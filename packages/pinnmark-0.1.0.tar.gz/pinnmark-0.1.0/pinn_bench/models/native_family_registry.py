"""PINNMark-native canonical family registry.

This layer internalizes the platform model universe above individual native or
external model identities:

- canonical family = benchmark-facing primary identity
- implementation variant = concrete runnable or reference implementation
- provenance / lineage = source benchmark and fidelity context
"""

from __future__ import annotations

from dataclasses import dataclass, field

INTERNALIZATION_DECLARED = "declared"
INTERNALIZATION_CONTRACT_DEFINED = "contract_defined"
INTERNALIZATION_PROXY_BACKED = "proxy_backed"
INTERNALIZATION_PARTIALLY_INTERNALIZED = "partially_internalized"
INTERNALIZATION_SOURCE_REFERENCE_ONLY = "source_reference_only"
INTERNALIZATION_NATIVE_IMPL = "native_impl_available"
INTERNALIZATION_BENCHMARK_READY = "benchmark_ready"


@dataclass(frozen=True)
class FamilyVariantRecord:
    """One implementation/provenance variant collapsed under a canonical family."""

    original_model_id: str
    original_type: str
    source_benchmark: str | None
    source_family_name: str | None
    current_native_equivalent: str | None
    canonical_family_id: str
    canonical_family_display_name: str
    canonical_family_category: str
    implementation_variant_id: str
    implementation_variant_role: str
    fidelity_level: str
    provenance_retained: bool
    collapse_confidence: str
    runtime_model_name: str | None = None
    notes: str = ""

    def to_dict(self) -> dict[str, object]:
        return {
            "original_model_id": self.original_model_id,
            "original_type": self.original_type,
            "source_benchmark": self.source_benchmark,
            "source_family_name": self.source_family_name,
            "current_native_equivalent": self.current_native_equivalent,
            "canonical_family_id": self.canonical_family_id,
            "canonical_family_display_name": self.canonical_family_display_name,
            "canonical_family_category": self.canonical_family_category,
            "implementation_variant_id": self.implementation_variant_id,
            "implementation_variant_role": self.implementation_variant_role,
            "fidelity_level": self.fidelity_level,
            "provenance_retained": self.provenance_retained,
            "collapse_confidence": self.collapse_confidence,
            "runtime_model_name": self.runtime_model_name,
            "notes": self.notes,
        }


@dataclass(frozen=True)
class CanonicalFamilyRecord:
    """Canonical benchmark-facing family identity."""

    family_id: str
    display_name: str
    family_category: str
    summary: str
    internalization_state: str
    default_variant_id: str | None
    default_model_name: str | None
    top_level_family_id: str
    top_level_family_display_name: str
    family_level: str
    benchmark_surface_compatibility: dict[str, str] = field(default_factory=dict)
    comparability_defaults: dict[str, str] = field(default_factory=dict)
    lineage_policy: str = ""
    variant_ids: tuple[str, ...] = field(default_factory=tuple)
    aliases: tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, object]:
        return {
            "family_id": self.family_id,
            "display_name": self.display_name,
            "family_category": self.family_category,
            "summary": self.summary,
            "internalization_state": self.internalization_state,
            "default_variant_id": self.default_variant_id,
            "default_model_name": self.default_model_name,
            "top_level_family_id": self.top_level_family_id,
            "top_level_family_display_name": self.top_level_family_display_name,
            "family_level": self.family_level,
            "benchmark_surface_compatibility": dict(self.benchmark_surface_compatibility),
            "comparability_defaults": dict(self.comparability_defaults),
            "lineage_policy": self.lineage_policy,
            "variant_ids": list(self.variant_ids),
            "aliases": list(self.aliases),
        }


_SURFACE_POINTWISE = {
    "nominal_anchor": "pointwise",
    "inverse_core": "pointwise",
    "sparse_extension": "pointwise",
    "noisy_extension": "pointwise",
    "joint_local_grid": "pointwise",
    "transfer_expansion": "appendix",
    "reference_context": "appendix",
}
_SURFACE_OPERATOR = {
    "nominal_anchor": "appendix",
    "inverse_core": "not_current",
    "sparse_extension": "not_current",
    "noisy_extension": "not_current",
    "joint_local_grid": "not_current",
    "transfer_expansion": "appendix",
    "reference_context": "appendix",
}
_SURFACE_REFERENCE = {surface: "reference_only" for surface in _SURFACE_POINTWISE}


def _variant(
    *,
    original_model_id: str,
    original_type: str,
    source_benchmark: str | None,
    source_family_name: str | None,
    current_native_equivalent: str | None,
    canonical_family_id: str,
    canonical_family_display_name: str,
    canonical_family_category: str,
    implementation_variant_id: str,
    implementation_variant_role: str,
    fidelity_level: str,
    provenance_retained: bool = True,
    collapse_confidence: str = "high",
    runtime_model_name: str | None = None,
    notes: str = "",
) -> FamilyVariantRecord:
    return FamilyVariantRecord(
        original_model_id=original_model_id,
        original_type=original_type,
        source_benchmark=source_benchmark,
        source_family_name=source_family_name,
        current_native_equivalent=current_native_equivalent,
        canonical_family_id=canonical_family_id,
        canonical_family_display_name=canonical_family_display_name,
        canonical_family_category=canonical_family_category,
        implementation_variant_id=implementation_variant_id,
        implementation_variant_role=implementation_variant_role,
        fidelity_level=fidelity_level,
        provenance_retained=provenance_retained,
        collapse_confidence=collapse_confidence,
        runtime_model_name=runtime_model_name,
        notes=notes,
    )


_VARIANTS: tuple[FamilyVariantRecord, ...] = (
    _variant(
        original_model_id="mlp",
        original_type="native",
        source_benchmark=None,
        source_family_name=None,
        current_native_equivalent="mlp",
        canonical_family_id="pinnmark.pinn.vanilla",
        canonical_family_display_name="PINNMark Vanilla PINN",
        canonical_family_category="pointwise_pinn",
        implementation_variant_id="native.mlp",
        implementation_variant_role="primary_native_impl",
        fidelity_level="native_authoritative",
        runtime_model_name="mlp",
    ),
    _variant(
        original_model_id="PDEBench::pinn",
        original_type="external",
        source_benchmark="PDEBench",
        source_family_name="pinn",
        current_native_equivalent="mlp",
        canonical_family_id="pinnmark.pinn.vanilla",
        canonical_family_display_name="PINNMark Vanilla PINN",
        canonical_family_category="pointwise_pinn",
        implementation_variant_id="external.pdebench.pinn_proxy",
        implementation_variant_role="external_proxy_variant",
        fidelity_level="proxy_family",
        runtime_model_name="ext_pdebench_pinn",
        notes="External benchmark lineage retained as provenance.",
    ),
    _variant(
        original_model_id="PDENNEval::PINN",
        original_type="external",
        source_benchmark="PDENNEval",
        source_family_name="PINN",
        current_native_equivalent="mlp",
        canonical_family_id="pinnmark.pinn.vanilla",
        canonical_family_display_name="PINNMark Vanilla PINN",
        canonical_family_category="pointwise_pinn",
        implementation_variant_id="external.pdenneval.pinn_proxy",
        implementation_variant_role="external_proxy_variant",
        fidelity_level="proxy_family",
        runtime_model_name="ext_pdenneval_pinn",
    ),
    _variant(
        original_model_id="PINNacle::fnn",
        original_type="external",
        source_benchmark="PINNacle",
        source_family_name="fnn",
        current_native_equivalent="mlp",
        canonical_family_id="pinnmark.pinn.vanilla",
        canonical_family_display_name="PINNMark Vanilla PINN",
        canonical_family_category="pointwise_pinn",
        implementation_variant_id="external.pinnacle.fnn_proxy",
        implementation_variant_role="external_proxy_variant",
        fidelity_level="proxy_family",
        runtime_model_name="ext_pinnacle_fnn",
    ),
    _variant(
        original_model_id="PINNacle::deepxde",
        original_type="external",
        source_benchmark="PINNacle",
        source_family_name="deepxde",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.framework.deepxde",
        canonical_family_display_name="PINNMark DeepXDE Lineage",
        canonical_family_category="framework_reference",
        implementation_variant_id="external.pinnacle.deepxde_framework",
        implementation_variant_role="framework_reference",
        fidelity_level="framework_reference",
        runtime_model_name=None,
        notes="Framework stack retained as lineage, not as a benchmark-facing method family.",
    ),
    _variant(
        original_model_id="siren",
        original_type="native",
        source_benchmark=None,
        source_family_name=None,
        current_native_equivalent="siren",
        canonical_family_id="pinnmark.pinn.siren",
        canonical_family_display_name="PINNMark SIREN PINN",
        canonical_family_category="pointwise_pinn",
        implementation_variant_id="native.siren",
        implementation_variant_role="primary_native_impl",
        fidelity_level="native_authoritative",
        runtime_model_name="siren",
    ),
    _variant(
        original_model_id="adaptive_mlp",
        original_type="native",
        source_benchmark=None,
        source_family_name=None,
        current_native_equivalent="adaptive_mlp",
        canonical_family_id="pinnmark.pinn.adaptive",
        canonical_family_display_name="PINNMark Adaptive PINN",
        canonical_family_category="pointwise_pinn",
        implementation_variant_id="native.adaptive_mlp",
        implementation_variant_role="native_profile_variant",
        fidelity_level="native_profile",
        runtime_model_name="adaptive_mlp",
        notes="Sampling-profile variant rather than adaptive-activation lineage.",
    ),
    _variant(
        original_model_id="PINNacle::laaf",
        original_type="external",
        source_benchmark="PINNacle",
        source_family_name="laaf",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.pinn.adaptive",
        canonical_family_display_name="PINNMark Adaptive PINN",
        canonical_family_category="pointwise_pinn",
        implementation_variant_id="external.pinnacle.laaf_adapter",
        implementation_variant_role="external_architecture_variant",
        fidelity_level="external_code_runnable",
        runtime_model_name="ext_pinnacle_laaf",
        collapse_confidence="medium",
        notes="Collapsed into the broader adaptive PINN family while preserving the activation-adaptive lineage as a distinct variant.",
    ),
    _variant(
        original_model_id="kan",
        original_type="native",
        source_benchmark=None,
        source_family_name=None,
        current_native_equivalent="kan",
        canonical_family_id="pinnmark.pinn.kan",
        canonical_family_display_name="PINNMark KAN PINN",
        canonical_family_category="pointwise_pinn",
        implementation_variant_id="native.kan",
        implementation_variant_role="primary_native_impl",
        fidelity_level="native_authoritative",
        runtime_model_name="kan",
    ),
    _variant(
        original_model_id="PINNacle::hard_constraint",
        original_type="external",
        source_benchmark="PINNacle",
        source_family_name="hard_constraint",
        current_native_equivalent="mlp",
        canonical_family_id="pinnmark.pinn.hard_constraint",
        canonical_family_display_name="PINNMark Hard-Constraint PINN",
        canonical_family_category="pointwise_pinn",
        implementation_variant_id="external.pinnacle.hard_constraint_runtime_hook",
        implementation_variant_role="external_runtime_hook_variant",
        fidelity_level="partially_internalized",
        runtime_model_name="ext_pinnacle_hard_constraint",
    ),
    _variant(
        original_model_id="xpinn_mlp",
        original_type="native",
        source_benchmark=None,
        source_family_name=None,
        current_native_equivalent="xpinn_mlp",
        canonical_family_id="pinnmark.pinn.xpinn",
        canonical_family_display_name="PINNMark XPINN",
        canonical_family_category="pointwise_pinn",
        implementation_variant_id="native.xpinn_mlp",
        implementation_variant_role="primary_native_impl",
        fidelity_level="native_authoritative",
        runtime_model_name="xpinn_mlp",
    ),
    _variant(
        original_model_id="PINNacle::vpinn",
        original_type="external",
        source_benchmark="PINNacle",
        source_family_name="vpinn",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.pinn.vpinn",
        canonical_family_display_name="PINNMark VPINN",
        canonical_family_category="pointwise_pinn",
        implementation_variant_id="external.pinnacle.vpinn_reference",
        implementation_variant_role="source_reference_variant",
        fidelity_level="source_reference_only",
        runtime_model_name=None,
    ),
    _variant(
        original_model_id="mini_fno",
        original_type="native",
        source_benchmark=None,
        source_family_name=None,
        current_native_equivalent="mini_fno",
        canonical_family_id="pinnmark.operator.fno",
        canonical_family_display_name="PINNMark Operator FNO",
        canonical_family_category="operator_family",
        implementation_variant_id="native.mini_fno",
        implementation_variant_role="primary_native_impl",
        fidelity_level="native_authoritative",
        runtime_model_name="mini_fno",
    ),
    _variant(
        original_model_id="PDEBench::fno",
        original_type="external",
        source_benchmark="PDEBench",
        source_family_name="fno",
        current_native_equivalent="mini_fno",
        canonical_family_id="pinnmark.operator.fno",
        canonical_family_display_name="PINNMark Operator FNO",
        canonical_family_category="operator_family",
        implementation_variant_id="external.pdebench.fno_proxy",
        implementation_variant_role="external_proxy_variant",
        fidelity_level="proxy_family",
        runtime_model_name="ext_pdebench_fno",
    ),
    _variant(
        original_model_id="PDENNEval::FNO",
        original_type="external",
        source_benchmark="PDENNEval",
        source_family_name="FNO",
        current_native_equivalent="mini_fno",
        canonical_family_id="pinnmark.operator.fno",
        canonical_family_display_name="PINNMark Operator FNO",
        canonical_family_category="operator_family",
        implementation_variant_id="external.pdenneval.fno_proxy",
        implementation_variant_role="external_proxy_variant",
        fidelity_level="proxy_family",
        runtime_model_name="ext_pdenneval_fno",
    ),
    _variant(
        original_model_id="PDENNEval::PINO",
        original_type="external",
        source_benchmark="PDENNEval",
        source_family_name="PINO",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.operator.pino",
        canonical_family_display_name="PINNMark Operator PINO",
        canonical_family_category="operator_family",
        implementation_variant_id="external.pdenneval.pino_reference",
        implementation_variant_role="source_reference_variant",
        fidelity_level="adapter_classified",
        runtime_model_name=None,
    ),
    _variant(
        original_model_id="PDENNEval::DeepONet",
        original_type="external",
        source_benchmark="PDENNEval",
        source_family_name="DeepONet",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.operator.deeponet",
        canonical_family_display_name="PINNMark Operator DeepONet",
        canonical_family_category="operator_family",
        implementation_variant_id="external.pdenneval.deeponet_adapter",
        implementation_variant_role="external_architecture_variant",
        fidelity_level="external_code_runnable",
        runtime_model_name="ext_pdenneval_deeponet",
    ),
    _variant(
        original_model_id="PDENNEval::UNet",
        original_type="external",
        source_benchmark="PDENNEval",
        source_family_name="UNet",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.operator.unet",
        canonical_family_display_name="PINNMark Operator UNet",
        canonical_family_category="operator_family",
        implementation_variant_id="external.pdenneval.unet_reference",
        implementation_variant_role="source_reference_variant",
        fidelity_level="source_reference_only",
        runtime_model_name=None,
    ),
    _variant(
        original_model_id="PDEBench::unet",
        original_type="external",
        source_benchmark="PDEBench",
        source_family_name="unet",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.operator.unet",
        canonical_family_display_name="PINNMark Operator UNet",
        canonical_family_category="operator_family",
        implementation_variant_id="external.pdebench.unet_reference",
        implementation_variant_role="source_reference_variant",
        fidelity_level="source_reference_only",
        runtime_model_name=None,
    ),
    _variant(
        original_model_id="PDENNEval::UNO",
        original_type="external",
        source_benchmark="PDENNEval",
        source_family_name="UNO",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.operator.uno",
        canonical_family_display_name="PINNMark Operator UNO",
        canonical_family_category="operator_family",
        implementation_variant_id="external.pdenneval.uno_reference",
        implementation_variant_role="source_reference_variant",
        fidelity_level="source_reference_only",
        runtime_model_name=None,
    ),
    _variant(
        original_model_id="PDENNEval::MPNN",
        original_type="external",
        source_benchmark="PDENNEval",
        source_family_name="MPNN",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.operator.mpnn",
        canonical_family_display_name="PINNMark Operator MPNN",
        canonical_family_category="operator_family",
        implementation_variant_id="external.pdenneval.mpnn_reference",
        implementation_variant_role="source_reference_variant",
        fidelity_level="source_reference_only",
        runtime_model_name=None,
    ),
    _variant(
        original_model_id="PINNacle::fbpinns",
        original_type="external",
        source_benchmark="PINNacle",
        source_family_name="fbpinns",
        current_native_equivalent="xpinn_mlp",
        canonical_family_id="pinnmark.hybrid.fbpinn",
        canonical_family_display_name="PINNMark FBPINN-style Hybrid",
        canonical_family_category="hybrid_family",
        implementation_variant_id="external.pinnacle.fbpinn_proxy",
        implementation_variant_role="external_proxy_variant",
        fidelity_level="proxy_family",
        runtime_model_name="ext_pinnacle_fbpinns",
    ),
    _variant(
        original_model_id="grid_mlp",
        original_type="native",
        source_benchmark=None,
        source_family_name=None,
        current_native_equivalent="grid_mlp",
        canonical_family_id="pinnmark.hybrid.grid_mlp",
        canonical_family_display_name="PINNMark Grid MLP Hybrid",
        canonical_family_category="hybrid_family",
        implementation_variant_id="native.grid_mlp",
        implementation_variant_role="primary_native_impl",
        fidelity_level="native_authoritative",
        runtime_model_name="grid_mlp",
    ),
    _variant(
        original_model_id="spectral_mlp",
        original_type="native",
        source_benchmark=None,
        source_family_name=None,
        current_native_equivalent="spectral_mlp",
        canonical_family_id="pinnmark.hybrid.spectral_mlp",
        canonical_family_display_name="PINNMark Spectral MLP Hybrid",
        canonical_family_category="hybrid_family",
        implementation_variant_id="native.spectral_mlp",
        implementation_variant_role="primary_native_impl",
        fidelity_level="native_authoritative",
        runtime_model_name="spectral_mlp",
    ),
    _variant(
        original_model_id="pdearena::pdemodel",
        original_type="external",
        source_benchmark="pdearena",
        source_family_name="pdemodel",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.operator.wrapper",
        canonical_family_display_name="PINNMark Operator Wrapper Surface",
        canonical_family_category="operator_wrapper",
        implementation_variant_id="external.pdearena.pdemodel_wrapper",
        implementation_variant_role="wrapper_reference",
        fidelity_level="blocked_reference",
        runtime_model_name=None,
    ),
    _variant(
        original_model_id="pdearena::cond_pdemodel",
        original_type="external",
        source_benchmark="pdearena",
        source_family_name="cond_pdemodel",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.operator.wrapper",
        canonical_family_display_name="PINNMark Operator Wrapper Surface",
        canonical_family_category="operator_wrapper",
        implementation_variant_id="external.pdearena.cond_pdemodel_wrapper",
        implementation_variant_role="wrapper_reference",
        fidelity_level="blocked_reference",
        runtime_model_name=None,
    ),
    _variant(
        original_model_id="pdearena::pderefiner",
        original_type="external",
        source_benchmark="pdearena",
        source_family_name="pderefiner",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.operator.refiner",
        canonical_family_display_name="PINNMark Operator Refiner",
        canonical_family_category="operator_wrapper",
        implementation_variant_id="external.pdearena.pderefiner_reference",
        implementation_variant_role="wrapper_reference",
        fidelity_level="blocked_reference",
        runtime_model_name=None,
    ),
    _variant(
        original_model_id="PDENNEval::DRM",
        original_type="external",
        source_benchmark="PDENNEval",
        source_family_name="DRM",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.solver.weak_form",
        canonical_family_display_name="PINNMark Weak-Form Solver Family",
        canonical_family_category="solver_family",
        implementation_variant_id="external.pdenneval.drm_reference",
        implementation_variant_role="source_reference_variant",
        fidelity_level="source_reference_only",
        runtime_model_name=None,
    ),
    _variant(
        original_model_id="PDENNEval::DFLM",
        original_type="external",
        source_benchmark="PDENNEval",
        source_family_name="DFLM",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.solver.weak_form",
        canonical_family_display_name="PINNMark Weak-Form Solver Family",
        canonical_family_category="solver_family",
        implementation_variant_id="external.pdenneval.dflm_reference",
        implementation_variant_role="source_reference_variant",
        fidelity_level="source_reference_only",
        runtime_model_name=None,
    ),
    _variant(
        original_model_id="PDENNEval::DFVM",
        original_type="external",
        source_benchmark="PDENNEval",
        source_family_name="DFVM",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.solver.weak_form",
        canonical_family_display_name="PINNMark Weak-Form Solver Family",
        canonical_family_category="solver_family",
        implementation_variant_id="external.pdenneval.dfvm_reference",
        implementation_variant_role="source_reference_variant",
        fidelity_level="source_reference_only",
        runtime_model_name=None,
    ),
    _variant(
        original_model_id="PDENNEval::WAN",
        original_type="external",
        source_benchmark="PDENNEval",
        source_family_name="WAN",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.solver.weak_form",
        canonical_family_display_name="PINNMark Weak-Form Solver Family",
        canonical_family_category="solver_family",
        implementation_variant_id="external.pdenneval.wan_reference",
        implementation_variant_role="source_reference_variant",
        fidelity_level="source_reference_only",
        runtime_model_name=None,
    ),
    _variant(
        original_model_id="PDENNEval::RFM",
        original_type="external",
        source_benchmark="PDENNEval",
        source_family_name="RFM",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.solver.random_feature",
        canonical_family_display_name="PINNMark Random-Feature Solver Family",
        canonical_family_category="solver_family",
        implementation_variant_id="external.pdenneval.rfm_reference",
        implementation_variant_role="source_reference_variant",
        fidelity_level="source_reference_only",
        runtime_model_name=None,
    ),
    _variant(
        original_model_id="PDEBench::inverse",
        original_type="external",
        source_benchmark="PDEBench",
        source_family_name="inverse",
        current_native_equivalent=None,
        canonical_family_id="pinnmark.solver.inverse_wrapper",
        canonical_family_display_name="PINNMark Inverse Wrapper Surface",
        canonical_family_category="solver_family",
        implementation_variant_id="external.pdebench.inverse_wrapper",
        implementation_variant_role="wrapper_reference",
        fidelity_level="blocked_reference",
        runtime_model_name=None,
    ),
)


def _family(
    *,
    family_id: str,
    display_name: str,
    family_category: str,
    summary: str,
    internalization_state: str,
    default_variant_id: str | None,
    default_model_name: str | None,
    top_level_family_id: str | None = None,
    top_level_family_display_name: str | None = None,
    family_level: str | None = None,
    benchmark_surface_compatibility: dict[str, str],
    comparability_defaults: dict[str, str],
    lineage_policy: str,
    aliases: tuple[str, ...] = (),
) -> CanonicalFamilyRecord:
    variant_ids = tuple(
        variant.implementation_variant_id
        for variant in _VARIANTS
        if variant.canonical_family_id == family_id
    )
    resolved_family_level = family_level
    if resolved_family_level is None:
        if family_category in {"framework_reference", "solver_family", "operator_wrapper"}:
            resolved_family_level = "reference"
        else:
            resolved_family_level = "primary_method"
    return CanonicalFamilyRecord(
        family_id=family_id,
        display_name=display_name,
        family_category=family_category,
        summary=summary,
        internalization_state=internalization_state,
        default_variant_id=default_variant_id,
        default_model_name=default_model_name,
        top_level_family_id=family_id if top_level_family_id is None else top_level_family_id,
        top_level_family_display_name=display_name if top_level_family_display_name is None else top_level_family_display_name,
        family_level=resolved_family_level,
        benchmark_surface_compatibility=benchmark_surface_compatibility,
        comparability_defaults=comparability_defaults,
        lineage_policy=lineage_policy,
        variant_ids=variant_ids,
        aliases=tuple(aliases),
    )


_FAMILIES: tuple[CanonicalFamilyRecord, ...] = (
    _family(
        family_id="pinnmark.pinn.vanilla",
        display_name="PINNMark Vanilla PINN",
        family_category="pointwise_pinn",
        summary="Canonical pointwise residual PINN family used for the matched-budget nominal and inverse-centered benchmark line.",
        internalization_state=INTERNALIZATION_BENCHMARK_READY,
        default_variant_id="native.mlp",
        default_model_name="mlp",
        benchmark_surface_compatibility=dict(_SURFACE_POINTWISE),
        comparability_defaults={"mainline_role": "nominal_anchor_and_inverse_core"},
        lineage_policy="Collapse vanilla external PINN lineages into one benchmark-facing family while preserving each benchmark lineage as variants.",
    ),
    _family(
        family_id="pinnmark.pinn.siren",
        display_name="PINNMark SIREN PINN",
        family_category="pointwise_pinn",
        summary="Oscillatory pointwise PINN family used as a native non-vanilla baseline.",
        internalization_state=INTERNALIZATION_BENCHMARK_READY,
        default_variant_id="native.siren",
        default_model_name="siren",
        benchmark_surface_compatibility=dict(_SURFACE_POINTWISE),
        comparability_defaults={"mainline_role": "native_non_vanilla_pointwise"},
        lineage_policy="Native family without external collapse pressure today.",
    ),
    _family(
        family_id="pinnmark.pinn.adaptive",
        display_name="PINNMark Adaptive PINN",
        family_category="pointwise_pinn",
        summary="Broader adaptive PINN family that currently covers both native residual-adaptive sampling and activation-adaptive external lineages.",
        internalization_state=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        default_variant_id="native.adaptive_mlp",
        default_model_name="adaptive_mlp",
        benchmark_surface_compatibility=dict(_SURFACE_POINTWISE),
        comparability_defaults={"mainline_role": "native_profile_variant"},
        lineage_policy="Collapse adaptive sampling and adaptive activation into one family while preserving variant-level semantics explicitly.",
        aliases=("adaptive_pinn",),
    ),
    _family(
        family_id="pinnmark.pinn.kan",
        display_name="PINNMark KAN PINN",
        family_category="pointwise_pinn",
        summary="Pointwise KAN-based PINN family.",
        internalization_state=INTERNALIZATION_NATIVE_IMPL,
        default_variant_id="native.kan",
        default_model_name="kan",
        benchmark_surface_compatibility=dict(_SURFACE_POINTWISE),
        comparability_defaults={"mainline_role": "native_pointwise_variant"},
        lineage_policy="Native-only family for now.",
    ),
    _family(
        family_id="pinnmark.pinn.hard_constraint",
        display_name="PINNMark Hard-Constraint PINN",
        family_category="pointwise_pinn",
        summary="Task-coupled hard-constraint PINN family with output-transform semantics.",
        internalization_state=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        default_variant_id="external.pinnacle.hard_constraint_runtime_hook",
        default_model_name="ext_pinnacle_hard_constraint",
        benchmark_surface_compatibility=dict(_SURFACE_POINTWISE),
        comparability_defaults={"mainline_role": "temporal_appendix_candidate"},
        lineage_policy="Keep external PINNacle lineage as provenance while promoting the family as a PINNMark-native contract.",
        aliases=("hard_constraint", "hard-constraint-pinn"),
    ),
    _family(
        family_id="pinnmark.pinn.xpinn",
        display_name="PINNMark XPINN",
        family_category="pointwise_pinn",
        summary="Domain-decomposition pointwise PINN family centered on native XPINN-style routing.",
        internalization_state=INTERNALIZATION_NATIVE_IMPL,
        default_variant_id="native.xpinn_mlp",
        default_model_name="xpinn_mlp",
        top_level_family_id="pinnmark.pinn.domain_decomposition",
        top_level_family_display_name="PINNMark Domain-Decomposition PINNs",
        benchmark_surface_compatibility=dict(_SURFACE_POINTWISE),
        comparability_defaults={"mainline_role": "decomposition_native_variant"},
        lineage_policy="Native XPINN remains separate from FBPINN lineage.",
        aliases=("XPINN", "xpinn"),
    ),
    _family(
        family_id="pinnmark.pinn.vpinn",
        display_name="PINNMark VPINN",
        family_category="pointwise_pinn",
        summary="Variational PINN family requiring weak-form / quadrature-aware runtime support.",
        internalization_state=INTERNALIZATION_CONTRACT_DEFINED,
        default_variant_id=None,
        default_model_name=None,
        top_level_family_id="pinnmark.pinn.variational",
        top_level_family_display_name="PINNMark Variational PINNs",
        benchmark_surface_compatibility=dict(_SURFACE_REFERENCE),
        comparability_defaults={"mainline_role": "not_yet"},
        lineage_policy="Currently represented only through external reference lineage until variational runtime support exists.",
        aliases=("VPINN", "vpinn"),
    ),
    _family(
        family_id="pinnmark.pinn.domain_decomposition",
        display_name="PINNMark Domain-Decomposition PINNs",
        family_category="pointwise_pinn",
        summary="Top-level canonical family for domain-decomposition PINN methods such as cPINN, XPINN-style routing, and FBPINN-adjacent decomposition branches.",
        internalization_state=INTERNALIZATION_CONTRACT_DEFINED,
        default_variant_id=None,
        default_model_name=None,
        family_level="umbrella",
        benchmark_surface_compatibility=dict(_SURFACE_POINTWISE),
        comparability_defaults={"mainline_role": "bounded_support"},
        lineage_policy="Use as the stable umbrella for decomposition-first pointwise PINN subfamilies without flattening conservative, finite-basis, or interface-aware semantics into one proxy implementation.",
        aliases=("domain_decomposition", "decomposition_pinn"),
    ),
    _family(
        family_id="pinnmark.pinn.bayesian",
        display_name="PINNMark Bayesian PINNs",
        family_category="pointwise_pinn",
        summary="Top-level canonical family for Bayesian and uncertainty-aware physics-informed neural networks.",
        internalization_state=INTERNALIZATION_CONTRACT_DEFINED,
        default_variant_id=None,
        default_model_name=None,
        family_level="umbrella",
        benchmark_surface_compatibility=dict(_SURFACE_REFERENCE),
        comparability_defaults={"mainline_role": "not_yet"},
        lineage_policy="Keep Bayesian posterior/inference semantics explicit rather than collapsing them into vanilla multi-seed pointwise PINNs.",
        aliases=("bayesian_pinn",),
    ),
    _family(
        family_id="pinnmark.pinn.residual_adaptive",
        display_name="PINNMark Residual-Adaptive Architectures",
        family_category="pointwise_pinn",
        summary="Top-level canonical family for architecture-level residual-adaptive PINN designs such as PirateNets.",
        internalization_state=INTERNALIZATION_CONTRACT_DEFINED,
        default_variant_id=None,
        default_model_name=None,
        family_level="umbrella",
        benchmark_surface_compatibility=dict(_SURFACE_POINTWISE),
        comparability_defaults={"mainline_role": "not_yet"},
        lineage_policy="Separate architecture-driven residual adaptation from sampling-adaptive or activation-adaptive PINN families.",
        aliases=("residual_adaptive",),
    ),
    _family(
        family_id="pinnmark.pinn.transformer",
        display_name="PINNMark Transformer PINNs",
        family_category="pointwise_pinn",
        summary="Top-level canonical family for transformer-based physics-informed sequence models such as PINNsFormer.",
        internalization_state=INTERNALIZATION_CONTRACT_DEFINED,
        default_variant_id=None,
        default_model_name=None,
        family_level="umbrella",
        benchmark_surface_compatibility=dict(_SURFACE_POINTWISE),
        comparability_defaults={"mainline_role": "not_yet"},
        lineage_policy="Keep transformer/sequence-model semantics explicit instead of flattening them into generic attention or MLP variants.",
        aliases=("transformer_pinn",),
    ),
    _family(
        family_id="pinnmark.pinn.attention_sequence",
        display_name="PINNMark Attention/Sequence PINNs",
        family_category="pointwise_pinn",
        summary="Top-level canonical family for attention- or recurrent-sequence PINN architectures such as PIANN.",
        internalization_state=INTERNALIZATION_CONTRACT_DEFINED,
        default_variant_id=None,
        default_model_name=None,
        family_level="umbrella",
        benchmark_surface_compatibility=dict(_SURFACE_POINTWISE),
        comparability_defaults={"mainline_role": "not_yet"},
        lineage_policy="Use for sequence/attention PINN methods that are not naturally operator families and should not be collapsed into adaptive-weighting methods.",
        aliases=("attention_sequence_pinn",),
    ),
    _family(
        family_id="pinnmark.pinn.separable",
        display_name="PINNMark Separable PINNs",
        family_category="pointwise_pinn",
        summary="Top-level canonical family for separable or axis-factorized PINN architectures such as SPINN.",
        internalization_state=INTERNALIZATION_CONTRACT_DEFINED,
        default_variant_id=None,
        default_model_name=None,
        family_level="umbrella",
        benchmark_surface_compatibility=dict(_SURFACE_POINTWISE),
        comparability_defaults={"mainline_role": "not_yet"},
        lineage_policy="Keep separable/factorized architecture semantics distinct from compact MLP baselines.",
        aliases=("separable_pinn",),
    ),
    _family(
        family_id="pinnmark.pinn.causal_time_marching",
        display_name="PINNMark Causal Time-Marching PINNs",
        family_category="pointwise_pinn",
        summary="Top-level canonical family for causality-respecting or time-sweeping PINN training methods.",
        internalization_state=INTERNALIZATION_CONTRACT_DEFINED,
        default_variant_id=None,
        default_model_name=None,
        family_level="umbrella",
        benchmark_surface_compatibility=dict(_SURFACE_POINTWISE),
        comparability_defaults={"mainline_role": "not_yet"},
        lineage_policy="Use for time-causal curriculum/sweeping methods rather than flattening them into vanilla time-dependent PINNs.",
        aliases=("causal_time_marching", "causal_pinn"),
    ),
    _family(
        family_id="pinnmark.operator.fno",
        display_name="PINNMark Operator FNO",
        family_category="operator_family",
        summary="Canonical Fourier operator family for PINNMark's operator-native branch.",
        internalization_state=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        default_variant_id="native.mini_fno",
        default_model_name="mini_fno",
        benchmark_surface_compatibility=dict(_SURFACE_OPERATOR),
        comparability_defaults={"mainline_role": "operator_appendix_branch"},
        lineage_policy="Collapse native mini_fno and external FNO lineages into one operator family while retaining proxy/source distinctions as variants.",
        aliases=("FNO", "fno", "fourier_neural_operator"),
    ),
    _family(
        family_id="pinnmark.operator.pino",
        display_name="PINNMark Operator PINO",
        family_category="operator_family",
        summary="Physics-informed neural operator family.",
        internalization_state=INTERNALIZATION_CONTRACT_DEFINED,
        default_variant_id=None,
        default_model_name=None,
        benchmark_surface_compatibility=dict(_SURFACE_OPERATOR),
        comparability_defaults={"mainline_role": "future_operator_branch"},
        lineage_policy="External lineage retained until benchmark-faithful operator+physics runtime exists.",
    ),
    _family(
        family_id="pinnmark.operator.deeponet",
        display_name="PINNMark Operator DeepONet",
        family_category="operator_family",
        summary="Canonical branch-trunk neural operator family.",
        internalization_state=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        default_variant_id="external.pdenneval.deeponet_adapter",
        default_model_name="ext_pdenneval_deeponet",
        benchmark_surface_compatibility=dict(_SURFACE_OPERATOR),
        comparability_defaults={"mainline_role": "operator_appendix_branch"},
        lineage_policy="Promote the operator family identity while keeping the PDENNEval lineage as the current implementation reference.",
        aliases=("DeepONet", "deeponet"),
    ),
    _family(
        family_id="pinnmark.operator.unet",
        display_name="PINNMark Operator UNet",
        family_category="operator_family",
        summary="Autoregressive UNet-style operator family.",
        internalization_state=INTERNALIZATION_SOURCE_REFERENCE_ONLY,
        default_variant_id=None,
        default_model_name=None,
        benchmark_surface_compatibility=dict(_SURFACE_OPERATOR),
        comparability_defaults={"mainline_role": "not_yet"},
        lineage_policy="External references only; no native or runnable implementation promoted yet.",
    ),
    _family(
        family_id="pinnmark.operator.uno",
        display_name="PINNMark Operator UNO",
        family_category="operator_family",
        summary="UNO-style neural operator family.",
        internalization_state=INTERNALIZATION_SOURCE_REFERENCE_ONLY,
        default_variant_id=None,
        default_model_name=None,
        benchmark_surface_compatibility=dict(_SURFACE_OPERATOR),
        comparability_defaults={"mainline_role": "not_yet"},
        lineage_policy="External references only.",
    ),
    _family(
        family_id="pinnmark.operator.mpnn",
        display_name="PINNMark Operator MPNN",
        family_category="operator_family",
        summary="Graph/message-passing operator family.",
        internalization_state=INTERNALIZATION_SOURCE_REFERENCE_ONLY,
        default_variant_id=None,
        default_model_name=None,
        benchmark_surface_compatibility=dict(_SURFACE_OPERATOR),
        comparability_defaults={"mainline_role": "not_yet"},
        lineage_policy="External graph-operator lineage only.",
    ),
    _family(
        family_id="pinnmark.hybrid.fbpinn",
        display_name="PINNMark FBPINN-style Hybrid",
        family_category="hybrid_family",
        summary="Family for FBPINN-style decomposition methods distinct from XPINN proper.",
        internalization_state=INTERNALIZATION_PROXY_BACKED,
        default_variant_id="external.pinnacle.fbpinn_proxy",
        default_model_name="ext_pinnacle_fbpinns",
        top_level_family_id="pinnmark.pinn.domain_decomposition",
        top_level_family_display_name="PINNMark Domain-Decomposition PINNs",
        benchmark_surface_compatibility=dict(_SURFACE_OPERATOR | _SURFACE_POINTWISE),
        comparability_defaults={"mainline_role": "bounded_support"},
        lineage_policy="Keep source-faithfulness warnings explicit; current family identity is more mature than the implementation fidelity.",
        aliases=("FBPINN", "FBPINNs", "fbpinn", "fbpinns"),
    ),
    _family(
        family_id="pinnmark.hybrid.grid_mlp",
        display_name="PINNMark Grid MLP Hybrid",
        family_category="hybrid_family",
        summary="Native grid-aware MLP field family.",
        internalization_state=INTERNALIZATION_NATIVE_IMPL,
        default_variant_id="native.grid_mlp",
        default_model_name="grid_mlp",
        benchmark_surface_compatibility=dict(_SURFACE_OPERATOR),
        comparability_defaults={"mainline_role": "inverse_field_shell"},
        lineage_policy="Native-only family.",
    ),
    _family(
        family_id="pinnmark.hybrid.spectral_mlp",
        display_name="PINNMark Spectral MLP Hybrid",
        family_category="hybrid_family",
        summary="Native spectral-feature MLP family.",
        internalization_state=INTERNALIZATION_NATIVE_IMPL,
        default_variant_id="native.spectral_mlp",
        default_model_name="spectral_mlp",
        benchmark_surface_compatibility=dict(_SURFACE_OPERATOR),
        comparability_defaults={"mainline_role": "inverse_field_shell"},
        lineage_policy="Native-only family.",
    ),
    _family(
        family_id="pinnmark.framework.deepxde",
        display_name="PINNMark DeepXDE Lineage",
        family_category="framework_reference",
        summary="Framework/runtime lineage retained for provenance, not a benchmark-facing model family.",
        internalization_state=INTERNALIZATION_SOURCE_REFERENCE_ONLY,
        default_variant_id=None,
        default_model_name=None,
        benchmark_surface_compatibility=dict(_SURFACE_REFERENCE),
        comparability_defaults={"mainline_role": "reference_only"},
        lineage_policy="Framework lineage only.",
    ),
    _family(
        family_id="pinnmark.solver.weak_form",
        display_name="PINNMark Weak-Form Solver Family",
        family_category="solver_family",
        summary="Grouped weak-form / alternative solver family references (DRM/DFLM/DFVM/WAN).",
        internalization_state=INTERNALIZATION_SOURCE_REFERENCE_ONLY,
        default_variant_id=None,
        default_model_name=None,
        benchmark_surface_compatibility=dict(_SURFACE_REFERENCE),
        comparability_defaults={"mainline_role": "reference_only"},
        lineage_policy="Grouped solver-adjacent provenance until a benchmark-facing weak-form contract exists.",
    ),
    _family(
        family_id="pinnmark.solver.random_feature",
        display_name="PINNMark Random-Feature Solver Family",
        family_category="solver_family",
        summary="Random-feature-based solver family reference.",
        internalization_state=INTERNALIZATION_SOURCE_REFERENCE_ONLY,
        default_variant_id=None,
        default_model_name=None,
        benchmark_surface_compatibility=dict(_SURFACE_REFERENCE),
        comparability_defaults={"mainline_role": "reference_only"},
        lineage_policy="Reference-only until there is a benchmark-facing contract.",
    ),
    _family(
        family_id="pinnmark.operator.wrapper",
        display_name="PINNMark Operator Wrapper Surface",
        family_category="operator_wrapper",
        summary="Wrapper/runtime surfaces from external operator platforms retained for provenance only.",
        internalization_state=INTERNALIZATION_SOURCE_REFERENCE_ONLY,
        default_variant_id=None,
        default_model_name=None,
        benchmark_surface_compatibility=dict(_SURFACE_REFERENCE),
        comparability_defaults={"mainline_role": "reference_only"},
        lineage_policy="Wrapper reference only; not a comparable method family today.",
    ),
    _family(
        family_id="pinnmark.operator.refiner",
        display_name="PINNMark Operator Refiner",
        family_category="operator_wrapper",
        summary="Refinement/corrector operator family reference.",
        internalization_state=INTERNALIZATION_SOURCE_REFERENCE_ONLY,
        default_variant_id=None,
        default_model_name=None,
        benchmark_surface_compatibility=dict(_SURFACE_REFERENCE),
        comparability_defaults={"mainline_role": "reference_only"},
        lineage_policy="Reference-only until the refinement runtime becomes benchmark-facing.",
    ),
    _family(
        family_id="pinnmark.solver.inverse_wrapper",
        display_name="PINNMark Inverse Wrapper Surface",
        family_category="solver_family",
        summary="Inverse-wrapper lineage retained for provenance.",
        internalization_state=INTERNALIZATION_SOURCE_REFERENCE_ONLY,
        default_variant_id=None,
        default_model_name=None,
        benchmark_surface_compatibility=dict(_SURFACE_REFERENCE),
        comparability_defaults={"mainline_role": "reference_only"},
        lineage_policy="Wrapper reference only.",
    ),
    _family(
        family_id="pinnmark.operator.inverse_operator",
        display_name="PINNMark Inverse Operators",
        family_category="operator_family",
        summary="Top-level canonical family for inverse-operator methods such as PI-DION.",
        internalization_state=INTERNALIZATION_CONTRACT_DEFINED,
        default_variant_id=None,
        default_model_name=None,
        family_level="umbrella",
        benchmark_surface_compatibility=dict(_SURFACE_OPERATOR),
        comparability_defaults={"mainline_role": "future_operator_branch"},
        lineage_policy="Use when the core semantics are inverse-operator inference from measurements rather than forward operator rollout.",
        aliases=("inverse_operator",),
    ),
    _family(
        family_id="pinnmark.operator.geometry_aware",
        display_name="PINNMark Geometry-Aware Operators",
        family_category="operator_family",
        summary="Top-level canonical family for geometry-conditioned neural operators such as PI-GANO.",
        internalization_state=INTERNALIZATION_CONTRACT_DEFINED,
        default_variant_id=None,
        default_model_name=None,
        family_level="umbrella",
        benchmark_surface_compatibility=dict(_SURFACE_OPERATOR),
        comparability_defaults={"mainline_role": "future_operator_branch"},
        lineage_policy="Keep geometry-aware operator families separate from plain FNO/DeepONet/PINO rollouts until geometry-conditioned runtime and tasks are benchmark-native.",
        aliases=("geometry_aware_operator",),
    ),
    _family(
        family_id="pinnmark.operator.variational",
        display_name="PINNMark Variational Operators",
        family_category="operator_family",
        summary="Top-level canonical family for variational or energy-based neural operators such as VINO.",
        internalization_state=INTERNALIZATION_CONTRACT_DEFINED,
        default_variant_id=None,
        default_model_name=None,
        family_level="umbrella",
        benchmark_surface_compatibility=dict(_SURFACE_OPERATOR),
        comparability_defaults={"mainline_role": "future_operator_branch"},
        lineage_policy="Separate variational/integral operator semantics from both pointwise VPINN-style families and standard operator rollouts.",
        aliases=("variational_operator",),
    ),
    _family(
        family_id="pinnmark.multifidelity.physics_informed",
        display_name="PINNMark Multi-Fidelity Physics-Informed Models",
        family_category="multifidelity_family",
        summary="Top-level canonical family for multi-fidelity physics-informed models such as MF-PIDNN.",
        internalization_state=INTERNALIZATION_CONTRACT_DEFINED,
        default_variant_id=None,
        default_model_name=None,
        family_level="umbrella",
        benchmark_surface_compatibility=dict(_SURFACE_REFERENCE),
        comparability_defaults={"mainline_role": "future_multifidelity_branch"},
        lineage_policy="Reserve a distinct family axis for low-/high-fidelity coupling rather than collapsing multi-fidelity methods into vanilla PINN or operator families.",
        aliases=("multifidelity_physics_informed", "multifidelity"),
    ),
)

_FAMILY_INDEX = {record.family_id: record for record in _FAMILIES}
_VARIANTS_BY_FAMILY: dict[str, list[FamilyVariantRecord]] = {}
for variant in _VARIANTS:
    _VARIANTS_BY_FAMILY.setdefault(variant.canonical_family_id, []).append(variant)
_MODEL_TO_FAMILY = {variant.original_model_id.lower(): variant.canonical_family_id for variant in _VARIANTS}
_FAMILY_ALIAS_TO_ID: dict[str, str] = {}
for record in _FAMILIES:
    for alias in (record.family_id, record.display_name, *record.aliases):
        key = str(alias).strip().lower()
        if key:
            _FAMILY_ALIAS_TO_ID[key] = record.family_id


def list_canonical_families() -> list[str]:
    """Return sorted canonical family ids."""
    return sorted(_FAMILY_INDEX)


def list_top_level_families() -> list[str]:
    """Return sorted top-level family ids."""
    return sorted({record.top_level_family_id for record in _FAMILIES})


def list_primary_method_families() -> list[str]:
    """Return sorted canonical family ids that act as primary method objects."""
    return sorted(record.family_id for record in _FAMILIES if record.family_level == "primary_method")


def resolve_canonical_family_name(name: str) -> str:
    """Resolve canonical family ids, display names, and aliases."""
    key = str(name).strip().lower()
    if key in _FAMILY_ALIAS_TO_ID:
        return _FAMILY_ALIAS_TO_ID[key]
    available = ", ".join(sorted(_FAMILY_INDEX)) or "<empty>"
    raise KeyError(f"Unknown canonical family '{name}'. Available: {available}")


def get_canonical_family_record(family_id: str) -> CanonicalFamilyRecord:
    """Return one canonical family record."""
    key = resolve_canonical_family_name(family_id)
    if key not in _FAMILY_INDEX:
        available = ", ".join(sorted(_FAMILY_INDEX)) or "<empty>"
        raise KeyError(f"Unknown canonical family '{family_id}'. Available: {available}")
    return _FAMILY_INDEX[key]


def get_family_variants(family_id: str) -> list[FamilyVariantRecord]:
    """Return implementation/provenance variants for one canonical family."""
    record = get_canonical_family_record(family_id)
    return list(_VARIANTS_BY_FAMILY.get(record.family_id, []))


def get_family_lineage(family_id: str) -> list[dict[str, object]]:
    """Return provenance-focused lineage rows for one canonical family."""
    return [
        {
            "original_model_id": variant.original_model_id,
            "source_benchmark": variant.source_benchmark,
            "source_family_name": variant.source_family_name,
            "implementation_variant_id": variant.implementation_variant_id,
            "implementation_variant_role": variant.implementation_variant_role,
            "fidelity_level": variant.fidelity_level,
            "provenance_retained": variant.provenance_retained,
            "notes": variant.notes,
        }
        for variant in get_family_variants(family_id)
    ]


def resolve_model_to_canonical_family(model_id: str) -> str:
    """Resolve any original model id into a canonical family id."""
    key = str(model_id).strip().lower()
    if key in _MODEL_TO_FAMILY:
        return _MODEL_TO_FAMILY[key]
    if key in _FAMILY_ALIAS_TO_ID:
        return _FAMILY_ALIAS_TO_ID[key]
    available = ", ".join(sorted(_MODEL_TO_FAMILY)) or "<empty>"
    raise KeyError(f"Unknown model or family '{model_id}'. Available original ids: {available}")


def get_family_internalization_state(family_id: str) -> str:
    """Return internalization state for one canonical family."""
    return get_canonical_family_record(family_id).internalization_state


def get_variant_for_original_model(model_id: str) -> FamilyVariantRecord:
    """Return the collapsed variant record for one original model id."""
    key = str(model_id).strip().lower()
    for variant in _VARIANTS:
        if variant.original_model_id.lower() == key:
            return variant
    available = ", ".join(sorted(variant.original_model_id for variant in _VARIANTS)) or "<empty>"
    raise KeyError(f"Unknown original model id '{model_id}'. Available: {available}")


def resolve_canonical_family_default_model(family_id: str) -> str | None:
    """Return the default runnable model identity for a canonical family when available."""
    record = get_canonical_family_record(family_id)
    return record.default_model_name


def canonical_family_status_rows() -> list[dict[str, object]]:
    """Return serializable family-state rows."""
    rows: list[dict[str, object]] = []
    for family_id in list_canonical_families():
        record = get_canonical_family_record(family_id)
        rows.append(
            {
                "family_id": record.family_id,
                "display_name": record.display_name,
                "family_category": record.family_category,
                "internalization_state": record.internalization_state,
                "default_variant_id": record.default_variant_id,
                "default_model_name": record.default_model_name,
                "top_level_family_id": record.top_level_family_id,
                "top_level_family_display_name": record.top_level_family_display_name,
                "family_level": record.family_level,
                "variant_count": len(get_family_variants(family_id)),
                "lineage_policy": record.lineage_policy,
                "benchmark_surface_compatibility": dict(record.benchmark_surface_compatibility),
                "comparability_defaults": dict(record.comparability_defaults),
                "summary": record.summary,
                "aliases": list(record.aliases),
            }
        )
    return rows


def collapse_map_rows() -> list[dict[str, object]]:
    """Return the full original->canonical collapse rows."""
    return [variant.to_dict() for variant in _VARIANTS]


__all__ = [
    "CanonicalFamilyRecord",
    "FamilyVariantRecord",
    "INTERNALIZATION_BENCHMARK_READY",
    "INTERNALIZATION_CONTRACT_DEFINED",
    "INTERNALIZATION_DECLARED",
    "INTERNALIZATION_NATIVE_IMPL",
    "INTERNALIZATION_PARTIALLY_INTERNALIZED",
    "INTERNALIZATION_PROXY_BACKED",
    "INTERNALIZATION_SOURCE_REFERENCE_ONLY",
    "canonical_family_status_rows",
    "collapse_map_rows",
    "get_canonical_family_record",
    "get_family_internalization_state",
    "get_variant_for_original_model",
    "get_family_lineage",
    "get_family_variants",
    "list_canonical_families",
    "list_primary_method_families",
    "list_top_level_families",
    "resolve_canonical_family_name",
    "resolve_canonical_family_default_model",
    "resolve_model_to_canonical_family",
]
