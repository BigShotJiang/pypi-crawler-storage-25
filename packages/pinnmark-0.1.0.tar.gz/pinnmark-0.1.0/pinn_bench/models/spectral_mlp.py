"""Preview operator-ready spectral MLP baseline."""

from __future__ import annotations

from typing import Any

import torch
from torch import nn

from pinn_bench.models.base import BaseOperatorModel
from pinn_bench.models.grid_mlp import _build_activation
from pinn_bench.registry import register_model


@register_model("spectral_mlp")
class SpectralMLP(BaseOperatorModel):
    """Lightweight spectral-feature operator baseline for flattened field prediction."""

    def __init__(
        self,
        query_dim: int = 2,
        condition_dim: int = 1,
        output_dim: int = 1,
        hidden_dims: list[int] | None = None,
        activation: str = "tanh",
        num_frequencies: int = 4,
        max_frequency: float = 4.0,
        include_identity: bool = True,
        **_: Any,
    ) -> None:
        super().__init__()
        self.query_dim = int(query_dim)
        self.condition_dim = int(condition_dim)
        self.output_dim = int(output_dim)
        self.model_mode = "pointwise" if self.condition_dim == 0 else "field"
        self.hidden_dims = [int(dim) for dim in (hidden_dims or [64, 64, 64])]
        self.num_frequencies = int(num_frequencies)
        self.max_frequency = float(max_frequency)
        self.include_identity = bool(include_identity)
        if self.num_frequencies <= 0:
            raise ValueError("num_frequencies must be positive.")
        if self.max_frequency <= 0.0:
            raise ValueError("max_frequency must be positive.")

        frequency_bands = torch.linspace(1.0, self.max_frequency, steps=self.num_frequencies)
        self.register_buffer("frequency_bands", frequency_bands, persistent=False)

        encoded_query_dim = self.query_dim * (2 * self.num_frequencies + (1 if self.include_identity else 0))
        self.encoded_query_dim = int(encoded_query_dim)
        layer_dims = [self.encoded_query_dim + self.condition_dim, *self.hidden_dims, self.output_dim]

        layers: list[nn.Module] = []
        for idx in range(len(layer_dims) - 1):
            layers.append(nn.Linear(layer_dims[idx], layer_dims[idx + 1]))
            if idx < len(layer_dims) - 2:
                layers.append(_build_activation(activation))
        self.network = nn.Sequential(*layers)

    def _encode_queries(self, query_inputs: torch.Tensor) -> torch.Tensor:
        if query_inputs.ndim != 2 or query_inputs.shape[1] != self.query_dim:
            raise ValueError(
                f"Expected query_inputs with shape (N, {self.query_dim}); got {tuple(query_inputs.shape)}."
            )
        query_inputs = query_inputs.to(dtype=torch.float32)
        parts: list[torch.Tensor] = []
        if self.include_identity:
            parts.append(query_inputs)
        angles = 2.0 * torch.pi * query_inputs.unsqueeze(-1) * self.frequency_bands
        parts.append(torch.sin(angles).reshape(query_inputs.shape[0], -1))
        parts.append(torch.cos(angles).reshape(query_inputs.shape[0], -1))
        return torch.cat(parts, dim=1)

    def _expand_condition(self, condition_inputs: torch.Tensor | None, query_inputs: torch.Tensor) -> torch.Tensor:
        if self.condition_dim <= 0:
            return torch.zeros((query_inputs.shape[0], 0), device=query_inputs.device, dtype=query_inputs.dtype)
        if condition_inputs is None:
            return torch.zeros((query_inputs.shape[0], self.condition_dim), device=query_inputs.device, dtype=query_inputs.dtype)
        if condition_inputs.ndim == 1:
            condition_inputs = condition_inputs.unsqueeze(0)
        condition_inputs = condition_inputs.to(device=query_inputs.device, dtype=query_inputs.dtype)
        if condition_inputs.shape[1] != self.condition_dim:
            raise ValueError(
                f"Condition feature dimension {condition_inputs.shape[1]} does not match expected {self.condition_dim}."
            )
        if condition_inputs.shape[0] == query_inputs.shape[0]:
            return condition_inputs
        if condition_inputs.shape[0] == 1:
            return condition_inputs.expand(query_inputs.shape[0], -1)
        raise ValueError(
            f"Condition batch shape {tuple(condition_inputs.shape)} is incompatible with query batch shape {tuple(query_inputs.shape)}."
        )

    def _forward_encoded(self, query_inputs: torch.Tensor, condition_inputs: torch.Tensor | None) -> torch.Tensor:
        encoded_queries = self._encode_queries(query_inputs)
        expanded_condition = self._expand_condition(condition_inputs, query_inputs)
        return self.network(torch.cat([encoded_queries, expanded_condition], dim=1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim != 2:
            raise ValueError(f"Expected a rank-2 input tensor; got shape {tuple(x.shape)}.")
        if x.shape[1] == self.query_dim + self.condition_dim:
            query_inputs = x[:, : self.query_dim]
            condition_inputs = None if self.condition_dim == 0 else x[:, self.query_dim :]
            return self._forward_encoded(query_inputs, condition_inputs)
        if self.condition_dim == 0 and x.shape[1] == self.query_dim:
            return self._forward_encoded(x, None)
        raise ValueError(
            f"SpectralMLP.forward expected concatenated query/condition inputs with width {self.query_dim + self.condition_dim}; got {x.shape[1]}."
        )

    def forward_field(
        self,
        condition_inputs: torch.Tensor | None,
        query_inputs: torch.Tensor | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> torch.Tensor:
        del metadata
        if query_inputs is None:
            raise ValueError("SpectralMLP requires query_inputs for forward_field(...).")
        return self._forward_encoded(query_inputs, condition_inputs)
