"""Concrete external adapter bindings for first-wave PINN families."""

from __future__ import annotations

from pinn_bench.models.external_adapters.base import (
    BlockedAdapter,
    NativeProxyAdapter,
    fbpinns_proxy_params,
    laaf_proxy_params,
    pointwise_mlp_proxy_params,
)


FIRST_WAVE_ADAPTERS = {
    "native_proxy_fnn_mlp": NativeProxyAdapter(
        adapter_name="native_proxy_fnn_mlp",
        native_model_name="mlp",
        transform_params=pointwise_mlp_proxy_params,
    ),
    "native_proxy_deepxde_fnn": NativeProxyAdapter(
        adapter_name="native_proxy_deepxde_fnn",
        native_model_name="mlp",
        transform_params=pointwise_mlp_proxy_params,
    ),
    "native_proxy_laaf_adaptive_mlp": NativeProxyAdapter(
        adapter_name="native_proxy_laaf_adaptive_mlp",
        native_model_name="adaptive_mlp",
        transform_params=laaf_proxy_params,
    ),
    "native_proxy_fbpinns_xpinn": NativeProxyAdapter(
        adapter_name="native_proxy_fbpinns_xpinn",
        native_model_name="xpinn_mlp",
        transform_params=fbpinns_proxy_params,
    ),
    "native_proxy_pinn_mlp": NativeProxyAdapter(
        adapter_name="native_proxy_pinn_mlp",
        native_model_name="mlp",
        transform_params=pointwise_mlp_proxy_params,
    ),
    "native_proxy_operator_family": BlockedAdapter(
        adapter_name="native_proxy_operator_family",
        reason=(
            "A source-family classification exists, but a benchmark-faithful operator-family proxy has not been promoted yet. "
            "Current native operator baselines remain available separately."
        ),
    ),
    "blocked_vpinn_variational": BlockedAdapter(
        adapter_name="blocked_vpinn_variational",
        reason=(
            "The current runtime exposes pointwise and operator field interfaces, but not the variational quadrature/residual hooks required by VPINN."
        ),
    ),
    "blocked_hard_constraint_wrapper": BlockedAdapter(
        adapter_name="blocked_hard_constraint_wrapper",
        reason=(
            "The source wrapper depends on task-coupled output transforms and initial-condition hooks that are not formalized in the current runtime contract."
        ),
    ),
}

