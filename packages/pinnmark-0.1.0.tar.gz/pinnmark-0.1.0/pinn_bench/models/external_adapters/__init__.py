"""Runnable adapter implementations for external model families."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import torch
from torch import nn

from pinn_bench.models.base import BaseModel, BaseOperatorModel
from pinn_bench.models.external_adapters.base import (
    BlockedAdapter,
    ExternalModelAdapter,
    NativeProxyAdapter,
    fbpinns_proxy_params,
    pointwise_mlp_proxy_params,
)
from pinn_bench.models.external_adapters.helpers import load_module_from_path
from pinn_bench.models.external_registry import ExternalModelRecord


class HardConstraintWrappedModel(BaseModel):
    """Task-coupled hard-constraint wrapper over a base pointwise model."""

    model_mode = "pointwise"

    def __init__(self, *, base_model: nn.Module, task: object, alpha: float = 5.0) -> None:
        super().__init__()
        self.base_model = base_model
        self.task = task
        self.alpha = float(alpha)

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        outputs = self.base_model(inputs)
        exact_solution = getattr(self.task, "exact_solution", None)
        domain = getattr(self.task, "domain", None)
        if exact_solution is None or not callable(exact_solution):
            return outputs
        if not isinstance(domain, dict) or "t_min" not in domain or inputs.ndim != 2 or inputs.shape[1] < 2:
            return outputs
        initial_inputs = inputs.clone()
        initial_time = float(domain.get("t_min", 0.0))
        initial_inputs[:, -1] = initial_time
        initial_targets = exact_solution(initial_inputs)
        if initial_targets is None:
            return outputs
        t = inputs[:, -1:].to(dtype=outputs.dtype)
        t0 = torch.full_like(t, initial_time)
        weight = torch.exp(-(t - t0).clamp_min(0.0) * self.alpha)
        return outputs * (1.0 - weight) + initial_targets.to(device=outputs.device, dtype=outputs.dtype) * weight


class PinnacleLAAFModel(BaseModel):
    """Thin runnable wrapper around PINNacle's checked-in LAAF implementation."""

    model_mode = "pointwise"

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dims: list[int] | None = None,
        **_: Any,
    ) -> None:
        super().__init__()
        dims = [int(dim) for dim in (hidden_dims or [64, 64, 64])]
        if not dims:
            dims = [64, 64, 64]
        if len(set(dims)) != 1:
            raise ValueError("PINNacle LAAF adapter currently requires uniform hidden_dims.")
        repo_root = Path(__file__).resolve().parents[3]
        module_path = (
            repo_root
            / "experiments"
            / "comparability_audit"
            / "external_repos"
            / "PINNacle"
            / "src"
            / "model"
            / "laaf.py"
        )
        module = load_module_from_path(module_name="_pinnmark_ext_pinnacle_laaf", path=module_path)
        self.external_model = module.DNN_LAAF(
            n_layers=len(dims),
            n_hidden=dims[0],
            x_dim=int(input_dim),
            u_dim=int(output_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.external_model(x)


class PinnacleLAAFAdapter(ExternalModelAdapter):
    adapter_name = "pinnacle_laaf_external"

    def build_model(self, *, record: ExternalModelRecord, **kwargs: Any) -> Any:
        del record
        payload = dict(kwargs)
        n_layers = int(payload.pop("n_layers", 3))
        n_hidden = int(payload.pop("n_hidden", 64))
        input_dim = int(payload.pop("input_dim", payload.pop("x_dim", 1)))
        output_dim = int(payload.pop("output_dim", payload.pop("u_dim", 1)))
        hidden_dims = payload.pop("hidden_dims", [n_hidden for _ in range(n_layers)])
        return PinnacleLAAFModel(
            input_dim=input_dim,
            output_dim=output_dim,
            hidden_dims=hidden_dims,
            **payload,
        )


class _DeepONetMLP(nn.Module):
    """Small MLP block used by the external DeepONet surrogate."""

    def __init__(self, layer_sizes: list[int], activation: str) -> None:
        super().__init__()
        self._activation_name = str(activation).strip().lower()
        self._activation = {
            "relu": torch.relu,
            "tanh": torch.tanh,
            "gelu": torch.nn.functional.gelu,
            "silu": torch.nn.functional.silu,
        }[self._activation_name]
        self.linears = nn.ModuleList()
        for in_dim, out_dim in zip(layer_sizes[:-1], layer_sizes[1:]):
            self.linears.append(nn.Linear(int(in_dim), int(out_dim)))
            nn.init.xavier_uniform_(self.linears[-1].weight)
            nn.init.zeros_(self.linears[-1].bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for layer in self.linears[:-1]:
            x = self._activation(layer(x))
        return self.linears[-1](x)


class ExternalDeepONetModel(BaseOperatorModel):
    """Thin operator-response surrogate inspired by the external DeepONet family."""

    model_mode = "field"
    supports_flattened_field = False

    def __init__(
        self,
        *,
        query_dim: int = 2,
        condition_dim: int = 11,
        output_dim: int = 1,
        branch_hidden_dims: list[int] | None = None,
        trunk_hidden_dims: list[int] | None = None,
        latent_dim: int = 64,
        activation: str = "tanh",
        **_: Any,
    ) -> None:
        super().__init__()
        self.query_dim = int(query_dim)
        self.condition_dim = int(condition_dim)
        self.output_dim = int(output_dim)
        self.latent_dim = int(latent_dim)
        branch_hidden_dims = [int(v) for v in (branch_hidden_dims or [64, 64, 64])]
        trunk_hidden_dims = [int(v) for v in (trunk_hidden_dims or [64, 64, 64])]
        self.branch = _DeepONetMLP([self.condition_dim, *branch_hidden_dims, self.latent_dim * self.output_dim], activation)
        self.trunk = _DeepONetMLP([self.query_dim, *trunk_hidden_dims, self.latent_dim * self.output_dim], activation)
        self.bias = nn.Parameter(torch.zeros(self.output_dim))

    def forward_field(
        self,
        condition_inputs: torch.Tensor | None,
        query_inputs: torch.Tensor | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> torch.Tensor:
        del metadata
        if condition_inputs is None or query_inputs is None:
            raise ValueError("ExternalDeepONetModel requires both condition_inputs and query_inputs.")
        if condition_inputs.ndim != 2 or condition_inputs.shape[1] != self.condition_dim:
            raise ValueError(
                f"ExternalDeepONetModel expected condition_inputs shape (*, {self.condition_dim}); got {tuple(condition_inputs.shape)}."
            )
        if query_inputs.ndim != 2 or query_inputs.shape[1] != self.query_dim:
            raise ValueError(
                f"ExternalDeepONetModel expected query_inputs shape (*, {self.query_dim}); got {tuple(query_inputs.shape)}."
            )
        branch = self.branch(condition_inputs).reshape(condition_inputs.shape[0], self.output_dim, self.latent_dim)
        trunk = torch.tanh(self.trunk(query_inputs)).reshape(query_inputs.shape[0], self.output_dim, self.latent_dim)
        return torch.einsum("bcl,bcl->bc", branch, trunk) + self.bias


class ExternalDeepONetAdapter(ExternalModelAdapter):
    """Adapter for the external PDENNEval DeepONet family."""

    adapter_name = "operator_deeponet_family"

    def build_model(self, *, record: ExternalModelRecord, **kwargs: Any) -> Any:
        del record
        payload = dict(kwargs)
        query_dim = int(payload.pop("query_dim", 2))
        condition_dim = int(payload.pop("condition_dim", 11))
        output_dim = int(payload.pop("output_dim", 1))
        hidden_dims = payload.pop("hidden_dims", None)
        branch_hidden_dims = payload.pop("branch_hidden_dims", hidden_dims)
        trunk_hidden_dims = payload.pop("trunk_hidden_dims", hidden_dims)
        return ExternalDeepONetModel(
            query_dim=query_dim,
            condition_dim=condition_dim,
            output_dim=output_dim,
            branch_hidden_dims=branch_hidden_dims,
            trunk_hidden_dims=trunk_hidden_dims,
            activation=str(payload.pop("activation", "tanh")),
            **payload,
        )


class PinnacleHardConstraintAdapter(ExternalModelAdapter):
    """Adapter that marks a base pointwise model for task-coupled hard-constraint wrapping."""

    adapter_name = "pinnacle_hard_constraint_family"

    def build_model(self, *, record: ExternalModelRecord, **kwargs: Any) -> Any:
        del record
        from pinn_bench.registry import create_native_model

        payload = pointwise_mlp_proxy_params(kwargs)
        alpha = float(payload.pop("hard_constraint_alpha", payload.pop("alpha", 5.0)))
        base_model = create_native_model("mlp", **payload)
        setattr(base_model, "__pinn_bench_external_constraint__", {"kind": "hard_constraint", "alpha": alpha})
        return base_model


_ADAPTERS: dict[str, ExternalModelAdapter] = {
    "pinnacle_deepxde_proxy": BlockedAdapter(
        adapter_name="pinnacle_deepxde_proxy",
        reason=(
            "DeepXDE is integrated as a framework family and provenance surface, not as one directly runnable model identity."
        ),
    ),
    "pinnacle_fbpinns_proxy": NativeProxyAdapter(
        adapter_name="pinnacle_fbpinns_proxy",
        native_model_name="xpinn_mlp",
        transform_params=fbpinns_proxy_params,
        default_params={"hidden_dims": [48, 48, 48], "activation": "tanh", "num_subdomains": 4, "overlap": 0.15},
    ),
    "pinnacle_fnn_proxy": NativeProxyAdapter(
        adapter_name="pinnacle_fnn_proxy",
        native_model_name="mlp",
        transform_params=pointwise_mlp_proxy_params,
        default_params={"hidden_dims": [40, 40, 40, 40, 40, 40], "activation": "tanh"},
    ),
    "pinnacle_laaf_external": PinnacleLAAFAdapter(),
    "pdenneval_pinn_proxy": NativeProxyAdapter(
        adapter_name="pdenneval_pinn_proxy",
        native_model_name="mlp",
        transform_params=pointwise_mlp_proxy_params,
        default_params={"hidden_dims": [40, 40, 40, 40, 40, 40], "activation": "tanh"},
    ),
    "pdebench_pinn_proxy": NativeProxyAdapter(
        adapter_name="pdebench_pinn_proxy",
        native_model_name="mlp",
        transform_params=pointwise_mlp_proxy_params,
        default_params={"hidden_dims": [40, 40, 40, 40, 40, 40], "activation": "tanh"},
    ),
    "operator_fno_family": BlockedAdapter(
        adapter_name="operator_fno_family",
        reason=(
            "placeholder"
        ),
    ),
    "operator_pino_family": BlockedAdapter(
        adapter_name="operator_pino_family",
        reason=(
            "PINO remains adapter-classified only; the current runtime does not yet express the operator+physics training semantics needed for an honest family adapter."
        ),
    ),
    "operator_deeponet_family": BlockedAdapter(
        adapter_name="operator_deeponet_family",
        reason=(
            "placeholder"
        ),
    ),
    "pinnacle_vpinn_family": BlockedAdapter(
        adapter_name="pinnacle_vpinn_family",
        reason=(
            "VPINN requires weak-form / quadrature-aware task hooks that are not part of the current runtime contract."
        ),
    ),
    "pinnacle_hard_constraint_family": BlockedAdapter(
        adapter_name="pinnacle_hard_constraint_family",
        reason=(
            "placeholder"
        ),
    ),
}

_ADAPTERS["operator_fno_family"] = NativeProxyAdapter(
    adapter_name="operator_fno_family",
    native_model_name="mini_fno",
    default_params={
        "query_dim": 2,
        "condition_dim": 11,
        "output_dim": 1,
        "hidden_width": 32,
        "num_layers": 2,
        "spectral_modes_x": 8,
        "spectral_modes_y": 8,
        "activation": "gelu",
    },
)
_ADAPTERS["operator_deeponet_family"] = ExternalDeepONetAdapter()
_ADAPTERS["pinnacle_hard_constraint_family"] = PinnacleHardConstraintAdapter()


def get_external_adapter(name: str) -> ExternalModelAdapter:
    key = str(name).strip()
    if key not in _ADAPTERS:
        available = ", ".join(sorted(_ADAPTERS)) or "<empty>"
        raise KeyError(f"Unknown external adapter '{name}'. Available: {available}")
    return _ADAPTERS[key]


def list_external_adapters() -> list[str]:
    return sorted(_ADAPTERS.keys())


__all__ = ["get_external_adapter", "list_external_adapters"]
