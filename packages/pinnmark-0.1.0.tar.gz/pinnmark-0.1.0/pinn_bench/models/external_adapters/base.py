"""Base adapter abstractions for external model families."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Mapping
import inspect
from typing import Any

from pinn_bench.models.external_registry import ExternalModelRecord


_SIGNATURE_KIND_NAMES = {
    inspect.Parameter.POSITIONAL_ONLY: "positional_only",
    inspect.Parameter.POSITIONAL_OR_KEYWORD: "positional_or_keyword",
    inspect.Parameter.VAR_POSITIONAL: "var_positional",
    inspect.Parameter.KEYWORD_ONLY: "keyword_only",
    inspect.Parameter.VAR_KEYWORD: "var_keyword",
}


class ExternalModelAdapter(ABC):
    """Abstract adapter for external model families."""

    adapter_name: str

    @abstractmethod
    def build_model(self, *, record: ExternalModelRecord, **kwargs: Any) -> Any:
        """Return a runnable model instance."""

    def signature_payload(self) -> list[dict[str, object]]:
        target = self.build_model
        parameters = [
            parameter
            for parameter in inspect.signature(target).parameters.values()
            if parameter.name not in {"self", "record"}
        ]
        payload: list[dict[str, object]] = []
        for parameter in parameters:
            default_repr = None if parameter.default is inspect.Signature.empty else repr(parameter.default)
            payload.append(
                {
                    "name": parameter.name,
                    "kind": _SIGNATURE_KIND_NAMES[parameter.kind],
                    "required": parameter.default is inspect.Signature.empty,
                    "default_repr": default_repr,
                }
            )
        payload.append(
            {
                "name": "kwargs",
                "kind": "var_keyword",
                "required": False,
                "default_repr": None,
            }
        )
        return payload


class BlockedAdapter(ExternalModelAdapter):
    """Adapter placeholder that explains why a family is not runnable yet."""

    def __init__(self, *, adapter_name: str, reason: str) -> None:
        self.adapter_name = adapter_name
        self.reason = str(reason)

    def build_model(self, *, record: ExternalModelRecord, **kwargs: Any) -> Any:
        del kwargs
        raise ValueError(
            f"External model '{record.canonical_name}' is adapter-backed but not runnable. "
            f"state={record.integration_state}, runnable_status={record.runnable_status}. {self.reason}"
        )


def _pop_first(payload: dict[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in payload:
            return payload.pop(key)
    return default


def pointwise_mlp_proxy_params(
    params: Mapping[str, Any],
    *,
    default_activation: str = "tanh",
) -> dict[str, Any]:
    """Translate external FNN/PINN-style kwargs into native MLP kwargs."""
    payload = dict(params)
    layer_sizes = _pop_first(payload, "layer_sizes", "layers", default=None)
    input_dim = _pop_first(payload, "input_dim", "x_dim", default=None)
    output_dim = _pop_first(payload, "output_dim", "u_dim", default=None)
    hidden_dims = _pop_first(payload, "hidden_dims", default=None)
    if layer_sizes is not None:
        if not isinstance(layer_sizes, (list, tuple)) or len(layer_sizes) < 2:
            raise ValueError("'layer_sizes' must be a list/tuple with input and output widths.")
        layer_sizes = [int(value) for value in layer_sizes]
        input_dim = layer_sizes[0]
        output_dim = layer_sizes[-1]
        hidden_dims = layer_sizes[1:-1]
    if input_dim is None or output_dim is None:
        raise ValueError("External pointwise proxy requires input/output dimensions.")
    activation = str(_pop_first(payload, "activation", default=default_activation) or default_activation)
    _pop_first(payload, "kernel_initializer", default=None)
    _pop_first(payload, "initializer", default=None)
    translated = {
        "input_dim": int(input_dim),
        "output_dim": int(output_dim),
        "hidden_dims": [int(value) for value in (hidden_dims or [64, 64, 64])],
        "activation": activation,
    }
    translated.update(payload)
    return translated


def laaf_proxy_params(params: Mapping[str, Any]) -> dict[str, Any]:
    """Translate PINNacle LAAF-style kwargs into native adaptive MLP kwargs."""
    payload = dict(params)
    n_layers = int(_pop_first(payload, "n_layers", default=3))
    n_hidden = int(_pop_first(payload, "n_hidden", default=64))
    x_dim = int(_pop_first(payload, "x_dim", "input_dim", default=1))
    u_dim = int(_pop_first(payload, "u_dim", "output_dim", default=1))
    translated = {
        "input_dim": x_dim,
        "output_dim": u_dim,
        "hidden_dims": [n_hidden for _ in range(n_layers)],
        "activation": "tanh",
    }
    translated.update(payload)
    return translated


def fbpinns_proxy_params(params: Mapping[str, Any]) -> dict[str, Any]:
    """Translate PINNacle FBPINNs-style kwargs into native XPINN kwargs."""
    payload = dict(params)
    layer_sizes = _pop_first(payload, "layer_sizes", "layers", default=None)
    input_dim = _pop_first(payload, "input_dim", "x_dim", default=None)
    output_dim = _pop_first(payload, "output_dim", "u_dim", default=None)
    hidden_dims = _pop_first(payload, "hidden_dims", default=None)
    if layer_sizes is not None:
        if not isinstance(layer_sizes, (list, tuple)) or len(layer_sizes) < 2:
            raise ValueError("'layer_sizes' must be a list/tuple with input and output widths.")
        layer_sizes = [int(value) for value in layer_sizes]
        input_dim = layer_sizes[0]
        output_dim = layer_sizes[-1]
        hidden_dims = layer_sizes[1:-1]
    if input_dim is None or output_dim is None:
        raise ValueError("FBPINNs proxy requires input/output dimensions.")
    translated = {
        "input_dim": int(input_dim),
        "output_dim": int(output_dim),
        "hidden_dims": [int(value) for value in (hidden_dims or [48, 48, 48])],
        "activation": str(_pop_first(payload, "activation", default="tanh") or "tanh"),
        "num_subdomains": int(_pop_first(payload, "num_subdomains", "subdomains", default=2)),
        "overlap": float(_pop_first(payload, "overlap", default=0.1)),
        "decompose_axis": int(_pop_first(payload, "decompose_axis", default=0)),
        "domain_min": float(_pop_first(payload, "domain_min", default=0.0)),
        "domain_max": float(_pop_first(payload, "domain_max", default=1.0)),
    }
    translated.update(payload)
    return translated


class NativeProxyAdapter(ExternalModelAdapter):
    """Adapter that reuses an existing native PINNMark model as a family proxy."""

    def __init__(
        self,
        *,
        adapter_name: str,
        native_model_name: str,
        transform_params: Any | None = None,
        default_params: dict[str, Any] | None = None,
    ) -> None:
        self.adapter_name = adapter_name
        self.native_model_name = str(native_model_name)
        self.transform_params = transform_params
        self.default_params = dict(default_params or {})

    def build_model(self, *, record: ExternalModelRecord, **kwargs: Any) -> Any:
        from pinn_bench.registry import create_native_model

        params = {**self.default_params, **kwargs}
        if self.transform_params is not None:
            params = self.transform_params(params)
        return create_native_model(self.native_model_name, **params)
