"""Helpers shared by external model adapters."""

from __future__ import annotations

import importlib.util
from pathlib import Path
from typing import Any


def load_module_from_path(*, module_name: str, path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load module spec for {path}.")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

