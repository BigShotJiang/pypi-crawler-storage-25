"""Residual-adaptive sampling solver profile backed by the standard MLP architecture."""

from __future__ import annotations

from typing import Any

from pinn_bench.models.mlp import MLP
from pinn_bench.registry import register_model


@register_model("adaptive_mlp")
class AdaptiveMLP(MLP):
    """MLP profile used with residual-adaptive interior resampling."""

    solver_profile = "adaptive_mlp"
    sampling_strategy = "residual_adaptive"

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
