"""Primary benchmark-method registry for the twenty-method intake wave.

This layer sits above runtime identities and external lineage handles:

- top-level family = stable canonical umbrella
- primary method = benchmark-visible main method object
- runtime selector = concrete current runnable/default implementation, if any
"""

from __future__ import annotations

from dataclasses import dataclass, field
import re

from pinn_bench.models.native_family_registry import (
    INTERNALIZATION_CONTRACT_DEFINED,
    INTERNALIZATION_PARTIALLY_INTERNALIZED,
    INTERNALIZATION_PROXY_BACKED,
)

PRIMARY_METHOD_INTEGRATION = "primary_method"
RUNNABLE_STATUS_RUNNABLE = "runnable"
RUNNABLE_STATUS_BLOCKED = "blocked"

COMPARABILITY_BLOCKED = "blocked"
COMPARABILITY_BOUNDED = "bounded_support_only"
COMPARABILITY_APPENDIX = "appendix_only_comparable"
COMPARABILITY_FUTURE = "future_branch_only"
COMPARABILITY_RUNNABLE_NOT_COMPARABLE = "runnable_but_not_comparable"

EVIDENCE_NONE = "no_checked_in_evidence"
EVIDENCE_EXECUTED = "executed_evidence_available"
EVIDENCE_TEMPORAL = "temporal_nominal_bridge"
EVIDENCE_OPERATOR = "operator_nominal_bridge"
EVIDENCE_RUNTIME_SMOKE = "runtime_smoke_available"

_NORMALIZE_PATTERN = re.compile(r"[^a-z0-9]+")


@dataclass(frozen=True)
class PrimaryMethodRecord:
    method_name: str
    method_id: str
    display_name: str
    top_level_family: str
    benchmark_primary_subfamily: bool
    canonical_status: str
    method_type: str
    formulation_type: str
    source_lineage: tuple[str, ...]
    config_contract_defined: bool
    runtime_contract_defined: bool
    loss_or_formulation_contract_defined: bool
    task_shell_compatibility: str
    benchmark_surface_compatibility: str
    runtime_contract_status: str
    runnable_status: str
    comparability_status: str
    evidence_status: str
    internalization_level: str
    source_faithfulness_level: str
    default_runtime_name: str | None = None
    aliases: tuple[str, ...] = field(default_factory=tuple)
    notes: str = ""

    def to_dict(self) -> dict[str, object]:
        return {
            "method_name": self.method_name,
            "method_id": self.method_id,
            "display_name": self.display_name,
            "top_level_family": self.top_level_family,
            "benchmark_primary_subfamily": self.benchmark_primary_subfamily,
            "canonical_status": self.canonical_status,
            "method_type": self.method_type,
            "formulation_type": self.formulation_type,
            "source_lineage": list(self.source_lineage),
            "config_contract_defined": self.config_contract_defined,
            "runtime_contract_defined": self.runtime_contract_defined,
            "loss_or_formulation_contract_defined": self.loss_or_formulation_contract_defined,
            "task_shell_compatibility": self.task_shell_compatibility,
            "benchmark_surface_compatibility": self.benchmark_surface_compatibility,
            "runtime_contract_status": self.runtime_contract_status,
            "runnable_status": self.runnable_status,
            "comparability_status": self.comparability_status,
            "evidence_status": self.evidence_status,
            "internalization_level": self.internalization_level,
            "source_faithfulness_level": self.source_faithfulness_level,
            "default_runtime_name": self.default_runtime_name,
            "aliases": list(self.aliases),
            "notes": self.notes,
        }

    def to_intake_row(self) -> dict[str, object]:
        return {
            "method_name": self.method_name,
            "proposed_primary_id": self.method_id,
            "top_level_family": self.top_level_family,
            "benchmark_primary_subfamily": self.benchmark_primary_subfamily,
            "canonical_status": self.canonical_status,
            "source_lineage": " | ".join(self.source_lineage),
            "method_type": self.method_type,
            "formulation_type": self.formulation_type,
            "runtime_contract_status": self.runtime_contract_status,
            "runnable_status": self.runnable_status,
            "comparability_status": self.comparability_status,
            "evidence_status": self.evidence_status,
            "internalization_level": self.internalization_level,
            "notes": self.notes,
        }

    def to_contract_row(self) -> dict[str, object]:
        blocker = ""
        if self.runnable_status != RUNNABLE_STATUS_RUNNABLE:
            blocker = self.runtime_contract_status
        elif self.comparability_status in {COMPARABILITY_BLOCKED, COMPARABILITY_FUTURE}:
            blocker = self.comparability_status
        return {
            "method_id": self.method_id,
            "config_contract_defined": self.config_contract_defined,
            "runtime_contract_defined": self.runtime_contract_defined,
            "loss_or_formulation_contract_defined": self.loss_or_formulation_contract_defined,
            "task_shell_compatibility": self.task_shell_compatibility,
            "benchmark_surface_compatibility": self.benchmark_surface_compatibility,
            "lineage_retained": True,
            "source_faithfulness_level": self.source_faithfulness_level,
            "remaining_blocker": blocker,
            "notes": self.notes,
        }

    def to_catalog_entry(self) -> dict[str, object]:
        try:
            from pinn_bench.models.native_family_registry import get_canonical_family_record

            top_level_display = get_canonical_family_record(self.top_level_family).display_name
        except Exception:
            top_level_display = self.top_level_family
        return {
            "name": self.method_id,
            "kind": "primary_method",
            "canonical_name": self.method_id,
            "display_name": self.display_name,
            "primary_method_id": self.method_id,
            "primary_method_name": self.method_name,
            "top_level_family": self.top_level_family,
            "top_level_family_display_name": top_level_display,
            "benchmark_primary_subfamily": self.benchmark_primary_subfamily,
            "canonical_status": self.canonical_status,
            "method_type": self.method_type,
            "model_category": "primary_method",
            "model_subcategory": self.top_level_family.split(".")[-1],
            "formulation_type": self.formulation_type,
            "source_lineage": list(self.source_lineage),
            "integration_state": PRIMARY_METHOD_INTEGRATION,
            "internalization_state": self.internalization_level,
            "runtime_contract_status": self.runtime_contract_status,
            "runnable_status": self.runnable_status,
            "comparability_status": self.comparability_status,
            "evidence_status": self.evidence_status,
            "default_runtime_name": self.default_runtime_name,
            "native_equivalent": self.default_runtime_name,
            "is_pinn_family": self.method_type in {"pointwise_pinn", "hybrid_pinn"},
            "is_operator_family": self.method_type == "operator_family",
            "is_solver_adjacent": "variational" in self.formulation_type or "bayesian" in self.formulation_type,
            "comparability_scope": self.benchmark_surface_compatibility,
            "capability_tags": [
                f"top_level:{self.top_level_family}",
                f"formulation:{self.formulation_type}",
                f"internalization:{self.internalization_level}",
            ],
            "notes": self.notes,
            "aliases": list(self.aliases),
        }


def _normalize_token(value: str) -> str:
    return _NORMALIZE_PATTERN.sub("", str(value).strip().lower())


_RECORDS: tuple[PrimaryMethodRecord, ...] = (
    PrimaryMethodRecord(
        method_name="cPINN",
        method_id="pinnmark.pinn.cpinn",
        display_name="PINNMark cPINN",
        top_level_family="pinnmark.pinn.domain_decomposition",
        benchmark_primary_subfamily=True,
        canonical_status="benchmark_primary_subfamily",
        method_type="pointwise_pinn",
        formulation_type="strong_form_interface_conservative",
        source_lineage=("cPINN literature lineage", "conservative interface PINN family"),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="requires domain partition + conservative interface coupling hooks",
        benchmark_surface_compatibility="pointwise_decomposition_family_not_yet_benchmark_normalized",
        runtime_contract_status="bounded_xpinn_proxy_without_conservative_interface_terms",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_BOUNDED,
        evidence_status=EVIDENCE_RUNTIME_SMOKE,
        internalization_level=INTERNALIZATION_PROXY_BACKED,
        source_faithfulness_level="bounded_proxy_family",
        default_runtime_name="xpinn_mlp",
        aliases=("cPINN", "cpinn", "c-pinn"),
        notes="Runnable through a bounded XPINN-style decomposition proxy, but current runtime still lacks explicit conservative interface conditions and subdomain coupling semantics.",
    ),
    PrimaryMethodRecord(
        method_name="FBPINN",
        method_id="pinnmark.hybrid.fbpinn",
        display_name="PINNMark FBPINN",
        top_level_family="pinnmark.pinn.domain_decomposition",
        benchmark_primary_subfamily=False,
        canonical_status="existing_primary_family",
        method_type="hybrid_pinn",
        formulation_type="finite_basis_domain_decomposition",
        source_lineage=("PINNacle::fbpinns", "finite-basis decomposition lineage"),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="proxy-compatible on current pointwise shells",
        benchmark_surface_compatibility="bounded_appendix_or_decomposition_support",
        runtime_contract_status="proxy_backed_via_xpinn_style_runtime",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_BOUNDED,
        evidence_status=EVIDENCE_RUNTIME_SMOKE,
        internalization_level=INTERNALIZATION_PROXY_BACKED,
        source_faithfulness_level="proxy_family",
        default_runtime_name="ext_pinnacle_fbpinns",
        aliases=("FBPINN", "fbpinn", "FBPINNs", "fbpinns"),
        notes="Existing canonical family retained as a primary method object; current runtime remains proxy-backed and bounded rather than source-faithful.",
    ),
    PrimaryMethodRecord(
        method_name="VPINN",
        method_id="pinnmark.pinn.vpinn",
        display_name="PINNMark VPINN",
        top_level_family="pinnmark.pinn.variational",
        benchmark_primary_subfamily=False,
        canonical_status="existing_primary_family",
        method_type="pointwise_pinn",
        formulation_type="weak_form_variational",
        source_lineage=("PINNacle::vpinn", "variational PINN lineage"),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="needs quadrature/test-function aware task shell",
        benchmark_surface_compatibility="task_scoped_variational_runtime",
        runtime_contract_status="bounded_variational_runtime",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_RUNNABLE_NOT_COMPARABLE,
        evidence_status=EVIDENCE_RUNTIME_SMOKE,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="task_scoped_runtime",
        default_runtime_name="vpinn_variational_mlp",
        aliases=("VPINN", "vpinn", "variational pinn"),
        notes="Existing canonical family remains primary and now has a bounded task-scoped variational surrogate, but still lacks true quadrature-aware weak-form runtime and loss assembly support.",
    ),
    PrimaryMethodRecord(
        method_name="hp-VPINN",
        method_id="pinnmark.pinn.hp_vpinn",
        display_name="PINNMark hp-VPINN",
        top_level_family="pinnmark.pinn.vpinn",
        benchmark_primary_subfamily=True,
        canonical_status="benchmark_primary_subfamily",
        method_type="pointwise_pinn",
        formulation_type="weak_form_variational_hp_refinement",
        source_lineage=("hp-VPINN literature lineage", "domain-decomposed variational refinement lineage"),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="needs weak-form + hp/decomposition controls",
        benchmark_surface_compatibility="task_scoped_hp_variational_runtime",
        runtime_contract_status="bounded_hp_variational_runtime",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_RUNNABLE_NOT_COMPARABLE,
        evidence_status=EVIDENCE_RUNTIME_SMOKE,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="task_scoped_runtime",
        default_runtime_name="hp_vpinn_variational_mlp",
        aliases=("hp-VPINN", "hpVPINN", "hp_vpinn"),
        notes="Primary subfamily under VPINN retained separately and now has a bounded task-scoped surrogate, but still lacks true hp refinement, quadrature, and decomposition-aware weak-form machinery.",
    ),
    PrimaryMethodRecord(
        method_name="hPINN",
        method_id="pinnmark.pinn.hpinn",
        display_name="PINNMark hPINN",
        top_level_family="pinnmark.pinn.hard_constraint",
        benchmark_primary_subfamily=True,
        canonical_status="benchmark_primary_subfamily",
        method_type="pointwise_pinn",
        formulation_type="hard_constraint_ansatz",
        source_lineage=("PINNacle::hard_constraint", "hard-constraint / inverse-design lineage"),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="task-coupled output-transform shells only",
        benchmark_surface_compatibility="temporal_appendix_candidate",
        runtime_contract_status="task_coupled_hard_constraint_proxy",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_APPENDIX,
        evidence_status=EVIDENCE_TEMPORAL,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="task_coupled_proxy",
        default_runtime_name="ext_pinnacle_hard_constraint",
        aliases=("hPINN", "hpinn", "h-pinn"),
        notes="Mapped onto the existing hard-constraint runtime hook with explicit disclosure that current evidence is bounded and task-coupled rather than full hPINN closure.",
    ),
    PrimaryMethodRecord(
        method_name="B-PINN",
        method_id="pinnmark.pinn.b_pinn",
        display_name="PINNMark B-PINN",
        top_level_family="pinnmark.pinn.bayesian",
        benchmark_primary_subfamily=True,
        canonical_status="benchmark_primary_subfamily",
        method_type="pointwise_pinn",
        formulation_type="bayesian_posterior_inference",
        source_lineage=("B-PINN literature lineage", "Bayesian physics-informed posterior family"),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="needs probabilistic inference runtime and uncertainty-aware evaluation",
        benchmark_surface_compatibility="bayesian_family_not_yet_supported",
        runtime_contract_status="bounded_variational_bayes_runtime",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_BOUNDED,
        evidence_status=EVIDENCE_RUNTIME_SMOKE,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="bounded_variational_bayes_proxy",
        default_runtime_name="bayesian_mlp",
        aliases=("B-PINN", "bpinn", "b_pinn"),
        notes="Admitted as a top-level Bayesian primary method and now constructible through a lightweight variational Bayesian MLP, but benchmark-surface comparability and source-faithful posterior semantics remain incomplete.",
    ),
    PrimaryMethodRecord(
        method_name="SA-PINN",
        method_id="pinnmark.pinn.sa_pinn",
        display_name="PINNMark SA-PINN",
        top_level_family="pinnmark.pinn.adaptive",
        benchmark_primary_subfamily=True,
        canonical_status="benchmark_primary_subfamily",
        method_type="pointwise_pinn",
        formulation_type="self_adaptive_loss_weighting",
        source_lineage=("SA-PINN literature lineage", "soft-attention residual weighting lineage"),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="needs adaptive loss-state updates in trainer/runtime",
        benchmark_surface_compatibility="bounded_adaptive_weighting_runtime",
        runtime_contract_status="bounded_self_adaptive_weighting_runtime",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_RUNNABLE_NOT_COMPARABLE,
        evidence_status=EVIDENCE_RUNTIME_SMOKE,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="bounded_native_runtime",
        default_runtime_name="sa_pinn_mlp",
        aliases=("SA-PINN", "sapinn", "sa_pinn"),
        notes="Placed under the broader adaptive umbrella and now runnable through bounded self-adaptive loss weighting, while still remaining distinct from activation- or sampling-adaptive paths.",
    ),
    PrimaryMethodRecord(
        method_name="PirateNets",
        method_id="pinnmark.pinn.piratenets",
        display_name="PINNMark PirateNets",
        top_level_family="pinnmark.pinn.residual_adaptive",
        benchmark_primary_subfamily=True,
        canonical_status="benchmark_primary_subfamily",
        method_type="pointwise_pinn",
        formulation_type="residual_adaptive_architecture",
        source_lineage=("PirateNets literature lineage",),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="needs architecture-specific residual blocks and initialization contract",
        benchmark_surface_compatibility="bounded_architecture_runtime",
        runtime_contract_status="bounded_residual_adaptive_runtime",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_RUNNABLE_NOT_COMPARABLE,
        evidence_status=EVIDENCE_RUNTIME_SMOKE,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="bounded_native_runtime",
        default_runtime_name="piratenets_mlp",
        aliases=("PirateNets", "piratenets", "pirate nets"),
        notes="Admitted as a primary subfamily and now runnable through a bounded residual-adaptive architecture, while remaining a non-source-faithful minimal implementation.",
    ),
    PrimaryMethodRecord(
        method_name="PINNsFormer",
        method_id="pinnmark.pinn.pinnsformer",
        display_name="PINNMark PINNsFormer",
        top_level_family="pinnmark.pinn.transformer",
        benchmark_primary_subfamily=True,
        canonical_status="benchmark_primary_subfamily",
        method_type="pointwise_pinn",
        formulation_type="transformer_sequence_modeling",
        source_lineage=("PINNsFormer literature lineage",),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="time-dependent shells require sequence-aware inputs and rollout semantics",
        benchmark_surface_compatibility="bounded_transformer_runtime",
        runtime_contract_status="bounded_transformer_runtime",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_RUNNABLE_NOT_COMPARABLE,
        evidence_status=EVIDENCE_RUNTIME_SMOKE,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="bounded_native_runtime",
        default_runtime_name="pinnsformer_model",
        aliases=("PINNsFormer", "pinnsformer"),
        notes="Primary transformer PINN method is now runnable through a bounded transformer encoder architecture, but full sequence-task and source-faithful semantics remain absent.",
    ),
    PrimaryMethodRecord(
        method_name="PIANN",
        method_id="pinnmark.pinn.piann",
        display_name="PINNMark PIANN",
        top_level_family="pinnmark.pinn.attention_sequence",
        benchmark_primary_subfamily=True,
        canonical_status="benchmark_primary_subfamily",
        method_type="pointwise_pinn",
        formulation_type="attention_recurrent_sequence",
        source_lineage=("PIANN literature lineage",),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="needs attention/recurrent sequence contract on time-dependent PDE shells",
        benchmark_surface_compatibility="bounded_attention_sequence_runtime",
        runtime_contract_status="bounded_attention_sequence_runtime",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_RUNNABLE_NOT_COMPARABLE,
        evidence_status=EVIDENCE_RUNTIME_SMOKE,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="bounded_native_runtime",
        default_runtime_name="piann_model",
        aliases=("PIANN", "piann"),
        notes="Admitted separately from transformer methods and now runnable through a bounded attention/recurrent architecture, while full literature-faithful PIANN semantics remain absent.",
    ),
    PrimaryMethodRecord(
        method_name="SPINN",
        method_id="pinnmark.pinn.spinn",
        display_name="PINNMark SPINN",
        top_level_family="pinnmark.pinn.separable",
        benchmark_primary_subfamily=True,
        canonical_status="benchmark_primary_subfamily",
        method_type="pointwise_pinn",
        formulation_type="separable_factorized",
        source_lineage=("SPINN literature lineage",),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="needs separable/factorized architecture contract and compatible AD path",
        benchmark_surface_compatibility="bounded_separable_runtime",
        runtime_contract_status="bounded_separable_runtime",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_RUNNABLE_NOT_COMPARABLE,
        evidence_status=EVIDENCE_RUNTIME_SMOKE,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="bounded_native_runtime",
        default_runtime_name="spinn_model",
        aliases=("SPINN", "spinn"),
        notes="Admitted as a distinct separable architecture family and now runnable through a bounded factorized architecture rather than collapsed into compact MLP baselines.",
    ),
    PrimaryMethodRecord(
        method_name="Causal-Sweeping PINNs",
        method_id="pinnmark.pinn.causal_sweeping",
        display_name="PINNMark Causal-Sweeping PINNs",
        top_level_family="pinnmark.pinn.causal_time_marching",
        benchmark_primary_subfamily=True,
        canonical_status="benchmark_primary_subfamily",
        method_type="pointwise_pinn",
        formulation_type="causal_time_marching",
        source_lineage=("Causal-Sweeping PINN literature lineage",),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="needs causal curriculum / stage scheduling in trainer and task metadata",
        benchmark_surface_compatibility="task_scoped_causal_runtime",
        runtime_contract_status="bounded_causal_scheduling_runtime",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_RUNNABLE_NOT_COMPARABLE,
        evidence_status=EVIDENCE_RUNTIME_SMOKE,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="task_scoped_runtime",
        default_runtime_name="causal_sweeping_mlp",
        aliases=("Causal-Sweeping PINNs", "causal-sweeping pinns", "causal_sweeping_pinns"),
        notes="Admitted into the main method universe and now runnable through a task-scoped causal scheduling surrogate, while still lacking full time-sweeping stage machinery.",
    ),
    PrimaryMethodRecord(
        method_name="FNO",
        method_id="pinnmark.operator.fno",
        display_name="PINNMark FNO",
        top_level_family="pinnmark.operator.fno",
        benchmark_primary_subfamily=False,
        canonical_status="existing_primary_family",
        method_type="operator_family",
        formulation_type="spectral_operator_learning",
        source_lineage=("PDEBench::fno", "PDENNEval::FNO"),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="operator rollout shells with fieldwise inputs/outputs",
        benchmark_surface_compatibility="operator_appendix_branch",
        runtime_contract_status="mini_fno_proxy_or_operator_adapter",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_APPENDIX,
        evidence_status=EVIDENCE_OPERATOR,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="operator_proxy_family",
        default_runtime_name="mini_fno",
        aliases=("FNO", "fno", "Fourier Neural Operator"),
        notes="Existing canonical operator family retained as a primary method object; appendix/operator evidence exists, but current story remains bounded.",
    ),
    PrimaryMethodRecord(
        method_name="DeepONet",
        method_id="pinnmark.operator.deeponet",
        display_name="PINNMark DeepONet",
        top_level_family="pinnmark.operator.deeponet",
        benchmark_primary_subfamily=False,
        canonical_status="existing_primary_family",
        method_type="operator_family",
        formulation_type="branch_trunk_operator_learning",
        source_lineage=("PDENNEval::DeepONet",),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="operator-response shells with condition/query inputs",
        benchmark_surface_compatibility="operator_appendix_branch",
        runtime_contract_status="branch_trunk_operator_adapter",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_APPENDIX,
        evidence_status=EVIDENCE_OPERATOR,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="external_code_family",
        default_runtime_name="ext_pdenneval_deeponet",
        aliases=("DeepONet", "deeponet", "deep operator network"),
        notes="Existing canonical operator family retained as a primary method object; appendix/operator evidence exists, but mainline rights remain bounded.",
    ),
    PrimaryMethodRecord(
        method_name="PINO",
        method_id="pinnmark.operator.pino",
        display_name="PINNMark PINO",
        top_level_family="pinnmark.operator.pino",
        benchmark_primary_subfamily=False,
        canonical_status="existing_primary_family",
        method_type="operator_family",
        formulation_type="physics_informed_operator_learning",
        source_lineage=("PDENNEval::PINO",),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="needs operator + physics residual coupling on rollout tasks",
        benchmark_surface_compatibility="task_scoped_operator_physics_runtime",
        runtime_contract_status="bounded_operator_physics_runtime",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_RUNNABLE_NOT_COMPARABLE,
        evidence_status=EVIDENCE_RUNTIME_SMOKE,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="bounded_native_runtime",
        default_runtime_name="pino_operator",
        aliases=("PINO", "pino"),
        notes="Existing canonical operator family remains primary and now has a bounded operator+physics runnable surrogate, but the training contract is still not benchmark-faithful.",
    ),
    PrimaryMethodRecord(
        method_name="PI-DeepONet",
        method_id="pinnmark.operator.pi_deeponet",
        display_name="PINNMark PI-DeepONet",
        top_level_family="pinnmark.operator.deeponet",
        benchmark_primary_subfamily=True,
        canonical_status="benchmark_primary_subfamily",
        method_type="operator_family",
        formulation_type="physics_informed_branch_trunk_operator",
        source_lineage=("PI-DeepONet literature lineage", "physics-informed DeepONet branch"),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="needs DeepONet operator shells plus physics-informed training hooks",
        benchmark_surface_compatibility="task_scoped_operator_physics_runtime",
        runtime_contract_status="bounded_physics_informed_deeponet_runtime",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_RUNNABLE_NOT_COMPARABLE,
        evidence_status=EVIDENCE_RUNTIME_SMOKE,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="source_backed_bounded_runtime",
        default_runtime_name="pi_deeponet_operator",
        aliases=("PI-DeepONet", "pi_deeponet", "pideeponet"),
        notes="Admitted as a primary subfamily of DeepONet and now runnable through a bounded source-backed PI-DeepONet surrogate, while full physics-informed operator training semantics remain incomplete.",
    ),
    PrimaryMethodRecord(
        method_name="PI-DION",
        method_id="pinnmark.operator.pi_dion",
        display_name="PINNMark PI-DION",
        top_level_family="pinnmark.operator.inverse_operator",
        benchmark_primary_subfamily=True,
        canonical_status="benchmark_primary_subfamily",
        method_type="operator_family",
        formulation_type="physics_informed_inverse_operator",
        source_lineage=("PI-DION literature lineage",),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="needs inverse-operator supervision and physics coupling from measurements",
        benchmark_surface_compatibility="task_scoped_inverse_operator_runtime",
        runtime_contract_status="bounded_inverse_operator_runtime",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_RUNNABLE_NOT_COMPARABLE,
        evidence_status=EVIDENCE_RUNTIME_SMOKE,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="bounded_native_runtime",
        default_runtime_name="pi_dion_operator",
        aliases=("PI-DION", "pi_dion", "pidion"),
        notes="Admitted as a distinct inverse-operator method and now runnable through a bounded inverse-operator surrogate, while full inverse-supervision semantics remain incomplete.",
    ),
    PrimaryMethodRecord(
        method_name="PI-GANO",
        method_id="pinnmark.operator.pi_gano",
        display_name="PINNMark PI-GANO",
        top_level_family="pinnmark.operator.geometry_aware",
        benchmark_primary_subfamily=True,
        canonical_status="benchmark_primary_subfamily",
        method_type="operator_family",
        formulation_type="geometry_aware_physics_informed_operator",
        source_lineage=("PI-GANO literature lineage",),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="needs geometry-conditioned operator tasks and physics-informed loss hooks",
        benchmark_surface_compatibility="task_scoped_geometry_operator_runtime",
        runtime_contract_status="bounded_geometry_aware_operator_runtime",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_RUNNABLE_NOT_COMPARABLE,
        evidence_status=EVIDENCE_RUNTIME_SMOKE,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="task_scoped_runtime",
        default_runtime_name="pi_gano_operator",
        aliases=("PI-GANO", "pi_gano", "pigano"),
        notes="Admitted as a geometry-aware operator subfamily and now runnable through a task-scoped geometry-aware surrogate, while full geometry-conditioned operator tasks remain missing.",
    ),
    PrimaryMethodRecord(
        method_name="VINO",
        method_id="pinnmark.operator.vino",
        display_name="PINNMark VINO",
        top_level_family="pinnmark.operator.variational",
        benchmark_primary_subfamily=True,
        canonical_status="benchmark_primary_subfamily",
        method_type="operator_family",
        formulation_type="variational_operator_learning",
        source_lineage=("VINO literature lineage",),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="needs variational operator losses and discretization-aware rollout shells",
        benchmark_surface_compatibility="task_scoped_variational_operator_runtime",
        runtime_contract_status="bounded_variational_operator_runtime",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_RUNNABLE_NOT_COMPARABLE,
        evidence_status=EVIDENCE_RUNTIME_SMOKE,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="task_scoped_runtime",
        default_runtime_name="vino_operator",
        aliases=("VINO", "vino"),
        notes="Admitted as a variational-operator primary method and now runnable through a task-scoped variational surrogate, while true integral/energy-based operator training remains missing.",
    ),
    PrimaryMethodRecord(
        method_name="MF-PIDNN",
        method_id="pinnmark.multifidelity.mf_pidnn",
        display_name="PINNMark MF-PIDNN",
        top_level_family="pinnmark.multifidelity.physics_informed",
        benchmark_primary_subfamily=True,
        canonical_status="benchmark_primary_subfamily",
        method_type="multifidelity_family",
        formulation_type="multifidelity_transfer_physics_informed",
        source_lineage=("MF-PIDNN literature lineage",),
        config_contract_defined=True,
        runtime_contract_defined=True,
        loss_or_formulation_contract_defined=True,
        task_shell_compatibility="needs low-/high-fidelity routing, transfer stages, and fidelity-aware evaluation",
        benchmark_surface_compatibility="multifidelity_branch_not_yet_defined",
        runtime_contract_status="bounded_multifidelity_correction_runtime",
        runnable_status=RUNNABLE_STATUS_RUNNABLE,
        comparability_status=COMPARABILITY_RUNNABLE_NOT_COMPARABLE,
        evidence_status=EVIDENCE_RUNTIME_SMOKE,
        internalization_level=INTERNALIZATION_PARTIALLY_INTERNALIZED,
        source_faithfulness_level="bounded_multifidelity_proxy",
        default_runtime_name="mf_pidnn_mlp",
        aliases=("MF-PIDNN", "mf_pidnn", "mfpidnn"),
        notes="Admitted into the main method universe as the anchor multi-fidelity physics-informed method and now constructible through a bounded low-/high-fidelity correction MLP proxy; true multifidelity data routing and evaluation remain missing.",
    ),
)

_INDEX = {record.method_id: record for record in _RECORDS}
_ALIAS_INDEX: dict[str, PrimaryMethodRecord] = {}
for record in _RECORDS:
    for alias in (record.method_id, record.method_name, *record.aliases):
        _ALIAS_INDEX[_normalize_token(alias)] = record


def list_primary_method_ids() -> list[str]:
    return sorted(_INDEX)


def list_primary_method_records() -> list[PrimaryMethodRecord]:
    return list(_RECORDS)


def get_primary_method_record(name: str) -> PrimaryMethodRecord:
    key = _normalize_token(name)
    if key not in _ALIAS_INDEX:
        available = ", ".join(list_primary_method_ids()) or "<empty>"
        raise KeyError(f"Unknown primary method '{name}'. Available: {available}")
    return _ALIAS_INDEX[key]


def resolve_primary_method_record(name: str) -> PrimaryMethodRecord | None:
    try:
        return get_primary_method_record(name)
    except KeyError:
        return None


def resolve_primary_method_runtime_name(name: str) -> str:
    record = get_primary_method_record(name)
    if record.default_runtime_name is None or record.runnable_status != RUNNABLE_STATUS_RUNNABLE:
        raise KeyError(
            f"Known primary method '{name}' is not currently runnable "
            f"(level={record.internalization_level}, runtime_status={record.runtime_contract_status}, "
            f"comparability={record.comparability_status})."
        )
    return record.default_runtime_name


def primary_method_intake_rows() -> list[dict[str, object]]:
    return [record.to_intake_row() for record in _RECORDS]


def primary_method_contract_rows() -> list[dict[str, object]]:
    return [record.to_contract_row() for record in _RECORDS]


__all__ = [
    "PRIMARY_METHOD_INTEGRATION",
    "PrimaryMethodRecord",
    "get_primary_method_record",
    "list_primary_method_ids",
    "list_primary_method_records",
    "primary_method_contract_rows",
    "primary_method_intake_rows",
    "resolve_primary_method_record",
    "resolve_primary_method_runtime_name",
]
