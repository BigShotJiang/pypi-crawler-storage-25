"""Preview operator-ready grid MLP baseline."""

from __future__ import annotations

from typing import Any

import torch
from torch import nn

from pinn_bench.models.base import BaseOperatorModel
from pinn_bench.registry import register_model



def _build_activation(name: str) -> nn.Module:
    activation_name = str(name).lower()
    activation_map = {
        "relu": nn.ReLU,
        "gelu": nn.GELU,
        "tanh": nn.Tanh,
        "silu": nn.SiLU,
    }
    if activation_name not in activation_map:
        supported = ", ".join(sorted(activation_map))
        raise ValueError(f"Unsupported activation '{name}'. Supported: {supported}")
    return activation_map[activation_name]()


@register_model("grid_mlp")
class GridMLP(BaseOperatorModel):
    """Small operator-ready baseline that conditions on task metadata and predicts a flattened field."""

    def __init__(
        self,
        query_dim: int = 2,
        condition_dim: int = 1,
        output_dim: int = 1,
        hidden_dims: list[int] | None = None,
        activation: str = "tanh",
        **_: Any,
    ) -> None:
        super().__init__()
        self.query_dim = int(query_dim)
        self.condition_dim = int(condition_dim)
        self.output_dim = int(output_dim)
        self.hidden_dims = [int(dim) for dim in (hidden_dims or [64, 64, 64])]
        layer_dims = [self.query_dim + self.condition_dim, *self.hidden_dims, self.output_dim]

        layers: list[nn.Module] = []
        for idx in range(len(layer_dims) - 1):
            layers.append(nn.Linear(layer_dims[idx], layer_dims[idx + 1]))
            if idx < len(layer_dims) - 2:
                layers.append(_build_activation(activation))
        self.network = nn.Sequential(*layers)

    def _expand_condition(self, condition_inputs: torch.Tensor | None, query_inputs: torch.Tensor) -> torch.Tensor:
        if condition_inputs is None:
            return torch.zeros((query_inputs.shape[0], self.condition_dim), device=query_inputs.device, dtype=query_inputs.dtype)
        if condition_inputs.ndim == 1:
            condition_inputs = condition_inputs.unsqueeze(0)
        condition_inputs = condition_inputs.to(device=query_inputs.device, dtype=query_inputs.dtype)
        if condition_inputs.shape[0] == query_inputs.shape[0]:
            return condition_inputs
        if condition_inputs.shape[0] == 1:
            return condition_inputs.expand(query_inputs.shape[0], -1)
        raise ValueError(
            f"Condition batch shape {tuple(condition_inputs.shape)} is incompatible with query batch shape {tuple(query_inputs.shape)}."
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)

    def forward_field(
        self,
        condition_inputs: torch.Tensor | None,
        query_inputs: torch.Tensor | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> torch.Tensor:
        del metadata
        if query_inputs is None:
            raise ValueError("GridMLP requires query_inputs for forward_field(...).")
        expanded_condition = self._expand_condition(condition_inputs, query_inputs)
        return self.network(torch.cat([query_inputs, expanded_condition], dim=1))
