"""Soft domain-decomposition MLP for XPINN-style stress experiments."""

from __future__ import annotations

from typing import Any

import torch
from torch import nn

from pinn_bench.models.base import BaseModel
from pinn_bench.models.mlp import _build_activation
from pinn_bench.registry import register_model


@register_model("xpinn_mlp")
class XPINNMLP(BaseModel):
    """Partition-of-unity MLP ensemble over overlapping subdomains."""

    solver_profile = "xpinn_mlp"

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dims: list[int] | None = None,
        activation: str = "tanh",
        num_subdomains: int = 2,
        overlap: float = 0.1,
        decompose_axis: int = 0,
        domain_min: float = 0.0,
        domain_max: float = 1.0,
        **_: Any,
    ) -> None:
        super().__init__()
        self.input_dim = int(input_dim)
        self.output_dim = int(output_dim)
        self.hidden_dims = [int(dim) for dim in (hidden_dims or [48, 48, 48])]
        self.num_subdomains = max(2, int(num_subdomains))
        self.overlap = float(overlap)
        self.decompose_axis = int(decompose_axis)
        self.domain_min = float(domain_min)
        self.domain_max = float(domain_max)
        if not 0.0 <= self.overlap < 1.0:
            raise ValueError("XPINNMLP overlap must lie in [0, 1).")
        if not (0 <= self.decompose_axis < self.input_dim):
            raise ValueError("XPINNMLP decompose_axis must index an input feature.")
        if self.domain_max <= self.domain_min:
            raise ValueError("XPINNMLP domain_max must exceed domain_min.")

        self.subnetworks = nn.ModuleList(
            [self._build_subnetwork(activation=activation) for _ in range(self.num_subdomains)]
        )
        centers = torch.linspace(self.domain_min, self.domain_max, steps=self.num_subdomains)
        self.register_buffer("centers", centers, persistent=False)
        base_width = (self.domain_max - self.domain_min) / max(1, self.num_subdomains)
        gate_width = base_width * (1.0 + self.overlap)
        self.register_buffer("gate_width", torch.tensor(float(gate_width)), persistent=False)

    def _build_subnetwork(self, *, activation: str) -> nn.Sequential:
        layer_dims = [self.input_dim, *self.hidden_dims, self.output_dim]
        layers: list[nn.Module] = []
        for idx in range(len(layer_dims) - 1):
            layers.append(nn.Linear(layer_dims[idx], layer_dims[idx + 1]))
            if idx < len(layer_dims) - 2:
                layers.append(_build_activation(activation))
        return nn.Sequential(*layers)

    def _mixture_weights(self, x: torch.Tensor) -> torch.Tensor:
        coords = x[:, self.decompose_axis : self.decompose_axis + 1]
        diffs = coords - self.centers.reshape(1, -1)
        weights = torch.exp(-0.5 * (diffs / self.gate_width.clamp_min(1e-6)) ** 2)
        return weights / weights.sum(dim=1, keepdim=True).clamp_min(1e-6)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weights = self._mixture_weights(x)
        predictions = torch.stack([network(x) for network in self.subnetworks], dim=1)
        return (predictions * weights.unsqueeze(-1)).sum(dim=1)
