"""Lightweight variational Bayesian MLP for bounded B-PINN-style runtime support."""

from __future__ import annotations

from typing import Any

import torch
from torch import nn
from torch.nn import functional as F

from pinn_bench.models.base import BaseModel
from pinn_bench.models.mlp import _build_activation
from pinn_bench.registry import register_model


class BayesianLinear(nn.Module):
    """Variational linear layer with diagonal Gaussian posterior."""

    def __init__(self, in_features: int, out_features: int, *, prior_std: float = 1.0) -> None:
        super().__init__()
        self.in_features = int(in_features)
        self.out_features = int(out_features)
        self.prior_std = float(prior_std)
        self.weight_mu = nn.Parameter(torch.empty(out_features, in_features))
        self.weight_rho = nn.Parameter(torch.empty(out_features, in_features))
        self.bias_mu = nn.Parameter(torch.empty(out_features))
        self.bias_rho = nn.Parameter(torch.empty(out_features))
        self.reset_parameters()

    def reset_parameters(self) -> None:
        bound = 1.0 / max(1, self.in_features) ** 0.5
        nn.init.uniform_(self.weight_mu, -bound, bound)
        nn.init.constant_(self.weight_rho, -5.0)
        nn.init.uniform_(self.bias_mu, -bound, bound)
        nn.init.constant_(self.bias_rho, -5.0)

    @staticmethod
    def _sigma(rho: torch.Tensor) -> torch.Tensor:
        return F.softplus(rho)

    def _sample(self, mu: torch.Tensor, rho: torch.Tensor) -> torch.Tensor:
        sigma = self._sigma(rho)
        if self.training:
            eps = torch.randn_like(sigma)
            return mu + sigma * eps
        return mu

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self._sample(self.weight_mu, self.weight_rho)
        bias = self._sample(self.bias_mu, self.bias_rho)
        return F.linear(x, weight, bias)

    def kl_divergence(self) -> torch.Tensor:
        prior_var = self.prior_std ** 2
        weight_sigma = self._sigma(self.weight_rho)
        bias_sigma = self._sigma(self.bias_rho)
        weight_var = weight_sigma.square()
        bias_var = bias_sigma.square()
        weight_kl = 0.5 * torch.sum(
            (weight_var + self.weight_mu.square()) / prior_var - 1.0 + 2.0 * torch.log(self.prior_std / weight_sigma)
        )
        bias_kl = 0.5 * torch.sum(
            (bias_var + self.bias_mu.square()) / prior_var - 1.0 + 2.0 * torch.log(self.prior_std / bias_sigma)
        )
        return weight_kl + bias_kl


@register_model("bayesian_mlp")
class BayesianMLP(BaseModel):
    """Variational Bayesian MLP with a KL regularization hook."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dims: list[int] | None = None,
        activation: str = "tanh",
        prior_std: float = 1.0,
        kl_weight: float = 1e-4,
        **_: Any,
    ) -> None:
        super().__init__()
        hidden_dims = hidden_dims or [64, 64]
        layer_dims = [int(input_dim), *[int(value) for value in hidden_dims], int(output_dim)]
        layers: list[nn.Module] = []
        for idx in range(len(layer_dims) - 1):
            layers.append(BayesianLinear(layer_dims[idx], layer_dims[idx + 1], prior_std=float(prior_std)))
            if idx < len(layer_dims) - 2:
                layers.append(_build_activation(activation))
        self.network = nn.Sequential(*layers)
        self.kl_weight = float(kl_weight)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)

    def extra_loss_terms(self) -> dict[str, torch.Tensor]:
        kl = torch.zeros((), device=self.network[0].weight_mu.device)
        for module in self.modules():
            if isinstance(module, BayesianLinear):
                kl = kl + module.kl_divergence()
        return {"bayes_kl": kl * self.kl_weight}
