"""Unified registry and identity layer for external benchmark model families."""

from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache
import inspect
import json
from pathlib import Path
import re
from typing import Any

from pinn_bench.resources import resolve_repo_root


INTEGRATION_STATE_NATIVE = "native"
INTEGRATION_STATE_REGISTRY_ONLY = "external_registry_only"
INTEGRATION_STATE_ADAPTER_READY = "external_adapter_ready"
INTEGRATION_STATE_RUNNABLE = "external_runnable"
INTEGRATION_STATE_BLOCKED = "external_blocked"

RUNNABLE_STATUS_NATIVE_PROXY = "native_proxy_runnable"
RUNNABLE_STATUS_EXTERNAL_CODE = "external_code_runnable"
RUNNABLE_STATUS_ADAPTER_READY = "adapter_ready_not_runnable"
RUNNABLE_STATUS_REGISTRY_ONLY = "registry_only"
RUNNABLE_STATUS_BLOCKED = "blocked"
RUNNABLE_STATUS_FAMILY_ABSTRACT = "family_abstract_not_directly_runnable"
RUNNABLE_STATUS_TASK_HOOK_BLOCKED = "blocked_by_task_hook"
RUNNABLE_STATUS_VARIATIONAL_BLOCKED = "blocked_by_variational_runtime"
RUNNABLE_STATUS_NOT_YET = "not_yet_runnable"

MODEL_SURFACES = {"constructible", "native", "external", "all"}
_SANITIZE_PATTERN = re.compile(r"[^a-z0-9]+")
_BENCHMARK_FACING_NATIVE_MODEL_NAMES = (
    "adaptive_mlp",
    "bayesian_mlp",
    "grid_mlp",
    "mini_fno",
    "mlp",
    "siren",
    "spectral_mlp",
    "xpinn_mlp",
)


@dataclass(frozen=True)
class ExternalModelRecord:
    external_model_id: str
    source_benchmark: str
    source_family_name: str
    canonical_name: str
    display_name: str
    model_category: str
    model_subcategory: str
    is_pinn_family: bool
    is_operator_family: bool
    is_solver_adjacent: bool
    integration_state: str
    adapter_name: str | None
    runnable_status: str
    native_equivalent: str | None
    comparability_scope: str
    capability_tags: tuple[str, ...] = field(default_factory=tuple)
    provenance_notes: str = ""
    repo_path: str | None = None
    notes: str = ""
    aliases: tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, object]:
        return {
            "external_model_id": self.external_model_id,
            "source_benchmark": self.source_benchmark,
            "source_family_name": self.source_family_name,
            "canonical_name": self.canonical_name,
            "display_name": self.display_name,
            "model_category": self.model_category,
            "model_subcategory": self.model_subcategory,
            "is_pinn_family": self.is_pinn_family,
            "is_operator_family": self.is_operator_family,
            "is_solver_adjacent": self.is_solver_adjacent,
            "integration_state": self.integration_state,
            "adapter_name": self.adapter_name,
            "runnable_status": self.runnable_status,
            "native_equivalent": self.native_equivalent,
            "comparability_scope": self.comparability_scope,
            "capability_tags": list(self.capability_tags),
            "provenance_notes": self.provenance_notes,
            "repo_path": self.repo_path,
            "notes": self.notes,
            "aliases": list(self.aliases),
        }


@dataclass(frozen=True)
class ModelReferenceResolution:
    kind: str
    input_name: str
    canonical_name: str
    integration_state: str
    runnable_status: str
    source_benchmark: str | None = None
    external_model_id: str | None = None

    @property
    def constructible(self) -> bool:
        if self.kind == "native":
            return True
        return self.integration_state == INTEGRATION_STATE_RUNNABLE


def _inventory_artifact_path() -> Path:
    return (
        resolve_repo_root()
        / "artifacts"
        / "benchmark_model_inventory"
        / "external_benchmark_model_inventory.json"
    )


@lru_cache(maxsize=1)
def _inventory_payload() -> dict[str, Any]:
    payload = json.loads(_inventory_artifact_path().read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("external benchmark inventory must decode to a JSON object.")
    return payload


@lru_cache(maxsize=1)
def _inventory_rows_by_key() -> dict[str, dict[str, str]]:
    mapping: dict[str, dict[str, str]] = {}
    rows = _inventory_payload().get("rows", [])
    if not isinstance(rows, list):
        return mapping
    for row in rows:
        if not isinstance(row, dict):
            continue
        if str(row.get("inventory_type") or "") not in {"repo_family_dir", "repo_model_file"}:
            continue
        benchmark = str(row.get("benchmark") or "").strip()
        family = str(row.get("family") or "").strip()
        if not benchmark or not family:
            continue
        mapping[f"{benchmark}::{family}"] = {
            "path": str(row.get("path") or "").strip(),
            "detail": str(row.get("detail") or "").strip(),
            "notes": str(row.get("notes") or "").strip(),
        }
    return mapping


def _sanitize_fragment(value: str) -> str:
    text = _SANITIZE_PATTERN.sub("_", str(value).strip().lower()).strip("_")
    return text or "unknown"


def _canonical_name(benchmark: str, family: str) -> str:
    return f"ext_{_sanitize_fragment(benchmark)}_{_sanitize_fragment(family)}"


def _display_name(benchmark: str, family: str) -> str:
    pieces = family.replace("_", " ").split()
    pretty_family = " ".join(piece.upper() if piece.isupper() else piece.capitalize() for piece in pieces)
    return f"{benchmark} {pretty_family}".strip()


def _source_record_summary(benchmark: str) -> str:
    rows = _inventory_payload().get("rows", [])
    if not isinstance(rows, list):
        return ""
    benchmarks = set()
    for row in rows:
        if not isinstance(row, dict):
            continue
        if str(row.get("inventory_type") or "") != "source_record_entry":
            continue
        if str(row.get("benchmark") or "").strip() == benchmark:
            benchmarks.add(str(row.get("path") or "").strip())
    if not benchmarks:
        return "No checked-in source_record entry currently points to this family."
    return f"Checked-in source intake exists under {sorted(benchmarks)[0]}."


_CATEGORY_OVERRIDES: dict[str, dict[str, object]] = {
    "PINNacle::deepxde": {
        "model_category": "pinn_framework",
        "model_subcategory": "library_runtime",
        "is_pinn_family": True,
        "is_operator_family": False,
        "is_solver_adjacent": False,
        "integration_state": INTEGRATION_STATE_ADAPTER_READY,
        "adapter_name": "pinnacle_deepxde_proxy",
        "runnable_status": RUNNABLE_STATUS_FAMILY_ABSTRACT,
        "native_equivalent": None,
        "comparability_scope": "framework_family_metadata_only",
        "capability_tags": ("family:pinn", "family:framework", "adapter:family"),
        "notes": "Framework family is cataloged and adapter-classified, but not promoted as one directly runnable model identity.",
    },
    "PINNacle::fbpinns": {
        "model_category": "pinn_family",
        "model_subcategory": "domain_decomposition",
        "is_pinn_family": True,
        "is_operator_family": False,
        "is_solver_adjacent": False,
        "integration_state": INTEGRATION_STATE_RUNNABLE,
        "adapter_name": "pinnacle_fbpinns_proxy",
        "runnable_status": RUNNABLE_STATUS_NATIVE_PROXY,
        "native_equivalent": "xpinn_mlp",
        "comparability_scope": "pointwise_decomposition_proxy",
        "capability_tags": ("capability:pointwise_solution_model", "family:pinn", "family:decomposition", "adapter:proxy"),
        "notes": "Runnable decomposition proxy backed by the native XPINN-style model surface.",
    },
    "PINNacle::vpinn": {
        "model_category": "pinn_family",
        "model_subcategory": "variational",
        "is_pinn_family": True,
        "is_operator_family": False,
        "is_solver_adjacent": True,
        "integration_state": INTEGRATION_STATE_BLOCKED,
        "adapter_name": "pinnacle_vpinn_family",
        "runnable_status": RUNNABLE_STATUS_VARIATIONAL_BLOCKED,
        "native_equivalent": None,
        "comparability_scope": "weak_form_task_specific",
        "capability_tags": ("family:pinn", "family:variational", "surface:weak_form"),
        "notes": "Blocked on a task-owned weak-form / quadrature contract; a model-only adapter would misrepresent the method.",
    },
    "PINNacle::fnn": {
        "model_category": "pinn_family",
        "model_subcategory": "vanilla_mlp",
        "is_pinn_family": True,
        "is_operator_family": False,
        "is_solver_adjacent": False,
        "integration_state": INTEGRATION_STATE_RUNNABLE,
        "adapter_name": "pinnacle_fnn_proxy",
        "runnable_status": RUNNABLE_STATUS_NATIVE_PROXY,
        "native_equivalent": "mlp",
        "comparability_scope": "pointwise_nominal_proxy",
        "capability_tags": ("capability:pointwise_solution_model", "family:pinn", "adapter:proxy"),
        "notes": "Runnable FNN proxy backed by the native MLP interface.",
    },
    "PINNacle::laaf": {
        "model_category": "pinn_family",
        "model_subcategory": "adaptive_activation",
        "is_pinn_family": True,
        "is_operator_family": False,
        "is_solver_adjacent": False,
        "integration_state": INTEGRATION_STATE_RUNNABLE,
        "adapter_name": "pinnacle_laaf_external",
        "runnable_status": RUNNABLE_STATUS_EXTERNAL_CODE,
        "native_equivalent": None,
        "comparability_scope": "pointwise_nominal_family",
        "capability_tags": ("capability:pointwise_solution_model", "family:pinn", "family:adaptive_activation", "adapter:external_code"),
        "notes": "Runnable through a thin adapter over the checked-in PINNacle LAAF implementation.",
    },
    "PINNacle::hard_constraint": {
        "model_category": "pinn_family",
        "model_subcategory": "hard_constraint",
        "is_pinn_family": True,
        "is_operator_family": False,
        "is_solver_adjacent": True,
        "integration_state": INTEGRATION_STATE_RUNNABLE,
        "adapter_name": "pinnacle_hard_constraint_family",
        "runnable_status": RUNNABLE_STATUS_NATIVE_PROXY,
        "native_equivalent": "mlp",
        "comparability_scope": "task_conditioned_constraint_family",
        "capability_tags": ("family:pinn", "family:hard_constraint", "adapter:runtime_hook"),
        "notes": "Runnable through a task-coupled output-transform wrapper over the native MLP path; still narrower than a source-faithful benchmark family.",
    },
    "PDENNEval::PINN": {
        "model_category": "pinn_family",
        "model_subcategory": "vanilla_mlp",
        "is_pinn_family": True,
        "is_operator_family": False,
        "is_solver_adjacent": False,
        "integration_state": INTEGRATION_STATE_RUNNABLE,
        "adapter_name": "pdenneval_pinn_proxy",
        "runnable_status": RUNNABLE_STATUS_NATIVE_PROXY,
        "native_equivalent": "mlp",
        "comparability_scope": "pointwise_nominal_proxy",
        "capability_tags": ("capability:pointwise_solution_model", "family:pinn", "adapter:proxy"),
        "notes": "Runnable family proxy that preserves source provenance while using the native pointwise MLP path.",
    },
    "PDEBench::pinn": {
        "model_category": "pinn_family",
        "model_subcategory": "vanilla_mlp",
        "is_pinn_family": True,
        "is_operator_family": False,
        "is_solver_adjacent": False,
        "integration_state": INTEGRATION_STATE_RUNNABLE,
        "adapter_name": "pdebench_pinn_proxy",
        "runnable_status": RUNNABLE_STATUS_NATIVE_PROXY,
        "native_equivalent": "mlp",
        "comparability_scope": "pointwise_nominal_proxy",
        "capability_tags": ("capability:pointwise_solution_model", "family:pinn", "adapter:proxy"),
        "notes": "Runnable family proxy aligned to the current native pointwise MLP surface.",
    },
    "PDENNEval::PINO": {
        "model_category": "operator_family",
        "model_subcategory": "physics_informed_operator",
        "is_pinn_family": False,
        "is_operator_family": True,
        "is_solver_adjacent": False,
        "integration_state": INTEGRATION_STATE_ADAPTER_READY,
        "adapter_name": "operator_pino_family",
        "runnable_status": RUNNABLE_STATUS_NOT_YET,
        "native_equivalent": None,
        "comparability_scope": "field_rollout_family",
        "capability_tags": ("capability:fieldwise_solution_model", "family:operator"),
        "notes": "Adapter-classified operator family; current runtime still lacks benchmark-faithful PINO training semantics.",
    },
    "PDENNEval::DeepONet": {
        "model_category": "operator_family",
        "model_subcategory": "operator_response",
        "is_pinn_family": False,
        "is_operator_family": True,
        "is_solver_adjacent": False,
        "integration_state": INTEGRATION_STATE_RUNNABLE,
        "adapter_name": "operator_deeponet_family",
        "runnable_status": RUNNABLE_STATUS_EXTERNAL_CODE,
        "native_equivalent": None,
        "comparability_scope": "operator_response_family",
        "capability_tags": ("capability:operator_response_model", "family:operator", "adapter:external_code"),
        "notes": "Runnable through a lightweight branch-trunk adapter inspired by the local external DeepONet family; benchmark-surface promotion still remains separate from construction.",
    },
    "PDENNEval::FNO": {
        "model_category": "operator_family",
        "model_subcategory": "fourier_operator",
        "is_pinn_family": False,
        "is_operator_family": True,
        "is_solver_adjacent": False,
        "integration_state": INTEGRATION_STATE_RUNNABLE,
        "adapter_name": "operator_fno_family",
        "runnable_status": RUNNABLE_STATUS_NATIVE_PROXY,
        "native_equivalent": "mini_fno",
        "comparability_scope": "field_rollout_proxy",
        "capability_tags": ("capability:fieldwise_solution_model", "family:operator", "adapter:proxy"),
        "notes": "Runnable as a mini_fno-backed operator proxy; benchmark-faithful source-family parity is still incomplete.",
    },
    "PDEBench::fno": {
        "model_category": "operator_family",
        "model_subcategory": "fourier_operator",
        "is_pinn_family": False,
        "is_operator_family": True,
        "is_solver_adjacent": False,
        "integration_state": INTEGRATION_STATE_RUNNABLE,
        "adapter_name": "operator_fno_family",
        "runnable_status": RUNNABLE_STATUS_NATIVE_PROXY,
        "native_equivalent": "mini_fno",
        "comparability_scope": "field_rollout_proxy",
        "capability_tags": ("capability:fieldwise_solution_model", "family:operator", "adapter:proxy"),
        "notes": "Runnable as a mini_fno-backed operator proxy; benchmark-faithful source-family parity is still incomplete.",
    },
    "PDEBench::inverse": {
        "model_category": "solver_family",
        "model_subcategory": "inverse_runtime",
        "is_pinn_family": False,
        "is_operator_family": False,
        "is_solver_adjacent": True,
        "integration_state": INTEGRATION_STATE_BLOCKED,
        "adapter_name": None,
        "runnable_status": RUNNABLE_STATUS_BLOCKED,
        "native_equivalent": None,
        "comparability_scope": "inverse_task_specific",
        "capability_tags": ("family:inverse", "surface:task_specific"),
        "notes": "Blocked on benchmark-specific inverse data plumbing and does not map cleanly to the current native task contract.",
    },
    "PDEBench::unet": {
        "model_category": "operator_family",
        "model_subcategory": "unet_field_model",
        "is_pinn_family": False,
        "is_operator_family": True,
        "is_solver_adjacent": False,
        "integration_state": INTEGRATION_STATE_REGISTRY_ONLY,
        "adapter_name": None,
        "runnable_status": RUNNABLE_STATUS_REGISTRY_ONLY,
        "native_equivalent": None,
        "comparability_scope": "field_rollout_family",
        "capability_tags": ("capability:fieldwise_solution_model", "family:operator"),
        "notes": "Cataloged for later fieldwise integration; no native UNet surface exists yet.",
    },
    "pdearena::pdemodel": {
        "model_category": "operator_family",
        "model_subcategory": "field_dynamics_model",
        "is_pinn_family": False,
        "is_operator_family": True,
        "is_solver_adjacent": False,
        "integration_state": INTEGRATION_STATE_BLOCKED,
        "adapter_name": None,
        "runnable_status": RUNNABLE_STATUS_BLOCKED,
        "native_equivalent": None,
        "comparability_scope": "field_rollout_family",
        "capability_tags": ("capability:fieldwise_solution_model", "family:operator"),
        "notes": "Family retained in the catalog; current pdearena model surface is broader than the native operator contract.",
    },
    "pdearena::cond_pdemodel": {
        "model_category": "operator_family",
        "model_subcategory": "conditional_field_dynamics",
        "is_pinn_family": False,
        "is_operator_family": True,
        "is_solver_adjacent": False,
        "integration_state": INTEGRATION_STATE_BLOCKED,
        "adapter_name": None,
        "runnable_status": RUNNABLE_STATUS_BLOCKED,
        "native_equivalent": None,
        "comparability_scope": "conditional_field_rollout_family",
        "capability_tags": ("capability:fieldwise_solution_model", "family:operator"),
        "notes": "Conditional operator family requires richer task conditioning metadata than the current native runner exposes.",
    },
    "pdearena::pderefiner": {
        "model_category": "solver_family",
        "model_subcategory": "refinement_model",
        "is_pinn_family": False,
        "is_operator_family": True,
        "is_solver_adjacent": True,
        "integration_state": INTEGRATION_STATE_BLOCKED,
        "adapter_name": None,
        "runnable_status": RUNNABLE_STATUS_BLOCKED,
        "native_equivalent": None,
        "comparability_scope": "field_refinement_family",
        "capability_tags": ("family:refinement", "surface:field"),
        "notes": "Cataloged as a refinement-side family; current native runner has no dedicated refinement contract.",
    },
    "pdearena::registry": {
        "model_category": "support_module",
        "model_subcategory": "model_registry_helper",
        "is_pinn_family": False,
        "is_operator_family": False,
        "is_solver_adjacent": True,
        "integration_state": INTEGRATION_STATE_REGISTRY_ONLY,
        "adapter_name": None,
        "runnable_status": RUNNABLE_STATUS_REGISTRY_ONLY,
        "native_equivalent": None,
        "comparability_scope": "support_only",
        "capability_tags": ("support:registry",),
        "notes": "Support module only; excluded from the user-facing external model universe.",
    },
}


def _default_family_metadata(key: str) -> dict[str, object]:
    benchmark, family = key.split("::", maxsplit=1)
    family_lower = family.lower()
    model_category = "solver_family"
    model_subcategory = "general"
    is_pinn_family = False
    is_operator_family = False
    is_solver_adjacent = True
    comparability_scope = "benchmark_family"
    capability_tags: tuple[str, ...] = ("family:external",)

    if family_lower in {"deepxde", "fbpinns", "vpinn", "fnn", "laaf", "hard_constraint", "pinn"}:
        model_category = "pinn_family"
        model_subcategory = family_lower
        is_pinn_family = True
        is_solver_adjacent = False
        comparability_scope = "pointwise_family"
        capability_tags = ("capability:pointwise_solution_model", "family:pinn")
    elif family_lower in {"pino", "deeponet", "fno", "uno", "unet", "mpnn", "pdemodel", "cond_pdemodel", "pderefiner"}:
        model_category = "operator_family"
        model_subcategory = family_lower
        is_operator_family = True
        is_solver_adjacent = family_lower == "pderefiner"
        comparability_scope = "field_rollout_family"
        capability_tags = ("capability:fieldwise_solution_model", "family:operator")
    elif family_lower in {"drm", "dflm", "dfvm", "rfm", "wan", "inverse"}:
        model_category = "solver_family"
        model_subcategory = family_lower
        is_solver_adjacent = True
        comparability_scope = "solver_adjacent_family"
        capability_tags = ("family:solver_adjacent",)

    return {
        "model_category": model_category,
        "model_subcategory": model_subcategory,
        "is_pinn_family": is_pinn_family,
        "is_operator_family": is_operator_family,
        "is_solver_adjacent": is_solver_adjacent,
        "integration_state": INTEGRATION_STATE_REGISTRY_ONLY,
        "adapter_name": None,
        "runnable_status": RUNNABLE_STATUS_REGISTRY_ONLY,
        "native_equivalent": None,
        "comparability_scope": comparability_scope,
        "capability_tags": capability_tags,
        "notes": "Cataloged from the checked-in external benchmark repo inventory.",
    }


def _family_aliases(*, benchmark: str, family: str, canonical_name: str, external_model_id: str) -> tuple[str, ...]:
    return tuple(
        sorted(
            {
                canonical_name,
                external_model_id,
                external_model_id.lower(),
                f"{_sanitize_fragment(benchmark)}::{_sanitize_fragment(family)}",
                f"{_sanitize_fragment(benchmark)}_{_sanitize_fragment(family)}",
            }
        )
    )


def _provenance_notes(benchmark: str, key: str, path: str | None) -> str:
    source_bits = [f"source benchmark: {benchmark}"]
    if path:
        source_bits.append(f"repo locator: {path}")
    source_bits.append(_source_record_summary(benchmark))
    return " | ".join(source_bits)


@lru_cache(maxsize=1)
def _external_records() -> dict[str, ExternalModelRecord]:
    rows = _inventory_rows_by_key()
    records: dict[str, ExternalModelRecord] = {}
    for key in sorted(rows):
        if key == "pdearena::registry":
            continue
        benchmark, family = key.split("::", maxsplit=1)
        path = rows[key].get("path") or None
        canonical_name = _canonical_name(benchmark, family)
        overrides = {**_default_family_metadata(key), **_CATEGORY_OVERRIDES.get(key, {})}
        external_model_id = key
        record = ExternalModelRecord(
            external_model_id=external_model_id,
            source_benchmark=benchmark,
            source_family_name=family,
            canonical_name=canonical_name,
            display_name=_display_name(benchmark, family),
            model_category=str(overrides["model_category"]),
            model_subcategory=str(overrides["model_subcategory"]),
            is_pinn_family=bool(overrides["is_pinn_family"]),
            is_operator_family=bool(overrides["is_operator_family"]),
            is_solver_adjacent=bool(overrides["is_solver_adjacent"]),
            integration_state=str(overrides["integration_state"]),
            adapter_name=None if overrides["adapter_name"] is None else str(overrides["adapter_name"]),
            runnable_status=str(overrides["runnable_status"]),
            native_equivalent=None if overrides["native_equivalent"] is None else str(overrides["native_equivalent"]),
            comparability_scope=str(overrides["comparability_scope"]),
            capability_tags=tuple(str(item) for item in overrides.get("capability_tags", ())),
            provenance_notes=_provenance_notes(benchmark, key, path),
            repo_path=path,
            notes=str(overrides["notes"]),
            aliases=_family_aliases(
                benchmark=benchmark,
                family=family,
                canonical_name=canonical_name,
                external_model_id=external_model_id,
            ),
        )
        records[canonical_name] = record
    return records


@lru_cache(maxsize=1)
def _external_alias_map() -> dict[str, str]:
    mapping: dict[str, str] = {}
    for canonical_name, record in _external_records().items():
        for alias in record.aliases:
            mapping[str(alias).strip().lower()] = canonical_name
    return mapping


def list_external_model_records(
    *,
    source_benchmark: str | None = None,
    integration_state: str | None = None,
    model_category: str | None = None,
    runnable_only: bool = False,
    pinn_family_only: bool = False,
    operator_family_only: bool = False,
) -> list[ExternalModelRecord]:
    rows = list(_external_records().values())
    if source_benchmark is not None:
        key = str(source_benchmark).strip().lower()
        rows = [row for row in rows if row.source_benchmark.lower() == key]
    if integration_state is not None:
        key = str(integration_state).strip().lower()
        rows = [row for row in rows if row.integration_state.lower() == key]
    if model_category is not None:
        key = str(model_category).strip().lower()
        rows = [row for row in rows if row.model_category.lower() == key]
    if runnable_only:
        rows = [row for row in rows if row.integration_state == INTEGRATION_STATE_RUNNABLE]
    if pinn_family_only:
        rows = [row for row in rows if row.is_pinn_family]
    if operator_family_only:
        rows = [row for row in rows if row.is_operator_family]
    return sorted(rows, key=lambda row: (row.source_benchmark.lower(), row.canonical_name))


def resolve_external_model_record(name: str) -> ExternalModelRecord | None:
    key = str(name).strip()
    if not key:
        return None
    lowered = key.lower()
    if lowered in _external_records():
        return _external_records()[lowered]
    canonical_name = _external_alias_map().get(lowered)
    if canonical_name is None:
        return None
    return _external_records()[canonical_name]


def get_external_model_record(name: str) -> ExternalModelRecord | None:
    """Return the external record for a canonical name or alias."""
    return resolve_external_model_record(name)


def list_external_model_names(
    *,
    source_benchmark: str | None = None,
    integration_state: str | None = None,
    model_category: str | None = None,
    runnable_only: bool = False,
    pinn_family_only: bool = False,
    operator_family_only: bool = False,
) -> list[str]:
    """Return canonical external model names with common filters."""
    return [
        row.canonical_name
        for row in list_external_model_records(
            source_benchmark=source_benchmark,
            integration_state=integration_state,
            model_category=model_category,
            runnable_only=runnable_only,
            pinn_family_only=pinn_family_only,
            operator_family_only=operator_family_only,
        )
    ]


def list_external_source_benchmarks() -> list[str]:
    """Return source benchmarks represented in the external model catalog."""
    return sorted({row.source_benchmark for row in list_external_model_records()})


def normalize_model_name(name: str) -> str:
    """Normalize a native or external model reference into its canonical name."""
    try:
        return normalize_model_reference(name, require_runnable=False)
    except ValueError:
        return str(name).strip().lower()


def resolve_external_model_name(name: str) -> str | None:
    record = resolve_external_model_record(name)
    return None if record is None else record.canonical_name


def build_external_model(name: str, **kwargs: Any) -> Any:
    record = resolve_external_model_record(name)
    if record is None:
        raise KeyError(f"Unknown external model '{name}'.")
    if record.integration_state != INTEGRATION_STATE_RUNNABLE or not record.adapter_name:
        raise ValueError(
            f"External model '{name}' is known but not runnable (state={record.integration_state}, runnable_status={record.runnable_status})."
        )
    from pinn_bench.models.external_adapters import get_external_adapter

    model = get_external_adapter(record.adapter_name).build_model(record=record, **kwargs)
    try:
        setattr(model, "__pinn_bench_external_model_metadata__", record.to_dict())
    except Exception:
        pass
    return model


def create_external_model(name: str, **kwargs: Any) -> Any:
    return build_external_model(name, **kwargs)


def normalize_model_reference(name: str, *, require_runnable: bool = False) -> str:
    from pinn_bench import registry as registry_module

    lowered = str(name).strip().lower()
    if lowered in registry_module._MODEL_REGISTRY:  # type: ignore[attr-defined]
        return lowered
    record = resolve_external_model_record(lowered)
    if record is None:
        available = ", ".join(sorted(registry_module._MODEL_REGISTRY.keys()))  # type: ignore[attr-defined]
        raise ValueError(f"Unknown model '{name}'. Available native models: {available}")
    if require_runnable and record.integration_state != INTEGRATION_STATE_RUNNABLE:
        raise ValueError(
            f"Model '{name}' resolves to external family '{record.external_model_id}', "
            f"but it is not runnable (state={record.integration_state}, runnable_status={record.runnable_status})."
        )
    return record.canonical_name


def resolve_model_reference(name: str) -> ModelReferenceResolution | None:
    from pinn_bench import registry as registry_module

    lowered = str(name).strip().lower()
    if not lowered:
        return None
    if lowered in registry_module._MODEL_REGISTRY:  # type: ignore[attr-defined]
        return ModelReferenceResolution(
            kind="native",
            input_name=name,
            canonical_name=lowered,
            integration_state=INTEGRATION_STATE_NATIVE,
            runnable_status="native_runnable",
        )
    record = resolve_external_model_record(lowered)
    if record is None:
        return None
    return ModelReferenceResolution(
        kind="external",
        input_name=name,
        canonical_name=record.canonical_name,
        integration_state=record.integration_state,
        runnable_status=record.runnable_status,
        source_benchmark=record.source_benchmark,
        external_model_id=record.external_model_id,
    )


def list_constructible_model_names() -> list[str]:
    from pinn_bench.registry import list_models

    native = list_models()
    external = [row.canonical_name for row in list_external_model_records(runnable_only=True)]
    return sorted(set(native) | set(external))


def list_native_model_names() -> list[str]:
    from pinn_bench.registry import list_models

    return list_models()


def list_unified_model_entries(
    *,
    surface: str = "constructible",
    source_benchmark: str | None = None,
    integration_state: str | None = None,
    model_category: str | None = None,
    runnable_only: bool = False,
) -> list[dict[str, object]]:
    normalized_surface = str(surface).strip().lower()
    if normalized_surface not in MODEL_SURFACES:
        allowed = ", ".join(sorted(MODEL_SURFACES))
        raise ValueError(f"surface must be one of: {allowed}")

    items: list[dict[str, object]] = []
    if normalized_surface in {"native", "constructible", "all"}:
        from pinn_bench.capabilities import lookup_model_capability
        from pinn_bench.registry import list_models

        for name in list_models():
            capability = lookup_model_capability(name)
            items.append(
                {
                    "name": name,
                    "kind": "native",
                    "canonical_name": name,
                    "display_name": name,
                    "source_benchmark": None,
                    "integration_state": INTEGRATION_STATE_NATIVE,
                    "runnable_status": "native_runnable",
                    "model_category": "native_model",
                    "capability_tags": [f"capability:{capability.capability_class.value}"],
                    "native_equivalent": None,
                }
            )
    if normalized_surface in {"external", "all"}:
        items.extend(
            {
                "name": row.canonical_name,
                "kind": "external",
                "canonical_name": row.canonical_name,
                "display_name": row.display_name,
                "source_benchmark": row.source_benchmark,
                "integration_state": row.integration_state,
                "runnable_status": row.runnable_status,
                "model_category": row.model_category,
                "capability_tags": list(row.capability_tags),
                "native_equivalent": row.native_equivalent,
            }
            for row in list_external_model_records(
                source_benchmark=source_benchmark,
                integration_state=integration_state,
                model_category=model_category,
                runnable_only=runnable_only,
            )
        )
    if normalized_surface == "constructible":
        items.extend(
            {
                "name": row.canonical_name,
                "kind": "external",
                "canonical_name": row.canonical_name,
                "display_name": row.display_name,
                "source_benchmark": row.source_benchmark,
                "integration_state": row.integration_state,
                "runnable_status": row.runnable_status,
                "model_category": row.model_category,
                "capability_tags": list(row.capability_tags),
                "native_equivalent": row.native_equivalent,
            }
            for row in list_external_model_records(runnable_only=True)
        )
    return items


def describe_external_model(name: str) -> dict[str, object]:
    record = resolve_external_model_record(name)
    if record is None:
        available = ", ".join(row.canonical_name for row in list_external_model_records()) or "<empty>"
        raise KeyError(f"Unknown external model '{name}'. Available: {available}")
    payload = record.to_dict()
    payload["name"] = record.canonical_name
    payload["kind"] = "model"
    payload["module"] = ""
    payload["qualname"] = record.display_name
    payload["doc"] = record.notes
    payload["source_path"] = record.repo_path
    payload["starter_config_paths"] = []
    payload["starter_config_count"] = 0
    payload["docs_path"] = None
    payload["docs_summary_excerpt"] = None
    payload["example_paths"] = []
    payload["accepts_var_keyword"] = True
    payload["signature"] = []
    payload["model_mode"] = "field" if record.is_operator_family else "pointwise"
    payload["supports_flattened_field"] = bool(record.is_operator_family)
    if record.adapter_name:
        from pinn_bench.models.external_adapters import get_external_adapter

        try:
            adapter = get_external_adapter(record.adapter_name)
        except KeyError:
            adapter = None
        if adapter is not None:
            payload["module"] = adapter.__class__.__module__
            payload["qualname"] = adapter.__class__.__qualname__
            payload["signature"] = adapter.signature_payload()
    return payload


def get_external_adapter_component(name: str) -> Any | None:
    record = resolve_external_model_record(name)
    if record is None or not record.adapter_name:
        return None
    from functools import partial
    from pinn_bench.models.external_adapters import get_external_adapter

    try:
        adapter = get_external_adapter(record.adapter_name)
    except KeyError:
        return None
    return partial(adapter.build_model, record=record)


def external_model_status_rows() -> list[dict[str, object]]:
    return [
        {
            "external_model_id": row.external_model_id,
            "source_benchmark": row.source_benchmark,
            "canonical_name": row.canonical_name,
            "category": row.model_category,
            "integration_state": row.integration_state,
            "adapter_name": row.adapter_name,
            "runnable_status": row.runnable_status,
            "native_equivalent": row.native_equivalent,
            "notes": row.notes,
        }
        for row in list_external_model_records()
    ]


def unified_model_universe_count() -> dict[str, int]:
    native_names = set(list_native_model_names())
    benchmark_native_count = sum(1 for name in _BENCHMARK_FACING_NATIVE_MODEL_NAMES if name in native_names)
    constructible_external_count = len(list_external_model_records(runnable_only=True))
    return {
        "native_model_count": benchmark_native_count,
        "external_model_count": len(list_external_model_records()),
        "constructible_external_model_count": constructible_external_count,
        "constructible_total_model_count": benchmark_native_count + constructible_external_count,
        "unified_total_model_count": benchmark_native_count + len(list_external_model_records()),
    }


__all__ = [
    "ExternalModelRecord",
    "INTEGRATION_STATE_ADAPTER_READY",
    "INTEGRATION_STATE_BLOCKED",
    "INTEGRATION_STATE_NATIVE",
    "INTEGRATION_STATE_REGISTRY_ONLY",
    "INTEGRATION_STATE_RUNNABLE",
    "ModelReferenceResolution",
    "RUNNABLE_STATUS_ADAPTER_READY",
    "RUNNABLE_STATUS_BLOCKED",
    "RUNNABLE_STATUS_EXTERNAL_CODE",
    "RUNNABLE_STATUS_NATIVE_PROXY",
    "RUNNABLE_STATUS_REGISTRY_ONLY",
    "build_external_model",
    "create_external_model",
    "describe_external_model",
    "external_model_status_rows",
    "get_external_model_record",
    "get_external_adapter_component",
    "list_constructible_model_names",
    "list_external_model_records",
    "list_external_model_names",
    "list_external_source_benchmarks",
    "list_native_model_names",
    "list_unified_model_entries",
    "normalize_model_name",
    "normalize_model_reference",
    "resolve_external_model_name",
    "resolve_external_model_record",
    "resolve_model_reference",
    "unified_model_universe_count",
]
