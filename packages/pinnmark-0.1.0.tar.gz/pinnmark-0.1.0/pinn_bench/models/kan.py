"""Lightweight native KAN model implementation."""

from __future__ import annotations

import math
from typing import Any

import torch
import torch.nn.functional as F
from torch import nn

from pinn_bench.models.base import BaseModel
from pinn_bench.registry import register_model


def _build_activation(name: str) -> nn.Module:
    activation_name = str(name).lower()
    activation_map = {
        "relu": nn.ReLU,
        "gelu": nn.GELU,
        "tanh": nn.Tanh,
        "silu": nn.SiLU,
    }
    if activation_name not in activation_map:
        supported = ", ".join(sorted(activation_map))
        raise ValueError(f"Unsupported activation '{name}'. Supported: {supported}")
    return activation_map[activation_name]()


class KANLinear(nn.Module):
    """Single lightweight KAN layer with a linear base path and spline path."""

    def __init__(
        self,
        in_features: int,
        out_features: int,
        *,
        grid_size: int = 5,
        spline_order: int = 3,
        base_activation: str = "silu",
        grid_range: list[float] | tuple[float, float] | None = None,
        bias: bool = True,
    ) -> None:
        super().__init__()
        if grid_size <= 0:
            raise ValueError("grid_size must be a positive integer.")
        if spline_order <= 0:
            raise ValueError("spline_order must be a positive integer.")

        if grid_range is None:
            grid_range = (-1.0, 1.0)
        if len(grid_range) != 2:
            raise ValueError("grid_range must contain exactly two numeric values.")
        grid_min = float(grid_range[0])
        grid_max = float(grid_range[1])
        if grid_min >= grid_max:
            raise ValueError("grid_range must be ordered as [min, max].")

        self.in_features = int(in_features)
        self.out_features = int(out_features)
        self.grid_size = int(grid_size)
        self.spline_order = int(spline_order)
        self.base_activation_name = str(base_activation)
        self.base_activation = _build_activation(self.base_activation_name)
        self.grid_range = [grid_min, grid_max]
        self.basis_size = self.grid_size + self.spline_order

        self.base_weight = nn.Parameter(torch.empty(self.out_features, self.in_features))
        self.base_bias = nn.Parameter(torch.empty(self.out_features)) if bias else None
        self.spline_weight = nn.Parameter(
            torch.empty(self.out_features, self.in_features, self.basis_size)
        )
        self.spline_scale = nn.Parameter(torch.ones(self.out_features, self.in_features))

        step = (grid_max - grid_min) / self.grid_size
        knots = torch.arange(
            -self.spline_order,
            self.grid_size + self.spline_order + 1,
            dtype=torch.float32,
        )
        grid = knots.mul(step).add(grid_min)
        self.register_buffer("grid", grid.unsqueeze(0).repeat(self.in_features, 1), persistent=False)
        self.reset_parameters()

    def reset_parameters(self) -> None:
        nn.init.xavier_uniform_(self.base_weight)
        if self.base_bias is not None:
            bound = 1.0 / math.sqrt(max(1, self.in_features))
            nn.init.uniform_(self.base_bias, -bound, bound)
        nn.init.uniform_(self.spline_weight, -0.01, 0.01)
        nn.init.ones_(self.spline_scale)

    def _project_inputs_to_grid(self, x: torch.Tensor) -> torch.Tensor:
        grid_min, grid_max = self.grid_range
        squashed = torch.tanh(x)
        projected = 0.5 * (squashed + 1.0) * (grid_max - grid_min) + grid_min
        epsilon = torch.finfo(projected.dtype).eps * max(1.0, abs(grid_min), abs(grid_max)) * 32.0
        return projected.clamp(min=grid_min, max=grid_max - epsilon)

    def _bspline_basis(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim != 2 or x.shape[-1] != self.in_features:
            raise ValueError(
                f"Expected inputs with shape (batch, {self.in_features}), got {tuple(x.shape)}."
            )

        projected = self._project_inputs_to_grid(x)
        grid = self.grid.to(device=projected.device, dtype=projected.dtype)
        expanded = projected.unsqueeze(-1)
        bases = ((expanded >= grid[:, :-1]) & (expanded < grid[:, 1:])).to(projected.dtype)

        for degree in range(1, self.spline_order + 1):
            left_den = grid[:, degree:-1] - grid[:, : -(degree + 1)]
            right_den = grid[:, degree + 1 :] - grid[:, 1:-degree]

            left = torch.where(
                left_den != 0,
                (expanded - grid[:, : -(degree + 1)]) / left_den,
                torch.zeros_like(expanded),
            )
            right = torch.where(
                right_den != 0,
                (grid[:, degree + 1 :] - expanded) / right_den,
                torch.zeros_like(expanded),
            )
            bases = left * bases[:, :, :-1] + right * bases[:, :, 1:]

        return bases.contiguous()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        base_output = F.linear(self.base_activation(x), self.base_weight, self.base_bias)
        spline_basis = self._bspline_basis(x).reshape(x.shape[0], -1)
        spline_weight = (self.spline_weight * self.spline_scale.unsqueeze(-1)).reshape(
            self.out_features, -1
        )
        spline_output = F.linear(spline_basis, spline_weight)
        return base_output + spline_output


@register_model("kan")
class KAN(BaseModel):
    """Benchmark-stable lightweight Kolmogorov-Arnold Network."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dims: list[int] | None = None,
        grid_size: int = 5,
        spline_order: int = 3,
        base_activation: str = "silu",
        grid_range: list[float] | tuple[float, float] | None = None,
        **_: Any,
    ) -> None:
        super().__init__()
        hidden_dims = hidden_dims or [64, 64, 64]
        layer_dims = [int(input_dim), *[int(dim) for dim in hidden_dims], int(output_dim)]

        self.input_dim = int(input_dim)
        self.output_dim = int(output_dim)
        self.hidden_dims = [int(dim) for dim in hidden_dims]
        self.grid_size = int(grid_size)
        self.spline_order = int(spline_order)
        self.base_activation_name = str(base_activation)
        self.grid_range = list(grid_range) if grid_range is not None else [-1.0, 1.0]

        self.network = nn.Sequential(
            *[
                KANLinear(
                    layer_dims[idx],
                    layer_dims[idx + 1],
                    grid_size=self.grid_size,
                    spline_order=self.spline_order,
                    base_activation=self.base_activation_name,
                    grid_range=self.grid_range,
                )
                for idx in range(len(layer_dims) - 1)
            ]
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)


KanModel = KAN

__all__ = ["KAN", "KANLinear", "KanModel"]
