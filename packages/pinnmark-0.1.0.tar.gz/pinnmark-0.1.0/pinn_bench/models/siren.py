"""SIREN model implementation."""

from __future__ import annotations

import math
from typing import Any

import torch
from torch import nn

from pinn_bench.models.base import BaseModel
from pinn_bench.registry import register_model


class SineLayer(nn.Module):
    """Linear layer followed by sine activation for SIREN networks."""

    def __init__(
        self,
        in_features: int,
        out_features: int,
        *,
        omega_0: float,
        is_first: bool = False,
        is_last: bool = False,
        bias: bool = True,
    ) -> None:
        super().__init__()
        self.in_features = int(in_features)
        self.out_features = int(out_features)
        self.omega_0 = float(omega_0)
        self.is_first = bool(is_first)
        self.is_last = bool(is_last)
        self.linear = nn.Linear(self.in_features, self.out_features, bias=bias)
        self.reset_parameters()

    def reset_parameters(self) -> None:
        if self.is_first:
            bound = 1.0 / self.in_features
        else:
            bound = math.sqrt(6.0 / self.in_features) / self.omega_0

        with torch.no_grad():
            self.linear.weight.uniform_(-bound, bound)
            if self.linear.bias is not None:
                self.linear.bias.uniform_(-bound, bound)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        activations = self.linear(x)
        if self.is_last:
            return activations
        return torch.sin(self.omega_0 * activations)


@register_model("siren")
class SIREN(BaseModel):
    """Sinusoidal representation network with paper-style initialization."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dims: list[int] | None = None,
        first_omega_0: float = 30.0,
        hidden_omega_0: float = 1.0,
        omega_0: float | None = None,
        **_: Any,
    ) -> None:
        super().__init__()
        hidden_dims = hidden_dims or [64, 64, 64]
        if not hidden_dims:
            raise ValueError("SIREN requires at least one hidden layer.")

        if omega_0 is not None and first_omega_0 == 30.0:
            first_omega_0 = float(omega_0)

        self.input_dim = int(input_dim)
        self.output_dim = int(output_dim)
        self.hidden_dims = [int(dim) for dim in hidden_dims]
        self.first_omega_0 = float(first_omega_0)
        self.hidden_omega_0 = float(hidden_omega_0)

        layers: list[nn.Module] = [
            SineLayer(
                self.input_dim,
                self.hidden_dims[0],
                omega_0=self.first_omega_0,
                is_first=True,
            )
        ]

        for in_features, out_features in zip(self.hidden_dims[:-1], self.hidden_dims[1:]):
            layers.append(
                SineLayer(
                    in_features,
                    out_features,
                    omega_0=self.hidden_omega_0,
                )
            )

        layers.append(
            SineLayer(
                self.hidden_dims[-1],
                self.output_dim,
                omega_0=self.hidden_omega_0,
                is_last=True,
            )
        )
        self.network = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)


SirenModel = SIREN

__all__ = ["SIREN", "SineLayer", "SirenModel"]
