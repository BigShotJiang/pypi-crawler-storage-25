"""Preview-scale Fourier-style operator baseline for v0.8-preview."""

from __future__ import annotations

from typing import Any

import torch
from torch import nn

from pinn_bench.models.base import BaseOperatorModel
from pinn_bench.registry import register_model


class SpectralMix2d(nn.Module):
    """Compact 2D spectral mixing layer used by MiniFNO."""

    def __init__(self, in_channels: int, out_channels: int, modes_x: int, modes_y: int) -> None:
        super().__init__()
        self.in_channels = int(in_channels)
        self.out_channels = int(out_channels)
        self.modes_x = int(modes_x)
        self.modes_y = int(modes_y)
        scale = 1.0 / max(1, in_channels * out_channels)
        self.weight = nn.Parameter(
            scale * torch.randn(self.in_channels, self.out_channels, self.modes_y, self.modes_x, dtype=torch.cfloat)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch_size, _channels, height, width = x.shape
        spectrum = torch.fft.rfft2(x, dim=(-2, -1), norm="ortho")
        out = torch.zeros(
            batch_size,
            self.out_channels,
            height,
            width // 2 + 1,
            device=x.device,
            dtype=torch.cfloat,
        )
        modes_y = min(self.modes_y, height)
        modes_x = min(self.modes_x, width // 2 + 1)
        out[:, :, :modes_y, :modes_x] = torch.einsum(
            "bcyx,coyx->boyx",
            spectrum[:, :, :modes_y, :modes_x],
            self.weight[:, :, :modes_y, :modes_x],
        )
        return torch.fft.irfft2(out, s=(height, width), dim=(-2, -1), norm="ortho")


class MiniFNOBlock(nn.Module):
    """One residual spectral mixing block."""

    def __init__(self, hidden_width: int, modes_x: int, modes_y: int, activation: nn.Module) -> None:
        super().__init__()
        self.spectral = SpectralMix2d(hidden_width, hidden_width, modes_x=modes_x, modes_y=modes_y)
        self.pointwise = nn.Conv2d(hidden_width, hidden_width, kernel_size=1)
        self.activation = activation

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.activation(self.spectral(x) + self.pointwise(x) + x)


@register_model("mini_fno")
class MiniFNO(BaseOperatorModel):
    """Preview-scale Fourier-style operator baseline over flattened field queries."""

    def __init__(
        self,
        query_dim: int = 2,
        condition_dim: int = 1,
        output_dim: int = 1,
        hidden_width: int = 32,
        num_layers: int = 2,
        spectral_modes_x: int = 8,
        spectral_modes_y: int = 8,
        activation: str = "gelu",
        **_: Any,
    ) -> None:
        super().__init__()
        self.query_dim = int(query_dim)
        self.condition_dim = int(condition_dim)
        self.output_dim = int(output_dim)
        self.hidden_width = int(hidden_width)
        self.num_layers = int(num_layers)
        self.spectral_modes_x = int(spectral_modes_x)
        self.spectral_modes_y = int(spectral_modes_y)
        activation_name = str(activation).lower()
        if activation_name == "gelu":
            self.activation = nn.GELU()
        elif activation_name == "relu":
            self.activation = nn.ReLU()
        elif activation_name == "tanh":
            self.activation = nn.Tanh()
        else:
            raise ValueError("MiniFNO activation must be one of: gelu, relu, tanh.")

        self.input_projection = nn.Linear(self.query_dim + self.condition_dim, self.hidden_width)
        self.blocks = nn.ModuleList(
            [
                MiniFNOBlock(
                    hidden_width=self.hidden_width,
                    modes_x=self.spectral_modes_x,
                    modes_y=self.spectral_modes_y,
                    activation=self.activation,
                )
                for _ in range(self.num_layers)
            ]
        )
        self.output_projection = nn.Sequential(
            nn.Conv2d(self.hidden_width, self.hidden_width, kernel_size=1),
            self.activation,
            nn.Conv2d(self.hidden_width, self.output_dim, kernel_size=1),
        )

    def _resolve_grid_shape(self, metadata: dict[str, Any] | None, query_inputs: torch.Tensor) -> tuple[int, ...]:
        if metadata is None or "grid_shape" not in metadata:
            raise ValueError("MiniFNO requires metadata['grid_shape'] for forward_field(...).")
        grid_shape = metadata.get("grid_shape")
        if not isinstance(grid_shape, (list, tuple)) or len(grid_shape) not in {2, 3}:
            raise ValueError("MiniFNO expects metadata['grid_shape'] to be a length-2 or length-3 sequence.")
        batch_size = int(metadata.get("family_batch_size", 1) or 1)
        if batch_size <= 0:
            raise ValueError("MiniFNO requires metadata['family_batch_size'] to be positive when provided.")
        resolved_grid_shape = tuple(int(value) for value in grid_shape)
        if any(value <= 0 for value in resolved_grid_shape):
            raise ValueError("MiniFNO requires positive grid dimensions in metadata['grid_shape'].")
        expected_points = batch_size
        for dim in resolved_grid_shape:
            expected_points *= dim
        if expected_points != int(query_inputs.shape[0]):
            raise ValueError(
                f"MiniFNO reshape mismatch: grid_shape {grid_shape} with family_batch_size {batch_size} implies "
                f"{expected_points} points but query_inputs has {query_inputs.shape[0]}."
            )
        return (batch_size, *resolved_grid_shape)

    def _resolve_condition_grid(
        self,
        condition_inputs: torch.Tensor | None,
        *,
        query_inputs: torch.Tensor,
        grid_shape: tuple[int, ...],
    ) -> torch.Tensor:
        batch_size = int(grid_shape[0])
        grid_dims = tuple(int(value) for value in grid_shape[1:])
        if self.condition_dim == 0:
            return torch.zeros((batch_size, *grid_dims, 0), device=query_inputs.device, dtype=query_inputs.dtype)
        if condition_inputs is None:
            base = torch.zeros((batch_size, self.condition_dim), device=query_inputs.device, dtype=query_inputs.dtype)
            return base[(slice(None), *([None] * len(grid_dims)), slice(None))].expand(batch_size, *grid_dims, self.condition_dim)
        condition_inputs = condition_inputs.to(device=query_inputs.device, dtype=query_inputs.dtype)
        if condition_inputs.ndim == 1:
            condition_inputs = condition_inputs.unsqueeze(0)
        if condition_inputs.shape[1] != self.condition_dim:
            raise ValueError(
                f"Condition feature dimension {condition_inputs.shape[1]} does not match expected {self.condition_dim}."
            )
        if condition_inputs.shape[0] == 1:
            return condition_inputs[(slice(None), *([None] * len(grid_dims)), slice(None))].expand(
                batch_size,
                *grid_dims,
                self.condition_dim,
            )
        if condition_inputs.shape[0] == batch_size:
            return condition_inputs[(slice(None), *([None] * len(grid_dims)), slice(None))].expand(
                batch_size,
                *grid_dims,
                self.condition_dim,
            )
        if condition_inputs.shape[0] == query_inputs.shape[0]:
            return condition_inputs.reshape(batch_size, *grid_dims, self.condition_dim)
        raise ValueError(
            f"Condition batch shape {tuple(condition_inputs.shape)} is incompatible with query batch shape {tuple(query_inputs.shape)}."
        )

    def forward_field(
        self,
        condition_inputs: torch.Tensor | None,
        query_inputs: torch.Tensor | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> torch.Tensor:
        if query_inputs is None:
            raise ValueError("MiniFNO requires query_inputs for forward_field(...).")
        if query_inputs.ndim != 2 or query_inputs.shape[1] != self.query_dim:
            raise ValueError(
                f"MiniFNO expected query_inputs shape (*, {self.query_dim}); got {tuple(query_inputs.shape)}."
            )
        resolved_grid_shape = self._resolve_grid_shape(metadata, query_inputs)
        batch_size = int(resolved_grid_shape[0])
        grid_dims = tuple(int(value) for value in resolved_grid_shape[1:])
        query_grid = query_inputs.reshape(batch_size, *grid_dims, self.query_dim)
        condition_grid = self._resolve_condition_grid(
            condition_inputs,
            query_inputs=query_inputs,
            grid_shape=resolved_grid_shape,
        )
        features = torch.cat([query_grid, condition_grid], dim=-1)
        if len(grid_dims) == 2:
            height, width = grid_dims
            lifted = self.input_projection(features)
            x = lifted.permute(0, 3, 1, 2)
            for block in self.blocks:
                x = block(x)
            outputs = self.output_projection(x)
            return outputs.permute(0, 2, 3, 1).reshape(batch_size * height * width, self.output_dim)
        rollout_steps, height, width = grid_dims
        lifted = self.input_projection(features).reshape(batch_size * rollout_steps, height, width, self.hidden_width)
        x = lifted.permute(0, 3, 1, 2)
        for block in self.blocks:
            x = block(x)
        outputs = self.output_projection(x)
        return outputs.permute(0, 2, 3, 1).reshape(batch_size * rollout_steps * height * width, self.output_dim)
