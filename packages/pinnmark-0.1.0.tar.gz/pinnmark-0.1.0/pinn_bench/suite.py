"""Unified suite-level Python object layer."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from html import escape
from pathlib import Path
from typing import Any

from pinn_bench.suite_frontdoor import (
    default_launch_manifest_path,
    get_suite_entry,
    inspect_suite_summary,
    list_suites,
    run_suite,
)
from pinn_bench.suite_models import (
    SuiteClaim,
    SuiteFigure,
    SuiteKeyFiles,
    SuiteRunResult,
    SuiteSummary,
)


@dataclass(frozen=True)
class SuiteCatalogEntry:
    """Human-facing suite catalog row."""

    suite_name: str
    phase: int
    runner_type: str
    depends_on: str
    launch_results_root: str
    default_results_root: str
    manifest_path: str
    runbook_path: str
    gate_spec_path: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "suite_name": self.suite_name,
            "phase": self.phase,
            "runner_type": self.runner_type,
            "depends_on": self.depends_on,
            "launch_results_root": self.launch_results_root,
            "default_results_root": self.default_results_root,
            "manifest_path": self.manifest_path,
            "runbook_path": self.runbook_path,
            "gate_spec_path": self.gate_spec_path,
        }


class Suite:
    """Thin sklearn-like suite object over the existing NeurIPS 2026 execution system."""

    def __init__(self, *, suite_name: str, launch_manifest_path: str | Path | None = None) -> None:
        self._entry = get_suite_entry(suite_name, launch_manifest_path=launch_manifest_path)
        self._launch_manifest_path = (
            default_launch_manifest_path() if launch_manifest_path is None else Path(str(launch_manifest_path)).resolve()
        )
        self._last_results_root: Path | None = None

    def __repr__(self) -> str:
        return (
            "Suite("
            f"suite_name={self.name!r}, phase={self.phase!r}, runner_type={self.runner_type!r}, "
            f"launch_manifest_path={str(self._launch_manifest_path)!r})"
        )

    def _repr_html_(self) -> str:
        rows = [
            ("suite_name", self.name),
            ("phase", self.phase),
            ("runner_type", self.runner_type),
            ("depends_on", self.depends_on),
            ("launch_manifest_path", str(self._launch_manifest_path)),
        ]
        html_rows = "".join(
            f"<tr><th>{escape(str(key))}</th><td><code>{escape(str(value))}</code></td></tr>"
            for key, value in rows
        )
        return f"<div><strong>Suite</strong><table>{html_rows}</table></div>"

    @property
    def name(self) -> str:
        return self._entry.suite_name

    @property
    def phase(self) -> int:
        return self._entry.phase

    @property
    def runner_type(self) -> str:
        return self._entry.runner_type

    @property
    def depends_on(self) -> str:
        return self._entry.depends_on

    @classmethod
    def list(cls, launch_manifest_path: str | Path | None = None) -> list[str]:
        """Return the stable suite names."""
        return [entry["suite_name"] for entry in list_suites(launch_manifest_path)]

    @classmethod
    def catalog(cls, launch_manifest_path: str | Path | None = None) -> list[SuiteCatalogEntry]:
        """Return the suite catalog with runner and path information."""
        return [SuiteCatalogEntry(**entry) for entry in list_suites(launch_manifest_path)]

    @classmethod
    def load(cls, suite_name: str, launch_manifest_path: str | Path | None = None) -> "Suite":
        """Load one suite object by stable suite name."""
        return cls(suite_name=suite_name, launch_manifest_path=launch_manifest_path)

    def run(
        self,
        *,
        results_root: str | Path | None = None,
        use_launch_root: bool = False,
        family_ids: Sequence[str] | None = None,
        seeds: Sequence[int] | None = None,
        max_runs: int | None = None,
        skip_existing: bool = True,
        dry_run: bool = False,
    ) -> SuiteRunResult:
        """Run this suite through the unified front door."""
        result = run_suite(
            suite_name=self.name,
            launch_manifest_path=self._launch_manifest_path,
            results_root=results_root,
            use_launch_root=use_launch_root,
            family_ids=family_ids,
            seeds=seeds,
            max_runs=max_runs,
            skip_existing=skip_existing,
            dry_run=dry_run,
        )
        self._last_results_root = Path(result.results_root).resolve()
        return result

    def summary(
        self,
        *,
        results_root: str | Path | None = None,
        use_launch_root: bool = False,
    ) -> SuiteSummary:
        """Return the unified structured summary for this suite."""
        resolved_results_root = results_root
        if resolved_results_root is None and not use_launch_root and self._last_results_root is not None:
            resolved_results_root = self._last_results_root
        return inspect_suite_summary(
            suite_name=self.name,
            launch_manifest_path=self._launch_manifest_path,
            results_root=resolved_results_root,
            use_launch_root=use_launch_root,
        )

    def inspect(
        self,
        *,
        results_root: str | Path | None = None,
        use_launch_root: bool = False,
    ) -> SuiteSummary:
        """Alias for summary()."""
        return self.summary(results_root=results_root, use_launch_root=use_launch_root)

    def figures(
        self,
        *,
        results_root: str | Path | None = None,
        use_launch_root: bool = False,
    ) -> list[SuiteFigure]:
        """Return normalized figure records for this suite."""
        return list(self.summary(results_root=results_root, use_launch_root=use_launch_root).figures)

    def claims(
        self,
        *,
        results_root: str | Path | None = None,
        use_launch_root: bool = False,
    ) -> list[SuiteClaim]:
        """Return normalized claim records for this suite."""
        return list(self.summary(results_root=results_root, use_launch_root=use_launch_root).claims)

    def key_files(
        self,
        *,
        results_root: str | Path | None = None,
        use_launch_root: bool = False,
    ) -> SuiteKeyFiles:
        """Return the most important suite file paths."""
        return self.summary(results_root=results_root, use_launch_root=use_launch_root).key_files

    def warnings(
        self,
        *,
        results_root: str | Path | None = None,
        use_launch_root: bool = False,
    ) -> tuple[str, ...]:
        """Return warnings emitted by the suite truth layer."""
        return self.summary(results_root=results_root, use_launch_root=use_launch_root).warning_messages()

    def main_text_candidates(
        self,
        *,
        results_root: str | Path | None = None,
        use_launch_root: bool = False,
    ) -> list[str]:
        """Return main-text candidate suite/figure ids."""
        return self.summary(results_root=results_root, use_launch_root=use_launch_root).main_text_candidates()
