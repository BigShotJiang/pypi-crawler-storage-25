"""Path utilities."""

from __future__ import annotations

from pathlib import Path


def ensure_output_dir(root_dir: str | Path) -> Path:
    """Create and return output directory path."""
    path = Path(root_dir)
    path.mkdir(parents=True, exist_ok=True)
    return path

