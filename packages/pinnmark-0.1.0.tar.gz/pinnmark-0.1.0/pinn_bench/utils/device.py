"""Device selection helpers."""

from __future__ import annotations

import torch


def resolve_device(requested: str | None = None) -> torch.device:
    """Resolve runtime device with safe fallback to CPU."""
    if requested is None:
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")

    candidate = requested.lower()
    if candidate.startswith("cuda") and not torch.cuda.is_available():
        return torch.device("cpu")
    return torch.device(candidate)

