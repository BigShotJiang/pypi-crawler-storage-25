"""Contracts for the v3.0-preview super-benchmark registry layer."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


SUPERBENCH_PREVIEW_LINE = "v3.0-preview"
SOURCE_RECORD_SCHEMA_VERSION = "superbench.source_record.v0.1"
REGISTRY_BUNDLE_SCHEMA_VERSION = "superbench.registry_bundle.v0.1"
REGISTRY_VIEW_SCHEMA_VERSION = "superbench.registry_view.v0.1"
SOURCE_REGISTRY_SCHEMA_VERSION = "superbench.source_registry.v0.1"
RERUN_EXECUTION_SCHEMA_VERSION = "superbench.rerun_execution.v0.1"
DOMAIN_REGISTRY_SCHEMA_VERSION = "superbench.domain_registry.v0.1"
MATURITY_BOARD_SCHEMA_VERSION = "superbench.maturity_board.v0.1"
TRANCHE_MANIFEST_SCHEMA_VERSION = "superbench.tranche_manifest.v0.1"
TRANCHE_EXECUTION_SCHEMA_VERSION = "superbench.tranche_execution.v0.1"

NATIVE_RERUN_REQUIRED_FIELDS = (
    "native_task_name",
    "native_model_name",
    "native_config_template",
    "native_config_output",
    "run_output_dir",
    "bundle_output_path",
    "rerun_provenance_output",
    "bridge_target",
    "admission_expectation",
    "preflight_requirements",
    "staging_reason_codes",
)

ALLOWED_NATIVE_RERUN_BRIDGE_TARGETS = {
    "official_cohort",
    "staging_registry",
}

ALLOWED_NATIVE_RERUN_ADMISSION_EXPECTATIONS = {
    "must_officialize",
    "must_stage",
}

SUPERBENCH_SUBMISSION_OPTIONAL_FIELDS: dict[str, type] = {
    "source_benchmark_id": str,
    "source_benchmark_version": str,
    "source_adapter_version": str,
    "canonical_task_id": str,
    "metric_id": str,
    "artifact_evidence_tier": str,
    "rerun_provenance_id": str,
    "cohort_id": str,
    "bridge_status": str,
}

CANONICAL_COHORT_FIELDS = (
    "canonical_task_id",
    "observation_surface",
    "target_surface",
    "evaluation_mode",
    "protocol_family",
    "severity_level",
    "metric_id",
)

OFFICIAL_REQUIRED_ENTRY_FIELDS = (
    "canonical_task_id",
    "observation_surface",
    "target_surface",
    "evaluation_mode",
    "protocol_family",
    "severity_level",
    "metric_id",
    "artifact_evidence_tier",
    "rerun_provenance_id",
    "cohort_id",
    "bridge_status",
    "metric_value",
    "native_config_path",
    "artifact_bundle_path",
    "rerun_provenance_path",
)

REQUIRED_ABSORPTION_PACK_FIELDS = (
    "native_task_pack",
    "native_model_pack",
    "metric_mapping",
    "config_templates",
    "dataset_manifest",
    "rerun_recipe",
)

ALLOWED_SOURCE_ARTIFACT_KINDS = {
    "repo_run",
    "benchmark_output",
    "paper_table",
    "notebook_output",
    "published_benchmark_page",
    "workflow_replay",
    "historical_output",
    "domain_pack",
}

ALLOWED_DOMAIN_FAMILIES = {
    "pinn",
    "operator_learning",
    "surrogate_modeling",
    "equation_solver",
    "inverse_problem",
    "ude",
    "other_sciml",
}

ALLOWED_ARTIFACT_EVIDENCE_TIERS = {
    "controlled_rerun",
    "partial_rerun",
    "paper_table_only",
    "repo_summary_only",
    "published_page_only",
    "notebook_output_only",
}

ALLOWED_BRIDGE_STATUSES = {
    "cohort_bridge_complete",
    "cohort_bridge_partial",
    "no_native_bridge",
    "source_evidence_only",
}

SOURCE_ONLY_EVIDENCE_TIERS = {
    "paper_table_only",
    "repo_summary_only",
    "published_page_only",
    "notebook_output_only",
}

CONTROLLED_RERUN_EVIDENCE_TIER = "controlled_rerun"
OFFICIAL_BRIDGE_STATUS = "cohort_bridge_complete"


def _clean_text(value: Any) -> str:
    return str(value or "").strip()


def derive_cohort_id(payload: Mapping[str, Any]) -> str:
    """Build a canonical cohort id from the official grouping fields."""
    return "|".join(f"{field}={_clean_text(payload.get(field))}" for field in CANONICAL_COHORT_FIELDS)


def normalize_reason_codes(values: Any) -> list[str]:
    if not isinstance(values, list):
        return []
    seen: set[str] = set()
    normalized: list[str] = []
    for item in values:
        text = _clean_text(item)
        if not text or text in seen:
            continue
        seen.add(text)
        normalized.append(text)
    return normalized


__all__ = [
    "ALLOWED_ARTIFACT_EVIDENCE_TIERS",
    "ALLOWED_BRIDGE_STATUSES",
    "ALLOWED_DOMAIN_FAMILIES",
    "ALLOWED_SOURCE_ARTIFACT_KINDS",
    "CANONICAL_COHORT_FIELDS",
    "CONTROLLED_RERUN_EVIDENCE_TIER",
    "DOMAIN_REGISTRY_SCHEMA_VERSION",
    "OFFICIAL_BRIDGE_STATUS",
    "OFFICIAL_REQUIRED_ENTRY_FIELDS",
    "MATURITY_BOARD_SCHEMA_VERSION",
    "RERUN_EXECUTION_SCHEMA_VERSION",
    "REGISTRY_BUNDLE_SCHEMA_VERSION",
    "REGISTRY_VIEW_SCHEMA_VERSION",
    "NATIVE_RERUN_REQUIRED_FIELDS",
    "ALLOWED_NATIVE_RERUN_BRIDGE_TARGETS",
    "ALLOWED_NATIVE_RERUN_ADMISSION_EXPECTATIONS",
    "REQUIRED_ABSORPTION_PACK_FIELDS",
    "SOURCE_ONLY_EVIDENCE_TIERS",
    "SOURCE_RECORD_SCHEMA_VERSION",
    "SOURCE_REGISTRY_SCHEMA_VERSION",
    "SUPERBENCH_PREVIEW_LINE",
    "SUPERBENCH_SUBMISSION_OPTIONAL_FIELDS",
    "TRANCHE_EXECUTION_SCHEMA_VERSION",
    "TRANCHE_MANIFEST_SCHEMA_VERSION",
    "derive_cohort_id",
    "normalize_reason_codes",
]
