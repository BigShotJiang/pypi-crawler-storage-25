"""Native rerun orchestration for v3.0-preview super-benchmark entries."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

import pinn_bench.metrics  # noqa: F401
import pinn_bench.models  # noqa: F401
import pinn_bench.tasks  # noqa: F401
from pinn_bench.community.bundle import copy_bundle_artifacts
from pinn_bench.community.compare_bundle import build_bundle_comparison_payload
from pinn_bench.community.import_bundle import import_bundle
from pinn_bench.community.validate_submission import build_submission_validation_payload
from pinn_bench.config.loader import load_config
from pinn_bench.registry import list_models, list_tasks
from pinn_bench.resources import resolve_manifest_path, resolve_repo_root
from pinn_bench.run import run_experiment_cli
from pinn_bench.superbench.contracts import (
    OFFICIAL_BRIDGE_STATUS,
    RERUN_EXECUTION_SCHEMA_VERSION,
    SUPERBENCH_PREVIEW_LINE,
    derive_cohort_id,
    normalize_reason_codes,
)
from pinn_bench.superbench.registry import write_superbench_registry


_COMPARISON_TARGETS: tuple[tuple[str, str, str], ...] = (
    ("v1.0", "outputs_v10", "baseline_v1_0_formal.yaml"),
    ("v1.6-preview", "outputs_preview_v16", "baseline_v1_6_preview.yaml"),
    ("v0.6", "outputs_v06", "baseline_v0_6.yaml"),
    ("v0.5", "outputs_v05", "baseline_v0_5.yaml"),
    ("v0.4", "outputs_v04", "baseline_v0_4.yaml"),
    ("v0.3", "outputs_v03", "baseline_v0_3.yaml"),
)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError(f"Expected a JSON object in {path}.")
    return dict(payload)


def _write_json(path: Path, payload: Mapping[str, Any]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return path


def _load_yaml(path: Path) -> dict[str, Any]:
    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError(f"Expected a YAML mapping in {path}.")
    return dict(payload)


def _write_yaml(path: Path, payload: Mapping[str, Any]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        yaml.safe_dump(dict(payload), handle, sort_keys=False)
    return path


def _source_root_for_record(record_path: Path) -> Path:
    parent = record_path.resolve().parent
    candidate = parent.parent
    if candidate != parent and list(candidate.glob("*/source_record.json")):
        return candidate
    return parent


def _render_path_for_record(path: Path, *, record_path: Path) -> str:
    resolved = path.resolve()
    base = record_path.resolve().parent
    try:
        return str(resolved.relative_to(base))
    except ValueError:
        return str(resolved)


def _resolve_path(*, raw: str, base_root: Path) -> Path:
    candidate = Path(str(raw)).expanduser()
    if not candidate.is_absolute():
        candidate = (base_root / candidate).resolve()
    return candidate


def _load_source_record(record_path: Path) -> dict[str, Any]:
    payload = _load_json(record_path)
    entries = payload.get("entries")
    if not isinstance(entries, list):
        raise ValueError(f"{record_path} is missing an entries list.")
    return payload


def _write_source_record(record_path: Path, payload: Mapping[str, Any]) -> Path:
    return _write_json(record_path, payload)


def _find_entry(payload: Mapping[str, Any], *, entry_id: str) -> tuple[int, dict[str, Any]]:
    entries = payload.get("entries")
    if not isinstance(entries, list):
        raise ValueError("source_record entries must be a list.")
    for index, entry in enumerate(entries):
        if isinstance(entry, Mapping) and str(entry.get("entry_id") or "").strip() == entry_id:
            return index, dict(entry)
    raise ValueError(f"Entry '{entry_id}' was not found in the source record.")


def _require_native_rerun(entry: Mapping[str, Any], *, entry_id: str) -> dict[str, Any]:
    native_rerun = entry.get("native_rerun")
    if not isinstance(native_rerun, Mapping):
        raise ValueError(f"Entry '{entry_id}' is missing native_rerun.")
    return dict(native_rerun)


def _load_manifest_tasks(manifest_name: str) -> set[str]:
    manifest_path = resolve_manifest_path(manifest_name)
    payload = _load_yaml(manifest_path)
    runs = payload.get("runs") if isinstance(payload.get("runs"), list) else []
    tasks: set[str] = set()
    for run in runs:
        if isinstance(run, Mapping):
            task_name = str(run.get("task_name") or "").strip()
            if task_name:
                tasks.add(task_name)
    return tasks


def _resolve_comparison_target(*, task_name: str) -> dict[str, str]:
    repo_root = resolve_repo_root()
    for benchmark_line, outputs_root_name, manifest_name in _COMPARISON_TARGETS:
        if task_name not in _load_manifest_tasks(manifest_name):
            continue
        grouped_json = repo_root / outputs_root_name / "_leaderboard" / "leaderboard_grouped.json"
        if not grouped_json.exists():
            continue
        return {
            "benchmark_line": benchmark_line,
            "manifest_path": str(resolve_manifest_path(manifest_name).resolve()),
            "grouped_json": str(grouped_json.resolve()),
        }
    raise ValueError(f"No compatible grouped leaderboard target was found for native task '{task_name}'.")


def _bundle_dir_from_summary_path(summary_path: Path) -> Path:
    if summary_path.suffix == ".json":
        return summary_path.with_suffix("")
    return summary_path / "bundle"


def _import_dir_from_summary_path(summary_path: Path) -> Path:
    imports_root = summary_path.resolve().parent.parent / "imports"
    return imports_root / summary_path.stem


def _extract_metric_value(*, metrics_path: Path, metric_id: str) -> float:
    metrics_payload = _load_json(metrics_path)
    eval_payload = metrics_payload.get("eval")
    if not isinstance(eval_payload, Mapping) or metric_id not in eval_payload:
        raise ValueError(f"metrics.json at {metrics_path} does not contain eval.{metric_id}.")
    return float(eval_payload[metric_id])


def _resolve_reason_codes(*, entry: Mapping[str, Any], native_rerun: Mapping[str, Any], additional: Sequence[str] | None = None) -> list[str]:
    codes = normalize_reason_codes(entry.get("reason_codes"))
    codes.extend(normalize_reason_codes(native_rerun.get("staging_reason_codes")))
    if additional:
        codes.extend(normalize_reason_codes(list(additional)))
    return normalize_reason_codes(codes)


def _materialize_config(
    *,
    template_path: Path,
    output_path: Path,
    run_output_dir: Path,
) -> Path:
    payload = _load_yaml(template_path)
    output_payload = payload.get("output")
    if not isinstance(output_payload, Mapping):
        raise ValueError(f"Config template {template_path} must contain an output mapping.")
    rendered = deepcopy(payload)
    task_payload = rendered.get("task")
    if isinstance(task_payload, Mapping):
        task_params = task_payload.get("params")
        if isinstance(task_params, Mapping):
            dataset_root = str(task_params.get("dataset_root") or "").strip()
            if dataset_root:
                candidate = Path(dataset_root).expanduser()
                if not candidate.is_absolute():
                    resolved_dataset_root = (template_path.parent / candidate).resolve()
                    rendered_task = dict(task_payload)
                    rendered_task_params = dict(task_params)
                    rendered_task_params["dataset_root"] = str(resolved_dataset_root)
                    rendered_task["params"] = rendered_task_params
                    rendered["task"] = rendered_task
    rendered_output = dict(rendered["output"])
    rendered_output["root_dir"] = str(run_output_dir.resolve())
    rendered["output"] = rendered_output
    return _write_yaml(output_path, rendered)


def _run_native_config(config_path: Path) -> Path:
    config = load_config(config_path)
    run_experiment_cli(["--config", str(config_path), "--output-dir", config.output.root_dir])
    return Path(config.output.root_dir).resolve()


def _preflight_failures(*, entry: Mapping[str, Any], native_rerun: Mapping[str, Any], workspace_root: Path) -> list[str]:
    failures: list[str] = []
    registered_tasks = set(list_tasks())
    registered_models = set(list_models())
    for requirement in native_rerun.get("preflight_requirements", []):
        prefix, _, value = str(requirement).partition(":")
        target = value.strip()
        if prefix == "native_task_registered":
            if target not in registered_tasks:
                failures.append(f"missing_native_task:{target}")
        elif prefix == "native_model_registered":
            if target not in registered_models:
                failures.append(f"missing_native_model:{target}")
        elif prefix == "local_path_exists":
            candidate = _resolve_path(raw=target, base_root=workspace_root)
            if not candidate.exists():
                failures.append(f"missing_local_path:{target}")
        else:
            failures.append(f"unsupported_preflight_requirement:{requirement}")
    return normalize_reason_codes(failures)


def _write_bundle_summary(
    *,
    summary_path: Path,
    entry: Mapping[str, Any],
    bundle_dir: Path | None,
    import_dir: Path | None,
    status: str,
    metric_value: float | None,
    validation_payload: Mapping[str, Any] | None,
    comparison_payload: Mapping[str, Any] | None,
    reason_codes: Sequence[str],
) -> Path:
    payload: dict[str, Any] = {
        "schema_version": "superbench.bundle_capture.v0.1",
        "preview_line": SUPERBENCH_PREVIEW_LINE,
        "entry_id": str(entry.get("entry_id") or ""),
        "source_benchmark_id": str(entry.get("source_benchmark_id") or ""),
        "status": status,
        "bundle_dir": None if bundle_dir is None else str(bundle_dir.resolve()),
        "import_dir": None if import_dir is None else str(import_dir.resolve()),
        "metric_value": metric_value,
        "reason_codes": list(reason_codes),
    }
    if validation_payload is not None:
        payload["validation_status"] = validation_payload.get("status")
        payload["compatibility_status"] = validation_payload.get("compatibility", {}).get("status")
    if comparison_payload is not None:
        payload["comparison_disposition"] = comparison_payload.get("admission_disposition")
        payload["comparison_strength"] = comparison_payload.get("comparison_strength")
    return _write_json(summary_path, payload)


def _write_rerun_provenance(
    *,
    provenance_path: Path,
    entry: Mapping[str, Any],
    native_rerun: Mapping[str, Any],
    native_config_output: Path,
    run_output_dir: Path,
    bundle_summary_path: Path,
    bundle_dir: Path | None,
    import_dir: Path | None,
    comparison_target: Mapping[str, Any] | None,
    metric_value: float | None,
    status: str,
    reason_codes: Sequence[str],
) -> Path:
    payload = {
        "schema_version": RERUN_EXECUTION_SCHEMA_VERSION,
        "preview_line": SUPERBENCH_PREVIEW_LINE,
        "generated_at": _utc_now(),
        "status": status,
        "entry_id": str(entry.get("entry_id") or ""),
        "source_benchmark_id": str(entry.get("source_benchmark_id") or ""),
        "source_benchmark_version": str(entry.get("source_benchmark_version") or ""),
        "source_adapter_version": str(entry.get("source_adapter_version") or ""),
        "rerun_provenance_id": str(entry.get("rerun_provenance_id") or ""),
        "native_task_name": str(native_rerun.get("native_task_name") or ""),
        "native_model_name": str(native_rerun.get("native_model_name") or ""),
        "native_config_template": str(native_rerun.get("native_config_template") or ""),
        "native_config_output": str(native_config_output.resolve()),
        "run_output_dir": str(run_output_dir.resolve()),
        "bundle_summary_path": str(bundle_summary_path.resolve()),
        "bundle_dir": None if bundle_dir is None else str(bundle_dir.resolve()),
        "import_dir": None if import_dir is None else str(import_dir.resolve()),
        "metric_id": str(entry.get("metric_id") or ""),
        "metric_value": metric_value,
        "comparison_target": None if comparison_target is None else dict(comparison_target),
        "bridge_target": str(native_rerun.get("bridge_target") or ""),
        "admission_expectation": str(native_rerun.get("admission_expectation") or ""),
        "reason_codes": list(reason_codes),
    }
    return _write_json(provenance_path, payload)


def _submission_overrides_for_entry(entry: Mapping[str, Any], *, benchmark_line: str) -> dict[str, Any]:
    return {
        "benchmark_line": benchmark_line,
        "compatibility_target": benchmark_line,
        "benchmark_manifest": None,
        "source_type": "external",
        "source_benchmark_id": entry.get("source_benchmark_id"),
        "source_benchmark_version": entry.get("source_benchmark_version"),
        "source_adapter_version": entry.get("source_adapter_version"),
        "canonical_task_id": entry.get("canonical_task_id"),
        "metric_id": entry.get("metric_id"),
        "artifact_evidence_tier": entry.get("artifact_evidence_tier"),
        "rerun_provenance_id": entry.get("rerun_provenance_id"),
        "cohort_id": entry.get("cohort_id"),
        "bridge_status": entry.get("bridge_status"),
    }


def orchestrate_superbench_rerun_entry(
    *,
    source_record: Path,
    entry_id: str,
    registry_root: Path,
    workspace_root: Path,
    mode: str = "auto",
) -> dict[str, Any]:
    if mode != "auto":
        raise ValueError("Only --mode auto is currently supported.")

    record_path = source_record.resolve()
    workspace_root = workspace_root.resolve()
    registry_root = registry_root.resolve()
    payload = _load_source_record(record_path)
    entry_index, entry = _find_entry(payload, entry_id=entry_id)
    entry["source_benchmark_id"] = str(payload.get("source_benchmark_id") or "")
    entry["source_benchmark_version"] = str(payload.get("source_benchmark_version") or "")
    entry["source_adapter_version"] = str(payload.get("source_adapter_version") or "")
    native_rerun = _require_native_rerun(entry, entry_id=entry_id)

    template_path = _resolve_path(raw=str(native_rerun["native_config_template"]), base_root=record_path.parent)
    native_config_output = _resolve_path(raw=str(native_rerun["native_config_output"]), base_root=workspace_root)
    run_output_dir = _resolve_path(raw=str(native_rerun["run_output_dir"]), base_root=workspace_root)
    bundle_summary_path = _resolve_path(raw=str(native_rerun["bundle_output_path"]), base_root=workspace_root)
    rerun_provenance_path = _resolve_path(raw=str(native_rerun["rerun_provenance_output"]), base_root=workspace_root)
    bundle_dir = _bundle_dir_from_summary_path(bundle_summary_path)
    import_dir = _import_dir_from_summary_path(bundle_summary_path)

    rendered_config_path = _materialize_config(
        template_path=template_path,
        output_path=native_config_output,
        run_output_dir=run_output_dir,
    )

    bridge_target = str(native_rerun.get("bridge_target") or "").strip()
    comparison_target: dict[str, Any] | None = None
    validation_payload: dict[str, Any] | None = None
    comparison_payload: dict[str, Any] | None = None
    metric_value: float | None = None
    status = "completed"
    reason_codes = normalize_reason_codes(entry.get("reason_codes"))

    if bridge_target == "official_cohort":
        comparison_target = _resolve_comparison_target(task_name=str(native_rerun.get("native_task_name") or ""))
        run_dir = _run_native_config(rendered_config_path)
        copy_bundle_artifacts(
            run_dir=run_dir,
            output_dir=bundle_dir,
            compatibility_target=str(comparison_target["benchmark_line"]),
            submission_overrides=_submission_overrides_for_entry(entry, benchmark_line=str(comparison_target["benchmark_line"])),
        )
        validation_payload = build_submission_validation_payload(
            bundle_dir,
            against_benchmark_line=str(comparison_target["benchmark_line"]),
            against_manifest=str(comparison_target["manifest_path"]),
            profile="external",
        )
        comparison_payload = build_bundle_comparison_payload(
            bundle_dir,
            Path(str(comparison_target["grouped_json"])),
            against_benchmark_line=str(comparison_target["benchmark_line"]),
        )
        import_bundle(
            bundle_dir,
            grouped_json=Path(str(comparison_target["grouped_json"])),
            output_dir=import_dir,
            against_benchmark_line=str(comparison_target["benchmark_line"]),
        )
        metric_value = _extract_metric_value(metrics_path=run_dir / "metrics.json", metric_id=str(entry.get("metric_id") or "relative_l2"))
        reason_codes = []
    else:
        preflight_failures = _preflight_failures(entry=entry, native_rerun=native_rerun, workspace_root=workspace_root)
        if preflight_failures:
            status = "staged_preflight_blocked"
            reason_codes = _resolve_reason_codes(
                entry=entry,
                native_rerun=native_rerun,
                additional=preflight_failures,
            )
        else:
            run_dir = _run_native_config(rendered_config_path)
            metric_value = _extract_metric_value(
                metrics_path=run_dir / "metrics.json",
                metric_id=str(entry.get("metric_id") or "relative_l2"),
            )
            status = "staged_ready"
            reason_codes = _resolve_reason_codes(
                entry=entry,
                native_rerun=native_rerun,
                additional=[],
            )

    bundle_summary = _write_bundle_summary(
        summary_path=bundle_summary_path,
        entry=entry,
        bundle_dir=bundle_dir if bridge_target == "official_cohort" else None,
        import_dir=import_dir if bridge_target == "official_cohort" else None,
        status=status,
        metric_value=metric_value,
        validation_payload=validation_payload,
        comparison_payload=comparison_payload,
        reason_codes=reason_codes,
    )
    rerun_provenance = _write_rerun_provenance(
        provenance_path=rerun_provenance_path,
        entry=entry,
        native_rerun=native_rerun,
        native_config_output=rendered_config_path,
        run_output_dir=run_output_dir,
        bundle_summary_path=bundle_summary,
        bundle_dir=bundle_dir if bridge_target == "official_cohort" else None,
        import_dir=import_dir if bridge_target == "official_cohort" else None,
        comparison_target=comparison_target,
        metric_value=metric_value,
        status=status,
        reason_codes=reason_codes,
    )

    updated_entry = dict(entry)
    updated_entry["native_config_path"] = _render_path_for_record(rendered_config_path, record_path=record_path)
    updated_entry["artifact_bundle_path"] = _render_path_for_record(bundle_summary, record_path=record_path)
    updated_entry["rerun_provenance_path"] = _render_path_for_record(rerun_provenance, record_path=record_path)
    updated_entry["cohort_id"] = str(updated_entry.get("cohort_id") or derive_cohort_id(updated_entry))
    updated_entry["reason_codes"] = reason_codes
    if metric_value is not None:
        updated_entry["metric_value"] = metric_value
    elif bridge_target != "official_cohort":
        updated_entry["metric_value"] = None
    if bridge_target != "official_cohort":
        updated_entry["bridge_status"] = "cohort_bridge_partial"

    entries = payload.get("entries")
    assert isinstance(entries, list)
    entries[entry_index] = updated_entry
    _write_source_record(record_path, payload)

    source_root = _source_root_for_record(record_path)
    registry_written = write_superbench_registry(source_root=source_root, output_dir=registry_root)

    execution = {
        "schema_version": RERUN_EXECUTION_SCHEMA_VERSION,
        "preview_line": SUPERBENCH_PREVIEW_LINE,
        "entry_id": entry_id,
        "source_record": str(record_path),
        "workspace_root": str(workspace_root),
        "registry_root": str(registry_root),
        "status": status,
        "native_config_output": str(rendered_config_path),
        "run_output_dir": str(run_output_dir),
        "bundle_summary_path": str(bundle_summary),
        "rerun_provenance_path": str(rerun_provenance),
        "metric_value": metric_value,
        "reason_codes": reason_codes,
        "registry_written": registry_written,
    }
    return execution


__all__ = ["orchestrate_superbench_rerun_entry"]
