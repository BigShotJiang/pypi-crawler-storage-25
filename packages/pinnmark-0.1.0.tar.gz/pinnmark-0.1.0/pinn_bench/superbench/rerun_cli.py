"""CLI for super-benchmark native rerun orchestration."""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from pathlib import Path

from pinn_bench.superbench.orchestrator import orchestrate_superbench_rerun_entry


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run one v3.0-preview super-benchmark source entry through native rerun orchestration.")
    parser.add_argument("--source-record", required=True, type=str, help="Path to the source_record.json that owns the target entry.")
    parser.add_argument("--entry-id", required=True, type=str, help="Entry id to orchestrate.")
    parser.add_argument("--registry-root", required=True, type=str, help="Directory where rebuilt super-benchmark registry views will be written.")
    parser.add_argument("--workspace-root", required=True, type=str, help="Workspace root for rendered configs, run outputs, bundles, and rerun provenance.")
    parser.add_argument("--mode", choices=["auto"], default="auto", help="`auto` runs a real native rerun for official overlap entries and a preflight staging pass for blocked entries.")
    parser.add_argument("--json", action="store_true", help="Print the machine-readable execution record after completion.")
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    try:
        payload = orchestrate_superbench_rerun_entry(
            source_record=Path(args.source_record),
            entry_id=str(args.entry_id),
            registry_root=Path(args.registry_root),
            workspace_root=Path(args.workspace_root),
            mode=str(args.mode),
        )
    except ValueError as error:
        raise SystemExit(str(error))

    print("Super-benchmark rerun entry completed:")
    print(f"- entry_id: {payload['entry_id']}")
    print(f"- status: {payload['status']}")
    print(f"- native_config_output: {Path(payload['native_config_output']).resolve()}")
    print(f"- bundle_summary_path: {Path(payload['bundle_summary_path']).resolve()}")
    print(f"- rerun_provenance_path: {Path(payload['rerun_provenance_path']).resolve()}")
    if args.json:
        print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
