"""Super-benchmark registry support for the v3.0-preview line."""

from pinn_bench.superbench.cli import main
from pinn_bench.superbench.registry import build_superbench_registry, write_superbench_registry

__all__ = ["build_superbench_registry", "main", "write_superbench_registry"]
