"""CLI for v3.0-preview super-benchmark tranche orchestration."""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from pathlib import Path

from pinn_bench.superbench.tranche import orchestrate_superbench_tranche


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run a v3.0-preview super-benchmark tranche manifest through ordered native rerun orchestration."
    )
    parser.add_argument("--tranche-manifest", required=True, type=str, help="Path to a tranche manifest JSON file.")
    parser.add_argument("--registry-root", required=True, type=str, help="Directory where registry artifacts will be written.")
    parser.add_argument(
        "--mode",
        choices=["auto"],
        default="auto",
        help="`auto` executes official overlap reruns and deterministic staged preflight entries in manifest order.",
    )
    parser.add_argument("--json", action="store_true", help="Print the machine-readable tranche execution record.")
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    try:
        payload = orchestrate_superbench_tranche(
            tranche_manifest=Path(args.tranche_manifest),
            registry_root=Path(args.registry_root),
            mode=str(args.mode),
        )
    except ValueError as error:
        raise SystemExit(str(error))

    print("Super-benchmark tranche completed:")
    print(f"- tranche: {payload['name']}")
    print(f"- entry_count: {payload['summary']['entry_count']}")
    print(f"- execution_record_path: {Path(payload['execution_record_path']).resolve()}")
    print(f"- execution_markdown_path: {Path(payload['execution_markdown_path']).resolve()}")
    if args.json:
        print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
