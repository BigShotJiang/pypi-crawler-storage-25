"""CLI for the v3.0-preview super-benchmark registry builder."""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from pathlib import Path

from pinn_bench.superbench.registry import build_superbench_registry, write_superbench_registry


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Build strict official/staging/evidence registry views for v3.0-preview super-benchmark sources.")
    parser.add_argument("--source-root", required=True, type=str, help="Directory containing source_record.json files.")
    parser.add_argument("--output-dir", required=True, type=str, help="Directory where registry artifacts will be written.")
    parser.add_argument("--json", action="store_true", help="Print the bundle summary as JSON after writing outputs.")
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    source_root = Path(args.source_root)
    output_dir = Path(args.output_dir)
    try:
        written = write_superbench_registry(source_root=source_root, output_dir=output_dir)
        payload = build_superbench_registry(source_root=source_root)
    except ValueError as error:
        raise SystemExit(str(error))

    print("Super-benchmark registry artifacts:")
    for name in sorted(written):
        print(f"- {name}: {Path(written[name]).resolve()}")
    if args.json:
        print(json.dumps(payload["bundle"], indent=2))


if __name__ == "__main__":
    main()
