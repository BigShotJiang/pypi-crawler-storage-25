"""Batch orchestration for v3.0-preview super-benchmark tranches."""

from __future__ import annotations

import json
from collections import defaultdict
from collections.abc import Mapping, Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pinn_bench.superbench.contracts import (
    SUPERBENCH_PREVIEW_LINE,
    TRANCHE_EXECUTION_SCHEMA_VERSION,
    TRANCHE_MANIFEST_SCHEMA_VERSION,
)
from pinn_bench.superbench.orchestrator import orchestrate_superbench_rerun_entry


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError(f"Expected a JSON object in {path}.")
    return dict(payload)


def _write_json(path: Path, payload: Mapping[str, Any]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(dict(payload), indent=2), encoding="utf-8")
    return path


def _resolve_path(*, raw: str, base_root: Path) -> Path:
    candidate = Path(str(raw)).expanduser()
    if not candidate.is_absolute():
        candidate = (base_root / candidate).resolve()
    return candidate


def _validate_tranche_manifest(manifest_path: Path) -> dict[str, Any]:
    payload = _load_json(manifest_path)
    if str(payload.get("schema_version") or "").strip() != TRANCHE_MANIFEST_SCHEMA_VERSION:
        raise ValueError(
            f"Invalid tranche manifest {manifest_path}: schema_version must be {TRANCHE_MANIFEST_SCHEMA_VERSION}."
        )
    if str(payload.get("preview_line") or "").strip() != SUPERBENCH_PREVIEW_LINE:
        raise ValueError(f"Invalid tranche manifest {manifest_path}: preview_line must be {SUPERBENCH_PREVIEW_LINE}.")
    if not str(payload.get("name") or "").strip():
        raise ValueError(f"Invalid tranche manifest {manifest_path}: missing name.")
    entries = payload.get("entries")
    if not isinstance(entries, list) or not entries:
        raise ValueError(f"Invalid tranche manifest {manifest_path}: entries must be a non-empty list.")
    for index, entry in enumerate(entries):
        if not isinstance(entry, Mapping):
            raise ValueError(f"Invalid tranche manifest {manifest_path}: entry {index} is not an object.")
        for field in ("source_record", "entry_id", "workspace_root"):
            if not str(entry.get(field) or "").strip():
                raise ValueError(f"Invalid tranche manifest {manifest_path}: entry {index} missing {field}.")
    return payload


def _render_tranche_markdown(payload: Mapping[str, Any]) -> str:
    summary = payload["summary"]
    lines = [
        "# Super-Benchmark Tranche Execution",
        "",
        f"- Preview line: `{payload['preview_line']}`",
        f"- Tranche: `{payload['name']}`",
        f"- Registry root: `{payload['registry_root']}`",
        f"- Entries attempted: `{summary['entry_count']}`",
        f"- Completed official reruns: `{summary['completed_count']}`",
        f"- Staged entries: `{summary['staged_count']}`",
        "",
        "## Entry Results",
        "",
    ]
    for result in payload.get("results", []):
        reason_codes = ", ".join(result.get("reason_codes", [])) or "none"
        lines.append(
            f"- `{result['entry_id']}` -> `{result['status']}` "
            f"(metric `{result.get('metric_value')}`, reasons `{reason_codes}`)"
        )
    bundle_summary = payload.get("registry_bundle_summary")
    if isinstance(bundle_summary, Mapping):
        lines.extend(
            [
                "",
                "## Registry Snapshot",
                "",
                f"- Official cohorts: `{bundle_summary.get('official_cohort_count')}`",
                f"- Official entries: `{bundle_summary.get('official_entry_count')}`",
                f"- Staging entries: `{bundle_summary.get('staging_entry_count')}`",
                f"- Source-evidence entries: `{bundle_summary.get('source_evidence_entry_count')}`",
            ]
        )
    lines.append("")
    return "\n".join(lines)


def orchestrate_superbench_tranche(
    *,
    tranche_manifest: Path,
    registry_root: Path,
    mode: str = "auto",
) -> dict[str, Any]:
    if mode != "auto":
        raise ValueError("Only --mode auto is currently supported.")

    manifest_path = tranche_manifest.resolve()
    registry_root = registry_root.resolve()
    payload = _validate_tranche_manifest(manifest_path)
    manifest_dir = manifest_path.parent
    results: list[dict[str, Any]] = []
    status_counts: dict[str, int] = defaultdict(int)

    for raw_entry in payload["entries"]:
        entry = dict(raw_entry)
        execution = orchestrate_superbench_rerun_entry(
            source_record=_resolve_path(raw=str(entry["source_record"]), base_root=manifest_dir),
            entry_id=str(entry["entry_id"]),
            workspace_root=_resolve_path(raw=str(entry["workspace_root"]), base_root=manifest_dir),
            registry_root=registry_root,
            mode=mode,
        )
        results.append(execution)
        status_counts[str(execution["status"])] += 1

    registry_bundle_path = registry_root / "superbench_registry_bundle.json"
    registry_bundle_summary = _load_json(registry_bundle_path) if registry_bundle_path.exists() else None

    execution_payload: dict[str, Any] = {
        "schema_version": TRANCHE_EXECUTION_SCHEMA_VERSION,
        "preview_line": SUPERBENCH_PREVIEW_LINE,
        "generated_at": _utc_now(),
        "manifest_path": str(manifest_path),
        "name": str(payload["name"]),
        "registry_root": str(registry_root),
        "summary": {
            "entry_count": len(results),
            "completed_count": status_counts.get("completed", 0),
            "staged_count": sum(count for status, count in status_counts.items() if status.startswith("staged")),
            "status_counts": dict(sorted(status_counts.items())),
        },
        "results": results,
        "registry_bundle_summary": registry_bundle_summary,
    }

    tranche_root = registry_root / "_tranche_runs"
    stem = manifest_path.stem
    execution_payload["execution_record_path"] = str(
        _write_json(tranche_root / f"{stem}_execution.json", execution_payload).resolve()
    )
    markdown_path = tranche_root / f"{stem}_execution.md"
    markdown_path.write_text(_render_tranche_markdown(execution_payload), encoding="utf-8")
    execution_payload["execution_markdown_path"] = str(markdown_path.resolve())
    _write_json(Path(str(execution_payload["execution_record_path"])), execution_payload)
    return execution_payload


__all__ = ["orchestrate_superbench_tranche"]
