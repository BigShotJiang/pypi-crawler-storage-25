"""Build strict official/staging/evidence views for the v3.0-preview super-benchmark line."""

from __future__ import annotations

import json
from collections import defaultdict
from collections.abc import Mapping, Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pinn_bench.superbench.contracts import (
    ALLOWED_ARTIFACT_EVIDENCE_TIERS,
    ALLOWED_BRIDGE_STATUSES,
    ALLOWED_DOMAIN_FAMILIES,
    ALLOWED_NATIVE_RERUN_ADMISSION_EXPECTATIONS,
    ALLOWED_NATIVE_RERUN_BRIDGE_TARGETS,
    ALLOWED_SOURCE_ARTIFACT_KINDS,
    CONTROLLED_RERUN_EVIDENCE_TIER,
    DOMAIN_REGISTRY_SCHEMA_VERSION,
    MATURITY_BOARD_SCHEMA_VERSION,
    NATIVE_RERUN_REQUIRED_FIELDS,
    OFFICIAL_BRIDGE_STATUS,
    OFFICIAL_REQUIRED_ENTRY_FIELDS,
    REGISTRY_BUNDLE_SCHEMA_VERSION,
    REGISTRY_VIEW_SCHEMA_VERSION,
    REQUIRED_ABSORPTION_PACK_FIELDS,
    SOURCE_ONLY_EVIDENCE_TIERS,
    SOURCE_RECORD_SCHEMA_VERSION,
    SOURCE_REGISTRY_SCHEMA_VERSION,
    SUPERBENCH_PREVIEW_LINE,
    derive_cohort_id,
    normalize_reason_codes,
)


SOURCE_RECORD_FILENAME = "source_record.json"


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError(f"Expected a JSON object in {path}.")
    return dict(payload)


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _render_number(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:.6g}"
    return str(value)


def _resolve_optional_path(record_path: Path, raw: Any) -> str | None:
    text = str(raw or "").strip()
    if not text:
        return None
    candidate = Path(text).expanduser()
    if not candidate.is_absolute():
        candidate = (record_path.parent / candidate).resolve()
    return str(candidate)


def _clean_list(values: Any) -> list[str]:
    if values is None:
        return []
    if not isinstance(values, list):
        raise ValueError("Expected a list of strings.")
    normalized: list[str] = []
    for item in values:
        text = str(item or "").strip()
        if not text:
            continue
        normalized.append(text)
    return normalized


def discover_source_record_paths(source_root: Path) -> list[Path]:
    resolved = source_root.resolve()
    if resolved.is_file():
        return [resolved]
    return sorted(resolved.rglob(SOURCE_RECORD_FILENAME))


def _validate_absorption_pack(record: Mapping[str, Any], record_path: Path) -> tuple[dict[str, str], list[str]]:
    errors: list[str] = []
    pack_raw = record.get("absorption_pack")
    if not isinstance(pack_raw, Mapping):
        return {}, ["source_record.absorption_pack_missing"]
    pack: dict[str, str] = {}
    for field in REQUIRED_ABSORPTION_PACK_FIELDS:
        resolved = _resolve_optional_path(record_path, pack_raw.get(field))
        if resolved is None:
            errors.append(f"source_record.absorption_pack_missing:{field}")
            continue
        if not Path(resolved).exists():
            errors.append(f"source_record.absorption_pack_path_missing:{field}")
            continue
        pack[field] = resolved
    return pack, errors


def _validate_native_rerun(entry: Mapping[str, Any], record_path: Path) -> tuple[dict[str, Any], list[str]]:
    errors: list[str] = []
    native_rerun_raw = entry.get("native_rerun")
    if not isinstance(native_rerun_raw, Mapping):
        return {}, ["source_record.entry_native_rerun_missing"]

    native_rerun = dict(native_rerun_raw)
    normalized: dict[str, Any] = {}
    for field in NATIVE_RERUN_REQUIRED_FIELDS:
        if field not in native_rerun:
            errors.append(f"source_record.entry_native_rerun_missing:{field}")

    template_path = _resolve_optional_path(record_path, native_rerun.get("native_config_template"))
    if template_path is None:
        errors.append("source_record.entry_native_rerun_missing:native_config_template")
    elif not Path(template_path).exists():
        errors.append("source_record.entry_native_rerun_template_missing_on_disk")
    else:
        normalized["native_config_template"] = template_path

    for field in (
        "native_task_name",
        "native_model_name",
        "native_config_output",
        "run_output_dir",
        "bundle_output_path",
        "rerun_provenance_output",
    ):
        text = str(native_rerun.get(field) or "").strip()
        if not text:
            errors.append(f"source_record.entry_native_rerun_missing:{field}")
            continue
        normalized[field] = text

    bridge_target = str(native_rerun.get("bridge_target") or "").strip()
    if bridge_target not in ALLOWED_NATIVE_RERUN_BRIDGE_TARGETS:
        errors.append("source_record.entry_native_rerun_bridge_target_invalid")
    else:
        normalized["bridge_target"] = bridge_target

    admission_expectation = str(native_rerun.get("admission_expectation") or "").strip()
    if admission_expectation not in ALLOWED_NATIVE_RERUN_ADMISSION_EXPECTATIONS:
        errors.append("source_record.entry_native_rerun_admission_expectation_invalid")
    else:
        normalized["admission_expectation"] = admission_expectation

    try:
        normalized["preflight_requirements"] = _clean_list(native_rerun.get("preflight_requirements"))
    except ValueError:
        errors.append("source_record.entry_native_rerun_preflight_requirements_invalid")
    try:
        normalized["staging_reason_codes"] = _clean_list(native_rerun.get("staging_reason_codes"))
    except ValueError:
        errors.append("source_record.entry_native_rerun_staging_reason_codes_invalid")

    if normalized.get("bridge_target") == "official_cohort" and normalized.get("admission_expectation") != "must_officialize":
        errors.append("source_record.entry_native_rerun_official_target_requires_must_officialize")
    if normalized.get("bridge_target") == "staging_registry" and normalized.get("admission_expectation") != "must_stage":
        errors.append("source_record.entry_native_rerun_staging_target_requires_must_stage")

    return normalized, errors


def _normalize_entry(*, entry: Mapping[str, Any], record: Mapping[str, Any], record_path: Path) -> dict[str, Any]:
    normalized = dict(entry)
    normalized["source_benchmark_id"] = str(record.get("source_benchmark_id") or "").strip()
    normalized["source_benchmark_version"] = str(record.get("source_benchmark_version") or "").strip()
    normalized["source_adapter_version"] = str(record.get("source_adapter_version") or "").strip()
    normalized["domain_family"] = str(entry.get("domain_family") or record.get("domain_family") or "").strip().lower()
    normalized["source_repo_path"] = _resolve_optional_path(record_path, record.get("source_repo_path"))
    normalized["reason_codes"] = normalize_reason_codes(entry.get("reason_codes"))
    for path_field in ("native_config_path", "artifact_bundle_path", "rerun_provenance_path", "source_pointer_path"):
        normalized[path_field] = _resolve_optional_path(record_path, entry.get(path_field))
    if normalized.get("cohort_id") in {None, ""}:
        normalized["derived_cohort_id"] = derive_cohort_id(normalized)
    else:
        normalized["derived_cohort_id"] = str(normalized.get("cohort_id") or "").strip()
    return normalized


def load_source_records(source_root: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    paths = discover_source_record_paths(source_root)
    if not paths:
        raise ValueError(f"No source_record.json files found under {source_root.resolve()}.")
    for record_path in paths:
        raw = _load_json(record_path)
        errors: list[str] = []
        if str(raw.get("schema_version") or "").strip() != SOURCE_RECORD_SCHEMA_VERSION:
            errors.append("source_record.schema_version_invalid")
        if str(raw.get("preview_line") or "").strip() != SUPERBENCH_PREVIEW_LINE:
            errors.append("source_record.preview_line_invalid")
        for field in ("source_benchmark_id", "source_benchmark_version", "source_adapter_version"):
            if not str(raw.get(field) or "").strip():
                errors.append(f"source_record.field_missing:{field}")
        domain_family = str(raw.get("domain_family") or "").strip().lower()
        if domain_family not in ALLOWED_DOMAIN_FAMILIES:
            errors.append("source_record.domain_family_invalid")
        source_repo_path = _resolve_optional_path(record_path, raw.get("source_repo_path"))
        if source_repo_path is None:
            errors.append("source_record.source_repo_path_missing")
        elif not Path(source_repo_path).exists():
            errors.append("source_record.source_repo_path_missing_on_disk")
        absorption_pack, pack_errors = _validate_absorption_pack(raw, record_path)
        errors.extend(pack_errors)
        entries_raw = raw.get("entries") if isinstance(raw.get("entries"), list) else None
        if not entries_raw:
            errors.append("source_record.entries_missing")
            entries_raw = []
        normalized_entries: list[dict[str, Any]] = []
        for index, entry in enumerate(entries_raw):
            if not isinstance(entry, Mapping):
                errors.append(f"source_record.entry_not_object:{index}")
                continue
            normalized = _normalize_entry(entry=entry, record=raw, record_path=record_path)
            if not str(normalized.get("entry_id") or "").strip():
                errors.append(f"source_record.entry_missing:entry_id:{index}")
            kind = str(normalized.get("source_artifact_kind") or "").strip()
            if kind not in ALLOWED_SOURCE_ARTIFACT_KINDS:
                errors.append(f"source_record.entry_invalid_kind:{index}")
            tier = str(normalized.get("artifact_evidence_tier") or "").strip()
            if tier not in ALLOWED_ARTIFACT_EVIDENCE_TIERS:
                errors.append(f"source_record.entry_invalid_tier:{index}")
            bridge = str(normalized.get("bridge_status") or "").strip()
            if bridge not in ALLOWED_BRIDGE_STATUSES:
                errors.append(f"source_record.entry_invalid_bridge:{index}")
            tier = str(normalized.get("artifact_evidence_tier") or "").strip()
            if tier not in SOURCE_ONLY_EVIDENCE_TIERS:
                native_rerun, native_rerun_errors = _validate_native_rerun(entry, record_path)
                if native_rerun_errors:
                    errors.extend(f"{error}:{index}" for error in native_rerun_errors)
                else:
                    normalized["native_rerun"] = native_rerun
            normalized_entries.append(normalized)
        if errors:
            joined = ", ".join(errors)
            raise ValueError(f"Invalid source record {record_path}: {joined}")
        records.append(
            {
                "schema_version": SOURCE_RECORD_SCHEMA_VERSION,
                "preview_line": SUPERBENCH_PREVIEW_LINE,
                "record_path": str(record_path.resolve()),
                "source_benchmark_id": str(raw.get("source_benchmark_id") or "").strip(),
                "source_benchmark_version": str(raw.get("source_benchmark_version") or "").strip(),
                "source_adapter_version": str(raw.get("source_adapter_version") or "").strip(),
                "source_repo_path": source_repo_path,
                "domain_family": domain_family,
                "absorption_pack": absorption_pack,
                "entries": normalized_entries,
            }
        )
    return records


def _coerce_float(value: Any) -> float | None:
    if value in {None, ""}:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _safe_ratio(numerator: int, denominator: int) -> float:
    if denominator <= 0:
        return 0.0
    return float(numerator) / float(denominator)


def _reason_count_rows(entries: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    counts: dict[str, int] = defaultdict(int)
    for entry in entries:
        for code in normalize_reason_codes(entry.get("reason_codes")):
            counts[code] += 1
    return [
        {"reason_code": code, "count": counts[code]}
        for code in sorted(counts, key=lambda item: (-counts[item], item))
    ]


def _family_count_rows(entries: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    counts: dict[str, int] = defaultdict(int)
    for entry in entries:
        for family in entry.get("bridge_blocking_families", []):
            counts[str(family)] += 1
    return [
        {"blocking_family": family, "count": counts[family]}
        for family in sorted(counts, key=lambda item: (-counts[item], item))
    ]


def _readiness_count_rows(entries: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    counts: dict[str, int] = defaultdict(int)
    for entry in entries:
        readiness = str(entry.get("bridge_readiness") or "").strip()
        if not readiness:
            continue
        counts[readiness] += 1
    return [
        {"bridge_readiness": readiness, "count": counts[readiness]}
        for readiness in sorted(counts, key=lambda item: (-counts[item], item))
    ]


def _derive_blocking_families(reason_codes: Sequence[str]) -> list[str]:
    families: set[str] = set()
    for code in normalize_reason_codes(list(reason_codes)):
        if code.startswith("missing_native_task:") or code in {
            "non_overlap_cohort_pending_native_extension",
            "operator_history_rollout_task_missing",
        }:
            families.add("native_task_contract")
        elif code.startswith("missing_native_model:") or code in {
            "source_native_model_family_not_yet_canonicalized",
        }:
            families.add("native_model_bridge")
        elif code.startswith("missing_local_path:") or code in {
            "external_dataset_not_local",
        }:
            families.add("dataset_locality")
        elif code in {
            "partial_rerun_only",
            "evidence_not_controlled_rerun",
        }:
            families.add("controlled_rerun_evidence")
        elif code.startswith("official_field_missing:") or code in {
            "cohort_bridge_incomplete",
            "bridge_preflight_blocked_before_officialization",
        }:
            families.add("cohort_governance")
        elif code == "catalog_registered_not_officialized":
            families.add("catalog_bridge_definition")
        elif code == "umbrella_registry_only_until_task_level_bridge":
            families.add("umbrella_task_bridge_definition")
        elif code == "source_evidence_only":
            families.add("source_evidence_only")
    return sorted(families)


def _choose_next_internalization_step(blocking_families: Sequence[str]) -> str:
    ordered = [
        ("native_task_contract", "add_native_task_contract"),
        ("native_model_bridge", "define_native_model_bridge"),
        ("dataset_locality", "localize_or_manifest_dataset"),
        ("controlled_rerun_evidence", "upgrade_to_controlled_rerun"),
        ("cohort_governance", "complete_cohort_bridge"),
        ("catalog_bridge_definition", "declare_task_level_bridge_candidates"),
        ("umbrella_task_bridge_definition", "extract_task_level_bridge_candidates"),
        ("source_evidence_only", "promote_source_evidence_to_declared_entry"),
    ]
    families = {str(item) for item in blocking_families}
    for family, action in ordered:
        if family in families:
            return action
    return "none"


def _derive_bridge_state(*, surface: str, tier: str, reason_codes: Sequence[str]) -> tuple[str, list[str], str]:
    blocking_families = _derive_blocking_families(reason_codes)
    next_step = _choose_next_internalization_step(blocking_families)

    if surface == "official":
        return "officialized", [], "none"

    if tier in SOURCE_ONLY_EVIDENCE_TIERS:
        if "catalog_bridge_definition" in blocking_families:
            return "catalog_only", blocking_families, next_step
        if "umbrella_task_bridge_definition" in blocking_families:
            return "umbrella_only", blocking_families, next_step
        return "evidence_only", blocking_families, next_step

    families = set(blocking_families)
    if "native_task_contract" in families and "dataset_locality" in families:
        return "blocked_native_contract_and_dataset", blocking_families, next_step
    if "native_task_contract" in families:
        return "blocked_native_task_contract", blocking_families, next_step
    if "native_model_bridge" in families:
        return "blocked_native_model_bridge", blocking_families, next_step
    if "dataset_locality" in families:
        return "blocked_dataset_locality", blocking_families, next_step
    if "controlled_rerun_evidence" in families:
        return "blocked_evidence_tier", blocking_families, next_step
    if "cohort_governance" in families:
        return "blocked_cohort_governance", blocking_families, next_step
    return "staging_review_pending", blocking_families, next_step


def _select_next_internalization_step(entries: Sequence[Mapping[str, Any]]) -> str:
    steps: dict[str, int] = defaultdict(int)
    for entry in entries:
        action = str(entry.get("next_internalization_step") or "").strip()
        if not action or action == "none":
            continue
        steps[action] += 1
    if not steps:
        return "none"
    priority = [
        "add_native_task_contract",
        "define_native_model_bridge",
        "localize_or_manifest_dataset",
        "upgrade_to_controlled_rerun",
        "complete_cohort_bridge",
        "declare_task_level_bridge_candidates",
        "extract_task_level_bridge_candidates",
        "promote_source_evidence_to_declared_entry",
    ]
    return sorted(steps, key=lambda item: (priority.index(item) if item in priority else len(priority), -steps[item], item))[0]


def classify_entry(entry: Mapping[str, Any]) -> tuple[str, list[str]]:
    reason_codes = normalize_reason_codes(entry.get("reason_codes"))
    tier = str(entry.get("artifact_evidence_tier") or "").strip()
    bridge_status = str(entry.get("bridge_status") or "").strip()

    if tier in SOURCE_ONLY_EVIDENCE_TIERS:
        if "source_evidence_only" not in reason_codes:
            reason_codes.append("source_evidence_only")
        return "source_evidence", reason_codes

    if tier != CONTROLLED_RERUN_EVIDENCE_TIER:
        if "evidence_not_controlled_rerun" not in reason_codes:
            reason_codes.append("evidence_not_controlled_rerun")
        return "staging", reason_codes

    if bridge_status != OFFICIAL_BRIDGE_STATUS:
        if "cohort_bridge_incomplete" not in reason_codes:
            reason_codes.append("cohort_bridge_incomplete")
        return "staging", reason_codes

    missing_fields = [field for field in OFFICIAL_REQUIRED_ENTRY_FIELDS if entry.get(field) in {None, ""}]
    if _coerce_float(entry.get("metric_value")) is None and "metric_value" not in missing_fields:
        missing_fields.append("metric_value")
    if missing_fields:
        for field in missing_fields:
            code = f"official_field_missing:{field}"
            if code not in reason_codes:
                reason_codes.append(code)
        return "staging", reason_codes

    return "official", reason_codes


def _sort_official_entry(entry: Mapping[str, Any]) -> tuple[float, str, str]:
    metric_value = _coerce_float(entry.get("metric_value"))
    metric_key = float("inf") if metric_value is None else metric_value
    return metric_key, str(entry.get("source_benchmark_id") or ""), str(entry.get("entry_id") or "")


def build_superbench_registry(*, source_root: Path) -> dict[str, Any]:
    records = load_source_records(source_root)
    official_entries: list[dict[str, Any]] = []
    staging_entries: list[dict[str, Any]] = []
    source_evidence_entries: list[dict[str, Any]] = []
    source_registry: list[dict[str, Any]] = []
    all_entries: list[dict[str, Any]] = []

    for record in records:
        per_source_counts = {"official": 0, "staging": 0, "source_evidence": 0}
        for raw_entry in record["entries"]:
            entry = dict(raw_entry)
            entry["cohort_id"] = str(entry.get("cohort_id") or "").strip()
            entry["metric_value"] = _coerce_float(entry.get("metric_value"))
            surface, reason_codes = classify_entry(entry)
            entry["surface"] = surface
            entry["reason_codes"] = reason_codes
            entry["bridge_readiness"], entry["bridge_blocking_families"], entry["next_internalization_step"] = _derive_bridge_state(
                surface=surface,
                tier=str(entry.get("artifact_evidence_tier") or "").strip(),
                reason_codes=reason_codes,
            )
            per_source_counts[surface] += 1
            all_entries.append(entry)
            if surface == "official":
                official_entries.append(entry)
            elif surface == "staging":
                staging_entries.append(entry)
            else:
                source_evidence_entries.append(entry)

        executable_entry_count = sum(
            1
            for entry in record["entries"]
            if str(entry.get("artifact_evidence_tier") or "").strip() not in SOURCE_ONLY_EVIDENCE_TIERS
        )
        bridge_complete_entry_count = sum(
            1 for entry in record["entries"] if str(entry.get("bridge_status") or "").strip() == "cohort_bridge_complete"
        )
        bridge_partial_entry_count = sum(
            1 for entry in record["entries"] if str(entry.get("bridge_status") or "").strip() == "cohort_bridge_partial"
        )
        internalization_stage = (
            "fully_officialized"
            if executable_entry_count > 0 and per_source_counts["official"] == executable_entry_count
            else "partially_officialized"
            if per_source_counts["official"] > 0
            else "staging_only"
            if per_source_counts["staging"] > 0
            else "evidence_only"
        )
        source_registry.append(
            {
                "source_benchmark_id": record["source_benchmark_id"],
                "source_benchmark_version": record["source_benchmark_version"],
                "source_adapter_version": record["source_adapter_version"],
                "domain_family": record["domain_family"],
                "source_repo_path": record["source_repo_path"],
                "record_path": record["record_path"],
                "absorption_pack": dict(record["absorption_pack"]),
                "official_entry_count": per_source_counts["official"],
                "staging_entry_count": per_source_counts["staging"],
                "source_evidence_entry_count": per_source_counts["source_evidence"],
                "total_entry_count": len(record["entries"]),
                "executable_entry_count": executable_entry_count,
                "bridge_complete_entry_count": bridge_complete_entry_count,
                "bridge_partial_entry_count": bridge_partial_entry_count,
                "internalization_stage": internalization_stage,
                "absorption_ratio": _safe_ratio(executable_entry_count, len(record["entries"])),
                "officialization_ratio": _safe_ratio(per_source_counts["official"], executable_entry_count),
                "bridge_readiness_counts": _readiness_count_rows(
                    [entry for entry in all_entries if str(entry.get("source_benchmark_id") or "") == record["source_benchmark_id"]]
                ),
                "blocking_family_counts": _family_count_rows(
                    [
                        entry
                        for entry in all_entries
                        if str(entry.get("source_benchmark_id") or "") == record["source_benchmark_id"]
                        and entry.get("surface") != "official"
                    ]
                ),
                "next_internalization_step": _select_next_internalization_step(
                    [
                        entry
                        for entry in all_entries
                        if str(entry.get("source_benchmark_id") or "") == record["source_benchmark_id"]
                        and entry.get("surface") != "official"
                    ]
                ),
            }
        )

    grouped_official: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for entry in official_entries:
        grouped_official[str(entry.get("cohort_id") or "")].append(dict(entry))

    official_cohorts: list[dict[str, Any]] = []
    for cohort_id in sorted(grouped_official):
        ranked = sorted(grouped_official[cohort_id], key=_sort_official_entry)
        for rank, entry in enumerate(ranked, start=1):
            entry["rank"] = rank
        official_cohorts.append(
            {
                "cohort_id": cohort_id,
                "entry_count": len(ranked),
                "entries": ranked,
            }
        )

    domain_registry_rows: list[dict[str, Any]] = []
    grouped_domains: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for entry in all_entries:
        grouped_domains[str(entry.get("domain_family") or "")].append(entry)
    for domain_family in sorted(grouped_domains):
        entries = grouped_domains[domain_family]
        source_ids = sorted({str(entry.get("source_benchmark_id") or "") for entry in entries})
        official_domain_entries = [entry for entry in entries if entry.get("surface") == "official"]
        domain_registry_rows.append(
            {
                "domain_family": domain_family,
                "source_count": len(source_ids),
                "source_benchmark_ids": source_ids,
                "entry_count": len(entries),
                "official_entry_count": sum(1 for entry in entries if entry.get("surface") == "official"),
                "staging_entry_count": sum(1 for entry in entries if entry.get("surface") == "staging"),
                "source_evidence_entry_count": sum(1 for entry in entries if entry.get("surface") == "source_evidence"),
                "official_cohort_count": len({str(entry.get("cohort_id") or "") for entry in official_domain_entries}),
                "bridge_readiness_counts": _readiness_count_rows(entries),
                "blocking_reason_counts": _reason_count_rows(
                    [entry for entry in entries if entry.get("surface") != "official"]
                ),
                "blocking_family_counts": _family_count_rows(
                    [entry for entry in entries if entry.get("surface") != "official"]
                ),
                "next_internalization_step": _select_next_internalization_step(
                    [entry for entry in entries if entry.get("surface") != "official"]
                ),
            }
        )

    cohort_convergence_rows: list[dict[str, Any]] = []
    for cohort in official_cohorts:
        source_ids = sorted({str(entry.get("source_benchmark_id") or "") for entry in cohort["entries"]})
        cohort_convergence_rows.append(
            {
                "cohort_id": cohort["cohort_id"],
                "source_count": len(source_ids),
                "source_benchmark_ids": source_ids,
                "entry_count": cohort["entry_count"],
                "cross_source_converged": len(source_ids) > 1,
            }
        )

    grouped_source_entries: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for entry in all_entries:
        grouped_source_entries[str(entry.get("source_benchmark_id") or "")].append(entry)
    source_maturity_rows: list[dict[str, Any]] = []
    for source in sorted(source_registry, key=lambda item: str(item["source_benchmark_id"])):
        source_id = str(source["source_benchmark_id"])
        entries = grouped_source_entries[source_id]
        official_cohort_ids = sorted(
            {str(entry.get("cohort_id") or "") for entry in entries if entry.get("surface") == "official"}
        )
        highest_surface = (
            "official"
            if source["official_entry_count"] > 0
            else "staging"
            if source["staging_entry_count"] > 0
            else "source_evidence"
        )
        source_maturity_rows.append(
            {
                "source_benchmark_id": source_id,
                "domain_family": source["domain_family"],
                "total_entry_count": source["total_entry_count"],
                "executable_entry_count": source["executable_entry_count"],
                "official_entry_count": source["official_entry_count"],
                "staging_entry_count": source["staging_entry_count"],
                "source_evidence_entry_count": source["source_evidence_entry_count"],
                "bridge_complete_entry_count": source["bridge_complete_entry_count"],
                "bridge_partial_entry_count": source["bridge_partial_entry_count"],
                "official_cohort_count": len(official_cohort_ids),
                "official_cohort_ids": official_cohort_ids,
                "highest_surface": highest_surface,
                "internalization_stage": source["internalization_stage"],
                "absorption_ratio": source["absorption_ratio"],
                "officialization_ratio": source["officialization_ratio"],
                "bridge_readiness_counts": source["bridge_readiness_counts"],
                "blocking_reason_counts": _reason_count_rows(
                    [entry for entry in entries if entry.get("surface") != "official"]
                ),
                "blocking_family_counts": source["blocking_family_counts"],
                "next_internalization_step": source["next_internalization_step"],
            }
        )

    global_blocking_reasons = _reason_count_rows(staging_entries + source_evidence_entries)
    global_blocking_families = _family_count_rows([entry for entry in all_entries if entry.get("surface") != "official"])
    global_bridge_readiness = _readiness_count_rows(all_entries)
    maturity_board = {
        "schema_version": MATURITY_BOARD_SCHEMA_VERSION,
        "preview_line": SUPERBENCH_PREVIEW_LINE,
        "generated_at": _utc_now(),
        "summary": {
            "source_count": len(source_registry),
            "domain_count": len(domain_registry_rows),
            "official_cohort_count": len(official_cohorts),
            "cross_source_converged_cohort_count": sum(
                1 for row in cohort_convergence_rows if row["cross_source_converged"]
            ),
            "official_source_count": sum(1 for row in source_maturity_rows if row["official_entry_count"] > 0),
            "internalized_source_count": sum(1 for row in source_maturity_rows if row["internalization_stage"] != "evidence_only"),
            "fully_officialized_source_count": sum(
                1 for row in source_maturity_rows if row["internalization_stage"] == "fully_officialized"
            ),
            "partially_officialized_source_count": sum(
                1 for row in source_maturity_rows if row["internalization_stage"] == "partially_officialized"
            ),
            "staging_only_source_count": sum(
                1
                for row in source_maturity_rows
                if row["official_entry_count"] == 0 and row["staging_entry_count"] > 0
            ),
            "evidence_only_source_count": sum(
                1
                for row in source_maturity_rows
                if row["official_entry_count"] == 0 and row["staging_entry_count"] == 0
            ),
            "global_officialization_ratio": round(
                _safe_ratio(
                    sum(row["official_entry_count"] for row in source_maturity_rows),
                    sum(row["executable_entry_count"] for row in source_maturity_rows),
                ),
                6,
            ),
            "bridge_readiness_counts": global_bridge_readiness,
            "top_blocking_families": global_blocking_families[:10],
            "next_internalization_step": _select_next_internalization_step(
                [entry for entry in all_entries if entry.get("surface") != "official"]
            ),
            "top_blockers": global_blocking_reasons[:10],
        },
        "source_rows": source_maturity_rows,
        "domain_rows": domain_registry_rows,
        "cohort_convergence": cohort_convergence_rows,
    }

    bundle = {
        "schema_version": REGISTRY_BUNDLE_SCHEMA_VERSION,
        "preview_line": SUPERBENCH_PREVIEW_LINE,
        "generated_at": _utc_now(),
        "source_root": str(source_root.resolve()),
        "source_count": len(source_registry),
        "official_entry_count": len(official_entries),
        "staging_entry_count": len(staging_entries),
        "source_evidence_entry_count": len(source_evidence_entries),
        "official_cohort_count": len(official_cohorts),
        "surfaces": {
            "official_cohort_leaderboard": "official_cohort_leaderboard.json",
            "staging_registry": "staging_registry.json",
            "source_evidence_registry": "source_evidence_registry.json",
            "benchmark_source_registry": "benchmark_source_registry.json",
            "domain_registry": "domain_registry.json",
            "superbench_maturity_board": "superbench_maturity_board.json",
        },
    }

    return {
        "bundle": bundle,
        "benchmark_source_registry": {
            "schema_version": SOURCE_REGISTRY_SCHEMA_VERSION,
            "preview_line": SUPERBENCH_PREVIEW_LINE,
            "generated_at": bundle["generated_at"],
            "sources": source_registry,
        },
        "domain_registry": {
            "schema_version": DOMAIN_REGISTRY_SCHEMA_VERSION,
            "preview_line": SUPERBENCH_PREVIEW_LINE,
            "generated_at": bundle["generated_at"],
            "domains": domain_registry_rows,
        },
        "official_cohort_leaderboard": {
            "schema_version": REGISTRY_VIEW_SCHEMA_VERSION,
            "preview_line": SUPERBENCH_PREVIEW_LINE,
            "generated_at": bundle["generated_at"],
            "cohorts": official_cohorts,
        },
        "staging_registry": {
            "schema_version": REGISTRY_VIEW_SCHEMA_VERSION,
            "preview_line": SUPERBENCH_PREVIEW_LINE,
            "generated_at": bundle["generated_at"],
            "entries": sorted(staging_entries, key=lambda item: (str(item.get("source_benchmark_id") or ""), str(item.get("entry_id") or ""))),
        },
        "source_evidence_registry": {
            "schema_version": REGISTRY_VIEW_SCHEMA_VERSION,
            "preview_line": SUPERBENCH_PREVIEW_LINE,
            "generated_at": bundle["generated_at"],
            "entries": sorted(source_evidence_entries, key=lambda item: (str(item.get("source_benchmark_id") or ""), str(item.get("entry_id") or ""))),
        },
        "superbench_maturity_board": maturity_board,
    }


def render_superbench_registry_markdown(payload: Mapping[str, Any]) -> str:
    bundle = payload["bundle"]
    official = payload["official_cohort_leaderboard"]
    staging = payload["staging_registry"]
    evidence = payload["source_evidence_registry"]
    sources = payload["benchmark_source_registry"]
    domains = payload["domain_registry"]
    maturity = payload["superbench_maturity_board"]

    lines = [
        "# Super-Benchmark Registry Bundle",
        "",
        f"- Preview line: `{bundle['preview_line']}`",
        f"- Source root: `{bundle['source_root']}`",
        f"- Sources discovered: `{bundle['source_count']}`",
        f"- Official cohorts: `{bundle['official_cohort_count']}`",
        f"- Official entries: `{bundle['official_entry_count']}`",
        f"- Staging entries: `{bundle['staging_entry_count']}`",
        f"- Source-evidence entries: `{bundle['source_evidence_entry_count']}`",
        "",
        "## Platform Maturity",
        "",
        f"- Domains discovered: `{maturity['summary']['domain_count']}`",
        f"- Official sources: `{maturity['summary']['official_source_count']}`",
        f"- Internalized sources: `{maturity['summary']['internalized_source_count']}`",
        f"- Fully officialized sources: `{maturity['summary']['fully_officialized_source_count']}`",
        f"- Partially officialized sources: `{maturity['summary']['partially_officialized_source_count']}`",
        f"- Staging-only sources: `{maturity['summary']['staging_only_source_count']}`",
        f"- Evidence-only sources: `{maturity['summary']['evidence_only_source_count']}`",
        f"- Cross-source converged official cohorts: `{maturity['summary']['cross_source_converged_cohort_count']}`",
        "",
        "## Source Registry",
        "",
    ]
    for source in sources.get("sources", []):
        lines.append(
            f"- `{source['source_benchmark_id']}` ({source['domain_family']}): stage `{source['internalization_stage']}`, official `{source['official_entry_count']}`, staging `{source['staging_entry_count']}`, evidence `{source['source_evidence_entry_count']}`, officialization `{source['officialization_ratio']:.3f}`, next step `{source['next_internalization_step']}`"
        )

    lines.extend(["", "## Domain Registry", ""])
    for domain in domains.get("domains", []):
        lines.append(
            f"- `{domain['domain_family']}`: sources `{domain['source_count']}`, official cohorts `{domain['official_cohort_count']}`, official `{domain['official_entry_count']}`, staging `{domain['staging_entry_count']}`, evidence `{domain['source_evidence_entry_count']}`, next step `{domain['next_internalization_step']}`"
        )

    lines.extend(["", "## Official Cohorts", ""])
    for cohort in official.get("cohorts", []):
        lines.append(f"### `{cohort['cohort_id']}`")
        lines.append("")
        for entry in cohort.get("entries", []):
            lines.append(
                f"- rank `{entry['rank']}`: `{entry['source_benchmark_id']}` / `{entry['entry_id']}` / metric `{_render_number(entry.get('metric_value'))}`"
            )
        lines.append("")

    lines.extend(["## Staging Entries", ""])
    for entry in staging.get("entries", []):
        lines.append(
            f"- `{entry['source_benchmark_id']}` / `{entry['entry_id']}`: readiness `{entry.get('bridge_readiness', '')}`, next step `{entry.get('next_internalization_step', '')}`, reasons {', '.join(entry.get('reason_codes', []))}"
        )

    lines.extend(["", "## Source Evidence", ""])
    for entry in evidence.get("entries", []):
        lines.append(
            f"- `{entry['source_benchmark_id']}` / `{entry['entry_id']}`: readiness `{entry.get('bridge_readiness', '')}`, next step `{entry.get('next_internalization_step', '')}`, reasons {', '.join(entry.get('reason_codes', []))}"
        )

    lines.extend(["", "## Top Blocking Families", ""])
    for row in maturity.get("summary", {}).get("top_blocking_families", []):
        lines.append(f"- `{row['blocking_family']}`: `{row['count']}`")

    lines.extend(["", "## Top Blocking Reasons", ""])
    for row in maturity.get("summary", {}).get("top_blockers", []):
        lines.append(f"- `{row['reason_code']}`: `{row['count']}`")

    lines.append("")
    return "\n".join(lines)


def write_superbench_registry(*, source_root: Path, output_dir: Path) -> dict[str, str]:
    payload = build_superbench_registry(source_root=source_root)
    destination = output_dir.resolve()
    destination.mkdir(parents=True, exist_ok=True)
    written: dict[str, str] = {}
    for filename, content in (
        ("superbench_registry_bundle.json", payload["bundle"]),
        ("benchmark_source_registry.json", payload["benchmark_source_registry"]),
        ("domain_registry.json", payload["domain_registry"]),
        ("official_cohort_leaderboard.json", payload["official_cohort_leaderboard"]),
        ("staging_registry.json", payload["staging_registry"]),
        ("source_evidence_registry.json", payload["source_evidence_registry"]),
        ("superbench_maturity_board.json", payload["superbench_maturity_board"]),
    ):
        path = destination / filename
        _write_json(path, content)
        written[filename] = str(path)
    markdown_path = destination / "superbench_registry_bundle.md"
    markdown_path.write_text(render_superbench_registry_markdown(payload), encoding="utf-8")
    written["superbench_registry_bundle.md"] = str(markdown_path)
    return written


__all__ = [
    "SOURCE_RECORD_FILENAME",
    "build_superbench_registry",
    "classify_entry",
    "discover_source_record_paths",
    "load_source_records",
    "render_superbench_registry_markdown",
    "write_superbench_registry",
]
