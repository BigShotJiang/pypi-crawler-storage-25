"""CLI helpers for official presets."""

from __future__ import annotations

import argparse
from collections.abc import Sequence
from pathlib import Path

from pinn_bench.demo import DEMO_SPECS, demo_resource_checks, main as demo_main
from pinn_bench.experiments import matrix_run
from pinn_bench.presets import PresetSpec, get_preset, list_presets, search_presets
from pinn_bench.resources import resolve_config_path, resolve_manifest_path, resolve_outputs_root
from pinn_bench.run import run_experiment_cli
from pinn_bench.scaffold import main as scaffold_main


SAFE_ROOT_BLOCKLIST = {"outputs_v02", "outputs"}


def _parse_scaffold_target(target: str) -> tuple[str, str]:
    kind, _, name = target.partition(":")
    if kind not in {"external-model", "external-task"} or not name:
        raise ValueError(f"Unsupported scaffold target '{target}'.")
    return kind, name



def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="List, inspect, and run official pinn_bench presets.")
    subparsers = parser.add_subparsers(dest="command")

    list_parser = subparsers.add_parser("list", help="List official presets.")
    list_parser.add_argument("--kind", type=str, default=None, help="Optional preset kind filter.")
    list_parser.add_argument("--tag", type=str, default=None, help="Optional preset tag filter.")

    show_parser = subparsers.add_parser("show", help="Show one preset.")
    show_parser.add_argument("name", type=str)

    run_parser = subparsers.add_parser("run", help="Run one preset.")
    run_parser.add_argument("name", type=str)
    run_parser.add_argument("--output-root", type=str, default=None, help="Optional safe outputs root override.")

    search_parser = subparsers.add_parser("search", help="Search presets by name, description, or tags.")
    search_parser.add_argument("query", nargs="?", default=None, type=str)
    search_parser.add_argument("--kind", type=str, default=None, help="Optional preset kind filter.")
    search_parser.add_argument("--tag", type=str, default=None, help="Optional preset tag filter.")

    subparsers.add_parser("doctor", help="Validate preset targets and safe roots.")
    return parser



def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)



def _format_preset_block(preset: PresetSpec) -> str:
    generated_assets = ", ".join(preset.generated_assets)
    tags = ", ".join(preset.tags)
    return "\n".join(
        [
            f"name: {preset.name}",
            f"kind: {preset.kind}",
            f"audience: {preset.audience}",
            f"description: {preset.description}",
            f"target_command: {preset.target_command}",
            f"config_or_manifest: {preset.config_or_manifest}",
            f"recommended_outputs_root: {preset.recommended_outputs_root}",
            f"expected_runtime: {preset.expected_runtime}",
            f"generated_assets: {generated_assets}",
            f"tags: {tags}",
        ]
    )



def _list_line(preset: PresetSpec) -> str:
    return (
        f"{preset.name} | kind={preset.kind} | audience={preset.audience} | "
        f"runtime={preset.expected_runtime} | tags={','.join(preset.tags)} | {preset.description}"
    )



def print_preset_list(*, kind: str | None = None, tag: str | None = None) -> None:
    for preset in list_presets(kind=kind, tag=tag):
        print(_list_line(preset))



def print_preset(preset: PresetSpec) -> None:
    print(_format_preset_block(preset))



def _is_safe_root(root: str) -> bool:
    parts = set(Path(root).parts)
    return not any(blocked in parts for blocked in SAFE_ROOT_BLOCKLIST)



def validate_preset_catalog() -> list[str]:
    issues: list[str] = []
    for preset in list_presets():
        if not _is_safe_root(preset.recommended_outputs_root):
            issues.append(f"Preset '{preset.name}' points at an unsafe outputs root: {preset.recommended_outputs_root}")
        try:
            if preset.mode == "run":
                resolve_config_path(preset.target)
            elif preset.mode == "matrix":
                resolve_manifest_path(preset.target)
            elif preset.mode == "demo":
                if preset.target not in DEMO_SPECS:
                    issues.append(f"Preset '{preset.name}' references unknown demo mode '{preset.target}'.")
                else:
                    for resolved_path in demo_resource_checks(preset.target):
                        if not resolved_path.exists():
                            issues.append(f"Preset '{preset.name}' demo dependency is missing: {resolved_path}")
            elif preset.mode == "scaffold":
                _parse_scaffold_target(preset.target)
            else:
                issues.append(f"Preset '{preset.name}' uses unsupported mode '{preset.mode}'.")
        except FileNotFoundError as error:
            issues.append(f"Preset '{preset.name}' could not resolve its target: {error}")
    return issues



def run_preset(preset: PresetSpec, output_root: str | None = None) -> None:
    resolved_output_root = resolve_outputs_root(preset.recommended_outputs_root if output_root is None else output_root)
    if preset.mode == "run":
        config_path = resolve_config_path(preset.target)
        run_id = config_path.stem
        run_experiment_cli(
            [
                "--config",
                str(config_path),
                "--seed",
                "0",
                "--output-dir",
                str(resolved_output_root / f"{run_id}_seed0"),
            ]
        )
        return
    if preset.mode == "matrix":
        manifest_path = resolve_manifest_path(preset.target)
        matrix_run.main(
            [
                "--matrix-manifest",
                str(manifest_path),
                "--outputs-root",
                str(resolved_output_root),
                "--skip-existing",
            ]
        )
        return
    if preset.mode == "demo":
        demo_main([preset.target, "--output-root", str(resolved_output_root)])
        return
    if preset.mode == "scaffold":
        kind, name = _parse_scaffold_target(preset.target)
        scaffold_main([kind, name, "--dest-root", str(resolved_output_root)])
        return
    raise ValueError(f"Unsupported preset mode '{preset.mode}'.")



def main(argv: Sequence[str] | None = None) -> None:
    args = parse_args(argv)
    if args.command is None or args.command in {"-h", "--help"}:
        build_parser().print_help()
        return
    if args.command == "list":
        print_preset_list(kind=args.kind, tag=args.tag)
        return
    if args.command == "show":
        print_preset(get_preset(args.name))
        return
    if args.command == "run":
        preset = get_preset(args.name)
        print_preset(preset)
        run_preset(preset, output_root=args.output_root)
        return
    if args.command == "search":
        for preset in search_presets(args.query, kind=args.kind, tag=args.tag):
            print(_list_line(preset))
        return
    if args.command == "doctor":
        issues = validate_preset_catalog()
        if issues:
            print("pinn_bench preset doctor")
            for issue in issues:
                print(f"[FAIL] {issue}")
            raise SystemExit(1)
        print("pinn_bench preset doctor")
        print("[OK] Preset catalog targets and safe roots validated.")
        return
    raise SystemExit(f"Unknown preset subcommand '{args.command}'.")


if __name__ == "__main__":
    main()
