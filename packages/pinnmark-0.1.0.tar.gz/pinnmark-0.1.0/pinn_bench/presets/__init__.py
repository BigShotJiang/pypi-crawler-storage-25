"""Official preset catalog for productized benchmark entrypoints."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PresetSpec:
    name: str
    kind: str
    description: str
    target_command: str
    config_or_manifest: str
    recommended_outputs_root: str
    audience: str
    expected_runtime: str
    generated_assets: tuple[str, ...]
    tags: tuple[str, ...]
    mode: str
    target: str


PRESETS = [
    PresetSpec(
        name="community-bundle-demo",
        kind="community",
        description="Official packaging demo focused on producing a submission bundle from a frozen formal run.",
        target_command="pinn-bench demo submission-path",
        config_or_manifest="demo:submission-path",
        recommended_outputs_root="outputs_demo/community-bundle-demo",
        audience="community",
        expected_runtime="short (~5-10s using frozen reference assets)",
        generated_assets=("bundle/", "validation.json", "comparison.md", "doctor_submission.json", "demo_summary.md", "asset_index.md"),
        tags=("community", "bundle", "package-run", "official-reference"),
        mode="demo",
        target="submission-path",
    ),
    PresetSpec(
        name="community-validate-demo",
        kind="community",
        description="Official validation demo focused on schema and compatibility checks for a packaged bundle.",
        target_command="pinn-bench demo submission-path",
        config_or_manifest="demo:submission-path",
        recommended_outputs_root="outputs_demo/community-validate-demo",
        audience="community",
        expected_runtime="short (~5-10s using frozen reference assets)",
        generated_assets=("bundle/", "validation.json", "doctor_submission.json", "demo_summary.md", "asset_index.md"),
        tags=("community", "validate", "bundle", "compatibility"),
        mode="demo",
        target="submission-path",
    ),
    PresetSpec(
        name="community-compare-demo",
        kind="community",
        description="Official comparison demo focused on comparing a packaged bundle against grouped formal results.",
        target_command="pinn-bench demo submission-path",
        config_or_manifest="demo:submission-path",
        recommended_outputs_root="outputs_demo/community-compare-demo",
        audience="community",
        expected_runtime="short (~5-10s using frozen reference assets)",
        generated_assets=("bundle/", "comparison.md", "validation.json", "doctor_submission.json", "demo_summary.md", "asset_index.md"),
        tags=("community", "compare", "bundle", "grouped"),
        mode="demo",
        target="submission-path",
    ),
    PresetSpec(
        name="community-bundle-validate-demo",
        kind="community",
        description="Community onboarding demo for package, validate, and compare.",
        target_command="pinn-bench demo community-path",
        config_or_manifest="demo:community-path",
        recommended_outputs_root="outputs_demo/community-bundle-validate-demo",
        audience="community",
        expected_runtime="short (~5-10s using frozen reference assets)",
        generated_assets=("external_templates/", "bundle/", "validation.json", "comparison.md", "demo_summary.md", "asset_index.md"),
        tags=("community", "bundle", "validate", "compare", "official-reference"),
        mode="demo",
        target="community-path",
    ),
    PresetSpec(
        name="community-external-model-template",
        kind="community",
        description="Generate an external model teaching template with bundle-oriented next steps.",
        target_command="pinn-bench scaffold external-model community_example_model",
        config_or_manifest="scaffold:external-model:community_example_model",
        recommended_outputs_root="outputs_playground/community-external-model-template",
        audience="community",
        expected_runtime="instant",
        generated_assets=("external_templates/model/community_example_model/",),
        tags=("community", "external-model", "scaffold", "teaching"),
        mode="scaffold",
        target="external-model:community_example_model",
    ),
    PresetSpec(
        name="community-external-task-template",
        kind="community",
        description="Generate an external task teaching template with protocol and packaging guidance.",
        target_command="pinn-bench scaffold external-task community_example_task",
        config_or_manifest="scaffold:external-task:community_example_task",
        recommended_outputs_root="outputs_playground/community-external-task-template",
        audience="community",
        expected_runtime="instant",
        generated_assets=("external_templates/task/community_example_task/",),
        tags=("community", "external-task", "scaffold", "teaching"),
        mode="scaffold",
        target="external-task:community_example_task",
    ),
    PresetSpec(
        name="quickstart-heat-mlp",
        kind="quickstart",
        description="Single-run Heat1D MLP quickstart.",
        target_command="pinn-bench run --config heat1d_mlp.yaml",
        config_or_manifest="heat1d_mlp.yaml",
        recommended_outputs_root="outputs_demo/quickstart-heat-mlp",
        audience="newcomer",
        expected_runtime="short (~10-20s on CPU)",
        generated_assets=("config_snapshot.yaml", "metrics.json", "train_log.csv", "loss_curve.png", "model.pt"),
        tags=("quickstart", "single-run", "heat1d", "mlp", "cpu"),
        mode="run",
        target="heat1d_mlp.yaml",
    ),
    PresetSpec(
        name="quickstart-burgers-siren",
        kind="quickstart",
        description="Single-run Burgers1D SIREN quickstart.",
        target_command="pinn-bench run --config burgers1d_siren.yaml",
        config_or_manifest="burgers1d_siren.yaml",
        recommended_outputs_root="outputs_demo/quickstart-burgers-siren",
        audience="newcomer",
        expected_runtime="short (~10-20s on CPU)",
        generated_assets=("config_snapshot.yaml", "metrics.json", "train_log.csv", "loss_curve.png", "model.pt"),
        tags=("quickstart", "single-run", "burgers1d", "siren", "cpu"),
        mode="run",
        target="burgers1d_siren.yaml",
    ),
    PresetSpec(
        name="quickstart-poisson-kan",
        kind="quickstart",
        description="Single-run Poisson2D KAN quickstart.",
        target_command="pinn-bench run --config poisson2d_kan.yaml",
        config_or_manifest="poisson2d_kan.yaml",
        recommended_outputs_root="outputs_demo/quickstart-poisson-kan",
        audience="newcomer",
        expected_runtime="short (~10-20s on CPU)",
        generated_assets=("config_snapshot.yaml", "metrics.json", "train_log.csv", "loss_curve.png", "model.pt"),
        tags=("quickstart", "single-run", "poisson2d", "kan", "cpu"),
        mode="run",
        target="poisson2d_kan.yaml",
    ),
    PresetSpec(
        name="demo-heat-compare",
        kind="demo",
        description="Heat1D MLP vs SIREN grouped comparison demo.",
        target_command="pinn-bench demo compare",
        config_or_manifest="demo:compare",
        recommended_outputs_root="outputs_demo/demo-heat-compare",
        audience="newcomer",
        expected_runtime="short (~20-30s on CPU)",
        generated_assets=("_demo_manifest.yaml", "_leaderboard/leaderboard_grouped.json", "_leaderboard/reporting/", "demo_summary.md", "asset_index.md"),
        tags=("demo", "compare", "heat1d", "grouped", "reporting"),
        mode="demo",
        target="compare",
    ),
    PresetSpec(
        name="demo-robustness-heat",
        kind="demo",
        description="Heat1D robustness demo using SIREN noise protocol.",
        target_command="pinn-bench demo robustness",
        config_or_manifest="demo:robustness",
        recommended_outputs_root="outputs_demo/demo-robustness-heat",
        audience="newcomer",
        expected_runtime="short (~15-25s on CPU)",
        generated_assets=("_demo_manifest.yaml", "_leaderboard/leaderboard_grouped.json", "_leaderboard/reporting/", "_leaderboard/pareto/", "demo_summary.md", "asset_index.md"),
        tags=("demo", "robustness", "heat1d", "noise", "pareto"),
        mode="demo",
        target="robustness",
    ),
    PresetSpec(
        name="demo-quick-platform-tour",
        kind="demo",
        description="Official compact end-to-end platform tour demo.",
        target_command="pinn-bench demo platform-tour",
        config_or_manifest="demo:platform-tour",
        recommended_outputs_root="outputs_demo/demo-quick-platform-tour",
        audience="newcomer",
        expected_runtime="medium (~30-45s on CPU)",
        generated_assets=("_demo_manifest.yaml", "_leaderboard/leaderboard_grouped.json", "_leaderboard/reporting/", "_leaderboard/pareto/", "demo_summary.md", "asset_index.md"),
        tags=("demo", "official", "platform-tour", "grouped", "reporting", "pareto"),
        mode="demo",
        target="platform-tour",
    ),
    PresetSpec(
        name="formal-v0.1",
        kind="formal",
        description="Run the frozen v0.1 baseline on a safe preview root.",
        target_command="pinn-bench matrix --matrix-manifest baseline_v0_1.yaml",
        config_or_manifest="baseline_v0_1.yaml",
        recommended_outputs_root="outputs_preview_v03/formal_v0_1",
        audience="maintainer",
        expected_runtime="long (full matrix)",
        generated_assets=("_matrix_runs/",),
        tags=("formal", "v0.1", "matrix", "preview-root"),
        mode="matrix",
        target="baseline_v0_1.yaml",
    ),
    PresetSpec(
        name="formal-v0.2",
        kind="formal",
        description="Run the frozen v0.2 baseline on a safe preview root.",
        target_command="pinn-bench matrix --matrix-manifest baseline_v0_2.yaml",
        config_or_manifest="baseline_v0_2.yaml",
        recommended_outputs_root="outputs_preview_v03/formal_v0_2",
        audience="maintainer",
        expected_runtime="long (full matrix)",
        generated_assets=("_matrix_runs/",),
        tags=("formal", "v0.2", "matrix", "preview-root"),
        mode="matrix",
        target="baseline_v0_2.yaml",
    ),
    PresetSpec(
        name="preview-v0.3-core",
        kind="preview",
        description="Core v0.3-preview product experience through the platform-tour demo.",
        target_command="pinn-bench demo platform-tour",
        config_or_manifest="demo:platform-tour",
        recommended_outputs_root="outputs_preview_v03/preview-v0.3-core",
        audience="researcher",
        expected_runtime="medium (~30-45s on CPU)",
        generated_assets=("_demo_manifest.yaml", "_leaderboard/leaderboard_grouped.json", "_leaderboard/reporting/", "_leaderboard/pareto/", "demo_summary.md", "asset_index.md"),
        tags=("preview", "official", "platform-tour", "v0.3"),
        mode="demo",
        target="platform-tour",
    ),
    PresetSpec(
        name="preview-v0.3-demo",
        kind="preview",
        description="Preview-only quick demo for product walkthroughs.",
        target_command="pinn-bench demo quick",
        config_or_manifest="demo:quick",
        recommended_outputs_root="outputs_preview_v03/preview-v0.3-demo",
        audience="researcher",
        expected_runtime="short (~10-20s on CPU)",
        generated_assets=("_demo_manifest.yaml", "_leaderboard/leaderboard_grouped.json", "_leaderboard/reporting/", "demo_summary.md", "asset_index.md"),
        tags=("preview", "quick", "v0.3"),
        mode="demo",
        target="quick",
    ),
]



def _matches_filters(preset: PresetSpec, *, kind: str | None = None, tag: str | None = None) -> bool:
    if kind is not None and preset.kind != kind.strip().lower():
        return False
    if tag is not None and tag.strip().lower() not in {item.lower() for item in preset.tags}:
        return False
    return True



def list_presets(*, kind: str | None = None, tag: str | None = None) -> list[PresetSpec]:
    return sorted(
        [preset for preset in PRESETS if _matches_filters(preset, kind=kind, tag=tag)],
        key=lambda preset: (preset.kind, preset.name),
    )



def search_presets(query: str | None = None, *, kind: str | None = None, tag: str | None = None) -> list[PresetSpec]:
    filtered = list_presets(kind=kind, tag=tag)
    if query is None or not query.strip():
        return filtered
    needle = query.strip().lower()
    return [
        preset
        for preset in filtered
        if needle in preset.name.lower()
        or needle in preset.description.lower()
        or any(needle in item.lower() for item in preset.tags)
    ]



def get_preset(name: str) -> PresetSpec:
    normalized = name.strip().lower()
    for preset in PRESETS:
        if preset.name == normalized:
            return preset
    available = ", ".join(preset.name for preset in list_presets())
    raise KeyError(f"Unknown preset '{name}'. Available: {available}")
