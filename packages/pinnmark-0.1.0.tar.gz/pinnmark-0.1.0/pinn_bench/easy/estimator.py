"""sklearn-like benchmark estimator facade built on the existing benchmark kernel."""

from __future__ import annotations

from collections.abc import Mapping
from html import escape
from pathlib import Path
from typing import Any

import yaml

from pinn_bench.easy.base import clone_value, coerce_path, flatten_prefixed, normalize_mapping, set_nested_mapping_value
from pinn_bench.config.loader import load_config
from pinn_bench.easy.config_adapter import (
    config_to_estimator,
    estimator_to_config,
    normalize_model_spec,
    normalize_task_spec,
    resolve_starter_config_path,
)
from pinn_bench.easy.context import get_easy_config
from pinn_bench.easy.exceptions import InvalidCompositionError, NotExecutedError
from pinn_bench.easy.report import BenchmarkReport
from pinn_bench.easy.specs import ModelSpec, TaskSpec
from pinn_bench.easy.discovery import describe_starter
from pinn_bench.resources import resolve_config_path
from pinn_bench.api.user_api import load_config_template


class BenchmarkEstimator:
    """User-facing benchmark object with sklearn-like fit/score/report semantics."""

    def __init__(
        self,
        *,
        model: str | ModelSpec,
        task: str | TaskSpec,
        epochs: int,
        lr: float,
        seed: int = 42,
        device: str | None = None,
        metrics: tuple[str, ...] = ("mse", "relative_l2"),
        logging_backend: str | None = None,
        robustness: dict[str, Any] | None = None,
        comparison: dict[str, Any] | None = None,
        train_extras: dict[str, Any] | None = None,
        evaluation: dict[str, Any] | None = None,
        output_dir: str | Path | None = None,
    ) -> None:
        easy_config = get_easy_config()
        self.model = normalize_model_spec(model)
        self.task = normalize_task_spec(task)
        self.epochs = int(epochs)
        self.lr = float(lr)
        self.seed = int(seed)
        self.device = str(easy_config["default_device"] if device is None else device)
        self.metrics = tuple(str(name) for name in metrics)
        self.logging_backend = str(
            easy_config["default_logging_backend"] if logging_backend is None else logging_backend
        )
        self.robustness = normalize_mapping(robustness, location="robustness")
        self.comparison = None if comparison is None else normalize_mapping(comparison, location="comparison")
        self.train_extras = normalize_mapping(train_extras, location="train_extras")
        self.evaluation = normalize_mapping(evaluation, location="evaluation")
        self.output_dir = None if output_dir is None else str(coerce_path(output_dir))
        self._run_dir: Path | None = None
        self._results: dict[str, Any] | None = None

    def __repr__(self) -> str:
        return (
            "BenchmarkEstimator("
            f"model={self.model!r}, task={self.task!r}, epochs={self.epochs!r}, lr={self.lr!r}, "
            f"seed={self.seed!r}, device={self.device!r}, metrics={self.metrics!r}, "
            f"logging_backend={self.logging_backend!r}, output_dir={self.output_dir!r})"
        )

    def _repr_html_(self) -> str:
        rows = [
            ("task", self.task.name),
            ("model", self.model.name),
            ("epochs", self.epochs),
            ("lr", self.lr),
            ("seed", self.seed),
            ("device", self.device),
            ("metrics", self.metrics),
            ("output_dir", self.output_dir),
            ("is_fitted_", self.is_fitted_),
        ]
        html_rows = "".join(
            f"<tr><th>{escape(str(key))}</th><td><code>{escape(repr(value))}</code></td></tr>" for key, value in rows
        )
        return f"<div><strong>BenchmarkEstimator</strong><table>{html_rows}</table></div>"

    @classmethod
    def from_config(cls, config) -> "BenchmarkEstimator":
        """Create one easy estimator from an ExperimentConfig."""
        kwargs = config_to_estimator(config)
        return cls(**kwargs)

    @classmethod
    def from_template(
        cls,
        template_name: str | Path,
        *,
        output_dir: str | Path | None = None,
        overrides: Mapping[str, Any] | None = None,
    ) -> "BenchmarkEstimator":
        """Create one estimator from a built-in config template."""
        config = load_config_template(template_name, overrides=dict(overrides or {}))
        if output_dir is not None:
            config.output.root_dir = str(coerce_path(output_dir))
        return cls.from_config(config)

    @classmethod
    def from_config_path(
        cls,
        config_path: str | Path,
        *,
        output_dir: str | Path | None = None,
        overrides: Mapping[str, Any] | None = None,
    ) -> "BenchmarkEstimator":
        """Create one estimator from a sectioned YAML config path."""
        config = load_config(resolve_config_path(config_path), overrides=dict(overrides or {}))
        if output_dir is not None:
            config.output.root_dir = str(coerce_path(output_dir))
        return cls.from_config(config)

    @classmethod
    def from_starter(
        cls,
        *,
        task_name: str,
        model_name: str,
        output_dir: str | Path | None = None,
        overrides: Mapping[str, Any] | None = None,
    ) -> "BenchmarkEstimator":
        """Create one estimator from a canonical experiment config for a task/model pair."""
        config_path = resolve_starter_config_path(task_name=task_name, model_name=model_name)
        return cls.from_config_path(config_path, output_dir=output_dir, overrides=overrides)

    @classmethod
    def from_starter_id(
        cls,
        starter_id: str,
        *,
        output_dir: str | Path | None = None,
        overrides: Mapping[str, Any] | None = None,
    ) -> "BenchmarkEstimator":
        """Instantiate an estimator directly from a starter catalog entry."""
        entry = describe_starter(starter_id)
        config_path = Path(entry["config_path"])
        return cls.from_config_path(config_path, output_dir=output_dir, overrides=overrides)

    @classmethod
    def load_spec(cls, path: str | Path) -> "BenchmarkEstimator":
        """Load an unfitted estimator spec saved with save_spec(...)."""
        resolved = Path(str(path)).expanduser().resolve()
        payload = yaml.safe_load(resolved.read_text(encoding="utf-8"))
        if not isinstance(payload, dict) or not isinstance(payload.get("spec"), dict):
            raise InvalidCompositionError(f"Estimator spec '{resolved}' must contain a top-level 'spec' mapping.")
        spec = dict(payload["spec"])
        if isinstance(spec.get("model"), dict):
            model_payload = spec["model"]
            spec["model"] = ModelSpec(str(model_payload.get("name", "")), **clone_value(model_payload.get("params", {})))
        if isinstance(spec.get("task"), dict):
            task_payload = spec["task"]
            spec["task"] = TaskSpec(str(task_payload.get("name", "")), **clone_value(task_payload.get("params", {})))
        if isinstance(spec.get("metrics"), list):
            spec["metrics"] = tuple(spec["metrics"])
        return cls(**spec)

    @property
    def is_fitted_(self) -> bool:
        """Return whether this estimator has completed one run."""
        return self._results is not None

    @property
    def run_dir_(self) -> Path | None:
        """Return the resolved run directory after fit."""
        return self._run_dir

    @property
    def results_(self) -> dict[str, Any] | None:
        """Return the in-memory results payload after fit."""
        return None if self._results is None else clone_value(self._results)

    def get_params(self, deep: bool = True) -> dict[str, object]:
        """Expose constructor parameters and nested param trees."""
        payload: dict[str, object] = {
            "model": self.model.clone(),
            "task": self.task.clone(),
            "epochs": self.epochs,
            "lr": self.lr,
            "seed": self.seed,
            "device": self.device,
            "metrics": tuple(self.metrics),
            "logging_backend": self.logging_backend,
            "robustness": clone_value(self.robustness),
            "comparison": clone_value(self.comparison),
            "train_extras": clone_value(self.train_extras),
            "evaluation": clone_value(self.evaluation),
            "output_dir": self.output_dir,
        }
        if not deep:
            return payload
        payload["model__name"] = self.model.name
        payload["task__name"] = self.task.name
        payload.update({f"model__{key}": clone_value(value) for key, value in self.model.params.items()})
        payload.update({f"task__{key}": clone_value(value) for key, value in self.task.params.items()})
        payload.update(
            {
                "train__epochs": self.epochs,
                "train__lr": self.lr,
                "train__seed": self.seed,
                "train__device": self.device,
            }
        )
        payload.update(flatten_prefixed("train", self.train_extras))
        payload["metrics__names"] = tuple(self.metrics)
        payload.update(flatten_prefixed("robustness", self.robustness))
        if self.comparison:
            payload.update(flatten_prefixed("comparison", self.comparison))
        payload.update(flatten_prefixed("evaluation", self.evaluation))
        payload["output__root_dir"] = self.output_dir
        return payload

    def to_spec_dict(self) -> dict[str, object]:
        """Return a YAML-safe unfitted specification payload."""
        return {
            "model": self.model.to_dict(),
            "task": self.task.to_dict(),
            "epochs": self.epochs,
            "lr": self.lr,
            "seed": self.seed,
            "device": self.device,
            "metrics": list(self.metrics),
            "logging_backend": self.logging_backend,
            "robustness": clone_value(self.robustness),
            "comparison": clone_value(self.comparison),
            "train_extras": clone_value(self.train_extras),
            "evaluation": clone_value(self.evaluation),
            "output_dir": self.output_dir,
        }

    def set_params(self, **kwargs: Any) -> "BenchmarkEstimator":
        """Update top-level or nested sklearn-style parameters."""
        for key, value in kwargs.items():
            key_text = str(key)
            if "__" not in key_text:
                if key_text == "model":
                    self.model = normalize_model_spec(value)
                elif key_text == "task":
                    self.task = normalize_task_spec(value)
                elif key_text == "epochs":
                    self.epochs = int(value)
                elif key_text == "lr":
                    self.lr = float(value)
                elif key_text == "seed":
                    self.seed = int(value)
                elif key_text == "device":
                    self.device = str(value)
                elif key_text == "metrics":
                    self.metrics = tuple(str(name) for name in value)
                elif key_text == "logging_backend":
                    self.logging_backend = str(value)
                elif key_text == "robustness":
                    self.robustness = normalize_mapping(value, location="robustness")
                elif key_text == "comparison":
                    self.comparison = None if value is None else normalize_mapping(value, location="comparison")
                elif key_text == "train_extras":
                    self.train_extras = normalize_mapping(value, location="train_extras")
                elif key_text == "evaluation":
                    self.evaluation = normalize_mapping(value, location="evaluation")
                elif key_text == "output_dir":
                    self.output_dir = None if value is None else str(coerce_path(value))
                else:
                    raise InvalidCompositionError(f"Unknown easy estimator parameter '{key_text}'.")
                continue

            prefix, *path = key_text.split("__")
            if prefix == "model":
                if path and path[0] == "name":
                    self.model.set_params(name=value)
                else:
                    self.model.set_params(**{"__".join(path): value})
            elif prefix == "task":
                if path and path[0] == "name":
                    self.task.set_params(name=value)
                else:
                    self.task.set_params(**{"__".join(path): value})
            elif prefix == "train":
                if not path:
                    raise InvalidCompositionError("Nested train parameters must specify a field after 'train__'.")
                head = path[0]
                if head == "epochs":
                    self.epochs = int(value)
                elif head == "lr":
                    self.lr = float(value)
                elif head == "seed":
                    self.seed = int(value)
                elif head == "device":
                    self.device = str(value)
                else:
                    set_nested_mapping_value(self.train_extras, path, value)
            elif prefix == "metrics":
                if path == ["names"]:
                    self.metrics = tuple(str(name) for name in value)
                else:
                    raise InvalidCompositionError(f"Unsupported nested metrics parameter '{key_text}'.")
            elif prefix == "robustness":
                if not path:
                    raise InvalidCompositionError("Nested robustness parameters must specify a field after 'robustness__'.")
                set_nested_mapping_value(self.robustness, path, value)
            elif prefix == "comparison":
                if not path:
                    raise InvalidCompositionError("Nested comparison parameters must specify a field after 'comparison__'.")
                if self.comparison is None:
                    self.comparison = {}
                set_nested_mapping_value(self.comparison, path, value)
            elif prefix == "evaluation":
                if not path:
                    raise InvalidCompositionError("Nested evaluation parameters must specify a field after 'evaluation__'.")
                set_nested_mapping_value(self.evaluation, path, value)
            elif prefix == "output":
                if path == ["root_dir"]:
                    self.output_dir = None if value is None else str(coerce_path(value))
                else:
                    raise InvalidCompositionError(f"Unsupported nested output parameter '{key_text}'.")
            else:
                raise InvalidCompositionError(f"Unknown nested easy estimator parameter prefix '{prefix}'.")
        return self

    def clone(self) -> "BenchmarkEstimator":
        """Return an unfitted copy with identical constructor parameters."""
        return type(self)(
            model=self.model.clone(),
            task=self.task.clone(),
            epochs=self.epochs,
            lr=self.lr,
            seed=self.seed,
            device=self.device,
            metrics=tuple(self.metrics),
            logging_backend=self.logging_backend,
            robustness=clone_value(self.robustness),
            comparison=clone_value(self.comparison),
            train_extras=clone_value(self.train_extras),
            evaluation=clone_value(self.evaluation),
            output_dir=self.output_dir,
        )

    def save_spec(self, path: str | Path) -> Path:
        """Persist the unfitted estimator specification as YAML."""
        resolved = Path(str(path)).expanduser().resolve()
        resolved.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "kind": "BenchmarkEstimator",
            "spec": self.to_spec_dict(),
        }
        resolved.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
        return resolved

    def with_robustness(self, **kwargs: Any) -> "BenchmarkEstimator":
        """Return a cloned estimator with updated robustness settings."""
        clone = self.clone()
        clone.robustness.update(clone_value(kwargs))
        return clone

    def with_comparison(self, **kwargs: Any) -> "BenchmarkEstimator":
        """Return a cloned estimator with updated comparison settings."""
        clone = self.clone()
        if clone.comparison is None:
            clone.comparison = {}
        clone.comparison.update(clone_value(kwargs))
        return clone

    def with_profile(self, **kwargs: Any) -> "BenchmarkEstimator":
        """Return a cloned estimator with updated profile-contract extras."""
        clone = self.clone()
        profile_contract = clone.train_extras.get("profile_contract")
        if not isinstance(profile_contract, Mapping):
            profile_contract = {}
        merged = dict(profile_contract)
        merged.update(clone_value(kwargs))
        clone.train_extras["profile_contract"] = merged
        return clone

    def to_config(self):
        """Compile this public estimator into the typed ExperimentConfig."""
        easy_config = get_easy_config()
        return estimator_to_config(
            model=self.model,
            task=self.task,
            epochs=self.epochs,
            lr=self.lr,
            seed=self.seed,
            device=self.device,
            metrics=tuple(self.metrics),
            logging_backend=self.logging_backend,
            robustness=self.robustness,
            comparison=self.comparison,
            train_extras=self.train_extras,
            evaluation=self.evaluation,
            output_dir=self.output_dir,
            strict_validation=bool(easy_config["strict_validation"]),
            safe_output_policy=str(easy_config["safe_output_policy"]),
        )

    def fit(self, *, output_dir: str | Path | None = None) -> "BenchmarkEstimator":
        """Run the benchmark and persist the resulting fitted state."""
        from pinn_bench.runners import experiment as experiment_module

        config = self.clone()
        if output_dir is not None:
            config.set_params(output_dir=output_dir)
        compiled = config.to_config()
        result = experiment_module.run_experiment(compiled)
        payload = result.to_dict() if hasattr(result, "to_dict") else clone_value(result)
        if not isinstance(payload, Mapping):
            raise InvalidCompositionError("run_experiment must return a mapping-like results payload.")
        self._run_dir = Path(compiled.output.root_dir).resolve()
        self.output_dir = str(self._run_dir)
        self._results = dict(payload)
        return self

    def _require_results(self) -> dict[str, Any]:
        if self._results is None:
            raise NotExecutedError(
                "This BenchmarkEstimator instance is not fitted yet. Call 'fit(...)' before requesting eval, score, or report."
            )
        return self._results

    def evaluate(self) -> dict[str, float]:
        """Return the current evaluation metrics."""
        payload = self._require_results()
        eval_metrics = payload.get("eval", {})
        return {str(key): float(value) for key, value in dict(eval_metrics).items()}

    def score(self, metric: str = "relative_l2") -> float:
        """Return one scalar evaluation metric from the current fitted state."""
        return self.report().score(metric=metric)

    def report(self) -> BenchmarkReport:
        """Return a report over the current fitted state."""
        payload = self._require_results()
        if self._run_dir is not None and (self._run_dir / "metrics.json").exists():
            return BenchmarkReport.from_run_dir(self._run_dir)
        config_snapshot = None
        if self._run_dir is not None and (self._run_dir / "config_snapshot.yaml").exists():
            config_snapshot = self.to_config().to_dict()
        return BenchmarkReport.from_payload(dict(payload), run_dir=self._run_dir, config_snapshot=config_snapshot)
