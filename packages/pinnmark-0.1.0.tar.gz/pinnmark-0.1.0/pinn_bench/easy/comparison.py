"""Higher-level easy-layer workflow helpers."""

from __future__ import annotations

from collections.abc import Sequence
from html import escape
from pathlib import Path
from typing import Any

import yaml

from pinn_bench.easy.base import clone_value, coerce_path
from pinn_bench.easy.estimator import BenchmarkEstimator
from pinn_bench.easy.exceptions import InvalidCompositionError
from pinn_bench.easy.report import BenchmarkReport
from pinn_bench.easy.specs import ModelSpec, TaskSpec


class BenchmarkSuite:
    """Run and inspect a small collection of benchmark estimators."""

    def __init__(self, estimators: list[BenchmarkEstimator]) -> None:
        if not estimators:
            raise InvalidCompositionError("BenchmarkSuite requires at least one BenchmarkEstimator.")
        self._estimators = [estimator.clone() for estimator in estimators]
        self._reports: list[BenchmarkReport] = []

    def __repr__(self) -> str:
        return f"BenchmarkSuite(num_estimators={len(self._estimators)!r}, is_fitted_={self.is_fitted_!r})"

    def _repr_html_(self) -> str:
        rows = "".join(
            "<tr>"
            f"<td>{index}</td>"
            f"<td><code>{escape(estimator.task.name)}</code></td>"
            f"<td><code>{escape(estimator.model.name)}</code></td>"
            f"<td>{escape(str(estimator.epochs))}</td>"
            f"<td>{escape(str(estimator.lr))}</td>"
            "</tr>"
            for index, estimator in enumerate(self._estimators)
        )
        if not rows:
            rows = "<tr><td colspan='5'><em>no estimators</em></td></tr>"
        return (
            "<div><strong>BenchmarkSuite</strong>"
            f"<p>is_fitted_=<code>{self.is_fitted_}</code></p>"
            "<table><tr><th>#</th><th>task</th><th>model</th><th>epochs</th><th>lr</th></tr>"
            f"{rows}</table></div>"
        )

    @property
    def is_fitted_(self) -> bool:
        """Return whether the suite has completed at least one fit_all call."""
        return bool(self._reports)

    @property
    def run_dirs_(self) -> list[Path]:
        """Return run directories from the most recent fit_all call."""
        return [report.run_dir_ for report in self._reports if report.run_dir_ is not None]

    def get_params(self, deep: bool = True) -> dict[str, object]:
        """Expose suite constructor params and nested estimator params."""
        payload: dict[str, object] = {
            "estimators": [estimator.clone() for estimator in self._estimators],
        }
        if not deep:
            return payload
        for index, estimator in enumerate(self._estimators):
            payload[f"estimators__{index}"] = estimator.clone()
            for key, value in estimator.get_params(deep=True).items():
                payload[f"estimators__{index}__{key}"] = clone_value(value)
        return payload

    def set_params(self, **kwargs: Any) -> "BenchmarkSuite":
        """Update the estimator list or nested estimator params."""
        for key, value in kwargs.items():
            key_text = str(key)
            if key_text == "estimators":
                if not isinstance(value, Sequence):
                    raise InvalidCompositionError("BenchmarkSuite.estimators must be a sequence of BenchmarkEstimator.")
                normalized: list[BenchmarkEstimator] = []
                for item in value:
                    if not isinstance(item, BenchmarkEstimator):
                        raise InvalidCompositionError("BenchmarkSuite.estimators must contain BenchmarkEstimator objects.")
                    normalized.append(item.clone())
                if not normalized:
                    raise InvalidCompositionError("BenchmarkSuite requires at least one BenchmarkEstimator.")
                self._estimators = normalized
                self._reports = []
                continue
            parts = key_text.split("__")
            if len(parts) < 2 or parts[0] != "estimators":
                raise InvalidCompositionError(f"Unknown BenchmarkSuite parameter '{key_text}'.")
            try:
                index = int(parts[1])
            except ValueError as error:
                raise InvalidCompositionError(
                    f"BenchmarkSuite nested parameter '{key_text}' must use an integer estimator index."
                ) from error
            if index < 0 or index >= len(self._estimators):
                raise InvalidCompositionError(
                    f"BenchmarkSuite nested parameter '{key_text}' references estimator index {index}, but only {len(self._estimators)} estimators exist."
                )
            if len(parts) == 2:
                if not isinstance(value, BenchmarkEstimator):
                    raise InvalidCompositionError("Replacing one suite estimator requires a BenchmarkEstimator value.")
                self._estimators[index] = value.clone()
                self._reports = []
                continue
            nested_key = "__".join(parts[2:])
            self._estimators[index].set_params(**{nested_key: value})
            self._reports = []
        return self

    def clone(self) -> "BenchmarkSuite":
        """Return an unfitted copy of the suite and all member estimators."""
        return type(self)([estimator.clone() for estimator in self._estimators])

    def save_spec(self, path: str | Path) -> Path:
        """Persist the unfitted suite specification as YAML."""
        resolved = Path(str(path)).expanduser().resolve()
        resolved.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "kind": "BenchmarkSuite",
            "estimators": [estimator.to_spec_dict() for estimator in self._estimators],
        }
        resolved.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
        return resolved

    @classmethod
    def load_spec(cls, path: str | Path) -> "BenchmarkSuite":
        """Load one suite spec saved with save_spec(...)."""
        resolved = Path(str(path)).expanduser().resolve()
        payload = yaml.safe_load(resolved.read_text(encoding="utf-8"))
        if not isinstance(payload, dict) or not isinstance(payload.get("estimators"), list):
            raise InvalidCompositionError(f"BenchmarkSuite spec '{resolved}' must contain an estimators list.")
        estimators: list[BenchmarkEstimator] = []
        for item in payload["estimators"]:
            if not isinstance(item, dict):
                raise InvalidCompositionError(f"BenchmarkSuite spec '{resolved}' has an invalid estimator entry.")
            entry = dict(item)
            model_payload = entry.get("model")
            task_payload = entry.get("task")
            if isinstance(model_payload, dict):
                entry["model"] = ModelSpec(str(model_payload.get("name", "")), **clone_value(model_payload.get("params", {})))
            if isinstance(task_payload, dict):
                entry["task"] = TaskSpec(str(task_payload.get("name", "")), **clone_value(task_payload.get("params", {})))
            if isinstance(entry.get("metrics"), list):
                entry["metrics"] = tuple(entry["metrics"])
            estimators.append(BenchmarkEstimator(**entry))
        return cls(estimators)

    def fit_all(self, output_root: str | Path | None = None) -> "BenchmarkSuite":
        """Fit all estimators and store the resulting reports."""
        resolved_root = coerce_path(output_root)
        reports: list[BenchmarkReport] = []
        for index, estimator in enumerate(self._estimators):
            run_output = None
            if resolved_root is not None:
                label = f"{index:02d}_{estimator.task.name}_{estimator.model.name}"
                run_output = resolved_root / label
            estimator.fit(output_dir=run_output)
            reports.append(estimator.report())
        self._reports = reports
        return self

    def reports(self) -> list[BenchmarkReport]:
        """Return the reports from the last fit_all call."""
        return [report for report in self._reports]

    def scores(self, metric: str = "relative_l2") -> list[dict[str, object]]:
        """Return one comparison-friendly score row per report."""
        rows: list[dict[str, object]] = []
        for report in self._reports:
            summary = report.summary()
            rows.append(
                {
                    "run_dir": str(report.run_dir) if report.run_dir is not None else None,
                    "task_name": summary.get("task_name"),
                    "model_name": summary.get("model_name"),
                    "metric": metric,
                    "score": report.score(metric=metric),
                }
            )
        return rows

    def summary(self, metric: str = "relative_l2") -> list[dict[str, Any]]:
        """Return score rows enriched with report summaries."""
        rows: list[dict[str, Any]] = []
        for report in self._reports:
            report_summary = report.summary()
            rows.append(
                {
                    "run_dir": str(report.run_dir_) if report.run_dir_ is not None else None,
                    "task_name": report_summary.get("task_name"),
                    "model_name": report_summary.get("model_name"),
                    "metric": metric,
                    "score": report.score(metric=metric),
                    "summary": clone_value(report_summary),
                }
            )
        return rows


class BenchmarkComparison:
    """Read-only comparison view over multiple benchmark reports."""

    def __init__(self, reports: list[BenchmarkReport]) -> None:
        if not reports:
            raise InvalidCompositionError("BenchmarkComparison requires at least one BenchmarkReport.")
        self._reports = list(reports)

    def __repr__(self) -> str:
        return f"BenchmarkComparison(num_reports={len(self._reports)!r})"

    def _repr_html_(self) -> str:
        rows = "".join(
            "<tr>"
            f"<td><code>{escape(str(report.summary().get('task_name')))}</code></td>"
            f"<td><code>{escape(str(report.summary().get('model_name')))}</code></td>"
            f"<td><code>{escape(str(report.summary().get('run_dir')))}</code></td>"
            "</tr>"
            for report in self._reports
        )
        if not rows:
            rows = "<tr><td colspan='3'><em>no reports</em></td></tr>"
        return (
            "<div><strong>BenchmarkComparison</strong>"
            "<table><tr><th>task</th><th>model</th><th>run_dir</th></tr>"
            f"{rows}</table></div>"
        )

    @classmethod
    def from_reports(cls, reports: list[BenchmarkReport]) -> "BenchmarkComparison":
        """Build a comparison from existing reports."""
        return cls(reports=reports)

    @classmethod
    def from_run_dirs(cls, run_dirs: list[str | Path]) -> "BenchmarkComparison":
        """Build a comparison from run directories."""
        return cls(reports=[BenchmarkReport.from_run_dir(path) for path in run_dirs])

    @classmethod
    def from_suite(cls, suite: BenchmarkSuite) -> "BenchmarkComparison":
        """Build a comparison from an already-fit suite."""
        reports = suite.reports()
        if not reports:
            raise InvalidCompositionError("BenchmarkComparison.from_suite(...) requires a fitted BenchmarkSuite.")
        return cls(reports=reports)

    def reports(self) -> list[BenchmarkReport]:
        """Return the underlying reports."""
        return list(self._reports)

    def summary(self, metric: str = "relative_l2") -> list[dict[str, Any]]:
        """Return sorted score rows for all reports."""
        rows: list[dict[str, Any]] = []
        for report in self._reports:
            report_summary = report.summary()
            rows.append(
                {
                    "run_dir": str(report.run_dir) if report.run_dir is not None else None,
                    "task_name": report_summary.get("task_name"),
                    "model_name": report_summary.get("model_name"),
                    "metric": metric,
                    "score": report.score(metric=metric),
                    "summary": clone_value(report_summary),
                }
            )
        return sorted(rows, key=lambda item: float(item["score"]))

    def best(self, metric: str = "relative_l2") -> dict[str, Any]:
        """Return the best row under the current lower-is-better benchmark metrics."""
        return self.summary(metric=metric)[0]

    def to_dict(self, metric: str = "relative_l2") -> dict[str, Any]:
        """Return one comparison payload suitable for JSON or notebooks."""
        return {
            "metric": metric,
            "best": self.best(metric=metric),
            "rows": self.summary(metric=metric),
        }

    def metric_names(self) -> list[str]:
        """Return the sorted union of metric names across all reports."""
        metrics: set[str] = set()
        for report in self._reports:
            metrics.update(report.metric_names())
        return sorted(metrics)
