"""Compile easy-layer objects to and from ExperimentConfig."""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any

from pinn_bench.comparison import parse_comparison_config
from pinn_bench.config.loader import load_config
from pinn_bench.config.schema import (
    ComponentConfig,
    EvaluationConfig,
    ExperimentConfig,
    LoggingConfig,
    MetricsConfig,
    OutputConfig,
    RobustnessConfig,
    TrainConfig,
)
from pinn_bench.easy.base import clone_value, coerce_path, merge_mappings, normalize_mapping
from pinn_bench.easy.context import get_easy_config
from pinn_bench.easy.discovery import all_metrics, all_models, all_tasks
from pinn_bench.easy.exceptions import InvalidComponentError, InvalidCompositionError, UnsafeOutputRootError
from pinn_bench.easy.specs import ModelSpec, TaskSpec
from pinn_bench.registry import resolve_model_name
from pinn_bench.resources import resolve_config_path, resolve_repo_root


_ROBUSTNESS_FIELDS = {
    "protocol",
    "level",
    "severity_label",
    "target_scopes",
    "train_time_range",
    "eval_time_range",
    "train_support_ratio",
}
_EVALUATION_FIELDS = {"num_samples", "grid_x", "grid_t", "grid_y"}
_TRAIN_FIELDS = {"epochs", "lr", "seed", "device", "loss_weights"}
_SAFE_OUTPUT_POLICIES = {"strict", "allow_any"}
_CANONICAL_FORMAL_ROOTS = {"outputs_v10", "outputs_v02", "outputs_v03", "outputs_v04", "outputs_v05", "outputs_v06"}
_CANONICAL_PREVIEW_ROOTS = {
    "outputs_preview_v07",
    "outputs_preview_v08",
    "outputs_preview_v09",
    "outputs_preview_v11",
    "outputs_preview_v12",
    "outputs_preview_v13",
    "outputs_preview_v14",
    "outputs_preview_v15",
    "outputs_preview_v16",
    "outputs_preview_v17",
    "outputs_preview_v18",
    "outputs_preview_v19",
}


def normalize_model_spec(value: str | ModelSpec) -> ModelSpec:
    """Normalize model input into a public spec object."""
    if isinstance(value, ModelSpec):
        return value.clone()
    if isinstance(value, str):
        return ModelSpec(value)
    raise InvalidCompositionError("model must be a model name or ModelSpec instance")


def normalize_task_spec(value: str | TaskSpec) -> TaskSpec:
    """Normalize task input into a public spec object."""
    if isinstance(value, TaskSpec):
        return value.clone()
    if isinstance(value, str):
        return TaskSpec(value)
    raise InvalidCompositionError("task must be a task name or TaskSpec instance")


def _is_protected_output_root(path: Path) -> bool:
    resolved = path.resolve()
    names = _CANONICAL_FORMAL_ROOTS | _CANONICAL_PREVIEW_ROOTS
    if resolved.name in names:
        return True
    return any(parent.name in names for parent in resolved.parents)


def ensure_safe_output_root(path: str | Path, *, purpose: str, safe_output_policy: str | None = None) -> Path:
    """Validate one output root against canonical benchmark roots."""
    policy = str(safe_output_policy or get_easy_config()["safe_output_policy"]).strip() or "strict"
    if policy not in _SAFE_OUTPUT_POLICIES:
        allowed = ", ".join(sorted(_SAFE_OUTPUT_POLICIES))
        raise InvalidCompositionError(f"safe_output_policy must be one of: {allowed}")
    resolved = Path(str(path)).expanduser().resolve()
    if policy == "strict" and _is_protected_output_root(resolved):
        raise UnsafeOutputRootError(
            f"Refusing to use canonical benchmark root '{resolved}'. Choose a safe custom path such as outputs_playground/... for {purpose}."
        )
    return resolved


def default_output_dir(*, task_name: str, model_name: str) -> Path:
    """Return the default safe playground run directory for one easy estimator."""
    label = f"{task_name}_{model_name}".strip("_").replace("-", "_")
    return (resolve_repo_root() / "outputs_playground" / f"{label}_preview").resolve()


def resolve_starter_config_path(*, task_name: str, model_name: str) -> Path:
    """Resolve one canonical experiment config for a task/model quickstart pair."""
    candidates = [
        f"{task_name}_{model_name}.yaml",
        f"{task_name}_{model_name.lower()}.yaml",
    ]
    attempted: list[str] = []
    for candidate in candidates:
        try:
            return resolve_config_path(candidate)
        except FileNotFoundError:
            attempted.append(candidate)
    tried = ", ".join(attempted)
    raise InvalidComponentError(
        f"No starter config is available for task '{task_name}' and model '{model_name}'. Tried: {tried}"
    )


def _normalize_component_name(name: str, *, kind: str, strict_validation: bool) -> str:
    normalized = str(name).strip()
    if not normalized:
        raise InvalidComponentError(f"{kind.title()} name must be a non-empty string.")
    if kind == "model":
        try:
            return resolve_model_name(normalized, include_external=True, include_canonical_family=True)
        except KeyError as error:
            if strict_validation:
                raise InvalidComponentError(str(error)) from error
            return normalized
    if not strict_validation:
        return normalized
    allowed = {
        "model": set(all_models()),
        "task": set(all_tasks()),
        "metric": set(all_metrics()),
    }[kind]
    if normalized.lower() not in allowed:
        available = ", ".join(sorted(allowed)) or "<empty>"
        raise InvalidComponentError(f"Unknown {kind} '{name}'. Available: {available}")
    return normalized


def _normalize_robustness_config(payload: Mapping[str, Any] | None) -> RobustnessConfig:
    data = normalize_mapping(payload, location="robustness")
    extras = {key: value for key, value in data.items() if key not in _ROBUSTNESS_FIELDS}
    scopes = data.get("target_scopes", [])
    if scopes is None:
        scopes = []
    if not isinstance(scopes, list):
        raise InvalidCompositionError("robustness.target_scopes must be a list when provided")
    return RobustnessConfig(
        protocol=str(data.get("protocol", "none")),
        level=float(data.get("level", 0.0)),
        severity_label=None if data.get("severity_label") is None else str(data.get("severity_label")),
        target_scopes=[str(scope) for scope in scopes],
        train_time_range=None if data.get("train_time_range") is None else list(data.get("train_time_range")),
        eval_time_range=None if data.get("eval_time_range") is None else list(data.get("eval_time_range")),
        train_support_ratio=(
            None if data.get("train_support_ratio") is None else float(data.get("train_support_ratio"))
        ),
        extras=extras,
    )


def _normalize_evaluation_config(payload: Mapping[str, Any] | None) -> EvaluationConfig:
    data = normalize_mapping(payload, location="evaluation")
    extras = {key: value for key, value in data.items() if key not in _EVALUATION_FIELDS}
    return EvaluationConfig(
        num_samples=int(data.get("num_samples", 256)),
        grid_x=None if data.get("grid_x") is None else int(data.get("grid_x")),
        grid_t=None if data.get("grid_t") is None else int(data.get("grid_t")),
        grid_y=None if data.get("grid_y") is None else int(data.get("grid_y")),
        extras=extras,
    )


def _load_starter_defaults(*, model_name: str, task_name: str) -> ExperimentConfig | None:
    """Best-effort starter config used to hydrate missing easy-layer params."""
    try:
        return load_config(resolve_starter_config_path(task_name=task_name, model_name=model_name))
    except (FileNotFoundError, InvalidComponentError, ValueError, KeyError):
        return None


def estimator_to_config(
    *,
    model: ModelSpec,
    task: TaskSpec,
    epochs: int,
    lr: float,
    seed: int,
    device: str,
    metrics: tuple[str, ...],
    logging_backend: str,
    robustness: Mapping[str, Any] | None,
    comparison: Mapping[str, Any] | None,
    train_extras: Mapping[str, Any] | None,
    evaluation: Mapping[str, Any] | None,
    output_dir: str | Path | None,
    strict_validation: bool | None = None,
    safe_output_policy: str | None = None,
) -> ExperimentConfig:
    """Compile one easy-layer benchmark spec into ExperimentConfig."""
    strict = bool(get_easy_config()["strict_validation"] if strict_validation is None else strict_validation)
    model_name = _normalize_component_name(model.name, kind="model", strict_validation=strict)
    task_name = _normalize_component_name(task.name, kind="task", strict_validation=strict)
    metric_names = tuple(
        _normalize_component_name(metric_name, kind="metric", strict_validation=strict) for metric_name in metrics
    )
    resolved_output_dir = coerce_path(output_dir) or default_output_dir(task_name=task_name, model_name=model_name)
    safe_output_dir = ensure_safe_output_root(
        resolved_output_dir,
        purpose="easy benchmark run",
        safe_output_policy=safe_output_policy,
    )
    starter_defaults = _load_starter_defaults(model_name=model_name, task_name=task_name)

    model_params = merge_mappings(
        None if starter_defaults is None else starter_defaults.model.params,
        model.params,
    )
    task_params = merge_mappings(
        None if starter_defaults is None else starter_defaults.task.params,
        task.params,
    )
    train_payload = merge_mappings(
        None if starter_defaults is None else starter_defaults.train.extras,
        train_extras,
    )
    loss_weights = merge_mappings(
        None if starter_defaults is None else starter_defaults.train.loss_weights,
        train_payload.pop("loss_weights", {}),
    )
    if not isinstance(loss_weights, Mapping):
        raise InvalidCompositionError("train_extras.loss_weights must be a mapping when provided")
    comparison_payload = merge_mappings(
        None if starter_defaults is None or starter_defaults.comparison is None else starter_defaults.comparison.to_dict(),
        comparison,
    )
    evaluation_payload = merge_mappings(
        None if starter_defaults is None else starter_defaults.evaluation.to_dict(),
        evaluation,
    )
    robustness_payload = merge_mappings(
        None if starter_defaults is None else starter_defaults.robustness.to_dict(),
        robustness,
    )

    return ExperimentConfig(
        model=ComponentConfig(name=model_name, params=model_params),
        task=ComponentConfig(name=task_name, params=task_params),
        train=TrainConfig(
            epochs=int(epochs),
            lr=float(lr),
            seed=int(seed),
            device=str(device),
            loss_weights={str(key): float(value) for key, value in dict(loss_weights).items()},
            extras=train_payload,
        ),
        logging=LoggingConfig(backend=str(logging_backend), log_every=1),
        output=OutputConfig(root_dir=str(safe_output_dir)),
        evaluation=_normalize_evaluation_config(evaluation_payload),
        metrics=MetricsConfig(names=list(metric_names)),
        robustness=_normalize_robustness_config(robustness_payload),
        comparison=None if not comparison_payload else parse_comparison_config(comparison_payload),
    )


def config_to_estimator(config: ExperimentConfig, *, output_dir: str | Path | None = None) -> dict[str, Any]:
    """Project one ExperimentConfig into easy-layer constructor kwargs."""
    output_path = coerce_path(output_dir) or coerce_path(config.output.root_dir)
    return {
        "model": ModelSpec(config.model.name, **clone_value(config.model.params)),
        "task": TaskSpec(config.task.name, **clone_value(config.task.params)),
        "epochs": int(config.train.epochs),
        "lr": float(config.train.lr),
        "seed": int(config.train.seed),
        "device": str(config.train.device),
        "metrics": tuple(str(name) for name in config.metrics.names),
        "logging_backend": str(config.logging.backend),
        "robustness": clone_value(config.robustness.to_dict()),
        "comparison": None if config.comparison is None else clone_value(config.comparison.to_dict()),
        "train_extras": {
            **clone_value(config.train.extras),
            "loss_weights": clone_value(config.train.loss_weights),
        },
        "evaluation": clone_value(config.evaluation.to_dict()),
        "output_dir": None if output_path is None else str(output_path),
    }
