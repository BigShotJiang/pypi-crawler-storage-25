"""CLI sugar for the sklearn-like easy API layer."""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from pathlib import Path

from pinn_bench.easy.comparison import BenchmarkComparison
from pinn_bench.easy.discovery import (
    all_external_models,
    all_external_sources,
    all_families,
    all_metrics,
    all_models,
    all_native_models,
    all_primary_methods,
    all_starters,
    all_tasks,
    all_templates,
    all_top_level_families,
    describe_metric,
    describe_family,
    describe_model,
    describe_primary_method,
    describe_starter,
    describe_task,
    query_primary_methods,
    query_models,
)
from pinn_bench.easy.estimator import BenchmarkEstimator
from pinn_bench.easy.report import BenchmarkReport


def build_list_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pinn-bench list",
        description="List easy-layer discoverable resources.",
    )
    parser.add_argument(
        "resource",
        choices=("tasks", "models", "metrics", "templates", "starters", "families", "methods"),
        help="Which resource family to list.",
    )
    parser.add_argument("--native-only", action="store_true", help="When resource=models, show only native models.")
    parser.add_argument("--external-only", action="store_true", help="When resource=models, show only external models.")
    parser.add_argument("--source-benchmark", default=None, help="When resource=models, filter external models by source benchmark.")
    parser.add_argument("--integration-state", default=None, help="When resource=models, filter external models by integration state.")
    parser.add_argument("--category", default=None, help="When resource=models, filter by model category.")
    parser.add_argument("--top-level-family", default=None, help="When resource=methods, filter by top-level family.")
    parser.add_argument("--name", default=None, help="When resource=models/families/methods, return one exact description by name or alias.")
    parser.add_argument("--runnable-only", action="store_true", help="When resource=models, show only runnable models.")
    parser.add_argument("--constructible-only", action="store_true", help="When resource=methods, show only methods with a runnable default path.")
    parser.add_argument("--pinn-family-only", action="store_true", help="When resource=models, show only PINN-family models.")
    parser.add_argument("--operator-family-only", action="store_true", help="When resource=models, show only operator-family models.")
    parser.add_argument("--json", action="store_true", help="Emit JSON instead of plain text.")
    return parser


def build_quickstart_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pinn-bench quickstart",
        description="Run or dry-run one Python-first easy-layer quickstart benchmark.",
    )
    parser.add_argument("--task", required=True, help="Registered task name.")
    parser.add_argument("--model", required=True, help="Registered model name.")
    parser.add_argument("--output-dir", default=None, help="Safe custom output directory.")
    parser.add_argument("--epochs", type=int, default=5, help="Training epochs for the quickstart run.")
    parser.add_argument("--lr", type=float, default=1e-3, help="Learning rate for the quickstart run.")
    parser.add_argument("--seed", type=int, default=42, help="Random seed.")
    parser.add_argument("--device", default="cpu", help="Execution device.")
    parser.add_argument(
        "--log-backend",
        default="none",
        help="Logging backend for the quickstart run.",
    )
    parser.add_argument(
        "--metric",
        action="append",
        dest="metrics",
        default=None,
        help="Metric name to include. Repeat to request multiple metrics.",
    )
    parser.add_argument("--dry-run", action="store_true", help="Compile and print the config without executing.")
    parser.add_argument("--json", action="store_true", help="Emit JSON instead of plain text.")
    return parser


def build_inspect_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pinn-bench inspect",
        description="Inspect one run directory through the easy BenchmarkReport facade.",
    )
    parser.add_argument("--run-dir", required=True, help="Run directory containing stable benchmark artifacts.")
    parser.add_argument("--metric", default="relative_l2", help="Metric to highlight in the summary output.")
    parser.add_argument("--json", action="store_true", help="Emit JSON instead of plain text.")
    return parser


def build_starter_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pinn-bench starter",
        description="Inspect one starter config entry or list the exact starter configs for one task/model pair.",
    )
    parser.add_argument("--id", dest="starter_id", default=None, help="Stable starter id to inspect directly.")
    parser.add_argument("--task", default=None, help="Registered task name.")
    parser.add_argument("--model", default=None, help="Registered model name.")
    parser.add_argument("--json", action="store_true", help="Emit JSON instead of plain text.")
    return parser


def build_compare_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pinn-bench compare",
        description="Compare multiple benchmark run directories through the easy comparison facade.",
    )
    parser.add_argument(
        "--run-dir",
        action="append",
        dest="run_dirs",
        required=True,
        help="Run directory to compare. Repeat this flag for multiple runs.",
    )
    parser.add_argument("--metric", default="relative_l2", help="Metric used for ranking.")
    parser.add_argument("--json", action="store_true", help="Emit JSON instead of plain text.")
    return parser


def _list_payload(args: argparse.Namespace) -> list[str]:
    mapping = {
        "tasks": all_tasks,
        "metrics": all_metrics,
        "templates": all_templates,
        "starters": all_starters,
        "families": all_families,
        "methods": all_primary_methods,
    }
    if args.resource != "models":
        if args.resource == "methods":
            return all_primary_methods(
                top_level_family=args.top_level_family,
                constructible_only=args.constructible_only,
            )
        return mapping[args.resource]()
    if args.native_only and args.external_only:
        raise SystemExit("--native-only and --external-only are mutually exclusive.")
    if args.native_only:
        payload = all_native_models()
        if args.pinn_family_only:
            payload = [name for name in payload if name in {"mlp", "siren", "adaptive_mlp", "xpinn_mlp"}]
        if args.operator_family_only:
            payload = [name for name in payload if name in {"mini_fno", "grid_mlp", "spectral_mlp"}]
        return payload
    if args.external_only:
        return all_external_models(
            source_benchmark=args.source_benchmark,
            integration_state=args.integration_state,
            model_category=args.category,
            runnable_only=args.runnable_only,
            pinn_family_only=args.pinn_family_only,
            operator_family_only=args.operator_family_only,
        )
    return all_models(
        source_benchmark=args.source_benchmark,
        integration_state=args.integration_state,
        model_category=args.category,
        runnable_only=args.runnable_only,
        pinn_family_only=args.pinn_family_only,
        operator_family_only=args.operator_family_only,
    )


def list_main(argv: Sequence[str] | None = None) -> None:
    args = build_list_parser().parse_args(argv)
    if args.resource in {"models", "families", "methods"} and args.name is not None:
        payload = (
            describe_model(args.name)
            if args.resource == "models"
            else describe_family(args.name)
            if args.resource == "families"
            else describe_primary_method(args.name)
        )
        if args.json:
            print(json.dumps(payload, indent=2))
            return
        print(payload["name"])
        return
    payload = _list_payload(args)
    if args.json:
        if args.resource == "models":
            items = query_models(
                native_only=args.native_only,
                external_only=args.external_only,
                source_benchmark=args.source_benchmark,
                integration_state=args.integration_state,
                model_category=args.category,
                runnable_only=args.runnable_only,
                pinn_family_only=args.pinn_family_only,
                operator_family_only=args.operator_family_only,
            )
        elif args.resource == "families":
            items = [describe_family(name) for name in payload]
        elif args.resource == "methods":
            items = [describe_primary_method(name) for name in payload]
        elif args.resource == "tasks":
            items = [
                {
                    "name": name,
                    "docs_path": describe_task(name).get("docs_path"),
                    "starter_config_count": describe_task(name).get("starter_config_count"),
                }
                for name in payload
            ]
        elif args.resource == "metrics":
            items = [
                {
                    "name": name,
                    "source_path": describe_metric(name).get("source_path"),
                }
                for name in payload
            ]
        elif args.resource == "starters":
            items = [describe_starter(name) for name in payload]
        else:
            items = [{"name": name} for name in payload]
        extra_payload = {}
        if args.resource == "models":
            extra_payload = {
                "native_only": bool(args.native_only),
                "external_only": bool(args.external_only),
                "source_benchmarks": all_external_sources(),
            }
        elif args.resource == "methods":
            extra_payload = {
                "top_level_families": all_top_level_families(),
            }
        print(json.dumps({"resource": args.resource, "count": len(payload), "items": items, **extra_payload}, indent=2))
        return
    print("\n".join(payload))


def quickstart_main(argv: Sequence[str] | None = None) -> None:
    args = build_quickstart_parser().parse_args(argv)
    estimator = BenchmarkEstimator(
        model=args.model,
        task=args.task,
        epochs=args.epochs,
        lr=args.lr,
        seed=args.seed,
        device=args.device,
        logging_backend=args.log_backend,
        metrics=tuple(args.metrics or ("mse", "relative_l2")),
        output_dir=args.output_dir,
    )
    if args.dry_run:
        config = estimator.to_config()
        payload = {
            "task": args.task,
            "model": args.model,
            "output_dir": config.output.root_dir,
            "config": config.to_dict(),
        }
        if args.json:
            print(json.dumps(payload, indent=2))
            return
        print(f"task={payload['task']}")
        print(f"model={payload['model']}")
        print(f"output_dir={payload['output_dir']}")
        return

    estimator.fit(output_dir=args.output_dir)
    report = estimator.report()
    summary = report.summary()
    payload = {
        "run_dir": None if estimator.run_dir_ is None else str(estimator.run_dir_),
        "score_metric": args.metric,
        "score": report.score(metric=args.metric),
        "summary": summary,
    }
    if args.json:
        print(json.dumps(payload, indent=2))
        return
    print(f"run_dir={payload['run_dir']}")
    print(f"{args.metric}={payload['score']}")


def inspect_main(argv: Sequence[str] | None = None) -> None:
    args = build_inspect_parser().parse_args(argv)
    report = BenchmarkReport.from_run_dir(Path(args.run_dir))
    payload = {
        "run_dir": str(Path(args.run_dir).expanduser().resolve()),
        "score_metric": args.metric,
        "score": report.score(metric=args.metric),
        "summary": report.summary(),
    }
    if args.json:
        print(json.dumps(payload, indent=2))
        return
    print(f"run_dir={payload['run_dir']}")
    print(f"{args.metric}={payload['score']}")


def starter_main(argv: Sequence[str] | None = None) -> None:
    args = build_starter_parser().parse_args(argv)
    if args.starter_id is not None:
        payload = describe_starter(args.starter_id)
        if args.json:
            print(json.dumps(payload, indent=2))
            return
        print(payload["starter_id"])
        print(payload["config_path"])
        return

    if not args.task or not args.model:
        raise SystemExit("starter requires either --id or both --task and --model.")

    task_payload = describe_task(args.task)
    model_payload = describe_model(args.model)
    model_paths = set(model_payload.get("starter_config_paths", []))
    task_paths = set(task_payload.get("starter_config_paths", []))
    shared = sorted(model_paths & task_paths)
    payload = {
        "task": args.task,
        "model": args.model,
        "starter_config_paths": shared,
    }
    if args.json:
        print(json.dumps(payload, indent=2))
        return
    print("\n".join(shared))


def compare_main(argv: Sequence[str] | None = None) -> None:
    args = build_compare_parser().parse_args(argv)
    comparison = BenchmarkComparison.from_run_dirs(args.run_dirs)
    payload = {
        "metric": args.metric,
        "best": comparison.best(metric=args.metric),
        "rows": comparison.summary(metric=args.metric),
    }
    if args.json:
        print(json.dumps(payload, indent=2))
        return
    for row in payload["rows"]:
        print(f"{row['score']}\t{row['task_name']}\t{row['model_name']}\t{row['run_dir']}")
