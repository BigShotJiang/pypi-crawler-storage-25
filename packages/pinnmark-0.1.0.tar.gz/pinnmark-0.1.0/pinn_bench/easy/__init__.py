"""sklearn-like public API facade built on the pinn_bench benchmark kernel."""

from pinn_bench.easy.comparison import BenchmarkComparison, BenchmarkSuite
from pinn_bench.easy.compliance import EasyComplianceReport, check_easy_estimator
from pinn_bench.easy.context import easy_config_context, get_easy_config, set_easy_config
from pinn_bench.easy.discovery import (
    all_external_models,
    all_external_sources,
    all_families,
    all_metrics,
    all_models,
    all_native_models,
    all_primary_methods,
    all_starters,
    all_tasks,
    all_templates,
    all_top_level_families,
    describe_metric,
    describe_family,
    describe_model,
    describe_primary_method,
    describe_starter,
    describe_task,
    query_primary_methods,
    query_models,
)
from pinn_bench.easy.estimator import BenchmarkEstimator
from pinn_bench.easy.exceptions import (
    EasyAPIError,
    InvalidComponentError,
    InvalidCompositionError,
    NotExecutedError,
    UnsafeOutputRootError,
)
from pinn_bench.easy.report import BenchmarkReport
from pinn_bench.easy.specs import ModelSpec, TaskSpec
from pinn_bench.easy.study import BenchmarkStudy, BenchmarkSweep, ParameterGrid, ParameterSampler

__all__ = [
    "BenchmarkComparison",
    "BenchmarkEstimator",
    "BenchmarkReport",
    "BenchmarkStudy",
    "BenchmarkSuite",
    "BenchmarkSweep",
    "EasyComplianceReport",
    "EasyAPIError",
    "InvalidComponentError",
    "InvalidCompositionError",
    "ModelSpec",
    "NotExecutedError",
    "ParameterGrid",
    "ParameterSampler",
    "TaskSpec",
    "UnsafeOutputRootError",
    "all_starters",
    "all_external_models",
    "all_external_sources",
    "all_families",
    "all_metrics",
    "all_models",
    "all_native_models",
    "all_primary_methods",
    "all_tasks",
    "all_templates",
    "all_top_level_families",
    "check_easy_estimator",
    "describe_metric",
    "describe_family",
    "describe_model",
    "describe_primary_method",
    "describe_starter",
    "describe_task",
    "easy_config_context",
    "get_easy_config",
    "query_primary_methods",
    "query_models",
    "set_easy_config",
]
