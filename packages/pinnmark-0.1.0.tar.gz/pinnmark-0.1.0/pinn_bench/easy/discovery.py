"""Discoverability helpers for the easy API layer."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import inspect
from pathlib import Path
import re
from typing import Any

import pinn_bench.metrics  # noqa: F401
import pinn_bench.models  # noqa: F401
import pinn_bench.tasks  # noqa: F401
from pinn_bench.api.user_api import list_config_templates
from pinn_bench.config.loader import load_config
from pinn_bench.easy.exceptions import InvalidComponentError
from pinn_bench.models.external_adapters import get_external_adapter
from pinn_bench.models.external_registry import get_external_model_record, list_external_model_records, list_external_source_benchmarks
from pinn_bench.models.primary_method_registry import list_primary_method_records, resolve_primary_method_record
from pinn_bench.registry import get_model_catalog_entry
from pinn_bench.registry import get_family_internalization_state
from pinn_bench.registry import get_family_lineage as registry_get_family_lineage
from pinn_bench.registry import get_family_variants as registry_get_family_variants
from pinn_bench.registry import list_canonical_families as list_registered_families
from pinn_bench.registry import list_all_models as list_registered_all_models
from pinn_bench.registry import list_external_models as list_registered_external_models
from pinn_bench.registry import list_metrics as list_registered_metrics
from pinn_bench.registry import list_models as list_registered_models
from pinn_bench.registry import list_primary_methods as list_registered_primary_methods
from pinn_bench.registry import list_tasks as list_registered_tasks
from pinn_bench.registry import list_top_level_families as list_registered_top_level_families
from pinn_bench.resources import resolve_repo_root
from pinn_bench.robustness.protocols import _TASK_DEFAULT_TARGET_SCOPES, _TASK_PROTOCOL_DEFAULT_TARGET_SCOPES
from pinn_bench.tasks.base import BaseTask

_SIGNATURE_KIND_NAMES = {
    inspect.Parameter.POSITIONAL_ONLY: "positional_only",
    inspect.Parameter.POSITIONAL_OR_KEYWORD: "positional_or_keyword",
    inspect.Parameter.VAR_POSITIONAL: "var_positional",
    inspect.Parameter.KEYWORD_ONLY: "keyword_only",
    inspect.Parameter.VAR_KEYWORD: "var_keyword",
}
_EXPECTED_OUTPUTS = (
    "config_snapshot.yaml",
    "metrics.json",
    "train_log.csv",
    "model.pt",
    "loss_curve.png",
)
_FORMAL_OUTPUT_ROOTS = {
    "outputs": "v0.1",
    "outputs_v02": "v0.2",
    "outputs_v03": "v0.3",
    "outputs_v04": "v0.4",
    "outputs_v05": "v0.5",
    "outputs_v06": "v0.6",
    "outputs_v10": "v1.0",
}
_PREVIEW_PATTERN = re.compile(r"^outputs_preview_v(\d+)$")
_FORMAL_PATTERN = re.compile(r"^outputs_v(\d+)$")


@dataclass(frozen=True)
class StarterCatalogEntry:
    """Stable metadata for one starter config in the easy catalog."""

    starter_id: str
    task_name: str
    model_name: str
    profile: str
    config_path: str
    benchmark_line: str
    tags: tuple[str, ...]
    expected_outputs: tuple[str, ...]
    supports_robustness: bool
    supports_comparison: bool

    def to_dict(self) -> dict[str, object]:
        return {
            "starter_id": self.starter_id,
            "task_name": self.task_name,
            "model_name": self.model_name,
            "profile": self.profile,
            "config_path": self.config_path,
            "benchmark_line": self.benchmark_line,
            "tags": list(self.tags),
            "expected_outputs": list(self.expected_outputs),
            "supports_robustness": self.supports_robustness,
            "supports_comparison": self.supports_comparison,
        }


def query_models(
    *,
    native_only: bool = False,
    external_only: bool = False,
    source_benchmark: str | None = None,
    integration_state: str | None = None,
    model_category: str | None = None,
    runnable_only: bool = False,
    pinn_family_only: bool = False,
    operator_family_only: bool = False,
) -> list[dict[str, object]]:
    """Return unified model identity records with filtering."""
    payload: list[dict[str, object]] = []
    if not external_only:
        for name in list_registered_models():
            entry = get_model_catalog_entry(name)
            if model_category is not None and model_category != "native":
                continue
            if source_benchmark is not None:
                continue
            if integration_state is not None and integration_state != "native":
                continue
            if pinn_family_only and not bool(entry.get("is_pinn_family")):
                continue
            if operator_family_only and not bool(entry.get("is_operator_family")):
                continue
            if runnable_only and entry.get("runnable_status") != "runnable":
                continue
            payload.append(entry)
    if not native_only:
        payload.extend(
            record.to_dict()
            for record in list_external_model_records(
                source_benchmark=source_benchmark,
                integration_state=integration_state,
                model_category=model_category,
                runnable_only=runnable_only,
                pinn_family_only=pinn_family_only,
                operator_family_only=operator_family_only,
            )
        )
    return sorted(payload, key=lambda item: str(item.get("canonical_name") or item.get("name") or ""))


def all_models(
    *,
    native_only: bool = False,
    external_only: bool = False,
    source_benchmark: str | None = None,
    integration_state: str | None = None,
    model_category: str | None = None,
    runnable_only: bool = False,
    pinn_family_only: bool = False,
    operator_family_only: bool = False,
) -> list[str]:
    """Return the unified native + external model universe."""
    return [
        str(item.get("canonical_name") or item.get("name"))
        for item in query_models(
            native_only=native_only,
            external_only=external_only,
            source_benchmark=source_benchmark,
            integration_state=integration_state,
            model_category=model_category,
            runnable_only=runnable_only,
            pinn_family_only=pinn_family_only,
            operator_family_only=operator_family_only,
        )
    ]


def all_native_models() -> list[str]:
    """Return sorted native registered model names."""
    return list_registered_models()


def all_external_models(
    *,
    source_benchmark: str | None = None,
    integration_state: str | None = None,
    model_category: str | None = None,
    runnable_only: bool = False,
    pinn_family_only: bool = False,
    operator_family_only: bool = False,
) -> list[str]:
    """Return filtered external model names."""
    return list_registered_external_models(
        source_benchmark=source_benchmark,
        integration_state=integration_state,
        model_category=model_category,
        runnable_only=runnable_only,
        pinn_family_only=pinn_family_only,
        operator_family_only=operator_family_only,
    )


def all_external_sources() -> list[str]:
    """Return sorted external source benchmark ids."""
    return list_external_source_benchmarks()


def all_families() -> list[str]:
    """Return sorted canonical family ids."""
    return list_registered_families()


def all_top_level_families() -> list[str]:
    """Return sorted top-level family ids."""
    return list_registered_top_level_families()


def query_primary_methods(
    *,
    top_level_family: str | None = None,
    constructible_only: bool = False,
) -> list[dict[str, object]]:
    """Return primary benchmark-method records."""
    payload: list[dict[str, object]] = []
    for record in list_primary_method_records():
        if top_level_family is not None and record.top_level_family != str(top_level_family):
            continue
        if constructible_only and record.runnable_status != "runnable":
            continue
        payload.append(get_model_catalog_entry(record.method_id))
    return sorted(payload, key=lambda item: str(item["canonical_name"]))


def all_primary_methods(
    *,
    top_level_family: str | None = None,
    constructible_only: bool = False,
) -> list[str]:
    """Return sorted primary benchmark-method ids."""
    return [
        str(item["canonical_name"])
        for item in query_primary_methods(
            top_level_family=top_level_family,
            constructible_only=constructible_only,
        )
    ]


def all_tasks() -> list[str]:
    """Return sorted registered task names."""
    return list_registered_tasks()


def all_metrics() -> list[str]:
    """Return sorted registered metric names."""
    return list_registered_metrics()


def all_templates() -> list[str]:
    """Return built-in config template names."""
    return list_config_templates()


def all_starters() -> list[str]:
    """Return the sorted starter ids derived from `configs/experiment`."""
    return sorted(_starter_catalog())


def describe_family(family_id: str) -> dict[str, object]:
    """Describe one canonical family plus its variants and lineage."""
    from pinn_bench.models.native_family_registry import get_canonical_family_record

    record = get_canonical_family_record(family_id)
    return {
        "name": record.family_id,
        "kind": "family",
        **record.to_dict(),
        "internalization_state": get_family_internalization_state(family_id),
        "variants": registry_get_family_variants(family_id),
        "lineage": registry_get_family_lineage(family_id),
    }


def describe_primary_method(name: str) -> dict[str, object]:
    """Describe one primary benchmark method."""
    record = resolve_primary_method_record(name)
    if record is None:
        raise InvalidComponentError(
            f"Unknown primary method '{name}'. Available: {', '.join(list_registered_primary_methods()) or '<empty>'}"
        )
    payload = get_model_catalog_entry(record.method_id)
    payload.update(
        {
            "doc": record.notes,
            "source_path": None,
            "signature": [],
            "accepts_var_keyword": True,
            "docs_path": None,
            "docs_summary_excerpt": None,
            "starter_config_paths": [],
            "starter_config_count": 0,
            "example_paths": [],
        }
    )
    return payload


def _component_signature(component: object) -> tuple[list[dict[str, object]], bool]:
    target = component.__init__ if inspect.isclass(component) else component
    parameters = list(inspect.signature(target).parameters.values())
    if inspect.isclass(component):
        parameters = [parameter for parameter in parameters if parameter.name != "self"]

    payload: list[dict[str, object]] = []
    accepts_var_keyword = False
    for parameter in parameters:
        if parameter.kind is inspect.Parameter.VAR_KEYWORD:
            accepts_var_keyword = True
        default_repr = None
        required = parameter.default is inspect.Signature.empty and parameter.kind not in {
            inspect.Parameter.VAR_POSITIONAL,
            inspect.Parameter.VAR_KEYWORD,
        }
        if parameter.default is not inspect.Signature.empty:
            default_repr = repr(parameter.default)
        payload.append(
            {
                "name": parameter.name,
                "kind": _SIGNATURE_KIND_NAMES[parameter.kind],
                "required": required,
                "default_repr": default_repr,
            }
        )
    return payload, accepts_var_keyword


def _repo_relative_path(path: str | Path | None) -> str | None:
    if path is None:
        return None
    resolved = Path(str(path)).resolve()
    repo_root = resolve_repo_root()
    try:
        return str(resolved.relative_to(repo_root))
    except ValueError:
        return None


def _docs_path_for(*, name: str, kind: str) -> str | None:
    repo_root = resolve_repo_root()
    base = repo_root / "docs" / ("models" if kind == "model" else "tasks")
    candidate = base / f"{name}-card.md"
    if candidate.exists():
        return str(candidate.relative_to(repo_root))
    return None


def _docs_summary_excerpt(path: str | None) -> str | None:
    if path is None:
        return None
    repo_root = resolve_repo_root()
    text = (repo_root / path).read_text(encoding="utf-8")
    lines = [line.strip() for line in text.splitlines()]
    for index, line in enumerate(lines):
        if line == "## Purpose":
            for candidate in lines[index + 1 :]:
                if candidate and not candidate.startswith("#"):
                    return candidate
    for candidate in lines:
        if candidate and not candidate.startswith("#") and not candidate.startswith("---"):
            return candidate
    return None


def _infer_benchmark_line_from_output_root(root_dir: str | None) -> str:
    if not root_dir:
        return "custom"
    top_level = Path(str(root_dir)).parts[0] if Path(str(root_dir)).parts else ""
    if top_level in _FORMAL_OUTPUT_ROOTS:
        return _FORMAL_OUTPUT_ROOTS[top_level]
    preview_match = _PREVIEW_PATTERN.match(top_level)
    if preview_match:
        raw = int(preview_match.group(1))
        return f"v{raw // 10}.{raw % 10}-preview"
    formal_match = _FORMAL_PATTERN.match(top_level)
    if formal_match:
        raw = int(formal_match.group(1))
        if raw < 10:
            return f"v0.{raw}"
        return f"v{raw // 10}.{raw % 10}"
    return "custom"


def _infer_starter_profile(*, stem: str, task_name: str, model_name: str) -> str:
    stem_tokens = [token for token in stem.split("_") if token]
    task_tokens = [token for token in task_name.split("_") if token]
    model_tokens = [token for token in model_name.split("_") if token]

    remainder = list(stem_tokens)
    if remainder[: len(task_tokens)] == task_tokens:
        remainder = remainder[len(task_tokens) :]
    if remainder[: len(model_tokens)] == model_tokens:
        remainder = remainder[len(model_tokens) :]
    if not remainder:
        return "default"
    return "_".join(remainder)


def _starter_supports_robustness(task_name: str) -> bool:
    normalized = str(task_name).strip().lower()
    return normalized in _TASK_DEFAULT_TARGET_SCOPES or normalized in _TASK_PROTOCOL_DEFAULT_TARGET_SCOPES


def _starter_tags(*, task_name: str, model_name: str, profile: str, benchmark_line: str) -> tuple[str, ...]:
    tags = {
        f"task:{task_name}",
        f"model:{model_name}",
        f"profile:{profile}",
        f"line:{benchmark_line}",
    }
    if profile == "default":
        tags.add("starter:canonical")
    if "starter" in profile:
        tags.add("starter:lightweight")
    if any(token in profile for token in ("noise", "sparsity", "extrapolation")):
        tags.add("workflow:robustness")
    if "shift" in profile:
        tags.add("workflow:regime")
    if "field" in task_name or "operator" in task_name:
        tags.add("mode:field")
    return tuple(sorted(tags))


@lru_cache(maxsize=1)
def _starter_config_index() -> dict[str, dict[str, list[str]]]:
    repo_root = resolve_repo_root()
    configs_root = repo_root / "configs" / "experiment"
    index = {
        "model": {},
        "task": {},
    }
    for path in sorted(configs_root.glob("*.yaml")):
        try:
            config = load_config(path)
        except (FileNotFoundError, KeyError, ValueError):
            continue
        model_name = str(config.model.name).strip().lower()
        task_name = str(config.task.name).strip().lower()
        relative = str(path.relative_to(repo_root))
        index["model"].setdefault(model_name, []).append(relative)
        index["task"].setdefault(task_name, []).append(relative)
    return index


@lru_cache(maxsize=1)
def _starter_catalog() -> dict[str, StarterCatalogEntry]:
    repo_root = resolve_repo_root()
    configs_root = repo_root / "configs" / "experiment"
    catalog: dict[str, StarterCatalogEntry] = {}
    for path in sorted(configs_root.glob("*.yaml")):
        try:
            config = load_config(path)
        except (FileNotFoundError, KeyError, ValueError):
            continue
        task_name = str(config.task.name).strip().lower()
        model_name = str(config.model.name).strip().lower()
        profile = _infer_starter_profile(stem=path.stem, task_name=task_name, model_name=model_name)
        starter_id = f"{task_name}::{model_name}::{profile}"
        benchmark_line = _infer_benchmark_line_from_output_root(config.output.root_dir)
        catalog[starter_id] = StarterCatalogEntry(
            starter_id=starter_id,
            task_name=task_name,
            model_name=model_name,
            profile=profile,
            config_path=str(path.relative_to(repo_root)),
            benchmark_line=benchmark_line,
            tags=_starter_tags(
                task_name=task_name,
                model_name=model_name,
                profile=profile,
                benchmark_line=benchmark_line,
            ),
            expected_outputs=_EXPECTED_OUTPUTS,
            supports_robustness=_starter_supports_robustness(task_name),
            supports_comparison=config.comparison is not None,
        )
    return catalog


def describe_starter(starter_id: str) -> dict[str, object]:
    """Describe one starter config from the checked-in starter catalog."""
    key = str(starter_id).strip().lower()
    catalog = _starter_catalog()
    if key not in catalog:
        available = ", ".join(sorted(catalog)) or "<empty>"
        raise InvalidComponentError(f"Unknown starter '{starter_id}'. Available: {available}")
    return catalog[key].to_dict()


def _component_source_path(component: object) -> str | None:
    try:
        source_path = inspect.getsourcefile(component)
    except (TypeError, OSError):
        return None
    return _repo_relative_path(source_path)


def _example_paths_for(*, name: str, kind: str) -> list[str]:
    repo_root = resolve_repo_root()
    examples_root = repo_root / "examples" / "easy"
    results: list[str] = []
    for path in sorted(examples_root.glob("*.py")):
        content = path.read_text(encoding="utf-8")
        needle = f'{kind}="{name}"'
        single_quoted = f"{kind}='{name}'"
        if needle in content or single_quoted in content:
            results.append(str(path.relative_to(repo_root)))
    return results


def _task_supported_metrics(component: object) -> list[str]:
    metrics = set(all_metrics())
    compute_metric = getattr(component, "compute_metric", None)
    if compute_metric is None or compute_metric is BaseTask.compute_metric:
        return sorted(metrics)
    try:
        source = inspect.getsource(compute_metric)
    except (OSError, TypeError):
        return sorted(metrics)
    for token in ("residual_metric",):
        if token in source:
            metrics.add(token)
    return sorted(metrics)


def _describe_component(name: str, registry: dict[str, object], *, kind: str) -> dict[str, object]:
    key = str(name).strip().lower()
    if key not in registry:
        available = ", ".join(sorted(registry)) or "<empty>"
        raise InvalidComponentError(f"Unknown {kind} '{name}'. Available: {available}")
    component = registry[key]
    signature, accepts_var_keyword = _component_signature(component)
    docs_path = None if kind == "metric" else _docs_path_for(name=key, kind=kind)
    starter_config_paths = [] if kind == "metric" else list(_starter_config_index()[kind].get(key, []))
    payload: dict[str, Any] = {
        "name": key,
        "kind": kind,
        "module": getattr(component, "__module__", ""),
        "qualname": getattr(component, "__qualname__", getattr(component, "__name__", "")),
        "doc": inspect.getdoc(component) or "",
        "source_path": _component_source_path(component),
        "signature": signature,
        "accepts_var_keyword": accepts_var_keyword,
        "docs_path": docs_path,
        "starter_config_paths": starter_config_paths,
    }
    payload["starter_config_count"] = len(payload["starter_config_paths"])
    payload["docs_summary_excerpt"] = _docs_summary_excerpt(payload["docs_path"])
    payload["example_paths"] = _example_paths_for(name=key, kind=kind)
    if kind == "model":
        payload["model_mode"] = str(getattr(component, "model_mode", "pointwise"))
        payload["supports_flattened_field"] = bool(getattr(component, "supports_flattened_field", False))
    else:
        payload["task_mode"] = str(getattr(component, "task_mode", "pointwise"))
        payload["supports_operator"] = bool(getattr(component, "supports_operator", False))
        payload["supported_metrics"] = _task_supported_metrics(component)
    return payload


def _describe_external_model(name: str) -> dict[str, object]:
    record = get_external_model_record(name)
    if record is None:
        available = ", ".join(all_models(external_only=True)) or "<empty>"
        raise InvalidComponentError(f"Unknown model '{name}'. Available: {available}")
    payload = get_model_catalog_entry(name)
    adapter_source = None
    adapter_doc = ""
    signature: list[dict[str, object]] = []
    accepts_var_keyword = True
    if record.adapter_name:
        try:
            adapter = get_external_adapter(record.adapter_name)
            adapter_source = _component_source_path(adapter.__class__)
            adapter_doc = inspect.getdoc(adapter.__class__) or ""
            signature = adapter.signature_payload()
        except Exception:
            adapter_source = None
    payload.update(
        {
            "name": record.canonical_name,
            "kind": "model",
            "module": "pinn_bench.models.external_registry",
            "qualname": "ExternalModelRecord",
            "doc": adapter_doc or record.notes,
            "source_path": record.repo_path,
            "signature": signature,
            "accepts_var_keyword": accepts_var_keyword,
            "docs_path": None,
            "docs_summary_excerpt": None,
            "starter_config_paths": [],
            "starter_config_count": 0,
            "example_paths": [],
            "model_mode": "field" if record.is_operator_family else "pointwise",
            "supports_flattened_field": bool(record.is_operator_family),
            "adapter_source_path": adapter_source,
        }
    )
    return payload


def describe_model(name: str) -> dict[str, object]:
    """Describe one registered model class or factory."""
    from pinn_bench import registry as registry_module

    try:
        entry = get_model_catalog_entry(name)
    except Exception:
        entry = None
    if entry is not None and entry.get("kind") == "primary_method":
        return describe_primary_method(name)
    if entry is not None and entry.get("integration_state") != "native":
        return _describe_external_model(name)
    return _describe_component(name, registry_module._MODEL_REGISTRY, kind="model")  # type: ignore[attr-defined]


def describe_task(name: str) -> dict[str, object]:
    """Describe one registered task class or factory."""
    from pinn_bench import registry as registry_module

    return _describe_component(name, registry_module._TASK_REGISTRY, kind="task")  # type: ignore[attr-defined]


def describe_metric(name: str) -> dict[str, object]:
    """Describe one registered metric function."""
    from pinn_bench import registry as registry_module

    key = str(name).strip().lower()
    registry = registry_module._METRIC_REGISTRY  # type: ignore[attr-defined]
    if key not in registry:
        available = ", ".join(sorted(registry)) or "<empty>"
        raise InvalidComponentError(f"Unknown metric '{name}'. Available: {available}")
    component = registry[key]
    signature, accepts_var_keyword = _component_signature(component)
    return {
        "name": key,
        "kind": "metric",
        "module": getattr(component, "__module__", ""),
        "qualname": getattr(component, "__qualname__", getattr(component, "__name__", "")),
        "doc": inspect.getdoc(component) or "",
        "source_path": _component_source_path(component),
        "signature": signature,
        "accepts_var_keyword": accepts_var_keyword,
    }
