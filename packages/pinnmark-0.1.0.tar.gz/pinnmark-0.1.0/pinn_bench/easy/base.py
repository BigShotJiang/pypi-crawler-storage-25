"""Shared helpers for the sklearn-like easy API layer."""

from __future__ import annotations

from collections.abc import Mapping
from copy import deepcopy
from pathlib import Path
from typing import Any


def clone_value(value: Any) -> Any:
    """Return a defensive deep copy."""
    return deepcopy(value)


def normalize_mapping(value: Mapping[str, Any] | None, *, location: str) -> dict[str, Any]:
    """Normalize an optional mapping into a plain dict."""
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise ValueError(f"Expected mapping at '{location}', got {type(value).__name__}.")
    return deepcopy(dict(value))


def merge_mappings(base: Mapping[str, Any] | None, override: Mapping[str, Any] | None) -> dict[str, Any]:
    """Return a deep merged mapping where override values win."""
    merged = normalize_mapping(base, location="base")
    for key, value in normalize_mapping(override, location="override").items():
        existing = merged.get(key)
        if isinstance(existing, Mapping) and isinstance(value, Mapping):
            merged[str(key)] = merge_mappings(existing, value)
        else:
            merged[str(key)] = clone_value(value)
    return merged


def flatten_prefixed(prefix: str, value: Any) -> dict[str, Any]:
    """Flatten nested mappings into sklearn-style __-separated keys."""
    flattened: dict[str, Any] = {}
    if isinstance(value, Mapping):
        for key, nested_value in value.items():
            nested_prefix = f"{prefix}__{key}" if prefix else str(key)
            if isinstance(nested_value, Mapping):
                flattened.update(flatten_prefixed(nested_prefix, nested_value))
            else:
                flattened[nested_prefix] = clone_value(nested_value)
        return flattened
    flattened[prefix] = clone_value(value)
    return flattened


def set_nested_mapping_value(target: dict[str, Any], path: list[str], value: Any) -> None:
    """Set one nested dict path, creating intermediate mappings when needed."""
    cursor = target
    for part in path[:-1]:
        existing = cursor.get(part)
        if not isinstance(existing, Mapping):
            existing = {}
        child = dict(existing)
        cursor[part] = child
        cursor = child
    cursor[path[-1]] = clone_value(value)


def coerce_path(value: str | Path | None) -> Path | None:
    """Normalize an optional path-like value."""
    if value is None:
        return None
    return Path(str(value)).expanduser().resolve()
