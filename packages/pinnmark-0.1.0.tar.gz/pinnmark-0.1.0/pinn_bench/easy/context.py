"""Global easy-layer configuration helpers."""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import asdict, dataclass
from typing import Iterator

from pinn_bench.easy.base import clone_value
from pinn_bench.easy.exceptions import InvalidCompositionError

_SAFE_OUTPUT_POLICIES = {"strict", "allow_any"}


@dataclass(frozen=True)
class EasyConfig:
    """Process-wide easy API defaults."""

    default_device: str = "cpu"
    default_logging_backend: str = "none"
    strict_validation: bool = True
    safe_output_policy: str = "strict"


_STATE = EasyConfig()


def _validate_safe_output_policy(value: str) -> str:
    normalized = str(value).strip() or "strict"
    if normalized not in _SAFE_OUTPUT_POLICIES:
        allowed = ", ".join(sorted(_SAFE_OUTPUT_POLICIES))
        raise InvalidCompositionError(f"safe_output_policy must be one of: {allowed}")
    return normalized


def get_easy_config() -> dict[str, object]:
    """Return the current easy-layer configuration as a plain dict."""
    return clone_value(asdict(_STATE))


def set_easy_config(
    *,
    default_device: str | None = None,
    default_logging_backend: str | None = None,
    strict_validation: bool | None = None,
    safe_output_policy: str | None = None,
) -> dict[str, object]:
    """Update one or more easy-layer defaults."""
    global _STATE
    payload = asdict(_STATE)
    if default_device is not None:
        payload["default_device"] = str(default_device)
    if default_logging_backend is not None:
        payload["default_logging_backend"] = str(default_logging_backend)
    if strict_validation is not None:
        payload["strict_validation"] = bool(strict_validation)
    if safe_output_policy is not None:
        payload["safe_output_policy"] = _validate_safe_output_policy(safe_output_policy)
    _STATE = EasyConfig(**payload)
    return get_easy_config()


@contextmanager
def easy_config_context(**kwargs: object) -> Iterator[dict[str, object]]:
    """Temporarily override easy-layer defaults within a context manager."""
    global _STATE
    previous = _STATE
    set_easy_config(**kwargs)
    try:
        yield get_easy_config()
    finally:
        _STATE = previous
