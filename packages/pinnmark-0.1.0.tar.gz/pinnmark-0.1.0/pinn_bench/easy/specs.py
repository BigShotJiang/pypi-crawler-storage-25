"""User-facing component specifications for the easy API layer."""

from __future__ import annotations

from html import escape
from pathlib import Path
from typing import Any

import yaml

from pinn_bench.easy.base import clone_value, normalize_mapping, set_nested_mapping_value


class _ComponentSpec:
    """Common implementation for lightweight public component specs."""

    kind = "component"

    def __init__(self, name: str, **params: Any) -> None:
        normalized = str(name).strip()
        if not normalized:
            raise ValueError(f"{self.kind.title()} name must be a non-empty string.")
        self.name = normalized
        self.params = dict(params)

    def __repr__(self) -> str:
        return f"{type(self).__name__}(name={self.name!r}, params={self.params!r})"

    def _repr_html_(self) -> str:
        rows = "".join(
            f"<tr><th>{escape(str(key))}</th><td><code>{escape(repr(value))}</code></td></tr>"
            for key, value in sorted(self.params.items())
        )
        if not rows:
            rows = "<tr><td colspan='2'><em>no params</em></td></tr>"
        return (
            f"<div><strong>{escape(type(self).__name__)}</strong>"
            f"<table><tr><th>name</th><td><code>{escape(self.name)}</code></td></tr>{rows}</table></div>"
        )

    def get_params(self, deep: bool = True) -> dict[str, Any]:
        payload = {
            "name": self.name,
            "params": clone_value(self.params),
        }
        if deep:
            for key, value in self.params.items():
                payload[str(key)] = clone_value(value)
        return payload

    def set_params(self, **kwargs: Any) -> "_ComponentSpec":
        if "name" in kwargs:
            normalized = str(kwargs.pop("name")).strip()
            if not normalized:
                raise ValueError(f"{self.kind.title()} name must be a non-empty string.")
            self.name = normalized
        if "params" in kwargs:
            self.params = normalize_mapping(kwargs.pop("params"), location=f"{type(self).__name__}.params")
        for key, value in kwargs.items():
            parts = str(key).split("__")
            if parts[0] == "params":
                set_nested_mapping_value(self.params, parts[1:] or [parts[0]], value)
                continue
            self.params[str(key)] = clone_value(value)
        return self

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "params": clone_value(self.params)}

    def clone(self) -> "_ComponentSpec":
        return type(self)(self.name, **clone_value(self.params))

    def save_spec(self, path: str | Path) -> Path:
        resolved = Path(str(path)).expanduser().resolve()
        resolved.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "kind": type(self).__name__,
            "spec": self.to_dict(),
        }
        resolved.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
        return resolved

    @classmethod
    def load_spec(cls, path: str | Path) -> "_ComponentSpec":
        resolved = Path(str(path)).expanduser().resolve()
        payload = yaml.safe_load(resolved.read_text(encoding="utf-8"))
        if not isinstance(payload, dict) or not isinstance(payload.get("spec"), dict):
            raise ValueError(f"Spec file '{resolved}' must contain a top-level 'spec' mapping.")
        spec_payload = payload["spec"]
        name = spec_payload.get("name")
        params = spec_payload.get("params", {})
        if not isinstance(params, dict):
            raise ValueError(f"Spec file '{resolved}' has invalid 'params' content.")
        return cls(str(name), **clone_value(params))


class ModelSpec(_ComponentSpec):
    """Named model specification."""

    kind = "model"


class TaskSpec(_ComponentSpec):
    """Named task specification."""

    kind = "task"
