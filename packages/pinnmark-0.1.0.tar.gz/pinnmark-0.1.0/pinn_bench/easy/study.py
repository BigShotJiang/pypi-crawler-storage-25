"""Additive workflow layer for the easy API research core."""

from __future__ import annotations

import itertools
from html import escape
import random
from pathlib import Path
from typing import Any

from pinn_bench.easy.base import clone_value, coerce_path
from pinn_bench.easy.estimator import BenchmarkEstimator
from pinn_bench.easy.exceptions import InvalidCompositionError
from pinn_bench.easy.report import BenchmarkReport

_DEFAULT_METRIC_DIRECTIONS = {
    "mse": True,
    "relative_l2": True,
    "near_boundary_relative_l2": True,
    "residual_metric": True,
}


def metric_lower_is_better(metric: str) -> bool:
    """Return whether lower values are better for the given metric."""
    return _DEFAULT_METRIC_DIRECTIONS.get(str(metric).strip(), True)


class ParameterGrid:
    """Expand sklearn-style parameter grids into explicit dictionaries."""

    def __init__(self, param_grid: dict[str, list[Any]] | list[dict[str, list[Any]]]) -> None:
        grids = param_grid if isinstance(param_grid, list) else [param_grid]
        if not grids:
            raise InvalidCompositionError("ParameterGrid requires at least one grid mapping.")
        normalized: list[dict[str, list[Any]]] = []
        for index, grid in enumerate(grids):
            if not isinstance(grid, dict):
                raise InvalidCompositionError(f"ParameterGrid entry {index} must be a mapping.")
            payload: dict[str, list[Any]] = {}
            for key, values in grid.items():
                if isinstance(values, str):
                    raise InvalidCompositionError(f"ParameterGrid entry '{key}' must be an iterable of values, not a string.")
                options = list(values)
                if not options:
                    raise InvalidCompositionError(f"ParameterGrid entry '{key}' must contain at least one value.")
                payload[str(key)] = clone_value(options)
            normalized.append(payload)
        self._grids = normalized

    def __iter__(self):
        for grid in self._grids:
            keys = list(grid)
            values = [grid[key] for key in keys]
            for product in itertools.product(*values):
                yield {key: clone_value(value) for key, value in zip(keys, product)}

    def __len__(self) -> int:
        total = 0
        for grid in self._grids:
            size = 1
            for values in grid.values():
                size *= len(values)
            total += size
        return total

    def to_list(self) -> list[dict[str, Any]]:
        return list(self)


class ParameterSampler:
    """Sample additive parameter dictionaries from a simple search space."""

    def __init__(
        self,
        param_distributions: ParameterGrid | dict[str, list[Any]],
        *,
        n_iter: int | None = None,
        random_state: int | None = None,
    ) -> None:
        if isinstance(param_distributions, ParameterGrid):
            self._param_distributions = {"__grid__": param_distributions.to_list()}
            self._n_iter = len(self._param_distributions["__grid__"]) if n_iter is None else int(n_iter)
        else:
            if not isinstance(param_distributions, dict) or not param_distributions:
                raise InvalidCompositionError("ParameterSampler requires a non-empty mapping of parameter choices.")
            if n_iter is None:
                raise InvalidCompositionError("ParameterSampler requires n_iter when sampling from raw distributions.")
            payload: dict[str, list[Any]] = {}
            for key, values in param_distributions.items():
                if isinstance(values, str):
                    raise InvalidCompositionError(f"ParameterSampler entry '{key}' must be a sequence, not a string.")
                options = list(values)
                if not options:
                    raise InvalidCompositionError(f"ParameterSampler entry '{key}' cannot be empty.")
                payload[str(key)] = clone_value(options)
            self._param_distributions = payload
            self._n_iter = int(n_iter)
        if self._n_iter <= 0:
            raise InvalidCompositionError("ParameterSampler requires n_iter > 0.")
        self._random_state = random_state

    def __iter__(self):
        rng = random.Random(self._random_state)
        if "__grid__" in self._param_distributions:
            grid_rows = list(self._param_distributions["__grid__"])
            for _ in range(self._n_iter):
                yield clone_value(rng.choice(grid_rows))
            return
        keys = list(self._param_distributions)
        for _ in range(self._n_iter):
            yield {
                key: clone_value(rng.choice(self._param_distributions[key]))
                for key in keys
            }

    def __len__(self) -> int:
        return self._n_iter

    def to_list(self) -> list[dict[str, Any]]:
        return list(self)


class BenchmarkStudy:
    """Batch researcher workflow over multiple estimator variants."""

    def __init__(
        self,
        *,
        base_estimator: BenchmarkEstimator | None = None,
        variants: list[BenchmarkEstimator | dict[str, Any]] | None = None,
        estimators: list[BenchmarkEstimator] | None = None,
        seeds: tuple[int, ...] = (),
        metric: str = "relative_l2",
        output_root: str | Path | None = None,
    ) -> None:
        if estimators and (base_estimator is not None or variants is not None):
            raise InvalidCompositionError("BenchmarkStudy accepts either estimators=... or base_estimator + variants, not both.")
        if estimators is None and base_estimator is None:
            raise InvalidCompositionError("BenchmarkStudy requires either estimators=... or base_estimator=....")
        self.base_estimator = None if base_estimator is None else base_estimator.clone()
        self._input_estimators = None if estimators is None else [estimator.clone() for estimator in estimators]
        self._variants = [] if variants is None else [clone_value(item) for item in variants]
        self._seeds = tuple(int(seed) for seed in seeds)
        self.metric = str(metric)
        self.output_root = coerce_path(output_root)
        self._reports: list[BenchmarkReport] = []
        self._candidate_reports: dict[str, list[BenchmarkReport]] = {}
        self._candidate_params: dict[str, dict[str, Any]] = {}
        self.results_: list[dict[str, Any]] = []

    def __repr__(self) -> str:
        return (
            "BenchmarkStudy("
            f"metric={self.metric!r}, is_fitted_={self.is_fitted_!r}, "
            f"num_reports={len(self._reports)!r})"
        )

    def _repr_html_(self) -> str:
        rows = "".join(
            "<tr>"
            f"<td>{escape(str(row.get('label')))}</td>"
            f"<td><code>{escape(str(row.get('task_name')))}</code></td>"
            f"<td><code>{escape(str(row.get('model_name')))}</code></td>"
            f"<td><code>{escape(repr(row.get('score')))}</code></td>"
            f"<td>{escape(str(row.get('num_runs')))}</td>"
            "</tr>"
            for row in self.summary(self.metric)
        )
        if not rows:
            rows = "<tr><td colspan='5'><em>not fitted</em></td></tr>"
        return (
            "<div><strong>BenchmarkStudy</strong>"
            f"<p>metric=<code>{escape(self.metric)}</code> is_fitted_=<code>{self.is_fitted_}</code></p>"
            "<table><tr><th>label</th><th>task</th><th>model</th><th>score</th><th>runs</th></tr>"
            f"{rows}</table></div>"
        )

    @property
    def is_fitted_(self) -> bool:
        return bool(self.results_)

    def _candidate_estimators(self) -> list[tuple[str, BenchmarkEstimator, dict[str, Any]]]:
        candidates: list[tuple[str, BenchmarkEstimator, dict[str, Any]]] = []
        if self._input_estimators is not None:
            for index, estimator in enumerate(self._input_estimators):
                label = f"candidate_{index:02d}_{estimator.task.name}_{estimator.model.name}"
                candidates.append((label, estimator.clone(), {}))
            return candidates

        assert self.base_estimator is not None
        if not self._variants:
            base = self.base_estimator.clone()
            candidates.append(("candidate_00_default", base, {}))
            return candidates

        for index, variant in enumerate(self._variants):
            if isinstance(variant, BenchmarkEstimator):
                estimator = variant.clone()
                label = f"candidate_{index:02d}_{estimator.task.name}_{estimator.model.name}"
                candidates.append((label, estimator, {}))
                continue
            if not isinstance(variant, dict):
                raise InvalidCompositionError("BenchmarkStudy variants must contain BenchmarkEstimator objects or param mappings.")
            estimator = self.base_estimator.clone()
            estimator.set_params(**variant)
            label_suffix = "_".join(f"{key}-{variant[key]}" for key in sorted(variant)) or "default"
            candidates.append((f"candidate_{index:02d}_{label_suffix}", estimator, clone_value(variant)))
        return candidates

    def fit_all(self, output_root: str | Path | None = None) -> "BenchmarkStudy":
        self.output_root = self.output_root if output_root is None else coerce_path(output_root)
        self._reports = []
        self._candidate_reports = {}
        self._candidate_params = {}
        self.results_ = []

        for label, estimator, params in self._candidate_estimators():
            seeds = self._seeds or (estimator.seed,)
            seed_reports: list[BenchmarkReport] = []
            seed_scores: list[float] = []
            run_dirs: list[str] = []
            for seed in seeds:
                run_estimator = estimator.clone()
                run_estimator.set_params(seed=seed)
                run_output = None
                if self.output_root is not None:
                    run_output = self.output_root / label / f"seed_{seed}"
                run_estimator.fit(output_dir=run_output)
                report = run_estimator.report()
                score = report.score(metric=self.metric)
                self._reports.append(report)
                seed_reports.append(report)
                seed_scores.append(score)
                if report.run_dir_ is not None:
                    run_dirs.append(str(report.run_dir_))
            self._candidate_reports[label] = list(seed_reports)
            self._candidate_params[label] = clone_value(params)
            representative = seed_reports[0].summary() if seed_reports else {}
            mean_score = sum(seed_scores) / len(seed_scores) if seed_scores else float("inf")
            self.results_.append(
                {
                    "label": label,
                    "task_name": representative.get("task_name"),
                    "model_name": representative.get("model_name"),
                    "metric": self.metric,
                    "score": mean_score,
                    "num_runs": len(seed_scores),
                    "seed_scores": list(seed_scores),
                    "seeds": list(seeds),
                    "params": clone_value(params),
                    "run_dirs": list(run_dirs),
                    "summary": representative,
                }
            )
        return self

    def reports(self) -> list[BenchmarkReport]:
        return list(self._reports)

    def metric_names(self) -> list[str]:
        metrics: set[str] = set()
        for report in self._reports:
            metrics.update(report.metric_names())
        return sorted(metrics)

    def summary(self, metric: str = "relative_l2") -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for label, reports in self._candidate_reports.items():
            if not reports:
                continue
            scores = [report.score(metric=metric) for report in reports]
            representative = reports[0].summary()
            rows.append(
                {
                    "label": label,
                    "task_name": representative.get("task_name"),
                    "model_name": representative.get("model_name"),
                    "metric": metric,
                    "score": sum(scores) / len(scores),
                    "num_runs": len(scores),
                    "seed_scores": list(scores),
                    "seeds": [representative.get("seed")] if len(scores) == 1 else [report.summary().get("seed") for report in reports],
                    "params": clone_value(self._candidate_params.get(label, {})),
                    "run_dirs": [str(report.run_dir_) for report in reports if report.run_dir_ is not None],
                    "summary": representative,
                }
            )
        reverse = not metric_lower_is_better(metric)
        return sorted(rows, key=lambda item: float(item["score"]), reverse=reverse)

    def best(self, metric: str = "relative_l2") -> dict[str, Any]:
        rows = self.summary(metric=metric)
        if not rows:
            raise InvalidCompositionError("BenchmarkStudy must be fitted before best(...) is available.")
        return rows[0]

    def to_dict(self, metric: str = "relative_l2") -> dict[str, Any]:
        return {
            "metric": metric,
            "best": self.best(metric=metric),
            "rows": self.summary(metric=metric),
        }


class BenchmarkSweep:
    """Parameter sweep with optional refit of the best candidate."""

    def __init__(
        self,
        *,
        base_estimator: BenchmarkEstimator,
        param_grid: ParameterGrid | dict[str, list[Any]] | None = None,
        param_sampler: ParameterSampler | dict[str, list[Any]] | None = None,
        seeds: tuple[int, ...] = (),
        metric: str = "relative_l2",
        refit_best: bool = True,
        output_root: str | Path | None = None,
    ) -> None:
        if (param_grid is None) == (param_sampler is None):
            raise InvalidCompositionError("BenchmarkSweep requires exactly one of param_grid or param_sampler.")
        self.base_estimator = base_estimator.clone()
        self.param_grid = param_grid if isinstance(param_grid, ParameterGrid) or param_grid is None else ParameterGrid(param_grid)
        self.param_sampler = (
            param_sampler if isinstance(param_sampler, ParameterSampler) or param_sampler is None else None
        )
        if isinstance(param_sampler, dict):
            raise InvalidCompositionError("BenchmarkSweep param_sampler must be a ParameterSampler instance.")
        self.seeds = tuple(int(seed) for seed in seeds)
        self.metric = str(metric)
        self.refit_best = bool(refit_best)
        self.output_root = coerce_path(output_root)
        self.results_: dict[str, Any] | None = None
        self.best_estimator_: BenchmarkEstimator | None = None
        self.best_score_: float | None = None
        self.best_report_: BenchmarkReport | None = None
        self._study: BenchmarkStudy | None = None

    def __repr__(self) -> str:
        return (
            "BenchmarkSweep("
            f"metric={self.metric!r}, refit_best={self.refit_best!r}, "
            f"is_fitted_={self.is_fitted_!r})"
        )

    def _repr_html_(self) -> str:
        rows = "" if self.results_ is None else "".join(
            "<tr>"
            f"<td>{escape(str(row.get('label')))}</td>"
            f"<td><code>{escape(repr(row.get('score')))}</code></td>"
            f"<td><code>{escape(repr(row.get('params')))}</code></td>"
            "</tr>"
            for row in self.results_.get("rows", [])
        )
        if not rows:
            rows = "<tr><td colspan='3'><em>not fitted</em></td></tr>"
        return (
            "<div><strong>BenchmarkSweep</strong>"
            f"<p>metric=<code>{escape(self.metric)}</code> is_fitted_=<code>{self.is_fitted_}</code></p>"
            "<table><tr><th>label</th><th>score</th><th>params</th></tr>"
            f"{rows}</table></div>"
        )

    @property
    def is_fitted_(self) -> bool:
        return self.results_ is not None

    def fit(self, output_root: str | Path | None = None) -> "BenchmarkSweep":
        self.output_root = self.output_root if output_root is None else coerce_path(output_root)
        variants = (
            self.param_grid.to_list()
            if self.param_grid is not None
            else self.param_sampler.to_list() if self.param_sampler is not None else []
        )
        study = BenchmarkStudy(
            base_estimator=self.base_estimator,
            variants=variants,
            seeds=self.seeds,
            metric=self.metric,
            output_root=self.output_root,
        )
        study.fit_all()
        self._study = study
        self.results_ = study.to_dict(metric=self.metric)
        best = study.best(metric=self.metric)
        self.best_score_ = float(best["score"])
        representative_reports = study._candidate_reports.get(str(best.get("label")), [])  # type: ignore[attr-defined]
        representative_report = representative_reports[0] if representative_reports else None
        self.best_report_ = representative_report

        chosen = self.base_estimator.clone()
        if isinstance(best.get("params"), dict):
            chosen.set_params(**best["params"])
        if self.refit_best:
            refit_output = None if self.output_root is None else self.output_root / "_best_refit"
            chosen.fit(output_dir=refit_output)
            self.best_estimator_ = chosen
            self.best_report_ = chosen.report()
        else:
            self.best_estimator_ = chosen
        return self

    def reports(self) -> list[BenchmarkReport]:
        return [] if self._study is None else self._study.reports()

    def metric_names(self) -> list[str]:
        return [] if self._study is None else self._study.metric_names()

    def summary(self, metric: str = "relative_l2") -> list[dict[str, Any]]:
        if self._study is None:
            raise InvalidCompositionError("BenchmarkSweep must be fitted before summary(...) is available.")
        return self._study.summary(metric=metric)

    def best(self, metric: str = "relative_l2") -> dict[str, Any]:
        if self._study is None:
            raise InvalidCompositionError("BenchmarkSweep must be fitted before best(...) is available.")
        return self._study.best(metric=metric)

    def to_dict(self, metric: str = "relative_l2") -> dict[str, Any]:
        if self._study is None:
            raise InvalidCompositionError("BenchmarkSweep must be fitted before to_dict(...) is available.")
        payload = self._study.to_dict(metric=metric)
        payload["best_score_"] = self.best_score_
        payload["best_report"] = None if self.best_report_ is None else self.best_report_.summary()
        return payload
