"""Easy-layer compliance helpers."""

from __future__ import annotations

from dataclasses import dataclass
from html import escape
from typing import Any

from pinn_bench.easy.exceptions import NotExecutedError
from pinn_bench.easy.estimator import BenchmarkEstimator


@dataclass(frozen=True)
class EasyComplianceReport:
    """Human-readable compliance result for one easy estimator instance."""

    compliant: bool
    checks: tuple[dict[str, object], ...]
    warnings: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, object]:
        return {
            "compliant": self.compliant,
            "checks": [dict(item) for item in self.checks],
            "warnings": list(self.warnings),
        }

    def summary(self) -> dict[str, object]:
        passed = sum(1 for item in self.checks if item.get("ok"))
        return {
            "compliant": self.compliant,
            "passed_checks": passed,
            "failed_checks": len(self.checks) - passed,
            "warnings": list(self.warnings),
        }

    def _repr_html_(self) -> str:
        rows = "".join(
            "<tr>"
            f"<td>{escape(str(item.get('name')))}</td>"
            f"<td><code>{escape(str(item.get('ok')))}</code></td>"
            f"<td>{escape(str(item.get('detail')))}</td>"
            "</tr>"
            for item in self.checks
        )
        if not rows:
            rows = "<tr><td colspan='3'><em>no checks</em></td></tr>"
        warnings = "".join(f"<li>{escape(str(item))}</li>" for item in self.warnings)
        warnings_html = f"<ul>{warnings}</ul>" if warnings else "<em>none</em>"
        return (
            "<div><strong>EasyComplianceReport</strong>"
            f"<p>compliant=<code>{self.compliant}</code></p>"
            "<table><tr><th>check</th><th>ok</th><th>detail</th></tr>"
            f"{rows}</table>"
            f"<details><summary>warnings</summary>{warnings_html}</details>"
            "</div>"
        )


def _check(name: str, ok: bool, detail: str) -> dict[str, object]:
    return {"name": name, "ok": bool(ok), "detail": detail}


def check_easy_estimator(obj: Any) -> EasyComplianceReport:
    """Validate the public researcher-core contract for one estimator object."""
    checks: list[dict[str, object]] = []
    warnings: list[str] = []

    if not isinstance(obj, BenchmarkEstimator):
        checks.append(_check("instance_type", False, "Object is not a BenchmarkEstimator instance."))
        return EasyComplianceReport(compliant=False, checks=tuple(checks), warnings=tuple(warnings))

    estimator = obj
    checks.append(_check("instance_type", True, "Object is a BenchmarkEstimator instance."))

    clone = estimator.clone()
    checks.append(_check("clone_type", isinstance(clone, BenchmarkEstimator), "clone() returns a BenchmarkEstimator."))
    checks.append(_check("clone_distinct", clone is not estimator, "clone() returns a distinct object."))
    checks.append(_check("clone_unfitted", clone.is_fitted_ is False, "clone() returns an unfitted estimator."))

    params = estimator.get_params(deep=True)
    required_keys = ("model__name", "task__name", "train__epochs", "train__lr", "train__seed", "metrics__names")
    missing = [key for key in required_keys if key not in params]
    checks.append(
        _check(
            "deep_params_shape",
            not missing,
            "get_params(deep=True) exposes the sklearn-style nested parameter keys."
            if not missing
            else f"Missing nested keys: {', '.join(missing)}",
        )
    )

    original_epochs = clone.epochs
    clone.set_params(train__epochs=original_epochs + 1)
    checks.append(
        _check(
            "nested_set_params",
            clone.epochs == original_epochs + 1,
            "set_params(train__epochs=...) updates nested training params.",
        )
    )

    checks.append(_check("trailing_state_is_fresh", estimator.run_dir_ is None and estimator.results_ is None, "Fresh estimators keep trailing-underscore execution state empty."))

    try:
        estimator.report()
    except NotExecutedError as exc:
        checks.append(
            _check(
                "unfitted_error_message",
                "fit" in str(exc).lower(),
                "report() on an unfitted estimator raises a clear fit-before-use error.",
            )
        )
    except Exception as exc:  # pragma: no cover - defensive
        checks.append(_check("unfitted_error_message", False, f"Unexpected exception type: {type(exc).__name__}"))
    else:
        checks.append(_check("unfitted_error_message", False, "report() unexpectedly succeeded on an unfitted estimator."))

    lower_is_better_metrics = {"mse", "relative_l2"}
    unknown_metrics = sorted(metric for metric in estimator.metrics if metric not in lower_is_better_metrics)
    checks.append(
        _check(
            "metric_direction_defaults",
            not unknown_metrics,
            "Configured metrics all use the default lower-is-better researcher-core direction."
            if not unknown_metrics
            else f"Unknown metric direction defaults for: {', '.join(unknown_metrics)}",
        )
    )

    if estimator.output_dir is None:
        warnings.append("Estimator has no explicit output_dir; it will resolve to a safe playground path on fit().")

    compliant = all(bool(item.get("ok")) for item in checks)
    return EasyComplianceReport(compliant=compliant, checks=tuple(checks), warnings=tuple(warnings))
