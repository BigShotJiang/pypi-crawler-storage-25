"""Public exceptions for the sklearn-like easy API."""

from __future__ import annotations


class EasyAPIError(ValueError):
    """Base error for pinn_bench.easy."""


class NotExecutedError(EasyAPIError):
    """Raised when a benchmark object is used before fit/execution."""


class UnsafeOutputRootError(EasyAPIError):
    """Raised when an unsafe canonical benchmark root is requested."""


class InvalidComponentError(EasyAPIError):
    """Raised when a model, task, or metric name cannot be resolved."""


class InvalidCompositionError(EasyAPIError):
    """Raised when an invalid easy-layer parameter or composition is requested."""
