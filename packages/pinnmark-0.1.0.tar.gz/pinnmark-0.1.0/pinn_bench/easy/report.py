"""Report reader for the sklearn-like easy API layer."""

from __future__ import annotations

from html import escape
import json
from pathlib import Path
from typing import Any

import yaml

from pinn_bench.easy.base import clone_value, coerce_path
from pinn_bench.easy.exceptions import InvalidCompositionError, NotExecutedError
from pinn_bench.provenance import infer_line_and_manifest

_ARTIFACT_FILENAMES = {
    "config_snapshot": "config_snapshot.yaml",
    "metrics": "metrics.json",
    "train_log": "train_log.csv",
    "model": "model.pt",
    "loss_curve": "loss_curve.png",
    "provenance": "provenance.json",
}


class BenchmarkReport:
    """Read-only view over one benchmark run's stable outputs."""

    def __init__(
        self,
        *,
        payload: dict[str, Any],
        run_dir: str | Path | None = None,
        config_snapshot: dict[str, Any] | None = None,
    ) -> None:
        self._payload = clone_value(payload)
        self._run_dir = coerce_path(run_dir)
        self._config_snapshot = clone_value(config_snapshot)

    def __repr__(self) -> str:
        task_name = self._payload.get("metadata", {}).get("task_name")
        model_name = self._payload.get("metadata", {}).get("model_name")
        return f"BenchmarkReport(run_dir={self._run_dir!r}, task_name={task_name!r}, model_name={model_name!r})"

    @classmethod
    def from_payload(
        cls,
        payload: dict[str, Any],
        *,
        run_dir: str | Path | None = None,
        config_snapshot: dict[str, Any] | None = None,
    ) -> "BenchmarkReport":
        """Build a report directly from an in-memory results payload."""
        return cls(payload=payload, run_dir=run_dir, config_snapshot=config_snapshot)

    @classmethod
    def from_run_dir(cls, path: str | Path) -> "BenchmarkReport":
        """Load a report from one benchmark run directory."""
        run_dir = coerce_path(path)
        if run_dir is None:
            raise NotExecutedError("A run directory is required to load a benchmark report.")
        metrics_path = run_dir / "metrics.json"
        if not metrics_path.exists():
            raise NotExecutedError(
                f"Run directory '{run_dir}' does not contain metrics.json. Fit a benchmark before requesting a report."
            )
        payload = json.loads(metrics_path.read_text(encoding="utf-8"))
        config_snapshot = None
        snapshot_path = run_dir / "config_snapshot.yaml"
        if snapshot_path.exists():
            config_snapshot = yaml.safe_load(snapshot_path.read_text(encoding="utf-8"))
        return cls(payload=payload, run_dir=run_dir, config_snapshot=config_snapshot)

    @property
    def run_dir(self) -> Path | None:
        """Return the resolved run directory when available."""
        return self._run_dir

    @property
    def run_dir_(self) -> Path | None:
        """Return the resolved run directory using easy-layer trailing-underscore naming."""
        return self._run_dir

    def to_dict(self) -> dict[str, Any]:
        """Return the metrics payload."""
        return clone_value(self._payload)

    def artifact_paths(self) -> dict[str, str | None]:
        """Return stable artifact locations for the current run directory."""
        if self._run_dir is None:
            return {key: None for key in _ARTIFACT_FILENAMES}
        return {
            key: str((self._run_dir / filename).resolve()) if (self._run_dir / filename).exists() else None
            for key, filename in _ARTIFACT_FILENAMES.items()
        }

    def summary(self) -> dict[str, Any]:
        """Return a compact human-friendly summary."""
        metadata = self._payload.get("metadata", {})
        train = self._payload.get("train", {})
        eval_metrics = self._payload.get("eval", {})
        benchmark_line = "custom"
        if self._run_dir is not None:
            benchmark_line, _manifest_path = infer_line_and_manifest(self._run_dir)
        return {
            "run_dir": None if self._run_dir is None else str(self._run_dir),
            "benchmark_line": benchmark_line,
            "task_name": metadata.get("task_name"),
            "model_name": metadata.get("model_name"),
            "seed": metadata.get("seed"),
            "device": metadata.get("device"),
            "robustness": metadata.get("robustness"),
            "final_loss": train.get("final_loss"),
            "best_loss": train.get("best_loss"),
            "epochs": train.get("epochs"),
            "metrics": clone_value(eval_metrics),
            "artifacts": self.artifact_paths(),
        }

    def score(self, metric: str = "relative_l2") -> float:
        """Return one scalar evaluation metric from the report payload."""
        key = str(metric).strip()
        eval_metrics = self._payload.get("eval", {})
        if key not in eval_metrics:
            available = ", ".join(sorted(eval_metrics)) or "<empty>"
            raise InvalidCompositionError(f"Metric '{metric}' is not available in this report. Available: {available}")
        return float(eval_metrics[key])

    def metric_names(self) -> list[str]:
        """Return the sorted evaluation metrics available in this report."""
        eval_metrics = self._payload.get("eval", {})
        return sorted(str(key) for key in dict(eval_metrics))

    @property
    def config_snapshot(self) -> dict[str, Any] | None:
        """Return the resolved config snapshot when available."""
        return clone_value(self._config_snapshot)

    def _repr_html_(self) -> str:
        summary = self.summary()
        rows = []
        for key in ("task_name", "model_name", "seed", "device", "benchmark_line", "run_dir", "final_loss", "best_loss"):
            rows.append(
                f"<tr><th>{escape(str(key))}</th><td><code>{escape(repr(summary.get(key)))}</code></td></tr>"
            )
        metric_rows = "".join(
            f"<tr><th>{escape(str(name))}</th><td><code>{escape(repr(value))}</code></td></tr>"
            for name, value in sorted(summary.get("metrics", {}).items())
        )
        if not metric_rows:
            metric_rows = "<tr><td colspan='2'><em>no metrics</em></td></tr>"
        return (
            "<div>"
            "<strong>BenchmarkReport</strong>"
            f"<table>{''.join(rows)}</table>"
            "<details><summary>Metrics</summary>"
            f"<table>{metric_rows}</table>"
            "</details>"
            "</div>"
        )
