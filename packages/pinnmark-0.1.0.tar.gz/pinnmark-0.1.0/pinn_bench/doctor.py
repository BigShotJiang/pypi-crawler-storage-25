"""Repository and artifact health checks for pinn_bench."""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from pinn_bench.community.validate_submission import build_submission_validation_payload
from pinn_bench.comparison import HEADLINE_TASKS, OPERATOR_COVERAGE_TASKS
from pinn_bench.demo import DEMO_SPECS, demo_resource_checks
from pinn_bench.presets.cli import validate_preset_catalog
from pinn_bench.analysis.normalize import list_history_entries, required_analysis_asset_paths
from pinn_bench.regime import summarize_regime_governance
from pinn_bench.resources import resolve_manifest_path, resolve_outputs_root, resolve_repo_root
from pinn_bench.utils.io import write_json
from pinn_bench.version import (
    KNOWN_PREVIEW_LINE,
    KNOWN_PREVIEW_MANIFEST_NAME,
    KNOWN_PREVIEW_OUTPUTS_ROOT,
    LATEST_COMPLETED_PREVIEW_LINE,
    LATEST_COMPLETED_PREVIEW_MANIFEST_NAME,
    LATEST_COMPLETED_PREVIEW_OUTPUTS_ROOT,
    LATEST_FORMAL_MANIFEST_NAME,
    LATEST_FORMAL_OUTPUTS_ROOT,
)


@dataclass(frozen=True)
class CheckResult:
    code: str
    severity: str
    status: str
    message: str
    path: str | None = None


FORMAL_MODE = "formal"
PREVIEW_MODE = "preview"
STARTER_MODE = "starter"
COMMUNITY_MODE = "community"
FORMAL_V10_REQUIRED_ANALYSIS_FILES = [
    "freeze_packet.json",
    "freeze_packet.md",
    "freeze_readiness_report.json",
    "freeze_readiness_report.md",
    "formal_baseline_summary.md",
    "v1_0_formal_manifest.json",
    "v1_0_formal_manifest.md",
    "freeze_governance_record.md",
    "freeze_decision_brief.md",
]
DOCTOR_REPORT_JSON = "doctor_report.json"
DOCTOR_REPORT_MARKDOWN = "doctor_report.md"
PROTECTED_REPO_OUTPUT_ROOTS = ("outputs_v02", "outputs_v03", "outputs_v04", "outputs_v05", "outputs_v06")
STARTER_PACK_ID = "post-v1.8-geometry"
STARTER_MANIFEST_NAME = "post_v1_8_geometry_starter.yaml"
STARTER_OUTPUTS_ROOT = "outputs_post_v1_8_geometry"
STARTER_REFERENCE_PREVIEW_LINE = "v1.8-preview"



def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Check repository manifests and benchmark assets.")
    mode_group = parser.add_mutually_exclusive_group()
    mode_group.add_argument("--formal", action="store_true", help="Run formal v1.0 release checks (default).")
    mode_group.add_argument("--preview", action="store_true", help="Run historical preview/product-root checks.")
    mode_group.add_argument("--starter", type=str, default=None, help="Run draft-governed starter-pack checks.")
    mode_group.add_argument("--community", action="store_true", help="Run community submission/docs/demo checks.")
    parser.add_argument("--strict", action="store_true", help="Return non-zero if any warning or error is reported.")
    parser.add_argument("--json", action="store_true", help="Emit machine-readable check results to stdout.")
    parser.add_argument("--write", action="store_true", help="Persist canonical doctor JSON and Markdown artifacts.")
    parser.add_argument("--outputs-root", "--formal-root", dest="outputs_root", type=str, default=None, help="Optional outputs root override.")
    parser.add_argument("--matrix-manifest", type=str, default=None, help="Optional matrix manifest override.")
    parser.add_argument("--submission-bundle", type=str, default=None, help="Optional submission bundle directory to validate in doctor mode.")
    parser.add_argument("--scaffold-root", type=str, default=None, help="Optional external scaffold root to validate in doctor mode.")
    return parser



def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)



def _protected_repo_output_roots() -> tuple[Path, ...]:
    repo_root = resolve_repo_root()
    return tuple((repo_root / name).resolve() for name in PROTECTED_REPO_OUTPUT_ROOTS)



def _protected_root_name_for_path(path: Path) -> str | None:
    resolved = path.resolve()
    for protected_root in _protected_repo_output_roots():
        if resolved == protected_root or protected_root in resolved.parents:
            return protected_root.name
    return None



def ensure_doctor_write_allowed(*, output_dir: Path) -> None:
    protected_root_name = _protected_root_name_for_path(output_dir)
    if protected_root_name is not None:
        raise SystemExit(
            f"writing doctor artifacts is not allowed for protected historical formal roots: {protected_root_name}"
        )



def resolve_doctor_output_dir(outputs_root: Path, *, mode: str, starter_pack: str | None = None) -> Path:
    if mode == STARTER_MODE and starter_pack:
        return (outputs_root / "_doctor" / starter_pack.replace("-", "_")).resolve()
    return (outputs_root / "_doctor").resolve()



def _doctor_write_supported(*, mode: str, submission_bundle_arg: str | None, scaffold_root_arg: str | None) -> bool:
    return mode in {FORMAL_MODE, PREVIEW_MODE, STARTER_MODE} and submission_bundle_arg is None and scaffold_root_arg is None



def _result(code: str, severity: str, passed: bool, message: str, path: Path | None = None) -> CheckResult:
    return CheckResult(
        code=code,
        severity=severity,
        status="pass" if passed else "fail",
        message=message,
        path=None if path is None else str(path.resolve()),
    )



def _append_path_check(results: list[CheckResult], *, code: str, severity: str, path: Path, success_message: str, failure_message: str) -> None:
    results.append(_result(code, "info", True, success_message, path=path) if path.exists() else _result(code, severity, False, failure_message, path=path))



def _default_mode(args: argparse.Namespace) -> str:
    if args.community:
        return COMMUNITY_MODE
    if args.starter is not None:
        return STARTER_MODE
    return PREVIEW_MODE if args.preview else FORMAL_MODE



def _default_manifest(mode: str) -> Path | None:
    if mode == FORMAL_MODE:
        return resolve_manifest_path(LATEST_FORMAL_MANIFEST_NAME)
    if mode == STARTER_MODE:
        return resolve_manifest_path(STARTER_MANIFEST_NAME)
    if mode in {PREVIEW_MODE, COMMUNITY_MODE}:
        manifest_name = KNOWN_PREVIEW_MANIFEST_NAME or LATEST_COMPLETED_PREVIEW_MANIFEST_NAME
        if manifest_name is not None:
            return resolve_manifest_path(manifest_name)
    return None



def _infer_formal_manifest_from_outputs_root(outputs_root: Path) -> Path | None:
    mapping = {
        'outputs_v02': 'baseline_v0_2.yaml',
        'outputs_v03': 'baseline_v0_3.yaml',
        'outputs_v04': 'baseline_v0_4.yaml',
        'outputs_v05': 'baseline_v0_5.yaml',
        'outputs_v06': 'baseline_v0_6.yaml',
        'outputs_v10': 'baseline_v1_0_formal.yaml',
    }
    manifest_name = mapping.get(outputs_root.name)
    return None if manifest_name is None else resolve_manifest_path(manifest_name)


def _infer_starter_manifest_from_outputs_root(outputs_root: Path) -> Path | None:
    if outputs_root.name != STARTER_OUTPUTS_ROOT:
        return None
    try:
        return resolve_manifest_path(STARTER_MANIFEST_NAME)
    except FileNotFoundError:
        return (resolve_repo_root() / "configs" / "matrix" / STARTER_MANIFEST_NAME).resolve()



def _default_roots(mode: str, repo_root: Path) -> list[Path]:
    if mode == STARTER_MODE:
        return [repo_root / STARTER_OUTPUTS_ROOT]
    if mode == PREVIEW_MODE:
        return [repo_root / (KNOWN_PREVIEW_OUTPUTS_ROOT or LATEST_COMPLETED_PREVIEW_OUTPUTS_ROOT)]
    if mode == COMMUNITY_MODE:
        return [repo_root / (KNOWN_PREVIEW_OUTPUTS_ROOT or LATEST_COMPLETED_PREVIEW_OUTPUTS_ROOT)]
    return [repo_root / LATEST_FORMAL_OUTPUTS_ROOT]


def _formal_v10_analysis_paths(outputs_root: Path) -> list[Path]:
    analysis_dir = outputs_root / "_analysis"
    return [analysis_dir / name for name in FORMAL_V10_REQUIRED_ANALYSIS_FILES]


def _requires_formal_v10_analysis(outputs_root: Path, matrix_manifest: Path | None) -> bool:
    return outputs_root.name == "outputs_v10" or (matrix_manifest is not None and matrix_manifest.name == "baseline_v1_0_formal.yaml")


def _append_collection_check(
    results: list[CheckResult],
    *,
    code: str,
    severity: str,
    paths: Sequence[Path],
    success_message: str,
    failure_message: str,
) -> None:
    missing = [path for path in paths if not path.exists()]
    results.append(
        _result(
            code,
            severity,
            not missing,
            success_message if not missing else failure_message,
            path=None if not missing else missing[0],
        )
    )


def _load_grouped_rows(grouped_json_path: Path) -> list[dict[str, object]]:
    if not grouped_json_path.exists():
        return []
    try:
        payload = json.loads(grouped_json_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    rows = payload.get("rows")
    return [row for row in rows if isinstance(row, dict)] if isinstance(rows, list) else []


def _load_analysis_bundle_payload(analysis_dir: Path) -> dict[str, object] | None:
    bundle_path = analysis_dir / "analysis_bundle.json"
    if not bundle_path.exists():
        return None
    try:
        payload = json.loads(bundle_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def _load_protocol_bundle_payload(protocol_dir: Path) -> dict[str, object] | None:
    bundle_path = protocol_dir / "leaderboard_protocol_bundle.json"
    if not bundle_path.exists():
        return None
    try:
        payload = json.loads(bundle_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def _field_rows(rows: Sequence[dict[str, object]]) -> list[dict[str, object]]:
    return [
        row
        for row in rows
        if any(str(row.get(key, "")).lower() == "field" for key in ("task_mode", "model_mode", "evaluation_mode"))
    ]


def _load_grouped_payload(grouped_json_path: Path) -> dict[str, Any] | None:
    if not grouped_json_path.exists():
        return None
    try:
        payload = json.loads(grouped_json_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def _v1_7_fair_budget_facts(grouped_payload: dict[str, Any] | None) -> dict[str, Any]:
    rows = grouped_payload.get("rows") if isinstance(grouped_payload, dict) and isinstance(grouped_payload.get("rows"), list) else []
    groups = grouped_payload.get("fair_budget_groups") if isinstance(grouped_payload, dict) and isinstance(grouped_payload.get("fair_budget_groups"), list) else []
    summary = grouped_payload.get("fair_budget_summary") if isinstance(grouped_payload, dict) and isinstance(grouped_payload.get("fair_budget_summary"), dict) else {}
    targeted_tasks = set(HEADLINE_TASKS) | set(OPERATOR_COVERAGE_TASKS)
    targeted_rows: list[dict[str, Any]] = []
    targeted_row_ids: set[str] = set()
    if groups:
        for group in groups:
            if not isinstance(group, dict):
                continue
            task_name = str(group.get("task_name") or "").strip()
            if task_name not in targeted_tasks:
                continue
            for row in group.get("rows", []):
                if not isinstance(row, dict):
                    continue
                row_id = str(row.get("row_id") or row.get("run_id") or "")
                if row_id in targeted_row_ids:
                    continue
                targeted_rows.append(row)
                targeted_row_ids.add(row_id)
    else:
        targeted_rows = [
            row
            for row in rows
            if isinstance(row, dict) and str(row.get("task_name") or "").strip() in targeted_tasks
        ]
    def _row_has_complete_comparison_contract(row: dict[str, Any]) -> bool:
        explicit = row.get("comparison_contract_complete")
        if explicit is not None:
            return bool(explicit)
        return all(
            bool(str(row.get(key) or "").strip())
            for key in (
                "baseline_family",
                "data_budget_class",
                "compute_budget_class",
                "tuning_budget_class",
                "comparison_scope",
            )
        )

    targeted_rows_missing = [
        str(row.get("run_id") or row.get("row_id") or "")
        for row in targeted_rows
        if not _row_has_complete_comparison_contract(row)
    ]
    headline_groups = [
        group
        for group in groups
        if isinstance(group, dict) and bool(group.get("headline_program"))
    ]
    headline_eligible_groups = [
        group for group in headline_groups if bool(group.get("headline_claim_eligible"))
    ]
    blocked_headline_groups = [
        group for group in headline_groups if not bool(group.get("headline_claim_eligible"))
    ]
    headline_tasks_with_eligible_groups = sorted(
        {
            str(group.get("task_name") or "").strip()
            for group in headline_eligible_groups
            if str(group.get("task_name") or "").strip()
        }
    )
    return {
        "summary": dict(summary),
        "targeted_row_count": len(targeted_rows),
        "targeted_rows_missing_comparison_count": len(targeted_rows_missing),
        "targeted_rows_missing_comparison": targeted_rows_missing,
        "headline_group_count": len(headline_groups),
        "headline_eligible_group_count": len(headline_eligible_groups),
        "blocked_headline_group_count": len(blocked_headline_groups),
        "headline_tasks_with_eligible_groups": headline_tasks_with_eligible_groups,
    }


def _infer_preview_manifest_from_outputs_root(outputs_root: Path) -> Path | None:
    mapping = {
        "outputs_preview_v19": "baseline_v1_9_preview.yaml",
        "outputs_preview_v18": "baseline_v1_8_preview.yaml",
        "outputs_preview_v17": "baseline_v1_7_preview.yaml",
        "outputs_preview_v16": "baseline_v1_6_preview.yaml",
        "outputs_preview_v15": "baseline_v1_5_preview.yaml",
        "outputs_preview_v14": "baseline_v1_4_preview.yaml",
        "outputs_preview_v13": "baseline_v1_3_preview.yaml",
        "outputs_preview_v12": "baseline_v1_2_preview.yaml",
        "outputs_preview_v11": "baseline_v1_1_preview.yaml",
        "outputs_preview_v09": "baseline_v0_9_preview.yaml",
        "outputs_preview_v08": "baseline_v0_8_preview.yaml",
        "outputs_preview_v07": "baseline_v0_7_preview.yaml",
        "outputs_preview_v06": "baseline_v0_6_preview.yaml",
        "outputs_preview_v05": "baseline_v0_5_preview.yaml",
        "outputs_preview_v04": "baseline_v0_4_preview.yaml",
        "outputs_preview_v03": "baseline_v0_3_preview.yaml",
    }
    manifest_name = mapping.get(outputs_root.name)
    if manifest_name is None:
        return None
    try:
        return resolve_manifest_path(manifest_name)
    except FileNotFoundError:
        return (resolve_repo_root() / "configs" / "matrix" / manifest_name).resolve()


def _infer_preview_line(*, checked_root: Path, matrix_manifest: Path | None) -> str | None:
    root_name = checked_root.name
    if root_name == "outputs_preview_v19":
        return "v1.9-preview"
    if root_name == "outputs_preview_v18":
        return "v1.8-preview"
    if root_name == "outputs_preview_v17":
        return "v1.7-preview"
    if root_name == "outputs_preview_v16":
        return "v1.6-preview"
    if root_name == "outputs_preview_v15":
        return "v1.5-preview"
    if root_name == "outputs_preview_v14":
        return "v1.4-preview"
    if root_name == "outputs_preview_v13":
        return "v1.3-preview"
    if root_name == "outputs_preview_v12":
        return "v1.2-preview"
    if root_name == "outputs_preview_v11":
        return "v1.1-preview"
    if root_name == "outputs_preview_v09":
        return "v0.9-preview"
    if root_name == "outputs_preview_v08":
        return "v0.8-preview"
    if root_name == "outputs_preview_v07":
        return "v0.7-preview"
    if root_name == "outputs_preview_v06":
        return "v0.6-preview"
    if root_name == "outputs_preview_v05":
        return "v0.5-preview"
    if root_name == "outputs_preview_v04":
        return "v0.4-preview"
    if root_name == "outputs_preview_v03":
        return "v0.3-preview"
    if matrix_manifest is not None:
        name = matrix_manifest.name
        if name == "baseline_v1_9_preview.yaml":
            return "v1.9-preview"
        if name == "baseline_v1_8_preview.yaml":
            return "v1.8-preview"
        if name == "baseline_v1_7_preview.yaml":
            return "v1.7-preview"
        if name == "baseline_v1_6_preview.yaml":
            return "v1.6-preview"
        if name == "baseline_v1_5_preview.yaml":
            return "v1.5-preview"
        if name == "baseline_v1_4_preview.yaml":
            return "v1.4-preview"
        if name == "baseline_v1_3_preview.yaml":
            return "v1.3-preview"
        if name == "baseline_v1_2_preview.yaml":
            return "v1.2-preview"
        if name == "baseline_v1_1_preview.yaml":
            return "v1.1-preview"
        if name == "baseline_v0_9_preview.yaml":
            return "v0.9-preview"
        if name == "baseline_v0_8_preview.yaml":
            return "v0.8-preview"
        if name == "baseline_v0_7_preview.yaml":
            return "v0.7-preview"
        if name == "baseline_v0_6_preview.yaml":
            return "v0.6-preview"
        if name == "baseline_v0_5_preview.yaml":
            return "v0.5-preview"
        if name == "baseline_v0_4_preview.yaml":
            return "v0.4-preview"
    return None


def _infer_starter_pack(*, checked_root: Path, matrix_manifest: Path | None) -> str | None:
    if checked_root.name == STARTER_OUTPUTS_ROOT:
        return STARTER_PACK_ID
    if matrix_manifest is not None and matrix_manifest.name == STARTER_MANIFEST_NAME:
        return STARTER_PACK_ID
    return None


def _preview_asset_basename(*, grouped_payload: dict[str, Any] | None, matrix_manifest: Path | None) -> str | None:
    candidates: list[str] = []
    if matrix_manifest is not None:
        candidates.append(matrix_manifest.stem)
    if isinstance(grouped_payload, dict):
        manifest_text = grouped_payload.get("matrix_manifest")
        if manifest_text is not None:
            try:
                candidates.append(Path(str(manifest_text)).stem)
            except (OSError, ValueError):
                pass
    for candidate in candidates:
        candidate = candidate.strip()
        if candidate:
            return candidate
    return None


def _first_preview_asset_match(directory: Path, pattern: str) -> Path | None:
    if not directory.exists():
        return None
    matches = sorted(directory.glob(pattern))
    return None if not matches else matches[0].resolve()


def _preview_regime_artifact_paths(
    *,
    checked_root: Path,
    grouped_payload: dict[str, Any] | None,
    matrix_manifest: Path | None,
) -> dict[str, Path | None]:
    reporting_dir = checked_root / "_leaderboard" / "reporting"
    basename = _preview_asset_basename(grouped_payload=grouped_payload, matrix_manifest=matrix_manifest)

    def _candidate(directory: Path, suffix: str) -> Path | None:
        if basename is not None:
            candidate = (directory / f"{basename}{suffix}").resolve()
            return candidate
        return _first_preview_asset_match(directory, f"*{suffix}")

    return {
        "regime_map_json": _candidate(reporting_dir, "_regime_map.json"),
        "ood_slice_leaderboard_csv": _candidate(reporting_dir, "_ood_slice_leaderboard.csv"),
        "failure_atlas_json": _candidate(reporting_dir, "_failure_atlas.json"),
        "physics_consistency_dashboard_json": _candidate(reporting_dir, "_physics_consistency_dashboard.json"),
    }


def _v1_8_regime_facts(*, grouped_payload: dict[str, Any] | None, checked_root: Path, matrix_manifest: Path | None) -> dict[str, Any]:
    regime_artifact_paths = _preview_regime_artifact_paths(
        checked_root=checked_root,
        grouped_payload=grouped_payload,
        matrix_manifest=matrix_manifest,
    )
    regime_map_payload: dict[str, Any] | None = None
    regime_map_path = regime_artifact_paths.get("regime_map_json")
    if regime_map_path is not None and regime_map_path.exists():
        try:
            payload = json.loads(regime_map_path.read_text(encoding="utf-8"))
            regime_map_payload = payload if isinstance(payload, dict) else None
        except (OSError, json.JSONDecodeError):
            regime_map_payload = None
    facts = summarize_regime_governance(grouped_payload, regime_map_payload=regime_map_payload)
    facts["regime_artifact_paths"] = {
        key: None if path is None else str(path.resolve())
        for key, path in regime_artifact_paths.items()
    }
    facts["regime_artifacts_complete"] = all(
        path is not None and path.exists() for path in regime_artifact_paths.values()
    )
    return facts


def _preview_scene_summary(*, repo_root: Path, checked_root: Path, preview_line: str | None) -> dict[str, object]:
    grouped_json_path = checked_root / "_leaderboard" / "leaderboard_grouped.json"
    grouped_payload = _load_grouped_payload(grouped_json_path)
    rows = _load_grouped_rows(grouped_json_path)
    field_rows = _field_rows(rows)
    mode_fields_present = bool(field_rows) and all(
        bool(row.get("task_mode")) and bool(row.get("model_mode")) and bool(row.get("evaluation_mode"))
        for row in field_rows
    )
    analysis_dir = checked_root / "_analysis"
    analysis_assets_present = all(path.exists() for path in required_analysis_asset_paths(analysis_dir, preview_line=preview_line))
    analysis_bundle = _load_analysis_bundle_payload(analysis_dir)
    protocol_dir = checked_root / "_leaderboard_protocol"
    protocol_bundle = _load_protocol_bundle_payload(protocol_dir)
    reporting_dir = checked_root / "_leaderboard" / "reporting"
    example_imports_root = checked_root / "_submission_imports" / "examples"
    example_import_count = len(list(example_imports_root.rglob("leaderboard_entry_candidate.json"))) if example_imports_root.exists() else 0
    matrix_manifest = _infer_preview_manifest_from_outputs_root(checked_root)
    fair_budget_facts = _v1_7_fair_budget_facts(grouped_payload) if preview_line in {"v1.7-preview", "v1.8-preview", "v1.9-preview"} else {}
    regime_facts = _v1_8_regime_facts(grouped_payload=grouped_payload, checked_root=checked_root, matrix_manifest=matrix_manifest) if preview_line in {"v1.8-preview", "v1.9-preview"} else {}
    history_entries = list_history_entries(analysis_dir)
    inverse_rows = [row for row in rows if str(row.get("inverse_parameter_name") or "").strip()]
    inverse_reporting_present = False
    if matrix_manifest is not None:
        matrix_name = matrix_manifest.stem
        inverse_reporting_present = (
            (reporting_dir / f"{matrix_name}_inverse_trust_table.csv").exists()
            and (reporting_dir / f"{matrix_name}_identifiability_map.json").exists()
            and (reporting_dir / f"{matrix_name}_calibration_report.json").exists()
        )
    formal_discussion_signal = None
    analysis_readiness_conclusion = None
    provenance_surface_present = False
    observation_consistency_present = False
    comparison_fairness_present = False
    previous_preview_linkage_present = False
    packet_completeness_present = False
    if isinstance(analysis_bundle, dict):
        formal_discussion_signal = analysis_bundle.get("decision_support", {}).get("formal_discussion_recommendation")
        analysis_readiness_conclusion = analysis_bundle.get("review_packet", {}).get("analysis_readiness_conclusion")
        provenance_surface_present = bool(analysis_bundle.get("reproducibility_facts", {}).get("provenance_surface_present"))
        observation_consistency_present = bool(analysis_bundle.get("observation_consistency"))
        comparison_fairness_present = bool(analysis_bundle.get("comparison_fairness"))
        previous_preview_linkage_present = analysis_bundle.get("previous_preview_root") is not None
        review_packet = analysis_bundle.get("review_packet", {})
        packet_completeness_present = all(
            key in review_packet
            for key in (
                "engineering_status",
                "reproducibility_status",
                "observation_consistency_status",
                "asset_completeness_status",
                "comparison_fairness_summary",
            )
        )
    return {
        "preview_line": preview_line,
        "checked_outputs_root": str(checked_root.resolve()),
        "operator_tasks": sorted({str(row.get("task_name")) for row in field_rows if row.get("task_name")}),
        "operator_baselines": sorted({str(row.get("model_name")) for row in field_rows if row.get("model_name")}),
        "field_grouped_rows": len(field_rows),
        "inverse_grouped_rows": len(inverse_rows),
        "mode_fields_present": mode_fields_present,
        "operator_example_present": (repo_root / "examples" / "operator_model_example" / "README.md").exists(),
        "analysis_bundle_present": (analysis_dir / "analysis_bundle.json").exists(),
        "analysis_views_complete": analysis_assets_present,
        "history_entry_count": len(history_entries),
        "observation_snapshot_present": (analysis_dir / "observation_snapshot.json").exists(),
        "review_packet_present": (analysis_dir / "review_packet.json").exists(),
        "promotion_gap_report_present": (analysis_dir / "promotion_gap_report.json").exists(),
        "provenance_surface_present": provenance_surface_present,
        "observation_consistency_present": observation_consistency_present,
        "comparison_fairness_present": comparison_fairness_present,
        "previous_preview_linkage_present": previous_preview_linkage_present,
        "packet_completeness_present": packet_completeness_present,
        "formal_discussion_signal_present": formal_discussion_signal is not None,
        "formal_discussion_signal": formal_discussion_signal,
        "analysis_readiness_conclusion": analysis_readiness_conclusion,
        "leaderboard_protocol_bundle_present": (protocol_dir / "leaderboard_protocol_bundle.json").exists(),
        "admission_registry_present": (protocol_dir / "admission_registry.json").exists(),
        "governance_packet_present": (protocol_dir / "governance_packet.json").exists(),
        "leaderboard_protocol_view_count": len(protocol_bundle.get("view_coverage_summary", {})) if isinstance(protocol_bundle, dict) else 0,
        "example_import_count": example_import_count,
        "dx_surface_present": bool(analysis_bundle.get("dx_surface_summary")) if isinstance(analysis_bundle, dict) else False,
        "template_catalog_present": bool(analysis_bundle.get("template_catalog_summary")) if isinstance(analysis_bundle, dict) else False,
        "quickstart_surface_present": bool(analysis_bundle.get("quickstart_surface_summary")) if isinstance(analysis_bundle, dict) else False,
        "logging_hook_summary_present": bool(analysis_bundle.get("logging_hook_summary")) if isinstance(analysis_bundle, dict) else False,
        "capability_surface_present": bool(analysis_bundle.get("capability_surface_summary")) if isinstance(analysis_bundle, dict) else False,
        "observation_target_surface_present": bool(analysis_bundle.get("observation_target_surface_summary")) if isinstance(analysis_bundle, dict) else False,
        "operator_ready_summary_present": bool(analysis_bundle.get("operator_ready_summary")) if isinstance(analysis_bundle, dict) else False,
        "stress_surface_summary_present": bool(analysis_bundle.get("stress_surface_summary")) if isinstance(analysis_bundle, dict) else False,
        "cross_line_consolidation_summary_present": bool(analysis_bundle.get("cross_line_consolidation_summary")) if isinstance(analysis_bundle, dict) else False,
        "external_adoption_summary_present": bool(analysis_bundle.get("external_adoption_summary")) if isinstance(analysis_bundle, dict) else False,
        "publication_packaging_summary_present": bool(analysis_bundle.get("publication_packaging_summary")) if isinstance(analysis_bundle, dict) else False,
        "benchmark_positioning_summary_present": bool(analysis_bundle.get("benchmark_positioning_summary")) if isinstance(analysis_bundle, dict) else False,
        "inverse_reporting_present": inverse_reporting_present,
        "fair_budget_summary_present": bool(fair_budget_facts),
        "fair_budget_summary": fair_budget_facts.get("summary"),
        "targeted_rows_missing_comparison_count": fair_budget_facts.get("targeted_rows_missing_comparison_count"),
        "headline_eligible_group_count": fair_budget_facts.get("headline_eligible_group_count"),
        "blocked_headline_group_count": fair_budget_facts.get("blocked_headline_group_count"),
        "headline_tasks_with_eligible_groups": fair_budget_facts.get("headline_tasks_with_eligible_groups"),
        "regime_summary_present": bool(regime_facts.get("regime_summary_present")),
        "ood_protocol_families_present": regime_facts.get("ood_protocol_families_present", []),
        "headline_regime_group_count": regime_facts.get("headline_regime_group_count", 0),
        "blocked_regime_group_count": regime_facts.get("blocked_regime_group_count", 0),
        "mixed_distribution_group_count": regime_facts.get("mixed_distribution_group_count", 0),
        "mixed_ood_family_group_count": regime_facts.get("mixed_ood_family_group_count", 0),
        "regime_hosts_with_complete_labels": regime_facts.get("regime_hosts_with_complete_labels", {}),
        "geometry_targeted_row_count": regime_facts.get("geometry_targeted_row_count", 0),
        "geometry_group_count": regime_facts.get("geometry_group_count", 0),
        "mixed_geometry_distribution_group_count": regime_facts.get("mixed_geometry_distribution_group_count", 0),
        "mixed_geometry_class_group_count": regime_facts.get("mixed_geometry_class_group_count", 0),
        "geometry_hosts_with_complete_labels": regime_facts.get("geometry_hosts_with_complete_labels", {}),
    }


def _starter_scene_summary(*, checked_root: Path, starter_pack: str) -> dict[str, object]:
    grouped_json_path = checked_root / "_leaderboard" / "leaderboard_grouped.json"
    grouped_payload = _load_grouped_payload(grouped_json_path)
    analysis_dir = checked_root / "_analysis"
    analysis_bundle = _load_analysis_bundle_payload(analysis_dir)
    regime_facts = _v1_8_regime_facts(
        grouped_payload=grouped_payload,
        checked_root=checked_root,
        matrix_manifest=_infer_starter_manifest_from_outputs_root(checked_root),
    )
    return {
        "starter_pack": starter_pack,
        "reference_preview_line": STARTER_REFERENCE_PREVIEW_LINE,
        "checked_outputs_root": str(checked_root.resolve()),
        "analysis_bundle_present": (analysis_dir / "analysis_bundle.json").exists(),
        "leaderboard_protocol_bundle_present": (checked_root / "_leaderboard_protocol" / "leaderboard_protocol_bundle.json").exists(),
        "regime_summary_present": bool(regime_facts.get("regime_summary_present")),
        "geometry_group_count": regime_facts.get("geometry_group_count", 0),
        "geometry_targeted_row_count": regime_facts.get("geometry_targeted_row_count", 0),
        "mixed_geometry_distribution_group_count": regime_facts.get("mixed_geometry_distribution_group_count", 0),
        "mixed_geometry_class_group_count": regime_facts.get("mixed_geometry_class_group_count", 0),
        "geometry_hosts_with_complete_labels": regime_facts.get("geometry_hosts_with_complete_labels", {}),
        "geometry_classes_present": list((regime_facts.get("regime_summary") or {}).get("geometry_classes_present", [])),
        "analysis_pack_identity_present": bool(isinstance(analysis_bundle, dict) and analysis_bundle.get("pack_identity")),
    }


def _append_bundle_checks(results: list[CheckResult], bundle_dir: Path) -> None:
    payload = build_submission_validation_payload(bundle_dir)
    for check in payload.get("checks", []):
        if not isinstance(check, dict):
            continue
        results.append(
            CheckResult(
                code=f"community.{check.get('code')}",
                severity=str(check.get("severity", "error")),
                status=str(check.get("status", "fail")),
                message=str(check.get("message", "Bundle validation check.")),
                path=None if check.get("path") is None else str(check.get("path")),
            )
        )


def _append_scaffold_checks(results: list[CheckResult], scaffold_root: Path) -> None:
    _append_path_check(
        results,
        code="community.scaffold.root",
        severity="error",
        path=scaffold_root,
        success_message="Found scaffold root.",
        failure_message="Missing scaffold root.",
    )
    if not scaffold_root.exists():
        return

    readme_path = scaffold_root / "README.md"
    code_files = sorted(
        path
        for path in scaffold_root.rglob("*.py")
        if path.is_file() and "tests" not in path.parts
    )
    test_files = sorted(scaffold_root.rglob("tests/test_*.py"))
    config_files = sorted(
        path
        for path in scaffold_root.rglob("*_example.yaml")
        if "configs" in path.parts
    )
    card_files = sorted(scaffold_root.rglob("*card.md"))
    checklist_path = scaffold_root / "CHECKLIST.md"

    _append_path_check(
        results,
        code="community.scaffold.readme",
        severity="error",
        path=readme_path,
        success_message="Found scaffold README.",
        failure_message="Missing scaffold README.",
    )
    results.append(
        _result(
            "community.scaffold.code",
            "error",
            bool(code_files),
            "Found scaffold implementation file." if code_files else "Missing scaffold implementation file.",
            path=None if not code_files else code_files[0],
        )
    )
    results.append(
        _result(
            "community.scaffold.tests",
            "error",
            bool(test_files),
            "Found scaffold test stub." if test_files else "Missing scaffold test stub.",
            path=None if not test_files else test_files[0],
        )
    )
    results.append(
        _result(
            "community.scaffold.config",
            "error",
            bool(config_files),
            "Found scaffold example config." if config_files else "Missing scaffold example config.",
            path=None if not config_files else config_files[0],
        )
    )
    results.append(
        _result(
            "community.scaffold.card",
            "warning",
            bool(card_files),
            "Found scaffold card stub." if card_files else "Missing scaffold card stub.",
            path=None if not card_files else card_files[0],
        )
    )
    _append_path_check(
        results,
        code="community.scaffold.checklist",
        severity="warning",
        path=checklist_path,
        success_message="Found scaffold checklist.",
        failure_message="Missing scaffold checklist.",
    )
    todo_hits = []
    for candidate in [readme_path, *code_files, *test_files, *config_files, *card_files, checklist_path]:
        if candidate.exists() and "TODO" in candidate.read_text(encoding="utf-8"):
            todo_hits.append(candidate)
    results.append(
        _result(
            "community.scaffold.todo_markers",
            "warning",
            not todo_hits,
            "No unresolved TODO markers detected in the scaffold root." if not todo_hits else f"Scaffold still contains TODO markers in {len(todo_hits)} file(s).",
            path=None if not todo_hits else todo_hits[0],
        )
    )

    readme_text = readme_path.read_text(encoding="utf-8") if readme_path.exists() else ""
    checklist_text = checklist_path.read_text(encoding="utf-8") if checklist_path.exists() else ""
    code_text = "\n".join(path.read_text(encoding="utf-8") for path in code_files if path.exists())
    operator_scaffold = "BaseOperatorModel" in code_text or "forward_field(" in code_text or "operator model" in readme_text.lower()
    if operator_scaffold:
        has_smoke_command = "pinn-bench run --config" in readme_text
        results.append(
            _result(
                "community.scaffold.operator_smoke_command",
                "warning",
                has_smoke_command,
                "Operator scaffold README includes at least one smoke command."
                if has_smoke_command
                else "Operator scaffold README should include at least one smoke command.",
                path=readme_path,
            )
        )
        mentions_forward_field = "forward_field" in readme_text or "forward_field" in checklist_text
        results.append(
            _result(
                "community.scaffold.operator_forward_field_docs",
                "warning",
                mentions_forward_field,
                "Operator scaffold docs mention forward_field(...)."
                if mentions_forward_field
                else "Operator scaffold docs should mention forward_field(...).",
                path=readme_path if "forward_field" in readme_text else checklist_path,
            )
        )



def _report_paths(outputs_root: Path, matrix_manifest: Path | None) -> list[tuple[str, Path, str]]:
    reporting_dir = outputs_root / "_leaderboard" / "reporting"
    pareto_dir = outputs_root / "_leaderboard" / "pareto"
    grouped_json = outputs_root / "_leaderboard" / "leaderboard_grouped.json"
    run_report_dir = outputs_root / "_matrix_runs"
    snapshot = outputs_root / "_release_snapshot.json"

    paths: list[tuple[str, Path, str]] = [
        ("results.outputs_root", outputs_root, "outputs root"),
        ("results.grouped_json", grouped_json, "grouped leaderboard"),
        ("results.reporting_dir", reporting_dir, "reporting directory"),
        ("results.pareto_dir", pareto_dir, "pareto directory"),
        ("results.run_report_dir", run_report_dir, "run report directory"),
    ]
    if matrix_manifest is not None:
        matrix_name = matrix_manifest.stem
        paths.extend(
            [
                (f"results.run_report_json.{matrix_name}", run_report_dir / f"{matrix_name}_run_report.json", "run report JSON"),
                (f"results.run_report_csv.{matrix_name}", run_report_dir / f"{matrix_name}_run_report.csv", "run report CSV"),
                (f"results.release_snapshot.{matrix_name}", snapshot, "release snapshot"),
            ]
        )
        if matrix_name in {"baseline_v1_7_preview", "baseline_v1_8_preview", "baseline_v1_9_preview"}:
            paths.extend(
                [
                    (f"results.matched_budget_csv.{matrix_name}", reporting_dir / f"{matrix_name}_matched_budget_table.csv", "matched-budget CSV"),
                    (f"results.matched_budget_md.{matrix_name}", reporting_dir / f"{matrix_name}_matched_budget_table.md", "matched-budget Markdown"),
                    (f"results.matched_budget_tex.{matrix_name}", reporting_dir / f"{matrix_name}_matched_budget_table.tex", "matched-budget LaTeX"),
                    (f"results.fairness_coverage_json.{matrix_name}", reporting_dir / f"{matrix_name}_fairness_coverage.json", "fairness coverage JSON"),
                    (f"results.fairness_coverage_md.{matrix_name}", reporting_dir / f"{matrix_name}_fairness_coverage.md", "fairness coverage Markdown"),
                    (f"results.accuracy_cost_pareto_csv.{matrix_name}", pareto_dir / f"{matrix_name}_accuracy_cost_pareto.csv", "accuracy-cost pareto CSV"),
                    (f"results.accuracy_cost_pareto_md.{matrix_name}", pareto_dir / f"{matrix_name}_accuracy_cost_pareto.md", "accuracy-cost pareto Markdown"),
                ]
            )
    else:
        paths.append(("results.release_snapshot", snapshot, "release snapshot"))
    return paths



def _check_grouped_manifest_reference(results: list[CheckResult], grouped_json_path: Path, *, formal_mode: bool) -> None:
    if not grouped_json_path.exists():
        return
    payload = json.loads(grouped_json_path.read_text(encoding="utf-8"))
    matrix_manifest = str(payload.get("matrix_manifest", ""))
    if formal_mode and matrix_manifest.endswith("_preview.yaml"):
        results.append(
            _result(
                "results.grouped_manifest_reference",
                "warning",
                False,
                "Formal grouped leaderboard references the preview manifest.",
                path=grouped_json_path,
            )
        )
    else:
        results.append(
            _result(
                "results.grouped_manifest_reference",
                "info",
                True,
                "Grouped leaderboard manifest reference looks consistent.",
                path=grouped_json_path,
            )
        )



def _check_release_snapshot_reference(results: list[CheckResult], snapshot_path: Path, *, formal_mode: bool) -> None:
    if not snapshot_path.exists():
        return
    payload = json.loads(snapshot_path.read_text(encoding="utf-8"))
    manifest_path = str(payload.get("manifest_path", ""))
    if formal_mode and manifest_path.endswith("_preview.yaml"):
        results.append(
            _result(
                "results.release_snapshot_reference",
                "warning",
                False,
                "Formal release snapshot references the preview manifest.",
                path=snapshot_path,
            )
        )
    else:
        results.append(
            _result(
                "results.release_snapshot_reference",
                "info",
                True,
                "Release snapshot manifest reference looks consistent.",
                path=snapshot_path,
            )
        )



def _check_root_pollution(results: list[CheckResult], outputs_root: Path, *, formal_mode: bool) -> None:
    if not outputs_root.exists():
        return
    suspicious_dirs = [
        child.name
        for child in outputs_root.iterdir()
        if child.is_dir() and not child.name.startswith("_") and any(token in child.name.lower() for token in ("demo", "preview"))
    ]
    if formal_mode and suspicious_dirs:
        results.append(
            _result(
                "results.formal_root_pollution",
                "warning",
                False,
                f"Possible preview/demo pollution in formal root: {', '.join(sorted(suspicious_dirs))}",
                path=outputs_root,
            )
        )
    else:
        results.append(
            _result(
                "results.formal_root_pollution",
                "info",
                True,
                "No obvious demo/preview pollution detected in the inspected outputs root.",
                path=outputs_root,
            )
        )



def build_doctor_payload(
    *,
    mode: str,
    outputs_root_arg: str | None,
    matrix_manifest_arg: str | None,
    strict: bool,
    submission_bundle_arg: str | None = None,
    scaffold_root_arg: str | None = None,
) -> dict[str, object]:
    repo_root = resolve_repo_root()
    matrix_manifest = None if matrix_manifest_arg is None else resolve_manifest_path(matrix_manifest_arg)

    if outputs_root_arg is not None:
        inspected_roots = [resolve_outputs_root(outputs_root_arg)]
    elif submission_bundle_arg is not None or scaffold_root_arg is not None:
        inspected_roots = []
    else:
        inspected_roots = [root.resolve() for root in _default_roots(mode, repo_root)]

    if matrix_manifest is None and mode == FORMAL_MODE and inspected_roots:
        matrix_manifest = _infer_formal_manifest_from_outputs_root(inspected_roots[0])
    if matrix_manifest is None and mode == STARTER_MODE and inspected_roots:
        matrix_manifest = _infer_starter_manifest_from_outputs_root(inspected_roots[0])
    if matrix_manifest is None and mode == PREVIEW_MODE and inspected_roots:
        matrix_manifest = _infer_preview_manifest_from_outputs_root(inspected_roots[0])
    if matrix_manifest is None:
        matrix_manifest = _default_manifest(mode)

    results: list[CheckResult] = []
    checked_root = inspected_roots[0] if inspected_roots else None
    starter_pack = None if checked_root is None else _infer_starter_pack(checked_root=checked_root, matrix_manifest=matrix_manifest)
    preview_line = None if checked_root is None else _infer_preview_line(checked_root=checked_root, matrix_manifest=matrix_manifest)
    active_starter = mode == STARTER_MODE and checked_root is not None and starter_pack == STARTER_PACK_ID
    active_operator_preview = (
        mode == PREVIEW_MODE
        and checked_root is not None
        and preview_line in {"v0.6-preview", "v0.7-preview", "v0.8-preview", "v0.9-preview", "v1.1-preview", "v1.2-preview", "v1.3-preview", "v1.4-preview", "v1.5-preview", "v1.6-preview", "v1.7-preview", "v1.8-preview", "v1.9-preview"}
    )
    governed_preview_lines = {line for line in (KNOWN_PREVIEW_LINE, LATEST_COMPLETED_PREVIEW_LINE, "v1.8-preview", "v1.9-preview") if line}
    active_analysis_preview = active_operator_preview and preview_line in governed_preview_lines

    repo_checks = [
        ("repo.formal_manifest_v01", resolve_manifest_path("baseline_v0_1.yaml"), "formal manifest v0.1"),
        ("repo.formal_manifest_v02", resolve_manifest_path("baseline_v0_2.yaml"), "formal manifest v0.2"),
        ("repo.formal_manifest_v03", resolve_manifest_path("baseline_v0_3.yaml"), "formal manifest v0.3"),
        ("repo.formal_manifest_v04", resolve_manifest_path("baseline_v0_4.yaml"), "formal manifest v0.4"),
        ("repo.formal_manifest_v05", resolve_manifest_path("baseline_v0_5.yaml"), "historical formal manifest v0.5"),
        ("repo.formal_manifest_v06", resolve_manifest_path("baseline_v0_6.yaml"), "historical formal manifest v0.6"),
        ("repo.formal_manifest_v10", resolve_manifest_path("baseline_v1_0_formal.yaml"), "current formal manifest v1.0"),
        ("repo.preview_manifest_v02", resolve_manifest_path("baseline_v0_2_preview.yaml"), "historical preview manifest v0.2"),
        ("repo.preview_manifest_v04", resolve_manifest_path("baseline_v0_4_preview.yaml"), "preview manifest v0.4"),
        ("repo.preview_manifest_v05", resolve_manifest_path("baseline_v0_5_preview.yaml"), "historical preview manifest v0.5"),
        ("repo.preview_manifest_v06", resolve_manifest_path("baseline_v0_6_preview.yaml"), "historical preview manifest v0.6"),
        ("repo.preview_manifest_v07", resolve_manifest_path("baseline_v0_7_preview.yaml"), "historical preview manifest v0.7"),
        ("repo.preview_manifest_v08", resolve_manifest_path("baseline_v0_8_preview.yaml"), "historical preview manifest v0.8"),
        ("repo.preview_manifest_v09", resolve_manifest_path("baseline_v0_9_preview.yaml"), "historical preview manifest v0.9"),
        ("repo.preview_manifest_v11", resolve_manifest_path("baseline_v1_1_preview.yaml"), "latest completed preview manifest v1.1"),
        ("repo.preview_manifest_v12", resolve_manifest_path("baseline_v1_2_preview.yaml"), "active preview manifest v1.2"),
        ("repo.docs_index", repo_root / "docs" / "index.md", "docs index"),
        ("repo.docs_product_index", repo_root / "docs" / "product" / "index.md", "product docs index"),
        ("repo.product.presets", repo_root / "docs" / "product" / "presets.md", "product preset guide"),
        ("repo.product.demo", repo_root / "docs" / "product" / "demo.md", "product demo guide"),
        ("repo.product.scaffold", repo_root / "docs" / "product" / "scaffold.md", "product scaffold guide"),
        ("repo.product.doctor", repo_root / "docs" / "product" / "doctor.md", "product doctor guide"),
        ("repo.product.audit", repo_root / "docs" / "product" / "audit.md", "product audit guide"),
        ("repo.product.analysis", repo_root / "docs" / "product" / "analysis.md", "product analysis guide"),
        ("repo.product.versioning", repo_root / "docs" / "product" / "versioning.md", "product versioning guide"),
        ("repo.cards.tasks_index", repo_root / "docs" / "tasks" / "index.md", "tasks card index"),
        ("repo.cards.models_index", repo_root / "docs" / "models" / "index.md", "models card index"),
        ("repo.cards.protocols_index", repo_root / "docs" / "protocols" / "index.md", "protocols card index"),
        ("repo.community.index", repo_root / "docs" / "community" / "index.md", "community docs index"),
        ("repo.community.external_model", repo_root / "docs" / "community" / "adding-an-external-model.md", "external model guide"),
        ("repo.community.external_task", repo_root / "docs" / "community" / "adding-an-external-task.md", "external task guide"),
        ("repo.community.submission_schema", repo_root / "docs" / "community" / "submission-schema.md", "submission schema guide"),
        ("repo.community.submission_standard_v1", repo_root / "docs" / "community" / "submission-standard-v1.md", "submission standard v1 guide"),
        ("repo.community.compatibility_rules", repo_root / "docs" / "community" / "compatibility-rules.md", "compatibility rules guide"),
        ("repo.community.bundle", repo_root / "docs" / "community" / "result-bundle.md", "result bundle guide"),
        ("repo.community.compare", repo_root / "docs" / "community" / "compare-external-results.md", "external comparison guide"),
        ("repo.community.reviewing_external_submission", repo_root / "docs" / "community" / "reviewing-an-external-submission.md", "external submission review guide"),
        ("repo.community.smoke_checklist", repo_root / "docs" / "community" / "community-smoke-checklist.md", "community smoke checklist"),
        ("repo.community.submission_faq", repo_root / "docs" / "community" / "submission-faq.md", "submission FAQ"),
        ("repo.guides.adding_metric", repo_root / "docs" / "metrics" / "adding-a-metric.md", "metric extension guide"),
        ("repo.guides.adding_task", repo_root / "docs" / "tasks" / "adding-a-task.md", "task extension guide"),
        ("repo.version_policy", repo_root / "docs" / "experiments" / "version-policy.md", "version policy"),
        ("repo.preview_doc_v05", repo_root / "docs" / "experiments" / "v0_5_preview.md", "v0.5 preview doc"),
        ("repo.preview_scope_v05", repo_root / "docs" / "experiments" / "v0_5_scope.md", "v0.5 scope doc"),
        ("repo.preview_governance_v05", repo_root / "docs" / "experiments" / "v0_5_governance.md", "v0.5 governance doc"),
        ("repo.preview_doc_v06", repo_root / "docs" / "experiments" / "v0_6_preview.md", "v0.6 preview doc"),
        ("repo.preview_scope_v06", repo_root / "docs" / "experiments" / "v0_6_scope.md", "v0.6 scope doc"),
        ("repo.preview_governance_v06", repo_root / "docs" / "experiments" / "v0_6_governance.md", "v0.6 governance doc"),
        ("repo.preview_doc_v07", repo_root / "docs" / "experiments" / "v0_7_preview.md", "v0.7 preview doc"),
        ("repo.preview_scope_v07", repo_root / "docs" / "experiments" / "v0_7_scope.md", "v0.7 scope doc"),
        ("repo.preview_governance_v07", repo_root / "docs" / "experiments" / "v0_7_governance.md", "v0.7 governance doc"),
        ("repo.preview_doc_v08", repo_root / "docs" / "experiments" / "v0_8_preview.md", "v0.8 preview doc"),
        ("repo.preview_scope_v08", repo_root / "docs" / "experiments" / "v0_8_scope.md", "v0.8 scope doc"),
        ("repo.preview_governance_v08", repo_root / "docs" / "experiments" / "v0_8_governance.md", "v0.8 governance doc"),
        ("repo.preview_doc_v09", repo_root / "docs" / "experiments" / "v0_9_preview.md", "v0.9 preview doc"),
        ("repo.preview_scope_v09", repo_root / "docs" / "experiments" / "v0_9_scope.md", "v0.9 scope doc"),
        ("repo.preview_governance_v09", repo_root / "docs" / "experiments" / "v0_9_governance.md", "v0.9 governance doc"),
        ("repo.preview_doc_v12", repo_root / "docs" / "product" / "v1_2_preview.md", "v1.2 preview doc"),
        ("repo.preview_scope_v12", repo_root / "docs" / "product" / "v1_2_scope.md", "v1.2 scope doc"),
        ("repo.preview_governance_v12", repo_root / "docs" / "product" / "v1_2_governance.md", "v1.2 governance doc"),
        ("repo.examples.external_model", repo_root / "examples" / "external_model_example" / "README.md", "external model example"),
        ("repo.examples.external_task", repo_root / "examples" / "external_task_example" / "README.md", "external task example"),
        ("repo.examples.external_submission", repo_root / "examples" / "external_submission_example" / "README.md", "external submission example"),
        ("repo.examples.external_submission_v2", repo_root / "examples" / "external_submission_example_v2" / "README.md", "external submission example v2"),
        ("repo.community.reviewing_bundle", repo_root / "docs" / "community" / "reviewing-a-bundle.md", "bundle review guide"),
        ("repo.community.submission_lifecycle", repo_root / "docs" / "community" / "submission-lifecycle.md", "submission lifecycle guide"),
        ("repo.community.community_review_checklist", repo_root / "docs" / "community" / "community_review_checklist.md", "community review checklist"),
        ("repo.product.review_packet_schema", repo_root / "docs" / "product" / "review_packet_schema.md", "review packet schema notes"),
        ("repo.preset_catalog", repo_root / "pinn_bench" / "presets" / "__init__.py", "preset catalog"),
    ]
    for code, path, label in repo_checks:
        _append_path_check(
            results,
            code=code,
            severity="error",
            path=path,
            success_message=f"Found {label}.",
            failure_message=f"Missing {label}.",
        )
    if mode == STARTER_MODE:
        _append_path_check(
            results,
            code="repo.starter_manifest",
            severity="error",
            path=resolve_manifest_path(STARTER_MANIFEST_NAME),
            success_message="Found starter manifest.",
            failure_message="Missing starter manifest.",
        )
        _append_path_check(
            results,
            code="repo.starter_doc",
            severity="warning",
            path=repo_root / "docs" / "product" / "post_v1_8_geometry_starter_pack.md",
            success_message="Found starter-pack product doc.",
            failure_message="Missing starter-pack product doc.",
        )

    if active_operator_preview:
        operator_doc_paths = [
            repo_root / "docs" / "models" / "operator-model-contract.md",
            repo_root / "docs" / "tasks" / "operator-ready-tasks.md",
            repo_root / "docs" / "community" / "adding-an-operator-model.md",
            repo_root / "docs" / "community" / "operator-benchmark-faq.md",
            repo_root / "docs" / "community" / "operator-smoke-checklist.md",
        ]
        operator_task_card_paths = [
            repo_root / "docs" / "tasks" / "heat1d_field-card.md",
            repo_root / "docs" / "tasks" / "poisson2d_field-card.md",
        ]
        if preview_line in {"v0.8-preview", "v0.9-preview", "v1.1-preview"}:
            operator_task_card_paths.append(repo_root / "docs" / "tasks" / "wave1d_field-card.md")
        operator_example_path = repo_root / "examples" / "operator_model_example" / "README.md"
        _append_path_check(
            results,
            code="preview.operator_example",
            severity="warning",
            path=operator_example_path,
            success_message="Found operator example README.",
            failure_message="Missing operator example README.",
        )
        _append_collection_check(
            results,
            code="preview.operator_docs",
            severity="warning",
            paths=operator_doc_paths,
            success_message="Found operator preview docs chain.",
            failure_message="Missing one or more operator preview docs.",
        )
        _append_collection_check(
            results,
            code="preview.operator_task_cards",
            severity="warning",
            paths=operator_task_card_paths,
            success_message="Found operator task cards.",
            failure_message="Missing one or more operator task cards.",
        )

    preset_issues = validate_preset_catalog()
    if preset_issues:
        for issue in preset_issues:
            results.append(_result("repo.preset_catalog_validation", "error", False, issue))
    else:
        results.append(_result("repo.preset_catalog_validation", "info", True, "Preset catalog targets and safe roots validated."))

    for mode_name in sorted(DEMO_SPECS):
        try:
            for resource_path in demo_resource_checks(mode_name):
                results.append(
                    _result(
                        f"repo.demo_resources.{mode_name}",
                        "info",
                        True,
                        f"Resolved demo dependency for mode '{mode_name}'.",
                        path=resource_path,
                    )
                )
        except FileNotFoundError as error:
            results.append(_result(f"repo.demo_resources.{mode_name}", "error", False, str(error)))

    for index, outputs_root in enumerate(inspected_roots):
        severity = "error" if mode == FORMAL_MODE else "warning"
        for code, path, label in _report_paths(outputs_root, matrix_manifest if index == 0 else None):
            _append_path_check(
                results,
                code=f"{code}.{index}" if len(inspected_roots) > 1 else code,
                severity=severity,
                path=path,
                success_message=f"Found {label}.",
                failure_message=f"Missing {label}.",
            )
        _check_root_pollution(results, outputs_root, formal_mode=(mode == FORMAL_MODE))
        _check_grouped_manifest_reference(results, outputs_root / "_leaderboard" / "leaderboard_grouped.json", formal_mode=(mode == FORMAL_MODE))
        _check_release_snapshot_reference(results, outputs_root / "_release_snapshot.json", formal_mode=(mode == FORMAL_MODE))
        if mode == FORMAL_MODE and _requires_formal_v10_analysis(outputs_root, matrix_manifest if index == 0 else None):
            _append_collection_check(
                results,
                code="results.formal_v10_analysis_assets",
                severity="error",
                paths=_formal_v10_analysis_paths(outputs_root),
                success_message="Found formal v1.0 freeze-analysis assets.",
                failure_message="Missing one or more formal v1.0 freeze-analysis assets.",
            )

    if submission_bundle_arg is not None:
        _append_bundle_checks(results, resolve_outputs_root(submission_bundle_arg))

    if scaffold_root_arg is not None:
        _append_scaffold_checks(results, resolve_outputs_root(scaffold_root_arg))

    if active_operator_preview and checked_root is not None:
        grouped_json_path = checked_root / "_leaderboard" / "leaderboard_grouped.json"
        field_rows = _field_rows(_load_grouped_rows(grouped_json_path))
        mode_fields_present = bool(field_rows) and all(
            bool(row.get("task_mode")) and bool(row.get("model_mode")) and bool(row.get("evaluation_mode"))
            for row in field_rows
        )
        results.append(
            _result(
                "preview.field_mode_fields",
                "warning",
                mode_fields_present,
                "Field rows expose task_mode, model_mode, and evaluation_mode."
                if mode_fields_present
                else "Field rows should expose task_mode, model_mode, and evaluation_mode.",
                path=grouped_json_path,
            )
        )
        if active_analysis_preview:
            analysis_dir = checked_root / "_analysis"
            analysis_paths = required_analysis_asset_paths(analysis_dir, preview_line=preview_line)
            _append_collection_check(
                results,
                code="preview.analysis_assets",
                severity="warning",
                paths=analysis_paths,
                success_message="Found analysis preview assets.",
                failure_message="Missing one or more analysis preview assets.",
            )
            if preview_line in {"v1.2-preview", "v1.3-preview", "v1.4-preview", "v1.5-preview", "v1.6-preview", "v1.7-preview", "v1.8-preview", "v1.9-preview"}:
                protocol_dir = checked_root / "_leaderboard_protocol"
                protocol_paths = [
                    protocol_dir / "leaderboard_protocol_bundle.json",
                    protocol_dir / "admission_registry.json",
                    protocol_dir / "admission_registry.md",
                    protocol_dir / "governance_packet.json",
                    protocol_dir / "governance_packet.md",
                    protocol_dir / "main_leaderboard.json",
                    protocol_dir / "main_leaderboard.md",
                    protocol_dir / "stress_leaderboard.json",
                    protocol_dir / "stress_leaderboard.md",
                    protocol_dir / "pareto_leaderboard.json",
                    protocol_dir / "pareto_leaderboard.md",
                    protocol_dir / "parameter_efficiency.json",
                    protocol_dir / "parameter_efficiency.md",
                ]
                _append_collection_check(
                    results,
                    code="preview.leaderboard_protocol_assets",
                    severity="warning",
                    paths=protocol_paths,
                    success_message="Found leaderboard protocol assets.",
                    failure_message="Missing one or more leaderboard protocol assets.",
                )
                example_root = checked_root / "_submission_imports" / "examples"
                example_import_count = len(list(example_root.rglob("leaderboard_entry_candidate.json"))) if example_root.exists() else 0
                expected_examples_ok = example_import_count == 3
                expected_examples_message = (
                    "Found the three canonical example imported submissions for the leaderboard protocol surface."
                    if example_import_count == 3
                    else "Expected exactly three canonical example imported submissions under _submission_imports/examples."
                )
                if preview_line in {"v1.7-preview", "v1.8-preview", "v1.9-preview"}:
                    fair_budget_payload = _v1_7_fair_budget_facts(_load_grouped_payload(grouped_json_path))
                    imported_reference_row_count = int(fair_budget_payload.get("summary", {}).get("imported_reference_row_count", 0) or 0)
                    expected_examples_ok = imported_reference_row_count == 4
                    expected_examples_message = (
                        f"Found the four canonical imported classical-reference rows required by the {preview_line} fair-budget program."
                        if imported_reference_row_count == 4
                        else f"Expected four imported classical-reference rows in the {preview_line} fair-budget surface."
                    )
                results.append(
                    _result(
                        "preview.leaderboard_protocol_examples",
                        "warning",
                        expected_examples_ok,
                        expected_examples_message,
                        path=example_root,
                    )
                )
                if preview_line in {"v1.3-preview", "v1.4-preview", "v1.5-preview", "v1.6-preview", "v1.7-preview", "v1.8-preview", "v1.9-preview"}:
                    analysis_bundle = _load_analysis_bundle_payload(analysis_dir)
                    dx_present = isinstance(analysis_bundle, dict) and all(
                        key in analysis_bundle
                        for key in (
                            "dx_surface_summary",
                            "template_catalog_summary",
                            "quickstart_surface_summary",
                            "logging_hook_summary",
                        )
                    )
                    results.append(
                        _result(
                            "preview.dx_surface_summary",
                            "warning",
                            dx_present,
                            "Found additive DX summaries in the preview analysis bundle."
                            if dx_present
                            else "Missing one or more additive DX summaries in the preview analysis bundle.",
                            path=analysis_dir / "analysis_bundle.json",
                        )
                    )
                    if preview_line in {"v1.4-preview", "v1.5-preview", "v1.6-preview", "v1.7-preview", "v1.8-preview", "v1.9-preview"}:
                        capability_present = isinstance(analysis_bundle, dict) and all(
                            key in analysis_bundle
                            for key in (
                                "capability_surface_summary",
                                "observation_target_surface_summary",
                                "operator_ready_summary",
                            )
                        )
                        results.append(
                            _result(
                                "preview.operator_abstraction_summary",
                                "warning",
                                capability_present,
                                "Found additive operator-abstraction summaries in the preview analysis bundle."
                                if capability_present
                                else "Missing one or more additive operator-abstraction summaries in the preview analysis bundle.",
                                path=analysis_dir / "analysis_bundle.json",
                            )
                        )
                    if preview_line in {"v1.5-preview", "v1.6-preview", "v1.7-preview", "v1.8-preview", "v1.9-preview"}:
                        stress_surface_present = isinstance(analysis_bundle, dict) and "stress_surface_summary" in analysis_bundle
                        results.append(
                            _result(
                                "preview.stress_surface_summary",
                                "warning",
                                stress_surface_present,
                                f"Found additive stress-surface summary in the {preview_line} analysis bundle."
                                if stress_surface_present
                                else f"Missing additive stress-surface summary in the {preview_line} analysis bundle.",
                                path=analysis_dir / "analysis_bundle.json",
                            )
                        )
                        consolidation_present = isinstance(analysis_bundle, dict) and "cross_line_consolidation_summary" in analysis_bundle
                        results.append(
                            _result(
                                "preview.cross_line_consolidation_summary",
                                "warning",
                                consolidation_present,
                                "Found additive cross-line consolidation summary in the v1.5 analysis bundle."
                                if consolidation_present
                                else "Missing additive cross-line consolidation summary in the v1.5 analysis bundle.",
                                path=analysis_dir / "analysis_bundle.json",
                            )
                        )
                    packaging_present = False
                    if preview_line in {"v1.6-preview", "v1.7-preview", "v1.8-preview", "v1.9-preview"}:
                        packaging_present = isinstance(analysis_bundle, dict) and all(
                            key in analysis_bundle
                            for key in (
                                "external_adoption_summary",
                                "publication_packaging_summary",
                                "benchmark_positioning_summary",
                            )
                        )
                    if preview_line in {"v1.7-preview", "v1.8-preview", "v1.9-preview"}:
                        fair_budget_payload = _v1_7_fair_budget_facts(_load_grouped_payload(grouped_json_path))
                        matrix_name = matrix_manifest.stem if matrix_manifest is not None else "baseline_v1_7_preview"
                        matched_budget_paths = [
                            checked_root / "_leaderboard" / "reporting" / f"{matrix_name}_matched_budget_table.csv",
                            checked_root / "_leaderboard" / "reporting" / f"{matrix_name}_matched_budget_table.md",
                            checked_root / "_leaderboard" / "reporting" / f"{matrix_name}_matched_budget_table.tex",
                            checked_root / "_leaderboard" / "reporting" / f"{matrix_name}_fairness_coverage.json",
                            checked_root / "_leaderboard" / "reporting" / f"{matrix_name}_fairness_coverage.md",
                            checked_root / "_leaderboard" / "pareto" / f"{matrix_name}_accuracy_cost_pareto.csv",
                            checked_root / "_leaderboard" / "pareto" / f"{matrix_name}_accuracy_cost_pareto.md",
                        ]
                        _append_collection_check(
                            results,
                            code="preview.fair_budget_assets",
                            severity="warning",
                            paths=matched_budget_paths,
                            success_message=f"Found carried-forward fair-budget reporting assets for {preview_line}.",
                            failure_message=f"Missing one or more carried-forward fair-budget reporting assets for {preview_line}.",
                        )
                        results.append(
                            _result(
                                "preview.fair_budget_targeted_metadata",
                                "warning",
                                int(fair_budget_payload.get("targeted_rows_missing_comparison_count") or 0) == 0,
                                "All R1-targeted grouped rows expose comparison metadata."
                                if int(fair_budget_payload.get("targeted_rows_missing_comparison_count") or 0) == 0
                                else "One or more R1-targeted grouped rows are missing comparison metadata.",
                                path=grouped_json_path,
                            )
                        )
                        results.append(
                            _result(
                                "preview.fair_budget_headline_task_coverage",
                                "warning",
                                set(fair_budget_payload.get("headline_tasks_with_eligible_groups") or []) == set(HEADLINE_TASKS),
                                "All four headline pointwise tasks have at least one headline-eligible matched-budget group."
                                if set(fair_budget_payload.get("headline_tasks_with_eligible_groups") or []) == set(HEADLINE_TASKS)
                                else "One or more headline pointwise tasks are missing a headline-eligible matched-budget group.",
                                path=grouped_json_path,
                            )
                        )
                        results.append(
                            _result(
                                "preview.fair_budget_headline_blockers",
                                "warning",
                                int(fair_budget_payload.get("blocked_headline_group_count") or 0) == 0,
                                "No headline matched-budget groups remain blocked."
                                if int(fair_budget_payload.get("blocked_headline_group_count") or 0) == 0
                                else "One or more headline matched-budget groups remain blocked.",
                                path=grouped_json_path,
                            )
                        )
                    if preview_line in {"v1.8-preview", "v1.9-preview"}:
                        regime_facts = _v1_8_regime_facts(
                            grouped_payload=_load_grouped_payload(grouped_json_path),
                            checked_root=checked_root,
                            matrix_manifest=matrix_manifest,
                        )
                        regime_artifact_paths = [
                            Path(path)
                            for path in regime_facts.get("regime_artifact_paths", {}).values()
                            if path is not None
                        ]
                        _append_collection_check(
                            results,
                            code="preview.regime_assets",
                            severity="warning",
                            paths=regime_artifact_paths,
                            success_message=f"Found {preview_line} regime/OOD reporting artifacts.",
                            failure_message=f"Missing one or more {preview_line} regime/OOD reporting artifacts.",
                        )
                        results.append(
                            _result(
                                "preview.regime_targeted_metadata",
                                "warning",
                                int(regime_facts.get("targeted_rows_missing_complete_labels_count") or 0) == 0,
                                "All R2-A targeted grouped rows expose complete regime labels."
                                if int(regime_facts.get("targeted_rows_missing_complete_labels_count") or 0) == 0
                                else "One or more R2-A targeted grouped rows are missing complete regime labels.",
                                path=grouped_json_path,
                            )
                        )
                        results.append(
                            _result(
                                "preview.regime_headline_distribution_mix",
                                "warning",
                                int(regime_facts.get("mixed_distribution_group_count") or 0) == 0,
                                "No headline regime groups mix ID and OOD rows."
                                if int(regime_facts.get("mixed_distribution_group_count") or 0) == 0
                                else "One or more headline regime groups mix ID and OOD rows.",
                                path=grouped_json_path,
                            )
                        )
                        results.append(
                            _result(
                                "preview.regime_headline_ood_family_mix",
                                "warning",
                                int(regime_facts.get("mixed_ood_family_group_count") or 0) == 0,
                                "No headline regime groups mix multiple OOD protocol families."
                                if int(regime_facts.get("mixed_ood_family_group_count") or 0) == 0
                                else "One or more headline regime groups mix multiple OOD protocol families.",
                                path=grouped_json_path,
                            )
                        )
                        host_requirements = regime_facts.get("host_requirements", {})
                        host_checks = [
                            (
                                "preview.regime_parameter_shift_pointwise_host",
                                bool(host_requirements.get("parameter_shift_pointwise")),
                                "Found a pointwise parameter_shift host with complete regime labels.",
                                "Missing a pointwise parameter_shift host with complete regime labels.",
                            ),
                            (
                                "preview.regime_parameter_shift_operator_host",
                                bool(host_requirements.get("parameter_shift_operator")),
                                "Found an operator parameter_shift host with complete regime labels.",
                                "Missing an operator parameter_shift host with complete regime labels.",
                            ),
                            (
                                "preview.regime_resolution_shift_pointwise_host",
                                bool(host_requirements.get("resolution_shift_pointwise")),
                                "Found a pointwise resolution_shift host with complete regime labels.",
                                "Missing a pointwise resolution_shift host with complete regime labels.",
                            ),
                            (
                                "preview.regime_resolution_shift_operator_host",
                                bool(host_requirements.get("resolution_shift_operator")),
                                "Found an operator resolution_shift host with complete regime labels.",
                                "Missing an operator resolution_shift host with complete regime labels.",
                            ),
                            (
                                "preview.regime_bc_family_shift_pointwise_host",
                                bool(host_requirements.get("bc_family_shift_pointwise")),
                                "Found a pointwise bc_family_shift host with complete regime labels.",
                                "Missing a pointwise bc_family_shift host with complete regime labels.",
                            ),
                            (
                                "preview.regime_ic_family_shift_pointwise_host",
                                bool(host_requirements.get("ic_family_shift_pointwise")),
                                "Found a pointwise ic_family_shift host with complete regime labels.",
                                "Missing a pointwise ic_family_shift host with complete regime labels.",
                            ),
                        ]
                        for code, passed, success_message, failure_message in host_checks:
                            results.append(
                                _result(
                                    code,
                                    "warning",
                                    passed,
                                    success_message if passed else failure_message,
                                    path=grouped_json_path,
                                )
                            )
                        geometry_targeted_row_count = int(regime_facts.get("geometry_targeted_row_count") or 0)
                        if geometry_targeted_row_count > 0:
                            results.append(
                                _result(
                                    "preview.geometry_targeted_metadata",
                                    "warning",
                                    int(regime_facts.get("geometry_targeted_rows_missing_complete_labels_count") or 0) == 0,
                                    "All geometry-targeted grouped rows expose complete geometry and regime labels."
                                    if int(regime_facts.get("geometry_targeted_rows_missing_complete_labels_count") or 0) == 0
                                    else "One or more geometry-targeted grouped rows are missing complete geometry or regime labels.",
                                    path=grouped_json_path,
                                )
                            )
                            results.append(
                                _result(
                                    "preview.geometry_required_metrics",
                                    "warning",
                                    int(regime_facts.get("geometry_targeted_rows_missing_required_metrics_count") or 0) == 0,
                                    "All geometry-targeted grouped rows expose near-boundary and residual metrics."
                                    if int(regime_facts.get("geometry_targeted_rows_missing_required_metrics_count") or 0) == 0
                                    else "One or more geometry-targeted grouped rows are missing near-boundary or residual metrics.",
                                    path=grouped_json_path,
                                )
                            )
                            results.append(
                                _result(
                                    "preview.geometry_distribution_mix",
                                    "warning",
                                    int(regime_facts.get("mixed_geometry_distribution_group_count") or 0) == 0,
                                    "No geometry claim groups mix multiple geometry-distribution labels."
                                    if int(regime_facts.get("mixed_geometry_distribution_group_count") or 0) == 0
                                    else "One or more geometry claim groups mix multiple geometry-distribution labels.",
                                    path=grouped_json_path,
                                )
                            )
                            results.append(
                                _result(
                                    "preview.geometry_class_mix",
                                    "warning",
                                    int(regime_facts.get("mixed_geometry_class_group_count") or 0) == 0,
                                    "No geometry claim groups mix multiple derived geometry classes."
                                    if int(regime_facts.get("mixed_geometry_class_group_count") or 0) == 0
                                    else "One or more geometry claim groups mix multiple derived geometry classes.",
                                    path=grouped_json_path,
                                )
                            )
                            geometry_host_requirements = regime_facts.get("geometry_host_requirements", {})
                            geometry_host_checks = [
                                (
                                    "preview.geometry_shift_pointwise_host",
                                    bool(geometry_host_requirements.get("geometry_shift_pointwise")),
                                    "Found a pointwise geometry_shift host with complete labels and metrics.",
                                    "Missing a pointwise geometry_shift host with complete labels and metrics.",
                                ),
                                (
                                    "preview.geometry_shift_operator_host",
                                    bool(geometry_host_requirements.get("geometry_shift_operator")),
                                    "Found a companion field geometry_shift host with complete labels and metrics.",
                                    "Missing a companion field geometry_shift host with complete labels and metrics.",
                                ),
                            ]
                            for code, passed, success_message, failure_message in geometry_host_checks:
                                results.append(
                                    _result(
                                        code,
                                        "warning",
                                        passed,
                                        success_message if passed else failure_message,
                                        path=grouped_json_path,
                                    )
                                )
                        results.append(
                            _result(
                                "preview.external_packaging_summaries",
                                "warning",
                                packaging_present,
                                f"Found carried-forward external-adoption and publication-packaging summaries in the {preview_line} analysis bundle."
                                if packaging_present
                                else f"Missing one or more carried-forward external-adoption or publication-packaging summaries in the {preview_line} analysis bundle.",
                                path=analysis_dir / "analysis_bundle.json",
                            )
                        )

    if active_starter and checked_root is not None:
        grouped_json_path = checked_root / "_leaderboard" / "leaderboard_grouped.json"
        analysis_dir = checked_root / "_analysis"
        _append_collection_check(
            results,
            code="starter.analysis_assets",
            severity="warning",
            paths=required_analysis_asset_paths(analysis_dir, preview_line=STARTER_REFERENCE_PREVIEW_LINE),
            success_message="Found starter-pack analysis assets.",
            failure_message="Missing one or more starter-pack analysis assets.",
        )
        protocol_dir = checked_root / "_leaderboard_protocol"
        protocol_paths = [
            protocol_dir / "leaderboard_protocol_bundle.json",
            protocol_dir / "admission_registry.json",
            protocol_dir / "admission_registry.md",
            protocol_dir / "governance_packet.json",
            protocol_dir / "governance_packet.md",
            protocol_dir / "main_leaderboard.json",
            protocol_dir / "main_leaderboard.md",
            protocol_dir / "stress_leaderboard.json",
            protocol_dir / "stress_leaderboard.md",
            protocol_dir / "pareto_leaderboard.json",
            protocol_dir / "pareto_leaderboard.md",
            protocol_dir / "parameter_efficiency.json",
            protocol_dir / "parameter_efficiency.md",
        ]
        _append_collection_check(
            results,
            code="starter.leaderboard_protocol_assets",
            severity="warning",
            paths=protocol_paths,
            success_message="Found starter-pack leaderboard-protocol assets.",
            failure_message="Missing one or more starter-pack leaderboard-protocol assets.",
        )
        analysis_bundle = _load_analysis_bundle_payload(analysis_dir)
        results.append(
            _result(
                "starter.analysis_pack_identity",
                "warning",
                bool(isinstance(analysis_bundle, dict) and analysis_bundle.get("pack_identity", {}).get("pack_kind") == "starter"),
                "Analysis bundle identifies the outputs root as a starter pack."
                if isinstance(analysis_bundle, dict) and analysis_bundle.get("pack_identity", {}).get("pack_kind") == "starter"
                else "Analysis bundle should identify the outputs root as a starter pack.",
                path=analysis_dir / "analysis_bundle.json",
            )
        )
        regime_facts = _v1_8_regime_facts(
            grouped_payload=_load_grouped_payload(grouped_json_path),
            checked_root=checked_root,
            matrix_manifest=matrix_manifest,
        )
        regime_artifact_paths = [
            Path(path)
            for path in regime_facts.get("regime_artifact_paths", {}).values()
            if path is not None
        ]
        _append_collection_check(
            results,
            code="starter.regime_assets",
            severity="warning",
            paths=regime_artifact_paths,
            success_message="Found starter-pack geometry regime artifacts.",
            failure_message="Missing one or more starter-pack geometry regime artifacts.",
        )
        results.extend(
            [
                _result(
                    "starter.geometry_targeted_metadata",
                    "warning",
                    int(regime_facts.get("geometry_targeted_rows_missing_geometry_labels_count") or 0) == 0,
                    "All geometry-targeted grouped rows expose complete geometry metadata."
                    if int(regime_facts.get("geometry_targeted_rows_missing_geometry_labels_count") or 0) == 0
                    else "One or more geometry-targeted grouped rows are missing complete geometry metadata.",
                    path=grouped_json_path,
                ),
                _result(
                    "starter.geometry_required_metrics",
                    "warning",
                    int(regime_facts.get("geometry_targeted_rows_missing_required_metrics_count") or 0) == 0,
                    "All geometry-targeted grouped rows expose near-boundary and residual metrics."
                    if int(regime_facts.get("geometry_targeted_rows_missing_required_metrics_count") or 0) == 0
                    else "One or more geometry-targeted grouped rows are missing near-boundary or residual metrics.",
                    path=grouped_json_path,
                ),
                _result(
                    "starter.geometry_distribution_mix",
                    "warning",
                    int(regime_facts.get("mixed_geometry_distribution_group_count") or 0) == 0,
                    "No geometry claim groups mix multiple geometry-distribution labels."
                    if int(regime_facts.get("mixed_geometry_distribution_group_count") or 0) == 0
                    else "One or more geometry claim groups mix multiple geometry-distribution labels.",
                    path=grouped_json_path,
                ),
                _result(
                    "starter.geometry_class_mix",
                    "warning",
                    int(regime_facts.get("mixed_geometry_class_group_count") or 0) == 0,
                    "No geometry claim groups mix multiple derived geometry classes."
                    if int(regime_facts.get("mixed_geometry_class_group_count") or 0) == 0
                    else "One or more geometry claim groups mix multiple derived geometry classes.",
                    path=grouped_json_path,
                ),
            ]
        )
        geometry_host_requirements = regime_facts.get("geometry_host_requirements", {})
        geometry_host_checks = [
            (
                "starter.geometry_shift_pointwise_host",
                bool(geometry_host_requirements.get("geometry_shift_pointwise")),
                "Found a pointwise geometry starter host with complete labels and metrics.",
                "Missing a pointwise geometry starter host with complete labels and metrics.",
            ),
            (
                "starter.geometry_shift_operator_host",
                bool(geometry_host_requirements.get("geometry_shift_operator")),
                "Found a companion field geometry starter host with complete labels and metrics.",
                "Missing a companion field geometry starter host with complete labels and metrics.",
            ),
        ]
        for code, passed, success_message, failure_message in geometry_host_checks:
            results.append(
                _result(
                    code,
                    "warning",
                    passed,
                    success_message if passed else failure_message,
                    path=grouped_json_path,
                )
            )
        geometry_hosts = regime_facts.get("geometry_hosts_with_complete_labels", {})
        pointwise_tasks = set(geometry_hosts.get("pointwise_tasks", [])) if isinstance(geometry_hosts, dict) else set()
        operator_tasks = set(geometry_hosts.get("operator_tasks", [])) if isinstance(geometry_hosts, dict) else set()
        starter_hosts_complete = "poisson2d" in pointwise_tasks and "poisson2d_field" in operator_tasks
        results.append(
            _result(
                "starter.geometry_starter_hosts",
                "warning",
                starter_hosts_complete,
                "Starter pack includes both `poisson2d` and `poisson2d_field` geometry hosts."
                if starter_hosts_complete
                else "Starter pack must include both `poisson2d` and `poisson2d_field` geometry hosts.",
                path=grouped_json_path,
            )
        )

    checks = [asdict(result) for result in results]
    summary = {
        "info": sum(1 for result in results if result.severity == "info"),
        "warning": sum(1 for result in results if result.severity == "warning" and result.status == "fail"),
        "error": sum(1 for result in results if result.severity == "error" and result.status == "fail"),
        "pass": sum(1 for result in results if result.status == "pass"),
        "fail": sum(1 for result in results if result.status == "fail"),
    }
    scene_summary = None
    if active_operator_preview and checked_root is not None:
        scene_summary = _preview_scene_summary(repo_root=repo_root, checked_root=checked_root, preview_line=preview_line)
    elif active_starter and checked_root is not None and starter_pack is not None:
        scene_summary = _starter_scene_summary(checked_root=checked_root, starter_pack=starter_pack)
    elif mode == COMMUNITY_MODE:
        scene_summary = {
            "active_preview_line": KNOWN_PREVIEW_LINE,
            "latest_completed_preview_line": LATEST_COMPLETED_PREVIEW_LINE,
            "docs_and_examples_ready": summary["error"] == 0,
            "checked_outputs_root": str(inspected_roots[0]) if inspected_roots else None,
        }

    return {
        "repo_root": str(repo_root),
        "mode": mode,
        "strict": strict,
        "matrix_manifest": None if matrix_manifest is None else str(matrix_manifest),
        "outputs_root": str(inspected_roots[0]) if inspected_roots else None,
        "scene_summary": scene_summary,
        "checks": checks,
        "summary": summary,
    }



def finalize_doctor_payload(result: dict[str, Any]) -> dict[str, Any]:
    payload = dict(result)
    payload["checks"] = [dict(check) for check in result.get("checks", []) if isinstance(check, dict)]
    summary = result.get("summary")
    if isinstance(summary, dict):
        payload["summary"] = dict(summary)
    scene_summary = result.get("scene_summary")
    if isinstance(scene_summary, dict):
        payload["scene_summary"] = dict(scene_summary)
    return payload



def render_doctor_markdown(payload: dict[str, Any]) -> str:
    lines = ["# Doctor Report", "", "## Identity", ""]
    lines.extend(
        [
            f"- Mode: `{payload['mode']}`",
            f"- Strict: `{payload['strict']}`",
            f"- Repo root: `{payload['repo_root']}`",
            f"- Matrix manifest: `{payload['matrix_manifest']}`",
            f"- Outputs root: `{payload['outputs_root']}`",
        ]
    )

    scene_summary = payload.get("scene_summary")
    if isinstance(scene_summary, dict):
        lines.extend(["", "## Scene Summary", ""])
        for key, value in scene_summary.items():
            rendered = json.dumps(value, sort_keys=True) if isinstance(value, (dict, list)) else value
            lines.append(f"- {key}: `{rendered}`")

    summary = payload.get("summary")
    if isinstance(summary, dict):
        lines.extend(
            [
                "",
                "## Summary",
                "",
                f"- Pass: `{summary['pass']}`",
                f"- Fail: `{summary['fail']}`",
                f"- Warnings: `{summary['warning']}`",
                f"- Errors: `{summary['error']}`",
                f"- Info: `{summary['info']}`",
            ]
        )

    lines.extend(["", "## Checks", ""])
    checks = payload.get("checks")
    if isinstance(checks, list) and checks:
        for check in checks:
            if not isinstance(check, dict):
                continue
            path_text = f" ({check['path']})" if check.get("path") else ""
            lines.append(f"- [{str(check['severity']).upper()}][{str(check['status']).upper()}] {check['message']}{path_text}")
    else:
        lines.append("- No checks recorded.")
    lines.append("")
    return "\n".join(lines)



def persist_doctor_outputs(*, payload: dict[str, Any], output_dir: Path) -> dict[str, str]:
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / DOCTOR_REPORT_JSON
    md_path = output_dir / DOCTOR_REPORT_MARKDOWN
    write_json(json_path, payload)
    md_path.write_text(render_doctor_markdown(payload), encoding="utf-8")
    return {"json_path": str(json_path.resolve()), "md_path": str(md_path.resolve())}



def render_doctor_summary(
    *,
    payload: dict[str, Any],
    written: dict[str, str] | None = None,
    output_dir: Path | None = None,
    persistence_supported: bool,
) -> str:
    summary = payload.get("summary")
    assert isinstance(summary, dict)
    summary_line = "Summary: pass={pass_count}, fail={fail_count}, warnings={warning_count}, errors={error_count}".format(
        pass_count=summary["pass"],
        fail_count=summary["fail"],
        warning_count=summary["warning"],
        error_count=summary["error"],
    )
    if written is None:
        lines = [
            f"Doctor verification completed ({payload['mode']}).",
            "Doctor artifacts were not written.",
        ]
        if persistence_supported and output_dir is not None:
            lines.append(f"Re-run with --write to persist reports under {output_dir}.")
        else:
            lines.append("Persistence is unavailable for this doctor mode.")
        lines.append(summary_line)
        return "\n".join(lines)
    return "\n".join(
        [
            f"Doctor JSON written to {written['json_path']}",
            f"Doctor Markdown written to {written['md_path']}",
            summary_line,
        ]
    )



def _exit_code(payload: dict[str, object], *, strict: bool) -> int:
    if not strict:
        return 0
    summary = payload["summary"]
    assert isinstance(summary, dict)
    return 1 if (summary["warning"] or summary["error"]) else 0



def main(argv: Sequence[str] | None = None) -> None:
    args = parse_args(argv)
    mode = _default_mode(args)
    persistence_supported = _doctor_write_supported(
        mode=mode,
        submission_bundle_arg=args.submission_bundle,
        scaffold_root_arg=args.scaffold_root,
    )
    if args.write and not persistence_supported:
        if mode == COMMUNITY_MODE:
            raise SystemExit("--write is not supported for community doctor checks.")
        if args.submission_bundle is not None:
            raise SystemExit("--write is not supported for submission-bundle doctor checks.")
        raise SystemExit("--write is not supported for scaffold-root doctor checks.")

    payload = finalize_doctor_payload(
        build_doctor_payload(
            mode=mode,
            outputs_root_arg=args.outputs_root,
            matrix_manifest_arg=args.matrix_manifest,
            strict=bool(args.strict),
            submission_bundle_arg=args.submission_bundle,
            scaffold_root_arg=args.scaffold_root,
        )
    )

    output_dir = None
    if persistence_supported and payload.get("outputs_root") is not None:
        output_dir = resolve_doctor_output_dir(
            Path(str(payload["outputs_root"])),
            mode=mode,
            starter_pack=args.starter,
        )

    written = None
    if args.write:
        if output_dir is None:
            raise SystemExit("doctor write mode requires an outputs root-backed formal or preview check.")
        ensure_doctor_write_allowed(output_dir=output_dir)
        written = persist_doctor_outputs(payload=payload, output_dir=output_dir)

    if args.json:
        print(json.dumps(payload, indent=2))
    else:
        print(
            render_doctor_summary(
                payload=payload,
                written=written,
                output_dir=output_dir,
                persistence_supported=persistence_supported,
            )
        )
    raise SystemExit(_exit_code(payload, strict=bool(args.strict)))


if __name__ == '__main__':
    main()
