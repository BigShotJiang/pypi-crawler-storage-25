"""Task adapters for robustness protocols."""

from __future__ import annotations

import torch

from pinn_bench.robustness.protocols import BaseRobustnessProtocol
from pinn_bench.tasks.base import BaseTask, EvaluationBatch, TrainBatches


class RobustnessTaskAdapter(BaseTask):
    """Wrap a task and apply a robustness protocol to training batches."""

    def __init__(self, task: BaseTask, protocol: BaseRobustnessProtocol, task_name: str) -> None:
        self.task = task
        self.protocol = protocol
        self.task_name = task_name
        self.task_mode = getattr(task, "task_mode", "pointwise")
        self.supports_operator = bool(getattr(task, "supports_operator", False))

    def __getattr__(self, name: str) -> object:
        return getattr(self.task, name)

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        return self.protocol.sample_train_batches(task=self.task, task_name=self.task_name, device=device)

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        return self.protocol.sample_evaluation_batch(
            task=self.task,
            device=device,
            num_samples=num_samples,
            grid_x=grid_x,
            grid_t=grid_t,
            grid_y=grid_y,
        )

    def compute_loss_terms(self, model: torch.nn.Module, batches: TrainBatches) -> dict[str, torch.Tensor]:
        return self.protocol.compute_loss_terms(task=self.task, model=model, batches=batches)

    def exact_solution(self, inputs: torch.Tensor) -> torch.Tensor | None:
        return self.protocol.exact_solution(task=self.task, inputs=inputs)

    def trainable_parameters(self):
        return self.task.trainable_parameters()

    def compute_metric(
        self,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        return self.protocol.compute_metric(
            task=self.task,
            metric_name=metric_name,
            model=model,
            batch=batch,
            predictions=predictions,
            targets=targets,
        )

    def compute_residual(self, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        return self.protocol.compute_residual(task=self.task, model=model, inputs=inputs)
