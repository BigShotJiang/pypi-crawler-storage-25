"""Robustness protocol implementations and helpers."""

from __future__ import annotations

from collections.abc import Mapping
from contextlib import ExitStack, contextmanager
from dataclasses import dataclass, field
from math import ceil, pi
from typing import Any, Iterator

import torch

from pinn_bench.config.schema import RobustnessConfig
from pinn_bench.tasks.base import BaseTask, EvaluationBatch, SampleBatch, TrainBatches

_PROTOCOL_ALIASES = {"gaussian_noise": "noise", "extrapolation": "support_extrapolation"}
_SCOPE_ALIASES = {"supervision": "data"}
_ALLOWED_SCOPES = {"boundary", "initial", "initial_velocity", "data"}
_SCOPE_TO_BATCH_NAME = {
    "boundary": "boundary",
    "initial": "initial",
    "initial_velocity": "initial_velocity",
    "data": "supervision",
}
_TASK_DEFAULT_TARGET_SCOPES = {
    "burgers1d": ["boundary", "initial"],
    "heat1d": ["boundary", "initial"],
    "heat1d_field": ["data"],
    "wave1d": ["boundary", "initial", "initial_velocity"],
    "allencahn1d": ["boundary", "initial"],
    "poisson2d": ["boundary"],
    "poisson2d_field": ["data"],
}
_TASK_PROTOCOL_DEFAULT_TARGET_SCOPES = {
    "burgers1d_inverse_viscosity": {
        "noise": ["data"],
        "sensor_drift": ["data"],
        "heteroscedastic_noise": ["data"],
        "low_frequency_bias": ["data"],
        "sparsity": ["data"],
        "bcic_corruption": ["boundary", "initial"],
    },
    "heat1d_inverse_diffusivity": {
        "noise": ["data"],
        "sensor_drift": ["data"],
        "heteroscedastic_noise": ["data"],
        "low_frequency_bias": ["data"],
        "sparsity": ["data"],
        "bcic_corruption": ["boundary", "initial"],
    },
}
_REGIME_PROTOCOLS = {"parameter_shift", "resolution_shift", "bc_family_shift", "ic_family_shift", "geometry_shift"}
_ALLOWED_REGIME_SLICE_KEYS = {
    "parameter_shift": {"slice_id", "parameter_name", "train_value", "eval_value"},
    "resolution_shift": {"slice_id", "train_sampling_overrides", "eval_grid_overrides", "operator_train_stride"},
    "bc_family_shift": {"slice_id", "train_boundary_family", "eval_boundary_family"},
    "ic_family_shift": {"slice_id", "train_initial_family", "eval_initial_family"},
    "geometry_shift": {
        "slice_id",
        "geometry_split_id",
        "representation",
        "train_geometry_family",
        "eval_geometry_family",
        "geometry_distribution",
        "boundary_band_epsilon",
    },
}
_ALLOWED_RESOLUTION_SHIFT_GRID_KEYS = {"grid_x", "grid_t", "grid_y"}
_ALLOWED_OPERATOR_TRAIN_STRIDE_KEYS = {"x", "y", "t"}
_ALLOWED_GEOMETRY_REPRESENTATIONS = {"sdf"}
_ALLOWED_GEOMETRY_DISTRIBUTIONS = {"ID", "OOD"}


def normalize_protocol_name(protocol: str) -> str:
    """Normalize protocol names, preserving backward compatibility aliases."""
    normalized = str(protocol).strip().lower()
    return _PROTOCOL_ALIASES.get(normalized, normalized)



def normalize_target_scope(scope: str) -> str:
    """Normalize public target scope names, preserving legacy aliases."""
    normalized = str(scope).strip().lower()
    return _SCOPE_ALIASES.get(normalized, normalized)



def _validate_scope_names(scopes: list[str]) -> list[str]:
    normalized_scopes = [normalize_target_scope(scope) for scope in scopes]
    invalid = [scope for scope in normalized_scopes if scope not in _ALLOWED_SCOPES]
    if invalid:
        if "physics" in invalid:
            raise ValueError(
                "physics sparsification is not supported in Phase 4B. "
                "Sparsity applies only to target-bearing supervision scopes."
            )
        allowed = ", ".join(sorted(_ALLOWED_SCOPES))
        invalid_joined = ", ".join(invalid)
        raise ValueError(f"Unsupported robustness target scope(s): {invalid_joined}. Allowed: {allowed}")
    return normalized_scopes



def _scope_to_batch_name(scope: str) -> str:
    return _SCOPE_TO_BATCH_NAME[scope]


def _ensure_mapping(value: Any, location: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"Expected mapping at '{location}', got {type(value).__name__}.")
    return dict(value)


def _require_string(payload: dict[str, Any], key: str, *, location: str) -> str:
    raw = payload.pop(key, None)
    if not isinstance(raw, str) or not raw.strip():
        raise ValueError(f"'{location}.{key}' must be a non-empty string.")
    return raw.strip()


def _is_supported_scalar(value: Any) -> bool:
    return isinstance(value, (str, int, float)) and not isinstance(value, bool)


def _require_scalar(payload: dict[str, Any], key: str, *, location: str) -> str | int | float:
    raw = payload.pop(key, None)
    if not _is_supported_scalar(raw):
        raise ValueError(f"'{location}.{key}' must be a scalar string or number.")
    return raw


def _require_float(payload: dict[str, Any], key: str, *, location: str) -> float:
    raw = payload.pop(key, None)
    try:
        return float(raw)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"'{location}.{key}' must be a float.") from exc


def _require_positive_float(payload: dict[str, Any], key: str, *, location: str) -> float:
    value = _require_float(payload, key, location=location)
    if value <= 0.0:
        raise ValueError(f"'{location}.{key}' must be > 0.")
    return value


def _require_choice(payload: dict[str, Any], key: str, *, location: str, allowed: set[str]) -> str:
    value = _require_string(payload, key, location=location)
    normalized = value.upper() if allowed == _ALLOWED_GEOMETRY_DISTRIBUTIONS else value.lower()
    if normalized not in allowed:
        allowed_text = ", ".join(sorted(allowed))
        raise ValueError(f"'{location}.{key}' must be one of: {allowed_text}")
    return normalized


def _require_int_mapping(
    payload: dict[str, Any],
    key: str,
    *,
    location: str,
    allowed_keys: set[str] | None = None,
) -> dict[str, int]:
    raw = payload.pop(key, None)
    data = _ensure_mapping(raw, f"{location}.{key}")
    normalized: dict[str, int] = {}
    for raw_key, raw_value in data.items():
        key_text = str(raw_key).strip()
        if not key_text:
            raise ValueError(f"'{location}.{key}' keys must be non-empty strings.")
        if allowed_keys is not None and key_text not in allowed_keys:
            allowed = ", ".join(sorted(allowed_keys))
            raise ValueError(f"'{location}.{key}' only supports keys: {allowed}")
        try:
            normalized[key_text] = int(raw_value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"'{location}.{key}.{key_text}' must be an integer.") from exc
    return normalized


def _validate_no_extra_keys(payload: dict[str, Any], *, location: str) -> None:
    if payload:
        extras = ", ".join(sorted(payload))
        raise ValueError(f"Unsupported key(s) in '{location}': {extras}")


def _scalar_kind(value: str | int | float) -> str:
    return "string" if isinstance(value, str) else "number"


def _format_variant_mapping(prefix: str, mapping: Mapping[str, Any]) -> str:
    items = ", ".join(f"{key}={mapping[key]}" for key in sorted(mapping))
    return f"{prefix}[{items}]"


def _parse_regime_slice(*, task_params: Mapping[str, Any] | None, protocol_name: str) -> dict[str, Any]:
    if task_params is None:
        raise ValueError(f"{protocol_name} requires 'task.params.regime_slice'.")
    data = _ensure_mapping(task_params, "task.params")
    raw_slice = data.get("regime_slice")
    if raw_slice is None:
        raise ValueError(f"{protocol_name} requires 'task.params.regime_slice'.")
    regime_slice = _ensure_mapping(raw_slice, "task.params.regime_slice")
    allowed_keys = _ALLOWED_REGIME_SLICE_KEYS[protocol_name]
    unknown = sorted(set(regime_slice) - allowed_keys)
    if unknown:
        extras = ", ".join(unknown)
        raise ValueError(f"Unsupported key(s) in 'task.params.regime_slice' for {protocol_name}: {extras}")
    return regime_slice


def _ensure_task_scalar_attribute(
    *,
    task: BaseTask,
    task_name: str,
    attribute_name: str,
    protocol_name: str,
    train_value: str | int | float,
    eval_value: str | int | float,
) -> None:
    if not hasattr(task, attribute_name):
        raise ValueError(f"Task {task_name} does not expose scalar attribute '{attribute_name}' for {protocol_name}.")
    current_value = getattr(task, attribute_name)
    if not _is_supported_scalar(current_value):
        raise ValueError(f"Task {task_name} attribute '{attribute_name}' must be a scalar string or number for {protocol_name}.")
    expected_kind = _scalar_kind(current_value)
    if _scalar_kind(train_value) != expected_kind or _scalar_kind(eval_value) != expected_kind:
        raise ValueError(
            f"Task {task_name} attribute '{attribute_name}' expects {expected_kind} values for {protocol_name}."
        )


@contextmanager
def _temporary_task_attribute(task: BaseTask, attribute_name: str, value: str | int | float) -> Iterator[None]:
    original_value = getattr(task, attribute_name)
    setattr(task, attribute_name, value)
    try:
        yield
    finally:
        setattr(task, attribute_name, original_value)


def _ensure_task_mapping_attribute(
    *,
    task: BaseTask,
    task_name: str,
    attribute_name: str,
    protocol_name: str,
) -> dict[str, Any]:
    if not hasattr(task, attribute_name):
        raise ValueError(f"Task {task_name} does not expose mapping attribute '{attribute_name}' for {protocol_name}.")
    mapping = getattr(task, attribute_name)
    if not isinstance(mapping, dict):
        raise ValueError(f"Task {task_name} attribute '{attribute_name}' must be a mutable mapping for {protocol_name}.")
    return mapping


def _ensure_task_attribute(task: BaseTask, task_name: str, attribute_name: str, protocol_name: str) -> None:
    if not hasattr(task, attribute_name):
        raise ValueError(f"Task {task_name} does not expose attribute '{attribute_name}' for {protocol_name}.")


@contextmanager
def _temporary_mapping_updates(mapping: dict[str, Any], updates: Mapping[str, Any]) -> Iterator[None]:
    original = dict(mapping)
    mapping.update(dict(updates))
    try:
        yield
    finally:
        mapping.clear()
        mapping.update(original)


@contextmanager
def _temporary_task_attributes(task: BaseTask, updates: Mapping[str, Any]) -> Iterator[None]:
    with ExitStack() as stack:
        for attribute_name, value in updates.items():
            stack.enter_context(_temporary_task_attribute(task, attribute_name, value))
        yield


@dataclass
class BaseRobustnessProtocol:
    """Common contract for robustness protocols."""

    protocol_name: str
    level: float
    severity_label: str | None = None
    resolved_target_scopes: list[str] = field(default_factory=list)
    components: list[dict[str, object]] = field(default_factory=list)
    train_time_range: list[float] | None = None
    eval_time_range: list[float] | None = None
    train_support_ratio: float | None = None
    support_axis: str | None = None
    pattern_family: str | None = None
    temporal_block_range: list[float] | None = None

    def apply_to_train_batches(self, task_name: str, batches: TrainBatches) -> TrainBatches:
        return batches

    def sample_train_batches(self, task: BaseTask, task_name: str, device: torch.device) -> TrainBatches:
        batches = task.sample_train_batches(device=device)
        return self.apply_to_train_batches(task_name=task_name, batches=batches)

    def sample_evaluation_batch(
        self,
        task: BaseTask,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        return task.sample_evaluation_batch(
            device=device,
            num_samples=num_samples,
            grid_x=grid_x,
            grid_t=grid_t,
            grid_y=grid_y,
        )

    def exact_solution(self, task: BaseTask, inputs: torch.Tensor) -> torch.Tensor | None:
        return task.exact_solution(inputs)

    def compute_loss_terms(
        self,
        task: BaseTask,
        model: torch.nn.Module,
        batches: TrainBatches,
    ) -> dict[str, torch.Tensor]:
        return task.compute_loss_terms(model=model, batches=batches)

    def compute_metric(
        self,
        task: BaseTask,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        return task.compute_metric(
            metric_name,
            model=model,
            batch=batch,
            predictions=predictions,
            targets=targets,
        )

    def compute_residual(self, task: BaseTask, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        return task.compute_residual(model=model, inputs=inputs)

    def regime_metadata_dict(self) -> dict[str, object] | None:
        return None

    def geometry_metadata_dict(self) -> dict[str, object] | None:
        return None

    def _clone_batch(
        self,
        batch: SampleBatch,
        inputs: torch.Tensor | None = None,
        targets: torch.Tensor | None = None,
        weights: torch.Tensor | None = None,
        metadata: dict[str, object] | None = None,
    ) -> SampleBatch:
        return SampleBatch(
            inputs=batch.inputs if inputs is None else inputs,
            targets=batch.targets if targets is None else targets,
            weights=batch.weights if weights is None else weights,
            metadata=dict(batch.metadata) if metadata is None else metadata,
        )

    def _validate_selected_batches(
        self,
        task_name: str,
        batches: TrainBatches,
        *,
        require_nonempty: bool = False,
    ) -> None:
        named_batches = batches.named_batches()
        for scope in set(self.resolved_target_scopes):
            batch_name = _scope_to_batch_name(scope)
            if batch_name not in named_batches:
                raise ValueError(f"Task {task_name} does not provide scope {scope} for {self.protocol_name} protocol.")
            batch = named_batches[batch_name]
            if batch.targets is None:
                raise ValueError(f"Robustness scope '{scope}' for task '{task_name}' has no targets to transform.")
            if require_nonempty and batch.inputs.shape[0] == 0:
                raise ValueError(f"Robustness scope '{scope}' for task '{task_name}' has zero samples.")

    def _build_batches_metadata(self, metadata: dict[str, object]) -> dict[str, object]:
        payload: dict[str, object] = {
            **dict(metadata),
            "robustness": {
                "protocol": self.protocol_name,
                "level": self.level,
                "target_scopes": list(self.resolved_target_scopes),
            },
        }
        robustness = payload["robustness"]
        assert isinstance(robustness, dict)
        if self.components:
            robustness["components"] = [dict(component) for component in self.components]
        if self.train_time_range is not None:
            robustness["train_time_range"] = list(self.train_time_range)
        if self.eval_time_range is not None:
            robustness["eval_time_range"] = list(self.eval_time_range)
        if self.severity_label is not None:
            robustness["severity_label"] = str(self.severity_label)
        if self.train_support_ratio is not None:
            robustness["train_support_ratio"] = float(self.train_support_ratio)
        if self.support_axis is not None:
            robustness["support_axis"] = str(self.support_axis)
        if self.pattern_family is not None:
            robustness["pattern_family"] = str(self.pattern_family)
        if self.temporal_block_range is not None:
            robustness["temporal_block_range"] = list(self.temporal_block_range)
        return payload

    def _build_batch_metadata(self, batch: SampleBatch) -> dict[str, object]:
        metadata = dict(batch.metadata)
        metadata["robustness_protocol"] = self.protocol_name
        metadata["robustness_level"] = self.level
        if self.components:
            metadata["robustness_components"] = [dict(component) for component in self.components]
        if self.severity_label is not None:
            metadata["robustness_severity_label"] = str(self.severity_label)
        if self.train_time_range is not None:
            metadata["robustness_train_time_range"] = list(self.train_time_range)
        if self.eval_time_range is not None:
            metadata["robustness_eval_time_range"] = list(self.eval_time_range)
        if self.train_support_ratio is not None:
            metadata["robustness_train_support_ratio"] = float(self.train_support_ratio)
        if self.support_axis is not None:
            metadata["robustness_support_axis"] = str(self.support_axis)
        if self.pattern_family is not None:
            metadata["robustness_pattern_family"] = str(self.pattern_family)
        if self.temporal_block_range is not None:
            metadata["robustness_temporal_block_range"] = list(self.temporal_block_range)
        return metadata


@dataclass
class NoOpRobustnessProtocol(BaseRobustnessProtocol):
    """No-op robustness protocol used for default runs."""

    def __init__(self) -> None:
        super().__init__(protocol_name="none", level=0.0, severity_label="nominal", resolved_target_scopes=[])


@dataclass
class NoiseProtocol(BaseRobustnessProtocol):
    """Gaussian noise protocol applied to selected training targets."""

    def __init__(self, level: float, resolved_target_scopes: list[str], severity_label: str | None = None) -> None:
        super().__init__(
            protocol_name="noise",
            level=float(level),
            severity_label=severity_label,
            resolved_target_scopes=list(resolved_target_scopes),
        )

    def apply_to_train_batches(self, task_name: str, batches: TrainBatches) -> TrainBatches:
        selected_scopes = set(self.resolved_target_scopes)
        self._validate_selected_batches(task_name=task_name, batches=batches)

        def maybe_perturb(scope: str, batch: SampleBatch | None) -> SampleBatch | None:
            if batch is None:
                return None
            if scope not in selected_scopes:
                return self._clone_batch(batch)
            assert batch.targets is not None
            noisy_targets = batch.targets.clone() if self.level == 0.0 else batch.targets + self.level * torch.randn_like(batch.targets)
            return self._clone_batch(
                batch,
                targets=noisy_targets,
                metadata=self._build_batch_metadata(batch),
            )

        return TrainBatches(
            interior=self._clone_batch(batches.interior) if batches.interior is not None else None,
            boundary=maybe_perturb("boundary", batches.boundary),
            initial=maybe_perturb("initial", batches.initial),
            initial_velocity=maybe_perturb("initial_velocity", batches.initial_velocity),
            supervision=maybe_perturb("data", batches.supervision),
            metadata=self._build_batches_metadata(batches.metadata),
        )


GaussianNoiseProtocol = NoiseProtocol


@dataclass
class SensorDriftProtocol(BaseRobustnessProtocol):
    """Deterministic low-frequency drift that grows over time."""

    def __init__(self, level: float, resolved_target_scopes: list[str], severity_label: str | None = None) -> None:
        super().__init__(
            protocol_name="sensor_drift",
            level=float(level),
            severity_label=severity_label,
            resolved_target_scopes=list(resolved_target_scopes),
        )

    def apply_to_train_batches(self, task_name: str, batches: TrainBatches) -> TrainBatches:
        selected_scopes = set(self.resolved_target_scopes)
        self._validate_selected_batches(task_name=task_name, batches=batches)

        def maybe_perturb(scope: str, batch: SampleBatch | None) -> SampleBatch | None:
            if batch is None:
                return None
            if scope not in selected_scopes:
                return self._clone_batch(batch)
            assert batch.targets is not None
            profile = _low_frequency_profile(batch.inputs, include_time_drift=True)
            scale = torch.sqrt(torch.mean(batch.targets**2)).clamp_min(1e-6)
            perturbed = batch.targets + float(self.level) * scale * profile
            return self._clone_batch(batch, targets=perturbed, metadata=self._build_batch_metadata(batch))

        return TrainBatches(
            interior=self._clone_batch(batches.interior) if batches.interior is not None else None,
            boundary=maybe_perturb("boundary", batches.boundary),
            initial=maybe_perturb("initial", batches.initial),
            initial_velocity=maybe_perturb("initial_velocity", batches.initial_velocity),
            supervision=maybe_perturb("data", batches.supervision),
            metadata=self._build_batches_metadata(batches.metadata),
        )


@dataclass
class HeteroscedasticNoiseProtocol(BaseRobustnessProtocol):
    """Gaussian noise with variance proportional to local target magnitude."""

    def __init__(self, level: float, resolved_target_scopes: list[str], severity_label: str | None = None) -> None:
        super().__init__(
            protocol_name="heteroscedastic_noise",
            level=float(level),
            severity_label=severity_label,
            resolved_target_scopes=list(resolved_target_scopes),
        )

    def apply_to_train_batches(self, task_name: str, batches: TrainBatches) -> TrainBatches:
        selected_scopes = set(self.resolved_target_scopes)
        self._validate_selected_batches(task_name=task_name, batches=batches)

        def maybe_perturb(scope: str, batch: SampleBatch | None) -> SampleBatch | None:
            if batch is None:
                return None
            if scope not in selected_scopes:
                return self._clone_batch(batch)
            assert batch.targets is not None
            target_scale = torch.sqrt(torch.mean(batch.targets**2)).clamp_min(1e-6)
            sigma = float(self.level) * torch.maximum(batch.targets.abs(), 0.25 * target_scale)
            perturbed = batch.targets + sigma * torch.randn_like(batch.targets)
            return self._clone_batch(batch, targets=perturbed, metadata=self._build_batch_metadata(batch))

        return TrainBatches(
            interior=self._clone_batch(batches.interior) if batches.interior is not None else None,
            boundary=maybe_perturb("boundary", batches.boundary),
            initial=maybe_perturb("initial", batches.initial),
            initial_velocity=maybe_perturb("initial_velocity", batches.initial_velocity),
            supervision=maybe_perturb("data", batches.supervision),
            metadata=self._build_batches_metadata(batches.metadata),
        )


@dataclass
class LowFrequencyBiasProtocol(BaseRobustnessProtocol):
    """Deterministic low-frequency global bias over target-bearing batches."""

    def __init__(self, level: float, resolved_target_scopes: list[str], severity_label: str | None = None) -> None:
        super().__init__(
            protocol_name="low_frequency_bias",
            level=float(level),
            severity_label=severity_label,
            resolved_target_scopes=list(resolved_target_scopes),
        )

    def apply_to_train_batches(self, task_name: str, batches: TrainBatches) -> TrainBatches:
        selected_scopes = set(self.resolved_target_scopes)
        self._validate_selected_batches(task_name=task_name, batches=batches)

        def maybe_perturb(scope: str, batch: SampleBatch | None) -> SampleBatch | None:
            if batch is None:
                return None
            if scope not in selected_scopes:
                return self._clone_batch(batch)
            assert batch.targets is not None
            profile = _low_frequency_profile(batch.inputs, include_time_drift=False)
            scale = torch.sqrt(torch.mean(batch.targets**2)).clamp_min(1e-6)
            perturbed = batch.targets + float(self.level) * scale * profile
            return self._clone_batch(batch, targets=perturbed, metadata=self._build_batch_metadata(batch))

        return TrainBatches(
            interior=self._clone_batch(batches.interior) if batches.interior is not None else None,
            boundary=maybe_perturb("boundary", batches.boundary),
            initial=maybe_perturb("initial", batches.initial),
            initial_velocity=maybe_perturb("initial_velocity", batches.initial_velocity),
            supervision=maybe_perturb("data", batches.supervision),
            metadata=self._build_batches_metadata(batches.metadata),
        )


@dataclass
class SparsityProtocol(BaseRobustnessProtocol):
    """Uniform random subsampling protocol for target-bearing batches."""

    def __init__(
        self,
        level: float,
        resolved_target_scopes: list[str],
        severity_label: str | None = None,
        pattern_family: str | None = None,
        temporal_block_range: list[float] | None = None,
    ) -> None:
        super().__init__(
            protocol_name="sparsity",
            level=float(level),
            severity_label=severity_label,
            resolved_target_scopes=list(resolved_target_scopes),
            pattern_family=pattern_family,
            temporal_block_range=None if temporal_block_range is None else [float(temporal_block_range[0]), float(temporal_block_range[1])],
        )

    def _select_indices(self, num_rows: int, device: torch.device) -> torch.Tensor:
        retain_count = min(num_rows, max(1, int(round(num_rows * self.level))))
        if retain_count == num_rows:
            return torch.arange(num_rows, device=device)
        selected = torch.randperm(num_rows, device=device)[:retain_count]
        return torch.sort(selected).values

    @staticmethod
    def _is_field_grid_batch(batch: SampleBatch) -> bool:
        grid_shape = batch.metadata.get("grid_shape")
        return bool(batch.metadata.get("task_mode") == "field" and isinstance(grid_shape, (list, tuple)) and len(grid_shape) == 2)

    @staticmethod
    def _expand_weights_like(targets: torch.Tensor, weights: torch.Tensor | None) -> torch.Tensor:
        if weights is None:
            return torch.ones_like(targets)
        resolved = weights.to(device=targets.device, dtype=targets.dtype)
        while resolved.ndim < targets.ndim:
            resolved = resolved.unsqueeze(-1)
        return resolved.expand_as(targets)

    def apply_to_train_batches(self, task_name: str, batches: TrainBatches) -> TrainBatches:
        selected_scopes = set(self.resolved_target_scopes)
        self._validate_selected_batches(task_name=task_name, batches=batches, require_nonempty=True)

        def maybe_sparsify(scope: str, batch: SampleBatch | None) -> SampleBatch | None:
            if batch is None:
                return None
            if scope not in selected_scopes:
                return self._clone_batch(batch)
            assert batch.targets is not None
            if self.pattern_family and self.pattern_family != "random_sensor":
                mask = _structured_sparse_mask(
                    batch=batch,
                    pattern_family=self.pattern_family,
                    temporal_block_range=None
                    if self.temporal_block_range is None
                    else (float(self.temporal_block_range[0]), float(self.temporal_block_range[1])),
                ).to(device=batch.inputs.device)
                if not bool(mask.any().item()):
                    raise ValueError(f"Structured sparsity pattern '{self.pattern_family}' selected zero samples.")
                if self._is_field_grid_batch(batch):
                    weights = self._expand_weights_like(batch.targets, batch.weights)
                    masked_weights = weights * mask.to(dtype=batch.targets.dtype).unsqueeze(-1)
                    return self._clone_batch(
                        batch,
                        weights=masked_weights,
                        metadata=self._build_batch_metadata(batch),
                    )
                indices = torch.nonzero(mask, as_tuple=False).reshape(-1)
                inputs = batch.inputs.index_select(0, indices)
                targets = batch.targets.index_select(0, indices)
                weights = None if batch.weights is None else batch.weights.index_select(0, indices)
                return self._clone_batch(
                    batch,
                    inputs=inputs,
                    targets=targets,
                    weights=weights,
                    metadata=self._build_batch_metadata(batch),
                )
            indices = self._select_indices(num_rows=batch.inputs.shape[0], device=batch.inputs.device)
            if self._is_field_grid_batch(batch):
                weights = self._expand_weights_like(batch.targets, batch.weights)
                mask = torch.zeros((batch.inputs.shape[0],), device=batch.inputs.device, dtype=batch.targets.dtype)
                mask.index_fill_(0, indices, 1.0)
                masked_weights = weights * mask.unsqueeze(-1)
                return self._clone_batch(
                    batch,
                    weights=masked_weights,
                    metadata=self._build_batch_metadata(batch),
                )
            inputs = batch.inputs.index_select(0, indices)
            targets = batch.targets.index_select(0, indices)
            weights = None if batch.weights is None else batch.weights.index_select(0, indices)
            return self._clone_batch(
                batch,
                inputs=inputs,
                targets=targets,
                weights=weights,
                metadata=self._build_batch_metadata(batch),
            )

        return TrainBatches(
            interior=self._clone_batch(batches.interior) if batches.interior is not None else None,
            boundary=maybe_sparsify("boundary", batches.boundary),
            initial=maybe_sparsify("initial", batches.initial),
            initial_velocity=maybe_sparsify("initial_velocity", batches.initial_velocity),
            supervision=maybe_sparsify("data", batches.supervision),
            metadata=self._build_batches_metadata(batches.metadata),
        )


@dataclass
class CompositeProtocol(BaseRobustnessProtocol):
    """Ordered composition of multiple robustness protocols over one shared task shell."""

    component_protocols: list[BaseRobustnessProtocol] = field(default_factory=list)

    def __init__(
        self,
        *,
        component_protocols: list[BaseRobustnessProtocol],
        resolved_target_scopes: list[str],
        severity_label: str | None = None,
    ) -> None:
        component_descriptors = []
        for protocol in component_protocols:
            descriptor: dict[str, object] = {
                "protocol": str(protocol.protocol_name),
                "level": float(protocol.level),
            }
            if protocol.severity_label is not None:
                descriptor["severity_label"] = str(protocol.severity_label)
            component_descriptors.append(descriptor)
        super().__init__(
            protocol_name="composite",
            level=0.0,
            severity_label=severity_label,
            resolved_target_scopes=list(resolved_target_scopes),
            components=component_descriptors,
        )
        self.component_protocols = list(component_protocols)

    def _retag_batch(self, batch: SampleBatch | None) -> SampleBatch | None:
        if batch is None:
            return None
        return self._clone_batch(batch, metadata=self._build_batch_metadata(batch))

    def _retag_batches(self, batches: TrainBatches) -> TrainBatches:
        return TrainBatches(
            interior=self._retag_batch(batches.interior),
            boundary=self._retag_batch(batches.boundary),
            initial=self._retag_batch(batches.initial),
            initial_velocity=self._retag_batch(batches.initial_velocity),
            supervision=self._retag_batch(batches.supervision),
            metadata=self._build_batches_metadata(batches.metadata),
        )

    def apply_to_train_batches(self, task_name: str, batches: TrainBatches) -> TrainBatches:
        transformed = batches
        for protocol in self.component_protocols:
            transformed = protocol.apply_to_train_batches(task_name=task_name, batches=transformed)
        return self._retag_batches(transformed)


def _domain_bounds(domain: dict[str, float], axis: str) -> tuple[str, str]:
    if axis == "t":
        return "t_min", "t_max"
    if axis == "x":
        return "x_min", "x_max"
    raise ValueError(f"Unsupported support axis '{axis}'.")


def _structured_target_perturbation(inputs: torch.Tensor, targets: torch.Tensor, level: float) -> torch.Tensor:
    if level == 0.0:
        return targets.clone()
    mins = inputs.min(dim=0).values
    maxs = inputs.max(dim=0).values
    spans = (maxs - mins).clamp_min(1e-6)
    normalized = (inputs - mins) / spans
    pattern = torch.sin(2.0 * pi * normalized[:, :1])
    if normalized.shape[1] > 1:
        pattern = pattern + 0.5 * torch.cos(pi * normalized.sum(dim=1, keepdim=True))
    if normalized.shape[1] > 2:
        pattern = pattern + 0.25 * torch.sin(pi * normalized[:, 2:3])
    pattern_std = pattern.std(unbiased=False).clamp_min(1e-6)
    pattern = pattern / pattern_std
    scale = torch.sqrt(torch.mean(targets**2)).clamp_min(1e-6)
    return targets + float(level) * scale * pattern


def _resolved_axis_index(metadata: Mapping[str, Any] | None, axis_name: str, default_index: int) -> int:
    if not isinstance(metadata, Mapping):
        return default_index
    grid_axes = metadata.get("grid_axes")
    if isinstance(grid_axes, Mapping) and axis_name in grid_axes:
        try:
            return int(grid_axes[axis_name])
        except (TypeError, ValueError):
            return default_index
    return default_index


def _resolved_axis_bounds(inputs: torch.Tensor, metadata: Mapping[str, Any] | None, axis_name: str, axis_index: int) -> tuple[float, float]:
    if isinstance(metadata, Mapping):
        domain_bounds = metadata.get("domain_bounds")
        if isinstance(domain_bounds, Mapping) and axis_name in domain_bounds:
            raw = domain_bounds[axis_name]
            if isinstance(raw, (list, tuple)) and len(raw) == 2:
                return float(raw[0]), float(raw[1])
    column = inputs[:, axis_index]
    return float(column.min().detach().item()), float(column.max().detach().item())


def _structured_sparse_mask(
    *,
    batch: SampleBatch,
    pattern_family: str,
    temporal_block_range: tuple[float, float] | None,
) -> torch.Tensor:
    metadata = batch.metadata
    if isinstance(metadata, Mapping):
        scope_masks = metadata.get("structured_scope_masks")
        if isinstance(scope_masks, Mapping):
            candidate = scope_masks.get(pattern_family)
            if isinstance(candidate, torch.Tensor):
                return candidate.to(device=batch.inputs.device, dtype=batch.inputs.dtype).reshape(-1)

    inputs = batch.inputs
    x_index = _resolved_axis_index(metadata, "x", 0)
    t_index = _resolved_axis_index(metadata, "t", inputs.shape[1] - 1 if inputs.shape[1] > 1 else 0)
    x_min, x_max = _resolved_axis_bounds(inputs, metadata, "x", x_index)
    t_min, t_max = _resolved_axis_bounds(inputs, metadata, "t", t_index)

    if pattern_family == "boundary_only":
        x = inputs[:, x_index]
        span = max(x_max - x_min, 1e-6)
        boundary_distance = torch.minimum(torch.abs(x - x_min), torch.abs(x - x_max))
        mask = boundary_distance <= 0.05 * span
        if bool(mask.any().item()):
            return mask
        keep_count = max(1, int(round(inputs.shape[0] * 0.1)))
        indices = torch.argsort(boundary_distance)[:keep_count]
        mask = torch.zeros_like(boundary_distance, dtype=torch.bool)
        mask[indices] = True
        return mask
    if pattern_family == "initial_only":
        t = inputs[:, t_index]
        span = max(t_max - t_min, 1e-6)
        distance = t - t_min
        mask = distance <= 0.05 * span
        if bool(mask.any().item()):
            return mask
        keep_count = max(1, int(round(inputs.shape[0] * 0.1)))
        indices = torch.argsort(distance)[:keep_count]
        mask = torch.zeros_like(distance, dtype=torch.bool)
        mask[indices] = True
        return mask
    if pattern_family == "temporal_block_missing":
        start, end = temporal_block_range or (0.3, 0.7)
        t = inputs[:, t_index]
        span = max(t_max - t_min, 1e-6)
        normalized_t = (t - t_min) / span
        return (normalized_t < start) | (normalized_t > end)
    raise ValueError(f"Unsupported structured sparsity pattern '{pattern_family}'.")


def _low_frequency_profile(inputs: torch.Tensor, *, include_time_drift: bool) -> torch.Tensor:
    mins = inputs.min(dim=0).values
    maxs = inputs.max(dim=0).values
    spans = (maxs - mins).clamp_min(1e-6)
    normalized = (inputs - mins) / spans
    x = normalized[:, :1]
    profile = torch.sin(2.0 * pi * x) + 0.5 * torch.cos(pi * x)
    if normalized.shape[1] > 1:
        y_or_t = normalized[:, 1:2]
        profile = profile + 0.35 * torch.cos(2.0 * pi * y_or_t)
    if normalized.shape[1] > 2:
        t = normalized[:, 2:3]
        profile = profile + 0.25 * torch.sin(pi * t)
    if include_time_drift:
        time_axis = normalized[:, -1:]
        profile = profile * time_axis
    profile_std = profile.std(unbiased=False).clamp_min(1e-6)
    return profile / profile_std


@dataclass
class BCICCorruptionProtocol(BaseRobustnessProtocol):
    """Structured low-frequency corruption over BC/IC targets."""

    def __init__(self, level: float, resolved_target_scopes: list[str], severity_label: str | None = None) -> None:
        super().__init__(
            protocol_name="bcic_corruption",
            level=float(level),
            severity_label=severity_label,
            resolved_target_scopes=list(resolved_target_scopes),
        )

    def apply_to_train_batches(self, task_name: str, batches: TrainBatches) -> TrainBatches:
        selected_scopes = set(self.resolved_target_scopes)
        if "data" in selected_scopes:
            raise ValueError("bcic_corruption applies only to boundary/initial surfaces, not data supervision.")
        self._validate_selected_batches(task_name=task_name, batches=batches)

        def maybe_corrupt(scope: str, batch: SampleBatch | None) -> SampleBatch | None:
            if batch is None:
                return None
            if scope not in selected_scopes:
                return self._clone_batch(batch)
            assert batch.targets is not None
            perturbed_targets = _structured_target_perturbation(batch.inputs, batch.targets, self.level)
            return self._clone_batch(
                batch,
                targets=perturbed_targets,
                metadata=self._build_batch_metadata(batch),
            )

        return TrainBatches(
            interior=self._clone_batch(batches.interior) if batches.interior is not None else None,
            boundary=maybe_corrupt("boundary", batches.boundary),
            initial=maybe_corrupt("initial", batches.initial),
            initial_velocity=maybe_corrupt("initial_velocity", batches.initial_velocity),
            supervision=self._clone_batch(batches.supervision) if batches.supervision is not None else None,
            metadata=self._build_batches_metadata(batches.metadata),
        )


@dataclass
class SupportExtrapolationProtocol(BaseRobustnessProtocol):
    """Host-relative support restriction protocol with optional legacy holdout compatibility."""

    def __init__(
        self,
        *,
        train_support_ratio: float | None = None,
        train_time_range: list[float] | None = None,
        eval_time_range: list[float] | None = None,
        severity_label: str | None = None,
    ) -> None:
        super().__init__(
            protocol_name="support_extrapolation",
            level=0.0,
            severity_label=severity_label,
            resolved_target_scopes=[],
            train_time_range=None if train_time_range is None else [float(train_time_range[0]), float(train_time_range[1])],
            eval_time_range=None if eval_time_range is None else [float(eval_time_range[0]), float(eval_time_range[1])],
            train_support_ratio=None if train_support_ratio is None else float(train_support_ratio),
        )

    @property
    def legacy_holdout_mode(self) -> bool:
        return self.train_time_range is not None and self.eval_time_range is not None

    def _resolve_support_axis(self, task_name: str, task: BaseTask) -> str:
        domain = getattr(task, "domain", None)
        if not isinstance(domain, dict):
            raise ValueError(f"Task {task_name} does not expose a mutable domain mapping.")
        if "t_min" in domain and "t_max" in domain:
            return "t"
        if "x_min" in domain and "x_max" in domain:
            return "x"
        raise ValueError(f"Task {task_name} does not expose x/t domain bounds for support_extrapolation.")

    def validate_task(self, task_name: str, task: BaseTask) -> None:
        domain = getattr(task, "domain", None)
        if not isinstance(domain, dict):
            raise ValueError(f"Task {task_name} does not expose a mutable sampling domain.")

        if self.legacy_holdout_mode:
            if "t_min" not in domain or "t_max" not in domain:
                raise ValueError(
                    f"Task {task_name} does not support legacy extrapolation protocol because it has no time-domain sampling contract."
                )
            full_t_min = float(domain["t_min"])
            full_t_max = float(domain["t_max"])
            assert self.train_time_range is not None
            assert self.eval_time_range is not None
            train_start, train_end = self.train_time_range
            eval_start, eval_end = self.eval_time_range
            if not (full_t_min <= train_start <= train_end <= full_t_max):
                raise ValueError(
                    f"train_time_range {self.train_time_range} must lie within the task time domain [{full_t_min}, {full_t_max}]."
                )
            if not (full_t_min <= eval_start <= eval_end <= full_t_max):
                raise ValueError(
                    f"eval_time_range {self.eval_time_range} must lie within the task time domain [{full_t_min}, {full_t_max}]."
                )
            if train_end > eval_start:
                raise ValueError("Extrapolation protocol requires train_time_range[1] <= eval_time_range[0].")
            if not (train_start <= full_t_min <= train_end):
                raise ValueError(
                    f"Extrapolation protocol for task {task_name} requires train_time_range to include the initial time {full_t_min}."
                )
            self.support_axis = "t"
            return

        if self.train_support_ratio is None:
            raise ValueError("support_extrapolation requires train_support_ratio unless legacy time ranges are provided.")
        if not (0.0 < self.train_support_ratio <= 1.0):
            raise ValueError("support_extrapolation train_support_ratio must lie in (0, 1].")
        self.support_axis = self._resolve_support_axis(task_name=task_name, task=task)

    @contextmanager
    def _temporary_domain_range(self, task: BaseTask, axis: str, support_range: list[float]) -> Iterator[None]:
        domain = getattr(task, "domain", None)
        if not isinstance(domain, dict):
            raise ValueError("support_extrapolation requires task.domain to be a mutable mapping.")
        min_key, max_key = _domain_bounds(domain, axis)
        original_min = float(domain[min_key])
        original_max = float(domain[max_key])
        domain[min_key] = float(support_range[0])
        domain[max_key] = float(support_range[1])
        try:
            yield
        finally:
            domain[min_key] = original_min
            domain[max_key] = original_max

    def _ratio_support_range(self, task: BaseTask, axis: str) -> list[float]:
        domain = getattr(task, "domain", None)
        assert isinstance(domain, dict)
        min_key, max_key = _domain_bounds(domain, axis)
        lower = float(domain[min_key])
        upper = float(domain[max_key])
        assert self.train_support_ratio is not None
        return [lower, lower + (upper - lower) * self.train_support_ratio]

    def sample_train_batches(self, task: BaseTask, task_name: str, device: torch.device) -> TrainBatches:
        if self.legacy_holdout_mode:
            assert self.train_time_range is not None
            with self._temporary_domain_range(task, "t", self.train_time_range):
                batches = task.sample_train_batches(device=device)
            return self.apply_to_train_batches(task_name=task_name, batches=batches)

        assert self.support_axis is not None
        with self._temporary_domain_range(task, self.support_axis, self._ratio_support_range(task, self.support_axis)):
            batches = task.sample_train_batches(device=device)
        return self.apply_to_train_batches(task_name=task_name, batches=batches)

    def sample_evaluation_batch(
        self,
        task: BaseTask,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        if self.legacy_holdout_mode:
            assert self.eval_time_range is not None
            with self._temporary_domain_range(task, "t", self.eval_time_range):
                return task.sample_evaluation_batch(
                    device=device,
                    num_samples=num_samples,
                    grid_x=grid_x,
                    grid_t=grid_t,
                    grid_y=grid_y,
                )
        return task.sample_evaluation_batch(
            device=device,
            num_samples=num_samples,
            grid_x=grid_x,
            grid_t=grid_t,
            grid_y=grid_y,
        )


ExtrapolationProtocol = SupportExtrapolationProtocol


@dataclass
class ParameterShiftProtocol(BaseRobustnessProtocol):
    """Scalar task-parameter shift protocol for train/eval regime slices."""

    slice_id: str = ""
    parameter_name: str = ""
    train_value: str | int | float = 0.0
    eval_value: str | int | float = 0.0

    def __init__(
        self,
        *,
        slice_id: str,
        parameter_name: str,
        train_value: str | int | float,
        eval_value: str | int | float,
        severity_label: str | None = None,
    ) -> None:
        super().__init__(
            protocol_name="parameter_shift",
            level=0.0,
            severity_label=severity_label,
            resolved_target_scopes=[],
        )
        self.slice_id = slice_id
        self.parameter_name = parameter_name
        self.train_value = train_value
        self.eval_value = eval_value

    def validate_task(self, *, task_name: str, task: BaseTask) -> None:
        _ensure_task_scalar_attribute(
            task=task,
            task_name=task_name,
            attribute_name=self.parameter_name,
            protocol_name=self.protocol_name,
            train_value=self.train_value,
            eval_value=self.eval_value,
        )

    def sample_train_batches(self, task: BaseTask, task_name: str, device: torch.device) -> TrainBatches:
        with _temporary_task_attribute(task, self.parameter_name, self.train_value):
            return task.sample_train_batches(device=device)

    def sample_evaluation_batch(
        self,
        task: BaseTask,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        with _temporary_task_attribute(task, self.parameter_name, self.eval_value):
            return task.sample_evaluation_batch(
                device=device,
                num_samples=num_samples,
                grid_x=grid_x,
                grid_t=grid_t,
                grid_y=grid_y,
            )

    def exact_solution(self, task: BaseTask, inputs: torch.Tensor) -> torch.Tensor | None:
        with _temporary_task_attribute(task, self.parameter_name, self.eval_value):
            return task.exact_solution(inputs)

    def compute_loss_terms(
        self,
        task: BaseTask,
        model: torch.nn.Module,
        batches: TrainBatches,
    ) -> dict[str, torch.Tensor]:
        with _temporary_task_attribute(task, self.parameter_name, self.train_value):
            return task.compute_loss_terms(model=model, batches=batches)

    def compute_metric(
        self,
        task: BaseTask,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        with _temporary_task_attribute(task, self.parameter_name, self.eval_value):
            return task.compute_metric(
                metric_name,
                model=model,
                batch=batch,
                predictions=predictions,
                targets=targets,
            )

    def compute_residual(self, task: BaseTask, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        with _temporary_task_attribute(task, self.parameter_name, self.eval_value):
            return task.compute_residual(model=model, inputs=inputs)

    def regime_metadata_dict(self) -> dict[str, object]:
        return {
            "protocol_family": self.protocol_name,
            "slice_id": self.slice_id,
            "shift_dimension": "parameter",
            "train_variant_label": f"{self.parameter_name}={self.train_value}",
            "eval_variant_label": f"{self.parameter_name}={self.eval_value}",
            "parameter_name": self.parameter_name,
        }


@dataclass
class ResolutionShiftProtocol(BaseRobustnessProtocol):
    """Sampling and evaluation-grid override protocol for resolution shifts."""

    slice_id: str = ""
    train_sampling_overrides: dict[str, int] = field(default_factory=dict)
    eval_grid_overrides: dict[str, int] = field(default_factory=dict)
    operator_train_stride: dict[str, int] = field(default_factory=dict)

    def __init__(
        self,
        *,
        slice_id: str,
        train_sampling_overrides: Mapping[str, int] | None = None,
        eval_grid_overrides: Mapping[str, int] | None = None,
        operator_train_stride: Mapping[str, int] | None = None,
        severity_label: str | None = None,
    ) -> None:
        super().__init__(
            protocol_name="resolution_shift",
            level=0.0,
            severity_label=severity_label,
            resolved_target_scopes=[],
        )
        self.slice_id = slice_id
        self.train_sampling_overrides = dict(train_sampling_overrides or {})
        self.eval_grid_overrides = dict(eval_grid_overrides or {})
        self.operator_train_stride = dict(operator_train_stride or {})

    def validate_task(self, *, task_name: str, task: BaseTask) -> None:
        if not self.train_sampling_overrides and not self.eval_grid_overrides and not self.operator_train_stride:
            raise ValueError("resolution_shift requires at least one of sampling, grid, or operator stride overrides.")
        if self.train_sampling_overrides:
            _ensure_task_mapping_attribute(
                task=task,
                task_name=task_name,
                attribute_name="sampling",
                protocol_name=self.protocol_name,
            )
        if self.operator_train_stride:
            _ensure_task_mapping_attribute(
                task=task,
                task_name=task_name,
                attribute_name="operator_train_stride",
                protocol_name=self.protocol_name,
            )

    def sample_train_batches(self, task: BaseTask, task_name: str, device: torch.device) -> TrainBatches:
        with ExitStack() as stack:
            if self.train_sampling_overrides:
                sampling = _ensure_task_mapping_attribute(
                    task=task,
                    task_name=task_name,
                    attribute_name="sampling",
                    protocol_name=self.protocol_name,
                )
                stack.enter_context(_temporary_mapping_updates(sampling, self.train_sampling_overrides))
            if self.operator_train_stride:
                stride_mapping = _ensure_task_mapping_attribute(
                    task=task,
                    task_name=task_name,
                    attribute_name="operator_train_stride",
                    protocol_name=self.protocol_name,
                )
                stack.enter_context(_temporary_mapping_updates(stride_mapping, self.operator_train_stride))
            return task.sample_train_batches(device=device)

    def sample_evaluation_batch(
        self,
        task: BaseTask,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        resolved_grid_x = self.eval_grid_overrides.get("grid_x", grid_x)
        resolved_grid_t = self.eval_grid_overrides.get("grid_t", grid_t)
        resolved_grid_y = self.eval_grid_overrides.get("grid_y", grid_y)
        return task.sample_evaluation_batch(
            device=device,
            num_samples=num_samples,
            grid_x=resolved_grid_x,
            grid_t=resolved_grid_t,
            grid_y=resolved_grid_y,
        )

    def regime_metadata_dict(self) -> dict[str, object]:
        train_parts: list[str] = []
        if self.train_sampling_overrides:
            train_parts.append(_format_variant_mapping("sampling", self.train_sampling_overrides))
        if self.operator_train_stride:
            train_parts.append(_format_variant_mapping("stride", self.operator_train_stride))
        train_variant = ";".join(train_parts) if train_parts else "nominal"
        eval_variant = (
            _format_variant_mapping("grid", self.eval_grid_overrides) if self.eval_grid_overrides else "nominal"
        )
        return {
            "protocol_family": self.protocol_name,
            "slice_id": self.slice_id,
            "shift_dimension": "resolution",
            "train_variant_label": train_variant,
            "eval_variant_label": eval_variant,
        }


@dataclass
class BCFamilyShiftProtocol(BaseRobustnessProtocol):
    """Boundary-family shift protocol using task-owned family labels."""

    slice_id: str = ""
    train_boundary_family: str = ""
    eval_boundary_family: str = ""

    def __init__(
        self,
        *,
        slice_id: str,
        train_boundary_family: str,
        eval_boundary_family: str,
        severity_label: str | None = None,
    ) -> None:
        super().__init__(
            protocol_name="bc_family_shift",
            level=0.0,
            severity_label=severity_label,
            resolved_target_scopes=[],
        )
        self.slice_id = slice_id
        self.train_boundary_family = train_boundary_family
        self.eval_boundary_family = eval_boundary_family

    def validate_task(self, *, task_name: str, task: BaseTask) -> None:
        _ensure_task_scalar_attribute(
            task=task,
            task_name=task_name,
            attribute_name="boundary_family",
            protocol_name=self.protocol_name,
            train_value=self.train_boundary_family,
            eval_value=self.eval_boundary_family,
        )

    def sample_train_batches(self, task: BaseTask, task_name: str, device: torch.device) -> TrainBatches:
        del task_name
        with _temporary_task_attribute(task, "boundary_family", self.train_boundary_family):
            return task.sample_train_batches(device=device)

    def sample_evaluation_batch(
        self,
        task: BaseTask,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        with _temporary_task_attribute(task, "boundary_family", self.eval_boundary_family):
            return task.sample_evaluation_batch(
                device=device,
                num_samples=num_samples,
                grid_x=grid_x,
                grid_t=grid_t,
                grid_y=grid_y,
            )

    def exact_solution(self, task: BaseTask, inputs: torch.Tensor) -> torch.Tensor | None:
        with _temporary_task_attribute(task, "boundary_family", self.eval_boundary_family):
            return task.exact_solution(inputs)

    def compute_loss_terms(
        self,
        task: BaseTask,
        model: torch.nn.Module,
        batches: TrainBatches,
    ) -> dict[str, torch.Tensor]:
        with _temporary_task_attribute(task, "boundary_family", self.train_boundary_family):
            return task.compute_loss_terms(model=model, batches=batches)

    def compute_metric(
        self,
        task: BaseTask,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        with _temporary_task_attribute(task, "boundary_family", self.eval_boundary_family):
            return task.compute_metric(
                metric_name,
                model=model,
                batch=batch,
                predictions=predictions,
                targets=targets,
            )

    def regime_metadata_dict(self) -> dict[str, object]:
        return {
            "protocol_family": self.protocol_name,
            "slice_id": self.slice_id,
            "shift_dimension": "boundary_family",
            "train_variant_label": self.train_boundary_family,
            "eval_variant_label": self.eval_boundary_family,
        }


@dataclass
class ICFamilyShiftProtocol(BaseRobustnessProtocol):
    """Initial-family shift protocol using task-owned family labels."""

    slice_id: str = ""
    train_initial_family: str = ""
    eval_initial_family: str = ""

    def __init__(
        self,
        *,
        slice_id: str,
        train_initial_family: str,
        eval_initial_family: str,
        severity_label: str | None = None,
    ) -> None:
        super().__init__(
            protocol_name="ic_family_shift",
            level=0.0,
            severity_label=severity_label,
            resolved_target_scopes=[],
        )
        self.slice_id = slice_id
        self.train_initial_family = train_initial_family
        self.eval_initial_family = eval_initial_family

    def validate_task(self, *, task_name: str, task: BaseTask) -> None:
        _ensure_task_scalar_attribute(
            task=task,
            task_name=task_name,
            attribute_name="initial_family",
            protocol_name=self.protocol_name,
            train_value=self.train_initial_family,
            eval_value=self.eval_initial_family,
        )

    def sample_train_batches(self, task: BaseTask, task_name: str, device: torch.device) -> TrainBatches:
        del task_name
        with _temporary_task_attribute(task, "initial_family", self.train_initial_family):
            return task.sample_train_batches(device=device)

    def sample_evaluation_batch(
        self,
        task: BaseTask,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        with _temporary_task_attribute(task, "initial_family", self.eval_initial_family):
            return task.sample_evaluation_batch(
                device=device,
                num_samples=num_samples,
                grid_x=grid_x,
                grid_t=grid_t,
                grid_y=grid_y,
            )

    def exact_solution(self, task: BaseTask, inputs: torch.Tensor) -> torch.Tensor | None:
        with _temporary_task_attribute(task, "initial_family", self.eval_initial_family):
            return task.exact_solution(inputs)

    def compute_loss_terms(
        self,
        task: BaseTask,
        model: torch.nn.Module,
        batches: TrainBatches,
    ) -> dict[str, torch.Tensor]:
        with _temporary_task_attribute(task, "initial_family", self.train_initial_family):
            return task.compute_loss_terms(model=model, batches=batches)

    def compute_metric(
        self,
        task: BaseTask,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        with _temporary_task_attribute(task, "initial_family", self.eval_initial_family):
            return task.compute_metric(
                metric_name,
                model=model,
                batch=batch,
                predictions=predictions,
                targets=targets,
            )

    def regime_metadata_dict(self) -> dict[str, object]:
        return {
            "protocol_family": self.protocol_name,
            "slice_id": self.slice_id,
            "shift_dimension": "initial_family",
            "train_variant_label": self.train_initial_family,
            "eval_variant_label": self.eval_initial_family,
        }


@dataclass
class GeometryShiftProtocol(BaseRobustnessProtocol):
    """Geometry-family shift protocol for geometry-aware task hosts."""

    slice_id: str = ""
    geometry_split_id: str = ""
    representation: str = "sdf"
    train_geometry_family: str = ""
    eval_geometry_family: str = ""
    geometry_distribution: str = "OOD"
    boundary_band_epsilon: float = 0.05

    def __init__(
        self,
        *,
        slice_id: str,
        geometry_split_id: str,
        representation: str,
        train_geometry_family: str,
        eval_geometry_family: str,
        geometry_distribution: str,
        boundary_band_epsilon: float,
        severity_label: str | None = None,
    ) -> None:
        super().__init__(
            protocol_name="geometry_shift",
            level=0.0,
            severity_label=severity_label,
            resolved_target_scopes=[],
        )
        self.slice_id = slice_id
        self.geometry_split_id = geometry_split_id
        self.representation = representation
        self.train_geometry_family = train_geometry_family
        self.eval_geometry_family = eval_geometry_family
        self.geometry_distribution = geometry_distribution
        self.boundary_band_epsilon = float(boundary_band_epsilon)

    def _train_overrides(self) -> dict[str, Any]:
        return {
            "geometry_family": self.train_geometry_family,
            "geometry_split_id": self.geometry_split_id,
            "geometry_distribution": self.geometry_distribution,
            "boundary_band_epsilon": self.boundary_band_epsilon,
        }

    def _eval_overrides(self) -> dict[str, Any]:
        return {
            "geometry_family": self.eval_geometry_family,
            "geometry_split_id": self.geometry_split_id,
            "geometry_distribution": self.geometry_distribution,
            "boundary_band_epsilon": self.boundary_band_epsilon,
        }

    def validate_task(self, *, task_name: str, task: BaseTask) -> None:
        _ensure_task_scalar_attribute(
            task=task,
            task_name=task_name,
            attribute_name="geometry_family",
            protocol_name=self.protocol_name,
            train_value=self.train_geometry_family,
            eval_value=self.eval_geometry_family,
        )
        _ensure_task_attribute(task, task_name, "geometry_split_id", self.protocol_name)
        _ensure_task_attribute(task, task_name, "geometry_distribution", self.protocol_name)
        _ensure_task_scalar_attribute(
            task=task,
            task_name=task_name,
            attribute_name="boundary_band_epsilon",
            protocol_name=self.protocol_name,
            train_value=self.boundary_band_epsilon,
            eval_value=self.boundary_band_epsilon,
        )

    def sample_train_batches(self, task: BaseTask, task_name: str, device: torch.device) -> TrainBatches:
        del task_name
        with _temporary_task_attributes(task, self._train_overrides()):
            return task.sample_train_batches(device=device)

    def sample_evaluation_batch(
        self,
        task: BaseTask,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        with _temporary_task_attributes(task, self._eval_overrides()):
            return task.sample_evaluation_batch(
                device=device,
                num_samples=num_samples,
                grid_x=grid_x,
                grid_t=grid_t,
                grid_y=grid_y,
            )

    def exact_solution(self, task: BaseTask, inputs: torch.Tensor) -> torch.Tensor | None:
        with _temporary_task_attributes(task, self._eval_overrides()):
            return task.exact_solution(inputs)

    def compute_loss_terms(
        self,
        task: BaseTask,
        model: torch.nn.Module,
        batches: TrainBatches,
    ) -> dict[str, torch.Tensor]:
        with _temporary_task_attributes(task, self._train_overrides()):
            return task.compute_loss_terms(model=model, batches=batches)

    def compute_metric(
        self,
        task: BaseTask,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        with _temporary_task_attributes(task, self._eval_overrides()):
            return task.compute_metric(
                metric_name,
                model=model,
                batch=batch,
                predictions=predictions,
                targets=targets,
            )

    def compute_residual(self, task: BaseTask, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        with _temporary_task_attributes(task, self._eval_overrides()):
            return task.compute_residual(model=model, inputs=inputs)

    def regime_metadata_dict(self) -> dict[str, object]:
        return {
            "protocol_family": self.protocol_name,
            "slice_id": self.slice_id,
            "shift_dimension": "geometry",
            "train_variant_label": self.train_geometry_family,
            "eval_variant_label": self.eval_geometry_family,
        }

    def geometry_metadata_dict(self) -> dict[str, object]:
        return {
            "representation": self.representation,
            "geometry_split_id": self.geometry_split_id,
            "train_geometry_family": self.train_geometry_family,
            "eval_geometry_family": self.eval_geometry_family,
            "geometry_distribution": self.geometry_distribution,
            "boundary_band_epsilon": self.boundary_band_epsilon,
        }



def resolve_target_scopes(config: RobustnessConfig, task_name: str) -> list[str]:
    if config.target_scopes:
        return _validate_scope_names(list(config.target_scopes))
    protocol_name = normalize_protocol_name(config.protocol)
    task_protocol_defaults = _TASK_PROTOCOL_DEFAULT_TARGET_SCOPES.get(task_name)
    if task_protocol_defaults is not None and protocol_name in task_protocol_defaults:
        return list(task_protocol_defaults[protocol_name])
    if task_name not in _TASK_DEFAULT_TARGET_SCOPES:
        raise ValueError(
            f"No default robustness target scopes are defined for task '{task_name}'. "
            "Provide 'robustness.target_scopes' explicitly."
        )
    return list(_TASK_DEFAULT_TARGET_SCOPES[task_name])



def create_robustness_protocol(
    config: RobustnessConfig,
    task_name: str,
    task: BaseTask | None = None,
    task_params: Mapping[str, Any] | None = None,
) -> BaseRobustnessProtocol:
    protocol_name = normalize_protocol_name(config.protocol)
    if protocol_name == "none":
        return NoOpRobustnessProtocol()

    if protocol_name == "support_extrapolation":
        if task is None:
            raise ValueError("support_extrapolation requires a task instance for validation.")
        protocol = SupportExtrapolationProtocol(
            train_support_ratio=config.train_support_ratio,
            train_time_range=config.train_time_range,
            eval_time_range=config.eval_time_range,
            severity_label=config.severity_label,
        )
        protocol.validate_task(task_name=task_name, task=task)
        return protocol

    if protocol_name == "composite":
        resolved_target_scopes = resolve_target_scopes(config=config, task_name=task_name)
        component_protocols: list[BaseRobustnessProtocol] = []
        for component in config.components:
            component_protocol_name = normalize_protocol_name(str(component.get("protocol", "")))
            component_level = float(component.get("level", 0.0))
            component_severity_label = (
                None if component.get("severity_label") is None else str(component.get("severity_label"))
            )
            if component_protocol_name == "sparsity":
                component_protocols.append(
                    SparsityProtocol(
                        level=component_level,
                        resolved_target_scopes=resolved_target_scopes,
                        severity_label=component_severity_label,
                    )
                )
                continue
            if component_protocol_name == "noise":
                component_protocols.append(
                    NoiseProtocol(
                        level=component_level,
                        resolved_target_scopes=resolved_target_scopes,
                        severity_label=component_severity_label,
                    )
                )
                continue
            raise ValueError(f"Unsupported composite component protocol '{component_protocol_name}'.")
        return CompositeProtocol(
            component_protocols=component_protocols,
            resolved_target_scopes=resolved_target_scopes,
            severity_label=config.severity_label,
        )

    if protocol_name in _REGIME_PROTOCOLS:
        if task is None:
            raise ValueError(f"{protocol_name} requires a task instance for validation.")
        regime_slice = _parse_regime_slice(task_params=task_params, protocol_name=protocol_name)
        location = "task.params.regime_slice"
        if protocol_name == "parameter_shift":
            payload = dict(regime_slice)
            protocol = ParameterShiftProtocol(
                slice_id=_require_string(payload, "slice_id", location=location),
                parameter_name=_require_string(payload, "parameter_name", location=location),
                train_value=_require_scalar(payload, "train_value", location=location),
                eval_value=_require_scalar(payload, "eval_value", location=location),
                severity_label=config.severity_label,
            )
            _validate_no_extra_keys(payload, location=location)
            protocol.validate_task(task_name=task_name, task=task)
            return protocol
        if protocol_name == "resolution_shift":
            payload = dict(regime_slice)
            slice_id = _require_string(payload, "slice_id", location=location)
            train_sampling_overrides = (
                _require_int_mapping(payload, "train_sampling_overrides", location=location)
                if "train_sampling_overrides" in payload
                else {}
            )
            eval_grid_overrides = (
                _require_int_mapping(
                    payload,
                    "eval_grid_overrides",
                    location=location,
                    allowed_keys=_ALLOWED_RESOLUTION_SHIFT_GRID_KEYS,
                )
                if "eval_grid_overrides" in payload
                else {}
            )
            operator_train_stride = (
                _require_int_mapping(
                    payload,
                    "operator_train_stride",
                    location=location,
                    allowed_keys=_ALLOWED_OPERATOR_TRAIN_STRIDE_KEYS,
                )
                if "operator_train_stride" in payload
                else {}
            )
            _validate_no_extra_keys(payload, location=location)
            protocol = ResolutionShiftProtocol(
                slice_id=slice_id,
                train_sampling_overrides=train_sampling_overrides,
                eval_grid_overrides=eval_grid_overrides,
                operator_train_stride=operator_train_stride,
                severity_label=config.severity_label,
            )
            protocol.validate_task(task_name=task_name, task=task)
            return protocol
        if protocol_name == "bc_family_shift":
            payload = dict(regime_slice)
            protocol = BCFamilyShiftProtocol(
                slice_id=_require_string(payload, "slice_id", location=location),
                train_boundary_family=_require_string(payload, "train_boundary_family", location=location),
                eval_boundary_family=_require_string(payload, "eval_boundary_family", location=location),
                severity_label=config.severity_label,
            )
            _validate_no_extra_keys(payload, location=location)
            protocol.validate_task(task_name=task_name, task=task)
            return protocol
        if protocol_name == "ic_family_shift":
            payload = dict(regime_slice)
            protocol = ICFamilyShiftProtocol(
                slice_id=_require_string(payload, "slice_id", location=location),
                train_initial_family=_require_string(payload, "train_initial_family", location=location),
                eval_initial_family=_require_string(payload, "eval_initial_family", location=location),
                severity_label=config.severity_label,
            )
            _validate_no_extra_keys(payload, location=location)
            protocol.validate_task(task_name=task_name, task=task)
            return protocol
        if protocol_name == "geometry_shift":
            payload = dict(regime_slice)
            protocol = GeometryShiftProtocol(
                slice_id=_require_string(payload, "slice_id", location=location),
                geometry_split_id=_require_string(payload, "geometry_split_id", location=location),
                representation=_require_choice(
                    payload,
                    "representation",
                    location=location,
                    allowed=_ALLOWED_GEOMETRY_REPRESENTATIONS,
                ),
                train_geometry_family=_require_string(payload, "train_geometry_family", location=location),
                eval_geometry_family=_require_string(payload, "eval_geometry_family", location=location),
                geometry_distribution=_require_choice(
                    payload,
                    "geometry_distribution",
                    location=location,
                    allowed=_ALLOWED_GEOMETRY_DISTRIBUTIONS,
                ),
                boundary_band_epsilon=_require_positive_float(payload, "boundary_band_epsilon", location=location),
                severity_label=config.severity_label,
            )
            _validate_no_extra_keys(payload, location=location)
            protocol.validate_task(task_name=task_name, task=task)
            return protocol

    resolved_target_scopes = resolve_target_scopes(config=config, task_name=task_name)
    if protocol_name == "noise":
        return NoiseProtocol(level=config.level, resolved_target_scopes=resolved_target_scopes, severity_label=config.severity_label)
    if protocol_name == "sensor_drift":
        return SensorDriftProtocol(level=config.level, resolved_target_scopes=resolved_target_scopes, severity_label=config.severity_label)
    if protocol_name == "heteroscedastic_noise":
        return HeteroscedasticNoiseProtocol(
            level=config.level,
            resolved_target_scopes=resolved_target_scopes,
            severity_label=config.severity_label,
        )
    if protocol_name == "low_frequency_bias":
        return LowFrequencyBiasProtocol(
            level=config.level,
            resolved_target_scopes=resolved_target_scopes,
            severity_label=config.severity_label,
        )
    if protocol_name == "sparsity":
        return SparsityProtocol(
            level=config.level,
            resolved_target_scopes=resolved_target_scopes,
            severity_label=config.severity_label,
            pattern_family=None if config.extras.get("pattern_family") is None else str(config.extras["pattern_family"]),
            temporal_block_range=None
            if config.extras.get("temporal_block_range") is None
            else list(config.extras["temporal_block_range"]),
        )
    if protocol_name == "bcic_corruption":
        return BCICCorruptionProtocol(level=config.level, resolved_target_scopes=resolved_target_scopes, severity_label=config.severity_label)
    raise ValueError(f"Unknown robustness protocol '{protocol_name}'.")



def list_protocols() -> list[str]:
    """Return available robustness protocols."""
    return [
        "bc_family_shift",
        "bcic_corruption",
        "composite",
        "extrapolation",
        "geometry_shift",
        "heteroscedastic_noise",
        "ic_family_shift",
        "low_frequency_bias",
        "noise",
        "none",
        "parameter_shift",
        "resolution_shift",
        "sensor_drift",
        "sparsity",
        "support_extrapolation",
    ]
