"""Metric utilities."""

from pinn_bench.metrics.basic import field_mse, field_relative_l2, mse, register_builtin_metrics, relative_l2
from pinn_bench.metrics.registry import get_metric, list_metrics, register_metric

register_builtin_metrics()

__all__ = [
    "field_mse",
    "field_relative_l2",
    "get_metric",
    "list_metrics",
    "mse",
    "register_builtin_metrics",
    "register_metric",
    "relative_l2",
]
