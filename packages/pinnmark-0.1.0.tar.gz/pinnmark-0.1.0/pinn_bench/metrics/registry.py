"""Metric registry helpers."""

from pinn_bench.registry import get_metric, list_metrics, register_metric

__all__ = ["get_metric", "list_metrics", "register_metric"]
