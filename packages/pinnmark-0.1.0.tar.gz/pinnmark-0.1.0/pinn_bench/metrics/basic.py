"""Basic metric functions."""

from __future__ import annotations

import torch

from pinn_bench.registry import register_metric



def mse(predictions: torch.Tensor, targets: torch.Tensor) -> float:
    """Return scalar mean squared error."""
    return float(torch.mean((predictions - targets) ** 2).item())



def relative_l2(predictions: torch.Tensor, targets: torch.Tensor, eps: float = 1e-12) -> float:
    """Return relative L2 norm error."""
    numerator = torch.linalg.norm(predictions - targets)
    denominator = torch.linalg.norm(targets) + eps
    return float((numerator / denominator).item())



def field_mse(predictions: torch.Tensor, targets: torch.Tensor) -> float:
    """Return scalar mean squared error for flattened field outputs."""
    return mse(predictions, targets)



def field_relative_l2(predictions: torch.Tensor, targets: torch.Tensor, eps: float = 1e-12) -> float:
    """Return relative L2 norm error for flattened field outputs."""
    return relative_l2(predictions, targets, eps=eps)



def register_builtin_metrics() -> None:
    """Register builtin metrics in an idempotent way."""
    for name, function in (
        ("mse", mse),
        ("relative_l2", relative_l2),
        ("field_mse", field_mse),
        ("field_relative_l2", field_relative_l2),
    ):
        try:
            register_metric(name)(function)
        except KeyError:
            continue
