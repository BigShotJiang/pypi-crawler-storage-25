"""Version reporting for pinn_bench."""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence

from pinn_bench import __version__
from pinn_bench.resources import resolve_manifest_path, resolve_repo_root


FROZEN_BASELINES = ["v0.1", "v0.2", "v0.3", "v0.4", "v0.5", "v0.6", "v1.0"]
LATEST_FORMAL_BASELINE = "v1.0"
LATEST_FORMAL_MANIFEST_NAME = "baseline_v1_0_formal.yaml"
LATEST_FORMAL_OUTPUTS_ROOT = "outputs_v10"
KNOWN_PREVIEW_LINE: str | None = None
KNOWN_PREVIEW_MANIFEST_NAME: str | None = None
KNOWN_PREVIEW_OUTPUTS_ROOT: str | None = None
LATEST_COMPLETED_PREVIEW_LINE = "v1.9-preview"
LATEST_COMPLETED_PREVIEW_MANIFEST_NAME = "baseline_v1_9_preview.yaml"
LATEST_COMPLETED_PREVIEW_OUTPUTS_ROOT = "outputs_preview_v19"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Show package and benchmark line version information.")
    parser.add_argument("--json", action="store_true", help="Emit machine-readable version state.")
    return parser



def build_version_payload() -> dict[str, object]:
    repo_root = resolve_repo_root()
    formal_manifest = resolve_manifest_path(LATEST_FORMAL_MANIFEST_NAME)
    formal_outputs_root = (repo_root / LATEST_FORMAL_OUTPUTS_ROOT).resolve()
    preview_manifest = None if KNOWN_PREVIEW_MANIFEST_NAME is None else resolve_manifest_path(KNOWN_PREVIEW_MANIFEST_NAME)
    preview_outputs_root = None if KNOWN_PREVIEW_OUTPUTS_ROOT is None else (repo_root / KNOWN_PREVIEW_OUTPUTS_ROOT).resolve()
    completed_preview_manifest = resolve_manifest_path(LATEST_COMPLETED_PREVIEW_MANIFEST_NAME)
    completed_preview_outputs_root = (repo_root / LATEST_COMPLETED_PREVIEW_OUTPUTS_ROOT).resolve()
    return {
        "package_version": __version__,
        "frozen_baselines": list(FROZEN_BASELINES),
        "current_formal_baseline": LATEST_FORMAL_BASELINE,
        "current_preview_line": KNOWN_PREVIEW_LINE,
        "formal_manifest": str(formal_manifest),
        "formal_outputs_root": str(formal_outputs_root),
        "preview_manifest": None if preview_manifest is None else str(preview_manifest),
        "preview_outputs_root": None if preview_outputs_root is None else str(preview_outputs_root),
        "latest_completed_preview_line": LATEST_COMPLETED_PREVIEW_LINE,
        "latest_completed_preview_manifest": str(completed_preview_manifest),
        "latest_completed_preview_outputs_root": str(completed_preview_outputs_root),
    }



def _preview_text(value: object) -> str:
    if value is None:
        return "none"
    text = str(value).strip()
    return text or "none"



def _print_text(payload: dict[str, object]) -> None:
    frozen_baselines = payload["frozen_baselines"]
    assert isinstance(frozen_baselines, list)
    preview_line = _preview_text(payload.get("current_preview_line"))
    completed_preview_line = _preview_text(payload.get("latest_completed_preview_line"))
    print(f"package_version: {payload['package_version']}")
    print(f"frozen_baselines: {', '.join(str(item) for item in frozen_baselines)}")
    print(f"current_formal_baseline: {payload['current_formal_baseline']}")
    print(f"latest_formal_baseline: {payload['current_formal_baseline']}")
    print(f"current_preview_line: {preview_line}")
    print(f"known_preview_line: {preview_line}")
    print(f"latest_completed_preview_line: {completed_preview_line}")
    print(f"formal_manifest: {payload['formal_manifest']}")
    print(f"formal_outputs_root: {payload['formal_outputs_root']}")
    print(f"preview_manifest: {payload.get('preview_manifest')}")
    print(f"preview_outputs_root: {payload.get('preview_outputs_root')}")
    print(f"latest_completed_preview_manifest: {payload['latest_completed_preview_manifest']}")
    print(f"latest_completed_preview_outputs_root: {payload['latest_completed_preview_outputs_root']}")



def main(argv: Sequence[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    payload = build_version_payload()
    if args.json:
        print(json.dumps(payload, indent=2))
        return
    _print_text(payload)


if __name__ == '__main__':
    main()
