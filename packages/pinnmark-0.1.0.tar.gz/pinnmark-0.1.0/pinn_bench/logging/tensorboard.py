"""TensorBoard logging wrapper."""

from __future__ import annotations

from pathlib import Path

import importlib


class TensorBoardLogger:
    """Optional TensorBoard scalar logger."""

    def __init__(self, enabled: bool, log_dir: Path) -> None:
        self.enabled = enabled
        self._writer = None
        if enabled:
            try:
                summary_writer = importlib.import_module("torch.utils.tensorboard").SummaryWriter
            except ModuleNotFoundError as error:
                raise ValueError(
                    "Logging backend 'tensorboard' requires TensorBoard support. Install tensorboard or use --log-backend none|basic|wandb."
                ) from error
            self._writer = summary_writer(log_dir=str(log_dir))

    def log_scalar(self, tag: str, value: float, step: int) -> None:
        """Log a scalar if TensorBoard backend is enabled."""
        if self._writer is None:
            return
        self._writer.add_scalar(tag=tag, scalar_value=value, global_step=step)

    def close(self) -> None:
        """Close writer resources."""
        if self._writer is not None:
            self._writer.flush()
            self._writer.close()

