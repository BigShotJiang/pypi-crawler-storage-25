"""Console logger wrapper."""

from __future__ import annotations

import logging
from collections.abc import Mapping
from typing import Any


class BasicLogger:
    """Simple epoch logger for stdout."""

    def __init__(self, log_every: int = 1, name: str = "pinn_bench") -> None:
        self.log_every = max(1, int(log_every))
        self._logger = logging.getLogger(name)
        self._logger.setLevel(logging.INFO)
        self._logger.propagate = False

        if not self._logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter("[%(asctime)s] %(levelname)s - %(message)s")
            handler.setFormatter(formatter)
            self._logger.addHandler(handler)

    def info(self, message: str) -> None:
        """Log an informational message."""
        self._logger.info(message)

    def log_epoch(self, epoch: int, metrics: Mapping[str, Any]) -> None:
        """Log metrics for one epoch according to frequency."""
        if epoch % self.log_every != 0:
            return
        parts: list[str] = []
        for key, value in metrics.items():
            if key == "epoch":
                continue
            if isinstance(value, (int, float)):
                parts.append(f"{key}={float(value):.6f}")
            else:
                parts.append(f"{key}={value}")
        metric_str = ", ".join(parts)
        self._logger.info("epoch=%d, %s", epoch, metric_str)
