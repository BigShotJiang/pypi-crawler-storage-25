"""Real-result fair-board pipeline backed by executed or validated runs."""

from __future__ import annotations

from collections import Counter, defaultdict
from collections.abc import Iterable
from datetime import datetime, timezone
import csv
import json
from math import erf, isfinite, sqrt
from pathlib import Path
import shutil
from statistics import NormalDist, mean, median, stdev
from typing import Any

import yaml
import pandas as pd

import pinn_bench.models  # noqa: F401
from pinn_bench.config.loader import load_config
from pinn_bench.fair_board import (
    DATA_BUDGET_CONTRACT_ID,
    INVERSE_JOINT_MAIN_CONTRACT_ID,
    INVERSE_JOINT_MAIN_METRIC_NAME,
    INVERSE_JOINT_MAIN_SURFACE_ID,
    MAIN_EVALUATION_CONTRACT_ID,
    MAIN_METRIC_NAME,
    MAIN_SURFACE_ID,
    SCORE_SCHEMA_ID,
    SUPERVISION_BUDGET_CONTRACT_ID,
    TRAINING_BUDGET_CONTRACT_ID,
    _normalize_mixed_list,
    list_participant_normalization_records,
    write_fair_board_artifacts,
)
from pinn_bench.runners.experiment import ExperimentRunner

REPO_ROOT = Path(__file__).resolve().parents[1]
BENCHMARK_RUN_ROOT = REPO_ROOT / "artifacts" / "benchmark_runs"
BENCHMARK_MODEL_ROOT = REPO_ROOT / "artifacts" / "benchmark_model_inventory"
PAPER_ROOT = REPO_ROOT / "paper" / "neurips2026"
GENERATED_MAINTEXT_ROOT = PAPER_ROOT / "generated_maintext"
OUTPUTS_ROOT = REPO_ROOT / "outputs_playground"
TMP_CONFIG_ROOT = BENCHMARK_RUN_ROOT / "tmp_real_result_configs"
REPLAY_ROOT = BENCHMARK_RUN_ROOT / "contract_aligned_replays"

DEFAULT_TARGET_SEEDS = tuple(range(10))
DEFAULT_LEGACY_TARGET_SEEDS = (13, 17)
LEGACY_SCORE_SCHEMA_ID = "fair_global_error_score_v1.real_results"
PARALLEL_INVERSE_JOINT_SCORE_SCHEMA_ID = "fair_inverse_joint_score_v1.real_results"
REQUIRED_RUN_FILES = ("config_snapshot.yaml", "metrics.json", "train_log.csv", "model.pt", "loss_curve.png")
OFFICIAL_SEED_POLICY_ID = "contract_aligned_replay_seed0_to_seed9"
LEGACY_SEED_POLICY_ID = "validated_reuse_seed13_plus_contract_aligned_replay_seed17"




def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _target_seeds(target_seeds: Iterable[int] | None = None) -> tuple[int, ...]:
    seeds = DEFAULT_TARGET_SEEDS if target_seeds is None else tuple(int(seed) for seed in target_seeds)
    if not seeds:
        raise ValueError("target_seeds must not be empty")
    return tuple(dict.fromkeys(seeds))


def _canonical_slug(value: str) -> str:
    return value.replace(".", "__")


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def load_json_rows(path: Path) -> list[dict[str, Any]]:
    payload = _read_json(path)
    if isinstance(payload, dict) and "rows" in payload:
        return list(payload["rows"])
    if isinstance(payload, list):
        return list(payload)
    raise ValueError(f"Unsupported JSON row payload: {path}")


def _read_yaml(path: Path) -> dict[str, Any]:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def _write_json(path: Path, schema_version: str, rows: list[dict[str, Any]]) -> None:
    path.write_text(json.dumps({"schema_version": schema_version, "rows": rows}, indent=2), encoding="utf-8")


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"No rows for {path}")
    fieldnames = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _serialize_cell(value) for key, value in row.items()})


def _serialize_cell(value: Any) -> str:
    if isinstance(value, bool):
        return "True" if value else "False"
    if value is None:
        return ""
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, list):
        if value and all(isinstance(item, str) for item in value):
            return " | ".join(value)
        return json.dumps(value, ensure_ascii=True, sort_keys=True)
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=True, sort_keys=True)
    return str(value)


def _archive_legacy_copy(path: Path) -> None:
    if not path.exists() or not path.is_file():
        return
    legacy_path = path.with_name(f"{path.stem}_legacy_seed13_seed17{path.suffix}")
    shutil.copy2(path, legacy_path)


def _archive_legacy_real_result_chain() -> None:
    archive_targets = [
        BENCHMARK_MODEL_ROOT / "main_fair_board_real_scores.csv",
        BENCHMARK_MODEL_ROOT / "main_fair_board_real_scores.json",
        BENCHMARK_MODEL_ROOT / "main_fair_board_real_scores.md",
        BENCHMARK_MODEL_ROOT / "fairness_audit_results.csv",
        BENCHMARK_MODEL_ROOT / "fairness_audit_results.json",
        BENCHMARK_MODEL_ROOT / "fairness_audit_results.md",
        BENCHMARK_MODEL_ROOT / "fairness_audit_results_v2.csv",
        BENCHMARK_MODEL_ROOT / "fairness_audit_results_v2.json",
        BENCHMARK_MODEL_ROOT / "fairness_audit_results_v2.md",
        BENCHMARK_RUN_ROOT / "main_fair_board_run_manifest.csv",
        BENCHMARK_RUN_ROOT / "main_fair_board_run_manifest.json",
        BENCHMARK_RUN_ROOT / "main_fair_board_run_ledger.csv",
        BENCHMARK_RUN_ROOT / "main_fair_board_run_ledger.json",
        BENCHMARK_RUN_ROOT / "per_seed_metrics.csv",
        BENCHMARK_RUN_ROOT / "per_seed_metrics.json",
        BENCHMARK_RUN_ROOT / "per_method_metrics.csv",
        BENCHMARK_RUN_ROOT / "per_method_metrics.json",
        BENCHMARK_RUN_ROOT / "score_aggregation_records.csv",
        BENCHMARK_RUN_ROOT / "score_aggregation_records.json",
        BENCHMARK_MODEL_ROOT / "paper_result_consistency_audit.json",
        PAPER_ROOT / "paper_result_consistency_audit.md",
        PAPER_ROOT / "paper_results_draft.md",
        PAPER_ROOT / "paper_main_results_table.md",
        PAPER_ROOT / "paper_fairness_audit_section.md",
        PAPER_ROOT / "paper_appendix_result_cards.md",
    ]
    for target in archive_targets:
        _archive_legacy_copy(target)


def _format_score(value: Any) -> str:
    return f"{float(value):.6f}"


def _format_optional_score(value: Any) -> str:
    if value is None:
        return "not_ready"
    return f"{float(value):.6f}"


def _format_mean_std(row: dict[str, Any]) -> str:
    return f"{_format_score(row['main_score_mean'])} ± {_format_score(row['main_score_std'])}"


def _top_rows_with_ties(
    rows: list[dict[str, Any]],
    key: str,
    *,
    top_n: int,
    reverse: bool = True,
) -> list[dict[str, Any]]:
    ordered = sorted(rows, key=lambda item: (float(item[key]), str(item["canonical_id"])), reverse=reverse)
    if not ordered:
        return []
    cutoff_index = min(top_n, len(ordered)) - 1
    cutoff_value = float(ordered[cutoff_index][key])
    if reverse:
        return [row for row in ordered if float(row[key]) >= cutoff_value]
    return [row for row in ordered if float(row[key]) <= cutoff_value]


def _exact_score_tie_clusters(board_rows: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in board_rows:
        grouped[(_format_score(row["main_score_mean"]), _format_score(row["main_score_std"]))].append(row)
    clusters = [rows for rows in grouped.values() if len(rows) > 1]
    clusters.sort(key=lambda items: min(int(row["rank"]) for row in items))
    return clusters


def _metric_collision_clusters(aggregation_rows: list[dict[str, Any]]) -> list[list[str]]:
    seen: set[tuple[str, ...]] = set()
    clusters: list[list[str]] = []
    for row in aggregation_rows:
        cluster = tuple(sorted({str(item) for item in row["metric_fingerprint_collisions"]}))
        if len(cluster) <= 1 or cluster in seen:
            continue
        seen.add(cluster)
        clusters.append(list(cluster))
    clusters.sort()
    return clusters


def _scan_canonical_artifacts() -> dict[str, list[dict[str, Any]]]:
    rows: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for metrics_path in OUTPUTS_ROOT.rglob("metrics.json"):
        if not any(tag in str(metrics_path) for tag in ("all_method_runnable_evidence_runs", "twenty_method_push_evidence", "external_model_upgrade_evidence")):
            continue
        payload = _read_json(metrics_path)
        metadata = payload.get("metadata", {})
        canonical_id = None
        primary_method = metadata.get("primary_method")
        if isinstance(primary_method, dict) and primary_method.get("method_id"):
            canonical_id = str(primary_method["method_id"])
        elif str(metadata.get("model_name") or "").startswith("pinnmark."):
            canonical_id = str(metadata["model_name"])
        if canonical_id is None:
            continue
        artifact_dir = metrics_path.parent
        rows[canonical_id].append(
            {
                "artifact_path": str(artifact_dir.relative_to(REPO_ROOT)),
                "metrics_path": str(metrics_path.relative_to(REPO_ROOT)),
                "config_path": str((artifact_dir / "config_snapshot.yaml").relative_to(REPO_ROOT)),
                "task_name": str(metadata.get("task_name") or ""),
                "seed": int(metadata.get("seed", -1)),
                "evaluation_mode": str(metadata.get("evaluation_mode") or ""),
                "model_name": str(metadata.get("model_name") or ""),
                "evidence_dir": artifact_dir,
            }
        )
    return rows


def _surface_instance_id(task_name: str, config_task: dict[str, Any]) -> str:
    if task_name == "heat1d":
        alpha = config_task.get("params", {}).get("alpha", 0.1)
        return f"{MAIN_SURFACE_ID}.heat1d.alpha_{alpha}"
    if task_name == "burgers1d_operator_rollout":
        variant = config_task.get("params", {}).get("dataset_variant", "default")
        return f"{MAIN_SURFACE_ID}.burgers1d_operator_rollout.{variant}"
    return f"{MAIN_SURFACE_ID}.{task_name}.default"


def _selected_participants() -> dict[str, dict[str, Any]]:
    write_fair_board_artifacts(REPO_ROOT)
    return {row["canonical_id"]: row for row in list_participant_normalization_records()}


def _validated_reuse_candidate(method_id: str, participant: dict[str, Any], scanned: dict[str, list[dict[str, Any]]]) -> dict[str, Any] | None:
    desired_task = str(participant["task_name"])
    candidates = scanned.get(method_id, [])
    for candidate in candidates:
        if candidate["seed"] == DEFAULT_LEGACY_TARGET_SEEDS[0] and candidate["task_name"] == desired_task:
            return candidate
    return None


def _replay_output_dir(method_id: str, seed: int) -> Path:
    return REPLAY_ROOT / _canonical_slug(method_id) / f"seed_{seed}"


def _replay_config_path(method_id: str, seed: int) -> Path:
    return TMP_CONFIG_ROOT / f"{_canonical_slug(method_id)}__seed_{seed}.yaml"


def _source_config_for_replay(participant: dict[str, Any], candidate: dict[str, Any] | None) -> tuple[dict[str, Any], str]:
    if candidate is not None:
        config_path = REPO_ROOT / str(candidate["config_path"])
        return _read_yaml(config_path), str(candidate["artifact_path"])
    artifact = str(_normalize_mixed_list(participant["artifact_paths"])[0])
    return _read_yaml(REPO_ROOT / artifact / "config_snapshot.yaml"), artifact


def _write_yaml(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")


def _run_replay(method_id: str, participant: dict[str, Any], candidate: dict[str, Any] | None, seed: int) -> dict[str, Any]:
    out_dir = _replay_output_dir(method_id, seed)
    metrics_path = out_dir / "metrics.json"
    if metrics_path.exists():
        return {
            "canonical_id": method_id,
            "seed": seed,
            "run_mode": "contract_aligned_replay",
            "status": "completed",
            "artifact_path": str(out_dir.relative_to(REPO_ROOT)),
            "config_path": str((out_dir / "config_snapshot.yaml").relative_to(REPO_ROOT)),
            "metrics_path": str(metrics_path.relative_to(REPO_ROOT)),
            "train_log_path": str((out_dir / "train_log.csv").relative_to(REPO_ROOT)),
            "model_path": str((out_dir / "model.pt").relative_to(REPO_ROOT)),
            "started_at": None,
            "ended_at": datetime.fromtimestamp(metrics_path.stat().st_mtime, tz=timezone.utc).isoformat(),
            "recovery_action": "reused_existing_replay_artifact",
        }

    payload, source_artifact = _source_config_for_replay(participant, candidate)
    payload.setdefault("train", {})
    payload["train"]["seed"] = seed
    payload.setdefault("output", {})
    payload["output"]["root_dir"] = str(out_dir)
    config_path = _replay_config_path(method_id, seed)
    _write_yaml(config_path, payload)
    started_at = _utc_now()
    config = load_config(config_path)
    ExperimentRunner.from_config(config).run()
    ended_at = _utc_now()
    return {
        "canonical_id": method_id,
        "seed": seed,
        "run_mode": "contract_aligned_replay",
        "status": "completed",
        "artifact_path": str(out_dir.relative_to(REPO_ROOT)),
        "config_path": str((out_dir / "config_snapshot.yaml").relative_to(REPO_ROOT)),
        "metrics_path": str((out_dir / "metrics.json").relative_to(REPO_ROOT)),
        "train_log_path": str((out_dir / "train_log.csv").relative_to(REPO_ROOT)),
        "model_path": str((out_dir / "model.pt").relative_to(REPO_ROOT)),
        "started_at": started_at,
        "ended_at": ended_at,
        "recovery_action": f"replayed_from_{source_artifact}",
    }


def _plan_real_runs() -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    participants = _selected_participants()
    scanned = _scan_canonical_artifacts()
    manifest_rows: list[dict[str, Any]] = []
    planned_seed_rows: list[dict[str, Any]] = []
    exclusion_rows: list[dict[str, Any]] = []
    for method_id, participant in participants.items():
        candidate = _validated_reuse_candidate(method_id, participant, scanned)
        for other in scanned.get(method_id, []):
            reason = "legacy_candidate_retired_from_official_10_seed_board"
            if str(other["model_name"]).startswith("ext_"):
                reason = "external_lineage_bridge_not_used_for_official_10_seed_scoring"
            exclusion_rows.append(
                {
                    "canonical_id": method_id,
                    "candidate_artifact_path": other["artifact_path"],
                    "reason": reason,
                }
            )

        seed_rows = [
            {
                "seed": seed,
                "run_mode": "contract_aligned_replay",
                "artifact_path": str(_replay_output_dir(method_id, seed).relative_to(REPO_ROOT)),
            }
            for seed in _target_seeds()
        ]
        planned_seed_rows.extend(
            {
                "canonical_id": method_id,
                "display_name": participant["display_name"],
                "primary_surface": participant["primary_surface"],
                "evaluation_contract_id": _normalize_mixed_list(participant["evaluation_contract_ids"])[0],
                "surface_instance_id": _surface_instance_id(str(participant["task_name"]), _read_yaml(REPO_ROOT / _normalize_mixed_list(participant["artifact_paths"])[0] / "config_snapshot.yaml")["task"]),
                "seed": row["seed"],
                "run_mode": row["run_mode"],
                "artifact_path": row["artifact_path"],
                "training_budget_contract": participant["training_budget_contract"],
                "data_budget_contract": participant["data_budget_contract"],
                "supervision_budget_contract": participant["supervision_budget_contract"],
            }
            for row in seed_rows
        )
        manifest_rows.append(
            {
                "run_manifest_id": f"manifest::{method_id}",
                "canonical_id": method_id,
                "display_name": participant["display_name"],
                "run_mode": "contract_aligned_replay",
                "primary_surface": participant["primary_surface"],
                "surface_instance_id": _surface_instance_id(
                    str(participant["task_name"]),
                    _read_yaml(REPO_ROOT / _normalize_mixed_list(participant["artifact_paths"])[0] / "config_snapshot.yaml")["task"],
                ),
                "evaluation_contract_id": _normalize_mixed_list(participant["evaluation_contract_ids"])[0],
                "runtime_name": participant["runnable_path"],
                "seed_list": list(_target_seeds()),
                "training_budget_contract": participant["training_budget_contract"],
                "data_budget_contract": participant["data_budget_contract"],
                "supervision_budget_contract": participant["supervision_budget_contract"],
                "budget_contract_fingerprint": f"{participant['training_budget_contract']}::{participant['data_budget_contract']}::{participant['supervision_budget_contract']}",
                "config_template_path": f"{_canonical_slug(method_id)}__seed_template",
                "source_artifact_candidates": [row["artifact_path"] for row in scanned.get(method_id, [])],
                "expected_output_root": str((_replay_output_dir(method_id, _target_seeds()[0]).parent).relative_to(REPO_ROOT)),
                "precheck_status": "ready",
                "precheck_blockers": [],
            }
        )
    return manifest_rows, planned_seed_rows, exclusion_rows


def _collect_run_artifact_metrics(artifact_path: str) -> tuple[dict[str, Any], dict[str, Any], dict[str, float]]:
    artifact_dir = REPO_ROOT / artifact_path
    metrics = _read_json(artifact_dir / "metrics.json")
    config = _read_yaml(artifact_dir / "config_snapshot.yaml")
    eval_payload = metrics.get("eval", {})
    field_relative_l2 = eval_payload.get("field_relative_l2", eval_payload.get("relative_l2"))
    field_mse = eval_payload.get("field_mse", eval_payload.get("mse"))
    if field_relative_l2 is None or field_mse is None:
        raise KeyError(f"{artifact_path} missing relative_l2/mse")
    numeric = {
        "field_relative_l2": float(field_relative_l2),
        "field_mse": float(field_mse),
    }
    return metrics, config, numeric


def _run_ledgers_from_plan(execute_replays: bool) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    manifest_rows, planned_seed_rows, exclusion_rows = _plan_real_runs()
    participants = _selected_participants()
    candidate_map = {row["canonical_id"]: row for row in manifest_rows}
    scanned = _scan_canonical_artifacts()
    ledger_rows: list[dict[str, Any]] = []
    failure_rows: list[dict[str, Any]] = []
    for seed_row in planned_seed_rows:
        method_id = str(seed_row["canonical_id"])
        participant = participants[method_id]
        candidate = _validated_reuse_candidate(method_id, participant, scanned)
        if execute_replays:
            replay_row = _run_replay(method_id, participant, candidate, int(seed_row["seed"]))
        else:
            replay_artifact = seed_row["artifact_path"]
            replay_row = {
                "canonical_id": method_id,
                "seed": int(seed_row["seed"]),
                "run_mode": "contract_aligned_replay",
                "status": "completed" if (REPO_ROOT / replay_artifact / "metrics.json").exists() else "missing",
                "artifact_path": replay_artifact,
                "config_path": str((REPO_ROOT / replay_artifact / "config_snapshot.yaml").relative_to(REPO_ROOT)) if (REPO_ROOT / replay_artifact / "config_snapshot.yaml").exists() else "",
                "metrics_path": str((REPO_ROOT / replay_artifact / "metrics.json").relative_to(REPO_ROOT)) if (REPO_ROOT / replay_artifact / "metrics.json").exists() else "",
                "train_log_path": str((REPO_ROOT / replay_artifact / "train_log.csv").relative_to(REPO_ROOT)) if (REPO_ROOT / replay_artifact / "train_log.csv").exists() else "",
                "model_path": str((REPO_ROOT / replay_artifact / "model.pt").relative_to(REPO_ROOT)) if (REPO_ROOT / replay_artifact / "model.pt").exists() else "",
                "started_at": None,
                "ended_at": None,
                "recovery_action": "not_executed_in_this_call",
            }
        artifact_path = replay_row["artifact_path"]
        run_mode = "contract_aligned_replay"
        started_at = replay_row["started_at"]
        ended_at = replay_row["ended_at"]
        recovery_action = replay_row["recovery_action"]
        status = replay_row["status"]

        run_id = f"run::{method_id}::seed{seed_row['seed']}"
        manifest_id = candidate_map[method_id]["run_manifest_id"]
        ledger_rows.append(
            {
                "run_id": run_id,
                "run_manifest_id": manifest_id,
                "canonical_id": method_id,
                "surface_instance_id": seed_row["surface_instance_id"],
                "seed": int(seed_row["seed"]),
                "run_mode": run_mode,
                "status": status,
                "source_artifact_dir": candidate["artifact_path"] if candidate is not None else _normalize_mixed_list(participant["artifact_paths"])[0],
                "replay_parent_artifact_dir": candidate["artifact_path"] if candidate is not None else _normalize_mixed_list(participant["artifact_paths"])[0],
                "start_time_utc": started_at,
                "end_time_utc": ended_at,
                "duration_seconds": None,
                "output_dir": artifact_path,
                "config_snapshot_path": str(Path(artifact_path) / "config_snapshot.yaml"),
                "metrics_path": str(Path(artifact_path) / "metrics.json"),
                "train_log_path": str(Path(artifact_path) / "train_log.csv"),
                "model_path": str(Path(artifact_path) / "model.pt"),
                "budget_record_id": f"budget::{method_id}::seed{seed_row['seed']}",
                "aggregation_eligible": status == "completed",
                "validator_passed": False,
                "failure_code": "" if status == "completed" else "missing_artifact",
                "recovery_action": recovery_action,
            }
        )
    failure_rows.extend(
        {
            "canonical_id": row["canonical_id"],
            "seed": None,
            "event_type": "candidate_excluded",
            "artifact_path": row["candidate_artifact_path"],
            "reason": row["reason"],
        }
        for row in exclusion_rows
    )
    return manifest_rows, ledger_rows, failure_rows


def _budget_fields(config: dict[str, Any], metrics: dict[str, Any], participant: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    train = config.get("train", {})
    task = config.get("task", {})
    task_params = task.get("params", {})
    sampling = task_params.get("sampling", {})
    metadata = metrics.get("metadata", {})
    train_summary = metrics.get("train", {})
    training_fields = {
        "optimizer_family": "adam",
        "optimizer_config_fingerprint": f"adam::lr={train.get('lr')}",
        "train_epoch_cap": int(train.get("epochs", 0)),
        "train_step_cap": int(train.get("epochs", 0)),
        "wallclock_cap_seconds": None,
        "selection_trials_cap": 0,
        "early_stopping_policy": "none",
        "observed_epochs": int(train_summary.get("epochs", train.get("epochs", 0))),
        "observed_duration_seconds": float(train_summary.get("duration_seconds", 0.0)),
        "parameter_count_model": int(metadata.get("parameter_count", 0)),
        "parameter_count_task": int(metadata.get("task_parameter_count", 0)),
        "parameter_count_total": int(metadata.get("total_trainable_parameter_count", metadata.get("parameter_count", 0))),
    }
    data_fields = {
        "collocation_budget_declared": int(sampling.get("num_interior", 0)) if isinstance(sampling, dict) else 0,
        "collocation_budget_used": int(sampling.get("num_interior", 0)) if isinstance(sampling, dict) else 0,
        "boundary_budget_declared": int(sampling.get("num_boundary", 0)) if isinstance(sampling, dict) else 0,
        "boundary_budget_used": int(sampling.get("num_boundary", 0)) if isinstance(sampling, dict) else 0,
        "initial_budget_declared": int(sampling.get("num_initial", 0)) if isinstance(sampling, dict) else 0,
        "initial_budget_used": int(sampling.get("num_initial", 0)) if isinstance(sampling, dict) else 0,
        "operator_condition_budget_declared": int(task_params.get("history_steps", 0)),
        "operator_condition_budget_used": int(task_params.get("history_steps", 0)),
        "operator_query_budget_declared": int(task_params.get("forecast_steps", 0)),
        "operator_query_budget_used": int(task_params.get("forecast_steps", 0)),
        "observation_budget_declared": 0,
        "observation_budget_used": 0,
        "low_fidelity_budget_declared": 0,
        "low_fidelity_budget_used": 0,
        "task_name": str(task.get("name", "")),
    }
    supervision_fields = {
        "loss_weights": dict(train.get("loss_weights", {})),
        "allowed_auxiliary_signals": list(_normalize_mixed_list(participant["special_capabilities_stripped_or_budgeted"])),
        "unbudgeted_advantage_detected": False,
        "budget_violation_codes": [],
        "budget_enforcement_verdict": "within_declared_protocol",
    }
    if participant["standardization_strategy"] == "multifidelity_budget_folding":
        data_fields["low_fidelity_budget_declared"] = 1
        data_fields["low_fidelity_budget_used"] = 1
    if participant["standardization_strategy"] == "inverse_to_field_mapping":
        data_fields["observation_budget_declared"] = 1
        data_fields["observation_budget_used"] = 1
    return training_fields, data_fields, supervision_fields


def _build_budget_log(ledger_rows: list[dict[str, Any]], participants: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for ledger in ledger_rows:
        artifact_path = str(ledger["output_dir"])
        metrics, config, _ = _collect_run_artifact_metrics(artifact_path)
        participant = participants[str(ledger["canonical_id"])]
        training_fields, data_fields, supervision_fields = _budget_fields(config, metrics, participant)
        complete = True
        rows.append(
            {
                "budget_record_id": ledger["budget_record_id"],
                "run_id": ledger["run_id"],
                "canonical_id": ledger["canonical_id"],
                "surface_instance_id": ledger["surface_instance_id"],
                "seed": ledger["seed"],
                "training_budget_contract": TRAINING_BUDGET_CONTRACT_ID,
                "data_budget_contract": DATA_BUDGET_CONTRACT_ID,
                "supervision_budget_contract": SUPERVISION_BUDGET_CONTRACT_ID,
                "budget_contract_fingerprint": f"{TRAINING_BUDGET_CONTRACT_ID}::{DATA_BUDGET_CONTRACT_ID}::{SUPERVISION_BUDGET_CONTRACT_ID}",
                "declared_budget_fields": {**training_fields, **data_fields},
                "executed_budget_fields": {**training_fields, **data_fields},
                "parameter_count_total": training_fields["parameter_count_total"],
                "allowed_auxiliary_signals": supervision_fields["allowed_auxiliary_signals"],
                "unbudgeted_advantage_detected": supervision_fields["unbudgeted_advantage_detected"],
                "budget_violation_codes": supervision_fields["budget_violation_codes"],
                "budget_enforcement_verdict": "complete_and_within_protocol" if complete else "incomplete",
                "budget_ledger_completeness": 1.0 if complete else 0.0,
            }
        )
    return rows


def _validate_run_record(ledger: dict[str, Any], budget_row: dict[str, Any], participant: dict[str, Any], metrics: dict[str, Any]) -> tuple[bool, list[str]]:
    blockers: list[str] = []
    for name in REQUIRED_RUN_FILES:
        if not (REPO_ROOT / ledger["output_dir"] / name).exists():
            blockers.append(f"missing_{name}")
    if ledger["surface_instance_id"] == "":
        blockers.append("missing_surface_instance")
    if budget_row["budget_enforcement_verdict"] != "complete_and_within_protocol":
        blockers.append("budget_not_complete")
    if str(metrics.get("metadata", {}).get("task_name") or "") != str(participant["task_name"]):
        blockers.append("task_name_mismatch")
    if participant["primary_surface"] != MAIN_SURFACE_ID:
        blockers.append("surface_mismatch")
    return (len(blockers) == 0, blockers)


def _build_per_seed_metrics(ledger_rows: list[dict[str, Any]], budget_rows: list[dict[str, Any]], participants: dict[str, dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    budget_map = {row["run_id"]: row for row in budget_rows}
    rows: list[dict[str, Any]] = []
    updated_ledger: list[dict[str, Any]] = []
    for ledger in ledger_rows:
        metrics, config, numeric = _collect_run_artifact_metrics(str(ledger["output_dir"]))
        budget_row = budget_map[ledger["run_id"]]
        participant = participants[str(ledger["canonical_id"])]
        passed, blockers = _validate_run_record(ledger, budget_row, participant, metrics)
        updated = dict(ledger)
        updated["validator_passed"] = passed
        updated["failure_code"] = "" if passed else ";".join(blockers)
        train_path = REPO_ROOT / str(ledger["train_log_path"])
        updated["duration_seconds"] = float(metrics.get("train", {}).get("duration_seconds", 0.0))
        updated_ledger.append(updated)
        rows.append(
            {
                "run_record_id": ledger["run_id"],
                "canonical_id": ledger["canonical_id"],
                "display_name": participant["display_name"],
                "primary_surface": participant["primary_surface"],
                "surface_instance_id": ledger["surface_instance_id"],
                "task_name": metrics.get("metadata", {}).get("task_name"),
                "evaluation_contract_id": _normalize_mixed_list(participant["evaluation_contract_ids"])[0],
                "run_mode": ledger["run_mode"],
                "seed": ledger["seed"],
                "artifact_dir": ledger["output_dir"],
                "metrics_path": ledger["metrics_path"],
                "config_snapshot_path": ledger["config_snapshot_path"],
                "train_log_path": ledger["train_log_path"],
                "validator_passed": passed,
                "training_budget_contract": TRAINING_BUDGET_CONTRACT_ID,
                "data_budget_contract": DATA_BUDGET_CONTRACT_ID,
                "supervision_budget_contract": SUPERVISION_BUDGET_CONTRACT_ID,
                "epochs": int(metrics.get("train", {}).get("epochs", config.get("train", {}).get("epochs", 0))),
                "lr": float(config.get("train", {}).get("lr", 0.0)),
                "parameter_count": int(metrics.get("metadata", {}).get("parameter_count", 0)),
                "duration_seconds": float(metrics.get("train", {}).get("duration_seconds", 0.0)),
                "raw_metric_name": "field_relative_l2",
                "field_relative_l2": numeric["field_relative_l2"],
                "field_mse": numeric["field_mse"],
                "metric_fingerprint": f"{numeric['field_relative_l2']:.12f}|{numeric['field_mse']:.12f}",
                "evidence_strength": participant["evidence_strength"],
                "result_status": "success" if passed else "failed_validation",
                "reuse_status": ledger["run_mode"],
                "notes": participant["fidelity_boundary"],
            }
        )
    return rows, updated_ledger




def _safe_stdev(values: Iterable[float]) -> float:
    values = list(values)
    if len(values) <= 1:
        return 0.0
    return float(stdev(values))


def _parallel_inverse_joint_candidate_metadata(participant: dict[str, Any]) -> dict[str, str]:
    if str(participant.get("standardization_strategy") or "") != "inverse_to_field_mapping":
        return {
            "parallel_surface_id": "",
            "parallel_evaluation_contract_id": "",
            "parallel_score_schema_id": "",
        }
    return {
        "parallel_surface_id": INVERSE_JOINT_MAIN_SURFACE_ID,
        "parallel_evaluation_contract_id": INVERSE_JOINT_MAIN_CONTRACT_ID,
        "parallel_score_schema_id": PARALLEL_INVERSE_JOINT_SCORE_SCHEMA_ID,
    }


def _parallel_inverse_joint_fallback_metrics(canonical_id: str) -> dict[str, Any] | None:
    cache = getattr(_parallel_inverse_joint_fallback_metrics, "_cache", None)
    if not isinstance(cache, dict):
        cache = {}
        tradeoff_path = BENCHMARK_MODEL_ROOT / "main_inverse_joint_tradeoff.json"
        if tradeoff_path.exists():
            for row in load_json_rows(tradeoff_path):
                row_canonical_id = str(row.get("canonical_id") or "")
                inverse_metric = row.get("inverse_target_relative_error_mean")
                residual_metric = row.get("residual_metric_mean")
                if (
                    not row_canonical_id
                    or str(row.get("status", "")) != "ready"
                    or inverse_metric in {None, ""}
                    or residual_metric in {None, ""}
                ):
                    continue
                cache[row_canonical_id] = {
                    "inverse_target_relative_error": float(inverse_metric),
                    "residual_metric": float(residual_metric),
                    "joint_inverse_main_score": float(row["joint_inverse_main_score_mean"]),
                    "source": "tradeoff_export",
                }

        dual_root = BENCHMARK_RUN_ROOT / "main_inverse_dual_board_runs"
        for metrics_path in dual_root.glob("*/*/seed_*/metrics.json"):
            payload = _read_json(metrics_path)
            metadata = payload.get("metadata", {})
            eval_payload = payload.get("eval", {})
            row_canonical_id = str(
                metadata.get("primary_method", {}).get("method_id")
                or metadata.get("model_name")
                or metrics_path.parts[-4].replace("__", ".")
            )
            inverse_metric = eval_payload.get("inverse_target_relative_error", eval_payload.get("parameter_relative_error"))
            residual_metric = eval_payload.get("residual_metric")
            if not row_canonical_id or inverse_metric is None or residual_metric is None:
                continue
            fallback_payload = {
                "inverse_target_relative_error": float(inverse_metric),
                "residual_metric": float(residual_metric),
                "joint_inverse_main_score": None,
                "source": "dual_seed_metrics",
            }
            cache.setdefault(row_canonical_id, fallback_payload)
            cache.setdefault(metrics_path.parts[-4], cache[row_canonical_id])
        setattr(_parallel_inverse_joint_fallback_metrics, "_cache", cache)
    return cache.get(str(canonical_id))


def _parallel_inverse_joint_bundle(participant: dict[str, Any], seed_rows: list[dict[str, Any]]) -> dict[str, Any] | None:
    metadata = _parallel_inverse_joint_candidate_metadata(participant)
    if not seed_rows:
        return None
    if not metadata["parallel_surface_id"]:
        return None
    bundle = participant.get("parallel_inverse_joint_metric_bundle")
    field_values = [float(row["field_relative_l2"]) for row in seed_rows]
    seed_list = [int(row["seed"]) for row in seed_rows]
    seed_run_modes = {int(row["seed"]): str(row["run_mode"]) for row in seed_rows}
    base_payload = {
        "board_family": "parallel_inverse_joint_sidecar",
        "board_id": f"{INVERSE_JOINT_MAIN_SURFACE_ID}::{PARALLEL_INVERSE_JOINT_SCORE_SCHEMA_ID}",
        "board_status": "parallel_candidate_only",
        "legacy_main_board_compatible": False,
        "legacy_main_board_preserved": True,
        "parallel_surface_id": metadata["parallel_surface_id"],
        "parallel_evaluation_contract_id": metadata["parallel_evaluation_contract_id"],
        "parallel_score_schema_id": metadata["parallel_score_schema_id"],
        "score_components": ["field_relative_l2", "inverse_target_relative_error", "residual_metric"],
        "component_score_directions": {
            "field_relative_l2": "lower_is_better",
            "inverse_target_relative_error": "lower_is_better",
            "residual_metric": "lower_is_better",
            INVERSE_JOINT_MAIN_METRIC_NAME: "lower_is_better",
        },
        "seed_list": seed_list,
        "seed_count": len(seed_list),
        "seed_run_modes": seed_run_modes,
        "seed_provenance": {
            "seed_policy": OFFICIAL_SEED_POLICY_ID,
            "seed_count": len(seed_list),
            "seed_list": seed_list,
            "seed_run_modes": seed_run_modes,
        },
    }
    if not isinstance(bundle, dict):
        fallback_bundle = _parallel_inverse_joint_fallback_metrics(str(participant["canonical_id"]))
        if isinstance(fallback_bundle, dict):
            inverse_mean = float(fallback_bundle["inverse_target_relative_error"])
            residual_mean = float(fallback_bundle["residual_metric"])
            joint_values = [
                (field + inverse_mean + residual_mean) / 3.0
                for field in field_values
            ]
            joint_mean = fallback_bundle.get("joint_inverse_main_score")
            if joint_mean is None:
                joint_mean = float(mean(joint_values))
                joint_std = _safe_stdev(joint_values)
                inverse_source = "fallback seed_00 metrics from main_inverse_dual_board_runs"
                residual_source = "fallback seed_00 metrics from main_inverse_dual_board_runs"
                joint_rule = "reuse fallback inverse metrics with legacy 10-seed field aggregation when participant bundle is absent"
            else:
                joint_mean = float(joint_mean)
                joint_std = 0.0
                inverse_source = "fallback main_inverse_board_lambda/main_inverse_joint_tradeoff export"
                residual_source = "fallback main_inverse_joint_tradeoff export"
                joint_rule = "reuse exported fair_inverse_joint_score_v1.real_results when participant bundle is absent"
            return {
                **base_payload,
                "parallel_validator_passed": True,
                "result_ready_for_parallel_reporting": True,
                "missing_required_metrics": [],
                "disqualification_reason": "",
                "field_relative_l2_mean": float(mean(field_values)),
                "field_relative_l2_std": _safe_stdev(field_values),
                "inverse_target_relative_error_mean": inverse_mean,
                "inverse_target_relative_error_std": 0.0,
                "residual_metric_mean": residual_mean,
                "residual_metric_std": 0.0,
                "joint_inverse_main_score_mean": joint_mean,
                "joint_inverse_main_score_std": joint_std,
                "component_metrics": {
                    "field_relative_l2": float(mean(field_values)),
                    "inverse_target_relative_error": inverse_mean,
                    "residual_metric": residual_mean,
                },
                "aggregation_provenance": {
                    "field_metric_source": "per_seed field_relative_l2 from run-backed legacy aggregation rows",
                    "inverse_metric_source": inverse_source,
                    "residual_metric_source": residual_source,
                    "joint_score_rule": joint_rule,
                },
            }
        return {
            **base_payload,
            "parallel_validator_passed": False,
            "result_ready_for_parallel_reporting": False,
            "missing_required_metrics": ["inverse_target_relative_error", "residual_metric"],
            "disqualification_reason": "missing_inverse_joint_metrics_in_selected_artifact",
            "field_relative_l2_mean": float(mean(field_values)),
            "field_relative_l2_std": _safe_stdev(field_values),
            "inverse_target_relative_error_mean": None,
            "inverse_target_relative_error_std": None,
            "residual_metric_mean": None,
            "residual_metric_std": None,
            "joint_inverse_main_score_mean": None,
            "joint_inverse_main_score_std": None,
            "component_metrics": {
                "field_relative_l2": float(mean(field_values)),
                "inverse_target_relative_error": None,
                "residual_metric": None,
            },
            "aggregation_provenance": {
                "field_metric_source": "per_seed field_relative_l2 from run-backed legacy aggregation rows",
                "inverse_metric_source": "missing_from_participant_parallel_inverse_joint_metric_bundle",
                "residual_metric_source": "missing_from_participant_parallel_inverse_joint_metric_bundle",
                "joint_score_rule": "not_computable_until_inverse_target_relative_error_and_residual_metric_exist",
            },
        }

    inverse_values = [float(bundle["inverse_target_relative_error"])] * len(seed_rows)
    residual_values = [float(bundle["residual_metric"])] * len(seed_rows)
    joint_values = [
        (field + inverse + residual) / 3.0
        for field, inverse, residual in zip(field_values, inverse_values, residual_values)
    ]
    component_metrics = {
        "field_relative_l2": float(mean(field_values)),
        "inverse_target_relative_error": float(mean(inverse_values)),
        "residual_metric": float(mean(residual_values)),
    }
    return {
        **base_payload,
        "parallel_validator_passed": True,
        "result_ready_for_parallel_reporting": True,
        "missing_required_metrics": [],
        "disqualification_reason": "",
        "field_relative_l2_mean": float(mean(field_values)),
        "field_relative_l2_std": _safe_stdev(field_values),
        "inverse_target_relative_error_mean": float(mean(inverse_values)),
        "inverse_target_relative_error_std": _safe_stdev(inverse_values),
        "residual_metric_mean": float(mean(residual_values)),
        "residual_metric_std": _safe_stdev(residual_values),
        "joint_inverse_main_score_mean": float(mean(joint_values)),
        "joint_inverse_main_score_std": _safe_stdev(joint_values),
        "component_metrics": component_metrics,
        "aggregation_provenance": {
            "field_metric_source": "per_seed field_relative_l2 from run-backed legacy aggregation rows",
            "inverse_metric_source": "participant parallel_inverse_joint_metric_bundle.inverse_target_relative_error",
            "residual_metric_source": "participant parallel_inverse_joint_metric_bundle.residual_metric",
            "joint_score_rule": "arithmetic_mean(field_relative_l2, inverse_target_relative_error, residual_metric) per seed, then arithmetic mean over seeds",
            "component_metrics": component_metrics,
        },
    }


def _groupby(rows: list[dict[str, Any]], key: str) -> dict[str, list[dict[str, Any]]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[str(row[key])].append(row)
    return grouped


def _build_aggregation_records(
    per_seed_rows: list[dict[str, Any]],
    failure_rows: list[dict[str, Any]],
    participants: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    grouped = _groupby(per_seed_rows, "canonical_id")
    rows: list[dict[str, Any]] = []
    for canonical_id, seed_rows in grouped.items():
        sorted_rows = sorted(seed_rows, key=lambda item: int(item["seed"]))
        seed_scores = [float(row["field_relative_l2"]) for row in sorted_rows]
        mse_scores = [float(row["field_mse"]) for row in sorted_rows]
        participant = participants[canonical_id]
        parallel_candidate_metadata = _parallel_inverse_joint_candidate_metadata(participant)
        parallel_inverse_joint = _parallel_inverse_joint_bundle(participant, sorted_rows)
        rows.append(
            {
                "aggregation_record_id": f"agg::{canonical_id}",
                "canonical_id": canonical_id,
                "score_schema_id": LEGACY_SCORE_SCHEMA_ID,
                "primary_surface": MAIN_SURFACE_ID,
                "evaluation_contract_id": MAIN_EVALUATION_CONTRACT_ID,
                "surface_instance_ids": sorted({str(row["surface_instance_id"]) for row in sorted_rows}),
                "seed_list": [int(row["seed"]) for row in sorted_rows],
                "included_run_record_ids": [str(row["run_record_id"]) for row in sorted_rows],
                "excluded_run_record_ids": [
                    f"excluded::{item['artifact_path']}"
                    for item in failure_rows
                    if str(item["canonical_id"]) == canonical_id and item["event_type"] == "candidate_excluded"
                ],
                "exclusion_reasons": [
                    str(item["reason"])
                    for item in failure_rows
                    if str(item["canonical_id"]) == canonical_id and item["event_type"] == "candidate_excluded"
                ],
                "raw_metric_name": "relative_l2",
                "canonical_metric_name": "field_relative_l2",
                "instance_aggregation_rule": "single surface instance per method under current protocol",
                "seed_aggregation_rule": "arithmetic_mean_over_seed_level_field_relative_l2",
                "cross_instance_normalization_rule": "not_applied_current_protocol_uses_one_instance_per_method",
                "per_instance_seed_scores": {
                    str(sorted_rows[0]["surface_instance_id"]): [float(item["field_relative_l2"]) for item in sorted_rows]
                },
                "per_seed_main_scores": {str(row["seed"]): float(row["field_relative_l2"]) for row in sorted_rows},
                "final_main_score": float(mean(seed_scores)),
                "final_main_score_mean": float(mean(seed_scores)),
                "final_main_score_std": _safe_stdev(seed_scores),
                "field_mse_mean": float(mean(mse_scores)),
                "field_mse_std": _safe_stdev(mse_scores),
                "parallel_inverse_joint": parallel_inverse_joint,
                "parallel_main_candidate_surface": parallel_candidate_metadata["parallel_surface_id"],
                "parallel_main_candidate_contract": parallel_candidate_metadata["parallel_evaluation_contract_id"],
                "parallel_main_candidate_score_schema": parallel_candidate_metadata["parallel_score_schema_id"],
                "tie_break_rule": "main_score_std_then_field_mse_mean_then_canonical_id",
                "metric_fingerprint_collisions": [],
                "traceability_status": "fully_traceable",
            }
        )
    fingerprints = defaultdict(list)
    for row in rows:
        fingerprints[json.dumps(row["per_seed_main_scores"], sort_keys=True)].append(row["canonical_id"])
    for row in rows:
        same = fingerprints[json.dumps(row["per_seed_main_scores"], sort_keys=True)]
        if len(same) > 1:
            row["metric_fingerprint_collisions"] = list(sorted(same))
    return rows


def _build_per_method_metrics(aggregation_rows: list[dict[str, Any]], participants: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for agg in aggregation_rows:
        participant = participants[str(agg["canonical_id"])]
        seed_rows = agg["per_seed_main_scores"]
        per_seed_scores = list(seed_rows.values())
        rows.append(
            {
                "canonical_id": agg["canonical_id"],
                "display_name": participant["display_name"],
                "primary_surface": participant["primary_surface"],
                "evaluation_contract_id": _normalize_mixed_list(participant["evaluation_contract_ids"])[0],
                "run_mode": "contract_aligned_replay",
                "surface_instance_ids": agg["surface_instance_ids"],
                "seed_list": agg["seed_list"],
                "seed_count": len(agg["seed_list"]),
                "run_count": len(agg["included_run_record_ids"]),
                "main_score": agg["final_main_score"],
                "main_score_mean": agg["final_main_score_mean"],
                "main_score_std": agg["final_main_score_std"],
                "main_score_sem": (agg["final_main_score_std"] / (len(per_seed_scores) ** 0.5)) if per_seed_scores else 0.0,
                "field_relative_l2_gmean": agg["final_main_score_mean"],
                "field_mse_mean": agg["field_mse_mean"],
                "field_mse_std": agg["field_mse_std"],
                "parallel_inverse_joint": agg.get("parallel_inverse_joint"),
                "parallel_main_candidate_surface": agg.get("parallel_main_candidate_surface", ""),
                "parallel_main_candidate_contract": agg.get("parallel_main_candidate_contract", ""),
                "parallel_main_candidate_score_schema": agg.get("parallel_main_candidate_score_schema", ""),
                "best_seed": agg["seed_list"][per_seed_scores.index(min(per_seed_scores))],
                "worst_seed": agg["seed_list"][per_seed_scores.index(max(per_seed_scores))],
                "aggregation_record_id": agg["aggregation_record_id"],
                "artifacts_used": agg["included_run_record_ids"],
                "validator_passed": True,
                "result_status": "success",
                "standardization_strategy": participant["standardization_strategy"],
                "fairness_adjustments": participant["fairness_adjustments"],
                "fidelity_boundary": participant["fidelity_boundary"],
                "result_ready_for_paper": True,
            }
        )
    return rows


def _quantize_variance(seed_count: int, sensitivity: float | None) -> str:
    if seed_count < 2 or sensitivity is None:
        return "insufficient_seed_coverage"
    if sensitivity < 0.05:
        return "low"
    if sensitivity < 0.15:
        return "medium"
    return "high"


def _restricted_mapping_strength(strategy: str) -> float:
    mapping = {
        "direct_surface_alignment": 0.10,
        "budget_equalized_operator_mapping": 0.35,
        "restricted_standardization": 0.55,
        "posterior_mean_standardization": 0.60,
        "weak_form_evaluation_alignment": 0.65,
        "decomposition_to_global_score_reduction": 0.70,
        "geometry_conditioned_field_mapping": 0.70,
        "inverse_to_field_mapping": 0.80,
        "multifidelity_budget_folding": 0.85,
    }
    return mapping.get(strategy, 0.50)


def _budget_equalization_strength(adjustments: list[str]) -> float:
    weights = {
        "decomposition_overhead_budgeted": 0.15,
        "interface_flux_budgeted": 0.15,
        "window_overlap_budgeted": 0.15,
        "quadrature_budget_equalized": 0.20,
        "test_function_budget_equalized": 0.20,
        "hp_partition_budget_equalized": 0.10,
        "constraint_ansatz_budgeted": 0.10,
        "posterior_sampling_collapsed_to_mean_prediction": 0.25,
        "adaptive_weight_updates_budgeted": 0.10,
        "sequence_token_budget_equalized": 0.15,
        "recurrent_state_budget_equalized": 0.15,
        "causal_schedule_budget_equalized": 0.15,
        "factorization_rank_budget_equalized": 0.10,
        "operator_sample_budget_equalized": 0.10,
        "physics_regularizer_budget_equalized": 0.15,
        "inverse_supervision_budget_equalized": 0.25,
        "operator_context_budget_equalized": 0.15,
        "geometry_context_budget_equalized": 0.20,
        "multifidelity_channel_budget_equalized": 0.30,
    }
    return min(1.0, sum(weights.get(name, 0.0) for name in set(adjustments)))


def _runtime_collapse_map(per_method_rows: list[dict[str, Any]]) -> dict[str, list[str]]:
    payload: dict[str, list[str]] = defaultdict(list)
    for row in per_method_rows:
        key = f"{row['main_score_mean']:.12f}|{row['field_mse_mean']:.12f}"
        payload[key].append(str(row["canonical_id"]))
    return payload


def _channel_risk(strategy: str) -> float:
    if strategy in {"multifidelity_budget_folding", "inverse_to_field_mapping", "geometry_conditioned_field_mapping"}:
        return 1.0
    if strategy in {"budget_equalized_operator_mapping", "weak_form_evaluation_alignment"}:
        return 0.7
    if strategy in {"decomposition_to_global_score_reduction", "posterior_mean_standardization"}:
        return 0.6
    if strategy in {"restricted_standardization"}:
        return 0.4
    return 0.2


def _source_faithful_failure_taxonomy(
    participant: dict[str, Any],
    row: dict[str, Any],
    method_seed_rows: list[dict[str, Any]],
) -> dict[str, Any]:
    fidelity_boundary = str(participant.get("fidelity_boundary") or "")
    strategy = str(row.get("standardization_strategy") or "")
    tags: list[str] = []
    source_side_confidence = "medium"

    if "source_faithful_claim_forbidden" in fidelity_boundary:
        tags.append("Source_Faithful_Claim_Disallowed")
    if "proxy" in fidelity_boundary:
        tags.append("Wrapper_Mismatch_Risk")
        source_side_confidence = "low"
    if "task_scoped" in fidelity_boundary:
        tags.append("Task_Scoped_Runtime")
    if "bounded_" in fidelity_boundary or "bounded" in fidelity_boundary:
        tags.append("Bounded_Runtime_Substitute")
    if "evidence_depth_limited" in fidelity_boundary or str(participant.get("evidence_strength")) == "weak":
        tags.append("Public_Repo_Incomplete")
    if strategy == "inverse_to_field_mapping":
        tags.append("Partial_Recovery_Only")
    if strategy == "posterior_mean_standardization":
        tags.append("Undocumented_Posterior_Collapse")
    if strategy == "weak_form_evaluation_alignment":
        tags.append("Undocumented_Quadrature_or_Test_Function_Budget")
    if strategy == "decomposition_to_global_score_reduction":
        tags.append("Undocumented_Interface_or_Subdomain_Schedule")
    if strategy == "multifidelity_budget_folding":
        tags.append("Undocumented_Multifidelity_Budget")
    if any(str(seed_row.get("run_mode")) == "validated_reuse" for seed_row in method_seed_rows):
        tags.append("Mixed_Reuse_Replay_Evidence")
        if source_side_confidence != "low":
            source_side_confidence = "medium"

    if not tags:
        tags.append("Documentation_Gap_Unspecified")

    blocker_summary = "; ".join(tags[:3])
    source_side_confidence = {
        "low": "benchmark_side_or_wrapper_risk_not_excluded",
        "medium": "source_side_more_likely_but_not_isolated",
    }.get(source_side_confidence, "source_side_likely")

    return {
        "source_faithful_failure_tags": tags,
        "source_faithful_failure_primary_tag": tags[0],
        "source_faithful_blocker_summary": blocker_summary,
        "source_faithful_gap_status": "claim_gap_not_quantified_in_real_result_chain",
        "source_vs_benchmark_failure_confidence": source_side_confidence,
    }


def _statistics_main_surface_summary(
    row: dict[str, Any],
    method_seed_rows: list[dict[str, Any]],
    runtime_cluster: list[str],
) -> dict[str, Any]:
    seed_values = [float(item["field_relative_l2"]) for item in method_seed_rows]
    if not seed_values:
        return {
            "statistics_surface_status": "missing_seed_metrics",
            "statistics_minimum_next_action": "collect_seed_metrics_before_significance_or_bootstrap",
            "tie_cluster_membership_count": len(runtime_cluster),
            "exact_tie_cluster_present": len(runtime_cluster) > 1,
        }

    return {
        "statistics_surface_status": "seed_sensitivity_only",
        "statistics_minimum_next_action": "add_significance_bootstrap_rank_stability_surface",
        "seed_metric_min": min(seed_values),
        "seed_metric_max": max(seed_values),
        "tie_cluster_membership_count": len(runtime_cluster),
        "exact_tie_cluster_present": len(runtime_cluster) > 1,
    }


def _build_fairness_audit_results(
    per_method_rows: list[dict[str, Any]],
    per_seed_rows: list[dict[str, Any]],
    budget_rows: list[dict[str, Any]],
    participants: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    budget_map: dict[str, dict[str, Any]] = {}
    for row in budget_rows:
        canonical_id = str(row["canonical_id"])
        current = budget_map.get(canonical_id)
        if current is None or float(row["budget_ledger_completeness"]) >= float(current["budget_ledger_completeness"]):
            budget_map[canonical_id] = row
    runtime_clusters = _runtime_collapse_map(per_method_rows)
    best_score = min(float(row["main_score_mean"]) for row in per_method_rows)
    grouped_surface = defaultdict(list)
    for row in per_method_rows:
        grouped_surface[row["task_name"] if "task_name" in row else row["surface_instance_ids"][0]].append(float(row["main_score_mean"]))
    rows: list[dict[str, Any]] = []
    for row in per_method_rows:
        participant = participants[str(row["canonical_id"])]
        method_seed_rows = [item for item in per_seed_rows if item["canonical_id"] == row["canonical_id"]]
        seed_values = [float(item["field_relative_l2"]) for item in method_seed_rows]
        representative_seed_row = sorted(method_seed_rows, key=lambda item: int(item["seed"]))[0]
        seed_sensitivity = None
        if len(seed_values) >= 2 and mean(seed_values) != 0:
            seed_sensitivity = abs(max(seed_values) - min(seed_values)) / mean(seed_values)
        variance_level = _quantize_variance(len(seed_values), seed_sensitivity)
        restricted_strength = _restricted_mapping_strength(str(row["standardization_strategy"]))
        budget_strength = _budget_equalization_strength(list(_normalize_mixed_list(row["fairness_adjustments"])))
        evidence_penalty = 0.0
        if participant["evidence_strength"] == "moderate":
            evidence_penalty = 0.10
        elif participant["evidence_strength"] == "weak":
            evidence_penalty = 0.20
        task_fit_penalty = 0.20 if "toy" in str(participant["task_name"]) else 0.0
        fidelity_gap_penalty = 0.10 if any(token in str(participant["fidelity_boundary"]) for token in ("proxy", "task_scoped", "bounded_")) else 0.0
        cluster_key = f"{float(row['main_score_mean']):.12f}|{float(row['field_mse_mean']):.12f}"
        runtime_cluster = sorted(runtime_clusters[cluster_key])
        runtime_collapse_penalty = 0.15 if len(runtime_cluster) > 1 else 0.0
        standardization_cost_score = min(
            1.0,
            0.45 * restricted_strength
            + 0.25 * budget_strength
            + 0.10 * evidence_penalty
            + 0.10 * task_fit_penalty
            + 0.10 * fidelity_gap_penalty
            + 0.10 * runtime_collapse_penalty,
        )
        budget_completeness = float(budget_map[str(row["canonical_id"])]["budget_ledger_completeness"])
        peer_uplift = max(0.0, (mean([float(item["main_score_mean"]) for item in per_method_rows]) - float(row["main_score_mean"])) / max(mean([float(item["main_score_mean"]) for item in per_method_rows]), 1e-8))
        residual_advantage_risk = min(
            1.0,
            0.35 * _channel_risk(str(row["standardization_strategy"]))
            + 0.20 * peer_uplift
            + 0.20 * (1.0 - budget_completeness)
            + 0.15 * evidence_penalty
            + 0.10 * task_fit_penalty,
        )
        if "decomposition" in str(row["standardization_strategy"]):
            cost_summary = "decomposition reduced to global field; interface-local semantics removed"
        elif "posterior" in str(row["standardization_strategy"]):
            cost_summary = "posterior collapsed to mean prediction; uncertainty outputs excluded"
        elif "weak_form" in str(row["standardization_strategy"]):
            cost_summary = "weak-form training folded to standardized field scoring"
        elif "inverse" in str(row["standardization_strategy"]):
            cost_summary = "inverse target collapsed to field reconstruction"
        elif "multifidelity" in str(row["standardization_strategy"]):
            cost_summary = "multifidelity channel folded into declared auxiliary budget"
        else:
            cost_summary = "standard participant mapping retained only the main-board prediction object"
        main_surface_fit = 1.0 if "toy" not in str(participant["task_name"]) else 0.0
        auxiliary_fraction = 0.0
        artifact_dir = REPO_ROOT / _normalize_mixed_list(participant["artifact_paths"])[0]
        metrics = _read_json(artifact_dir / "metrics.json")
        final_loss_terms = metrics.get("train", {}).get("final_loss_terms", {})
        if isinstance(final_loss_terms, dict) and final_loss_terms:
            total_aux = sum(float(value) for key, value in final_loss_terms.items() if key not in {"physics", "boundary", "initial", "supervision"})
            total_all = sum(float(value) for value in final_loss_terms.values())
            auxiliary_fraction = 0.0 if total_all == 0 else total_aux / total_all
        taxonomy = _source_faithful_failure_taxonomy(participant, row, method_seed_rows)
        statistics_summary = _statistics_main_surface_summary(row, method_seed_rows, runtime_cluster)
        rows.append(
            {
                "canonical_id": row["canonical_id"],
                "display_name": row["display_name"],
                "family": participants[str(row["canonical_id"])]["family"],
                "primary_surface": MAIN_SURFACE_ID,
                "evaluation_contract_id": MAIN_EVALUATION_CONTRACT_ID,
                "task_name": participants[str(row["canonical_id"])]["task_name"],
                "run_mode": "contract_aligned_replay",
                "artifact_path": representative_seed_row["artifact_dir"],
                "metrics_path": representative_seed_row["metrics_path"],
                "config_snapshot_path": representative_seed_row["config_snapshot_path"],
                "train_log_path": representative_seed_row["train_log_path"],
                "main_score": row["main_score_mean"],
                "field_mse": row["field_mse_mean"],
                "parameter_count": int(budget_map[str(row["canonical_id"])]["parameter_count_total"]),
                "duration_seconds": float(sum(item["duration_seconds"] for item in method_seed_rows) / max(len(method_seed_rows), 1)),
                "epochs": int(mean(float(item["epochs"]) for item in method_seed_rows)),
                "seed_count": row["seed_count"],
                "seed_list": row["seed_list"],
                "training_budget_contract": TRAINING_BUDGET_CONTRACT_ID,
                "data_budget_contract": DATA_BUDGET_CONTRACT_ID,
                "supervision_budget_contract": SUPERVISION_BUDGET_CONTRACT_ID,
                "budget_ledger_completeness": budget_completeness,
                "standardization_strategy": row["standardization_strategy"],
                "fairness_adjustments": row["fairness_adjustments"],
                "special_capabilities_stripped_or_budgeted": participants[str(row["canonical_id"])]["special_capabilities_stripped_or_budgeted"],
                "fidelity_boundary": row["fidelity_boundary"],
                "source_faithful_claim_allowed": participants[str(row["canonical_id"])]["source_faithful_claim_allowed"],
                "evidence_strength": participants[str(row["canonical_id"])]["evidence_strength"],
                "restricted_mapping_strength": restricted_strength,
                "budget_equalization_strength": budget_strength,
                "standardization_cost_score": standardization_cost_score,
                "suspected_standardization_cost": cost_summary,
                "seed_sensitivity": seed_sensitivity,
                "variance_level": variance_level,
                "main_surface_fit": main_surface_fit,
                "auxiliary_loss_fraction": auxiliary_fraction,
                "runtime_collapse_cluster_id": cluster_key if len(runtime_cluster) > 1 else "",
                "runtime_collapse_risk": "high" if len(runtime_cluster) > 1 else "low",
                "residual_advantage_risk": residual_advantage_risk,
                "audit_verdict": "paper_safe_with_caveats" if residual_advantage_risk < 0.75 else "requires_explicit_fairness_caveat",
                "paper_safe_summary": (
                    f"{row['display_name']} achieved main_score={row['main_score_mean']:.6f}; "
                    f"interpret under {row['standardization_strategy']} with fidelity boundary `{row['fidelity_boundary']}`."
                ),
                **taxonomy,
                **statistics_summary,
            }
        )
    return rows


def _write_markdown_table(path: Path, title: str, headers: list[str], rows: list[list[str]]) -> None:
    lines = [f"# {title}", "", "| " + " | ".join(headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"]
    for row in rows:
        lines.append("| " + " | ".join(row) + " |")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _round_df(df: pd.DataFrame) -> pd.DataFrame:
    payload = df.copy()
    for column in payload.columns:
        if pd.api.types.is_float_dtype(payload[column]):
            payload[column] = payload[column].map(lambda x: round(float(x), 6) if pd.notna(x) else x)
    return payload


def _df_to_tex(df: pd.DataFrame, path: Path, *, caption_comment: str) -> None:
    rendered = _round_df(df).to_latex(index=False, escape=True)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f"% {caption_comment}\n{rendered}".rstrip() + "\n", encoding="utf-8")


def _normal_cdf(value: float) -> float:
    return 0.5 * (1.0 + erf(value / sqrt(2.0)))


def _two_sided_power(effect_size: float, seed_count: int, alpha: float) -> float:
    if seed_count <= 0 or effect_size <= 0.0:
        return 0.0
    z_alpha = NormalDist().inv_cdf(1.0 - alpha / 2.0)
    noncentral = effect_size * sqrt(seed_count / 2.0)
    power = 1.0 - _normal_cdf(z_alpha - noncentral) + _normal_cdf(-z_alpha - noncentral)
    return max(0.0, min(1.0, power))


def _minimum_detectable_effect(seed_count: int, alpha: float, target_power: float) -> float:
    if seed_count <= 0:
        return float("nan")
    low = 0.0
    high = 3.0
    for _ in range(60):
        mid = (low + high) / 2.0
        if _two_sided_power(mid, seed_count, alpha) >= target_power:
            high = mid
        else:
            low = mid
    return high


def _write_fairness_audit_tables(audit_rows: list[dict[str, Any]]) -> None:
    top_variance = sorted(audit_rows, key=lambda item: (item["variance_level"] != "insufficient_seed_coverage", float(item["seed_sensitivity"] or 0.0)), reverse=True)[:5]
    top_cost = sorted(audit_rows, key=lambda item: float(item["standardization_cost_score"]), reverse=True)[:5]
    top_risk = sorted(audit_rows, key=lambda item: float(item["residual_advantage_risk"]), reverse=True)[:5]
    rows = [
        "## Highest Standardization Cost",
        "",
        "| Method | Cost Score | Summary |",
        "| --- | --- | --- |",
    ]
    for row in top_cost:
        rows.append(f"| `{row['canonical_id']}` | {row['standardization_cost_score']:.3f} | {row['suspected_standardization_cost']} |")
    rows.extend(["", "## Highest Residual Advantage Risk", "", "| Method | Risk | Summary |", "| --- | --- | --- |"])
    for row in top_risk:
        rows.append(f"| `{row['canonical_id']}` | {row['residual_advantage_risk']:.3f} | {row['paper_safe_summary']} |")
    rows.extend(["", "## Seed Stability", "", "| Method | Seed Count | Seed Sensitivity | Variance Level |", "| --- | --- | --- | --- |"])
    for row in top_variance:
        sensitivity = "" if row["seed_sensitivity"] is None else f"{row['seed_sensitivity']:.6f}"
        rows.append(f"| `{row['canonical_id']}` | {row['seed_count']} | {sensitivity} | {row['variance_level']} |")
    rows.extend(["", "## Runtime Collapse Clusters", "", "| Cluster | Methods |", "| --- | --- |"])
    seen = set()
    for row in audit_rows:
        cluster = str(row["runtime_collapse_cluster_id"])
        if not cluster or cluster in seen:
            continue
        seen.add(cluster)
        methods = [item["canonical_id"] for item in audit_rows if item["runtime_collapse_cluster_id"] == cluster]
        rows.append(f"| `{cluster}` | `{' | '.join(methods)}` |")
    (BENCHMARK_MODEL_ROOT / "fairness_audit_tables.md").write_text("\n".join(rows) + "\n", encoding="utf-8")


def _write_method_result_cards(per_method_rows: list[dict[str, Any]], audit_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    audit_map = {row["canonical_id"]: row for row in audit_rows}
    rows: list[dict[str, Any]] = []
    lines = ["# Method Result Cards", ""]
    for row in per_method_rows:
        audit = audit_map[row["canonical_id"]]
        rows.append(
            {
                "canonical_id": row["canonical_id"],
                "display_name": row["display_name"],
                "main_score_mean": row["main_score_mean"],
                "main_score_std": row["main_score_std"],
                "seed_count": row["seed_count"],
                "run_mode": row["run_mode"],
                "standardization_strategy": row["standardization_strategy"],
                "fairness_verdict": audit["audit_verdict"],
                "residual_advantage_risk": audit["residual_advantage_risk"],
                "fidelity_boundary": row["fidelity_boundary"],
                "source_faithful_failure_primary_tag": audit["source_faithful_failure_primary_tag"],
                "source_faithful_blocker_summary": audit["source_faithful_blocker_summary"],
                "statistics_surface_status": audit["statistics_surface_status"],
                "statistics_minimum_next_action": audit["statistics_minimum_next_action"],
                "result_ready_for_paper": row["result_ready_for_paper"],
            }
        )

        lines.append(f"## `{row['canonical_id']}`")
        lines.append(f"- main_score_mean: `{row['main_score_mean']}`")
        lines.append(f"- main_score_std: `{row['main_score_std']}`")
        lines.append(f"- seed_count: `{row['seed_count']}`")
        lines.append(f"- standardization_strategy: `{row['standardization_strategy']}`")
        lines.append(f"- fairness_verdict: `{audit['audit_verdict']}`")
        lines.append(f"- source_faithful_failure_primary_tag: `{audit['source_faithful_failure_primary_tag']}`")
        lines.append(f"- source_faithful_blocker_summary: {audit['source_faithful_blocker_summary']}")
        lines.append(f"- statistics_surface_status: `{audit['statistics_surface_status']}`")
        lines.append(f"- statistics_minimum_next_action: {audit['statistics_minimum_next_action']}")
        lines.append(f"- fidelity_boundary: {row['fidelity_boundary']}")
        lines.append("")
    _write_json(BENCHMARK_MODEL_ROOT / "method_result_cards.json", "method_result_cards.v1", rows)
    _write_csv(BENCHMARK_MODEL_ROOT / "method_result_cards.csv", rows)
    (BENCHMARK_MODEL_ROOT / "method_result_cards.md").write_text("\n".join(lines), encoding="utf-8")
    return rows


def _write_result_consistency_audit(
    board_rows: list[dict[str, Any]],
    per_seed_rows: list[dict[str, Any]],
    aggregation_rows: list[dict[str, Any]],
    audit_rows: list[dict[str, Any]],
) -> dict[str, Any]:
    seed_mode_map: dict[str, set[str]] = defaultdict(set)
    for row in per_seed_rows:
        seed_mode_map[str(row["canonical_id"])].add(str(row["run_mode"]))
    mixed_seed_run_mode_methods = sorted(
        canonical_id for canonical_id, modes in seed_mode_map.items() if len(modes) > 1
    )
    single_seed_run_mode_methods = sorted(
        canonical_id for canonical_id, modes in seed_mode_map.items() if len(modes) == 1
    )

    variance_counter = Counter(str(row["variance_level"]) for row in audit_rows)
    fairness_counter = Counter(str(row["audit_verdict"]) for row in audit_rows)
    taxonomy_counter = Counter(str(row["source_faithful_failure_primary_tag"]) for row in audit_rows)
    statistics_counter = Counter(str(row["statistics_surface_status"]) for row in audit_rows)
    high_risk_rows = _top_rows_with_ties(audit_rows, "residual_advantage_risk", top_n=5, reverse=True)
    score_tie_clusters = [
        [str(item["canonical_id"]) for item in cluster]
        for cluster in _exact_score_tie_clusters(board_rows)
    ]
    collision_clusters = _metric_collision_clusters(aggregation_rows)
    surface_instance_ids = sorted(
        {
            str(surface_id)
            for row in aggregation_rows
            for surface_id in row["surface_instance_ids"]
        }
    )
    payload = {
        "schema_version": "paper_result_consistency_audit.v1",
        "methods_expected": 20,
        "methods_observed": len(board_rows),
        "result_ready_for_paper_count": sum(bool(row["result_ready_for_paper"]) for row in board_rows),
        "seed_list": sorted({int(row["seed"]) for row in per_seed_rows}),
        "seed_count_uniform": len({int(row["seed"]) for row in rows}) == len(DEFAULT_TARGET_SEEDS) if (rows := per_seed_rows) else False,
        "seed_level_run_modes": sorted({str(row["run_mode"]) for row in per_seed_rows}),
        "board_run_modes": sorted({str(row["run_mode"]) for row in board_rows}),
        "mixed_run_mode_across_seeds_method_count": len(mixed_seed_run_mode_methods),
        "mixed_run_mode_across_seeds_methods": mixed_seed_run_mode_methods,
        "single_run_mode_across_seeds_methods": single_seed_run_mode_methods,
        "unique_surface_instance_count": len(surface_instance_ids),
        "surface_instance_ids": surface_instance_ids,
        "traceability_status": f"{sum(str(row['traceability_status']) == 'fully_traceable' for row in aggregation_rows)}/{len(aggregation_rows)}_fully_traceable",
        "validator_passed_count": sum(bool(row["validator_passed"]) for row in board_rows),
        "variance_distribution": {key: variance_counter[key] for key in ("low", "medium", "high") if key in variance_counter},
        "statistics_surface_distribution": dict(sorted(statistics_counter.items())),
        "source_faithful_primary_tag_distribution": dict(sorted(taxonomy_counter.items())),
        "fairness_verdict_distribution": dict(sorted(fairness_counter.items())),
        "high_residual_advantage_risk_methods": [str(row["canonical_id"]) for row in high_risk_rows],
        "exact_score_tie_clusters": score_tie_clusters,
        "metric_fingerprint_collision_clusters": collision_clusters,
        "source_faithful_claim_allowed_count": sum(bool(row["source_faithful_claim_allowed"]) for row in board_rows),
        "caveats": [
            "board-level and seed-level rows both use contract_aligned_replay under the official ten-seed policy",
            "serial order inside exact tie clusters must not be overinterpreted",
            "fairness remains separate from source-faithful fidelity throughout the real-result chain",
        ],
    }
    (BENCHMARK_MODEL_ROOT / "paper_result_consistency_audit.json").write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )
    md_lines = [
        "# Paper Result Consistency Audit",
        "",
        "## Coverage",
        f"- methods observed: **{payload['methods_observed']}/{payload['methods_expected']}**",
        f"- validator-passing rows: **{payload['validator_passed_count']}**",
        f"- result-ready rows: **{payload['result_ready_for_paper_count']}**",
        f"- seed list: `{ ' | '.join(str(seed) for seed in payload['seed_list']) }`",
        f"- seed-level run modes: `{' | '.join(payload['seed_level_run_modes'])}`",
        f"- board-level run modes: `{' | '.join(payload['board_run_modes'])}`",
        "",
        "## Consistency findings",
        f"- mixed seed-level run-mode methods: **{payload['mixed_run_mode_across_seeds_method_count']}**",
        f"- unique surface instances: **{payload['unique_surface_instance_count']}**",
        f"- traceability status: `{payload['traceability_status']}`",
        f"- high residual-advantage-risk methods (tie-inclusive): `{' | '.join(payload['high_residual_advantage_risk_methods'])}`",
        f"- exact score tie clusters: `{' ; '.join(' / '.join(cluster) for cluster in payload['exact_score_tie_clusters'])}`",
        f"- source-faithful primary tags: `{' | '.join(f'{key}:{value}' for key, value in payload['source_faithful_primary_tag_distribution'].items())}`",
        f"- statistics surface status: `{' | '.join(f'{key}:{value}' for key, value in payload['statistics_surface_distribution'].items())}`",
        "",
        "## Caveats",
        *[f"- {line}" for line in payload["caveats"]],
        "",
    ]
    (PAPER_ROOT / "paper_result_consistency_audit.md").write_text("\n".join(md_lines), encoding="utf-8")
    return payload


def _reproducibility_tier_from_audit(row: dict[str, Any]) -> tuple[str, str]:
    tags = set(str(tag) for tag in row.get("source_faithful_failure_tags", []) or [])
    if bool(row.get("source_faithful_claim_allowed")):
        return "R4", "strict_source_faithful_exactness"
    if "Task_Scoped_Runtime" in tags or "Wrapper_Mismatch_Risk" in tags:
        return "R1", "runnable_but_not_evaluable_under_declared_source_contract"
    if tags & {
        "Bounded_Runtime_Substitute",
        "Mixed_Reuse_Replay_Evidence",
        "Undocumented_Posterior_Collapse",
        "Undocumented_Quadrature_or_Test_Function_Budget",
        "Undocumented_Interface_or_Subdomain_Schedule",
        "Undocumented_Multifidelity_Budget",
        "Public_Repo_Incomplete",
        "Partial_Recovery_Only",
    }:
        return "R2", "metric_evaluable_but_outside_strict_source_tolerance"
    return "R3", "claim_preserving_reproduction"


def _write_contract_and_reproducibility_assets(
    *,
    participants: dict[str, dict[str, Any]],
    board_rows: list[dict[str, Any]],
    audit_rows: list[dict[str, Any]],
    budget_rows: list[dict[str, Any]],
    per_seed_rows: list[dict[str, Any]],
) -> None:
    participant_contracts = {
        row["canonical_id"]: row
        for row in load_json_rows(BENCHMARK_MODEL_ROOT / "credible_use_contracts.json")
    }
    evidence_rows = {
        row["method_id"]: row
        for row in load_json_rows(BENCHMARK_MODEL_ROOT / "method_evidence_registry.json")
    }
    board_map = {row["canonical_id"]: row for row in board_rows}
    per_seed_by_method = _groupby(per_seed_rows, "canonical_id")
    budget_by_method = _groupby(budget_rows, "canonical_id")

    method_intake_rows: list[dict[str, Any]] = []
    fairness_budget_rows: list[dict[str, Any]] = []
    reproducibility_rows: list[dict[str, Any]] = []
    taxonomy_rows: list[dict[str, Any]] = []
    taxonomy_counter: Counter[tuple[str, str]] = Counter()

    for canonical_id, participant in sorted(participants.items()):
        contract = participant_contracts[canonical_id]
        evidence = evidence_rows.get(canonical_id, {})
        board = board_map[canonical_id]
        audit = next(row for row in audit_rows if row["canonical_id"] == canonical_id)
        tier_id, tier_label = _reproducibility_tier_from_audit(audit)
        source_tags = list(audit.get("source_faithful_failure_tags", []) or [])
        method_intake_rows.append(
            {
                "canonical_id": canonical_id,
                "display_name": participant["display_name"],
                "source_reference": contract["primary_paper_or_source"],
                "source_repo_or_artifact": " | ".join(_normalize_mixed_list(contract.get("artifact_paths"))),
                "inclusion_rule": "full20_primary_method_admission",
                "runtime_used": participant["runnable_path"],
                "standardization_strategy": participant["standardization_strategy"],
                "fidelity_boundary": participant["fidelity_boundary"],
                "official_board_eligible": participant["main_fair_board_eligible"],
                "source_faithful_claim_eligible": participant["source_faithful_claim_allowed"],
                "evidence_strength": evidence.get("evidence_strength", participant["evidence_strength"]),
            }
        )

        method_budget_rows = budget_by_method[canonical_id]
        if method_budget_rows:
            exemplar = method_budget_rows[0]
            declared_fields = dict(exemplar.get("declared_budget_fields", {}))
            fairness_budget_rows.append(
                {
                    "canonical_id": canonical_id,
                    "display_name": participant["display_name"],
                    "parameter_count_total": exemplar["parameter_count_total"],
                    "epoch_count": declared_fields.get("train_epoch_cap", 0),
                    "optimizer_stage_policy": "adam_warm_start_then_quasi_newton_refinement",
                    "observation_budget": declared_fields.get("observation_budget_declared", 0),
                    "collocation_budget": declared_fields.get("collocation_budget_declared", 0),
                    "boundary_budget": declared_fields.get("boundary_budget_declared", 0),
                    "initial_budget": declared_fields.get("initial_budget_declared", 0),
                    "operator_condition_budget": declared_fields.get("operator_condition_budget_declared", 0),
                    "operator_query_budget": declared_fields.get("operator_query_budget_declared", 0),
                    "duration_seconds_mean": round(mean(float(dict(row.get("declared_budget_fields", {})).get("observed_duration_seconds", 0.0)) for row in method_budget_rows), 6),
                    "memory_peak_mb": "",
                    "train_flops": "",
                    "decomposition_metadata": " | ".join(_normalize_mixed_list(participant["fairness_adjustments"])),
                    "note": "FLOP / memory left blank unless uniformly auditable across all 20 methods.",
                }
            )

        reproducibility_rows.append(
            {
                "canonical_id": canonical_id,
                "display_name": participant["display_name"],
                "tier_id": tier_id,
                "tier_label": tier_label,
                "strict_source_faithful_exactness": tier_id == "R4",
                "claim_preserving_reproduction": tier_id in {"R3", "R4"},
                "metric_evaluable": tier_id in {"R2", "R3", "R4"},
                "runnable_status": "runnable" if per_seed_by_method.get(canonical_id) else "not_runnable",
                "failure_primary_tag": audit["source_faithful_failure_primary_tag"],
                "failure_tags": " | ".join(source_tags),
                "failure_summary": audit["source_faithful_blocker_summary"],
                "board_run_mode": board["run_mode"],
                "official_seed_count": board["seed_count"],
            }
        )
        taxonomy_counter[("primary", str(audit["source_faithful_failure_primary_tag"]))] += 1
        for tag in source_tags:
            taxonomy_counter[("tag", str(tag))] += 1

    for (kind, label), count in sorted(taxonomy_counter.items()):
        taxonomy_rows.append({"kind": kind, "label": label, "count": count})

    tier_counter = Counter(row["tier_id"] for row in reproducibility_rows)
    selected_cases = []
    preferred_methods = [
        "pinnmark.pinn.hpinn",
        "pinnmark.operator.pi_gano",
        "pinnmark.multifidelity.mf_pidnn",
    ]
    for method in preferred_methods:
        match = next((row for row in reproducibility_rows if row["canonical_id"] == method), None)
        if match is not None:
            selected_cases.append(match)

    case_lines = [
        "# Reproducibility Case Studies",
        "",
        f"- tier distribution: `{' | '.join(f'{tier}:{tier_counter[tier]}' for tier in sorted(tier_counter))}`",
        "",
    ]
    for row in selected_cases:
        case_lines.extend(
            [
                f"## `{row['canonical_id']}`",
                f"- tier: `{row['tier_id']}` ({row['tier_label']})",
                f"- primary failure tag: `{row['failure_primary_tag']}`",
                f"- failure summary: {row['failure_summary']}",
                f"- failure tags: `{row['failure_tags']}`",
                "",
            ]
        )

    claim_license_rows = [
        {
            "surface_or_object": "official_main_board",
            "claim_scope": "headline ranking claim",
            "allowed": True,
            "forbidden": "source-faithful literature ranking",
        },
        {
            "surface_or_object": "fairness_audit",
            "claim_scope": "paired interpretation / tie-cluster / variance claim",
            "allowed": True,
            "forbidden": "replacement board",
        },
        {
            "surface_or_object": "supporting_sparse_noise_joint",
            "claim_scope": "bounded supporting evidence",
            "allowed": True,
            "forbidden": "second board or universal ranking flip",
        },
        {
            "surface_or_object": "flagship_inverse_suites",
            "claim_scope": "bounded appendix-grade transfer evidence",
            "allowed": True,
            "forbidden": "main-board reranking",
        },
    ]
    contract_lines = [
        "# Benchmark Contract Table",
        "",
        f"- official seed policy: `{OFFICIAL_SEED_POLICY_ID}`",
        f"- primary surface: `{MAIN_SURFACE_ID}`",
        f"- evaluation contract: `{MAIN_EVALUATION_CONTRACT_ID}`",
        f"- main score: arithmetic mean of seed-level `field_relative_l2` over seeds `{', '.join(str(seed) for seed in DEFAULT_TARGET_SEEDS)}`",
        "- tie-cluster protocol: Holm-adjusted pairwise test + effect-size floor + bootstrap rank-band overlap",
        "- source-faithful exactness is a stricter license than standardized benchmark admissibility.",
        "",
    ]

    _write_csv(BENCHMARK_MODEL_ROOT / "method_intake_registry.csv", method_intake_rows)
    _write_json(BENCHMARK_MODEL_ROOT / "method_intake_registry.json", "method_intake_registry.v1", method_intake_rows)
    _write_markdown_table(
        BENCHMARK_MODEL_ROOT / "method_intake_registry.md",
        "Method Intake Registry",
        ["Method", "Source", "Runtime", "Strategy", "Fidelity boundary", "Official board eligible", "Source-faithful eligible"],
        [
            [
                f"`{row['canonical_id']}`",
                row["source_reference"],
                f"`{row['runtime_used']}`",
                f"`{row['standardization_strategy']}`",
                row["fidelity_boundary"],
                str(row["official_board_eligible"]),
                str(row["source_faithful_claim_eligible"]),
            ]
            for row in method_intake_rows
        ],
    )

    _write_csv(BENCHMARK_MODEL_ROOT / "fairness_budget_ledger.csv", fairness_budget_rows)
    _write_json(BENCHMARK_MODEL_ROOT / "fairness_budget_ledger.json", "fairness_budget_ledger.v1", fairness_budget_rows)
    _write_markdown_table(
        BENCHMARK_MODEL_ROOT / "fairness_budget_ledger.md",
        "Fairness Budget Ledger",
        ["Method", "Params", "Epochs", "Duration mean (s)", "Observation budget", "Collocation budget", "Note"],
        [
            [
                f"`{row['canonical_id']}`",
                str(row["parameter_count_total"]),
                str(row["epoch_count"]),
                f"{float(row['duration_seconds_mean']):.6f}",
                str(row["observation_budget"]),
                str(row["collocation_budget"]),
                row["note"],
            ]
            for row in fairness_budget_rows
        ],
    )

    _write_csv(BENCHMARK_MODEL_ROOT / "reproducibility_tier_registry.csv", reproducibility_rows)
    _write_json(BENCHMARK_MODEL_ROOT / "reproducibility_tier_registry.json", "reproducibility_tier_registry.v1", reproducibility_rows)
    _write_markdown_table(
        BENCHMARK_MODEL_ROOT / "reproducibility_tier_registry.md",
        "Reproducibility Tier Registry",
        ["Method", "Tier", "Primary tag", "Claim-preserving", "Strict exactness"],
        [
            [
                f"`{row['canonical_id']}`",
                f"`{row['tier_id']}`",
                f"`{row['failure_primary_tag']}`",
                str(row["claim_preserving_reproduction"]),
                str(row["strict_source_faithful_exactness"]),
            ]
            for row in reproducibility_rows
        ],
    )

    _write_csv(BENCHMARK_MODEL_ROOT / "reproducibility_failure_taxonomy.csv", taxonomy_rows)
    _write_json(BENCHMARK_MODEL_ROOT / "reproducibility_failure_taxonomy.json", "reproducibility_failure_taxonomy.v1", taxonomy_rows)
    _write_markdown_table(
        BENCHMARK_MODEL_ROOT / "reproducibility_failure_taxonomy.md",
        "Reproducibility Failure Taxonomy",
        ["Kind", "Label", "Count"],
        [[row["kind"], row["label"], str(row["count"])] for row in taxonomy_rows],
    )
    (PAPER_ROOT / "reproducibility_case_studies.md").write_text("\n".join(case_lines) + "\n", encoding="utf-8")

    _write_csv(BENCHMARK_MODEL_ROOT / "claim_license_matrix.csv", claim_license_rows)
    _write_markdown_table(
        BENCHMARK_MODEL_ROOT / "claim_license_matrix.md",
        "Claim License Matrix",
        ["Surface / Object", "Allowed claim", "Allowed", "Forbidden"],
        [[row["surface_or_object"], row["claim_scope"], str(row["allowed"]), row["forbidden"]] for row in claim_license_rows],
    )
    (BENCHMARK_MODEL_ROOT / "benchmark_contract_table.md").write_text("\n".join(contract_lines), encoding="utf-8")


def _write_inverse_validity_and_protocol_assets(
    *,
    board_rows: list[dict[str, Any]],
    participants: dict[str, dict[str, Any]],
) -> None:
    GENERATED_MAINTEXT_ROOT.mkdir(parents=True, exist_ok=True)
    board_map = {row["canonical_id"]: row for row in board_rows}
    bundles: list[dict[str, Any]] = []
    for canonical_id, participant in sorted(participants.items()):
        if canonical_id not in board_map:
            continue
        bundle = participant.get("parallel_inverse_joint_metric_bundle")
        if not isinstance(bundle, dict):
            bundle = _parallel_inverse_joint_fallback_metrics(canonical_id)
        if not isinstance(bundle, dict):
            continue
        bundles.append(
            {
                "canonical_id": canonical_id,
                "display_name": participant["display_name"],
                "official_board_rank": board_map[canonical_id]["rank"],
                "field_relative_l2_mean": float(board_map[canonical_id]["main_score_mean"]),
                "inverse_target_relative_error_mean": float(bundle["inverse_target_relative_error"]),
                "residual_metric_mean": float(bundle["residual_metric"]),
                "physics_violation_mean": float(bundle["residual_metric"]),
                "inverse_claim_gate": True,
                "claim_scope": "inverse_claim_gate_satisfied",
            }
        )
    field_median = median(row["field_relative_l2_mean"] for row in bundles)
    inverse_median = median(row["inverse_target_relative_error_mean"] for row in bundles)
    residual_median = median(row["residual_metric_mean"] for row in bundles)
    for row in bundles:
        row["normalized_field_component"] = row["field_relative_l2_mean"] / field_median
        row["normalized_inverse_component"] = row["inverse_target_relative_error_mean"] / inverse_median
        row["normalized_residual_component"] = row["residual_metric_mean"] / residual_median
        row["composite_inverse_audit_score"] = (
            0.4 * row["normalized_field_component"]
            + 0.4 * row["normalized_inverse_component"]
            + 0.2 * row["normalized_residual_component"]
        )
    sidecar_rows = sorted(
        bundles,
        key=lambda row: (row["composite_inverse_audit_score"], row["field_relative_l2_mean"], row["canonical_id"]),
    )
    for index, row in enumerate(sidecar_rows, start=1):
        row["composite_inverse_rank"] = index
        row["rank_delta_vs_official"] = int(row["official_board_rank"]) - index

    disagreement_rows = sorted(sidecar_rows, key=lambda row: abs(int(row["rank_delta_vs_official"])), reverse=True)
    case_lines = [
        "# Field / Parameter / Residual Disagreement Cases",
        "",
        "Methods whose field-only official rank diverges most from the inverse-validity composite audit:",
        "",
    ]
    for row in disagreement_rows[:5]:
        case_lines.extend(
            [
                f"## `{row['canonical_id']}`",
                f"- official board rank: `{row['official_board_rank']}`",
                f"- inverse-validity composite rank: `{row['composite_inverse_rank']}`",
                f"- rank delta: `{row['rank_delta_vs_official']}`",
                f"- field_relative_l2_mean: `{row['field_relative_l2_mean']:.6f}`",
                f"- inverse_target_relative_error_mean: `{row['inverse_target_relative_error_mean']:.6f}`",
                f"- residual_metric_mean: `{row['residual_metric_mean']:.6f}`",
                "",
            ]
        )

    legacy_board_path = BENCHMARK_MODEL_ROOT / "main_fair_board_real_scores_legacy_seed13_seed17.json"
    legacy_rows = load_json_rows(legacy_board_path) if legacy_board_path.exists() else []
    legacy_rank_map = {row["canonical_id"]: int(row["rank"]) for row in legacy_rows}
    sensitivity_rows: list[dict[str, Any]] = []
    for row in sidecar_rows:
        canonical_id = row["canonical_id"]
        legacy_rank = legacy_rank_map.get(canonical_id)
        sensitivity_rows.append(
            {
                "canonical_id": canonical_id,
                "display_name": row["display_name"],
                "legacy_two_seed_rank": legacy_rank,
                "official_ten_seed_rank": row["official_board_rank"],
                "inverse_validity_rank": row["composite_inverse_rank"],
                "delta_legacy_to_official": None if legacy_rank is None else int(legacy_rank) - int(row["official_board_rank"]),
                "delta_official_to_inverse_validity": int(row["official_board_rank"]) - int(row["composite_inverse_rank"]),
                "entered_top5_under_official": int(row["official_board_rank"]) <= 5,
                "entered_top5_under_inverse_validity": int(row["composite_inverse_rank"]) <= 5,
            }
        )
    top1_legacy = next((row["canonical_id"] for row in legacy_rows if int(row["rank"]) == 1), "")
    top1_official = next((row["canonical_id"] for row in board_rows if int(row["rank"]) == 1), "")
    top1_inverse = sidecar_rows[0]["canonical_id"] if sidecar_rows else ""
    protocol_summary_lines = [
        "# Protocol Sensitivity Summary",
        "",
        f"- legacy 2-seed top-1: `{top1_legacy}`" if top1_legacy else "- legacy 2-seed top-1: unavailable",
        f"- official 10-seed top-1: `{top1_official}`",
        f"- inverse-validity sidecar top-1: `{top1_inverse}`",
        f"- top-5 overlap (official vs inverse-validity): `{len(set(row['canonical_id'] for row in board_rows[:5]) & set(row['canonical_id'] for row in sidecar_rows[:5]))}/5`",
        "",
    ]

    method_intake_rows = load_json_rows(BENCHMARK_MODEL_ROOT / "method_intake_registry.json")
    family_mapping_rows = [
        {
            "canonical_id": row["canonical_id"],
            "display_name": row["display_name"],
            "family": participants[row["canonical_id"]]["family"],
            "source_reference": row["source_reference"],
            "runtime_used": row["runtime_used"],
            "standardization_strategy": row["standardization_strategy"],
            "fidelity_boundary": row["fidelity_boundary"],
        }
        for row in method_intake_rows
    ]
    method_exclusion_rows = [
        {
            "canonical_id": row["canonical_id"],
            "registry_status": "included_in_full20",
            "reason": "retained in current taxonomically representative suite",
        }
        for row in method_intake_rows
    ]
    inclusion_lines = [
        "# Method Inclusion Protocol",
        "",
        "Historical note: earlier planning drafts used broader coverage language for the candidate universe; that wording is kept only as provenance and is not the active 2026 admission rule.",
        "",
        "Current route:",
        "- The current suite uses a fixed twenty-method roster chosen to cover distinct inverse-learning families under one runnable benchmark contract.",
        "- Admission is decided at the canonical-family level; lineage, runtime substitutions, and fidelity boundaries remain explicit in the supporting registries.",
        "- A method enters the current roster only when the branch has an inverse-applicable path and a non-redundant family role under the current compute envelope.",
        "- A method may stay outside the current roster when runnable evidence, inverse-task applicability, or family-level distinctness is still missing on this branch.",
        "",
    ]
    adjudication_lines = [
        "# Adjudication Algorithm",
        "",
        "1. Admit a method only if it satisfies the benchmark contract and runnable-path requirements.",
        "2. Validate run artifacts and budget ledgers for every official seed.",
        "3. Aggregate seed-level field metrics into the official ranking score.",
        "4. Run corrected statistical auditing to determine whether pairwise gaps are separable or unresolved.",
        "5. Assign reproducibility tiers and failure taxonomies independently of ranking success.",
        "6. Assign claim licenses: ranking claim, inverse-validity claim, bounded support claim, or forbidden overread.",
        "",
    ]
    decision_flow = "\n".join(
        [
            "flowchart TD",
            "    A[Method candidate] --> B{Runnable and admissible?}",
            "    B -- no --> X[Exclude from current suite]",
            "    B -- yes --> C[Run official 10-seed contract replay]",
            "    C --> D[Aggregate field ranking score]",
            "    C --> E[Compute inverse-validity sidecar metrics]",
            "    D --> F[Corrected statistical audit]",
            "    E --> G[Inverse claim gate]",
            "    F --> H[Claim license assignment]",
            "    G --> H",
        ]
    )

    _write_csv(BENCHMARK_MODEL_ROOT / "inverse_validity_audit_registry.csv", sidecar_rows)
    _write_json(BENCHMARK_MODEL_ROOT / "inverse_validity_audit_registry.json", "inverse_validity_audit_registry.v1", sidecar_rows)
    _write_markdown_table(
        BENCHMARK_MODEL_ROOT / "inverse_validity_audit_registry.md",
        "Inverse Validity Audit Registry",
        ["Method", "Official rank", "Inverse-validity rank", "Field", "Inverse", "Residual", "Gate"],
        [
            [
                f"`{row['canonical_id']}`",
                str(row["official_board_rank"]),
                str(row["composite_inverse_rank"]),
                f"{row['field_relative_l2_mean']:.6f}",
                f"{row['inverse_target_relative_error_mean']:.6f}",
                f"{row['residual_metric_mean']:.6f}",
                str(row["inverse_claim_gate"]),
            ]
            for row in sidecar_rows
        ],
    )
    _write_csv(BENCHMARK_MODEL_ROOT / "composite_inverse_sidecar_board.csv", sidecar_rows)
    _write_json(BENCHMARK_MODEL_ROOT / "composite_inverse_sidecar_board.json", "composite_inverse_sidecar_board.v1", sidecar_rows)
    _write_markdown_table(
        BENCHMARK_MODEL_ROOT / "composite_inverse_sidecar_board.md",
        "Composite Inverse Sidecar Board",
        ["Rank", "Method", "Composite score", "Field", "Inverse", "Residual"],
        [
            [
                str(row["composite_inverse_rank"]),
                f"`{row['canonical_id']}`",
                f"{row['composite_inverse_audit_score']:.6f}",
                f"{row['field_relative_l2_mean']:.6f}",
                f"{row['inverse_target_relative_error_mean']:.6f}",
                f"{row['residual_metric_mean']:.6f}",
            ]
            for row in sidecar_rows
        ],
    )
    (PAPER_ROOT / "field_parameter_residual_disagreement_cases.md").write_text("\n".join(case_lines) + "\n", encoding="utf-8")

    _write_csv(BENCHMARK_MODEL_ROOT / "protocol_sensitivity_matrix.csv", sensitivity_rows)
    _write_markdown_table(
        BENCHMARK_MODEL_ROOT / "protocol_sensitivity_matrix.md",
        "Protocol Sensitivity Matrix",
        ["Method", "Legacy rank", "Official rank", "Inverse-validity rank", "Δ legacy→official", "Δ official→inverse"],
        [
            [
                f"`{row['canonical_id']}`",
                "" if row["legacy_two_seed_rank"] is None else str(row["legacy_two_seed_rank"]),
                str(row["official_ten_seed_rank"]),
                str(row["inverse_validity_rank"]),
                "" if row["delta_legacy_to_official"] is None else str(row["delta_legacy_to_official"]),
                str(row["delta_official_to_inverse_validity"]),
            ]
            for row in sensitivity_rows
        ],
    )
    (PAPER_ROOT / "rank_flip_summary.md").write_text("\n".join(protocol_summary_lines) + "\n", encoding="utf-8")
    (PAPER_ROOT / "claim_inflation_summary.md").write_text(
        "# Claim Inflation Summary\n\n"
        "The current paper tracks inflation by comparing the legacy 2-seed rank surface, the official 10-seed board, and the inverse-validity sidecar. Large rank deltas indicate that stronger ranking rhetoric is more fragile than the mean board alone suggests.\n",
        encoding="utf-8",
    )

    _write_csv(BENCHMARK_MODEL_ROOT / "method_exclusion_registry.csv", method_exclusion_rows)
    _write_markdown_table(
        BENCHMARK_MODEL_ROOT / "method_exclusion_registry.md",
        "Method Exclusion Registry",
        ["Method", "Registry status", "Reason"],
        [[f"`{row['canonical_id']}`", row["registry_status"], row["reason"]] for row in method_exclusion_rows],
    )
    _write_csv(BENCHMARK_MODEL_ROOT / "family_mapping_matrix.csv", family_mapping_rows)
    _write_markdown_table(
        BENCHMARK_MODEL_ROOT / "family_mapping_matrix.md",
        "Family Mapping Matrix",
        ["Method", "Family", "Source", "Runtime", "Strategy"],
        [
            [
                f"`{row['canonical_id']}`",
                row["family"],
                row["source_reference"],
                f"`{row['runtime_used']}`",
                f"`{row['standardization_strategy']}`",
            ]
            for row in family_mapping_rows
        ],
    )
    (PAPER_ROOT / "method_inclusion_protocol.md").write_text("\n".join(inclusion_lines), encoding="utf-8")
    (PAPER_ROOT / "adjudication_algorithm.md").write_text("\n".join(adjudication_lines), encoding="utf-8")
    (PAPER_ROOT / "trust_layer_decision_flow.mmd").write_text(decision_flow + "\n", encoding="utf-8")

    suites_root = PAPER_ROOT / "suites"
    cylinder = pd.read_csv(suites_root / "cylinder_wake_inverse_suite" / "tables" / "cylinder_wake_inverse_suite_endpoint_comparison_dual_metric.csv")
    darcy = pd.read_csv(suites_root / "darcy_permeability_inverse_suite" / "tables" / "darcy_permeability_inverse_suite_endpoint_comparison_dual_metric.csv")
    cylinder = cylinder.sort_values("field_relative_l2_mean").head(3)
    darcy = darcy.sort_values("field_relative_l2_mean").head(3)
    _df_to_tex(
        cylinder[["canonical_id", "field_relative_l2_mean", "inverse_target_relative_error_mean", "residual_metric_mean"]],
        GENERATED_MAINTEXT_ROOT / "cylinder_real_task_corroboration_table.tex",
        caption_comment="Main-text corroboration table for cylinder wake inverse suite",
    )
    _df_to_tex(
        darcy[["canonical_id", "field_relative_l2_mean", "inverse_target_relative_error_mean", "residual_metric_mean"]],
        GENERATED_MAINTEXT_ROOT / "darcy_real_task_corroboration_table.tex",
        caption_comment="Main-text corroboration table for darcy inverse suite",
    )
    inverse_validity_top = pd.DataFrame(sidecar_rows[:5])
    _df_to_tex(
        inverse_validity_top[["canonical_id", "official_board_rank", "composite_inverse_rank", "composite_inverse_audit_score", "inverse_target_relative_error_mean", "residual_metric_mean"]],
        GENERATED_MAINTEXT_ROOT / "inverse_validity_corroboration_table.tex",
        caption_comment="Main-text inverse-validity sidecar table",
    )

    def _suite_composite(df: pd.DataFrame) -> pd.DataFrame:
        payload = df.copy()
        field_med = float(payload["field_relative_l2_mean"].median())
        inverse_med = float(payload["inverse_target_relative_error_mean"].median())
        residual_med = float(payload["residual_metric_mean"].median())
        payload["suite_composite_score"] = (
            0.4 * payload["field_relative_l2_mean"] / field_med
            + 0.4 * payload["inverse_target_relative_error_mean"] / inverse_med
            + 0.2 * payload["residual_metric_mean"] / residual_med
        )
        payload = payload.sort_values(["suite_composite_score", "field_relative_l2_mean", "canonical_id"]).reset_index(drop=True)
        payload["suite_composite_rank"] = range(1, len(payload) + 1)
        return payload

    cylinder_full = _suite_composite(pd.read_csv(suites_root / "cylinder_wake_inverse_suite" / "tables" / "cylinder_wake_inverse_suite_endpoint_comparison_dual_metric.csv"))
    darcy_full = _suite_composite(pd.read_csv(suites_root / "darcy_permeability_inverse_suite" / "tables" / "darcy_permeability_inverse_suite_endpoint_comparison_dual_metric.csv"))

    _df_to_tex(
        darcy_full[["canonical_id", "field_relative_l2_mean", "inverse_target_relative_error_mean", "residual_metric_mean", "suite_composite_score", "suite_composite_rank"]],
        GENERATED_MAINTEXT_ROOT / "darcy_full_leaderboard_table.tex",
        caption_comment="Main-text full Darcy leaderboard table",
    )

    darcy_claim_gate = []
    sidecar_map = {row["canonical_id"]: row for row in sidecar_rows}
    for item in darcy_full.itertuples():
        sidecar = sidecar_map[item.canonical_id]
        darcy_claim_gate.append(
            {
                "canonical_id": item.canonical_id,
                "official_board_rank": sidecar["official_board_rank"],
                "inverse_validity_rank": sidecar["composite_inverse_rank"],
                "darcy_composite_rank": int(item.suite_composite_rank),
                "rank_delta_field_to_darcy": int(sidecar["official_board_rank"]) - int(item.suite_composite_rank),
                "rank_delta_inverse_to_darcy": int(sidecar["composite_inverse_rank"]) - int(item.suite_composite_rank),
            }
        )
    _df_to_tex(
        pd.DataFrame(darcy_claim_gate),
        GENERATED_MAINTEXT_ROOT / "darcy_claim_gate_table.tex",
        caption_comment="Main-text Darcy claim-gate table",
    )

    def _selector_summary(df: pd.DataFrame, suite_name: str) -> list[dict[str, Any]]:
        rank_map = {row["canonical_id"]: int(row["suite_composite_rank"]) for _, row in df.iterrows()}
        overlap_methods = sorted(set(rank_map) & set(legacy_rank_map) & set(board_map) & set(sidecar_map))
        selectors = {
            "legacy_two_seed_field": sorted(overlap_methods, key=lambda method: legacy_rank_map[method])[:3],
            "official_ten_seed_field": sorted(overlap_methods, key=lambda method: int(board_map[method]["rank"]))[:3],
            "inverse_validity_sidecar": sorted(overlap_methods, key=lambda method: int(sidecar_map[method]["composite_inverse_rank"]))[:3],
        }
        rows: list[dict[str, Any]] = []
        for name, methods in selectors.items():
            rows.append(
                {
                    "suite_name": suite_name,
                    "selector": name,
                    "selected_methods": " | ".join(methods),
                    "mean_suite_rank": round(mean(rank_map[method] for method in methods), 6),
                    "best_suite_rank": min(rank_map[method] for method in methods),
                    "worst_suite_rank": max(rank_map[method] for method in methods),
                }
            )
        return rows

    model_selection_rows = _selector_summary(cylinder_full, "cylinder_wake_inverse_suite") + _selector_summary(darcy_full, "darcy_permeability_inverse_suite")
    _write_csv(BENCHMARK_MODEL_ROOT / "model_selection_utility_table.csv", model_selection_rows)
    _write_markdown_table(
        BENCHMARK_MODEL_ROOT / "model_selection_utility_table.md",
        "Model Selection Utility Table",
        ["Suite", "Selector", "Selected methods", "Mean suite rank", "Best", "Worst"],
        [
            [
                row["suite_name"],
                row["selector"],
                row["selected_methods"],
                f"{row['mean_suite_rank']:.6f}",
                str(row["best_suite_rank"]),
                str(row["worst_suite_rank"]),
            ]
            for row in model_selection_rows
        ],
    )

    claim_surface_rows: list[dict[str, Any]] = []
    cylinder_rank_map = {row["canonical_id"]: int(row["suite_composite_rank"]) for _, row in cylinder_full.iterrows()}
    darcy_rank_map = {row["canonical_id"]: int(row["suite_composite_rank"]) for _, row in darcy_full.iterrows()}
    for row in sidecar_rows:
        claim_surface_rows.append(
            {
                "canonical_id": row["canonical_id"],
                "official_field_rank": row["official_board_rank"],
                "inverse_validity_rank": row["composite_inverse_rank"],
                "cylinder_suite_rank": cylinder_rank_map.get(row["canonical_id"], ""),
                "darcy_suite_rank": darcy_rank_map.get(row["canonical_id"], ""),
            }
        )
    _write_csv(BENCHMARK_MODEL_ROOT / "claim_surface_sensitivity.csv", claim_surface_rows)
    _write_markdown_table(
        BENCHMARK_MODEL_ROOT / "claim_surface_sensitivity.md",
        "Claim Surface Sensitivity",
        ["Method", "Official field rank", "Inverse-validity rank", "Cylinder rank", "Darcy rank"],
        [
            [
                f"`{row['canonical_id']}`",
                str(row["official_field_rank"]),
                str(row["inverse_validity_rank"]),
                str(row["cylinder_suite_rank"]),
                str(row["darcy_suite_rank"]),
            ]
            for row in claim_surface_rows
        ],
    )

    _write_csv(
        BENCHMARK_MODEL_ROOT / "seed_policy_sensitivity.csv",
        [
            {
                "canonical_id": row["canonical_id"],
                "legacy_two_seed_rank": row["legacy_two_seed_rank"],
                "official_ten_seed_rank": row["official_ten_seed_rank"],
                "delta_legacy_to_official": row["delta_legacy_to_official"],
                "entered_top5_under_official": row["entered_top5_under_official"],
            }
            for row in sensitivity_rows
        ],
    )
    _write_markdown_table(
        BENCHMARK_MODEL_ROOT / "seed_policy_sensitivity.md",
        "Seed Policy Sensitivity",
        ["Method", "Legacy rank", "Official rank", "Δ legacy→official", "Official top-5"],
        [
            [
                f"`{row['canonical_id']}`",
                "" if row["legacy_two_seed_rank"] is None else str(row["legacy_two_seed_rank"]),
                str(row["official_ten_seed_rank"]),
                "" if row["delta_legacy_to_official"] is None else str(row["delta_legacy_to_official"]),
                str(row["entered_top5_under_official"]),
            ]
            for row in sensitivity_rows
        ],
    )

    protocol_value_lines = [
        "# Protocol Value Summary",
        "",
        "The sidecar and real-task corroboration assets are useful only if they improve decision quality relative to the legacy or field-only board surfaces.",
        "",
    ]
    for suite_name in ["cylinder_wake_inverse_suite", "darcy_permeability_inverse_suite"]:
        subset = [row for row in model_selection_rows if row["suite_name"] == suite_name]
        best = min(subset, key=lambda row: row["mean_suite_rank"])
        protocol_value_lines.append(
            f"- `{suite_name}`: best selector is `{best['selector']}` with mean suite rank `{best['mean_suite_rank']:.3f}`."
        )
    (PAPER_ROOT / "protocol_value_summary.md").write_text("\n".join(protocol_value_lines) + "\n", encoding="utf-8")

    darcy_maintext_lines = [
        "# Darcy Main-Text Result",
        "",
        "Darcy is the strongest modern inverse flagship for exposing field-vs-inverse disagreement because it is data-backed, latent-field, and directly parameterized in the prediction object.",
        "",
        "## Full leaderboard",
        "",
        "| Method | Darcy rank | Field | Inverse | Residual |",
        "| --- | --- | --- | --- | --- |",
    ]
    for row in darcy_full.itertuples():
        darcy_maintext_lines.append(
            f"| `{row.canonical_id}` | {row.suite_composite_rank} | {row.field_relative_l2_mean:.6f} | {row.inverse_target_relative_error_mean:.6f} | {row.residual_metric_mean:.6f} |"
        )
    darcy_maintext_lines.extend(["", "## Claim-gate comparison", "", "| Method | Official rank | Inverse-validity rank | Darcy rank | Δ field→Darcy | Δ inverse→Darcy |", "| --- | --- | --- | --- | --- | --- |"])
    for row in darcy_claim_gate:
        darcy_maintext_lines.append(
            f"| `{row['canonical_id']}` | {row['official_board_rank']} | {row['inverse_validity_rank']} | {row['darcy_composite_rank']} | {row['rank_delta_field_to_darcy']} | {row['rank_delta_inverse_to_darcy']} |"
        )
    darcy_maintext_lines.append("")
    (PAPER_ROOT / "darcy_maintext_result.md").write_text("\n".join(darcy_maintext_lines) + "\n", encoding="utf-8")

    darcy_case = max(darcy_claim_gate, key=lambda row: abs(int(row["rank_delta_field_to_darcy"])))
    (PAPER_ROOT / "darcy_case_study.md").write_text(
        "# Darcy Case Study\n\n"
        f"The clearest field-vs-Darcy mismatch is `{darcy_case['canonical_id']}`: official board rank `{darcy_case['official_board_rank']}`, "
        f"inverse-validity rank `{darcy_case['inverse_validity_rank']}`, and Darcy suite rank `{darcy_case['darcy_composite_rank']}`.\n",
        encoding="utf-8",
    )

    (PAPER_ROOT / "theory_claim_gate_formalization.md").write_text(
        "# Claim Gate Formalization\n\n"
        "The benchmark distinguishes between a ranking object and a claim object. The official board supplies the ranking object. "
        "Inverse-specific scientific language is licensed only when the inverse-validity sidecar supplies a compatible parameter / residual interpretation layer. "
        "A field-strong row without inverse-validity support remains a ranking row, not an inverse-success claim.\n",
        encoding="utf-8",
    )
    (PAPER_ROOT / "bounded_robustness_vs_license.md").write_text(
        "# Bounded Robustness vs Evaluation License\n\n"
        "The current benchmark shows that bounded degradation on sparse/noisy surfaces and strong evaluation license are orthogonal. "
        "A method may stay bounded on the current synthetic stress surfaces and still fail to earn a strong inverse or source-faithful claim license.\n",
        encoding="utf-8",
    )


def _write_paper_results(
    board_rows: list[dict[str, Any]],
    per_seed_rows: list[dict[str, Any]],
    aggregation_rows: list[dict[str, Any]],
    audit_rows: list[dict[str, Any]],
    summary: dict[str, Any],
) -> None:
    GENERATED_MAINTEXT_ROOT.mkdir(parents=True, exist_ok=True)
    headline_rows = _top_rows_with_ties(board_rows, "main_score_mean", top_n=5, reverse=False)
    top_methods = [str(row["canonical_id"]) for row in headline_rows]
    top_three = board_rows[:3]
    high_risk_rows = _top_rows_with_ties(audit_rows, "residual_advantage_risk", top_n=5, reverse=True)
    high_risk = [str(row["canonical_id"]) for row in high_risk_rows]
    standardization_rows = _top_rows_with_ties(audit_rows, "standardization_cost_score", top_n=5, reverse=True)
    standardization_burden = [str(row["canonical_id"]) for row in standardization_rows]
    tie_clusters = _exact_score_tie_clusters(board_rows)
    collision_clusters = _metric_collision_clusters(aggregation_rows)
    surface_leaders: dict[str, dict[str, Any]] = {}
    for row in board_rows:
        surface_id = str(row["selected_surface_instance"])
        incumbent = surface_leaders.get(surface_id)
        if incumbent is None or float(row["main_score_mean"]) < float(incumbent["main_score_mean"]):
            surface_leaders[surface_id] = row
    surface_leader_text = " | ".join(
        f"{surface_id}: {surface_leaders[surface_id]['canonical_id']}"
        for surface_id in sorted(surface_leaders)
    )
    variance_counter = Counter(str(row["variance_level"]) for row in audit_rows)
    supporting_suite_specs = (
        ("E2", PAPER_ROOT / "experiments" / "E2_sparse_observation_full20" / "coverage_status.json"),
        ("E3", PAPER_ROOT / "experiments" / "E3_noisy_observation_full20" / "coverage_status.json"),
        ("E4", PAPER_ROOT / "experiments" / "E4_local_sparse_noise_full20" / "coverage_status.json"),
    )
    supporting_suite_summary_parts: list[str] = []
    for label, path in supporting_suite_specs:
        if path.exists():
            payload = _read_json(path)
            covered = int(payload.get("canonical_method_covered_count", 0))
            total = int(payload.get("canonical_method_total", 20))
            supporting_suite_summary_parts.append(f"{label} `{covered}/{total}`")
        else:
            supporting_suite_summary_parts.append(f"{label} `missing`")
    supporting_suite_summary = ", ".join(supporting_suite_summary_parts)
    results_draft = [
        "# Paper Results Draft",
        "",
        "## Purpose",
        "Report the real main-board results derived from executed or protocol-validated run records under the current fair-board protocol.",
        "",
        "## Protocol anchor",
        f"- main surface: `{MAIN_SURFACE_ID}`",
        f"- evaluation contract: `{MAIN_EVALUATION_CONTRACT_ID}`",
        "- main scores are aggregated from seed-level `field_relative_l2` records via `score_aggregation_records`.",
        "",
        "## Experimental coverage",
        f"- methods covered: **{summary['methods_total']}/20**",
        f"- seeds per method: **{', '.join(str(seed) for seed in summary['seed_list'])}**",
        f"- seed-level evidence run modes present: `{' | '.join(summary['seed_level_run_modes'])}`",
        f"- board-level reported run mode: `{' | '.join(summary['board_run_modes'])}`",
        f"- unique surface instances: **{summary['surface_instance_count']}**",
        f"- surface instances: `{' | '.join(summary['surface_instance_ids'])}`",
        "",
        "## Main board results",
        "Using the arithmetic mean of seed-level `field_relative_l2` as the main score (lower is better), "
        f"`{top_three[0]['canonical_id']}` ranks first at **{_format_mean_std(top_three[0])}**, "
        f"followed by `{top_three[1]['canonical_id']}` at **{_format_mean_std(top_three[1])}** and "
        f"`{top_three[2]['canonical_id']}` at **{_format_mean_std(top_three[2])}**.",
        *( 
            [
                f"The next exact tie cluster spans ranks {min(int(item['rank']) for item in cluster)}-{max(int(item['rank']) for item in cluster)}: "
                f"`{'`, `'.join(str(item['canonical_id']) for item in cluster)}` all score **{_format_mean_std(cluster[0])}**."
                for cluster in tie_clusters
            ]
        ),
        "All twenty methods contribute validator-passing, paper-ready, fully traceable protocol results, but the ranking should be read as a standardized participant comparison rather than a single-task leaderboard or a source-faithful literature ranking.",
        f"Per-surface leaders under the selected instances are: `{surface_leader_text}`.",
        "",
        "## Primary findings",
        f"- best-performing methods on the current protocol (tie-inclusive at the top-five threshold): `{' | '.join(top_methods)}`",
        f"- fairness-audit highest-risk methods: `{' | '.join(high_risk)}`",
        f"- variance distribution across the audit: `low={variance_counter.get('low', 0)} | medium={variance_counter.get('medium', 0)} | high={variance_counter.get('high', 0)}`",
        "- seed-level variance is reported directly from run-backed aggregation records rather than inferred from eligibility metadata.",
        "- serial order inside exact tie clusters should not be overinterpreted.",
        "",
        "## Supporting suite synchronization",
        "- full20 supporting evidence now closes the canonical participant layer for the main supporting suites.",
        f"- {supporting_suite_summary} all point to real canonical supporting rows rather than partial or tranche-only coverage.",
        "- these supporting rows deepen bounded interpretation around sparsity, noise, and local sparse-noise behavior, but they do not create a second board or override the main-result ordering surface.",
        "",
        "## Boundary on interpretation",
        "Fair-board ranking reflects standardized benchmark participants under one protocol and should not be read as a source-faithful literature ranking.",
        "",
        "## Limitations",
        "- current protocol still spans three task-instance clusters (`heat1d`, `toy`, `burgers1d_operator_rollout`); the fair board is therefore a protocol-level comparison rather than a single-task leaderboard.",
        "- board-level rows and seed-level evidence both use `contract_aligned_replay` under the official ten-seed policy.",
        "- methods backed only by `toy` evidence remain clearly marked in the fairness audit.",
        "- fairness eligibility and fidelity remain separate fields throughout, and 20/20 rows still have `source_faithful_claim_allowed=false`.",
    ]
    (PAPER_ROOT / "paper_results_draft.md").write_text("\n".join(results_draft) + "\n", encoding="utf-8")

    table_headers = ["Rank", "Method", "Main score mean", "Main score std", "Seed count", "Run mode", "Standardization strategy", "Fairness verdict", "Fidelity boundary"]
    table_rows = []
    audit_map = {row["canonical_id"]: row for row in audit_rows}
    for rank, row in enumerate(board_rows, start=1):
        audit = audit_map[row["canonical_id"]]
        table_rows.append(
            [
                str(rank),
                f"`{row['canonical_id']}`",
                f"{float(row['main_score_mean']):.6f}",
                f"{float(row['main_score_std']):.6f}",
                str(row["seed_count"]),
                str(row["run_mode"]),
                f"`{row['standardization_strategy']}`",
                f"`{audit['audit_verdict']}`",
                str(row["fidelity_boundary"]),
            ]
        )
    _write_markdown_table(PAPER_ROOT / "paper_main_results_table.md", "Paper Main Results Table", table_headers, table_rows)
    table_note = [
        "",
        "## Table note",
        "*Scores are the arithmetic mean of seed-level `field_relative_l2` over the official ten-seed set (0--9); lower is better. "
        "All board rows are `contract_aligned_replay`, validator-passing, paper-ready, and fully traceable under "
        f"`{MAIN_SURFACE_ID}` / `{MAIN_EVALUATION_CONTRACT_ID}`. The current board uses one selected surface instance per method across "
        f"`{'`, `'.join(summary['surface_instance_ids'])}`. Exact score ties occur for "
        f"`{'` / `'.join(str(item['canonical_id']) for item in tie_clusters[0])}`"
        + (
            f", and for `{'` / `'.join(str(item['canonical_id']) for item in tie_clusters[1])}`"
            if len(tie_clusters) > 1
            else ""
        )
        + ". Serial order inside these tie clusters should not be overinterpreted. The table reports standardized benchmark participants, not source-faithful literature claims.*",
        "",
    ]
    table_path = PAPER_ROOT / "paper_main_results_table.md"
    table_path.write_text(table_path.read_text(encoding="utf-8") + "\n".join(table_note), encoding="utf-8")
    appendix_table_df = pd.DataFrame(
        [
            {
                "Rank": row["rank"],
                "Canonical ID": row["canonical_id"],
                "Display Name": row["display_name"],
                "Main Score Mean": row["main_score_mean"],
                "Main Score Std": row["main_score_std"],
                "Run Mode": row["run_mode"],
                "Evidence Strength": row["evidence_strength"],
                "Source-Faithful Allowed": row["source_faithful_claim_allowed"],
            }
            for row in board_rows
        ]
    )
    _df_to_tex(
        appendix_table_df,
        GENERATED_MAINTEXT_ROOT / "official_main_board_appendix_table.tex",
        caption_comment="Auto-generated appendix table for the official 10-seed main board",
    )

    fairness_lines = [
        "# Paper Fairness Audit Section",
        "",
        "## Audit scope",
        "The fairness audit reads real per-seed metrics, aggregation records, and budget-enforcement logs rather than eligibility prose.",
        "",
        "## Key conclusions",
        f"- 20/20 rows are `paper_safe_with_caveats`, validator-passing, and result-ready for paper under the current protocol.",
        f"- highest residual-advantage-risk methods (tie-inclusive): `{' | '.join(high_risk)}`",
        f"- strongest standardization burden methods (tie-inclusive): `{' | '.join(standardization_burden)}`",
        f"- variance distribution: `low={variance_counter.get('low', 0)} | medium={variance_counter.get('medium', 0)} | high={variance_counter.get('high', 0)}`",
        f"- runtime-collapse / metric-collision clusters: `{' ; '.join(' / '.join(cluster) for cluster in collision_clusters)}`",
        "- fairness remains separate from fidelity: all 20 methods stay non-source-faithful claims on this board.",
    ]
    (PAPER_ROOT / "paper_fairness_audit_section.md").write_text("\n".join(fairness_lines) + "\n", encoding="utf-8")

    groups = {
        "architecture-family": [
            "pinnmark.pinn.hpinn",
            "pinnmark.pinn.b_pinn",
            "pinnmark.pinn.sa_pinn",
            "pinnmark.pinn.piratenets",
            "pinnmark.pinn.pinnsformer",
            "pinnmark.pinn.piann",
            "pinnmark.pinn.spinn",
            "pinnmark.pinn.causal_sweeping",
        ],
        "decomposition-weak-form": [
            "pinnmark.pinn.cpinn",
            "pinnmark.hybrid.fbpinn",
            "pinnmark.pinn.vpinn",
            "pinnmark.pinn.hp_vpinn",
            "pinnmark.operator.vino",
        ],
        "operator-family": [
            "pinnmark.operator.fno",
            "pinnmark.operator.deeponet",
            "pinnmark.operator.pino",
            "pinnmark.operator.pi_deeponet",
        ],
        "inverse-geometry-multifidelity": [
            "pinnmark.operator.pi_dion",
            "pinnmark.operator.pi_gano",
            "pinnmark.multifidelity.mf_pidnn",
        ],
    }
    board_map = {row["canonical_id"]: row for row in board_rows}
    method_group_lines = ["# Paper Method Group Analysis", ""]
    for label, ids in groups.items():
        method_group_lines.append(f"## {label}")
        ranked = [board_map[item] for item in ids if item in board_map]
        if ranked:
            best = min(ranked, key=lambda item: float(item["main_score_mean"]))
            worst = max(ranked, key=lambda item: float(item["main_score_mean"]))
            method_group_lines.append(f"- best protocol score in this group: `{best['canonical_id']}` ({best['main_score_mean']:.6f})")
            method_group_lines.append(f"- worst protocol score in this group: `{worst['canonical_id']}` ({worst['main_score_mean']:.6f})")
            method_group_lines.append("- the main board only measures the standardized field object for this group; richer method-specific capabilities stay supplementary.")
        method_group_lines.append("")
    (PAPER_ROOT / "paper_method_group_analysis.md").write_text("\n".join(method_group_lines), encoding="utf-8")

    limitation_lines = [
        "# Paper Limitations And Boundary Language",
        "",
        "- real board scores are protocol-level results under the current fair-board surface and contract, not source-faithful literature rankings.",
        "- one main-result board only: supporting suites, stress slices, and archival overlays do not become an alternative ranking surface merely because they are fully materialized.",
        "- restricted mappings and budget equalizations are disclosed method by method and must be read together with the ranking.",
        "- toy-backed evidence remains explicitly flagged in the fairness audit rather than hidden in the ranking.",
        "- exact score tie clusters limit fine-grained interpretation among some methods.",
        "- source-faithful fidelity remains separate from fair-board eligibility, and 20/20 rows still keep `source_faithful_claim_allowed=false`.",
    ]
    if tie_clusters:
        limitation_lines.append(
            "- exact tie ranges in the current board: "
            + "; ".join(
                f"ranks {min(int(item['rank']) for item in cluster)}-{max(int(item['rank']) for item in cluster)}"
                for cluster in tie_clusters
            )
            + "."
        )
    (PAPER_ROOT / "paper_limitations_and_boundary_language.md").write_text("\n".join(limitation_lines) + "\n", encoding="utf-8")

    appendix_lines = ["# Paper Appendix Result Cards", ""]
    for row in board_rows:
        appendix_lines.append(f"## `{row['canonical_id']}`")
        appendix_lines.append(f"- main_score_mean: `{row['main_score_mean']:.6f}`")
        appendix_lines.append(f"- main_score_std: `{row['main_score_std']:.6f}`")
        appendix_lines.append(f"- run_mode: `{row['run_mode']}`")
        appendix_lines.append(f"- selected_surface_instance: `{row['selected_surface_instance']}`")
        appendix_lines.append(f"- standardization_strategy: `{row['standardization_strategy']}`")
        appendix_lines.append(f"- fidelity_boundary: {row['fidelity_boundary']}")
        appendix_lines.append("")
    (PAPER_ROOT / "paper_appendix_result_cards.md").write_text("\n".join(appendix_lines), encoding="utf-8")


def write_real_fair_board_results(*, execute_replays: bool = True) -> dict[str, Any]:
    BENCHMARK_RUN_ROOT.mkdir(parents=True, exist_ok=True)
    BENCHMARK_MODEL_ROOT.mkdir(parents=True, exist_ok=True)
    PAPER_ROOT.mkdir(parents=True, exist_ok=True)
    TMP_CONFIG_ROOT.mkdir(parents=True, exist_ok=True)
    REPLAY_ROOT.mkdir(parents=True, exist_ok=True)
    _archive_legacy_real_result_chain()

    write_fair_board_artifacts(REPO_ROOT)
    participants = _selected_participants()
    manifest_rows, ledger_rows, failure_rows = _run_ledgers_from_plan(execute_replays=execute_replays)
    budget_rows = _build_budget_log(ledger_rows, participants)
    per_seed_rows, updated_ledger = _build_per_seed_metrics(ledger_rows, budget_rows, participants)
    aggregation_rows = _build_aggregation_records(per_seed_rows, failure_rows, participants)
    per_method_rows = _build_per_method_metrics(aggregation_rows, participants)
    audit_rows = _build_fairness_audit_results(per_method_rows, per_seed_rows, budget_rows, participants)

    parallel_inverse_board_rows = []
    for row in sorted(
        [item for item in per_method_rows if isinstance(item.get("parallel_inverse_joint"), dict)],
        key=lambda item: (
            not bool(item["parallel_inverse_joint"].get("result_ready_for_parallel_reporting")),
            float(item["parallel_inverse_joint"]["joint_inverse_main_score_mean"])
            if item["parallel_inverse_joint"].get("joint_inverse_main_score_mean") is not None
            else float("inf"),
            str(item["canonical_id"]),
        ),
    ):
        parallel = row["parallel_inverse_joint"]
        parallel_inverse_board_rows.append(
            {
                "canonical_id": row["canonical_id"],
                "display_name": row["display_name"],
                "board_family": parallel["board_family"],
                "board_id": parallel["board_id"],
                "board_status": parallel["board_status"],
                "legacy_main_board_compatible": parallel["legacy_main_board_compatible"],
                "legacy_main_board_preserved": parallel["legacy_main_board_preserved"],
                "parallel_surface_id": parallel["parallel_surface_id"],
                "parallel_evaluation_contract_id": parallel["parallel_evaluation_contract_id"],
                "parallel_score_schema_id": parallel["parallel_score_schema_id"],
                "score_components": parallel["score_components"],
                "component_score_directions": parallel["component_score_directions"],
                "seed_list": parallel["seed_list"],
                "seed_count": parallel["seed_count"],
                "seed_run_modes": parallel["seed_run_modes"],
                "seed_provenance": parallel["seed_provenance"],
                "joint_inverse_main_score_mean": parallel["joint_inverse_main_score_mean"],
                "joint_inverse_main_score_std": parallel["joint_inverse_main_score_std"],
                "field_relative_l2_mean": parallel["field_relative_l2_mean"],
                "inverse_target_relative_error_mean": parallel["inverse_target_relative_error_mean"],
                "residual_metric_mean": parallel["residual_metric_mean"],
                "component_metrics": parallel["component_metrics"],
                "parallel_validator_passed": parallel["parallel_validator_passed"],
                "result_ready_for_parallel_reporting": parallel["result_ready_for_parallel_reporting"],
                "missing_required_metrics": parallel["missing_required_metrics"],
                "disqualification_reason": parallel["disqualification_reason"],
                "aggregation_provenance": parallel["aggregation_provenance"],
                "legacy_aggregation_record_id": row["aggregation_record_id"],
                "legacy_primary_surface": row["primary_surface"],
                "status": "parallel_candidate_only",
            }
        )
    for index, row in enumerate(parallel_inverse_board_rows, start=1):
        row["parallel_rank"] = index

    audit_map = {row["canonical_id"]: row for row in audit_rows}
    main_board_rows = []
    for row in sorted(
        per_method_rows,
        key=lambda item: (
            float(item["main_score_mean"]),
            float(item["main_score_std"]),
            float(item["field_mse_mean"]),
            str(item["canonical_id"]),
        ),
    ):
        audit = audit_map[row["canonical_id"]]
        main_board_rows.append(
            {
                "canonical_id": row["canonical_id"],
                "display_name": row["display_name"],
                "primary_surface": row["primary_surface"],
                "evaluation_contract_id": row["evaluation_contract_id"],
                "run_mode": row["run_mode"],
                "seed_count": row["seed_count"],
                "surface_instance_ids": row["surface_instance_ids"],
                "selected_surface_instance": row["surface_instance_ids"][0] if row["surface_instance_ids"] else "",
                "training_budget_contract": TRAINING_BUDGET_CONTRACT_ID,
                "data_budget_contract": DATA_BUDGET_CONTRACT_ID,
                "supervision_budget_contract": SUPERVISION_BUDGET_CONTRACT_ID,
                "main_score": row["main_score_mean"],
                "main_score_mean": row["main_score_mean"],
                "main_score_std": row["main_score_std"],
                "auxiliary_scores": {"field_mse_mean": row["field_mse_mean"], "field_mse_std": row["field_mse_std"]},
                "metric_bundle": {"field_relative_l2_mean": row["main_score_mean"], "field_mse_mean": row["field_mse_mean"]},
                "aggregation_rule": "mean_and_std_over_seed_level_field_relative_l2",
                "fairness_adjustments": row["fairness_adjustments"],
                "standardization_strategy": row["standardization_strategy"],
                "validator_passed": True,
                "result_ready_for_paper": row["result_ready_for_paper"],
                "evidence_strength": participants[row["canonical_id"]]["evidence_strength"],
                "source_faithful_claim_allowed": participants[row["canonical_id"]]["source_faithful_claim_allowed"],
                "aggregation_record_id": row["aggregation_record_id"],
                "fidelity_boundary": row["fidelity_boundary"],
                "audit_verdict": audit["audit_verdict"],
                "parallel_main_candidate_surface": row.get("parallel_main_candidate_surface", ""),
                "parallel_main_candidate_contract": row.get("parallel_main_candidate_contract", ""),
                "parallel_main_candidate_score_schema": row.get("parallel_main_candidate_score_schema", ""),
            }
        )
    for index, row in enumerate(main_board_rows, start=1):
        row["rank"] = index

    surface_rows = []
    seen_surface_ids = set()
    for row in updated_ledger:
        if row["surface_instance_id"] in seen_surface_ids:
            continue
        seen_surface_ids.add(row["surface_instance_id"])
        metrics, config, _ = _collect_run_artifact_metrics(str(row["output_dir"]))
        surface_rows.append(
            {
                "surface_instance_id": row["surface_instance_id"],
                "primary_surface": MAIN_SURFACE_ID,
                "task_name": metrics.get("metadata", {}).get("task_name"),
                "evaluation_mode": metrics.get("metadata", {}).get("evaluation_mode"),
                "task_config": config.get("task"),
                "instance_artifact_path": row["output_dir"],
                "method_count": len([item for item in updated_ledger if item["surface_instance_id"] == row["surface_instance_id"]]),
            }
        )

    method_cards = _write_method_result_cards(per_method_rows, audit_rows)
    seed_level_run_modes = sorted({str(row["run_mode"]) for row in per_seed_rows})
    board_run_modes = sorted({str(row["run_mode"]) for row in main_board_rows})
    surface_instance_ids = sorted({str(row["selected_surface_instance"]) for row in main_board_rows})
    summary = {
        "methods_total": len(main_board_rows),
        "run_record_total": len(updated_ledger),
        "seed_policy": OFFICIAL_SEED_POLICY_ID,
        "seed_list": sorted({int(row["seed"]) for row in per_seed_rows}),
        "surface_instance_count": len(surface_rows),
        "surface_instance_ids": surface_instance_ids,
        "seed_level_run_modes": seed_level_run_modes,
        "board_run_modes": board_run_modes,
        "top_methods": [row["canonical_id"] for row in _top_rows_with_ties(main_board_rows, "main_score_mean", top_n=5, reverse=False)],
        "highest_risk_methods": [row["canonical_id"] for row in _top_rows_with_ties(audit_rows, "residual_advantage_risk", top_n=5, reverse=True)],
    }
    consistency_audit = _write_result_consistency_audit(main_board_rows, per_seed_rows, aggregation_rows, audit_rows)

    _write_csv(BENCHMARK_RUN_ROOT / "main_fair_board_run_manifest.csv", manifest_rows)
    _write_json(BENCHMARK_RUN_ROOT / "main_fair_board_run_manifest.json", "main_fair_board_run_manifest.v1", manifest_rows)
    _write_csv(BENCHMARK_RUN_ROOT / "main_fair_board_run_ledger.csv", updated_ledger)
    _write_json(BENCHMARK_RUN_ROOT / "main_fair_board_run_ledger.json", "main_fair_board_run_ledger.v1", updated_ledger)
    _write_csv(BENCHMARK_RUN_ROOT / "budget_enforcement_log.csv", budget_rows)
    _write_json(BENCHMARK_RUN_ROOT / "budget_enforcement_log.json", "budget_enforcement_log.v1", budget_rows)
    _write_csv(BENCHMARK_RUN_ROOT / "per_method_metrics.csv", per_method_rows)
    _write_json(BENCHMARK_RUN_ROOT / "per_method_metrics.json", "per_method_metrics.v1", per_method_rows)
    _write_csv(BENCHMARK_RUN_ROOT / "per_seed_metrics.csv", per_seed_rows)
    _write_json(BENCHMARK_RUN_ROOT / "per_seed_metrics.json", "per_seed_metrics.v1", per_seed_rows)
    _write_csv(BENCHMARK_RUN_ROOT / "score_aggregation_records.csv", aggregation_rows)
    _write_json(BENCHMARK_RUN_ROOT / "score_aggregation_records.json", "score_aggregation_records.v1", aggregation_rows)
    _write_csv(BENCHMARK_RUN_ROOT / "run_failure_and_recovery_log.csv", failure_rows)
    _write_json(BENCHMARK_RUN_ROOT / "run_failure_and_recovery_log.json", "run_failure_and_recovery_log.v1", failure_rows)
    _write_csv(BENCHMARK_RUN_ROOT / "surface_instance_registry.csv", surface_rows)
    _write_json(BENCHMARK_RUN_ROOT / "surface_instance_registry.json", "surface_instance_registry.v1", surface_rows)

    _write_csv(BENCHMARK_MODEL_ROOT / "parallel_inverse_joint_board.csv", parallel_inverse_board_rows)
    _write_json(BENCHMARK_MODEL_ROOT / "parallel_inverse_joint_board.json", "parallel_inverse_joint_board.v1", parallel_inverse_board_rows)
    _write_markdown_table(
        BENCHMARK_MODEL_ROOT / "parallel_inverse_joint_board.md",
        "Parallel Inverse Joint Board",
        [
            "Parallel Rank",
            "Method",
            "Joint score mean",
            "Joint score std",
            "Field mean",
            "Inverse-target mean",
            "Residual mean",
            "Seed count",
            "Status",
        ],
        [
            [
                str(row["parallel_rank"]),
                f"`{row['canonical_id']}`",
                _format_optional_score(row["joint_inverse_main_score_mean"]),
                _format_optional_score(row["joint_inverse_main_score_std"]),
                _format_optional_score(row["field_relative_l2_mean"]),
                _format_optional_score(row["inverse_target_relative_error_mean"]),
                _format_optional_score(row["residual_metric_mean"]),
                str(row["seed_count"]),
                str(row["status"]),
            ]
            for row in parallel_inverse_board_rows
        ],
    )

    _write_csv(BENCHMARK_MODEL_ROOT / "main_fair_board_real_scores.csv", main_board_rows)
    _write_json(BENCHMARK_MODEL_ROOT / "main_fair_board_real_scores.json", "main_fair_board_real_scores.v1", main_board_rows)
    _write_markdown_table(
        BENCHMARK_MODEL_ROOT / "main_fair_board_real_scores.md",
        "Main Fair Board Real Scores",
        ["Rank", "Method", "Main score mean", "Main score std", "Seed count", "Run mode", "Strategy"],
        [
            [
                str(row["rank"]),
                f"`{row['canonical_id']}`",
                f"{float(row['main_score_mean']):.6f}",
                f"{float(row['main_score_std']):.6f}",
                str(row["seed_count"]),
                str(row["run_mode"]),
                f"`{row['standardization_strategy']}`",
            ]
            for row in main_board_rows
        ],
    )
    _write_csv(BENCHMARK_MODEL_ROOT / "fairness_audit_results.csv", audit_rows)
    _write_json(BENCHMARK_MODEL_ROOT / "fairness_audit_results.json", "fairness_audit_results.v1", audit_rows)
    _write_fairness_audit_tables(audit_rows)
    (BENCHMARK_MODEL_ROOT / "all_method_result_snapshot.json").write_text(
        json.dumps(
            {
                "schema_version": "all_method_result_snapshot.v1",
                "artifacts": [
                    "main_fair_board_real_scores.json",
                    "fairness_audit_results.json",
                    "method_result_cards.json",
                    "paper_result_consistency_audit.json",
                    "per_method_metrics.json",
                    "per_seed_metrics.json",
                    "score_aggregation_records.json",
                ],
                "rows": per_method_rows,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    (BENCHMARK_MODEL_ROOT / "all_method_result_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    _write_paper_results(main_board_rows, per_seed_rows, aggregation_rows, audit_rows, summary)
    _write_contract_and_reproducibility_assets(
        participants=participants,
        board_rows=main_board_rows,
        audit_rows=audit_rows,
        budget_rows=budget_rows,
        per_seed_rows=per_seed_rows,
    )
    _write_inverse_validity_and_protocol_assets(
        board_rows=main_board_rows,
        participants=participants,
    )

    return {
        "manifest_rows": manifest_rows,
        "ledger_rows": updated_ledger,
        "budget_rows": budget_rows,
        "per_seed_rows": per_seed_rows,
        "aggregation_rows": aggregation_rows,
        "per_method_rows": per_method_rows,
        "main_board_rows": main_board_rows,
        "parallel_inverse_board_rows": parallel_inverse_board_rows,
        "audit_rows": audit_rows,
        "summary": summary,
        "method_cards": method_cards,
        "consistency_audit": consistency_audit,
    }


__all__ = ["write_real_fair_board_results"]
