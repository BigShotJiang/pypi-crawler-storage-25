"""Typed schema definitions for experiment configuration."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pinn_bench.comparison import ComparisonConfig


@dataclass
class ComponentConfig:
    """Named component configuration with nested parameters."""

    name: str
    params: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "params": dict(self.params)}


@dataclass
class TrainConfig:
    """Training-related configuration."""

    epochs: int
    lr: float
    seed: int = 42
    device: str = "cpu"
    loss_weights: dict[str, float] = field(default_factory=dict)
    extras: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "epochs": self.epochs,
            "lr": self.lr,
            "seed": self.seed,
            "device": self.device,
            "loss_weights": dict(self.loss_weights),
            **self.extras,
        }


@dataclass
class LoggingConfig:
    """Logging-related configuration."""

    backend: str = "basic"
    log_every: int = 1
    extras: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"backend": self.backend, "log_every": self.log_every, **self.extras}


@dataclass
class OutputConfig:
    """Output-related configuration."""

    root_dir: str
    extras: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"root_dir": self.root_dir, **self.extras}


@dataclass
class EvaluationConfig:
    """Evaluation-related configuration."""

    num_samples: int = 256
    grid_x: int | None = None
    grid_t: int | None = None
    grid_y: int | None = None
    extras: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"num_samples": self.num_samples, **self.extras}
        payload["grid_x"] = self.grid_x
        payload["grid_t"] = self.grid_t
        payload["grid_y"] = self.grid_y
        return payload


@dataclass
class MetricsConfig:
    """Metric-related configuration."""

    names: list[str] = field(default_factory=lambda: ["mse", "relative_l2"])
    extras: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"names": list(self.names), **self.extras}


@dataclass
class RobustnessConfig:
    """Robustness protocol configuration."""

    protocol: str = "none"
    level: float = 0.0
    severity_label: str | None = None
    target_scopes: list[str] = field(default_factory=list)
    components: list[dict[str, Any]] = field(default_factory=list)
    train_time_range: list[float] | None = None
    eval_time_range: list[float] | None = None
    train_support_ratio: float | None = None
    extras: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "protocol": self.protocol,
            "level": self.level,
            "target_scopes": list(self.target_scopes),
            **self.extras,
        }
        if self.components:
            payload["components"] = [dict(component) for component in self.components]
        if self.severity_label is not None:
            payload["severity_label"] = str(self.severity_label)
        if self.train_time_range is not None:
            payload["train_time_range"] = list(self.train_time_range)
        if self.eval_time_range is not None:
            payload["eval_time_range"] = list(self.eval_time_range)
        if self.train_support_ratio is not None:
            payload["train_support_ratio"] = float(self.train_support_ratio)
        return payload


@dataclass
class ExperimentConfig:
    """Top-level experiment configuration."""

    model: ComponentConfig
    task: ComponentConfig
    train: TrainConfig
    logging: LoggingConfig
    output: OutputConfig
    evaluation: EvaluationConfig = field(default_factory=EvaluationConfig)
    metrics: MetricsConfig = field(default_factory=MetricsConfig)
    robustness: RobustnessConfig = field(default_factory=RobustnessConfig)
    comparison: ComparisonConfig | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "model": self.model.to_dict(),
            "task": self.task.to_dict(),
            "train": self.train.to_dict(),
            "logging": self.logging.to_dict(),
            "output": self.output.to_dict(),
            "evaluation": self.evaluation.to_dict(),
            "metrics": self.metrics.to_dict(),
            "robustness": self.robustness.to_dict(),
        }
        if self.comparison is not None:
            payload["comparison"] = self.comparison.to_dict()
        return payload
