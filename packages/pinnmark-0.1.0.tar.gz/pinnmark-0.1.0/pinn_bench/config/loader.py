"""YAML loader and validators for experiment configuration."""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any

import yaml

from pinn_bench.config.schema import (
    ComponentConfig,
    EvaluationConfig,
    ExperimentConfig,
    LoggingConfig,
    MetricsConfig,
    OutputConfig,
    RobustnessConfig,
    TrainConfig,
)
from pinn_bench.comparison import parse_comparison_config
from pinn_bench.registry import resolve_model_name
from pinn_bench.registry import resolve_primary_method_name
from pinn_bench.resources import resolve_config_path

REQUIRED_SECTIONS = ("model", "task", "train", "logging", "output")
_PROTOCOL_ALIASES = {"gaussian_noise": "noise"}
_SCOPE_ALIASES = {"supervision": "data"}
_ALLOWED_ROBUSTNESS_SCOPES = {"boundary", "initial", "initial_velocity", "data"}
_ALLOWED_SEVERITY_LABELS = {"nominal", "mild", "medium", "severe"}
_ALLOWED_ROBUSTNESS_LEVELS = {
    "none": {0.0},
    "noise": {0.0, 0.005, 0.01, 0.02, 0.05, 0.1, 0.15},
    "sensor_drift": {0.0, 0.005, 0.01, 0.02, 0.05, 0.1, 0.15},
    "heteroscedastic_noise": {0.0, 0.005, 0.01, 0.02, 0.05, 0.1, 0.15},
    "low_frequency_bias": {0.0, 0.005, 0.01, 0.02, 0.05, 0.1, 0.15},
    "sparsity": {1.0, 0.5, 0.25, 0.2, 0.1},
    "bcic_corruption": {0.0, 0.02, 0.05, 0.1},
    "parameter_shift": {0.0},
    "resolution_shift": {0.0},
    "bc_family_shift": {0.0},
    "ic_family_shift": {0.0},
    "geometry_shift": {0.0},
    "extrapolation": {0.0},
    "support_extrapolation": {0.0},
    "composite": {0.0},
}
_COMPOSITE_ALLOWED_COMPONENT_PROTOCOLS = ("sparsity", "noise")
_ALLOWED_SPARSITY_PATTERN_FAMILIES = {
    "random_sensor",
    "boundary_only",
    "initial_only",
    "temporal_block_missing",
}


def _ensure_mapping(value: Any, location: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"Expected mapping at '{location}', got {type(value).__name__}.")
    return dict(value)


def _pop_required(mapping: dict[str, Any], key: str, section: str) -> Any:
    if key not in mapping:
        raise ValueError(f"Missing required key '{section}.{key}'.")
    return mapping.pop(key)


def _parse_component(section: str, payload: dict[str, Any]) -> ComponentConfig:
    data = _ensure_mapping(payload, section)
    name = _pop_required(data, "name", section)
    if not isinstance(name, str) or not name.strip():
        raise ValueError(f"'{section}.name' must be a non-empty string.")
    if section == "model":
        primary_method_id = None
        try:
            primary_method_id = resolve_primary_method_name(name.strip())
        except KeyError:
            primary_method_id = None
        try:
            normalized_name = resolve_model_name(name.strip(), include_external=True, include_canonical_family=True)
        except KeyError as error:
            raise ValueError(str(error)) from error
    else:
        normalized_name = name.strip()

    nested_params = data.pop("params", {})
    if nested_params is None:
        nested_params = {}
    nested_params = _ensure_mapping(nested_params, f"{section}.params")
    params = {**nested_params, **data}
    if section == "model" and primary_method_id is not None:
        params.setdefault("_pinn_primary_method_id", str(primary_method_id))
        params.setdefault("_pinn_requested_model_name", str(name).strip())
    return ComponentConfig(name=normalized_name, params=params)


def _parse_train(payload: dict[str, Any]) -> TrainConfig:
    data = _ensure_mapping(payload, "train")
    epochs = int(_pop_required(data, "epochs", "train"))
    lr = float(_pop_required(data, "lr", "train"))
    seed = int(data.pop("seed", 42))
    device = str(data.pop("device", "cpu"))

    raw_loss_weights = data.pop("loss_weights", {})
    if raw_loss_weights is None:
        raw_loss_weights = {}
    loss_weights = {
        str(name): float(weight)
        for name, weight in _ensure_mapping(raw_loss_weights, "train.loss_weights").items()
    }
    return TrainConfig(
        epochs=epochs,
        lr=lr,
        seed=seed,
        device=device,
        loss_weights=loss_weights,
        extras=data,
    )


def _parse_logging(payload: dict[str, Any]) -> LoggingConfig:
    data = _ensure_mapping(payload, "logging")
    backend = str(data.pop("backend", "basic"))
    log_every = int(data.pop("log_every", 1))
    return LoggingConfig(backend=backend, log_every=log_every, extras=data)


def _parse_output(payload: dict[str, Any]) -> OutputConfig:
    data = _ensure_mapping(payload, "output")
    root_dir = str(_pop_required(data, "root_dir", "output"))
    return OutputConfig(root_dir=root_dir, extras=data)


def _parse_evaluation(payload: dict[str, Any] | None) -> EvaluationConfig:
    if payload is None:
        return EvaluationConfig()
    data = _ensure_mapping(payload, "evaluation")
    num_samples = int(data.pop("num_samples", 256))
    grid_x = data.pop("grid_x", None)
    grid_t = data.pop("grid_t", None)
    grid_y = data.pop("grid_y", None)
    return EvaluationConfig(
        num_samples=num_samples,
        grid_x=None if grid_x is None else int(grid_x),
        grid_t=None if grid_t is None else int(grid_t),
        grid_y=None if grid_y is None else int(grid_y),
        extras=data,
    )


def _parse_metrics(payload: dict[str, Any] | None) -> MetricsConfig:
    if payload is None:
        return MetricsConfig()
    data = _ensure_mapping(payload, "metrics")
    names = data.pop("names", ["mse", "relative_l2"])
    if not isinstance(names, list) or not all(isinstance(name, str) for name in names):
        raise ValueError("'metrics.names' must be a list of strings.")
    return MetricsConfig(names=names, extras=data)


def _normalize_protocol_name(protocol: str) -> str:
    normalized = str(protocol).strip().lower()
    return _PROTOCOL_ALIASES.get(normalized, normalized)


def _normalize_target_scope(scope: str) -> str:
    normalized = str(scope).strip().lower()
    return _SCOPE_ALIASES.get(normalized, normalized)


def _format_level(value: float) -> str:
    if value in {0.0, 1.0}:
        return f"{value:.1f}"
    return str(value)


def _format_allowed_levels(protocol: str) -> str:
    values = sorted(_ALLOWED_ROBUSTNESS_LEVELS[protocol])
    return ", ".join(_format_level(value) for value in values)


def _parse_numeric_range(value: Any, location: str) -> list[float] | None:
    if value is None:
        return None
    if not isinstance(value, list) or len(value) != 2:
        raise ValueError(f"'{location}' must be a length-2 numeric range.")
    try:
        start = float(value[0])
        end = float(value[1])
    except (TypeError, ValueError) as exc:
        raise ValueError(f"'{location}' must be a length-2 numeric range.") from exc
    if start > end:
        raise ValueError(f"'{location}' must be ordered as [start, end].")
    return [start, end]


def _parse_robustness_component(value: Any, *, index: int) -> dict[str, Any]:
    location = f"robustness.components[{index}]"
    data = _ensure_mapping(value, location)
    protocol = _normalize_protocol_name(str(data.pop("protocol", "")))
    if protocol not in _COMPOSITE_ALLOWED_COMPONENT_PROTOCOLS:
        allowed = ", ".join(_COMPOSITE_ALLOWED_COMPONENT_PROTOCOLS)
        raise ValueError(f"'{location}.protocol' must be one of: {allowed}")
    if "target_scopes" in data:
        raise ValueError(f"'{location}.target_scopes' is not supported; composite target scopes stay on 'robustness.target_scopes'.")
    if "components" in data:
        raise ValueError(f"'{location}.components' is not supported.")
    level = float(data.pop("level", 0.0))
    if level not in _ALLOWED_ROBUSTNESS_LEVELS[protocol]:
        raise ValueError(
            f"Unsupported robustness level {level} for component protocol '{protocol}'. "
            f"Allowed: {_format_allowed_levels(protocol)}"
        )
    severity_label = data.pop("severity_label", None)
    if severity_label is not None:
        severity_label = str(severity_label).strip().lower()
        if severity_label not in _ALLOWED_SEVERITY_LABELS:
            allowed = ", ".join(sorted(_ALLOWED_SEVERITY_LABELS))
            raise ValueError(f"'{location}.severity_label' must be one of: {allowed}")
    if data:
        extras = ", ".join(sorted(data))
        raise ValueError(f"Unsupported key(s) in '{location}': {extras}")
    return {
        "protocol": protocol,
        "level": level,
        **({"severity_label": severity_label} if severity_label is not None else {}),
    }


def _parse_robustness(payload: dict[str, Any] | None) -> RobustnessConfig:
    if payload is None:
        return RobustnessConfig()

    data = _ensure_mapping(payload, "robustness")
    protocol = _normalize_protocol_name(str(data.pop("protocol", "none")))
    level = float(data.pop("level", 0.0))
    severity_label = data.pop("severity_label", None)
    if severity_label is not None:
        severity_label = str(severity_label).strip().lower()
        if severity_label not in _ALLOWED_SEVERITY_LABELS:
            allowed = ", ".join(sorted(_ALLOWED_SEVERITY_LABELS))
            raise ValueError(f"'robustness.severity_label' must be one of: {allowed}")
    train_time_range = _parse_numeric_range(data.pop("train_time_range", None), "robustness.train_time_range")
    eval_time_range = _parse_numeric_range(data.pop("eval_time_range", None), "robustness.eval_time_range")
    temporal_block_range = _parse_numeric_range(data.pop("temporal_block_range", None), "robustness.temporal_block_range")
    raw_train_support_ratio = data.pop("train_support_ratio", None)
    train_support_ratio = None if raw_train_support_ratio is None else float(raw_train_support_ratio)
    if train_support_ratio is not None and not (0.0 < train_support_ratio <= 1.0):
        raise ValueError("'robustness.train_support_ratio' must lie in (0, 1].")

    raw_target_scopes = data.pop("target_scopes", [])
    if raw_target_scopes is None:
        raw_target_scopes = []
    if not isinstance(raw_target_scopes, list) or not all(isinstance(scope, str) for scope in raw_target_scopes):
        raise ValueError("'robustness.target_scopes' must be a list of strings.")
    target_scopes = [_normalize_target_scope(scope) for scope in raw_target_scopes]
    raw_components = data.pop("components", [])
    if raw_components is None:
        raw_components = []
    if not isinstance(raw_components, list):
        raise ValueError("'robustness.components' must be a list when provided.")
    components = [
        _parse_robustness_component(component, index=index)
        for index, component in enumerate(raw_components)
    ]
    raw_pattern_family = data.pop("pattern_family", None)
    pattern_family = None if raw_pattern_family is None else str(raw_pattern_family).strip().lower()
    if pattern_family is not None and pattern_family not in _ALLOWED_SPARSITY_PATTERN_FAMILIES:
        allowed = ", ".join(sorted(_ALLOWED_SPARSITY_PATTERN_FAMILIES))
        raise ValueError(f"'robustness.pattern_family' must be one of: {allowed}")

    invalid_scopes = [scope for scope in target_scopes if scope not in _ALLOWED_ROBUSTNESS_SCOPES]
    if invalid_scopes:
        if "physics" in invalid_scopes:
            raise ValueError(
                "physics sparsification is not supported in Phase 4B. "
                "Sparsity applies only to target-bearing supervision scopes."
            )
        allowed = ", ".join(sorted(_ALLOWED_ROBUSTNESS_SCOPES))
        bad = ", ".join(invalid_scopes)
        raise ValueError(f"Unsupported robustness target scope(s): {bad}. Allowed: {allowed}")

    if protocol not in _ALLOWED_ROBUSTNESS_LEVELS:
        allowed_protocols = ", ".join(sorted(_ALLOWED_ROBUSTNESS_LEVELS))
        raise ValueError(f"Unsupported robustness protocol. Allowed: {allowed_protocols}")

    if level not in _ALLOWED_ROBUSTNESS_LEVELS[protocol]:
        raise ValueError(
            f"Unsupported robustness level {level} for protocol '{protocol}'. Allowed: {_format_allowed_levels(protocol)}"
        )

    if protocol == "none":
        if components:
            raise ValueError("'robustness.components' must be empty when protocol is 'none'.")
        if target_scopes:
            raise ValueError("'robustness.target_scopes' must be empty when protocol is 'none'.")
        if train_time_range is not None or eval_time_range is not None or train_support_ratio is not None:
            raise ValueError("Time ranges and support ratios are only supported for extrapolation-style protocols.")

    if protocol == "composite":
        if train_time_range is not None or eval_time_range is not None or train_support_ratio is not None:
            raise ValueError("Time ranges and support ratios are not supported for 'composite'.")
        if not components:
            raise ValueError("'robustness.components' must contain at least one component when protocol is 'composite'.")
        component_protocols = [component["protocol"] for component in components]
        if component_protocols != list(_COMPOSITE_ALLOWED_COMPONENT_PROTOCOLS):
            ordered = ", ".join(_COMPOSITE_ALLOWED_COMPONENT_PROTOCOLS)
            raise ValueError(f"'robustness.components' must appear exactly in this order: {ordered}")

    if protocol in {"parameter_shift", "resolution_shift", "bc_family_shift", "ic_family_shift", "geometry_shift"}:
        if components:
            raise ValueError(f"'robustness.components' must be empty when protocol is '{protocol}'.")
        if target_scopes:
            raise ValueError(f"'robustness.target_scopes' must be empty when protocol is '{protocol}'.")
        if train_time_range is not None or eval_time_range is not None or train_support_ratio is not None:
            raise ValueError(f"Time ranges and support ratios are not supported for '{protocol}'.")

    if protocol in {"noise", "sparsity", "bcic_corruption"}:
        if components:
            raise ValueError(f"'robustness.components' must be empty when protocol is '{protocol}'.")
        if train_time_range is not None or eval_time_range is not None or train_support_ratio is not None:
            raise ValueError("Time ranges and support ratios are only supported for extrapolation-style protocols.")
    if protocol in {"sensor_drift", "heteroscedastic_noise", "low_frequency_bias"}:
        if components:
            raise ValueError(f"'robustness.components' must be empty when protocol is '{protocol}'.")
        if train_time_range is not None or eval_time_range is not None or train_support_ratio is not None:
            raise ValueError("Time ranges and support ratios are only supported for extrapolation-style protocols.")
        if target_scopes and any(scope not in _ALLOWED_ROBUSTNESS_SCOPES for scope in target_scopes):
            allowed = ", ".join(sorted(_ALLOWED_ROBUSTNESS_SCOPES))
            raise ValueError(f"Unsupported robustness target scope(s). Allowed: {allowed}")

    if protocol in {"extrapolation", "support_extrapolation"}:
        if components:
            raise ValueError(f"'robustness.components' must be empty when protocol is '{protocol}'.")
        if target_scopes:
            raise ValueError("'robustness.target_scopes' must be empty when protocol is extrapolation-style.")
        has_support_ratio = train_support_ratio is not None
        has_time_ranges = train_time_range is not None or eval_time_range is not None
        if has_support_ratio and has_time_ranges:
            raise ValueError("Use either train_support_ratio or explicit time ranges, not both.")
        if not has_support_ratio and has_time_ranges and (train_time_range is None or eval_time_range is None):
            raise ValueError("Extrapolation-style protocol requires both train_time_range and eval_time_range.")
        if not has_support_ratio and not (train_time_range is not None and eval_time_range is not None):
            raise ValueError("Extrapolation-style protocols require train_support_ratio or both time ranges.")
        if has_time_ranges:
            if train_time_range is None or eval_time_range is None:
                raise ValueError("Extrapolation-style protocols require both train_time_range and eval_time_range.")
            if train_time_range[1] > eval_time_range[0]:
                raise ValueError("Extrapolation protocol requires train_time_range[1] <= eval_time_range[0].")

    if pattern_family is not None and protocol != "sparsity":
        raise ValueError("'robustness.pattern_family' is only supported when protocol is 'sparsity'.")
    if temporal_block_range is not None and protocol != "sparsity":
        raise ValueError("'robustness.temporal_block_range' is only supported when protocol is 'sparsity'.")
    if pattern_family == "temporal_block_missing":
        if temporal_block_range is None:
            temporal_block_range = [0.3, 0.7]
        if not (0.0 <= temporal_block_range[0] < temporal_block_range[1] <= 1.0):
            raise ValueError("'robustness.temporal_block_range' must lie within [0, 1] and satisfy start < end.")
    elif temporal_block_range is not None:
        raise ValueError("'robustness.temporal_block_range' is only supported with pattern_family='temporal_block_missing'.")

    if pattern_family is not None:
        data["pattern_family"] = pattern_family
    if temporal_block_range is not None:
        data["temporal_block_range"] = temporal_block_range

    return RobustnessConfig(
        protocol=protocol,
        level=level,
        severity_label=severity_label,
        target_scopes=target_scopes,
        components=components,
        train_time_range=train_time_range,
        eval_time_range=eval_time_range,
        train_support_ratio=train_support_ratio,
        extras=data,
    )


def _validate_sections(payload: dict[str, Any]) -> None:
    missing = [section for section in REQUIRED_SECTIONS if section not in payload]
    if missing:
        missing_joined = ", ".join(missing)
        raise ValueError(f"Missing required section(s): {missing_joined}")


def _apply_overrides(config: ExperimentConfig, overrides: Mapping[str, Any] | None) -> None:
    if not overrides:
        return

    seed = overrides.get("seed")
    device = overrides.get("device")
    output_dir = overrides.get("output_dir")

    if seed is not None:
        config.train.seed = int(seed)
    if device is not None:
        config.train.device = str(device)
    if output_dir is not None:
        config.output.root_dir = str(output_dir)


def load_config(path: str | Path, overrides: Mapping[str, Any] | None = None) -> ExperimentConfig:
    """Load and validate a YAML experiment config."""
    config_path = resolve_config_path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"Config file does not exist: {config_path}")

    with config_path.open("r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle)

    payload = _ensure_mapping(raw, "root")
    _validate_sections(payload)

    config = ExperimentConfig(
        model=_parse_component("model", payload["model"]),
        task=_parse_component("task", payload["task"]),
        train=_parse_train(payload["train"]),
        logging=_parse_logging(payload["logging"]),
        output=_parse_output(payload["output"]),
        evaluation=_parse_evaluation(payload.get("evaluation")),
        metrics=_parse_metrics(payload.get("metrics")),
        robustness=_parse_robustness(payload.get("robustness")),
        comparison=parse_comparison_config(payload.get("comparison")),
    )
    _apply_overrides(config=config, overrides=overrides)
    return config
