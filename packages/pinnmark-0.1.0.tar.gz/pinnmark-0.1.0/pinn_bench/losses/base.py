"""Base loss functions."""

from __future__ import annotations

import torch
import torch.nn.functional as F


def mse_loss(predictions: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
    """Mean squared error loss."""
    return F.mse_loss(predictions, targets)

