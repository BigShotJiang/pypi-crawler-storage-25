"""Loss composition utilities."""

from __future__ import annotations

from collections.abc import Mapping

import torch


class LossComposer:
    """Compose named loss terms into a single optimization objective."""

    def compose(
        self,
        loss_terms: Mapping[str, torch.Tensor],
        weights: Mapping[str, float] | None = None,
    ) -> tuple[torch.Tensor, dict[str, float]]:
        """Compute weighted total loss and detached scalar term logs."""
        if not loss_terms:
            raise ValueError("Expected at least one loss term.")

        total_loss: torch.Tensor | None = None
        scalar_terms: dict[str, float] = {}
        resolved_weights = dict(weights or {})

        for name, loss_term in loss_terms.items():
            scalar = loss_term if loss_term.ndim == 0 else loss_term.mean()
            weight = float(resolved_weights.get(name, 1.0))
            weighted = scalar * weight
            total_loss = weighted if total_loss is None else total_loss + weighted
            scalar_terms[f"loss_{name}"] = float(scalar.detach().item())

        assert total_loss is not None
        return total_loss, scalar_terms
