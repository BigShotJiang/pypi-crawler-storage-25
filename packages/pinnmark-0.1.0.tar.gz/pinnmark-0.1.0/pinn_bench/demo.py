"""Guided demo workflows for pinn_bench."""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from pathlib import Path

import yaml

from pinn_bench.community.compare_bundle import render_bundle_comparison
from pinn_bench.community.bundle import copy_bundle_artifacts
from pinn_bench.community.validate_submission import build_submission_validation_payload
from pinn_bench.experiments import matrix_run
from pinn_bench.leaderboard.export import export_results
from pinn_bench.leaderboard.pareto import export_pareto_tables
from pinn_bench.leaderboard.reporting import export_reporting_tables
from pinn_bench.leaderboard.robustness_summary import export_robustness_summary
from pinn_bench.leaderboard.summary import export_benchmark_summary
from pinn_bench.resources import resolve_config_path, resolve_outputs_root, resolve_repo_root
from pinn_bench.scaffold import generate_scaffold
from pinn_bench.version import LATEST_FORMAL_BASELINE, LATEST_FORMAL_OUTPUTS_ROOT

DEMO_SPECS = {
    "quick": {
        "objective": "Run one small Heat1D experiment and inspect the minimum grouped/reporting chain.",
        "description": "Single-model Heat1D quick demo.",
        "recommended_outputs_root": "outputs_demo/quick",
        "families": [
            {
                "run_id": "heat1d_mlp",
                "config_path": "heat1d_mlp.yaml",
                "task_name": "heat1d",
                "model_name": "mlp",
                "protocol": "none",
            }
        ],
        "include_pareto": False,
        "official": False,
    },
    "compare": {
        "objective": "Compare two model families on the same Heat1D task under the standard protocol.",
        "description": "Heat1D MLP vs SIREN grouped comparison.",
        "recommended_outputs_root": "outputs_demo/compare",
        "families": [
            {
                "run_id": "heat1d_mlp",
                "config_path": "heat1d_mlp.yaml",
                "task_name": "heat1d",
                "model_name": "mlp",
                "protocol": "none",
            },
            {
                "run_id": "heat1d_siren",
                "config_path": "heat1d_siren.yaml",
                "task_name": "heat1d",
                "model_name": "siren",
                "protocol": "none",
            },
        ],
        "include_pareto": False,
        "official": False,
    },
    "robustness": {
        "objective": "Show how a robustness family flows through grouped, reporting, and Pareto exports.",
        "description": "Heat1D robustness walkthrough with SIREN noise.",
        "recommended_outputs_root": "outputs_demo/robustness",
        "families": [
            {
                "run_id": "heat1d_siren_noise_0p05",
                "config_path": "heat1d_siren_noise_0p05.yaml",
                "task_name": "heat1d",
                "model_name": "siren",
                "protocol": "noise",
            }
        ],
        "include_pareto": True,
        "official": False,
    },
    "platform-tour": {
        "objective": "Show the official end-to-end product walkthrough across matrix-like execution, grouped export, reporting, Pareto, and summary assets.",
        "description": "Official compact end-to-end platform tour across run, grouped, report, and pareto layers.",
        "recommended_outputs_root": "outputs_demo_official",
        "families": [
            {
                "run_id": "heat1d_mlp",
                "config_path": "heat1d_mlp.yaml",
                "task_name": "heat1d",
                "model_name": "mlp",
                "protocol": "none",
            },
            {
                "run_id": "heat1d_siren",
                "config_path": "heat1d_siren.yaml",
                "task_name": "heat1d",
                "model_name": "siren",
                "protocol": "none",
            },
            {
                "run_id": "heat1d_siren_noise_0p05",
                "config_path": "heat1d_siren_noise_0p05.yaml",
                "task_name": "heat1d",
                "model_name": "siren",
                "protocol": "noise",
            },
        ],
        "include_pareto": True,
        "official": True,
    },
    "community-path": {
        "objective": "Show the community onboarding path across external scaffolding, bundle packaging, submission validation, and grouped comparison.",
        "description": "Community-ready workflow using one external model scaffold and one official reference bundle.",
        "recommended_outputs_root": "outputs_demo/community-path",
        "families": [],
        "include_pareto": False,
        "official": False,
    },
    "submission-path": {
        "objective": "Show the official submission packaging path across package-run, validate-submission, compare-bundle, and doctor --submission-bundle.",
        "description": "Official reference workflow using one frozen formal run and grouped baseline assets.",
        "recommended_outputs_root": "outputs_demo/submission-path",
        "families": [],
        "include_pareto": False,
        "official": False,
    },
}



def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run guided pinn_bench demo workflows.")
    parser.add_argument("mode", nargs="?", default="quick", help="Demo mode to execute.")
    parser.add_argument("--output-root", type=str, default=None, help="Optional demo outputs root override.")
    parser.add_argument("--list", action="store_true", help="List available demo modes and exit.")
    parser.add_argument("--explain", action="store_true", help="Explain the selected demo mode without running it.")
    return parser



def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)



def get_demo_spec(mode: str) -> dict[str, object]:
    normalized = mode.strip().lower()
    if normalized not in DEMO_SPECS:
        available = ", ".join(sorted(DEMO_SPECS))
        raise KeyError(f"Unknown demo mode '{mode}'. Available: {available}")
    return DEMO_SPECS[normalized]



def list_demo_modes() -> list[str]:
    return sorted(DEMO_SPECS)



def demo_resource_checks(mode: str) -> list[Path]:
    spec = get_demo_spec(mode)
    if mode in {"community-path", "submission-path"}:
        repo_root = resolve_repo_root()
        return [
            repo_root / "outputs_v06" / "heat1d_mlp_seed0" / "metrics.json",
            repo_root / "outputs_v06" / "heat1d_mlp_seed0" / "config_snapshot.yaml",
            repo_root / LATEST_FORMAL_OUTPUTS_ROOT / "_leaderboard" / "leaderboard_grouped.json",
        ]
    checks: list[Path] = []
    families = spec["families"]
    assert isinstance(families, list)
    for family in families:
        assert isinstance(family, dict)
        checks.append(resolve_config_path(str(family["config_path"])))
    return checks



def _default_output_root(mode: str) -> Path:
    spec = get_demo_spec(mode)
    return resolve_outputs_root(str(spec["recommended_outputs_root"]))



def _resolve_demo_families(mode: str) -> list[dict[str, str]]:
    families = get_demo_spec(mode)["families"]
    assert isinstance(families, list)
    resolved: list[dict[str, str]] = []
    for family in families:
        assert isinstance(family, dict)
        resolved.append(
            {
                **family,
                "config_path": str(resolve_config_path(str(family["config_path"]))),
            }
        )
    return resolved



def _write_demo_manifest(output_root: Path, mode: str) -> Path:
    spec = get_demo_spec(mode)
    manifest = {
        "schema_version": "baseline_matrix.v0.1",
        "default_seeds": [0],
        "results_root": str(output_root),
        "runs": _resolve_demo_families(mode),
    }
    manifest_path = output_root / "_demo_manifest.yaml"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(yaml.safe_dump(manifest, sort_keys=False), encoding="utf-8")
    return manifest_path



def _demo_generated_assets(output_root: Path, *, include_pareto: bool) -> list[Path]:
    assets = [
        output_root / "_demo_manifest.yaml",
        output_root / "_matrix_runs",
        output_root / "_leaderboard" / "leaderboard_grouped.json",
        output_root / "_leaderboard" / "reporting",
        output_root / "_leaderboard" / "benchmark_summary.md",
        output_root / "_leaderboard" / "robustness_summary.json",
        output_root / "_leaderboard" / "robustness_summary.md",
        output_root / "demo_summary.md",
        output_root / "asset_index.md",
    ]
    if include_pareto:
        assets.append(output_root / "_leaderboard" / "pareto")
    return assets


def _community_demo_assets(output_root: Path) -> list[Path]:
    return [
        output_root / "external_templates",
        output_root / "bundle",
        output_root / "validation.json",
        output_root / "comparison.md",
        output_root / "demo_summary.md",
        output_root / "asset_index.md",
    ]


def _submission_demo_assets(output_root: Path) -> list[Path]:
    return [
        output_root / "bundle",
        output_root / "validation.json",
        output_root / "comparison.md",
        output_root / "doctor_submission.json",
        output_root / "demo_summary.md",
        output_root / "asset_index.md",
    ]



def describe_demo_mode(mode: str, *, output_root: Path | None = None) -> str:
    spec = get_demo_spec(mode)
    root = _default_output_root(mode) if output_root is None else output_root.resolve()
    families = _resolve_demo_families(mode)
    include_pareto = bool(spec["include_pareto"])
    if mode == "community-path":
        lines = [
            f"mode: {mode}",
            f"description: {spec['description']}",
            f"objective: {spec['objective']}",
            f"recommended_outputs_root: {root}",
            "workflow:",
            "- scaffold external-model community_example_model",
            "- package one official reference run into a bundle",
            "- validate the bundle",
            "- compare the bundle against grouped official results",
            "generated_assets:",
        ]
        for asset in _community_demo_assets(root):
            lines.append(f"- {asset}")
        return "\n".join(lines)
    lines = [
        f"mode: {mode}",
        f"description: {spec['description']}",
        f"objective: {spec['objective']}",
        f"recommended_outputs_root: {root}",
        f"includes_pareto: {include_pareto}",
        "families:",
    ]
    for family in families:
        lines.append(f"- {family['run_id']} -> {family['config_path']}")
    lines.append("generated_assets:")
    for asset in _demo_generated_assets(root, include_pareto=include_pareto):
        lines.append(f"- {asset}")
    return "\n".join(lines)



def _write_demo_summary(output_root: Path, mode: str, manifest_path: Path, include_pareto: bool) -> None:
    spec = get_demo_spec(mode)
    reporting_dir = output_root / "_leaderboard" / "reporting"
    pareto_dir = output_root / "_leaderboard" / "pareto"
    families = _resolve_demo_families(mode)
    lines = [
        f"# Demo Summary ({mode})",
        "",
        f"Objective: {spec['objective']}",
        "",
        f"Description: {spec['description']}",
        "",
        "## Families",
        "",
        *[f"- `{family['run_id']}` -> `{family['config_path']}`" for family in families],
        "",
        "## Generated Assets",
        "",
        f"- Manifest: `{manifest_path}`",
        f"- Matrix reports: `{output_root / '_matrix_runs'}`",
        f"- Grouped leaderboard: `{output_root / '_leaderboard' / 'leaderboard_grouped.json'}`",
        f"- Reporting assets: `{reporting_dir}`",
    ]
    if include_pareto:
        lines.append(f"- Pareto assets: `{pareto_dir}`")
    lines.extend(
        [
            "",
            "## Next Recommended Commands",
            "",
            f"- `pinn-bench doctor --preview --outputs-root {output_root}`",
            f"- `pinn-bench summary --grouped-json {output_root / '_leaderboard' / 'leaderboard_grouped.json'}`",
            "- `pinn-bench preset list`",
            "",
        ]
    )
    (output_root / "demo_summary.md").write_text("\n".join(lines), encoding="utf-8")



def _write_asset_index(output_root: Path, *, include_pareto: bool) -> None:
    assets = _demo_generated_assets(output_root, include_pareto=include_pareto)
    lines = ["# Asset Index", "", "## Generated Paths", ""]
    for asset in assets:
        lines.append(f"- `{asset}`")
    lines.append("")
    (output_root / "asset_index.md").write_text("\n".join(lines), encoding="utf-8")



def run_demo(mode: str, output_root: Path) -> None:
    if mode == "community-path":
        _run_community_demo(output_root)
        return
    if mode == "submission-path":
        _run_submission_demo(output_root)
        return
    spec = get_demo_spec(mode)
    include_pareto = bool(spec["include_pareto"])
    manifest_path = _write_demo_manifest(output_root, mode)
    matrix_run.main(
        [
            "--matrix-manifest",
            str(manifest_path),
            "--outputs-root",
            str(output_root),
            "--skip-existing",
        ]
    )
    export_results(results_dir=output_root, output_dir=output_root / "_leaderboard", matrix_manifest=manifest_path)
    export_reporting_tables(
        grouped_json_path=output_root / "_leaderboard" / "leaderboard_grouped.json",
        output_dir=output_root / "_leaderboard" / "reporting",
    )
    export_benchmark_summary(grouped_json_path=output_root / "_leaderboard" / "leaderboard_grouped.json")
    export_robustness_summary(grouped_json_path=output_root / "_leaderboard" / "leaderboard_grouped.json")
    if include_pareto:
        export_pareto_tables(
            grouped_json_path=output_root / "_leaderboard" / "leaderboard_grouped.json",
            output_dir=output_root / "_leaderboard" / "pareto",
        )
    _write_demo_summary(output_root, mode, manifest_path, include_pareto=include_pareto)
    _write_asset_index(output_root, include_pareto=include_pareto)


def _run_submission_demo(output_root: Path) -> None:
    from pinn_bench.doctor import COMMUNITY_MODE, build_doctor_payload

    repo_root = resolve_repo_root()
    output_root.mkdir(parents=True, exist_ok=True)

    reference_run_dir = repo_root / "outputs_v06" / "heat1d_mlp_seed0"
    bundle_dir = output_root / "bundle"
    copy_bundle_artifacts(run_dir=reference_run_dir, output_dir=bundle_dir)

    validation_payload = build_submission_validation_payload(bundle_dir)
    validation_path = output_root / "validation.json"
    validation_path.write_text(json.dumps(validation_payload, indent=2), encoding="utf-8")

    comparison_text = render_bundle_comparison(bundle_dir, repo_root / LATEST_FORMAL_OUTPUTS_ROOT / "_leaderboard" / "leaderboard_grouped.json")
    comparison_path = output_root / "comparison.md"
    comparison_path.write_text(comparison_text, encoding="utf-8")

    doctor_payload = build_doctor_payload(
        mode=COMMUNITY_MODE,
        outputs_root_arg=None,
        matrix_manifest_arg=None,
        strict=False,
        submission_bundle_arg=str(bundle_dir),
        scaffold_root_arg=None,
    )
    doctor_path = output_root / "doctor_submission.json"
    doctor_path.write_text(json.dumps(doctor_payload, indent=2), encoding="utf-8")

    lines = [
        "# Demo Summary (submission-path)",
        "",
        "Objective: show the official package → validate → compare → doctor workflow.",
        "",
        "## Workflow",
        "",
        f"- Reference run packaged from: `{reference_run_dir}`",
        f"- Bundle dir: `{bundle_dir}`",
        f"- Validation payload: `{validation_path}`",
        f"- Comparison summary: `{comparison_path}`",
        f"- Doctor payload: `{doctor_path}`",
        "",
        "## Next Recommended Commands",
        "",
        f"- `pinn-bench package-run {reference_run_dir} --output-dir {bundle_dir}`",
        f"- `pinn-bench validate-submission {bundle_dir} --against-benchmark-line {LATEST_FORMAL_BASELINE}`",
        f"- `pinn-bench compare-bundle {bundle_dir} --against {LATEST_FORMAL_OUTPUTS_ROOT}/_leaderboard/leaderboard_grouped.json`",
        f"- `pinn-bench doctor --submission-bundle {bundle_dir}`",
        "",
    ]
    (output_root / "demo_summary.md").write_text("\n".join(lines), encoding="utf-8")

    asset_lines = ["# Asset Index", "", "## Generated Paths", ""]
    for asset in _submission_demo_assets(output_root):
        asset_lines.append(f"- `{asset}`")
    asset_lines.append("")
    (output_root / "asset_index.md").write_text("\n".join(asset_lines), encoding="utf-8")


def _run_community_demo(output_root: Path) -> None:
    repo_root = resolve_repo_root()
    output_root.mkdir(parents=True, exist_ok=True)
    generate_scaffold("external-model", "community_example_model", output_root)

    reference_run_dir = repo_root / "outputs_v06" / "heat1d_mlp_seed0"
    bundle_dir = output_root / "bundle"
    copy_bundle_artifacts(run_dir=reference_run_dir, output_dir=bundle_dir)

    validation_payload = build_submission_validation_payload(bundle_dir)
    validation_path = output_root / "validation.json"
    validation_path.write_text(json.dumps(validation_payload, indent=2), encoding="utf-8")

    comparison_text = render_bundle_comparison(bundle_dir, repo_root / LATEST_FORMAL_OUTPUTS_ROOT / "_leaderboard" / "leaderboard_grouped.json")
    comparison_path = output_root / "comparison.md"
    comparison_path.write_text(comparison_text, encoding="utf-8")

    lines = [
        "# Demo Summary (community-path)",
        "",
        "Objective: show the external scaffold → package → validate → compare workflow.",
        "",
        "## Workflow",
        "",
        f"- External scaffold root: `{output_root / 'external_templates'}`",
        f"- Reference run packaged from: `{reference_run_dir}`",
        f"- Bundle dir: `{bundle_dir}`",
        f"- Validation payload: `{validation_path}`",
        f"- Comparison summary: `{comparison_path}`",
        "",
        "## Next Recommended Commands",
        "",
        f"- `pinn-bench validate-submission {bundle_dir}`",
        f"- `pinn-bench compare-bundle {bundle_dir} --against {LATEST_FORMAL_OUTPUTS_ROOT}/_leaderboard/leaderboard_grouped.json`",
        f"- `pinn-bench doctor --submission-bundle {bundle_dir}`",
        f"- `pinn-bench doctor --scaffold-root {output_root / 'external_templates' / 'model' / 'community_example_model'}`",
        "",
    ]
    (output_root / "demo_summary.md").write_text("\n".join(lines), encoding="utf-8")

    asset_lines = [
        "# Asset Index",
        "",
        "## Generated Paths",
        "",
        f"- `{output_root / 'external_templates'}`",
        f"- `{bundle_dir}`",
        f"- `{validation_path}`",
        f"- `{comparison_path}`",
        f"- `{output_root / 'demo_summary.md'}`",
        "",
    ]
    (output_root / "asset_index.md").write_text("\n".join(asset_lines), encoding="utf-8")



def main(argv: Sequence[str] | None = None) -> None:
    args = parse_args(argv)
    if args.list:
        for mode in list_demo_modes():
            spec = get_demo_spec(mode)
            marker = " [official]" if bool(spec.get("official")) else ""
            print(f"{mode}{marker} | {spec['description']}")
        return

    mode = args.mode.strip().lower()
    output_root = _default_output_root(mode) if args.output_root is None else resolve_outputs_root(args.output_root)
    if args.explain:
        print(describe_demo_mode(mode, output_root=output_root))
        return
    run_demo(mode, output_root=output_root)
    print(f"Demo '{mode}' written to {output_root.resolve()}")


if __name__ == "__main__":
    main()
