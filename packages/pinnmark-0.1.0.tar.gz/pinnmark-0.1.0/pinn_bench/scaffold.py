"""Scaffold templates for extending pinn_bench."""

from __future__ import annotations

import argparse
from collections.abc import Sequence
from pathlib import Path

from pinn_bench.api.user_api import create_scaffold as create_user_scaffold


TASK_TEMPLATE = '''"""Task scaffold for {name}."""

from __future__ import annotations

import torch

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import BaseTask, EvaluationBatch, SampleBatch, TrainBatches


@register_task("{name}")
class {class_name}(BaseTask):
    """TODO: describe the {name} task."""

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        raise NotImplementedError("TODO: implement sample_train_batches for {name}.")

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        raise NotImplementedError("TODO: implement sample_evaluation_batch for {name}.")

    def compute_loss_terms(self, model: torch.nn.Module, batches: TrainBatches) -> dict[str, torch.Tensor]:
        raise NotImplementedError("TODO: implement compute_loss_terms for {name}.")
'''

MODEL_TEMPLATE = '''"""Model scaffold for {name}."""

from __future__ import annotations

from typing import Any

import torch
from torch import nn

from pinn_bench.models.base import BaseModel
from pinn_bench.registry import register_model


@register_model("{name}")
class {class_name}(BaseModel):
    """TODO: describe the {name} model."""

    def __init__(self, **_: Any) -> None:
        super().__init__()
        raise NotImplementedError("TODO: add parameters and init logic for {name}.")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        raise NotImplementedError("TODO: implement forward pass for {name}.")
'''

OPERATOR_MODEL_TEMPLATE = '''"""Operator model scaffold for {name}."""

from __future__ import annotations

from typing import Any

import torch

from pinn_bench.models.base import BaseOperatorModel
from pinn_bench.registry import register_model


@register_model("{name}")
class {class_name}(BaseOperatorModel):
    """TODO: describe the {name} operator-ready model."""

    def __init__(self, **_: Any) -> None:
        super().__init__()
        raise NotImplementedError("TODO: add parameters and init logic for {name}.")

    def forward_field(
        self,
        condition_inputs: torch.Tensor | None,
        query_inputs: torch.Tensor | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> torch.Tensor:
        raise NotImplementedError("TODO: implement field prediction for {name}.")
'''

METRIC_TEMPLATE = '''"""Metric scaffold for {name}."""

from __future__ import annotations

import torch

from pinn_bench.registry import register_metric


@register_metric("{name}")
def {function_name}(predictions: torch.Tensor, targets: torch.Tensor) -> float:
    """TODO: explain the {name} metric."""
    raise NotImplementedError("TODO: implement metric computation for {name}.")
'''

PROTOCOL_TEMPLATE = '''"""Protocol scaffold for {name}."""

from __future__ import annotations

from dataclasses import dataclass

from pinn_bench.robustness.protocols import BaseRobustnessProtocol
from pinn_bench.tasks.base import TrainBatches


@dataclass
class {class_name}(BaseRobustnessProtocol):
    """TODO: describe the {name} protocol."""

    def __init__(self) -> None:
        super().__init__(protocol_name="{name}", level=0.0, resolved_target_scopes=[])

    def apply_to_train_batches(self, task_name: str, batches: TrainBatches) -> TrainBatches:
        raise NotImplementedError("TODO: integrate {name} into pinn_bench.robustness.protocols.create_robustness_protocol.")
'''

CARD_TEMPLATE = '''# {title}

## Purpose / Problem
- TODO: describe the goal of this {kind}.

## Related Configs
- TODO: add example configs.

## Related Presets
- TODO: add relevant presets or demos.

## Related Protocols
- TODO: list applicable protocols or explain why not applicable.

## Known Limitations
- TODO: document current limitations and caveats.

## Next Entrypoints
- TODO: add the next command, module, or config to try.
'''

TASK_TEST_TEMPLATE = '''from __future__ import annotations

import pytest


def test_{function_name}_task_placeholder() -> None:
    pytest.skip("TODO: replace the {name} task scaffold placeholder with real task tests.")
'''

MODEL_TEST_TEMPLATE = '''from __future__ import annotations

import pytest


def test_{function_name}_model_placeholder() -> None:
    pytest.skip("TODO: replace the {name} model scaffold placeholder with real model tests.")
'''

METRIC_TEST_TEMPLATE = '''from __future__ import annotations

import pytest


def test_{function_name}_metric_placeholder() -> None:
    pytest.skip("TODO: replace the {name} metric scaffold placeholder with real metric tests.")
'''

PROTOCOL_TEST_TEMPLATE = '''from __future__ import annotations

import pytest


def test_{function_name}_protocol_placeholder() -> None:
    pytest.skip("TODO: replace the {name} protocol scaffold placeholder with real protocol tests.")
'''

TASK_CONFIG_TEMPLATE = '''model:
  name: mlp
  params:
    input_dim: 2
    output_dim: 1
    hidden_dims: [64, 64, 64]

task:
  name: {name}
  params:
    input_dim: 2
    output_dim: 1

train:
  epochs: 10
  lr: 0.001
  seed: 0
  device: cpu

logging:
  backend: basic
  log_every: 1

output:
  root_dir: outputs_playground/{name}
'''

MODEL_CONFIG_TEMPLATE = '''model:
  name: {name}
  params:
    input_dim: 2
    output_dim: 1

task:
  name: heat1d
  params:
    input_dim: 2
    output_dim: 1

train:
  epochs: 10
  lr: 0.001
  seed: 0
  device: cpu

logging:
  backend: basic
  log_every: 1

output:
  root_dir: outputs_playground/{name}
'''

PROTOCOL_CONFIG_TEMPLATE = '''model:
  name: mlp
  params:
    input_dim: 2
    output_dim: 1
    hidden_dims: [64, 64, 64]

task:
  name: heat1d
  params:
    input_dim: 2
    output_dim: 1

train:
  epochs: 10
  lr: 0.001
  seed: 0
  device: cpu

logging:
  backend: basic
  log_every: 1

output:
  root_dir: outputs_playground/{name}

robustness:
  protocol: {name}
  level: 0.0
'''

EXTERNAL_MODEL_TEMPLATE = '''"""External model template for {name}."""

from __future__ import annotations

from typing import Any

import torch
from torch import nn


class {class_name}(nn.Module):
    """Replace this example with your external model implementation."""

    def __init__(self, **_: Any) -> None:
        super().__init__()
        raise NotImplementedError("TODO: initialize the external model parameters for {name}.")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        raise NotImplementedError("TODO: implement the external model forward pass for {name}.")
'''

EXTERNAL_TASK_TEMPLATE = '''"""External task template for {name}."""

from __future__ import annotations

import torch


class {class_name}:
    """Replace this example with your external task wrapper or adapter."""

    def sample_train_batches(self, device: torch.device) -> object:
        raise NotImplementedError("TODO: implement train batch sampling for {name}.")

    def sample_evaluation_batch(self, device: torch.device) -> object:
        raise NotImplementedError("TODO: implement evaluation batch sampling for {name}.")

    def compute_loss_terms(self, model: torch.nn.Module, batches: object) -> dict[str, torch.Tensor]:
        raise NotImplementedError("TODO: implement loss terms for {name} and keep naming aligned with public task contracts.")
'''

EXTERNAL_TEST_TEMPLATE = '''from __future__ import annotations

import pytest


def test_{function_name}_external_placeholder() -> None:
    pytest.skip("TODO: replace the external scaffold placeholder for {name}.")
'''

EXTERNAL_README_TEMPLATE = '''# {title}

## Purpose
- TODO: explain what this external {kind} integrates with `pinn_bench`.
- Suggested task target: `{task_target}`.
- Suggested protocol target: `{protocol_target}`.

## Minimal Files
- `{code_path}`
- `{test_path}`
- `{config_path}`
- `{card_path}`
- `{checklist_path}`

## Integration Notes
- Keep the implementation small at first and make one runnable path work end-to-end.
- Use the config stub to point at your real entrypoint and benchmark reference artifacts.
- Keep cards/docs in sync with the package/validate/compare flow you intend to support.
- Run `pinn-bench doctor --scaffold-root .` inside this directory before sharing the template.

## Next Steps
- Fill in the template implementation and example config.
- Run `pytest {test_path}`.
- Package one official run as a reference bundle with `pinn-bench package-run <run_dir> --output-dir <bundle_dir>`.
- Validate the bundle with `pinn-bench validate-submission <bundle_dir> --against-benchmark-line v0.5`.
- Compare the bundle against grouped results with `pinn-bench compare-bundle <bundle_dir> --against <grouped_json>`.
- Import a local comparison view with `pinn-bench import-bundle <bundle_dir> --against <grouped_json> --output-dir <dir>`.
'''

EXTERNAL_CONFIG_TEMPLATE = '''external:
  name: {name}
  entrypoint: {entrypoint}
  task_target: {task_target}
  protocol_target: {protocol_target}

reference:
  grouped_json: outputs_v05/_leaderboard/leaderboard_grouped.json
  bundle_dir: outputs_playground/{name}_bundle

notes:
  - TODO: point this config at your external implementation.
  - TODO: keep benchmark_line / compatibility_target expectations explicit if you emit manual bundles.
'''

EXTERNAL_CARD_TEMPLATE = '''# {title}

## Purpose
- TODO: explain the external {kind} and its expected comparison slice.

## Suggested Targets
- Task: `{task_target}`
- Protocol: `{protocol_target}`

## Package / Validate / Compare Notes
- TODO: describe how this template should be packaged.
- TODO: describe what `validate-submission` should accept or warn on.
- TODO: describe the grouped slice you expect `compare-bundle` to use.
'''

EXTERNAL_PROTOCOL_SUPPORT_TEMPLATE = '''schema_version: external_protocol_support.v0.1
kind: external-task
name: {name}
supported_protocols:
  - none
  - TODO_protocol
loss_terms:
  - TODO_loss_term
notes:
  - TODO: explain which public supervision or PDE terms are required.
'''

EXTERNAL_CHECKLIST_TEMPLATE = '''# Integration Checklist

- [ ] Replace all template TODO markers.
- [ ] Make the example config runnable in your environment.
- [ ] Fill in the {card_filename}.
- [ ] Run the generated test stub and replace the skip with real assertions.
- [ ] Run `pinn-bench doctor --scaffold-root <this_dir>` and resolve any missing files or TODO warnings.
- [ ] Package a reference result with `pinn-bench package-run`.
- [ ] Validate it with `pinn-bench validate-submission`.
- [ ] Compare it against grouped results with `pinn-bench compare-bundle`.
- [ ] Optionally export a local comparison view with `pinn-bench import-bundle`.
- [ ] Document any compatibility caveats before sharing the template.
'''

OPERATOR_MODEL_CONFIG_TEMPLATE = '''model:
  name: {name}
  params:
    query_dim: 2
    condition_dim: 1
    output_dim: 1
    hidden_dims: [64, 64]
    activation: tanh

task:
  name: heat1d_field
  params:
    input_dim: 2
    output_dim: 1

train:
  epochs: 10
  lr: 0.001
  seed: 0
  device: cpu

logging:
  backend: basic
  log_every: 1

output:
  root_dir: outputs_playground/{name}

evaluation:
  grid_x: 64
  grid_t: 32

metrics:
  names: [mse, relative_l2, field_mse, field_relative_l2]
'''

OPERATOR_README_TEMPLATE = '''# {title}

## Purpose
- TODO: explain what this operator-ready model is trying to predict.
- Default generated config target: `heat1d_field`.
- Reference preview tasks: `heat1d_field` for the 1D field path and `poisson2d_field` for the 2D field path.
- This scaffold is intentionally preview-oriented and should stay small until one `forward_field(...)` path works end-to-end.

## Minimal Files
- `{code_path}`
- `{test_path}`
- `{config_path}`
- `{card_path}`
- `{checklist_path}`

## Contract Checks
- Implement `forward_field(condition_inputs, query_inputs=None, metadata=None)`.
- Keep `model_mode = "field"`.
- Make output shape compatible with flattened field targets.
- Preserve `task_mode`, `model_mode`, and `evaluation_mode` clarity in any docs or exports you add.

## Recommended Smoke Sequence
```bash
pytest {test_path}
pinn-bench doctor --scaffold-root .
pinn-bench run --config {config_path} --output-dir /tmp/{slug}_heat1d_smoke
```

Once the model is wired into a repo checkout, run one 1D and one 2D reference smoke before proposing preview-matrix changes:

```bash
pinn-bench run --config configs/experiment/heat1d_field_grid_mlp.yaml --output-dir /tmp/{slug}_heat1d_reference
pinn-bench run --config configs/experiment/poisson2d_field_grid_mlp.yaml --output-dir /tmp/{slug}_poisson2d_reference
```

## Review Path
- Inspect `outputs_preview_v06/_leaderboard/leaderboard_grouped.json`.
- Inspect `outputs_preview_v06/_leaderboard/reporting/`.
- Inspect `outputs_preview_v06/_audit/benchmark_summary.md`.

## Next Steps
- Fill in the generated implementation, card, and config.
- Start with the generated `heat1d_field` config, then duplicate it for a `poisson2d_field` smoke once the first path is stable.
- Keep the scaffold preview-only until both the 1D and 2D field paths are understandable.
'''

OPERATOR_CHECKLIST_TEMPLATE = '''# Operator Model Checklist

- [ ] Replace all scaffold TODO markers.
- [ ] Implement `forward_field(...)` and keep the output aligned with flattened targets.
- [ ] Fill in `{card_filename}` with purpose, limitations, and next steps.
- [ ] Make `{config_filename}` runnable.
- [ ] Run `pytest {test_filename}`.
- [ ] Run `pinn-bench doctor --scaffold-root <this_dir>` and resolve any missing-file failures.
- [ ] Smoke the generated config against `heat1d_field`.
- [ ] Duplicate or adapt the config for a `poisson2d_field` smoke before wiring it into a preview matrix.
- [ ] Inspect grouped/reporting/summary outputs after the smoke path is stable.
'''


def _to_class_name(name: str) -> str:
    return "".join(part.capitalize() for part in name.replace("-", "_").split("_"))



def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generate starter configs, starter runs, and extension scaffolds for pinn_bench."
    )
    subparsers = parser.add_subparsers(dest="kind")

    config_parser = subparsers.add_parser("config", help="Generate one starter config from a built-in template.")
    config_parser.add_argument("--template", required=True, type=str, help="Built-in template name or template YAML path.")
    config_parser.add_argument("--out", required=True, type=str, help="Destination YAML path for the generated starter config.")
    config_parser.add_argument("--force", action="store_true", help="Overwrite the destination config if it already exists.")
    config_parser.add_argument(
        "--output-root",
        type=str,
        default=None,
        help="Optional safe playground output root override written into the generated config.",
    )

    run_parser = subparsers.add_parser("run", help="Generate a starter run directory from a built-in template.")
    run_parser.add_argument("--template", required=True, type=str, help="Built-in template name or template YAML path.")
    run_parser.add_argument("--out-dir", required=True, type=str, help="Destination directory for the generated starter run.")
    run_parser.add_argument("--force", action="store_true", help="Reuse the destination directory if it already exists.")
    run_parser.add_argument(
        "--output-root",
        type=str,
        default=None,
        help="Optional safe playground output root written into the generated config.",
    )

    for kind in ["task", "model", "operator-model", "metric", "protocol", "external-model", "external-task"]:
        subparser = subparsers.add_parser(kind, help=f"Generate a {kind} scaffold.")
        subparser.add_argument("name", type=str)
        subparser.add_argument("--dest-root", type=str, default=".")
        if kind in {"task", "model", "operator-model", "protocol"}:
            subparser.add_argument("--with-card", action="store_true", help="Generate a related card stub.")
            subparser.add_argument("--with-config", action="store_true", help="Generate an example config stub.")
        if kind in {"external-model", "external-task"}:
            subparser.add_argument("--with-test", action="store_true", help="Accepted for CLI symmetry; external modes always generate a test stub.")
            subparser.add_argument("--with-card", action="store_true", help="Accepted for CLI symmetry; external modes always generate a card stub.")
            subparser.add_argument("--with-config", action="store_true", help="Accepted for CLI symmetry; external modes always generate an example config.")
            subparser.add_argument("--task-target", type=str, default="heat1d", help="Optional task hint used only in generated comments and examples.")
            subparser.add_argument("--protocol-target", type=str, default="none", help="Optional protocol hint used only in generated comments and examples.")

    card_parser = subparsers.add_parser("card", help="Generate a task/model/protocol card stub.")
    card_parser.add_argument("card_kind", choices=["task", "model", "protocol"], type=str)
    card_parser.add_argument("name", type=str)
    card_parser.add_argument("--dest-root", type=str, default=".")
    return parser


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)



def _scaffold_file(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")



def _card_path(dest_root: Path, card_kind: str, normalized: str) -> Path:
    directory_map = {"task": "tasks", "model": "models", "protocol": "protocols"}
    return dest_root / "docs" / directory_map[card_kind] / f"{normalized}-card.md"



def _config_path(dest_root: Path, normalized: str) -> Path:
    return dest_root / "configs" / "experiment" / f"{normalized}_example.yaml"



def _test_path(dest_root: Path, normalized: str, suffix: str) -> Path:
    return dest_root / "tests" / f"test_{normalized}_{suffix}.py"


def _external_root(dest_root: Path, kind: str, normalized: str) -> Path:
    external_kind = "model" if kind == "external-model" else "task"
    return dest_root / "external_templates" / external_kind / normalized



def generate_scaffold(
    kind: str,
    name: str,
    dest_root: Path,
    *,
    card_kind: str | None = None,
    with_card: bool = False,
    with_config: bool = False,
    task_target: str = "heat1d",
    protocol_target: str = "none",
) -> list[Path]:
    normalized = name.strip().replace("-", "_")
    class_name = _to_class_name(normalized)
    created: list[Path] = []

    if kind == "task":
        task_path = dest_root / "pinn_bench" / "tasks" / f"{normalized}.py"
        test_path = _test_path(dest_root, normalized, "task")
        _scaffold_file(task_path, TASK_TEMPLATE.format(name=normalized, class_name=class_name))
        _scaffold_file(test_path, TASK_TEST_TEMPLATE.format(name=normalized, function_name=normalized))
        created.extend([task_path, test_path])
        if with_card:
            card_path = _card_path(dest_root, "task", normalized)
            _scaffold_file(card_path, CARD_TEMPLATE.format(title=f"{normalized} task card", kind="task"))
            created.append(card_path)
        if with_config:
            config_path = _config_path(dest_root, normalized)
            _scaffold_file(config_path, TASK_CONFIG_TEMPLATE.format(name=normalized))
            created.append(config_path)
        return created

    if kind == "model":
        model_path = dest_root / "pinn_bench" / "models" / f"{normalized}.py"
        test_path = _test_path(dest_root, normalized, "model")
        _scaffold_file(model_path, MODEL_TEMPLATE.format(name=normalized, class_name=class_name))
        _scaffold_file(test_path, MODEL_TEST_TEMPLATE.format(name=normalized, function_name=normalized))
        created.extend([model_path, test_path])
        if with_card:
            card_path = _card_path(dest_root, "model", normalized)
            _scaffold_file(card_path, CARD_TEMPLATE.format(title=f"{normalized} model card", kind="model"))
            created.append(card_path)
        if with_config:
            config_path = _config_path(dest_root, normalized)
            _scaffold_file(config_path, MODEL_CONFIG_TEMPLATE.format(name=normalized))
            created.append(config_path)
        return created

    if kind == "operator-model":
        model_path = dest_root / "pinn_bench" / "models" / f"{normalized}.py"
        test_path = _test_path(dest_root, normalized, "model")
        card_path = _card_path(dest_root, "model", normalized)
        config_path = _config_path(dest_root, normalized)
        readme_path = dest_root / "README.md"
        checklist_path = dest_root / "CHECKLIST.md"

        _scaffold_file(model_path, OPERATOR_MODEL_TEMPLATE.format(name=normalized, class_name=class_name))
        _scaffold_file(test_path, MODEL_TEST_TEMPLATE.format(name=normalized, function_name=normalized))
        _scaffold_file(card_path, CARD_TEMPLATE.format(title=f"{normalized} operator model card", kind="model"))
        _scaffold_file(config_path, OPERATOR_MODEL_CONFIG_TEMPLATE.format(name=normalized))
        _scaffold_file(
            readme_path,
            OPERATOR_README_TEMPLATE.format(
                title=f"{normalized} operator model scaffold",
                code_path=model_path.relative_to(dest_root).as_posix(),
                test_path=test_path.relative_to(dest_root).as_posix(),
                config_path=config_path.relative_to(dest_root).as_posix(),
                card_path=card_path.relative_to(dest_root).as_posix(),
                checklist_path=checklist_path.relative_to(dest_root).as_posix(),
                slug=normalized,
            ),
        )
        _scaffold_file(
            checklist_path,
            OPERATOR_CHECKLIST_TEMPLATE.format(
                card_filename=card_path.relative_to(dest_root).as_posix(),
                config_filename=config_path.relative_to(dest_root).as_posix(),
                test_filename=test_path.relative_to(dest_root).as_posix(),
            ),
        )
        created.extend([model_path, test_path, card_path, config_path, readme_path, checklist_path])
        return created

    if kind == "metric":
        metric_path = dest_root / "pinn_bench" / "metrics" / f"{normalized}.py"
        test_path = _test_path(dest_root, normalized, "metric")
        _scaffold_file(metric_path, METRIC_TEMPLATE.format(name=normalized, function_name=normalized))
        _scaffold_file(test_path, METRIC_TEST_TEMPLATE.format(name=normalized, function_name=normalized))
        return [metric_path, test_path]

    if kind == "protocol":
        protocol_path = dest_root / "pinn_bench" / "robustness" / f"{normalized}.py"
        test_path = _test_path(dest_root, normalized, "protocol")
        _scaffold_file(protocol_path, PROTOCOL_TEMPLATE.format(name=normalized, class_name=class_name))
        _scaffold_file(test_path, PROTOCOL_TEST_TEMPLATE.format(name=normalized, function_name=normalized))
        created.extend([protocol_path, test_path])
        if with_card:
            card_path = _card_path(dest_root, "protocol", normalized)
            _scaffold_file(card_path, CARD_TEMPLATE.format(title=f"{normalized} protocol card", kind="protocol"))
            created.append(card_path)
        if with_config:
            config_path = _config_path(dest_root, normalized)
            _scaffold_file(config_path, PROTOCOL_CONFIG_TEMPLATE.format(name=normalized))
            created.append(config_path)
        return created

    if kind == "card":
        assert card_kind is not None
        card_path = _card_path(dest_root, card_kind, normalized)
        _scaffold_file(card_path, CARD_TEMPLATE.format(title=f"{normalized} {card_kind} card", kind=card_kind))
        return [card_path]

    if kind in {"external-model", "external-task"}:
        root = _external_root(dest_root, kind, normalized)
        code_path = root / f"{normalized}.py"
        test_path = root / "tests" / f"test_{normalized}.py"
        readme_path = root / "README.md"
        checklist_path = root / "CHECKLIST.md"
        config_path = root / "configs" / f"{normalized}_example.yaml"
        card_filename = "model_card.md" if kind == "external-model" else "task_card.md"
        card_path = root / card_filename
        protocol_support_path = root / "protocol_support.yaml"
        template = EXTERNAL_MODEL_TEMPLATE if kind == "external-model" else EXTERNAL_TASK_TEMPLATE
        _scaffold_file(code_path, template.format(name=normalized, class_name=class_name))
        _scaffold_file(test_path, EXTERNAL_TEST_TEMPLATE.format(name=normalized, function_name=normalized))
        _scaffold_file(
            readme_path,
            EXTERNAL_README_TEMPLATE.format(
                title=f"External {'model' if kind == 'external-model' else 'task'} template: {normalized}",
                kind="model" if kind == "external-model" else "task",
                code_path=code_path.relative_to(root),
                test_path=test_path.relative_to(root),
                config_path=config_path.relative_to(root),
                card_path=card_path.relative_to(root),
                checklist_path=checklist_path.relative_to(root),
                task_target=task_target,
                protocol_target=protocol_target,
            ),
        )
        _scaffold_file(
            config_path,
            EXTERNAL_CONFIG_TEMPLATE.format(
                name=normalized,
                entrypoint=f"external_templates/{'model' if kind == 'external-model' else 'task'}/{normalized}/{normalized}.py",
                task_target=task_target,
                protocol_target=protocol_target,
            ),
        )
        _scaffold_file(
            card_path,
            EXTERNAL_CARD_TEMPLATE.format(
                title=f"External {'model' if kind == 'external-model' else 'task'} card: {normalized}",
                kind="model" if kind == "external-model" else "task",
                task_target=task_target,
                protocol_target=protocol_target,
            ),
        )
        _scaffold_file(
            checklist_path,
            EXTERNAL_CHECKLIST_TEMPLATE.format(card_filename=card_filename),
        )
        created = [code_path, test_path, readme_path, config_path, card_path, checklist_path]
        if kind == "external-task":
            _scaffold_file(protocol_support_path, EXTERNAL_PROTOCOL_SUPPORT_TEMPLATE.format(name=normalized))
            created.append(protocol_support_path)
        return created

    raise ValueError(f"Unsupported scaffold kind '{kind}'.")



def build_scaffold_checklist(kind: str, name: str, created: list[Path]) -> list[str]:
    normalized = name.strip().replace("-", "_")
    if kind == "config":
        return [
            f"review the generated starter config at {created[0].name}",
            "run pinn-bench run --config <generated.yaml> against a safe playground output path",
            "use pinn-bench version --json and read-only doctor/audit commands for verification, not canonical root writes",
        ]
    if kind == "run":
        return [
            "review README.md for the exact next commands",
            "keep output.root_dir outside canonical formal or preview roots",
            "run pinn-bench run --config config.yaml before promoting the config into any larger workflow",
        ]
    checklist = [
        "register or import the new module in the package entrypoint used by your runtime flow",
        f"replace scaffold TODOs in the generated {kind} implementation",
    ]
    if kind in {"task", "model", "operator-model", "metric", "protocol"}:
        test_suffix = "task" if kind == "task" else ("model" if kind in {"model", "operator-model"} else kind)
        checklist.append(f"run pytest on tests/test_{normalized}_{test_suffix}.py")
    config_paths = [path for path in created if path.name.endswith("_example.yaml")]
    if config_paths:
        checklist.append(f"use {config_paths[0]} as the starting config")
    if kind in {"task", "model", "operator-model", "protocol"}:
        checklist.append("connect related docs, presets, and registry imports if you want the new component auto-discoverable")
    if kind == "operator-model":
        checklist.append("review the generated README.md and CHECKLIST.md before wiring the scaffold into a preview slice")
        checklist.append("run pinn-bench doctor --scaffold-root on the generated root")
        checklist.append("use the generated config for a heat1d_field smoke, then adapt it for a poisson2d_field smoke")
        checklist.append("inspect grouped/reporting/summary assets after the smoke path is stable")
    if kind in {"external-model", "external-task"}:
        checklist.extend(
            [
                "fill in the external template README and example config",
                "run pinn-bench doctor --scaffold-root on the generated template root",
                "package a reference run with pinn-bench package-run",
                "validate the resulting bundle with pinn-bench validate-submission",
                "compare the bundle against grouped results with pinn-bench compare-bundle",
                "optionally export a local comparison view with pinn-bench import-bundle",
            ]
        )
    return checklist


def main(argv: Sequence[str] | None = None) -> None:
    args = parse_args(argv)
    if args.kind is None or args.kind in {"-h", "--help"}:
        build_parser().print_help()
        return

    if args.kind in {"config", "run"}:
        try:
            destination = args.out if args.kind == "config" else args.out_dir
            created = create_user_scaffold(
                args.kind,
                args.template,
                destination,
                force=bool(getattr(args, "force", False)),
                output_root=getattr(args, "output_root", None),
            )
        except (FileExistsError, FileNotFoundError, ValueError) as error:
            raise SystemExit(str(error))
        print("Generated artifacts:")
        for path in created:
            print(f"- {path.resolve()}")
        print("Checklist:")
        for item in build_scaffold_checklist(args.kind, Path(str(args.template)).stem, created):
            print(f"- {item}")
        return

    destination_root = Path(args.dest_root).resolve()
    if args.kind == "card":
        created = generate_scaffold("card", args.name, destination_root, card_kind=args.card_kind)
    else:
        created = generate_scaffold(
            args.kind,
            args.name,
            destination_root,
            with_card=bool(getattr(args, "with_card", False)),
            with_config=bool(getattr(args, "with_config", False)),
            task_target=str(getattr(args, "task_target", "heat1d")),
            protocol_target=str(getattr(args, "protocol_target", "none")),
        )
    print("Generated artifacts:")
    for path in created:
        print(f"- {path.resolve()}")
    print("Checklist:")
    for item in build_scaffold_checklist(args.kind, args.name, created):
        print(f"- {item}")


if __name__ == "__main__":
    main()
