"""Typed interfaces for additive abstraction layers."""

from pinn_bench.interfaces.model_capabilities import CapabilityClass, CapabilityDescriptor, ModelCapabilityAssignment
from pinn_bench.interfaces.observation_types import (
    ObservationDescriptor,
    ObservationType,
    TargetDescriptor,
    TargetType,
    TaskObservationTargetAssignment,
)

__all__ = [
    'CapabilityClass',
    'CapabilityDescriptor',
    'ModelCapabilityAssignment',
    'ObservationDescriptor',
    'ObservationType',
    'TargetDescriptor',
    'TargetType',
    'TaskObservationTargetAssignment',
]
