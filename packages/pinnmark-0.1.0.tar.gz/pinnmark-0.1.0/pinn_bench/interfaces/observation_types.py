"""Typed observation/target interfaces for v1.4-preview."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class ObservationType(str, Enum):
    POINT_OBSERVATION = 'point_observation'
    FIELD_OBSERVATION = 'field_observation'
    TRAJECTORY_OBSERVATION = 'trajectory_observation'
    OPERATOR_CONDITION_OBSERVATION = 'operator_condition_observation'


class TargetType(str, Enum):
    POINT_TARGET = 'point_target'
    FIELD_TARGET = 'field_target'
    TRAJECTORY_TARGET = 'trajectory_target'
    OPERATOR_RESPONSE_TARGET = 'operator_response_target'


@dataclass(frozen=True)
class ObservationDescriptor:
    observation_type: ObservationType
    summary: str
    future_facing: bool = False


@dataclass(frozen=True)
class TargetDescriptor:
    target_type: TargetType
    summary: str
    future_facing: bool = False


@dataclass(frozen=True)
class TaskObservationTargetAssignment:
    task_name: str
    observation_type: ObservationType
    target_type: TargetType
    task_mode: str
    supports_operator: bool
