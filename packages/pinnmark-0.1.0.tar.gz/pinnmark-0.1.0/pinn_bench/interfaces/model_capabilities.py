"""Typed model-capability interfaces for v1.4-preview."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class CapabilityClass(str, Enum):
    POINTWISE_SOLUTION_MODEL = 'pointwise_solution_model'
    FIELDWISE_SOLUTION_MODEL = 'fieldwise_solution_model'
    TRAJECTORY_SOLUTION_MODEL = 'trajectory_solution_model'
    OPERATOR_RESPONSE_MODEL = 'operator_response_model'
    HYBRID_PHYSICS_MODEL = 'hybrid_physics_model'


@dataclass(frozen=True)
class CapabilityDescriptor:
    capability_class: CapabilityClass
    summary: str
    interface_shape: str
    future_facing: bool = False


@dataclass(frozen=True)
class ModelCapabilityAssignment:
    model_name: str
    capability_class: CapabilityClass
    operator_ready_flag: bool
    evidence: tuple[str, ...] = ()
