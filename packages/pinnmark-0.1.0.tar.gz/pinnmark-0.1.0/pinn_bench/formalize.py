"""Explicit formal-freeze workflow for packaging a preview line into a formal root."""

from __future__ import annotations

import argparse
import json
import shutil
from collections.abc import Mapping, Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from pinn_bench.leaderboard.summary import render_benchmark_summary
from pinn_bench.resources import resolve_manifest_path, resolve_outputs_root, resolve_repo_root
from pinn_bench.utils.io import write_json

PROTECTED_FORMAL_ROOT_NAMES = {"outputs", "outputs_v02", "outputs_v03", "outputs_v04", "outputs_v05", "outputs_v06"}
SUPPORTED_SOURCE_PREVIEW = "v0.9-preview"
SUPPORTED_TARGET_VERSION = "v1.0"
SOURCE_MANIFEST_NAME = "baseline_v0_9_preview.yaml"
TARGET_MANIFEST_NAME = "baseline_v1_0_formal.yaml"
SOURCE_MATRIX_NAME = "baseline_v0_9_preview"
TARGET_MATRIX_NAME = "baseline_v1_0_formal"
FORMAL_ANALYSIS_FILES = [
    "freeze_packet.json",
    "freeze_packet.md",
    "freeze_readiness_report.json",
    "freeze_readiness_report.md",
    "formal_baseline_summary.md",
    "v1_0_formal_manifest.json",
    "v1_0_formal_manifest.md",
    "freeze_governance_record.md",
    "freeze_decision_brief.md",
]
TEXT_REPLACEMENTS = {
    SOURCE_MATRIX_NAME: TARGET_MATRIX_NAME,
    "baseline_v0_9_preview.yaml": TARGET_MANIFEST_NAME,
    "outputs_preview_v09": "outputs_v10",
    "v0.9-preview": "v1.0",
}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Formalize a validated preview root into a self-contained formal root.")
    parser.add_argument("--from-preview", required=True, type=str, help="Source preview line. Only v0.9-preview is supported.")
    parser.add_argument("--source-root", required=True, type=str, help="Source preview outputs root.")
    parser.add_argument("--target-root", required=True, type=str, help="Target formal outputs root.")
    parser.add_argument("--target-version", required=True, type=str, help="Target formal version label. Only v1.0 is supported.")
    parser.add_argument("--dry-run", action="store_true", help="Validate inputs and print the formalization plan without writing files.")
    parser.add_argument("--json", action="store_true", help="Emit machine-readable plan or execution details.")
    return parser



def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)



def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()



def _load_json(path: Path, *, label: str) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError(f"{label} must contain a JSON object: {path}")
    return dict(payload)



def _load_yaml(path: Path, *, label: str) -> dict[str, Any]:
    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError(f"{label} must contain a YAML mapping: {path}")
    return dict(payload)



def _assert_safe_target(target_root: Path) -> None:
    if target_root.name in PROTECTED_FORMAL_ROOT_NAMES:
        raise ValueError(f"Refusing to formalize into protected frozen root '{target_root.name}'.")



def _replace_values(payload: Any, replacements: Mapping[str, str]) -> Any:
    if isinstance(payload, str):
        text = payload
        for old, new in replacements.items():
            text = text.replace(old, new)
        return text
    if isinstance(payload, list):
        return [_replace_values(item, replacements) for item in payload]
    if isinstance(payload, dict):
        return {key: _replace_values(value, replacements) for key, value in payload.items()}
    return payload



def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")



def _required_source_paths(source_root: Path) -> dict[str, Path]:
    return {
        "grouped_json": source_root / "_leaderboard" / "leaderboard_grouped.json",
        "reporting_csv": source_root / "_leaderboard" / "reporting" / f"{SOURCE_MATRIX_NAME}_baseline_table.csv",
        "pareto_csv": source_root / "_leaderboard" / "pareto" / f"{SOURCE_MATRIX_NAME}_pareto.csv",
        "run_report_json": source_root / "_matrix_runs" / f"{SOURCE_MATRIX_NAME}_run_report.json",
        "release_snapshot": source_root / "_release_snapshot.json",
        "analysis_bundle": source_root / "_analysis" / "analysis_bundle.json",
        "decision_support": source_root / "_analysis" / "decision_support.json",
        "review_packet": source_root / "_analysis" / "review_packet.json",
        "promotion_gap_report": source_root / "_analysis" / "promotion_gap_report.json",
        "cross_version_review": source_root / "_analysis" / "cross_version_review.json",
        "preview_audit": source_root / "_audit" / "v0.9-preview" / "v0_9_preview_audit.json",
        "robustness_summary": source_root / "_audit" / "robustness_summary.json",
    }



def _load_context(*, from_preview: str, source_root: Path, target_root: Path, target_version: str) -> dict[str, Any]:
    if from_preview != SUPPORTED_SOURCE_PREVIEW:
        raise ValueError(f"Unsupported source preview '{from_preview}'. Only '{SUPPORTED_SOURCE_PREVIEW}' is supported.")
    if target_version != SUPPORTED_TARGET_VERSION:
        raise ValueError(f"Unsupported target version '{target_version}'. Only '{SUPPORTED_TARGET_VERSION}' is supported.")

    source_root = source_root.resolve()
    target_root = target_root.resolve()
    if source_root == target_root:
        raise ValueError("Source and target roots must be different.")
    _assert_safe_target(target_root)

    required = _required_source_paths(source_root)
    missing = [str(path) for path in required.values() if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Formalize source is incomplete. Missing required paths: {', '.join(sorted(missing))}")

    repo_root = resolve_repo_root(source_root)
    source_manifest_path = resolve_manifest_path(SOURCE_MANIFEST_NAME)
    target_manifest_path = resolve_manifest_path(TARGET_MANIFEST_NAME)
    source_manifest = _load_yaml(source_manifest_path, label="source preview manifest")
    target_manifest = _load_yaml(target_manifest_path, label="target formal manifest")
    analysis_bundle = _load_json(required["analysis_bundle"], label="analysis bundle")
    decision_support = _load_json(required["decision_support"], label="decision support")
    review_packet = _load_json(required["review_packet"], label="review packet")
    promotion_gap_report = _load_json(required["promotion_gap_report"], label="promotion gap report")
    cross_version_review = _load_json(required["cross_version_review"], label="cross-version review")
    preview_audit = _load_json(required["preview_audit"], label="preview audit")
    release_snapshot = _load_json(required["release_snapshot"], label="release snapshot")

    if review_packet.get("analysis_readiness_conclusion") != "ready_for_formal_discussion":
        raise ValueError("Source preview is not marked ready_for_formal_discussion.")
    if decision_support.get("formal_discussion_recommendation") != "ready_for_formal_discussion":
        raise ValueError("Source decision support does not recommend ready_for_formal_discussion.")
    if bool(review_packet.get("should_formalize_v0_9")):
        raise ValueError("Historical truth drift detected: should_formalize_v0_9 must remain false in the source preview record.")
    if bool(review_packet.get("open_v1_0_preview")):
        raise ValueError("Historical truth drift detected: open_v1_0_preview must remain false in the source preview record.")
    if str(promotion_gap_report.get("smallest_remaining_gap")) != "governance_caution":
        raise ValueError("Source preview does not report governance_caution as the smallest remaining gap.")
    if str(preview_audit.get("verdict", {}).get("status")) != "ready_for_preview_only":
        raise ValueError("Source preview audit verdict must remain ready_for_preview_only.")
    if str(review_packet.get("current_formal_line")) != "v0.6":
        raise ValueError("Historical source review packet must still report v0.6 as the current formal line.")
    if str(review_packet.get("current_preview_line")) != SUPPORTED_SOURCE_PREVIEW:
        raise ValueError("Historical source review packet must still report v0.9-preview as the current preview line.")

    expected_target_fields = {
        "version": SUPPORTED_TARGET_VERSION,
        "status": "formal",
        "source_preview": SUPPORTED_SOURCE_PREVIEW,
        "source_outputs_root": "outputs_preview_v09",
        "formal_outputs_root": "outputs_v10",
        "slice_policy": "exact_carry_forward",
        "rewrite_trainer": False,
        "rewrite_evaluator": False,
        "rewrite_main_results_schema": False,
        "mass_content_expansion": False,
        "platform_expansion_included": False,
    }
    for key, expected in expected_target_fields.items():
        if target_manifest.get(key) != expected:
            raise ValueError(f"Target manifest field '{key}' must equal {expected!r}.")

    counts = dict(analysis_bundle.get("counts") or {})
    if counts.get("grouped_rows") != 32 or counts.get("reporting_rows") != 32 or counts.get("pareto_rows") != 32:
        raise ValueError("Source preview counts do not match the expected 32/32/32 grouped/reporting/pareto shape.")
    if counts.get("robustness_rows") != 13 or counts.get("field_grouped_rows") != 26 or counts.get("planned_runs") != 96:
        raise ValueError("Source preview counts do not match the expected 13/26/96 robustness/field/planned shape.")
    if len(source_manifest.get("runs") or []) != 32:
        raise ValueError("Source preview manifest must contain 32 runs.")
    if len(target_manifest.get("runs") or []) != 32:
        raise ValueError("Target formal manifest must contain 32 runs.")

    replacements = dict(TEXT_REPLACEMENTS)
    replacements[str(source_root)] = str(target_root)
    replacements[str(source_manifest_path.resolve())] = str(target_manifest_path.resolve())

    return {
        "repo_root": repo_root,
        "source_root": source_root,
        "source_manifest_path": source_manifest_path.resolve(),
        "source_manifest": source_manifest,
        "target_root": target_root,
        "target_manifest_path": target_manifest_path.resolve(),
        "target_manifest": target_manifest,
        "analysis_bundle": analysis_bundle,
        "decision_support": decision_support,
        "review_packet": review_packet,
        "promotion_gap_report": promotion_gap_report,
        "cross_version_review": cross_version_review,
        "preview_audit": preview_audit,
        "release_snapshot": release_snapshot,
        "counts": counts,
        "replacements": replacements,
    }



def _copied_assets() -> list[str]:
    return [
        "_leaderboard/",
        "_matrix_runs/",
        "_audit/robustness_summary.json",
        "_audit/robustness_summary.md",
        "_release_snapshot.json",
    ]



def _generated_assets() -> list[str]:
    generated = [f"_analysis/{name}" for name in FORMAL_ANALYSIS_FILES]
    generated.extend([
        "_audit/benchmark_summary.md",
        "_leaderboard/benchmark_summary.md",
    ])
    return generated



def _excluded_assets() -> list[str]:
    return [
        "_analysis/history/",
        "_analysis/formal_discussion_brief.md",
        "_analysis/formal_discussion_memo.md",
        "_analysis/formal_discussion_checklist.md",
        "_audit/v0.9-preview/",
    ]



def build_formalize_plan(*, from_preview: str, source_root: Path, target_root: Path, target_version: str) -> dict[str, Any]:
    context = _load_context(
        from_preview=from_preview,
        source_root=source_root,
        target_root=target_root,
        target_version=target_version,
    )
    return {
        "command": "formalize",
        "dry_run": True,
        "generated_at": _utc_now(),
        "source_preview_line": from_preview,
        "source_root": str(context["source_root"]),
        "source_manifest": str(context["source_manifest_path"]),
        "target_version": target_version,
        "target_root": str(context["target_root"]),
        "target_manifest": str(context["target_manifest_path"]),
        "source_state": {
            "historical_current_formal_line": context["review_packet"]["current_formal_line"],
            "historical_current_preview_line": context["review_packet"]["current_preview_line"],
            "analysis_readiness_conclusion": context["review_packet"]["analysis_readiness_conclusion"],
            "formal_discussion_recommendation": context["decision_support"]["formal_discussion_recommendation"],
            "smallest_remaining_gap": context["promotion_gap_report"]["smallest_remaining_gap"],
            "audit_verdict": context["preview_audit"]["verdict"]["status"],
            "counts": context["counts"],
        },
        "copy_plan": _copied_assets(),
        "generated_assets": _generated_assets(),
        "excluded_assets": _excluded_assets(),
        "policy_references": [
            "docs/product/v1_0_freeze_boundary.md",
            "docs/product/v1_0_formal_contents.md",
            "docs/product/v1_0_freeze_decision.md",
            "docs/product/post_v1_0_rules.md",
            str(context["target_manifest_path"]),
        ],
        "protected_formal_roots": sorted(PROTECTED_FORMAL_ROOT_NAMES),
    }



def _render_plan_text(plan: Mapping[str, Any]) -> str:
    lines = [
        "# Formalize Plan",
        "",
        f"- Source preview line: `{plan['source_preview_line']}`",
        f"- Source root: `{plan['source_root']}`",
        f"- Target version: `{plan['target_version']}`",
        f"- Target root: `{plan['target_root']}`",
        f"- Historical current formal line: `{plan['source_state']['historical_current_formal_line']}`",
        f"- Historical current preview line: `{plan['source_state']['historical_current_preview_line']}`",
        f"- Analysis readiness: `{plan['source_state']['analysis_readiness_conclusion']}`",
        f"- Preview audit verdict: `{plan['source_state']['audit_verdict']}`",
        f"- Smallest remaining gap: `{plan['source_state']['smallest_remaining_gap']}`",
        f"- Counts: `{plan['source_state']['counts']}`",
        "",
        "## Copied Assets",
    ]
    for item in plan["copy_plan"]:
        lines.append(f"- `{item}`")
    lines.extend(["", "## Generated Assets"])
    for item in plan["generated_assets"]:
        lines.append(f"- `{item}`")
    lines.extend(["", "## Excluded Assets"])
    for item in plan["excluded_assets"]:
        lines.append(f"- `{item}`")
    lines.extend(["", "## Policy References"])
    for item in plan["policy_references"]:
        lines.append(f"- `{item}`")
    return "\n".join(lines)



def _copy_core_assets(context: Mapping[str, Any]) -> None:
    source_root = Path(str(context["source_root"]))
    target_root = Path(str(context["target_root"]))
    if target_root.exists():
        shutil.rmtree(target_root)
    target_root.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source_root / "_leaderboard", target_root / "_leaderboard")
    shutil.copytree(source_root / "_matrix_runs", target_root / "_matrix_runs")
    (target_root / "_audit").mkdir(parents=True, exist_ok=True)
    shutil.copy2(source_root / "_audit" / "robustness_summary.json", target_root / "_audit" / "robustness_summary.json")
    shutil.copy2(source_root / "_audit" / "robustness_summary.md", target_root / "_audit" / "robustness_summary.md")
    shutil.copy2(source_root / "_release_snapshot.json", target_root / "_release_snapshot.json")



def _rename_paths_with_target_basename(target_root: Path) -> None:
    for path in sorted(target_root.rglob(f"*{SOURCE_MATRIX_NAME}*"), reverse=True):
        renamed = path.with_name(path.name.replace(SOURCE_MATRIX_NAME, TARGET_MATRIX_NAME))
        path.rename(renamed)



def _rewrite_textual_assets(context: Mapping[str, Any]) -> None:
    target_root = Path(str(context["target_root"]))
    replacements = dict(context["replacements"])
    for path in sorted(target_root.rglob("*")):
        if not path.is_file() or path.suffix not in {".json", ".csv", ".md", ".tex"}:
            continue
        if path.suffix == ".json":
            payload = _load_json(path, label=f"formalize copy {path.name}")
            rewritten = _replace_values(payload, replacements)
            path.write_text(json.dumps(rewritten, indent=2), encoding="utf-8")
            continue
        text = path.read_text(encoding="utf-8")
        for old, new in replacements.items():
            text = text.replace(old, new)
        path.write_text(text, encoding="utf-8")



def _rewrite_release_snapshot_and_run_report(context: Mapping[str, Any]) -> None:
    target_root = Path(str(context["target_root"]))
    release_snapshot_path = target_root / "_release_snapshot.json"
    release_snapshot = _load_json(release_snapshot_path, label="target release snapshot")
    release_snapshot.update(
        {
            "version": SUPPORTED_TARGET_VERSION,
            "matrix_name": TARGET_MATRIX_NAME,
            "manifest_path": str(context["target_manifest_path"]),
            "outputs_root": str(target_root),
            "source_preview_line": SUPPORTED_SOURCE_PREVIEW,
            "source_outputs_root": str(context["source_root"]),
            "formalization_act": "pinn-bench formalize",
        }
    )
    release_snapshot_path.write_text(json.dumps(release_snapshot, indent=2), encoding="utf-8")

    run_report_path = target_root / "_matrix_runs" / f"{TARGET_MATRIX_NAME}_run_report.json"
    run_report = _load_json(run_report_path, label="target run report")
    run_report.update(
        {
            "matrix_name": TARGET_MATRIX_NAME,
            "manifest_path": str(context["target_manifest_path"]),
            "outputs_root": str(target_root),
            "source_preview_line": SUPPORTED_SOURCE_PREVIEW,
            "source_outputs_root": str(context["source_root"]),
        }
    )
    run_report_path.write_text(json.dumps(run_report, indent=2), encoding="utf-8")



def _write_benchmark_summaries(context: Mapping[str, Any]) -> None:
    target_root = Path(str(context["target_root"]))
    grouped_json_path = target_root / "_leaderboard" / "leaderboard_grouped.json"
    grouped_payload = _load_json(grouped_json_path, label="target grouped leaderboard")
    summary_text = render_benchmark_summary(grouped_payload, grouped_json_path=grouped_json_path, analysis_bundle=None)
    _write_text(target_root / "_leaderboard" / "benchmark_summary.md", summary_text)
    _write_text(target_root / "_audit" / "benchmark_summary.md", summary_text)



def _included_asset_paths(target_root: Path) -> list[str]:
    files = [path.relative_to(target_root).as_posix() for path in sorted(target_root.rglob("*")) if path.is_file()]
    return files



def _build_freeze_packet(context: Mapping[str, Any], *, target_root: Path) -> dict[str, Any]:
    cross_review = dict(context["cross_version_review"].get("preview_vs_previous_preview") or {})
    return {
        "schema_version": "formal_freeze_packet.v1",
        "generated_at": _utc_now(),
        "target_version": SUPPORTED_TARGET_VERSION,
        "target_outputs_root": str(target_root),
        "target_manifest_path": str(context["target_manifest_path"]),
        "source_preview_line": SUPPORTED_SOURCE_PREVIEW,
        "source_outputs_root": str(context["source_root"]),
        "source_manifest_path": str(context["source_manifest_path"]),
        "historical_source_state": {
            "current_formal_line": context["review_packet"]["current_formal_line"],
            "current_preview_line": context["review_packet"]["current_preview_line"],
            "analysis_readiness_conclusion": context["review_packet"]["analysis_readiness_conclusion"],
            "formal_discussion_recommendation": context["decision_support"]["formal_discussion_recommendation"],
            "audit_verdict": context["preview_audit"]["verdict"]["status"],
            "should_formalize_v0_9": context["review_packet"]["should_formalize_v0_9"],
            "open_v1_0_preview": context["review_packet"]["open_v1_0_preview"],
            "smallest_remaining_gap": context["promotion_gap_report"]["smallest_remaining_gap"],
        },
        "counts": context["counts"],
        "slice_policy": "exact_carry_forward",
        "meaningful_delta": cross_review.get("meaningful_delta"),
        "included_assets": _copied_assets() + _generated_assets(),
        "excluded_assets": _excluded_assets(),
        "policy_references": [
            "docs/product/v1_0_freeze_boundary.md",
            "docs/product/v1_0_formal_contents.md",
            "docs/product/v1_0_freeze_decision.md",
            "docs/product/post_v1_0_rules.md",
        ],
    }



def _render_freeze_packet_markdown(payload: Mapping[str, Any]) -> str:
    state = payload["historical_source_state"]
    lines = [
        "# Freeze Packet",
        "",
        f"- Target version: `{payload['target_version']}`",
        f"- Target outputs root: `{payload['target_outputs_root']}`",
        f"- Source preview line: `{payload['source_preview_line']}`",
        f"- Source outputs root: `{payload['source_outputs_root']}`",
        f"- Historical current formal line: `{state['current_formal_line']}`",
        f"- Historical current preview line: `{state['current_preview_line']}`",
        f"- Historical discussion recommendation: `{state['formal_discussion_recommendation']}`",
        f"- Historical audit verdict: `{state['audit_verdict']}`",
        f"- Historical `should_formalize_v0_9`: `{state['should_formalize_v0_9']}`",
        f"- Historical `open_v1_0_preview`: `{state['open_v1_0_preview']}`",
        f"- Smallest remaining gap at source closeout: `{state['smallest_remaining_gap']}`",
        f"- Slice policy: `{payload['slice_policy']}`",
        f"- Meaningful delta carried into freeze: `{payload['meaningful_delta']}`",
        f"- Counts: `{payload['counts']}`",
        "",
        "This packet records an explicit formalization act. It does not claim that `v0.9-preview` auto-promoted itself.",
    ]
    return "\n".join(lines)



def _build_freeze_readiness_report(context: Mapping[str, Any], *, target_root: Path) -> dict[str, Any]:
    decision_support = context["decision_support"]
    preview_audit = context["preview_audit"]
    counts = context["counts"]
    return {
        "schema_version": "formal_freeze_readiness.v1",
        "generated_at": _utc_now(),
        "target_version": SUPPORTED_TARGET_VERSION,
        "target_outputs_root": str(target_root),
        "readiness_summary": {
            "historical_discussion_grade": context["review_packet"]["analysis_readiness_conclusion"],
            "historical_preview_audit": preview_audit["verdict"]["status"],
            "historical_smallest_gap": context["promotion_gap_report"]["smallest_remaining_gap"],
            "bounded_freeze_decision": True,
            "old_formal_roots_protected": True,
            "schema_rewrite_enabled": False,
            "slice_expansion_enabled": False,
        },
        "counts": counts,
        "residual_cautions": [
            "governance_caution was recorded and accepted explicitly rather than rewritten away.",
            "No new preview line is opened as part of this freeze.",
        ],
        "policy_references": [
            "docs/product/v1_0_freeze_decision.md",
            "docs/product/v1_0_governance_record.md",
            "docs/product/post_v1_0_rules.md",
        ],
        "formal_discussion_recommendation": decision_support["formal_discussion_recommendation"],
    }



def _render_freeze_readiness_markdown(payload: Mapping[str, Any]) -> str:
    readiness = payload["readiness_summary"]
    lines = [
        "# Freeze Readiness Report",
        "",
        f"- Historical discussion grade: `{readiness['historical_discussion_grade']}`",
        f"- Historical preview audit: `{readiness['historical_preview_audit']}`",
        f"- Historical smallest gap: `{readiness['historical_smallest_gap']}`",
        f"- Bounded freeze decision: `{readiness['bounded_freeze_decision']}`",
        f"- Old formal roots protected: `{readiness['old_formal_roots_protected']}`",
        f"- Schema rewrite enabled: `{readiness['schema_rewrite_enabled']}`",
        f"- Slice expansion enabled: `{readiness['slice_expansion_enabled']}`",
        f"- Counts: `{payload['counts']}`",
        "",
        "## Residual Cautions",
    ]
    for item in payload["residual_cautions"]:
        lines.append(f"- {item}")
    return "\n".join(lines)



def _build_formal_manifest_payload(context: Mapping[str, Any], *, target_root: Path) -> dict[str, Any]:
    return {
        "schema_version": "v1_0_formal_manifest.v1",
        "generated_at": _utc_now(),
        "version": SUPPORTED_TARGET_VERSION,
        "human_label": "v1.0-formal",
        "source_preview": SUPPORTED_SOURCE_PREVIEW,
        "source_outputs_root": str(context["source_root"]),
        "formal_outputs_root": str(target_root),
        "formal_manifest_path": str(context["target_manifest_path"]),
        "counts": context["counts"],
        "included_asset_paths": _included_asset_paths(target_root),
        "policy_references": [
            "docs/product/v1_0_freeze_boundary.md",
            "docs/product/v1_0_formal_contents.md",
            "docs/product/post_v1_0_rules.md",
        ],
    }



def _render_formal_manifest_markdown(payload: Mapping[str, Any]) -> str:
    lines = [
        "# v1.0 Formal Manifest",
        "",
        f"- Version: `{payload['version']}`",
        f"- Human label: `{payload['human_label']}`",
        f"- Source preview: `{payload['source_preview']}`",
        f"- Source outputs root: `{payload['source_outputs_root']}`",
        f"- Formal outputs root: `{payload['formal_outputs_root']}`",
        f"- Formal manifest path: `{payload['formal_manifest_path']}`",
        f"- Counts: `{payload['counts']}`",
        "",
        "## Included Asset Paths",
    ]
    for item in payload["included_asset_paths"]:
        lines.append(f"- `{item}`")
    return "\n".join(lines)



def _render_formal_baseline_summary(context: Mapping[str, Any]) -> str:
    counts = context["counts"]
    lines = [
        "# Formal Baseline Summary",
        "",
        f"`v1.0` freezes the validated `v0.9-preview` line into the canonical formal root `outputs_v10`.",
        "",
        "## What Carries Forward",
        "- Exact carry-forward of the `v0.8` / `v0.9` 32-row slice.",
        "- Trust, reproducibility, submission-review, and governance maturity documented during `v0.9-preview`.",
        "- No trainer, evaluator, or main result schema rewrite.",
        "",
        "## Canonical Counts",
        f"- grouped rows: `{counts['grouped_rows']}`",
        f"- reporting rows: `{counts['reporting_rows']}`",
        f"- pareto rows: `{counts['pareto_rows']}`",
        f"- robustness rows: `{counts['robustness_rows']}`",
        f"- field grouped rows: `{counts['field_grouped_rows']}`",
        f"- planned runs: `{counts['planned_runs']}`",
        "",
        "## Historical Truth",
        "- `v0.9-preview` was discussion-ready rather than auto-formalized.",
        "- `v1.0` is a stability-first formal freeze, not a breadth expansion.",
        "- future work must proceed on a new preview or platform line instead of mutating `outputs_v10`.",
    ]
    return "\n".join(lines)



def _render_governance_record(context: Mapping[str, Any]) -> str:
    return "\n".join(
        [
            "# Freeze Governance Record",
            "",
            "`governance_caution` remained the smallest remaining gap at the end of `v0.9-preview`.",
            "It was accepted explicitly as part of the bounded `v1.0` freeze decision rather than hidden or reinterpreted as an engineering blocker.",
            "",
            "The freeze therefore records two truths together:",
            "- historical preview governance never claimed automatic formalization",
            "- explicit freeze approval later accepted the caution within a stability-first boundary",
        ]
    )



def _render_decision_brief(context: Mapping[str, Any]) -> str:
    return "\n".join(
        [
            "# Freeze Decision Brief",
            "",
            "`v1.0` is the explicit formal freeze of the validated `v0.9-preview` line.",
            "",
            "## Why This Freeze Is Bounded",
            "- It carries forward the validated 32-row slice without expanding benchmark breadth.",
            "- It packages trust, reproducibility, submission maturity, and governance evidence into a self-contained formal root.",
            "- It keeps historical truth intact: `should_formalize_v0_9 = false` remained true during preview governance.",
            "",
            "## What It Does Not Mean",
            "- It is not an automatic promotion of `v0.9-preview`.",
            "- It is not a new preview opening.",
            "- It is not a platform-expansion release.",
        ]
    )



def _write_formal_analysis_assets(context: Mapping[str, Any]) -> list[Path]:
    target_root = Path(str(context["target_root"]))
    analysis_dir = target_root / "_analysis"
    analysis_dir.mkdir(parents=True, exist_ok=True)

    freeze_packet = _build_freeze_packet(context, target_root=target_root)
    freeze_readiness = _build_freeze_readiness_report(context, target_root=target_root)
    formal_manifest_payload = _build_formal_manifest_payload(context, target_root=target_root)

    outputs = {
        analysis_dir / "freeze_packet.json": freeze_packet,
        analysis_dir / "freeze_readiness_report.json": freeze_readiness,
        analysis_dir / "v1_0_formal_manifest.json": formal_manifest_payload,
    }
    for path, payload in outputs.items():
        write_json(path, payload)

    markdown_outputs = {
        analysis_dir / "freeze_packet.md": _render_freeze_packet_markdown(freeze_packet),
        analysis_dir / "freeze_readiness_report.md": _render_freeze_readiness_markdown(freeze_readiness),
        analysis_dir / "formal_baseline_summary.md": _render_formal_baseline_summary(context),
        analysis_dir / "v1_0_formal_manifest.md": _render_formal_manifest_markdown(formal_manifest_payload),
        analysis_dir / "freeze_governance_record.md": _render_governance_record(context),
        analysis_dir / "freeze_decision_brief.md": _render_decision_brief(context),
    }
    for path, text in markdown_outputs.items():
        _write_text(path, text)
    return sorted(list(outputs) + list(markdown_outputs))



def execute_formalize(*, from_preview: str, source_root: Path, target_root: Path, target_version: str) -> dict[str, Any]:
    context = _load_context(
        from_preview=from_preview,
        source_root=source_root,
        target_root=target_root,
        target_version=target_version,
    )
    target_root = Path(str(context["target_root"]))
    _copy_core_assets(context)
    _rename_paths_with_target_basename(target_root)
    _rewrite_textual_assets(context)
    _rewrite_release_snapshot_and_run_report(context)
    _write_benchmark_summaries(context)
    written_analysis_assets = _write_formal_analysis_assets(context)

    return {
        "command": "formalize",
        "dry_run": False,
        "generated_at": _utc_now(),
        "source_preview_line": from_preview,
        "source_root": str(context["source_root"]),
        "target_version": target_version,
        "target_root": str(target_root),
        "target_manifest": str(context["target_manifest_path"]),
        "written_analysis_assets": [str(path.resolve()) for path in written_analysis_assets],
        "counts": context["counts"],
    }



def main(argv: Sequence[str] | None = None) -> None:
    args = parse_args(argv)
    source_root = resolve_outputs_root(args.source_root)
    target_root = resolve_outputs_root(args.target_root)
    if args.dry_run:
        plan = build_formalize_plan(
            from_preview=args.from_preview,
            source_root=source_root,
            target_root=target_root,
            target_version=args.target_version,
        )
        if args.json:
            print(json.dumps(plan, indent=2))
        else:
            print(_render_plan_text(plan))
        return

    payload = execute_formalize(
        from_preview=args.from_preview,
        source_root=source_root,
        target_root=target_root,
        target_version=args.target_version,
    )
    if args.json:
        print(json.dumps(payload, indent=2))
        return
    print(
        "Formalized {source} -> {target} as {version}.".format(
            source=payload["source_root"],
            target=payload["target_root"],
            version=payload["target_version"],
        )
    )


if __name__ == "__main__":
    main()
