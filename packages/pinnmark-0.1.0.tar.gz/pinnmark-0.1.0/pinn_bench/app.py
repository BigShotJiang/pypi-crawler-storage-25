"""Top-level product CLI for pinn_bench."""

from __future__ import annotations

import argparse
from collections.abc import Sequence
import sys

from pinn_bench.analysis.cli import main as analysis_main
from pinn_bench.audit import main as audit_main
from pinn_bench.community.compare_bundle import main as compare_bundle_main
from pinn_bench.community.import_bundle import main as import_bundle_main
from pinn_bench.community.leaderboard_protocol import main as leaderboard_protocol_main
from pinn_bench.community.package_run import main as package_run_main
from pinn_bench.community.validate_submission import main as validate_submission_main
from pinn_bench.demo import main as demo_main
from pinn_bench.doctor import main as doctor_main
from pinn_bench.easy.cli import (
    build_compare_parser as build_easy_compare_parser,
    build_inspect_parser as build_easy_inspect_parser,
    build_list_parser as build_easy_list_parser,
    build_quickstart_parser as build_easy_quickstart_parser,
    build_starter_parser as build_easy_starter_parser,
    compare_main as easy_compare_main,
    inspect_main as easy_inspect_main,
    list_main as easy_list_main,
    quickstart_main as easy_quickstart_main,
    starter_main as easy_starter_main,
)
from pinn_bench.easy.exceptions import EasyAPIError
from pinn_bench.experiments import matrix_run, snapshot_assets
from pinn_bench.formalize import main as formalize_main
from pinn_bench.leaderboard import pareto, reporting
from pinn_bench.leaderboard.run import main as leaderboard_main
from pinn_bench.leaderboard.summary import main as summary_main
from pinn_bench.presets.cli import main as preset_main
from pinn_bench.run import run_experiment_cli
from pinn_bench.scaffold import main as scaffold_main
from pinn_bench.suite_cli import build_parser as build_suite_parser, main as suite_main
from pinn_bench.superbench.cli import main as superbench_registry_main
from pinn_bench.superbench.rerun_cli import main as superbench_rerun_entry_main
from pinn_bench.superbench.tranche_cli import main as superbench_run_tranche_main
from pinn_bench.version import main as version_main

COMMAND_HELP = {
    "quickstart": "Run or dry-run one Python-first easy-layer benchmark.",
    "list": "List easy-layer discoverable tasks, models, metrics, or templates.",
    "inspect": "Inspect one run directory through the easy report facade.",
    "starter": "Show exact starter configs for one task/model pair.",
    "compare": "Compare multiple benchmark run directories through the easy facade.",
    "suite": "List, run, or inspect NeurIPS 2026 suites through one unified front door.",
    "run": "Run a single experiment config.",
    "scaffold": "Generate starter configs, starter runs, and extension templates.",
    "preset": "List, inspect, and run official presets.",
    "demo": "Run guided demo workflows.",
    "matrix": "Run a matrix manifest sequentially.",
    "leaderboard": "Export leaderboard artifacts.",
    "report": "Export reporting-friendly grouped tables.",
    "pareto": "Export Pareto-friendly grouped tables.",
    "analysis": "Export comparative analysis and decision-support assets.",
    "formalize": "Freeze a validated preview line into a canonical formal root.",
    "snapshot": "Capture a release snapshot and archive run reports.",
    "doctor": "Check repository and artifact health.",
    "audit": "Generate a release audit report for a formal or preview line.",
    "version": "Show package and baseline version information.",
    "summary": "Generate a narrative grouped benchmark summary.",
    "package-run": "Package a single run directory into a submission bundle.",
    "validate-submission": "Validate a submission bundle against the community schema.",
    "compare-bundle": "Compare a submission bundle against grouped official results.",
    "import-bundle": "Import a submission bundle into local comparison-ready artifacts.",
    "leaderboard-protocol": "Render static leaderboard protocol views for a preview outputs root.",
    "superbench-registry": "Build strict official/staging/evidence registry views for the v3.0-preview super-benchmark line.",
    "superbench-rerun-entry": "Run one v3.0-preview source entry through native rerun orchestration and registry sync.",
    "superbench-run-tranche": "Run one ordered v3.0-preview tranche manifest through native rerun orchestration.",
}

KNOWN_SUBCOMMANDS = tuple(COMMAND_HELP)
LEGACY_RUN_FLAGS = {"--config", "--device", "--seed", "--output-dir"}



def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pinn-bench",
        description="Layer 1 benchmark OS CLI with a Layer 2 researcher front door.",
        epilog=(
            "Layer 2 researcher front door: quickstart, list, inspect, starter, compare. "
            "Layer 1 benchmark OS surfaces: run, scaffold, doctor, audit, matrix, analysis, formalize, snapshot, and community tooling. "
            "Layer 3 PINNAtlas remains a docs/package entry surface rather than a runtime CLI front door."
        ),
    )
    subparsers = parser.add_subparsers(dest="command")
    for name, help_text in COMMAND_HELP.items():
        subparsers.add_parser(name, help=help_text)
    return parser



def should_use_legacy_run(argv: Sequence[str]) -> bool:
    if not argv:
        return False
    first = str(argv[0])
    if first in KNOWN_SUBCOMMANDS:
        return False
    return any(flag in argv for flag in LEGACY_RUN_FLAGS)



def _print_root_help() -> None:
    build_parser().print_help()



def main(argv: Sequence[str] | None = None) -> None:
    args = list(sys.argv[1:] if argv is None else argv)
    if not args:
        _print_root_help()
        return
    if should_use_legacy_run(args):
        run_experiment_cli(args)
        return

    command = args[0]
    command_args = args[1:]

    if command in {"-h", "--help", "help"}:
        _print_root_help()
        return

    if command == "run":
        if not command_args or command_args[0] in {"-h", "--help"}:
            from pinn_bench.cli import build_parser as build_run_parser

            build_run_parser().print_help()
            return
        run_experiment_cli(command_args)
        return

    if command == "matrix":
        if not command_args or command_args[0] in {"-h", "--help"}:
            matrix_run.build_parser().print_help()
            return
        matrix_run.main(command_args)
        return

    if command == "leaderboard":
        if not command_args or command_args[0] in {"-h", "--help"}:
            from pinn_bench.leaderboard.run import build_parser as build_leaderboard_parser

            build_leaderboard_parser().print_help()
            return
        leaderboard_main(command_args)
        return

    if command == "report":
        if not command_args or command_args[0] in {"-h", "--help"}:
            reporting.build_parser().print_help()
            return
        reporting.main(command_args)
        return

    if command == "pareto":
        if not command_args or command_args[0] in {"-h", "--help"}:
            pareto.build_parser().print_help()
            return
        pareto.main(command_args)
        return

    if command == "analysis":
        if not command_args or command_args[0] in {"-h", "--help"}:
            from pinn_bench.analysis.cli import build_parser as build_analysis_parser

            build_analysis_parser().print_help()
            return
        analysis_main(command_args)
        return

    if command == "formalize":
        formalize_main(command_args)
        return

    if command == "snapshot":
        if not command_args or command_args[0] in {"-h", "--help"}:
            snapshot_assets.build_parser().print_help()
            return
        snapshot_assets.main(command_args)
        return

    if command == "preset":
        preset_main(command_args)
        return

    if command == "demo":
        demo_main(command_args)
        return

    if command == "scaffold":
        scaffold_main(command_args)
        return

    if command == "doctor":
        doctor_main(command_args)
        return

    if command == "audit":
        audit_main(command_args)
        return

    if command == "version":
        version_main(command_args)
        return

    if command == "summary":
        summary_main(command_args)
        return

    if command == "list":
        if not command_args or command_args[0] in {"-h", "--help"}:
            build_easy_list_parser().print_help()
            return
        try:
            easy_list_main(command_args)
        except EasyAPIError as error:
            raise SystemExit(str(error))
        return

    if command == "inspect":
        if not command_args or command_args[0] in {"-h", "--help"}:
            build_easy_inspect_parser().print_help()
            return
        try:
            easy_inspect_main(command_args)
        except EasyAPIError as error:
            raise SystemExit(str(error))
        return

    if command == "starter":
        if not command_args or command_args[0] in {"-h", "--help"}:
            build_easy_starter_parser().print_help()
            return
        try:
            easy_starter_main(command_args)
        except EasyAPIError as error:
            raise SystemExit(str(error))
        return

    if command == "compare":
        if not command_args or command_args[0] in {"-h", "--help"}:
            build_easy_compare_parser().print_help()
            return
        try:
            easy_compare_main(command_args)
        except EasyAPIError as error:
            raise SystemExit(str(error))
        return

    if command == "suite":
        if not command_args or command_args[0] in {"-h", "--help"}:
            build_suite_parser().print_help()
            return
        try:
            suite_main(command_args)
        except (EasyAPIError, FileNotFoundError, ValueError) as error:
            raise SystemExit(str(error))
        return

    if command == "quickstart":
        if not command_args or command_args[0] in {"-h", "--help"}:
            build_easy_quickstart_parser().print_help()
            return
        try:
            easy_quickstart_main(command_args)
        except EasyAPIError as error:
            raise SystemExit(str(error))
        return

    if command == "package-run":
        package_run_main(command_args)
        return

    if command == "validate-submission":
        validate_submission_main(command_args)
        return

    if command == "compare-bundle":
        compare_bundle_main(command_args)
        return

    if command == "import-bundle":
        import_bundle_main(command_args)
        return

    if command == "leaderboard-protocol":
        leaderboard_protocol_main(command_args)
        return

    if command == "superbench-registry":
        superbench_registry_main(command_args)
        return

    if command == "superbench-rerun-entry":
        superbench_rerun_entry_main(command_args)
        return

    if command == "superbench-run-tranche":
        superbench_run_tranche_main(command_args)
        return

    raise SystemExit(f"Unknown subcommand '{command}'. Run 'pinn-bench --help' for available commands.")


if __name__ == "__main__":
    main()
