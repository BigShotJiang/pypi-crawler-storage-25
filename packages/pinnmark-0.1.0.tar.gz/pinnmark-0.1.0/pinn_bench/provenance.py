"""Helpers for additive run provenance and reproducibility facts."""

from __future__ import annotations

import hashlib
import json
import platform
import sys
from pathlib import Path
from typing import Any, Mapping

import yaml

from pinn_bench.resources import resolve_repo_root


PROVENANCE_SCHEMA_VERSION = "run_provenance.v0.1"
PROVENANCE_FILENAME = "provenance.json"
PROVENANCE_GROUPED_COLUMNS = [
    "config_fingerprint",
    "manifest_fingerprint",
    "normalized_identity",
    "results_lineage",
    "snapshot_linkage",
    "environment_summary",
    "asset_completeness_fingerprint",
]


_OUTPUT_IDENTITIES: dict[str, tuple[str, str | None]] = {
    "outputs_v10": ("v1.0", "baseline_v1_0_formal.yaml"),
    "outputs_preview_v09": ("v0.9-preview", "baseline_v0_9_preview.yaml"),
    "outputs_preview_v08": ("v0.8-preview", "baseline_v0_8_preview.yaml"),
    "outputs_preview_v07": ("v0.7-preview", "baseline_v0_7_preview.yaml"),
    "outputs_v06": ("v0.6", "baseline_v0_6.yaml"),
    "outputs_v05": ("v0.5", "baseline_v0_5.yaml"),
    "outputs_v04": ("v0.4", "baseline_v0_4.yaml"),
    "outputs_v03": ("v0.3", "baseline_v0_3.yaml"),
    "outputs_v02": ("v0.2", "baseline_v0_2.yaml"),
    "outputs": ("v0.1", "baseline_v0_1.yaml"),
}


def stable_fingerprint(payload: Any) -> str:
    normalized = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def file_fingerprint(path: Path | None) -> str | None:
    if path is None or not path.exists() or not path.is_file():
        return None
    return hashlib.sha256(path.read_bytes()).hexdigest()


def infer_line_and_manifest(run_dir: Path) -> tuple[str, Path | None]:
    repo_root = resolve_repo_root(run_dir)
    for part in run_dir.resolve().parts:
        if part in _OUTPUT_IDENTITIES:
            line, manifest_name = _OUTPUT_IDENTITIES[part]
            manifest_path = None if manifest_name is None else (repo_root / "configs" / "matrix" / manifest_name)
            return line, None if manifest_path is None or not manifest_path.exists() else manifest_path.resolve()
    return "custom", None


def _robustness_from_metrics(metrics_payload: Mapping[str, Any]) -> dict[str, Any]:
    metadata = metrics_payload.get("metadata") if isinstance(metrics_payload.get("metadata"), Mapping) else {}
    robustness = metadata.get("robustness") if isinstance(metadata.get("robustness"), Mapping) else {}
    return {
        "protocol": str(robustness.get("protocol") or "none"),
        "level": robustness.get("level"),
        "train_time_range": robustness.get("train_time_range"),
        "eval_time_range": robustness.get("eval_time_range"),
    }


def normalized_identity(*, config_payload: Mapping[str, Any], metrics_payload: Mapping[str, Any]) -> dict[str, Any]:
    metadata = metrics_payload.get("metadata") if isinstance(metrics_payload.get("metadata"), Mapping) else {}
    task_cfg = config_payload.get("task") if isinstance(config_payload.get("task"), Mapping) else {}
    model_cfg = config_payload.get("model") if isinstance(config_payload.get("model"), Mapping) else {}
    task_name = str(metadata.get("task_name") or task_cfg.get("name") or "")
    model_name = str(metadata.get("model_name") or model_cfg.get("name") or "")
    robustness = _robustness_from_metrics(metrics_payload)
    protocol = str(robustness.get("protocol") or "none")
    setting = "standard"
    if protocol == "noise":
        setting = f"noise={robustness.get('level')}"
    elif protocol == "sparsity":
        setting = f"sparsity={robustness.get('level')}"
    elif protocol == "extrapolation":
        setting = f"train={robustness.get('train_time_range')};eval={robustness.get('eval_time_range')}"
    return {
        "task_name": task_name,
        "model_name": model_name,
        "protocol": protocol,
        "setting": setting,
        "task_mode": str(metadata.get("task_mode") or "pointwise"),
        "model_mode": str(metadata.get("model_mode") or "pointwise"),
        "evaluation_mode": str(metadata.get("evaluation_mode") or metadata.get("task_mode") or "pointwise"),
    }


def environment_summary() -> dict[str, Any]:
    payload: dict[str, Any] = {
        "python_version": sys.version.split()[0],
        "platform": platform.platform(),
    }
    try:
        import torch

        payload["torch_version"] = torch.__version__
    except Exception:
        payload["torch_version"] = None
    return payload


def asset_completeness_fingerprint(run_dir: Path) -> str:
    present = sorted(path.name for path in run_dir.iterdir() if path.is_file()) if run_dir.exists() else []
    return stable_fingerprint({"artifacts": present})


def build_run_provenance(*, run_dir: Path, config_payload: Mapping[str, Any], metrics_payload: Mapping[str, Any]) -> dict[str, Any]:
    benchmark_line, manifest_path = infer_line_and_manifest(run_dir)
    normalized = normalized_identity(config_payload=config_payload, metrics_payload=metrics_payload)
    config_fp = stable_fingerprint(config_payload)
    manifest_fp = file_fingerprint(manifest_path)
    snapshot_candidate = run_dir.resolve().parent / "_release_snapshot.json"
    return {
        "schema_version": PROVENANCE_SCHEMA_VERSION,
        "run_dir": str(run_dir.resolve()),
        "benchmark_line": benchmark_line,
        "config_fingerprint": config_fp,
        "manifest_fingerprint": manifest_fp,
        "normalized_identity": normalized,
        "results_lineage": {
            "metrics_path": str((run_dir / "metrics.json").resolve()),
            "config_snapshot_path": str((run_dir / "config_snapshot.yaml").resolve()),
            "source_outputs_root": run_dir.resolve().parent.name,
        },
        "snapshot_linkage": {
            "release_snapshot_path": str(snapshot_candidate.resolve()) if snapshot_candidate.exists() else None,
            "release_snapshot_present": snapshot_candidate.exists(),
        },
        "environment_summary": environment_summary(),
        "asset_completeness_fingerprint": asset_completeness_fingerprint(run_dir),
    }


def write_run_provenance(*, run_dir: Path, config_payload: Mapping[str, Any], metrics_payload: Mapping[str, Any]) -> Path:
    path = run_dir / PROVENANCE_FILENAME
    payload = build_run_provenance(run_dir=run_dir, config_payload=config_payload, metrics_payload=metrics_payload)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return path


def load_run_provenance(run_dir: Path) -> dict[str, Any] | None:
    path = run_dir / PROVENANCE_FILENAME
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def stringify_normalized_identity(payload: Mapping[str, Any] | None) -> str | None:
    if not isinstance(payload, Mapping):
        return None
    return "task={task_name}|model={model_name}|protocol={protocol}|setting={setting}".format(
        task_name=payload.get("task_name") or "",
        model_name=payload.get("model_name") or "",
        protocol=payload.get("protocol") or "",
        setting=payload.get("setting") or "",
    )


def summarized_environment(payload: Mapping[str, Any] | None) -> str | None:
    if not isinstance(payload, Mapping):
        return None
    python_version = payload.get("python_version")
    torch_version = payload.get("torch_version")
    platform_text = payload.get("platform")
    return f"python={python_version};torch={torch_version};platform={platform_text}"


def row_provenance_columns(run_dir: Path) -> dict[str, Any]:
    provenance = load_run_provenance(run_dir)
    if provenance is None:
        return {key: None for key in PROVENANCE_GROUPED_COLUMNS}
    return {
        "config_fingerprint": provenance.get("config_fingerprint"),
        "manifest_fingerprint": provenance.get("manifest_fingerprint"),
        "normalized_identity": stringify_normalized_identity(provenance.get("normalized_identity")),
        "results_lineage": json.dumps(provenance.get("results_lineage"), sort_keys=True),
        "snapshot_linkage": json.dumps(provenance.get("snapshot_linkage"), sort_keys=True),
        "environment_summary": summarized_environment(provenance.get("environment_summary")),
        "asset_completeness_fingerprint": provenance.get("asset_completeness_fingerprint"),
    }


def aggregate_provenance_rows(rows: list[dict[str, Any]], *, run_id: str, found_seeds: list[int]) -> dict[str, Any]:
    values: dict[str, list[Any]] = {key: [] for key in PROVENANCE_GROUPED_COLUMNS}
    for row in rows:
        for key in PROVENANCE_GROUPED_COLUMNS:
            value = row.get(key)
            if value not in {None, ""}:
                values[key].append(value)
    output: dict[str, Any] = {}
    for key, bucket in values.items():
        if not bucket:
            output[key] = None
        elif key == "results_lineage":
            output[key] = json.dumps({"run_id": run_id, "found_seeds": found_seeds, "entries": bucket}, sort_keys=True)
        else:
            output[key] = bucket[0]
    return output
