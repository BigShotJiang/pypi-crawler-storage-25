"""Structured suite-level product models."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class SuiteFigure:
    """Normalized suite figure record."""

    figure_id: str
    source: str
    status: str | None = None
    evidence_state: str | None = None
    section: str | None = None
    claim_supported: str | None = None
    purpose: str | None = None
    artifact_paths: tuple[str, ...] = field(default_factory=tuple)
    note: str | None = None
    materialization_state: str | None = None
    candidate_status: str | None = None
    provenance: tuple[str, ...] = field(default_factory=tuple)
    related_claim_ids: tuple[str, ...] = field(default_factory=tuple)
    warnings: tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SuiteClaim:
    """Normalized suite claim record."""

    claim_id: str
    status: str
    result_polarity: str | None = None
    coverage_fraction: float | None = None
    target_claim: str | None = None
    backing_table: str | None = None
    backing_figure: str | None = None
    boundary_wording: str | None = None
    risk_note: str | None = None
    recommended_tone: str | None = None
    evidence_sources: tuple[str, ...] = field(default_factory=tuple)
    main_text_relevant: bool = False
    provenance: tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SuiteKeyFiles:
    """Stable key paths a user most commonly needs for a suite."""

    suite_dir: str
    results_root: str
    runtime_report_path: str
    runbook_path: str
    gate_spec_path: str
    claim_log_path: str
    figure_spec_path: str
    artifact_spec_path: str
    projection_index_path: str
    staging_root: str
    work_order_path: str
    figure_registry_path: str
    claim_registry_path: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SuiteTruthTrace:
    """Explain which source layers were used to assemble the suite truth view."""

    hierarchy_version: str
    source_priority: tuple[str, ...]
    runtime_source: str
    maturity_source: str
    figures_source: str
    claims_source: str
    boundedness_sources: tuple[str, ...] = field(default_factory=tuple)
    source_files: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            **asdict(self),
            "source_priority": list(self.source_priority),
            "boundedness_sources": list(self.boundedness_sources),
            "source_files": dict(self.source_files),
        }


@dataclass(frozen=True)
class SuiteMaturity:
    """Normalized suite-level maturity and boundedness state."""

    execution_state: str | None
    projection_state: str | None
    figure_state: str | None
    claim_state: str | None
    main_text_candidate: bool
    evidence_scope: str | None = None
    boundedness: str | None = None
    warnings: tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, Any]:
        return {
            **asdict(self),
            "warnings": list(self.warnings),
        }


@dataclass(frozen=True)
class SuiteRunResult:
    """Structured result from one suite run dispatch."""

    suite_name: str
    phase: int
    runner_type: str
    depends_on: str
    launch_manifest_path: str
    suite_manifest_path: str
    results_root: str
    used_launch_root: bool
    family_ids: tuple[str, ...] = field(default_factory=tuple)
    seeds: tuple[int, ...] | None = None
    max_runs: int | None = None
    skip_existing: bool = True
    dry_run: bool = False
    summary: dict[str, Any] = field(default_factory=dict)
    runtime_report_path: str | None = None
    next_step: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            **asdict(self),
            "family_ids": list(self.family_ids),
            "seeds": None if self.seeds is None else list(self.seeds),
            "summary": dict(self.summary),
        }


@dataclass(frozen=True)
class SuiteSummary:
    """Single-source-of-truth suite summary for Python and CLI users."""

    suite_name: str
    phase: int
    runner_type: str
    depends_on: str
    maturity: SuiteMaturity
    key_files: SuiteKeyFiles
    truth_trace: SuiteTruthTrace
    results_root_exists: bool
    used_launch_root: bool
    runtime_report_exists: bool
    runtime_summary: dict[str, Any] = field(default_factory=dict)
    launch_manifest_path: str = ""
    suite_manifest_path: str = ""
    figures: tuple[SuiteFigure, ...] = field(default_factory=tuple)
    claims: tuple[SuiteClaim, ...] = field(default_factory=tuple)
    materialized_figure_files: tuple[str, ...] = field(default_factory=tuple)
    materialized_table_files: tuple[str, ...] = field(default_factory=tuple)
    materialized_note_files: tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, Any]:
        return {
            "suite_name": self.suite_name,
            "phase": self.phase,
            "runner_type": self.runner_type,
            "depends_on": self.depends_on,
            "maturity": self.maturity.to_dict(),
            "key_files": self.key_files.to_dict(),
            "truth_trace": self.truth_trace.to_dict(),
            "results_root_exists": self.results_root_exists,
            "used_launch_root": self.used_launch_root,
            "runtime_report_exists": self.runtime_report_exists,
            "runtime_summary": dict(self.runtime_summary),
            "launch_manifest_path": self.launch_manifest_path,
            "suite_manifest_path": self.suite_manifest_path,
            "figures": [figure.to_dict() for figure in self.figures],
            "claims": [claim.to_dict() for claim in self.claims],
            "materialized_figure_files": list(self.materialized_figure_files),
            "materialized_table_files": list(self.materialized_table_files),
            "materialized_note_files": list(self.materialized_note_files),
            # flattened convenience fields for CLI / notebooks / backwards-friendly JSON consumption
            "results_root": self.results_root,
            "runtime_report_path": self.runtime_report_path,
            "suite_dir": self.suite_dir,
            "work_order_path": self.work_order_path,
            "claim_log_path": self.claim_log_path,
            "figure_spec_path": self.figure_spec_path,
            "artifact_spec_path": self.artifact_spec_path,
            "projection_index_path": self.projection_index_path,
            "staging_root": self.staging_root,
            "execution_state": self.execution_state,
            "projection_state": self.projection_state,
            "figure_state": self.figure_state,
            "claim_state": self.claim_state,
            "main_text_candidate": self.main_text_candidate,
            "evidence_scope": self.evidence_scope,
            "boundedness": self.boundedness,
            "warnings": list(self.warnings),
            "boundedness_notes": list(self.boundedness_notes),
        }

    @property
    def results_root(self) -> str:
        return self.key_files.results_root

    @property
    def runtime_report_path(self) -> str:
        return self.key_files.runtime_report_path

    @property
    def suite_dir(self) -> str:
        return self.key_files.suite_dir

    @property
    def work_order_path(self) -> str:
        return self.key_files.work_order_path

    @property
    def claim_log_path(self) -> str:
        return self.key_files.claim_log_path

    @property
    def figure_spec_path(self) -> str:
        return self.key_files.figure_spec_path

    @property
    def artifact_spec_path(self) -> str:
        return self.key_files.artifact_spec_path

    @property
    def projection_index_path(self) -> str:
        return self.key_files.projection_index_path

    @property
    def staging_root(self) -> str:
        return self.key_files.staging_root

    @property
    def execution_state(self) -> str | None:
        return self.maturity.execution_state

    @property
    def projection_state(self) -> str | None:
        return self.maturity.projection_state

    @property
    def figure_state(self) -> str | None:
        return self.maturity.figure_state

    @property
    def claim_state(self) -> str | None:
        return self.maturity.claim_state

    @property
    def main_text_candidate(self) -> bool:
        return self.maturity.main_text_candidate

    @property
    def evidence_scope(self) -> str | None:
        return self.maturity.evidence_scope

    @property
    def boundedness(self) -> str | None:
        return self.maturity.boundedness

    @property
    def warnings(self) -> tuple[str, ...]:
        return self.maturity.warnings

    @property
    def boundedness_notes(self) -> tuple[str, ...]:
        if self.maturity.boundedness is None:
            return self.maturity.warnings
        return (self.maturity.boundedness,)

    def key_files_map(self) -> dict[str, str]:
        return self.key_files.to_dict()

    def warning_messages(self) -> tuple[str, ...]:
        return self.warnings

    def main_text_candidates(self) -> list[str]:
        candidates: list[str] = []
        if self.main_text_candidate:
            candidates.append(self.suite_name)
        for figure in self.figures:
            status = (figure.status or "").strip().lower()
            evidence_state = (figure.evidence_state or "").strip().lower()
            candidate_status = (figure.candidate_status or "").strip().lower()
            if (
                status in {"main_text_candidate", "selected"}
                or evidence_state in {"main_text_candidate", "figure_ready"}
                or candidate_status in {"main_text_candidate", "figure_ready"}
            ):
                candidates.append(figure.figure_id)
        return candidates
