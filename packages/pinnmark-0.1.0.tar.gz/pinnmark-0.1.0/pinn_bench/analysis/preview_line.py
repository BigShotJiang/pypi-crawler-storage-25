"""Preview-line metadata helpers for analysis/review logic."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class PreviewLineInfo:
    preview_line: str
    current_formal_line: str
    manifest_name: str
    outputs_root_name: str
    previous_preview_line: str | None
    previous_outputs_root_name: str | None
    docs: tuple[str, ...]
    formalize_flag: str
    next_preview_flag: str
    next_preview_line: str | None
    theme: str
    month_theme: str
    phase_anchor: str
    benchmark_slice_policy: str


_PREVIEW_LINE_SPECS: dict[str, PreviewLineInfo] = {
    "v0.7-preview": PreviewLineInfo(
        preview_line="v0.7-preview",
        current_formal_line="v0.6",
        manifest_name="baseline_v0_7_preview.yaml",
        outputs_root_name="outputs_preview_v07",
        previous_preview_line=None,
        previous_outputs_root_name=None,
        docs=(
            "docs/experiments/v0_7_preview.md",
            "docs/experiments/v0_7_scope.md",
            "docs/experiments/v0_7_governance.md",
        ),
        formalize_flag="should_formalize_v0_7",
        next_preview_flag="open_v0_8_preview",
        next_preview_line="v0.8-preview",
        theme="Benchmark Intelligence / Comparative Analysis / Governance Support Line",
        month_theme="Benchmark Intelligence / Comparative Analysis / Governance Support Line",
        phase_anchor="month_sprint_v0_7_preview",
        benchmark_slice_policy="mirrored_from_v0_6",
    ),
    "v0.8-preview": PreviewLineInfo(
        preview_line="v0.8-preview",
        current_formal_line="v0.6",
        manifest_name="baseline_v0_8_preview.yaml",
        outputs_root_name="outputs_preview_v08",
        previous_preview_line="v0.7-preview",
        previous_outputs_root_name="outputs_preview_v07",
        docs=(
            "docs/experiments/v0_8_preview.md",
            "docs/experiments/v0_8_scope.md",
            "docs/experiments/v0_8_governance.md",
        ),
        formalize_flag="should_formalize_v0_8",
        next_preview_flag="open_v0_9_preview",
        next_preview_line="v0.9-preview",
        theme="Content Breadth Expansion Line",
        month_theme="Content Breadth Expansion / Governance-ready Review Line",
        phase_anchor="month_sprint_v0_8_preview",
        benchmark_slice_policy="strict_superset_of_v0_7_preview",
    ),
    "v0.9-preview": PreviewLineInfo(
        preview_line="v0.9-preview",
        current_formal_line="v0.6",
        manifest_name="baseline_v0_9_preview.yaml",
        outputs_root_name="outputs_preview_v09",
        previous_preview_line="v0.8-preview",
        previous_outputs_root_name="outputs_preview_v08",
        docs=(
            "docs/experiments/v0_9_preview.md",
            "docs/experiments/v0_9_scope.md",
            "docs/experiments/v0_9_governance.md",
        ),
        formalize_flag="should_formalize_v0_9",
        next_preview_flag="open_v1_0_preview",
        next_preview_line="v1.0-preview",
        theme="Reproducibility + Submission Maturity + Trust Line",
        month_theme="Reproducibility / Submission Maturity / Trust Line",
        phase_anchor="month_sprint_v0_9_preview",
        benchmark_slice_policy="exact_carry_forward_of_v0_8_preview",
    ),
    "v1.1-preview": PreviewLineInfo(
        preview_line="v1.1-preview",
        current_formal_line="v1.0",
        manifest_name="baseline_v1_1_preview.yaml",
        outputs_root_name="outputs_preview_v11",
        previous_preview_line="v0.9-preview",
        previous_outputs_root_name="outputs_preview_v09",
        docs=(
            "docs/product/v1_1_preview.md",
            "docs/product/v1_1_scope.md",
            "docs/product/v1_1_governance.md",
        ),
        formalize_flag="should_formalize_v1_1",
        next_preview_flag="open_v1_2_preview",
        next_preview_line="v1.2-preview",
        theme="Stress Robustness + OOD Trust Line",
        month_theme="Stress Robustness / OOD Trust Line",
        phase_anchor="month_sprint_v1_1_preview",
        benchmark_slice_policy="v1_0_carry_forward_plus_stress_sentinel_overlay",
    ),
    "v1.2-preview": PreviewLineInfo(
        preview_line="v1.2-preview",
        current_formal_line="v1.0",
        manifest_name="baseline_v1_2_preview.yaml",
        outputs_root_name="outputs_preview_v12",
        previous_preview_line="v1.1-preview",
        previous_outputs_root_name="outputs_preview_v11",
        docs=(
            "docs/product/v1_2_preview.md",
            "docs/product/v1_2_scope.md",
            "docs/product/v1_2_governance.md",
        ),
        formalize_flag="should_formalize_v1_2",
        next_preview_flag="open_v1_3_preview",
        next_preview_line="v1.3-preview",
        theme="Submission Ecosystem + Living Leaderboard Protocol",
        month_theme="Submission Ecosystem / Living Leaderboard Protocol",
        phase_anchor="month_sprint_v1_2_preview",
        benchmark_slice_policy="exact_carry_forward_of_v1_1_preview_plus_leaderboard_protocol_overlay",
    ),
    "v1.3-preview": PreviewLineInfo(
        preview_line="v1.3-preview",
        current_formal_line="v1.0",
        manifest_name="baseline_v1_3_preview.yaml",
        outputs_root_name="outputs_preview_v13",
        previous_preview_line="v1.2-preview",
        previous_outputs_root_name="outputs_preview_v12",
        docs=(
            "docs/product/v1_3_preview.md",
            "docs/product/v1_3_scope.md",
            "docs/product/v1_3_governance.md",
        ),
        formalize_flag="should_formalize_v1_3",
        next_preview_flag="open_v1_4_preview",
        next_preview_line="v1.4-preview",
        theme="Developer Experience + Config Scaffolding + User-Facing API Line",
        month_theme="Developer Experience / Config Scaffolding / User-Facing API",
        phase_anchor="month_sprint_v1_3_preview",
        benchmark_slice_policy="exact_carry_forward_of_v1_2_preview_plus_dx_facade_overlay",
    ),
    "v1.4-preview": PreviewLineInfo(
        preview_line="v1.4-preview",
        current_formal_line="v1.0",
        manifest_name="baseline_v1_4_preview.yaml",
        outputs_root_name="outputs_preview_v14",
        previous_preview_line="v1.3-preview",
        previous_outputs_root_name="outputs_preview_v13",
        docs=(
            "docs/product/v1_4_preview.md",
            "docs/product/v1_4_scope.md",
            "docs/product/v1_4_governance.md",
        ),
        formalize_flag="should_formalize_v1_4",
        next_preview_flag="open_v1_5_preview",
        next_preview_line="v1.5-preview",
        theme="Operator Capability + Observation/Target Abstraction",
        month_theme="Operator Capability / Observation-Target Abstraction",
        phase_anchor="month_sprint_v1_4_preview",
        benchmark_slice_policy="exact_carry_forward_of_v1_3_preview_plus_operator_abstraction_overlay",
    ),
    "v1.5-preview": PreviewLineInfo(
        preview_line="v1.5-preview",
        current_formal_line="v1.0",
        manifest_name="baseline_v1_5_preview.yaml",
        outputs_root_name="outputs_preview_v15",
        previous_preview_line="v1.4-preview",
        previous_outputs_root_name="outputs_preview_v14",
        docs=(
            "docs/product/v1_5_preview.md",
            "docs/product/v1_5_scope.md",
            "docs/product/v1_5_governance.md",
        ),
        formalize_flag="should_formalize_v1_5",
        next_preview_flag="open_v1_6_preview",
        next_preview_line="v1.6-preview",
        theme="Cross-Line Consolidation + Repo Truth Unification",
        month_theme="Cross-Line Consolidation / Repo Truth Unification",
        phase_anchor="month_sprint_v1_5_preview",
        benchmark_slice_policy="exact_carry_forward_of_v1_4_preview_plus_cross_line_consolidation_overlay",
    ),
    "v1.6-preview": PreviewLineInfo(
        preview_line="v1.6-preview",
        current_formal_line="v1.0",
        manifest_name="baseline_v1_6_preview.yaml",
        outputs_root_name="outputs_preview_v16",
        previous_preview_line="v1.5-preview",
        previous_outputs_root_name="outputs_preview_v15",
        docs=(
            "docs/product/v1_6_preview.md",
            "docs/product/v1_6_scope.md",
            "docs/product/v1_6_governance.md",
        ),
        formalize_flag="should_formalize_v1_6",
        next_preview_flag="open_post_v1_6_follow_on",
        next_preview_line=None,
        theme="External Adoption + Publication Packaging",
        month_theme="External Adoption / Publication Packaging",
        phase_anchor="month_sprint_v1_6_preview",
        benchmark_slice_policy="exact_carry_forward_of_v1_5_preview_plus_external_adoption_publication_packaging_overlay",
    ),
    "v1.7-preview": PreviewLineInfo(
        preview_line="v1.7-preview",
        current_formal_line="v1.0",
        manifest_name="baseline_v1_7_preview.yaml",
        outputs_root_name="outputs_preview_v17",
        previous_preview_line="v1.6-preview",
        previous_outputs_root_name="outputs_preview_v16",
        docs=(
            "docs/product/v1_7_preview.md",
            "docs/product/v1_7_scope.md",
            "docs/product/v1_7_governance.md",
        ),
        formalize_flag="should_formalize_v1_7",
        next_preview_flag="open_v1_8_preview",
        next_preview_line="v1.8-preview",
        theme="Fair-Budget + Strong-Baseline Preview",
        month_theme="Fair-Budget / Strong-Baseline Preview",
        phase_anchor="month_sprint_v1_7_preview",
        benchmark_slice_policy="v1_6_carry_forward_plus_fair_budget_strong_baseline_overlay",
    ),
    "v1.8-preview": PreviewLineInfo(
        preview_line="v1.8-preview",
        current_formal_line="v1.0",
        manifest_name="baseline_v1_8_preview.yaml",
        outputs_root_name="outputs_preview_v18",
        previous_preview_line="v1.7-preview",
        previous_outputs_root_name="outputs_preview_v17",
        docs=(
            "docs/product/v1_8_preview.md",
            "docs/product/v1_8_scope.md",
            "docs/product/v1_8_governance.md",
        ),
        formalize_flag="should_formalize_v1_8",
        next_preview_flag="open_post_v1_8_follow_on",
        next_preview_line=None,
        theme="Regime-Map + Structured OOD Preview",
        month_theme="Regime-Map / Structured OOD Preview",
        phase_anchor="month_sprint_v1_8_preview",
        benchmark_slice_policy="v1_7_carry_forward_plus_regime_map_structured_ood_overlay",
    ),
    "v1.9-preview": PreviewLineInfo(
        preview_line="v1.9-preview",
        current_formal_line="v1.0",
        manifest_name="baseline_v1_9_preview.yaml",
        outputs_root_name="outputs_preview_v19",
        previous_preview_line="v1.8-preview",
        previous_outputs_root_name="outputs_preview_v18",
        docs=(
            "docs/product/v1_9_preview.md",
            "docs/product/v1_9_scope.md",
            "docs/product/v1_9_governance.md",
        ),
        formalize_flag="should_formalize_v1_9",
        next_preview_flag="open_post_v1_9_follow_on",
        next_preview_line=None,
        theme="OOD Elevation + Evidence-Richness Preview",
        month_theme="OOD Elevation / Evidence-Richness Preview",
        phase_anchor="month_sprint_v1_9_preview",
        benchmark_slice_policy="v1_8_carry_forward_plus_geometry_operator_external_recoverability_overlay",
    ),
}



def get_preview_line_info(preview_line: str | None) -> PreviewLineInfo:
    line = str(preview_line or "v0.7-preview").strip()
    return _PREVIEW_LINE_SPECS.get(line, _PREVIEW_LINE_SPECS["v0.7-preview"])



def infer_preview_line(*, outputs_root: Path, snapshot_payload: dict[str, Any] | None = None) -> str:
    if isinstance(snapshot_payload, dict):
        version_label = str(snapshot_payload.get("version_label") or "").strip()
        if version_label in _PREVIEW_LINE_SPECS:
            return version_label
        reference_preview_line = str(snapshot_payload.get("reference_preview_line") or "").strip()
        if reference_preview_line in _PREVIEW_LINE_SPECS:
            return reference_preview_line
    root_name = outputs_root.resolve().name
    for line, info in _PREVIEW_LINE_SPECS.items():
        if root_name == info.outputs_root_name:
            return line
    return "v0.7-preview"



def infer_previous_preview_root(*, outputs_root: Path, repo_root: Path, preview_line: str) -> Path | None:
    info = get_preview_line_info(preview_line)
    if info.previous_outputs_root_name is None:
        return None

    sibling = outputs_root.resolve().parent / info.previous_outputs_root_name
    if sibling.exists():
        return sibling.resolve()

    repo_candidate = (repo_root / info.previous_outputs_root_name).resolve()
    if repo_candidate.exists() and repo_candidate != outputs_root.resolve():
        return repo_candidate
    return None



def should_formalize_preview(*, preview_line: str, analysis_readiness_conclusion: str | None, smallest_gap: str | None) -> bool:
    del preview_line, analysis_readiness_conclusion, smallest_gap
    return False



def should_open_next_preview(*, preview_line: str, should_formalize: bool, smallest_gap: str | None) -> bool:
    if should_formalize:
        return False
    if preview_line in {"v1.1-preview", "v1.2-preview", "v1.3-preview", "v1.4-preview", "v1.5-preview", "v1.6-preview", "v1.7-preview", "v1.8-preview", "v1.9-preview"}:
        return False
    info = get_preview_line_info(preview_line)
    if info.next_preview_line is None:
        return False
    return smallest_gap == "slice_breadth"
