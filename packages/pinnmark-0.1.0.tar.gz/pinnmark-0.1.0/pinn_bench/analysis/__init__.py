"""Comparative analysis package for benchmark intelligence assets."""

from pinn_bench.analysis.cli import build_parser, main

__all__ = ["build_parser", "main"]
