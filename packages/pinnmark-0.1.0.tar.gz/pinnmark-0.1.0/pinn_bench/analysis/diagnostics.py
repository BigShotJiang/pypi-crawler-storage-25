"""Structured diagnostic finding generation for analysis assets."""

from __future__ import annotations

from collections import Counter
from typing import Any

from pinn_bench.analysis.normalize import AnalysisInputs


SEVERITY_ORDER = {"warning": 0, "caution": 1, "note": 2}
FAMILY_ORDER = {"slice_completeness": 0, "comparison_quality": 1, "interpretability": 2}



def _finding(
    family: str,
    code: str,
    severity: str,
    subject: str,
    message: str,
    recommendation: str,
) -> dict[str, str]:
    return {
        "family": family,
        "code": code,
        "severity": severity,
        "subject": subject,
        "message": message,
        "recommendation": recommendation,
    }



def _mode(value: Any) -> str:
    text = str(value or "pointwise").strip().lower()
    return text or "pointwise"



def build_diagnostics(inputs: AnalysisInputs, *, comparative_report: dict[str, Any], cross_version_review: dict[str, Any]) -> dict[str, Any]:
    findings: list[dict[str, str]] = []
    rows = inputs.grouped_rows
    preview_line = inputs.preview_line
    standard_pairs = {
        (str(row.get("task_name") or "unknown"), str(row.get("model_name") or "unknown"))
        for row in rows
        if str(row.get("protocol") or "none") == "none"
    }
    non_standard_rows = [row for row in rows if str(row.get("protocol") or "none") != "none"]
    for row in non_standard_rows:
        pair = (str(row.get("task_name") or "unknown"), str(row.get("model_name") or "unknown"))
        if pair not in standard_pairs:
            findings.append(
                _finding(
                    "comparison_quality",
                    "comparison_quality.missing_clean_reference",
                    "warning",
                    str(row.get("run_id") or "unknown"),
                    "This robustness row has no clean reference row for degradation comparison.",
                    "Add or regenerate the matching clean reference row before using degradation ratios in review narratives.",
                )
            )

    standard_rows = [row for row in rows if str(row.get("protocol") or "none") == "none"]
    task_modes = Counter(_mode(row.get("task_mode")) for row in standard_rows)
    protocols = Counter(str(row.get("protocol") or "none") for row in rows)
    pointwise_tasks = comparative_report.get("mode_comparison", {}).get("pointwise", {}).get("task_count", 0)
    operator_tasks = comparative_report.get("mode_comparison", {}).get("operator", {}).get("task_count", 0)

    if operator_tasks and pointwise_tasks and operator_tasks < pointwise_tasks:
        findings.append(
            _finding(
                "slice_completeness",
                "slice_completeness.operator_still_thinner",
                "note",
                "operator_slice",
                f"The operator slice remains thinner than the pointwise slice ({operator_tasks} operator tasks vs {pointwise_tasks} pointwise tasks).",
                "Keep breadth claims mode-aware and avoid implying balanced task coverage across modes.",
            )
        )

    if task_modes.get("field", 0) and task_modes.get("pointwise", 0):
        findings.append(
            _finding(
                "slice_completeness",
                "slice_completeness.mixed_mode_coverage",
                "note",
                "mode_coverage",
                "Pointwise and operator rows now share the same export chain, so mixed-mode assets are expected rather than incidental.",
                "Preserve mode fields and mode-aware sections when presenting mixed assets.",
            )
        )

    if protocols.get("extrapolation", 0) and operator_tasks:
        if preview_line == "v0.8-preview" and comparative_report.get("breadth_delta", {}).get("new_field_protocols"):
            findings.append(
                _finding(
                    "slice_completeness",
                    "slice_completeness.field_protocol_breadth_is_local",
                    "caution",
                    "field_protocol_coverage",
                    "Field extrapolation is now present in the operator slice, but only on a local host task rather than uniformly across all field tasks.",
                    "Describe field extrapolation as preview-scale protocol breadth growth rather than a frozen platform-wide requirement.",
                )
            )
        else:
            findings.append(
                _finding(
                    "slice_completeness",
                    "slice_completeness.protocol_asymmetry",
                    "caution",
                    "protocol_coverage",
                    "Protocol coverage is asymmetric across modes because extrapolation still belongs to the pointwise line rather than the operator line.",
                    "Avoid reading protocol coverage as uniform across all tasks and modes.",
                )
            )

    if operator_tasks and operator_tasks < 3:
        findings.append(
            _finding(
                "slice_completeness",
                "slice_completeness.preview_slice_still_thin",
                "caution",
                "operator_slice",
                "The preview operator slice is stable enough to review, but still thin for strong breadth claims.",
                "Keep operator conclusions benchmark-internal and avoid implying broad operator-market coverage.",
            )
        )

    if operator_tasks and pointwise_tasks:
        findings.append(
            _finding(
                "comparison_quality",
                "comparison_quality.mixed_mode_caution",
                "caution",
                "pointwise_vs_operator",
                "Pointwise and operator rows share exports, but pooled comparisons across modes should stay interpretive rather than headline-ranked as one homogeneous slice.",
                "Keep mode-aware sections in reports and avoid a single pooled leaderboard narrative.",
            )
        )

    preview_vs_formal = cross_version_review.get("preview_vs_current_formal", {})
    if preview_vs_formal.get("mirrors_benchmark_slice"):
        findings.append(
            _finding(
                "comparison_quality",
                "comparison_quality.preview_mirrors_formal_slice",
                "note",
                preview_line,
                f"`{preview_line}` mirrors the formal `v0.6` benchmark slice; the meaningful delta is the analysis and interpretation surface.",
                "Evaluate the preview on analysis quality rather than asking it to prove new benchmark-content breadth.",
            )
        )
    elif preview_line == "v0.9-preview":
        findings.append(
            _finding(
                "comparison_quality",
                "comparison_quality.preview_strengthens_trust_surface",
                "note",
                preview_line,
                "`v0.9-preview` keeps benchmark content fixed relative to `v0.8-preview` and instead deepens reproducibility, trust, and submission-review maturity.",
                "Keep the narrative focused on trust-surface deltas rather than claiming additional content breadth.",
            )
        )
    elif preview_line == "v1.1-preview":
        findings.append(
            _finding(
                "comparison_quality",
                "comparison_quality.preview_standardizes_stress_surface",
                "note",
                preview_line,
                "`v1.1-preview` carries forward the `v1.0` slice and adds a severity-standardized stress sentinel overlay rather than widening the main benchmark slice.",
                "Keep the narrative focused on severity standardization, host-relative degradation, and comparability boundaries.",
            )
        )
    elif preview_line == "v0.8-preview":
        findings.append(
            _finding(
                "comparison_quality",
                "comparison_quality.preview_expands_content_breadth",
                "note",
                preview_line,
                "`v0.8-preview` widens content breadth relative to both `v0.7-preview` and the frozen `v0.6` formal root.",
                "Keep the narrative focused on preview-scale breadth deltas, especially the new task, new baseline, and local field extrapolation host.",
            )
        )

    protocol_rankings = comparative_report.get("protocol_intelligence", {}).get("rankings", [])
    if protocol_rankings:
        hardest = protocol_rankings[0]
        findings.append(
            _finding(
                "comparison_quality",
                "comparison_quality.highest_fragility_protocol",
                "note",
                str(hardest.get("protocol_label") or "unknown"),
                "This protocol currently produces the largest average degradation ratio in the observed slice.",
                "Use the hardness and degradation sections when explaining why this protocol is informative rather than treating it as a release blocker by itself.",
            )
        )

    appendix_rows = [row for row in rows if str(row.get("protocol") or "none") != "none"]
    if appendix_rows:
        findings.append(
            _finding(
                "interpretability",
                "interpretability.appendix_preferred_rows",
                "note",
                "non_standard_rows",
                "Protocol stress rows are often more appropriate for appendix-style discussion than headline narrative.",
                "Use `table_hints` and the review packet to separate representative standard rows from completeness-oriented stress rows.",
            )
        )

    findings.append(
        _finding(
            "interpretability",
            "interpretability.heuristic_not_statistical",
            "caution",
            "analysis_surface",
            "Comparative, hardness, and decision-support sections remain heuristic review aids rather than statistical significance claims.",
            "Keep prose tied to machine-readable observations and avoid overstating causal or universal conclusions.",
        )
    )

    if not findings:
        findings.append(
            _finding(
                "interpretability",
                "interpretability.minimal_signal",
                "note",
                "analysis",
                "No structural warnings were triggered from the current assets.",
                "Treat this as a thin signal and keep reviewing the machine-readable bundle alongside the Markdown reports.",
            )
        )

    findings = sorted(
        findings,
        key=lambda item: (
            SEVERITY_ORDER.get(item["severity"], 99),
            FAMILY_ORDER.get(item.get("family", "interpretability"), 99),
            item["code"],
            item["subject"],
        ),
    )
    family_counts = Counter(str(item.get("family") or "interpretability") for item in findings)
    return {
        "summary": {
            "note": sum(1 for item in findings if item["severity"] == "note"),
            "warning": sum(1 for item in findings if item["severity"] == "warning"),
            "caution": sum(1 for item in findings if item["severity"] == "caution"),
        },
        "families": {
            family: {
                "finding_count": family_counts.get(family, 0),
            }
            for family in ["slice_completeness", "comparison_quality", "interpretability"]
        },
        "findings": findings,
    }



def render_diagnostics_markdown(payload: dict[str, Any]) -> str:
    lines = ["# Diagnostics", ""]
    findings = payload.get("findings", [])
    if not findings:
        return "# Diagnostics\n\n- No findings.\n"
    for severity in ["warning", "caution", "note"]:
        lines.extend([f"## {severity.title()}", ""])
        bucket = [item for item in findings if item.get("severity") == severity]
        if not bucket:
            lines.append(f"- No {severity}-level findings.")
        else:
            for item in bucket:
                lines.append(
                    "- `{code}` (`{family}`) on `{subject}`: {message} Why it matters: {recommendation}".format(
                        **item
                    )
                )
        lines.append("")
    lines.extend(["## Families", ""])
    for family, info in payload.get("families", {}).items():
        lines.append(f"- `{family}`: `{info.get('finding_count')}` findings")
    lines.append("")
    return "\n".join(lines)



def render_diagnostics_compact_markdown(payload: dict[str, Any]) -> str:
    lines = ["# Diagnostics Compact", ""]
    for severity in ["warning", "caution", "note"]:
        bucket = [item for item in payload.get("findings", []) if item.get("severity") == severity]
        if not bucket:
            continue
        lines.append(f"## {severity.title()}")
        lines.append("")
        for item in bucket:
            lines.append(f"- `{item['code']}` on `{item['subject']}`: {item['message']}")
        lines.append("")
    if len(lines) == 2:
        lines.append("- No findings.")
        lines.append("")
    return "\n".join(lines)
