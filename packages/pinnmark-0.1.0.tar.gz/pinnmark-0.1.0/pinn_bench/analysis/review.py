"""Observation, readiness, and review-packet helpers for analysis assets."""

from __future__ import annotations

from typing import Any

from pinn_bench.analysis.preview_line import get_preview_line_info, should_formalize_preview, should_open_next_preview


def _dimension_block(name: str, item: dict[str, Any]) -> dict[str, Any]:
    return {
        "dimension": name,
        "status": item.get("status"),
        "evidence": list(item.get("evidence", [])),
    }


def _main_governance_question(*, preview_line: str, smallest_gap: str | None, formal_discussion_ready: bool) -> str:
    info = get_preview_line_info(preview_line)
    if smallest_gap in {"comparison_fairness", "governance_caution"} and info.preview_line == "v1.2-preview":
        return "Is the leaderboard admission and comparability layer now governance-readable enough to support external participation without blurring official versus imported evidence?"
    if smallest_gap in {"comparison_fairness", "governance_caution"} and info.preview_line == "v1.1-preview":
        return "Is the stress overlay now severity-standardized and comparable enough for governance review, or should the line stay preview-only until the stress interpretation boundary is sharper?"
    if smallest_gap == "slice_breadth" and info.preview_line == "v0.7-preview":
        return "Is the mirrored slice broad enough for formal discussion, or should breadth expansion move to a later preview line?"
    if smallest_gap == "slice_breadth" and info.preview_line == "v0.8-preview":
        return "Is the current breadth delta already sufficient for formal discussion, or does governance still want one more content axis before freeze discussion?"
    if smallest_gap in {"reproducibility", "comparison_fairness"} and info.preview_line == "v0.9-preview":
        return "Should governance open formal discussion now based on the strengthened trust surface, or require one more round of reproducibility and fairness hardening before discussion?"
    if smallest_gap == "governance_caution":
        return "Should governance open formal discussion now, or keep observing the preview line without implying automatic promotion or freeze readiness?"
    if formal_discussion_ready:
        return "Is the current review surface sufficiently stable to support formal discussion without implying automatic promotion?"
    return "Which remaining gap should be reduced before governance opens a formal discussion?"


def _freeze_not_recommended_reason(*, preview_line: str, smallest_gap: str | None, formal_discussion_ready: bool) -> str:
    gap = smallest_gap or "unknown"
    if formal_discussion_ready:
        return (
            f"Freeze is still not recommended automatically because `{preview_line}` remains preview-governed and the smallest remaining gap is `{gap}`."
        )
    return f"Freeze is not recommended while the smallest remaining gap remains `{gap}`."


def build_readiness_matrix(decision_support: dict[str, Any]) -> dict[str, Any]:
    dimensions = dict(decision_support.get("dimensions", {}))
    statuses = [str(item.get("status")) for item in dimensions.values()]
    formal_discussion_recommendation = str(decision_support.get("formal_discussion_recommendation") or "")
    analysis_readiness_conclusion = decision_support.get("analysis_readiness_conclusion")
    smallest_gap = decision_support.get("smallest_remaining_gap")
    preview_line = str(decision_support.get("preview_line") or "v0.7-preview")
    formal_discussion_ready = formal_discussion_recommendation == "ready_for_formal_discussion"
    return {
        "preview_line": preview_line,
        "dimensions": dimensions,
        "evidence_blocks": [_dimension_block(name, item) for name, item in dimensions.items()],
        "healthy_count": sum(1 for status in statuses if status == "healthy"),
        "partial_count": sum(1 for status in statuses if status == "partial"),
        "gap_count": sum(1 for status in statuses if status == "gap"),
        "smallest_remaining_gap": smallest_gap,
        "formal_discussion_recommendation": formal_discussion_recommendation,
        "analysis_readiness_conclusion": analysis_readiness_conclusion,
        "formal_discussion_ready": formal_discussion_ready,
        "freeze_not_recommended_reason": _freeze_not_recommended_reason(
            preview_line=preview_line,
            smallest_gap=smallest_gap,
            formal_discussion_ready=formal_discussion_ready,
        ),
        "main_governance_question": _main_governance_question(
            preview_line=preview_line,
            smallest_gap=smallest_gap,
            formal_discussion_ready=formal_discussion_ready,
        ),
    }


def render_readiness_matrix_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Readiness Matrix",
        "",
        f"- Healthy dimensions: `{payload.get('healthy_count')}`",
        f"- Partial dimensions: `{payload.get('partial_count')}`",
        f"- Gap dimensions: `{payload.get('gap_count')}`",
        f"- Smallest remaining gap: `{payload.get('smallest_remaining_gap')}`",
        f"- Formal-discussion recommendation: `{payload.get('formal_discussion_recommendation')}`",
        f"- Formal-discussion ready: `{payload.get('formal_discussion_ready')}`",
        f"- Analysis readiness conclusion: `{payload.get('analysis_readiness_conclusion')}`",
        f"- Main governance question: {payload.get('main_governance_question')}",
        f"- Freeze-not-recommended reason: {payload.get('freeze_not_recommended_reason')}",
        "",
        "## Evidence Blocks",
        "",
    ]
    for block in payload.get("evidence_blocks", []):
        lines.append(f"- `{block.get('dimension')}`: `{block.get('status')}`")
        for evidence in block.get("evidence", []):
            lines.append(f"  - {evidence}")
    lines.append("")
    return "\n".join(lines)


def build_promotion_gap_report(decision_support: dict[str, Any], readiness_matrix: dict[str, Any]) -> dict[str, Any]:
    preview_line = str(decision_support.get("preview_line") or readiness_matrix.get("preview_line") or "v0.7-preview")
    info = get_preview_line_info(preview_line)
    issue_buckets = dict(decision_support.get("issue_buckets", {}))
    blocking_categories = [
        "engineering_blockers",
        "asset_completeness_issues",
        "onboarding_sufficiency_issues",
    ]
    non_blocking_categories = [
        "reproducibility_issues",
        "comparison_fairness_issues",
        "interpretation_quality_issues",
        "slice_breadth_issues",
        "governance_cautions",
    ]
    blocking_issue_count = sum(len(issue_buckets.get(name, [])) for name in blocking_categories)
    non_blocking_issue_count = sum(len(issue_buckets.get(name, [])) for name in non_blocking_categories)
    governance_only = (
        blocking_issue_count == 0
        and not issue_buckets.get("interpretation_quality_issues")
        and not issue_buckets.get("slice_breadth_issues")
        and bool(issue_buckets.get("governance_cautions"))
    )
    smallest_gap = decision_support.get("smallest_remaining_gap")
    formal_discussion_recommendation = decision_support.get("formal_discussion_recommendation")
    formal_discussion_ready = readiness_matrix.get("formal_discussion_ready")
    should_formalize = should_formalize_preview(
        preview_line=preview_line,
        analysis_readiness_conclusion=readiness_matrix.get("analysis_readiness_conclusion"),
        smallest_gap=smallest_gap,
    )
    open_next_preview = should_open_next_preview(
        preview_line=preview_line,
        should_formalize=should_formalize,
        smallest_gap=smallest_gap,
    )
    return {
        "preview_line": preview_line,
        "remaining_gaps_by_category": {
            "engineering_stability": list(issue_buckets.get("engineering_blockers", [])),
            "asset_completeness": list(issue_buckets.get("asset_completeness_issues", [])),
            "reproducibility": list(issue_buckets.get("reproducibility_issues", [])),
            "comparison_fairness": list(issue_buckets.get("comparison_fairness_issues", [])),
            "interpretation_quality": list(issue_buckets.get("interpretation_quality_issues", [])),
            "onboarding_sufficiency": list(issue_buckets.get("onboarding_sufficiency_issues", [])),
            "slice_breadth": list(issue_buckets.get("slice_breadth_issues", [])),
            "governance_caution": list(issue_buckets.get("governance_cautions", [])),
        },
        "blocking_categories": blocking_categories,
        "non_blocking_categories": non_blocking_categories,
        "blocking_issue_count": blocking_issue_count,
        "non_blocking_issue_count": non_blocking_issue_count,
        "governance_only": governance_only,
        "smallest_remaining_gap": smallest_gap,
        "formal_discussion_recommendation": formal_discussion_recommendation,
        "formal_discussion_ready": formal_discussion_ready,
        "analysis_readiness_conclusion": readiness_matrix.get("analysis_readiness_conclusion"),
        "freeze_not_recommended_reason": readiness_matrix.get("freeze_not_recommended_reason"),
        "main_governance_question": readiness_matrix.get("main_governance_question"),
        info.formalize_flag: should_formalize,
        info.next_preview_flag: open_next_preview,
        "evidence_blocks": list(readiness_matrix.get("evidence_blocks", [])),
    }


def render_promotion_gap_report_markdown(payload: dict[str, Any]) -> str:
    info = get_preview_line_info(str(payload.get("preview_line") or "v0.7-preview"))
    lines = [
        "# Promotion Gap Report",
        "",
        f"- Blocking issue count: `{payload.get('blocking_issue_count')}`",
        f"- Non-blocking issue count: `{payload.get('non_blocking_issue_count')}`",
        f"- Governance only: `{payload.get('governance_only')}`",
        f"- Smallest remaining gap: `{payload.get('smallest_remaining_gap')}`",
        f"- Formal-discussion recommendation: `{payload.get('formal_discussion_recommendation')}`",
        f"- Formal-discussion ready: `{payload.get('formal_discussion_ready')}`",
        f"- Analysis readiness conclusion: `{payload.get('analysis_readiness_conclusion')}`",
        f"- {info.formalize_flag}: `{payload.get(info.formalize_flag)}`",
        f"- {info.next_preview_flag}: `{payload.get(info.next_preview_flag)}`",
        f"- Main governance question: {payload.get('main_governance_question')}",
        f"- Freeze-not-recommended reason: {payload.get('freeze_not_recommended_reason')}",
        "",
        "## Remaining Gaps",
        "",
    ]
    for name, items in payload.get("remaining_gaps_by_category", {}).items():
        if not items:
            lines.append(f"- `{name}`: none")
            continue
        lines.append(f"- `{name}`:")
        for item in items:
            lines.append(f"  - {item}")
    lines.extend(["", "## Evidence Blocks", ""])
    for block in payload.get("evidence_blocks", []):
        lines.append(f"- `{block.get('dimension')}`: `{block.get('status')}`")
        for evidence in block.get("evidence", []):
            lines.append(f"  - {evidence}")
    lines.append("")
    return "\n".join(lines)


def build_observation_snapshot(
    *,
    preview_line: str,
    current_formal_line: str,
    counts: dict[str, int],
    comparative_report: dict[str, Any],
    diagnostics: dict[str, Any],
    decision_support: dict[str, Any],
    promotion_gap_report: dict[str, Any],
    observation_time: str,
    history_entry_name: str,
    expected_history_entry_count: int,
    previous_history_entry: str | None,
) -> dict[str, Any]:
    key_findings = []
    highest_fragility = comparative_report.get("protocol_intelligence", {}).get("highest_fragility")
    if isinstance(highest_fragility, dict):
        key_findings.append(
            "Highest current fragility protocol is `{protocol}` with mean degradation `{ratio}`.".format(
                protocol=highest_fragility.get("protocol_label"),
                ratio=highest_fragility.get("mean_degradation_ratio"),
            )
        )
    mode_notes = comparative_report.get("mode_comparison", {}).get("evidence_backed_observations", [])
    key_findings.extend(mode_notes[:2])
    diagnostic_codes = [item.get("code") for item in diagnostics.get("findings", []) if isinstance(item, dict)]
    return {
        "observation_time": observation_time,
        "history_entry_name": history_entry_name,
        "previous_history_entry": previous_history_entry,
        "current_preview_line": preview_line,
        "current_formal_line": current_formal_line,
        "locked_counts": counts,
        "key_findings": key_findings,
        "diagnostics_summary": diagnostics.get("summary", {}),
        "diagnostic_codes": diagnostic_codes,
        "decision_support_summary": {
            "overall_recommendation": decision_support.get("overall_recommendation"),
            "formal_discussion_recommendation": decision_support.get("formal_discussion_recommendation"),
            "analysis_readiness_conclusion": decision_support.get("analysis_readiness_conclusion"),
        },
        "smallest_remaining_gap": decision_support.get("smallest_remaining_gap"),
        "current_formal_discussion_signal": decision_support.get("formal_discussion_recommendation"),
        "blocking_issue_count": promotion_gap_report.get("blocking_issue_count"),
        "non_blocking_issue_count": promotion_gap_report.get("non_blocking_issue_count"),
        "expected_history_entry_count": expected_history_entry_count,
    }


def render_observation_snapshot_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Observation Snapshot",
        "",
        f"- Observation time: `{payload.get('observation_time')}`",
        f"- History entry: `{payload.get('history_entry_name')}`",
        f"- Previous history entry: `{payload.get('previous_history_entry')}`",
        f"- Current preview line: `{payload.get('current_preview_line')}`",
        f"- Current formal line: `{payload.get('current_formal_line')}`",
        f"- Smallest remaining gap: `{payload.get('smallest_remaining_gap')}`",
        f"- Formal-discussion signal: `{payload.get('current_formal_discussion_signal')}`",
        f"- Expected history entry count after this run: `{payload.get('expected_history_entry_count')}`",
        "",
        "## Key Findings",
        "",
    ]
    for item in payload.get("key_findings", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Locked Counts", ""])
    for name, value in payload.get("locked_counts", {}).items():
        lines.append(f"- `{name}`: `{value}`")
    lines.extend(["", "## Decision Summary", ""])
    decision = payload.get("decision_support_summary", {})
    for name, value in decision.items():
        lines.append(f"- `{name}`: `{value}`")
    lines.append("")
    return "\n".join(lines)


def build_preview_evolution_record(
    *,
    preview_line: str,
    current_formal_line: str,
    cross_version_review: dict[str, Any],
    current_observation_snapshot: dict[str, Any],
    previous_observation_snapshot: dict[str, Any] | None,
    previous_history_entry: str | None,
) -> dict[str, Any]:
    changes_since_previous: list[str] = []
    structured_delta = {
        "counts_changed": False,
        "smallest_gap_changed": False,
        "formal_signal_changed": False,
        "diagnostics_summary_changed": False,
        "key_findings_changed": False,
    }
    if previous_observation_snapshot is None:
        changes_since_previous.append(
            "No previous archived observation was available, so this run establishes the first history comparison point for the current review surface."
        )
    else:
        previous_gap = previous_observation_snapshot.get("smallest_remaining_gap")
        current_gap = current_observation_snapshot.get("smallest_remaining_gap")
        if previous_gap != current_gap:
            structured_delta["smallest_gap_changed"] = True
            changes_since_previous.append(f"Smallest remaining gap changed from `{previous_gap}` to `{current_gap}`.")

        previous_signal = previous_observation_snapshot.get("current_formal_discussion_signal")
        current_signal = current_observation_snapshot.get("current_formal_discussion_signal")
        if previous_signal != current_signal:
            structured_delta["formal_signal_changed"] = True
            changes_since_previous.append(
                f"Formal-discussion signal changed from `{previous_signal}` to `{current_signal}`."
            )

        previous_counts = dict(previous_observation_snapshot.get("locked_counts", {}))
        current_counts = dict(current_observation_snapshot.get("locked_counts", {}))
        if previous_counts != current_counts:
            structured_delta["counts_changed"] = True
            changes_since_previous.append(
                f"Locked counts changed from `{previous_counts}` to `{current_counts}`."
            )

        previous_diagnostics = dict(previous_observation_snapshot.get("diagnostics_summary", {}))
        current_diagnostics = dict(current_observation_snapshot.get("diagnostics_summary", {}))
        if previous_diagnostics != current_diagnostics:
            structured_delta["diagnostics_summary_changed"] = True
            changes_since_previous.append(
                f"Diagnostics summary changed from `{previous_diagnostics}` to `{current_diagnostics}`."
            )

        previous_findings = list(previous_observation_snapshot.get("key_findings", []))
        current_findings = list(current_observation_snapshot.get("key_findings", []))
        if previous_findings != current_findings:
            structured_delta["key_findings_changed"] = True
            changes_since_previous.append("Top-line key findings changed relative to the latest archived observation.")

        if not changes_since_previous:
            changes_since_previous.append(
                "The top-line review signal is stable relative to the latest archived observation."
            )

    smallest_gap = current_observation_snapshot.get("smallest_remaining_gap")
    open_questions = []
    if smallest_gap == "governance_caution":
        open_questions.append(
            "Is the remaining caution now purely governance-oriented, or should the line stay in observation mode despite stronger review assets?"
        )
    if smallest_gap == "slice_breadth":
        if preview_line == "v0.7-preview":
            open_questions.append(
                "Is the unchanged mirrored slice broad enough for formal discussion, or should breadth expansion shift to a later preview line?"
            )
        else:
            open_questions.append(
                "Is the current breadth expansion already sufficient for formal discussion, or does governance still want another preview-scale content axis?"
            )

    next_focus = [
        "Review whether the analysis and packet assets stay readable after repeated re-closure, not just after one clean export.",
        "Keep the line preview-aware even if the formal-discussion signal remains positive.",
    ]
    if smallest_gap == "slice_breadth":
        next_focus.append(
            "Keep separating slice-breadth caution from engineering or asset-completeness concerns."
        )
    if preview_line == "v0.8-preview":
        next_focus.append(
            "Keep local field-protocol growth explicit so content-breadth claims stay narrower than a full protocol freeze."
        )
    if preview_line == "v0.9-preview":
        next_focus.append(
            "Keep observation consistency, provenance coverage, and fairness wording aligned so the trust line stays additive rather than content-expanding."
        )
    if preview_line == "v1.1-preview":
        next_focus.append(
            "Keep severity labels, nominal-peer mapping, and appendix-only stress boundaries explicit so the stress line stays governance-readable."
        )
    if preview_line == "v1.9-preview":
        next_focus.append(
            "Keep the eight headline-complete groups, frozen external cohort summaries, and bounded recoverability wording aligned so the line reads denser without over-claiming complete geometry, inverse trust, or participant validation."
        )
    if preview_line == "v1.8-preview":
        next_focus.append(
            "Keep regime-map eligibility, mixed-family blockers, and coverage-only operator groups explicit so regime-aware claims stay stricter than raw OOD breadth."
        )
    if preview_line == "v1.7-preview":
        next_focus.append(
            "Keep matched-budget eligibility, imported classical-reference coverage, and coverage-only operator groups explicit so fair-budget claims stay stricter than raw leaderboard breadth."
        )
    if preview_line == "v1.5-preview":
        next_focus.append(
            "Keep cross-line consolidation wording aligned so the line stays about repo-truth unification and packaging discipline rather than hidden scope expansion."
        )
    elif preview_line == "v1.4-preview":
        next_focus.append(
            "Keep capability, observation/target, and operator-ready wording conservative so the abstraction line stays additive rather than over-claiming present operator benchmark support."
        )
    elif preview_line == "v1.2-preview":
        next_focus.append(
            "Keep official versus imported admission boundaries explicit so leaderboard views stay protocol-readable rather than presentation-driven."
        )

    preview_vs_formal = cross_version_review.get("preview_vs_current_formal", {})
    return {
        "current_preview_line": preview_line,
        "current_formal_line": current_formal_line,
        "current_observation_time": current_observation_snapshot.get("observation_time"),
        "latest_archived_observation": previous_history_entry,
        "latest_archived_observation_time": None
        if previous_observation_snapshot is None
        else previous_observation_snapshot.get("observation_time"),
        "meaningful_delta_vs_current_formal": preview_vs_formal.get("meaningful_delta"),
        "platform_layer_changes_vs_current_formal": preview_vs_formal.get("platform_layer_changes", []),
        "changed_since_latest_archived_observation": changes_since_previous,
        "structured_delta": structured_delta,
        "remaining_open_questions": open_questions,
        "next_observation_focus": next_focus,
    }


def render_preview_evolution_record_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Preview Evolution Record",
        "",
        f"- Current preview line: `{payload.get('current_preview_line')}`",
        f"- Current formal line: `{payload.get('current_formal_line')}`",
        f"- Current observation time: `{payload.get('current_observation_time')}`",
        f"- Meaningful delta vs current formal: `{payload.get('meaningful_delta_vs_current_formal')}`",
        f"- Latest archived observation: `{payload.get('latest_archived_observation')}`",
        f"- Latest archived observation time: `{payload.get('latest_archived_observation_time')}`",
        "",
        "## Platform-Layer Changes vs Current Formal",
        "",
    ]
    for item in payload.get("platform_layer_changes_vs_current_formal", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Changes Since Latest Archived Observation", ""])
    for item in payload.get("changed_since_latest_archived_observation", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Structured Delta", ""])
    for name, value in payload.get("structured_delta", {}).items():
        lines.append(f"- `{name}`: `{value}`")
    lines.extend(["", "## Remaining Open Questions", ""])
    for item in payload.get("remaining_open_questions", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Next Observation Focus", ""])
    for item in payload.get("next_observation_focus", []):
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)


def build_review_packet(
    *,
    preview_line: str,
    current_formal_line: str,
    pack_identity: dict[str, Any],
    counts: dict[str, int],
    cross_version_review: dict[str, Any],
    diagnostics: dict[str, Any],
    decision_support: dict[str, Any],
    readiness_matrix: dict[str, Any],
    promotion_gap_report: dict[str, Any],
    comparative_report: dict[str, Any],
    observation_snapshot: dict[str, Any],
    reproducibility_facts: dict[str, Any],
    observation_consistency: dict[str, Any],
    comparison_fairness: dict[str, Any],
    leaderboard_protocol_summary: dict[str, Any],
    admission_summary: dict[str, Any],
    view_coverage_summary: dict[str, Any],
    leaderboard_governance_caveats: list[str],
    dx_surface_summary: dict[str, Any],
    template_catalog_summary: dict[str, Any],
    quickstart_surface_summary: dict[str, Any],
    logging_hook_summary: dict[str, Any],
    capability_surface_summary: dict[str, Any],
    observation_target_surface_summary: dict[str, Any],
    operator_ready_summary: dict[str, Any],
    stress_surface_summary: dict[str, Any],
    cross_line_consolidation_summary: dict[str, Any],
    external_adoption_summary: dict[str, Any],
    publication_packaging_summary: dict[str, Any],
    benchmark_positioning_summary: dict[str, Any],
) -> dict[str, Any]:
    info = get_preview_line_info(preview_line)
    issue_buckets = dict(decision_support.get("issue_buckets", {}))
    remaining_cautions = list(issue_buckets.get("governance_cautions", []))
    remaining_cautions.extend(issue_buckets.get("slice_breadth_issues", []))
    remaining_cautions.extend(issue_buckets.get("interpretation_quality_issues", []))
    remaining_cautions.extend(issue_buckets.get("comparison_fairness_issues", []))
    key_findings = list(comparative_report.get("protocol_intelligence", {}).get("observations", []))
    key_findings.extend(comparative_report.get("mode_comparison", {}).get("evidence_backed_observations", []))
    if preview_line in {"v0.8-preview", "v0.9-preview", "v1.2-preview", "v1.4-preview", "v1.5-preview", "v1.6-preview", "v1.7-preview", "v1.8-preview", "v1.9-preview"}:
        key_findings.extend(cross_version_review.get("preview_vs_previous_preview", {}).get("key_points", [])[:2])
    smallest_gap = promotion_gap_report.get("smallest_remaining_gap")
    analysis_readiness_conclusion = decision_support.get("analysis_readiness_conclusion")
    should_formalize = should_formalize_preview(
        preview_line=preview_line,
        analysis_readiness_conclusion=analysis_readiness_conclusion,
        smallest_gap=smallest_gap,
    )
    open_next_preview = should_open_next_preview(
        preview_line=preview_line,
        should_formalize=should_formalize,
        smallest_gap=smallest_gap,
    )
    engineering_blockers = list(issue_buckets.get("engineering_blockers", []))
    governance_blockers = [] if smallest_gap != "governance_caution" else list(issue_buckets.get("governance_cautions", []))
    dimensions = dict(decision_support.get("dimensions", {}))
    decision_flags = {
        info.formalize_flag: should_formalize,
        info.next_preview_flag: open_next_preview,
    }
    current_limitation_notes = [
        "Current field baselines remain `fieldwise_solution_model`; `operator_response_model` stays reserved in the carried-forward operator-ready abstraction surface.",
        "Trajectory-native classes are introduced only as placeholders and do not map current carried-forward rows.",
    ]
    if preview_line == "v1.4-preview":
        future_compatibility_notes = [
            "Future v1.5+ lines may map explicit operator-learning families into `operator_response_model` with `operator_condition_observation -> operator_response_target` surfaces.",
            "Future lines may also map trajectory-native tasks and models into the reserved trajectory classes without rewriting the current main results schema.",
        ]
    elif preview_line == "v1.9-preview":
        future_compatibility_notes = [
            "Future work after `v1.9-preview` should focus on participant-backed recoverability and broader inverse-trust closure rather than reopening the current OOD, comparability, or recoverability contract from scratch.",
            "The evidence-rich overlay keeps runtime semantics fixed while making eight headline-complete OOD groups, a frozen external comparability cohort, and thicker recoverability evidence explicit enough for paper-grade use.",
        ]
    elif preview_line == "v1.8-preview":
        future_compatibility_notes = [
            "Future work after `v1.8-preview` should focus on complex geometry, inverse trust, and paper closeout rather than reopening the fair-budget or regime contract from scratch.",
            "The regime-aware overlay keeps runtime semantics fixed while making regime eligibility, structured-OOD coverage, and failure surfaces explicit enough for headline use.",
        ]
    elif preview_line == "v1.7-preview":
        future_compatibility_notes = [
            "Future work after `v1.7-preview` should focus on regime-map and OOD expansion rather than reopening the fair-budget contract from scratch.",
            "The fair-budget overlay keeps runtime semantics fixed while making comparison eligibility, budget matching, and strong-baseline coverage explicit enough for headline use.",
        ]
    elif preview_line == "v1.6-preview":
        future_compatibility_notes = [
            "Future work after `v1.6-preview` should focus on stabilization, release planning, public launch preparation, and paper submission packaging rather than new protocol churn.",
            "The packaging overlay keeps benchmark semantics fixed while making the existing formal baseline and completed preview layers easier to adopt and cite.",
        ]
    elif preview_line == "v1.5-preview":
        future_compatibility_notes = [
            "Future v1.6+ lines may package the unified stress, leaderboard, DX, and operator-ready surfaces for external adoption without rewriting the current main results schema.",
            "Future lines may still map explicit operator-learning and trajectory-native components into the reserved classes introduced by the operator-ready abstraction layer.",
        ]
    else:
        future_compatibility_notes = [
            "Future lines may map explicit operator-learning families into `operator_response_model` with `operator_condition_observation -> operator_response_target` surfaces.",
            "Future lines may also map trajectory-native tasks and models into the reserved trajectory classes without rewriting the current main results schema.",
        ]
    cross_line_consolidation_notes = list(cross_line_consolidation_summary.get("repo_truth_unification_notes", []))
    payload = {
        "current_preview_line": preview_line,
        "current_formal_line": current_formal_line,
        "pack_identity": dict(pack_identity),
        "meaningful_delta": cross_version_review.get("preview_vs_current_formal", {}).get("meaningful_delta"),
        "counts": counts,
        "key_findings": key_findings,
        "diagnostics_summary": diagnostics.get("summary", {}),
        "decision_support_summary": {
            "overall_recommendation": decision_support.get("overall_recommendation"),
            "formal_discussion_recommendation": decision_support.get("formal_discussion_recommendation"),
            "analysis_readiness_conclusion": analysis_readiness_conclusion,
            "smallest_remaining_gap": decision_support.get("smallest_remaining_gap"),
        },
        "dimension_status_summary": {name: item.get("status") for name, item in dimensions.items()},
        "engineering_status": {
            "status": dimensions.get("engineering_stability", {}).get("status"),
            "evidence": list(dimensions.get("engineering_stability", {}).get("evidence", [])),
        },
        "reproducibility_status": {
            "status": dimensions.get("reproducibility", {}).get("status"),
            "evidence": list(dimensions.get("reproducibility", {}).get("evidence", [])),
            "surface": reproducibility_facts,
        },
        "observation_consistency_status": {
            "status": "healthy" if observation_consistency.get("sufficient_history") else "partial",
            "summary": observation_consistency,
        },
        "asset_completeness_status": {
            "status": dimensions.get("asset_completeness", {}).get("status"),
            "evidence": list(dimensions.get("asset_completeness", {}).get("evidence", [])),
        },
        "comparison_fairness_summary": comparison_fairness,
        "leaderboard_protocol_summary": leaderboard_protocol_summary,
        "admission_summary": admission_summary,
        "view_coverage_summary": view_coverage_summary,
        "leaderboard_governance_caveats": leaderboard_governance_caveats,
        "dx_surface_summary": dx_surface_summary,
        "template_catalog_summary": template_catalog_summary,
        "quickstart_surface_summary": quickstart_surface_summary,
        "logging_hook_summary": logging_hook_summary,
        "capability_surface_summary": capability_surface_summary,
        "observation_target_surface_summary": observation_target_surface_summary,
        "operator_ready_summary": operator_ready_summary,
        "capability_summary": capability_surface_summary,
        "observation_target_summary": observation_target_surface_summary,
        "operator_ready_notes": list(operator_ready_summary.get("notes", [])),
        "current_limitation_notes": current_limitation_notes,
        "future_compatibility_notes": future_compatibility_notes,
        "stress_surface_summary": stress_surface_summary,
        "stress_summary": comparative_report.get("stress_surface", {}).get("stress_summary", {}),
        "regime_surface_summary": dict(comparative_report.get("regime_surface", {})),
        "cross_line_consolidation_summary": cross_line_consolidation_summary,
        "cross_line_consolidation_notes": cross_line_consolidation_notes,
        "external_adoption_summary": external_adoption_summary,
        "publication_packaging_summary": publication_packaging_summary,
        "benchmark_positioning_summary": benchmark_positioning_summary,
        "worst_stress_case": comparative_report.get("stress_surface", {}).get("worst_stress_case"),
        "stress_caveats": list(comparative_report.get("stress_surface", {}).get("stress_caveats", [])),
        "nominal_vs_stress_contrast": list(comparative_report.get("stress_surface", {}).get("nominal_vs_stress_contrast", [])),
        "comparability_notes": list(comparison_fairness.get("stress_policy", {}).get("comparability_notes", [])),
        "interpretation_quality_status": {
            "status": dimensions.get("interpretation_quality", {}).get("status"),
            "evidence": list(dimensions.get("interpretation_quality", {}).get("evidence", [])),
        },
        "governance_caution_status": {
            "status": dimensions.get("governance_caution", {}).get("status"),
            "evidence": list(dimensions.get("governance_caution", {}).get("evidence", [])),
        },
        "readiness_matrix_summary": {
            "healthy_count": readiness_matrix.get("healthy_count"),
            "partial_count": readiness_matrix.get("partial_count"),
            "gap_count": readiness_matrix.get("gap_count"),
            "formal_discussion_ready": readiness_matrix.get("formal_discussion_ready"),
            "main_governance_question": readiness_matrix.get("main_governance_question"),
        },
        "observation_summary": {
            "observation_time": observation_snapshot.get("observation_time"),
            "history_entry_name": observation_snapshot.get("history_entry_name"),
            "formal_discussion_signal": observation_snapshot.get("current_formal_discussion_signal"),
        },
        "remaining_cautions": remaining_cautions,
        "engineering_blockers": engineering_blockers,
        "governance_blockers": governance_blockers,
        "formal_discussion_justified": decision_support.get("formal_discussion_recommendation") == "ready_for_formal_discussion",
        "formal_discussion_recommendation": decision_support.get("formal_discussion_recommendation"),
        "analysis_readiness_conclusion": analysis_readiness_conclusion,
        "smallest_remaining_gap": smallest_gap,
        "main_governance_question": promotion_gap_report.get("main_governance_question") or readiness_matrix.get("main_governance_question"),
        "governance_question_and_recommendation": {
            "question": promotion_gap_report.get("main_governance_question") or readiness_matrix.get("main_governance_question"),
            "formal_discussion_recommendation": decision_support.get("formal_discussion_recommendation"),
        },
        "decision_flags": decision_flags,
    }
    payload.update(decision_flags)
    if pack_identity.get("pack_kind") == "starter":
        payload["starter_pack_summary"] = {
            "starter_pack": pack_identity.get("starter_pack_id"),
            "reference_preview_line": pack_identity.get("reference_preview_line"),
            "framing": "starter_pack_reuses_reference_preview_analysis_without_opening_a_new_preview_line",
        }
    return payload


def render_review_packet_markdown(payload: dict[str, Any]) -> str:
    info = get_preview_line_info(str(payload.get("current_preview_line") or "v0.7-preview"))
    pack_identity = payload.get("pack_identity", {})
    lines = [
        "# Review Packet",
        "",
        f"- Current preview line: `{payload.get('current_preview_line')}`",
        f"- Current formal line: `{payload.get('current_formal_line')}`",
        f"- Meaningful delta: `{payload.get('meaningful_delta')}`",
        f"- Formal discussion justified: `{payload.get('formal_discussion_justified')}`",
        f"- Formal-discussion recommendation: `{payload.get('formal_discussion_recommendation')}`",
        f"- Analysis readiness conclusion: `{payload.get('analysis_readiness_conclusion')}`",
        f"- Smallest remaining gap: `{payload.get('smallest_remaining_gap')}`",
        f"- Main governance question: {payload.get('main_governance_question')}",
        f"- {info.formalize_flag}: `{payload.get(info.formalize_flag)}`",
        f"- {info.next_preview_flag}: `{payload.get(info.next_preview_flag)}`",
        "",
        "## Counts",
        "",
    ]
    if isinstance(pack_identity, dict) and pack_identity.get("pack_kind") == "starter":
        lines[2:2] = [
            f"- Pack kind: `{pack_identity.get('pack_kind')}`",
            f"- Starter pack: `{pack_identity.get('starter_pack_id')}`",
            f"- Reference preview line: `{pack_identity.get('reference_preview_line')}`",
        ]
    for name, value in payload.get("counts", {}).items():
        lines.append(f"- `{name}`: `{value}`")
    lines.extend(["", "## Key Findings", ""])
    for item in payload.get("key_findings", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Engineering Status", ""])
    engineering_status = payload.get("engineering_status", {})
    lines.append(f"- Status: `{engineering_status.get('status')}`")
    for item in engineering_status.get("evidence", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Reproducibility Status", ""])
    reproducibility_status = payload.get("reproducibility_status", {})
    lines.append(f"- Status: `{reproducibility_status.get('status')}`")
    for item in reproducibility_status.get("evidence", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Observation Consistency Status", ""])
    lines.append(f"- Status: `{payload.get('observation_consistency_status', {}).get('status')}`")
    lines.append(f"- Summary: `{payload.get('observation_consistency_status', {}).get('summary')}`")
    lines.extend(["", "## Asset Completeness", ""])
    asset_status = payload.get("asset_completeness_status", {})
    lines.append(f"- Status: `{asset_status.get('status')}`")
    for item in asset_status.get("evidence", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Comparison Fairness Summary", ""])
    lines.append(f"- Summary: `{payload.get('comparison_fairness_summary', {}).get('summary')}`")
    lines.extend(["", "## Leaderboard Protocol Summary", ""])
    lines.append(f"- Summary: `{payload.get('leaderboard_protocol_summary')}`")
    lines.append(f"- Admission summary: `{payload.get('admission_summary')}`")
    lines.append(f"- View coverage summary: `{payload.get('view_coverage_summary')}`")
    for item in payload.get('leaderboard_governance_caveats', []):
        lines.append(f"- Governance caveat: {item}")
    lines.extend(["", "## DX Surface Summary", ""])
    lines.append(f"- DX summary: `{payload.get('dx_surface_summary')}`")
    lines.append(f"- Template catalog: `{payload.get('template_catalog_summary')}`")
    lines.append(f"- Quickstart surface: `{payload.get('quickstart_surface_summary')}`")
    lines.append(f"- Logging hooks: `{payload.get('logging_hook_summary')}`")
    lines.extend(["", "## Operator-Ready Abstraction", ""])
    lines.append(f"- Capability surface: `{payload.get('capability_surface_summary')}`")
    lines.append(f"- Observation/target surface: `{payload.get('observation_target_surface_summary')}`")
    lines.append(f"- Operator-ready summary: `{payload.get('operator_ready_summary')}`")
    lines.append(f"- Capability summary: `{payload.get('capability_summary')}`")
    lines.append(f"- Observation/target summary: `{payload.get('observation_target_summary')}`")
    for item in payload.get("operator_ready_notes", []):
        lines.append(f"- Operator-ready note: {item}")
    for item in payload.get("current_limitation_notes", []):
        lines.append(f"- Current limitation: {item}")
    for item in payload.get("future_compatibility_notes", []):
        lines.append(f"- Future compatibility: {item}")
    lines.extend(["", "## Stress Summary", ""])
    lines.append(f"- Surface summary: `{payload.get('stress_surface_summary')}`")
    lines.append(f"- Summary: `{payload.get('stress_summary')}`")
    lines.append(f"- Worst stress case: `{payload.get('worst_stress_case')}`")
    for item in payload.get("nominal_vs_stress_contrast", []):
        lines.append(f"- Contrast: {item}")
    for item in payload.get("stress_caveats", []):
        lines.append(f"- Caveat: {item}")
    if payload.get("regime_surface_summary"):
        lines.extend(["", "## Regime Surface", ""])
        for name, value in payload.get("regime_surface_summary", {}).items():
            lines.append(f"- `{name}`: `{value}`")
    if payload.get("cross_line_consolidation_summary") or payload.get("cross_line_consolidation_notes"):
        lines.extend(["", "## Cross-Line Consolidation", ""])
        lines.append(f"- Summary: `{payload.get('cross_line_consolidation_summary')}`")
        for item in payload.get("cross_line_consolidation_notes", []):
            lines.append(f"- Note: {item}")
    if payload.get("benchmark_positioning_summary"):
        lines.extend(["", "## Benchmark Positioning", ""])
        lines.append(f"- Summary: `{payload.get('benchmark_positioning_summary')}`")
    if payload.get("external_adoption_summary"):
        lines.extend(["", "## External Adoption", ""])
        lines.append(f"- Summary: `{payload.get('external_adoption_summary')}`")
    if payload.get("publication_packaging_summary"):
        lines.extend(["", "## Publication Packaging", ""])
        lines.append(f"- Summary: `{payload.get('publication_packaging_summary')}`")
    lines.extend(["", "## Comparability Notes", ""])
    for item in payload.get("comparability_notes", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Interpretation Quality", ""])
    interpretation_status = payload.get("interpretation_quality_status", {})
    lines.append(f"- Status: `{interpretation_status.get('status')}`")
    for item in interpretation_status.get("evidence", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Governance Caution", ""])
    governance_status = payload.get("governance_caution_status", {})
    lines.append(f"- Status: `{governance_status.get('status')}`")
    for item in governance_status.get("evidence", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Diagnostics Summary", ""])
    for name, value in payload.get("diagnostics_summary", {}).items():
        lines.append(f"- `{name}`: `{value}`")
    lines.extend(["", "## Decision-Support Summary", ""])
    for name, value in payload.get("decision_support_summary", {}).items():
        lines.append(f"- `{name}`: `{value}`")
    lines.extend(["", "## Readiness Matrix Summary", ""])
    for name, value in payload.get("readiness_matrix_summary", {}).items():
        lines.append(f"- `{name}`: `{value}`")
    lines.extend(["", "## Observation Summary", ""])
    for name, value in payload.get("observation_summary", {}).items():
        lines.append(f"- `{name}`: `{value}`")
    lines.extend(["", "## Governance Question And Recommendation", ""])
    lines.append(f"- `{payload.get('governance_question_and_recommendation')}`")
    lines.extend(["", "## Remaining Cautions", ""])
    for item in payload.get("remaining_cautions", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Decision Flags", ""])
    for name, value in payload.get("decision_flags", {}).items():
        lines.append(f"- `{name}`: `{value}`")
    lines.extend(["", "## Blockers", ""])
    if payload.get("engineering_blockers"):
        lines.append("- Engineering blockers:")
        for item in payload.get("engineering_blockers", []):
            lines.append(f"  - {item}")
    else:
        lines.append("- Engineering blockers: none")
    if payload.get("governance_blockers"):
        lines.append("- Governance blockers:")
        for item in payload.get("governance_blockers", []):
            lines.append(f"  - {item}")
    else:
        lines.append("- Governance blockers: none")
    lines.append("")
    return "\n".join(lines)


def build_release_packet_draft(review_packet: dict[str, Any], release_review: dict[str, Any]) -> dict[str, Any]:
    info = get_preview_line_info(str(review_packet.get("current_preview_line") or "v0.7-preview"))
    return {
        "title": f"{info.preview_line} release packet draft",
        "preview_only": True,
        "promotion_decision_made": False,
        "current_preview_line": review_packet.get("current_preview_line"),
        "current_formal_line": review_packet.get("current_formal_line"),
        "meaningful_delta": review_packet.get("meaningful_delta"),
        "analysis_readiness_conclusion": review_packet.get("analysis_readiness_conclusion"),
        "formal_discussion_justified": review_packet.get("formal_discussion_justified"),
        info.formalize_flag: review_packet.get(info.formalize_flag),
        info.next_preview_flag: review_packet.get(info.next_preview_flag),
        "notes": [
            "This sprint does not make a promotion decision.",
            "The draft exists so release discussion can start from a structured packet if governance review is opened later.",
            "Preview interpretation remains observational even when the formal-discussion signal is positive.",
        ],
        "release_review_anchor": release_review.get("reviewability", {}),
    }


def render_release_packet_draft_markdown(payload: dict[str, Any]) -> str:
    info = get_preview_line_info(str(payload.get("current_preview_line") or "v0.7-preview"))
    lines = [
        "# Release Packet Draft",
        "",
        f"- Preview only: `{payload.get('preview_only')}`",
        f"- Promotion decision made in this sprint: `{payload.get('promotion_decision_made')}`",
        f"- Current preview line: `{payload.get('current_preview_line')}`",
        f"- Current formal line: `{payload.get('current_formal_line')}`",
        f"- Meaningful delta: `{payload.get('meaningful_delta')}`",
        f"- Analysis readiness conclusion: `{payload.get('analysis_readiness_conclusion')}`",
        f"- Formal discussion justified: `{payload.get('formal_discussion_justified')}`",
        f"- {info.formalize_flag}: `{payload.get(info.formalize_flag)}`",
        f"- {info.next_preview_flag}: `{payload.get(info.next_preview_flag)}`",
        "",
        "## Notes",
        "",
    ]
    for item in payload.get("notes", []):
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)


def build_executive_summary(review_packet: dict[str, Any], promotion_gap_report: dict[str, Any]) -> dict[str, Any]:
    preview_line = str(review_packet.get("current_preview_line") or "v0.7-preview")
    if preview_line == "v1.9-preview":
        headline = "`v1.9-preview` closes an evidence-richer structured-OOD line on top of the carried-forward fair-budget and regime-aware benchmark system without changing the frozen formal baseline or public runtime semantics."
        key_points = [
            "The meaningful delta vs `v1.8-preview` is evidence-density: eight headline-complete OOD groups, no remaining headline-visible coverage-only operator rows, a support-only robustness plane, a frozen external comparability cohort, and thicker recoverability support.",
            "The carried-forward preview system remains intact while geometry enters as a first governed OOD family and operator parameter / resolution rows become headline-complete rather than coverage-only.",
            "Verdict enums and main machine fields remain unchanged; the line adds denser benchmark evidence, stronger reviewer routing, and a new canonical preview root rather than trainer or evaluator churn.",
            "The line remains preview-only and sets the next benchmark-facing steps to participant-backed recoverability and broader inverse-trust closure rather than automatic formal promotion.",
        ]
    elif preview_line == "v1.8-preview":
        headline = "`v1.8-preview` closes a regime-aware and structured-OOD reporting layer on top of the carried-forward fair-budget benchmark system without changing the frozen formal baseline or core runtime semantics."
        key_points = [
            "The meaningful delta vs `v1.7-preview` is regime-layer: grouped regime metadata, regime map / OOD slice reporting, failure atlas, physics consistency dashboard, and regime-aware closeout rules.",
            "The carried-forward preview system remains intact while headline OOD claims are now separated from blocked groups and coverage-only operator cells.",
            "Verdict enums and main machine fields remain unchanged; the line adds regime-aware reporting, closeout policy, and checked-in preview assets rather than trainer or evaluator churn.",
            "The line remains preview-only and sets the next benchmark-facing steps to complex geometry, inverse trust, and paper-closeout evidence rather than formal promotion.",
        ]
    elif preview_line == "v1.7-preview":
        headline = "`v1.7-preview` closes a fair-budget and strong-baseline comparison layer on top of the carried-forward benchmark system without changing the frozen formal baseline or core runtime semantics."
        key_points = [
            "The meaningful delta vs `v1.6-preview` is comparison-layer: explicit budget metadata, matched-budget grouping, imported classical-reference coverage, and headline-eligibility rules for fairer claims.",
            "The carried-forward preview system remains intact while headline pointwise tasks now support matched-budget discussion that is stricter than the raw grouped leaderboard.",
            "Verdict enums and main machine fields remain unchanged; the line adds fair-budget reporting, coverage policy, and doctor/audit redlines rather than trainer or evaluator churn.",
            "The line remains preview-only and sets the next benchmark-facing step to regime-map and OOD expansion rather than formal promotion.",
        ]
    elif preview_line == "v1.6-preview":
        headline = "`v1.6-preview` packages the carried-forward benchmark system for external adoption, reviewer comprehension, and publication-facing reuse without expanding benchmark scope."
        key_points = [
            "The meaningful delta vs `v1.5-preview` is packaging-layer: external positioning docs, lifecycle maps, reviewer-facing summaries, and additive adoption/publication summaries in canonical analysis surfaces.",
            "The carried-forward `48 grouped / 144 run` preview slice remains fixed while stress, leaderboard-protocol, DX, operator-ready, and consolidation layers are translated into a clearer external narrative.",
            "Verdict enums and main machine fields remain unchanged; the line adds external-facing summaries and documentation rather than protocol churn.",
            "The line remains preview-only and does not request automatic formalization or machine-routed opening of a follow-on preview line.",
        ]
    elif preview_line == "v1.5-preview":
        headline = "`v1.5-preview` consolidates the carried-forward stress, leaderboard, DX, and operator-ready layers into one repo-truth and review-facing system narrative without expanding benchmark scope."
        key_points = [
            "The meaningful delta vs `v1.4-preview` is consolidation-layer: unified entrypoints, glossary and governance language, and additive cross-line summary surfaces.",
            "The carried-forward `48 grouped / 144 run` preview slice remains fixed while stress, leaderboard-protocol, DX, and operator-ready sections are described under one consistent preview-governed vocabulary.",
            "Verdict enums and main machine fields remain unchanged; the line adds summaries and packaging rather than rewriting core semantics.",
            "The line remains preview-only and does not request automatic formalization or auto-open a `v1.6-preview` follow-up.",
        ]
    elif preview_line == "v1.4-preview":
        headline = "`v1.4-preview` makes the carried-forward preview slice operator-ready in vocabulary and review framing without claiming a full operator benchmark rollout."
        key_points = [
            "The meaningful delta vs `v1.3-preview` is abstraction-layer: capability taxonomy, observation/target taxonomy, compatibility classes, and operator-ready packet language.",
            "Current pointwise and conditioned-field rows now share one conservative descriptive surface while trainer, evaluator, and main result schema contracts stay fixed.",
            "Current field baselines remain `fieldwise_solution_model` and are operator-ready in interface shape only; explicit operator-response classes stay reserved for later lines.",
            "The line remains preview-only and does not request automatic formalization or auto-open a `v1.5-preview` follow-up.",
        ]
    elif preview_line == "v1.2-preview":
        headline = "`v1.2-preview` turns the completed stress line into a living leaderboard protocol surface without broadening the benchmark slice."
        key_points = [
            "The meaningful delta vs `v1.1-preview` is protocol-layer: admission registry, imported-bundle dispositions, static leaderboard views, and governance packets.",
            "Official rows remain repo-owned carry-forward evidence, while imported bundles stay additive as `unofficial`, `stress_only`, or `appendix_only` entries.",
            "Stress views remain family-matched, severity-matched, and cohort-local rather than collapsing into one pooled ranking.",
            "The line remains preview-only and does not request automatic formalization or auto-open a `v1.3-preview` follow-up.",
        ]
    elif preview_line == "v1.1-preview":
        headline = "`v1.1-preview` standardizes stress severity and review semantics on top of the frozen `v1.0` slice."
        key_points = [
            "The meaningful delta vs `v1.0` is a bounded 16-run stress sentinel overlay rather than new benchmark breadth.",
            "Noise, sparsity, and temporal holdout runs now map to canonical severity IDs and host-relative nominal peers.",
            "Cross-family or cross-severity stress comparisons remain appendix-only by policy, so the line should be read as a trust/governance upgrade rather than a pooled ranking refresh.",
            "The line remains preview-only and does not request automatic formalization or auto-open a `v1.2-preview` follow-up.",
        ]
    elif preview_line == "v0.9-preview":
        headline = "`v0.9-preview` strengthens reproducibility, submission maturity, and trust while keeping benchmark content fixed."
        key_points = [
            "The meaningful delta vs `v0.8-preview` is trust-surface hardening: provenance, observation consistency, comparison fairness, and stronger external review artifacts.",
            "Benchmark content remains the exact carried-forward `v0.8-preview` 32-row slice over the frozen `v0.6` contract.",
            "The current output should be read as governance-grade evidence for formal discussion, not as a freeze request, release declaration, or automatic promotion claim.",
            "Any future `v1.0-formal` candidate should remain stability-first and separate from new breadth-expansion or platform-ambition work.",
        ]
    elif preview_line == "v0.8-preview":
        headline = "`v0.8-preview` widens benchmark content while keeping governance and review surfaces preview-aware."
        key_points = [
            "The meaningful delta vs `v0.7-preview` is content breadth: new operator task, new operator baseline, and local field extrapolation coverage.",
            "The frozen `v0.6` operator-ready contract remains intact while the preview slice grows from the inherited 18 rows to the active 32-row target.",
            "The current output should be read as governance-grade preview evidence for formal discussion, not as an automatic promotion claim.",
        ]
    else:
        headline = "`v0.7-preview` deepens benchmark intelligence without changing benchmark content."
        key_points = [
            "Benchmark content remains the exact frozen `v0.6` 18-family slice.",
            "The meaningful delta is the analysis, diagnostics, observation, and decision-support surface.",
            "The current output should be read as review-oriented preview evidence rather than a freeze, release, or promotion claim.",
        ]
    return {
        "headline": headline,
        "readiness_conclusion": review_packet.get("analysis_readiness_conclusion"),
        "formal_discussion_recommendation": review_packet.get("decision_support_summary", {}).get(
            "formal_discussion_recommendation"
        ),
        "smallest_remaining_gap": promotion_gap_report.get("smallest_remaining_gap"),
        "blocking_issue_count": promotion_gap_report.get("blocking_issue_count"),
        "non_blocking_issue_count": promotion_gap_report.get("non_blocking_issue_count"),
        "freeze_not_recommended_reason": promotion_gap_report.get("freeze_not_recommended_reason"),
        "main_governance_question": promotion_gap_report.get("main_governance_question"),
        "key_points": key_points,
    }


def render_executive_summary_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Executive Summary",
        "",
        f"- {payload.get('headline')}",
        f"- Analysis readiness conclusion: `{payload.get('readiness_conclusion')}`",
        f"- Formal-discussion recommendation: `{payload.get('formal_discussion_recommendation')}`",
        f"- Smallest remaining gap: `{payload.get('smallest_remaining_gap')}`",
        f"- Blocking issue count: `{payload.get('blocking_issue_count')}`",
        f"- Non-blocking issue count: `{payload.get('non_blocking_issue_count')}`",
        f"- Main governance question: {payload.get('main_governance_question')}",
        f"- Freeze-not-recommended reason: {payload.get('freeze_not_recommended_reason')}",
        "- Supporting scope note: `docs/product/v1_0_candidate_scope.md`",
        "",
        "## Key Points",
        "",
    ]
    for item in payload.get("key_points", []):
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
