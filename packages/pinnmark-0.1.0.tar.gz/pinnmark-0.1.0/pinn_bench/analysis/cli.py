"""CLI for comparative benchmark analysis assets."""

from __future__ import annotations

import argparse
import json
import shutil
from collections.abc import Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pinn_bench.analysis.comparative import (
    build_comparative_report,
    build_cross_version_review,
    build_hardness_report,
    build_operator_abstraction_surface,
    build_release_review,
    build_table_hints,
    render_comparative_report_markdown,
    render_cross_version_review_markdown,
    render_hardness_report_markdown,
    render_release_review_markdown,
    render_table_hints_markdown,
)
from pinn_bench.analysis.decision import build_decision_support, render_decision_support_markdown
from pinn_bench.analysis.diagnostics import (
    build_diagnostics,
    render_diagnostics_compact_markdown,
    render_diagnostics_markdown,
)
from pinn_bench.analysis.fairness import assess_comparison_fairness, assess_stress_comparability
from pinn_bench.analysis.normalize import (
    analysis_asset_paths,
    latest_history_entry,
    list_history_entries,
    load_analysis_inputs,
)
from pinn_bench.analysis.preview_line import get_preview_line_info
from pinn_bench.analysis.review import (
    build_executive_summary,
    build_observation_snapshot,
    build_preview_evolution_record,
    build_promotion_gap_report,
    build_readiness_matrix,
    build_release_packet_draft,
    build_review_packet,
    render_executive_summary_markdown,
    render_observation_snapshot_markdown,
    render_preview_evolution_record_markdown,
    render_promotion_gap_report_markdown,
    render_readiness_matrix_markdown,
    render_release_packet_draft_markdown,
    render_review_packet_markdown,
)
from pinn_bench.provenance import PROVENANCE_FILENAME
from pinn_bench.resources import resolve_repo_root
from pinn_bench.version import LATEST_COMPLETED_PREVIEW_LINE
from pinn_bench.utils.io import write_json


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Generate comparative analysis and decision-support assets.")
    parser.add_argument("--outputs-root", required=True, type=str, help="Benchmark outputs root to analyze.")
    parser.add_argument("--output-dir", default=None, type=str, help="Directory for analysis assets. Defaults to <outputs-root>/_analysis.")
    parser.add_argument("--formal-root", default="outputs_v10", type=str, help="Optional current formal outputs root reference.")
    parser.add_argument("--previous-formal-root", default="outputs_v06", type=str, help="Optional previous formal outputs root reference.")
    return parser



def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()



def _history_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")



def _load_previous_observation_snapshot(history_entry: Path | None) -> tuple[dict[str, Any] | None, str | None]:
    if history_entry is None:
        return None, None
    bundle_path = history_entry / "analysis_bundle.json"
    if not bundle_path.exists():
        return None, history_entry.name
    try:
        payload = json.loads(bundle_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None, history_entry.name
    if not isinstance(payload, dict):
        return None, history_entry.name
    snapshot = payload.get("observation_snapshot")
    if not isinstance(snapshot, dict):
        return None, history_entry.name
    return snapshot, history_entry.name



def _load_previous_analysis_bundle(history_entry: Path | None) -> dict[str, Any] | None:
    if history_entry is None:
        return None
    bundle_path = history_entry / "analysis_bundle.json"
    if not bundle_path.exists():
        return None
    try:
        payload = json.loads(bundle_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None
    return payload if isinstance(payload, dict) else None



def _load_leaderboard_protocol_surface(outputs_root: Path) -> dict[str, Any]:
    protocol_dir = outputs_root / "_leaderboard_protocol"
    bundle_path = protocol_dir / "leaderboard_protocol_bundle.json"
    governance_path = protocol_dir / "governance_packet.json"
    admission_path = protocol_dir / "admission_registry.json"
    payload: dict[str, Any] = {}
    governance_payload: dict[str, Any] = {}
    if bundle_path.exists():
        try:
            loaded = json.loads(bundle_path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                payload = loaded
        except json.JSONDecodeError:
            payload = {}
    if governance_path.exists():
        try:
            loaded = json.loads(governance_path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                governance_payload = loaded
        except json.JSONDecodeError:
            governance_payload = {}
    return {
        "protocol_bundle_present": bundle_path.exists(),
        "admission_registry_present": admission_path.exists(),
        "governance_packet_present": governance_path.exists(),
        "leaderboard_protocol_summary": {
            "protocol_bundle_present": bundle_path.exists(),
            "target_benchmark_line": payload.get("target_benchmark_line"),
            "imported_example_count": len(payload.get("imported_examples", [])) if isinstance(payload.get("imported_examples"), list) else 0,
            "stress_policy_class": payload.get("comparison_fairness", {}).get("stress_policy", {}).get("policy_class"),
        },
        "admission_summary": dict(payload.get("admission_summary", {})) if isinstance(payload.get("admission_summary"), dict) else {},
        "view_coverage_summary": dict(payload.get("view_coverage_summary", {})) if isinstance(payload.get("view_coverage_summary"), dict) else {},
        "leaderboard_governance_caveats": list(governance_payload.get("caveats", [])) if isinstance(governance_payload.get("caveats"), list) else [],
    }


def _load_dx_surface() -> dict[str, Any]:
    repo_root = resolve_repo_root()
    template_root = repo_root / "configs" / "templates"
    examples_root = repo_root / "configs" / "examples" / "v1_3_preview"
    product_root = repo_root / "docs" / "product"
    template_names = sorted(path.stem for path in template_root.glob("*.yaml")) if template_root.exists() else []
    example_names = sorted(path.name for path in examples_root.glob("*.yaml")) if examples_root.exists() else []
    quickstart_docs = {
        "quickstart_doc_present": (product_root / "quickstart.md").exists(),
        "getting_started_doc_present": (product_root / "getting_started.md").exists(),
        "cli_quickstart_doc_present": (product_root / "cli_quickstart.md").exists(),
    }
    return {
        "dx_surface_summary": {
            "api_surface_doc_present": (product_root / "dx_api_surface.md").exists(),
            "scaffold_doc_present": (product_root / "scaffold.md").exists(),
            "safe_playground_root": "outputs_playground",
            "template_count": len(template_names),
            "example_count": len(example_names),
        },
        "template_catalog_summary": {
            "template_names": template_names,
            "example_names": example_names,
            "template_root": str(template_root.resolve()),
            "examples_root": str(examples_root.resolve()),
        },
        "quickstart_surface_summary": quickstart_docs,
        "logging_hook_summary": {
            "supported_backends": ["basic", "none", "tensorboard", "wandb"],
            "logging_doc_present": (product_root / "logging_hooks.md").exists(),
            "logging_config_root": str((repo_root / "configs" / "logging").resolve()),
        },
    }


def _build_stress_surface_summary(*, comparative_report: dict[str, Any], preview_line: str) -> dict[str, Any]:
    stress_surface = dict(comparative_report.get("stress_surface", {}))
    summary = dict(stress_surface.get("stress_summary", {}))
    summary.update(
        {
            "preview_line": preview_line,
            "surface_origin": "v1.1-preview",
            "surface_status": "carried_forward_additive",
            "worst_stress_case_present": stress_surface.get("worst_stress_case") is not None,
            "contrast_count": len(stress_surface.get("nominal_vs_stress_contrast", [])),
            "caveat_count": len(stress_surface.get("stress_caveats", [])),
        }
    )
    return summary


def _build_cross_line_consolidation_summary(*, preview_line: str, current_formal_line: str) -> dict[str, Any]:
    if preview_line not in {"v1.5-preview", "v1.6-preview", "v1.7-preview", "v1.8-preview", "v1.9-preview"}:
        return {}
    if preview_line == "v1.9-preview":
        return {
            "source_preview_lines": ["v1.1-preview", "v1.2-preview", "v1.3-preview", "v1.4-preview", "v1.5-preview", "v1.6-preview", "v1.7-preview", "v1.8-preview"],
            "current_formal_baseline": current_formal_line,
            "latest_completed_preview_line": LATEST_COMPLETED_PREVIEW_LINE,
            "preserved_surface_families": [
                "stress_surface",
                "leaderboard_protocol_surface",
                "dx_surface",
                "operator_ready_abstraction_surface",
                "external_adoption_surface",
                "publication_packaging_surface",
                "fair_budget_surface",
                "regime_surface",
            ],
            "repo_truth_unification_notes": [
                "`v1.9-preview` keeps the carried-forward `v1.8-preview` fair-budget and regime-aware benchmark-system surface while re-centering the line on thicker structured OOD evidence, frozen external comparability cohort evidence, and stronger recoverability support.",
                "The `v1.9` overlay is additive: it lifts operator rows out of the previous coverage-only posture, absorbs governed geometry OOD into the headline layer, and exposes a support-only robustness plane without changing the frozen formal baseline or public runtime contract.",
                "Stress, leaderboard-protocol, DX, operator-ready, packaging, fair-budget, and regime-aware reporting remain preserved surfaces inside the evidence-rich line rather than being replaced by it.",
            ],
            "remaining_externalization_gap": "Participant-validated recoverability, broader inverse-trust closure, and later post-paper benchmark widening remain follow-on work after the evidence-rich preview line.",
        }
    if preview_line == "v1.8-preview":
        return {
            "source_preview_lines": ["v1.1-preview", "v1.2-preview", "v1.3-preview", "v1.4-preview", "v1.5-preview", "v1.6-preview", "v1.7-preview"],
            "current_formal_baseline": current_formal_line,
            "latest_completed_preview_line": LATEST_COMPLETED_PREVIEW_LINE,
            "preserved_surface_families": [
                "stress_surface",
                "leaderboard_protocol_surface",
                "dx_surface",
                "operator_ready_abstraction_surface",
                "external_adoption_surface",
                "publication_packaging_surface",
                "fair_budget_surface",
            ],
            "repo_truth_unification_notes": [
                "`v1.8-preview` keeps the carried-forward `v1.7-preview` fair-budget system surface and re-centers the line around regime-aware/OOD reporting rather than baseline-comparison cleanup.",
                "The regime/OOD overlay is additive: it layers grouped regime metadata, regime-aware reporting artifacts, and closeout-time doctor/audit redlines on top of the preserved fair-budget and packaging surfaces.",
                "Stress, leaderboard-protocol, DX, operator-ready, packaging, and fair-budget sections remain preserved surfaces inside the regime-aware line rather than being replaced by it.",
            ],
            "remaining_externalization_gap": "Complex geometry, inverse trust, and paper-closeout evidence remain post-closeout follow-on work after the regime-aware preview line.",
        }
    if preview_line == "v1.7-preview":
        return {
            "source_preview_lines": ["v1.1-preview", "v1.2-preview", "v1.3-preview", "v1.4-preview", "v1.5-preview", "v1.6-preview"],
            "current_formal_baseline": current_formal_line,
            "latest_completed_preview_line": LATEST_COMPLETED_PREVIEW_LINE,
            "preserved_surface_families": [
                "stress_surface",
                "leaderboard_protocol_surface",
                "dx_surface",
                "operator_ready_abstraction_surface",
                "external_adoption_surface",
                "publication_packaging_surface",
            ],
            "repo_truth_unification_notes": [
                "`v1.7-preview` keeps the carried-forward `v1.6-preview` system surface and re-centers the line around fair-budget, strong-baseline, and headline-eligibility governance.",
                "The fair-budget overlay is additive: it layers comparison metadata, matched-budget reporting, and closeout-time doctor/audit redlines on top of the preserved packaging and protocol surfaces.",
                "Stress, leaderboard-protocol, DX, operator-ready, and packaging sections remain preserved surfaces inside the fair-budget line rather than being replaced by it.",
            ],
            "remaining_externalization_gap": "Regime-map and OOD expansion remain the next benchmark-facing preview step after the fair-budget closeout.",
        }
    if preview_line == "v1.6-preview":
        return {
            "source_preview_lines": ["v1.1-preview", "v1.2-preview", "v1.3-preview", "v1.4-preview"],
            "current_formal_baseline": current_formal_line,
            "latest_completed_preview_line": LATEST_COMPLETED_PREVIEW_LINE,
            "preserved_surface_families": [
                "stress_surface",
                "leaderboard_protocol_surface",
                "dx_surface",
                "operator_ready_abstraction_surface",
            ],
            "repo_truth_unification_notes": [
                "`v1.6-preview` keeps the carried-forward `v1.5` slice and preserves the consolidation summary so the earlier preview layers remain described under one shared repo-truth vocabulary.",
                "The packaging overlay is additive: it layers external positioning, reviewer, and publication-facing surfaces on top of the preserved consolidation summary rather than replacing it.",
                "Stress, leaderboard-protocol, DX, and operator-ready sections remain preserved surfaces inside the externally packaged system narrative.",
            ],
            "remaining_externalization_gap": "Stabilization, release planning, and public launch preparation remain outside the current packaging closeout.",
        }
    return {
        "source_preview_lines": ["v1.1-preview", "v1.2-preview", "v1.3-preview", "v1.4-preview"],
        "current_formal_baseline": current_formal_line,
        "latest_completed_preview_line": LATEST_COMPLETED_PREVIEW_LINE,
        "preserved_surface_families": [
            "stress_surface",
            "leaderboard_protocol_surface",
            "dx_surface",
            "operator_ready_abstraction_surface",
        ],
        "repo_truth_unification_notes": [
            "`v1.5-preview` keeps the carried-forward `v1.4` slice and focuses on unifying how the repo describes already-completed preview layers.",
            "The consolidation summary is additive: it does not rename existing machine fields or replace established preview verdict enums.",
            "Stress, leaderboard-protocol, DX, and operator-ready sections remain preserved surfaces rather than four disconnected storylines.",
        ],
        "remaining_externalization_gap": "External Adoption + Publication Packaging remains outside the current consolidation line.",
    }


def _build_external_adoption_summary(*, preview_line: str) -> dict[str, Any]:
    if preview_line not in {"v1.6-preview", "v1.7-preview", "v1.8-preview", "v1.9-preview"}:
        return {}
    repo_root = resolve_repo_root()
    product_root = repo_root / "docs" / "product"
    entrypoints = [
        "README.md",
        "docs/index.md",
        "docs/product/index.md",
        "docs/product/adoption_guide.md",
        "docs/product/public_quickstart.md",
        "docs/product/contribution_path.md",
    ]
    return {
        "preview_line": preview_line,
        "surface_origin": "v1.6-preview",
        "surface_status": "additive_packaging_overlay" if preview_line == "v1.6-preview" else "carried_forward_packaging_surface",
        "reader_paths": [
            "first-time reader",
            "benchmark user",
            "benchmark contributor",
            "governance / review reader",
        ],
        "primary_entrypoints": entrypoints,
        "submission_path_present": (repo_root / "docs" / "community" / "submission-standard-v1.md").exists(),
        "external_model_path_present": (repo_root / "examples" / "external_model_example" / "README.md").exists(),
        "external_task_path_present": (repo_root / "examples" / "external_task_example" / "README.md").exists(),
        "adoption_scope_caveat": "The line packages existing benchmark truth for external readers; it does not add a remote service, new protocol family, or benchmark-slice expansion."
        if preview_line == "v1.6-preview"
        else (
            "The fair-budget line preserves the external-facing packaging surface while shifting the headline change to comparison-faithful benchmark reporting rather than public-service expansion."
            if preview_line == "v1.7-preview"
            else (
                "The regime-aware line preserves the external-facing packaging surface while shifting the headline change to regime-map and structured-OOD evidence rather than public-service expansion."
                if preview_line == "v1.8-preview"
                else "The evidence-rich line preserves the external-facing packaging surface while shifting the headline change to governed OOD thickening, frozen external-cohort comparability, and stronger recoverability support rather than service expansion."
            )
        ),
    }


def _build_publication_packaging_summary(*, preview_line: str) -> dict[str, Any]:
    if preview_line not in {"v1.6-preview", "v1.7-preview", "v1.8-preview", "v1.9-preview"}:
        return {}
    repo_root = resolve_repo_root()
    product_root = repo_root / "docs" / "product"
    publication_story = product_root / "publication_story.md"
    publication_text = publication_story.read_text(encoding="utf-8") if publication_story.exists() else ""
    return {
        "preview_line": preview_line,
        "surface_origin": "v1.6-preview",
        "surface_status": "additive_packaging_overlay" if preview_line == "v1.6-preview" else "carried_forward_packaging_surface",
        "problem_statement_present": "## Benchmark Problem Statement" in publication_text,
        "paper_section_mapping_present": "## Suggested Paper Section Mapping" in publication_text,
        "reviewer_summary_present": (product_root / "reviewer_summary.md").exists(),
        "appendix_surface_present": (product_root / "appendix_surface.md").exists(),
        "architecture_workflow_docs_present": (product_root / "benchmark_architecture.md").exists() and (product_root / "workflow_overview.md").exists(),
        "remaining_publication_gap": "Public launch and submission packaging remain follow-on decisions after the preview-governed v1.6 closeout."
        if preview_line == "v1.6-preview"
        else (
            "The next paper-facing gap is to convert the closed fair-budget surface into regime-map and inverse-trust evidence rather than to widen packaging alone."
            if preview_line == "v1.7-preview"
            else (
                "The next paper-facing gap is to convert the closed regime-aware/OOD surface into complex-geometry, inverse-trust, and paper-closeout evidence rather than to widen packaging alone."
                if preview_line == "v1.8-preview"
                else "The next paper-facing gap is to convert the evidence-rich `v1.9` paper surface into participant-backed recoverability and broader inverse-trust closure rather than to widen packaging alone."
            )
        ),
    }


def _completed_preview_lines_for_positioning(*, preview_line: str) -> list[str]:
    ordered_lines = [
        "v1.1-preview",
        "v1.2-preview",
        "v1.3-preview",
        "v1.4-preview",
        "v1.5-preview",
        "v1.6-preview",
        "v1.7-preview",
        "v1.8-preview",
        "v1.9-preview",
    ]
    try:
        preview_index = ordered_lines.index(preview_line)
    except ValueError:
        return []
    try:
        completed_index = ordered_lines.index(LATEST_COMPLETED_PREVIEW_LINE)
    except ValueError:
        completed_index = preview_index
    return ordered_lines[: min(preview_index, completed_index) + 1]


def _build_benchmark_positioning_summary(*, preview_line: str, current_formal_line: str) -> dict[str, Any]:
    if preview_line not in {"v1.6-preview", "v1.7-preview", "v1.8-preview", "v1.9-preview"}:
        return {}
    return {
        "preview_line": preview_line,
        "surface_origin": (
            "v1.6-preview"
            if preview_line == "v1.6-preview"
            else ("v1.7-preview" if preview_line == "v1.7-preview" else ("v1.8-preview" if preview_line == "v1.8-preview" else "v1.9-preview"))
        ),
        "surface_status": (
            "additive_packaging_overlay"
            if preview_line == "v1.6-preview"
            else ("fair_budget_overlay" if preview_line == "v1.7-preview" else ("regime_ood_overlay" if preview_line == "v1.8-preview" else "evidence_rich_ood_overlay"))
        ),
        "current_formal_baseline": current_formal_line,
        "completed_preview_lines": _completed_preview_lines_for_positioning(preview_line=preview_line),
        "differentiators": [
            "frozen_formal_baseline plus preview-governed overlays instead of a single mutable benchmark surface",
            "stress-aware review and leaderboard protocol surfaces that stay additive to official benchmark truth",
            "DX and operator-ready vocabulary carried forward into external-facing adoption and publication packaging",
            (
                "fair-budget comparison metadata, matched-budget tables, and headline-eligibility policy that prevent weak-baseline claims from reading as main conclusions"
                if preview_line == "v1.7-preview"
                else (
                    "regime-map, OOD-slice, failure-atlas, and physics-consistency surfaces that show where methods hold or fail rather than only averaging across regimes"
                    if preview_line == "v1.8-preview"
                    else (
                        "an eight-group structured OOD headline layer, frozen external comparability cohort evidence, and thicker recoverability support that raise evidence density without changing the frozen formal baseline"
                        if preview_line == "v1.9-preview"
                        else "DX and operator-ready vocabulary carried forward into external-facing adoption and publication packaging"
                    )
                )
            ),
        ],
        "intended_users": [
            "benchmark users evaluating nominal and stress-aware evidence",
            "external contributors integrating models, tasks, and submission bundles",
            "reviewers and collaborators who need one system-level benchmark narrative",
        ],
        "out_of_scope": [
            "remote leaderboard service rollout",
            "operator-zoo benchmark expansion",
            "trainer, evaluator, or main results schema rewrites",
        ],
    }



def _run_dirs(outputs_root: Path) -> list[Path]:
    return sorted(
        path
        for path in outputs_root.resolve().iterdir()
        if path.is_dir() and not path.name.startswith("_")
    ) if outputs_root.exists() else []



def _build_reproducibility_facts(inputs, *, preview_line: str) -> dict[str, Any]:
    run_dirs = _run_dirs(inputs.outputs_root)
    provenance_paths = [run_dir / PROVENANCE_FILENAME for run_dir in run_dirs if (run_dir / PROVENANCE_FILENAME).exists()]
    grouped_rows = inputs.grouped_rows
    grouped_columns = [
        "config_fingerprint",
        "manifest_fingerprint",
        "normalized_identity",
        "results_lineage",
        "snapshot_linkage",
        "environment_summary",
        "asset_completeness_fingerprint",
    ]
    grouped_coverage = {
        column: sum(1 for row in grouped_rows if row.get(column) not in {None, ""})
        for column in grouped_columns
    }
    surface_present = bool(run_dirs) and len(provenance_paths) == len(run_dirs)
    return {
        "schema_version": "reproducibility_facts.v0.1",
        "preview_line": preview_line,
        "run_dir_count": len(run_dirs),
        "provenance_sidecar_count": len(provenance_paths),
        "provenance_surface_present": surface_present,
        "grouped_provenance_column_coverage": grouped_coverage,
        "snapshot_linkage_present": inputs.snapshot_payload is not None,
        "previous_preview_linkage_present": inputs.previous_preview_reference is not None,
        "asset_completeness_surface_present": grouped_coverage["asset_completeness_fingerprint"] > 0,
        "notes": [
            "Run provenance is additive and preview-only; historical lines remain readable without provenance sidecars.",
            "Reproducibility facts should be read as traceability support rather than as a formal reproducibility proof.",
        ],
    }



def _build_comparison_fairness(inputs, *, cross_version_review: dict[str, Any], diagnostics: dict[str, Any]) -> dict[str, Any]:
    same_slice_as_previous_preview = False
    if inputs.previous_preview_reference is not None:
        current_pairs = {
            (str(row.get("task_name") or ""), str(row.get("model_name") or ""), str(row.get("protocol") or "none"))
            for row in inputs.grouped_rows
        }
        previous_pairs = {
            (str(row.get("task_name") or ""), str(row.get("model_name") or ""), str(row.get("protocol") or "none"))
            for row in inputs.previous_preview_reference.grouped_rows
        }
        same_slice_as_previous_preview = current_pairs == previous_pairs

    diagnostic_codes = {str(item.get("code")) for item in diagnostics.get("findings", []) if isinstance(item, dict)}
    preview_vs_previous = assess_comparison_fairness(
        benchmark_line_match=same_slice_as_previous_preview,
        slice_match=same_slice_as_previous_preview,
        protocol_supported=True,
        mode_compatible=True,
        artifact_completeness="complete" if inputs.previous_preview_reference is not None else "partial",
        reference_available=inputs.previous_preview_reference is not None,
        context_label="Preview-vs-previous-preview comparison",
    )
    preview_vs_formal = assess_comparison_fairness(
        benchmark_line_match=False,
        slice_match=bool(cross_version_review.get("preview_vs_current_formal", {}).get("mirrors_benchmark_slice")),
        protocol_supported=True,
        mode_compatible=True,
        artifact_completeness="complete" if inputs.formal_reference is not None else "partial",
        reference_available=inputs.formal_reference is not None,
        context_label="Preview-vs-current-formal comparison",
    )
    mixed_mode = assess_comparison_fairness(
        benchmark_line_match=True,
        slice_match=True,
        protocol_supported=True,
        mode_compatible=False,
        artifact_completeness="complete",
        reference_available=True,
        context_label="Mixed-mode internal ranking",
    )
    robustness = assess_comparison_fairness(
        benchmark_line_match=True,
        slice_match=True,
        protocol_supported=True,
        mode_compatible=True,
        artifact_completeness="complete" if "comparison_quality.missing_clean_reference" not in diagnostic_codes else "partial",
        reference_available="comparison_quality.missing_clean_reference" not in diagnostic_codes,
        context_label="Robustness degradation comparison",
    )
    stress_policy = assess_stress_comparability(inputs.grouped_rows)
    surfaces = {
        "preview_vs_previous_preview": preview_vs_previous,
        "preview_vs_current_formal": preview_vs_formal,
        "mixed_mode_internal_ranking": mixed_mode,
        "robustness_degradation": robustness,
    }
    categories = [surface["fairness_category"] for surface in surfaces.values()]
    strength_order = {"strong": 0, "moderate": 1, "limited": 2, "none": 3}
    category_order = {"fair": 0, "mostly_fair": 1, "caution": 2, "partial": 3, "not_comparable": 4}
    overall_category = sorted(categories, key=lambda item: category_order[item])[0]
    overall_strength = sorted((surface["comparison_strength"] for surface in surfaces.values()), key=lambda item: strength_order[item])[0]
    return {
        "schema_version": "comparison_fairness.v0.1",
        "preview_line": inputs.preview_line,
        "summary": {
            "overall_fairness_category": overall_category,
            "overall_comparison_strength": overall_strength,
            "appendix_only_surface_count": sum(1 for surface in surfaces.values() if surface["appendix_only_recommended"]),
            "stress_policy_class": stress_policy.get("policy_class"),
        },
        "surfaces": surfaces,
        "stress_policy": stress_policy,
        "notes": [
            "Fairness categories are advisory trust labels rather than publication decisions.",
            "Compare-bundle and analysis reuse the same fairness classification helper so wording stays aligned.",
        ],
    }



def _render_comparison_fairness_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Comparison Fairness",
        "",
        f"- Preview line: `{payload.get('preview_line')}`",
        f"- Overall fairness category: `{payload.get('summary', {}).get('overall_fairness_category')}`",
        f"- Overall comparison strength: `{payload.get('summary', {}).get('overall_comparison_strength')}`",
        "",
    ]
    for name, surface in payload.get("surfaces", {}).items():
        lines.extend([f"## {name}", ""])
        lines.append(f"- Fairness category: `{surface.get('fairness_category')}`")
        lines.append(f"- Comparison strength: `{surface.get('comparison_strength')}`")
        lines.append(f"- Appendix only recommended: `{surface.get('appendix_only_recommended')}`")
        for note in surface.get("fairness_notes", []):
            lines.append(f"- {note}")
        lines.append("")
    for note in payload.get("notes", []):
        lines.append(f"- {note}")
    stress_policy = payload.get("stress_policy", {})
    lines.extend(["", "## Stress Policy", ""])
    lines.append(f"- Policy class: `{stress_policy.get('policy_class')}`")
    lines.append(f"- Official stress rows: `{stress_policy.get('official_stress_row_count')}`")
    lines.append(f"- Appendix-only stress rows: `{stress_policy.get('appendix_only_stress_row_count')}`")
    for note in stress_policy.get("comparability_notes", []):
        lines.append(f"- {note}")
    lines.append("")
    return "\n".join(lines)



def _build_observation_consistency(
    *,
    preview_line: str,
    counts: dict[str, int],
    diagnostics: dict[str, Any],
    decision_support: dict[str, Any],
    promotion_gap_report: dict[str, Any],
    reproducibility_facts: dict[str, Any],
    previous_analysis_bundle: dict[str, Any] | None,
) -> dict[str, Any]:
    previous_counts = previous_analysis_bundle.get("counts") if isinstance(previous_analysis_bundle, dict) else None
    previous_diagnostics = previous_analysis_bundle.get("diagnostics", {}).get("summary") if isinstance(previous_analysis_bundle, dict) else None
    previous_decision = previous_analysis_bundle.get("decision_support") if isinstance(previous_analysis_bundle, dict) else None
    previous_gap = previous_analysis_bundle.get("promotion_gap_report", {}).get("smallest_remaining_gap") if isinstance(previous_analysis_bundle, dict) else None
    previous_repro = previous_analysis_bundle.get("reproducibility_facts") if isinstance(previous_analysis_bundle, dict) else None

    changes = []
    counts_stable = previous_counts == counts if isinstance(previous_counts, dict) else None
    diagnostics_stable = previous_diagnostics == diagnostics.get("summary") if isinstance(previous_diagnostics, dict) else None
    recommendation_stable = (
        previous_decision.get("formal_discussion_recommendation") == decision_support.get("formal_discussion_recommendation")
        if isinstance(previous_decision, dict)
        else None
    )
    smallest_gap_stable = previous_gap == promotion_gap_report.get("smallest_remaining_gap") if previous_gap is not None else None
    asset_completeness_stable = (
        previous_repro.get("provenance_surface_present") == reproducibility_facts.get("provenance_surface_present")
        if isinstance(previous_repro, dict)
        else None
    )

    if counts_stable is False:
        changes.append(f"Counts changed from `{previous_counts}` to `{counts}`.")
    if diagnostics_stable is False:
        changes.append(f"Diagnostics summary changed from `{previous_diagnostics}` to `{diagnostics.get('summary')}`.")
    if recommendation_stable is False:
        changes.append("Formal-discussion recommendation changed relative to the latest archived observation.")
    if smallest_gap_stable is False:
        changes.append(
            f"Smallest remaining gap changed from `{previous_gap}` to `{promotion_gap_report.get('smallest_remaining_gap')}`."
        )
    if asset_completeness_stable is False:
        changes.append("Reproducibility surface changed relative to the latest archived observation.")
    if not changes:
        changes.append("Top-line review and trust signals are stable relative to the latest archived observation.")

    sufficient_history = isinstance(previous_analysis_bundle, dict)
    return {
        "schema_version": "observation_consistency.v0.1",
        "preview_line": preview_line,
        "sufficient_history": sufficient_history,
        "counts_consistency": {"stable": counts_stable, "current": counts, "previous": previous_counts},
        "recommendation_stability": {
            "stable": recommendation_stable,
            "current": decision_support.get("formal_discussion_recommendation"),
            "previous": None if not isinstance(previous_decision, dict) else previous_decision.get("formal_discussion_recommendation"),
        },
        "diagnostics_stability": {
            "stable": diagnostics_stable,
            "current": diagnostics.get("summary"),
            "previous": previous_diagnostics,
        },
        "smallest_gap_stability": {
            "stable": smallest_gap_stable,
            "current": promotion_gap_report.get("smallest_remaining_gap"),
            "previous": previous_gap,
        },
        "asset_completeness_stability": {
            "stable": asset_completeness_stable,
            "current": reproducibility_facts.get("provenance_surface_present"),
            "previous": None if not isinstance(previous_repro, dict) else previous_repro.get("provenance_surface_present"),
        },
        "conclusion_drift": {
            "changed": recommendation_stable is False or smallest_gap_stable is False,
            "current": decision_support.get("analysis_readiness_conclusion"),
            "previous": None if not isinstance(previous_decision, dict) else previous_decision.get("analysis_readiness_conclusion"),
        },
        "changed_since_previous_observation": changes,
    }



def _render_observation_consistency_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Observation Consistency",
        "",
        f"- Preview line: `{payload.get('preview_line')}`",
        f"- Sufficient history: `{payload.get('sufficient_history')}`",
        "",
        "## Stability Checks",
        "",
    ]
    for name in [
        "counts_consistency",
        "recommendation_stability",
        "diagnostics_stability",
        "smallest_gap_stability",
        "asset_completeness_stability",
        "conclusion_drift",
    ]:
        block = payload.get(name, {})
        lines.append(f"- `{name}`: `{block}`")
    lines.extend(["", "## Changed Since Previous Observation", ""])
    for item in payload.get("changed_since_previous_observation", []):
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)



def _render_formal_discussion_memo(bundle: dict[str, Any]) -> str:
    review_packet = bundle.get("review_packet", {})
    promotion_gap = bundle.get("promotion_gap_report", {})
    should_formalize = "false" if review_packet.get("should_formalize_v0_9") is False else "true"
    open_next_preview = "false" if review_packet.get("open_v1_0_preview") is False else "true"
    lines = [
        "# Formal Discussion Memo",
        "",
        f"- Current preview line: `{review_packet.get('current_preview_line')}`",
        f"- Analysis readiness conclusion: `{review_packet.get('analysis_readiness_conclusion')}`",
        f"- Formal-discussion recommendation: `{review_packet.get('formal_discussion_recommendation')}`",
        f"- should_formalize_v0_9: `{should_formalize}`",
        f"- open_v1_0_preview: `{open_next_preview}`",
        f"- smallest_remaining_gap: `{review_packet.get('smallest_remaining_gap')}`",
        "",
        "## Why Formal Discussion Is Reasonable",
        "",
        "- `v0.9-preview` has reached `ready_for_formal_discussion` while remaining explicitly preview-governed.",
        "- The active benchmark slice remains an exact carry-forward of `v0.8-preview`, so the current discussion is about trust, reproducibility, submission maturity, and reviewability rather than content breadth expansion.",
        "- The meaningful `v0.9-preview` delta is trust-surface hardening: provenance, observation consistency, comparison fairness, and stronger external review artifacts.",
        "- The audit posture remains conservative at `ready_for_preview_only`, which should be read as a stricter gate rather than as a contradiction of the analysis conclusion.",
    ]
    lines.extend(
        [
            "",
            "## Governance Questions This Handoff Supports",
            "",
            f"- {review_packet.get('main_governance_question')}",
            "- Should governance treat the remaining caution as interpretation and boundary-setting work rather than an engineering blocker?",
            "- Should any future `v1.0-formal` candidate remain stability-first instead of absorbing new benchmark breadth or platform ambition?",
            "",
            "## Why This Still Does Not Imply Freeze",
            "",
            f"- {promotion_gap.get('freeze_not_recommended_reason')}",
            "- Any future formal freeze would still require an explicit, bounded governance decision rather than a default promotion step.",
            "- The package supports formal discussion only. It does not request promotion, declare freeze completion, or open a new preview line.",
            "",
            "## Supporting Scope Note",
            "",
            "- `docs/product/v1_0_candidate_scope.md`",
            "",
        ]
    )
    return "\n".join(lines)


def _render_discussion_questions(bundle: dict[str, Any]) -> str:
    review_packet = bundle.get("review_packet", {})
    lines = [
        "# Discussion Questions",
        "",
        f"- Main governance question: {review_packet.get('main_governance_question')}",
        "",
        "## Decision Surface",
        "",
        "1. Should governance open formal discussion now while keeping `should_formalize_v0_9 = false` and `open_v1_0_preview = false`?",
        "2. Is the smallest remaining gap still accurately described as `governance_caution`, rather than an engineering or benchmark-content blocker?",
        "3. Should `v0.8-preview -> v0.9-preview` be recorded primarily as trust-surface hardening rather than another content-breadth expansion?",
        "4. Should any future `v1.0-formal` candidate stay stability-first, with trust, reproducibility, submission maturity, and reviewability treated as the core freeze criteria?",
        "5. Should any next platform-ambition line remain separate from this formal-discussion track rather than being folded into the current candidate base?",
        "",
    ]
    return "\n".join(lines)


def _render_formal_discussion_checklist(bundle: dict[str, Any]) -> str:
    review_packet = bundle.get("review_packet", {})
    promotion_gap = bundle.get("promotion_gap_report", {})
    smallest_gap = promotion_gap.get("smallest_remaining_gap")
    lines = [
        "# Formal Discussion Checklist",
        "",
        "- Active preview identity: verified",
        "  - Evidence: `pinn-bench version --json`, `review_packet.json`",
        f"  - Expected state: current preview line = `{review_packet.get('current_preview_line')}`",
        "- Outputs root: verified",
        "  - Evidence: `review_packet.json`, `pinn-bench doctor --preview --outputs-root outputs_preview_v09 --json`",
        "  - Expected state: outputs root = `outputs_preview_v09`",
        "- Frozen-root protection: verified",
        "  - Evidence: frozen-root pollution scans, formal-root verification notes",
        "  - Expected state: no writes under `outputs_v02` through `outputs_v06`",
        "- Preview doctor strict: passed",
        "  - Evidence: `pinn-bench doctor --preview --outputs-root outputs_preview_v09 --strict`",
        "- Preview audit: completed",
        "  - Evidence: `pinn-bench audit --preview v0.9-preview --outputs-root outputs_preview_v09 --json`",
        "- Analysis readiness: verified",
        "  - Evidence: `review_packet.json`, `decision_support.json`",
        f"  - Expected state: analysis readiness = `{review_packet.get('analysis_readiness_conclusion')}`",
        f"- Promotion-gap state: {'verified' if smallest_gap == 'governance_caution' else 'review required'}",
        "  - Evidence: `promotion_gap_report.json`",
        f"  - Expected state: smallest remaining gap = `{smallest_gap}`",
        "- Cross-version trust delta: verified",
        "  - Evidence: `cross_version_review.json`",
        "  - Expected state: `v0.9-preview vs v0.8-preview` = `trust_surface_hardening`",
        "- No automatic formalization claim present: verified",
        "  - Evidence: `formal_discussion_memo.md`, `executive_summary.md`",
        f"  - Expected state: `should_formalize_v0_9 = {'false' if review_packet.get('should_formalize_v0_9') is False else 'true'}`",
        "- Governance caution explicitly retained: verified",
        "  - Evidence: `promotion_gap_report.json`, `review_packet.json`",
        f"  - Expected state: main governance question = {review_packet.get('main_governance_question')}",
        "- Supporting scope note: ready",
        "  - Evidence: `docs/product/v1_0_candidate_scope.md`",
        "",
    ]
    return "\n".join(lines)


def _render_formal_discussion_brief(bundle: dict[str, Any]) -> str:
    review_packet = bundle.get("review_packet", {})
    promotion_gap = bundle.get("promotion_gap_report", {})
    cross_version = bundle.get("cross_version_review", {}).get("preview_vs_previous_preview", {})
    should_formalize = "false" if review_packet.get("should_formalize_v0_9") is False else "true"
    open_next_preview = "false" if review_packet.get("open_v1_0_preview") is False else "true"
    lines = [
        "# Formal Discussion Brief",
        "",
        "This brief compresses the existing `v0.9-preview` handoff package into a short governance pre-read. It supports formal discussion, not a freeze, release, or promotion notice.",
        "",
        "## 1. Current State",
        "",
        f"`v0.9-preview` is ready for formal discussion, while `{review_packet.get('current_formal_line')}` remains the current formal baseline.",
        "",
        f"- The active preview line remains `{review_packet.get('current_preview_line')}`, and the current posture stays `should_formalize_v0_9 = {should_formalize}` with `open_v1_0_preview = {open_next_preview}`.",
        f"- Analysis conclusion: `{review_packet.get('analysis_readiness_conclusion')}`.",
        "- The audit posture remains conservative at `ready_for_preview_only`, which is a stricter gate rather than a conflicting signal.",
        f"- The smallest remaining gap is `{promotion_gap.get('smallest_remaining_gap')}`.",
        "",
        "## 2. What Changed In v0.9",
        "",
        "The primary delta from `v0.8-preview` is trust-surface hardening over an unchanged carried-forward benchmark slice.",
        "",
        "- Reproducibility is stronger through provenance and observation-consistency assets.",
        "- Submission and review maturity are stronger through a more complete review surface and clearer external-review artifacts.",
        "- Fairness and comparability guidance are stronger, but the benchmark slice itself is still carried forward rather than broadened.",
        f"- Canonical cross-version label: `{cross_version.get('meaningful_delta')}`.",
        "",
        "## 3. Why Formal Discussion Is Appropriate Now",
        "",
        "Formal discussion is appropriate now because the evidence chain is complete enough for governance review, even though freeze remains a separate decision.",
        "",
        "- `review_packet`, `decision_support`, `promotion_gap_report`, and `cross_version_review` now provide a coherent discussion surface.",
        "- `pinn-bench doctor --preview --outputs-root outputs_preview_v09 --strict` passes, and preview audit succeeds with a conservative `ready_for_preview_only` verdict.",
        f"- The remaining gap is `{promotion_gap.get('smallest_remaining_gap')}` rather than an engineering blocker.",
        "",
        "## 4. Why Automatic Formalization Is Not Implied",
        "",
        "Formal discussion is appropriate now, but automatic formal promotion is not implied.",
        "",
        f"- The decision flags remain unchanged: `should_formalize_v0_9 = {should_formalize}` and `open_v1_0_preview = {open_next_preview}`.",
        "- `governance_caution` means the remaining work is about interpretation and boundary-setting, not an engineering failure.",
        f"- {promotion_gap.get('freeze_not_recommended_reason')}",
        "- Any future formal freeze would still require a separate explicit, bounded approval.",
        "",
        "## 5. What A Future v1.0 Candidate Should Mean",
        "",
        "A future `v1.0-formal` candidate should mean standard stability, not breadth expansion.",
        "",
        "- It should formalize trust, reproducibility, submission maturity, reviewability, and fairness expectations.",
        "- It should keep a stable slice policy and an explicit freeze boundary.",
        "- New benchmark breadth or platform ambition should remain outside this candidate track rather than being folded into the current discussion line.",
        "- Boundary note: `docs/product/v1_0_candidate_scope.md`.",
        "",
        "## 6. Discussion Decisions Requested",
        "",
        "This discussion should resolve a small set of governance decisions rather than reopen implementation detail.",
        "",
        "- Should governance open formal discussion now while keeping the current non-promotion posture in place?",
        "- Should the remaining caution continue to be treated as `governance_caution` rather than as an engineering blocker?",
        "- Should `v0.8-preview -> v0.9-preview` be recorded primarily as trust-surface hardening over an unchanged slice?",
        "- Should any future `v1.0-formal` candidate remain stability-first instead of absorbing new expansion work?",
        "- Should any next platform-ambition line remain separate from this formal-discussion track?",
        "",
        "## Evidence Map",
        "",
        "If you want to verify the main claims, start with the artifacts below.",
        "",
        "- Current state -> `pinn-bench version --json`, `review_packet.json`",
        "- Why discussion is appropriate now -> `review_packet.json`, `decision_support.json`",
        "- Why automatic promotion is not implied -> `promotion_gap_report.json`, `pinn-bench audit --preview v0.9-preview --outputs-root outputs_preview_v09 --json`",
        "- Trust delta vs `v0.8-preview` -> `cross_version_review.json`",
        "- Preview integrity -> `pinn-bench doctor --preview --outputs-root outputs_preview_v09 --strict`",
        "- v1.0 boundary -> `docs/product/v1_0_candidate_scope.md`",
        "",
        "## Governance Notes",
        "",
        "The three voices in this handoff are complementary rather than conflicting.",
        "",
        f"- Analysis conclusion: `{review_packet.get('analysis_readiness_conclusion')}`.",
        "- Audit verdict: `ready_for_preview_only`.",
        "- Governance interpretation: discussion-ready does not equal freeze-ready.",
        "",
    ]
    return "\n".join(lines)


def generate_analysis_bundle(
    *,
    outputs_root: Path,
    output_dir: Path,
    formal_root: Path | None,
    previous_formal_root: Path | None,
) -> dict[str, Any]:
    inputs = load_analysis_inputs(outputs_root=outputs_root, formal_root=formal_root, previous_formal_root=previous_formal_root)
    preview_info = get_preview_line_info(inputs.preview_line)
    existing_history_entries = list_history_entries(output_dir)
    previous_history_entry = latest_history_entry(output_dir)
    previous_observation_snapshot, previous_history_entry_name = _load_previous_observation_snapshot(previous_history_entry)
    previous_analysis_bundle = _load_previous_analysis_bundle(previous_history_entry)
    current_history_stamp = _history_stamp()
    current_history_entry_path = output_dir.resolve() / "history" / current_history_stamp
    observation_time = _utc_now()

    counts = {
        "grouped_rows": len(inputs.grouped_rows),
        "reporting_rows": len(inputs.reporting_rows),
        "pareto_rows": len(inputs.pareto_rows),
        "robustness_rows": len(inputs.robustness_rows),
        "field_grouped_rows": sum(1 for row in inputs.grouped_rows if str(row.get("task_mode") or "pointwise") == "field"),
        "planned_runs": len(inputs.grouped_rows) * len(inputs.grouped_payload.get("default_seeds") or []),
    }
    comparative_report = build_comparative_report(inputs)
    hardness_report = build_hardness_report(comparative_report)
    diagnostics = build_diagnostics(inputs, comparative_report=comparative_report, cross_version_review={})
    cross_version_review = build_cross_version_review(inputs)
    diagnostics = build_diagnostics(inputs, comparative_report=comparative_report, cross_version_review=cross_version_review)
    reproducibility_facts = _build_reproducibility_facts(inputs, preview_line=preview_info.preview_line)
    comparison_fairness = _build_comparison_fairness(inputs, cross_version_review=cross_version_review, diagnostics=diagnostics)
    leaderboard_protocol_surface = _load_leaderboard_protocol_surface(inputs.outputs_root)
    dx_surface = _load_dx_surface()
    operator_abstraction_surface = build_operator_abstraction_surface(inputs)
    stress_surface_summary = _build_stress_surface_summary(
        comparative_report=comparative_report,
        preview_line=preview_info.preview_line,
    )
    cross_line_consolidation_summary = _build_cross_line_consolidation_summary(
        preview_line=preview_info.preview_line,
        current_formal_line=preview_info.current_formal_line,
    )
    external_adoption_summary = _build_external_adoption_summary(preview_line=preview_info.preview_line)
    publication_packaging_summary = _build_publication_packaging_summary(preview_line=preview_info.preview_line)
    benchmark_positioning_summary = _build_benchmark_positioning_summary(
        preview_line=preview_info.preview_line,
        current_formal_line=preview_info.current_formal_line,
    )
    decision_support = build_decision_support(
        inputs,
        comparative_report=comparative_report,
        diagnostics=diagnostics,
        cross_version_review=cross_version_review,
        reproducibility_facts=reproducibility_facts,
        comparison_fairness=comparison_fairness,
    )
    readiness_matrix = build_readiness_matrix(decision_support)
    promotion_gap_report = build_promotion_gap_report(decision_support, readiness_matrix)
    observation_snapshot = build_observation_snapshot(
        preview_line=preview_info.preview_line,
        current_formal_line=preview_info.current_formal_line,
        counts=counts,
        comparative_report=comparative_report,
        diagnostics=diagnostics,
        decision_support=decision_support,
        promotion_gap_report=promotion_gap_report,
        observation_time=observation_time,
        history_entry_name=current_history_stamp,
        expected_history_entry_count=len(existing_history_entries) + 1,
        previous_history_entry=previous_history_entry_name,
    )
    observation_consistency = _build_observation_consistency(
        preview_line=preview_info.preview_line,
        counts=counts,
        diagnostics=diagnostics,
        decision_support=decision_support,
        promotion_gap_report=promotion_gap_report,
        reproducibility_facts=reproducibility_facts,
        previous_analysis_bundle=previous_analysis_bundle,
    )
    preview_evolution_record = build_preview_evolution_record(
        preview_line=preview_info.preview_line,
        current_formal_line=preview_info.current_formal_line,
        cross_version_review=cross_version_review,
        current_observation_snapshot=observation_snapshot,
        previous_observation_snapshot=previous_observation_snapshot,
        previous_history_entry=previous_history_entry_name,
    )
    release_review = build_release_review(
        inputs,
        decision_support=decision_support,
        cross_version_review=cross_version_review,
        diagnostics=diagnostics,
    )
    table_hints = build_table_hints(inputs, diagnostics=diagnostics, comparative_report=comparative_report)
    review_packet = build_review_packet(
        preview_line=preview_info.preview_line,
        current_formal_line=preview_info.current_formal_line,
        pack_identity=inputs.pack_identity,
        counts=counts,
        cross_version_review=cross_version_review,
        diagnostics=diagnostics,
        decision_support=decision_support,
        readiness_matrix=readiness_matrix,
        promotion_gap_report=promotion_gap_report,
        comparative_report=comparative_report,
        observation_snapshot=observation_snapshot,
        reproducibility_facts=reproducibility_facts,
        observation_consistency=observation_consistency,
        comparison_fairness=comparison_fairness,
        leaderboard_protocol_summary=leaderboard_protocol_surface["leaderboard_protocol_summary"],
        admission_summary=leaderboard_protocol_surface["admission_summary"],
        view_coverage_summary=leaderboard_protocol_surface["view_coverage_summary"],
        leaderboard_governance_caveats=leaderboard_protocol_surface["leaderboard_governance_caveats"],
        dx_surface_summary=dx_surface["dx_surface_summary"],
        template_catalog_summary=dx_surface["template_catalog_summary"],
        quickstart_surface_summary=dx_surface["quickstart_surface_summary"],
        logging_hook_summary=dx_surface["logging_hook_summary"],
        capability_surface_summary=operator_abstraction_surface["capability_surface_summary"],
        observation_target_surface_summary=operator_abstraction_surface["observation_target_surface_summary"],
        operator_ready_summary=operator_abstraction_surface["operator_ready_summary"],
        stress_surface_summary=stress_surface_summary,
        cross_line_consolidation_summary=cross_line_consolidation_summary,
        external_adoption_summary=external_adoption_summary,
        publication_packaging_summary=publication_packaging_summary,
        benchmark_positioning_summary=benchmark_positioning_summary,
    )
    release_packet_draft = build_release_packet_draft(review_packet, release_review)
    executive_summary = build_executive_summary(review_packet, promotion_gap_report)

    breadth_delta = comparative_report.get("breadth_delta", {})
    content_breadth_delta = {
        "preview_line": preview_info.preview_line,
        "grouped_row_delta_vs_previous_preview": breadth_delta.get("grouped_row_delta"),
        "current_grouped_rows": breadth_delta.get("current_grouped_rows"),
        "previous_preview_grouped_rows": breadth_delta.get("previous_preview_grouped_rows"),
        "new_operator_tasks": breadth_delta.get("new_operator_tasks", []),
        "new_operator_baselines": breadth_delta.get("new_operator_baselines", []),
        "new_field_protocols": breadth_delta.get("new_field_protocols", []),
    }
    operator_task_breadth_delta = {
        "current_operator_tasks": breadth_delta.get("current_field_tasks", []),
        "previous_preview_operator_tasks": breadth_delta.get("previous_preview_field_tasks", []),
        "new_operator_tasks": breadth_delta.get("new_operator_tasks", []),
    }
    operator_baseline_breadth_delta = {
        "current_operator_baselines": breadth_delta.get("current_field_baselines", []),
        "previous_preview_operator_baselines": breadth_delta.get("previous_preview_field_baselines", []),
        "new_operator_baselines": breadth_delta.get("new_operator_baselines", []),
    }
    field_protocol_breadth_delta = {
        "current_field_protocols": breadth_delta.get("current_field_protocols", []),
        "previous_preview_field_protocols": breadth_delta.get("previous_preview_field_protocols", []),
        "new_field_protocols": breadth_delta.get("new_field_protocols", []),
        "host_tasks": breadth_delta.get("field_protocol_host_tasks", []),
        "coverage_characterization": "local_preview_growth" if breadth_delta.get("new_field_protocols") else "unchanged",
    }

    if preview_info.preview_line == "v1.9-preview":
        schema_version = "analysis.bundle.v1.3"
    elif preview_info.preview_line == "v1.8-preview":
        schema_version = "analysis.bundle.v1.2"
    elif preview_info.preview_line == "v1.6-preview":
        schema_version = "analysis.bundle.v1.0"
    elif preview_info.preview_line == "v1.7-preview":
        schema_version = "analysis.bundle.v1.1"
    elif preview_info.preview_line == "v1.5-preview":
        schema_version = "analysis.bundle.v0.9"
    elif preview_info.preview_line == "v1.4-preview":
        schema_version = "analysis.bundle.v0.8"
    elif preview_info.preview_line == "v1.2-preview":
        schema_version = "analysis.bundle.v0.7"
    elif preview_info.preview_line == "v1.1-preview":
        schema_version = "analysis.bundle.v0.6"
    elif preview_info.preview_line == "v0.9-preview":
        schema_version = "analysis.bundle.v0.5"
    elif preview_info.preview_line == "v0.8-preview":
        schema_version = "analysis.bundle.v0.4"
    else:
        schema_version = "analysis.bundle.v0.3"

    bundle = {
        "schema_version": schema_version,
        "generated_at": observation_time,
        "outputs_root": str(inputs.outputs_root),
        "analysis_dir": str(output_dir.resolve()),
        "pack_identity": dict(inputs.pack_identity),
        "formal_root": None if inputs.formal_reference is None else str(inputs.formal_reference.outputs_root),
        "previous_formal_root": None if inputs.previous_formal_reference is None else str(inputs.previous_formal_reference.outputs_root),
        "previous_preview_root": None if inputs.previous_preview_reference is None else str(inputs.previous_preview_reference.outputs_root),
        "preview_line": preview_info.preview_line,
        "counts": counts,
        "history": {
            "policy": "latest_plus_history",
            "history_root": str((output_dir.resolve() / 'history')),
            "previous_entry_count": len(existing_history_entries),
            "expected_entry_count_after_write": len(existing_history_entries) + 1,
            "latest_previous_entry": None if previous_history_entry is None else str(previous_history_entry),
            "current_entry_name": current_history_stamp,
            "current_entry_path": str(current_history_entry_path),
        },
        "month_sprint": {
            "theme": preview_info.month_theme,
            "current_phase_anchor": preview_info.phase_anchor,
            "previous_history_bundle_present": previous_analysis_bundle is not None,
        },
        "content_breadth_delta": content_breadth_delta,
        "operator_task_breadth_delta": operator_task_breadth_delta,
        "operator_baseline_breadth_delta": operator_baseline_breadth_delta,
        "field_protocol_breadth_delta": field_protocol_breadth_delta,
        "reproducibility_facts": reproducibility_facts,
        "observation_consistency": observation_consistency,
        "comparison_fairness": comparison_fairness,
        "leaderboard_protocol_summary": leaderboard_protocol_surface["leaderboard_protocol_summary"],
        "admission_summary": leaderboard_protocol_surface["admission_summary"],
        "view_coverage_summary": leaderboard_protocol_surface["view_coverage_summary"],
        "leaderboard_governance_caveats": leaderboard_protocol_surface["leaderboard_governance_caveats"],
        "dx_surface_summary": dx_surface["dx_surface_summary"],
        "template_catalog_summary": dx_surface["template_catalog_summary"],
        "quickstart_surface_summary": dx_surface["quickstart_surface_summary"],
        "logging_hook_summary": dx_surface["logging_hook_summary"],
        "capability_surface_summary": operator_abstraction_surface["capability_surface_summary"],
        "observation_target_surface_summary": operator_abstraction_surface["observation_target_surface_summary"],
        "operator_ready_summary": operator_abstraction_surface["operator_ready_summary"],
        "stress_surface_summary": stress_surface_summary,
        "cross_line_consolidation_summary": cross_line_consolidation_summary,
        "external_adoption_summary": external_adoption_summary,
        "publication_packaging_summary": publication_packaging_summary,
        "benchmark_positioning_summary": benchmark_positioning_summary,
        "comparative_report": comparative_report,
        "hardness_report": hardness_report,
        "diagnostics": diagnostics,
        "decision_support": decision_support,
        "readiness_matrix": readiness_matrix,
        "promotion_gap_report": promotion_gap_report,
        "observation_snapshot": observation_snapshot,
        "preview_evolution_record": preview_evolution_record,
        "review_packet": review_packet,
        "release_packet_draft": release_packet_draft,
        "release_review": release_review,
        "table_hints": table_hints,
        "cross_version_review": cross_version_review,
        "executive_summary": executive_summary,
    }
    return bundle



def write_analysis_assets(bundle: dict[str, Any], *, output_dir: Path) -> dict[str, str]:
    output_dir.mkdir(parents=True, exist_ok=True)
    paths = analysis_asset_paths(output_dir, preview_line=str(bundle.get("preview_line") or "v0.7-preview"))
    write_json(paths["analysis_bundle"], bundle)

    sections = {
        "comparative_report": (bundle["comparative_report"], render_comparative_report_markdown(bundle["comparative_report"])),
        "diagnostics": (bundle["diagnostics"], render_diagnostics_markdown(bundle["diagnostics"])),
        "decision_support": (bundle["decision_support"], render_decision_support_markdown(bundle["decision_support"])),
        "release_review": (bundle["release_review"], render_release_review_markdown(bundle["release_review"])),
        "table_hints": (bundle["table_hints"], render_table_hints_markdown(bundle["table_hints"])),
        "cross_version_review": (bundle["cross_version_review"], render_cross_version_review_markdown(bundle["cross_version_review"])),
        "hardness_report": (bundle["hardness_report"], render_hardness_report_markdown(bundle["hardness_report"])),
        "observation_snapshot": (bundle["observation_snapshot"], render_observation_snapshot_markdown(bundle["observation_snapshot"])),
        "preview_evolution_record": (bundle["preview_evolution_record"], render_preview_evolution_record_markdown(bundle["preview_evolution_record"])),
        "review_packet": (bundle["review_packet"], render_review_packet_markdown(bundle["review_packet"])),
        "release_packet_draft": (bundle["release_packet_draft"], render_release_packet_draft_markdown(bundle["release_packet_draft"])),
        "readiness_matrix": (bundle["readiness_matrix"], render_readiness_matrix_markdown(bundle["readiness_matrix"])),
        "promotion_gap_report": (bundle["promotion_gap_report"], render_promotion_gap_report_markdown(bundle["promotion_gap_report"])),
    }
    if "observation_consistency" in bundle:
        sections["observation_consistency"] = (bundle["observation_consistency"], _render_observation_consistency_markdown(bundle["observation_consistency"]))
    if "comparison_fairness" in bundle:
        sections["comparison_fairness"] = (bundle["comparison_fairness"], _render_comparison_fairness_markdown(bundle["comparison_fairness"]))

    written = {"analysis_bundle": str(paths["analysis_bundle"].resolve())}
    for base, (payload, markdown) in sections.items():
        json_path = paths.get(f"{base}_json")
        md_path = paths.get(f"{base}_md")
        if json_path is not None:
            write_json(json_path, payload)
            written[f"{base}_json"] = str(json_path.resolve())
        if md_path is not None:
            md_path.write_text(markdown, encoding="utf-8")
            written[f"{base}_md"] = str(md_path.resolve())

    paths["diagnostics_compact_md"].write_text(render_diagnostics_compact_markdown(bundle["diagnostics"]), encoding="utf-8")
    paths["executive_summary_md"].write_text(render_executive_summary_markdown(bundle["executive_summary"]), encoding="utf-8")
    written["diagnostics_compact_md"] = str(paths["diagnostics_compact_md"].resolve())
    written["executive_summary_md"] = str(paths["executive_summary_md"].resolve())

    if "formal_discussion_memo_md" in paths:
        paths["formal_discussion_memo_md"].write_text(_render_formal_discussion_memo(bundle), encoding="utf-8")
        written["formal_discussion_memo_md"] = str(paths["formal_discussion_memo_md"].resolve())
    if "discussion_questions_md" in paths:
        paths["discussion_questions_md"].write_text(_render_discussion_questions(bundle), encoding="utf-8")
        written["discussion_questions_md"] = str(paths["discussion_questions_md"].resolve())
    if "formal_discussion_checklist_md" in paths:
        paths["formal_discussion_checklist_md"].write_text(_render_formal_discussion_checklist(bundle), encoding="utf-8")
        written["formal_discussion_checklist_md"] = str(paths["formal_discussion_checklist_md"].resolve())
    if "formal_discussion_brief_md" in paths:
        paths["formal_discussion_brief_md"].write_text(_render_formal_discussion_brief(bundle), encoding="utf-8")
        written["formal_discussion_brief_md"] = str(paths["formal_discussion_brief_md"].resolve())
    return written



def archive_analysis_assets(*, output_dir: Path, entry_name: str) -> dict[str, Any]:
    paths = analysis_asset_paths(output_dir)
    history_dir = paths["history_dir"]
    history_dir.mkdir(parents=True, exist_ok=True)
    entry_dir = history_dir / entry_name
    entry_dir.mkdir(parents=True, exist_ok=False)

    copied_files = []
    for key, path in paths.items():
        if key == "history_dir":
            continue
        if not path.exists():
            continue
        destination = entry_dir / path.name
        shutil.copy2(path, destination)
        copied_files.append(str(destination.resolve()))
    return {
        "entry_dir": str(entry_dir.resolve()),
        "entry_name": entry_dir.name,
        "copied_files": copied_files,
        "history_entry_count": len(list_history_entries(output_dir)),
    }



def main(argv: Sequence[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    outputs_root = Path(args.outputs_root)
    output_dir = outputs_root / "_analysis" if args.output_dir is None else Path(args.output_dir)
    formal_root = None if args.formal_root is None else Path(args.formal_root)
    previous_formal_root = None if args.previous_formal_root is None else Path(args.previous_formal_root)
    bundle = generate_analysis_bundle(
        outputs_root=outputs_root,
        output_dir=output_dir,
        formal_root=formal_root,
        previous_formal_root=previous_formal_root,
    )
    written = write_analysis_assets(bundle, output_dir=output_dir)
    archive = archive_analysis_assets(output_dir=output_dir, entry_name=str(bundle.get("history", {}).get("current_entry_name") or _history_stamp()))
    print(
        json.dumps(
            {
                "analysis_dir": str(output_dir.resolve()),
                "written": written,
                "counts": bundle["counts"],
                "history": archive,
            },
            indent=2,
        )
    )
