"""Shared fairness classification helpers for analysis and community review paths."""

from __future__ import annotations

from typing import Any

from pinn_bench.stress import build_stress_comparability_policy


def _bool_text(value: bool) -> str:
    return "yes" if value else "no"


FAIRNESS_TO_COMPARISON_KIND = {
    "fair": "fair",
    "mostly_fair": "partial",
    "caution": "partial",
    "partial": "partial",
    "not_comparable": "incompatible",
}


COMPARISON_STRENGTH_ORDER = {
    "strong": 0,
    "moderate": 1,
    "limited": 2,
    "none": 3,
}


def assess_comparison_fairness(
    *,
    benchmark_line_match: bool,
    slice_match: bool,
    protocol_supported: bool,
    mode_compatible: bool,
    artifact_completeness: str,
    reference_available: bool,
    context_label: str,
) -> dict[str, Any]:
    """Return additive fairness metadata while preserving existing public enums elsewhere."""

    completeness = str(artifact_completeness or "partial").strip().lower()
    if completeness not in {"complete", "partial", "missing_critical"}:
        completeness = "partial"

    notes = [
        f"benchmark_line_match={_bool_text(benchmark_line_match)}",
        f"slice_match={_bool_text(slice_match)}",
        f"protocol_supported={_bool_text(protocol_supported)}",
        f"mode_compatible={_bool_text(mode_compatible)}",
        f"artifact_completeness={completeness}",
        f"reference_available={_bool_text(reference_available)}",
    ]

    if completeness == "missing_critical" or not protocol_supported:
        fairness_category = "not_comparable"
        comparison_strength = "none"
        appendix_only_recommended = True
        fairness_notes = [
            f"{context_label} is missing critical evidence or protocol support, so the comparison should not be treated as rankable.",
            "Keep the result in compatibility-review territory until the missing evidence is repaired.",
        ]
    elif benchmark_line_match and slice_match and mode_compatible and reference_available and completeness == "complete":
        fairness_category = "fair"
        comparison_strength = "strong"
        appendix_only_recommended = False
        fairness_notes = [
            f"{context_label} matches the requested benchmark line and slice closely enough for bounded ranking discussion.",
            "Even in the fair case, keep claims slice-local rather than treating one row as a global benchmark verdict.",
        ]
    elif slice_match and protocol_supported and mode_compatible and reference_available:
        fairness_category = "mostly_fair" if benchmark_line_match else "caution"
        comparison_strength = "moderate" if benchmark_line_match else "limited"
        appendix_only_recommended = not benchmark_line_match or completeness != "complete"
        fairness_notes = [
            f"{context_label} remains reviewable, but at least one trust precondition is weaker than the fully fair case.",
            "Use caveated narrative and preserve fairness notes near any ranking-style summary.",
        ]
    elif reference_available and protocol_supported:
        fairness_category = "partial"
        comparison_strength = "limited"
        appendix_only_recommended = True
        fairness_notes = [
            f"{context_label} supports a partial comparison, but contract or slice differences are too large for headline ranking claims.",
            "Prefer appendix-style or discussion-only treatment over main-table treatment.",
        ]
    else:
        fairness_category = "not_comparable"
        comparison_strength = "none"
        appendix_only_recommended = True
        fairness_notes = [
            f"{context_label} lacks enough matched evidence for a trustworthy comparison.",
            "Treat the output as non-comparable until a matching reference or contract-aligned slice exists.",
        ]

    fairness_notes.extend(notes)
    rank_context_notes = [
        "Ranking context remains advisory and slice-local.",
        "Fairness category should be read before any approximate rank or delta claim.",
    ]
    return {
        "fairness_category": fairness_category,
        "comparison_kind": FAIRNESS_TO_COMPARISON_KIND[fairness_category],
        "comparison_strength": comparison_strength,
        "appendix_only_recommended": appendix_only_recommended,
        "fairness_notes": fairness_notes,
        "rank_context_notes": rank_context_notes,
        "factors": {
            "benchmark_line_match": benchmark_line_match,
            "slice_match": slice_match,
            "protocol_supported": protocol_supported,
            "mode_compatible": mode_compatible,
            "artifact_completeness": completeness,
            "reference_available": reference_available,
        },
    }


def assess_stress_comparability(rows: list[dict[str, Any]]) -> dict[str, Any]:
    policy = build_stress_comparability_policy(rows)
    return {
        "policy_class": policy.get("summary"),
        "official_comparison_contract": list(policy.get("official_comparison_contract", [])),
        "appendix_only_conditions": list(policy.get("appendix_only_conditions", [])),
        "official_stress_row_count": int(policy.get("official_stress_row_count", 0) or 0),
        "appendix_only_stress_row_count": int(policy.get("appendix_only_stress_row_count", 0) or 0),
        "comparability_notes": list(policy.get("comparability_notes", [])),
        "official_stress_case_ids": list(policy.get("official_stress_case_ids", [])),
        "appendix_only_run_ids": list(policy.get("appendix_only_run_ids", [])),
    }
