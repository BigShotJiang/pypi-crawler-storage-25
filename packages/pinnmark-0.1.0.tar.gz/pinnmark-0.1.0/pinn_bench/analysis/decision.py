"""Decision-support logic for the analysis preview line."""

from __future__ import annotations

from typing import Any

from pinn_bench.analysis.normalize import AnalysisInputs
from pinn_bench.analysis.preview_line import get_preview_line_info


READINESS_DIMENSIONS = [
    "engineering_stability",
    "asset_completeness",
    "reproducibility",
    "comparison_fairness",
    "interpretation_quality",
    "onboarding_sufficiency",
    "slice_breadth",
    "governance_caution",
]



def _dimension(name: str, status: str, evidence: list[str]) -> dict[str, Any]:
    return {"name": name, "status": status, "evidence": evidence}



def derive_analysis_readiness_conclusion(*, formal_discussion_recommendation: str, smallest_gap: str, dimensions: dict[str, Any]) -> str:
    non_governance_gaps = [
        name
        for name, item in dimensions.items()
        if name != "governance_caution" and str(item.get("status")) == "gap"
    ]
    if non_governance_gaps:
        return "ready_for_preview_only"
    if formal_discussion_recommendation == "ready_for_formal_discussion" and smallest_gap in {"governance_caution", "reproducibility", "comparison_fairness"}:
        return "ready_for_formal_discussion"
    if formal_discussion_recommendation == "ready_for_formal_discussion":
        return "approaching_ready_for_freeze"
    return "ready_for_preview_only"



def _docs_ready(inputs: AnalysisInputs) -> bool:
    info = get_preview_line_info(inputs.preview_line)
    required = [
        inputs.repo_root / "docs" / "product" / "analysis.md",
        inputs.repo_root / "docs" / "experiments" / "analysis_surfaces.md",
    ]
    required.extend(inputs.repo_root / path for path in info.docs)
    return all(path.exists() for path in required)



def _count_field_baselines(rows: list[dict[str, Any]]) -> int:
    return len(
        {
            str(row.get("model_name") or "unknown")
            for row in rows
            if str(row.get("task_mode") or "pointwise") == "field" and str(row.get("protocol") or "none") == "none"
        }
    )



def build_decision_support(
    inputs: AnalysisInputs,
    *,
    comparative_report: dict[str, Any],
    diagnostics: dict[str, Any],
    cross_version_review: dict[str, Any],
    reproducibility_facts: dict[str, Any],
    comparison_fairness: dict[str, Any],
) -> dict[str, Any]:
    info = get_preview_line_info(inputs.preview_line)
    diagnostics_summary = diagnostics.get("summary", {})
    diagnostic_codes = {str(item.get("code")) for item in diagnostics.get("findings", []) if isinstance(item, dict)}
    preview_vs_formal = cross_version_review.get("preview_vs_current_formal", {})
    preview_vs_previous_preview = cross_version_review.get("preview_vs_previous_preview", {})
    mirrored_slice = bool(preview_vs_formal.get("mirrors_benchmark_slice"))
    preview_complete = (
        len(inputs.grouped_rows) > 0
        and len(inputs.reporting_rows) > 0
        and len(inputs.pareto_rows) > 0
        and len(inputs.robustness_rows) > 0
    )
    analysis_docs_ready = _docs_ready(inputs)
    pointwise_tasks = comparative_report.get("mode_comparison", {}).get("pointwise", {}).get("task_count", 0)
    operator_tasks = comparative_report.get("mode_comparison", {}).get("operator", {}).get("task_count", 0)
    operator_baselines = _count_field_baselines(inputs.grouped_rows)

    engineering_blockers: list[str] = []
    if not preview_complete:
        engineering_blockers.append("One or more required benchmark roots are missing grouped/reporting/pareto/robustness assets.")

    asset_completeness_issues: list[str] = []
    if "comparison_quality.missing_clean_reference" in diagnostic_codes:
        asset_completeness_issues.append("At least one robustness row is missing a clean reference for degradation comparison.")
    if info.preview_line == "v0.7-preview" and not mirrored_slice:
        asset_completeness_issues.append("The preview slice no longer mirrors the current formal root, so cross-version review is unstable.")
    if info.preview_line in {"v0.8-preview", "v0.9-preview", "v1.1-preview"} and inputs.previous_preview_reference is None:
        asset_completeness_issues.append(
            f"The active preview line is missing a readable `{info.previous_preview_line}` reference root for historical comparison."
        )

    reproducibility_issues: list[str] = []
    if info.preview_line in {"v0.9-preview", "v1.1-preview"}:
        if not reproducibility_facts.get("provenance_surface_present"):
            reproducibility_issues.append("Per-run provenance sidecars are not yet present across the active preview slice.")
        if not reproducibility_facts.get("snapshot_linkage_present"):
            reproducibility_issues.append("Release snapshot linkage is missing from the active preview outputs root.")

    fairness_issues: list[str] = []
    fairness_surfaces = comparison_fairness.get("surfaces", {})
    stress_policy = comparison_fairness.get("stress_policy", {}) if isinstance(comparison_fairness, dict) else {}
    previous_preview_fairness = fairness_surfaces.get("preview_vs_previous_preview", {}) if isinstance(fairness_surfaces, dict) else {}
    if info.preview_line in {"v0.9-preview", "v1.1-preview"}:
        fairness_category = str(previous_preview_fairness.get("fairness_category") or "not_comparable")
        if fairness_category in {"partial", "not_comparable"}:
            fairness_issues.append("The comparison against the previous preview line is not yet fair enough for trust-oriented review.")
    if info.preview_line == "v1.1-preview" and str(stress_policy.get("policy_class") or "") == "appendix_only":
        fairness_issues.append("Stress metadata is present, but the current preview root does not yet expose enough official severity-matched stress comparisons.")

    interpretation_quality_issues: list[str] = []
    if diagnostics_summary.get("warning", 0):
        interpretation_quality_issues.append("Warning-level diagnostics are still present in the analysis surface.")

    onboarding_sufficiency_issues: list[str] = []
    if not analysis_docs_ready:
        onboarding_sufficiency_issues.append("Analysis docs or experiment docs are missing, so the review surface is not discoverable enough.")

    slice_breadth_issues: list[str] = []
    breadth_delta = comparative_report.get("breadth_delta", {})
    if info.preview_line == "v0.7-preview":
        if operator_tasks and pointwise_tasks and operator_tasks < pointwise_tasks:
            slice_breadth_issues.append(
                f"Operator breadth remains narrower than pointwise breadth ({operator_tasks} vs {pointwise_tasks} tasks)."
            )
    elif info.preview_line == "v0.8-preview":
        new_tasks = breadth_delta.get("new_operator_tasks", [])
        new_baselines = breadth_delta.get("new_operator_baselines", [])
        new_field_protocols = breadth_delta.get("new_field_protocols", [])
        if not new_tasks:
            slice_breadth_issues.append("The current preview root does not yet show any new operator task breadth versus `v0.7-preview`.")
        if not new_baselines:
            slice_breadth_issues.append("The current preview root does not yet show any new operator baseline breadth versus `v0.7-preview`.")
        if not new_field_protocols:
            slice_breadth_issues.append("The current preview root does not yet show any new field-protocol breadth versus `v0.7-preview`.")
    elif info.preview_line == "v0.9-preview":
        if int(breadth_delta.get("grouped_row_delta") or 0) != 0:
            slice_breadth_issues.append("`v0.9-preview` should carry forward the `v0.8-preview` slice exactly, but grouped-row counts drifted.")
        if breadth_delta.get("new_operator_tasks") or breadth_delta.get("new_operator_baselines") or breadth_delta.get("new_field_protocols"):
            slice_breadth_issues.append("`v0.9-preview` is trust-focused and should not widen benchmark content relative to `v0.8-preview`.")
    elif info.preview_line == "v1.1-preview":
        if int(breadth_delta.get("grouped_row_delta") or 0) != 16:
            slice_breadth_issues.append("`v1.1-preview` should add exactly the 16-run stress sentinel overlay on top of the carried-forward `v1.0` slice.")

    governance_cautions = [
        f"`{info.preview_line}` is still a preview line, so any freeze-level interpretation should remain a governance decision rather than an automatic machine conclusion.",
    ]
    if info.preview_line == "v0.7-preview":
        governance_cautions.append(
            "The benchmark slice is intentionally mirrored from `v0.6`, so the line should be judged on review quality rather than benchmark-content novelty."
        )
    elif info.preview_line == "v0.8-preview":
        governance_cautions.append(
            "The new breadth remains preview-scale and partially local to `heat1d_field`, so governance should treat formal discussion as evidence review rather than automatic promotion."
        )
    elif info.preview_line == "v1.1-preview":
        governance_cautions.append(
            "The stress sentinel overlay is a governance-grade robustness surface, not a new formal slice or a permission slip for pooled stress rankings."
        )
    else:
        governance_cautions.append(
            "The active slice is intentionally unchanged, so the decision question is trust and reproducibility maturity rather than whether even more content should be added."
        )

    dimensions = {
        "engineering_stability": _dimension(
            "engineering_stability",
            "healthy" if not engineering_blockers else "gap",
            [
                f"grouped_rows={len(inputs.grouped_rows)}",
                f"reporting_rows={len(inputs.reporting_rows)}",
                f"pareto_rows={len(inputs.pareto_rows)}",
                f"robustness_rows={len(inputs.robustness_rows)}",
            ]
            + engineering_blockers,
        ),
        "asset_completeness": _dimension(
            "asset_completeness",
            "healthy" if not asset_completeness_issues else "gap",
            [
                f"preview_line={info.preview_line}",
                f"diagnostic_warnings={diagnostics_summary.get('warning', 0)}",
                f"mirrored_slice={mirrored_slice}",
                f"previous_preview_reference_present={inputs.previous_preview_reference is not None}",
            ]
            + asset_completeness_issues,
        ),
        "reproducibility": _dimension(
            "reproducibility",
            "healthy" if not reproducibility_issues else "partial",
            [
                f"provenance_surface_present={reproducibility_facts.get('provenance_surface_present')}",
                f"provenance_sidecar_count={reproducibility_facts.get('provenance_sidecar_count')}",
                f"snapshot_linkage_present={reproducibility_facts.get('snapshot_linkage_present')}",
            ]
            + reproducibility_issues,
        ),
        "comparison_fairness": _dimension(
            "comparison_fairness",
            "healthy" if not fairness_issues else "partial",
            [
                f"previous_preview_fairness={previous_preview_fairness.get('fairness_category')}",
                f"previous_preview_strength={previous_preview_fairness.get('comparison_strength')}",
                "Fairness labels remain advisory trust signals rather than publication decisions.",
            ]
            + fairness_issues,
        ),
        "interpretation_quality": _dimension(
            "interpretation_quality",
            "healthy" if not interpretation_quality_issues else "partial",
            [
                f"diagnostic_cautions={diagnostics_summary.get('caution', 0)}",
                "Analysis wording should stay observational and preview-aware even when the assets are complete.",
                f"mixed_mode_caution_managed={'comparison_quality.mixed_mode_caution' in diagnostic_codes}",
            ]
            + interpretation_quality_issues,
        ),
        "onboarding_sufficiency": _dimension(
            "onboarding_sufficiency",
            "healthy" if not onboarding_sufficiency_issues else "gap",
            [
                f"analysis_docs_ready={analysis_docs_ready}",
                "The analysis layer should be discoverable from product docs and experiment docs, not only from code.",
            ]
            + onboarding_sufficiency_issues,
        ),
        "slice_breadth": _dimension(
            "slice_breadth",
            "healthy" if not slice_breadth_issues else "partial",
            [
                f"pointwise_tasks={pointwise_tasks}",
                f"operator_tasks={operator_tasks}",
                f"operator_baselines={operator_baselines}",
                f"previous_preview_reference={preview_vs_previous_preview.get('comparison')}",
            ]
            + slice_breadth_issues,
        ),
        "governance_caution": _dimension(
            "governance_caution",
            "partial",
            governance_cautions,
        ),
    }

    smallest_gap = "governance_caution"
    for name in READINESS_DIMENSIONS:
        status = str(dimensions[name].get("status"))
        if status in {"gap", "partial"}:
            smallest_gap = name
            break

    if any(str(dimensions[name].get("status")) == "gap" for name in READINESS_DIMENSIONS if name != "governance_caution"):
        overall_recommendation = "harden_analysis_assets"
        formal_discussion_recommendation = "not_ready_for_formal_discussion"
    elif smallest_gap in {"governance_caution", "slice_breadth", "reproducibility", "comparison_fairness"}:
        overall_recommendation = "continue_preview_observation"
        formal_discussion_recommendation = "ready_for_formal_discussion"
    else:
        overall_recommendation = "continue_preview_observation"
        formal_discussion_recommendation = "continue_preview_observation"

    analysis_readiness_conclusion = derive_analysis_readiness_conclusion(
        formal_discussion_recommendation=formal_discussion_recommendation,
        smallest_gap=smallest_gap,
        dimensions=dimensions,
    )

    evidence_backed_observations = [
        "Grouped, reporting, pareto, and robustness assets are present for the active preview root.",
    ]
    if info.preview_line == "v0.7-preview":
        evidence_backed_observations.append(
            "The preview line mirrors the formal `v0.6` slice, so cross-version interpretation can focus on analysis-surface change rather than benchmark-content change."
        )
    elif info.preview_line == "v0.8-preview":
        evidence_backed_observations.append(
            "The preview line widens task, baseline, and field-protocol breadth while inheriting the review surface first developed in `v0.7-preview`."
        )
    elif info.preview_line == "v1.1-preview":
        evidence_backed_observations.append(
            "The preview line carries forward the full `v1.0` slice and adds only a 16-run severity-standardized stress sentinel overlay."
        )
    else:
        evidence_backed_observations.append(
            "The preview line carries forward the `v0.8-preview` content slice and uses the new trust surface to strengthen reproducibility, bundle review, and comparison fairness."
        )
    if preview_vs_previous_preview:
        evidence_backed_observations.extend(preview_vs_previous_preview.get("key_points", [])[:2])

    cautionary_interpretation = [
        "Mixed-mode findings remain review-oriented rather than a pooled benchmark ranking across pointwise and operator rows.",
        "A positive formal-discussion signal does not imply a promotion recommendation by itself.",
    ]
    governance_facing_recommendation = {
        "overall_recommendation": overall_recommendation,
        "formal_discussion_recommendation": formal_discussion_recommendation,
        "analysis_readiness_conclusion": analysis_readiness_conclusion,
        "smallest_remaining_gap": smallest_gap,
    }

    return {
        "preview_line": info.preview_line,
        "dimensions": dimensions,
        "issue_buckets": {
            "engineering_blockers": engineering_blockers,
            "asset_completeness_issues": asset_completeness_issues,
            "reproducibility_issues": reproducibility_issues,
            "comparison_fairness_issues": fairness_issues,
            "interpretation_quality_issues": interpretation_quality_issues,
            "onboarding_sufficiency_issues": onboarding_sufficiency_issues,
            "slice_breadth_issues": slice_breadth_issues,
            "governance_cautions": governance_cautions,
        },
        "evidence_backed_observations": evidence_backed_observations,
        "cautionary_interpretation": cautionary_interpretation,
        "governance_facing_recommendation": governance_facing_recommendation,
        "overall_recommendation": overall_recommendation,
        "formal_discussion_recommendation": formal_discussion_recommendation,
        "smallest_remaining_gap": smallest_gap,
        "reviewable_enough_for_formal_discussion": formal_discussion_recommendation == "ready_for_formal_discussion",
        "interpretation": "reviewable" if formal_discussion_recommendation == "ready_for_formal_discussion" else "interesting",
        "analysis_readiness_conclusion": analysis_readiness_conclusion,
    }



def render_decision_support_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Decision Support",
        "",
        f"- Overall recommendation: `{payload.get('overall_recommendation')}`",
        f"- Formal-discussion recommendation: `{payload.get('formal_discussion_recommendation')}`",
        f"- Smallest remaining gap: `{payload.get('smallest_remaining_gap')}`",
        f"- Interpretation: `{payload.get('interpretation')}`",
        f"- Analysis readiness conclusion: `{payload.get('analysis_readiness_conclusion')}`",
        "",
        "## Evidence-Backed Observations",
        "",
    ]
    for item in payload.get("evidence_backed_observations", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Cautionary Interpretation", ""])
    for item in payload.get("cautionary_interpretation", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Governance-Facing Recommendation", ""])
    recommendation = payload.get("governance_facing_recommendation", {})
    for name, value in recommendation.items():
        lines.append(f"- `{name}`: `{value}`")
    lines.extend(["", "## Dimensions", ""])
    for name, item in payload.get("dimensions", {}).items():
        lines.append(f"- `{name}`: `{item.get('status')}`")
        for evidence in item.get("evidence", []):
            lines.append(f"  - {evidence}")
    lines.extend(["", "## Issue Buckets", ""])
    for name, items in payload.get("issue_buckets", {}).items():
        if not items:
            lines.append(f"- `{name}`: none")
            continue
        lines.append(f"- `{name}`:")
        for item in items:
            lines.append(f"  - {item}")
    lines.append("")
    return "\n".join(lines)
