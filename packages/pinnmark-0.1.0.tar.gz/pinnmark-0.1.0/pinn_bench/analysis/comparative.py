"""Comparative and release-intelligence logic for benchmark analysis."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable
from statistics import fmean
from typing import Any

from pinn_bench.analysis.normalize import AnalysisInputs, ReferenceRoot
from pinn_bench.analysis.preview_line import get_preview_line_info
from pinn_bench.stress import build_stress_summary


def _preview_info(inputs: AnalysisInputs):
    return get_preview_line_info(inputs.preview_line)


def _field_protocols(rows: list[dict[str, Any]]) -> list[str]:
    return sorted(
        {str(row.get("protocol") or "none") for row in rows if _display_mode(row.get("task_mode")) == "field"},
        key=_protocol_sort_key,
    )


def _field_task_names(rows: list[dict[str, Any]]) -> list[str]:
    return sorted({str(row.get("task_name") or "unknown") for row in rows if _display_mode(row.get("task_mode")) == "field"})


def _field_baseline_names(rows: list[dict[str, Any]]) -> list[str]:
    standard_field_rows = [
        row
        for row in rows
        if _display_mode(row.get("task_mode")) == "field" and str(row.get("protocol") or "none") == "none"
    ]
    return sorted({str(row.get("model_name") or "unknown") for row in standard_field_rows})


def _breadth_delta(inputs: AnalysisInputs) -> dict[str, Any]:
    current_rows = inputs.grouped_rows
    current_field_tasks = _field_task_names(current_rows)
    current_field_baselines = _field_baseline_names(current_rows)
    current_field_protocols = _field_protocols(current_rows)
    previous_reference = inputs.previous_preview_reference
    previous_rows = [] if previous_reference is None else previous_reference.grouped_rows
    previous_field_tasks = _field_task_names(previous_rows)
    previous_field_baselines = _field_baseline_names(previous_rows)
    previous_field_protocols = _field_protocols(previous_rows)
    new_operator_tasks = sorted(set(current_field_tasks) - set(previous_field_tasks))
    new_operator_baselines = sorted(set(current_field_baselines) - set(previous_field_baselines))
    new_field_protocols = sorted(set(current_field_protocols) - set(previous_field_protocols), key=_protocol_sort_key)
    return {
        "current_grouped_rows": len(current_rows),
        "previous_preview_grouped_rows": len(previous_rows),
        "grouped_row_delta": len(current_rows) - len(previous_rows),
        "current_field_tasks": current_field_tasks,
        "previous_preview_field_tasks": previous_field_tasks,
        "new_operator_tasks": new_operator_tasks,
        "current_field_baselines": current_field_baselines,
        "previous_preview_field_baselines": previous_field_baselines,
        "new_operator_baselines": new_operator_baselines,
        "current_field_protocols": current_field_protocols,
        "previous_preview_field_protocols": previous_field_protocols,
        "new_field_protocols": new_field_protocols,
        "field_protocol_host_tasks": sorted(
            {
                str(row.get("task_name") or "unknown")
                for row in current_rows
                if _display_mode(row.get("task_mode")) == "field"
                and str(row.get("protocol") or "none") in new_field_protocols
            }
        ),
    }



PROTOCOL_ORDER = {"none": 0, "noise": 1, "sparsity": 2, "extrapolation": 3}
DISPLAY_PROTOCOL = {"none": "standard"}
MODEL_COHORTS = {
    "mlp": "mlp_core",
    "siren": "implicit_representation",
    "kan": "basis_expansion",
    "grid_mlp": "operator_grid",
    "spectral_mlp": "operator_spectral",
    "mini_fno": "operator_fourier",
}


def _coerce_float(value: Any) -> float | None:
    if value in {None, "", "nan", "None"}:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _display_mode(value: Any) -> str:
    text = str(value or "pointwise").strip()
    return text or "pointwise"


def _display_protocol(value: Any) -> str:
    text = str(value or "none").strip().lower()
    return DISPLAY_PROTOCOL.get(text, text)


def _protocol_sort_key(protocol: str) -> tuple[int, str]:
    return (PROTOCOL_ORDER.get(protocol, 99), protocol)


def _cohort_name(model_name: Any) -> str:
    return MODEL_COHORTS.get(str(model_name or "unknown"), "unknown")


def _standard_rows(rows: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    return [row for row in rows if str(row.get("protocol") or "none") == "none"]


def _field_rows(rows: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        row
        for row in rows
        if any(_display_mode(row.get(key)) == "field" for key in ("task_mode", "model_mode", "evaluation_mode"))
    ]


def _pointwise_rows(rows: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    return [row for row in rows if _display_mode(row.get("task_mode")) == "pointwise"]


def _best_row(rows: Iterable[dict[str, Any]]) -> dict[str, Any] | None:
    candidates = [row for row in rows if _coerce_float(row.get("eval_relative_l2_mean")) is not None]
    if not candidates:
        return None
    return min(
        candidates,
        key=lambda row: (
            _coerce_float(row.get("eval_relative_l2_mean")) or float("inf"),
            _coerce_float(row.get("eval_mse_mean")) or float("inf"),
            _coerce_float(row.get("parameter_count")) or float("inf"),
            _coerce_float(row.get("train_duration_seconds_mean")) or float("inf"),
            str(row.get("run_id") or ""),
        ),
    )


def _mean(values: Iterable[float | None]) -> float | None:
    usable = [value for value in values if value is not None]
    if not usable:
        return None
    return fmean(usable)


def _pack_row(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "run_id": str(row.get("run_id") or "unknown"),
        "task_name": str(row.get("task_name") or "unknown"),
        "model_name": str(row.get("model_name") or "unknown"),
        "cohort": _cohort_name(row.get("model_name")),
        "task_mode": _display_mode(row.get("task_mode")),
        "model_mode": _display_mode(row.get("model_mode")),
        "evaluation_mode": _display_mode(row.get("evaluation_mode")),
        "protocol": str(row.get("protocol") or "none"),
        "protocol_label": _display_protocol(row.get("protocol")),
        "mean_relative_l2": _coerce_float(row.get("eval_relative_l2_mean")),
        "mean_mse": _coerce_float(row.get("eval_mse_mean")),
        "parameter_count": _coerce_float(row.get("parameter_count")),
        "train_duration_seconds_mean": _coerce_float(row.get("train_duration_seconds_mean")),
    }


def _task_leaders(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[str(row.get("task_name") or "unknown")].append(row)
    output = []
    for task_name in sorted(grouped):
        winner = _best_row(grouped[task_name])
        if winner is None:
            continue
        packed = _pack_row(winner)
        packed["observation"] = "Best standard row for this task inside the current observed preview slice."
        output.append(packed)
    return output


def _build_degradation_entries(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    standard_lookup: dict[tuple[str, str], dict[str, Any]] = {}
    entries: list[dict[str, Any]] = []
    for row in rows:
        if str(row.get("protocol") or "none") == "none":
            standard_lookup[(str(row.get("task_name") or "unknown"), str(row.get("model_name") or "unknown"))] = row
    for row in rows:
        protocol = str(row.get("protocol") or "none")
        if protocol == "none":
            continue
        task_name = str(row.get("task_name") or "unknown")
        model_name = str(row.get("model_name") or "unknown")
        ratio = _coerce_float(row.get("degradation_ratio_vs_standard"))
        standard_row = standard_lookup.get((task_name, model_name))
        if ratio is None and standard_row is not None:
            metric = _coerce_float(row.get("eval_relative_l2_mean"))
            standard_metric = _coerce_float(standard_row.get("eval_relative_l2_mean"))
            if metric is not None and standard_metric is not None:
                ratio = metric / standard_metric if standard_metric > 0 else metric
        entries.append(
            {
                "run_id": str(row.get("run_id") or "unknown"),
                "task_name": task_name,
                "model_name": model_name,
                "cohort": _cohort_name(model_name),
                "task_mode": _display_mode(row.get("task_mode")),
                "model_mode": _display_mode(row.get("model_mode")),
                "evaluation_mode": _display_mode(row.get("evaluation_mode")),
                "protocol": protocol,
                "protocol_label": _display_protocol(protocol),
                "ratio": ratio,
                "has_clean_reference": standard_row is not None,
            }
        )
    return entries


def _protocol_sensitivity(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, list[float]] = defaultdict(list)
    for entry in entries:
        ratio = entry.get("ratio")
        if ratio is None:
            continue
        grouped[str(entry.get("protocol"))].append(float(ratio))
    output = []
    for protocol, ratios in grouped.items():
        output.append(
            {
                "protocol": protocol,
                "protocol_label": _display_protocol(protocol),
                "mean_degradation_ratio": fmean(ratios),
                "case_count": len(ratios),
                "spread": max(ratios) - min(ratios) if len(ratios) > 1 else 0.0,
            }
        )
    return sorted(
        output,
        key=lambda item: (
            -float(item["mean_degradation_ratio"]),
            _protocol_sort_key(str(item["protocol"])),
        ),
    )


def _stability_profiles(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for entry in entries:
        grouped[(str(entry["task_name"]), str(entry["model_name"]), str(entry["model_mode"]))].append(entry)
    output = []
    for (task_name, model_name, model_mode), task_entries in grouped.items():
        usable = [entry for entry in task_entries if entry.get("ratio") is not None]
        ratios = [float(entry["ratio"]) for entry in usable]
        best_entry = min(usable, key=lambda item: float(item["ratio"]), default=None)
        worst_entry = max(usable, key=lambda item: float(item["ratio"]), default=None)
        output.append(
            {
                "task_name": task_name,
                "model_name": model_name,
                "cohort": _cohort_name(model_name),
                "model_mode": model_mode,
                "protocols": [
                    str(entry["protocol"]) for entry in sorted(task_entries, key=lambda item: _protocol_sort_key(str(item["protocol"])))
                ],
                "case_count": len(task_entries),
                "average_degradation_ratio": _mean(ratios),
                "best_protocol": None if best_entry is None else str(best_entry["protocol"]),
                "best_ratio": None if best_entry is None else float(best_entry["ratio"]),
                "worst_protocol": None if worst_entry is None else str(worst_entry["protocol"]),
                "worst_ratio": None if worst_entry is None else float(worst_entry["ratio"]),
                "observation": "Lower average degradation ratio indicates a more stable family inside the current robustness slice.",
            }
        )
    return sorted(
        output,
        key=lambda item: (
            float(item["average_degradation_ratio"]) if item["average_degradation_ratio"] is not None else float("inf"),
            item["task_name"],
            item["model_name"],
        ),
    )


def _degradation_by_task_model_mode(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str], list[float]] = defaultdict(list)
    for entry in entries:
        ratio = entry.get("ratio")
        if ratio is None:
            continue
        grouped[(str(entry["task_name"]), str(entry["model_mode"]))].append(float(ratio))
    output = []
    for (task_name, model_mode), ratios in sorted(grouped.items()):
        output.append(
            {
                "task_name": task_name,
                "model_mode": model_mode,
                "average_degradation_ratio": fmean(ratios),
                "case_count": len(ratios),
            }
        )
    return output


def _robustness_leaders(robustness_rows: list[dict[str, Any]]) -> dict[str, Any]:
    usable = [row for row in robustness_rows if _coerce_float(row.get("average_degradation_ratio")) is not None]
    if not usable:
        return {
            "leaders": [],
            "best_case": None,
            "worst_case": None,
            "observations": ["Robustness summary is sparse; operator preview conclusions should continue to lean on grouped degradation entries too."],
        }
    leaders = sorted(
        [
            {
                "task_name": str(row.get("task_name") or "unknown"),
                "model_name": str(row.get("model_name") or "unknown"),
                "cohort": _cohort_name(row.get("model_name")),
                "average_degradation_ratio": _coerce_float(row.get("average_degradation_ratio")),
                "protocol_coverage_count": int(row.get("protocol_coverage_count") or 0),
                "missing_protocols": list(row.get("missing_protocols") or []),
            }
            for row in usable
        ],
        key=lambda item: (
            float(item["average_degradation_ratio"]),
            item["task_name"],
            item["model_name"],
        ),
    )
    return {
        "leaders": leaders,
        "best_case": leaders[0],
        "worst_case": leaders[-1],
        "observations": [
            "Robustness-leader ordering is benchmark-internal and should be read alongside protocol coverage counts.",
        ],
    }


def _mode_slice_summary(rows: list[dict[str, Any]]) -> dict[str, Any]:
    standard_rows = _standard_rows(rows)
    pointwise_rows = _pointwise_rows(standard_rows)
    operator_rows = _field_rows(standard_rows)

    def summarize(slice_rows: list[dict[str, Any]], *, label: str) -> dict[str, Any]:
        best = _best_row(slice_rows)
        errors = [_coerce_float(row.get("eval_relative_l2_mean")) for row in slice_rows]
        durations = [_coerce_float(row.get("train_duration_seconds_mean")) for row in slice_rows]
        parameters = [_coerce_float(row.get("parameter_count")) for row in slice_rows]
        return {
            "label": label,
            "task_count": len({str(row.get("task_name")) for row in slice_rows if row.get("task_name")}),
            "family_count": len(slice_rows),
            "mean_standard_relative_l2": _mean(errors),
            "mean_train_duration_seconds": _mean(durations),
            "mean_parameter_count": _mean(parameters),
            "best_run": None if best is None else _pack_row(best),
        }

    pointwise_summary = summarize(pointwise_rows, label="pointwise")
    operator_summary = summarize(operator_rows, label="operator")
    evidence = []
    cautionary = []
    fair = []
    if pointwise_summary["task_count"] and operator_summary["task_count"]:
        evidence.append(
            "Pointwise and operator rows now coexist in the same asset chain, so mode-aware comparisons are part of the intended preview workflow."
        )
        cautionary.append(
            "Do not rank pointwise and operator families as one homogeneous table; compare them within mode or at the level of asset behavior."
        )
        fair.append(
            "Slice-level comparisons are fair when they stay at the level of mode coverage, protocol support, or reporting clarity rather than pooled error ranking."
        )
    if operator_summary["task_count"] < pointwise_summary["task_count"]:
        cautionary.append(
            f"Operator coverage remains intentionally narrower than pointwise coverage ({operator_summary['task_count']} operator tasks vs {pointwise_summary['task_count']} pointwise tasks)."
        )
    if operator_summary["family_count"]:
        evidence.append(
            "Operator rows stay mode-aware and benchmark-internal; review them as bounded preview content rather than a single pooled market-style claim."
        )
    return {
        "pointwise": pointwise_summary,
        "operator": operator_summary,
        "evidence_backed_observations": evidence,
        "cautionary_interpretation": cautionary,
        "fair_comparisons": fair,
    }


def _efficiency_tradeoff(rows: list[dict[str, Any]]) -> dict[str, Any]:
    standard_rows = _standard_rows(rows)
    candidates = [row for row in standard_rows if _coerce_float(row.get("eval_relative_l2_mean")) is not None]
    if not candidates:
        return {
            "lightest_family": None,
            "fastest_family": None,
            "lowest_error_family": None,
            "balanced_tradeoff_family": None,
            "notes": [],
        }

    lightest = min(
        candidates,
        key=lambda row: (
            _coerce_float(row.get("parameter_count")) or float("inf"),
            _coerce_float(row.get("eval_relative_l2_mean")) or float("inf"),
            str(row.get("run_id") or ""),
        ),
    )
    fastest = min(
        candidates,
        key=lambda row: (
            _coerce_float(row.get("train_duration_seconds_mean")) or float("inf"),
            _coerce_float(row.get("eval_relative_l2_mean")) or float("inf"),
            str(row.get("run_id") or ""),
        ),
    )
    lowest_error = min(
        candidates,
        key=lambda row: (
            _coerce_float(row.get("eval_relative_l2_mean")) or float("inf"),
            _coerce_float(row.get("parameter_count")) or float("inf"),
            str(row.get("run_id") or ""),
        ),
    )
    ranked = sorted(
        candidates,
        key=lambda row: (
            (_coerce_float(row.get("eval_relative_l2_mean")) or float("inf")) * 0.6
            + (_coerce_float(row.get("train_duration_seconds_mean")) or float("inf")) * 0.25
            + (_coerce_float(row.get("parameter_count")) or float("inf")) * 0.15 / 10000.0,
            str(row.get("run_id") or ""),
        ),
    )
    balanced = ranked[0]

    notes = [
        f"`{lightest.get('run_id')}` is the lightest standard family by parameter count.",
        f"`{fastest.get('run_id')}` is the fastest standard family by mean train duration.",
        f"`{lowest_error.get('run_id')}` is the lowest-error standard family in the mirrored slice.",
        f"`{balanced.get('run_id')}` is the most balanced standard tradeoff under the lightweight preview heuristic exported by `analysis`.",
        "These efficiency notes are writing aids, not a substitute for task-specific scrutiny.",
    ]
    return {
        "lightest_family": _pack_row(lightest),
        "fastest_family": _pack_row(fastest),
        "lowest_error_family": _pack_row(lowest_error),
        "balanced_tradeoff_family": _pack_row(balanced),
        "notes": notes,
    }


def _cohort_intelligence(standard_rows: list[dict[str, Any]], entries: list[dict[str, Any]]) -> dict[str, Any]:
    degradation_by_model: dict[str, list[float]] = defaultdict(list)
    for entry in entries:
        ratio = entry.get("ratio")
        if ratio is not None:
            degradation_by_model[str(entry.get("model_name") or "unknown")].append(float(ratio))
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in standard_rows:
        grouped[_cohort_name(row.get("model_name"))].append(row)
    profiles = []
    for cohort, rows_for_cohort in sorted(grouped.items()):
        model_names = {str(row.get("model_name") or "unknown") for row in rows_for_cohort}
        degradation_values: list[float] = []
        for model_name in model_names:
            degradation_values.extend(degradation_by_model.get(model_name, []))
        profiles.append(
            {
                "cohort": cohort,
                "family_count": len(rows_for_cohort),
                "task_count": len({str(row.get("task_name")) for row in rows_for_cohort if row.get("task_name")}),
                "mean_standard_relative_l2": _mean(_coerce_float(row.get("eval_relative_l2_mean")) for row in rows_for_cohort),
                "mean_parameter_count": _mean(_coerce_float(row.get("parameter_count")) for row in rows_for_cohort),
                "mean_degradation_ratio": _mean(degradation_values),
                "model_names": sorted(model_names),
            }
        )
    observations = []
    if any(profile["cohort"].startswith("operator_") for profile in profiles):
        observations.append(
            "Operator-specific cohorts are present, but they should still be interpreted within operator tasks rather than as a mature operator-model zoo."
        )
    if len(profiles) >= 2:
        observations.append(
            "Cohort-level comparisons help explain architecture families, but the mirrored slice keeps those comparisons intentionally thin and heuristic."
        )
    return {
        "cohort_map": dict(MODEL_COHORTS),
        "profiles": profiles,
        "observations": observations,
    }


def _protocol_intelligence(entries: list[dict[str, Any]]) -> dict[str, Any]:
    rankings = _protocol_sensitivity(entries)
    highest_fragility = rankings[0] if rankings else None

    separating_candidates = []
    grouped_ratios: dict[str, list[float]] = defaultdict(list)
    for entry in entries:
        ratio = entry.get("ratio")
        if ratio is not None:
            grouped_ratios[str(entry.get("protocol") or "none")].append(float(ratio))
    for protocol, ratios in grouped_ratios.items():
        if not ratios:
            continue
        separating_candidates.append(
            {
                "protocol": protocol,
                "protocol_label": _display_protocol(protocol),
                "spread": max(ratios) - min(ratios) if len(ratios) > 1 else 0.0,
                "case_count": len(ratios),
            }
        )
    separating = max(
        separating_candidates,
        key=lambda item: (float(item["spread"]), int(item["case_count"]), -PROTOCOL_ORDER.get(str(item["protocol"]), 99)),
        default=None,
    )

    stress_test = max(
        rankings,
        key=lambda item: (
            float(item["mean_degradation_ratio"]),
            min(int(item["case_count"]), 3),
            -PROTOCOL_ORDER.get(str(item["protocol"]), 99),
        ),
        default=None,
    )
    observations = []
    if highest_fragility is not None:
        observations.append(
            f"`{highest_fragility['protocol_label']}` currently shows the highest average degradation ratio in the observed slice."
        )
    if separating is not None:
        observations.append(
            f"`{separating['protocol_label']}` currently produces the widest internal spread across families, so it is the strongest architecture-separating protocol in this preview view."
        )
    if stress_test is not None:
        observations.append(
            f"`{stress_test['protocol_label']}` behaves most like a stress-test protocol under the current heuristic because it combines elevated degradation with non-trivial coverage."
        )
    return {
        "rankings": rankings,
        "highest_fragility": highest_fragility,
        "strongest_architecture_separating_protocol": separating,
        "most_stress_test_like_protocol": stress_test,
        "observations": observations,
    }


def _task_hardness(rows: list[dict[str, Any]], entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    standard_rows = _standard_rows(rows)
    degradation_by_task: dict[str, list[float]] = defaultdict(list)
    for entry in entries:
        ratio = entry.get("ratio")
        if ratio is not None:
            degradation_by_task[str(entry["task_name"] or "unknown")].append(float(ratio))

    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in standard_rows:
        grouped[str(row.get("task_name") or "unknown")].append(row)

    output = []
    for task_name, task_rows in grouped.items():
        best = _best_row(task_rows)
        best_error = None if best is None else _coerce_float(best.get("eval_relative_l2_mean"))
        mean_standard_error = _mean(_coerce_float(row.get("eval_relative_l2_mean")) for row in task_rows)
        degradation_values = degradation_by_task.get(task_name, [])
        mean_degradation = _mean(degradation_values)
        score = None
        if best_error is not None:
            score = best_error * (mean_degradation if mean_degradation is not None else 1.0)
        confidence = "medium" if len(task_rows) >= 2 or len(degradation_values) >= 2 else "low"
        output.append(
            {
                "task_name": task_name,
                "score": score,
                "hardness_score": score,
                "best_standard_relative_l2": best_error,
                "mean_standard_relative_l2": mean_standard_error,
                "mean_degradation_ratio": mean_degradation,
                "confidence": confidence,
                "explanation": "Higher task hardness combines stronger baseline error with higher robustness degradation inside the current benchmark slice.",
                "caution_note": "Benchmark-internal only; this is not an absolute PDE difficulty claim.",
            }
        )
    return sorted(
        output,
        key=lambda item: (
            -(float(item["score"]) if item["score"] is not None else float("-inf")),
            item["task_name"],
        ),
    )


def _protocol_hardness(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rankings = _protocol_sensitivity(entries)
    output = []
    for item in rankings:
        case_count = int(item["case_count"])
        output.append(
            {
                "protocol": item["protocol"],
                "protocol_label": item["protocol_label"],
                "score": item["mean_degradation_ratio"],
                "mean_degradation_ratio": item["mean_degradation_ratio"],
                "case_count": case_count,
                "confidence": "medium" if case_count >= 3 else "low",
                "explanation": "Higher protocol hardness reflects larger mean degradation inside the current observed preview slice.",
                "caution_note": "Protocol hardness is benchmark-internal and depends on the currently supported task/mode coverage.",
            }
        )
    return output


def _slice_tension_notes(rows: list[dict[str, Any]], entries: list[dict[str, Any]]) -> list[str]:
    notes = []
    standard_rows = _standard_rows(rows)
    pointwise_task_count = len({str(row.get("task_name")) for row in _pointwise_rows(standard_rows) if row.get("task_name")})
    operator_task_count = len({str(row.get("task_name")) for row in _field_rows(standard_rows) if row.get("task_name")})
    protocols = sorted({str(entry.get("protocol") or "none") for entry in entries}, key=_protocol_sort_key)
    if operator_task_count and pointwise_task_count:
        notes.append("Mixed pointwise/operator exports are normal in the active preview line, but whole-benchmark claims should stay mode-aware.")
    if operator_task_count < pointwise_task_count:
        notes.append(
            f"The operator slice remains thinner than the pointwise slice ({operator_task_count} vs {pointwise_task_count} tasks), so breadth claims should stay conservative."
        )
    if "extrapolation" in protocols:
        notes.append("Protocol coverage can remain asymmetric across modes even after preview-scale field extrapolation growth, so scope statements should stay explicit.")
    notes.append("Hardness is exported as a review aid, not as a freeze-level truth claim.")
    return notes


def _regime_surface(inputs: AnalysisInputs) -> dict[str, Any]:
    reporting_dir = inputs.outputs_root / "_leaderboard" / "reporting"
    artifact_presence = {
        "regime_map": any(reporting_dir.glob("*_regime_map.json")),
        "ood_slice_leaderboard": any(reporting_dir.glob("*_ood_slice_leaderboard.csv")),
        "failure_atlas": any(reporting_dir.glob("*_failure_atlas.json")),
        "physics_consistency_dashboard": any(reporting_dir.glob("*_physics_consistency_dashboard.json")),
    }
    regime_summary = (
        dict(inputs.regime_map_payload.get("summary", {}))
        if isinstance(inputs.regime_map_payload, dict)
        else {}
    )
    return {
        "pack_identity": dict(inputs.pack_identity),
        "artifacts_present": all(artifact_presence.values()),
        "artifact_presence": artifact_presence,
        "regime_group_count": int(regime_summary.get("regime_group_count", 0) or 0),
        "headline_regime_group_count": int(regime_summary.get("headline_regime_group_count", 0) or 0),
        "blocked_regime_group_count": int(regime_summary.get("blocked_regime_group_count", 0) or 0),
        "ood_protocol_families_present": list(regime_summary.get("ood_protocol_families_present", [])),
        "coverage_only_regime_group_count": int(regime_summary.get("coverage_only_regime_group_count", 0) or 0),
        "geometry_group_count": int(regime_summary.get("geometry_group_count", 0) or 0),
        "geometry_id_group_count": int(regime_summary.get("geometry_id_group_count", 0) or 0),
        "geometry_ood_group_count": int(regime_summary.get("geometry_ood_group_count", 0) or 0),
        "geometry_classes_present": list(regime_summary.get("geometry_classes_present", [])),
    }


def build_comparative_report(inputs: AnalysisInputs) -> dict[str, Any]:
    info = _preview_info(inputs)
    rows = inputs.grouped_rows
    standard_rows = _standard_rows(rows)
    degradation_entries = _build_degradation_entries(rows)
    stability_profiles = _stability_profiles(degradation_entries)
    protocol_intelligence = _protocol_intelligence(degradation_entries)
    robustness_intelligence = _robustness_leaders(inputs.robustness_rows)
    efficiency_tradeoff = _efficiency_tradeoff(rows)
    breadth_delta = _breadth_delta(inputs)
    stress_surface = build_stress_summary(rows)
    regime_surface = _regime_surface(inputs)

    evidence_backed_observations = [
        "Comparative findings are benchmark-internal observations over the active preview slice.",
        "The review surface should separate evidence-backed content changes from governance interpretation, not collapse them into a single headline claim.",
    ]
    if inputs.pack_identity.get("pack_kind") == "starter":
        evidence_backed_observations.append(
            "This outputs root is a checked-in starter pack that references `v1.8-preview`; it reuses the carried-forward review vocabulary without declaring a new preview line."
        )
    if info.preview_line == "v1.8-preview":
        evidence_backed_observations.append(
            "`v1.8-preview` keeps the carried-forward `v1.7-preview` fair-budget system surface and adds only additive regime-aware reporting: grouped regime metadata, regime map / OOD slice / failure-atlas / physics-consistency assets, and preview-governed regime closeout policy."
        )
    elif info.preview_line == "v1.7-preview":
        evidence_backed_observations.append(
            "`v1.7-preview` keeps the carried-forward `v1.6-preview` system surface and adds an additive fair-budget overlay: comparison metadata, matched-budget grouping, imported classical references, and headline-eligibility policy."
        )
    elif info.preview_line == "v1.6-preview":
        evidence_backed_observations.append(
            "`v1.6-preview` keeps the full `v1.5-preview` slice and adds only additive external-adoption and publication-packaging surfaces on top of the carried-forward stress, leaderboard-protocol, DX, operator-ready, and consolidation layers."
        )
    elif info.preview_line == "v1.5-preview":
        evidence_backed_observations.append(
            "`v1.5-preview` keeps the full `v1.4-preview` slice and adds only additive cross-line consolidation summaries, synthesis docs, and repo-truth unification language on top of the carried-forward stress, leaderboard-protocol, DX, and operator-ready surfaces."
        )
    elif info.preview_line == "v1.4-preview":
        evidence_backed_observations.append(
            "`v1.4-preview` keeps the full `v1.3-preview` slice and adds only additive operator-capability plus observation/target abstraction metadata on top of the carried-forward DX and leaderboard-protocol surfaces."
        )
    elif info.preview_line == "v1.1-preview":
        evidence_backed_observations.append(
            "`v1.1-preview` keeps the full `v1.0` slice and adds only a severity-standardized stress sentinel overlay for robustness and temporal holdout review."
        )
    elif info.preview_line == "v0.9-preview":
        evidence_backed_observations.append(
            "`v0.9-preview` keeps benchmark content fixed and asks whether the carried-forward `v0.8-preview` slice is now more reproducible, reviewable, and trustworthy."
        )
    elif info.preview_line == "v0.8-preview":
        evidence_backed_observations.append(
            "`v0.8-preview` is the content-breadth line, so comparative reading should foreground what widened relative to `v0.7-preview` before jumping to governance conclusions."
        )
    else:
        evidence_backed_observations.append(
            "`v0.7-preview` keeps benchmark content fixed and asks whether the same slice is now more reviewable and decision-useful."
        )

    comparative = {
        "summary": {
            "grouped_row_count": len(rows),
            "reporting_row_count": len(inputs.reporting_rows),
            "pareto_row_count": len(inputs.pareto_rows),
            "robustness_row_count": len(inputs.robustness_rows),
            "standard_family_count": len(standard_rows),
            "preview_line": info.preview_line,
        },
        "review_framing": {
            "evidence_backed_observations": evidence_backed_observations,
            "cautionary_interpretation": [
                "Comparative leaders should stay within task, protocol, or mode-aware groupings rather than being read as a single global ranking.",
                "Efficiency and hardness outputs are heuristics that support review discussion rather than release-level proof claims.",
            ],
        },
        "breadth_delta": breadth_delta,
        "task_level": {
            "leaders": _task_leaders(standard_rows),
            "stability_leaders": stability_profiles,
            "efficiency_leaders": {
                "lightest_family": efficiency_tradeoff.get("lightest_family"),
                "fastest_family": efficiency_tradeoff.get("fastest_family"),
                "lowest_error_family": efficiency_tradeoff.get("lowest_error_family"),
                "balanced_tradeoff_family": efficiency_tradeoff.get("balanced_tradeoff_family"),
            },
            "robustness_leaders": robustness_intelligence.get("leaders", []),
        },
        "protocol_intelligence": protocol_intelligence,
        "protocol_sensitivity": {
            "rankings": protocol_intelligence["rankings"],
            "widest_gap_protocol": protocol_intelligence["highest_fragility"],
        },
        "mode_comparison": _mode_slice_summary(rows),
        "efficiency_tradeoff": efficiency_tradeoff,
        "cross_model_family": _cohort_intelligence(standard_rows, degradation_entries),
        "degradation_intelligence": {
            "by_task_model": stability_profiles,
            "by_task_model_mode": _degradation_by_task_model_mode(degradation_entries),
            "protocol_fragility": protocol_intelligence["rankings"],
            "best_stability_case": stability_profiles[0] if stability_profiles else None,
            "worst_stability_case": max(
                (item for item in stability_profiles if item.get("average_degradation_ratio") is not None),
                key=lambda item: float(item["average_degradation_ratio"]),
                default=None,
            ),
            "best_robustness_case": robustness_intelligence.get("best_case"),
            "worst_robustness_case": robustness_intelligence.get("worst_case"),
        },
        "stress_surface": stress_surface,
        "regime_surface": regime_surface,
        "hardness": {
            "task_ranking": _task_hardness(rows, degradation_entries),
            "protocol_ranking": _protocol_hardness(degradation_entries),
            "slice_tension_notes": _slice_tension_notes(rows, degradation_entries),
        },
    }
    return comparative





def build_operator_abstraction_surface(inputs: AnalysisInputs) -> dict[str, Any]:
    rows = inputs.grouped_rows
    capability_counts: dict[str, int] = defaultdict(int)
    observation_counts: dict[str, int] = defaultdict(int)
    target_counts: dict[str, int] = defaultdict(int)
    compatibility_counts: dict[str, int] = defaultdict(int)
    operator_ready_models: set[str] = set()
    operator_ready_standard_models: set[str] = set()
    pairings: set[str] = set()
    rows_with_metadata = 0
    for row in rows:
        capability_class = str(row.get("model_capability_class") or "").strip()
        observation_type = str(row.get("observation_type") or "").strip()
        target_type = str(row.get("target_type") or "").strip()
        compatibility_class = str(row.get("capability_compatibility_class") or "").strip()
        if capability_class and observation_type and target_type and compatibility_class:
            rows_with_metadata += 1
        if capability_class:
            capability_counts[capability_class] += 1
        if observation_type:
            observation_counts[observation_type] += 1
        if target_type:
            target_counts[target_type] += 1
        if compatibility_class:
            compatibility_counts[compatibility_class] += 1
        if observation_type and target_type:
            pairings.add(f"{observation_type}->{target_type}")
        if bool(row.get("operator_ready_flag")):
            model_name = str(row.get("model_name") or "unknown")
            operator_ready_models.add(model_name)
            if str(row.get("protocol") or "none") == "none":
                operator_ready_standard_models.add(model_name)
    return {
        "capability_surface_summary": {
            "grouped_rows_with_capability_metadata": rows_with_metadata,
            "capability_class_counts": dict(sorted(capability_counts.items())),
            "compatibility_class_counts": dict(sorted(compatibility_counts.items())),
            "future_reserved_classes_present": sorted(
                capability
                for capability in capability_counts
                if capability in {"trajectory_solution_model", "operator_response_model", "hybrid_physics_model"}
            ),
        },
        "observation_target_surface_summary": {
            "grouped_rows_with_observation_metadata": rows_with_metadata,
            "observation_type_counts": dict(sorted(observation_counts.items())),
            "target_type_counts": dict(sorted(target_counts.items())),
            "pairings_present": sorted(pairings),
        },
        "operator_ready_summary": {
            "operator_ready_grouped_rows": sum(1 for row in rows if bool(row.get("operator_ready_flag"))),
            "operator_ready_model_families": sorted(operator_ready_models),
            "operator_ready_standard_model_families": sorted(operator_ready_standard_models),
            "reserved_operator_response_present": bool(capability_counts.get("operator_response_model")),
            "reserved_trajectory_present": bool(capability_counts.get("trajectory_solution_model")),
            "notes": [
                "Current field baselines are operator-ready in interface shape only and remain classified as fieldwise_solution_model.",
                "No current grouped row is promoted to operator_response_model in v1.4-preview.",
            ],
        },
    }


def build_hardness_report(comparative_report: dict[str, Any]) -> dict[str, Any]:
    task_ranking = list(comparative_report.get("hardness", {}).get("task_ranking", []))
    protocol_ranking = list(comparative_report.get("hardness", {}).get("protocol_ranking", []))
    return {
        "summary": {
            "top_task": None if not task_ranking else task_ranking[0],
            "top_protocol": None if not protocol_ranking else protocol_ranking[0],
            "note": "Hardness is comparative and review-oriented for the active preview line, not a claim of absolute scientific difficulty.",
        },
        "task_ranking": task_ranking,
        "protocol_ranking": protocol_ranking,
        "slice_tension_notes": list(comparative_report.get("hardness", {}).get("slice_tension_notes", [])),
    }


def render_comparative_report_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Comparative Report",
        "",
        "## Review Framing",
        "",
    ]
    framing = payload.get("review_framing", {})
    for item in framing.get("evidence_backed_observations", []):
        lines.append(f"- Evidence-backed observation: {item}")
    for item in framing.get("cautionary_interpretation", []):
        lines.append(f"- Cautionary interpretation: {item}")

    lines.extend([
        "",
        "## Task-Level Evidence",
        "",
    ])
    leaders = payload.get("task_level", {}).get("leaders", [])
    if not leaders:
        lines.append("- No task-level leaders were available.")
    else:
        for leader in leaders:
            lines.append(
                "- `{task_name}`: `{run_id}` ({model_name}, cohort=`{cohort}`, mode=`{evaluation_mode}`) is the best standard row with mean Relative L2 `{mean_relative_l2:.6g}`.".format(
                    **leader
                )
            )

    lines.extend(["", "## Protocol-Level Evidence", ""])
    protocol_intelligence = payload.get("protocol_intelligence", {})
    rankings = protocol_intelligence.get("rankings", [])
    if not rankings:
        lines.append("- No protocol intelligence was available.")
    else:
        for item in rankings:
            lines.append(
                "- `{protocol_label}`: mean degradation ratio `{mean_degradation_ratio:.3f}` across `{case_count}` cases.".format(
                    **item
                )
            )
    for note in protocol_intelligence.get("observations", []):
        lines.append(f"- Observation: {note}")

    lines.extend(["", "## Mode-Level Evidence", ""])
    mode_comparison = payload.get("mode_comparison", {})
    for key in ["pointwise", "operator"]:
        item = mode_comparison.get(key)
        if not isinstance(item, dict):
            continue
        best_run = None if item.get("best_run") is None else item["best_run"].get("run_id")
        lines.append(
            "- `{label}` slice: tasks=`{task_count}` families=`{family_count}` mean standard Relative L2=`{mean_standard_relative_l2}` mean train duration=`{mean_train_duration_seconds}` best run=`{best_run}`.".format(
                label=item.get("label"),
                task_count=item.get("task_count"),
                family_count=item.get("family_count"),
                mean_standard_relative_l2=item.get("mean_standard_relative_l2"),
                mean_train_duration_seconds=item.get("mean_train_duration_seconds"),
                best_run=best_run,
            )
        )
    for note in mode_comparison.get("evidence_backed_observations", []):
        lines.append(f"- Observation: {note}")
    for note in mode_comparison.get("cautionary_interpretation", []):
        lines.append(f"- Caution: {note}")
    for note in mode_comparison.get("fair_comparisons", []):
        lines.append(f"- Fair comparison: {note}")

    lines.extend(["", "## Efficiency Tradeoff", ""])
    for note in payload.get("efficiency_tradeoff", {}).get("notes", []):
        lines.append(f"- {note}")
    efficiency_leaders = payload.get("task_level", {}).get("efficiency_leaders", {})
    for key in ["lightest_family", "fastest_family", "lowest_error_family", "balanced_tradeoff_family"]:
        item = efficiency_leaders.get(key)
        if isinstance(item, dict):
            lines.append(
                "- `{label}` anchor: `{run_id}` ({model_name}, task=`{task_name}`, mode=`{evaluation_mode}`).".format(
                    label=key,
                    run_id=item.get("run_id"),
                    model_name=item.get("model_name"),
                    task_name=item.get("task_name"),
                    evaluation_mode=item.get("evaluation_mode"),
                )
            )

    lines.extend(["", "## Cohort View", ""])
    cohort_payload = payload.get("cross_model_family", {})
    for profile in cohort_payload.get("profiles", []):
        lines.append(
            "- `{cohort}`: tasks=`{task_count}` families=`{family_count}` mean standard Relative L2=`{mean_standard_relative_l2}` mean degradation=`{mean_degradation_ratio}`.".format(
                **profile
            )
        )
    for note in cohort_payload.get("observations", []):
        lines.append(f"- Observation: {note}")

    lines.extend(["", "## Stress Surface", ""])
    stress_surface = payload.get("stress_surface", {})
    lines.append(f"- Stress rows: `{stress_surface.get('stress_row_count')}`")
    lines.append(f"- Official stress rows: `{stress_surface.get('official_stress_row_count')}`")
    lines.append(f"- Worst stress case: `{stress_surface.get('worst_stress_case')}`")
    for note in stress_surface.get("nominal_vs_stress_contrast", []):
        lines.append(f"- Contrast: {note}")
    for note in stress_surface.get("stress_caveats", []):
        lines.append(f"- Caveat: {note}")

    lines.extend(["", "## Regime Surface", ""])
    regime_surface = payload.get("regime_surface", {})
    for key, value in regime_surface.items():
        lines.append(f"- `{key}`: `{value}`")

    lines.extend(["", "## Hardness Review", ""])
    task_ranking = payload.get("hardness", {}).get("task_ranking", [])
    if task_ranking:
        lines.append("### Tasks")
        for item in task_ranking:
            lines.append(
                "- `{task_name}`: score=`{score}` confidence=`{confidence}`. {explanation} Caution: {caution_note}".format(
                    **item
                )
            )
    protocol_ranking = payload.get("hardness", {}).get("protocol_ranking", [])
    if protocol_ranking:
        lines.extend(["", "### Protocols"])
        for item in protocol_ranking:
            lines.append(
                "- `{protocol_label}`: score=`{score}` confidence=`{confidence}` across `{case_count}` cases. {explanation} Caution: {caution_note}".format(
                    **item
                )
            )
    for note in payload.get("hardness", {}).get("slice_tension_notes", []):
        lines.append(f"- Tension note: {note}")
    lines.append("")
    return "\n".join(lines)


def render_hardness_report_markdown(payload: dict[str, Any]) -> str:
    lines = ["# Hardness Report", ""]
    summary = payload.get("summary", {})
    top_task = summary.get("top_task")
    top_protocol = summary.get("top_protocol")
    if isinstance(top_task, dict):
        lines.append(f"- Top task by current hardness heuristic: `{top_task.get('task_name')}` (score=`{top_task.get('score')}`, confidence=`{top_task.get('confidence')}`).")
    if isinstance(top_protocol, dict):
        lines.append(f"- Top protocol by current hardness heuristic: `{top_protocol.get('protocol_label')}` (score=`{top_protocol.get('score')}`, confidence=`{top_protocol.get('confidence')}`).")
    if summary.get("note"):
        lines.append(f"- {summary['note']}")
    lines.extend(["", "## Task Ranking", ""])
    for item in payload.get("task_ranking", []):
        lines.append(
            "- `{task_name}`: score=`{score}` confidence=`{confidence}`. {explanation} Caution: {caution_note}".format(
                **item
            )
        )
    lines.extend(["", "## Protocol Ranking", ""])
    for item in payload.get("protocol_ranking", []):
        lines.append(
            "- `{protocol_label}`: score=`{score}` confidence=`{confidence}` across `{case_count}` cases. {explanation} Caution: {caution_note}".format(
                **item
            )
        )
    lines.extend(["", "## Slice Tension Notes", ""])
    for note in payload.get("slice_tension_notes", []):
        lines.append(f"- {note}")
    lines.append("")
    return "\n".join(lines)


def _root_scope(reference: ReferenceRoot | None) -> dict[str, Any] | None:
    if reference is None:
        return None
    rows = reference.grouped_rows
    standard_rows = _standard_rows(rows)
    field_rows = _field_rows(standard_rows)
    return {
        "outputs_root": str(reference.outputs_root),
        "grouped_rows": len(rows),
        "task_names": sorted({str(row.get("task_name")) for row in standard_rows if row.get("task_name")}),
        "protocols": sorted({str(row.get("protocol") or "none") for row in rows}, key=_protocol_sort_key),
        "mode_coverage": sorted({_display_mode(row.get("task_mode")) for row in rows}),
        "operator_task_count": len({str(row.get("task_name")) for row in field_rows if row.get("task_name")}),
        "operator_baseline_count": len({str(row.get("model_name")) for row in field_rows if row.get("model_name")}),
        "asset_surface": {
            "reporting_rows": len(reference.reporting_rows),
            "pareto_rows": len(reference.pareto_rows),
            "robustness_rows": len(reference.robustness_rows),
            "analysis_bundle_present": (reference.outputs_root / "_analysis" / "analysis_bundle.json").exists(),
        },
    }


def build_cross_version_review(inputs: AnalysisInputs) -> dict[str, Any]:
    info = _preview_info(inputs)
    preview_scope = _root_scope(
        ReferenceRoot(
            label="preview",
            outputs_root=inputs.outputs_root,
            grouped_payload=inputs.grouped_payload,
            grouped_rows=inputs.grouped_rows,
            snapshot_payload=inputs.snapshot_payload,
            reporting_rows=inputs.reporting_rows,
            pareto_rows=inputs.pareto_rows,
            robustness_rows=inputs.robustness_rows,
            regime_map_payload=inputs.regime_map_payload,
            ood_slice_rows=inputs.ood_slice_rows,
            failure_atlas_payload=inputs.failure_atlas_payload,
            physics_consistency_payload=inputs.physics_consistency_payload,
        )
    )
    previous_preview = _root_scope(inputs.previous_preview_reference)
    current_formal = _root_scope(inputs.formal_reference)
    previous_formal = _root_scope(inputs.previous_formal_reference)
    breadth_delta = _breadth_delta(inputs)

    mirrored_slice = bool(
        preview_scope
        and current_formal
        and preview_scope["task_names"] == current_formal["task_names"]
        and preview_scope["protocols"] == current_formal["protocols"]
        and preview_scope["grouped_rows"] == current_formal["grouped_rows"]
    )

    preview_section: dict[str, Any]
    if info.preview_line == "v1.8-preview":
        preview_points = [
            f"`v1.8-preview` raises grouped rows to `{breadth_delta['current_grouped_rows']}` while keeping the carried-forward `v1.7-preview` fair-budget system surface and adding regime-aware/OOD coverage.",
            "The meaningful preview delta is regime-aware interpretation: grouped regime metadata, regime-map reporting, OOD-slice reporting, failure-atlas surfaces, and pointwise-first physics consistency summaries that make OOD claims more review-resilient.",
            "Packaging, stress, leaderboard-protocol, DX, operator-ready, and fair-budget layers remain preserved surfaces; the line changes regime-aware reporting and governance discipline rather than trainer or evaluator semantics.",
        ]
        preview_section = {
            "comparison": "v1.8-preview vs v1.0",
            "mirrors_benchmark_slice": False,
            "meaningful_delta": "regime_map_structured_ood_overlay",
            "freeze_history_context": "`v1.0` remains the frozen formal baseline; `v1.8-preview` carries forward the larger preview-owned `v1.7-preview` fair-budget system surface and adds only additive regime-aware and structured-OOD reporting overlays.",
            "unchanged_scope": [
                "The current formal baseline remains `v1.0`.",
                "Trainer, evaluator, and main result schema contracts remain unchanged.",
                "The carried-forward stress, leaderboard-protocol, DX, operator-ready, packaging, and fair-budget layers stay intact beneath the regime-aware overlay.",
            ],
            "platform_layer_changes": [
                "Adds grouped regime metadata transport, regime registry derivation, and regime-aware reporting artifacts for grouped leaderboard payloads.",
                "Extends doctor and audit with regime-aware closeout rules while preserving earlier fair-budget, packaging, and protocol surfaces.",
            ],
            "content_layer_changes": [
                "Adds locked pointwise and minimal-operator OOD host coverage for parameter, resolution, boundary-family, and initial-family shift evidence.",
            ],
            "excluded_scope": [
                "Automatic formalization or machine-routed preview opening.",
                "Complex geometry closeout, inverse-trust closeout, or runtime-native classical solver integration.",
            ],
            "benchmark_scope": {"preview": preview_scope, "current_formal": current_formal},
            "key_points": preview_points,
        }
    elif info.preview_line == "v1.7-preview":
        preview_points = [
            f"`v1.7-preview` raises grouped rows to `{breadth_delta['current_grouped_rows']}` while keeping the carried-forward `v1.6-preview` system surface and adding fair-budget comparison coverage.",
            "The meaningful preview delta is comparison-faithfulness: budget metadata, headline-eligibility rules, imported classical references, and matched-budget reporting surfaces that make claims more review-resilient.",
            "Packaging, stress, leaderboard-protocol, DX, and operator-ready layers remain preserved surfaces; the line changes comparison contract and reporting discipline rather than trainer or evaluator semantics.",
        ]
        preview_section = {
            "comparison": "v1.7-preview vs v1.0",
            "mirrors_benchmark_slice": False,
            "meaningful_delta": "fair_budget_strong_baseline_overlay",
            "freeze_history_context": "`v1.0` remains the frozen formal baseline; `v1.7-preview` carries forward the larger preview-owned `v1.6-preview` system surface and adds only additive fair-budget and strong-baseline reporting overlays.",
            "unchanged_scope": [
                "The current formal baseline remains `v1.0`.",
                "Trainer, evaluator, and main result schema contracts remain unchanged.",
                "The carried-forward stress, leaderboard-protocol, DX, operator-ready, and packaging layers stay intact beneath the fair-budget overlay.",
            ],
            "platform_layer_changes": [
                "Adds strict comparison metadata, matched-budget grouping, and imported classical-reference coverage for headline pointwise tasks.",
                "Adds additive matched-budget, fairness-coverage, and accuracy-cost reporting surfaces plus doctor/audit redlines without changing established verdict enums.",
            ],
            "content_layer_changes": [
                "Expands headline pointwise comparison coverage so `heat1d`, `burgers1d`, `poisson2d`, and `allencahn1d` can be discussed under matched-budget rules.",
            ],
            "excluded_scope": [
                "Trainer or evaluator rewrites during this sprint.",
                "Formal baseline promotion, remote services, or automatic follow-on preview opening.",
            ],
            "benchmark_scope": {"preview": preview_scope, "current_formal": current_formal},
            "key_points": preview_points,
        }
    elif info.preview_line == "v1.6-preview":
        preview_points = [
            f"`v1.6-preview` keeps grouped rows fixed at `{breadth_delta['current_grouped_rows']}` while carrying forward the full `v1.5-preview` slice.",
            "The meaningful preview delta is external packaging: positioning, lifecycle, publication-story, reviewer-summary, and adoption-guide surfaces that package the existing benchmark system for outside readers.",
            "Stress, leaderboard-protocol, DX, operator-ready, and consolidation layers remain preserved surfaces; the line changes external readability rather than benchmark content.",
        ]
        preview_section = {
            "comparison": "v1.6-preview vs v1.0",
            "mirrors_benchmark_slice": False,
            "meaningful_delta": "external_adoption_publication_packaging_overlay",
            "freeze_history_context": "`v1.0` remains the frozen formal baseline; `v1.6-preview` carries forward the larger preview-owned `v1.5-preview` slice and adds only additive external-adoption and publication-packaging surfaces.",
            "unchanged_scope": [
                "The current formal baseline remains `v1.0`.",
                "Trainer, evaluator, and main result schema contracts remain unchanged.",
                "The carried-forward stress, leaderboard-protocol, DX, operator-ready, and consolidation layers stay intact beneath the packaging overlay.",
            ],
            "platform_layer_changes": [
                "Adds external-facing positioning, lifecycle, architecture, reviewer, appendix, and adoption docs so the completed system is easier to read outside the repo.",
                "Adds additive `external_adoption_summary`, `publication_packaging_summary`, and `benchmark_positioning_summary` fields to analysis and review outputs without changing existing verdict enums.",
            ],
            "content_layer_changes": [],
            "excluded_scope": [
                "Trainer or evaluator rewrites during this sprint.",
                "New benchmark protocol families, remote services, or automatic formalization.",
            ],
            "benchmark_scope": {"preview": preview_scope, "current_formal": current_formal},
            "key_points": preview_points,
        }
    elif info.preview_line == "v1.5-preview":
        preview_points = [
            f"`v1.5-preview` keeps grouped rows fixed at `{breadth_delta['current_grouped_rows']}` while carrying forward the full `v1.4-preview` slice.",
            "The meaningful preview delta is cross-line consolidation: unified repo-truth language, docs-only synthesis surfaces, and additive consolidation summaries in analysis and review outputs.",
            "Stress, leaderboard-protocol, DX, and operator-ready layers remain preserved surfaces; the line changes packaging and interpretive coherence rather than benchmark content.",
        ]
        preview_section = {
            "comparison": "v1.5-preview vs v1.0",
            "mirrors_benchmark_slice": False,
            "meaningful_delta": "cross_line_consolidation_overlay",
            "freeze_history_context": "`v1.0` remains the frozen formal baseline; `v1.5-preview` carries forward the larger preview-owned `v1.4-preview` slice and adds only additive consolidation and repo-truth unification surfaces.",
            "unchanged_scope": [
                "The current formal baseline remains `v1.0`.",
                "Trainer, evaluator, and main result schema contracts remain unchanged.",
                "The carried-forward stress, leaderboard-protocol, DX, and operator-ready layers stay intact beneath the consolidation overlay.",
            ],
            "platform_layer_changes": [
                "Adds docs-only registry, synthesis, glossary, and governance-model surfaces so completed preview lines read as one coherent system.",
                "Adds additive `stress_surface_summary` and `cross_line_consolidation_summary` fields to analysis and review outputs without changing existing verdict enums.",
            ],
            "content_layer_changes": [],
            "excluded_scope": [
                "Trainer or evaluator rewrites during this sprint.",
                "Major benchmark-content expansion, external service rollout, or automatic formalization.",
            ],
            "benchmark_scope": {"preview": preview_scope, "current_formal": current_formal},
            "asset_surface": {
                "preview_analysis_bundle_present": bool(preview_scope and preview_scope["asset_surface"]["analysis_bundle_present"]),
                "current_formal_analysis_bundle_present": bool(current_formal and current_formal["asset_surface"]["analysis_bundle_present"]),
            },
            "key_points": preview_points,
        }
    elif info.preview_line == "v1.4-preview":
        preview_points = [
            f"`v1.4-preview` keeps grouped rows fixed at `{breadth_delta['current_grouped_rows']}` while carrying forward the full `v1.3-preview` slice.",
            "The meaningful preview delta is additive abstraction metadata: capability taxonomy, observation/target taxonomy, conservative compatibility classes, and operator-ready review framing.",
            "Current field baselines become operator-ready in interface description only; no current row is reclassified as an explicit operator-response benchmark result.",
        ]
        preview_section = {
            "comparison": "v1.4-preview vs v1.0",
            "mirrors_benchmark_slice": False,
            "meaningful_delta": "operator_capability_abstraction_overlay",
            "freeze_history_context": "`v1.0` remains the frozen formal baseline; `v1.4-preview` carries forward the larger preview-owned `v1.3-preview` slice and adds only additive abstraction metadata plus operator-ready narrative.",
            "unchanged_scope": [
                "The current formal baseline remains `v1.0`.",
                "Trainer, evaluator, and main result schema contracts remain unchanged.",
                "The carried-forward `v1.3-preview` leaderboard-protocol and DX layers stay intact beneath the abstraction overlay.",
            ],
            "platform_layer_changes": [
                "Adds conservative capability, observation, target, compatibility, and operator-ready metadata to normalized grouped rows and analysis bundles.",
                "Keeps analysis, review, doctor, and audit as additive consumers of the new abstraction surface rather than introducing a second operator-only pipeline.",
            ],
            "content_layer_changes": [],
            "excluded_scope": [
                "Trainer or evaluator rewrites during this sprint.",
                "Full operator-model zoo rollout or remote evaluation service work.",
                "Automatic formalization or automatic next-preview opening.",
            ],
            "benchmark_scope": {"preview": preview_scope, "current_formal": current_formal},
            "asset_surface": {
                "preview_analysis_bundle_present": bool(preview_scope and preview_scope["asset_surface"]["analysis_bundle_present"]),
                "current_formal_analysis_bundle_present": bool(current_formal and current_formal["asset_surface"]["analysis_bundle_present"]),
            },
            "key_points": preview_points,
        }
    elif info.preview_line == "v1.1-preview":
        preview_points = [
            f"`v1.1-preview` grows grouped rows from `{breadth_delta['previous_preview_grouped_rows']}` to `{breadth_delta['current_grouped_rows']}` by adding only the 16-run stress sentinel overlay.",
            "The meaningful preview delta is severity standardization, stress comparability policy, and stress-aware review/governance rather than benchmark-slice expansion.",
            "Temporal stress remains an in-domain holdout proxy, not a true out-of-domain time extension.",
        ]
        preview_section = {
            "comparison": "v1.1-preview vs v1.0",
            "mirrors_benchmark_slice": False,
            "meaningful_delta": "stress_standardization_overlay",
            "freeze_history_context": "`v1.0` is the frozen formal baseline; `v1.1-preview` carries that slice forward and adds only a bounded stress/OOD sentinel overlay.",
            "unchanged_scope": [
                "The current formal baseline remains `v1.0`.",
                "Trainer, evaluator, and main result schema contracts remain unchanged.",
                "The carried-forward `v1.0` slice stays intact beneath the overlay.",
            ],
            "platform_layer_changes": [
                "Adds derived stress metadata, severity mapping, stress-aware review fields, and bounded stress comparability policy.",
                "Keeps audit and doctor on the same read-only-by-default verification surface while extending preview analysis for stress governance.",
            ],
            "content_layer_changes": [
                "Adds a 16-run sentinel overlay across noise, sparsity, and temporal holdout severity hosts.",
            ],
            "excluded_scope": [
                "New PDE families, new model families, or trainer/evaluator rewrites in this sprint.",
                "True out-of-domain time extension beyond the task domain.",
                "Automatic formalization or automatic next-preview opening.",
            ],
            "benchmark_scope": {"preview": preview_scope, "current_formal": current_formal},
            "asset_surface": {
                "preview_analysis_bundle_present": bool(preview_scope and preview_scope["asset_surface"]["analysis_bundle_present"]),
                "current_formal_analysis_bundle_present": bool(current_formal and current_formal["asset_surface"]["analysis_bundle_present"]),
            },
            "key_points": preview_points,
        }
    elif info.preview_line == "v0.9-preview":
        preview_points = [
            f"`v0.9-preview` keeps grouped rows fixed at `{breadth_delta['current_grouped_rows']}` while carrying forward the full `v0.8-preview` slice.",
            "The meaningful preview delta is reproducibility, observation consistency, comparison fairness, and submission-review maturity rather than new benchmark content.",
            "Trust-surface changes should be read before any governance conclusion about freeze readiness.",
        ]
        preview_section = {
            "comparison": "v0.9-preview vs v0.6",
            "mirrors_benchmark_slice": False,
            "meaningful_delta": "trust_surface_hardening",
            "freeze_history_context": "`v0.6` is the frozen formal content baseline; `v0.7-preview` deepened analysis/governance; `v0.8-preview` widened content; `v0.9-preview` keeps that widened slice fixed while strengthening trust and submission maturity.",
            "unchanged_scope": [
                "The current formal baseline remains `v0.6`.",
                "Benchmark content stays equal to the carried-forward `v0.8-preview` 32-row slice.",
                "Trainer, evaluator, and main result schema contracts remain unchanged.",
            ],
            "platform_layer_changes": [
                "Adds reproducibility facts, observation consistency, comparison fairness, and formal-discussion-grade review artifacts under `_analysis`.",
                "Strengthens submission validation, bundle comparison, and self-contained import review without changing public schema strings.",
            ],
            "content_layer_changes": [],
            "excluded_scope": [
                "New benchmark-content expansion during this sprint.",
                "Automatic freeze/promotion decisions during this sprint.",
                "Web dashboards, remote services, or distributed execution systems.",
            ],
            "benchmark_scope": {"preview": preview_scope, "current_formal": current_formal},
            "asset_surface": {
                "preview_analysis_bundle_present": bool(preview_scope and preview_scope["asset_surface"]["analysis_bundle_present"]),
                "current_formal_analysis_bundle_present": bool(current_formal and current_formal["asset_surface"]["analysis_bundle_present"]),
            },
            "key_points": preview_points,
        }
    elif info.preview_line == "v0.8-preview":
        preview_points = [
            f"`v0.8-preview` widens grouped rows from `{breadth_delta['previous_preview_grouped_rows']}` to `{breadth_delta['current_grouped_rows']}` relative to `v0.7-preview`.",
            f"New operator-task breadth vs `v0.7-preview`: {', '.join(breadth_delta['new_operator_tasks']) if breadth_delta['new_operator_tasks'] else 'none' }.",
            f"New operator-baseline breadth vs `v0.7-preview`: {', '.join(breadth_delta['new_operator_baselines']) if breadth_delta['new_operator_baselines'] else 'none' }.",
        ]
        if breadth_delta["new_field_protocols"]:
            preview_points.append(
                f"New field-protocol breadth is local to {', '.join(breadth_delta['field_protocol_host_tasks'])} through {', '.join(breadth_delta['new_field_protocols'])}."
            )
        preview_section = {
            "comparison": "v0.8-preview vs v0.6",
            "mirrors_benchmark_slice": False,
            "meaningful_delta": "content_breadth_expansion",
            "freeze_history_context": "`v0.6` is the frozen formal content baseline; `v0.7-preview` deepened the review surface; `v0.8-preview` widens task, baseline, and protocol breadth without changing the frozen contract.",
            "unchanged_scope": [
                "The current formal baseline remains `v0.6`.",
                "Trainer, evaluator, and main result schema contracts remain unchanged.",
            ],
            "platform_layer_changes": [
                "Inherits the deeper `_analysis` / review-packet surface first stabilized in `v0.7-preview`.",
                "Keeps `pinn-bench analysis` as the single analysis/review entrypoint and `summary --analysis-dir` as the only summary extension point.",
            ],
            "content_layer_changes": [
                "Adds `wave1d_field` as the first new runnable operator-ready task in this preview line.",
                "Adds `mini_fno` as a third preview-scale operator baseline on `heat1d_field` and `poisson2d_field`.",
                "Adds local `heat1d_field` extrapolation so field protocol breadth grows beyond none/noise/sparsity.",
            ],
            "excluded_scope": [
                "Automatic freeze/promotion decisions during this sprint.",
                "A mature operator zoo or broad extrapolation coverage across all field tasks.",
                "Web dashboards, remote services, or distributed execution systems.",
            ],
            "benchmark_scope": {"preview": preview_scope, "current_formal": current_formal},
            "asset_surface": {
                "preview_analysis_bundle_present": bool(preview_scope and preview_scope["asset_surface"]["analysis_bundle_present"]),
                "current_formal_analysis_bundle_present": bool(current_formal and current_formal["asset_surface"]["analysis_bundle_present"]),
            },
            "key_points": preview_points,
        }
    else:
        preview_points = [
            "`v0.7-preview` mirrors the current formal `v0.6` benchmark slice rather than expanding benchmark content.",
            "The meaningful preview delta is the analysis, diagnostics, observation, and review surface under `_analysis/`.",
        ]
        if preview_scope and current_formal:
            preview_points.append(
                f"Mode coverage stays aligned with `v0.6` ({', '.join(preview_scope['mode_coverage'])}); operator presence remains `{preview_scope['operator_task_count']} tasks x {preview_scope['operator_baseline_count']} baselines`."
            )
        preview_section = {
            "comparison": "v0.7-preview vs v0.6",
            "mirrors_benchmark_slice": mirrored_slice,
            "meaningful_delta": "analysis_surface_deepening",
            "freeze_history_context": "`v0.6` is the frozen formal benchmark content baseline; `v0.7-preview` exists to deepen analysis, diagnostics, observation history, and review materials without widening scope.",
            "unchanged_scope": [
                "Benchmark content remains the exact frozen `v0.6` 18-family slice.",
                "No new tasks, baselines, protocols, trainer changes, evaluator changes, or main-schema changes are introduced.",
            ],
            "platform_layer_changes": [
                "Adds deeper comparative, diagnostic, readiness, observation, and review-packet assets under `_analysis/`.",
                "Keeps `pinn-bench analysis` as the single analysis entrypoint while widening the view set it exports.",
                "Adds observation history so the preview line can be reviewed over time rather than as a one-shot export.",
            ],
            "content_layer_changes": ["None by design; benchmark content is intentionally unchanged."],
            "excluded_scope": [
                "Benchmark-content expansion.",
                "Web dashboards, remote services, distributed execution, or heavy profiling.",
                "Automatic promotion claims based on performance deltas alone.",
            ],
            "benchmark_scope": {"preview": preview_scope, "current_formal": current_formal},
            "asset_surface": {
                "preview_analysis_bundle_present": bool(preview_scope and preview_scope["asset_surface"]["analysis_bundle_present"]),
                "current_formal_analysis_bundle_present": bool(current_formal and current_formal["asset_surface"]["analysis_bundle_present"]),
            },
            "key_points": preview_points,
        }

    formal_points: list[str] = []
    formal_platform_changes: list[str] = []
    formal_content_changes: list[str] = []
    if current_formal and previous_formal:
        new_tasks = sorted(set(current_formal["task_names"]) - set(previous_formal["task_names"]))
        new_modes = sorted(set(current_formal["mode_coverage"]) - set(previous_formal["mode_coverage"]))
        formal_points.append(
            f"`v0.6` adds operator-ready coverage over `v0.5` with grouped rows `{previous_formal['grouped_rows']}` -> `{current_formal['grouped_rows']}`."
        )
        formal_points.append(
            f"Operator presence changes from `{previous_formal['operator_task_count']} tasks x {previous_formal['operator_baseline_count']} baselines` to `{current_formal['operator_task_count']} tasks x {current_formal['operator_baseline_count']} baselines`."
        )
        formal_points.append(
            f"Mode coverage delta vs `v0.5`: {', '.join(new_modes) if new_modes else 'none'}."
        )
        formal_content_changes = [
            f"New task coverage vs `v0.5`: {', '.join(new_tasks) if new_tasks else 'none' }.",
            "Operator benchmark content is widened in `v0.6`, establishing the frozen contract inherited by later preview lines.",
        ]
        formal_platform_changes = [
            "Introduces the operator-ready task contract and field evaluator path into the formal platform definition.",
            "Adds mixed-mode reporting fields so pointwise and operator rows can share grouped assets without hiding their mode semantics.",
        ]

    payload: dict[str, Any] = {
        "preview_vs_current_formal": preview_section,
        "current_formal_vs_previous_formal": {
            "comparison": "v0.6 vs v0.5",
            "meaningful_delta": "operator_ready_platform_layer",
            "freeze_history_context": "`v0.5` formalized the submission/community-ready platform line, while `v0.6` formalized the first operator-ready widening of benchmark content.",
            "unchanged_scope": [
                "`v0.6` keeps the core pointwise benchmark line while adding operator-ready breadth.",
            ],
            "platform_layer_changes": formal_platform_changes,
            "content_layer_changes": formal_content_changes,
            "excluded_scope": [
                "Helmholtz promotion or a third operator baseline.",
                "Field extrapolation as a formal requirement.",
            ],
            "benchmark_scope": {"current_formal": current_formal, "previous_formal": previous_formal},
            "key_points": formal_points,
        },
    }
    if info.preview_line == "v1.8-preview":
        payload["preview_vs_previous_preview"] = {
            "comparison": "v1.8-preview vs v1.7-preview",
            "meaningful_delta": "regime_map_structured_ood_overlay",
            "freeze_history_context": "`v1.7-preview` closed the fair-budget and strong-baseline comparison layer; `v1.8-preview` keeps that system surface and closes a regime-aware and structured-OOD reporting layer on top of it.",
            "unchanged_scope": [
                "The active line remains preview-only and inherits the same frozen `v1.0` formal contract.",
                "No trainer, evaluator, or main results schema rewrite is introduced.",
            ],
            "platform_layer_changes": [
                "Adds grouped regime metadata, regime-board derivation, regime-aware reporting assets, and preview-governed regime closeout logic.",
                "Extends doctor and audit with regime-aware redlines while preserving earlier fair-budget, stress, leaderboard-protocol, DX, operator-ready, and packaging sections.",
            ],
            "content_layer_changes": [
                "Adds locked structured-OOD host coverage for pointwise and minimal operator tasks without treating coverage-only operator rows as headline regime claims.",
            ],
            "excluded_scope": [
                "Automatic formalization or machine-routed preview opening.",
                "Complex-geometry closeout, inverse-trust closeout, or paper-closeout claims.",
            ],
            "benchmark_scope": {"preview": preview_scope, "previous_preview": previous_preview},
            "key_points": [
                f"Grouped rows rise to `{breadth_delta['current_grouped_rows']}` because `v1.8-preview` adds regime-aware grouped coverage on top of the carried-forward `v1.7-preview` slice.",
                "The main change is regime-aware interpretation: the line distinguishes headline-eligible OOD groups, blocked groups, and coverage-only cells instead of flattening them into one average leaderboard.",
                "The line remains preview-governed and does not request formal promotion, complex-geometry closeout, or inverse-trust closeout.",
            ],
        }
    elif info.preview_line == "v1.7-preview":
        payload["preview_vs_previous_preview"] = {
            "comparison": "v1.7-preview vs v1.6-preview",
            "meaningful_delta": "fair_budget_strong_baseline_overlay",
            "freeze_history_context": "`v1.6-preview` packaged the completed benchmark system for external adoption; `v1.7-preview` keeps that system surface and closes a fair-budget, strong-baseline comparison layer on top of it.",
            "unchanged_scope": [
                "The active line remains preview-only and inherits the same frozen `v1.0` formal contract.",
                "No trainer, evaluator, or main results schema rewrite is introduced.",
            ],
            "platform_layer_changes": [
                "Adds comparison metadata transport, matched-budget grouping, and headline-eligibility logic to grouped, reporting, and imported-reference surfaces.",
                "Extends doctor and audit with fair-budget closeout rules while preserving earlier stress, leaderboard-protocol, DX, operator-ready, and packaging sections.",
            ],
            "content_layer_changes": [
                "Adds headline pointwise strong-baseline coverage and imported classical references without turning operator coverage groups into headline claims.",
            ],
            "excluded_scope": [
                "Automatic formalization or machine-routed preview opening.",
                "Runtime-native classical solver integration or broader OOD-family rollout.",
            ],
            "benchmark_scope": {"preview": preview_scope, "previous_preview": previous_preview},
            "key_points": [
                f"Grouped rows rise to `{breadth_delta['current_grouped_rows']}` because `v1.7-preview` adds headline fair-budget coverage on top of the carried-forward `v1.6-preview` slice.",
                "The main change is comparison discipline: the line distinguishes headline-eligible matched-budget groups from coverage-only surfaces rather than treating all rows as equally claimable.",
                "The line remains preview-governed and does not request formal promotion or a new formal baseline.",
            ],
        }
    elif info.preview_line == "v1.6-preview":
        payload["preview_vs_previous_preview"] = {
            "comparison": "v1.6-preview vs v1.5-preview",
            "meaningful_delta": "external_adoption_publication_packaging_overlay",
            "freeze_history_context": "`v1.5-preview` unified the completed stress, leaderboard, DX, and operator-ready layers into one internal system narrative; `v1.6-preview` keeps that exact slice and packages it for external adoption and publication-facing use.",
            "unchanged_scope": [
                "The active line remains preview-only and inherits the same frozen `v1.0` formal contract.",
                "No new benchmark rows, PDE families, or model families are introduced.",
            ],
            "platform_layer_changes": [
                "Adds external positioning, lifecycle, reviewer-summary, appendix, and adoption-guide surfaces that translate the existing benchmark system for outside readers.",
                "Extends analysis, review, doctor, and audit with additive external-adoption and publication-packaging summaries while preserving earlier stress, leaderboard, DX, operator-ready, and consolidation sections.",
            ],
            "content_layer_changes": [],
            "excluded_scope": [
                "Broad task or PDE expansion in this sprint.",
                "Automatic formalization or machine-routed preview opening.",
            ],
            "benchmark_scope": {"preview": preview_scope, "previous_preview": previous_preview},
            "key_points": [
                f"Grouped rows stay fixed at `{breadth_delta['current_grouped_rows']}` because `v1.6-preview` is an exact carry-forward of the `v1.5-preview` benchmark slice.",
                "The main change is external readability: the existing stress, leaderboard, DX, operator-ready, and consolidation layers are now packaged for first-time readers, collaborators, and reviewers.",
                "The line remains preview-governed and does not claim formal promotion or a new protocol family.",
            ],
        }
    elif info.preview_line == "v1.5-preview":
        payload["preview_vs_previous_preview"] = {
            "comparison": "v1.5-preview vs v1.4-preview",
            "meaningful_delta": "cross_line_consolidation_overlay",
            "freeze_history_context": "`v1.4-preview` proved out the operator-ready abstraction surface; `v1.5-preview` keeps that exact preview slice and consolidates the already-completed stress, leaderboard, DX, and operator-ready layers into one unified repo-truth narrative.",
            "unchanged_scope": [
                "The active line remains preview-only and inherits the same frozen `v1.0` formal contract.",
                "No new benchmark rows, PDE families, or model families are introduced.",
            ],
            "platform_layer_changes": [
                "Adds docs-only registry, system-overview, synthesis, glossary, and governance-model pages for cross-line orientation.",
                "Extends analysis, review, doctor, and audit with additive consolidation summaries while preserving earlier stress, leaderboard, DX, and operator-ready sections.",
            ],
            "content_layer_changes": [],
            "excluded_scope": [
                "Broad task or PDE expansion in this sprint.",
                "Automatic formalization or automatic follow-up preview opening.",
            ],
            "benchmark_scope": {"preview": preview_scope, "previous_preview": previous_preview},
            "key_points": [
                f"Grouped rows stay fixed at `{breadth_delta['current_grouped_rows']}` because `v1.5-preview` is an exact carry-forward of the `v1.4-preview` benchmark slice.",
                "The main change is interpretive coherence: previously introduced stress, leaderboard, DX, and operator-ready surfaces are now summarized under one shared repo-truth vocabulary.",
                "The line remains preview-governed and does not claim formal promotion or external benchmark completion.",
            ],
        }
    elif info.preview_line == "v1.4-preview":
        payload["preview_vs_previous_preview"] = {
            "comparison": "v1.4-preview vs v1.3-preview",
            "meaningful_delta": "operator_capability_abstraction_overlay",
            "freeze_history_context": "`v1.3-preview` proved out the newcomer DX surface on top of the living-leaderboard protocol layer; `v1.4-preview` keeps that exact preview slice and adds a conservative operator-ready abstraction vocabulary.",
            "unchanged_scope": [
                "The active line remains preview-only and inherits the same frozen `v1.0` formal contract.",
                "No new benchmark rows, PDE families, or model families are introduced.",
            ],
            "platform_layer_changes": [
                "Adds capability taxonomy, observation/target taxonomy, and additive compatibility metadata for current rows.",
                "Extends the analysis surface so review packets can describe pointwise and conditioned-field paths under one conservative abstraction.",
            ],
            "content_layer_changes": [],
            "excluded_scope": [
                "Full explicit operator-model benchmark rollout in this sprint.",
                "Automatic formalization or automatic follow-up preview opening.",
            ],
            "benchmark_scope": {"preview": preview_scope, "previous_preview": previous_preview},
            "key_points": [
                f"Grouped rows stay fixed at `{breadth_delta['current_grouped_rows']}` because `v1.4-preview` is an exact carry-forward of the `v1.3-preview` benchmark slice.",
                f"Operator-ready field families remain `{', '.join(sorted(breadth_delta['current_field_baselines']))}` while explicit operator-response classes stay reserved for future lines.",
                "The main change is descriptive power: the benchmark can now distinguish pointwise and conditioned-field surfaces without rewriting the underlying result schema.",
            ],
        }
    elif info.preview_line == "v1.1-preview":
        payload["preview_vs_previous_preview"] = {
            "comparison": "v1.1-preview vs v0.9-preview",
            "meaningful_delta": "stress_standardization_overlay",
            "freeze_history_context": "`v0.9-preview` hardened the trust surface for the pre-`v1.0` line; `v1.1-preview` reopens preview governance on top of frozen `v1.0` through bounded severity standardization.",
            "unchanged_scope": [
                "The active line still remains preview-only and keeps the `v1.0` formal root untouched.",
                "No new top-level CLI commands or benchmark-schema rewrites are introduced.",
            ],
            "platform_layer_changes": [
                "Adds canonical stress-family and severity metadata plus bounded comparability policy.",
                "Extends review assets so nominal-vs-stress and worst-case degradation surfaces are explicit in the packet.",
            ],
            "content_layer_changes": [
                "Adds exactly the 16-run sentinel severity overlay on top of the carried-forward base rows.",
            ],
            "excluded_scope": [
                "Full severity expansion across every legacy stress host.",
                "Automatic promotion or a new active preview line in the same patch.",
            ],
            "benchmark_scope": {"preview": preview_scope, "previous_preview": previous_preview},
            "key_points": [
                f"Grouped rows grow by `{breadth_delta['grouped_row_delta']}` because `v1.1-preview` adds only the bounded stress sentinel overlay.",
                "Legacy `0p05`, `0p1`, and `t0p5` rows remain in place and are mapped additively to canonical severity IDs.",
                "Cross-family and cross-severity stress comparisons remain appendix-only by policy.",
            ],
        }
    elif info.preview_line == "v0.9-preview":
        payload["preview_vs_previous_preview"] = {
            "comparison": "v0.9-preview vs v0.8-preview",
            "meaningful_delta": "trust_surface_hardening",
            "freeze_history_context": "`v0.8-preview` proved out the widened content slice; `v0.9-preview` uses that exact carried-forward slice to strengthen trust, reproducibility, submission maturity, and external review readiness.",
            "unchanged_scope": [
                "The active line still remains preview-only and inherits the same frozen `v0.6` formal contract.",
                "No new top-level CLI commands or benchmark-schema rewrites are introduced.",
                "Grouped-row counts stay fixed while trust surfaces deepen.",
            ],
            "platform_layer_changes": [
                "Adds reproducibility facts, observation consistency, comparison fairness, and formal-discussion support assets.",
                "Strengthens validate/compare/import review outputs without changing public schema strings or top-level commands.",
            ],
            "content_layer_changes": [],
            "excluded_scope": [
                "Additional task, baseline, or protocol expansion during this sprint.",
                "Automatic freeze/promotion decisions during this sprint.",
            ],
            "benchmark_scope": {"preview": preview_scope, "previous_preview": previous_preview},
            "key_points": [
                f"Grouped rows stay fixed at `{breadth_delta['current_grouped_rows']}` because `v0.9-preview` is an exact carry-forward of the `v0.8-preview` benchmark slice.",
                f"Operator-task breadth remains `{len(breadth_delta['current_field_tasks'])}` tasks because this line hardens trust and reviewability rather than expanding content breadth.",
                f"Operator-baseline breadth remains `{len(breadth_delta['current_field_baselines'])}` baselines while governance-facing review maturity increases.",
            ],
        }
    elif info.preview_line == "v0.8-preview":
        payload["preview_vs_previous_preview"] = {
            "comparison": "v0.8-preview vs v0.7-preview",
            "meaningful_delta": "content_breadth_expansion",
            "freeze_history_context": "`v0.7-preview` proved out the analysis/governance surface; `v0.8-preview` uses that surface to review a wider benchmark slice.",
            "unchanged_scope": [
                "The active line still remains preview-only and inherits the same frozen `v0.6` formal contract.",
                "No new top-level CLI commands or benchmark-schema rewrites are introduced.",
            ],
            "platform_layer_changes": [
                "Reuses the review packet, executive summary, promotion gap, and cross-version review surfaces added in `v0.7-preview`.",
            ],
            "content_layer_changes": [
                f"Grouped rows grow by `{breadth_delta['grouped_row_delta']}` while keeping the inherited `v0.7-preview` rows intact.",
                f"New operator task(s): {', '.join(breadth_delta['new_operator_tasks']) if breadth_delta['new_operator_tasks'] else 'none' }.",
                f"New operator baseline(s): {', '.join(breadth_delta['new_operator_baselines']) if breadth_delta['new_operator_baselines'] else 'none' }.",
                f"New field protocol(s): {', '.join(breadth_delta['new_field_protocols']) if breadth_delta['new_field_protocols'] else 'none' }.",
            ],
            "excluded_scope": [
                "Running `mini_fno` on `wave1d_field` in the month must-have slice.",
                "Broad field extrapolation coverage beyond `heat1d_field`.",
            ],
            "benchmark_scope": {"preview": preview_scope, "previous_preview": previous_preview},
            "key_points": [
                f"Operator-task breadth grows from `{len(breadth_delta['previous_preview_field_tasks'])}` to `{len(breadth_delta['current_field_tasks'])}` tasks.",
                f"Operator-baseline breadth grows from `{len(breadth_delta['previous_preview_field_baselines'])}` to `{len(breadth_delta['current_field_baselines'])}` baselines.",
                f"Field protocol breadth grows from `{', '.join(breadth_delta['previous_preview_field_protocols']) or 'none'}` to `{', '.join(breadth_delta['current_field_protocols'])}`.",
            ],
        }
    return payload


def render_cross_version_review_markdown(payload: dict[str, Any]) -> str:
    lines = ["# Cross-Version Review", ""]
    sections = [
        "preview_vs_previous_preview",
        "preview_vs_current_formal",
        "current_formal_vs_previous_formal",
    ]
    for section_name in sections:
        section = payload.get(section_name, {})
        if not section:
            continue
        lines.extend([f"## {section.get('comparison')}", ""])
        lines.append(f"- Meaningful delta: `{section.get('meaningful_delta')}`")
        if section.get("freeze_history_context"):
            lines.append(f"- Freeze-history context: {section.get('freeze_history_context')}")
        for item in section.get("key_points", []):
            lines.append(f"- Evidence-backed observation: {item}")
        for item in section.get("platform_layer_changes", []):
            lines.append(f"- Platform-layer change: {item}")
        for item in section.get("content_layer_changes", []):
            lines.append(f"- Content-layer change: {item}")
        for item in section.get("unchanged_scope", []):
            lines.append(f"- Unchanged scope: {item}")
        for item in section.get("excluded_scope", []):
            lines.append(f"- Excluded scope: {item}")
        lines.append("")
    return "\n".join(lines)


def build_release_review(
    inputs: AnalysisInputs,
    *,
    decision_support: dict[str, Any],
    cross_version_review: dict[str, Any],
    diagnostics: dict[str, Any],
) -> dict[str, Any]:
    info = _preview_info(inputs)
    smallest_gap = decision_support.get("smallest_remaining_gap")
    diagnostics_counts = diagnostics.get("summary", {})
    formal_discussion = decision_support.get("formal_discussion_recommendation")
    reviewability = "reviewable" if formal_discussion == "ready_for_formal_discussion" else "interesting"
    if info.preview_line == "v1.1-preview":
        evidence_backed_observations = [
            "`v1.1-preview` carries forward the frozen `v1.0` slice and adds only a bounded 16-run stress sentinel overlay.",
            "The release-review question is whether the new severity-standardized stress surface is clear enough to support governance-grade robustness interpretation without implying a new formal baseline.",
        ]
        changed_vs_v0_6 = [
            "Adds stress-family/severity metadata, stress-aware review packet sections, and bounded stress comparability rules on top of the existing robustness execution layer.",
            "Introduces no trainer/evaluator/main-schema rewrites and no new PDE or model-family expansion.",
            "Packages the line as a stress/OOD trust overlay rather than a hidden benchmark-breadth expansion.",
        ]
        unchanged_vs_v0_6 = [
            "The current formal baseline remains `v1.0` and its frozen root stays untouched.",
            "The carried-forward `v1.0` benchmark slice remains readable under the overlay.",
            "No automatic formalization or auto-opened next preview line is introduced.",
        ]
        explanation = "The line becomes reviewable when the stress sentinel overlay is severity-standardized, host-relative, and governance-readable without blurring the frozen `v1.0` baseline."
    elif info.preview_line == "v0.9-preview":
        evidence_backed_observations = [
            "`v0.9-preview` keeps the full `v0.8-preview` content slice while strengthening reproducibility, trust, and external review maturity.",
            "The formal-discussion question is whether the trust surface is now strong enough to justify governance review without implying automatic promotion or freeze.",
        ]
        changed_vs_v0_6 = [
            "Adds provenance, observation consistency, comparison fairness, and formal-discussion support assets on top of the frozen `v0.6` contract and the widened `v0.8-preview` slice.",
            "Strengthens submission validation, comparison, and import review outputs without changing schema strings or top-level CLI entrypoints.",
            "Packages the handoff as governance-grade review material rather than a release claim or freeze request.",
        ]
        unchanged_vs_v0_6 = [
            "The current formal baseline remains `v0.6` and the operator-ready contract stays frozen.",
            "Benchmark content remains equal to the carried-forward `v0.8-preview` 32-row slice.",
            "No trainer/evaluator/main-schema rewrites are introduced.",
        ]
        explanation = "The line becomes reviewable when trust and reproducibility materially improve without destabilizing the carried-forward benchmark slice."
    elif info.preview_line == "v0.8-preview":
        evidence_backed_observations = [
            "`v0.8-preview` widens benchmark content while inheriting the analysis/governance surface first developed in `v0.7-preview`.",
            "The release-review question is whether the content-breadth delta is now strong enough to justify formal discussion without implying automatic promotion.",
        ]
        changed_vs_v0_6 = [
            "Adds `wave1d_field`, `mini_fno`, and local `heat1d_field` extrapolation on top of the frozen `v0.6` contract.",
            "Reuses the deeper analysis/review packet surface so breadth changes can be discussed with meeting-ready evidence.",
        ]
        unchanged_vs_v0_6 = [
            "The current formal baseline remains `v0.6` and the operator-ready contract stays frozen.",
            "No trainer/evaluator/main-schema rewrites are introduced.",
        ]
        explanation = "The line becomes reviewable when content breadth is visibly wider than `v0.7-preview` and the inherited governance surface can explain that change cleanly."
    else:
        evidence_backed_observations = [
            "`v0.7-preview` keeps benchmark content fixed and deepens only the analysis/review surface.",
            "The review question is whether the platform can now explain benchmark results more clearly, not whether benchmark breadth has changed.",
        ]
        changed_vs_v0_6 = [
            "Adds deeper comparative, diagnostics, observation, readiness, and review-packet assets under `_analysis/`.",
            "Extends `summary` so benchmark narratives can consume analysis-backed findings through `--analysis-dir`.",
        ]
        unchanged_vs_v0_6 = [
            "Benchmark content remains the exact frozen `18`-family `v0.6` slice.",
            "No new tasks, baselines, protocols, trainer changes, evaluator changes, or main-schema changes are introduced.",
        ]
        explanation = "The line becomes reviewable when the new analysis surface is clear enough to support version discussion without changing benchmark content."
    return {
        "theme": info.theme,
        "benchmark_slice_policy": info.benchmark_slice_policy,
        "evidence_backed_observations": evidence_backed_observations,
        "cautionary_interpretation": [
            "The preview line should not read like a freeze, release, or promotion claim even when the review surface becomes more meeting-ready.",
            "Any formal discussion should still distinguish governance caution from engineering incompleteness.",
        ],
        "governance_facing_recommendation": {
            "overall_recommendation": decision_support.get("overall_recommendation"),
            "formal_discussion_recommendation": formal_discussion,
            "smallest_remaining_gap": smallest_gap,
            "analysis_readiness_conclusion": decision_support.get("analysis_readiness_conclusion"),
        },
        "changed_vs_v0_6": changed_vs_v0_6,
        "unchanged_vs_v0_6": unchanged_vs_v0_6,
        "excluded_scope": [
            "Automatic promotion decisions during this sprint.",
            "Web dashboards, remote services, distributed execution, or heavy profiling.",
            "Narrating preview-scale breadth as a mature operator zoo or final protocol freeze.",
        ],
        "reviewability": {
            "status": reviewability,
            "smallest_remaining_gap": smallest_gap,
            "diagnostics_summary": diagnostics_counts,
            "cross_version_anchor": cross_version_review.get("preview_vs_current_formal", {}).get("key_points", []),
            "explanation": explanation,
            "governance_note": "Reviewability here means discussion-ready preview evidence, not a promotion claim.",
        },
    }


def render_release_review_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Release Review",
        "",
        f"- Theme: {payload.get('theme')}",
        f"- Benchmark slice policy: `{payload.get('benchmark_slice_policy')}`",
        f"- Reviewability: `{payload.get('reviewability', {}).get('status')}`",
        f"- Smallest remaining gap: `{payload.get('reviewability', {}).get('smallest_remaining_gap')}`",
        "",
        "## Evidence-Backed Observations",
        "",
    ]
    for item in payload.get("evidence_backed_observations", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Cautionary Interpretation", ""])
    for item in payload.get("cautionary_interpretation", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Governance-Facing Recommendation", ""])
    recommendation = payload.get("governance_facing_recommendation", {})
    lines.append(f"- Overall recommendation: `{recommendation.get('overall_recommendation')}`")
    lines.append(f"- Formal-discussion recommendation: `{recommendation.get('formal_discussion_recommendation')}`")
    lines.append(f"- Analysis readiness conclusion: `{recommendation.get('analysis_readiness_conclusion')}`")
    lines.extend(["", "## Changed vs v0.6", ""])
    for item in payload.get("changed_vs_v0_6", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Unchanged vs v0.6", ""])
    for item in payload.get("unchanged_vs_v0_6", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Excluded Scope", ""])
    for item in payload.get("excluded_scope", []):
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)


def build_table_hints(inputs: AnalysisInputs, *, diagnostics: dict[str, Any], comparative_report: dict[str, Any]) -> dict[str, Any]:
    best_by_task = {item["task_name"]: item for item in comparative_report.get("task_level", {}).get("leaders", [])}
    main_candidates = []
    for task_name in sorted(best_by_task):
        leader = best_by_task[task_name]
        main_candidates.append(
            {
                "subject": leader["run_id"],
                "source": "grouped_row",
                "task_name": task_name,
                "protocol": leader["protocol_label"],
                "mode": leader["evaluation_mode"],
                "hint_strength": "primary",
                "reason": "Representative standard row for this task; suitable as a writing anchor rather than an auto-generated table mandate.",
            }
        )
    appendix_candidates = []
    for row in inputs.grouped_rows:
        protocol = str(row.get("protocol") or "none")
        if protocol != "none":
            appendix_candidates.append(
                {
                    "subject": str(row.get("run_id") or "unknown"),
                    "source": "grouped_row",
                    "task_name": str(row.get("task_name") or "unknown"),
                    "protocol": _display_protocol(protocol),
                    "mode": _display_mode(row.get("evaluation_mode")),
                    "hint_strength": "appendix",
                    "reason": "Protocol stress row; useful for appendix-style completeness rather than headline narrative.",
                }
            )
    for row in inputs.robustness_rows:
        appendix_candidates.append(
            {
                "subject": f"{row.get('task_name')}/{row.get('model_name')}",
                "source": "robustness_summary",
                "task_name": str(row.get("task_name") or "unknown"),
                "protocol": "robustness-summary",
                "mode": "mixed",
                "hint_strength": "appendix",
                "reason": "Robustness-only comparative view; best used to support appendix discussion or reviewer questions.",
            }
        )
    return {
        "main_table_candidates": main_candidates,
        "appendix_candidates": appendix_candidates,
        "appendix_guidance": [
            "Prefer appendix placement for stress protocols, robustness-only summaries, and rows that mainly support completeness or reviewer questions.",
            "Keep standard representative rows in the main narrative when they define the preview theme without relying on mixed-mode overreach.",
        ],
        "notes": [
            "Hints are heuristic and non-binding.",
            "Main-table hints behave as a writing aid, not as an automatic table generator.",
            "Appendix hints absorb protocol stress cases, robustness summaries, and completeness-oriented material.",
        ],
        "diagnostics_reference": [finding.get("code") for finding in diagnostics.get("findings", []) if isinstance(finding, dict)],
    }


def render_table_hints_markdown(payload: dict[str, Any]) -> str:
    lines = ["# Table Hints", "", "## Main-Table Candidates", ""]
    for item in payload.get("main_table_candidates", []):
        lines.append(
            f"- `{item['subject']}` ({item['task_name']}, {item['mode']}, {item['protocol']}): {item['reason']}"
        )
    lines.extend(["", "## Appendix Candidates", ""])
    for item in payload.get("appendix_candidates", []):
        lines.append(
            f"- `{item['subject']}` ({item['task_name']}, {item['source']}): {item['reason']}"
        )
    lines.extend(["", "## Notes", ""])
    for note in payload.get("notes", []):
        lines.append(f"- {note}")
    lines.extend(["", "## Appendix Guidance", ""])
    for note in payload.get("appendix_guidance", []):
        lines.append(f"- {note}")
    lines.append("")
    return "\n".join(lines)
