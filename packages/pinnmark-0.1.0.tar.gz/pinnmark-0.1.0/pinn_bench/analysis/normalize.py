"""Normalization helpers for analysis assets."""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from pinn_bench.analysis.preview_line import infer_previous_preview_root, infer_preview_line
from pinn_bench.capabilities import classify_capability_compatibility, lookup_model_capability
from pinn_bench.observation_types import lookup_task_observation_target
from pinn_bench.resources import resolve_repo_root
from pinn_bench.stress import apply_stress_metadata


BASE_ANALYSIS_JSON_MD_BASENAMES = [
    "comparative_report",
    "diagnostics",
    "decision_support",
    "release_review",
    "table_hints",
    "cross_version_review",
    "hardness_report",
    "observation_snapshot",
    "preview_evolution_record",
    "review_packet",
    "release_packet_draft",
    "readiness_matrix",
    "promotion_gap_report",
]
BASE_ANALYSIS_MD_ONLY_BASENAMES = ["diagnostics_compact", "executive_summary"]
V09_ANALYSIS_JSON_MD_BASENAMES = ["observation_consistency", "comparison_fairness"]
V09_ANALYSIS_MD_ONLY_BASENAMES = ["formal_discussion_memo", "discussion_questions", "formal_discussion_brief"]
V11_ANALYSIS_JSON_MD_BASENAMES = ["observation_consistency", "comparison_fairness"]
OPTIONAL_ANALYSIS_MD_ONLY_BASENAMES = ["formal_discussion_checklist"]


@dataclass(frozen=True)
class ReferenceRoot:
    label: str
    outputs_root: Path
    grouped_payload: dict[str, Any]
    grouped_rows: list[dict[str, Any]]
    snapshot_payload: dict[str, Any] | None
    reporting_rows: list[dict[str, str]]
    pareto_rows: list[dict[str, str]]
    robustness_rows: list[dict[str, Any]]
    regime_map_payload: dict[str, Any] | None
    ood_slice_rows: list[dict[str, str]]
    failure_atlas_payload: dict[str, Any] | None
    physics_consistency_payload: dict[str, Any] | None


@dataclass(frozen=True)
class AnalysisInputs:
    repo_root: Path
    outputs_root: Path
    preview_line: str
    pack_identity: dict[str, Any]
    grouped_payload: dict[str, Any]
    grouped_rows: list[dict[str, Any]]
    reporting_rows: list[dict[str, str]]
    pareto_rows: list[dict[str, str]]
    robustness_payload: dict[str, Any]
    robustness_rows: list[dict[str, Any]]
    regime_map_payload: dict[str, Any] | None
    ood_slice_rows: list[dict[str, str]]
    failure_atlas_payload: dict[str, Any] | None
    physics_consistency_payload: dict[str, Any] | None
    snapshot_payload: dict[str, Any] | None
    formal_reference: ReferenceRoot | None
    previous_formal_reference: ReferenceRoot | None
    previous_preview_reference: ReferenceRoot | None


@dataclass(frozen=True)
class AssetPaths:
    grouped_json: Path
    reporting_csv: Path
    pareto_csv: Path
    robustness_json: Path
    snapshot_json: Path
    regime_map_json: Path | None
    ood_slice_csv: Path | None
    failure_atlas_json: Path | None
    physics_consistency_json: Path | None


class AnalysisInputError(RuntimeError):
    """Raised when a required analysis input is missing or malformed."""



def analysis_asset_basenames(preview_line: str | None) -> dict[str, list[str]]:
    line = str(preview_line or "v0.7-preview").strip()
    json_md = list(BASE_ANALYSIS_JSON_MD_BASENAMES)
    md_only = list(BASE_ANALYSIS_MD_ONLY_BASENAMES)
    optional_md_only = list(OPTIONAL_ANALYSIS_MD_ONLY_BASENAMES)
    if line == "v0.9-preview":
        json_md.extend(V09_ANALYSIS_JSON_MD_BASENAMES)
        md_only.extend(V09_ANALYSIS_MD_ONLY_BASENAMES)
    elif line in {"v1.1-preview", "v1.2-preview", "v1.3-preview", "v1.4-preview", "v1.5-preview", "v1.6-preview", "v1.7-preview", "v1.8-preview"}:
        json_md.extend(V11_ANALYSIS_JSON_MD_BASENAMES)
    return {"json_md": json_md, "md_only": md_only, "optional_md_only": optional_md_only}



def _infer_preview_line_from_analysis_dir(output_dir: Path) -> str:
    outputs_root = output_dir.resolve().parent
    return infer_preview_line(outputs_root=outputs_root)



def _load_json(path: Path, *, label: str) -> dict[str, Any]:
    if not path.exists():
        raise AnalysisInputError(f"Missing {label}: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise AnalysisInputError(f"Invalid JSON for {label}: {path} ({error})") from error
    if not isinstance(payload, dict):
        raise AnalysisInputError(f"Expected {label} to contain a JSON object: {path}")
    return dict(payload)



def _load_csv_rows(path: Path, *, label: str) -> list[dict[str, str]]:
    if not path.exists():
        raise AnalysisInputError(f"Missing {label}: {path}")
    with path.open("r", encoding="utf-8", newline="") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def _load_optional_json(path: Path | None) -> dict[str, Any] | None:
    if path is None or not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise AnalysisInputError(f"Invalid JSON for optional analysis asset: {path} ({error})") from error
    if not isinstance(payload, dict):
        raise AnalysisInputError(f"Expected optional analysis asset to contain a JSON object: {path}")
    return dict(payload)


def _load_optional_csv_rows(path: Path | None) -> list[dict[str, str]]:
    if path is None or not path.exists():
        return []
    with path.open("r", encoding="utf-8", newline="") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def _pack_identity(outputs_root: Path, snapshot_payload: dict[str, Any] | None) -> dict[str, Any]:
    identity: dict[str, Any] = {
        "pack_kind": "preview",
        "starter_pack_id": None,
        "reference_preview_line": None,
        "outputs_root": str(outputs_root.resolve()),
    }
    if not isinstance(snapshot_payload, dict):
        return identity
    pack_kind = str(snapshot_payload.get("pack_kind") or "").strip()
    if pack_kind:
        identity["pack_kind"] = pack_kind
    starter_pack_id = str(snapshot_payload.get("starter_pack_id") or "").strip()
    if starter_pack_id:
        identity["starter_pack_id"] = starter_pack_id
    reference_preview_line = str(snapshot_payload.get("reference_preview_line") or "").strip()
    if reference_preview_line:
        identity["reference_preview_line"] = reference_preview_line
    return identity


def _first_optional_asset(directory: Path, pattern: str) -> Path | None:
    return next(iter(sorted(directory.glob(pattern))), None)



def resolve_asset_paths(outputs_root: Path) -> AssetPaths:
    output_root = outputs_root.resolve()
    pareto_dir = output_root / "_leaderboard" / "pareto"
    reporting_dir = output_root / "_leaderboard" / "reporting"
    pareto_candidates = [
        path
        for path in sorted(pareto_dir.glob("*_pareto.csv"))
        if not path.name.endswith("_accuracy_cost_pareto.csv")
    ]
    return AssetPaths(
        grouped_json=output_root / "_leaderboard" / "leaderboard_grouped.json",
        reporting_csv=next(
            iter(sorted(reporting_dir.glob("*_baseline_table.csv"))),
            reporting_dir / "missing.csv",
        ),
        pareto_csv=pareto_candidates[0] if pareto_candidates else pareto_dir / "missing.csv",
        robustness_json=output_root / "_audit" / "robustness_summary.json",
        snapshot_json=output_root / "_release_snapshot.json",
        regime_map_json=_first_optional_asset(reporting_dir, "*_regime_map.json"),
        ood_slice_csv=_first_optional_asset(reporting_dir, "*_ood_slice_leaderboard.csv"),
        failure_atlas_json=_first_optional_asset(reporting_dir, "*_failure_atlas.json"),
        physics_consistency_json=_first_optional_asset(reporting_dir, "*_physics_consistency_dashboard.json"),
    )






def _apply_abstraction_metadata(row: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(apply_stress_metadata(row))
    model_name = str(normalized.get("model_name") or "").strip()
    task_name = str(normalized.get("task_name") or "").strip()
    if not model_name or not task_name:
        return normalized
    try:
        model_assignment = lookup_model_capability(model_name)
        task_assignment = lookup_task_observation_target(task_name)
    except KeyError:
        return normalized
    normalized["model_capability_class"] = model_assignment.capability_class.value
    normalized["observation_type"] = task_assignment.observation_type.value
    normalized["target_type"] = task_assignment.target_type.value
    normalized["capability_compatibility_class"] = classify_capability_compatibility(
        capability_class=model_assignment.capability_class,
        observation_type=task_assignment.observation_type,
        target_type=task_assignment.target_type,
    )
    normalized["operator_ready_flag"] = model_assignment.operator_ready_flag
    return normalized

def _normalize_grouped_rows(payload: dict[str, Any]) -> list[dict[str, Any]]:
    rows = payload.get("rows")
    if not isinstance(rows, list):
        raise AnalysisInputError("Grouped payload must contain a 'rows' list.")
    return [_apply_abstraction_metadata(row) for row in rows if isinstance(row, dict)]



def _normalize_robustness_rows(payload: dict[str, Any]) -> list[dict[str, Any]]:
    rows = payload.get("rows")
    if not isinstance(rows, list):
        raise AnalysisInputError("Robustness payload must contain a 'rows' list.")
    return [_apply_abstraction_metadata(dict(row)) for row in rows if isinstance(row, dict)]



def _load_reference_root(outputs_root: Path | None, *, label: str) -> ReferenceRoot | None:
    if outputs_root is None:
        return None
    paths = resolve_asset_paths(outputs_root)
    grouped_payload = _load_json(paths.grouped_json, label=f"{label} grouped leaderboard JSON")
    grouped_rows = _normalize_grouped_rows(grouped_payload)
    reporting_rows = _load_csv_rows(paths.reporting_csv, label=f"{label} reporting CSV")
    pareto_rows = _load_csv_rows(paths.pareto_csv, label=f"{label} pareto CSV")
    snapshot_payload = _load_json(paths.snapshot_json, label=f"{label} release snapshot") if paths.snapshot_json.exists() else None
    robustness_payload = _load_json(paths.robustness_json, label=f"{label} robustness summary") if paths.robustness_json.exists() else {"rows": []}
    robustness_rows = _normalize_robustness_rows(robustness_payload)
    return ReferenceRoot(
        label=label,
        outputs_root=outputs_root.resolve(),
        grouped_payload=grouped_payload,
        grouped_rows=grouped_rows,
        snapshot_payload=snapshot_payload,
        reporting_rows=reporting_rows,
        pareto_rows=pareto_rows,
        robustness_rows=robustness_rows,
        regime_map_payload=_load_optional_json(paths.regime_map_json),
        ood_slice_rows=_load_optional_csv_rows(paths.ood_slice_csv),
        failure_atlas_payload=_load_optional_json(paths.failure_atlas_json),
        physics_consistency_payload=_load_optional_json(paths.physics_consistency_json),
    )



def load_analysis_inputs(
    *,
    outputs_root: Path,
    formal_root: Path | None = None,
    previous_formal_root: Path | None = None,
) -> AnalysisInputs:
    repo_root = resolve_repo_root()
    resolved_outputs_root = outputs_root.resolve()
    paths = resolve_asset_paths(resolved_outputs_root)
    grouped_payload = _load_json(paths.grouped_json, label="grouped leaderboard JSON")
    robustness_payload = _load_json(paths.robustness_json, label="robustness summary JSON")
    snapshot_payload = _load_json(paths.snapshot_json, label="release snapshot JSON") if paths.snapshot_json.exists() else None
    preview_line = infer_preview_line(outputs_root=resolved_outputs_root, snapshot_payload=snapshot_payload)
    previous_preview_root = infer_previous_preview_root(
        outputs_root=resolved_outputs_root,
        repo_root=repo_root,
        preview_line=preview_line,
    )
    return AnalysisInputs(
        repo_root=repo_root,
        outputs_root=resolved_outputs_root,
        preview_line=preview_line,
        pack_identity=_pack_identity(resolved_outputs_root, snapshot_payload),
        grouped_payload=grouped_payload,
        grouped_rows=_normalize_grouped_rows(grouped_payload),
        reporting_rows=_load_csv_rows(paths.reporting_csv, label="reporting CSV"),
        pareto_rows=_load_csv_rows(paths.pareto_csv, label="pareto CSV"),
        robustness_payload=robustness_payload,
        robustness_rows=_normalize_robustness_rows(robustness_payload),
        regime_map_payload=_load_optional_json(paths.regime_map_json),
        ood_slice_rows=_load_optional_csv_rows(paths.ood_slice_csv),
        failure_atlas_payload=_load_optional_json(paths.failure_atlas_json),
        physics_consistency_payload=_load_optional_json(paths.physics_consistency_json),
        snapshot_payload=snapshot_payload,
        formal_reference=_load_reference_root(formal_root, label="current formal reference"),
        previous_formal_reference=_load_reference_root(previous_formal_root, label="previous formal reference"),
        previous_preview_reference=_load_reference_root(previous_preview_root, label="previous preview reference"),
    )



def analysis_history_root(output_dir: Path) -> Path:
    return output_dir.resolve() / "history"



def list_history_entries(output_dir: Path) -> list[Path]:
    history_root = analysis_history_root(output_dir)
    if not history_root.exists():
        return []
    return sorted(path for path in history_root.iterdir() if path.is_dir())



def latest_history_entry(output_dir: Path) -> Path | None:
    entries = list_history_entries(output_dir)
    return entries[-1] if entries else None



def analysis_asset_paths(output_dir: Path, *, preview_line: str | None = None) -> dict[str, Path]:
    resolved = output_dir.resolve()
    line = preview_line or _infer_preview_line_from_analysis_dir(resolved)
    basenames = analysis_asset_basenames(line)
    paths: dict[str, Path] = {
        "analysis_bundle": resolved / "analysis_bundle.json",
        "history_dir": analysis_history_root(resolved),
    }
    for base in basenames["json_md"]:
        paths[f"{base}_json"] = resolved / f"{base}.json"
        paths[f"{base}_md"] = resolved / f"{base}.md"
    for base in basenames["md_only"]:
        paths[f"{base}_md"] = resolved / f"{base}.md"
    for base in basenames["optional_md_only"]:
        paths[f"{base}_md"] = resolved / f"{base}.md"
    return paths



def required_analysis_asset_paths(output_dir: Path, *, preview_line: str | None = None) -> list[Path]:
    line = preview_line or _infer_preview_line_from_analysis_dir(output_dir)
    basenames = analysis_asset_basenames(line)
    paths = analysis_asset_paths(output_dir, preview_line=line)
    required: list[Path] = [paths["analysis_bundle"]]
    for base in basenames["json_md"]:
        required.append(paths[f"{base}_json"])
        required.append(paths[f"{base}_md"])
    for base in basenames["md_only"]:
        required.append(paths[f"{base}_md"])
    return required
