"""Shared regime metadata normalization and grouped-claim derivation."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping
from typing import Any

REGIME_RAW_FIELDS = [
    "regime_protocol_family",
    "regime_slice_id",
    "shift_dimension",
    "train_variant_label",
    "eval_variant_label",
    "parameter_name",
]
GEOMETRY_RAW_FIELDS = [
    "geometry_representation",
    "geometry_split_id",
    "train_geometry_family",
    "eval_geometry_family",
    "geometry_distribution",
    "boundary_band_epsilon",
]
REGIME_DERIVED_FIELDS = [
    "ood_family",
    "regime_problem_class",
    "regime_dynamics_class",
    "regime_observation_class",
    "regime_distribution_class",
    "regime_horizon_class",
    "regime_geometry_class",
    "regime_board_cell_id",
    "regime_claim_complete",
    "regime_claim_blocker_codes",
    "regime_program",
]
GEOMETRY_REQUIRED_COMPLETE_LABEL_FIELDS = [
    "geometry_representation",
    "geometry_split_id",
    "train_geometry_family",
    "eval_geometry_family",
    "geometry_distribution",
    "boundary_band_epsilon",
]
REGIME_REQUIRED_COMPLETE_LABEL_FIELDS = [
    "regime_protocol_family",
    "regime_slice_id",
    "shift_dimension",
    "train_variant_label",
    "eval_variant_label",
    "ood_family",
    "regime_problem_class",
    "regime_dynamics_class",
    "regime_observation_class",
    "regime_distribution_class",
    "regime_horizon_class",
    "regime_geometry_class",
    "regime_board_cell_id",
    "regime_program",
]
REGIME_OOD_PROTOCOLS = {
    "parameter_shift",
    "resolution_shift",
    "bc_family_shift",
    "ic_family_shift",
}
GEOMETRY_PROTOCOLS = {"geometry_shift"}
REGIME_PROTOCOL_HOST_REQUIREMENTS = {
    "parameter_shift": ("pointwise", "operator"),
    "resolution_shift": ("pointwise", "operator"),
    "bc_family_shift": ("pointwise",),
    "ic_family_shift": ("pointwise",),
}
_REGIME_SLICE_KEYS = {
    "parameter_shift": {"slice_id", "parameter_name", "train_value", "eval_value"},
    "resolution_shift": {"slice_id", "train_sampling_overrides", "eval_grid_overrides", "operator_train_stride"},
    "bc_family_shift": {"slice_id", "train_boundary_family", "eval_boundary_family"},
    "ic_family_shift": {"slice_id", "train_initial_family", "eval_initial_family"},
}
_POINTWISE_HEADLINE_TASKS = {"heat1d", "burgers1d", "poisson2d", "allencahn1d"}
_OPERATOR_COVERAGE_TASKS = {
    "burgers1d_operator_rollout",
    "navier_stokes_2d_operator_rollout",
    "shallowwater2d_operator_rollout",
    "reaction_diffusion_operator_rollout",
}
_INVERSE_TASKS = {"heat1d_inverse_diffusivity", "burgers1d_inverse_viscosity"}
_TASK_DYNAMICS_CLASS = {
    "heat1d": "smooth",
    "poisson2d": "smooth",
    "poisson2d_field": "smooth",
    "allencahn1d": "stiff",
    "burgers1d": "discontinuous",
    "burgers1d_operator_rollout": "discontinuous",
    "navier_stokes_2d_operator_rollout": "multiscale",
    "shallowwater2d_operator_rollout": "multiscale",
    "reaction_diffusion_operator_rollout": "multiscale",
}


def empty_regime_raw_fields() -> dict[str, Any]:
    return {field: None for field in REGIME_RAW_FIELDS}


def empty_geometry_raw_fields() -> dict[str, Any]:
    return {field: None for field in GEOMETRY_RAW_FIELDS}


def empty_regime_derived_fields() -> dict[str, Any]:
    payload = {field: None for field in REGIME_DERIVED_FIELDS}
    payload["regime_claim_blocker_codes"] = []
    return payload


def _string_or_none(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _float_or_none(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _is_mapping(value: Any) -> bool:
    return isinstance(value, Mapping)


def _format_variant_mapping(prefix: str, mapping: Mapping[str, Any]) -> str:
    items = ", ".join(f"{key}={mapping[key]}" for key in sorted(mapping))
    return f"{prefix}[{items}]"


def _regime_raw_payload(
    *,
    protocol_family: str | None = None,
    slice_id: str | None = None,
    shift_dimension: str | None = None,
    train_variant_label: str | None = None,
    eval_variant_label: str | None = None,
    parameter_name: str | None = None,
) -> dict[str, Any]:
    return {
        "regime_protocol_family": protocol_family,
        "regime_slice_id": slice_id,
        "shift_dimension": shift_dimension,
        "train_variant_label": train_variant_label,
        "eval_variant_label": eval_variant_label,
        "parameter_name": parameter_name,
    }


def normalize_regime_metadata_mapping(raw: Any) -> dict[str, Any]:
    payload = empty_regime_raw_fields()
    if not _is_mapping(raw):
        return payload
    data = dict(raw)
    payload["regime_protocol_family"] = _string_or_none(data.get("protocol_family"))
    payload["regime_slice_id"] = _string_or_none(data.get("slice_id"))
    payload["shift_dimension"] = _string_or_none(data.get("shift_dimension"))
    payload["train_variant_label"] = _string_or_none(data.get("train_variant_label"))
    payload["eval_variant_label"] = _string_or_none(data.get("eval_variant_label"))
    payload["parameter_name"] = _string_or_none(data.get("parameter_name"))
    return payload


def normalize_geometry_metadata_mapping(raw: Any) -> dict[str, Any]:
    payload = empty_geometry_raw_fields()
    if not _is_mapping(raw):
        return payload
    data = dict(raw)
    payload["geometry_representation"] = _string_or_none(data.get("representation"))
    payload["geometry_split_id"] = _string_or_none(data.get("geometry_split_id"))
    payload["train_geometry_family"] = _string_or_none(data.get("train_geometry_family"))
    payload["eval_geometry_family"] = _string_or_none(data.get("eval_geometry_family"))
    payload["geometry_distribution"] = _string_or_none(data.get("geometry_distribution"))
    payload["boundary_band_epsilon"] = _float_or_none(data.get("boundary_band_epsilon"))
    return payload


def regime_dict_from_record(record: Mapping[str, Any]) -> dict[str, Any]:
    direct = {field: record.get(field) for field in REGIME_RAW_FIELDS}
    if any(value not in {None, ""} for value in direct.values()):
        normalized = empty_regime_raw_fields()
        for field, value in direct.items():
            normalized[field] = _string_or_none(value)
        return normalized
    return normalize_regime_metadata_mapping(record.get("regime"))


def geometry_dict_from_record(record: Mapping[str, Any]) -> dict[str, Any]:
    direct = {field: record.get(field) for field in GEOMETRY_RAW_FIELDS}
    if any(value not in {None, ""} for value in direct.values()):
        normalized = empty_geometry_raw_fields()
        for field, value in direct.items():
            if field == "boundary_band_epsilon":
                normalized[field] = _float_or_none(value)
            else:
                normalized[field] = _string_or_none(value)
        return normalized
    return normalize_geometry_metadata_mapping(record.get("geometry"))


def regime_raw_fields_from_config(*, protocol: str, task_params: Mapping[str, Any] | None) -> dict[str, Any]:
    if protocol not in REGIME_OOD_PROTOCOLS or not _is_mapping(task_params):
        return empty_regime_raw_fields()
    raw_slice = task_params.get("regime_slice")
    if not _is_mapping(raw_slice):
        return empty_regime_raw_fields()
    regime_slice = dict(raw_slice)
    if set(regime_slice) - _REGIME_SLICE_KEYS[protocol]:
        return empty_regime_raw_fields()
    slice_id = _string_or_none(regime_slice.get("slice_id"))
    if slice_id is None:
        return empty_regime_raw_fields()
    if protocol == "parameter_shift":
        parameter_name = _string_or_none(regime_slice.get("parameter_name"))
        if parameter_name is None or "train_value" not in regime_slice or "eval_value" not in regime_slice:
            return empty_regime_raw_fields()
        return _regime_raw_payload(
            protocol_family=protocol,
            slice_id=slice_id,
            shift_dimension="parameter",
            train_variant_label=f"{parameter_name}={regime_slice['train_value']}",
            eval_variant_label=f"{parameter_name}={regime_slice['eval_value']}",
            parameter_name=parameter_name,
        )
    if protocol == "resolution_shift":
        train_sampling_overrides = regime_slice.get("train_sampling_overrides")
        eval_grid_overrides = regime_slice.get("eval_grid_overrides")
        operator_train_stride = regime_slice.get("operator_train_stride")
        train_parts: list[str] = []
        if _is_mapping(train_sampling_overrides) and train_sampling_overrides:
            train_parts.append(_format_variant_mapping("sampling", train_sampling_overrides))
        if _is_mapping(operator_train_stride) and operator_train_stride:
            train_parts.append(_format_variant_mapping("stride", operator_train_stride))
        train_variant = ";".join(train_parts) if train_parts else "nominal"
        eval_variant = (
            _format_variant_mapping("grid", eval_grid_overrides)
            if _is_mapping(eval_grid_overrides) and eval_grid_overrides
            else "nominal"
        )
        return _regime_raw_payload(
            protocol_family=protocol,
            slice_id=slice_id,
            shift_dimension="resolution",
            train_variant_label=train_variant,
            eval_variant_label=eval_variant,
        )
    if protocol == "bc_family_shift":
        train_family = _string_or_none(regime_slice.get("train_boundary_family"))
        eval_family = _string_or_none(regime_slice.get("eval_boundary_family"))
        if train_family is None or eval_family is None:
            return empty_regime_raw_fields()
        return _regime_raw_payload(
            protocol_family=protocol,
            slice_id=slice_id,
            shift_dimension="boundary_family",
            train_variant_label=train_family,
            eval_variant_label=eval_family,
        )
    if protocol == "ic_family_shift":
        train_family = _string_or_none(regime_slice.get("train_initial_family"))
        eval_family = _string_or_none(regime_slice.get("eval_initial_family"))
        if train_family is None or eval_family is None:
            return empty_regime_raw_fields()
        return _regime_raw_payload(
            protocol_family=protocol,
            slice_id=slice_id,
            shift_dimension="initial_family",
            train_variant_label=train_family,
            eval_variant_label=eval_family,
        )
    return empty_regime_raw_fields()


def _regime_candidate(record: Mapping[str, Any], raw: Mapping[str, Any]) -> bool:
    protocol = str(record.get("protocol") or "none").strip()
    geometry_raw = geometry_dict_from_record(record)
    geometry_present = any(value not in {None, ""} for value in geometry_raw.values())
    return (
        protocol in REGIME_OOD_PROTOCOLS
        or protocol in GEOMETRY_PROTOCOLS
        or any(value not in {None, ""} for value in raw.values())
        or geometry_present
    )


def _problem_class(record: Mapping[str, Any]) -> str | None:
    task_name = str(record.get("task_name") or "").strip()
    if task_name in _INVERSE_TASKS:
        return "inverse"
    task_mode = str(record.get("task_mode") or "").strip()
    if task_mode == "field" or task_name in _OPERATOR_COVERAGE_TASKS:
        return "operator"
    if task_name:
        return "forward"
    return None


def _distribution_class(record: Mapping[str, Any], geometry: Mapping[str, Any]) -> str | None:
    protocol = str(record.get("protocol") or "none").strip()
    if protocol == "none":
        geometry_distribution = _string_or_none(geometry.get("geometry_distribution"))
        return geometry_distribution or "ID"
    if protocol in REGIME_OOD_PROTOCOLS:
        return "OOD"
    if protocol in GEOMETRY_PROTOCOLS:
        return _string_or_none(geometry.get("geometry_distribution"))
    return None


def _horizon_class(record: Mapping[str, Any]) -> str | None:
    task_name = str(record.get("task_name") or "").strip()
    if task_name in _OPERATOR_COVERAGE_TASKS:
        return "long_horizon"
    if task_name:
        return "short_horizon"
    return None


def _regime_program(record: Mapping[str, Any]) -> str | None:
    task_name = str(record.get("task_name") or "").strip()
    if task_name in _POINTWISE_HEADLINE_TASKS:
        return "headline"
    if task_name:
        return "coverage_only"
    return None


def _regime_geometry_class(*, geometry: Mapping[str, Any], distribution_class: str | None) -> str:
    geometry_present = any(value not in {None, ""} for value in geometry.values())
    if not geometry_present:
        return "regular_geometry"
    train_geometry_family = _string_or_none(geometry.get("train_geometry_family"))
    eval_geometry_family = _string_or_none(geometry.get("eval_geometry_family"))
    if train_geometry_family == "regular_square" and eval_geometry_family == "regular_square":
        return "regular_geometry"
    if distribution_class == "ID":
        return "geometry_id"
    if distribution_class == "OOD":
        return "geometry_ood"
    return "regular_geometry"


def _board_cell_id(*, problem_class: str, dynamics_class: str, observation_class: str, distribution_class: str, horizon_class: str, geometry_class: str) -> str:
    return "|".join(
        [
            f"problem={problem_class}",
            f"dynamics={dynamics_class}",
            f"observation={observation_class}",
            f"distribution={distribution_class}",
            f"horizon={horizon_class}",
            f"geometry={geometry_class}",
        ]
    )


def derive_regime_row_fields(record: Mapping[str, Any]) -> dict[str, Any]:
    raw = regime_dict_from_record(record)
    geometry = geometry_dict_from_record(record)
    if not _regime_candidate(record, raw):
        return empty_regime_derived_fields()

    derived = empty_regime_derived_fields()
    blockers: list[str] = []
    raw_present = any(value not in {None, ""} for value in raw.values())
    if not raw_present:
        blockers.append("missing_regime_metadata")

    protocol = str(record.get("protocol") or "none").strip()
    distribution_class = _distribution_class(record, geometry)
    derived["ood_family"] = "ID" if distribution_class == "ID" else (protocol if distribution_class == "OOD" else None)
    derived["regime_problem_class"] = _problem_class(record)
    derived["regime_dynamics_class"] = _TASK_DYNAMICS_CLASS.get(str(record.get("task_name") or "").strip())
    derived["regime_observation_class"] = "dense_supervision"
    derived["regime_distribution_class"] = distribution_class
    derived["regime_horizon_class"] = _horizon_class(record)
    derived["regime_geometry_class"] = _regime_geometry_class(geometry=geometry, distribution_class=distribution_class)
    derived["regime_program"] = _regime_program(record)

    if raw_present:
        required_axes = [
            derived["regime_problem_class"],
            derived["regime_dynamics_class"],
            derived["regime_observation_class"],
            derived["regime_distribution_class"],
            derived["regime_horizon_class"],
            derived["regime_geometry_class"],
        ]
        if any(value in {None, ""} for value in required_axes):
            blockers.append("missing_regime_axes")
        else:
            derived["regime_board_cell_id"] = _board_cell_id(
                problem_class=str(derived["regime_problem_class"]),
                dynamics_class=str(derived["regime_dynamics_class"]),
                observation_class=str(derived["regime_observation_class"]),
                distribution_class=str(derived["regime_distribution_class"]),
                horizon_class=str(derived["regime_horizon_class"]),
                geometry_class=str(derived["regime_geometry_class"]),
            )
    if derived["regime_program"] == "coverage_only":
        blockers.append("coverage_only_program")
    derived["regime_claim_blocker_codes"] = sorted(dict.fromkeys(blockers))
    derived["regime_claim_complete"] = bool(raw_present and not derived["regime_claim_blocker_codes"])
    return derived


def enrich_regime_row(record: Mapping[str, Any]) -> dict[str, Any]:
    enriched = dict(record)
    raw = regime_dict_from_record(record)
    geometry = geometry_dict_from_record(record)
    enriched.update(raw)
    enriched.update(geometry)
    enriched.update(derive_regime_row_fields(enriched))
    return enriched


def row_has_complete_regime_labels(record: Mapping[str, Any]) -> bool:
    enriched = enrich_regime_row(record)
    for field in REGIME_REQUIRED_COMPLETE_LABEL_FIELDS:
        if _string_or_none(enriched.get(field)) is None:
            return False
    protocol_family = _string_or_none(enriched.get("regime_protocol_family"))
    if protocol_family == "parameter_shift" and _string_or_none(enriched.get("parameter_name")) is None:
        return False
    geometry_present = any(enriched.get(field) not in {None, ""} for field in GEOMETRY_RAW_FIELDS)
    if protocol_family == "geometry_shift" or geometry_present:
        for field in GEOMETRY_REQUIRED_COMPLETE_LABEL_FIELDS:
            if field == "boundary_band_epsilon":
                if _float_or_none(enriched.get(field)) is None:
                    return False
                continue
            if _string_or_none(enriched.get(field)) is None:
                return False
    return True


def row_has_complete_geometry_labels(record: Mapping[str, Any]) -> bool:
    enriched = enrich_regime_row(record)
    protocol_family = _string_or_none(enriched.get("regime_protocol_family"))
    geometry_present = any(enriched.get(field) not in {None, ""} for field in GEOMETRY_RAW_FIELDS)
    if protocol_family != "geometry_shift" and not geometry_present:
        return True
    for field in GEOMETRY_REQUIRED_COMPLETE_LABEL_FIELDS:
        if field == "boundary_band_epsilon":
            if _float_or_none(enriched.get(field)) is None:
                return False
            continue
        if _string_or_none(enriched.get(field)) is None:
            return False
    return True


def summarize_regime_governance(
    grouped_payload: Mapping[str, Any] | None,
    *,
    regime_map_payload: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    rows = grouped_payload.get("rows") if isinstance(grouped_payload, Mapping) and isinstance(grouped_payload.get("rows"), list) else []
    candidate_rows: list[dict[str, Any]] = []
    targeted_rows_missing_complete_labels: list[str] = []
    host_index: dict[str, dict[str, set[str]]] = {
        protocol: {"pointwise_tasks": set(), "operator_tasks": set()}
        for protocol in sorted(REGIME_OOD_PROTOCOLS)
    }
    geometry_targeted_rows: list[dict[str, Any]] = []
    geometry_targeted_rows_missing_complete_labels: list[str] = []
    geometry_targeted_rows_missing_geometry_labels: list[str] = []
    geometry_targeted_rows_missing_required_metrics: list[str] = []
    geometry_host_index = {"pointwise_tasks": set(), "operator_tasks": set()}

    for row in rows:
        if not isinstance(row, Mapping):
            continue
        enriched = enrich_regime_row(row)
        if not _regime_candidate(enriched, regime_dict_from_record(enriched)):
            continue
        candidate_rows.append(enriched)
        if not row_has_complete_regime_labels(enriched):
            row_id = _string_or_none(enriched.get("run_id")) or _string_or_none(enriched.get("row_id")) or ""
            targeted_rows_missing_complete_labels.append(row_id)
        protocol_family = _string_or_none(enriched.get("regime_protocol_family"))
        protocol = str(enriched.get("protocol") or "none").strip()
        problem_class = _string_or_none(enriched.get("regime_problem_class"))
        task_name = _string_or_none(enriched.get("task_name"))
        if protocol_family in REGIME_OOD_PROTOCOLS and task_name is not None and row_has_complete_regime_labels(enriched):
            if problem_class == "forward":
                host_index[protocol_family]["pointwise_tasks"].add(task_name)
            elif problem_class == "operator":
                host_index[protocol_family]["operator_tasks"].add(task_name)
        geometry_present = any(enriched.get(field) not in {None, ""} for field in GEOMETRY_RAW_FIELDS)
        if protocol_family == "geometry_shift" or geometry_present:
            row_id = _string_or_none(enriched.get("run_id")) or _string_or_none(enriched.get("row_id")) or ""
            geometry_targeted_rows.append(enriched)
            if not row_has_complete_geometry_labels(enriched):
                geometry_targeted_rows_missing_geometry_labels.append(row_id)
            if not row_has_complete_regime_labels(enriched):
                geometry_targeted_rows_missing_complete_labels.append(row_id)
            else:
                near_boundary_metric = _float_or_none(enriched.get("eval_near_boundary_relative_l2_mean"))
                residual_metric = _float_or_none(enriched.get("eval_residual_metric_mean"))
                if near_boundary_metric is None or residual_metric is None:
                    geometry_targeted_rows_missing_required_metrics.append(row_id)
                elif task_name is not None and protocol == "geometry_shift":
                    if problem_class == "forward":
                        geometry_host_index["pointwise_tasks"].add(task_name)
                    elif problem_class == "operator":
                        geometry_host_index["operator_tasks"].add(task_name)

    regime_map_summary = (
        dict(regime_map_payload.get("summary", {}))
        if isinstance(regime_map_payload, Mapping) and isinstance(regime_map_payload.get("summary"), Mapping)
        else {}
    )
    cells = [
        dict(cell)
        for cell in (regime_map_payload.get("cells") if isinstance(regime_map_payload, Mapping) else [])
        if isinstance(cell, Mapping)
    ]
    headline_cells = [cell for cell in cells if _string_or_none(cell.get("regime_program")) == "headline"]
    coverage_only_cells = [cell for cell in cells if _string_or_none(cell.get("regime_program")) == "coverage_only"]
    blocked_headline_cells = [
        cell
        for cell in headline_cells
        if bool(cell.get("blocker_codes")) or int(cell.get("blocked_count", 0) or 0) > 0
    ]
    mixed_distribution_group_count = sum(
        1
        for cell in headline_cells
        if "mixed_distribution_class" in [str(code) for code in cell.get("blocker_codes", [])]
    )
    mixed_ood_family_group_count = sum(
        1
        for cell in headline_cells
        if "mixed_ood_family" in [str(code) for code in cell.get("blocker_codes", [])]
    )
    ood_protocol_families_present = regime_map_summary.get("ood_protocol_families_present")
    if not isinstance(ood_protocol_families_present, list):
        ood_protocol_families_present = sorted(
            {
                str(row.get("ood_family"))
                for row in candidate_rows
                if row.get("ood_family") not in {None, "", "ID"}
            }
        )
    regime_hosts_with_complete_labels = {
        protocol: {
            "pointwise_tasks": sorted(host_index[protocol]["pointwise_tasks"]),
            "operator_tasks": sorted(host_index[protocol]["operator_tasks"]),
        }
        for protocol in sorted(host_index)
    }
    host_requirements = {
        "parameter_shift_pointwise": bool(regime_hosts_with_complete_labels["parameter_shift"]["pointwise_tasks"]),
        "parameter_shift_operator": bool(regime_hosts_with_complete_labels["parameter_shift"]["operator_tasks"]),
        "resolution_shift_pointwise": bool(regime_hosts_with_complete_labels["resolution_shift"]["pointwise_tasks"]),
        "resolution_shift_operator": bool(regime_hosts_with_complete_labels["resolution_shift"]["operator_tasks"]),
        "bc_family_shift_pointwise": bool(regime_hosts_with_complete_labels["bc_family_shift"]["pointwise_tasks"]),
        "ic_family_shift_pointwise": bool(regime_hosts_with_complete_labels["ic_family_shift"]["pointwise_tasks"]),
    }
    missing_host_requirements = [
        requirement for requirement, present in host_requirements.items() if not present
    ]
    geometry_claim_groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in geometry_targeted_rows:
        split_id = _string_or_none(row.get("geometry_split_id"))
        if split_id is None:
            continue
        geometry_claim_groups[split_id].append(row)
    mixed_geometry_distribution_group_count = 0
    mixed_geometry_class_group_count = 0
    for group_rows in geometry_claim_groups.values():
        distributions = {
            str(row.get("geometry_distribution") or "")
            for row in group_rows
            if _string_or_none(row.get("geometry_distribution")) is not None
        }
        geometry_classes = {
            str(row.get("regime_geometry_class") or "")
            for row in group_rows
            if _string_or_none(row.get("regime_geometry_class")) is not None
        }
        if len(distributions) > 1:
            mixed_geometry_distribution_group_count += 1
        if len(geometry_classes) > 1:
            mixed_geometry_class_group_count += 1
    geometry_host_requirements = {
        "geometry_shift_pointwise": bool(geometry_host_index["pointwise_tasks"]) if geometry_targeted_rows else True,
        "geometry_shift_operator": bool(geometry_host_index["operator_tasks"]) if geometry_targeted_rows else True,
    }
    missing_geometry_host_requirements = [
        requirement for requirement, present in geometry_host_requirements.items() if not present
    ]
    return {
        "regime_summary_present": bool(regime_map_summary),
        "regime_group_count": len(cells),
        "headline_regime_group_count": len(headline_cells),
        "coverage_only_regime_group_count": len(coverage_only_cells),
        "blocked_regime_group_count": len(blocked_headline_cells),
        "mixed_distribution_group_count": mixed_distribution_group_count,
        "mixed_ood_family_group_count": mixed_ood_family_group_count,
        "ood_protocol_families_present": list(ood_protocol_families_present),
        "targeted_regime_row_count": len(candidate_rows),
        "targeted_rows_missing_complete_labels_count": len(targeted_rows_missing_complete_labels),
        "targeted_rows_missing_complete_labels": targeted_rows_missing_complete_labels,
        "regime_hosts_with_complete_labels": regime_hosts_with_complete_labels,
        "host_requirements": host_requirements,
        "missing_host_requirements": missing_host_requirements,
        "regime_summary": regime_map_summary,
        "geometry_targeted_row_count": len(geometry_targeted_rows),
        "geometry_targeted_rows_missing_complete_labels_count": len(geometry_targeted_rows_missing_complete_labels),
        "geometry_targeted_rows_missing_complete_labels": geometry_targeted_rows_missing_complete_labels,
        "geometry_targeted_rows_missing_geometry_labels_count": len(geometry_targeted_rows_missing_geometry_labels),
        "geometry_targeted_rows_missing_geometry_labels": geometry_targeted_rows_missing_geometry_labels,
        "geometry_targeted_rows_missing_required_metrics_count": len(geometry_targeted_rows_missing_required_metrics),
        "geometry_targeted_rows_missing_required_metrics": geometry_targeted_rows_missing_required_metrics,
        "geometry_group_count": len(geometry_claim_groups),
        "mixed_geometry_distribution_group_count": mixed_geometry_distribution_group_count,
        "mixed_geometry_class_group_count": mixed_geometry_class_group_count,
        "geometry_hosts_with_complete_labels": {
            "pointwise_tasks": sorted(geometry_host_index["pointwise_tasks"]),
            "operator_tasks": sorted(geometry_host_index["operator_tasks"]),
        },
        "geometry_host_requirements": geometry_host_requirements,
        "missing_geometry_host_requirements": missing_geometry_host_requirements,
    }


def build_regime_payload(*, grouped_rows: list[dict[str, Any]]) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, dict[str, Any]]]:
    candidate_rows: list[dict[str, Any]] = []
    metadata_complete_rows = 0
    metadata_missing_rows = 0
    claim_complete_rows = 0
    claim_incomplete_rows = 0

    for row in grouped_rows:
        raw = regime_dict_from_record(row)
        if not _regime_candidate(row, raw):
            continue
        enriched = dict(row)
        enriched.update(raw)
        derived = derive_regime_row_fields(enriched)
        enriched.update(derived)
        if any(value not in {None, ""} for value in raw.values()):
            metadata_complete_rows += 1
        else:
            metadata_missing_rows += 1
        if derived.get("regime_claim_complete"):
            claim_complete_rows += 1
        else:
            claim_incomplete_rows += 1
        candidate_rows.append(enriched)

    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in candidate_rows:
        board_cell_id = _string_or_none(row.get("regime_board_cell_id"))
        if board_cell_id is not None:
            grouped[board_cell_id].append(dict(row))

    regime_groups: list[dict[str, Any]] = []
    regime_group_index: dict[str, dict[str, Any]] = {}
    for board_cell_id in sorted(grouped):
        rows = grouped[board_cell_id]
        example = rows[0]
        distribution_classes = sorted({str(row.get("regime_distribution_class")) for row in rows if row.get("regime_distribution_class")})
        ood_families = sorted({str(row.get("ood_family")) for row in rows if row.get("ood_family")})
        baseline_families_present = sorted({str(row.get("baseline_family")) for row in rows if row.get("baseline_family")})
        blockers: list[str] = []
        if len(distribution_classes) > 1:
            blockers.append("mixed_distribution_class")
        if len([family for family in ood_families if family != "ID"]) > 1:
            blockers.append("mixed_ood_family")
        if any("coverage_only_program" in (row.get("regime_claim_blocker_codes") or []) for row in rows):
            blockers.append("coverage_only_program")
        unique_blockers = sorted(dict.fromkeys(blockers))
        group_payload = {
            "regime_board_cell_id": board_cell_id,
            "ood_family": example.get("ood_family"),
            "regime_problem_class": example.get("regime_problem_class"),
            "regime_dynamics_class": example.get("regime_dynamics_class"),
            "regime_observation_class": example.get("regime_observation_class"),
            "regime_distribution_class": example.get("regime_distribution_class"),
            "regime_horizon_class": example.get("regime_horizon_class"),
            "regime_geometry_class": example.get("regime_geometry_class"),
            "regime_program": example.get("regime_program"),
            "regime_claim_complete": not unique_blockers,
            "regime_claim_blocker_codes": unique_blockers,
            "row_count": len(rows),
            "headline_row_count": sum(1 for row in rows if row.get("regime_program") == "headline"),
            "coverage_only_row_count": sum(1 for row in rows if row.get("regime_program") == "coverage_only"),
            "baseline_families_present": baseline_families_present,
            "ood_families_present": ood_families,
            "rows": rows,
        }
        regime_groups.append(group_payload)
        regime_group_index[board_cell_id] = group_payload

    summary = {
        "regime_metadata_row_count": metadata_complete_rows,
        "regime_metadata_missing_row_count": metadata_missing_rows,
        "regime_claim_complete_row_count": claim_complete_rows,
        "regime_claim_incomplete_row_count": claim_incomplete_rows,
        "regime_group_count": len(regime_groups),
        "headline_regime_group_count": sum(1 for group in regime_groups if group.get("regime_program") == "headline"),
        "coverage_only_regime_group_count": sum(1 for group in regime_groups if group.get("regime_program") == "coverage_only"),
        "blocked_regime_group_count": sum(1 for group in regime_groups if group.get("regime_claim_blocker_codes")),
        "mixed_distribution_group_count": sum(
            1 for group in regime_groups if "mixed_distribution_class" in group.get("regime_claim_blocker_codes", [])
        ),
        "mixed_ood_family_group_count": sum(
            1 for group in regime_groups if "mixed_ood_family" in group.get("regime_claim_blocker_codes", [])
        ),
        "ood_protocol_families_present": sorted(
            {
                str(row.get("ood_family"))
                for row in candidate_rows
                if row.get("ood_family") not in {None, "", "ID"}
            }
        ),
        "geometry_group_count": sum(
            1 for group in regime_groups if group.get("regime_geometry_class") in {"geometry_id", "geometry_ood"}
        ),
        "geometry_id_group_count": sum(1 for group in regime_groups if group.get("regime_geometry_class") == "geometry_id"),
        "geometry_ood_group_count": sum(1 for group in regime_groups if group.get("regime_geometry_class") == "geometry_ood"),
        "geometry_classes_present": sorted(
            {
                str(group.get("regime_geometry_class"))
                for group in regime_groups
                if group.get("regime_geometry_class") not in {None, ""}
            }
        ),
    }
    return summary, regime_groups, regime_group_index
