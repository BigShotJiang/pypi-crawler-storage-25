"""Registry helpers for models, tasks, and metrics."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

Factory = Callable[..., Any]
MetricFn = Callable[..., float]

_MODEL_REGISTRY: dict[str, Factory] = {}
_TASK_REGISTRY: dict[str, Factory] = {}
_METRIC_REGISTRY: dict[str, MetricFn] = {}


def _register(name: str, factory: Factory, registry: dict[str, Factory], kind: str) -> None:
    key = name.lower()
    if key in registry:
        raise KeyError(f"{kind} '{name}' is already registered.")
    registry[key] = factory


def _create(name: str, registry: dict[str, Factory], kind: str, **kwargs: Any) -> Any:
    key = name.lower()
    if key not in registry:
        available = ", ".join(sorted(registry.keys())) or "<empty>"
        raise KeyError(f"Unknown {kind} '{name}'. Available: {available}")
    return registry[key](**kwargs)


def _get(name: str, registry: dict[str, MetricFn], kind: str) -> MetricFn:
    key = name.lower()
    if key not in registry:
        available = ", ".join(sorted(registry.keys())) or "<empty>"
        raise KeyError(f"Unknown {kind} '{name}'. Available: {available}")
    return registry[key]


def register_model(name: str) -> Callable[[Factory], Factory]:
    """Decorator for registering a model factory/class."""

    def decorator(factory: Factory) -> Factory:
        _register(name=name, factory=factory, registry=_MODEL_REGISTRY, kind="model")
        return factory

    return decorator


def create_native_model(name: str, **kwargs: Any) -> Any:
    """Create a native model by name from the native model registry."""
    return _create(name=name, registry=_MODEL_REGISTRY, kind="model", **kwargs)


def register_task(name: str) -> Callable[[Factory], Factory]:
    """Decorator for registering a task factory/class."""

    def decorator(factory: Factory) -> Factory:
        _register(name=name, factory=factory, registry=_TASK_REGISTRY, kind="task")
        return factory

    return decorator


def register_metric(name: str) -> Callable[[MetricFn], MetricFn]:
    """Decorator for registering a metric function."""

    def decorator(factory: MetricFn) -> MetricFn:
        _register(name=name, factory=factory, registry=_METRIC_REGISTRY, kind="metric")
        return factory

    return decorator


def create_model(name: str, **kwargs: Any) -> Any:
    """Create a native or external adapter-backed model by name."""
    resolution_error: KeyError | None = None
    try:
        resolved_name = resolve_model_name(name, include_external=True, include_canonical_family=True)
    except KeyError as error:
        resolution_error = error
        resolved_name = str(name).strip().lower()
    key = resolved_name.lower()
    if key in _MODEL_REGISTRY:
        model = _MODEL_REGISTRY[key](**kwargs)
        from pinn_bench.models.primary_method_registry import resolve_primary_method_record

        primary_method = resolve_primary_method_record(name)
        if primary_method is not None:
            setattr(model, "__pinn_bench_primary_method_metadata__", primary_method.to_catalog_entry())
        return model

    from pinn_bench.models.external_registry import create_external_model, list_external_model_names, resolve_external_model_record

    if resolve_external_model_record(resolved_name) is None:
        if resolution_error is not None:
            raise resolution_error
        available = ", ".join(sorted([*list_models(), *list_external_model_names()])) or "<empty>"
        raise KeyError(f"Unknown model '{name}'. Available: {available}")
    model = create_external_model(resolved_name, **kwargs)
    from pinn_bench.models.primary_method_registry import resolve_primary_method_record

    primary_method = resolve_primary_method_record(name)
    if primary_method is not None:
        setattr(model, "__pinn_bench_primary_method_metadata__", primary_method.to_catalog_entry())
    return model


def create_task(name: str, **kwargs: Any) -> Any:
    """Create a task by name from the task registry."""
    return _create(name=name, registry=_TASK_REGISTRY, kind="task", **kwargs)


def get_metric(name: str) -> MetricFn:
    """Return a metric function by name from the metric registry."""
    return _get(name=name, registry=_METRIC_REGISTRY, kind="metric")


def list_models() -> list[str]:
    """Return sorted native registered model names."""
    return sorted(_MODEL_REGISTRY.keys())


def list_external_models(
    *,
    source_benchmark: str | None = None,
    integration_state: str | None = None,
    model_category: str | None = None,
    runnable_only: bool = False,
    pinn_family_only: bool = False,
    operator_family_only: bool = False,
) -> list[str]:
    """Return sorted external model names from the external catalog."""
    from pinn_bench.models.external_registry import list_external_model_names

    return list_external_model_names(
        source_benchmark=source_benchmark,
        integration_state=integration_state,
        model_category=model_category,
        runnable_only=runnable_only,
        pinn_family_only=pinn_family_only,
        operator_family_only=operator_family_only,
    )


def list_all_models(
    *,
    include_native: bool = True,
    include_external: bool = True,
    source_benchmark: str | None = None,
    integration_state: str | None = None,
    model_category: str | None = None,
    runnable_only: bool = False,
    pinn_family_only: bool = False,
    operator_family_only: bool = False,
) -> list[str]:
    """Return the unified native + external model universe."""
    names: list[str] = []
    if include_native:
        native = list_models()
        if pinn_family_only:
            native = [name for name in native if name in {"mlp", "siren", "adaptive_mlp", "xpinn_mlp"}]
        if operator_family_only:
            native = [name for name in native if name in {"mini_fno", "grid_mlp", "spectral_mlp"}]
        if runnable_only:
            native = list(native)
        names.extend(native)
    if include_external:
        names.extend(
            list_external_models(
                source_benchmark=source_benchmark,
                integration_state=integration_state,
                model_category=model_category,
                runnable_only=runnable_only,
                pinn_family_only=pinn_family_only,
                operator_family_only=operator_family_only,
            )
        )
    return sorted(dict.fromkeys(names))


def get_model_catalog_entry(name: str) -> dict[str, Any]:
    """Return unified identity metadata for one native or external model."""
    key = str(name).strip().lower()
    from pinn_bench.models.primary_method_registry import resolve_primary_method_record
    from pinn_bench.models.native_family_registry import get_variant_for_original_model, resolve_model_to_canonical_family, get_canonical_family_record

    primary_method = resolve_primary_method_record(name)
    if primary_method is not None:
        payload = primary_method.to_catalog_entry()
        try:
            from pinn_bench.fair_board import get_fair_board_method_entry

            payload.update(get_fair_board_method_entry(primary_method.method_id))
        except Exception:
            pass
        if primary_method.default_runtime_name is not None:
            try:
                runtime_payload = get_model_catalog_entry(primary_method.default_runtime_name)
            except KeyError:
                runtime_payload = None
            if runtime_payload is not None:
                payload["resolved_runtime_entry"] = runtime_payload
        return payload

    if key in _MODEL_REGISTRY:
        factory = _MODEL_REGISTRY[key]
        payload = {
            "canonical_name": key,
            "display_name": key,
            "source_benchmark": None,
            "source_family_name": None,
            "external_model_id": None,
            "model_category": "native",
            "model_subcategory": "field" if str(getattr(factory, "model_mode", "pointwise")) == "field" else "pointwise",
            "is_pinn_family": key in {"mlp", "siren", "adaptive_mlp", "xpinn_mlp"},
            "is_operator_family": str(getattr(factory, "model_mode", "pointwise")) == "field",
            "is_solver_adjacent": False,
            "integration_state": "native",
            "adapter_name": None,
            "runnable_status": "runnable",
            "native_equivalent": key,
            "comparability_scope": "native_runtime",
            "capability_tags": [],
            "provenance_notes": "Native model registered directly in PINNMark.",
            "repo_path": None,
            "notes": "",
        }
        try:
            family_id = resolve_model_to_canonical_family(key)
            family = get_canonical_family_record(family_id)
            variant = get_variant_for_original_model(key)
            payload.update(
                {
                    "canonical_family_id": family_id,
                    "canonical_family_display_name": family.display_name,
                    "canonical_family_category": family.family_category,
                    "top_level_family_id": family.top_level_family_id,
                    "top_level_family_display_name": family.top_level_family_display_name,
                    "family_level": family.family_level,
                    "family_aliases": list(family.aliases),
                    "implementation_variant_id": variant.implementation_variant_id,
                    "implementation_variant_role": variant.implementation_variant_role,
                    "fidelity_level": variant.fidelity_level,
                    "internalization_state": family.internalization_state,
                }
            )
        except KeyError:
            pass
        return payload
    from pinn_bench.models.external_registry import resolve_external_model_record
    record = resolve_external_model_record(name)
    if record is None:
        available = ", ".join(sorted([*list_models(), *list_external_models()])) or "<empty>"
        raise KeyError(f"Unknown model '{name}'. Available: {available}")
    payload = record.to_dict()
    try:
        family_id = resolve_model_to_canonical_family(record.external_model_id)
        family = get_canonical_family_record(family_id)
        variant = get_variant_for_original_model(record.external_model_id)
        payload.update(
            {
                "canonical_family_id": family_id,
                "canonical_family_display_name": family.display_name,
                "canonical_family_category": family.family_category,
                "top_level_family_id": family.top_level_family_id,
                "top_level_family_display_name": family.top_level_family_display_name,
                "family_level": family.family_level,
                "family_aliases": list(family.aliases),
                "implementation_variant_id": variant.implementation_variant_id,
                "implementation_variant_role": variant.implementation_variant_role,
                "fidelity_level": variant.fidelity_level,
                "internalization_state": family.internalization_state,
            }
        )
    except KeyError:
        pass
    return payload


def list_main_fair_board_entries() -> list[dict[str, Any]]:
    """Return the hard-gated main fair board entries."""
    from pinn_bench.fair_board import build_main_fair_board

    return build_main_fair_board()


def resolve_model_name(
    name: str,
    *,
    include_external: bool = True,
    include_canonical_family: bool = False,
) -> str:
    """Resolve native or external aliases to canonical model names."""
    key = str(name).strip().lower()
    if key in _MODEL_REGISTRY:
        return key
    from pinn_bench.models.primary_method_registry import resolve_primary_method_record

    primary_method = resolve_primary_method_record(name)
    if primary_method is not None:
        if primary_method.default_runtime_name is None or primary_method.runnable_status != "runnable":
            raise KeyError(
                f"Known primary method '{name}' is not constructible yet "
                f"(level={primary_method.internalization_level}, runtime_status={primary_method.runtime_contract_status}, "
                f"comparability={primary_method.comparability_status})."
            )
        return str(primary_method.default_runtime_name)

    if include_canonical_family:
        from pinn_bench.models.native_family_registry import get_canonical_family_record, resolve_canonical_family_default_model

        if str(name).strip().startswith("pinnmark."):
            try:
                family = get_canonical_family_record(str(name).strip())
            except KeyError:
                family = None
            if family is not None:
                default_model = resolve_canonical_family_default_model(str(name).strip())
                if default_model is not None:
                    return default_model
                raise KeyError(
                    f"Canonical family '{name}' exists but has no default runnable variant "
                    f"(state={family.internalization_state})."
                )
    if include_external:
        from pinn_bench.models.external_registry import get_external_model_record

        record = get_external_model_record(name)
        if record is not None:
            if record.integration_state != "external_runnable":
                raise KeyError(
                    f"Known external model '{name}' is not runnable "
                    f"(state={record.integration_state}, runnable_status={record.runnable_status})."
                )
            return record.canonical_name
    available = ", ".join(sorted([*list_models(), *list_external_models()])) or "<empty>"
    raise KeyError(f"Unknown model '{name}'. Available: {available}")


def list_canonical_families() -> list[str]:
    """Return sorted canonical family ids."""
    from pinn_bench.models.native_family_registry import list_canonical_families as _list_canonical_families

    return _list_canonical_families()


def list_top_level_families() -> list[str]:
    """Return sorted top-level family ids."""
    from pinn_bench.models.native_family_registry import list_top_level_families as _list_top_level_families

    return _list_top_level_families()


def list_primary_methods() -> list[str]:
    """Return sorted primary benchmark-method ids."""
    from pinn_bench.models.primary_method_registry import list_primary_method_ids as _list_primary_method_ids

    return _list_primary_method_ids()


def resolve_primary_method_name(name: str) -> str:
    """Resolve a primary-method id or alias to its canonical id."""
    from pinn_bench.models.primary_method_registry import get_primary_method_record

    return get_primary_method_record(name).method_id


def get_family_variants(family_id: str) -> list[dict[str, Any]]:
    """Return serializable variants for one canonical family."""
    from pinn_bench.models.native_family_registry import get_family_variants as _get_family_variants

    return [variant.to_dict() for variant in _get_family_variants(family_id)]


def get_family_lineage(family_id: str) -> list[dict[str, Any]]:
    """Return lineage/provenance rows for one canonical family."""
    from pinn_bench.models.native_family_registry import get_family_lineage as _get_family_lineage

    return _get_family_lineage(family_id)


def resolve_model_to_canonical_family(model_id: str) -> str:
    """Resolve any model id into a canonical family id."""
    from pinn_bench.models.native_family_registry import resolve_model_to_canonical_family as _resolve_model_to_canonical_family

    return _resolve_model_to_canonical_family(model_id)


def get_family_internalization_state(family_id: str) -> str:
    """Return internalization state for one canonical family."""
    from pinn_bench.models.native_family_registry import get_family_internalization_state as _get_family_internalization_state

    return _get_family_internalization_state(family_id)


def list_tasks() -> list[str]:
    """Return sorted registered task names."""
    return sorted(_TASK_REGISTRY.keys())


def list_metrics() -> list[str]:
    """Return sorted registered metric names."""
    return sorted(_METRIC_REGISTRY.keys())
