"""Command-line interface utilities for pinn_bench."""

from __future__ import annotations

import argparse
from typing import Sequence


def build_parser() -> argparse.ArgumentParser:
    """Build the CLI parser for benchmark execution."""
    parser = argparse.ArgumentParser(description="Run PINN benchmark experiment.")
    parser.add_argument(
        "--config",
        type=str,
        required=True,
        help="Path to experiment YAML config.",
    )
    parser.add_argument(
        "--device",
        type=str,
        default=None,
        help="Optional device override (e.g. cpu, cuda).",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Optional random seed override.",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=None,
        help="Optional output directory override.",
    )
    parser.add_argument(
        "--log-backend",
        type=str,
        default=None,
        help="Optional logging backend override (basic, none, tensorboard, wandb).",
    )
    return parser


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    """Parse CLI arguments."""
    parser = build_parser()
    return parser.parse_args(argv)

