"""Shared fair-budget comparison contract helpers."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any


ALLOWED_BASELINE_FAMILIES = (
    "pinn",
    "neural_operator",
    "classical_reference",
    "pure_data_driven",
)
ALLOWED_DATA_BUDGET_CLASSES = ("sparse", "moderate", "dense")
ALLOWED_COMPUTE_BUDGET_CLASSES = ("small", "medium", "large")
ALLOWED_TUNING_BUDGET_CLASSES = ("fixed_recipe", "bounded_tuning", "open_tuning")
ALLOWED_COMPARISON_SCOPES = (
    "matched_information",
    "matched_compute",
    "matched_tuning",
    "matched_all",
)
COMPARISON_FIELDS = (
    "baseline_family",
    "data_budget_class",
    "compute_budget_class",
    "tuning_budget_class",
    "comparison_scope",
)
HEADLINE_TASKS = ("heat1d", "burgers1d", "poisson2d", "allencahn1d")
HEADLINE_PINN_MODELS = ("mlp", "siren")
HEADLINE_REQUIRED_BASELINE_FAMILIES = ("pinn", "classical_reference")
OPERATOR_COVERAGE_TASKS = (
    "navier_stokes_2d_operator_rollout",
    "shallowwater2d_operator_rollout",
    "reaction_diffusion_operator_rollout",
)


def _ensure_mapping(value: Any, location: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"Expected mapping at '{location}', got {type(value).__name__}.")
    return dict(value)


def _parse_enum(
    payload: dict[str, Any],
    *,
    key: str,
    allowed: tuple[str, ...],
    location: str,
) -> str:
    raw_value = payload.pop(key, None)
    normalized = str(raw_value or "").strip()
    if normalized not in allowed:
        allowed_text = ", ".join(allowed)
        raise ValueError(f"'{location}.{key}' must be one of: {allowed_text}")
    return normalized


@dataclass(frozen=True)
class ComparisonConfig:
    """Strict fair-budget comparison metadata."""

    baseline_family: str
    data_budget_class: str
    compute_budget_class: str
    tuning_budget_class: str
    comparison_scope: str

    def to_dict(self) -> dict[str, str]:
        return {
            "baseline_family": self.baseline_family,
            "data_budget_class": self.data_budget_class,
            "compute_budget_class": self.compute_budget_class,
            "tuning_budget_class": self.tuning_budget_class,
            "comparison_scope": self.comparison_scope,
        }


def parse_comparison_config(payload: Mapping[str, Any] | None, *, location: str = "comparison") -> ComparisonConfig | None:
    """Parse optional fair-budget comparison metadata from a mapping."""
    if payload is None:
        return None
    data = _ensure_mapping(payload, location)
    comparison = ComparisonConfig(
        baseline_family=_parse_enum(
            data,
            key="baseline_family",
            allowed=ALLOWED_BASELINE_FAMILIES,
            location=location,
        ),
        data_budget_class=_parse_enum(
            data,
            key="data_budget_class",
            allowed=ALLOWED_DATA_BUDGET_CLASSES,
            location=location,
        ),
        compute_budget_class=_parse_enum(
            data,
            key="compute_budget_class",
            allowed=ALLOWED_COMPUTE_BUDGET_CLASSES,
            location=location,
        ),
        tuning_budget_class=_parse_enum(
            data,
            key="tuning_budget_class",
            allowed=ALLOWED_TUNING_BUDGET_CLASSES,
            location=location,
        ),
        comparison_scope=_parse_enum(
            data,
            key="comparison_scope",
            allowed=ALLOWED_COMPARISON_SCOPES,
            location=location,
        ),
    )
    if data:
        extras = ", ".join(sorted(data))
        raise ValueError(f"Unsupported key(s) in '{location}': {extras}")
    return comparison


def comparison_dict_from_mapping(payload: Mapping[str, Any] | None, *, location: str = "comparison") -> dict[str, str] | None:
    """Normalize an optional mapping into a strict comparison dict."""
    comparison = parse_comparison_config(payload, location=location)
    return None if comparison is None else comparison.to_dict()


def comparison_dict_from_record(record: Mapping[str, Any]) -> dict[str, str] | None:
    """Reconstruct a comparison mapping from flattened row-like records."""
    values = {field: record.get(field) for field in COMPARISON_FIELDS}
    if all(values[field] not in {None, ""} for field in COMPARISON_FIELDS):
        return comparison_dict_from_mapping(values)
    return None


def comparison_contract_complete(record: Mapping[str, Any]) -> bool:
    return comparison_dict_from_record(record) is not None


def is_headline_task(task_name: str) -> bool:
    return str(task_name).strip() in HEADLINE_TASKS


def is_operator_coverage_task(task_name: str) -> bool:
    return str(task_name).strip() in OPERATOR_COVERAGE_TASKS

