"""Capability taxonomy helpers for the v1.4-preview abstraction line."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml

import pinn_bench.models  # noqa: F401
from pinn_bench.interfaces.model_capabilities import CapabilityClass, CapabilityDescriptor, ModelCapabilityAssignment
from pinn_bench.interfaces.observation_types import ObservationType, TargetType
from pinn_bench.registry import _MODEL_REGISTRY
from pinn_bench.resources import resolve_repo_root


def _taxonomy_path() -> Path:
    return resolve_repo_root() / 'configs' / 'capabilities' / 'capability_taxonomy.yaml'


@lru_cache(maxsize=1)
def _taxonomy_payload() -> dict[str, Any]:
    payload = yaml.safe_load(_taxonomy_path().read_text(encoding='utf-8'))
    if not isinstance(payload, dict):
        raise ValueError('Capability taxonomy must decode to a mapping.')
    return dict(payload)


@lru_cache(maxsize=1)
def _capability_descriptors() -> dict[str, CapabilityDescriptor]:
    classes = _taxonomy_payload().get('capability_classes', [])
    if not isinstance(classes, list):
        raise ValueError('capability_classes must be a list.')
    descriptors: dict[str, CapabilityDescriptor] = {}
    for item in classes:
        if not isinstance(item, dict):
            continue
        capability_name = str(item.get('name') or '').strip()
        if not capability_name:
            continue
        capability_class = CapabilityClass(capability_name)
        descriptors[capability_name] = CapabilityDescriptor(
            capability_class=capability_class,
            summary=str(item.get('summary') or '').strip(),
            interface_shape=str(item.get('interface_shape') or '').strip(),
            future_facing=bool(item.get('future_facing')),
        )
    return descriptors


def list_capability_classes() -> list[str]:
    return list(_capability_descriptors().keys())


def get_capability_descriptor(capability_class: str | CapabilityClass) -> CapabilityDescriptor:
    key = capability_class.value if isinstance(capability_class, CapabilityClass) else str(capability_class).strip()
    descriptors = _capability_descriptors()
    if key not in descriptors:
        available = ', '.join(descriptors)
        raise KeyError(f"Unknown capability class '{capability_class}'. Available: {available}")
    return descriptors[key]


@lru_cache(maxsize=1)
def _model_assignments() -> dict[str, ModelCapabilityAssignment]:
    mapping = _taxonomy_payload().get('current_model_mapping', {})
    if not isinstance(mapping, dict):
        raise ValueError('current_model_mapping must be a mapping.')
    assignments: dict[str, ModelCapabilityAssignment] = {}
    for raw_name, payload in mapping.items():
        if not isinstance(payload, dict):
            continue
        model_name = str(raw_name).strip().lower()
        capability_class = CapabilityClass(str(payload.get('capability_class') or '').strip())
        evidence = payload.get('evidence', [])
        assignments[model_name] = ModelCapabilityAssignment(
            model_name=model_name,
            capability_class=capability_class,
            operator_ready_flag=bool(payload.get('operator_ready_flag')),
            evidence=tuple(str(item) for item in evidence) if isinstance(evidence, list) else (),
        )
    return assignments


def list_model_capability_assignments() -> list[ModelCapabilityAssignment]:
    return [lookup_model_capability(name) for name in sorted(_model_assignments())]


def lookup_model_capability(model_name: str) -> ModelCapabilityAssignment:
    key = str(model_name).strip().lower()
    assignments = _model_assignments()
    if key not in assignments:
        available = ', '.join(sorted(assignments))
        raise KeyError(f"Unknown model capability mapping '{model_name}'. Available: {available}")
    assignment = assignments[key]
    factory = _MODEL_REGISTRY.get(key)
    if factory is None:
        raise KeyError(f"Model '{model_name}' is not registered.")
    model_mode = str(getattr(factory, 'model_mode', 'pointwise')).strip().lower()
    has_forward_field = callable(getattr(factory, 'forward_field', None))
    if assignment.capability_class is CapabilityClass.FIELDWISE_SOLUTION_MODEL:
        if model_mode != 'field' or not has_forward_field:
            raise ValueError(f"Model '{model_name}' is mapped as fieldwise_solution_model but does not expose the expected field interface.")
    if assignment.capability_class is CapabilityClass.POINTWISE_SOLUTION_MODEL and model_mode == 'field':
        raise ValueError(f"Model '{model_name}' is mapped as pointwise_solution_model but reports model_mode='field'.")
    if assignment.operator_ready_flag and not has_forward_field:
        raise ValueError(f"Model '{model_name}' is marked operator-ready but lacks forward_field(...).")
    return assignment


def classify_capability_compatibility(
    *,
    capability_class: str | CapabilityClass,
    observation_type: str | ObservationType,
    target_type: str | TargetType,
) -> str:
    capability = CapabilityClass(capability_class) if not isinstance(capability_class, CapabilityClass) else capability_class
    observation = ObservationType(observation_type) if not isinstance(observation_type, ObservationType) else observation_type
    target = TargetType(target_type) if not isinstance(target_type, TargetType) else target_type
    if capability is CapabilityClass.POINTWISE_SOLUTION_MODEL and observation is ObservationType.POINT_OBSERVATION and target is TargetType.POINT_TARGET:
        return 'native_pointwise'
    if capability is CapabilityClass.FIELDWISE_SOLUTION_MODEL and observation is ObservationType.OPERATOR_CONDITION_OBSERVATION and target is TargetType.FIELD_TARGET:
        return 'native_field_conditioned'
    if capability is CapabilityClass.TRAJECTORY_SOLUTION_MODEL and observation is ObservationType.TRAJECTORY_OBSERVATION and target is TargetType.TRAJECTORY_TARGET:
        return 'future_trajectory_reserved'
    if capability is CapabilityClass.OPERATOR_RESPONSE_MODEL and observation is ObservationType.OPERATOR_CONDITION_OBSERVATION and target is TargetType.OPERATOR_RESPONSE_TARGET:
        return 'future_operator_reserved'
    if capability is CapabilityClass.HYBRID_PHYSICS_MODEL and (observation, target) in {
        (ObservationType.POINT_OBSERVATION, TargetType.POINT_TARGET),
        (ObservationType.OPERATOR_CONDITION_OBSERVATION, TargetType.FIELD_TARGET),
    }:
        return 'hybrid_bridge'
    return 'incompatible'
