"""User-facing API facade for common pinn_bench workflows."""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml

import pinn_bench.metrics  # noqa: F401
import pinn_bench.models  # noqa: F401
import pinn_bench.tasks  # noqa: F401
from pinn_bench.analysis.preview_line import get_preview_line_info
from pinn_bench.config.loader import load_config
from pinn_bench.config.schema import ExperimentConfig
from pinn_bench.experiments import matrix_run
from pinn_bench.registry import create_model
from pinn_bench.resources import resolve_config_path, resolve_manifest_path, resolve_repo_root

_CANONICAL_FORMAL_ROOTS = {"outputs_v10", "outputs_v02", "outputs_v03", "outputs_v04", "outputs_v05", "outputs_v06"}
_CANONICAL_PREVIEW_ROOTS = {
    get_preview_line_info("v0.7-preview").outputs_root_name,
    get_preview_line_info("v0.8-preview").outputs_root_name,
    get_preview_line_info("v0.9-preview").outputs_root_name,
    get_preview_line_info("v1.1-preview").outputs_root_name,
    get_preview_line_info("v1.2-preview").outputs_root_name,
    get_preview_line_info("v1.3-preview").outputs_root_name,
}
_TEMPLATE_SUFFIX = ".yaml"


def _template_root() -> Path:
    return (resolve_repo_root() / "configs" / "templates").resolve()


def _examples_root() -> Path:
    return (resolve_repo_root() / "configs" / "examples" / "v1_3_preview").resolve()


def _available_template_paths() -> dict[str, Path]:
    root = _template_root()
    templates: dict[str, Path] = {}
    if not root.exists():
        return templates
    for path in sorted(root.glob("*.yaml")):
        templates[path.stem] = path.resolve()
    return templates


def list_config_templates() -> list[str]:
    """Return the available built-in config template names."""
    return sorted(_available_template_paths())


def _format_available_templates() -> str:
    available = list_config_templates()
    return ", ".join(available) if available else "<none>"


def _resolve_template_path(template_name: str | Path) -> Path:
    raw = Path(str(template_name)).expanduser()
    templates = _available_template_paths()
    if raw.is_absolute() or len(raw.parts) > 1:
        resolved = raw.resolve()
        if resolved.exists():
            return resolved
        raise FileNotFoundError(f"Template file does not exist: {resolved}")
    key = raw.stem if raw.suffix else raw.name
    if key in templates:
        return templates[key]
    if raw.suffix == _TEMPLATE_SUFFIX:
        keyed = raw.name[: -len(_TEMPLATE_SUFFIX)]
        if keyed in templates:
            return templates[keyed]
    raise ValueError(f"Unknown template '{template_name}'. Available templates: {_format_available_templates()}")


def _load_template_payload(template_name: str | Path) -> tuple[Path, dict[str, Any]]:
    template_path = _resolve_template_path(template_name)
    payload = yaml.safe_load(template_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Template '{template_path}' must contain a YAML mapping.")
    return template_path, payload


def _safe_output_root_name(name: str) -> str:
    normalized = name.strip().replace("-", "_") or "preview"
    return normalized


def _is_protected_output_root(path: Path) -> bool:
    resolved = path.resolve()
    names = _CANONICAL_FORMAL_ROOTS | _CANONICAL_PREVIEW_ROOTS
    if resolved.name in names:
        return True
    return any(parent.name in names for parent in resolved.parents)


def _ensure_safe_output_root(path: str | Path, *, purpose: str) -> Path:
    resolved = Path(str(path)).expanduser().resolve()
    if _is_protected_output_root(resolved):
        raise ValueError(
            f"Refusing to use canonical benchmark root '{resolved}'. Choose a safe custom path such as outputs_playground/... for {purpose}."
        )
    return resolved


def _default_preview_output_dir(label: str) -> Path:
    repo_root = resolve_repo_root()
    return (repo_root / "outputs_playground" / f"{_safe_output_root_name(label)}_preview").resolve()


def load_model(name: str, **params: Any) -> Any:
    """Instantiate a registered model through the public facade."""
    return create_model(name, **params)


def load_config_template(template_name: str | Path, *, overrides: dict[str, Any] | None = None) -> ExperimentConfig:
    """Load one built-in template through the standard config loader."""
    template_path = _resolve_template_path(template_name)
    return load_config(template_path, overrides=overrides)


def _write_yaml(path: Path, payload: dict[str, Any]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
    return path


def create_scaffold(
    kind: str,
    template_name: str | Path,
    destination: str | Path,
    *,
    force: bool = False,
    output_root: str | Path | None = None,
) -> list[Path]:
    """Generate a config or starter-run scaffold from a built-in template."""
    template_path, payload = _load_template_payload(template_name)
    kind_value = str(kind).strip().lower()
    if kind_value not in {"config", "run"}:
        raise ValueError("Scaffold kind must be 'config' or 'run'.")

    cloned = deepcopy(payload)
    if output_root is not None:
        safe_output = _ensure_safe_output_root(output_root, purpose="DX scaffold output")
        cloned.setdefault("output", {})["root_dir"] = str(safe_output)

    destination_path = Path(str(destination)).expanduser().resolve()
    if destination_path.exists() and not force:
        raise FileExistsError(f"Destination already exists: {destination_path}. Use --force to overwrite it.")

    created: list[Path] = []
    if kind_value == "config":
        if destination_path.suffix != _TEMPLATE_SUFFIX:
            raise ValueError(f"Config scaffold destination must end with '{_TEMPLATE_SUFFIX}': {destination_path}")
        created.append(_write_yaml(destination_path, cloned))
        return created

    destination_path.mkdir(parents=True, exist_ok=True)
    config_path = destination_path / "config.yaml"
    readme_path = destination_path / "README.md"
    config_output_root = cloned.get("output", {}).get("root_dir")
    if output_root is None and config_output_root:
        _ensure_safe_output_root(config_output_root, purpose="DX scaffold output")
    _write_yaml(config_path, cloned)
    template_label = template_path.stem
    readme_path.write_text(
        "\n".join(
            [
                f"# {template_label} starter run",
                "",
                "## Purpose",
                f"This directory was scaffolded from `{template_label}`.",
                "",
                "## Next Commands",
                f"- `pinn-bench run --config {config_path}`",
                f"- `pinn-bench doctor --preview --outputs-root {config_output_root or 'outputs_playground/...'} --json`",
                "- `pinn-bench version --json`",
                "",
                "## Notes",
                "- Keep starter outputs outside canonical formal or preview roots.",
                "- Adjust `output.root_dir` in `config.yaml` if you want a different playground path.",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    created.extend([config_path, readme_path])
    return created


def run_preview(
    config_or_template: str | Path | ExperimentConfig,
    *,
    output_dir: str | Path | None = None,
    seed: int | None = None,
    device: str | None = None,
    log_backend: str | None = None,
) -> dict[str, Any]:
    """Run one safe preview-oriented experiment through the public facade."""
    from pinn_bench.runners.experiment import run_experiment

    if isinstance(config_or_template, ExperimentConfig):
        config = deepcopy(config_or_template)
        label = f"{config.task.name}_{config.model.name}"
    else:
        try:
            template_path = _resolve_template_path(config_or_template)
        except Exception:
            template_path = resolve_config_path(config_or_template)
        config = load_config(template_path, overrides={"seed": seed, "device": device})
        label = Path(template_path).stem

    resolved_output = _default_preview_output_dir(label) if output_dir is None else _ensure_safe_output_root(output_dir, purpose="run_preview")
    config.output.root_dir = str(resolved_output)
    if seed is not None:
        config.train.seed = int(seed)
    if device is not None:
        config.train.device = str(device)
    if log_backend is not None:
        config.logging.backend = str(log_backend)
    return run_experiment(config)


def run_benchmark(
    matrix_manifest: str | Path,
    *,
    outputs_root: str | Path,
    dry_run: bool = False,
    skip_existing: bool = False,
) -> dict[str, Any]:
    """Run or dry-run a benchmark matrix against a safe outputs root."""
    manifest_path = resolve_manifest_path(matrix_manifest)
    safe_outputs_root = _ensure_safe_output_root(outputs_root, purpose="run_benchmark")
    argv = [
        "--matrix-manifest",
        str(manifest_path),
        "--outputs-root",
        str(safe_outputs_root),
    ]
    if dry_run:
        argv.append("--dry-run")
    if skip_existing:
        argv.append("--skip-existing")
    matrix_run.main(argv)
    context = matrix_run.build_matrix_context(manifest_path, safe_outputs_root)
    return {
        "manifest_path": str(manifest_path.resolve()),
        "outputs_root": str(safe_outputs_root),
        "dry_run": bool(dry_run),
        "skip_existing": bool(skip_existing),
        "report_json": str(context.report_json_path.resolve()),
        "report_csv": str(context.report_csv_path.resolve()),
    }


__all__ = [
    "create_scaffold",
    "list_config_templates",
    "load_config_template",
    "load_model",
    "run_benchmark",
    "run_preview",
]
