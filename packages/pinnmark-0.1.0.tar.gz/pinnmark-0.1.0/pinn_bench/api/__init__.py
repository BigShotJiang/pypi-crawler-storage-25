"""Stable user-facing API facade for pinn_bench."""

from pinn_bench.api.user_api import (
    create_scaffold,
    list_config_templates,
    load_config_template,
    load_model,
    run_benchmark,
    run_preview,
)

__all__ = [
    "create_scaffold",
    "list_config_templates",
    "load_config_template",
    "load_model",
    "run_benchmark",
    "run_preview",
]
