"""pinn_bench package."""

__version__ = "0.1.0"

from pinn_bench.suite import Suite
from pinn_bench.suite_models import (
    SuiteClaim,
    SuiteFigure,
    SuiteKeyFiles,
    SuiteMaturity,
    SuiteRunResult,
    SuiteSummary,
    SuiteTruthTrace,
)

__all__ = [
    "Suite",
    "SuiteClaim",
    "SuiteFigure",
    "SuiteKeyFiles",
    "SuiteMaturity",
    "SuiteRunResult",
    "SuiteSummary",
    "SuiteTruthTrace",
    "__version__",
]
