"""Thin suite-level front door for NeurIPS 2026 benchmark suites."""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from functools import lru_cache
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from typing import Any

import yaml

from pinn_bench.easy.config_adapter import ensure_safe_output_root
from pinn_bench.easy.exceptions import InvalidCompositionError
from pinn_bench.experiments import matrix_run
from pinn_bench.resources import resolve_repo_root
from pinn_bench.suite_models import (
    SuiteClaim,
    SuiteFigure,
    SuiteKeyFiles,
    SuiteMaturity,
    SuiteRunResult,
    SuiteSummary,
    SuiteTruthTrace,
)


DEFAULT_SUITE_LAUNCH_MANIFEST = (
    "project_management/neurips2026_execution/first_wave/generated_manifests/launch/"
    "neurips2026_first_wave_launch.yaml"
)
FIGURE_REGISTRY_SCHEMA_VERSION = "suite.figure_registry.v0.1"
CLAIM_REGISTRY_SCHEMA_VERSION = "suite.claim_registry.v0.1"
SUITE_TRUTH_HIERARCHY = (
    "runtime_artifacts",
    "machine_readable_registries",
    "suite_local_projected_artifacts",
    "execution_control_board",
    "descriptive_suite_docs",
)
SUITE_TRUTH_VERSION = "suite_truth.v0.2"


@dataclass(frozen=True)
class SuiteLaunchEntry:
    """Resolved suite entry from the compiled first-wave launch manifest."""

    suite_name: str
    phase: int
    runner_type: str
    depends_on: str
    manifest_path: Path
    results_root: Path
    runbook_path: Path
    gate_spec_path: Path
    projection_plan_path: Path
    launch_manifest_path: Path


def default_launch_manifest_path() -> Path:
    """Return the default compiled first-wave launch manifest."""
    return (resolve_repo_root() / DEFAULT_SUITE_LAUNCH_MANIFEST).resolve()


def default_suite_results_root(*, suite_name: str) -> Path:
    """Return the safe, non-canonical default runtime root for one suite."""
    return (resolve_repo_root() / "outputs_playground" / "suite_runs" / suite_name).resolve()


def suite_dir_path(*, suite_name: str) -> Path:
    """Return the paper-facing suite directory."""
    return (resolve_repo_root() / "paper" / "neurips2026" / "suites" / suite_name).resolve()


def execution_dir_path() -> Path:
    """Return the paper-facing execution control directory."""
    return (resolve_repo_root() / "paper" / "neurips2026" / "execution").resolve()


def staging_root_path() -> Path:
    """Return the first-wave staging root."""
    return (resolve_repo_root() / "outputs_neurips2026_first_wave_staging").resolve()


def _registry_dir_path(suite_dir: Path) -> Path:
    return suite_dir / "registry"


def _figure_registry_path(suite_dir: Path) -> Path:
    return _registry_dir_path(suite_dir) / "figures.json"


def _claim_registry_path(suite_dir: Path) -> Path:
    return _registry_dir_path(suite_dir) / "claims.json"


def _coerce_path(path: str | Path) -> Path:
    return Path(str(path)).expanduser().resolve()


def _read_yaml(path: Path) -> dict[str, Any]:
    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Expected YAML mapping in {path}")
    return dict(payload)


def _read_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Expected JSON mapping in {path}")
    return dict(payload)


def _read_csv_rows(path: Path) -> list[dict[str, str]]:
    import csv

    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _resolve_launch_path(path: str | Path | None) -> Path:
    if path is None:
        return default_launch_manifest_path()
    candidate = _coerce_path(path)
    if candidate.exists():
        return candidate
    raise FileNotFoundError(f"Suite launch manifest does not exist: {candidate}")


def _resolve_entry_path(raw: str, *, repo_root: Path) -> Path:
    path = Path(str(raw)).expanduser()
    if path.is_absolute():
        resolved = path.resolve()
        if resolved.exists():
            return resolved
        try:
            anchor_index = max(index for index, part in enumerate(path.parts) if part == repo_root.name)
        except ValueError:
            return resolved
        if anchor_index + 1 >= len(path.parts):
            return resolved
        rebased = (repo_root / Path(*path.parts[anchor_index + 1 :])).resolve()
        if rebased.exists():
            return rebased
        return resolved
    return (repo_root / path).resolve()


def load_suite_launch_entries(launch_manifest_path: str | Path | None = None) -> list[SuiteLaunchEntry]:
    """Load all suite entries from the compiled first-wave launch manifest."""
    launch_path = _resolve_launch_path(launch_manifest_path)
    payload = _read_yaml(launch_path)
    entries = payload.get("entries")
    if not isinstance(entries, list):
        raise ValueError(f"Launch manifest '{launch_path}' must contain an 'entries' list.")
    repo_root = resolve_repo_root(launch_path)
    normalized: list[SuiteLaunchEntry] = []
    for item in entries:
        if not isinstance(item, Mapping):
            continue
        suite_name = str(item.get("suite_name", "")).strip()
        if not suite_name:
            continue
        normalized.append(
            SuiteLaunchEntry(
                suite_name=suite_name,
                phase=int(item.get("phase", 0)),
                runner_type=str(item.get("runner_type", "")).strip(),
                depends_on=str(item.get("depends_on", "")).strip(),
                manifest_path=_resolve_entry_path(str(item.get("manifest_path", "")), repo_root=repo_root),
                results_root=_resolve_entry_path(str(item.get("results_root", "")), repo_root=repo_root),
                runbook_path=_resolve_entry_path(str(item.get("runbook_path", "")), repo_root=repo_root),
                gate_spec_path=_resolve_entry_path(str(item.get("gate_spec_path", "")), repo_root=repo_root),
                projection_plan_path=_resolve_entry_path(
                    str(item.get("projection_plan_path", "")),
                    repo_root=repo_root,
                ),
                launch_manifest_path=launch_path,
            )
        )
    return normalized


def get_suite_entry(
    suite_name: str,
    *,
    launch_manifest_path: str | Path | None = None,
) -> SuiteLaunchEntry:
    """Resolve one suite entry by stable suite name."""
    normalized_name = str(suite_name).strip()
    for entry in load_suite_launch_entries(launch_manifest_path):
        if entry.suite_name == normalized_name:
            return entry
    available = ", ".join(entry.suite_name for entry in load_suite_launch_entries(launch_manifest_path))
    raise InvalidCompositionError(f"Unknown suite '{suite_name}'. Available suites: {available}")


def list_suites(launch_manifest_path: str | Path | None = None) -> list[dict[str, Any]]:
    """Return suite catalog entries for the front door."""
    rows: list[dict[str, Any]] = []
    for entry in load_suite_launch_entries(launch_manifest_path):
        rows.append(
            {
                "suite_name": entry.suite_name,
                "phase": entry.phase,
                "runner_type": entry.runner_type,
                "depends_on": entry.depends_on,
                "launch_results_root": str(entry.results_root),
                "default_results_root": str(default_suite_results_root(suite_name=entry.suite_name)),
                "manifest_path": str(entry.manifest_path),
                "runbook_path": str(entry.runbook_path),
                "gate_spec_path": str(entry.gate_spec_path),
            }
        )
    return rows


def _runtime_report_path_from_payload(payload: Mapping[str, Any], *, results_root: Path) -> Path | None:
    runs = payload.get("runs")
    if isinstance(runs, list) and runs and isinstance(runs[0], Mapping):
        first_row = runs[0]
        matrix_name = first_row.get("matrix_name")
        if matrix_name:
            candidate = results_root / "_matrix_runs" / f"{matrix_name}_run_report.json"
            if candidate.exists():
                return candidate
    summary = payload.get("summary")
    if isinstance(summary, Mapping):
        pass
    return None


@lru_cache(maxsize=2)
def _load_external_script_module(path: str) -> Any:
    module_path = (resolve_repo_root() / path).resolve()
    spec = importlib.util.spec_from_file_location(module_path.stem.replace("-", "_"), module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load module spec for {module_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module.__name__] = module
    spec.loader.exec_module(module)
    return module


def _make_manifest_with_results_root(
    manifest_path: Path,
    *,
    results_root: Path,
) -> Path:
    payload = _read_yaml(manifest_path)
    payload["results_root"] = str(results_root.resolve())
    tempdir = Path(tempfile.mkdtemp(prefix="pinn_bench_suite_manifest_"))
    temp_manifest_path = tempdir / manifest_path.name
    temp_manifest_path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
    return temp_manifest_path


def _resolve_runtime_results_root(
    entry: SuiteLaunchEntry,
    *,
    results_root: str | Path | None,
    use_launch_root: bool,
    prefer_existing_user_root: bool = False,
) -> Path:
    if results_root is not None and use_launch_root:
        raise InvalidCompositionError("Use either --results-root or --use-launch-root, not both.")
    if results_root is not None:
        return ensure_safe_output_root(results_root, purpose=f"suite run for {entry.suite_name}")
    if use_launch_root:
        return entry.results_root.resolve()
    default_root = default_suite_results_root(suite_name=entry.suite_name)
    if prefer_existing_user_root and default_root.exists():
        return default_root.resolve()
    if prefer_existing_user_root:
        return entry.results_root.resolve()
    return default_root.resolve()


def run_suite(
    *,
    suite_name: str,
    launch_manifest_path: str | Path | None = None,
    results_root: str | Path | None = None,
    use_launch_root: bool = False,
    family_ids: Sequence[str] | None = None,
    seeds: Sequence[int] | None = None,
    max_runs: int | None = None,
    skip_existing: bool = True,
    dry_run: bool = False,
) -> SuiteRunResult:
    """Run one suite through a unified thin front door."""
    entry = get_suite_entry(suite_name, launch_manifest_path=launch_manifest_path)
    runtime_results_root = _resolve_runtime_results_root(
        entry,
        results_root=results_root,
        use_launch_root=use_launch_root,
    )

    dispatch_family_ids = [str(family_id).strip() for family_id in family_ids or [] if str(family_id).strip()]
    dispatch_seeds = [int(seed) for seed in seeds] if seeds is not None else None

    if entry.runner_type == "native_matrix":
        payload = matrix_run.execute_matrix_runs(
            manifest_path=entry.manifest_path,
            outputs_root_override=str(runtime_results_root),
            seeds_override=dispatch_seeds,
            run_ids=dispatch_family_ids or None,
            max_runs=max_runs,
            skip_existing=bool(skip_existing),
            dry_run=bool(dry_run),
        )
    elif entry.runner_type == "transfer_program":
        module = _load_external_script_module("scripts/run_neurips2026_transfer_program.py")
        manifest_path = (
            entry.manifest_path
            if runtime_results_root == entry.results_root.resolve()
            else _make_manifest_with_results_root(entry.manifest_path, results_root=runtime_results_root)
        )
        payload = module.execute_transfer_program(
            manifest_path=manifest_path,
            family_ids=dispatch_family_ids or None,
            seeds_override=dispatch_seeds,
            skip_existing=bool(skip_existing),
            dry_run=bool(dry_run),
        )
    elif entry.runner_type == "reference_program":
        module = _load_external_script_module("scripts/run_neurips2026_reference_program.py")
        manifest_path = (
            entry.manifest_path
            if runtime_results_root == entry.results_root.resolve()
            else _make_manifest_with_results_root(entry.manifest_path, results_root=runtime_results_root)
        )
        payload = module.execute_reference_program(
            manifest_path=manifest_path,
            family_ids=dispatch_family_ids or None,
            seeds_override=dispatch_seeds,
            skip_existing=bool(skip_existing),
            dry_run=bool(dry_run),
        )
    else:
        raise InvalidCompositionError(
            f"Suite '{entry.suite_name}' uses unsupported runner_type '{entry.runner_type}'."
        )

    summary = dict(payload.get("summary", {})) if isinstance(payload, Mapping) else {}
    report_path = _suite_runtime_report_path(entry, results_root=runtime_results_root)
    return SuiteRunResult(
        suite_name=entry.suite_name,
        phase=entry.phase,
        runner_type=entry.runner_type,
        depends_on=entry.depends_on,
        launch_manifest_path=str(entry.launch_manifest_path),
        suite_manifest_path=str(entry.manifest_path),
        results_root=str(runtime_results_root),
        used_launch_root=runtime_results_root.resolve() == entry.results_root.resolve(),
        family_ids=tuple(dispatch_family_ids),
        seeds=None if dispatch_seeds is None else tuple(dispatch_seeds),
        max_runs=max_runs,
        skip_existing=bool(skip_existing),
        dry_run=bool(dry_run),
        summary=summary,
        runtime_report_path=str(report_path),
        next_step=f"pinn-bench suite inspect --suite {entry.suite_name}"
        + ("" if runtime_results_root == entry.results_root.resolve() else f" --results-root {runtime_results_root}"),
    )


def _parse_markdown_tables(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    lines = path.read_text(encoding="utf-8").splitlines()
    tables: list[dict[str, Any]] = []
    current_section = ""
    index = 0
    while index < len(lines):
        stripped = lines[index].strip()
        if stripped.startswith("#"):
            current_section = stripped.lstrip("#").strip()
            index += 1
            continue
        if stripped.startswith("|") and index + 1 < len(lines):
            divider = lines[index + 1].strip()
            divider_text = divider.replace("|", "").replace("-", "").replace(":", "").replace(" ", "")
            if divider.startswith("|") and divider_text == "":
                header = [cell.strip() for cell in stripped.strip("|").split("|")]
                index += 2
                rows: list[dict[str, str]] = []
                while index < len(lines) and lines[index].strip().startswith("|"):
                    values = [cell.strip() for cell in lines[index].strip().strip("|").split("|")]
                    if len(values) < len(header):
                        values.extend([""] * (len(header) - len(values)))
                    rows.append({header[pos]: values[pos] for pos in range(len(header))})
                    index += 1
                tables.append({"section": current_section, "rows": rows})
                continue
        index += 1
    return tables


def _normalize_markdown_token(value: str) -> str:
    return str(value).strip().strip("`")


def _canonical_figure_signal(value: str | None) -> str | None:
    if value in {None, ""}:
        return None
    normalized = str(value).strip().lower()
    aliases = {
        "partial_real_results": "real_results_available",
        "scaffold_only": "not_applicable",
    }
    return aliases.get(normalized, normalized)


def _canonical_claim_signal(value: str | None) -> str | None:
    if value in {None, ""}:
        return None
    normalized = str(value).strip().lower()
    aliases = {
        "claim_strengthened": "supporting_contract_complete",
    }
    return aliases.get(normalized, normalized)


def _load_claim_rows(claim_log_path: Path) -> list[dict[str, str]]:
    merged_rows: dict[str, dict[str, str]] = {}
    order: list[str] = []
    for table in _parse_markdown_tables(claim_log_path):
        if not table["rows"] or "claim_id" not in table["rows"][0]:
            continue
        for row in table["rows"]:
            normalized = {
                key: (_normalize_markdown_token(value) if key == "claim_id" else value)
                for key, value in row.items()
            }
            claim_id = str(normalized.get("claim_id", "")).strip()
            if not claim_id:
                continue
            if claim_id not in order:
                order.append(claim_id)
            merged_rows[claim_id] = normalized
    return [merged_rows[claim_id] for claim_id in order]


def _load_figure_rows(figure_inventory_path: Path, *, suite_name: str) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for table in _parse_markdown_tables(figure_inventory_path):
        for row in table["rows"]:
            if _normalize_markdown_token(row.get("suite_name", "")) == suite_name:
                rows.append(
                    {
                        "section": str(table["section"]),
                        **{
                            key: (_normalize_markdown_token(value) if key in {"suite_name", "figure_id"} else value)
                            for key, value in row.items()
                        },
                    }
                )
    return rows


def _load_figure_spec_rows(figure_spec_path: Path) -> list[dict[str, Any]]:
    if not figure_spec_path.exists():
        return []
    rows: list[dict[str, Any]] = []
    current_section = ""
    current_row: dict[str, Any] | None = None
    expect_artifact_paths = False
    for raw_line in figure_spec_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.rstrip()
        stripped = line.strip()
        indent = len(line) - len(line.lstrip(" "))
        if stripped.startswith("#"):
            current_section = stripped.lstrip("#").strip()
            continue
        if indent == 0 and stripped.startswith("- `") and stripped.endswith("`"):
            if current_row is not None:
                rows.append(current_row)
            current_row = {
                "figure_id": _normalize_markdown_token(stripped.removeprefix("- ").strip()),
                "section": current_section,
                "source": "figure_spec",
                "artifact_paths": [],
            }
            expect_artifact_paths = False
            continue
        if current_row is None:
            continue
        if stripped.startswith("- purpose:"):
            current_row["purpose"] = stripped.split(":", 1)[1].strip()
            continue
        if stripped.startswith("- current status:"):
            current_row["status"] = _normalize_markdown_token(stripped.split(":", 1)[1].strip())
            continue
        if stripped.startswith("- current artifact:"):
            expect_artifact_paths = True
            continue
        if expect_artifact_paths and indent > 0 and stripped.startswith("- "):
            current_row.setdefault("artifact_paths", []).append(
                _normalize_markdown_token(stripped.removeprefix("- ").strip())
            )
            continue
        expect_artifact_paths = False
    if current_row is not None:
        rows.append(current_row)
    return rows


def _normalize_claim_tone(status: str) -> str:
    normalized = _canonical_claim_signal(status) or ""
    if normalized == "claim_ready":
        return "hard"
    if normalized == "supporting_contract_complete":
        return "bounded"
    if normalized in {"partial_real_results", "bounded_only", "partial"}:
        return "bounded"
    return "not_yet"


def _build_claim_registry_entries(claim_rows: Sequence[Mapping[str, str]]) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for row in claim_rows:
        evidence_sources = []
        for key in ("backing_table", "backing_figure"):
            value = row.get(key)
            if value:
                evidence_sources.append(str(value))
        status = _canonical_claim_signal(row.get("status")) or ""
        entries.append(
            {
                "claim_id": str(row.get("claim_id", "")).strip(),
                "status": status,
                "result_polarity": None if not row.get("result_polarity") else str(row.get("result_polarity")),
                "coverage_fraction": None
                if row.get("coverage_fraction") in {None, ""}
                else float(row.get("coverage_fraction")),
                "target_claim": None if not row.get("target_claim") else str(row.get("target_claim")),
                "backing_table": None if not row.get("backing_table") else str(row.get("backing_table")),
                "backing_figure": None if not row.get("backing_figure") else str(row.get("backing_figure")),
                "boundary_wording": None if not row.get("boundary_wording") else str(row.get("boundary_wording")),
                "risk_note": None if not row.get("risk_note") else str(row.get("risk_note")),
                "recommended_tone": _normalize_claim_tone(status),
                "evidence_sources": evidence_sources,
                "main_text_relevant": status in {"claim_ready", "partial_real_results"},
                "provenance": ["claim_log_md"],
            }
        )
    return entries


def _figure_related_claim_ids(
    *,
    artifact_paths: Sequence[str],
    claim_rows: Sequence[Mapping[str, str]],
) -> list[str]:
    if not artifact_paths:
        return []
    related: list[str] = []
    basenames = {Path(path).name for path in artifact_paths}
    for row in claim_rows:
        backing_figure = str(row.get("backing_figure", ""))
        if any(name and name in backing_figure for name in basenames):
            claim_id = str(row.get("claim_id", "")).strip()
            if claim_id and claim_id not in related:
                related.append(claim_id)
    return related


def _materialization_state_for_paths(paths: Sequence[str]) -> str:
    if not paths:
        return "declared_only"
    resolved = [Path(path) for path in paths]
    if all(path.exists() for path in resolved):
        return "materialized"
    if any(path.exists() for path in resolved):
        return "partially_materialized"
    return "declared_missing"


def _build_figure_registry_entries(
    *,
    figure_rows: Sequence[Mapping[str, str]],
    figure_spec_rows: Sequence[Mapping[str, Any]],
    claim_rows: Sequence[Mapping[str, str]],
) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    seen_keys: set[tuple[str, str]] = set()

    for row in figure_rows:
        figure_id = str(row.get("figure_id", "")).strip()
        key = ("figure_inventory", figure_id)
        if not figure_id or key in seen_keys:
            continue
        seen_keys.add(key)
        status = _canonical_figure_signal(row.get("status"))
        evidence_state = _canonical_figure_signal(row.get("evidence_state"))
        entries.append(
            {
                "figure_id": figure_id,
                "source": "figure_inventory",
                "status": status,
                "evidence_state": evidence_state,
                "candidate_status": status or evidence_state,
                "section": None if row.get("section") in {None, ""} else str(row.get("section")),
                "claim_supported": None if row.get("claim_supported") in {None, ""} else str(row.get("claim_supported")),
                "note": None if row.get("drop_reason") in {None, ""} else str(row.get("drop_reason")),
                "purpose": None,
                "artifact_paths": [],
                "materialization_state": "declared_only",
                "provenance": ["figure_inventory_master_md"],
                "related_claim_ids": [],
                "warnings": [],
            }
        )

    for row in figure_spec_rows:
        figure_id = str(row.get("figure_id", "")).strip()
        key = ("figure_spec", figure_id)
        if not figure_id or key in seen_keys:
            continue
        seen_keys.add(key)
        artifact_paths = [str(path) for path in row.get("artifact_paths", [])]
        status = _canonical_figure_signal(row.get("status"))
        entries.append(
            {
                "figure_id": figure_id,
                "source": "figure_spec",
                "status": status,
                "evidence_state": None,
                "candidate_status": status,
                "section": None if row.get("section") in {None, ""} else str(row.get("section")),
                "claim_supported": None,
                "note": None,
                "purpose": None if row.get("purpose") in {None, ""} else str(row.get("purpose")),
                "artifact_paths": artifact_paths,
                "materialization_state": _materialization_state_for_paths(artifact_paths),
                "provenance": ["figure_spec_md"],
                "related_claim_ids": _figure_related_claim_ids(artifact_paths=artifact_paths, claim_rows=claim_rows),
                "warnings": [],
            }
        )

    return entries


def _supporting_figure_registry_entries(*, suite_name: str, suite_dir: Path) -> list[dict[str, Any]]:
    tranche_specs = {
        "small_sample_inverse_suite": {
            "figure_id": "sparsity_degradation_curve_canonical_tranche1",
            "figure_png": "small_sample_inverse_suite__figure_sparse_curve_canonical_tranche1.png",
            "claim_id": "SSI-T1-1",
            "claim_supported": "canonical_tranche1_partial_coverage",
            "section": "Canonical Tranche-1 Figures",
            "source": "supporting_suite_tranche1",
            "status": "figure_candidate",
            "candidate_status": "figure_candidate",
            "evidence_state": "real_results_available",
            "note": "Canonical tranche-1 supporting figure generated from real new results.",
            "purpose": "show first real canonical tranche-1 supporting evidence",
        },
        "noisy_inverse_suite": {
            "figure_id": "noise_degradation_curve_canonical_tranche1",
            "figure_png": "noisy_inverse_suite__figure_noise_curve_canonical_tranche1.png",
            "claim_id": "NI-T1-1",
            "claim_supported": "canonical_tranche1_partial_coverage",
            "section": "Canonical Tranche-1 Figures",
            "source": "supporting_suite_tranche1",
            "status": "figure_candidate",
            "candidate_status": "figure_candidate",
            "evidence_state": "real_results_available",
            "note": "Canonical tranche-1 supporting figure generated from real new results.",
            "purpose": "show first real canonical tranche-1 supporting evidence",
        },
        "sparse_noise_joint_grid": {
            "figure_id": "local_heatmap_canonical_tranche1",
            "figure_png": "sparse_noise_joint_grid__figure_local_heatmap_canonical_tranche1.png",
            "claim_id": "JG-T1-1",
            "claim_supported": "canonical_tranche1_partial_coverage",
            "section": "Canonical Tranche-1 Figures",
            "source": "supporting_suite_tranche1",
            "status": "figure_candidate",
            "candidate_status": "figure_candidate",
            "evidence_state": "real_results_available",
            "note": "Canonical tranche-1 supporting figure generated from real new results.",
            "purpose": "show first real canonical tranche-1 supporting evidence",
        },
    }
    full20_specs = {
        "small_sample_inverse_suite": {
            "figure_id": "sparsity_degradation_curve_canonical_full20",
            "figure_png": "small_sample_inverse_suite__figure_sparse_curve_canonical_full20.png",
            "claim_id": "SSI-F20-1",
            "claim_supported": "canonical_full20_completed_supporting_surface",
            "section": "Canonical Full20 Figures",
            "source": "supporting_suite_full20",
            "status": "main_text_candidate",
            "candidate_status": "figure_candidate",
            "evidence_state": "real_results_available",
            "note": "Canonical full20 supporting figure generated from real new results.",
            "purpose": "show real canonical full20 supporting evidence",
        },
        "noisy_inverse_suite": {
            "figure_id": "noise_degradation_curve_canonical_full20",
            "figure_png": "noisy_inverse_suite__figure_noise_curve_canonical_full20.png",
            "claim_id": "NI-F20-1",
            "claim_supported": "canonical_full20_completed_supporting_surface",
            "section": "Canonical Full20 Figures",
            "source": "supporting_suite_full20",
            "status": "main_text_candidate",
            "candidate_status": "figure_candidate",
            "evidence_state": "real_results_available",
            "note": "Canonical full20 supporting figure generated from real new results.",
            "purpose": "show real canonical full20 supporting evidence",
        },
        "sparse_noise_joint_grid": {
            "figure_id": "local_heatmap_canonical_full20",
            "figure_png": "sparse_noise_joint_grid__figure_local_heatmap_canonical_full20.png",
            "claim_id": "JG-F20-1",
            "claim_supported": "canonical_full20_completed_supporting_surface",
            "section": "Canonical Full20 Figures",
            "source": "supporting_suite_full20",
            "status": "main_text_candidate",
            "candidate_status": "figure_candidate",
            "evidence_state": "real_results_available",
            "note": "Canonical full20 supporting figure generated from real new results.",
            "purpose": "show real canonical full20 supporting evidence",
        },
    }

    entries: list[dict[str, Any]] = []
    for specs in (tranche_specs.get(suite_name), full20_specs.get(suite_name)):
        if not specs:
            continue
        figure_path = suite_dir / "figures" / specs["figure_png"]
        if not figure_path.exists():
            continue
        entries.append(
            {
                "figure_id": specs["figure_id"],
                "source": specs["source"],
                "status": specs["status"],
                "evidence_state": specs["evidence_state"],
                "candidate_status": specs["candidate_status"],
                "section": specs["section"],
                "claim_supported": specs["claim_supported"],
                "note": specs["note"],
                "purpose": specs["purpose"],
                "artifact_paths": [str(figure_path.resolve())],
                "materialization_state": _materialization_state_for_paths([str(figure_path.resolve())]),
                "provenance": [specs["source"]],
                "related_claim_ids": [specs["claim_id"]],
                "warnings": ["supporting_only_not_second_board"],
            }
        )
    return entries


def _write_registry_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def materialize_suite_registries(
    *,
    suite_name: str,
    launch_manifest_path: str | Path | None = None,
) -> dict[str, str]:
    entry = get_suite_entry(suite_name, launch_manifest_path=launch_manifest_path)
    suite_dir = suite_dir_path(suite_name=entry.suite_name)
    execution_dir = execution_dir_path()
    figure_rows = _load_figure_rows(execution_dir / "figure_inventory_master.md", suite_name=entry.suite_name)
    figure_spec_rows = _load_figure_spec_rows(suite_dir / "figure_spec.md")
    claim_rows = _load_claim_rows(suite_dir / "claim_log.md")

    figure_entries = _build_figure_registry_entries(
        figure_rows=figure_rows,
        figure_spec_rows=figure_spec_rows,
        claim_rows=claim_rows,
    )
    existing_figure_path = _figure_registry_path(suite_dir)
    if existing_figure_path.exists():
        try:
            existing_entries = _load_registry_entries(
                existing_figure_path,
                expected_schema=FIGURE_REGISTRY_SCHEMA_VERSION,
                suite_name=entry.suite_name,
            )
        except Exception:
            existing_entries = []
        else:
            protected_entries = [
                dict(row)
                for row in existing_entries
                if str(row.get("source", "")).strip() not in {"figure_inventory", "figure_spec"}
            ]
            seen_ids = {str(item.get("figure_id", "")) for item in figure_entries}
            for row in protected_entries:
                figure_id = str(row.get("figure_id", "")).strip()
                if figure_id and figure_id not in seen_ids:
                    figure_entries.append(dict(row))
                    seen_ids.add(figure_id)
    for row in _supporting_figure_registry_entries(suite_name=entry.suite_name, suite_dir=suite_dir):
        figure_id = str(row.get("figure_id", "")).strip()
        if figure_id and figure_id not in {str(item.get("figure_id", "")) for item in figure_entries}:
            figure_entries.append(row)

    figure_registry = {
        "schema_version": FIGURE_REGISTRY_SCHEMA_VERSION,
        "suite_name": entry.suite_name,
        "source_priority": [
            "machine_readable_registry",
            "execution_control_board",
            "descriptive_suite_docs",
            "materialized_files",
        ],
        "entries": figure_entries,
    }
    claim_registry = {
        "schema_version": CLAIM_REGISTRY_SCHEMA_VERSION,
        "suite_name": entry.suite_name,
        "source_priority": [
            "machine_readable_registry",
            "descriptive_suite_docs",
        ],
        "entries": _build_claim_registry_entries(claim_rows),
    }

    figure_path = _figure_registry_path(suite_dir)
    claim_path = _claim_registry_path(suite_dir)
    _write_registry_json(figure_path, figure_registry)
    _write_registry_json(claim_path, claim_registry)
    return {
        "figure_registry_path": str(figure_path.resolve()),
        "claim_registry_path": str(claim_path.resolve()),
    }


def _load_registry_entries(path: Path, *, expected_schema: str, suite_name: str) -> list[dict[str, Any]]:
    payload = _read_json(path)
    if str(payload.get("schema_version", "")).strip() != expected_schema:
        raise ValueError(f"Registry '{path}' has unsupported schema_version.")
    if str(payload.get("suite_name", "")).strip() != suite_name:
        raise ValueError(f"Registry '{path}' belongs to a different suite.")
    entries = payload.get("entries")
    if not isinstance(entries, list):
        raise ValueError(f"Registry '{path}' must contain an entries list.")
    return [dict(entry) for entry in entries if isinstance(entry, Mapping)]


def _load_inventory_row(real_result_inventory_path: Path, *, suite_name: str) -> dict[str, str] | None:
    for table in _parse_markdown_tables(real_result_inventory_path):
        for row in table["rows"]:
            if _normalize_markdown_token(row.get("suite", "")) == suite_name:
                return {
                    key: (_normalize_markdown_token(value) if key == "suite" else value)
                    for key, value in row.items()
                }
    return None


def _suite_runtime_report_path(entry: SuiteLaunchEntry, *, results_root: Path) -> Path:
    return results_root / "_matrix_runs" / f"{entry.manifest_path.stem}_run_report.json"


def _infer_evidence_scope(
    *,
    runner_type: str,
    inventory_row: Mapping[str, str] | None,
    status_row: Mapping[str, str],
) -> str | None:
    candidates = []
    for source in (inventory_row or {}, status_row):
        note = str(source.get("notes", "")).lower()
        if "full native suite" in note or "full suite" in note:
            candidates.append("full_suite")
        elif "focal shell" in note or "focal sparse" in note or "focal noisy" in note:
            candidates.append("focal_slice")
        elif "local joint grid" in note or "local real grid" in note or "3x3 heatmap" in note:
            candidates.append("local_grid")
        elif "representative context" in note or "representative-task" in note:
            candidates.append("representative_context")
        elif "transfer path" in note or "one path" in note:
            candidates.append("minimal_path")
    if candidates:
        return candidates[0]
    fallback = {
        "native_matrix": "suite_or_slice",
        "transfer_program": "minimal_path",
        "reference_program": "representative_context",
    }
    return fallback.get(runner_type)


def _resolve_maturity(
    *,
    status_row: Mapping[str, str],
    inventory_row: Mapping[str, str] | None,
    runner_type: str,
    runtime_report_exists: bool,
    runtime_summary: Mapping[str, Any],
    projection_index_exists: bool,
    figure_entries: Sequence[SuiteFigure],
    claim_entries: Sequence[SuiteClaim],
    warnings: Sequence[str],
    boundedness_notes: Sequence[str],
) -> SuiteMaturity:
    evidence_scope = _infer_evidence_scope(
        runner_type=runner_type,
        inventory_row=inventory_row,
        status_row=status_row,
    )
    derived_figure_state = None
    for target in ("figure_ready", "main_text_candidate", "figure_candidate"):
        if any(
            (_canonical_figure_signal(figure.status) or "") == target
            or (_canonical_figure_signal(figure.evidence_state) or "") == target
            or (_canonical_figure_signal(figure.candidate_status) or "") == target
            for figure in figure_entries
        ):
            derived_figure_state = target
            break
    if derived_figure_state is None and figure_entries:
        derived_figure_state = "projected_to_artifacts"

    derived_claim_state = None
    for target in ("claim_ready", "supporting_contract_complete", "partial_real_results", "blocked_by_contract_gap"):
        if any((_canonical_claim_signal(claim.status) or "") == target for claim in claim_entries):
            derived_claim_state = target
            break
    if derived_claim_state is None and claim_entries:
        derived_claim_state = "scaffold_only"

    derived_projection_state = "projected_to_artifacts" if projection_index_exists else None
    succeeded = int(runtime_summary.get("total_runs_succeeded", 0) or 0)
    failed = int(runtime_summary.get("total_runs_failed", 0) or 0)
    skipped = int(runtime_summary.get("total_runs_skipped", 0) or 0)
    attempted = int(runtime_summary.get("total_runs_attempted", 0) or 0)
    planned = int(runtime_summary.get("total_runs_planned", 0) or 0)
    covered = attempted + skipped

    if not runtime_report_exists:
        derived_execution_state = "scaffold_only"
    elif attempted == 0 and succeeded == 0 and skipped == 0 and planned > 0:
        derived_execution_state = "dry_run_only"
    elif planned > 0 and covered >= planned and failed == 0 and succeeded > 0:
        derived_execution_state = "real_results_available"
    elif succeeded > 0 or skipped > 0:
        derived_execution_state = "partial_real_results"
    elif failed > 0:
        derived_execution_state = "real_run_started"
    else:
        derived_execution_state = "real_run_started"

    derived_main_text_candidate = any(
        (_canonical_figure_signal(figure.status) or "") in {"main_text_candidate", "selected"}
        or (_canonical_figure_signal(figure.evidence_state) or "") in {"main_text_candidate", "figure_ready"}
        for figure in figure_entries
    )

    for field_name, derived_value, board_value in (
        ("execution_state", derived_execution_state, str(status_row.get("execution_state", "")).strip().lower() or None),
        ("projection_state", derived_projection_state, str(status_row.get("projection_state", "")).strip().lower() or None),
        (
            "figure_state",
            derived_figure_state,
            _canonical_figure_signal(str(status_row.get("figure_state", "")).strip().lower() or None),
        ),
        (
            "claim_state",
            derived_claim_state,
            _canonical_claim_signal(str(status_row.get("claim_state", "")).strip().lower() or None),
        ),
    ):
        if board_value and derived_value and board_value != derived_value:
            # keep warnings small and actionable
            extra = f"Derived {field_name}='{derived_value}' differs from control-board value '{board_value}'."
            if extra not in warnings:
                warnings = tuple(list(warnings) + [extra])

    boundedness = None if not boundedness_notes else " | ".join(dict.fromkeys(str(note) for note in boundedness_notes))
    return SuiteMaturity(
        execution_state=derived_execution_state,
        projection_state=derived_projection_state,
        figure_state=derived_figure_state,
        claim_state=derived_claim_state,
        main_text_candidate=derived_main_text_candidate,
        evidence_scope=evidence_scope,
        boundedness=boundedness,
        warnings=tuple(str(warning) for warning in warnings),
    )


def _build_truth_trace(
    *,
    execution_dir: Path,
    suite_dir: Path,
    report_json_path: Path,
) -> SuiteTruthTrace:
    return SuiteTruthTrace(
        hierarchy_version=SUITE_TRUTH_VERSION,
        source_priority=SUITE_TRUTH_HIERARCHY,
        runtime_source="runtime_artifacts",
        maturity_source="derived(runtime_artifacts + machine_readable_registries, reconciled_with_execution_control_board)",
        figures_source="machine_readable_figure_registry -> suite_local_projected_artifacts",
        claims_source="machine_readable_claim_registry",
        boundedness_sources=("machine_readable_claim_registry", "machine_readable_figure_registry", "execution_control_board", "runtime_artifacts"),
        source_files={
            "suite_status_board": str((execution_dir / "suite_status_board.csv").resolve()),
            "real_result_inventory": str((execution_dir / "real_result_inventory.md").resolve()),
            "figure_inventory_master": str((execution_dir / "figure_inventory_master.md").resolve()),
            "runtime_report": str(report_json_path.resolve()),
            "figure_registry": str(_figure_registry_path(suite_dir).resolve()),
            "claim_registry": str(_claim_registry_path(suite_dir).resolve()),
            "claim_log": str((suite_dir / "claim_log.md").resolve()),
            "figure_spec": str((suite_dir / "figure_spec.md").resolve()),
            "projection_index": str((suite_dir / "projection_index.json").resolve()),
        },
    )


def _append_consistency_warnings(
    *,
    status_row: Mapping[str, str],
    runtime_report_exists: bool,
    runtime_summary: Mapping[str, Any],
    figure_entries: Sequence[SuiteFigure],
    claim_entries: Sequence[SuiteClaim],
    warnings: list[str],
) -> None:
    execution_state = str(status_row.get("execution_state", "")).strip().lower()
    if execution_state in {"real_results_available", "partial_real_results"} and not runtime_report_exists:
        warnings.append(
            "Execution control state says results exist, but the runtime report is missing."
        )
    if runtime_report_exists and runtime_summary.get("total_runs_succeeded", 0) == 0 and execution_state == "real_results_available":
        warnings.append(
            "Execution control state says real_results_available, but the runtime report shows zero succeeded runs."
        )

    figure_state = _canonical_figure_signal(str(status_row.get("figure_state", "")).strip().lower() or None) or ""
    has_candidate_like_figure = any(
        (_canonical_figure_signal(figure.status) or "") in {"selected", "main_text_candidate", "figure_ready", "figure_candidate"}
        or (_canonical_figure_signal(figure.evidence_state) or "") in {"main_text_candidate", "figure_ready", "figure_candidate"}
        for figure in figure_entries
    )
    if figure_state in {"figure_ready", "main_text_candidate", "figure_candidate"} and not has_candidate_like_figure:
        warnings.append(
            "Figure state indicates candidate material, but no matching figure entries were assembled."
        )

    claim_state = _canonical_claim_signal(str(status_row.get("claim_state", "")).strip().lower() or None) or ""
    if claim_state in {"claim_ready", "supporting_contract_complete", "partial_real_results"} and not claim_entries:
        warnings.append(
            "Claim state indicates usable claim material, but no claim rows were assembled."
        )


def inspect_suite_summary(
    *,
    suite_name: str,
    launch_manifest_path: str | Path | None = None,
    results_root: str | Path | None = None,
    use_launch_root: bool = False,
) -> SuiteSummary:
    """Return one unified structured suite summary."""
    entry = get_suite_entry(suite_name, launch_manifest_path=launch_manifest_path)
    runtime_results_root = _resolve_runtime_results_root(
        entry,
        results_root=results_root,
        use_launch_root=use_launch_root,
        prefer_existing_user_root=True,
    )
    suite_dir = suite_dir_path(suite_name=entry.suite_name)
    execution_dir = execution_dir_path()
    staging_root = staging_root_path()
    figure_registry_path = _figure_registry_path(suite_dir)
    claim_registry_path = _claim_registry_path(suite_dir)

    status_rows = {
        row["suite_name"]: row
        for row in _read_csv_rows(execution_dir / "suite_status_board.csv")
    }
    status_row = dict(status_rows.get(entry.suite_name, {}))
    inventory_row = _load_inventory_row(execution_dir / "real_result_inventory.md", suite_name=entry.suite_name)
    if not figure_registry_path.exists() or not claim_registry_path.exists():
        materialize_suite_registries(suite_name=entry.suite_name, launch_manifest_path=launch_manifest_path)
    figure_registry_entries = _load_registry_entries(
        figure_registry_path,
        expected_schema=FIGURE_REGISTRY_SCHEMA_VERSION,
        suite_name=entry.suite_name,
    )
    claim_registry_entries = _load_registry_entries(
        claim_registry_path,
        expected_schema=CLAIM_REGISTRY_SCHEMA_VERSION,
        suite_name=entry.suite_name,
    )

    report_json_path = _suite_runtime_report_path(entry, results_root=runtime_results_root)
    runtime_report = _read_json(report_json_path) if report_json_path.exists() else None
    staged_suite_root = staging_root / entry.suite_name

    figure_files = sorted(str(path.resolve()) for path in (suite_dir / "figures").glob("*") if path.is_file())
    note_files = sorted(str(path.resolve()) for path in (suite_dir / "notes").glob("*") if path.is_file())
    table_files = sorted(str(path.resolve()) for path in (suite_dir / "tables").glob("*") if path.is_file())

    warnings: list[str] = []
    boundedness_notes: list[str] = []
    for note in (status_row.get("notes"), None if inventory_row is None else inventory_row.get("notes")):
        if note:
            boundedness_notes.append(str(note))
    if not runtime_results_root.exists():
        warnings.append(f"Results root does not exist yet: {runtime_results_root}")
    if not report_json_path.exists():
        warnings.append(f"Runtime report does not exist yet: {report_json_path}")

    figure_entries = [
        SuiteFigure(
            figure_id=str(row.get("figure_id", "")),
            source=str(row.get("source", "figure_registry")),
            status=_canonical_figure_signal(row.get("status")),
            evidence_state=_canonical_figure_signal(row.get("evidence_state")),
            section=None if row.get("section") in {None, ""} else str(row.get("section")),
            claim_supported=None if row.get("claim_supported") in {None, ""} else str(row.get("claim_supported")),
            purpose=None if row.get("purpose") in {None, ""} else str(row.get("purpose")),
            artifact_paths=tuple(str(path) for path in row.get("artifact_paths", [])),
            note=None if row.get("note") in {None, ""} else str(row.get("note")),
            materialization_state=None
            if row.get("materialization_state") in {None, ""}
            else str(row.get("materialization_state")),
            candidate_status=_canonical_figure_signal(row.get("candidate_status")),
            provenance=tuple(str(item) for item in row.get("provenance", [])),
            related_claim_ids=tuple(str(item) for item in row.get("related_claim_ids", [])),
            warnings=tuple(str(item) for item in row.get("warnings", [])),
        )
        for row in figure_registry_entries
    ]

    claim_entries = [
        SuiteClaim(
            claim_id=str(row.get("claim_id", "")),
            status=_canonical_claim_signal(row.get("status")) or "",
            result_polarity=None if row.get("result_polarity") in {None, ""} else str(row.get("result_polarity")),
            coverage_fraction=None
            if row.get("coverage_fraction") in {None, ""}
            else float(row.get("coverage_fraction")),
            target_claim=None if row.get("target_claim") in {None, ""} else str(row.get("target_claim")),
            backing_table=None if row.get("backing_table") in {None, ""} else str(row.get("backing_table")),
            backing_figure=None if row.get("backing_figure") in {None, ""} else str(row.get("backing_figure")),
            boundary_wording=None if row.get("boundary_wording") in {None, ""} else str(row.get("boundary_wording")),
            risk_note=None if row.get("risk_note") in {None, ""} else str(row.get("risk_note")),
            recommended_tone=None if row.get("recommended_tone") in {None, ""} else str(row.get("recommended_tone")),
            evidence_sources=tuple(str(item) for item in row.get("evidence_sources", [])),
            main_text_relevant=bool(row.get("main_text_relevant", False)),
            provenance=tuple(str(item) for item in row.get("provenance", [])),
        )
        for row in claim_registry_entries
    ]

    runtime_summary = {} if runtime_report is None else dict(runtime_report.get("summary", {}))
    _append_consistency_warnings(
        status_row=status_row,
        runtime_report_exists=report_json_path.exists(),
        runtime_summary=runtime_summary,
        figure_entries=figure_entries,
        claim_entries=claim_entries,
        warnings=warnings,
    )

    maturity = _resolve_maturity(
        status_row=status_row,
        inventory_row=inventory_row,
        runner_type=entry.runner_type,
        runtime_report_exists=report_json_path.exists(),
        runtime_summary=runtime_summary,
        projection_index_exists=(suite_dir / "projection_index.json").exists(),
        figure_entries=figure_entries,
        claim_entries=claim_entries,
        warnings=warnings,
        boundedness_notes=tuple(dict.fromkeys(boundedness_notes)),
    )
    key_files = SuiteKeyFiles(
        suite_dir=str(suite_dir),
        results_root=str(runtime_results_root),
        runtime_report_path=str(report_json_path),
        runbook_path=str(entry.runbook_path),
        gate_spec_path=str(entry.gate_spec_path),
        claim_log_path=str((suite_dir / "claim_log.md").resolve()),
        figure_spec_path=str((suite_dir / "figure_spec.md").resolve()),
        artifact_spec_path=str((suite_dir / "artifact_spec.md").resolve()),
        projection_index_path=str((suite_dir / "projection_index.json").resolve()),
        staging_root=str(staged_suite_root.resolve()),
        work_order_path=str((suite_dir / "work_order.md").resolve()),
        figure_registry_path=str(figure_registry_path.resolve()),
        claim_registry_path=str(claim_registry_path.resolve()),
    )
    truth_trace = _build_truth_trace(
        execution_dir=execution_dir,
        suite_dir=suite_dir,
        report_json_path=report_json_path,
    )

    return SuiteSummary(
        suite_name=entry.suite_name,
        phase=entry.phase,
        runner_type=entry.runner_type,
        depends_on=entry.depends_on,
        maturity=maturity,
        key_files=key_files,
        truth_trace=truth_trace,
        results_root_exists=runtime_results_root.exists(),
        used_launch_root=runtime_results_root.resolve() == entry.results_root.resolve(),
        runtime_report_exists=report_json_path.exists(),
        runtime_summary=runtime_summary,
        launch_manifest_path=str(entry.launch_manifest_path),
        suite_manifest_path=str(entry.manifest_path),
        figures=tuple(figure_entries),
        claims=tuple(claim_entries),
        materialized_figure_files=tuple(figure_files),
        materialized_table_files=tuple(table_files),
        materialized_note_files=tuple(note_files),
    )


def inspect_suite(
    *,
    suite_name: str,
    launch_manifest_path: str | Path | None = None,
    results_root: str | Path | None = None,
    use_launch_root: bool = False,
) -> dict[str, Any]:
    """Backward-compatible dict view of the suite summary."""
    return inspect_suite_summary(
        suite_name=suite_name,
        launch_manifest_path=launch_manifest_path,
        results_root=results_root,
        use_launch_root=use_launch_root,
    ).to_dict()


def format_suite_list(entries: Sequence[dict[str, Any]]) -> str:
    """Format suite catalog rows for human-readable output."""
    lines = []
    for entry in entries:
        lines.append(
            f"{entry['suite_name']} (phase={entry['phase']}, runner={entry['runner_type']}, "
            f"default_results_root={entry['default_results_root']})"
        )
    return "\n".join(lines)


def format_suite_run_summary(payload: Mapping[str, Any] | SuiteRunResult) -> str:
    """Format a run payload into a concise human-readable summary."""
    if isinstance(payload, SuiteRunResult):
        payload_mapping = payload.to_dict()
    else:
        payload_mapping = dict(payload)
    summary = dict(payload_mapping.get("summary", {}))
    lines = [
        f"suite={payload_mapping['suite_name']}",
        f"runner_type={payload_mapping['runner_type']}",
        f"results_root={payload_mapping['results_root']}",
        (
            "planned={planned} attempted={attempted} succeeded={succeeded} failed={failed} skipped={skipped}".format(
                planned=summary.get("total_runs_planned", 0),
                attempted=summary.get("total_runs_attempted", 0),
                succeeded=summary.get("total_runs_succeeded", 0),
                failed=summary.get("total_runs_failed", 0),
                skipped=summary.get("total_runs_skipped", 0),
            )
            if summary
            else "summary=<unavailable>"
        ),
        f"runtime_report={payload_mapping.get('runtime_report_path')}",
        f"next_step={payload_mapping['next_step']}",
    ]
    return "\n".join(lines)


def format_suite_inspect_summary(payload: Mapping[str, Any] | SuiteSummary) -> str:
    """Format one inspect payload for human-readable output."""
    if isinstance(payload, SuiteSummary):
        summary = payload
        figures = list(summary.figures)
        claims = list(summary.claims)
    else:
        payload_dict = dict(payload)
        summary = None
        figures = list(payload_dict.get("figures", []))
        claims = list(payload_dict.get("claims", []))

    lines = [
        f"suite={(summary.suite_name if summary else payload_dict.get('suite_name'))}",
        f"runner_type={(summary.runner_type if summary else payload_dict.get('runner_type'))}",
        f"results_root={(summary.results_root if summary else payload_dict.get('results_root'))}",
        f"execution_state={(summary.execution_state if summary else payload_dict.get('execution_state') or '<unknown>')}",
        f"figure_state={(summary.figure_state if summary else payload_dict.get('figure_state') or '<unknown>')}",
        f"claim_state={(summary.claim_state if summary else payload_dict.get('claim_state') or '<unknown>')}",
        f"main_text_candidate={(summary.main_text_candidate if summary else payload_dict.get('main_text_candidate'))}",
        f"evidence_scope={(summary.evidence_scope if summary else payload_dict.get('evidence_scope') or '<unknown>')}",
        f"truth_layer={(summary.truth_trace.hierarchy_version if summary else payload_dict.get('truth_trace', {}).get('hierarchy_version', '<unknown>'))}",
    ]
    runtime_summary = summary.runtime_summary if summary else dict(payload_dict.get("runtime_summary", {}))
    if runtime_summary:
        lines.append(
            "runtime_summary="
            + "planned={planned}, succeeded={succeeded}, failed={failed}, skipped={skipped}".format(
                planned=runtime_summary.get("total_runs_planned", 0),
                succeeded=runtime_summary.get("total_runs_succeeded", 0),
                failed=runtime_summary.get("total_runs_failed", 0),
                skipped=runtime_summary.get("total_runs_skipped", 0),
            )
        )
    if figures:
        lines.append(
            "figure_candidates="
            + ", ".join(
                (
                    f"{figure.figure_id}[{figure.status or figure.evidence_state or 'unknown'}]"
                    if isinstance(figure, SuiteFigure)
                    else f"{figure.get('figure_id')}[{figure.get('status') or figure.get('evidence_state') or 'unknown'}]"
                )
                for figure in figures
            )
        )
    if claims:
        lines.append(
            "claim_statuses="
            + ", ".join(
                (
                    f"{claim.claim_id}[{claim.status}]"
                    if isinstance(claim, SuiteClaim)
                    else f"{claim.get('claim_id')}[{claim.get('status')}]"
                )
                for claim in claims
            )
        )
    boundedness_notes = list(summary.boundedness_notes) if summary else list(payload_dict.get("boundedness_notes", []))
    warnings = list(summary.warnings) if summary else list(payload_dict.get("warnings", []))
    if boundedness_notes:
        lines.append("boundedness=" + " | ".join(boundedness_notes))
    if warnings:
        lines.append("warnings=" + " | ".join(warnings))
    lines.append(f"claim_log={(summary.claim_log_path if summary else payload_dict.get('claim_log_path'))}")
    lines.append(f"runtime_report={(summary.runtime_report_path if summary else payload_dict.get('runtime_report_path'))}")
    return "\n".join(lines)
