"""Native-proxy segmentation task for sciml-bench SLSTR cloud patches."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import (
    BaseTask,
    ConditionBatch,
    EvaluationBatch,
    FieldBatch,
    SampleBatch,
    TrainBatches,
)


def _resolve_dataset_root(raw: str | Path | None) -> Path:
    if raw is None or not str(raw).strip():
        return (
            Path.cwd()
            / "examples"
            / "superbench_v3_preview"
            / "shared_datasets"
            / "slstr_cloud_mask_segmentation_native_proxy_v1"
        ).resolve()
    candidate = Path(str(raw)).expanduser()
    if not candidate.is_absolute():
        candidate = (Path.cwd() / candidate).resolve()
    return candidate


@register_task("slstr_cloud_mask_segmentation")
class SlstrCloudMaskSegmentationTask(BaseTask):
    """Preview-scale image-to-mask segmentation task over static 64x64 patches."""

    task_mode = "field"
    supports_operator = True

    def __init__(
        self,
        input_dim: int = 2,
        output_dim: int = 1,
        dataset_variant: str = "native_proxy_v1",
        dataset_root: str | None = None,
        field_grid: dict[str, int] | None = None,
        **_: Any,
    ) -> None:
        self.input_dim = int(input_dim)
        self.output_dim = int(output_dim)
        if self.input_dim != 2 or self.output_dim != 1:
            raise ValueError("SlstrCloudMaskSegmentationTask expects input_dim=2 and output_dim=1.")
        self.dataset_variant = str(dataset_variant)
        self.dataset_root = _resolve_dataset_root(dataset_root)
        self.field_grid = {
            "grid_x": 64,
            "grid_y": 64,
            **(field_grid or {}),
        }
        self._payload = self._load_payload()

    def _dataset_payload_path(self) -> Path:
        return self.dataset_root / f"{self.dataset_variant}.npz"

    def _load_payload(self) -> dict[str, np.ndarray | str]:
        payload_path = self._dataset_payload_path()
        if not payload_path.exists():
            raise FileNotFoundError(f"Expected SLSTR cloud preview dataset at {payload_path}.")
        loaded = np.load(payload_path, allow_pickle=False)
        x = np.asarray(loaded["x"], dtype=np.float32)
        y = np.asarray(loaded["y"], dtype=np.float32)
        images = np.asarray(loaded["images"], dtype=np.float32)
        masks = np.asarray(loaded["masks"], dtype=np.float32)
        sample_ids = np.asarray(loaded["sample_ids"], dtype=np.int64)
        family_id = str(loaded["family_id"].tolist())
        source_tag = str(loaded["source_tag"].tolist())
        if x.shape != (64,) or y.shape != (64,):
            raise ValueError("SLSTR cloud native proxy expects x/y axes with shape (64,).")
        if images.shape != (2, 64, 64, 9):
            raise ValueError("SLSTR cloud native proxy expects images with shape (2, 64, 64, 9).")
        if masks.shape != (2, 64, 64, 1):
            raise ValueError("SLSTR cloud native proxy expects masks with shape (2, 64, 64, 1).")
        if sample_ids.shape != (2,):
            raise ValueError("SLSTR cloud native proxy expects sample_ids with shape (2,).")
        if int(self.field_grid["grid_x"]) != int(len(x)) or int(self.field_grid["grid_y"]) != int(len(y)):
            raise ValueError("SLSTR cloud native proxy grid does not match the configured field_grid.")
        return {
            "x": x,
            "y": y,
            "images": images,
            "masks": masks,
            "sample_ids": sample_ids,
            "family_id": family_id,
            "source_tag": source_tag,
        }

    @staticmethod
    def _resolve_condition_inputs(batch: SampleBatch, batches: TrainBatches) -> torch.Tensor | None:
        condition_inputs = batch.metadata.get("condition_inputs")
        if condition_inputs is not None:
            return condition_inputs
        condition_batch = batches.metadata.get("condition_batch")
        if isinstance(condition_batch, ConditionBatch):
            return condition_batch.inputs
        if isinstance(condition_batch, dict) and isinstance(condition_batch.get("inputs"), torch.Tensor):
            return condition_batch["inputs"]
        return None

    @staticmethod
    def _predict_field(*, model: torch.nn.Module, batch: SampleBatch, batches: TrainBatches) -> torch.Tensor:
        condition_inputs = SlstrCloudMaskSegmentationTask._resolve_condition_inputs(batch, batches)
        if hasattr(model, "forward_field"):
            predictions = model.forward_field(
                condition_inputs=condition_inputs,
                query_inputs=batch.inputs,
                metadata=batch.metadata,
            )
        elif bool(getattr(model, "supports_flattened_field", False)):
            predictions = model(batch.inputs)
        else:
            raise ValueError("SlstrCloudMaskSegmentationTask requires an operator-ready model.")
        if predictions.shape == batch.targets.shape:
            return predictions
        if predictions.numel() == batch.targets.numel():
            return predictions.reshape_as(batch.targets)
        raise ValueError(
            f"Field prediction shape {tuple(predictions.shape)} does not match targets {tuple(batch.targets.shape)}."
        )

    def _sample_ids(self) -> list[int]:
        raw = self._payload["sample_ids"]
        return [int(value) for value in raw]

    def _build_field_batch(self, *, device: torch.device) -> FieldBatch:
        x = torch.tensor(self._payload["x"], dtype=torch.float32, device=device)
        y = torch.tensor(self._payload["y"], dtype=torch.float32, device=device)
        images = torch.tensor(self._payload["images"], dtype=torch.float32, device=device)
        masks = torch.tensor(self._payload["masks"], dtype=torch.float32, device=device)

        xx, yy = torch.meshgrid(x, y, indexing="xy")
        query_grid = torch.stack([xx.reshape(-1), yy.reshape(-1)], dim=1)
        sample_count = int(images.shape[0])
        grid_y = int(images.shape[1])
        grid_x = int(images.shape[2])
        channel_dim = int(images.shape[3])

        inputs = query_grid.unsqueeze(0).expand(sample_count, -1, -1).reshape(-1, self.input_dim)
        condition_inputs = images.reshape(sample_count * grid_y * grid_x, channel_dim)
        targets = masks.reshape(sample_count * grid_y * grid_x, self.output_dim)
        return FieldBatch(
            inputs=inputs,
            targets=targets,
            condition_inputs=condition_inputs,
            metadata={
                "grid_shape": (grid_y, grid_x),
                "family_batch_size": sample_count,
                "field_shape": (grid_y, grid_x, self.output_dim),
                "family_field_shape": (sample_count, grid_y, grid_x, self.output_dim),
                "condition_shape": tuple(condition_inputs.shape),
                "condition_dim": channel_dim,
                "channel_count": channel_dim,
                "evaluation_mode": "field",
                "task_mode": "field",
                "dataset_variant": self.dataset_variant,
                "dataset_root": str(self.dataset_root),
                "family_id": str(self._payload["family_id"]),
                "source_tag": str(self._payload["source_tag"]),
                "sample_ids": self._sample_ids(),
            },
        )

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        field_batch = self._build_field_batch(device=device)
        condition_batch = ConditionBatch(
            inputs=field_batch.condition_inputs,
            metadata={
                "condition_shape": tuple(field_batch.condition_inputs.shape),
                "condition_dim": field_batch.metadata["condition_dim"],
            },
        )
        supervision = field_batch.to_sample_batch()
        return TrainBatches(
            supervision=supervision,
            metadata={
                "task_name": "slstr_cloud_mask_segmentation",
                "task_mode": "field",
                "grid_shape": supervision.metadata["grid_shape"],
                "family_batch_size": supervision.metadata["family_batch_size"],
                "field_shape": supervision.metadata["field_shape"],
                "family_field_shape": supervision.metadata["family_field_shape"],
                "condition_batch": condition_batch,
                "sample_ids": supervision.metadata["sample_ids"],
                "dataset_variant": self.dataset_variant,
                "family_id": supervision.metadata["family_id"],
            },
        )

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        del num_samples, grid_t
        if grid_x is not None and int(grid_x) != int(self.field_grid["grid_x"]):
            raise ValueError("SlstrCloudMaskSegmentationTask does not support grid_x overrides outside the locked proxy grid.")
        if grid_y is not None and int(grid_y) != int(self.field_grid["grid_y"]):
            raise ValueError("SlstrCloudMaskSegmentationTask does not support grid_y overrides outside the locked proxy grid.")
        field_batch = self._build_field_batch(device=device)
        return EvaluationBatch(
            inputs=field_batch.inputs,
            targets=field_batch.targets,
            name="slstr_cloud_mask_segmentation_native_proxy",
            metadata={
                **field_batch.metadata,
                "condition_inputs": field_batch.condition_inputs,
            },
        )

    def compute_loss_terms(self, model: torch.nn.Module, batches: TrainBatches) -> dict[str, torch.Tensor]:
        batch = batches.supervision
        if batch is None or batch.targets is None:
            raise ValueError("SlstrCloudMaskSegmentationTask requires a supervised field batch with targets.")
        predictions = self._predict_field(model=model, batch=batch, batches=batches)
        return {
            "segmentation_supervision": F.binary_cross_entropy_with_logits(predictions, batch.targets),
        }

    def compute_metric(
        self,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        del model, batch
        if metric_name != "f1":
            return None
        predicted_mask = (torch.sigmoid(predictions) > 0.5).to(dtype=torch.float32)
        target_mask = (targets > 0.5).to(dtype=torch.float32)
        true_positive = torch.sum(predicted_mask * target_mask)
        predicted_positive = torch.sum(predicted_mask)
        target_positive = torch.sum(target_mask)
        denominator = 2.0 * true_positive + (predicted_positive - true_positive) + (target_positive - true_positive)
        if float(denominator.detach().item()) <= 0.0:
            return 1.0
        return float(((2.0 * true_positive) / denominator).detach().item())
