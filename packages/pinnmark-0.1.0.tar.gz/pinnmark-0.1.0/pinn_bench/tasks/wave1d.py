"""Wave 1D task using an analytic standing-wave solution."""

from __future__ import annotations

from math import pi
from typing import Any

import torch
import torch.nn.functional as F

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import BaseTask, EvaluationBatch, SampleBatch, TrainBatches


@register_task("wave1d")
class Wave1DTask(BaseTask):
    """Wave equation benchmark task on a unit interval and unit time horizon."""

    def __init__(
        self,
        input_dim: int = 2,
        output_dim: int = 1,
        domain: dict[str, float] | None = None,
        wave_speed: float = 1.0,
        sampling: dict[str, int] | None = None,
        **_: Any,
    ) -> None:
        self.input_dim = int(input_dim)
        self.output_dim = int(output_dim)
        self.domain = {
            "x_min": 0.0,
            "x_max": 1.0,
            "t_min": 0.0,
            "t_max": 1.0,
            **(domain or {}),
        }
        self.wave_speed = float(wave_speed)
        self.sampling = {
            "num_interior": 256,
            "num_boundary": 64,
            "num_initial": 64,
            "num_initial_velocity": 64,
            **(sampling or {}),
        }

        if self.input_dim != 2 or self.output_dim != 1:
            raise ValueError("Wave1DTask expects input_dim=2 and output_dim=1.")

    def _sample_x(self, num_samples: int, device: torch.device, interior: bool = False) -> torch.Tensor:
        epsilon = 1e-6 if interior else 0.0
        return torch.rand((num_samples, 1), device=device) * (
            (self.domain["x_max"] - epsilon) - (self.domain["x_min"] + epsilon)
        ) + (self.domain["x_min"] + epsilon)

    def _sample_t(self, num_samples: int, device: torch.device, include_zero: bool = False) -> torch.Tensor:
        epsilon = 0.0 if include_zero else 1e-6
        return torch.rand((num_samples, 1), device=device) * (
            (self.domain["t_max"] - epsilon) - (self.domain["t_min"] + epsilon)
        ) + (self.domain["t_min"] + epsilon)

    def exact_solution(self, inputs: torch.Tensor) -> torch.Tensor:
        x = inputs[:, :1]
        t = inputs[:, 1:2]
        return torch.sin(pi * x) * torch.cos(self.wave_speed * pi * t)

    def _physics_residual(self, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        interior_inputs = inputs.clone().detach().requires_grad_(True)
        predictions = model(interior_inputs)
        gradients = torch.autograd.grad(
            outputs=predictions,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(predictions),
            create_graph=True,
            retain_graph=True,
        )[0]
        u_x = gradients[:, :1]
        u_t = gradients[:, 1:2]
        second_derivatives = torch.autograd.grad(
            outputs=u_x,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(u_x),
            create_graph=True,
            retain_graph=True,
        )[0]
        u_xx = second_derivatives[:, :1]
        u_tt = torch.autograd.grad(
            outputs=u_t,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(u_t),
            create_graph=True,
            retain_graph=True,
        )[0][:, 1:2]
        return u_tt - (self.wave_speed**2) * u_xx

    def _initial_condition(self, x: torch.Tensor) -> torch.Tensor:
        return torch.sin(pi * x)

    def _initial_velocity_condition(self, inputs: torch.Tensor) -> torch.Tensor:
        return torch.zeros((inputs.shape[0], 1), device=inputs.device, dtype=inputs.dtype)

    def _boundary_diagnostic_batch(self, device: torch.device, num_points: int = 128) -> tuple[torch.Tensor, torch.Tensor]:
        count = max(2, num_points // 2)
        t = torch.linspace(self.domain["t_min"], self.domain["t_max"], steps=count, device=device).reshape(-1, 1)
        left_inputs = torch.cat(
            [torch.full((count, 1), float(self.domain["x_min"]), device=device), t],
            dim=1,
        )
        right_inputs = torch.cat(
            [torch.full((count, 1), float(self.domain["x_max"]), device=device), t],
            dim=1,
        )
        inputs = torch.cat([left_inputs, right_inputs], dim=0)
        targets = torch.zeros((inputs.shape[0], 1), device=device)
        return inputs, targets

    def _initial_diagnostic_batch(self, device: torch.device, num_points: int = 128) -> tuple[torch.Tensor, torch.Tensor]:
        x = torch.linspace(self.domain["x_min"], self.domain["x_max"], steps=max(2, num_points), device=device).reshape(-1, 1)
        t = torch.full((x.shape[0], 1), float(self.domain["t_min"]), device=device)
        inputs = torch.cat([x, t], dim=1)
        return inputs, self._initial_condition(x)

    def _initial_velocity_diagnostic_batch(self, device: torch.device, num_points: int = 128) -> tuple[torch.Tensor, torch.Tensor]:
        x = torch.linspace(self.domain["x_min"], self.domain["x_max"], steps=max(2, num_points), device=device).reshape(-1, 1)
        t = torch.full((x.shape[0], 1), float(self.domain["t_min"]), device=device)
        inputs = torch.cat([x, t], dim=1)
        return inputs, self._initial_velocity_condition(inputs)

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        num_interior = int(self.sampling["num_interior"])
        num_boundary = int(self.sampling["num_boundary"])
        num_initial = int(self.sampling["num_initial"])
        num_initial_velocity = int(self.sampling["num_initial_velocity"])

        interior_inputs = torch.cat(
            [
                self._sample_x(num_interior, device=device, interior=True),
                self._sample_t(num_interior, device=device, include_zero=False),
            ],
            dim=1,
        )

        half_boundary = num_boundary // 2
        left_t = self._sample_t(half_boundary, device=device, include_zero=True)
        right_t = self._sample_t(num_boundary - half_boundary, device=device, include_zero=True)
        left_x = torch.full((half_boundary, 1), float(self.domain["x_min"]), device=device)
        right_x = torch.full((num_boundary - half_boundary, 1), float(self.domain["x_max"]), device=device)
        boundary_inputs = torch.cat(
            [torch.cat([left_x, left_t], dim=1), torch.cat([right_x, right_t], dim=1)],
            dim=0,
        )
        boundary_targets = torch.zeros((num_boundary, 1), device=device)

        initial_x = self._sample_x(num_initial, device=device, interior=False)
        initial_t = torch.full((num_initial, 1), float(self.domain["t_min"]), device=device)
        initial_inputs = torch.cat([initial_x, initial_t], dim=1)
        initial_targets = self._initial_condition(initial_x)

        initial_velocity_x = self._sample_x(num_initial_velocity, device=device, interior=False)
        initial_velocity_t = torch.full((num_initial_velocity, 1), float(self.domain["t_min"]), device=device)
        initial_velocity_inputs = torch.cat([initial_velocity_x, initial_velocity_t], dim=1)
        initial_velocity_targets = self._initial_velocity_condition(initial_velocity_inputs)

        return TrainBatches(
            interior=SampleBatch(inputs=interior_inputs, metadata={"kind": "interior"}),
            boundary=SampleBatch(inputs=boundary_inputs, targets=boundary_targets, metadata={"kind": "boundary"}),
            initial=SampleBatch(inputs=initial_inputs, targets=initial_targets, metadata={"kind": "initial"}),
            initial_velocity=SampleBatch(
                inputs=initial_velocity_inputs,
                targets=initial_velocity_targets,
                metadata={"kind": "initial_velocity"},
            ),
            supervision=None,
            metadata={"task_name": "wave1d", "wave_speed": self.wave_speed},
        )

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        del num_samples, grid_y
        resolved_grid_x = int(grid_x or 128)
        resolved_grid_t = int(grid_t or 64)

        x = torch.linspace(self.domain["x_min"], self.domain["x_max"], steps=resolved_grid_x, device=device)
        t = torch.linspace(self.domain["t_min"], self.domain["t_max"], steps=resolved_grid_t, device=device)
        tt, xx = torch.meshgrid(t, x, indexing="ij")
        inputs = torch.stack([xx.reshape(-1), tt.reshape(-1)], dim=1)
        targets = self.exact_solution(inputs)
        return EvaluationBatch(
            inputs=inputs,
            targets=targets,
            name="wave1d_analytic_grid",
            metadata={"grid_shape": (resolved_grid_t, resolved_grid_x), "wave_speed": self.wave_speed},
        )

    def compute_loss_terms(self, model: torch.nn.Module, batches: TrainBatches) -> dict[str, torch.Tensor]:
        if (
            batches.interior is None
            or batches.boundary is None
            or batches.initial is None
            or batches.initial_velocity is None
        ):
            raise ValueError("Wave1DTask requires interior, boundary, initial, and initial_velocity batches.")
        if (
            batches.boundary.targets is None
            or batches.initial.targets is None
            or batches.initial_velocity.targets is None
        ):
            raise ValueError("Wave1DTask boundary, initial, and initial_velocity batches require targets.")

        residual = self._physics_residual(model, batches.interior.inputs)
        physics_loss = F.mse_loss(residual, torch.zeros_like(residual))

        boundary_predictions = model(batches.boundary.inputs)
        boundary_loss = F.mse_loss(boundary_predictions, batches.boundary.targets)

        initial_predictions = model(batches.initial.inputs)
        initial_loss = F.mse_loss(initial_predictions, batches.initial.targets)

        initial_velocity_inputs = batches.initial_velocity.inputs.clone().detach().requires_grad_(True)
        initial_velocity_predictions = model(initial_velocity_inputs)
        initial_velocity_gradients = torch.autograd.grad(
            outputs=initial_velocity_predictions,
            inputs=initial_velocity_inputs,
            grad_outputs=torch.ones_like(initial_velocity_predictions),
            create_graph=True,
            retain_graph=True,
        )[0]
        initial_velocity_values = initial_velocity_gradients[:, 1:2]
        initial_velocity_loss = F.mse_loss(initial_velocity_values, batches.initial_velocity.targets)

        return {
            "physics": physics_loss,
            "boundary": boundary_loss,
            "initial": initial_loss,
            "initial_velocity": initial_velocity_loss,
        }

    def compute_residual(self, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        return self._physics_residual(model, inputs).detach()

    def compute_metric(
        self,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        del predictions, targets
        if metric_name == "residual_metric":
            residual = self._physics_residual(model, batch.inputs)
            return float(torch.mean(residual**2).detach().item())
        if metric_name == "bc_violation":
            inputs, target_values = self._boundary_diagnostic_batch(batch.inputs.device)
            values = model(inputs)
            return float(F.mse_loss(values, target_values).detach().item())
        if metric_name == "ic_violation":
            initial_inputs, initial_targets = self._initial_diagnostic_batch(batch.inputs.device)
            initial_values = model(initial_inputs)
            initial_loss = F.mse_loss(initial_values, initial_targets)
            velocity_inputs, velocity_targets = self._initial_velocity_diagnostic_batch(batch.inputs.device)
            velocity_inputs = velocity_inputs.clone().detach().requires_grad_(True)
            velocity_predictions = model(velocity_inputs)
            velocity_gradients = torch.autograd.grad(
                outputs=velocity_predictions,
                inputs=velocity_inputs,
                grad_outputs=torch.ones_like(velocity_predictions),
                create_graph=True,
                retain_graph=True,
            )[0][:, 1:2]
            velocity_loss = F.mse_loss(velocity_gradients, velocity_targets)
            return float(0.5 * (initial_loss + velocity_loss).detach().item())
        return None
