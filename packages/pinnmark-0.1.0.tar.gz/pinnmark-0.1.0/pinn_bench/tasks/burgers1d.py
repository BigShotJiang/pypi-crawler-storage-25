"""Burgers 1D PDE task using the classic PINN setup."""

from __future__ import annotations

from importlib.resources import files
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import BaseTask, EvaluationBatch, SampleBatch, TrainBatches


@register_task("burgers1d")
class Burgers1DTask(BaseTask):
    """Burgers 1D benchmark task for validating PINN abstractions."""

    def __init__(
        self,
        input_dim: int = 2,
        output_dim: int = 1,
        domain: dict[str, float] | None = None,
        viscosity: float = 0.01 / np.pi,
        sampling: dict[str, int] | None = None,
        reference: dict[str, int] | None = None,
        **_: Any,
    ) -> None:
        self.input_dim = int(input_dim)
        self.output_dim = int(output_dim)
        self.domain = {
            "x_min": -1.0,
            "x_max": 1.0,
            "t_min": 0.0,
            "t_max": 1.0,
            **(domain or {}),
        }
        self.viscosity = float(viscosity)
        self.sampling = {
            "num_interior": 256,
            "num_boundary": 64,
            "num_initial": 64,
            **(sampling or {}),
        }
        self.reference = {
            "grid_x": 256,
            "grid_t": 100,
            **(reference or {}),
        }
        if self.input_dim != 2 or self.output_dim != 1:
            raise ValueError("Burgers1DTask expects input_dim=2 and output_dim=1.")

    def _sample_x(self, num_samples: int, device: torch.device) -> torch.Tensor:
        return torch.rand((num_samples, 1), device=device) * (self.domain["x_max"] - self.domain["x_min"]) + self.domain["x_min"]

    def _sample_t(self, num_samples: int, device: torch.device, include_zero: bool = False) -> torch.Tensor:
        t_min = self.domain["t_min"] if include_zero else max(self.domain["t_min"], 1e-6)
        return torch.rand((num_samples, 1), device=device) * (self.domain["t_max"] - t_min) + t_min

    def _initial_condition(self, x: torch.Tensor) -> torch.Tensor:
        return -torch.sin(torch.pi * x)

    def _load_reference_solution(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        resource = files("pinn_bench.assets").joinpath("burgers1d_reference.npz")
        with resource.open("rb") as handle:
            data = np.load(handle)
            x = data["x"]
            t = data["t"]
            u = data["u"]
        return x, t, u

    def _physics_residual(self, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        interior_inputs = inputs.clone().detach().requires_grad_(True)
        interior_predictions = model(interior_inputs)
        gradients = torch.autograd.grad(
            outputs=interior_predictions,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(interior_predictions),
            create_graph=True,
            retain_graph=True,
        )[0]
        u_x = gradients[:, :1]
        u_t = gradients[:, 1:2]
        second_gradients = torch.autograd.grad(
            outputs=u_x,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(u_x),
            create_graph=True,
            retain_graph=True,
        )[0]
        u_xx = second_gradients[:, :1]
        return u_t + interior_predictions * u_x - self.viscosity * u_xx

    def _boundary_diagnostic_batch(self, device: torch.device, num_points: int = 128) -> tuple[torch.Tensor, torch.Tensor]:
        count = max(2, num_points // 2)
        t = torch.linspace(self.domain["t_min"], self.domain["t_max"], steps=count, device=device).reshape(-1, 1)
        left_inputs = torch.cat(
            [torch.full((count, 1), float(self.domain["x_min"]), device=device), t],
            dim=1,
        )
        right_inputs = torch.cat(
            [torch.full((count, 1), float(self.domain["x_max"]), device=device), t],
            dim=1,
        )
        inputs = torch.cat([left_inputs, right_inputs], dim=0)
        targets = torch.zeros((inputs.shape[0], 1), device=device)
        return inputs, targets

    def _initial_diagnostic_batch(self, device: torch.device, num_points: int = 128) -> tuple[torch.Tensor, torch.Tensor]:
        x = torch.linspace(self.domain["x_min"], self.domain["x_max"], steps=max(2, num_points), device=device).reshape(-1, 1)
        t = torch.full((x.shape[0], 1), float(self.domain["t_min"]), device=device)
        inputs = torch.cat([x, t], dim=1)
        return inputs, self._initial_condition(x)

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        num_interior = int(self.sampling["num_interior"])
        num_boundary = int(self.sampling["num_boundary"])
        num_initial = int(self.sampling["num_initial"])

        interior_x = self._sample_x(num_interior, device=device)
        interior_t = self._sample_t(num_interior, device=device, include_zero=False)
        interior_inputs = torch.cat([interior_x, interior_t], dim=1)

        half_boundary = num_boundary // 2
        left_t = self._sample_t(half_boundary, device=device, include_zero=True)
        right_t = self._sample_t(num_boundary - half_boundary, device=device, include_zero=True)
        left_x = torch.full((half_boundary, 1), float(self.domain["x_min"]), device=device)
        right_x = torch.full((num_boundary - half_boundary, 1), float(self.domain["x_max"]), device=device)
        boundary_inputs = torch.cat(
            [torch.cat([left_x, left_t], dim=1), torch.cat([right_x, right_t], dim=1)],
            dim=0,
        )
        boundary_targets = torch.zeros((num_boundary, 1), device=device)

        initial_x = self._sample_x(num_initial, device=device)
        initial_t = torch.full((num_initial, 1), float(self.domain["t_min"]), device=device)
        initial_inputs = torch.cat([initial_x, initial_t], dim=1)
        initial_targets = self._initial_condition(initial_x)

        return TrainBatches(
            interior=SampleBatch(inputs=interior_inputs, metadata={"kind": "interior"}),
            boundary=SampleBatch(inputs=boundary_inputs, targets=boundary_targets, metadata={"kind": "boundary"}),
            initial=SampleBatch(inputs=initial_inputs, targets=initial_targets, metadata={"kind": "initial"}),
            supervision=None,
            metadata={"task_name": "burgers1d", "viscosity": self.viscosity},
        )

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        del num_samples, grid_y
        reference_x, reference_t, reference_u = self._load_reference_solution()
        requested_grid_x = int(grid_x or self.reference["grid_x"])
        requested_grid_t = int(grid_t or self.reference["grid_t"])

        if requested_grid_x > reference_x.shape[0]:
            raise ValueError("Requested Burgers evaluation grid exceeds packaged reference resolution.")

        t_min = float(self.domain["t_min"])
        t_max = float(self.domain["t_max"])
        time_mask = (reference_t >= (t_min - 1e-8)) & (reference_t <= (t_max + 1e-8))
        available_t_indices = np.flatnonzero(time_mask)
        if available_t_indices.size == 0:
            raise ValueError(
                f"No Burgers reference time points are available in the requested domain [{t_min}, {t_max}]."
            )
        if requested_grid_t > available_t_indices.size:
            raise ValueError(
                "Requested Burgers evaluation grid exceeds packaged reference resolution for the current time domain."
            )

        x_indices = np.linspace(0, reference_x.shape[0] - 1, requested_grid_x, dtype=int)
        filtered_time_positions = np.linspace(0, available_t_indices.size - 1, requested_grid_t, dtype=int)
        t_indices = available_t_indices[filtered_time_positions]
        x = reference_x[x_indices]
        t = reference_t[t_indices]
        u = reference_u[np.ix_(t_indices, x_indices)]

        tt, xx = np.meshgrid(t, x, indexing="ij")
        inputs = np.stack([xx.reshape(-1), tt.reshape(-1)], axis=1)
        targets = u.reshape(-1, 1)

        return EvaluationBatch(
            inputs=torch.tensor(inputs, dtype=torch.float32, device=device),
            targets=torch.tensor(targets, dtype=torch.float32, device=device),
            name="burgers1d_reference_grid",
            metadata={
                "grid_shape": (requested_grid_t, requested_grid_x),
                "viscosity": self.viscosity,
                "time_range": (float(t[0]), float(t[-1])),
            },
        )

    def compute_loss_terms(
        self,
        model: torch.nn.Module,
        batches: TrainBatches,
    ) -> dict[str, torch.Tensor]:
        if batches.interior is None or batches.boundary is None or batches.initial is None:
            raise ValueError("Burgers1DTask requires interior, boundary, and initial batches.")
        if batches.boundary.targets is None or batches.initial.targets is None:
            raise ValueError("Boundary and initial batches require targets.")

        residual = self._physics_residual(model, batches.interior.inputs)
        physics_loss = F.mse_loss(residual, torch.zeros_like(residual))

        boundary_predictions = model(batches.boundary.inputs)
        boundary_loss = F.mse_loss(boundary_predictions, batches.boundary.targets)

        initial_predictions = model(batches.initial.inputs)
        initial_loss = F.mse_loss(initial_predictions, batches.initial.targets)

        return {
            "physics": physics_loss,
            "boundary": boundary_loss,
            "initial": initial_loss,
        }

    def exact_solution(self, inputs: torch.Tensor) -> torch.Tensor | None:
        del inputs
        return None

    def compute_residual(self, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        return self._physics_residual(model, inputs).detach()

    def compute_metric(
        self,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        del predictions, targets
        if metric_name == "residual_metric":
            residual = self._physics_residual(model, batch.inputs)
            return float(torch.mean(residual**2).detach().item())
        if metric_name == "bc_violation":
            inputs, target_values = self._boundary_diagnostic_batch(batch.inputs.device)
            values = model(inputs)
            return float(F.mse_loss(values, target_values).detach().item())
        if metric_name == "ic_violation":
            inputs, target_values = self._initial_diagnostic_batch(batch.inputs.device)
            values = model(inputs)
            return float(F.mse_loss(values, target_values).detach().item())
        return None
