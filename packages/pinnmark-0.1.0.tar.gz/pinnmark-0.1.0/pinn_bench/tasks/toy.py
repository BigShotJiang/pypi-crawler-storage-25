"""Toy task for Phase 2 end-to-end validation."""

from __future__ import annotations

from typing import Any

import torch
import torch.nn.functional as F

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import BaseTask, EvaluationBatch, SampleBatch, TrainBatches


@register_task("toy")
class ToyTask(BaseTask):
    """Synthetic regression task used to validate pipeline wiring."""

    def __init__(
        self,
        input_dim: int = 2,
        output_dim: int = 1,
        num_interior: int = 128,
        num_boundary: int = 32,
        noise_std: float = 0.0,
        evaluation_points: int = 256,
        **_: Any,
    ) -> None:
        self.input_dim = int(input_dim)
        self.output_dim = int(output_dim)
        self.num_interior = int(num_interior)
        self.num_boundary = int(num_boundary)
        self.noise_std = float(noise_std)
        self.evaluation_points = int(evaluation_points)

    def _target_function(self, x: torch.Tensor) -> torch.Tensor:
        if x.shape[1] < 2:
            signal = torch.sin(torch.pi * x[:, :1])
        else:
            signal = torch.sin(torch.pi * x[:, :1]) + torch.cos(torch.pi * x[:, 1:2])
        if self.output_dim > 1:
            signal = signal.repeat(1, self.output_dim)
        return signal

    def sample_batch(self, num_samples: int, device: torch.device) -> SampleBatch:
        """Return a plain toy regression batch."""
        inputs = torch.rand((num_samples, self.input_dim), device=device) * 2.0 - 1.0
        targets = self._target_function(inputs)
        if self.noise_std > 0:
            targets = targets + torch.randn_like(targets) * self.noise_std
        return SampleBatch(inputs=inputs, targets=targets)

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        interior = self.sample_batch(num_samples=self.num_interior, device=device)
        boundary = self.sample_batch(num_samples=max(self.num_boundary, 1), device=device)
        supervision = self.sample_batch(
            num_samples=self.num_interior + self.num_boundary,
            device=device,
        )
        return TrainBatches(
            interior=interior,
            boundary=boundary,
            supervision=supervision,
            metadata={"task_name": "toy"},
        )

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        del grid_x, grid_t, grid_y
        total_samples = num_samples or self.evaluation_points
        axis = torch.linspace(-1.0, 1.0, steps=total_samples, device=device)
        inputs = torch.stack([axis for _ in range(self.input_dim)], dim=1)
        targets = self.exact_solution(inputs)
        return EvaluationBatch(inputs=inputs, targets=targets, name="toy_eval")

    def compute_loss_terms(
        self,
        model: torch.nn.Module,
        batches: TrainBatches,
    ) -> dict[str, torch.Tensor]:
        supervision = batches.supervision
        if supervision is None or supervision.targets is None:
            raise ValueError("ToyTask requires supervision targets for loss computation.")

        predictions = model(supervision.inputs)
        return {"supervision": F.mse_loss(predictions, supervision.targets)}

    def exact_solution(self, inputs: torch.Tensor) -> torch.Tensor:
        return self._target_function(inputs)
