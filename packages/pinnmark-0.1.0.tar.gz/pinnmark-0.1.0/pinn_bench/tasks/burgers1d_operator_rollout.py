"""Operator rollout task over a locked Burgers viscosity family."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import torch

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import BaseTask, ConditionBatch, EvaluationBatch, FieldBatch, SampleBatch, TrainBatches, weighted_mse_loss


def _resolve_dataset_root(raw: str | Path | None) -> Path:
    if raw is None or not str(raw).strip():
        return (
            Path.cwd()
            / "examples"
            / "superbench_v3_preview"
            / "shared_datasets"
            / "burgers1d_operator_rollout_locked_viscosity_family_v1"
        ).resolve()
    candidate = Path(str(raw)).expanduser()
    if not candidate.is_absolute():
        candidate = (Path.cwd() / candidate).resolve()
    return candidate


@register_task("burgers1d_operator_rollout")
class Burgers1DOperatorRolloutTask(BaseTask):
    """Field-output rollout task over a locked two-slice Burgers viscosity family."""

    task_mode = "field"
    supports_operator = True

    def __init__(
        self,
        input_dim: int = 2,
        output_dim: int = 1,
        dataset_variant: str = "locked_viscosity_family_v1",
        dataset_root: str | None = None,
        history_steps: int = 10,
        rollout_stride: int = 5,
        forecast_steps: int = 20,
        viscosity_values: list[float] | None = None,
        field_grid: dict[str, int] | None = None,
        **_: Any,
    ) -> None:
        self.input_dim = int(input_dim)
        self.output_dim = int(output_dim)
        if self.input_dim != 2:
            raise ValueError("Burgers1DOperatorRolloutTask requires input_dim=2 for (x, t_future).")
        if self.output_dim != 1:
            raise ValueError("Burgers1DOperatorRolloutTask requires output_dim=1.")

        self.dataset_variant = str(dataset_variant)
        self.dataset_root = _resolve_dataset_root(dataset_root)
        self.history_steps = int(history_steps)
        self.rollout_stride = int(rollout_stride)
        self.forecast_steps = int(forecast_steps)
        self.field_grid = {
            "grid_x": 64,
            "grid_t": 20,
            **(field_grid or {}),
        }
        self.requested_viscosity_values = [float(value) for value in (viscosity_values or [0.001, 1.0])]
        self._condition_feature_names = [
            *[f"history_step_{index:02d}" for index in range(self.history_steps)],
            "viscosity",
        ]
        self._family_payload = self._load_family_payload()
        self._selected_indices = self._resolve_viscosity_indices()

    def _dataset_payload_path(self) -> Path:
        return self.dataset_root / f"{self.dataset_variant}.npz"

    def _load_family_payload(self) -> dict[str, np.ndarray]:
        payload_path = self._dataset_payload_path()
        if not payload_path.exists():
            raise FileNotFoundError(f"Expected Burgers operator dataset at {payload_path}.")
        loaded = np.load(payload_path, allow_pickle=False)
        x = np.asarray(loaded["x"], dtype=np.float32)
        t = np.asarray(loaded["t"], dtype=np.float32)
        u = np.asarray(loaded["u"], dtype=np.float32)
        viscosity_values = np.asarray(loaded["viscosity_values"], dtype=np.float32)
        viscosity_set_id = str(loaded["viscosity_set_id"].tolist())
        if u.ndim != 3:
            raise ValueError("Expected operator family payload `u` to have shape (family, time, x).")
        if tuple(u.shape) != (len(viscosity_values), len(t), len(x)):
            raise ValueError("Operator family payload shapes are inconsistent.")
        if int(self.field_grid["grid_x"]) != int(len(x)):
            raise ValueError(
                f"Burgers operator dataset uses grid_x={len(x)} but task was configured for grid_x={self.field_grid['grid_x']}."
            )
        if len(t) < self.history_steps + (self.forecast_steps - 1) * self.rollout_stride + 1:
            raise ValueError("Operator family payload does not contain enough time steps for the requested rollout horizon.")
        if int(self.field_grid["grid_t"]) != self.forecast_steps:
            raise ValueError(
                f"Burgers operator task requires field_grid.grid_t == forecast_steps; got {self.field_grid['grid_t']} and {self.forecast_steps}."
            )
        return {
            "x": x,
            "t": t,
            "u": u,
            "viscosity_values": viscosity_values,
            "viscosity_set_id": viscosity_set_id,
        }

    def _resolve_viscosity_indices(self) -> list[int]:
        available = [float(value) for value in self._family_payload["viscosity_values"]]
        indices: list[int] = []
        for requested in self.requested_viscosity_values:
            matches = [index for index, available_value in enumerate(available) if abs(available_value - requested) <= 1e-8]
            if not matches:
                raise ValueError(
                    f"Requested viscosity {requested} is not available in dataset family {available}."
                )
            indices.append(matches[0])
        return indices

    @property
    def viscosity_values(self) -> list[float]:
        raw = self._family_payload["viscosity_values"]
        return [float(raw[index]) for index in self._selected_indices]

    def _resolve_future_indices(self) -> list[int]:
        return [self.history_steps + index * self.rollout_stride for index in range(self.forecast_steps)]

    @staticmethod
    def _resolve_condition_inputs(batch: SampleBatch, batches: TrainBatches) -> torch.Tensor | None:
        condition_inputs = batch.metadata.get("condition_inputs")
        if condition_inputs is not None:
            return condition_inputs
        condition_batch = batches.metadata.get("condition_batch")
        if isinstance(condition_batch, ConditionBatch):
            return condition_batch.inputs
        if isinstance(condition_batch, dict) and isinstance(condition_batch.get("inputs"), torch.Tensor):
            return condition_batch["inputs"]
        return None

    @staticmethod
    def _predict_field(*, model: torch.nn.Module, batch: SampleBatch, batches: TrainBatches) -> torch.Tensor:
        condition_inputs = Burgers1DOperatorRolloutTask._resolve_condition_inputs(batch, batches)
        if hasattr(model, "forward_field"):
            predictions = model.forward_field(
                condition_inputs=condition_inputs,
                query_inputs=batch.inputs,
                metadata=batch.metadata,
            )
        elif bool(getattr(model, "supports_flattened_field", False)):
            predictions = model(batch.inputs)
        else:
            raise ValueError("Burgers1DOperatorRolloutTask requires an operator-ready model.")
        if predictions.shape == batch.targets.shape:
            return predictions
        if predictions.numel() == batch.targets.numel():
            return predictions.reshape_as(batch.targets)
        raise ValueError(
            f"Field prediction shape {tuple(predictions.shape)} does not match targets {tuple(batch.targets.shape)}."
        )

    def _build_field_batch(self, *, device: torch.device) -> FieldBatch:
        x = torch.tensor(self._family_payload["x"], dtype=torch.float32, device=device)
        t = torch.tensor(self._family_payload["t"], dtype=torch.float32, device=device)
        u = torch.tensor(self._family_payload["u"], dtype=torch.float32, device=device)
        future_indices = self._resolve_future_indices()
        future_t = t[future_indices]
        tt_template, xx_template = torch.meshgrid(future_t, x, indexing="ij")
        boundary_mask_template = ((xx_template <= float(x.min())) | (xx_template >= float(x.max()))).reshape(-1)
        initial_mask_template = (tt_template <= float(future_t[0])).reshape(-1)
        normalized_t = (tt_template - float(future_t.min())) / max(float(future_t.max() - future_t.min()), 1e-6)
        temporal_block_keep_template = ((normalized_t < 0.3) | (normalized_t > 0.7)).reshape(-1)

        query_batches: list[torch.Tensor] = []
        target_batches: list[torch.Tensor] = []
        condition_batches: list[torch.Tensor] = []
        family_viscosities: list[float] = []
        boundary_mask_batches: list[torch.Tensor] = []
        initial_mask_batches: list[torch.Tensor] = []
        temporal_block_keep_batches: list[torch.Tensor] = []

        for family_index in self._selected_indices:
            viscosity = float(self._family_payload["viscosity_values"][family_index])
            history = u[family_index, : self.history_steps, :]  # (history_steps, grid_x)
            future = u[family_index, future_indices, :]  # (forecast_steps, grid_x)
            tt, xx = torch.meshgrid(future_t, x, indexing="ij")
            query_inputs = torch.stack([xx.reshape(-1), tt.reshape(-1)], dim=1)
            history_per_x = history.transpose(0, 1)
            history_per_query = history_per_x.unsqueeze(0).expand(self.forecast_steps, -1, -1).reshape(-1, self.history_steps)
            viscosity_column = torch.full((query_inputs.shape[0], 1), viscosity, dtype=torch.float32, device=device)
            condition_inputs = torch.cat([history_per_query, viscosity_column], dim=1)

            query_batches.append(query_inputs)
            target_batches.append(future.reshape(-1, 1))
            condition_batches.append(condition_inputs)
            family_viscosities.append(viscosity)
            boundary_mask_batches.append(boundary_mask_template.clone())
            initial_mask_batches.append(initial_mask_template.clone())
            temporal_block_keep_batches.append(temporal_block_keep_template.clone())

        inputs = torch.cat(query_batches, dim=0)
        targets = torch.cat(target_batches, dim=0)
        condition_inputs = torch.cat(condition_batches, dim=0)
        boundary_mask = torch.cat(boundary_mask_batches, dim=0)
        initial_mask = torch.cat(initial_mask_batches, dim=0)
        temporal_block_keep = torch.cat(temporal_block_keep_batches, dim=0)
        family_batch_size = len(self._selected_indices)
        grid_x = int(self.field_grid["grid_x"])
        grid_t = int(self.field_grid["grid_t"])
        return FieldBatch(
            inputs=inputs,
            targets=targets,
            condition_inputs=condition_inputs,
            metadata={
                "grid_shape": (grid_t, grid_x),
                "grid_axes": {"x": 0, "t": 1},
                "domain_bounds": {
                    "x": (float(x.min()), float(x.max())),
                    "t": (float(future_t.min()), float(future_t.max())),
                },
                "family_batch_size": family_batch_size,
                "field_shape": (grid_t, grid_x, self.output_dim),
                "family_field_shape": (family_batch_size, grid_t, grid_x, self.output_dim),
                "condition_shape": tuple(condition_inputs.shape),
                "condition_feature_names": list(self._condition_feature_names),
                "evaluation_mode": "field",
                "task_mode": "field",
                "dataset_variant": self.dataset_variant,
                "dataset_root": str(self.dataset_root),
                "viscosity_set_id": str(self._family_payload["viscosity_set_id"]),
                "viscosity_values": list(family_viscosities),
                "viscosity": list(family_viscosities),
                "history_steps": self.history_steps,
                "rollout_stride": self.rollout_stride,
                "forecast_steps": self.forecast_steps,
                "structured_scope_masks": {
                    "boundary_only": boundary_mask,
                    "initial_only": initial_mask,
                    "temporal_block_missing": temporal_block_keep,
                },
            },
        )

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        field_batch = self._build_field_batch(device=device)
        condition_batch = ConditionBatch(
            inputs=field_batch.condition_inputs,
            metadata={
                "condition_shape": tuple(field_batch.condition_inputs.shape),
                "condition_feature_names": list(self._condition_feature_names),
            },
        )
        supervision = field_batch.to_sample_batch()
        return TrainBatches(
            supervision=supervision,
            metadata={
                "task_name": "burgers1d_operator_rollout",
                "task_mode": "field",
                "grid_shape": supervision.metadata["grid_shape"],
                "family_batch_size": supervision.metadata["family_batch_size"],
                "field_shape": supervision.metadata["field_shape"],
                "family_field_shape": supervision.metadata["family_field_shape"],
                "condition_batch": condition_batch,
                "viscosity_set_id": supervision.metadata["viscosity_set_id"],
                "viscosity_values": supervision.metadata["viscosity_values"],
                "history_steps": self.history_steps,
                "rollout_stride": self.rollout_stride,
                "forecast_steps": self.forecast_steps,
            },
        )

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        del num_samples, grid_y
        if grid_x is not None and int(grid_x) != int(self.field_grid["grid_x"]):
            raise ValueError("Burgers1DOperatorRolloutTask does not support grid_x overrides outside the locked family grid.")
        if grid_t is not None and int(grid_t) != int(self.field_grid["grid_t"]):
            raise ValueError("Burgers1DOperatorRolloutTask does not support grid_t overrides outside the locked family rollout horizon.")
        field_batch = self._build_field_batch(device=device)
        return EvaluationBatch(
            inputs=field_batch.inputs,
            targets=field_batch.targets,
            name="burgers1d_operator_rollout_grid",
            metadata={
                **field_batch.metadata,
                "condition_inputs": field_batch.condition_inputs,
            },
        )

    def compute_loss_terms(self, model: torch.nn.Module, batches: TrainBatches) -> dict[str, torch.Tensor]:
        if batches.supervision is None or batches.supervision.targets is None:
            raise ValueError("Burgers1DOperatorRolloutTask requires a target-bearing supervision batch.")
        predictions = self._predict_field(model=model, batch=batches.supervision, batches=batches)
        return {
            "field_supervision": weighted_mse_loss(
                predictions,
                batches.supervision.targets,
                weights=batches.supervision.weights,
            ),
        }
