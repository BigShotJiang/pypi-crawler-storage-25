"""Poisson 2D task using a manufactured analytic solution."""

from __future__ import annotations

from math import pi
from typing import Any

import torch
import torch.nn.functional as F

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import BaseTask, EvaluationBatch, SampleBatch, TrainBatches


@register_task("poisson2d")
class Poisson2DTask(BaseTask):
    """Poisson 2D benchmark task on the unit square with zero Dirichlet boundary."""

    _GEOMETRY_FAMILIES = {"regular_square", "disk", "annulus"}
    _GEOMETRY_DISTRIBUTIONS = {None, "ID", "OOD"}
    _DEFAULT_GEOMETRY_PARAMS = {
        "disk": {
            "center_x": 0.5,
            "center_y": 0.5,
            "radius": 0.35,
        },
        "annulus": {
            "center_x": 0.5,
            "center_y": 0.5,
            "inner_radius": 0.18,
            "outer_radius": 0.4,
        },
    }

    def __init__(
        self,
        input_dim: int = 2,
        output_dim: int = 1,
        domain: dict[str, float] | None = None,
        sampling: dict[str, int] | None = None,
        manufactured_solution: str = "sine_dirichlet",
        geometry_family: str = "regular_square",
        geometry_split_id: str | None = None,
        geometry_distribution: str | None = None,
        boundary_band_epsilon: float = 0.05,
        **_: Any,
    ) -> None:
        self.input_dim = int(input_dim)
        self.output_dim = int(output_dim)
        self.domain = {
            "x_min": 0.0,
            "x_max": 1.0,
            "y_min": 0.0,
            "y_max": 1.0,
            **(domain or {}),
        }
        self.sampling = {
            "num_interior": 256,
            "num_boundary": 64,
            **(sampling or {}),
        }
        self.manufactured_solution = str(manufactured_solution)
        self.geometry_family = str(geometry_family).strip()
        self.geometry_split_id = None if geometry_split_id is None else str(geometry_split_id).strip()
        self.geometry_distribution = None if geometry_distribution is None else str(geometry_distribution).strip().upper()
        self.boundary_band_epsilon = float(boundary_band_epsilon)
        self.geometry_representation = "sdf"
        self.geometry_params = {
            name: dict(values)
            for name, values in self._DEFAULT_GEOMETRY_PARAMS.items()
        }

        if self.input_dim != 2 or self.output_dim != 1:
            raise ValueError("Poisson2DTask expects input_dim=2 and output_dim=1.")
        if self.manufactured_solution != "sine_dirichlet":
            raise ValueError("Poisson2DTask only supports manufactured_solution='sine_dirichlet' in Phase 3B.")
        if self.geometry_family not in self._GEOMETRY_FAMILIES:
            allowed = ", ".join(sorted(self._GEOMETRY_FAMILIES))
            raise ValueError(f"Poisson2DTask geometry_family must be one of: {allowed}")
        if self.geometry_distribution not in self._GEOMETRY_DISTRIBUTIONS:
            allowed = ", ".join(sorted(value for value in self._GEOMETRY_DISTRIBUTIONS if value is not None))
            raise ValueError(f"Poisson2DTask geometry_distribution must be one of: {allowed}")
        if self.boundary_band_epsilon <= 0.0:
            raise ValueError("Poisson2DTask boundary_band_epsilon must be > 0.")

    def _sample_x(self, num_samples: int, device: torch.device, interior: bool = False) -> torch.Tensor:
        epsilon = 1e-6 if interior else 0.0
        return torch.rand((num_samples, 1), device=device) * (
            (self.domain["x_max"] - epsilon) - (self.domain["x_min"] + epsilon)
        ) + (self.domain["x_min"] + epsilon)

    def _sample_y(self, num_samples: int, device: torch.device, interior: bool = False) -> torch.Tensor:
        epsilon = 1e-6 if interior else 0.0
        return torch.rand((num_samples, 1), device=device) * (
            (self.domain["y_max"] - epsilon) - (self.domain["y_min"] + epsilon)
        ) + (self.domain["y_min"] + epsilon)

    def _geometry_metadata(self) -> dict[str, object]:
        return {
            "geometry_family": self.geometry_family,
            "geometry_representation": self.geometry_representation,
            "geometry_split_id": self.geometry_split_id,
            "geometry_distribution": self.geometry_distribution,
            "boundary_band_epsilon": self.boundary_band_epsilon,
        }

    def _geometry_centered_coordinates(self, inputs: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        if self.geometry_family == "annulus":
            params = self.geometry_params["annulus"]
        else:
            params = self.geometry_params["disk"]
        dx = inputs[:, :1] - float(params["center_x"])
        dy = inputs[:, 1:2] - float(params["center_y"])
        return dx, dy

    def _radius(self, inputs: torch.Tensor) -> torch.Tensor:
        dx, dy = self._geometry_centered_coordinates(inputs)
        return torch.sqrt(dx**2 + dy**2 + 1e-12)

    def _geometry_sdf(self, inputs: torch.Tensor) -> torch.Tensor:
        if self.geometry_family == "regular_square":
            edge_distances = torch.cat(
                [
                    inputs[:, :1] - float(self.domain["x_min"]),
                    float(self.domain["x_max"]) - inputs[:, :1],
                    inputs[:, 1:2] - float(self.domain["y_min"]),
                    float(self.domain["y_max"]) - inputs[:, 1:2],
                ],
                dim=1,
            )
            return -torch.min(edge_distances, dim=1, keepdim=True).values
        radius = self._radius(inputs)
        if self.geometry_family == "disk":
            outer_radius = float(self.geometry_params["disk"]["radius"])
            return radius - outer_radius
        inner_radius = float(self.geometry_params["annulus"]["inner_radius"])
        outer_radius = float(self.geometry_params["annulus"]["outer_radius"])
        return torch.maximum(inner_radius - radius, radius - outer_radius)

    def _inside_geometry_mask(self, inputs: torch.Tensor) -> torch.Tensor:
        if self.geometry_family == "regular_square":
            return torch.ones((inputs.shape[0],), device=inputs.device, dtype=torch.bool)
        if self.geometry_family == "disk":
            radius = self._radius(inputs)
            return (radius <= float(self.geometry_params["disk"]["radius"]) + 1e-6).reshape(-1)
        radius = self._radius(inputs)
        inner_radius = float(self.geometry_params["annulus"]["inner_radius"])
        outer_radius = float(self.geometry_params["annulus"]["outer_radius"])
        return ((radius >= inner_radius - 1e-6) & (radius <= outer_radius + 1e-6)).reshape(-1)

    def _near_boundary_mask(self, inputs: torch.Tensor, *, epsilon: float | None = None) -> torch.Tensor:
        resolved_epsilon = float(self.boundary_band_epsilon if epsilon is None else epsilon)
        sdf = self._geometry_sdf(inputs).abs().reshape(-1)
        return self._inside_geometry_mask(inputs) & (sdf <= resolved_epsilon)

    def _manufactured_solution(self, inputs: torch.Tensor) -> torch.Tensor:
        x = inputs[:, :1]
        y = inputs[:, 1:2]
        if self.geometry_family == "regular_square":
            return torch.sin(pi * x) * torch.sin(pi * y)
        mode = torch.sin(pi * x) * torch.sin(pi * y)
        radius = self._radius(inputs)
        if self.geometry_family == "disk":
            outer_radius = float(self.geometry_params["disk"]["radius"])
            boundary_factor = (outer_radius**2 - radius**2).clamp_min(0.0)
            return boundary_factor * mode
        inner_radius = float(self.geometry_params["annulus"]["inner_radius"])
        outer_radius = float(self.geometry_params["annulus"]["outer_radius"])
        outer_factor = (outer_radius**2 - radius**2).clamp_min(0.0)
        inner_factor = (radius**2 - inner_radius**2).clamp_min(0.0)
        return outer_factor * inner_factor * mode

    def _boundary_condition_targets(self, inputs: torch.Tensor) -> torch.Tensor:
        return torch.zeros((inputs.shape[0], 1), device=inputs.device)

    def _sample_geometry_interior(self, num_samples: int, device: torch.device) -> torch.Tensor:
        collected: list[torch.Tensor] = []
        remaining = num_samples
        while remaining > 0:
            candidate_count = max(remaining * 4, 64)
            candidates = torch.cat(
                [
                    self._sample_x(candidate_count, device=device, interior=True),
                    self._sample_y(candidate_count, device=device, interior=True),
                ],
                dim=1,
            )
            selected = candidates[self._inside_geometry_mask(candidates)]
            if selected.numel() == 0:
                continue
            collected.append(selected[:remaining])
            remaining -= selected[:remaining].shape[0]
        return torch.cat(collected, dim=0)

    def _sample_geometry_boundary(self, num_samples: int, device: torch.device) -> torch.Tensor:
        if self.geometry_family == "regular_square":
            return self._sample_square_boundary(num_samples=num_samples, device=device)
        theta = 2.0 * pi * torch.rand((num_samples, 1), device=device)
        if self.geometry_family == "disk":
            params = self.geometry_params["disk"]
            center_x = float(params["center_x"])
            center_y = float(params["center_y"])
            radius = float(params["radius"])
            x = center_x + radius * torch.cos(theta)
            y = center_y + radius * torch.sin(theta)
            return torch.cat([x, y], dim=1)
        params = self.geometry_params["annulus"]
        center_x = float(params["center_x"])
        center_y = float(params["center_y"])
        inner_radius = float(params["inner_radius"])
        outer_radius = float(params["outer_radius"])
        outer_count = num_samples // 2
        inner_count = num_samples - outer_count
        outer_theta = theta[:outer_count]
        inner_theta = theta[outer_count:]
        outer = torch.cat(
            [
                center_x + outer_radius * torch.cos(outer_theta),
                center_y + outer_radius * torch.sin(outer_theta),
            ],
            dim=1,
        )
        inner = torch.cat(
            [
                center_x + inner_radius * torch.cos(inner_theta),
                center_y + inner_radius * torch.sin(inner_theta),
            ],
            dim=1,
        )
        return torch.cat([outer, inner], dim=0)

    def _sample_near_boundary_points(self, num_samples: int, device: torch.device) -> torch.Tensor:
        if self.geometry_family == "regular_square":
            candidates = torch.cat(
                [
                    self._sample_x(num_samples * 4, device=device, interior=True),
                    self._sample_y(num_samples * 4, device=device, interior=True),
                ],
                dim=1,
            )
            distances = torch.stack(
                [
                    candidates[:, 0] - float(self.domain["x_min"]),
                    float(self.domain["x_max"]) - candidates[:, 0],
                    candidates[:, 1] - float(self.domain["y_min"]),
                    float(self.domain["y_max"]) - candidates[:, 1],
                ],
                dim=1,
            )
            mask = torch.min(distances, dim=1).values <= self.boundary_band_epsilon
            selected = candidates[mask]
            if selected.shape[0] >= num_samples:
                return selected[:num_samples]
            return candidates[:num_samples]
        collected: list[torch.Tensor] = []
        remaining = num_samples
        while remaining > 0:
            candidate_count = max(remaining * 8, 128)
            candidates = torch.cat(
                [
                    self._sample_x(candidate_count, device=device, interior=True),
                    self._sample_y(candidate_count, device=device, interior=True),
                ],
                dim=1,
            )
            selected = candidates[self._near_boundary_mask(candidates)]
            if selected.numel() == 0:
                continue
            collected.append(selected[:remaining])
            remaining -= selected[:remaining].shape[0]
        return torch.cat(collected, dim=0)

    def _sample_square_boundary(self, num_samples: int, device: torch.device) -> torch.Tensor:
        base_count = num_samples // 4
        remainder = num_samples % 4
        side_counts = [base_count, base_count, base_count, base_count]
        for index in range(remainder):
            side_counts[index] += 1
        left_count, right_count, bottom_count, top_count = side_counts
        left_inputs = torch.cat(
            [
                torch.full((left_count, 1), float(self.domain["x_min"]), device=device),
                self._sample_y(left_count, device=device, interior=False),
            ],
            dim=1,
        )
        right_inputs = torch.cat(
            [
                torch.full((right_count, 1), float(self.domain["x_max"]), device=device),
                self._sample_y(right_count, device=device, interior=False),
            ],
            dim=1,
        )
        bottom_inputs = torch.cat(
            [
                self._sample_x(bottom_count, device=device, interior=False),
                torch.full((bottom_count, 1), float(self.domain["y_min"]), device=device),
            ],
            dim=1,
        )
        top_inputs = torch.cat(
            [
                self._sample_x(top_count, device=device, interior=False),
                torch.full((top_count, 1), float(self.domain["y_max"]), device=device),
            ],
            dim=1,
        )
        return torch.cat([left_inputs, right_inputs, bottom_inputs, top_inputs], dim=0)

    def _source_term(self, inputs: torch.Tensor) -> torch.Tensor:
        if self.geometry_family == "regular_square":
            x = inputs[:, :1]
            y = inputs[:, 1:2]
            return 2.0 * (pi**2) * torch.sin(pi * x) * torch.sin(pi * y)
        analytic_inputs = inputs.clone().detach().requires_grad_(True)
        solution = self._manufactured_solution(analytic_inputs)
        gradients = torch.autograd.grad(
            outputs=solution,
            inputs=analytic_inputs,
            grad_outputs=torch.ones_like(solution),
            create_graph=True,
            retain_graph=True,
        )[0]
        second_x = torch.autograd.grad(
            outputs=gradients[:, :1],
            inputs=analytic_inputs,
            grad_outputs=torch.ones_like(gradients[:, :1]),
            create_graph=True,
            retain_graph=True,
        )[0][:, :1]
        second_y = torch.autograd.grad(
            outputs=gradients[:, 1:2],
            inputs=analytic_inputs,
            grad_outputs=torch.ones_like(gradients[:, 1:2]),
            create_graph=True,
            retain_graph=True,
        )[0][:, 1:2]
        return (-(second_x + second_y)).detach()

    def exact_solution(self, inputs: torch.Tensor) -> torch.Tensor:
        values = self._manufactured_solution(inputs)
        if self.geometry_family == "regular_square":
            return values
        mask = self._inside_geometry_mask(inputs).to(device=inputs.device, dtype=values.dtype).unsqueeze(-1)
        return values * mask

    def _physics_residual(self, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        interior_inputs = inputs.clone().detach().requires_grad_(True)
        predictions = model(interior_inputs)
        gradients = torch.autograd.grad(
            outputs=predictions,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(predictions),
            create_graph=True,
            retain_graph=True,
        )[0]
        u_x = gradients[:, :1]
        u_y = gradients[:, 1:2]
        second_x = torch.autograd.grad(
            outputs=u_x,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(u_x),
            create_graph=True,
            retain_graph=True,
        )[0][:, :1]
        second_y = torch.autograd.grad(
            outputs=u_y,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(u_y),
            create_graph=True,
            retain_graph=True,
        )[0][:, 1:2]
        source = self._source_term(interior_inputs)
        return -(second_x + second_y) - source

    def _boundary_diagnostic_batch(self, device: torch.device, num_points: int = 128) -> tuple[torch.Tensor, torch.Tensor]:
        inputs = self._sample_geometry_boundary(num_points, device=device)
        targets = self._boundary_condition_targets(inputs)
        return inputs, targets

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        num_interior = int(self.sampling["num_interior"])
        num_boundary = int(self.sampling["num_boundary"])

        if self.geometry_family == "regular_square":
            interior_inputs = torch.cat(
                [
                    self._sample_x(num_interior, device=device, interior=True),
                    self._sample_y(num_interior, device=device, interior=True),
                ],
                dim=1,
            )
        else:
            interior_inputs = self._sample_geometry_interior(num_interior, device=device)
        boundary_inputs = self._sample_geometry_boundary(num_boundary, device=device)
        boundary_targets = self._boundary_condition_targets(boundary_inputs)

        return TrainBatches(
            interior=SampleBatch(
                inputs=interior_inputs,
                metadata={"kind": "interior", **self._geometry_metadata()},
            ),
            boundary=SampleBatch(
                inputs=boundary_inputs,
                targets=boundary_targets,
                metadata={"kind": "boundary", **self._geometry_metadata()},
            ),
            initial=None,
            supervision=None,
            metadata={
                "task_name": "poisson2d",
                "manufactured_solution": self.manufactured_solution,
                **self._geometry_metadata(),
            },
        )

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        del num_samples, grid_t
        resolved_grid_x = int(grid_x or 64)
        resolved_grid_y = int(grid_y or 64)

        x = torch.linspace(self.domain["x_min"], self.domain["x_max"], steps=resolved_grid_x, device=device)
        y = torch.linspace(self.domain["y_min"], self.domain["y_max"], steps=resolved_grid_y, device=device)
        yy, xx = torch.meshgrid(y, x, indexing="ij")
        full_inputs = torch.stack([xx.reshape(-1), yy.reshape(-1)], dim=1)
        if self.geometry_family == "regular_square":
            inputs = full_inputs
        else:
            inputs = full_inputs[self._inside_geometry_mask(full_inputs)]
        targets = self.exact_solution(inputs)
        return EvaluationBatch(
            inputs=inputs,
            targets=targets,
            name="poisson2d_analytic_grid",
            metadata={
                "grid_shape": (resolved_grid_y, resolved_grid_x),
                "manufactured_solution": self.manufactured_solution,
                "active_point_count": int(inputs.shape[0]),
                **self._geometry_metadata(),
            },
        )

    def compute_loss_terms(
        self,
        model: torch.nn.Module,
        batches: TrainBatches,
    ) -> dict[str, torch.Tensor]:
        if batches.interior is None or batches.boundary is None:
            raise ValueError("Poisson2DTask requires interior and boundary batches.")
        if batches.boundary.targets is None:
            raise ValueError("Poisson2DTask boundary batch requires targets.")

        residual = self._physics_residual(model, batches.interior.inputs)
        physics_loss = F.mse_loss(residual, torch.zeros_like(residual))

        boundary_predictions = model(batches.boundary.inputs)
        boundary_loss = F.mse_loss(boundary_predictions, batches.boundary.targets)

        return {
            "physics": physics_loss,
            "boundary": boundary_loss,
        }

    def compute_residual(self, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        return self._physics_residual(model, inputs).detach()

    def compute_metric(
        self,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        if metric_name == "residual_metric":
            residual = self._physics_residual(model, batch.inputs)
            return float(torch.mean(residual**2).detach().item())
        if metric_name == "bc_violation":
            inputs, target_values = self._boundary_diagnostic_batch(batch.inputs.device)
            values = model(inputs)
            return float(F.mse_loss(values, target_values).detach().item())
        if metric_name == "near_boundary_relative_l2":
            near_boundary_mask = self._near_boundary_mask(batch.inputs)
            metric_inputs = batch.inputs[near_boundary_mask]
            metric_targets = targets[near_boundary_mask]
            metric_predictions = predictions[near_boundary_mask]
            if metric_inputs.shape[0] == 0:
                metric_inputs = self._sample_near_boundary_points(num_samples=128, device=batch.inputs.device)
                metric_targets = self.exact_solution(metric_inputs)
                metric_predictions = model(metric_inputs)
            numerator = torch.linalg.norm(metric_predictions - metric_targets)
            denominator = torch.linalg.norm(metric_targets) + 1e-12
            return float((numerator / denominator).detach().item())
        return None
