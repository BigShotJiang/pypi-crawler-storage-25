"""Task implementations and registrations."""

from pinn_bench.tasks.base import BaseTask, ConditionBatch, EvaluationBatch, FieldBatch, SampleBatch, TrainBatches
from pinn_bench.tasks.allencahn1d import AllenCahn1DTask
from pinn_bench.tasks.burgers1d import Burgers1DTask
from pinn_bench.tasks.burgers1d_operator_rollout import Burgers1DOperatorRolloutTask
from pinn_bench.tasks.burgers1d_operator_inverse_viscosity import Burgers1DOperatorInverseViscosityTask
from pinn_bench.tasks.burgers1d_inverse_viscosity import Burgers1DInverseViscosityTask
from pinn_bench.tasks.darcy2d_inverse_permeability import Darcy2DInversePermeabilityTask
from pinn_bench.tasks.heat1d import Heat1DTask
from pinn_bench.tasks.heat1d_field import Heat1DFieldTask
from pinn_bench.tasks.heat1d_inverse_diffusivity import Heat1DInverseDiffusivityTask
from pinn_bench.tasks.hamilton_jacobi_1d import HamiltonJacobi1DTask
from pinn_bench.tasks.helmholtz1d import Helmholtz1DTask
from pinn_bench.tasks.hydronet_energy_graph_regression import HydronetEnergyGraphRegressionTask
from pinn_bench.tasks.navier_stokes_2d_inverse_viscosity import NavierStokes2DInverseViscosityTask
from pinn_bench.tasks.navier_stokes_2d_operator_rollout import NavierStokes2DOperatorRolloutTask
from pinn_bench.tasks.poisson2d import Poisson2DTask
from pinn_bench.tasks.poisson2d_field import Poisson2DFieldTask
from pinn_bench.tasks.reaction_diffusion_operator_rollout import ReactionDiffusionOperatorRolloutTask
from pinn_bench.tasks.shallowwater2d_operator_rollout import ShallowWater2DOperatorRolloutTask
from pinn_bench.tasks.slstr_cloud_mask_segmentation import SlstrCloudMaskSegmentationTask
from pinn_bench.tasks.toy import ToyTask
from pinn_bench.tasks.wave1d import Wave1DTask
from pinn_bench.tasks.wave1d_field import Wave1DFieldTask

__all__ = [
    "BaseTask",
    "ConditionBatch",
    "EvaluationBatch",
    "FieldBatch",
    "SampleBatch",
    "TrainBatches",
    "AllenCahn1DTask",
    "Burgers1DTask",
    "Burgers1DOperatorRolloutTask",
    "Burgers1DOperatorInverseViscosityTask",
    "Burgers1DInverseViscosityTask",
    "Darcy2DInversePermeabilityTask",
    "Heat1DTask",
    "Heat1DFieldTask",
    "Heat1DInverseDiffusivityTask",
    "HamiltonJacobi1DTask",
    "Helmholtz1DTask",
    "HydronetEnergyGraphRegressionTask",
    "NavierStokes2DInverseViscosityTask",
    "NavierStokes2DOperatorRolloutTask",
    "Poisson2DTask",
    "Poisson2DFieldTask",
    "ReactionDiffusionOperatorRolloutTask",
    "ShallowWater2DOperatorRolloutTask",
    "SlstrCloudMaskSegmentationTask",
    "ToyTask",
    "Wave1DTask",
    "Wave1DFieldTask",
]
