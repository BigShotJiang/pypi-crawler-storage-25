"""Heat 1D task using an analytic time-space solution."""

from __future__ import annotations

from math import pi
from typing import Any

import torch
import torch.nn.functional as F

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import BaseTask, EvaluationBatch, SampleBatch, TrainBatches


@register_task("heat1d")
class Heat1DTask(BaseTask):
    """Heat 1D benchmark task on a unit interval and unit time horizon."""

    _BOUNDARY_FAMILIES = {"zero_dirichlet", "affine_dirichlet"}
    _INITIAL_FAMILIES = {"sine_mode_1", "sine_mode_2"}

    def __init__(
        self,
        input_dim: int = 2,
        output_dim: int = 1,
        domain: dict[str, float] | None = None,
        alpha: float = 0.1,
        sampling: dict[str, int] | None = None,
        boundary_family: str = "zero_dirichlet",
        initial_family: str = "sine_mode_1",
        **_: Any,
    ) -> None:
        self.input_dim = int(input_dim)
        self.output_dim = int(output_dim)
        self.domain = {
            "x_min": 0.0,
            "x_max": 1.0,
            "t_min": 0.0,
            "t_max": 1.0,
            **(domain or {}),
        }
        self.alpha = float(alpha)
        self.sampling = {
            "num_interior": 256,
            "num_boundary": 64,
            "num_initial": 64,
            **(sampling or {}),
        }
        self.boundary_family = str(boundary_family)
        self.initial_family = str(initial_family)

        if self.input_dim != 2 or self.output_dim != 1:
            raise ValueError("Heat1DTask expects input_dim=2 and output_dim=1.")
        if self.boundary_family not in self._BOUNDARY_FAMILIES:
            allowed = ", ".join(sorted(self._BOUNDARY_FAMILIES))
            raise ValueError(f"Heat1DTask only supports boundary_family values: {allowed}.")
        if self.initial_family not in self._INITIAL_FAMILIES:
            allowed = ", ".join(sorted(self._INITIAL_FAMILIES))
            raise ValueError(f"Heat1DTask only supports initial_family values: {allowed}.")

    def _sample_x(self, num_samples: int, device: torch.device, interior: bool = False) -> torch.Tensor:
        epsilon = 1e-6 if interior else 0.0
        return torch.rand((num_samples, 1), device=device) * (
            (self.domain["x_max"] - epsilon) - (self.domain["x_min"] + epsilon)
        ) + (self.domain["x_min"] + epsilon)

    def _sample_t(self, num_samples: int, device: torch.device, include_zero: bool = False) -> torch.Tensor:
        epsilon = 0.0 if include_zero else 1e-6
        return torch.rand((num_samples, 1), device=device) * (
            (self.domain["t_max"] - epsilon) - (self.domain["t_min"] + epsilon)
        ) + (self.domain["t_min"] + epsilon)

    def _mode_number(self) -> int:
        return 1 if self.initial_family == "sine_mode_1" else 2

    def _boundary_lift(self, x: torch.Tensor) -> torch.Tensor:
        if self.boundary_family == "zero_dirichlet":
            return torch.zeros_like(x)
        return x

    def _transient_component(self, x: torch.Tensor, t: torch.Tensor) -> torch.Tensor:
        mode_number = self._mode_number()
        return torch.sin(mode_number * pi * x) * torch.exp(-self.alpha * ((mode_number * pi) ** 2) * t)

    def exact_solution(self, inputs: torch.Tensor) -> torch.Tensor:
        x = inputs[:, :1]
        t = inputs[:, 1:2]
        return self._boundary_lift(x) + self._transient_component(x, t)

    def _physics_residual(self, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        interior_inputs = inputs.clone().detach().requires_grad_(True)
        predictions = model(interior_inputs)
        gradients = torch.autograd.grad(
            outputs=predictions,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(predictions),
            create_graph=True,
            retain_graph=True,
        )[0]
        u_x = gradients[:, :1]
        u_t = gradients[:, 1:2]
        u_xx = torch.autograd.grad(
            outputs=u_x,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(u_x),
            create_graph=True,
            retain_graph=True,
        )[0][:, :1]
        return u_t - self.alpha * u_xx

    def _initial_condition(self, x: torch.Tensor) -> torch.Tensor:
        return self._boundary_lift(x) + torch.sin(self._mode_number() * pi * x)

    def _boundary_diagnostic_batch(self, device: torch.device, num_points: int = 128) -> tuple[torch.Tensor, torch.Tensor]:
        count = max(2, num_points // 2)
        t = torch.linspace(self.domain["t_min"], self.domain["t_max"], steps=count, device=device).reshape(-1, 1)
        left_inputs = torch.cat(
            [torch.full((count, 1), float(self.domain["x_min"]), device=device), t],
            dim=1,
        )
        right_inputs = torch.cat(
            [torch.full((count, 1), float(self.domain["x_max"]), device=device), t],
            dim=1,
        )
        inputs = torch.cat([left_inputs, right_inputs], dim=0)
        targets = self._boundary_lift(inputs[:, :1])
        return inputs, targets

    def _initial_diagnostic_batch(self, device: torch.device, num_points: int = 128) -> tuple[torch.Tensor, torch.Tensor]:
        x = torch.linspace(self.domain["x_min"], self.domain["x_max"], steps=max(2, num_points), device=device).reshape(-1, 1)
        t = torch.full((x.shape[0], 1), float(self.domain["t_min"]), device=device)
        inputs = torch.cat([x, t], dim=1)
        return inputs, self._initial_condition(x)

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        num_interior = int(self.sampling["num_interior"])
        num_boundary = int(self.sampling["num_boundary"])
        num_initial = int(self.sampling["num_initial"])

        interior_inputs = torch.cat(
            [
                self._sample_x(num_interior, device=device, interior=True),
                self._sample_t(num_interior, device=device, include_zero=False),
            ],
            dim=1,
        )

        half_boundary = num_boundary // 2
        left_t = self._sample_t(half_boundary, device=device, include_zero=True)
        right_t = self._sample_t(num_boundary - half_boundary, device=device, include_zero=True)
        left_x = torch.full((half_boundary, 1), float(self.domain["x_min"]), device=device)
        right_x = torch.full((num_boundary - half_boundary, 1), float(self.domain["x_max"]), device=device)
        boundary_inputs = torch.cat(
            [torch.cat([left_x, left_t], dim=1), torch.cat([right_x, right_t], dim=1)],
            dim=0,
        )
        boundary_targets = self._boundary_lift(boundary_inputs[:, :1])

        initial_x = self._sample_x(num_initial, device=device, interior=False)
        initial_t = torch.full((num_initial, 1), float(self.domain["t_min"]), device=device)
        initial_inputs = torch.cat([initial_x, initial_t], dim=1)
        initial_targets = self._initial_condition(initial_x)

        return TrainBatches(
            interior=SampleBatch(
                inputs=interior_inputs,
                metadata={
                    "kind": "interior",
                    "boundary_family": self.boundary_family,
                    "initial_family": self.initial_family,
                },
            ),
            boundary=SampleBatch(
                inputs=boundary_inputs,
                targets=boundary_targets,
                metadata={"kind": "boundary", "boundary_family": self.boundary_family},
            ),
            initial=SampleBatch(
                inputs=initial_inputs,
                targets=initial_targets,
                metadata={"kind": "initial", "initial_family": self.initial_family},
            ),
            supervision=None,
            metadata={
                "task_name": "heat1d",
                "alpha": self.alpha,
                "boundary_family": self.boundary_family,
                "initial_family": self.initial_family,
            },
        )

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        del num_samples, grid_y
        resolved_grid_x = int(grid_x or 128)
        resolved_grid_t = int(grid_t or 64)

        x = torch.linspace(self.domain["x_min"], self.domain["x_max"], steps=resolved_grid_x, device=device)
        t = torch.linspace(self.domain["t_min"], self.domain["t_max"], steps=resolved_grid_t, device=device)
        tt, xx = torch.meshgrid(t, x, indexing="ij")
        inputs = torch.stack([xx.reshape(-1), tt.reshape(-1)], dim=1)
        targets = self.exact_solution(inputs)
        return EvaluationBatch(
            inputs=inputs,
            targets=targets,
            name="heat1d_analytic_grid",
            metadata={
                "grid_shape": (resolved_grid_t, resolved_grid_x),
                "alpha": self.alpha,
                "boundary_family": self.boundary_family,
                "initial_family": self.initial_family,
            },
        )

    def compute_loss_terms(
        self,
        model: torch.nn.Module,
        batches: TrainBatches,
    ) -> dict[str, torch.Tensor]:
        if batches.interior is None or batches.boundary is None or batches.initial is None:
            raise ValueError("Heat1DTask requires interior, boundary, and initial batches.")
        if batches.boundary.targets is None or batches.initial.targets is None:
            raise ValueError("Heat1DTask boundary and initial batches require targets.")

        residual = self._physics_residual(model, batches.interior.inputs)
        physics_loss = F.mse_loss(residual, torch.zeros_like(residual))

        boundary_predictions = model(batches.boundary.inputs)
        boundary_loss = F.mse_loss(boundary_predictions, batches.boundary.targets)

        initial_predictions = model(batches.initial.inputs)
        initial_loss = F.mse_loss(initial_predictions, batches.initial.targets)

        return {
            "physics": physics_loss,
            "boundary": boundary_loss,
            "initial": initial_loss,
        }

    def compute_residual(self, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        return self._physics_residual(model, inputs).detach()

    def compute_metric(
        self,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        del predictions, targets
        if metric_name == "residual_metric":
            residual = self._physics_residual(model, batch.inputs)
            return float(torch.mean(residual**2).detach().item())
        if metric_name == "bc_violation":
            inputs, target_values = self._boundary_diagnostic_batch(batch.inputs.device)
            values = model(inputs)
            return float(F.mse_loss(values, target_values).detach().item())
        if metric_name == "ic_violation":
            inputs, target_values = self._initial_diagnostic_batch(batch.inputs.device)
            values = model(inputs)
            return float(F.mse_loss(values, target_values).detach().item())
        return None
