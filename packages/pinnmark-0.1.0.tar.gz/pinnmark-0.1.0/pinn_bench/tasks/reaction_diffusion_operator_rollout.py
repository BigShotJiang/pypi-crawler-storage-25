"""Operator rollout task over a locked Gray-Scott preview family."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import torch

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import BaseTask, ConditionBatch, EvaluationBatch, FieldBatch, SampleBatch, TrainBatches, weighted_mse_loss


def _resolve_dataset_root(raw: str | Path | None) -> Path:
    if raw is None or not str(raw).strip():
        return (
            Path.cwd()
            / "examples"
            / "superbench_v3_preview"
            / "shared_datasets"
            / "reaction_diffusion_operator_rollout_locked_gray_scott_preview_family_v1"
        ).resolve()
    candidate = Path(str(raw)).expanduser()
    if not candidate.is_absolute():
        candidate = (Path.cwd() / candidate).resolve()
    return candidate


@register_task("reaction_diffusion_operator_rollout")
class ReactionDiffusionOperatorRolloutTask(BaseTask):
    """Field-output rollout task over a locked two-trajectory Gray-Scott preview family."""

    task_mode = "field"
    supports_operator = True
    _SCENARIO_FAMILIES = {
        "gray_scott": "locked_gray_scott_preview_family_v1",
        "gray_scott_shifted": "locked_gray_scott_shifted_preview_family_v1",
    }

    def __init__(
        self,
        input_dim: int = 3,
        output_dim: int = 2,
        dataset_variant: str = "locked_gray_scott_preview_family_v1",
        dataset_root: str | None = None,
        scenario_family: str | None = None,
        history_steps: int = 1,
        rollout_stride: int = 1,
        forecast_steps: int = 8,
        trajectory_ids: list[int] | None = None,
        field_grid: dict[str, int] | None = None,
        **_: Any,
    ) -> None:
        self.input_dim = int(input_dim)
        self.output_dim = int(output_dim)
        if self.input_dim != 3:
            raise ValueError("ReactionDiffusionOperatorRolloutTask requires input_dim=3 for (x, y, t_future).")
        if self.output_dim != 2:
            raise ValueError("ReactionDiffusionOperatorRolloutTask requires output_dim=2 for two-channel rollout.")

        self.dataset_variant = str(dataset_variant)
        self.dataset_root = _resolve_dataset_root(dataset_root)
        inferred_family = self._scenario_family_from_variant(self.dataset_variant)
        self.scenario_family = inferred_family if scenario_family is None else str(scenario_family)
        if self.scenario_family not in self._SCENARIO_FAMILIES:
            allowed = ", ".join(sorted(self._SCENARIO_FAMILIES))
            raise ValueError(f"scenario_family must be one of {allowed}; got {self.scenario_family!r}.")
        if self._SCENARIO_FAMILIES[self.scenario_family] != self.dataset_variant:
            raise ValueError(
                "dataset_variant and scenario_family must describe the same locked operator family; "
                f"got dataset_variant={self.dataset_variant!r} and scenario_family={self.scenario_family!r}."
            )
        self.history_steps = int(history_steps)
        self.rollout_stride = int(rollout_stride)
        self.forecast_steps = int(forecast_steps)
        self.field_grid = {
            "grid_x": 32,
            "grid_y": 32,
            "grid_t": 8,
            **(field_grid or {}),
        }
        self.requested_trajectory_ids = [int(value) for value in (trajectory_ids or [0, 1])]
        self._condition_feature_names = [
            feature
            for index in range(self.history_steps)
            for feature in (f"u_t{index:02d}", f"v_t{index:02d}")
        ]
        self._family_payload_cache: dict[str, dict[str, np.ndarray | str]] = {}
        self._selected_indices_cache: dict[str, list[int]] = {}
        self._selected_indices(self._get_family_payload())

    @classmethod
    def _scenario_family_from_variant(cls, dataset_variant: str) -> str:
        for scenario_family, variant in cls._SCENARIO_FAMILIES.items():
            if dataset_variant == variant:
                return scenario_family
        allowed = ", ".join(sorted(cls._SCENARIO_FAMILIES.values()))
        raise ValueError(f"dataset_variant must be one of {allowed}; got {dataset_variant!r}.")

    def _active_dataset_variant(self) -> str:
        scenario_family = str(self.scenario_family)
        if scenario_family not in self._SCENARIO_FAMILIES:
            allowed = ", ".join(sorted(self._SCENARIO_FAMILIES))
            raise ValueError(f"scenario_family must be one of {allowed}; got {scenario_family!r}.")
        return self._SCENARIO_FAMILIES[scenario_family]

    def _dataset_payload_path(self, dataset_variant: str | None = None) -> Path:
        resolved_variant = self.dataset_variant if dataset_variant is None else str(dataset_variant)
        return self.dataset_root / f"{resolved_variant}.npz"

    def _load_family_payload(self, dataset_variant: str) -> dict[str, np.ndarray | str]:
        payload_path = self._dataset_payload_path(dataset_variant)
        if not payload_path.exists():
            raise FileNotFoundError(f"Expected reaction-diffusion operator dataset at {payload_path}.")
        loaded = np.load(payload_path, allow_pickle=False)
        x = np.asarray(loaded["x"], dtype=np.float32)
        y = np.asarray(loaded["y"], dtype=np.float32)
        t = np.asarray(loaded["t"], dtype=np.float32)
        state = np.asarray(loaded["state"], dtype=np.float32)
        trajectory_ids = np.asarray(loaded["trajectory_ids"], dtype=np.int64)
        family_id = str(loaded["family_id"].tolist())
        scenario_family = str(loaded["scenario_family"].tolist())
        source_tag = str(loaded["source_tag"].tolist())
        if state.ndim != 5:
            raise ValueError("Expected reaction-diffusion operator payload `state` to have shape (family, time, y, x, channel).")
        if tuple(state.shape) != (len(trajectory_ids), len(t), len(y), len(x), self.output_dim):
            raise ValueError("Reaction-diffusion operator payload shapes are inconsistent.")
        if int(self.field_grid["grid_x"]) != int(len(x)):
            raise ValueError(
                f"Reaction-diffusion operator dataset uses grid_x={len(x)} but task was configured for grid_x={self.field_grid['grid_x']}."
            )
        if int(self.field_grid["grid_y"]) != int(len(y)):
            raise ValueError(
                f"Reaction-diffusion operator dataset uses grid_y={len(y)} but task was configured for grid_y={self.field_grid['grid_y']}."
            )
        if len(t) < self.history_steps + (self.forecast_steps - 1) * self.rollout_stride + 1:
            raise ValueError("Reaction-diffusion operator payload does not contain enough time steps for the requested rollout horizon.")
        if int(self.field_grid["grid_t"]) != self.forecast_steps:
            raise ValueError(
                "Reaction-diffusion operator task requires field_grid.grid_t == forecast_steps; "
                f"got {self.field_grid['grid_t']} and {self.forecast_steps}."
            )
        return {
            "x": x,
            "y": y,
            "t": t,
            "state": state,
            "trajectory_ids": trajectory_ids,
            "family_id": family_id,
            "scenario_family": scenario_family,
            "source_tag": source_tag,
        }

    def _get_family_payload(self, scenario_family: str | None = None) -> dict[str, np.ndarray | str]:
        resolved_family = str(self.scenario_family if scenario_family is None else scenario_family)
        dataset_variant = self._SCENARIO_FAMILIES.get(resolved_family)
        if dataset_variant is None:
            allowed = ", ".join(sorted(self._SCENARIO_FAMILIES))
            raise ValueError(f"scenario_family must be one of {allowed}; got {resolved_family!r}.")
        cached = self._family_payload_cache.get(dataset_variant)
        if cached is None:
            cached = self._load_family_payload(dataset_variant)
            self._family_payload_cache[dataset_variant] = cached
        return cached

    def _resolve_trajectory_indices(self, payload: dict[str, np.ndarray | str]) -> list[int]:
        available = [int(value) for value in payload["trajectory_ids"]]
        indices: list[int] = []
        for requested in self.requested_trajectory_ids:
            matches = [index for index, available_value in enumerate(available) if available_value == requested]
            if not matches:
                raise ValueError(
                    f"Requested trajectory_id {requested} is not available in dataset family {available}."
                )
            indices.append(matches[0])
        return indices

    def _selected_indices(self, payload: dict[str, np.ndarray | str]) -> list[int]:
        family_id = str(payload["family_id"])
        cached = self._selected_indices_cache.get(family_id)
        if cached is None:
            cached = self._resolve_trajectory_indices(payload)
            self._selected_indices_cache[family_id] = cached
        return cached

    @property
    def trajectory_ids(self) -> list[int]:
        payload = self._get_family_payload()
        raw = payload["trajectory_ids"]
        return [int(raw[index]) for index in self._selected_indices(payload)]

    def _resolve_future_indices(self) -> list[int]:
        return [self.history_steps + index * self.rollout_stride for index in range(self.forecast_steps)]

    @staticmethod
    def _resolve_condition_inputs(batch: SampleBatch, batches: TrainBatches) -> torch.Tensor | None:
        condition_inputs = batch.metadata.get("condition_inputs")
        if condition_inputs is not None:
            return condition_inputs
        condition_batch = batches.metadata.get("condition_batch")
        if isinstance(condition_batch, ConditionBatch):
            return condition_batch.inputs
        if isinstance(condition_batch, dict) and isinstance(condition_batch.get("inputs"), torch.Tensor):
            return condition_batch["inputs"]
        return None

    @staticmethod
    def _predict_field(*, model: torch.nn.Module, batch: SampleBatch, batches: TrainBatches) -> torch.Tensor:
        condition_inputs = ReactionDiffusionOperatorRolloutTask._resolve_condition_inputs(batch, batches)
        if hasattr(model, "forward_field"):
            predictions = model.forward_field(
                condition_inputs=condition_inputs,
                query_inputs=batch.inputs,
                metadata=batch.metadata,
            )
        elif bool(getattr(model, "supports_flattened_field", False)):
            predictions = model(batch.inputs)
        else:
            raise ValueError("ReactionDiffusionOperatorRolloutTask requires an operator-ready model.")
        if predictions.shape == batch.targets.shape:
            return predictions
        if predictions.numel() == batch.targets.numel():
            return predictions.reshape_as(batch.targets)
        raise ValueError(
            f"Field prediction shape {tuple(predictions.shape)} does not match targets {tuple(batch.targets.shape)}."
        )

    def _build_field_batch(self, *, device: torch.device) -> FieldBatch:
        payload = self._get_family_payload()
        active_dataset_variant = self._active_dataset_variant()
        selected_indices = self._selected_indices(payload)
        x = torch.tensor(payload["x"], dtype=torch.float32, device=device)
        y = torch.tensor(payload["y"], dtype=torch.float32, device=device)
        t = torch.tensor(payload["t"], dtype=torch.float32, device=device)
        state = torch.tensor(payload["state"], dtype=torch.float32, device=device)
        future_indices = self._resolve_future_indices()

        query_batches: list[torch.Tensor] = []
        target_batches: list[torch.Tensor] = []
        condition_batches: list[torch.Tensor] = []
        family_trajectory_ids: list[int] = []

        for family_index in selected_indices:
            trajectory_id = int(payload["trajectory_ids"][family_index])
            history = state[family_index, : self.history_steps, :, :, :]
            future = state[family_index, future_indices, :, :, :]
            future_t = t[future_indices]
            tt, yy, xx = torch.meshgrid(future_t, y, x, indexing="ij")
            query_inputs = torch.stack([xx.reshape(-1), yy.reshape(-1), tt.reshape(-1)], dim=1)
            history_features = history.permute(1, 2, 0, 3).reshape(len(y), len(x), self.history_steps * self.output_dim)
            history_per_query = history_features.unsqueeze(0).expand(self.forecast_steps, -1, -1, -1).reshape(
                -1,
                self.history_steps * self.output_dim,
            )

            query_batches.append(query_inputs)
            target_batches.append(future.reshape(-1, self.output_dim))
            condition_batches.append(history_per_query)
            family_trajectory_ids.append(trajectory_id)

        inputs = torch.cat(query_batches, dim=0)
        targets = torch.cat(target_batches, dim=0)
        condition_inputs = torch.cat(condition_batches, dim=0)
        family_batch_size = len(selected_indices)
        grid_t = int(self.field_grid["grid_t"])
        grid_y = int(self.field_grid["grid_y"])
        grid_x = int(self.field_grid["grid_x"])
        return FieldBatch(
            inputs=inputs,
            targets=targets,
            condition_inputs=condition_inputs,
            metadata={
                "grid_shape": (grid_t, grid_y, grid_x),
                "family_batch_size": family_batch_size,
                "field_shape": (grid_t, grid_y, grid_x, self.output_dim),
                "family_field_shape": (family_batch_size, grid_t, grid_y, grid_x, self.output_dim),
                "condition_shape": tuple(condition_inputs.shape),
                "condition_feature_names": list(self._condition_feature_names),
                "evaluation_mode": "field",
                "task_mode": "field",
                "dataset_variant": active_dataset_variant,
                "dataset_root": str(self.dataset_root),
                "family_id": str(payload["family_id"]),
                "scenario_family": str(payload["scenario_family"]),
                "source_tag": str(payload["source_tag"]),
                "trajectory_ids": list(family_trajectory_ids),
                "history_steps": self.history_steps,
                "rollout_stride": self.rollout_stride,
                "forecast_steps": self.forecast_steps,
                "channel_names": ["u", "v"],
            },
        )

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        field_batch = self._build_field_batch(device=device)
        condition_batch = ConditionBatch(
            inputs=field_batch.condition_inputs,
            metadata={
                "condition_shape": tuple(field_batch.condition_inputs.shape),
                "condition_feature_names": list(self._condition_feature_names),
            },
        )
        supervision = field_batch.to_sample_batch()
        return TrainBatches(
            supervision=supervision,
            metadata={
                "task_name": "reaction_diffusion_operator_rollout",
                "task_mode": "field",
                "grid_shape": supervision.metadata["grid_shape"],
                "family_batch_size": supervision.metadata["family_batch_size"],
                "field_shape": supervision.metadata["field_shape"],
                "family_field_shape": supervision.metadata["family_field_shape"],
                "condition_batch": condition_batch,
                "trajectory_ids": supervision.metadata["trajectory_ids"],
                "history_steps": self.history_steps,
                "rollout_stride": self.rollout_stride,
                "forecast_steps": self.forecast_steps,
                "dataset_variant": supervision.metadata["dataset_variant"],
                "family_id": supervision.metadata["family_id"],
                "scenario_family": supervision.metadata["scenario_family"],
                "channel_names": supervision.metadata["channel_names"],
            },
        )

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        del num_samples
        if grid_x is not None and int(grid_x) != int(self.field_grid["grid_x"]):
            raise ValueError("ReactionDiffusionOperatorRolloutTask does not support grid_x overrides outside the locked family grid.")
        if grid_y is not None and int(grid_y) != int(self.field_grid["grid_y"]):
            raise ValueError("ReactionDiffusionOperatorRolloutTask does not support grid_y overrides outside the locked family grid.")
        if grid_t is not None and int(grid_t) != int(self.field_grid["grid_t"]):
            raise ValueError("ReactionDiffusionOperatorRolloutTask does not support grid_t overrides outside the locked family rollout horizon.")
        field_batch = self._build_field_batch(device=device)
        return EvaluationBatch(
            inputs=field_batch.inputs,
            targets=field_batch.targets,
            name="reaction_diffusion_operator_rollout_grid",
            metadata={
                **field_batch.metadata,
                "condition_inputs": field_batch.condition_inputs,
            },
        )

    def compute_loss_terms(self, model: torch.nn.Module, batches: TrainBatches) -> dict[str, torch.Tensor]:
        if batches.supervision is None or batches.supervision.targets is None:
            raise ValueError("ReactionDiffusionOperatorRolloutTask requires a target-bearing supervision batch.")
        predictions = self._predict_field(model=model, batch=batches.supervision, batches=batches)
        return {
            "field_supervision": weighted_mse_loss(
                predictions,
                batches.supervision.targets,
                weights=batches.supervision.weights,
            ),
        }
