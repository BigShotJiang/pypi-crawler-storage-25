"""One-dimensional Helmholtz task with a manufactured analytic solution."""

from __future__ import annotations

from math import pi

import torch
import torch.nn.functional as F

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import BaseTask, EvaluationBatch, SampleBatch, TrainBatches


@register_task("helmholtz1d")
class Helmholtz1DTask(BaseTask):
    """Manufactured 1D Helmholtz equation with Dirichlet boundaries.

    The task solves ``u_xx + k^2 u = f`` on ``x in [x_min, x_max]`` with the
    analytic reference solution ``u(x) = sin(pi x)``.
    """

    def __init__(
        self,
        *,
        input_dim: int,
        output_dim: int,
        domain: dict[str, float],
        wavenumber: float = 2.0,
        sampling: dict[str, int] | None = None,
    ) -> None:
        if input_dim != 1 or output_dim != 1:
            raise ValueError("Helmholtz1DTask expects input_dim=1 and output_dim=1.")
        self.domain = {
            "x_min": float(domain["x_min"]),
            "x_max": float(domain["x_max"]),
        }
        self.wavenumber = float(wavenumber)
        self.sampling = {
            "num_interior": 128,
            "num_boundary": 32,
            **({} if sampling is None else {key: int(value) for key, value in sampling.items()}),
        }

    def _sample_x(self, num_samples: int, *, device: torch.device, interior: bool = False) -> torch.Tensor:
        epsilon = 1e-6 if interior else 0.0
        return torch.rand((num_samples, 1), device=device) * (
            (self.domain["x_max"] - epsilon) - (self.domain["x_min"] + epsilon)
        ) + (self.domain["x_min"] + epsilon)

    def exact_solution(self, inputs: torch.Tensor) -> torch.Tensor:
        x = inputs[:, :1]
        return torch.sin(pi * x)

    def _physics_residual(self, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        interior_inputs = inputs.clone().detach().requires_grad_(True)
        predictions = model(interior_inputs)
        gradients = torch.autograd.grad(
            outputs=predictions,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(predictions),
            create_graph=True,
            retain_graph=True,
        )[0]
        u_x = gradients[:, :1]
        u_xx = torch.autograd.grad(
            outputs=u_x,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(u_x),
            create_graph=True,
            retain_graph=True,
        )[0][:, :1]
        forcing = self._forcing_term(interior_inputs)
        return u_xx + (self.wavenumber**2) * predictions - forcing

    def _boundary_diagnostic_batch(self, device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
        inputs = torch.tensor(
            [[self.domain["x_min"]], [self.domain["x_max"]]],
            dtype=torch.float32,
            device=device,
        )
        return inputs, self.exact_solution(inputs)

    def _forcing_term(self, inputs: torch.Tensor) -> torch.Tensor:
        solution = self.exact_solution(inputs)
        return ((self.wavenumber**2) - (pi**2)) * solution

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        num_interior = int(self.sampling["num_interior"])
        num_boundary = int(self.sampling["num_boundary"])

        interior_inputs = self._sample_x(num_interior, device=device, interior=True)
        left_count = num_boundary // 2
        right_count = num_boundary - left_count
        boundary_inputs = torch.cat(
            [
                torch.full((left_count, 1), float(self.domain["x_min"]), device=device),
                torch.full((right_count, 1), float(self.domain["x_max"]), device=device),
            ],
            dim=0,
        )
        boundary_targets = self.exact_solution(boundary_inputs)
        return TrainBatches(
            interior=SampleBatch(inputs=interior_inputs, metadata={"kind": "interior"}),
            boundary=SampleBatch(inputs=boundary_inputs, targets=boundary_targets, metadata={"kind": "boundary"}),
            supervision=None,
            metadata={"task_name": "helmholtz1d", "wavenumber": self.wavenumber},
        )

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        del grid_t, grid_y
        resolved_grid_x = int(grid_x or num_samples or 128)
        x = torch.linspace(self.domain["x_min"], self.domain["x_max"], steps=resolved_grid_x, device=device).reshape(-1, 1)
        targets = self.exact_solution(x)
        return EvaluationBatch(
            inputs=x,
            targets=targets,
            name="helmholtz1d_analytic_grid",
            metadata={"grid_shape": (resolved_grid_x,), "wavenumber": self.wavenumber},
        )

    def compute_loss_terms(self, model: torch.nn.Module, batches: TrainBatches) -> dict[str, torch.Tensor]:
        if batches.interior is None or batches.boundary is None:
            raise ValueError("Helmholtz1DTask requires interior and boundary batches.")
        if batches.boundary.targets is None:
            raise ValueError("Helmholtz1DTask boundary batch requires targets.")

        residual = self._physics_residual(model, batches.interior.inputs)
        physics_loss = F.mse_loss(residual, torch.zeros_like(residual))

        boundary_predictions = model(batches.boundary.inputs)
        boundary_loss = F.mse_loss(boundary_predictions, batches.boundary.targets)
        return {
            "physics": physics_loss,
            "boundary": boundary_loss,
        }

    def compute_residual(self, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        return self._physics_residual(model, inputs).detach()

    def compute_metric(
        self,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        del predictions, targets
        if metric_name == "residual_metric":
            residual = self._physics_residual(model, batch.inputs)
            return float(torch.mean(residual**2).detach().item())
        if metric_name == "bc_violation":
            inputs, target_values = self._boundary_diagnostic_batch(batch.inputs.device)
            values = model(inputs)
            return float(F.mse_loss(values, target_values).detach().item())
        return None
