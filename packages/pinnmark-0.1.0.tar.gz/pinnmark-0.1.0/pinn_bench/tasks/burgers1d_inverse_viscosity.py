"""Inverse Burgers task that learns viscosity from benchmark-governed evidence surfaces."""

from __future__ import annotations

from dataclasses import replace
from math import pi
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import EvaluationBatch, SampleBatch, TrainBatches
from pinn_bench.tasks.burgers1d import Burgers1DTask


@register_task("burgers1d_inverse_viscosity")
class Burgers1DInverseViscosityTask(Burgers1DTask):
    """Inverse Burgers benchmark with a learnable viscosity parameter."""

    def __init__(
        self,
        input_dim: int = 2,
        output_dim: int = 1,
        domain: dict[str, float] | None = None,
        true_viscosity: float = 0.01 / pi,
        initial_viscosity: float | None = None,
        sampling: dict[str, int] | None = None,
        reference: dict[str, int] | None = None,
        **kwargs: Any,
    ) -> None:
        sampling_payload = dict(sampling or {})
        num_supervision = int(sampling_payload.pop("num_supervision", 64))
        super().__init__(
            input_dim=input_dim,
            output_dim=output_dim,
            domain=domain,
            viscosity=true_viscosity,
            sampling=sampling_payload,
            reference=reference,
            **kwargs,
        )
        self.true_viscosity = float(true_viscosity)
        self.initial_viscosity = float(initial_viscosity if initial_viscosity is not None else self.true_viscosity * 1.5)
        if self.initial_viscosity <= 0.0:
            raise ValueError("initial_viscosity must be positive.")
        self.sampling["num_supervision"] = num_supervision
        self._log_viscosity = torch.nn.Parameter(torch.tensor(np.log(self.initial_viscosity), dtype=torch.float32))

    def trainable_parameters(self):
        return (self._log_viscosity,)

    def _current_viscosity_tensor(self) -> torch.Tensor:
        return torch.exp(self._log_viscosity)

    def current_viscosity(self) -> float:
        return float(self._current_viscosity_tensor().detach().item())

    def _physics_residual(self, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        interior_inputs = inputs.clone().detach().requires_grad_(True)
        interior_predictions = model(interior_inputs)
        gradients = torch.autograd.grad(
            outputs=interior_predictions,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(interior_predictions),
            create_graph=True,
            retain_graph=True,
        )[0]
        u_x = gradients[:, :1]
        u_t = gradients[:, 1:2]
        second_gradients = torch.autograd.grad(
            outputs=u_x,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(u_x),
            create_graph=True,
            retain_graph=True,
        )[0]
        u_xx = second_gradients[:, :1]
        return u_t + interior_predictions * u_x - self._current_viscosity_tensor() * u_xx

    def _sample_supervision_batch(self, device: torch.device) -> SampleBatch:
        reference_x, reference_t, reference_u = self._load_reference_solution()
        x_indices = torch.randint(reference_x.shape[0], size=(int(self.sampling["num_supervision"]),), device=device)
        t_indices = torch.randint(reference_t.shape[0], size=(int(self.sampling["num_supervision"]),), device=device)
        x = torch.tensor(reference_x, dtype=torch.float32, device=device).index_select(0, x_indices).reshape(-1, 1)
        t = torch.tensor(reference_t, dtype=torch.float32, device=device).index_select(0, t_indices).reshape(-1, 1)
        inputs = torch.cat([x, t], dim=1)
        targets_np = reference_u[t_indices.cpu().numpy(), x_indices.cpu().numpy()].reshape(-1, 1)
        targets = torch.tensor(targets_np, dtype=torch.float32, device=device)
        return SampleBatch(
            inputs=inputs,
            targets=targets,
            metadata={
                "kind": "supervision",
                "parameter_name": "viscosity",
                "true_parameter_value": self.true_viscosity,
                "grid_axes": {"x": 0, "t": 1},
                "domain_bounds": {
                    "x": (float(self.domain["x_min"]), float(self.domain["x_max"])),
                    "t": (float(self.domain["t_min"]), float(self.domain["t_max"])),
                },
            },
        )

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        base = super().sample_train_batches(device=device)
        supervision = self._sample_supervision_batch(device=device)
        metadata = {
            **dict(base.metadata),
            "inverse_parameter_name": "viscosity",
            "inverse_target_family": "coefficient",
            "true_parameter_value": self.true_viscosity,
            "estimated_parameter_value": self.current_viscosity(),
            "supervision_source": "packaged_reference_surface",
            "identifiability_metadata": {
                "requires_supervision": True,
                "supervision_source": "packaged_reference_surface",
                "parameter_name": "viscosity",
            },
        }
        return replace(base, supervision=supervision, metadata=metadata)

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        base = super().sample_evaluation_batch(
            device=device,
            num_samples=num_samples,
            grid_x=grid_x,
            grid_t=grid_t,
            grid_y=grid_y,
        )
        metadata = {
            **dict(base.metadata),
            "inverse_parameter_name": "viscosity",
            "inverse_target_family": "coefficient",
            "true_parameter_value": self.true_viscosity,
            "estimated_parameter_value": self.current_viscosity(),
            "supervision_source": "packaged_reference_surface",
            "identifiability_metadata": {
                "requires_supervision": True,
                "parameter_name": "viscosity",
            },
        }
        return replace(base, metadata=metadata)

    def compute_loss_terms(
        self,
        model: torch.nn.Module,
        batches: TrainBatches,
    ) -> dict[str, torch.Tensor]:
        if batches.supervision is None or batches.supervision.targets is None:
            raise ValueError("Burgers1DInverseViscosityTask requires a supervision batch with targets.")
        loss_terms = super().compute_loss_terms(model=model, batches=batches)
        supervision_predictions = model(batches.supervision.inputs)
        loss_terms["supervision"] = F.mse_loss(supervision_predictions, batches.supervision.targets)
        return loss_terms

    def compute_metric(
        self,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        estimate = self.current_viscosity()
        if metric_name == "parameter_error":
            return float(abs(estimate - self.true_viscosity))
        if metric_name == "parameter_relative_error":
            return float(abs(estimate - self.true_viscosity) / max(abs(self.true_viscosity), 1e-12))
        return super().compute_metric(
            metric_name,
            model=model,
            batch=batch,
            predictions=predictions,
            targets=targets,
        )
