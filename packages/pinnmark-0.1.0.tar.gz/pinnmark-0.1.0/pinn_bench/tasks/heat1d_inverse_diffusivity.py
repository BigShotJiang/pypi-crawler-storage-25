"""Inverse heat task that learns diffusivity from benchmark-governed evidence surfaces."""

from __future__ import annotations

from dataclasses import replace
from math import log
from typing import Any

import torch
import torch.nn.functional as F

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import EvaluationBatch, SampleBatch, TrainBatches
from pinn_bench.tasks.heat1d import Heat1DTask


@register_task("heat1d_inverse_diffusivity")
class Heat1DInverseDiffusivityTask(Heat1DTask):
    """Inverse heat benchmark with a learnable diffusivity parameter."""

    def __init__(
        self,
        input_dim: int = 2,
        output_dim: int = 1,
        domain: dict[str, float] | None = None,
        alpha: float = 0.1,
        initial_alpha: float | None = None,
        sampling: dict[str, int] | None = None,
        **kwargs: Any,
    ) -> None:
        sampling_payload = dict(sampling or {})
        num_supervision = int(sampling_payload.pop("num_supervision", 64))
        super().__init__(
            input_dim=input_dim,
            output_dim=output_dim,
            domain=domain,
            alpha=alpha,
            sampling=sampling_payload,
            **kwargs,
        )
        self.true_alpha = float(alpha)
        self.initial_alpha = float(initial_alpha if initial_alpha is not None else self.true_alpha * 1.5)
        if self.initial_alpha <= 0.0:
            raise ValueError("initial_alpha must be positive.")
        self.sampling["num_supervision"] = num_supervision
        self._log_alpha = torch.nn.Parameter(torch.tensor(log(self.initial_alpha), dtype=torch.float32))

    def trainable_parameters(self):
        return (self._log_alpha,)

    def _current_alpha_tensor(self) -> torch.Tensor:
        return torch.exp(self._log_alpha)

    def current_alpha(self) -> float:
        return float(self._current_alpha_tensor().detach().item())

    def _physics_residual(self, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        interior_inputs = inputs.clone().detach().requires_grad_(True)
        predictions = model(interior_inputs)
        gradients = torch.autograd.grad(
            outputs=predictions,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(predictions),
            create_graph=True,
            retain_graph=True,
        )[0]
        u_x = gradients[:, :1]
        u_t = gradients[:, 1:2]
        u_xx = torch.autograd.grad(
            outputs=u_x,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(u_x),
            create_graph=True,
            retain_graph=True,
        )[0][:, :1]
        return u_t - self._current_alpha_tensor() * u_xx

    def _sample_supervision_batch(self, device: torch.device) -> SampleBatch:
        num_supervision = int(self.sampling["num_supervision"])
        inputs = torch.cat(
            [
                self._sample_x(num_supervision, device=device, interior=False),
                self._sample_t(num_supervision, device=device, include_zero=True),
            ],
            dim=1,
        )
        targets = self.exact_solution(inputs)
        return SampleBatch(
            inputs=inputs,
            targets=targets,
            metadata={
                "kind": "supervision",
                "parameter_name": "alpha",
                "true_parameter_value": self.true_alpha,
                "grid_axes": {"x": 0, "t": 1},
                "domain_bounds": {
                    "x": (float(self.domain["x_min"]), float(self.domain["x_max"])),
                    "t": (float(self.domain["t_min"]), float(self.domain["t_max"])),
                },
            },
        )

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        base = super().sample_train_batches(device=device)
        supervision = self._sample_supervision_batch(device=device)
        metadata = {
            **dict(base.metadata),
            "inverse_parameter_name": "alpha",
            "inverse_target_family": "coefficient",
            "true_parameter_value": self.true_alpha,
            "estimated_parameter_value": self.current_alpha(),
            "supervision_source": "analytic_solution_surface",
            "identifiability_metadata": {
                "requires_supervision": True,
                "supervision_source": "analytic_solution_surface",
                "parameter_name": "alpha",
            },
        }
        return replace(base, supervision=supervision, metadata=metadata)

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        base = super().sample_evaluation_batch(
            device=device,
            num_samples=num_samples,
            grid_x=grid_x,
            grid_t=grid_t,
            grid_y=grid_y,
        )
        metadata = {
            **dict(base.metadata),
            "inverse_parameter_name": "alpha",
            "inverse_target_family": "coefficient",
            "true_parameter_value": self.true_alpha,
            "estimated_parameter_value": self.current_alpha(),
            "supervision_source": "analytic_solution_surface",
            "identifiability_metadata": {
                "requires_supervision": True,
                "parameter_name": "alpha",
            },
        }
        return replace(base, metadata=metadata)

    def compute_loss_terms(
        self,
        model: torch.nn.Module,
        batches: TrainBatches,
    ) -> dict[str, torch.Tensor]:
        if batches.supervision is None or batches.supervision.targets is None:
            raise ValueError("Heat1DInverseDiffusivityTask requires a supervision batch with targets.")
        loss_terms = super().compute_loss_terms(model=model, batches=batches)
        supervision_predictions = model(batches.supervision.inputs)
        loss_terms["supervision"] = F.mse_loss(supervision_predictions, batches.supervision.targets)
        return loss_terms

    def compute_metric(
        self,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        estimate = self.current_alpha()
        if metric_name == "parameter_error":
            return float(abs(estimate - self.true_alpha))
        if metric_name == "parameter_relative_error":
            return float(abs(estimate - self.true_alpha) / max(abs(self.true_alpha), 1e-12))
        return super().compute_metric(
            metric_name,
            model=model,
            batch=batch,
            predictions=predictions,
            targets=targets,
        )
