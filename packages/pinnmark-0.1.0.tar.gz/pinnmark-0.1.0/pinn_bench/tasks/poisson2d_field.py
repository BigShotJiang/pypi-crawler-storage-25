"""Operator-ready Poisson2D field task for v0.6-preview."""

from __future__ import annotations

from typing import Any

import torch

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import (
    ConditionBatch,
    EvaluationBatch,
    FieldBatch,
    SampleBatch,
    TrainBatches,
    weighted_mse_loss,
)
from pinn_bench.tasks.poisson2d import Poisson2DTask


@register_task("poisson2d_field")
class Poisson2DFieldTask(Poisson2DTask):
    """Poisson2D variant that trains and evaluates on flattened whole-field supervision."""

    task_mode = "field"
    supports_operator = True

    def __init__(
        self,
        input_dim: int = 2,
        output_dim: int = 1,
        domain: dict[str, float] | None = None,
        sampling: dict[str, int] | None = None,
        manufactured_solution: str = "sine_dirichlet",
        field_grid: dict[str, int] | None = None,
        forcing_scale: float = 1.0,
        condition_features: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            input_dim=input_dim,
            output_dim=output_dim,
            domain=domain,
            sampling=sampling,
            manufactured_solution=manufactured_solution,
            **kwargs,
        )
        self.field_grid = {
            "grid_x": 32,
            "grid_y": 32,
            **(field_grid or {}),
        }
        self.forcing_scale = float(forcing_scale)
        self.condition_features = list(condition_features or ["forcing_scale"])

    def exact_solution(self, inputs: torch.Tensor) -> torch.Tensor:
        return self.forcing_scale * super().exact_solution(inputs)

    def _condition_inputs(self, device: torch.device) -> torch.Tensor:
        feature_values = {
            "forcing_scale": self.forcing_scale,
            "x_min": float(self.domain["x_min"]),
            "x_max": float(self.domain["x_max"]),
            "y_min": float(self.domain["y_min"]),
            "y_max": float(self.domain["y_max"]),
            "geometry_family_code": {"regular_square": 0.0, "disk": 1.0, "annulus": 2.0}[self.geometry_family],
            "geometry_outer_radius": float(
                self.geometry_params["disk"]["radius"]
                if self.geometry_family == "disk"
                else self.geometry_params["annulus"]["outer_radius"]
                if self.geometry_family == "annulus"
                else 0.0
            ),
            "geometry_inner_radius": float(
                self.geometry_params["annulus"]["inner_radius"] if self.geometry_family == "annulus" else 0.0
            ),
            "boundary_band_epsilon": float(self.boundary_band_epsilon),
        }
        values = [feature_values[name] for name in self.condition_features]
        return torch.tensor([values], device=device, dtype=torch.float32)

    def _build_field_batch(self, *, device: torch.device, grid_x: int, grid_y: int) -> FieldBatch:
        x = torch.linspace(self.domain["x_min"], self.domain["x_max"], steps=grid_x, device=device)
        y = torch.linspace(self.domain["y_min"], self.domain["y_max"], steps=grid_y, device=device)
        yy, xx = torch.meshgrid(y, x, indexing="ij")
        inputs = torch.stack([xx.reshape(-1), yy.reshape(-1)], dim=1)
        targets = self.exact_solution(inputs)
        valid_domain_mask = self._inside_geometry_mask(inputs).to(device=device, dtype=targets.dtype)
        condition_inputs = self._condition_inputs(device)
        return FieldBatch(
            inputs=inputs,
            targets=targets,
            condition_inputs=condition_inputs,
            weights=valid_domain_mask,
            metadata={
                "grid_shape": (grid_y, grid_x),
                "field_shape": (grid_y, grid_x, self.output_dim),
                "condition_shape": tuple(condition_inputs.shape),
                "condition_feature_names": list(self.condition_features),
                "evaluation_mode": "field",
                "task_mode": "field",
                "forcing_scale": self.forcing_scale,
                "metric_weights": valid_domain_mask,
                "valid_domain_mask": valid_domain_mask,
                "inverse_parameter_name": "field_state",
                "inverse_target_family": "field",
                "inverse_target_type": "field",
                "supervision_source": "analytic_field_surface",
                "diagnostic_status": "field_only",
                "diagnostic_reason": "task_recovers_field_state_only",
                "identifiability_metadata": {
                    "requires_supervision": True,
                    "parameter_name": "field_state",
                    "field_condition_feature_names": list(self.condition_features),
                },
                **self._geometry_metadata(),
            },
        )

    @staticmethod
    def _resolve_condition_inputs(batch: SampleBatch, batches: TrainBatches) -> torch.Tensor | None:
        condition_inputs = batch.metadata.get("condition_inputs")
        if condition_inputs is not None:
            return condition_inputs
        condition_batch = batches.metadata.get("condition_batch")
        if isinstance(condition_batch, ConditionBatch):
            return condition_batch.inputs
        if isinstance(condition_batch, dict) and isinstance(condition_batch.get("inputs"), torch.Tensor):
            return condition_batch["inputs"]
        return None

    @staticmethod
    def _predict_field(*, model: torch.nn.Module, batch: SampleBatch, batches: TrainBatches) -> torch.Tensor:
        condition_inputs = Poisson2DFieldTask._resolve_condition_inputs(batch, batches)
        if hasattr(model, "forward_field"):
            predictions = model.forward_field(
                condition_inputs=condition_inputs,
                query_inputs=batch.inputs,
                metadata=batch.metadata,
            )
        elif bool(getattr(model, "supports_flattened_field", False)):
            predictions = model(batch.inputs)
        else:
            raise ValueError("Poisson2DFieldTask requires an operator-ready model or explicit field fallback support.")
        if predictions.shape == batch.targets.shape:
            return predictions
        if predictions.numel() == batch.targets.numel():
            return predictions.reshape_as(batch.targets)
        raise ValueError(
            f"Field prediction shape {tuple(predictions.shape)} does not match targets {tuple(batch.targets.shape)}."
        )

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        grid_x = int(self.field_grid["grid_x"])
        grid_y = int(self.field_grid["grid_y"])
        field_batch = self._build_field_batch(device=device, grid_x=grid_x, grid_y=grid_y)
        condition_batch = ConditionBatch(
            inputs=field_batch.condition_inputs,
            metadata={
                "condition_shape": tuple(field_batch.condition_inputs.shape),
                "condition_feature_names": list(self.condition_features),
            },
        )
        supervision = field_batch.to_sample_batch()
        return TrainBatches(
            supervision=supervision,
            metadata={
                "task_name": "poisson2d_field",
                "task_mode": "field",
                "field_shape": supervision.metadata["field_shape"],
                "grid_shape": supervision.metadata["grid_shape"],
                "condition_batch": condition_batch,
                "manufactured_solution": self.manufactured_solution,
                "forcing_scale": self.forcing_scale,
                **self._geometry_metadata(),
            },
        )

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        del num_samples, grid_t
        resolved_grid_x = int(grid_x or 64)
        resolved_grid_y = int(grid_y or 64)
        field_batch = self._build_field_batch(device=device, grid_x=resolved_grid_x, grid_y=resolved_grid_y)
        return EvaluationBatch(
            inputs=field_batch.inputs,
            targets=field_batch.targets,
            name="poisson2d_field_grid",
            metadata={
                **field_batch.metadata,
                "condition_inputs": field_batch.condition_inputs,
            },
        )

    def compute_loss_terms(
        self,
        model: torch.nn.Module,
        batches: TrainBatches,
    ) -> dict[str, torch.Tensor]:
        if batches.supervision is None or batches.supervision.targets is None:
            raise ValueError("Poisson2DFieldTask requires a target-bearing supervision batch.")
        predictions = self._predict_field(model=model, batch=batches.supervision, batches=batches)
        return {
            "field_supervision": weighted_mse_loss(
                predictions,
                batches.supervision.targets,
                weights=batches.supervision.weights,
            ),
        }

    @staticmethod
    def _predict_with_condition(
        *,
        model: torch.nn.Module,
        inputs: torch.Tensor,
        condition_inputs: torch.Tensor | None,
        metadata: dict[str, Any],
    ) -> torch.Tensor:
        if hasattr(model, "forward_field"):
            predictions = model.forward_field(
                condition_inputs=condition_inputs,
                query_inputs=inputs,
                metadata=metadata,
            )
        elif bool(getattr(model, "supports_flattened_field", False)):
            predictions = model(inputs)
        else:
            raise ValueError("Poisson2DFieldTask requires an operator-ready model or explicit field fallback support.")
        return predictions

    def compute_residual(self, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        interior_inputs = inputs.clone().detach().requires_grad_(True)
        metadata = {
            "evaluation_mode": "field",
            "task_mode": "field",
            **self._geometry_metadata(),
        }
        condition_inputs = self._condition_inputs(interior_inputs.device)
        predictions = self._predict_with_condition(
            model=model,
            inputs=interior_inputs,
            condition_inputs=condition_inputs,
            metadata=metadata,
        )
        gradients = torch.autograd.grad(
            outputs=predictions,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(predictions),
            create_graph=True,
            retain_graph=True,
        )[0]
        second_x = torch.autograd.grad(
            outputs=gradients[:, :1],
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(gradients[:, :1]),
            create_graph=True,
            retain_graph=True,
        )[0][:, :1]
        second_y = torch.autograd.grad(
            outputs=gradients[:, 1:2],
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(gradients[:, 1:2]),
            create_graph=True,
            retain_graph=True,
        )[0][:, 1:2]
        source = self._source_term(interior_inputs)
        return (-(second_x + second_y) - source).detach()

    def compute_metric(
        self,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        if metric_name == "near_boundary_relative_l2":
            near_boundary_mask = self._near_boundary_mask(batch.inputs)
            if not bool(torch.any(near_boundary_mask)):
                metric_inputs = self._sample_near_boundary_points(num_samples=256, device=batch.inputs.device)
                metric_targets = self.exact_solution(metric_inputs)
                metric_predictions = self._predict_with_condition(
                    model=model,
                    inputs=metric_inputs,
                    condition_inputs=batch.metadata.get("condition_inputs"),
                    metadata=batch.metadata,
                )
            else:
                metric_targets = targets[near_boundary_mask]
                metric_predictions = predictions[near_boundary_mask]
            numerator = torch.linalg.norm(metric_predictions - metric_targets)
            denominator = torch.linalg.norm(metric_targets) + 1e-12
            return float((numerator / denominator).detach().item())
        if metric_name == "residual_metric":
            active_mask = self._inside_geometry_mask(batch.inputs)
            active_inputs = batch.inputs[active_mask]
            if active_inputs.shape[0] == 0:
                return None
            residual = self.compute_residual(model=model, inputs=active_inputs)
            return float(torch.mean(residual**2).detach().item())
        if metric_name == "physics_violation_metric":
            active_mask = self._inside_geometry_mask(batch.inputs)
            active_inputs = batch.inputs[active_mask]
            if active_inputs.shape[0] == 0:
                return None
            residual = self.compute_residual(model=model, inputs=active_inputs)
            return float(torch.mean(residual**2).detach().item())
        return None
