"""Operator-ready inverse Burgers rollout with a learnable viscosity parameter."""

from __future__ import annotations

from dataclasses import replace
from math import log
from typing import Any

import torch

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import EvaluationBatch, SampleBatch, TrainBatches, weighted_mse_loss
from pinn_bench.tasks.burgers1d_operator_rollout import Burgers1DOperatorRolloutTask


@register_task("burgers1d_operator_inverse_viscosity")
class Burgers1DOperatorInverseViscosityTask(Burgers1DOperatorRolloutTask):
    """Burgers operator rollout shell with a learnable viscosity parameter and residual metric."""

    def __init__(
        self,
        input_dim: int = 2,
        output_dim: int = 1,
        true_viscosity: float = 0.001,
        initial_viscosity: float | None = None,
        viscosity_values: list[float] | None = None,
        **kwargs: Any,
    ) -> None:
        selected_values = [float(value) for value in (viscosity_values or [true_viscosity])]
        if len(selected_values) != 1:
            raise ValueError("Burgers1DOperatorInverseViscosityTask requires exactly one viscosity value.")
        super().__init__(
            input_dim=input_dim,
            output_dim=output_dim,
            viscosity_values=selected_values,
            **kwargs,
        )
        self.true_viscosity = float(selected_values[0])
        self.initial_viscosity = float(initial_viscosity if initial_viscosity is not None else self.true_viscosity * 1.5)
        if self.initial_viscosity <= 0.0:
            raise ValueError("initial_viscosity must be positive.")
        self._log_viscosity = torch.nn.Parameter(torch.tensor(log(self.initial_viscosity), dtype=torch.float32))

    def trainable_parameters(self):
        return (self._log_viscosity,)

    def _current_viscosity_tensor(self) -> torch.Tensor:
        return torch.exp(self._log_viscosity)

    def current_viscosity(self) -> float:
        return float(self._current_viscosity_tensor().detach().item())

    def _build_field_batch(self, *, device: torch.device):
        field_batch = super()._build_field_batch(device=device)
        condition_inputs = field_batch.condition_inputs.clone()
        condition_inputs[:, -1] = self._current_viscosity_tensor()
        metadata = {
            **field_batch.metadata,
            "inverse_parameter_name": "viscosity",
            "inverse_target_family": "coefficient",
            "true_parameter_value": self.true_viscosity,
            "estimated_parameter_value": self.current_viscosity(),
            "supervision_source": "locked_operator_family_v1",
        }
        return replace(field_batch, condition_inputs=condition_inputs, metadata=metadata)

    @staticmethod
    def _field_tensor(predictions: torch.Tensor, metadata: dict[str, Any]) -> torch.Tensor:
        family_batch_size = int(metadata["family_batch_size"])
        grid_t, grid_x = metadata["grid_shape"]
        return predictions.reshape(family_batch_size, grid_t, grid_x, 1)

    def _physics_residual(self, field_tensor: torch.Tensor) -> torch.Tensor:
        u = field_tensor[..., 0]
        x = torch.tensor(self._family_payload["x"], dtype=field_tensor.dtype, device=field_tensor.device)
        t = torch.tensor(self._family_payload["t"], dtype=field_tensor.dtype, device=field_tensor.device)[self._resolve_future_indices()]
        dx = float(x[1] - x[0]) if x.numel() > 1 else 1.0
        dt = float(t[1] - t[0]) if t.numel() > 1 else 1.0
        u_t, u_x = torch.gradient(u, spacing=(dt, dx), dim=(1, 2))
        _, u_xx = torch.gradient(u_x, spacing=(dt, dx), dim=(1, 2))
        viscosity = self._current_viscosity_tensor()
        return u_t + u * u_x - viscosity * u_xx

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        base = super().sample_train_batches(device=device)
        metadata = {
            **dict(base.metadata),
            "inverse_parameter_name": "viscosity",
            "inverse_target_family": "coefficient",
            "true_parameter_value": self.true_viscosity,
            "estimated_parameter_value": self.current_viscosity(),
        }
        return replace(base, metadata=metadata)

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        base = super().sample_evaluation_batch(
            device=device,
            num_samples=num_samples,
            grid_x=grid_x,
            grid_t=grid_t,
            grid_y=grid_y,
        )
        metadata = {
            **dict(base.metadata),
            "inverse_parameter_name": "viscosity",
            "inverse_target_family": "coefficient",
            "true_parameter_value": self.true_viscosity,
            "estimated_parameter_value": self.current_viscosity(),
        }
        condition_inputs = base.metadata.get("condition_inputs")
        if isinstance(condition_inputs, torch.Tensor):
            condition_inputs = condition_inputs.clone()
            condition_inputs[:, -1] = self._current_viscosity_tensor()
            metadata["condition_inputs"] = condition_inputs
        return replace(base, metadata=metadata)

    def compute_loss_terms(self, model: torch.nn.Module, batches: TrainBatches) -> dict[str, torch.Tensor]:
        if batches.supervision is None or batches.supervision.targets is None:
            raise ValueError("Burgers1DOperatorInverseViscosityTask requires a supervision batch with targets.")
        predictions = self._predict_field(model=model, batch=batches.supervision, batches=batches)
        field_loss = weighted_mse_loss(predictions, batches.supervision.targets, weights=batches.supervision.weights)
        field_tensor = self._field_tensor(predictions, batches.supervision.metadata)
        residual = self._physics_residual(field_tensor)
        return {
            "field_supervision": field_loss,
            "physics": torch.mean(residual**2),
        }

    def compute_metric(
        self,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        del model, targets
        estimate = self.current_viscosity()
        if metric_name == "parameter_error":
            return float(abs(estimate - self.true_viscosity))
        if metric_name == "parameter_relative_error":
            return float(abs(estimate - self.true_viscosity) / max(abs(self.true_viscosity), 1e-12))
        if metric_name == "residual_metric":
            field_tensor = self._field_tensor(predictions, batch.metadata)
            residual = self._physics_residual(field_tensor)
            return float(torch.mean(residual**2).detach().item())
        return None
