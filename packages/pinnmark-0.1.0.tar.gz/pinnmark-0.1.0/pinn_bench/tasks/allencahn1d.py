"""Allen-Cahn 1D task with a manufactured analytic solution."""

from __future__ import annotations

from dataclasses import replace
from math import log
from math import pi
from typing import Any

import torch
import torch.nn.functional as F

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import BaseTask, EvaluationBatch, SampleBatch, TrainBatches


@register_task("allencahn1d")
class AllenCahn1DTask(BaseTask):
    """Allen-Cahn benchmark task on a 1D space-time domain."""

    _INITIAL_FAMILIES = {"sine_mode_1", "sine_mode_2"}

    def __init__(
        self,
        input_dim: int = 2,
        output_dim: int = 1,
        domain: dict[str, float] | None = None,
        epsilon: float = 0.1,
        initial_epsilon: float | None = None,
        learnable_epsilon: bool = False,
        reaction: float = 1.0,
        sampling: dict[str, int] | None = None,
        initial_family: str = "sine_mode_1",
        **_: Any,
    ) -> None:
        sampling_payload = dict(sampling or {})
        num_supervision = int(sampling_payload.pop("num_supervision", 64))
        self.input_dim = int(input_dim)
        self.output_dim = int(output_dim)
        self.domain = {
            "x_min": -1.0,
            "x_max": 1.0,
            "t_min": 0.0,
            "t_max": 1.0,
            **(domain or {}),
        }
        self.epsilon = float(epsilon)
        self.true_epsilon = float(epsilon)
        self.learnable_epsilon = bool(learnable_epsilon)
        self.initial_epsilon = float(initial_epsilon if initial_epsilon is not None else self.true_epsilon * 1.5)
        self.reaction = float(reaction)
        self.sampling = {
            "num_interior": 192,
            "num_boundary": 48,
            "num_initial": 48,
            **sampling_payload,
        }
        if self.learnable_epsilon:
            if self.initial_epsilon <= 0.0:
                raise ValueError("initial_epsilon must be positive when learnable_epsilon=True.")
            self.sampling["num_supervision"] = num_supervision
            self._log_epsilon = torch.nn.Parameter(torch.tensor(log(self.initial_epsilon), dtype=torch.float32))
        else:
            self._log_epsilon = None
        self.initial_family = str(initial_family)

        if self.input_dim != 2 or self.output_dim != 1:
            raise ValueError("AllenCahn1DTask expects input_dim=2 and output_dim=1.")
        if self.initial_family not in self._INITIAL_FAMILIES:
            allowed = ", ".join(sorted(self._INITIAL_FAMILIES))
            raise ValueError(f"AllenCahn1DTask only supports initial_family values: {allowed}.")

    def _sample_x(self, num_samples: int, device: torch.device, interior: bool = False) -> torch.Tensor:
        epsilon = 1e-6 if interior else 0.0
        return torch.rand((num_samples, 1), device=device) * (
            (self.domain["x_max"] - epsilon) - (self.domain["x_min"] + epsilon)
        ) + (self.domain["x_min"] + epsilon)

    def _sample_t(self, num_samples: int, device: torch.device, include_zero: bool = False) -> torch.Tensor:
        epsilon = 0.0 if include_zero else 1e-6
        return torch.rand((num_samples, 1), device=device) * (
            (self.domain["t_max"] - epsilon) - (self.domain["t_min"] + epsilon)
        ) + (self.domain["t_min"] + epsilon)

    def _mode_number(self) -> int:
        return 1 if self.initial_family == "sine_mode_1" else 2

    def _mode_profile(self, x: torch.Tensor) -> torch.Tensor:
        return torch.sin(self._mode_number() * pi * x)

    def trainable_parameters(self):
        if not self.learnable_epsilon or self._log_epsilon is None:
            return ()
        return (self._log_epsilon,)

    def _current_epsilon_tensor(self) -> torch.Tensor:
        if self._log_epsilon is None:
            return torch.tensor(self.true_epsilon, dtype=torch.float32)
        return torch.exp(self._log_epsilon)

    def current_epsilon(self) -> float:
        return float(self._current_epsilon_tensor().detach().item())

    def exact_solution(self, inputs: torch.Tensor) -> torch.Tensor:
        x = inputs[:, :1]
        t = inputs[:, 1:2]
        return torch.exp(-t) * self._mode_profile(x)

    def _physics_residual(self, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        interior_inputs = inputs.clone().detach().requires_grad_(True)
        predictions = model(interior_inputs)
        gradients = torch.autograd.grad(
            outputs=predictions,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(predictions),
            create_graph=True,
            retain_graph=True,
        )[0]
        u_x = gradients[:, :1]
        u_t = gradients[:, 1:2]
        second_x = torch.autograd.grad(
            outputs=u_x,
            inputs=interior_inputs,
            grad_outputs=torch.ones_like(u_x),
            create_graph=True,
            retain_graph=True,
        )[0][:, :1]
        forcing = self._forcing_term(interior_inputs)
        epsilon_tensor = self._current_epsilon_tensor().to(device=interior_inputs.device, dtype=interior_inputs.dtype)
        return u_t - (epsilon_tensor**2) * second_x + self.reaction * (predictions**3 - predictions) - forcing

    def _initial_condition(self, x: torch.Tensor) -> torch.Tensor:
        return self._mode_profile(x)

    def _forcing_term(self, inputs: torch.Tensor) -> torch.Tensor:
        solution = self.exact_solution(inputs)
        mode_number = self._mode_number()
        return (-1.0 + (self.true_epsilon**2) * ((mode_number * pi) ** 2)) * solution + self.reaction * (solution**3 - solution)

    def _boundary_diagnostic_batch(self, device: torch.device, num_points: int = 128) -> tuple[torch.Tensor, torch.Tensor]:
        count = max(2, num_points // 2)
        t = torch.linspace(self.domain["t_min"], self.domain["t_max"], steps=count, device=device).reshape(-1, 1)
        left_inputs = torch.cat(
            [torch.full((count, 1), float(self.domain["x_min"]), device=device), t],
            dim=1,
        )
        right_inputs = torch.cat(
            [torch.full((count, 1), float(self.domain["x_max"]), device=device), t],
            dim=1,
        )
        inputs = torch.cat([left_inputs, right_inputs], dim=0)
        targets = torch.zeros((inputs.shape[0], 1), device=device)
        return inputs, targets

    def _initial_diagnostic_batch(self, device: torch.device, num_points: int = 128) -> tuple[torch.Tensor, torch.Tensor]:
        x = torch.linspace(self.domain["x_min"], self.domain["x_max"], steps=max(2, num_points), device=device).reshape(-1, 1)
        t = torch.full((x.shape[0], 1), float(self.domain["t_min"]), device=device)
        inputs = torch.cat([x, t], dim=1)
        return inputs, self._initial_condition(x)

    def _sample_supervision_batch(self, device: torch.device) -> SampleBatch:
        num_supervision = int(self.sampling["num_supervision"])
        inputs = torch.cat(
            [
                self._sample_x(num_supervision, device=device, interior=False),
                self._sample_t(num_supervision, device=device, include_zero=True),
            ],
            dim=1,
        )
        targets = self.exact_solution(inputs)
        return SampleBatch(
            inputs=inputs,
            targets=targets,
            metadata={
                "kind": "supervision",
                "parameter_name": "epsilon",
                "true_parameter_value": self.true_epsilon,
                "grid_axes": {"x": 0, "t": 1},
                "domain_bounds": {
                    "x": (float(self.domain["x_min"]), float(self.domain["x_max"])),
                    "t": (float(self.domain["t_min"]), float(self.domain["t_max"])),
                },
            },
        )

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        num_interior = int(self.sampling["num_interior"])
        num_boundary = int(self.sampling["num_boundary"])
        num_initial = int(self.sampling["num_initial"])

        interior_inputs = torch.cat(
            [
                self._sample_x(num_interior, device=device, interior=True),
                self._sample_t(num_interior, device=device, include_zero=False),
            ],
            dim=1,
        )

        half_boundary = num_boundary // 2
        left_t = self._sample_t(half_boundary, device=device, include_zero=True)
        right_t = self._sample_t(num_boundary - half_boundary, device=device, include_zero=True)
        left_x = torch.full((half_boundary, 1), float(self.domain["x_min"]), device=device)
        right_x = torch.full((num_boundary - half_boundary, 1), float(self.domain["x_max"]), device=device)
        boundary_inputs = torch.cat(
            [torch.cat([left_x, left_t], dim=1), torch.cat([right_x, right_t], dim=1)],
            dim=0,
        )
        boundary_targets = torch.zeros((num_boundary, 1), device=device)

        initial_x = self._sample_x(num_initial, device=device, interior=False)
        initial_t = torch.full((num_initial, 1), float(self.domain["t_min"]), device=device)
        initial_inputs = torch.cat([initial_x, initial_t], dim=1)
        initial_targets = self._initial_condition(initial_x)

        batches = TrainBatches(
            interior=SampleBatch(
                inputs=interior_inputs,
                metadata={"kind": "interior", "initial_family": self.initial_family},
            ),
            boundary=SampleBatch(inputs=boundary_inputs, targets=boundary_targets, metadata={"kind": "boundary"}),
            initial=SampleBatch(
                inputs=initial_inputs,
                targets=initial_targets,
                metadata={"kind": "initial", "initial_family": self.initial_family},
            ),
            supervision=None,
            metadata={
                "task_name": "allencahn1d",
                "epsilon": self.epsilon,
                "reaction": self.reaction,
                "initial_family": self.initial_family,
            },
        )
        if not self.learnable_epsilon:
            return batches
        supervision = self._sample_supervision_batch(device=device)
        metadata = {
            **dict(batches.metadata),
            "inverse_parameter_name": "epsilon",
            "inverse_target_family": "coefficient",
            "inverse_target_type": "parameter",
            "true_parameter_value": self.true_epsilon,
            "estimated_parameter_value": self.current_epsilon(),
            "supervision_source": "analytic_solution_surface",
            "diagnostic_status": "complete",
            "diagnostic_reason": "",
            "identifiability_metadata": {
                "requires_supervision": True,
                "supervision_source": "analytic_solution_surface",
                "parameter_name": "epsilon",
            },
        }
        return replace(batches, supervision=supervision, metadata=metadata)

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        del num_samples, grid_y
        resolved_grid_x = int(grid_x or 128)
        resolved_grid_t = int(grid_t or 64)

        x = torch.linspace(self.domain["x_min"], self.domain["x_max"], steps=resolved_grid_x, device=device)
        t = torch.linspace(self.domain["t_min"], self.domain["t_max"], steps=resolved_grid_t, device=device)
        tt, xx = torch.meshgrid(t, x, indexing="ij")
        inputs = torch.stack([xx.reshape(-1), tt.reshape(-1)], dim=1)
        targets = self.exact_solution(inputs)
        batch = EvaluationBatch(
            inputs=inputs,
            targets=targets,
            name="allencahn1d_analytic_grid",
            metadata={
                "grid_shape": (resolved_grid_t, resolved_grid_x),
                "epsilon": self.epsilon,
                "reaction": self.reaction,
                "initial_family": self.initial_family,
            },
        )
        if not self.learnable_epsilon:
            return batch
        metadata = {
            **dict(batch.metadata),
            "inverse_parameter_name": "epsilon",
            "inverse_target_family": "coefficient",
            "inverse_target_type": "parameter",
            "true_parameter_value": self.true_epsilon,
            "estimated_parameter_value": self.current_epsilon(),
            "supervision_source": "analytic_solution_surface",
            "diagnostic_status": "complete",
            "diagnostic_reason": "",
            "identifiability_metadata": {
                "requires_supervision": True,
                "parameter_name": "epsilon",
            },
        }
        return replace(batch, metadata=metadata)

    def compute_loss_terms(self, model: torch.nn.Module, batches: TrainBatches) -> dict[str, torch.Tensor]:
        if batches.interior is None or batches.boundary is None or batches.initial is None:
            raise ValueError("AllenCahn1DTask requires interior, boundary, and initial batches.")
        if batches.boundary.targets is None or batches.initial.targets is None:
            raise ValueError("AllenCahn1DTask boundary and initial batches require targets.")

        residual = self._physics_residual(model, batches.interior.inputs)
        physics_loss = F.mse_loss(residual, torch.zeros_like(residual))

        boundary_predictions = model(batches.boundary.inputs)
        boundary_loss = F.mse_loss(boundary_predictions, batches.boundary.targets)

        initial_predictions = model(batches.initial.inputs)
        initial_loss = F.mse_loss(initial_predictions, batches.initial.targets)

        loss_terms = {
            "physics": physics_loss,
            "boundary": boundary_loss,
            "initial": initial_loss,
        }
        if self.learnable_epsilon:
            if batches.supervision is None or batches.supervision.targets is None:
                raise ValueError("AllenCahn1DTask requires a supervision batch with targets when learnable_epsilon=True.")
            supervision_predictions = model(batches.supervision.inputs)
            loss_terms["supervision"] = F.mse_loss(supervision_predictions, batches.supervision.targets)
        return loss_terms

    def compute_residual(self, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        return self._physics_residual(model, inputs).detach()

    def compute_metric(
        self,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        del predictions, targets
        if self.learnable_epsilon:
            estimate = self.current_epsilon()
            if metric_name == "parameter_error":
                return float(abs(estimate - self.true_epsilon))
            if metric_name in {"parameter_relative_error", "inverse_target_relative_error"}:
                return float(abs(estimate - self.true_epsilon) / max(abs(self.true_epsilon), 1e-12))
        if metric_name == "residual_metric":
            residual = self._physics_residual(model, batch.inputs)
            return float(torch.mean(residual**2).detach().item())
        if metric_name == "physics_violation_metric":
            residual = self._physics_residual(model, batch.inputs)
            return float(torch.mean(residual**2).detach().item())
        if metric_name == "bc_violation":
            inputs, target_values = self._boundary_diagnostic_batch(batch.inputs.device)
            values = model(inputs)
            return float(F.mse_loss(values, target_values).detach().item())
        if metric_name == "ic_violation":
            inputs, target_values = self._initial_diagnostic_batch(batch.inputs.device)
            values = model(inputs)
            return float(F.mse_loss(values, target_values).detach().item())
        return None
