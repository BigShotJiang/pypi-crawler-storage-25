"""Operator rollout task over a locked shallow-water preview family."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import torch

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import (
    BaseTask,
    ConditionBatch,
    EvaluationBatch,
    FieldBatch,
    SampleBatch,
    TrainBatches,
    weighted_mse_loss,
)


def _resolve_dataset_root(raw: str | Path | None) -> Path:
    if raw is None or not str(raw).strip():
        return (
            Path.cwd()
            / "examples"
            / "superbench_v3_preview"
            / "shared_datasets"
            / "shallowwater2d_operator_rollout_locked_preview_family_v1"
        ).resolve()
    candidate = Path(str(raw)).expanduser()
    if not candidate.is_absolute():
        candidate = (Path.cwd() / candidate).resolve()
    return candidate


def _normalize_operator_train_stride(raw: dict[str, int] | None) -> dict[str, int]:
    resolved = {"x": 1, "y": 1, "t": 1}
    if raw is None:
        return resolved
    for axis, value in raw.items():
        axis_name = str(axis).strip()
        if axis_name not in resolved:
            allowed = ", ".join(sorted(resolved))
            raise ValueError(f"operator_train_stride only supports keys {allowed}; got {axis_name!r}.")
        integer = int(value)
        if integer <= 0:
            raise ValueError(f"operator_train_stride.{axis_name} must be a positive integer.")
        resolved[axis_name] = integer
    return resolved


@register_task("shallowwater2d_operator_rollout")
class ShallowWater2DOperatorRolloutTask(BaseTask):
    """Field-output rollout task over a locked shallow-water preview family."""

    task_mode = "field"
    supports_operator = True

    def __init__(
        self,
        input_dim: int = 3,
        output_dim: int = 2,
        dataset_variant: str = "locked_preview_family_v1",
        dataset_root: str | None = None,
        operator_train_stride: dict[str, int] | None = None,
        history_steps: int = 2,
        rollout_stride: int = 1,
        forecast_steps: int = 9,
        trajectory_ids: list[int] | None = None,
        field_grid: dict[str, int] | None = None,
        **_: Any,
    ) -> None:
        self.input_dim = int(input_dim)
        self.output_dim = int(output_dim)
        if self.input_dim != 3:
            raise ValueError("ShallowWater2DOperatorRolloutTask requires input_dim=3 for (x, y, t_future).")
        if self.output_dim != 2:
            raise ValueError("ShallowWater2DOperatorRolloutTask requires output_dim=2 for velocity rollout.")

        self.dataset_variant = str(dataset_variant)
        self.dataset_root = _resolve_dataset_root(dataset_root)
        self.operator_train_stride = _normalize_operator_train_stride(operator_train_stride)
        self.history_steps = int(history_steps)
        self.rollout_stride = int(rollout_stride)
        self.forecast_steps = int(forecast_steps)
        self.field_grid = {
            "grid_x": 32,
            "grid_y": 32,
            "grid_t": 9,
            **(field_grid or {}),
        }
        self.requested_trajectory_ids = [int(value) for value in (trajectory_ids or [0, 1])]
        self._condition_feature_names = [f"pressure_t{index:02d}" for index in range(self.history_steps)]
        self._family_payload = self._load_family_payload()
        self._selected_indices = self._resolve_trajectory_indices()

    def _dataset_payload_path(self) -> Path:
        return self.dataset_root / f"{self.dataset_variant}.npz"

    def _load_family_payload(self) -> dict[str, np.ndarray | str]:
        payload_path = self._dataset_payload_path()
        if not payload_path.exists():
            raise FileNotFoundError(f"Expected shallow-water operator dataset at {payload_path}.")
        loaded = np.load(payload_path, allow_pickle=False)
        x = np.asarray(loaded["x"], dtype=np.float32)
        y = np.asarray(loaded["y"], dtype=np.float32)
        t = np.asarray(loaded["t"], dtype=np.float32)
        pressure = np.asarray(loaded["pressure"], dtype=np.float32)
        velocity = np.asarray(loaded["velocity"], dtype=np.float32)
        trajectory_ids = np.asarray(loaded["trajectory_ids"], dtype=np.int64)
        family_id = str(loaded["family_id"].tolist())
        source_tag = str(loaded["source_tag"].tolist())
        if pressure.ndim != 5 or velocity.ndim != 5:
            raise ValueError("Expected shallow-water payload pressure/velocity to have shape (family, time, y, x, channel).")
        if pressure.shape[-1] != 1:
            raise ValueError("Shallow-water pressure history must expose one scalar channel.")
        if velocity.shape[-1] != self.output_dim:
            raise ValueError("Shallow-water velocity rollout must expose two channels.")
        if tuple(pressure.shape[:4]) != tuple(velocity.shape[:4]):
            raise ValueError("Shallow-water pressure/velocity shapes must share family/time/grid axes.")
        if tuple(velocity.shape) != (len(trajectory_ids), len(t), len(y), len(x), self.output_dim):
            raise ValueError("Shallow-water operator payload shapes are inconsistent.")
        if int(self.field_grid["grid_x"]) != int(len(x)):
            raise ValueError(
                f"Shallow-water dataset uses grid_x={len(x)} but task was configured for grid_x={self.field_grid['grid_x']}."
            )
        if int(self.field_grid["grid_y"]) != int(len(y)):
            raise ValueError(
                f"Shallow-water dataset uses grid_y={len(y)} but task was configured for grid_y={self.field_grid['grid_y']}."
            )
        if len(t) < self.history_steps + (self.forecast_steps - 1) * self.rollout_stride + 1:
            raise ValueError("Shallow-water operator payload does not contain enough time steps for the requested rollout horizon.")
        if int(self.field_grid["grid_t"]) != self.forecast_steps:
            raise ValueError(
                "Shallow-water operator task requires field_grid.grid_t == forecast_steps; "
                f"got {self.field_grid['grid_t']} and {self.forecast_steps}."
            )
        return {
            "x": x,
            "y": y,
            "t": t,
            "pressure": pressure,
            "velocity": velocity,
            "trajectory_ids": trajectory_ids,
            "family_id": family_id,
            "source_tag": source_tag,
        }

    def _resolved_operator_train_stride(self) -> dict[str, int]:
        return _normalize_operator_train_stride(self.operator_train_stride)

    def _resolve_trajectory_indices(self) -> list[int]:
        available = [int(value) for value in self._family_payload["trajectory_ids"]]
        indices: list[int] = []
        for requested in self.requested_trajectory_ids:
            matches = [index for index, available_value in enumerate(available) if available_value == requested]
            if not matches:
                raise ValueError(f"Requested trajectory_id {requested} is not available in dataset family {available}.")
            indices.append(matches[0])
        return indices

    def _resolve_future_indices(self) -> list[int]:
        return [self.history_steps + index * self.rollout_stride for index in range(self.forecast_steps)]

    @staticmethod
    def _resolve_condition_inputs(batch: SampleBatch, batches: TrainBatches) -> torch.Tensor | None:
        condition_inputs = batch.metadata.get("condition_inputs")
        if condition_inputs is not None:
            return condition_inputs
        condition_batch = batches.metadata.get("condition_batch")
        if isinstance(condition_batch, ConditionBatch):
            return condition_batch.inputs
        if isinstance(condition_batch, dict) and isinstance(condition_batch.get("inputs"), torch.Tensor):
            return condition_batch["inputs"]
        return None

    @staticmethod
    def _predict_field(*, model: torch.nn.Module, batch: SampleBatch, batches: TrainBatches) -> torch.Tensor:
        condition_inputs = ShallowWater2DOperatorRolloutTask._resolve_condition_inputs(batch, batches)
        if hasattr(model, "forward_field"):
            predictions = model.forward_field(
                condition_inputs=condition_inputs,
                query_inputs=batch.inputs,
                metadata=batch.metadata,
            )
        elif bool(getattr(model, "supports_flattened_field", False)):
            predictions = model(batch.inputs)
        else:
            raise ValueError("ShallowWater2DOperatorRolloutTask requires an operator-ready model.")
        if predictions.shape == batch.targets.shape:
            return predictions
        if predictions.numel() == batch.targets.numel():
            return predictions.reshape_as(batch.targets)
        raise ValueError(
            f"Field prediction shape {tuple(predictions.shape)} does not match targets {tuple(batch.targets.shape)}."
        )

    def _build_field_batch(self, *, device: torch.device) -> FieldBatch:
        x = torch.tensor(self._family_payload["x"], dtype=torch.float32, device=device)
        y = torch.tensor(self._family_payload["y"], dtype=torch.float32, device=device)
        t = torch.tensor(self._family_payload["t"], dtype=torch.float32, device=device)
        pressure = torch.tensor(self._family_payload["pressure"], dtype=torch.float32, device=device)
        velocity = torch.tensor(self._family_payload["velocity"], dtype=torch.float32, device=device)
        future_indices = self._resolve_future_indices()
        operator_train_stride = self._resolved_operator_train_stride()

        query_batches: list[torch.Tensor] = []
        target_batches: list[torch.Tensor] = []
        condition_batches: list[torch.Tensor] = []
        family_trajectory_ids: list[int] = []

        for family_index in self._selected_indices:
            trajectory_id = int(self._family_payload["trajectory_ids"][family_index])
            history = pressure[family_index, : self.history_steps, :, :, :]
            future = velocity[family_index, future_indices, :, :, :]
            future_t = t[future_indices]
            tt, yy, xx = torch.meshgrid(future_t, y, x, indexing="ij")
            query_inputs = torch.stack([xx.reshape(-1), yy.reshape(-1), tt.reshape(-1)], dim=1)
            history_features = history.permute(1, 2, 0, 3).reshape(len(y), len(x), self.history_steps)
            history_per_query = history_features.unsqueeze(0).expand(self.forecast_steps, -1, -1, -1).reshape(
                -1,
                self.history_steps,
            )

            query_batches.append(query_inputs)
            target_batches.append(future.reshape(-1, self.output_dim))
            condition_batches.append(history_per_query)
            family_trajectory_ids.append(trajectory_id)

        inputs = torch.cat(query_batches, dim=0)
        targets = torch.cat(target_batches, dim=0)
        condition_inputs = torch.cat(condition_batches, dim=0)
        family_batch_size = len(self._selected_indices)
        grid_t = int(self.field_grid["grid_t"])
        grid_y = int(self.field_grid["grid_y"])
        grid_x = int(self.field_grid["grid_x"])
        total_points_per_family = grid_t * grid_y * grid_x
        mask = torch.zeros((grid_t, grid_y, grid_x), dtype=torch.float32, device=device)
        mask[
            :: operator_train_stride["t"],
            :: operator_train_stride["y"],
            :: operator_train_stride["x"],
        ] = 1.0
        active_points_per_family = int(mask.sum().item())
        supervision_coverage_ratio = float(active_points_per_family / float(total_points_per_family))
        weights = None
        if supervision_coverage_ratio < 1.0:
            weights = mask.reshape(-1).repeat(family_batch_size)
        return FieldBatch(
            inputs=inputs,
            targets=targets,
            condition_inputs=condition_inputs,
            weights=weights,
            metadata={
                "grid_shape": (grid_t, grid_y, grid_x),
                "family_batch_size": family_batch_size,
                "field_shape": (grid_t, grid_y, grid_x, self.output_dim),
                "family_field_shape": (family_batch_size, grid_t, grid_y, grid_x, self.output_dim),
                "condition_shape": tuple(condition_inputs.shape),
                "condition_feature_names": list(self._condition_feature_names),
                "evaluation_mode": "field",
                "task_mode": "field",
                "dataset_variant": self.dataset_variant,
                "dataset_root": str(self.dataset_root),
                "family_id": str(self._family_payload["family_id"]),
                "source_tag": str(self._family_payload["source_tag"]),
                "trajectory_ids": list(family_trajectory_ids),
                "history_steps": self.history_steps,
                "rollout_stride": self.rollout_stride,
                "forecast_steps": self.forecast_steps,
                "operator_train_stride": dict(operator_train_stride),
                "supervision_active_points": active_points_per_family * family_batch_size,
                "supervision_total_points": total_points_per_family * family_batch_size,
                "supervision_coverage_ratio": supervision_coverage_ratio,
            },
        )

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        field_batch = self._build_field_batch(device=device)
        condition_batch = ConditionBatch(
            inputs=field_batch.condition_inputs,
            metadata={
                "condition_shape": tuple(field_batch.condition_inputs.shape),
                "condition_feature_names": list(self._condition_feature_names),
            },
        )
        supervision = field_batch.to_sample_batch()
        return TrainBatches(
            supervision=supervision,
            metadata={
                "task_name": "shallowwater2d_operator_rollout",
                "task_mode": "field",
                "grid_shape": supervision.metadata["grid_shape"],
                "family_batch_size": supervision.metadata["family_batch_size"],
                "field_shape": supervision.metadata["field_shape"],
                "family_field_shape": supervision.metadata["family_field_shape"],
                "condition_batch": condition_batch,
                "trajectory_ids": supervision.metadata["trajectory_ids"],
                "history_steps": self.history_steps,
                "rollout_stride": self.rollout_stride,
                "forecast_steps": self.forecast_steps,
                "dataset_variant": self.dataset_variant,
                "family_id": supervision.metadata["family_id"],
                "operator_train_stride": supervision.metadata["operator_train_stride"],
                "supervision_active_points": supervision.metadata["supervision_active_points"],
                "supervision_total_points": supervision.metadata["supervision_total_points"],
                "supervision_coverage_ratio": supervision.metadata["supervision_coverage_ratio"],
            },
        )

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        del num_samples
        if grid_x is not None and int(grid_x) != int(self.field_grid["grid_x"]):
            raise ValueError("ShallowWater2DOperatorRolloutTask does not support grid_x overrides outside the locked family grid.")
        if grid_y is not None and int(grid_y) != int(self.field_grid["grid_y"]):
            raise ValueError("ShallowWater2DOperatorRolloutTask does not support grid_y overrides outside the locked family grid.")
        if grid_t is not None and int(grid_t) != int(self.field_grid["grid_t"]):
            raise ValueError("ShallowWater2DOperatorRolloutTask does not support grid_t overrides outside the locked family rollout horizon.")
        field_batch = self._build_field_batch(device=device)
        return EvaluationBatch(
            inputs=field_batch.inputs,
            targets=field_batch.targets,
            name="shallowwater2d_operator_rollout_preview_family",
            metadata={
                **field_batch.metadata,
                "condition_inputs": field_batch.condition_inputs,
            },
        )

    def compute_loss_terms(self, model: torch.nn.Module, batches: TrainBatches) -> dict[str, torch.Tensor]:
        batch = batches.supervision
        if batch is None or batch.targets is None:
            raise ValueError("ShallowWater2DOperatorRolloutTask requires a supervised field batch with targets.")
        predictions = self._predict_field(model=model, batch=batch, batches=batches)
        return {
            "field_supervision": weighted_mse_loss(predictions, batch.targets, batch.weights),
        }
