"""Operator-ready Heat1D field task for v0.6-preview."""

from __future__ import annotations

from typing import Any

import torch

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import (
    ConditionBatch,
    EvaluationBatch,
    FieldBatch,
    SampleBatch,
    TrainBatches,
    weighted_mse_loss,
)
from pinn_bench.tasks.heat1d import Heat1DTask


@register_task("heat1d_field")
class Heat1DFieldTask(Heat1DTask):
    """Heat1D variant that trains and evaluates on flattened whole-field supervision."""

    task_mode = "field"
    supports_operator = True

    def __init__(
        self,
        input_dim: int = 2,
        output_dim: int = 1,
        domain: dict[str, float] | None = None,
        alpha: float = 0.1,
        sampling: dict[str, int] | None = None,
        field_grid: dict[str, int] | None = None,
        condition_features: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            input_dim=input_dim,
            output_dim=output_dim,
            domain=domain,
            alpha=alpha,
            sampling=sampling,
            **kwargs,
        )
        self.field_grid = {
            "grid_x": 32,
            "grid_t": 16,
            **(field_grid or {}),
        }
        self.condition_features = list(condition_features or ["alpha"])

    def _condition_inputs(self, device: torch.device) -> torch.Tensor:
        feature_values = {
            "alpha": self.alpha,
            "x_min": float(self.domain["x_min"]),
            "x_max": float(self.domain["x_max"]),
            "t_min": float(self.domain["t_min"]),
            "t_max": float(self.domain["t_max"]),
        }
        values = [feature_values[name] for name in self.condition_features]
        return torch.tensor([values], device=device, dtype=torch.float32)

    def _build_field_batch(self, *, device: torch.device, grid_x: int, grid_t: int) -> FieldBatch:
        x = torch.linspace(self.domain["x_min"], self.domain["x_max"], steps=grid_x, device=device)
        t = torch.linspace(self.domain["t_min"], self.domain["t_max"], steps=grid_t, device=device)
        tt, xx = torch.meshgrid(t, x, indexing="ij")
        inputs = torch.stack([xx.reshape(-1), tt.reshape(-1)], dim=1)
        targets = self.exact_solution(inputs)
        condition_inputs = self._condition_inputs(device)
        return FieldBatch(
            inputs=inputs,
            targets=targets,
            condition_inputs=condition_inputs,
            metadata={
                "grid_shape": (grid_t, grid_x),
                "field_shape": (grid_t, grid_x, self.output_dim),
                "condition_shape": tuple(condition_inputs.shape),
                "condition_feature_names": list(self.condition_features),
                "evaluation_mode": "field",
                "task_mode": "field",
                "alpha": self.alpha,
            },
        )

    @staticmethod
    def _resolve_condition_inputs(batch: SampleBatch, batches: TrainBatches) -> torch.Tensor | None:
        condition_inputs = batch.metadata.get("condition_inputs")
        if condition_inputs is not None:
            return condition_inputs
        condition_batch = batches.metadata.get("condition_batch")
        if isinstance(condition_batch, ConditionBatch):
            return condition_batch.inputs
        if isinstance(condition_batch, dict) and isinstance(condition_batch.get("inputs"), torch.Tensor):
            return condition_batch["inputs"]
        return None

    @staticmethod
    def _predict_field(
        *,
        model: torch.nn.Module,
        batch: SampleBatch,
        batches: TrainBatches,
    ) -> torch.Tensor:
        condition_inputs = Heat1DFieldTask._resolve_condition_inputs(batch, batches)
        if hasattr(model, "forward_field"):
            predictions = model.forward_field(
                condition_inputs=condition_inputs,
                query_inputs=batch.inputs,
                metadata=batch.metadata,
            )
        elif bool(getattr(model, "supports_flattened_field", False)):
            predictions = model(batch.inputs)
        else:
            raise ValueError("Heat1DFieldTask requires an operator-ready model or explicit field fallback support.")
        if predictions.shape == batch.targets.shape:
            return predictions
        if predictions.numel() == batch.targets.numel():
            return predictions.reshape_as(batch.targets)
        raise ValueError(
            f"Field prediction shape {tuple(predictions.shape)} does not match targets {tuple(batch.targets.shape)}."
        )

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        grid_x = int(self.field_grid["grid_x"])
        grid_t = int(self.field_grid["grid_t"])
        field_batch = self._build_field_batch(device=device, grid_x=grid_x, grid_t=grid_t)
        condition_batch = ConditionBatch(
            inputs=field_batch.condition_inputs,
            metadata={
                "condition_shape": tuple(field_batch.condition_inputs.shape),
                "condition_feature_names": list(self.condition_features),
            },
        )
        supervision = field_batch.to_sample_batch()
        return TrainBatches(
            supervision=supervision,
            metadata={
                "task_name": "heat1d_field",
                "task_mode": "field",
                "field_shape": supervision.metadata["field_shape"],
                "grid_shape": supervision.metadata["grid_shape"],
                "condition_batch": condition_batch,
            },
        )

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        del num_samples, grid_y
        resolved_grid_x = int(grid_x or 128)
        resolved_grid_t = int(grid_t or 64)
        field_batch = self._build_field_batch(device=device, grid_x=resolved_grid_x, grid_t=resolved_grid_t)
        return EvaluationBatch(
            inputs=field_batch.inputs,
            targets=field_batch.targets,
            name="heat1d_field_grid",
            metadata={
                **field_batch.metadata,
                "condition_inputs": field_batch.condition_inputs,
            },
        )

    def compute_loss_terms(
        self,
        model: torch.nn.Module,
        batches: TrainBatches,
    ) -> dict[str, torch.Tensor]:
        if batches.supervision is None or batches.supervision.targets is None:
            raise ValueError("Heat1DFieldTask requires a target-bearing supervision batch.")
        predictions = self._predict_field(model=model, batch=batches.supervision, batches=batches)
        return {
            "field_supervision": weighted_mse_loss(
                predictions,
                batches.supervision.targets,
                weights=batches.supervision.weights,
            ),
        }
