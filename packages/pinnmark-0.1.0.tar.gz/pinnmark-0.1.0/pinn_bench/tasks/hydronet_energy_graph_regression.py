"""Native-proxy molecular energy regression task for sciml-bench Hydronet."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import BaseTask, EvaluationBatch, SampleBatch, TrainBatches


def _resolve_dataset_root(raw: str | Path | None) -> Path:
    if raw is None or not str(raw).strip():
        return (
            Path.cwd()
            / "examples"
            / "superbench_v3_preview"
            / "shared_datasets"
            / "hydronet_energy_graph_regression_native_proxy_v1"
        ).resolve()
    candidate = Path(str(raw)).expanduser()
    if not candidate.is_absolute():
        candidate = (Path.cwd() / candidate).resolve()
    return candidate


@register_task("hydronet_energy_graph_regression")
class HydronetEnergyGraphRegressionTask(BaseTask):
    """Fixed-width native-proxy regression task over padded molecular tokens."""

    task_mode = "pointwise"
    supports_operator = False

    def __init__(
        self,
        input_dim: int = 270,
        output_dim: int = 1,
        dataset_variant: str = "native_proxy_v1",
        dataset_root: str | None = None,
        **_: Any,
    ) -> None:
        self.input_dim = int(input_dim)
        self.output_dim = int(output_dim)
        if self.input_dim != 270 or self.output_dim != 1:
            raise ValueError("HydronetEnergyGraphRegressionTask expects input_dim=270 and output_dim=1.")
        self.dataset_variant = str(dataset_variant)
        self.dataset_root = _resolve_dataset_root(dataset_root)
        self._payload = self._load_payload()
        self._features, self._targets = self._build_dense_tensors()

    def _dataset_payload_path(self) -> Path:
        return self.dataset_root / f"{self.dataset_variant}.npz"

    def _load_payload(self) -> dict[str, np.ndarray | str]:
        payload_path = self._dataset_payload_path()
        if not payload_path.exists():
            raise FileNotFoundError(f"Expected hydronet preview dataset at {payload_path}.")
        loaded = np.load(payload_path, allow_pickle=False)
        atom_positions = np.asarray(loaded["atom_positions"], dtype=np.float32)
        atom_types_one_hot = np.asarray(loaded["atom_types_one_hot"], dtype=np.float32)
        atom_mask = np.asarray(loaded["atom_mask"], dtype=np.float32)
        targets = np.asarray(loaded["targets"], dtype=np.float32)
        sample_ids = np.asarray(loaded["sample_ids"], dtype=np.int64)
        family_id = str(loaded["family_id"].tolist())
        source_tag = str(loaded["source_tag"].tolist())
        if atom_positions.shape != (2, 30, 3):
            raise ValueError("Hydronet native proxy expects atom_positions with shape (2, 30, 3).")
        if atom_types_one_hot.shape != (2, 30, 5):
            raise ValueError("Hydronet native proxy expects atom_types_one_hot with shape (2, 30, 5).")
        if atom_mask.shape != (2, 30, 1):
            raise ValueError("Hydronet native proxy expects atom_mask with shape (2, 30, 1).")
        if targets.shape != (2, 1):
            raise ValueError("Hydronet native proxy expects targets with shape (2, 1).")
        if sample_ids.shape != (2,):
            raise ValueError("Hydronet native proxy expects sample_ids with shape (2,).")
        return {
            "atom_positions": atom_positions,
            "atom_types_one_hot": atom_types_one_hot,
            "atom_mask": atom_mask,
            "targets": targets,
            "sample_ids": sample_ids,
            "family_id": family_id,
            "source_tag": source_tag,
        }

    def _build_dense_tensors(self) -> tuple[torch.Tensor, torch.Tensor]:
        atom_positions = torch.tensor(self._payload["atom_positions"], dtype=torch.float32)
        atom_types_one_hot = torch.tensor(self._payload["atom_types_one_hot"], dtype=torch.float32)
        atom_mask = torch.tensor(self._payload["atom_mask"], dtype=torch.float32)
        targets = torch.tensor(self._payload["targets"], dtype=torch.float32)
        features = torch.cat(
            [
                atom_positions.reshape(atom_positions.shape[0], -1),
                atom_types_one_hot.reshape(atom_types_one_hot.shape[0], -1),
                atom_mask.reshape(atom_mask.shape[0], -1),
            ],
            dim=1,
        )
        if features.shape != (2, self.input_dim):
            raise ValueError(f"Hydronet native proxy expected flattened feature shape (2, {self.input_dim}).")
        return features, targets

    def _sample_ids(self) -> list[int]:
        raw = self._payload["sample_ids"]
        return [int(value) for value in raw]

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        inputs = self._features.to(device=device)
        targets = self._targets.to(device=device)
        return TrainBatches(
            supervision=SampleBatch(
                inputs=inputs,
                targets=targets,
                metadata={
                    "task_mode": "pointwise",
                    "dataset_variant": self.dataset_variant,
                    "dataset_root": str(self.dataset_root),
                    "family_id": str(self._payload["family_id"]),
                    "source_tag": str(self._payload["source_tag"]),
                    "sample_ids": self._sample_ids(),
                    "input_shape": tuple(inputs.shape),
                    "target_shape": tuple(targets.shape),
                },
            ),
            metadata={
                "task_name": "hydronet_energy_graph_regression",
                "dataset_variant": self.dataset_variant,
                "family_id": str(self._payload["family_id"]),
                "sample_ids": self._sample_ids(),
            },
        )

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        del num_samples, grid_x, grid_t, grid_y
        inputs = self._features.to(device=device)
        targets = self._targets.to(device=device)
        return EvaluationBatch(
            inputs=inputs,
            targets=targets,
            name="hydronet_energy_graph_regression_native_proxy",
            metadata={
                "dataset_variant": self.dataset_variant,
                "dataset_root": str(self.dataset_root),
                "family_id": str(self._payload["family_id"]),
                "source_tag": str(self._payload["source_tag"]),
                "sample_ids": self._sample_ids(),
                "input_shape": tuple(inputs.shape),
                "target_shape": tuple(targets.shape),
            },
        )

    def compute_loss_terms(self, model: torch.nn.Module, batches: TrainBatches) -> dict[str, torch.Tensor]:
        batch = batches.supervision
        if batch is None or batch.targets is None:
            raise ValueError("HydronetEnergyGraphRegressionTask requires a supervision batch with targets.")
        predictions = model(batch.inputs)
        return {
            "supervision": F.mse_loss(predictions, batch.targets),
        }

    def compute_metric(
        self,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        del model, batch
        if metric_name == "mae":
            return float(torch.mean(torch.abs(predictions - targets)).detach().item())
        return None

