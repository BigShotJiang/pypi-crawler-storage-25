"""Base interfaces and typed batches for benchmark tasks."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

import torch
from collections.abc import Iterable


@dataclass
class SampleBatch:
    """One semantically grouped batch of samples."""

    inputs: torch.Tensor
    targets: torch.Tensor | None = None
    weights: torch.Tensor | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ConditionBatch:
    """Conditioning inputs for operator-ready tasks and models."""

    inputs: torch.Tensor
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class FieldBatch:
    """Structured field batch used by operator-ready tasks."""

    inputs: torch.Tensor
    targets: torch.Tensor | None = None
    condition_inputs: torch.Tensor | None = None
    weights: torch.Tensor | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_sample_batch(self) -> SampleBatch:
        """Convert a field batch into the canonical trainer/evaluator batch shape."""
        payload = dict(self.metadata)
        payload.setdefault("evaluation_mode", "field")
        payload.setdefault("task_mode", "field")
        if self.condition_inputs is not None and "condition_inputs" not in payload:
            payload["condition_inputs"] = self.condition_inputs
            payload.setdefault("condition_shape", tuple(self.condition_inputs.shape))
        return SampleBatch(
            inputs=self.inputs,
            targets=self.targets,
            weights=self.weights,
            metadata=payload,
        )


@dataclass
class TrainBatches:
    """Structured training batches for pointwise and operator-ready tasks."""

    interior: SampleBatch | None = None
    boundary: SampleBatch | None = None
    initial: SampleBatch | None = None
    initial_velocity: SampleBatch | None = None
    supervision: SampleBatch | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def named_batches(self) -> dict[str, SampleBatch]:
        """Return non-empty named training batches."""
        return {
            name: batch
            for name, batch in {
                "interior": self.interior,
                "boundary": self.boundary,
                "initial": self.initial,
                "initial_velocity": self.initial_velocity,
                "supervision": self.supervision,
            }.items()
            if batch is not None
        }


@dataclass
class EvaluationBatch:
    """Evaluation batch and associated metadata."""

    inputs: torch.Tensor
    targets: torch.Tensor | None = None
    name: str = "default"
    metadata: dict[str, Any] = field(default_factory=dict)


def weighted_mse_loss(
    predictions: torch.Tensor,
    targets: torch.Tensor,
    weights: torch.Tensor | None = None,
) -> torch.Tensor:
    """Compute MSE with optional sample or element weights.

    When `weights` are provided for field-supervision batches, zero-weighted entries are
    ignored while preserving full-grid tensor shapes for operator models that require a
    regular grid layout.
    """
    errors = (predictions - targets) ** 2
    if weights is None:
        return errors.mean()
    resolved = weights.to(device=errors.device, dtype=errors.dtype)
    while resolved.ndim < errors.ndim:
        resolved = resolved.unsqueeze(-1)
    weight_sum = resolved.sum()
    if float(weight_sum.detach().item()) <= 0.0:
        raise ValueError("weighted_mse_loss requires at least one positive weight.")
    return (errors * resolved).sum() / weight_sum


class BaseTask(ABC):
    """Common interface for benchmark tasks."""

    task_mode = "pointwise"
    supports_operator = False

    @abstractmethod
    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        """Return structured batches for one training step."""

    @abstractmethod
    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        """Return a structured batch for evaluation."""

    @abstractmethod
    def compute_loss_terms(
        self,
        model: torch.nn.Module,
        batches: TrainBatches,
    ) -> dict[str, torch.Tensor]:
        """Return named loss terms for optimization."""

    def exact_solution(self, inputs: torch.Tensor) -> torch.Tensor | None:
        """Return an exact solution if available."""
        return None

    def trainable_parameters(self) -> Iterable[torch.nn.Parameter]:
        """Return additive task-owned trainable parameters when a task solves inverse variables."""
        return ()

    def compute_metric(
        self,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        """Compute task-owned metrics that require model or task semantics."""
        del metric_name, model, batch, predictions, targets
        return None

    def compute_residual(self, model: torch.nn.Module, inputs: torch.Tensor) -> torch.Tensor:
        """Return pointwise PDE residual magnitudes for adaptive sampling or diagnostics."""
        raise NotImplementedError(f"{self.__class__.__name__} does not implement compute_residual(...).")
