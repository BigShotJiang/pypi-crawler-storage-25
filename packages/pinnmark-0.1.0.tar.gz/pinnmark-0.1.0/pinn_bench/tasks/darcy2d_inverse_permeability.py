"""Data-backed Darcy inverse task with explicit solution and permeability fields."""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import Any

import numpy as np
import torch
from scipy.interpolate import RegularGridInterpolator, griddata

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import BaseTask, EvaluationBatch, SampleBatch, TrainBatches, weighted_mse_loss


def _default_dataset_root() -> Path:
    return (
        Path(__file__).resolve().parents[2]
        / "examples"
        / "superbench_v3_preview"
        / "shared_datasets"
        / "darcy2d_inverse_permeability_family_v1"
    ).resolve()


def _default_ref_dir() -> Path:
    return (
        Path(__file__).resolve().parents[2]
        / "experiments"
        / "comparability_audit"
        / "external_repos"
        / "PINNacle"
        / "ref"
    ).resolve()


def _reshape_regular_field(raw: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    x = np.unique(raw[:, 0])
    y = np.unique(raw[:, 1])
    field = raw[:, 2].reshape(len(y), len(x))
    return x.astype(np.float32), y.astype(np.float32), field.astype(np.float32)


def _build_dataset_package(dataset_root: Path, dataset_variant: str, grid_size: int) -> Path:
    dataset_root.mkdir(parents=True, exist_ok=True)
    target_path = dataset_root / f"{dataset_variant}.npz"
    if target_path.exists():
        return target_path

    ref_dir = _default_ref_dir()
    coef_raw = np.loadtxt(ref_dir / "darcy_2d_coef_256.dat", dtype=np.float64)
    x_full, y_full, k_full = _reshape_regular_field(coef_raw)

    heat_raw = np.loadtxt(ref_dir / "heat_darcy.dat", comments="%", dtype=np.float64)
    sample_points = heat_raw[:, :2]
    solution_final = heat_raw[:, -1]

    x = np.linspace(float(x_full.min()), float(x_full.max()), grid_size, dtype=np.float32)
    y = np.linspace(float(y_full.min()), float(y_full.max()), grid_size, dtype=np.float32)
    yy, xx = np.meshgrid(y, x, indexing="ij")
    grid_points = np.stack([xx.reshape(-1), yy.reshape(-1)], axis=1)

    solution_grid = griddata(sample_points, solution_final, grid_points, method="linear")
    if np.isnan(solution_grid).any():
        nearest = griddata(sample_points, solution_final, grid_points, method="nearest")
        solution_grid = np.where(np.isnan(solution_grid), nearest, solution_grid)
    solution_grid = solution_grid.reshape(grid_size, grid_size).astype(np.float32)

    k_interp = RegularGridInterpolator((y_full, x_full), k_full, bounds_error=False, fill_value=None)
    permeability_grid = k_interp(grid_points).reshape(grid_size, grid_size).astype(np.float32)

    dx = float(x[1] - x[0]) if len(x) > 1 else 1.0
    dy = float(y[1] - y[0]) if len(y) > 1 else 1.0
    du_dy, du_dx = np.gradient(solution_grid, dy, dx)
    flux_x = permeability_grid * du_dx
    flux_y = permeability_grid * du_dy
    dflux_y_dy = np.gradient(flux_y, dy, dx)[0]
    dflux_x_dx = np.gradient(flux_x, dy, dx)[1]
    source_grid = -(dflux_x_dx + dflux_y_dy).astype(np.float32)

    boundary_mask = np.zeros((grid_size, grid_size), dtype=bool)
    boundary_mask[0, :] = True
    boundary_mask[-1, :] = True
    boundary_mask[:, 0] = True
    boundary_mask[:, -1] = True

    np.savez(
        target_path,
        x=x,
        y=y,
        solution_field=solution_grid,
        permeability_field=permeability_grid,
        source_field=source_grid,
        boundary_mask=boundary_mask.astype(np.uint8),
        family_id="darcy2d_inverse_permeability_family_v1",
        source_tag="PINNacle_ref_darcy_2d_coef_256 + heat_darcy",
    )
    return target_path


@register_task("darcy2d_inverse_permeability")
class Darcy2DInversePermeabilityTask(BaseTask):
    """Pointwise Darcy inverse task with explicit solution and permeability-field predictions."""

    def __init__(
        self,
        input_dim: int = 2,
        output_dim: int = 2,
        dataset_variant: str = "darcy2d_inverse_permeability_family_v1",
        dataset_root: str | None = None,
        field_grid: dict[str, int] | None = None,
        sampling: dict[str, int] | None = None,
        observation_shell: str = "nominal",
        **_: Any,
    ) -> None:
        self.input_dim = int(input_dim)
        self.output_dim = int(output_dim)
        if self.input_dim != 2:
            raise ValueError("Darcy2DInversePermeabilityTask requires input_dim=2.")
        if self.output_dim != 2:
            raise ValueError("Darcy2DInversePermeabilityTask requires output_dim=2 for [u, log_k].")

        self.dataset_variant = str(dataset_variant)
        self.dataset_root = _default_dataset_root() if dataset_root is None else Path(str(dataset_root)).expanduser().resolve()
        self.field_grid = {"grid_x": 64, "grid_y": 64, **(field_grid or {})}
        self.sampling = {"num_interior": 256, "num_boundary": 128, "num_supervision": 256, **(sampling or {})}
        self.observation_shell = str(observation_shell).strip().lower()
        if self.observation_shell not in {"nominal", "spatial_blind_zone"}:
            raise ValueError("Darcy2DInversePermeabilityTask only supports observation_shell='nominal' or 'spatial_blind_zone'.")

        package_path = _build_dataset_package(self.dataset_root, self.dataset_variant, int(self.field_grid["grid_x"]))
        payload = np.load(package_path, allow_pickle=False)
        self.x = payload["x"].astype(np.float32)
        self.y = payload["y"].astype(np.float32)
        self.solution_field = payload["solution_field"].astype(np.float32)
        self.permeability_field = payload["permeability_field"].astype(np.float32)
        self.source_field = payload["source_field"].astype(np.float32)
        self.boundary_mask = payload["boundary_mask"].astype(bool)
        self.family_id = str(payload["family_id"].tolist())
        self.source_tag = str(payload["source_tag"].tolist())

        yy, xx = np.meshgrid(self.y, self.x, indexing="ij")
        self.full_inputs_np = np.stack([xx.reshape(-1), yy.reshape(-1)], axis=1).astype(np.float32)
        self.full_solution_np = self.solution_field.reshape(-1, 1).astype(np.float32)
        self.full_permeability_np = self.permeability_field.reshape(-1, 1).astype(np.float32)
        self.full_targets_np = np.concatenate([self.full_solution_np, self.full_permeability_np], axis=1).astype(np.float32)
        self.full_source_np = self.source_field.reshape(-1, 1).astype(np.float32)
        self.boundary_indices = np.flatnonzero(self.boundary_mask.reshape(-1))
        self.interior_indices = np.flatnonzero(~self.boundary_mask.reshape(-1))
        self.blind_zone_mask_np = (
            (self.full_inputs_np[:, 0] >= 0.35)
            & (self.full_inputs_np[:, 0] <= 0.65)
            & (self.full_inputs_np[:, 1] >= 0.35)
            & (self.full_inputs_np[:, 1] <= 0.65)
        )
        self.blind_zone_indices = np.flatnonzero(self.blind_zone_mask_np)
        self.observed_zone_indices = np.flatnonzero(~self.blind_zone_mask_np)
        self.metric_weights_np = np.concatenate(
            [
                np.ones_like(self.full_solution_np, dtype=np.float32),
                np.zeros_like(self.full_permeability_np, dtype=np.float32),
            ],
            axis=1,
        )

    @staticmethod
    def _select_indices(pool: np.ndarray, count: int) -> np.ndarray:
        if count >= pool.shape[0]:
            return pool.copy()
        positions = np.random.choice(pool.shape[0], size=count, replace=False)
        return pool[positions]

    def _supervision_weights(self, count: int, device: torch.device) -> torch.Tensor | None:
        if self.observation_shell != "spatial_blind_zone":
            return None
        selected_parts: list[np.ndarray] = []
        remaining = max(int(count), 0)
        if remaining > 0 and self.blind_zone_indices.size:
            selected_parts.append(self._select_indices(self.blind_zone_indices, 1))
            remaining -= 1
        if remaining > 0 and self.observed_zone_indices.size:
            selected_parts.append(self._select_indices(self.observed_zone_indices, 1))
            remaining -= 1

        selected = np.concatenate(selected_parts) if selected_parts else np.empty((0,), dtype=np.int64)
        if remaining > 0:
            available = np.setdiff1d(np.arange(self.full_inputs_np.shape[0]), selected, assume_unique=False)
            extra = self._select_indices(available, remaining)
            selected = np.concatenate([selected, extra])
        if selected.size > 1:
            np.random.shuffle(selected)

        keep_mask = (~self.blind_zone_mask_np[selected]).astype(np.float32).reshape(-1, 1)
        keep_tensor = torch.tensor(keep_mask, dtype=torch.float32, device=device)
        weights = torch.cat([keep_tensor, torch.zeros_like(keep_tensor)], dim=1)
        return selected, weights

    def _predict_solution_and_logk(self, model: torch.nn.Module, inputs: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        outputs = model(inputs)
        if outputs.ndim != 2 or outputs.shape[1] != 2:
            raise ValueError(f"Darcy2DInversePermeabilityTask requires model outputs of shape (N, 2), got {tuple(outputs.shape)}.")
        return outputs[:, :1], outputs[:, 1:2]

    @staticmethod
    def _positive_permeability(log_k: torch.Tensor) -> torch.Tensor:
        return torch.exp(torch.clamp(log_k, min=-6.0, max=6.0))

    def _residual(self, model: torch.nn.Module, inputs: torch.Tensor, source_values: torch.Tensor) -> torch.Tensor:
        resolved_inputs = inputs.clone().detach().requires_grad_(True)
        u, log_k = self._predict_solution_and_logk(model, resolved_inputs)
        k = self._positive_permeability(log_k)
        grads_u = torch.autograd.grad(
            outputs=u,
            inputs=resolved_inputs,
            grad_outputs=torch.ones_like(u),
            create_graph=True,
            retain_graph=True,
        )[0]
        u_x = grads_u[:, :1]
        u_y = grads_u[:, 1:2]
        flux_x = k * u_x
        flux_y = k * u_y
        dflux_x = torch.autograd.grad(
            outputs=flux_x,
            inputs=resolved_inputs,
            grad_outputs=torch.ones_like(flux_x),
            create_graph=True,
            retain_graph=True,
        )[0][:, :1]
        dflux_y = torch.autograd.grad(
            outputs=flux_y,
            inputs=resolved_inputs,
            grad_outputs=torch.ones_like(flux_y),
            create_graph=True,
            retain_graph=True,
        )[0][:, 1:2]
        return -(dflux_x + dflux_y) - source_values

    def sample_train_batches(self, device: torch.device) -> TrainBatches:
        interior_idx = self._select_indices(self.interior_indices, int(self.sampling["num_interior"]))
        boundary_idx = self._select_indices(self.boundary_indices, int(self.sampling["num_boundary"]))
        supervision_count = int(self.sampling["num_supervision"])
        if self.observation_shell == "spatial_blind_zone":
            supervision_idx, supervision_weights = self._supervision_weights(supervision_count, device=device)
        else:
            supervision_idx = self._select_indices(np.arange(self.full_inputs_np.shape[0]), supervision_count)
            supervision_weights = None

        interior = SampleBatch(
            inputs=torch.tensor(self.full_inputs_np[interior_idx], dtype=torch.float32, device=device),
            metadata={
                "kind": "interior",
                "grid_axes": {"x": 0, "y": 1},
                "domain_bounds": {
                    "x": (float(self.x.min()), float(self.x.max())),
                    "y": (float(self.y.min()), float(self.y.max())),
                },
                "source_values": torch.tensor(self.full_source_np[interior_idx], dtype=torch.float32, device=device),
            },
        )
        boundary = SampleBatch(
            inputs=torch.tensor(self.full_inputs_np[boundary_idx], dtype=torch.float32, device=device),
            targets=torch.tensor(self.full_solution_np[boundary_idx], dtype=torch.float32, device=device),
            metadata={"kind": "boundary"},
        )
        supervision = SampleBatch(
            inputs=torch.tensor(self.full_inputs_np[supervision_idx], dtype=torch.float32, device=device),
            targets=torch.tensor(self.full_targets_np[supervision_idx], dtype=torch.float32, device=device),
            weights=supervision_weights,
            metadata={
                "kind": "supervision",
                "grid_axes": {"x": 0, "y": 1},
                "domain_bounds": {
                    "x": (float(self.x.min()), float(self.x.max())),
                    "y": (float(self.y.min()), float(self.y.max())),
                },
                "parameter_name": "permeability_field",
                "observation_shell": self.observation_shell,
            },
        )
        return TrainBatches(
            interior=interior,
            boundary=boundary,
            supervision=supervision,
            metadata={
                "task_name": "darcy2d_inverse_permeability",
                "inverse_parameter_name": "permeability_field",
                "inverse_target_family": "latent_field",
                "supervision_source": "darcy2d_inverse_permeability_family_v1",
                "observation_shell": self.observation_shell,
            },
        )

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        del num_samples, grid_t, grid_x, grid_y
        return EvaluationBatch(
            inputs=torch.tensor(self.full_inputs_np, dtype=torch.float32, device=device),
            targets=torch.tensor(self.full_targets_np, dtype=torch.float32, device=device),
            name="darcy2d_inverse_permeability_grid",
            metadata={
                "grid_shape": (len(self.y), len(self.x)),
                "grid_axes": {"x": 0, "y": 1},
                "metric_weights": torch.tensor(self.metric_weights_np, dtype=torch.float32, device=device),
                "source_values": torch.tensor(self.full_source_np, dtype=torch.float32, device=device),
                "inverse_parameter_name": "permeability_field",
                "inverse_target_family": "latent_field",
                "supervision_source": "darcy2d_inverse_permeability_family_v1",
                "observation_shell": self.observation_shell,
            },
        )

    def compute_loss_terms(self, model: torch.nn.Module, batches: TrainBatches) -> dict[str, torch.Tensor]:
        if batches.boundary is None or batches.boundary.targets is None or batches.supervision is None or batches.supervision.targets is None:
            raise ValueError("Darcy2DInversePermeabilityTask requires boundary and supervision targets.")
        if batches.interior is None:
            raise ValueError("Darcy2DInversePermeabilityTask requires interior samples.")
        boundary_u, _ = self._predict_solution_and_logk(model, batches.boundary.inputs)
        supervision_u, _ = self._predict_solution_and_logk(model, batches.supervision.inputs)
        source_values = batches.interior.metadata["source_values"]
        assert isinstance(source_values, torch.Tensor)
        residual = self._residual(model, batches.interior.inputs, source_values=source_values)

        supervision_targets_u = batches.supervision.targets[:, :1]
        supervision_weights_u = None if batches.supervision.weights is None else batches.supervision.weights[:, :1]
        return {
            "field_supervision": weighted_mse_loss(supervision_u, supervision_targets_u, weights=supervision_weights_u),
            "boundary": weighted_mse_loss(boundary_u, batches.boundary.targets),
            "physics": torch.mean(residual**2),
        }

    def compute_metric(
        self,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        predicted_k = self._positive_permeability(predictions[:, 1:2])
        target_k = targets[:, 1:2]
        if metric_name == "parameter_error":
            return float(torch.linalg.norm(predicted_k - target_k).detach().item())
        if metric_name == "parameter_relative_error":
            return float((torch.linalg.norm(predicted_k - target_k) / (torch.linalg.norm(target_k) + 1e-12)).detach().item())
        if metric_name == "residual_metric":
            source_values = batch.metadata["source_values"]
            assert isinstance(source_values, torch.Tensor)
            residual = self._residual(model, batch.inputs, source_values=source_values)
            return float(torch.mean(residual**2).detach().item())
        return None
