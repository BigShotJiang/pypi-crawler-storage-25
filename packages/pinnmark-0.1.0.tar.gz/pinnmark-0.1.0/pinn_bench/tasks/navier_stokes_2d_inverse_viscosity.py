"""Operator-ready inverse Navier-Stokes rollout with a learnable viscosity parameter."""

from __future__ import annotations

from dataclasses import replace
from math import log
from typing import Any

import torch

from pinn_bench.registry import register_task
from pinn_bench.tasks.base import EvaluationBatch, weighted_mse_loss
from pinn_bench.tasks.navier_stokes_2d_operator_rollout import NavierStokes2DOperatorRolloutTask


@register_task("navier_stokes_2d_inverse_viscosity")
class NavierStokes2DInverseViscosityTask(NavierStokes2DOperatorRolloutTask):
    """Navier-Stokes rollout shell with a learnable viscosity and physics proxy metrics."""

    def __init__(
        self,
        input_dim: int = 3,
        output_dim: int = 2,
        true_viscosity: float = 0.01,
        initial_viscosity: float | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(input_dim=input_dim, output_dim=output_dim, **kwargs)
        self.true_viscosity = float(true_viscosity)
        self.initial_viscosity = float(initial_viscosity if initial_viscosity is not None else self.true_viscosity * 1.5)
        if self.initial_viscosity <= 0.0:
            raise ValueError("initial_viscosity must be positive.")
        self._log_viscosity = torch.nn.Parameter(torch.tensor(log(self.initial_viscosity), dtype=torch.float32))

    def trainable_parameters(self):
        return (self._log_viscosity,)

    def _current_viscosity_tensor(self) -> torch.Tensor:
        return torch.exp(self._log_viscosity)

    def current_viscosity(self) -> float:
        return float(self._current_viscosity_tensor().detach().item())

    @staticmethod
    def _field_tensor(predictions: torch.Tensor, metadata: dict[str, Any]) -> torch.Tensor:
        family_batch_size = int(metadata["family_batch_size"])
        grid_t, grid_y, grid_x = metadata["grid_shape"]
        return predictions.reshape(family_batch_size, grid_t, grid_y, grid_x, 2)

    def _physics_components(self, field_tensor: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        u = field_tensor[..., 0]
        v = field_tensor[..., 1]
        x = torch.tensor(self._family_payload["x"], dtype=field_tensor.dtype, device=field_tensor.device)
        y = torch.tensor(self._family_payload["y"], dtype=field_tensor.dtype, device=field_tensor.device)
        t = torch.tensor(self._family_payload["t"], dtype=field_tensor.dtype, device=field_tensor.device)[self._resolve_future_indices()]
        dx = float(x[1] - x[0]) if x.numel() > 1 else 1.0
        dy = float(y[1] - y[0]) if y.numel() > 1 else 1.0
        dt = float(t[1] - t[0]) if t.numel() > 1 else 1.0
        u_t, u_y, u_x = torch.gradient(u, spacing=(dt, dy, dx), dim=(1, 2, 3))
        v_t, v_y, v_x = torch.gradient(v, spacing=(dt, dy, dx), dim=(1, 2, 3))
        _, _, u_xx = torch.gradient(u_x, spacing=(dt, dy, dx), dim=(1, 2, 3))
        _, u_yy, _ = torch.gradient(u_y, spacing=(dt, dy, dx), dim=(1, 2, 3))
        _, _, v_xx = torch.gradient(v_x, spacing=(dt, dy, dx), dim=(1, 2, 3))
        _, v_yy, _ = torch.gradient(v_y, spacing=(dt, dy, dx), dim=(1, 2, 3))
        viscosity = self._current_viscosity_tensor()
        divergence = u_x + v_y
        momentum_residual = (u_t + u * u_x + v * u_y - viscosity * (u_xx + u_yy)) ** 2 + (
            v_t + u * v_x + v * v_y - viscosity * (v_xx + v_yy)
        ) ** 2
        return divergence, momentum_residual

    def sample_train_batches(self, device: torch.device):
        base = super().sample_train_batches(device=device)
        metadata = {
            **dict(base.metadata),
            "inverse_parameter_name": "viscosity",
            "inverse_target_family": "coefficient",
            "true_parameter_value": self.true_viscosity,
            "estimated_parameter_value": self.current_viscosity(),
        }
        return replace(base, metadata=metadata)

    def sample_evaluation_batch(
        self,
        device: torch.device,
        num_samples: int | None = None,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> EvaluationBatch:
        base = super().sample_evaluation_batch(
            device=device,
            num_samples=num_samples,
            grid_x=grid_x,
            grid_t=grid_t,
            grid_y=grid_y,
        )
        metadata = {
            **dict(base.metadata),
            "inverse_parameter_name": "viscosity",
            "inverse_target_family": "coefficient",
            "true_parameter_value": self.true_viscosity,
            "estimated_parameter_value": self.current_viscosity(),
        }
        return replace(base, metadata=metadata)

    def compute_loss_terms(self, model: torch.nn.Module, batches) -> dict[str, torch.Tensor]:
        if batches.supervision is None or batches.supervision.targets is None:
            raise ValueError("NavierStokes2DInverseViscosityTask requires a supervision batch with targets.")
        predictions = self._predict_field(model=model, batch=batches.supervision, batches=batches)
        field_loss = weighted_mse_loss(predictions, batches.supervision.targets, weights=batches.supervision.weights)
        field_tensor = self._field_tensor(predictions, batches.supervision.metadata)
        divergence, momentum = self._physics_components(field_tensor)
        return {
            "field_supervision": field_loss,
            "physics": torch.mean(divergence**2) + torch.mean(momentum),
        }

    def compute_metric(
        self,
        metric_name: str,
        *,
        model: torch.nn.Module,
        batch: EvaluationBatch,
        predictions: torch.Tensor,
        targets: torch.Tensor,
    ) -> float | None:
        del model, targets
        estimate = self.current_viscosity()
        if metric_name == "parameter_error":
            return float(abs(estimate - self.true_viscosity))
        if metric_name == "parameter_relative_error":
            return float(abs(estimate - self.true_viscosity) / max(abs(self.true_viscosity), 1e-12))
        field_tensor = self._field_tensor(predictions, batch.metadata)
        divergence, momentum = self._physics_components(field_tensor)
        if metric_name == "divergence_violation":
            return float(torch.mean(divergence**2).detach().item())
        if metric_name == "residual_metric":
            return float((torch.mean(divergence**2) + torch.mean(momentum)).detach().item())
        return None
