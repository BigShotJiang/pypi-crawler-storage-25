"""Fair-board registry, validator, and asset generation for the twenty-method universe."""

from __future__ import annotations

from dataclasses import dataclass
import csv
import json
import math
from pathlib import Path
from typing import Any

from pinn_bench.models.primary_method_registry import list_primary_method_records

REPO_ROOT = Path(__file__).resolve().parents[1]
ARTIFACT_ROOT = REPO_ROOT / "artifacts" / "benchmark_model_inventory"
PAPER_ROOT = REPO_ROOT / "paper" / "neurips2026"
OUTPUTS_ROOT = REPO_ROOT / "outputs_playground"

MAIN_SURFACE_ID = "canonical_global_solution_surface"
INVERSE_AUX_SURFACE_ID = "canonical_inverse_target_aux_surface"
INVERSE_JOINT_MAIN_SURFACE_ID = "canonical_inverse_joint_main_surface"
TRANSFER_AUX_SURFACE_ID = "canonical_transfer_operator_aux_surface"
MAIN_EVALUATION_CONTRACT_ID = "eval.global_solution.v1"
INVERSE_AUX_CONTRACT_ID = "eval.inverse_target_aux.v1"
INVERSE_JOINT_MAIN_CONTRACT_ID = "eval.inverse_joint_main.v1"
TRANSFER_AUX_CONTRACT_ID = "eval.transfer_operator_aux.v1"
TRAINING_BUDGET_CONTRACT_ID = "fair_train_budget_v1"
DATA_BUDGET_CONTRACT_ID = "fair_data_budget_v1"
SUPERVISION_BUDGET_CONTRACT_ID = "fair_supervision_budget_v1"
SCORE_SCHEMA_ID = "fair_global_error_score_v1"
INVERSE_JOINT_SCORE_SCHEMA_ID = "fair_inverse_joint_score_v1"
MAIN_METRIC_NAME = "field_relative_l2"
INVERSE_JOINT_MAIN_METRIC_NAME = "joint_inverse_main_score"
ALLOWED_COMPARISON_SCOPE = "matched_all"

REQUIRED_TESTS = (
    "tests/test_fair_board_pipeline.py",
    "tests/test_credible_use_contracts.py",
    "tests/test_all_method_runnable.py",
    "tests/test_twenty_method_internalization.py",
)

INVERSE_SHELL_BINDINGS: dict[str, str] = {
    "pinnmark.pinn.hpinn": "heat1d_inverse_diffusivity",
    "pinnmark.pinn.b_pinn": "heat1d_inverse_diffusivity",
    "pinnmark.pinn.sa_pinn": "heat1d_inverse_diffusivity",
    "pinnmark.pinn.hp_vpinn": "heat1d_inverse_diffusivity",
    "pinnmark.pinn.vpinn": "heat1d_inverse_diffusivity",
    "pinnmark.pinn.cpinn": "heat1d_inverse_diffusivity",
    "pinnmark.pinn.causal_sweeping": "heat1d_inverse_diffusivity",
    "pinnmark.hybrid.fbpinn": "burgers1d_inverse_viscosity",
    "pinnmark.multifidelity.mf_pidnn": "burgers1d_inverse_viscosity",
    "pinnmark.pinn.piann": "burgers1d_inverse_viscosity",
    "pinnmark.pinn.pinnsformer": "burgers1d_inverse_viscosity",
    "pinnmark.pinn.piratenets": "burgers1d_inverse_viscosity",
    "pinnmark.pinn.spinn": "burgers1d_inverse_viscosity",
    "pinnmark.operator.fno": "burgers1d_operator_inverse_viscosity",
    "pinnmark.operator.deeponet": "burgers1d_operator_inverse_viscosity",
    "pinnmark.operator.pi_deeponet": "burgers1d_operator_inverse_viscosity",
    "pinnmark.operator.pi_dion": "burgers1d_operator_inverse_viscosity",
    "pinnmark.operator.pi_gano": "burgers1d_operator_inverse_viscosity",
    "pinnmark.operator.pino": "burgers1d_operator_inverse_viscosity",
    "pinnmark.operator.vino": "burgers1d_operator_inverse_viscosity",
}

ALLOWED_FAIRNESS_ADJUSTMENTS = {
    "global_output_only_scoring",
    "decomposition_overhead_budgeted",
    "interface_flux_budgeted",
    "window_overlap_budgeted",
    "quadrature_budget_equalized",
    "test_function_budget_equalized",
    "hp_partition_budget_equalized",
    "operator_sample_budget_equalized",
    "physics_regularizer_budget_equalized",
    "inverse_supervision_budget_equalized",
    "geometry_context_budget_equalized",
    "multifidelity_channel_budget_equalized",
    "posterior_sampling_collapsed_to_mean_prediction",
    "uncertainty_outputs_removed_from_main_score",
    "adaptive_weight_updates_budgeted",
    "causal_schedule_budget_equalized",
    "sequence_token_budget_equalized",
    "recurrent_state_budget_equalized",
    "factorization_rank_budget_equalized",
    "constraint_ansatz_budgeted",
    "operator_context_budget_equalized",
}

METHOD_ARTIFACT_PREFERENCES: dict[str, str] = {
    "pinnmark.pinn.cpinn": "outputs_playground/twenty_method_push_evidence/cpinn_heat1d_nominal_smoke",
    "pinnmark.hybrid.fbpinn": "outputs_playground/all_method_runnable_evidence_runs/fbpinn_toy_smoke",
    "pinnmark.pinn.vpinn": "outputs_playground/all_method_runnable_evidence_runs/vpinn_heat_smoke",
    "pinnmark.pinn.hp_vpinn": "outputs_playground/all_method_runnable_evidence_runs/hp_vpinn_heat_smoke",
    "pinnmark.pinn.hpinn": "outputs_playground/all_method_runnable_evidence_runs/hpinn_heat_smoke",
    "pinnmark.pinn.b_pinn": "outputs_playground/twenty_method_push_evidence/b_pinn_heat1d_nominal_smoke",
    "pinnmark.pinn.sa_pinn": "outputs_playground/all_method_runnable_evidence_runs/sa_pinn_heat_smoke",
    "pinnmark.pinn.piratenets": "outputs_playground/all_method_runnable_evidence_runs/piratenets_toy_smoke",
    "pinnmark.pinn.pinnsformer": "outputs_playground/all_method_runnable_evidence_runs/pinnsformer_toy_smoke",
    "pinnmark.pinn.piann": "outputs_playground/all_method_runnable_evidence_runs/piann_toy_smoke",
    "pinnmark.pinn.spinn": "outputs_playground/all_method_runnable_evidence_runs/spinn_toy_smoke",
    "pinnmark.pinn.causal_sweeping": "outputs_playground/all_method_runnable_evidence_runs/causal_sweeping_pinns_heat_smoke",
    "pinnmark.operator.fno": "outputs_playground/all_method_runnable_evidence_runs/fno_operator_smoke",
    "pinnmark.operator.deeponet": "outputs_playground/all_method_runnable_evidence_runs/deeponet_operator_smoke",
    "pinnmark.operator.pino": "outputs_playground/all_method_runnable_evidence_runs/pino_operator_smoke",
    "pinnmark.operator.pi_deeponet": "outputs_playground/all_method_runnable_evidence_runs/pi_deeponet_operator_smoke",
    "pinnmark.operator.pi_dion": "outputs_playground/all_method_runnable_evidence_runs/pi_dion_operator_smoke",
    "pinnmark.operator.pi_gano": "outputs_playground/all_method_runnable_evidence_runs/pi_gano_operator_smoke",
    "pinnmark.operator.vino": "outputs_playground/all_method_runnable_evidence_runs/vino_operator_smoke",
    "pinnmark.multifidelity.mf_pidnn": "outputs_playground/all_method_runnable_evidence_runs/mf_pidnn_toy_smoke",
}


@dataclass(frozen=True)
class MethodFairnessConfig:
    standardization_strategy: str
    fairness_adjustments: tuple[str, ...]
    special_capabilities: tuple[str, ...]
    verdict: str
    secondary_surfaces: tuple[str, ...] = ()
    main_board_notes: str = ""


METHOD_FAIRNESS_CONFIGS: dict[str, MethodFairnessConfig] = {
    "pinnmark.pinn.cpinn": MethodFairnessConfig(
        standardization_strategy="decomposition_to_global_score_reduction",
        fairness_adjustments=("global_output_only_scoring", "decomposition_overhead_budgeted", "interface_flux_budgeted"),
        special_capabilities=(
            "interface_flux_terms_removed_from_main_score",
            "subdomain_metadata_reported_in_fairness_audit_only",
            "source_fidelity_not_claimed",
        ),
        verdict="fair_board_eligible_with_restricted_mapping",
        main_board_notes="XPINN-style proxy is admitted only as a global-output participant with decomposition overhead budgeted.",
    ),
    "pinnmark.hybrid.fbpinn": MethodFairnessConfig(
        standardization_strategy="decomposition_to_global_score_reduction",
        fairness_adjustments=("global_output_only_scoring", "decomposition_overhead_budgeted", "window_overlap_budgeted"),
        special_capabilities=(
            "window_basis_metadata_removed_from_main_score",
            "overlap_duplication_counted_in_budget",
            "proxy_runtime_disclosed",
        ),
        verdict="fair_board_eligible_with_restricted_mapping",
        main_board_notes="Finite-basis decomposition is folded into the same global score contract as other forward participants.",
    ),
    "pinnmark.pinn.vpinn": MethodFairnessConfig(
        standardization_strategy="weak_form_evaluation_alignment",
        fairness_adjustments=("quadrature_budget_equalized", "test_function_budget_equalized"),
        special_capabilities=(
            "weak_form_energy_not_used_for_main_score",
            "quadrature_metadata_budgeted",
            "test_function_search_disallowed",
        ),
        verdict="fair_board_eligible_with_budget_equalization",
        main_board_notes="Weak-form training is permitted, but main-board scoring always uses standardized held-out field error.",
    ),
    "pinnmark.pinn.hp_vpinn": MethodFairnessConfig(
        standardization_strategy="weak_form_evaluation_alignment",
        fairness_adjustments=("quadrature_budget_equalized", "test_function_budget_equalized", "hp_partition_budget_equalized"),
        special_capabilities=(
            "hp_partition_schedule_locked",
            "polynomial_order_search_disallowed",
            "weak_form_moments_removed_from_main_score",
        ),
        verdict="fair_board_eligible_with_budget_equalization",
        main_board_notes="hp refinement is admitted only under locked budget fields and global held-out scoring.",
    ),
    "pinnmark.pinn.hpinn": MethodFairnessConfig(
        standardization_strategy="restricted_standardization",
        fairness_adjustments=("constraint_ansatz_budgeted",),
        special_capabilities=(
            "hard_constraint_diagnostics_removed_from_main_score",
            "constraint_transform_must_derive_from_public_task_spec",
        ),
        verdict="fair_board_eligible_with_restricted_mapping",
        main_board_notes="Hard constraints may shape training, but the main board only scores the resulting global field.",
    ),
    "pinnmark.pinn.b_pinn": MethodFairnessConfig(
        standardization_strategy="posterior_mean_standardization",
        fairness_adjustments=("posterior_sampling_collapsed_to_mean_prediction", "uncertainty_outputs_removed_from_main_score"),
        special_capabilities=(
            "posterior_draw_budget_reported",
            "uncertainty_calibration_removed_from_main_score",
            "variational_parameter_expansion_budgeted",
        ),
        verdict="fair_board_eligible_with_budget_equalization",
        main_board_notes="Bayesian runs enter the board only through a deterministic posterior-summary prediction.",
    ),
    "pinnmark.pinn.sa_pinn": MethodFairnessConfig(
        standardization_strategy="direct_surface_alignment",
        fairness_adjustments=("adaptive_weight_updates_budgeted",),
        special_capabilities=(
            "loss_weight_trajectory_supplementary_only",
            "adaptive_weight_state_budgeted",
        ),
        verdict="fair_board_eligible",
        main_board_notes="Adaptive weighting is treated as internal optimization state under the shared budget.",
    ),
    "pinnmark.pinn.piratenets": MethodFairnessConfig(
        standardization_strategy="direct_surface_alignment",
        fairness_adjustments=(),
        special_capabilities=(
            "architecture_bias_retained_as_method_identity",
            "no_extra_information_channel",
        ),
        verdict="fair_board_eligible",
        main_board_notes="Architecture differences remain part of the method identity but do not change the shared participant contract.",
    ),
    "pinnmark.pinn.pinnsformer": MethodFairnessConfig(
        standardization_strategy="restricted_standardization",
        fairness_adjustments=("sequence_token_budget_equalized",),
        special_capabilities=(
            "attention_maps_supplementary_only",
            "sequence_token_budget_locked",
            "teacher_forcing_advantage_disallowed",
        ),
        verdict="fair_board_eligible_with_budget_equalization",
        main_board_notes="Transformer sequence machinery is allowed only within the shared token budget.",
    ),
    "pinnmark.pinn.piann": MethodFairnessConfig(
        standardization_strategy="restricted_standardization",
        fairness_adjustments=("sequence_token_budget_equalized", "recurrent_state_budget_equalized"),
        special_capabilities=(
            "recurrent_state_diagnostics_supplementary_only",
            "autoregressive_teacher_signals_disallowed",
            "sequence_budget_locked",
        ),
        verdict="fair_board_eligible_with_budget_equalization",
        main_board_notes="Attention/recurrent state is budgeted, while the main board only uses the final standardized field prediction.",
    ),
    "pinnmark.pinn.spinn": MethodFairnessConfig(
        standardization_strategy="direct_surface_alignment",
        fairness_adjustments=("factorization_rank_budget_equalized",),
        special_capabilities=(
            "factor_rank_manifest_required",
            "separable_factor_diagnostics_supplementary_only",
        ),
        verdict="fair_board_eligible",
        main_board_notes="Factorization rank is reported and capped, but the score remains the shared field error.",
    ),
    "pinnmark.pinn.causal_sweeping": MethodFairnessConfig(
        standardization_strategy="restricted_standardization",
        fairness_adjustments=("causal_schedule_budget_equalized",),
        special_capabilities=(
            "causal_stage_curves_supplementary_only",
            "schedule_budget_locked",
            "stagewise_bonus_compute_disallowed",
        ),
        verdict="fair_board_eligible_with_budget_equalization",
        main_board_notes="Causal schedules are treated as budgeted training policy, not a separate score object.",
    ),
    "pinnmark.operator.fno": MethodFairnessConfig(
        standardization_strategy="direct_surface_alignment",
        fairness_adjustments=("operator_sample_budget_equalized",),
        special_capabilities=(
            "spectral_block_details_supplementary_only",
            "operator_conditioning_shared_with_all_operator_entries",
        ),
        verdict="fair_board_eligible",
        secondary_surfaces=(TRANSFER_AUX_SURFACE_ID,),
        main_board_notes="Operator baselines are admitted directly because they already match the shared condition/query -> field participant form.",
    ),
    "pinnmark.operator.deeponet": MethodFairnessConfig(
        standardization_strategy="direct_surface_alignment",
        fairness_adjustments=("operator_sample_budget_equalized",),
        special_capabilities=(
            "branch_trunk_interpretability_supplementary_only",
            "operator_conditioning_shared_with_all_operator_entries",
        ),
        verdict="fair_board_eligible",
        secondary_surfaces=(TRANSFER_AUX_SURFACE_ID,),
        main_board_notes="DeepONet uses the same standardized operator participant form as FNO on the main board.",
    ),
    "pinnmark.operator.pino": MethodFairnessConfig(
        standardization_strategy="budget_equalized_operator_mapping",
        fairness_adjustments=("operator_sample_budget_equalized", "physics_regularizer_budget_equalized"),
        special_capabilities=(
            "physics_regularizer_removed_from_main_score",
            "extra_collocation_bonus_disallowed",
            "physics_weight_search_budgeted",
        ),
        verdict="fair_board_eligible_with_budget_equalization",
        secondary_surfaces=(TRANSFER_AUX_SURFACE_ID,),
        main_board_notes="Physics-informed operator terms count as budgeted auxiliary regularization and never create a separate main-board score path.",
    ),
    "pinnmark.operator.pi_deeponet": MethodFairnessConfig(
        standardization_strategy="budget_equalized_operator_mapping",
        fairness_adjustments=("operator_sample_budget_equalized", "physics_regularizer_budget_equalized"),
        special_capabilities=(
            "physics_regularizer_removed_from_main_score",
            "extra_collocation_bonus_disallowed",
            "physics_weight_search_budgeted",
        ),
        verdict="fair_board_eligible_with_budget_equalization",
        secondary_surfaces=(TRANSFER_AUX_SURFACE_ID,),
        main_board_notes="PI-DeepONet is normalized to the same operator participant form as other operator models.",
    ),
    "pinnmark.operator.pi_dion": MethodFairnessConfig(
        standardization_strategy="inverse_to_field_mapping",
        fairness_adjustments=("inverse_supervision_budget_equalized", "operator_context_budget_equalized"),
        special_capabilities=(
            "inverse_target_reporting_aux_surface_only",
            "latent_operator_states_removed_from_main_score",
            "observation_budget_manifest_required",
        ),
        verdict="fair_board_eligible_with_restricted_mapping",
        secondary_surfaces=(INVERSE_AUX_SURFACE_ID,),
        main_board_notes="Inverse outputs are folded into a standardized field-reconstruction participant for the main board.",
    ),
    "pinnmark.operator.pi_gano": MethodFairnessConfig(
        standardization_strategy="geometry_conditioned_field_mapping",
        fairness_adjustments=("operator_sample_budget_equalized", "geometry_context_budget_equalized"),
        special_capabilities=(
            "geometry_latent_interpolation_supplementary_only",
            "geometry_representation_manifest_required",
            "unshared_geometry_oracles_disallowed",
        ),
        verdict="fair_board_eligible_with_budget_equalization",
        secondary_surfaces=(TRANSFER_AUX_SURFACE_ID,),
        main_board_notes="Geometry conditioning is allowed only as a budgeted shared input channel on the main board.",
    ),
    "pinnmark.operator.vino": MethodFairnessConfig(
        standardization_strategy="weak_form_evaluation_alignment",
        fairness_adjustments=("operator_sample_budget_equalized", "quadrature_budget_equalized", "test_function_budget_equalized"),
        special_capabilities=(
            "variational_energy_removed_from_main_score",
            "energy_query_budget_reported",
            "extra_variational_mesh_bonus_disallowed",
        ),
        verdict="fair_board_eligible_with_budget_equalization",
        secondary_surfaces=(TRANSFER_AUX_SURFACE_ID,),
        main_board_notes="Variational operator training is folded back to the standardized operator field score on the main board.",
    ),
    "pinnmark.multifidelity.mf_pidnn": MethodFairnessConfig(
        standardization_strategy="multifidelity_budget_folding",
        fairness_adjustments=("multifidelity_channel_budget_equalized",),
        special_capabilities=(
            "fidelity_channel_ledger_required",
            "transfer_gain_removed_from_main_score",
            "extra_low_fidelity_labels_budgeted",
        ),
        verdict="fair_board_eligible_with_budget_equalization",
        main_board_notes="Low/high fidelity channels are admitted only through a declared auxiliary credit ledger.",
    ),
}


@dataclass(frozen=True)
class CanonicalSurfaceRecord:
    surface_id: str
    display_name: str
    surface_role: str
    problem_object: str
    standardized_participant_form: str
    standardized_input_contract: str
    standardized_output_contract: str
    allowed_methods: tuple[str, ...]
    evaluation_contract_id: str
    score_schema_id: str
    eligible_for_main_fair_board: bool
    fairness_notes: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "surface_id": self.surface_id,
            "display_name": self.display_name,
            "surface_role": self.surface_role,
            "problem_object": self.problem_object,
            "standardized_participant_form": self.standardized_participant_form,
            "standardized_input_contract": self.standardized_input_contract,
            "standardized_output_contract": self.standardized_output_contract,
            "allowed_methods": list(self.allowed_methods),
            "evaluation_contract_id": self.evaluation_contract_id,
            "score_schema_id": self.score_schema_id,
            "eligible_for_main_fair_board": self.eligible_for_main_fair_board,
            "fairness_notes": list(self.fairness_notes),
        }


@dataclass(frozen=True)
class EvaluationContractRecord:
    evaluation_contract_id: str
    surface_id: str
    surface_role: str
    problem_object: str
    standardized_input_contract: str
    standardized_output_contract: str
    standardized_participant_form: str
    train_split_rule: str
    val_split_rule: str
    test_split_rule: str
    sampling_rule: str
    collocation_budget_rule: str
    quadrature_budget_rule: str
    operator_sample_budget_rule: str
    observation_budget_rule: str
    boundary_initial_budget_rule: str
    fidelity_channel_budget_rule: str
    train_step_budget_rule: str
    wallclock_budget_rule: str
    parameter_budget_rule: str
    seed_policy: str
    optimizer_family_rule: str
    model_selection_rule: str
    early_stopping_rule: str
    metric_bundle: tuple[str, ...]
    main_metric: str
    score_aggregation_rule: str
    allowed_auxiliary_signals: tuple[str, ...]
    disallowed_extra_advantages: tuple[str, ...]
    fairness_constraints: tuple[str, ...]
    reporting_template: str
    eligible_for_main_fair_board: bool
    training_budget_contract: str
    data_budget_contract: str
    supervision_budget_contract: str

    def to_dict(self) -> dict[str, object]:
        return {
            "evaluation_contract_id": self.evaluation_contract_id,
            "surface_id": self.surface_id,
            "surface_role": self.surface_role,
            "problem_object": self.problem_object,
            "standardized_input_contract": self.standardized_input_contract,
            "standardized_output_contract": self.standardized_output_contract,
            "standardized_participant_form": self.standardized_participant_form,
            "train_split_rule": self.train_split_rule,
            "val_split_rule": self.val_split_rule,
            "test_split_rule": self.test_split_rule,
            "sampling_rule": self.sampling_rule,
            "collocation_budget_rule": self.collocation_budget_rule,
            "quadrature_budget_rule": self.quadrature_budget_rule,
            "operator_sample_budget_rule": self.operator_sample_budget_rule,
            "observation_budget_rule": self.observation_budget_rule,
            "boundary_initial_budget_rule": self.boundary_initial_budget_rule,
            "fidelity_channel_budget_rule": self.fidelity_channel_budget_rule,
            "train_step_budget_rule": self.train_step_budget_rule,
            "wallclock_budget_rule": self.wallclock_budget_rule,
            "parameter_budget_rule": self.parameter_budget_rule,
            "seed_policy": self.seed_policy,
            "optimizer_family_rule": self.optimizer_family_rule,
            "model_selection_rule": self.model_selection_rule,
            "early_stopping_rule": self.early_stopping_rule,
            "metric_bundle": list(self.metric_bundle),
            "main_metric": self.main_metric,
            "score_aggregation_rule": self.score_aggregation_rule,
            "allowed_auxiliary_signals": list(self.allowed_auxiliary_signals),
            "disallowed_extra_advantages": list(self.disallowed_extra_advantages),
            "fairness_constraints": list(self.fairness_constraints),
            "reporting_template": self.reporting_template,
            "eligible_for_main_fair_board": self.eligible_for_main_fair_board,
            "training_budget_contract": self.training_budget_contract,
            "data_budget_contract": self.data_budget_contract,
            "supervision_budget_contract": self.supervision_budget_contract,
        }


def _read_rows(path: Path) -> list[dict[str, Any]]:
    return json.loads(path.read_text(encoding="utf-8"))["rows"]


def _normalize_mixed_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        parts: list[str] = []
        for item in value:
            parts.extend(_normalize_mixed_list(item))
        return parts
    text = str(value).strip()
    if not text:
        return []
    return [part.strip() for part in text.split("|") if part.strip()]


def _first_mixed(value: Any) -> str:
    items = _normalize_mixed_list(value)
    if not items:
        raise ValueError(f"Expected at least one value, received: {value!r}")
    return items[0]


def _load_contract_rows() -> dict[str, dict[str, Any]]:
    rows = _read_rows(ARTIFACT_ROOT / "credible_use_contracts.json")
    return {str(row["canonical_id"]): row for row in rows}


def _load_evidence_rows() -> dict[str, dict[str, Any]]:
    rows = _read_rows(ARTIFACT_ROOT / "method_evidence_registry.json")
    return {str(row["method_id"]): row for row in rows}


def _load_gap_rows() -> dict[str, dict[str, Any]]:
    rows = _read_rows(ARTIFACT_ROOT / "contract_gap_audit.json")
    return {str(row["canonical_id"]): row for row in rows}


def _primary_records() -> dict[str, Any]:
    return {record.method_id: record for record in list_primary_method_records()}


def _surface_records(method_ids: list[str]) -> list[CanonicalSurfaceRecord]:
    inverse_joint_allowed_methods = tuple(sorted({*method_ids, "pinnmark.operator.pi_dion"}))
    return [
        CanonicalSurfaceRecord(
            surface_id=MAIN_SURFACE_ID,
            display_name="Canonical Global Solution Surface",
            surface_role="main_fair_board_surface",
            problem_object="standardized task bundle to global solution field on canonical evaluation mesh",
            standardized_participant_form="global_solution_field_participant",
            standardized_input_contract="canonical_task_bundle_v1",
            standardized_output_contract="global_field_on_canonical_eval_mesh_v1",
            allowed_methods=tuple(method_ids),
            evaluation_contract_id=MAIN_EVALUATION_CONTRACT_ID,
            score_schema_id=SCORE_SCHEMA_ID,
            eligible_for_main_fair_board=True,
            fairness_notes=(
                "main board compares only standardized held-out field prediction",
                "special capabilities are either budgeted or stripped from the main score",
                "fidelity is reported separately from fairness eligibility",
            ),
        ),
        CanonicalSurfaceRecord(
            surface_id=INVERSE_JOINT_MAIN_SURFACE_ID,
            display_name="Canonical Inverse Joint Main Surface",
            surface_role="parallel_main_candidate",
            problem_object="standardized inverse recovery bundle with jointly scored field reconstruction, latent parameter recovery, and physics consistency",
            standardized_participant_form="inverse_joint_recovery_participant",
            standardized_input_contract="canonical_task_bundle_v1",
            standardized_output_contract="inverse_joint_bundle_v1",
            allowed_methods=inverse_joint_allowed_methods,
            evaluation_contract_id=INVERSE_JOINT_MAIN_CONTRACT_ID,
            score_schema_id=INVERSE_JOINT_SCORE_SCHEMA_ID,
            eligible_for_main_fair_board=False,
            fairness_notes=(
                "parallel compatibility lane for inverse-joint remediation; legacy frozen board remains authoritative until upgraded artifacts and tests land",
                "joint ordering must expose field, parameter, and physics components instead of collapsing everything into field-only ranking",
            ),
        ),
        CanonicalSurfaceRecord(
            surface_id=INVERSE_AUX_SURFACE_ID,
            display_name="Canonical Inverse Target Auxiliary Surface",
            surface_role="supplementary_only",
            problem_object="standardized inverse target estimate plus aligned field reconstruction",
            standardized_participant_form="inverse_target_aux_participant",
            standardized_input_contract="canonical_task_bundle_v1",
            standardized_output_contract="inverse_target_bundle_v1",
            allowed_methods=("pinnmark.operator.pi_dion",),
            evaluation_contract_id=INVERSE_AUX_CONTRACT_ID,
            score_schema_id=SCORE_SCHEMA_ID,
            eligible_for_main_fair_board=False,
            fairness_notes=(
                "inverse target quality is supplementary and never drives main-board ordering",
            ),
        ),
        CanonicalSurfaceRecord(
            surface_id=TRANSFER_AUX_SURFACE_ID,
            display_name="Canonical Transfer/Operator Auxiliary Surface",
            surface_role="supplementary_only",
            problem_object="operator or geometry-conditioned transfer field prediction",
            standardized_participant_form="transfer_operator_aux_participant",
            standardized_input_contract="canonical_task_bundle_v1",
            standardized_output_contract="global_field_on_canonical_eval_mesh_v1",
            allowed_methods=(
                "pinnmark.operator.fno",
                "pinnmark.operator.deeponet",
                "pinnmark.operator.pino",
                "pinnmark.operator.pi_deeponet",
                "pinnmark.operator.pi_gano",
                "pinnmark.operator.vino",
            ),
            evaluation_contract_id=TRANSFER_AUX_CONTRACT_ID,
            score_schema_id=SCORE_SCHEMA_ID,
            eligible_for_main_fair_board=False,
            fairness_notes=(
                "operator/transfer diagnostics remain supplementary once main-board scoring has been standardized",
            ),
        ),
    ]


def _evaluation_contracts() -> list[EvaluationContractRecord]:
    shared_allowed_aux = (
        "public_task_specification",
        "canonical_observation_set",
        "geometry_descriptor_if_budgeted",
        "operator_context_if_budgeted",
        "low_fidelity_channel_if_budgeted",
        "quadrature_or_test_function_metadata_if_budgeted",
    )
    shared_disallowed = (
        "unbudgeted_extra_target_labels",
        "unbudgeted_extra_collocation_mesh",
        "test_time_solver_oracle",
        "unshared_geometry_labels",
        "unshared_low_fidelity_teacher",
        "source_faithful_claim_without_support",
    )
    shared_constraints = (
        "all main-board entries must bind to the same surface and evaluation contract",
        "training, data, and supervision contracts must be present",
        "all extra method-specific capabilities must appear in fairness_adjustments or special_capabilities_stripped_or_budgeted",
        "main-board score uses only standardized held-out field metrics",
    )
    return [
        EvaluationContractRecord(
            evaluation_contract_id=MAIN_EVALUATION_CONTRACT_ID,
            surface_id=MAIN_SURFACE_ID,
            surface_role="main_fair_board_surface",
            problem_object="standardized task bundle to global solution field on canonical evaluation mesh",
            standardized_input_contract="canonical_task_bundle_v1",
            standardized_output_contract="global_field_on_canonical_eval_mesh_v1",
            standardized_participant_form="global_solution_field_participant",
            train_split_rule="use the checked-in canonical participant artifact and its resolved train split",
            val_split_rule="use the checked-in canonical participant artifact and its resolved validation split when present",
            test_split_rule="score only on the canonical held-out evaluation mesh bundled with the selected artifact",
            sampling_rule="normalize pointwise, operator, inverse, geometry, and multifidelity runs to the same held-out field prediction object",
            collocation_budget_rule="collocation, decomposition, and physics residual evaluations count against one shared budget family",
            quadrature_budget_rule="quadrature/test-function work is permitted only when counted inside the shared budget family",
            operator_sample_budget_rule="condition/query samples must come from the same declared participant artifact and count against one operator sample budget",
            observation_budget_rule="inverse observations may inform the participant only when declared and budgeted",
            boundary_initial_budget_rule="boundary/initial samples count inside the same shared budget family and do not create bonus score channels",
            fidelity_channel_budget_rule="extra low/high-fidelity channels must be declared and budgeted or are disallowed",
            train_step_budget_rule="shared train-step/epoch cap family with method-specific addenda disclosed via fairness adjustments",
            wallclock_budget_rule="shared wallclock cap family with decomposition/sequence/physics overheads budgeted rather than hidden",
            parameter_budget_rule="all parameter counts must be reported using the full effective participant footprint",
            seed_policy="shared seed-count policy; main score aggregates across the fixed seed set carried by the artifact",
            optimizer_family_rule="shared optimizer family or fixed-recipe equivalents only",
            model_selection_rule="shared fixed-recipe or bounded tuning rule; no hidden search outside the declared budget",
            early_stopping_rule="shared early stopping or explicit no-early-stopping disclosure",
            metric_bundle=("field_relative_l2", "field_mse"),
            main_metric=MAIN_METRIC_NAME,
            score_aggregation_rule="main_score equals the standardized field_relative_l2; lower is better; field_mse remains auxiliary",
            allowed_auxiliary_signals=shared_allowed_aux,
            disallowed_extra_advantages=shared_disallowed,
            fairness_constraints=shared_constraints,
            reporting_template="main_fair_board_v1",
            eligible_for_main_fair_board=True,
            training_budget_contract=TRAINING_BUDGET_CONTRACT_ID,
            data_budget_contract=DATA_BUDGET_CONTRACT_ID,
            supervision_budget_contract=SUPERVISION_BUDGET_CONTRACT_ID,
        ),
        EvaluationContractRecord(
            evaluation_contract_id=INVERSE_JOINT_MAIN_CONTRACT_ID,
            surface_id=INVERSE_JOINT_MAIN_SURFACE_ID,
            surface_role="parallel_main_candidate",
            problem_object="standardized inverse recovery bundle with jointly scored field reconstruction, latent parameter recovery, and physics consistency",
            standardized_input_contract="canonical_task_bundle_v1",
            standardized_output_contract="inverse_joint_bundle_v1",
            standardized_participant_form="inverse_joint_recovery_participant",
            train_split_rule="inherits the checked-in canonical participant artifact and its resolved train split",
            val_split_rule="inherits the checked-in canonical participant artifact and its resolved validation split when present",
            test_split_rule="scores on the canonical held-out evaluation mesh plus declared inverse targets and physics consistency diagnostics",
            sampling_rule="preserves the shared participant artifact while exposing field, parameter, and physics components in parallel",
            collocation_budget_rule="collocation and physics consistency evaluations remain inside the same shared budget family",
            quadrature_budget_rule="inherits the main contract unless a method already declares budgeted quadrature/test-function work",
            operator_sample_budget_rule="inherits the main contract and disallows extra inverse-only operator query bonuses",
            observation_budget_rule="inverse observations may inform the participant only when declared and budgeted; latent target recovery must be reported explicitly",
            boundary_initial_budget_rule="inherits the main contract and does not create bonus score channels",
            fidelity_channel_budget_rule="inherits the main contract and requires declared low/high-fidelity channels",
            train_step_budget_rule="inherits the main contract with any inverse-specific addenda disclosed via fairness adjustments",
            wallclock_budget_rule="inherits the main contract and requires physics-consistency overhead disclosure rather than hidden compute",
            parameter_budget_rule="inherits the main contract and reports the full effective participant footprint",
            seed_policy="parallel remediation lane should support configurable shared seed-count policy rather than the frozen two-seed board",
            optimizer_family_rule="inherits the main contract",
            model_selection_rule="inherits the main contract and forbids hidden seed-family selection before reporting",
            early_stopping_rule="inherits the main contract and requires explicit disclosure when used",
            metric_bundle=("field_relative_l2", "inverse_target_relative_error", "residual_metric"),
            main_metric=INVERSE_JOINT_MAIN_METRIC_NAME,
            score_aggregation_rule="parallel joint board must report component metrics separately and may expose a composite only as an auxiliary ordering aid",
            allowed_auxiliary_signals=shared_allowed_aux,
            disallowed_extra_advantages=shared_disallowed,
            fairness_constraints=(
                "parallel compatibility surface only until upgraded artifacts/tests land",
                "joint board cannot hide parameter or physics components behind a field-only scalar",
            ),
            reporting_template="inverse_joint_main_board_v1",
            eligible_for_main_fair_board=False,
            training_budget_contract=TRAINING_BUDGET_CONTRACT_ID,
            data_budget_contract=DATA_BUDGET_CONTRACT_ID,
            supervision_budget_contract=SUPERVISION_BUDGET_CONTRACT_ID,
        ),
        EvaluationContractRecord(
            evaluation_contract_id=INVERSE_AUX_CONTRACT_ID,
            surface_id=INVERSE_AUX_SURFACE_ID,
            surface_role="supplementary_only",
            problem_object="inverse target estimate plus aligned field reconstruction",
            standardized_input_contract="canonical_task_bundle_v1",
            standardized_output_contract="inverse_target_bundle_v1",
            standardized_participant_form="inverse_target_aux_participant",
            train_split_rule="inherits the main participant artifact splits",
            val_split_rule="inherits the main participant artifact splits",
            test_split_rule="evaluates declared inverse targets only",
            sampling_rule="auxiliary inverse targets do not alter main-board admission",
            collocation_budget_rule="inherits the main contract",
            quadrature_budget_rule="inherits the main contract",
            operator_sample_budget_rule="inherits the main contract",
            observation_budget_rule="reports inverse-target quality under the declared observation budget",
            boundary_initial_budget_rule="inherits the main contract",
            fidelity_channel_budget_rule="inherits the main contract",
            train_step_budget_rule="inherits the main contract",
            wallclock_budget_rule="inherits the main contract",
            parameter_budget_rule="inherits the main contract",
            seed_policy="inherits the main contract",
            optimizer_family_rule="inherits the main contract",
            model_selection_rule="inherits the main contract",
            early_stopping_rule="inherits the main contract",
            metric_bundle=("inverse_target_relative_error", "field_relative_l2"),
            main_metric="inverse_target_relative_error",
            score_aggregation_rule="supplementary only",
            allowed_auxiliary_signals=shared_allowed_aux,
            disallowed_extra_advantages=shared_disallowed,
            fairness_constraints=("supplementary surface only",),
            reporting_template="inverse_aux_surface_v1",
            eligible_for_main_fair_board=False,
            training_budget_contract=TRAINING_BUDGET_CONTRACT_ID,
            data_budget_contract=DATA_BUDGET_CONTRACT_ID,
            supervision_budget_contract=SUPERVISION_BUDGET_CONTRACT_ID,
        ),
        EvaluationContractRecord(
            evaluation_contract_id=TRANSFER_AUX_CONTRACT_ID,
            surface_id=TRANSFER_AUX_SURFACE_ID,
            surface_role="supplementary_only",
            problem_object="operator/transfer diagnostics on the same standardized field object",
            standardized_input_contract="canonical_task_bundle_v1",
            standardized_output_contract="global_field_on_canonical_eval_mesh_v1",
            standardized_participant_form="transfer_operator_aux_participant",
            train_split_rule="inherits the main participant artifact splits",
            val_split_rule="inherits the main participant artifact splits",
            test_split_rule="uses the same held-out mesh but reports transfer/operator-specific diagnostics",
            sampling_rule="supplementary transfer/operator metrics do not alter main-board ordering",
            collocation_budget_rule="inherits the main contract",
            quadrature_budget_rule="inherits the main contract",
            operator_sample_budget_rule="inherits the main contract",
            observation_budget_rule="inherits the main contract",
            boundary_initial_budget_rule="inherits the main contract",
            fidelity_channel_budget_rule="inherits the main contract",
            train_step_budget_rule="inherits the main contract",
            wallclock_budget_rule="inherits the main contract",
            parameter_budget_rule="inherits the main contract",
            seed_policy="inherits the main contract",
            optimizer_family_rule="inherits the main contract",
            model_selection_rule="inherits the main contract",
            early_stopping_rule="inherits the main contract",
            metric_bundle=("shifted_field_relative_l2", "degradation_ratio"),
            main_metric="shifted_field_relative_l2",
            score_aggregation_rule="supplementary only",
            allowed_auxiliary_signals=shared_allowed_aux,
            disallowed_extra_advantages=shared_disallowed,
            fairness_constraints=("supplementary surface only",),
            reporting_template="transfer_operator_aux_surface_v1",
            eligible_for_main_fair_board=False,
            training_budget_contract=TRAINING_BUDGET_CONTRACT_ID,
            data_budget_contract=DATA_BUDGET_CONTRACT_ID,
            supervision_budget_contract=SUPERVISION_BUDGET_CONTRACT_ID,
        ),
    ]


def _scan_metrics_by_model() -> dict[str, list[str]]:
    payload: dict[str, list[str]] = {}
    for metrics_path in OUTPUTS_ROOT.rglob("metrics.json"):
        try:
            payload_json = json.loads(metrics_path.read_text(encoding="utf-8"))
        except Exception:
            continue
        model_name = str(payload_json.get("metadata", {}).get("model_name") or "").strip()
        if not model_name:
            continue
        relative_dir = str(metrics_path.parent.relative_to(REPO_ROOT))
        payload.setdefault(model_name, []).append(relative_dir)
    return payload


def _select_artifact_path(method_id: str, by_model: dict[str, list[str]]) -> str:
    preferred = METHOD_ARTIFACT_PREFERENCES.get(method_id)
    if preferred is not None and (REPO_ROOT / preferred / "metrics.json").exists():
        return preferred
    candidates = by_model.get(method_id, [])
    if candidates:
        return sorted(candidates)[0]
    raise FileNotFoundError(f"No metrics.json found for {method_id}")


def _load_metrics_bundle(artifact_path: str) -> tuple[dict[str, Any], dict[str, float]]:
    metrics_path = REPO_ROOT / artifact_path / "metrics.json"
    payload = json.loads(metrics_path.read_text(encoding="utf-8"))
    eval_payload = payload.get("eval", {})
    raw_rel = eval_payload.get("field_relative_l2", eval_payload.get("relative_l2"))
    raw_mse = eval_payload.get("field_mse", eval_payload.get("mse"))
    if raw_rel is None or raw_mse is None:
        raise KeyError(f"Artifact {artifact_path} is missing field-relative metrics")
    normalized = {
        "field_relative_l2": float(raw_rel),
        "field_mse": float(raw_mse),
    }
    return payload, normalized


def _load_main_inverse_selection_rows() -> dict[str, dict[str, Any]]:
    selection_path = ARTIFACT_ROOT / "main_inverse_dual_board_selection.json"
    if not selection_path.exists():
        return {}
    payload = json.loads(selection_path.read_text(encoding="utf-8"))
    rows = payload.get("rows", [])
    if not isinstance(rows, list):
        return {}
    return {
        str(row.get("canonical_id")): dict(row)
        for row in rows
        if isinstance(row, dict) and row.get("canonical_id")
    }


def _selection_metric_bundle(method_id: str) -> dict[str, float] | None:
    selection = _load_main_inverse_selection_rows().get(method_id)
    if not selection:
        return None
    selected_run_root = str(selection.get("selected_run_root") or "").strip()
    seed_list = selection.get("seed_list") or []
    if not selected_run_root or not seed_list:
        return None
    run_root = REPO_ROOT / selected_run_root
    seed_rows: list[dict[str, float]] = []
    for seed in seed_list:
        try:
            seed_int = int(seed)
        except (TypeError, ValueError):
            continue
        metrics_path = run_root / f"seed_{seed_int:02d}" / "metrics.json"
        if not metrics_path.exists():
            continue
        payload = json.loads(metrics_path.read_text(encoding="utf-8"))
        eval_payload = payload.get("eval", {})
        field_relative_l2 = eval_payload.get("field_relative_l2", eval_payload.get("relative_l2"))
        inverse_target = eval_payload.get("inverse_target_relative_error", eval_payload.get("parameter_relative_error"))
        residual_metric = eval_payload.get("physics_consistency", eval_payload.get("residual_metric"))
        if field_relative_l2 is None or inverse_target is None or residual_metric is None:
            continue
        seed_rows.append(
            {
                "field_relative_l2": float(field_relative_l2),
                "inverse_target_relative_error": float(inverse_target),
                "residual_metric": float(residual_metric),
            }
        )
    if not seed_rows:
        return None
    bundle = {
        "field_relative_l2": sum(row["field_relative_l2"] for row in seed_rows) / len(seed_rows),
        "inverse_target_relative_error": sum(row["inverse_target_relative_error"] for row in seed_rows) / len(seed_rows),
        "residual_metric": sum(row["residual_metric"] for row in seed_rows) / len(seed_rows),
    }
    bundle["joint_inverse_main_score"] = (
        bundle["field_relative_l2"] + bundle["inverse_target_relative_error"] + bundle["residual_metric"]
    ) / 3.0
    return bundle


def _inverse_joint_metric_bundle(eval_payload: dict[str, Any], normalized_metrics: dict[str, float]) -> dict[str, float] | None:
    inverse_target = eval_payload.get("inverse_target_relative_error", eval_payload.get("parameter_relative_error"))
    residual_metric = eval_payload.get("physics_consistency", eval_payload.get("residual_metric"))
    if inverse_target is None or residual_metric is None:
        return None
    return {
        "field_relative_l2": normalized_metrics["field_relative_l2"],
        "inverse_target_relative_error": float(inverse_target),
        "residual_metric": float(residual_metric),
        "joint_inverse_main_score": (
            float(normalized_metrics["field_relative_l2"])
            + float(inverse_target)
            + float(residual_metric)
        ) / 3.0,
    }


def _fairness_config(method_id: str) -> MethodFairnessConfig:
    if method_id not in METHOD_FAIRNESS_CONFIGS:
        raise KeyError(f"Missing fairness config for {method_id}")
    return METHOD_FAIRNESS_CONFIGS[method_id]


def _comparison_scope_for_method(method_id: str) -> str:
    _fairness_config(method_id)
    return ALLOWED_COMPARISON_SCOPE


def _inverse_shell_binding(method_id: str) -> str:
    return INVERSE_SHELL_BINDINGS.get(method_id, "")


def _participant_record(method_id: str) -> dict[str, Any]:
    contracts = _load_contract_rows()
    evidence = _load_evidence_rows()
    gaps = _load_gap_rows()
    primary = _primary_records()[method_id]
    fairness = _fairness_config(method_id)
    contract_row = contracts[method_id]
    evidence_row = evidence[method_id]
    gap_row = gaps[method_id]
    artifact_path = _select_artifact_path(method_id, _scan_metrics_by_model())
    metrics_payload, normalized_metrics = _load_metrics_bundle(artifact_path)
    eval_payload = metrics_payload.get("eval", {})
    inverse_joint_metrics = _inverse_joint_metric_bundle(eval_payload, normalized_metrics)
    selection_metrics = _selection_metric_bundle(method_id)
    if selection_metrics is not None:
        inverse_joint_metrics = selection_metrics
    task_name = str(metrics_payload.get("metadata", {}).get("task_name") or "")
    inverse_shell_binding = _inverse_shell_binding(method_id)
    dual_metric_ready = inverse_joint_metrics is not None
    if not inverse_shell_binding:
        missing_inverse_metrics_reason = "no_inverse_shell_binding_defined"
    elif inverse_joint_metrics is None:
        missing_inverse_metrics_reason = "selected_artifact_missing_inverse_target_or_residual_metrics"
    else:
        missing_inverse_metrics_reason = ""

    fidelity_gap = str(gap_row["contract_gaps"])
    canonical_surfaces = [MAIN_SURFACE_ID, *fairness.secondary_surfaces]
    participant_mode = "standardized_global_prediction_participant"
    if fairness.standardization_strategy == "decomposition_to_global_score_reduction":
        participant_mode = "decomposition_global_output_participant"
    elif fairness.standardization_strategy == "inverse_to_field_mapping":
        participant_mode = "inverse_conditioned_field_participant"
    elif fairness.standardization_strategy == "geometry_conditioned_field_mapping":
        participant_mode = "geometry_conditioned_field_participant"

    participant_records = [
        {
            "surface_id": MAIN_SURFACE_ID,
            "participation_mode": participant_mode,
            "standardized_input_contract": "canonical_task_bundle_v1",
            "standardized_output_contract": "global_field_on_canonical_eval_mesh_v1",
            "training_budget_contract": TRAINING_BUDGET_CONTRACT_ID,
            "data_budget_contract": DATA_BUDGET_CONTRACT_ID,
            "supervision_budget_contract": SUPERVISION_BUDGET_CONTRACT_ID,
            "fairness_adjustments": list(fairness.fairness_adjustments),
            "evaluation_contract_id": MAIN_EVALUATION_CONTRACT_ID,
            "score_fields": [MAIN_METRIC_NAME, "field_mse"],
            "eligible_for_main_fair_board": True,
            "disqualification_reason": None,
        }
    ]
    inverse_joint_candidate = fairness.standardization_strategy == "inverse_to_field_mapping"
    if inverse_joint_candidate and INVERSE_JOINT_MAIN_SURFACE_ID not in canonical_surfaces:
        canonical_surfaces.append(INVERSE_JOINT_MAIN_SURFACE_ID)
    if inverse_joint_metrics is not None or inverse_joint_candidate:
        participant_records.append(
            {
                "surface_id": INVERSE_JOINT_MAIN_SURFACE_ID,
                "participation_mode": "inverse_joint_recovery_participant",
                "standardized_input_contract": "canonical_task_bundle_v1",
                "standardized_output_contract": "inverse_joint_bundle_v1",
                "training_budget_contract": TRAINING_BUDGET_CONTRACT_ID,
                "data_budget_contract": DATA_BUDGET_CONTRACT_ID,
                "supervision_budget_contract": SUPERVISION_BUDGET_CONTRACT_ID,
                "fairness_adjustments": list(fairness.fairness_adjustments),
                "evaluation_contract_id": INVERSE_JOINT_MAIN_CONTRACT_ID,
                "score_fields": [
                    "field_relative_l2",
                    "inverse_target_relative_error",
                    "residual_metric",
                    INVERSE_JOINT_MAIN_METRIC_NAME,
                ],
                "eligible_for_main_fair_board": False,
                "disqualification_reason": "parallel_inverse_joint_candidate_until_upgraded_artifacts_and_tests_land",
            }
        )

    participant = {
        "canonical_id": method_id,
        "display_name": contract_row["display_name"],
        "aliases": _normalize_mixed_list(contract_row["aliases"]),
        "family": contract_row["family"],
        "primary_source": contract_row["primary_paper_or_source"],
        "runnable_path": primary.default_runtime_name,
        "artifact_paths": [artifact_path],
        "canonical_surfaces": canonical_surfaces,
        "primary_surface": MAIN_SURFACE_ID,
        "participant_records": participant_records,
        "evaluation_contract_ids": [MAIN_EVALUATION_CONTRACT_ID],
        "parallel_main_candidate_surfaces": [] if not inverse_joint_candidate else [INVERSE_JOINT_MAIN_SURFACE_ID],
        "parallel_main_candidate_contract_ids": [] if not inverse_joint_candidate else [INVERSE_JOINT_MAIN_CONTRACT_ID],
        "parallel_main_candidate_score_schemas": [] if not inverse_joint_candidate else [INVERSE_JOINT_SCORE_SCHEMA_ID],
        "parallel_inverse_joint_metric_bundle": inverse_joint_metrics,
        "official_inverse_board_eligible": bool(inverse_shell_binding),
        "inverse_shell_binding": inverse_shell_binding,
        "inverse_metric_transport_mode": "parallel_inverse_joint_metric_bundle" if dual_metric_ready else "field_only_metrics_bundle",
        "missing_inverse_metrics_reason": missing_inverse_metrics_reason,
        "official_dual_metric_status": "ready" if dual_metric_ready else "not_ready",
        "training_budget_contract": TRAINING_BUDGET_CONTRACT_ID,
        "data_budget_contract": DATA_BUDGET_CONTRACT_ID,
        "supervision_budget_contract": SUPERVISION_BUDGET_CONTRACT_ID,
        "fairness_adjustments": list(fairness.fairness_adjustments),
        "special_capabilities_stripped_or_budgeted": list(fairness.special_capabilities),
        "main_fair_board_eligible": True,
        "main_fair_board_score_fields": [MAIN_METRIC_NAME, "field_mse"],
        "standardization_strategy": fairness.standardization_strategy,
        "comparability_is_hard_gated": True,
        "hard_gate_reasoning": (
            f"Allowed onto the main board only through {MAIN_SURFACE_ID} + {MAIN_EVALUATION_CONTRACT_ID}; "
            "validator rejects missing budgets, mismatched output contracts, and unbudgeted advantages."
        ),
        "fidelity_boundary": f"{contract_row['fidelity_tier']}: {fidelity_gap}",
        "source_faithful_claim_allowed": bool(contract_row["source_faithful_claim_allowed"]),
        "evidence_lines": _normalize_mixed_list(contract_row["evidence_lines"]),
        "evidence_strength": contract_row["evidence_strength"],
        "board_status": "main_fair_board_candidate",
        "final_fairness_verdict": fairness.verdict,
        "last_verified_by_tests": list(REQUIRED_TESTS),
        "standardized_input_contract": "canonical_task_bundle_v1",
        "standardized_output_contract": "global_field_on_canonical_eval_mesh_v1",
        "comparison_scope": _comparison_scope_for_method(method_id),
        "main_metric_name": MAIN_METRIC_NAME,
        "main_metric_value": normalized_metrics["field_relative_l2"],
        "auxiliary_scores": {"field_mse": normalized_metrics["field_mse"]},
        "metric_bundle": normalized_metrics,
        "score_aggregation_rule": "main_score equals field_relative_l2; lower is better",
        "matched_budget_group_id": "main_fair_board.global_solution.v1",
        "task_name": task_name,
        "evidence_artifact_path": evidence_row["artifact_path"],
        "fairness_notes": fairness.main_board_notes,
    }
    return participant


def list_participant_normalization_records() -> list[dict[str, Any]]:
    return [_participant_record(record.method_id) for record in list_primary_method_records()]


def _validator_blockers(record: dict[str, Any]) -> list[str]:
    blockers: list[str] = []
    if not record.get("runnable_path"):
        blockers.append("missing_runnable_path")
    if record.get("primary_surface") != MAIN_SURFACE_ID:
        blockers.append("surface_not_main_board_surface")
    if _first_mixed(record.get("evaluation_contract_ids")) != MAIN_EVALUATION_CONTRACT_ID:
        blockers.append("evaluation_contract_mismatch")
    if record.get("standardized_output_contract") != "global_field_on_canonical_eval_mesh_v1":
        blockers.append("output_contract_mismatch")
    if record.get("comparison_scope") != ALLOWED_COMPARISON_SCOPE:
        blockers.append("comparison_scope_not_matched_all")
    if record.get("training_budget_contract") != TRAINING_BUDGET_CONTRACT_ID:
        blockers.append("missing_training_budget_contract")
    if record.get("data_budget_contract") != DATA_BUDGET_CONTRACT_ID:
        blockers.append("missing_data_budget_contract")
    if record.get("supervision_budget_contract") != SUPERVISION_BUDGET_CONTRACT_ID:
        blockers.append("missing_supervision_budget_contract")
    if not record.get("standardization_strategy"):
        blockers.append("missing_standardization_strategy")
    if not record.get("main_fair_board_score_fields"):
        blockers.append("missing_score_fields")
    if not record.get("evidence_lines"):
        blockers.append("missing_evidence_line")
    if not record.get("fidelity_boundary"):
        blockers.append("fairness_fidelity_field_collision")
    artifact_paths = _normalize_mixed_list(record.get("artifact_paths"))
    if not artifact_paths:
        blockers.append("missing_evidence_line")
    for artifact_path in artifact_paths:
        if not (REPO_ROOT / artifact_path / "metrics.json").exists():
            blockers.append("missing_evidence_line")
    adjustments = set(_normalize_mixed_list(record.get("fairness_adjustments")))
    if not adjustments.issubset(ALLOWED_FAIRNESS_ADJUSTMENTS):
        blockers.append("unbudgeted_auxiliary_signal")
    specials = _normalize_mixed_list(record.get("special_capabilities_stripped_or_budgeted"))
    if not specials:
        blockers.append("unbudgeted_auxiliary_signal")
    for special in specials:
        if special.startswith("unbudgeted_"):
            blockers.append("unbudgeted_auxiliary_signal")
    return sorted(dict.fromkeys(blockers))


def build_fair_board_eligibility_registry() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for record in list_participant_normalization_records():
        blockers = _validator_blockers(record)
        rows.append(
            {
                "canonical_id": record["canonical_id"],
                "display_name": record["display_name"],
                "primary_surface": record["primary_surface"],
                "evaluation_contract_id": _first_mixed(record["evaluation_contract_ids"]),
                "standardization_strategy": record["standardization_strategy"],
                "training_budget_contract": record["training_budget_contract"],
                "data_budget_contract": record["data_budget_contract"],
                "supervision_budget_contract": record["supervision_budget_contract"],
                "fairness_adjustments": record["fairness_adjustments"],
                "special_capabilities_stripped_or_budgeted": record["special_capabilities_stripped_or_budgeted"],
                "main_fair_board_eligible": len(blockers) == 0,
                "validator_passed": len(blockers) == 0,
                "disqualification_reason": None if not blockers else "; ".join(blockers),
                "blocker_codes": blockers,
                "final_fairness_verdict": record["final_fairness_verdict"],
                "comparability_is_hard_gated": True,
                "hard_gate_reasoning": record["hard_gate_reasoning"],
                "fidelity_boundary": record["fidelity_boundary"],
                "source_faithful_claim_allowed": record["source_faithful_claim_allowed"],
                "last_verified_by_tests": record["last_verified_by_tests"],
            }
        )
    return rows


def build_surface_alignment_evidence_registry() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for record in list_participant_normalization_records():
        artifact_path = _first_mixed(record["artifact_paths"])
        metrics_payload, normalized_metrics = _load_metrics_bundle(artifact_path)
        rows.append(
            {
                "canonical_id": record["canonical_id"],
                "surface_id": record["primary_surface"],
                "evaluation_contract_id": _first_mixed(record["evaluation_contract_ids"]),
                "artifact_path": artifact_path,
                "metrics_path": f"{artifact_path}/metrics.json",
                "task_name": metrics_payload.get("metadata", {}).get("task_name"),
                "field_relative_l2": normalized_metrics["field_relative_l2"],
                "field_mse": normalized_metrics["field_mse"],
                "evidence_strength": record["evidence_strength"],
                "alignment_status": "aligned_to_main_surface",
                "notes": record["fairness_notes"],
            }
        )
    return rows


def build_main_fair_board() -> list[dict[str, Any]]:
    participants = {row["canonical_id"]: row for row in list_participant_normalization_records()}
    eligibility = {row["canonical_id"]: row for row in build_fair_board_eligibility_registry()}
    rows: list[dict[str, Any]] = []
    for method_id, record in participants.items():
        gate = eligibility[method_id]
        if not gate["validator_passed"]:
            continue
        metric_bundle = record["metric_bundle"]
        rows.append(
            {
                "canonical_id": method_id,
                "display_name": record["display_name"],
                "primary_surface": record["primary_surface"],
                "evaluation_contract_id": _first_mixed(record["evaluation_contract_ids"]),
                "standardization_strategy": record["standardization_strategy"],
                "training_budget_contract": record["training_budget_contract"],
                "data_budget_contract": record["data_budget_contract"],
                "supervision_budget_contract": record["supervision_budget_contract"],
                "fairness_adjustments": record["fairness_adjustments"],
                "main_score": metric_bundle[MAIN_METRIC_NAME],
                "auxiliary_scores": record["auxiliary_scores"],
                "metric_bundle": metric_bundle,
                "score_aggregation_rule": record["score_aggregation_rule"],
                "main_fair_board_eligible": gate["main_fair_board_eligible"],
                "fairness_verdict": gate["final_fairness_verdict"],
                "evidence_strength": record["evidence_strength"],
                "artifact_count": len(_normalize_mixed_list(record["artifact_paths"])),
                "validator_passed": gate["validator_passed"],
                "source_faithful_claim_allowed": record["source_faithful_claim_allowed"],
                "main_metric_name": record["main_metric_name"],
                "main_metric_value": record["main_metric_value"],
                "matched_budget_group_id": record["matched_budget_group_id"],
                "fidelity_tier": _load_contract_rows()[method_id]["fidelity_tier"],
                "fidelity_boundary": record["fidelity_boundary"],
                "comparison_scope": record["comparison_scope"],
            }
        )
    rows.sort(key=lambda item: (float(item["main_score"]), str(item["canonical_id"])))
    for index, row in enumerate(rows, start=1):
        row["rank"] = index
    return rows


def build_method_standardization_strategies() -> list[dict[str, Any]]:
    participants = list_participant_normalization_records()
    rows: list[dict[str, Any]] = []
    for record in participants:
        rows.append(
            {
                "canonical_id": record["canonical_id"],
                "display_name": record["display_name"],
                "standardization_strategy": record["standardization_strategy"],
                "fairness_adjustments": record["fairness_adjustments"],
                "special_capabilities_stripped_or_budgeted": record["special_capabilities_stripped_or_budgeted"],
                "comparability_is_hard_gated": record["comparability_is_hard_gated"],
                "hard_gate_reasoning": record["hard_gate_reasoning"],
                "final_fairness_verdict": record["final_fairness_verdict"],
                "fidelity_boundary": record["fidelity_boundary"],
                "source_faithful_claim_allowed": record["source_faithful_claim_allowed"],
            }
        )
    return rows


def build_fairness_audit_log() -> list[dict[str, Any]]:
    contracts = _load_contract_rows()
    rows: list[dict[str, Any]] = []
    for record in list_participant_normalization_records():
        method_id = record["canonical_id"]
        contract_row = contracts[method_id]
        rows.append(
            {
                "canonical_id": method_id,
                "display_name": record["display_name"],
                "legacy_benchmark_surface": _first_mixed(contract_row["benchmark_surface"]),
                "legacy_comparability_scope": _first_mixed(contract_row["comparability_scope"]),
                "new_primary_surface": record["primary_surface"],
                "standardization_strategy": record["standardization_strategy"],
                "fairness_adjustments": record["fairness_adjustments"],
                "special_capabilities_stripped_or_budgeted": record["special_capabilities_stripped_or_budgeted"],
                "no_unbudgeted_advantages": len(_validator_blockers(record)) == 0,
                "main_fair_board_eligible": True,
                "audit_verdict": record["final_fairness_verdict"],
                "notes": record["fairness_notes"],
            }
        )
    return rows


def get_fair_board_method_entry(method_id: str) -> dict[str, Any]:
    participant_rows = {row["canonical_id"]: row for row in list_participant_normalization_records()}
    eligibility_rows = {row["canonical_id"]: row for row in build_fair_board_eligibility_registry()}
    board_rows = {row["canonical_id"]: row for row in build_main_fair_board()}
    participant = participant_rows[method_id]
    eligibility = eligibility_rows[method_id]
    board_entry = board_rows.get(method_id)
    return {
        "canonical_surfaces": participant["canonical_surfaces"],
        "primary_surface": participant["primary_surface"],
        "evaluation_contract_ids": participant["evaluation_contract_ids"],
        "training_budget_contract": participant["training_budget_contract"],
        "data_budget_contract": participant["data_budget_contract"],
        "supervision_budget_contract": participant["supervision_budget_contract"],
        "standardization_strategy": participant["standardization_strategy"],
        "fairness_adjustments": participant["fairness_adjustments"],
        "special_capabilities_stripped_or_budgeted": participant["special_capabilities_stripped_or_budgeted"],
        "main_fair_board_eligible": eligibility["main_fair_board_eligible"],
        "comparability_is_hard_gated": participant["comparability_is_hard_gated"],
        "hard_gate_reasoning": participant["hard_gate_reasoning"],
        "final_fairness_verdict": eligibility["final_fairness_verdict"],
        "validator_passed": eligibility["validator_passed"],
        "main_fair_board_score_fields": participant["main_fair_board_score_fields"],
        "board_rank": None if board_entry is None else board_entry["rank"],
    }


def _serialize_cell(value: Any) -> str:
    if isinstance(value, bool):
        return "True" if value else "False"
    if value is None:
        return ""
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, list):
        if value and all(isinstance(item, str) for item in value):
            return " | ".join(value)
        return json.dumps(value, ensure_ascii=True, sort_keys=True)
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=True, sort_keys=True)
    return str(value)


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"No rows to write for {path}")
    fieldnames = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _serialize_cell(value) for key, value in row.items()})


def _write_json(path: Path, schema_version: str, rows: list[dict[str, Any]]) -> None:
    path.write_text(json.dumps({"schema_version": schema_version, "rows": rows}, indent=2), encoding="utf-8")


def _write_markdown_board(path: Path, rows: list[dict[str, Any]]) -> None:
    lines = [
        "# Main Fair Board",
        "",
        "| Rank | Method | Surface | Main Score | Strategy | Fairness Verdict |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    for row in rows:
        lines.append(
            f"| {row['rank']} | `{row['canonical_id']}` | `{row['primary_surface']}` | "
            f"{row['main_score']:.6f} | `{row['standardization_strategy']}` | `{row['fairness_verdict']}` |"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _build_score_schema() -> dict[str, Any]:
    return {
        "score_schema_id": SCORE_SCHEMA_ID,
        "surface_id": MAIN_SURFACE_ID,
        "main_metric_name": MAIN_METRIC_NAME,
        "main_score_field": "main_score",
        "auxiliary_score_fields": ["field_mse"],
        "ranking_order": "lower_is_better",
        "score_aggregation_rule": "main_score equals field_relative_l2; field_mse is auxiliary and does not change ordering",
        "metric_bundle": ["field_relative_l2", "field_mse"],
        "fairness_note": "All entries share the same standardized participant contract; extra capabilities are budgeted or stripped before scoring.",
    }


def _write_score_schema_markdown(path: Path, payload: dict[str, Any]) -> None:
    lines = [
        "# Fair Board Score Schema",
        "",
        f"- `score_schema_id`: `{payload['score_schema_id']}`",
        f"- `surface_id`: `{payload['surface_id']}`",
        f"- `main_metric_name`: `{payload['main_metric_name']}`",
        f"- `main_score_field`: `{payload['main_score_field']}`",
        f"- `auxiliary_score_fields`: `{' | '.join(payload['auxiliary_score_fields'])}`",
        f"- `ranking_order`: `{payload['ranking_order']}`",
        f"- `score_aggregation_rule`: `{payload['score_aggregation_rule']}`",
        f"- `fairness_note`: {payload['fairness_note']}",
        "",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")


def _write_paper_docs(
    board_rows: list[dict[str, Any]],
    participant_rows: list[dict[str, Any]],
    surface_rows: list[dict[str, Any]],
    contract_rows: list[dict[str, Any]],
    summary: dict[str, Any],
) -> None:
    fair_report = [
        "# Fair Board Report",
        "",
        "## Executive conclusion",
        "",
        f"- all methods fair-board-eligible: **{summary['eligible_total']}/{summary['methods_total']}**",
        f"- main fair board entries: **{summary['main_board_total']}**",
        f"- canonical comparison surfaces tracked in registry: **{summary['surface_count']}**",
        f"- frozen submission-facing main-board surface id: **`{MAIN_SURFACE_ID}`**",
        f"- parallel compatibility surface ids: **`{'`, `'.join(summary['parallel_main_candidate_surface_ids'])}`**",
        f"- supplementary surface ids: **`{'`, `'.join(summary['supplementary_surface_ids'])}`**",
        "",
        "All twenty methods still enter one hard-gated legacy main fair board through standardized participant records, shared budget contracts, and one shared evaluation contract.",
        "In parallel, the registry now also exposes an inverse-joint compatibility surface so inverse-centric methods are no longer described as supplementary-only everywhere while upgraded artifacts and tests are still landing.",
        "",
        "## Fairness boundary",
        "",
        "Main-board eligibility means the method has been standardized to the shared participant protocol. It does not imply source-faithful reproduction.",
        "",
    ]
    (PAPER_ROOT / "fair_board_report.md").write_text("\n".join(fair_report), encoding="utf-8")

    author_summary = [
        "# Fair Board Author Summary",
        "",
        f"- all fair-board-eligible: **{summary['eligible_total']}/{summary['methods_total']}**",
        f"- all methods on `main_fair_board`: **{summary['main_board_total']}/{summary['methods_total']}**",
        f"- canonical comparison surfaces tracked: **{summary['surface_count']}**",
        f"- frozen main surface: `{MAIN_SURFACE_ID}`",
        f"- parallel compatibility surface: `{' | '.join(summary['parallel_main_candidate_surface_ids'])}`",
        "- comparability is now a hard validator gate rather than a prose label",
        "- fairness and fidelity are reported separately",
        "- inverse-joint compatibility objects are registry-visible without replacing the frozen submission board",
    ]
    (PAPER_ROOT / "fair_board_author_summary.md").write_text("\n".join(author_summary) + "\n", encoding="utf-8")

    protocol_lines = [
        "# Fair Comparison Protocol",
        "",
        "## Purpose",
        "Define the hard-gated fair comparison protocol that feeds `main_fair_board`, plus any explicitly disclosed parallel compatibility contracts.",
        "",
    ]
    for row in contract_rows:
        protocol_lines.append(f"### `{row['evaluation_contract_id']}`")
        protocol_lines.append(f"- `surface_id`: `{row['surface_id']}`")
        protocol_lines.append(f"- `problem_object`: {row['problem_object']}")
        protocol_lines.append(f"- `main_metric`: `{row['main_metric']}`")
        protocol_lines.append(f"- `score_aggregation_rule`: {row['score_aggregation_rule']}")
        protocol_lines.append(f"- `eligible_for_main_fair_board`: `{row['eligible_for_main_fair_board']}`")
        protocol_lines.append("")
    (PAPER_ROOT / "fair_comparison_protocol.md").write_text("\n".join(protocol_lines), encoding="utf-8")

    surface_lines = [
        "# Canonical Surfaces And Contracts",
        "",
        "## Purpose",
        "Record the canonical comparison surfaces and their bound evaluation contracts.",
        "",
    ]
    for row in surface_rows:
        surface_lines.append(f"### `{row['surface_id']}`")
        surface_lines.append(f"- `surface_role`: `{row['surface_role']}`")
        surface_lines.append(f"- `problem_object`: {row['problem_object']}")
        surface_lines.append(f"- `evaluation_contract_id`: `{row['evaluation_contract_id']}`")
        surface_lines.append(f"- `eligible_for_main_fair_board`: `{row['eligible_for_main_fair_board']}`")
        surface_lines.append(f"- `allowed_methods`: `{' | '.join(_normalize_mixed_list(row['allowed_methods']))}`")
        surface_lines.append("")
    (PAPER_ROOT / "canonical_surfaces_and_contracts.md").write_text("\n".join(surface_lines), encoding="utf-8")

    appendix_lines = [
        "# Method Standardization Appendix",
        "",
        "## Purpose",
        "Disclose how each method was standardized into the shared fair-board protocol.",
        "",
    ]
    for row in participant_rows:
        appendix_lines.append(f"### `{row['canonical_id']}`")
        appendix_lines.append(f"- `standardization_strategy`: `{row['standardization_strategy']}`")
        appendix_lines.append(f"- `fairness_adjustments`: `{' | '.join(_normalize_mixed_list(row['fairness_adjustments']))}`")
        appendix_lines.append(
            f"- `special_capabilities_stripped_or_budgeted`: "
            f"`{' | '.join(_normalize_mixed_list(row['special_capabilities_stripped_or_budgeted']))}`"
        )
        appendix_lines.append(f"- `final_fairness_verdict`: `{row['final_fairness_verdict']}`")
        appendix_lines.append(f"- `fidelity_boundary`: {row['fidelity_boundary']}")
        appendix_lines.append("")
    (PAPER_ROOT / "method_standardization_appendix.md").write_text("\n".join(appendix_lines), encoding="utf-8")

    boundary_lines = [
        "# Fairness Boundary Language",
        "",
        "## Purpose",
        "Keep fairness eligibility and fidelity claims separate.",
        "",
        "- `fair_board_eligible` means the method passed the shared surface, contract, budget, and validator gates.",
        "- `source_faithful_claim_allowed` remains a separate claim-boundary field and does not control board admission by itself.",
        "- restricted mappings and budget equalizations must be disclosed in the participant registry and fairness audit log.",
    ]
    (PAPER_ROOT / "fairness_boundary_language.md").write_text("\n".join(boundary_lines) + "\n", encoding="utf-8")

    methods_lines = [
        "# Main Fair Board Methods Appendix",
        "",
        "## Purpose",
        "List every method that entered the single main fair board.",
        "",
    ]
    for row in board_rows:
        methods_lines.append(f"### Rank {row['rank']}: `{row['canonical_id']}`")
        methods_lines.append(f"- `main_score`: `{row['main_score']}`")
        methods_lines.append(f"- `standardization_strategy`: `{row['standardization_strategy']}`")
        methods_lines.append(f"- `fidelity_boundary`: {row['fidelity_boundary']}")
        methods_lines.append(f"- `fairness_verdict`: `{row['fairness_verdict']}`")
        methods_lines.append("")
    (PAPER_ROOT / "main_fair_board_methods_appendix.md").write_text("\n".join(methods_lines), encoding="utf-8")


def _build_summary(
    board_rows: list[dict[str, Any]],
    participant_rows: list[dict[str, Any]],
    surface_rows: list[dict[str, Any]],
) -> dict[str, Any]:
    strategies: dict[str, int] = {}
    verdicts: dict[str, int] = {}
    primary_surface_counts: dict[str, int] = {}
    restricted_methods: list[str] = []
    budget_equalized_methods: list[str] = []
    parallel_surface_counts: dict[str, int] = {}
    for row in participant_rows:
        strategies[row["standardization_strategy"]] = strategies.get(row["standardization_strategy"], 0) + 1
        verdicts[row["final_fairness_verdict"]] = verdicts.get(row["final_fairness_verdict"], 0) + 1
        primary_surface_counts[row["primary_surface"]] = primary_surface_counts.get(row["primary_surface"], 0) + 1
        for surface_id in row.get("parallel_main_candidate_surfaces", []):
            parallel_surface_counts[str(surface_id)] = parallel_surface_counts.get(str(surface_id), 0) + 1
        if row["final_fairness_verdict"] == "fair_board_eligible_with_restricted_mapping":
            restricted_methods.append(row["canonical_id"])
        if row["final_fairness_verdict"] == "fair_board_eligible_with_budget_equalization":
            budget_equalized_methods.append(row["canonical_id"])
    return {
        "methods_total": len(participant_rows),
        "eligible_total": len([row for row in participant_rows if row["main_fair_board_eligible"]]),
        "main_board_total": len(board_rows),
        "surface_count": len(surface_rows),
        "main_surface_id": MAIN_SURFACE_ID,
        "parallel_main_candidate_surface_ids": [INVERSE_JOINT_MAIN_SURFACE_ID],
        "supplementary_surface_ids": [INVERSE_AUX_SURFACE_ID, TRANSFER_AUX_SURFACE_ID],
        "parallel_surface_counts": parallel_surface_counts,
        "standardization_strategy_counts": strategies,
        "fairness_verdict_counts": verdicts,
        "primary_surface_counts": primary_surface_counts,
        "restricted_mapping_methods": restricted_methods,
        "budget_equalized_methods": budget_equalized_methods,
        "single_main_board": True,
        "comparability_is_hard_gated": True,
    }


def write_fair_board_artifacts(repo_root: Path | None = None) -> dict[str, Any]:
    del repo_root  # the module is repo-root anchored by design.
    ARTIFACT_ROOT.mkdir(parents=True, exist_ok=True)
    PAPER_ROOT.mkdir(parents=True, exist_ok=True)

    participant_rows = list_participant_normalization_records()
    eligibility_rows = build_fair_board_eligibility_registry()
    board_rows = build_main_fair_board()
    surface_rows = [row.to_dict() for row in _surface_records([row["canonical_id"] for row in participant_rows])]
    contract_rows = [row.to_dict() for row in _evaluation_contracts()]
    strategy_rows = build_method_standardization_strategies()
    audit_rows = build_fairness_audit_log()
    alignment_rows = build_surface_alignment_evidence_registry()
    score_schema = _build_score_schema()
    summary = _build_summary(board_rows, participant_rows, surface_rows)

    _write_csv(ARTIFACT_ROOT / "canonical_surface_registry.csv", surface_rows)
    _write_json(ARTIFACT_ROOT / "canonical_surface_registry.json", "canonical_surface_registry.v1", surface_rows)

    _write_csv(ARTIFACT_ROOT / "evaluation_contract_registry.csv", contract_rows)
    _write_json(ARTIFACT_ROOT / "evaluation_contract_registry.json", "evaluation_contract_registry.v1", contract_rows)

    _write_csv(ARTIFACT_ROOT / "participant_normalization_registry.csv", participant_rows)
    _write_json(ARTIFACT_ROOT / "participant_normalization_registry.json", "participant_normalization_registry.v1", participant_rows)

    _write_csv(ARTIFACT_ROOT / "fair_board_eligibility_registry.csv", eligibility_rows)
    _write_json(ARTIFACT_ROOT / "fair_board_eligibility_registry.json", "fair_board_eligibility_registry.v1", eligibility_rows)

    _write_csv(ARTIFACT_ROOT / "main_fair_board.csv", board_rows)
    _write_json(ARTIFACT_ROOT / "main_fair_board.json", "main_fair_board.v1", board_rows)
    _write_markdown_board(ARTIFACT_ROOT / "main_fair_board.md", board_rows)

    _write_csv(ARTIFACT_ROOT / "fairness_audit_log.csv", audit_rows)
    _write_json(ARTIFACT_ROOT / "fairness_audit_log.json", "fairness_audit_log.v1", audit_rows)

    _write_csv(ARTIFACT_ROOT / "method_standardization_strategies.csv", strategy_rows)
    _write_json(ARTIFACT_ROOT / "method_standardization_strategies.json", "method_standardization_strategies.v1", strategy_rows)

    snapshot_payload = {
        "schema_version": "all_method_fair_board_snapshot.v1",
        "artifacts": [
            "canonical_surface_registry.json",
            "evaluation_contract_registry.json",
            "participant_normalization_registry.json",
            "fair_board_eligibility_registry.json",
            "main_fair_board.json",
            "fairness_audit_log.json",
            "method_standardization_strategies.json",
            "surface_alignment_evidence_registry.json",
        ],
        "rows": participant_rows,
    }
    (ARTIFACT_ROOT / "all_method_fair_board_snapshot.json").write_text(json.dumps(snapshot_payload, indent=2), encoding="utf-8")
    (ARTIFACT_ROOT / "all_method_fair_board_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    (ARTIFACT_ROOT / "fair_board_score_schema.json").write_text(json.dumps(score_schema, indent=2), encoding="utf-8")
    _write_score_schema_markdown(ARTIFACT_ROOT / "fair_board_score_schema.md", score_schema)

    _write_csv(ARTIFACT_ROOT / "surface_alignment_evidence_registry.csv", alignment_rows)
    _write_json(ARTIFACT_ROOT / "surface_alignment_evidence_registry.json", "surface_alignment_evidence_registry.v1", alignment_rows)

    _write_paper_docs(board_rows, participant_rows, surface_rows, contract_rows, summary)
    return {
        "participant_rows": participant_rows,
        "eligibility_rows": eligibility_rows,
        "board_rows": board_rows,
        "surface_rows": surface_rows,
        "contract_rows": contract_rows,
        "summary": summary,
    }


__all__ = [
    "ALLOWED_COMPARISON_SCOPE",
    "DATA_BUDGET_CONTRACT_ID",
    "MAIN_EVALUATION_CONTRACT_ID",
    "MAIN_SURFACE_ID",
    "SCORE_SCHEMA_ID",
    "SUPERVISION_BUDGET_CONTRACT_ID",
    "TRAINING_BUDGET_CONTRACT_ID",
    "build_fair_board_eligibility_registry",
    "build_main_fair_board",
    "build_surface_alignment_evidence_registry",
    "get_fair_board_method_entry",
    "list_participant_normalization_records",
    "write_fair_board_artifacts",
]
