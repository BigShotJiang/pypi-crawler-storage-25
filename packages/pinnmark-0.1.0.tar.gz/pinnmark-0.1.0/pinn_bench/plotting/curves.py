"""Curve plotting utilities."""

from __future__ import annotations

import csv
from collections.abc import Sequence
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from figure_r.python.rendering import render_template_or_fallback


def _python_plot_loss_curve(history: Sequence[dict[str, float]], output_path: Path) -> list[str]:
    if not history:
        return []

    epochs = [row["epoch"] for row in history]
    losses = [row["loss"] for row in history]

    figure = plt.figure(figsize=(6, 4))
    axis = figure.add_subplot(1, 1, 1)
    axis.plot(epochs, losses, label="train_loss")
    axis.set_xlabel("Epoch")
    axis.set_ylabel("Loss")
    axis.set_title("Training Loss Curve")
    axis.grid(True, alpha=0.3)
    axis.legend()
    figure.tight_layout()
    figure.savefig(output_path)
    plt.close(figure)
    return [str(output_path.resolve())]


def plot_loss_curve(history: Sequence[dict[str, float]], output_path: Path) -> None:
    """Plot and save training loss curve."""
    if not history:
        return

    output_path = Path(output_path)

    def _prepare_spec(input_dir: Path, output_paths: list[Path]) -> dict[str, object]:
        history_path = input_dir / "history.csv"
        with history_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=["epoch", "loss"])
            writer.writeheader()
            for row in history:
                writer.writerow({"epoch": row["epoch"], "loss": row["loss"]})
        return {
            "mode": "loss_curve",
            "kind": "single_panel",
            "title": "Training Loss Curve",
            "subtitle": "R-backed runtime training-dynamics renderer",
            "x_label": "Epoch",
            "y_label": "Loss",
            "width": 6.0,
            "height": 4.0,
            "files": {"history": "history.csv"},
        }

    render_template_or_fallback(
        template_name="training_dynamics.R",
        output_paths=[output_path],
        prepare_spec=_prepare_spec,
        python_fallback=lambda: _python_plot_loss_curve(history, output_path),
        description=f"runtime loss curve at {output_path}",
    )
