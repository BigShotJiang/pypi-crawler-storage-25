"""Shared resource resolution helpers for product-layer CLI flows."""

from __future__ import annotations

from pathlib import Path

_CONFIG_DIR = Path("configs") / "experiment"
_MANIFEST_DIR = Path("configs") / "matrix"
_REQUIRED_REPO_MARKERS = ("pinn_bench", "configs", "docs")


def _candidate_roots(start: Path | None = None) -> list[Path]:
    seen: set[Path] = set()
    candidates: list[Path] = []

    def add_path(path: Path | None) -> None:
        if path is None:
            return
        resolved = path.resolve()
        base = resolved if resolved.is_dir() else resolved.parent
        for candidate in [base, *base.parents]:
            if candidate in seen:
                continue
            seen.add(candidate)
            candidates.append(candidate)

    add_path(start)
    add_path(Path.cwd())
    add_path(Path(__file__).resolve())
    return candidates


def _is_repo_root(path: Path) -> bool:
    return all((path / marker).exists() for marker in _REQUIRED_REPO_MARKERS)


def resolve_repo_root(start: Path | None = None) -> Path:
    for candidate in _candidate_roots(start=start):
        if _is_repo_root(candidate):
            return candidate.resolve()
    raise FileNotFoundError(
        "Could not locate the pinn_bench repo root. Run inside a source checkout/editable install or pass an explicit path."
    )


def _normalize_suffix(path: Path) -> Path:
    if path.suffix:
        return path
    return path.with_suffix(".yaml")


def _fallback_builtin_candidate(raw_path: Path, builtin_root: Path, repo_root: Path) -> Path | None:
    raw_parts = list(raw_path.parts)
    builtin_parts = list(builtin_root.relative_to(repo_root).parts)
    for idx in range(len(raw_parts)):
        if raw_parts[idx : idx + len(builtin_parts)] == builtin_parts:
            candidate = repo_root.joinpath(*raw_parts[idx:])
            if candidate.exists():
                return candidate.resolve()
    basename_candidate = (builtin_root / _normalize_suffix(Path(raw_path.name))).resolve()
    if basename_candidate.exists():
        return basename_candidate
    return None


def resolve_builtin_resource(name: str | Path, *, resource_type: str) -> Path:
    raw_path = Path(str(name)).expanduser()
    repo_root = resolve_repo_root()
    builtin_root = {
        "config": repo_root / _CONFIG_DIR,
        "manifest": repo_root / _MANIFEST_DIR,
    }.get(resource_type)
    if builtin_root is None:
        raise ValueError(f"Unsupported resource_type '{resource_type}'.")

    attempted: list[Path] = []
    if raw_path.is_absolute():
        attempted.append(raw_path)
        if raw_path.exists():
            return raw_path.resolve()
        fallback = _fallback_builtin_candidate(raw_path, builtin_root, repo_root)
        if fallback is not None:
            attempted.append(fallback)
            return fallback
        raise FileNotFoundError(f"Resolved absolute {resource_type} path does not exist: {raw_path}")

    cwd_candidate = (Path.cwd() / raw_path).resolve()
    attempted.append(cwd_candidate)
    if cwd_candidate.exists():
        return cwd_candidate

    repo_candidate = (repo_root / raw_path).resolve()
    attempted.append(repo_candidate)
    if repo_candidate.exists():
        return repo_candidate

    if len(raw_path.parts) == 1:
        builtin_candidate = (builtin_root / _normalize_suffix(raw_path)).resolve()
        attempted.append(builtin_candidate)
        if builtin_candidate.exists():
            return builtin_candidate

    attempts = ", ".join(str(path) for path in attempted)
    raise FileNotFoundError(f"Could not resolve {resource_type} resource '{name}'. Tried: {attempts}")


def resolve_config_path(path: str | Path) -> Path:
    return resolve_builtin_resource(path, resource_type="config")


def resolve_manifest_path(path: str | Path) -> Path:
    return resolve_builtin_resource(path, resource_type="manifest")


def resolve_outputs_root(path: str | Path) -> Path:
    return Path(str(path)).expanduser().resolve()


__all__ = [
    "resolve_repo_root",
    "resolve_config_path",
    "resolve_manifest_path",
    "resolve_builtin_resource",
    "resolve_outputs_root",
]
