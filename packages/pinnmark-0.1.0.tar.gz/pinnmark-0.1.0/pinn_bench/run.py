"""Main runtime entrypoint for pinn_bench."""

from __future__ import annotations

from collections.abc import Sequence
import sys

import pinn_bench.metrics  # noqa: F401
import pinn_bench.models  # noqa: F401
import pinn_bench.tasks  # noqa: F401
from pinn_bench.cli import parse_args
from pinn_bench.config.loader import load_config
from pinn_bench.runners.experiment import run_experiment

KNOWN_SUBCOMMANDS = {
    "run",
    "matrix",
    "leaderboard",
    "report",
    "pareto",
    "analysis",
    "formalize",
    "snapshot",
    "preset",
    "demo",
    "scaffold",
    "doctor",
    "audit",
    "version",
    "summary",
    "list",
    "quickstart",
    "inspect",
    "starter",
    "compare",
    "suite",
    "package-run",
    "validate-submission",
    "compare-bundle",
    "import-bundle",
    "leaderboard-protocol",
    "superbench-registry",
    "superbench-rerun-entry",
    "superbench-run-tranche",
    "help",
    "-h",
    "--help",
}
LEGACY_RUN_FLAGS = {"--config", "--device", "--seed", "--output-dir", "--log-backend"}



def run_experiment_cli(argv: Sequence[str] | None = None) -> None:
    args = parse_args(argv)
    overrides = {
        "seed": args.seed,
        "device": args.device,
        "output_dir": args.output_dir,
    }
    try:
        config = load_config(args.config, overrides=overrides)
        if args.log_backend is not None:
            config.logging.backend = str(args.log_backend)
        run_experiment(config)
    except (FileNotFoundError, KeyError, ValueError) as error:
        raise SystemExit(str(error))



def _should_dispatch_to_app(argv: Sequence[str]) -> bool:
    if not argv:
        return True
    first = str(argv[0])
    if first in KNOWN_SUBCOMMANDS:
        return True
    if any(flag in argv for flag in LEGACY_RUN_FLAGS):
        return False
    return False



def main(argv: Sequence[str] | None = None) -> None:
    resolved_argv = list(sys.argv[1:] if argv is None else argv)
    if _should_dispatch_to_app(resolved_argv):
        from pinn_bench.app import main as app_main

        app_main(resolved_argv)
        return
    run_experiment_cli(resolved_argv)


if __name__ == "__main__":
    main()
