"""Observation/target taxonomy helpers for the v1.4-preview abstraction line."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml

import pinn_bench.tasks  # noqa: F401
from pinn_bench.interfaces.observation_types import (
    ObservationDescriptor,
    ObservationType,
    TargetDescriptor,
    TargetType,
    TaskObservationTargetAssignment,
)
from pinn_bench.registry import _TASK_REGISTRY
from pinn_bench.resources import resolve_repo_root


def _taxonomy_path() -> Path:
    return resolve_repo_root() / 'configs' / 'observation_types' / 'observation_target_taxonomy.yaml'


@lru_cache(maxsize=1)
def _taxonomy_payload() -> dict[str, Any]:
    payload = yaml.safe_load(_taxonomy_path().read_text(encoding='utf-8'))
    if not isinstance(payload, dict):
        raise ValueError('Observation/target taxonomy must decode to a mapping.')
    return dict(payload)


@lru_cache(maxsize=1)
def _observation_descriptors() -> dict[str, ObservationDescriptor]:
    items = _taxonomy_payload().get('observation_classes', [])
    if not isinstance(items, list):
        raise ValueError('observation_classes must be a list.')
    descriptors: dict[str, ObservationDescriptor] = {}
    for item in items:
        if not isinstance(item, dict):
            continue
        observation_name = str(item.get('name') or '').strip()
        if not observation_name:
            continue
        observation_type = ObservationType(observation_name)
        descriptors[observation_name] = ObservationDescriptor(
            observation_type=observation_type,
            summary=str(item.get('summary') or '').strip(),
            future_facing=bool(item.get('future_facing')),
        )
    return descriptors


@lru_cache(maxsize=1)
def _target_descriptors() -> dict[str, TargetDescriptor]:
    items = _taxonomy_payload().get('target_classes', [])
    if not isinstance(items, list):
        raise ValueError('target_classes must be a list.')
    descriptors: dict[str, TargetDescriptor] = {}
    for item in items:
        if not isinstance(item, dict):
            continue
        target_name = str(item.get('name') or '').strip()
        if not target_name:
            continue
        target_type = TargetType(target_name)
        descriptors[target_name] = TargetDescriptor(
            target_type=target_type,
            summary=str(item.get('summary') or '').strip(),
            future_facing=bool(item.get('future_facing')),
        )
    return descriptors


@lru_cache(maxsize=1)
def _allowed_pairings() -> dict[str, set[tuple[str, str]]]:
    payload = _taxonomy_payload().get('allowed_pairings', {})
    if not isinstance(payload, dict):
        raise ValueError('allowed_pairings must be a mapping.')
    pairings: dict[str, set[tuple[str, str]]] = {'current': set(), 'future': set()}
    for stage in ('current', 'future'):
        values = payload.get(stage, [])
        if not isinstance(values, list):
            raise ValueError(f'allowed_pairings.{stage} must be a list.')
        pairings[stage] = {
            (str(item.get('observation_type') or '').strip(), str(item.get('target_type') or '').strip())
            for item in values
            if isinstance(item, dict)
        }
    return pairings


@lru_cache(maxsize=1)
def _task_assignments() -> dict[str, TaskObservationTargetAssignment]:
    mapping = _taxonomy_payload().get('current_task_mapping', {})
    if not isinstance(mapping, dict):
        raise ValueError('current_task_mapping must be a mapping.')
    assignments: dict[str, TaskObservationTargetAssignment] = {}
    for raw_name, payload in mapping.items():
        if not isinstance(payload, dict):
            continue
        task_name = str(raw_name).strip().lower()
        observation_type = ObservationType(str(payload.get('observation_type') or '').strip())
        target_type = TargetType(str(payload.get('target_type') or '').strip())
        task_factory = _TASK_REGISTRY.get(task_name)
        if task_factory is None:
            raise KeyError(f"Task '{task_name}' is not registered.")
        task_mode = str(getattr(task_factory, 'task_mode', 'pointwise')).strip().lower()
        supports_operator = bool(getattr(task_factory, 'supports_operator', False))
        if observation_type is ObservationType.OPERATOR_CONDITION_OBSERVATION and not supports_operator:
            raise ValueError(f"Task '{task_name}' is mapped as operator_condition_observation but does not declare supports_operator.")
        if observation_type is ObservationType.POINT_OBSERVATION and task_mode == 'field':
            raise ValueError(f"Task '{task_name}' is mapped as point_observation but reports task_mode='field'.")
        assignments[task_name] = TaskObservationTargetAssignment(
            task_name=task_name,
            observation_type=observation_type,
            target_type=target_type,
            task_mode=task_mode,
            supports_operator=supports_operator,
        )
    return assignments


def list_observation_types() -> list[str]:
    return list(_observation_descriptors().keys())


def list_target_types() -> list[str]:
    return list(_target_descriptors().keys())


def get_observation_descriptor(observation_type: str | ObservationType) -> ObservationDescriptor:
    key = observation_type.value if isinstance(observation_type, ObservationType) else str(observation_type).strip()
    descriptors = _observation_descriptors()
    if key not in descriptors:
        available = ', '.join(descriptors)
        raise KeyError(f"Unknown observation type '{observation_type}'. Available: {available}")
    return descriptors[key]


def get_target_descriptor(target_type: str | TargetType) -> TargetDescriptor:
    key = target_type.value if isinstance(target_type, TargetType) else str(target_type).strip()
    descriptors = _target_descriptors()
    if key not in descriptors:
        available = ', '.join(descriptors)
        raise KeyError(f"Unknown target type '{target_type}'. Available: {available}")
    return descriptors[key]


def lookup_task_observation_target(task_name: str) -> TaskObservationTargetAssignment:
    key = str(task_name).strip().lower()
    assignments = _task_assignments()
    if key not in assignments:
        available = ', '.join(sorted(assignments))
        raise KeyError(f"Unknown task observation/target mapping '{task_name}'. Available: {available}")
    return assignments[key]


def is_allowed_observation_target_pairing(
    observation_type: str | ObservationType,
    target_type: str | TargetType,
    *,
    include_future: bool = True,
) -> bool:
    observation = observation_type.value if isinstance(observation_type, ObservationType) else str(observation_type).strip()
    target = target_type.value if isinstance(target_type, TargetType) else str(target_type).strip()
    pair = (observation, target)
    pairings = _allowed_pairings()
    if pair in pairings['current']:
        return True
    if include_future and pair in pairings['future']:
        return True
    return False
