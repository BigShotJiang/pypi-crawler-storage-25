"""Stress metadata helpers for the v1.1-preview severity-standardization line."""

from __future__ import annotations

from collections import Counter
from collections.abc import Mapping, Sequence
from typing import Any


NOISE_FAMILY = "noise_gaussian"
SPARSITY_FAMILY = "data_sparsity"
TEMPORAL_HOLDOUT_FAMILY = "temporal_holdout"
SUPPORT_EXTRAPOLATION_FAMILY = "support_extrapolation"
BCIC_CORRUPTION_FAMILY = "bcic_corruption"

STABLE_THRESHOLD = 1.25
FRAGILE_THRESHOLD = 2.0

_NOISE_LEVEL_TO_SEVERITY = {
    0.01: "s1",
    0.05: "s2",
    0.10: "s3",
}

_SPARSITY_LEVEL_TO_SEVERITY = {
    0.50: "s1",
    0.25: "s2",
    0.10: "s3",
}

_BCIC_LEVEL_TO_SEVERITY = {
    0.02: "mild",
    0.05: "medium",
    0.10: "severe",
}

_SUPPORT_RATIO_TO_SEVERITY = {
    0.80: "mild",
    0.60: "medium",
    0.40: "severe",
}

_TEMPORAL_WINDOWS_TO_SEVERITY = {
    (0.0, 0.75, 0.75, 1.0): "s1",
    (0.0, 0.50, 0.50, 1.0): "s2",
    (0.0, 0.25, 0.25, 1.0): "s3",
}

_SUFFIX_TO_STRESS = {
    "_noise_s1": (NOISE_FAMILY, "s1"),
    "_noise_s3": (NOISE_FAMILY, "s3"),
    "_noise_0p05": (NOISE_FAMILY, "s2"),
    "_sparsity_s1": (SPARSITY_FAMILY, "s1"),
    "_sparsity_s2": (SPARSITY_FAMILY, "s2"),
    "_sparsity_0p1": (SPARSITY_FAMILY, "s3"),
    "_extrapolation_s1": (TEMPORAL_HOLDOUT_FAMILY, "s1"),
    "_extrapolation_s3": (TEMPORAL_HOLDOUT_FAMILY, "s3"),
    "_extrapolation_t0p5": (TEMPORAL_HOLDOUT_FAMILY, "s2"),
    "_support_extrapolation_mild": (SUPPORT_EXTRAPOLATION_FAMILY, "mild"),
    "_support_extrapolation_medium": (SUPPORT_EXTRAPOLATION_FAMILY, "medium"),
    "_support_extrapolation_severe": (SUPPORT_EXTRAPOLATION_FAMILY, "severe"),
    "_bcic_corruption_mild": (BCIC_CORRUPTION_FAMILY, "mild"),
    "_bcic_corruption_medium": (BCIC_CORRUPTION_FAMILY, "medium"),
    "_bcic_corruption_severe": (BCIC_CORRUPTION_FAMILY, "severe"),
}

_PROTOCOL_TO_FAMILY = {
    "noise": "noise",
    "sparsity": "sparsity",
    "support_extrapolation": SUPPORT_EXTRAPOLATION_FAMILY,
    "extrapolation": TEMPORAL_HOLDOUT_FAMILY,
    "bcic_corruption": BCIC_CORRUPTION_FAMILY,
}



def _coerce_float(value: Any) -> float | None:
    if value is None or value == "":
        return None
    return float(value)



def _approx_equal(left: float | None, right: float) -> bool:
    if left is None:
        return False
    return abs(left - right) <= 1e-9



def derive_stability_category(degradation_ratio: Any) -> str | None:
    ratio = _coerce_float(degradation_ratio)
    if ratio is None:
        return None
    if ratio <= STABLE_THRESHOLD:
        return "stable"
    if ratio <= FRAGILE_THRESHOLD:
        return "degraded"
    return "fragile"



def _severity_from_level(protocol: str, level: float | None) -> str | None:
    if protocol == "noise":
        for candidate, severity in _NOISE_LEVEL_TO_SEVERITY.items():
            if _approx_equal(level, candidate):
                return severity
        return None
    if protocol == "sparsity":
        for candidate, severity in _SPARSITY_LEVEL_TO_SEVERITY.items():
            if _approx_equal(level, candidate):
                return severity
        return None
    if protocol == "bcic_corruption":
        for candidate, severity in _BCIC_LEVEL_TO_SEVERITY.items():
            if _approx_equal(level, candidate):
                return severity
        return None
    return None



def _severity_from_temporal_windows(row: Mapping[str, Any]) -> str | None:
    window_key = (
        _coerce_float(row.get("train_time_range_start")),
        _coerce_float(row.get("train_time_range_end")),
        _coerce_float(row.get("eval_time_range_start")),
        _coerce_float(row.get("eval_time_range_end")),
    )
    return _TEMPORAL_WINDOWS_TO_SEVERITY.get(window_key)



def _nominal_peer_run_id(run_id: str) -> str | None:
    for suffix in _SUFFIX_TO_STRESS:
        if run_id.endswith(suffix):
            return run_id[: -len(suffix)]
    for protocol in ("noise", "sparsity", "support_extrapolation", "bcic_corruption"):
        for severity in ("nominal", "mild", "medium", "severe", "s1", "s2", "s3"):
            suffix = f"_{protocol}_{severity}"
            if run_id.endswith(suffix):
                return run_id[: -len(suffix)]
    return None


def _normalize_protocol_name(protocol: str) -> str:
    normalized = str(protocol).strip().lower()
    return normalized


def _severity_from_label(row: Mapping[str, Any]) -> str | None:
    for key in ("severity_label", "robustness_severity_label", "stress_severity"):
        value = row.get(key)
        if value is None:
            continue
        normalized = str(value).strip().lower()
        if normalized:
            return normalized
    return None


def _severity_from_support_ratio(row: Mapping[str, Any]) -> str | None:
    ratio = _coerce_float(row.get("train_support_ratio"))
    if ratio is None:
        return None
    for candidate, severity in _SUPPORT_RATIO_TO_SEVERITY.items():
        if _approx_equal(ratio, candidate):
            return severity
    return None



def derive_stress_metadata(row: Mapping[str, Any]) -> dict[str, Any]:
    run_id = str(row.get("run_id") or "").strip()
    protocol = _normalize_protocol_name(str(row.get("protocol") or "none"))
    if protocol == "none":
        return {
            "is_stress_run": False,
            "stress_family": None,
            "stress_severity": None,
            "stress_case_id": None,
            "nominal_peer_run_id": run_id or None,
            "stress_comparability_class": "nominal_only",
            "stability_category": derive_stability_category(row.get("degradation_ratio_vs_standard")),
        }

    family: str | None = None
    severity: str | None = None
    nominal_peer = _nominal_peer_run_id(run_id)
    for suffix, pair in _SUFFIX_TO_STRESS.items():
        if run_id.endswith(suffix):
            family, severity = pair
            break

    level = _coerce_float(row.get("robustness_level"))
    severity = severity or _severity_from_label(row)
    if protocol == "noise":
        family = family or ("noise" if severity in {"nominal", "mild", "medium", "severe"} else NOISE_FAMILY)
        severity = severity or _severity_from_level(protocol, level)
    elif protocol == "sparsity":
        family = family or ("sparsity" if severity in {"nominal", "mild", "medium", "severe"} else SPARSITY_FAMILY)
        severity = severity or _severity_from_level(protocol, level)
    elif protocol == "extrapolation":
        family = family or TEMPORAL_HOLDOUT_FAMILY
        severity = severity or _severity_from_temporal_windows(row)
    elif protocol == "support_extrapolation":
        family = family or SUPPORT_EXTRAPOLATION_FAMILY
        severity = severity or _severity_from_support_ratio(row)
        severity = severity or _severity_from_temporal_windows(row)
    elif protocol == "bcic_corruption":
        family = family or BCIC_CORRUPTION_FAMILY
        severity = severity or _severity_from_level(protocol, level)
    else:
        family = family or _PROTOCOL_TO_FAMILY.get(protocol)

    stress_case_id = None if family is None or severity is None else f"{family}_{severity}"
    if family is not None and severity is not None and nominal_peer is not None:
        comparability_class = "official_within_host_and_severity"
    else:
        comparability_class = "appendix_only"

    return {
        "is_stress_run": True,
        "stress_family": family,
        "stress_severity": severity,
        "stress_case_id": stress_case_id,
        "nominal_peer_run_id": nominal_peer,
        "stress_comparability_class": comparability_class,
        "stability_category": derive_stability_category(row.get("degradation_ratio_vs_standard")),
    }



def apply_stress_metadata(row: Mapping[str, Any]) -> dict[str, Any]:
    enriched = dict(row)
    enriched.update(derive_stress_metadata(row))
    return enriched



def build_stress_summary(rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    enriched_rows = [apply_stress_metadata(row) for row in rows]
    stress_rows = [row for row in enriched_rows if bool(row.get("is_stress_run"))]
    official_rows = [row for row in stress_rows if row.get("stress_comparability_class") == "official_within_host_and_severity"]
    ratios = [
        (row, _coerce_float(row.get("degradation_ratio_vs_standard")))
        for row in stress_rows
    ]
    ratios = [(row, ratio) for row, ratio in ratios if ratio is not None]
    worst_row = max(ratios, key=lambda item: item[1])[0] if ratios else None
    by_family = Counter(str(row.get("stress_family") or "unknown") for row in stress_rows)
    by_severity = Counter(str(row.get("stress_severity") or "unknown") for row in stress_rows)
    stable_counts = Counter(str(row.get("stability_category") or "unknown") for row in stress_rows)

    contrast_rows = sorted(
        ratios,
        key=lambda item: item[1],
        reverse=True,
    )[:3]
    contrast_lines = [
        "`{run_id}` vs `{nominal_peer_run_id}` -> degradation=`{ratio:.6g}` ({stability})".format(
            run_id=row.get("run_id"),
            nominal_peer_run_id=row.get("nominal_peer_run_id"),
            ratio=ratio,
            stability=row.get("stability_category"),
        )
        for row, ratio in contrast_rows
    ]

    worst_case = None
    if worst_row is not None:
        worst_case = {
            "run_id": worst_row.get("run_id"),
            "stress_family": worst_row.get("stress_family"),
            "stress_severity": worst_row.get("stress_severity"),
            "stress_case_id": worst_row.get("stress_case_id"),
            "nominal_peer_run_id": worst_row.get("nominal_peer_run_id"),
            "degradation_ratio_vs_standard": worst_row.get("degradation_ratio_vs_standard"),
            "stability_category": worst_row.get("stability_category"),
        }

    return {
        "stress_row_count": len(stress_rows),
        "official_stress_row_count": len(official_rows),
        "stress_family_counts": dict(sorted(by_family.items())),
        "stress_severity_counts": dict(sorted(by_severity.items())),
        "stability_counts": dict(sorted(stable_counts.items())),
        "stress_summary": {
            "stress_row_count": len(stress_rows),
            "official_stress_row_count": len(official_rows),
            "stress_family_counts": dict(sorted(by_family.items())),
            "stress_severity_counts": dict(sorted(by_severity.items())),
            "stability_counts": dict(sorted(stable_counts.items())),
        },
        "worst_stress_case": worst_case,
        "nominal_vs_stress_contrast": contrast_lines,
        "stress_caveats": [
            "Stress comparisons stay host-relative and should not be collapsed into one pooled global ranking.",
            "Canonical stress labels are additive metadata over the existing protocol/robustness execution surface.",
        ],
    }



def build_stress_comparability_policy(rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    enriched_rows = [apply_stress_metadata(row) for row in rows]
    stress_rows = [row for row in enriched_rows if bool(row.get("is_stress_run"))]
    official_rows = [row for row in stress_rows if row.get("stress_comparability_class") == "official_within_host_and_severity"]
    appendix_only_rows = [row for row in stress_rows if row.get("stress_comparability_class") != "official_within_host_and_severity"]
    return {
        "official_comparison_contract": [
            "official comparisons require the same stress_family",
            "official comparisons require the same stress_severity",
            "official comparisons require the same task/model/evaluation cohort",
            "nominal-vs-stress comparisons remain host-relative via nominal_peer_run_id",
        ],
        "appendix_only_conditions": [
            "cross-family stress comparisons",
            "cross-severity stress comparisons",
            "rows without a recognized canonical severity",
            "rows without a nominal peer host",
        ],
        "official_stress_row_count": len(official_rows),
        "appendix_only_stress_row_count": len(appendix_only_rows),
        "official_stress_case_ids": sorted({str(row.get("stress_case_id")) for row in official_rows if row.get("stress_case_id")}),
        "appendix_only_run_ids": sorted(str(row.get("run_id")) for row in appendix_only_rows if row.get("run_id")),
        "comparability_notes": [
            "Official stress comparisons are severity-matched, family-matched, and cohort-local.",
            "Cross-family, cross-severity, or unmatched-host stress rows should be treated as appendix_only.",
            "Nominal-vs-stress interpretation should stay within the same host family rather than turning into a pooled leaderboard.",
        ],
        "summary": "severity_standardized" if official_rows else "appendix_only",
    }
