from __future__ import annotations

from pathlib import Path

from setuptools import find_packages, setup


REPO_ROOT = Path(__file__).resolve().parent


def read_text(path: str) -> str:
    return (REPO_ROOT / path).read_text(encoding="utf-8")


def read_requirements(path: str) -> list[str]:
    requirements: list[str] = []
    for line in (REPO_ROOT / path).read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        requirements.append(stripped)
    return requirements


setup(
    name="pinnmark",
    version="0.1.0",
    description="PINNMark inverse PDE benchmarking toolkit and CLI facade",
    long_description=read_text("README.md"),
    long_description_content_type="text/markdown",
    author="PINNMark Authors",
    author_email="opensource@pinnmark.org",
    url="https://pypi.org/project/pinnmark/",
    license="MIT",
    python_requires=">=3.9",
    packages=find_packages(include=["pinnmark*", "pinn_bench*"]),
    include_package_data=True,
    install_requires=read_requirements("requirements.txt"),
    entry_points={
        "console_scripts": [
            "pinnmark-run = pinnmark.run_full_inverse_benchmark:main",
            "pinn-bench = pinn_bench.run:main",
        ]
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering",
    ],
)
