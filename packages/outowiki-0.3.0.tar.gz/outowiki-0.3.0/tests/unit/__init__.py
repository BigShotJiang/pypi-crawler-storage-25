"""Unit tests for OutoWiki."""
