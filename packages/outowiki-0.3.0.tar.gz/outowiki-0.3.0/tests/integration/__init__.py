"""Integration tests for OutoWiki."""
