# Goose MCP Client Spec

- **Config path (macOS):** `~/.config/goose/config.yaml`
- **Config path (Windows):** `%APPDATA%/Block/goose/config/config.yaml`
- **Format:** YAML
- **Servers key:** `extensions`
- **Project config:** None (global only)
- **Transport:** stdio, streamable_http
- **Note:** Uses `cmd`/`envs` instead of `command`/`env` for stdio servers; `enabled` field for filtering
- **Last verified:** 2026-04-06

## Editor docs

- **Skills:** https://block.github.io/goose/docs/guides/context-engineering/using-skills/
- **Plugins:** No native plugin system
- **MCP:** https://block.github.io/goose/docs/getting-started/using-extensions/

## Runlayer support

### Skills: not supported
Goose has native skills but Runlayer does not install them yet.

### Plugins: mcp_fallback
No native plugin support. Writes HTTP proxy entry to client config under `"extensions"`.
- Lockfile: `.runlayer/plugin-lock.yml` (`install_mode: mcp_fallback`)

### MCP connectors (servers)
- Config: `~/.config/goose/config.yaml`
- Local entry (YAML, uses `cmd` not `command`):
  ```yaml
  enabled: true
  type: stdio
  name: <normalized-name>
  cmd: uvx
  args: ["runlayer", "run", "<server-id>", "--host", "<host>"]
  envs: {}
  timeout: 300
  ```
- Remote entry (YAML):
  ```yaml
  enabled: true
  type: streamable_http
  name: <normalized-name>
  uri: <proxy-url>
  envs: {}
  timeout: 300
  ```
