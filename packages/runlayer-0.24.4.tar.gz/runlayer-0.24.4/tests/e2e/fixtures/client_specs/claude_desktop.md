# Claude Desktop MCP Client Spec

- **Config path (macOS):** `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Config path (Windows):** `%APPDATA%/Claude/claude_desktop_config.json`
- **Format:** JSON
- **Servers key:** `mcpServers`
- **Project config:** None (global only)
- **Transport:** stdio via `claude_desktop_config.json`; remote connectors via Claude Settings > Connectors
- **Last verified:** 2026-04-06

## Editor docs

- **Skills:** No native SKILL.md support (uses Cowork skills, UI-based)
- **Plugins:** https://github.com/anthropics/dxt (DXT/MCPB desktop extensions)
- **MCP:** https://modelcontextprotocol.io/quickstart/user

## Runlayer support

### Skills: not supported
Claude Desktop does not support SKILL.md files.

### Plugins: unsupported
Desktop extensions (`.mcpb`) exist, but Runlayer CLI does not install them.

### MCP connectors (servers)
- Config: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Runlayer CLI writes local only** — no remote/proxy entry in `claude_desktop_config.json`
- Remote connectors are added in Claude Settings > Connectors (not via `claude_desktop_config.json`)
- Local entry:
  ```json
  {"command": "uvx", "args": ["runlayer", "run", "<server-id>", "--host", "<host>"]}
  ```
