# Codex MCP Client Spec

- **Config path:** `~/.codex/config.toml` (all platforms)
- **Format:** TOML
- **Servers key:** `mcp_servers`
- **Project config:** `.codex/config.toml` (servers key: `mcp_servers`)
- **Marketplace path (project):** `$REPO_ROOT/.agents/plugins/marketplace.json`
- **Marketplace path (global):** `~/.agents/plugins/marketplace.json`
- **Plugin cache:** `~/.codex/plugins/cache/<marketplace>/<plugin>/<version>/`
- **Plugin state:** `~/.codex/config.toml`
- **Transport:** stdio, Streamable HTTP
- **Last verified:** 2026-04-06

## Editor docs

- **Plugins:** https://developers.openai.com/codex/plugins
- **Config:** https://developers.openai.com/codex/config-reference
- **MCP:** https://developers.openai.com/codex/mcp

## Runlayer support

### Skills: supported separately
- Native skill install is tracked outside this plugin flow.

### Plugins: marketplace-native
- Canonical: `.agents/plugins/<normalized-name>/`
- Manifest: `.agents/plugins/<normalized-name>/.codex-plugin/plugin.json`
- MCP config: `.agents/plugins/<normalized-name>/.mcp.json` with `"mcpServers"` key
- Skills: `.agents/plugins/<normalized-name>/skills/<normalized-skill-name>/`
- Normalization: kebab-case for Codex-facing plugin and skill names
- Display name: plugin manifest may preserve the original title via `interface.displayName`
- Marketplace entry:
  - project: `.agents/plugins/marketplace.json`
  - global: `~/.agents/plugins/marketplace.json`
- Lockfile: `.runlayer/plugin-lock.yml` (`install_mode: native_codex_marketplace`)
- Runlayer CLI does **not** write Codex cache or `config.toml`; user finishes install in Codex via `/plugins`

### MCP connectors (servers)
- Config: `~/.codex/config.toml` or `.codex/config.toml`
- Local entry:
  ```toml
  [mcp_servers.runlayer]
  command = "uvx"
  args = ["runlayer", "run", "<server-id>", "--host", "<host>"]
  ```
- Remote entry:
  ```toml
  [mcp_servers.runlayer]
  url = "<proxy-url>"
  ```
