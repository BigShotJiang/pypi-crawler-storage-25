# Zed MCP Client Spec

- **Config path (macOS):** `~/.config/zed/settings.json`
- **Config path (Windows):** `%APPDATA%/Zed/settings.json`
- **Format:** JSON
- **Servers key:** `context_servers`
- **Project config:** `.zed/settings.json` (servers key: `context_servers`)
- **Transport:** stdio, HTTP
- **Extensions:** `~/Library/Application Support/Zed/extensions/installed/mcp-server-*`
- **Last verified:** 2026-04-06

## Editor docs

- **Skills:** No native skills support
- **Plugins:** No native plugin system (uses Rust/WASM extensions)
- **MCP:** https://zed.dev/docs/assistant/model-context-protocol
- **Extensions:** https://zed.dev/docs/extensions

## Runlayer support

### Skills: not supported
Zed does not have native SKILL.md support.

### Plugins: mcp_fallback
No native plugin support. Writes HTTP proxy entry to client config under `"context_servers"`.
- Lockfile: `.runlayer/plugin-lock.yml` (`install_mode: mcp_fallback`)

### MCP connectors (servers)
- Config: `~/.config/zed/settings.json` or `.zed/settings.json`
- Local entry:
  ```json
  {"command": "uvx", "args": ["runlayer", "run", "<server-id>", "--host", "<host>"], "env": {}}
  ```
- Remote entry:
  ```json
  {"url": "<proxy-url>"}
  ```
