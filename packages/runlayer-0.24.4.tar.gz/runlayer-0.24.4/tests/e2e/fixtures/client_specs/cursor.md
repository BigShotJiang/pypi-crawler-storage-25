# Cursor MCP Client Spec

- **Config path (macOS):** `~/.cursor/mcp.json`
- **Config path (Windows):** `%USERPROFILE%/.cursor/mcp.json`
- **Format:** JSON
- **Servers key:** `mcpServers`
- **Project config:** `.cursor/mcp.json` (servers key: `mcpServers`)
- **Transport:** stdio, SSE, Streamable HTTP
- **Last verified:** 2026-04-06

## Editor docs

- **Skills:** https://cursor.com/docs/skills
- **Plugins:** https://cursor.com/docs/plugins
- **MCP:** https://docs.cursor.com/context/model-context-protocol

## Runlayer support

### Skills: native
- Canonical: `.agents/skills/<name>/`
- Symlink: `.cursor/skills/<name>` → canonical
- Lockfile: `.runlayer/skill-lock.yml`

### Plugins: native
- Manifest: `.agents/plugins/<name>/.cursor-plugin/plugin.json`
- MCP config: `.agents/plugins/<name>/.mcp.json` with `"mcpServers"` key
- Skills: `.agents/plugins/<name>/skills/<skill>/`
- Symlink: `.cursor/plugins/<name>` → canonical
- Lockfile: `.runlayer/plugin-lock.yml` (`install_mode: native`)

### MCP connectors (servers)
- Config: `~/.cursor/mcp.json` or `.cursor/mcp.json`
- Local entry:
  ```json
  {"command": "uvx", "args": ["runlayer", "run", "<server-id>", "--host", "<host>"]}
  ```
- Remote entry:
  ```json
  {"url": "<proxy-url>"}
  ```
