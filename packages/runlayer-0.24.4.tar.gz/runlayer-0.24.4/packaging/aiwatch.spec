# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec for the AI Watch scan-only binary.

One-dir mode on purpose: MDM-deployed tools must not look like self-extracting
droppers to EDR. `--onefile` writes ~25 MB of dylibs/DLLs to $TMPDIR on every
invocation, which is the textbook behavioral fingerprint CrowdStrike /
SentinelOne / Defender ATP flag. `--onedir` installs once to
`/usr/local/lib/aiwatch/` (mac) or `C:\\Program Files\\Runlayer\\AIWatch\\`
(win) and every subsequent scan is an exec of an already-on-disk signed
binary. Installers wrap the resulting `dist/aiwatch/` directory.

UPX is deliberately disabled for the same reason: UPX-packed Mach-O / PE is
another "packer" signal to EDR behavioral rules and also breaks or complicates
macOS codesigning + notarization.

Build:
  macOS (host arch):  pyinstaller packaging/aiwatch.spec
  Windows x64:        pyinstaller packaging/aiwatch.spec

macOS ships two .pkgs (arm64 + x86_64) built natively per-arch in CI rather
than a universal2 binary — universal2 requires every C-extension in the
Python install to be fat, which setup-python does not guarantee.
"""

import platform
import sys

block_cipher = None

target_arch = None
if "--target-arch" in sys.argv:
    idx = sys.argv.index("--target-arch")
    if idx + 1 < len(sys.argv):
        target_arch = sys.argv[idx + 1]

a = Analysis(
    ["../runlayer_cli/aiwatch.py"],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=[
        "keyring.backends.macOS" if platform.system() == "Darwin" else "keyring.backends.Windows",
        "runlayer_cli.scan",
        "runlayer_cli.scan.clients",
        "runlayer_cli.scan.config_parser",
        "runlayer_cli.scan.device",
        "runlayer_cli.scan.service",
        "runlayer_cli.scan.skill_scanner",
        "runlayer_cli.scan.plugin_scanner",
        "runlayer_cli.scan.file_collector",
        "runlayer_cli.scan.project_scanner",
        "runlayer_cli.scan.claude_code_plugins",
        "runlayer_cli.scan.codex_plugins",
        "runlayer_cli.scan.cursor_plugins",
        "runlayer_cli.scan.opencode_plugins",
        "runlayer_cli.scan.openclaw_detector",
        "runlayer_cli.skill_identifier",
        "runlayer_cli.plugins.claude_manifest",
        "runlayer_cli.skills.discovery",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        "fastmcp",
        "docker",
        "mcp",
        "fakeredis",
        "questionary",
        "dotenv",
        "python-dotenv",
        "anyio",
        "tkinter",
        "unittest",
        "PIL",
        "numpy",
        "pandas",
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe_kwargs = dict(
    name="aiwatch",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=True,
)

if target_arch:
    exe_kwargs["target_arch"] = target_arch

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    **exe_kwargs,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="aiwatch",
)
