# AI Watch — Deployment Guide

Step-by-step for IT admins deploying `aiwatch` to a fleet via Kandji (macOS) or Intune (Windows). For builder/packaging details see [`README.md`](README.md).

## Deployment model

One build artifact per platform ships to every tenant. Tenant-specific values are supplied at deploy time through OS-native surfaces — **never** baked into the binary.

| Setting                | macOS source                                            | Windows source                             |
| ---------------------- | ------------------------------------------------------- | ------------------------------------------ |
| Tenant host            | MDM Configuration Profile, domain `com.runlayer.aiwatch`, key `Host` | MSI property `AIWATCH_HOST` → `HKLM\Software\Runlayer\AIWatch\Host` |
| Org API key value      | Same profile, key `OrgApiKey` (the `rl_org_...` secret) | MSI property `AIWATCH_ORG_API_KEY` (the `rl_org_...` secret) → `HKLM\Software\Runlayer\AIWatch\OrgApiKey` |
| Scan schedule          | LaunchAgent bundled in `.pkg` (default 900 s; override via Custom Script) | Intune Remediations UI                     |

The MDM-pushed `OrgApiKey` is the **actual org API key secret** (e.g.
`rl_org_...`), not a name to look up. `aiwatch` feeds it straight into
`RUNLAYER_API_KEY` at startup.

`aiwatch` resolution order at scan time:

1. CLI flags (`--host`, `--secret`)
2. Env vars (`RUNLAYER_HOST`, `RUNLAYER_API_KEY`)
3. OS-native managed config (table above)

## Parameterization support by MDM

Some MDMs let admins supply tenant values (host URL + org API key) through a native form or variable system so the `.mobileconfig` never needs manual editing. Others only support fixed device/user tokens — those still require find-and-replace before upload.

| MDM | Parameterized? | Mechanism | Artifact |
| --- | --- | --- | --- |
| Jamf Pro | **Yes** | JSON Schema manifest → form UI in Application & Custom Settings | `com.runlayer.aiwatch.jamf.schema.json` |
| Workspace ONE | **Yes** | Custom Attributes `{CustomAttribute1}` / `{CustomAttribute2}` in profile XML | `com.runlayer.aiwatch.config.ws1.mobileconfig` |
| Intune Windows | **Yes** (already) | MSI public properties `AIWATCH_HOST` / `AIWATCH_ORG_API_KEY` | No extra artifact |
| Intune macOS | No | Only device tokens (`{{serialnumber}}` etc.) — no admin tenant values | Use base `.mobileconfig` with find-and-replace |
| Iru (Kandji) | Possibly (unconfirmed) | May support Blueprint-level parameters for Custom Profiles — to be confirmed | Use base `.mobileconfig` with find-and-replace for now |
| Mosyle | No | Fixed tokens + per-device custom-attribute scripts only | Use base `.mobileconfig` with find-and-replace |
| Jamf Now | No | No Custom Settings payload | Use base `.mobileconfig` with find-and-replace |

If your MDM is in the **Yes** column, skip to the relevant section under [Other MDMs](#other-mdms) for setup instructions — no XML editing required.

## Prerequisites

### Runlayer backend

1. In the Runlayer tenant, create an **organization API key** intended for AI Watch. Record the secret value (`rl_org_...`) — that exact string is what gets pushed to every device via MDM.
2. Confirm your tenant host URL (e.g. `https://tenant.runlayer.com`).

### MDM access

- macOS: Kandji admin with permission to create Custom Apps and Custom Profiles. (No "Launch Agent" library item is needed — the agent ships inside the `.pkg`.)
- Windows: Intune admin with Win32 app upload rights and Devices → Remediations access.

### Artifacts

From the latest GitHub Release of the `cli-*` tag (CI produces all):

- `aiwatch-<ver>-macos-arm64.pkg` — Apple Silicon
- `aiwatch-<ver>-macos-x86_64.pkg` — Intel
- `aiwatch-<ver>-win-x64.msi`
- `aiwatch-<ver>-win-x64.intunewin`

Each macOS `.pkg` declares `hostArchitectures` so the macOS Installer cleanly
refuses the wrong arch (no Rosetta prompt). Upload both as separate Kandji
Custom Apps and scope each to a Smart Group filtered by Mac CPU architecture.

## macOS (Kandji)

The `.pkg` is self-contained: it installs the onedir bundle to `/usr/local/lib/aiwatch/`, the `/usr/local/bin/aiwatch` symlink, **and** the LaunchAgent at `/Library/LaunchAgents/com.runlayer.aiwatch.plist`. The postinstall script bootstraps the agent into the console user's GUI domain immediately, and it auto-loads on every subsequent login. Schedule defaults to 15 min — see [§5](#5-customize-scan-schedule-optional) to override per tenant.

**Four MDM items** (deploy to the same Blueprint). Kandji does not have a native "Launch Agent" library item — the agent ships inside the `.pkg`, not as a separate MDM payload.

1. **Custom App** — the `.pkg` (binary + LaunchAgent install).
2. **Custom Profile** — tenant host + org API key secret (runtime config).
3. **PPPC Profile** — Full Disk Access for `aiwatch` (TCC grants).
4. **Login Items Profile** — pre-approves the LaunchAgent on macOS 13+ so users don't see "Background Item Added" notifications.

### 1. Install the binary + LaunchAgent

1. Kandji → **Library → Add New Item → Custom App**.
2. Upload the `.pkg` matching the target Macs' arch (`arm64` or `x86_64`). Repeat as a second Custom App for the other arch and scope each via Smart Group.
3. **Install Type**: Audit & Enforce.
4. **Audit Script**: `test -x /usr/local/bin/aiwatch && test -f /Library/LaunchAgents/com.runlayer.aiwatch.plist` (exit 0 = installed). This script never needs updating across releases — it only detects tampering / corruption. Upgrades are handled by Kandji separately: the `.pkg` carries its version in its metadata (`pkgbuild --version`), Kandji compares against the device's `pkgutil --pkg-info com.runlayer.aiwatch` receipt, and reinstalls when the uploaded `.pkg` is newer.
5. Assign to the device **Blueprint** for AI Watch targets.

### 2. Push tenant host + org API key secret

1. Open `packaging/macos/com.runlayer.aiwatch.config.mobileconfig` and replace the two placeholders:

   | Placeholder                    | Replace with                                                            |
   | ------------------------------ | ----------------------------------------------------------------------- |
   | `REPLACE_WITH_TENANT_HOST`     | e.g. `https://tenant.runlayer.com`                                      |
   | `REPLACE_WITH_ORG_API_KEY`     | the **actual** org API key secret minted in Runlayer (e.g. `rl_org_...`) |

2. Kandji → **Library → Add New Item → Custom Profile**. Upload the edited `.mobileconfig`.
3. Assign to the same Blueprint. `aiwatch` reads from `/Library/Managed Preferences/com.runlayer.aiwatch.plist` at scan time — changes are picked up on the next profile sync.

To update values later: edit the file, bump `PayloadVersion` on both the inner and outer payloads, re-upload. No `.pkg` reinstall required.

### 3. Grant Full Disk Access (PPPC)

`aiwatch scan` walks `$HOME` looking for project-level MCP configs (`.mcp.json`, `.cursor/mcp.json`, etc.). macOS TCC protects `~/Desktop`, `~/Documents`, `~/Downloads`, and parts of `~/Library/Application Support` — without an FDA grant the LaunchAgent silently skips those trees (no prompt possible from a background agent). Push a PPPC profile up-front.

1. Kandji → **Library → Add New Item → Custom Profile** (or **Privacy Preferences Policy Control** if your Kandji tenant exposes the typed UI).
2. Upload `packaging/macos/com.runlayer.aiwatch.pppc.mobileconfig` as-is.
3. Assign to the same Blueprint.

Permissions granted (mirrors the existing `runlayer-scan` wrapper profile — same reviewer-approved surface):

| TCC service                  | Why aiwatch needs it                                              |
| ---------------------------- | ----------------------------------------------------------------- |
| `SystemPolicyAllFiles` (FDA) | Catch-all for any future TCC-gated path                           |
| `SystemPolicyAppData`        | Some MCP clients write under `~/Library/Application Support/<app>/` |
| `SystemPolicyDesktopFolder`  | Project-level `.mcp.json` under `~/Desktop/`                      |
| `SystemPolicyDocumentsFolder`| Project-level `.mcp.json` under `~/Documents/`                    |
| `SystemPolicyDownloadsFolder`| Project-level `.mcp.json` under `~/Downloads/`                    |
| `SystemPolicyNetworkVolumes` | Projects on mounted network shares                                |
| `SystemPolicyRemovableVolumes` | Projects on external drives                                     |

Code requirement: `identifier "com.runlayer.aiwatch"`, target path `/usr/local/lib/aiwatch/aiwatch` (the real binary behind the `/usr/local/bin/aiwatch` symlink — TCC attributes on the canonical path).

**Prerequisites:**

- The `.pkg` must be signed + notarized, and the inner `aiwatch` Mach-O must be codesigned with identifier `com.runlayer.aiwatch` (Developer ID Application cert, hardened runtime). **Unsigned / ad-hoc signed builds will not receive these grants** — the CodeRequirement check fails and TCC falls back to deny.
- Device must be **UAMDM** (User-Approved MDM) or DEP/ADE. TCC payloads are ignored on manually-enrolled MDM.
- Deploy the PPPC profile **before or alongside** the `.pkg` so the LaunchAgent's first tick already has permissions.

### 4. Pre-approve the LaunchAgent (Login Items profile)

On macOS 13 (Ventura) and newer, any LaunchAgent installed by a `.pkg` triggers a one-shot **"Background Item Added"** notification on first login post-install, and the user can disable it from System Settings → General → Login Items. On a managed fleet this is noisy and breaks scanning. A `com.apple.servicemanagement` profile pre-approves the agent and locks it on.

1. Open `packaging/macos/com.runlayer.aiwatch.loginitems.mobileconfig` and replace `REPLACE_WITH_TEAM_ID` with the Apple Developer team identifier the `aiwatch` binary is signed with (visible via `codesign -dv /usr/local/lib/aiwatch/aiwatch | grep TeamIdentifier`). This is the same team ID for every tenant.
2. Kandji → **Library → Add New Item → Custom Profile**. Upload the edited `.mobileconfig`.
3. Assign to the same Blueprint.

The profile matches the LaunchAgent by `LabelPrefix=com.runlayer.aiwatch` + the team identifier, so it covers any future agents we ship under that prefix without reauthoring. macOS < 13 ignores the payload silently.

### 5. Customize scan schedule (optional)

Default `StartInterval` is 900 s (15 min), baked into the bundled `/Library/LaunchAgents/com.runlayer.aiwatch.plist`. Most tenants don't need to change it. To override per-tenant push a Kandji **Custom Script** (Run on a Schedule, or Audit & Enforce):

```bash
#!/bin/bash
set -euo pipefail
PLIST=/Library/LaunchAgents/com.runlayer.aiwatch.plist
INTERVAL=1800   # 30 min — edit per tenant

/usr/libexec/PlistBuddy -c "Set :StartInterval ${INTERVAL}" "$PLIST"

CONSOLE_UID=$(stat -f %u /dev/console 2>/dev/null || echo "")
if [ -n "$CONSOLE_UID" ] && [ "$CONSOLE_UID" != "0" ]; then
    launchctl bootout "gui/${CONSOLE_UID}/com.runlayer.aiwatch" 2>/dev/null || true
    launchctl bootstrap "gui/${CONSOLE_UID}" "$PLIST" 2>/dev/null || true
fi
```

Note: the next `.pkg` upgrade will reset the file to the bundled default, so the override script must run on a recurring schedule (or be re-applied after each Custom App update).

### 6. Verify

On a test Mac after blueprint sync:

```bash
# .pkg installed (binary + LaunchAgent)?
test -x /usr/local/bin/aiwatch && \
  test -f /Library/LaunchAgents/com.runlayer.aiwatch.plist && \
  echo "binary + agent OK"

# Config Profile landed?
defaults read /Library/Managed\ Preferences/com.runlayer.aiwatch.plist

# LaunchAgent loaded for the console user?
launchctl print "gui/$(id -u)/com.runlayer.aiwatch"

# Login Items profile applied (macOS 13+)?
sfltool dumpbtm | grep -i runlayer || echo "not yet — wait one profile sync"

# PPPC grants visible to TCC?
tccutil reset All com.runlayer.aiwatch   # optional: clear stale state
sudo log show --predicate 'subsystem == "com.apple.TCC"' --last 5m | grep -i aiwatch

# Trigger an immediate scan
/usr/local/bin/aiwatch scan

# Tail the logs
tail -f /tmp/aiwatch.out /tmp/aiwatch.err
```

### 7. Update tenant config later

- Change host / rotate org API key: edit `com.runlayer.aiwatch.config.mobileconfig`, bump `PayloadVersion`, re-upload. Takes effect next scan.
- Change schedule: see [§5](#5-customize-scan-schedule-optional).
- Neither requires reinstalling the `.pkg`.

### 8. Uninstall

- Unscope the Blueprint (removes the three Configuration Profiles: tenant config, PPPC, Login Items).
- Add a **Custom Script** (Run Once) to remove the binary + LaunchAgent:

  ```bash
  CONSOLE_UID=$(stat -f %u /dev/console 2>/dev/null || echo "")
  if [ -n "$CONSOLE_UID" ] && [ "$CONSOLE_UID" != "0" ]; then
      launchctl bootout "gui/${CONSOLE_UID}/com.runlayer.aiwatch" 2>/dev/null || true
  fi
  rm -f /usr/local/bin/aiwatch
  rm -rf /usr/local/lib/aiwatch
  rm -f /Library/LaunchAgents/com.runlayer.aiwatch.plist
  pkgutil --forget com.runlayer.aiwatch 2>/dev/null || true
  ```

## Windows (Intune)

Two deployments: (1) Win32 app for the MSI, (2) Remediation for the scan schedule. Both target the same device group.

### 1. Install the MSI (Win32 app)

1. Intune → **Apps → Windows → Add → Windows app (Win32)**.
2. Upload `aiwatch-<ver>-win-x64.intunewin`.
3. **Install command** (substitute tenant values; `AIWATCH_ORG_API_KEY` is the actual `rl_org_...` secret minted in Runlayer):

   ```
   msiexec /i aiwatch-<ver>-win-x64.msi /qn ^
     AIWATCH_HOST=https://tenant.runlayer.com ^
     AIWATCH_ORG_API_KEY=rl_org_xxxxxxxxxxxxxxxxxxxxxxxxxxxx
   ```

4. **Uninstall command**:

   ```
   msiexec /x aiwatch-<ver>-win-x64.msi /qn
   ```

5. **Install behavior**: System.
6. **Device restart**: No restart required.
7. **Detection rule** (MSI product code detection works, or use a file rule):

   | Path | `C:\Program Files\Runlayer\AIWatch\aiwatch.exe` |
   | ---- | ---- |
   | Property | File exists |

8. **Requirements**: 64-bit Windows 10 1809+ / 11.
9. Assign to the AI Watch device group.

The MSI writes `AIWATCH_HOST` / `AIWATCH_ORG_API_KEY` to `HKLM\Software\Runlayer\AIWatch` (values `Host` / `OrgApiKey`). `aiwatch.exe` reads them via `winreg` at scan time and uses `OrgApiKey` directly as `RUNLAYER_API_KEY`. Both properties are **required** — the installer aborts with a clear error if either is missing, so there is no silent tenant-mismatch path.

### 2. Schedule scans (Intune Remediations)

1. Intune → **Devices → Remediations → Create script package**.
2. **Detection script**: upload `packaging/windows/remediation/detect.ps1` as-is.
3. **Remediation script**: upload `packaging/windows/remediation/remediate.ps1` as-is.
4. **Run this script using the logged-on credentials**: **Yes** — critical, so scan sees per-user MCP client configs under `%APPDATA%`.
5. **Run script in 64-bit PowerShell**: Yes.
6. **Enforce script signature check**: No (unless you re-sign the scripts).
7. **Schedule**: minimum hourly (Intune limit).
8. Assign to the same device group as the Win32 app.

`detect.ps1` reports non-compliant if either (a) `aiwatch.exe` is missing or (b) the last successful scan is older than 30 min, which triggers `remediate.ps1`.

### 3. Verify

On a test device after sync:

```powershell
# MSI landed and wrote registry?
Get-ItemProperty "HKLM:\Software\Runlayer\AIWatch"

# Manual scan from user session
& "C:\Program Files\Runlayer\AIWatch\aiwatch.exe" scan

# Compliance marker written?
Get-Content "$env:LOCALAPPDATA\Runlayer\last_scan"

# Remediation logs
# Intune → Devices → [device] → Remediation status
```

### 4. Update tenant config later

- Change host / rotate org API key: uninstall + reinstall the Win32 app with new install command, OR push a small remediation that rewrites `HKLM\Software\Runlayer\AIWatch`. Since these values are MSI public properties, the simplest flow is re-deploy the MSI with updated `AIWATCH_HOST` / `AIWATCH_ORG_API_KEY`.
- Change schedule: edit the Remediation script package schedule in Intune. No reinstall.

### 5. Uninstall

Unscope the Win32 app and Remediation assignments. Intune issues `msiexec /x` on next check-in, which removes the binary and the registry key (MSI owns both).

## Other MDMs

The four artifacts (`.pkg` + 3 `.mobileconfig` files) deploy the same way on other MDMs. The LaunchAgent ships inside the `.pkg` everywhere — no MDM has to manage it directly. See the [parameterization matrix](#parameterization-support-by-mdm) to pick the right tenant-config artifact for your MDM.

### Jamf Pro (parameterized — no file editing)

Jamf Pro's **Application & Custom Settings** payload accepts a JSON Schema that generates a fill-in form. Admins type tenant values into the Jamf UI; Jamf writes managed preferences — no XML editing needed.

1. **Install the `.pkg`**: Jamf → **Computers → Policies → Packages** — upload both arch `.pkg` files, scope via Smart Group.
2. **Upload PPPC + Login Items profiles**: Jamf → **Configuration Profiles → Upload** — upload `com.runlayer.aiwatch.pppc.mobileconfig` and `com.runlayer.aiwatch.loginitems.mobileconfig` as-is (edit Login Items for `REPLACE_WITH_TEAM_ID` per [§4](#4-pre-approve-the-launchagent-login-items-profile)).
3. **Create the tenant-config profile via JSON Schema**:
   1. Jamf → **Configuration Profiles → New → Application & Custom Settings → External Applications → Add → Custom Schema**.
   2. **Preference Domain**: `com.runlayer.aiwatch`.
   3. Paste the contents of `packaging/macos/com.runlayer.aiwatch.jamf.schema.json` into the schema source field.
   4. Fill in **Tenant Host** (e.g. `https://tenant.runlayer.com`) and **Org API Key** (the `rl_org_...` secret).
   5. Scope to the same Smart Group.
4. Devices receive managed preferences at `/Library/Managed Preferences/com.runlayer.aiwatch.plist` — identical to the `.mobileconfig` flow.

### Workspace ONE (parameterized — no file editing)

Workspace ONE substitutes Custom Attribute lookup tokens inside uploaded profiles at deploy time.

1. **Define two Custom Attributes** (one-time per Organization Group):
   - Devices → Provisioning → Custom Attributes → **Add**.
   - `CustomAttribute1` → set value to the tenant host URL (e.g. `https://tenant.runlayer.com`).
   - `CustomAttribute2` → set value to the org API key secret (`rl_org_...`).
2. **Upload the `.pkg`**: Apps & Books → Internal → Add Application.
3. **Upload PPPC + Login Items profiles**: Devices → Profiles → Add → Upload — `com.runlayer.aiwatch.pppc.mobileconfig` and `com.runlayer.aiwatch.loginitems.mobileconfig` (edit Login Items for `REPLACE_WITH_TEAM_ID`).
4. **Upload the WS1 tenant-config profile**: Devices → Profiles → Add → Upload — use `packaging/macos/com.runlayer.aiwatch.config.ws1.mobileconfig` as-is (no editing). WS1 replaces `{CustomAttribute1}` and `{CustomAttribute2}` with the values defined in step 1 at deploy time.
5. Assign all to the same Smart Group / Organization Group.

To rotate values later: update the Custom Attribute values in the WS1 console and re-publish the profile. No file editing, no `.pkg` reinstall.

### Mosyle / Jamf Now / Intune macOS (find-and-replace)

These MDMs do not support admin-defined tenant variables in custom profiles:

- **Intune macOS**: only device-scoped tokens like `{{serialnumber}}` — no way to inject admin-typed tenant values.
- **Mosyle**: custom device attributes exist but require a companion script per tenant (worse UX than find-and-replace).
- **Jamf Now**: no Custom Settings payload at all — only basic profile types are available.

For all three, use the base `com.runlayer.aiwatch.config.mobileconfig` with manual find-and-replace:

1. Open `packaging/macos/com.runlayer.aiwatch.config.mobileconfig` and replace `REPLACE_WITH_TENANT_HOST` and `REPLACE_WITH_ORG_API_KEY` with your tenant values.
2. Upload the edited file as a Custom Profile alongside PPPC and Login Items profiles.
3. Deploy the `.pkg` via Custom App / LOB App.

### Iru (Kandji) — current flow

The [macOS (Kandji)](#macos-kandji) section above covers the full Kandji/Iru deployment. The current flow uses find-and-replace on `com.runlayer.aiwatch.config.mobileconfig`.

> **Note:** Iru (formerly Kandji) may support Blueprint-level parameters for Custom Profiles natively. If confirmed, a parameterized variant will be shipped in a follow-up — eliminating the need for manual XML editing on this MDM.

## Troubleshooting

### macOS

| Symptom                                          | Likely cause / check                                                                 |
| ------------------------------------------------ | ------------------------------------------------------------------------------------ |
| `aiwatch: host not configured`                   | Configuration Profile not yet synced. `defaults read /Library/Managed\ Preferences/com.runlayer.aiwatch.plist`. |
| Nothing in `/tmp/aiwatch.out` ever               | Launch Agent not loaded. `launchctl print gui/$(id -u)/com.runlayer.aiwatch`.         |
| `aiwatch` runs but no user scans appear          | Running as root, not console user. LaunchAgent (gui/<uid>) is required, not LaunchDaemon. |
| Users see "Background Item Added" notification on first login post-install (macOS 13+) | Login Items profile not yet applied or `REPLACE_WITH_TEAM_ID` not edited. `sfltool dumpbtm \| grep -i runlayer` should show the agent as `Disposition: enabled allowed visible` after the profile syncs. |
| Binary blocked by Gatekeeper                     | `.pkg` not signed + notarized yet. See `README.md` → Signing.                        |
| Scan completes but reports 0 project configs on a dev Mac with obvious projects under `~/Documents` | PPPC profile not applied (or binary unsigned so CodeRequirement fails). Check `log show --predicate 'subsystem == "com.apple.TCC"' --last 10m \| grep aiwatch` for `Prompting policy ... Deny` lines. Verify `codesign -dr - /usr/local/lib/aiwatch/aiwatch` shows `identifier "com.runlayer.aiwatch"`, and that the device is UAMDM-enrolled. |

### Windows

| Symptom                                          | Likely cause / check                                                                 |
| ------------------------------------------------ | ------------------------------------------------------------------------------------ |
| `aiwatch.exe: host not configured`               | MSI installed before tenant props were set. Re-run the Win32 app install command. |
| MSI install fails: `AIWATCH_HOST property is required` or `AIWATCH_ORG_API_KEY property is required` | Install command missing one of the required public properties. Both are mandatory — the installer refuses to write a half-configured registry entry. Re-run with both set. |
| Remediation reports compliant but no data in Runlayer | Scan running as SYSTEM instead of logged-on user — check "Run as logged-on credentials = Yes". |
| Detection always non-compliant                   | User profile has no `%LOCALAPPDATA%\Runlayer\last_scan` yet; give one remediation cycle. |
| SmartScreen warns on install                     | `.msi` not signed yet. See `README.md` → Signing.                                    |

## Upgrade path

- **macOS**: push the new `.pkg` version via Kandji Custom App. The `pkgbuild` receipt (`com.runlayer.aiwatch`) tracks every file in `/usr/local/lib/aiwatch/`, the `/usr/local/bin/aiwatch` symlink, and `/Library/LaunchAgents/com.runlayer.aiwatch.plist`; `installer` removes any files in the old receipt not present in the new payload and lays down the new tree atomically per-file. Mid-scan upgrades are safe — macOS lets you unlink an open file; the running `aiwatch` keeps its mapped `.dylib` pages until the next LaunchAgent tick picks up the new version. The postinstall script re-bootstraps the LaunchAgent so config changes (e.g. updated default `StartInterval`) take effect immediately. The three Configuration Profiles are unchanged. **Caveat**: if you've overridden `StartInterval` via Custom Script ([§5](#5-customize-scan-schedule-optional)), the upgrade resets it to the bundled default — your override script needs to run on a recurring schedule or be re-applied after each upgrade.
- **Windows**: bump the Win32 app in Intune with the new `.intunewin`. The MSI's `MajorUpgrade` sequences `RemoveExistingProducts` before `InstallFinalize`: it uninstalls the old product's whole `C:\Program Files\Runlayer\AIWatch\` tree then installs the new one. `HKLM\Software\Runlayer\AIWatch` registry values survive because they're owned by a separate component keyed on a registry value, not a file.

Both upgrades preserve tenant config — no re-profiling needed unless `Host` / `OrgApiKey` changed.
