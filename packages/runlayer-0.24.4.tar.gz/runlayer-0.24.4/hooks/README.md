# Runlayer Client Hooks

Single unified shell script injected into AI coding clients (Cursor, Claude Code, Codex) to enforce MCP security policy and forward telemetry events.

Installed via `runlayer setup hooks --install`. The setup command copies `runlayer-hook.sh` into the client's config directory, wires it into the client's hook registration file, and installs ignore-file patterns.

## Script

`runlayer-hook.sh` — auto-detects the calling client via environment variables:
- **Cursor**: `CURSOR_VERSION` env var present
- **Codex**: hook installed under `~/.codex/` or `/etc/codex/`
- **Claude Code**: fallback client when neither Cursor nor Codex markers are present

Adapts input parsing, event name normalization, and response format based on the detected client.

### Third-party hook guard

Cursor loads hooks from `~/.claude/settings.json` by default. When both Cursor and Claude Code hooks are installed, Cursor would fire both — causing double enforcement and event forwarding. The script guards against this by checking `dirname "$0"`: if the client is Cursor but the script path does not contain `cursor` (case-insensitive), it outputs `{"permission":"allow"}` and exits immediately. This ensures only the hook installed specifically for Cursor runs.

### Migration from old per-client scripts

Previous versions shipped separate `runlayer-cursor-hook.sh` and `runlayer-claude-hook.sh` scripts. The installer now cleans up these old files during `--install` and replaces them with the unified `runlayer-hook.sh`.

## Runtime config

A sibling `runlayer-config.json` is written next to the script at install time:

```json
{"enforcement": true}
```

When `enforcement` is `false`, the script skips all blocking checks and only forwards events (monitoring-only mode).

## Credentials

The script reads `~/.runlayer/config.yaml` (written by `runlayer login`) to resolve:

- `RUNLAYER_API_HOST` — from `default_host`
- `RUNLAYER_API_KEY` — from the `secret` field matching the host

If credentials are missing, enforcement hooks deny with a fail-closed message; observational hooks silently exit.

## Event flow

### Event name normalization

Cursor uses camelCase event names; Claude Code uses PascalCase. The script normalizes all names to PascalCase for internal dispatch:

| Cursor (camelCase)    | Normalized (PascalCase) |
|-----------------------|-------------------------|
| `preToolUse`          | `PreToolUse`            |
| `postToolUse`         | `PostToolUse`           |
| `postToolUseFailure`  | `PostToolUseFailure`    |
| `stop`                | `Stop`                  |
| `sessionStart`        | `SessionStart`          |
| `sessionEnd`          | `SessionEnd`            |
| `subagentStart`       | `SubagentStart`         |
| `subagentStop`        | `SubagentStop`          |
| `beforeSubmitPrompt`  | `UserPromptSubmit`      |
| `preCompact`          | `PreCompact`            |

### Enforcement events (blocking)

**MCP tool calls:**
- Cursor `beforeMCPExecution`: input carries `url`/`command` directly → POST to `/api/v1/hooks/cursor`
- Claude Code `PreToolUse` with `mcp__*` prefix: uses `_lookup_mcp_server` to resolve server identity → POST to `/api/v1/hooks/cursor`

Return `allow` or `deny` based on response. Fail-closed: any error → deny.

**File reads** (`beforeReadFile` / `PreToolUse` with `Read` tool):

Local-only pattern matching blocks access to:
- `.env`, `.env.*`, `*.env`, `.envrc`
- `mcp.json`, `.mcp.json`, `mcp_config.json`, `mcp-config.json`, `mcp.yaml`, `mcp.yml`
- `.claude.json`, `claude_desktop_config.json`
- `~/.claude/settings.json` (path-scoped — other `settings.json` files are allowed)

No API call — pure filename matching.

**Shell commands** (`PreToolUse` with `Bash` tool / Cursor `beforeShellExecution`):

Scans the command string for references to the same protected file patterns above. Catches bypass attempts like `cat .env`, `head -n 10 .env.production`, `cat .mcp.json | jq .`, etc. Words starting with `-` and numeric arguments are skipped to avoid false positives with command flags.

### Observational events (fire-and-forget)

All other events are forwarded as best-effort background POSTs to `/api/v1/hooks/events`:

```json
{"client": "cursor|claude_code|codex", "event_name": "...", "payload": <raw_input>}
```

**Stop events** additionally attach the last 512 KB of the transcript file when available.

## MCP server lookup (Claude Code only)

Claude Code names MCP tools as `mcp__<server>__<tool>`. The hook strips the prefix to extract the server name, then resolves it to a URL or command. Cursor doesn't need this — `beforeMCPExecution` already carries the server URL.

The lookup walks Claude Code's config file hierarchy in priority order:

1. `${cwd}/.mcp.json` → `mcpServers[name]` — project-scoped
2. `~/.claude.json` → `projects[cwd].mcpServers[name]` — per-project in user state
3. `~/.claude.json` → `mcpServers[name]` — global user-scoped

First match wins. For each file, the function checks for a `url` field (remote/streamable-HTTP server) or a `command` + `args` pair (stdio server). The result is included in the enforcement request to `/api/v1/hooks/cursor`.

If no config file contains the server name, the hook denies the call — an unknown server can't be verified.

## Deny response format

**Cursor:**
```json
{"permission": "deny", "continue": true, "user_message": "...", "agentMessage": "..."}
```

**Claude Code:**
```json
{"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "deny", "permissionDecisionReason": "..."}}
```

**Codex `PreToolUse`:**
```json
{"decision": "block", "reason": "..."}
```

**Codex `PermissionRequest`:**
```json
{"hookSpecificOutput": {"hookEventName": "PermissionRequest", "decision": {"behavior": "deny", "message": "..."}}}
```

## Ignore files

The installer creates `~/.cursorignore` and `~/.claudeignore` (non-MDM, enforcement mode only) with managed patterns matching the same sensitive files the hook protects. Patterns are wrapped in `# >>> Runlayer managed` markers for idempotent updates. Uninstall removes the managed block.

## Installation modes

| Flag | Behavior |
|---|---|
| (default) | Enforcement hooks only. Pipeline hooks auto-enabled if workspace client hook APIs are enabled. |
| `--all-events` | Enforcement + all pipeline/observational hooks |
| `--no-enforcement` | All hooks registered but enforcement skipped (monitoring only) |
| `--mdm` | Enterprise install location requiring elevated privileges. Cursor: `hooks.json` in `/Library/Application Support/Cursor` (macOS), `/etc/cursor` (Linux), `C:\ProgramData\Cursor` (Windows). Claude Code: `managed-settings.json` in `/Library/Application Support/ClaudeCode` (macOS), `/etc/claude-code` (Linux), `C:\Program Files\ClaudeCode` (Windows). Codex: `hooks.json` plus `managed_config.toml` in `/etc/codex` on macOS/Linux. MDM install migrates existing user-level hooks to the enterprise location where supported. |

### Registered hook events

**Cursor enforcement:** `beforeMCPExecution`, `beforeReadFile`, `beforeShellExecution`

**Cursor pipeline:** `sessionStart`, `sessionEnd`, `beforeSubmitPrompt`, `afterAgentThought`, `afterAgentResponse`, `afterMCPExecution`, `afterShellExecution`, `preToolUse`, `postToolUse`, `postToolUseFailure`, `subagentStart`, `subagentStop`, `afterFileEdit`, `stop`, `preCompact`

**Claude Code enforcement:** `PreToolUse`

**Claude Code pipeline:** `SessionStart`, `SessionEnd`, `UserPromptSubmit`, `PreToolUse`, `PostToolUse`, `PostToolUseFailure`, `SubagentStart`, `SubagentStop`, `Stop`, `PreCompact`, `PermissionRequest`, `Notification`, `TeammateIdle`, `TaskCompleted`, `InstructionsLoaded`, `ConfigChange`, `WorktreeCreate`, `WorktreeRemove`

**Codex enforcement (limited):** `PreToolUse` (Bash only), `PermissionRequest` (Bash only)

**Codex pipeline (limited):** `SessionStart`, `PostToolUse` (Bash only), `UserPromptSubmit`, `Stop`

## Dependencies

The script requires `jq` and either `runlayer` or `uvx` on `$PATH`.
