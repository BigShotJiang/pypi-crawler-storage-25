from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "DM" / "test.py"
test = SourceCodeModule("bm_preprocessing.DM.test", _source_file)
