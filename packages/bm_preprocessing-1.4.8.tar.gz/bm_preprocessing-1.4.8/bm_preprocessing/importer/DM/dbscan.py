from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "DM" / "dbscan.py"
dbscan = SourceCodeModule("bm_preprocessing.DM.dbscan", _source_file)
