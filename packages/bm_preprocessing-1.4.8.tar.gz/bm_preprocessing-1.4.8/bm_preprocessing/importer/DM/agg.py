from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "DM" / "agg.py"
agg = SourceCodeModule("bm_preprocessing.DM.agg", _source_file)
