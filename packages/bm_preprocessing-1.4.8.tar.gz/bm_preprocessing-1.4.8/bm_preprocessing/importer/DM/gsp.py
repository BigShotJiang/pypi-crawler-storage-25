from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "DM" / "gsp.py"
gsp = SourceCodeModule("bm_preprocessing.DM.gsp", _source_file)
