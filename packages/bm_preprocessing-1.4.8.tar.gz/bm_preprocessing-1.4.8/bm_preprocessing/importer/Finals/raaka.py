from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "Finals" / "raaka.py"
agg = SourceCodeModule("bm_preprocessing.Finals.raaka", _source_file)
