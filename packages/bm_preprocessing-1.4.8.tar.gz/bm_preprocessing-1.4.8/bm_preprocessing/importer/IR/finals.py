from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "IR" / "finals.py"
finals = SourceCodeModule("bm_preprocessing.IR.finals", _source_file)
