from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "IR" / "pagerank.py"
pagerank = SourceCodeModule("bm_preprocessing.IR.pagerank", _source_file)
