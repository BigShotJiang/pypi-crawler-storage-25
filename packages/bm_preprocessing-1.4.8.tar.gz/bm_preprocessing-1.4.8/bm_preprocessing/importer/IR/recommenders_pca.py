from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "IR" / "recommenders_pca.py"
recommenders_pca = SourceCodeModule(
    "bm_preprocessing.IR.recommenders_pca", _source_file
)
