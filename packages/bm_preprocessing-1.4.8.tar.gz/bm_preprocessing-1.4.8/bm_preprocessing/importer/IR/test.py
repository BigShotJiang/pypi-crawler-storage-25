from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "IR" / "test.py"
test = SourceCodeModule("bm_preprocessing.IR.test", _source_file)
