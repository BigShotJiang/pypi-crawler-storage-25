from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "PY" / "lib_doc.py"
lib_doc = SourceCodeModule("bm_preprocessing.PY.lib_doc", _source_file)
