from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "PY" / "python_doc.py"
python_doc = SourceCodeModule("bm_preprocessing.PY.python_doc", _source_file)
