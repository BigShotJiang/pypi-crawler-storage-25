from .lib_doc import lib_doc
from .python_doc import python_doc

__all__ = ["lib_doc", "python_doc"]
