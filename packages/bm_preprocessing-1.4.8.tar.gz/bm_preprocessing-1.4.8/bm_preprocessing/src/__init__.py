"""Raw source snippets shipped with the package."""
