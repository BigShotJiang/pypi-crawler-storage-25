"""Data-mining quick reference.

Printing bm_preprocessing.DM.dm_doc displays this source file.
"""

from pandas import DataFrame, display

df = DataFrame()  # Placeholder for type hinting

df = {
    "col1": [1, 2, 3],
    "col2": ["a", "b", "c"],
}

df["col1"].mean()

print(df["col2"].unique())

display(df.head())
