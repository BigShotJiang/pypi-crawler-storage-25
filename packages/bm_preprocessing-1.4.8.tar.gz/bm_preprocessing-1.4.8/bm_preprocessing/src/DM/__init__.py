"""Data-mining source snippets."""
