"IR source snippets."

import pandas as pd

# Dimensionality reduction source snippets

df = pd.DataFrame(
    {
        "A": [1, 2, 3],
        "B": [4, 5, 6],
        "C": [7, 8, 9],
    }
)
print(df)
