"""IR source snippets."""
