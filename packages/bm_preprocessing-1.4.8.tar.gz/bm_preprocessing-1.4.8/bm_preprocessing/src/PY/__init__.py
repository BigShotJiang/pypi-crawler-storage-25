"""Python-related source snippets."""
