"""Finals source snippets."""
