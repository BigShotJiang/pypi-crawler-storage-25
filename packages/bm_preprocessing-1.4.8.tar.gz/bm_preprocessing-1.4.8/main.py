def main():
    print("Hello from bm-preprocessing!")


if __name__ == "__main__":
    main()
