# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Copyright (c) 2025-2026 Dmitrii Gagarin aka madgagarin


from typing import Any

from .base import HistoryStorageBase


class NoOpHistoryStorage(HistoryStorageBase):
    """A "null" implementation of the history store that performs no actions.
    Used when history storage is not configured.
    """

    def __init__(self) -> None:
        super().__init__()

    async def start(self) -> None:
        pass

    async def close(self) -> None:
        pass

    async def initialize(self) -> None:
        pass

    async def log_job_event(self, event_data: dict[str, Any]) -> None:
        pass

    async def log_worker_event(self, event_data: dict[str, Any]) -> None:
        pass

    async def _persist_job_event(self, event_data: dict[str, Any]) -> None:
        pass

    async def _persist_worker_event(self, event_data: dict[str, Any]) -> None:
        pass

    async def get_job_history(self, job_id: str) -> list[dict[str, Any]]:
        return []

    async def get_jobs(self, limit: int = 100, offset: int = 0) -> list[dict[str, Any]]:
        return []

    async def get_job_summary(self) -> dict[str, int]:
        return {}

    async def get_worker_history(
        self,
        worker_id: str,
        since_days: int,
    ) -> list[dict[str, Any]]:
        return []
