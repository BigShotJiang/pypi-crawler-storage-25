"""Tests for PredictQueue."""
import asyncio
import pytest
import numpy as np


@pytest.fixture
def queue():
    from JwzTumor.server.queue import PredictQueue
    return PredictQueue(max_size=4)


def test_queue_initial_state(queue):
    assert queue.depth == 0
    assert queue.max_size == 4
    assert not queue.is_full


def test_queue_submit_success(queue):
    image = np.random.rand(32, 32).astype(np.float32)
    task_id = queue.submit(image, "single")
    assert task_id is not None
    assert len(task_id) > 0
    assert queue.depth == 1


def test_queue_submit_full(queue):
    from JwzTumor.server.queue import QueueFullError
    for i in range(4):
        queue.submit(np.zeros((8, 8), dtype=np.float32), "single")
    with pytest.raises(QueueFullError):
        queue.submit(np.zeros((8, 8), dtype=np.float32), "single")


def test_queue_submit_lr(queue):
    left = np.random.rand(32, 32).astype(np.float32)
    right = np.random.rand(32, 32).astype(np.float32)
    task_id = queue.submit_lr(left, right)
    assert task_id is not None
    assert queue.depth == 1


def test_queue_get_task(queue):
    image = np.random.rand(16, 16).astype(np.float32)
    task_id = queue.submit(image, "single")
    task = queue.get_task(task_id)
    assert task is not None
    assert task["task_id"] == task_id
    assert task["mode"] == "single"


def test_queue_get_nonexistent_task(queue):
    assert queue.get_task("nope") is None


def test_queue_complete_releases_memory(queue):
    image = np.random.rand(64, 64).astype(np.float32)
    task_id = queue.submit(image, "single")
    task = queue.get_task(task_id)
    assert task["image"] is not None
    queue.complete_task(task_id, result={"label": "benign"})
    task2 = queue.get_task(task_id)
    assert task2["image"] is None  # released
    assert task2["result"] is not None
