"""Tests for rule-based report composition."""

from JwzTumor.server.report.rules import compose_rule_report
from JwzTumor.server.report.schemas import CaseInfo, ReportRequest


def test_rule_report_locks_model_facts():
    req = ReportRequest(
        mode="single",
        report_mode="rule",
        case_info=CaseInfo(
            exam_id="E1",
            age=45,
            sex="female",
            exam_part="breast",
            side="left",
        ),
        ultrasound_fields={"shape": "椭圆形"},
        inference_result={
            "label": "benign",
            "label_index": 0,
            "prob_malignant": 0.12,
            "prob_benign": 0.88,
            "processing_time_ms": 100,
        },
    )
    report = compose_rule_report(req)
    assert report.locked_facts["inference_result"]["prob_malignant"] == 0.12
    assert "临床辅助诊断" in report.sections.disclaimer
