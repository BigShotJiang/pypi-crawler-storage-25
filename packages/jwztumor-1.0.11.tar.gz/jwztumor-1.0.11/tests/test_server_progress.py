"""Tests for SSE progress event emitter."""
import asyncio
import json
import pytest


def test_progress_callback_stages():
    from JwzTumor.server.progress import ProgressCallback
    cb = ProgressCallback(stages=["preprocessing", "inference", "postprocessing"])
    assert cb.stages == ["preprocessing", "inference", "postprocessing"]


def test_progress_callback_emit():
    from JwzTumor.server.progress import ProgressCallback
    events = []
    cb = ProgressCallback(
        stages=["preprocessing", "inference", "postprocessing"],
        on_event=lambda e: events.append(e),
    )
    cb.emit("preprocessing", 0.3, "Preprocessing image...")
    assert len(events) == 1
    assert events[0].event == "progress"
    assert events[0].data["stage"] == "preprocessing"
    assert events[0].data["progress"] == pytest.approx(0.3)


def test_progress_callback_no_handler():
    """emit() without on_event should not raise."""
    from JwzTumor.server.progress import ProgressCallback
    cb = ProgressCallback(stages=["preprocessing"])
    cb.emit("preprocessing", 0.5, "ok")  # should not raise


def test_sse_encode_event():
    from JwzTumor.server.progress import ProgressCallback
    events = []
    cb = ProgressCallback(
        stages=["preprocessing"],
        on_event=lambda e: events.append(e),
    )
    cb.emit("preprocessing", 0.5, "test")
    encoded = events[0].encode()
    assert encoded.startswith("event: progress\n")
    assert '"stage": "preprocessing"' in encoded
    assert encoded.endswith("\n\n")
