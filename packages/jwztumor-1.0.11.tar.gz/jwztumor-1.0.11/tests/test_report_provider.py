"""Tests for report LLM providers."""

import asyncio
import json
from unittest.mock import patch

from JwzTumor.server.report.providers import (
    DisabledProvider,
    MockProvider,
    OpenAICompatibleProvider,
    ReportLLMMessage,
    create_provider_from_env,
)


def test_mock_provider_returns_json_text():
    async def _run():
        provider = MockProvider(response='{"summary":"ok"}')
        text = await provider.complete(messages=[{"role": "user", "content": "hello"}])
        assert text == '{"summary":"ok"}'

    asyncio.run(_run())


def test_create_provider_from_env_returns_disabled_without_required_values():
    provider = create_provider_from_env({})
    assert isinstance(provider, DisabledProvider)


def test_create_provider_from_env_builds_openai_compatible_provider():
    provider = create_provider_from_env(
        {
            "JWZT_REPORT_LLM_ENABLED": "true",
            "JWZT_REPORT_LLM_BASE_URL": "https://llm.example.com/v1/",
            "JWZT_REPORT_LLM_API_KEY": "test-key",
            "JWZT_REPORT_LLM_MODEL": "gpt-4.1-mini",
            "JWZT_REPORT_LLM_TIMEOUT": "45",
            "JWZT_REPORT_LLM_MAX_RETRIES": "4",
            "JWZT_REPORT_LLM_TEMPERATURE": "0.35",
            "JWZT_REPORT_LLM_MAX_TOKENS": "1600",
            "JWZT_REPORT_LLM_MULTIMODAL_ENABLED": "true",
            "JWZT_REPORT_LLM_STARTUP_CHECK": "true",
            "JWZT_REPORT_LLM_IMAGE_INPUT_MODE": "public_url",
            "JWZT_REPORT_LLM_PUBLIC_BASE_URL": "https://jwzt.example.com",
            "JWZT_REPORT_LLM_STARTUP_IMAGE_URL": "https://img.example.com/probe.png",
            "JWZT_REPORT_LLM_THINKING_DISABLE_PARAM": '{"enable_thinking": false}',
            "JWZT_REPORT_LLM_EXTRA_BODY": '{"response_format": {"type": "json_object"}}',
        }
    )
    assert isinstance(provider, OpenAICompatibleProvider)
    assert provider.base_url == "https://llm.example.com/v1"
    assert provider.api_key == "test-key"
    assert provider.model == "gpt-4.1-mini"
    assert provider.timeout == 45.0
    assert provider.max_retries == 4
    assert provider.temperature == 0.35
    assert provider.max_tokens == 1600
    assert provider.multimodal_enabled is True
    assert provider.startup_check is True
    assert provider.image_input_mode == "public_url"
    assert provider.public_base_url == "https://jwzt.example.com"
    assert provider.startup_image_url == "https://img.example.com/probe.png"
    assert provider.thinking_disable_param == {"enable_thinking": False}
    assert provider.extra_body == {"response_format": {"type": "json_object"}}


def test_provider_complete_merges_request_payload_fields():
    payloads: list[dict] = []

    class FakeResponse:
        status_code = 200
        text = ""

        @staticmethod
        def json():
            return {"choices": [{"message": {"content": '{"image_findings":"ok","assessment":"ok","recommendations":"ok"}'}}]}

    class FakeClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return None

        async def post(self, url, headers, json):
            payloads.append(json)
            return FakeResponse()

    async def _run():
        provider = OpenAICompatibleProvider(
            base_url="https://llm.example.com/v1",
            api_key="test-key",
            model="vision-model",
            max_tokens=1600,
            multimodal_enabled=True,
            startup_check=True,
            thinking_disable_param={"enable_thinking": False},
            extra_body={"response_format": {"type": "json_object"}},
        )
        messages: list[ReportLLMMessage] = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "hello"},
                    {
                        "type": "image_url",
                        "image_url": {"url": "data:image/png;base64,abc"},
                    },
                ],
            }
        ]
        with patch("httpx.AsyncClient", FakeClient):
            await provider.complete(messages)

    asyncio.run(_run())

    assert len(payloads) == 1
    payload = payloads[0]
    assert payload["model"] == "vision-model"
    assert payload["max_tokens"] == 1600
    assert payload["enable_thinking"] is False
    assert payload["response_format"] == {"type": "json_object"}
    assert payload["messages"][0]["content"][1]["type"] == "image_url"


def test_provider_startup_check_runs_text_and_multimodal_probes():
    payloads: list[dict] = []

    class FakeImageResponse:
        status_code = 200
        text = ""
        headers = {"content-type": "image/jpeg"}
        content = b"fake-jpeg-bytes"

        def raise_for_status(self):
            return None

    class FakeResponse:
        status_code = 200
        text = ""

        @staticmethod
        def json():
            return {"choices": [{"message": {"content": '{"image_findings":"ok","assessment":"ok","recommendations":"ok"}'}}]}

    class FakeClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return None

        async def post(self, url, headers, json):
            payloads.append(json)
            return FakeResponse()

        async def get(self, url):
            return FakeImageResponse()

    async def _run():
        provider = OpenAICompatibleProvider(
            base_url="https://llm.example.com/v1",
            api_key="test-key",
            model="vision-model",
            max_tokens=1600,
            multimodal_enabled=True,
            startup_check=True,
            thinking_disable_param={"enable_thinking": False},
            extra_body={"response_format": {"type": "json_object"}},
        )
        with patch("httpx.AsyncClient", FakeClient):
            await provider.check_startup()

    asyncio.run(_run())

    assert len(payloads) == 2
    assert isinstance(payloads[0]["messages"][0]["content"], str)
    assert isinstance(payloads[1]["messages"][0]["content"], list)
    assert payloads[1]["messages"][0]["content"][1]["type"] == "image_url"
    assert payloads[1]["messages"][0]["content"][1]["image_url"]["url"].startswith(
        "data:image/jpeg;base64,"
    )


def test_provider_startup_check_uses_public_image_url_mode():
    payloads: list[dict] = []

    class FakeResponse:
        status_code = 200
        text = ""

        @staticmethod
        def json():
            return {"choices": [{"message": {"content": '{"image_findings":"ok","assessment":"ok","recommendations":"ok"}'}}]}

    class FakeClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return None

        async def post(self, url, headers, json):
            payloads.append(json)
            return FakeResponse()

    async def _run():
        provider = OpenAICompatibleProvider(
            base_url="https://llm.example.com/v1",
            api_key="test-key",
            model="vision-model",
            max_tokens=1600,
            multimodal_enabled=True,
            startup_check=True,
            image_input_mode="public_url",
            public_base_url="https://jwzt.example.com/",
            startup_image_url="https://img.example.com/probe.png",
            thinking_disable_param={"enable_thinking": False},
        )
        with patch("httpx.AsyncClient", FakeClient):
            await provider.check_startup()

    asyncio.run(_run())

    image_content = payloads[1]["messages"][0]["content"]
    assert image_content[1]["image_url"]["url"] == "https://img.example.com/probe.png"


def test_provider_startup_check_raises_on_probe_failure():
    class FakeResponse:
        status_code = 400
        text = "unsupported parameter"

        @staticmethod
        def json():
            return {"error": "unsupported"}

    class FakeClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return None

        async def post(self, url, headers, json):
            return FakeResponse()

    async def _run():
        provider = OpenAICompatibleProvider(
            base_url="https://llm.example.com/v1",
            api_key="test-key",
            model="vision-model",
            max_tokens=1600,
            multimodal_enabled=True,
            startup_check=True,
            thinking_disable_param={"enable_thinking": False},
        )
        with patch("httpx.AsyncClient", FakeClient):
            try:
                await provider.check_startup()
            except RuntimeError as exc:
                assert "startup check failed" in str(exc).lower()
                return
        raise AssertionError("Expected startup check to fail")

    asyncio.run(_run())


def test_provider_complete_raises_clear_error_when_choices_missing():
    class FakeResponse:
        status_code = 200
        text = '{"choices": null}'

        @staticmethod
        def json():
            return {
                "id": "chatcmpl-test",
                "object": "",
                "created": 0,
                "model": "vision-model",
                "choices": None,
                "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
            }

    class FakeClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return None

        async def post(self, url, headers, json):
            return FakeResponse()

    async def _run():
        provider = OpenAICompatibleProvider(
            base_url="https://llm.example.com/v1",
            api_key="test-key",
            model="vision-model",
            max_tokens=1600,
            multimodal_enabled=True,
            startup_check=True,
            thinking_disable_param={"enable_thinking": False},
        )
        with patch("httpx.AsyncClient", FakeClient):
            try:
                await provider.complete(
                    [
                        {
                            "role": "user",
                            "content": [
                                {"type": "text", "text": "hello"},
                                {"type": "image_url", "image_url": {"url": "data:image/png;base64,abc"}},
                            ],
                        }
                    ]
                )
            except RuntimeError as exc:
                assert "no completion choices" in str(exc).lower()
                assert "public_url" in str(exc)
                return
        raise AssertionError("Expected clear validation error for missing choices")

    asyncio.run(_run())
