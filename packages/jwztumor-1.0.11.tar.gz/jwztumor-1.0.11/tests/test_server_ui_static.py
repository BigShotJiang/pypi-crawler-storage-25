"""Tests for static UI hosting."""

from pathlib import Path

from fastapi.testclient import TestClient

from JwzTumor.server.app import create_app
from JwzTumor.server.queue import PredictQueue


class DummyEngine:
    is_loaded = True
    device = "cpu"


def test_static_ui_index_served(tmp_path: Path):
    ui_dir = tmp_path / "ui"
    ui_dir.mkdir()
    (ui_dir / "index.html").write_text("<html>JWZT UI</html>", encoding="utf-8")
    app = create_app(engine=DummyEngine(), queue=PredictQueue(), ui_dir=str(ui_dir))
    client = TestClient(app)
    resp = client.get("/")
    assert resp.status_code == 200
    assert "JWZT UI" in resp.text


def test_static_ui_runtime_config_served(tmp_path: Path):
    ui_dir = tmp_path / "ui"
    ui_dir.mkdir()
    (ui_dir / "index.html").write_text("<html>JWZT UI</html>", encoding="utf-8")
    app = create_app(
        engine=DummyEngine(),
        queue=PredictQueue(),
        ui_dir=str(ui_dir),
        ui_api_base_url="https://api.example.com",
    )
    client = TestClient(app)
    resp = client.get("/config.js")
    assert resp.status_code == 200
    assert 'window.__JWZT_CONFIG__ = {"apiBaseUrl": "https://api.example.com"};' == resp.text
