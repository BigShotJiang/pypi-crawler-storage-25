"""Tests for jwzt server UI CLI options."""

from pathlib import Path

from typer.testing import CliRunner

from JwzTumor.cli.main import app
from JwzTumor.cli.server_cmd import _build_report_llm_env, _resolve_ui_api_base_url
from JwzTumor.utils.config import Config, ReportLLMConfig


def test_server_help_lists_ui_options():
    result = CliRunner().invoke(app, ["server", "--help"])
    assert result.exit_code == 0
    assert "--ui-port" in result.stdout
    assert "--ui-host" in result.stdout


def test_server_help_lists_report_llm_options():
    result = CliRunner().invoke(app, ["server", "--help"])
    assert result.exit_code == 0
    assert "报告 LLM Base URL" in result.stdout
    assert "报告 LLM API Key" in result.stdout
    assert "--report-llm-model" in result.stdout
    assert "启用/禁用报告 LLM" in result.stdout
    assert "最大输出" in result.stdout
    assert "关闭思考模式" in result.stdout
    assert "图片输入模式" in result.stdout
    assert "public_url" in result.stdout
    assert "模式下当前服务" in result.stdout


def test_same_port_ui_uses_same_origin_api_base_when_host_binds_all_interfaces():
    assert _resolve_ui_api_base_url(
        explicit_url=None,
        host="0.0.0.0",
        port=8000,
        same_port=True,
    ) == ""


def test_config_loads_server_and_report_llm_sections(tmp_path: Path):
    config_path = tmp_path / "server.yaml"
    config_path.write_text(
        """
server:
  host: 127.0.0.1
  port: 18080
  with_ui: true
  ui_api_base_url: https://api.example.com
report_llm:
  enabled: true
  base_url: https://llm.example.com/v1
  api_key: test-key
  model: report-model
  timeout: 45
  max_retries: 4
  temperature: 0.35
  max_tokens: 1200
  multimodal_enabled: true
  startup_check: true
  image_input_mode: public_url
  public_base_url: https://jwzt.example.com
  startup_image_url: https://img.example.com/probe.png
  thinking_disable_param:
    enable_thinking: false
  extra_body:
    response_format:
      type: json_object
""",
        encoding="utf-8",
    )

    cfg = Config(str(config_path))

    assert cfg.server.host == "127.0.0.1"
    assert cfg.server.port == 18080
    assert cfg.server.with_ui is True
    assert cfg.server.ui_api_base_url == "https://api.example.com"
    assert cfg.report_llm.base_url == "https://llm.example.com/v1"
    assert cfg.report_llm.api_key == "test-key"
    assert cfg.report_llm.model == "report-model"
    assert cfg.report_llm.timeout == 45
    assert cfg.report_llm.max_retries == 4
    assert cfg.report_llm.temperature == 0.35
    assert cfg.report_llm.enabled is True
    assert cfg.report_llm.max_tokens == 1200
    assert cfg.report_llm.multimodal_enabled is True
    assert cfg.report_llm.startup_check is True
    assert cfg.report_llm.image_input_mode == "public_url"
    assert cfg.report_llm.public_base_url == "https://jwzt.example.com"
    assert cfg.report_llm.startup_image_url == "https://img.example.com/probe.png"
    assert cfg.report_llm.thinking_disable_param == {"enable_thinking": False}
    assert cfg.report_llm.extra_body == {"response_format": {"type": "json_object"}}


def test_get_server_template_contains_server_and_report_llm_sections():
    result = CliRunner().invoke(app, ["get", "-t", "server"])

    assert result.exit_code == 0
    assert "server:" in result.stdout
    assert "report_llm:" in result.stdout
    assert "JWZT_REPORT_LLM_BASE_URL" in result.stdout
    assert "JWZT_REPORT_LLM_MAX_TOKENS" in result.stdout
    assert "JWZT_REPORT_LLM_IMAGE_INPUT_MODE" in result.stdout
    assert "JWZT_REPORT_LLM_PUBLIC_BASE_URL" in result.stdout
    assert "JWZT_REPORT_LLM_THINKING_DISABLE_PARAM" in result.stdout


def test_report_llm_env_merges_process_config_and_explicit_values(monkeypatch):
    monkeypatch.setenv("JWZT_REPORT_LLM_BASE_URL", "https://env.example.com/v1")
    config = ReportLLMConfig(
        enabled=True,
        base_url="https://config.example.com/v1",
        api_key="config-key",
        model="config-model",
        max_tokens=1000,
        multimodal_enabled=True,
        startup_check=True,
        image_input_mode="data_url",
        public_base_url="https://config-public.example.com",
        startup_image_url="https://config-img.example.com/probe.png",
        thinking_disable_param={"enable_thinking": False},
        extra_body={"top_p": 0.9},
    )

    values = _build_report_llm_env(
        config,
        enabled=None,
        base_url="https://cli.example.com/v1",
        api_key=None,
        model="cli-model",
        timeout=None,
        max_retries=5,
        temperature=None,
        max_tokens=1600,
        multimodal_enabled=False,
        startup_check=None,
        image_input_mode="public_url",
        public_base_url="https://cli-public.example.com",
        startup_image_url="https://cli-img.example.com/probe.png",
        thinking_disable_param='{"reasoning": {"enabled": false}}',
        extra_body='{"response_format": {"type": "json_object"}}',
    )

    assert values["JWZT_REPORT_LLM_BASE_URL"] == "https://cli.example.com/v1"
    assert values["JWZT_REPORT_LLM_API_KEY"] == "config-key"
    assert values["JWZT_REPORT_LLM_MODEL"] == "cli-model"
    assert values["JWZT_REPORT_LLM_MAX_RETRIES"] == "5"
    assert values["JWZT_REPORT_LLM_ENABLED"] == "True"
    assert values["JWZT_REPORT_LLM_MAX_TOKENS"] == "1600"
    assert values["JWZT_REPORT_LLM_MULTIMODAL_ENABLED"] == "False"
    assert values["JWZT_REPORT_LLM_STARTUP_CHECK"] == "True"
    assert values["JWZT_REPORT_LLM_IMAGE_INPUT_MODE"] == "public_url"
    assert values["JWZT_REPORT_LLM_PUBLIC_BASE_URL"] == "https://cli-public.example.com"
    assert values["JWZT_REPORT_LLM_STARTUP_IMAGE_URL"] == "https://cli-img.example.com/probe.png"
    assert values["JWZT_REPORT_LLM_THINKING_DISABLE_PARAM"] == '{"reasoning": {"enabled": false}}'
    assert values["JWZT_REPORT_LLM_EXTRA_BODY"] == '{"response_format": {"type": "json_object"}}'
