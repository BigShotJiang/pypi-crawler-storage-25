"""Integration tests for server API routes."""
import io
import base64
import pytest
import numpy as np
from PIL import Image
from unittest.mock import patch, MagicMock

from fastapi.testclient import TestClient


def _make_test_app():
    """Create a test app with random-weight model."""
    from JwzTumor.utils.config import Config
    from JwzTumor.server.engine import InferenceEngine
    from JwzTumor.server.queue import PredictQueue
    from JwzTumor.server.app import create_app

    config = Config()
    config.dataset.model_input_size = 64
    config.inference.threshold = 0.5
    config.inference.use_tta = False
    config.postprocess.threshold = 0.5
    config.postprocess.use_largest_component = False

    engine = InferenceEngine(config)
    engine.load_model_direct()
    queue = PredictQueue(max_size=4)
    app = create_app(engine, queue, max_upload_bytes=5 * 1024 * 1024)
    return app


@pytest.fixture(scope="module")
def client():
    app = _make_test_app()
    with TestClient(app) as c:
        yield c


def _make_png_bytes(h=32, w=32):
    img = Image.fromarray((np.random.rand(h, w) * 255).astype(np.uint8), mode="L")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return buf


def test_health_endpoint(client):
    resp = client.get("/api/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "healthy"
    assert data["model_loaded"] is True
    assert "device" in data


def test_predict_single_sync(client):
    png_buf = _make_png_bytes()
    resp = client.post("/api/predict", files={"file": ("test.png", png_buf, "image/png")})
    assert resp.status_code == 200
    data = resp.json()
    assert "label" in data
    assert data["label"] in ("benign", "malignant")
    assert "prob_malignant" in data
    assert "processing_time_ms" in data
    assert isinstance(data["processing_time_ms"], int)


def test_predict_invalid_file(client):
    resp = client.post(
        "/api/predict",
        files={"file": ("test.txt", b"not an image", "text/plain")},
    )
    assert resp.status_code == 422
    assert resp.json()["error"] == "invalid_image"


def test_predict_lr_sync(client):
    left_buf = _make_png_bytes()
    right_buf = _make_png_bytes()
    resp = client.post(
        "/api/predict/lr",
        files={
            "left": ("left.png", left_buf, "image/png"),
            "right": ("right.png", right_buf, "image/png"),
        },
    )
    assert resp.status_code == 200
    data = resp.json()
    assert "left" in data
    assert "right" in data
    assert "fused_label" in data
    assert "fused_prob_malignant" in data


def test_predict_async_submit(client):
    png_buf = _make_png_bytes()
    resp = client.post(
        "/api/predict?async=true",
        files={"file": ("test.png", png_buf, "image/png")},
    )
    assert resp.status_code == 200
    data = resp.json()
    assert "task_id" in data
    assert len(data["task_id"]) > 0


def test_predict_queue_full(client):
    """Fill the queue and verify 503 response.

    Waits for any prior tasks to drain, then fills the queue directly
    via the queue object so the background worker cannot drain tasks
    between HTTP calls, then submits one more request via the API
    and expects a 503.
    """
    import time
    from JwzTumor.server.app import get_app_state

    state = get_app_state()
    queue = state["queue"]
    max_size = queue.max_size

    # Wait for the queue to drain from prior tests
    for _ in range(40):
        if queue.depth == 0:
            break
        time.sleep(0.1)

    # Fill the queue directly (bypass the worker)
    for _ in range(max_size):
        dummy_image = np.zeros((32, 32), dtype=np.float32)
        queue.submit(dummy_image, mode="single")

    assert queue.is_full

    # Now an API request should get 503
    png_buf = _make_png_bytes()
    resp = client.post(
        "/api/predict?async=true",
        files={"file": ("test.png", png_buf, "image/png")},
    )
    assert resp.status_code == 503

    # Clean up: let the worker drain the tasks
    time.sleep(3)


def test_docs_endpoint(client):
    resp = client.get("/docs")
    assert resp.status_code == 200
