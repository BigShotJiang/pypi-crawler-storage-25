"""Tests for report API routes."""

from fastapi.testclient import TestClient

from JwzTumor.server.app import create_app
from JwzTumor.server.queue import PredictQueue
from JwzTumor.server.report.providers import MockProvider, OpenAICompatibleProvider
from JwzTumor.server.report.service import ReportService


class DummyEngine:
    is_loaded = True
    device = "cpu"


def test_report_route_rule_mode():
    app = create_app(engine=DummyEngine(), queue=PredictQueue())
    client = TestClient(app)
    resp = client.post(
        "/api/report",
        json={
            "mode": "single",
            "report_mode": "rule",
            "case_info": {
                "exam_id": "E1",
                "age": 45,
                "sex": "female",
                "exam_part": "breast",
                "side": "left",
            },
            "ultrasound_fields": {"shape": "椭圆形"},
            "inference_result": {
                "label": "benign",
                "label_index": 0,
                "prob_malignant": 0.12,
                "prob_benign": 0.88,
                "processing_time_ms": 100,
            },
        },
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["sections"]["assessment"]
    assert data["locked_facts"]["inference_result"]["prob_malignant"] == 0.12


def test_create_app_builds_report_provider_from_env(monkeypatch):
    monkeypatch.setenv("JWZT_REPORT_LLM_BASE_URL", "https://llm.example.com/v1/")
    monkeypatch.setenv("JWZT_REPORT_LLM_API_KEY", "test-key")
    monkeypatch.setenv("JWZT_REPORT_LLM_MODEL", "gpt-4.1-mini")
    app = create_app(engine=DummyEngine(), queue=PredictQueue())
    provider = app.state._app_state["report_service"].provider
    assert isinstance(provider, OpenAICompatibleProvider)
    assert provider.base_url == "https://llm.example.com/v1"
    assert provider.model == "gpt-4.1-mini"


def test_report_route_rewrites_data_url_images_to_public_urls():
    class PublicUrlMockProvider(MockProvider):
        image_input_mode = "public_url"
        public_base_url = "https://jwzt.example.com/root/"

    provider = PublicUrlMockProvider(
        response='{"image_findings":"LLM影像描述","assessment":"LLM诊断意见","recommendations":"LLM建议"}'
    )
    app = create_app(
        engine=DummyEngine(),
        queue=PredictQueue(),
        report_service=ReportService(provider=provider),
    )
    client = TestClient(app)
    image_data_url = (
        "data:image/png;base64,"
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJ"
        "AAAADUlEQVR42mP8z8BQDwAFgwJ/lQnLqQAAAABJRU5ErkJggg=="
    )

    resp = client.post(
        "/api/report",
        json={
            "mode": "single",
            "report_mode": "hybrid",
            "case_info": {"exam_id": "E2"},
            "ultrasound_fields": {},
            "images": {"original": image_data_url},
            "inference_result": {
                "label": "benign",
                "label_index": 0,
                "prob_malignant": 0.12,
                "prob_benign": 0.88,
                "processing_time_ms": 100,
            },
        },
    )

    assert resp.status_code == 200
    content = provider.messages[1]["content"]
    public_url = content[1]["image_url"]["url"]
    assert public_url.startswith("https://jwzt.example.com/root/api/report-images/")

    image_path = public_url.removeprefix("https://jwzt.example.com/root")
    image_resp = client.get(image_path)
    assert image_resp.status_code == 200
    assert image_resp.headers["content-type"] == "image/png"
    assert image_resp.content.startswith(b"\x89PNG")
