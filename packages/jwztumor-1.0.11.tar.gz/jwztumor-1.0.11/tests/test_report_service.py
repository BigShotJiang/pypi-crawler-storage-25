"""Tests for report service."""

import asyncio
import logging

from JwzTumor.server.report.providers import MockProvider
from JwzTumor.server.report.prompt import build_report_messages
from JwzTumor.server.report.schemas import CaseInfo, ReportRequest
from JwzTumor.server.report.service import ReportService


def test_hybrid_falls_back_when_llm_json_invalid():
    req = ReportRequest(
        mode="single",
        report_mode="hybrid",
        case_info=CaseInfo(
            exam_id="E1",
            age=45,
            sex="female",
            exam_part="breast",
            side="left",
        ),
        ultrasound_fields={},
        inference_result={
            "label": "benign",
            "label_index": 0,
            "prob_malignant": 0.12,
            "prob_benign": 0.88,
            "processing_time_ms": 100,
        },
    )
    service = ReportService(provider=MockProvider(response="not json"))
    report = asyncio.run(service.generate(req))
    assert report.report_mode == "hybrid"
    assert report.warnings


def test_hybrid_accepts_markdown_wrapped_llm_json():
    req = ReportRequest(
        mode="single",
        report_mode="hybrid",
        case_info=CaseInfo(
            exam_id="E1",
            age=45,
            sex="female",
            exam_part="breast",
            side="left",
        ),
        ultrasound_fields={},
        inference_result={
            "label": "benign",
            "label_index": 0,
            "prob_malignant": 0.12,
            "prob_benign": 0.88,
            "processing_time_ms": 100,
        },
    )
    service = ReportService(
        provider=MockProvider(
            response='```json\n{"image_findings":"LLM影像描述","assessment":"LLM诊断意见","recommendations":"LLM建议"}\n```'
        )
    )

    report = asyncio.run(service.generate(req))

    assert report.sections.image_findings == "LLM影像描述"
    assert report.sections.assessment == "LLM诊断意见"
    assert report.sections.recommendations == "LLM建议"
    assert report.warnings == []


def test_prompt_filters_empty_ultrasound_fields_and_includes_single_image():
    req = ReportRequest(
        mode="single",
        report_mode="hybrid",
        case_info=CaseInfo(exam_id="E1"),
        ultrasound_fields={
            "lesionLocation": "左乳 10 点方向",
            "shape": "",
            "margin": None,
        },
        inference_result={
            "label": "benign",
            "label_index": 0,
            "prob_malignant": 0.12,
            "prob_benign": 0.88,
            "processing_time_ms": 100,
        },
        images={"original": "data:image/png;base64,abc"},
    )

    messages = build_report_messages(req)

    user_content = messages[1]["content"]
    assert isinstance(user_content, list)
    text_block = user_content[0]
    assert text_block["type"] == "text"
    assert "左乳 10 点方向" in text_block["text"]
    assert '"shape"' not in text_block["text"]
    assert '"margin"' not in text_block["text"]
    assert user_content[1] == {
        "type": "image_url",
        "image_url": {"url": "data:image/png;base64,abc"},
    }


def test_prompt_includes_dual_original_images():
    req = ReportRequest(
        mode="dual",
        report_mode="hybrid",
        case_info=CaseInfo(exam_id="E2"),
        ultrasound_fields={},
        inference_result={
            "left": {"label": "benign", "prob_malignant": 0.2, "prob_benign": 0.8},
            "right": {"label": "malignant", "prob_malignant": 0.7, "prob_benign": 0.3},
            "fused_label": "malignant",
            "fused_prob_malignant": 0.45,
            "processing_time_ms": 200,
        },
        images={
            "left_original": "data:image/png;base64,left",
            "right_original": "data:image/png;base64,right",
        },
    )

    messages = build_report_messages(req)

    user_content = messages[1]["content"]
    assert isinstance(user_content, list)
    assert user_content[1]["image_url"]["url"] == "data:image/png;base64,left"
    assert user_content[2]["image_url"]["url"] == "data:image/png;base64,right"


def test_llm_receives_multimodal_messages():
    req = ReportRequest(
        mode="single",
        report_mode="hybrid",
        case_info=CaseInfo(exam_id="E3"),
        ultrasound_fields={},
        inference_result={
            "label": "benign",
            "label_index": 0,
            "prob_malignant": 0.12,
            "prob_benign": 0.88,
            "processing_time_ms": 100,
        },
        images={"original": "data:image/png;base64,abc"},
    )
    provider = MockProvider(
        response='{"image_findings":"LLM影像描述","assessment":"LLM诊断意见","recommendations":"LLM建议"}'
    )
    service = ReportService(provider=provider)

    asyncio.run(service.generate(req))

    assert isinstance(provider.messages[1]["content"], list)


def test_hybrid_logs_llm_report_generation_steps(caplog):
    req = ReportRequest(
        mode="single",
        report_mode="hybrid",
        case_info=CaseInfo(exam_id="E4"),
        ultrasound_fields={},
        inference_result={
            "label": "benign",
            "label_index": 0,
            "prob_malignant": 0.12,
            "prob_benign": 0.88,
            "processing_time_ms": 100,
        },
    )
    service = ReportService(
        provider=MockProvider(
            response='{"image_findings":"LLM影像描述","assessment":"LLM诊断意见","recommendations":"LLM建议"}'
        )
    )

    with caplog.at_level(logging.INFO, logger="JwzTumor.server.report.service"):
        asyncio.run(service.generate(req))

    assert "Report generation started: exam_id=E4 mode=single report_mode=hybrid" in caplog.text
    assert "Calling report LLM: exam_id=E4 mode=single images=0 ultrasound_fields=0" in caplog.text
    assert "Report generation completed: exam_id=E4 mode=single report_mode=hybrid warnings=0" in caplog.text


def test_hybrid_logs_llm_fallback_warning(caplog):
    req = ReportRequest(
        mode="single",
        report_mode="hybrid",
        case_info=CaseInfo(exam_id="E5"),
        ultrasound_fields={},
        inference_result={
            "label": "benign",
            "label_index": 0,
            "prob_malignant": 0.12,
            "prob_benign": 0.88,
            "processing_time_ms": 100,
        },
    )
    service = ReportService(provider=MockProvider(response="not json"))

    with caplog.at_level(logging.INFO, logger="JwzTumor.server.report.service"):
        asyncio.run(service.generate(req))

    assert "Report generation started: exam_id=E5 mode=single report_mode=hybrid" in caplog.text
    assert "Report LLM failed, using rule fallback: exam_id=E5" in caplog.text
    assert "Report generation completed: exam_id=E5 mode=single report_mode=hybrid warnings=1" in caplog.text
