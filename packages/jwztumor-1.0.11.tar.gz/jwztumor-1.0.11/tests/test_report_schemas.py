"""Tests for report API schemas."""

from JwzTumor.server.report.schemas import CaseInfo, ReportRequest


def test_report_request_single_rule():
    req = ReportRequest(
        mode="single",
        report_mode="rule",
        case_info=CaseInfo(
            exam_id="E1",
            age=45,
            sex="female",
            exam_part="breast",
            side="left",
        ),
        ultrasound_fields={},
        inference_result={
            "label": "benign",
            "label_index": 0,
            "prob_malignant": 0.12,
            "prob_benign": 0.88,
            "processing_time_ms": 100,
        },
    )
    assert req.mode == "single"
    assert req.report_mode == "rule"
