"""Tests for InferenceEngine."""
import io
import base64
import pytest
import numpy as np


def _make_dummy_config():
    """Create a minimal config for testing."""
    from JwzTumor.utils.config import Config
    config = Config()
    config.dataset.model_input_size = 64  # small for test speed
    config.inference.threshold = 0.5
    config.inference.use_tta = False
    config.postprocess.threshold = 0.5
    config.postprocess.use_largest_component = False
    return config


def test_engine_init():
    from JwzTumor.server.engine import InferenceEngine
    config = _make_dummy_config()
    engine = InferenceEngine(config)
    assert engine.config is config
    assert engine.model is None
    assert not engine.is_loaded


def test_load_checkpoint_raises_on_missing():
    from JwzTumor.server.engine import InferenceEngine
    config = _make_dummy_config()
    engine = InferenceEngine(config)
    with pytest.raises(FileNotFoundError):
        engine.load_checkpoint("/nonexistent/path.ckpt")


def test_run_inference_on_random_image():
    """End-to-end test with a real model created from config (random weights)."""
    from JwzTumor.server.engine import InferenceEngine
    config = _make_dummy_config()
    engine = InferenceEngine(config)
    engine.load_model_direct()  # creates model with random weights
    assert engine.is_loaded

    # Create a random grayscale image
    image = np.random.rand(128, 128).astype(np.float32)
    result = engine.run_inference(image)
    assert "label" in result
    assert "label_index" in result
    assert "prob_malignant" in result
    assert "prob_benign" in result
    assert "seg_mask" in result
    assert isinstance(result["processing_time_ms"], int)
    assert result["processing_time_ms"] >= 0


def test_run_inference_with_progress_callback():
    """Verify progress callback receives events for each stage."""
    from JwzTumor.server.engine import InferenceEngine
    from JwzTumor.server.schemas import SSEEvent
    config = _make_dummy_config()
    engine = InferenceEngine(config)
    engine.load_model_direct()

    events = []
    from JwzTumor.server.progress import ProgressCallback
    cb = ProgressCallback(
        stages=["preprocessing", "inference", "postprocessing"],
        on_event=lambda e: events.append(e),
    )

    image = np.random.rand(64, 64).astype(np.float32)
    result = engine.run_inference(image, progress_callback=cb)
    assert len(events) == 3
    assert events[0].data["stage"] == "preprocessing"
    assert events[1].data["stage"] == "inference"
    assert events[2].data["stage"] == "postprocessing"


def test_decode_upload_valid_png():
    """Test image decoding from PNG bytes."""
    from JwzTumor.server.engine import decode_upload
    from PIL import Image
    img = Image.fromarray((np.random.rand(32, 32) * 255).astype(np.uint8))
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    png_bytes = buf.getvalue()
    result = decode_upload(png_bytes)
    assert isinstance(result, np.ndarray)
    assert result.ndim == 2
    assert result.shape == (32, 32)


def test_decode_upload_invalid_bytes():
    """Test image decoding with invalid bytes."""
    from JwzTumor.server.engine import decode_upload
    with pytest.raises(ValueError, match="Cannot decode"):
        decode_upload(b"not an image")


def test_tensor_to_base64_png():
    """Test tensor to base64 PNG conversion."""
    from JwzTumor.server.engine import tensor_to_base64_png
    import torch
    t = torch.rand(1, 64, 64)
    result = tensor_to_base64_png(t)
    assert isinstance(result, str)
    # Verify it's valid base64
    decoded = base64.b64decode(result)
    assert decoded[:4] == b"\x89PNG"
