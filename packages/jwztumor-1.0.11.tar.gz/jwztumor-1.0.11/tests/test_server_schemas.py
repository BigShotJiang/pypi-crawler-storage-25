"""Tests for server Pydantic schemas."""
import base64
import pytest


def test_predict_response_creation():
    from JwzTumor.server.schemas import PredictResponse
    resp = PredictResponse(
        label="benign",
        label_index=0,
        prob_malignant=0.12,
        prob_benign=0.88,
        seg_mask="base64data",
        edge_map="base64data",
        uncertainty_map="base64data",
        processing_time_ms=156,
    )
    assert resp.label == "benign"
    assert resp.label_index == 0
    assert resp.prob_malignant == pytest.approx(0.12)
    assert resp.processing_time_ms == 156


def test_predict_response_optional_maps():
    from JwzTumor.server.schemas import PredictResponse
    resp = PredictResponse(
        label="malignant",
        label_index=1,
        prob_malignant=0.92,
        prob_benign=0.08,
        processing_time_ms=200,
    )
    assert resp.seg_mask is None
    assert resp.edge_map is None
    assert resp.uncertainty_map is None


def test_lr_predict_response_creation():
    from JwzTumor.server.schemas import PredictResponse, LRPredictResponse
    left = PredictResponse(
        label="benign", label_index=0,
        prob_malignant=0.1, prob_benign=0.9,
        processing_time_ms=100,
    )
    right = PredictResponse(
        label="malignant", label_index=1,
        prob_malignant=0.8, prob_benign=0.2,
        processing_time_ms=100,
    )
    resp = LRPredictResponse(
        left=left, right=right,
        fused_label="malignant", fused_label_index=1,
        fused_prob_malignant=0.45, fused_prob_benign=0.55,
        processing_time_ms=200,
    )
    assert resp.fused_prob_malignant == pytest.approx(0.45)


def test_health_response():
    from JwzTumor.server.schemas import HealthResponse
    resp = HealthResponse(
        status="healthy", model_loaded=True,
        device="cuda:0", busy=False,
        queue_depth=0, max_queue=32,
    )
    assert resp.status == "healthy"
    assert resp.model_loaded is True


def test_task_submit_response():
    from JwzTumor.server.schemas import TaskSubmitResponse
    resp = TaskSubmitResponse(task_id="abc123")
    assert resp.task_id == "abc123"


def test_sse_progress_event():
    from JwzTumor.server.schemas import SSEEvent
    event = SSEEvent(event="progress", data={"stage": "inference", "progress": 0.5})
    sse_str = event.encode()
    assert "event: progress\n" in sse_str
    assert '"stage": "inference"' in sse_str


def test_error_response():
    from JwzTumor.server.schemas import ErrorResponse
    resp = ErrorResponse(error="invalid_image", detail="Cannot decode file")
    assert resp.error == "invalid_image"
