"""FastAPI application factory and background worker."""
import asyncio
import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Dict

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response

from .engine import InferenceEngine
from .progress import ProgressCallback
from .queue import PredictQueue
from .report.routes import router as report_router
from .report.providers import create_provider_from_env
from .report.service import ReportService
from .report.images import ReportImageStore
from .routes import health, predict
from .schemas import SSEEvent

logger = logging.getLogger(__name__)

# Module-level app state (set during create_app)
_app_state: Dict[str, Any] = {}


def get_app_state() -> Dict[str, Any]:
    """Return the current app state dict."""
    return _app_state


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage startup/shutdown lifecycle."""
    state = app.state._app_state
    _app_state.update(state)

    # Start background queue worker
    worker_task = asyncio.create_task(_queue_worker(state))
    state["_worker_task"] = worker_task

    logger.info(
        "Server started: model_loaded=%s, device=%s",
        state["engine"].is_loaded,
        state["engine"].device,
    )

    yield  # App is running

    # Shutdown: cancel worker
    worker_task.cancel()
    try:
        await worker_task
    except asyncio.CancelledError:
        pass
    logger.info("Server shutting down")


async def _queue_worker(state: Dict[str, Any]):
    """Background worker that processes queued tasks with auto-batching."""
    queue: PredictQueue = state["queue"]
    engine: InferenceEngine = state["engine"]
    max_batch_size: int = state.get("max_batch_size", 4)
    batch_timeout: float = state.get("batch_timeout", 0.05)  # seconds to wait for more tasks

    while True:
        try:
            # Collect up to max_batch_size single-mode tasks
            single_tasks = []
            lr_tasks = []

            # Wait for first task
            first = queue.pop_next()
            if first is None:
                await asyncio.sleep(0.05)
                continue

            if first["mode"] == "single":
                single_tasks.append(first)
            else:
                lr_tasks.append(first)

            # Try to collect more single-mode tasks within timeout
            deadline = asyncio.get_event_loop().time() + batch_timeout
            while len(single_tasks) < max_batch_size:
                remaining = deadline - asyncio.get_event_loop().time()
                if remaining <= 0:
                    break
                await asyncio.sleep(min(0.01, remaining))
                extra = queue.pop_next()
                if extra is None:
                    continue
                if extra["mode"] == "single" and len(single_tasks) < max_batch_size:
                    single_tasks.append(extra)
                else:
                    lr_tasks.append(extra)

            # Process single tasks as batch
            if single_tasks:
                if len(single_tasks) == 1:
                    # Single task — use run_inference with progress callback
                    task = single_tasks[0]
                    task_id = task["task_id"]
                    logger.info("Inference task started: task_id=%s mode=single batch_size=1", task_id)
                    cb = ProgressCallback(
                        stages=["preprocessing", "inference", "postprocessing"],
                        on_event=lambda e, tid=task_id: queue.add_progress_event(tid, e),
                    )
                    result = await asyncio.to_thread(engine.run_inference, task["image"], cb)
                    queue.complete_task(task_id, result)
                    logger.info(
                        "Inference task completed: task_id=%s mode=single label=%s prob_malignant=%.4f processing_time_ms=%s",
                        task_id,
                        result.get("label"),
                        float(result.get("prob_malignant", 0.0)),
                        result.get("processing_time_ms"),
                    )
                else:
                    # Batch — use run_batch_inference
                    images = [t["image"] for t in single_tasks]
                    task_ids = [t["task_id"] for t in single_tasks]
                    logger.info(
                        "Inference batch started: mode=single batch_size=%d task_ids=%s",
                        len(task_ids),
                        ",".join(task_ids),
                    )

                    def _on_progress(tid, event):
                        queue.add_progress_event(tid, event)

                    batch_results = await asyncio.to_thread(
                        engine.run_batch_inference, images, task_ids, _on_progress,
                    )
                    for tid, result in batch_results.items():
                        queue.complete_task(tid, result)
                        logger.info(
                            "Inference task completed: task_id=%s mode=single label=%s prob_malignant=%.4f processing_time_ms=%s",
                            tid,
                            result.get("label"),
                            float(result.get("prob_malignant", 0.0)),
                            result.get("processing_time_ms"),
                        )

            # Process L/R tasks one by one
            for task in lr_tasks:
                task_id = task["task_id"]
                left_image = task["left_image"]
                right_image = task["right_image"]
                logger.info("Inference task started: task_id=%s mode=dual", task_id)

                cb_left = ProgressCallback(
                    stages=["preprocessing", "inference", "postprocessing"],
                    on_event=lambda e, tid=task_id: queue.add_progress_event(tid, e),
                )
                left_result = await asyncio.to_thread(engine.run_inference, left_image, cb_left)

                cb_right = ProgressCallback(
                    stages=["preprocessing", "inference", "postprocessing"],
                    on_event=lambda e, tid=task_id: queue.add_progress_event(tid, e),
                )
                right_result = await asyncio.to_thread(engine.run_inference, right_image, cb_right)

                fused_prob_malignant = round(
                    (left_result["prob_malignant"] + right_result["prob_malignant"]) / 2, 4
                )
                fused_prob_benign = round(
                    (left_result["prob_benign"] + right_result["prob_benign"]) / 2, 4
                )
                fused_label_index = 1 if fused_prob_malignant >= 0.5 else 0
                fused_label = "malignant" if fused_label_index == 1 else "benign"

                fused_result = {
                    "left": left_result,
                    "right": right_result,
                    "fused_label": fused_label,
                    "fused_label_index": fused_label_index,
                    "fused_prob_malignant": fused_prob_malignant,
                    "fused_prob_benign": fused_prob_benign,
                    "processing_time_ms": left_result["processing_time_ms"] + right_result["processing_time_ms"],
                }
                queue.complete_task(task_id, fused_result)
                logger.info(
                    "Inference task completed: task_id=%s mode=dual fused_label=%s fused_prob_malignant=%.4f processing_time_ms=%s",
                    task_id,
                    fused_label,
                    fused_prob_malignant,
                    fused_result["processing_time_ms"],
                )

        except asyncio.CancelledError:
            # Graceful shutdown: fail remaining tasks
            for tid in list(queue._tasks.keys()):
                queue.fail_task(tid, "Service shutting down")
            raise
        except Exception as e:
            logger.exception("Queue worker error for task %s", task.get("task_id", "?"))
            if task:
                queue.fail_task(task["task_id"], str(e))


def create_app(
    engine: InferenceEngine,
    queue: PredictQueue,
    cors_origins: str = "*",
    max_upload_bytes: int = 10 * 1024 * 1024,
    max_batch_size: int = 4,
    batch_timeout: float = 0.05,
    report_service: ReportService | None = None,
    ui_dir: str | None = None,
    ui_api_base_url: str | None = None,
) -> FastAPI:
    """Create and configure the FastAPI application.

    Args:
        engine: Initialized InferenceEngine with loaded model.
        queue: PredictQueue instance.
        cors_origins: CORS allowed origins (comma-separated or "*").
        max_upload_bytes: Maximum upload file size in bytes.
        max_batch_size: Maximum tasks to batch together for inference.
        batch_timeout: Seconds to wait for more tasks before processing.

    Returns:
        Configured FastAPI app.
    """
    app = FastAPI(
        title="JwzTumor Inference Server",
        description="Breast ultrasound benign-malignant diagnosis inference API",
        version="1.0.0",
    )

    # CORS
    origins = [o.strip() for o in cors_origins.split(",")]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Custom handler for FastAPI validation errors -> unified error format
    from fastapi.exceptions import RequestValidationError

    @app.exception_handler(RequestValidationError)
    async def validation_error_handler(request: Request, exc: RequestValidationError):
        errors = exc.errors()
        # Check for missing required fields (file, left, right)
        missing = [e for e in errors if e.get("type") == "missing"]
        if missing:
            field_names = ", ".join(
                e.get("loc", ["unknown"])[-1] for e in missing
            )
            return JSONResponse(
                status_code=422,
                content={"error": "missing_field", "detail": f"Missing required field(s): {field_names}"},
            )
        return JSONResponse(
            status_code=422,
            content={"error": "invalid_request", "detail": str(errors)},
        )

    # Store state
    state = {
        "engine": engine,
        "queue": queue,
        "max_upload_bytes": max_upload_bytes,
        "max_batch_size": max_batch_size,
        "batch_timeout": batch_timeout,
        "report_service": report_service or ReportService(provider=create_provider_from_env()),
        "report_image_store": ReportImageStore(),
        "ui_api_base_url": ui_api_base_url,
    }
    app.state._app_state = state

    # Lifespan
    app.router.lifespan_context = lifespan

    # Routes
    app.include_router(health.router)
    app.include_router(predict.router)
    app.include_router(report_router)

    _mount_static_ui(app, ui_dir=ui_dir, ui_api_base_url=ui_api_base_url)

    return app


def _mount_static_ui(app: FastAPI, ui_dir: str | None, ui_api_base_url: str | None) -> None:
    """Serve a built frontend directory without intercepting /api routes."""
    if not ui_dir:
        return

    root = Path(ui_dir).resolve()
    index_file = root / "index.html"
    if not index_file.exists():
        logger.warning("UI directory does not contain index.html: %s", root)
        return

    @app.get("/config.js", include_in_schema=False)
    async def runtime_config():
        api_base = ui_api_base_url or ""
        return Response(
            content=f'window.__JWZT_CONFIG__ = {{"apiBaseUrl": "{api_base}"}};',
            media_type="application/javascript",
        )

    @app.get("/", include_in_schema=False)
    async def serve_index():
        return FileResponse(index_file)

    @app.get("/{full_path:path}", include_in_schema=False)
    async def serve_static_or_index(full_path: str):
        candidate = (root / full_path).resolve()
        if root in candidate.parents and candidate.is_file():
            return FileResponse(candidate)
        return FileResponse(index_file)
