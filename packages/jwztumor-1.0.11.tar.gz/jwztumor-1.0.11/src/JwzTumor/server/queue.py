"""Inference request queue with memory management."""
import uuid
import logging
import threading
from typing import Any, Dict, List, Optional

import numpy as np

from .schemas import SSEEvent

logger = logging.getLogger(__name__)


class QueueFullError(Exception):
    """Raised when the inference queue is at capacity."""
    pass


class PredictQueue:
    """Thread-safe FIFO queue for inference requests.

    Stores decoded numpy images in memory. Releases them after inference
    completes to manage memory usage.

    Each task stores:
        - task_id: Unique identifier
        - mode: "single" or "lr"
        - image: numpy array (single) or None (after completion)
        - left_image / right_image: numpy arrays (lr mode)
        - result: inference result dict (set on completion)
        - status: "queued" | "running" | "completed" | "error"
    """

    def __init__(self, max_size: int = 32):
        self.max_size = max_size
        self._tasks: Dict[str, Dict[str, Any]] = {}
        self._order: List[str] = []
        self._lock = threading.Lock()

    @property
    def depth(self) -> int:
        with self._lock:
            return sum(
                1 for t in self._tasks.values()
                if t["status"] in ("queued", "running")
            )

    @property
    def is_full(self) -> bool:
        return self.depth >= self.max_size

    def _gen_id(self) -> str:
        return uuid.uuid4().hex[:12]

    def _active_count(self) -> int:
        """Count tasks that are queued or running (lock must be held)."""
        return sum(
            1 for t in self._tasks.values()
            if t["status"] in ("queued", "running")
        )

    def submit(self, image: np.ndarray, mode: str = "single") -> str:
        """Submit a single-image inference request."""
        with self._lock:
            if self._active_count() >= self.max_size:
                raise QueueFullError(
                    f"Queue full (max {self.max_size}). Try again later."
                )
            task_id = self._gen_id()
            self._tasks[task_id] = {
                "task_id": task_id,
                "mode": mode,
                "image": image,
                "left_image": None,
                "right_image": None,
                "result": None,
                "status": "queued",
                "progress_events": [],
            }
            self._order.append(task_id)
            logger.debug("Task %s submitted (mode=%s, queue_depth=%d)", task_id, mode, len(self._tasks))
            return task_id

    def submit_lr(self, left: np.ndarray, right: np.ndarray) -> str:
        """Submit an L/R dual-image inference request."""
        with self._lock:
            if self._active_count() >= self.max_size:
                raise QueueFullError(
                    f"Queue full (max {self.max_size}). Try again later."
                )
            task_id = self._gen_id()
            self._tasks[task_id] = {
                "task_id": task_id,
                "mode": "lr",
                "image": None,
                "left_image": left,
                "right_image": right,
                "result": None,
                "status": "queued",
                "progress_events": [],
            }
            self._order.append(task_id)
            logger.debug("Task %s submitted (mode=lr, queue_depth=%d)", task_id, len(self._tasks))
            return task_id

    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Get task by ID. Returns None if not found."""
        with self._lock:
            return self._tasks.get(task_id)

    def pop_next(self) -> Optional[Dict[str, Any]]:
        """Pop the next queued task (FIFO). Returns None if empty."""
        with self._lock:
            for tid in self._order:
                task = self._tasks.get(tid)
                if task and task["status"] == "queued":
                    task["status"] = "running"
                    return task
            return None

    def add_progress_event(self, task_id: str, event: SSEEvent) -> None:
        """Append a progress event to a task's event list."""
        with self._lock:
            task = self._tasks.get(task_id)
            if task is not None:
                task["progress_events"].append(event)

    def drain_progress_events(self, task_id: str) -> List[SSEEvent]:
        """Return and clear all pending progress events for a task."""
        with self._lock:
            task = self._tasks.get(task_id)
            if task is None:
                return []
            events = task["progress_events"]
            task["progress_events"] = []
            return events

    def complete_task(self, task_id: str, result: Dict[str, Any]) -> None:
        """Mark task as completed, release image memory."""
        with self._lock:
            task = self._tasks.get(task_id)
            if task is None:
                return
            task["result"] = result
            task["status"] = "completed"
            # Release numpy memory
            task["image"] = None
            task["left_image"] = None
            task["right_image"] = None
            # Remove from order list
            if task_id in self._order:
                self._order.remove(task_id)
            logger.debug("Task %s completed, memory released", task_id)

    def fail_task(self, task_id: str, error: str) -> None:
        """Mark task as failed, release image memory."""
        with self._lock:
            task = self._tasks.get(task_id)
            if task is None:
                return
            task["result"] = {"error": error}
            task["status"] = "error"
            task["image"] = None
            task["left_image"] = None
            task["right_image"] = None
            if task_id in self._order:
                self._order.remove(task_id)
            logger.debug("Task %s failed: %s", task_id, error)

    def remove(self, task_id: str) -> None:
        """Remove task from tracking entirely."""
        with self._lock:
            self._tasks.pop(task_id, None)
            if task_id in self._order:
                self._order.remove(task_id)
