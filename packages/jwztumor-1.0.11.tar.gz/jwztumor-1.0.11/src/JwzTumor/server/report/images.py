"""Temporary report image storage for public LLM image URLs."""

from __future__ import annotations

import base64
import time
from dataclasses import dataclass
from secrets import token_urlsafe
from typing import Dict, Optional


@dataclass
class StoredReportImage:
    """A report image served temporarily for LLM providers."""

    content: bytes
    media_type: str
    expires_at: float


class ReportImageStore:
    """In-memory temporary image store for report generation."""

    def __init__(self, ttl_seconds: int = 900):
        self.ttl_seconds = ttl_seconds
        self._items: Dict[str, StoredReportImage] = {}

    def put_data_url(self, data_url: str) -> str:
        """Store a data URL image and return its opaque id."""
        media_type, encoded = _split_image_data_url(data_url)
        image_id = token_urlsafe(24)
        self._purge_expired()
        self._items[image_id] = StoredReportImage(
            content=base64.b64decode(encoded, validate=True),
            media_type=media_type,
            expires_at=time.time() + self.ttl_seconds,
        )
        return image_id

    def get(self, image_id: str) -> Optional[StoredReportImage]:
        self._purge_expired()
        item = self._items.get(image_id)
        if item is None or item.expires_at < time.time():
            self._items.pop(image_id, None)
            return None
        return item

    def _purge_expired(self) -> None:
        now = time.time()
        for image_id, item in list(self._items.items()):
            if item.expires_at < now:
                self._items.pop(image_id, None)


def _split_image_data_url(data_url: str) -> tuple[str, str]:
    prefix, separator, encoded = data_url.partition(",")
    if separator != "," or not prefix.startswith("data:") or ";base64" not in prefix:
        raise ValueError("Report image must be a base64 data URL")
    media_type = prefix.removeprefix("data:").split(";", 1)[0]
    if media_type not in {"image/png", "image/jpeg", "image/bmp"}:
        raise ValueError("Report image data URL must be PNG, JPEG, or BMP")
    return media_type, encoded
