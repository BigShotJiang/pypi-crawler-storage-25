"""Clinical report generation for the JwzTumor inference server."""

