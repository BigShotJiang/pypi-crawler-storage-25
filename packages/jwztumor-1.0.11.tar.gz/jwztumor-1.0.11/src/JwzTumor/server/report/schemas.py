"""Schemas for clinical auxiliary report generation."""

from datetime import datetime, timezone
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field

DiagnosisMode = Literal["single", "dual"]
ReportMode = Literal["rule", "llm", "hybrid"]


class CaseInfo(BaseModel):
    """Patient and examination metadata used for report generation."""

    exam_id: str
    age: Optional[int] = None
    sex: Optional[str] = None
    exam_part: str = "breast"
    side: Optional[str] = None
    history: str = ""
    notes: str = ""


class ReportSections(BaseModel):
    """Structured report text sections."""

    summary: str
    image_findings: str
    model_findings: str
    assessment: str
    recommendations: str
    disclaimer: str
    comparison: Optional[str] = None


class ReportImages(BaseModel):
    """Original ultrasound images forwarded to multimodal report generation."""

    original: Optional[str] = None
    left_original: Optional[str] = None
    right_original: Optional[str] = None


class ReportRequest(BaseModel):
    """Request body for /api/report."""

    mode: DiagnosisMode
    report_mode: ReportMode = "hybrid"
    case_info: CaseInfo
    ultrasound_fields: Dict[str, Any] = Field(default_factory=dict)
    images: ReportImages = Field(default_factory=ReportImages)
    inference_result: Dict[str, Any]
    locked_fields: List[str] = Field(default_factory=lambda: ["case_info", "inference_result"])
    language: str = "zh-CN"


class ReportResponse(BaseModel):
    """Generated report response."""

    report_id: str
    mode: DiagnosisMode
    report_mode: ReportMode
    sections: ReportSections
    editable_fields: List[str]
    locked_facts: Dict[str, Any]
    warnings: List[str] = Field(default_factory=list)
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
