"""Rule-based report composition."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, Iterable

from .schemas import ReportRequest, ReportResponse, ReportSections

DISCLAIMER = (
    "本报告由 JwzTumor 模型和结构化信息生成，仅用于临床辅助诊断，"
    "不能替代医生诊断、病理结果及其他检查结论。"
)


def compose_rule_report(req: ReportRequest) -> ReportResponse:
    """Compose a deterministic clinical auxiliary report from locked facts."""
    sections = _compose_dual_sections(req) if req.mode == "dual" else _compose_single_sections(req)
    return ReportResponse(
        report_id=f"rule-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')}",
        mode=req.mode,
        report_mode=req.report_mode,
        sections=sections,
        editable_fields=["image_findings", "assessment", "recommendations"],
        locked_facts={
            "case_info": _model_to_dict(req.case_info),
            "inference_result": req.inference_result,
        },
        warnings=[],
    )


def _compose_single_sections(req: ReportRequest) -> ReportSections:
    result = req.inference_result
    label = _label_text(result.get("label"))
    prob_malignant = _format_prob(result.get("prob_malignant"))
    prob_benign = _format_prob(result.get("prob_benign"))
    fields = _field_sentence(req.ultrasound_fields)
    processing_time = result.get("processing_time_ms", "-")

    return ReportSections(
        summary=f"模型提示{label}，恶性概率 {prob_malignant}。",
        image_findings=fields or "未填写额外超声结构化描述。",
        model_findings=(
            f"单图推理结果：良性概率 {prob_benign}，恶性概率 {prob_malignant}，"
            f"处理耗时 {processing_time} ms。"
        ),
        assessment=(
            f"结合上传图像和模型输出，当前结果为{label}的辅助判断。"
            "请结合临床触诊、超声医师观察及必要病理检查综合评估。"
        ),
        recommendations=(
            "建议结合 BI-RADS 分级、必要时进一步行穿刺活检或专科评估。"
            if _as_float(result.get("prob_malignant")) >= 0.5
            else "建议结合临床风险因素和随访策略，由超声医师确认最终诊断意见。"
        ),
        disclaimer=DISCLAIMER,
    )


def _compose_dual_sections(req: ReportRequest) -> ReportSections:
    result = req.inference_result
    left = result.get("left", {})
    right = result.get("right", {})
    fused_label = _label_text(result.get("fused_label"))
    fused_prob = _format_prob(result.get("fused_prob_malignant"))
    fields = _field_sentence(req.ultrasound_fields)

    return ReportSections(
        summary=f"左右图融合判断为{fused_label}，融合恶性概率 {fused_prob}。",
        image_findings=fields or "未填写额外超声结构化描述。",
        model_findings=(
            f"左侧恶性概率 {_format_prob(left.get('prob_malignant'))}，"
            f"右侧恶性概率 {_format_prob(right.get('prob_malignant'))}，"
            f"融合恶性概率 {fused_prob}，处理耗时 {result.get('processing_time_ms', '-')} ms。"
        ),
        comparison=(
            f"左侧模型判断为{_label_text(left.get('label'))}，"
            f"右侧模型判断为{_label_text(right.get('label'))}。"
            "请重点结合左右侧病灶形态、边界、回声和血流差异进行临床复核。"
        ),
        assessment=(
            f"结合左右侧图像和融合概率，当前报告给出{fused_label}的辅助判断。"
            "该判断用于辅助临床比较分析，不作为确诊依据。"
        ),
        recommendations=(
            "建议优先复核高风险侧影像表现，结合 BI-RADS 分级、病理检查或进一步影像学评估。"
            if _as_float(result.get("fused_prob_malignant")) >= 0.5
            else "建议结合双侧临床表现与随访策略，由超声医师确认最终诊断意见。"
        ),
        disclaimer=DISCLAIMER,
    )


def _field_sentence(fields: Dict[str, Any]) -> str:
    labels = {
        "lesion_location": "肿块位置",
        "lesionLocation": "肿块位置",
        "lesion_size": "肿块大小",
        "lesionSize": "肿块大小",
        "shape": "形态",
        "margin": "边界",
        "echo": "内部回声",
        "posterior_echo": "后方回声",
        "posteriorEcho": "后方回声",
        "blood_flow": "血流信号",
        "bloodFlow": "血流信号",
    }
    parts = []
    for key, value in fields.items():
        if value is None or str(value).strip() == "":
            continue
        parts.append(f"{labels.get(key, key)}：{str(value).strip()}")
    return "；".join(parts)


def _label_text(label: Any) -> str:
    if label == "benign":
        return "良性倾向"
    if label == "malignant":
        return "恶性风险"
    return str(label) if label is not None else "未明确"


def _format_prob(value: Any) -> str:
    return f"{_as_float(value) * 100:.1f}%"


def _as_float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _model_to_dict(model: Any) -> Dict[str, Any]:
    if hasattr(model, "model_dump"):
        return model.model_dump()
    return model.dict()
