"""LLM providers for report generation."""

from __future__ import annotations

import json
import os
import base64
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Mapping, Optional, Union


ReportLLMContentBlock = Dict[str, Any]
ReportLLMContent = Union[str, List[ReportLLMContentBlock]]
ReportLLMMessage = Dict[str, ReportLLMContent]
Message = ReportLLMMessage


class BaseLLMProvider(ABC):
    """Abstract LLM provider interface."""

    @abstractmethod
    async def complete(self, messages: List[Message]) -> str:
        """Return the model's raw text completion."""


class DisabledProvider(BaseLLMProvider):
    """Provider used when LLM report generation is disabled."""

    async def complete(self, messages: List[Message]) -> str:
        raise RuntimeError("LLM provider is disabled")


class MockProvider(BaseLLMProvider):
    """Deterministic provider for tests."""

    def __init__(self, response: str):
        self.response = response
        self.messages: List[Message] = []

    async def complete(self, messages: List[Message]) -> str:
        self.messages = messages
        return self.response


class OpenAICompatibleProvider(BaseLLMProvider):
    """OpenAI-compatible chat completions provider."""

    def __init__(
        self,
        base_url: str,
        api_key: str,
        model: str,
        timeout: float = 60.0,
        max_retries: int = 2,
        temperature: float = 0.2,
        max_tokens: int = 1600,
        multimodal_enabled: bool = True,
        startup_check: bool = True,
        image_input_mode: str = "data_url",
        public_base_url: str = "",
        startup_image_url: str = (
            "https://qianwen-res.oss-accelerate.aliyuncs.com/"
            "Qwen3.5/demo/CI_Demo/mathv-1327.jpg"
        ),
        thinking_disable_param: Optional[Dict[str, Any]] = None,
        extra_body: Optional[Dict[str, Any]] = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.timeout = timeout
        self.max_retries = max_retries
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.multimodal_enabled = multimodal_enabled
        self.startup_check = startup_check
        self.image_input_mode = image_input_mode
        self.public_base_url = public_base_url.rstrip("/")
        self.startup_image_url = startup_image_url
        self.thinking_disable_param = thinking_disable_param or {}
        self.extra_body = extra_body or {}

    async def complete(self, messages: List[Message]) -> str:
        import httpx

        payload = self._build_payload(messages)
        data = await self._post_payload(httpx.AsyncClient, payload)
        return self._extract_content(data, expect_multimodal=self._contains_image_content(messages))

    async def check_startup(self) -> None:
        """Validate configured text and multimodal report requests before serving."""
        if not self.thinking_disable_param:
            raise RuntimeError("LLM startup check failed: thinking_disable_param is required")
        if self.max_tokens <= 0:
            raise RuntimeError("LLM startup check failed: max_tokens must be greater than 0")
        if self.image_input_mode not in {"data_url", "public_url"}:
            raise RuntimeError("LLM startup check failed: image_input_mode must be data_url or public_url")
        if self.image_input_mode == "public_url" and not self.public_base_url:
            raise RuntimeError("LLM startup check failed: public_base_url is required for public_url image mode")

        text_probe: List[Message] = [
            {"role": "system", "content": "Return strict JSON only."},
            {
                "role": "user",
                "content": (
                    'Return {"image_findings":"ok","assessment":"ok","recommendations":"ok"} '
                    "as strict JSON."
                ),
            },
        ]
        try:
            await self.complete(text_probe)
            if self.multimodal_enabled:
                image_url = await self._startup_image_url()
                image_probe: List[Message] = [
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": "Return strict JSON after reading this test image."},
                            {
                                "type": "image_url",
                                "image_url": {"url": image_url},
                            },
                        ],
                    }
                ]
                await self.complete(image_probe)
        except Exception as exc:  # noqa: BLE001 - wrap provider details for startup failure
            raise RuntimeError(f"LLM startup check failed: {exc}") from exc

    async def _startup_image_url(self) -> str:
        if self.image_input_mode == "public_url":
            return self.startup_image_url
        return await self._download_startup_image_data_url()

    async def _download_startup_image_data_url(self) -> str:
        import httpx

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.get(self.startup_image_url)
        if response.status_code >= 400:
            raise RuntimeError(f"HTTP {response.status_code} while downloading startup image")

        content = response.content
        if not content:
            raise RuntimeError("Startup image download returned empty content")
        if len(content) > 5 * 1024 * 1024:
            raise RuntimeError("Startup image is larger than 5 MB")

        media_type = response.headers.get("content-type", "image/jpeg").split(";", 1)[0].strip()
        if not media_type.startswith("image/"):
            media_type = "image/jpeg"
        encoded = base64.b64encode(content).decode("ascii")
        return f"data:{media_type};base64,{encoded}"

    def _build_payload(self, messages: List[Message]) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }
        payload.update(self.thinking_disable_param)
        payload.update(self.extra_body)
        return payload

    async def _post_payload(self, client_factory: Any, payload: Dict[str, Any]) -> Dict[str, Any]:
        url = f"{self.base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        last_error: Optional[Exception] = None
        async with client_factory(timeout=self.timeout) as client:
            for _ in range(self.max_retries + 1):
                try:
                    response = await client.post(url, headers=headers, json=payload)
                    if response.status_code >= 400:
                        detail = response.text[:500]
                        raise RuntimeError(
                            f"HTTP {response.status_code} from OpenAI-compatible provider: {detail}"
                        )
                    return response.json()
                except Exception as exc:  # noqa: BLE001 - retry and surface final provider failure
                    last_error = exc

        raise RuntimeError(f"OpenAI-compatible provider failed: {last_error}") from last_error

    def _extract_content(self, data: Dict[str, Any], *, expect_multimodal: bool) -> str:
        choices = data.get("choices")
        if not isinstance(choices, list) or not choices:
            raise RuntimeError(
                "OpenAI-compatible provider returned no completion choices."
                + self._missing_choices_hint(expect_multimodal=expect_multimodal)
            )

        message = choices[0].get("message") if isinstance(choices[0], dict) else None
        if not isinstance(message, dict):
            raise RuntimeError("OpenAI-compatible provider returned an invalid completion message.")

        content = message.get("content")
        if not isinstance(content, str) or not content.strip():
            reasoning_content = message.get("reasoning_content")
            if isinstance(reasoning_content, str) and reasoning_content.strip():
                raise RuntimeError(
                    "OpenAI-compatible provider returned no assistant content after disabling thinking mode."
                )
            raise RuntimeError("OpenAI-compatible provider returned empty assistant content.")

        return content

    def _missing_choices_hint(self, *, expect_multimodal: bool) -> str:
        if not expect_multimodal:
            return ""
        if self.image_input_mode == "data_url":
            return (
                " The provider rejected or ignored the data_url image payload; "
                "try report_llm.image_input_mode=public_url with a public_base_url "
                "that the LLM provider can access."
            )
        if self.image_input_mode == "public_url":
            return (
                " The configured model may not support multimodal image inputs, "
                "or the public image URL is not reachable by the LLM provider."
            )
        return " The configured model may not support multimodal image inputs."

    @staticmethod
    def _contains_image_content(messages: List[Message]) -> bool:
        for message in messages:
            content = message.get("content")
            if isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "image_url":
                        return True
        return False


def create_provider_from_env(env: Mapping[str, str] | None = None) -> BaseLLMProvider:
    """Build an LLM provider from environment variables."""
    values = env or os.environ
    base_url = values.get("JWZT_REPORT_LLM_BASE_URL", "").strip()
    api_key = values.get("JWZT_REPORT_LLM_API_KEY", "").strip()
    model = values.get("JWZT_REPORT_LLM_MODEL", "").strip()
    enabled_value = values.get("JWZT_REPORT_LLM_ENABLED")
    enabled = _parse_bool(enabled_value, default=bool(base_url and api_key and model))

    if not enabled:
        return DisabledProvider()
    if not (base_url and api_key and model):
        raise ValueError("Report LLM is enabled but base_url, api_key, or model is missing")

    timeout = float(values.get("JWZT_REPORT_LLM_TIMEOUT", "60"))
    max_retries = int(values.get("JWZT_REPORT_LLM_MAX_RETRIES", "2"))
    temperature = float(values.get("JWZT_REPORT_LLM_TEMPERATURE", "0.2"))
    max_tokens = int(values.get("JWZT_REPORT_LLM_MAX_TOKENS", "1600"))
    multimodal_enabled = _parse_bool(values.get("JWZT_REPORT_LLM_MULTIMODAL_ENABLED"), default=True)
    startup_check = _parse_bool(values.get("JWZT_REPORT_LLM_STARTUP_CHECK"), default=True)
    image_input_mode = values.get("JWZT_REPORT_LLM_IMAGE_INPUT_MODE", "data_url").strip() or "data_url"
    public_base_url = values.get("JWZT_REPORT_LLM_PUBLIC_BASE_URL", "").strip()
    startup_image_url = values.get(
        "JWZT_REPORT_LLM_STARTUP_IMAGE_URL",
        (
            "https://qianwen-res.oss-accelerate.aliyuncs.com/"
            "Qwen3.5/demo/CI_Demo/mathv-1327.jpg"
        ),
    ).strip()
    thinking_disable_param = _parse_json_mapping(values.get("JWZT_REPORT_LLM_THINKING_DISABLE_PARAM", ""))
    extra_body = _parse_json_mapping(values.get("JWZT_REPORT_LLM_EXTRA_BODY", ""))
    return OpenAICompatibleProvider(
        base_url=base_url,
        api_key=api_key,
        model=model,
        timeout=timeout,
        max_retries=max_retries,
        temperature=temperature,
        max_tokens=max_tokens,
        multimodal_enabled=multimodal_enabled,
        startup_check=startup_check,
        image_input_mode=image_input_mode,
        public_base_url=public_base_url,
        startup_image_url=startup_image_url,
        thinking_disable_param=thinking_disable_param,
        extra_body=extra_body,
    )


def _parse_bool(value: str | None, *, default: bool) -> bool:
    if value is None or str(value).strip() == "":
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def _parse_json_mapping(value: str | Mapping[str, Any] | None) -> Dict[str, Any]:
    if value is None or value == "":
        return {}
    if isinstance(value, Mapping):
        return dict(value)
    data = json.loads(value)
    if not isinstance(data, dict):
        raise ValueError("LLM JSON configuration value must be an object")
    return data
