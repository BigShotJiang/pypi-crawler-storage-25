"""Report generation API routes."""

import logging

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import Response

from .images import ReportImageStore
from .schemas import ReportImages, ReportRequest, ReportResponse

router = APIRouter()
logger = logging.getLogger(__name__)


@router.post("/api/report", response_model=ReportResponse)
async def generate_report(req: ReportRequest, request: Request):
    logger.info(
        "Report API request received: exam_id=%s mode=%s report_mode=%s",
        req.case_info.exam_id,
        req.mode,
        req.report_mode,
    )
    service = request.app.state._app_state["report_service"]
    provider = getattr(service, "provider", None)
    if getattr(provider, "image_input_mode", "data_url") == "public_url":
        logger.info(
            "Report API rewriting images to public URLs: exam_id=%s mode=%s images=%d",
            req.case_info.exam_id,
            req.mode,
            len(req.images.model_dump(exclude_none=True)),
        )
        req = _rewrite_images_to_public_urls(
            req,
            store=request.app.state._app_state["report_image_store"],
            public_base_url=getattr(provider, "public_base_url", ""),
        )
    response = await service.generate(req)
    logger.info(
        "Report API response ready: exam_id=%s report_id=%s warnings=%d",
        req.case_info.exam_id,
        response.report_id,
        len(response.warnings),
    )
    return response


@router.get("/api/report-images/{image_id}")
async def get_report_image(image_id: str, request: Request):
    store: ReportImageStore = request.app.state._app_state["report_image_store"]
    image = store.get(image_id)
    if image is None:
        raise HTTPException(status_code=404, detail="Report image not found or expired")
    return Response(
        content=image.content,
        media_type=image.media_type,
        headers={"Cache-Control": "no-store"},
    )


def _rewrite_images_to_public_urls(
    req: ReportRequest,
    *,
    store: ReportImageStore,
    public_base_url: str,
) -> ReportRequest:
    if not public_base_url:
        raise HTTPException(
            status_code=500,
            detail="report_llm.public_base_url is required for public_url image mode",
        )

    base_url = public_base_url.rstrip("/")
    image_values = req.images.model_dump(exclude_none=True)
    rewritten = {}
    for key, value in image_values.items():
        if isinstance(value, str) and value.startswith("data:"):
            image_id = store.put_data_url(value)
            rewritten[key] = f"{base_url}/api/report-images/{image_id}"
        else:
            rewritten[key] = value

    next_req = req.model_copy(update={"images": ReportImages(**rewritten)})
    return next_req
