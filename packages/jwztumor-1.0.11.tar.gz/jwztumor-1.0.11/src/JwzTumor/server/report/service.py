"""Report generation service."""

from __future__ import annotations

import json
import logging
import re
import time
from typing import Any, Dict, Optional

from .prompt import build_report_messages
from .providers import BaseLLMProvider, DisabledProvider
from .rules import compose_rule_report
from .schemas import ReportRequest, ReportResponse, ReportSections

logger = logging.getLogger(__name__)


class ReportService:
    """Generate clinical auxiliary reports using rule, LLM, or hybrid mode."""

    def __init__(self, provider: Optional[BaseLLMProvider] = None):
        self.provider = provider or DisabledProvider()

    async def generate(self, req: ReportRequest) -> ReportResponse:
        started_at = time.perf_counter()
        exam_id = req.case_info.exam_id
        logger.info(
            "Report generation started: exam_id=%s mode=%s report_mode=%s",
            exam_id,
            req.mode,
            req.report_mode,
        )

        if req.report_mode == "rule":
            report = compose_rule_report(req)
            logger.info(
                "Report generation completed: exam_id=%s mode=%s report_mode=%s warnings=%d elapsed_ms=%d",
                exam_id,
                req.mode,
                req.report_mode,
                len(report.warnings),
                int((time.perf_counter() - started_at) * 1000),
            )
            return report

        base_report = compose_rule_report(req)
        if req.report_mode == "llm":
            base_report.sections = ReportSections(
                summary=base_report.sections.summary,
                model_findings=base_report.sections.model_findings,
                disclaimer=base_report.sections.disclaimer,
                comparison=base_report.sections.comparison,
                **await self._generate_editable_sections(req, None),
            )
            logger.info(
                "Report generation completed: exam_id=%s mode=%s report_mode=%s warnings=%d elapsed_ms=%d",
                exam_id,
                req.mode,
                req.report_mode,
                len(base_report.warnings),
                int((time.perf_counter() - started_at) * 1000),
            )
            return base_report

        try:
            editable = await self._generate_editable_sections(req, base_report)
            base_report.sections = ReportSections(
                summary=base_report.sections.summary,
                model_findings=base_report.sections.model_findings,
                disclaimer=base_report.sections.disclaimer,
                comparison=base_report.sections.comparison,
                **editable,
            )
        except Exception as exc:  # noqa: BLE001 - surface fallback warning to API consumer
            logger.warning("Report LLM failed, using rule fallback: exam_id=%s error=%s", exam_id, exc)
            base_report.warnings.append(f"LLM report generation failed; used rule fallback: {exc}")
        logger.info(
            "Report generation completed: exam_id=%s mode=%s report_mode=%s warnings=%d elapsed_ms=%d",
            exam_id,
            req.mode,
            req.report_mode,
            len(base_report.warnings),
            int((time.perf_counter() - started_at) * 1000),
        )
        return base_report

    async def _generate_editable_sections(
        self,
        req: ReportRequest,
        base_report: Optional[ReportResponse],
    ) -> Dict[str, str]:
        exam_id = req.case_info.exam_id
        image_count = _count_images(req)
        ultrasound_field_count = _count_non_empty_fields(req.ultrasound_fields)
        logger.info(
            "Calling report LLM: exam_id=%s mode=%s images=%d ultrasound_fields=%d",
            exam_id,
            req.mode,
            image_count,
            ultrasound_field_count,
        )
        text = await self.provider.complete(build_report_messages(req, base_report))
        logger.info("Report LLM response received: exam_id=%s chars=%d", exam_id, len(text))
        data = _parse_llm_json_object(text)
        required = ["image_findings", "assessment", "recommendations"]
        missing = [field for field in required if field not in data]
        if missing:
            raise ValueError(f"LLM output missing required field(s): {', '.join(missing)}")
        logger.info(
            "Report LLM sections parsed: exam_id=%s fields=%s",
            exam_id,
            ",".join(required),
        )
        return {field: str(data[field]) for field in required}


def _parse_llm_json_object(text: str) -> Dict[str, Any]:
    """Parse JSON object text from common LLM response wrappers."""
    stripped = text.strip()
    if stripped.startswith("```"):
        stripped = re.sub(r"^```(?:json)?\s*", "", stripped, flags=re.IGNORECASE)
        stripped = re.sub(r"\s*```$", "", stripped)
    try:
        data = json.loads(stripped)
    except json.JSONDecodeError:
        start = stripped.find("{")
        end = stripped.rfind("}")
        if start == -1 or end == -1 or end <= start:
            raise
        data = json.loads(stripped[start : end + 1])
    if not isinstance(data, dict):
        raise ValueError("LLM output must be a JSON object")
    return data


def _count_images(req: ReportRequest) -> int:
    return sum(1 for value in req.images.model_dump(exclude_none=True).values() if value)


def _count_non_empty_fields(fields: Dict[str, Any]) -> int:
    return sum(1 for value in fields.values() if value is not None and str(value).strip())
