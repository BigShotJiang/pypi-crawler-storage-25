"""Prompt construction for report LLM generation."""

from __future__ import annotations

import json
from typing import Any, Dict, List

from .providers import ReportLLMMessage
from .schemas import ReportRequest, ReportResponse


def build_report_messages(req: ReportRequest, base_report: ReportResponse | None = None) -> List[ReportLLMMessage]:
    """Build strict JSON-only multimodal messages for report generation."""
    locked_facts = {
        "case_info": _model_to_dict(req.case_info),
        "inference_result": req.inference_result,
    }
    editable_seed = _model_to_dict(base_report.sections) if base_report is not None else {}
    filtered_ultrasound_fields = _filter_empty_fields(req.ultrasound_fields)

    system = (
        "你是乳腺超声临床辅助诊断报告生成助手。"
        "必须遵循结构化输入，不得改写 locked_facts 中的患者信息、模型标签、概率、耗时或推理数据。"
        "仅可生成或润色 image_findings、assessment、recommendations 三个文字字段。"
        "输出必须是严格 JSON，不要输出 Markdown。"
    )
    user_payload = {
        "mode": req.mode,
        "language": req.language,
        "locked_facts": locked_facts,
        "ultrasound_fields": filtered_ultrasound_fields,
        "editable_seed": editable_seed,
        "required_json_schema": {
            "image_findings": "string",
            "assessment": "string",
            "recommendations": "string",
        },
    }
    user_content: List[Dict[str, Any]] = [
        {"type": "text", "text": json.dumps(user_payload, ensure_ascii=False)}
    ]
    images = req.images.model_dump(exclude_none=True)
    if req.mode == "single" and images.get("original"):
        user_content.append(
            {"type": "image_url", "image_url": {"url": images["original"]}}
        )
    else:
        if images.get("left_original"):
            user_content.append(
                {"type": "image_url", "image_url": {"url": images["left_original"]}}
            )
        if images.get("right_original"):
            user_content.append(
                {"type": "image_url", "image_url": {"url": images["right_original"]}}
            )
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": user_content},
    ]


def _model_to_dict(model: Any) -> Dict[str, Any]:
    if hasattr(model, "model_dump"):
        return model.model_dump()
    if hasattr(model, "dict"):
        return model.dict()
    return dict(model)


def _filter_empty_fields(fields: Dict[str, Any]) -> Dict[str, Any]:
    return {
        key: value
        for key, value in fields.items()
        if value is not None and str(value).strip() != ""
    }
