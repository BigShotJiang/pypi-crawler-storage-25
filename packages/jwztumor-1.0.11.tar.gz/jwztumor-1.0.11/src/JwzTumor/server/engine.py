"""Inference engine — wraps model + preprocessor, runs substeps with progress."""
import io
import time
import logging
import base64
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn

from ..data.preprocessing import BreastUSPreprocessor, RestoreTransform
from ..inference.postprocessing import postprocess_segmentation, postprocess_classification
from ..inference.tta import apply_tta
from .progress import ProgressCallback

logger = logging.getLogger(__name__)


def decode_upload(file_bytes: bytes) -> np.ndarray:
    """Decode uploaded file bytes to a grayscale numpy array [H, W].

    Args:
        file_bytes: Raw file bytes (PNG, JPEG, or BMP).

    Returns:
        Grayscale float32 numpy array [H, W].

    Raises:
        ValueError: If bytes cannot be decoded as an image.
    """
    try:
        from PIL import Image
        img = Image.open(io.BytesIO(file_bytes))
        img = img.convert("L")  # grayscale
        return np.array(img, dtype=np.float32)
    except Exception as e:
        raise ValueError(f"Cannot decode uploaded file as image: {e}") from e


def tensor_to_base64_png(tensor: torch.Tensor) -> str:
    """Convert a [1, H, W] or [H, W] tensor to a base64-encoded PNG string.

    Values are normalized to [0, 255] uint8 for PNG encoding.
    """
    if tensor.dim() == 3:
        tensor = tensor[0]  # [H, W]
    arr = tensor.cpu().numpy()
    # Normalize to 0-255
    arr_min, arr_max = arr.min(), arr.max()
    if arr_max - arr_min > 1e-6:
        arr = (arr - arr_min) / (arr_max - arr_min) * 255.0
    else:
        arr = np.zeros_like(arr)
    arr = arr.astype(np.uint8)

    from PIL import Image
    img = Image.fromarray(arr, mode="L")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("ascii")


class InferenceEngine:
    """Manages model lifecycle and runs inference substeps.

    Provides:
        - load_checkpoint(): Load from .ckpt file
        - load_model_direct(): Create model with random weights (for testing)
        - run_inference(): Run full pipeline on a single numpy image
    """

    def __init__(self, config):
        self.config = config
        self.model: Optional[nn.Module] = None
        self.preprocessor = BreastUSPreprocessor(
            model_input_size=config.dataset.model_input_size,
            pad_mode=config.dataset.pad_mode,
        )
        self.device = torch.device(
            config.training.device
            if config.training.device != "auto"
            else ("cuda" if torch.cuda.is_available() else "cpu")
        )

    @property
    def is_loaded(self) -> bool:
        return self.model is not None

    def _warmup(self) -> None:
        """Run a dummy forward pass to pre-allocate CUDA memory pools."""
        from ..inference.predictor import _warmup_model
        input_size = getattr(self.config.dataset, "model_input_size", 512)
        _warmup_model(self.model, self.device, input_size)

    def load_model_direct(self) -> None:
        """Create model from config with random weights (for testing)."""
        from ..models.model_factory import create_model
        self.model = create_model(self.config)
        self.model.to(self.device)
        self.model.eval()
        self._warmup()

    def load_checkpoint(self, checkpoint_path: str) -> None:
        """Load model weights from a checkpoint file."""
        import os
        if not os.path.exists(checkpoint_path):
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")
        from ..models.model_factory import create_model
        self.model = create_model(self.config)
        ckpt = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        self.model.load_state_dict(ckpt["model_state_dict"])
        self.model.to(self.device)
        self.model.eval()
        logger.info("Loaded checkpoint from %s (epoch=%d)", checkpoint_path, ckpt.get("epoch", -1))
        self._warmup()

    def run_inference(
        self,
        image: np.ndarray,
        progress_callback: Optional[ProgressCallback] = None,
    ) -> Dict[str, Any]:
        """Run full inference pipeline on a single image.

        Args:
            image: Grayscale numpy array [H, W].
            progress_callback: Optional callback for SSE progress updates.

        Returns:
            Dict with label, label_index, prob_malignant, prob_benign,
            seg_mask, edge_map, uncertainty_map, processing_time_ms.
        """
        t_start = time.perf_counter()

        # Stage 1: Preprocessing
        if progress_callback:
            progress_callback.emit("preprocessing", 0.2, "Preprocessing image...")
        processed = self.preprocessor.process_infer(image)

        image_tensor = processed["image"].unsqueeze(0).to(self.device)

        # Stage 2: Inference
        if progress_callback:
            progress_callback.emit("inference", 0.5, "Running model inference...")
        with torch.no_grad():
            if self.config.inference.use_tta:
                outputs = apply_tta(self.model, image_tensor)
            else:
                outputs = self.model(image_tensor)

        # Move outputs to CPU
        outputs = {k: v.cpu() if isinstance(v, torch.Tensor) else v for k, v in outputs.items()}

        # Stage 3: Postprocessing
        if progress_callback:
            progress_callback.emit("postprocessing", 0.8, "Postprocessing results...")

        # Restore spatial outputs to original size
        restore = RestoreTransform(
            pad_info=processed["pad_info"],
            resize_scale=processed["resize_scale"],
            original_size=processed["original_size"],
        )

        # Classification postprocessing
        cls_result = postprocess_classification(
            outputs.get("cls_prob", torch.zeros(1, 2)),
        )

        # Segmentation postprocessing
        seg_prob = outputs.get("seg_prob")
        seg_mask = None
        if seg_prob is not None:
            restored_seg = restore(seg_prob)
            seg_mask = postprocess_segmentation(
                restored_seg.unsqueeze(0) if restored_seg.dim() == 2 else restored_seg,
                threshold=self.config.inference.threshold,
                use_largest_component=self.config.postprocess.use_largest_component,
                min_region_size=self.config.postprocess.min_region_size,
            ).squeeze(0)

        # Restore edge and uncertainty maps
        edge_map = None
        edge_prob = outputs.get("edge_prob")
        if edge_prob is not None:
            edge_map = restore(edge_prob)

        uncertainty_map = None
        unc = outputs.get("uncertainty_map")
        if unc is not None:
            uncertainty_map = restore(unc)

        elapsed_ms = int((time.perf_counter() - t_start) * 1000)

        # Encode spatial outputs as base64 PNG
        result = {
            "label": "malignant" if cls_result["pred_label"] == 1 else "benign",
            "label_index": cls_result["pred_label"],
            "prob_malignant": round(cls_result["prob_malignant"], 4),
            "prob_benign": round(cls_result["prob_benign"], 4),
            "seg_mask": tensor_to_base64_png(seg_mask) if seg_mask is not None else None,
            "edge_map": tensor_to_base64_png(edge_map) if edge_map is not None else None,
            "uncertainty_map": tensor_to_base64_png(uncertainty_map) if uncertainty_map is not None else None,
            "processing_time_ms": elapsed_ms,
        }

        return result

    def run_batch_inference(
        self,
        images: List[np.ndarray],
        task_ids: List[str],
        on_progress=None,
    ) -> Dict[str, Dict[str, Any]]:
        """Run batch inference on multiple images in a single forward pass.

        Args:
            images: List of grayscale numpy arrays [H, W].
            task_ids: Corresponding task IDs for progress callbacks.
            on_progress: Optional callable(task_id, SSEEvent) for progress.

        Returns:
            Dict mapping task_id -> inference result dict.
        """
        if not images:
            return {}

        t_start = time.perf_counter()
        batch_size = len(images)

        # Emit preprocessing progress for all tasks
        if on_progress:
            for tid in task_ids:
                from .schemas import SSEEvent
                on_progress(tid, SSEEvent("progress", {
                    "stage": "preprocessing", "progress": 0.2, "message": "Preprocessing batch...",
                }))

        # Preprocess all images
        processed_list = []
        for img in images:
            processed_list.append(self.preprocessor.process_infer(img))

        # Stack into batch tensor [B, 1, H, W]
        tensors = [p["image"].unsqueeze(0) for p in processed_list]
        batch_tensor = torch.cat(tensors, dim=0).to(self.device)

        # Emit inference progress
        if on_progress:
            for tid in task_ids:
                from .schemas import SSEEvent
                on_progress(tid, SSEEvent("progress", {
                    "stage": "inference", "progress": 0.5, "message": f"Running batch inference (batch={batch_size})...",
                }))

        # Single batch forward pass
        with torch.no_grad():
            if self.config.inference.use_tta:
                outputs = apply_tta(self.model, batch_tensor)
            else:
                outputs = self.model(batch_tensor)

        # Move to CPU
        outputs = {k: v.cpu() if isinstance(v, torch.Tensor) else v for k, v in outputs.items()}

        # Emit postprocessing progress
        if on_progress:
            for tid in task_ids:
                from .schemas import SSEEvent
                on_progress(tid, SSEEvent("progress", {
                    "stage": "postprocessing", "progress": 0.8, "message": "Postprocessing batch...",
                }))

        # Per-image postprocessing
        results = {}
        for i, (processed, tid) in enumerate(zip(processed_list, task_ids)):
            restore = RestoreTransform(
                pad_info=processed["pad_info"],
                resize_scale=processed["resize_scale"],
                original_size=processed["original_size"],
            )

            cls_result = postprocess_classification(
                outputs.get("cls_prob", torch.zeros(batch_size, 2))[i],
            )

            seg_prob_i = outputs.get("seg_prob")
            seg_mask = None
            if seg_prob_i is not None:
                restored = restore(seg_prob_i[i])
                seg_mask = postprocess_segmentation(
                    restored.unsqueeze(0) if restored.dim() == 2 else restored,
                    threshold=self.config.inference.threshold,
                    use_largest_component=self.config.postprocess.use_largest_component,
                    min_region_size=self.config.postprocess.min_region_size,
                ).squeeze(0)

            edge_map = None
            edge_prob_i = outputs.get("edge_prob")
            if edge_prob_i is not None:
                edge_map = restore(edge_prob_i[i])

            uncertainty_map = None
            unc_i = outputs.get("uncertainty_map")
            if unc_i is not None:
                uncertainty_map = restore(unc_i[i])

            results[tid] = {
                "label": "malignant" if cls_result["pred_label"] == 1 else "benign",
                "label_index": cls_result["pred_label"],
                "prob_malignant": round(cls_result["prob_malignant"], 4),
                "prob_benign": round(cls_result["prob_benign"], 4),
                "seg_mask": tensor_to_base64_png(seg_mask) if seg_mask is not None else None,
                "edge_map": tensor_to_base64_png(edge_map) if edge_map is not None else None,
                "uncertainty_map": tensor_to_base64_png(uncertainty_map) if uncertainty_map is not None else None,
                "processing_time_ms": 0,  # Set below
            }

        elapsed_ms = int((time.perf_counter() - t_start) * 1000)
        for r in results.values():
            r["processing_time_ms"] = elapsed_ms

        return results
