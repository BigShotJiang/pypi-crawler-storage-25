"""SSE progress event management for inference tasks."""
import json
from typing import Callable, List, Optional

from .schemas import SSEEvent


class ProgressCallback:
    """Emits SSE progress events during inference substeps.

    Called by InferenceEngine between preprocessing -> inference -> postprocessing
    to notify SSE clients of current stage and progress.
    """

    def __init__(
        self,
        stages: List[str],
        on_event: Optional[Callable[[SSEEvent], None]] = None,
    ):
        self.stages = stages
        self._on_event = on_event

    def emit(self, stage: str, progress: float, message: str = "") -> None:
        """Emit a progress event."""
        event = SSEEvent(
            event="progress",
            data={
                "stage": stage,
                "progress": round(progress, 4),
                "message": message,
            },
        )
        if self._on_event is not None:
            self._on_event(event)
