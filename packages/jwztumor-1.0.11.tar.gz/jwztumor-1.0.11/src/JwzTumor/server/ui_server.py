"""Standalone static UI server helpers."""

from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse, Response


def create_ui_app(ui_dir: str, api_base_url: str) -> FastAPI:
    """Create a small FastAPI app that serves the built frontend."""
    app = FastAPI(title="JwzTumor UI", docs_url=None, redoc_url=None, openapi_url=None)
    root = Path(ui_dir).resolve()
    index_file = root / "index.html"

    @app.get("/config.js", include_in_schema=False)
    async def runtime_config():
        return Response(
            content=f'window.__JWZT_CONFIG__ = {{"apiBaseUrl": "{api_base_url}"}};',
            media_type="application/javascript",
        )

    @app.get("/", include_in_schema=False)
    async def serve_index():
        return FileResponse(index_file)

    @app.get("/{full_path:path}", include_in_schema=False)
    async def serve_static_or_index(full_path: str):
        candidate = (root / full_path).resolve()
        if root in candidate.parents and candidate.is_file():
            return FileResponse(candidate)
        return FileResponse(index_file)

    return app
