"""Health check endpoint."""
from fastapi import APIRouter

from ..schemas import HealthResponse

router = APIRouter()


def _get_state():
    """Lazy import to avoid circular deps at module level."""
    from ..app import get_app_state
    return get_app_state()


@router.get("/api/health", response_model=HealthResponse)
async def health_check():
    state = _get_state()
    return HealthResponse(
        status="healthy",
        model_loaded=state["engine"].is_loaded,
        device=str(state["engine"].device),
        busy=state["queue"].depth > 0,
        queue_depth=state["queue"].depth,
        max_queue=state["queue"].max_size,
    )
