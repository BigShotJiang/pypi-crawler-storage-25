"""Prediction API endpoints."""
import asyncio
import json
import logging
from typing import Optional

from fastapi import APIRouter, File, Form, Query, UploadFile
from fastapi.responses import JSONResponse, StreamingResponse

from ..schemas import (
    ErrorResponse,
    LRPredictResponse,
    PredictResponse,
    SSEEvent,
    TaskSubmitResponse,
)
from ..engine import decode_upload
from ..progress import ProgressCallback

logger = logging.getLogger(__name__)

router = APIRouter()

INFERENCE_STAGES = ["preprocessing", "inference", "postprocessing"]


def _get_state():
    from ..app import get_app_state
    return get_app_state()


async def _run_and_respond_single(image_bytes: bytes) -> PredictResponse:
    """Run single inference in thread and return response."""
    state = _get_state()
    image = decode_upload(image_bytes)

    result = await asyncio.to_thread(state["engine"].run_inference, image)

    return PredictResponse(**result)


async def _run_and_respond_lr(left_bytes: bytes, right_bytes: bytes) -> LRPredictResponse:
    """Run L/R inference in thread and return fused response."""
    state = _get_state()
    left_image = decode_upload(left_bytes)
    right_image = decode_upload(right_bytes)

    # Run both sequentially (single GPU)
    import time
    t_start = time.perf_counter()
    left_result = await asyncio.to_thread(state["engine"].run_inference, left_image)
    right_result = await asyncio.to_thread(state["engine"].run_inference, right_image)
    elapsed_ms = int((time.perf_counter() - t_start) * 1000)

    # Fuse: average probabilities
    fused_prob_malignant = round(
        (left_result["prob_malignant"] + right_result["prob_malignant"]) / 2, 4
    )
    fused_prob_benign = round(
        (left_result["prob_benign"] + right_result["prob_benign"]) / 2, 4
    )
    fused_label_index = 1 if fused_prob_malignant >= 0.5 else 0
    fused_label = "malignant" if fused_label_index == 1 else "benign"

    return LRPredictResponse(
        left=PredictResponse(**left_result),
        right=PredictResponse(**right_result),
        fused_label=fused_label,
        fused_label_index=fused_label_index,
        fused_prob_malignant=fused_prob_malignant,
        fused_prob_benign=fused_prob_benign,
        processing_time_ms=elapsed_ms,
    )


@router.post("/api/predict")
async def predict_single(
    file: UploadFile = File(...),
    async_mode: Optional[str] = Query(None, alias="async"),
):
    """Single image prediction — sync or async (SSE)."""
    # Read file bytes
    file_bytes = await file.read()
    logger.info(
        "Prediction request received: mode=single async=%s filename=%s bytes=%d",
        bool(async_mode and async_mode.lower() == "true"),
        file.filename or "-",
        len(file_bytes),
    )

    # Validate size
    state = _get_state()
    max_bytes = state.get("max_upload_bytes", 10 * 1024 * 1024)
    if len(file_bytes) > max_bytes:
        return JSONResponse(
            status_code=413,
            content={"error": "payload_too_large", "detail": f"File exceeds {max_bytes // (1024*1024)}MB limit"},
        )

    # Validate image can be decoded
    try:
        decode_upload(file_bytes)
    except ValueError as e:
        return JSONResponse(
            status_code=422,
            content={"error": "invalid_image", "detail": str(e)},
        )

    # Async mode: submit to queue, return task_id
    if async_mode and async_mode.lower() == "true":
        queue = state["queue"]
        if queue.is_full:
            return JSONResponse(
                status_code=503,
                content={"error": "queue_full", "detail": "Inference queue is full. Try again later."},
            )
        # Decode to numpy for queue storage
        image_np = decode_upload(file_bytes)
        task_id = queue.submit(image_np, "single")
        logger.info(
            "Prediction task queued: task_id=%s mode=single filename=%s queue_depth=%d",
            task_id,
            file.filename or "-",
            queue.depth,
        )
        return TaskSubmitResponse(task_id=task_id)

    # Sync mode: run directly
    try:
        resp = await _run_and_respond_single(file_bytes)
        logger.info(
            "Prediction request completed: mode=single filename=%s label=%s prob_malignant=%.4f processing_time_ms=%s",
            file.filename or "-",
            resp.label,
            resp.prob_malignant,
            resp.processing_time_ms,
        )
        return resp
    except Exception as e:
        logger.exception("Inference failed")
        return JSONResponse(
            status_code=500,
            content={"error": "inference_error", "detail": str(e)},
        )


@router.post("/api/predict/lr")
async def predict_lr(
    left: UploadFile = File(...),
    right: UploadFile = File(...),
    async_mode: Optional[str] = Query(None, alias="async"),
):
    """L/R dual image prediction — sync or async (SSE)."""
    left_bytes = await left.read()
    right_bytes = await right.read()
    logger.info(
        "Prediction request received: mode=dual async=%s left_filename=%s right_filename=%s left_bytes=%d right_bytes=%d",
        bool(async_mode and async_mode.lower() == "true"),
        left.filename or "-",
        right.filename or "-",
        len(left_bytes),
        len(right_bytes),
    )

    state = _get_state()
    max_bytes = state.get("max_upload_bytes", 10 * 1024 * 1024)
    for name, data in [("left", left_bytes), ("right", right_bytes)]:
        if len(data) > max_bytes:
            return JSONResponse(
                status_code=413,
                content={"error": "payload_too_large", "detail": f"File '{name}' exceeds {max_bytes // (1024*1024)}MB limit"},
            )

    # Validate both images
    try:
        decode_upload(left_bytes)
    except ValueError as e:
        return JSONResponse(status_code=422, content={"error": "invalid_image", "detail": f"Left image: {e}"})
    try:
        decode_upload(right_bytes)
    except ValueError as e:
        return JSONResponse(status_code=422, content={"error": "invalid_image", "detail": f"Right image: {e}"})

    # Async mode
    if async_mode and async_mode.lower() == "true":
        queue = state["queue"]
        if queue.is_full:
            return JSONResponse(
                status_code=503,
                content={"error": "queue_full", "detail": "Inference queue is full. Try again later."},
            )
        left_np = decode_upload(left_bytes)
        right_np = decode_upload(right_bytes)
        task_id = queue.submit_lr(left_np, right_np)
        logger.info(
            "Prediction task queued: task_id=%s mode=dual left_filename=%s right_filename=%s queue_depth=%d",
            task_id,
            left.filename or "-",
            right.filename or "-",
            queue.depth,
        )
        return TaskSubmitResponse(task_id=task_id)

    # Sync mode
    try:
        resp = await _run_and_respond_lr(left_bytes, right_bytes)
        logger.info(
            "Prediction request completed: mode=dual left_filename=%s right_filename=%s fused_label=%s fused_prob_malignant=%.4f processing_time_ms=%s",
            left.filename or "-",
            right.filename or "-",
            resp.fused_label,
            resp.fused_prob_malignant,
            resp.processing_time_ms,
        )
        return resp
    except Exception as e:
        logger.exception("L/R inference failed")
        return JSONResponse(
            status_code=500,
            content={"error": "inference_error", "detail": str(e)},
        )


@router.get("/api/tasks/{task_id}/stream")
async def task_stream(task_id: str):
    """SSE stream for async task progress and results."""
    state = _get_state()
    queue = state["queue"]

    task = queue.get_task(task_id)
    if task is None:
        return JSONResponse(
            status_code=404,
            content={"error": "not_found", "detail": f"Task {task_id} not found"},
        )

    async def event_generator():
        # Emit queued event
        queue_event = SSEEvent(
            event="queued",
            data={
                "task_id": task_id,
                "queue_position": queue.depth,
                "status": "queued",
                "stages": INFERENCE_STAGES,
            },
        )
        yield queue_event.encode()

        # Poll for progress events and terminal states
        while True:
            await asyncio.sleep(0.05)

            # Drain any accumulated progress events
            for evt in queue.drain_progress_events(task_id):
                yield evt.encode()

            task = queue.get_task(task_id)
            if task is None:
                yield SSEEvent(event="error", data={"task_id": task_id, "error": "Task lost"}).encode()
                return
            if task["status"] == "completed":
                yield SSEEvent(
                    event="complete",
                    data={"task_id": task_id, "result": task["result"]},
                ).encode()
                return
            if task["status"] == "error":
                yield SSEEvent(
                    event="error",
                    data={"task_id": task_id, "error": task["result"].get("error", "Unknown error")},
                ).encode()
                return

    return StreamingResponse(event_generator(), media_type="text/event-stream")
