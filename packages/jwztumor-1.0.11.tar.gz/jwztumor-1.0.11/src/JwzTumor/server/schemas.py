"""Pydantic request/response models for the inference server."""
import json
from typing import Optional

from pydantic import BaseModel, Field


class PredictResponse(BaseModel):
    """Single image prediction result."""
    label: str = Field(..., description="Predicted label: 'benign' or 'malignant'")
    label_index: int = Field(..., description="0=benign, 1=malignant")
    prob_malignant: float = Field(..., description="Malignant probability [0,1]")
    prob_benign: float = Field(..., description="Benign probability [0,1]")
    seg_mask: Optional[str] = Field(None, description="Base64-encoded PNG segmentation mask")
    edge_map: Optional[str] = Field(None, description="Base64-encoded PNG edge map")
    uncertainty_map: Optional[str] = Field(None, description="Base64-encoded PNG uncertainty map")
    processing_time_ms: int = Field(..., description="Processing time in milliseconds")


class LRPredictResponse(BaseModel):
    """L/R dual image prediction result."""
    left: PredictResponse
    right: PredictResponse
    fused_label: str = Field(..., description="Fused prediction label")
    fused_label_index: int = Field(..., description="Fused label index")
    fused_prob_malignant: float = Field(..., description="Fused malignant probability (average)")
    fused_prob_benign: float = Field(..., description="Fused benign probability (average)")
    processing_time_ms: int = Field(..., description="Total processing time in milliseconds")


class HealthResponse(BaseModel):
    """Health check response."""
    status: str
    model_loaded: bool
    device: str
    busy: bool
    queue_depth: int
    max_queue: int


class TaskSubmitResponse(BaseModel):
    """Response for async task submission."""
    task_id: str


class ErrorResponse(BaseModel):
    """Standard error response."""
    error: str
    detail: str


class SSEEvent:
    """Server-Sent Event wrapper."""

    def __init__(self, event: str, data: dict):
        self.event = event
        self.data = data

    def encode(self) -> str:
        """Encode as SSE text format."""
        data_str = json.dumps(self.data, ensure_ascii=False)
        return f"event: {self.event}\ndata: {data_str}\n\n"
