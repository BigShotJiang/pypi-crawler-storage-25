window.__JWZT_CONFIG__ = window.__JWZT_CONFIG__ || {};
