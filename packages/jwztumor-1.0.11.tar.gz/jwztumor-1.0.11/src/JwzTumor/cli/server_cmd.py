"""Server command for JwzTumor CLI."""
import json
import typer
from typing import Any, Dict, Optional
from pathlib import Path

server_app = typer.Typer(help="启动推理服务 API")


@server_app.callback(invoke_without_command=True)
def server(
    model: Optional[str] = typer.Option(None, "--model", "-m", envvar="JWZT_MODEL", help="模型检查点路径"),
    config: str = typer.Option(
        "configs/infer_busi.yaml",
        "--config",
        "-c",
        envvar="JWZT_CONFIG",
        help="配置文件路径",
    ),
    host: Optional[str] = typer.Option(None, "--host", envvar="JWZT_HOST", help="监听地址"),
    port: Optional[int] = typer.Option(None, "--port", envvar="JWZT_PORT", help="监听端口"),
    device: Optional[str] = typer.Option(None, "--device", envvar="JWZT_DEVICE", help="推理设备 (auto/cuda/cpu)"),
    tta: Optional[bool] = typer.Option(None, "--tta/--no-tta", envvar="JWZT_TTA", help="启用/禁用 TTA"),
    max_queue: Optional[int] = typer.Option(None, "--max-queue", envvar="JWZT_MAX_QUEUE", help="最大排队任务数"),
    max_upload_mb: Optional[int] = typer.Option(
        None, "--max-upload-mb", envvar="JWZT_MAX_UPLOAD_MB", help="最大上传文件大小 (MB)"
    ),
    max_batch_size: Optional[int] = typer.Option(
        None, "--max-batch-size", envvar="JWZT_MAX_BATCH_SIZE", help="最大批处理任务数 (自动凑批)"
    ),
    cors_origins: Optional[str] = typer.Option(None, "--cors-origins", envvar="JWZT_CORS_ORIGINS", help="CORS 允许的源 (逗号分隔)"),
    log_dir: Optional[str] = typer.Option(None, "--log-dir", envvar="JWZT_LOG_DIR", help="服务日志保存目录"),
    with_ui: Optional[bool] = typer.Option(None, "--with-ui/--no-with-ui", envvar="JWZT_WITH_UI", help="托管前端静态网页"),
    ui_dir: Optional[str] = typer.Option(None, "--ui-dir", envvar="JWZT_UI_DIR", help="前端 dist 静态目录"),
    ui_host: Optional[str] = typer.Option(None, "--ui-host", envvar="JWZT_UI_HOST", help="前端静态服务监听地址"),
    ui_port: Optional[int] = typer.Option(
        None,
        "--ui-port",
        envvar="JWZT_UI_PORT",
        help="前端静态服务监听端口；不传则与 API 同端口",
    ),
    ui_api_base_url: Optional[str] = typer.Option(
        None,
        "--ui-api-base-url",
        envvar="JWZT_UI_API_BASE_URL",
        help="注入前端的 API 地址",
    ),
    no_ui: Optional[bool] = typer.Option(None, "--no-ui", envvar="JWZT_NO_UI", help="显式禁用前端 UI 托管"),
    report_llm_enabled: Optional[bool] = typer.Option(
        None,
        "--report-llm-enabled/--no-report-llm-enabled",
        envvar="JWZT_REPORT_LLM_ENABLED",
        help="启用/禁用报告 LLM",
    ),
    report_llm_base_url: Optional[str] = typer.Option(
        None,
        "--report-llm-base-url",
        envvar="JWZT_REPORT_LLM_BASE_URL",
        help="OpenAI-Compatible 报告 LLM Base URL",
    ),
    report_llm_api_key: Optional[str] = typer.Option(
        None,
        "--report-llm-api-key",
        envvar="JWZT_REPORT_LLM_API_KEY",
        help="OpenAI-Compatible 报告 LLM API Key",
    ),
    report_llm_model: Optional[str] = typer.Option(
        None,
        "--report-llm-model",
        envvar="JWZT_REPORT_LLM_MODEL",
        help="OpenAI-Compatible 报告 LLM 模型名",
    ),
    report_llm_timeout: Optional[float] = typer.Option(
        None,
        "--report-llm-timeout",
        envvar="JWZT_REPORT_LLM_TIMEOUT",
        help="报告 LLM 请求超时时间（秒）",
    ),
    report_llm_max_retries: Optional[int] = typer.Option(
        None,
        "--report-llm-max-retries",
        envvar="JWZT_REPORT_LLM_MAX_RETRIES",
        help="报告 LLM 最大重试次数",
    ),
    report_llm_temperature: Optional[float] = typer.Option(
        None,
        "--report-llm-temperature",
        envvar="JWZT_REPORT_LLM_TEMPERATURE",
        help="报告 LLM 温度参数",
    ),
    report_llm_max_tokens: Optional[int] = typer.Option(
        None,
        "--report-llm-max-tokens",
        envvar="JWZT_REPORT_LLM_MAX_TOKENS",
        help="报告 LLM 最大输出 token 数",
    ),
    report_llm_multimodal_enabled: Optional[bool] = typer.Option(
        None,
        "--report-llm-multimodal/--no-report-llm-multimodal",
        envvar="JWZT_REPORT_LLM_MULTIMODAL_ENABLED",
        help="启用/禁用报告 LLM 多模态图片输入",
    ),
    report_llm_startup_check: Optional[bool] = typer.Option(
        None,
        "--report-llm-startup-check/--no-report-llm-startup-check",
        envvar="JWZT_REPORT_LLM_STARTUP_CHECK",
        help="启用/禁用报告 LLM 启动自检",
    ),
    report_llm_image_input_mode: Optional[str] = typer.Option(
        None,
        "--report-llm-image-input-mode",
        envvar="JWZT_REPORT_LLM_IMAGE_INPUT_MODE",
        help="报告 LLM 图片输入模式: data_url/public_url",
    ),
    report_llm_public_base_url: Optional[str] = typer.Option(
        None,
        "--report-llm-public-base-url",
        envvar="JWZT_REPORT_LLM_PUBLIC_BASE_URL",
        help="public_url 模式下当前服务公网可访问的根地址",
    ),
    report_llm_startup_image_url: Optional[str] = typer.Option(
        None,
        "--report-llm-startup-image-url",
        envvar="JWZT_REPORT_LLM_STARTUP_IMAGE_URL",
        help="public_url 模式下用于启动自检的公网图片 URL",
    ),
    report_llm_thinking_disable_param: Optional[str] = typer.Option(
        None,
        "--report-llm-thinking-disable-param",
        envvar="JWZT_REPORT_LLM_THINKING_DISABLE_PARAM",
        help='关闭思考模式的 JSON 请求体参数，例如 \'{"enable_thinking": false}\'',
    ),
    report_llm_extra_body: Optional[str] = typer.Option(
        None,
        "--report-llm-extra-body",
        envvar="JWZT_REPORT_LLM_EXTRA_BODY",
        help="附加到 OpenAI-Compatible 请求体的 JSON 对象",
    ),
):
    """启动 JwzTumor 推理服务。"""
    import os
    import logging
    import uvicorn

    from ..utils.config import load_config
    from ..server.engine import InferenceEngine
    from ..server.queue import PredictQueue
    from ..server.app import create_app
    from ..server.report.providers import create_provider_from_env
    from ..server.report.service import ReportService

    # ---- ASCII Art Banner ----
    banner = r"""
[bold cyan]
       _                    _______
      | |                  |__   __|
      | | __      __  ____    | |     _   _   _ __ ___     ___    _ __
  _   | | \ \ /\ / / |_  /    | |    | | | | | '_ ` _ \   / _ \  | '__|
 | |__| |  \ V  V /   / /     | |    | |_| | | | | | | | | (_) | | |
  \____/    \_/\_/   /___|    |_|     \__,_| |_| |_| |_|  \___/  |_|
[/bold cyan]
[dim]  ──────────────────────────────────────────────────────────────────────[/dim]
[bold white]  Breast Ultrasound Benign-Malignant Diagnosis[/bold white]
[dim]  Inference Server[/dim]
[dim]  Author: SuShuheng | License: Apache-2.0[/dim]
"""

    try:
        from rich.console import Console
        console = Console()
        console.print(banner)
    except ImportError:
        typer.echo(banner)

    # ---- Load Config and resolve CLI/env overrides ----
    cfg = load_config(config)
    server_cfg = cfg.server
    model = _resolve_option(model, server_cfg.model)
    host = _resolve_option(host, server_cfg.host)
    port = _resolve_option(port, server_cfg.port)
    device = _resolve_option(device, server_cfg.device)
    tta = _resolve_option(tta, server_cfg.tta)
    max_queue = _resolve_option(max_queue, server_cfg.max_queue)
    max_upload_mb = _resolve_option(max_upload_mb, server_cfg.max_upload_mb)
    max_batch_size = _resolve_option(max_batch_size, server_cfg.max_batch_size)
    cors_origins = _resolve_option(cors_origins, server_cfg.cors_origins)
    log_dir = _resolve_option(log_dir, server_cfg.log_dir)
    with_ui = _resolve_option(with_ui, server_cfg.with_ui)
    ui_dir = _resolve_option(ui_dir, server_cfg.ui_dir)
    ui_host = _resolve_option(ui_host, server_cfg.ui_host)
    ui_port = _resolve_option(ui_port, server_cfg.ui_port)
    ui_api_base_url = _resolve_option(ui_api_base_url, server_cfg.ui_api_base_url)
    no_ui = _resolve_option(no_ui, server_cfg.no_ui)
    if not model:
        raise typer.BadParameter("model checkpoint is required via --model, JWZT_MODEL, or server.model in config")

    # ---- Setup Logging ----
    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)

    # Root logger config
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)

    # File handler
    file_handler = logging.FileHandler(log_path / "server.log", encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    file_handler.setFormatter(file_fmt)
    root_logger.addHandler(file_handler)

    # Rich console handler
    try:
        from rich.logging import RichHandler
        console_handler = RichHandler(
            level=logging.INFO,
            show_time=True,
            show_path=False,
            markup=True,
        )
        root_logger.addHandler(console_handler)
    except ImportError:
        stream_handler = logging.StreamHandler()
        stream_handler.setLevel(logging.INFO)
        stream_handler.setFormatter(file_fmt)
        root_logger.addHandler(stream_handler)

    logger = logging.getLogger(__name__)

    if device is not None:
        cfg.training.device = device
    if tta is not None:
        cfg.inference.use_tta = tta

    # ---- Load Model ----
    engine = InferenceEngine(cfg)
    logger.info("Loading model from %s ...", model)
    engine.load_checkpoint(model)
    logger.info("Model loaded on %s", engine.device)

    # ---- Create App ----
    queue = PredictQueue(max_size=max_queue)
    resolved_ui_dir = _resolve_ui_dir(ui_dir, with_ui and not no_ui)
    resolved_ui_host = ui_host or host
    resolved_ui_api_base_url = _resolve_ui_api_base_url(
        explicit_url=ui_api_base_url,
        host=host,
        port=port,
        same_port=ui_port is None,
    )
    same_port_ui_dir = resolved_ui_dir if resolved_ui_dir and ui_port is None else None

    provider = create_provider_from_env(
        _build_report_llm_env(
            cfg.report_llm,
            enabled=report_llm_enabled,
            base_url=report_llm_base_url,
            api_key=report_llm_api_key,
            model=report_llm_model,
            timeout=report_llm_timeout,
            max_retries=report_llm_max_retries,
            temperature=report_llm_temperature,
            max_tokens=report_llm_max_tokens,
            multimodal_enabled=report_llm_multimodal_enabled,
            startup_check=report_llm_startup_check,
            image_input_mode=report_llm_image_input_mode,
            public_base_url=report_llm_public_base_url,
            startup_image_url=report_llm_startup_image_url,
            thinking_disable_param=report_llm_thinking_disable_param,
            extra_body=report_llm_extra_body,
        )
    )
    if getattr(provider, "startup_check", False):
        import asyncio

        logger.info("Running report LLM startup check ...")
        asyncio.run(provider.check_startup())
        logger.info("Report LLM startup check passed")

    app = create_app(
        engine=engine,
        queue=queue,
        cors_origins=cors_origins,
        max_upload_bytes=max_upload_mb * 1024 * 1024,
        max_batch_size=max_batch_size,
        report_service=ReportService(provider=provider),
        ui_dir=same_port_ui_dir,
        ui_api_base_url=resolved_ui_api_base_url,
    )

    if resolved_ui_dir and ui_port is not None:
        _start_separate_ui_server(
            ui_dir=resolved_ui_dir,
            ui_host=resolved_ui_host,
            ui_port=ui_port,
            api_base_url=resolved_ui_api_base_url,
        )

    logger.info("Starting server at http://%s:%d", host, port)
    logger.info("API docs: http://%s:%d/docs", host, port)
    logger.info("Logs directory: %s", log_path.resolve())
    logger.info("Max batch size: %d, Max queue: %d", max_batch_size, max_queue)
    if same_port_ui_dir:
        logger.info("UI: http://%s:%d (dir=%s)", host, port, resolved_ui_dir)
    elif resolved_ui_dir and ui_port is not None:
        logger.info("UI: http://%s:%d (dir=%s)", resolved_ui_host, ui_port, resolved_ui_dir)

    # ---- Run ----
    uvicorn.run(app, host=host, port=port, log_level="warning")


def _resolve_ui_dir(ui_dir: Optional[str], with_ui: bool) -> Optional[str]:
    """Resolve external or package-bundled UI directory."""
    if ui_dir:
        return str(Path(ui_dir).resolve())
    if not with_ui:
        return None
    package_ui = Path(__file__).resolve().parents[1] / "server" / "ui"
    if (package_ui / "index.html").exists():
        return str(package_ui)
    return None


def _resolve_option(cli_value: Any, config_value: Any) -> Any:
    """Use CLI/env value when present, otherwise use YAML config value."""
    return config_value if cli_value is None else cli_value


def _build_report_llm_env(
    config: Any,
    *,
    enabled: Optional[bool] = None,
    base_url: Optional[str],
    api_key: Optional[str],
    model: Optional[str],
    timeout: Optional[float],
    max_retries: Optional[int],
    temperature: Optional[float],
    max_tokens: Optional[int] = None,
    multimodal_enabled: Optional[bool] = None,
    startup_check: Optional[bool] = None,
    image_input_mode: Optional[str] = None,
    public_base_url: Optional[str] = None,
    startup_image_url: Optional[str] = None,
    thinking_disable_param: Optional[str] = None,
    extra_body: Optional[str] = None,
) -> Dict[str, str]:
    """Merge process env, server YAML, and explicit CLI/env LLM options."""
    import os

    values: Dict[str, str] = dict(os.environ)
    config_mapping = {
        "JWZT_REPORT_LLM_ENABLED": config.enabled,
        "JWZT_REPORT_LLM_BASE_URL": config.base_url,
        "JWZT_REPORT_LLM_API_KEY": config.api_key,
        "JWZT_REPORT_LLM_MODEL": config.model,
        "JWZT_REPORT_LLM_TIMEOUT": config.timeout,
        "JWZT_REPORT_LLM_MAX_RETRIES": config.max_retries,
        "JWZT_REPORT_LLM_TEMPERATURE": config.temperature,
        "JWZT_REPORT_LLM_MAX_TOKENS": config.max_tokens,
        "JWZT_REPORT_LLM_MULTIMODAL_ENABLED": config.multimodal_enabled,
        "JWZT_REPORT_LLM_STARTUP_CHECK": config.startup_check,
        "JWZT_REPORT_LLM_IMAGE_INPUT_MODE": config.image_input_mode,
        "JWZT_REPORT_LLM_PUBLIC_BASE_URL": config.public_base_url,
        "JWZT_REPORT_LLM_STARTUP_IMAGE_URL": config.startup_image_url,
        "JWZT_REPORT_LLM_THINKING_DISABLE_PARAM": config.thinking_disable_param,
        "JWZT_REPORT_LLM_EXTRA_BODY": config.extra_body,
    }
    for key, value in config_mapping.items():
        if value not in (None, "", {}):
            values[key] = _stringify_report_llm_value(value)

    explicit_mapping = {
        "JWZT_REPORT_LLM_ENABLED": enabled,
        "JWZT_REPORT_LLM_BASE_URL": base_url,
        "JWZT_REPORT_LLM_API_KEY": api_key,
        "JWZT_REPORT_LLM_MODEL": model,
        "JWZT_REPORT_LLM_TIMEOUT": timeout,
        "JWZT_REPORT_LLM_MAX_RETRIES": max_retries,
        "JWZT_REPORT_LLM_TEMPERATURE": temperature,
        "JWZT_REPORT_LLM_MAX_TOKENS": max_tokens,
        "JWZT_REPORT_LLM_MULTIMODAL_ENABLED": multimodal_enabled,
        "JWZT_REPORT_LLM_STARTUP_CHECK": startup_check,
        "JWZT_REPORT_LLM_IMAGE_INPUT_MODE": image_input_mode,
        "JWZT_REPORT_LLM_PUBLIC_BASE_URL": public_base_url,
        "JWZT_REPORT_LLM_STARTUP_IMAGE_URL": startup_image_url,
        "JWZT_REPORT_LLM_THINKING_DISABLE_PARAM": thinking_disable_param,
        "JWZT_REPORT_LLM_EXTRA_BODY": extra_body,
    }
    for key, value in explicit_mapping.items():
        if value is not None:
            values[key] = _stringify_report_llm_value(value)
    return values


def _stringify_report_llm_value(value: Any) -> str:
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def _resolve_ui_api_base_url(
    explicit_url: Optional[str],
    host: str,
    port: int,
    same_port: bool,
) -> str:
    """Resolve the browser-facing API base URL for hosted UI."""
    if explicit_url is not None:
        return explicit_url
    if same_port:
        return ""
    browser_host = "127.0.0.1" if host in {"0.0.0.0", "::"} else host
    return f"http://{browser_host}:{port}"


def _start_separate_ui_server(
    ui_dir: str,
    ui_host: str,
    ui_port: int,
    api_base_url: str,
) -> None:
    """Start a separate static UI uvicorn server in a daemon thread."""
    import threading
    import uvicorn

    from ..server.ui_server import create_ui_app

    ui_app = create_ui_app(ui_dir=ui_dir, api_base_url=api_base_url)

    def _run():
        uvicorn.run(ui_app, host=ui_host, port=ui_port, log_level="warning")

    thread = threading.Thread(target=_run, name="jwzt-ui-server", daemon=True)
    thread.start()
