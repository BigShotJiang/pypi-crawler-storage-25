"""CLI Main Entry Point for JwzTumor."""
import typer

app = typer.Typer(
    name="jwzt",
    help="JwzTumor: 乳腺超声良恶性诊断 - 分割辅助多任务学习框架",
    no_args_is_help=True,
)

from .train_cmd import train_app
from .pred_cmd import predict_app
from .eval_cmd import eval_app
from .get_cmd import get_app
from .audit_cmd import audit_app
from .server_cmd import server_app
from .version_cmd import version_cmd

app.add_typer(train_app, name="train")
app.add_typer(predict_app, name="pred")
app.add_typer(eval_app, name="eval")
app.add_typer(get_app, name="get")
app.add_typer(audit_app, name="audit-data")
app.add_typer(server_app, name="server")
app.command(name="version")(version_cmd)


def run():
    app()


if __name__ == "__main__":
    run()
