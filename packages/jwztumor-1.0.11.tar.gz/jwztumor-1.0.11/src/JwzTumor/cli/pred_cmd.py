"""Predict command for JwzTumor CLI."""
import typer
from typing import Optional

predict_app = typer.Typer(help="对新数据进行推理预测")


@predict_app.callback(invoke_without_command=True)
def predict(
    config: str = typer.Option("configs/infer_busi.yaml", "--config", "-c", help="YAML 配置文件路径"),
    model: str = typer.Option("checkpoints/best_auc.ckpt", "--model", "-m", help="模型检查点路径"),
    data: str = typer.Option("dataset/Dataset_BUSI_with_GT", "--data", "-d", help="数据目录"),
    output: str = typer.Option("outputs/busi_predictions", "--output", "-o", help="输出目录"),
    mode: str = typer.Option("batch", "--mode", help="预测模式: single / batch"),
    use_tta: bool = typer.Option(True, "--tta/--no-tta", help="启用/禁用测试时增强 (TTA)"),
    batch_size: Optional[int] = typer.Option(None, "--batch-size", "-b", help="推理批大小 (默认使用训练配置)"),
    threshold: Optional[float] = typer.Option(None, "--threshold", help="分割阈值"),
    save_overlay: bool = typer.Option(True, "--save-overlay/--no-save-overlay", help="保存叠加可视化结果"),
    save_heatmap: bool = typer.Option(True, "--save-heatmap/--no-save-heatmap", help="保存热力图"),
    save_uncertainty: bool = typer.Option(True, "--save-uncertainty/--no-save-uncertainty", help="保存不确定性图"),
    save_edge: bool = typer.Option(True, "--save-edge/--no-save-edge", help="保存边缘检测结果"),
    restore_original_size: bool = typer.Option(True, "--restore-original-size/--no-restore-original-size", help="恢复为原始图像尺寸"),
    cache_mode: Optional[str] = typer.Option(None, "--cache-mode", help="缓存模式: ram / disk / none"),
    report: bool = typer.Option(False, "--report", help="预测完成后输出评估指标报告"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="详细日志模式"),
):
    """对 BUSI 或自定义数据进行推理预测。"""
    from .predict_impl import run_prediction

    overrides = {}
    if threshold is not None:
        overrides["inference.threshold"] = threshold
    if cache_mode:
        overrides["dataset.cache_mode"] = cache_mode
    overrides["inference.model_path"] = model
    overrides["inference.output_dir"] = output
    overrides["inference.mode"] = mode
    overrides["inference.use_tta"] = use_tta

    run_prediction(
        config_path=config,
        data_path=data,
        output_dir=output,
        overrides=overrides,
        verbose=verbose,
        report=report,
        batch_size=batch_size,
    )
