"""Multi-task predictor for JwzTumor."""
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import torch
import torch.nn as nn

from ..data.preprocessing import BreastUSPreprocessor, RestoreTransform
from ..data.busi_dataset import BUSIDataset
from ..data.collate import multitask_collate_fn

logger = logging.getLogger(__name__)


def _warmup_model(model: nn.Module, device: torch.device, input_size: int = 512) -> None:
    """Run a dummy forward pass to pre-allocate CUDA memory pools.

    PyTorch's CUDA allocator is lazy -- it grabs large memory blocks on first
    use, causing a transient VRAM spike.  A warmup pass triggers all
    allocations upfront so subsequent inference runs at a stable VRAM level.
    """
    if device.type != "cuda":
        return
    dummy = torch.randn(1, 1, input_size, input_size, device=device)
    with torch.no_grad():
        _ = model(dummy)
    del dummy
    torch.cuda.empty_cache()
    logger.info("Model warmup complete on %s", device)


class MultiTaskPredictor:
    """Multi-task predictor for breast ultrasound diagnosis.

    Handles:
        - Model loading
        - Batch/single inference
        - TTA (Test-Time Augmentation)
        - Output post-processing and restoration
    """

    def __init__(
        self,
        model: nn.Module,
        config,
        device: Optional[str] = None,
    ):
        self.model = model
        self.config = config
        self.device = torch.device(
            device or ("cuda" if torch.cuda.is_available() else "cpu")
        )
        self.model.to(self.device)
        self.model.eval()

        # Warmup: pre-allocate CUDA memory to avoid VRAM spikes during inference
        input_size = getattr(config.dataset, "model_input_size", 512)
        _warmup_model(self.model, self.device, input_size)

        self.preprocessor = BreastUSPreprocessor(
            model_input_size=config.dataset.model_input_size,
            pad_mode=config.dataset.pad_mode,
        )

    @classmethod
    def from_checkpoint(
        cls,
        config,
        checkpoint_path: str,
        model_fn=None,
        device: Optional[str] = None,
    ) -> "MultiTaskPredictor":
        """Create predictor from checkpoint file."""
        if model_fn is None:
            from ..models.model_factory import create_model
            model = create_model(config)
        else:
            model = model_fn(config)

        ckpt = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        model.load_state_dict(ckpt["model_state_dict"])
        logger.info("Loaded checkpoint from %s (epoch=%d)", checkpoint_path, ckpt.get("epoch", -1))

        return cls(model, config, device)

    def predict_single(self, image: np.ndarray) -> Dict[str, Any]:
        """Predict on a single image.

        Args:
            image: Raw image array [H, W] or [H, W, C].

        Returns:
            Dict with cls_prob, seg_prob, edge_prob, sdm_pred, uncertainty_map, meta.
        """
        processed = self.preprocessor.process_infer(image)

        image_tensor = processed["image"].unsqueeze(0).to(self.device)

        with torch.no_grad():
            outputs = self.model(image_tensor)

        # Restore spatial outputs to original size
        restore = RestoreTransform(
            pad_info=processed["pad_info"],
            resize_scale=processed["resize_scale"],
            original_size=processed["original_size"],
        )

        result = {
            "cls_prob": outputs.get("cls_prob", torch.zeros(1, 2)).cpu(),
            "meta": {
                "original_size": processed["original_size"],
                "pad_info": processed["pad_info"],
                "resize_scale": processed["resize_scale"],
            },
        }

        # Restore spatial maps
        for key in ["seg_prob", "edge_prob", "sdm_pred", "uncertainty_map", "coarse_mask"]:
            if key in outputs:
                result[key] = restore(outputs[key].cpu())

        return result

    def predict_batch(
        self,
        dataset,
        output_dir: str,
        use_tta: bool = False,
        tta_fn=None,
        verbose: bool = False,
        display=None,
        batch_size: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """Run batch prediction on a dataset.

        Args:
            dataset: Dataset instance.
            output_dir: Output directory path.
            use_tta: Whether to use TTA.
            tta_fn: Optional TTA function.
            verbose: Whether to log verbosely.
            display: Optional VerboseLiveDisplay for verbose mode progress + log panel.
            batch_size: Inference batch size (defaults to config.training.batch_size).

        Returns:
            List of prediction dicts.
        """
        from torch.utils.data import DataLoader
        from .postprocessing import postprocess_segmentation, postprocess_classification
        from .visualization import save_prediction_outputs

        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        if batch_size is None:
            batch_size = self.config.training.batch_size

        use_cuda = self.device.type == "cuda"
        loader = DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=0,
            collate_fn=multitask_collate_fn,
            pin_memory=use_cuda,
        )

        predictions = []

        # Create progress bar
        if display is not None:
            display.start(total=len(loader), description="Predicting")
        else:
            from ..utils.rich_display import create_prediction_progress
            progress, task_id = create_prediction_progress(
                total_steps=len(loader),
                description="Predicting",
            )

        try:
            for batch_idx, batch in enumerate(loader):
                images = batch["image"].to(self.device, non_blocking=use_cuda)

                with torch.inference_mode():
                    if use_tta and tta_fn is not None:
                        outputs = tta_fn(self.model, images)
                    else:
                        outputs = self.model(images)

                # Process each sample in batch
                batch_size = images.shape[0]
                for i in range(batch_size):
                    meta = batch["meta"][i] if "meta" in batch else {}

                    pred = {
                        "image_id": meta.get("image_id", f"sample_{batch_idx}_{i}"),
                        "cls_prob": outputs["cls_prob"][i].cpu() if "cls_prob" in outputs else None,
                        "seg_prob": outputs["seg_prob"][i].cpu() if "seg_prob" in outputs else None,
                        "edge_prob": outputs["edge_prob"][i].cpu() if "edge_prob" in outputs else None,
                        "uncertainty_map": outputs["uncertainty_map"][i].cpu() if "uncertainty_map" in outputs else None,
                        "meta": meta,
                        "true_label": batch["label"][i].item() if "label" in batch else None,
                    }

                    # Postprocess
                    if pred["seg_prob"] is not None:
                        pred["seg_mask"] = postprocess_segmentation(
                            pred["seg_prob"].unsqueeze(0),
                            threshold=self.config.inference.threshold,
                        ).squeeze(0)

                    # Classification postprocess
                    if pred["cls_prob"] is not None:
                        cls_result = postprocess_classification(pred["cls_prob"])
                        pred["pred_label"] = cls_result["pred_label"]
                        pred["prob_benign"] = cls_result["prob_benign"]
                        pred["prob_malignant"] = cls_result["prob_malignant"]

                    # Restore to original size
                    if "original_size" in meta and pred.get("seg_mask") is not None:
                        restore = RestoreTransform(
                            pad_info=meta.get("pad_info", {"top": 0, "bottom": 0, "left": 0, "right": 0}),
                            resize_scale=meta.get("resize_scale", 1.0),
                            original_size=meta["original_size"],
                        )
                        pred["seg_mask_restored"] = restore(pred["seg_mask"].unsqueeze(0)).squeeze(0)

                    predictions.append(pred)

                # Update progress
                done = len(predictions)
                if display is not None:
                    display.update_progress(advance=1, postfix=f"done={done}")
                else:
                    progress.update(task_id, advance=1, postfix=f"done={done}")
        finally:
            if display is not None:
                display.stop()
            else:
                progress.stop()

        # Save outputs
        save_prediction_outputs(predictions, output_dir)

        logger.info("Batch prediction complete: %d samples -> %s", len(predictions), output_dir)
        return predictions
