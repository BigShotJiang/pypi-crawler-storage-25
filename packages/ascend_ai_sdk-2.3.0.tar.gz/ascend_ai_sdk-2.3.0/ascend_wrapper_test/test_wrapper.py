"""ASCEND Boto3 Wrapper Integration Test"""
import os
import logging
from ascend_boto3 import enable_governance, disable_governance

# Enable debug logging to see governance decisions
logging.basicConfig(level=logging.DEBUG)

api_key = os.environ.get("ASCEND_API_KEY")
print(f"API Key configured: {bool(api_key)}")

# Enable governance
print("\nEnabling governance...")
enable_governance(
    api_key=api_key,
    base_url="https://pilot.owkai.app"
)

# Test: s3:list_buckets (low risk - should approve)
print("\nTesting s3:list_buckets...")
try:
    import boto3
    s3 = boto3.client('s3')
    response = s3.list_buckets()
    print(f"SUCCESS: Found {len(response.get('Buckets', []))} buckets")
except Exception as e:
    print(f"Result: {e}")

# Disable governance
print("\nDisabling governance...")
disable_governance()
print("Test complete.")
