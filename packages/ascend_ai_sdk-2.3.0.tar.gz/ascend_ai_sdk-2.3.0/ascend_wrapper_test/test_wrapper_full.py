"""ASCEND Boto3 Wrapper - Full Risk Level Test"""
import os
import logging
from ascend_boto3 import enable_governance, disable_governance

logging.basicConfig(level=logging.DEBUG)

print("Enabling governance (auto_approve disabled)...")
enable_governance(
    api_key=os.environ.get("ASCEND_API_KEY"),
    base_url="https://pilot.owkai.app",
    auto_approve_low_risk=True,  # Force API evaluation
    auto_approve_medium_risk=False
)

import boto3

# Test 1: Low risk - now goes to API
print("\n[TEST 1] s3:list_buckets (low risk)...")
try:
    s3 = boto3.client('s3')
    response = s3.list_buckets()
    print(f"APPROVED: {len(response.get('Buckets', []))} buckets")
except Exception as e:
    print(f"Result: {e}")

# Test 2: Critical risk - should DENY
print("\n[TEST 2] s3:delete_bucket (critical risk)...")
try:
    s3.delete_bucket(Bucket='fake-bucket-that-does-not-exist-12345')
    print("APPROVED (unexpected)")
except Exception as e:
    print(f"Result: {e}")

disable_governance()
print("\nTest complete.")
