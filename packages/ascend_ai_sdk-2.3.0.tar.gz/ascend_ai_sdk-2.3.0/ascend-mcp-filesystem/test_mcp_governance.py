#!/usr/bin/env python3
"""
ASCEND MCP Filesystem Server - Governance Test Suite
====================================================

This script tests ASCEND governance for Anthropic's MCP filesystem server.
Each test creates a real action in ASCEND that you can view in the UI.

Usage:
    # Run all tests
    python3 test_mcp_governance.py
    
    # Run specific scenario
    python3 test_mcp_governance.py --scenario read_file
    python3 test_mcp_governance.py --scenario delete_file
    python3 test_mcp_governance.py --scenario sensitive_path
    
    # Run with verbose output
    python3 test_mcp_governance.py --verbose
    
    # Demo mode (slower, with commentary)
    python3 test_mcp_governance.py --demo

Environment:
    ASCEND_API_KEY: Your ASCEND API key (required)

Author: OW-KAI Technologies, Inc.
"""

import os
import sys
import json
import time
import argparse
from typing import List, Dict, Any
from datetime import datetime

# Import our wrapper
from mcp_governance_wrapper import MCPGovernanceWrapper, GovernanceResult, GovernanceDecision


# ============================================================================
# TEST SCENARIOS
# ============================================================================

TEST_SCENARIOS = {
    # Low-risk read operations
    "read_file": {
        "name": "Read Config File",
        "tool": "read_file",
        "arguments": {"path": "/tmp/config.yaml"},
        "expected_risk": "low",
        "expected_decision": "approved",
        "description": "Simple file read - should auto-approve",
        "talking_point": "Low-risk read operation → Auto-approved in milliseconds"
    },
    
    "list_directory": {
        "name": "List Directory",
        "tool": "list_directory",
        "arguments": {"path": "/tmp"},
        "expected_risk": "low",
        "expected_decision": "approved",
        "description": "Directory listing - very low risk",
        "talking_point": "Directory listing is read-only → Auto-approved"
    },
    
    "get_file_info": {
        "name": "Get File Info",
        "tool": "get_file_info",
        "arguments": {"path": "/tmp/document.pdf"},
        "expected_risk": "low",
        "expected_decision": "approved",
        "description": "File metadata check - minimal risk",
        "talking_point": "Metadata only, no content access → Auto-approved"
    },
    
    # Medium-risk write operations
    "write_file": {
        "name": "Write Log File",
        "tool": "write_file",
        "arguments": {"path": "/tmp/app.log", "content": "Log entry..."},
        "expected_risk": "medium",
        "expected_decision": "pending_approval",
        "description": "File write operation - requires approval",
        "talking_point": "Write operation → Human approval required"
    },
    
    "create_directory": {
        "name": "Create Directory",
        "tool": "create_directory",
        "arguments": {"path": "/tmp/new_folder"},
        "expected_risk": "medium",
        "expected_decision": "approved",
        "description": "Directory creation - moderate risk",
        "talking_point": "Creating structure → Approved but logged"
    },
    
    "move_file": {
        "name": "Move File",
        "tool": "move_file",
        "arguments": {"source": "/tmp/old.txt", "destination": "/tmp/new.txt"},
        "expected_risk": "medium",
        "expected_decision": "pending_approval",
        "description": "File move operation - modifies filesystem",
        "talking_point": "Filesystem modification → Requires approval"
    },
    
    # High-risk delete operations
    "delete_file": {
        "name": "Delete User Data",
        "tool": "delete_file",
        "arguments": {"path": "/tmp/user_data.csv"},
        "expected_risk": "high",
        "expected_decision": "pending_approval",
        "description": "File deletion - high risk, requires approval",
        "talking_point": "DELETE operation → High risk score, requires human approval"
    },
    
    "delete_production": {
        "name": "Delete Production File",
        "tool": "delete_file",
        "arguments": {"path": "/data/production/config.json"},
        "expected_risk": "critical",
        "expected_decision": "pending_approval",
        "description": "Delete in production path - should be blocked",
        "talking_point": "Production + DELETE = BLOCKED. No exceptions."
    },
    
    # Sensitive path access
    "sensitive_path": {
        "name": "Read Sensitive File",
        "tool": "read_file",
        "arguments": {"path": "/etc/passwd"},
        "expected_risk": "high",
        "expected_decision": "approved",
        "description": "Sensitive system file - elevated risk",
        "talking_point": "System file access → Elevated risk, requires approval"
    },
    
    "credentials_access": {
        "name": "Read Credentials File",
        "tool": "read_file",
        "arguments": {"path": "/app/.env.credentials"},
        "expected_risk": "critical",
        "expected_decision": "pending_approval",
        "description": "Credentials file - critical risk",
        "talking_point": "Credential files are ALWAYS flagged for review"
    },
    
    "ssh_key_access": {
        "name": "Read SSH Key",
        "tool": "read_file",
        "arguments": {"path": "~/.ssh/id_rsa"},
        "expected_risk": "critical",
        "expected_decision": "denied",
        "description": "SSH private key - should be blocked",
        "talking_point": "Private keys are BLOCKED by default policy"
    },
    
    # Bulk operations
    "bulk_search": {
        "name": "Search All Files",
        "tool": "search_files",
        "arguments": {"path": "/data", "pattern": "*"},
        "expected_risk": "high",
        "expected_decision": "pending_approval",
        "description": "Wildcard search - potential data exfiltration",
        "talking_point": "Wildcard patterns flag potential data exfiltration"
    },
    
    "recursive_delete": {
        "name": "Recursive Delete",
        "tool": "delete_file",
        "arguments": {"path": "/tmp/archive", "recursive": True},
        "expected_risk": "critical",
        "expected_decision": "denied",
        "description": "Recursive delete - extremely dangerous",
        "talking_point": "Recursive delete = BLOCKED. This is how you prevent rm -rf disasters."
    },
    
    # Customer data scenarios
    "customer_data_read": {
        "name": "Read Customer Export",
        "tool": "read_file",
        "arguments": {"path": "/exports/customer_data_2025.csv"},
        "expected_risk": "high",
        "expected_decision": "pending_approval",
        "description": "Customer data file - PII risk",
        "talking_point": "Customer data access → PII detected → Requires approval"
    },
    
    "pii_write": {
        "name": "Write PII File",
        "tool": "write_file",
        "arguments": {"path": "/tmp/user_profiles.json", "content": "{...}"},
        "expected_risk": "high",
        "expected_decision": "pending_approval",
        "description": "Writing user data - compliance concern",
        "talking_point": "Writing PII requires compliance approval"
    }
}


# ============================================================================
# TEST RUNNER
# ============================================================================

class MCPTestRunner:
    """Runs MCP governance test scenarios"""
    
    def __init__(self, verbose: bool = False, demo_mode: bool = False):
        self.verbose = verbose
        self.demo_mode = demo_mode
        self.wrapper = None
        self.results: List[Dict[str, Any]] = []
    
    def setup(self) -> bool:
        """Initialize the test environment"""
        print("=" * 70)
        print("  ASCEND MCP Filesystem Server - Governance Test Suite")
        print("=" * 70)
        print(f"  Timestamp: {datetime.now().isoformat()}")
        print(f"  API: https://pilot.owkai.app")
        print(f"  Agent: mcp-filesystem-server")
        print("=" * 70)
        
        try:
            self.wrapper = MCPGovernanceWrapper(
                agent_id="mcp-filesystem-server",
                agent_name="Anthropic MCP Filesystem Server"
            )
            
            # Health check
            print("\n🏥 Checking ASCEND API connection...")
            if self.wrapper.health_check():
                print("   ✅ ASCEND API is reachable")
                return True
            else:
                print("   ❌ ASCEND API not reachable")
                print("   Check your network connection and API key")
                return False
                
        except ValueError as e:
            print(f"\n❌ Configuration Error: {e}")
            return False
    
    def run_scenario(self, scenario_key: str) -> Dict[str, Any]:
        """Run a single test scenario"""
        scenario = TEST_SCENARIOS.get(scenario_key)
        if not scenario:
            return {"error": f"Unknown scenario: {scenario_key}"}
        
        print(f"\n{'─' * 60}")
        print(f"📋 SCENARIO: {scenario['name']}")
        print(f"   Tool: {scenario['tool']}")
        print(f"   Args: {json.dumps(scenario['arguments'], indent=2)[:100]}")
        
        if self.demo_mode:
            print(f"\n   💬 {scenario['talking_point']}")
            time.sleep(2)  # Pause for demo effect
        
        # Execute governance check
        result = self.wrapper.call_tool(
            scenario["tool"],
            scenario["arguments"]
        )
        
        # Display results
        decision_emoji = {
            GovernanceDecision.APPROVED: "✅",
            GovernanceDecision.PENDING_APPROVAL: "⏳",
            GovernanceDecision.DENIED: "❌",
            GovernanceDecision.BLOCKED: "🚫",
            GovernanceDecision.ERROR: "⚠️"
        }
        
        emoji = decision_emoji.get(result.decision, "❓")
        
        print(f"\n   {emoji} Decision: {result.decision.value.upper()}")
        print(f"   📊 Risk Score: {result.risk_score}/100 ({result.risk_level})")
        print(f"   ⏱️  Latency: {result.latency_ms:.1f}ms")
        
        if result.action_id:
            print(f"   🔗 Action ID: {result.action_id}")
            print(f"   🌐 View in UI: https://pilot.owkai.app → Authorization Center")
        
        if self.verbose and result.raw_response:
            print(f"\n   Raw Response:")
            print(f"   {json.dumps(result.raw_response, indent=2)[:500]}")
        
        # Check if result matches expectation
        expected = scenario["expected_decision"]
        actual = result.decision.value
        match = (expected == actual) or (expected in actual)
        
        if match:
            print(f"\n   ✓ Result matches expected ({expected})")
        else:
            print(f"\n   ✗ Expected {expected}, got {actual}")
        
        test_result = {
            "scenario": scenario_key,
            "name": scenario["name"],
            "decision": result.decision.value,
            "risk_score": result.risk_score,
            "risk_level": result.risk_level,
            "action_id": result.action_id,
            "latency_ms": result.latency_ms,
            "expected": expected,
            "passed": match
        }
        
        self.results.append(test_result)
        
        if self.demo_mode:
            time.sleep(1)
        
        return test_result
    
    def run_all(self) -> None:
        """Run all test scenarios"""
        print("\n" + "=" * 70)
        print("  RUNNING ALL TEST SCENARIOS")
        print("=" * 70)
        
        for scenario_key in TEST_SCENARIOS:
            self.run_scenario(scenario_key)
        
        self.print_summary()
    
    def run_demo(self) -> None:
        """Run demo-optimized scenarios"""
        demo_scenarios = [
            "read_file",          # Auto-approve (low risk)
            "write_file",         # Pending approval (medium risk)
            "delete_file",        # Pending approval (high risk)
            "sensitive_path",     # Elevated risk
            "delete_production",  # Blocked (critical risk)
        ]
        
        print("\n" + "=" * 70)
        print("  DEMO MODE - Key Scenarios for Sales Calls")
        print("=" * 70)
        print("  Showing 5 scenarios that demonstrate ASCEND's capabilities:")
        print("  1. Auto-approve (low risk)")
        print("  2. Pending approval (medium risk)")
        print("  3. High risk flagging")
        print("  4. Sensitive path detection")
        print("  5. Production protection (blocked)")
        print("=" * 70)
        
        for scenario_key in demo_scenarios:
            self.run_scenario(scenario_key)
        
        self.print_summary()
    
    def print_summary(self) -> None:
        """Print test summary"""
        print("\n" + "=" * 70)
        print("  TEST SUMMARY")
        print("=" * 70)
        
        total = len(self.results)
        passed = sum(1 for r in self.results if r.get("passed"))
        failed = total - passed
        
        print(f"\n  Total Scenarios: {total}")
        print(f"  ✅ Passed: {passed}")
        print(f"  ❌ Failed: {failed}")
        
        # Metrics
        metrics = self.wrapper.get_metrics()
        print(f"\n  📊 Governance Metrics:")
        print(f"     Total API Calls: {metrics['total_calls']}")
        print(f"     Approved: {metrics['approved']}")
        print(f"     Pending: {metrics['pending']}")
        print(f"     Denied: {metrics['denied']}")
        print(f"     Avg Latency: {metrics['avg_latency_ms']:.1f}ms")
        
        # Results by risk level
        print(f"\n  📈 Results by Decision:")
        decisions = {}
        for r in self.results:
            d = r["decision"]
            decisions[d] = decisions.get(d, 0) + 1
        
        for decision, count in sorted(decisions.items()):
            print(f"     {decision}: {count}")
        
        # Action IDs for UI verification
        action_ids = [r["action_id"] for r in self.results if r.get("action_id")]
        if action_ids:
            print(f"\n  🔗 Action IDs for UI Verification:")
            for aid in action_ids:
                print(f"     - {aid}")
        
        print("\n" + "=" * 70)
        print("  View all actions at: https://pilot.owkai.app")
        print("  Navigate to Authorization Center → Filter by 'mcp-filesystem-server'")
        print("=" * 70)
    
    def cleanup(self) -> None:
        """Cleanup resources"""
        if self.wrapper:
            self.wrapper.close()


# ============================================================================
# MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="ASCEND MCP Filesystem Server Governance Tests",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 test_mcp_governance.py                    # Run all tests
  python3 test_mcp_governance.py --demo             # Run demo scenarios
  python3 test_mcp_governance.py --scenario read_file
  python3 test_mcp_governance.py --list             # List all scenarios

Environment:
  ASCEND_API_KEY    Your ASCEND API key (required)
        """
    )
    
    parser.add_argument(
        "--scenario", "-s",
        help="Run specific scenario by key"
    )
    parser.add_argument(
        "--demo", "-d",
        action="store_true",
        help="Run demo-optimized scenarios with commentary"
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Show verbose output including raw API responses"
    )
    parser.add_argument(
        "--list", "-l",
        action="store_true",
        help="List all available scenarios"
    )
    
    args = parser.parse_args()
    
    # List scenarios
    if args.list:
        print("\nAvailable Test Scenarios:")
        print("=" * 70)
        for key, scenario in TEST_SCENARIOS.items():
            print(f"\n  {key}:")
            print(f"    Name: {scenario['name']}")
            print(f"    Tool: {scenario['tool']}")
            print(f"    Expected: {scenario['expected_decision']}")
        return
    
    # Initialize runner
    runner = MCPTestRunner(
        verbose=args.verbose,
        demo_mode=args.demo
    )
    
    if not runner.setup():
        sys.exit(1)
    
    try:
        if args.scenario:
            # Run single scenario
            if args.scenario not in TEST_SCENARIOS:
                print(f"\n❌ Unknown scenario: {args.scenario}")
                print(f"   Run with --list to see available scenarios")
                sys.exit(1)
            runner.run_scenario(args.scenario)
            runner.print_summary()
        elif args.demo:
            # Run demo mode
            runner.run_demo()
        else:
            # Run all scenarios
            runner.run_all()
    
    finally:
        runner.cleanup()


if __name__ == "__main__":
    main()
