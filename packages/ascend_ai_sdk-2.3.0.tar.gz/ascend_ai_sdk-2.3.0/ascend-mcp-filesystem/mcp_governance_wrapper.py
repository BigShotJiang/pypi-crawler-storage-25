#!/usr/bin/env python3
"""
ASCEND MCP Governance Wrapper
=============================

This module wraps MCP tool calls with ASCEND governance.
Every tool call goes through risk assessment before execution.

Usage:
    from mcp_governance_wrapper import MCPGovernanceWrapper
    
    wrapper = MCPGovernanceWrapper(
        api_key="ascend_prod_...",
        agent_id="mcp-filesystem-server"
    )
    
    result = wrapper.call_tool("read_file", {"path": "/tmp/test.txt"})
"""

import os
import json
import time
from typing import Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum

try:
    import httpx
except ImportError:
    print("ERROR: httpx not installed. Run: pip install httpx")
    print("Installing now...")
    import subprocess
    subprocess.run(["pip", "install", "httpx", "-q"])
    import httpx


class GovernanceDecision(Enum):
    """Possible governance decisions"""
    APPROVED = "approved"
    PENDING_APPROVAL = "pending_approval"
    DENIED = "denied"
    BLOCKED = "blocked"
    ERROR = "error"


@dataclass
class GovernanceResult:
    """Result from governance check"""
    decision: GovernanceDecision
    action_id: Optional[int]
    risk_score: float
    risk_level: str
    message: str
    requires_approval: bool
    latency_ms: float
    raw_response: Dict[str, Any]
    
    def is_approved(self) -> bool:
        return self.decision == GovernanceDecision.APPROVED
    
    def is_pending(self) -> bool:
        return self.decision == GovernanceDecision.PENDING_APPROVAL
    
    def is_denied(self) -> bool:
        return self.decision in [GovernanceDecision.DENIED, GovernanceDecision.BLOCKED]


class MCPGovernanceWrapper:
    """
    Wraps MCP tool calls with ASCEND governance.
    
    This is the key integration point - every MCP tool call
    goes through this wrapper before execution.
    """
    
    # Tool-to-action-type mappings for MCP filesystem server
    TOOL_MAPPINGS = {
        "read_file": {
            "action_type": "file_read",
            "base_risk": 20,
            "description_template": "MCP tool: Read file at {path}"
        },
        "write_file": {
            "action_type": "file_write",
            "base_risk": 50,
            "description_template": "MCP tool: Write file at {path}"
        },
        "create_directory": {
            "action_type": "directory_create",
            "base_risk": 35,
            "description_template": "MCP tool: Create directory at {path}"
        },
        "list_directory": {
            "action_type": "directory_list",
            "base_risk": 15,
            "description_template": "MCP tool: List directory at {path}"
        },
        "move_file": {
            "action_type": "file_move",
            "base_risk": 45,
            "description_template": "MCP tool: Move file from {source} to {destination}"
        },
        "search_files": {
            "action_type": "file_search",
            "base_risk": 25,
            "description_template": "MCP tool: Search files with pattern {pattern}"
        },
        "get_file_info": {
            "action_type": "file_info",
            "base_risk": 10,
            "description_template": "MCP tool: Get info for {path}"
        },
        "delete_file": {
            "action_type": "file_delete",
            "base_risk": 75,
            "description_template": "MCP tool: DELETE file at {path}"
        },
        "list_allowed_directories": {
            "action_type": "directory_list",
            "base_risk": 5,
            "description_template": "MCP tool: List allowed directories"
        }
    }
    
    # Sensitive paths that increase risk
    SENSITIVE_PATHS = [
        "/etc/passwd",
        "/etc/shadow",
        "/etc/hosts",
        "/root",
        "/home",
        "~/.ssh",
        "~/.aws",
        "/var/log",
        ".env",
        "credentials",
        "secrets",
        "password",
        "token",
        "api_key"
    ]
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        agent_id: str = "mcp-filesystem-server",
        agent_name: str = "Anthropic MCP Filesystem Server",
        base_url: str = "https://pilot.owkai.app",
        timeout: float = 30.0
    ):
        """
        Initialize the MCP governance wrapper.
        
        Args:
            api_key: ASCEND API key (or set ASCEND_API_KEY env var)
            agent_id: Unique identifier for this MCP server
            agent_name: Human-readable name
            base_url: ASCEND backend URL
            timeout: Request timeout in seconds
        """
        self.api_key = api_key or os.getenv("ASCEND_API_KEY")
        if not self.api_key:
            raise ValueError(
                "ASCEND_API_KEY required. Set via parameter or environment variable.\n"
                "Example: export ASCEND_API_KEY='ascend_prod_...'"
            )
        
        self.agent_id = agent_id
        self.agent_name = agent_name
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        
        self.client = httpx.Client(
            timeout=timeout,
            headers={
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
                "User-Agent": f"ASCEND-MCP-Wrapper/{agent_id}"
            }
        )
        
        # Track metrics
        self.total_calls = 0
        self.approved_calls = 0
        self.denied_calls = 0
        self.pending_calls = 0
        self.total_latency_ms = 0.0
    
    def _calculate_risk_adjustments(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculate risk adjustments based on tool and arguments.
        
        This adds contextual risk factors that ASCEND will use
        in its risk calculation.
        """
        adjustments = {
            "sensitive_path": False,
            "bulk_operation": False,
            "recursive": False,
            "production_indicator": False,
            "pii_indicator": False
        }
        
        # Check for sensitive paths
        path = arguments.get("path", "") or arguments.get("source", "")
        path_lower = path.lower() if path else ""
        
        for sensitive in self.SENSITIVE_PATHS:
            if sensitive.lower() in path_lower:
                adjustments["sensitive_path"] = True
                break
        
        # Check for production indicators
        if any(prod in path_lower for prod in ["prod", "production", "live"]):
            adjustments["production_indicator"] = True
        
        # Check for PII indicators
        if any(pii in path_lower for pii in ["customer", "user", "personal", "ssn", "credit"]):
            adjustments["pii_indicator"] = True
        
        # Check for bulk operations (e.g., patterns with wildcards)
        pattern = arguments.get("pattern", "")
        if "*" in pattern or "?" in pattern:
            adjustments["bulk_operation"] = True
        
        # Check for recursive operations
        if arguments.get("recursive", False):
            adjustments["recursive"] = True
        
        return adjustments
    
    def call_tool(
        self,
        tool_name: str,
        arguments: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None
    ) -> GovernanceResult:
        """
        Call an MCP tool with ASCEND governance.
        
        This is the main entry point. Before any tool executes,
        this method:
        1. Maps the tool to an action type
        2. Calculates contextual risk factors
        3. Calls ASCEND for governance decision
        4. Returns the decision (approved/pending/denied)
        
        Args:
            tool_name: Name of the MCP tool (e.g., "read_file")
            arguments: Tool arguments (e.g., {"path": "/tmp/test.txt"})
            context: Optional additional context
            
        Returns:
            GovernanceResult with decision and details
        """
        start_time = time.time()
        self.total_calls += 1
        
        # Get tool mapping or use defaults
        tool_config = self.TOOL_MAPPINGS.get(tool_name, {
            "action_type": f"mcp.{tool_name}",
            "base_risk": 50,
            "description_template": f"MCP tool: {tool_name}"
        })
        
        # Calculate risk adjustments
        risk_adjustments = self._calculate_risk_adjustments(tool_name, arguments)
        
        # Build description
        try:
            description = tool_config["description_template"].format(**arguments)
        except KeyError:
            description = f"MCP tool: {tool_name} with args {arguments}"
        
        # Build context for ASCEND
        full_context = {
            "mcp_server": "anthropic-filesystem",
            "mcp_tool": tool_name,
            "tool_arguments": arguments,
            "source": "mcp",
            "protocol": "mcp",
            **risk_adjustments,
            **(context or {})
        }
        
        # Build the action payload
        payload = {
            "agent_id": self.agent_id,
            "action_type": tool_config["action_type"],
            "tool_name": f"mcp.filesystem.{tool_name}",
            "description": description,
            "resource_type": "filesystem",
            "context": full_context
        }
        
        # Call ASCEND API
        try:
            response = self.client.post(
                f"{self.base_url}/api/v1/actions/submit",
                json=payload
            )
            
            latency_ms = (time.time() - start_time) * 1000
            self.total_latency_ms += latency_ms
            
            if response.status_code == 200:
                data = response.json()
                
                # Map status to decision
                status = data.get("status", "").lower()
                if status == "approved":
                    decision = GovernanceDecision.APPROVED
                    self.approved_calls += 1
                elif status == "pending_approval":
                    decision = GovernanceDecision.PENDING_APPROVAL
                    self.pending_calls += 1
                elif status in ["denied", "blocked"]:
                    decision = GovernanceDecision.DENIED
                    self.denied_calls += 1
                else:
                    decision = GovernanceDecision.ERROR
                
                return GovernanceResult(
                    decision=decision,
                    action_id=data.get("id"),
                    risk_score=data.get("risk_score", 0),
                    risk_level=data.get("risk_level", "unknown"),
                    message=data.get("message", ""),
                    requires_approval=data.get("requires_approval", False),
                    latency_ms=latency_ms,
                    raw_response=data
                )
            
            elif response.status_code == 401:
                return GovernanceResult(
                    decision=GovernanceDecision.ERROR,
                    action_id=None,
                    risk_score=0,
                    risk_level="error",
                    message="Authentication failed. Check your API key.",
                    requires_approval=False,
                    latency_ms=latency_ms,
                    raw_response={"error": "401 Unauthorized"}
                )
            
            elif response.status_code == 403:
                self.denied_calls += 1
                return GovernanceResult(
                    decision=GovernanceDecision.BLOCKED,
                    action_id=None,
                    risk_score=100,
                    risk_level="blocked",
                    message="Agent is blocked via kill-switch",
                    requires_approval=False,
                    latency_ms=latency_ms,
                    raw_response={"error": "403 Agent Blocked"}
                )
            
            else:
                return GovernanceResult(
                    decision=GovernanceDecision.ERROR,
                    action_id=None,
                    risk_score=0,
                    risk_level="error",
                    message=f"API error: {response.status_code}",
                    requires_approval=False,
                    latency_ms=latency_ms,
                    raw_response={"error": f"HTTP {response.status_code}"}
                )
                
        except httpx.RequestError as e:
            latency_ms = (time.time() - start_time) * 1000
            return GovernanceResult(
                decision=GovernanceDecision.ERROR,
                action_id=None,
                risk_score=0,
                risk_level="error",
                message=f"Connection error: {str(e)}",
                requires_approval=False,
                latency_ms=latency_ms,
                raw_response={"error": str(e)}
            )
    
    def health_check(self) -> bool:
        """Check if ASCEND API is reachable"""
        try:
            response = self.client.get(f"{self.base_url}/health")
            return response.status_code == 200
        except Exception:
            return False
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get wrapper metrics"""
        avg_latency = self.total_latency_ms / self.total_calls if self.total_calls > 0 else 0
        return {
            "total_calls": self.total_calls,
            "approved": self.approved_calls,
            "denied": self.denied_calls,
            "pending": self.pending_calls,
            "avg_latency_ms": round(avg_latency, 2)
        }
    
    def close(self):
        """Close the HTTP client"""
        self.client.close()


# Convenience function for quick testing
def test_governance(tool_name: str, arguments: Dict[str, Any]) -> GovernanceResult:
    """
    Quick test function for governance check.
    
    Usage:
        from mcp_governance_wrapper import test_governance
        
        result = test_governance("read_file", {"path": "/tmp/test.txt"})
        print(f"Decision: {result.decision.value}")
    """
    wrapper = MCPGovernanceWrapper()
    try:
        return wrapper.call_tool(tool_name, arguments)
    finally:
        wrapper.close()


if __name__ == "__main__":
    # Quick test
    print("=" * 60)
    print("MCP Governance Wrapper - Quick Test")
    print("=" * 60)
    
    try:
        wrapper = MCPGovernanceWrapper()
        
        # Test health check
        print("\n🏥 Health Check...")
        if wrapper.health_check():
            print("   ✅ ASCEND API is reachable")
        else:
            print("   ❌ ASCEND API not reachable")
            exit(1)
        
        # Test a simple read
        print("\n📄 Testing read_file governance...")
        result = wrapper.call_tool("read_file", {"path": "/tmp/test.txt"})
        print(f"   Decision: {result.decision.value}")
        print(f"   Risk Score: {result.risk_score}")
        print(f"   Latency: {result.latency_ms:.1f}ms")
        
        if result.action_id:
            print(f"   Action ID: {result.action_id}")
        
        wrapper.close()
        print("\n✅ Quick test complete!")
        
    except ValueError as e:
        print(f"\n❌ Configuration Error: {e}")
        exit(1)
