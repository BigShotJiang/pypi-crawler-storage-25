# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.5.0] - 2026-03-24

### Added

- `create_user`, `update_user`, `delete_user` -- full CRUD for user accounts via `/setting/admins` API. Delete fetches username before removal for audit-friendly responses.
- `create_collector_group`, `update_collector_group`, `delete_collector_group` -- collector group management. Delete blocks if collectors are still assigned. Update merges custom properties with existing values.
- `update_ops_note`, `delete_ops_note` -- ops note write operations. Update supports note text, tags, and device/group scopes.
- `update_dashboard_group` -- update dashboard group name, description, or parent ID via PATCH.
- `update_sdt` -- modify scheduled downtimes using fetch-modify-PUT pattern to preserve unmodified fields.
- Tool categories index updated to include all new tools.

## [2.4.0] - 2026-03-24

### Added

- Portal URL links in single-resource detail responses (`get_device`, `get_device_group`, `get_alert_details`, `get_dashboard`, `get_website`). Each response now includes a `portal_url` field linking directly to the resource in the LM portal UI.
- HTTPS transport support via `LM_HTTP_SSL_CERTFILE`, `LM_HTTP_SSL_KEYFILE`, and `LM_HTTP_SSL_KEYFILE_PASSWORD` environment variables. When configured, the HTTP transport starts with TLS via Uvicorn.
- `portal_url()` shared helper in tools init for constructing LM portal UI links.

## [2.3.2] - 2026-03-23

### Added

- `get_alerts` now supports `group_id` parameter to filter alerts by device group. Resolves the group ID to its `fullPath` and uses the `monitorObjectGroups~` filter, which works reliably for Kubernetes clusters and all other device groups.
- `get_alerts` now supports `device_id` parameter to filter alerts by device/resource ID using `monitorObjectId:` filter.
- `resolve_group_filter()` shared helper resolves a group ID to a `monitorObjectGroups~` filter clause via a single API call.
- Alert filter documentation (`filters.py`) now includes `hostGroupIds`, `monitorObjectId`, and `monitorObjectGroups` fields with examples.

### Fixed

- `correlate_alerts`, `get_alert_statistics`, and `score_alert_noise` now use `monitorObjectGroups~` instead of `hostGroupIds~` for group filtering. The `hostGroupIds~` filter does not reliably restrict results to the target group in the LM API.
- `correlate_alerts` and `score_alert_noise` now sanitize the `device` parameter through `sanitize_filter_value()`, matching `get_alerts` behavior.

## [2.3.0] - 2026-03-22

### Added

- `get_device_group` — Fetch full device group detail including `appliesTo` expression and `parentId`
- `get_device_eventsources` — List EventSources applied to a device with alerting status
- `update_device_eventsource` — Enable/disable alerting for an EventSource on a device (write-protected)
- `bulk_delete_devices` — Batch delete up to 100 devices with K8S warnings, soft or hard delete (write-protected)
- `update_collector` — Update collector group, description, failback, and escalation chain (write-protected)
- `delete_collector` — Delete a collector with guardrail blocking deletion if devices are still assigned (write-protected)
- `recover_device` — Restore soft-deleted devices via PATCH with `recover=true` parameter (write-protected)
- `safe_total()` helper for handling LM API negative total sentinel values in paginated responses

### Fixed

- `get_devices` status filter restored to numeric codes (`hostStatus:1` for dead) — the v3 API rejects string values like `hostStatus:dead` with "invalid filter"
- `get_devices` and `get_alerts` no longer return negative totals when the API response is truncated — `safe_total()` applies `abs()` to sentinel values
- `score_alert_noise` weight formula corrected from `repeat_ratio * 3000` / `flap_ratio * 3000` to `* 30` — scores were pegged at 100 for any normal alert volume

### Changed

- `calculate_availability` now post-filters results to the target device, preventing unrelated devices from polluting calculations; added optional `device_name` parameter and safe uptime floor (`max(0.0, ...)`)
- `delete_device` warns when deleting K8S-managed devices (deviceType=8) since Argus may recreate them; includes deleted device audit context
- `update_device` warns when `host_group_ids` changes may not persist on K8S-managed devices
- `get_device_groups` now includes `parentId` and `appliesTo` in list results
- Tool count: 216 -> 223 (205 LM + 18 AAP)

## [2.2.0] - 2026-03-20

### Changed

- CORS default changed from `*` (allow all) to empty string (no CORS by default). HTTP transport users must now explicitly set `LM_CORS_ORIGINS` to enable cross-origin requests.
- `AWX_VERIFY_SSL` default changed from `false` to `true` in setup script
- Expanded ruff lint rules to full recommended set (E/F/I/N/W/UP/B/SIM/RUF)
- Added mypy type checking to CI (non-blocking)
- Pinned uv to 0.9.27 in Dockerfile and CI workflows
- Added Docker layer caching to release workflow

### Fixed

- Setup script (`scripts/add-mcp-to-project.sh`) no longer uses hardcoded path; auto-detects project root

## [2.1.1] - 2026-03-17

### Fixed

- `create_sdt` and `bulk_create_device_sdt` map Device* SDT type names to Resource* before POST, fixing 400 "Invalid type" errors on the v3 API which renamed Device* to Resource* for SDT create endpoints

## [2.1.0] - 2026-03-12

### Added

- `create_sdt` expanded from 2 types (DeviceSDT, DeviceGroupSDT) to all 13 LM API SDT types
- `datasource_id` parameter on `create_sdt` for DeviceDataSourceSDT type
- Generalized Device-prefixed type handling so `deviceId` is sent for all Device* types
- Improved error messages with cloud resource workaround guidance

## [2.0.1] - 2026-03-12

### Added

- `update_device_group` tool for modifying group name, description, AppliesTo, properties, and alerting state with property merging

### Removed

- 10 action chain/rule tools removed (not present on v3 API swagger)
- Action sources guide category renamed to remediation (7 tools retained)

### Changed

- Tool count: 225 -> 216 (198 LM + 18 AAP)

## [2.0.0] - 2026-03-12

### Added

- 5 composite workflow tools (`triage`, `health_check`, `capacity_plan`, `portal_overview`, `diagnose`) combining multiple sub-tools into single calls with summary/full detail levels and partial failure handling
- `search_tools` for keyword-based progressive discovery across all 225 tools
- `calculate_error_budget` for SLO error budget tracking
- `execute_remediation`, `get_remediation_status`, `get_remediation_history` for RemediationSource execution with 8-point pre-execution safety checklist
- Holt-Winters forecasting with auto-selection between linear and exponential smoothing
- IQR and MAD anomaly detection methods alongside existing z-score
- Prediction intervals on forecast results
- Metric presets auto-configure analysis parameters by datapoint name
- 15 enriched prompts with composite shortcuts and argument parsing
- 2 new resources (best-practices, example-responses)
- Common mistake notes on 6 frequently misused tool descriptions

### Changed

- Scoring tools return structured best-practice recommendations and anti-patterns when thresholds are breached
- Tool count: 215 -> 225 (207 LM + 18 AAP), prompt count: 14 -> 15, resource count: 24 -> 26

## [1.9.6] - 2026-03-11

### Fixed

- `get_widget`, `update_widget`, `delete_widget` use flat `/dashboard/widgets/{id}` endpoint instead of nested path that returned 404
- `add_widget` applies deviceSLA default fields (daysInWeek, periodInOneDay, displayType, calculationMethod, unmonitoredTimeAlertStatus) that the portal UI sets automatically
- `add_widget` remaps common field name aliases (`deviceGroupFullPath` -> `groupName`, `html` -> `content`) to prevent silent data loss from LM API discarding unknown fields
- `get_dashboards` prefers `numOfWidgets` over unreliable `widgetsConfig` for widget count

### Changed

- `add_widget` description documents text widget `content` key and deviceSLA required fields

## [1.9.5] - 2026-02-27

### Added

- Action Sources integration: 14 tools for diagnostic and remediation workflows
  - Action chains: get, create, update, delete
  - Action rules: get, create, update, delete
  - Diagnostic sources: list, get details
  - Remediation sources: list, get details
- All Action Sources tools marked `[PREVIEW]` — API endpoints are not yet GA in LM portals

### Removed

- Event-Driven Ansible (EDA) tools removed from deployed package (20 tools)
  - EDA required standalone infrastructure not available through LM Portal
  - Source code preserved in `contrib/eda/` for future reference
  - `/lm-eda` skill removed

### Changed

- Tool count: 221 -> 215 (197 LM + 18 AAP)
- Skill count: 7 -> 6
- Dispatch simplified from 4-way (session -> EDA -> AWX -> LM) to 3-way (session -> AWX -> LM)

## [1.9.2] - 2026-02-25

### Fixed

- EDA create tools now include required `organization_id` parameter (default 1 = "Default" org)
- `create_eda_event_stream` now requires `eda_credential_id` parameter (EDA API requirement)
- `create_eda_project` sends `organization_id` in request body
- `create_eda_activation` sends `organization_id` in request body

## [1.9.0] - 2026-02-25

### Added

- Event-Driven Ansible integration (20 tools) for automated event response
- EdaClient HTTP client with Bearer token auth, retry logic, and error mapping
- Activation management: list, get, create, enable, disable, restart, delete
- Activation instance monitoring with log retrieval
- EDA project management: list, get, create, sync from Git
- Rulebook queries: list, get (populated via project sync)
- Event stream management: list, get, create, delete
- Write-protected tools: create/enable/disable/restart/delete activations, create/sync projects, create/delete event streams
- `test_eda_connection` tool for verifying EDA Controller connectivity
- EDA_URL, EDA_TOKEN env vars (optional — EDA tools excluded if not set)
- `/lm-eda` Claude Code skill: event-driven alert automation workflow
- 4-way dispatch in server: session -> EDA -> AWX -> LM
- `add_device_instance` — Create datasource instances on a device (for datasources without Active Discovery)
- `update_device_instance` — Update instance properties (display name, description, monitoring, alerting)
- `delete_device_instance` — Delete a datasource instance from a device

### Fixed

- AAP check_mode (dry run) now sends `job_type: "check"` to the controller, preventing accidental execution during dry runs

### Changed

- Tool count: 198 -> 221 (183 LM + 18 AAP + 20 EDA)
- Skill count: 6 -> 7
- Tool categories guide updated with "eda" domain
- Write audit logging expanded with enable/disable/restart/sync prefixes

## [1.8.0] - 2026-02-19

### Added

- Ansible Automation Platform integration (18 tools) for observability-driven remediation
- Tool categories: job templates, job execution, inventories, workflows, projects, credentials, organizations, hosts
- Write-protected tools: launch_job, launch_workflow, cancel_job, relaunch_job (require LM_ENABLE_WRITE_OPERATIONS=true)
- Jinja2 injection protection on all extra_vars inputs
- `/lm-remediate` Claude Code skill: 10-step diagnosis-to-remediation workflow
- `remediate_workflow` MCP prompt for non-Claude-Code MCP clients
- Job template naming convention: `lm-remediate-<category>-<action>` for automatic discovery
- Example playbooks: disk-cleanup, service-restart, log-rotate, memory-cache-clear
- Skill structure tests validating all 6 skills against the tool registry
- `test_awx_connection` tool for verifying AAP connectivity
- AWX_URL, AWX_TOKEN env vars (optional — AAP tools excluded if not set)

### Changed

- Tool count: 180 -> 198 (180 LM + 18 AAP)
- Prompt count: 13 -> 14
- Skill count: 5 -> 6
- Tool categories guide updated with "ansible" domain

## [1.7.2] - 2026-02-18

### Fixed

- **`update_device` custom_properties merge** — Custom properties are now merged with existing properties instead of replacing them. Prevents silent data loss when updating a subset of custom properties on a device.
- **`update_device_property` create-on-404** — Falls back to POST (create) when PUT returns 404 for a property that doesn't exist yet. Matches the tool description "Update or create a device property".
- **`get_devices` filter validation for dot-notation fields** — Custom property filter queries like `customProperties.name:"env"` no longer fail schema validation. Dot-notation fields are now skipped during field validation since the LM API handles them natively.
- **Import tools string definition handling** — All import tools (`import_datasource`, `import_configsource`, etc.) and `post_multipart()` now handle definitions that arrive as JSON strings instead of dicts, preventing double-serialization of complex embedded content (e.g., Groovy scripts with escape characters).

### Added

- **`update_datasource`** — Update an existing DataSource definition via PUT.
- **`delete_datasource`** — Delete a DataSource definition by ID with confirmation.
- **`hostname_filter` on `get_devices`** — Filter devices by hostname or IP address (the `name` field). The existing `name_filter` parameter searches `displayName`; the new parameter searches the actual hostname/IP.
- **`overwrite` on `create_datasource`** — When `true`, deletes any existing DataSource with the same name before creating. Provides explicit upsert semantics without hidden behavior.

### Changed

- **`update_device` description** — Now documents merge behavior for custom properties.
- **`get_devices` filter description** — Documents custom property query syntax with proper quoting examples.
- **`get_devices` `name_filter` description** — Clarified as "display name" filter to distinguish from the new `hostname_filter`.

Tool count: 178 -> 180.

## [1.7.1] - 2026-02-17

### Fixed

- **HTTP 200 error body detection** — API client now checks for `errorMessage` + `errorCode` inside HTTP 200 response bodies and raises `LMError` with code `API_ERROR_{errorCode}`. Some LM API endpoints return HTTP 200 with error details in the body instead of using HTTP status codes; these previously passed through silently as success.
- **`add_widget` endpoint URL** — Changed from `/dashboard/dashboards/{id}/widgets` (returns 405) to `/dashboard/widgets`. The `dashboardId` field in the request body specifies which dashboard the widget belongs to.
- **`import_datasource` silent failure detection** — Now detects empty `{}` responses (no `id` or `errorMessage`) and returns an error noting the import may have silently failed, with guidance to use `create_datasource` for REST API format definitions.

### Added

- **`create_datasource`** — Create a DataSource via REST API from a full definition dict. Accepts the same format as `export_datasource` output, enabling round-tripping of exported definitions. Strips `id` from the definition before POST.

### Changed

- **Export/import format documentation** — Updated descriptions for `export_datasource`, `import_datasource`, and `create_datasource` to clarify the difference between REST API format (used by export/create) and LM Exchange format (used by import).
- **`add_widget` description** — Added format guidance for common widget types (bigNumber, cgraph) including GlobMatchToggle objects and aggregateFunction casing.

Tool count: 177 -> 178.

## [1.7.0] - 2026-02-17

### Added

5 Claude Code skills providing guided multi-step workflows for common LogicMonitor admin operations. Skills ship in the repo so anyone cloning it gets them automatically via `.claude/skills/`.

- **`/lm-triage`** — Alert triage workflow: gathers active alerts and statistics, scores noise level, clusters correlated alerts, performs deep dive with blast radius analysis, checks change correlation, and presents numbered action options (acknowledge, add note, bulk acknowledge). Write actions require explicit confirmation.
- **`/lm-health`** — Device health check: resolves device by ID or name, inventories datasources by category (CPU/Memory/Disk/Network), pulls core metrics, computes health score with decision tree, runs anomaly detection on degraded datasources, checks alert status, device properties, 30-day availability, and topology neighbors. Produces a compiled health report.
- **`/lm-portal`** — Portal-wide health snapshot for shift handoff: alert severity breakdown with trends, collector status (flags any down collectors), active SDT windows, top 5 alert clusters, noise scoring, down device count with collector correlation heuristic. Outputs a GREEN/YELLOW/RED portal status.
- **`/lm-capacity`** — Capacity planning and forecasting: current utilization across CPU/Memory/Disk, trend classification (stable/increasing/decreasing/volatile), seasonality detection, change point detection, breach forecasting with urgency tiers, and baseline comparison. Offers to save baselines with confirmation.
- **`/lm-apm`** — APM trace investigation: service discovery, service profile with properties, service-level RED metrics, operation breakdown sorted by volume, per-operation deep dive, datasource coverage check, and alert correlation. Supports both targeted service investigation and discovery mode.

### Changed

- `.gitignore` updated to track `.claude/skills/` while keeping other `.claude/` contents ignored.

## [1.6.1] - 2026-02-17

### Fixed

- **Import tools send wrong Content-Type** — All 8 `import_*` tools now use `multipart/form-data` file upload via `post_multipart()` instead of `application/json` POST. The LM import endpoints require multipart upload; the previous JSON body approach silently failed.
- **Unhandled 4xx status codes returned as success** — `_raise_for_status()` now has a catch-all for 400-499 status codes (400, 405, 409, 415, etc.) that raises `LMError` with code `HTTP_{status}`. Previously these fell through and returned error response bodies as if they were successful results.
- **Export/import format mismatch documented** — Updated docstrings on all export and import functions to clarify that REST API export format differs from LM Exchange format required by import endpoints.

### Added

- **`create_dashboard` template and widget token support** — `create_dashboard` now accepts `widget_tokens` (list of token overrides) and `template` (full dashboard definition from `export_dashboard` to clone from). When using a template, the exported definition is used as the base payload with name overridden and id stripped.
- **`create_dashboard_group`** — Create dashboard groups with optional parent_id and description. Follows the same pattern as `create_website_group`.
- **`delete_dashboard_group`** — Delete dashboard groups by ID. Follows the same pattern as `delete_website_group`.
- **`post_multipart()` client method** — Handles multipart/form-data file uploads for LM import endpoints with proper auth headers and retry logic.

Tool count: 175 -> 177.

## [1.6.0] - 2026-02-16

### Added

8 APM trace tools for service discovery and RED metrics via the v3 API. APM services are stored as `deviceType:6` devices with `LogicMonitor_APM_Services` and `LogicMonitor_APM_Operations` datasources.

- **`get_trace_services`** — Lists all APM trace services by filtering for deviceType:6. Entry point for discovering which services are instrumented. Supports namespace filtering for substring matching on service names.
- **`get_trace_service`** — Gets full device detail for a specific APM service, including status, groups, and configuration.
- **`get_trace_service_alerts`** — Gets active alerts for an APM service with optional severity filtering (critical, error, warning, info). Bridges traces and alerting.
- **`get_trace_service_datasources`** — Lists datasources applied to an APM service (LogicMonitor_APM_Services, LogicMonitor_APM_Operations, etc.). Required step before querying instances or metric data.
- **`get_trace_operations`** — Lists operation instances (endpoints/routes) for an APM service datasource. Each operation has its own RED metrics.
- **`get_trace_service_metrics`** — Gets service-level time-series data for Duration, ErrorOperationCount, OperationCount, and UniqueOperationCount. Supports time range and datapoint filtering.
- **`get_trace_operation_metrics`** — Gets per-operation RED metrics for a specific endpoint/route. Same API shape as service metrics but scoped to an individual operation instance.
- **`get_trace_service_properties`** — Gets device properties for an APM service including OTel attributes, namespace info, and auto-discovered metadata. Supports name filtering.

Tool count: 167 -> 175. Added "traces" category to tool-categories guide resource.

## [1.5.1] - 2026-02-14

### Added
- ML tool usage guide with detailed examples for capacity forecasting, metric correlation, change point detection, noise scoring, health scoring, and availability calculation
- ML Analysis & Forecasting example prompts section (10 natural language examples)
- Updated project structure with new tool files

## [1.5.0] - 2026-02-14

### Added

10 ML/statistical analysis tools using pure-Python implementations (no numpy/scipy dependencies).

- **`forecast_metric`** — Predicts when a metric will breach a threshold. Uses linear regression on historical data to calculate trend direction, slope, and estimated days until breach. Useful for capacity planning — point it at CPU, memory, or disk and set a threshold to get an early warning.
- **`correlate_metrics`** — Computes a Pearson correlation matrix across up to 10 metric series. Helps answer "are these metrics related?" — for example, does CPU spike when memory does? Highlights strong correlations (|r| > 0.7) automatically. Each source can be from a different device.
- **`detect_change_points`** — Finds moments where metric behavior shifted using the CUSUM algorithm. Instead of just looking at whether a value is high or low, it detects when the pattern changed — a sudden jump, a drop to a new baseline, or a regime shift. Sensitivity is configurable.
- **`score_alert_noise`** — Scores how noisy your alert environment is on a 0-100 scale. Combines Shannon entropy (how spread out alerts are across sources), flap detection (alerts that clear and re-fire within 30 minutes), and repeat ratio. Returns the top noisy devices and datasources with tuning recommendations.
- **`detect_seasonality`** — Checks whether a metric has a repeating pattern using autocorrelation. Tests standard intervals (1h, 4h, 6h, 8h, 12h, 24h, 7d) and reports which periods show strong periodicity. Useful for distinguishing "this spikes every day at 2pm" from "this is random."
- **`calculate_availability`** — Computes SLA-style uptime percentage from alert history. Merges overlapping alert windows and returns availability %, MTTR, incident count, longest incident duration, and a per-device breakdown. Filterable by severity threshold and time range.
- **`analyze_blast_radius`** — Scores the downstream impact if a device goes down. Walks the topology map to find dependent devices and produces an impact score. Useful for change management — check the blast radius before taking a device offline for maintenance.
- **`correlate_changes`** — Cross-references alert activity with audit/change logs to find correlations. Identifies config changes, device updates, or user actions that occurred within a configurable window before alert spikes. Each correlation gets a confidence score based on time proximity.
- **`classify_trend`** — Categorizes a metric's recent behavior into one of five patterns: stable, increasing, decreasing, cyclic, or volatile. A quick way to triage a metric without staring at a graph — run it across multiple datapoints to see what's moving.
- **`score_device_health`** — Produces a composite health score from 0-100 by computing z-scores for each datapoint's latest value against its historical window. Weights are configurable. Returns an overall status (healthy/degraded/critical) and identifies the top contributing factors dragging the score down.

2 analysis workflows:
- `capacity_forecast` — runs forecast_metric + classify_trend
- `device_health_assessment` — runs score_device_health + analyze_blast_radius + get_metric_anomalies

Shared statistical helpers module (`stats_helpers.py`) for reusable math utilities.

## [1.4.1] - 2026-02-14

### Fixed
- Metric data API returns values as list-of-lists, not dict

## [1.4.0] - 2026-02-14

### Added

5 AI analysis tools for server-side intelligence on monitoring data.

- **`correlate_alerts`** — Groups related alerts together by device, datasource, and time proximity. Instead of looking at alerts one by one, it clusters them to show which alerts are part of the same incident. Helps cut through a noisy alert storm to see "these 15 alerts are actually 3 distinct issues."
- **`get_alert_statistics`** — Aggregates alert counts across severity, device, datasource, and time buckets. Returns a statistical summary over a configurable time window — think of it as a quick dashboard view of alert volume and distribution without needing to open the portal.
- **`get_metric_anomalies`** — Detects datapoints that are deviating significantly from their historical mean using z-score analysis. Point it at a device and it flags which metrics are behaving abnormally right now. Useful for triage — instead of checking every graph, let it tell you what looks off.
- **`save_baseline`** — Snapshots a metric's historical behavior — mean, min, max, and standard deviation per datapoint — and stores it in the session. Use this to capture what "normal" looks like before a maintenance window, deployment, or any planned change.
- **`compare_to_baseline`** — Compares current metric values against a previously saved baseline. Reports deviation percentage and status (normal, elevated, critical) for each datapoint. The companion to `save_baseline` — run it after a change to see if anything drifted from where it was.

3 workflow prompts:
- `top_talkers` — Identify the noisiest devices and datasources generating the most alerts
- `rca_workflow` — Guided root cause analysis combining alert correlation, topology, and change history
- `capacity_forecast` — Forecast capacity trends and predict days-until-threshold-breach

Enhanced `alert_correlation` prompt with `device_id`/`group_id` scoping and correlation tool integration.

MCP orchestration guide resource (`lm://guide/mcp-orchestration`) documenting multi-MCP-server patterns.

Session persistence via `LM_SESSION_PERSIST_PATH` — session variables survive restarts.

HTTP analysis API: `POST /api/v1/analyze`, `GET /api/v1/analysis/{id}`, `POST /api/v1/webhooks/alert` for scheduled and webhook-triggered analysis workflows.

## [1.3.3] - 2026-02-13

### Fixed
- HTTP transport now applies the full middleware chain (tool filtering, field validation, write audit logging, session recording) — previously bypassed entirely
- HTTP `tools/list` now respects `LM_ENABLED_TOOLS` and `LM_DISABLED_TOOLS` filtering

### Changed
- Extracted shared `execute_tool()` middleware from `call_tool()` for transport-agnostic tool execution
- LMConfig cached as singleton to avoid redundant environment parsing on every tool call
- Removed dead logging infrastructure (LogLevel enum, LogEvent dataclass, 7 unused event factory functions)

## [1.3.2] - 2025-02-13

### Fixed
- Fixed 20 MCP tool schemas where parameter names did not match handler function signatures, causing "unexpected keyword argument" errors at runtime

### Added
- Registry test that validates all schema property names match handler function parameter names, preventing future mismatches

## [1.3.1] - 2025-02-12

### Fixed
- `get_change_audit` no longer crashes when the API returns `happenedOn` as an epoch integer

## [1.3.0] - 2025-02-10

### Added
- 5 MCP prompts: `cost_optimization`, `audit_review`, `alert_correlation`, `collector_health`, `troubleshoot_device`
- 6 resource schemas: escalations, reports, websites, datasources, users, audit
- 2 guide resources: tool categories index (all 152 tools) and common query examples
- `LM_LOG_LEVEL` configuration for controlling debug output (debug, info, warning, error)
- Write operation audit trail (INFO-level logging for create/update/delete actions)

### Fixed
- Wildcard sanitization applied to all 11 remaining string filter parameters across audit, cost, batchjobs, SDTs, and topology tools

## [1.2.1] - 2025-02-05

### Fixed
- Patch release with minor fixes

## [1.2.0] - 2025-02-01

### Added
- Tool filtering with `LM_ENABLED_TOOLS` and `LM_DISABLED_TOOLS` glob patterns
- Export/import support for all LogicModule types
- Cost optimization recommendation categories and detail endpoints

## [1.1.0] - 2025-01-20

### Added
- HTTP transport for remote deployments via Starlette/Uvicorn
- Session context tracking for conversational workflows
- 6 session management tools
- Health endpoints (`/health`, `/healthz`, `/readyz`) for Kubernetes
- Docker deployment with multi-stage build and Caddy reverse proxy
- CORS middleware configuration via `LM_CORS_ORIGINS`

## [1.0.1] - 2025-01-15

### Changed
- Comprehensive README update with all 146 tools documented
- Fixed installation command: `uvx --from lm-mcp lm-mcp-server`
- Added MCP Resources and Prompts documentation
- Added LMv1 authentication configuration instructions

## [1.0.0] - 2025-01-15

### Added
- **MCP Resources**: 15 schema/enum/filter resources for API reference
  - Schema resources: alerts, devices, sdts, dashboards, collectors
  - Enum resources: severity, device-status, sdt-type, alert-cleared, alert-acked, collector-build
  - Filter resources: alerts, devices, sdts, operators
- **MCP Prompts**: 5 workflow templates
  - incident_triage, capacity_review, health_check, alert_summary, sdt_planning
- **MCP Completions**: Auto-complete for tool arguments (severity, status, sdt_type, etc.)
- **LMv1 HMAC Authentication**: Support for Access ID/Key authentication
- **Ingestion APIs**: ingest_logs and push_metrics tools (requires LMv1 auth)
- **Cost Optimization Tools**: 7 tools for LM Envision cost analysis
  - get_cost_summary, get_resource_cost, get_cost_recommendations
  - get_cost_recommendation_categories, get_cost_recommendation
  - get_idle_resources, get_cloud_cost_accounts
- **LogicModule Import Tools**: 8 import tools for JSON definitions
  - import_datasource, import_configsource, import_eventsource
  - import_propertysource, import_logsource, import_topologysource
  - import_jobmonitor, import_appliesto_function
- **Website CRUD**: create_website, update_website, delete_website, create_website_group, delete_website_group
- **Alert Rule CRUD**: create_alert_rule, update_alert_rule, delete_alert_rule
- **Escalation CRUD**: create_escalation_chain, update_escalation_chain, delete_escalation_chain
- **Recipient Group CRUD**: create_recipient_group, update_recipient_group, delete_recipient_group
- **Structured Logging**: Event-based logging for API operations

### Changed
- Total tool count increased from ~120 to 146
- Development status changed to Production/Stable
- Improved metrics ingestion endpoint (changed to /rest/metric/ingest with create=true)

### Fixed
- MCP resource reading: Convert AnyUrl to string in read handler

## [0.5.1] - 2024-12-14

### Added
- MCP Registry server name in README for registry ownership validation

## [0.5.0] - 2024-12-14

### Added
- Comprehensive API filter support for all list tools
- Raw `filter` parameter for power users (LogicMonitor filter syntax)
- Named filter parameters for convenience (e.g., `name_filter`, `severity`)
- `offset` parameter for pagination on all list endpoints
- `has_more` indicator in responses for easier pagination
- Expanded README with Quick Start section and 50+ example prompts

### Changed
- All list tools now support both named parameters and raw filter expressions
- Improved pagination support across all endpoints

## [0.4.0] - 2024-12-13

### Added
- MCP tool registration with 120 tools
- Bulk operations: bulk_acknowledge_alerts, bulk_create_device_sdt, bulk_delete_sdt
- Export tools for datasources, dashboards, alert rules, escalation chains
- Active and upcoming SDT queries
- Network topology and flow tools
- Batch job management tools
- Cloud cost analysis tools
- Comprehensive LogicModule support (ConfigSources, EventSources, PropertySources, TopologySources, LogSources)

### Changed
- Improved tool descriptions for better AI understanding
- Enhanced error messages with actionable guidance

## [0.3.0] - 2024-12-13

### Added
- Dashboard management (create, update, delete dashboards and widgets)
- Report management (list, view, run, schedule reports)
- User and role management
- Access group tools
- API token tools
- Service and service group tools
- OID management tools
- Netscan execution

### Changed
- Reorganized tool modules for better maintainability
- Improved response formatting consistency

## [0.2.0] - 2024-12-12

### Added
- Alert rules tools
- Escalation chain and recipient group tools
- Ops notes and audit log tools
- Website/synthetic monitoring tools
- Collector group tools
- Device property management

### Changed
- Enhanced alert filtering options
- Improved error handling with retry logic

## [0.1.0] - 2024-12-12

### Added
- Initial release
- Bearer token authentication
- Core device management (list, create, update, delete)
- Alert management (list, view, acknowledge, add notes)
- SDT management (list, create, delete)
- Collector listing
- Basic metrics and datasource queries
- Rate limit handling with exponential backoff
- Write operation protection (disabled by default)

[2.3.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v2.2.0...v2.3.0
[2.2.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v2.1.1...v2.2.0
[2.1.1]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v2.1.0...v2.1.1
[2.1.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v2.0.1...v2.1.0
[2.0.1]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v2.0.0...v2.0.1
[2.0.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.9.6...v2.0.0
[1.9.6]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.9.5...v1.9.6
[1.9.5]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.9.2...v1.9.5
[1.9.2]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.9.0...v1.9.2
[1.9.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.8.0...v1.9.0
[1.8.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.7.2...v1.8.0
[1.7.2]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.7.1...v1.7.2
[1.7.1]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.7.0...v1.7.1
[1.7.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.6.1...v1.7.0
[1.6.1]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.6.0...v1.6.1
[1.6.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.5.1...v1.6.0
[1.5.1]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.5.0...v1.5.1
[1.5.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.4.1...v1.5.0
[1.4.1]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.4.0...v1.4.1
[1.4.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.3.3...v1.4.0
[1.3.3]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.3.2...v1.3.3
[1.3.2]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.3.1...v1.3.2
[1.3.1]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.3.0...v1.3.1
[1.3.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.2.1...v1.3.0
[1.2.1]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.2.0...v1.2.1
[1.2.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.1.0...v1.2.0
[1.1.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.0.1...v1.1.0
[1.0.1]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v1.0.0...v1.0.1
[1.0.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v0.5.1...v1.0.0
[0.5.1]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v0.5.0...v0.5.1
[0.5.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v0.4.0...v0.5.0
[0.4.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/ryanmat/mcp-server-logicmonitor/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/ryanmat/mcp-server-logicmonitor/releases/tag/v0.1.0
