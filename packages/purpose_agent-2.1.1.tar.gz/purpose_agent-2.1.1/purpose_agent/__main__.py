"""
Run Purpose Agent from the command line:

    python -m purpose_agent

Launches the interactive quickstart wizard.
"""
from purpose_agent.easy import quickstart

if __name__ == "__main__":
    quickstart()
