print("the-critic-matters")
