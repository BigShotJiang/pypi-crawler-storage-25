"""
Event types + uuid7 contracts.
"""

from dobby_collector._events import (
    LLM_COMPLETION,
    RUN_COMPLETED,
    TERMINAL_EVENT_TYPES,
    SdkBatch,
    SdkEvent,
    SdkMeta,
    iso_now,
    new_event_id,
    new_run_id,
)


class TestUuid7:
    def test_event_ids_are_unique(self) -> None:
        ids = {new_event_id() for _ in range(1000)}
        assert len(ids) == 1000, "uuid7 collisions in 1000-batch — corrupted source of entropy"

    def test_event_ids_are_sortable_by_creation_order(self) -> None:
        """uuid7 timestamps in the prefix → lexicographic sort == chronological sort."""
        ids = [new_event_id() for _ in range(100)]
        assert ids == sorted(ids), "uuid7 ids must be monotonically sortable"

    def test_run_id_format_matches_event_id(self) -> None:
        # Both come from uuid_utils.uuid7() — same shape (8-4-4-4-12 hex).
        rid = new_run_id()
        assert len(rid) == 36
        assert rid.count("-") == 4


class TestSdkEvent:
    def test_to_dict_drops_none_fields(self) -> None:
        ev = SdkEvent(
            event_id="e1",
            run_id="r1",
            timestamp="2026-05-13T10:00:00Z",
            type=RUN_COMPLETED,
        )
        out = ev.to_dict()
        assert out == {
            "event_id": "e1",
            "run_id": "r1",
            "timestamp": "2026-05-13T10:00:00Z",
            "type": RUN_COMPLETED,
        }
        assert "name" not in out
        assert "data" not in out

    def test_to_dict_preserves_zero_falsy_values(self) -> None:
        """duration_ms=0 and status='' are valid distinct values — must not be dropped."""
        ev = SdkEvent(
            event_id="e1",
            run_id="r1",
            timestamp="t",
            type=LLM_COMPLETION,
            duration_ms=0.0,
            status="success",
        )
        out = ev.to_dict()
        assert out["duration_ms"] == 0.0
        assert out["status"] == "success"

    def test_to_dict_preserves_nested_data(self) -> None:
        ev = SdkEvent(
            event_id="e1",
            run_id="r1",
            timestamp="t",
            type=LLM_COMPLETION,
            data={"model": "gpt-4o", "completion": "hi", "prompt_tokens": 5},
        )
        out = ev.to_dict()
        assert out["data"] == {"model": "gpt-4o", "completion": "hi", "prompt_tokens": 5}


class TestSdkBatch:
    def test_batch_with_meta(self) -> None:
        batch = SdkBatch(
            events=[
                SdkEvent(
                    event_id="e1", run_id="r1", timestamp="t", type=RUN_COMPLETED
                ),
            ],
            sdk_meta=SdkMeta(version="0.1.0", framework="langchain"),
        )
        out = batch.to_dict()
        assert "events" in out
        assert len(out["events"]) == 1
        assert out["sdk_meta"]["version"] == "0.1.0"
        assert out["sdk_meta"]["framework"] == "langchain"

    def test_batch_without_meta(self) -> None:
        batch = SdkBatch(events=[])
        out = batch.to_dict()
        assert out == {"events": []}
        assert "sdk_meta" not in out


class TestTerminalSet:
    def test_terminal_types_covers_three_endings(self) -> None:
        assert frozenset(
            {"run.completed", "run.failed", "run.cancelled"}
        ) == TERMINAL_EVENT_TYPES

    def test_iso_now_format(self) -> None:
        ts = iso_now()
        # Format: YYYY-MM-DDTHH:MM:SS.mmmZ
        assert ts.endswith("Z")
        assert "T" in ts
        # 24 chars total (4-2-2 T 2-2-2 . 3 Z)
        assert len(ts) == 24
