"""
Sender contracts:
  - POST with correct URL, auth, body shape
  - 5xx triggers retry, 4xx drops the batch (no retry)
  - Network errors retry per schedule
  - Sender thread starts + drains + stops cleanly
  - Terminal events trigger immediate flush
"""

from typing import Any
from unittest.mock import MagicMock, patch

import httpx

from dobby_collector._buffer import EventBuffer
from dobby_collector._events import RUN_STARTED, SdkEvent
from dobby_collector._sender import Sender


def _ev(event_id: str = "e1", event_type: str = RUN_STARTED) -> SdkEvent:
    return SdkEvent(
        event_id=event_id,
        run_id="r1",
        timestamp="2026-05-13T10:00:00Z",
        type=event_type,
    )


def _build_sender(
    *,
    buffer: EventBuffer,
    http_client: httpx.Client,
    flush_interval: float = 0.05,
) -> Sender:
    return Sender(
        buffer=buffer,
        api_key="gk_test_abc",
        connector_id="wc_test",
        base_url="https://dobby-test.local",
        sdk_version="0.1.0",
        flush_interval_seconds=flush_interval,
        batch_size=100,
        framework="langchain",
        http_client=http_client,
    )


def _http_with_response(
    status_code: int, body: Any = None, *, capture: list[Any] | None = None
) -> httpx.Client:
    """Return an httpx.Client whose post() returns a canned Response."""
    response = httpx.Response(status_code, json=body or {"ok": True})

    def fake_send(request: httpx.Request) -> httpx.Response:
        if capture is not None:
            capture.append(request)
        return response

    transport = httpx.MockTransport(fake_send)
    return httpx.Client(transport=transport)


class TestSenderHttp:
    def test_posts_to_correct_url_with_bearer_auth(self) -> None:
        buf = EventBuffer(max_events=10)
        buf.append(_ev())
        captured: list[httpx.Request] = []
        http = _http_with_response(200, capture=captured)

        sender = _build_sender(buffer=buf, http_client=http)
        sender._drain_and_send()

        assert len(captured) == 1
        req = captured[0]
        assert req.url == "https://dobby-test.local/api/v1/webhooks/workloads/wc_test"
        assert req.headers["authorization"] == "Bearer gk_test_abc"
        assert req.headers["content-type"] == "application/json"
        assert "dobby-collector/0.1.0" in req.headers["user-agent"]

    def test_emits_w3c_traceparent_header(self) -> None:
        """Option C (v0.4.0+) — every POST carries a fresh W3C traceparent.

        Server-side webhook handler stamps this onto workload_runs.metadata_json,
        which detectTracingEnabled (Surrounding-mode governance detector) counts.
        """
        import re

        buf = EventBuffer(max_events=10)
        buf.append(_ev())
        captured: list[httpx.Request] = []
        http = _http_with_response(200, capture=captured)

        sender = _build_sender(buffer=buf, http_client=http)
        sender._drain_and_send()

        assert "traceparent" in captured[0].headers
        traceparent = captured[0].headers["traceparent"]
        # W3C format: 00-{32hex}-{16hex}-01
        assert re.match(r"^00-[0-9a-f]{32}-[0-9a-f]{16}-01$", traceparent), (
            f"traceparent {traceparent!r} must match W3C spec"
        )

    def test_traceparent_unique_per_batch(self) -> None:
        """Each batch POST gets its own fresh trace-id + span-id.

        Per-process or per-event reuse would defeat trace correlation —
        per-batch is the right granularity (one outbound transaction per batch).
        """
        buf = EventBuffer(max_events=10)
        captured: list[httpx.Request] = []
        http = _http_with_response(200, capture=captured)
        sender = _build_sender(buffer=buf, http_client=http)

        # 3 separate batches
        for i in range(3):
            buf.append(_ev(f"e{i}"))
            sender._drain_and_send()

        assert len(captured) == 3
        traceparents = [r.headers["traceparent"] for r in captured]
        # All three must be distinct (uniqueness via secrets.token_hex(16+8))
        assert len(set(traceparents)) == 3, (
            f"Each batch must emit a unique traceparent, got {traceparents}"
        )

    def test_traceparent_never_uses_all_zero_sentinels(self) -> None:
        """W3C spec rejects all-zero trace-id (00...0) and span-id as invalid sentinels.

        secrets.token_hex(16) collision-rate to all zeros is ~1/2^128 —
        essentially impossible — but the regex below would fail anyway if
        the generator changed to use a weaker source.
        """
        from dobby_collector._sender import _make_traceparent

        # Generate many — the probability all of them collide on zeros is
        # vanishingly small but we also assert per-instance.
        for _ in range(50):
            tp = _make_traceparent()
            parts = tp.split("-")
            assert len(parts) == 4
            assert parts[0] == "00"
            assert parts[1] != "0" * 32, "trace-id MUST NOT be all zeros (W3C sentinel)"
            assert parts[2] != "0" * 16, "span-id MUST NOT be all zeros (W3C sentinel)"
            assert parts[3] == "01"

    def test_body_shape_matches_server_adapter(self) -> None:
        """Payload must be {events:[...], sdk_meta:{version, framework}}."""
        import json

        buf = EventBuffer(max_events=10)
        buf.append(_ev("e1"))
        buf.append(_ev("e2"))
        captured: list[httpx.Request] = []
        http = _http_with_response(200, capture=captured)

        sender = _build_sender(buffer=buf, http_client=http)
        sender._drain_and_send()

        body = json.loads(captured[0].content)
        assert "events" in body
        assert len(body["events"]) == 2
        assert body["events"][0]["event_id"] == "e1"
        assert body["events"][0]["type"] == RUN_STARTED
        assert body["sdk_meta"]["version"] == "0.1.0"
        assert body["sdk_meta"]["framework"] == "langchain"

    def test_2xx_no_retry(self) -> None:
        buf = EventBuffer(max_events=10)
        buf.append(_ev())
        captured: list[httpx.Request] = []
        http = _http_with_response(202, capture=captured)

        sender = _build_sender(buffer=buf, http_client=http)
        sender._drain_and_send()

        assert len(captured) == 1, "2xx should not trigger retry"

    def test_4xx_drops_no_retry(self) -> None:
        """4xx = customer-side bug. Drop batch + log, do NOT retry."""
        buf = EventBuffer(max_events=10)
        buf.append(_ev())
        captured: list[httpx.Request] = []
        http = _http_with_response(401, body={"error": "bad token"}, capture=captured)

        sender = _build_sender(buffer=buf, http_client=http)
        sender._drain_and_send()

        assert len(captured) == 1, "4xx must NOT retry"


class TestSenderRetry:
    def test_5xx_retries_per_schedule(self) -> None:
        """5xx → 4 total attempts (initial + 3 retries from RETRY_DELAYS_SECONDS)."""
        buf = EventBuffer(max_events=10)
        buf.append(_ev())
        captured: list[httpx.Request] = []
        http = _http_with_response(503, capture=captured)

        # Patch time.sleep so the test runs fast instead of 1+5+25=31 seconds
        with patch("dobby_collector._sender.time.sleep"):
            sender = _build_sender(buffer=buf, http_client=http)
            sender._drain_and_send()

        assert len(captured) == 4, "5xx should produce 4 attempts (1 initial + 3 retries)"

    def test_5xx_then_success_stops_retrying(self) -> None:
        """First call 503, second 200 → 2 attempts only."""
        buf = EventBuffer(max_events=10)
        buf.append(_ev())
        captured: list[httpx.Request] = []
        attempt = {"n": 0}

        def fake_send(request: httpx.Request) -> httpx.Response:
            captured.append(request)
            attempt["n"] += 1
            if attempt["n"] == 1:
                return httpx.Response(503)
            return httpx.Response(200, json={"ok": True})

        http = httpx.Client(transport=httpx.MockTransport(fake_send))

        with patch("dobby_collector._sender.time.sleep"):
            sender = _build_sender(buffer=buf, http_client=http)
            sender._drain_and_send()

        assert len(captured) == 2

    def test_network_error_retries(self) -> None:
        """ConnectError = network failure → retry per schedule."""
        buf = EventBuffer(max_events=10)
        buf.append(_ev())
        call_count = {"n": 0}

        def fake_send(request: httpx.Request) -> httpx.Response:
            call_count["n"] += 1
            raise httpx.ConnectError("connection refused")

        http = httpx.Client(transport=httpx.MockTransport(fake_send))

        with patch("dobby_collector._sender.time.sleep"):
            sender = _build_sender(buffer=buf, http_client=http)
            sender._drain_and_send()

        assert call_count["n"] == 4, "network error should retry all 3 delays"


class TestSenderThread:
    def test_start_stop_lifecycle(self) -> None:
        buf = EventBuffer(max_events=10)
        captured: list[httpx.Request] = []
        http = _http_with_response(200, capture=captured)

        sender = _build_sender(buffer=buf, http_client=http, flush_interval=0.05)
        sender.start()
        assert sender._thread is not None
        assert sender._thread.is_alive()

        # Push event; thread should pick it up on next interval tick.
        buf.append(_ev("threaded_event"))
        # Wait up to 500ms for the post.
        import time as _time
        for _ in range(50):
            if captured:
                break
            _time.sleep(0.01)

        sender.stop(timeout=1.0)
        assert sender._thread is None
        assert len(captured) >= 1

    def test_stop_drains_pending_events(self) -> None:
        """stop() must flush whatever is in the buffer before returning."""
        buf = EventBuffer(max_events=10)
        captured: list[httpx.Request] = []
        http = _http_with_response(200, capture=captured)

        # Long flush interval — events would NOT auto-flush during the test
        sender = _build_sender(buffer=buf, http_client=http, flush_interval=60.0)
        sender.start()

        # Push events, then immediately stop — the final drain should pick them up.
        for i in range(3):
            buf.append(_ev(f"e{i}"))

        sender.stop(timeout=2.0)
        assert len(captured) >= 1, "stop() should flush pending events"

    def test_flush_now_wakes_thread_early(self) -> None:
        buf = EventBuffer(max_events=10)
        captured: list[httpx.Request] = []
        http = _http_with_response(200, capture=captured)

        sender = _build_sender(buffer=buf, http_client=http, flush_interval=60.0)
        sender.start()

        buf.append(_ev("urgent"))
        sender.flush_now()

        import time as _time
        for _ in range(50):
            if captured:
                break
            _time.sleep(0.01)

        sender.stop(timeout=1.0)
        assert len(captured) >= 1


class TestSenderRobustness:
    def test_unrecoverable_exception_does_not_kill_thread(self) -> None:
        """If httpx raises an unknown exception, the sender swallows it + drops the batch."""
        buf = EventBuffer(max_events=10)
        buf.append(_ev())

        def fake_send(_req: httpx.Request) -> httpx.Response:
            raise RuntimeError("simulated weirdness")

        http = httpx.Client(transport=httpx.MockTransport(fake_send))
        sender = _build_sender(buffer=buf, http_client=http)

        # Must not raise.
        sender._drain_and_send()

    def test_drain_loop_handles_buffer_exception_gracefully(self) -> None:
        """If buffer.drain() raises, the sender swallows it (thread must never die)."""
        buf = MagicMock(spec=EventBuffer)
        buf.drain.side_effect = RuntimeError("boom")

        http = _http_with_response(200)
        sender = _build_sender(buffer=buf, http_client=http)

        # Must not raise.
        sender._drain_and_send()
