"""
Ring buffer contracts:
  - append + drain in FIFO order
  - capped at max_events — silently drops oldest when full
  - dropped_count tracks overflow
  - flush signal wakes the sender
"""

import threading
import time

import pytest

from dobby_collector._buffer import EventBuffer
from dobby_collector._events import RUN_STARTED, SdkEvent


def _ev(event_id: str) -> SdkEvent:
    return SdkEvent(
        event_id=event_id,
        run_id="r1",
        timestamp="2026-05-13T10:00:00Z",
        type=RUN_STARTED,
    )


class TestEventBuffer:
    def test_append_and_drain_fifo(self) -> None:
        buf = EventBuffer(max_events=10)
        buf.append(_ev("a"))
        buf.append(_ev("b"))
        buf.append(_ev("c"))

        assert len(buf) == 3
        drained = buf.drain(max_count=10)
        assert [e.event_id for e in drained] == ["a", "b", "c"]
        assert len(buf) == 0

    def test_drain_respects_max_count(self) -> None:
        buf = EventBuffer(max_events=10)
        for i in range(5):
            buf.append(_ev(f"e{i}"))

        first = buf.drain(max_count=2)
        assert [e.event_id for e in first] == ["e0", "e1"]
        assert len(buf) == 3

        rest = buf.drain(max_count=99)
        assert [e.event_id for e in rest] == ["e2", "e3", "e4"]

    def test_drain_on_empty_returns_empty_list(self) -> None:
        buf = EventBuffer(max_events=10)
        assert buf.drain(max_count=5) == []

    def test_overflow_drops_oldest(self) -> None:
        buf = EventBuffer(max_events=3)
        for i in range(5):
            buf.append(_ev(f"e{i}"))

        # 2 events dropped (e0, e1); buffer holds [e2, e3, e4]
        assert len(buf) == 3
        assert buf.dropped_count == 2
        drained = buf.drain(max_count=10)
        assert [e.event_id for e in drained] == ["e2", "e3", "e4"]

    def test_reset_dropped_count(self) -> None:
        buf = EventBuffer(max_events=2)
        for i in range(5):
            buf.append(_ev(f"e{i}"))
        assert buf.dropped_count == 3
        assert buf.reset_dropped_count() == 3
        assert buf.dropped_count == 0

    def test_max_events_must_be_positive(self) -> None:
        with pytest.raises(ValueError, match="max_events must be > 0"):
            EventBuffer(max_events=0)
        with pytest.raises(ValueError, match="max_events must be > 0"):
            EventBuffer(max_events=-1)

    def test_wait_for_flush_signal_returns_false_on_timeout(self) -> None:
        buf = EventBuffer(max_events=10)
        start = time.monotonic()
        triggered = buf.wait_for_flush_signal(timeout=0.05)
        elapsed = time.monotonic() - start
        assert triggered is False
        assert elapsed >= 0.04, "wait should have blocked ~50ms"

    def test_request_flush_wakes_waiter(self) -> None:
        buf = EventBuffer(max_events=10)
        results: list[bool] = []

        def waiter() -> None:
            results.append(buf.wait_for_flush_signal(timeout=2.0))

        thread = threading.Thread(target=waiter)
        thread.start()
        time.sleep(0.05)  # let waiter enter wait()
        buf.request_flush()
        thread.join(timeout=1.0)
        assert results == [True]

    def test_flush_signal_auto_clears(self) -> None:
        """After wait returns True, the next wait must block again (signal consumed)."""
        buf = EventBuffer(max_events=10)
        buf.request_flush()
        assert buf.wait_for_flush_signal(timeout=0.5) is True
        # Now signal is cleared; next wait should time out
        assert buf.wait_for_flush_signal(timeout=0.05) is False

    def test_concurrent_appends_are_thread_safe(self) -> None:
        """N threads each append 100 events to a 10K buffer — no events lost, no exceptions."""
        buf = EventBuffer(max_events=10_000)
        n_threads = 10
        per_thread = 100

        def worker(tid: int) -> None:
            for i in range(per_thread):
                buf.append(_ev(f"t{tid}-e{i}"))

        threads = [threading.Thread(target=worker, args=(t,)) for t in range(n_threads)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(buf) == n_threads * per_thread
        assert buf.dropped_count == 0
