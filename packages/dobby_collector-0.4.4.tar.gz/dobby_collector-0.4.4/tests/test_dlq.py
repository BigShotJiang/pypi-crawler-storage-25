"""
SQLite DLQ tests
=================

Pinned contracts:
  - enqueue persists + assigns batch_id; drain returns oldest-first
  - delete removes by id; count reflects current size
  - bounded `max_rows` evicts oldest on overflow
  - disabled mode (path=None) is silent no-op — every method works, all return 0/None/[]
  - schema-version mismatch on open drops existing rows + resets
  - increment_attempts updates the column for the named ids
  - prune_older_than reaps by created_at cutoff
  - corruption recovery: a malformed file resets cleanly
  - non-JSON-serializable payload → enqueue returns None, no crash
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import pytest

from dobby_collector._dlq import Dlq, _SCHEMA_VERSION


@pytest.fixture
def dlq_path(tmp_path: Path) -> Path:
    return tmp_path / "dlq.sqlite"


# ---------------------------------------------------------------------------
# Disabled mode (path=None)
# ---------------------------------------------------------------------------


class TestDisabled:
    def test_disabled_dlq_path_is_none(self) -> None:
        dlq = Dlq(path=None)
        assert dlq.enabled is False
        assert dlq.path is None


# ---------------------------------------------------------------------------
# Path coercion — `init(dlq_path=...)` is a documented public arg and
# customers naturally pass a plain string. The Dlq boundary must coerce so
# `self._path.parent` doesn't AttributeError + silently disable the DLQ.
# (Regression: shipped broken in v0.1.0 — caught 2026-05-14 comprehensive QA.)
# ---------------------------------------------------------------------------


class TestPathCoercion:
    def test_string_path_is_coerced_and_works(self, tmp_path: Path) -> None:
        str_path = str(tmp_path / "subdir" / "dlq.sqlite")  # nested → mkdir must run
        dlq = Dlq(path=str_path)
        assert dlq.enabled is True
        assert isinstance(dlq.path, Path)
        # enqueue must actually work — proves _init_db ran, not just no-crash
        batch_id = dlq.enqueue({"events": [{"event_id": "e1"}]})
        assert batch_id is not None
        assert dlq.count() == 1

    def test_path_object_passes_through(self, dlq_path: Path) -> None:
        dlq = Dlq(path=dlq_path)
        assert isinstance(dlq.path, Path)
        assert dlq.enabled is True

    def test_disabled_enqueue_returns_none(self) -> None:
        dlq = Dlq(path=None)
        assert dlq.enqueue({"events": [{"event_id": "e1"}]}) is None

    def test_disabled_drain_returns_empty(self) -> None:
        dlq = Dlq(path=None)
        assert dlq.drain() == []

    def test_disabled_count_is_zero(self) -> None:
        dlq = Dlq(path=None)
        assert dlq.count() == 0


# ---------------------------------------------------------------------------
# Enabled mode — basic CRUD
# ---------------------------------------------------------------------------


class TestEnabled:
    def test_enqueue_assigns_increasing_ids(self, dlq_path: Path) -> None:
        dlq = Dlq(path=dlq_path)
        id1 = dlq.enqueue({"events": [{"e": 1}]})
        id2 = dlq.enqueue({"events": [{"e": 2}]})
        assert id1 is not None and id2 is not None
        assert id2 > id1

    def test_count_reflects_size(self, dlq_path: Path) -> None:
        dlq = Dlq(path=dlq_path)
        assert dlq.count() == 0
        dlq.enqueue({"e": "a"})
        dlq.enqueue({"e": "b"})
        dlq.enqueue({"e": "c"})
        assert dlq.count() == 3

    def test_drain_returns_oldest_first(self, dlq_path: Path) -> None:
        dlq = Dlq(path=dlq_path)
        dlq.enqueue({"e": "first"})
        # Small sleep ensures different created_at timestamps.
        time.sleep(0.01)
        dlq.enqueue({"e": "second"})
        time.sleep(0.01)
        dlq.enqueue({"e": "third"})

        rows = dlq.drain(limit=10)
        payloads = [p["e"] for _bid, p in rows]
        assert payloads == ["first", "second", "third"]

    def test_drain_limit_caps_results(self, dlq_path: Path) -> None:
        dlq = Dlq(path=dlq_path)
        for i in range(20):
            dlq.enqueue({"i": i})
        rows = dlq.drain(limit=5)
        assert len(rows) == 5
        assert [p["i"] for _bid, p in rows] == [0, 1, 2, 3, 4]

    def test_delete_removes_by_id(self, dlq_path: Path) -> None:
        dlq = Dlq(path=dlq_path)
        id1 = dlq.enqueue({"e": "keep"})
        id2 = dlq.enqueue({"e": "drop"})
        assert id2 is not None
        deleted = dlq.delete([id2])
        assert deleted == 1
        rows = dlq.drain(limit=10)
        assert [p["e"] for _bid, p in rows] == ["keep"]

    def test_delete_empty_list_is_no_op(self, dlq_path: Path) -> None:
        dlq = Dlq(path=dlq_path)
        dlq.enqueue({"e": "x"})
        assert dlq.delete([]) == 0
        assert dlq.count() == 1

    def test_increment_attempts(self, dlq_path: Path) -> None:
        dlq = Dlq(path=dlq_path)
        id1 = dlq.enqueue({"e": "x"})
        assert id1 is not None
        dlq.increment_attempts([id1])
        dlq.increment_attempts([id1])
        # We can't read `attempts` directly via the public API — peek via SQL.
        import sqlite3

        with sqlite3.connect(str(dlq_path)) as conn:
            row = conn.execute(
                "SELECT attempts FROM pending_batches WHERE batch_id = ?", (id1,)
            ).fetchone()
        assert row[0] == 2

    def test_prune_older_than(self, dlq_path: Path) -> None:
        dlq = Dlq(path=dlq_path)
        # Mark all 3 batches with manual created_at via direct SQL — easier than
        # waiting hours.
        import sqlite3

        for label in ["old1", "old2", "fresh"]:
            dlq.enqueue({"e": label})
        with sqlite3.connect(str(dlq_path)) as conn:
            conn.execute(
                "UPDATE pending_batches SET created_at = ? WHERE payload LIKE '%old%'",
                (time.time() - 86_400 * 10,),  # 10 days ago
            )
        deleted = dlq.prune_older_than(86_400 * 7)  # cutoff 7 days
        assert deleted == 2
        assert dlq.count() == 1


# ---------------------------------------------------------------------------
# Bounded eviction
# ---------------------------------------------------------------------------


class TestEviction:
    def test_overflow_evicts_oldest(self, dlq_path: Path) -> None:
        dlq = Dlq(path=dlq_path, max_rows=3)
        for i in range(5):
            dlq.enqueue({"i": i})
            time.sleep(0.005)  # ensure increasing created_at
        rows = dlq.drain(limit=10)
        assert len(rows) == 3
        # The 2 oldest (i=0, 1) should have been evicted; we keep 2,3,4.
        assert [p["i"] for _bid, p in rows] == [2, 3, 4]


# ---------------------------------------------------------------------------
# Schema versioning + corruption recovery
# ---------------------------------------------------------------------------


class TestSchemaAndCorruption:
    def test_schema_version_persisted(self, dlq_path: Path) -> None:
        Dlq(path=dlq_path)
        import sqlite3

        with sqlite3.connect(str(dlq_path)) as conn:
            row = conn.execute(
                "SELECT value FROM dlq_meta WHERE key='schema_version'"
            ).fetchone()
        assert int(row[0]) == _SCHEMA_VERSION

    def test_stale_schema_version_drops_rows_on_reopen(self, dlq_path: Path) -> None:
        # Open + add data
        dlq = Dlq(path=dlq_path)
        dlq.enqueue({"e": "x"})
        assert dlq.count() == 1
        # Tamper: force the schema version to look stale. Use a non-zero
        # value to simulate "rows from a PRIOR install" (vs zero/None which
        # signals "fresh install — table just got created").
        import sqlite3

        conn = sqlite3.connect(str(dlq_path), isolation_level=None)
        try:
            conn.execute(
                "UPDATE dlq_meta SET value = ? WHERE key='schema_version'", ("99",)
            )
        finally:
            conn.close()
        # Re-open — should drop the row + bump version
        dlq2 = Dlq(path=dlq_path)
        assert dlq2.count() == 0
        conn2 = sqlite3.connect(str(dlq_path))
        try:
            row = conn2.execute(
                "SELECT value FROM dlq_meta WHERE key='schema_version'"
            ).fetchone()
            assert int(row[0]) == _SCHEMA_VERSION
        finally:
            conn2.close()

    def test_non_serializable_payload_returns_none(self, dlq_path: Path) -> None:
        dlq = Dlq(path=dlq_path)

        class NotJsonable:
            pass

        result = dlq.enqueue({"thing": NotJsonable()})  # type: ignore[dict-item]
        assert result is None
        assert dlq.count() == 0

    def test_corrupt_file_is_reset(self, dlq_path: Path) -> None:
        # Write garbage to the would-be sqlite path
        dlq_path.parent.mkdir(parents=True, exist_ok=True)
        dlq_path.write_bytes(b"\x00\x01\x02 NOT SQLITE")
        # Init should NOT raise; corruption-recovery resets the file
        dlq = Dlq(path=dlq_path)
        # The Dlq constructor doesn't auto-reset on first read — it only
        # detects corruption on a query. So a count() should trip the reset.
        assert dlq.count() == 0
        # Enqueue should now work cleanly
        bid = dlq.enqueue({"e": "ok"})
        assert bid is not None


# ---------------------------------------------------------------------------
# Unwritable path / mkdir-parents
# ---------------------------------------------------------------------------


class TestUnwritable:
    def test_nested_path_creates_parent_dirs(self, tmp_path: Path) -> None:
        nested = tmp_path / "deeply" / "nested" / "dir" / "dlq.sqlite"
        dlq = Dlq(path=nested)
        assert dlq.enabled is True
        bid = dlq.enqueue({"e": "x"})
        assert bid is not None
        assert nested.exists()
