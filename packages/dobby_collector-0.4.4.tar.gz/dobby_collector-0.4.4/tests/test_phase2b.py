"""
Phase 2b integration tests
===========================

  - sdk.dropped backpressure: buffer overflow drop count surfaces in
    sdk_meta.dropped_events_since_last_batch
  - DLQ persists on retry-exhausted 5xx; gets drained on next flush
  - DLQ does NOT persist 4xx (customer error — wouldn't help to retry)
  - Successful send after DLQ persistence → batch deleted from DLQ
  - LangChain handler emits events that pass through the sender end-to-end
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import httpx
import pytest

from dobby_collector._buffer import EventBuffer
from dobby_collector._dlq import Dlq
from dobby_collector._events import RUN_STARTED, SdkEvent
from dobby_collector._sender import Sender


def _ev(event_id: str = "e1") -> SdkEvent:
    return SdkEvent(
        event_id=event_id,
        run_id="r1",
        timestamp="2026-05-13T10:00:00Z",
        type=RUN_STARTED,
    )


def _http_capturing(
    status_code: int, capture: list[httpx.Request]
) -> httpx.Client:
    response = httpx.Response(status_code, json={"ok": True})

    def fake_send(request: httpx.Request) -> httpx.Response:
        capture.append(request)
        return response

    return httpx.Client(transport=httpx.MockTransport(fake_send))


def _build_sender(
    buf: EventBuffer,
    http_client: httpx.Client,
    *,
    dlq: Dlq | None = None,
) -> Sender:
    return Sender(
        buffer=buf,
        api_key="gk_test_abc",
        connector_id="wc_test",
        base_url="https://dobby-test.local",
        sdk_version="0.1.0",
        flush_interval_seconds=0.05,
        batch_size=100,
        framework="langchain",
        http_client=http_client,
        dlq=dlq,
    )


def _body(req: httpx.Request) -> dict[str, Any]:
    return json.loads(req.content.decode("utf-8"))


# ---------------------------------------------------------------------------
# sdk.dropped backpressure
# ---------------------------------------------------------------------------


class TestDroppedBackpressure:
    def test_no_drops_no_field_in_meta(self) -> None:
        """Healthy batches don't carry dropped_events_since_last_batch."""
        buf = EventBuffer(max_events=10)
        buf.append(_ev())
        captured: list[httpx.Request] = []
        sender = _build_sender(buf, _http_capturing(200, captured))
        sender._drain_and_send()
        assert len(captured) == 1
        body = _body(captured[0])
        # Field omitted entirely from sdk_meta when count == 0
        assert body["sdk_meta"].get("dropped_events_since_last_batch") is None

    def test_buffer_overflow_surfaces_in_meta(self) -> None:
        """When the buffer drops events, the next batch reports the count."""
        buf = EventBuffer(max_events=3)
        # Overflow: append 5, only last 3 retained — 2 dropped
        for i in range(5):
            buf.append(_ev(f"e{i}"))
        assert buf.dropped_count == 2

        captured: list[httpx.Request] = []
        sender = _build_sender(buf, _http_capturing(200, captured))
        sender._drain_and_send()

        assert len(captured) == 1
        body = _body(captured[0])
        assert body["sdk_meta"]["dropped_events_since_last_batch"] == 2
        # Counter must be reset after the batch carries the value.
        assert buf.dropped_count == 0

    def test_dropped_count_clears_after_send(self) -> None:
        """Two consecutive batches: drops in batch 1, healthy in batch 2."""
        buf = EventBuffer(max_events=3)
        for i in range(5):
            buf.append(_ev(f"e{i}"))
        captured: list[httpx.Request] = []
        sender = _build_sender(buf, _http_capturing(200, captured))
        sender._drain_and_send()
        # Add a fresh event, no overflow
        buf.append(_ev("fresh"))
        sender._drain_and_send()
        assert len(captured) == 2
        b1 = _body(captured[0])
        b2 = _body(captured[1])
        assert b1["sdk_meta"]["dropped_events_since_last_batch"] == 2
        assert b2["sdk_meta"].get("dropped_events_since_last_batch") is None


# ---------------------------------------------------------------------------
# DLQ persistence on retry exhaustion
# ---------------------------------------------------------------------------


class TestDlqPersistence:
    def test_retry_exhausted_5xx_persists_to_dlq(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        # Make retries instant so the test doesn't actually sleep 31s
        monkeypatch.setattr(
            "dobby_collector._sender.RETRY_DELAYS_SECONDS", (0.0, 0.0, 0.0)
        )
        buf = EventBuffer(max_events=10)
        buf.append(_ev("important"))

        # Always 503 → exhaust retries
        http = _http_capturing(503, [])
        dlq = Dlq(path=tmp_path / "dlq.sqlite")
        sender = _build_sender(buf, http, dlq=dlq)
        sender._drain_and_send()

        # The batch should now be in the DLQ for later retry.
        assert dlq.count() == 1
        rows = dlq.drain(limit=5)
        assert len(rows) == 1
        _bid, payload = rows[0]
        assert len(payload["events"]) == 1
        assert payload["events"][0]["event_id"] == "important"

    def test_4xx_does_not_persist_to_dlq(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Customer-side errors (bad token, banned connector) shouldn't sit in DLQ forever."""
        monkeypatch.setattr(
            "dobby_collector._sender.RETRY_DELAYS_SECONDS", (0.0, 0.0, 0.0)
        )
        buf = EventBuffer(max_events=10)
        buf.append(_ev())

        http = _http_capturing(401, [])
        dlq = Dlq(path=tmp_path / "dlq.sqlite")
        sender = _build_sender(buf, http, dlq=dlq)
        sender._drain_and_send()

        assert dlq.count() == 0

    def test_dlq_is_drained_on_next_flush(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Pending DLQ rows get sent + removed on the next successful flush."""
        monkeypatch.setattr(
            "dobby_collector._sender.RETRY_DELAYS_SECONDS", (0.0, 0.0, 0.0)
        )
        # Pre-seed the DLQ with a payload as if a prior process had failed.
        dlq = Dlq(path=tmp_path / "dlq.sqlite")
        legacy_payload = {
            "events": [
                {
                    "event_id": "legacy1",
                    "run_id": "r_legacy",
                    "timestamp": "2026-05-13T09:00:00Z",
                    "type": "run.started",
                }
            ],
            "sdk_meta": {"version": "0.1.0"},
        }
        dlq.enqueue(legacy_payload)
        assert dlq.count() == 1

        # Buffer is empty — only the DLQ row exists.
        buf = EventBuffer(max_events=10)
        captured: list[httpx.Request] = []
        http = _http_capturing(200, captured)
        sender = _build_sender(buf, http, dlq=dlq)
        sender._drain_and_send()

        # DLQ batch was sent + removed.
        assert len(captured) == 1
        body = _body(captured[0])
        assert body["events"][0]["event_id"] == "legacy1"
        assert dlq.count() == 0

    def test_dlq_failed_drain_increments_attempts(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """If the DLQ batch also fails on resend, attempts counter bumps."""
        monkeypatch.setattr(
            "dobby_collector._sender.RETRY_DELAYS_SECONDS", (0.0, 0.0, 0.0)
        )
        dlq = Dlq(path=tmp_path / "dlq.sqlite")
        dlq.enqueue({"events": [{"event_id": "x", "run_id": "y", "type": "z", "timestamp": "t"}]})

        buf = EventBuffer(max_events=10)
        http = _http_capturing(503, [])
        sender = _build_sender(buf, http, dlq=dlq)
        sender._drain_and_send()

        # Row should still be in DLQ with attempts >= 1
        import sqlite3
        conn = sqlite3.connect(str(tmp_path / "dlq.sqlite"))
        try:
            row = conn.execute(
                "SELECT attempts FROM pending_batches LIMIT 1"
            ).fetchone()
        finally:
            conn.close()
        assert row is not None and row[0] >= 1

    def test_dlq_disabled_drops_silently_on_retry_exhaustion(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When DLQ is None, batch is dropped + logged (Phase 2a behavior preserved)."""
        monkeypatch.setattr(
            "dobby_collector._sender.RETRY_DELAYS_SECONDS", (0.0, 0.0, 0.0)
        )
        buf = EventBuffer(max_events=10)
        buf.append(_ev())
        http = _http_capturing(503, [])
        sender = _build_sender(buf, http, dlq=None)
        # Must not raise.
        sender._drain_and_send()
