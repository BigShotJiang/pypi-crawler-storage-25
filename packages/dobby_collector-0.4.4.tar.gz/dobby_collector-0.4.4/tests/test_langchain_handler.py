"""
DobbyCallbackHandler — LangChain auto-instrument tests
=======================================================

Each LangChain callback type maps to a Dobby SDK event. These tests fire
the handler's `on_*` methods directly with realistic args (no actual
LangChain runtime — handler is a pure-Python callback receiver) and
assert the resulting buffered SDK events match the canonical wire shape.

Contracts pinned:
  - on_chain_start at top level (parent_run_id=None) AUTO-starts an SDK run
  - on_chain_end at top level closes that SDK run
  - on_llm_start emits llm.start with model + prompt + params
  - on_llm_end emits llm.completion with completion + token_usage
  - on_tool_start emits tool.start with tool_name + args
  - on_tool_end emits tool.end paired via parent_event_id
  - on_agent_action emits agent.step with thought + action + action_input
  - LangChain run_id (UUID) maps deterministically to SDK event_id
  - Nested chains: parent_run_id → parent_event_id propagation
  - All callbacks NEVER raise — exception inside any handler is swallowed
  - Handler works without init() — silent no-op (sender thread not running)
  - Large prompts truncated at max_payload_chars
"""

from __future__ import annotations

from typing import Any
from uuid import UUID, uuid4

import pytest

import dobby_collector
from dobby_collector import _config
from dobby_collector._events import (
    AGENT_STEP,
    CHAIN_END,
    CHAIN_START,
    LLM_COMPLETION,
    LLM_START,
    TOOL_END,
    TOOL_START,
)
from dobby_collector.integrations.langchain import DobbyCallbackHandler


def _drain() -> list[dict]:
    """Read every event the SDK buffered so far, as dicts."""
    c = _config.get_collector()
    assert c is not None, "SDK must be initialized for this test"
    events = c.buffer.drain(max_count=10_000)
    return [e.to_dict() for e in events]


def _init_sdk() -> None:
    """Init with a 60s flush interval so events stay in buffer for assertions."""
    dobby_collector.init(
        api_key="gk_test_abc",
        connector_id="wc_test",
        flush_interval_seconds=60.0,
    )


class _FakeLLMResult:
    """Stand-in for langchain_core.outputs.LLMResult."""

    def __init__(self, text: str, usage: dict[str, int] | None = None) -> None:
        self.generations = [[type("G", (), {"text": text})()]]
        self.llm_output = {"token_usage": usage or {}}


class _FakeAgentAction:
    def __init__(self, tool: str, tool_input: Any, log: str) -> None:
        self.tool = tool
        self.tool_input = tool_input
        self.log = log


class _FakeAgentFinish:
    def __init__(self, return_values: dict[str, Any], log: str) -> None:
        self.return_values = return_values
        self.log = log


# ---------------------------------------------------------------------------
# Lifecycle — handler doesn't crash before init or after shutdown
# ---------------------------------------------------------------------------


class TestLifecycle:
    def test_callback_before_init_does_not_raise(self) -> None:
        """Handler emission BEFORE init() is a silent no-op."""
        handler = DobbyCallbackHandler()
        # No init() called — collector is None.
        handler.on_chain_start(
            {"name": "TestChain"}, {"input": "hi"}, run_id=uuid4()
        )
        # No assertion — just that it didn't raise.

    def test_callback_after_shutdown_does_not_raise(self) -> None:
        _init_sdk()
        handler = DobbyCallbackHandler()
        dobby_collector.shutdown(timeout_seconds=0.5)
        handler.on_chain_start(
            {"name": "X"}, {}, run_id=uuid4()
        )

    def test_handler_swallows_internal_exceptions(self) -> None:
        """Even if e.g. a malformed event slips in, the customer's agent keeps running."""
        _init_sdk()
        handler = DobbyCallbackHandler()
        # Pass a serialized dict that breaks the `.get('id', [''])[-1]` chain.
        # The handler's `_truncate` etc. should handle weird input gracefully.
        handler.on_chain_start(None, None, run_id=uuid4())  # type: ignore[arg-type]
        # Should not raise.


# ---------------------------------------------------------------------------
# Top-level chain → auto-start_run / end_run
# ---------------------------------------------------------------------------


class TestAutoRun:
    def test_top_level_chain_auto_starts_run(self) -> None:
        _init_sdk()
        handler = DobbyCallbackHandler()
        chain_run = uuid4()

        # Top-level chain — parent_run_id None
        handler.on_chain_start(
            {"name": "RootChain"}, {"q": "hi"}, run_id=chain_run
        )

        events = _drain()
        # Expect run.started (auto) + chain.start
        types = [e["type"] for e in events]
        assert "run.started" in types
        assert "chain.start" in types

    def test_top_level_chain_end_closes_auto_run(self) -> None:
        _init_sdk()
        handler = DobbyCallbackHandler()
        chain_run = uuid4()

        handler.on_chain_start(
            {"name": "RootChain"}, {"q": "hi"}, run_id=chain_run
        )
        handler.on_chain_end({"answer": "hello"}, run_id=chain_run)

        events = _drain()
        types = [e["type"] for e in events]
        assert "run.completed" in types
        assert "chain.end" in types

    def test_chain_error_closes_run_as_failed(self) -> None:
        _init_sdk()
        handler = DobbyCallbackHandler()
        chain_run = uuid4()

        handler.on_chain_start(
            {"name": "RootChain"}, {}, run_id=chain_run
        )
        handler.on_chain_error(ValueError("boom"), run_id=chain_run)

        events = _drain()
        types = [e["type"] for e in events]
        assert "run.failed" in types

    def test_auto_run_disabled_does_not_auto_start(self) -> None:
        _init_sdk()
        handler = DobbyCallbackHandler(auto_run=False)
        chain_run = uuid4()

        handler.on_chain_start(
            {"name": "RootChain"}, {"q": "hi"}, run_id=chain_run
        )

        events = _drain()
        types = [e["type"] for e in events]
        # Only chain.start — no auto run.started
        assert "run.started" not in types
        assert "chain.start" in types

    def test_nested_chain_does_not_auto_start(self) -> None:
        """A nested chain (parent_run_id set) reuses the parent run, no auto-start."""
        _init_sdk()
        handler = DobbyCallbackHandler()
        outer_run = uuid4()
        inner_run = uuid4()

        handler.on_chain_start({"name": "Outer"}, {}, run_id=outer_run)
        _drain()  # clear outer's events
        handler.on_chain_start(
            {"name": "Inner"}, {}, run_id=inner_run, parent_run_id=outer_run
        )

        events = _drain()
        types = [e["type"] for e in events]
        # Nested chain should NOT trigger a second auto-start_run.
        assert "run.started" not in types
        assert "chain.start" in types


# ---------------------------------------------------------------------------
# LLM callbacks
# ---------------------------------------------------------------------------


class TestLLM:
    def test_on_llm_start_emits_llm_start_with_model(self) -> None:
        _init_sdk()
        handler = DobbyCallbackHandler()
        handler.on_llm_start(
            {"name": "OpenAI"},
            ["Hello?"],
            run_id=uuid4(),
            invocation_params={"model": "gpt-4o-mini", "temperature": 0.7, "max_tokens": 100},
        )

        events = _drain()
        llm_starts = [e for e in events if e["type"] == LLM_START]
        assert len(llm_starts) == 1
        ev = llm_starts[0]
        assert ev["data"]["model"] == "gpt-4o-mini"
        assert ev["data"]["prompt"] == "Hello?"
        assert ev["data"]["params"]["temperature"] == 0.7
        assert ev["data"]["params"]["max_tokens"] == 100

    def test_on_chat_model_start_routes_through_same_path(self) -> None:
        _init_sdk()
        handler = DobbyCallbackHandler()
        handler.on_chat_model_start(
            {"name": "ChatOpenAI"},
            [["system: hi", "user: hello"]],
            run_id=uuid4(),
            invocation_params={"model_name": "gpt-4o"},
        )

        events = _drain()
        starts = [e for e in events if e["type"] == LLM_START]
        assert len(starts) == 1
        assert starts[0]["data"]["model"] == "gpt-4o"
        assert "hi" in starts[0]["data"]["prompt"]
        assert "hello" in starts[0]["data"]["prompt"]

    def test_on_llm_end_extracts_completion_and_tokens(self) -> None:
        _init_sdk()
        handler = DobbyCallbackHandler()
        run = uuid4()
        handler.on_llm_start(
            {"name": "OpenAI"},
            ["Hi"],
            run_id=run,
            invocation_params={"model": "gpt-4o-mini"},
        )
        _drain()
        handler.on_llm_end(
            _FakeLLMResult(
                "Hello!",
                usage={"prompt_tokens": 5, "completion_tokens": 2},
            ),
            run_id=run,
        )

        events = _drain()
        ends = [e for e in events if e["type"] == LLM_COMPLETION]
        assert len(ends) == 1
        ev = ends[0]
        assert ev["data"]["completion"] == "Hello!"
        assert ev["data"]["prompt_tokens"] == 5
        assert ev["data"]["completion_tokens"] == 2
        assert ev["status"] == "success"

    def test_on_llm_error_marks_completion_as_error(self) -> None:
        _init_sdk()
        handler = DobbyCallbackHandler()
        run = uuid4()
        handler.on_llm_start(
            {"name": "OpenAI"},
            ["x"],
            run_id=run,
            invocation_params={"model": "gpt-4o"},
        )
        _drain()
        handler.on_llm_error(RuntimeError("rate limited"), run_id=run)

        events = _drain()
        ends = [e for e in events if e["type"] == LLM_COMPLETION]
        assert len(ends) == 1
        assert ends[0]["status"] == "error"
        assert "rate limited" in ends[0]["data"]["error"]


# ---------------------------------------------------------------------------
# Tool callbacks
# ---------------------------------------------------------------------------


class TestTool:
    def test_on_tool_start_emits_with_name_and_args(self) -> None:
        _init_sdk()
        handler = DobbyCallbackHandler()
        handler.on_tool_start(
            {"name": "calculator"},
            "100 * 5",
            run_id=uuid4(),
            inputs={"expression": "100*5"},
        )

        events = _drain()
        starts = [e for e in events if e["type"] == TOOL_START]
        assert len(starts) == 1
        ev = starts[0]
        assert ev["data"]["tool_name"] == "calculator"
        assert ev["name"] == "calculator"
        # inputs (dict) preferred over input_str when both available
        assert ev["data"]["args"] == {"expression": "100*5"}

    def test_on_tool_end_pairs_via_parent_event_id(self) -> None:
        _init_sdk()
        handler = DobbyCallbackHandler()
        run = uuid4()
        handler.on_tool_start(
            {"name": "calculator"},
            "100 * 5",
            run_id=run,
            inputs={"expression": "100*5"},
        )
        start_events = _drain()
        start_event_id = start_events[0]["event_id"]
        handler.on_tool_end("500", run_id=run)

        events = _drain()
        ends = [e for e in events if e["type"] == TOOL_END]
        assert len(ends) == 1
        ev = ends[0]
        assert ev["data"]["output"] == "500"
        assert ev["status"] == "success"
        # The end event should reference the start via parent_event_id
        assert ev["parent_event_id"] == start_event_id

    def test_on_tool_error_emits_end_with_status_error(self) -> None:
        _init_sdk()
        handler = DobbyCallbackHandler()
        run = uuid4()
        handler.on_tool_start({"name": "x"}, "", run_id=run)
        _drain()
        handler.on_tool_error(KeyError("missing"), run_id=run)

        events = _drain()
        ends = [e for e in events if e["type"] == TOOL_END]
        assert len(ends) == 1
        assert ends[0]["status"] == "error"
        assert "missing" in ends[0]["data"]["error"]


# ---------------------------------------------------------------------------
# Agent reasoning
# ---------------------------------------------------------------------------


class TestAgentSteps:
    def test_on_agent_action_emits_step_with_thought(self) -> None:
        _init_sdk()
        handler = DobbyCallbackHandler()
        handler.on_agent_action(
            _FakeAgentAction(
                tool="search",
                tool_input={"query": "weather Tel Aviv"},
                log="Thought: I should look up the weather.",
            ),
            run_id=uuid4(),
        )

        events = _drain()
        steps = [e for e in events if e["type"] == AGENT_STEP]
        assert len(steps) == 1
        ev = steps[0]
        assert ev["name"] == "search"
        assert "Thought" in ev["data"]["thought"]
        assert ev["data"]["action"] == "search"
        assert ev["data"]["action_input"]["query"] == "weather Tel Aviv"

    def test_on_agent_finish_emits_step_with_observation(self) -> None:
        _init_sdk()
        handler = DobbyCallbackHandler()
        handler.on_agent_finish(
            _FakeAgentFinish(
                return_values={"output": "It's sunny."},
                log="Final Answer: It's sunny.",
            ),
            run_id=uuid4(),
        )

        events = _drain()
        steps = [e for e in events if e["type"] == AGENT_STEP]
        assert len(steps) == 1
        ev = steps[0]
        assert ev["name"] == "agent_finish"
        assert "sunny" in str(ev["data"]["observation"])
        assert ev["status"] == "success"


# ---------------------------------------------------------------------------
# Parent-event propagation
# ---------------------------------------------------------------------------


class TestParentPropagation:
    def test_nested_call_inherits_parent_event_id(self) -> None:
        """A tool call inside a chain inside a chain should chain parent_event_ids."""
        _init_sdk()
        handler = DobbyCallbackHandler()
        outer_run = uuid4()
        inner_run = uuid4()
        tool_run = uuid4()

        handler.on_chain_start({"name": "Outer"}, {}, run_id=outer_run)
        outer_events = _drain()
        outer_start_id = outer_events[1]["event_id"]  # [0] = run.started, [1] = chain.start

        handler.on_chain_start(
            {"name": "Inner"}, {}, run_id=inner_run, parent_run_id=outer_run
        )
        inner_events = _drain()
        inner_start = next(e for e in inner_events if e["type"] == CHAIN_START)
        assert inner_start["parent_event_id"] == outer_start_id

        handler.on_tool_start(
            {"name": "do"}, "", run_id=tool_run, parent_run_id=inner_run
        )
        tool_events = _drain()
        tool_start = next(e for e in tool_events if e["type"] == TOOL_START)
        assert tool_start["parent_event_id"] == inner_start["event_id"]


# ---------------------------------------------------------------------------
# Truncation
# ---------------------------------------------------------------------------


class TestTruncation:
    def test_huge_prompt_truncated(self) -> None:
        _init_sdk()
        handler = DobbyCallbackHandler(max_payload_chars=100)
        long_prompt = "x" * 5000
        handler.on_llm_start(
            {"name": "OpenAI"},
            [long_prompt],
            run_id=uuid4(),
            invocation_params={"model": "gpt-4o"},
        )

        events = _drain()
        start = next(e for e in events if e["type"] == LLM_START)
        assert len(start["data"]["prompt"]) < 200  # 100 + ellipsis annotation
        assert "truncated" in start["data"]["prompt"]


# ---------------------------------------------------------------------------
# Framework tagging
# ---------------------------------------------------------------------------


class TestFrameworkTag:
    def test_default_framework_is_langchain(self) -> None:
        _init_sdk()
        handler = DobbyCallbackHandler()
        handler.on_chain_start({"name": "x"}, {}, run_id=uuid4())

        events = _drain()
        # Auto-started run + chain.start — both should be tagged
        for ev in events:
            if ev["type"] == "chain.start":
                assert ev["framework"] == "langchain"

    def test_custom_framework_override(self) -> None:
        _init_sdk()
        handler = DobbyCallbackHandler(framework="custom-fork")
        handler.on_chain_start({"name": "x"}, {}, run_id=uuid4())

        events = _drain()
        chain_start = next(e for e in events if e["type"] == "chain.start")
        assert chain_start["framework"] == "custom-fork"
