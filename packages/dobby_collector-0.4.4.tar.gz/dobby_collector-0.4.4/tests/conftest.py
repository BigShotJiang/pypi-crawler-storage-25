"""
Test fixtures shared across the suite.

Critical invariant: every test must leave the SDK singleton uninitialized
when it finishes. The module-level state in `_config.py` is process-global,
so a leaked instance from one test would affect the next. The `_reset_sdk`
autouse fixture handles this.
"""

import pytest

import dobby_collector
from dobby_collector import _config


@pytest.fixture(autouse=True)
def _reset_sdk():
    """Force-reset the SDK singleton before AND after every test."""
    if _config._collector is not None:
        try:
            dobby_collector.shutdown(timeout_seconds=0.5)
        except Exception:
            _config._collector = None
    yield
    if _config._collector is not None:
        try:
            dobby_collector.shutdown(timeout_seconds=0.5)
        except Exception:
            _config._collector = None
