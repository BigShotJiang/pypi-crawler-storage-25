"""
Regression tests — lock in the bug-class fixes that shipped across v0.4.1
(CrewAI), v0.4.2 (LangChain), v0.4.3 (AutoGen + OpenAI Assistants).

Two specific footguns are tested for ALL 4 framework handlers:

1. **`_truncate()` must coerce non-(None/str/list/dict) values.** Pydantic
   v2 models (CrewAI's TaskOutput, LangChain's HumanMessage / AIMessage,
   AutoGen / OpenAI's various event payloads) crash `json.dumps` in the
   sender thread if returned as-is. Pre-fix behavior: every batch
   silently dropped → 0 workload_runs rows on prod despite agent
   completing successfully. Fix recipe: try `model_dump()` first, fall
   back to `str(value)`.

2. **`LLM_END` constant must equal `"llm.completion"`.** The server-side
   normalizer at `web/shared/lib/connectors/dobby-sdk/normalize.ts`
   pairs `llm.start` ↔ `llm.completion` by `parent_event_id`. A
   handler that emits `llm.end` (the wrong constant) produces a BQ row
   with `llm_calls=0` even when LLM calls actually fired. Same pattern
   as the canonical `_events.LLM_COMPLETION` constant.

These two test classes together guarantee no future handler ships with
either bug — the test file is one of the cheapest regression nets in
the SDK.

If a NEW framework handler is added (e.g. `integrations.adk` for Google
Agent Development Kit), add it to both PARAMETRIZE lists below.
"""

from __future__ import annotations

import json
from typing import Any

import pytest

from dobby_collector._events import LLM_COMPLETION

# Import the handler modules lazily inside fixtures so the unrelated
# framework deps don't have to be installed for every test run.
# (Each handler module imports its framework — crewai / langchain / etc.
# — at module load. We only import the ones we need per test.)


HANDLER_MODULES = [
    "dobby_collector.integrations.crewai",
    "dobby_collector.integrations.langchain",
    "dobby_collector.integrations.autogen",
    "dobby_collector.integrations.openai_assistants",
]


def _import_module(name: str):
    """Import a handler module, skip the test if its framework dep isn't installed."""
    try:
        import importlib

        return importlib.import_module(name)
    except ImportError as e:
        pytest.skip(f"{name} not installed: {e}")


# ──────────────────────────────────────────────────────────────────────
# Bug class #1: _truncate must coerce non-(None/str/list/dict) values
# ──────────────────────────────────────────────────────────────────────


class _PydanticV2Like:
    """Stand-in for a Pydantic v2 model — has `.model_dump()` returning a dict."""

    def __init__(self, payload: dict[str, Any]) -> None:
        self._payload = payload

    def model_dump(self) -> dict[str, Any]:
        return self._payload


class _PlainObject:
    """Stand-in for any other non-(None/str/list/dict) object — has `__str__`."""

    def __str__(self) -> str:
        return "plain_object_repr"


@pytest.mark.parametrize("module_name", HANDLER_MODULES)
class TestTruncateCoercesNonSerializable:
    """Verifies the _truncate fix-class shipped in v0.4.1+ across all 4 handlers."""

    def test_pydantic_v2_object_serialised_via_model_dump(self, module_name: str) -> None:
        """A Pydantic v2 model must be converted to its dict via `.model_dump()`."""
        mod = _import_module(module_name)
        result = mod._truncate(_PydanticV2Like({"role": "user", "content": "hi"}))
        assert isinstance(result, dict), (
            f"{module_name}._truncate(PydanticV2) returned {type(result).__name__} "
            f"instead of dict — silently drops payloads in the sender thread"
        )
        assert result == {"role": "user", "content": "hi"}

    def test_plain_object_falls_back_to_str(self, module_name: str) -> None:
        """Any other non-(None/str/list/dict) object must coerce to string."""
        mod = _import_module(module_name)
        result = mod._truncate(_PlainObject())
        assert isinstance(result, str), (
            f"{module_name}._truncate(PlainObject) returned {type(result).__name__} "
            f"instead of str — would crash json.dumps in the sender thread"
        )
        assert result == "plain_object_repr"

    def test_str_passes_through_unchanged_short(self, module_name: str) -> None:
        """The original truncation behavior must still work for short strings."""
        mod = _import_module(module_name)
        assert mod._truncate("hello") == "hello"

    def test_none_passes_through(self, module_name: str) -> None:
        """None must remain None (not coerced to the literal string 'None')."""
        mod = _import_module(module_name)
        assert mod._truncate(None) is None

    def test_dict_recursively_handles_pydantic_values(self, module_name: str) -> None:
        """A dict containing a Pydantic value must recursively coerce."""
        mod = _import_module(module_name)
        result = mod._truncate({"msg": _PydanticV2Like({"text": "x"}), "ok": True})
        assert isinstance(result, dict)
        assert result["msg"] == {"text": "x"}
        assert result["ok"] is True

    def test_list_recursively_handles_pydantic_values(self, module_name: str) -> None:
        """A list containing Pydantic values must recursively coerce."""
        mod = _import_module(module_name)
        result = mod._truncate([_PydanticV2Like({"a": 1}), "x", None])
        assert result == [{"a": 1}, "x", None]

    def test_full_event_data_is_json_serializable_after_truncate(
        self, module_name: str
    ) -> None:
        """
        End-to-end safety net: anything _truncate returns MUST survive
        json.dumps. The original bug was that the sender called json.dumps
        on a buffer of events with non-serializable payloads, which crashed
        the whole batch.
        """
        mod = _import_module(module_name)
        weird_inputs = [
            _PydanticV2Like({"k": "v"}),
            _PlainObject(),
            {"nested": [_PydanticV2Like({"x": 1}), _PlainObject()]},
            ["a", _PydanticV2Like({"y": 2})],
        ]
        for raw in weird_inputs:
            coerced = mod._truncate(raw)
            # This MUST not raise — that's the whole regression
            json.dumps(coerced)


# ──────────────────────────────────────────────────────────────────────
# Bug class #2: LLM_END constant must equal _events.LLM_COMPLETION
# ──────────────────────────────────────────────────────────────────────


# Handlers that DEFINE an LLM_END constant (some use the canonical
# `_events.LLM_COMPLETION` import directly and don't redefine).
HANDLERS_WITH_LLM_END = [
    "dobby_collector.integrations.crewai",
    "dobby_collector.integrations.autogen",
    "dobby_collector.integrations.openai_assistants",
]


@pytest.mark.parametrize("module_name", HANDLERS_WITH_LLM_END)
class TestLLMEndMatchesNormalizerExpectation:
    """
    Verifies the LLM_END alignment fix-class shipped in v0.4.1 (CrewAI) +
    v0.4.3 (AutoGen, OpenAI Assistants).

    The server normalizer at web/shared/lib/connectors/dobby-sdk/normalize.ts
    pairs `llm.start` ↔ `llm.completion`. Any handler that emits `llm.end`
    silently produces `llm_calls=0` in BQ even on successful runs.
    """

    def test_llm_end_equals_canonical_completion(self, module_name: str) -> None:
        """LLM_END MUST be 'llm.completion' to pair with server normalizer."""
        mod = _import_module(module_name)
        assert mod.LLM_END == "llm.completion", (
            f"{module_name}.LLM_END = {mod.LLM_END!r}, expected 'llm.completion'. "
            f"Server normalizer at web/shared/lib/connectors/dobby-sdk/normalize.ts "
            f"pairs llm.start ↔ llm.completion — any other value causes llm_calls=0 "
            f"in workload_runs.metadata_json."
        )

    def test_llm_end_matches_events_canonical_constant(self, module_name: str) -> None:
        """LLM_END MUST match the canonical _events.LLM_COMPLETION export."""
        mod = _import_module(module_name)
        assert mod.LLM_END == LLM_COMPLETION


def test_langchain_handler_imports_canonical_constants() -> None:
    """
    LangChain handler doesn't define a local LLM_END — it imports
    LLM_COMPLETION directly from _events. Verify it's wired correctly.
    """
    try:
        import dobby_collector.integrations.langchain as lc
    except ImportError as e:
        pytest.skip(f"langchain integration not installed: {e}")

    assert lc.LLM_COMPLETION == "llm.completion"
