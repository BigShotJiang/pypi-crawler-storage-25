"""
Tests for DobbyAssistantsHandler — OpenAI Assistants auto-instrumentation.

Tests call handler methods directly with stub run_step / tool_call /
message objects (SimpleNamespace), mirroring how the OpenAI SDK invokes
the AssistantEventHandler subclass during a streamed run.

Skipped automatically if openai isn't installed.
"""
from __future__ import annotations

import os
from types import SimpleNamespace
from typing import Any

import pytest

openai_installed = True
try:
    # OpenAI SDK requires OPENAI_API_KEY env var on import in some versions —
    # set a dummy so test collection doesn't blow up.
    os.environ.setdefault("OPENAI_API_KEY", "sk-dummy-test-only")
    import openai  # noqa: F401
except ImportError:
    openai_installed = False

pytestmark = pytest.mark.skipif(
    not openai_installed, reason="openai not installed (optional integration dep)"
)


@pytest.fixture
def captured_events(monkeypatch):
    captured = []

    def fake_emit(event):
        captured.append(event)

    import dobby_collector.integrations.openai_assistants as oa_mod

    monkeypatch.setattr(oa_mod, "_emit", fake_emit)
    return captured


@pytest.fixture
def handler(captured_events):
    from dobby_collector.integrations.openai_assistants import DobbyAssistantsHandler

    return DobbyAssistantsHandler()


def _stub(**fields: Any) -> Any:
    """Build a SimpleNamespace stub with arbitrary attrs."""
    return SimpleNamespace(**fields)


# ---------------------------------------------------------------------------
# run_step lifecycle (span.started → span.completed pairing)
# ---------------------------------------------------------------------------


class TestRunStep:
    def test_created_emits_span_started_with_step_metadata(
        self, handler, captured_events
    ):
        step = _stub(
            id="step_abc",
            type="tool_calls",
            thread_id="thread_xyz",
            run_id="run_123",
        )
        handler.on_run_step_created(step)

        assert len(captured_events) == 1
        e = captured_events[0]
        assert e.type == "span.started"
        assert e.name == "run_step:tool_calls"
        assert e.framework == "openai_assistants"
        assert e.data["step_id"] == "step_abc"
        assert e.data["step_type"] == "tool_calls"
        assert e.data["thread_id"] == "thread_xyz"

    def test_done_pairs_via_parent_event_id_with_duration(
        self, handler, captured_events
    ):
        step = _stub(id="step_abc", type="message_creation", status="completed",
                     thread_id="t", run_id="r", usage=None)
        handler.on_run_step_created(step)
        start_event_id = captured_events[0].event_id

        done_step = _stub(
            id="step_abc",
            type="message_creation",
            status="completed",
            usage=_stub(prompt_tokens=10, completion_tokens=5),
        )
        handler.on_run_step_done(done_step)

        assert len(captured_events) == 2
        done_event = captured_events[1]
        assert done_event.type == "span.completed"
        assert done_event.status == "success"
        assert done_event.duration_ms is not None
        assert done_event.parent_event_id == start_event_id

    def test_failed_status_routes_to_span_failed(self, handler, captured_events):
        step = _stub(id="step_x", type="tool_calls", status="completed",
                     thread_id="t", run_id="r", usage=None)
        handler.on_run_step_created(step)
        failed = _stub(id="step_x", type="tool_calls", status="failed", usage=None)
        handler.on_run_step_done(failed)

        assert captured_events[1].type == "span.failed"
        assert captured_events[1].status == "error"


# ---------------------------------------------------------------------------
# Tool calls
# ---------------------------------------------------------------------------


class TestToolCall:
    def test_function_tool_created_emits_tool_start_with_function_name(
        self, handler, captured_events
    ):
        tc = _stub(
            id="tc_1",
            type="function",
            function=_stub(name="search_db", arguments='{"q":"AI"}'),
        )
        handler.on_tool_call_created(tc)

        e = captured_events[0]
        assert e.type == "tool.start"
        assert e.name == "search_db"
        assert e.data["tool_id"] == "tc_1"
        assert e.data["tool_type"] == "function"
        assert e.data["tool_name"] == "search_db"

    def test_function_tool_done_pairs_with_start_and_captures_output(
        self, handler, captured_events
    ):
        created = _stub(
            id="tc_1",
            type="function",
            function=_stub(name="search_db", arguments='{"q":"AI"}'),
        )
        handler.on_tool_call_created(created)
        start_event_id = captured_events[0].event_id

        done = _stub(
            id="tc_1",
            type="function",
            function=_stub(
                name="search_db",
                arguments='{"q":"AI"}',
                output='{"results": 5}',
            ),
        )
        handler.on_tool_call_done(done)

        done_event = captured_events[1]
        assert done_event.type == "tool.end"
        assert done_event.status == "success"
        assert done_event.name == "search_db"
        assert done_event.data["arguments"] == '{"q":"AI"}'
        assert done_event.parent_event_id == start_event_id

    def test_code_interpreter_tool_done_captures_input_output(
        self, handler, captured_events
    ):
        created = _stub(
            id="tc_2", type="code_interpreter", code_interpreter=_stub(input="x=1"),
        )
        handler.on_tool_call_created(created)
        done = _stub(
            id="tc_2",
            type="code_interpreter",
            code_interpreter=_stub(input="x=1", outputs=[{"type": "logs"}]),
        )
        handler.on_tool_call_done(done)

        done_event = captured_events[1]
        assert done_event.type == "tool.end"
        assert done_event.name == "code_interpreter"
        assert done_event.data["arguments"] == "x=1"


# ---------------------------------------------------------------------------
# Messages
# ---------------------------------------------------------------------------


class TestMessage:
    def test_created_emits_agent_message(self, handler, captured_events):
        msg = _stub(id="msg_1", role="assistant", thread_id="t1")
        handler.on_message_created(msg)

        e = captured_events[0]
        assert e.type == "agent.message"
        assert e.name == "message_created"
        assert e.data["message_id"] == "msg_1"
        assert e.data["role"] == "assistant"

    def test_done_extracts_text_value_from_content_blocks(
        self, handler, captured_events
    ):
        text_block = _stub(text=_stub(value="Hello world"))
        msg = _stub(id="msg_1", role="assistant", content=[text_block])
        handler.on_message_done(msg)

        e = captured_events[0]
        assert e.type == "agent.message"
        assert e.name == "message_done"
        assert e.status == "success"
        assert e.data["text"] == "Hello world"


# ---------------------------------------------------------------------------
# Exception + timeout
# ---------------------------------------------------------------------------


class TestErrorPaths:
    def test_on_exception_emits_span_failed(self, handler, captured_events):
        handler.on_exception(RuntimeError("boom"))

        e = captured_events[0]
        assert e.type == "span.failed"
        assert e.status == "error"
        assert "boom" in e.data["error"]

    def test_on_timeout_emits_span_failed_with_timeout_marker(
        self, handler, captured_events
    ):
        handler.on_timeout()

        e = captured_events[0]
        assert e.type == "span.failed"
        assert e.data["error"] == "openai_assistants_run_timeout"


# ---------------------------------------------------------------------------
# Error swallowing — handler MUST never raise into customer code
# ---------------------------------------------------------------------------


class TestErrorSwallowing:
    def test_emit_errors_are_swallowed(self, handler, monkeypatch):
        import dobby_collector.integrations.openai_assistants as oa_mod

        def raising_emit(event):
            raise RuntimeError("buffer full")

        monkeypatch.setattr(oa_mod, "_emit", raising_emit)
        step = _stub(id="s", type="tool_calls", thread_id="t", run_id="r")

        # Must NOT raise
        handler.on_run_step_created(step)
        handler.on_run_step_done(step)
        handler.on_message_created(_stub(id="m", role="assistant", thread_id="t"))
        handler.on_tool_call_created(_stub(id="tc", type="function", function=_stub(name="x", arguments="")))
        handler.on_tool_call_done(_stub(id="tc", type="function", function=_stub(name="x", arguments="", output="y")))
        handler.on_exception(Exception("x"))
        handler.on_timeout()

    def test_handler_handles_attr_access_errors(self, handler, captured_events):
        """If a SimpleNamespace stub is missing attrs, handler shouldn't crash."""
        # Step with minimal attrs (no thread_id, no run_id)
        step = _stub(id="s", type="x")
        handler.on_run_step_created(step)
        # Should still emit (with None defaults)
        assert len(captured_events) == 1
        assert captured_events[0].data["step_id"] == "s"


# ---------------------------------------------------------------------------
# Inheritance check
# ---------------------------------------------------------------------------


class TestInheritance:
    def test_subclasses_AssistantEventHandler(self, handler):
        from openai import AssistantEventHandler

        assert isinstance(handler, AssistantEventHandler)

    def test_custom_framework_tag_propagates(self, captured_events):
        from dobby_collector.integrations.openai_assistants import DobbyAssistantsHandler

        h = DobbyAssistantsHandler(framework="openai-assistants-prod")
        h.on_exception(Exception("test"))

        assert captured_events[0].framework == "openai-assistants-prod"


# ---------------------------------------------------------------------------
# Payload truncation
# ---------------------------------------------------------------------------


class TestTruncation:
    def test_long_message_text_truncated(self, captured_events):
        from dobby_collector.integrations.openai_assistants import DobbyAssistantsHandler

        h = DobbyAssistantsHandler(max_payload_chars=50)
        text_block = _stub(text=_stub(value="x" * 500))
        msg = _stub(id="m", role="assistant", content=[text_block])
        h.on_message_done(msg)

        text = captured_events[0].data["text"]
        assert text.endswith("...[truncated]")
        assert len(text) <= 50 + len("...[truncated]")
