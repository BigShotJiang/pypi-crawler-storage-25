"""
Public API contracts:
  - init() requires api_key + connector_id (or env vars)
  - init() is idempotent
  - shutdown() drains + un-singletons
  - start_run / end_run emit correct events + manage ambient run_id
  - @track wraps a function and emits start/end events
  - span() context manager emits start + end events
  - Pre-init or post-shutdown emission is a silent no-op (does NOT raise)
  - Decorated functions still raise on failure (instrumentation transparent)
"""


import pytest

import dobby_collector
from dobby_collector import _config
from dobby_collector._events import (
    RUN_COMPLETED,
    RUN_FAILED,
    RUN_STARTED,
    TOOL_END,
    TOOL_START,
)


def _drain_buffer_dicts() -> list[dict]:
    """Read every event the SDK has buffered so far, as dicts."""
    c = _config.get_collector()
    assert c is not None
    events = c.buffer.drain(max_count=10_000)
    return [e.to_dict() for e in events]


def _init_with_mock_transport() -> None:
    """init() but pin the sender's HTTP client to a no-op transport so nothing leaves the process."""
    # We can't easily inject the http client through `init()`, so init normally
    # then replace the sender's client. Most tests don't actually need the
    # sender to fire — they just check buffer contents.
    dobby_collector.init(
        api_key="gk_test_abc",
        connector_id="wc_test",
        # 60s flush interval — events stay in buffer for our assertions
        flush_interval_seconds=60.0,
    )


# ---------------------------------------------------------------------------
# init / shutdown
# ---------------------------------------------------------------------------


class TestInit:
    def test_init_requires_api_key(self) -> None:
        with pytest.raises(ValueError, match="api_key is required"):
            dobby_collector.init(connector_id="wc_x")

    def test_init_requires_connector_id(self) -> None:
        with pytest.raises(ValueError, match="connector_id is required"):
            dobby_collector.init(api_key="gk_x")

    def test_init_reads_env_var_fallbacks(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("DOBBY_API_KEY", "gk_env_key")
        monkeypatch.setenv("DOBBY_CONNECTOR_ID", "wc_env_id")
        c = dobby_collector.init(flush_interval_seconds=60.0)
        assert c.api_key == "gk_env_key"
        assert c.connector_id == "wc_env_id"

    def test_init_args_override_env_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("DOBBY_API_KEY", "from_env")
        c = dobby_collector.init(
            api_key="from_arg", connector_id="wc_x", flush_interval_seconds=60.0
        )
        assert c.api_key == "from_arg"

    def test_init_is_idempotent(self) -> None:
        c1 = dobby_collector.init(
            api_key="k", connector_id="c", flush_interval_seconds=60.0
        )
        c2 = dobby_collector.init(
            api_key="different", connector_id="different", flush_interval_seconds=60.0
        )
        # Same instance returned; new creds IGNORED until shutdown + re-init
        assert c1 is c2
        assert c2.api_key == "k"

    def test_shutdown_un_singletons(self) -> None:
        dobby_collector.init(
            api_key="k", connector_id="c", flush_interval_seconds=60.0
        )
        assert _config.get_collector() is not None
        dobby_collector.shutdown(timeout_seconds=0.5)
        assert _config.get_collector() is None

    def test_shutdown_when_not_initialized_is_noop(self) -> None:
        # Must not raise
        dobby_collector.shutdown(timeout_seconds=0.5)


# ---------------------------------------------------------------------------
# start_run / end_run
# ---------------------------------------------------------------------------


class TestRunBoundaries:
    def test_start_run_emits_run_started(self) -> None:
        _init_with_mock_transport()
        run = dobby_collector.start_run(name="my_agent", inputs={"q": "hello"})

        events = _drain_buffer_dicts()
        assert len(events) == 1
        assert events[0]["type"] == RUN_STARTED
        assert events[0]["name"] == "my_agent"
        assert events[0]["run_id"] == run.run_id
        assert events[0]["data"]["agent_name"] == "my_agent"
        assert events[0]["data"]["inputs"] == {"q": "hello"}

    def test_end_run_emits_run_completed(self) -> None:
        _init_with_mock_transport()
        run = dobby_collector.start_run(name="my_agent", inputs={"q": "hello"})
        dobby_collector.end_run(run, outputs={"answer": "42"}, status="success")

        events = _drain_buffer_dicts()
        assert len(events) == 2
        assert events[1]["type"] == RUN_COMPLETED
        assert events[1]["status"] == "success"
        assert events[1]["data"]["outputs"] == {"answer": "42"}
        # duration_ms must be populated (a positive number)
        assert events[1]["duration_ms"] > 0

    def test_end_run_failed_emits_run_failed(self) -> None:
        _init_with_mock_transport()
        run = dobby_collector.start_run(name="x")
        dobby_collector.end_run(run, status="error", error="oops")

        events = _drain_buffer_dicts()
        assert events[1]["type"] == RUN_FAILED
        assert events[1]["data"]["error"] == "oops"

    def test_start_run_sets_ambient_run_id(self) -> None:
        _init_with_mock_transport()
        run = dobby_collector.start_run(name="x")
        c = _config.get_collector()
        assert c is not None
        assert c.get_current_run() == run.run_id

    def test_end_run_clears_ambient_run_id(self) -> None:
        _init_with_mock_transport()
        run = dobby_collector.start_run(name="x")
        dobby_collector.end_run(run, outputs={}, status="success")
        c = _config.get_collector()
        assert c is not None
        assert c.get_current_run() is None


# ---------------------------------------------------------------------------
# span() context manager
# ---------------------------------------------------------------------------


class TestSpan:
    def test_span_emits_start_and_end(self) -> None:
        _init_with_mock_transport()
        run = dobby_collector.start_run(name="agent")
        with dobby_collector.span("retrieve", kind="tool", inputs={"q": "x"}):
            pass
        dobby_collector.end_run(run, outputs={}, status="success")

        events = _drain_buffer_dicts()
        # Events: run.started, tool.start, tool.end, run.completed
        types = [e["type"] for e in events]
        assert types == [RUN_STARTED, TOOL_START, TOOL_END, RUN_COMPLETED]

        # The end event should reference the start via parent_event_id
        tool_start = events[1]
        tool_end = events[2]
        assert tool_end["parent_event_id"] == tool_start["event_id"]
        assert tool_end["duration_ms"] >= 0

    def test_span_records_error_on_exception_and_reraises(self) -> None:
        _init_with_mock_transport()
        dobby_collector.start_run(name="agent")
        with pytest.raises(RuntimeError, match="boom"), dobby_collector.span(
            "broken_tool", kind="tool"
        ):
            raise RuntimeError("boom")

        events = _drain_buffer_dicts()
        # The end event status must be 'error', and `data.error` must hold the repr
        end_ev = events[-1]
        assert end_ev["type"] == TOOL_END
        assert end_ev["status"] == "error"
        assert "boom" in end_ev["data"]["error"]

    def test_span_inherits_ambient_run_id(self) -> None:
        _init_with_mock_transport()
        run = dobby_collector.start_run(name="agent")
        with dobby_collector.span("sub"):
            pass

        events = _drain_buffer_dicts()
        for e in events:
            assert e["run_id"] == run.run_id

    def test_span_without_run_uses_fresh_run_id(self) -> None:
        """Calling span() before start_run() shouldn't crash — assign a fresh run_id."""
        _init_with_mock_transport()
        with dobby_collector.span("orphan_span"):
            pass

        events = _drain_buffer_dicts()
        assert len(events) == 2
        # Both events share the same auto-minted run_id
        assert events[0]["run_id"] == events[1]["run_id"]


# ---------------------------------------------------------------------------
# @track decorator
# ---------------------------------------------------------------------------


class TestTrackDecorator:
    def test_track_emits_start_and_end_on_success(self) -> None:
        _init_with_mock_transport()
        dobby_collector.start_run(name="agent")

        @dobby_collector.track(name="search_db", kind="tool")
        def search_db(q: str) -> list[str]:
            return [f"hit:{q}"]

        result = search_db("ai startups")
        assert result == ["hit:ai startups"]

        events = _drain_buffer_dicts()
        # run.started + tool.start + tool.end
        assert events[1]["type"] == TOOL_START
        assert events[1]["data"]["tool_name"] == "search_db"
        assert events[2]["type"] == TOOL_END
        assert events[2]["status"] == "success"
        assert events[2]["data"]["output"] == ["hit:ai startups"]

    def test_track_reraises_exception(self) -> None:
        _init_with_mock_transport()
        dobby_collector.start_run(name="agent")

        @dobby_collector.track(name="broken")
        def broken() -> None:
            raise ValueError("nope")

        with pytest.raises(ValueError, match="nope"):
            broken()

        events = _drain_buffer_dicts()
        # End event must be 'error' status with the exception repr
        end_ev = events[-1]
        assert end_ev["status"] == "error"
        assert "nope" in end_ev["data"]["error"]

    def test_track_preserves_function_metadata(self) -> None:
        @dobby_collector.track(name="t")
        def documented(x: int) -> int:
            """Doc string."""
            return x * 2

        assert documented.__name__ == "documented"
        assert documented.__doc__ == "Doc string."

    def test_track_name_defaults_to_function_name(self) -> None:
        _init_with_mock_transport()
        dobby_collector.start_run(name="agent")

        @dobby_collector.track()
        def my_func() -> str:
            return "ok"

        my_func()
        events = _drain_buffer_dicts()
        assert events[1]["name"] == "my_func"

    def test_capture_args_false_omits_inputs(self) -> None:
        _init_with_mock_transport()
        dobby_collector.start_run(name="agent")

        @dobby_collector.track(name="quiet", capture_args=False)
        def quiet(secret: str) -> str:
            return "ok"

        quiet("supersecret")
        events = _drain_buffer_dicts()
        # The tool.start event should NOT contain `inputs`
        start_ev = events[1]
        assert "inputs" not in (start_ev.get("data") or {})

    def test_capture_return_false_omits_output(self) -> None:
        _init_with_mock_transport()
        dobby_collector.start_run(name="agent")

        @dobby_collector.track(name="quiet_ret", capture_return=False)
        def f() -> str:
            return "secret_output"

        f()
        events = _drain_buffer_dicts()
        end_ev = events[2]
        assert "output" not in (end_ev.get("data") or {})


# ---------------------------------------------------------------------------
# Pre-init / post-shutdown safety
# ---------------------------------------------------------------------------


class TestSafetyNets:
    def test_track_decorator_works_before_init_no_crash(self) -> None:
        """Customer might decorate at module-import time, BEFORE init(). Must not raise."""

        @dobby_collector.track(name="early")
        def f() -> int:
            return 42

        # Calling the function before init() also must not raise
        assert f() == 42

    def test_span_before_init_no_crash(self) -> None:
        with dobby_collector.span("orphan"):
            pass
        # No assertion needed — just must not raise

    def test_start_run_before_init_no_crash(self) -> None:
        run = dobby_collector.start_run(name="orphan")
        dobby_collector.end_run(run, outputs={}, status="success")
        # Must not raise

    def test_emission_after_shutdown_no_crash(self) -> None:
        _init_with_mock_transport()
        dobby_collector.shutdown(timeout_seconds=0.5)

        # Now post-shutdown emissions should silently no-op
        run = dobby_collector.start_run(name="zombie")
        dobby_collector.end_run(run, outputs={}, status="success")
        # Must not raise
