"""
In-memory ring buffer for SDK events
=====================================

Bounded `collections.deque` — drops oldest events when full. Telemetry must
NEVER block the customer's agent — failure mode is "lose oldest events" not
"raise + crash the agent".

Phase 2a: drops silently. Phase 2b will emit an `sdk.dropped` synthetic event
in the next batch so the server can record the gap.

Thread-safe: deque's append/popleft/drain are atomic under the GIL. The
public API methods are non-blocking — append is O(1).
"""

from __future__ import annotations

import threading
from collections import deque

from ._events import SdkEvent


class EventBuffer:
    """Bounded ring buffer with a flush event for the sender thread."""

    def __init__(self, max_events: int = 10_000) -> None:
        if max_events <= 0:
            raise ValueError(f"max_events must be > 0, got {max_events}")
        self._max_events = max_events
        self._dropped_count = 0
        # `deque(maxlen=N)` silently pops the oldest item when appending past N.
        self._events: deque[SdkEvent] = deque(maxlen=max_events)
        # Used by the sender thread to wake up early on terminal events.
        self._flush_now = threading.Event()
        self._lock = threading.Lock()

    def append(self, event: SdkEvent) -> None:
        """Append an event. O(1). Drops oldest if buffer is full."""
        with self._lock:
            # If deque is at capacity, the leftmost element is about to be evicted.
            # Track that — we surface the count in Phase 2b.
            if len(self._events) == self._max_events:
                self._dropped_count += 1
            self._events.append(event)

    def drain(self, max_count: int) -> list[SdkEvent]:
        """
        Atomically remove up to `max_count` events from the head and return them.
        Returns an empty list if the buffer is empty.
        """
        with self._lock:
            n = min(max_count, len(self._events))
            if n == 0:
                return []
            taken = [self._events.popleft() for _ in range(n)]
        return taken

    def __len__(self) -> int:
        with self._lock:
            return len(self._events)

    def request_flush(self) -> None:
        """Signal the sender thread to wake up and flush immediately."""
        self._flush_now.set()

    def wait_for_flush_signal(self, timeout: float) -> bool:
        """
        Block up to `timeout` seconds OR until `request_flush()` is called.
        Returns True if flush was requested, False if timed out.
        Auto-clears the signal so the next iteration starts fresh.
        """
        triggered = self._flush_now.wait(timeout=timeout)
        if triggered:
            self._flush_now.clear()
        return triggered

    @property
    def dropped_count(self) -> int:
        """Number of events dropped due to buffer overflow since process start."""
        with self._lock:
            return self._dropped_count

    def reset_dropped_count(self) -> int:
        """Atomically read + clear the dropped counter. For Phase 2b dropped-event emission."""
        with self._lock:
            n = self._dropped_count
            self._dropped_count = 0
        return n
