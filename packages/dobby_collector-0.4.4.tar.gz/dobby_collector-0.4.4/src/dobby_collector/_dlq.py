"""
SQLite-backed Dead-Letter Queue for offline survival
=====================================================

Events live in the in-memory buffer until the sender thread flushes them to
the webhook. If the webhook is unreachable (server down, customer offline,
process restarts before flush), Phase 2a lost those events. Phase 2b
persists them to a local SQLite file so the next process invocation can
drain and retry.

Storage: `~/.dobby-collector/dlq.sqlite` (overridable via `DOBBY_DLQ_PATH`
env var or `init(dlq_path=...)`). One file per process, WAL mode for
crash safety.

Failure modes — telemetry must NEVER block the customer's agent:
  - SQLite file unwritable (permission, disk full) → log warning, drop silently
  - Corrupted file → log + recreate empty
  - Schema mismatch on read → log + recreate empty
  - Path doesn't exist → mkdir parents + retry once

Bounded: `max_rows` (default 1000). When exceeded on enqueue, the oldest
row is evicted first — same drop-oldest semantics as the in-memory buffer.

Thread-safety: the sender thread is the single writer + reader. SQLite WAL
mode handles concurrent processes on the same file safely; we don't rely
on that today (one process per file by convention) but the WAL pragma
costs nothing and protects against future multi-process scenarios.
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, Optional

logger = logging.getLogger("dobby_collector.dlq")

# Schema version — bump if the table structure changes. On mismatch we drop
# the table + recreate (the cost is losing un-sent telemetry, not crashing).
_SCHEMA_VERSION = 1

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS pending_batches (
    batch_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    payload     TEXT NOT NULL,
    created_at  REAL NOT NULL,
    attempts    INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS dlq_meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE INDEX IF NOT EXISTS idx_pending_batches_created
    ON pending_batches(created_at);
"""


def _default_dlq_path() -> Path:
    """`$DOBBY_DLQ_PATH` → arg → `~/.dobby-collector/dlq.sqlite`."""
    env = os.environ.get("DOBBY_DLQ_PATH")
    if env:
        return Path(env).expanduser()
    return Path.home() / ".dobby-collector" / "dlq.sqlite"


class Dlq:
    """
    SQLite-backed pending-batch queue.

    The sender persists a batch HERE only as a last resort — after exhausting
    in-process retries. On the next process startup (or any later flush
    cycle), pending batches are drained FIRST.

    All methods are best-effort: a failure to read/write the DLQ logs a
    warning but never raises into the sender thread. The worst case is "we
    drop the same batch the buffer drops" — telemetry is degraded, not
    broken.

    Args:
        path: SQLite filepath. Pass `None` to disable the DLQ entirely
            (useful for tests + customers who don't want a local file).
        max_rows: Hard cap on persisted batches. When exceeded, oldest
            batches are evicted first. Default 1000.

    Tests should use `tmp_path / "dlq.sqlite"` to isolate per-test files.
    """

    def __init__(
        self,
        *,
        path: Optional[Path] = None,
        max_rows: int = 1000,
    ) -> None:
        # Coerce at the boundary — `init(dlq_path=...)` is a documented public
        # arg and customers naturally pass a plain string. Without this,
        # `self._path.parent` raises AttributeError and the DLQ silently
        # disables itself (offline-survival feature dead for string paths).
        # Path(Path(...)) is idempotent, so Path inputs pass through unchanged.
        self._path: Optional[Path] = Path(path) if path is not None else None
        self._max_rows = max_rows
        self._lock = threading.Lock()
        self._disabled = self._path is None

        if self._disabled:
            return

        try:
            assert self._path is not None
            self._path.parent.mkdir(parents=True, exist_ok=True)
            self._init_db()
        except sqlite3.DatabaseError:
            # File exists but isn't a valid SQLite database (e.g. previous
            # crash mid-write, customer pointed us at a garbage file).
            # Reset + retry once. Worst case: lose the un-readable batches.
            logger.warning(
                "dobby_collector.dlq: existing file at %s is not a valid SQLite DB — resetting",
                self._path,
            )
            self._reset_file()
            try:
                self._init_db()
            except Exception:  # noqa: BLE001
                logger.exception("dobby_collector.dlq: re-init after reset still failed — disabling")
                self._disabled = True
        except Exception:  # noqa: BLE001 — DLQ failure must not crash init
            logger.exception("dobby_collector.dlq: init failed — disabling DLQ")
            self._disabled = True

    @property
    def enabled(self) -> bool:
        return not self._disabled

    @property
    def path(self) -> Optional[Path]:
        return self._path

    @contextmanager
    def _conn(self) -> Iterator[sqlite3.Connection]:
        """
        Open a SQLite connection in WAL mode. ALWAYS closes on exit.

        SQLite gotcha: `with sqlite3.connect(...) as conn` commits/rolls
        back but does NOT close the connection — leaks the underlying
        file descriptor + WAL lock. We always need explicit `.close()`.
        """
        assert self._path is not None
        conn = sqlite3.connect(
            str(self._path),
            timeout=5.0,  # block up to 5s if another connection holds the lock
            isolation_level=None,  # autocommit
        )
        try:
            # WAL mode tolerates concurrent readers + one writer + survives crashes.
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("PRAGMA synchronous=NORMAL;")
            yield conn
        finally:
            with contextlib.suppress(Exception):
                conn.close()

    def _reset_file(self) -> None:
        """Delete the SQLite file + its WAL/SHM siblings. Called on corruption."""
        if self._path is None:
            return
        with contextlib.suppress(Exception):
            self._path.unlink(missing_ok=True)
        # WAL + SHM sidecars
        for suffix in ("-wal", "-shm"):
            with contextlib.suppress(Exception):
                Path(str(self._path) + suffix).unlink(missing_ok=True)

    def _init_db(self) -> None:
        with self._conn() as conn:
            conn.executescript(_SCHEMA_SQL)
            row = conn.execute(
                "SELECT value FROM dlq_meta WHERE key='schema_version'"
            ).fetchone()
            current = int(row[0]) if row else 0
            if current != _SCHEMA_VERSION:
                if current != 0:
                    logger.warning(
                        "dobby_collector.dlq: schema version %d != %d — dropping pending batches",
                        current,
                        _SCHEMA_VERSION,
                    )
                    conn.execute("DELETE FROM pending_batches")
                conn.execute(
                    "INSERT OR REPLACE INTO dlq_meta(key, value) VALUES(?, ?)",
                    ("schema_version", str(_SCHEMA_VERSION)),
                )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def enqueue(self, payload: dict) -> Optional[int]:
        """
        Persist a batch payload. Returns the new batch_id, or None on failure
        (DLQ disabled, file unwritable, corruption — never raises).

        Enforces `max_rows` — oldest rows evicted first when over limit.
        """
        if self._disabled:
            return None
        try:
            serialized = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        except (TypeError, ValueError):
            logger.exception("dobby_collector.dlq: payload not JSON-serializable")
            return None

        try:
            with self._lock, self._conn() as conn:
                cur = conn.execute(
                    "INSERT INTO pending_batches(payload, created_at, attempts) VALUES(?, ?, 0)",
                    (serialized, time.time()),
                )
                batch_id = cur.lastrowid
                # Eviction: oldest-first, keep within bound.
                count_row = conn.execute(
                    "SELECT COUNT(*) FROM pending_batches"
                ).fetchone()
                if count_row[0] > self._max_rows:
                    excess = count_row[0] - self._max_rows
                    conn.execute(
                        """DELETE FROM pending_batches
                           WHERE batch_id IN (
                               SELECT batch_id FROM pending_batches
                               ORDER BY created_at ASC, batch_id ASC
                               LIMIT ?
                           )""",
                        (excess,),
                    )
                return batch_id
        except sqlite3.DatabaseError:
            logger.exception("dobby_collector.dlq: enqueue failed — DB error")
            self._maybe_reset_on_corruption()
            return None
        except Exception:  # noqa: BLE001
            logger.exception("dobby_collector.dlq: enqueue swallowed exception")
            return None

    def drain(self, limit: int = 50) -> list[tuple[int, dict]]:
        """
        Read up to `limit` pending batches (oldest first). Does NOT remove
        them — caller is responsible for `delete()` after a successful send.

        Returns [(batch_id, payload_dict), ...]. Skips rows whose payload
        won't parse (logs + leaves them in place for `prune_corrupt()`).
        """
        if self._disabled:
            return []
        try:
            with self._lock, self._conn() as conn:
                rows = conn.execute(
                    "SELECT batch_id, payload FROM pending_batches "
                    "ORDER BY created_at ASC, batch_id ASC LIMIT ?",
                    (limit,),
                ).fetchall()
        except sqlite3.DatabaseError:
            logger.exception("dobby_collector.dlq: drain failed — DB error")
            self._maybe_reset_on_corruption()
            return []
        except Exception:  # noqa: BLE001
            logger.exception("dobby_collector.dlq: drain swallowed exception")
            return []

        out: list[tuple[int, dict]] = []
        for batch_id, payload_str in rows:
            try:
                out.append((int(batch_id), json.loads(payload_str)))
            except (TypeError, ValueError, json.JSONDecodeError):
                logger.warning(
                    "dobby_collector.dlq: skipping corrupt row batch_id=%d", batch_id
                )
        return out

    def delete(self, batch_ids: list[int]) -> int:
        """Remove batches by id. Returns count deleted. No-op on empty list."""
        if self._disabled or not batch_ids:
            return 0
        try:
            with self._lock, self._conn() as conn:
                placeholders = ",".join("?" * len(batch_ids))
                cur = conn.execute(
                    f"DELETE FROM pending_batches WHERE batch_id IN ({placeholders})",
                    batch_ids,
                )
                return cur.rowcount
        except Exception:  # noqa: BLE001
            logger.exception("dobby_collector.dlq: delete swallowed exception")
            return 0

    def increment_attempts(self, batch_ids: list[int]) -> None:
        """Track failed drain attempts so prune_corrupt can reap permanently-stuck rows."""
        if self._disabled or not batch_ids:
            return
        try:
            with self._lock, self._conn() as conn:
                placeholders = ",".join("?" * len(batch_ids))
                conn.execute(
                    f"UPDATE pending_batches SET attempts = attempts + 1 "
                    f"WHERE batch_id IN ({placeholders})",
                    batch_ids,
                )
        except Exception:  # noqa: BLE001
            logger.exception("dobby_collector.dlq: increment_attempts swallowed")

    def count(self) -> int:
        """Number of pending batches. Cheap — 0 if DLQ is disabled."""
        if self._disabled:
            return 0
        try:
            with self._lock, self._conn() as conn:
                row = conn.execute("SELECT COUNT(*) FROM pending_batches").fetchone()
                return int(row[0]) if row else 0
        except Exception:  # noqa: BLE001
            return 0

    def prune_older_than(self, max_age_seconds: float) -> int:
        """
        Delete batches older than `max_age_seconds`. Returns count deleted.

        Default policy is to let `enqueue()`'s LRU eviction handle space.
        Use this when the customer wants a stricter retention (e.g. comply
        with their own data-residency / GDPR rules).
        """
        if self._disabled:
            return 0
        cutoff = time.time() - max_age_seconds
        try:
            with self._lock, self._conn() as conn:
                cur = conn.execute(
                    "DELETE FROM pending_batches WHERE created_at < ?", (cutoff,)
                )
                return cur.rowcount
        except Exception:  # noqa: BLE001
            logger.exception("dobby_collector.dlq: prune swallowed exception")
            return 0

    def _maybe_reset_on_corruption(self) -> None:
        """If the SQLite file is unreadable, delete it + recreate empty."""
        if self._disabled or self._path is None:
            return
        with contextlib.suppress(Exception):
            self._path.unlink(missing_ok=True)
        with contextlib.suppress(Exception):
            self._init_db()
        logger.warning(
            "dobby_collector.dlq: reset corrupted file at %s", self._path
        )
