"""
Framework-specific auto-instrumentation adapters.

Each adapter translates a framework's native callback / hook API into the
SDK's canonical `SdkEvent` shape, so customers can plug Dobby in without
manually decorating every function with `@track` or wrapping every block
with `span()`.

Phase 2b ships LangChain. Phase 4 ships CrewAI / AutoGen / OpenAI SDK /
Anthropic SDK.

Each integration imports its framework lazily so the SDK's base install
(`pip install dobby-collector`) doesn't pull LangChain etc. as transitive
dependencies. Use the framework's `[extras]` to opt-in:

    pip install dobby-collector[langchain]
"""

__all__: list[str] = []
