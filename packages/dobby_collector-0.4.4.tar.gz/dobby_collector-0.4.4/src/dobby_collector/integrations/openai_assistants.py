"""
OpenAI Assistants API auto-instrumentation
===========================================

Customer subclasses (or uses directly) `DobbyAssistantsHandler` when
streaming a run via `client.beta.threads.runs.stream()` — every run-step
/ message / tool-call / text-event fires a Dobby SdkEvent automatically.

Usage::

    from openai import OpenAI
    from dobby_collector import init, start_run, end_run
    from dobby_collector.integrations.openai_assistants import DobbyAssistantsHandler

    init(api_key="dsdk_...", connector_id="wc_...")

    client = OpenAI()
    assistant = client.beta.assistants.create(model="gpt-4o-mini", ...)
    thread = client.beta.threads.create()
    client.beta.threads.messages.create(thread_id=thread.id, role="user", content="...")

    run = start_run(name="my_assistants_query", inputs={"thread_id": thread.id})
    try:
        with client.beta.threads.runs.stream(
            thread_id=thread.id,
            assistant_id=assistant.id,
            event_handler=DobbyAssistantsHandler(),
        ) as stream:
            stream.until_done()
        end_run(run, status="success")
    except Exception as e:
        end_run(run, status="error", error=str(e))
        raise

Why different from LangChain / CrewAI / AutoGen patterns:
    OpenAI Assistants API uses a SERVER-SIDE polling-thread model.
    Customer creates an Assistant + Thread + posts a Run, then either
    polls or streams. The official SDK exposes an `AssistantEventHandler`
    subclass with `on_*()` methods — same pattern as LangChain's
    `BaseCallbackHandler`. Our integration is a `DobbyAssistantsHandler`
    subclass that emits SdkEvents in each on_*() method.

    A new handler instance is constructed per stream call (no global
    registration like CrewAI's event bus). That's a feature, not a bug —
    each stream gets isolated state for parent/child event_id mapping.

Run-boundary management:
    Unlike CrewAI's CrewKickoffStartedEvent / AutoGen's session, there's
    no obvious "the run started" event in OpenAI Assistants — the run
    is created BEFORE the stream begins. So the handler does NOT
    auto-start_run() by default. Customer wraps the stream in their own
    `start_run()` / `end_run()`. The example above is the canonical
    pattern.

Install::

    pip install dobby-collector[openai_assistants]

Lazy import: this module imports `openai` at module load. If openai
isn't installed, the import raises ImportError with a remediation
message.

Compatibility:
    Verified against openai==2.37.0. The AssistantEventHandler API has
    been stable since openai>=1.20 (early 2024). Customers on older
    openai: pin a newer version.
"""

from __future__ import annotations

import logging
import threading
from collections import OrderedDict
from time import time
from typing import Any, Optional

from .._api import _emit
from .._config import get_collector
from .._events import SdkEvent, iso_now, new_event_id

logger = logging.getLogger(__name__)

try:
    from openai import AssistantEventHandler
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "DobbyAssistantsHandler requires openai>=1.20. Install with: "
        "pip install dobby-collector[openai_assistants]  (or: pip install openai)"
    ) from e


# Dobby SdkEvent types (mirror other handler vocab)
SPAN_STARTED = "span.started"
SPAN_COMPLETED = "span.completed"
SPAN_FAILED = "span.failed"
TOOL_START = "tool.start"
TOOL_END = "tool.end"
LLM_START = "llm.start"
LLM_END = "llm.completion"  # MUST match _events.LLM_COMPLETION for server pairing
MESSAGE = "agent.message"
RUN_STEP = "agent.run_step"

_DEFAULT_MAX_PAYLOAD_CHARS = 4000
_DEFAULT_MAP_SIZE = 1024


def _truncate(value: Any, max_chars: int = _DEFAULT_MAX_PAYLOAD_CHARS) -> Any:
    """
    Coerce value to a JSON-serializable shape and truncate long strings.

    OpenAI Assistants surfaces Pydantic v2 objects (RunStep, MessageDelta,
    ToolCallDelta, etc.) in event handler callbacks. Without coercion the
    sender's `json.dumps()` crashes and the batch drops silently. Mirror
    of the crewai.py / langchain.py / autogen.py fixes from v0.4.1+.
    """
    if value is None:
        return None
    if isinstance(value, str):
        return value if len(value) <= max_chars else value[:max_chars] + "...[truncated]"
    if isinstance(value, list):
        return [_truncate(v, max_chars) for v in value[:50]]
    if isinstance(value, dict):
        return {k: _truncate(v, max_chars) for k, v in list(value.items())[:50]}
    # JSON-native primitives must pass through unchanged — coercing to string
    # would break downstream queries that expect numeric/boolean BQ values.
    # `bool` is checked before `int` because `bool` IS-A `int` in Python.
    if isinstance(value, (bool, int, float)):
        return value
    # Pydantic v2 model — serialise via model_dump() then truncate.
    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        try:
            return _truncate(model_dump(), max_chars)
        except Exception:  # noqa: BLE001 — fall through to str fallback
            pass
    # Any other type — coerce to string (last-resort JSON safety net).
    s = str(value)
    return s if len(s) <= max_chars else s[:max_chars] + "...[truncated]"


def _safe_attr(obj: Any, name: str, default: Any = None) -> Any:
    """Read an attr from an OpenAI SDK pydantic model defensively."""
    try:
        v = getattr(obj, name, default)
        return v if v is not None else default
    except Exception:  # noqa: BLE001
        return default


def _dump_model(obj: Any, max_chars: int) -> Any:
    """Dump an OpenAI pydantic model to dict, with truncation."""
    if obj is None:
        return None
    try:
        if hasattr(obj, "model_dump"):
            return _truncate(obj.model_dump(), max_chars)
        if hasattr(obj, "to_dict"):
            return _truncate(obj.to_dict(), max_chars)
        return _truncate(str(obj), max_chars)
    except Exception:  # noqa: BLE001
        return None


class _BoundedLRU(OrderedDict):
    def __init__(self, max_size: int) -> None:
        super().__init__()
        self._max_size = max_size

    def __setitem__(self, key: str, value: Any) -> None:
        if key in self:
            self.move_to_end(key)
        super().__setitem__(key, value)
        if len(self) > self._max_size:
            self.popitem(last=False)

    def get_or_none(self, key: str) -> Any:
        if key in self:
            self.move_to_end(key)
            return OrderedDict.__getitem__(self, key)
        return None


class DobbyAssistantsHandler(AssistantEventHandler):
    """
    OpenAI Assistants API event handler that emits Dobby SdkEvents for
    every callback the SDK fires during a streamed run.

    Per-stream instance: construct one per `client.beta.threads.runs.stream()`
    call. The handler maintains internal state (run-step → event_id map)
    that's scoped to one stream.

    Args:
        framework: Tag emitted on every event. Defaults to "openai_assistants".
        max_payload_chars: Per-field truncation cap. Default 4000.

    Example:
        handler = DobbyAssistantsHandler()
        with client.beta.threads.runs.stream(
            thread_id=t.id, assistant_id=a.id, event_handler=handler,
        ) as stream:
            stream.until_done()
    """

    def __init__(
        self,
        *,
        framework: str = "openai_assistants",
        max_payload_chars: int = _DEFAULT_MAX_PAYLOAD_CHARS,
    ) -> None:
        super().__init__()
        self._framework = framework
        self._max_payload_chars = max_payload_chars
        self._lock = threading.Lock()
        # OpenAI run-step id → Dobby event_id mapping (start → done pairing)
        self._step_event_map: _BoundedLRU = _BoundedLRU(_DEFAULT_MAP_SIZE)
        # Per-step start time (monotonic) for duration_ms on done events
        self._step_start_times: _BoundedLRU = _BoundedLRU(_DEFAULT_MAP_SIZE)
        # Tool-call id → Dobby event_id mapping
        self._tool_event_map: _BoundedLRU = _BoundedLRU(_DEFAULT_MAP_SIZE)
        self._tool_start_times: _BoundedLRU = _BoundedLRU(_DEFAULT_MAP_SIZE)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_run_id(self) -> str:
        c = get_collector()
        if c is not None:
            rid = c.get_current_run()
            if rid is not None:
                return rid
        from .._events import new_run_id

        return new_run_id()

    def _emit(
        self,
        *,
        event_type: str,
        name: Optional[str] = None,
        status: Optional[str] = None,
        data: Optional[dict[str, Any]] = None,
        parent_event_id: Optional[str] = None,
        duration_ms: Optional[float] = None,
    ) -> str:
        """Build + emit one SdkEvent. Returns the new Dobby event_id."""
        dobby_event_id = new_event_id()
        sdk_event = SdkEvent(
            event_id=dobby_event_id,
            run_id=self._resolve_run_id(),
            timestamp=iso_now(),
            type=event_type,
            name=name,
            parent_event_id=parent_event_id,
            duration_ms=duration_ms,
            status=status,
            data=data,
            framework=self._framework,
        )
        try:
            _emit(sdk_event)
        except Exception:  # noqa: BLE001 — handler must NEVER raise into customer
            logger.exception("DobbyAssistantsHandler: _emit swallowed")
        return dobby_event_id

    # ------------------------------------------------------------------
    # OpenAI AssistantEventHandler callbacks
    # ------------------------------------------------------------------

    def on_run_step_created(self, run_step: Any) -> None:
        """A new run step (message_creation or tool_calls) was created."""
        try:
            step_id = _safe_attr(run_step, "id", "unknown")
            step_type = _safe_attr(run_step, "type", "unknown")
            dobby_id = self._emit(
                event_type=SPAN_STARTED,
                name=f"run_step:{step_type}",
                data={
                    "step_id": step_id,
                    "step_type": step_type,
                    "thread_id": _safe_attr(run_step, "thread_id"),
                    "run_id_openai": _safe_attr(run_step, "run_id"),
                },
            )
            with self._lock:
                self._step_event_map[step_id] = dobby_id
                self._step_start_times[step_id] = time()
        except Exception:  # noqa: BLE001
            logger.exception("on_run_step_created swallowed")

    def on_run_step_done(self, run_step: Any) -> None:
        """A run step completed."""
        try:
            step_id = _safe_attr(run_step, "id", "unknown")
            step_type = _safe_attr(run_step, "type", "unknown")
            status = _safe_attr(run_step, "status", "unknown")
            with self._lock:
                start_id = self._step_event_map.get_or_none(step_id)
                start_time = self._step_start_times.get_or_none(step_id)
            duration_ms = (time() - start_time) * 1000.0 if start_time else None
            sdk_status = "success" if status == "completed" else (
                "error" if status in ("failed", "cancelled", "expired") else None
            )
            self._emit(
                event_type=SPAN_COMPLETED if sdk_status != "error" else SPAN_FAILED,
                name=f"run_step:{step_type}",
                status=sdk_status,
                data={
                    "step_id": step_id,
                    "step_type": step_type,
                    "openai_status": status,
                    "usage": _dump_model(
                        _safe_attr(run_step, "usage"), self._max_payload_chars
                    ),
                },
                parent_event_id=start_id,
                duration_ms=duration_ms,
            )
        except Exception:  # noqa: BLE001
            logger.exception("on_run_step_done swallowed")

    def on_message_created(self, message: Any) -> None:
        """A new message was created (typically the assistant's reply)."""
        try:
            self._emit(
                event_type=MESSAGE,
                name="message_created",
                data={
                    "message_id": _safe_attr(message, "id"),
                    "role": _safe_attr(message, "role"),
                    "thread_id": _safe_attr(message, "thread_id"),
                },
            )
        except Exception:  # noqa: BLE001
            logger.exception("on_message_created swallowed")

    def on_message_done(self, message: Any) -> None:
        """A message completed."""
        try:
            content = _safe_attr(message, "content", [])
            # content is a list of MessageContent (text / image / etc.)
            text_parts = []
            for c in content if isinstance(content, list) else []:
                if hasattr(c, "text") and hasattr(c.text, "value"):
                    text_parts.append(c.text.value)
            full_text = "\n".join(text_parts) if text_parts else None
            self._emit(
                event_type=MESSAGE,
                name="message_done",
                status="success",
                data={
                    "message_id": _safe_attr(message, "id"),
                    "role": _safe_attr(message, "role"),
                    "text": _truncate(full_text, self._max_payload_chars),
                },
            )
        except Exception:  # noqa: BLE001
            logger.exception("on_message_done swallowed")

    def on_tool_call_created(self, tool_call: Any) -> None:
        """A new tool call started."""
        try:
            tool_id = _safe_attr(tool_call, "id", "unknown")
            tool_type = _safe_attr(tool_call, "type", "unknown")
            # OpenAI tool types: code_interpreter / file_search / function
            tool_name = tool_type
            if tool_type == "function":
                fn = _safe_attr(tool_call, "function")
                if fn:
                    tool_name = _safe_attr(fn, "name", "function")
            dobby_id = self._emit(
                event_type=TOOL_START,
                name=tool_name,
                data={
                    "tool_id": tool_id,
                    "tool_type": tool_type,
                    "tool_name": tool_name,
                },
            )
            with self._lock:
                self._tool_event_map[tool_id] = dobby_id
                self._tool_start_times[tool_id] = time()
        except Exception:  # noqa: BLE001
            logger.exception("on_tool_call_created swallowed")

    def on_tool_call_done(self, tool_call: Any) -> None:
        """A tool call completed."""
        try:
            tool_id = _safe_attr(tool_call, "id", "unknown")
            tool_type = _safe_attr(tool_call, "type", "unknown")
            tool_name = tool_type
            arguments = None
            output = None
            if tool_type == "function":
                fn = _safe_attr(tool_call, "function")
                if fn:
                    tool_name = _safe_attr(fn, "name", "function")
                    arguments = _safe_attr(fn, "arguments")
                    output = _safe_attr(fn, "output")
            elif tool_type == "code_interpreter":
                ci = _safe_attr(tool_call, "code_interpreter")
                if ci:
                    arguments = _safe_attr(ci, "input")
                    output = _safe_attr(ci, "outputs")
            with self._lock:
                start_id = self._tool_event_map.get_or_none(tool_id)
                start_time = self._tool_start_times.get_or_none(tool_id)
            duration_ms = (time() - start_time) * 1000.0 if start_time else None
            self._emit(
                event_type=TOOL_END,
                name=tool_name,
                status="success",
                data={
                    "tool_id": tool_id,
                    "tool_type": tool_type,
                    "tool_name": tool_name,
                    "arguments": _truncate(arguments, self._max_payload_chars),
                    "output": _dump_model(output, self._max_payload_chars),
                },
                parent_event_id=start_id,
                duration_ms=duration_ms,
            )
        except Exception:  # noqa: BLE001
            logger.exception("on_tool_call_done swallowed")

    def on_exception(self, exception: Exception) -> None:
        """The run raised an exception."""
        try:
            self._emit(
                event_type=SPAN_FAILED,
                name="run_exception",
                status="error",
                data={"error": str(exception)[:1000]},
            )
        except Exception:  # noqa: BLE001
            logger.exception("on_exception swallowed")

    def on_timeout(self) -> None:
        """The run timed out."""
        try:
            self._emit(
                event_type=SPAN_FAILED,
                name="run_timeout",
                status="error",
                data={"error": "openai_assistants_run_timeout"},
            )
        except Exception:  # noqa: BLE001
            logger.exception("on_timeout swallowed")
