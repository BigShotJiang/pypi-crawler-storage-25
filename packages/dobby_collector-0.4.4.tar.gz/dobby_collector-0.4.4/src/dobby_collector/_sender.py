"""
Background sender thread
=========================

Drains the buffer every `flush_interval_seconds` (default 10s) and POSTs to:

  POST {base_url}/api/v1/webhooks/workloads/{connector_id}
  Authorization: Bearer {api_key}
  Content-Type: application/json
  { "events": [...], "sdk_meta": {...} }

Retry policy: 3 attempts on 5xx + network errors with exp backoff (1s, 5s, 25s).
4xx are NOT retried — they indicate a customer-side bug (bad token, malformed
event, banned connector). Dropped + logged.

Telemetry MUST NEVER block the customer's agent. Every error path swallows
and logs — the sender thread can never propagate exceptions to the main thread.
"""

from __future__ import annotations

import contextlib
import logging
import secrets
import threading
import time
from typing import Optional

import httpx

from ._buffer import EventBuffer
from ._dlq import Dlq
from ._events import SdkBatch, SdkEvent, SdkMeta

logger = logging.getLogger("dobby_collector.sender")

# Max events per POST. Lots of small batches > one huge slow batch.
DEFAULT_BATCH_SIZE = 500

# Retry schedule for 5xx + network errors (seconds).
RETRY_DELAYS_SECONDS = (1.0, 5.0, 25.0)

# Cap on DLQ batches drained per loop iteration. Keeps a backlogged process
# from spending forever draining old batches before getting to fresh events.
MAX_DLQ_DRAIN_PER_ITERATION = 10

# After N consecutive failed delivery attempts on a single DLQ row, give up
# and delete it. Prevents a permanently-corrupt batch from blocking newer ones.
MAX_DLQ_ATTEMPTS_BEFORE_REAP = 5


def _make_traceparent() -> str:
    """
    Generate a W3C Trace Context `traceparent` header value (v0.4.0+).

    Format: `{version}-{trace-id}-{parent-id}-{trace-flags}`
        - version    = `00` (only defined version per W3C spec)
        - trace-id   = 16 bytes hex (32 chars), MUST NOT be all zeros
        - parent-id  = 8 bytes hex  (16 chars), MUST NOT be all zeros
        - trace-flags = `01` (sampled — we always want server to record it)

    A fresh traceparent is generated per outbound batch POST. Server-side
    Phase 4.5 writer (extractTraceparent) stamps it onto workload_runs.
    The Surrounding-mode governance detector (detectTracingEnabled) counts
    the rows that carry it — so any SDK customer on v0.4.0+ automatically
    flips that control from `not_applicable` → `configured`.

    Why per-batch (not per-process or per-event):
      - Per-process: would emit the same traceparent forever; defeats the
        purpose of trace correlation.
      - Per-event: requires threading a context through every emit call
        and the SDK doesn't expose request-level identity to the customer's
        code paths today.
      - Per-batch: clean batch-level transaction identifier; matches how
        the firewall reads traceparent (per-request scope).
    """
    trace_id = secrets.token_hex(16)   # 32 hex chars = 16 bytes
    span_id = secrets.token_hex(8)     # 16 hex chars = 8 bytes
    return f"00-{trace_id}-{span_id}-01"


class Sender:
    """
    Owns one daemon thread that flushes the buffer at a regular interval.

    Lifecycle:
        sender = Sender(...)
        sender.start()
        # ... agent runs, events accumulate ...
        sender.stop(timeout=5.0)   # drains remaining buffer + joins thread
    """

    def __init__(
        self,
        *,
        buffer: EventBuffer,
        api_key: str,
        connector_id: str,
        base_url: str,
        sdk_version: str,
        flush_interval_seconds: float = 10.0,
        batch_size: int = DEFAULT_BATCH_SIZE,
        framework: Optional[str] = None,
        host_fingerprint: Optional[str] = None,
        http_timeout_seconds: float = 30.0,
        http_client: Optional[httpx.Client] = None,
        dlq: Optional[Dlq] = None,
    ) -> None:
        self._buffer = buffer
        self._api_key = api_key
        self._connector_id = connector_id
        self._endpoint = f"{base_url.rstrip('/')}/api/v1/webhooks/workloads/{connector_id}"
        self._flush_interval_seconds = flush_interval_seconds
        self._batch_size = batch_size
        self._sdk_meta = SdkMeta(
            version=sdk_version,
            framework=framework,
            host_fingerprint=host_fingerprint,
        )
        self._http = http_client or httpx.Client(timeout=http_timeout_seconds)
        self._owns_http_client = http_client is None
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        # DLQ — None means no offline-survival persistence (Phase 2a behavior).
        # When provided, the sender:
        #   - drains DLQ FIRST on each flush iteration (oldest pending first)
        #   - persists batches HERE on retry-exhausted 5xx/network errors
        # 4xx still drops immediately — those are customer-fixable, not retryable.
        self._dlq = dlq

    # ----- lifecycle -----------------------------------------------------

    def start(self) -> None:
        """Start the background flusher thread. Idempotent."""
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run,
            name="dobby_collector.sender",
            daemon=True,
        )
        self._thread.start()

    def stop(self, *, timeout: float = 5.0) -> None:
        """
        Signal the thread to drain + exit. Blocks up to `timeout` seconds.
        Best-effort — if the final POST is still in-flight when the timeout
        fires, those events are lost (Phase 2b adds SQLite DLQ).
        """
        self._stop_event.set()
        self._buffer.request_flush()
        if self._thread is not None:
            self._thread.join(timeout=timeout)
            self._thread = None
        if self._owns_http_client:
            with contextlib.suppress(Exception):
                # Defensive: shutdown must never throw on an already-closed client.
                self._http.close()

    def flush_now(self) -> None:
        """Wake the thread early — used on terminal events."""
        self._buffer.request_flush()

    # ----- internals -----------------------------------------------------

    def _run(self) -> None:
        """Thread main loop. Exits when `stop_event` is set AND buffer empty."""
        while not self._stop_event.is_set():
            # Wait for flush signal OR interval timeout.
            self._buffer.wait_for_flush_signal(timeout=self._flush_interval_seconds)
            self._drain_and_send()

        # Final drain after stop signal.
        self._drain_and_send(drain_all=True)

    def _drain_and_send(self, *, drain_all: bool = False) -> None:
        """Drain DLQ first, then buffer in batches. Swallows all exceptions."""
        try:
            # Phase 1 — drain pending DLQ batches (offline-survival retry).
            # Cap at MAX_DLQ_DRAIN_PER_ITERATION so a huge backlog doesn't
            # block fresh events forever.
            self._drain_dlq_batches(MAX_DLQ_DRAIN_PER_ITERATION)

            # Phase 2 — drain in-memory buffer.
            while True:
                events = self._buffer.drain(self._batch_size)
                if not events:
                    return
                self._send_batch(events)
                if not drain_all:
                    return
        except Exception:  # noqa: BLE001 — sender thread MUST NOT crash
            logger.exception("dobby_collector: drain loop swallowed exception")

    def _drain_dlq_batches(self, limit: int) -> None:
        """Pull pending DLQ batches + try to send each. Best-effort."""
        if self._dlq is None or not self._dlq.enabled:
            return
        try:
            pending = self._dlq.drain(limit=limit)
        except Exception:  # noqa: BLE001
            logger.exception("dobby_collector: DLQ drain swallowed")
            return
        if not pending:
            return

        successful_ids: list[int] = []
        failed_ids: list[int] = []
        for batch_id, payload in pending:
            # `payload` is already a dict — same shape as SdkBatch.to_dict()
            ok = self._send_payload(payload)
            if ok:
                successful_ids.append(batch_id)
            else:
                failed_ids.append(batch_id)

        if successful_ids:
            self._dlq.delete(successful_ids)
            logger.info(
                "dobby_collector: drained %d batches from DLQ", len(successful_ids)
            )
        if failed_ids:
            self._dlq.increment_attempts(failed_ids)
            # Reap rows that have failed too many times — they're either
            # permanently broken (auth changed, connector deleted) or the
            # payload itself is malformed. Better to lose 1 stuck batch than
            # block newer ones forever.
            self._reap_stuck_dlq_rows()

    def _reap_stuck_dlq_rows(self) -> None:
        """Delete DLQ rows that have failed N+ times — they're permanently stuck."""
        if self._dlq is None or not self._dlq.enabled:
            return
        try:
            # Cheap one-shot SQL via the connection — drain + filter would be
            # heavier. Direct DELETE on attempts threshold.
            with contextlib.suppress(Exception):
                with self._dlq._lock, self._dlq._conn() as conn:  # type: ignore[attr-defined]
                    cur = conn.execute(
                        "DELETE FROM pending_batches WHERE attempts >= ?",
                        (MAX_DLQ_ATTEMPTS_BEFORE_REAP,),
                    )
                    if cur.rowcount > 0:
                        logger.warning(
                            "dobby_collector: reaped %d permanently-stuck DLQ batches",
                            cur.rowcount,
                        )
        except Exception:  # noqa: BLE001
            logger.exception("dobby_collector: DLQ reap swallowed")

    def _send_batch(self, events: list[SdkEvent]) -> None:
        """POST one batch with retry. On retry exhaustion → persist to DLQ."""
        # Read + clear the dropped-events counter atomically so this batch
        # carries the count of events lost since the prior batch. Server
        # logs it as a customer-health signal ("telemetry was degraded
        # around this run"). Zero is intentionally omitted from the wire
        # via SdkMeta.to_dict — saves bytes on healthy batches.
        dropped = self._buffer.reset_dropped_count()
        if dropped > 0:
            logger.warning(
                "dobby_collector: %d events dropped from buffer (overflow) — reporting in batch sdk_meta",
                dropped,
            )

        sdk_meta = SdkMeta(
            version=self._sdk_meta.version,
            framework=self._sdk_meta.framework,
            host_fingerprint=self._sdk_meta.host_fingerprint,
            dropped_events_since_last_batch=dropped if dropped > 0 else None,
        )
        batch = SdkBatch(events=events, sdk_meta=sdk_meta)
        payload = batch.to_dict()
        ok = self._send_payload(payload)
        if not ok:
            # Retry exhausted — persist for later instead of dropping silently.
            # If DLQ is disabled (Phase 2a behavior), we already logged the
            # error in _send_payload; nothing more to do. The dropped-count
            # IS persisted alongside the payload (in sdk_meta) so it survives
            # the round-trip via DLQ.
            if self._dlq is not None and self._dlq.enabled:
                batch_id = self._dlq.enqueue(payload)
                if batch_id is not None:
                    logger.warning(
                        "dobby_collector: persisted %d events to DLQ (batch_id=%d) — "
                        "will retry on next flush",
                        len(events),
                        batch_id,
                    )

    def _send_payload(self, payload: dict) -> bool:
        """
        POST a pre-built payload with retry. Returns True on success OR on
        4xx (customer error — don't retry). Returns False on retry-exhausted
        5xx / network errors so the caller can persist to DLQ.
        """
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "User-Agent": f"dobby-collector/{self._sdk_meta.version}",
            # W3C Trace Context (v0.4.0+) — fresh per batch. Server-side
            # webhook handler extracts this and stamps onto workload_runs,
            # so detectTracingEnabled flips from `no_traceparent_observed`
            # → `configured` for SDK customers automatically.
            "traceparent": _make_traceparent(),
        }

        for attempt, delay in enumerate([0.0, *RETRY_DELAYS_SECONDS]):
            if delay > 0:
                time.sleep(delay)
            try:
                resp = self._http.post(self._endpoint, json=payload, headers=headers)
            except (httpx.NetworkError, httpx.TimeoutException) as e:
                logger.warning(
                    "dobby_collector: network error on attempt %d: %s", attempt + 1, e
                )
                continue
            except Exception:  # noqa: BLE001 — unknown httpx error → don't retry, treat as drop
                logger.exception("dobby_collector: unrecoverable POST exception")
                return True  # don't DLQ — same as 4xx, the batch is broken

            status = resp.status_code
            if 200 <= status < 300:
                event_count = len(payload.get("events", []))
                logger.debug(
                    "dobby_collector: posted %d events (status=%d)", event_count, status
                )
                return True
            if 400 <= status < 500:
                # 4xx — customer error. Don't retry, don't DLQ (it'll just
                # 4xx again forever). Drop + log.
                logger.warning(
                    "dobby_collector: dropping batch — server returned %d: %s",
                    status,
                    resp.text[:200],
                )
                return True
            # 5xx — server error. Retry per schedule.
            logger.warning(
                "dobby_collector: attempt %d returned %d, retrying", attempt + 1, status
            )

        # All retries exhausted on 5xx / network — caller decides whether to DLQ.
        logger.error(
            "dobby_collector: gave up after %d attempts on %d events",
            len(RETRY_DELAYS_SECONDS) + 1,
            len(payload.get("events", [])),
        )
        return False
