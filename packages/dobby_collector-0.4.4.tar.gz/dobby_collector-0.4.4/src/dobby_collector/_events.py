"""
Event types + envelope construction
====================================

One canonical SDK event shape that matches the server-side webhook adapter at
`web/shared/lib/connectors/dobby-sdk/event-adapter.ts`. The server treats
unknown event types as forward-compatible — they land in `_events` raw — so
adding a new type here doesn't require a server change.

Spec: docs/spikes/dobby-collector-sdk-spec.md §"Event payload — wire format"
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

import uuid_utils

# ---------------------------------------------------------------------------
# Event type discriminator — must match the regex
# `^(run|llm|tool|chain|agent|custom)\\.` in the server's `isSdkBatch()`.
# ---------------------------------------------------------------------------

# Run lifecycle
RUN_STARTED = "run.started"
RUN_COMPLETED = "run.completed"
RUN_FAILED = "run.failed"
RUN_CANCELLED = "run.cancelled"

# LLM calls
LLM_START = "llm.start"
LLM_COMPLETION = "llm.completion"

# Tool invocations
TOOL_START = "tool.start"
TOOL_END = "tool.end"

# Chain/sequence
CHAIN_START = "chain.start"
CHAIN_END = "chain.end"

# Agent reasoning
AGENT_STEP = "agent.step"

# User-defined spans via @track / span()
CUSTOM_SPAN = "custom.span"

# Terminal types — sender flushes immediately on these.
TERMINAL_EVENT_TYPES = frozenset({RUN_COMPLETED, RUN_FAILED, RUN_CANCELLED})


def new_event_id() -> str:
    """Generate a uuid7 — sortable by creation time, unique per event."""
    return str(uuid_utils.uuid7())


def new_run_id() -> str:
    """Generate a fresh run_id (uuid7) when the caller doesn't supply one."""
    return str(uuid_utils.uuid7())


def iso_now() -> str:
    """RFC 3339 UTC timestamp with millisecond precision."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.") + (
        f"{datetime.now(timezone.utc).microsecond // 1000:03d}Z"
    )


@dataclass
class SdkEvent:
    """
    Wire-format event. Mirrors `SdkEvent` interface in event-adapter.ts.

    Required: event_id, run_id, timestamp, type.
    All other fields optional — the server tolerates missing fields.
    """

    event_id: str
    run_id: str
    timestamp: str
    type: str
    name: Optional[str] = None
    parent_event_id: Optional[str] = None
    duration_ms: Optional[float] = None
    status: Optional[str] = None  # 'success' | 'error' | 'running'
    data: Optional[dict[str, Any]] = None
    framework: Optional[str] = None
    framework_version: Optional[str] = None
    sdk_version: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        """Serializable dict — drops None fields to keep payloads small."""
        raw = asdict(self)
        return {k: v for k, v in raw.items() if v is not None}


@dataclass
class SdkMeta:
    """
    Top-level batch metadata. Sent once per POST, not per event.

    `dropped_events_since_last_batch` is the count of events the in-memory
    buffer evicted due to overflow between this batch and the prior one.
    Lets the server signal "telemetry was degraded around this run" — without
    knowing WHICH events were lost (we don't, by definition — they were
    dropped before we could read them).
    """

    version: str
    framework: Optional[str] = None
    host_fingerprint: Optional[str] = None
    dropped_events_since_last_batch: Optional[int] = None

    def to_dict(self) -> dict[str, Any]:
        raw = asdict(self)
        return {k: v for k, v in raw.items() if v is not None}


@dataclass
class SdkBatch:
    """POST body shape: {events: [...], sdk_meta: {...}}."""

    events: list[SdkEvent] = field(default_factory=list)
    sdk_meta: Optional[SdkMeta] = None

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"events": [e.to_dict() for e in self.events]}
        if self.sdk_meta is not None:
            out["sdk_meta"] = self.sdk_meta.to_dict()
        return out
