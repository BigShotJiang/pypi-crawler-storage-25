"""
dobby-collector — telemetry collector for AI agents
====================================================

Capture every run, LLM call, tool invocation, and chain step from your AI
agent. Stream them to the Dobby AI Control Plane (https://dobby-ai.com) for
governance, compliance, and observability.

Quickstart:
    from dobby_collector import init, track, span, start_run, end_run, shutdown

    init(api_key="gk_user_...", connector_id="wc_...")

    @track(name="search_db", kind="tool")
    def search_db(query): ...

    run = start_run(name="weekly_report", inputs={"week": "2026-W19"})
    with span("retrieval", inputs={"query": q}):
        docs = retriever.invoke(q)
    end_run(run, outputs={"summary": "..."}, status="success")

    shutdown()  # at process exit (auto-fires via atexit if you forget)

Full spec: docs/spikes/dobby-collector-sdk-spec.md
"""

from ._api import RunHandle, end_run, span, start_run, track
from ._config import SDK_VERSION, init, shutdown

__version__ = SDK_VERSION

__all__ = [
    "init",
    "shutdown",
    "track",
    "span",
    "start_run",
    "end_run",
    "RunHandle",
    "__version__",
]
