"""
Public instrumentation API
===========================

Customer code reaches into the SDK via three primitives:

    @track(name="search_db", kind="tool")          # decorator on a function
    def search_db(q): ...

    with span("retrieval", inputs={"q": q}):       # context manager for a block
        result = retriever.invoke(q)

    run = start_run(name="weekly_report", inputs={"week": "2026-W19"})
    # ...
    end_run(run, outputs={"report_url": "..."}, status="success")

All three share one event-emission path: build an `SdkEvent`, push to the
buffer, let the sender thread flush. None of them raise — if the SDK isn't
initialized OR the buffer overflows, the customer's code keeps running.
"""

from __future__ import annotations

import functools
import logging
import time
from contextlib import contextmanager
from typing import Any, Callable, Iterator, Optional, TypeVar

from ._config import get_collector
from ._events import (
    AGENT_STEP,
    CUSTOM_SPAN,
    LLM_COMPLETION,
    LLM_START,
    RUN_CANCELLED,
    RUN_COMPLETED,
    RUN_FAILED,
    RUN_STARTED,
    TERMINAL_EVENT_TYPES,
    TOOL_END,
    TOOL_START,
    SdkEvent,
    iso_now,
    new_event_id,
    new_run_id,
)

logger = logging.getLogger("dobby_collector.api")

F = TypeVar("F", bound=Callable[..., Any])

# `kind` → (start_type, end_type). Decides which canonical event pair to emit
# from @track and span(). Falls back to custom.span when not recognized.
_KIND_TO_TYPES: dict[str, tuple[str, str]] = {
    "tool": (TOOL_START, TOOL_END),
    "llm": (LLM_START, LLM_COMPLETION),
    "agent_step": (AGENT_STEP, AGENT_STEP),  # single-event type
    "custom": (CUSTOM_SPAN, CUSTOM_SPAN),
}


# ---------------------------------------------------------------------------
# Emission helper — the single chokepoint that touches the buffer
# ---------------------------------------------------------------------------


def _emit(event: SdkEvent) -> None:
    """Push an event to the buffer. Silently no-ops if SDK is not initialized."""
    collector = get_collector()
    if collector is None:
        # Customer instrumented code but forgot to call init(). Don't raise —
        # let the agent run. They'll notice when no telemetry shows up in the UI.
        return
    try:
        collector.buffer.append(event)
        if event.type in TERMINAL_EVENT_TYPES:
            collector.sender.flush_now()
    except Exception:  # noqa: BLE001 — instrumentation must never break the agent
        logger.exception("dobby_collector: _emit swallowed exception")


def _current_run_id_or_new() -> str:
    """Lookup the active run_id; mint one if no run is active."""
    c = get_collector()
    if c is None:
        return new_run_id()
    rid = c.get_current_run()
    return rid or new_run_id()


# ---------------------------------------------------------------------------
# start_run / end_run — explicit run boundaries
# ---------------------------------------------------------------------------


class RunHandle:
    """Returned by `start_run`, passed back to `end_run` to close the run."""

    __slots__ = ("run_id", "started_at_monotonic", "name")

    def __init__(self, run_id: str, started_at_monotonic: float, name: Optional[str]) -> None:
        self.run_id = run_id
        self.started_at_monotonic = started_at_monotonic
        self.name = name


def start_run(
    *,
    name: Optional[str] = None,
    inputs: Optional[Any] = None,
    run_id: Optional[str] = None,
    metadata: Optional[dict[str, Any]] = None,
) -> RunHandle:
    """
    Mark the start of an agent invocation. Emits a `run.started` event and
    sets the run as ambient (so subsequent @track / span() calls inherit it).
    """
    rid = run_id or new_run_id()

    data: dict[str, Any] = {}
    if inputs is not None:
        data["inputs"] = inputs
    if name is not None:
        data["agent_name"] = name
    if metadata:
        data["metadata"] = metadata

    event = SdkEvent(
        event_id=new_event_id(),
        run_id=rid,
        timestamp=iso_now(),
        type=RUN_STARTED,
        name=name,
        status="running",
        data=data or None,
    )
    _emit(event)

    c = get_collector()
    if c is not None:
        c.set_current_run(rid)

    return RunHandle(run_id=rid, started_at_monotonic=time.monotonic(), name=name)


def end_run(
    run: RunHandle,
    *,
    outputs: Optional[Any] = None,
    status: str = "success",
    error: Optional[str] = None,
) -> None:
    """
    Mark the end of an agent invocation. Emits one of run.completed /
    run.failed / run.cancelled based on `status`.

    Triggers an immediate buffer flush — terminal events are time-sensitive
    (Policy Scanner needs them within ~10s for the run to land in BQ).
    """
    duration_ms = (time.monotonic() - run.started_at_monotonic) * 1000.0

    if status == "success":
        ev_type = RUN_COMPLETED
    elif status == "cancelled":
        ev_type = RUN_CANCELLED
    else:
        ev_type = RUN_FAILED

    data: dict[str, Any] = {}
    if outputs is not None:
        data["outputs"] = outputs
    if error is not None:
        data["error"] = error

    event = SdkEvent(
        event_id=new_event_id(),
        run_id=run.run_id,
        timestamp=iso_now(),
        type=ev_type,
        name=run.name,
        duration_ms=duration_ms,
        status=status if status in ("success", "error", "running") else "error",
        data=data or None,
    )
    _emit(event)

    c = get_collector()
    if c is not None and c.get_current_run() == run.run_id:
        c.set_current_run(None)


# ---------------------------------------------------------------------------
# span — context manager for a chunk of code
# ---------------------------------------------------------------------------


@contextmanager
def span(
    name: str,
    *,
    kind: str = "custom",
    inputs: Optional[Any] = None,
    metadata: Optional[dict[str, Any]] = None,
) -> Iterator[None]:
    """
    Mark a sub-step of a run. Emits a start event on enter, an end event on
    exit. Use for any logical unit of work that's worth capturing — DB queries,
    external API calls, retrieval steps, etc.

        with span("retrieve_docs", kind="tool", inputs={"query": q}):
            docs = retriever.invoke(q)
    """
    start_type, end_type = _KIND_TO_TYPES.get(kind, (CUSTOM_SPAN, CUSTOM_SPAN))
    rid = _current_run_id_or_new()
    parent_event_id = new_event_id()
    started_monotonic = time.monotonic()

    start_data: dict[str, Any] = {}
    if inputs is not None:
        start_data["inputs"] = inputs
    if kind == "tool":
        start_data["tool_name"] = name
        if inputs is not None:
            start_data["args"] = inputs
    if metadata:
        start_data["metadata"] = metadata

    _emit(
        SdkEvent(
            event_id=parent_event_id,
            run_id=rid,
            timestamp=iso_now(),
            type=start_type,
            name=name,
            status="running",
            data=start_data or None,
        )
    )

    error: Optional[BaseException] = None
    try:
        yield
    except BaseException as e:
        error = e
        raise
    finally:
        duration_ms = (time.monotonic() - started_monotonic) * 1000.0
        end_data: dict[str, Any] = {}
        if kind == "tool":
            end_data["tool_name"] = name
        if error is not None:
            end_data["error"] = repr(error)

        _emit(
            SdkEvent(
                event_id=new_event_id(),
                run_id=rid,
                timestamp=iso_now(),
                type=end_type,
                name=name,
                parent_event_id=parent_event_id,
                duration_ms=duration_ms,
                status="error" if error is not None else "success",
                data=end_data or None,
            )
        )


# ---------------------------------------------------------------------------
# @track — decorator wrapping a function
# ---------------------------------------------------------------------------


def track(
    name: Optional[str] = None,
    *,
    kind: str = "custom",
    capture_args: bool = True,
    capture_return: bool = True,
) -> Callable[[F], F]:
    """
    Decorator that wraps a function in a span.

        @track(name="search_database", kind="tool")
        def search_db(query: str) -> list: ...

    `capture_args=True`: function args land in the start event's `inputs`/`args`.
    `capture_return=True`: return value lands in the end event's `output`.

    The wrapped function preserves the original signature via `functools.wraps`.
    Exceptions propagate to the caller — the SDK records the failure but
    re-raises so the customer's error handling still runs.
    """

    def decorator(fn: F) -> F:
        span_name = name or fn.__name__

        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            start_type, end_type = _KIND_TO_TYPES.get(kind, (CUSTOM_SPAN, CUSTOM_SPAN))
            rid = _current_run_id_or_new()
            parent_event_id = new_event_id()
            started_monotonic = time.monotonic()

            start_data: dict[str, Any] = {}
            if capture_args:
                # `args` is a tuple; `kwargs` is a dict. Don't crash on un-JSON-able
                # values — let the server-side stringify path handle it.
                start_data["inputs"] = {"args": list(args), "kwargs": kwargs}
                if kind == "tool":
                    start_data["tool_name"] = span_name
                    start_data["args"] = {"args": list(args), "kwargs": kwargs}

            _emit(
                SdkEvent(
                    event_id=parent_event_id,
                    run_id=rid,
                    timestamp=iso_now(),
                    type=start_type,
                    name=span_name,
                    status="running",
                    data=start_data or None,
                )
            )

            try:
                result = fn(*args, **kwargs)
            except BaseException as e:
                duration_ms = (time.monotonic() - started_monotonic) * 1000.0
                _emit(
                    SdkEvent(
                        event_id=new_event_id(),
                        run_id=rid,
                        timestamp=iso_now(),
                        type=end_type,
                        name=span_name,
                        parent_event_id=parent_event_id,
                        duration_ms=duration_ms,
                        status="error",
                        data={"error": repr(e)},
                    )
                )
                raise

            duration_ms = (time.monotonic() - started_monotonic) * 1000.0
            end_data: dict[str, Any] = {}
            if capture_return:
                end_data["output"] = result
            if kind == "tool":
                end_data["tool_name"] = span_name

            _emit(
                SdkEvent(
                    event_id=new_event_id(),
                    run_id=rid,
                    timestamp=iso_now(),
                    type=end_type,
                    name=span_name,
                    parent_event_id=parent_event_id,
                    duration_ms=duration_ms,
                    status="success",
                    data=end_data or None,
                )
            )

            return result

        return wrapper  # type: ignore[return-value]

    return decorator
