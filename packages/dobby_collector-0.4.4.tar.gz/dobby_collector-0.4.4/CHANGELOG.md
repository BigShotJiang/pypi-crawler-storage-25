# dobby-collector — Changelog

All notable changes to the `dobby-collector` Python SDK. Versions follow
[Semantic Versioning](https://semver.org/) — pre-1.0, `0.X.Y` bumps:
- `Y+1` = bug fix, wire-protocol unchanged, public API unchanged
- `X+1` = new feature (new event types, new framework adapter, new server contract)

Release process: see [PUBLISH.md](./PUBLISH.md).

## [0.4.4] — READY TO UPLOAD (build artifact prepared 2026-05-16 night)

Build artifacts at `sdk/python-collector/dist/dobby_collector-0.4.4*`
pass twine check. Wheel content verified to include both the primitive
passthrough fix + `SDK_VERSION="0.4.4"`. Gil-direct: `twine upload`
+ tag + flip section heading to PUBLISHED. See PUBLISH.md §v0.4.4
for the one-line command.

### Fixed
- **`_truncate()` in all 4 handlers preserves JSON-native primitives
  (`int`, `float`, `bool`)** instead of coercing to string. Regression
  introduced in v0.4.1-v0.4.3 when the `_truncate` rewrite added a
  blanket `str(value)` fallback for any non-(None/str/list/dict) type —
  that path was meant for Pydantic + other objects but inadvertently
  caught numerics + booleans too. Customer-visible impact: pre-fix,
  `metadata_json.foo = 42` rendered as `"42"` (string) in BQ —
  downstream queries that cast to INT64 / aggregate would silently
  break. Now: numerics + booleans pass through unchanged, Pydantic uses
  `model_dump()`, everything else falls back to `str(value)`. `bool`
  checked before `int` (Python's `bool IS-A int`).

### Added
- **`tests/test_handler_bug_regressions.py`** — 35-test regression net
  parametrized across all 4 handlers. Locks in two fix classes
  permanently:
  1. `_truncate()` correctly handles Pydantic + str-fallback + primitive
     passthrough + None/list/dict recursion + JSON-safety end-to-end.
  2. `LLM_END` constant aligned to `"llm.completion"` (matches server
     normalizer `extractLlmCalls` pair logic).
  Catches future framework handlers with either bug at PR time.

### Tests
- 192/192 SDK tests passing (157 existing + 35 new regression).
- 3 stale existing tests updated to assert against the new canonical
  `"llm.completion"` literal (test_crewai_handler line 298,
  test_autogen_handler lines 90 + 315).

## [0.4.3] — 2026-05-16 (PUBLISHED, commit `380cc739`)

PyPI: https://pypi.org/project/dobby-collector/0.4.3/. Tag `dobby-collector-v0.4.3`.

### Fixed
- **AutoGen handler `LLM_END` aligned to `"llm.completion"`** (was
  `"llm.end"`). The server normalizer pairs `llm.start` ↔ `llm.completion`
  — pre-fix `llm_calls=0` in BQ for every AutoGen run. Same bug class
  as the CrewAI fix in v0.4.1.
- **AutoGen handler `_truncate()` now coerces Pydantic objects** —
  defense-in-depth backport of the v0.4.2 LangChain fix. AutoGen ≥ 0.4
  typically stringifies before logging, but future autogen-core releases
  could change that and silently drop batches.
- **OpenAI Assistants handler `LLM_END` aligned to `"llm.completion"`**
  — same fix-pattern.
- **OpenAI Assistants handler `_truncate()` now coerces Pydantic
  objects** — RunStep / MessageDelta / ToolCallDelta are all Pydantic v2.

### Verified
- AutoGen E2E proven on prod 2026-05-16: pre-fix `llm_calls=0`, post-fix
  `llm_calls=1` (5/6 fields populated; `agent_steps=0` is by-design — no
  `agent.step` events in AutoGen's event model). Memory:
  `autogen-assistants-e2e-2026-05-16-evening`.

### Known limitations (not fixed in v0.4.3)
- **OpenAI Assistants E2E unverified** — fixes ship defensively but the
  `DobbyAssistantsHandler.on_*()` callbacks don't fire in openai SDK 2.37
  (Assistants API deprecated → Responses API replacement; legacy
  streaming callback dispatch appears broken). Separate Phase 6.5 work
  needed: either route through `on_event()` raw events or build a
  `DobbyResponsesHandler` for the new API.

### Cumulative coverage post-v0.4.3
- 2/4 frameworks E2E-verified end-to-end via public PyPI install
  (CrewAI + AutoGen)
- 1/4 partially verified (LangChain — 5/6 fields, LC 1.x langgraph gap)
- 1/4 source-fixed but verification incomplete (OpenAI Assistants)

## [0.4.2] — 2026-05-16 (PUBLISHED, commit `68982d53`)

### Fixed
- **LangChain handler `_truncate()` now coerces Pydantic Message objects.**
  LangChain ≥ 1.0 surfaces `HumanMessage` / `AIMessage` / `ToolMessage`
  Pydantic v2 models in event data. Pre-fix, `_truncate` fell through to
  `return value`, sender's `json.dumps()` crashed, every batch was silently
  dropped → **0 `workload_runs` rows** for any LangChain ≥ 1.0 customer.
  Now: try `model_dump()` first, fall back to `str(value)`. Same recipe as
  the CrewAI fix in v0.4.1. Commit `56fae416`.
- Verified end-to-end against prod: pre-fix 0 rows, post-fix 1 row with
  `tool_calls=1` + `llm_calls=2` + `traceparent` populated.
- PyPI: https://pypi.org/project/dobby-collector/0.4.2/

### Known limitations (not fixed in v0.4.2)
- **LangChain ≥ 1.0 `create_agent` (langgraph) doesn't fire legacy
  `on_agent_action` / `on_agent_finish` callbacks** → `agent_steps` is
  always 0 for new LangChain runs. `tool_calls` + `llm_calls` capture the
  essential signal. LangChain 0.x `AgentExecutor` users unaffected.

## [0.4.1] — 2026-05-16

### Fixed
- **CrewAI handler `_truncate()` now coerces Pydantic `TaskOutput`.**
  CrewAI's `TaskCompletedEvent.output` is a Pydantic v2 model — pre-fix
  the sender's `json.dumps()` crashed on it → batches dropped silently.
  Added `model_dump()` path + `str()` fallback. Commit `a0a0954c`.
- **CrewAI handler `LLM_END` constant corrected to `"llm.completion"`**
  (was `"llm.end"`). The server normalizer pairs `llm.start` ↔
  `llm.completion`, so the mismatch caused `llm_calls=0` in BQ even on
  successful runs. Commit `a0a0954c`.

### Companion server-side change (deployed alongside v0.4.1)
- **`extractAgentSteps` server normalizer recognises CrewAI span:agent
  events** (commit `d7f63415`). Closes the `agent_steps=0` gap for
  CrewAI — no SDK upgrade required for this piece, takes effect on next
  prod deploy.

### Verified
- PyPI install path (`pip install dobby-collector[crewai]==0.4.1`) +
  fresh prod connector + real CrewAI 2-agent crew → 6/6 BQ verification
  fields populate including `agent_steps=2`. Memory:
  `crewai-oss-pypi-end-to-end-verified-2026-05-16`.

## [0.4.0] — 2026-05-16

### Added
- **W3C Trace Context auto-emission** on every outbound batch via fresh
  `traceparent: 00-{32hex}-{16hex}-01` header generated through
  `secrets.token_hex`. Per-batch (not per-process, not per-event) so each
  upload is a unique transaction. No customer code changes — `init(...)`
  picks up the behavior automatically.
- **Server-side strict W3C validation** + all-zero sentinel rejection
  before stamping onto `workload_runs.metadata_json.traceparent`.
  Malformed headers silently dropped; the batch is never rejected.

### Customer impact
- The Surrounding-mode `Tracing Enabled` governance control (weight = 4)
  flips from `not_applicable` → `configured` for an org within one
  hourly governance-rescore cron tick after their first batch lands.
- Public docs page: `/docs/sdk/python-collector/tracing`.

## [0.3.0] — 2026-05-XX

### Added
- **`DobbyAssistantsHandler`** — auto-instrumentation for OpenAI
  Assistants API. Install via `pip install dobby-collector[openai_assistants]`.
- **`DobbyAutoGenLogHandler`** — auto-instrumentation for AutoGen ≥ 0.4.
  Install via `pip install dobby-collector[autogen]`.

## [0.2.0] — 2026-05-XX

### Added
- **`DobbyCrewAIHandler`** — auto-instrumentation for CrewAI ≥ 1.0 via
  the `CrewAIEventsBus` + `BaseEventListener` pattern. Install via
  `pip install dobby-collector[crewai]`. Runnable example +
  `examples/crewai_real_agent.py`.

## [0.1.x] — 2026-05-13/14

### Added
- **v0.1.0** Phase 1 publish — manual `@track` / `span` / `start_run` /
  `end_run` / `shutdown` API. In-memory ring buffer + background sender
  + HTTP retries. SQLite DLQ for crash-survival. First PyPI publish.
- **Phase 2b** — `DobbyCallbackHandler` for LangChain via
  `BaseCallbackHandler`. PII redaction + field exclusion. Backpressure
  synthetic event.

## Cross-references

- Release runbook: [PUBLISH.md](./PUBLISH.md)
- Server-side adapter: `web/shared/lib/connectors/dobby-sdk/normalize.ts`
  + `web/app/api/v1/webhooks/workloads/[connectorId]/route.ts`
- Verification scripts: [scripts/debug/smoke-crewai-oss.py](../../scripts/debug/smoke-crewai-oss.py) ·
  [scripts/debug/smoke-langchain-oss.py](../../scripts/debug/smoke-langchain-oss.py) ·
  [scripts/debug/smoke-dobby-sdk.py](../../scripts/debug/smoke-dobby-sdk.py)
- Customer quickstart pages: `/docs/sdk/python-collector/crewai` ·
  `/docs/sdk/python-collector/tracing`
