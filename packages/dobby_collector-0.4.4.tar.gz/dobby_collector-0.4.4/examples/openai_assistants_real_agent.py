#!/usr/bin/env python3
"""
Real OpenAI Assistants agent → Dobby (auto-instrumented via DobbyAssistantsHandler)
======================================================================================

Complete runnable example — REAL OpenAI Assistant with a custom function
tool, streamed through `client.beta.threads.runs.stream()` with every
run-step / message / tool-call captured automatically by the Dobby SDK.

Prereqs
-------

1. `pip install dobby-collector[openai_assistants]`
2. Set env vars:
     DOBBY_API_KEY       = dsdk_...   (from wizard step 2)
     DOBBY_CONNECTOR_ID  = wc_...
     OPENAI_API_KEY      = sk-...     (for the real Assistant + LLM)

Run
---

    python examples/openai_assistants_real_agent.py

What it does
------------

1. Creates an Assistant with the gpt-4o-mini model + 1 function tool
2. Creates a Thread + posts a user message
3. Streams a run with DobbyAssistantsHandler attached
4. Handler emits SdkEvents for every run_step / tool_call / message
5. Cleanup: deletes the Assistant + Thread (so prod doesn't accumulate
   thousands of test assistants)

Within ~30s the run lands in /{tenantId}/dashboard/workloads/runs.

Compatibility note
------------------

OpenAI Assistants API was MIGRATED to "Responses API" in late 2024 — the
streaming handler pattern shown here works on the Assistants v2 surface.
Customers on the newer Responses API (`client.responses.create()`) should
use the manual @track/span pattern instead until we ship a Responses
auto-handler.
"""

import json
import os
import sys
from typing import Final

from dobby_collector import end_run, init, shutdown, start_run

DOBBY_API_KEY: Final = os.environ.get("DOBBY_API_KEY") or "dsdk_REPLACE_ME"
DOBBY_CONNECTOR_ID: Final = os.environ.get("DOBBY_CONNECTOR_ID") or "wc_REPLACE_ME"

if "REPLACE_ME" in DOBBY_API_KEY or "REPLACE_ME" in DOBBY_CONNECTOR_ID:
    sys.stderr.write(
        "\n❌ DOBBY_API_KEY / DOBBY_CONNECTOR_ID not set. Mint them at "
        "/dashboard/workloads/connect/python-sdk then re-run.\n\n"
    )
    sys.exit(1)

if not os.environ.get("OPENAI_API_KEY"):
    sys.stderr.write("\n❌ OPENAI_API_KEY not set.\n\n")
    sys.exit(1)

init(api_key=DOBBY_API_KEY, connector_id=DOBBY_CONNECTOR_ID, framework="openai_assistants")

try:
    from openai import OpenAI
except ImportError as e:
    sys.stderr.write(
        "\n❌ Missing openai package. Install with:\n"
        "   pip install dobby-collector[openai_assistants]\n\n"
        f"   (Underlying error: {e})\n"
    )
    sys.exit(1)

from dobby_collector.integrations.openai_assistants import DobbyAssistantsHandler


# --- Define a real function tool ---


def calculate_density(population: int, area_km2: float) -> dict:
    """Calculate population density in people per km²."""
    return {
        "population": population,
        "area_km2": area_km2,
        "density_per_km2": round(population / area_km2, 2),
    }


CALCULATE_DENSITY_TOOL = {
    "type": "function",
    "function": {
        "name": "calculate_density",
        "description": "Calculate population density in people per km²",
        "parameters": {
            "type": "object",
            "properties": {
                "population": {"type": "integer"},
                "area_km2": {"type": "number"},
            },
            "required": ["population", "area_km2"],
        },
    },
}


# --- Main flow ---


def main() -> None:
    client = OpenAI()
    assistant = None
    thread = None

    run = start_run(
        name="openai_assistants_demo",
        inputs={"question": "Reykjavik population density"},
    )

    try:
        # 1. Create the Assistant
        assistant = client.beta.assistants.create(
            name="Reykjavik Population Bot",
            model="gpt-4o-mini",
            instructions=(
                "You answer geography questions. When asked for population "
                "density, ALWAYS use the calculate_density tool — do not "
                "compute it yourself. Use 140000 for Reykjavik population "
                "and 273 km² for area."
            ),
            tools=[CALCULATE_DENSITY_TOOL],
        )
        print(f"Created Assistant: {assistant.id}")

        # 2. Create a thread + post a user message
        thread = client.beta.threads.create()
        client.beta.threads.messages.create(
            thread_id=thread.id,
            role="user",
            content="What's the population density of Reykjavik, Iceland?",
        )
        print(f"Posted user message to thread {thread.id}")

        # 3. Stream the run with the Dobby handler attached
        print("\n🤖 Streaming run...\n")
        handler = DobbyAssistantsHandler()

        with client.beta.threads.runs.stream(
            thread_id=thread.id,
            assistant_id=assistant.id,
            event_handler=handler,
        ) as stream:
            # Some runs require us to handle the tool calls manually:
            for event in stream:
                if hasattr(event, "event") and event.event == "thread.run.requires_action":
                    # Tool calls await our output
                    tool_outputs = []
                    for tc in event.data.required_action.submit_tool_outputs.tool_calls:
                        if tc.function.name == "calculate_density":
                            args = json.loads(tc.function.arguments)
                            result = calculate_density(**args)
                            tool_outputs.append({
                                "tool_call_id": tc.id,
                                "output": json.dumps(result),
                            })
                    # Submit + continue streaming under the same handler
                    with client.beta.threads.runs.submit_tool_outputs_stream(
                        thread_id=thread.id,
                        run_id=event.data.id,
                        tool_outputs=tool_outputs,
                        event_handler=handler,
                    ) as continuation:
                        continuation.until_done()
                    break

        # 4. Read the final assistant message
        messages = client.beta.threads.messages.list(thread_id=thread.id, order="desc", limit=1)
        if messages.data and messages.data[0].role == "assistant":
            answer = messages.data[0].content[0].text.value
            print(f"\n✅ Assistant answer:\n   {answer}\n")
        else:
            answer = "(no assistant reply)"

        end_run(run, outputs={"answer": answer}, status="success")

    except Exception as e:
        print(f"\n❌ Error: {e}\n")
        end_run(run, error=str(e), status="error")
        raise

    finally:
        # 5. Cleanup — delete the Assistant + Thread (avoids leaking test
        # objects into the customer's OpenAI account)
        if assistant:
            try:
                client.beta.assistants.delete(assistant_id=assistant.id)
                print(f"Cleaned up Assistant {assistant.id}")
            except Exception:
                pass
        if thread:
            try:
                client.beta.threads.delete(thread_id=thread.id)
                print(f"Cleaned up Thread {thread.id}")
            except Exception:
                pass

        shutdown(timeout_seconds=15.0)
        print(
            "[dobby] events flushed. Check the UI:\n"
            f"  https://dobby-ai.com/{os.environ.get('DOBBY_TENANT_ID', '{tenantId}')}/dashboard/workloads/runs\n"
        )


if __name__ == "__main__":
    main()


# ---------------------------------------------------------------------------
# WHAT TO CHECK IN THE UI
# ---------------------------------------------------------------------------
#
# 1. /{tenantId}/dashboard/workloads/runs
#    Click the new "openai_assistants_demo" row → drawer with:
#      • Inputs: { question: "Reykjavik population density" }
#      • Outputs: { answer: "..." } — the assistant's reply
#      • Spans tree (run-step pairs nest via parent_event_id):
#          run.started (Dobby start_run)
#          ├── span.started: run_step:tool_calls
#          │   ├── tool.start: calculate_density
#          │   ├── tool.end:   calculate_density (w/ arguments + output)
#          │   └── span.completed: run_step:tool_calls
#          ├── span.started: run_step:message_creation
#          │   ├── agent.message: message_created
#          │   ├── agent.message: message_done (w/ extracted text)
#          │   └── span.completed: run_step:message_creation
#          └── run.completed (Dobby end_run)
#      • framework: "openai_assistants"
#
# 2. /{tenantId}/dashboard/compliance/scans
#    Same as the LangChain + CrewAI + AutoGen examples.
#
# TROUBLESHOOTING — same as langchain_real_agent.py.
#
# OpenAI Assistants-specific gotchas:
#   - openai>=1.20 required (AssistantEventHandler API stabilized then)
#   - The handler is PER-RUN (construct one per stream() call) — different
#     from CrewAI's global event_bus subscriber. State is scoped to the run.
#   - Don't forget the assistant/thread cleanup — Assistants persist in your
#     OpenAI account until deleted, and there's a quota cap (~100 active).
#   - If you use Responses API (new, replacing Assistants in 2025) — this
#     handler doesn't apply. Use manual @track/span until a Responses
#     handler ships.
