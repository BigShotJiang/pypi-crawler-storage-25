#!/usr/bin/env python3
"""
Real LangChain agent → Dobby (auto-instrumented via DobbyCallbackHandler)
==========================================================================

This is a COMPLETE runnable example — no seed data, no mocks. Sends real
LLM calls to OpenAI through a real LangChain ReAct agent, with every
chain step / tool call / LLM invocation captured by the Dobby SDK and
forwarded to the Dobby Control Plane for governance scanning.

Use this to verify your `wc_*` connector + `dsdk_*` API key WORK
end-to-end after you complete the Workloads Connect → Python SDK
wizard. Within ~30 seconds of running this you should see:

  - 1 row in /{tenantId}/dashboard/workloads (status: success)
  - 1 row in /{tenantId}/dashboard/workloads/runs
  - 1+ rows in /{tenantId}/dashboard/compliance/scans (auto-fires
    when the run lands)
  - Compliance verdicts against your imported pack policies

Prereqs
-------

1. `pip install dobby-collector langchain langchain-openai langchain-community ddgs`
2. Set these env vars (or paste them inline below):
     DOBBY_API_KEY       = dsdk_...   (from wizard step 2)
     DOBBY_CONNECTOR_ID  = wc_...     (from wizard step 2)
     OPENAI_API_KEY      = sk-...     (your own — Dobby never sees it
                                       directly; only metadata)

Run
---

    python examples/langchain_real_agent.py

Expected console output (~10-20 seconds):

    [dobby-collector] init: connector=wc_xxx, framework=langchain
    > Entering new AgentExecutor chain...
    Thought: I need to look up the population of Reykjavik.
    Action: duckduckgo_search
    Action Input: "population of Reykjavik 2026"
    Observation: Reykjavik has approximately 140,000 inhabitants ...
    Thought: I now know the final answer.
    Final Answer: Reykjavik's population is approximately 140,000.
    > Finished chain.
    [dobby-collector] flushed 8 events to dobby-ai.com (run_id=run_xxx)

Then navigate to /{tenantId}/dashboard/workloads/runs and click
through to the run drawer to see:
  - prompt, tool_calls, output captured
  - Compliance scan auto-triggered
  - Verdicts per inherited policy (Platform/Org/Tenant)

If you don't see the row within 60s, see TROUBLESHOOTING below.
"""

import os
import sys
from typing import Final

from dobby_collector import init
from dobby_collector.integrations.langchain import DobbyCallbackHandler

# --- LangChain imports (must be installed separately by the customer) ---
try:
    from langchain.agents import AgentExecutor, create_react_agent
    from langchain_community.tools import DuckDuckGoSearchRun
    from langchain_core.prompts import PromptTemplate
    from langchain_openai import ChatOpenAI
except ImportError as e:
    sys.stderr.write(
        "\n❌ Missing LangChain dependencies. Install with:\n"
        "   pip install langchain langchain-openai langchain-community ddgs\n\n"
        f"   (Underlying error: {e})\n"
    )
    sys.exit(1)


# ---------------------------------------------------------------------------
# 1. Initialize Dobby SDK
# ---------------------------------------------------------------------------
# Credentials come from env vars (DOBBY_API_KEY + DOBBY_CONNECTOR_ID).
# Falls back to the literal placeholders below ONLY for local dry-run;
# real runs MUST supply env vars or the SDK errors loud.

DOBBY_API_KEY: Final = os.environ.get("DOBBY_API_KEY") or "dsdk_REPLACE_ME"
DOBBY_CONNECTOR_ID: Final = os.environ.get("DOBBY_CONNECTOR_ID") or "wc_REPLACE_ME"

if "REPLACE_ME" in DOBBY_API_KEY or "REPLACE_ME" in DOBBY_CONNECTOR_ID:
    sys.stderr.write(
        "\n❌ DOBBY_API_KEY / DOBBY_CONNECTOR_ID not set.\n"
        "   Generate them at /dashboard/workloads/connect/python-sdk\n"
        "   then re-run:\n"
        '     export DOBBY_API_KEY="dsdk_..."\n'
        '     export DOBBY_CONNECTOR_ID="wc_..."\n'
        "     python examples/langchain_real_agent.py\n\n"
    )
    sys.exit(1)

if not os.environ.get("OPENAI_API_KEY"):
    sys.stderr.write(
        "\n❌ OPENAI_API_KEY not set. The agent makes real OpenAI calls.\n"
        "   Get a key at https://platform.openai.com/api-keys then:\n"
        '     export OPENAI_API_KEY="sk-..."\n\n'
    )
    sys.exit(1)

init(
    api_key=DOBBY_API_KEY,
    connector_id=DOBBY_CONNECTOR_ID,
    framework="langchain",
    # Defaults are fine for production. Tighten flush_interval if you
    # want events visible faster (cost: more network round-trips):
    # flush_interval_seconds=2.0,
)


# ---------------------------------------------------------------------------
# 2. Build the LangChain agent
# ---------------------------------------------------------------------------
# Minimal ReAct agent with one real tool (DuckDuckGo search). Substitute
# any tools you already use — the Dobby handler captures all of them.

llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

tools = [
    DuckDuckGoSearchRun(),
]

# Minimal ReAct prompt (LangChain's canonical shape).
prompt = PromptTemplate.from_template(
    """Answer the user's question. You have access to these tools:

{tools}

Use this format:

Question: the input question
Thought: think about what to do
Action: the action, one of [{tool_names}]
Action Input: input to the action
Observation: result of the action
... (repeat Thought/Action/Action Input/Observation as needed)
Thought: I now know the final answer
Final Answer: the final answer

Question: {input}
Thought: {agent_scratchpad}"""
)

agent = create_react_agent(llm, tools, prompt)
executor = AgentExecutor(
    agent=agent,
    tools=tools,
    verbose=True,
    max_iterations=4,
    handle_parsing_errors=True,
)


# ---------------------------------------------------------------------------
# 3. Run with DobbyCallbackHandler attached
# ---------------------------------------------------------------------------
# The handler captures every chain/llm/tool event and auto-starts an SDK
# run on the top-level invoke. On completion the SDK flushes the buffer
# to Dobby — usually within 10s of agent finish.

handler = DobbyCallbackHandler()

question = (
    "What's the current population of Reykjavik, Iceland? "
    "Cite the source you used."
)

print(f"\n🤖 Asking agent: {question}\n")

try:
    result = executor.invoke(
        {"input": question},
        config={"callbacks": [handler]},
    )
    print(f"\n✅ Agent answer:\n   {result.get('output', '(no output field)')}\n")
except Exception as e:
    print(f"\n❌ Agent error: {e}\n")
    raise
finally:
    # Force a flush before exiting so the customer sees the run land
    # without waiting for the 10s interval.
    from dobby_collector import shutdown

    shutdown(timeout_seconds=15.0)
    print(
        "[dobby] events flushed. Check the UI:\n"
        f"  https://dobby-ai.com/{os.environ.get('DOBBY_TENANT_ID', '{tenantId}')}/dashboard/workloads/runs\n"
    )


# ---------------------------------------------------------------------------
# TROUBLESHOOTING
# ---------------------------------------------------------------------------
#
# Q: I ran the script, it succeeded, but I don't see the run in /workloads.
# A: Check in order:
#    1. The SDK printed "flushed N events" — if N=0, no events were
#       captured. Verify your LangChain version is >=0.1.0 (older
#       versions had a different callback API).
#    2. The flush could have errored. Set DOBBY_LOG_LEVEL=DEBUG and re-run
#       to see the POST response (200 = accepted; 401/403 = wrong API
#       key; 404 = wrong connector_id; 5xx = transient — DLQ will retry).
#    3. The connector might be paused. Open
#       /dashboard/workloads → click your connector → Status should be
#       "Connected" (green). If "Paused" / "Auth expired", regenerate
#       the dsdk_* key.
#    4. There's a ~60s ingestion delay between SDK flush and UI row.
#       Wait a minute + hard-refresh the page (Cmd+Shift+R / Ctrl+F5)
#       — see KM #2026-05-16 (Next.js bundle cache trap).
#
# Q: I see "401 Unauthorized" in the SDK logs.
# A: The dsdk_* token is shown ONCE during wizard step 2. If you lost
#    it, regenerate via the wizard (POST creates a new token and revokes
#    the old one). Do NOT confuse with the OpenAI sk-* key.
#
# Q: I see "DLQ wrote N events to ~/.dobby-collector/dlq.sqlite".
# A: Network was unavailable during flush. The SDK persists events to a
#    local SQLite file and retries on next init(). Safe to ignore — when
#    connectivity returns, the next start_run() drains the DLQ.
#
# Q: My agent is sensitive — I don't want raw prompts/outputs in Dobby.
# A: Pass `pii_redact=True` to init() — the SDK redacts SSN/credit-card/
#    email/phone patterns BEFORE sending. For full-field exclusion use
#    `exclude_fields=["output.raw_text"]`.
