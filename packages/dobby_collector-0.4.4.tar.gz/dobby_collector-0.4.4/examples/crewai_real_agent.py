#!/usr/bin/env python3
"""
Real CrewAI agent → Dobby (auto-instrumented via DobbyCrewAIHandler)
=====================================================================

Complete runnable example — REAL CrewAI crew with real LLM calls,
captured automatically by the Dobby SDK via the crewai_event_bus.
No `@track` decorators, no `start_run`/`end_run` — instantiate the
handler once and every subsequent `crew.kickoff()` flows to Dobby.

Use this to verify your `wc_*` connector + `dsdk_*` API key WORK
end-to-end after you complete the Workloads Connect → Python SDK
wizard. Within ~30 seconds of running this you should see:

  - 1 row in /{tenantId}/dashboard/workloads (status: success)
  - 1 row in /{tenantId}/dashboard/workloads/runs
  - Per-task + per-LLM-call + per-tool-call spans nested in the
    drawer (CrewAI's parent_event_id threading is honored end-to-end)
  - 1+ rows in /{tenantId}/dashboard/compliance/scans (auto-fires
    when the run lands)
  - Compliance verdicts against your imported pack policies

Prereqs
-------

1. `pip install dobby-collector[crewai]`
   (Pulls dobby-collector + crewai>=1.0 in one shot.)
2. Set env vars:
     DOBBY_API_KEY       = dsdk_...   (from wizard step 2)
     DOBBY_CONNECTOR_ID  = wc_...     (from wizard step 2)
     OPENAI_API_KEY      = sk-...     (CrewAI's default LLM provider)

Run
---

    python examples/crewai_real_agent.py

Expected console output (~15-30 seconds depending on LLM latency):

    [dobby-collector] init: connector=wc_xxx, framework=crewai
    > Crew kickoff: research_demo_crew
    > Agent (Researcher) → planning task
    > Tool: search_web(query="population Reykjavik 2026")
    > Tool result: 140,000 inhabitants...
    > Agent (Writer) → summarizing
    > LLM call (gpt-4o-mini): generating answer
    > Crew completed: Reykjavik's population is approximately 140,000.
    [dobby] flushed N events to dobby-ai.com

Comparison vs the manual_api_real_agent.py example:
  - This file:    0 @track decorators, handler captures everything
  - manual_api:   3 @track/span calls inline, no handler needed
  - LangChain:    DobbyCallbackHandler via config={"callbacks": [handler]}

All three produce the SAME workload_run + scan + verdict chain on
the server side — pick whichever fits your stack.
"""

import os
import sys
from typing import Final

# --- Dobby SDK init (BEFORE crewai imports — handler registers on import) ---
from dobby_collector import init, shutdown

DOBBY_API_KEY: Final = os.environ.get("DOBBY_API_KEY") or "dsdk_REPLACE_ME"
DOBBY_CONNECTOR_ID: Final = os.environ.get("DOBBY_CONNECTOR_ID") or "wc_REPLACE_ME"

if "REPLACE_ME" in DOBBY_API_KEY or "REPLACE_ME" in DOBBY_CONNECTOR_ID:
    sys.stderr.write(
        "\n❌ DOBBY_API_KEY / DOBBY_CONNECTOR_ID not set.\n"
        "   Generate them at /dashboard/workloads/connect/python-sdk\n"
        "   then re-run:\n"
        '     export DOBBY_API_KEY="dsdk_..."\n'
        '     export DOBBY_CONNECTOR_ID="wc_..."\n'
        "     python examples/crewai_real_agent.py\n\n"
    )
    sys.exit(1)

if not os.environ.get("OPENAI_API_KEY"):
    sys.stderr.write(
        "\n❌ OPENAI_API_KEY not set. CrewAI defaults to OpenAI; set it before running.\n"
        "   Get a key at https://platform.openai.com/api-keys then:\n"
        '     export OPENAI_API_KEY="sk-..."\n\n'
    )
    sys.exit(1)

init(
    api_key=DOBBY_API_KEY,
    connector_id=DOBBY_CONNECTOR_ID,
    framework="crewai",
)

# --- CrewAI imports (must be after dobby init for clean log ordering) ---
try:
    from crewai import Agent, Crew, Process, Task
    from crewai_tools import SerperDevTool  # web search — needs SERPER_API_KEY
except ImportError as e:
    sys.stderr.write(
        "\n❌ Missing CrewAI dependencies. Install with:\n"
        "   pip install dobby-collector[crewai] crewai-tools\n\n"
        f"   (Underlying error: {e})\n"
    )
    sys.exit(1)


# --- Register the Dobby auto-handler (one-time, before any kickoff) ---
from dobby_collector.integrations.crewai import DobbyCrewAIHandler

handler = DobbyCrewAIHandler()
# That's it. Every future crew.kickoff() in this process flows to Dobby.


# --- Build a minimal real crew ---
# Researcher + Writer collaborate on a 1-paragraph summary. Substitute any
# of your existing CrewAI agents/tasks — the handler captures them all.

if not os.environ.get("SERPER_API_KEY"):
    # Fall back to a no-tool crew if SERPER not available
    sys.stderr.write(
        "ℹ️  No SERPER_API_KEY — running without web search.\n"
        "   Get a free key at https://serper.dev to enable real search.\n\n"
    )
    research_tools = []
    research_backstory = (
        "You're a knowledgeable researcher who answers questions from "
        "memory. When unsure, say so explicitly."
    )
else:
    research_tools = [SerperDevTool()]
    research_backstory = (
        "You're a meticulous researcher who searches the web for primary "
        "sources and cites them in your answers."
    )

researcher = Agent(
    role="Researcher",
    goal="Find accurate, up-to-date information on the user's question",
    backstory=research_backstory,
    tools=research_tools,
    verbose=True,
    allow_delegation=False,
)

writer = Agent(
    role="Writer",
    goal="Summarize the researcher's findings into a single concise paragraph",
    backstory=(
        "You're a clear, concise writer who turns research notes into "
        "1-paragraph briefings. You preserve numerical claims verbatim."
    ),
    verbose=True,
    allow_delegation=False,
)

research_task = Task(
    description=(
        "Find the current population of Reykjavik, Iceland. "
        "Note the source if you used one."
    ),
    expected_output="A short paragraph with the population figure and source.",
    agent=researcher,
)

write_task = Task(
    description=(
        "Take the researcher's findings and produce a 1-sentence summary "
        "the customer can use directly in a report."
    ),
    expected_output="A single sentence containing the population figure.",
    agent=writer,
    context=[research_task],
)

crew = Crew(
    agents=[researcher, writer],
    tasks=[research_task, write_task],
    process=Process.sequential,
    verbose=True,
)


# --- Run + flush ---

if __name__ == "__main__":
    print("\n🤖 Kicking off CrewAI crew...\n")
    try:
        result = crew.kickoff()
        print(f"\n✅ Crew result:\n   {result}\n")
    except Exception as e:
        print(f"\n❌ Crew failed: {e}\n")
        raise
    finally:
        shutdown(timeout_seconds=15.0)
        print(
            "[dobby] events flushed. Check the UI:\n"
            f"  https://dobby-ai.com/{os.environ.get('DOBBY_TENANT_ID', '{tenantId}')}/dashboard/workloads/runs\n"
        )


# ---------------------------------------------------------------------------
# WHAT TO CHECK IN THE UI
# ---------------------------------------------------------------------------
#
# 1. /{tenantId}/dashboard/workloads/runs
#    Click the new row → drawer opens with:
#      • Inputs: { topic: "..." } or empty
#      • Outputs: { result: "..." }
#      • Spans tree (CrewAI parent_event_id threading is honored):
#          crew.kickoff (run.started)
#          ├── task: research_phase (span.started)
#          │   ├── agent: Researcher (span.started)
#          │   │   ├── llm.start (gpt-4o-mini)
#          │   │   ├── tool.start: search_web
#          │   │   ├── tool.end: search_web
#          │   │   └── llm.end (...with usage)
#          │   └── agent end
#          └── task: writing_phase ...
#      • Status: success
#
# 2. /{tenantId}/dashboard/compliance/scans
#    Same as the LangChain example: auto-fires on workload_run insert,
#    evaluates against the inherited cascade.
#
# TROUBLESHOOTING — same as langchain_real_agent.py.
#
# CrewAI-specific gotchas:
#   - CrewAI ≥1.0 required (event bus API). Older versions: pin newer
#     crewai or use the manual @track/span API in manual_api_real_agent.py.
#   - DobbyCrewAIHandler() must be instantiated AFTER init() but BEFORE
#     crew.kickoff(). Registration is on the GLOBAL crewai_event_bus.
#   - Multi-process CrewAI (e.g. Process.parallel) — the bus is per-process,
#     so the handler captures only the main process's events. Sub-process
#     events are lost unless you spawn DobbyCrewAIHandler() in each.
