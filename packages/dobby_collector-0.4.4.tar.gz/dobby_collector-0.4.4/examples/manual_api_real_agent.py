#!/usr/bin/env python3
"""
Real agent → Dobby (manual @track + span API)
==============================================

Same end-to-end behavior as langchain_real_agent.py — a real LLM call +
real tool invocation — but using the SDK's manual API instead of the
LangChain auto-handler. Use this if your agent is:

  - Plain OpenAI/Anthropic SDK (no LangChain/CrewAI/AutoGen)
  - Custom orchestration code
  - Any Python that wants explicit per-span control

The decorators are zero-overhead (no events emitted if init() wasn't
called) so you can sprinkle them throughout your codebase without
gating on env vars.

Prereqs
-------

1. `pip install dobby-collector openai`
2. Set env vars:
     DOBBY_API_KEY       = dsdk_...
     DOBBY_CONNECTOR_ID  = wc_...
     OPENAI_API_KEY      = sk-...

Run
---

    python examples/manual_api_real_agent.py

What it does
------------

1. Defines a fake "PII-leak risk" tool (calls a public allowed URL).
2. Wraps the agent body in `start_run` / `end_run` for the workload_run row.
3. Decorates the tool with `@track` for automatic span capture.
4. Wraps the LLM call in `span(kind="llm")` for fine-grained timing.
5. Calls a real OpenAI LLM (gpt-4o-mini) and gets a real answer.

Within ~30s the run lands in /{tenantId}/dashboard/workloads/runs. The
Dobby Policy Scanner auto-fires and produces verdicts against the
inherited policy cascade (Platform + Org + Tenant).
"""

import os
import sys
from typing import Final

import urllib.request

from dobby_collector import end_run, init, span, start_run, track, shutdown

try:
    from openai import OpenAI
except ImportError as e:
    sys.stderr.write(
        "\n❌ Missing openai package. Install with:\n"
        "   pip install openai\n\n"
        f"   (Underlying error: {e})\n"
    )
    sys.exit(1)


# ---------------------------------------------------------------------------
# 1. Initialize Dobby SDK
# ---------------------------------------------------------------------------

DOBBY_API_KEY: Final = os.environ.get("DOBBY_API_KEY") or "dsdk_REPLACE_ME"
DOBBY_CONNECTOR_ID: Final = os.environ.get("DOBBY_CONNECTOR_ID") or "wc_REPLACE_ME"

if "REPLACE_ME" in DOBBY_API_KEY or "REPLACE_ME" in DOBBY_CONNECTOR_ID:
    sys.stderr.write(
        "\n❌ DOBBY_API_KEY / DOBBY_CONNECTOR_ID not set.\n"
        "   Generate them at /dashboard/workloads/connect/python-sdk\n"
        "   then re-run with the env vars exported.\n\n"
    )
    sys.exit(1)

if not os.environ.get("OPENAI_API_KEY"):
    sys.stderr.write(
        "\n❌ OPENAI_API_KEY not set. The script makes a real OpenAI call.\n\n"
    )
    sys.exit(1)

init(
    api_key=DOBBY_API_KEY,
    connector_id=DOBBY_CONNECTOR_ID,
    framework="manual",  # Tag for telemetry — appears on UI as the framework chip
)

openai_client = OpenAI()


# ---------------------------------------------------------------------------
# 2. Define an instrumented tool
# ---------------------------------------------------------------------------
# The @track decorator captures: start time, end time, status (success/error),
# exception traceback if raised, inputs (function args), outputs (return value).
# `kind="tool"` is the policy-scanner-relevant category.

@track(name="fetch_url_metadata", kind="tool")
def fetch_url_metadata(url: str) -> dict:
    """Fetch the first 500 bytes of a URL and return shape info.

    Realistic example of a "tool call" that the customer's agent might
    make — fetches from a public URL (which the Dobby policy scanner
    will evaluate against any allowlist rules).
    """
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=5) as resp:
        body = resp.read(500)
        return {
            "url": url,
            "status_code": resp.status,
            "content_type": resp.headers.get("Content-Type"),
            "first_bytes": len(body),
        }


# ---------------------------------------------------------------------------
# 3. Agent body — wrapped in start_run/end_run
# ---------------------------------------------------------------------------

def run_agent(question: str) -> str:
    """Toy ReAct loop — call tool, summarize via LLM."""
    run = start_run(
        name="customer_demo_qa",
        inputs={"question": question},
    )
    try:
        # Use one tool to gather grounding data
        meta = fetch_url_metadata("https://en.wikipedia.org/wiki/Reykjav%C3%ADk")

        # Make a real LLM call inside a span so timing is captured separately.
        # `span()` is a context manager that yields None — emit start on enter,
        # end on exit. The `inputs` argument is captured at start; the LLM
        # output is captured via end_run's outputs below.
        with span(
            name="summarize_reykjavik",
            kind="llm",
            inputs={"model": "gpt-4o-mini", "prompt_chars": len(question)},
        ):
            chat = openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "Answer concisely."},
                    {
                        "role": "user",
                        "content": (
                            f"{question}\n\n"
                            f"(I just fetched the Wikipedia page; it returned "
                            f"{meta['status_code']} with type {meta['content_type']}.)"
                        ),
                    },
                ],
                max_tokens=200,
            )
            answer = chat.choices[0].message.content
            tokens_used = chat.usage.total_tokens

        end_run(
            run,
            outputs={"answer": answer, "tokens_used": tokens_used},
            status="success",
        )
        return answer

    except Exception as e:
        end_run(run, error=str(e), status="error")
        raise


# ---------------------------------------------------------------------------
# 4. Execute + flush
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("\n🤖 Running manual-API agent demo...\n")
    try:
        answer = run_agent("What's the population of Reykjavik in one sentence?")
        print(f"\n✅ LLM answer:\n   {answer}\n")
    finally:
        shutdown(timeout_seconds=15.0)
        print(
            "[dobby] events flushed. Check the UI:\n"
            f"  https://dobby-ai.com/{os.environ.get('DOBBY_TENANT_ID', '{tenantId}')}/dashboard/workloads/runs\n"
        )


# ---------------------------------------------------------------------------
# WHAT TO CHECK IN THE UI
# ---------------------------------------------------------------------------
# Within ~60s of running this script:
#
# 1. /{tenantId}/dashboard/workloads/runs
#    Click "customer_demo_qa" row → drawer opens showing:
#      • Inputs: { question: "..." }
#      • Outputs: { answer: "..." }
#      • Status: success
#      • Spans tree: fetch_url_metadata + summarize_reykjavik
#
# 2. /{tenantId}/dashboard/compliance/scans
#    The newest scan row (auto-fired on workload_run insert) shows:
#      • overall_status: compliant / partial / violated / unverifiable
#      • N policies evaluated = 3 Platform + Org policies + Tenant policies
#      • Click → see per-policy verdict + evidence excerpt
#
# 3. /{tenantId}/dashboard/policies?layer=tenant
#    The "Policy Summary" AI card refreshes within 60s — the
#    source_policy_count stays the same (you didn't change policies),
#    but the "Last analyzed" timestamp tells you the scanner consumed
#    this run's evidence.
#
# TROUBLESHOOTING — same as langchain_real_agent.py.
