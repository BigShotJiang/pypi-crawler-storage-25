#!/usr/bin/env python3
"""
Real AutoGen agent → Dobby (auto-instrumented via DobbyAutoGenLogHandler)
==========================================================================

Complete runnable example — REAL AutoGen agent that calls a REAL LLM
(OpenAI gpt-4o-mini) and runs a REAL tool, with every LLM call / tool
call / message dispatch captured automatically by Dobby via the stdlib
`logging` integration AutoGen uses for telemetry.

AutoGen differs from LangChain + CrewAI: it doesn't have a callback
class — instead it routes all events through a Python logger
(`autogen_core.events`). The Dobby integration is a `logging.Handler`
subclass that subscribes to that logger.

Prereqs
-------

1. `pip install dobby-collector[autogen] autogen-agentchat autogen-ext[openai]`
2. Set env vars:
     DOBBY_API_KEY       = dsdk_...   (from wizard step 2)
     DOBBY_CONNECTOR_ID  = wc_...     (from wizard step 2)
     OPENAI_API_KEY      = sk-...

Run
---

    python examples/autogen_real_agent.py

What it does
------------

1. Wraps everything in `start_run` / `end_run` (AutoGen has no single
   "kickoff" event so we manage the run boundary ourselves).
2. Builds an AssistantAgent with one custom tool (Python function).
3. Sends a question, lets the agent reason + call the tool.
4. Every LLM call + tool invocation fires through autogen_core's event
   logger → captured by DobbyAutoGenLogHandler → SdkEvent → Dobby.

Within ~30s the run lands in /{tenantId}/dashboard/workloads/runs with
the LLM + tool spans visible in the drawer.
"""

import asyncio
import logging
import os
import sys
from typing import Final

# --- Dobby SDK + handler init (BEFORE autogen imports) ---
from dobby_collector import end_run, init, shutdown, start_run

DOBBY_API_KEY: Final = os.environ.get("DOBBY_API_KEY") or "dsdk_REPLACE_ME"
DOBBY_CONNECTOR_ID: Final = os.environ.get("DOBBY_CONNECTOR_ID") or "wc_REPLACE_ME"

if "REPLACE_ME" in DOBBY_API_KEY or "REPLACE_ME" in DOBBY_CONNECTOR_ID:
    sys.stderr.write(
        "\n❌ DOBBY_API_KEY / DOBBY_CONNECTOR_ID not set. Mint them at "
        "/dashboard/workloads/connect/python-sdk then re-run.\n\n"
    )
    sys.exit(1)

if not os.environ.get("OPENAI_API_KEY"):
    sys.stderr.write("\n❌ OPENAI_API_KEY not set — AutoGen uses OpenAI by default.\n\n")
    sys.exit(1)

init(api_key=DOBBY_API_KEY, connector_id=DOBBY_CONNECTOR_ID, framework="autogen")

# --- Attach Dobby handler to AutoGen's event logger ---
try:
    from autogen_core import EVENT_LOGGER_NAME
    from autogen_agentchat.agents import AssistantAgent
    from autogen_agentchat.messages import TextMessage
    from autogen_core import CancellationToken
    from autogen_ext.models.openai import OpenAIChatCompletionClient
except ImportError as e:
    sys.stderr.write(
        "\n❌ Missing AutoGen dependencies. Install with:\n"
        "   pip install dobby-collector[autogen] autogen-agentchat autogen-ext[openai]\n\n"
        f"   (Underlying error: {e})\n"
    )
    sys.exit(1)

from dobby_collector.integrations.autogen import DobbyAutoGenLogHandler

autogen_logger = logging.getLogger(EVENT_LOGGER_NAME)
autogen_logger.addHandler(DobbyAutoGenLogHandler())
autogen_logger.setLevel(logging.DEBUG)


# --- Build a real AutoGen agent with a custom tool ---

def calculate_population_density(population: int, area_km2: float) -> float:
    """Calculate population density in people per km²."""
    return round(population / area_km2, 2)


async def run_agent() -> str:
    """Run the agent + capture telemetry under one Dobby workload_run."""
    run = start_run(
        name="autogen_population_query",
        inputs={"question": "Reykjavik population density"},
    )
    try:
        model_client = OpenAIChatCompletionClient(model="gpt-4o-mini")

        assistant = AssistantAgent(
            name="researcher",
            model_client=model_client,
            tools=[calculate_population_density],
            system_message=(
                "You're a research assistant. When the user asks for population "
                "density, call the calculate_population_density tool to get the "
                "result. Use the tool's actual output in your reply."
            ),
        )

        user_message = TextMessage(
            content=(
                "What's the population density of Reykjavik, Iceland? "
                "Use 140000 for population and 273 km² for area."
            ),
            source="user",
        )

        response = await assistant.on_messages(
            [user_message], cancellation_token=CancellationToken()
        )

        answer = response.chat_message.content if response.chat_message else "(no reply)"
        end_run(run, outputs={"answer": answer}, status="success")
        return answer

    except Exception as e:
        end_run(run, error=str(e), status="error")
        raise
    finally:
        # Close the model client (releases HTTP connection pool)
        try:
            await model_client.close()
        except Exception:
            pass


if __name__ == "__main__":
    print("\n🤖 Running AutoGen agent demo...\n")
    try:
        answer = asyncio.run(run_agent())
        print(f"\n✅ Agent answer:\n   {answer}\n")
    finally:
        shutdown(timeout_seconds=15.0)
        print(
            "[dobby] events flushed. Check the UI:\n"
            f"  https://dobby-ai.com/{os.environ.get('DOBBY_TENANT_ID', '{tenantId}')}/dashboard/workloads/runs\n"
        )


# ---------------------------------------------------------------------------
# WHAT TO CHECK IN THE UI
# ---------------------------------------------------------------------------
#
# 1. /{tenantId}/dashboard/workloads/runs
#    Click the new "autogen_population_query" row → drawer with:
#      • Inputs: { question: "Reykjavik population density" }
#      • Outputs: { answer: "..." } — the LLM-generated reply
#      • Spans tree:
#          run.started (Dobby start_run)
#          ├── llm.end (gpt-4o-mini call w/ messages + response + tokens)
#          ├── tool.end: calculate_population_density (w/ arguments + result)
#          ├── llm.end (second LLM call to interpret tool result)
#          └── run.completed (Dobby end_run)
#      • framework: "autogen"
#      • Status: success
#
# 2. /{tenantId}/dashboard/compliance/scans
#    Same as the LangChain + CrewAI examples — scan auto-fires.
#
# TROUBLESHOOTING — same as the LangChain example.
#
# AutoGen-specific gotchas:
#   - autogen-core>=0.4 required (event logger pattern stabilized in v0.4)
#   - DobbyAutoGenLogHandler must be attached AFTER init() but BEFORE
#     the first autogen call. Attach once at process start.
#   - Multi-process AutoGen runtimes — the event logger is per-process,
#     so attach the handler in each process.
#   - AutoGen's LLMCallEvent + ToolCallEvent are AFTER-THE-FACT events
#     (no separate "start" event), so Dobby emits only ".end"-style
#     events for those — there's no separate llm.start unless you use
#     the streaming LLM client (LLMStreamStartEvent / LLMStreamEndEvent).
