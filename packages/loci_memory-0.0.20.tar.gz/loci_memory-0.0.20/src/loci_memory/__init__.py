#   Import main from the main script file
#from .loci import main

#__all__ = ["main"]
#
#   Not used, main is being reference directly on pyproject.toml
#