BUILD_SHA = "github.com/bihua-university/bhu-cli@00d0edf107ca"
