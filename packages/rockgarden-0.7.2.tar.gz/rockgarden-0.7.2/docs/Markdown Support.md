---
tags: [markdown, reference]
---

# Markdown Syntax Support

Rockgarden supports the superset of CommonMark, GFM (GitHub Flavored Markdown), and Obsidian markdown. No configuration needed — all syntax is handled gracefully.

## CommonMark (Base Markdown)

| Feature           | Syntax                     | Status |
| ----------------- | -------------------------- | ------ |
| Headings          | `# H1` through `###### H6` | ✅     |
| Paragraphs        | Plain text                 | ✅     |
| Line breaks       | Two spaces or `\` at end   | ✅     |
| Emphasis          | `*italic*` or `_italic_`   | ✅     |
| Strong            | `**bold**` or `__bold__`   | ✅     |
| Blockquotes       | `> quote`                  | ✅     |
| Lists (ordered)   | `1. item`                  | ✅     |
| Lists (unordered) | `- item` or `* item`       | ✅     |
| Code (inline)     | `` `code` ``               | ✅     |
| Code blocks       | ` ``` ` or indented        | ✅     |
| Horizontal rule   | `---` or `***`             | ✅     |
| Links             | `[text](url)`              | ✅     |
| Images            | `![alt](url)`              | ✅     |
| Autolinks         | `<http://url>`             | ✅     |
| HTML              | Raw HTML passthrough       | ✅     |

## GFM (GitHub Flavored Markdown)

| Feature             | Syntax                  | Status | Notes              |
| ------------------- | ----------------------- | ------ | ------------------ |
| Tables              | `\| col \| col \|`      | ✅     | Via markdown-it-py |
| Strikethrough       | `~~text~~`              | ✅     | Via markdown-it-py |
| Task lists          | `- [ ]` and `- [x]`     | ✅     | Via mdit-py-plugins |
| Autolinks           | Bare URLs               | ✅     | Via markdown-it-py |
| Syntax highlighting | ` ```python `           | ✅     | Via Pygments       |
| Footnotes           | `[^1]` and `[^1]: text` | ✅     | Via mdit-py-plugins |
| Alerts              | `> [!NOTE]`             | ✅     |                    |

## Obsidian Markdown

### Links & References

| Feature              | Syntax              | Status | Notes           |
| -------------------- | ------------------- | ------ | --------------- |
| Wiki-links           | `[[Page Name]]`     | ✅     |                 |
| Wiki-links (aliased) | `[[Page\|Display]]` | ✅     |                 |
| Heading links        | `[[Page#Heading]]`  | ✅     |                 |
| Block references     | `[[Page#^block]]`   | ❌     | Future          |

### Embeds

| Feature           | Syntax                     | Status | Notes      |
| ----------------- | -------------------------- | ------ | ---------- |
| Image embeds      | `![[image.png]]`           | ✅     |            |
| Image sizing      | `![[image.png\|200]]`      | ✅     |            |
| Image alt text    | `![[image.png\|alt text]]` | ✅     |            |
| Audio embeds      | `![[audio.mp3]]`           | ✅     |            |
| Video embeds      | `![[video.mp4]]`           | ✅     |            |
| PDF embeds        | `![[doc.pdf]]`             | ✅     |            |
| Note transclusion | `![[note]]`                | ✅     |            |

### Formatting

| Feature       | Syntax             | Status | Notes                     |
| ------------- | ------------------ | ------ | ------------------------- |
| Highlights    | `==text==`         | ✅     | Renders as `<mark>`       |
| Comments      | `%% comment %%`    | ✅     | Stripped during build     |
| HTML comments | `<!-- comment -->` | ✅     | Standard markdown         |

### Callouts

| Feature              | Syntax            | Status | Notes      |
| -------------------- | ----------------- | ------ | ---------- |
| Basic callouts       | `> [!note]`       | ✅     |            |
| Custom titles        | `> [!note] Title` | ✅     |            |
| Collapsible (open)   | `> [!note]+`      | ✅     |            |
| Collapsible (closed) | `> [!note]-`      | ✅     |            |

### Math

Math syntax is always parsed. The default theme loads KaTeX from CDN for rendering. Set `math_cdn = false` under `[theme]` to provide KaTeX yourself via `_styles/` and `_scripts/`.

| Feature         | Syntax       | Status | Notes                        |
| --------------- | ------------ | ------ | ---------------------------- |
| Inline math     | `$E = mc^2$` | ✅     | Via mdit-py-plugins          |
| Block math      | `$$...$$`    | ✅     | Via mdit-py-plugins          |
| GFM math blocks | ` ```math `  | ✅     | Rendered as display math     |

### Diagrams

| Feature | Syntax         | Status | Notes              |
| ------- | -------------- | ------ | ------------------ |
| Mermaid | ` ```mermaid ` | ✅     | Via CDN, client-side rendering |

### Tags

| Feature          | Syntax               | Status | Notes                |
| ---------------- | -------------------- | ------ | -------------------- |
| Inline tags      | `#tag`               | ✅     | Extracted and rendered as links |
| Nested tags      | `#parent/child`      | ✅     | Hierarchical — parent tags auto-created |
| Frontmatter tags | `tags: [tag1, tag2]` | ✅     | Already parsed       |

### Metadata

| Feature          | Syntax        | Status | Notes                    |
| ---------------- | ------------- | ------ | ------------------------ |
| YAML frontmatter | `---` block   | ✅     | Fully parsed             |
| Inline fields    | `key:: value` | ❌     | Future (Dataview compat) |

## Icons

| Feature      | Syntax              | Status | Notes                  |
| ------------ | ------------------- | ------ | ---------------------- |
| Inline icons | `:lucide-map-pin:`  | ✅     | Lucide library bundled |

Insert Lucide icons inline using `:lucide-name:` syntax. Only resolved icons are replaced; unrecognized patterns are left as literal text. See [[Customization]] for template usage and custom icon overrides.

## Syntax Priority

When features overlap (rare), rockgarden handles them in this order:

1. **Obsidian-specific syntax** is preprocessed first (wiki-links, embeds, callouts, comments)
2. **Inline icons** are resolved and replaced with SVG
3. **GFM/CommonMark** is parsed by markdown-it-py
4. **HTML passthrough** for anything not matched

This ensures:

- Code blocks protect their contents from all processing
- Obsidian syntax works even if it conflicts with markdown edge cases
- Standard markdown always works

## Future Syntax Additions

- Block references: `[[page#^block]]`
- Inline fields: `key:: value` (Dataview compatibility)

### Not Planned

- Canvas files (`.canvas`): binary format, not markdown
- Dataview queries: requires runtime evaluation
- Plugin-specific syntax: too varied to support generically
