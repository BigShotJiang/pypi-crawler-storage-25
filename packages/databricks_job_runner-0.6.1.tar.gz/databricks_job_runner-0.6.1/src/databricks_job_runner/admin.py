"""Unity Catalog admin helpers exposed via :class:`Runner`.

These are thin wrappers around :mod:`databricks_job_runner.catalog` module
functions, grouped by object level so callers can write
``runner.catalog.list()``, ``runner.schema.create("foo.bar")``, etc.

The confirm-prompt logic for destructive ``delete`` operations lives here
(not in :mod:`catalog`) so the catalog functions themselves stay
side-effect-pure aside from the SDK call and ``print`` output.
"""

from __future__ import annotations

from databricks.sdk import WorkspaceClient

from databricks_job_runner import catalog


def _confirm(prompt: str) -> bool:
    """Ask *prompt* and return True iff the user answers ``y`` or ``yes``.

    Centralizes the y/N convention used by the three ``delete`` methods so
    a future change (e.g. accepting ``--yes`` env vars, or piping to a TTY
    check) only needs to touch one place.
    """
    answer = input(f"{prompt} [y/N] ").strip().lower()
    if answer in ("y", "yes"):
        return True
    print("Cancelled.")
    return False


class CatalogAdmin:
    """Catalog-level operations."""

    def __init__(self, ws: WorkspaceClient) -> None:
        self._ws = ws

    def list(self) -> None:
        """List all catalogs."""
        catalog.list_catalogs(self._ws)

    def get(self, name: str) -> None:
        """Show details for a catalog."""
        catalog.get_catalog(self._ws, name)

    def create(
        self,
        name: str,
        *,
        storage_root: str | None = None,
        comment: str | None = None,
    ) -> None:
        """Create a catalog."""
        catalog.create_catalog(
            self._ws, name, storage_root=storage_root, comment=comment
        )

    def delete(
        self,
        name: str,
        *,
        force: bool = False,
        confirm: bool = True,
    ) -> None:
        """Delete a catalog.  *force* cascades to all contents."""
        if confirm:
            msg = f"Delete catalog '{name}'"
            if force:
                msg += " and ALL contents (schemas, tables, volumes)"
            if not _confirm(f"{msg}?"):
                return
        catalog.delete_catalog(self._ws, name, force=force)


class SchemaAdmin:
    """Schema-level operations.  ``full_name`` is ``catalog.schema``."""

    def __init__(self, ws: WorkspaceClient) -> None:
        self._ws = ws

    def list(self, catalog_name: str) -> None:
        """List schemas in a catalog."""
        catalog.list_schemas(self._ws, catalog_name)

    def get(self, full_name: str) -> None:
        """Show details for a schema."""
        catalog.get_schema(self._ws, full_name)

    def create(self, full_name: str, *, comment: str | None = None) -> None:
        """Create a schema."""
        catalog.create_schema(self._ws, full_name, comment=comment)

    def delete(self, full_name: str, *, confirm: bool = True) -> None:
        """Delete a schema."""
        if confirm and not _confirm(f"Delete schema '{full_name}'?"):
            return
        catalog.delete_schema(self._ws, full_name)


class VolumeAdmin:
    """Volume-level operations.  ``full_name`` is ``catalog.schema.volume``."""

    def __init__(self, ws: WorkspaceClient) -> None:
        self._ws = ws

    def list(self, parent: str) -> None:
        """List volumes in a schema (*parent* is ``catalog.schema``)."""
        catalog.list_volumes(self._ws, parent)

    def get(self, full_name: str) -> None:
        """Show details for a volume."""
        catalog.get_volume(self._ws, full_name)

    def create(
        self,
        full_name: str,
        *,
        volume_type: str = "MANAGED",
        storage_location: str | None = None,
        comment: str | None = None,
    ) -> None:
        """Create a volume."""
        catalog.create_volume(
            self._ws,
            full_name,
            volume_type=volume_type,
            storage_location=storage_location,
            comment=comment,
        )

    def delete(self, full_name: str, *, confirm: bool = True) -> None:
        """Delete a volume."""
        if confirm and not _confirm(f"Delete volume '{full_name}'?"):
            return
        catalog.delete_volume(self._ws, full_name)
