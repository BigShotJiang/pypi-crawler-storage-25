"""Download files from Databricks UC Volumes."""

from __future__ import annotations

import shutil
from pathlib import Path

from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import DatabricksError

from databricks_job_runner._paths import ensure_volumes_prefix
from databricks_job_runner.errors import RunnerError


def download_file(
    ws: WorkspaceClient,
    remote_path: str,
    local_path: Path,
) -> None:
    """Download a single file from a UC Volume to a local path.

    Creates parent directories locally as needed.
    """
    remote_path = ensure_volumes_prefix(remote_path)
    local_path.parent.mkdir(parents=True, exist_ok=True)

    resp = ws.files.download(file_path=remote_path)
    with local_path.open("wb") as fh:
        shutil.copyfileobj(resp.contents, fh)

    print(f"  {remote_path} -> {local_path}")


def list_volume_files(
    ws: WorkspaceClient,
    volume_path: str,
) -> list[str]:
    """List files in a UC Volume directory.

    Returns a list of file paths (relative to volume_path).
    """
    volume_path = ensure_volumes_prefix(volume_path)

    try:
        entries = ws.files.list_directory_contents(directory_path=volume_path)
    except DatabricksError as exc:
        raise RunnerError(f"cannot list {volume_path}: {exc}") from exc

    paths: list[str] = []
    for entry in entries:
        name = entry.name or entry.path or ""
        suffix = "/" if entry.is_directory else ""
        paths.append(f"{name}{suffix}")

    return sorted(paths)
