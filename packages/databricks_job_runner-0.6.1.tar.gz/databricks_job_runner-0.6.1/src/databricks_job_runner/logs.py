"""Retrieve stdout/stderr and error traces from one-time job runs.

The Databricks Jobs API exposes output per **task** rather than per run:
``jobs.get_run()`` returns a parent :class:`Run` whose ``tasks`` list holds
one :class:`RunTask` per submitted task, each with its own ``run_id``.
``jobs.get_run_output()`` must be called with that task-level ``run_id``.
"""

from __future__ import annotations

from itertools import islice

from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import NotFound
from databricks.sdk.service.jobs import RunType

from databricks_job_runner.errors import RunnerError

# Default upper bound on how many SUBMIT_RUNs find_latest_run will scan.
# If the latest matching run isn't in the most recent few hundred, the
# caller is better served by passing an explicit run_id than by paging
# through thousands of unrelated runs.
_DEFAULT_FIND_LATEST_SCAN_LIMIT = 200


def find_latest_run(
    ws: WorkspaceClient,
    run_name_prefix: str,
    *,
    scan_limit: int = _DEFAULT_FIND_LATEST_SCAN_LIMIT,
) -> int:
    """Return the ``run_id`` of the most recent SUBMIT_RUN matching *prefix*.

    Runs are returned newest-first by the Jobs API, so the first match is
    the latest.  Scans at most *scan_limit* runs before giving up — pass
    a larger value (or ``None`` upstream) if you expect the match to be
    far back in history.  Raises :class:`RunnerError` if no matching run
    exists within the scan window.
    """
    for run in islice(
        ws.jobs.list_runs(run_type=RunType.SUBMIT_RUN, expand_tasks=False),
        scan_limit,
    ):
        if run.run_id is None:
            continue
        if (run.run_name or "").startswith(run_name_prefix):
            return run.run_id
    raise RunnerError(
        f"no SUBMIT_RUN matching '{run_name_prefix}*' found in the most "
        f"recent {scan_limit} runs.\n"
        "Submit a job first, or pass an explicit run_id."
    )


def get_run_logs(ws: WorkspaceClient, parent_run_id: int) -> None:
    """Print stdout/stderr, error, and trace for *parent_run_id*'s tasks.

    Resolves the parent run to its task-level ``run_id``(s) via
    ``jobs.get_run``, then fetches each task's output with
    ``jobs.get_run_output``.  Databricks caps output at 5 MB (tail) per task.
    Raises :class:`RunnerError` if the run doesn't exist or has no tasks.
    """
    try:
        parent = ws.jobs.get_run(parent_run_id)
    except NotFound as exc:
        raise RunnerError(
            f"run {parent_run_id} not found (runs older than 60 days are "
            "removed automatically)."
        ) from exc

    tasks = parent.tasks or []
    if not tasks:
        raise RunnerError(
            f"run {parent_run_id} has no tasks — nothing to fetch."
        )

    run_name = parent.run_name or f"run {parent_run_id}"
    run_state = parent.state.result_state if parent.state else None
    state_name = run_state.value if run_state else "UNKNOWN"
    page_url = parent.run_page_url or ""

    print(f"Run: {run_name}")
    print(f"  Parent run ID: {parent_run_id}")
    print(f"  Result state:  {state_name}")
    if page_url:
        print(f"  URL:           {page_url}")
    print("---")

    for task in tasks:
        task_run_id = task.run_id
        task_key = task.task_key or "(unnamed)"
        if task_run_id is None:
            print(f"Task {task_key}: no run_id, skipping.")
            continue

        print(f"Task: {task_key} (task run ID {task_run_id})")
        try:
            output = ws.jobs.get_run_output(task_run_id)
        except NotFound:
            print("  (no output available)")
            print()
            continue

        if output.error:
            print("  Error:")
            for line in output.error.splitlines():
                print(f"    {line}")
        if output.error_trace:
            print("  Trace:")
            for line in output.error_trace.splitlines():
                print(f"    {line}")

        if output.logs:
            truncated = " (truncated, showing last 5 MB)" if output.logs_truncated else ""
            print(f"  Logs{truncated}:")
            for line in output.logs.splitlines():
                print(f"    {line}")
        elif not output.error:
            print("  (no logs captured)")
        print()
