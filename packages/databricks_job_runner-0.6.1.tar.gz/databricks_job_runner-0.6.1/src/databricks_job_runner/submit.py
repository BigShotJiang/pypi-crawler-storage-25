"""Submit Python scripts as one-time Databricks job runs."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.jobs import (
    RunResultState,
    SparkPythonTask,
    SubmitTask,
)

from databricks_job_runner.compute import Compute
from databricks_job_runner.errors import RunnerError

# Remote filename the packaged bootstrap is uploaded as.  Underscored
# and prefixed so it does not collide with a project script name.
BOOTSTRAP_SCRIPT_NAME = "_dbxrunner_bootstrap.py"


def bootstrap_script_path() -> Path:
    """Local path to the packaged bootstrap script for upload."""
    return Path(__file__).with_name("bootstrap.py")


@dataclass(frozen=True)
class BootstrapConfig:
    """Inputs the bootstrap reads from the ``argv[1]`` JSON blob.

    The consumer owns these values (wheel coordinates, pinned closure,
    connector probe class); the runner only serializes and transports
    them.  ``to_blob`` produces the single positional argv token; the
    project ``KEY=VALUE`` params follow it.
    """

    wheel_volume_path: str
    pinned_closure: list[str]
    wheel_package: str
    console_script: str
    jvm_probe_class: str | None = None
    per_run_root: str | None = None
    smoke_imports: list[str] = field(default_factory=list)
    sweep_age_seconds: int | None = None
    lock_timeout_seconds: int | None = None
    stale_lock_seconds: int | None = None

    def to_blob(self) -> str:
        payload: dict[str, object] = {
            "wheel_volume_path": self.wheel_volume_path,
            "pinned_closure": list(self.pinned_closure),
            "wheel_package": self.wheel_package,
            "console_script": self.console_script,
        }
        if self.jvm_probe_class:
            payload["jvm_probe_class"] = self.jvm_probe_class
        if self.per_run_root:
            payload["per_run_root"] = self.per_run_root
        if self.smoke_imports:
            payload["smoke_imports"] = list(self.smoke_imports)
        if self.sweep_age_seconds is not None:
            payload["sweep_age_seconds"] = self.sweep_age_seconds
        if self.lock_timeout_seconds is not None:
            payload["lock_timeout_seconds"] = self.lock_timeout_seconds
        if self.stale_lock_seconds is not None:
            payload["stale_lock_seconds"] = self.stale_lock_seconds
        return json.dumps(payload)


def submit_job(
    ws: WorkspaceClient,
    *,
    compute: Compute,
    workspace_dir: str,
    script_name: str,
    run_name: str,
    params: list[str] | None = None,
    no_wait: bool = False,
    scripts_dir: str = "agent_modules",
    validate_compute: bool = True,
) -> int:
    """Submit a script as a one-shot Databricks job and optionally wait.

    *compute* is the backend strategy (classic cluster or serverless).  It
    validates its own readiness, decorates the :class:`SubmitTask` with
    the right fields, and provides the top-level ``environments`` list
    (``None`` on classic, a single-entry list on serverless).

    *validate_compute* defaults to ``True`` so a direct caller still gets
    the readiness check.  The :class:`Runner` validates compute once
    itself and passes ``False`` here to avoid a redundant second check.

    Returns the run ID.
    """
    if validate_compute:
        compute.validate(ws)

    remote_path = f"{workspace_dir}/{scripts_dir}/{script_name}"

    print("Submitting job")
    print(f"  Script:   {remote_path}")
    print(f"  Run name: {run_name}")
    print("---")

    task = SubmitTask(
        task_key="run_script",
        spark_python_task=SparkPythonTask(
            python_file=remote_path,
            parameters=params if params else None,
        ),
    )
    task = compute.decorate_task(task)

    waiter = ws.jobs.submit(
        run_name=run_name,
        tasks=[task],
        environments=compute.environments(),
    )

    run_id: int | None = waiter.run_id
    if run_id is None:
        raise RunnerError("Databricks did not return a run_id for the submitted job.")
    print(f"  Run ID:   {run_id}")

    if no_wait:
        print("\nJob submitted (--no-wait). Check status in the Databricks UI.")
        return run_id

    print("  Waiting for completion...")
    run = waiter.result()
    result_state = run.state.result_state if run.state else None
    state_name = result_state.value if result_state else "UNKNOWN"
    page_url = run.run_page_url or ""

    print(f"\n  Result:   {state_name}")
    if page_url:
        print(f"  URL:      {page_url}")

    if result_state != RunResultState.SUCCESS:
        raise RunnerError(f"Job finished with non-success state: {state_name}")

    print("\nJob complete.")
    return run_id


def submit_bootstrap_job(
    ws: WorkspaceClient,
    *,
    compute: Compute,
    workspace_dir: str,
    bootstrap: BootstrapConfig,
    run_name: str,
    project_params: list[str] | None = None,
    no_wait: bool = False,
    scripts_dir: str = "agent_modules",
    validate_compute: bool = True,
) -> int:
    """Submit the bootstrap as a ``SparkPythonTask``.

    The JSON config blob is passed as the first positional parameter and
    the project ``KEY=VALUE`` params follow.  No Python artifact is
    attached as a cluster or task library; the bootstrap installs the
    wheel from the Volume at run startup instead.
    """
    params = [bootstrap.to_blob(), *(project_params or [])]
    return submit_job(
        ws,
        compute=compute,
        workspace_dir=workspace_dir,
        script_name=BOOTSTRAP_SCRIPT_NAME,
        run_name=run_name,
        params=params,
        no_wait=no_wait,
        scripts_dir=scripts_dir,
        validate_compute=validate_compute,
    )
