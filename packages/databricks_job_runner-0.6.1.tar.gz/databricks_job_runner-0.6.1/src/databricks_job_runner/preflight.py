"""First-class preflight hooks for submit and validate.

A preflight is a callable that inspects the target compute before a run
is created and either passes or fails fast with actionable messages.
Both :meth:`Runner.submit` and :meth:`Runner.validate` invoke the same
ordered, fail-fast hook list, so a problem surfaces before a run is
submitted rather than as a mid-run error.

The mechanism lives here in the library.  The policy (which libraries
must be present, which Spark config is required) lives in the consuming
project, which supplies hooks via ``Runner(preflights=[...])``.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field

from databricks.sdk import WorkspaceClient

from databricks_job_runner.compute import Compute
from databricks_job_runner.errors import RunnerError
from databricks_job_runner.libraries import (
    DesiredLibrary,
    check_cluster_libraries,
    format_cluster_library_plan,
)


@dataclass(frozen=True)
class PreflightResult:
    """Outcome of a single preflight hook.

    *ok* is the gate: a falsy result aborts submit/validate before a run
    is created.  *messages* are operator-facing and must be specific
    enough to act on (name the missing connector, the drifted config
    key, etc.).
    """

    name: str
    ok: bool
    messages: tuple[str, ...] = field(default_factory=tuple)


# A preflight receives the workspace client, the target cluster id
# (``None`` on serverless), and the resolved compute strategy.
Preflight = Callable[[WorkspaceClient, str | None, Compute], PreflightResult]


def run_preflights(
    ws: WorkspaceClient,
    cluster_id: str | None,
    compute: Compute,
    preflights: list[Preflight],
) -> None:
    """Run *preflights* in order, fail-fast on the first failure.

    Raises :class:`RunnerError` naming the failed hook and its messages.
    Hooks after the first failure are not run, so the operator fixes one
    clearly identified problem at a time.
    """
    if not preflights:
        return
    print("Running preflight checks")
    print("---")
    for preflight in preflights:
        result = preflight(ws, cluster_id, compute)
        if result.ok:
            print(f"  [ok]   {result.name}")
            continue
        print(f"  [fail] {result.name}")
        detail = "".join(f"    - {m}\n" for m in result.messages)
        raise RunnerError(
            f"preflight {result.name!r} failed:\n{detail}".rstrip()
        )
    print()


def maven_libraries_preflight(
    desired: list[DesiredLibrary],
    *,
    name: str = "maven libraries",
) -> Preflight:
    """Build a preflight that asserts a maven-only desired library list.

    Wraps :func:`check_cluster_libraries` and passes only when none of
    the desired libraries are missing, pending, or failed.  This is the
    "assert, do not reconcile" check: it never installs or uninstalls,
    it only reports.  The consumer supplies the maven coordinates as
    policy; the wrapping mechanism lives here.

    On serverless (no classic cluster) the check is reported as passed
    with a skip note, since maven cluster libraries are a classic-cluster
    concept and that path is rejected elsewhere for connector workloads.
    """

    def _preflight(
        ws: WorkspaceClient,
        cluster_id: str | None,
        compute: Compute,
    ) -> PreflightResult:
        if cluster_id is None:
            return PreflightResult(
                name=name,
                ok=True,
                messages=("skipped: no classic cluster for maven libraries",),
            )
        plan = check_cluster_libraries(ws, cluster_id, desired)
        if not (plan.missing or plan.pending or plan.failed):
            return PreflightResult(name=name, ok=True)
        messages: list[str] = []
        for item in plan.missing:
            messages.append(f"missing: {item.label}")
        for issue in plan.pending:
            messages.append(f"pending: {issue.label}")
        for issue in plan.failed:
            label = issue.label
            if issue.messages:
                label = f"{label}: {'; '.join(issue.messages)}"
            messages.append(f"failed: {label}")
        messages.append("")
        messages.append(format_cluster_library_plan(plan))
        return PreflightResult(
            name=name,
            ok=False,
            messages=tuple(messages),
        )

    return _preflight
