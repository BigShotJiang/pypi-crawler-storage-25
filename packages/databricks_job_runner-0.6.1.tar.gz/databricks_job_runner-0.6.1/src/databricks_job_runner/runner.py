"""Runner: orchestration for upload, submit, validate, logs, and clean operations.

Each project creates a :class:`Runner` instance with its config, then
calls :meth:`Runner.main` to dispatch CLI subcommands.  The Runner's
orchestration methods (``upload_file``, ``submit``, ``validate``,
``logs``, ``clean``, etc.) are also callable directly as a library API.

All non-core ``.env`` keys are automatically passed to submitted jobs as
``KEY=VALUE`` parameters.  Scripts call :func:`inject_params` at startup
to load them into ``os.environ``, then use pydantic ``BaseSettings`` to
read configuration.

Example usage in a consuming project::

    # cli/__init__.py
    from databricks_job_runner import Runner

    runner = Runner(
        run_name_prefix="graph_validation",
        wheel_package="augmentation_agent",  # optional
    )

    # cli/__main__.py
    from . import runner
    runner.main()

Then invoke as::

    python -m cli upload --all
    python -m cli submit test_hello.py
    python -m cli clean --yes
"""

from __future__ import annotations

from pathlib import Path

from databricks.sdk import WorkspaceClient

from databricks_job_runner.admin import CatalogAdmin, SchemaAdmin, VolumeAdmin
from databricks_job_runner.clean import clean_runs, clean_workspace
from databricks_job_runner.compute import ClassicCluster, Compute, Serverless
from databricks_job_runner.config import RunnerConfig, make_client
from databricks_job_runner.download import download_file, list_volume_files
from databricks_job_runner.errors import RunnerError
from databricks_job_runner.logs import find_latest_run, get_run_logs
from databricks_job_runner.preflight import Preflight, run_preflights
from databricks_job_runner.submit import (
    BootstrapConfig,
    submit_bootstrap_job,
    submit_job,
)
from databricks_job_runner.upload import (
    ensure_remote_dirs,
    publish_wheel_stable,
    upload_agent_modules,
    upload_bootstrap_script,
    upload_data_to_volume,
    upload_file,
)
from databricks_job_runner.validate import check_file_exists, list_workspace


class Runner:
    """Reusable Databricks job runner configured per-project.

    All non-core ``.env`` keys are automatically passed to submitted jobs
    as ``KEY=VALUE`` parameters.  No callback needed.

    Unity Catalog admin operations are grouped under three properties:
    :attr:`catalog`, :attr:`schema`, and :attr:`volume`, each backed by a
    helper from :mod:`databricks_job_runner.admin`.  Use
    ``runner.catalog.list()``, ``runner.schema.create("cat.sch")``, etc.

    Args:
        run_name_prefix: Prefix for job run names (e.g. ``"graph_validation"``).
            Also used to filter runs during cleanup (matches ``"prefix:"``).
        project_dir: Root directory of the consuming project (where ``.env``
            and the scripts directory live).  Defaults to the caller's working
            directory.
        wheel_package: Optional package name for the wheel built and
            published by :meth:`publish_wheel_stable` (e.g.
            ``"augmentation_agent"``).  Required for the bootstrap path;
            the stable wheel is written under
            ``<DATABRICKS_VOLUME_PATH>/wheels/``.
        secret_keys: Optional list of ``.env`` key names whose values should
            be stored in a Databricks secret scope instead of being passed as
            plaintext job parameters.  Requires ``DATABRICKS_SECRET_SCOPE``
            in ``.env``.  At runtime, :func:`inject_params` fetches them
            from the scope into ``os.environ``.
        scripts_dir: Name of the local subdirectory containing scripts to
            upload and submit (default: ``"agent_modules"``).  Change this
            to match your project layout, e.g. ``"scripts"``.
        remote_scripts_dir: Remote workspace subdirectory for uploaded scripts.
            Defaults to *scripts_dir* so existing projects keep the same local
            and remote layout.
        extra_files: Optional list of file paths relative to *project_dir*
            that should be uploaded into the remote scripts directory
            alongside the Python scripts.  Use this for non-Python assets
            that job scripts read via ``Path(__file__).parent`` on the
            cluster (e.g. ``["sql/gold_schema.sql"]``).
        cli_command: Command string printed in "Next steps" hints after a job
            is submitted (e.g. ``"uv run myproject"`` or
            ``"uv run python -m cli"``).  Defaults to ``"uv run python -m cli"``
            for backward compatibility.
        preflights: Optional ordered list of preflight hooks.  Both
            :meth:`submit` and :meth:`validate` invoke this same list,
            fail-fast, before a run is created.  Each hook receives
            ``(ws, cluster_id, compute)`` and returns a
            :class:`PreflightResult`.  The mechanism lives in this
            library; the policy (which libraries or config to assert)
            is supplied by the consumer.
    """

    DEFAULT_DATA_DIR = "data"

    def __init__(
        self,
        run_name_prefix: str,
        project_dir: Path | str | None = None,
        wheel_package: str | None = None,
        secret_keys: list[str] | None = None,
        scripts_dir: str = "agent_modules",
        remote_scripts_dir: str | None = None,
        extra_files: list[str] | None = None,
        cli_command: str = "uv run python -m cli",
        preflights: list[Preflight] | None = None,
    ) -> None:
        self.run_name_prefix = run_name_prefix
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()
        self.wheel_package = wheel_package
        self.secret_keys = secret_keys
        self.scripts_dir = scripts_dir
        self.remote_scripts_dir = remote_scripts_dir or scripts_dir
        self.extra_files = extra_files or []
        self.cli_command = cli_command
        self.preflights = preflights or []

        # Lazy-initialized
        self._config: RunnerConfig | None = None
        self._ws: WorkspaceClient | None = None
        self._catalog: CatalogAdmin | None = None
        self._schema: SchemaAdmin | None = None
        self._volume: VolumeAdmin | None = None

    # -- Properties (lazy) ---------------------------------------------------

    @property
    def config(self) -> RunnerConfig:
        """Parsed ``.env`` values as a typed :class:`RunnerConfig`."""
        if self._config is None:
            self._config = RunnerConfig.from_env_file(self.project_dir / ".env")
        return self._config

    @property
    def ws(self) -> WorkspaceClient:
        """Databricks workspace client.  Created once on first access.

        Uses ``DATABRICKS_PROFILE`` when set; otherwise falls back to the
        SDK's unified auth (env vars, Azure CLI, etc.).
        """
        if self._ws is None:
            self._ws = make_client(self.config.databricks_profile)
        return self._ws

    @property
    def agent_modules_dir(self) -> Path:
        return self.project_dir / self.scripts_dir

    @property
    def wheel_volume_dir(self) -> str:
        vol = self.config.databricks_volume_path
        return f"{vol}/wheels" if vol else ""

    @property
    def catalog(self) -> CatalogAdmin:
        """Unity Catalog catalog-level admin helper.

        Lazily constructed.  Reuses :attr:`ws`, so accessing this also
        triggers :class:`WorkspaceClient` initialization.
        """
        if self._catalog is None:
            self._catalog = CatalogAdmin(self.ws)
        return self._catalog

    @property
    def schema(self) -> SchemaAdmin:
        """Unity Catalog schema-level admin helper."""
        if self._schema is None:
            self._schema = SchemaAdmin(self.ws)
        return self._schema

    @property
    def volume(self) -> VolumeAdmin:
        """Unity Catalog volume-level admin helper."""
        if self._volume is None:
            self._volume = VolumeAdmin(self.ws)
        return self._volume

    # -- Public helpers ------------------------------------------------------

    def _compute(self, mode_override: str | None = None) -> Compute:
        """Build the :class:`Compute` strategy from config.

        Args:
            mode_override: When set (``"cluster"`` or ``"serverless"``),
                overrides ``DATABRICKS_COMPUTE_MODE`` from ``.env``.
        """
        mode = mode_override or self.config.databricks_compute_mode
        if mode == "serverless":
            return Serverless(
                environment_version=self.config.databricks_serverless_env_version,
            )
        if not self.config.databricks_cluster_id:
            raise RunnerError(
                "DATABRICKS_CLUSTER_ID must be set in .env to use cluster compute."
            )
        return ClassicCluster(cluster_id=self.config.databricks_cluster_id)

    @staticmethod
    def _preflight_cluster_id(compute: Compute) -> str | None:
        """Cluster id for the preflight contract, from the resolved compute.

        The preflight hook receives the cluster id of the backend the run
        will actually use, not the configured value, so a serverless mode
        override correctly passes ``None`` and cluster-only hooks skip.
        """
        if isinstance(compute, ClassicCluster):
            return compute.cluster_id
        return None

    # -- Orchestration methods ----------------------------------------------

    def upload_file(self, filename: str) -> None:
        """Upload a single file from ``agent_modules/`` to the workspace."""
        local_path = self.agent_modules_dir / filename
        if not local_path.exists():
            raise RunnerError(f"{local_path} not found")
        workspace_dir = self.config.databricks_workspace_dir
        ensure_remote_dirs(self.ws, workspace_dir, self.remote_scripts_dir)
        print(f"Uploading to {workspace_dir}/{self.remote_scripts_dir}")
        print("---")
        upload_file(
            self.ws,
            local_path,
            f"{workspace_dir}/{self.remote_scripts_dir}/{local_path.name}",
        )
        print()
        print("Upload complete.")

    def upload_all(self) -> None:
        """Upload all ``{scripts_dir}/*.py`` files to the workspace, plus any extra files."""
        workspace_dir = self.config.databricks_workspace_dir
        print(f"Uploading all {self.scripts_dir}/ to {workspace_dir}/{self.remote_scripts_dir}")
        print("---")
        extra: list[tuple[Path, str]] = [
            (self.project_dir / rel, Path(rel).name) for rel in self.extra_files
        ]
        upload_agent_modules(
            self.ws, self.agent_modules_dir, workspace_dir, self.remote_scripts_dir,
            extra_files=extra if extra else None,
        )
        upload_bootstrap_script(self.ws, workspace_dir, self.remote_scripts_dir)
        print()
        print("Upload complete.")

    def publish_wheel_stable(self) -> str:
        """Build a versioned wheel and publish it to a fixed Volume path.

        Does not bump the patch version, does not prune old Volume wheels,
        and does not touch cluster libraries.  Returns the Volume destination
        path.  Pair this with :meth:`submit_bootstrap`.
        """
        if not self.wheel_package:
            raise RunnerError("wheel_package not configured for this runner.")
        print(f"Publishing stable wheel to {self.wheel_volume_dir}")
        print("---")
        dest = publish_wheel_stable(
            self.ws, self.project_dir, self.wheel_volume_dir, self.wheel_package
        )
        print()
        print("Publish complete.")
        return dest

    def upload_data(self, source_dir: str = DEFAULT_DATA_DIR) -> None:
        """Upload a local data directory to the UC Volume.

        Uploads ``{project_dir}/{source_dir}/`` to
        ``{DATABRICKS_VOLUME_PATH}/``, preserving the subdirectory
        structure.
        """
        vol = self.config.databricks_volume_path
        if not vol:
            raise RunnerError(
                "volume path not set in .env — cannot determine upload path."
            )

        local_dir = self.project_dir / source_dir
        if not local_dir.is_dir():
            raise RunnerError(f"{local_dir} not found or is not a directory.")

        print(f"Uploading {source_dir}/ to {vol}")
        print("---")
        upload_data_to_volume(self.ws, local_dir, vol)
        print()
        print("Upload complete.")

    def download(self, remote_path: str, dest: str | None = None) -> None:
        """Download a file from the UC Volume to a local path.

        *remote_path* is relative to ``DATABRICKS_VOLUME_PATH`` unless it
        starts with ``/Volumes``.  When *dest* is ``None`` the file is
        saved to the current directory using the remote filename.
        """
        if not remote_path.startswith("/Volumes"):
            vol = self.config.databricks_volume_path
            if not vol:
                raise RunnerError(
                    "volume path not set in .env — cannot resolve relative path.\n"
                    "Use an absolute path starting with /Volumes or set "
                    "DATABRICKS_VOLUME_PATH in .env."
                )
            remote_path = f"{vol}/{remote_path}"

        filename = remote_path.rsplit("/", 1)[-1]
        local = Path(dest) if dest else Path.cwd() / filename

        print("Downloading from volume")
        print("---")
        download_file(self.ws, remote_path, local)
        print()
        print("Download complete.")

    def list_volume(self, subdir: str | None = None) -> None:
        """List files at the configured volume path (or a subdirectory)."""
        vol = self.config.databricks_volume_path
        if not vol:
            raise RunnerError(
                "volume path not set in .env — cannot list volume contents."
            )
        path = f"{vol}/{subdir}" if subdir else vol

        print(f"Listing: {path}")
        print("---")
        files = list_volume_files(self.ws, path)
        if not files:
            print("  (empty)")
        for f in files:
            print(f"  {f}")
        print()

    def submit(
        self, script: str, *, no_wait: bool = False, compute_mode: str | None = None,
    ) -> None:
        """Submit a script as a one-time Databricks job.

        Builds the compute strategy from ``DATABRICKS_COMPUTE_MODE`` (or
        the *compute_mode* override) and delegates readiness checks to it
        (classic starts the cluster if terminated; serverless is a no-op).
        Submits the script with no attached Python library; wheel-backed
        projects use the bootstrap path (:meth:`submit_bootstrap`).

        Args:
            script: Script name in ``agent_modules/``.
            no_wait: Submit without waiting for completion.
            compute_mode: Override the project-level compute mode
                (``"cluster"`` or ``"serverless"``).  When ``None``,
                uses ``DATABRICKS_COMPUTE_MODE`` from ``.env``.
        """
        params = self.config.env_params(secret_keys=self.secret_keys)
        run_name = f"{self.run_name_prefix}: {script}"

        if params:
            print(f"  Params:   {len(params)} env values from .env")

        compute = self._compute(compute_mode)
        compute.validate(self.ws)
        if self.preflights:
            run_preflights(
                self.ws,
                self._preflight_cluster_id(compute),
                compute,
                self.preflights,
            )
        run_id = submit_job(
            self.ws,
            compute=compute,
            workspace_dir=self.config.databricks_workspace_dir,
            script_name=script,
            run_name=run_name,
            params=params,
            no_wait=no_wait,
            scripts_dir=self.remote_scripts_dir,
            validate_compute=False,
        )

        print()
        print("Next steps:")
        print(f"  View logs:          {self.cli_command} logs {run_id}")
        if self.config.databricks_volume_path:
            print(f"  List results:       {self.cli_command} download --list results")
            print(f"  Download results:   {self.cli_command} download results/<filename>")

    def submit_bootstrap(
        self,
        bootstrap: BootstrapConfig,
        *,
        run_name_suffix: str = "bootstrap",
        no_wait: bool = False,
        compute_mode: str | None = None,
    ) -> None:
        """Submit the bootstrap as a ``SparkPythonTask``.

        Replaces the ``PythonWheelTask`` model for paths that install
        their wheel at run startup.  No Python artifact is attached as a
        cluster or task library; the bootstrap installs the project wheel
        from the stable Volume path into a per-run target instead.  The
        preflight hook list runs first, exactly as in :meth:`submit`.
        """
        params = self.config.env_params(secret_keys=self.secret_keys)
        run_name = f"{self.run_name_prefix}: {run_name_suffix}"
        if params:
            print(f"  Params:   {len(params)} env values from .env")

        compute = self._compute(compute_mode)
        compute.validate(self.ws)
        if self.preflights:
            run_preflights(
                self.ws,
                self._preflight_cluster_id(compute),
                compute,
                self.preflights,
            )
        run_id = submit_bootstrap_job(
            self.ws,
            compute=compute,
            workspace_dir=self.config.databricks_workspace_dir,
            bootstrap=bootstrap,
            run_name=run_name,
            project_params=params,
            no_wait=no_wait,
            scripts_dir=self.remote_scripts_dir,
            validate_compute=False,
        )

        print()
        print("Next steps:")
        print(f"  View logs:          {self.cli_command} logs {run_id}")

    def logs(self, run_id: int | None = None) -> None:
        """Print stdout/stderr and error trace for a submitted run.

        When *run_id* is ``None``, finds the most recent SUBMIT_RUN whose
        name starts with ``{run_name_prefix}:`` (matches the same filter
        used by ``clean --runs``).  Output comes from the Jobs API's
        ``get_run_output`` endpoint, which returns the tail 5 MB of
        stdout/stderr captured by Databricks.
        """
        if run_id is None:
            prefix = f"{self.run_name_prefix}:"
            print(f"Finding latest run matching '{prefix}*'...")
            run_id = find_latest_run(self.ws, prefix)
            print(f"  Found run {run_id}")
            print()
        get_run_logs(self.ws, run_id)

    def validate(self, file: str | None = None) -> None:
        """Check compute readiness, list remote workspace, verify a file.

        Runs the compute strategy's ``validate`` — on classic that
        auto-starts the cluster if it is not already RUNNING; on
        serverless it is a no-op.  If *file* is given, verifies it exists
        under the configured remote scripts directory and raises :class:`RunnerError` otherwise.
        """
        compute = self._compute()
        compute.validate(self.ws)
        if self.preflights:
            run_preflights(
                self.ws,
                self._preflight_cluster_id(compute),
                compute,
                self.preflights,
            )
        print()
        list_workspace(self.ws, self.config.databricks_workspace_dir, self.remote_scripts_dir)
        if file:
            check_file_exists(self.ws, self.config.databricks_workspace_dir, file, self.remote_scripts_dir)
        print()
        print("Validation complete.")

    def clean(
        self,
        *,
        workspace: bool = True,
        runs: bool = True,
        confirm: bool = True,
    ) -> None:
        """Delete the remote workspace directory and/or matching job runs."""
        print(f"{self.run_name_prefix}: cleanup")
        print("---")
        if workspace:
            print(
                f"  Workspace:  {self.config.databricks_workspace_dir} "
                f"(will be deleted recursively)"
            )
        if runs:
            print(
                f"  Job runs:   all one-time runs matching '{self.run_name_prefix}:*'"
            )
        print()

        if confirm:
            answer = input("Proceed? [y/N] ").strip().lower()
            if answer not in ("y", "yes"):
                print("Cancelled.")
                return
            print()

        if workspace:
            clean_workspace(self.ws, self.config.databricks_workspace_dir)
            print()
        if runs:
            clean_runs(self.ws, f"{self.run_name_prefix}:")
            print()

        print("Cleanup complete.")

    # -- Main CLI entry point ------------------------------------------------

    def main(self, argv: list[str] | None = None) -> None:
        """Parse args and dispatch to the appropriate orchestration method."""
        from databricks_job_runner.cli import run_cli

        run_cli(self, argv)
