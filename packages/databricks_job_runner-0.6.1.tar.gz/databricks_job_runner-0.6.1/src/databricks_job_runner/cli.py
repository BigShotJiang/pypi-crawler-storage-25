"""CLI argparse setup and dispatch for :class:`Runner`.

This module owns the command-line interface.  :class:`Runner` exposes
orchestration methods; this module translates argparse results into
calls on them, and formats :class:`RunnerError` into friendly CLI
output before exiting non-zero.
"""

from __future__ import annotations

import argparse
import sys
from typing import TYPE_CHECKING

from databricks_job_runner.errors import RunnerError

if TYPE_CHECKING:
    from databricks_job_runner.runner import Runner


def run_cli(runner: "Runner", argv: list[str] | None = None) -> None:
    """Parse *argv* and dispatch to the matching method on *runner*.

    Catches :class:`RunnerError` from orchestration methods and exits
    with code 1 after printing a friendly message to stderr.
    """
    try:
        _dispatch(runner, argv)
    except RunnerError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


def _dispatch(runner: "Runner", argv: list[str] | None) -> None:
    parser = _build_parser(runner)
    args = parser.parse_args(argv)

    if args.command == "upload":
        _dispatch_upload(runner, args)
    elif args.command == "download":
        _dispatch_download(runner, args)
    elif args.command == "submit":
        if args.upload:
            runner.upload_all()
        runner.submit(args.script, no_wait=args.no_wait, compute_mode=args.compute)
    elif args.command == "validate":
        runner.validate(args.file)
    elif args.command == "logs":
        runner.logs(args.run_id)
    elif args.command == "clean":
        # If neither flag is set, clean both
        if not args.workspace and not args.runs:
            do_workspace, do_runs = True, True
        else:
            do_workspace, do_runs = args.workspace, args.runs
        runner.clean(
            workspace=do_workspace,
            runs=do_runs,
            confirm=not args.yes,
        )
    elif args.command == "catalog":
        _dispatch_catalog(runner, args)
    elif args.command == "schema":
        _dispatch_schema(runner, args)
    elif args.command == "volume":
        _dispatch_volume(runner, args)


def _build_parser(runner: "Runner") -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=f"Databricks job runner ({runner.run_name_prefix})",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # -- upload --------------------------------------------------------------
    p_upload = sub.add_parser("upload", help="Upload scripts/wheels to Databricks")
    p_upload.add_argument(
        "file",
        nargs="?",
        default="test_hello.py",
        help=f"File in {runner.scripts_dir}/ to upload (default: test_hello.py)",
    )
    upload_mode = p_upload.add_mutually_exclusive_group()
    upload_mode.add_argument(
        "--all",
        action="store_true",
        help=f"Upload all {runner.scripts_dir}/*.py files",
    )
    upload_mode.add_argument(
        "--data",
        nargs="?",
        const=runner.DEFAULT_DATA_DIR,
        default=None,
        metavar="DIR",
        help=f"Upload a data directory to the UC volume (default: {runner.DEFAULT_DATA_DIR}/)",
    )

    # -- download ------------------------------------------------------------
    p_download = sub.add_parser(
        "download",
        help="Download files from a UC Volume",
    )
    p_download.add_argument(
        "path",
        nargs="?",
        default=None,
        help=(
            "Volume file path to download (relative to DATABRICKS_VOLUME_PATH, "
            "or absolute starting with /Volumes)"
        ),
    )
    p_download.add_argument(
        "--list",
        dest="list_files",
        nargs="?",
        const="",
        default=None,
        metavar="SUBDIR",
        help="List files at the volume path (optionally in a subdirectory)",
    )
    p_download.add_argument(
        "--dest",
        "-o",
        default=None,
        help="Local destination path (default: current directory)",
    )

    # -- submit --------------------------------------------------------------
    p_submit = sub.add_parser("submit", help="Submit a script as a Databricks job")
    p_submit.add_argument(
        "script",
        nargs="?",
        default="test_hello.py",
        help=f"Script name in {runner.scripts_dir}/ (default: test_hello.py)",
    )
    p_submit.add_argument(
        "--no-wait",
        action="store_true",
        help="Submit without waiting for completion",
    )
    p_submit.add_argument(
        "--compute",
        choices=["cluster", "serverless"],
        default=None,
        help="Override compute mode for this submission (default: from .env)",
    )
    p_submit.add_argument(
        "--upload",
        action="store_true",
        help=f"Upload all {runner.scripts_dir}/*.py files before submitting",
    )

    # -- validate ------------------------------------------------------------
    p_validate = sub.add_parser(
        "validate",
        help="List remote workspace contents and verify uploads",
    )
    p_validate.add_argument(
        "file",
        nargs="?",
        default=None,
        help=f"Optional {runner.scripts_dir}/ file to check for existence",
    )

    # -- logs ----------------------------------------------------------------
    p_logs = sub.add_parser(
        "logs",
        help="Print stdout/stderr from a submitted run",
    )
    p_logs.add_argument(
        "run_id",
        nargs="?",
        type=int,
        default=None,
        help=(
            "Parent run ID to fetch logs for. Defaults to the latest run "
            f"matching '{runner.run_name_prefix}:*'."
        ),
    )

    # -- clean ---------------------------------------------------------------
    p_clean = sub.add_parser("clean", help="Clean up remote workspace and job runs")
    p_clean.add_argument(
        "--workspace",
        action="store_true",
        help="Clean only remote workspace",
    )
    p_clean.add_argument(
        "--runs",
        action="store_true",
        help="Clean only job runs",
    )
    p_clean.add_argument(
        "--yes",
        "-y",
        action="store_true",
        help="Skip confirmation prompt",
    )

    # -- catalog -------------------------------------------------------------
    p_catalog = sub.add_parser("catalog", help="Manage Unity Catalog catalogs")
    cat_sub = p_catalog.add_subparsers(dest="action", required=True)

    cat_sub.add_parser("list", help="List catalogs")

    cat_get = cat_sub.add_parser("get", help="Get catalog details")
    cat_get.add_argument("name", help="Catalog name")

    cat_create = cat_sub.add_parser("create", help="Create a catalog")
    cat_create.add_argument("name", help="Catalog name")
    cat_create.add_argument(
        "--storage-root",
        help="Managed storage location URL for the catalog (e.g. abfss://container@account.dfs.core.windows.net/path)",
    )
    cat_create.add_argument("--comment", help="Catalog comment")

    cat_delete = cat_sub.add_parser("delete", help="Delete a catalog")
    cat_delete.add_argument("name", help="Catalog name")
    cat_delete.add_argument(
        "--yes", "-y", action="store_true", help="Skip confirmation prompt"
    )
    cat_delete.add_argument(
        "--force",
        action="store_true",
        help="Force delete (cascades to schemas, tables, and volumes)",
    )

    # -- schema --------------------------------------------------------------
    p_schema = sub.add_parser("schema", help="Manage Unity Catalog schemas")
    sch_sub = p_schema.add_subparsers(dest="action", required=True)

    sch_list = sch_sub.add_parser("list", help="List schemas in a catalog")
    sch_list.add_argument("catalog", help="Catalog name")

    sch_get = sch_sub.add_parser("get", help="Get schema details")
    sch_get.add_argument("name", help="Full name (catalog.schema)")

    sch_create = sch_sub.add_parser("create", help="Create a schema")
    sch_create.add_argument("name", help="Full name (catalog.schema)")
    sch_create.add_argument("--comment", help="Schema comment")

    sch_delete = sch_sub.add_parser("delete", help="Delete a schema")
    sch_delete.add_argument("name", help="Full name (catalog.schema)")
    sch_delete.add_argument(
        "--yes", "-y", action="store_true", help="Skip confirmation prompt"
    )

    # -- volume --------------------------------------------------------------
    p_volume = sub.add_parser("volume", help="Manage Unity Catalog volumes")
    vol_sub = p_volume.add_subparsers(dest="action", required=True)

    vol_list = vol_sub.add_parser("list", help="List volumes in a schema")
    vol_list.add_argument("parent", help="Parent schema (catalog.schema)")

    vol_get = vol_sub.add_parser("get", help="Get volume details")
    vol_get.add_argument("name", help="Full name (catalog.schema.volume)")

    vol_create = vol_sub.add_parser("create", help="Create a volume")
    vol_create.add_argument("name", help="Full name (catalog.schema.volume)")
    vol_create.add_argument(
        "--volume-type",
        choices=["MANAGED", "EXTERNAL"],
        default="MANAGED",
        help="Volume type (default: MANAGED)",
    )
    vol_create.add_argument(
        "--storage-location",
        help="External storage location (required for EXTERNAL volumes)",
    )
    vol_create.add_argument("--comment", help="Volume comment")

    vol_delete = vol_sub.add_parser("delete", help="Delete a volume")
    vol_delete.add_argument("name", help="Full name (catalog.schema.volume)")
    vol_delete.add_argument(
        "--yes", "-y", action="store_true", help="Skip confirmation prompt"
    )

    return parser


def _dispatch_upload(runner: "Runner", args: argparse.Namespace) -> None:
    if args.data is not None:
        runner.upload_data(args.data)
    elif args.all:
        runner.upload_all()
    else:
        runner.upload_file(args.file)


def _dispatch_download(runner: "Runner", args: argparse.Namespace) -> None:
    if args.list_files is not None:
        runner.list_volume(args.list_files or None)
    elif args.path:
        runner.download(args.path, dest=args.dest)
    else:
        # No path and no --list: list the root volume
        runner.list_volume()


def _dispatch_catalog(runner: "Runner", args: argparse.Namespace) -> None:
    if args.action == "list":
        runner.catalog.list()
    elif args.action == "get":
        runner.catalog.get(args.name)
    elif args.action == "create":
        runner.catalog.create(
            args.name, storage_root=args.storage_root, comment=args.comment
        )
    elif args.action == "delete":
        runner.catalog.delete(args.name, force=args.force, confirm=not args.yes)


def _dispatch_schema(runner: "Runner", args: argparse.Namespace) -> None:
    if args.action == "list":
        runner.schema.list(args.catalog)
    elif args.action == "get":
        runner.schema.get(args.name)
    elif args.action == "create":
        runner.schema.create(args.name, comment=args.comment)
    elif args.action == "delete":
        runner.schema.delete(args.name, confirm=not args.yes)


def _dispatch_volume(runner: "Runner", args: argparse.Namespace) -> None:
    if args.action == "list":
        runner.volume.list(args.parent)
    elif args.action == "get":
        runner.volume.get(args.name)
    elif args.action == "create":
        runner.volume.create(
            args.name,
            volume_type=args.volume_type,
            storage_location=args.storage_location,
            comment=args.comment,
        )
    elif args.action == "delete":
        runner.volume.delete(args.name, confirm=not args.yes)
