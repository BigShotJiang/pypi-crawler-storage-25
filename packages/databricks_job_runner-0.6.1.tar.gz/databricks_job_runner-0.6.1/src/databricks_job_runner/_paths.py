"""Shared path helpers for UC Volume operations."""

from __future__ import annotations


def ensure_volumes_prefix(path: str) -> str:
    """Prepend ``/Volumes`` if *path* doesn't already start with it.

    The Files API requires the ``/Volumes`` prefix; the Workspace API and
    user-facing config (``DATABRICKS_VOLUME_PATH``) typically omit it.
    """
    return path if path.startswith("/Volumes") else f"/Volumes{path}"
