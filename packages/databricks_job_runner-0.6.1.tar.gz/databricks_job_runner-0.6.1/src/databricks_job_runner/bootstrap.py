"""Generic run-startup bootstrap, submitted as a ``SparkPythonTask``.

This module is uploaded as a plain script and executed on the cluster
driver.  It depends only on the Python standard library, ``pip``, and
``pyspark`` (already on the cluster).  It must not import
``databricks_job_runner`` or any project package, so there is no
installer-installs-itself cycle and no pin on the runner version.

What it does, in order:

1. Parse a single JSON blob from ``argv[1]``; the project ``KEY=VALUE``
   params follow as the remaining argv tokens.
2. Sweep stale per-run target directories off local disk.
3. Install the project wheel from a stable Volume path into a fresh
   per-run target directory with ``--force-reinstall --no-deps``.
4. Install the pinned dependency closure into the shared driver
   environment with ``--no-deps``, serialized by a coarse ``fcntl``
   advisory lock keyed by a hash of the closure so overlapping cold
   first runs do not race.
5. Smoke-check the shared environment by importing caller-named modules.
6. Prepend the per-run target to ``sys.path``.
7. Probe the JVM classpath for a caller-supplied connector class via
   ``SparkSession.getOrCreate()`` and ``Class.forName``.
8. Rebuild ``sys.argv`` to exactly what the console entry point would
   have seen under ``PythonWheelTask`` (script name + project params,
   JSON blob removed).
9. Resolve the console entry point by its ``console_scripts`` name
   through ``importlib.metadata`` against the just-installed wheel and
   invoke it.  The bootstrap never calls ``inject_params``; the entry
   point owns its own parameter and secret-scope injection.

A one-line manifest is printed to the driver log so "did my new code
actually run" is answerable by inspecting one line.
"""

from __future__ import annotations

import contextlib
import email
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

_MANIFEST_PREFIX = "BOOTSTRAP_MANIFEST "

_DEFAULT_PER_RUN_ROOT_CANDIDATES = ("/local_disk0/tmp/dbxrunner",)
_DEFAULT_SWEEP_AGE_SECONDS = 24 * 60 * 60
_DEFAULT_LOCK_TIMEOUT_SECONDS = 600
_DEFAULT_STALE_LOCK_SECONDS = 1800
_LOCK_POLL_SECONDS = 2


@dataclass(frozen=True)
class Invocation:
    """Parsed bootstrap inputs from ``argv``.

    ``project_params`` is the verbatim tail of argv (the ``KEY=VALUE``
    tokens the console entry point expects); the bootstrap never parses
    or consumes them.
    """

    wheel_volume_path: str
    pinned_closure: tuple[str, ...]
    wheel_package: str
    console_script: str
    jvm_probe_class: str | None
    project_params: tuple[str, ...]
    per_run_root: str | None = None
    smoke_imports: tuple[str, ...] = field(default_factory=tuple)
    sweep_age_seconds: int = _DEFAULT_SWEEP_AGE_SECONDS
    lock_timeout_seconds: int = _DEFAULT_LOCK_TIMEOUT_SECONDS
    stale_lock_seconds: int = _DEFAULT_STALE_LOCK_SECONDS


def parse_invocation(argv: list[str]) -> Invocation:
    """Parse ``argv`` into an :class:`Invocation`.

    ``argv[0]`` is the script name, ``argv[1]`` is the JSON blob, and
    ``argv[2:]`` are the project ``KEY=VALUE`` params passed through
    untouched.
    """
    if len(argv) < 2:
        raise ValueError(
            "bootstrap requires a JSON config blob as argv[1]; "
            f"got argv={argv!r}"
        )
    try:
        blob = json.loads(argv[1])
    except json.JSONDecodeError as exc:
        raise ValueError(f"argv[1] is not valid JSON: {exc}") from exc
    if not isinstance(blob, dict):
        raise ValueError("argv[1] JSON must be an object")

    required = ("wheel_volume_path", "pinned_closure", "wheel_package",
                "console_script")
    missing = [k for k in required if k not in blob]
    if missing:
        raise ValueError(
            f"argv[1] JSON missing required keys: {', '.join(missing)}"
        )

    return Invocation(
        wheel_volume_path=str(blob["wheel_volume_path"]),
        pinned_closure=tuple(str(x) for x in blob["pinned_closure"]),
        wheel_package=str(blob["wheel_package"]),
        console_script=str(blob["console_script"]),
        jvm_probe_class=(
            str(blob["jvm_probe_class"]) if blob.get("jvm_probe_class") else None
        ),
        project_params=tuple(argv[2:]),
        per_run_root=(
            str(blob["per_run_root"]) if blob.get("per_run_root") else None
        ),
        smoke_imports=tuple(str(x) for x in blob.get("smoke_imports", ())),
        sweep_age_seconds=int(
            blob.get("sweep_age_seconds", _DEFAULT_SWEEP_AGE_SECONDS)
        ),
        lock_timeout_seconds=int(
            blob.get("lock_timeout_seconds", _DEFAULT_LOCK_TIMEOUT_SECONDS)
        ),
        stale_lock_seconds=int(
            blob.get("stale_lock_seconds", _DEFAULT_STALE_LOCK_SECONDS)
        ),
    )


def run_token() -> str:
    """A unique-per-run token used to isolate per-run install targets.

    Overlapping runs are separate driver processes, so a token built
    from the Databricks run id when present, falling back to time, pid,
    and a random suffix, is sufficient for the isolation guarantee:
    each run loads its own copy of the project code.
    """
    run_id = os.environ.get("DATABRICKS_RUN_ID")
    if run_id:
        return f"run-{run_id}"
    return f"t-{int(time.time())}-{os.getpid()}-{uuid.uuid4().hex[:8]}"


def resolve_per_run_root(requested: str | None) -> Path:
    """Resolve the local-disk root for per-run target directories."""
    if requested:
        return Path(requested)
    for candidate in _DEFAULT_PER_RUN_ROOT_CANDIDATES:
        parent = Path(candidate).parent
        if parent.exists():
            return Path(candidate)
    return Path(tempfile.gettempdir()) / "dbxrunner"


def select_sweep_targets(
    runs_dir: Path,
    *,
    now: float,
    age_seconds: int,
    keep: str,
) -> list[Path]:
    """Per-run subdirs older than *age_seconds*, never the active *keep*.

    Pure for unit testing.  Filesystem mutation is done by the caller.
    """
    if not runs_dir.is_dir():
        return []
    stale: list[Path] = []
    for entry in sorted(runs_dir.iterdir()):
        if not entry.is_dir() or entry.name == keep:
            continue
        try:
            mtime = entry.stat().st_mtime
        except OSError:
            continue
        if now - mtime > age_seconds:
            stale.append(entry)
    return stale


def closure_hash(pinned_closure: tuple[str, ...]) -> str:
    """Stable hash of the pinned closure, order-independent.

    Keys the shared-environment install lock so concurrent runs with the
    same closure serialize, while a changed closure uses a new lock.
    """
    joined = "\n".join(sorted(pinned_closure))
    return hashlib.sha256(joined.encode("utf-8")).hexdigest()[:16]


def _normalize_dist_name(name: str) -> str:
    out = []
    prev_sep = False
    for ch in name:
        if ch in "-_.":
            if not prev_sep:
                out.append("_")
            prev_sep = True
        else:
            out.append(ch)
            prev_sep = False
    return "".join(out)


def wheel_filename_from_metadata(wheel_path: Path) -> str:
    """Derive a PEP 427 wheel filename from the wheel's own METADATA.

    The stable Volume copy is written under a fixed destination name,
    which is not a valid wheel filename, and pip rejects wheels whose
    filename does not parse.  The project wheel is pure Python
    (``py3-none-any``), so reconstructing the filename from the
    ``Name`` and ``Version`` in ``*.dist-info/METADATA`` is sufficient
    for the per-run ``--no-deps`` install.
    """
    with zipfile.ZipFile(wheel_path) as zf:
        meta_names = sorted(
            (n for n in zf.namelist()
             if n.endswith(".dist-info/METADATA")),
            key=len,
        )
        if not meta_names:
            raise ValueError(
                f"{wheel_path} has no .dist-info/METADATA; not a wheel"
            )
        raw = zf.read(meta_names[0]).decode("utf-8", "replace")
    msg = email.message_from_string(raw)
    name = msg.get("Name")
    version = msg.get("Version")
    if not name or not version:
        raise ValueError(
            f"{wheel_path} METADATA missing Name/Version"
        )
    return f"{_normalize_dist_name(name)}-{version}-py3-none-any.whl"


def rebuild_argv(script: str, project_params: tuple[str, ...]) -> list[str]:
    """The argv the console entry point would have seen under wheel task.

    Script name followed by the project params, with the JSON blob
    removed.
    """
    return [script, *project_params]


def _pip_install(args: list[str]) -> None:
    # Inherit stdout/stderr so pip progress streams into the driver log
    # live.  A cold closure install is slow; capturing it would leave the
    # log silent until it finished or failed.
    cmd = [sys.executable, "-m", "pip", "install", *args]
    print(f"  pip: {' '.join(args)}", flush=True)
    result = subprocess.run(cmd)
    if result.returncode != 0:
        raise RuntimeError(
            f"pip install failed (exit {result.returncode}); see the pip "
            f"output above. cmd: {' '.join(cmd)}"
        )


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _read_lock_owner(lock_path: Path) -> int | None:
    try:
        raw = lock_path.read_text().strip()
    except OSError:
        return None
    try:
        return int(raw)
    except ValueError:
        return None


@contextlib.contextmanager
def _closure_lock(
    lock_path: Path,
    *,
    timeout_seconds: int,
    stale_seconds: int,
):
    """Coarse advisory file lock around the shared-environment install.

    Serializes cold first installs into the shared driver environment so
    two overlapping runs do not pip-install into the same site-packages
    at once.  The per-run wheel install does not take this lock.

    A crashed holder does not wedge future runs: ``flock`` is bound to
    the holder's open file description and the kernel releases it when
    that process dies, so a later waiter acquires the lock with no
    intervention.  The lock file is never unlinked to "break" it, since
    unlinking lets a second process acquire a fresh inode while an alive
    holder still holds the old one, allowing concurrent shared-environment
    installs.  After *timeout_seconds* the waiter inspects the recorded
    owner pid: a live owner is never force-broken and the waiter raises
    with an actionable error; an owner that is not alive is given up to
    *stale_seconds* more for the kernel lock to clear before raising.
    """
    import fcntl

    lock_path.parent.mkdir(parents=True, exist_ok=True)
    deadline = time.time() + timeout_seconds
    granted_grace = False
    fd = os.open(str(lock_path), os.O_CREAT | os.O_RDWR, 0o644)
    try:
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError:
                if time.time() >= deadline:
                    owner = _read_lock_owner(lock_path)
                    if owner is not None and _pid_alive(owner):
                        raise TimeoutError(
                            f"could not acquire {lock_path} within "
                            f"{timeout_seconds}s; held by live pid "
                            f"{owner} running the shared-environment "
                            "install. Not breaking an active install; "
                            "rerun once it completes."
                        )
                    if not granted_grace:
                        granted_grace = True
                        deadline = time.time() + stale_seconds
                        time.sleep(_LOCK_POLL_SECONDS)
                        continue
                    raise TimeoutError(
                        f"could not acquire {lock_path}; recorded owner "
                        f"{owner!r} is not alive but the kernel lock did "
                        f"not clear within {stale_seconds}s. Investigate "
                        "the cluster driver before rerunning."
                    )
                time.sleep(_LOCK_POLL_SECONDS)
        os.lseek(fd, 0, os.SEEK_SET)
        os.ftruncate(fd, 0)
        os.write(fd, str(os.getpid()).encode())
        os.fsync(fd)
        yield
    finally:
        with contextlib.suppress(OSError):
            fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def _smoke_check(modules: tuple[str, ...]) -> str:
    if not modules:
        return "skipped"
    import importlib

    for mod in modules:
        try:
            importlib.import_module(mod)
        except Exception as exc:  # noqa: BLE001 - surface any import failure
            raise RuntimeError(
                f"shared-environment smoke check failed importing "
                f"{mod!r}: {exc}"
            ) from exc
    return f"ok ({len(modules)})"


def _probe_jvm_class(probe_class: str) -> None:
    from pyspark.sql import SparkSession

    spark = SparkSession.builder.getOrCreate()
    jvm = spark._jvm
    try:
        # Resolve through the driver thread's context classloader, not the
        # default ``Class.forName`` caller classloader.  Databricks loads
        # maven cluster libraries (the Neo4j connector) into the Spark
        # driver's user classloader, which is the context classloader here
        # but is not visible to a bare reflective ``Class.forName`` via the
        # py4j gateway, so the bare form can false-negative on a connector
        # that is actually installed and usable by Spark.
        loader = jvm.java.lang.Thread.currentThread().getContextClassLoader()
        jvm.java.lang.Class.forName(probe_class, False, loader)
    except Exception as exc:  # noqa: BLE001 - translate to actionable msg
        raise RuntimeError(
            f"JVM connector class {probe_class!r} is not on the Spark "
            "classpath. The required maven cluster library is missing or "
            "failed to install. Fix the cluster library before running."
        ) from exc


def _resolve_entry_point(
    console_script: str, wheel_package: str, per_run_target: Path
):
    """Resolve the console entry point from the just-installed per-run wheel.

    Resolution is scoped to ``per_run_target`` rather than the global
    environment so an unrelated or stale install of the same script name
    elsewhere on ``sys.path`` cannot shadow the per-run project code.
    """
    from importlib.metadata import distributions

    want = _normalize_dist_name(wheel_package)
    dists = [
        d
        for d in distributions(path=[str(per_run_target)])
        if _normalize_dist_name(d.metadata["Name"] or "") == want
    ]
    if not dists:
        raise RuntimeError(
            f"project distribution {wheel_package!r} not found in the "
            f"per-run target {per_run_target}"
        )
    if len(dists) > 1:
        raise RuntimeError(
            f"found {len(dists)} distributions named {wheel_package!r} in "
            f"the per-run target {per_run_target}; expected exactly one"
        )

    matches = [
        ep
        for ep in dists[0].entry_points
        if ep.group == "console_scripts" and ep.name == console_script
    ]
    if not matches:
        raise RuntimeError(
            f"console entry point {console_script!r} not found in the "
            f"console_scripts of {wheel_package!r}"
        )
    if len(matches) > 1:
        raise RuntimeError(
            f"console entry point {console_script!r} is defined "
            f"{len(matches)} times in {wheel_package!r}; expected one"
        )
    return matches[0].load()


def main(argv: list[str] | None = None) -> None:
    """Bootstrap entry point.  Invoked as a ``SparkPythonTask`` script."""
    argv = list(sys.argv if argv is None else argv)
    inv = parse_invocation(argv)

    token = run_token()
    root = resolve_per_run_root(inv.per_run_root)
    runs_dir = root / "runs"
    per_run_target = runs_dir / token / "site"
    # pip --target does not cleanly overwrite a populated directory, so the
    # target must be fresh.  A same-run task retry reuses the run token, so
    # clear any prior contents rather than failing the retry.
    if per_run_target.exists():
        shutil.rmtree(per_run_target)
    per_run_target.mkdir(parents=True)

    now = time.time()
    for stale in select_sweep_targets(
        runs_dir, now=now, age_seconds=inv.sweep_age_seconds, keep=token
    ):
        print(f"  sweeping stale per-run dir: {stale}")
        with contextlib.suppress(OSError):
            shutil.rmtree(stale)

    wheel_src = Path(inv.wheel_volume_path)
    # Stage the local wheel copy inside the per-run run dir so the sweep
    # reclaims it with the run.  A sibling top-level ``wheelsrc/<token>``
    # would never be swept and would grow unbounded on the warm cluster's
    # local disk across dev iterations.
    staged = runs_dir / token / "wheelsrc"
    staged.mkdir(parents=True, exist_ok=True)
    wheel_name = wheel_filename_from_metadata(wheel_src)
    local_wheel = staged / wheel_name
    shutil.copyfile(wheel_src, local_wheel)
    wheel_sha = hashlib.sha256(local_wheel.read_bytes()).hexdigest()[:16]

    _pip_install([
        "--target", str(per_run_target),
        "--force-reinstall", "--no-deps",
        str(local_wheel),
    ])

    pinned_hash = closure_hash(inv.pinned_closure)
    if inv.pinned_closure:
        lock_path = root / "locks" / f"{pinned_hash}.lock"
        with _closure_lock(
            lock_path,
            timeout_seconds=inv.lock_timeout_seconds,
            stale_seconds=inv.stale_lock_seconds,
        ):
            _pip_install(["--no-deps", *inv.pinned_closure])

    smoke = _smoke_check(inv.smoke_imports)

    print(
        _MANIFEST_PREFIX
        + json.dumps({
            "wheel_volume_path": inv.wheel_volume_path,
            "wheel_sha": wheel_sha,
            "wheel_filename": wheel_name,
            "per_run_target": str(per_run_target),
            "closure_hash": pinned_hash,
            "smoke_check": smoke,
            "run_token": token,
        })
    )

    sys.path.insert(0, str(per_run_target))

    if inv.jvm_probe_class:
        _probe_jvm_class(inv.jvm_probe_class)

    sys.argv = rebuild_argv(argv[0], inv.project_params)
    entry = _resolve_entry_point(
        inv.console_script, inv.wheel_package, per_run_target
    )
    entry()


if __name__ == "__main__":
    main()
