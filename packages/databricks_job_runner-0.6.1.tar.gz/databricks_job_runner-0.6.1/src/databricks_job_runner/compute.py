"""Compute strategies for submitting Databricks jobs.

Each strategy knows how to attach itself to a :class:`SubmitTask` and how
to validate that its compute backend is ready.  :class:`ClassicCluster`
targets an existing all-purpose cluster (auto-started if terminated);
:class:`Serverless` targets Databricks serverless compute via a
job-level environment spec.

The :class:`Compute` type is a :class:`typing.Protocol` — concrete
strategies don't inherit from it, they just match its shape.  The
``frozen=True`` dataclasses give value-equality and hashability for free
and block accidental mutation of the strategy after construction.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import timedelta
from typing import Protocol

from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import OperationFailed
from databricks.sdk.service.compute import ClusterDetails, Environment, State
from databricks.sdk.service.jobs import JobEnvironment, SubmitTask

from databricks_job_runner.errors import RunnerError

_SERVERLESS_ENV_KEY = "default"

_TERMINATING_POLL_INTERVAL = 15  # seconds
_TERMINATING_TIMEOUT = timedelta(minutes=20)


class Compute(Protocol):
    """Strategy for attaching compute + dependencies to a SubmitTask."""

    def validate(self, ws: WorkspaceClient) -> None:
        """Ensure the compute backend is ready to accept a submission."""
        ...

    def decorate_task(self, task: SubmitTask) -> SubmitTask:
        """Mutate *task* in place with compute-specific fields and return it."""
        ...

    def environments(self) -> list[JobEnvironment] | None:
        """Return the top-level ``environments`` list for ``jobs.submit``.

        Classic clusters return ``None`` (the parameter is omitted).
        Serverless returns a non-empty list with one :class:`JobEnvironment`
        matching the task's ``environment_key``.
        """
        ...


@dataclass(frozen=True)
class ClassicCluster:
    """Submit to an existing all-purpose cluster, starting it if terminated."""

    cluster_id: str

    def validate(self, ws: WorkspaceClient) -> None:
        check_cluster(ws, self.cluster_id)

    def decorate_task(self, task: SubmitTask) -> SubmitTask:
        task.existing_cluster_id = self.cluster_id
        return task

    def environments(self) -> list[JobEnvironment] | None:
        return None


@dataclass(frozen=True)
class Serverless:
    """Submit to Databricks serverless compute via a job-level environment.

    The Jobs REST API requires ``environment_key`` for Python script,
    Python wheel, and dbt tasks on serverless, and requires a matching
    entry in ``environments[]``, so we always emit exactly one. The
    bootstrap installs the project wheel at run startup, so the emitted
    environment carries no dependencies.
    """

    environment_version: str = "3"

    def validate(self, ws: WorkspaceClient) -> None:
        # No-op: serverless compute is managed; nothing to warm up.
        return

    def decorate_task(self, task: SubmitTask) -> SubmitTask:
        task.environment_key = _SERVERLESS_ENV_KEY
        return task

    def environments(self) -> list[JobEnvironment]:
        return [
            JobEnvironment(
                environment_key=_SERVERLESS_ENV_KEY,
                spec=Environment(
                    environment_version=self.environment_version,
                    dependencies=[],
                ),
            )
        ]


def check_cluster(ws: WorkspaceClient, cluster_id: str) -> None:
    """Ensure the cluster is RUNNING, starting it if terminated.

    Uses the SDK's built-in ``wait_get_cluster_running`` poller with a
    callback that prints each state transition.  Uses the SDK's default
    20-minute timeout.  Raises :class:`RunnerError` if the cluster cannot
    reach RUNNING (e.g. it is in ERROR state, or the wait times out).
    """
    print(f"Checking cluster {cluster_id}...")
    cluster = ws.clusters.get(cluster_id)
    state = cluster.state
    state_name = state.value if state else "UNKNOWN"
    print(f"  Cluster: {state_name}")

    if state == State.RUNNING:
        return

    def _progress(poll: ClusterDetails) -> None:
        st = poll.state.value if poll.state else "UNKNOWN"
        print(f"  Waiting... ({st})")

    try:
        if state == State.TERMINATED:
            print("  Starting cluster...")
            ws.clusters.start(cluster_id).result(callback=_progress)
        elif state == State.TERMINATING:
            # wait_get_cluster_running treats TERMINATED as a failure state,
            # so we must wait for the cluster to finish terminating first.
            print("  Waiting for cluster to finish terminating...")
            _wait_for_terminated(ws, cluster_id, _progress)
            print("  Starting cluster...")
            ws.clusters.start(cluster_id).result(callback=_progress)
        elif state in (State.PENDING, State.RESTARTING, State.RESIZING):
            print("  Cluster is transitioning; waiting until RUNNING...")
            ws.clusters.wait_get_cluster_running(cluster_id, callback=_progress)
        else:  # ERROR, UNKNOWN, or any unexpected state
            raise RunnerError(
                f"cluster {cluster_id} is in state {state_name}."
            )
    except OperationFailed as exc:
        raise RunnerError(
            f"cluster did not reach RUNNING state: {exc}"
        ) from exc

    print("  Cluster: RUNNING")


def _wait_for_terminated(
    ws: WorkspaceClient,
    cluster_id: str,
    callback: Callable[[ClusterDetails], None],
) -> None:
    """Poll until the cluster reaches TERMINATED state (post-TERMINATING)."""
    deadline = time.time() + _TERMINATING_TIMEOUT.total_seconds()
    while time.time() < deadline:
        poll = ws.clusters.get(cluster_id)
        if poll.state == State.TERMINATED:
            return
        callback(poll)
        time.sleep(_TERMINATING_POLL_INTERVAL)
    raise RunnerError(
        f"cluster {cluster_id} did not finish terminating within "
        f"{_TERMINATING_TIMEOUT}."
    )
