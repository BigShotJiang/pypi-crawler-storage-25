"""Manage Unity Catalog catalogs, schemas, and volumes."""

from __future__ import annotations

from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import BadRequest, NotFound
from databricks.sdk.service.catalog import VolumeType

from databricks_job_runner.errors import RunnerError


# -- Name parsing helpers ----------------------------------------------------


def _parse_schema_name(full_name: str) -> tuple[str, str]:
    """Split ``catalog.schema`` into *(catalog, schema)*."""
    parts = full_name.split(".")
    if len(parts) != 2:
        raise RunnerError(
            f"Expected 'catalog.schema' format, got: '{full_name}'"
        )
    return parts[0], parts[1]


def _parse_volume_name(full_name: str) -> tuple[str, str, str]:
    """Split ``catalog.schema.volume`` into *(catalog, schema, volume)*."""
    parts = full_name.split(".")
    if len(parts) != 3:
        raise RunnerError(
            f"Expected 'catalog.schema.volume' format, got: '{full_name}'"
        )
    return parts[0], parts[1], parts[2]


# -- Catalogs ----------------------------------------------------------------


def list_catalogs(ws: WorkspaceClient) -> None:
    """List all catalogs visible to the current user."""
    print("Catalogs:")
    count = 0
    for cat in ws.catalogs.list():
        print(f"  {cat.name}")
        count += 1
    if count == 0:
        print("  (none)")
    print(f"\n{count} catalog(s) found.")


def get_catalog(ws: WorkspaceClient, name: str) -> None:
    """Print details for a single catalog."""
    try:
        cat = ws.catalogs.get(name)
    except NotFound as exc:
        raise RunnerError(f"Catalog '{name}' not found.") from exc
    print(f"Catalog: {cat.name}")
    if cat.owner:
        print(f"  Owner:            {cat.owner}")
    if cat.storage_root:
        print(f"  Storage root:     {cat.storage_root}")
    if cat.storage_location:
        print(f"  Storage location: {cat.storage_location}")
    if cat.comment:
        print(f"  Comment:          {cat.comment}")
    if cat.created_at:
        print(f"  Created:          {cat.created_at}")


def create_catalog(
    ws: WorkspaceClient,
    name: str,
    *,
    storage_root: str | None = None,
    comment: str | None = None,
) -> None:
    """Create a new catalog.

    *storage_root* sets the managed storage location for the catalog
    (equivalent to ``MANAGED LOCATION`` in SQL).  Required on metastores
    that use per-catalog storage roots instead of a metastore-level default.
    """
    cat = ws.catalogs.create(
        name=name, storage_root=storage_root, comment=comment
    )
    print(f"Created catalog: {cat.name}")
    if cat.storage_root:
        print(f"  Storage root: {cat.storage_root}")


def delete_catalog(
    ws: WorkspaceClient, name: str, *, force: bool = False
) -> None:
    """Delete a catalog.  *force* cascades to schemas, tables, and volumes."""
    try:
        ws.catalogs.delete(name, force=force)
        print(f"Deleted catalog: {name}")
    except NotFound as exc:
        raise RunnerError(f"Catalog '{name}' not found.") from exc
    except BadRequest as exc:
        if "not empty" in str(exc).lower():
            raise RunnerError(
                f"Catalog '{name}' is not empty. "
                "Use --force to cascade-delete all contents."
            ) from exc
        raise


# -- Schemas -----------------------------------------------------------------


def list_schemas(ws: WorkspaceClient, catalog_name: str) -> None:
    """List schemas in *catalog_name*."""
    print(f"Schemas in '{catalog_name}':")
    count = 0
    for schema in ws.schemas.list(catalog_name=catalog_name):
        print(f"  {schema.full_name}")
        count += 1
    if count == 0:
        print("  (none)")
    print(f"\n{count} schema(s) found.")


def get_schema(ws: WorkspaceClient, full_name: str) -> None:
    """Print details for a schema.  *full_name* is ``catalog.schema``."""
    try:
        schema = ws.schemas.get(full_name)
    except NotFound as exc:
        raise RunnerError(f"Schema '{full_name}' not found.") from exc
    print(f"Schema: {schema.full_name}")
    if schema.owner:
        print(f"  Owner:   {schema.owner}")
    if schema.comment:
        print(f"  Comment: {schema.comment}")
    if schema.created_at:
        print(f"  Created: {schema.created_at}")


def create_schema(
    ws: WorkspaceClient, full_name: str, *, comment: str | None = None
) -> None:
    """Create a schema.  *full_name* is ``catalog.schema``."""
    catalog_name, schema_name = _parse_schema_name(full_name)
    schema = ws.schemas.create(
        name=schema_name, catalog_name=catalog_name, comment=comment
    )
    print(f"Created schema: {schema.full_name}")


def delete_schema(ws: WorkspaceClient, full_name: str) -> None:
    """Delete a schema.  *full_name* is ``catalog.schema``."""
    try:
        ws.schemas.delete(full_name)
        print(f"Deleted schema: {full_name}")
    except NotFound as exc:
        raise RunnerError(f"Schema '{full_name}' not found.") from exc


# -- Volumes -----------------------------------------------------------------


def list_volumes(ws: WorkspaceClient, parent: str) -> None:
    """List volumes.  *parent* is ``catalog.schema``."""
    catalog_name, schema_name = _parse_schema_name(parent)
    print(f"Volumes in '{parent}':")
    count = 0
    for vol in ws.volumes.list(
        catalog_name=catalog_name, schema_name=schema_name
    ):
        vtype = vol.volume_type.value if vol.volume_type else "?"
        print(f"  {vol.full_name}  ({vtype})")
        count += 1
    if count == 0:
        print("  (none)")
    print(f"\n{count} volume(s) found.")


def get_volume(ws: WorkspaceClient, full_name: str) -> None:
    """Print details for a volume.  *full_name* is ``catalog.schema.volume``."""
    try:
        vol = ws.volumes.read(full_name)
    except NotFound as exc:
        raise RunnerError(f"Volume '{full_name}' not found.") from exc
    print(f"Volume: {vol.full_name}")
    if vol.volume_type:
        print(f"  Type:     {vol.volume_type.value}")
    if vol.owner:
        print(f"  Owner:    {vol.owner}")
    if vol.storage_location:
        print(f"  Location: {vol.storage_location}")
    if vol.comment:
        print(f"  Comment:  {vol.comment}")
    if vol.created_at:
        print(f"  Created:  {vol.created_at}")


def create_volume(
    ws: WorkspaceClient,
    full_name: str,
    *,
    volume_type: str = "MANAGED",
    storage_location: str | None = None,
    comment: str | None = None,
) -> None:
    """Create a volume.  *full_name* is ``catalog.schema.volume``."""
    catalog_name, schema_name, volume_name = _parse_volume_name(full_name)
    vtype = VolumeType(volume_type)
    if vtype == VolumeType.EXTERNAL and not storage_location:
        raise RunnerError("EXTERNAL volumes require --storage-location.")
    vol = ws.volumes.create(
        catalog_name=catalog_name,
        schema_name=schema_name,
        name=volume_name,
        volume_type=vtype,
        storage_location=storage_location,
        comment=comment,
    )
    print(f"Created volume: {vol.full_name} ({vtype.value})")


def delete_volume(ws: WorkspaceClient, full_name: str) -> None:
    """Delete a volume.  *full_name* is ``catalog.schema.volume``."""
    try:
        ws.volumes.delete(full_name)
        print(f"Deleted volume: {full_name}")
    except NotFound as exc:
        raise RunnerError(f"Volume '{full_name}' not found.") from exc
