from __future__ import annotations

"""Extract internal, URL, and email references from item content."""

import logging
import re
from pathlib import Path, PurePosixPath
from typing import Any
from urllib.parse import unquote, urlparse

from ..types import file_uri_to_path, format_ref
from . import action
from ._item_scope import resolve_item_text

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Link parsing
# ---------------------------------------------------------------------------

# [[target]] or [[target|display text]]
_WIKI_LINK_RE = re.compile(r"\[\[([^\]|]+)(?:\|([^\]]*))?\]\]")

# [display](target) or [display](target "title") — but not images
_MD_LINK_RE = re.compile(r'(?<!!)\[([^\]]*)\]\(([^)\s]+)(?:\s+"[^"]*")?\)')

# ![alt](src) or ![alt](src "title")
_MD_IMAGE_RE = re.compile(r'!\[([^\]]*)\]\(([^)\s]+)(?:\s+"[^"]*")?\)')

# Bare URLs (http/https) — used for non-markdown content
_URL_RE = re.compile(r'https?://[^\s<>\"\')]+')

# Bare email addresses — used for non-markdown content.
_EMAIL_RE = re.compile(
    r'(?<![A-Za-z0-9._%+-])'
    r'([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})'
    r'(?![A-Za-z0-9_%+-])',
)

# Directories that mark a vault root
_VAULT_MARKERS = (".obsidian", ".logseq", ".git")


def _parse_links(content: str, *, content_type: str = "text/markdown") -> list[dict[str, str]]:
    """Extract links from content.

    For markdown: extracts wiki-links, markdown links, and images.
    For other types (HTML, email, etc.): extracts bare URLs and email addresses.

    Returns a list of dicts with 'target' and 'style' keys.
    """
    links: list[dict[str, str]] = []
    seen: set[str] = set()

    is_markdown = content_type in ("text/markdown", "text/x-markdown")

    if is_markdown:
        for m in _WIKI_LINK_RE.finditer(content):
            target = m.group(1).strip()
            title = (m.group(2) or "").strip()
            if target and target not in seen:
                seen.add(target)
                link = {"target": target, "style": "wiki"}
                if title:
                    link["title"] = title
                links.append(link)

        for m in _MD_IMAGE_RE.finditer(content):
            target = m.group(2).strip()
            if target and target not in seen:
                seen.add(target)
                links.append({"target": target, "style": "markdown"})

        for m in _MD_LINK_RE.finditer(content):
            target = m.group(2).strip()
            title = m.group(1).strip()
            if not target or target.startswith("#"):
                continue
            normalized_email = _normalize_email_target(target)
            if normalized_email:
                if normalized_email not in seen:
                    seen.add(normalized_email)
                    link = {"target": normalized_email, "style": "email"}
                    if title and title != normalized_email:
                        link["title"] = title
                    links.append(link)
                continue
            if target not in seen:
                seen.add(target)
                links.append({"target": target, "style": "markdown"})
    else:
        # Non-markdown: extract bare URLs and bare email addresses.
        for m in _URL_RE.finditer(content):
            target = m.group(0).rstrip(".,;:!?)")
            if target and target not in seen:
                seen.add(target)
                links.append({"target": target, "style": "url"})
        for m in _EMAIL_RE.finditer(content):
            target = m.group(1).strip().lower()
            if target and target not in seen:
                seen.add(target)
                links.append({"target": target, "style": "email"})

    return links


def _normalize_email_target(target: str) -> str | None:
    """Normalize bare-email and mailto targets to keep's email item ID form."""
    raw = str(target or "").strip()
    if not raw:
        return None
    if raw.lower().startswith("mailto:"):
        raw = unquote(urlparse(raw).path or "").strip()
    normalized = raw.lower()
    return normalized if _EMAIL_RE.fullmatch(normalized) else None


def _safe_link_title(title: Any, target: str) -> str | None:
    """Return a safe alias for a resolved external target."""
    label = " ".join(str(title or "").split()).strip()
    if not label or label == target:
        return None
    if "|" in label or "]]" in label:
        return None
    return label


# ---------------------------------------------------------------------------
# Vault detection
# ---------------------------------------------------------------------------

def _detect_vault_root(file_path: str) -> str | None:
    """Walk parent dirs of a file:// path looking for vault markers.

    Returns the vault root as a ``file://`` URI, or None.
    """
    p = Path(file_path)
    for parent in p.parents:
        for marker in _VAULT_MARKERS:
            if (parent / marker).is_dir():
                return f"file://{parent}"
    return None


def _get_vault_root(source_id: str, context: Any) -> str | None:
    """Resolve the vault root for a file:// source item.

    Checks cached ``.vault/*`` items first, falls back to filesystem detection.
    Returns the vault root URI or None.
    """
    if not source_id.startswith("file://"):
        return None

    # _detect_vault_root walks the actual filesystem, so decode percent-escapes.
    file_path = file_uri_to_path(source_id)

    # Fast path: check known vault roots from store
    try:
        vault_items = context.list_items(
            prefix=".vault/", include_hidden=True, limit=100,
        )
    except Exception:
        vault_items = []

    if isinstance(vault_items, list):
        for vi in vault_items:
            vault_uri = str(getattr(vi, "id", "")).removeprefix(".vault/")
            if vault_uri and source_id.startswith(vault_uri):
                return vault_uri

    # Slow path: walk filesystem (once per vault)
    vault_root = _detect_vault_root(file_path)
    return vault_root


# ---------------------------------------------------------------------------
# Link resolution
# ---------------------------------------------------------------------------

def _is_url(target: str) -> bool:
    return target.startswith("http://") or target.startswith("https://")


def _is_email(target: str) -> bool:
    return _normalize_email_target(target) == target


def _resolve_internal_link(
    target: str,
    source_id: str,
    context: Any,
    *,
    style: str = "wiki",
    vault_root: str | None = None,
) -> str | None:
    """Resolve an internal link target to a keep item ID.

    For markdown-style links, uses folder-relative path matching only.
    For wiki-style links, tries folder-relative first then vault-wide
    name search as a fallback.
    """
    # Normalize: strip .md suffix for matching
    bare = target.removesuffix(".md")

    # If the source is a file:// URI, resolve relative paths
    if source_id.startswith("file://"):
        source_path = PurePosixPath(source_id.removeprefix("file://"))
        source_dir = source_path.parent

        # Build candidate file:// URIs
        candidates = []
        resolved = source_dir / target
        candidates.append(f"file://{resolved}")
        if not target.endswith(".md"):
            candidates.append(f"file://{resolved}.md")
        # Also try bare name resolve
        resolved_bare = source_dir / bare
        candidates.append(f"file://{resolved_bare}")
        candidates.append(f"file://{resolved_bare}.md")

        # Deduplicate while preserving order
        seen: set[str] = set()
        unique: list[str] = []
        for c in candidates:
            if c not in seen:
                seen.add(c)
                unique.append(c)

        for candidate in unique:
            item = context.get(candidate)
            if item is not None:
                return candidate

    # Fallback: try the target directly as an ID
    item = context.get(target)
    if item is not None:
        return target
    item = context.get(bare)
    if item is not None:
        return bare

    # Wiki-style fallback: vault-wide name search
    if style == "wiki" and hasattr(context, "find_by_name"):
        found = context.find_by_name(bare, vault=vault_root)
        if found is not None:
            found_id = str(getattr(found, "id", ""))
            if found_id:
                return found_id

    return None


# ---------------------------------------------------------------------------
# Action
# ---------------------------------------------------------------------------

@action(id="extract_links", priority=1)
class ExtractLinks:
    """Extract links from content and create reference edges.

    For markdown: wiki-links, markdown links, and images.
    For HTML/email/other: bare URLs (http/https).
    """

    def run(self, params: dict[str, Any], context: Any) -> dict[str, Any]:
        item_id, item, content = resolve_item_text(params, context)

        tag_key = str(params.get("tag", "references"))
        create_targets = str(params.get("create_targets", "true")).lower() == "true"

        # Determine content type for link parsing strategy
        item_tags = getattr(item, "tags", {}) or {}
        ct = item_tags.get("_content_type", "text/markdown")

        links = _parse_links(content, content_type=ct)

        # Merge pre-extracted structured links from document provider
        # (PDF annotations, DOCX/PPTX hyperlinks, HTML <a> tags). Each
        # entry is either a bare URL string or ``{"url": ..., "title"?:}``.
        doc_links = params.get("doc_links") or []
        if doc_links:
            seen = {l["target"] for l in links}
            for entry in doc_links:
                if isinstance(entry, dict):
                    url = entry.get("url")
                    title = entry.get("title")
                else:
                    url = entry
                    title = None
                raw_target = str(url or "").strip()
                normalized_target = raw_target
                if not _is_url(raw_target):
                    normalized_target = _normalize_email_target(raw_target) or ""
                if not normalized_target or normalized_target in seen:
                    continue
                seen.add(normalized_target)
                link: dict[str, str] = {"target": normalized_target, "style": "structured"}
                safe_title = _safe_link_title(title, normalized_target)
                if safe_title:
                    link["title"] = safe_title
                links.append(link)

        if not links:
            return {"skipped": True}

        # Detect vault root for wiki-style resolution
        vault_root = _get_vault_root(item_id, context)

        mutations: list[dict[str, Any]] = []
        resolved_targets: list[str] = []

        # If we discovered a new vault root, register it
        if vault_root:
            vault_item_id = f".vault/{vault_root}"
            existing_vault = context.get(vault_item_id)
            if existing_vault is None:
                mutations.append({
                    "op": "put_item",
                    "id": vault_item_id,
                    "content": f"Vault root: {vault_root}",
                    "summary": f"Vault root: {vault_root}",
                    "tags": {"_source": "vault_detect", "category": "system"},
                    "queue_background_tasks": False,
                })

        for link in links:
            target = link["target"]
            style = link["style"]

            if _is_url(target):
                # External URL — encode an alias if the structured
                # extractor gave us link text (e.g. HTML <a> anchor text).
                # When a title is present we deliberately skip the explicit
                # put_item: the edge processor's auto-vivify path seeds the
                # target's `name` tag from the alias, which is what we want.
                # Pre-creating the stub here would block that path (the
                # target would already exist by the time set_tags fires).
                title = link.get("title")
                # When create_targets=false, strip the alias so the edge
                # processor doesn't seed a `name` on the auto-vivified
                # target. The caller asked not to create target docs;
                # the edge row itself is still created (existing
                # behavior for URL tag values), but we stop the
                # upgrade-to-named-entity that a title would trigger.
                if title and not create_targets:
                    title = None
                ref_value = format_ref(target, title)
                resolved_targets.append(ref_value)
                if create_targets and not title:
                    # Untitled URL — keep the legacy put_item so the stub
                    # gets queued for background summarization.
                    existing = context.get(target)
                    if existing is None:
                        mutations.append({
                            "op": "stub_item",
                            "id": target,
                            "content": target,
                            "summary": target,
                            "tags": {"_source": "link"},
                            "queue_background_tasks": True,
                        })
            elif _is_email(target):
                title = _safe_link_title(link.get("title"), target)
                ref_value = format_ref(target, title)
                resolved_targets.append(ref_value)
                if create_targets and not title:
                    existing = context.get(target)
                    if existing is None:
                        mutations.append({
                            "op": "stub_item",
                            "id": target,
                            "content": target,
                            "summary": target,
                            "tags": {"_source": "link"},
                            "queue_background_tasks": True,
                        })
            else:
                # Internal link — resolve via path matching
                resolved = _resolve_internal_link(
                    target, item_id, context,
                    style=style, vault_root=vault_root,
                )
                if resolved:
                    # For wiki links, encode the alias for re-resolution
                    ref_value = resolved
                    if style == "wiki":
                        bare = target.removesuffix(".md")
                        ref_value = format_ref(resolved, link.get("title") or bare)
                    resolved_targets.append(ref_value)
                elif create_targets:
                    # Auto-vivify: create from relative path if source is file://
                    vivified = _vivify_id(target, item_id)
                    if vivified:
                        bare = target.removesuffix(".md")
                        ref_value = vivified
                        if style == "wiki":
                            ref_value = format_ref(vivified, link.get("title") or bare)
                        resolved_targets.append(ref_value)
                        mutations.append({
                            "op": "stub_item",
                            "id": vivified,
                            "content": f"[{target}]",
                            "summary": f"[{target}]",
                            "tags": {"_source": "link", "_link_stem": bare},
                            "queue_background_tasks": False,
                        })

        if not resolved_targets:
            return {"skipped": True, "links_found": len(links)}

        # Build edge tags — merge with existing
        existing_tags = dict(getattr(item, "tags", {}) or {})
        existing_refs = existing_tags.get(tag_key)
        if isinstance(existing_refs, list):
            # Merge, preserving order, dedup by ID
            from ..types import parse_ref
            seen_ids = {parse_ref(r)[0] for r in existing_refs}
            merged = list(existing_refs)
            for t in resolved_targets:
                tid = parse_ref(t)[0]
                if tid not in seen_ids:
                    seen_ids.add(tid)
                    merged.append(t)
            existing_tags[tag_key] = merged
        elif isinstance(existing_refs, str) and existing_refs:
            from ..types import parse_ref
            seen_ids = {parse_ref(existing_refs)[0]}
            merged = [existing_refs]
            for t in resolved_targets:
                tid = parse_ref(t)[0]
                if tid not in seen_ids:
                    seen_ids.add(tid)
                    merged.append(t)
            existing_tags[tag_key] = merged
        else:
            existing_tags[tag_key] = resolved_targets

        mutations.append({
            "op": "set_tags",
            "target": item_id,
            "tags": existing_tags,
        })

        return {
            "links": [l["target"] for l in links],
            "resolved": resolved_targets,
            "mutations": mutations,
        }


def _vivify_id(target: str, source_id: str) -> str | None:
    """Build a keep ID for auto-vivification of an internal link."""
    bare = target.removesuffix(".md")
    if source_id.startswith("file://"):
        source_path = PurePosixPath(source_id.removeprefix("file://"))
        resolved = source_path.parent / bare
        return f"file://{resolved}.md"
    # Non-file source: use the target as-is
    return bare or None
