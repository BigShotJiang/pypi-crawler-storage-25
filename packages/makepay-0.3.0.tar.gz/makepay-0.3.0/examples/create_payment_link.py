import os

from makepay import MakePayClient


makepay = MakePayClient(
    key_id=os.environ["MAKEPAY_KEY_ID"],
    key_secret=os.environ["MAKEPAY_KEY_SECRET"],
)

response = makepay.create_payment_link(
    {
        "title": "Order #1042",
        "amount": "129.99",
        "currency": "USDT",
        "orderId": "order_1042",
        "customerEmail": "buyer@example.com",
    }
)

print(response["paymentLink"]["publicUrl"])
