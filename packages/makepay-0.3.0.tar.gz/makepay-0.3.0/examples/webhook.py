import os

from makepay import parse_makepay_webhook


def handle_webhook(raw_body: bytes, headers: dict[str, str]) -> tuple[str, int]:
    event = parse_makepay_webhook(
        raw_body,
        headers.get("x-makepay-signature"),
        os.environ["MAKEPAY_WEBHOOK_SECRET"],
    )

    if event.get("event", {}).get("type") == "status_changed":
        # Update your local order status.
        pass

    return "ok", 200
