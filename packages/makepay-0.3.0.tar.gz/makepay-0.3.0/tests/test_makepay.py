import hmac
import json
import time
import unittest
from hashlib import sha256

from makepay import (
    MakePayClient,
    MakePayError,
    build_makepay_embedded_donation_url,
    build_makepay_embed_button_html,
    build_makepay_embedded_checkout_url,
    build_makepay_hosted_donation_url,
    build_makepay_hosted_checkout_url,
    build_makepay_iframe_html,
    build_makepay_modal_script_url,
    create_anonymous_payment_link,
    parse_makepay_webhook,
    verify_makepay_webhook,
)


class FakeResponse:
    def __init__(self, body, status=200):
        self.status = status
        self._body = body

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, traceback):
        return False

    def read(self):
        return self._body


class MakePaySdkTest(unittest.TestCase):
    def test_webhook_verification_and_parsing(self):
        body = json.dumps({"event": {"type": "status_changed"}})
        secret = "whsec_test"
        timestamp = int(time.time())
        signature = hmac.new(
            secret.encode("utf-8"),
            f"{timestamp}.".encode("utf-8") + body.encode("utf-8"),
            sha256,
        ).hexdigest()
        header = f"t={timestamp},v1={signature}"

        self.assertTrue(verify_makepay_webhook(body, header, secret))
        self.assertFalse(verify_makepay_webhook(body, header, "wrong"))
        self.assertEqual(
            parse_makepay_webhook(body, header, secret),
            {"event": {"type": "status_changed"}},
        )

    def test_client_creates_payment_link(self):
        requests = []

        def transport(request, timeout):
            requests.append((request, timeout))
            return FakeResponse(
                json.dumps(
                    {
                        "ok": True,
                        "paymentLink": {
                            "publicUrl": "https://makepay.io/payment/test",
                        },
                    }
                ).encode("utf-8"),
                status=201,
            )

        client = MakePayClient(
            key_id="mk_test",
            key_secret="mksec_test",
            transport=transport,
        )

        response = client.create_payment_link(
            {
                "amount": "12.50",
                "currency": "USDT",
            }
        )

        self.assertTrue(response["ok"])
        self.assertEqual(len(requests), 1)
        request, timeout = requests[0]
        self.assertEqual(timeout, 30)
        self.assertTrue(request.full_url.endswith("/api/partner/v1/makepay/payment-links"))
        self.assertEqual(request.get_method(), "POST")
        self.assertEqual(request.get_header("X-makecrypto-key-id"), "mk_test")
        self.assertEqual(request.get_header("X-makecrypto-key-secret"), "mksec_test")

    def test_client_covers_makepay_0_3_resource_routes(self):
        requests = []

        def transport(request, timeout):
            requests.append(request)
            return FakeResponse(b'{"ok":true}')

        client = MakePayClient(
            key_id="mk_test",
            key_secret="mksec_test",
            transport=transport,
        )

        calls = [
            (client.create_donation_link, ({"title": "Campaign"},), "POST", "/donations"),
            (client.list_donation_links, (), "GET", "/donations"),
            (client.get_donation_link, ("don_123",), "GET", "/donations/don_123"),
            (
                client.update_donation_link,
                ("don_123", {"status": "paused"}),
                "PATCH",
                "/donations/don_123",
            ),
            (client.list_customers, (), "GET", "/customers"),
            (client.upsert_customer, ({"email": "buyer@example.com"},), "POST", "/customers"),
            (client.create_customer_portal, ("cus_123",), "POST", "/customers/cus_123/portal"),
            (client.list_subscriptions, (), "GET", "/subscriptions"),
            (
                client.create_subscription,
                ({"amountUsd": "29", "customerEmail": "buyer@example.com"},),
                "POST",
                "/subscriptions",
            ),
            (client.list_destination_assets, (), "GET", "/destination-assets"),
            (client.list_webhook_requests, ({"limit": 25},), "GET", "/webhook-requests?limit=25"),
            (client.list_pos_terminals, (), "GET", "/pos-terminals"),
            (client.create_pos_terminal, ({"name": "Front counter"},), "POST", "/pos-terminals"),
            (client.get_pos_terminal, ("pos_123",), "GET", "/pos-terminals/pos_123"),
            (
                client.update_pos_terminal,
                ("pos_123", {"status": "paused"}),
                "PATCH",
                "/pos-terminals/pos_123",
            ),
            (client.list_products, (), "GET", "/products"),
            (client.create_product, ({"name": "Guide"},), "POST", "/products"),
            (client.get_product, ("prod_123",), "GET", "/products/prod_123"),
            (
                client.update_product,
                ("prod_123", {"status": "active"}),
                "PATCH",
                "/products/prod_123",
            ),
            (
                client.list_product_downloads,
                ("prod_123",),
                "GET",
                "/shop/products/prod_123/downloads",
            ),
            (
                client.create_product_download,
                ("prod_123", {"fileName": "guide.pdf"}),
                "POST",
                "/shop/products/prod_123/downloads",
            ),
            (client.get_shop, (), "GET", "/shop"),
            (client.update_shop, ({"slug": "merchant-shop"},), "PATCH", "/shop"),
            (client.get_shop_builder, (), "GET", "/shop/builder"),
            (client.update_shop_builder, ({"blocks": []},), "PUT", "/shop/builder"),
            (client.get_shop_domain, (), "GET", "/shop/domains"),
            (client.update_shop_domain, ("shop.example",), "PUT", "/shop/domains"),
            (client.refresh_shop_domain, (), "POST", "/shop/domains"),
            (client.list_shop_coupons, (), "GET", "/shop/coupons"),
            (client.create_shop_coupon, ({"code": "SAVE10"},), "POST", "/shop/coupons"),
            (
                client.update_shop_coupon,
                ("coupon_123", {"status": "active"}),
                "PATCH",
                "/shop/coupons/coupon_123",
            ),
            (client.archive_shop_coupon, ("coupon_123",), "DELETE", "/shop/coupons/coupon_123"),
            (client.list_shop_orders, ({"status": "paid"},), "GET", "/shop/orders?status=paid"),
            (client.get_branding, (), "GET", "/branding"),
            (client.update_branding, ({"brandName": "Merchant"},), "PATCH", "/branding"),
            (client.refresh_branding_domains, (), "POST", "/branding/domains/refresh"),
            (client.get_bookkeeping_summary, (), "GET", "/bookkeeping"),
            (client.list_bookkeeping_invoices, (), "GET", "/bookkeeping/invoices"),
            (
                client.create_bookkeeping_invoice,
                ({"title": "Invoice #1042"},),
                "POST",
                "/bookkeeping/invoices",
            ),
            (
                client.get_bookkeeping_invoice,
                ("inv_123",),
                "GET",
                "/bookkeeping/invoices/inv_123",
            ),
            (
                client.update_bookkeeping_invoice,
                ("inv_123", {"status": "open"}),
                "PATCH",
                "/bookkeeping/invoices/inv_123",
            ),
            (
                client.create_bookkeeping_invoice_payment_link,
                ("inv_123", {"sendPaymentRequestEmail": True}),
                "POST",
                "/bookkeeping/invoices/inv_123/payment-link",
            ),
            (client.list_bookkeeping_expenses, (), "GET", "/bookkeeping/expenses"),
            (
                client.create_bookkeeping_expense,
                ({"title": "Hosting"},),
                "POST",
                "/bookkeeping/expenses",
            ),
            (
                client.create_bookkeeping_expense_from_activity,
                ({"walletActivityEventKey": "event_123"},),
                "POST",
                "/bookkeeping/expenses/from-activity",
            ),
            (
                client.get_bookkeeping_expense,
                ("exp_123",),
                "GET",
                "/bookkeeping/expenses/exp_123",
            ),
            (
                client.update_bookkeeping_expense,
                ("exp_123", {"status": "approved"}),
                "PATCH",
                "/bookkeeping/expenses/exp_123",
            ),
            (client.list_bookkeeping_documents, (), "GET", "/bookkeeping/documents"),
            (
                client.get_bookkeeping_document_download_url,
                ("doc_123",),
                "GET",
                "/bookkeeping/documents/doc_123/download",
            ),
            (
                client.run_bookkeeping_document_ocr,
                ("doc_123",),
                "POST",
                "/bookkeeping/documents/doc_123/ocr",
            ),
            (
                client.create_bookkeeping_reconciliation,
                ({"invoiceId": "inv_123", "paymentSessionId": "session_123"},),
                "POST",
                "/bookkeeping/reconciliation",
            ),
        ]

        for function, args, method, suffix in calls:
            with self.subTest(function=function.__name__):
                requests.clear()
                function(*args)
                request = requests[0]
                self.assertEqual(request.get_method(), method)
                self.assertTrue(
                    request.full_url.endswith(f"/api/partner/v1/makepay{suffix}"),
                    request.full_url,
                )

        requests.clear()
        client.create_donation_link({"title": "Campaign"})
        body = json.loads(requests[0].data.decode("utf-8"))
        self.assertEqual(body["payload"]["type"], "donation")

    def test_anonymous_payment_link_uses_public_request(self):
        requests = []

        def transport(request, timeout):
            requests.append((request, timeout))
            return FakeResponse(b'{"paymentLink":{"uid":"pay_123"}}', status=201)

        response = create_anonymous_payment_link(
            {
                "amount": "25",
                "settlement": {
                    "currency": "USDT",
                    "priorities": [{"chain": "ETH", "address": "0xabc"}],
                },
            },
            transport=transport,
        )

        self.assertEqual(response["paymentLink"]["uid"], "pay_123")
        request, timeout = requests[0]
        self.assertEqual(timeout, 30)
        self.assertEqual(request.get_method(), "POST")
        self.assertIsNone(request.get_header("X-makecrypto-key-id"))
        self.assertTrue(request.full_url.endswith("/api/partner/v1/makepay/payment-links"))

    def test_bookkeeping_document_upload_uses_multipart(self):
        requests = []

        def transport(request, timeout):
            requests.append(request)
            return FakeResponse(b'{"ok":true}', status=201)

        client = MakePayClient(
            key_id="mk_test",
            key_secret="mksec_test",
            transport=transport,
        )

        client.upload_bookkeeping_document(
            {
                "file": b"%PDF-1.4",
                "fileName": "receipt.pdf",
                "documentType": "receipt",
                "expenseId": "exp_123",
            }
        )

        request = requests[0]
        self.assertEqual(request.get_method(), "POST")
        self.assertTrue(
            request.full_url.endswith("/api/partner/v1/makepay/bookkeeping/documents")
        )
        self.assertIn("multipart/form-data", request.get_header("Content-type"))
        self.assertIn(b'name="documentType"', request.data)
        self.assertIn(b"receipt", request.data)
        self.assertIn(b'filename="receipt.pdf"', request.data)
        self.assertIn(b"%PDF-1.4", request.data)

    def test_checkout_helpers(self):
        client = MakePayClient(
            key_id="mk_test",
            key_secret="mksec_test",
            checkout_base_url="https://checkout.example/",
            transport=lambda request, timeout: FakeResponse(b"{}"),
        )

        self.assertEqual(
            client.hosted_checkout_url("pay_123"),
            "https://checkout.example/payment/pay_123",
        )
        self.assertEqual(
            build_makepay_hosted_checkout_url("pay_123", base_url="https://pay.example/"),
            "https://pay.example/payment/pay_123",
        )
        self.assertEqual(
            client.hosted_donation_url("spring-campaign"),
            "https://checkout.example/donations/spring-campaign",
        )
        self.assertEqual(
            build_makepay_hosted_donation_url(
                "spring-campaign",
                base_url="https://pay.example/",
            ),
            "https://pay.example/donations/spring-campaign",
        )
        self.assertEqual(
            build_makepay_embedded_checkout_url(
                "pay_123",
                base_url="https://pay.example/",
                parent_origin="https://merchant.example",
            ),
            "https://pay.example/embed/payment/pay_123?parentOrigin=https%3A%2F%2Fmerchant.example",
        )
        self.assertEqual(
            build_makepay_embedded_donation_url(
                "spring-campaign",
                base_url="https://pay.example/",
                parent_origin="https://merchant.example",
            ),
            "https://pay.example/embed/donations/spring-campaign?parentOrigin=https%3A%2F%2Fmerchant.example",
        )
        self.assertEqual(
            build_makepay_modal_script_url(base_url="https://pay.example/"),
            "https://pay.example/modal/makepay.js",
        )
        self.assertIn(
            'data-makepay-payment-link="pay_&quot;&lt;&amp;"',
            build_makepay_embed_button_html('pay_"<&', button_label="Pay <now>"),
        )
        self.assertIn(
            'src="https://makepay.io/embed/payment/pay_123"',
            build_makepay_iframe_html("pay_123", iframe_title="Secure checkout"),
        )

    def test_missing_credentials_raise(self):
        with self.assertRaises(MakePayError):
            MakePayClient(key_id="", key_secret="")


if __name__ == "__main__":
    unittest.main()
