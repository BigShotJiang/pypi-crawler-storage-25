from __future__ import annotations

import json
import mimetypes
import secrets
from html import escape
from pathlib import Path
from typing import Any, Callable, Mapping, MutableMapping, Sequence
from urllib.error import HTTPError
from urllib.parse import quote, urlencode, urljoin
from urllib.request import Request, urlopen

from .errors import MakePayError
from .webhooks import parse_makepay_webhook, verify_makepay_webhook

JsonObject = dict[str, Any]
RequestQuery = Mapping[str, Any]
Transport = Callable[..., Any]


class MakePayClient:
    default_base_url = "https://www.makecrypto.io"
    default_checkout_base_url = "https://makepay.io"
    version = "0.3.0"

    def __init__(
        self,
        *,
        key_id: str | None = None,
        key_secret: str | None = None,
        base_url: str | None = None,
        checkout_base_url: str | None = None,
        timeout: float = 30,
        transport: Transport | None = None,
        **aliases: Any,
    ) -> None:
        self.base_url = _normalize_base_url(
            base_url
            or aliases.pop("baseUrl", None)
            or aliases.pop("api_base_url", None)
            or self.default_base_url
        )
        self.checkout_base_url = _normalize_base_url(
            checkout_base_url
            or aliases.pop("checkoutBaseUrl", None)
            or self.default_checkout_base_url
        )
        self.key_id = str(
            key_id
            or aliases.pop("keyId", None)
            or aliases.pop("api_key_id", None)
            or ""
        )
        self.key_secret = str(
            key_secret
            or aliases.pop("keySecret", None)
            or aliases.pop("api_key_secret", None)
            or ""
        )
        self.timeout = timeout
        self._transport = transport or urlopen

        if aliases:
            names = ", ".join(sorted(aliases))
            raise TypeError(f"Unexpected MakePayClient option(s): {names}")

        if not self.key_id or not self.key_secret:
            raise MakePayError("MakePay key_id and key_secret are required.", status=400)

    def create_payment_link(
        self,
        payload: Mapping[str, Any],
        *,
        status: str = "active",
        send_payment_request_email: bool = False,
    ) -> JsonObject:
        return self.request(
            "POST",
            "/api/partner/v1/makepay/payment-links",
            {
                "status": status,
                "sendPaymentRequestEmail": send_payment_request_email,
                "payload": dict(payload),
            },
        )

    def list_payment_links(self, query: RequestQuery | None = None) -> JsonObject:
        return self.request(
            "GET",
            "/api/partner/v1/makepay/payment-links",
            query=query,
        )

    def get_payment_link(self, uid: str) -> JsonObject:
        _assert_non_empty(uid, "Payment link UID is required.")

        return self.request(
            "GET",
            f"/api/partner/v1/makepay/payment-links/{quote(uid, safe='')}",
        )

    def update_payment_link(self, uid: str, updates: Mapping[str, Any]) -> JsonObject:
        _assert_non_empty(uid, "Payment link UID is required.")

        return self.request(
            "PATCH",
            f"/api/partner/v1/makepay/payment-links/{quote(uid, safe='')}",
            dict(updates),
        )

    def send_payment_request_email(self, uid: str, email: str | None = None) -> JsonObject:
        _assert_non_empty(uid, "Payment link UID is required.")

        return self.request(
            "POST",
            f"/api/partner/v1/makepay/payment-links/{quote(uid, safe='')}/send-request-email",
            {"email": email} if email else {},
        )

    def create_donation_link(
        self,
        payload: Mapping[str, Any],
        *,
        status: str = "active",
        send_payment_request_email: bool = False,
    ) -> JsonObject:
        donation_payload = dict(payload)
        donation_payload["type"] = "donation"
        return self.request(
            "POST",
            "/api/partner/v1/makepay/donations",
            {
                "status": status,
                "sendPaymentRequestEmail": send_payment_request_email,
                "payload": donation_payload,
            },
        )

    def list_donation_links(self) -> JsonObject:
        return self.request("GET", "/api/partner/v1/makepay/donations")

    def get_donation_link(self, uid: str) -> JsonObject:
        _assert_non_empty(uid, "Donation link UID is required.")

        return self.request(
            "GET",
            f"/api/partner/v1/makepay/donations/{quote(uid, safe='')}",
        )

    def update_donation_link(self, uid: str, updates: Mapping[str, Any]) -> JsonObject:
        _assert_non_empty(uid, "Donation link UID is required.")

        return self.request(
            "PATCH",
            f"/api/partner/v1/makepay/donations/{quote(uid, safe='')}",
            dict(updates),
        )

    def list_customers(self) -> JsonObject:
        return self.request("GET", "/api/partner/v1/makepay/customers")

    def upsert_customer(self, payload: Mapping[str, Any]) -> JsonObject:
        return self.request("POST", "/api/partner/v1/makepay/customers", dict(payload))

    def create_customer_portal(
        self, customer_id: str, payload: Mapping[str, Any] | None = None
    ) -> JsonObject:
        _assert_non_empty(customer_id, "Customer ID is required.")

        return self.request(
            "POST",
            f"/api/partner/v1/makepay/customers/{quote(customer_id, safe='')}/portal",
            dict(payload or {}),
        )

    def list_subscriptions(self) -> JsonObject:
        return self.request("GET", "/api/partner/v1/makepay/subscriptions")

    def create_subscription(self, payload: Mapping[str, Any]) -> JsonObject:
        return self.request("POST", "/api/partner/v1/makepay/subscriptions", dict(payload))

    def list_destination_assets(self) -> JsonObject:
        return self.request("GET", "/api/partner/v1/makepay/destination-assets")

    def list_webhook_requests(self, query: RequestQuery | None = None) -> JsonObject:
        return self.request(
            "GET",
            "/api/partner/v1/makepay/webhook-requests",
            query=query,
        )

    def list_pos_terminals(self) -> JsonObject:
        return self.request("GET", "/api/partner/v1/makepay/pos-terminals")

    def create_pos_terminal(self, payload: Mapping[str, Any]) -> JsonObject:
        return self.request("POST", "/api/partner/v1/makepay/pos-terminals", dict(payload))

    def get_pos_terminal(self, terminal_id: str) -> JsonObject:
        _assert_non_empty(terminal_id, "POS terminal ID is required.")

        return self.request(
            "GET",
            f"/api/partner/v1/makepay/pos-terminals/{quote(terminal_id, safe='')}",
        )

    def update_pos_terminal(
        self, terminal_id: str, payload: Mapping[str, Any]
    ) -> JsonObject:
        _assert_non_empty(terminal_id, "POS terminal ID is required.")

        return self.request(
            "PATCH",
            f"/api/partner/v1/makepay/pos-terminals/{quote(terminal_id, safe='')}",
            dict(payload),
        )

    def list_products(self) -> JsonObject:
        return self.request("GET", "/api/partner/v1/makepay/products")

    def create_product(self, payload: Mapping[str, Any]) -> JsonObject:
        return self.request("POST", "/api/partner/v1/makepay/products", dict(payload))

    def get_product(self, product_id: str) -> JsonObject:
        _assert_non_empty(product_id, "Product ID is required.")

        return self.request(
            "GET",
            f"/api/partner/v1/makepay/products/{quote(product_id, safe='')}",
        )

    def update_product(self, product_id: str, payload: Mapping[str, Any]) -> JsonObject:
        _assert_non_empty(product_id, "Product ID is required.")

        return self.request(
            "PATCH",
            f"/api/partner/v1/makepay/products/{quote(product_id, safe='')}",
            dict(payload),
        )

    def list_product_downloads(self, product_id: str) -> JsonObject:
        _assert_non_empty(product_id, "Product ID is required.")

        return self.request(
            "GET",
            f"/api/partner/v1/makepay/shop/products/{quote(product_id, safe='')}/downloads",
        )

    def create_product_download(
        self, product_id: str, payload: Mapping[str, Any]
    ) -> JsonObject:
        _assert_non_empty(product_id, "Product ID is required.")

        return self.request(
            "POST",
            f"/api/partner/v1/makepay/shop/products/{quote(product_id, safe='')}/downloads",
            dict(payload),
        )

    def get_shop(self) -> JsonObject:
        return self.request("GET", "/api/partner/v1/makepay/shop")

    def update_shop(self, payload: Mapping[str, Any]) -> JsonObject:
        return self.request("PATCH", "/api/partner/v1/makepay/shop", dict(payload))

    def get_shop_builder(self) -> JsonObject:
        return self.request("GET", "/api/partner/v1/makepay/shop/builder")

    def update_shop_builder(self, payload: Mapping[str, Any]) -> JsonObject:
        return self.request("PUT", "/api/partner/v1/makepay/shop/builder", dict(payload))

    def get_shop_domain(self) -> JsonObject:
        return self.request("GET", "/api/partner/v1/makepay/shop/domains")

    def update_shop_domain(self, domain_or_payload: str | Mapping[str, Any] | None) -> JsonObject:
        body = (
            {"domain": domain_or_payload}
            if isinstance(domain_or_payload, str) or domain_or_payload is None
            else dict(domain_or_payload)
        )
        return self.request("PUT", "/api/partner/v1/makepay/shop/domains", body)

    def refresh_shop_domain(
        self, domain_or_payload: str | Mapping[str, Any] | None = None
    ) -> JsonObject:
        body = (
            {"domain": domain_or_payload}
            if isinstance(domain_or_payload, str)
            else dict(domain_or_payload or {})
        )
        return self.request("POST", "/api/partner/v1/makepay/shop/domains", body)

    def list_shop_coupons(self) -> JsonObject:
        return self.request("GET", "/api/partner/v1/makepay/shop/coupons")

    def create_shop_coupon(self, payload: Mapping[str, Any]) -> JsonObject:
        return self.request("POST", "/api/partner/v1/makepay/shop/coupons", dict(payload))

    def update_shop_coupon(self, coupon_uid: str, payload: Mapping[str, Any]) -> JsonObject:
        _assert_non_empty(coupon_uid, "Shop coupon UID is required.")

        return self.request(
            "PATCH",
            f"/api/partner/v1/makepay/shop/coupons/{quote(coupon_uid, safe='')}",
            dict(payload),
        )

    def archive_shop_coupon(self, coupon_uid: str) -> JsonObject:
        _assert_non_empty(coupon_uid, "Shop coupon UID is required.")

        return self.request(
            "DELETE",
            f"/api/partner/v1/makepay/shop/coupons/{quote(coupon_uid, safe='')}",
        )

    def list_shop_orders(self, query: RequestQuery | None = None) -> JsonObject:
        return self.request(
            "GET",
            "/api/partner/v1/makepay/shop/orders",
            query=query,
        )

    def get_branding(self) -> JsonObject:
        return self.request("GET", "/api/partner/v1/makepay/branding")

    def update_branding(self, payload: Mapping[str, Any]) -> JsonObject:
        return self.request("PATCH", "/api/partner/v1/makepay/branding", dict(payload))

    def refresh_branding_domains(self, kind: str = "all") -> JsonObject:
        return self.request(
            "POST",
            "/api/partner/v1/makepay/branding/domains/refresh",
            {"kind": kind},
        )

    def get_bookkeeping_summary(self) -> JsonObject:
        return self.request("GET", "/api/partner/v1/makepay/bookkeeping")

    def list_bookkeeping_invoices(self) -> JsonObject:
        return self.request("GET", "/api/partner/v1/makepay/bookkeeping/invoices")

    def create_bookkeeping_invoice(self, payload: Mapping[str, Any]) -> JsonObject:
        return self.request(
            "POST",
            "/api/partner/v1/makepay/bookkeeping/invoices",
            dict(payload),
        )

    def get_bookkeeping_invoice(self, invoice_id: str) -> JsonObject:
        _assert_non_empty(invoice_id, "Bookkeeping invoice ID is required.")

        return self.request(
            "GET",
            f"/api/partner/v1/makepay/bookkeeping/invoices/{quote(invoice_id, safe='')}",
        )

    def update_bookkeeping_invoice(
        self, invoice_id: str, payload: Mapping[str, Any]
    ) -> JsonObject:
        _assert_non_empty(invoice_id, "Bookkeeping invoice ID is required.")

        return self.request(
            "PATCH",
            f"/api/partner/v1/makepay/bookkeeping/invoices/{quote(invoice_id, safe='')}",
            dict(payload),
        )

    def create_bookkeeping_invoice_payment_link(
        self, invoice_id: str, options: Mapping[str, Any] | None = None
    ) -> JsonObject:
        _assert_non_empty(invoice_id, "Bookkeeping invoice ID is required.")

        return self.request(
            "POST",
            f"/api/partner/v1/makepay/bookkeeping/invoices/{quote(invoice_id, safe='')}/payment-link",
            dict(options or {}),
        )

    def list_bookkeeping_expenses(self) -> JsonObject:
        return self.request("GET", "/api/partner/v1/makepay/bookkeeping/expenses")

    def create_bookkeeping_expense(self, payload: Mapping[str, Any]) -> JsonObject:
        return self.request(
            "POST",
            "/api/partner/v1/makepay/bookkeeping/expenses",
            dict(payload),
        )

    def create_bookkeeping_expense_from_activity(
        self, payload: Mapping[str, Any]
    ) -> JsonObject:
        return self.request(
            "POST",
            "/api/partner/v1/makepay/bookkeeping/expenses/from-activity",
            dict(payload),
        )

    def get_bookkeeping_expense(self, expense_id: str) -> JsonObject:
        _assert_non_empty(expense_id, "Bookkeeping expense ID is required.")

        return self.request(
            "GET",
            f"/api/partner/v1/makepay/bookkeeping/expenses/{quote(expense_id, safe='')}",
        )

    def update_bookkeeping_expense(
        self, expense_id: str, payload: Mapping[str, Any]
    ) -> JsonObject:
        _assert_non_empty(expense_id, "Bookkeeping expense ID is required.")

        return self.request(
            "PATCH",
            f"/api/partner/v1/makepay/bookkeeping/expenses/{quote(expense_id, safe='')}",
            dict(payload),
        )

    def list_bookkeeping_documents(self) -> JsonObject:
        return self.request("GET", "/api/partner/v1/makepay/bookkeeping/documents")

    def upload_bookkeeping_document(self, input: Mapping[str, Any]) -> JsonObject:
        file_value = input.get("file")
        if file_value is None:
            raise MakePayError("Bookkeeping document file is required.", status=400)

        file_name = (
            input.get("fileName")
            or input.get("file_name")
            or getattr(file_value, "name", None)
            or "document"
        )
        fields = _pick_present(
            input,
            (
                ("documentType", "document_type"),
                ("invoiceId", "invoice_id"),
                ("expenseId", "expense_id"),
            ),
        )
        files = [
            (
                "file",
                str(file_name),
                _read_file_payload(file_value),
                _guess_content_type(str(file_name)),
            )
        ]
        return self.request_form_data(
            "POST",
            "/api/partner/v1/makepay/bookkeeping/documents",
            fields,
            files,
        )

    def get_bookkeeping_document_download_url(self, document_id: str) -> JsonObject:
        _assert_non_empty(document_id, "Bookkeeping document ID is required.")

        return self.request(
            "GET",
            f"/api/partner/v1/makepay/bookkeeping/documents/{quote(document_id, safe='')}/download",
        )

    def run_bookkeeping_document_ocr(self, document_id: str) -> JsonObject:
        _assert_non_empty(document_id, "Bookkeeping document ID is required.")

        return self.request(
            "POST",
            f"/api/partner/v1/makepay/bookkeeping/documents/{quote(document_id, safe='')}/ocr",
            {},
        )

    def create_bookkeeping_reconciliation(self, payload: Mapping[str, Any]) -> JsonObject:
        return self.request(
            "POST",
            "/api/partner/v1/makepay/bookkeeping/reconciliation",
            dict(payload),
        )

    def get_settings(self) -> JsonObject:
        return self.request("GET", "/api/partner/v1/makepay/settings")

    def update_settings(self, settings: Mapping[str, Any]) -> JsonObject:
        return self.request("PUT", "/api/partner/v1/makepay/settings", dict(settings))

    def hosted_checkout_url(self, payment_uid: str) -> str:
        return build_makepay_hosted_checkout_url(
            payment_uid,
            base_url=self.checkout_base_url,
        )

    def hosted_donation_url(self, donation_slug: str) -> str:
        return build_makepay_hosted_donation_url(
            donation_slug,
            base_url=self.checkout_base_url,
        )

    def embedded_checkout_url(
        self,
        payment_uid: str,
        *,
        parent_origin: str | None = None,
    ) -> str:
        return build_makepay_embedded_checkout_url(
            payment_uid,
            base_url=self.checkout_base_url,
            parent_origin=parent_origin,
        )

    def embedded_donation_url(
        self,
        donation_slug: str,
        *,
        parent_origin: str | None = None,
    ) -> str:
        return build_makepay_embedded_donation_url(
            donation_slug,
            base_url=self.checkout_base_url,
            parent_origin=parent_origin,
        )

    def modal_script_url(self) -> str:
        return build_makepay_modal_script_url(base_url=self.checkout_base_url)

    def embed_button_html(
        self,
        payment_uid: str,
        *,
        button_label: str = "Pay with crypto",
    ) -> str:
        return build_makepay_embed_button_html(
            payment_uid,
            base_url=self.checkout_base_url,
            button_label=button_label,
        )

    def iframe_html(
        self,
        payment_uid: str,
        *,
        iframe_title: str = "MakePay checkout",
        parent_origin: str | None = None,
    ) -> str:
        return build_makepay_iframe_html(
            payment_uid,
            base_url=self.checkout_base_url,
            iframe_title=iframe_title,
            parent_origin=parent_origin,
        )

    def verify_webhook(
        self,
        raw_body: str | bytes,
        signature_header: str | None,
        secret: str,
        *,
        tolerance_seconds: int = 300,
    ) -> bool:
        return verify_makepay_webhook(
            raw_body,
            signature_header,
            secret,
            tolerance_seconds=tolerance_seconds,
        )

    def parse_webhook(
        self,
        raw_body: str | bytes,
        signature_header: str | None,
        secret: str,
        *,
        tolerance_seconds: int = 300,
    ) -> JsonObject:
        return parse_makepay_webhook(
            raw_body,
            signature_header,
            secret,
            tolerance_seconds=tolerance_seconds,
        )

    def request(
        self,
        method: str,
        path: str,
        body: Mapping[str, Any] | None = None,
        *,
        query: RequestQuery | None = None,
    ) -> JsonObject:
        data: bytes | None = None
        headers: MutableMapping[str, str] = self._authenticated_headers()

        if body is not None and method.upper() != "GET":
            headers["Content-Type"] = "application/json"
            data = json.dumps(dict(body), separators=(",", ":")).encode("utf-8")

        return self._send(method, path, headers, data, query=query)

    def request_form_data(
        self,
        method: str,
        path: str,
        fields: Mapping[str, Any],
        files: Sequence[tuple[str, str, bytes, str]],
        *,
        query: RequestQuery | None = None,
    ) -> JsonObject:
        body, content_type = _encode_multipart_form_data(fields, files)
        headers = self._authenticated_headers()
        headers["Content-Type"] = content_type
        return self._send(method, path, headers, body, query=query)

    def _authenticated_headers(self) -> MutableMapping[str, str]:
        return {
            "Accept": "application/json",
            "User-Agent": f"MakePayPython/{self.version}",
            "X-MakeCrypto-Key-Id": self.key_id,
            "X-MakeCrypto-Key-Secret": self.key_secret,
        }

    def _send(
        self,
        method: str,
        path: str,
        headers: Mapping[str, str],
        data: bytes | None,
        *,
        query: RequestQuery | None = None,
    ) -> JsonObject:
        request = Request(
            _build_url(self.base_url, path, query),
            data=data,
            headers=dict(headers),
            method=method.upper(),
        )

        try:
            response = self._transport(request, timeout=self.timeout)
            with response:
                status = _read_status(response)
                response_body = response.read()
        except HTTPError as error:
            status = int(error.code or 0)
            response_body = error.read()

        return _decode_makepay_response(status, response_body)


def create_anonymous_payment_link(
    payload: Mapping[str, Any],
    *,
    base_url: str = MakePayClient.default_base_url,
    timeout: float = 30,
    transport: Transport | None = None,
) -> JsonObject:
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "User-Agent": f"MakePayPython/{MakePayClient.version}",
    }
    request = Request(
        _build_url(base_url, "/api/partner/v1/makepay/payment-links", None),
        data=json.dumps(dict(payload), separators=(",", ":")).encode("utf-8"),
        headers=headers,
        method="POST",
    )

    try:
        response = (transport or urlopen)(request, timeout=timeout)
        with response:
            status = _read_status(response)
            response_body = response.read()
    except HTTPError as error:
        status = int(error.code or 0)
        response_body = error.read()

    return _decode_makepay_response(status, response_body)


create_anonymous_makepay_payment_link = create_anonymous_payment_link


def build_makepay_hosted_checkout_url(
    payment_uid: str,
    *,
    base_url: str = MakePayClient.default_checkout_base_url,
) -> str:
    _assert_non_empty(payment_uid, "Payment link UID is required.")

    return urljoin(f"{_normalize_base_url(base_url)}/", f"payment/{quote(payment_uid, safe='')}")


def build_makepay_hosted_donation_url(
    donation_slug: str,
    *,
    base_url: str = MakePayClient.default_checkout_base_url,
) -> str:
    _assert_non_empty(donation_slug, "Donation slug is required.")

    return urljoin(
        f"{_normalize_base_url(base_url)}/",
        f"donations/{quote(donation_slug, safe='')}",
    )


def build_makepay_embedded_checkout_url(
    payment_uid: str,
    *,
    base_url: str = MakePayClient.default_checkout_base_url,
    parent_origin: str | None = None,
) -> str:
    _assert_non_empty(payment_uid, "Payment link UID is required.")

    url = urljoin(
        f"{_normalize_base_url(base_url)}/",
        f"embed/payment/{quote(payment_uid, safe='')}",
    )
    if parent_origin:
        url = f"{url}?{urlencode({'parentOrigin': parent_origin})}"

    return url


def build_makepay_embedded_donation_url(
    donation_slug: str,
    *,
    base_url: str = MakePayClient.default_checkout_base_url,
    parent_origin: str | None = None,
) -> str:
    _assert_non_empty(donation_slug, "Donation slug is required.")

    url = urljoin(
        f"{_normalize_base_url(base_url)}/",
        f"embed/donations/{quote(donation_slug, safe='')}",
    )
    if parent_origin:
        url = f"{url}?{urlencode({'parentOrigin': parent_origin})}"

    return url


def build_makepay_modal_script_url(
    *, base_url: str = MakePayClient.default_checkout_base_url
) -> str:
    return urljoin(f"{_normalize_base_url(base_url)}/", "modal/makepay.js")


def build_makepay_embed_button_html(
    payment_uid: str,
    *,
    base_url: str = MakePayClient.default_checkout_base_url,
    button_label: str = "Pay with crypto",
) -> str:
    _assert_non_empty(payment_uid, "Payment link UID is required.")

    return "\n".join(
        [
            f'<script src="{escape(build_makepay_modal_script_url(base_url=base_url), quote=True)}"></script>',
            f'<button type="button" data-makepay-payment-link="{escape(payment_uid, quote=True)}">',
            f"  {escape(button_label, quote=False)}",
            "</button>",
        ]
    )


def build_makepay_iframe_html(
    payment_uid: str,
    *,
    base_url: str = MakePayClient.default_checkout_base_url,
    iframe_title: str = "MakePay checkout",
    parent_origin: str | None = None,
) -> str:
    return "\n".join(
        [
            "<iframe",
            f'  title="{escape(iframe_title, quote=True)}"',
            f'  src="{escape(build_makepay_embedded_checkout_url(payment_uid, base_url=base_url, parent_origin=parent_origin), quote=True)}"',
            '  style="width:100%;min-height:720px;border:0;border-radius:12px;"',
            '  allow="clipboard-read; clipboard-write"',
            "></iframe>",
        ]
    )


def _build_url(
    base_url: str,
    path: str,
    query: RequestQuery | None,
) -> str:
    url = urljoin(f"{_normalize_base_url(base_url)}/", path.lstrip("/"))
    if query:
        clean_query = {key: value for key, value in query.items() if value is not None}
        if clean_query:
            url = f"{url}?{urlencode(clean_query)}"

    return url


def _decode_makepay_response(status: int, response_body: bytes) -> JsonObject:
    decoded = _decode_response_body(response_body)

    if status < 200 or status >= 300:
        raise MakePayError(
            _read_error_message(decoded, status),
            status=status,
            response_body=decoded,
        )

    return decoded if isinstance(decoded, dict) else {}


def _decode_response_body(body: bytes) -> Any:
    if not body:
        return {}

    try:
        return json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {}


def _read_status(response: Any) -> int:
    status = getattr(response, "status", None)
    if status is not None:
        return int(status)

    getcode = getattr(response, "getcode", None)
    if callable(getcode):
        return int(getcode())

    return 0


def _read_error_message(decoded: Any, status: int) -> str:
    if isinstance(decoded, dict) and isinstance(decoded.get("error"), str):
        return decoded["error"]

    return f"MakePay API request failed with HTTP {status}."


def _assert_non_empty(value: str, message: str) -> None:
    if not str(value).strip():
        raise MakePayError(message, status=400)


def _normalize_base_url(base_url: str) -> str:
    return str(base_url).rstrip("/")


def _pick_present(
    input: Mapping[str, Any], keys: Sequence[tuple[str, str]]
) -> dict[str, str]:
    fields: dict[str, str] = {}
    for api_key, python_key in keys:
        value = input.get(api_key, input.get(python_key))
        if value is not None:
            fields[api_key] = str(value)
    return fields


def _read_file_payload(value: Any) -> bytes:
    if isinstance(value, bytes):
        return value
    if isinstance(value, bytearray):
        return bytes(value)
    if isinstance(value, Path):
        return value.read_bytes()
    if isinstance(value, str):
        path = Path(value)
        if path.exists():
            return path.read_bytes()
        return value.encode("utf-8")

    read = getattr(value, "read", None)
    if callable(read):
        content = read()
        if isinstance(content, bytes):
            return content
        if isinstance(content, str):
            return content.encode("utf-8")

    raise MakePayError(
        "Bookkeeping document file must be bytes, a path, or a readable file object.",
        status=400,
    )


def _guess_content_type(file_name: str) -> str:
    return mimetypes.guess_type(file_name)[0] or "application/octet-stream"


def _encode_multipart_form_data(
    fields: Mapping[str, Any],
    files: Sequence[tuple[str, str, bytes, str]],
) -> tuple[bytes, str]:
    boundary = f"makepay-python-{secrets.token_hex(16)}"
    parts: list[bytes] = []

    for name, value in fields.items():
        parts.extend(
            [
                f"--{boundary}\r\n".encode("utf-8"),
                f'Content-Disposition: form-data; name="{_escape_multipart_name(name)}"\r\n\r\n'.encode(
                    "utf-8"
                ),
                str(value).encode("utf-8"),
                b"\r\n",
            ]
        )

    for name, file_name, content, content_type in files:
        parts.extend(
            [
                f"--{boundary}\r\n".encode("utf-8"),
                (
                    "Content-Disposition: form-data; "
                    f'name="{_escape_multipart_name(name)}"; '
                    f'filename="{_escape_multipart_name(file_name)}"\r\n'
                ).encode("utf-8"),
                f"Content-Type: {content_type}\r\n\r\n".encode("utf-8"),
                content,
                b"\r\n",
            ]
        )

    parts.append(f"--{boundary}--\r\n".encode("utf-8"))
    return b"".join(parts), f"multipart/form-data; boundary={boundary}"


def _escape_multipart_name(value: str) -> str:
    return str(value).replace("\\", "\\\\").replace('"', '\\"')


MakePay = MakePayClient
