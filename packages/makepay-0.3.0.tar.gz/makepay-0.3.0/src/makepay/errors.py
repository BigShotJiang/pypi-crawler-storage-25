from __future__ import annotations

from typing import Any


class MakePayError(Exception):
    def __init__(
        self,
        message: str,
        *,
        status: int = 0,
        response_body: Any = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.response_body = response_body
