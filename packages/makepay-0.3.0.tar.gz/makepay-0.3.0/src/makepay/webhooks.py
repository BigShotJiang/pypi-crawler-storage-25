from __future__ import annotations

import hmac
import json
import time
from hashlib import sha256
from typing import Any

from .errors import MakePayError


def verify_makepay_webhook(
    raw_body: str | bytes,
    signature_header: str | None,
    secret: str,
    *,
    tolerance_seconds: int = 300,
) -> bool:
    if not signature_header or not secret:
        return False

    parts = _parse_signature_header(signature_header)
    timestamp_value = parts.get("t")
    signature = parts.get("v1", "")
    if not timestamp_value or not signature or not _is_hex(signature):
        return False

    try:
        timestamp = int(timestamp_value)
    except ValueError:
        return False

    if tolerance_seconds > 0 and abs(int(time.time()) - timestamp) > tolerance_seconds:
        return False

    body = raw_body if isinstance(raw_body, bytes) else raw_body.encode("utf-8")
    expected = hmac.new(
        secret.encode("utf-8"),
        str(timestamp).encode("utf-8") + b"." + body,
        sha256,
    ).hexdigest()

    return hmac.compare_digest(expected, signature.lower())


def parse_makepay_webhook(
    raw_body: str | bytes,
    signature_header: str | None,
    secret: str,
    *,
    tolerance_seconds: int = 300,
) -> dict[str, Any]:
    if not verify_makepay_webhook(
        raw_body,
        signature_header,
        secret,
        tolerance_seconds=tolerance_seconds,
    ):
        raise MakePayError("Invalid MakePay webhook signature.", status=401)

    body = raw_body.decode("utf-8") if isinstance(raw_body, bytes) else raw_body
    try:
        parsed = json.loads(body)
    except json.JSONDecodeError as error:
        raise MakePayError("Invalid MakePay webhook JSON body.", status=400) from error

    if not isinstance(parsed, dict):
        raise MakePayError("Invalid MakePay webhook JSON body.", status=400)

    return parsed


def _parse_signature_header(header: str) -> dict[str, str]:
    parsed: dict[str, str] = {}
    for part in header.split(","):
        key, separator, value = part.strip().partition("=")
        if separator and key:
            parsed[key] = value

    return parsed


def _is_hex(value: str) -> bool:
    try:
        bytes.fromhex(value)
    except ValueError:
        return False

    return True
