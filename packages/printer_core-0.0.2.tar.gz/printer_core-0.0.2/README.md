# printer-core
Foodeo Printer Core
