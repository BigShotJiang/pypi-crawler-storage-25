#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
VENV_PATH="${1:-${HOME}/venv/foodeo-backend}"
ACTIVATE_SCRIPT="${VENV_PATH}/bin/activate"

if [[ ! -f "${ACTIVATE_SCRIPT}" ]]; then
    echo "No existe el virtualenv esperado en: ${VENV_PATH}" >&2
    echo "Pasame la ruta del venv como primer argumento si usa otra ubicacion." >&2
    exit 1
fi

# Instala printer-core en modo editable dentro del venv del backend.
source "${ACTIVATE_SCRIPT}"
python -m pip install -e "${REPO_ROOT}"

echo
echo "printer-core quedo enlazado en modo editable en ${VENV_PATH}."
echo "Los cambios que hagas en ${REPO_ROOT} se reflejaran en ese entorno sin subir a PyPI."
