from decimal import Decimal

import unittest
from printer_core.entities import KitchenProductLine
from printer_core.utils.printer_helpers import build_iva_data, group_products_by_orders, order_products_by_name


class PrinterHelpersTest(unittest.TestCase):
    def test_order_products_by_name(self):
        products = [
            KitchenProductLine(name="Zeta", qty=1, option=None, printer_r="P1", printer_w="80"),
            KitchenProductLine(name="Alpha", qty=1, option=None, printer_r="P1", printer_w="80"),
        ]

        sorted_products = order_products_by_name(products)

        self.assertEqual([item.name for item in sorted_products], ["Alpha", "Zeta"])

    def test_group_products_by_orders(self):
        products = [
            KitchenProductLine(
                name="A",
                qty=1,
                option=None,
                printer_r="P1",
                printer_w="80",
                order="2",
                order_readable="Mesa 2",
            ),
            KitchenProductLine(
                name="B",
                qty=1,
                option=None,
                printer_r="P1",
                printer_w="80",
                order="1",
                order_readable="Mesa 1",
            ),
            KitchenProductLine(
                name="C",
                qty=1,
                option=None,
                printer_r="P1",
                printer_w="80",
                order=None,
            ),
            KitchenProductLine(
                name="D",
                qty=1,
                option=None,
                printer_r="P1",
                printer_w="80",
                order="not-a-number",
            ),
        ]

        grouped = group_products_by_orders(products)

        self.assertEqual(grouped[0].group, "Mesa 1")
        self.assertEqual(grouped[0].products[0].order, "1")
        self.assertEqual(grouped[1].group, "Mesa 2")
        self.assertEqual(grouped[1].products[0].order, "2")
        self.assertEqual(grouped[2].group, "Sin orden")
        self.assertEqual([item.name for item in grouped[2].products], ["C"])

    def test_build_iva_data(self):
        data = build_iva_data(Decimal("121.00"), Decimal("21"))

        self.assertEqual(data.Base, "100.00")
        self.assertEqual(data.impo, "21.00")
        self.assertEqual(data.iva, "21")
