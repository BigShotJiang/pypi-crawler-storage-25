from unittest.mock import patch

import unittest
from printer_core.entities import PrintChannel
from printer_core.services.flows.client import ClientPrintFlow
from printer_core.services.flows.kitchen import KitchenPrintFlow

from printer_core.tests.unitaries.helpers import (
    FakeGateway,
    FakeHeaderProvider,
    FakePrintSettingsBuilder,
    make_kitchen_settings,
    make_printer,
    make_product,
    make_request,
    make_ticket_settings,
)


class ClientPrintFlowTest(unittest.TestCase):
    def test_execute_requires_tpv_key(self):
        flow = ClientPrintFlow(
            gateway=FakeGateway(),
            header_provider=FakeHeaderProvider(),
            print_settings_builder=FakePrintSettingsBuilder(),
            currency_symbol_resolver=lambda _: "",
            domicile_service_label="Service",
        )

        with self.assertRaises(ValueError):
            flow.execute(
                base_request=make_request(),
                products=[make_product()],
                context=type("Ctx", (), {"kitchen_settings": make_kitchen_settings(), "ticket_settings": make_ticket_settings(), "main_printer": make_printer(), "worker": None})(),
                channel=PrintChannel.LOCAL,
                tpv_key="",
            )

    def test_execute_sends_payload(self):
        gateway = FakeGateway()
        flow = ClientPrintFlow(
            gateway=gateway,
            header_provider=FakeHeaderProvider(),
            print_settings_builder=FakePrintSettingsBuilder(),
            currency_symbol_resolver=lambda _: "",
            domicile_service_label="Service",
        )
        context = type("Ctx", (), {
            "kitchen_settings": make_kitchen_settings(),
            "ticket_settings": make_ticket_settings(),
            "main_printer": make_printer(),
            "worker": None,
        })()

        flow.execute(
            base_request=make_request(request_type="local", from_client="web"),
            products=[make_product()],
            context=context,
            channel=PrintChannel.LOCAL,
            tpv_key="TPV1",
        )

        self.assertEqual(len(gateway.calls), 1)
        payload = gateway.calls[0][1][0]
        self.assertEqual(payload["company_key"], "TPV1")
        self.assertEqual(payload["data"]["PrintSettings"]["show_header"], False)
        self.assertEqual(payload["data"]["headerData"]["client_name"], "local:web")


class KitchenPrintFlowTest(unittest.TestCase):
    def test_execute_uses_multi_printer_service(self):
        captured = {}

        class DummyService:
            def __init__(self, **kwargs):
                pass

            def build_and_dispatch(self, request, products, main_printer, ticket_settings, kitchen_ticket_settings):
                captured["request"] = request
                return []

        with patch("printer_core.services.flows.kitchen.MultiPrinterService", DummyService):
            flow = KitchenPrintFlow(
                gateway=FakeGateway(),
                header_provider=FakeHeaderProvider(),
                print_settings_builder=FakePrintSettingsBuilder(),
                family_provider=object(),
                currency_symbol_resolver=lambda _: "",
            )
            context = type("Ctx", (), {
                "ticket_settings": make_ticket_settings(),
                "kitchen_settings": make_kitchen_settings(print_by="categories"),
                "main_printer": make_printer(),
                "worker": None,
            })()

            flow.execute(
                base_request=make_request(request_type="local"),
                products=[make_product()],
                context=context,
                channel=PrintChannel.LOCAL,
                tpv_key="TPV1",
            )

        self.assertEqual(captured["request"].print_by, "categories")

    def test_execute_uses_family_service_and_skips_print_by(self):
        captured = {}

        class DummyFamilyService:
            def __init__(self, **kwargs):
                pass

            def build_and_dispatch(self, request, products, main_printer, ticket_settings, kitchen_ticket_settings):
                captured["request"] = request
                return []

        with patch("printer_core.services.flows.kitchen.MultiPrinterFamilyService", DummyFamilyService):
            flow = KitchenPrintFlow(
                gateway=FakeGateway(),
                header_provider=FakeHeaderProvider(),
                print_settings_builder=FakePrintSettingsBuilder(),
                family_provider=object(),
                currency_symbol_resolver=lambda _: "",
            )
            context = type("Ctx", (), {
                "ticket_settings": make_ticket_settings(),
                "kitchen_settings": make_kitchen_settings(print_by="families"),
                "main_printer": make_printer(),
                "worker": None,
            })()

            flow.execute(
                base_request=make_request(request_type="barra"),
                products=[make_product()],
                context=context,
                channel=PrintChannel.BARRA,
                tpv_key="TPV1",
            )

        self.assertIsNone(captured["request"].print_by)
