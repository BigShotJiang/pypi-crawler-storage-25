import unittest
from printer_core.builders.printer_products_grouper import PrinterProductsGrouper
from printer_core.entities import KitchenProductLine


class PrinterProductsGrouperTest(unittest.TestCase):
    def test_group_by_printer_key(self):
        products = [
            KitchenProductLine(name="A", qty=1, option=None, printer_r="P1", printer_w="80", tpv="TPV1"),
            KitchenProductLine(name="B", qty=1, option=None, printer_r="P1", printer_w="80", tpv="TPV1"),
            KitchenProductLine(name="C", qty=1, option=None, printer_r="P2", printer_w="58", tpv="TPV2"),
        ]

        grouped = PrinterProductsGrouper.group_by_printer_key(products)

        self.assertEqual(len(grouped), 2)
        self.assertEqual(grouped[0].printer_name, "P1")
        self.assertEqual(len(grouped[0].products), 2)
        self.assertEqual(grouped[1].printer_name, "P2")
        self.assertEqual(len(grouped[1].products), 1)
