from unittest.mock import patch

import unittest
from printer_core.services.multi_printer_service import MultiPrinterService

from printer_core.tests.unitaries.helpers import FakeGateway, make_kitchen_settings, make_printer, make_product, make_request, make_ticket_settings


class MultiPrinterServiceTest(unittest.TestCase):
    def test_build_and_dispatch_groups_by_printer(self):
        gateway = FakeGateway()
        request = make_request(order_by="name")
        products = [
            make_product(name="B", printer=[make_printer(name="P1", printer_width="80", tpv="TPV1")]),
            make_product(name="A", printer=[make_printer(name="P2", printer_width="58", tpv="TPV2")]),
        ]
        kitchen_settings = make_kitchen_settings(show_price_per_unit=False)
        ticket_settings = make_ticket_settings()
        captured: dict[str, object] = {}

        class DummyDispatcher:
            def __init__(self, gateway):
                self._gateway = gateway

            def dispatch(self, request, grouped_products, ticket_settings, kitchen_ticket_settings, group_products_func):
                captured["grouped"] = grouped_products
                captured["group_func"] = group_products_func
                return []

        def reverse_order(items):
            return list(reversed(items))

        with patch("printer_core.services.multi_printer_service.KitchenTicketDispatcher", DummyDispatcher):
            service = MultiPrinterService(
                gateway=gateway,
                currency_symbol_resolver=lambda _: "",
                order_by_func=reverse_order,
                group_products_func=lambda items: [],
            )
            service.build_and_dispatch(
                request=request,
                products=products,
                main_printer=make_printer(name="Main"),
                ticket_settings=ticket_settings,
                kitchen_ticket_settings=kitchen_settings,
            )

        grouped = captured["grouped"]
        self.assertEqual(len(grouped), 2)
        self.assertEqual({group.printer_name for group in grouped}, {"P1", "P2"})
        self.assertEqual(captured["group_func"].__name__, "<lambda>")
