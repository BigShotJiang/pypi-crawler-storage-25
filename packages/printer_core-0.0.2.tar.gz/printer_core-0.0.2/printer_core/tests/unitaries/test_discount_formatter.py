import unittest
from printer_core.entities import DiscountData
from printer_core.formatters.discount_formatter import DiscountFormatter

from printer_core.tests.unitaries.helpers import make_product


class DiscountFormatterTest(unittest.TestCase):
    def test_format_number_discount(self):
        formatter = DiscountFormatter(currency_symbol_resolver=lambda _: "€")
        product = make_product(total_price="5.00", discount_type="number")

        result = formatter.format(product, "EUR")

        self.assertEqual(result, " (Dto 5.00€)")

    def test_format_percent_discount(self):
        formatter = DiscountFormatter(currency_symbol_resolver=lambda _: "€")
        product = make_product(
            total_price="90",
            product_price="100",
            discount_type="percent",
            discount=DiscountData(value="10", type="percent"),
            importe="100",
        )

        result = formatter.format(product, "EUR")

        self.assertEqual(result, " (Dto 10% 10€)")

    def test_format_without_discount(self):
        formatter = DiscountFormatter(currency_symbol_resolver=lambda _: "€")
        product = make_product(total_price="90", product_price="100")

        result = formatter.format(product, "EUR")

        self.assertEqual(result, "")
