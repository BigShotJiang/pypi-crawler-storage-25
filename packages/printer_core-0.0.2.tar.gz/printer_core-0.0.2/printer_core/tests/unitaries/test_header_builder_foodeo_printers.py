import unittest
from printer_core.builders.header_builder import HeaderBuilder
from printer_core.entities import PrintRequestData


class FakeHeaderDataProvider:
    def __init__(self):
        self.calls: list[tuple[str, object | None, object | None]] = []

    def get_company_header(self) -> dict[str, str]:
        return {"company_name": "Company"}

    def get_worker_header(self, user: object) -> dict[str, str]:
        return {"worker_name": getattr(user, "first_name", "")}

    def get_pickup_client_header(self, client_id: int | None, from_client: str | None) -> dict[str, str]:
        self.calls.append(("pickup", client_id, from_client))
        return {"client_name": f"pickup:{client_id}:{from_client}"}

    def get_domicile_client_header(self, address_id: int | None, from_client: str | None) -> dict[str, str]:
        self.calls.append(("domicile", address_id, from_client))
        return {"client_name": f"domicile:{address_id}:{from_client}"}


class FakeUser:
    def __init__(self, first_name: str):
        self.first_name = first_name


class HeaderBuilderTest(unittest.TestCase):
    def test_build_header_with_worker_and_pickup(self):
        provider = FakeHeaderDataProvider()
        builder = HeaderBuilder(provider=provider, show_person_name=True)
        request = PrintRequestData(
            id=1,
            type="recoger",
            serial="S1",
            credit_card=False,
            request_price="10.00",
            from_client="web",
            client=10,
        )

        header = builder.build_header(request, worker=FakeUser("Ana"))

        self.assertEqual(header.company_name, "Company")
        self.assertEqual(header.worker_name, "Ana")
        self.assertEqual(header.client_name, "pickup:10:web")
        self.assertEqual(provider.calls, [("pickup", 10, "web")])

    def test_build_header_domicile_without_worker(self):
        provider = FakeHeaderDataProvider()
        builder = HeaderBuilder(provider=provider, show_person_name=False)
        request = PrintRequestData(
            id=1,
            type="domicilio",
            serial="S1",
            credit_card=False,
            request_price="10.00",
            from_client="apk",
            address=20,
        )

        header = builder.build_header(request)

        self.assertEqual(header.company_name, "Company")
        self.assertIsNone(header.worker_name)
        self.assertEqual(header.client_name, "domicile:20:apk")
        self.assertEqual(provider.calls, [("domicile", 20, "apk")])

    def test_build_header_for_other_types(self):
        provider = FakeHeaderDataProvider()
        builder = HeaderBuilder(provider=provider, show_person_name=False)
        request = PrintRequestData(
            id=1,
            type="local",
            serial="S1",
            credit_card=False,
            request_price="10.00",
            from_client="web",
        )

        header = builder.build_header(request)

        self.assertEqual(header.company_name, "Company")
        self.assertIsNone(header.client_name)
        self.assertEqual(provider.calls, [])
