import unittest
from printer_core.entities import FamilyData
from printer_core.selectors.family_product_selector import FamilyProductSelector

from printer_core.tests.unitaries.helpers import FakeFamilyProvider, make_product


class FamilyProductSelectorTest(unittest.TestCase):
    def test_group_products(self):
        family_1 = FamilyData(id=1, name="Family 1")
        family_2 = FamilyData(id=2, name="Family 2")
        provider = FakeFamilyProvider(
            families=[family_1, family_2],
            family_by_category={10: family_1, 20: family_2},
        )
        selector = FamilyProductSelector(provider=provider)
        products = [
            make_product(name="A", category=10),
            make_product(name="B", category=20),
            make_product(name="C", category=None),
        ]

        families, products_by_family, products_without_family = selector.group_products(products)

        self.assertEqual(families, [family_1, family_2])
        self.assertEqual([p.product_name for p in products_by_family[1]], ["A"])
        self.assertEqual([p.product_name for p in products_by_family[2]], ["B"])
        self.assertEqual([p.product_name for p in products_without_family], ["C"])
