import unittest
from printer_core.builders.kitchen_ticket_payload_builder import KitchenTicketPayloadBuilder
from printer_core.entities import KitchenProductLine, PrintSettingsData, ProductsGroup

from printer_core.tests.unitaries.helpers import FakeClock, make_kitchen_settings, make_request, make_ticket_settings


class KitchenTicketPayloadBuilderTest(unittest.TestCase):
    def test_build_sets_model_and_created_at(self):
        builder = KitchenTicketPayloadBuilder(clock=FakeClock("2024-01-02 12:00"))
        request = make_request(request_type="local")
        products = [KitchenProductLine(name="A", qty=1, option=None, printer_r="P1", printer_w="80")]
        ticket_settings = make_ticket_settings(qty_kitchen_ticket=2)
        kitchen_settings = make_kitchen_settings(show_total_price=False, show_command_guests=False)

        payload = builder.build(
            request=request,
            printer_name="P1",
            tpv_key="TPV1",
            printer_width="80",
            products=products,
            ticket_settings=ticket_settings,
            kitchen_ticket_settings=kitchen_settings,
            group_products_func=lambda items: [ProductsGroup(group="G", products=items)],
        )

        self.assertEqual(payload.model, 1)
        self.assertEqual(payload.data.created_at, "2024-01-02 12:00")
        self.assertEqual(payload.printer_qty, 2)

    def test_build_uses_shift_time_for_domicile(self):
        builder = KitchenTicketPayloadBuilder(clock=FakeClock("2024-01-02 12:00"))
        request = make_request(
            request_type="domicilio",
            shift_time="10:30",
            delivery_date="2024-03-10",
        )
        products = [KitchenProductLine(name="A", qty=1, option=None, printer_r="P1", printer_w="80")]
        payload = builder.build(
            request=request,
            printer_name="P1",
            tpv_key="TPV1",
            printer_width="80",
            products=products,
            ticket_settings=make_ticket_settings(),
            kitchen_ticket_settings=make_kitchen_settings(),
            group_products_func=lambda items: [ProductsGroup(group="G", products=items)],
        )

        self.assertEqual(payload.data.created_at, "2024-03-10 10:30")
        self.assertEqual(payload.model, 2)

    def test_build_includes_total_and_command_guests(self):
        builder = KitchenTicketPayloadBuilder(clock=FakeClock())
        request = make_request(request_type="local", total="12.00", request_price="10.00", command_guests=3)
        products = [KitchenProductLine(name="A", qty=1, option=None, printer_r="P1", printer_w="80")]
        kitchen_settings = make_kitchen_settings(show_total_price=True, show_command_guests=True)

        payload = builder.build(
            request=request,
            printer_name="P1",
            tpv_key="TPV1",
            printer_width="80",
            products=products,
            ticket_settings=make_ticket_settings(),
            kitchen_ticket_settings=kitchen_settings,
            group_products_func=lambda items: [ProductsGroup(group="G", products=items)],
        )

        self.assertEqual(payload.data.total, "12.00")
        self.assertEqual(payload.data.request_price, "10.00")
        self.assertEqual(payload.data.command_guests, 3)

    def test_build_groups_products_when_enabled(self):
        builder = KitchenTicketPayloadBuilder(clock=FakeClock())
        request = make_request(request_type="local", group_by_orders=True)
        products = [KitchenProductLine(name="A", qty=1, option=None, printer_r="P1", printer_w="80")]
        kitchen_settings = make_kitchen_settings(show_total_price=False, show_command_guests=False)

        payload = builder.build(
            request=request,
            printer_name="P1",
            tpv_key="TPV1",
            printer_width="80",
            products=products,
            ticket_settings=make_ticket_settings(),
            kitchen_ticket_settings=kitchen_settings,
            group_products_func=lambda items: [ProductsGroup(group="G", products=items)],
        )

        self.assertIsNone(payload.data.products)
        self.assertEqual(payload.data.products_groups[0].group, "G")

    def test_build_print_settings_overrides_show_header(self):
        builder = KitchenTicketPayloadBuilder(clock=FakeClock())
        request = make_request(
            request_type="local",
            PrintSettings=PrintSettingsData(show_header=True, show_local_header=False),
        )
        products = [KitchenProductLine(name="A", qty=1, option=None, printer_r="P1", printer_w="80")]

        payload = builder.build(
            request=request,
            printer_name="P1",
            tpv_key="TPV1",
            printer_width="80",
            products=products,
            ticket_settings=make_ticket_settings(),
            kitchen_ticket_settings=make_kitchen_settings(),
            group_products_func=lambda items: [ProductsGroup(group="G", products=items)],
        )

        self.assertEqual(payload.PrintSettings.show_header, False)
