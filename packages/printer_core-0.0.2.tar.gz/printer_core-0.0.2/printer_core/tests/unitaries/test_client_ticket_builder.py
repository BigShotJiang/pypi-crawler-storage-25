import unittest
from printer_core.builders.client_ticket_builder import ClientTicketBuilder
from printer_core.entities import DiscountData

from printer_core.tests.unitaries.helpers import make_printer, make_product, make_request, make_ticket_settings


class ClientTicketBuilderTest(unittest.TestCase):
    def test_build_removes_details_for_local(self):
        builder = ClientTicketBuilder(currency_symbol_resolver=lambda _: "€")
        request = make_request(request_type="local", details="Some details")
        products = [make_product()]
        printer = make_printer()
        ticket_settings = make_ticket_settings(ticket_text="Text", qty_client_ticket=2)

        payloads = builder.build(
            request=request,
            products=products,
            printer=printer,
            ticket_settings=ticket_settings,
            tpv_key="TPV1",
        )

        self.assertIsNone(payloads[0].data.details)
        self.assertEqual(payloads[0].printer_qty, 2)
        self.assertEqual(payloads[0].data.ticket_text, "Text")

    def test_build_keeps_details_for_domicile(self):
        builder = ClientTicketBuilder()
        request = make_request(request_type="domicilio", details=None)
        products = [make_product()]
        payloads = builder.build(
            request=request,
            products=products,
            printer=make_printer(),
            ticket_settings=make_ticket_settings(),
            tpv_key="TPV1",
        )

        self.assertEqual(payloads[0].data.details, "")

    def test_build_formats_discount(self):
        builder = ClientTicketBuilder(currency_symbol_resolver=lambda _: "€")
        request = make_request()
        products = [
            make_product(
                total_price="90",
                product_price="100",
                discount_type="percent",
                discount=DiscountData(value="10", type="percent"),
                importe="100",
            )
        ]
        payloads = builder.build(
            request=request,
            products=products,
            printer=make_printer(),
            ticket_settings=make_ticket_settings(),
            tpv_key="TPV1",
        )

        self.assertIn("Dto 10% 10€", payloads[0].data.products[0].name)

    def test_build_adds_domicile_service_line(self):
        builder = ClientTicketBuilder(domicile_service_label="Service")
        request = make_request(request_type="domicilio", price_domicile_service="2.00")
        products = [make_product()]

        payloads = builder.build(
            request=request,
            products=products,
            printer=make_printer(),
            ticket_settings=make_ticket_settings(),
            tpv_key="TPV1",
        )

        self.assertEqual(payloads[0].data.products[-1].name, "Service")
        self.assertEqual(payloads[0].data.products[-1].price, "2.00")
