import unittest
from printer_core.entities import MarchCommandData, PrintSettingsData
from printer_core.services.march_printer_service import MarchPrinterService

from printer_core.tests.unitaries.helpers import FakeClock, FakeGateway, make_printer


class MarchPrinterServiceTest(unittest.TestCase):
    def test_build_and_send(self):
        gateway = FakeGateway()
        clock = FakeClock("2024-02-01 09:00")
        service = MarchPrinterService(gateway=gateway, clock=clock)
        printers = [make_printer(name="P1", tpv="TPV1"), make_printer(name="P2", tpv="TPV1")]
        command_data = MarchCommandData(table_name="T1", credit_card=False, serial="S1", type="local")
        print_settings = PrintSettingsData(show_header=False)

        payloads = service.build_and_send(
            printers=printers,
            command_data=command_data,
            order_type_text="Marchar primeros",
            tpv_key="TPV1",
            currency="EUR",
            print_settings=print_settings,
            printer_qty=2,
        )

        self.assertEqual(len(payloads), 2)
        self.assertEqual(payloads[0].data.created_at, "2024-02-01 09:00")
        self.assertEqual(payloads[0].printer_qty, 2)
        self.assertEqual(len(gateway.calls), 2)
        self.assertEqual(gateway.calls[0][1][0]["printer"], "P1")
