import unittest
from printer_core.entities import PrintChannel, PrintJob
from printer_core.services.order_print_service import OrderPrintService
from printer_core.services.print_policy import FlowTarget

from printer_core.tests.unitaries.helpers import (
    FakeClock,
    make_discount,
    make_global_settings,
    make_kitchen_settings,
    make_product,
    make_request,
    make_ticket_settings,
)


class FakeFlow:
    def __init__(self, target: FlowTarget, return_value: list[object]):
        self.target = target
        self.return_value = return_value
        self.calls: list[dict[str, object]] = []

    def execute(self, base_request, products, context, channel, tpv_key=None):
        self.calls.append({
            "base_request": base_request,
            "products": products,
            "context": context,
            "channel": channel,
            "tpv_key": tpv_key,
        })
        return self.return_value


class OrderPrintServiceTest(unittest.TestCase):
    def test_print_job_enriches_request_and_runs_flows(self):
        kitchen_flow = FakeFlow(FlowTarget.KITCHEN, return_value=[{"kitchen": True}])
        client_flow = FakeFlow(FlowTarget.CLIENT, return_value=[{"client": True}])
        service = OrderPrintService(
            flows=[kitchen_flow, client_flow],
        )
        request = make_request(
            request_type="local",
            currency=None,
            discount=make_discount(),
            price_domicile_service="2.00",
        )
        job = PrintJob(request=request, products=[make_product()], tpv_key="TPV1")
        context = type("Ctx", (), {
            "ticket_settings": make_ticket_settings(ticket_kitchen_local=True, ticket_client_local=True),
            "kitchen_settings": make_kitchen_settings(print_by="categories"),
            "global_settings": make_global_settings(currency="EUR", iva=21),
        })()

        result = service.print_job(job, context, PrintChannel.LOCAL)

        self.assertEqual(result.multi_printer, [{"kitchen": True}])
        self.assertEqual(result.ticket_client, [{"client": True}])
        enriched = kitchen_flow.calls[0]["base_request"]
        self.assertIsNone(enriched.discount)
        self.assertEqual(enriched.currency, "EUR")
        self.assertEqual(enriched.price_domicile_service, None)
        self.assertIsNotNone(enriched.ivaData)

    def test_print_job_domicile_total_includes_service_price(self):
        kitchen_flow = FakeFlow(FlowTarget.KITCHEN, return_value=[])
        service = OrderPrintService(
            flows=[kitchen_flow],
        )
        service._clock = FakeClock("2024-05-01 08:00")
        request = make_request(
            request_type="domicilio",
            request_price="10.00",
            price_domicile_service="2.00",
        )
        job = PrintJob(request=request, products=[make_product()], tpv_key="TPV1")
        context = type("Ctx", (), {
            "ticket_settings": make_ticket_settings(ticket_kitchen_domicile_or_pickup=True),
            "kitchen_settings": make_kitchen_settings(print_by="categories"),
            "global_settings": make_global_settings(currency="EUR", iva=21),
        })()

        service.print_job(job, context, PrintChannel.DOMICILE)

        enriched = kitchen_flow.calls[0]["base_request"]
        self.assertEqual(enriched.total, "12.00")
        self.assertEqual(enriched.price_domicile_service, "2.00")

    def test_print_job_overrides_created_at_for_barra(self):
        kitchen_flow = FakeFlow(FlowTarget.KITCHEN, return_value=[])
        service = OrderPrintService(
            flows=[kitchen_flow],
        )
        service._clock = FakeClock("2024-05-01 08:00")
        request = make_request(request_type="barra", created_at="old")
        job = PrintJob(request=request, products=[make_product()], tpv_key="TPV1")
        context = type("Ctx", (), {
            "ticket_settings": make_ticket_settings(ticket_kitchen_barra=True),
            "kitchen_settings": make_kitchen_settings(print_by="categories"),
            "global_settings": make_global_settings(currency="EUR", iva=21),
        })()

        service.print_job(job, context, PrintChannel.BARRA)

        enriched = kitchen_flow.calls[0]["base_request"]
        self.assertEqual(enriched.created_at, "2024-05-01 08:00")

    def test_print_job_skips_flows_when_disabled(self):
        kitchen_flow = FakeFlow(FlowTarget.KITCHEN, return_value=[])
        service = OrderPrintService(
            flows=[kitchen_flow],
        )
        request = make_request(request_type="local")
        job = PrintJob(request=request, products=[make_product()], tpv_key="TPV1")
        context = type("Ctx", (), {
            "ticket_settings": make_ticket_settings(ticket_kitchen_local=False, ticket_client_local=False),
            "kitchen_settings": make_kitchen_settings(print_by="categories"),
            "global_settings": make_global_settings(currency="EUR", iva=21),
        })()

        result = service.print_job(job, context, PrintChannel.LOCAL)

        self.assertEqual(kitchen_flow.calls, [])
        self.assertIsNone(result.multi_printer)
        self.assertIsNone(result.ticket_client)
