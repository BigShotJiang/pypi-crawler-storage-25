import json
import os
from pathlib import Path
from types import SimpleNamespace

import unittest
from printer_core.dispatchers.kitchen_ticket_dispatcher import KitchenTicketDispatcher
from printer_core.entities import HeaderData, KitchenProductLine, PrintChannel, PrinterProductGroup
from printer_core.services.flows.client import ClientPrintFlow

from printer_core.tests.unitaries.helpers import (
    FakeGateway,
    FakeHeaderProvider,
    FakePrintSettingsBuilder,
    make_kitchen_settings,
    make_printer,
    make_product,
    make_request,
    make_ticket_settings,
)


def _should_dump_cases() -> bool:
    return os.getenv("FOODEO_PRINTERS_DUMP_CASES", "").lower() in {"1", "true", "yes"}


def _dump_case_output(case_id: str, flow: str, input_data: dict[str, object], ws_payload: object) -> None:
    if not _should_dump_cases():
        return
    dump_dir = Path(os.getenv("FOODEO_PRINTERS_DUMP_DIR", "tmp/foodeo_printers_cases"))
    dump_dir.mkdir(parents=True, exist_ok=True)
    path = dump_dir / f"{case_id}_{flow}.json"
    payload = {
        "case_id": case_id,
        "flow": flow,
        "input": input_data,
        "ws_payload": ws_payload,
    }
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=True, indent=2, sort_keys=True)


CASES_ALL = [
    ("CASE01", "local", "web", PrintChannel.LOCAL),
    ("CASE02", "local", "apk", PrintChannel.LOCAL),
    ("CASE03", "local", "web_sales", PrintChannel.LOCAL),
    ("CASE04", "local", "kiosko", PrintChannel.LOCAL),
    ("CASE05", "barra", "web", PrintChannel.BARRA),
    ("CASE06", "barra", "apk", PrintChannel.BARRA),
    ("CASE07", "barra", "web_sales", PrintChannel.BARRA),
    ("CASE08", "barra", "kiosko", PrintChannel.BARRA),
    ("CASE09", "kiosko", "web", PrintChannel.KIOSKO),
    ("CASE10", "kiosko", "apk", PrintChannel.KIOSKO),
    ("CASE11", "kiosko", "web_sales", PrintChannel.KIOSKO),
    ("CASE12", "kiosko", "kiosko", PrintChannel.KIOSKO),
    ("CASE13", "domicilio", "web", PrintChannel.DOMICILE),
    ("CASE14", "domicilio", "apk", PrintChannel.DOMICILE),
    ("CASE15", "domicilio", "kiosko", PrintChannel.DOMICILE),
    ("CASE16", "domicilio", "web_sales", PrintChannel.DOMICILE),
    ("CASE17", "recoger", "web", PrintChannel.PICKUP),
    ("CASE18", "recoger", "apk", PrintChannel.PICKUP),
    ("CASE19", "recoger", "kiosko", PrintChannel.PICKUP),
    ("CASE20", "recoger", "web_sales", PrintChannel.PICKUP),
    ("CASE21", "local", "web", PrintChannel.LOCAL),
    ("CASE22", "local", "apk", PrintChannel.LOCAL),
    ("CASE23", "local", "web_sales", PrintChannel.LOCAL),
    ("CASE24", "local", "kiosko", PrintChannel.LOCAL),
    ("CASE25", "barra", "web", PrintChannel.BARRA),
    ("CASE26", "barra", "apk", PrintChannel.BARRA),
    ("CASE27", "barra", "web_sales", PrintChannel.BARRA),
    ("CASE28", "barra", "kiosko", PrintChannel.BARRA),
    ("CASE29", "kiosko", "web", PrintChannel.KIOSKO),
    ("CASE30", "kiosko", "apk", PrintChannel.KIOSKO),
    ("CASE31", "kiosko", "web_sales", PrintChannel.KIOSKO),
    ("CASE32", "kiosko", "kiosko", PrintChannel.KIOSKO),
    ("CASE33", "domicilio", "web", PrintChannel.DOMICILE),
    ("CASE34", "domicilio", "apk", PrintChannel.DOMICILE),
    ("CASE35", "domicilio", "web_sales", PrintChannel.DOMICILE),
    ("CASE36", "domicilio", "kiosko", PrintChannel.DOMICILE),
    ("CASE37", "recoger", "web", PrintChannel.PICKUP),
    ("CASE38", "recoger", "apk", PrintChannel.PICKUP),
    ("CASE39", "recoger", "web_sales", PrintChannel.PICKUP),
    ("CASE40", "recoger", "kiosko", PrintChannel.PICKUP),
    ("CASE41", "domicilio", "web", PrintChannel.DOMICILE),
    ("CASE42", "domicilio", "apk", PrintChannel.DOMICILE),
    ("CASE43", "domicilio", "web_sales", PrintChannel.DOMICILE),
    ("CASE44", "domicilio", "kiosko", PrintChannel.DOMICILE),
    ("CASE45", "recoger", "web", PrintChannel.PICKUP),
    ("CASE46", "recoger", "apk", PrintChannel.PICKUP),
    ("CASE47", "recoger", "web_sales", PrintChannel.PICKUP),
    ("CASE48", "recoger", "kiosko", PrintChannel.PICKUP),
]


class CasesOutputTest(unittest.TestCase):
    def test_client_flow_outputs_for_cases(self):
        for case_id, request_type, from_client, channel in CASES_ALL:
            with self.subTest(case=case_id):
                gateway = FakeGateway()
                base_request = make_request(request_type=request_type, from_client=from_client)
                products = [make_product()]
                flow = ClientPrintFlow(
                    gateway=gateway,
                    header_provider=FakeHeaderProvider(),
                    print_settings_builder=FakePrintSettingsBuilder(),
                    currency_symbol_resolver=lambda _: "",
                    domicile_service_label="Service",
                )
                context = SimpleNamespace(
                    kitchen_settings=make_kitchen_settings(),
                    ticket_settings=make_ticket_settings(),
                    main_printer=make_printer(),
                    worker=None,
                )
                flow.execute(
                    base_request=base_request,
                    products=products,
                    context=context,
                    channel=channel,
                    tpv_key="TPV1",
                )

                payload = gateway.calls[0][1][0]
                _dump_case_output(
                    case_id=case_id,
                    flow="client",
                    input_data={
                        "request": base_request.model_dump(mode="json", exclude_none=True),
                        "products": [product.model_dump(mode="json", exclude_none=True) for product in products],
                        "channel": channel.value,
                        "tpv_key": "TPV1",
                        "ticket_settings": vars(context.ticket_settings),
                        "kitchen_settings": vars(context.kitchen_settings),
                        "main_printer": context.main_printer.model_dump(mode="json", exclude_none=True),
                    },
                    ws_payload=gateway.calls[0][1],
                )
                self.assertEqual(payload["data"]["headerData"]["client_name"], f"{request_type}:{from_client}")
                if channel == PrintChannel.LOCAL:
                    self.assertEqual(payload["data"]["PrintSettings"]["show_header"], False)
                else:
                    self.assertEqual(payload["data"]["PrintSettings"]["show_header"], True)

    def test_kitchen_dispatcher_outputs_for_cases(self):
        for case_id, request_type, from_client, channel in CASES_ALL:
            with self.subTest(case=case_id):
                gateway = FakeGateway()
                request = make_request(
                    request_type=request_type,
                    from_client=from_client,
                    headerData=HeaderData(client_name=f"{request_type}:{from_client}"),
                )
                dispatcher = KitchenTicketDispatcher(gateway=gateway)
                grouped_products = [
                    PrinterProductGroup(
                        printer_name="P1",
                        tpv_key="TPV1",
                        printer_width="80",
                        products=[KitchenProductLine(name="A", qty=1, option=None, printer_r="P1", printer_w="80")],
                    )
                ]
                ticket_settings = make_ticket_settings()
                kitchen_ticket_settings = make_kitchen_settings()

                dispatcher.dispatch(
                    request=request,
                    grouped_products=grouped_products,
                    ticket_settings=ticket_settings,
                    kitchen_ticket_settings=kitchen_ticket_settings,
                    group_products_func=lambda items: [],
                )

                payload = gateway.calls[0][1][0]
                _dump_case_output(
                    case_id=case_id,
                    flow="kitchen",
                    input_data={
                        "request": request.model_dump(mode="json", exclude_none=True),
                        "grouped_products": [group.model_dump(mode="json", exclude_none=True) for group in grouped_products],
                        "ticket_settings": vars(ticket_settings),
                        "kitchen_ticket_settings": vars(kitchen_ticket_settings),
                    },
                    ws_payload=gateway.calls[0][1],
                )
                expected_model = 1 if request_type == "local" else 2
                self.assertEqual(payload["model"], expected_model)
                self.assertEqual(payload["data"]["headerData"]["client_name"], f"{request_type}:{from_client}")
                self.assertEqual(payload["printer"], "P1")
                self.assertEqual(payload["company_key"], "TPV1")
