from __future__ import annotations

from types import SimpleNamespace

from printer_core.entities import (
    DiscountData,
    FamilyData,
    HeaderData,
    PrintProductData,
    PrintRequestData,
    PrintSettingsData,
    PrinterData,
)


class FakeGateway:
    def __init__(self):
        self.calls: list[tuple[str, object]] = []

    def send_data(self, tpv_key: str, data: object) -> None:
        self.calls.append((tpv_key, data))


class FakeClock:
    def __init__(self, now_value: str = "2024-01-01 10:00"):
        self._now_value = now_value

    def now_iso(self) -> str:
        return self._now_value


class FakeHeaderProvider:
    def build_header(self, request: PrintRequestData, worker: object | None = None) -> HeaderData:
        worker_name = getattr(worker, "first_name", None) if worker else None
        return HeaderData(
            company_name="Company",
            worker_name=worker_name,
            client_name=f"{request.type}:{request.from_client}",
        )


class FakePrintSettingsBuilder:
    def __init__(self, settings: PrintSettingsData | None = None):
        self._settings = settings or PrintSettingsData(
            show_header=True,
            show_total_price=True,
            show_price_per_unit=False,
            show_local_header=None,
            details_font={"size": 10},
        )

    def build(self, kitchen_ticket_settings: object) -> PrintSettingsData:
        return self._settings


class FakeFamilyProvider:
    def __init__(self, families: list[FamilyData], family_by_category: dict[int, FamilyData]):
        self._families = families
        self._family_by_category = family_by_category

    def get_families(self) -> list[FamilyData]:
        return self._families

    def get_family_by_category_ids(self, category_ids: list[int]) -> dict[int, FamilyData]:
        return {cid: self._family_by_category[cid] for cid in category_ids if cid in self._family_by_category}


def make_discount(value: str = "10", discount_type: str = "percent", total: str = "0") -> DiscountData:
    return DiscountData(value=value, type=discount_type, total=total)


def make_request(
    request_type: str = "local",
    from_client: str = "web",
    credit_card: bool = False,
    request_price: str = "10.00",
    currency: str | None = "EUR",
    all_discounted: bool = False,
    discount: DiscountData | None = None,
    price_domicile_service: str | None = None,
    **overrides: object,
) -> PrintRequestData:
    payload = {
        "id": 1,
        "type": request_type,
        "serial": "S1",
        "credit_card": credit_card,
        "request_price": request_price,
        "from_client": from_client,
        "currency": currency,
        "all_discounted": all_discounted,
        "discount": discount,
        "price_domicile_service": price_domicile_service,
        "command_guests": 2,
        "table_name": "T1",
    }
    payload.update(overrides)
    return PrintRequestData(**payload)


def make_product(
    name: str = "Burger",
    qty: int = 1,
    total_price: str = "5.00",
    product_price: str = "5.00",
    **overrides: object,
) -> PrintProductData:
    payload = {
        "product_name": name,
        "qty": qty,
        "total_price": total_price,
        "product_price": product_price,
    }
    payload.update(overrides)
    return PrintProductData(**payload)


def make_printer(name: str = "P1", printer_width: str = "80", tpv: str | None = "TPV1") -> PrinterData:
    return PrinterData(name=name, printer_width=printer_width, tpv=tpv)


def make_print_settings(
    show_header: bool | None = True,
    show_total_price: bool | None = True,
    show_price_per_unit: bool | None = False,
    show_local_header: bool | None = None,
    details_font: dict[str, object] | str | None = None,
) -> PrintSettingsData:
    return PrintSettingsData(
        show_header=show_header,
        show_total_price=show_total_price,
        show_price_per_unit=show_price_per_unit,
        show_local_header=show_local_header,
        details_font=details_font,
    )


def make_ticket_settings(
    order_by: str | None = None,
    qty_kitchen_ticket: int = 1,
    qty_client_ticket: int = 1,
    ticket_text: str = "",
    **overrides: object,
) -> SimpleNamespace:
    payload = {
        "order_by": order_by,
        "qty_kitchen_ticket": qty_kitchen_ticket,
        "qty_client_ticket": qty_client_ticket,
        "ticket_text": ticket_text,
    }
    payload.update(overrides)
    return SimpleNamespace(**payload)


def make_kitchen_settings(
    group_by_orders: bool = False,
    print_by: str = "categories",
    show_total_price: bool = False,
    show_command_guests: bool = False,
    show_price_per_unit: bool = False,
    show_local_header: bool = True,
    show_domicile_header: bool = True,
) -> SimpleNamespace:
    return SimpleNamespace(
        group_by_orders=group_by_orders,
        print_by=print_by,
        show_total_price=show_total_price,
        show_command_guests=show_command_guests,
        show_price_per_unit=show_price_per_unit,
        show_local_header=show_local_header,
        show_domicile_header=show_domicile_header,
    )


def make_global_settings(
    currency: str | None = "EUR",
    iva: int = 21,
    use_payment_terminal: bool = False,
    use_cashmatic: bool = False,
    use_cashlogy: bool = False,
) -> SimpleNamespace:
    return SimpleNamespace(
        currency=currency,
        iva=iva,
        use_payment_terminal=use_payment_terminal,
        use_cashmatic=use_cashmatic,
        use_cashlogy=use_cashlogy,
    )
