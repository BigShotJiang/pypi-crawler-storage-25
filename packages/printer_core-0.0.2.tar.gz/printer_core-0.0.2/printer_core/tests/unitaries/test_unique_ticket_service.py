import unittest
from printer_core.services.unique_ticket_service import UniqueTicketService

from printer_core.tests.unitaries.helpers import make_printer, make_product, make_request, make_ticket_settings


class UniqueTicketServiceTest(unittest.TestCase):
    def test_build_payload(self):
        service = UniqueTicketService(currency_symbol_resolver=lambda _: "€", domicile_service_label="Service")
        request = make_request(request_type="domicilio", price_domicile_service="2.00")
        products = [make_product()]
        ticket_settings = make_ticket_settings(ticket_text="Text", qty_client_ticket=2)

        payloads = service.build_payload(
            request=request,
            products=products,
            ticket_settings=ticket_settings,
            printer=make_printer(name="P1"),
            tpv_key="TPV1",
        )

        self.assertEqual(payloads[0].printer_qty, 2)
        self.assertEqual(payloads[0].data.ticket_text, "Text")
        self.assertEqual(payloads[0].data.products[-1].name, "Service")
