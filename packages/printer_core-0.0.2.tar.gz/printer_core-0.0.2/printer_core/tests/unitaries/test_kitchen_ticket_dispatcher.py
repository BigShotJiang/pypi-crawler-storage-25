import unittest
from printer_core.dispatchers.kitchen_ticket_dispatcher import KitchenTicketDispatcher
from printer_core.entities import KitchenTicketData, KitchenTicketPayload, PrinterProductGroup

from printer_core.tests.unitaries.helpers import FakeGateway


class DummyBuilder:
    def __init__(self):
        self.calls: list[tuple[str, str]] = []

    def build(self, request, printer_name, tpv_key, printer_width, products, ticket_settings, kitchen_ticket_settings, group_products_func):
        self.calls.append((printer_name, tpv_key))
        return KitchenTicketPayload(
            data=KitchenTicketData(
                id=request.id,
                table_name=request.table_name,
                credit_card=request.credit_card,
                serial=request.serial,
                type=request.type,
            ),
            currency=request.currency or "",
            model=1,
            company_key=tpv_key,
            printer=printer_name,
            printer_qty=1,
            printer_width=printer_width,
        )


class KitchenTicketDispatcherTest(unittest.TestCase):
    def test_dispatch_sends_payloads(self):
        gateway = FakeGateway()
        builder = DummyBuilder()
        dispatcher = KitchenTicketDispatcher(gateway=gateway, builder=builder)
        request = type("Request", (), {
            "id": 1,
            "table_name": "T1",
            "credit_card": False,
            "serial": "S1",
            "type": "local",
            "currency": "EUR",
        })()

        grouped_products = [
            PrinterProductGroup(printer_name="P1", tpv_key="TPV1", printer_width="80", products=[]),
            PrinterProductGroup(printer_name="P2", tpv_key="TPV2", printer_width="58", products=[]),
        ]

        dispatcher.dispatch(
            request=request,
            grouped_products=grouped_products,
            ticket_settings=object(),
            kitchen_ticket_settings=object(),
            group_products_func=lambda items: [],
        )

        self.assertEqual(len(gateway.calls), 2)
        self.assertEqual(builder.calls, [("P1", "TPV1"), ("P2", "TPV2")])
        self.assertEqual(gateway.calls[0][1][0]["printer"], "P1")
        self.assertEqual(gateway.calls[1][1][0]["printer"], "P2")
