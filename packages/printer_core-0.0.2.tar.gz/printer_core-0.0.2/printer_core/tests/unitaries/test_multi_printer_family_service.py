from unittest.mock import patch

import unittest
from printer_core.entities import FamilyData
from printer_core.services.multi_printer_family_service import MultiPrinterFamilyService

from printer_core.tests.unitaries.helpers import FakeFamilyProvider, make_kitchen_settings, make_printer, make_product, make_request, make_ticket_settings


class MultiPrinterFamilyServiceTest(unittest.TestCase):
    def test_build_and_dispatch_by_family(self):
        family_1 = FamilyData(id=1, name="Family 1")
        family_2 = FamilyData(id=2, name="Family 2")
        provider = FakeFamilyProvider(
            families=[family_1, family_2],
            family_by_category={10: family_1, 20: family_2},
        )
        request = make_request(order_by="name")
        products = [
            make_product(name="A", category=10, printer=[make_printer(name="P1")]),
            make_product(name="B", category=20, printer=[make_printer(name="P2")]),
            make_product(name="C", category=None),
        ]
        kitchen_settings = make_kitchen_settings(show_price_per_unit=False)
        ticket_settings = make_ticket_settings()
        dispatch_calls: list[int] = []

        class DummyDispatcher:
            def __init__(self, gateway):
                self._gateway = gateway

            def dispatch(self, request, grouped_products, ticket_settings, kitchen_ticket_settings, group_products_func):
                dispatch_calls.append(len(grouped_products))
                return []

        with patch("printer_core.services.multi_printer_family_service.KitchenTicketDispatcher", DummyDispatcher):
            service = MultiPrinterFamilyService(
                gateway=object(),
                family_provider=provider,
                currency_symbol_resolver=lambda _: "",
                order_by_func=lambda items: items,
                group_products_func=lambda items: [],
            )
            service.build_and_dispatch(
                request=request,
                products=products,
                main_printer=make_printer(name="Main"),
                ticket_settings=ticket_settings,
                kitchen_ticket_settings=kitchen_settings,
            )

        self.assertEqual(len(dispatch_calls), 3)
        self.assertTrue(all(count >= 1 for count in dispatch_calls))
