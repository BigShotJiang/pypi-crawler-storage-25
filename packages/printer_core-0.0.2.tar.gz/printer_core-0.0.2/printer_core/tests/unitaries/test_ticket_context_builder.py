import unittest
from printer_core.context.ticket_context_builder import TicketContextBuilder
from printer_core.entities import HeaderData

from printer_core.tests.unitaries.helpers import FakeHeaderProvider, FakePrintSettingsBuilder, make_kitchen_settings, make_request, make_ticket_settings


class TicketContextBuilderTest(unittest.TestCase):
    def test_apply_kitchen_context_sets_header_and_print_by(self):
        header_provider = FakeHeaderProvider()
        print_settings_builder = FakePrintSettingsBuilder()
        builder = TicketContextBuilder(header_provider=header_provider, print_settings_builder=print_settings_builder)
        request = make_request()
        ticket_settings = make_ticket_settings(order_by="standard")
        kitchen_settings = make_kitchen_settings(group_by_orders=True, print_by="categories")

        enriched = builder.apply_kitchen_context(
            request=request,
            ticket_settings=ticket_settings,
            kitchen_ticket_settings=kitchen_settings,
            header_mode="local",
            include_print_by=True,
            worker=None,
        )

        self.assertEqual(enriched.order_by, "standard")
        self.assertEqual(enriched.group_by_orders, True)
        self.assertEqual(enriched.print_by, "categories")
        self.assertIsInstance(enriched.headerData, HeaderData)

    def test_apply_kitchen_context_respects_header_mode(self):
        header_provider = FakeHeaderProvider()
        print_settings_builder = FakePrintSettingsBuilder()
        builder = TicketContextBuilder(header_provider=header_provider, print_settings_builder=print_settings_builder)
        request = make_request(request_type="domicilio")
        ticket_settings = make_ticket_settings(order_by=None)
        kitchen_settings = make_kitchen_settings(show_local_header=False, show_domicile_header=True)

        enriched_local = builder.apply_kitchen_context(
            request=request,
            ticket_settings=ticket_settings,
            kitchen_ticket_settings=kitchen_settings,
            header_mode="local",
        )
        enriched_domicile = builder.apply_kitchen_context(
            request=request,
            ticket_settings=ticket_settings,
            kitchen_ticket_settings=kitchen_settings,
            header_mode="domicile",
        )

        self.assertIsNone(enriched_local.headerData)
        self.assertIsNotNone(enriched_domicile.headerData)

    def test_apply_client_context_clears_details_font(self):
        header_provider = FakeHeaderProvider()
        print_settings_builder = FakePrintSettingsBuilder()
        builder = TicketContextBuilder(header_provider=header_provider, print_settings_builder=print_settings_builder)
        request = make_request()
        kitchen_settings = make_kitchen_settings()

        enriched = builder.apply_client_context(
            request=request,
            kitchen_ticket_settings=kitchen_settings,
            include_header=True,
            details_font_none=True,
            worker=None,
        )

        self.assertIsNone(enriched.PrintSettings.details_font)
        self.assertIsNotNone(enriched.headerData)
