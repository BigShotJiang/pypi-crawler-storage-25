import unittest
from printer_core.entities import PrintChannel
from printer_core.services.print_policy import FlowTarget, PrintPolicy

from printer_core.tests.unitaries.helpers import make_global_settings, make_request, make_ticket_settings


class PrintPolicyTest(unittest.TestCase):
    def test_plan_local(self):
        ticket_settings = make_ticket_settings(
            ticket_kitchen_local=True,
            ticket_client_local=True,
        )
        policy = PrintPolicy(PrintChannel.LOCAL, ticket_settings, make_global_settings())

        plan = policy.plan(make_request())

        self.assertIn(FlowTarget.KITCHEN, plan.enabled_flows)
        self.assertIn(FlowTarget.CLIENT, plan.enabled_flows)

    def test_plan_barra_suppresses_client_for_credit_card(self):
        ticket_settings = make_ticket_settings(
            ticket_kitchen_barra=True,
            ticket_client_barra=True,
        )
        global_settings = make_global_settings(use_payment_terminal=True)
        policy = PrintPolicy(PrintChannel.BARRA, ticket_settings, global_settings)
        request = make_request(credit_card=True)

        plan = policy.plan(request)

        self.assertIn(FlowTarget.KITCHEN, plan.enabled_flows)
        self.assertNotIn(FlowTarget.CLIENT, plan.enabled_flows)

    def test_plan_domicile(self):
        ticket_settings = make_ticket_settings(
            ticket_kitchen_domicile_or_pickup=True,
            ticket_client_domicile_or_pickup=False,
        )
        policy = PrintPolicy(PrintChannel.DOMICILE, ticket_settings, make_global_settings())

        plan = policy.plan(make_request(request_type="domicilio"))

        self.assertIn(FlowTarget.KITCHEN, plan.enabled_flows)
        self.assertNotIn(FlowTarget.CLIENT, plan.enabled_flows)
