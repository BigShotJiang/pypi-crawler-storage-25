import unittest
from printer_core.algorithms.products_modifiers_multiprinter import ProductsModifiersMultiPrinter
from printer_core.algorithms.products_modifiers_multiprinter_family import ProductsModifiersMultiprinterFamily
from printer_core.algorithms.products_modifiers_unique_ticket import ProductsModifiersUniqueTicket
from printer_core.formatters.discount_formatter import DiscountFormatter

from printer_core.tests.unitaries.helpers import make_kitchen_settings, make_printer, make_product, make_request


class ProductsModifiersMultiPrinterTest(unittest.TestCase):
    def test_build_uses_fallback_printer(self):
        formatter = DiscountFormatter()
        service = ProductsModifiersMultiPrinter(formatter)
        request = make_request()
        product = make_product()
        kitchen_settings = make_kitchen_settings(show_price_per_unit=False)
        main_printer = make_printer(name="Main", printer_width="80", tpv="TPV1")

        lines = service.build(request, [product], kitchen_settings, main_printer)

        self.assertEqual(lines[0].printer_r, "Main")
        self.assertEqual(lines[0].printer_w, "80")
        self.assertEqual(lines[0].tpv, "TPV1")

    def test_build_with_multiple_printers(self):
        formatter = DiscountFormatter()
        service = ProductsModifiersMultiPrinter(formatter)
        request = make_request()
        product = make_product(printer=[make_printer(name="P1"), make_printer(name="P2")])
        kitchen_settings = make_kitchen_settings(show_price_per_unit=False)

        lines = service.build(request, [product], kitchen_settings, make_printer())

        self.assertEqual(len(lines), 2)
        self.assertEqual({line.printer_r for line in lines}, {"P1", "P2"})

    def test_build_sets_prices_when_enabled(self):
        formatter = DiscountFormatter()
        service = ProductsModifiersMultiPrinter(formatter)
        request = make_request(all_discounted=True)
        product = make_product(total_price="8.00", product_price="4.00")
        kitchen_settings = make_kitchen_settings(show_price_per_unit=True)

        lines = service.build(request, [product], kitchen_settings, make_printer())

        self.assertEqual(lines[0].price, "8.00")
        self.assertEqual(lines[0].unitary_price, "4.00")


class ProductsModifiersMultiprinterFamilyTest(unittest.TestCase):
    def test_append_product_adds_lines(self):
        formatter = DiscountFormatter()
        service = ProductsModifiersMultiprinterFamily(formatter)
        request = make_request()
        product = make_product(printer=[make_printer(name="P1"), make_printer(name="P2")])
        kitchen_settings = make_kitchen_settings(show_price_per_unit=False)
        lines = []

        service.append_product(lines, product, request, kitchen_settings)

        self.assertEqual(len(lines), 2)
        self.assertEqual({line.printer_r for line in lines}, {"P1", "P2"})

    def test_append_product_sets_prices_when_enabled(self):
        formatter = DiscountFormatter()
        service = ProductsModifiersMultiprinterFamily(formatter)
        request = make_request(all_discounted=True)
        product = make_product(
            printer=[make_printer(name="P1")],
            total_price="6.00",
            product_price="3.00",
        )
        kitchen_settings = make_kitchen_settings(show_price_per_unit=True)
        lines = []

        service.append_product(lines, product, request, kitchen_settings)

        self.assertEqual(lines[0].price, "6.00")
        self.assertEqual(lines[0].unitary_price, "3.00")


class ProductsModifiersUniqueTicketTest(unittest.TestCase):
    def test_build_appends_domicile_service(self):
        formatter = DiscountFormatter()
        service = ProductsModifiersUniqueTicket(formatter, domicile_service_label="Service")
        request = make_request(request_type="domicilio", price_domicile_service="2.00")
        product = make_product()

        lines = service.build(request, [product])

        self.assertEqual(lines[-1].name, "Service")
        self.assertEqual(lines[-1].price, "2.00")

    def test_build_respects_all_discounted(self):
        formatter = DiscountFormatter()
        service = ProductsModifiersUniqueTicket(formatter)
        request = make_request(all_discounted=True)
        product = make_product(discount_type="number", total_price="1.00")

        lines = service.build(request, [product])

        self.assertEqual(lines[0].name, "Burger")
