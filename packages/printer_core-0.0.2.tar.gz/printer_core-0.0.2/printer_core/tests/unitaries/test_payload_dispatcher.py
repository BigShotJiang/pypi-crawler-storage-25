import unittest
from printer_core.dispatchers.payload_dispatcher import PayloadDispatcher
from printer_core.entities import ClientTicketData, ClientTicketPayload

from printer_core.tests.unitaries.helpers import FakeGateway


class PayloadDispatcherTest(unittest.TestCase):
    def test_send_model_payload(self):
        gateway = FakeGateway()
        dispatcher = PayloadDispatcher(gateway=gateway)
        payload = ClientTicketPayload(
            data=ClientTicketData(
                id=1,
                type="local",
                serial="S1",
                credit_card=False,
                request_price="10.00",
            ),
            currency="EUR",
            model=2,
            company_key="TPV1",
            printer="P1",
            printer_qty=1,
            printer_width="80",
        )

        dispatcher.send("TPV1", payload)

        self.assertEqual(len(gateway.calls), 1)
        tpv_key, data = gateway.calls[0]
        self.assertEqual(tpv_key, "TPV1")
        self.assertEqual(data["printer"], "P1")

    def test_send_list_payload(self):
        gateway = FakeGateway()
        dispatcher = PayloadDispatcher(gateway=gateway)
        payloads = [
            ClientTicketPayload(
                data=ClientTicketData(
                    id=1,
                    type="local",
                    serial="S1",
                    credit_card=False,
                    request_price="10.00",
                ),
                currency="EUR",
                model=2,
                company_key="TPV1",
                printer="P1",
                printer_qty=1,
                printer_width="80",
            )
        ]

        dispatcher.send("TPV1", payloads)

        self.assertEqual(len(gateway.calls), 1)
        tpv_key, data = gateway.calls[0]
        self.assertEqual(tpv_key, "TPV1")
        self.assertEqual(data[0]["printer"], "P1")
