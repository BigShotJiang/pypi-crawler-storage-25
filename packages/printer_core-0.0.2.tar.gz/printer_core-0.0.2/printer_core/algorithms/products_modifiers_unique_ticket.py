from printer_core.entities import ClientTicketProduct, PrintProductData, PrintRequestData
from printer_core.formatters.discount_formatter import DiscountFormatter


class ProductsModifiersUniqueTicket:
    def __init__(self, formatter: DiscountFormatter, domicile_service_label: str = "Domicile Service"):
        self._formatter = formatter
        self._domicile_service_label = domicile_service_label

    def build(self, request: PrintRequestData, products: list[PrintProductData]) -> list[ClientTicketProduct]:
        list_products_in_same_printers: list[ClientTicketProduct] = []
        for product in products:
            with_discount = ""
            if not request.all_discounted:
                with_discount = self._formatter.format(product, request.currency or "")
            product_name = product.product_name + with_discount
            list_products_in_same_printers.append(ClientTicketProduct(
                name=product_name,
                qty=int(product.qty),
                option=product.option,
                price=str(product.total_price),
                unitary_price=str(product.product_price),
            ))
        if request.price_domicile_service:
            list_products_in_same_printers.append(ClientTicketProduct(
                name=self._domicile_service_label,
                qty=1,
                price=str(request.price_domicile_service),
            ))
        return list_products_in_same_printers
