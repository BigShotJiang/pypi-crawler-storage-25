from typing import Any

from printer_core.entities import KitchenProductLine, PrintProductData, PrintRequestData, PrinterData
from printer_core.formatters.discount_formatter import DiscountFormatter


class ProductsModifiersMultiprinterFamily:
    def __init__(self, formatter: DiscountFormatter):
        self._formatter = formatter

    def append_product(self,
                       list_products_own_printer: list[KitchenProductLine],
                       product: PrintProductData,
                       request: PrintRequestData,
                       kitchen_ticket_settings: Any,
                       ) -> None:
        for actual_printer in product.printer:
            printer_payload = self._resolve_printer(actual_printer)
            name_with_discount: str = product.product_name
            if not request.all_discounted:
                name_with_discount += self._formatter.format(product, request.currency or "")
            line = KitchenProductLine(
                name=name_with_discount,
                qty=int(product.qty),
                option=product.option,
                printer_r=printer_payload.name,
                printer_w=printer_payload.printer_width,
                details=product.details or "",
                order=product.order or "",
                tpv=printer_payload.tpv,
                order_readable=product.order_readable or "",
            )

            if kitchen_ticket_settings.show_price_per_unit:
                line = line.model_copy(update={
                    "price": product.total_price,
                    "unitary_price": product.product_price,
                })

            list_products_own_printer.append(line)

    def _resolve_printer(self, printer: PrinterData | dict[str, Any]) -> PrinterData:
        if isinstance(printer, PrinterData):
            return printer
        if isinstance(printer, dict):
            return PrinterData(**printer)
        if hasattr(printer, "model_dump"):
            return PrinterData(**printer.model_dump(mode="json", exclude_none=True))
        return PrinterData(
            name=printer.name,
            printer_width=printer.printer_width,
            tpv=getattr(printer, "tpv", None),
        )
