from collections import defaultdict

from printer_core.entities import FamilyData, PrintProductData
from printer_core.ports import FamilyCategoryProvider


class FamilyProductSelector:
    def __init__(self, provider: FamilyCategoryProvider):
        self._provider = provider

    def group_products(self, products: list[PrintProductData]) -> tuple[
        list[FamilyData], dict[int, list[PrintProductData]], list[PrintProductData]
    ]:
        category_ids = [product.category for product in products if product.category]
        category_ids = [category_id for category_id in category_ids if category_id]
        families = self._provider.get_families()
        family_by_category = self._provider.get_family_by_category_ids(category_ids)

        products_by_family: dict[int, list[PrintProductData]] = defaultdict(list)
        products_without_family: list[PrintProductData] = []

        for product in products:
            category_id = product.category
            if not category_id or category_id not in family_by_category:
                products_without_family.append(product)
                continue
            family = family_by_category.get(category_id)
            if not family:
                products_without_family.append(product)
                continue
            products_by_family[family.id].append(product)

        return families, products_by_family, products_without_family
