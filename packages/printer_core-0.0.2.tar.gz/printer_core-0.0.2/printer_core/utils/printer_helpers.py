from collections import OrderedDict
from decimal import Decimal
from operator import attrgetter

from printer_core.entities import IvaData, KitchenProductLine, ProductsGroup


def order_products_by_name(list_of_products: list[KitchenProductLine]) -> list[KitchenProductLine]:
    return sorted(list_of_products, key=attrgetter("name"))


def group_products_by_orders(products: list[KitchenProductLine]) -> list[ProductsGroup]:
    dict_aux: dict[int, ProductsGroup] = {}
    array_without_order: list[KitchenProductLine] = []
    for product in products:
        if product.order is not None:
            try:
                order_id = int(product.order)
                product = product.model_copy(update={"order": str(order_id)})
                if order_id in dict_aux:
                    dict_aux[order_id].products.append(product)
                else:
                    dict_aux[order_id] = ProductsGroup(
                        group=product.order_readable or "",
                        products=[product],
                    )
            except ValueError:
                continue
        else:
            array_without_order.append(product)

    ordered_dict = OrderedDict(sorted(dict_aux.items()))
    list_of_ordered_values: list[ProductsGroup] = list(ordered_dict.values())
    list_of_ordered_values.append(ProductsGroup(group="Sin orden", products=array_without_order))
    return list_of_ordered_values


def build_iva_data(total: Decimal, iva: Decimal) -> IvaData:
    aa: Decimal = Decimal(total)
    iva_value: Decimal = Decimal(str(iva))
    base: Decimal = Decimal(aa / (1 + iva_value / 100)).quantize(Decimal(".01"))
    return IvaData(Base=str(base), impo=str(aa - base), iva=str(iva_value))
