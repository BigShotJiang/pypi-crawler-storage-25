from typing import Any, Protocol

from printer_core.entities import FamilyData, HeaderData, PrintRequestData, PrintSettingsData


class PrinterGateway(Protocol):
    def send_data(self, tpv_key: str, data: Any) -> None:
        ...


class Clock(Protocol):
    def now_iso(self) -> str:
        ...


class HeaderProvider(Protocol):
    def build_header(self, request: PrintRequestData, worker: Any | None = None) -> HeaderData:
        ...


class HeaderDataProvider(Protocol):
    def get_company_header(self) -> dict[str, str]:
        ...

    def get_worker_header(self, user: Any) -> dict[str, str]:
        ...

    def get_pickup_client_header(self, client_id: int | None, from_client: str | None) -> dict[str, str]:
        ...

    def get_domicile_client_header(self, address_id: int | None, from_client: str | None) -> dict[str, str]:
        ...


class PrintSettingsBuilder(Protocol):
    def build(self, kitchen_ticket_settings: Any) -> PrintSettingsData:
        ...


class FamilyCategoryProvider(Protocol):
    def get_families(self) -> list[FamilyData]:
        ...

    def get_family_by_category_ids(self, category_ids: list[int]) -> dict[int, FamilyData]:
        ...
