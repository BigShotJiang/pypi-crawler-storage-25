from typing import Any

from printer_core.entities import PrintRequestData, PrintSettingsData
from printer_core.ports import HeaderProvider, PrintSettingsBuilder


class TicketContextBuilder:
    def __init__(self, header_provider: HeaderProvider, print_settings_builder: PrintSettingsBuilder):
        self._header_provider = header_provider
        self._print_settings_builder = print_settings_builder

    def apply_kitchen_context(self,
                              request: PrintRequestData,
                              ticket_settings: Any,
                              kitchen_ticket_settings: Any,
                              header_mode: str,
                              include_print_by: bool = True,
                              worker: Any | None = None,
                              ) -> PrintRequestData:
        updates: dict[str, Any] = {
            "order_by": ticket_settings.order_by if ticket_settings.order_by else "name",
            "group_by_orders": kitchen_ticket_settings.group_by_orders,
            "PrintSettings": self._print_settings_builder.build(kitchen_ticket_settings),
        }
        if include_print_by:
            updates["print_by"] = kitchen_ticket_settings.print_by
        if self._should_add_header(kitchen_ticket_settings, header_mode):
            header_data = self._header_provider.build_header(request, worker=worker)
            updates["headerData"] = header_data
        return request.model_copy(update=updates)

    def apply_client_context(self,
                             request: PrintRequestData,
                             kitchen_ticket_settings: Any,
                             include_header: bool = True,
                             details_font_none: bool = True,
                             worker: Any | None = None,
                             ) -> PrintRequestData:
        print_settings: PrintSettingsData = self._print_settings_builder.build(kitchen_ticket_settings)
        if details_font_none:
            print_settings = print_settings.model_copy(update={"details_font": None})
        updates: dict[str, Any] = {"PrintSettings": print_settings}
        if include_header:
            header_data = self._header_provider.build_header(request, worker=worker)
            updates["headerData"] = header_data
        return request.model_copy(update=updates)

    def _should_add_header(self, kitchen_ticket_settings: Any, header_mode: str) -> bool:
        match header_mode:
            case "local":
                return kitchen_ticket_settings.show_local_header
            case "domicile":
                return kitchen_ticket_settings.show_domicile_header
            case _:
                return False
