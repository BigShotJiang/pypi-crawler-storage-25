from decimal import Decimal
from typing import Callable

from printer_core.entities import PrintProductData

class DiscountFormatter:
    def __init__(self, currency_symbol_resolver: Callable[[str], str] | None = None):
        self._currency_symbol_resolver = currency_symbol_resolver or (lambda _: "")

    def format(self, product: PrintProductData, currency_code: str) -> str:
        currency_symbol = self._currency_symbol_resolver(currency_code)
        if product.discount_type == "number":
            return f" (Dto {product.total_price}{currency_symbol})"
        if product.discount_type == "percent" and product.discount:
            total = Decimal(str(product.importe)) - Decimal(str(product.total_price))
            return f" (Dto {product.discount.value}% {total}{currency_symbol})"
        return ""
