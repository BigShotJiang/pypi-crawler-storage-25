from typing import Any, Callable

from printer_core.builders.kitchen_ticket_payload_builder import KitchenTicketPayloadBuilder
from printer_core.entities import KitchenProductLine, KitchenTicketPayload, PrintRequestData, PrinterProductGroup, ProductsGroup
from printer_core.ports import PrinterGateway


class KitchenTicketDispatcher:
    def __init__(self, gateway: PrinterGateway, builder: KitchenTicketPayloadBuilder | None = None):
        self._builder = builder or KitchenTicketPayloadBuilder()
        self._gateway = gateway

    def dispatch(self,
                 request: PrintRequestData,
                 grouped_products: list[PrinterProductGroup],
                 ticket_settings: Any,
                 kitchen_ticket_settings: Any,
                 group_products_func: Callable[[list[KitchenProductLine]], list[ProductsGroup]],
                 ) -> list[KitchenTicketPayload]:
        final_request: list[KitchenTicketPayload] = []
        for group in grouped_products:
            payload = self._builder.build(
                request=request,
                printer_name=group.printer_name,
                tpv_key=group.tpv_key,
                printer_width=group.printer_width,
                products=group.products,
                ticket_settings=ticket_settings,
                kitchen_ticket_settings=kitchen_ticket_settings,
                group_products_func=group_products_func,
            )
            final_request.append(payload)
            self._gateway.send_data(group.tpv_key, [payload.model_dump(mode="json", exclude_none=True)])
        return final_request
