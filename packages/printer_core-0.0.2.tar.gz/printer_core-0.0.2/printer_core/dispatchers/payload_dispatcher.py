from typing import Any

from printer_core.ports import PrinterGateway


class PayloadDispatcher:
    def __init__(self, gateway: PrinterGateway):
        self._gateway = gateway

    def send(self, tpv_key: str, payload: Any) -> None:
        if hasattr(payload, "model_dump"):
            payload = payload.model_dump(mode="json", exclude_none=True)
        if isinstance(payload, list):
            payload = [
                item.model_dump(mode="json", exclude_none=True) if hasattr(item, "model_dump") else item
                for item in payload
            ]
        self._gateway.send_data(tpv_key, payload)
