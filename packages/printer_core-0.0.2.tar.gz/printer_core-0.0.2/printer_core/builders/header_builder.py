from typing import Any

from printer_core.entities import HeaderData, PrintRequestData
from printer_core.ports import HeaderDataProvider


class HeaderBuilder:
    def __init__(self, provider: HeaderDataProvider, show_person_name: bool):
        self._provider = provider
        self._show_person_name = show_person_name

    def build_header(self, request: PrintRequestData, worker: Any | None = None) -> HeaderData:
        header_data: dict[str, str] = self._provider.get_company_header()
        if self._show_person_name and worker:
            header_data.update(self._provider.get_worker_header(worker))
        header_data.update(self._client_header(request))
        return HeaderData(**header_data)

    def _client_header(self, request: PrintRequestData) -> dict[str, str]:
        request_type = request.type
        from_client = request.from_client
        if request_type == "recoger":
            return self._provider.get_pickup_client_header(request.client, from_client)
        if request_type == "domicilio":
            return self._provider.get_domicile_client_header(request.address, from_client)
        return {}
