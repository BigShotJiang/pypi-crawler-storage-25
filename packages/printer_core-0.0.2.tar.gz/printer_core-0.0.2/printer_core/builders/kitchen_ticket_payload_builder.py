from datetime import datetime
from typing import Any, Callable

from printer_core.clock import SystemClock
from printer_core.entities import (
    KitchenProductLine,
    KitchenTicketData,
    KitchenTicketPayload,
    PrintRequestData,
    PrintSettingsData,
    ProductsGroup,
)
from printer_core.ports import Clock


class KitchenTicketPayloadBuilder:
    def __init__(self, clock: Clock | None = None):
        self._clock = clock or SystemClock()

    def build(self,
              request: PrintRequestData,
              printer_name: str,
              tpv_key: str,
              printer_width: str,
              products: list[KitchenProductLine],
              ticket_settings: Any,
              kitchen_ticket_settings: Any,
              group_products_func: Callable[[list[KitchenProductLine]], list[ProductsGroup]],
              ) -> KitchenTicketPayload:
        data = KitchenTicketData(
            id=request.id,
            table_name=request.table_name,
            credit_card=request.credit_card,
            serial=request.serial,
            details=request.details or "",
            type=request.type,
            discount=request.discount,
        )

        data = data.model_copy(update={"created_at": self._resolve_created_at(request)})

        if kitchen_ticket_settings.show_total_price:
            data = data.model_copy(update={
                "total": str(request.total),
                "request_price": request.request_price,
            })

        if request.type == "local" and kitchen_ticket_settings.show_command_guests:
            data = data.model_copy(update={"command_guests": request.command_guests})

        if request.headerData:
            data = data.model_copy(update={"headerData": request.headerData})

        model = 1
        if request.type != "local":
            model = 2

        data = self._set_products(data, request, products, group_products_func)
        print_settings = self._set_print_settings(request)

        return KitchenTicketPayload(
            data=data,
            model=model,
            printer_qty=ticket_settings.qty_kitchen_ticket,
            printer=printer_name,
            company_key=tpv_key,
            printer_width=printer_width,
            currency=request.currency or "",
            PrintSettings=print_settings,
        )

    def _resolve_created_at(self, request: PrintRequestData) -> str:
        if request.type in ["domicilio", "recoger"] and request.shift_time and request.delivery_date:
            shift_time = datetime.strptime(request.shift_time, "%H:%M").time()
            delivery_date = datetime.strptime(request.delivery_date, "%Y-%m-%d").date()
            return datetime.combine(delivery_date, shift_time).strftime("%Y-%m-%d %H:%M")
        return self._clock.now_iso()

    def _set_products(self,
                      data: KitchenTicketData,
                      request: PrintRequestData,
                      products: list[KitchenProductLine],
                      group_products_func: Callable[[list[KitchenProductLine]], list[ProductsGroup]],
                      ) -> KitchenTicketData:
        group_by_orders = request.group_by_orders
        if group_by_orders and request.type == "local":
            grouped = group_products_func(products)
            if grouped and not isinstance(grouped[0], ProductsGroup):
                grouped = [ProductsGroup(group="Sin orden", products=grouped)]
            return data.model_copy(update={"products_groups": grouped})
        return data.model_copy(update={"products": products})

    def _set_print_settings(self, request: PrintRequestData) -> PrintSettingsData | None:
        print_settings = request.PrintSettings
        if not print_settings:
            return None
        if request.type == "local" and print_settings.show_local_header is not None:
            return print_settings.model_copy(update={"show_header": print_settings.show_local_header})
        return print_settings
