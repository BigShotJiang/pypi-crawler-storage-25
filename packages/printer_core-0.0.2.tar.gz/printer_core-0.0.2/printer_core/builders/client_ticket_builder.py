from decimal import Decimal
from typing import Any, Callable

from printer_core.entities import (
    ClientTicketData,
    ClientTicketPayload,
    ClientTicketProduct,
    PrintProductData,
    PrintRequestData,
    PrinterData,
)


class ClientTicketBuilder:
    def __init__(self,
                 currency_symbol_resolver: Callable[[str], str] | None = None,
                 domicile_service_label: str = "Domicile Service",
                 ):
        self._currency_symbol_resolver = currency_symbol_resolver or (lambda _: "")
        self._domicile_service_label = domicile_service_label

    def build(self,
              request: PrintRequestData,
              products: list[PrintProductData],
              printer: PrinterData | dict[str, Any],
              ticket_settings: Any,
              tpv_key: str,
              ) -> list[ClientTicketPayload]:
        ticket_text = self._get_attr(ticket_settings, "ticket_text", "")
        qty_client_ticket = self._get_attr(ticket_settings, "qty_client_ticket", 1)
        client_request = ClientTicketData(
            **request.model_dump(exclude={"products", "ticket_text"}),
            ticket_text=ticket_text,
            products=self._build_products(request, products),
        )

        if client_request.type in ["domicilio", "recoger"]:
            client_request = client_request.model_copy(update={"details": client_request.details or ""})
        elif client_request.details:
            client_request = client_request.model_copy(update={"details": None})

        printer_name, printer_width = self._resolve_printer(printer)
        payload = ClientTicketPayload(
            data=client_request,
            currency=client_request.currency or "",
            model=2,
            company_key=tpv_key,
            printer=printer_name,
            printer_qty=qty_client_ticket,
            printer_width=printer_width,
        )
        return [payload]

    def _build_products(
        self,
        request: PrintRequestData,
        products: list[PrintProductData],
    ) -> list[ClientTicketProduct]:
        list_products: list[ClientTicketProduct] = []
        currency_symbol = self._currency_symbol_resolver(request.currency or "")
        for product in products:
            with_discount = ""
            if not request.all_discounted:
                with_discount = self._format_discount(product, currency_symbol)
            product_name = product.product_name + with_discount
            list_products.append(ClientTicketProduct(
                name=product_name,
                qty=int(product.qty),
                option=product.option,
                price=str(product.total_price),
                unitary_price=str(product.product_price),
            ))
        if request.price_domicile_service:
            list_products.append(ClientTicketProduct(
                name=self._domicile_service_label,
                qty=1,
                price=str(request.price_domicile_service),
            ))
        return list_products

    def _format_discount(self, product: PrintProductData, currency_symbol: str) -> str:
        if product.discount_type == "number":
            return f" (Dto {product.total_price}{currency_symbol})"
        if product.discount_type == "percent" and product.discount:
            total = Decimal(str(product.importe)) - Decimal(str(product.total_price))
            return f" (Dto {product.discount.value}% {total}{currency_symbol})"
        return ""

    def _get_attr(self, obj: Any, attr: str, default: Any) -> Any:
        if isinstance(obj, dict):
            return obj.get(attr, default)
        return getattr(obj, attr, default)

    def _resolve_printer(self, printer: PrinterData | dict[str, Any]) -> tuple[str, Any]:
        if isinstance(printer, dict):
            return printer["name"], printer["printer_width"]
        return printer.name, printer.printer_width
