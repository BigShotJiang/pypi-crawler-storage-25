from printer_core.entities import KitchenProductLine, PrinterProductGroup


class PrinterProductsGrouper:
    @staticmethod
    def group_by_printer_key(products: list[KitchenProductLine]) -> list[PrinterProductGroup]:
        grouped: dict[str, PrinterProductGroup] = {}
        for item in products:
            key = f"{item.printer_r}%%{item.tpv or ''}%%{item.printer_w}"
            if key not in grouped:
                grouped[key] = PrinterProductGroup(
                    printer_name=item.printer_r,
                    tpv_key=item.tpv or "",
                    printer_width=item.printer_w,
                    products=[item],
                )
            else:
                grouped[key].products.append(item)
        return list(grouped.values())
