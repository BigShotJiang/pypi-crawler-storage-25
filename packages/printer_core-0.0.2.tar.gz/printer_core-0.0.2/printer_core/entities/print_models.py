from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class PrintChannel(str, Enum):
    KIOSKO = "kiosko"
    BARRA = "barra"
    LOCAL = "local"
    DOMICILE = "domicilio"
    PICKUP = "recoger"


class CompanyHeaderData(BaseModel):
    company_name: str | None = None
    company_reason: str | None = None
    company_dni: str | None = None
    company_phone: str | None = None
    company_address: str | None = None


class WorkerData(BaseModel):
    first_name: str | None = None


class DiscountData(BaseModel):
    model_config = ConfigDict(extra="allow")

    value: str | None = None
    type: str | None = None
    total: str | None = None


class HeaderData(BaseModel):
    model_config = ConfigDict(extra="allow")

    company_name: str | None = None
    company_reason: str | None = None
    company_dni: str | None = None
    company_phone: str | None = None
    company_address: str | None = None
    worker_name: str | None = None
    client_name: str | None = None
    client_phone: str | None = None
    client_address: str | None = None


class PrintSettingsData(BaseModel):
    model_config = ConfigDict(extra="allow")

    show_header: bool | None = None
    show_total_price: bool | None = None
    show_price_per_unit: bool | None = None
    show_local_header: bool | None = None
    details_font: dict[str, Any] | str | None = None


class IvaData(BaseModel):
    Base: str
    impo: str
    iva: str


class FiskalyData(BaseModel):
    model_config = ConfigDict(extra="allow")


class PrinterData(BaseModel):
    name: str
    printer_width: str
    tpv: str | None = None


class PrintProductData(BaseModel):
    model_config = ConfigDict(extra="allow")

    product_name: str
    qty: int
    option: Any = None
    total_price: Any
    product_price: Any
    discount_type: str | None = None
    discount: DiscountData | None = None
    importe: Any | None = None
    details: str | None = None
    order: str | None = None
    order_readable: str | None = None
    printer: list[PrinterData] = Field(default_factory=list)
    category: int | None = None


class ClientTicketProduct(BaseModel):
    name: str
    qty: int
    option: Any | None = None
    price: str | None = None
    unitary_price: str | None = None


class KitchenProductLine(BaseModel):
    name: str
    qty: int
    option: Any | None = None
    printer_r: str
    printer_w: str
    details: str | None = None
    order: str | None = None
    tpv: str | None = None
    order_readable: str | None = None
    price: Any | None = None
    unitary_price: Any | None = None


class ProductsGroup(BaseModel):
    group: str
    products: list[KitchenProductLine]


class PrinterProductGroup(BaseModel):
    printer_name: str
    tpv_key: str
    printer_width: str
    products: list[KitchenProductLine]


class KitchenTicketData(BaseModel):
    id: int | None = None
    table_name: str | None = None
    credit_card: bool
    serial: str
    details: str | None = None
    type: str
    discount: DiscountData | None = None
    created_at: str | None = None
    total: str | None = None
    request_price: Any | None = None
    command_guests: int | None = None
    headerData: HeaderData | None = None
    products: list[KitchenProductLine] | None = None
    products_groups: list[ProductsGroup] | None = None


class PrintRequestData(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: int
    type: str
    serial: str
    credit_card: bool
    request_price: Any
    details: str | None = None
    from_client: str | None = None
    client: int | None = None
    address: int | None = None
    shift_time: str | None = None
    delivery_date: str | None = None
    created_at: str | None = None
    print_by: str | None = None
    order_by: str | None = None
    group_by_orders: bool | None = None
    all_discounted: bool | None = None
    discount: DiscountData | None = None
    command_guests: int | None = None
    table_name: str | None = None
    qr: str | None = None
    currency: str | None = None
    total: str | None = None
    ivaData: IvaData | None = None
    PrintSettings: PrintSettingsData | None = None
    headerData: HeaderData | None = None
    is_invoice: bool | None = None
    ticket_text: str | None = None
    payed_with: str | None = None
    fiskalyData: FiskalyData | None = None
    price_domicile_service: Any | None = None


class ClientTicketData(PrintRequestData):
    products: list[ClientTicketProduct] | None = None


class PrintJob(BaseModel):
    request: PrintRequestData
    products: list[PrintProductData]
    tpv_key: str


class ClientTicketPayload(BaseModel):
    data: ClientTicketData
    currency: str
    model: int
    company_key: str | None
    printer: str
    printer_qty: int
    printer_width: Any


class KitchenTicketPayload(BaseModel):
    data: KitchenTicketData
    currency: str
    model: int
    company_key: str | None = None
    printer: str
    printer_qty: int
    printer_width: Any
    PrintSettings: PrintSettingsData | None = None


class MarchCommandData(BaseModel):
    table_name: str | None = None
    credit_card: bool | None = None
    serial: str | None = None
    type: str | None = None


class FamilyData(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: int
    name: str | None = None


class PrintResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    multi_printer: list[KitchenTicketPayload] | bool | None = None
    ticket_client: list[ClientTicketPayload] | None = None
