from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from printer_core.entities.print_models import PrinterData, WorkerData


@dataclass(frozen=True)
class PrintContext:
    ticket_settings: Any
    kitchen_settings: Any
    global_settings: Any
    main_printer: PrinterData
    worker: WorkerData | None = None
