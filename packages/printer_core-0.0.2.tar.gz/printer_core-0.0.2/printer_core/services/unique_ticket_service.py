from typing import Any, Callable

from printer_core.algorithms.products_modifiers_unique_ticket import ProductsModifiersUniqueTicket
from printer_core.entities import ClientTicketData, ClientTicketPayload, PrintProductData, PrintRequestData, PrinterData
from printer_core.formatters.discount_formatter import DiscountFormatter


class UniqueTicketService:
    def __init__(
        self,
        currency_symbol_resolver: Callable[[str], str],
        domicile_service_label: str,
    ):
        self._currency_symbol_resolver = currency_symbol_resolver
        self._domicile_service_label = domicile_service_label

    def build_payload(
        self,
        request: PrintRequestData,
        products: list[PrintProductData],
        ticket_settings: Any,
        printer: PrinterData,
        tpv_key: str,
    ) -> list[ClientTicketPayload]:
        formatter = DiscountFormatter(currency_symbol_resolver=self._currency_symbol_resolver)
        list_products_in_same_printers = ProductsModifiersUniqueTicket(
            formatter, domicile_service_label=self._domicile_service_label
        ).build(request, products)

        ticket_text = getattr(ticket_settings, "ticket_text", "")
        qty_client_ticket = getattr(ticket_settings, "qty_client_ticket", 1)

        client_request = ClientTicketData(
            **request.model_dump(exclude={"products", "ticket_text"}),
            ticket_text=ticket_text,
            products=list_products_in_same_printers,
        )
        if client_request.type in ["domicilio", "recoger"]:
            client_request = client_request.model_copy(update={"details": client_request.details or ""})
        elif client_request.details:
            client_request = client_request.model_copy(update={"details": None})

        payload = ClientTicketPayload(
            data=client_request,
            currency=client_request.currency or "",
            model=2,
            company_key=tpv_key,
            printer=printer.name,
            printer_qty=qty_client_ticket,
            printer_width=printer.printer_width,
        )
        return [payload]
