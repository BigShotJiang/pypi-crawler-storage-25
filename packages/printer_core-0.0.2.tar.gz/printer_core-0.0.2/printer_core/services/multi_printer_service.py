from typing import Any, Callable

from printer_core.algorithms.products_modifiers_multiprinter import ProductsModifiersMultiPrinter
from printer_core.builders.printer_products_grouper import PrinterProductsGrouper
from printer_core.dispatchers.kitchen_ticket_dispatcher import KitchenTicketDispatcher
from printer_core.entities import KitchenProductLine, KitchenTicketPayload, PrintProductData, PrintRequestData, PrinterData, ProductsGroup
from printer_core.formatters.discount_formatter import DiscountFormatter
from printer_core.ports import PrinterGateway
from printer_core.utils.printer_helpers import group_products_by_orders, order_products_by_name


class MultiPrinterService:
    def __init__(
        self,
        gateway: PrinterGateway,
        currency_symbol_resolver: Callable[[str], str],
        order_by_func: Callable[[list[KitchenProductLine]], list[KitchenProductLine]] | None = None,
        group_products_func: Callable[[list[KitchenProductLine]], list[ProductsGroup]] | None = None,
    ):
        self._gateway = gateway
        self._currency_symbol_resolver = currency_symbol_resolver
        self._order_by_func = order_by_func or order_products_by_name
        self._group_products_func = group_products_func or group_products_by_orders

    def build_and_dispatch(
        self,
        request: PrintRequestData,
        products: list[PrintProductData],
        main_printer: PrinterData,
        ticket_settings: Any,
        kitchen_ticket_settings: Any,
    ) -> list[KitchenTicketPayload]:
        formatter = DiscountFormatter(currency_symbol_resolver=self._currency_symbol_resolver)
        list_products_own_printer = ProductsModifiersMultiPrinter(formatter).build(
            request, products, kitchen_ticket_settings, main_printer
        )

        if (request.order_by or "standard") == "name":
            list_products_own_printer = self._order_by_func(list_products_own_printer)

        grouped_products = PrinterProductsGrouper.group_by_printer_key(list_products_own_printer)
        dispatcher = KitchenTicketDispatcher(gateway=self._gateway)
        return dispatcher.dispatch(
            request=request,
            grouped_products=grouped_products,
            ticket_settings=ticket_settings,
            kitchen_ticket_settings=kitchen_ticket_settings,
            group_products_func=self._group_products_func,
        )
