from __future__ import annotations

from decimal import Decimal
from typing import Any

from printer_core.clock import SystemClock
from printer_core.entities import (
    PrintChannel,
    PrintJob,
    PrintRequestData,
    PrintResult,
)
from printer_core.services.flows import PrintFlow
from printer_core.services.print_policy import FlowTarget, PrintPolicy
from printer_core.utils.printer_helpers import build_iva_data


class OrderPrintService:
    def __init__(self, flows: list[PrintFlow]):
        self._clock = SystemClock()
        self._flows = flows

    def print_job(self, job: PrintJob, context: Any, channel: PrintChannel) -> PrintResult:
        base_request = self._build_request(job.request, context, channel)
        products = job.products

        result = PrintResult()
        policy = PrintPolicy(channel, context.ticket_settings, context.global_settings)
        plan = policy.plan(base_request)

        for flow in self._flows:
            if flow.target not in plan.enabled_flows:
                continue
            data = flow.execute(
                base_request=base_request,
                products=products,
                context=context,
                channel=channel,
                tpv_key=job.tpv_key,
            )
            if flow.target == FlowTarget.KITCHEN:
                result = result.model_copy(update={"multi_printer": data})
            elif flow.target == FlowTarget.CLIENT:
                result = result.model_copy(update={"ticket_client": data})

        return result

    def _build_request(
        self,
        request: PrintRequestData,
        context: Any,
        channel: PrintChannel,
    ) -> PrintRequestData:
        enriched = self._normalize_discount(channel, request)
        if not enriched.print_by and getattr(context.kitchen_settings, "print_by", None):
            enriched = enriched.model_copy(update={"print_by": context.kitchen_settings.print_by})
        if channel in (PrintChannel.KIOSKO, PrintChannel.BARRA):
            enriched = enriched.model_copy(update={"created_at": self._clock.now_iso()})
        if not enriched.currency and getattr(context.global_settings, "currency", None):
            enriched = enriched.model_copy(update={"currency": context.global_settings.currency})

        total, enriched = self._compute_total(channel, enriched)
        iva_data = build_iva_data(total, Decimal(str(context.global_settings.iva)))
        enriched = enriched.model_copy(update={"total": str(total), "ivaData": iva_data})
        return enriched

    def _compute_total(self, channel: PrintChannel, request: PrintRequestData) -> tuple[Decimal, PrintRequestData]:
        request_price = Decimal(str(request.request_price)).quantize(Decimal(".01"))
        if channel != PrintChannel.DOMICILE:
            if request.price_domicile_service is not None:
                request = request.model_copy(update={"price_domicile_service": None})
            return request_price, request
        domicile_price = Decimal(str(request.price_domicile_service or "0")).quantize(Decimal(".01"))
        request = request.model_copy(update={"price_domicile_service": str(domicile_price)})
        return request_price + domicile_price, request

    def _normalize_discount(self, channel: PrintChannel, request: PrintRequestData) -> PrintRequestData:
        if channel == PrintChannel.LOCAL:
            return request.model_copy(update={"discount": None})
        if channel in (PrintChannel.KIOSKO, PrintChannel.BARRA) and not request.all_discounted:
            return request.model_copy(update={"discount": None})
        return request
