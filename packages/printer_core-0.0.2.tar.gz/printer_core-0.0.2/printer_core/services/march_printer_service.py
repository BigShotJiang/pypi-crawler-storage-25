from printer_core.clock import SystemClock
from printer_core.entities import KitchenProductLine, KitchenTicketData, KitchenTicketPayload, MarchCommandData, PrinterData, PrintSettingsData
from printer_core.ports import Clock, PrinterGateway


class MarchPrinterService:
    def __init__(self, gateway: PrinterGateway, clock: Clock | None = None):
        self._gateway = gateway
        self._clock = clock or SystemClock()

    def build_and_send(self,
                       printers: list[PrinterData],
                       command_data: MarchCommandData,
                       order_type_text: str,
                       tpv_key: str,
                       currency: str,
                       print_settings: PrintSettingsData,
                       printer_qty: int = 1,
                       ) -> list[KitchenTicketPayload]:
        final_request: list[KitchenTicketPayload] = []
        for printer in printers:
            products = [KitchenProductLine(
                name=str(order_type_text),
                qty=0,
                option=[],
                price=0,
                printer_r=str(printer.name),
                printer_w=printer.printer_width,
                details="",
                order=None,
                tpv=str(tpv_key),
                order_readable=None,
            )]
            data = KitchenTicketData(
                table_name=str(command_data.table_name or ""),
                credit_card=bool(command_data.credit_card),
                serial=str(command_data.serial or ""),
                created_at=self._clock.now_iso(),
                request_price="0",
                type=str(command_data.type or ""),
                total="0",
                discount=None,
                products=products,
            )
            payload = KitchenTicketPayload(
                data=data,
                model=1,
                printer_qty=printer_qty,
                printer=str(printer.name),
                printer_width=printer.printer_width,
                currency=currency,
                PrintSettings=print_settings.model_copy(update={
                    "show_header": True,
                    "show_total_price": False,
                    "show_price_per_unit": False,
                }),
            )

            final_request.append(payload)
            self._gateway.send_data(tpv_key, [payload.model_dump(mode="json", exclude_none=True)])
        return final_request
