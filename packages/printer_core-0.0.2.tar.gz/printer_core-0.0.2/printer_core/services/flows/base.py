from __future__ import annotations

from typing import Any, Protocol

from printer_core.entities import (
    ClientTicketPayload,
    KitchenTicketPayload,
    PrintChannel,
    PrintProductData,
    PrintRequestData,
)
from printer_core.services.print_policy import FlowTarget


class PrintFlow(Protocol):
    target: FlowTarget

    def execute(
        self,
        base_request: PrintRequestData,
        products: list[PrintProductData],
        context: Any,
        channel: PrintChannel,
        tpv_key: str | None = None,
    ) -> list[KitchenTicketPayload] | list[ClientTicketPayload]:
        ...
