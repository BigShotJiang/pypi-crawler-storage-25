from __future__ import annotations

from typing import Any, Callable

from printer_core.builders.client_ticket_builder import ClientTicketBuilder
from printer_core.context.ticket_context_builder import TicketContextBuilder
from printer_core.entities import (
    ClientTicketPayload,
    PrintChannel,
    PrintProductData,
    PrintRequestData,
    PrinterData,
)
from printer_core.ports import HeaderProvider, PrinterGateway, PrintSettingsBuilder
from printer_core.services.print_policy import FlowTarget


class ClientPrintFlow:
    target = FlowTarget.CLIENT

    def __init__(
        self,
        gateway: PrinterGateway,
        header_provider: HeaderProvider,
        print_settings_builder: PrintSettingsBuilder,
        currency_symbol_resolver: Callable[[str], str],
        domicile_service_label: str,
    ):
        self._gateway = gateway
        self._currency_symbol_resolver = currency_symbol_resolver
        self._domicile_service_label = domicile_service_label
        self._context_builder = TicketContextBuilder(
            header_provider=header_provider,
            print_settings_builder=print_settings_builder,
        )

    def execute(
        self,
        base_request: PrintRequestData,
        products: list[PrintProductData],
        context: Any,
        channel: PrintChannel,
        tpv_key: str,
    ) -> list[ClientTicketPayload]:
        if not tpv_key:
            raise ValueError("tpv_key is required for client printing")
        client_request = self._context_builder.apply_client_context(
            base_request,
            context.kitchen_settings,
            include_header=True,
            details_font_none=True,
            worker=context.worker,
        )
        client_request = self._apply_client_request_overrides(client_request, channel)
        client_request = client_request.model_copy(update={"is_invoice": False})
        data = self._build_client_ticket(
            client_request,
            products,
            context.ticket_settings,
            context.main_printer,
            tpv_key,
        )
        payload = [item.model_dump(mode="json", exclude_none=True) for item in data]
        self._gateway.send_data(tpv_key, payload)
        return data

    def _build_client_ticket(
        self,
        request: PrintRequestData,
        products: list[PrintProductData],
        ticket_settings: Any,
        main_printer: PrinterData,
        tpv_key: str,
    ) -> list[ClientTicketPayload]:
        ticket_builder = ClientTicketBuilder(
            currency_symbol_resolver=self._currency_symbol_resolver,
            domicile_service_label=self._domicile_service_label,
        )
        return ticket_builder.build(
            request=request,
            products=products,
            printer=main_printer,
            ticket_settings=ticket_settings,
            tpv_key=tpv_key,
        )

    def _apply_client_request_overrides(
        self,
        request: PrintRequestData,
        channel: PrintChannel,
    ) -> PrintRequestData:
        if channel != PrintChannel.LOCAL:
            return request
        print_settings = request.PrintSettings
        if not print_settings:
            return request
        return request.model_copy(update={"PrintSettings": print_settings.model_copy(update={"show_header": False})})
