from __future__ import annotations

from typing import Any, Callable

from printer_core.context.ticket_context_builder import TicketContextBuilder
from printer_core.entities import (
    KitchenProductLine,
    KitchenTicketPayload,
    PrintChannel,
    PrintProductData,
    PrintRequestData,
    PrinterData,
    ProductsGroup,
)
from printer_core.ports import FamilyCategoryProvider, HeaderProvider, PrinterGateway, PrintSettingsBuilder
from printer_core.services.multi_printer_family_service import MultiPrinterFamilyService
from printer_core.services.multi_printer_service import MultiPrinterService
from printer_core.services.print_policy import FlowTarget


class KitchenPrintFlow:
    target = FlowTarget.KITCHEN

    def __init__(
        self,
        gateway: PrinterGateway,
        header_provider: HeaderProvider,
        print_settings_builder: PrintSettingsBuilder,
        family_provider: FamilyCategoryProvider,
        currency_symbol_resolver: Callable[[str], str],
    ):
        self._gateway = gateway
        self._family_provider = family_provider
        self._currency_symbol_resolver = currency_symbol_resolver
        self._context_builder = TicketContextBuilder(
            header_provider=header_provider,
            print_settings_builder=print_settings_builder,
        )

    def execute(
        self,
        base_request: PrintRequestData,
        products: list[PrintProductData],
        context: Any,
        channel: PrintChannel,
        tpv_key: str | None = None,
    ) -> list[KitchenTicketPayload]:
        kitchen_request = self._context_builder.apply_kitchen_context(
            base_request,
            context.ticket_settings,
            context.kitchen_settings,
            header_mode=self._header_mode(channel),
            include_print_by=self._include_print_by(channel),
            worker=context.worker,
        )
        return self._dispatch_kitchen(
            request=kitchen_request,
            products=products,
            ticket_settings=context.ticket_settings,
            kitchen_settings=context.kitchen_settings,
            main_printer=context.main_printer,
        )

    def _dispatch_kitchen(
        self,
        request: PrintRequestData,
        products: list[PrintProductData],
        ticket_settings: Any,
        kitchen_settings: Any,
        main_printer: PrinterData,
    ) -> list[KitchenTicketPayload]:
        if getattr(kitchen_settings, "print_by", "categories") == "categories":
            service = MultiPrinterService(
                gateway=self._gateway,
                currency_symbol_resolver=self._currency_symbol_resolver,
                order_by_func=self._noop_order_by,
                group_products_func=self._noop_group_products,
            )
            return service.build_and_dispatch(
                request=request,
                products=products,
                main_printer=main_printer,
                ticket_settings=ticket_settings,
                kitchen_ticket_settings=kitchen_settings,
            )
        service = MultiPrinterFamilyService(
            gateway=self._gateway,
            family_provider=self._family_provider,
            currency_symbol_resolver=self._currency_symbol_resolver,
            order_by_func=self._noop_order_by,
            group_products_func=self._noop_group_products,
        )
        return service.build_and_dispatch(
            request=request,
            products=products,
            main_printer=main_printer,
            ticket_settings=ticket_settings,
            kitchen_ticket_settings=kitchen_settings,
        )

    def _header_mode(self, channel: PrintChannel) -> str:
        if channel in (PrintChannel.DOMICILE, PrintChannel.PICKUP):
            return "domicile"
        return "local"

    def _include_print_by(self, channel: PrintChannel) -> bool:
        return channel not in (PrintChannel.BARRA, PrintChannel.KIOSKO)

    def _noop_order_by(self, products: list[KitchenProductLine]) -> list[KitchenProductLine]:
        return products

    def _noop_group_products(self, products: list[KitchenProductLine]) -> list[ProductsGroup]:
        return [ProductsGroup(group="Sin orden", products=products)]
