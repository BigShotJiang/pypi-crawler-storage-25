from typing import Any, Callable

from printer_core.algorithms.products_modifiers_multiprinter_family import (
    ProductsModifiersMultiprinterFamily,
)
from printer_core.builders.printer_products_grouper import PrinterProductsGrouper
from printer_core.dispatchers.kitchen_ticket_dispatcher import KitchenTicketDispatcher
from printer_core.entities import (
    KitchenProductLine,
    KitchenTicketPayload,
    PrintProductData,
    PrintRequestData,
    PrinterData,
    ProductsGroup,
)
from printer_core.formatters.discount_formatter import DiscountFormatter
from printer_core.ports import FamilyCategoryProvider, PrinterGateway
from printer_core.selectors.family_product_selector import FamilyProductSelector
from printer_core.utils.printer_helpers import group_products_by_orders, order_products_by_name


class MultiPrinterFamilyService:
    def __init__(
        self,
        gateway: PrinterGateway,
        family_provider: FamilyCategoryProvider,
        currency_symbol_resolver: Callable[[str], str],
        order_by_func: Callable[[list[KitchenProductLine]], list[KitchenProductLine]] | None = None,
        group_products_func: Callable[[list[KitchenProductLine]], list[ProductsGroup]] | None = None,
    ):
        self._gateway = gateway
        self._family_provider = family_provider
        self._currency_symbol_resolver = currency_symbol_resolver
        self._order_by_func = order_by_func or order_products_by_name
        self._group_products_func = group_products_func or group_products_by_orders

    def build_and_dispatch(
        self,
        request: PrintRequestData,
        products: list[PrintProductData],
        main_printer: PrinterData,
        ticket_settings: Any,
        kitchen_ticket_settings: Any,
    ) -> list[KitchenTicketPayload]:
        selector = FamilyProductSelector(provider=self._family_provider)
        families, products_by_family, products_without_family = selector.group_products(products)

        formatter = DiscountFormatter(currency_symbol_resolver=self._currency_symbol_resolver)
        family_builder = ProductsModifiersMultiprinterFamily(formatter)
        list_products_own_printer: list[KitchenProductLine] = []
        dispatched: list[KitchenTicketPayload] = []

        for family in families:
            list_products_own_printer.clear()
            family_products = products_by_family.get(family.id, [])
            for product in family_products:
                if product.printer:
                    product_with_printer = product
                else:
                    product_with_printer = product.model_copy(update={"printer": [main_printer]})
                family_builder.append_product(
                    list_products_own_printer, product_with_printer, request, kitchen_ticket_settings
                )
            dispatched.extend(self._dispatch_products(
                list_products_own_printer, request, ticket_settings, kitchen_ticket_settings
            ))

        list_products_own_printer.clear()
        for product in products_without_family:
            if product.printer:
                product_with_printer = product
            else:
                product_with_printer = product.model_copy(update={"printer": [main_printer]})
            family_builder.append_product(
                list_products_own_printer, product_with_printer, request, kitchen_ticket_settings
            )

        dispatched.extend(self._dispatch_products(
            list_products_own_printer, request, ticket_settings, kitchen_ticket_settings
        ))
        return dispatched

    def _dispatch_products(
        self,
        list_products_own_printer: list[KitchenProductLine],
        request: PrintRequestData,
        ticket_settings: Any,
        kitchen_ticket_settings: Any,
    ) -> list[KitchenTicketPayload]:
        if not list_products_own_printer:
            return []
        if (request.order_by or "standard") == "name":
            list_products_own_printer = self._order_by_func(list_products_own_printer)
        grouped_products = PrinterProductsGrouper.group_by_printer_key(list_products_own_printer)
        dispatcher = KitchenTicketDispatcher(gateway=self._gateway)
        return dispatcher.dispatch(
            request=request,
            grouped_products=grouped_products,
            ticket_settings=ticket_settings,
            kitchen_ticket_settings=kitchen_ticket_settings,
            group_products_func=self._group_products_func,
        )
