from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from printer_core.entities import PrintChannel, PrintRequestData


class FlowTarget(str, Enum):
    KITCHEN = "kitchen"
    CLIENT = "client"


@dataclass(frozen=True)
class PrintPlan:
    enabled_flows: set[FlowTarget] = field(default_factory=set)
    reasons: list[str] = field(default_factory=list)

    @property
    def print_kitchen(self) -> bool:
        return FlowTarget.KITCHEN in self.enabled_flows

    @property
    def print_client(self) -> bool:
        return FlowTarget.CLIENT in self.enabled_flows


class PrintPolicy:
    def __init__(self, channel: PrintChannel, ticket_settings: Any, global_settings: Any):
        self._channel = channel
        self._ticket_settings = ticket_settings
        self._global_settings = global_settings

    def plan(self, request: PrintRequestData) -> PrintPlan:
        print_kitchen = self._should_print_kitchen()
        print_client = self._should_print_client(request)
        enabled_flows: set[FlowTarget] = set()
        if print_kitchen:
            enabled_flows.add(FlowTarget.KITCHEN)
        if print_client:
            enabled_flows.add(FlowTarget.CLIENT)
        return PrintPlan(enabled_flows=enabled_flows)

    def _should_print_kitchen(self) -> bool:
        if self._channel in (PrintChannel.KIOSKO, PrintChannel.BARRA):
            return bool(getattr(self._ticket_settings, "ticket_kitchen_barra", False))
        if self._channel == PrintChannel.LOCAL:
            return bool(getattr(self._ticket_settings, "ticket_kitchen_local", False))
        return bool(getattr(self._ticket_settings, "ticket_kitchen_domicile_or_pickup", False))

    def _should_print_client(self, request: PrintRequestData) -> bool:
        if self._channel in (PrintChannel.KIOSKO, PrintChannel.BARRA):
            enabled = bool(getattr(self._ticket_settings, "ticket_client_barra", False))
            if not enabled:
                return False
            if self._channel == PrintChannel.BARRA and self._barra_payment_suppresses(request):
                return False
            return True
        if self._channel == PrintChannel.LOCAL:
            return bool(getattr(self._ticket_settings, "ticket_client_local", False))
        return bool(getattr(self._ticket_settings, "ticket_client_domicile_or_pickup", False))

    def _barra_payment_suppresses(self, request: PrintRequestData) -> bool:
        credit_card = bool(request.credit_card)
        if getattr(self._global_settings, "use_payment_terminal", False) and credit_card:
            return True
        if getattr(self._global_settings, "use_cashmatic", False) and not credit_card:
            return True
        if getattr(self._global_settings, "use_cashlogy", False) and not credit_card:
            return True
        return False
