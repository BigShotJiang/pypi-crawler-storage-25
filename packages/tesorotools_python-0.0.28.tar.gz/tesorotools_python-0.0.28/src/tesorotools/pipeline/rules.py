"""Built-in transformation rule factories.

Each factory function takes an output name, its source
column(s), and optional parameters, and returns a single
``TransformationRule``.

Projects can register additional factories in the
``FACTORIES`` dict to make them available from YAML config.

NaN-aware operations
--------------------
``yoy_rule`` and ``rolling_sum_rule`` drop NaN before
calling ``shift()`` / ``rolling()`` so that the window
counts real observations, not DataFrame rows.  This is
essential when monthly and quarterly series coexist in
the same DataFrame.
"""

from __future__ import annotations

from collections.abc import Callable

import pandas as pd

from tesorotools.pipeline.engine import TransformationRule


def scale_rule(output: str, source: str, divisor: float) -> TransformationRule:
    """Divide a column by a constant."""
    return TransformationRule(
        output_name=output,
        dependencies=[source],
        compute=lambda df, s=source, d=divisor: df[s] / d,
    )


def sum_rule(output: str, sources: list[str]) -> TransformationRule:
    """Sum multiple columns (NaN-safe with min_count=1)."""
    return TransformationRule(
        output_name=output,
        dependencies=list(sources),
        compute=lambda df, cols=list(sources): df[cols].sum(
            axis=1, min_count=1
        ),
    )


def ratio_rule(
    output: str, numerator: str, denominator: str
) -> TransformationRule:
    """Divide one column by another."""
    return TransformationRule(
        output_name=output,
        dependencies=[numerator, denominator],
        compute=lambda df, n=numerator, d=denominator: df[n] / df[d],
    )


def difference_rule(
    output: str,
    dependencies: list[str],
) -> TransformationRule:
    """Subtract the second column from the first."""
    if len(dependencies) != 2:
        raise ValueError(
            f"difference requires exactly 2 dependencies,"
            f" got {len(dependencies)}"
        )
    target, reference = dependencies
    return TransformationRule(
        output_name=output,
        dependencies=[target, reference],
        compute=lambda df, t=target, r=reference: df[t] - df[r],
    )


def inverse_rule(
    output: str,
    dependencies: list[str],
) -> TransformationRule:
    """Compute 1 / source."""
    if len(dependencies) != 1:
        raise ValueError(
            f"inverse requires exactly 1 dependency, got {len(dependencies)}"
        )
    source = dependencies[0]
    return TransformationRule(
        output_name=output,
        dependencies=[source],
        compute=lambda df, s=source: 1 / df[s],
    )


def pct_change_rule(
    output: str, source: str, periods: int = 12
) -> TransformationRule:
    """Periodic percentage change: source_t / source_{t-N} - 1.

    Drops NaN before shifting so that *periods* counts
    actual observations, not DataFrame rows.
    """

    def _compute(
        df: pd.DataFrame,
        s: str = source,
        p: int = periods,
    ) -> pd.Series[float]:
        clean: pd.Series[float] = df[s].dropna()
        return clean / clean.shift(p) - 1

    return TransformationRule(
        output_name=output,
        dependencies=[source],
        compute=_compute,
    )


def rolling_sum_rule(
    output: str, source: str, window: int = 4
) -> TransformationRule:
    """Rolling sum (e.g. 4-quarter annualization).

    Drops NaN before rolling so that *window* counts
    actual observations.
    """

    def _compute(
        df: pd.DataFrame,
        s: str = source,
        w: int = window,
    ) -> pd.Series[float]:
        clean: pd.Series[float] = df[s].dropna()
        return clean.rolling(window=w, min_periods=w).sum()

    return TransformationRule(
        output_name=output,
        dependencies=[source],
        compute=_compute,
    )


def delta_rule(
    output: str, source: str, periods: int = 1
) -> TransformationRule:
    """Level change: source_t - source_{t-periods}.

    Drops NaN before shifting (mixed-frequency safe).
    """

    def _compute(
        df: pd.DataFrame,
        s: str = source,
        p: int = periods,
    ) -> pd.Series[float]:
        clean: pd.Series[float] = df[s].dropna()
        return clean - clean.shift(p)

    return TransformationRule(
        output_name=output,
        dependencies=[source],
        compute=_compute,
    )


def cumsum_rule(output: str, source: str) -> TransformationRule:
    """Cumulative sum of a column.

    Drops NaN before cumsum (mixed-frequency safe).
    """

    def _compute(df: pd.DataFrame, s: str = source) -> pd.Series[float]:
        clean: pd.Series[float] = df[s].dropna()
        return clean.cumsum()

    return TransformationRule(
        output_name=output,
        dependencies=[source],
        compute=_compute,
    )


#: Registry of factory functions, keyed by YAML function name.
#: Projects can add custom factories at runtime.
FACTORIES: dict[
    str,
    Callable[..., TransformationRule],
] = {
    "scale": scale_rule,
    "sum": sum_rule,
    "ratio": ratio_rule,
    "difference": difference_rule,
    "inverse": inverse_rule,
    "pct_change": pct_change_rule,
    "rolling_sum": rolling_sum_rule,
    "delta": delta_rule,
    "cumsum": cumsum_rule,
}
