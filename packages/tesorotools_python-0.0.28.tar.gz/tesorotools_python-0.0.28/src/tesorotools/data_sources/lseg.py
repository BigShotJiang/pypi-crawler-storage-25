import logging
import time
from pathlib import Path

import lseg.data as ld
import pandas as pd

logger = logging.getLogger(__name__)

MAX_RETRIES = 150


def get_series(
    api_key: str,
    series_id_list: list[str],
    start_date: str,
    end_date: str,
    freq: str = "B",
    fields: list[str] | None = None,
    cooldown: int = 60,
    datapoint_limit: int = 2_000,
    cache_path: Path | None = None,
) -> pd.DataFrame:
    """Downloads data from LSEG given a valid API key."""
    ld.open_session(app_key=api_key)
    fields = ["TIMESTAMP", "CLOSE"] if fields is None else fields

    dates_list: list[str] = list(
        pd.date_range(start=start_date, end=end_date, freq=freq).astype("str")
    )
    partial_data: list[pd.DataFrame] = []
    download_step: int = datapoint_limit // (
        len(series_id_list) * (len(fields) - 1)
    )
    downloaded_dates: int = 0
    data: pd.DataFrame = pd.DataFrame()
    while downloaded_dates < len(dates_list):
        dates_to_download = dates_list[
            downloaded_dates : downloaded_dates + download_step
        ]
        start = dates_to_download[0]
        end = dates_to_download[-1]
        cache_file_path: Path | None = (
            cache_path / f"from_{start}_to_{end}.csv"
            if cache_path is not None
            else None
        )
        if (cache_file_path is None) or (not cache_file_path.exists()):
            data = block_download(
                series_id_list,
                start_date=start,
                end_date=end,
                freq=freq,
                fields=fields,
                cooldown=cooldown,
                file_path=cache_file_path,
            )
            if cache_file_path is None:
                partial_data.append(data)
            if downloaded_dates + download_step < len(dates_list):
                logger.info(
                    "Waiting %d seconds for LSEG cooldown...",
                    cooldown,
                )
                time.sleep(cooldown)
        downloaded_dates += download_step
    return data


def block_download(
    series_id_list: list[str],
    start_date: str,
    end_date: str,
    freq: str = "B",
    fields: list[str] | None = None,
    cooldown: int = 60,
    file_path: Path | None = None,
    max_retries: int = MAX_RETRIES,
) -> pd.DataFrame:
    interval = "daily" if freq == "B" else freq

    for attempt in range(1, max_retries + 1):
        try:
            data: pd.DataFrame | None = ld.get_history(  # type: ignore[reportUnknownMemberType]
                universe=series_id_list,
                start=start_date,
                end=end_date,
                fields=fields,
                interval=interval,
            )
            if data is None:  # type: ignore[reportUnnecessaryComparison]
                raise ld.errors.LDError(
                    code=404,
                    message="Service temporarily unavailable",
                )
            data = data.drop_duplicates()
            data = data.sort_index()
            if len(data.columns) == 1:
                data.columns = pd.Index(series_id_list)
            if file_path is not None:
                data.to_csv(file_path)
            return data
        except ld.errors.LDError as e:
            logger.warning(
                "LSEG error (attempt %d/%d): %s",
                attempt,
                max_retries,
                e,
            )
            if attempt == max_retries:
                raise
        logger.info(
            "Waiting %d seconds for LSEG cooldown...",
            cooldown,
        )
        time.sleep(cooldown)

    raise RuntimeError("Unreachable")


def concat_partial_data(
    cache_path: Path | None,
    partial_data: list[pd.DataFrame],
) -> pd.DataFrame:
    dfs = list(partial_data)
    if cache_path is not None:
        for chunk in cache_path.iterdir():
            df: pd.DataFrame = pd.read_csv(chunk, index_col="Date")
            dfs.append(df)
    full: pd.DataFrame = pd.concat(dfs)
    return full
