"""
Módulo de gestión de bases de datos y persistencia para tesorotools.
Contiene las utilidades para interactuar con bases de datos locales y remotas.
"""

from tesorotools.database.local import LocalDatabase, ShortcutDatabase

__all__ = [
    "LocalDatabase",
    "ShortcutDatabase",
]
