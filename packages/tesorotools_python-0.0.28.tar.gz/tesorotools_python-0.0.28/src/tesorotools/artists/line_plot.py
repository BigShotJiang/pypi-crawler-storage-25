import datetime
import locale
from pathlib import Path
from typing import Any, Self

import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.axes import Axes
from matplotlib.figure import Figure
from matplotlib.ticker import FuncFormatter
from yaml.nodes import MappingNode

from tesorotools.utils.config import TemplateLoader
from tesorotools.utils.matplotlib import (
    PLOT_CONFIG,
    format_annotation,
    load_fonts,
)

locale.setlocale(locale.LC_ALL, "")

load_fonts()

LINE_PLOT_CONFIG: dict[str, Any] = PLOT_CONFIG["line"]
AX_CONFIG: dict[str, Any] = PLOT_CONFIG["ax"]
FIG_CONFIG: dict[str, Any] = PLOT_CONFIG["figure"]


def adjust_figure_for_plot_size(
    fig: Figure,
    ax: Axes,
    plot_size: tuple[float, float],
) -> None:
    """Resize the figure so the axes area matches *plot_size*.

    Call this **after** adding the legend.  The figure
    height grows to accommodate the legend while keeping
    the plot area at the requested size.

    Parameters
    ----------
    fig
        The figure to resize.
    ax
        The axes whose area should match *plot_size*.
    plot_size
        Desired ``(width, height)`` of the axes area in
        inches.
    """
    fig.canvas.draw()  # type: ignore[reportUnknownMemberType]
    renderer = fig.canvas.get_renderer()  # type: ignore[reportUnknownMemberType]
    ax_bbox = ax.get_tightbbox(renderer)  # type: ignore[reportUnknownArgumentType]
    fig_bbox = fig.get_tightbbox(renderer)  # type: ignore[reportUnknownArgumentType]
    if ax_bbox is None or fig_bbox is None:  # type: ignore[reportUnnecessaryComparison]
        return
    fig_w, fig_h = fig.get_size_inches()
    ax_w_in = ax_bbox.width / fig.dpi
    ax_h_in = ax_bbox.height / fig.dpi
    if ax_w_in <= 0 or ax_h_in <= 0:
        return
    new_w = fig_w * (plot_size[0] / ax_w_in)
    new_h = fig_h * (plot_size[1] / ax_h_in)
    fig.set_size_inches(new_w, new_h)


def auto_ncol(ax: Axes, labels: list[str]) -> int:
    """Choose the maximum legend ncol that fits the axes.

    Renders each label as a temporary Text to measure its
    width, then packs as many columns as the axes width
    allows, with padding for the legend handle + spacing.
    Falls back to ``len(labels)`` (single row) when all
    labels are short enough.
    """
    fig = ax.get_figure()
    if fig is None:
        return len(labels)
    renderer = fig.canvas.get_renderer()  # type: ignore[reportUnknownMemberType]
    ax_width_px = ax.get_window_extent(renderer).width  # type: ignore[reportUnknownArgumentType]

    # Measure widest label in pixels.
    handle_pad_px = 40.0  # handle icon + spacing estimate
    max_label_px = 0.0
    for label in labels:
        t = ax.text(  # type: ignore[reportUnknownMemberType]
            0, 0, label
        )
        bbox = t.get_window_extent(renderer)  # type: ignore[reportUnknownArgumentType]
        max_label_px = max(max_label_px, bbox.width)
        t.remove()

    col_width = max_label_px + handle_pad_px
    if col_width <= 0:
        return len(labels)
    ncol = max(1, int(ax_width_px / col_width))
    return min(ncol, len(labels))


def style_spines(
    ax: Axes,
    decimals: int,
    units: str,
    *,
    color: str,
    linewidth: float,
) -> None:
    ax.grid(  # type: ignore[reportUnknownMemberType]
        visible=True, axis="y"
    )
    for spine in ax.spines.values():
        spine.set_color(color)
        spine.set_linewidth(linewidth)
    ax.yaxis.tick_right()

    def _fmt_tick(y: float, _pos: int) -> str:
        return format_annotation(y, decimals, units)

    ax.yaxis.set_major_formatter(FuncFormatter(_fmt_tick))
    ax.set_xlabel(  # type: ignore[reportUnknownMemberType]
        ""
    )

    ax.tick_params(  # type: ignore[reportUnknownMemberType]
        which="minor", size=0, width=0
    )
    ax.tick_params(  # type: ignore[reportUnknownMemberType]
        axis="both", which="major"
    )
    for tick in ax.get_xticklines():
        tick.set_markeredgecolor(color)
    for tick in ax.get_yticklines():
        tick.set_markeredgecolor(color)


def export_legend(
    ax: Axes,
    out_path: Path,
    *,
    ncol: int = 5,
    dpi: int = 500,
) -> None:
    """Save the legend of *ax* as a standalone PNG.

    The plot's own legend is removed after export.
    """
    handles, labels = ax.get_legend_handles_labels()
    fig_leg = plt.figure(  # type: ignore[reportUnknownMemberType]
        figsize=(6, 0.5), dpi=dpi
    )
    fig_leg.legend(  # type: ignore[reportUnknownMemberType]
        handles,
        labels,
        loc="center",
        ncol=ncol,
    )
    fig_leg.savefig(  # type: ignore[reportUnknownMemberType]
        out_path, bbox_inches="tight"
    )
    plt.close(fig_leg)
    legend = ax.get_legend()
    if legend is not None:
        legend.remove()


def style_baseline(
    ax: Axes,
    reference: float = 0,
    **baseline_config: Any,
) -> None:
    color: str = baseline_config["color"]
    bottom_lim, top_lim = ax.get_ylim()
    ax.set_ylim(
        bottom=min(reference, bottom_lim),
        top=max(reference, top_lim),
    )
    bottom_lim, top_lim = ax.get_ylim()
    if bottom_lim == reference:
        ax.spines["bottom"].set_edgecolor(color)
    elif top_lim == reference:
        ax.spines["top"].set_edgecolor(color)
    else:
        ax.axhline(  # type: ignore[reportUnknownMemberType]
            y=reference, **baseline_config
        )


def plot_line_chart(
    out_name: Path,
    data: pd.DataFrame,
    *,
    base_100: bool,
    annotate: bool,
    format: dict[str, Any],
    **kwargs: Any,
) -> None:
    if base_100:
        data = data / data.iloc[0, :] * 100
    if format["units"] == "p.b.":
        data = data * 100
    fig: Figure = plt.figure(  # type: ignore[reportUnknownMemberType]
        **FIG_CONFIG
    )
    ax = fig.add_subplot()
    data.plot(ax=ax)
    if annotate:
        pass

    reference = 100 if base_100 else 0
    style_spines(ax, **format, **AX_CONFIG["spines"])
    style_baseline(ax, reference, **AX_CONFIG["baseline"])
    ax.legend(  # type: ignore[reportUnknownMemberType]
        loc="upper center",
        bbox_to_anchor=(0.5, LINE_PLOT_CONFIG["legend_sep"]),
        ncol=(
            kwargs["legend"]["ncol"]
            if kwargs.get("legend", None) is not None
            else LINE_PLOT_CONFIG["ncol"]
        ),
    )

    fig.savefig(  # type: ignore[reportUnknownMemberType]
        out_name
    )


def plot_line_charts(
    out_path: Path,
    data: pd.DataFrame,
    config_dicts: dict[str, Any],
) -> None:
    for name, config in config_dicts.items():
        start_date: pd.Timestamp = pd.Timestamp(config["start_date"])
        end_date_str: str | None = config["end_date"]
        end_date: pd.Timestamp = (
            data.index.max()
            if end_date_str is None
            else pd.Timestamp(end_date_str)
        )
        series: dict[str, str] = config["series"]
        trimmed_data: pd.DataFrame = data.loc[
            slice(start_date, end_date), series.keys()
        ]
        trimmed_data = trimmed_data.rename(columns=series)
        out_name: Path = out_path / f"{name}.png"
        plot_line_chart(out_name, trimmed_data, **config)


class Format:
    def __init__(self, units: str = "", decimals: int = 0) -> None:
        self.units = units
        self.decimals = decimals

    @classmethod
    def from_yaml(cls, loader: TemplateLoader, node: MappingNode) -> Self:
        loader.flatten_mapping(node)
        format_cfg: dict[str, Any] = loader.construct_mapping(  # type: ignore[assignment]
            node, deep=True
        )
        format_cfg.pop("id")
        return cls(**format_cfg)


class Legend:
    def __init__(
        self,
        ncol: int | None = None,
        sep: float = -0.125,
    ) -> None:
        self.ncol = ncol
        self.sep = sep

    @classmethod
    def from_yaml(cls, loader: TemplateLoader, node: MappingNode) -> Self:
        legend_cfg: dict[str, Any] = loader.construct_mapping(  # type: ignore[assignment]
            node, deep=True
        )
        legend_cfg.pop("id")
        return cls(**legend_cfg)


# as more stuff is needed, seems wise to make a class
class LinePlot:
    def __init__(
        self,
        out_path: Path,
        data_path: Path | None = None,
        series: dict[str, str] | None = None,
        scale: float = 1,
        start_date: datetime.datetime | None = None,
        end_date: datetime.datetime | None = None,
        base_100: bool = False,
        annotate: bool = False,
        baseline: bool = False,
        format: Format | None = None,
        legend: Legend | None = None,
        data: pd.DataFrame | None = None,
        figsize: tuple[float, float] | None = None,
        series_styles: dict[str, dict[str, Any]] | None = None,
        plot_size: tuple[float, float] | None = None,
    ) -> None:

        if out_path.suffix != ".png":
            raise ValueError(f"The out file {out_path} should be a .png file")
        self.out_path = out_path

        if data is not None and data_path is not None:
            raise ValueError("Provide data or data_path, not both")
        if data is not None:
            self.data = data
        elif data_path is not None:
            if data_path.suffix != ".feather":
                raise ValueError(
                    f"The data file {data_path} must be a .feather file"
                )
            self.data = pd.read_feather(data_path)
        else:
            raise ValueError("Provide data or data_path")

        if series is None:
            raise ValueError("series is required")

        self.base_100 = base_100
        self.annotate = annotate  # unused for the moment
        self.format = format
        self.start_date = start_date
        self.end_date = end_date
        self.series = series
        self.legend = legend
        self.baseline = baseline
        self.scale = scale
        self.figsize = figsize
        self.series_styles = series_styles or {}
        self.plot_size = plot_size

    @classmethod
    def from_yaml(cls, loader: TemplateLoader, node: MappingNode) -> Self:
        line_plot_cfg: dict[str, Any] = loader.construct_mapping(  # type: ignore[assignment]
            node, deep=True
        )
        line_plot_cfg.pop("id")
        line_plot_cfg["out_path"] = Path(line_plot_cfg["out_path"])
        line_plot_cfg["data_path"] = Path(line_plot_cfg["data_path"])
        return cls(**line_plot_cfg)

    def plot(self) -> Axes:
        start_date: pd.Timestamp = (
            self.data.index.min()
            if self.start_date is None
            else pd.to_datetime(self.start_date)
        )

        end_date: pd.Timestamp = (
            self.data.index.max()
            if self.end_date is None
            else pd.to_datetime(self.end_date)
        )

        plot_data: pd.DataFrame = self.data.loc[
            slice(start_date, end_date), self.series.keys()
        ]
        plot_data = plot_data.rename(columns=self.series)

        plot_data = plot_data * self.scale

        if self.base_100:  # maybe more flexible in the future
            plot_data = plot_data / plot_data.iloc[0, :] * 100

        fig_kw = dict(FIG_CONFIG)
        if self.figsize is not None:
            fig_kw["figsize"] = self.figsize
        fig: Figure = plt.figure(  # type: ignore[reportUnknownMemberType]
            **fig_kw
        )
        ax = fig.add_subplot()
        if self.series_styles:
            for col in plot_data.columns:
                style = self.series_styles.get(col, {})
                plot_data[col].plot(ax=ax, label=col, **style)
        else:
            plot_data.plot(ax=ax)

        if self.annotate:  # not implemented yet
            pass

        assert self.format is not None
        style_spines(  # maybe make this function accept a Format object
            ax,
            decimals=self.format.decimals,
            units=self.format.units,
            **AX_CONFIG["spines"],
        )
        if self.baseline:
            reference = 100 if self.base_100 else 0
            style_baseline(ax, reference, **AX_CONFIG["baseline"])

        if self.legend is not None:
            labels = list(plot_data.columns)
            ncol = (
                self.legend.ncol
                if self.legend.ncol is not None
                else auto_ncol(ax, labels)
            )
            ax.legend(  # type: ignore[reportUnknownMemberType]
                loc="upper center",
                bbox_to_anchor=(
                    0.5,
                    LINE_PLOT_CONFIG["legend_sep"],
                ),
                ncol=ncol,
            )
        else:
            ax.legend().set_visible(  # type: ignore[reportUnknownMemberType]
                False
            )

        if self.plot_size is not None:
            adjust_figure_for_plot_size(fig, ax, self.plot_size)

        fig.savefig(  # type: ignore[reportUnknownMemberType]
            self.out_path
        )
        return ax
