"""Internal runner — connects to the gateway, dispatches messages to user code.

Not a public API. Invoked by the start script inside the runtime:

    python -m cpsl.runner module:ClassName
"""

from __future__ import annotations

import asyncio
import importlib
import json
import os
import signal
import subprocess
import sys
import threading
import time
from typing import Any

from aiohttp import web

from .channel import Channel as GrpcChannel
from .channels import Channel
from .clients.capsule import (
    GetSessionRequest,
    GetWorkRequest,
    HeartbeatRequest,
    RegisterRequest,
    RunnerServiceStub,
    SaveSessionDataRequest,
    SessionServiceStub,
    SubmitResultRequest,
    WorkItem,
)
from .decorators import _BOOT_ATTR, _SHUTDOWN_ATTR, _ENTER_ATTR, _EXIT_ATTR, _MESSAGE_ATTR
from .msg import Message
from .session import Session, UserInfo

_PORT = 8080
_HEARTBEAT_INTERVAL = 10
_MAX_BACKOFF = 30

_log = lambda msg: print(f"[cpsl] {msg}", file=sys.stderr)  # noqa: E731


def _find_hook(instance: object, attr: str):
    for name in dir(instance):
        fn = getattr(instance, name, None)
        if callable(fn) and getattr(fn, attr, False):
            return fn
    return None


async def _maybe_await(result):
    if asyncio.iscoroutine(result):
        return await result
    return result


class Runner:
    def __init__(self, module_path: str, class_name: str) -> None:
        self.module_path = module_path
        self.class_name = class_name
        self._cls = getattr(importlib.import_module(module_path), class_name)
        self._instance: Any = None
        self._hooks: dict[str, Any] = {}
        self._sessions: dict[str, Session] = {}
        self._session_stub: SessionServiceStub | None = None
        self._runner_stub: RunnerServiceStub | None = None
        self._app_id: str = ""
        self._version_id: str = ""
        self._retries: int = 0
        self._loop: asyncio.AbstractEventLoop | None = None

    # ── lifecycle ────────────────────────────────────────────────────────

    async def boot(self) -> None:
        self._instance = self._cls()
        for key in (_BOOT_ATTR, _SHUTDOWN_ATTR, _ENTER_ATTR, _EXIT_ATTR, _MESSAGE_ATTR):
            self._hooks[key] = _find_hook(self._instance, key)
        if self._hooks[_BOOT_ATTR]:
            await _maybe_await(self._hooks[_BOOT_ATTR]())

    async def shutdown(self) -> None:
        if self._hooks.get(_SHUTDOWN_ATTR):
            await _maybe_await(self._hooks[_SHUTDOWN_ATTR]())

    # ── session management ──────────────────────────────────────────────

    async def _get_session(self, msg: WorkItem) -> tuple[Session, bool]:
        if msg.session_id in self._sessions:
            return self._sessions[msg.session_id], False

        user = UserInfo(id=msg.user_id, email=msg.user_email or None)
        channel_type = msg.channel_type or "chat"
        history: list[Message] = []
        data: dict[str, Any] = {}

        if self._session_stub:
            try:
                resp = await asyncio.get_event_loop().run_in_executor(
                    None, self._session_stub.get_session,
                    GetSessionRequest(session_id=msg.session_id, history_count=50),
                )
                if resp.user_id:
                    user = UserInfo(id=resp.user_id, email=resp.user_email or None)
                if resp.channel_type:
                    channel_type = resp.channel_type
                if resp.data_json:
                    data = json.loads(resp.data_json)
                history = [
                    Message(text=e.text, sender=e.sender, channel_type=e.channel_type)
                    for e in resp.history
                ]
            except Exception as exc:
                _log(f"GetSession failed: {exc}")

        session = Session(
            id=msg.session_id, user=user,
            channel=Channel(type=channel_type), history=history, data=data,
        )
        self._sessions[msg.session_id] = session
        return session, True

    async def _persist(self, session: Session) -> None:
        if not self._session_stub:
            return
        try:
            await asyncio.get_event_loop().run_in_executor(
                None, self._session_stub.save_session_data,
                SaveSessionDataRequest(
                    session_id=session.id, data_json=json.dumps(session.data),
                ),
            )
        except Exception as exc:
            _log(f"SaveSessionData failed: {exc}")

    # ── message handling ────────────────────────────────────────────────

    async def _handle(self, item: WorkItem) -> None:
        session, is_new = await self._get_session(item)
        rid = item.request_id

        if is_new and self._hooks.get(_ENTER_ATTR):
            await _maybe_await(self._hooks[_ENTER_ATTR](session))

        user_msg = Message(text=item.text, sender="user", channel_type=session.channel.type)
        session.history.append(user_msg)

        session._reply_callback = lambda m: self._submit(rid, m.text)
        session._stream_callback = lambda chunks: self._stream_chunks(rid, chunks)

        handler = self._hooks.get(_MESSAGE_ATTR)
        if handler:
            await _maybe_await(handler(session, user_msg))

        self._submit(rid, "", done=True)
        await self._persist(session)

    def _submit(self, request_id: str, text: str, done: bool = False) -> None:
        """Send a result chunk back to the gateway via unary SubmitResult RPC."""
        if not self._runner_stub:
            return
        try:
            self._runner_stub.submit_result(
                SubmitResultRequest(request_id=request_id, text=text, done=done)
            )
        except Exception as exc:
            _log(f"SubmitResult failed: {exc}")

    async def _stream_chunks(self, request_id: str, chunks) -> None:
        async for text in chunks:
            self._submit(request_id, text)

    # ── gRPC transport: register + heartbeat + pull ─────────────────────

    def _register(self) -> None:
        _log(f"registering app_id={self._app_id}")
        self._runner_stub.register(
            RegisterRequest(app_id=self._app_id, version_id=self._version_id)
        )

    def _heartbeat_loop(self, stop: threading.Event) -> None:
        """Runs in a background thread. Sends heartbeat every 10s."""
        while not stop.is_set():
            try:
                resp = self._runner_stub.heartbeat(
                    HeartbeatRequest(app_id=self._app_id)
                )
                if resp.update and resp.update.sdk_version:
                    self._do_update(resp.update.sdk_version)
            except Exception as exc:
                _log(f"heartbeat failed: {exc}")
                return
            stop.wait(_HEARTBEAT_INTERVAL)

    def _work_loop(self, stop: threading.Event) -> None:
        """Runs in a background thread. Opens GetWork server-stream, dispatches items."""
        while not stop.is_set():
            try:
                for item in self._runner_stub.get_work(
                    GetWorkRequest(app_id=self._app_id)
                ):
                    if stop.is_set():
                        return
                    if item.request_id and self._loop:
                        asyncio.run_coroutine_threadsafe(
                            self._handle(item), self._loop
                        ).result(timeout=300)
                        self._retries = 0
            except Exception as exc:
                _log(f"work stream error: {exc}")
                return

    def _do_update(self, version: str) -> None:
        _log(f"updating SDK → {version}")
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", f"cpsl=={version}"],
                stdout=sys.stderr, stderr=sys.stderr,
            )
            _log("SDK updated — will take effect on next reconnect")
        except Exception as exc:
            _log(f"update failed: {exc}")

    # ── serve ───────────────────────────────────────────────────────────

    async def serve(self) -> None:
        gw = os.environ.get("CAPSULE_GATEWAY_HOST", "localhost:1980")
        self._app_id = os.environ.get("CAPSULE_APP_ID", "")
        self._version_id = os.environ.get("CAPSULE_VERSION_ID", "")
        token = os.environ.get("CAPSULE_RUNNER_TOKEN") or None

        _log(f"connecting → {gw}")

        ch = GrpcChannel(addr=gw, token=token)
        sch = GrpcChannel(addr=gw, token=token)
        self._runner_stub = RunnerServiceStub(ch)
        self._session_stub = SessionServiceStub(sch)
        self._loop = asyncio.get_event_loop()

        # Health endpoint (used by sprites service manager)
        app = web.Application()
        app.router.add_get("/health", lambda _: web.json_response({"ok": True}))
        runner = web.AppRunner(app)
        await runner.setup()
        await web.TCPSite(runner, "0.0.0.0", _PORT).start()

        stop = asyncio.Event()
        thread_stop = threading.Event()
        for sig in (signal.SIGTERM, signal.SIGINT):
            self._loop.add_signal_handler(sig, stop.set)

        # Main reconnection loop
        while not stop.is_set():
            try:
                self._register()
                self._retries = 0

                hb = threading.Thread(
                    target=self._heartbeat_loop, args=(thread_stop,), daemon=True
                )
                wk = threading.Thread(
                    target=self._work_loop, args=(thread_stop,), daemon=True
                )
                hb.start()
                wk.start()

                _log(f"connected app_id={self._app_id}")

                while not stop.is_set() and hb.is_alive() and wk.is_alive():
                    await asyncio.sleep(1)

                thread_stop.set()
                hb.join(timeout=5)
                wk.join(timeout=5)
                thread_stop.clear()

                if stop.is_set():
                    break

            except Exception as exc:
                _log(f"connection error: {exc}")

            backoff = min(2 ** self._retries, _MAX_BACKOFF)
            self._retries += 1
            _log(f"reconnecting in {backoff}s (attempt {self._retries})")
            try:
                await asyncio.wait_for(stop.wait(), timeout=backoff)
                break
            except asyncio.TimeoutError:
                pass

        await self.shutdown()
        await runner.cleanup()
        ch.close()
        sch.close()


def main() -> None:
    if len(sys.argv) != 2 or ":" not in sys.argv[1]:
        print("Usage: python -m cpsl.runner <module>:<Class>", file=sys.stderr)
        sys.exit(1)

    mod, cls = sys.argv[1].rsplit(":", 1)

    async def _run():
        r = Runner(mod, cls)
        await r.boot()
        await r.serve()

    asyncio.run(_run())


if __name__ == "__main__":
    main()
