from __future__ import annotations

import time
from collections import defaultdict

from fastapi import WebSocket

from ._debug import dlog, _sizeof


class ConnectionManager:
    """Pub/sub manager for WebSocket connections.

    Each connection subscribes to exactly one channel at a time.

    Channels:
        "workflow_list"          – broadcast run_created / run_updated to all list-page viewers
        "workflow_detail:{id}" – broadcast run_updated to viewers of a specific run
    """

    def __init__(self) -> None:
        self._channels: dict[str, set[WebSocket]] = defaultdict(set)
        # id(ws) → (ws, channel)
        self._ws_channel: dict[int, tuple[WebSocket, str]] = {}

    def subscribe(self, ws: WebSocket, channel: str) -> None:
        ws_id = id(ws)
        if ws_id in self._ws_channel:
            _, old = self._ws_channel[ws_id]
            self._channels[old].discard(ws)
        self._channels[channel].add(ws)
        self._ws_channel[ws_id] = (ws, channel)

    def disconnect(self, ws: WebSocket) -> None:
        ws_id = id(ws)
        if ws_id in self._ws_channel:
            _, channel = self._ws_channel.pop(ws_id)
            self._channels[channel].discard(ws)

    async def broadcast(self, channel: str, message: dict) -> None:
        subscribers = list(self._channels.get(channel, set()))
        dead: list[WebSocket] = []
        t0 = time.perf_counter()
        n_sent = 0
        for ws in subscribers:
            try:
                await ws.send_json(message)
                n_sent += 1
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)
        if n_sent:
            ms = (time.perf_counter() - t0) * 1000
            dlog("WS_SEND", channel, ms, _sizeof(message), f"→ {n_sent} client(s)")


manager = ConnectionManager()
