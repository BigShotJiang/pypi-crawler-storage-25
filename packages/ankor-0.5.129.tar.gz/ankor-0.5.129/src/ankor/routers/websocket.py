from __future__ import annotations

import time

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from ..auth import decode_token
from ..broadcast import manager
from .._debug import dlog, _sizeof


def create_websocket_router() -> APIRouter:
    router = APIRouter()

    @router.websocket("/ws")
    async def ws_endpoint(ws: WebSocket, token: str = ""):
        """Real-time event stream.

        Connect with ?token=<jwt>.  Then send a subscription message:

            {"type": "subscribe", "channel": "workflow_list"}
            {"type": "subscribe", "channel": "workflow_detail", "id": "<run-id>"}
            {"type": "subscribe", "channel": "table", "id": "<table-id>"}
            {"type": "subscribe", "channel": "table_list"}

        The server will reply with {"type": "subscribed", "channel": "..."} and
        then push events as they happen:

            workflow_list  → {"type": "run_created"|"run_updated", "data": <WorkflowRunSummary>}
            workflow_detail → {"type": "run_updated", "data": <WorkflowRun>}
            table:{id}     → {"type": "rows_changed"|"schema_changed"|"row_updated"}
            table_list     → {"type": "table_created"|"table_deleted", "id": <table-id>}
        """
        if not decode_token(token):
            await ws.close(code=4001)
            return
        await ws.accept()
        try:
            while True:
                t_recv = time.perf_counter()
                data = await ws.receive_json()
                recv_ms = (time.perf_counter() - t_recv) * 1000
                dlog("WS_RECV", data.get("type", "?"), recv_ms, _sizeof(data))
                msg_type = data.get("type")
                if msg_type == "subscribe":
                    channel = data.get("channel", "")
                    if channel == "workflow_detail":
                        run_id = data.get("id", "")
                        channel = f"workflow_detail:{run_id}"
                    elif channel == "table":
                        table_id_str = data.get("id", "")
                        channel = f"table:{table_id_str}"
                    if channel:
                        manager.subscribe(ws, channel)
                        await ws.send_json({"type": "subscribed", "channel": channel})
                elif msg_type == "ping":
                    await ws.send_json({"type": "pong"})
        except WebSocketDisconnect:
            manager.disconnect(ws)
        except Exception:
            manager.disconnect(ws)

    return router
