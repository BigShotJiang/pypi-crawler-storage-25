"""Hooks test package."""
