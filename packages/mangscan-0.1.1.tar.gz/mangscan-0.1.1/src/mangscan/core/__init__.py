"""Core orchestration and domain models."""

