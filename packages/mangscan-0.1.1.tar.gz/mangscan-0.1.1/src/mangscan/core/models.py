from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class ScriptResult:
    script_id: str
    output: str


@dataclass
class PortFinding:
    port: int
    protocol: str
    state: str
    service: Optional[str] = None
    product: Optional[str] = None
    version: Optional[str] = None
    extrainfo: Optional[str] = None
    category: str = "other"
    priority: str = "low"
    scripts: List[ScriptResult] = field(default_factory=list)


@dataclass
class HostFinding:
    target: str
    ip: Optional[str] = None
    hostname: Optional[str] = None
    status: Optional[str] = None
    ports: List[PortFinding] = field(default_factory=list)
    hypotheses: List[str] = field(default_factory=list)


@dataclass
class ScanArtifact:
    phase1_xml: str
    phase2_xml: Optional[str] = None
    open_ports: List[int] = field(default_factory=list)


@dataclass
class FinalResult:
    host: HostFinding
    artifacts: ScanArtifact
    summary: Dict[str, int] = field(default_factory=dict)

