import logging

from mangscan.config import LOG_DIR, OUTPUT_DIR, PHASE1_ARGS, PHASE2_ARGS
from mangscan.core.models import FinalResult, ScanArtifact
from mangscan.logging_config import attach_run_logfile
from mangscan.services.classifier import FindingClassifier
from mangscan.services.parser import NmapXmlParser
from mangscan.services.reporter import Reporter
from mangscan.services.scanner import NmapScanner
from mangscan.utils.filesystem import ensure_dir, ports_to_csv, timestamp


logger = logging.getLogger(__name__)


class MangScanOrchestrator:
    def __init__(self) -> None:
        self.scanner = NmapScanner()
        self.parser = NmapXmlParser()
        self.classifier = FindingClassifier()
        self.reporter = Reporter()

    def run(self, target: str) -> FinalResult:
        ensure_dir(OUTPUT_DIR)
        run_id = timestamp()

        safe_target = target.replace("/", "_")
        log_file = attach_run_logfile(LOG_DIR, f"{run_id}_{safe_target}.log")
        logger.info("Run initialized | run_id=%s | target=%s | logfile=%s", run_id, target, log_file)
        phase1_xml = OUTPUT_DIR / f"{run_id}_{safe_target}_phase1.xml"
        phase2_xml = OUTPUT_DIR / f"{run_id}_{safe_target}_phase2.xml"

        logger.info("Phase 1 started | target=%s | arguments=%s", target, PHASE1_ARGS)
        self.scanner.scan(target=target, arguments=PHASE1_ARGS, xml_output=phase1_xml)
        logger.info("Phase 1 finished | xml=%s", phase1_xml)
        phase1_host = self.parser.parse_host(phase1_xml, target)
        open_ports = sorted({p.port for p in phase1_host.ports if p.state == "open"})
        logger.info("Phase 1 parsed | target=%s | open_ports=%s", target, open_ports)

        artifact = ScanArtifact(
            phase1_xml=str(phase1_xml),
            open_ports=open_ports,
        )

        report_json = OUTPUT_DIR / f"{run_id}_{safe_target}_report.json"
        report_md = OUTPUT_DIR / f"{run_id}_{safe_target}_report.md"

        if not open_ports:
            logger.warning("No open ports found in phase 1 | target=%s", target)
            classified_host = self.classifier.enrich_host(phase1_host)
            summary = self.classifier.summarize(classified_host)
            result = FinalResult(host=classified_host, artifacts=artifact, summary=summary)

            self.reporter.write_json(result, report_json)
            self.reporter.write_markdown(result, report_md)
            logger.info("Reports generated | json=%s | markdown=%s", report_json, report_md)
            return result

        ports_csv = ports_to_csv(open_ports)
        phase2_args = f"{PHASE2_ARGS} -p {ports_csv}"
        logger.info("Phase 2 started | target=%s | arguments=%s", target, phase2_args)
        self.scanner.scan(target=target, arguments=phase2_args, xml_output=phase2_xml)
        logger.info("Phase 2 finished | xml=%s", phase2_xml)

        artifact.phase2_xml = str(phase2_xml)

        phase2_host = self.parser.parse_host(phase2_xml, target)
        logger.info("Phase 2 parsed | target=%s | services=%s", target, len(phase2_host.ports))
        classified_host = self.classifier.enrich_host(phase2_host)
        summary = self.classifier.summarize(classified_host)
        logger.info("Classification finished | summary=%s", summary)

        result = FinalResult(host=classified_host, artifacts=artifact, summary=summary)

        self.reporter.write_json(result, report_json)
        self.reporter.write_markdown(result, report_md)
        logger.info("Reports generated | json=%s | markdown=%s", report_json, report_md)

        return result
