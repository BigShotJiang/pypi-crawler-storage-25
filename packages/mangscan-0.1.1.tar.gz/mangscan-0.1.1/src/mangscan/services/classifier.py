import logging
from collections import Counter

from mangscan.config import CATEGORY_MAP, SERVICE_HINTS
from mangscan.core.models import HostFinding, PortFinding


logger = logging.getLogger(__name__)


class FindingClassifier:
    def classify_port(self, finding: PortFinding) -> PortFinding:
        category = "other"

        for cat, ports in CATEGORY_MAP.items():
            if finding.port in ports:
                category = cat
                break

        if category == "other" and finding.service:
            service_name = finding.service.lower()
            for hint, hinted_category in SERVICE_HINTS.items():
                if hint in service_name:
                    category = hinted_category
                    break

        finding.category = category
        finding.priority = self._define_priority(finding)
        return finding

    def _define_priority(self, finding: PortFinding) -> str:
        if finding.category in {"remote_access", "database"}:
            return "high"
        if finding.category in {"web", "network_sharing"}:
            return "medium"
        return "low"

    def enrich_host(self, host: HostFinding) -> HostFinding:
        host.ports = [self.classify_port(p) for p in host.ports if p.state == "open"]
        host.hypotheses = self._build_hypotheses(host)
        logger.debug(
            "Host enriched | target=%s | open_ports=%s | hypotheses=%s",
            host.target,
            len(host.ports),
            len(host.hypotheses),
        )
        return host

    def summarize(self, host: HostFinding) -> dict:
        categories = Counter(p.category for p in host.ports)
        priorities = Counter(p.priority for p in host.ports)

        summary = {
            "total_open_ports": len(host.ports),
            "web": categories.get("web", 0),
            "remote_access": categories.get("remote_access", 0),
            "database": categories.get("database", 0),
            "network_sharing": categories.get("network_sharing", 0),
            "other": categories.get("other", 0),
            "high_priority": priorities.get("high", 0),
            "medium_priority": priorities.get("medium", 0),
            "low_priority": priorities.get("low", 0),
        }
        logger.debug("Summary generated | target=%s | summary=%s", host.target, summary)
        return summary

    def _build_hypotheses(self, host: HostFinding) -> list[str]:
        services = {p.service.lower() for p in host.ports if p.service}

        hypotheses = []

        if any(s in services for s in {"http", "https", "ssl/http"}):
            hypotheses.append("The host appears to expose at least one web service.")
        if "ssh" in services or "telnet" in services or "ms-wbt-server" in services:
            hypotheses.append("The host appears to allow remote administration.")
        if any(s in services for s in {"mysql", "postgresql", "mongodb", "redis", "ms-sql-s"}):
            hypotheses.append("The host appears to provide a database service.")
        if any(p.port in {139, 445, 2049} for p in host.ports):
            hypotheses.append("The host appears to provide file or network sharing mechanisms.")

        if not hypotheses:
            hypotheses.append(
                "The host profile could not be inferred with high confidence based only on the current enumeration."
            )

        return hypotheses
