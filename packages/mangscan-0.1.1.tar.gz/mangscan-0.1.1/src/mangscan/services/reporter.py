import json
import logging
from pathlib import Path

from mangscan.core.models import FinalResult


logger = logging.getLogger(__name__)


class Reporter:
    def write_json(self, result: FinalResult, output_file: Path) -> None:
        payload = {
            "host": {
                "target": result.host.target,
                "ip": result.host.ip,
                "hostname": result.host.hostname,
                "status": result.host.status,
                "hypotheses": result.host.hypotheses,
                "ports": [
                    {
                        "port": p.port,
                        "protocol": p.protocol,
                        "state": p.state,
                        "service": p.service,
                        "product": p.product,
                        "version": p.version,
                        "extrainfo": p.extrainfo,
                        "category": p.category,
                        "priority": p.priority,
                        "scripts": [
                            {"id": s.script_id, "output": s.output}
                            for s in p.scripts
                        ],
                    }
                    for p in result.host.ports
                ],
            },
            "artifacts": {
                "phase1_xml": result.artifacts.phase1_xml,
                "phase2_xml": result.artifacts.phase2_xml,
                "open_ports": result.artifacts.open_ports,
            },
            "summary": result.summary,
        }

        output_file.write_text(
            json.dumps(payload, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        logger.debug("JSON report written | file=%s", output_file)

    def write_markdown(self, result: FinalResult, output_file: Path) -> None:
        host = result.host
        lines = []

        lines.append(f"# Technical Report - {host.target}\n")
        lines.append("## Executive Summary\n")
        lines.append(
            f"The analyzed host exposed **{result.summary['total_open_ports']} open TCP port(s)** "
            f"during the collection performed in a controlled environment. "
            f"Identified services were classified into web, remote access, database, "
            f"network sharing, and other categories.\n"
        )

        lines.append("### Overview\n")
        lines.append(f"- Identified IP: `{host.ip or 'not identified'}`")
        lines.append(f"- Identified hostname: `{host.hostname or 'not identified'}`")
        lines.append(f"- Host status: `{host.status or 'unknown'}`")
        lines.append(
            f"- Open ports: `{', '.join(str(p) for p in result.artifacts.open_ports) or 'none'}`\n"
        )

        lines.append("## Ports and Services Table\n")
        lines.append("| Port | Proto | Service | Product | Version | Category | Priority |")
        lines.append("|-----:|:-----:|:--------|:--------|:--------|:---------|:---------|")

        for p in host.ports:
            lines.append(
                f"| {p.port} | {p.protocol} | {p.service or '-'} | {p.product or '-'} | "
                f"{p.version or '-'} | {p.category} | {p.priority} |"
            )

        lines.append("\n## Host Profile Hypotheses\n")
        for h in host.hypotheses:
            lines.append(f"- {h}")

        lines.append("\n## Basic Script Output\n")
        for p in host.ports:
            if p.scripts:
                lines.append(
                    f"\n### Port {p.port}/{p.protocol} - {p.service or 'unidentified service'}"
                )
                for s in p.scripts:
                    lines.append(f"- **{s.script_id}**: {s.output or 'no relevant output'}")

        lines.append("\n## Method Limitations\n")
        lines.append("- The analysis depends on network visibility at the time of collection.")
        lines.append("- Version detection and default scripts may not identify all service details.")
        lines.append("- The report reflects only the point-in-time snapshot of the scan.")
        lines.append(
            "- The severity classification is academic and based on simple rules, not validated real-world risk.\n"
        )

        lines.append("## Future Improvements\n")
        lines.append("- Support for multiple hosts and lab subnets.")
        lines.append("- Comparative execution history.")
        lines.append("- Local web dashboard for visualization.")
        lines.append("- More advanced rules engine for service correlation.")
        lines.append("- Additional CSV or HTML export.\n")

        lines.append("## Ethical Note\n")
        lines.append(
            "This tool was designed exclusively for academic, defensive, and authorized use "
            "in a private, isolated, controlled environment under the researcher's responsibility."
        )

        output_file.write_text("\n".join(lines), encoding="utf-8")
        logger.debug("Markdown report written | file=%s", output_file)
