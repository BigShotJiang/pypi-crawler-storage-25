import logging
from pathlib import Path
from xml.etree import ElementTree as ET

from mangscan.core.models import HostFinding, PortFinding, ScriptResult


logger = logging.getLogger(__name__)


class NmapXmlParser:
    def parse_host(self, xml_file: Path, target: str) -> HostFinding:
        logger.debug("Parsing Nmap XML | target=%s | file=%s", target, xml_file)
        tree = ET.parse(xml_file)
        root = tree.getroot()

        host_elem = root.find("host")
        if host_elem is None:
            logger.warning("No host element found in XML | target=%s | file=%s", target, xml_file)
            return HostFinding(target=target, status="unknown")

        status_elem = host_elem.find("status")
        status = status_elem.attrib.get("state") if status_elem is not None else None

        ip = None
        hostname = None

        for addr in host_elem.findall("address"):
            if addr.attrib.get("addrtype") == "ipv4":
                ip = addr.attrib.get("addr")

        hostnames = host_elem.find("hostnames")
        if hostnames is not None:
            hostname_elem = hostnames.find("hostname")
            if hostname_elem is not None:
                hostname = hostname_elem.attrib.get("name")

        result = HostFinding(
            target=target,
            ip=ip,
            hostname=hostname,
            status=status,
        )

        ports_elem = host_elem.find("ports")
        if ports_elem is None:
            return result

        for port_elem in ports_elem.findall("port"):
            state_elem = port_elem.find("state")
            service_elem = port_elem.find("service")

            port_number = int(port_elem.attrib.get("portid", "0"))
            protocol = port_elem.attrib.get("protocol", "tcp")
            state = state_elem.attrib.get("state") if state_elem is not None else "unknown"

            finding = PortFinding(
                port=port_number,
                protocol=protocol,
                state=state,
                service=service_elem.attrib.get("name") if service_elem is not None else None,
                product=service_elem.attrib.get("product") if service_elem is not None else None,
                version=service_elem.attrib.get("version") if service_elem is not None else None,
                extrainfo=service_elem.attrib.get("extrainfo") if service_elem is not None else None,
            )

            for script_elem in port_elem.findall("script"):
                finding.scripts.append(
                    ScriptResult(
                        script_id=script_elem.attrib.get("id", "unknown"),
                        output=script_elem.attrib.get("output", "").strip(),
                    )
                )

            result.ports.append(finding)

        logger.debug("XML parsing complete | target=%s | ports=%s", target, len(result.ports))
        return result
