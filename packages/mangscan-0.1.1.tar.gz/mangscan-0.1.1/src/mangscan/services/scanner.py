import logging
from pathlib import Path

import nmap


logger = logging.getLogger(__name__)


class NmapExecutionError(Exception):
    pass


class NmapScanner:
    def __init__(self) -> None:
        try:
            self.scanner = nmap.PortScanner()
            logger.debug("python-nmap initialized successfully")
        except Exception as exc:
            raise NmapExecutionError(
                "Failed to initialize python-nmap. Verify that Nmap is installed on the system."
            ) from exc

    def nmap_version(self) -> str:
        try:
            version = self.scanner.nmap_version()
            return ".".join(str(v) for v in version)
        except Exception:
            return "unknown"

    def scan(self, target: str, arguments: str, xml_output: Path) -> None:
        try:
            logger.debug("Executing nmap scan | target=%s | arguments=%s", target, arguments)
            self.scanner.scan(hosts=target, arguments=arguments)
            xml_output.parent.mkdir(parents=True, exist_ok=True)
            xml_output.write_text(self.scanner.get_nmap_last_output(), encoding="utf-8")
            logger.debug("Nmap XML output persisted | file=%s", xml_output)
        except Exception as exc:
            logger.exception("Nmap execution failed | target=%s | arguments=%s", target, arguments)
            raise NmapExecutionError(
                f"Failed to run Nmap for target {target} with arguments: {arguments}"
            ) from exc
