"""Service layer for scanning, parsing, classification, and reporting."""

