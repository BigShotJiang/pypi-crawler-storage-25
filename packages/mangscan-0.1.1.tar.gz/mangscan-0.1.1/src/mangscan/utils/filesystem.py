from datetime import datetime
from pathlib import Path


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def ports_to_csv(ports: list[int]) -> str:
    return ",".join(str(p) for p in sorted(set(ports)))

