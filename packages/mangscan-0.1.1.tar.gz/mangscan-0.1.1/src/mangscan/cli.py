import argparse
import logging
import sys

from mangscan.logging_config import DEFAULT_LOG_LEVEL, configure_logging
from mangscan.core.orchestrator import MangScanOrchestrator


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="MangScan - Smart port scan orchestrator"
    )
    parser.add_argument(
        "target",
        help="IP or hostname of the authorized target in a controlled lab",
    )
    parser.add_argument(
        "--log-level",
        default=DEFAULT_LOG_LEVEL,
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Console log level for runtime visibility (default: INFO).",
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()
    configure_logging(args.log_level)
    logger = logging.getLogger(__name__)

    try:
        logger.info("Starting MangScan for target %s", args.target)
        orchestrator = MangScanOrchestrator()
        result = orchestrator.run(args.target)
    except Exception:
        logger.exception("MangScan execution failed for target %s", args.target)
        raise SystemExit(1)

    print("\n[+] Execution finished")
    print(f"[+] Target: {result.host.target}")
    print(f"[+] IP: {result.host.ip}")
    print(f"[+] Open ports: {result.artifacts.open_ports}")
    print(f"[+] Total open ports: {result.summary.get('total_open_ports', 0)}")
    sys.exit(0)
