import logging
from pathlib import Path


DEFAULT_LOG_LEVEL = "INFO"
LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
RUN_FILE_HANDLER_NAME = "mangscan_run_file"


def configure_logging(level_name: str = DEFAULT_LOG_LEVEL) -> None:
    level = _resolve_level(level_name)
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)

    console_handler = _find_console_handler(root_logger)
    if console_handler is None:
        console_handler = logging.StreamHandler()
        console_handler.set_name("mangscan_console")
        console_handler.setFormatter(logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT))
        root_logger.addHandler(console_handler)

    console_handler.setLevel(level)


def attach_run_logfile(log_dir: Path, filename: str) -> Path:
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / filename

    root_logger = logging.getLogger()
    existing_handler = _find_handler_by_name(root_logger, RUN_FILE_HANDLER_NAME)
    if existing_handler is not None:
        root_logger.removeHandler(existing_handler)
        existing_handler.close()

    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.set_name(RUN_FILE_HANDLER_NAME)
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT))
    root_logger.addHandler(file_handler)
    return log_file


def _resolve_level(level_name: str) -> int:
    level = getattr(logging, level_name.upper(), None)
    if isinstance(level, int):
        return level
    return logging.INFO


def _find_console_handler(root_logger: logging.Logger) -> logging.Handler | None:
    for handler in root_logger.handlers:
        if isinstance(handler, logging.StreamHandler) and getattr(handler, "name", "") == "mangscan_console":
            return handler
    return None


def _find_handler_by_name(root_logger: logging.Logger, name: str) -> logging.Handler | None:
    for handler in root_logger.handlers:
        if getattr(handler, "name", "") == name:
            return handler
    return None

