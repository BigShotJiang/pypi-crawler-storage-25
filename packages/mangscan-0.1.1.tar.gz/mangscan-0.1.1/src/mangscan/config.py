import os
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = PACKAGE_DIR.parent.parent
OUTPUT_DIR = Path(os.environ.get("MANGSCAN_OUTPUT_DIR", Path.cwd() / "output")).resolve()
LOG_DIR = OUTPUT_DIR / "logs"

PHASE1_ARGS = "-Pn -p- --open -T3"

PHASE2_ARGS = "-Pn -sV -sC -T3"

CATEGORY_MAP = {
    "web": {80, 81, 443, 444, 591, 593, 8000, 8008, 8080, 8081, 8088, 8443, 8888},
    "remote_access": {22, 23, 3389, 5900, 5901, 5902},
    "database": {1433, 1521, 3306, 5432, 6379, 27017, 27018, 27019},
    "network_sharing": {21, 69, 111, 137, 138, 139, 445, 2049},
}

SERVICE_HINTS = {
    "http": "web",
    "https": "web",
    "ssl/http": "web",
    "nginx": "web",
    "apache": "web",
    "iis": "web",
    "tomcat": "web",
    "jetty": "web",
    "lighttpd": "web",
    "caddy": "web",
    "traefik": "web",
    "http-proxy": "web",
    "squid-http": "web",
    "ssh": "remote_access",
    "openssh": "remote_access",
    "dropbear": "remote_access",
    "telnet": "remote_access",
    "ms-wbt-server": "remote_access",
    "rdp": "remote_access",
    "vnc": "remote_access",
    "rfb": "remote_access",
    "winrm": "remote_access",
    "mysql": "database",
    "mariadb": "database",
    "postgresql": "database",
    "postgreSQL": "database",
    "mssql": "database",
    "ms-sql-s": "database",
    "oracle": "database",
    "oracle-tns": "database",
    "redis": "database",
    "mongodb": "database",
    "mongodb-shard": "database",
    "mongod": "database",
    "cassandra": "database",
    "elasticsearch": "database",
    "ftp": "network_sharing",
    "ftp-data": "network_sharing",
    "tftp": "network_sharing",
    "smb": "network_sharing",
    "microsoft-ds": "network_sharing",
    "netbios-ssn": "network_sharing",
    "netbios-ns": "network_sharing",
    "netbios-dgm": "network_sharing",
    "nfs": "network_sharing",
    "rpcbind": "network_sharing",
    "mountd": "network_sharing",
    "cifs": "network_sharing",
}
