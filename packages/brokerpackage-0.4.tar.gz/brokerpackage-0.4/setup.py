from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='brokerpackage',
    version='0.4',
    description='Package is a Python client library designed to interact with a broker API service. It provides functionalities to manage and execute trading strategies, handle orders, and retrieve market data.',
    author='Vadlamani Rampratap Sharma',
    author_email='rampratap.optalpha@gmail.com',
    packages=find_packages(),
    install_requires=[
        'openpyxl==3.1.2',
        'pandas==1.5.3',
        'numpy==1.23.5'
    ],
    long_description=long_description,
    long_description_content_type='text/markdown',
    license="MIT",
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.9.7',
    include_package_data=True
)