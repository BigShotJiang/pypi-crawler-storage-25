# TestAxiom Analysis: age

**Parameter type:** int  
**Techniques:** EP, BVA  
**Test cases:** 9  
**Efficiency:** 91% reduction (105 exhaustive → 9 optimized)  

## Test Cases

| ID | Technique | Input | Expected | Rationale |
|---|---|---|---|---|
| EP-age-001 | EP | `17` | ❌ invalid | Equivalence Partitioning: partition 'below_minimum' — one representative value t... |
| EP-age-002 | EP | `69` | ✅ valid | Equivalence Partitioning: partition 'valid_range' — one representative value tes... |
| EP-age-003 | EP | `121` | ❌ invalid | Equivalence Partitioning: partition 'above_maximum' — one representative value t... |
| BVA-age-001 | BVA | `17` | ❌ invalid | 3-value BVA: 17 is the invalid neighbor below the minimum boundary 18. Catches o... |
| BVA-age-002 | BVA | `18` | ✅ valid | 3-value BVA: 18 is the exact lower boundary value. Tests whether the boundary it... |
| BVA-age-003 | BVA | `19` | ✅ valid | 3-value BVA: 19 is the valid neighbor just inside the lower boundary. Verifies t... |
| BVA-age-004 | BVA | `119` | ✅ valid | 3-value BVA: 119 is the valid neighbor just inside the upper boundary. Verifies ... |
| BVA-age-005 | BVA | `120` | ✅ valid | 3-value BVA: 120 is the exact upper boundary value. Tests whether the boundary i... |
| BVA-age-006 | BVA | `121` | ❌ invalid | 3-value BVA: 121 is the invalid neighbor above the maximum boundary 120. Catches... |