"""
TestAxiom Licensing — Tier-based feature gating with offline license keys.

How it works:
    1. Admin generates a license key with tools/keygen.py (HMAC-SHA256 signed)
    2. User calls activate("TA-...") with their key
    3. TestAxiom verifies the signature offline (no server needed)
    4. If valid + not expired → tier is unlocked

    For development/testing: set_tier(Tier.PRO) still works as override.

Tiers:
    COMMUNITY (Free forever):
        EP, BVA, CLI, Python API, JSON/Markdown export, full traceability

    PRO ($19/mo):
        + Decision Table, Pairwise, State Transition, CSV export, AI parser

    ENTERPRISE (custom):
        + Jira/Xray, traceability matrix, SSO, audit log, on-premise
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
from datetime import datetime, timezone
from enum import Enum
from functools import wraps
from pathlib import Path
from typing import Callable


class Tier(str, Enum):
    """License tiers."""
    COMMUNITY = "community"
    PRO = "pro"
    ENTERPRISE = "enterprise"


class TierError(Exception):
    """Raised when a feature is accessed without the required tier."""
    pass


class LicenseError(Exception):
    """Raised when a license key is invalid or expired."""
    pass


# ─── License State ───

_current_tier: Tier = Tier.COMMUNITY
_license_info: dict | None = None

# Path where activated license is persisted
_LICENSE_FILE = Path.home() / ".testaxiom" / "license.key"


def get_tier() -> Tier:
    """Get current license tier."""
    return _current_tier


def get_license_info() -> dict | None:
    """Get current license details (email, tier, expires, org)."""
    return _license_info


def set_tier(tier: Tier | str) -> None:
    """
    Manually set license tier (for development/testing).

    In production, use activate() with a license key instead.
    """
    global _current_tier
    if isinstance(tier, str):
        tier = Tier(tier)
    _current_tier = tier


# ─── License Key Verification ───

def activate(license_key: str, secret: bytes | None = None) -> dict:
    """
    Activate a license key.

    Verifies the HMAC signature, checks expiry, and unlocks the tier.
    The key is saved to ~/.testaxiom/license.key for future sessions.

    Args:
        license_key: Key in format "TA-BASE64(payload).BASE64(signature)"
        secret: Secret key bytes (for testing). In production, uses
                the embedded verification.

    Returns:
        License info dict {email, tier, org, issued, expires}

    Raises:
        LicenseError: If the key is invalid, tampered, or expired.

    Usage:
        from testaxiom import activate
        activate("TA-eyJlbWFpb...")
    """
    global _current_tier, _license_info

    info = verify_key(license_key, secret=secret)

    # Check expiry
    expires = datetime.strptime(info["expires"], "%Y-%m-%d").replace(tzinfo=timezone.utc)
    now = datetime.now(timezone.utc)
    if now > expires:
        days_ago = (now - expires).days
        raise LicenseError(
            f"License expired {days_ago} days ago (expired: {info['expires']}). "
            f"Renew at https://testaxiom.dev/pricing"
        )

    # Activate
    _current_tier = Tier(info["tier"])
    _license_info = info

    # Persist for future sessions
    _save_license(license_key)

    return info


def verify_key(license_key: str, secret: bytes | None = None) -> dict:
    """
    Verify a license key's signature without activating it.

    Args:
        license_key: The full license key string.
        secret: HMAC secret (required — injected by keygen or tests).

    Returns:
        Decoded payload dict.

    Raises:
        LicenseError: If format is wrong or signature doesn't match.
    """
    if secret is None:
        raise LicenseError(
            "License verification requires a secret key. "
            "This is configured during deployment."
        )

    # Parse format: TA-{payload_b64}.{sig_b64}
    if not license_key.startswith("TA-"):
        raise LicenseError("Invalid license key format. Key must start with 'TA-'.")

    body = license_key[3:]  # strip "TA-"
    parts = body.split(".")
    if len(parts) != 2:
        raise LicenseError("Invalid license key format. Expected 'TA-{payload}.{signature}'.")

    payload_b64, sig_b64 = parts

    # Decode payload
    try:
        payload_bytes = base64.urlsafe_b64decode(payload_b64)
        payload = json.loads(payload_bytes)
    except Exception:
        raise LicenseError("Invalid license key: payload could not be decoded.")

    # Verify signature
    try:
        expected_sig = base64.urlsafe_b64decode(sig_b64)
    except Exception:
        raise LicenseError("Invalid license key: signature could not be decoded.")

    actual_sig = hmac.new(secret, payload_bytes, hashlib.sha256).digest()

    if not hmac.compare_digest(actual_sig, expected_sig):
        raise LicenseError(
            "Invalid license key: signature verification failed. "
            "This key may have been tampered with."
        )

    # Validate required fields
    required = {"email", "tier", "expires"}
    if not required.issubset(payload.keys()):
        missing = required - payload.keys()
        raise LicenseError(f"Invalid license key: missing fields {missing}")

    if payload["tier"] not in ("pro", "enterprise"):
        raise LicenseError(f"Invalid license tier: {payload['tier']}")

    return payload


def deactivate() -> None:
    """Deactivate current license and revert to Community tier."""
    global _current_tier, _license_info
    _current_tier = Tier.COMMUNITY
    _license_info = None
    if _LICENSE_FILE.exists():
        _LICENSE_FILE.unlink()


def _save_license(key: str) -> None:
    """Save license key to disk for auto-loading in future sessions."""
    _LICENSE_FILE.parent.mkdir(parents=True, exist_ok=True)
    _LICENSE_FILE.write_text(key)


def _load_saved_license(secret: bytes | None = None) -> bool:
    """Try to load and activate a previously saved license. Returns True if successful."""
    if not _LICENSE_FILE.exists():
        return False
    try:
        key = _LICENSE_FILE.read_text().strip()
        activate(key, secret=secret)
        return True
    except (LicenseError, Exception):
        return False


# ─── Feature Gating ───

def requires_tier(minimum_tier: Tier) -> Callable:
    """
    Decorator that gates a function behind a minimum tier.

    Usage:
        @requires_tier(Tier.PRO)
        def generate_pairwise(...):
            ...

    When called without the required tier:
        TierError: 'generate' requires PRO tier.
        Current tier: COMMUNITY.
        Upgrade at https://testaxiom.dev/pricing
    """
    tier_order = {Tier.COMMUNITY: 0, Tier.PRO: 1, Tier.ENTERPRISE: 2}

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            current = get_tier()
            if tier_order[current] < tier_order[minimum_tier]:
                raise TierError(
                    f"'{func.__name__}' requires {minimum_tier.value.upper()} tier. "
                    f"Current tier: {current.value.upper()}. "
                    f"Upgrade at https://testaxiom.dev/pricing"
                )
            return func(*args, **kwargs)
        wrapper._minimum_tier = minimum_tier
        return wrapper
    return decorator


# ─── Feature Map ───

FEATURE_MAP = {
    "ep_engine": Tier.COMMUNITY,
    "bva_engine": Tier.COMMUNITY,
    "cli": Tier.COMMUNITY,
    "python_api": Tier.COMMUNITY,
    "json_export": Tier.COMMUNITY,
    "text_export": Tier.COMMUNITY,
    "traceability": Tier.COMMUNITY,
    "decision_table_engine": Tier.PRO,
    "pairwise_engine": Tier.PRO,
    "state_transition_engine": Tier.PRO,
    "multi_param_batch": Tier.PRO,
    "csv_export": Tier.PRO,
    "excel_export": Tier.PRO,
    "ai_parser": Tier.PRO,
    "jira_integration": Tier.ENTERPRISE,
    "traceability_matrix_export": Tier.ENTERPRISE,
    "team_management": Tier.ENTERPRISE,
    "sso_saml": Tier.ENTERPRISE,
    "audit_log": Tier.ENTERPRISE,
    "on_premise": Tier.ENTERPRISE,
}


def list_features(tier: Tier | None = None) -> dict[str, str]:
    """
    List features and their required tiers.

    Args:
        tier: If specified, only show features available at this tier.

    Returns:
        Dict of feature_name → required_tier
    """
    tier_order = {Tier.COMMUNITY: 0, Tier.PRO: 1, Tier.ENTERPRISE: 2}

    if tier is None:
        return {k: v.value for k, v in FEATURE_MAP.items()}

    level = tier_order[tier]
    return {
        k: v.value for k, v in FEATURE_MAP.items()
        if tier_order[v] <= level
    }
