"""Parsers — NLP and structured input parsing (AI layer)."""
