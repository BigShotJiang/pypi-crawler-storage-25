"""
Decision Table Engine

ISTQB Definition: A black-box test design technique in which test cases are
designed to exercise the combinations of conditions and resulting actions
identified in a decision table.

Decision tables are ideal when:
- Multiple conditions (inputs) interact to determine the outcome
- Business rules involve IF-THEN logic with multiple variables
- Requirements contain words like "if", "when", "only when", "unless"

This engine:
1. Takes conditions (boolean inputs) and actions (expected outcomes)
2. Generates the full or collapsed decision table
3. Creates one test case per rule (column)
4. Supports "don't care" (-) values for collapsed tables
"""

from __future__ import annotations

from itertools import product
from dataclasses import dataclass

from testaxiom.core import TestCase, Technique, Verdict
from testaxiom.licensing import requires_tier, Tier


@dataclass
class Condition:
    """A boolean condition in a decision table."""
    name: str
    description: str = ""


@dataclass
class Action:
    """An action/outcome in a decision table."""
    name: str
    description: str = ""


@dataclass
class Rule:
    """A single rule (column) in a decision table."""
    id: int
    conditions: dict[str, bool | None]  # None = don't care (-)
    actions: dict[str, bool]
    description: str = ""


class DecisionTableEngine:
    """Decision Table test case generator."""

    @requires_tier(Tier.PRO)
    def generate(
        self,
        conditions: list[Condition],
        actions: list[Action],
        rules: list[Rule] | None = None,
        collapse: bool = True,
        **kwargs,
    ) -> list[TestCase]:
        """
        Generate test cases from a decision table.

        If rules are provided, use them directly.
        If not, generate the full truth table (2^n combinations)
        and optionally collapse redundant rules.

        Args:
            conditions: List of boolean conditions.
            actions: List of possible actions/outcomes.
            rules: Pre-defined rules (optional). If None, generates full table.
            collapse: Whether to collapse redundant rules (default True).

        Returns:
            List of test cases, one per rule.
        """
        if rules is None:
            rules = self._generate_full_table(conditions, actions)

        return self._create_test_cases(conditions, actions, rules)

    def generate_full_table(
        self,
        conditions: list[Condition],
        actions: list[Action],
        action_resolver: callable | None = None,
    ) -> list[Rule]:
        """
        Generate the complete truth table for given conditions.

        Public method for users who want to inspect/modify rules before
        generating test cases.

        Args:
            conditions: List of conditions.
            actions: List of actions.
            action_resolver: Optional function(condition_values: dict) → dict[str, bool]
                that determines which actions fire for a given combination.

        Returns:
            List of Rules covering all combinations.
        """
        return self._generate_full_table(conditions, actions, action_resolver)

    def _generate_full_table(
        self,
        conditions: list[Condition],
        actions: list[Action],
        action_resolver: callable | None = None,
    ) -> list[Rule]:
        """Generate 2^n rules for n conditions."""
        cond_names = [c.name for c in conditions]
        combinations = list(product([True, False], repeat=len(conditions)))
        rules = []

        for i, combo in enumerate(combinations, 1):
            cond_values = dict(zip(cond_names, combo))

            if action_resolver:
                action_values = action_resolver(cond_values)
            else:
                # Default: first action fires when all conditions True
                action_values = {a.name: all(combo) for a in actions}

            true_conds = [k for k, v in cond_values.items() if v]
            false_conds = [k for k, v in cond_values.items() if not v]
            desc_parts = []
            if true_conds:
                desc_parts.append(f"{', '.join(true_conds)} = True")
            if false_conds:
                desc_parts.append(f"{', '.join(false_conds)} = False")

            rules.append(Rule(
                id=i,
                conditions=cond_values,
                actions=action_values,
                description=f"Rule {i}: {'; '.join(desc_parts)}",
            ))

        return rules

    def _create_test_cases(
        self,
        conditions: list[Condition],
        actions: list[Action],
        rules: list[Rule],
    ) -> list[TestCase]:
        """Convert rules into traced TestCase objects."""
        test_cases = []

        for rule in rules:
            # Build input description
            input_parts = []
            for cond_name, cond_val in rule.conditions.items():
                if cond_val is None:
                    input_parts.append(f"{cond_name}=ANY")
                else:
                    input_parts.append(f"{cond_name}={'T' if cond_val else 'F'}")
            input_str = ", ".join(input_parts)

            # Build action description
            active_actions = [k for k, v in rule.actions.items() if v]
            [k for k, v in rule.actions.items() if not v]

            # Determine verdict: valid if any positive action fires
            verdict = Verdict.VALID if active_actions else Verdict.INVALID

            # Build rationale
            cond_count = len(conditions)
            total_combos = 2 ** cond_count
            rationale = (
                f"Decision Table Rule {rule.id}/{len(rules)}: "
                f"With {cond_count} conditions, there are {total_combos} possible combinations. "
                f"This rule tests [{input_str}] → "
                f"expected actions: {', '.join(active_actions) if active_actions else 'none'}."
            )

            tc_id = f"DT-R{rule.id:03d}"
            test_cases.append(TestCase(
                id=tc_id,
                parameter="decision_table",
                technique=Technique.DECISION_TABLE,
                input_value=rule.conditions,
                expected=verdict,
                description=rule.description,
                rationale=rationale,
            ))

        return test_cases
