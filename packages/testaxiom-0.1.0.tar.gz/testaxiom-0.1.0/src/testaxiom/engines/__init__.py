"""Test design technique engines — deterministic, mathematically grounded."""
