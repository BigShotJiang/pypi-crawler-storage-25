# TestAxiom

**From requirements to mathematically optimal test cases — with AI intelligence and ISTQB methodology.**

TestAxiom is an AI-Powered Test Design Engine that combines Large Language Model intelligence with deterministic, mathematically-grounded test design techniques.

## Why TestAxiom?

Most AI test generators just throw requirements at an LLM and say "generate tests." The result: bloated, unexplainable, untraceable test suites. Mathematical tools like PICT are precise but require manual parameter extraction.

**TestAxiom bridges the gap.** Every test case comes with:
- The **technique** that generated it (EP, BVA, Decision Table, Pairwise)
- The **mathematical rationale** explaining WHY this specific value was chosen
- Full **traceability** from requirement → technique → test case

## Quick Start

```bash
pip install testaxiom
```

### Python API

```python
from testaxiom import analyze

result = analyze("age", param_type="int", valid_range=(18, 65))
print(result.summary())
```

### CLI

```bash
testaxiom --param age --type int --range 18 65
testaxiom --param age --type int --range 18 65 --bva-mode 3-value --json
```

## Supported Techniques

| Technique | Status | Description |
|-----------|--------|-------------|
| Equivalence Partitioning (EP) | ✅ Ready | Divides input into partitions with equivalent behavior |
| Boundary Value Analysis (BVA) | ✅ Ready | Tests at partition boundaries (2-value & 3-value) |
| Decision Table | 🔜 Next | Covers combinations of business rules |
| State Transition | 🔜 Planned | Tests state machine transitions |
| Pairwise (All-Pairs) | 🔜 Planned | Minimizes combinatorial test sets |

## Architecture

```
testaxiom/
├── core.py          # Data models (ParameterSpec, TestCase, AnalysisResult)
├── engines/         # Deterministic technique engines (no AI dependency)
│   ├── equivalence_partitioning.py
│   ├── boundary_value.py
│   └── (decision_table.py, pairwise.py — coming soon)
├── parsers/         # AI layer for NLP requirement parsing (optional)
└── cli.py           # Command-line interface
```

## License

MIT

## Author

**Yaniv (Yaniv2809)** — AI-Powered QA Engineer
