"""
╔══════════════════════════════════════════════════════════════════╗
║  TestAxiom — Real-World Usage Example                          ║
║  Scenario: QA Engineer testing a User Registration Form        ║
║                                                                ║
║  You just installed testaxiom:                                 ║
║    pip install testaxiom                                       ║
║                                                                ║
║  Your PM sent you this requirement:                            ║
║    "Build a registration form with username (6-20 chars),      ║
║     age (18-120), email, password (8-64 chars), and a          ║
║     country selector (IL, US, UK, DE, FR)."                    ║
║                                                                ║
║  Let's generate all the test cases you need.                   ║
╚══════════════════════════════════════════════════════════════════╝
"""

# ─────────────────────────────────────────────────────
# Step 1: Install and import
# ─────────────────────────────────────────────────────
# In your terminal:  pip install testaxiom
# Then in your Python file:

from testaxiom import analyze, ParameterSpec

# ─────────────────────────────────────────────────────
# Step 2: Analyze each parameter from the requirement
# ─────────────────────────────────────────────────────

print("=" * 65)
print("  TESTAXIOM — Registration Form Test Design")
print("  Requirement: REQ-REG-001")
print("=" * 65)

# --- Parameter 1: Username (string, 6-20 characters) ---
print("\n📋 Parameter 1: username")
print("-" * 40)

username_result = analyze(
    parameter="username",
    param_type="str",
    valid_range=(6, 20),       # min_length=6, max_length=20
)

for tc in username_result.test_cases:
    icon = "✅" if tc.expected.value == "valid" else "❌"
    print(f"  {icon} {tc.id}: input={repr(tc.input_value)}")
    print(f"     → Expected: {tc.expected.value}")
    print(f"     → Why: {tc.rationale[:80]}...")
    print()


# --- Parameter 2: Age (integer, 18-120) ---
print("\n📋 Parameter 2: age")
print("-" * 40)

age_result = analyze(
    parameter="age",
    param_type="int",
    valid_range=(18, 120),
    bva_mode="3-value",       # high-risk field → 3-value BVA
)

print(f"  Techniques: {', '.join(t.value.upper() for t in age_result.techniques_applied)}")
print(f"  Test cases: {age_result.total_generated}")
print(f"  Efficiency: {age_result.efficiency_ratio}")
print()

for tc in age_result.test_cases:
    icon = "✅" if tc.expected.value == "valid" else "❌"
    technique = tc.technique.value.upper()
    print(f"  {icon} [{technique}] {tc.id}: age={tc.input_value} → {tc.expected.value}")


# --- Parameter 3: Country (enum) ---
print("\n\n📋 Parameter 3: country")
print("-" * 40)

country_result = analyze(
    parameter="country",
    param_type="enum",
    valid_values=["IL", "US", "UK", "DE", "FR"],
)

for tc in country_result.test_cases:
    icon = "✅" if tc.expected.value == "valid" else "❌"
    print(f"  {icon} {tc.id}: country={repr(tc.input_value)} → {tc.expected.value}")


# --- Parameter 4: Password length (integer, 8-64) ---
print("\n\n📋 Parameter 4: password length")
print("-" * 40)

password_result = analyze(
    parameter="password_length",
    param_type="int",
    valid_range=(8, 64),
    bva_mode="2-value",
)

for tc in password_result.test_cases:
    icon = "✅" if tc.expected.value == "valid" else "❌"
    technique = tc.technique.value.upper()
    print(f"  {icon} [{technique}] {tc.id}: length={tc.input_value} → {tc.expected.value}")


# ─────────────────────────────────────────────────────
# Step 3: Look at the full summary for one parameter
# ─────────────────────────────────────────────────────

print("\n\n" + "=" * 65)
print("  DEEP DIVE: Age parameter — full rationale")
print("=" * 65)
print()
print(age_result.summary())


# ─────────────────────────────────────────────────────
# Step 4: Export results
# ─────────────────────────────────────────────────────

from testaxiom import exporters

# Export as Markdown (free)
md = exporters.to_markdown(age_result)
with open("age_test_cases.md", "w") as f:
    f.write(md)
print("\n\n💾 Exported age_test_cases.md")

# Export as JSON (free)
import json
json_str = exporters.to_json(age_result)
with open("age_test_cases.json", "w") as f:
    f.write(json_str)
print("💾 Exported age_test_cases.json")


# ─────────────────────────────────────────────────────
# Step 5: Generate overall coverage report
# ─────────────────────────────────────────────────────

all_results = [username_result, age_result, country_result, password_result]

print("\n\n" + "=" * 65)
print("  COVERAGE REPORT — Registration Form")
print("=" * 65)

total_tests = 0
for r in all_results:
    total_tests += r.total_generated
    valid = sum(1 for tc in r.test_cases if tc.expected.value == "valid")
    invalid = sum(1 for tc in r.test_cases if tc.expected.value == "invalid")
    techniques = ", ".join(t.value.upper() for t in r.techniques_applied)
    print(f"\n  {r.parameter.name}:")
    print(f"    Type: {r.parameter.param_type}")
    print(f"    Techniques: {techniques}")
    print(f"    Tests: {r.total_generated} ({valid} valid, {invalid} invalid)")
    if r.efficiency_ratio:
        print(f"    Efficiency: {r.efficiency_ratio}")

print(f"\n  {'─' * 45}")
print(f"  TOTAL TEST CASES: {total_tests}")
print(f"  PARAMETERS COVERED: {len(all_results)}")
print(f"  TECHNIQUES USED: EP, BVA (2-value + 3-value)")
print()
print("  Every test case above includes a mathematical")
print("  rationale — ready for audit and traceability. ✓")
print()


# ─────────────────────────────────────────────────────
# Bonus: Using ParameterSpec for reusable definitions
# ─────────────────────────────────────────────────────

print("=" * 65)
print("  BONUS: Reusable parameter specs")
print("=" * 65)
print()

# Define once, reuse across test suites
age_spec = ParameterSpec(
    name="age",
    param_type="int",
    valid_range=(18, 120),
    constraints=["Must be a whole number", "Required field"],
    boundary_inclusive=True,
)

# Analyze with the spec object
result = analyze(age_spec, bva_mode="3-value")
print(f"  Spec: {age_spec.name} ({age_spec.param_type})")
print(f"  Range: {age_spec.valid_range}")
print(f"  Constraints: {age_spec.constraints}")
print(f"  Test cases generated: {result.total_generated}")
print()

# Iterate test cases in your automation framework
print("  Integration with pytest:")
print("  ─────────────────────────")
print()
print("  @pytest.mark.parametrize('age,expected', [")
for tc in result.test_cases:
    expected_bool = "True" if tc.expected.value == "valid" else "False"
    print(f"      ({tc.input_value}, {expected_bool}),  # {tc.id}")
print("  ])")
print("  def test_registration_age(age, expected):")
print("      result = register_user(age=age)")
print("      assert result.is_valid == expected")
