"""
Tests for TestAxiom License Key System.

Tests the full flow: generate → activate → verify → expire → deactivate.
"""

import os
import pytest

from testaxiom import activate, deactivate, get_tier, set_tier, get_license_info
from testaxiom import Tier, TierError, LicenseError
from testaxiom.licensing import verify_key, _LICENSE_FILE

# Import the keygen tool for generating test keys
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
from keygen import generate_license


# Shared test secret (never use this in production)
TEST_SECRET = b"test-secret-key-for-unit-tests-only-0123456789abcdef"


class TestKeyGeneration:
    """Test that keygen produces valid, verifiable keys."""

    def test_generates_key_with_ta_prefix(self):
        key = generate_license("user@test.com", "pro", 365, secret=TEST_SECRET)
        assert key.startswith("TA-")

    def test_generates_key_with_two_parts(self):
        key = generate_license("user@test.com", "pro", 365, secret=TEST_SECRET)
        body = key[3:]  # strip TA-
        parts = body.split(".")
        assert len(parts) == 2  # payload.signature

    def test_different_emails_produce_different_keys(self):
        k1 = generate_license("a@test.com", "pro", 365, secret=TEST_SECRET)
        k2 = generate_license("b@test.com", "pro", 365, secret=TEST_SECRET)
        assert k1 != k2

    def test_different_tiers_produce_different_keys(self):
        k1 = generate_license("user@test.com", "pro", 365, secret=TEST_SECRET)
        k2 = generate_license("user@test.com", "enterprise", 365, secret=TEST_SECRET)
        assert k1 != k2


class TestKeyVerification:
    """Test signature verification logic."""

    def test_valid_key_verifies(self):
        key = generate_license("user@test.com", "pro", 365, secret=TEST_SECRET)
        info = verify_key(key, secret=TEST_SECRET)
        assert info["email"] == "user@test.com"
        assert info["tier"] == "pro"

    def test_enterprise_key_verifies(self):
        key = generate_license("admin@corp.com", "enterprise", 365, org="BigCorp", secret=TEST_SECRET)
        info = verify_key(key, secret=TEST_SECRET)
        assert info["tier"] == "enterprise"
        assert info["org"] == "BigCorp"

    def test_tampered_payload_fails(self):
        key = generate_license("user@test.com", "pro", 365, secret=TEST_SECRET)
        # Tamper with a character in the payload
        tampered = key[:5] + "X" + key[6:]
        with pytest.raises(LicenseError):
            verify_key(tampered, secret=TEST_SECRET)

    def test_wrong_secret_fails(self):
        key = generate_license("user@test.com", "pro", 365, secret=TEST_SECRET)
        wrong_secret = b"wrong-secret-key"
        with pytest.raises(LicenseError, match="signature verification failed"):
            verify_key(key, secret=wrong_secret)

    def test_missing_ta_prefix_fails(self):
        key = generate_license("user@test.com", "pro", 365, secret=TEST_SECRET)
        no_prefix = key[3:]  # strip TA-
        with pytest.raises(LicenseError, match="must start with"):
            verify_key(no_prefix, secret=TEST_SECRET)

    def test_garbage_key_fails(self):
        with pytest.raises(LicenseError):
            verify_key("TA-not-a-valid-key", secret=TEST_SECRET)

    def test_empty_key_fails(self):
        with pytest.raises(LicenseError):
            verify_key("", secret=TEST_SECRET)


class TestActivation:
    """Test the full activation flow."""

    def setup_method(self):
        set_tier(Tier.COMMUNITY)
        # Clean up any saved license from previous tests
        if _LICENSE_FILE.exists():
            _LICENSE_FILE.unlink()

    def teardown_method(self):
        deactivate()

    def test_activate_pro_unlocks_tier(self):
        key = generate_license("user@test.com", "pro", 365, secret=TEST_SECRET)
        activate(key, secret=TEST_SECRET)
        assert get_tier() == Tier.PRO

    def test_activate_enterprise_unlocks_tier(self):
        key = generate_license("admin@corp.com", "enterprise", 365, secret=TEST_SECRET)
        activate(key, secret=TEST_SECRET)
        assert get_tier() == Tier.ENTERPRISE

    def test_activate_returns_license_info(self):
        key = generate_license("user@test.com", "pro", 365, org="TestCo", secret=TEST_SECRET)
        info = activate(key, secret=TEST_SECRET)
        assert info["email"] == "user@test.com"
        assert info["tier"] == "pro"
        assert info["org"] == "TestCo"

    def test_get_license_info_after_activation(self):
        key = generate_license("user@test.com", "pro", 365, secret=TEST_SECRET)
        activate(key, secret=TEST_SECRET)
        info = get_license_info()
        assert info is not None
        assert info["email"] == "user@test.com"

    def test_expired_key_raises(self):
        key = generate_license("user@test.com", "pro", -1, secret=TEST_SECRET)  # expired yesterday
        with pytest.raises(LicenseError, match="expired"):
            activate(key, secret=TEST_SECRET)

    def test_expired_key_does_not_change_tier(self):
        assert get_tier() == Tier.COMMUNITY
        key = generate_license("user@test.com", "pro", -1, secret=TEST_SECRET)
        with pytest.raises(LicenseError):
            activate(key, secret=TEST_SECRET)
        assert get_tier() == Tier.COMMUNITY  # still community

    def test_activate_persists_to_disk(self):
        key = generate_license("user@test.com", "pro", 365, secret=TEST_SECRET)
        activate(key, secret=TEST_SECRET)
        assert _LICENSE_FILE.exists()
        saved = _LICENSE_FILE.read_text().strip()
        assert saved == key


class TestDeactivation:
    """Test deactivation reverts to Community."""

    def test_deactivate_reverts_tier(self):
        key = generate_license("user@test.com", "pro", 365, secret=TEST_SECRET)
        activate(key, secret=TEST_SECRET)
        assert get_tier() == Tier.PRO

        deactivate()
        assert get_tier() == Tier.COMMUNITY

    def test_deactivate_clears_license_info(self):
        key = generate_license("user@test.com", "pro", 365, secret=TEST_SECRET)
        activate(key, secret=TEST_SECRET)
        deactivate()
        assert get_license_info() is None

    def test_deactivate_removes_saved_file(self):
        key = generate_license("user@test.com", "pro", 365, secret=TEST_SECRET)
        activate(key, secret=TEST_SECRET)
        assert _LICENSE_FILE.exists()

        deactivate()
        assert not _LICENSE_FILE.exists()


class TestLicenseWithFeatureGating:
    """Test that license activation actually unlocks Pro features."""

    def setup_method(self):
        set_tier(Tier.COMMUNITY)

    def teardown_method(self):
        deactivate()

    def test_pairwise_blocked_then_unlocked(self):
        from testaxiom.engines.pairwise import PairwiseEngine, Parameter

        engine = PairwiseEngine()
        params = [Parameter("a", [1, 2]), Parameter("b", ["x", "y"])]

        # Blocked on community
        with pytest.raises(TierError):
            engine.generate(params)

        # Activate pro
        key = generate_license("user@test.com", "pro", 365, secret=TEST_SECRET)
        activate(key, secret=TEST_SECRET)

        # Now works
        cases = engine.generate(params)
        assert len(cases) > 0

    def test_csv_export_blocked_then_unlocked(self):
        from testaxiom import analyze, exporters

        result = analyze("age", param_type="int", valid_range=(18, 65))

        # Blocked
        with pytest.raises(TierError):
            exporters.to_csv(result)

        # Activate
        key = generate_license("user@test.com", "pro", 365, secret=TEST_SECRET)
        activate(key, secret=TEST_SECRET)

        # Works
        csv = exporters.to_csv(result)
        assert "EP-age-001" in csv
