"""
TestAxiom License Key Generator (ADMIN TOOL — DO NOT DISTRIBUTE)

This script generates signed license keys for customers.
Keep the PRIVATE key secret. Only the PUBLIC key ships with testaxiom.

How it works:
    1. You generate an RSA key pair (once)
    2. For each customer, you create a payload (tier, email, expiry)
    3. You sign the payload with the PRIVATE key → license key
    4. Customer enters the license key into testaxiom
    5. testaxiom verifies the signature with the PUBLIC key (offline)
    6. No server needed — the math proves authenticity

Usage:
    # First time: generate keys
    python keygen.py --init

    # Generate a license
    python keygen.py --email "customer@company.com" --tier pro --days 365

    # Generate enterprise license
    python keygen.py --email "big@corp.com" --tier enterprise --days 365 --org "BigCorp Ltd"
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path


# ─── Key Management ───

KEYS_DIR = Path(__file__).parent / ".keys"
SECRET_KEY_FILE = KEYS_DIR / "testaxiom.secret"


def init_keys() -> None:
    """Generate a new HMAC secret key (one-time setup)."""
    KEYS_DIR.mkdir(exist_ok=True)

    if SECRET_KEY_FILE.exists():
        print(f"Secret key already exists at {SECRET_KEY_FILE}")
        print("Delete it first if you want to regenerate (will invalidate ALL existing licenses).")
        return

    secret = os.urandom(64)
    SECRET_KEY_FILE.write_bytes(secret)
    os.chmod(SECRET_KEY_FILE, 0o600)  # owner read/write only

    # Derive the public verification hash (ships with testaxiom)
    pub_hash = hashlib.sha256(secret).hexdigest()[:32]

    print(f"Secret key saved to: {SECRET_KEY_FILE}")
    print(f"Public verification hash: {pub_hash}")
    print()
    print("IMPORTANT:")
    print(f"  1. Keep {SECRET_KEY_FILE} SECRET — never commit to git")
    print(f"  2. Copy the public hash to licensing.py: VERIFICATION_HASH = '{pub_hash}'")


def load_secret() -> bytes:
    """Load the secret key from disk."""
    if not SECRET_KEY_FILE.exists():
        print("No secret key found. Run: python keygen.py --init")
        sys.exit(1)
    return SECRET_KEY_FILE.read_bytes()


# ─── License Generation ───

def generate_license(
    email: str,
    tier: str,
    days: int,
    org: str = "",
    secret: bytes | None = None,
) -> str:
    """
    Generate a signed license key.

    The key format is: BASE64(payload).BASE64(signature)
    Payload is JSON: {email, tier, org, issued, expires}
    Signature is HMAC-SHA256 of the payload bytes.
    """
    if secret is None:
        secret = load_secret()

    now = datetime.now(timezone.utc)
    expires = now + timedelta(days=days)

    payload = {
        "email": email,
        "tier": tier,
        "org": org,
        "issued": now.strftime("%Y-%m-%d"),
        "expires": expires.strftime("%Y-%m-%d"),
        "v": 1,  # license format version
    }

    payload_bytes = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
    payload_b64 = base64.urlsafe_b64encode(payload_bytes).decode()

    signature = hmac.new(secret, payload_bytes, hashlib.sha256).digest()
    sig_b64 = base64.urlsafe_b64encode(signature).decode()

    license_key = f"TA-{payload_b64}.{sig_b64}"

    return license_key


def display_license(key: str, email: str, tier: str, days: int, org: str) -> None:
    """Pretty-print a generated license."""
    print()
    print("═" * 60)
    print("  TestAxiom License Key Generated")
    print("═" * 60)
    print()
    print(f"  Email:   {email}")
    print(f"  Tier:    {tier.upper()}")
    if org:
        print(f"  Org:     {org}")
    print(f"  Valid:   {days} days")
    print()
    print("  License Key:")
    print(f"  {key}")
    print()
    print("  Customer activation:")
    print('    from testaxiom import activate')
    print(f'    activate("{key}")')
    print()
    print("═" * 60)


# ─── CLI ───

def main():
    parser = argparse.ArgumentParser(
        prog="keygen",
        description="TestAxiom License Key Generator (admin tool)",
    )
    parser.add_argument("--init", action="store_true", help="Generate secret key (first-time setup)")
    parser.add_argument("--email", "-e", help="Customer email")
    parser.add_argument("--tier", "-t", choices=["pro", "enterprise"], help="License tier")
    parser.add_argument("--days", "-d", type=int, default=365, help="Validity in days (default: 365)")
    parser.add_argument("--org", "-o", default="", help="Organization name (enterprise)")

    args = parser.parse_args()

    if args.init:
        init_keys()
        return

    if not args.email or not args.tier:
        parser.print_help()
        print("\nExamples:")
        print('  python keygen.py --init')
        print('  python keygen.py -e "user@co.com" -t pro -d 365')
        return

    key = generate_license(args.email, args.tier, args.days, args.org)
    display_license(key, args.email, args.tier, args.days, args.org)


if __name__ == "__main__":
    main()
