"""Tests for the ask_user tool."""

from __future__ import annotations

import asyncio

from mirascope import llm
import pytest

from kiss.agent.tools.ask_user import ask_user
from kiss.core.deps import AgentDeps
from kiss.core.types import AskUserReply, AskUserRequest


@pytest.mark.asyncio
async def test_ask_user_tool_returns_callback_answer() -> None:
    seen: list[str] = []

    async def on_ask_user(req: AskUserRequest) -> AskUserReply:
        seen.append(req.question)
        return AskUserReply.from_text("use the API path")

    ctx = llm.Context(deps=AgentDeps(on_ask_user=on_ask_user))

    result = await ask_user(ctx, "Which path should I use?")

    assert result == "use the API path"
    assert seen == ["Which path should I use?"]


@pytest.mark.asyncio
async def test_ask_user_tool_reports_when_unsupported() -> None:
    ctx = llm.Context(deps=AgentDeps())

    result = await ask_user(ctx, "Clarify?")

    assert "does not support mid-turn questions" in result


@pytest.mark.asyncio
async def test_ask_user_tool_with_options_builds_question_options() -> None:
    received: list[AskUserRequest] = []

    async def on_ask_user(req: AskUserRequest) -> AskUserReply:
        received.append(req)
        return AskUserReply(outcome="selected", selected_choice_ids=["alpha"])

    ctx = llm.Context(deps=AgentDeps(on_ask_user=on_ask_user))

    result = await ask_user(
        ctx,
        "Pick one?",
        type="choice",
        options=["Alpha", "Beta"],
        header="Choose",
        default_id="alpha",
    )

    assert result == "alpha"
    assert len(received) == 1
    req = received[0]
    assert req.header == "Choose"
    assert req.type == "choice"
    assert [o.id for o in req.options] == ["alpha", "beta"]
    assert [o.label for o in req.options] == ["Alpha", "Beta"]
    assert req.default_id == "alpha"


@pytest.mark.asyncio
async def test_ask_user_tool_timeout_cancels_future() -> None:
    from unittest.mock import patch

    async def on_ask_user(_req: AskUserRequest) -> AskUserReply:
        await asyncio.sleep(10)
        return AskUserReply.from_text("too late")

    async def _fake_wait_for(coro: object, *, timeout: float) -> object:
        import inspect

        if inspect.iscoroutine(coro):
            coro.close()
        raise asyncio.TimeoutError

    ctx = llm.Context(deps=AgentDeps(on_ask_user=on_ask_user))

    with patch("kiss.agent.tools.ask_user.asyncio.wait_for", _fake_wait_for):
        result = await ask_user(ctx, "Slow?")

    assert "did not respond in time" in result


@pytest.mark.asyncio
async def test_ask_user_tool_multi_select_returns_ids() -> None:
    received: list[AskUserRequest] = []

    async def on_ask_user(req: AskUserRequest) -> AskUserReply:
        received.append(req)
        return AskUserReply(outcome="selected", selected_choice_ids=["alpha", "beta"])

    ctx = llm.Context(deps=AgentDeps(on_ask_user=on_ask_user))

    result = await ask_user(
        ctx,
        "Pick some?",
        type="choice",
        options=["Alpha", "Beta", "Gamma"],
        multi_select=True,
    )

    assert result == "alpha, beta"
    assert received[0].multi_select is True
