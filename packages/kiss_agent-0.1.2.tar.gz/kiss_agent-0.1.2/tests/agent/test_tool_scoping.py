from __future__ import annotations

import pytest

from kiss.agent.plan_types import TurnPhase
from kiss.agent.tool_scoping import ToolSetName, classify_intent
from kiss.agent.tools.registry import ToolCategory, _tool_specs, create_all_tools
from kiss.agent.turn_event_callbacks import _READ_ONLY_TOOLS


@pytest.mark.parametrize(
    "task,expected",
    [
        # edit verbs — original
        ("fix the bug in login.py", "edit"),
        ("write a new test for the parser", "edit"),
        # edit verbs — new
        ("rename the function to process_data", "edit"),
        ("move this file to utils/", "edit"),
        ("revert the last commit", "edit"),
        ("migrate the database schema", "edit"),
        ("patch the auth flow", "edit"),
        # search verbs — original
        ("search for where UserModel is defined", "search"),
        ("find all TODO comments", "search"),
        ("explain how the caching works", "search"),
        # search verbs — new
        ("read through the config file", "search"),
        ("look at the error logs", "search"),
        ("debug this crash", "search"),
        ("trace the call path", "search"),
        ("investigate the slowdown", "search"),
        ("explore the codebase structure", "search"),
        # validate verbs — original
        ("validate the schema before saving", "validate"),
        ("check that all tests pass", "validate"),
        ("review the recent changes", "validate"),
        # validate verbs — new
        ("run the tests", "validate"),
        ("run ruff on the file", "validate"),
        # full fallback
        ("deploy the application to staging", "full"),
    ],
)
def test_classify_intent_fallback_tiers(task: str, expected: str) -> None:
    """classify_intent must return the correct intent for all verb categories."""
    result = classify_intent(task)
    assert result == expected


def _tool_names(tool_set: ToolSetName, phase: TurnPhase) -> set[str]:
    return {tool.__name__ for tool in create_all_tools(tool_set, phase=phase)}


def test_create_all_tools_blocks_research_phase_mutations() -> None:
    names = _tool_names("full", TurnPhase.RESEARCH)

    assert "read_file" in names
    assert "edit_file" not in names
    assert "write_file" not in names
    assert "apply_patch" not in names
    assert "git_commit" not in names
    assert "git_stage" not in names
    assert "run_bash" not in names
    assert "run_python" not in names


def test_create_all_tools_blocks_only_git_commit_in_planning() -> None:
    names = _tool_names("full", TurnPhase.PLANNING)

    assert "edit_file" in names
    assert "write_file" in names
    assert "apply_patch" in names
    assert "git_stage" in names
    assert "git_commit" not in names


def test_create_all_tools_allows_execution_phase_tools() -> None:
    names = _tool_names("full", TurnPhase.EXECUTION)

    assert "edit_file" in names
    assert "write_file" in names
    assert "apply_patch" in names
    assert "git_commit" in names
    assert "run_bash" in names
    assert "run_python" in names


# ── _READ_ONLY_TOOLS sync ──────────────────────────────────────────────────────

_ENTIRELY_READ_ONLY_CATEGORIES = frozenset(
    {ToolCategory.SEARCH, ToolCategory.VALIDATION, ToolCategory.EXTERNAL}
)


def test_read_only_tools_has_no_phantom_registry_entries() -> None:
    all_names = {name for name, _, _ in _tool_specs()}
    phantoms = _READ_ONLY_TOOLS - all_names
    assert not phantoms, f"_READ_ONLY_TOOLS contains unregistered tools: {phantoms}"


def test_read_only_tools_covers_all_clean_category_tools() -> None:
    expected = {
        name for name, cat, _ in _tool_specs() if cat in _ENTIRELY_READ_ONLY_CATEGORIES
    }
    missing = expected - _READ_ONLY_TOOLS
    assert not missing, (
        f"Tools in read-only categories missing from _READ_ONLY_TOOLS: {missing}"
    )
