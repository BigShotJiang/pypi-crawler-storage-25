"""Tests for perf helpers."""

from __future__ import annotations

from collections.abc import Mapping

import pytest

from kiss.agent.perf import perf_log
from kiss.core.tracing import SessionTracer


@pytest.mark.asyncio
async def test_perf_log_records_turn_span_and_completion_event() -> None:
    tracer = SessionTracer()

    async with perf_log(tracer, "agent.turn", task_type="unknown"):
        pass

    _active, finished = tracer.get_live_snapshot()
    assert len(finished) == 1
    span = finished[0]
    assert span.attributes is not None
    assert span.name == "agent.turn"
    assert span.attributes["task_type"] == "unknown"
    assert len(span.events) == 1
    assert span.events[0].name == "agent.turn.completed"
    event_attrs = span.events[0].attributes
    assert isinstance(event_attrs, Mapping)
    elapsed_ms = event_attrs["elapsed_ms"]
    assert isinstance(elapsed_ms, int | float)
    assert elapsed_ms >= 0
