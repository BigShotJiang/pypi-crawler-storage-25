"""Sanity checks for the legacy regression prompt corpus."""

from __future__ import annotations

from pathlib import Path

from tests.agent.regression_corpus import REGRESSION_CASES


def test_regression_corpus_has_target_size() -> None:
    assert 20 <= len(REGRESSION_CASES) <= 30


def test_regression_corpus_ids_and_prompts_are_unique() -> None:
    ids = [case.id for case in REGRESSION_CASES]
    prompts = [case.prompt for case in REGRESSION_CASES]
    assert len(ids) == len(set(ids))
    assert len(prompts) == len(set(prompts))


def test_regression_corpus_sources_exist() -> None:
    repo_root = Path(__file__).resolve().parents[2]
    for case in REGRESSION_CASES:
        assert (repo_root / case.source).exists(), case.source


def test_regression_corpus_covers_core_legacy_routes() -> None:
    routes = {case.legacy_route for case in REGRESSION_CASES}
    assert {"researcher", "coder", "reviewer", "full_pipeline"} <= routes
