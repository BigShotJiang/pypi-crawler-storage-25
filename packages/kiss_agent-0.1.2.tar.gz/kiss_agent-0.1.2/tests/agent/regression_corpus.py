"""Legacy prompt corpus extracted from existing tests for refactor regression checks."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class RegressionCase:
    id: str
    prompt: str
    legacy_route: str
    task_type: str
    source: str
    note: str


REGRESSION_CASES: tuple[RegressionCase, ...] = (
    RegressionCase(
        "review_pr",
        "review the PR",
        "reviewer",
        "review",
        "tests/agent/test_loop.py",
        "review-only route",
    ),
    RegressionCase(
        "check_bugs",
        "check for bugs",
        "reviewer",
        "review",
        "tests/agent/test_loop.py",
        "review keyword variant",
    ),
    RegressionCase(
        "audit_security",
        "audit security",
        "reviewer",
        "review",
        "tests/agent/test_loop.py",
        "security review route",
    ),
    RegressionCase(
        "validate_change",
        "validate this change",
        "reviewer",
        "review",
        "tests/agent/test_loop.py",
        "validation route",
    ),
    RegressionCase(
        "find_run_bash_usages",
        "find all usages of run_bash",
        "researcher",
        "search",
        "tests/agent/test_loop.py",
        "research route by symbol lookup",
    ),
    RegressionCase(
        "search_imports",
        "search for imports",
        "researcher",
        "search",
        "tests/agent/test_loop.py",
        "generic research route",
    ),
    RegressionCase(
        "explain_module",
        "explain this module",
        "researcher",
        "explain",
        "tests/agent/test_loop.py",
        "explanation route",
    ),
    RegressionCase(
        "overwrite_script",
        "overwrite script.ps1 with the following content",
        "coder",
        "fix",
        "tests/agent/test_loop.py",
        "single-worker write route",
    ),
    RegressionCase(
        "update_script",
        "update script.ps1 so it takes arguments",
        "coder",
        "fix",
        "tests/agent/test_loop.py",
        "edit route",
    ),
    RegressionCase(
        "replace_script_contents",
        "replace the contents of script.ps1 with the following content",
        "coder",
        "fix",
        "tests/agent/test_loop.py",
        "overwrite-existing route",
    ),
    RegressionCase(
        "fix_timeout_bug",
        "fix the timeout bug",
        "full_pipeline",
        "fix",
        "tests/agent/test_loop.py",
        "researcher -> coder -> reviewer",
    ),
    RegressionCase(
        "implement_new_api",
        "implement the new API",
        "full_pipeline",
        "fix",
        "tests/agent/test_loop.py",
        "implementation route",
    ),
    RegressionCase(
        "do_something",
        "do something",
        "full_pipeline",
        "fix",
        "tests/agent/test_loop.py",
        "default route fallback",
    ),
    RegressionCase(
        "review_and_fix",
        "review and fix the code",
        "full_pipeline",
        "fix",
        "tests/agent/test_loop.py",
        "mixed review+edit route",
    ),
    RegressionCase(
        "find_bash_tools",
        "find bash tools",
        "researcher",
        "search",
        "tests/agent/test_loop.py",
        "existing researcher integration query",
    ),
    RegressionCase(
        "unusual_request",
        "handle this unusual request",
        "classifier_fallback",
        "search",
        "tests/agent/test_loop.py",
        "ambiguous classifier fallback",
    ),
    RegressionCase(
        "look_at_note_ref",
        "Look at @note.py",
        "context_ref",
        "explain",
        "tests/agent/test_loop.py",
        "manifest injection with head preview",
    ),
    RegressionCase(
        "look_at_readme_ref",
        "Look at @README.md",
        "context_ref",
        "explain",
        "tests/agent/test_loop.py",
        "workspace-root ref resolution",
    ),
    RegressionCase(
        "check_hello_ref",
        "Check @hello.py",
        "context_ref",
        "explain",
        "tests/agent/test_context_refs.py",
        "full-file context expansion",
    ),
    RegressionCase(
        "look_at_code_range",
        "Look at @code.py:2-3",
        "context_ref",
        "explain",
        "tests/agent/test_context_refs.py",
        "range-limited context expansion",
    ),
    RegressionCase(
        "which_path_should_i_use",
        "Which path should I use?",
        "ask_user",
        "clarify",
        "tests/agent/test_ask_user_tool.py",
        "direct clarification path",
    ),
    RegressionCase(
        "clarify",
        "Clarify?",
        "ask_user",
        "clarify",
        "tests/agent/test_ask_user_tool.py",
        "minimal clarification prompt",
    ),
    RegressionCase(
        "save_script_locally",
        "Save script locally as List-VMs-In-Datacenter.ps1",
        "coder",
        "fix",
        "tests/agent/test_loop.py",
        "coder truthfulness guard",
    ),
    RegressionCase(
        "review_shell_file",
        "review shell.py",
        "reviewer",
        "review",
        "tests/agent/test_loop.py",
        "reviewer concrete-worker prompt",
    ),
)
