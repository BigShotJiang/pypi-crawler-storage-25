"""Tests for compaction helpers and SessionManager."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

import asyncio

from kiss.agent.plan_types import TurnPhase
from kiss.agent.compaction import (
    CompactionManager,
    _extract_prior_summary,
    _SUMMARY_MARKER,
    dedup_tool_calls,
    prune_error_outputs,
    sliding_window_fallback,
)
from kiss.core.deps import AgentDeps
from kiss.agent.loop import KissAgent
from kiss.core.session_manager import SessionManager
from kiss.core.settings import Settings
from kiss.core.types import EventKind


# ── Fakes ────────────────────────────────────────────────────────────────────


class _FakePart:
    type: str
    id: str
    name: str
    args: str
    result: object
    error: object

    def __init__(self, type_: str, **kwargs: object) -> None:
        self.type = type_
        for k, v in kwargs.items():
            setattr(self, k, v)


class _FakeMsg:
    def __init__(self, role: str, parts: list[_FakePart]) -> None:
        self.role = role
        self.content = parts


def _make_tool_pair(
    name: str,
    args: str,
    result: object = "ok",
    error: object = None,
    call_id: str = "id1",
) -> tuple[_FakeMsg, _FakeMsg]:
    """Return (assistant_msg_with_tool_call, user_msg_with_tool_output)."""
    call = _FakePart("tool_call", id=call_id, name=name, args=args)
    out = _FakePart("tool_output", id=call_id, result=result, error=error)
    return _FakeMsg("assistant", [call]), _FakeMsg("user", [out])


async def _summary_compactor(*_: object, **__: object) -> str:
    return "summary"


def _make_agent(tmp_path: Path, compactor=_summary_compactor) -> KissAgent:
    settings = Settings(model="test:model")

    return KissAgent(
        settings,
        compactor,
        sessions_dir=tmp_path,
    )


# ── prune_error_outputs ─────────────────────────────────────────────────────


def testprune_error_outputs_replaces_error_field() -> None:
    class _Err:
        def __str__(self) -> str:
            return "boom"

    _, user_msg = _make_tool_pair("read_file", "{}", error=_Err())
    messages = [user_msg]
    count = prune_error_outputs(messages)

    assert count == 1
    part = user_msg.content[0]
    assert part.error is None
    assert str(part.result).startswith("[ERROR:")


def testprune_error_outputs_ignores_success() -> None:
    _, user_msg = _make_tool_pair("read_file", "{}", result="content")
    count = prune_error_outputs([user_msg])
    assert count == 0
    assert user_msg.content[0].result == "content"


def testprune_error_outputs_skips_non_user_messages() -> None:
    part = _FakePart("tool_output", id="x", result=None, error=Exception("x"))
    msg = _FakeMsg("assistant", [part])
    count = prune_error_outputs([msg])
    assert count == 0


def testprune_error_outputs_truncates_long_error_at_120() -> None:
    class _LongErr:
        def __str__(self) -> str:
            return "x" * 200

    _, user_msg = _make_tool_pair("t", "{}", error=_LongErr())
    prune_error_outputs([user_msg])
    result = str(user_msg.content[0].result)
    assert len(result) < 200


# ── dedup_tool_calls ─────────────────────────────────────────────────────────


def test_dedup_collapses_identical_calls() -> None:
    a1, u1 = _make_tool_pair("search", '{"q":"foo"}', result="r1", call_id="c1")
    a2, u2 = _make_tool_pair("search", '{"q":"foo"}', result="r1", call_id="c2")
    messages = [a1, u1, a2, u2]
    count, rollback = dedup_tool_calls(messages)

    assert count == 1
    assert len(rollback) == 1
    assert str(u2.content[0].result).startswith("[DEDUP:")


def test_dedup_preserves_different_calls() -> None:
    a1, u1 = _make_tool_pair("search", '{"q":"foo"}', result="r1", call_id="c1")
    a2, u2 = _make_tool_pair("search", '{"q":"bar"}', result="r2", call_id="c2")
    messages = [a1, u1, a2, u2]
    count, rollback = dedup_tool_calls(messages)

    assert count == 0
    assert rollback == []
    assert u2.content[0].result == "r2"


def test_dedup_window_limits_lookback() -> None:
    pairs = [_make_tool_pair("t", "{}", result="r", call_id=f"c{i}") for i in range(30)]
    messages: list[object] = []
    for a, u in pairs:
        messages.extend([a, u])

    # Only the last 20 calls in window — first pair outside window, no dedup counted
    # for calls at position 0-9; but calls 10-29 are all identical so 10 should dedup.
    count, _ = dedup_tool_calls(messages, window=20)
    assert count >= 1  # at minimum some dedup happened within the window


def test_dedup_returns_zero_for_empty() -> None:
    count, rollback = dedup_tool_calls([])
    assert count == 0
    assert rollback == []


# ── SessionManager ────────────────────────────────────────────────────────────


def test_session_manager_roundtrip(tmp_path: Path) -> None:
    sm = SessionManager(tmp_path)
    messages = [
        {"role": "user", "content": "hello"},
        {"role": "assistant", "content": "hi"},
    ]
    ok = sm.export_snapshot(messages, "uuid-1", "2024-01-01T00:00:00")
    assert ok

    result = sm.restore_snapshot()
    assert result is not None
    restored, ts, todos, team_messages, last_tool, phase = result
    assert ts == "2024-01-01T00:00:00"
    assert restored == messages
    assert todos == []
    assert team_messages == []
    assert last_tool == ""
    assert phase is TurnPhase.RESEARCH


def test_session_manager_restore_returns_none_when_no_exports(tmp_path: Path) -> None:
    sm = SessionManager(tmp_path)
    assert sm.restore_snapshot() is None


def test_session_manager_prune_keeps_last_10(tmp_path: Path) -> None:
    sm = SessionManager(tmp_path)
    for i in range(15):
        sm.export_snapshot(
            [{"role": "user", "content": "x"}], f"uuid-{i:02d}", f"ts-{i}"
        )

    exports = list(tmp_path.glob("export_*.json"))
    assert len(exports) == 10


def test_session_manager_export_failure_returns_false(tmp_path: Path) -> None:
    # SessionManager creates dir in __init__, so use a file-as-dir to force OSError.
    blocked = tmp_path / "notadir"
    blocked.write_text("block")
    sm2 = SessionManager.__new__(SessionManager)
    sm2._dir = blocked
    sm2._log_path = blocked / "log.jsonl"
    result = sm2.export_snapshot([{"role": "user", "content": "x"}], "uid", "ts")
    assert result is False


def test_session_manager_append_turn_creates_jsonl(tmp_path: Path) -> None:
    sm = SessionManager(tmp_path)
    sm.append_turn("user", "hello")
    sm.append_turn("assistant", "hi")

    lines = sm.log_path.read_text().splitlines()
    assert len(lines) == 2
    import json

    first = json.loads(lines[0])
    assert first["role"] == "user"
    assert first["content"] == "hello"


def test_session_manager_roundtrip_with_phase(tmp_path: Path) -> None:
    sm = SessionManager(tmp_path)
    messages = [{"role": "user", "content": "phaseful"}]

    ok = sm.export_snapshot(
        messages,
        "uuid-phase",
        "2024-01-01T00:00:00",
        phase=TurnPhase.EXECUTION,
    )
    assert ok

    result = sm.restore_snapshot()
    assert result is not None
    restored, _ts, _todos, _team_messages, _last_tool, phase = result
    assert restored == messages
    assert phase is TurnPhase.EXECUTION


def test_restore_snapshot_invalid_phase_falls_back_to_research(tmp_path: Path) -> None:
    sm = SessionManager(tmp_path)
    snapshot_path = tmp_path / "export_uuid-bad-phase.json"
    snapshot_path.write_text(
        json.dumps(
            {
                "version": 5,
                "uuid": "uuid-bad-phase",
                "ts": "2024-01-01T00:00:00",
                "messages": [{"role": "user", "content": "hi"}],
                "phase": "execution",
            }
        )
    )

    result = sm.restore_snapshot()
    assert result is not None
    _, _, _, _, _, phase = result
    assert phase is TurnPhase.RESEARCH


def test_restore_snapshot_unknown_phase_falls_back_to_research(tmp_path: Path) -> None:
    sm = SessionManager(tmp_path)
    snapshot_path = tmp_path / "export_uuid-unknown-phase.json"
    snapshot_path.write_text(
        json.dumps(
            {
                "version": 5,
                "uuid": "uuid-unknown-phase",
                "ts": "2024-01-01T00:00:00",
                "messages": [{"role": "user", "content": "hi"}],
                "phase": 99,
            }
        )
    )

    result = sm.restore_snapshot()
    assert result is not None
    _, _, _, _, _, phase = result
    assert phase is TurnPhase.RESEARCH


# ── compact() integration ─────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_compact_yields_compacting_then_compacted(tmp_path: Path) -> None:
    agent = _make_agent(tmp_path)
    agent.history = [object()]  # non-empty history

    events = [e async for e in agent.compact("test")]
    kinds = [e.kind for e in events]

    assert EventKind.COMPACTING in kinds
    assert EventKind.COMPACTED in kinds


@pytest.mark.asyncio
async def test_compact_clears_history(tmp_path: Path) -> None:
    agent = _make_agent(tmp_path)

    class _Msg:
        role = "user"
        content = "old"

    agent.history = [_Msg(), _Msg(), _Msg()]
    [_ async for _ in agent.compact("manual")]

    assert len(agent.history) == 2  # summary pair only


@pytest.mark.asyncio
async def test_compact_exports_snapshot(tmp_path: Path) -> None:
    agent = _make_agent(tmp_path)
    agent.history = [object()]

    [_ async for _ in agent.compact("manual")]

    exports = list(tmp_path.glob("export_*.json"))
    assert len(exports) == 1


@pytest.mark.asyncio
async def test_compact_emits_compaction_meta(tmp_path: Path) -> None:
    agent = _make_agent(tmp_path)
    agent.history = [object()]

    events = [e async for e in agent.compact("manual")]
    compacted = next(e for e in events if e.kind is EventKind.COMPACTED)

    assert compacted.compaction_meta is not None
    assert "uuid" in compacted.compaction_meta
    assert "ts" in compacted.compaction_meta
    assert "deduped" in compacted.compaction_meta


@pytest.mark.asyncio
async def test_compact_export_failure_emits_info_event(tmp_path: Path) -> None:
    agent = _make_agent(tmp_path)
    agent.history = [object()]

    # Sabotage the session_manager so export fails
    blocked = tmp_path / "blocked"
    blocked.write_text("file not dir")
    agent.session_manager._dir = blocked

    events = [e async for e in agent.compact("manual")]
    info_events = [e for e in events if e.kind is EventKind.INFO]

    assert any("export failed" in e.info for e in info_events)


# ── sliding_window_fallback ──────────────────────────────────────────────────


def _text_msg(role: str, text: str = "") -> _FakeMsg:
    return _FakeMsg(role, [_FakePart("text", text=text or role)])


def test_sliding_window_within_budget_returns_unchanged() -> None:
    msgs = [_text_msg("user", "u"), _text_msg("assistant", "a")]
    result = sliding_window_fallback(msgs, budget_tokens=1_000_000)
    assert result == msgs


def test_sliding_window_drops_oldest_non_pinned_pair() -> None:
    u0, a0 = _text_msg("user", "pinned"), _text_msg("assistant", "pinned")
    u1, a1 = _text_msg("user", "drop1"), _text_msg("assistant", "drop1")
    u2, a2 = _text_msg("user", "drop2"), _text_msg("assistant", "drop2")
    u3, a3 = _text_msg("user", "last"), _text_msg("assistant", "last")
    history = [u0, a0, u1, a1, u2, a2, u3, a3]

    # budget=0 → force max trim; pinned=1 → pair0 sacred
    result = sliding_window_fallback(history, budget_tokens=0, pinned_turns=1)

    assert result[0] is u0
    assert result[1] is a0
    assert u1 not in result
    assert a1 not in result
    assert u2 not in result
    assert a2 not in result


def test_sliding_window_preserves_pinned_prefix() -> None:
    u0, a0 = _text_msg("user", "p"), _text_msg("assistant", "p")
    u1, a1 = _text_msg("user", "x"), _text_msg("assistant", "x")
    history = [u0, a0, u1, a1]

    result = sliding_window_fallback(history, budget_tokens=0, pinned_turns=1)

    assert result[0] is u0
    assert result[1] is a0


def test_sliding_window_last_resort_stub_replaces_pair() -> None:
    u0, a0 = _text_msg("user", "x"), _text_msg("assistant", "x")
    history = [u0, a0]

    result = sliding_window_fallback(history, budget_tokens=0, pinned_turns=0)

    assert len(result) == 2
    assert result[0] is not u0
    assert result[1] is not a0
    assert getattr(result[0], "role", None) == "user"
    assert getattr(result[1], "role", None) == "assistant"


def test_sliding_window_clamps_pinned_turns() -> None:
    u0, a0 = _text_msg("user", "x"), _text_msg("assistant", "x")
    history = [u0, a0]

    # pinned=100 but only 1 pair → clamps to 0 → stub applied
    result = sliding_window_fallback(history, budget_tokens=0, pinned_turns=100)

    assert len(result) == 2  # stub pair returned, no crash


def test_sliding_window_empty_history() -> None:
    assert sliding_window_fallback([], budget_tokens=1000) == []


def test_sliding_window_no_pairs_returns_history_unchanged() -> None:
    lone = _text_msg("assistant", "lone")
    result = sliding_window_fallback([lone], budget_tokens=0)
    assert result == [lone]


# ── _extract_prior_summary ───────────────────────────────────────────────────


def test_extract_prior_summary_detects_marker() -> None:
    summary_text = "prior context here"
    first = _text_msg("user", f"{_SUMMARY_MARKER}{summary_text}")
    second = _text_msg("assistant", "Understood.")
    third = _text_msg("user", "new turn")
    prior, new_turns = _extract_prior_summary([first, second, third])
    assert prior == summary_text
    assert len(new_turns) == 1
    assert new_turns[0] is third


def test_extract_prior_summary_returns_full_history_when_no_marker() -> None:
    msgs = [_text_msg("user", "hello"), _text_msg("assistant", "hi")]
    prior, new_turns = _extract_prior_summary(msgs)
    assert prior is None
    assert new_turns == msgs


# ── CompactionManager.run ─────────────────────────────────────────────────────


def _fake_deps() -> AgentDeps:
    return AgentDeps(context_window=100_000)


def _make_settings(strategy: str) -> object:
    return type(
        "_S",
        (),
        {"compaction_strategy": strategy, "pinned_prefix_turns": 0},
    )()


@pytest.mark.asyncio
async def test_compaction_manager_fallback_on_compactor_error(tmp_path: Path) -> None:
    async def _failing_compactor(*_: object, **__: object) -> str:
        raise RuntimeError("LLM unavailable")

    manager = CompactionManager(
        _failing_compactor,
        SessionManager(tmp_path),
        _make_settings("summarize_then_slide"),
    )
    history = [_text_msg("user", "a"), _text_msg("assistant", "b")]
    queue: asyncio.Queue = asyncio.Queue()
    deps = _fake_deps()

    result = await manager.run(history, "test", queue, deps)

    assert result.history is not None

    events = []
    while not queue.empty():
        events.append(await queue.get())
    assert any(
        getattr(e, "kind", None) is EventKind.COMPACTION_FALLBACK for e in events
    )


@pytest.mark.asyncio
async def test_compaction_manager_reraises_when_strategy_is_summarize_only(
    tmp_path: Path,
) -> None:
    async def _failing_compactor(*_: object, **__: object) -> str:
        raise RuntimeError("LLM unavailable")

    manager = CompactionManager(
        _failing_compactor, SessionManager(tmp_path), _make_settings("summarize")
    )
    history = [_text_msg("user", "a"), _text_msg("assistant", "b")]
    queue: asyncio.Queue = asyncio.Queue()
    deps = _fake_deps()

    with pytest.raises(RuntimeError, match="LLM unavailable"):
        await manager.run(history, "test", queue, deps)


def test_sliding_window_turn_pair_boundary_respected() -> None:
    pairs = [
        (_text_msg("user", f"u{i}"), _text_msg("assistant", f"a{i}")) for i in range(5)
    ]
    history = [msg for p in pairs for msg in p]

    result = sliding_window_fallback(history, budget_tokens=0, pinned_turns=1)

    for i in range(0, len(result) - 1, 2):
        assert getattr(result[i], "role", None) == "user"
        assert getattr(result[i + 1], "role", None) == "assistant"


# ── compact() integration — sliding window ───────────────────────────────────


@pytest.mark.asyncio
async def test_compact_fallback_on_llm_failure_emits_event(tmp_path: Path) -> None:
    async def _failing(*_: object) -> str:
        raise RuntimeError("LLM unavailable")

    agent = _make_agent(tmp_path, compactor=_failing)
    agent.history = [_text_msg("user", "task"), _text_msg("assistant", "ok")]

    events = [e async for e in agent.compact("test")]
    kinds = [e.kind for e in events]

    assert EventKind.COMPACTION_FALLBACK in kinds
    assert EventKind.COMPACTED in kinds


@pytest.mark.asyncio
async def test_compact_sliding_window_strategy_skips_llm(tmp_path: Path) -> None:
    called: list[bool] = []

    async def _tracking(*_: object) -> str:
        called.append(True)
        return "summary"

    settings = Settings(
        model="test:model",
        compaction_strategy="sliding_window",
    )

    from kiss.agent.loop import KissAgent

    agent = KissAgent(settings, _tracking, sessions_dir=tmp_path)
    agent.history = [_text_msg("user", "task"), _text_msg("assistant", "ok")]

    [_ async for _ in agent.compact("test")]

    assert called == []


# ── restore_session ───────────────────────────────────────────────────────────


def test_restore_session_returns_none_without_snapshot(tmp_path: Path) -> None:
    agent = _make_agent(tmp_path)
    assert agent.restore_session() is None


def test_restore_session_loads_history(tmp_path: Path) -> None:
    agent = _make_agent(tmp_path)
    messages = [
        {"role": "user", "content": "hi"},
        {"role": "assistant", "content": "hello"},
    ]
    agent.session_manager.export_snapshot(
        messages, "uuid-restore", "2024-01-01T00:00:00"
    )

    ts = agent.restore_session()
    assert ts == "2024-01-01T00:00:00"
    assert len(agent.history) == 2
    assert agent._turn_phase is TurnPhase.RESEARCH


def test_restore_session_resets_turns_since_compact(tmp_path: Path) -> None:
    agent = _make_agent(tmp_path)
    agent._turns_since_compact = 99
    messages = [{"role": "user", "content": "x"}, {"role": "assistant", "content": "y"}]
    agent.session_manager.export_snapshot(messages, "uid", "ts")

    agent.restore_session()
    assert agent._turns_since_compact == 0


def test_restore_session_loads_phase(tmp_path: Path) -> None:
    agent = _make_agent(tmp_path)
    messages = [{"role": "user", "content": "x"}, {"role": "assistant", "content": "y"}]
    agent.session_manager.export_snapshot(
        messages,
        "uid-phase",
        "ts",
        phase=TurnPhase.PLANNING,
    )

    agent.restore_session()
    assert agent._turn_phase is TurnPhase.PLANNING


# ── Snapshot v2 with Todos ────────────────────────────────────────────────────


def test_snapshot_v2_export_with_todos(tmp_path: Path) -> None:
    """Test exporting snapshot v2 with todos."""
    sm = SessionManager(tmp_path)
    messages = [
        {"role": "user", "content": "hello"},
        {"role": "assistant", "content": "hi"},
    ]
    todos = [
        {"text": "task 1", "done": False},
        {"text": "task 2", "done": True},
    ]

    ok = sm.export_snapshot(messages, "uuid-v2", "2024-01-01T00:00:00", todos=todos)
    assert ok

    result = sm.restore_snapshot()
    assert result is not None
    restored, ts, restored_todos, _team_msgs, _last_tool, phase = result
    assert ts == "2024-01-01T00:00:00"
    assert restored == messages
    assert restored_todos == todos
    assert phase is TurnPhase.RESEARCH


def test_snapshot_v2_restore_handles_malformed_todos(tmp_path: Path) -> None:
    """Test that v2 snapshots gracefully handle malformed todos."""
    sm = SessionManager(tmp_path)
    messages = [{"role": "user", "content": "hi"}]

    # Export with invalid todos structure
    snapshot_path = tmp_path / "export_uuid-bad.json"
    data = {
        "version": 2,
        "uuid": "uuid-bad",
        "ts": "2024-01-01T00:00:00",
        "messages": messages,
        "todos": "not a list",  # Invalid: should be list
    }
    snapshot_path.write_text(json.dumps(data))

    result = sm.restore_snapshot()
    assert result is not None
    _, _, todos, _, _, phase = result
    # Should return empty todos when malformed
    assert todos == []
    assert phase is TurnPhase.RESEARCH


def test_snapshot_v1_backwards_compat(tmp_path: Path) -> None:
    """Test that v1 snapshots (no version field) are backwards compatible."""
    sm = SessionManager(tmp_path)
    messages = [{"role": "user", "content": "old"}]

    # Manually write a v1 snapshot (no version, no todos)
    snapshot_path = tmp_path / "export_uuid-v1.json"
    data = {
        "uuid": "uuid-v1",
        "ts": "2024-01-01T00:00:00",
        "messages": messages,
    }
    snapshot_path.write_text(json.dumps(data))

    result = sm.restore_snapshot()
    assert result is not None
    restored, ts, todos, _, _, phase = result
    assert ts == "2024-01-01T00:00:00"
    assert restored == messages
    assert todos == []  # v1 snapshots have no todos
    assert phase is TurnPhase.RESEARCH


def test_snapshot_v4_backwards_compat_defaults_phase(tmp_path: Path) -> None:
    sm = SessionManager(tmp_path)
    messages = [{"role": "user", "content": "old"}]
    snapshot_path = tmp_path / "export_uuid-v4.json"
    data = {
        "version": 4,
        "uuid": "uuid-v4",
        "ts": "2024-01-01T00:00:00",
        "messages": messages,
        "todos": [],
        "team_messages": [],
        "last_tool": "read_file",
    }
    snapshot_path.write_text(json.dumps(data))

    result = sm.restore_snapshot()
    assert result is not None
    restored, ts, todos, team_messages, last_tool, phase = result
    assert restored == messages
    assert ts == "2024-01-01T00:00:00"
    assert todos == []
    assert team_messages == []
    assert last_tool == "read_file"
    assert phase is TurnPhase.RESEARCH


def test_list_sessions_newest_first(tmp_path: Path) -> None:
    sm = SessionManager(tmp_path)
    messages = [{"role": "user", "content": "hi"}]
    sm.export_snapshot(messages, "uuid-old", "2024-01-01T00:00:00")
    sm.export_snapshot(messages, "uuid-new", "2024-06-01T00:00:00")
    sessions = sm.list_sessions()
    assert len(sessions) == 2
    assert sessions[0]["uuid"] == "uuid-new"
    assert sessions[1]["uuid"] == "uuid-old"
    assert sessions[0]["ts"] == "2024-06-01T00:00:00"
    for s in sessions:
        assert "uuid" in s and "ts" in s and "path" in s


def test_list_sessions_empty_dir(tmp_path: Path) -> None:
    sm = SessionManager(tmp_path)
    assert sm.list_sessions() == []


def test_restore_snapshot_by_uuid(tmp_path: Path) -> None:
    sm = SessionManager(tmp_path)
    msgs_a = [{"role": "user", "content": "session A"}]
    msgs_b = [{"role": "user", "content": "session B"}]
    sm.export_snapshot(msgs_a, "uuid-aaa", "2024-01-01T00:00:00")
    sm.export_snapshot(msgs_b, "uuid-bbb", "2024-06-01T00:00:00")

    result = sm.restore_snapshot(uuid="uuid-aaa")
    assert result is not None
    restored, ts, _, _, _, phase = result
    assert restored == msgs_a
    assert ts == "2024-01-01T00:00:00"
    assert phase is TurnPhase.RESEARCH


def test_restore_snapshot_nonexistent_uuid_returns_none(tmp_path: Path) -> None:
    sm = SessionManager(tmp_path)
    messages = [{"role": "user", "content": "hi"}]
    sm.export_snapshot(messages, "uuid-exists", "2024-01-01T00:00:00")
    assert sm.restore_snapshot(uuid="uuid-does-not-exist") is None


def test_restore_snapshot_uuid_none_returns_latest(tmp_path: Path) -> None:
    sm = SessionManager(tmp_path)
    msgs_old = [{"role": "user", "content": "old"}]
    msgs_new = [{"role": "user", "content": "new"}]
    sm.export_snapshot(msgs_old, "uuid-old", "2024-01-01T00:00:00")
    sm.export_snapshot(msgs_new, "uuid-new", "2024-06-01T00:00:00")
    result = sm.restore_snapshot(uuid=None)
    assert result is not None
    restored, _, _, _, _, phase = result
    assert restored == msgs_new
    assert phase is TurnPhase.RESEARCH


def test_restore_session_loads_todos(tmp_path: Path) -> None:
    """Test that restore_session loads todos from snapshot."""
    agent = _make_agent(tmp_path)
    messages = [
        {"role": "user", "content": "hi"},
        {"role": "assistant", "content": "hello"},
    ]
    todos = [
        {"text": "follow up", "done": False},
        {"text": "document", "done": True},
    ]
    agent.session_manager.export_snapshot(
        messages, "uuid-todos", "2024-01-01T00:00:00", todos=todos
    )

    ts = agent.restore_session()
    assert ts == "2024-01-01T00:00:00"
    assert len(agent.todos) == 2
    assert agent.todos[0].text == "follow up"
    assert agent.todos[0].done is False
    assert agent.todos[1].text == "document"
    assert agent.todos[1].done is True


def test_clear_history_resets_turn_phase(tmp_path: Path) -> None:
    agent = _make_agent(tmp_path)
    agent._turn_phase = TurnPhase.EXECUTION

    agent.clear_history()

    assert agent._turn_phase is TurnPhase.RESEARCH


def test_switch_model_resets_turn_phase(tmp_path: Path) -> None:
    settings = Settings(model="openai:gpt-4.1")
    agent = KissAgent(settings, _summary_compactor, sessions_dir=tmp_path)
    agent._turn_phase = TurnPhase.EXECUTION

    agent.switch_model("openai:gpt-4.1")

    assert agent._turn_phase is TurnPhase.RESEARCH
