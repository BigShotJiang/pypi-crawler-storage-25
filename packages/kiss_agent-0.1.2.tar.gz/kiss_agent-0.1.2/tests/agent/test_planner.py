from __future__ import annotations

import inspect

from kiss.agent import planner


def test_planner_uses_sync_prompt_loader() -> None:
    assert not inspect.iscoroutinefunction(planner.prompt_load)


def test_planner_load_prompt_returns_string() -> None:
    prompt = planner.Planner.__new__(planner.Planner)._load_prompt()

    assert isinstance(prompt, str)
    assert prompt
