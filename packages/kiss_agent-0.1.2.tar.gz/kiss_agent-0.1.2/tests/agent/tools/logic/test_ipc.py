import asyncio
import socket
import pytest
from kiss.agent.tools.logic.ipc import _LineSocket


@pytest.mark.asyncio
async def test_line_socket_read_write():
    # Create a socket pair
    rsock, wsock = socket.socketpair()
    rsock.setblocking(False)
    wsock.setblocking(False)

    linesock_read = _LineSocket(rsock)
    linesock_write = _LineSocket(wsock)

    try:
        # Test write/read
        await linesock_write.write_line(b"hello\n")
        line = await linesock_read.read_line()
        assert line == b"hello\n"

        # Test partial read/buffer
        await linesock_write.write_line(b"part")
        # Give it a moment to send
        await asyncio.sleep(0.01)
        await linesock_write.write_line(b"ial\n")
        line = await linesock_read.read_line()
        assert line == b"partial\n"
    finally:
        linesock_read.close()
        linesock_write.close()
