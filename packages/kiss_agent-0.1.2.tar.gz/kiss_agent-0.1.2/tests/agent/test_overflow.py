from __future__ import annotations

from mirascope.llm.exceptions import BadRequestError, RateLimitError

from kiss.agent.overflow import classify_context_overflow_error


def test_classify_context_overflow_from_bad_request_message() -> None:
    error = BadRequestError(
        "This model's maximum context length is 8192 tokens.",
        provider="openai",
        status_code=400,
    )

    classification = classify_context_overflow_error(error)

    assert classification.is_overflow is True
    assert classification.provider_error_type == "BadRequestError"
    assert classification.status_code == 400
    assert classification.matched_reason == "status_code:400+message"
    assert classify_context_overflow_error(error).is_overflow is True


def test_classify_context_overflow_from_status_413() -> None:
    error = BadRequestError(
        "Request entity too large.",
        provider="anthropic",
        status_code=413,
    )

    classification = classify_context_overflow_error(error)

    assert classification.is_overflow is True
    assert classification.provider_error_type == "BadRequestError"
    assert classification.status_code == 413
    assert classification.matched_reason == "status_code:413"


def test_classify_context_overflow_rejects_unrelated_bad_request() -> None:
    error = BadRequestError(
        "Invalid JSON schema.",
        provider="openai",
        status_code=400,
    )

    classification = classify_context_overflow_error(error)

    assert classification.is_overflow is False
    assert classification.provider_error_type == "BadRequestError"
    assert classification.status_code == 400
    assert classify_context_overflow_error(error).is_overflow is False


def test_classify_context_overflow_follows_exception_chain() -> None:
    inner = BadRequestError(
        "Your prompt exceeds the maximum context length.",
        provider="openai",
        status_code=400,
    )
    outer = RateLimitError("wrapped failure", provider="openai", status_code=429)
    outer.__cause__ = inner

    classification = classify_context_overflow_error(outer)

    assert classification.is_overflow is True
    assert classification.provider_error_type == "BadRequestError"
    assert classification.status_code == 400
