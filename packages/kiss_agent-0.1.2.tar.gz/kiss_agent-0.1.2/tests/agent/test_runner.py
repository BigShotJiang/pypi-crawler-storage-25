from __future__ import annotations

import pytest

from mirascope import llm

from mirascope.llm.exceptions import ToolNotFoundError

from kiss.agent.runner import _handle_tool_outputs
from kiss.agent.runner import _COMPACT_SYSTEM
from kiss.core.errors import StuckLoopError
from kiss.core.deps import AgentDeps


class _ToolOutput:
    name: str
    result: object
    id: str
    error: object | None

    def __init__(self, name: str, result: str, call_id: str = "1", error=None) -> None:
        self.name = name
        self.result = result
        self.id = call_id
        self.error = error


@pytest.mark.asyncio
async def test_handle_tool_outputs_uses_truncated_model_and_ui_payloads() -> None:
    events: list[tuple[str, str]] = []

    async def on_tool_result(
        name: str, output: str, call_id: str, is_err: bool
    ) -> None:
        events.append((name, output))

    deps = AgentDeps(
        context_window=20_000,
        current_usage_tokens=18_500,
        tool_output_safety_buffer=1_000,
        tool_output_max_tokens=500,
        tool_output_min_tokens=100,
        on_tool_result=on_tool_result,
    )
    ctx = llm.Context(deps=deps)
    raw = "\n".join(f"line {i}: {'x' * 60}" for i in range(400))
    tool_output = _ToolOutput("run_bash", raw)

    await _handle_tool_outputs([tool_output], ctx)

    assert tool_output.result != raw
    assert isinstance(tool_output.result, str)
    result_text = tool_output.result
    assert events
    assert len(events[0][1]) >= len(result_text)


def test_compact_system_prompt_uses_runtime_state_language() -> None:
    assert "current goal" in _COMPACT_SYSTEM
    assert "recent tool results" in _COMPACT_SYSTEM
    assert "pleasantries" in _COMPACT_SYSTEM
    assert "external" not in _COMPACT_SYSTEM.lower()


@pytest.mark.asyncio
async def test_handle_tool_outputs_emits_stuck_loop_warning() -> None:
    events: list[tuple[str, str]] = []
    stuck_loop_events: list[tuple[str, str]] = []

    async def on_tool_result(
        name: str, output: str, call_id: str, is_err: bool
    ) -> None:
        events.append((name, output))

    async def on_stuck_loop(message: str, severity: str) -> None:
        stuck_loop_events.append((severity, message))

    deps = AgentDeps(on_tool_result=on_tool_result, on_stuck_loop=on_stuck_loop)
    for _ in range(3):
        deps.stuck_loop_tracker.register_tool_call("run_bash", {"command": "pwd"})
    ctx = llm.Context(deps=deps)

    outputs = [
        _ToolOutput("run_bash", "first", "1"),
        _ToolOutput("run_bash", "second", "2"),
        _ToolOutput("run_bash", "third", "3"),
    ]
    await _handle_tool_outputs(outputs, ctx)

    assert stuck_loop_events == [
        (
            "warn",
            "[LOOP DETECTED] You have called run_bash with identical arguments 3 times. Try a different approach.",
        )
    ]
    # Loop warnings are deduplicated: only the STUCK_LOOP event prints to UI,
    # the synthetic tool result is suppressed from on_tool_result.
    assert len(events) == 2
    assert isinstance(outputs[-1].result, str)
    assert outputs[-1].result.startswith("WARNING: [LOOP DETECTED]")


@pytest.mark.asyncio
async def test_handle_tool_outputs_aborts_on_stuck_loop() -> None:
    stuck_loop_events: list[tuple[str, str]] = []

    async def on_stuck_loop(message: str, severity: str) -> None:
        stuck_loop_events.append((severity, message))

    deps = AgentDeps(on_stuck_loop=on_stuck_loop)
    for _ in range(5):
        deps.stuck_loop_tracker.register_tool_call("run_bash", {"command": "pwd"})
    ctx = llm.Context(deps=deps)

    outputs = [_ToolOutput("run_bash", f"result {idx}", str(idx)) for idx in range(5)]
    with pytest.raises(StuckLoopError, match="identical arguments 5 times"):
        await _handle_tool_outputs(outputs, ctx)

    assert stuck_loop_events[-1][0] == "error"


# === Fuzzy tool resolver tests ===


@pytest.mark.asyncio
async def test_tool_not_found_enriched_with_close_match() -> None:
    # "write_fil" is a near-typo of "write_file" with ratio ~0.95 (above 0.9 cutoff)
    deps = AgentDeps()
    ctx = llm.Context(deps=deps)
    to = _ToolOutput(
        "write_fil",
        "Tool 'write_fil' not found in registered tools",
        error=ToolNotFoundError("write_fil"),
    )
    known = ["bash", "read_file", "write_file"]
    await _handle_tool_outputs([to], ctx, known_tool_names=known)
    assert isinstance(to.result, str)
    assert "write_file" in to.result
    assert "Did you mean" in to.result


@pytest.mark.asyncio
async def test_tool_not_found_no_match_lists_available_tools() -> None:
    deps = AgentDeps()
    ctx = llm.Context(deps=deps)
    to = _ToolOutput(
        "zzz_unknown",
        "Tool 'zzz_unknown' not found in registered tools",
        error=ToolNotFoundError("zzz_unknown"),
    )
    known = ["bash", "read_file"]
    await _handle_tool_outputs([to], ctx, known_tool_names=known)
    assert isinstance(to.result, str)
    assert "bash" in to.result
    assert "read_file" in to.result


@pytest.mark.asyncio
async def test_tool_not_found_no_known_names_result_unchanged() -> None:
    deps = AgentDeps()
    ctx = llm.Context(deps=deps)
    original = "Tool 'bad_tool' not found in registered tools"
    to = _ToolOutput("bad_tool", original, error=ToolNotFoundError("bad_tool"))
    await _handle_tool_outputs([to], ctx, known_tool_names=None)
    # result may be processed by prepare_tool_output but should not have suggestion
    assert "Did you mean" not in str(to.result)
    assert "Available tools" not in str(to.result)
