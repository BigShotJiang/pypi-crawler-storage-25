"""Tests for agent permission policy."""

from __future__ import annotations

from pathlib import Path

from kiss.agent.permissions import (
    file_write_action,
    filter_tools_for_role,
    git_write_action,
    shell_command_action,
    tool_access_action,
)
from kiss.core.permission_policy import PermissionPolicy, RolePermissionPolicy


def test_workspace_file_write_can_use_workspace_scope(tmp_path, monkeypatch) -> None:
    monkeypatch.chdir(tmp_path)

    action = file_write_action("write_file", "src/app.py", tmp_path)

    assert action.tool_name == "write_file"
    assert action.exact_only is False
    assert action.scope_key == "file_write:workspace"
    assert action.exact_key == f"file_write:write_file:{tmp_path / 'src' / 'app.py'}"


def test_sensitive_file_write_requires_exact_approval(tmp_path, monkeypatch) -> None:
    monkeypatch.chdir(tmp_path)

    action = file_write_action("edit_file", ".env", tmp_path)

    assert action.exact_only is True
    assert action.scope_key is None


def test_outside_workspace_file_write_requires_exact_approval(
    tmp_path, monkeypatch
) -> None:
    monkeypatch.chdir(tmp_path)
    outside = tmp_path.parent / "outside.txt"

    action = file_write_action("write_file", str(outside), tmp_path)

    assert action.exact_only is True
    assert action.scope_key is None


def test_generated_dir_file_write_requires_exact_approval(
    tmp_path: Path, monkeypatch
) -> None:
    monkeypatch.chdir(tmp_path)

    action = file_write_action("write_file", "dist/bundle.js", tmp_path)

    assert action.exact_only is True
    assert action.scope_key is None


def test_repeated_safe_shell_command_can_use_executable_scope() -> None:
    action = shell_command_action("uv run pytest")

    assert action.tool_name == "run_bash"
    assert action.exact_only is False
    assert action.scope_key == "shell_command:uv"
    assert action.exact_key == "shell_command:uv run pytest"


def test_mutating_shell_command_requires_exact_approval() -> None:
    action = shell_command_action("git reset --hard")

    assert action.exact_only is True
    assert action.scope_key is None


def test_shell_parse_error_requires_exact_approval() -> None:
    action = shell_command_action("echo 'unterminated")

    assert action.exact_only is True
    assert action.scope_key is None


def test_git_write_requires_exact_approval(tmp_path: Path) -> None:
    action = git_write_action("git_commit", str(tmp_path))

    assert action.tool_name == "git_commit"
    assert action.exact_only is True
    assert action.scope_key is None
    assert action.exact_key == f"git_write:git_commit:{tmp_path.resolve()}"


def test_tool_access_action_defaults_to_auto_allow() -> None:
    action = tool_access_action("web_search", "query text")

    assert action.tool_name == "web_search"
    assert action.kind == "tool_access"
    assert action.default_allow is True
    assert action.scope_key == "tool_access:web_search"


def test_filter_tools_for_role_applies_runtime_policy() -> None:
    async def allowed_tool() -> None:
        return None

    async def denied_tool() -> None:
        return None

    allowed_tool.__name__ = "web_search"
    denied_tool.__name__ = "write_file"

    policy = PermissionPolicy(
        roles={
            "researcher": RolePermissionPolicy(
                allow_tools=["web_*"], deny_tools=["write_file"]
            )
        }
    )

    filtered = filter_tools_for_role(
        [allowed_tool, denied_tool],
        role="researcher",
        policy=policy,
    )

    assert [tool.__name__ for tool in filtered] == ["web_search"]
