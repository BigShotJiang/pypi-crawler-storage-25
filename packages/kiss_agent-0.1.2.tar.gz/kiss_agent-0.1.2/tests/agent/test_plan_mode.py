from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest
from mirascope import llm

from kiss.agent.loop import KissAgent
from kiss.agent.plan_types import (
    CompletionResult,
    Plan,
    PlanResult,
    PlanExecutionState,
    WriteBlockedResult,
)
from kiss.agent.runner import _handle_tool_outputs
from kiss.agent.tools.gate import write_gated
from kiss.agent.tools.logic.approval import LogicApprovalRequest
from kiss.core.deps import AgentDeps
from kiss.core.settings import Settings
from kiss.core.types import AskUserReply, EventKind


class SimpleMessage:
    def __init__(self, role: str, content: str) -> None:
        self.role = role
        self.content = content

    def __str__(self) -> str:
        return self.content


class SimpleToolOutput:
    def __init__(self, name: str, result: object) -> None:
        self.name = name
        self.result = result
        self.id = "tool-1"
        self.error = None


async def _unused_compactor(history: list[object], deps: object) -> str:
    raise AssertionError("compactor should not run")


def _settings() -> Settings:
    return Settings(model="test:model", context_window=20_000)


@pytest.mark.asyncio
async def test_write_gated_blocks_until_writes_are_approved(tmp_path: Path) -> None:
    async def write_file(
        ctx: llm.Context[AgentDeps],
        path: str,
        content: str,
    ) -> str:
        return f"wrote {path}: {content}"

    gated = write_gated(write_file)
    deps = AgentDeps(workspace_root=tmp_path)
    ctx = llm.Context(deps=deps)

    blocked = await gated(ctx, "note.txt", "alpha")

    assert isinstance(blocked, WriteBlockedResult)
    assert blocked.tool_name == "write_file"
    assert blocked.args == {"path": "note.txt", "content": "alpha"}

    deps.writes_approved = True
    allowed = await gated(ctx, "note.txt", "beta")
    assert allowed == "wrote note.txt: beta"


@pytest.mark.asyncio
async def test_handle_tool_outputs_marks_turn_awaiting_approval() -> None:
    deps = AgentDeps()
    ctx = llm.Context(deps=deps)
    blocked = WriteBlockedResult("write_file", {"path": "out.py", "content": "x"})

    await _handle_tool_outputs([SimpleToolOutput("write_file", blocked)], ctx)

    assert deps.plan_state is PlanExecutionState.AWAITING_APPROVAL
    assert deps._blocked_calls == [blocked]


class PlanThenCompletePlanner:
    def __init__(self) -> None:
        self.calls = 0

    async def run(
        self,
        deps: AgentDeps,
        history: list[object],
        on_chunk: object,
        agent_label: str,
    ) -> PlanResult | CompletionResult:
        self.calls += 1
        if self.calls == 1:
            return PlanResult(
                plan=Plan(
                    plan_id="plan-1",
                    plan_hash="hash-1",
                    timestamp=0.0,
                    reasoning="Need approval before writing the file.",
                    tool_calls=[
                        {
                            "tool_name": "write_file",
                            "args": {"path": "out.py", "content": "x = 1\n"},
                            "reason": "plan_mode",
                        }
                    ],
                    estimated_impact="1 blocked operation affecting out.py",
                ),
                blocked_calls=[
                    WriteBlockedResult(
                        "write_file", {"path": "out.py", "content": "x = 1\n"}
                    )
                ],
                messages=[SimpleMessage("assistant", "plan pending")],
            )
        assert deps.writes_approved is True
        assert any(
            "User approved. Proceed with execution." in str(message)
            for message in history
        )
        return CompletionResult(
            text="done",
            messages=[SimpleMessage("assistant", "done")],
            usage=None,
            finish_reason=None,
        )


class _ToolCallMessage(SimpleMessage):
    def __init__(self, content: str) -> None:
        super().__init__("assistant", content)
        self.tool_calls = [{"id": "call-1", "function": {"name": "write_file"}}]


class PlanWithToolCallHistoryThenCompletePlanner:
    def __init__(self) -> None:
        self.calls = 0
        self.second_history: list[object] = []

    async def run(
        self,
        deps: AgentDeps,
        history: list[object],
        on_chunk: object,
        agent_label: str,
    ) -> PlanResult | CompletionResult:
        self.calls += 1
        if self.calls == 1:
            return PlanResult(
                plan=Plan(
                    plan_id="plan-2",
                    plan_hash="hash-2",
                    timestamp=0.0,
                    reasoning="Need approval before writing the file.",
                    tool_calls=[
                        {
                            "tool_name": "write_file",
                            "args": {"path": "out.py", "content": "x = 1\n"},
                            "reason": "plan_mode",
                        }
                    ],
                    estimated_impact="1 blocked operation affecting out.py",
                ),
                blocked_calls=[
                    WriteBlockedResult(
                        "write_file", {"path": "out.py", "content": "x = 1\n"}
                    )
                ],
                messages=[_ToolCallMessage("assistant tool call turn")],
            )
        self.second_history = history
        return CompletionResult(
            text="done",
            messages=[SimpleMessage("assistant", "done")],
            usage=None,
            finish_reason=None,
        )


@pytest.mark.asyncio
async def test_send_replays_turn_after_one_time_plan_approval() -> None:
    planner = PlanThenCompletePlanner()
    agent = KissAgent(
        _settings(),
        _unused_compactor,
        turn_engine_factory=lambda **_: planner,
    )

    events: list[Any] = []
    async for event in agent.send("write out.py"):
        events.append(event)
        if event.kind is EventKind.ASK_USER:
            assert event.ask_user is not None
            event.ask_user.reply_future.set_result(
                AskUserReply(
                    outcome="selected",
                    selected_choice_ids=["approve_once"],
                )
            )

    assert planner.calls == 2
    assert any(event.kind is EventKind.ASK_USER for event in events)
    assert any(event.kind is EventKind.DONE for event in events)
    assert len(agent.history) == 1
    assert str(agent.history[0]) == "done"


@pytest.mark.asyncio
async def test_send_replay_does_not_reuse_plan_history_with_tool_calls() -> None:
    planner = PlanWithToolCallHistoryThenCompletePlanner()
    agent = KissAgent(
        _settings(),
        _unused_compactor,
        turn_engine_factory=lambda **_: planner,
    )

    async for event in agent.send("write out.py"):
        if event.kind is EventKind.ASK_USER:
            assert event.ask_user is not None
            event.ask_user.reply_future.set_result(
                AskUserReply(
                    outcome="selected",
                    selected_choice_ids=["approve_once"],
                )
            )

    assert planner.calls == 2
    assert all(
        "assistant tool call turn" not in str(msg) for msg in planner.second_history
    )


def test_run_headless_prints_plan_and_exits_when_approval_is_required(
    capsys: pytest.CaptureFixture[str],
) -> None:
    planner = PlanThenCompletePlanner()
    agent = KissAgent(
        _settings(),
        _unused_compactor,
        turn_engine_factory=lambda **_: planner,
    )

    with pytest.raises(SystemExit) as exc:
        agent.run_headless("write out.py", allow_destructive=False)

    captured = capsys.readouterr()
    assert exc.value.code == 1
    assert "Plan pending approval" in captured.err
    assert "Approval required in non-interactive mode." in captured.err


class AlwaysPlanPlanner:
    def __init__(self) -> None:
        self.calls = 0

    async def run(
        self,
        deps: AgentDeps,
        history: list[object],
        on_chunk: object,
        agent_label: str,
    ) -> PlanResult | CompletionResult:
        self.calls += 1
        return PlanResult(
            plan=Plan(
                plan_id="plan-1",
                plan_hash="hash-1",
                timestamp=0.0,
                reasoning="Always plans.",
                tool_calls=[
                    {
                        "tool_name": "write_file",
                        "args": {"path": "out.py", "content": "x = 1\n"},
                        "reason": "plan_mode",
                    }
                ],
                estimated_impact="1 blocked operation affecting out.py",
            ),
            blocked_calls=[
                WriteBlockedResult(
                    "write_file", {"path": "out.py", "content": "x = 1\n"}
                )
            ],
            messages=[SimpleMessage("assistant", "plan pending")],
        )


@pytest.mark.asyncio
async def test_plan_approval_cycle_limit_raises_error() -> None:
    """Repeated denials must not loop forever — error after _MAX_PLAN_APPROVAL_CYCLES."""
    from kiss.agent.turn_orchestrator import _MAX_PLAN_APPROVAL_CYCLES

    planner = AlwaysPlanPlanner()
    agent = KissAgent(
        _settings(),
        _unused_compactor,
        turn_engine_factory=lambda **_: planner,
    )

    events: list[Any] = []
    async for event in agent.send("write out.py"):
        events.append(event)
        if event.kind is EventKind.ASK_USER:
            assert event.ask_user is not None
            event.ask_user.reply_future.set_result(
                AskUserReply(outcome="selected", selected_choice_ids=["deny"])
            )

    error_events = [e for e in events if e.kind is EventKind.ERROR]
    assert len(error_events) == 1
    assert "Plan approval loop exceeded" in str(error_events[0].error)
    # 1 initial call + 1 per denial before the limit check fires
    assert planner.calls == _MAX_PLAN_APPROVAL_CYCLES + 1


class LogicApprovalPlanner:
    async def run(
        self,
        deps: AgentDeps,
        history: list[object],
        on_chunk: object,
        agent_label: str,
    ) -> CompletionResult:
        if deps.on_logic_approval is None:
            raise AssertionError("logic approval callback should be configured")
        reply = await deps.on_logic_approval(LogicApprovalRequest(pending_changes=[]))
        assert reply.approved is True
        return CompletionResult(
            text="logic applied",
            messages=[SimpleMessage("assistant", "logic applied")],
            usage=None,
            finish_reason=None,
        )


class _RaisingOnReplayPlanner:
    """Returns a plan on first call, raises on the approved replay."""

    def __init__(self) -> None:
        self.calls = 0

    async def run(
        self,
        deps: AgentDeps,
        history: list[object],
        on_chunk: object,
        agent_label: str,
    ) -> PlanResult | CompletionResult:
        self.calls += 1
        if self.calls == 1:
            return PlanResult(
                plan=Plan(
                    plan_id="plan-raise",
                    plan_hash="hash-raise",
                    timestamp=0.0,
                    reasoning="Need approval.",
                    tool_calls=[
                        {
                            "tool_name": "write_file",
                            "args": {"path": "out.py", "content": "x = 1\n"},
                            "reason": "plan_mode",
                        }
                    ],
                    estimated_impact="1 blocked operation",
                ),
                blocked_calls=[
                    WriteBlockedResult(
                        "write_file", {"path": "out.py", "content": "x = 1\n"}
                    )
                ],
                messages=[SimpleMessage("assistant", "plan pending")],
            )
        raise RuntimeError("engine boom on replay")


@pytest.mark.asyncio
async def test_plan_approval_engine_raise_restores_history() -> None:
    """Regression for BUG-01/02: engine raise during approved replay must restore history."""
    planner = _RaisingOnReplayPlanner()
    original_msg = SimpleMessage("user", "original")
    agent = KissAgent(
        _settings(),
        _unused_compactor,
        turn_engine_factory=lambda **_: planner,
    )
    agent.history = [original_msg]

    events: list[Any] = []
    async for event in agent.send("write out.py"):
        events.append(event)
        if event.kind is EventKind.ASK_USER:
            assert event.ask_user is not None
            event.ask_user.reply_future.set_result(
                AskUserReply(outcome="selected", selected_choice_ids=["approve_once"])
            )

    # After the raise, the assistant replay message must NOT be in history (BUG-01/02 regression)
    history_texts = [str(m) for m in agent.history]
    assert not any("User approved. Proceed with execution." in t for t in history_texts)
    assert any(e.kind is EventKind.ERROR for e in events)


def test_run_headless_auto_approves_logic_manifest_when_destructive(
    capsys: pytest.CaptureFixture[str],
) -> None:
    agent = KissAgent(
        _settings(),
        _unused_compactor,
        turn_engine_factory=lambda **_: LogicApprovalPlanner(),
    )

    agent.run_headless("apply logic changes", allow_destructive=True)

    captured = capsys.readouterr()
    assert captured.out.strip() == "logic applied"
