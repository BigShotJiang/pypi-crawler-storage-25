from __future__ import annotations

import pytest

from kiss.agent.phases import PhaseManager
from kiss.agent.plan_types import TurnPhase
from kiss.core.types import AskUserReply, AskUserRequest, Event, EventKind


@pytest.mark.asyncio
async def test_phase_manager_explicit_slash_command_is_authoritative() -> None:
    manager = PhaseManager()

    result = await manager.resolve(
        message="/plan implement the fix",
        current_phase=TurnPhase.RESEARCH,
        headless=False,
        on_ask_user=None,
        on_event=None,
    )

    assert result.explicit is True
    assert result.phase is TurnPhase.PLANNING
    assert result.phase_changed is True
    assert result.cleaned_message == "implement the fix"
    assert result.control_only_confirmation is None


@pytest.mark.asyncio
async def test_phase_manager_approves_research_to_planning() -> None:
    manager = PhaseManager()
    requests: list[AskUserRequest] = []

    async def on_ask_user(req: AskUserRequest) -> AskUserReply:
        requests.append(req)
        return AskUserReply(outcome="selected", selected_choice_ids=["proceed"])

    result = await manager.resolve(
        message="Implement the feature",
        current_phase=TurnPhase.RESEARCH,
        headless=False,
        on_ask_user=on_ask_user,
        on_event=None,
    )

    assert result.phase is TurnPhase.PLANNING
    assert result.phase_changed is True
    assert len(requests) == 1
    assert [o.id for o in requests[0].options] == ["proceed", "stay"]
    assert requests[0].type == "choice"
    assert requests[0].default_id == "stay"
    assert "Current phase: RESEARCH" in requests[0].question
    assert "Requested phase: PLANNING" in requests[0].question


@pytest.mark.asyncio
async def test_phase_manager_rejection_debounces_until_slash_reset() -> None:
    manager = PhaseManager()
    prompt_count = 0
    events: list[Event] = []

    async def on_ask_user(req: AskUserRequest) -> AskUserReply:
        nonlocal prompt_count
        prompt_count += 1
        return AskUserReply(outcome="selected", selected_choice_ids=["stay"])

    async def on_event(event: Event) -> None:
        events.append(event)

    first = await manager.resolve(
        message="Implement the feature",
        current_phase=TurnPhase.RESEARCH,
        headless=False,
        on_ask_user=on_ask_user,
        on_event=on_event,
    )
    second = await manager.resolve(
        message="Implement the feature",
        current_phase=TurnPhase.RESEARCH,
        headless=False,
        on_ask_user=on_ask_user,
        on_event=on_event,
    )
    reset = await manager.resolve(
        message="/research",
        current_phase=TurnPhase.RESEARCH,
        headless=False,
        on_ask_user=on_ask_user,
        on_event=on_event,
    )
    third = await manager.resolve(
        message="Implement the feature",
        current_phase=TurnPhase.RESEARCH,
        headless=False,
        on_ask_user=on_ask_user,
        on_event=on_event,
    )

    assert first.phase is TurnPhase.RESEARCH
    assert second.phase is TurnPhase.RESEARCH
    assert reset.explicit is True
    assert third.phase is TurnPhase.RESEARCH
    assert prompt_count == 2
    assert any(
        event.kind is EventKind.INFO and "Phase coaching rejected" in event.info
        for event in events
    )


@pytest.mark.asyncio
async def test_phase_manager_regression_suppressed() -> None:
    # Backward regression coaching is suppressed (ARCH-02); phase stays at current.
    manager = PhaseManager()
    requests: list[AskUserRequest] = []

    async def on_ask_user(req: AskUserRequest) -> AskUserReply:
        requests.append(req)
        return AskUserReply(outcome="selected", selected_choice_ids=["proceed"])

    result = await manager.resolve(
        message="Review the diff for issues",
        current_phase=TurnPhase.PLANNING,
        headless=False,
        on_ask_user=on_ask_user,
        on_event=None,
    )

    assert result.phase is TurnPhase.PLANNING
    assert result.phase_changed is False
    assert len(requests) == 0


@pytest.mark.asyncio
async def test_phase_manager_headless_keeps_current_phase() -> None:
    manager = PhaseManager()
    events: list[Event] = []

    async def on_event(event: Event) -> None:
        events.append(event)

    result = await manager.resolve(
        message="Implement the feature",
        current_phase=TurnPhase.RESEARCH,
        headless=True,
        on_ask_user=None,
        on_event=on_event,
    )

    assert result.phase is TurnPhase.RESEARCH
    assert result.phase_changed is False
    assert any(
        event.kind is EventKind.INFO
        and "Skipped heuristic phase coaching in non-interactive mode" in event.info
        for event in events
    )
