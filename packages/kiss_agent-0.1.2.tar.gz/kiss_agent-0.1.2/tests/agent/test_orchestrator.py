from __future__ import annotations

from pathlib import Path

from kiss.agent.turn_engine import (
    _extract_claimed_paths_from_task,
    _extract_explicit_write_file_request,
    _is_file_write_task,
    _verified_file_write,
)


def test_extract_claimed_paths_from_create_file_task() -> None:
    task = "Create file list_vms_in_datacenter.ps1 with this content:\nWrite-Host 'x'"
    assert _extract_claimed_paths_from_task(task) == ["list_vms_in_datacenter.ps1"]


def test_extract_claimed_paths_from_save_as_task() -> None:
    task = "Save the script locally as List-VMs-In-Datacenter.ps1"
    assert _extract_claimed_paths_from_task(task) == ["List-VMs-In-Datacenter.ps1"]


def test_extract_claimed_paths_from_update_task() -> None:
    task = "Update List-VMs.ps1 so that it takes arguments"
    assert _extract_claimed_paths_from_task(task) == ["List-VMs.ps1"]


def test_extract_claimed_paths_from_replace_contents_task() -> None:
    task = "Replace the contents of List-VMs.ps1 with the following content:\n..."
    assert _extract_claimed_paths_from_task(task) == ["List-VMs.ps1"]


def test_is_file_write_task_detects_save_requests() -> None:
    assert _is_file_write_task("Save script locally as foo.ps1") is True
    assert _is_file_write_task("Explain this module") is False


def test_is_file_write_task_detects_update_requests() -> None:
    assert _is_file_write_task("Update List-VMs.ps1 to take arguments") is True
    assert (
        _is_file_write_task(
            "Replace the contents of List-VMs.ps1 with the following content:\n..."
        )
        is True
    )


def test_verified_file_write_accepts_successful_write_tool() -> None:
    verified, claimed = _verified_file_write(
        "Create file foo.ps1 with this content:\nWrite-Host 'x'",
        ["RESULT write_file OK\npath: /tmp/foo.ps1"],
        Path("/tmp"),
    )
    assert verified is True
    assert claimed == ["foo.ps1"]


def test_verified_file_write_rejects_missing_write_tool_and_missing_file(
    tmp_path: Path,
) -> None:
    verified, claimed = _verified_file_write(
        "Create file foo.ps1 with this content:\nWrite-Host 'x'",
        ["RESULT run_bash OK\nstdout: done"],
        tmp_path,
    )
    assert verified is False
    assert claimed == ["foo.ps1"]


def test_verified_file_write_accepts_shell_when_claimed_file_exists(
    tmp_path: Path,
) -> None:
    (tmp_path / "foo.ps1").write_text("Write-Host 'x'", encoding="utf-8")
    verified, claimed = _verified_file_write(
        "Create file foo.ps1 with this content:\nWrite-Host 'x'",
        ["RESULT run_bash OK\nstdout: done"],
        tmp_path,
        pre_snapshot={},  # empty snapshot: file absent before shell command
    )
    assert verified is True
    assert claimed == ["foo.ps1"]


def test_extract_explicit_write_file_request_parses_create_content() -> None:
    task = "Create file foo.ps1 with this content:\nWrite-Host 'x'\n"
    assert _extract_explicit_write_file_request(task) == (
        "foo.ps1",
        "Write-Host 'x'\n",
    )


def test_extract_explicit_write_file_request_parses_overwrite_content() -> None:
    task = "Overwrite ./foo.ps1 with the following content:\nWrite-Host 'y'\n"
    assert _extract_explicit_write_file_request(task) == (
        "./foo.ps1",
        "Write-Host 'y'\n",
    )


def test_extract_explicit_write_file_request_parses_replace_contents() -> None:
    task = "Replace the contents of ./foo.ps1 with this content:\nWrite-Host 'z'\n"
    assert _extract_explicit_write_file_request(task) == (
        "./foo.ps1",
        "Write-Host 'z'\n",
    )


def test_extract_explicit_write_file_request_returns_none_without_content() -> None:
    assert _extract_explicit_write_file_request("Create file foo.ps1") is None
