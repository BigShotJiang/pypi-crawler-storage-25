"""Tests for kiss.agent.loop."""

from __future__ import annotations

import asyncio
from pathlib import Path
import os
from typing import Awaitable, Callable, Protocol

import pytest
from mirascope.llm.exceptions import BadRequestError

from kiss.agent.loop import KissAgent
from kiss.agent.plan_types import CompletionResult, TurnPhase
from kiss.core.settings import Settings
from kiss.core.types import AskUserReply
from kiss.core.deps import StuckLoopTracker
from kiss.core.types import EventKind


class SimpleMessage:
    def __init__(self, role: str, content: str) -> None:
        self.role = role
        self.content = content

    def __str__(self) -> str:
        return self.content


class _OnToolUse(Protocol):
    async def __call__(self, name: str, args: dict[str, object]) -> None: ...


class _OnToolResult(Protocol):
    async def __call__(
        self, name: str, output: str, call_id: str, is_err: bool
    ) -> None: ...


class _Deps(Protocol):
    on_tool_use: _OnToolUse | None
    on_tool_result: _OnToolResult | None
    compact_requested: str | None
    on_stuck_loop: Callable[[str, str], Awaitable[None]] | None
    stuck_loop_tracker: StuckLoopTracker


class _Ctx(Protocol):
    deps: _Deps


class HangingPlanner:
    def __init__(self) -> None:
        self.started = asyncio.Event()

    async def run(
        self, deps: object, history: list[object], on_chunk: object, agent_label: str
    ) -> object:
        self.started.set()
        await asyncio.Event().wait()
        raise AssertionError("unreachable")


async def _unused_compactor(history: list[object], deps: object) -> str:
    raise AssertionError("compactor should not run")


class CompleteStream:
    tool_calls: list[object] = []
    usage = None
    finish_reason = None

    def __init__(self) -> None:
        self.messages = [SimpleMessage("user", "x" * 100)]

    async def streams(self):
        if False:
            yield []

    def text(self, default: str) -> str:
        return "done"


class CompletePlanner:
    async def run(
        self, deps: object, history: list[object], on_chunk: object, agent_label: str
    ) -> CompletionResult:
        return CompletionResult(
            text="done",
            messages=[SimpleMessage("user", "x" * 100)],
            usage=None,
            finish_reason=None,
        )


class CapturingTurnEngineFactory:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []

    def __call__(self, **kwargs: object) -> object:
        self.calls.append(kwargs)
        return object()


class ReadOnlyBurstPlanner:
    async def run(
        self, deps: _Deps, history: list[object], on_chunk: object, agent_label: str
    ) -> CompletionResult:
        if deps.on_tool_result is not None:  # type: ignore[attr-defined]
            await deps.on_tool_result("read_file", "alpha", "call-1", False)  # type: ignore[attr-defined]
            await deps.on_tool_result("search_code", "beta", "call-2", False)  # type: ignore[attr-defined]
            await deps.on_tool_result("git_diff", "gamma", "call-3", False)  # type: ignore[attr-defined]
        return CompletionResult(
            text="done",
            messages=[SimpleMessage("assistant", "done")],
            usage=None,
            finish_reason=None,
        )


class ReadMutationReadPlanner:
    async def run(
        self, deps: _Deps, history: list[object], on_chunk: object, agent_label: str
    ) -> CompletionResult:
        if deps.on_tool_result is not None:
            await deps.on_tool_result("read_file", "alpha", "call-1", False)
            await deps.on_tool_result("write_file", "beta", "call-2", False)
            await deps.on_tool_result("read_file", "gamma", "call-3", False)
        return CompletionResult(
            text="done",
            messages=[SimpleMessage("assistant", "done")],
            usage=None,
            finish_reason=None,
        )


class RetryOncePlanner:
    def __init__(self) -> None:
        self.calls = 0

    async def run(
        self, deps: object, history: list[object], on_chunk: object, agent_label: str
    ) -> CompletionResult:
        self.calls += 1
        if self.calls == 1:
            raise BadRequestError(
                "This model's maximum context length has been exceeded.",
                provider="openai",
                status_code=400,
            )
        return CompletionResult(
            text="done",
            messages=[SimpleMessage("assistant", "done")],
            usage=None,
            finish_reason=None,
        )


class ToolThenOverflowStream:
    def __init__(self, ctx: _Ctx) -> None:
        self.ctx = ctx
        self.tool_calls = [object()]
        self.messages = [SimpleMessage("assistant", "tool turn")]
        self.usage = None
        self.finish_reason = None

    async def streams(self):
        if False:
            yield []

    async def execute_tools(self, ctx: _Ctx) -> list[object]:
        self.ctx.deps.stuck_loop_tracker.register_tool_call(
            "coder", {"task": "write file"}
        )
        if self.ctx.deps.on_tool_use is not None:
            await self.ctx.deps.on_tool_use("coder", {"task": "write file"})
        raise BadRequestError(
            "Input exceeds the context window.",
            provider="openai",
            status_code=400,
        )

    async def resume(self, ctx: object, tool_outputs: list[object]) -> object:
        raise AssertionError("resume should not be reached")

    def text(self, default: str) -> str:
        return "unused"


class ToolThenOverflowPlanner:
    async def run(
        self, deps: _Deps, history: list[object], on_chunk: object, agent_label: str
    ) -> CompletionResult:
        deps.stuck_loop_tracker.register_tool_call("write_file", {"path": "foo.py"})
        if deps.on_tool_use is not None:
            await deps.on_tool_use("write_file", {"path": "foo.py"})
        raise BadRequestError(
            "Input exceeds the context window.",
            provider="openai",
            status_code=400,
        )


class GenericBadRequestPlanner:
    async def run(
        self, deps: _Deps, history: list[object], on_chunk: object, agent_label: str
    ) -> CompletionResult:
        raise BadRequestError(
            "Error code: 400",
            provider="openai",
            status_code=400,
        )


class SimpleToolOutput:
    def __init__(self, name: str, result: object) -> None:
        self.name = name
        self.result = result
        self.id = "tool-1"
        self.error = None


class SelfCompactStream:
    def __init__(self, ctx: _Ctx) -> None:
        self.ctx = ctx
        self.tool_calls = [object()]
        self.messages = [SimpleMessage("assistant", "self compact turn")]
        self.usage = None
        self.finish_reason = None

    async def streams(self):
        if False:
            yield []

    async def execute_tools(self, ctx: _Ctx) -> list[object]:
        self.ctx.deps.stuck_loop_tracker.register_tool_call(
            "self_compact", {"reason": "dead ends"}
        )
        if self.ctx.deps.on_tool_use is not None:
            await self.ctx.deps.on_tool_use("self_compact", {"reason": "dead ends"})
        return [SimpleToolOutput("self_compact", "Compaction requested: dead ends")]

    async def resume(self, ctx: _Ctx, tool_outputs: list[object]) -> object:
        return CompleteStream()

    def text(self, default: str) -> str:
        return "unused"


class SelfCompactPlanner:
    async def run(
        self, deps: _Deps, history: list[object], on_chunk: object, agent_label: str
    ) -> CompletionResult:
        deps.stuck_loop_tracker.register_tool_call(
            "self_compact", {"reason": "dead ends"}
        )
        if deps.on_tool_use is not None:
            await deps.on_tool_use("self_compact", {"reason": "dead ends"})
        deps.compact_requested = "dead ends"  # type: ignore[attr-defined]
        return CompletionResult(
            text="done",
            messages=[SimpleMessage("assistant", "self compact turn")],
            usage=None,
            finish_reason=None,
        )


async def _summary_compactor(history: list[object], deps: object) -> str:
    return "summary"


class PreflightPlanner:
    def __init__(self) -> None:
        self.started = asyncio.Event()
        self.history: list[object] = []

    async def run(
        self, deps: object, history: list[object], on_chunk: object, agent_label: str
    ) -> CompletionResult:
        self.started.set()
        self.history = history
        return CompletionResult(
            text="done",
            messages=[SimpleMessage("assistant", "done")],
            usage=None,
            finish_reason=None,
        )


class RepeatingToolStream:
    def __init__(self, ctx: _Ctx, orchestrator: "RepeatingToolPlanner") -> None:
        self.ctx = ctx
        self.orchestrator = orchestrator
        self.tool_calls = [object()]
        self.messages = [SimpleMessage("assistant", "loop turn")]
        self.usage = None
        self.finish_reason = None

    async def streams(self):
        if False:
            yield []

    async def execute_tools(self, ctx: _Ctx) -> list[object]:
        self.orchestrator.calls += 1
        self.ctx.deps.stuck_loop_tracker.register_tool_call(
            "search_code", {"pattern": "needle"}
        )
        if self.ctx.deps.on_tool_use is not None:
            await self.ctx.deps.on_tool_use("search_code", {"pattern": "needle"})
        return [SimpleToolOutput("search_code", f"result {self.orchestrator.calls}")]

    async def resume(self, ctx: _Ctx, tool_outputs: list[object]) -> object:
        if self.orchestrator.calls >= self.orchestrator.total_calls:
            return CompleteStream()
        return RepeatingToolStream(ctx, self.orchestrator)

    def text(self, default: str) -> str:
        return "unused"


class RepeatingToolPlanner:
    def __init__(self, total_calls: int = 3) -> None:
        self.calls = 0
        self.total_calls = total_calls

    async def run(
        self, deps: _Deps, history: list[object], on_chunk: object, agent_label: str
    ) -> CompletionResult:
        while self.calls < self.total_calls:
            self.calls += 1
            deps.stuck_loop_tracker.register_tool_call(
                "search_code", {"pattern": "needle"}
            )
            if deps.on_tool_use is not None:
                await deps.on_tool_use("search_code", {"pattern": "needle"})
        on_stuck_loop = deps.on_stuck_loop
        if on_stuck_loop is not None:
            await on_stuck_loop(
                "[LOOP BLOCKED] search_code identical call intercepted before execution",
                "warn",
            )
        return CompletionResult(
            text="done",
            messages=[SimpleMessage("assistant", "done")],
            usage=None,
            finish_reason=None,
        )


async def test_create_allows_openai_codex_provider_without_api_key(
    monkeypatch, tmp_path
) -> None:
    from kiss.agent import loop as loop_module

    settings = Settings(
        model="codex:o4-mini",
    )

    monkeypatch.setattr(loop_module, "create_compactor", lambda *_: object())
    monkeypatch.chdir(tmp_path)

    agent = await KissAgent.create(settings)

    assert agent.settings.model == "codex:o4-mini"


def _content_text(message: object) -> str:
    content = getattr(message, "content", [])
    parts = content if isinstance(content, list) else [content]
    text: list[str] = []
    for part in parts:
        if hasattr(part, "text"):
            text.append(part.text)
        else:
            text.append(str(part))
    return "\n".join(text)


@pytest.mark.asyncio
async def test_send_emits_cancelled_event_when_current_task_is_cancelled() -> None:
    settings = Settings(
        model="test:model",
        context_window=20_000,
    )
    planner = HangingPlanner()
    agent = KissAgent(
        settings,
        _unused_compactor,
        turn_engine_factory=lambda **_: planner,
    )

    events = agent.send("hello")
    first_event = asyncio.create_task(events.__anext__())
    await asyncio.wait_for(planner.started.wait(), timeout=1.0)

    agent.cancel()

    event = await asyncio.wait_for(first_event, timeout=1.0)
    assert event.kind is EventKind.CANCELLED

    with pytest.raises(StopAsyncIteration):
        await asyncio.wait_for(events.__anext__(), timeout=1.0)


@pytest.mark.asyncio
async def test_send_emits_compaction_events_before_done() -> None:
    settings = Settings(
        model="test:model",
        context_window=1,
    )
    agent = KissAgent(
        settings,
        _summary_compactor,
        turn_engine_factory=lambda **_: CompletePlanner(),
    )

    events = [event async for event in agent.send("hello")]
    kinds = [event.kind for event in events]

    assert EventKind.DONE in kinds
    done_idx = kinds.index(EventKind.DONE)
    pre_done = kinds[:done_idx]
    assert EventKind.COMPACTING in pre_done
    assert EventKind.COMPACTED in pre_done
    assert pre_done.index(EventKind.COMPACTING) < pre_done.index(EventKind.COMPACTED)


@pytest.mark.asyncio
async def test_send_emits_token_when_provider_returns_only_final_text() -> None:
    settings = Settings(
        model="test:model",
        context_window=20_000,
    )
    agent = KissAgent(
        settings,
        _unused_compactor,
        turn_engine_factory=lambda **_: CompletePlanner(),
    )

    events = [event async for event in agent.send("hello")]
    tokens = [event.token for event in events if event.kind is EventKind.TOKEN]

    assert tokens == ["done"]
    assert events[-1].kind is EventKind.DONE


@pytest.mark.asyncio
async def test_send_emits_stuck_loop_event_before_done() -> None:
    settings = Settings(
        model="test:model",
        context_window=20_000,
    )
    agent = KissAgent(
        settings,
        _unused_compactor,
        turn_engine_factory=lambda **_: RepeatingToolPlanner(total_calls=3),
    )

    events = [event async for event in agent.send("hello")]
    stuck_loop_events = [
        event for event in events if event.kind is EventKind.STUCK_LOOP
    ]

    assert len(stuck_loop_events) == 1
    assert stuck_loop_events[0].severity == "warn"
    assert "LOOP BLOCKED" in stuck_loop_events[0].info
    assert events[-1].kind is EventKind.DONE


@pytest.mark.asyncio
async def test_send_compacts_before_streaming_when_prompt_is_too_large() -> None:
    settings = Settings(
        model="test:model",
        context_window=2_000,
    )
    planner = PreflightPlanner()

    async def compactor(history: list[object], deps: object, **__: object) -> str:
        assert not planner.started.is_set()
        return "summary"

    agent = KissAgent(
        settings,
        compactor,
        turn_engine_factory=lambda **_: planner,
    )

    events = [event async for event in agent.send("hello")]
    kinds = [event.kind for event in events]

    assert kinds[:2] == [EventKind.COMPACTING, EventKind.COMPACTED]
    assert kinds[-1] is EventKind.DONE


@pytest.mark.asyncio
async def test_send_retries_once_on_overflow_before_tool_use() -> None:
    settings = Settings(
        model="test:model",
        context_window=20_000,
    )
    planner = RetryOncePlanner()
    compactions: list[str] = []

    async def compactor(history: list[object], deps: object, **__: object) -> str:
        compactions.append("called")
        return "summary"

    agent = KissAgent(
        settings,
        compactor,
        turn_engine_factory=lambda **_: planner,
    )
    agent._turns_since_compact = 20

    events = [event async for event in agent.send("hello")]
    kinds = [event.kind for event in events]
    compacting_info = [
        event.info for event in events if event.kind is EventKind.COMPACTING
    ]

    assert planner.calls == 2
    assert compactions == ["called"]
    assert kinds.count(EventKind.COMPACTING) == 1
    assert kinds.count(EventKind.COMPACTED) == 1
    assert compacting_info == [
        "Compacting context (self-healing retry after context overflow (status_code:400+message))…"
    ]
    assert kinds[-1] is EventKind.DONE
    assert EventKind.ERROR not in kinds


@pytest.mark.asyncio
async def test_send_does_not_retry_after_tool_use_begins() -> None:
    settings = Settings(
        model="test:model",
        context_window=20_000,
    )
    planner = ToolThenOverflowPlanner()
    compactions: list[str] = []

    async def compactor(history: list[object], deps: object, **__: object) -> str:
        compactions.append("called")
        return "summary"

    agent = KissAgent(
        settings,
        compactor,
        turn_engine_factory=lambda **_: planner,
    )

    events = [event async for event in agent.send("hello")]
    kinds = [event.kind for event in events]

    assert compactions == []
    assert kinds.count(EventKind.TOOL_CALL) == 1
    assert kinds.count(EventKind.ERROR) == 1
    assert EventKind.COMPACTING not in kinds
    assert EventKind.DONE not in kinds


@pytest.mark.asyncio
async def test_send_reframes_generic_bad_request_with_tool_capability_hint() -> None:
    settings = Settings(
        model="test:model",
        context_window=20_000,
    )
    planner = GenericBadRequestPlanner()
    agent = KissAgent(
        settings,
        _unused_compactor,
        turn_engine_factory=lambda **_: planner,
    )

    events_iter = agent.send("Create file foo.py with content: x")
    first = await events_iter.__anext__()
    assert first.kind is EventKind.ASK_USER
    assert first.ask_user is not None
    first.ask_user.reply_future.set_result(
        AskUserReply(outcome="selected", selected_choice_ids=["proceed"])
    )

    events = [first]
    async for event in events_iter:
        events.append(event)
    error_events = [event for event in events if event.kind is EventKind.ERROR]

    assert len(error_events) == 1
    assert error_events[0].error is not None
    assert "likely does not support the tool-calling payload" in str(
        error_events[0].error
    )
    assert "test:model" in str(error_events[0].error)
    assert EventKind.DONE not in [event.kind for event in events]


@pytest.mark.asyncio
async def test_send_compacts_after_self_compact_request() -> None:
    settings = Settings(
        model="test:model",
        context_window=20_000,
    )
    planner = SelfCompactPlanner()
    compactions: list[str] = []

    async def compactor(history: list[object], deps: object, **__: object) -> str:
        compactions.append("called")
        return "summary"

    agent = KissAgent(
        settings,
        compactor,
        turn_engine_factory=lambda **_: planner,
    )

    events = [event async for event in agent.send("hello")]
    kinds = [event.kind for event in events]
    compacting_info = [
        event.info for event in events if event.kind is EventKind.COMPACTING
    ]

    assert compactions == ["called"]
    assert kinds.count(EventKind.COMPACTING) == 1
    assert kinds.count(EventKind.COMPACTED) == 1
    assert compacting_info == [
        "Compacting context (self-compaction requested (dead ends))…"
    ]
    assert kinds[-1] is EventKind.DONE


@pytest.mark.asyncio
async def test_send_injects_context_ref_manifest_before_streaming(tmp_path) -> None:
    settings = Settings(
        model="test:model",
        context_window=20_000,
    )
    planner = PreflightPlanner()
    agent = KissAgent(
        settings,
        _unused_compactor,
        workspace_root=tmp_path,
        turn_engine_factory=lambda **_: planner,
    )

    target = tmp_path / "note.py"
    target.write_text("alpha\nbeta\n", encoding="utf-8")

    old_cwd = Path.cwd()
    try:
        os.chdir(tmp_path / "..")
        _ = [event async for event in agent.send("Look at @note.py")]
    finally:
        os.chdir(old_cwd)

    sent = _content_text(planner.history[-1])
    assert "[Referenced files]" in sent
    assert "Look at @note.py" in sent
    assert "1 | alpha" in sent


@pytest.mark.asyncio
async def test_send_uses_explicit_workspace_root_from_nested_cwd(tmp_path) -> None:
    workspace = tmp_path / "repo"
    nested = workspace / "src" / "kiss"
    nested.mkdir(parents=True)
    (workspace / "README.md").write_text("root readme\n", encoding="utf-8")

    settings = Settings(
        model="test:model",
        context_window=20_000,
    )
    planner = PreflightPlanner()
    agent = KissAgent(
        settings,
        _unused_compactor,
        workspace_root=workspace,
        turn_engine_factory=lambda **_: planner,
    )

    _ = [event async for event in agent.send("Look at @README.md")]

    sent = _content_text(planner.history[-1])
    assert "resolved: README.md" in sent
    assert "1 | root readme" in sent


def test_refresh_turn_engine_initializes_without_current_engine(tmp_path: Path) -> None:
    factory = CapturingTurnEngineFactory()
    settings = Settings(
        model="openai:gpt-4.1",
        context_window=1,
    )
    agent = KissAgent(
        settings,
        _unused_compactor,
        sessions_dir=tmp_path,
        turn_engine_factory=factory,
    )
    agent._current_turn_engine = None
    agent._current_tool_set = "validate"
    agent._gate_writes = False

    agent.refresh_turn_engine(TurnPhase.PLANNING)

    assert agent._turn_phase is TurnPhase.PLANNING
    assert agent._current_turn_engine is not None
    assert factory.calls == [
        {
            "model_id": "gpt-4.1",
            "workspace_root": agent.workspace_root,
            "settings": settings,
            "tool_set": "validate",
            "phase": TurnPhase.PLANNING,
            "gate_writes": False,
            "system_prompt_additions": [
                "[Phase: PLANNING] No git commits. Write tools available for drafting.\n"
            ],
        }
    ]


def test_refresh_turn_engine_reuses_engine_when_key_is_unchanged(
    tmp_path: Path,
) -> None:
    factory = CapturingTurnEngineFactory()
    settings = Settings(
        model="openai:gpt-4.1",
        context_window=1,
    )
    agent = KissAgent(
        settings,
        _unused_compactor,
        sessions_dir=tmp_path,
        turn_engine_factory=factory,
    )
    agent._current_tool_set = "validate"
    agent._gate_writes = False

    agent.refresh_turn_engine(TurnPhase.PLANNING)
    first_engine = agent._current_turn_engine
    agent.refresh_turn_engine(TurnPhase.PLANNING)

    assert agent._current_turn_engine is first_engine
    assert len(factory.calls) == 1


def test_refresh_turn_engine_rebuilds_when_nudge_addition_changes(
    tmp_path: Path,
) -> None:
    factory = CapturingTurnEngineFactory()
    settings = Settings(
        model="openai:gpt-4.1",
        context_window=1,
    )
    agent = KissAgent(
        settings,
        _unused_compactor,
        sessions_dir=tmp_path,
        turn_engine_factory=factory,
    )
    agent._current_tool_set = "validate"

    agent.refresh_turn_engine(TurnPhase.RESEARCH)
    first_engine = agent._current_turn_engine
    agent._post_file_nudge_pending = True
    agent.refresh_turn_engine(TurnPhase.RESEARCH)

    assert agent._current_turn_engine is not first_engine
    assert len(factory.calls) == 2
    additions = factory.calls[-1]["system_prompt_additions"]
    assert isinstance(additions, list)
    assert any(
        "You've used 3+ read/search tools since your last edit." in addition
        for addition in additions
        if isinstance(addition, str)
    )


@pytest.mark.asyncio
async def test_send_slash_only_command_skips_turn_engine() -> None:
    settings = Settings(
        model="test:model",
        context_window=20_000,
    )
    planner = HangingPlanner()
    agent = KissAgent(
        settings,
        _unused_compactor,
        turn_engine_factory=lambda **_: planner,
    )

    events = [event async for event in agent.send("/plan")]

    assert planner.started.is_set() is False
    assert agent._turn_phase is TurnPhase.PLANNING
    assert [event.kind for event in events] == [EventKind.TOKEN, EventKind.DONE]
    assert events[0].token == "Switched to Planning phase."


@pytest.mark.asyncio
async def test_send_phase_coaching_approval_refreshes_turn_engine() -> None:
    settings = Settings(
        model="test:model",
        context_window=20_000,
    )
    factory = CapturingTurnEngineFactory()
    planner = CompletePlanner()
    agent = KissAgent(
        settings,
        _unused_compactor,
        turn_engine_factory=lambda **kwargs: (
            factory(**kwargs),
            planner,
        )[1],
    )

    events_iter = agent.send("Implement the feature")
    first = await events_iter.__anext__()

    assert first.kind is EventKind.ASK_USER
    assert first.ask_user is not None
    first.ask_user.reply_future.set_result(
        AskUserReply(outcome="selected", selected_choice_ids=["proceed"])
    )

    events = [first]
    async for event in events_iter:
        events.append(event)

    assert agent._turn_phase is TurnPhase.PLANNING
    assert EventKind.DONE in [event.kind for event in events]
    assert factory.calls[-1]["phase"] is TurnPhase.PLANNING
    assert factory.calls[-1]["tool_set"] == "edit"


@pytest.mark.asyncio
async def test_send_headless_heuristic_transition_stays_in_current_phase() -> None:
    settings = Settings(
        model="test:model",
        context_window=20_000,
    )
    agent = KissAgent(
        settings,
        _unused_compactor,
        turn_engine_factory=lambda **_: CompletePlanner(),
    )
    agent._headless_mode = True

    try:
        events = [event async for event in agent.send("Implement the feature")]
    finally:
        agent._headless_mode = False

    assert agent._turn_phase is TurnPhase.RESEARCH
    assert EventKind.ASK_USER not in [event.kind for event in events]
    assert any(
        event.kind is EventKind.INFO
        and "Skipped heuristic phase coaching in non-interactive mode" in event.info
        for event in events
    )


@pytest.mark.asyncio
async def test_send_consumes_post_file_nudge_as_next_turn_system_context() -> None:
    settings = Settings(
        model="test:model",
        context_window=20_000,
    )
    factory = CapturingTurnEngineFactory()
    agent = KissAgent(
        settings,
        _unused_compactor,
        turn_engine_factory=lambda **kwargs: (
            factory(**kwargs),
            ReadOnlyBurstPlanner(),
        )[1],
    )

    _ = [event async for event in agent.send("inspect the files")]

    assert agent._consecutive_reads_since_mutation == 3
    assert agent._post_file_nudge_pending is True

    agent.refresh_turn_engine(TurnPhase.RESEARCH)

    additions = factory.calls[-1]["system_prompt_additions"]
    assert isinstance(additions, list)
    additions_text = [item for item in additions if isinstance(item, str)]
    assert len(additions_text) == len(additions)
    assert any("[Phase: RESEARCH]" in item for item in additions_text)
    assert any(
        "You've used 3+ read/search tools since your last edit." in item
        for item in additions_text
    )
    assert agent._post_file_nudge_pending is False


@pytest.mark.asyncio
async def test_send_resets_read_counter_after_mutation() -> None:
    settings = Settings(
        model="test:model",
        context_window=20_000,
    )
    agent = KissAgent(
        settings,
        _unused_compactor,
        turn_engine_factory=lambda **_: ReadMutationReadPlanner(),
    )
    agent._turn_phase = TurnPhase.PLANNING

    _ = [event async for event in agent.send("inspect and then edit")]

    assert agent._consecutive_reads_since_mutation == 1
    assert agent._post_file_nudge_pending is False


def test_shutdown_writes_session_learnings_and_trace_export(tmp_path: Path) -> None:
    settings = Settings(
        model="openai:gpt-4.1",
        context_window=1,
    )
    agent = KissAgent(
        settings,
        _unused_compactor,
        sessions_dir=tmp_path,
    )
    agent._turn_phase = TurnPhase.EXECUTION
    agent._last_tool_name = "write_file"

    agent.shutdown()

    learnings = (tmp_path / "agents_learn.md").read_text(encoding="utf-8")
    traces = (tmp_path / "traces.jsonl").read_text(encoding="utf-8")

    assert "Final phase: EXECUTION." in learnings
    assert "Last tool observed: write_file." in learnings
    assert (
        "Prompt source: Analyze this session and extract non-obvious learnings."
        in learnings
    )
    assert '"record_type": "session"' in traces
