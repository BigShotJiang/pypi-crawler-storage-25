from __future__ import annotations

from pathlib import Path

from kiss.agent.context_refs import (
    _build_manifest,
    _format_range_preview,
    _numbered_lines,
    ContextRef,
    expand_context_ref,
    resolve_message_context_refs,
)


def test_resolve_message_context_refs_injects_manifest_and_preview(
    tmp_path: Path,
) -> None:
    repo = tmp_path
    target = repo / "src" / "mod.py"
    target.parent.mkdir(parents=True)
    target.write_text("line1\nline2\nline3\n", encoding="utf-8")

    result = resolve_message_context_refs(
        "Check @src/mod.py",
        repo_root=repo,
    )

    assert "Referenced files" in result.injected_message
    assert "src/mod.py" in result.injected_message
    assert "1 | line1" in result.injected_message
    assert "Check @src/mod.py" in result.injected_message
    assert "src/mod.py" in result.refs


def test_resolve_message_context_refs_uses_exact_line_ranges(tmp_path: Path) -> None:
    repo = tmp_path
    target = repo / "app.py"
    target.write_text("a\nb\nc\nd\n", encoding="utf-8")

    result = resolve_message_context_refs(
        "Inspect @app.py:2-3",
        repo_root=repo,
    )

    assert "2 | b" in result.injected_message
    assert "3 | c" in result.injected_message
    assert "1 | a" not in result.injected_message


def test_resolve_message_context_refs_ignores_inline_code_and_fences(
    tmp_path: Path,
) -> None:
    repo = tmp_path
    (repo / "real.py").write_text("x = 1\n", encoding="utf-8")

    message = (
        "Use `@fake.py` as an example.\n"
        "```python\n@also_fake.py\n```\n"
        "But inspect @real.py"
    )
    result = resolve_message_context_refs(message, repo_root=repo)

    assert "real.py" in result.refs
    assert "@fake.py" not in result.manifest
    assert "@also_fake.py" not in result.manifest


def test_resolve_message_context_refs_injects_missing_ref_warnings(
    tmp_path: Path,
) -> None:
    repo = tmp_path

    result = resolve_message_context_refs(
        "Check @missing.py",
        repo_root=repo,
    )

    assert "Reference warnings" in result.injected_message
    assert "Missing ref: missing.py" in result.injected_message
    assert result.refs == {}


def test_expand_context_ref_rejects_unknown_refs(tmp_path: Path) -> None:
    repo = tmp_path
    target = repo / "ok.py"
    target.write_text("print('ok')\n", encoding="utf-8")

    resolved = resolve_message_context_refs("Read @ok.py", repo_root=repo)
    result = expand_context_ref("bad.py", resolved.refs, repo)

    assert result.meta.ok is False
    assert result.meta.error_message is not None
    assert "Error: unknown ref" in result.meta.error_message
    assert "ok.py" in result.meta.error_message


def test_expand_context_ref_full_file(tmp_path: Path) -> None:
    repo = tmp_path
    (repo / "hello.py").write_text("x = 1\ny = 2\n", encoding="utf-8")

    resolved = resolve_message_context_refs("Check @hello.py", repo_root=repo)
    result = expand_context_ref("hello.py", resolved.refs, repo)

    assert result.meta.ok is True
    assert result.content is not None
    assert "1 | x = 1" in result.content
    assert "2 | y = 2" in result.content
    assert "full content" in result.content


def test_expand_context_ref_range(tmp_path: Path) -> None:
    repo = tmp_path
    (repo / "code.py").write_text("a\nb\nc\nd\n", encoding="utf-8")

    resolved = resolve_message_context_refs("Look at @code.py:2-3", repo_root=repo)
    result = expand_context_ref("code.py:2-3", resolved.refs, repo)

    assert result.meta.ok is True
    assert result.content is not None
    assert "2 | b" in result.content
    assert "3 | c" in result.content
    assert "1 | a" not in result.content
    assert "4 | d" not in result.content


def test_expand_context_ref_execution_error(tmp_path: Path) -> None:
    repo = tmp_path
    target = repo / "gone.py"
    target.write_text("x = 1\n", encoding="utf-8")

    resolved = resolve_message_context_refs("Check @gone.py", repo_root=repo)
    target.unlink()
    result = expand_context_ref("gone.py", resolved.refs, repo)

    assert result.meta.ok is False
    assert result.meta.error_code == "execution_failed"


# ── _build_manifest ───────────────────────────────────────────────────────────


def test_build_manifest_head_ref(tmp_path: Path) -> None:
    repo = tmp_path
    f = repo / "mod.py"
    f.write_text("".join(f"line{i}\n" for i in range(1, 6)), encoding="utf-8")
    ref = ContextRef(label="mod.py", path_text="mod.py", resolved_path=f)

    manifest = _build_manifest([ref], [], repo)

    assert "Referenced files" in manifest
    assert "mod.py" in manifest
    assert "1 | line1" in manifest
    assert "Instructions" in manifest


def test_build_manifest_range_ref(tmp_path: Path) -> None:
    repo = tmp_path
    f = repo / "src.py"
    f.write_text("a\nb\nc\n", encoding="utf-8")
    ref = ContextRef(
        label="src.py:1-2",
        path_text="src.py",
        resolved_path=f,
        start_line=1,
        end_line=2,
    )

    manifest = _build_manifest([ref], [], repo)

    assert "1 | a" in manifest
    assert "2 | b" in manifest
    assert "3 | c" not in manifest


def test_build_manifest_warnings_only(tmp_path: Path) -> None:
    manifest = _build_manifest([], ["Missing ref: ghost.py (does not exist)"], tmp_path)

    assert "Reference warnings" in manifest
    assert "ghost.py" in manifest
    assert "Referenced files" not in manifest


def test_build_manifest_refs_and_warnings(tmp_path: Path) -> None:
    repo = tmp_path
    f = repo / "x.py"
    f.write_text("pass\n", encoding="utf-8")
    ref = ContextRef(label="x.py", path_text="x.py", resolved_path=f)

    manifest = _build_manifest([ref], ["Missing ref: y.py"], repo)

    assert "Referenced files" in manifest
    assert "Reference warnings" in manifest


# ── _format_range_preview ─────────────────────────────────────────────────────


def test_format_range_preview_normal(tmp_path: Path) -> None:
    repo = tmp_path
    f = repo / "f.py"
    f.write_text("a\nb\nc\nd\n", encoding="utf-8")
    ref = ContextRef(
        label="f.py:2-3",
        path_text="f.py",
        resolved_path=f,
        start_line=2,
        end_line=3,
    )

    preview = _format_range_preview(ref, repo)

    assert "2 | b" in preview
    assert "3 | c" in preview
    assert "1 | a" not in preview


def test_format_range_preview_end_beyond_file(tmp_path: Path) -> None:
    repo = tmp_path
    f = repo / "f.py"
    f.write_text("a\nb\n", encoding="utf-8")
    ref = ContextRef(
        label="f.py:1-99",
        path_text="f.py",
        resolved_path=f,
        start_line=1,
        end_line=99,
    )

    preview = _format_range_preview(ref, repo)

    assert "1 | a" in preview
    assert "2 | b" in preview
    assert "file ends at 2" in preview


def test_format_range_preview_start_beyond_file(tmp_path: Path) -> None:
    repo = tmp_path
    f = repo / "f.py"
    f.write_text("a\nb\n", encoding="utf-8")
    ref = ContextRef(
        label="f.py:50-60",
        path_text="f.py",
        resolved_path=f,
        start_line=50,
        end_line=60,
    )

    preview = _format_range_preview(ref, repo)

    assert "file has 2 lines" in preview


# ── _numbered_lines ───────────────────────────────────────────────────────────


def test_numbered_lines_basic() -> None:
    lines = ["alpha\n", "beta\n", "gamma\n"]
    result = _numbered_lines(lines, 1, 3)

    assert "1 | alpha" in result
    assert "2 | beta" in result
    assert "3 | gamma" in result


def test_numbered_lines_offset_start() -> None:
    lines = ["x\n", "y\n", "z\n"]
    result = _numbered_lines(lines, 2, 3)

    assert "2 | y" in result
    assert "3 | z" in result
    assert "1 |" not in result


def test_numbered_lines_empty_range() -> None:
    result = _numbered_lines(["a\n", "b\n"], start_line=5, end_line=3)

    assert result == ""


def test_numbered_lines_aligns_width() -> None:
    lines = [f"line{i}\n" for i in range(1, 12)]
    result = _numbered_lines(lines, 1, 11)

    assert " 1 | line1" in result
    assert "11 | line11" in result
