"""Tests for resolve_fallback_models() — depth guard, order, cross-provider."""

from __future__ import annotations

import pytest

import kiss.providers.registry as reg_module
from kiss.providers.fallback import resolve_fallback_models
from kiss.providers.registry import register_provider
from tests.providers.mock import MockAuthStrategy, make_profile


@pytest.fixture(autouse=True)
def reset_registry(monkeypatch):
    monkeypatch.setattr(reg_module, "_REGISTRY", {})
    monkeypatch.setattr(reg_module, "_ALIASES", {})
    monkeypatch.setattr(reg_module, "_discovery_state", reg_module._DS.DONE)
    from kiss.providers.strategies import _STRATEGIES

    original = dict(_STRATEGIES)
    _STRATEGIES["mock"] = MockAuthStrategy()
    yield
    _STRATEGIES.clear()
    _STRATEGIES.update(original)


def test_no_fallback_models_returns_empty():
    p = make_profile("alpha")
    assert resolve_fallback_models(p, "alpha/primary") == []


def test_bare_model_ids_scoped_to_provider():
    p = make_profile("alpha", fallback_models=("model-b", "model-c"))
    result = resolve_fallback_models(p, "model-primary")
    assert result == ["alpha/model-b", "alpha/model-c"]


def test_primary_excluded_from_fallbacks():
    p = make_profile("alpha", fallback_models=("primary", "backup"))
    result = resolve_fallback_models(p, "primary")
    assert "alpha/primary" not in result
    assert "alpha/backup" in result


def test_cross_provider_fallback_included():
    p = make_profile("alpha", fallback_models=("beta/model-x",))
    result = resolve_fallback_models(p, "alpha/main")
    assert "beta/model-x" in result


def test_depth_limit_prevents_deep_recursion():
    register_provider(make_profile("beta", fallback_models=("gamma/model-z",)))
    register_provider(make_profile("gamma", fallback_models=("delta/model-w",)))
    p = make_profile("alpha", fallback_models=("beta/model-x",))
    result = resolve_fallback_models(p, "alpha/main")
    # beta/model-x included (depth 0→1)
    assert "beta/model-x" in result
    # gamma/model-z included (depth 1→2, still within max 2)
    assert "gamma/model-z" in result
    # delta/model-w excluded (depth 2→3, exceeds max)
    assert "delta/model-w" not in result


def test_order_preserved_left_to_right():
    p = make_profile("alpha", fallback_models=("first", "second", "third"))
    result = resolve_fallback_models(p, "other")
    assert result.index("alpha/first") < result.index("alpha/second")
    assert result.index("alpha/second") < result.index("alpha/third")
