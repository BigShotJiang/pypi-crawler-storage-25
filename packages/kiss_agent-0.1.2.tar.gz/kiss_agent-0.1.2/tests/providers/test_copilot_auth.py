from __future__ import annotations

from pathlib import Path

import pytest

from kiss.providers import copilot_auth


def test_save_and_load_github_token(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(copilot_auth, "_CREDS_PATH", tmp_path / "copilot.json")

    copilot_auth.save_github_token("abc123")

    assert copilot_auth.load_github_token() == "abc123"


def test_load_github_token_missing_returns_empty(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(copilot_auth, "_CREDS_PATH", tmp_path / "copilot.json")

    assert copilot_auth.load_github_token() == ""


def test_clear_github_token_removes_stored_values(monkeypatch, tmp_path: Path) -> None:
    creds_path = tmp_path / "copilot.json"
    monkeypatch.setattr(copilot_auth, "_CREDS_PATH", creds_path)

    copilot_auth.save_github_token("stored-token")
    assert creds_path.exists()

    copilot_auth.clear_github_token()

    assert not creds_path.exists()


class _FakeResponse:
    def __init__(self, data: dict[str, object]) -> None:
        self._data = data

    def raise_for_status(self) -> None:
        return None

    def json(self) -> dict[str, object]:
        return self._data


class _FakeAsyncClient:
    instances: list["_FakeAsyncClient"] = []

    def __init__(self, **kwargs: object) -> None:
        self.kwargs = kwargs
        self.posts: list[dict[str, object]] = []
        type(self).instances.append(self)

    async def __aenter__(self) -> "_FakeAsyncClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        return None

    async def post(self, url: str, **kwargs: object) -> _FakeResponse:
        self.posts.append({"url": url, **kwargs})
        if url == copilot_auth._DEVICE_CODE_URL:
            return _FakeResponse(
                {
                    "device_code": "device-code",
                    "user_code": "user-code",
                    "verification_uri": "https://github.com/login/device",
                    "verification_uri_complete": "https://github.com/login/device/complete",
                }
            )
        return _FakeResponse({"access_token": "copilot-token"})


@pytest.mark.asyncio
async def test_run_copilot_device_auth_uses_env_friendly_clients(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    _FakeAsyncClient.instances.clear()
    monkeypatch.setattr(copilot_auth, "_CREDS_PATH", tmp_path / "copilot.json")

    async def _sleep(_: float) -> None:
        return None

    monkeypatch.setattr(copilot_auth.httpx, "AsyncClient", _FakeAsyncClient)
    monkeypatch.setattr(copilot_auth.asyncio, "sleep", _sleep)
    monkeypatch.setattr(copilot_auth, "open_browser", lambda url: None)

    success = await copilot_auth.run_copilot_device_auth()

    assert success is True
    assert len(_FakeAsyncClient.instances) == 2
    for client in _FakeAsyncClient.instances:
        assert client.kwargs["follow_redirects"] is True
        assert client.kwargs["trust_env"] is True
