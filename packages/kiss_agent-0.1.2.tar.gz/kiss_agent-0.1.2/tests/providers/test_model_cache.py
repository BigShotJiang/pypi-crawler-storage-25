"""Tests for disk-backed model cache: TTL, settings-hash, corruption resilience."""

from __future__ import annotations

import time

import pytest

from kiss.core.settings import Settings
from kiss.providers.model_cache import (
    _TTL_SECONDS,
    clear_model_cache,
    load_model_cache,
    save_model_cache,
)


@pytest.fixture(autouse=True)
def tmp_cache(tmp_path, monkeypatch):
    """Redirect cache file to a temp directory for each test."""
    import kiss.providers.model_cache as mc

    cache_dir = tmp_path / "cache"
    cache_file = cache_dir / "models.json"
    monkeypatch.setattr(mc, "_CACHE_DIR", cache_dir)
    monkeypatch.setattr(mc, "_CACHE_FILE", cache_file)
    monkeypatch.setattr(mc, "_USER_PROFILES_DIR", tmp_path / "profiles")
    yield cache_file


def _settings() -> Settings:
    return Settings(model="anthropic:claude-sonnet-4-6")


def test_load_returns_none_when_missing(tmp_cache):
    assert load_model_cache(_settings()) is None


def test_save_and_load_roundtrip(tmp_cache):
    models = {"anthropic": ["claude-sonnet-4-6", "claude-opus-4-7"]}
    save_model_cache(models, _settings())
    result = load_model_cache(_settings())
    assert result == models


def test_load_returns_none_when_expired(tmp_cache, monkeypatch):
    models = {"anthropic": ["claude-sonnet-4-6"]}
    save_model_cache(models, _settings())

    # Wind the clock forward past TTL
    monkeypatch.setattr(time, "time", lambda: time.time() + _TTL_SECONDS + 1)
    assert load_model_cache(_settings()) is None


def test_load_returns_none_on_settings_change(tmp_cache, monkeypatch):
    from kiss.providers import model_cache as mc

    monkeypatch.setattr(
        mc, "_settings_hash", lambda s: "hash-a" if "anthropic" in s.model else "hash-b"
    )

    models = {"anthropic": ["claude-sonnet-4-6"]}
    save_model_cache(models, _settings())

    different_settings = Settings(model="openai:gpt-4o")
    assert load_model_cache(different_settings) is None


def test_load_returns_none_on_corrupt_cache(tmp_cache):
    tmp_cache.parent.mkdir(parents=True, exist_ok=True)
    tmp_cache.write_text("{ not valid json !!!")
    assert load_model_cache(_settings()) is None


def test_clear_deletes_cache_file(tmp_cache):
    models = {"anthropic": ["claude-sonnet-4-6"]}
    save_model_cache(models, _settings())
    assert tmp_cache.exists()
    deleted = clear_model_cache()
    assert deleted is True
    assert not tmp_cache.exists()


def test_clear_returns_false_when_no_file(tmp_cache):
    assert not tmp_cache.exists()
    assert clear_model_cache() is False


def test_meta_not_in_result(tmp_cache):
    models = {"anthropic": ["claude-sonnet-4-6"]}
    save_model_cache(models, _settings())
    result = load_model_cache(_settings())
    assert result is not None
    assert "_meta" not in result
