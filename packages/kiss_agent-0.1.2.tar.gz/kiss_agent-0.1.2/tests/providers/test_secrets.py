"""Tests for mask_secret() and LogSanitizer."""

from __future__ import annotations

import logging

from kiss.providers.secrets import LogSanitizer, mask_secret


# ── mask_secret ───────────────────────────────────────────────────────────────


def test_mask_secret_short_keeps_two_chars():
    assert mask_secret("sk") == "sk..."


def test_mask_secret_exactly_12_chars():
    val = "a" * 12
    result = mask_secret(val)
    assert result.startswith("aaaa")
    assert result.endswith("aaaa")
    assert "..." in result


def test_mask_secret_long_keeps_first4_last4():
    result = mask_secret("sk-opABCDEFGHIJKLMNabcd")
    assert result.startswith("sk-o")
    assert result.endswith("abcd")
    assert "..." in result
    assert len(result) < len("sk-opABCDEFGHIJKLMNabcd")


def test_mask_secret_under_12_keeps_two_chars():
    result = mask_secret("short")
    assert result == "sh..."


# ── LogSanitizer ──────────────────────────────────────────────────────────────


def _make_record(msg: str, args: tuple[object, ...] | None = None) -> logging.LogRecord:
    record = logging.LogRecord(
        name="test",
        level=logging.INFO,
        pathname="",
        lineno=0,
        msg=msg,
        args=args,
        exc_info=None,
    )
    return record


def test_sanitizer_masks_api_key_in_message():
    sanitizer = LogSanitizer()
    record = _make_record("api_key=sk-opABCDEFGHIJKLMNabcd")
    sanitizer.filter(record)
    assert "sk-opABCDEFGHIJKLMNabcd" not in record.msg
    assert "..." in record.msg


def test_sanitizer_masks_bearer_token():
    sanitizer = LogSanitizer()
    record = _make_record("Authorization: Bearer ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ")
    sanitizer.filter(record)
    assert "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ" not in record.msg


def test_sanitizer_passes_through_safe_messages():
    sanitizer = LogSanitizer()
    record = _make_record("Provider 'anthropic' registered successfully")
    sanitizer.filter(record)
    assert record.msg == "Provider 'anthropic' registered successfully"


def test_sanitizer_masks_args_tuple():
    sanitizer = LogSanitizer()
    record = _make_record(
        "api_key=%s",
        ("sk-opABCDEFGHIJKLMNopqr",),
    )
    sanitizer.filter(record)
    # After sanitization the full formatted msg is stored and args are cleared.
    assert record.args is None
    assert "sk-opABCDEFGHIJKLMNopqr" not in record.msg
    assert "..." in record.msg


def test_sanitizer_masks_multiple_args():
    sanitizer = LogSanitizer()
    record = _make_record(
        "provider=%s token=%s",
        ("anthropic", "Bearer sk-opABCDEFGHIJKLMNopqr"),
    )
    sanitizer.filter(record)
    assert record.args is None
    assert "sk-opABCDEFGHIJKLMNopqr" not in record.msg
    assert "anthropic" in record.msg


def test_sanitizer_filter_always_returns_true():
    sanitizer = LogSanitizer()
    record = _make_record("some message")
    assert sanitizer.filter(record) is True
