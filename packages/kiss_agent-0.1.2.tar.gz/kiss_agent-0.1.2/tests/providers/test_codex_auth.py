from __future__ import annotations

import sys
from pathlib import Path

import pytest

from kiss.providers import codex_auth
from kiss.providers.codex_auth import CodexTokens


@pytest.fixture()
def no_keyring(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setitem(sys.modules, "keyring", None)


def test_save_and_load_codex_tokens(monkeypatch, tmp_path: Path) -> None:
    token_file = tmp_path / "codex_tokens.json"
    monkeypatch.setattr(codex_auth, "_TOKEN_FILE", token_file)

    expected = CodexTokens(
        access_token="access",
        refresh_token="refresh",
        expires_at=1234.5,
        account_id="acct_1",
    )
    codex_auth.save_codex_tokens(expected)

    loaded = codex_auth.load_codex_tokens()

    assert loaded == expected


def test_load_codex_tokens_returns_none_when_missing(
    no_keyring, monkeypatch, tmp_path: Path
) -> None:
    token_file = tmp_path / "codex_tokens.json"
    monkeypatch.setattr(codex_auth, "_TOKEN_FILE", token_file)

    assert codex_auth.load_codex_tokens() is None


def test_load_codex_tokens_returns_none_when_invalid(
    no_keyring, monkeypatch, tmp_path: Path
) -> None:
    token_file = tmp_path / "codex_tokens.json"
    token_file.write_text("{not-json", encoding="utf-8")
    monkeypatch.setattr(codex_auth, "_TOKEN_FILE", token_file)

    assert codex_auth.load_codex_tokens() is None


def test_extract_account_id_from_claims() -> None:
    claims = {"https://api.openai.com/auth": {"chatgpt_account_id": "acct_nested"}}

    assert codex_auth.extract_account_id(claims) == "acct_nested"


def test_parse_jwt_claims_handles_invalid_token() -> None:
    assert codex_auth.parse_jwt_claims("invalid") == {}
