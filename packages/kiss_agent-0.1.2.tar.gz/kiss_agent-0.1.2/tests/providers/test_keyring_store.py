"""Tests for keyring_store credential persistence with file fallback."""

from __future__ import annotations

import pytest

import kiss.providers.keyring_store as ks_module
from kiss.providers.keyring_store import (
    delete_credential,
    get_credential,
    set_credential,
)


@pytest.fixture(autouse=True)
def tmp_credentials(tmp_path, monkeypatch):
    """Redirect credentials file to tmp dir and disable system keyring."""
    creds_file = tmp_path / "credentials.json"
    monkeypatch.setattr(ks_module, "_CREDENTIALS_FILE", creds_file)

    # Make keyring import raise so we always hit the file fallback
    import builtins

    real_import = builtins.__import__

    def mock_import(name, *args, **kwargs):
        if name == "keyring":
            raise ImportError("keyring disabled in tests")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", mock_import)
    yield creds_file


def test_get_credential_missing_returns_none():
    assert get_credential("nonexistent") is None


def test_set_and_get_roundtrip():
    set_credential("my-key", "secret-value")
    assert get_credential("my-key") == "secret-value"


def test_delete_removes_credential():
    set_credential("my-key", "secret-value")
    delete_credential("my-key")
    assert get_credential("my-key") is None


def test_overwrite_credential():
    set_credential("my-key", "old-value")
    set_credential("my-key", "new-value")
    assert get_credential("my-key") == "new-value"


def test_credentials_file_mode(tmp_credentials):
    import stat

    set_credential("my-key", "secret")
    mode = tmp_credentials.stat().st_mode
    # Only owner should have read/write (no group/other bits)
    assert not (mode & stat.S_IRGRP)
    assert not (mode & stat.S_IWGRP)
    assert not (mode & stat.S_IROTH)
    assert not (mode & stat.S_IWOTH)


def test_multiple_credentials_coexist():
    set_credential("key-a", "value-a")
    set_credential("key-b", "value-b")
    assert get_credential("key-a") == "value-a"
    assert get_credential("key-b") == "value-b"
