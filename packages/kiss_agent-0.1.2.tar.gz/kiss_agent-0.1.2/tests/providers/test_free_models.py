"""Tests for free_models on ProviderProfile and free_providers in Settings."""

from __future__ import annotations

from kiss.providers.types import ProviderProfile


def make_profile(name: str, free_models: tuple[str, ...] = ()) -> ProviderProfile:
    return ProviderProfile(
        name=name,
        auth_type="api_key",
        base_url="https://example.com",
        free_models=free_models,
    )


# --- Task 74: ProviderProfile.free_models ---


def test_free_models_default_empty():
    p = make_profile("test")
    assert p.free_models == ()


def test_free_models_type_is_tuple():
    p = make_profile("test", free_models=("gpt-4o-mini",))
    assert isinstance(p.free_models, tuple)


def test_free_models_openai_profile():
    from kiss.providers.registry import _REGISTRY, _ensure_discovered

    _ensure_discovered()
    profile = _REGISTRY.get("openai")
    assert profile is not None
    assert "gpt-4o-mini" in profile.free_models


def test_free_models_gemini_profile():
    from kiss.providers.registry import _REGISTRY, _ensure_discovered

    _ensure_discovered()
    profile = _REGISTRY.get("gemini")
    assert profile is not None
    assert "gemini-2.0-flash-lite" in profile.free_models
    assert "gemini-2.0-flash" in profile.free_models


def test_free_models_bare_no_prefix():
    from kiss.providers.registry import _REGISTRY, _ensure_discovered

    _ensure_discovered()
    for name, profile in _REGISTRY.items():
        for model in profile.free_models:
            # Must not be double-prefixed as "provider_name/model_id".
            # Models may contain "/" legitimately (e.g. OpenRouter "org/model:free").
            assert not model.startswith(f"{name}/"), (
                f"{name}.free_models entry {model!r} must not use provider as prefix"
            )
