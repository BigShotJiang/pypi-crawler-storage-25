from __future__ import annotations

from dataclasses import dataclass
from typing import TypedDict

import pytest

from kiss.core.settings import Settings
from kiss.providers import manager


@dataclass
class _FakeResponse:
    data: dict[str, object]

    @property
    def is_success(self) -> bool:
        return True

    def json(self) -> dict[str, object]:
        return self.data


class _GetCall(TypedDict):
    url: str
    headers: dict[str, str]
    timeout: float


class _FakeAsyncClient:
    instances: list["_FakeAsyncClient"] = []

    def __init__(self, **kwargs: object) -> None:
        self.kwargs = kwargs
        self.get_calls: list[_GetCall] = []
        type(self).instances.append(self)

    async def __aenter__(self) -> "_FakeAsyncClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        return None

    async def get(
        self,
        url: str,
        *,
        headers: dict[str, str],
        timeout: float,
    ) -> _FakeResponse:
        self.get_calls.append({"url": url, "headers": headers, "timeout": timeout})
        return _FakeResponse(
            {
                "data": [
                    {"id": "gpt-4.1", "capabilities": {"type": "chat"}},
                    {"id": "ignored", "capabilities": {"type": "autocomplete"}},
                    {"id": "gpt-4o", "capabilities": {"type": "chat"}},
                ]
            }
        )


@pytest.mark.asyncio
async def test_fetch_copilot_models_uses_env_friendly_client(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    settings = Settings(model="copilot:gpt-4o")

    async def fake_get_copilot_token() -> tuple[str, float]:
        return "session-token", 1740.0

    _FakeAsyncClient.instances.clear()
    monkeypatch.setattr(manager, "_get_copilot_token", fake_get_copilot_token)
    monkeypatch.setattr(manager.httpx, "AsyncClient", _FakeAsyncClient)

    models = await manager._fetch_models_raw(settings, "copilot")

    assert models == ["gpt-4.1", "gpt-4o"]
    assert len(_FakeAsyncClient.instances) == 1
    client = _FakeAsyncClient.instances[0]
    assert client.kwargs["follow_redirects"] is True
    assert client.kwargs["trust_env"] is True
    assert client.get_calls[0]["url"] == "https://api.githubcopilot.com/models"
    assert client.get_calls[0]["headers"]["Authorization"] == "Bearer session-token"


@pytest.mark.asyncio
async def test_copilot_auth_preserves_refresh_cause(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    auth = manager._CopilotAuth()

    async def fake_get_copilot_token() -> str:
        raise ConnectionError("DNS failed")

    monkeypatch.setattr(manager, "_get_copilot_token", fake_get_copilot_token)

    request = manager.httpx.Request(
        "GET", "https://api.githubcopilot.com/chat/completions"
    )
    flow = auth.async_auth_flow(request)

    with pytest.raises(
        RuntimeError, match="Copilot token unavailable; refresh failed"
    ) as exc_info:
        await flow.__anext__()

    assert isinstance(exc_info.value.__cause__, ConnectionError)
    assert str(exc_info.value.__cause__) == "DNS failed"
