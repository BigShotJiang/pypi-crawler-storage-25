"""Tests for _sanitize_response tree-walk sanitization."""

from __future__ import annotations

from kiss.providers.normalization import _sanitize_response


def test_none_returns_none():
    assert _sanitize_response(None) is None


def test_primitives_pass_through():
    assert _sanitize_response(42) == 42
    assert _sanitize_response(3.14) == 3.14
    assert _sanitize_response(True) is True


def test_plain_string_no_creds():
    assert _sanitize_response("hello world") == "hello world"


def test_string_with_inline_credential_masked():
    result = _sanitize_response("api_key='sk-abcdefghijklmnop'")
    assert "sk-abcdefghijklmnop" not in result
    assert "api_key=" in result


def test_dict_credential_key_masked():
    result = _sanitize_response({"api_key": "sk-supersecret123456"})
    assert result["api_key"] != "sk-supersecret123456"
    assert "sk-supersecret123456" not in str(result)


def test_dict_non_credential_key_preserved():
    result = _sanitize_response({"model": "gpt-4o", "temperature": 0.7})
    assert result["model"] == "gpt-4o"
    assert result["temperature"] == 0.7


def test_nested_dict_credential_masked():
    result = _sanitize_response(
        {
            "provider": "openai",
            "auth": {"api_key": "sk-verysecret9999"},
        }
    )
    assert result["auth"]["api_key"] != "sk-verysecret9999"
    assert "sk-verysecret9999" not in str(result)


def test_list_of_strings_masked():
    result = _sanitize_response(["normal", "token='abc12345678'"])
    assert result[0] == "normal"
    assert "abc12345678" not in result[1]


def test_large_response_not_truncated():
    big = {"data": "x" * 10_000, "api_key": "sk-secret99999"}
    result = _sanitize_response(big)
    assert result != "<truncated>"
    assert len(result["data"]) == 10_000
    assert "sk-secret99999" not in str(result)


def test_cycle_detection():
    d: dict = {"key": "value"}
    d["self"] = d  # type: ignore[assignment]
    result = _sanitize_response(d)
    assert result["self"] == "<cycle>"


def test_depth_limit():
    # Build deeply nested structure
    obj: dict = {}
    current = obj
    for _ in range(15):
        current["child"] = {}
        current = current["child"]
    current["leaf"] = "value"

    result = _sanitize_response(obj)
    # Should not raise; deepest nodes replaced with depth-limit sentinel
    assert isinstance(result, dict)


def test_object_attributes_walked():
    class Resp:
        def __init__(self) -> None:
            self.model = "gpt-4o"
            self.api_key = "sk-hidden12345"
            self.content = "Hello!"

    result = _sanitize_response(Resp())
    assert isinstance(result, dict)
    assert result.get("model") == "gpt-4o"
    assert result.get("content") == "Hello!"
    assert "sk-hidden12345" not in str(result)


def test_token_key_masked():
    result = _sanitize_response({"token": "ghp_secret1234567890"})
    assert "ghp_secret1234567890" not in str(result)


def test_password_key_masked():
    result = _sanitize_response({"password": "hunter2reallylong"})
    assert "hunter2reallylong" not in str(result)
