"""Ensure auth strategies are loaded before any provider tests run."""

import kiss.providers.manager  # noqa: F401
