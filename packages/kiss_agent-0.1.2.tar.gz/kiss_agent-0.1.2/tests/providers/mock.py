"""MockProvider and MockAuthStrategy — test doubles for provider layer tests."""

from __future__ import annotations

from kiss.providers.types import ProviderProfile


class MockAuthStrategy:
    """Configurable AuthStrategy double for unit tests."""

    auth_type = "mock"

    def __init__(self, credential: str | None = "test-key") -> None:
        self._credential = credential
        self.resolve_calls: list[tuple[ProviderProfile, object]] = []
        self.register_calls: list[tuple[ProviderProfile, str | None]] = []

    def resolve(
        self, profile: ProviderProfile, settings: object, _depth: int = 0
    ) -> str | None:
        self.resolve_calls.append((profile, settings))
        return self._credential

    def register(self, profile: ProviderProfile, credentials: str | None) -> None:
        self.register_calls.append((profile, credentials))

    async def run(self, app: object, on_event=None) -> str | None:
        return self._credential


def make_profile(
    name: str = "test-provider",
    auth_type: str = "mock",
    base_url: str = "https://test.example.com",
    **kwargs,
) -> ProviderProfile:
    """Factory for ProviderProfile test fixtures."""
    return ProviderProfile(name=name, auth_type=auth_type, base_url=base_url, **kwargs)
