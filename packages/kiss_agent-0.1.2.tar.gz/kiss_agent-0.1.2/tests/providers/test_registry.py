"""Unit tests for ProviderRegistry: registration, collision, cycles, finalization."""

from __future__ import annotations

import pytest

import kiss.providers.registry as reg_module
from kiss.providers.registry import (
    _detect_fallback_cycles,
    get_provider_profile,
    list_providers,
    register_provider,
)
from tests.providers.mock import MockAuthStrategy, make_profile


@pytest.fixture(autouse=True)
def reset_registry(monkeypatch):
    """Isolate each test with a fresh registry state."""
    monkeypatch.setattr(reg_module, "_REGISTRY", {})
    monkeypatch.setattr(reg_module, "_ALIASES", {})
    monkeypatch.setattr(
        reg_module, "_discovery_state", reg_module._DS.DONE
    )  # skip auto-discovery
    # Register the mock strategy so finalization doesn't strip mock profiles
    from kiss.providers.strategies import _STRATEGIES

    original = dict(_STRATEGIES)
    _STRATEGIES["mock"] = MockAuthStrategy()
    yield
    _STRATEGIES.clear()
    _STRATEGIES.update(original)


# ── Registration ──────────────────────────────────────────────────────────────


def test_register_provider_adds_to_registry():
    p = make_profile("alpha")
    register_provider(p)
    assert get_provider_profile("alpha") is p


def test_register_provider_adds_aliases():
    p = make_profile("alpha", aliases=("a", "al"))
    register_provider(p)
    assert get_provider_profile("a") is p
    assert get_provider_profile("al") is p


def test_register_duplicate_skips(caplog):
    p1 = make_profile("alpha")
    p2 = make_profile("alpha", base_url="https://other.example.com")
    register_provider(p1)
    with caplog.at_level("WARNING", logger="kiss.providers.registry"):
        register_provider(p2)
    assert get_provider_profile("alpha") is p1  # first wins
    assert any("already registered" in r.message for r in caplog.records)


def test_register_alias_collision_skips_alias(caplog):
    p1 = make_profile("alpha", aliases=("shared",))
    p2 = make_profile("beta", aliases=("shared",))
    register_provider(p1)
    with caplog.at_level("WARNING", logger="kiss.providers.registry"):
        register_provider(p2)
    # beta is registered but "shared" alias still points to alpha
    assert get_provider_profile("beta") is p2
    assert get_provider_profile("shared") is p1
    assert any("conflicts" in r.message for r in caplog.records)


def test_register_user_global_replaces_bundled(monkeypatch):
    p_bundled = make_profile("alpha", base_url="https://bundled.example.com")
    p_user = make_profile("alpha", base_url="https://user.example.com")
    register_provider(p_bundled)

    reg_module._tls.user_global_tier = True
    register_provider(p_user)
    reg_module._tls.user_global_tier = False

    assert get_provider_profile("alpha") is p_user


def test_get_provider_profile_missing_returns_none():
    assert get_provider_profile("nonexistent") is None


def test_list_providers_returns_all():
    p1 = make_profile("a")
    p2 = make_profile("b")
    register_provider(p1)
    register_provider(p2)
    names = {p.name for p in list_providers()}
    assert names == {"a", "b"}


# ── Cycle detection ───────────────────────────────────────────────────────────


def test_detect_no_cycles_empty():
    assert _detect_fallback_cycles() == []


def test_detect_no_cycles_no_cross_provider():
    register_provider(make_profile("alpha", fallback_models=("model-a", "model-b")))
    assert _detect_fallback_cycles() == []


def test_detect_no_cycle_one_direction():
    register_provider(make_profile("alpha", fallback_models=("beta/model-x",)))
    register_provider(make_profile("beta", fallback_models=("model-y",)))
    assert _detect_fallback_cycles() == []


def test_detect_direct_cycle():
    register_provider(make_profile("alpha", fallback_models=("beta/model-x",)))
    register_provider(make_profile("beta", fallback_models=("alpha/model-y",)))
    cycles = _detect_fallback_cycles()
    assert set(cycles) == {"alpha", "beta"}


def test_detect_transitive_cycle():
    register_provider(make_profile("a", fallback_models=("b/m",)))
    register_provider(make_profile("b", fallback_models=("c/m",)))
    register_provider(make_profile("c", fallback_models=("a/m",)))
    cycles = set(_detect_fallback_cycles())
    assert cycles == {"a", "b", "c"}


# ── Finalization ──────────────────────────────────────────────────────────────


def test_finalize_removes_cycle_members():
    from kiss.providers.registry import _finalize_registry

    register_provider(make_profile("alpha", fallback_models=("beta/m",)))
    register_provider(make_profile("beta", fallback_models=("alpha/m",)))
    _finalize_registry()
    assert get_provider_profile("alpha") is None
    assert get_provider_profile("beta") is None


def test_finalize_removes_unknown_auth_type():
    from kiss.providers.registry import _finalize_registry

    register_provider(make_profile("alpha", auth_type="unknown_strategy"))
    _finalize_registry()
    assert get_provider_profile("alpha") is None


def test_finalize_keeps_valid_profiles():
    from kiss.providers.registry import _finalize_registry

    register_provider(make_profile("alpha"))
    _finalize_registry()
    assert get_provider_profile("alpha") is not None
