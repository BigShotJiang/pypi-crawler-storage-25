"""Tests for ProviderHealth state transitions and aggregate checks."""

from __future__ import annotations

import kiss.providers.health as health_module
from kiss.providers.health import (
    ProviderHealth,
    all_providers_unhealthy,
    get_provider_health,
    health_snapshot,
)
import pytest


@pytest.fixture(autouse=True)
def reset_health(monkeypatch):
    monkeypatch.setattr(health_module, "_HEALTH", {})


def test_initial_status_is_unknown():
    h = ProviderHealth()
    assert h.status == "unknown"
    assert h.failure_count == 0


def test_record_success_resets_to_healthy():
    h = ProviderHealth()
    h.record_failure("bad")
    h.record_success()
    assert h.status == "healthy"
    assert h.failure_count == 0
    assert h.last_error == ""


def test_record_failure_increments_count():
    h = ProviderHealth()
    h.record_failure("err1")
    assert h.failure_count == 1
    assert h.status == "degraded"
    assert h.last_error == "err1"


def test_record_failure_threshold_unhealthy():
    h = ProviderHealth()
    for i in range(3):
        h.record_failure("err")
    assert h.status == "unhealthy"


def test_record_failure_truncates_long_error():
    h = ProviderHealth()
    h.record_failure("x" * 500)
    assert len(h.last_error) == 200


def test_get_provider_health_creates_on_miss():
    h = get_provider_health("new-provider")
    assert h.status == "unknown"


def test_get_provider_health_same_instance():
    h1 = get_provider_health("alpha")
    h2 = get_provider_health("alpha")
    assert h1 is h2


def test_all_providers_unhealthy_false_when_one_healthy():
    h = get_provider_health("alpha")
    h.record_success()
    get_provider_health("beta").record_failure("err")
    get_provider_health("beta").record_failure("err")
    get_provider_health("beta").record_failure("err")
    assert not all_providers_unhealthy(["alpha", "beta"])


def test_all_providers_unhealthy_true():
    for name in ["a", "b"]:
        h = get_provider_health(name)
        for _ in range(3):
            h.record_failure("err")
    assert all_providers_unhealthy(["a", "b"])


def test_all_providers_unhealthy_empty_list():
    assert not all_providers_unhealthy([])


def test_health_snapshot_structure():
    h = get_provider_health("alpha")
    h.record_success()
    snap = health_snapshot()
    assert "alpha" in snap
    assert snap["alpha"]["status"] == "healthy"
    assert "failure_count" in snap["alpha"]
    assert "last_error" in snap["alpha"]
    assert "last_checked" in snap["alpha"]
