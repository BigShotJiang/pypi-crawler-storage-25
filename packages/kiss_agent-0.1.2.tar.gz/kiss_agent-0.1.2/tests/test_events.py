"""Tests for typed event dataclasses."""

from __future__ import annotations

from unittest.mock import Mock, patch

from kiss.agent.events import (
    ContextFiltered,
    PipelineDone,
    PipelineStarted,
    RetryAttempted,
    TemplateResolved,
    WorkerDone,
    WorkerFailed,
    WorkerRetryExhausted,
    WorkerSpawned,
)


class TestEventEmission:
    def test_pipeline_started_emits_info(self) -> None:
        tracer = Mock()
        with patch("kiss.agent.events.get_current_tracer", return_value=tracer):
            PipelineStarted(task_hash="abc123", route=["researcher"]).emit()
        tracer.event.assert_called_once()
        call_kwargs = tracer.event.call_args
        assert call_kwargs[0][0] == "pipeline_started"

    def test_pipeline_done_emits_info(self) -> None:
        tracer = Mock()
        with patch("kiss.agent.events.get_current_tracer", return_value=tracer):
            PipelineDone(
                task_hash="abc123", route=["researcher"], result_count=1
            ).emit()
        tracer.event.assert_called_once()

    def test_worker_spawned_emits_info(self) -> None:
        tracer = Mock()
        with patch("kiss.agent.events.get_current_tracer", return_value=tracer):
            WorkerSpawned(role="researcher").emit()
        tracer.event.assert_called_once()

    def test_worker_done_emits_info(self) -> None:
        tracer = Mock()
        with patch("kiss.agent.events.get_current_tracer", return_value=tracer):
            WorkerDone(role="coder", result_size=512).emit()
        tracer.event.assert_called_once()

    def test_worker_failed_emits_warning(self) -> None:
        tracer = Mock()
        with patch("kiss.agent.events.get_current_tracer", return_value=tracer):
            WorkerFailed(role="coder", error="bad json", attempt=1).emit()
        tracer.event.assert_called_once()

    def test_worker_retry_exhausted_emits_error(self) -> None:
        tracer = Mock()
        with patch("kiss.agent.events.get_current_tracer", return_value=tracer):
            WorkerRetryExhausted(role="coder", attempts=3, error="bad json").emit()
        tracer.event.assert_called_once()

    def test_context_filtered_includes_lens(self) -> None:
        tracer = Mock()
        with patch("kiss.agent.events.get_current_tracer", return_value=tracer):
            ContextFiltered(role="researcher", original_len=10, filtered_len=0).emit()
        call_kwargs = tracer.event.call_args[1]
        assert call_kwargs["original_len"] == 10
        assert call_kwargs["filtered_len"] == 0

    def test_template_resolved_emits_info(self) -> None:
        tracer = Mock()
        with patch("kiss.agent.events.get_current_tracer", return_value=tracer):
            TemplateResolved(role="researcher", source="default", path="/p").emit()
        tracer.event.assert_called_once()
        assert tracer.event.call_args[0][0] == "template_resolved"

    def test_retry_attempted_emits_warning(self) -> None:
        tracer = Mock()
        with patch("kiss.agent.events.get_current_tracer", return_value=tracer):
            RetryAttempted(role="coder", attempt=1, error="bad json").emit()
        tracer.event.assert_called_once()
        assert tracer.event.call_args[0][0] == "retry_attempted"


class TestEventFields:
    def test_all_events_have_timestamp(self) -> None:
        events = [
            PipelineStarted(task_hash="x", route=[]),
            PipelineDone(task_hash="x", route=[], result_count=0),
            WorkerSpawned(role="researcher"),
            WorkerDone(role="researcher", result_size=0),
            WorkerFailed(role="researcher", error="e", attempt=1),
            WorkerRetryExhausted(role="researcher", attempts=1, error="e"),
            ContextFiltered(role="researcher", original_len=0, filtered_len=0),
            TemplateResolved(role="researcher", source="default", path="/p"),
            RetryAttempted(role="researcher", attempt=1, error="e"),
        ]
        for event in events:
            assert event.timestamp != "", f"{type(event).__name__} missing timestamp"
