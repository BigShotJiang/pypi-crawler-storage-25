from __future__ import annotations

import pytest

from kiss.ui.rich.statusbar_backend import RichStatusBarBackend
from kiss.ui.shared import describe_exception


def _make_wrapped_connection_error() -> BaseException:
    try:
        raise ConnectionError("DNS failed")
    except ConnectionError as cause:
        try:
            raise RuntimeError("Connection error.") from cause
        except RuntimeError as error:
            return error


def test_describe_exception_includes_cause_chain() -> None:
    error = _make_wrapped_connection_error()

    description = describe_exception(error)

    assert "RuntimeError: Connection error." in description
    assert "ConnectionError: DNS failed" in description


@pytest.mark.asyncio
async def test_ensure_copilot_auth_clears_rejected_token_and_reauths(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    backend = RichStatusBarBackend()
    printed: list[str] = []

    monkeypatch.setattr(
        "kiss.providers.copilot_auth.load_github_token",
        lambda: "stored-token",
    )

    async def fake_probe() -> str:
        raise RuntimeError("Copilot token exchange failed (401)")

    monkeypatch.setattr("kiss.providers.manager.probe_copilot_token", fake_probe)
    cleared: list[bool] = []
    monkeypatch.setattr(
        "kiss.providers.copilot_auth.clear_github_token",
        lambda: cleared.append(True),
    )

    async def fake_device_auth(on_code=None) -> bool:
        return True

    monkeypatch.setattr(
        "kiss.providers.copilot_auth.run_copilot_device_auth",
        fake_device_auth,
    )
    monkeypatch.setattr(
        backend.console,
        "print",
        lambda *args, **kwargs: printed.append(" ".join(str(a) for a in args)),
    )

    ready = await backend._ensure_copilot_auth()

    assert ready is True
    assert cleared == [True]
    assert any("re-authenticating" in line.lower() for line in printed)
