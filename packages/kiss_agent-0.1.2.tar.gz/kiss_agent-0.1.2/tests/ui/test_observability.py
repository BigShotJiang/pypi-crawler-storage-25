"""Tests for observability ring buffers, grouped activity, and truncation store."""

from __future__ import annotations

import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

from kiss.ui.observability import (
    ChatActivityBuffer,
    ChatActivityEntry,
    LogEntry,
    LogsBuffer,
    MetricSample,
    MetricsBuffer,
    ObservabilityState,
    ThoughtsBuffer,
    TraceEvent,
    TracesBuffer,
)
from kiss.ui.activity import GroupActivityTracker, _GROUP_THRESHOLD


# ── ChatActivityBuffer ────────────────────────────────────────────────────────


def test_chat_activity_buffer_evicts_oldest_first() -> None:
    buf = ChatActivityBuffer(max_size=3)
    for i in range(4):
        buf.append(
            ChatActivityEntry(timestamp="t", kind="tool_call", label=f"call-{i}")
        )
    entries = buf.entries()
    assert len(entries) == 3
    labels = [e.label for e in entries]
    assert "call-0" not in labels
    assert "call-3" in labels


def test_chat_activity_buffer_get_by_group() -> None:
    buf = ChatActivityBuffer()
    buf.append(
        ChatActivityEntry(
            timestamp="t", kind="tool_call", label="a", activity_id="act-0001"
        )
    )
    buf.append(
        ChatActivityEntry(
            timestamp="t", kind="tool_call", label="b", activity_id="act-0002"
        )
    )
    buf.append(
        ChatActivityEntry(
            timestamp="t", kind="tool_result", label="c", activity_id="act-0001"
        )
    )
    grp1 = buf.get_by_activity("act-0001")
    assert len(grp1) == 2
    assert all(e.activity_id == "act-0001" for e in grp1)


def test_chat_activity_buffer_get_by_group_legacy_alias() -> None:
    buf = ChatActivityBuffer()
    buf.append(
        ChatActivityEntry(
            timestamp="t", kind="tool_call", label="a", activity_id="grp-0001"
        )
    )
    grp1 = buf.get_by_group("grp-0001")
    assert len(grp1) == 1


def test_chat_activity_buffer_clear() -> None:
    buf = ChatActivityBuffer()
    buf.append(ChatActivityEntry(timestamp="t", kind="tool_call", label="x"))
    buf.clear()
    assert len(buf) == 0


# ── LogsBuffer ────────────────────────────────────────────────────────────────


def test_logs_buffer_evicts_oldest_first() -> None:
    buf = LogsBuffer(max_size=2)
    buf.append(LogEntry(timestamp="t1", level="info", message="first"))
    buf.append(LogEntry(timestamp="t2", level="info", message="second"))
    buf.append(LogEntry(timestamp="t3", level="info", message="third"))
    entries = buf.entries()
    assert len(entries) == 2
    assert entries[0].message == "second"
    assert entries[1].message == "third"


# ── MetricsBuffer ─────────────────────────────────────────────────────────────


def test_metrics_buffer_retains_latest_per_key() -> None:
    buf = MetricsBuffer()
    ts = "2026-01-01T00:00:00"
    buf.record(MetricSample(timestamp=ts, key="cost_usd", value=0.01))
    buf.record(MetricSample(timestamp=ts, key="cost_usd", value=0.05))
    buf.record(MetricSample(timestamp=ts, key="input_tokens", value=100.0))
    latest = buf.latest_values()
    assert latest["cost_usd"] == 0.05
    assert latest["input_tokens"] == 100.0


def test_metrics_buffer_ring_evicts_oldest_samples() -> None:
    buf = MetricsBuffer(max_samples=3)
    ts = "t"
    for i in range(4):
        buf.record(MetricSample(timestamp=ts, key="x", value=float(i)))
    samples = buf.samples()
    assert len(samples) == 3
    values = [s.value for s in samples]
    assert 0.0 not in values
    assert 3.0 in values


# ── TracesBuffer ──────────────────────────────────────────────────────────────


def test_traces_buffer_evicts_completed_first() -> None:
    buf = TracesBuffer(max_size=2)
    active = TraceEvent(
        timestamp="t",
        tool_name="x",
        call_id="c1",
        kind="call",
        label="active",
        is_complete=False,
    )
    done = TraceEvent(
        timestamp="t",
        tool_name="y",
        call_id="c2",
        kind="result",
        label="done",
        is_complete=True,
    )
    buf.append(active)
    buf.append(done)
    new = TraceEvent(
        timestamp="t",
        tool_name="z",
        call_id="c3",
        kind="call",
        label="new",
        is_complete=False,
    )
    buf.append(new)
    events = buf.events()
    ids = [e.call_id for e in events]
    assert "c1" in ids  # active preserved
    assert "c2" not in ids  # completed evicted
    assert "c3" in ids  # new added


def test_traces_buffer_evicts_oldest_when_all_active() -> None:
    buf = TracesBuffer(max_size=2)
    for i in range(3):
        buf.append(
            TraceEvent(
                timestamp="t",
                tool_name="x",
                call_id=f"c{i}",
                kind="call",
                label=f"l{i}",
                is_complete=False,
            )
        )
    events = buf.events()
    assert len(events) == 2
    assert events[0].call_id == "c1"


# ── ThoughtsBuffer ────────────────────────────────────────────────────────────


def test_thoughts_buffer_stores_chunks_by_id() -> None:
    buf = ThoughtsBuffer()
    buf.append("th-1", "hello ")
    buf.append("th-1", "world")
    assert buf.get("th-1") == ["hello ", "world"]


def test_thoughts_buffer_ignores_null_id() -> None:
    buf = ThoughtsBuffer()
    buf.append(None, "transient")
    assert len(buf) == 0
    assert buf.get("missing") == []


def test_thoughts_buffer_evicts_per_stream() -> None:
    buf = ThoughtsBuffer(max_size=2)
    for i in range(4):
        buf.append("th-1", f"chunk-{i}")
    assert buf.get("th-1") == ["chunk-2", "chunk-3"]


def test_thoughts_buffer_independent_streams() -> None:
    buf = ThoughtsBuffer()
    buf.append("th-1", "a")
    buf.append("th-2", "b")
    assert buf.get("th-1") == ["a"]
    assert buf.get("th-2") == ["b"]


def test_thoughts_buffer_clear() -> None:
    buf = ThoughtsBuffer()
    buf.append("th-1", "x")
    buf.clear()
    assert len(buf) == 0
    assert buf.get("th-1") == []


# ── ObservabilityState ────────────────────────────────────────────────────────


def test_observability_state_aggregates_all_buffers() -> None:
    obs = ObservabilityState()
    obs.logs.append(LogEntry(timestamp="t", level="info", message="x"))
    obs.metrics.record(MetricSample(timestamp="t", key="k", value=1.0))
    assert len(obs.logs) == 1
    assert len(obs.metrics) == 1
    obs.clear()
    assert len(obs.logs) == 0
    assert len(obs.metrics) == 0


def test_observability_state_clears_thoughts() -> None:
    obs = ObservabilityState()
    obs.thoughts.append("th-1", "chunk")
    assert len(obs.thoughts) == 1
    obs.clear()
    assert len(obs.thoughts) == 0


# ── GroupActivityTracker ──────────────────────────────────────────────────────


def test_group_tracker_no_group_below_threshold() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    for i in range(_GROUP_THRESHOLD - 1):
        result = tracker.on_tool_call("read_file", f"id-{i}", f"file-{i}.py")
        assert result is None
    assert not tracker.is_grouping()


def test_group_tracker_groups_at_threshold() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    for i in range(_GROUP_THRESHOLD):
        tracker.on_tool_call("read_file", f"id-{i}", f"file-{i}.py")
    assert tracker.is_grouping()


def test_group_tracker_flush_emits_summary() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    for i in range(_GROUP_THRESHOLD):
        tracker.on_tool_call("read_file", f"id-{i}", f"file-{i}.py")
    summary = tracker.flush()
    assert summary is not None
    assert summary.call_count == _GROUP_THRESHOLD
    assert summary.tool_name == "read_file"
    assert summary.activity_id.startswith("act-")


def test_group_tracker_non_groupable_tool_flushes_pending() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    for i in range(_GROUP_THRESHOLD):
        tracker.on_tool_call("read_file", f"id-{i}", f"f{i}")
    # Non-groupable tool should flush the pending group
    result = tracker.on_tool_call("write_file", "wid", "out.py")
    assert result is not None
    assert result.tool_name == "read_file"


def test_group_tracker_detail_returns_entries() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    for i in range(_GROUP_THRESHOLD):
        tracker.on_tool_call("search_code", f"id-{i}", f"pattern-{i}")
        tracker.on_tool_result(f"id-{i}", f"result-{i}")
    summary = tracker.flush()
    assert summary is not None
    detail = tracker.get_detail(summary.activity_id)
    assert detail is not None
    assert len(detail) >= _GROUP_THRESHOLD


def test_group_tracker_format_detail_expired() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    result = tracker.format_detail("grp-9999")
    assert (
        "expired" in result.lower()
        or "not found" in result.lower()
        or "grp-9999" in result
    )


# ── TruncationStore ───────────────────────────────────────────────────────────


def test_truncation_store_persist_and_load() -> None:
    import kiss.ui.truncation_store as ts

    original_dir = ts._STORE_DIR
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            ts._STORE_DIR = Path(tmpdir) / "tool-output"
            content = "large tool output " * 100
            path = ts.persist_truncated_output(content)
            assert path is not None
            loaded = ts.load_truncated_output(path)
            assert loaded == content
    finally:
        ts._STORE_DIR = original_dir


def test_truncation_store_load_missing_returns_none() -> None:
    from kiss.ui.truncation_store import load_truncated_output

    result = load_truncated_output("/nonexistent/path/xyz.txt")
    assert result is None


def test_truncation_store_cleanup_deletes_expired() -> None:
    import kiss.ui.truncation_store as ts

    original_dir = ts._STORE_DIR
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            ts._STORE_DIR = Path(tmpdir) / "tool-output"
            ts._STORE_DIR.mkdir(parents=True)

            # Write a file and backdate its mtime past retention
            old_path = ts._STORE_DIR / "old.txt"
            old_path.write_text("old content", encoding="utf-8")
            old_mtime = (datetime.now(tz=timezone.utc) - timedelta(days=8)).timestamp()
            import os

            os.utime(old_path, (old_mtime, old_mtime))

            # Write a fresh file
            new_path = ts._STORE_DIR / "new.txt"
            new_path.write_text("new content", encoding="utf-8")

            deleted = ts.cleanup_expired()
            assert deleted == 1
            assert not old_path.exists()
            assert new_path.exists()
    finally:
        ts._STORE_DIR = original_dir


def test_truncation_store_cleanup_bounded() -> None:
    import kiss.ui.truncation_store as ts

    original_dir = ts._STORE_DIR
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            ts._STORE_DIR = Path(tmpdir) / "tool-output"
            ts._STORE_DIR.mkdir(parents=True)

            old_mtime = (datetime.now(tz=timezone.utc) - timedelta(days=8)).timestamp()
            import os

            for i in range(5):
                p = ts._STORE_DIR / f"old-{i}.txt"
                p.write_text(f"old {i}", encoding="utf-8")
                os.utime(p, (old_mtime, old_mtime))

            # Cap at 3 inspections — should delete at most 3
            deleted = ts.cleanup_expired(max_entries=3)
            assert deleted <= 3
    finally:
        ts._STORE_DIR = original_dir
