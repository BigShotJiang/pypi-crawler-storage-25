"""Readability regression tests for visual hierarchy, state prominence, and token system."""

from __future__ import annotations

from rich.console import Console

from kiss.data.ui_tokens import DEFAULT_TOKENS
from kiss.ui.rich.theme import build_rich_theme, build_tcss_variables
from kiss.ui.shared import ToolResultDisplay, TruncationMeta


# ── Token hierarchy ───────────────────────────────────────────────────────────


def test_default_tokens_error_distinct_from_warning() -> None:
    assert DEFAULT_TOKENS.text_error != DEFAULT_TOKENS.text_warning


def test_default_tokens_muted_distinct_from_primary() -> None:
    assert DEFAULT_TOKENS.text_muted != DEFAULT_TOKENS.text_primary


def test_default_tokens_subtle_quieter_convention() -> None:
    # subtle is used for separators — should differ from muted (hints)
    assert DEFAULT_TOKENS.text_subtle != DEFAULT_TOKENS.text_muted


def test_default_tokens_border_active_distinct_from_default() -> None:
    assert DEFAULT_TOKENS.border_active != DEFAULT_TOKENS.border_default


def test_default_tokens_status_blocked_uses_error_palette() -> None:
    # blocked states should visually align with error urgency
    assert DEFAULT_TOKENS.status_blocked == DEFAULT_TOKENS.text_error


def test_default_tokens_status_warning_uses_warning_palette() -> None:
    assert DEFAULT_TOKENS.status_warning == DEFAULT_TOKENS.text_warning


# ── Rich theme registration ───────────────────────────────────────────────────


def test_rich_theme_registers_all_required_styles() -> None:
    theme = build_rich_theme()
    required = [
        "ui.text.primary",
        "ui.text.muted",
        "ui.text.subtle",
        "ui.text.success",
        "ui.text.warning",
        "ui.text.error",
        "ui.text.accent",
        "ui.border.default",
        "ui.border.active",
        "ui.border.subtle",
        "ui.status.idle",
        "ui.status.streaming",
        "ui.status.running",
        "ui.status.blocked",
        "ui.status.compacting",
        "ui.status.warning",
        "ui.status.error",
    ]
    for name in required:
        assert name in theme.styles, f"Missing theme style: {name}"


def test_rich_theme_console_renders_semantic_styles() -> None:
    from io import StringIO

    theme = build_rich_theme()
    buf = StringIO()
    console = Console(
        theme=theme, file=buf, highlight=False, markup=True, width=80, no_color=False
    )
    # Should not raise — semantic style names must resolve
    console.print("[ui.text.muted]muted text[/ui.text.muted]")
    console.print("[ui.text.error]error text[/ui.text.error]")
    console.print("[ui.text.success]ok text[/ui.text.success]")
    output = buf.getvalue()
    assert "muted text" in output
    assert "error text" in output
    assert "ok text" in output


def test_rich_theme_error_style_differs_from_muted() -> None:
    theme = build_rich_theme()
    error_style = theme.styles.get("ui.text.error")
    muted_style = theme.styles.get("ui.text.muted")
    assert error_style is not None
    assert muted_style is not None
    assert str(error_style) != str(muted_style)


# ── TCSS variable generation ──────────────────────────────────────────────────


def test_tcss_variables_cover_all_status_tokens() -> None:
    tcss = build_tcss_variables()
    required = [
        "$ui-status-blocked",
        "$ui-status-error",
        "$ui-status-warning",
        "$ui-status-streaming",
        "$ui-status-running",
        "$ui-status-compacting",
    ]
    for var in required:
        assert var in tcss, f"Missing TCSS variable: {var}"


def test_tcss_variables_cover_border_tokens() -> None:
    tcss = build_tcss_variables()
    assert "$ui-border-active" in tcss
    assert "$ui-border-subtle" in tcss


# ── Tool-output display hierarchy ─────────────────────────────────────────────


def test_tool_result_error_status_distinct() -> None:
    ok = ToolResultDisplay(title="Read File", summary="ok")
    err = ToolResultDisplay(
        title="Read File", summary="permission denied", status="error"
    )
    assert ok.status == "ok"
    assert err.status == "error"
    assert ok.status != err.status


def test_tool_result_truncation_meta_visible() -> None:
    display = ToolResultDisplay(
        title="Run Bash",
        summary="output truncated",
        truncation_meta=TruncationMeta(truncated=True, persisted_path="/tmp/out.txt"),
    )
    assert display.truncation_meta is not None
    assert display.truncation_meta.truncated is True
    assert display.truncation_meta.persisted_path == "/tmp/out.txt"


# ── Transcript width ──────────────────────────────────────────────────────────


def test_transcript_max_cols_defined() -> None:
    from kiss.ui.rich.statusbar_backend import _TRANSCRIPT_MAX_COLS

    assert _TRANSCRIPT_MAX_COLS == 100


def test_transcript_width_bounded_by_max_cols() -> None:
    from kiss.ui.rich.statusbar_backend import RichStatusBarBackend

    backend = RichStatusBarBackend()
    # Width should never exceed the constant
    assert backend._transcript_width() <= 100


# ── Active state prominence ───────────────────────────────────────────────────


def test_status_blocked_is_visually_prominent() -> None:
    # blocked must differ from idle — both in value and should not be subtle
    assert DEFAULT_TOKENS.status_blocked != DEFAULT_TOKENS.status_idle
    assert DEFAULT_TOKENS.status_blocked != DEFAULT_TOKENS.text_subtle


def test_status_error_is_visually_prominent() -> None:
    assert DEFAULT_TOKENS.status_error != DEFAULT_TOKENS.status_idle
    assert DEFAULT_TOKENS.status_error != DEFAULT_TOKENS.text_subtle


# ── ASK_USER prompt readability ───────────────────────────────────────────────


def test_ask_user_reply_has_distinct_outcome_values() -> None:
    from kiss.core.events import AskUserReply

    assert AskUserReply(outcome="selected").outcome == "selected"
    assert AskUserReply(outcome="free_text").outcome == "free_text"
    assert AskUserReply(outcome="cancelled").outcome == "cancelled"


def test_ask_user_request_keyboard_guidance_fields_present() -> None:
    """Request carries enough metadata for backends to render keyboard guidance."""
    import asyncio

    async def _check() -> None:
        from kiss.core.events import AskUserRequest, QuestionOption

        req = AskUserRequest(
            question="Pick one?",
            type="choice",
            options=[
                QuestionOption(id="a", label="A"),
                QuestionOption(id="b", label="B"),
            ],
        )
        assert req.options is not None
        assert len(req.options) == 2

    asyncio.run(_check())


def test_border_active_stronger_than_subtle() -> None:
    # Qualitative: border_active should be a brighter or more saturated hex than border_subtle.
    # Use brightness proxy: sum of RGB components.
    def rgb_sum(hex_color: str) -> int:
        h = hex_color.lstrip("#")
        return int(h[0:2], 16) + int(h[2:4], 16) + int(h[4:6], 16)

    active_sum = rgb_sum(DEFAULT_TOKENS.border_active)
    subtle_sum = rgb_sum(DEFAULT_TOKENS.border_subtle)
    assert active_sum > subtle_sum, (
        "border_active should be visually brighter than border_subtle"
    )
