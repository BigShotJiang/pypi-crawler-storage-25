"""Parity and readability regression tests for file-operation output convergence."""

from __future__ import annotations

from kiss.ui.shared import (
    FileOperationResult,
    format_file_operation,
    normalize_edit_file_result,
    normalize_write_file_result,
)
from kiss.ui.renderers import get_renderer_registry


# ── FileOperationResult canonical fields ─────────────────────────────────────


def test_file_operation_result_kind_is_always_file_operation() -> None:
    r = FileOperationResult(operation="create", path="foo.py")
    assert r.result_kind == "file_operation"


def test_file_operation_result_all_operation_kinds() -> None:
    for op in ("create", "modify", "delete", "move", "patch"):
        r = FileOperationResult(operation=op, path="a.py")  # type: ignore[arg-type]
        assert r.operation == op


def test_file_operation_result_move_has_from_to_paths() -> None:
    r = FileOperationResult(
        operation="move", path="new.py", from_path="old.py", to_path="new.py"
    )
    assert r.from_path == "old.py"
    assert r.to_path == "new.py"


def test_file_operation_result_stats_default_none() -> None:
    r = FileOperationResult(operation="create", path="foo.py")
    assert r.added_lines is None
    assert r.removed_lines is None


# ── format_file_operation: create ────────────────────────────────────────────


def test_format_create_uses_created_verb() -> None:
    r = FileOperationResult(
        operation="create", path="src/new.py", added_lines=10, removed_lines=0
    )
    display = format_file_operation(r)
    assert display.summary.startswith("Created")
    assert "src/new.py" in display.summary


def test_format_create_includes_stats() -> None:
    r = FileOperationResult(
        operation="create", path="a.py", added_lines=5, removed_lines=0
    )
    display = format_file_operation(r)
    assert "+5" in display.summary
    assert "-0" in display.summary


def test_format_create_no_stats_when_none() -> None:
    r = FileOperationResult(operation="create", path="a.py")
    display = format_file_operation(r)
    assert "+" not in display.summary
    assert "-" not in display.summary


# ── format_file_operation: modify ────────────────────────────────────────────


def test_format_modify_uses_edited_verb() -> None:
    r = FileOperationResult(operation="modify", path="src/app.py")
    display = format_file_operation(r)
    assert display.summary.startswith("Edited")
    assert "src/app.py" in display.summary


def test_format_modify_no_stats_when_unavailable() -> None:
    r = FileOperationResult(operation="modify", path="app.py")
    display = format_file_operation(r)
    assert "+" not in display.summary


# ── format_file_operation: patch ─────────────────────────────────────────────


def test_format_patch_uses_patched_verb() -> None:
    r = FileOperationResult(operation="patch", path="lib/util.py")
    display = format_file_operation(r)
    assert display.summary.startswith("Patched")
    assert "lib/util.py" in display.summary


def test_format_patch_includes_diff_section() -> None:
    r = FileOperationResult(
        operation="patch", path="lib/util.py", diff_preview="@@ -1 +1 @@\n-a\n+b"
    )
    display = format_file_operation(r)
    assert any(s.title == "Diff" for s in display.sections)


# ── format_file_operation: delete ────────────────────────────────────────────


def test_format_delete_uses_deleted_verb() -> None:
    r = FileOperationResult(operation="delete", path="old.py")
    display = format_file_operation(r)
    assert display.summary.startswith("Deleted")
    assert "old.py" in display.summary


# ── format_file_operation: move ──────────────────────────────────────────────


def test_format_move_uses_moved_verb_with_arrow() -> None:
    r = FileOperationResult(
        operation="move", path="new.py", from_path="old.py", to_path="new.py"
    )
    display = format_file_operation(r)
    assert display.summary.startswith("Moved")
    assert "old.py" in display.summary
    assert "→" in display.summary
    assert "new.py" in display.summary


def test_format_move_renders_from_to_in_grouped_summaries() -> None:
    r = FileOperationResult(
        operation="move", path="b.py", from_path="a.py", to_path="b.py"
    )
    display = format_file_operation(r)
    # Both source and destination must be in the summary line
    assert "a.py" in display.summary
    assert "b.py" in display.summary


# ── Fallback: verb+path even without diff ─────────────────────────────────────


def test_format_fallback_no_diff_still_has_verb_and_path() -> None:
    r = FileOperationResult(operation="create", path="x.py")
    display = format_file_operation(r)
    assert "Created" in display.summary
    assert "x.py" in display.summary
    assert not display.sections


# ── Stats suppression when unavailable ───────────────────────────────────────


def test_stats_suppressed_when_neither_added_nor_removed() -> None:
    r = FileOperationResult(operation="modify", path="a.py")
    display = format_file_operation(r)
    assert "+" not in display.summary
    assert "-" not in display.summary


def test_stats_present_when_both_provided() -> None:
    r = FileOperationResult(
        operation="patch", path="a.py", added_lines=3, removed_lines=2
    )
    display = format_file_operation(r)
    assert "+3" in display.summary
    assert "-2" in display.summary


# ── Normalizers ───────────────────────────────────────────────────────────────


def test_normalize_write_create_produces_create_operation() -> None:
    op = normalize_write_file_result("new.py", created=True, line_count=10)
    assert op.operation == "create"
    assert op.added_lines == 10
    assert op.removed_lines == 0


def test_normalize_write_overwrite_produces_modify_operation() -> None:
    op = normalize_write_file_result("existing.py", created=False, line_count=5)
    assert op.operation == "modify"
    assert op.added_lines is None
    assert op.removed_lines is None


def test_normalize_edit_produces_patch_operation() -> None:
    op = normalize_edit_file_result("util.py", diff_preview="@@ -1 +1 @@")
    assert op.operation == "patch"
    assert op.diff_preview == "@@ -1 +1 @@"


def test_normalize_edit_diagnostics_propagate() -> None:
    op = normalize_edit_file_result("f.py", diagnostics="ambiguous match")
    assert op.diagnostics == "ambiguous match"


# ── create_tool_result_display integration ────────────────────────────────────


def test_create_display_write_file_create_canonical() -> None:
    from kiss.agent.tools.result_types import WriteFileResult

    result = WriteFileResult(path="new.py", created=True, line_count=7)
    display = get_renderer_registry().render("write_file", result)
    assert display is not None
    assert "Created" in display.summary
    assert "new.py" in display.summary
    assert "+7" in display.summary


def test_create_display_write_file_overwrite_canonical() -> None:
    from kiss.agent.tools.result_types import WriteFileResult

    result = WriteFileResult(path="app.py", created=False)
    display = get_renderer_registry().render("write_file", result)
    assert display is not None
    assert "Edited" in display.summary
    assert "app.py" in display.summary


def test_create_display_edit_file_canonical() -> None:
    from kiss.agent.tools.result_types import EditFileResult

    result = EditFileResult(path="lib.py", applied=True, replacement_count=2)
    display = get_renderer_registry().render("edit_file", result)
    assert display is not None
    assert "Patched" in display.summary
    assert "lib.py" in display.summary


def test_create_display_edit_file_disambiguation_error() -> None:
    from kiss.agent.tools.result_types import EditFileResult, ToolResultMeta

    result = EditFileResult(
        path="lib.py", meta=ToolResultMeta(needs_disambiguation=True)
    )
    display = get_renderer_registry().render("edit_file", result)
    assert display is not None
    assert display.status == "error"


def test_create_display_diff_section_preserved() -> None:
    from kiss.agent.tools.result_types import WriteFileResult

    result = WriteFileResult(
        path="x.py", created=False, diff_preview="@@ -1 +1 @@\n-old\n+new\n"
    )
    display = get_renderer_registry().render("write_file", result)
    assert display is not None
    assert any(s.title == "Diff" for s in display.sections)


# ── Renderer registry typed path ─────────────────────────────────────────────


def test_renderer_registry_write_file_produces_file_op_display() -> None:
    from kiss.agent.tools.result_types import WriteFileResult

    result = WriteFileResult(path="gen.py", created=True, line_count=4)
    registry = get_renderer_registry()
    display = registry.render("write_file", result)
    assert display is not None
    assert "Created" in display.summary
    assert "gen.py" in display.summary
    assert "+4" in display.summary


def test_renderer_registry_edit_file_produces_file_op_display() -> None:
    from kiss.agent.tools.result_types import EditFileResult

    result = EditFileResult(path="util.py", applied=True, replacement_count=2)
    registry = get_renderer_registry()
    display = registry.render("edit_file", result)
    assert display is not None
    assert "Patched" in display.summary
    assert "util.py" in display.summary


def test_renderer_registry_edit_file_disambiguation_is_error() -> None:
    from kiss.agent.tools.result_types import EditFileResult, ToolResultMeta

    result = EditFileResult(
        path="f.py",
        meta=ToolResultMeta(needs_disambiguation=True),
    )
    registry = get_renderer_registry()
    display = registry.render("edit_file", result)
    assert display is not None
    assert display.status == "error"


# ── Grouped-summary and truncation compatibility ───────────────────────────────


def test_format_large_truncated_still_has_verb_path() -> None:
    r = FileOperationResult(operation="create", path="big.py")
    display = format_file_operation(r)
    # Summary remains minimal — no diff — truncation handled at ToolResultDisplay level
    assert "Created" in display.summary
    assert "big.py" in display.summary


def test_format_structured_patch_fallback_section() -> None:
    r = FileOperationResult(
        operation="patch",
        path="f.py",
        structured_patch="--- a/f.py\n+++ b/f.py\n@@ -1 +1 @@",
    )
    display = format_file_operation(r)
    # structured_patch shows as Patch section when no diff_preview
    assert any(s.title == "Patch" for s in display.sections)
