from __future__ import annotations

import pytest

from kiss.ui.shared import (
    InformationalDisplay,
    InteractionController,
    ToolResultSection,
    create_tool_result_display,
    format_tool_result,
    map_event_to_informational_display,
    notify_user,
)


def test_search_code_renderer_groups_matches() -> None:
    from kiss.agent.tools.result_types import SearchCodeMatch, SearchCodeResult
    from kiss.ui.renderers import get_renderer_registry

    result = SearchCodeResult(
        pattern="foo",
        match_count=3,
        matches=[
            SearchCodeMatch(path="a.py", line=1, text="alpha"),
            SearchCodeMatch(path="a.py", line=2, text="beta"),
            SearchCodeMatch(path="b.py", line=3, text="gamma"),
        ],
    )
    display = get_renderer_registry().render("search_code", result)
    assert display is not None
    rendered = format_tool_result(display)

    assert display.summary == "3 matches across 2 files"
    assert "Matches:" in rendered
    assert "a.py" in rendered
    assert "  - 1: alpha" in rendered
    assert "b.py" in rendered


def test_glob_renderer_formats_display() -> None:
    from kiss.agent.tools.result_types import GlobMatch, GlobResult
    from kiss.ui.renderers import get_renderer_registry

    result = GlobResult(
        pattern="src/*.py",
        root="/tmp/project",
        truncated=True,
        matches=[GlobMatch(path="src/a.py"), GlobMatch(path="src/b.py")],
    )
    display = get_renderer_registry().render("glob", result)
    assert display is not None

    assert display.summary == "src/*.py  →  2 paths under /tmp/project (truncated)"
    assert display.sections[0].title == "Matches"


def test_fetch_url_renderer_formats_display() -> None:
    from kiss.agent.tools.result_types import FetchUrlResult
    from kiss.ui.renderers import get_renderer_registry

    result = FetchUrlResult(
        url="https://example.com",
        status_code=200,
        content_type="text/html",
        is_text=True,
        is_html=True,
        redirect_count=1,
        content="Hello world",
    )
    display = get_renderer_registry().render("fetch_url", result)
    assert display is not None

    assert display.summary == "200 text/html, 1 redirects [html]"
    assert display.sections[1].title == "Content"


def test_web_search_renderer_formats_display() -> None:
    from kiss.agent.tools.result_types import WebSearchMatch, WebSearchResult
    from kiss.ui.renderers import get_renderer_registry

    result = WebSearchResult(
        query="example query",
        provider="duckduckgo",
        result_count=1,
        cached=True,
        results=[WebSearchMatch(title="Example Result", url="https://example.com")],
    )
    display = get_renderer_registry().render("web_search", result)
    assert display is not None

    assert display.summary == "1 results via duckduckgo (cached)"
    assert display.sections[0].title == "Query"
    assert display.sections[1].title == "Results"


def test_run_bash_renderer_formats_display() -> None:
    from kiss.agent.tools.result_types import RunCommandResult
    from kiss.ui.renderers import get_renderer_registry

    result = RunCommandResult(command="pytest", exit_code=1, stdout="out", stderr="err")
    display = get_renderer_registry().render("run_bash", result)
    assert display is not None
    rendered = format_tool_result(display)

    assert "exit 1, timed_out=False" in display.summary
    assert "Stdout:" in rendered
    assert "Stderr:" in rendered


def test_write_file_renderer_formats_display() -> None:
    from kiss.agent.tools.result_types import WriteFileResult
    from kiss.ui.renderers import get_renderer_registry

    result = WriteFileResult(
        path="src/app.py",
        created=False,
        line_count=2,
        diff_preview="@@ -1 +1 @@\n-old\n+new\n",
    )
    display = get_renderer_registry().render("write_file", result)
    assert display is not None

    assert "Edited" in display.summary
    assert "src/app.py" in display.summary
    assert display.sections[0].title == "Diff"


def test_edit_file_renderer_formats_disambiguation() -> None:
    from kiss.agent.tools.result_types import EditFileResult, ToolResultMeta
    from kiss.ui.renderers import get_renderer_registry

    result = EditFileResult(
        path="src/app.py",
        meta=ToolResultMeta(needs_disambiguation=True),
        diff_preview="@@ -1 +1 @@\n-old\n+new\n",
    )
    display = get_renderer_registry().render("edit_file", result)
    assert display is not None

    assert display.status == "error"
    assert any(s.title in ("Diagnostics", "Match Contexts") for s in display.sections)


def test_create_tool_result_display_uses_error_summary_for_failures() -> None:
    display = create_tool_result_display(
        "fetch_url",
        "Request failed: boom",
        is_err=True,
    )

    assert display.status == "error"
    assert display.summary == "Request failed: boom"


# ── InformationalDisplay ──────────────────────────────────────────────────────


def test_informational_display_defaults() -> None:
    d = InformationalDisplay(message="hello", severity="info")
    assert d.message == "hello"
    assert d.severity == "info"
    assert d.sections == []


def test_informational_display_with_sections() -> None:
    d = InformationalDisplay(
        message="details",
        severity="warning",
        sections=[ToolResultSection("Context", "extra")],
    )
    assert d.severity == "warning"
    assert len(d.sections) == 1
    assert d.sections[0].title == "Context"


# ── map_event_to_informational_display ───────────────────────────────────────


def _mock_kind(name: str) -> object:
    class _Kind:
        def __init__(self, name: str) -> None:
            self.name = name

    return _Kind(name)


def test_map_thinking_event() -> None:
    d = map_event_to_informational_display(
        kind=_mock_kind("THINKING"), thought="pondering..."
    )
    assert d is not None
    assert d.severity == "thought"
    assert d.message == "pondering..."


def test_map_info_event() -> None:
    d = map_event_to_informational_display(
        kind=_mock_kind("INFO"), info="context compacted"
    )
    assert d is not None
    assert d.severity == "info"
    assert d.message == "context compacted"


def test_map_stuck_loop_warning() -> None:
    d = map_event_to_informational_display(
        kind=_mock_kind("STUCK_LOOP"), info="loop detected", severity="warn"
    )
    assert d is not None
    assert d.severity == "warning"
    assert d.message == "loop detected"


def test_map_stuck_loop_error() -> None:
    d = map_event_to_informational_display(
        kind=_mock_kind("STUCK_LOOP"), info="aborting", severity="error"
    )
    assert d is not None
    assert d.severity == "error"
    assert d.message == "aborting"


def test_map_unsupported_event_returns_none() -> None:
    d = map_event_to_informational_display(kind=_mock_kind("TOKEN"), info="x")
    assert d is None


# ── notify_user ────────────────────────────────────────────────────────────────


def test_notify_user_emits_sequences_when_enabled(
    capsys: pytest.CaptureFixture[str],
) -> None:
    notify_user("Header", "Body", enabled=True)
    captured = capsys.readouterr()
    assert "\x07" in captured.out
    assert "\x1b]9;Header\x07" in captured.out
    assert "\x1b]777;notify;Header;Body\x1b\\" in captured.out


def test_notify_user_is_silent_when_disabled(
    capsys: pytest.CaptureFixture[str],
) -> None:
    notify_user("Header", "Body", enabled=False)
    captured = capsys.readouterr()
    assert captured.out == ""


# ── InteractionController ──────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_interaction_controller_tracks_pending() -> None:
    from kiss.core.events import AskUserRequest

    ctrl = InteractionController()
    req = AskUserRequest(question="Q?")
    ctrl.register(req)
    assert req.interaction_id in ctrl._pending


@pytest.mark.asyncio
async def test_interaction_controller_deregister_removes() -> None:
    from kiss.core.events import AskUserRequest

    ctrl = InteractionController()
    req = AskUserRequest(question="Q?")
    ctrl.register(req)
    ctrl.deregister(req)
    assert req.interaction_id not in ctrl._pending


@pytest.mark.asyncio
async def test_interaction_controller_cancel_all_cancels_futures() -> None:
    from kiss.core.events import AskUserRequest

    ctrl = InteractionController()
    req = AskUserRequest(question="Q?")
    ctrl.register(req)

    ctrl.cancel_all()
    assert req.reply_future.cancelled()
    assert len(ctrl._pending) == 0


@pytest.mark.asyncio
async def test_interaction_controller_cancel_all_skips_done() -> None:
    from kiss.core.events import AskUserRequest, AskUserReply

    ctrl = InteractionController()
    req = AskUserRequest(question="Q?")
    req.reply_future.set_result(AskUserReply.from_text("ok"))
    ctrl.register(req)

    ctrl.cancel_all()
    assert req.reply_future.done() and not req.reply_future.cancelled()
    assert len(ctrl._pending) == 0
