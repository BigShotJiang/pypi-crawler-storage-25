from __future__ import annotations

import pytest

from kiss.core.settings import Settings
from kiss.ui.textual.app import KissApp


def _make_app() -> KissApp:
    settings = Settings(model="copilot:gpt-4o")
    return KissApp(settings)


@pytest.mark.asyncio
async def test_copilot_auth_required_when_token_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = _make_app()
    monkeypatch.setattr("kiss.ui.textual.app.load_github_token", lambda: "")
    monkeypatch.setattr("kiss.providers.manager.probe_copilot_token", pytest.fail)

    assert await app._copilot_auth_required() is True


@pytest.mark.asyncio
async def test_copilot_auth_skips_prompt_when_token_is_valid(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = _make_app()
    errors: list[str] = []

    monkeypatch.setattr("kiss.ui.textual.app.load_github_token", lambda: "token")

    async def fake_probe() -> str:
        return "copilot-session-token"

    monkeypatch.setattr("kiss.providers.manager.probe_copilot_token", fake_probe)
    monkeypatch.setattr(app, "_show_error", lambda message: errors.append(message))

    assert await app._copilot_auth_required() is False
    assert errors == []


@pytest.mark.asyncio
async def test_copilot_auth_clears_rejected_token(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = _make_app()
    cleared: list[bool] = []
    errors: list[str] = []

    monkeypatch.setattr("kiss.ui.textual.app.load_github_token", lambda: "token")

    async def fake_probe() -> str:
        raise RuntimeError("Copilot token exchange failed (401)")

    monkeypatch.setattr("kiss.providers.manager.probe_copilot_token", fake_probe)
    monkeypatch.setattr(
        "kiss.ui.textual.app.clear_github_token", lambda: cleared.append(True)
    )
    monkeypatch.setattr(app, "_show_error", lambda message: errors.append(message))

    assert await app._copilot_auth_required() is True
    assert cleared == [True]
    assert errors == []
