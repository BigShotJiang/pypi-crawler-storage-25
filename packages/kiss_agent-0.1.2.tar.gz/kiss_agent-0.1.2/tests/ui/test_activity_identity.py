"""Section 10 regression tests: activity_id naming, /detail parity, visibility profiles."""

from __future__ import annotations

from kiss.ui.activity import GroupActivityTracker, _GROUP_THRESHOLD
from kiss.ui.observability import (
    ChatActivityBuffer,
    ChatActivityEntry,
    ObservabilityState,
)
from kiss.ui.shared import ToolInteractionMeta, ToolResultDisplay


# ── 10.1 activity_id canonical naming ────────────────────────────────────────


def test_group_summary_uses_act_prefix() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    for i in range(_GROUP_THRESHOLD):
        tracker.on_tool_call("read_file", f"id-{i}", f"file-{i}.py")
    summary = tracker.flush()
    assert summary is not None
    assert summary.activity_id.startswith("act-"), (
        f"expected act- prefix, got {summary.activity_id}"
    )


def test_activity_id_format_is_zero_padded_4_digit() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    for i in range(_GROUP_THRESHOLD):
        tracker.on_tool_call("read_file", f"id-{i}", f"file-{i}.py")
    summary = tracker.flush()
    assert summary is not None
    suffix = summary.activity_id[len("act-") :]
    assert suffix.isdigit() and len(suffix) == 4


def test_activity_id_monotonically_increases() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    ids: list[str] = []
    for batch in range(3):
        for i in range(_GROUP_THRESHOLD):
            tracker.on_tool_call("read_file", f"b{batch}-id-{i}", f"f{i}.py")
        s = tracker.flush()
        if s is not None:
            ids.append(s.activity_id)
    assert ids == sorted(ids), f"ids not monotonic: {ids}"
    assert len(set(ids)) == len(ids), f"duplicate ids: {ids}"


def test_chat_activity_entry_uses_activity_id_field() -> None:
    entry = ChatActivityEntry(
        timestamp="t", kind="tool_call", label="x", activity_id="act-0001"
    )
    assert entry.activity_id == "act-0001"


def test_buffer_get_by_activity_returns_matching_entries() -> None:
    buf = ChatActivityBuffer()
    buf.append(
        ChatActivityEntry(
            timestamp="t", kind="tool_call", label="a", activity_id="act-0001"
        )
    )
    buf.append(
        ChatActivityEntry(
            timestamp="t", kind="tool_call", label="b", activity_id="act-0002"
        )
    )
    buf.append(
        ChatActivityEntry(
            timestamp="t", kind="tool_result", label="c", activity_id="act-0001"
        )
    )
    result = buf.get_by_activity("act-0001")
    assert len(result) == 2
    assert all(e.activity_id == "act-0001" for e in result)


def test_render_rich_shows_activity_id() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    for i in range(_GROUP_THRESHOLD):
        tracker.on_tool_call("read_file", f"id-{i}", f"file-{i}.py")
    summary = tracker.flush()
    assert summary is not None
    rendered = summary.render_rich()
    assert summary.activity_id in rendered


# ── 10.3 legacy grp- compatibility ───────────────────────────────────────────


def test_format_detail_accepts_legacy_grp_prefix() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    # Manually inject a legacy-style entry
    obs.chat_activity.append(
        ChatActivityEntry(
            timestamp="t",
            kind="tool_call",
            label="old tool call",
            activity_id="grp-0001",
            detail="read_file(old.py)",
        )
    )
    result = tracker.format_detail("grp-0001")
    assert "old.py" in result or "old tool call" in result


def test_format_detail_legacy_includes_deprecation_hint() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    obs.chat_activity.append(
        ChatActivityEntry(
            timestamp="t",
            kind="tool_call",
            label="old",
            activity_id="grp-0001",
            detail="x",
        )
    )
    result = tracker.format_detail("grp-0001")
    assert "deprecated" in result.lower() or "grp-" in result


def test_format_detail_expiry_for_unknown_id() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    result = tracker.format_detail("act-9999")
    assert "expired" in result.lower()


# ── 10.4 ToolInteractionMeta ──────────────────────────────────────────────────


def test_tool_interaction_meta_defaults() -> None:
    meta = ToolInteractionMeta(activity_id="act-0001")
    assert meta.visibility_profile == "compact"
    assert meta.is_expandable is False
    assert meta.detail_hint is None
    assert meta.detail_command is None
    assert meta.is_expired is False


def test_tool_interaction_meta_verbose_profile() -> None:
    meta = ToolInteractionMeta(activity_id="act-0001", visibility_profile="verbose")
    assert meta.visibility_profile == "verbose"


def test_tool_result_display_accepts_interaction() -> None:
    meta = ToolInteractionMeta(
        activity_id="act-0001",
        is_expandable=True,
        detail_command="/detail act-0001",
    )
    display = ToolResultDisplay(title="test", summary="ok", interaction=meta)
    assert display.interaction is not None
    assert display.interaction.activity_id == "act-0001"
    assert display.interaction.is_expandable is True
    assert display.interaction.detail_command == "/detail act-0001"


def test_tool_result_display_interaction_defaults_none() -> None:
    display = ToolResultDisplay(title="test", summary="ok")
    assert display.interaction is None


# ── 10.6 detail replay found/expired/unknown paths ───────────────────────────


def test_get_detail_returns_entries_for_known_activity() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    for i in range(_GROUP_THRESHOLD):
        tracker.on_tool_call("search_code", f"id-{i}", f"pattern-{i}")
        tracker.on_tool_result(f"id-{i}", f"result-{i}")
    summary = tracker.flush()
    assert summary is not None
    entries = tracker.get_detail(summary.activity_id)
    assert entries is not None
    assert len(entries) >= _GROUP_THRESHOLD


def test_get_detail_returns_none_for_unknown_activity() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    result = tracker.get_detail("act-9999")
    assert result is None


def test_format_detail_shows_tool_calls_and_results() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    for i in range(_GROUP_THRESHOLD):
        tracker.on_tool_call("glob", f"id-{i}", "*.py")
        tracker.on_tool_result(f"id-{i}", f"found {i} files")
    summary = tracker.flush()
    assert summary is not None
    detail = tracker.format_detail(summary.activity_id)
    assert "glob" in detail or "*.py" in detail
    assert "found" in detail


# ── 10.10 profile switching stability ────────────────────────────────────────


def test_verbose_profile_does_not_change_activity_id() -> None:
    meta = ToolInteractionMeta(
        activity_id="act-0042",
        visibility_profile="compact",
    )
    meta.visibility_profile = "verbose"
    assert meta.activity_id == "act-0042"


# ── 10.11 compact summary scanability ────────────────────────────────────────


def test_group_summary_render_rich_is_compact() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    for i in range(_GROUP_THRESHOLD):
        tracker.on_tool_call("read_file", f"id-{i}", f"file-{i}.py")
    summary = tracker.flush()
    assert summary is not None
    rendered = summary.render_rich()
    # compact: one logical line — no newlines in the summary itself
    assert "\n" not in rendered
    # activity_id is visible
    assert summary.activity_id in rendered
    # tool name is visible
    assert "read_file" in rendered


def test_bursty_activity_produces_one_summary_per_group() -> None:
    obs = ObservabilityState()
    tracker = GroupActivityTracker(obs.chat_activity)
    summaries: list = []
    for batch in range(3):
        for i in range(_GROUP_THRESHOLD + 2):
            s = tracker.on_tool_call("read_file", f"b{batch}-{i}", f"f{i}.py")
            if s is not None:
                summaries.append(s)
        final = tracker.flush()
        if final is not None:
            summaries.append(final)
    # Each batch produces at most one summary (may produce intermediate when threshold hit)
    activity_ids = [s.activity_id for s in summaries]
    assert len(activity_ids) == len(set(activity_ids)), (
        "duplicate activity ids across groups"
    )
