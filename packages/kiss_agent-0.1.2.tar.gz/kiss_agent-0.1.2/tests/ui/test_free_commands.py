"""Tests for free-provider toggle logic and free model collection (tasks 80, 84)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from kiss.providers.types import ProviderProfile


def _make_agent(free_providers: dict | None = None, model: str = "openai/gpt-4o"):
    settings = MagicMock()
    settings.free_providers = dict(free_providers or {})
    settings.model = model
    agent = MagicMock()
    agent.settings = settings
    return agent


def _make_profile(name: str, free_models: tuple[str, ...]) -> ProviderProfile:
    return ProviderProfile(
        name=name,
        auth_type="api_key",
        base_url="https://example.com",
        free_models=free_models,
    )


# --- Task 80: toggle logic ---


def test_toggle_enables_disabled_provider(monkeypatch):
    from kiss.ui.commands import toggle_free_provider

    profile = _make_profile("openai", ("gpt-4o-mini",))
    agent = _make_agent(free_providers={})

    monkeypatch.setattr(
        "kiss.providers.registry.get_provider_profile", lambda name: profile
    )
    with patch("kiss.core.settings.settings_save"):
        result = toggle_free_provider(agent, "openai")

    assert result is True
    assert agent.settings.free_providers["openai"] is True


def test_toggle_disables_enabled_provider(monkeypatch):
    from kiss.ui.commands import toggle_free_provider

    profile = _make_profile("openai", ("gpt-4o-mini",))
    agent = _make_agent(free_providers={"openai": True})

    monkeypatch.setattr(
        "kiss.providers.registry.get_provider_profile", lambda name: profile
    )
    with patch("kiss.core.settings.settings_save"):
        result = toggle_free_provider(agent, "openai")

    assert result is False
    assert agent.settings.free_providers["openai"] is False


def test_toggle_unknown_provider_raises(monkeypatch):
    from kiss.ui.commands import toggle_free_provider

    monkeypatch.setattr(
        "kiss.providers.registry.get_provider_profile", lambda name: None
    )
    agent = _make_agent()

    with pytest.raises(KeyError):
        toggle_free_provider(agent, "unknown-provider")


def test_toggle_provider_no_free_models_raises(monkeypatch):
    from kiss.ui.commands import toggle_free_provider

    profile = _make_profile("anthropic", ())
    monkeypatch.setattr(
        "kiss.providers.registry.get_provider_profile", lambda name: profile
    )
    agent = _make_agent()

    with pytest.raises(KeyError):
        toggle_free_provider(agent, "anthropic")


def test_toggle_persists_to_disk(monkeypatch):
    from kiss.ui.commands import toggle_free_provider

    profile = _make_profile("gemini", ("gemini-2.0-flash",))
    monkeypatch.setattr(
        "kiss.providers.registry.get_provider_profile", lambda name: profile
    )
    agent = _make_agent()
    saved = []

    with patch(
        "kiss.core.settings.settings_save", side_effect=lambda s: saved.append(s)
    ):
        toggle_free_provider(agent, "gemini")

    assert len(saved) == 1
    assert saved[0] is agent.settings


# --- Task 84: free model collection ---


def test_get_free_models_returns_enabled_providers(monkeypatch):
    from kiss.ui.commands import get_free_models

    openai_profile = _make_profile("openai", ("gpt-4o-mini",))
    gemini_profile = _make_profile(
        "gemini", ("gemini-2.0-flash-lite", "gemini-2.0-flash")
    )

    def fake_get_profile(name):
        return {"openai": openai_profile, "gemini": gemini_profile}.get(name)

    monkeypatch.setattr(
        "kiss.providers.registry.get_provider_profile", fake_get_profile
    )
    agent = _make_agent(
        free_providers={"openai": True, "gemini": True}, model="anthropic/claude"
    )

    result = get_free_models(agent)
    ids = [m.model_id for m in result]

    assert "openai:gpt-4o-mini" in ids
    assert "gemini:gemini-2.0-flash-lite" in ids
    assert "gemini:gemini-2.0-flash" in ids
    assert all(m.free for m in result)


def test_get_free_models_excludes_disabled_providers(monkeypatch):
    from kiss.ui.commands import get_free_models

    openai_profile = _make_profile("openai", ("gpt-4o-mini",))

    monkeypatch.setattr(
        "kiss.providers.registry.get_provider_profile",
        lambda name: openai_profile if name == "openai" else None,
    )
    agent = _make_agent(free_providers={"openai": False})

    result = get_free_models(agent)
    assert result == []


def test_get_free_models_deduplicates(monkeypatch):
    from kiss.ui.commands import get_free_models

    profile = _make_profile("openai", ("gpt-4o-mini", "gpt-4o-mini"))

    monkeypatch.setattr(
        "kiss.providers.registry.get_provider_profile", lambda name: profile
    )
    agent = _make_agent(free_providers={"openai": True})

    result = get_free_models(agent)
    ids = [m.model_id for m in result]
    assert ids.count("openai:gpt-4o-mini") == 1


def test_get_free_models_marks_current_model(monkeypatch):
    from kiss.ui.commands import get_free_models

    profile = _make_profile("openai", ("gpt-4o-mini",))

    monkeypatch.setattr(
        "kiss.providers.registry.get_provider_profile", lambda name: profile
    )
    agent = _make_agent(free_providers={"openai": True}, model="openai:gpt-4o-mini")

    result = get_free_models(agent)
    assert any(m.active and m.model_id == "openai:gpt-4o-mini" for m in result)


def test_get_free_models_empty_when_no_free_providers():
    from kiss.ui.commands import get_free_models

    agent = _make_agent(free_providers={})
    result = get_free_models(agent)
    assert result == []


# --- Tasks 87-88: integration — /model free filter end-to-end ---


def _merge_for_model(
    auth_model_ids: list[str],
    free_models_result,
) -> list[str]:
    """Replicate the merging logic from the Rich /model handler."""
    existing_ids = set(auth_model_ids)
    merged = list(auth_model_ids) + [
        m.model_id for m in free_models_result if m.model_id not in existing_ids
    ]
    return merged


def test_model_picker_includes_free_models_when_enabled(monkeypatch):
    """Task 87: enable free providers → /model shows free models."""
    from kiss.ui.commands import get_free_models

    gemini_profile = _make_profile(
        "gemini", ("gemini-2.0-flash-lite", "gemini-2.0-flash")
    )
    monkeypatch.setattr(
        "kiss.providers.registry.get_provider_profile",
        lambda name: gemini_profile if name == "gemini" else None,
    )
    agent = _make_agent(
        free_providers={"gemini": True},
        model="anthropic/claude-sonnet-4-6",
    )

    auth_models = ["anthropic/claude-sonnet-4-6", "anthropic/claude-opus-4"]
    free_result = get_free_models(agent)

    merged = _merge_for_model(auth_models, free_result)

    assert "gemini:gemini-2.0-flash-lite" in merged
    assert "gemini:gemini-2.0-flash" in merged
    assert "anthropic/claude-sonnet-4-6" in merged


def test_model_picker_excludes_free_models_when_disabled(monkeypatch):
    """Task 88: toggle provider off → free models disappear from /model."""
    from kiss.ui.commands import get_free_models

    gemini_profile = _make_profile(
        "gemini", ("gemini-2.0-flash-lite", "gemini-2.0-flash")
    )
    monkeypatch.setattr(
        "kiss.providers.registry.get_provider_profile",
        lambda name: gemini_profile if name == "gemini" else None,
    )
    agent_enabled = _make_agent(free_providers={"gemini": True})
    agent_disabled = _make_agent(free_providers={"gemini": False})

    auth_models = ["anthropic/claude-sonnet-4-6"]

    free_on = get_free_models(agent_enabled)
    merged_on = _merge_for_model(auth_models, free_on)
    assert "gemini:gemini-2.0-flash-lite" in merged_on

    free_off = get_free_models(agent_disabled)
    merged_off = _merge_for_model(auth_models, free_off)
    assert "gemini:gemini-2.0-flash-lite" not in merged_off
    assert "anthropic/claude-sonnet-4-6" in merged_off


def test_model_picker_no_duplicate_when_free_model_also_authenticated(monkeypatch):
    """Free model that also appears in auth'd model list should appear once."""
    from kiss.ui.commands import get_free_models

    openai_profile = _make_profile("openai", ("gpt-4o-mini",))
    monkeypatch.setattr(
        "kiss.providers.registry.get_provider_profile",
        lambda name: openai_profile if name == "openai" else None,
    )
    agent = _make_agent(free_providers={"openai": True})

    auth_models = ["openai:gpt-4o-mini", "openai/gpt-4o"]
    free_result = get_free_models(agent)
    merged = _merge_for_model(auth_models, free_result)

    assert merged.count("openai:gpt-4o-mini") == 1
