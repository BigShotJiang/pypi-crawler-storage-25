"""Regression tests for TODO output convergence: summary, delta, active state, all-done."""

from __future__ import annotations

from kiss.core.deps import TodoNormalizer
from kiss.core.events import TodoDelta, TodoUpdateMeta
from kiss.core.usage import TodoItem


from typing import Literal

TodoStatus = Literal["pending", "in_progress", "blocked", "done"]


def _make_todo(
    id: str,
    text: str,
    status: TodoStatus = "pending",
    done: bool = False,
) -> TodoItem:
    return TodoItem(id=id, text=text, status=status, done=done)


# ── TodoDelta ─────────────────────────────────────────────────────────────────


def test_todo_delta_is_empty_on_default() -> None:
    delta = TodoDelta()
    assert delta.is_empty()


def test_todo_delta_not_empty_when_added() -> None:
    delta = TodoDelta(added=["t-0001"])
    assert not delta.is_empty()


def test_todo_delta_not_empty_when_completed() -> None:
    delta = TodoDelta(completed=["t-0002"])
    assert not delta.is_empty()


def test_todo_delta_not_empty_when_reopened() -> None:
    delta = TodoDelta(reopened=["t-0003"])
    assert not delta.is_empty()


def test_todo_delta_not_empty_when_removed() -> None:
    delta = TodoDelta(removed=["t-0004"])
    assert not delta.is_empty()


# ── TodoUpdateMeta fields ─────────────────────────────────────────────────────


def test_todo_update_meta_fields() -> None:
    todos = [_make_todo("t-0001", "Write tests")]
    meta = TodoUpdateMeta(snapshot=todos, pending_count=1, completed_count=0)
    assert meta.pending_count == 1
    assert meta.completed_count == 0
    assert meta.delta is None
    assert meta.active_todo_id is None
    assert not meta.all_done
    assert meta.ambiguity_candidates == []


def test_todo_update_meta_snapshot_in_insertion_order() -> None:
    todos = [
        _make_todo("t-0001", "First"),
        _make_todo("t-0002", "Second"),
        _make_todo("t-0003", "Third"),
    ]
    meta = TodoUpdateMeta(snapshot=todos[:], pending_count=3, completed_count=0)
    assert [t.id for t in meta.snapshot] == ["t-0001", "t-0002", "t-0003"]


# ── TodoNormalizer: first emission ───────────────────────────────────────────


def test_normalizer_first_emission_has_no_delta() -> None:
    norm = TodoNormalizer()
    todos = [_make_todo("t-0001", "task")]
    meta = norm.compute(todos)
    assert meta.delta is None


def test_normalizer_first_emission_pending_count() -> None:
    norm = TodoNormalizer()
    todos = [
        _make_todo("t-0001", "a"),
        _make_todo("t-0002", "b"),
        _make_todo("t-0003", "c", status="done", done=True),
    ]
    meta = norm.compute(todos)
    assert meta.pending_count == 2
    assert meta.completed_count == 1


# ── TodoNormalizer: delta computation ────────────────────────────────────────


def test_normalizer_delta_added() -> None:
    norm = TodoNormalizer()
    norm.compute([_make_todo("t-0001", "existing")])

    todos = [_make_todo("t-0001", "existing"), _make_todo("t-0002", "new")]
    meta = norm.compute(todos)

    assert meta.delta is not None
    assert "t-0002" in meta.delta.added
    assert not meta.delta.is_empty()


def test_normalizer_delta_completed() -> None:
    norm = TodoNormalizer()
    norm.compute([_make_todo("t-0001", "task")])

    todos = [_make_todo("t-0001", "task", status="done", done=True)]
    meta = norm.compute(todos)

    assert meta.delta is not None
    assert "t-0001" in meta.delta.completed


def test_normalizer_delta_reopened() -> None:
    norm = TodoNormalizer()
    norm.compute([_make_todo("t-0001", "task", status="done", done=True)])

    todos = [_make_todo("t-0001", "task", status="pending", done=False)]
    meta = norm.compute(todos)

    assert meta.delta is not None
    assert "t-0001" in meta.delta.reopened


def test_normalizer_delta_empty_when_no_change() -> None:
    norm = TodoNormalizer()
    todos = [_make_todo("t-0001", "task")]
    norm.compute(todos)
    meta = norm.compute(todos)

    assert meta.delta is not None
    assert meta.delta.is_empty()


# ── TodoNormalizer: active_todo_id ────────────────────────────────────────────


def test_normalizer_active_todo_id_when_exactly_one_in_progress() -> None:
    norm = TodoNormalizer()
    todos = [
        _make_todo("t-0001", "a", status="in_progress"),
        _make_todo("t-0002", "b", status="pending"),
    ]
    meta = norm.compute(todos)
    assert meta.active_todo_id == "t-0001"


def test_normalizer_no_active_id_when_multiple_in_progress() -> None:
    norm = TodoNormalizer()
    todos = [
        _make_todo("t-0001", "a", status="in_progress"),
        _make_todo("t-0002", "b", status="in_progress"),
    ]
    meta = norm.compute(todos)
    assert meta.active_todo_id is None


def test_normalizer_no_active_id_when_none_in_progress() -> None:
    norm = TodoNormalizer()
    todos = [_make_todo("t-0001", "a", status="pending")]
    meta = norm.compute(todos)
    assert meta.active_todo_id is None


# ── TodoNormalizer: all_done signaling ───────────────────────────────────────


def test_normalizer_all_done_when_pending_transitions_to_zero() -> None:
    norm = TodoNormalizer()
    norm.compute([_make_todo("t-0001", "task", status="pending")])

    todos = [_make_todo("t-0001", "task", status="done", done=True)]
    meta = norm.compute(todos)

    assert meta.all_done is True
    assert meta.pending_count == 0


def test_normalizer_all_done_false_when_still_pending() -> None:
    norm = TodoNormalizer()
    norm.compute([_make_todo("t-0001", "a"), _make_todo("t-0002", "b")])

    todos = [
        _make_todo("t-0001", "a", status="done", done=True),
        _make_todo("t-0002", "b"),
    ]
    meta = norm.compute(todos)

    assert meta.all_done is False
    assert meta.pending_count == 1


def test_normalizer_all_done_false_on_first_emission_even_if_empty() -> None:
    norm = TodoNormalizer()
    meta = norm.compute([])
    assert meta.all_done is False


def test_normalizer_all_done_false_when_already_zero_stays_zero() -> None:
    norm = TodoNormalizer()
    todos = [_make_todo("t-0001", "a", status="done", done=True)]
    norm.compute(todos)
    # Second emission with same completed state — not a new transition
    meta = norm.compute(todos)
    assert meta.all_done is False


# ── Readability/noise: rapid burst stays summary-first ───────────────────────


def test_normalizer_rapid_burst_produces_only_summary_not_full_list() -> None:
    """Each meta has concise counts — backends must NOT replay the full todo list."""
    norm = TodoNormalizer()
    todos = []
    for i in range(1, 11):
        todos.append(_make_todo(f"t-{i:04d}", f"task {i}"))
        meta = norm.compute(todos)
        # summary has counts, not all text
        assert meta.pending_count == i
        assert meta.completed_count == 0
        # snapshot holds full list, but backends render summary line only
        assert len(meta.snapshot) == i


def test_normalizer_burst_deltas_are_incremental() -> None:
    """Rapid adds produce incremental deltas — each delta has only the latest addition."""
    norm = TodoNormalizer()
    norm.compute([_make_todo("t-0001", "first")])

    meta = norm.compute([_make_todo("t-0001", "first"), _make_todo("t-0002", "second")])
    assert meta.delta is not None
    assert meta.delta.added == ["t-0002"]
    assert "t-0001" not in meta.delta.added


# ── TodoUpdateMeta ambiguity candidates field ─────────────────────────────────


def test_todo_update_meta_ambiguity_candidates_default_empty() -> None:
    meta = TodoUpdateMeta(snapshot=[], pending_count=0, completed_count=0)
    assert meta.ambiguity_candidates == []


def test_todo_update_meta_ambiguity_candidates_populated() -> None:
    meta = TodoUpdateMeta(
        snapshot=[],
        pending_count=0,
        completed_count=0,
        ambiguity_candidates=[
            ("t-0001", "write tests", 0.92),
            ("t-0002", "write docs", 0.88),
        ],
    )
    assert len(meta.ambiguity_candidates) == 2
    assert meta.ambiguity_candidates[0][0] == "t-0001"
    assert meta.ambiguity_candidates[0][2] == 0.92
