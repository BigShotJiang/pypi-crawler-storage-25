"""Parity and readability regression tests for rail-lane transcript convergence."""

from __future__ import annotations

from kiss.data.ui_tokens import LANE_GLYPHS, LaneGlyphSet
from kiss.ui.shared import LaneDepth, LaneKind, TranscriptLane


# ── LaneGlyphSet ──────────────────────────────────────────────────────────────


def test_lane_glyphs_all_required_kinds_defined() -> None:
    required = {
        "user",
        "assistant",
        "thought",
        "tool",
        "system",
        "info",
        "warning",
        "error",
    }
    for kind in required:
        assert kind in LANE_GLYPHS, f"Missing glyph for lane kind: {kind}"


def test_lane_glyphs_user_assistant_non_collision_unicode() -> None:
    user = LANE_GLYPHS["user"]
    assistant = LANE_GLYPHS["assistant"]
    assert user.unicode != assistant.unicode, (
        "user and assistant primary rails MUST use different Unicode glyphs"
    )


def test_lane_glyphs_user_assistant_non_collision_ascii() -> None:
    user = LANE_GLYPHS["user"]
    assistant = LANE_GLYPHS["assistant"]
    assert user.ascii != assistant.ascii, (
        "user and assistant primary rails MUST use different ASCII fallback glyphs"
    )


def test_lane_glyphs_canonical_user_values() -> None:
    g = LANE_GLYPHS["user"]
    assert g.unicode == "▋"
    assert g.ascii == ">"


def test_lane_glyphs_canonical_assistant_values() -> None:
    g = LANE_GLYPHS["assistant"]
    assert g.unicode == "▊"
    assert g.ascii == "<"


def test_lane_glyphs_canonical_thought_values() -> None:
    g = LANE_GLYPHS["thought"]
    assert g.unicode == "▏"
    assert g.ascii == ":"


def test_lane_glyphs_tool_system_info_neutral() -> None:
    for kind in ("tool", "system", "info"):
        g = LANE_GLYPHS[kind]
        assert g.unicode == "│"
        assert g.ascii == "|"


def test_lane_glyphs_warning_error_severity() -> None:
    for kind in ("warning", "error"):
        g = LANE_GLYPHS[kind]
        assert g.ascii == "!"


def test_lane_glyph_set_is_frozen() -> None:
    g = LaneGlyphSet(unicode="X", ascii="Y")
    assert g.unicode == "X"
    assert g.ascii == "Y"


# ── TranscriptLane fields ─────────────────────────────────────────────────────


def test_transcript_lane_user_defaults() -> None:
    lane = TranscriptLane(kind="user")
    assert lane.kind == "user"
    assert lane.depth == "primary"
    assert lane.thought_id is None


def test_transcript_lane_assistant_defaults() -> None:
    lane = TranscriptLane(kind="assistant")
    assert lane.kind == "assistant"
    assert lane.depth == "primary"


def test_transcript_lane_thought_secondary() -> None:
    lane = TranscriptLane(kind="thought", depth="secondary", thought_id="th-1-1")
    assert lane.kind == "thought"
    assert lane.depth == "secondary"
    assert lane.thought_id == "th-1-1"


def test_transcript_lane_thought_id_none_by_default() -> None:
    lane = TranscriptLane(kind="thought", depth="secondary")
    assert lane.thought_id is None


def test_transcript_lane_all_kinds_valid() -> None:
    kinds: list[LaneKind] = ["user", "assistant", "thought", "tool", "system"]
    for k in kinds:
        lane = TranscriptLane(kind=k)
        assert lane.kind == k


def test_transcript_lane_all_depths_valid() -> None:
    depths: list[LaneDepth] = ["primary", "secondary"]
    for d in depths:
        lane = TranscriptLane(kind="user", depth=d)
        assert lane.depth == d


# ── thought_id carriage in Event ─────────────────────────────────────────────


def test_event_thought_id_field_exists() -> None:
    from kiss.core.events import Event, EventKind

    e = Event(kind=EventKind.THINKING, thought="hello", thought_id="th-1-1")
    assert e.thought_id == "th-1-1"


def test_event_thought_id_defaults_none() -> None:
    from kiss.core.events import Event, EventKind

    e = Event(kind=EventKind.THINKING, thought="hello")
    assert e.thought_id is None


def test_event_thought_id_format_matches_spec() -> None:
    # th-<turn_seq>-<thought_seq>: both segments must be integers
    thought_id = "th-1-1"
    parts = thought_id.split("-")
    assert len(parts) == 3
    assert parts[0] == "th"
    assert parts[1].isdigit()
    assert parts[2].isdigit()


# ── Monochrome fallback: user ≠ assistant at glyph level ─────────────────────


def test_monochrome_fallback_user_assistant_distinct_by_glyph() -> None:
    user_ascii = LANE_GLYPHS["user"].ascii
    assistant_ascii = LANE_GLYPHS["assistant"].ascii
    # Even in monochrome (no color), the ASCII glyphs must differ
    assert user_ascii != assistant_ascii


def test_thought_secondary_glyph_distinct_from_primary() -> None:
    thought_ascii = LANE_GLYPHS["thought"].ascii
    user_ascii = LANE_GLYPHS["user"].ascii
    assistant_ascii = LANE_GLYPHS["assistant"].ascii
    assert thought_ascii != user_ascii
    assert thought_ascii != assistant_ascii


def test_tool_neutral_rail_distinct_from_role_rails() -> None:
    tool_unicode = LANE_GLYPHS["tool"].unicode
    user_unicode = LANE_GLYPHS["user"].unicode
    assistant_unicode = LANE_GLYPHS["assistant"].unicode
    thought_unicode = LANE_GLYPHS["thought"].unicode
    assert tool_unicode != user_unicode
    assert tool_unicode != assistant_unicode
    assert tool_unicode != thought_unicode


# ── Role-label removal: no "You"/"Agent" in glyph table ──────────────────────


def test_glyph_table_contains_no_role_label_text() -> None:
    for kind, glyph_set in LANE_GLYPHS.items():
        assert "You" not in glyph_set.unicode
        assert "Agent" not in glyph_set.unicode
        assert "Assistant" not in glyph_set.unicode
        assert "You" not in glyph_set.ascii
        assert "Agent" not in glyph_set.ascii
