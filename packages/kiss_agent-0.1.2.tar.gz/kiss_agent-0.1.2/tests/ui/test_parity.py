"""Parity regression tests for shared terminal UI capabilities.

These tests validate backend-agnostic contracts: shared command metadata,
shared session state, structured tool output rendering, and renderer registry.
When a shared behavior changes, these tests should catch regressions in both
Rich and Textual surfaces.
"""

from __future__ import annotations

from kiss.ui.slash import (
    SLASH_COMMANDS,
    SlashCommand,
    slash_commands_for,
    slash_help_markup,
)
from kiss.ui.session_state import RuntimeState, UISessionState
from kiss.ui.shared import (
    ToolResultDisplay,
    create_tool_result_display,
)
from kiss.ui.renderers import RendererRegistry, get_renderer_registry
from kiss.data.ui_tokens import DEFAULT_TOKENS


# ── Slash command metadata ────────────────────────────────────────────────────


def test_slash_command_has_backend_field() -> None:
    cmd = SlashCommand("/test", "test", "/test")
    assert cmd.backend is None  # default: available in both backends


def test_slash_command_backend_restriction() -> None:
    cmd = SlashCommand("/foo", "foo", "/foo", backend="rich")
    assert cmd.backend == "rich"


def test_slash_commands_for_rich_excludes_textual_only() -> None:
    textual_cmds = [c for c in SLASH_COMMANDS if c.backend == "textual"]
    rich_available = slash_commands_for("rich")
    for cmd in textual_cmds:
        assert cmd not in rich_available


def test_slash_commands_for_textual_excludes_rich_only() -> None:
    rich_cmds = [c for c in SLASH_COMMANDS if c.backend == "rich"]
    textual_available = slash_commands_for("textual")
    for cmd in rich_cmds:
        assert cmd not in textual_available


def test_slash_commands_for_includes_shared() -> None:
    shared = [c for c in SLASH_COMMANDS if c.backend is None]
    rich_available = slash_commands_for("rich")
    textual_available = slash_commands_for("textual")
    for cmd in shared:
        assert cmd in rich_available
        assert cmd in textual_available


def test_shared_command_set_matches_expected_contract() -> None:
    shared = {cmd.name for cmd in SLASH_COMMANDS if cmd.backend is None}
    assert shared == {
        "/model",
        "/providers",
        "/free",
        "/connect",
        "/logout",
        "/clear",
        "/compact",
        "/resume",
        "/think",
        "/help",
        "/exit",
        "/quit",
    }


def test_slash_help_markup_shows_backend_only_suffix_for_restricted() -> None:
    markup_rich = slash_help_markup("rich")
    markup_textual = slash_help_markup("textual")
    assert "/compact" in markup_rich
    assert "/compact" in markup_textual


# ── Session state contract ────────────────────────────────────────────────────


def test_runtime_state_has_required_states() -> None:
    required = {
        "idle",
        "streaming",
        "tool_running",
        "compacting",
        "blocked_permission",
        "blocked_user_input",
        "warning",
        "error",
    }
    actual = {s.name for s in RuntimeState}
    assert required <= actual


def test_session_state_transitions() -> None:
    state = UISessionState(context_window=100_000)
    snap = state.current_snapshot()
    assert snap.runtime_state == RuntimeState.idle

    state.on_streaming()
    assert state.current_snapshot().runtime_state == RuntimeState.streaming

    state.on_tool_call("read_file: src/main.py")
    snap = state.current_snapshot()
    assert snap.runtime_state == RuntimeState.tool_running
    assert snap.active_tool_label == "read_file: src/main.py"

    state.on_tool_result()
    assert state.current_snapshot().runtime_state == RuntimeState.streaming

    state.on_compacting("compacting context…")
    snap = state.current_snapshot()
    assert snap.runtime_state == RuntimeState.compacting
    assert snap.compaction_label == "compacting context…"

    state.on_compacted()
    assert state.current_snapshot().runtime_state == RuntimeState.streaming

    state.on_blocked_permission()
    assert state.current_snapshot().runtime_state == RuntimeState.blocked_permission

    state.on_unblocked()
    assert state.current_snapshot().runtime_state == RuntimeState.streaming

    state.on_blocked_user_input()
    assert state.current_snapshot().runtime_state == RuntimeState.blocked_user_input

    state.on_warning("degraded state")
    snap = state.current_snapshot()
    assert snap.runtime_state == RuntimeState.warning
    assert snap.state_message == "degraded state"

    state.on_error("something failed")
    snap = state.current_snapshot()
    assert snap.runtime_state == RuntimeState.error
    assert snap.state_message == "something failed"

    state.on_cancelled()
    assert state.current_snapshot().runtime_state == RuntimeState.idle


def test_session_state_done_accumulates_tokens() -> None:
    state = UISessionState(context_window=100_000)
    state.on_done(
        input_tokens=100,
        output_tokens=50,
        cache_read_tokens=10,
        cache_write_tokens=5,
        thinking_tokens=20,
        cost_usd=0.01,
        context_window=100_000,
        finish_reason="end_turn",
        model_label="provider:model",
    )
    snap = state.current_snapshot()
    assert snap.input_tokens == 100
    assert snap.output_tokens == 50
    assert snap.turn_count == 1
    assert snap.finish_reason == "end_turn"
    assert "provider:model" in snap.models_used

    state.on_done(
        input_tokens=200,
        output_tokens=100,
        cache_read_tokens=0,
        cache_write_tokens=0,
        thinking_tokens=0,
        cost_usd=0.02,
        context_window=100_000,
        finish_reason="end_turn",
        model_label="provider:model",
    )
    snap = state.current_snapshot()
    assert snap.input_tokens == 300
    assert snap.output_tokens == 150
    assert snap.turn_count == 2


def test_session_state_file_change_accumulates() -> None:
    state = UISessionState()
    state.on_file_change("src/main.py", added=10, removed=5)
    state.on_file_change("src/main.py", added=3, removed=1)
    snap = state.current_snapshot()
    assert snap.file_changes["src/main.py"] == (13, 6)


def test_session_state_clear_resets() -> None:
    state = UISessionState(context_window=50_000)
    state.on_streaming()
    state.on_todos([])
    state.clear()
    snap = state.current_snapshot()
    assert snap.runtime_state == RuntimeState.idle
    assert snap.turn_count == 0
    assert snap.context_window == 50_000  # preserved


# ── Structured tool output ───────────────────────────────────────────────────


def test_tool_result_display_has_truncation_meta_field() -> None:
    display = ToolResultDisplay(title="Test", summary="ok")
    assert display.truncation_meta is None


def test_search_code_renderer_populates_truncation_meta() -> None:
    from kiss.agent.tools.result_types import SearchCodeMatch, SearchCodeResult
    from kiss.ui.renderers import get_renderer_registry

    result = SearchCodeResult(
        pattern="foo",
        match_count=5,
        truncated=True,
        matches=[SearchCodeMatch(path="a.py", line=1, text="alpha")],
    )
    display = get_renderer_registry().render("search_code", result)
    assert display is not None
    assert display.truncation_meta is not None
    assert display.truncation_meta.truncated is True


def test_search_code_renderer_no_truncation_meta_when_not_truncated() -> None:
    from kiss.agent.tools.result_types import SearchCodeMatch, SearchCodeResult
    from kiss.ui.renderers import get_renderer_registry

    result = SearchCodeResult(
        pattern="foo",
        match_count=1,
        truncated=False,
        matches=[SearchCodeMatch(path="a.py", line=1, text="alpha")],
    )
    display = get_renderer_registry().render("search_code", result)
    assert display is not None
    assert display.truncation_meta is None


def test_create_tool_result_display_populates_file_changes_when_path_given() -> None:
    output = (
        "path: src/app.py\n"
        "created: False\n"
        "overwrote: True\n"
        "bytes_written: 42\n"
        "line_count: 2\n"
    )
    display = create_tool_result_display("write_file", output, path="src/app.py")
    assert len(display.file_changes) == 1
    assert display.file_changes[0].path == "src/app.py"


def test_create_tool_result_display_no_file_changes_without_path() -> None:
    output = "exit_code: 0\ntimed_out: False\nstdout:\nhello\n"
    display = create_tool_result_display("run_bash", output)
    assert display.file_changes == []


# ── Renderer registry ────────────────────────────────────────────────────────


def test_renderer_registry_returns_none_for_unknown_tool_with_no_attrs() -> None:
    registry = RendererRegistry()
    result = object()
    assert registry.render("unknown_tool", result) is None


def test_renderer_registry_custom_renderer_called() -> None:
    class _MockResult:
        pass

    class _MockRenderer:
        called = False

        def render(self, result: object) -> ToolResultDisplay:
            _MockRenderer.called = True
            return ToolResultDisplay(title="Mock", summary="mocked")

    registry = RendererRegistry()
    renderer = _MockRenderer()
    registry.register("my_tool", renderer)  # type: ignore[arg-type]
    display = registry.render("my_tool", _MockResult())
    assert display is not None
    assert display.title == "Mock"
    assert _MockRenderer.called


def test_renderer_registry_generic_list_fallback() -> None:
    class _ListResult:
        entries = ["a", "b", "c"]
        truncated = False

    registry = RendererRegistry()
    display = registry.render("list_tool", _ListResult())
    assert display is not None
    assert "3" in display.summary


def test_renderer_registry_generic_diff_fallback() -> None:
    class _DiffResult:
        diff = "@@ -1 +1 @@\n-old\n+new"
        truncated = False
        repo_path = "."

    registry = RendererRegistry()
    display = registry.render("diff_tool", _DiffResult())
    assert display is not None
    assert display.sections[0].title == "Diff"


def test_renderer_registry_singleton_accessible() -> None:
    registry = get_renderer_registry()
    assert isinstance(registry, RendererRegistry)


# ── Semantic tokens ──────────────────────────────────────────────────────────


def test_default_tokens_has_all_required_fields() -> None:
    required = {
        "text_primary",
        "text_muted",
        "text_subtle",
        "text_success",
        "text_warning",
        "text_error",
        "text_accent",
        "border_default",
        "border_active",
        "border_subtle",
        "panel_bg",
        "panel_bg_alt",
        "selection_bg",
        "selection_fg",
        "status_idle",
        "status_streaming",
        "status_running",
        "status_blocked",
        "status_compacting",
        "status_warning",
        "status_error",
        "syntax_comment",
        "syntax_keyword",
        "syntax_function",
        "syntax_variable",
        "syntax_string",
        "syntax_number",
        "syntax_type",
        "syntax_operator",
        "syntax_punctuation",
    }
    actual = {f.name for f in DEFAULT_TOKENS.__dataclass_fields__.values()}  # type: ignore[union-attr]
    assert required <= actual


def test_default_tokens_values_are_hex_strings() -> None:
    import dataclasses

    for f in dataclasses.fields(DEFAULT_TOKENS):
        val = getattr(DEFAULT_TOKENS, f.name)
        assert isinstance(val, str), f"{f.name} must be a string"
        assert val.startswith("#"), f"{f.name} must be a hex color starting with '#'"


def test_rich_theme_builder_returns_theme() -> None:
    from rich.theme import Theme
    from kiss.ui.rich.theme import build_rich_theme

    theme = build_rich_theme()
    assert isinstance(theme, Theme)
    assert "ui.text.primary" in theme.styles


def test_tcss_variable_builder_returns_string() -> None:
    from kiss.ui.rich.theme import build_tcss_variables

    tcss = build_tcss_variables()
    assert "$ui-text-primary" in tcss
    assert "$ui-status-error" in tcss


# ── Fuzzy matching policy ─────────────────────────────────────────────────────


def test_suggest_command_returns_high_confidence_match() -> None:
    from kiss.ui.fuzzy import suggest_command

    result = suggest_command("/hlep", ["/help", "/model", "/clear"])
    assert result == "/help"


def test_suggest_command_returns_none_for_low_confidence() -> None:
    from kiss.ui.fuzzy import suggest_command

    result = suggest_command("/xyzabc", ["/help", "/model", "/clear"])
    assert result is None


def test_suggest_tool_returns_match() -> None:
    from kiss.ui.fuzzy import suggest_tool

    result = suggest_tool("read_fle", ["read_file", "write_file", "run_bash"])
    assert result == "read_file"


def test_suggest_tool_returns_none_for_no_match() -> None:
    from kiss.ui.fuzzy import suggest_tool

    result = suggest_tool("zzz_nonexistent", ["read_file", "write_file", "run_bash"])
    assert result is None


def test_resolve_todo_text_exact_id_wins() -> None:
    from kiss.ui.fuzzy import resolve_todo_text

    todos = [("t-0001", "implement login"), ("t-0002", "write tests")]
    result = resolve_todo_text("t-0001", todos)
    assert result.matched
    assert result.suggestion == "t-0001"
    assert not result.ambiguous


def test_resolve_todo_text_exact_text_wins() -> None:
    from kiss.ui.fuzzy import resolve_todo_text

    todos = [("t-0001", "implement login"), ("t-0002", "write tests")]
    result = resolve_todo_text("implement login", todos)
    assert result.matched
    assert result.suggestion == "t-0001"
    assert not result.ambiguous


def test_resolve_todo_text_fuzzy_match() -> None:
    from kiss.ui.fuzzy import resolve_todo_text

    todos = [("t-0001", "implement user login"), ("t-0002", "write integration tests")]
    result = resolve_todo_text("implement login", todos)
    assert result.matched
    assert result.suggestion == "t-0001"


def test_resolve_todo_text_no_match() -> None:
    from kiss.ui.fuzzy import resolve_todo_text

    todos = [("t-0001", "implement login"), ("t-0002", "write tests")]
    result = resolve_todo_text("xyzabc nonsense query", todos)
    assert not result.matched


# ── Command shell parity ──────────────────────────────────────────────────────


def test_parse_command_splits_name_and_args() -> None:
    from kiss.ui.commands import parse_command

    name, args = parse_command("/model provider:model-id")
    assert name == "/model"
    assert args == ["provider:model-id"]


def test_parse_command_no_args() -> None:
    from kiss.ui.commands import parse_command

    name, args = parse_command("/help")
    assert name == "/help"
    assert args == []


def test_slash_help_markup_grouped_has_section_headers() -> None:
    markup = slash_help_markup("rich")
    assert "Session" in markup or "Model" in markup or "Help" in markup


def test_slash_help_markup_rich_includes_compact() -> None:
    markup = slash_help_markup("rich")
    assert "/compact" in markup


def test_slash_help_markup_textual_includes_compact() -> None:
    markup = slash_help_markup("textual")
    assert "/compact" in markup


def test_workspace_history_file_uses_hash() -> None:
    from kiss.ui.prompt_history import workspace_history_file

    path = workspace_history_file()
    assert str(path).startswith(str(__import__("pathlib").Path.home()))
    assert "agent/history" in str(path)
    assert path.suffix == ".txt"
    assert len(path.stem) == 16  # 16-char hex hash


def test_compact_command_in_rich_commands() -> None:
    rich_cmds = {cmd.name for cmd in slash_commands_for("rich")}
    assert "/compact" in rich_cmds


def test_compact_command_in_textual_commands() -> None:
    textual_cmds = {cmd.name for cmd in slash_commands_for("textual")}
    assert "/compact" in textual_cmds
