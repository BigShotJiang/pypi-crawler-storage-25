"""ASK_USER convergence tests: transport types, gating, cancellation, choices, mixed mode."""

from __future__ import annotations

import asyncio
import pytest

from kiss.core.events import (
    AskUserReply,
    AskUserRequest,
    Event,
    EventKind,
    QuestionOption,
)
from kiss.core.deps import AgentDeps


# ── AskUserReply type ─────────────────────────────────────────────────────────


def test_ask_user_reply_from_text_produces_free_text() -> None:
    reply = AskUserReply.from_text("some answer")
    assert reply.outcome == "free_text"
    assert reply.text == "some answer"
    assert reply.selected_choice_ids == []


def test_ask_user_reply_as_text_free_text() -> None:
    reply = AskUserReply(outcome="free_text", text="hello")
    assert reply.as_text() == "hello"


def test_ask_user_reply_as_text_selected() -> None:
    reply = AskUserReply(outcome="selected", selected_choice_ids=["option-a"])
    assert reply.as_text() == "option-a"


def test_ask_user_reply_as_text_cancelled_returns_empty() -> None:
    reply = AskUserReply(outcome="cancelled")
    assert reply.as_text() == ""


def test_ask_user_reply_cancelled_has_no_text() -> None:
    reply = AskUserReply(outcome="cancelled")
    assert reply.text is None
    assert reply.selected_choice_ids == []


# ── AskUserRequest fields ─────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_ask_user_request_defaults() -> None:
    req = AskUserRequest(question="What should I do?")
    assert req.options == []
    assert req.type == "text"
    assert req.multi_select is False


@pytest.mark.asyncio
async def test_ask_user_request_with_options() -> None:
    req = AskUserRequest(
        question="Pick one?",
        type="choice",
        options=[
            QuestionOption(id="a", label="A"),
            QuestionOption(id="b", label="B"),
            QuestionOption(id="c", label="C"),
        ],
    )
    assert [o.id for o in req.options] == ["a", "b", "c"]


@pytest.mark.asyncio
async def test_ask_user_request_reply_future_is_async_future() -> None:
    req = AskUserRequest(question="Q?")
    assert isinstance(req.reply_future, asyncio.Future)


# ── Single-question validator ─────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_ask_user_request_rejects_multiline_multiquestion() -> None:
    with pytest.raises(ValueError, match="single question"):
        AskUserRequest(question="Do you want X?\nDo you also want Y?")


@pytest.mark.asyncio
async def test_ask_user_request_allows_single_question() -> None:
    req = AskUserRequest(question="What is your name?")
    assert req.question == "What is your name?"


@pytest.mark.asyncio
async def test_ask_user_request_allows_inline_double_question_mark() -> None:
    # "A? Or B?" on one line is one question — must not be rejected
    req = AskUserRequest(question="Use approach A? Or approach B?")
    assert req.question.count("?") == 2  # allowed: same line


@pytest.mark.asyncio
async def test_ask_user_request_allows_multiline_single_question() -> None:
    # Multiline but only one ? — must not be rejected
    req = AskUserRequest(question="Given the context:\nwhat should I do?")
    assert req.question == "Given the context:\nwhat should I do?"


@pytest.mark.asyncio
async def test_ask_user_request_rejects_wizard_style_questions() -> None:
    wizard = "What is your name?\nWhat is your quest?\nWhat is your favourite colour?"
    with pytest.raises(ValueError, match="single question"):
        AskUserRequest(question=wizard)


# ── One-active gating ─────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_one_active_ask_user_gating_rejects_second() -> None:
    """While one ASK_USER is pending, a second must be rejected as cancelled."""
    event_queue: asyncio.Queue[Event | None] = asyncio.Queue()
    info_events: list[Event] = []

    _ask_user_active = False

    async def on_ask_user(req: AskUserRequest) -> AskUserReply:
        nonlocal _ask_user_active
        if _ask_user_active:
            await event_queue.put(
                Event(
                    kind=EventKind.INFO,
                    info="[ASK_USER REJECTED] Second question rejected while one is already active.",
                )
            )
            return AskUserReply(outcome="cancelled")
        _ask_user_active = True
        try:
            await event_queue.put(Event(kind=EventKind.ASK_USER, ask_user=req))
            return await req.reply_future
        finally:
            _ask_user_active = False

    # Start first question — will block on reply_future
    req1 = AskUserRequest(question="First question?")
    task1 = asyncio.create_task(on_ask_user(req1))

    # Allow it to reach the await
    await asyncio.sleep(0)

    # Start second question while first is active
    req2 = AskUserRequest(question="Second question?")
    task2 = asyncio.create_task(on_ask_user(req2))
    second = await task2

    # Collect info events
    while not event_queue.empty():
        ev = event_queue.get_nowait()
        if ev and ev.kind == EventKind.INFO:
            info_events.append(ev)

    assert second.outcome == "cancelled"
    assert any("REJECTED" in ev.info for ev in info_events)

    # Resolve first
    req1.reply_future.set_result(AskUserReply.from_text("first answer"))
    first = await task1
    assert first.outcome == "free_text"
    assert first.as_text() == "first answer"


# ── Cancellation routing ──────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_cancelled_outcome_not_exception() -> None:
    """Cancellation must resolve as AskUserReply(outcome='cancelled'), not an exception."""
    req = AskUserRequest(question="Continue?")

    async def _cancel() -> None:
        await asyncio.sleep(0)
        req.reply_future.set_result(AskUserReply(outcome="cancelled"))

    asyncio.create_task(_cancel())
    reply = await req.reply_future

    assert reply.outcome == "cancelled"
    assert not req.reply_future.exception()


@pytest.mark.asyncio
async def test_cancelled_outcome_as_text_is_empty() -> None:
    reply = AskUserReply(outcome="cancelled")
    assert reply.as_text() == ""


# ── Choice selection ──────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_choice_selection_reply() -> None:
    req = AskUserRequest(
        question="Pick one?",
        type="choice",
        options=[
            QuestionOption(id="alpha", label="Alpha"),
            QuestionOption(id="beta", label="Beta"),
            QuestionOption(id="gamma", label="Gamma"),
        ],
    )

    async def _resolve() -> None:
        await asyncio.sleep(0)
        req.reply_future.set_result(
            AskUserReply(outcome="selected", selected_choice_ids=["beta"])
        )

    asyncio.create_task(_resolve())
    reply = await req.reply_future

    assert reply.outcome == "selected"
    assert reply.selected_choice_ids == ["beta"]
    assert reply.as_text() == "beta"


# ── Free-text answers ─────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_free_text_reply() -> None:
    req = AskUserRequest(question="Describe the issue?")

    async def _resolve() -> None:
        await asyncio.sleep(0)
        req.reply_future.set_result(AskUserReply.from_text("the server is down"))

    asyncio.create_task(_resolve())
    reply = await req.reply_future

    assert reply.outcome == "free_text"
    assert reply.text == "the server is down"


# ── Mixed-mode behavior ───────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_ask_user_request_mixed_mode_fields() -> None:
    req = AskUserRequest(
        question="Choose or describe?",
        type="choice_or_text",
        options=[
            QuestionOption(id="a", label="A"),
            QuestionOption(id="b", label="B"),
        ],
        default_id="a",
    )
    assert [o.id for o in req.options[:2]] == ["a", "b"]
    assert req.type == "choice_or_text"
    assert req.default_id == "a"


@pytest.mark.asyncio
async def test_ask_user_request_freeform_false_disables_text_entry() -> None:
    req = AskUserRequest(
        question="Must choose?",
        type="choice",
        options=[
            QuestionOption(id="x", label="X"),
            QuestionOption(id="y", label="Y"),
        ],
    )
    assert req.type == "choice"


# ── Backend-equivalent outcomes ───────────────────────────────────────────────


def test_all_outcome_values_are_valid_literals() -> None:
    for outcome in ("selected", "free_text", "cancelled"):
        r = AskUserReply(outcome=outcome)  # type: ignore[arg-type]
        assert r.outcome == outcome


def test_ask_user_reply_selected_requires_choice_id() -> None:
    reply = AskUserReply(outcome="selected", selected_choice_ids=["opt-1"])
    assert reply.selected_choice_ids == ["opt-1"]
    assert reply.as_text() == "opt-1"


def test_deps_on_ask_user_callback_type() -> None:
    """AgentDeps.on_ask_user accepts a callable returning AskUserReply."""

    async def cb(req: AskUserRequest) -> AskUserReply:
        return AskUserReply.from_text("ok")

    deps = AgentDeps(on_ask_user=cb)
    assert deps.on_ask_user is cb


# ── New-schema validation ─────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_header_too_short_raises() -> None:
    with pytest.raises(ValueError, match="header must be 3-30 chars"):
        AskUserRequest(question="Q?", header="")


@pytest.mark.asyncio
async def test_header_too_long_raises() -> None:
    with pytest.raises(ValueError, match="header must be 3-30 chars"):
        AskUserRequest(question="Q?", header="x" * 31)


@pytest.mark.asyncio
async def test_duplicate_option_ids_raises() -> None:
    with pytest.raises(ValueError, match="unique"):
        AskUserRequest(
            question="Q?",
            type="choice",
            options=[
                QuestionOption(id="a", label="A"),
                QuestionOption(id="a", label="B"),
            ],
        )


@pytest.mark.asyncio
async def test_invalid_option_id_format_raises() -> None:
    with pytest.raises(ValueError, match="invalid characters"):
        AskUserRequest(
            question="Q?",
            type="choice",
            options=[QuestionOption(id="bad id", label="Bad")],
        )


@pytest.mark.asyncio
async def test_choice_without_options_raises() -> None:
    with pytest.raises(ValueError, match="type='choice' requires non-empty options"):
        AskUserRequest(question="Q?", type="choice")


@pytest.mark.asyncio
async def test_text_with_options_raises() -> None:
    with pytest.raises(ValueError, match="type='text' requires empty options"):
        AskUserRequest(
            question="Q?",
            type="text",
            options=[QuestionOption(id="a", label="A")],
        )


@pytest.mark.asyncio
async def test_multi_select_without_choice_raises() -> None:
    with pytest.raises(
        ValueError, match="multi_select is only supported for type='choice'"
    ):
        AskUserRequest(
            question="Q?",
            type="text",
            multi_select=True,
        )


@pytest.mark.asyncio
async def test_default_id_not_found_raises() -> None:
    with pytest.raises(ValueError, match="default_id"):
        AskUserRequest(
            question="Q?",
            type="choice",
            options=[QuestionOption(id="a", label="A")],
            default_id="missing",
        )


@pytest.mark.asyncio
async def test_yesno_populates_options() -> None:
    req = AskUserRequest(question="Continue?", type="yesno")
    assert req.options == [
        QuestionOption(id="yes", label="Yes"),
        QuestionOption(id="no", label="No"),
    ]


@pytest.mark.asyncio
async def test_choice_or_text_appends_other_option() -> None:
    req = AskUserRequest(
        question="Pick?",
        type="choice_or_text",
        options=[QuestionOption(id="a", label="A")],
    )
    assert len(req.options) == 2
    assert req.options[-1].id == "_kiss_other_"


@pytest.mark.asyncio
async def test_choice_or_text_without_options_raises() -> None:
    with pytest.raises(ValueError, match="choice_or_text"):
        AskUserRequest(question="Pick?", type="choice_or_text")


@pytest.mark.asyncio
async def test_interaction_id_is_unique() -> None:
    req1 = AskUserRequest(question="Q1?")
    req2 = AskUserRequest(question="Q2?")
    assert req1.interaction_id != req2.interaction_id


def test_ask_user_reply_selected_choice_ids_as_text_joins() -> None:
    reply = AskUserReply(outcome="selected", selected_choice_ids=["a", "b", "c"])
    assert reply.as_text() == "a, b, c"


def test_ask_user_reply_empty_selected_choice_ids() -> None:
    reply = AskUserReply(outcome="selected")
    assert reply.selected_choice_ids == []
