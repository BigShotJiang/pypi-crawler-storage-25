from __future__ import annotations

from pathlib import Path

from kiss.ui.prompt_history import append_prompt_history, load_prompt_history
from kiss.ui.textual.widgets.history_input import HistoryInput


class _RecordingHistoryInput(HistoryInput):
    def __init__(self, history_path: Path) -> None:
        super().__init__(history_path=history_path)
        self.seen: list[str] = []

    def _set_history_value(self, value: str) -> None:
        self.seen.append(value)


def test_prompt_history_round_trips(tmp_path: Path) -> None:
    path = tmp_path / "history.txt"

    append_prompt_history(path, "first prompt")
    append_prompt_history(path, "second prompt")

    assert load_prompt_history(path) == ["first prompt", "second prompt"]


def test_history_input_navigates_previous_and_next(tmp_path: Path) -> None:
    path = tmp_path / "history.txt"
    path.write_text("one\ntwo\n", encoding="utf-8")
    widget = _RecordingHistoryInput(history_path=path)

    widget.on_mount()
    widget._history_draft = "draft"

    widget.action_history_previous()
    assert widget.seen[-1] == "two"

    widget.action_history_previous()
    assert widget.seen[-1] == "one"

    widget.action_history_next()
    assert widget.seen[-1] == "two"

    widget.action_history_next()
    assert widget.seen[-1] == "draft"


def test_history_input_remember_submission_updates_memory_and_disk(
    tmp_path: Path,
) -> None:
    path = tmp_path / "history.txt"
    widget = _RecordingHistoryInput(history_path=path)

    widget.on_mount()
    widget.remember_submission("hello")

    assert load_prompt_history(path) == ["hello"]
    widget.action_history_previous()
    assert widget.seen[-1] == "hello"
