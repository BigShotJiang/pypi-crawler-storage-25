"""Tests for kiss.core.deps."""

from __future__ import annotations

import hashlib

import pytest

from kiss.core.deps import AgentDeps, StuckLoopTracker
from kiss.core.settings import WebSearchConfig
from kiss.core.types import PermissionAction


def test_agent_deps_defaults():
    deps = AgentDeps()
    assert deps.context_window == 128_000
    assert deps.current_usage_tokens == 0
    assert deps.tool_output_safety_buffer == 10_000
    assert deps.tool_output_max_tokens == 12_000
    assert deps.tool_output_min_tokens == 1_000
    assert deps.response_token_reserve == 12_000
    assert deps.stuck_loop_warn_threshold == 3
    assert deps.stuck_loop_abort_threshold == 5
    assert deps.confirm_permission is None
    assert deps.on_tool_use is None
    assert deps.resolved_refs == {}
    assert deps.workspace_root is None
    assert deps.web_search_config == WebSearchConfig()


@pytest.mark.asyncio
async def test_agent_deps_confirm_permission():
    async def always_true(prompt: str | PermissionAction) -> bool:
        return True

    deps = AgentDeps(confirm_permission=always_true)
    assert deps.confirm_permission is not None
    assert await deps.confirm_permission("delete?") is True


@pytest.mark.asyncio
async def test_agent_deps_on_tool_use():
    calls: list[tuple[str, dict]] = []

    async def recorder(name: str, args: dict) -> None:
        calls.append((name, args))

    deps = AgentDeps(on_tool_use=recorder)
    assert deps.on_tool_use is not None
    await deps.on_tool_use("read_file", {"path": "/tmp/x"})
    assert calls == [("read_file", {"path": "/tmp/x"})]


def test_stuck_loop_tracker_warns_on_repeated_args() -> None:
    tracker = StuckLoopTracker()
    args_hash = "same"

    assert tracker.check("search_code", args_hash, "r1", 3, 5).action == "ok"
    assert tracker.check("search_code", args_hash, "r2", 3, 5).action == "ok"
    result = tracker.check("search_code", args_hash, "r3", 3, 5)

    assert result.action == "warn"
    assert "identical arguments 3 times" in result.message


def test_stuck_loop_tracker_aborts_on_repeated_args() -> None:
    tracker = StuckLoopTracker()
    args_hash = "same"

    for idx in range(4):
        tracker.check("search_code", args_hash, f"r{idx}", 3, 5)
    result = tracker.check("search_code", args_hash, "r5", 3, 5)

    assert result.action == "abort"
    assert "identical arguments 5 times" in result.message


def test_stuck_loop_tracker_detects_same_tool_alternating_pattern() -> None:
    tracker = StuckLoopTracker()
    a_hash = "a"
    b_hash = "b"

    tracker.check("search_code", a_hash, "ra", 3, 5)
    tracker.check("search_code", b_hash, "rb", 3, 5)
    tracker.check("search_code", a_hash, "ra2", 3, 5)
    result = tracker.check("search_code", b_hash, "rb2", 3, 5)

    assert result.action == "warn"
    assert "Alternating tool loop detected" in result.message


def test_stuck_loop_tracker_aborts_on_same_tool_alternating_fifth_call() -> None:
    tracker = StuckLoopTracker()
    sequence = [
        ("search_code", "a", "ra"),
        ("search_code", "b", "rb"),
        ("search_code", "a", "ra2"),
        ("search_code", "b", "rb2"),
        ("search_code", "a", "ra3"),
    ]

    result = None
    for tool_name, args_hash, result_text in sequence:
        result = tracker.check(tool_name, args_hash, result_text, 3, 5)

    assert result is not None
    assert result.action == "abort"
    assert "Alternating tool loop detected" in result.message


def test_stuck_loop_tracker_ignores_cross_tool_alternation() -> None:
    tracker = StuckLoopTracker()

    calls = [
        ("read_file", "a", "ra"),
        ("edit_file", "b", "rb"),
        ("read_file", "a", "ra2"),
        ("edit_file", "b", "rb2"),
    ]

    for tool_name, args_hash, result_text in calls:
        result = tracker.check(tool_name, args_hash, result_text, 3, 5)

    assert result.action == "ok"


def test_stuck_loop_tracker_detects_tool_scoped_noop_results() -> None:
    tracker = StuckLoopTracker()
    result_hash = hashlib.sha256("same result".encode()).hexdigest()

    assert tracker.check("tool_a", "a1", "same result", 3, 5).action == "ok"
    assert tracker.check("tool_b", "b1", "same result", 3, 5).action == "ok"
    assert tracker.check("tool_b", "b2", "same result", 3, 5).action == "ok"
    result = tracker.check("tool_b", "b3", "same result", 3, 5)

    assert result.action == "warn"
    assert f"noop:tool_b:{result_hash}" in tracker.warned_signatures


def test_stuck_loop_tracker_is_hard_blocked() -> None:
    tracker = StuckLoopTracker()
    args = {"pattern": "foo"}
    assert not tracker.is_hard_blocked("search_code", args)

    tracker.register_tool_call("search_code", args)
    args_hash = tracker.pending_tool_calls.pop().args_hash
    for i in range(3):
        tracker.check("search_code", args_hash, f"r{i}", 3, 5)

    assert tracker.is_hard_blocked("search_code", args)


def test_stuck_loop_tracker_hard_blocks_repeated_args_after_warn() -> None:
    tracker = StuckLoopTracker()
    args_hash = "same"

    tracker.check("search_code", args_hash, "r1", 3, 5)
    tracker.check("search_code", args_hash, "r2", 3, 5)
    warn = tracker.check("search_code", args_hash, "r3", 3, 5)
    assert warn.action == "warn"

    hard = tracker.check("search_code", args_hash, "r4", 3, 5)
    assert hard.action == "hard_block"
    assert "identical arguments 4 times" in hard.message

    abort = tracker.check("search_code", args_hash, "r5", 3, 5)
    assert abort.action == "abort"


def test_stuck_loop_tracker_hard_blocks_noop_result_after_warn() -> None:
    tracker = StuckLoopTracker()

    tracker.check("tool_b", "b1", "same result", 3, 5)
    tracker.check("tool_b", "b2", "same result", 3, 5)
    warn = tracker.check("tool_b", "b3", "same result", 3, 5)
    assert warn.action == "warn"

    hard = tracker.check("tool_b", "b4", "same result", 3, 5)
    assert hard.action == "hard_block"
    assert "same result 4 times" in hard.message


def test_stuck_loop_tracker_ignores_varied_calls() -> None:
    tracker = StuckLoopTracker()
    calls = [
        ("tool_a", "a1", "r1"),
        ("tool_a", "a2", "r2"),
        ("tool_b", "b1", "r1"),
        ("tool_c", "c1", "r3"),
    ]

    for tool_name, args_hash, result_text in calls:
        result = tracker.check(tool_name, args_hash, result_text, 3, 5)
        assert result.action == "ok"
