"""Tests for reasoning budget control."""

from __future__ import annotations

from kiss.core.reasoning_budget import ReasoningBudget


def test_should_reduce_thinking_when_over_budget() -> None:
    budget = ReasoningBudget(max_thinking_tokens=1000, max_retries=2)
    budget.record_thinking(1500)
    assert budget.should_reduce_thinking() is True


def test_should_reduce_thinking_when_under_budget() -> None:
    budget = ReasoningBudget(max_thinking_tokens=1000, max_retries=2)
    budget.record_thinking(500)
    assert budget.should_reduce_thinking() is False


def test_should_reduce_thinking_no_limit() -> None:
    budget = ReasoningBudget(max_thinking_tokens=0, max_retries=2)
    budget.record_thinking(5000)
    assert budget.should_reduce_thinking() is False


def test_should_reduce_thinking_max_retries_exceeded() -> None:
    budget = ReasoningBudget(max_thinking_tokens=1000, max_retries=2)
    budget.record_thinking(1500)
    budget.record_retry()
    budget.record_retry()
    assert budget.should_reduce_thinking() is False


def test_reset_clears_usage() -> None:
    budget = ReasoningBudget(max_thinking_tokens=1000, max_retries=2)
    budget.record_thinking(1500)
    budget.record_retry()
    budget.reset()
    assert budget.current_thinking_tokens == 0
    assert budget.retry_count == 0
    assert budget.should_reduce_thinking() is False
