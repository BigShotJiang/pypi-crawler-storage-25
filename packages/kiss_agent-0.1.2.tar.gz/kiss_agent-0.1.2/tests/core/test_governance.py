"""Tests for four-pass governance pipeline."""

from __future__ import annotations

from kiss.core.governance import (
    GovernanceResult,
    _ToolCallSignature,
    run_governance_pipeline,
)


def test_pass1_deduplicates_identical_calls() -> None:
    tool_calls = [
        ("read_file", {"path": "foo.py"}),
        ("read_file", {"path": "foo.py"}),
        ("read_file", {"path": "bar.py"}),
    ]
    result = run_governance_pipeline(
        tool_calls, context_tokens=1000, context_budget=10000
    )
    assert result.deduplicated_calls == 1
    assert "duplicate" in result.mechanical_summary.lower()


def test_pass1_detects_no_op_calls() -> None:
    tool_calls = [("read_file", {})]
    result = run_governance_pipeline(
        tool_calls, context_tokens=1000, context_budget=10000
    )
    assert result.no_op_calls_detected == 1


def test_pass2_triggers_compaction_when_over_budget() -> None:
    result = run_governance_pipeline([], context_tokens=15000, context_budget=10000)
    assert result.compaction_triggered is True
    assert result.tokens_before_compaction == 15000


def test_pass2_no_compaction_when_under_budget() -> None:
    result = run_governance_pipeline([], context_tokens=5000, context_budget=10000)
    assert result.compaction_triggered is False


def test_pass3_detects_stuck_loop() -> None:
    tool_calls = [("run_bash", {"command": "pwd"})] * 5
    result = run_governance_pipeline(
        tool_calls,
        context_tokens=1000,
        context_budget=10000,
        stuck_loop_abort_threshold=5,
    )
    assert result.stuck_loop_detected is True
    assert result.safety_blocked is True


def test_pass3_detects_alternating_pattern() -> None:
    tool_calls = [
        ("run_bash", {"command": "pwd"}),
        ("run_bash", {"command": "ls"}),
    ] * 3
    result = run_governance_pipeline(
        tool_calls,
        context_tokens=1000,
        context_budget=10000,
        stuck_loop_abort_threshold=5,
    )
    assert result.stuck_loop_detected is True
    assert result.safety_blocked is True
    assert "alternating" in result.safety_block_reason.lower()


def test_pass3_no_stuck_loop_with_varied_calls() -> None:
    tool_calls = [
        ("run_bash", {"command": "pwd"}),
        ("run_bash", {"command": "ls"}),
        ("run_bash", {"command": "pwd"}),
    ]
    result = run_governance_pipeline(
        tool_calls,
        context_tokens=1000,
        context_budget=10000,
        stuck_loop_abort_threshold=5,
    )
    assert result.stuck_loop_detected is False
    assert result.safety_blocked is False


def test_pass3_flags_stale_ledger() -> None:
    result = run_governance_pipeline(
        [],
        context_tokens=1000,
        context_budget=10000,
        ledger_stale=True,
    )
    assert result.stale_ledger is True


def test_pass4_assembles_prompt() -> None:
    result = run_governance_pipeline([], context_tokens=1000, context_budget=10000)
    assert result.final_prompt_assembled is True


def test_tool_call_signature_equality() -> None:
    sig1 = _ToolCallSignature.from_call("read_file", {"path": "foo.py"})
    sig2 = _ToolCallSignature.from_call("read_file", {"path": "foo.py"})
    assert sig1 == sig2


def test_tool_call_signature_inequality() -> None:
    sig1 = _ToolCallSignature.from_call("read_file", {"path": "foo.py"})
    sig2 = _ToolCallSignature.from_call("read_file", {"path": "bar.py"})
    assert sig1 != sig2


def test_is_blocked_property() -> None:
    assert GovernanceResult(safety_blocked=True).is_blocked is True
    assert GovernanceResult(safety_blocked=False).is_blocked is False
