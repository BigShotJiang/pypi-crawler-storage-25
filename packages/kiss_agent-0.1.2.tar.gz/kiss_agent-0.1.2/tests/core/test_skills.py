"""Tests for SkillLoader — markdown-based skill injection."""

from __future__ import annotations

from pathlib import Path

import pytest

from kiss.core.session_db import SessionDB
from kiss.core.skills import SkillLoader


@pytest.fixture
def db(tmp_path: Path) -> SessionDB:
    db_path = tmp_path / "session.db"
    session_db = SessionDB(db_path)
    session_db.execute_raw(
        "INSERT INTO sessions (id, workspace_root) VALUES (?, ?)",
        ("test-session", str(tmp_path)),
    )
    return session_db


@pytest.fixture
def project_root(tmp_path: Path) -> Path:
    return tmp_path


@pytest.fixture
def loader(db: SessionDB, project_root: Path) -> SkillLoader:
    return SkillLoader(db=db, project_root=project_root, max_total_skill_tokens=10_000)


def test_load_no_skills_dir(loader: SkillLoader) -> None:
    assert loader.load("test-session") == ""


def test_load_user_skill(loader: SkillLoader, tmp_path: Path, monkeypatch) -> None:
    skills_dir = tmp_path / "skills"
    skills_dir.mkdir()
    (skills_dir / "testing.md").write_text("# Testing skill\nRun tests first.")
    monkeypatch.setattr("kiss.core.skills._USER_SKILLS_DIR", skills_dir)
    result = loader.load("test-session")
    assert '<skill name="testing"' in result
    assert "Run tests first." in result


def test_load_project_skill(loader: SkillLoader, project_root: Path) -> None:
    skills_dir = project_root / ".kiss" / "skills"
    skills_dir.mkdir(parents=True)
    (skills_dir / "linting.md").write_text("# Linting\nRun linter before commit.")
    result = loader.load("test-session")
    assert '<skill name="linting"' in result


def test_project_overrides_user(
    loader: SkillLoader, tmp_path: Path, monkeypatch, project_root: Path
) -> None:
    user_skills = tmp_path / "skills"
    user_skills.mkdir()
    (user_skills / "shared.md").write_text("user version")
    proj_skills = project_root / ".kiss" / "skills"
    proj_skills.mkdir(parents=True)
    (proj_skills / "shared.md").write_text("project version")
    monkeypatch.setattr("kiss.core.skills._USER_SKILLS_DIR", user_skills)
    result = loader.load("test-session")
    assert "project version" in result
    assert "user version" not in result


def test_frontmatter_parsing(loader: SkillLoader, project_root: Path) -> None:
    skills_dir = project_root / ".kiss" / "skills"
    skills_dir.mkdir(parents=True)
    (skills_dir / "priority-test.md").write_text(
        "---\npriority: 10\nscope: write\nversion: 1.2\n---\nContent here."
    )
    result = loader.load("test-session")
    assert 'version="1.2"' in result
    assert 'scope="write"' in result


def test_frontmatter_defaults(loader: SkillLoader, project_root: Path) -> None:
    skills_dir = project_root / ".kiss" / "skills"
    skills_dir.mkdir(parents=True)
    (skills_dir / "no-frontmatter.md").write_text("Plain content.")
    records = loader._discover("test-session")
    skill = next(r for r in records if r.name == "no-frontmatter")
    assert skill.priority == 100
    assert skill.scope is None


def test_priority_sorting(loader: SkillLoader, project_root: Path) -> None:
    skills_dir = project_root / ".kiss" / "skills"
    skills_dir.mkdir(parents=True)
    (skills_dir / "low-priority.md").write_text("---\npriority: 50\n---\nLow")
    (skills_dir / "high-priority.md").write_text("---\npriority: 1\n---\nHigh")
    (skills_dir / "default.md").write_text("Default (100)")
    records = loader._discover("test-session")
    names = [r.name for r in records]
    assert names == ["high-priority", "low-priority", "default"]


def test_alpha_tiebreak(loader: SkillLoader, project_root: Path) -> None:
    skills_dir = project_root / ".kiss" / "skills"
    skills_dir.mkdir(parents=True)
    (skills_dir / "beta.md").write_text("Beta")
    (skills_dir / "alpha.md").write_text("Alpha")
    records = loader._discover("test-session")
    names = [r.name for r in records]
    assert names == ["alpha", "beta"]


def test_token_budget_skips_exceeding(loader: SkillLoader, project_root: Path) -> None:
    skills_dir = project_root / ".kiss" / "skills"
    skills_dir.mkdir(parents=True)
    (skills_dir / "huge.md").write_text("---\npriority: 1\n---\n" + "A" * 50_000)
    (skills_dir / "small.md").write_text("---\npriority: 2\n---\nSmall")
    result = loader.load("test-session")
    assert "Small" in result
    assert "AAAA" not in result


def test_skill_starts_untrusted(loader: SkillLoader, project_root: Path) -> None:
    skills_dir = project_root / ".kiss" / "skills"
    skills_dir.mkdir(parents=True)
    (skills_dir / "test.md").write_text("Content")
    result = loader.load("test-session")
    assert 'trust="untrusted"' in result


def test_trust_skill(loader: SkillLoader, project_root: Path) -> None:
    skills_dir = project_root / ".kiss" / "skills"
    skills_dir.mkdir(parents=True)
    (skills_dir / "test.md").write_text("Content")
    loader.load("test-session")
    ok, fp = loader.trust_skill("test-session", "test")
    assert ok is True
    assert len(fp) == 16
    result = loader.load("test-session")
    assert 'trust="untrusted"' not in result


def test_trust_skill_file_not_found(loader: SkillLoader) -> None:
    ok, msg = loader.trust_skill("test-session", "nonexistent")
    assert ok is False
    assert "not found" in msg.lower()


def test_drift_revokes_trust(loader: SkillLoader, project_root: Path) -> None:
    skills_dir = project_root / ".kiss" / "skills"
    skills_dir.mkdir(parents=True)
    (skills_dir / "test.md").write_text("v1 content")
    loader.load("test-session")
    loader.trust_skill("test-session", "test")
    (skills_dir / "test.md").write_text("v2 content")
    result = loader.load("test-session")
    assert 'trust="untrusted"' in result


def test_skill_priorities_override(project_root: Path, db: SessionDB) -> None:
    skills_dir = project_root / ".kiss" / "skills"
    skills_dir.mkdir(parents=True)
    (skills_dir / "a.md").write_text("A")
    (skills_dir / "b.md").write_text("B")
    loader = SkillLoader(
        db=db,
        project_root=project_root,
        skill_priorities={"b": 1, "a": 50},
    )
    records = loader._discover("test-session")
    names = [r.name for r in records]
    assert names == ["b", "a"]


def test_malformed_skill_skipped(loader: SkillLoader, project_root: Path) -> None:
    skills_dir = project_root / ".kiss" / "skills"
    skills_dir.mkdir(parents=True)
    (skills_dir / "bad.md").write_text("---\npriority: not_an_int\n---\nStill works")
    (skills_dir / "good.md").write_text("Good skill")
    result = loader.load("test-session")
    assert "Good skill" in result
    assert "Still works" in result


def test_unreadable_skill_skipped(
    loader: SkillLoader, project_root: Path, caplog
) -> None:
    skills_dir = project_root / ".kiss" / "skills"
    skills_dir.mkdir(parents=True)
    bad_file = skills_dir / "unreadable.md"
    bad_file.write_text("test")
    bad_file.chmod(0o000)
    result = loader.load("test-session")
    assert result == ""
    bad_file.chmod(0o644)


def test_fingerprint_is_deterministic() -> None:
    fp1 = SkillLoader._fingerprint("hello")
    fp2 = SkillLoader._fingerprint("hello")
    assert fp1 == fp2
    assert len(fp1) == 16


def test_fingerprint_differs_on_change() -> None:
    fp1 = SkillLoader._fingerprint("hello")
    fp2 = SkillLoader._fingerprint("world")
    assert fp1 != fp2
