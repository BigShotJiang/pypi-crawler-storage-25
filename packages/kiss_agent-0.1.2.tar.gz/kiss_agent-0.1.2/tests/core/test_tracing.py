"""Tests for kiss.core.tracing."""

from __future__ import annotations

import asyncio
import json

import pytest

from kiss.core.tracing import (
    SessionTracer,
    get_current_tracer,
    reset_tracer_context,
    set_current_tracer_context,
)


def test_live_snapshot_tracks_active_and_finished_spans() -> None:
    tracer = SessionTracer()

    with tracer.span("root", route="reviewer"):
        active, finished = tracer.get_live_snapshot()
        assert len(active) == 1
        assert finished == []

    active, finished = tracer.get_live_snapshot()
    assert active == []
    assert len(finished) == 1
    assert finished[0].name == "root"


def test_contextvar_round_trip_restores_parent_tracer() -> None:
    parent = SessionTracer()
    child = SessionTracer()

    parent_token = set_current_tracer_context(parent)
    try:
        assert get_current_tracer() is parent
        child_token = set_current_tracer_context(child)
        try:
            assert get_current_tracer() is child
        finally:
            reset_tracer_context(child_token)
        assert get_current_tracer() is parent
    finally:
        reset_tracer_context(parent_token)

    assert get_current_tracer() is None


@pytest.mark.asyncio
async def test_contextvar_propagates_across_async_calls() -> None:
    tracer = SessionTracer()
    token = set_current_tracer_context(tracer)
    try:
        await asyncio.sleep(0)
        assert get_current_tracer() is tracer
    finally:
        reset_tracer_context(token)


def test_export_jsonl_writes_hierarchy_and_events(tmp_path) -> None:
    tracer = SessionTracer()

    with tracer.span("root", route="full_pipeline"):
        tracer.event("pipeline_started", task_hash="abc123")
        with tracer.span("child", role="coder"):
            tracer.event("worker_trace", latency_ms=12)

    export_path = tmp_path / "traces.jsonl"
    tracer.export_jsonl(export_path)

    records = [
        json.loads(line)
        for line in export_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    assert records[0]["record_type"] == "session"
    assert records[0]["version"] == 1
    assert records[0]["service_name"] == "kiss-agent"
    assert records[0]["active_span_count"] == 0

    spans = records[1:]
    assert [span["name"] for span in spans] == ["root", "child"]
    assert spans[0]["record_type"] == "span"
    assert spans[0]["parent_span_id"] is None
    assert spans[0]["events"][0]["name"] == "pipeline_started"
    assert spans[1]["parent_span_id"] == spans[0]["span_id"]
    assert spans[1]["events"][0]["name"] == "worker_trace"
