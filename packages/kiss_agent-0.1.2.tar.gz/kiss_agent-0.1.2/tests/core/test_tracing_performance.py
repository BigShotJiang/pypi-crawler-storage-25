"""Performance smoke tests for kiss.core.tracing."""

from __future__ import annotations

import socket
import time

from kiss.core.tracing import SessionTracer


def test_span_creation_overhead_is_sub_millisecond() -> None:
    tracer = SessionTracer()
    iterations = 10_000

    start = time.perf_counter()
    for index in range(iterations):
        with tracer.span("perf", index=index):
            pass
    elapsed_ms = (time.perf_counter() - start) * 1_000
    per_span_ms = elapsed_ms / iterations

    assert per_span_ms < 0.1


def test_export_jsonl_makes_no_socket_connections(tmp_path, monkeypatch) -> None:
    tracer = SessionTracer()
    attempts: list[tuple[tuple[object, ...], dict[str, object]]] = []

    def fail_connect(*args: object, **kwargs: object) -> None:
        attempts.append((args, kwargs))
        raise AssertionError("network access attempted")

    monkeypatch.setattr(socket.socket, "connect", fail_connect)
    monkeypatch.setattr(socket, "create_connection", fail_connect)

    with tracer.span("perf"):
        tracer.event("worker_trace", latency_ms=1)
    tracer.export_jsonl(tmp_path / "traces.jsonl")

    assert attempts == []
