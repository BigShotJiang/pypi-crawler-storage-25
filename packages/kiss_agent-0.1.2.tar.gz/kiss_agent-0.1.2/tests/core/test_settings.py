"""Tests for kiss.core.settings."""

from __future__ import annotations

import json
import pytest

from kiss.core.settings import (
    Settings,
    SettingsError,
    WebSearchConfig,
    _FALLBACK_WINDOW,
    _DATE_SUFFIX_RE,
    discover_workspace_root,
    get_context_window,
    get_supported_params,
    is_usable_model_mode,
    model_mode,
    model_supports_reasoning,
    settings_load,
)


# ── get_context_window ────────────────────────────────────────────────────────


def test_get_context_window_override():
    assert get_context_window("gpt-4o", override=999) == 999


def test_get_context_window_known_model():
    # litellm reports max_input_tokens=1_000_000 for claude-sonnet-4-6
    assert get_context_window("claude-sonnet-4-6") == 1_000_000


def test_get_context_window_unknown_model_fallback():
    assert get_context_window("unknown-model-xyz") == _FALLBACK_WINDOW


def test_get_context_window_versioned_date_suffix():
    # Date-suffixed model should resolve same as base model via suffix strip
    assert get_context_window("claude-sonnet-4-6-20250514") == get_context_window(
        "claude-sonnet-4-6"
    )


def test_get_context_window_versioned_longest_prefix_wins():
    # gpt-4o-mini-20240718 → strip suffix → gpt-4o-mini (128_000, same as base)
    assert get_context_window("gpt-4o-mini-20240718") == get_context_window(
        "gpt-4o-mini"
    )


def test_get_context_window_gemini_flash_lite_versioned():
    assert get_context_window("gemini-2.0-flash-lite-20250513") == get_context_window(
        "gemini-2.0-flash-lite"
    )


def test_date_suffix_re_strips_correctly():
    assert _DATE_SUFFIX_RE.sub("", "claude-sonnet-4-6-20250514") == "claude-sonnet-4-6"
    assert _DATE_SUFFIX_RE.sub("", "gpt-4o-mini-20240718") == "gpt-4o-mini"
    assert _DATE_SUFFIX_RE.sub("", "no-date") == "no-date"


def test_model_supports_reasoning_true_for_sonnet():
    assert model_supports_reasoning("claude-sonnet-4-6") is True


def test_model_supports_reasoning_false_for_gpt4o():
    assert model_supports_reasoning("gpt-4o") is False


def test_model_supports_reasoning_false_for_unknown():
    assert model_supports_reasoning("unknown-model-xyz") is False


def test_model_supports_reasoning_versioned_strips_suffix():
    assert model_supports_reasoning("claude-sonnet-4-6-20250514") is True


def test_get_supported_params_contains_expected():
    params = get_supported_params("claude-sonnet-4-6")
    assert "thinking" in params
    assert "tools" in params
    assert "stream" in params


def test_get_supported_params_o3_has_reasoning_effort():
    params = get_supported_params("o3")
    assert "reasoning_effort" in params
    assert "thinking" not in params


def test_get_supported_params_unknown_returns_empty():
    assert get_supported_params("unknown-model-xyz") == frozenset()


def test_model_mode_chat():
    assert model_mode("gpt-4o") == "chat"
    assert model_mode("claude-sonnet-4-6") == "chat"


def test_model_mode_non_chat():
    assert model_mode("text-embedding-ada-002") == "embedding"
    assert model_mode("dall-e-3") == "image_generation"
    assert model_mode("whisper-1") == "audio_transcription"


def test_model_mode_unknown_returns_none():
    assert model_mode("unknown-model-xyz") is None


def test_is_usable_model_mode_chat():
    assert is_usable_model_mode("gpt-4o") is True
    assert is_usable_model_mode("claude-sonnet-4-6") is True


def test_is_usable_model_mode_completion():
    assert is_usable_model_mode("gpt-3.5-turbo-instruct") is True


def test_is_usable_model_mode_rejects_non_chat():
    assert is_usable_model_mode("text-embedding-ada-002") is False
    assert is_usable_model_mode("dall-e-3") is False
    assert is_usable_model_mode("whisper-1") is False


def test_is_usable_model_mode_unknown_kept():
    assert is_usable_model_mode("unknown-model-xyz") is True


def test_discover_workspace_root_finds_git_ancestor(tmp_path):
    repo = tmp_path / "repo"
    nested = repo / "src" / "kiss"
    nested.mkdir(parents=True)
    (repo / ".git").mkdir()

    assert discover_workspace_root(nested) == repo.resolve()


def test_discover_workspace_root_falls_back_to_start(tmp_path):
    nested = tmp_path / "a" / "b"
    nested.mkdir(parents=True)

    assert discover_workspace_root(nested) == nested.resolve()


# ── Settings properties ───────────────────────────────────────────────────────


def test_settings_provider_alias():
    s = Settings(model="anthropic:claude-sonnet-4-6")
    assert s.provider_alias == "anthropic"


def test_settings_model_id():
    s = Settings(model="openai:gpt-4o")
    assert s.model_id == "gpt-4o"


def test_settings_invalid_model_format_raises():
    s = Settings(model="no-colon")
    with pytest.raises(ValueError, match="Invalid model format"):
        _ = s.provider_alias


def test_settings_effective_provider_type_uses_alias():
    s = Settings(model="openai:gpt-4o")
    assert s.effective_provider_type == "openai"


def test_settings_web_search_defaults():
    s = Settings(model="anthropic:claude-sonnet-4-6")
    assert s.web_search == WebSearchConfig()


def test_settings_empty_model_allowed():
    s = Settings()
    assert s.model == ""


# ── settings_load ─────────────────────────────────────────────────────────────


def test_settings_load_valid(tmp_path, monkeypatch):
    import asyncio

    monkeypatch.chdir(tmp_path)
    kiss_dir = tmp_path / ".kiss"
    kiss_dir.mkdir()
    (kiss_dir / "settings.json").write_text(
        json.dumps({"model": "anthropic:claude-sonnet-4-6"})
    )
    s = asyncio.run(settings_load())
    assert s.model == "anthropic:claude-sonnet-4-6"


def test_settings_load_missing_file_returns_defaults(tmp_path, monkeypatch):
    import asyncio

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(
        "kiss.core.settings._GLOBAL_JSON", tmp_path / "nonexistent.json"
    )
    monkeypatch.setattr(
        "kiss.core.settings._GLOBAL_JSONC", tmp_path / "nonexistent.jsonc"
    )
    monkeypatch.setattr("kiss.core.settings._LOCAL_JSON", tmp_path / "local.json")
    monkeypatch.setattr("kiss.core.settings._LOCAL_JSONC", tmp_path / "local.jsonc")
    s = asyncio.run(settings_load())
    assert s == Settings()


def test_settings_load_invalid_json_raises(tmp_path, monkeypatch):
    import asyncio

    monkeypatch.chdir(tmp_path)
    kiss_dir = tmp_path / ".kiss"
    kiss_dir.mkdir()
    (kiss_dir / "settings.json").write_text("not-json{{{")
    with pytest.raises(SettingsError, match="not valid JSON"):
        asyncio.run(settings_load())


def test_settings_load_empty_model_allowed(tmp_path, monkeypatch):
    import asyncio

    monkeypatch.chdir(tmp_path)
    kiss_dir = tmp_path / ".kiss"
    kiss_dir.mkdir()
    (kiss_dir / "settings.json").write_text(json.dumps({}))
    s = asyncio.run(settings_load())
    assert s.model == ""


def test_settings_load_model_without_colon_raises(tmp_path, monkeypatch):
    import asyncio

    monkeypatch.chdir(tmp_path)
    kiss_dir = tmp_path / ".kiss"
    kiss_dir.mkdir()
    (kiss_dir / "settings.json").write_text(json.dumps({"model": "nocolon"}))
    with pytest.raises(SettingsError, match="provider:model-id"):
        asyncio.run(settings_load())


# ── JSONC support ─────────────────────────────────────────────────────────────


def test_strip_jsonc_comments_line_comment():
    from kiss.core.settings import _strip_jsonc_comments

    result = _strip_jsonc_comments('{"a": 1} // comment')
    assert json.loads(result) == {"a": 1}


def test_strip_jsonc_comments_block_comment():
    from kiss.core.settings import _strip_jsonc_comments

    result = _strip_jsonc_comments('{"a": /* block */ 1}')
    assert json.loads(result) == {"a": 1}


def test_strip_jsonc_comments_preserves_url_in_string():
    from kiss.core.settings import _strip_jsonc_comments

    raw = '{"url": "https://example.com/path"}'
    assert json.loads(_strip_jsonc_comments(raw)) == {"url": "https://example.com/path"}


def test_strip_jsonc_comments_multiline_block():
    from kiss.core.settings import _strip_jsonc_comments

    raw = '{"a": /* multi\nline */ 1}'
    assert json.loads(_strip_jsonc_comments(raw)) == {"a": 1}


def test_settings_load_jsonc_file(tmp_path, monkeypatch):
    """settings.jsonc with comments loads successfully."""
    import asyncio

    monkeypatch.chdir(tmp_path)
    kiss_dir = tmp_path / ".kiss"
    kiss_dir.mkdir()
    jsonc = '{\n  // Active model\n  "model": "anthropic:claude-sonnet-4-6"\n}'
    (kiss_dir / "settings.jsonc").write_text(jsonc)
    s = asyncio.run(settings_load())
    assert s.model == "anthropic:claude-sonnet-4-6"


def test_settings_jsonc_preferred_over_json(tmp_path, monkeypatch):
    """Local .jsonc takes priority over local .json."""
    import asyncio

    monkeypatch.chdir(tmp_path)
    kiss_dir = tmp_path / ".kiss"
    kiss_dir.mkdir()
    (kiss_dir / "settings.json").write_text(json.dumps({"model": "openai:gpt-4o"}))
    (kiss_dir / "settings.jsonc").write_text('{"model": "anthropic:claude-sonnet-4-6"}')
    s = asyncio.run(settings_load())
    assert s.model == "anthropic:claude-sonnet-4-6"
