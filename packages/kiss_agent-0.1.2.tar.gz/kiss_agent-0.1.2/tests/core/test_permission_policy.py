"""Tests for permission policy schema and evaluation."""

from __future__ import annotations

import json

import pytest

from kiss.core.permission_policy import (
    PermissionPolicy,
    PermissionPolicyError,
    PermissionRule,
    RolePermissionPolicy,
    ToolPermissionPolicy,
    evaluate_tool_policy,
    permission_policy_load,
    role_allows_tool,
)


def test_permission_policy_load_prefers_local(tmp_path, monkeypatch) -> None:
    workspace = tmp_path / "repo"
    workspace.mkdir()
    kiss_dir = workspace / ".kiss"
    kiss_dir.mkdir()
    (kiss_dir / "permissions.json").write_text(
        json.dumps(
            {
                "tools": {
                    "web_search": {
                        "default": "allow",
                    }
                }
            }
        )
    )
    monkeypatch.setattr(
        "kiss.core.permission_policy._GLOBAL_POLICY", tmp_path / "global.json"
    )

    import asyncio

    policy = asyncio.run(permission_policy_load(workspace))

    assert policy.tools["web_search"].default == "allow"


def test_permission_policy_load_uses_global_fallback(tmp_path, monkeypatch) -> None:
    global_path = tmp_path / "global.json"
    global_path.write_text(
        json.dumps(
            {
                "roles": {
                    "reviewer": {
                        "denyTools": ["write_file"],
                    }
                }
            }
        )
    )
    monkeypatch.setattr("kiss.core.permission_policy._GLOBAL_POLICY", global_path)

    import asyncio

    policy = asyncio.run(permission_policy_load(tmp_path / "repo"))

    assert policy.roles["reviewer"].deny_tools == ["write_file"]


def test_permission_policy_load_invalid_json_raises(tmp_path, monkeypatch) -> None:
    workspace = tmp_path / "repo"
    workspace.mkdir()
    kiss_dir = workspace / ".kiss"
    kiss_dir.mkdir()
    (kiss_dir / "permissions.json").write_text("{bad json")

    import asyncio

    with pytest.raises(PermissionPolicyError, match="not valid JSON"):
        asyncio.run(permission_policy_load(workspace))


def test_evaluate_tool_policy_uses_deny_over_allow() -> None:
    policy = PermissionPolicy(
        tools={
            "run_bash": ToolPermissionPolicy(
                default="ask",
                rules=[
                    PermissionRule(pattern="uv *", action="allow"),
                    PermissionRule(pattern="uv sync", action="deny"),
                ],
            )
        }
    )

    assert evaluate_tool_policy(policy, "run_bash", ("uv sync", "uv")) == "deny"
    assert evaluate_tool_policy(policy, "run_bash", ("uv run", "uv")) == "allow"


def test_evaluate_tool_policy_ask_beats_default_deny() -> None:
    policy = PermissionPolicy(
        tools={
            "run_bash": ToolPermissionPolicy(
                default="deny",
                rules=[PermissionRule(pattern="rm *", action="ask")],
            )
        }
    )

    assert evaluate_tool_policy(policy, "run_bash", ("rm -rf /tmp/x",)) == "ask"


def test_evaluate_tool_policy_ask_does_not_beat_explicit_deny() -> None:
    policy = PermissionPolicy(
        tools={
            "run_bash": ToolPermissionPolicy(
                rules=[
                    PermissionRule(pattern="rm *", action="ask"),
                    PermissionRule(pattern="rm -rf *", action="deny"),
                ],
            )
        }
    )

    assert evaluate_tool_policy(policy, "run_bash", ("rm -rf /tmp/x",)) == "deny"


def test_role_allows_tool_enforces_allow_and_deny_lists() -> None:
    policy = PermissionPolicy(
        roles={
            "researcher": RolePermissionPolicy(
                allow_tools=["read_file", "web_*"],
                deny_tools=["web_search"],
            )
        }
    )

    assert role_allows_tool(policy, "researcher", "read_file") is True
    assert role_allows_tool(policy, "researcher", "web_search") is False
    assert role_allows_tool(policy, "researcher", "write_file") is False
