"""Tests for kiss.core.pricing."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

import kiss.core.pricing as pricing_module
from kiss.core.pricing import estimate_cost, load_prices


@pytest.fixture(autouse=True)
def _reset_cache():
    pricing_module._cache = None
    yield
    pricing_module._cache = None


def test_load_prices_bundled_file_loads():
    prices = load_prices()
    assert isinstance(prices, dict)
    assert "claude-sonnet-4-6" in prices
    assert "claude-opus-4-7" in prices


def test_load_prices_returns_expected_keys():
    prices = load_prices()
    entry = prices["claude-sonnet-4-6"]
    assert "input_per_million" in entry
    assert "output_per_million" in entry
    assert "cache_read_per_million" in entry
    assert "cache_write_per_million" in entry


def test_load_prices_user_override_merges(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    user_prices = {
        "claude-custom-model": {"input_per_million": 1.0, "output_per_million": 2.0}
    }
    override_file = tmp_path / "prices.json"
    override_file.write_text(json.dumps(user_prices), encoding="utf-8")
    monkeypatch.setattr(pricing_module, "_USER_PRICES_PATH", override_file)

    prices = load_prices()
    assert "claude-custom-model" in prices
    assert "claude-sonnet-4-6" in prices


def test_load_prices_user_override_wins(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    user_prices = {
        "claude-sonnet-4-6": {"input_per_million": 99.0, "output_per_million": 99.0}
    }
    override_file = tmp_path / "prices.json"
    override_file.write_text(json.dumps(user_prices), encoding="utf-8")
    monkeypatch.setattr(pricing_module, "_USER_PRICES_PATH", override_file)

    prices = load_prices()
    assert prices["claude-sonnet-4-6"]["input_per_million"] == 99.0


def test_load_prices_missing_user_override_no_error(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
):
    monkeypatch.setattr(
        pricing_module, "_USER_PRICES_PATH", tmp_path / "nonexistent.json"
    )
    prices = load_prices()
    assert "claude-sonnet-4-6" in prices


def test_estimate_cost_known_model():
    cost = estimate_cost(
        "claude-sonnet-4-6", input_tokens=1_000_000, output_tokens=1_000_000
    )
    assert isinstance(cost, float)
    assert cost == pytest.approx(3.0 + 15.0)


def test_estimate_cost_cache_tokens():
    cost = estimate_cost(
        "claude-sonnet-4-6",
        input_tokens=0,
        output_tokens=0,
        cache_read_tokens=1_000_000,
        cache_write_tokens=1_000_000,
    )
    assert cost == pytest.approx(0.3 + 3.75)


def test_estimate_cost_unknown_model_returns_none():
    result = estimate_cost("unknown-model-xyz", input_tokens=100, output_tokens=100)
    assert result is None
