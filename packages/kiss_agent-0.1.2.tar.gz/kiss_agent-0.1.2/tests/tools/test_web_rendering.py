from __future__ import annotations

from kiss.agent.tools.result_types import (
    FetchUrlResult,
    WebSearchMatch,
    WebSearchResult,
)
from kiss.agent.tools.truncation import (
    render_fetch_url_result,
    render_web_search_result,
)


def test_render_fetch_url_result_formats_metadata_and_content() -> None:
    result = FetchUrlResult(
        url="https://example.com",
        final_url="https://example.com/final",
        method="GET",
        status_code=200,
        content_type="text/html",
        charset="utf-8",
        is_text=True,
        is_html=True,
        is_binary=False,
        redirect_count=1,
        title="Example Domain",
        extracted=True,
        truncated=False,
        content="Hello world",
    )

    rendered = render_fetch_url_result(result)

    assert "url: https://example.com" in rendered
    assert "final_url: https://example.com/final" in rendered
    assert "status_code: 200" in rendered
    assert "title: Example Domain" in rendered
    assert "extracted: True" in rendered
    assert "content:" in rendered
    assert "Hello world" in rendered


def test_render_web_search_result_formats_results() -> None:
    result = WebSearchResult(
        query="example query",
        provider="duckduckgo",
        max_results=5,
        result_count=1,
        cached=True,
        results=[
            WebSearchMatch(
                title="Example Result",
                url="https://example.com",
                snippet="Useful snippet",
            )
        ],
    )

    rendered = render_web_search_result(result)

    assert "query: example query" in rendered
    assert "provider: duckduckgo" in rendered
    assert "cached: True" in rendered
    assert "- Example Result" in rendered
    assert "snippet: Useful snippet" in rendered
