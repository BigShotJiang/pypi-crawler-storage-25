from __future__ import annotations

import os
import time
from pathlib import Path

import pytest

from kiss.agent.tools.code import glob
from kiss.agent.tools.result_types import GlobResult


@pytest.mark.asyncio
async def test_glob_matches_relative_pattern(tmp_path: Path) -> None:
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "a.py").write_text("a", encoding="utf-8")
    (tmp_path / "src" / "b.py").write_text("b", encoding="utf-8")

    result = await glob("src/*.py", workspace_root=tmp_path, sort_by="path")

    assert isinstance(result, GlobResult)
    assert [match.path for match in result.matches] == ["src/a.py", "src/b.py"]


@pytest.mark.asyncio
async def test_glob_excludes_hidden_by_default(tmp_path: Path) -> None:
    (tmp_path / ".hidden.py").write_text("x", encoding="utf-8")
    (tmp_path / "visible.py").write_text("y", encoding="utf-8")

    result = await glob("*.py", workspace_root=tmp_path)

    assert [match.path for match in result.matches] == ["visible.py"]


@pytest.mark.asyncio
async def test_glob_can_include_hidden(tmp_path: Path) -> None:
    (tmp_path / ".hidden.py").write_text("x", encoding="utf-8")

    result = await glob("*.py", workspace_root=tmp_path, include_hidden=True)

    assert [match.path for match in result.matches] == [".hidden.py"]


@pytest.mark.asyncio
async def test_glob_sorts_by_mtime_desc(tmp_path: Path) -> None:
    old = tmp_path / "old.py"
    new = tmp_path / "new.py"
    old.write_text("old", encoding="utf-8")
    time.sleep(0.01)
    new.write_text("new", encoding="utf-8")
    os.utime(old, (old.stat().st_atime, old.stat().st_mtime - 10))

    result = await glob("*.py", workspace_root=tmp_path, sort_by="mtime")

    assert [match.path for match in result.matches] == ["new.py", "old.py"]


@pytest.mark.asyncio
async def test_glob_truncates_to_max_results(tmp_path: Path) -> None:
    for index in range(3):
        (tmp_path / f"f{index}.py").write_text("x", encoding="utf-8")

    result = await glob("*.py", workspace_root=tmp_path, max_results=2, sort_by="path")

    assert result.truncated is True
    assert len(result.matches) == 2


@pytest.mark.asyncio
async def test_glob_invalid_max_results(tmp_path: Path) -> None:
    result = await glob("*.py", workspace_root=tmp_path, max_results=0)

    assert result.meta.ok is False
    assert result.meta.error_code == "invalid_input"
