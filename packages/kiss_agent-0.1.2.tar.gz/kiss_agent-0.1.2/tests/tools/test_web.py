from __future__ import annotations

import httpx
import pytest

from kiss.agent.tools.result_types import FetchUrlResult
from kiss.agent.tools.result_types import WebSearchResult
from kiss.agent.tools.web import (
    _SEARCH_CACHE,
    _SEARCH_CLIENT,
    _create_fetch_result,
    _extract_visible_text,
    _get_search_client,
    _parse_duckduckgo_results,
    close_search_client,
    fetch_url,
    web_search,
)
from kiss.core.settings import WebSearchConfig


@pytest.mark.asyncio
async def test_fetch_url_blocks_localhost() -> None:
    result = await fetch_url("http://localhost/test")

    assert isinstance(result, FetchUrlResult)
    assert result.meta.ok is False
    assert result.meta.error_message is not None
    assert "Localhost" in result.meta.error_message


def test_extract_visible_text_removes_script_and_style() -> None:
    html = (
        "<html><head><style>x</style><script>y</script></head>"
        "<body><h1>Hi</h1><p>There</p></body></html>"
    )

    text = _extract_visible_text(html)

    assert "Hi" in text
    assert "There" in text
    assert "x" not in text
    assert "y" not in text


def test_create_fetch_result_binary_is_metadata_only() -> None:
    request = httpx.Request("GET", "https://example.com/file.bin")
    response = httpx.Response(
        200,
        headers={"content-type": "application/octet-stream"},
        content=b"\x00\x01\x02",
        request=request,
    )

    result = _create_fetch_result(
        "https://example.com/file.bin", "GET", "auto", response
    )

    assert result.is_binary is True
    assert result.content is None


def test_create_fetch_result_html_auto_extracts_text() -> None:
    request = httpx.Request("GET", "https://example.com/")
    response = httpx.Response(
        200,
        headers={"content-type": "text/html; charset=utf-8"},
        content=b"<html><body><h1>Hello</h1><p>World</p></body></html>",
        request=request,
    )

    result = _create_fetch_result("https://example.com/", "GET", "auto", response)

    assert result.is_html is True
    assert result.extracted is True
    assert result.title == "Hello"
    assert result.content is not None
    assert "Hello" in result.content
    assert "World" in result.content


def test_parse_duckduckgo_results_returns_structured_matches() -> None:
    html = """
    <div class="result">
      <a class="result__a" href="https://example.com/a">Result A</a>
      <a class="result__snippet">Snippet A</a>
    </div>
    <div class="result">
      <a class="result__a" href="https://example.com/b">Result B</a>
      <div class="result__snippet">Snippet B</div>
    </div>
    """

    matches = _parse_duckduckgo_results(html, 5)

    assert len(matches) == 2
    assert matches[0].title == "Result A"
    assert matches[0].url == "https://example.com/a"
    assert matches[0].snippet == "Snippet A"


@pytest.mark.asyncio
async def test_web_search_returns_structured_results(monkeypatch) -> None:
    _SEARCH_CACHE.clear()

    html = """
    <div class="result">
      <a class="result__a" href="https://example.com/a">Result A</a>
      <div class="result__snippet">Snippet A</div>
    </div>
    """

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url == httpx.URL("https://html.duckduckgo.com/html/")
        return httpx.Response(200, text=html, request=request)

    transport = httpx.MockTransport(handler)
    monkeypatch.setattr(
        "kiss.agent.tools.web._SEARCH_CLIENT",
        httpx.AsyncClient(transport=transport),
    )

    result = await web_search(
        "test query",
        max_results=3,
        config=WebSearchConfig(provider="duckduckgo", cache_ttl_s=300.0),
    )

    assert isinstance(result, WebSearchResult)
    assert result.meta.ok is True
    assert result.provider == "duckduckgo"
    assert result.result_count == 1
    assert result.results[0].url == "https://example.com/a"


@pytest.mark.asyncio
async def test_web_search_uses_cache_for_repeated_query(monkeypatch) -> None:
    _SEARCH_CACHE.clear()
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(
            200,
            text="""
            <div class="result">
              <a class="result__a" href="https://example.com/a">Result A</a>
            </div>
            """,
            request=request,
        )

    transport = httpx.MockTransport(handler)
    monkeypatch.setattr(
        "kiss.agent.tools.web._SEARCH_CLIENT",
        httpx.AsyncClient(transport=transport),
    )

    config = WebSearchConfig(provider="duckduckgo", cache_ttl_s=300.0)
    first = await web_search("cache me", config=config)
    second = await web_search("cache me", config=config)

    assert first.cached is False
    assert second.cached is True
    assert calls == 1


@pytest.mark.asyncio
async def test_web_search_rejects_unsupported_provider() -> None:
    result = await web_search(
        "test query",
        config=WebSearchConfig(provider="unsupported"),
    )

    assert result.meta.ok is False
    assert result.meta.error_code == "invalid_configuration"


@pytest.mark.asyncio
async def test_fetch_url_blocks_redirect_to_localhost(monkeypatch) -> None:
    """A malicious server must not bypass validation by redirecting to localhost."""
    transport = httpx.MockTransport(
        lambda request: httpx.Response(
            302,
            headers={"location": "http://localhost:22/"},
            request=request,
        )
    )
    real_async_client = httpx.AsyncClient

    class DummyClient:
        def __init__(self, **_: object) -> None:
            self._client = real_async_client(transport=transport)

        async def __aenter__(self) -> httpx.AsyncClient:
            return self._client

        async def __aexit__(self, *args: object) -> None:
            await self._client.aclose()

    monkeypatch.setattr("kiss.agent.tools.web.httpx.AsyncClient", DummyClient)

    result = await fetch_url("http://example.com/")

    assert result.meta.ok is False
    assert result.meta.error_code == "network_blocked"
    assert result.meta.error_message is not None
    assert "Redirect blocked" in result.meta.error_message


@pytest.mark.asyncio
async def test_fetch_url_blocks_redirect_to_private_ip(monkeypatch) -> None:
    """A malicious server must not bypass validation by redirecting to a private IP."""
    transport = httpx.MockTransport(
        lambda request: httpx.Response(
            302,
            headers={"location": "http://192.168.1.1/"},
            request=request,
        )
    )
    real_async_client = httpx.AsyncClient

    class DummyClient:
        def __init__(self, **_: object) -> None:
            self._client = real_async_client(transport=transport)

        async def __aenter__(self) -> httpx.AsyncClient:
            return self._client

        async def __aexit__(self, *args: object) -> None:
            await self._client.aclose()

    monkeypatch.setattr("kiss.agent.tools.web.httpx.AsyncClient", DummyClient)

    result = await fetch_url("http://example.com/")

    assert result.meta.ok is False
    assert result.meta.error_code == "network_blocked"
    assert result.meta.error_message is not None
    assert "Redirect blocked" in result.meta.error_message


@pytest.mark.asyncio
async def test_fetch_url_allows_safe_redirect(monkeypatch) -> None:
    """Safe cross-domain redirects should still work."""

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.host == "example.com":
            return httpx.Response(
                302,
                headers={"location": "https://example.org/page"},
                request=request,
            )
        return httpx.Response(
            200,
            headers={"content-type": "text/plain"},
            content=b"ok",
            request=request,
        )

    transport = httpx.MockTransport(handler)
    real_async_client = httpx.AsyncClient

    class DummyClient:
        def __init__(self, **_: object) -> None:
            self._client = real_async_client(transport=transport)

        async def __aenter__(self) -> httpx.AsyncClient:
            return self._client

        async def __aexit__(self, *args: object) -> None:
            await self._client.aclose()

    monkeypatch.setattr("kiss.agent.tools.web.httpx.AsyncClient", DummyClient)

    result = await fetch_url("http://example.com/")

    assert result.meta.ok is True
    assert result.status_code == 200
    assert result.redirect_count == 1


@pytest.mark.asyncio
async def test_fetch_url_enforces_max_redirects(monkeypatch) -> None:
    """Too many redirects must be rejected."""
    transport = httpx.MockTransport(
        lambda request: httpx.Response(
            302,
            headers={"location": "http://example.com/loop"},
            request=request,
        )
    )
    real_async_client = httpx.AsyncClient

    class DummyClient:
        def __init__(self, **_: object) -> None:
            self._client = real_async_client(transport=transport)

        async def __aenter__(self) -> httpx.AsyncClient:
            return self._client

        async def __aexit__(self, *args: object) -> None:
            await self._client.aclose()

    monkeypatch.setattr("kiss.agent.tools.web.httpx.AsyncClient", DummyClient)

    result = await fetch_url("http://example.com/")

    assert result.meta.ok is False
    assert result.meta.error_code == "execution_failed"
    assert result.meta.error_message is not None
    assert "Too many redirects" in result.meta.error_message


def test_get_search_client_returns_same_instance() -> None:
    """The shared search client must be reused across calls."""
    client_a = _get_search_client()
    client_b = _get_search_client()
    assert client_a is client_b


@pytest.mark.asyncio
async def test_close_search_client_clears_instance() -> None:
    """Closing the search client must reset the global instance."""
    import kiss.agent.tools.web as web_mod

    web_mod._SEARCH_CLIENT = httpx.AsyncClient()
    await close_search_client()
    assert _SEARCH_CLIENT is None
