from __future__ import annotations

import json
from pathlib import Path
import subprocess

import pytest

from kiss.agent.tools.analysis import (
    analyze_code,
    check_style,
    document_symbols,
    find_definition,
    find_references,
    workspace_symbols,
)


@pytest.mark.asyncio
async def test_analyze_code_python_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "sample.py"
    path.write_text(
        "import os\n\nclass Greeter:\n    pass\n\ndef hello(name: str) -> str:\n    return name\n",
        encoding="utf-8",
    )

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "python"
    assert result.freshness_strategy == "on_demand_workspace_scan"
    assert result.metrics["class_count"] == 1
    assert result.metrics["function_count"] == 1


@pytest.mark.asyncio
async def test_analyze_code_json_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "sample.json"
    path.write_text('{"app": {"name": "kiss", "ports": [1, 2]}}', encoding="utf-8")

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "json"
    assert result.metrics["key_count"] == 3
    assert result.metrics["array_count"] == 1


@pytest.mark.asyncio
async def test_document_symbols_python_collects_symbols(tmp_path: Path) -> None:
    path = tmp_path / "sample.py"
    path.write_text(
        "VALUE = 1\n\nclass Greeter:\n    pass\n\ndef hello():\n    return VALUE\n",
        encoding="utf-8",
    )

    result = await document_symbols(str(path))

    names = {symbol.name for symbol in result.symbols}
    assert result.meta.ok is True
    assert names == {"VALUE", "Greeter", "hello"}


@pytest.mark.asyncio
async def test_document_symbols_json_collects_properties(tmp_path: Path) -> None:
    path = tmp_path / "sample.json"
    path.write_text('{"app": {"name": "kiss"}, "enabled": true}', encoding="utf-8")

    result = await document_symbols(str(path))

    names = {symbol.name for symbol in result.symbols}
    assert result.language == "json"
    assert {"app", "name", "enabled"} <= names


@pytest.mark.asyncio
async def test_workspace_symbols_filters_query(tmp_path: Path) -> None:
    (tmp_path / "alpha.py").write_text(
        "def greet_user():\n    return 1\n", encoding="utf-8"
    )
    (tmp_path / "config.json").write_text(
        '{"greeting_mode": "friendly"}', encoding="utf-8"
    )

    result = await workspace_symbols("greet", workspace_root=tmp_path)

    names = {symbol.name for symbol in result.symbols}
    assert result.meta.ok is True
    assert {"greet_user", "greeting_mode"} <= names


@pytest.mark.asyncio
async def test_find_definition_returns_python_symbol(tmp_path: Path) -> None:
    path = tmp_path / "sample.py"
    path.write_text("def greet():\n    return 1\n", encoding="utf-8")

    result = await find_definition("greet", workspace_root=tmp_path)

    assert result.meta.ok is True
    assert result.symbol is not None
    assert result.symbol.name == "greet"
    assert result.symbol.location.path == str(path)


@pytest.mark.asyncio
async def test_find_references_returns_workspace_locations(tmp_path: Path) -> None:
    (tmp_path / "one.py").write_text(
        "def greet():\n    return 1\n\nvalue = greet()\n",
        encoding="utf-8",
    )
    (tmp_path / "two.py").write_text(
        "from one import greet\nprint(greet())\n", encoding="utf-8"
    )

    result = await find_references("greet", workspace_root=tmp_path)

    assert result.meta.ok is True
    assert result.reference_count >= 3
    assert len(result.references) >= 3


@pytest.mark.asyncio
async def test_check_style_json_reports_parse_error(tmp_path: Path) -> None:
    path = tmp_path / "bad.json"
    path.write_text('{"broken": }', encoding="utf-8")

    result = await check_style(str(path))

    assert result.passed is False
    assert result.violations
    assert result.violations[0].code == "json_parse_error"


@pytest.mark.asyncio
async def test_check_style_python_uses_ruff(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    path = tmp_path / "sample.py"
    path.write_text("import os\n", encoding="utf-8")

    def fake_run(*args, **kwargs) -> subprocess.CompletedProcess[str]:
        payload = json.dumps(
            [
                {
                    "code": "F401",
                    "message": "`os` imported but unused",
                    "filename": str(path),
                    "location": {"row": 1, "column": 8},
                    "end_location": {"row": 1, "column": 10},
                }
            ]
        )
        return subprocess.CompletedProcess(args[0], 1, stdout=payload, stderr="")

    monkeypatch.setattr(
        "kiss.agent.tools.analysis.shutil.which", lambda name: "/usr/bin/ruff"
    )
    monkeypatch.setattr("subprocess.run", fake_run)

    result = await check_style(str(path))

    assert result.language == "python"
    assert result.passed is False
    assert result.violations[0].code == "F401"


@pytest.mark.asyncio
async def test_analyze_code_toml_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "sample.toml"
    path.write_text('[settings]\nname = "kiss"\nport = 8080\n', encoding="utf-8")

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "toml"
    assert isinstance(result.metrics, dict)
    assert "top_level_keys" in result.metrics
    assert result.metrics["top_level_keys"] == 1


@pytest.mark.asyncio
async def test_analyze_code_markdown_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "sample.md"
    path.write_text("# Title\n\n## Section\n\nSome text here.\n", encoding="utf-8")

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "markdown"
    assert isinstance(result.metrics, dict)
    assert "h1_count" in result.metrics
    assert result.metrics["h1_count"] == 1
    assert result.metrics["h2_count"] == 1


@pytest.mark.asyncio
async def test_analyze_code_yaml_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "sample.yaml"
    path.write_text("app:\n  name: kiss\n  port: 8080\n", encoding="utf-8")

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "yaml"
    assert isinstance(result.metrics, dict)
    assert "document_count" in result.metrics


@pytest.mark.asyncio
async def test_analyze_code_sql_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "sample.sql"
    path.write_text(
        "SELECT * FROM users;\nINSERT INTO logs VALUES (1);\n", encoding="utf-8"
    )

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "sql"
    assert isinstance(result.metrics, dict)


@pytest.mark.asyncio
async def test_analyze_code_csv_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "sample.csv"
    path.write_text("name,age,city\nAlice,30,Paris\nBob,25,Lyon\n", encoding="utf-8")

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "csv"
    assert isinstance(result.metrics, dict)
    assert "row_count" in result.metrics
    assert result.metrics["row_count"] == 3
    assert result.metrics["column_count"] == 3


@pytest.mark.asyncio
async def test_analyze_code_tsv_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "sample.tsv"
    path.write_text(
        "name\tage\tcity\nAlice\t30\tParis\nBob\t25\tLyon\n", encoding="utf-8"
    )

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "tsv"
    assert isinstance(result.metrics, dict)
    assert "row_count" in result.metrics
    assert result.metrics["row_count"] == 3
    assert result.metrics["column_count"] == 3


@pytest.mark.asyncio
async def test_analyze_code_bash_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "sample.sh"
    path.write_text('#!/bin/bash\n\necho "hello"\nls -la\n', encoding="utf-8")

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "bash"
    assert isinstance(result.metrics, dict)


@pytest.mark.asyncio
async def test_analyze_code_powershell_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "sample.ps1"
    path.write_text('Write-Host "Hello"\nGet-ChildItem\n', encoding="utf-8")

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "powershell"
    assert isinstance(result.metrics, dict)


@pytest.mark.asyncio
async def test_analyze_code_dockerfile_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "Dockerfile"
    path.write_text(
        'FROM python:3.11-slim\nRUN pip install kiss\nCMD ["kiss"]\n', encoding="utf-8"
    )

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "dockerfile"
    assert isinstance(result.metrics, dict)


@pytest.mark.asyncio
async def test_analyze_code_hcl_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "main.tf"
    path.write_text(
        'resource "aws_s3_bucket" "main" {\n  bucket = "my-bucket"\n}\n',
        encoding="utf-8",
    )

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "hcl"
    assert isinstance(result.metrics, dict)


@pytest.mark.asyncio
async def test_analyze_code_regex_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "sample.re"
    path.write_text("^[a-z]+[0-9]*$\n", encoding="utf-8")

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "regex"
    assert isinstance(result.metrics, dict)


@pytest.mark.asyncio
async def test_analyze_code_jq_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "sample.jq"
    path.write_text(".[] | .name\n", encoding="utf-8")

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "jq"
    assert isinstance(result.metrics, dict)


@pytest.mark.asyncio
async def test_analyze_code_javascript_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "sample.js"
    path.write_text(
        "function hello() { return 1; }\nconst add = (a, b) => a + b;\n",
        encoding="utf-8",
    )

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "javascript"
    assert isinstance(result.metrics, dict)


@pytest.mark.asyncio
async def test_analyze_code_typescript_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "sample.ts"
    path.write_text(
        "interface Foo { bar: string; }\nfunction hello(): void {}\n", encoding="utf-8"
    )

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "typescript"
    assert isinstance(result.metrics, dict)


@pytest.mark.asyncio
async def test_analyze_code_go_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "sample.go"
    path.write_text(
        'package main\n\nimport "fmt"\n\nfunc main() {\n\tfmt.Println("hi")\n}\n',
        encoding="utf-8",
    )

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "go"
    assert isinstance(result.metrics, dict)


@pytest.mark.asyncio
async def test_analyze_code_rust_reports_metrics(tmp_path: Path) -> None:
    path = tmp_path / "sample.rs"
    path.write_text(
        "fn main() {}\nstruct Foo {}\nenum Bar { A, B }\n", encoding="utf-8"
    )

    result = await analyze_code(str(path))

    assert result.meta.ok is True
    assert result.language == "rust"
    assert isinstance(result.metrics, dict)
