"""Unit tests for todo tracking and team coordination tools."""

from __future__ import annotations

from typing import Any

import pytest
from mirascope import llm

from kiss.agent.tools.todos import (
    add_todo,
    block_todo,
    claim_todo,
    complete_todo,
    done_todo,
    list_todos,
    post_team_message,
    read_team_messages,
    unblock_todo,
)
from kiss.core.deps import AgentDeps
from kiss.core.events import Event, EventKind


class _DepsForTest:
    """Test wrapper for AgentDeps that captures events."""

    def __init__(self, agent_label: str = "kiss-agent"):
        self.captured_events: list[Event] = []

        async def on_event(event: Event) -> None:
            self.captured_events.append(event)

        self.deps = AgentDeps(on_event=on_event, agent_label=agent_label)

    def __getattr__(self, name: str) -> Any:
        return getattr(self.deps, name)


@pytest.fixture
def deps_with_event_capture():
    return _DepsForTest()


# ── add_todo ──────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_add_todo_appends_and_emits(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    result = await add_todo(ctx, "write unit tests")

    assert "Added: write unit tests" in result
    assert len(deps_with_event_capture.deps.todos) == 1
    assert deps_with_event_capture.deps.todos[0].text == "write unit tests"
    assert deps_with_event_capture.deps.todos[0].done is False
    assert deps_with_event_capture.deps.todos[0].status == "pending"
    assert deps_with_event_capture.deps.todos[0].id == "t-0001"
    assert len(deps_with_event_capture.captured_events) == 1
    assert deps_with_event_capture.captured_events[0].kind == EventKind.TODO_UPDATE


@pytest.mark.asyncio
async def test_add_todo_increments_ids(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task 1")
    await add_todo(ctx, "task 2")
    await add_todo(ctx, "task 3")

    ids = [t.id for t in deps_with_event_capture.deps.todos]
    assert ids == ["t-0001", "t-0002", "t-0003"]
    assert len(deps_with_event_capture.captured_events) == 3


@pytest.mark.asyncio
async def test_add_todo_multiple_items(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task 1")
    await add_todo(ctx, "task 2")
    await add_todo(ctx, "task 3")

    assert len(deps_with_event_capture.deps.todos) == 3


# ── done_todo (legacy) ────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_done_todo_matches_and_marks_done(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "write unit tests")
    deps_with_event_capture.captured_events.clear()

    result = await done_todo(ctx, "unit tests")

    assert result == "Done: write unit tests"
    assert deps_with_event_capture.deps.todos[0].done is True
    assert deps_with_event_capture.deps.todos[0].status == "done"
    assert len(deps_with_event_capture.captured_events) == 1
    assert deps_with_event_capture.captured_events[0].kind == EventKind.TODO_UPDATE


@pytest.mark.asyncio
async def test_done_todo_case_insensitive(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "Write Unit Tests")
    deps_with_event_capture.captured_events.clear()

    result = await done_todo(ctx, "unit tests")

    assert result == "Done: Write Unit Tests"
    assert deps_with_event_capture.deps.todos[0].done is True


@pytest.mark.asyncio
async def test_done_todo_substring_match(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "write comprehensive unit tests")
    deps_with_event_capture.captured_events.clear()

    result = await done_todo(ctx, "unit")

    assert result == "Done: write comprehensive unit tests"
    assert deps_with_event_capture.deps.todos[0].done is True


@pytest.mark.asyncio
async def test_done_todo_ambiguous_fails_explicitly(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task 1 with tests")
    await add_todo(ctx, "task 2 with tests")
    deps_with_event_capture.captured_events.clear()

    result = await done_todo(ctx, "with tests")

    assert (
        "Ambiguous" in result
        or "ambiguous" in result.lower()
        or "No matching" in result
    )
    assert deps_with_event_capture.deps.todos[0].done is False
    assert deps_with_event_capture.deps.todos[1].done is False


@pytest.mark.asyncio
async def test_done_todo_no_match(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task 1")
    deps_with_event_capture.captured_events.clear()

    result = await done_todo(ctx, "nonexistent")

    assert result == "No matching todo found for: nonexistent"
    assert deps_with_event_capture.deps.todos[0].done is False
    assert len(deps_with_event_capture.captured_events) == 0


@pytest.mark.asyncio
async def test_done_todo_enforces_ownership():
    """done_todo must reject completing a todo owned by another agent."""
    wrapper = _DepsForTest(agent_label="reviewer")
    ctx = llm.Context(deps=wrapper.deps)

    await add_todo(ctx, "task")
    await claim_todo(ctx, "task", "coder")

    result = await done_todo(ctx, "task")

    assert "Ownership mismatch" in result
    assert wrapper.deps.todos[0].done is False


@pytest.mark.asyncio
async def test_done_todo_allows_unowned_todo():
    """done_todo should allow completing an unowned todo."""
    wrapper = _DepsForTest(agent_label="reviewer")
    ctx = llm.Context(deps=wrapper.deps)

    await add_todo(ctx, "task")

    result = await done_todo(ctx, "task")

    assert result == "Done: task"
    assert wrapper.deps.todos[0].done is True


# ── list_todos ────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_list_todos_empty(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)
    result = await list_todos(ctx)
    assert result == "No todos."


@pytest.mark.asyncio
async def test_list_todos_single_pending(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task 1")
    result = await list_todos(ctx)

    assert "Todos (1):" in result
    assert "[pending]" in result
    assert "task 1" in result


@pytest.mark.asyncio
async def test_list_todos_mixed_status(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "write tests")
    await add_todo(ctx, "run tests")
    await done_todo(ctx, "write")

    result = await list_todos(ctx)

    assert "Todos (2):" in result
    assert "[done]" in result
    assert "write tests" in result
    assert "[pending]" in result
    assert "run tests" in result


@pytest.mark.asyncio
async def test_list_todos_all_done(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task 1")
    await add_todo(ctx, "task 2")
    await done_todo(ctx, "task 1")
    await done_todo(ctx, "task 2")

    result = await list_todos(ctx)

    assert "Todos (2):" in result
    assert "task 1" in result
    assert "task 2" in result
    assert "[pending]" not in result


@pytest.mark.asyncio
async def test_workflow_sequence(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "step 1")
    await add_todo(ctx, "step 2")
    await add_todo(ctx, "step 3")

    result = await list_todos(ctx)
    assert "Todos (3):" in result
    assert "step 1" in result
    assert "step 2" in result
    assert "step 3" in result

    deps_with_event_capture.captured_events.clear()

    await done_todo(ctx, "step 2")
    result = await list_todos(ctx)
    assert "[done]" in result
    assert "step 2" in result

    await done_todo(ctx, "step 1")
    result = await list_todos(ctx)
    assert result.count("[done]") == 2
    assert "[pending]" in result


# ── claim_todo ────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_claim_todo_by_text(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "implement feature")
    deps_with_event_capture.captured_events.clear()

    result = await claim_todo(ctx, "implement feature", "alice")

    assert "Claimed" in result
    todo = deps_with_event_capture.deps.todos[0]
    assert todo.owner == "alice"
    assert todo.status == "in_progress"
    assert todo.done is False
    assert len(deps_with_event_capture.captured_events) == 1
    assert deps_with_event_capture.captured_events[0].kind == EventKind.TODO_UPDATE


@pytest.mark.asyncio
async def test_claim_todo_by_id(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task one")
    await add_todo(ctx, "task two")

    result = await claim_todo(ctx, "t-0002", "bob")

    assert "Claimed" in result
    assert deps_with_event_capture.deps.todos[1].owner == "bob"
    assert deps_with_event_capture.deps.todos[0].owner is None


@pytest.mark.asyncio
async def test_claim_todo_persists(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "work item")
    await claim_todo(ctx, "work item", "alice")

    result = await list_todos(ctx)
    assert "(alice)" in result
    assert "[in_progress]" in result


@pytest.mark.asyncio
async def test_claim_todo_no_match(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task 1")
    result = await claim_todo(ctx, "nonexistent", "alice")

    assert "No matching todo found" in result


@pytest.mark.asyncio
async def test_claim_done_todo_resets_done_flag(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task")
    await complete_todo(ctx, "task")
    assert deps_with_event_capture.deps.todos[0].done is True

    await claim_todo(ctx, "task", "alice")

    todo = deps_with_event_capture.deps.todos[0]
    assert todo.status == "in_progress"
    assert todo.done is False


# ── complete_todo ─────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_complete_todo_with_owner_match(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task")
    await claim_todo(ctx, "task", "alice")

    result = await complete_todo(ctx, "task", "alice")

    assert "Completed" in result
    assert deps_with_event_capture.deps.todos[0].status == "done"
    assert deps_with_event_capture.deps.todos[0].done is True


@pytest.mark.asyncio
async def test_complete_todo_owner_mismatch(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task")
    await claim_todo(ctx, "task", "alice")

    result = await complete_todo(ctx, "task", "bob")

    assert "Ownership mismatch" in result
    assert deps_with_event_capture.deps.todos[0].status == "in_progress"


@pytest.mark.asyncio
async def test_complete_todo_unowned_no_owner_arg(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task")

    result = await complete_todo(ctx, "task")

    assert "Completed" in result
    assert deps_with_event_capture.deps.todos[0].status == "done"


@pytest.mark.asyncio
async def test_complete_todo_actor_label_match():
    wrapper = _DepsForTest(agent_label="worker")
    ctx = llm.Context(deps=wrapper.deps)

    await add_todo(ctx, "task")
    await claim_todo(ctx, "task", "worker")

    result = await complete_todo(ctx, "task")

    assert "Completed" in result
    assert wrapper.deps.todos[0].status == "done"


@pytest.mark.asyncio
async def test_complete_todo_actor_label_mismatch():
    wrapper = _DepsForTest(agent_label="reviewer")
    ctx = llm.Context(deps=wrapper.deps)

    await add_todo(ctx, "task")
    await claim_todo(ctx, "task", "coder")

    result = await complete_todo(ctx, "task")

    assert "Ownership mismatch" in result
    assert wrapper.deps.todos[0].status == "in_progress"


# ── block_todo / unblock_todo ─────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_block_todo(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task")
    deps_with_event_capture.captured_events.clear()

    result = await block_todo(ctx, "task", "waiting for API")

    assert "Blocked" in result
    assert "waiting for API" in result
    todo = deps_with_event_capture.deps.todos[0]
    assert todo.status == "blocked"
    assert todo.done is False
    assert todo.block_reason == "waiting for API"
    assert len(deps_with_event_capture.captured_events) == 1


@pytest.mark.asyncio
async def test_block_done_todo_resets_done_flag(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task")
    await complete_todo(ctx, "task")
    assert deps_with_event_capture.deps.todos[0].done is True

    await block_todo(ctx, "task", "needs rework")

    todo = deps_with_event_capture.deps.todos[0]
    assert todo.status == "blocked"
    assert todo.done is False


@pytest.mark.asyncio
async def test_unblock_todo_resets_to_pending(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task")
    await block_todo(ctx, "task", "waiting for API")
    deps_with_event_capture.captured_events.clear()

    result = await unblock_todo(ctx, "task")

    assert "Unblocked" in result
    todo = deps_with_event_capture.deps.todos[0]
    assert todo.status == "pending"
    assert todo.done is False
    assert todo.block_reason is None
    assert len(deps_with_event_capture.captured_events) == 1


@pytest.mark.asyncio
async def test_unblock_retains_owner_but_not_in_progress(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task")
    await claim_todo(ctx, "task", "alice")
    await block_todo(ctx, "task", "blocked reason")

    await unblock_todo(ctx, "task")

    todo = deps_with_event_capture.deps.todos[0]
    assert todo.status == "pending"
    assert todo.done is False
    assert todo.owner == "alice"


# ── team message bus ──────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_post_team_message(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    result = await post_team_message(ctx, "hello team")

    assert "posted" in result.lower()
    assert len(ctx.deps.team_messages) == 1
    msg = ctx.deps.team_messages[0]
    assert msg.text == "hello team"
    assert msg.recipient == "all"


@pytest.mark.asyncio
async def test_post_team_message_with_label():
    wrapper = _DepsForTest(agent_label="coder")
    ctx = llm.Context(deps=wrapper.deps)

    await post_team_message(ctx, "starting feature X", "orchestrator")

    msg = ctx.deps.team_messages[0]
    assert msg.sender == "coder"
    assert msg.recipient == "orchestrator"


@pytest.mark.asyncio
async def test_read_team_messages_empty(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)
    result = await read_team_messages(ctx)
    assert result == "No messages."


@pytest.mark.asyncio
async def test_read_team_messages_returns_messages():
    wrapper = _DepsForTest(agent_label="coder")
    ctx = llm.Context(deps=wrapper.deps)

    await post_team_message(ctx, "first message")
    await post_team_message(ctx, "second message")

    result = await read_team_messages(ctx)

    assert "Messages (2):" in result
    assert "first message" in result
    assert "second message" in result


@pytest.mark.asyncio
async def test_read_team_messages_limit():
    wrapper = _DepsForTest(agent_label="coder")
    ctx = llm.Context(deps=wrapper.deps)

    for i in range(5):
        await post_team_message(ctx, f"msg {i}")

    result = await read_team_messages(ctx, limit=3)

    assert "Messages (3):" in result
    assert "msg 2" in result
    assert "msg 3" in result
    assert "msg 4" in result
    assert "msg 0" not in result


@pytest.mark.asyncio
async def test_team_message_retention_cap():
    wrapper = _DepsForTest(agent_label="coder")
    ctx = llm.Context(deps=wrapper.deps)

    for i in range(105):
        await post_team_message(ctx, f"msg {i}")

    assert len(ctx.deps.team_messages) == 100
    assert ctx.deps.team_messages[0].text == "msg 5"
    assert ctx.deps.team_messages[-1].text == "msg 104"


@pytest.mark.asyncio
async def test_post_team_message_emits_info_event(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await post_team_message(ctx, "hello")

    info_events = [
        e for e in deps_with_event_capture.captured_events if e.kind == EventKind.INFO
    ]
    assert len(info_events) == 1
    assert "hello" in info_events[0].info


# ── blocked_by dependency hints ───────────────────────────────────────────────


@pytest.mark.asyncio
async def test_block_todo_with_blocked_by(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task A")
    await add_todo(ctx, "task B")

    result = await block_todo(ctx, "task B", "waiting for A", blocked_by=["t-0001"])

    assert "Blocked" in result
    assert "t-0001" in result
    todo = deps_with_event_capture.deps.todos[1]
    assert todo.status == "blocked"
    assert todo.blocked_by == ["t-0001"]
    assert todo.block_reason == "waiting for A"


@pytest.mark.asyncio
async def test_block_todo_blocked_by_multiple(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "final task")

    await block_todo(
        ctx, "final task", "needs both", blocked_by=["t-0001", "some-external"]
    )

    todo = deps_with_event_capture.deps.todos[0]
    assert todo.blocked_by == ["t-0001", "some-external"]


@pytest.mark.asyncio
async def test_block_todo_no_blocked_by(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task")
    result = await block_todo(ctx, "task", "waiting for deploy")

    todo = deps_with_event_capture.deps.todos[0]
    assert todo.blocked_by == []
    assert "[needs:" not in result


@pytest.mark.asyncio
async def test_unblock_clears_blocked_by(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task")
    await block_todo(ctx, "task", "reason", blocked_by=["t-0002"])

    await unblock_todo(ctx, "task")

    todo = deps_with_event_capture.deps.todos[0]
    assert todo.blocked_by == []
    assert todo.block_reason is None
    assert todo.status == "pending"


@pytest.mark.asyncio
async def test_block_todo_filters_non_string_hints(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task")
    await block_todo(ctx, "task", "reason", blocked_by=["t-0001", "  ", "valid-ref"])

    todo = deps_with_event_capture.deps.todos[0]
    assert "t-0001" in todo.blocked_by
    assert "valid-ref" in todo.blocked_by


@pytest.mark.asyncio
async def test_list_todos_shows_blocked_by(deps_with_event_capture):
    ctx = llm.Context(deps=deps_with_event_capture.deps)

    await add_todo(ctx, "task A")
    await add_todo(ctx, "task B")
    await block_todo(ctx, "task B", "needs A", blocked_by=["t-0001"])

    result = await list_todos(ctx)

    assert "[needs: t-0001]" in result
