"""Tests for shell_hints deterministic exit-code hints."""

from __future__ import annotations

from kiss.agent.tools.shell_hints import get_hint


def test_127_command_not_found() -> None:
    hint = get_hint(127)
    assert hint is not None
    assert "not found" in hint.lower()


def test_126_not_executable() -> None:
    hint = get_hint(126)
    assert hint is not None
    assert "execut" in hint.lower()


def test_13_permission_denied() -> None:
    hint = get_hint(13)
    assert hint is not None
    assert "permission" in hint.lower()


def test_generic_exit_code_returns_none() -> None:
    assert get_hint(1) is None
    assert get_hint(2) is None
    assert get_hint(255) is None


def test_none_exit_code_returns_none() -> None:
    assert get_hint(None) is None
