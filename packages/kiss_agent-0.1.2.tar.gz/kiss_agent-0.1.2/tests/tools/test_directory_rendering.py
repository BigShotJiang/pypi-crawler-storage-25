from __future__ import annotations

from kiss.agent.tools.result_types import (
    DirectoryEntry,
    ListDirectoryResult,
    ToolResultMeta,
)
from kiss.agent.tools.truncation import render_list_directory_result


def test_render_list_directory_result_formats_entries() -> None:
    result = ListDirectoryResult(
        root="/tmp/project",
        max_depth=2,
        truncated=False,
        entries=[
            DirectoryEntry(path="src", kind="dir", depth=1),
            DirectoryEntry(path="src/app.py", kind="file", depth=2),
        ],
    )

    rendered = render_list_directory_result(result)

    assert "root: /tmp/project" in rendered
    assert "- src/" in rendered
    assert "- src/app.py" in rendered


def test_render_list_directory_result_error() -> None:
    result = ListDirectoryResult(
        root="/tmp/missing",
        max_depth=2,
        meta=ToolResultMeta(
            ok=False,
            error_code="not_found",
            error_message="not found",
        ),
    )

    rendered = render_list_directory_result(result)

    assert rendered == "not found"
