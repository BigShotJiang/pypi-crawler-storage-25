from __future__ import annotations

from kiss.agent.tools.result_types import SearchCodeMatch, SearchCodeResult
from kiss.agent.tools.truncation import render_search_code_result


def test_render_search_code_result_distributes_across_files() -> None:
    matches = [
        SearchCodeMatch(path="a.py", line=1, text="alpha"),
        SearchCodeMatch(path="a.py", line=2, text="beta"),
        SearchCodeMatch(path="b.py", line=3, text="gamma"),
    ]
    result = SearchCodeResult(pattern="x", match_count=3, matches=matches)

    rendered = render_search_code_result(result, max_tokens=20)

    assert "a.py:1" in rendered
    assert "b.py:3" in rendered


def test_render_search_code_result_no_matches() -> None:
    result = SearchCodeResult(pattern="x", match_count=0, matches=[])

    rendered = render_search_code_result(result)

    assert "match_count: 0" in rendered
