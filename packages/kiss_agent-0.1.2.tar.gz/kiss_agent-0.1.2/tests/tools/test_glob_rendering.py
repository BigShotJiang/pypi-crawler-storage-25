from __future__ import annotations

from kiss.agent.tools.result_types import GlobMatch, GlobResult, ToolResultMeta
from kiss.agent.tools.truncation import render_glob_result


def test_render_glob_result_formats_matches() -> None:
    result = GlobResult(
        pattern="src/*.py",
        root="/tmp/project",
        matches=[
            GlobMatch(path="src/app.py", size_bytes=10, mtime=123.456),
            GlobMatch(path="src/pkg", is_dir=True, size_bytes=0, mtime=120.0),
        ],
    )

    rendered = render_glob_result(result)

    assert "pattern: src/*.py" in rendered
    assert "root: /tmp/project" in rendered
    assert "- src/app.py size=10" in rendered
    assert "- src/pkg/ size=0" in rendered


def test_render_glob_result_error_uses_meta_message() -> None:
    result = GlobResult(
        pattern="*.py",
        root="/tmp/project",
        meta=ToolResultMeta(
            ok=False,
            error_code="permission_denied",
            error_message="Permission denied",
        ),
    )

    assert render_glob_result(result) == "Permission denied"
