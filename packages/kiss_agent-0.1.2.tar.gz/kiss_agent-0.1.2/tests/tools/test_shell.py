from __future__ import annotations

import pytest

from kiss.agent.tools.result_types import RunCommandResult
from kiss.agent.tools.shell import _truncate_streams, run_bash


def test_truncate_streams_small_budget_no_overflow() -> None:
    """When max_chars is small the per-stream budgets must not exceed it."""
    stdout = "a" * 500
    stderr = "b" * 500
    out, err, truncated = _truncate_streams(stdout, stderr, max_chars=600)

    assert truncated is True
    assert len(out) + len(err) <= 600 + len("\n... [truncated] ...\n") * 2


def test_truncate_streams_zero_budget() -> None:
    out, err, truncated = _truncate_streams("hello", "world", max_chars=0)

    assert out == ""
    assert err == ""
    assert truncated is True


@pytest.mark.asyncio
async def test_run_bash_success() -> None:
    result = await run_bash(
        "FOO=ok python3 -c \"import os; print(os.environ['FOO'])\" | cat"
    )

    assert isinstance(result, RunCommandResult)
    assert result.exit_code == 0
    assert "ok" in result.stdout
    assert result.truncated is False


@pytest.mark.asyncio
async def test_run_bash_timeout() -> None:
    result = await run_bash(
        'python3 -c "import time; time.sleep(1)"',
        timeout=0.01,
    )

    assert result.meta.ok is False
    assert result.meta.error_code == "timeout"
    assert result.timed_out is True


@pytest.mark.asyncio
async def test_run_bash_truncates_large_output() -> None:
    result = await run_bash(
        "python3 -c \"print('x' * 5000)\"",
        max_output_chars=200,
    )

    assert result.exit_code == 0
    assert result.truncated is True
    assert "[truncated]" in result.stdout
