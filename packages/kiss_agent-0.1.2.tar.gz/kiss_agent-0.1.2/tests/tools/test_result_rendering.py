from __future__ import annotations

from kiss.agent.tools.result_types import (
    AnalyzeCodeResult,
    AnalysisIssue,
    CodeLocation,
    DocumentSymbolsResult,
    EditFileResult,
    GitCommitResult,
    GitStageResult,
    ReadFileResult,
    SourceRange,
    SymbolInfo,
    ToolResultMeta,
    WriteFileResult,
)
from kiss.agent.tools.truncation import (
    render_analyze_code_result,
    render_document_symbols_result,
    render_edit_file_result,
    render_git_commit_result,
    render_git_stage_result,
    render_read_file_result,
    render_write_file_result,
)


def test_render_read_file_result_includes_metadata_and_numbered_content() -> None:
    result = ReadFileResult(
        path="/tmp/sample.py",
        exists=True,
        is_file=True,
        is_binary=False,
        size_bytes=12,
        start_line=10,
        end_line=11,
        line_count=20,
        truncated=True,
        content="alpha\nbeta\n",
    )

    rendered = render_read_file_result(result)

    assert "path: /tmp/sample.py" in rendered
    assert "lines: 10-11" in rendered
    assert "10 | alpha" in rendered
    assert "11 | beta" in rendered


def test_render_read_file_result_binary_is_metadata_only() -> None:
    result = ReadFileResult(
        path="/tmp/file.bin",
        exists=True,
        is_file=True,
        is_binary=True,
        size_bytes=3,
    )

    rendered = render_read_file_result(result)

    assert "is_binary: true" in rendered
    assert "content:" not in rendered


def test_render_write_file_result_includes_diff_preview() -> None:
    result = WriteFileResult(
        path="/tmp/sample.py",
        created=False,
        overwrote=True,
        bytes_written=21,
        line_count=2,
        diff_preview="@@ -1 +1 @@\n-old\n+new",
    )

    rendered = render_write_file_result(result)

    assert "overwrote: True" in rendered
    assert "bytes_written: 21" in rendered
    assert "diff_preview:" in rendered
    assert "+new" in rendered


def test_render_edit_file_result_disambiguation_includes_contexts() -> None:
    result = EditFileResult(
        path="/tmp/sample.py",
        meta=ToolResultMeta(
            ok=False,
            error_code="disambiguation_required",
            error_message=(
                "Error: old_text appears 2 times in /tmp/sample.py. "
                "Provide more surrounding context."
            ),
            needs_disambiguation=True,
        ),
        applied=False,
        requested_change_count=2,
        occurrence_count=2,
        failed_change_index=0,
        failed_change_label="change-1",
        recovery_type="ambiguous_match",
        match_contexts=["line 3: …foo old_text bar…"],
    )

    rendered = render_edit_file_result(result)

    assert "needs_disambiguation: True" in rendered
    assert "failed_change_label: change-1" in rendered
    assert "recovery_type: ambiguous_match" in rendered
    assert "match_contexts:" in rendered
    assert "line 3:" in rendered


def test_render_analyze_code_result_includes_metrics_and_issues() -> None:
    result = AnalyzeCodeResult(
        path="/tmp/sample.py",
        language="python",
        freshness_strategy="on_demand_workspace_scan",
        metrics={"function_count": 1},
        issues=[
            AnalysisIssue(
                code="syntax_error",
                message="bad syntax",
                severity="error",
                location=CodeLocation(
                    path="/tmp/sample.py",
                    range=SourceRange(start_line=3, start_col=1),
                ),
            )
        ],
    )

    rendered = render_analyze_code_result(result)

    assert "metrics:" in rendered
    assert "- function_count: 1" in rendered
    assert "issues:" in rendered
    assert "syntax_error" in rendered


def test_render_document_symbols_result_includes_symbols() -> None:
    result = DocumentSymbolsResult(
        path="/tmp/sample.py",
        language="python",
        freshness_strategy="on_demand_workspace_scan",
        symbol_count=1,
        symbols=[
            SymbolInfo(
                name="hello",
                kind="function",
                language="python",
                location=CodeLocation(
                    path="/tmp/sample.py",
                    range=SourceRange(start_line=5, start_col=0),
                ),
            )
        ],
    )

    rendered = render_document_symbols_result(result)

    assert "symbol_count: 1" in rendered
    assert "symbols:" in rendered
    assert "hello" in rendered


def test_render_git_stage_result_includes_operation_and_paths() -> None:
    result = GitStageResult(
        repo_path="/tmp/repo",
        repo_root="/tmp/repo",
        operation="stage",
        path_count=2,
        affected_paths=["src/app.py", "tests/test_app.py"],
    )

    rendered = render_git_stage_result(result)

    assert "operation: stage" in rendered
    assert "path_count: 2" in rendered
    assert "- src/app.py" in rendered


def test_render_git_commit_result_includes_safety_details() -> None:
    result = GitCommitResult(
        repo_path="/tmp/repo",
        repo_root="/tmp/repo",
        message="feat: add guarded commit",
        committed_paths=["src/app.py"],
        dirty_index_paths=["README.md"],
        missing_identity=False,
        meta=ToolResultMeta(
            ok=False,
            error_code="dirty_index",
            error_message="Staged changes do not exactly match the requested commit scope.",
        ),
    )

    rendered = render_git_commit_result(result)

    assert "message: feat: add guarded commit" in rendered
    assert (
        "error: Staged changes do not exactly match the requested commit scope."
        in rendered
    )
    assert "dirty_index_paths:" in rendered
    assert "- README.md" in rendered
