"""Tests for kiss.agent.tools.file."""

from __future__ import annotations

from pathlib import Path

import pytest

import kiss.agent.tools.file as file_tools
from kiss.agent.tools.file import (
    _file_locks,
    _lock,
    apply_patch,
    edit_file,
    read_file,
    write_file,
)
from kiss.agent.tools.result_types import (
    EditFileResult,
    ReadFileResult,
    WriteFileResult,
)


@pytest.fixture
def sample_file(tmp_path):
    f = tmp_path / "sample.txt"
    f.write_text("hello world\n", "utf-8")
    return f


# ── read_file ─────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_read_file_success(sample_file):
    result = await read_file(str(sample_file))
    assert isinstance(result, ReadFileResult)
    assert result.exists is True
    assert result.content == "hello world\n"
    assert result.start_line == 1
    assert result.end_line == 1


@pytest.mark.asyncio
async def test_read_file_not_found(tmp_path):
    result = await read_file(str(tmp_path / "missing.txt"))
    assert result.exists is False
    assert result.meta.ok is False
    assert result.meta.error_message is not None
    assert "does not exist" in result.meta.error_message


@pytest.mark.asyncio
async def test_read_file_is_directory(tmp_path):
    result = await read_file(str(tmp_path))
    assert result.is_file is False
    assert result.meta.ok is False
    assert result.meta.error_message is not None
    assert "not a file" in result.meta.error_message


@pytest.mark.asyncio
async def test_read_file_respects_offset_and_limit(tmp_path: Path):
    path = tmp_path / "sample.txt"
    path.write_text("a\nb\nc\nd\n", encoding="utf-8")

    result = await read_file(str(path), offset=2, limit=2)

    assert result.start_line == 2
    assert result.end_line == 3
    assert result.content == "b\nc\n"
    assert result.truncated is True


@pytest.mark.asyncio
async def test_read_file_stops_after_truncation(tmp_path: Path):
    """read_file must break the loop once truncation is reached."""
    path = tmp_path / "big.txt"
    lines = [f"line {i}\n" for i in range(100)]
    path.write_text("".join(lines), encoding="utf-8")

    result = await read_file(str(path), limit=5)

    assert result.content == "".join(lines[:5])
    assert result.truncated is True
    assert result.line_count == 6  # 5 collected + 1 that triggered break


@pytest.mark.asyncio
async def test_read_file_binary_returns_metadata_only(tmp_path: Path):
    path = tmp_path / "sample.bin"
    path.write_bytes(b"\x00\x01\x02")

    result = await read_file(str(path))

    assert result.is_binary is True
    assert result.content is None


@pytest.mark.asyncio
async def test_read_file_invalid_offset_reports_not_exists(tmp_path: Path):
    """Invalid offset must not claim the file exists before checking."""
    result = await read_file(str(tmp_path / "missing.txt"), offset=0)

    assert result.meta.ok is False
    assert result.exists is False
    assert result.is_file is False


@pytest.mark.asyncio
async def test_read_file_invalid_limit_reports_not_exists(tmp_path: Path):
    """Invalid limit must not claim the file exists before checking."""
    result = await read_file(str(tmp_path / "missing.txt"), limit=0)

    assert result.meta.ok is False
    assert result.exists is False
    assert result.is_file is False


# ── write_file ────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_write_file_creates_file(tmp_path):
    path = str(tmp_path / "new.txt")
    result = await write_file(path, "content")
    assert isinstance(result, WriteFileResult)
    assert result.created is True
    assert result.overwrote is False
    assert (tmp_path / "new.txt").read_text("utf-8") == "content"


@pytest.mark.asyncio
async def test_write_file_creates_parent_dirs(tmp_path):
    path = str(tmp_path / "a" / "b" / "c.txt")
    result = await write_file(path, "deep")
    assert result.meta.ok is True
    assert result.created is True


@pytest.mark.asyncio
async def test_write_file_refuses_overwrite(sample_file):
    result = await write_file(str(sample_file), "new content")
    assert result.meta.ok is False
    assert result.meta.error_code == "write_guard"
    # File content unchanged
    assert sample_file.read_text("utf-8") == "hello world\n"


@pytest.mark.asyncio
async def test_write_file_refuses_overwrite_preserves_content(sample_file):
    """Write-guard policy: write_file refuses to overwrite existing files."""
    result = await write_file(str(sample_file), "new content")
    assert result.meta.ok is False
    assert result.meta.error_code == "write_guard"
    # File content unchanged
    assert sample_file.read_text("utf-8") == "hello world\n"


# ── edit_file ─────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_edit_file_success(sample_file):
    result = await edit_file(str(sample_file), "hello", "goodbye")
    assert isinstance(result, EditFileResult)
    assert result.applied is True
    assert result.requested_change_count == 1
    assert result.applied_change_count == 1
    assert result.replacement_count == 1
    assert sample_file.read_text("utf-8") == "goodbye world\n"


@pytest.mark.asyncio
async def test_edit_file_old_text_not_found(sample_file):
    result = await edit_file(str(sample_file), "nonexistent", "replacement")
    assert result.meta.ok is False
    assert result.recovery_type == "not_found"
    assert result.failed_change_index == 0
    assert result.meta.error_message is not None
    assert "not found" in result.meta.error_message


@pytest.mark.asyncio
async def test_edit_file_missing_file(tmp_path):
    result = await edit_file(str(tmp_path / "missing.txt"), "a", "b")
    assert result.meta.ok is False
    assert result.meta.error_message is not None
    assert "does not exist" in result.meta.error_message


@pytest.mark.asyncio
async def test_edit_file_duplicate_match_needs_disambiguation(tmp_path):
    f = tmp_path / "dup.txt"
    f.write_text("aa aa", "utf-8")
    result = await edit_file(str(f), "aa", "bb")
    assert result.applied is False
    assert result.meta.needs_disambiguation is True
    assert result.recovery_type == "ambiguous_match"
    assert result.occurrence_count == 2
    assert result.match_contexts
    assert f.read_text("utf-8") == "aa aa"


@pytest.mark.asyncio
async def test_apply_patch_applies_multiple_changes_atomically(tmp_path: Path):
    path = tmp_path / "sample.txt"
    path.write_text("alpha\nbeta\ngamma\n", encoding="utf-8")

    result = await apply_patch(
        str(path),
        [
            {"label": "first", "old_text": "alpha", "new_text": "ALPHA"},
            {"label": "third", "old_text": "gamma", "new_text": "GAMMA"},
        ],
    )

    assert result.applied is True
    assert result.requested_change_count == 2
    assert result.applied_change_count == 2
    assert result.replacement_count == 2
    assert path.read_text("utf-8") == "ALPHA\nbeta\nGAMMA\n"


@pytest.mark.asyncio
async def test_apply_patch_rejects_overlap_and_preserves_file(tmp_path: Path):
    path = tmp_path / "sample.txt"
    path.write_text("abcdef", encoding="utf-8")

    result = await apply_patch(
        str(path),
        [
            {"label": "outer", "old_text": "abcd", "new_text": "ABCD"},
            {"label": "inner", "old_text": "bc", "new_text": "BC"},
        ],
    )

    assert result.meta.ok is False
    assert result.recovery_type == "overlap_rejected"
    assert result.failed_change_label == "inner"
    assert path.read_text("utf-8") == "abcdef"


@pytest.mark.asyncio
async def test_apply_patch_reports_failed_change_contexts(tmp_path: Path):
    path = tmp_path / "sample.txt"
    path.write_text("alpha\nbeta\ngamma\n", encoding="utf-8")

    result = await apply_patch(
        str(path),
        [
            {"label": "first", "old_text": "alpha", "new_text": "ALPHA"},
            {"label": "missing", "old_text": "betaa", "new_text": "BETA"},
        ],
    )

    assert result.meta.ok is False
    assert result.failed_change_label == "missing"
    assert result.failed_change_index == 1
    assert result.recovery_type == "not_found"
    assert result.match_contexts
    assert path.read_text("utf-8") == "alpha\nbeta\ngamma\n"


@pytest.mark.asyncio
async def test_apply_patch_rejects_invalid_change_shape(tmp_path: Path):
    path = tmp_path / "sample.txt"
    path.write_text("alpha\n", encoding="utf-8")

    result = await apply_patch(str(path), [{"label": "bad", "old_text": ""}])

    assert result.meta.ok is False
    assert result.recovery_type == "invalid_patch"
    assert result.failed_change_label == "bad"
    assert path.read_text("utf-8") == "alpha\n"


# ── file locks ────────────────────────────────────────────────────────────────


def test_file_locks_reuses_same_lock(tmp_path: Path):
    p = tmp_path / "reuse.txt"
    lock_a = _lock(p)
    lock_b = _lock(p)
    assert lock_a is lock_b


@pytest.mark.asyncio
async def test_file_locks_evicts_unlocked_entries_when_over_limit():
    original_max = file_tools._MAX_FILE_LOCKS
    file_tools._MAX_FILE_LOCKS = 3  # type: ignore
    _file_locks.clear()

    p1 = Path("/fake/1.txt")
    p2 = Path("/fake/2.txt")
    p3 = Path("/fake/3.txt")
    p4 = Path("/fake/4.txt")

    lock1 = _lock(p1)
    _lock(p2)
    _lock(p3)

    # All three should be present
    assert str(p1) in _file_locks
    assert str(p2) in _file_locks
    assert str(p3) in _file_locks

    # Simulate lock1 being held (locked) while others are free
    await lock1.acquire()
    _lock(p4)  # This triggers cleanup since len > 3

    # lock1 should remain because it's locked; lock2/3 may be evicted
    assert str(p1) in _file_locks

    lock1.release()
    file_tools._MAX_FILE_LOCKS = original_max
