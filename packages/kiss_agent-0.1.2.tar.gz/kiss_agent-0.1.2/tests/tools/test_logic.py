from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Any

import pytest

from kiss.agent.tools.logic.approval import LogicApprovalReply
from kiss.agent.tools.logic.executor import (
    ShadowWorkspace,
    SubprocessLogicExecutor,
    _truncate_streams,
)
from kiss.agent.tools.logic.run_python import run_python
from kiss.agent.tools.result_types import LogicApplyResult, LogicExecutionResult
from kiss.core.deps import AgentDeps


class _MockCtx:
    """Minimal mirascope-compatible context stub for tool unit tests."""

    def __init__(self, deps: AgentDeps) -> None:
        self.deps = deps


@pytest.mark.asyncio
async def test_subprocess_logic_executor_runs_async_code() -> None:
    executor = SubprocessLogicExecutor(timeout=10.0)

    result = await executor.execute('print("hello from logic")')

    assert isinstance(result, LogicExecutionResult)
    assert result.meta.ok is True
    assert result.exit_code == 0
    assert "hello from logic" in result.stdout


@pytest.mark.asyncio
async def test_subprocess_logic_executor_supports_guest_workspace_sdk(
    tmp_path: Path,
) -> None:
    path = tmp_path / "sample.txt"
    path.write_text("alpha\nbeta\n", encoding="utf-8")
    executor = SubprocessLogicExecutor(timeout=10.0)
    cwd = Path.cwd()
    try:
        os.chdir(tmp_path)
        result = await executor.execute(
            "\n".join(
                [
                    'matches = await kiss.workspace.search("alpha")',
                    'f = await kiss.workspace.open("sample.txt")',
                    "text = await f.read()",
                    'await f.replace("alpha", "ALPHA", count=1)',
                    "print(len(matches), text.splitlines()[0])",
                ]
            )
        )
    finally:
        os.chdir(cwd)

    assert result.meta.ok is True
    assert "1 alpha" in result.stdout
    assert result.pending_changes
    assert result.pending_changes[0].path == "sample.txt"


@pytest.mark.asyncio
async def test_subprocess_logic_executor_times_out() -> None:
    executor = SubprocessLogicExecutor(timeout=0.05)

    result = await executor.execute("while True:\n    pass")

    assert result.meta.ok is False
    assert result.meta.error_code == "timeout"
    assert result.timed_out is True


@pytest.mark.asyncio
async def test_subprocess_logic_executor_uses_minimal_safe_builtins() -> None:
    executor = SubprocessLogicExecutor(timeout=10.0)

    result = await executor.execute("import os")

    assert result.meta.ok is False
    assert result.meta.error_code == "execution_failed"
    assert "__import__" in result.stderr


@pytest.mark.asyncio
async def test_shadow_workspace_reads_virtual_content_after_write(
    tmp_path: Path,
) -> None:
    path = tmp_path / "sample.txt"
    path.write_text("alpha\n", encoding="utf-8")
    workspace = ShadowWorkspace(tmp_path)

    await workspace.write_text("sample.txt", "beta\n")
    content = await workspace.read_text("sample.txt")

    assert content == "beta\n"
    assert path.read_text(encoding="utf-8") == "alpha\n"
    assert workspace.pending_changes[0].change_type == "update"


@pytest.mark.asyncio
async def test_shadow_workspace_apply_detects_drift(tmp_path: Path) -> None:
    path = tmp_path / "sample.txt"
    path.write_text("alpha\n", encoding="utf-8")
    workspace = ShadowWorkspace(tmp_path)

    await workspace.write_text("sample.txt", "beta\n")
    path.write_text("gamma\n", encoding="utf-8")

    result = await workspace.apply_all()

    assert result.meta.ok is False
    assert result.meta.error_code == "drift_detected"
    assert str(path) in result.drift_detected_paths
    assert path.read_text(encoding="utf-8") == "gamma\n"


@pytest.mark.asyncio
async def test_shadow_workspace_apply_detects_created_file_collision(
    tmp_path: Path,
) -> None:
    path = tmp_path / "new.txt"
    workspace = ShadowWorkspace(tmp_path)

    await workspace.write_text("new.txt", "created\n")
    path.write_text("external\n", encoding="utf-8")

    result = await workspace.apply_all()

    assert result.meta.ok is False
    assert result.meta.error_code == "drift_detected"
    assert str(path) in result.drift_detected_paths


@pytest.mark.asyncio
async def test_shadow_workspace_concurrent_reads_and_serialized_mutations(
    tmp_path: Path,
) -> None:
    path = tmp_path / "sample.txt"
    path.write_text("alpha\n", encoding="utf-8")
    workspace = ShadowWorkspace(tmp_path)

    async def read_once() -> str:
        return await workspace.read_text("sample.txt")

    async def write_once(content: str) -> None:
        await workspace.write_text("sample.txt", content)

    reads = await asyncio.gather(read_once(), read_once(), read_once())
    await asyncio.gather(write_once("beta\n"), write_once("gamma\n"))

    assert reads == ["alpha\n", "alpha\n", "alpha\n"]
    assert await workspace.read_text("sample.txt") in {"beta\n", "gamma\n"}


@pytest.mark.asyncio
async def test_run_python_batch_refactor_with_approval(tmp_path: Path) -> None:
    (tmp_path / "a.py").write_text("x = old_name\n", encoding="utf-8")
    (tmp_path / "b.py").write_text("y = old_name\n", encoding="utf-8")
    (tmp_path / "c.py").write_text("# unrelated\n", encoding="utf-8")

    deps = AgentDeps(workspace_root=tmp_path)

    async def auto_approve(req: object) -> LogicApprovalReply:
        return LogicApprovalReply(approved=True)

    deps.on_logic_approval = auto_approve
    ctx: Any = _MockCtx(deps)

    code = "\n".join(
        [
            'matches = await kiss.workspace.search("old_name", path_glob="*.py")',
            "seen = set()",
            "for m in matches:",
            "    if m.path not in seen:",
            "        seen.add(m.path)",
            '        await m.file.replace("old_name", "new_name")',
        ]
    )

    result = await run_python(ctx, code, timeout=5.0)

    assert isinstance(result, LogicApplyResult)
    assert result.approved is True
    assert result.applied_count == 2
    assert (tmp_path / "a.py").read_text(encoding="utf-8") == "x = new_name\n"
    assert (tmp_path / "b.py").read_text(encoding="utf-8") == "y = new_name\n"
    assert (tmp_path / "c.py").read_text(encoding="utf-8") == "# unrelated\n"


@pytest.mark.asyncio
async def test_run_python_denied_manifest_leaves_disk_unchanged(tmp_path: Path) -> None:
    path = tmp_path / "target.txt"
    path.write_text("original\n", encoding="utf-8")

    deps = AgentDeps(workspace_root=tmp_path)

    async def auto_deny(req: object) -> LogicApprovalReply:
        return LogicApprovalReply(approved=False)

    deps.on_logic_approval = auto_deny
    ctx: Any = _MockCtx(deps)

    code = "\n".join(
        [
            'f = await kiss.workspace.open("target.txt")',
            'await f.write("changed")',
        ]
    )
    result = await run_python(ctx, code, timeout=5.0)

    assert isinstance(result, LogicApplyResult)
    assert result.approved is False
    assert result.meta.error_code == "permission_denied"
    assert path.read_text(encoding="utf-8") == "original\n"  # unchanged


def test_logic_truncate_streams_small_budget_no_overflow() -> None:
    """_truncate_streams must not overflow max_chars when budget is small."""
    stdout = "a" * 400
    stderr = "b" * 400

    out, err, truncated = _truncate_streams(stdout, stderr, max_chars=600)

    assert truncated is True
    assert len(out) + len(err) <= 600


def test_logic_truncate_streams_zero_budget() -> None:
    out, err, truncated = _truncate_streams("hello", "world", max_chars=0)

    assert out == ""
    assert err == ""
    assert truncated is True
