from __future__ import annotations

from kiss.agent.tools.result_types import RunCommandResult
from kiss.agent.tools.truncation import render_run_command_result


def test_render_run_command_result_keeps_stdout_and_stderr_separate() -> None:
    result = RunCommandResult(
        command="python3 -c ...",
        exit_code=1,
        truncated=True,
        stdout="out\n",
        stderr="err\n",
    )

    rendered = render_run_command_result(result)

    assert "truncated: True" in rendered
    assert "stdout:" in rendered
    assert "stderr:" in rendered
    assert "out" in rendered
    assert "err" in rendered
