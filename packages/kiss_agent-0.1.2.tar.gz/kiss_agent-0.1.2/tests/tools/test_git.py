from __future__ import annotations

import asyncio
import subprocess
from pathlib import Path

import pytest

from kiss.agent.tools.git import (
    _parse_branch_header,
    _run_git,
    git_commit,
    git_diff,
    git_log,
    git_stage,
    git_status,
    git_unstage,
)


def _git(*args: str, cwd: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args],
        cwd=cwd,
        check=True,
        capture_output=True,
        text=True,
    )


def _init_repo(path: str) -> None:
    _git("init", cwd=path)
    _git("branch", "-M", "main", cwd=path)
    _git("config", "user.name", "Test User", cwd=path)
    _git("config", "user.email", "test@example.com", cwd=path)


@pytest.mark.asyncio
async def test_git_read_tools_return_structured_results(tmp_path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(str(repo))

    tracked = repo / "tracked.txt"
    tracked.write_text("one\n")
    _git("add", "tracked.txt", cwd=str(repo))
    _git("commit", "-m", "initial", cwd=str(repo))

    tracked.write_text("two\n")
    staged = repo / "staged.txt"
    staged.write_text("staged\n")
    _git("add", "staged.txt", cwd=str(repo))
    untracked = repo / "untracked.txt"
    untracked.write_text("untracked\n")

    status_result = await git_status(repo)
    assert status_result.meta.ok is True
    assert status_result.repo_root == str(repo.resolve())
    assert {entry.path for entry in status_result.entries} == {
        "tracked.txt",
        "staged.txt",
        "untracked.txt",
    }

    diff_result = await git_diff(repo)
    assert diff_result.meta.ok is True
    assert diff_result.staged is False
    assert "--- a/tracked.txt" in diff_result.diff

    staged_diff_result = await git_diff(repo, staged=True)
    assert staged_diff_result.meta.ok is True
    assert staged_diff_result.staged is True
    assert "+++ b/staged.txt" in staged_diff_result.diff

    log_result = await git_log(repo, limit=5)
    assert log_result.meta.ok is True
    assert log_result.commits
    assert log_result.commits[0].subject == "initial"


@pytest.mark.asyncio
async def test_git_stage_and_unstage_selected_files(tmp_path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(str(repo))

    tracked = repo / "tracked.txt"
    tracked.write_text("one\n")
    _git("add", "tracked.txt", cwd=str(repo))
    _git("commit", "-m", "feat: add tracked file", cwd=str(repo))

    tracked.write_text("two\n")

    stage_result = await git_stage(repo, paths=["tracked.txt"])
    assert stage_result.meta.ok is True
    assert stage_result.operation == "stage"
    assert stage_result.affected_paths == ["tracked.txt"]

    staged_names = _git(
        "diff", "--cached", "--name-only", cwd=str(repo)
    ).stdout.splitlines()
    assert staged_names == ["tracked.txt"]

    unstage_result = await git_unstage(repo, paths=["tracked.txt"])
    assert unstage_result.meta.ok is True
    assert unstage_result.operation == "unstage"

    staged_names = _git(
        "diff", "--cached", "--name-only", cwd=str(repo)
    ).stdout.splitlines()
    assert staged_names == []


@pytest.mark.asyncio
async def test_git_commit_creates_commit_for_requested_paths(tmp_path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(str(repo))

    tracked = repo / "tracked.txt"
    tracked.write_text("one\n")
    _git("add", "tracked.txt", cwd=str(repo))
    _git("commit", "-m", "feat: add tracked file", cwd=str(repo))

    tracked.write_text("two\n")
    await git_stage(repo, paths=["tracked.txt"])

    commit_result = await git_commit(
        repo,
        message="feat: update tracked file",
        paths=["tracked.txt"],
    )

    assert commit_result.meta.ok is True
    assert commit_result.commit is not None
    assert commit_result.committed_paths == ["tracked.txt"]
    head_subject = _git("log", "-1", "--pretty=%s", cwd=str(repo)).stdout.strip()
    assert head_subject == "feat: update tracked file"


@pytest.mark.asyncio
async def test_git_commit_rejects_invalid_message(tmp_path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(str(repo))

    tracked = repo / "tracked.txt"
    tracked.write_text("one\n")
    _git("add", "tracked.txt", cwd=str(repo))

    commit_result = await git_commit(
        repo,
        message="bad message",
        paths=["tracked.txt"],
    )

    assert commit_result.meta.ok is False
    assert commit_result.meta.error_code == "invalid_input"


@pytest.mark.asyncio
async def test_git_commit_fails_when_identity_missing(tmp_path, monkeypatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _git("init", cwd=str(repo))
    _git("branch", "-M", "main", cwd=str(repo))

    home = tmp_path / "home"
    xdg = tmp_path / "xdg"
    home.mkdir()
    xdg.mkdir()
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(xdg))
    monkeypatch.setenv("GIT_CONFIG_NOSYSTEM", "1")
    monkeypatch.delenv("GIT_CONFIG_GLOBAL", raising=False)

    tracked = repo / "tracked.txt"
    tracked.write_text("one\n")
    await git_stage(repo, paths=["tracked.txt"])

    commit_result = await git_commit(
        repo,
        message="feat: add tracked file",
        paths=["tracked.txt"],
    )

    assert commit_result.meta.ok is False
    assert commit_result.meta.error_code == "missing_identity"
    assert commit_result.missing_identity is True


@pytest.mark.asyncio
async def test_git_commit_detects_unrelated_staged_changes(tmp_path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(str(repo))

    tracked = repo / "tracked.txt"
    extra = repo / "extra.txt"
    tracked.write_text("one\n")
    extra.write_text("alpha\n")
    _git("add", "tracked.txt", "extra.txt", cwd=str(repo))
    _git("commit", "-m", "feat: add tracked files", cwd=str(repo))

    tracked.write_text("two\n")
    extra.write_text("beta\n")
    await git_stage(repo, paths=["tracked.txt", "extra.txt"])

    commit_result = await git_commit(
        repo,
        message="feat: update tracked file",
        paths=["tracked.txt"],
    )

    assert commit_result.meta.ok is False
    assert commit_result.meta.error_code == "dirty_index"
    assert commit_result.dirty_index_paths == ["extra.txt"]


# ── timeout ───────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_git_run_times_out(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    class FakeProcess:
        async def communicate(self) -> tuple[bytes, bytes]:
            await asyncio.sleep(1000)
            return b"", b""

        async def wait(self) -> int:
            return 0

        def kill(self) -> None:
            pass

    async def fake_create(*a: object, **kw: object) -> FakeProcess:
        return FakeProcess()

    monkeypatch.setattr(asyncio, "create_subprocess_exec", fake_create)

    result = await _run_git(tmp_path, "status", timeout=0.01)

    assert result.meta is not None
    assert result.meta.error_code == "timeout"
    assert result.meta.error_message is not None
    assert "timed out" in result.meta.error_message


# ── detached HEAD ─────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_git_status_detects_detached_head(tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(str(repo))

    tracked = repo / "tracked.txt"
    tracked.write_text("one\n")
    _git("add", "tracked.txt", cwd=str(repo))
    _git("commit", "-m", "feat: initial", cwd=str(repo))

    # Detach HEAD
    head = _git("rev-parse", "HEAD", cwd=str(repo)).stdout.strip()
    _git("checkout", head, cwd=str(repo))

    status_result = await git_status(repo)
    assert status_result.detached is True
    assert status_result.branch is None


# ── log truncation flag ───────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_git_log_truncated_false_when_exactly_at_limit(tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(str(repo))

    # Create exactly 3 commits
    for i in range(3):
        f = repo / f"file{i}.txt"
        f.write_text(f"content{i}\n")
        _git("add", f"file{i}.txt", cwd=str(repo))
        _git("commit", "-m", f"feat: add file {i}", cwd=str(repo))

    log_result = await git_log(repo, limit=3)
    assert log_result.truncated is False
    assert len(log_result.commits) == 3


# ── branch header parsing ─────────────────────────────────────────────────────


def test_parse_branch_header_detached_at_commit() -> None:
    branch, detached, ahead, behind = _parse_branch_header("HEAD (no branch)")
    assert detached is True
    assert branch is None


def test_parse_branch_header_detached_with_sha() -> None:
    branch, detached, ahead, behind = _parse_branch_header("(HEAD detached at abc1234)")
    assert detached is True
    assert branch is None


def test_parse_branch_header_normal_branch() -> None:
    branch, detached, ahead, behind = _parse_branch_header("main")
    assert detached is False
    assert branch == "main"


def test_parse_branch_header_tracking_branch() -> None:
    branch, detached, ahead, behind = _parse_branch_header(
        "main...origin/main [ahead 2, behind 1]"
    )
    assert detached is False
    assert branch == "main"
    assert ahead == 2
    assert behind == 1
