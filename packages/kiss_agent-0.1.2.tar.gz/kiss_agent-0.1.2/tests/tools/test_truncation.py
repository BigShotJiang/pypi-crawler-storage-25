from __future__ import annotations

import pytest

from kiss.agent.tools.truncation import (
    PreparedToolOutput,
    TruncationStrategy,
    ToolOutputBudget,
    estimate_tokens,
    prepare_tool_output,
    truncate_text,
    truncate_tool_output,
)
from kiss.agent.tools.result_types import (
    ReadFileResult,
    WriteFileResult,
    EditFileResult,
    ExpandRefResult,
    SearchCodeResult,
    GlobResult,
    ListDirectoryResult,
    RunCommandResult,
    FetchUrlResult,
    WebSearchResult,
    GitStatusResult,
    GitDiffResult,
    GitLogResult,
    GitStageResult,
    GitCommitResult,
    AnalyzeCodeResult,
    CheckStyleResult,
    DefinitionResult,
    ReferencesResult,
    DocumentSymbolsResult,
    WorkspaceSymbolsResult,
    LogicExecutionResult,
    LogicApplyResult,
)
from kiss.core.deps import AgentDeps


def test_tool_output_budget_uses_available_context():
    budget = ToolOutputBudget(
        context_window=20_000,
        current_usage_tokens=9_000,
        safety_buffer=1_000,
        max_output_tokens=12_000,
        min_output_tokens=1_000,
    )

    assert budget.limit_tokens == 10_000


def test_tool_output_budget_clamps_to_minimum():
    budget = ToolOutputBudget(
        context_window=2_000,
        current_usage_tokens=1_900,
        safety_buffer=1_000,
        max_output_tokens=12_000,
        min_output_tokens=1_000,
    )

    assert budget.limit_tokens == 1_000


def test_truncate_text_keeps_head_and_tail():
    text = "\n".join(f"line {i}: {'x' * 60}" for i in range(500))

    result = truncate_text(text, max_tokens=200, label="test output")

    assert "line 0:" in result
    assert "line 499:" in result
    assert "truncated test output" in result
    assert estimate_tokens(result) <= 220


def test_short_tool_output_is_unchanged():
    deps = AgentDeps(tool_output_max_tokens=1_000)
    output = "small output"

    assert truncate_tool_output(output, deps, "read_file output") == output


def test_truncate_text_rejects_empty_budget():
    with pytest.raises(ValueError, match="max_tokens"):
        truncate_text("hello", max_tokens=0)


def test_truncate_text_tail_heavy_keeps_more_tail():
    text = "\n".join(f"line {i}: {'x' * 60}" for i in range(500))

    result = truncate_text(
        text,
        max_tokens=200,
        label="shell output",
        strategy=TruncationStrategy.TAIL_HEAVY,
    )

    assert "line 499:" in result
    assert "truncated shell output" in result


def test_truncate_text_top_matches_prefers_early_lines():
    text = "\n".join(f"match {i}" for i in range(200))

    result = truncate_text(
        text,
        max_tokens=60,
        label="search output",
        strategy=TruncationStrategy.TOP_MATCHES,
    )

    assert "match 0" in result
    assert "match 199" not in result
    assert "truncated search output" in result


def test_truncate_text_top_matches_includes_marker_in_budget():
    """The truncation marker must be accounted for in the token budget."""
    text = "\n".join(f"match {i}" for i in range(200))

    result = truncate_text(
        text,
        max_tokens=60,
        label="search output",
        strategy=TruncationStrategy.TOP_MATCHES,
    )

    assert estimate_tokens(result) <= 60


def test_prepare_tool_output_uses_separate_model_and_ui_budgets():
    deps = AgentDeps(
        context_window=20_000,
        current_usage_tokens=19_500,
        tool_output_safety_buffer=1_000,
        tool_output_max_tokens=500,
        tool_output_min_tokens=100,
    )
    output = "\n".join(f"line {i}: {'x' * 60}" for i in range(400))

    prepared = prepare_tool_output("run_bash", output, deps)

    assert isinstance(prepared, PreparedToolOutput)
    assert estimate_tokens(prepared.model_text) <= 130
    assert estimate_tokens(prepared.ui_text) <= 1_030
    assert len(prepared.ui_text) >= len(prepared.model_text)


@pytest.mark.parametrize(
    "tool_name,result",
    [
        ("read_file", ReadFileResult(path="/tmp/f.py", exists=True)),
        ("write_file", WriteFileResult(path="/tmp/f.py")),
        ("edit_file", EditFileResult(path="/tmp/f.py")),
        ("expand_ref", ExpandRefResult(ref="myref")),
        ("search_code", SearchCodeResult(pattern="def hello")),
        ("glob", GlobResult(pattern="**/*.py", root="/tmp")),
        ("list_directory", ListDirectoryResult(root="/tmp", max_depth=2)),
        ("run_bash", RunCommandResult(command="ls")),
        ("fetch_url", FetchUrlResult(url="https://example.com")),
        ("web_search", WebSearchResult(query="python")),
        ("git_status", GitStatusResult(repo_path="/tmp")),
        ("git_diff", GitDiffResult(repo_path="/tmp")),
        ("git_log", GitLogResult(repo_path="/tmp")),
        ("git_stage", GitStageResult(repo_path="/tmp")),
        ("git_commit", GitCommitResult(repo_path="/tmp")),
        ("analyze_code", AnalyzeCodeResult(path="/tmp/f.py")),
        ("check_style", CheckStyleResult(path="/tmp/f.py")),
        ("find_definition", DefinitionResult(query="hello")),
        ("find_references", ReferencesResult(query="hello")),
        ("document_symbols", DocumentSymbolsResult(path="/tmp/f.py")),
        ("workspace_symbols", WorkspaceSymbolsResult(query="hello")),
        ("run_python", LogicExecutionResult(code="print(1)")),
        ("run_python", LogicApplyResult()),
    ],
)
def test_prepare_tool_output_handles_all_result_types(
    tool_name: str, result: object
) -> None:
    deps = AgentDeps(tool_output_max_tokens=1000)

    output = prepare_tool_output(tool_name, result, deps)

    assert isinstance(output, PreparedToolOutput)
    assert isinstance(output.model_text, str)
    assert isinstance(output.ui_text, str)
    assert output.model_result is not None
