"""Tests for kiss.agent.tools.memory."""

from __future__ import annotations

from pathlib import Path

import pytest

from kiss.agent.tools.memory import append_memory, load_memory_block, read_memory


# ── load_memory_block ─────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_load_memory_block_both_files(tmp_path: Path) -> None:
    global_path = tmp_path / ".kiss" / "global_memory.md"
    project_path = tmp_path / ".kiss" / "memory.md"
    global_path.parent.mkdir(parents=True)
    global_path.write_text("- prefer uv\n")
    project_path.write_text("- use pytest\n")

    # Patch the global path by testing via a workspace that has project memory,
    # and separately confirm global loading via the real path constant.
    # For isolation we test each scope independently.
    result = await load_memory_block(tmp_path)
    assert "[Project memory]" in result
    assert "- use pytest\n" in result
    assert not result.endswith("---\n")


@pytest.mark.asyncio
async def test_load_memory_block_project_only(tmp_path: Path) -> None:
    project_path = tmp_path / ".kiss" / "memory.md"
    project_path.parent.mkdir(parents=True)
    project_path.write_text("- use ruff\n")

    result = await load_memory_block(tmp_path)
    assert "[Project memory]" in result
    assert "- use ruff\n" in result


@pytest.mark.asyncio
async def test_load_memory_block_neither_returns_empty(tmp_path: Path) -> None:
    result = await load_memory_block(tmp_path)
    assert result == ""


# ── append_memory ─────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_append_memory_creates_file_on_first_call(tmp_path: Path) -> None:
    result = await append_memory("always use uv", "project", tmp_path)
    path = tmp_path / ".kiss" / "memory.md"
    assert path.exists()
    assert "- always use uv\n" in path.read_text()
    assert result == "Saved to project memory."


@pytest.mark.asyncio
async def test_append_memory_appends_to_existing(tmp_path: Path) -> None:
    path = tmp_path / ".kiss" / "memory.md"
    path.parent.mkdir(parents=True)
    path.write_text("- first\n")
    await append_memory("second", "project", tmp_path)
    content = path.read_text()
    assert "- first\n" in content
    assert "- second\n" in content


@pytest.mark.asyncio
async def test_append_memory_100_line_cap(tmp_path: Path) -> None:
    path = tmp_path / ".kiss" / "memory.md"
    path.parent.mkdir(parents=True)
    path.write_text("".join(f"- line {i}\n" for i in range(100)))
    await append_memory("new line", "project", tmp_path)
    lines = path.read_text().splitlines()
    assert len(lines) == 100
    assert lines[0] == "- line 1"
    assert lines[-1] == "- new line"


@pytest.mark.asyncio
async def test_append_memory_invalid_scope(tmp_path: Path) -> None:
    result = await append_memory("text", "invalid", tmp_path)
    assert result == "invalid scope: must be 'global' or 'project'"


@pytest.mark.asyncio
async def test_append_memory_adds_newline_when_missing(tmp_path: Path) -> None:
    """If the file doesn't end with \n, a newline separator should be added."""
    path = tmp_path / ".kiss" / "memory.md"
    path.parent.mkdir(parents=True)
    path.write_text("- last line without newline")
    await append_memory("new item", "project", tmp_path)
    content = path.read_text()
    assert "- last line without newline\n- new item\n" in content


# ── read_memory ───────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_read_memory_absent_file_returns_no_memory(tmp_path: Path) -> None:
    result = await read_memory("project", tmp_path)
    assert result == "No project memory."


@pytest.mark.asyncio
async def test_read_memory_returns_file_content(tmp_path: Path) -> None:
    path = tmp_path / ".kiss" / "memory.md"
    path.parent.mkdir(parents=True)
    path.write_text("- use pytest\n")
    result = await read_memory("project", tmp_path)
    assert result == "- use pytest\n"


@pytest.mark.asyncio
async def test_read_memory_both_missing(tmp_path: Path) -> None:
    result = await read_memory("both", tmp_path)
    assert "No global memory." in result
    assert "No project memory." in result


@pytest.mark.asyncio
async def test_read_memory_invalid_scope(tmp_path: Path) -> None:
    result = await read_memory("bad", tmp_path)
    assert "invalid scope" in result


# ── load_memory_block injection format ────────────────────────────────────────


@pytest.mark.asyncio
async def test_load_memory_block_no_trailing_separator(tmp_path: Path) -> None:
    project_path = tmp_path / ".kiss" / "memory.md"
    project_path.parent.mkdir(parents=True)
    project_path.write_text("- convention\n")

    block = await load_memory_block(tmp_path)
    assert block.endswith("- convention\n")
    assert "---" not in block
