"""Tests for kiss.agent.tools.code."""

from __future__ import annotations

from pathlib import Path

import pytest

from kiss.agent.tools import code as code_tools
from kiss.agent.tools.code import _parse_search_matches, list_directory, search_code
from kiss.agent.tools.result_types import ListDirectoryResult, SearchCodeResult


@pytest.mark.asyncio
async def test_list_directory_basic(tmp_path):
    (tmp_path / "a.txt").write_text("a")
    (tmp_path / "sub").mkdir()
    (tmp_path / "sub" / "b.txt").write_text("b")

    result = await list_directory(str(tmp_path))
    assert isinstance(result, ListDirectoryResult)
    assert any(entry.path == "a.txt" for entry in result.entries)
    assert any(entry.path == "sub" and entry.kind == "dir" for entry in result.entries)
    assert any(entry.path == "sub/b.txt" for entry in result.entries)


@pytest.mark.asyncio
async def test_list_directory_nonexistent(tmp_path):
    result = await list_directory(str(tmp_path / "missing"))
    assert result.meta.ok is False
    assert result.meta.error_message is not None
    assert "does not exist" in result.meta.error_message


@pytest.mark.asyncio
async def test_list_directory_empty(tmp_path):
    result = await list_directory(str(tmp_path))
    assert result.entries == []


@pytest.mark.asyncio
async def test_list_directory_excludes_hidden(tmp_path):
    (tmp_path / ".hidden").mkdir()
    (tmp_path / ".hidden" / "secret.txt").write_text("x")
    (tmp_path / "visible.txt").write_text("y")

    result = await list_directory(str(tmp_path))
    assert all("secret.txt" not in entry.path for entry in result.entries)
    assert any("visible.txt" in entry.path for entry in result.entries)


@pytest.mark.asyncio
async def test_list_directory_excludes_pycache(tmp_path):
    (tmp_path / "__pycache__").mkdir()
    (tmp_path / "__pycache__" / "mod.pyc").write_text("")
    (tmp_path / "mod.py").write_text("")

    result = await list_directory(str(tmp_path))
    assert all("mod.pyc" not in entry.path for entry in result.entries)
    assert any("mod.py" in entry.path for entry in result.entries)


@pytest.mark.asyncio
async def test_list_directory_max_depth(tmp_path):
    deep = tmp_path / "a" / "b" / "c" / "d"
    deep.mkdir(parents=True)
    (deep / "deep.txt").write_text("")

    result = await list_directory(str(tmp_path), max_depth=2)
    assert all("deep.txt" not in entry.path for entry in result.entries)
    assert any(entry.path == "a" for entry in result.entries)
    assert result.truncated is True


def test_parse_search_matches_handles_colons_in_match_text():
    matches = _parse_search_matches(
        "src/app.py:12:foo: bar\nsrc/lib.py:4:baz\n",
        Path.cwd(),
    )

    assert matches[0].path == "src/app.py"
    assert matches[0].line == 12
    assert matches[0].text == "foo: bar"
    assert matches[1].path == "src/lib.py"


def test_parse_search_matches_handles_windows_drive_letter():
    """Windows absolute paths like C:\\src\\file.py:10:match must parse correctly."""
    root = Path("/workspace")
    matches = _parse_search_matches(
        "C:\\src\\file.py:10:hello world\nC:\\src\\other.py:20:foo:bar\n",
        root,
    )

    assert len(matches) == 2
    assert matches[0].path == "C:\\src\\file.py"
    assert matches[0].line == 10
    assert matches[0].text == "hello world"
    assert matches[1].path == "C:\\src\\other.py"
    assert matches[1].line == 20
    assert matches[1].text == "foo:bar"


def test_match_path_glob_supports_double_star():
    """** should match across directory boundaries."""
    assert code_tools._match_path_glob("src/app.py", "**/*.py") is True
    assert code_tools._match_path_glob("deep/nested/app.py", "**/*.py") is True
    assert code_tools._match_path_glob("app.py", "**/*.py") is True
    assert code_tools._match_path_glob("src/app.js", "**/*.py") is False
    assert code_tools._match_path_glob("src/app.py", "src/**/*.py") is True
    assert code_tools._match_path_glob("src/deep/app.py", "src/**/*.py") is True
    assert code_tools._match_path_glob("app.py", "src/**/*.py") is False


def test_search_code_result_defaults():
    result = SearchCodeResult(pattern="foo")

    assert result.match_count == 0
    assert result.matches == []


@pytest.mark.asyncio
async def test_search_code_filters_by_path_glob(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
):
    async def fake_run_search(cmd: list[str]) -> tuple[int, str, str]:
        return (
            0,
            "src/app.py:1:alpha\nsrc/other.txt:2:beta\ntests/test_app.py:3:gamma\n",
            "",
        )

    monkeypatch.setattr(code_tools.shutil, "which", lambda name: "/usr/bin/rg")
    monkeypatch.setattr(code_tools, "_run_search", fake_run_search)

    result = await search_code(
        "alpha|beta|gamma",
        path_glob="src/*.py",
        workspace_root=tmp_path,
    )

    assert [match.path for match in result.matches] == ["src/app.py"]
    assert result.match_count == 1


@pytest.mark.asyncio
async def test_search_code_respects_max_matches(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
):
    async def fake_run_search(cmd: list[str]) -> tuple[int, str, str]:
        return (0, "a.py:1:x\na.py:2:y\nb.py:3:z\n", "")

    monkeypatch.setattr(code_tools.shutil, "which", lambda name: "/usr/bin/rg")
    monkeypatch.setattr(code_tools, "_run_search", fake_run_search)

    result = await search_code("x|y|z", max_matches=2, workspace_root=tmp_path)

    assert result.truncated is True
    assert result.match_count == 3
    assert len(result.matches) == 2


@pytest.mark.asyncio
async def test_search_code_rg_searches_workspace_root(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
):
    captured_cmd: list[str] = []

    async def fake_run_search(cmd: list[str]) -> tuple[int, str, str]:
        captured_cmd.extend(cmd)
        return (0, "", "")

    monkeypatch.setattr(code_tools.shutil, "which", lambda name: "/usr/bin/rg")
    monkeypatch.setattr(code_tools, "_run_search", fake_run_search)

    await search_code("foo", workspace_root=tmp_path)

    assert str(tmp_path) in captured_cmd


@pytest.mark.asyncio
async def test_search_code_rg_escapes_leading_dash(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
):
    captured_cmd: list[str] = []

    async def fake_run_search(cmd: list[str]) -> tuple[int, str, str]:
        captured_cmd.extend(cmd)
        return (0, "", "")

    monkeypatch.setattr(code_tools.shutil, "which", lambda name: "/usr/bin/rg")
    monkeypatch.setattr(code_tools, "_run_search", fake_run_search)

    await search_code("-foo", workspace_root=tmp_path)

    assert "--" in captured_cmd
    dash_index = captured_cmd.index("--")
    assert captured_cmd[dash_index + 1] == "-foo"


@pytest.mark.asyncio
async def test_search_code_git_grep_uses_e_flag_for_pattern(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
):
    captured_cmd: list[str] = []

    async def fake_run_search(cmd: list[str]) -> tuple[int, str, str]:
        captured_cmd.extend(cmd)
        return (1, "", "")

    monkeypatch.setattr(code_tools.shutil, "which", lambda name: None)
    monkeypatch.setattr(code_tools, "_run_search", fake_run_search)

    await search_code("-foo", workspace_root=tmp_path)

    assert "-e" in captured_cmd
    e_index = captured_cmd.index("-e")
    assert captured_cmd[e_index + 1] == "-foo"


@pytest.mark.asyncio
async def test_search_code_grep_escapes_leading_dash(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
):
    calls: list[list[str]] = []

    async def fake_run_search(cmd: list[str]) -> tuple[int, str, str]:
        calls.append(cmd)
        if cmd[0] == "git":
            return (127, "", "command not found")
        return (0, "", "")

    monkeypatch.setattr(code_tools.shutil, "which", lambda name: None)
    monkeypatch.setattr(code_tools, "_run_search", fake_run_search)

    await search_code("-foo", workspace_root=tmp_path)

    grep_cmd = [c for c in calls if c[0] == "grep"][0]
    assert "--" in grep_cmd
    dash_index = grep_cmd.index("--")
    assert grep_cmd[dash_index + 1] == "-foo"
