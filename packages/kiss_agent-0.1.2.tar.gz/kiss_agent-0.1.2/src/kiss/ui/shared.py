"""Shared utilities used by both the Rich and Textual UI backends.

No Rich-specific or Textual-specific imports — only stdlib.
"""

from __future__ import annotations

import subprocess  # nosec B404
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, TypeVar

import msgspec

from kiss.core.events import AskUserRequest


# ── Constants ────────────────────────────────────────────────────────────────

_MUTATING_TOOLS: frozenset[str] = frozenset({"write_file", "edit_file", "apply_patch"})

_T = TypeVar("_T")

BUDGET_COLORS: dict[str, str] = {
    "System": "cyan",
    "User": "green",
    "Assistant": "yellow",
    "Tools": "magenta",
}

_BUDGET_ORDER = ["System", "User", "Assistant", "Tools"]


# ── Data types ───────────────────────────────────────────────────────────────


def require_event_field(value: _T | None, name: str, kind: str) -> _T:
    """Raise RuntimeError if value is None; return value otherwise."""
    if value is None:
        raise RuntimeError(f"{kind} event missing {name} field")
    return value


# ── Session-level token accumulator ──────────────────────────────────────────


@dataclass
class SessionTotals:
    """Accumulated session-level token and turn counts for both UI backends."""

    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    thinking_tokens: int = 0
    turn_count: int = 0

    def accumulate(self, turn_usage: Any | None) -> str | None:
        """Update totals from turn_usage and return finish_reason (or None)."""
        if turn_usage is None:
            return None
        self.input_tokens += turn_usage.input_tokens
        self.output_tokens += turn_usage.output_tokens
        self.cache_read_tokens += turn_usage.cache_read_tokens
        self.cache_write_tokens += turn_usage.cache_write_tokens
        self.thinking_tokens += turn_usage.thinking_tokens
        self.turn_count += 1
        return turn_usage.finish_reason


class FileChange(msgspec.Struct, omit_defaults=True):
    path: str
    added: int = 0
    removed: int = 0


# ── Transcript lane metadata ─────────────────────────────────────────────────

LaneKind = Literal["user", "assistant", "thought", "tool", "system"]
LaneDepth = Literal["primary", "secondary"]


class TranscriptLane(msgspec.Struct, omit_defaults=True):
    """Canonical lane identity for a transcript entry.

    Both backends render from this — never infer lane from label text.
    thought_id is populated for thought-kind lanes only; it is stable across
    all deltas in one thought stream and used for /detail thought:<id> expansion.
    """

    kind: LaneKind
    depth: LaneDepth = "primary"
    thought_id: str | None = None


# ── File-operation canonical types ───────────────────────────────────────────

FileOperationKind = Literal["create", "modify", "delete", "move", "patch"]


class FileOperationResult(msgspec.Struct, omit_defaults=True):
    """Canonical file-operation result metadata consumed by both UI backends.

    Backends check result_kind == 'file_operation' to apply the canonical
    summary formatter instead of generic tool-output display.

    Operation classification:
    - 'patch'  → targeted edits with hunk/range-level semantics
    - 'modify' → whole-file rewrite/overwrite without patch-hunk semantics
    - 'create' → new file written
    - 'delete' → file removed
    - 'move'   → file renamed/moved; set from_path and to_path

    added_lines / removed_lines are populated from tool-provided counts or
    exact hunk accounting only — never computed by re-reading files.
    """

    operation: FileOperationKind
    path: str
    from_path: str | None = None
    to_path: str | None = None
    added_lines: int | None = None
    removed_lines: int | None = None
    diff_preview: str | None = None
    structured_patch: str | None = None
    diagnostics: str | None = None
    result_kind: Literal["file_operation"] = "file_operation"


class TokenBudgetEntry(msgspec.Struct, omit_defaults=True):
    label: str
    tokens: int
    pct: int


class TruncationMeta(msgspec.Struct, omit_defaults=True):
    """Durable truncation metadata surfaced to UI backends.

    When a tool result is truncated, this carries the information both backends
    need to explain the omission and offer retrieval without reparsing output text.
    """

    truncated: bool = False
    # Path to the persisted full output under ~/.kiss/agent/tool-output/ if saved.
    persisted_path: str | None = None
    original_size_bytes: int = 0
    preview_size_bytes: int = 0


class ToolResultSection(msgspec.Struct, omit_defaults=True):
    title: str
    body: str


class InformationalDisplay(msgspec.Struct, omit_defaults=True):
    """Canonical display model for informational events (INFO, THINKING, STUCK_LOOP, etc.).

    Consumed by both Rich and Textual backends via a unified rendering path.
    """

    message: str
    severity: Literal["info", "warning", "error", "success", "debug", "thought"]
    sections: list[ToolResultSection] = msgspec.field(default_factory=list)


def map_event_to_informational_display(
    kind: object, info: str = "", thought: str = "", severity: str | None = None
) -> InformationalDisplay | None:
    """Map an agent event to a standardized InformationalDisplay.

    Accepts duck-typed parameters (kind, info, thought, severity) to avoid
    circular imports with kiss.core.events. Returns None for event kinds that
    do not produce informational output.
    """
    kind_name = getattr(kind, "name", str(kind))
    if kind_name == "THINKING":
        return InformationalDisplay(message=thought, severity="thought")
    if kind_name == "INFO":
        return InformationalDisplay(message=info, severity="info")
    if kind_name == "STUCK_LOOP":
        sev = "error" if severity == "error" else "warning"
        return InformationalDisplay(message=info, severity=sev)
    return None


# ── Notification & Interaction utilities ───────────────────────────────────────


def notify_user(header: str, body: str, *, enabled: bool = True) -> None:
    """Emit audible/OSC attention-capture sequences.

    Backends MUST pass ``settings.notify_enabled`` as the ``enabled`` kwarg.
    """
    if not enabled:
        return
    # BEL character for audible alert
    print("\x07", end="", flush=True)
    # OSC 9 (iTerm2 / GNOME Terminal)
    print(f"\x1b]9;{header}\x07", end="", flush=True)
    # OSC 777 (rxvt-unicode / some VTE terminals)
    print(f"\x1b]777;notify;{header};{body}\x1b\\", end="", flush=True)


class InteractionController:
    """Cleanup registry for pending ASK_USER interactions.

    Each UI backend instantiates one controller.  It tracks pending
    ``reply_future`` references keyed by ``interaction_id`` so they can be
    deterministically cancelled on session exit.  It does NOT track selection
    state, handle keybindings, or implement concurrency guards.
    """

    def __init__(self) -> None:
        self._pending: dict[str, AskUserRequest] = {}

    def register(self, req: AskUserRequest) -> None:
        """Register an interaction for cleanup tracking."""
        self._pending[req.interaction_id] = req

    def deregister(self, req: AskUserRequest) -> None:
        """Remove an interaction from the cleanup registry."""
        self._pending.pop(req.interaction_id, None)

    def cancel_all(self) -> None:
        """Cancel every pending interaction's reply_future."""
        for req in list(self._pending.values()):
            if not req.reply_future.done():
                req.reply_future.cancel()
        self._pending.clear()


VisibilityProfile = Literal["compact", "verbose"]


class ToolInteractionMeta(msgspec.Struct, omit_defaults=True):
    """Canonical interaction metadata for tool-output surfaces.

    Attached to ToolResultDisplay so backends drive expandability cues and
    detail replay from structured metadata rather than parsing rendered strings.

    activity_id   — canonical grouped-interaction id (act-NNNN format);
                    keyed against ObservabilityState.chat_activity via GroupActivityTracker
    visibility_profile — compact (default summary-first) or verbose (expanded detail-first)
    is_expandable — True when underlying detail is available for /detail replay
    detail_hint   — short guidance string rendered in compact summaries
    detail_command — the exact /detail command string for this activity
    is_expired    — True when the backing detail has been evicted from the session buffer
    """

    activity_id: str
    visibility_profile: VisibilityProfile = "compact"
    is_expandable: bool = False
    detail_hint: str | None = None
    detail_command: str | None = None
    is_expired: bool = False


class ToolResultDisplay(msgspec.Struct, omit_defaults=True):
    """Backend-neutral display model for tool results.

    Canonical representation consumed by both Rich and Textual.
    Typed renderers in renderers.py populate this from structured result types.
    create_tool_result_display() is the generic fallback for unregistered tools.
    """

    title: str
    summary: str
    status: str = "ok"
    sections: list[ToolResultSection] = msgspec.field(default_factory=list)
    # Structured truncation metadata; None when the result was not truncated.
    truncation_meta: TruncationMeta | None = None
    # File changes surfaced directly so backends do not need to re-derive them.
    file_changes: list[FileChange] = msgspec.field(default_factory=list)
    # Canonical tool-output interaction metadata; None when not part of a group.
    interaction: ToolInteractionMeta | None = None


# ── Banner rendering ──────────────────────────────────────────────────────────


def render_startup_banner(
    model_label: str,
    context_window: int,
    version: str = "0.1.0",
) -> str:
    """Return the shared startup banner with ASCII art and recommendations.

    Uses Rich markup compatible with both backends.
    """
    from rich.markup import escape

    # ASCII art 'kiss'
    logo = [
        " __  __     __     ______     ______    ",
        "/\\ \\/ /    /\\ \\   /\\  ___\\   /\\  ___\\   ",
        '\\ \\  _"-.  \\ \\ \\  \\ \\___  \\  \\ \\___  \\  ',
        " \\ \\_\\ \\_\\  \\ \\_\\  \\/\\_____\\  \\/\\_____\\ ",
        "  \\/_/\\/_/   \\/_/   \\/_____/   \\/_____/ ",
    ]

    model_short = model_label.split(":", 1)[-1] if ":" in model_label else model_label
    ctx_str = f"{context_window:,}"

    # Build the header block with logo and metadata
    lines = [
        f" [ui.text.accent]{escape(logo[0])}[/]  [bold]kiss-agent[/] [dim]v{version}[/]",
        f" [ui.text.accent]{escape(logo[1])}[/]  [ui.text.muted]model:[/]    [cyan]{model_short}[/]",
        f" [ui.text.accent]{escape(logo[2])}[/]  [ui.text.muted]context:[/]  [dim]{ctx_str} tokens[/]",
        f" [ui.text.accent]{escape(logo[3])}[/]  [ui.text.muted]status:[/]   [ui.text.success]ready[/]",
        f" [ui.text.accent]{escape(logo[4])}[/]",
        "",
        " [ui.text.accent]─ Get Started ────────────────────────────────────────────────[/]",
        " [dim]•[/] [bold]/help[/]      show all commands",
        " [dim]•[/] [bold]/model[/]     switch model or provider",
        " [dim]•[/] [bold]/resume[/]    restore your last session",
        " [ui.text.accent]──────────────────────────────────────────────────────────────[/]",
    ]
    return "\n".join(lines)


# ── Utility functions ────────────────────────────────────────────────────────


def count_diff_lines(path: str) -> tuple[int, int]:
    """Return (added, removed) line counts for path via git diff. Best-effort."""
    for cmd in (
        ["git", "diff", "--numstat", "HEAD", "--", path],
        ["git", "diff", "--numstat", "--cached", "--", path],
    ):
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=2)  # nosec B603
            out = result.stdout.strip()
            if out:
                parts = out.split("\t", 2)
                if len(parts) >= 2 and parts[0].isdigit() and parts[1].isdigit():
                    return int(parts[0]), int(parts[1])
        except Exception:  # nosec B110
            pass
    # New untracked file — count its lines as additions
    try:
        added = Path(path).read_text(encoding="utf-8", errors="replace").count("\n") + 1
        return added, 0
    except Exception:
        return 0, 0


def describe_exception(error: BaseException) -> str:
    """Return a compact exception summary with any wrapped cause chain."""
    parts: list[str] = []
    seen: set[int] = set()
    current: BaseException | None = error

    while current is not None and id(current) not in seen:
        seen.add(id(current))
        message = str(current).strip()
        label = type(current).__name__
        if message:
            parts.append(f"{label}: {message}")
        else:
            parts.append(label)
        current = current.__cause__ or current.__context__

    return " -> ".join(parts)


def classify_auth_error(error: BaseException) -> tuple[str, str] | None:
    """Return (title, body) for recognized auth/connection errors, None otherwise.

    Both backends use this to render structured error panels instead of generic text.
    """
    message = describe_exception(error)
    lowered = message.lower()

    if "connection error" in lowered or "connecterror" in lowered:
        return (
            "Connection error",
            "Copilot API unreachable — check network, proxy settings, or GitHub Copilot status.\n"
            f"Details: {message}",
        )

    if "codex" in lowered and (
        "oauth tokens not found" in lowered
        or "token unavailable" in lowered
        or "token refresh failed" in lowered
    ):
        return (
            "Authentication error",
            "Codex authentication failed. Use [bold]/model[/bold] to re-select and re-authenticate.\n"
            f"Details: {message}",
        )

    if "copilot" in lowered and (
        "oauth token not found" in lowered
        or "token unavailable" in lowered
        or "token exchange failed" in lowered
        or "connection failed" in lowered
    ):
        if "connection failed" in lowered:
            body = "Copilot API unreachable — check network or GitHub Copilot status.\n"
            title = "Connection error"
        else:
            body = "Copilot authentication failed. Use [bold]/model[/bold] to re-select and re-authenticate.\n"
            title = "Authentication error"
        return (title, body + f"Details: {message}")

    return None


def create_token_budget(raw: dict[str, int]) -> list[TokenBudgetEntry]:
    """Convert a role→tokens dict into a sorted TokenBudgetEntry list."""
    total = sum(raw.values()) or 1
    return [
        TokenBudgetEntry(label=label, tokens=raw[label], pct=raw[label] * 100 // total)
        for label in _BUDGET_ORDER
        if label in raw
    ]


# ── Tool call formatting ─────────────────────────────────────────────────────

import ast as _ast  # noqa: E402 — stdlib, kept local to avoid polluting namespace

_MAX_ARG_LEN = 60

# Maps tool name → the single arg key most worth showing to the user.
_KEY_ARG: dict[str, str] = {
    "read_file": "path",
    "write_file": "path",
    "edit_file": "path",
    "run_bash": "command",
    "run_python": "code",
    "search_code": "pattern",
    "glob": "pattern",
    "list_directory": "directory",
}


def format_tool_call(name: str, raw_args: str) -> str:
    """Return a compact 'tool_name: key_value' string for UI display."""
    key = _KEY_ARG.get(name)
    if key:
        try:
            args = _ast.literal_eval(raw_args)
            val = str(args.get(key, ""))
            val = val[:_MAX_ARG_LEN] + "…" if len(val) > _MAX_ARG_LEN else val
            return f"{name}: {val}"
        except Exception:  # nosec B110
            pass
    truncated = (
        raw_args[:_MAX_ARG_LEN] + "…" if len(raw_args) > _MAX_ARG_LEN else raw_args
    )
    return f"{name}({truncated})"


def create_tool_result_display(
    name: str,
    output: str,
    *,
    is_err: bool = False,
    path: str | None = None,
) -> ToolResultDisplay:
    """Generic fallback display for tools without typed renderers."""
    if is_err:
        return ToolResultDisplay(
            title=_tool_title(name),
            summary=_first_line(output),
            status="error",
        )
    summary = _first_line(output) if output.strip() else "completed"
    display = ToolResultDisplay(title=_tool_title(name), summary=summary, status="ok")
    if path is not None:
        display.file_changes = [FileChange(path=path)]
    return display


def format_file_operation(result: FileOperationResult) -> ToolResultDisplay:
    """Convert canonical FileOperationResult into a backend-neutral display model.

    Summary line always includes operation verb + target path.
    Compact diff stats (+N -M) are appended when available from tool metadata.
    Diff/patch details go into optional sections — backends render them as
    inline content (Rich) or collapsible detail (Textual).
    Fallback: if diff is missing, verb+path still renders without stats.
    """
    verb = _FILE_OP_VERB[result.operation]
    if result.operation == "move":
        src = result.from_path or result.path
        dst = result.to_path or result.path
        path_part = f"{src} → {dst}"
    else:
        path_part = result.path

    summary = f"{verb} {path_part}"

    if result.added_lines is not None and result.removed_lines is not None:
        summary += f"  +{result.added_lines} -{result.removed_lines}"
    elif result.added_lines is not None:
        summary += f"  +{result.added_lines}"

    sections: list[ToolResultSection] = []
    if result.diff_preview:
        sections.append(ToolResultSection("Diff", result.diff_preview))
    elif result.structured_patch:
        sections.append(ToolResultSection("Patch", result.structured_patch))
    if result.diagnostics:
        sections.append(ToolResultSection("Diagnostics", result.diagnostics))

    filename = Path(result.path).name if result.path else result.path
    title = f"{verb} {filename}" if filename else verb
    return ToolResultDisplay(title=title, summary=summary, sections=sections)


_FILE_OP_VERB: dict[str, str] = {
    "create": "Created",
    "modify": "Edited",
    "patch": "Patched",
    "delete": "Deleted",
    "move": "Moved",
}


def normalize_write_file_result(
    path: str,
    created: bool,
    line_count: int,
    diff_preview: str | None = None,
) -> FileOperationResult:
    """Produce a FileOperationResult from write_file tool output.

    created=True → 'create' operation; line_count is all-additions for new file.
    created=False → 'modify' operation; no line diff available without re-read.
    """
    operation: FileOperationKind = "create" if created else "modify"
    added = line_count if created else None
    return FileOperationResult(
        operation=operation,
        path=path,
        added_lines=added,
        removed_lines=0 if created else None,
        diff_preview=diff_preview,
    )


def normalize_edit_file_result(
    path: str,
    diff_preview: str | None = None,
    diagnostics: str | None = None,
) -> FileOperationResult:
    """Produce a FileOperationResult from edit_file / apply_patch tool output.

    edit_file uses hunk-range search/replace semantics → 'patch' operation.
    No deterministic line counts without re-reading; added/removed left None.
    """
    return FileOperationResult(
        operation="patch",
        path=path,
        diff_preview=diff_preview,
        diagnostics=diagnostics,
    )


def format_tool_result(display: ToolResultDisplay) -> str:
    lines = [display.summary]
    for section in display.sections:
        lines.append("")
        lines.append(f"{section.title}:")
        lines.append(section.body.rstrip())
    return "\n".join(lines).rstrip()


def _tool_title(name: str) -> str:
    return name.replace("_", " ").title()


def _first_line(text: str) -> str:
    return text.strip().splitlines()[0] if text.strip() else ""
