"""Grouped tool activity tracker for terminal UI backends.

Tracks repeated tool calls and collapses them into group summaries.
Each group gets a stable activity_id (e.g. act-0001) backends can reference
for detail replay via /detail <activity-id>.

Group detail is backed by the ChatActivityBuffer (bounded ring buffer).
When the buffer evicts entries the group expires; /detail returns a
readable "activity detail expired" message in that case.

Tools subject to grouping (repeated iterative flows):
  read_file, search_code, glob, list_directory, run_bash
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

from kiss.ui.observability import ChatActivityBuffer, ChatActivityEntry


_GROUPABLE_TOOLS = frozenset(
    {"read_file", "search_code", "glob", "list_directory", "run_bash"}
)
_GROUP_THRESHOLD = 3  # consecutive calls before collapsing into a group

# Legacy grp- prefix accepted as a transitional alias.
_LEGACY_PREFIX = "grp-"
_CANONICAL_PREFIX = "act-"


def _now() -> str:
    return datetime.now(tz=timezone.utc).isoformat()


def _next_activity_id(counter: list[int]) -> str:
    counter[0] += 1
    return f"{_CANONICAL_PREFIX}{counter[0]:04d}"


def _normalize_activity_id(raw: str) -> tuple[str, bool]:
    """Return (canonical_id, is_legacy) for a raw /detail argument.

    Legacy grp-NNNN values are accepted as transitional aliases and mapped
    to the same lookup key so callers do not need to know the old format.
    """
    if raw.startswith(_LEGACY_PREFIX):
        return raw, True
    return raw, False


@dataclass
class GroupSummary:
    activity_id: str
    tool_name: str
    call_count: int
    first_label: str
    last_label: str
    timestamp: str = field(default_factory=_now)

    def render_rich(self) -> str:
        return (
            f"[dim]{self.call_count}× {self.tool_name}[/dim]  "
            f"[dim italic][{self.activity_id}][/dim italic]  "
            f"[dim]{self.first_label} … {self.last_label}[/dim]"
        )


class GroupActivityTracker:
    """Tracks consecutive repeated tool calls and collapses them into groups.

    Call on_tool_call() for each TOOL_CALL event.
    Call on_tool_result() for each TOOL_RESULT event.
    Call flush() at DONE or start-of-new-tool to emit any pending group.

    on_tool_call returns a GroupSummary when a group was just completed
    (threshold crossed or tool changed), otherwise None.
    """

    def __init__(self, buffer: ChatActivityBuffer) -> None:
        self._buffer = buffer
        self._counter: list[int] = [0]
        self._current_tool: str | None = None
        self._current_activity_id: str | None = None
        self._pending_calls: list[tuple[str, str]] = []  # (call_id, label)

    def on_tool_call(
        self, tool_name: str, call_id: str, label: str
    ) -> GroupSummary | None:
        """Record a tool call. Returns a completed GroupSummary when a group closes."""
        summary: GroupSummary | None = None

        if tool_name not in _GROUPABLE_TOOLS:
            # Non-groupable: flush any pending group first
            summary = self._flush_if_pending()
            self._current_tool = None
            self._current_activity_id = None
            self._pending_calls = []
            return summary

        if self._current_tool != tool_name:
            # Tool changed: flush pending group for previous tool
            summary = self._flush_if_pending()
            self._current_tool = tool_name
            self._current_activity_id = _next_activity_id(self._counter)
            self._pending_calls = []

        self._pending_calls.append((call_id, label))

        # Record individual entry in buffer for /detail replay
        self._buffer.append(
            ChatActivityEntry(
                timestamp=_now(),
                kind="tool_call",
                label=label,
                activity_id=self._current_activity_id,
                detail=f"{tool_name}({label})",
            )
        )

        return summary

    def on_tool_result(self, call_id: str, label: str, is_err: bool = False) -> None:
        """Record a tool result in the buffer for /detail replay."""
        activity_id = self._current_activity_id
        self._buffer.append(
            ChatActivityEntry(
                timestamp=_now(),
                kind="tool_result",
                label=label,
                activity_id=activity_id,
                detail=("error: " if is_err else "") + label,
            )
        )

    def flush(self) -> GroupSummary | None:
        """Emit a group summary for any remaining pending calls and reset."""
        summary = self._flush_if_pending()
        self._current_tool = None
        self._current_activity_id = None
        self._pending_calls = []
        return summary

    def is_grouping(self) -> bool:
        """True when enough consecutive calls have accumulated to warrant a group summary."""
        return (
            self._current_tool is not None
            and len(self._pending_calls) >= _GROUP_THRESHOLD
        )

    def _flush_if_pending(self) -> GroupSummary | None:
        if (
            self._current_tool is None
            or len(self._pending_calls) < _GROUP_THRESHOLD
            or self._current_activity_id is None
        ):
            return None

        labels = [label for _, label in self._pending_calls]
        summary = GroupSummary(
            activity_id=self._current_activity_id,
            tool_name=self._current_tool,
            call_count=len(self._pending_calls),
            first_label=labels[0] if labels else "",
            last_label=labels[-1] if labels else "",
        )

        self._buffer.append(
            ChatActivityEntry(
                timestamp=_now(),
                kind="group_summary",
                label=summary.render_rich(),
                activity_id=self._current_activity_id,
                detail=f"{len(self._pending_calls)} calls",
            )
        )

        return summary

    def get_detail(self, activity_id: str) -> list[ChatActivityEntry] | None:
        """Return buffered detail entries for an activity, or None if expired."""
        entries = self._buffer.get_by_activity(activity_id)
        if not entries:
            return None
        return [e for e in entries if e.kind in ("tool_call", "tool_result")]

    def format_detail(self, raw_id: str) -> str:
        """Return printable detail for /detail <activity-id>, or expiry message.

        Accepts canonical act-NNNN ids and legacy grp-NNNN ids as a
        transitional alias (emits one deprecation hint for legacy input).
        """
        activity_id, is_legacy = _normalize_activity_id(raw_id)
        entries = self.get_detail(activity_id)

        deprecation = (
            f"[dim](Note: '{raw_id}' uses deprecated group-id format; "
            f"use /detail <act-NNNN> going forward)[/dim]\n"
            if is_legacy
            else ""
        )

        if entries is None:
            return f"{deprecation}Activity detail for {activity_id} has expired from the session buffer."
        lines = [f"Detail for {activity_id}:"]
        for e in entries:
            prefix = "  → " if e.kind == "tool_call" else "  ✓ "
            lines.append(f"{prefix}{e.detail}")
        return deprecation + "\n".join(lines)
