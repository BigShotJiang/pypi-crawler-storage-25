"""Textual TUI application — three-panel layout: chat, sidebar, input"""

from __future__ import annotations

import asyncio
import copy
import msgspec
import textwrap
from collections.abc import Callable

from rich.markdown import Markdown as RichMarkdown
from rich.text import Text
from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical
from textual.timer import Timer
from textual.widgets import (
    Footer,
    Header,
    Input,
    Markdown,
    RichLog,
    Static,
    TabbedContent,
    TabPane,
)
from textual.widgets.markdown import MarkdownStream
from textual_autocomplete import AutoComplete, DropdownItem, TargetState

from kiss.agent.loop import KissAgent
from kiss.providers.codex_auth import load_codex_tokens
from kiss.providers.copilot_auth import clear_github_token, load_github_token
from kiss.core.settings import Settings, get_context_window
from kiss.core.types import EventKind
from kiss.ui.textual.screens.codex_auth_screen import CodexAuthScreen
from kiss.ui.textual.screens.copilot_auth_screen import CopilotAuthScreen
from kiss.ui.textual.screens.model_picker import (
    ModelPickerScreen,
    fetch_provider_models,
)
from kiss.ui.textual.widgets.ask_user_banner import AskUserBanner
from kiss.ui.textual.widgets.history_input import HistoryInput
from kiss.ui.textual.widgets.logic_approval_banner import LogicApprovalBanner
from kiss.ui.textual.widgets.permission_banner import PermissionBanner
from kiss.core.pricing import estimate_cost
from kiss.ui.shared import (
    InteractionController,
    SessionTotals,
    _MUTATING_TOOLS,
    classify_auth_error,
    create_tool_result_display,
    create_token_budget,
    describe_exception,
    format_tool_call,
    count_diff_lines,
    notify_user,
    require_event_field,
)
from kiss.ui.slash import slash_commands_for, slash_help_markup
from kiss.ui.commands import (
    connect_provider,
    get_auth_status,
    get_free_models,
    get_free_provider_status,
    get_models,
    get_provider_status,
    list_sessions,
    logout_provider,
    parse_command,
    persist_connect,
    run_clear,
    run_compact,
    run_resume,
    toggle_free_provider,
)
from kiss.ui.activity import GroupActivityTracker
from kiss.ui.fuzzy import suggest_command
from kiss.ui.observability import LogEntry, MetricSample, ObservabilityState
from kiss.ui.session_state import UISessionState
from kiss.ui.truncation_store import cleanup_expired
from kiss.ui.textual.widgets.sidebar import SidebarWidget
from kiss.ui.rich.statusbar_data import RichStatusBarData
from kiss.ui.prompt_history import workspace_history_file
from kiss.data.ui_tokens import DEFAULT_TOKENS as _T
from kiss.ui.rich.theme import build_tcss_variables as _build_tcss_vars

_TRANSCRIPT_MAX_COLS = 100


def _wrap_text(text: str, width: int) -> str:
    """Word-wrap each paragraph of text, preserving intentional line breaks"""
    result: list[str] = []
    for line in text.split("\n"):
        if line.strip():
            result.extend(textwrap.wrap(line, width=width) or [line])
        else:
            result.append("")
    return "\n".join(result)


_SLASH_CANDIDATES: list[DropdownItem] = [
    DropdownItem(cmd.name, prefix=cmd.description)
    for cmd in slash_commands_for("textual")
]

_COMPACTING_FRAMES = ("|", "/", "-", "\\")


class _SlashAutoComplete(AutoComplete):
    """AutoComplete that only activates when the input starts with '/'"""

    def get_search_string(self, target_state: TargetState) -> str:
        text = target_state.text[: target_state.cursor_position]
        return text if text.startswith("/") else ""


class KissApp(App[None]):
    """Main terminal UI for kiss-agent"""

    CSS = (
        _build_tcss_vars()
        + """

    Screen {
        layout: horizontal;
    }

    #left-area {
        width: 1fr;
        height: 100%;
    }

    #chat {
        height: 1fr;
        padding: 0 1;
    }

    #stream-preview {
        height: auto;
        display: none;
        padding: 0 1;
        border-top: solid $ui-border-default;
    }

    #thought-preview {
        height: auto;
        display: none;
        padding: 0 1;
        color: $ui-text-subtle;
    }

    #model-bar {
        height: 1;
        padding: 0 1;
        color: $ui-text-muted;
    }

    SidebarWidget {
        width: 34;
        height: 100%;
        border: solid $ui-border-default;
        padding: 0 1;
    }

    #input-bar {
        height: 3;
        border: solid $ui-border-default;
        padding: 0 1;
    }

    #input-bar:focus {
        border: solid $ui-border-active;
    }

    #input-bar.tool-running {
        border: solid $ui-status-running;
    }

    #input-bar.warning {
        border: solid $ui-text-warning;
    }

    #logs-view {
        height: 1fr;
        padding: 0 1;
    }

    #metrics-view {
        height: 1fr;
        padding: 0 1;
    }

    TabPane {
        padding: 0;
        height: 1fr;
    }

    #obs-tabs {
        height: 1fr;
    }

    #obs-tabs > ContentSwitcher {
        height: 1fr;
    }

    #chat-area {
        height: 1fr;
        border: solid $ui-border-default;
    }
    """
    )

    BINDINGS = [
        ("ctrl+c", "quit", "Quit"),
        ("ctrl+m", "model_picker", "Models"),
        ("escape", "cancel", "Cancel"),
        ("ctrl+l", "clear_chat", "Clear"),
        ("f1", "show_help", "Help"),
    ]

    def __init__(self, settings: Settings, agent: KissAgent | None = None) -> None:
        super().__init__()
        self._settings = settings
        self._agent = agent
        self._streaming = False
        self._token_buffer: list[str] = []
        self._turn_stats = SessionTotals()
        self._models_used: list[str] = []
        self._model_cache: dict[str, list[str]] = {}
        self._stream: MarkdownStream | None = None
        self._compact_timer: Timer | None = None
        self._compact_frame: int = 0
        self._compact_reason: str = ""
        self._obs = ObservabilityState()
        self._tracker = GroupActivityTracker(self._obs.chat_activity)
        self._ui_state = UISessionState()
        self._sidebar = RichStatusBarData()
        self._history_path = workspace_history_file()
        self._thought_buffer: list[str] = []
        self._current_thought_id: str | None = None
        self._current_thought_phase: str | None = None
        self._interaction_controller = InteractionController()
        self._show_thinking: bool = getattr(settings, "show_thinking", True)

    # ── Composition ────────────────────────────────────────────────────────

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal():
            with Vertical(id="left-area"):
                with TabbedContent(id="obs-tabs"):
                    with TabPane("Chat", id="tab-chat"):
                        with Vertical(id="chat-area"):
                            yield RichLog(id="chat", highlight=True, markup=True)
                            yield Static("", id="thought-preview", markup=True)
                            yield Markdown("", id="stream-preview")
                    with TabPane("Logs", id="tab-logs"):
                        yield RichLog(id="logs-view", highlight=True, markup=True)
                    with TabPane("Metrics", id="tab-metrics"):
                        yield RichLog(id="metrics-view", highlight=True, markup=True)
                yield PermissionBanner()
                yield AskUserBanner(controller=self._interaction_controller)
                yield LogicApprovalBanner()
                yield Static("", id="model-bar", markup=True)
                yield HistoryInput(
                    placeholder="Ask kiss anything…",
                    id="input-bar",
                    history_path=self._history_path,
                )
            yield SidebarWidget()
        yield Footer()
        yield _SlashAutoComplete("#input-bar", candidates=_SLASH_CANDIDATES)

    # ── Lifecycle ──────────────────────────────────────────────────────────

    def on_unmount(self) -> None:
        self._interaction_controller.cancel_all()

    def on_mount(self) -> None:
        self.query_one("#chat", RichLog).can_focus = False
        if self._agent:
            self._models_used = [self._agent.model_label]
            self._update_model_bar()
            self.query_one(SidebarWidget).set_models(self._models_used)
            self._sidebar.set_models(self._models_used)
            ctx_window = get_context_window(
                self._agent.settings.model_id,
                None,
            )
            self._sidebar.context_window = ctx_window

            from kiss.ui.shared import render_startup_banner

            self.query_one("#chat", RichLog).write(
                render_startup_banner(self._agent.model_label, ctx_window)
            )

        if self._needs_codex_auth():
            self.push_screen(CodexAuthScreen(), self._on_codex_auth)
        elif self._copilot_provider_selected():
            asyncio.create_task(
                self._ensure_copilot_auth(
                    on_success=lambda: self._on_copilot_auth(True),
                    on_failure=lambda: self._on_copilot_auth(False),
                )
            )
        else:
            self.query_one("#input-bar", Input).focus()
        if self._settings.model:
            provider = self._settings.model.split(":", 1)[0]
            self.run_worker(self._fetch_and_cache(provider), name="init-model-cache")
        self.run_worker(self._startup_cleanup(), name="startup-cleanup")

    # ── Events ─────────────────────────────────────────────────────────────

    _QUIT_COMMANDS = {"/quit", "/exit"}

    def on_input_submitted(self, event: Input.Submitted) -> None:
        message = event.value.strip()
        if not message:
            return

        # 1. Handle active question from agent
        ask_banner = self.query_one(AskUserBanner)
        if ask_banner.is_active:
            chat = self.query_one("#chat", RichLog)
            chat.write(f"[{_T.text_accent} dim]  ↳ {message}[/]")
            ask_banner.submit(message)
            event.input.clear()
            return

        # 2. Block new input if still streaming
        if self._streaming:
            return

        event.input.clear()
        if isinstance(event.input, HistoryInput):
            event.input.remember_submission(message)

        if message.lower() in self._QUIT_COMMANDS:
            self.exit()
            return

        if message.startswith("/"):
            self._handle_command(message)
            return

        if not self._agent:
            self._show_error("no agent configured — check your settings.json")
            return

        chat = self.query_one("#chat", RichLog)
        t = Text()
        t.append("▋ ", style=f"{_T.text_accent} bold")
        t.append(_wrap_text(message, _TRANSCRIPT_MAX_COLS), style="on #0d2137")
        chat.write(t)

        self._streaming = True
        event.input.disabled = True
        self._token_buffer.clear()
        self._update_model_bar(streaming=True)
        self.run_worker(self._consume_events(message), exclusive=True)

    # ── Actions ────────────────────────────────────────────────────────────

    def action_model_picker(self) -> None:
        if self._streaming:
            return
        free_only = any(self._settings.free_providers.values())
        self.push_screen(
            ModelPickerScreen(
                self._settings,
                self._settings.model,
                cache=self._model_cache,
                free_only=free_only,
            ),
            self._on_model_selected,
        )

    def action_cancel(self) -> None:
        if self._agent:
            self._agent.cancel()

    def action_clear_chat(self) -> None:
        if not self._streaming:
            self._handle_command("/clear")

    def action_show_help(self) -> None:
        self._handle_command("/help")

    def _handle_command(self, raw: str) -> None:
        name, args = parse_command(raw)
        chat = self.query_one("#chat", RichLog)

        if name == "/clear":
            chat.clear()
            self._turn_stats = SessionTotals()
            self._models_used = [self._agent.model_label] if self._agent else []
            if self._agent:
                run_clear(self._agent)
            self.query_one(SidebarWidget).clear_session()
            if self._agent:
                self._update_model_bar()
                self.query_one(SidebarWidget).set_models(self._models_used)
            return

        if name == "/think":
            self._show_thinking = not self._show_thinking
            if self._agent is not None:
                self._agent.settings = msgspec.structs.replace(
                    self._agent.settings, show_thinking=self._show_thinking
                )
            self._settings = msgspec.structs.replace(
                self._settings, show_thinking=self._show_thinking
            )
            state = "on" if self._show_thinking else "off"
            chat.write(f"[dim]Thinking display {state}.[/]")
            return

        if name == "/help":
            chat.write(Text.from_markup(slash_help_markup("textual")))
            return

        if self._agent is None:
            self._show_error("no agent configured — check your settings.json")
            return

        if name == "/model":
            if not args:
                free_active = any(self._agent.settings.free_providers.values())
                if free_active:
                    free_models = get_free_models(self._agent)
                    if free_models:
                        chat.write("[dim]Free mode — available models:[/]")
                        for m in free_models:
                            marker = "[green]●[/] " if m.active else "  "
                            chat.write(f"{marker}{m.model_id}")
                    else:
                        chat.write(
                            "[dim]Free mode active but no free models available. "
                            "Use [bold]/free[/bold] to configure providers.[/]"
                        )
                else:
                    window = get_context_window(
                        self._agent.settings.model_id,
                        None,
                    )
                    chat.write(
                        f"Current model: [{_T.text_accent}]{self._agent.settings.model}[/]  "
                        f"context: [dim]{window:,} tokens[/]"
                    )
                return
            self._on_model_selected(args[0])
            return

        if name == "/free":
            if args:
                try:
                    new_state = toggle_free_provider(self._agent, args[0])
                    state_str = "enabled" if new_state else "disabled"
                    chat.write(
                        Text.from_markup(
                            f"[green]{args[0]}[/] free models: [bold]{state_str}[/]"
                        )
                    )
                except KeyError:
                    chat.write(
                        Text.from_markup(
                            f"[red]Provider '{args[0]}' not found or has no free models.[/]"
                        )
                    )
            else:
                rows = get_free_provider_status(self._agent)
                if not rows:
                    chat.write(
                        Text.from_markup("[dim]No providers with free models found.[/]")
                    )
                else:
                    for r in rows:
                        enabled_str = "[✓]" if r.enabled else "[ ]"
                        auth_str = "🔑" if r.ready else "⚠"
                        chat.write(
                            f"{enabled_str} {r.display_name}  "
                            f"[dim]{r.free_model_count} free model(s)[/]  {auth_str}"
                        )
                    chat.write(Text.from_markup("[dim]Toggle with /free <provider>[/]"))
            return

        if name == "/providers":
            statuses = get_provider_status(self._agent)
            auth_by_name = {s.name: s for s in get_auth_status(self._agent)}
            for s in statuses:
                if s.active:
                    marker = "[green]●[/green] "
                elif not s.ready:
                    marker = "[red]✗[/red] "
                else:
                    marker = "  "
                auth = auth_by_name.get(s.alias)
                auth_type = auth.auth_type if auth else ""
                auth_str = "[green]✓[/green]" if s.ready else "[red]✗[/red]"
                health_str = {
                    "healthy": "[green]healthy[/green]",
                    "degraded": "[yellow]degraded[/yellow]",
                    "unhealthy": "[red]unhealthy[/red]",
                }.get(s.health, "")
                active_tag = " [cyan](active)[/cyan]" if s.active else ""
                chat.write(
                    Text.from_markup(
                        f"{marker}[bold]{s.alias}[/bold]{active_tag}  "
                        f"[dim]{auth_type}[/dim]  {auth_str}  {health_str}"
                    )
                )
            return

        if name == "/connect":
            from kiss.ui.textual.screens.provider_picker import ProviderPickerScreen

            statuses = get_auth_status(self._agent)
            if not statuses:
                chat.write(Text.from_markup("[dim]No providers registered.[/]"))
                return

            def _on_connect_pick(target: str | None) -> None:
                if target is None:
                    return
                chat.write(Text.from_markup(f"[dim]Connecting to {target}…[/]"))
                self.run_worker(
                    self._run_connect(target),
                    name=f"connect-{target}",
                )

            self.push_screen(ProviderPickerScreen(statuses), _on_connect_pick)
            return

        if name == "/logout":
            from kiss.ui.textual.screens.provider_picker import LogoutPickerScreen

            statuses = [s for s in get_auth_status(self._agent) if s.ready]
            if not statuses:
                chat.write(
                    Text.from_markup(
                        "[dim]No authenticated providers to log out of.[/]"
                    )
                )
                return

            def _on_logout_pick(target: str | None) -> None:
                if target is None:
                    return
                logout_provider(target)
                chat.write(
                    Text.from_markup(f"[green]Credentials removed for {target}.[/]")
                )
                chat.write(Text.from_markup("[dim]Run /connect to re-authenticate.[/]"))

            self.push_screen(LogoutPickerScreen(statuses), _on_logout_pick)
            return

        if name == "/resume":
            if args and args[0] == "list":
                sessions = list_sessions(self._agent)
                if sessions:
                    for s in sessions:
                        chat.write(f"  {s.uuid[:8]}…  {s.ts}")
                    chat.write("Use /resume <uuid> to restore.")
                else:
                    chat.write(
                        Text.from_markup("[yellow]No saved sessions found.[/yellow]")
                    )
            else:
                uuid = args[0] if args else None
                ts = run_resume(self._agent, uuid=uuid)
                if ts:
                    chat.write(f"Session restored from {ts}.")
                else:
                    chat.write(
                        Text.from_markup("[yellow]No saved session found.[/yellow]")
                    )
            return

        if name == "/compact":
            self.run_worker(self._run_compact(), name="compact")
            return

        if name == "/detail":
            if not args:
                chat.write(
                    Text.from_markup("[yellow]Usage: /detail <activity-id>[/yellow]")
                )
                return
            detail = self._tracker.format_detail(args[0])
            chat.write(Text(detail, style="dim"))
            return

        known = [cmd.name for cmd in slash_commands_for("textual")]
        suggestion = suggest_command(name, known)
        if suggestion:
            self._show_error(f"unknown command {name!r} — did you mean {suggestion}?")
        else:
            self._show_error(f"unknown command {name!r} — type /help for commands")

    async def _run_connect(self, target: str) -> None:
        if self._agent is None:
            return
        chat = self.query_one("#chat", RichLog)

        def _on_event(event_type: str, data: dict) -> None:
            if event_type == "opening_browser":
                chat.write(
                    Text.from_markup(
                        f"[dim]Opening browser… or visit: {data.get('url', '')}[/]"
                    )
                )
            elif event_type == "waiting_for_input":
                chat.write(
                    Text.from_markup(
                        f"Visit [bold]{data.get('verification_uri', '')}[/bold] "
                        f"and enter code: [bold yellow]{data.get('user_code', '')}[/bold yellow]"
                    )
                )

        try:
            credential = await connect_provider(self._agent, target, on_event=_on_event)
        except KeyError:
            chat.write(Text.from_markup(f"[red]Provider '{target}' not found.[/]"))
            return
        except Exception as exc:
            chat.write(Text.from_markup(f"[red]Auth error:[/] {exc}"))
            return

        if credential is None:
            chat.write(
                Text.from_markup(
                    f"[yellow]{target} requires an API key. "
                    f"Set the relevant environment variable or run /connect {target} "
                    f"with keyring support.[/]"
                )
            )
            return

        persist_connect(target, credential)
        chat.write(Text.from_markup(f"[green]✓ Connected to {target}.[/]"))

    async def _show_models(self, provider: str) -> None:
        if self._agent is None:
            return
        chat = self.query_one("#chat", RichLog)
        model_list = await get_models(self._agent, provider)
        if not model_list:
            chat.write(f"No models found for {provider!r}")
            return
        for m in model_list:
            marker = "* " if m.active else "  "
            source = "" if m.from_config else " (live)"
            chat.write(f"{marker}{m.model_id}{source}")

    async def _run_compact(self) -> None:
        if self._agent is None:
            return
        chat = self.query_one("#chat", RichLog)
        async for event in run_compact(self._agent):
            if event.kind == EventKind.COMPACTING:
                chat.write(f"[{_T.text_subtle}]  ℹ {event.info}[/]")
            elif event.kind == EventKind.COMPACTED:
                chat.write(f"[{_T.text_subtle}]  ℹ {event.info}[/]")
            elif event.kind == EventKind.INFO:
                chat.write(f"[yellow]  ⚠ {event.info}[/yellow]")
            elif event.kind == EventKind.ERROR:
                self._show_error(
                    describe_exception(event.error) if event.error else "compact failed"
                )

    async def _startup_cleanup(self) -> None:
        await asyncio.to_thread(cleanup_expired)

    def _append_log(self, level: str, message: str) -> None:
        from datetime import datetime, timezone

        ts = datetime.now(tz=timezone.utc).strftime("%H:%M:%S")
        self._obs.logs.append(LogEntry(timestamp=ts, level=level, message=message))
        try:
            logs_view = self.query_one("#logs-view", RichLog)
            logs_view.write(f"[dim]{ts}[/dim] [{level}] {message}")
        except Exception:  # nosec B110 — view may not exist yet
            pass

    def _record_metric(self, key: str, value: float) -> None:
        from datetime import datetime, timezone

        ts = datetime.now(tz=timezone.utc).strftime("%H:%M:%S")
        self._obs.metrics.record(MetricSample(timestamp=ts, key=key, value=value))
        try:
            metrics_view = self.query_one("#metrics-view", RichLog)
            metrics_view.write(f"[dim]{ts}[/dim] {key}: {value:.2f}")
        except Exception:  # nosec B110
            pass

    # ── Auth callbacks ─────────────────────────────────────────────────────

    def _needs_codex_auth(self) -> bool:
        if not self._settings.model:
            return False
        provider_name = self._settings.model.split(":", 1)[0]
        if provider_name == "openai-codex":
            return load_codex_tokens() is None
        if provider_name == "openai":
            from kiss.providers.auth import provider_is_ready

            return not provider_is_ready(provider_name)
        return False

    def _copilot_provider_selected(self) -> bool:
        if not self._settings.model:
            return False
        provider_name = self._settings.model.split(":", 1)[0]
        return provider_name == "copilot"

    async def _copilot_auth_required(self) -> bool:
        if not load_github_token():
            return True
        from kiss.providers.manager import probe_copilot_token

        try:
            await probe_copilot_token()
        except Exception as exc:
            message = describe_exception(exc).lower()
            if "401" not in message:
                self._show_error(
                    f"Copilot token check failed: {describe_exception(exc)}"
                )
                return False
            clear_github_token()
            return True
        return False

    async def _ensure_copilot_auth(
        self,
        *,
        on_success: Callable[[], None],
        on_failure: Callable[[], None],
    ) -> None:
        if not self._copilot_provider_selected():
            on_success()
            return
        if await self._copilot_auth_required():
            self.push_screen(
                CopilotAuthScreen(),
                lambda success: on_success() if success else on_failure(),
            )
            return
        on_success()

    def _on_codex_auth(self, success: bool | None) -> None:
        if not success:
            self._show_error(
                "Codex authentication cancelled — select a model to try again"
            )
        elif not self._agent:
            asyncio.create_task(self._create_agent_async())
        self.query_one("#input-bar", Input).focus()

    def _on_copilot_auth(self, success: bool | None) -> None:
        if not success:
            self._show_error(
                "Copilot authentication cancelled — select a model to try again"
            )
        elif not self._agent:
            asyncio.create_task(self._create_agent_async())
        self.query_one("#input-bar", Input).focus()

    async def _create_agent_async(self) -> None:
        """Create agent asynchronously."""
        try:
            self._agent = await KissAgent.create(self._settings)
            self._update_model_usage(self._agent.model_label)
        except ValueError as exc:
            self._show_error(str(exc))
        self.query_one("#input-bar", Input).focus()

    # ── Model selection callback ───────────────────────────────────────────

    def _update_model_usage(self, model: str) -> None:
        if model in self._models_used:
            self._models_used.remove(model)
        self._models_used.insert(0, model)
        self._update_model_bar()
        self.query_one(SidebarWidget).set_models(self._models_used)

    def _on_model_selected(self, model: str | None) -> None:
        if not model or not self._agent:
            self.query_one("#input-bar", Input).focus()
            return

        previous_model = self._agent.settings.model

        try:
            self._agent.switch_model(model)
        except ValueError as exc:
            self._show_error(describe_exception(exc))
            self.query_one("#input-bar", Input).focus()
            return

        self._settings = self._agent.settings
        self._update_model_usage(model)

        def _cache_new_provider() -> None:
            new_provider = model.split(":", 1)[0]
            if new_provider not in self._model_cache:
                self.run_worker(
                    self._fetch_and_cache(new_provider),
                    name=f"cache-{new_provider}",
                )

        agent = self._agent  # narrowed — we checked `not self._agent` above

        if self._needs_codex_auth():

            def _after_codex(success: bool | None) -> None:
                if not success:
                    try:
                        agent.switch_model(previous_model)
                        self._settings = agent.settings
                        self._update_model_usage(previous_model)
                    except Exception:  # nosec B110
                        pass
                    self._show_error("Codex authentication cancelled")
                else:
                    _cache_new_provider()
                self.query_one("#input-bar", Input).focus()

            self.push_screen(CodexAuthScreen(), _after_codex)
            return

        if self._copilot_provider_selected():

            def _after_copilot(success: bool | None) -> None:
                if not success:
                    try:
                        agent.switch_model(previous_model)
                        self._settings = agent.settings
                        self._update_model_usage(previous_model)
                    except Exception:  # nosec B110
                        pass
                    self._show_error("Copilot authentication cancelled")
                else:
                    _cache_new_provider()
                self.query_one("#input-bar", Input).focus()

            def _after_copilot_failure() -> None:
                _after_copilot(False)

            def _after_copilot_success() -> None:
                _cache_new_provider()
                self.query_one("#input-bar", Input).focus()

            asyncio.create_task(
                self._ensure_copilot_auth(
                    on_success=_after_copilot_success,
                    on_failure=_after_copilot_failure,
                )
            )
            return

        _cache_new_provider()
        self.query_one("#input-bar", Input).focus()

    async def _fetch_and_cache(self, provider_name: str) -> None:
        models = await fetch_provider_models(self._settings, provider_name)
        if models:
            self._model_cache[provider_name] = models

    # ── Event consumer ─────────────────────────────────────────────────────

    async def _start_stream(self) -> None:
        """Show the Markdown preview widget and start a MarkdownStream into it."""
        preview = self.query_one("#stream-preview", Markdown)
        await preview.update("")  # clear any leftover content
        preview.display = True
        self._stream = Markdown.get_stream(preview)

    async def _stop_stream(self, chat: RichLog) -> str:
        """Stop streaming, move final text to RichLog, hide the preview."""
        if self._stream is None:
            return ""
        await self._stream.stop()
        self._stream = None
        text = "".join(self._token_buffer)
        self._token_buffer.clear()
        preview = self.query_one("#stream-preview", Markdown)
        preview.display = False
        if text:
            chat.write(RichMarkdown(text))
        return text

    async def _flush_thoughts(self, chat: RichLog) -> None:
        thought_preview = self.query_one("#thought-preview", Static)
        thought_preview.display = False
        if self._thought_buffer:
            text = "".join(self._thought_buffer)
            phase = self._current_thought_phase
            phase_prefix = f"[{phase}] " if phase else ""
            chat.write(f"[{_T.text_subtle}]    {phase_prefix}Thinking: {text}[/]")
            self._thought_buffer.clear()
            self._current_thought_phase = None

    async def _consume_events(self, message: str) -> None:
        if self._agent is None:
            raise RuntimeError("_consume_events called before agent was initialized")
        chat = self.query_one("#chat", RichLog)

        async for event in self._agent.send(message):
            if event.kind == EventKind.TOKEN:
                self._clear_warning_state()
                self._token_buffer.append(event.token)
                if self._stream is None:
                    await self._flush_thoughts(chat)
                    await self._start_stream()
                if self._stream is None:
                    raise RuntimeError("_start_stream() did not initialize _stream")
                await self._stream.write(event.token)

            elif event.kind == EventKind.THINKING:
                if not self._show_thinking:
                    continue
                if self._current_thought_id != event.thought_id:
                    await self._flush_thoughts(chat)
                    self._current_thought_id = event.thought_id
                self._current_thought_phase = event.phase
                if event.thought_id is not None:
                    self._obs.thoughts.append(event.thought_id, event.thought)
                self._thought_buffer.append(event.thought)
                thought_preview = self.query_one("#thought-preview", Static)
                thought_preview.display = True
                phase = event.phase or ""
                phase_prefix = f"[{phase}] " if phase else ""
                thought_preview.update(
                    f"[{_T.text_subtle}]    {phase_prefix}Thinking: {''.join(self._thought_buffer)}[/]"
                )

            elif event.kind == EventKind.INFO:
                await self._flush_thoughts(chat)
                await self._stop_stream(chat)
                chat.write(f"[{_T.text_muted} dim]  ℹ {event.info}[/]")
                self._append_log("info", event.info)

            elif event.kind == EventKind.COMPACTING:
                await self._flush_thoughts(chat)
                await self._stop_stream(chat)
                chat.write(f"[{_T.text_muted} dim]  ℹ {event.info}[/]")
                self._compact_reason = event.info
                self._append_log("compacting", event.info)
                self._ui_state.on_compacting(event.info)
                self._start_compacting()

            elif event.kind == EventKind.COMPACTED:
                await self._flush_thoughts(chat)
                await self._stop_stream(chat)
                self._stop_compacting()
                chat.write(f"[{_T.text_muted} dim]  ℹ {event.info}[/]")
                self._compact_reason = ""
                self._append_log("info", event.info)
                self._ui_state.on_compacted()

            elif event.kind == EventKind.TOOL_CALL:
                await self._flush_thoughts(chat)
                self._clear_warning_state()
                await self._stop_stream(chat)
                call = require_event_field(event.call, "call", "TOOL_CALL")
                tool_label = format_tool_call(call.name, call.args)
                self._ui_state.on_tool_call(tool_label)
                self._show_tool_running(tool_label)
                group_summary = self._tracker.on_tool_call(
                    call.name, call.id, tool_label
                )
                if group_summary is not None:
                    hint = f"  [dim](expand: /detail {group_summary.activity_id})[/dim]"
                    chat.write(
                        f"[{_T.text_subtle}]  ⊕ {group_summary.render_rich()}{hint}[/]"
                    )
                self._append_log("info", f"⚙ {tool_label}")

            elif event.kind == EventKind.PERMISSION:
                permission = require_event_field(
                    event.permission, "permission", "PERMISSION"
                )
                self.query_one(PermissionBanner).show_request(permission)

            elif event.kind == EventKind.LOGIC_APPROVAL:
                logic_approval = require_event_field(
                    event.logic_approval, "logic_approval", "LOGIC_APPROVAL"
                )
                self.query_one(LogicApprovalBanner).show_request(logic_approval)

            elif event.kind == EventKind.ASK_USER:
                await self._flush_thoughts(chat)
                await self._stop_stream(chat)
                ask_user = require_event_field(event.ask_user, "ask_user", "ASK_USER")
                chat.write("")
                chat.write(f"[{_T.text_accent} bold]  ? Agent Question[/]")
                chat.write(f"[{_T.text_primary}]    {ask_user.question}[/]")
                chat.write("")
                self.query_one(AskUserBanner).show_request(ask_user)
                self.query_one("#input-bar", Input).disabled = False
                # show_request handles focus: ListView for choices, input bar for freetext
                notify_user(
                    ask_user.header,
                    ask_user.question,
                    enabled=self._settings.notify_enabled,
                )

            elif event.kind == EventKind.TODO_UPDATE:
                if event.todos is not None:
                    self.query_one(SidebarWidget).set_todos(event.todos)
                    self._sidebar.set_todos(event.todos)
                if event.todo_meta is not None:
                    meta = event.todo_meta
                    delta_parts: list[str] = []
                    if meta.delta and not meta.delta.is_empty():
                        if meta.delta.added:
                            delta_parts.append(
                                f"[{_T.text_success}]+{len(meta.delta.added)}[/]"
                            )
                        if meta.delta.completed:
                            delta_parts.append(
                                f"[{_T.text_success}]✓{len(meta.delta.completed)}[/]"
                            )
                        if meta.delta.reopened:
                            delta_parts.append(
                                f"[{_T.text_warning}]↺{len(meta.delta.reopened)}[/]"
                            )
                        if meta.delta.removed:
                            delta_parts.append(
                                f"[{_T.text_error}]−{len(meta.delta.removed)}[/]"
                            )
                    delta_str = "  ".join(delta_parts)
                    todo_status = (
                        f"[{_T.text_success} bold]all done[/]"
                        if meta.all_done
                        else f"[{_T.text_muted}]{meta.pending_count} pending[/]"
                    )
                    chat.write(
                        f"[{_T.text_subtle}]  ☐ todos  {delta_str}  {todo_status}[/]"
                    )

            elif event.kind == EventKind.TOOL_RESULT:
                await self._flush_thoughts(chat)
                result = require_event_field(event.result, "result", "TOOL_RESULT")
                display = result.display or create_tool_result_display(
                    result.name,
                    result.output,
                    is_err=result.is_err,
                    path=result.path,
                )
                summary = display.summary
                if result.path is not None and result.name in _MUTATING_TOOLS:
                    added, removed = await asyncio.to_thread(
                        count_diff_lines, result.path
                    )
                    self.query_one(SidebarWidget).record_file_change(
                        result.path, added, removed
                    )
                    self._sidebar.record_file_change(result.path, added, removed)
                    summary = f"{summary}  +{added} -{removed}".rstrip()
                    if display is result.display:
                        display = copy.copy(display)
                    display.summary = summary
                self._tracker.on_tool_result(
                    result.call_id,
                    summary,
                    is_err=result.is_err,
                )
                self._clear_tool_running()
                _verbose = (
                    display.interaction is not None
                    and display.interaction.visibility_profile == "verbose"
                )
                if display.status == "error":
                    chat.write(
                        f"[{_T.text_error} bold]    ! {display.title}:[/bold] {display.summary}[/]"
                    )
                elif _verbose:
                    chat.write(
                        f"[{_T.text_subtle}]    {display.title}:[/] [{_T.text_muted}]{display.summary}[/]"
                    )
                else:
                    tr = Text()
                    tr.append("    ")
                    tr.append(display.title, style=_T.text_subtle)
                    tr.append("  ")
                    tr.append(display.summary, style=_T.text_muted)
                    tr.append("  ✓", style=_T.text_success)
                    chat.write(tr)

            elif event.kind == EventKind.DEGRADED:
                await self._flush_thoughts(chat)
                await self._stop_stream(chat)
                chat.write(
                    Text.from_markup(
                        f"[bold red]DEGRADED: ALL PROVIDERS UNHEALTHY[/bold red]\n{event.info}"
                    )
                )
                self._show_warning_state("DEGRADED: ALL PROVIDERS UNHEALTHY")

            elif event.kind == EventKind.STUCK_LOOP:
                await self._flush_thoughts(chat)
                await self._stop_stream(chat)
                self._clear_tool_running()
                if event.severity == "error":
                    self._ui_state.on_error(event.info)
                    chat.write(f"[{_T.text_error} bold]  ! {event.info}[/]")
                else:
                    self._ui_state.on_warning(event.info)
                    self._show_warning_state(event.info)
                    chat.write(f"[{_T.text_warning}]  ⚠ {event.info}[/]")

            elif event.kind == EventKind.DONE:
                await self._flush_thoughts(chat)
                await self._stop_stream(chat)
                final_group = self._tracker.flush()
                if final_group is not None:
                    hint = f"  [dim](expand: /detail {final_group.activity_id})[/dim]"
                    chat.write(
                        f"[{_T.text_subtle}]  ⊕ {final_group.render_rich()}{hint}[/]"
                    )
                finish_reason = self._turn_stats.accumulate(event.turn_usage)
                context_window = get_context_window(
                    self._agent.settings.model_id,
                    None,
                )
                _model_id = (
                    self._agent.model_label.split(":", 1)[-1]
                    if ":" in self._agent.model_label
                    else self._agent.model_label
                )
                cost = (
                    estimate_cost(
                        _model_id,
                        self._turn_stats.input_tokens,
                        self._turn_stats.output_tokens,
                        self._turn_stats.cache_read_tokens,
                        self._turn_stats.cache_write_tokens,
                    )
                    or 0.0
                )
                budget = create_token_budget(
                    event.turn_usage.message_budget if event.turn_usage else {}
                )
                _ts = self._turn_stats
                self.query_one(SidebarWidget).update_session(
                    turn_count=_ts.turn_count,
                    input_tokens=_ts.input_tokens,
                    output_tokens=_ts.output_tokens,
                    cost_usd=cost,
                    token_budget=budget,
                    context_window=context_window,
                    finish_reason=finish_reason,
                    thinking_tokens=_ts.thinking_tokens,
                )
                self._sidebar.update_session(
                    turn_count=_ts.turn_count,
                    input_tokens=_ts.input_tokens,
                    output_tokens=_ts.output_tokens,
                    cost_usd=cost,
                    token_budget=budget,
                    context_window=context_window,
                    finish_reason=finish_reason,
                    thinking_tokens=_ts.thinking_tokens,
                )
                self._sidebar.set_models([self._agent.model_label])
                _tu = event.turn_usage
                self._ui_state.on_done(
                    input_tokens=_tu.input_tokens if _tu else 0,
                    output_tokens=_tu.output_tokens if _tu else 0,
                    cache_read_tokens=_tu.cache_read_tokens if _tu else 0,
                    cache_write_tokens=_tu.cache_write_tokens if _tu else 0,
                    thinking_tokens=_tu.thinking_tokens if _tu else 0,
                    cost_usd=cost,
                    context_window=context_window,
                    finish_reason=finish_reason,
                    model_label=self._agent.model_label,
                )
                self._record_metric("input_tokens", self._turn_stats.input_tokens)
                self._record_metric("output_tokens", self._turn_stats.output_tokens)
                self._record_metric("cost_usd", cost)
                self._end_turn()

            elif event.kind == EventKind.CANCELLED:
                await self._flush_thoughts(chat)
                await self._stop_stream(chat)
                self._stop_compacting()
                self._ui_state.on_cancelled()
                chat.write(f"[{_T.text_muted} dim]  ↳ cancelled[/]")
                self._end_turn()

            elif event.kind == EventKind.ERROR:
                await self._flush_thoughts(chat)
                await self._stop_stream(chat)
                self._stop_compacting()
                error = require_event_field(event.error, "error", "ERROR")
                if isinstance(error, asyncio.CancelledError):
                    self._ui_state.on_cancelled()
                    chat.write(f"[{_T.text_muted} dim]  ↳ cancelled[/]")
                else:
                    self._ui_state.on_error(describe_exception(error))
                    self._append_log("error", describe_exception(error))
                    auth_info = classify_auth_error(error)
                    if auth_info is not None:
                        title, body = auth_info
                        chat.write(
                            f"[{_T.text_error} bold]  ! {title}:[/bold] {body}[/]"
                        )
                    else:
                        self._show_error(describe_exception(error))
                self._end_turn()

    # ── Helpers ────────────────────────────────────────────────────────────

    def _write_wrapped_message(
        self, chat: RichLog, label: str, label_style: str, text: str
    ) -> None:
        content_w = chat.size.width - 4
        if content_w < 20:
            content_w = 80
        prefix_len = len(label) + 2
        wrapped = _wrap_text(text, max(20, content_w - prefix_len))
        lines = wrapped.split("\n")
        t = Text()
        t.append(label, style=label_style)
        t.append(": ")
        t.append(lines[0])
        for line in lines[1:]:
            t.append("\n" + " " * prefix_len + line)
        chat.write(t)

    def _end_turn(self) -> None:
        self._streaming = False
        self._stop_compacting()
        self._clear_tool_running()
        self._clear_warning_state()
        self._update_model_bar(streaming=False)
        input_bar = self.query_one("#input-bar", Input)
        input_bar.disabled = False
        input_bar.focus()

    def _start_compacting(self) -> None:
        if self._compact_timer is None:
            self._compact_frame = 0
            self._compact_timer = self.set_interval(0.12, self._tick_compacting)
        self._render_compacting_model_bar()

    def _stop_compacting(self) -> None:
        if self._compact_timer is not None:
            self._compact_timer.stop()
            self._compact_timer = None
            self._update_model_bar(streaming=False)

    def _tick_compacting(self) -> None:
        self._compact_frame = (self._compact_frame + 1) % len(_COMPACTING_FRAMES)
        self._render_compacting_model_bar()

    def _render_compacting_model_bar(self) -> None:
        frame = _COMPACTING_FRAMES[self._compact_frame]
        label = "compacting context…"
        style = "yellow"
        if "self-healing retry" in self._compact_reason:
            label = "retrying after overflow…"
            style = "bold red"
        elif "self-compaction requested" in self._compact_reason:
            label = "self-compacting…"
            style = "bold yellow"
        self.query_one("#model-bar", Static).update(
            f"[bold yellow]{frame}[/bold yellow] [{style}]{label}[/{style}]"
        )

    def _update_model_bar(self, streaming: bool = False) -> None:
        if not self._agent:
            return
        label = self._agent.model_label
        short = label
        ctx = (
            get_context_window(
                self._agent.settings.model_id,
                None,
            )
            or 1
        )
        pct = min(100, self._turn_stats.input_tokens * 100 // ctx)
        if pct >= 80:
            ctx_style = "bold red"
            ctx_label = f"⚠ ctx {pct}%"
        elif pct >= 60:
            ctx_style = "yellow"
            ctx_label = f"⚠ ctx {pct}%"
        else:
            ctx_style = _T.text_success
            ctx_label = f"ctx {pct}%"
        indicator = (
            "[bold cyan]●[/bold cyan] " if streaming else f"[{_T.text_subtle}]●[/] "
        )
        self.query_one("#model-bar", Static).update(
            f"{indicator}[dim]{short}[/dim]  [{ctx_style}]{ctx_label}[/{ctx_style}]"
        )

    def _show_tool_running(self, tool_label: str) -> None:
        short = tool_label[:40] + ("…" if len(tool_label) > 40 else "")
        self.query_one("#model-bar", Static).update(
            f"[{_T.status_running}]⚙[/] [{_T.status_running} dim]{short}[/]"
        )
        input_bar = self.query_one("#input-bar", Input)
        input_bar.remove_class("warning")
        input_bar.add_class("tool-running")

    def _clear_tool_running(self) -> None:
        self.query_one("#input-bar", Input).remove_class("tool-running")
        self._update_model_bar(streaming=True)

    def _show_warning_state(self, message: str) -> None:
        short = message[:50] + ("…" if len(message) > 50 else "")
        self.query_one("#model-bar", Static).update(f"[{_T.text_warning}]⚠ {short}[/]")
        input_bar = self.query_one("#input-bar", Input)
        input_bar.remove_class("tool-running")
        input_bar.add_class("warning")

    def _clear_warning_state(self) -> None:
        self.query_one("#input-bar", Input).remove_class("warning")

    def _show_error(self, message: str) -> None:
        self.query_one("#chat", RichLog).write(
            f"[{_T.text_error} bold]error[/]: {message}"
        )
