"""Logic Tool batch approval banner — shown above the input bar."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.css.query import NoMatches
from textual.widget import Widget
from textual.widgets import Button, Label

from kiss.agent.tools.logic.approval import LogicApprovalReply, LogicApprovalRequest


class LogicApprovalBanner(Widget):
    """Shows a Logic Tool batch manifest approval request above the input bar.

    Hidden by default. App calls show_request() on LOGIC_APPROVAL events.
    Resolves the asyncio.Future in the request on button press.
    """

    DEFAULT_CSS = """
    LogicApprovalBanner {
        display: none;
        height: auto;
        padding: 0;
    }

    LogicApprovalBanner #approval-label {
        width: 1fr;
        padding: 0 1;
        content-align: left middle;
    }

    LogicApprovalBanner Horizontal {
        height: auto;
        align: right middle;
    }

    LogicApprovalBanner Button {
        margin: 0 1;
    }
    """

    def __init__(self) -> None:
        super().__init__()
        self._pending: LogicApprovalRequest | None = None

    def compose(self) -> ComposeResult:
        yield Label("", id="approval-label")
        with Horizontal():
            yield Button("Apply", variant="success", id="apply")
            yield Button("Deny", variant="error", id="deny")

    def show_request(self, req: LogicApprovalRequest) -> None:
        self._pending = req
        n = len(req.pending_changes)
        previews = [f"{c.change_type}: {c.path}" for c in req.pending_changes[:3]]
        preview = ", ".join(previews)
        if n > 3:
            preview += f" (+{n - 3} more)"
        label = f"[bold]Logic Tool — {n} file change{'s' if n != 1 else ''}[/bold]: {preview}"
        self.query_one("#approval-label", Label).update(label)
        self.display = True
        self.query_one("#apply", Button).focus()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if self._pending is None:
            return
        approved = event.button.id == "apply"
        if not self._pending.reply_future.done():
            self._pending.reply_future.set_result(LogicApprovalReply(approved=approved))
        self._pending = None
        self.display = False
        try:
            self.app.query_one("#input-bar").focus()
        except NoMatches:
            pass
