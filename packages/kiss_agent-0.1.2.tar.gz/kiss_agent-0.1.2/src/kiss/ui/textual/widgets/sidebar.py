"""Sidebar widget — session stats, context usage, todo list, modified files.

Layout: SidebarWidget (border/padding) → VerticalScroll → one child widget per
section. Each section manages its own reactive state and renders independently,
so only the changed section re-renders instead of the whole panel
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any

from rich.console import Group
from rich.table import Table
from rich.text import Text
from textual.app import ComposeResult
from textual.containers import VerticalScroll
from textual.reactive import reactive
from textual.widget import Widget

from kiss.core.types import TodoItem
from kiss.ui.shared import BUDGET_COLORS, FileChange, TokenBudgetEntry
from kiss.data.ui_tokens import DEFAULT_TOKENS as _T

# Content width = sidebar width (34) - border (2) - padding (2) = 30
_W = 30


# ── Textual-specific render helpers ─────────────────────────────────────────


def _header(title: str) -> Text:
    """Section header: '─ Title ───────────────────'"""
    dashes = max(0, _W - 3 - len(title))
    return Text(f"─ {title} {'─' * dashes}", style=_T.text_accent)


def _grid(label_w: int) -> Table:
    """Two-column fixed-label grid with no borders"""
    t = Table.grid(padding=(0, 1))
    t.add_column(width=label_w, no_wrap=True)
    t.add_column(no_wrap=True)
    return t


def _stacked_bar(budget: tuple[TokenBudgetEntry, ...], width: int) -> Text:
    """Colored stacked █ bar, one segment per budget category"""
    t = Text()
    remaining = width
    for i, entry in enumerate(budget):
        chars = max(1, round(entry.pct * width / 100)) if entry.pct > 0 else 0
        if i == len(budget) - 1:
            chars = remaining  # last segment fills remainder to avoid rounding drift
        chars = max(0, min(chars, remaining))
        color = BUDGET_COLORS.get(entry.label, "white")
        t.append("█" * chars, style=color)
        remaining -= chars
    if remaining > 0:
        t.append("░" * remaining, style="dim")
    return t


# ── Section widgets ─────────────────────────────────────────────────────────


class _SessionSection(Widget):
    """Turn count, elapsed time, cost — always visible"""

    DEFAULT_CSS = "_SessionSection { height: auto; }"

    turn_count: reactive[int] = reactive(0)
    cost_usd: reactive[float] = reactive(0.0)
    finish_reason: reactive[str | None] = reactive(None)

    def __init__(self) -> None:
        super().__init__()
        self._session_start = time.monotonic()

    def on_mount(self) -> None:
        self.set_interval(1.0, self.refresh)  # keep elapsed ticking

    def render(self) -> Group:
        elapsed_s = int(time.monotonic() - self._session_start)
        h, rem = divmod(elapsed_s, 3600)
        m, s = divmod(rem, 60)
        elapsed = f"{h}:{m:02}:{s:02}" if h else f"{m}:{s:02}"
        t = _grid(7)
        t.add_row(Text("turns", style="dim"), Text(str(self.turn_count)))
        t.add_row(Text("elapsed", style="dim"), Text(elapsed))
        cost_s = f"${self.cost_usd:.4f}" if self.cost_usd else "—"
        t.add_row(Text("cost", style="dim"), Text(cost_s))
        if self.finish_reason:
            warn_style = (
                f"bold {_T.text_error}"
                if self.finish_reason == "refusal"
                else _T.text_warning
            )
            t.add_row(
                Text("warn", style="dim"), Text(self.finish_reason, style=warn_style)
            )
        return Group(_header("Session"), t)

    def clear(self) -> None:
        self.turn_count = 0
        self.cost_usd = 0.0
        self.finish_reason = None


class _ModelsSection(Widget):
    """Active models list — hidden when only one model is in use"""

    DEFAULT_CSS = "_ModelsSection { height: auto; margin-top: 1; display: none; }"

    models_used: reactive[tuple[str, ...]] = reactive(())

    def watch_models_used(self, val: tuple[str, ...]) -> None:
        self.display = len(val) > 1

    def render(self) -> Group:
        t = _grid(2)
        for i, model in enumerate(self.models_used):
            model_str = str(model)
            short = model_str.split(":", 1)[-1] if ":" in model_str else model_str
            marker = Text("●", style=_T.text_accent) if i == 0 else Text(" ")
            t.add_row(marker, Text(short[: _W - 3]))
        return Group(_header("Models"), t)


class _ContextSection(Widget):
    """Context window usage bar and token counts — always visible"""

    DEFAULT_CSS = "_ContextSection { height: auto; margin-top: 1; }"

    input_tokens: reactive[int] = reactive(0)
    output_tokens: reactive[int] = reactive(0)
    thinking_tokens: reactive[int] = reactive(0)
    context_window: reactive[int] = reactive(200_000)

    def render(self) -> Group:
        ctx = self.context_window or 1
        pct = min(100, self.input_tokens * 100 // ctx)
        filled = _W * pct // 100
        pct_style = (
            f"bold {_T.text_error}"
            if pct >= 80
            else (_T.text_warning if pct >= 60 else _T.text_success)
        )
        bar = Text("█" * filled, style=pct_style)
        bar.append("░" * (_W - filled), style="dim")
        ct = _grid(5)
        ct.add_row(Text("in", style="dim"), Text(f"{self.input_tokens:,} / {ctx:,}"))
        ct.add_row(Text("out", style="dim"), Text(f"{self.output_tokens:,}"))
        if self.thinking_tokens:
            ct.add_row(Text("think", style="dim"), Text(f"{self.thinking_tokens:,}"))
        return Group(_header("Context"), bar, ct)

    def clear(self) -> None:
        self.input_tokens = 0
        self.output_tokens = 0
        self.thinking_tokens = 0
        self.context_window = 200_000


class _BudgetSection(Widget):
    """Token budget breakdown — hidden until first turn completes"""

    DEFAULT_CSS = "_BudgetSection { height: auto; margin-top: 1; display: none; }"

    token_budget: reactive[tuple[TokenBudgetEntry, ...]] = reactive(())

    def watch_token_budget(self, val: tuple[TokenBudgetEntry, ...]) -> None:
        self.display = bool(val)

    def render(self) -> Group:
        bt = _grid(11)
        for entry in self.token_budget:
            color = BUDGET_COLORS.get(entry.label, "white")
            bt.add_row(
                Text(f"■ {entry.label}", style=color),
                Text(f"{entry.tokens:>6,}  {entry.pct:>3}%", style="dim"),
            )
        return Group(_header("Budget"), _stacked_bar(self.token_budget, _W), bt)


class _TodoSection(Widget):
    """Agent todo list — hidden when empty"""

    DEFAULT_CSS = "_TodoSection { height: auto; margin-top: 1; display: none; }"

    todos: reactive[tuple[TodoItem, ...]] = reactive(())

    def watch_todos(self, val: tuple[TodoItem, ...]) -> None:
        self.display = bool(val)

    def render(self) -> Group:
        parts: list[Any] = [_header("Todo")]
        for item in self.todos:
            icon = "✓" if item.done else "○"
            style = "dim" if item.done else ""
            row = Text(no_wrap=True, overflow="fold")
            row.append(f"{icon} {item.text[: _W - 2]}", style=style)
            parts.append(row)
        return Group(*parts)


class _FilesSection(Widget):
    """Modified files tracker — hidden until first file change"""

    DEFAULT_CSS = "_FilesSection { height: auto; margin-top: 1; display: none; }"

    file_changes: reactive[tuple[FileChange, ...]] = reactive(())

    def watch_file_changes(self, val: tuple[FileChange, ...]) -> None:
        self.display = bool(val)

    def render(self) -> Group:
        ft = _grid(14)
        for fc in self.file_changes:
            name = Path(fc.path).name[:14]
            added_s = f"+{fc.added}" if fc.added else ""
            removed_s = f"-{fc.removed}" if fc.removed else ""
            counts = f"{added_s:>4} {removed_s:>3}".rstrip()
            if added_s and removed_s:
                style = _T.text_warning
            elif added_s:
                style = _T.text_success
            else:
                style = _T.text_error
            ft.add_row(
                Text(name),
                Text(counts, style=style),
            )
        return Group(_header("Modified"), ft)


# ── Public sidebar widget ────────────────────────────────────────────────────


class SidebarWidget(Widget):
    """Sidebar panel: session stats, context usage, todos, modified files.

    Composes six independent section widgets so each section re-renders only
    when its own data changes. Scrolling is handled by the inner VerticalScroll
    """

    DEFAULT_CSS = """
    SidebarWidget > VerticalScroll {
        height: 1fr;
        background: transparent;
    }
    """

    def compose(self) -> ComposeResult:
        with VerticalScroll():
            yield _SessionSection()
            yield _ModelsSection()
            yield _ContextSection()
            yield _BudgetSection()
            yield _TodoSection()
            yield _FilesSection()

    # ── Public API ───────────────────────────────────────────────────────────

    def update_session(
        self,
        turn_count: int,
        input_tokens: int,
        output_tokens: int,
        cost_usd: float,
        token_budget: list[TokenBudgetEntry],
        context_window: int,
        finish_reason: str | None = None,
        thinking_tokens: int = 0,
    ) -> None:
        sess = self.query_one(_SessionSection)
        sess.turn_count = turn_count
        sess.cost_usd = cost_usd
        sess.finish_reason = finish_reason

        ctx = self.query_one(_ContextSection)
        ctx.input_tokens = input_tokens
        ctx.output_tokens = output_tokens
        ctx.context_window = context_window
        ctx.thinking_tokens = thinking_tokens

        self.query_one(_BudgetSection).token_budget = tuple(token_budget)

    def set_models(self, models: list[str]) -> None:
        self.query_one(_ModelsSection).models_used = tuple(models)

    def record_file_change(self, path: str, added: int, removed: int) -> None:
        section = self.query_one(_FilesSection)
        existing = {fc.path: fc for fc in section.file_changes}
        existing[path] = FileChange(path=path, added=added, removed=removed)
        section.file_changes = tuple(existing.values())

    def set_todos(self, todos: list[TodoItem]) -> None:
        self.query_one(_TodoSection).todos = tuple(todos)

    def clear_session(self) -> None:
        """Reset all session-scoped data. Elapsed timer is never reset."""
        self.query_one(_SessionSection).clear()
        self.query_one(_ContextSection).clear()
        self.query_one(_BudgetSection).token_budget = ()
        self.query_one(_ModelsSection).models_used = ()
        self.query_one(_TodoSection).todos = ()
        self.query_one(_FilesSection).file_changes = ()
