"""Textual input widget with persisted prompt history navigation."""

from __future__ import annotations

from pathlib import Path

from textual.events import Key
from textual.widgets import Input

from kiss.ui.prompt_history import append_prompt_history, load_prompt_history


class HistoryInput(Input):
    """Single-line input with deterministic previous/next history navigation."""

    def __init__(
        self,
        value: str | None = None,
        *,
        history_path: Path,
        placeholder: str = "",
        id: str | None = None,
        classes: str | None = None,
        disabled: bool = False,
    ) -> None:
        super().__init__(
            value=value,
            placeholder=placeholder,
            id=id,
            classes=classes,
            disabled=disabled,
        )
        self._history_path = history_path
        self._history: list[str] = []
        self._history_index = 0
        self._history_draft = ""

    def on_mount(self) -> None:
        self._history = load_prompt_history(self._history_path)
        self._history_index = len(self._history)

    def remember_submission(self, text: str) -> None:
        value = text.strip()
        if not value:
            return
        append_prompt_history(self._history_path, value)
        self._history.append(value)
        self._history_index = len(self._history)
        self._history_draft = ""

    def action_history_previous(self) -> None:
        if not self._history or self._history_index <= 0:
            return
        if self._history_index == len(self._history) and not self._history_draft:
            self._history_draft = self.value
        self._history_index -= 1
        self._set_history_value(self._history[self._history_index])

    def action_history_next(self) -> None:
        if not self._history or self._history_index >= len(self._history):
            return
        self._history_index += 1
        if self._history_index == len(self._history):
            self._set_history_value(self._history_draft)
            self._history_draft = ""
            return
        self._set_history_value(self._history[self._history_index])

    def _set_history_value(self, value: str) -> None:
        self.value = value
        self.cursor_position = len(self.value)

    def on_key(self, event: Key) -> None:
        if event.key == "up":
            self.action_history_previous()
            event.stop()
        elif event.key == "down":
            self.action_history_next()
            event.stop()
