"""Permission banner — strip above the input bar that toggles visibility"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.css.query import NoMatches
from textual.widget import Widget
from textual.widgets import Button, Label

from kiss.core.types import PermissionReply, PermissionRequest
from kiss.ui.shared import format_tool_call


class PermissionBanner(Widget):
    """Shows a permission request above the input bar.

    Hidden by default (display: none). Call show_request() to reveal it.
    Resolves the asyncio.Future in the PermissionRequest on button press
    """

    DEFAULT_CSS = """
    PermissionBanner {
        display: none;
        height: auto;
        padding: 0;
    }

    PermissionBanner Label {
        width: 1fr;
        padding: 0 1;
        content-align: left middle;
    }

    PermissionBanner Horizontal {
        height: auto;
        align: right middle;
    }

    PermissionBanner Button {
        margin: 0 1;
    }
    """

    def __init__(self) -> None:
        super().__init__()
        self._pending: PermissionRequest | None = None

    def compose(self) -> ComposeResult:
        yield Label("", id="permission-label")
        with Horizontal():
            yield Button("Allow once", variant="default", id="allow-once")
            yield Button("Allow command", variant="success", id="allow-cmd")
            yield Button("Allow tool", variant="primary", id="allow-tool")
            yield Button("Deny", variant="error", id="deny")

    def show_request(self, req: PermissionRequest) -> None:
        self._pending = req
        label = (
            req.args
            if req.action
            else format_tool_call(req.tool_name or "tool", req.args)
        )
        self.query_one("#permission-label", Label).update(f"[bold]{label}[/bold]")
        self.query_one("#allow-cmd", Button).label = (
            "Allow exact" if req.action else "Allow command"
        )
        allow_tool = self.query_one("#allow-tool", Button)
        allow_tool.label = "Allow scope" if req.action else "Allow tool"
        allow_tool.disabled = bool(req.action and req.action.exact_only)
        self.display = True
        self.query_one("#allow-once", Button).focus()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if self._pending is None:
            return
        match event.button.id:
            case "allow-once":
                self._pending.reply_future.set_result(PermissionReply.ALLOW)
            case "allow-cmd":
                self._pending.reply_future.set_result(PermissionReply.ALLOW_CMD)
            case "allow-tool":
                self._pending.reply_future.set_result(PermissionReply.ALLOW_TOOL)
            case "deny":
                self._pending.reply_future.set_result(PermissionReply.DENY)
        self._pending = None
        self.display = False
        try:
            self.app.query_one("#input-bar").focus()
        except NoMatches:
            pass
