"""AskUser banner — similar to PermissionBanner but for agent questions"""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.css.query import NoMatches
from textual.widget import Widget
from textual.widgets import Button, Label, ListView, ListItem

from kiss.core.types import AskUserReply, AskUserRequest
from kiss.data.ui_tokens import DEFAULT_TOKENS as _T

if TYPE_CHECKING:
    from kiss.ui.shared import InteractionController


class AskUserBanner(Widget):
    """Shows an agent question above the input bar.

    Hidden by default. App calls show_request() when ASK_USER event arrives.
    Supports plain free-text entry and selectable-choice mode when
    req.options is provided. Ctrl+T switches to free-text when the
    request type is "text" or "choice_or_text".

    Selection state is owned by this widget; cleanup is delegated to the
    passed-in InteractionController.
    """

    DEFAULT_CSS = f"""
    AskUserBanner {{
        display: none;
        height: auto;
        padding: 0;
    }}

    AskUserBanner.pulse {{
        background: {_T.text_accent} 10%;
    }}

    AskUserBanner #header-badge {{
        width: auto;
        padding: 0 1;
        color: {_T.text_accent};
        text-style: bold;
    }}

    AskUserBanner #ask-label {{
        width: 1fr;
        padding: 0 1;
        content-align: left middle;
    }}

    AskUserBanner #ask-desc {{
        width: 1fr;
        padding: 0 1;
        color: {_T.text_muted};
    }}

    AskUserBanner #ask-keys {{
        width: 1fr;
        padding: 0 1;
        color: {_T.text_muted};
    }}

    AskUserBanner #choice-list {{
        display: none;
        height: auto;
        max-height: 10;
        border: solid {_T.border_active};
        margin: 0 1;
    }}

    AskUserBanner Horizontal {{
        height: auto;
        align: right middle;
    }}

    AskUserBanner Button {{
        margin: 0 1;
    }}
    """

    def __init__(self, controller: InteractionController | None = None) -> None:
        super().__init__()
        self._controller = controller
        self._pending: AskUserRequest | None = None
        self._mode: str = "freetext"  # "select" or "freetext"
        self._choice_ids: list[str] = []
        self._selected_indices: set[int] = set()

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label("", id="header-badge")
            yield Label("", id="ask-label")
            yield Label("", id="ask-desc")
            yield Label("", id="ask-keys")
            yield ListView(id="choice-list")
        with Horizontal():
            yield Button("Cancel", variant="error", id="cancel-ask")

    @property
    def is_active(self) -> bool:
        return self._pending is not None

    def _can_freeform(self, req: AskUserRequest) -> bool:
        return req.type in ("text", "choice_or_text")

    def _build_option_label(self, opt: object, *, checked: bool = False) -> str:
        """Return a rich-text label for a QuestionOption."""
        label: str = getattr(opt, "label", str(opt))
        desc: str | None = getattr(opt, "description", None)
        parts: list[str] = [f"[bold]{label}[/bold]"]
        if desc:
            parts.append(f"\n  [dim]{desc}[/dim]")
        if checked:
            parts.insert(0, "[x] ")
        return "".join(parts)

    def show_request(self, req: AskUserRequest) -> None:
        self._pending = req
        self._choice_ids = [opt.id for opt in req.options]
        self._selected_indices = set()

        self.query_one("#header-badge", Label).update(
            f"[{_T.text_accent} bold]{req.header}[/]"
        )
        self.query_one("#ask-label", Label).update(req.question)

        desc = req.placeholder or ""
        self.query_one("#ask-desc", Label).update(f"[dim]{desc}[/]" if desc else "")

        choice_list = self.query_one("#choice-list", ListView)
        choice_list.clear()

        if self._choice_ids:
            self._mode = "select"
            for i, opt in enumerate(req.options):
                label = self._build_option_label(opt)
                choice_list.append(ListItem(Label(label)))
            choice_list.display = True
            keys = "↑↓ navigate  Enter confirm  Esc cancel"
            if self._can_freeform(req):
                keys += "  Ctrl+T free text"
            if req.multi_select:
                keys += "  Space toggle"
            self.query_one("#ask-keys", Label).update(f"[dim][{keys}][/dim]")
        else:
            self._mode = "freetext"
            choice_list.display = False
            keys = "Enter submit  Esc cancel"
            if req.placeholder:
                keys += f"  ({req.placeholder})"
            self.query_one("#ask-keys", Label).update(f"[dim][{keys}][/dim]")

        self.display = True
        self.add_class("pulse")
        self.set_timer(0.5, lambda: self.remove_class("pulse"))

        if self._controller is not None:
            self._controller.register(req)
            req.reply_future.add_done_callback(
                lambda _f: self.call_after_refresh(self._close)
            )

        if self._mode == "select":
            self.query_one("#choice-list", ListView).focus()
        else:
            self.app.query_one("#input-bar").focus()

    def on_list_view_selected(self, event: object) -> None:
        if not self._pending or self._mode != "select":
            return
        choice_list = self.query_one("#choice-list", ListView)
        idx = choice_list.index
        if idx is None:
            return
        req = self._pending
        if req.multi_select:
            # Toggle selection; do not submit on Enter for multi-select
            if idx in self._selected_indices:
                self._selected_indices.remove(idx)
            else:
                self._selected_indices.add(idx)
            self._refresh_checkboxes()
            return
        if 0 <= idx < len(self._choice_ids):
            reply = AskUserReply(
                outcome="selected", selected_choice_ids=[self._choice_ids[idx]]
            )
            self._pending.reply_future.set_result(reply)
            self._close()

    def _refresh_checkboxes(self) -> None:
        """Re-render choice list to reflect selection state."""
        choice_list = self.query_one("#choice-list", ListView)
        for i, child in enumerate(choice_list.children):
            label_widget = child.query_one(Label)
            opt = self._pending.options[i] if self._pending else None  # type: ignore[has-type]
            label = self._build_option_label(opt, checked=i in self._selected_indices)
            label_widget.update(label)

    def submit(self, answer: str) -> None:
        if not self._pending:
            return
        if self._mode == "select":
            req = self._pending
            if req.multi_select and self._selected_indices:
                ids = [self._choice_ids[i] for i in sorted(self._selected_indices)]
                reply = AskUserReply(outcome="selected", selected_choice_ids=ids)
            else:
                choice_list = self.query_one("#choice-list", ListView)
                idx = choice_list.index
                if idx is not None and 0 <= idx < len(self._choice_ids):
                    reply = AskUserReply(
                        outcome="selected", selected_choice_ids=[self._choice_ids[idx]]
                    )
                else:
                    reply = AskUserReply(outcome="free_text", text=answer)
        else:
            reply = AskUserReply.from_text(answer)
        self._pending.reply_future.set_result(reply)
        self._close()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel-ask":
            if self._pending:
                self._pending.reply_future.set_result(AskUserReply(outcome="cancelled"))
            self._close()

    def on_key(self, event: object) -> None:
        from textual.events import Key

        if not isinstance(event, Key):
            return
        req = self._pending
        if req is None:
            return
        can_freeform = self._can_freeform(req)
        if self._mode == "select" and event.key == "ctrl+t" and can_freeform:
            self._mode = "freetext"
            self.query_one("#choice-list", ListView).display = False
            self.query_one("#ask-keys", Label).update(
                "[dim][Enter submit  Esc cancel  Ctrl+T back to choices][/dim]"
            )
            self.app.query_one("#input-bar").focus()
            event.stop()
        elif self._mode == "freetext" and event.key == "ctrl+t" and self._choice_ids:
            self._mode = "select"
            choice_list = self.query_one("#choice-list", ListView)
            choice_list.display = True
            keys = "↑↓ navigate  Enter confirm  Esc cancel"
            if can_freeform:
                keys += "  Ctrl+T free text"
            if req.multi_select:
                keys += "  Space toggle"
            self.query_one("#ask-keys", Label).update(f"[dim][{keys}][/dim]")
            choice_list.focus()
            event.stop()
        elif event.key == "space" and self._mode == "select" and req.multi_select:
            choice_list = self.query_one("#choice-list", ListView)
            idx = choice_list.index
            if idx is not None:
                if idx in self._selected_indices:
                    self._selected_indices.remove(idx)
                else:
                    self._selected_indices.add(idx)
                self._refresh_checkboxes()
            event.stop()
        elif event.key == "escape":
            if self._pending:
                self._pending.reply_future.set_result(AskUserReply(outcome="cancelled"))
            self._close()
            event.stop()

    def _close(self) -> None:
        if self._pending and self._controller is not None:
            self._controller.deregister(self._pending)
        self._pending = None
        self._mode = "freetext"
        self._choice_ids = []
        self._selected_indices = set()
        self.display = False
        try:
            self.app.query_one("#input-bar").focus()
        except NoMatches:
            pass
