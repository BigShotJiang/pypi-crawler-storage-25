"""Textual backend — full TUI with sidebar, modal screens, and autocomplete"""

from __future__ import annotations

from typing import TYPE_CHECKING

from kiss.ui.base import UIBackend

if TYPE_CHECKING:
    from kiss.agent.loop import KissAgent
    from kiss.core.settings import Settings


class TextualBackend(UIBackend):
    """Launches the Textual KissApp; requires the `textual` optional dependency"""

    async def run(self, agent: "KissAgent", settings: "Settings") -> None:
        from kiss.ui.textual.app import KissApp
        from kiss.ui.rich.theme import build_rich_theme
        from rich.console import Console
        from rich.rule import Rule

        app = KissApp(settings, agent)
        await app.run_async()

        if app._sidebar.turn_count > 0:
            console = Console(theme=build_rich_theme())
            console.print(Rule(style="ui.border.subtle"))
            console.print(app._sidebar.render_summary())
