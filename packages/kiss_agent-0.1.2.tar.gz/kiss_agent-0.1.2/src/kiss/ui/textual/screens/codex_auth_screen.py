"""Codex browser OAuth screen (PKCE authorization-code flow).

Dismisses True on success, False on cancel/timeout/failure.
"""

from __future__ import annotations

import asyncio

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import Label, LoadingIndicator

from kiss.providers.codex_auth import run_codex_browser_auth


class CodexAuthScreen(ModalScreen[bool]):
    """Modal that runs the Codex PKCE browser flow and caches resulting tokens."""

    DEFAULT_CSS = """
    CodexAuthScreen {
        align: center middle;
    }
    #auth-container {
        width: 66;
        height: auto;
        border: solid $warning;
        background: $surface;
        padding: 1 2;
    }
    #auth-title {
        text-style: bold;
        margin-bottom: 1;
    }
    #auth-url {
        margin-bottom: 1;
    }
    #auth-status {
        color: $text-muted;
        margin-top: 1;
    }
    """

    BINDINGS = [("escape", "cancel", "Cancel")]

    def compose(self) -> ComposeResult:
        with Vertical(id="auth-container"):
            yield Label("ChatGPT Codex — sign in", id="auth-title")
            yield Label("", id="auth-url")
            yield LoadingIndicator()
            yield Label("Opening browser…", id="auth-status")

    def on_mount(self) -> None:
        self.run_worker(self._run_flow(), exclusive=True, name="codex-auth")

    def action_cancel(self) -> None:
        self.dismiss(False)

    async def _run_flow(self) -> None:
        url_label = self.query_one("#auth-url", Label)
        status = self.query_one("#auth-status", Label)

        def on_url(url: str) -> None:
            url_label.update(f"Browser opened — or visit:\n[dim]{url}[/dim]")
            status.update("Waiting for authorisation…")

        success = await run_codex_browser_auth(on_url=on_url)
        if success:
            status.update("[green]✓ Signed in![/green]")
            await asyncio.sleep(0.8)
            self.dismiss(True)
        else:
            status.update("[red]Failed or timed out — press Escape to cancel.[/red]")
