"""Copilot device-code OAuth screen.

Dismisses True on success, False on cancel/timeout/failure.
"""

from __future__ import annotations

import asyncio

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import Label, LoadingIndicator

from kiss.providers.copilot_auth import run_copilot_device_auth


class CopilotAuthScreen(ModalScreen[bool]):
    """Modal that runs the GitHub device-code flow and caches the resulting token."""

    DEFAULT_CSS = """
    CopilotAuthScreen {
        align: center middle;
    }
    #auth-container {
        width: 66;
        height: auto;
        border: solid $warning;
        background: $surface;
        padding: 1 2;
    }
    #auth-title {
        text-style: bold;
        margin-bottom: 1;
    }
    #auth-url {
        margin-bottom: 0;
    }
    #auth-code {
        text-style: bold;
        color: $warning;
        margin-bottom: 1;
    }
    #auth-status {
        color: $text-muted;
        margin-top: 1;
    }
    """

    BINDINGS = [("escape", "cancel", "Cancel")]

    def compose(self) -> ComposeResult:
        with Vertical(id="auth-container"):
            yield Label("GitHub Copilot — sign in", id="auth-title")
            yield Label("", id="auth-url")
            yield Label("", id="auth-code")
            yield LoadingIndicator()
            yield Label("Requesting device code…", id="auth-status")

    def on_mount(self) -> None:
        self.run_worker(self._run_flow(), exclusive=True, name="copilot-auth")

    def action_cancel(self) -> None:
        self.dismiss(False)

    async def _run_flow(self) -> None:
        status = self.query_one("#auth-status", Label)

        def on_code(verification_uri: str, user_code: str) -> None:
            self.query_one("#auth-url", Label).update(
                f"Browser opened — or visit: [bold]{verification_uri}[/bold]"
            )
            self.query_one("#auth-code", Label).update(
                f"Code: [bold]{user_code}[/bold]  [dim](if needed)[/dim]"
            )
            status.update("Waiting for authorisation…")

        success = await run_copilot_device_auth(on_code=on_code)
        if success:
            status.update("[green]✓ Signed in![/green]")
            await asyncio.sleep(0.8)
            self.dismiss(True)
        else:
            status.update("[red]Timed out — press Escape and try again.[/red]")
