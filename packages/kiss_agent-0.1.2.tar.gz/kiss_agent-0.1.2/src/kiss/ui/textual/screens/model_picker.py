"""Model picker — Ctrl+M modal overlay.

Tree layout: provider (collapsed) → model leaves.
Active provider is expanded on open with the current model highlighted.

Models come from two sources merged at open time:
  1. Static list from providers.jsonc runtime records (ProviderRuntimeRecord.models)
  2. In-memory cache populated by KissApp (active provider on startup,
     other providers on first switch)

Returns "provider:model-id" on selection, None on cancel
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import Label, Tree
from textual.widgets.tree import TreeNode

from kiss.core.settings import (
    Settings,
    is_usable_model_mode,
)  # kept for caller compatibility
from kiss.providers.auth import provider_is_ready
from kiss.providers.health import get_provider_health
from kiss.providers.manager import fetch_provider_models, probe_provider_models  # noqa: F401 (re-exported)


class ModelPickerScreen(ModalScreen[str | None]):
    DEFAULT_CSS = """
    ModelPickerScreen {
        align: center middle;
    }

    #picker-container {
        width: 64;
        max-height: 28;
        border: solid $primary;
        background: $surface;
        padding: 1 2;
    }

    #picker-title {
        text-style: bold;
        margin-bottom: 1;
    }

    #model-tree {
        height: 1fr;
        border: none;
    }
    """

    BINDINGS = [("escape", "cancel", "Cancel")]

    def __init__(
        self,
        settings: Settings,
        current_model: str,
        cache: dict[str, list[str]] | None = None,
        free_only: bool = False,
    ) -> None:
        super().__init__()
        self._settings = settings
        self._current_model = current_model
        self._active_provider = (
            current_model.split(":", 1)[0] if ":" in current_model else ""
        )
        self._cache = cache or {}
        self._free_only = free_only
        self._provider_nodes: dict[str, TreeNode[str | None]] = {}

    # ── Composition ────────────────────────────────────────────────────────

    def compose(self) -> ComposeResult:
        with Vertical(id="picker-container"):
            yield Label(
                "Select model  [dim]↑↓ navigate · Enter select · Esc cancel[/dim]",
                id="picker-title",
            )
            yield Tree("root", id="model-tree")

    def on_mount(self) -> None:
        self.query_one("#model-tree", Tree).show_root = False
        self._build_tree()
        self._highlight_current()
        if self._free_only:
            # Free models are static — no live fetch needed.
            return
        fetched: set[str] = set()
        # Always fetch active provider if not cached.
        if self._active_provider and self._active_provider not in self._cache:
            self.run_worker(
                self._fetch_and_refresh(self._active_provider),
                exclusive=False,
                name=f"fetch-{self._active_provider}",
            )
            fetched.add(self._active_provider)
        # Fetch all autodiscover providers not yet cached.
        from kiss.providers.providers_store import load_provider_records
        from kiss.providers.registry import list_providers

        records = load_provider_records()
        for profile in list_providers():
            record = records.get(profile.name)
            if (
                (record and record.autodiscover)
                and profile.name not in self._cache
                and profile.name not in fetched
            ):
                self.run_worker(
                    self._fetch_and_refresh(profile.name),
                    exclusive=False,
                    name=f"fetch-{profile.name}",
                )

    async def _fetch_and_refresh(self, provider_name: str) -> None:
        models = await probe_provider_models(self._settings, provider_name)
        node = self._provider_nodes.get(provider_name)
        if models is None:
            # Auth/network failure — mark provider red.
            if node:
                ptype = provider_name
                node.set_label(f"[red]✗ {provider_name}[/red] [dim]{ptype}[/dim]")
            return
        if models:
            self._cache[provider_name] = models
            if node:
                seen = {
                    str(leaf.data).split(":", 1)[1]
                    for leaf in node.children
                    if leaf.data
                }
                for model_id in models:
                    full = f"{provider_name}:{model_id}"
                    if (
                        not is_usable_model_mode(model_id)
                        and full != self._current_model
                    ):
                        continue
                    if model_id not in seen:
                        label = (
                            f"[bold green]● {model_id}[/bold green]"
                            if full == self._current_model
                            else model_id
                        )
                        node.add_leaf(label, data=full)
            self._highlight_current()

    # ── Events ─────────────────────────────────────────────────────────────

    def on_tree_node_selected(self, event: Tree.NodeSelected[str | None]) -> None:
        if isinstance(event.node.data, str):
            self.dismiss(event.node.data)

    def action_cancel(self) -> None:
        self.dismiss(None)

    # ── Tree construction ──────────────────────────────────────────────────

    def _build_tree(self) -> None:
        from kiss.providers.providers_store import load_provider_records
        from kiss.providers.registry import list_providers

        tree = self.query_one("#model-tree", Tree)
        records = load_provider_records()

        if self._free_only:
            self._build_free_tree(tree)
            return

        all_profiles = sorted(
            list_providers(),
            key=lambda p: (p.name != self._active_provider, p.name),
        )

        for profile in all_profiles:
            provider_name = profile.name
            ready = provider_is_ready(provider_name)
            health = get_provider_health(provider_name)
            record = records.get(provider_name)
            static_models = record.models if record else []
            if health.status == "unhealthy":
                label = f"[dim]{provider_name}[/dim] [dim red]✗ unhealthy[/dim red]"
            elif health.status == "degraded":
                label = f"{provider_name} [yellow]⚠ degraded[/yellow]"
            elif not ready:
                label = f"{provider_name} [dim red](no credentials)[/dim red]"
            else:
                label = provider_name
            node = self._get_or_create_provider_node(tree, provider_name, label)
            seen: set[str] = set()
            for model_id in (*static_models, *self._cache.get(provider_name, [])):
                if model_id in seen:
                    continue
                seen.add(model_id)
                full = f"{provider_name}:{model_id}"
                if not is_usable_model_mode(model_id) and full != self._current_model:
                    continue
                leaf_label = (
                    f"[bold green]● {model_id}[/bold green]"
                    if full == self._current_model
                    else model_id
                )
                node.add_leaf(leaf_label, data=full)

    def _build_free_tree(self, tree: "Tree[str | None]") -> None:
        from kiss.providers.registry import get_provider_profile

        free_providers = self._settings.free_providers
        for provider_name, enabled in sorted(free_providers.items()):
            if not enabled:
                continue
            profile = get_provider_profile(provider_name)
            if not profile or not profile.free_models:
                continue
            node = self._get_or_create_provider_node(
                tree, provider_name, f"{provider_name} [green][free][/green]"
            )
            for bare_model in sorted(profile.free_models):
                full = f"{provider_name}:{bare_model}"
                leaf_label = (
                    f"[bold green]● {bare_model}[/bold green]"
                    if full == self._current_model
                    else bare_model
                )
                node.add_leaf(leaf_label, data=full)
        for name, node in self._provider_nodes.items():
            node.expand()

        # If the active provider has no registered profile, still show the current model.
        if self._active_provider and self._active_provider not in self._provider_nodes:
            node = self._get_or_create_provider_node(tree, self._active_provider)
            model_id = (
                self._current_model.split(":", 1)[1]
                if ":" in self._current_model
                else ""
            )
            if model_id:
                node.add_leaf(
                    f"[bold green]● {model_id}[/bold green]",
                    data=self._current_model,
                )

        for name, node in self._provider_nodes.items():
            if name == self._active_provider:
                node.expand()
            else:
                node.collapse()

    def _get_or_create_provider_node(
        self, tree: Tree[str | None], provider_name: str, label: str | None = None
    ) -> TreeNode[str | None]:
        if provider_name not in self._provider_nodes:
            node = tree.root.add(label or provider_name, data=None)
            self._provider_nodes[provider_name] = node
        return self._provider_nodes[provider_name]

    def _highlight_current(self) -> None:
        tree = self.query_one("#model-tree", Tree)
        for node in tree.root.children:
            for leaf in node.children:
                if leaf.data == self._current_model:
                    tree.move_cursor(leaf, animate=False)
                    return
