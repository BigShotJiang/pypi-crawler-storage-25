"""Provider picker modal — navigate with arrows, Enter to select, Esc to cancel."""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import Label, ListView, ListItem

if TYPE_CHECKING:
    from kiss.ui.commands import AuthStatusInfo


class ProviderPickerScreen(ModalScreen[str | None]):
    DEFAULT_CSS = """
    ProviderPickerScreen {
        align: center middle;
    }

    #picker-container {
        width: 60;
        max-height: 24;
        border: solid $primary;
        background: $surface;
        padding: 1 2;
    }

    #picker-title {
        text-style: bold;
        margin-bottom: 1;
    }

    #provider-list {
        height: 1fr;
    }
    """

    BINDINGS = [("escape", "cancel", "Cancel")]

    def __init__(self, providers: list[AuthStatusInfo]) -> None:
        super().__init__()
        self._providers = providers

    def compose(self) -> ComposeResult:
        with Vertical(id="picker-container"):
            yield Label(
                "Connect a provider  [dim]↑↓ navigate · Enter select · Esc cancel[/dim]",
                id="picker-title",
            )
            yield ListView(
                *[
                    ListItem(
                        Label(
                            ("[green]● [/]" if p.ready else "  ")
                            + p.display_name
                            + f"  [dim]{p.auth_type}[/dim]"
                        )
                    )
                    for p in self._providers
                ],
                id="provider-list",
            )

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        idx = event.list_view.index
        if idx is not None and 0 <= idx < len(self._providers):
            self.dismiss(self._providers[idx].name)

    def action_cancel(self) -> None:
        self.dismiss(None)


class LogoutPickerScreen(ModalScreen[str | None]):
    DEFAULT_CSS = ProviderPickerScreen.DEFAULT_CSS

    BINDINGS = [("escape", "cancel", "Cancel")]

    def __init__(self, providers: list[AuthStatusInfo]) -> None:
        super().__init__()
        self._providers = providers

    def compose(self) -> ComposeResult:
        with Vertical(id="picker-container"):
            yield Label(
                "Logout from provider  [dim]↑↓ navigate · Enter select · Esc cancel[/dim]",
                id="picker-title",
            )
            yield ListView(
                *[
                    ListItem(
                        Label(
                            "[green]● [/]"
                            + p.display_name
                            + f"  [dim]{p.auth_type} · {p.credential_source}[/dim]"
                        )
                    )
                    for p in self._providers
                ],
                id="provider-list",
            )

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        idx = event.list_view.index
        if idx is not None and 0 <= idx < len(self._providers):
            self.dismiss(self._providers[idx].name)

    def action_cancel(self) -> None:
        self.dismiss(None)
