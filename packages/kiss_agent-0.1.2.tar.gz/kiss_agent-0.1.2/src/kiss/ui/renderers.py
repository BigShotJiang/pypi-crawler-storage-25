"""Shared tool-result renderer registry.

Maps structured tool results to backend-neutral ToolResultDisplay models.
Both Rich and Textual consume these displays without reparsing output text.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from kiss.ui.shared import (
    FileChange,
    ToolResultDisplay,
    ToolResultSection,
    TruncationMeta,
    format_file_operation,
    normalize_edit_file_result,
    normalize_write_file_result,
)


@runtime_checkable
class ToolRenderer(Protocol):
    """Render a typed tool result into a backend-neutral ToolResultDisplay."""

    def render(self, result: Any) -> ToolResultDisplay: ...


class _GenericListRenderer:
    """Generic fallback for list-like tool results."""

    def render(self, result: Any) -> ToolResultDisplay:
        title = type(result).__name__.replace("Result", "").replace("_", " ").title()
        items: list[Any] = []
        for attr in (
            "entries",
            "matches",
            "results",
            "commits",
            "references",
            "symbols",
            "violations",
        ):
            val = getattr(result, attr, None)
            if val:
                items = val
                break
        truncated = getattr(result, "truncated", False)
        count = len(items)
        summary = f"{count} item{'s' if count != 1 else ''}"
        if truncated:
            summary += " (truncated)"
        trunc_meta = TruncationMeta(truncated=True) if truncated else None
        body = "\n".join(str(item) for item in items[:20])
        sections = [ToolResultSection("Items", body)] if body else []
        return ToolResultDisplay(
            title=title,
            summary=summary,
            sections=sections,
            truncation_meta=trunc_meta,
        )


class _GenericDiffRenderer:
    """Generic fallback for diff-like tool results."""

    def render(self, result: Any) -> ToolResultDisplay:
        title = type(result).__name__.replace("Result", "").replace("_", " ").title()
        diff: str = (
            getattr(result, "diff", "") or getattr(result, "diff_preview", "") or ""
        )
        truncated = getattr(result, "truncated", False)
        path: str = getattr(result, "path", "") or getattr(result, "repo_path", "")
        summary = path or "diff"
        if truncated:
            summary += " (truncated)"
        trunc_meta = TruncationMeta(truncated=True) if truncated else None
        sections = [ToolResultSection("Diff", diff)] if diff else []
        return ToolResultDisplay(
            title=title,
            summary=summary,
            sections=sections,
            truncation_meta=trunc_meta,
        )


class _GenericTextRenderer:
    """Generic fallback for plain-text or unrecognized result shapes."""

    def render(self, result: Any) -> ToolResultDisplay:
        title = type(result).__name__.replace("Result", "").replace("_", " ").title()
        path: str = getattr(result, "path", "") or getattr(result, "url", "")
        content: str = (
            getattr(result, "content", "")
            or getattr(result, "output", "")
            or str(result)
        )
        truncated = getattr(result, "truncated", False)
        if path:
            summary = path
        else:
            summary = (
                content.strip().splitlines()[0] if content.strip() else "completed"
            )
        if truncated:
            summary += " (truncated)"
        trunc_meta = TruncationMeta(truncated=True) if truncated else None
        sections = (
            [ToolResultSection("Content", content.strip())] if content.strip() else []
        )
        return ToolResultDisplay(
            title=title,
            summary=summary,
            sections=sections,
            truncation_meta=trunc_meta,
        )


class _SearchCodeRenderer:
    def render(self, result: Any) -> ToolResultDisplay:
        match_count: int = getattr(result, "match_count", 0)
        truncated: bool = getattr(result, "truncated", False)
        matches: list[Any] = getattr(result, "matches", [])

        grouped: dict[str, list[str]] = {}
        order: list[str] = []
        for m in matches:
            path = getattr(m, "path", "")
            line = getattr(m, "line", "")
            text = getattr(m, "text", "")
            if path not in grouped:
                grouped[path] = []
                order.append(path)
            grouped[path].append(f"{line}: {text}")

        file_count = len(order)
        summary = f"{match_count} matches"
        if file_count:
            summary += f" across {file_count} files"
        if truncated:
            summary += " (truncated)"

        body_lines: list[str] = []
        for path in order:
            body_lines.append(path)
            for item in grouped[path]:
                body_lines.append(f"  - {item}")
        body = "\n".join(body_lines)

        trunc_meta = TruncationMeta(truncated=True) if truncated else None
        sections = [ToolResultSection("Matches", body)] if body else []
        return ToolResultDisplay(
            title="Search Code",
            summary=summary,
            sections=sections,
            truncation_meta=trunc_meta,
        )


class _GlobRenderer:
    def render(self, result: Any) -> ToolResultDisplay:
        pattern: str = getattr(result, "pattern", "")
        root: str = getattr(result, "root", "")
        truncated: bool = getattr(result, "truncated", False)
        matches: list[Any] = getattr(result, "matches", [])

        summary = f"{pattern}  →  {len(matches)} paths"
        if root:
            summary += f" under {root}"
        if truncated:
            summary += " (truncated)"

        trunc_meta = TruncationMeta(truncated=True) if truncated else None
        body = "\n".join(getattr(m, "path", str(m)) for m in matches)
        sections = [ToolResultSection("Matches", body)] if body else []
        return ToolResultDisplay(
            title="Glob",
            summary=summary,
            sections=sections,
            truncation_meta=trunc_meta,
        )


class _FetchUrlRenderer:
    def render(self, result: Any) -> ToolResultDisplay:
        status_code = getattr(result, "status_code", "?")
        content_type: str = getattr(result, "content_type", None) or "unknown"
        redirect_count: int = getattr(result, "redirect_count", 0)
        is_html: bool = getattr(result, "is_html", False)
        is_binary: bool = getattr(result, "is_binary", False)
        is_text: bool = getattr(result, "is_text", False)
        truncated: bool = getattr(result, "truncated", False)
        url: str = getattr(result, "url", "")
        content: str | None = getattr(result, "content", None)

        flags: list[str] = []
        if is_html:
            flags.append("html")
        elif is_binary:
            flags.append("binary")
        elif is_text:
            flags.append("text")
        if truncated:
            flags.append("truncated")
        flag_text = f" [{' '.join(flags)}]" if flags else ""
        summary = f"{status_code} {content_type}, {redirect_count} redirects{flag_text}"

        trunc_meta = TruncationMeta(truncated=True) if truncated else None
        sections: list[ToolResultSection] = []
        if url:
            sections.append(ToolResultSection("Request", f"url: {url}"))
        if content:
            sections.append(ToolResultSection("Content", content))
        return ToolResultDisplay(
            title="Fetch Url",
            summary=summary,
            sections=sections,
            truncation_meta=trunc_meta,
        )


class _WebSearchRenderer:
    def render(self, result: Any) -> ToolResultDisplay:
        provider: str = getattr(result, "provider", "unknown")
        result_count: int = getattr(result, "result_count", 0)
        cached: bool = getattr(result, "cached", False)
        query: str = getattr(result, "query", "")
        results: list[Any] = getattr(result, "results", [])

        summary = f"{result_count} results via {provider}"
        if cached:
            summary += " (cached)"

        sections: list[ToolResultSection] = []
        if query:
            sections.append(ToolResultSection("Query", query))
        if results:
            body_lines: list[str] = []
            for r in results:
                title = getattr(r, "title", "")
                url = getattr(r, "url", "")
                snippet = getattr(r, "snippet", "")
                if title:
                    body_lines.append(f"- {title}")
                if url:
                    body_lines.append(f"  {url}")
                if snippet:
                    body_lines.append(f"  {snippet}")
            sections.append(ToolResultSection("Results", "\n".join(body_lines)))
        return ToolResultDisplay(title="Web Search", summary=summary, sections=sections)


class _RunBashRenderer:
    def render(self, result: Any) -> ToolResultDisplay:
        exit_code = getattr(result, "exit_code", "?")
        timed_out: bool = getattr(result, "timed_out", False)
        command: str = getattr(result, "command", "")
        stdout: str = getattr(result, "stdout", "")
        stderr: str = getattr(result, "stderr", "")
        truncated: bool = getattr(result, "truncated", False)

        summary = f"exit {exit_code}, timed_out={timed_out}"
        if command:
            summary += f" — {command}"

        trunc_meta = TruncationMeta(truncated=True) if truncated else None
        sections: list[ToolResultSection] = []
        if stdout.strip():
            sections.append(ToolResultSection("Stdout", stdout.strip()))
        if stderr.strip():
            sections.append(ToolResultSection("Stderr", stderr.strip()))
        return ToolResultDisplay(
            title="Run Bash",
            summary=summary,
            sections=sections,
            truncation_meta=trunc_meta,
        )


class _ReadFileRenderer:
    def render(self, result: Any) -> ToolResultDisplay:
        path: str = getattr(result, "path", "")
        start_line: int | None = getattr(result, "start_line", None)
        end_line: int | None = getattr(result, "end_line", None)
        truncated: bool = getattr(result, "truncated", False)
        content: str | None = getattr(result, "content", None)

        parts: list[str] = []
        if path:
            parts.append(path)
        if start_line is not None and end_line is not None:
            parts.append(f"lines {start_line}-{end_line}")
        elif start_line is not None:
            parts.append(f"lines {start_line}+")
        if truncated:
            parts.append("truncated")
        summary = " — ".join(parts) if parts else "file read"

        trunc_meta = TruncationMeta(truncated=True) if truncated else None
        sections: list[ToolResultSection] = []
        if content:
            sections.append(ToolResultSection("Content", content))
        file_changes = [FileChange(path=path)] if path else []
        return ToolResultDisplay(
            title="Read File",
            summary=summary,
            sections=sections,
            truncation_meta=trunc_meta,
            file_changes=file_changes,
        )


class _ListDirectoryRenderer:
    def render(self, result: Any) -> ToolResultDisplay:
        root: str = getattr(result, "root", "")
        truncated: bool = getattr(result, "truncated", False)
        entries: list[Any] = getattr(result, "entries", [])

        parts = [f"{len(entries)} entries"]
        if root:
            parts.append(f"under {root}")
        if truncated:
            parts.append("truncated")

        trunc_meta = TruncationMeta(truncated=True) if truncated else None
        return ToolResultDisplay(
            title="List Directory",
            summary=", ".join(parts),
            truncation_meta=trunc_meta,
        )


class _ExpandRefRenderer:
    def render(self, result: Any) -> ToolResultDisplay:
        ref: str = getattr(result, "ref", "")
        content: str | None = getattr(result, "content", None)

        sections: list[ToolResultSection] = []
        if content and content.strip():
            sections.append(ToolResultSection("Content", content))
        return ToolResultDisplay(
            title="Expand Ref",
            summary=ref or "expanded ref",
            sections=sections,
        )


class _WriteFileRenderer:
    """Typed renderer for WriteFileResult using the canonical file-op formatter."""

    def render(self, result: Any) -> ToolResultDisplay:
        created: bool = getattr(result, "created", False)
        line_count: int = getattr(result, "line_count", 0)
        diff_preview: str | None = getattr(result, "diff_preview", None)
        path: str = getattr(result, "path", "")
        op = normalize_write_file_result(path, created, line_count, diff_preview)
        return format_file_operation(op)


class _EditFileRenderer:
    """Typed renderer for EditFileResult using the canonical file-op formatter."""

    def render(self, result: Any) -> ToolResultDisplay:
        path: str = getattr(result, "path", "")
        diff_preview: str | None = getattr(result, "diff_preview", None)
        needs_disambiguation: bool = getattr(result, "needs_disambiguation", False) or (
            getattr(result, "meta", None) is not None
            and getattr(result.meta, "needs_disambiguation", False)
        )
        diagnostics: str | None = None
        if needs_disambiguation:
            diagnostics = (
                "Disambiguation required — edit could not be applied uniquely."
            )
        elif contexts := getattr(result, "match_contexts", None):
            if contexts:
                diagnostics = "\n".join(str(c) for c in contexts[:5])
        op = normalize_edit_file_result(path, diff_preview, diagnostics)
        display = format_file_operation(op)
        if needs_disambiguation:
            display.status = "error"
        return display


class _LogicToolRenderer:
    """Typed renderer for run_python (LogicExecutionResult | LogicApplyResult)."""

    def render(self, result: Any) -> ToolResultDisplay:
        if hasattr(result, "applied_paths") or hasattr(result, "drift_detected_paths"):
            return self._render_apply(result)
        return self._render_execution(result)

    def _render_execution(self, result: Any) -> ToolResultDisplay:
        meta = getattr(result, "meta", None)
        ok = getattr(meta, "ok", True)
        timed_out = getattr(result, "timed_out", False)
        pending_changes = getattr(result, "pending_changes", [])
        stdout: str = getattr(result, "stdout", "")
        stderr: str = getattr(result, "stderr", "")
        truncated = getattr(result, "truncated", False)

        if timed_out:
            return ToolResultDisplay(
                title="run_python", summary="timed out", status="error"
            )
        if not ok:
            msg = (
                getattr(meta, "error_message", None)
                or getattr(meta, "error_code", None)
                or "failed"
            )
            return ToolResultDisplay(title="run_python", summary=msg, status="error")

        if pending_changes:
            n = len(pending_changes)
            summary = f"{n} file change{'s' if n != 1 else ''} pending approval"
        elif (stdout or stderr).strip():
            summary = (stdout or stderr).strip().splitlines()[0][:80]
        else:
            summary = "completed"

        sections = []
        if stdout.strip():
            sections.append(ToolResultSection("stdout", stdout.strip()))
        if stderr.strip():
            sections.append(ToolResultSection("stderr", stderr.strip()))

        trunc_meta = TruncationMeta(truncated=True) if truncated else None
        return ToolResultDisplay(
            title="run_python",
            summary=summary,
            sections=sections,
            truncation_meta=trunc_meta,
        )

    def _render_apply(self, result: Any) -> ToolResultDisplay:
        meta = getattr(result, "meta", None)
        ok = getattr(meta, "ok", True)
        approved = getattr(result, "approved", False)
        applied_paths: list[str] = getattr(result, "applied_paths", [])
        drift_paths: list[str] = getattr(result, "drift_detected_paths", [])
        applied_count: int = getattr(result, "applied_count", 0)

        if not approved:
            msg = getattr(meta, "error_message", None) or "denied"
            return ToolResultDisplay(title="run_python", summary=msg, status="error")

        if not ok and drift_paths:
            body = "\n".join(f"- {p}" for p in drift_paths)
            return ToolResultDisplay(
                title="run_python",
                summary=f"drift detected in {len(drift_paths)} file(s)",
                status="error",
                sections=[ToolResultSection("Drifted paths", body)],
            )

        file_changes = [FileChange(path=p) for p in applied_paths]
        if applied_count == 0:
            return ToolResultDisplay(
                title="run_python",
                summary="no changes to apply",
                file_changes=file_changes,
            )
        return ToolResultDisplay(
            title="run_python",
            summary=f"applied {applied_count} file{'s' if applied_count != 1 else ''}",
            status="ok",
            file_changes=file_changes,
        )


class RendererRegistry:
    """Registry mapping tool names to typed renderers.

    Usage:
        registry = RendererRegistry()
        registry.register("read_file", MyReadFileRenderer())
        display = registry.render("read_file", result)
    """

    def __init__(self) -> None:
        self._renderers: dict[str, ToolRenderer] = {}
        self._generic_list = _GenericListRenderer()
        self._generic_diff = _GenericDiffRenderer()
        self._generic_text = _GenericTextRenderer()

    def register(self, tool_name: str, renderer: ToolRenderer) -> None:
        self._renderers[tool_name] = renderer

    def render(self, tool_name: str, result: Any) -> ToolResultDisplay | None:
        """Return a display model for the given result, or None if no renderer matches.

        Falls back through generic typed renderers before returning None.
        None signals the caller to fall back to the legacy string-parsing path.
        """
        renderer = self._renderers.get(tool_name)
        if renderer is not None:
            return renderer.render(result)

        # Generic typed fallbacks by shape
        if hasattr(result, "diff") or hasattr(result, "diff_preview"):
            return self._generic_diff.render(result)

        for list_attr in (
            "entries",
            "matches",
            "results",
            "commits",
            "references",
            "symbols",
            "violations",
        ):
            if hasattr(result, list_attr) and isinstance(
                getattr(result, list_attr), list
            ):
                return self._generic_list.render(result)

        if hasattr(result, "content") or hasattr(result, "output"):
            return self._generic_text.render(result)

        return None


# Singleton registry shared across both backends.
_REGISTRY = RendererRegistry()
_REGISTRY.register("search_code", _SearchCodeRenderer())
_REGISTRY.register("glob", _GlobRenderer())
_REGISTRY.register("fetch_url", _FetchUrlRenderer())
_REGISTRY.register("web_search", _WebSearchRenderer())
_REGISTRY.register("run_bash", _RunBashRenderer())
_REGISTRY.register("read_file", _ReadFileRenderer())
_REGISTRY.register("list_directory", _ListDirectoryRenderer())
_REGISTRY.register("expand_ref", _ExpandRefRenderer())
_REGISTRY.register("write_file", _WriteFileRenderer())
_REGISTRY.register("edit_file", _EditFileRenderer())
_REGISTRY.register("apply_patch", _EditFileRenderer())
_REGISTRY.register("run_python", _LogicToolRenderer())


def get_renderer_registry() -> RendererRegistry:
    """Return the shared renderer registry."""
    return _REGISTRY
