"""Shared UI session and observability state contract.

Both Rich and Textual backends consume this model. The agent event stream
remains the authoritative source; this module translates events into a
finite runtime state machine and a unified session snapshot.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto

from kiss.core.usage import TodoItem


class RuntimeState(Enum):
    """Canonical runtime states for terminal UI backends.

    Backends must render each state with a visually distinct treatment.
    """

    idle = auto()
    streaming = auto()
    tool_running = auto()
    compacting = auto()
    blocked_permission = auto()
    blocked_user_input = auto()
    warning = auto()
    error = auto()


@dataclass
class SessionSnapshot:
    """Immutable snapshot of session-level UI state consumed by both backends.

    Updated by the shared state model after each relevant agent event.
    Backends render from this structure rather than maintaining incompatible
    local state machines.
    """

    runtime_state: RuntimeState = RuntimeState.idle
    turn_count: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    thinking_tokens: int = 0
    cost_usd: float = 0.0
    context_window: int = 0
    finish_reason: str | None = None
    models_used: list[str] = field(default_factory=list)
    todos: list[TodoItem] = field(default_factory=list)
    # tool_name -> (added, removed)
    file_changes: dict[str, tuple[int, int]] = field(default_factory=dict)
    # Active tool call label shown in progress indicators
    active_tool_label: str = ""
    # Compaction status label for progress indicators
    compaction_label: str = ""
    # Warning or error message for the current state
    state_message: str = ""


class UISessionState:
    """Mutable shared UI session state owner.

    Translates incoming agent events into RuntimeState transitions and
    maintains a SessionSnapshot consumed by both backends. Backends call
    event_* methods as events arrive, then read current_snapshot().
    """

    def __init__(self, context_window: int = 0) -> None:
        self._snap = SessionSnapshot(context_window=context_window)

    def current_snapshot(self) -> SessionSnapshot:
        return self._snap

    def _update(self, **kwargs: object) -> None:
        import dataclasses

        self._snap = dataclasses.replace(self._snap, **kwargs)  # type: ignore[arg-type]

    # ── Runtime state transitions ─────────────────────────────────────────

    def on_idle(self) -> None:
        self._update(
            runtime_state=RuntimeState.idle, active_tool_label="", state_message=""
        )

    def on_streaming(self) -> None:
        self._update(runtime_state=RuntimeState.streaming)

    def on_tool_call(self, tool_label: str) -> None:
        self._update(
            runtime_state=RuntimeState.tool_running, active_tool_label=tool_label
        )

    def on_tool_result(self) -> None:
        self._update(runtime_state=RuntimeState.streaming, active_tool_label="")

    def on_compacting(self, label: str) -> None:
        self._update(runtime_state=RuntimeState.compacting, compaction_label=label)

    def on_compacted(self) -> None:
        self._update(runtime_state=RuntimeState.streaming, compaction_label="")

    def on_blocked_permission(self) -> None:
        self._update(runtime_state=RuntimeState.blocked_permission)

    def on_unblocked(self) -> None:
        self._update(runtime_state=RuntimeState.streaming)

    def on_blocked_user_input(self) -> None:
        self._update(runtime_state=RuntimeState.blocked_user_input)

    def on_warning(self, message: str) -> None:
        self._update(runtime_state=RuntimeState.warning, state_message=message)

    def on_error(self, message: str) -> None:
        self._update(runtime_state=RuntimeState.error, state_message=message)

    def on_cancelled(self) -> None:
        self._update(
            runtime_state=RuntimeState.idle, active_tool_label="", state_message=""
        )

    # ── Session data updates ──────────────────────────────────────────────

    def on_todos(self, todos: list[TodoItem]) -> None:
        self._update(todos=todos)

    def on_file_change(self, path: str, added: int, removed: int) -> None:
        changes = dict(self._snap.file_changes)
        existing_added, existing_removed = changes.get(path, (0, 0))
        changes[path] = (existing_added + added, existing_removed + removed)
        self._update(file_changes=changes)

    def on_model(self, label: str) -> None:
        models = list(self._snap.models_used)
        if label not in models:
            models.insert(0, label)
        self._update(models_used=models)

    def on_done(
        self,
        *,
        input_tokens: int,
        output_tokens: int,
        cache_read_tokens: int,
        cache_write_tokens: int,
        thinking_tokens: int,
        cost_usd: float,
        context_window: int,
        finish_reason: str | None,
        model_label: str,
    ) -> None:
        models = list(self._snap.models_used)
        if model_label not in models:
            models.insert(0, model_label)
        self._update(
            runtime_state=RuntimeState.idle,
            turn_count=self._snap.turn_count + 1,
            input_tokens=self._snap.input_tokens + input_tokens,
            output_tokens=self._snap.output_tokens + output_tokens,
            cache_read_tokens=self._snap.cache_read_tokens + cache_read_tokens,
            cache_write_tokens=self._snap.cache_write_tokens + cache_write_tokens,
            thinking_tokens=self._snap.thinking_tokens + thinking_tokens,
            cost_usd=cost_usd,
            context_window=context_window,
            finish_reason=finish_reason,
            models_used=models,
            active_tool_label="",
            state_message="",
        )

    def clear(self) -> None:
        context_window = self._snap.context_window
        models = self._snap.models_used[:]
        self._snap = SessionSnapshot(context_window=context_window, models_used=models)
