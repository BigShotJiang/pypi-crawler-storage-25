"""Shared prompt-history storage helpers for terminal UI backends."""

from __future__ import annotations

import hashlib
from pathlib import Path

from kiss.core.settings import discover_workspace_root


def workspace_history_file(cwd: Path | None = None) -> Path:
    """Return the workspace-scoped prompt history file path."""
    workspace = discover_workspace_root(cwd or Path.cwd())
    workspace_hash = hashlib.sha256(str(workspace).encode()).hexdigest()[:16]
    return Path.home() / ".kiss" / "agent" / "history" / f"{workspace_hash}.txt"


def load_prompt_history(path: Path) -> list[str]:
    """Load newline-delimited prompt history from disk."""
    try:
        return [
            line.rstrip("\n")
            for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
    except FileNotFoundError:
        return []


def append_prompt_history(path: Path, text: str) -> None:
    """Append one submitted prompt to the history file."""
    value = text.strip()
    if not value:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(value + "\n")
