"""Shared fuzzy matching policy for targeted recovery and ambiguity resolution.

Used exclusively for these three paths (scope is intentionally narrow):
  1. Tool typo recovery — unknown tool name in the shared runner path
  2. Unknown shared slash-command suggestions — both Rich and Textual backends
  3. Todo text resolution — referenced by approximate text instead of exact id

Do NOT use this module for picker navigation, model selection, or autocomplete.
Those surfaces use list-driven or completion-library mechanisms instead.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

from rapidfuzz import process, fuzz


# ── Thresholds ────────────────────────────────────────────────────────────────

# Minimum score (0–100) for a match to be offered as a suggestion.
SUGGESTION_THRESHOLD = 70

# Score gap required to resolve a single winner rather than reporting ambiguity.
# If the top-2 scores are within this gap, the result is ambiguous.
AMBIGUITY_GAP = 10


# ── Result types ─────────────────────────────────────────────────────────────


@dataclass
class FuzzyMatch:
    value: str
    score: float


@dataclass
class FuzzyResult:
    """Outcome of a fuzzy match operation."""

    matched: bool
    suggestion: str | None = None
    # True when multiple candidates are too close to call deterministically.
    ambiguous: bool = False
    # All candidates above SUGGESTION_THRESHOLD, ordered by score descending.
    candidates: list[FuzzyMatch] = field(default_factory=list)


# ── Core matching functions ───────────────────────────────────────────────────


def best_match(query: str, choices: Sequence[str]) -> FuzzyResult:
    """Return the best fuzzy match for query among choices.

    Applies SUGGESTION_THRESHOLD and AMBIGUITY_GAP to determine whether to
    offer a single suggestion, report ambiguity, or return no match.
    """
    if not choices:
        return FuzzyResult(matched=False)

    results = process.extract(
        query,
        choices,
        scorer=fuzz.WRatio,
        limit=5,
    )

    above_threshold = [
        FuzzyMatch(value=str(r[0]), score=float(r[1]))
        for r in results
        if r[1] >= SUGGESTION_THRESHOLD
    ]

    if not above_threshold:
        return FuzzyResult(matched=False, candidates=[])

    top = above_threshold[0]
    second_score = above_threshold[1].score if len(above_threshold) > 1 else 0.0

    if top.score - second_score < AMBIGUITY_GAP and len(above_threshold) > 1:
        return FuzzyResult(matched=True, ambiguous=True, candidates=above_threshold)

    return FuzzyResult(matched=True, suggestion=top.value, candidates=above_threshold)


# ── Domain-specific helpers ───────────────────────────────────────────────────


def suggest_tool(unknown_name: str, known_names: Sequence[str]) -> str | None:
    """Return a single high-confidence tool name suggestion, or None.

    Used by the shared tool runner when an unknown tool name is encountered.
    Returns None when confidence is too low or result is ambiguous.
    """
    result = best_match(unknown_name, known_names)
    if result.matched and not result.ambiguous:
        return result.suggestion
    return None


def suggest_command(unknown_name: str, known_names: Sequence[str]) -> str | None:
    """Return a single high-confidence slash command suggestion, or None.

    Used by Rich and Textual backends for unknown shared command handling.
    Returns None when confidence is too low or result is ambiguous.
    """
    result = best_match(unknown_name, known_names)
    if result.matched and not result.ambiguous:
        return result.suggestion
    return None


def resolve_todo_text(
    query: str,
    todos: Sequence[tuple[str, str]],
) -> FuzzyResult:
    """Resolve a todo by approximate text with deterministic tie handling.

    `todos` is a sequence of (id, text) pairs. Resolution priority:
      1. Exact id match
      2. Exact text match (case-insensitive)
      3. Fuzzy ranked match with SUGGESTION_THRESHOLD and AMBIGUITY_GAP

    Returns a FuzzyResult. When ambiguous, the caller must report ambiguity
    explicitly rather than picking the first candidate.
    """
    # 1. Exact id match
    for todo_id, _ in todos:
        if todo_id == query:
            return FuzzyResult(matched=True, suggestion=todo_id, ambiguous=False)

    # 2. Exact text match (case-insensitive)
    query_lower = query.lower()
    for todo_id, text in todos:
        if text.lower() == query_lower:
            return FuzzyResult(matched=True, suggestion=todo_id, ambiguous=False)

    # 3. Fuzzy ranked match over todo texts
    texts = [text for _, text in todos]
    id_by_text = {text: todo_id for todo_id, text in todos}

    text_result = best_match(query, texts)
    if not text_result.matched:
        return FuzzyResult(matched=False)

    if text_result.ambiguous:
        resolved_candidates = [
            FuzzyMatch(value=id_by_text[m.value], score=m.score)
            for m in text_result.candidates
            if m.value in id_by_text
        ]
        return FuzzyResult(matched=True, ambiguous=True, candidates=resolved_candidates)

    matched_text = text_result.suggestion
    if matched_text is None or matched_text not in id_by_text:
        return FuzzyResult(matched=False)

    return FuzzyResult(matched=True, suggestion=id_by_text[matched_text])
