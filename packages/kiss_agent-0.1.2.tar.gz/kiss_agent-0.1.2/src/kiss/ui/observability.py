"""Bounded session-scoped observability buffers.

Each surface uses a deterministic per-surface eviction policy so test
expectations are stable and memory stays bounded during long sessions.

Buffer policies:
  ChatActivityBuffer — oldest entries evicted first (ring, 1000 max)
  LogsBuffer         — oldest entries evicted first (ring, 1000 max)
  MetricsBuffer      — latest value per metric key + 1000 time-series samples
  TracesBuffer       — oldest completed traces evicted first; active trace preserved

None of these buffers are shared across surfaces. The ObservabilityState
aggregates all four and is consumed by Textual observability views.
"""

from __future__ import annotations

from collections import deque

import msgspec


_MAX_ENTRIES = 1000


# ── Entry types ───────────────────────────────────────────────────────────────


class LogEntry(msgspec.Struct, omit_defaults=True):
    timestamp: str
    level: str  # "info" | "warning" | "error" | "compacting"
    message: str


class MetricSample(msgspec.Struct, omit_defaults=True):
    timestamp: str
    key: str
    value: float


class TraceEvent(msgspec.Struct, omit_defaults=True):
    timestamp: str
    tool_name: str
    call_id: str
    kind: str  # "call" | "result" | "error"
    label: str
    is_complete: bool = False


class ChatActivityEntry(msgspec.Struct, omit_defaults=True):
    timestamp: str
    kind: str  # "tool_call" | "tool_result" | "group_summary"
    label: str
    activity_id: str | None = None
    detail: str = ""


# ── Buffers ───────────────────────────────────────────────────────────────────


class ChatActivityBuffer:
    """Bounded chat-adjacent grouped activity buffer.

    Eviction: oldest entries first.
    """

    def __init__(self, max_size: int = _MAX_ENTRIES) -> None:
        self._buf: deque[ChatActivityEntry] = deque(maxlen=max_size)

    def append(self, entry: ChatActivityEntry) -> None:
        self._buf.append(entry)

    def entries(self) -> list[ChatActivityEntry]:
        return list(self._buf)

    def get_by_activity(self, activity_id: str) -> list[ChatActivityEntry]:
        return [e for e in self._buf if e.activity_id == activity_id]

    def get_by_group(self, group_id: str) -> list[ChatActivityEntry]:
        """Legacy alias for get_by_activity."""
        return self.get_by_activity(group_id)

    def clear(self) -> None:
        self._buf.clear()

    def __len__(self) -> int:
        return len(self._buf)


class LogsBuffer:
    """Bounded logs buffer.

    Eviction: oldest entries first.
    """

    def __init__(self, max_size: int = _MAX_ENTRIES) -> None:
        self._buf: deque[LogEntry] = deque(maxlen=max_size)

    def append(self, entry: LogEntry) -> None:
        self._buf.append(entry)

    def entries(self) -> list[LogEntry]:
        return list(self._buf)

    def clear(self) -> None:
        self._buf.clear()

    def __len__(self) -> int:
        return len(self._buf)


class MetricsBuffer:
    """Bounded metrics buffer.

    Retains latest value per metric key plus the most recent 1000 time-series
    samples across all keys. When the sample ring overflows, oldest samples are
    evicted while latest_values always reflects the most recent value per key.
    """

    def __init__(self, max_samples: int = _MAX_ENTRIES) -> None:
        self._samples: deque[MetricSample] = deque(maxlen=max_samples)
        self._latest: dict[str, float] = {}

    def record(self, entry: MetricSample) -> None:
        self._samples.append(entry)
        self._latest[entry.key] = entry.value

    def latest_values(self) -> dict[str, float]:
        return dict(self._latest)

    def samples(self) -> list[MetricSample]:
        return list(self._samples)

    def clear(self) -> None:
        self._samples.clear()
        self._latest.clear()

    def __len__(self) -> int:
        return len(self._samples)


class TracesBuffer:
    """Bounded traces buffer.

    Eviction: oldest *completed* traces evicted first; any currently active
    (incomplete) trace is preserved until completion. Max total events 1000.
    """

    def __init__(self, max_size: int = _MAX_ENTRIES) -> None:
        self._buf: deque[TraceEvent] = deque(maxlen=max_size)

    def append(self, event: TraceEvent) -> None:
        maxlen = self._buf.maxlen
        if maxlen is not None and len(self._buf) >= maxlen:
            self._evict_one_completed()
        self._buf.append(event)

    def _evict_one_completed(self) -> None:
        for i, ev in enumerate(self._buf):
            if ev.is_complete:
                del self._buf[i]  # type: ignore[attr-defined]
                return
        # All active — evict oldest anyway to stay bounded.
        if self._buf:
            self._buf.popleft()

    def events(self) -> list[TraceEvent]:
        return list(self._buf)

    def clear(self) -> None:
        self._buf.clear()

    def __len__(self) -> int:
        return len(self._buf)


class ThoughtsBuffer:
    """Bounded per-thought_id text buffer.

    Each thought stream gets an independent deque with maxlen=_MAX_ENTRIES.
    Chunks with thought_id=None are transient and not stored.
    """

    def __init__(self, max_size: int = _MAX_ENTRIES) -> None:
        self._max_size = max_size
        self._streams: dict[str, deque[str]] = {}

    def append(self, thought_id: str | None, chunk: str) -> None:
        if thought_id is None:
            return
        if thought_id not in self._streams:
            self._streams[thought_id] = deque(maxlen=self._max_size)
        self._streams[thought_id].append(chunk)

    def get(self, thought_id: str) -> list[str]:
        return list(self._streams.get(thought_id, deque()))

    def clear(self) -> None:
        self._streams.clear()

    def __len__(self) -> int:
        return len(self._streams)


# ── Aggregate state ───────────────────────────────────────────────────────────


class ObservabilityState:
    """Aggregates all observability surfaces for Textual views.

    Backends populate this from agent events. Textual views read from it when
    the user switches tabs so hidden views stay current.
    """

    def __init__(self) -> None:
        self.chat_activity = ChatActivityBuffer()
        self.logs = LogsBuffer()
        self.metrics = MetricsBuffer()
        self.traces = TracesBuffer()
        self.thoughts = ThoughtsBuffer()

    def clear(self) -> None:
        self.chat_activity.clear()
        self.logs.clear()
        self.metrics.clear()
        self.traces.clear()
        self.thoughts.clear()
