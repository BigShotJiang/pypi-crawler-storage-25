"""Shared slash command metadata."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

Backend = Literal["rich", "textual"]

_GROUP_ORDER = ["session", "model", "observability", "help"]
_GROUP_LABELS = {
    "session": "Session",
    "model": "Model",
    "observability": "Observability",
    "help": "Help",
}


@dataclass(frozen=True)
class SlashCommand:
    name: str
    description: str
    usage: str
    # None = available in both backends; "rich" or "textual" = backend-specific.
    backend: Backend | None = None
    # Logical grouping for help and command-discovery surfaces.
    group: str = "session"


SLASH_COMMANDS: tuple[SlashCommand, ...] = (
    SlashCommand(
        "/model", "show or switch model", "/model [provider:model-id]", group="model"
    ),
    SlashCommand(
        "/providers", "list providers with auth and health", "/providers", group="model"
    ),
    SlashCommand(
        "/free", "toggle free provider access", "/free [provider]", group="model"
    ),
    SlashCommand("/connect", "authenticate a provider", "/connect", group="model"),
    SlashCommand("/logout", "remove provider credentials", "/logout", group="model"),
    SlashCommand("/clear", "clear conversation history", "/clear"),
    SlashCommand("/compact", "compact context now", "/compact"),
    SlashCommand("/resume", "restore last saved session", "/resume"),
    SlashCommand("/think", "toggle thinking display", "/think", group="observability"),
    SlashCommand("/help", "show commands", "/help", group="help"),
    SlashCommand("/exit", "end the session", "/exit", group="help"),
    SlashCommand("/quit", "end the session", "/quit", group="help"),
)

SLASH_COMMAND_NAMES: tuple[str, ...] = tuple(cmd.name for cmd in SLASH_COMMANDS)


def slash_commands_for(backend: Backend) -> tuple[SlashCommand, ...]:
    """Return commands available in the given backend."""
    return tuple(
        cmd for cmd in SLASH_COMMANDS if cmd.backend is None or cmd.backend == backend
    )


def slash_help_markup(backend: Backend | None = None) -> str:
    """Return Rich markup for a grouped command help panel."""
    commands = slash_commands_for(backend) if backend else SLASH_COMMANDS

    by_group: dict[str, list[SlashCommand]] = {}
    max_usage = 0
    for cmd in commands:
        by_group.setdefault(cmd.group, []).append(cmd)
        max_usage = max(max_usage, len(cmd.usage))

    # Pad usage column for alignment
    usage_width = max(26, max_usage + 2)

    rows: list[str] = []
    ordered_groups = [g for g in _GROUP_ORDER if g in by_group]
    ordered_groups += [g for g in by_group if g not in _GROUP_ORDER]

    for i, group in enumerate(ordered_groups):
        if i > 0:
            rows.append("")
        label = _GROUP_LABELS.get(group, group.title())
        rows.append(f"[dim]{label}[/dim]")
        for cmd in by_group[group]:
            suffix = f"  [dim]({cmd.backend} only)[/dim]" if cmd.backend else ""
            rows.append(
                f"  [bold]{cmd.usage:<{usage_width}}[/] {cmd.description}{suffix}"
            )

    return "\n".join(rows)
