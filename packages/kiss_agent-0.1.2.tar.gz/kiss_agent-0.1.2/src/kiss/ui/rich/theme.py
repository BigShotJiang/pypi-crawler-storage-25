"""Build a Rich Theme from the shared semantic token set."""

from __future__ import annotations

from rich.theme import Theme

from kiss.data.ui_tokens import DEFAULT_TOKENS, UITokenSet


def build_rich_theme(tokens: UITokenSet = DEFAULT_TOKENS) -> Theme:
    """Return a Rich Theme mapping semantic roles to token hex values."""
    return Theme(
        {
            "ui.text.primary": tokens.text_primary,
            "ui.text.muted": tokens.text_muted,
            "ui.text.subtle": tokens.text_subtle,
            "ui.text.success": tokens.text_success,
            "ui.text.warning": tokens.text_warning,
            "ui.text.error": tokens.text_error,
            "ui.text.accent": tokens.text_accent,
            "ui.border.default": tokens.border_default,
            "ui.border.active": tokens.border_active,
            "ui.border.subtle": tokens.border_subtle,
            "ui.panel.bg": tokens.panel_bg,
            "ui.panel.bg_alt": tokens.panel_bg_alt,
            "ui.selection.bg": tokens.selection_bg,
            "ui.selection.fg": tokens.selection_fg,
            "ui.status.idle": tokens.status_idle,
            "ui.status.streaming": tokens.status_streaming,
            "ui.status.running": tokens.status_running,
            "ui.status.blocked": tokens.status_blocked,
            "ui.status.compacting": tokens.status_compacting,
            "ui.status.warning": tokens.status_warning,
            "ui.status.error": tokens.status_error,
            "ui.syntax.comment": tokens.syntax_comment,
            "ui.syntax.keyword": tokens.syntax_keyword,
            "ui.syntax.function": tokens.syntax_function,
            "ui.syntax.variable": tokens.syntax_variable,
            "ui.syntax.string": tokens.syntax_string,
            "ui.syntax.number": tokens.syntax_number,
            "ui.syntax.type": tokens.syntax_type,
            "ui.syntax.operator": tokens.syntax_operator,
            "ui.syntax.punctuation": tokens.syntax_punctuation,
        }
    )


def build_tcss_variables(tokens: UITokenSet = DEFAULT_TOKENS) -> str:
    """Return TCSS variable declarations for use in Textual CSS."""
    return "\n".join(
        [
            f"$ui-text-primary: {tokens.text_primary};",
            f"$ui-text-muted: {tokens.text_muted};",
            f"$ui-text-subtle: {tokens.text_subtle};",
            f"$ui-text-success: {tokens.text_success};",
            f"$ui-text-warning: {tokens.text_warning};",
            f"$ui-text-error: {tokens.text_error};",
            f"$ui-text-accent: {tokens.text_accent};",
            f"$ui-border-default: {tokens.border_default};",
            f"$ui-border-active: {tokens.border_active};",
            f"$ui-border-subtle: {tokens.border_subtle};",
            f"$ui-panel-bg: {tokens.panel_bg};",
            f"$ui-panel-bg-alt: {tokens.panel_bg_alt};",
            f"$ui-selection-bg: {tokens.selection_bg};",
            f"$ui-selection-fg: {tokens.selection_fg};",
            f"$ui-status-idle: {tokens.status_idle};",
            f"$ui-status-streaming: {tokens.status_streaming};",
            f"$ui-status-running: {tokens.status_running};",
            f"$ui-status-blocked: {tokens.status_blocked};",
            f"$ui-status-compacting: {tokens.status_compacting};",
            f"$ui-status-warning: {tokens.status_warning};",
            f"$ui-status-error: {tokens.status_error};",
            f"$ui-syntax-comment: {tokens.syntax_comment};",
            f"$ui-syntax-keyword: {tokens.syntax_keyword};",
            f"$ui-syntax-function: {tokens.syntax_function};",
            f"$ui-syntax-variable: {tokens.syntax_variable};",
            f"$ui-syntax-string: {tokens.syntax_string};",
            f"$ui-syntax-number: {tokens.syntax_number};",
            f"$ui-syntax-type: {tokens.syntax_type};",
            f"$ui-syntax-operator: {tokens.syntax_operator};",
            f"$ui-syntax-punctuation: {tokens.syntax_punctuation};",
        ]
    )
