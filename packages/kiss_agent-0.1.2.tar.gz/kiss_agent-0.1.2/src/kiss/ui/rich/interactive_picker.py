"""InteractivePicker — arrow-key navigable list with fuzzy filter.

Built on the same prompt_toolkit Application pattern as permission.py's
_run_choice_selector. Adds real-time fuzzy filtering and a metadata panel.

Falls back to a static Rich table when the terminal is non-interactive.
"""

from __future__ import annotations

from typing import Any

from prompt_toolkit.application import Application
from prompt_toolkit.formatted_text import FormattedText
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout import Layout
from prompt_toolkit.layout.containers import Window
from prompt_toolkit.layout.controls import FormattedTextControl
from rich.console import Console
from rich.table import Table

# Characters captured as filter input.  Excludes control chars; includes
# common model-name chars (letters, digits, hyphens, dots, slashes, colons).
_FILTER_CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_./:@ "


async def run_picker(
    console: Console,
    items: list[tuple[str, str | None]],
    *,
    title: str = "",
) -> int | None:
    """Arrow-key picker with real-time fuzzy filter and optional metadata.

    Parameters
    ----------
    console:
        Rich console for static fallback rendering.
    items:
        List of (label, metadata) pairs.  *metadata* is a short string shown
        below the list when that row is highlighted; pass None to omit.
    title:
        Optional header line rendered above the list.

    Returns
    -------
    int | None
        Zero-based index into *items* of the confirmed selection, or None if
        the user cancelled (Esc / Ctrl+C) or the list was empty.
    """
    if not items:
        console.print("[dim](no items to display)[/dim]")
        return None

    filter_chars: list[str] = []
    selected = 0
    result: list[int | None] = [None]

    def _visible() -> list[tuple[int, str, str | None]]:
        q = "".join(filter_chars).strip().lower()
        if not q:
            return [(i, lbl, meta) for i, (lbl, meta) in enumerate(items)]
        return [
            (i, lbl, meta) for i, (lbl, meta) in enumerate(items) if q in lbl.lower()
        ]

    def _render() -> FormattedText:
        lines: list[tuple[str, str]] = []
        if title:
            lines.append(("bold", f"  {title}\n\n"))

        q = "".join(filter_chars)
        if q:
            lines.append(("class:hint", f"  Filter: {q}\n\n"))

        visible = _visible()
        if not visible:
            lines.append(("class:hint", "  (no matches)\n"))
        else:
            for rank, (_, lbl, _meta) in enumerate(visible):
                if rank == selected:
                    lines.append(("class:selected", f"  ❯ {lbl}\n"))
                else:
                    lines.append(("", f"    {lbl}\n"))

        # Metadata panel for highlighted item
        if visible and 0 <= selected < len(visible):
            meta = visible[selected][2]
            if meta:
                lines.append(("class:hint", f"\n  ──\n  {meta}\n"))

        lines.append(
            (
                "class:hint",
                "\n  ↑↓ navigate  Enter confirm  Esc cancel  type to filter",
            )
        )
        return FormattedText(lines)

    kb = KeyBindings()

    @kb.add("up")
    def _up(_: Any) -> None:
        nonlocal selected
        vis = _visible()
        if vis:
            selected = (selected - 1) % len(vis)

    @kb.add("down")
    def _down(_: Any) -> None:
        nonlocal selected
        vis = _visible()
        if vis:
            selected = (selected + 1) % len(vis)

    @kb.add("enter")
    def _enter(event: Any) -> None:
        vis = _visible()
        if vis and 0 <= selected < len(vis):
            result[0] = vis[selected][0]
        import prompt_toolkit.application as _mod

        _mod.get_app().exit()

    @kb.add("escape")
    def _esc(event: Any) -> None:
        result[0] = None
        import prompt_toolkit.application as _mod

        _mod.get_app().exit()

    @kb.add("c-c")
    def _ctrlc(event: Any) -> None:
        result[0] = None
        import prompt_toolkit.application as _mod

        _mod.get_app().exit()

    @kb.add("backspace")
    def _back(_: Any) -> None:
        nonlocal selected
        if filter_chars:
            filter_chars.pop()
            selected = 0

    for _ch in _FILTER_CHARS:

        @kb.add(_ch)
        def _char(_: Any, c: str = _ch) -> None:
            nonlocal selected
            filter_chars.append(c)
            selected = 0

    layout = Layout(Window(content=FormattedTextControl(text=_render)))
    app: Application[None] = Application(
        layout=layout, key_bindings=kb, full_screen=False
    )

    try:
        await app.run_async()
    except Exception:
        return await _static_table_fallback(console, items, title)

    return result[0]


async def _static_table_fallback(
    console: Console,
    items: list[tuple[str, str | None]],
    title: str,
) -> int | None:
    """Numbered-list fallback for non-interactive / CI terminals."""
    table = Table(title=title or None, show_header=False, box=None, padding=(0, 1))
    table.add_column("#", style="dim", justify="right")
    table.add_column("Item")
    table.add_column("Info", style="dim")
    for idx, (label, meta) in enumerate(items, start=1):
        table.add_row(str(idx), label, meta or "")
    console.print(table)

    try:
        raw = input("  Enter number (or Enter to cancel): ").strip()
        if not raw:
            return None
        n = int(raw)
        if 1 <= n <= len(items):
            return n - 1
        console.print("[red]Invalid choice[/red]")
        return None
    except (ValueError, EOFError):
        return None
