"""Shared prompt_toolkit helpers for permission and ask-user prompts.

Used by RichStatusBarBackend to replace the
permission flow, and to add proper ASK_USER handling.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from prompt_toolkit import PromptSession
from prompt_toolkit.application import Application
from prompt_toolkit.formatted_text import FormattedText
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout import Layout
from prompt_toolkit.layout.containers import Window
from prompt_toolkit.layout.controls import FormattedTextControl
from rich.console import Console

from kiss.agent.tools.logic.approval import LogicApprovalReply, LogicApprovalRequest
from kiss.core.types import (
    AskUserReply,
    AskUserRequest,
    PermissionReply,
    PermissionRequest,
    QuestionOption,
)

if TYPE_CHECKING:
    from kiss.ui.shared import InteractionController


async def rich_ask_permission(
    req: PermissionRequest,
    session: PromptSession,
    console: Console,
) -> None:
    """Show a permission prompt with arrow-key selector and resolve the request's future."""
    console.print(
        f"[bold yellow]  🔒 Permission: {req.tool_name or 'tool'} — {req.args}[/bold yellow]"
    )
    allow_cmd_label = "Allow exact" if req.action else "Allow command"
    allow_tool_label = "Allow scope" if req.action else "Allow tool"
    exact_only = bool(req.action and req.action.exact_only)

    labels = ["Allow once", allow_cmd_label]
    if not exact_only:
        labels.append(allow_tool_label)
    labels.append("Deny")

    _REPLY_MAP = {
        "Allow once": PermissionReply.ALLOW,
        allow_cmd_label: PermissionReply.ALLOW_CMD,
        allow_tool_label: PermissionReply.ALLOW_TOOL,
        "Deny": PermissionReply.DENY,
    }

    result = await _run_choice_selector(
        console,
        labels=labels,
        can_freeform=False,
        default_label="Allow once",
    )
    if result.outcome == "selected" and result.selected_choice_ids:
        reply = _REPLY_MAP.get(result.selected_choice_ids[0], PermissionReply.DENY)
    else:
        reply = PermissionReply.DENY
    req.reply_future.set_result(reply)


async def rich_ask_logic_approval(
    req: LogicApprovalRequest,
    session: PromptSession,
    console: Console,
) -> None:
    """Show a batch manifest approval prompt and resolve the request's future."""
    n = len(req.pending_changes)
    body_lines = [
        f"  {c.change_type}: {c.path} ({c.line_count} lines)"
        for c in req.pending_changes
    ]
    console.print(
        f"[bold yellow]  ⚠ Approval: {n} file change{'s' if n != 1 else ''}[/bold yellow]"
    )
    for line in body_lines:
        console.print(f"[yellow]    {line}[/yellow]")
    if not body_lines:
        console.print("    (no changes)")
    result = await _run_choice_selector(
        console,
        labels=["Apply", "Deny"],
        can_freeform=False,
        default_label="Apply",
    )
    approved = result.outcome == "selected" and result.selected_choice_ids == ["Apply"]
    if not req.reply_future.done():
        req.reply_future.set_result(LogicApprovalReply(approved=approved))


async def _run_choice_selector(
    console: Console,
    labels: list[str] | None = None,
    can_freeform: bool = False,
    default_label: str | None = None,
    options: list[QuestionOption] | None = None,
    multi_select: bool = False,
    default_id: str | None = None,
) -> AskUserReply:
    """prompt_toolkit-based arrow-key choice selector.

    Returns AskUserReply with outcome 'selected', 'free_text', or 'cancelled'.
    Falls back to numbered-choice input if the terminal cannot run the app.

    When *options* is provided, rich labels and descriptions are rendered and
    stable IDs are returned in selected_choice_ids.  When only *labels* is
    provided, labels double as IDs for backward compatibility.
    """
    # Normalise to an options list
    if options is not None:
        display_items = [(opt.label, opt.id, opt.description) for opt in options]
    elif labels is not None:
        display_items = [(label, label, None) for label in labels]
    else:
        raise ValueError("Either labels or options must be provided")

    selected_index = 0
    if default_id and options is not None:
        for i, (_, opt_id, _) in enumerate(display_items):
            if opt_id == default_id:
                selected_index = i
                break
    elif default_label and labels is not None:
        if default_label in labels:
            selected_index = labels.index(default_label)

    selected_indices: set[int] = set()

    mode: list[str] = ["select"]  # mutable cell: "select" or "freetext"
    result: list[AskUserReply | None] = [None]

    def _render() -> FormattedText:
        lines: list[tuple[str, str]] = []
        for i, (label, _opt_id, desc) in enumerate(display_items):
            prefix = ""
            if multi_select:
                prefix = "[x] " if i in selected_indices else "[ ] "
            if i == selected_index:
                lines.append(("class:selected", f"  ❯ {prefix}{label}\n"))
            else:
                lines.append(("", f"    {prefix}{label}\n"))
            if desc:
                lines.append(("class:hint", f"      {desc}\n"))
        keys = "↑↓ navigate  Enter confirm  Esc cancel"
        if can_freeform:
            keys += "  Ctrl+T free text"
        if multi_select:
            keys += "  Space toggle"
        lines.append(("class:hint", f"\n  [{keys}]"))
        return FormattedText(lines)

    kb = KeyBindings()

    @kb.add("up")
    def _up(_event: object) -> None:
        nonlocal selected_index
        selected_index = (selected_index - 1) % len(display_items)

    @kb.add("down")
    def _down(_event: object) -> None:
        nonlocal selected_index
        selected_index = (selected_index + 1) % len(display_items)

    @kb.add("space")
    def _space(_event: object) -> None:
        if multi_select:
            if selected_index in selected_indices:
                selected_indices.discard(selected_index)
            else:
                selected_indices.add(selected_index)

    @kb.add("enter")
    def _enter(event: object) -> None:
        if multi_select and selected_indices:
            ids = [display_items[i][1] for i in sorted(selected_indices)]
            result[0] = AskUserReply(outcome="selected", selected_choice_ids=ids)
        else:
            result[0] = AskUserReply(
                outcome="selected",
                selected_choice_ids=[display_items[selected_index][1]],
            )
        import prompt_toolkit.application as _app_mod

        _app_mod.get_app().exit()

    @kb.add("escape")
    def _esc(event: object) -> None:
        result[0] = AskUserReply(outcome="cancelled")
        import prompt_toolkit.application as _app_mod

        _app_mod.get_app().exit()

    @kb.add("c-t")
    def _freetext(event: object) -> None:
        if can_freeform:
            mode[0] = "freetext"
            import prompt_toolkit.application as _app_mod

            _app_mod.get_app().exit()

    @kb.add("c-c")
    def _ctrlc(event: object) -> None:
        result[0] = AskUserReply(outcome="cancelled")
        import prompt_toolkit.application as _app_mod

        _app_mod.get_app().exit()

    layout = Layout(Window(content=FormattedTextControl(text=_render)))
    app: Application[None] = Application(
        layout=layout, key_bindings=kb, full_screen=False
    )

    try:
        await app.run_async()
    except Exception:
        # Terminal can't run the app — fall back to numbered choice
        return await _numbered_choice_fallback(
            console, labels, can_freeform, options, multi_select
        )

    if mode[0] == "freetext":
        # Ctrl+T pressed — switch to free-text entry
        from prompt_toolkit import PromptSession as _PS

        _session: _PS[str] = _PS()
        hint = "  [Enter answer  Ctrl+C cancel]"
        console.print(f"[dim]{hint}[/dim]")
        try:
            text = await _session.prompt_async("Answer: ")
            return AskUserReply(outcome="free_text", text=text)
        except (KeyboardInterrupt, EOFError):
            return AskUserReply(outcome="cancelled")

    return result[0] or AskUserReply(outcome="cancelled")


async def _numbered_choice_fallback(
    console: Console,
    labels: list[str] | None = None,
    can_freeform: bool = False,
    options: list[QuestionOption] | None = None,
    multi_select: bool = False,
) -> AskUserReply:
    """Numbered-choice fallback when arrow-key selector cannot run."""
    from prompt_toolkit import PromptSession as _PS

    _session: _PS[str] = _PS()

    if options is not None:
        display_items = [(opt.label, opt.id, opt.description) for opt in options]
    elif labels is not None:
        display_items = [(label, label, None) for label in labels]
    else:
        raise ValueError("Either labels or options must be provided")

    for i, (label, _opt_id, desc) in enumerate(display_items, 1):
        line = f"  [dim][{i}][/dim] {label}"
        if desc:
            line += f"  [dim]({desc})[/dim]"
        console.print(line)
    if can_freeform:
        console.print(f"  [dim][{len(display_items) + 1}][/dim] Enter free text")

    if multi_select:
        hint = f"Choices (comma-separated) [1-{len(display_items)}]: "
        try:
            raw = await _session.prompt_async(hint)
            raw = raw.strip()
            if not raw:
                return AskUserReply(outcome="cancelled")
            indices = [
                int(x.strip()) - 1 for x in raw.split(",") if x.strip().isdigit()
            ]
            valid = [i for i in indices if 0 <= i < len(display_items)]
            if valid:
                ids = [display_items[i][1] for i in valid]
                return AskUserReply(outcome="selected", selected_choice_ids=ids)
            return AskUserReply(outcome="cancelled")
        except (KeyboardInterrupt, EOFError):
            return AskUserReply(outcome="cancelled")

    hint = f"Choice [1-{len(display_items) + (1 if can_freeform else 0)}]: "
    try:
        raw = await _session.prompt_async(hint)
        raw = raw.strip()
        if raw.isdigit():
            idx = int(raw) - 1
            if 0 <= idx < len(display_items):
                return AskUserReply(
                    outcome="selected", selected_choice_ids=[display_items[idx][1]]
                )
            if can_freeform and idx == len(display_items):
                text = await _session.prompt_async("Answer: ")
                return AskUserReply(outcome="free_text", text=text)
        return AskUserReply(outcome="cancelled")
    except (KeyboardInterrupt, EOFError):
        return AskUserReply(outcome="cancelled")


async def rich_ask_user(
    req: AskUserRequest,
    session: PromptSession,
    console: Console,
    controller: InteractionController | None = None,
    notify_enabled: bool = True,
) -> None:
    """Print the agent's question and prompt the user to answer.

    When the request has options, presents an arrow-key selector (with
    numbered fallback). When type is "text" or "choice_or_text", uses
    plain line editing. Resolves the asyncio.Future on *req* with
    AskUserReply before returning.
    """
    if controller is not None:
        controller.register(req)
        req.reply_future.add_done_callback(
            lambda _f: controller.deregister(req) if controller else None
        )

    console.print("")
    console.print(f"[bold ui.text.accent]  ❓ {req.header}[/bold ui.text.accent]")
    console.print(f"[ui.text.primary]    {req.question}[/ui.text.primary]")

    if req.options:
        reply = await _run_choice_selector(
            options=list(req.options),
            can_freeform=req.type in ("text", "choice_or_text"),
            default_id=req.default_id,
            console=console,
            multi_select=req.multi_select,
        )
    else:
        keys_hint = "  [dim][Enter submit  Ctrl+C cancel][/dim]"
        console.print(keys_hint)
        try:
            answer = await session.prompt_async("Answer: ")
            reply = AskUserReply.from_text(answer)
        except (KeyboardInterrupt, EOFError):
            reply = AskUserReply(outcome="cancelled")

    if not req.reply_future.done():
        req.reply_future.set_result(reply)
