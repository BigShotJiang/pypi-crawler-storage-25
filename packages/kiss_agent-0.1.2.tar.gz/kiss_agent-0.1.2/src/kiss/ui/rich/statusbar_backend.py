"""Proposition C — Rich backend with a persistent status bar + inline post-turn summary.

No layout split. Chat output prints normally via console.print(). During
streaming, a single-line status bar is rendered via rich.live.Live at the
"bottom" of the visible output. After each turn a compact info block
(todos, file changes, token stats) is printed inline.

Activated via: kiss --ui statusbar
"""

from __future__ import annotations

import asyncio
import msgspec
import time
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.rule import Rule
from rich.spinner import Spinner
from rich.table import Table
from rich.text import Text

from prompt_toolkit import PromptSession
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.history import FileHistory
from prompt_toolkit.styles import Style

from kiss.core.settings import get_context_window, model_supports_prompt_caching
from kiss.core.types import EventKind, TodoUpdateMeta
from kiss.ui.base import UIBackend
from kiss.core.pricing import estimate_cost
from kiss.ui.shared import (
    InteractionController,
    SessionTotals,
    _MUTATING_TOOLS,
    classify_auth_error,
    create_token_budget,
    create_tool_result_display,
    count_diff_lines,
    describe_exception,
    format_tool_call,
    notify_user,
    require_event_field,
)
from kiss.data.ui_tokens import DEFAULT_TOKENS as _T
from kiss.ui.slash import slash_commands_for, slash_help_markup
from kiss.ui.commands import (
    connect_provider,
    get_auth_status,
    get_free_models,
    get_free_provider_status,
    get_models,
    get_provider_status,
    list_sessions,
    logout_provider,
    parse_command,
    persist_connect,
    run_clear,
    run_compact,
    run_resume,
    switch_model,
    toggle_free_provider,
)
from kiss.ui.rich.interactive_picker import run_picker
from kiss.ui.fuzzy import suggest_command
from kiss.ui.observability import ObservabilityState
from kiss.ui.activity import GroupActivityTracker
from kiss.ui.prompt_history import workspace_history_file
from kiss.ui.truncation_store import cleanup_expired
from kiss.ui.session_state import UISessionState
from kiss.ui.rich.statusbar_data import RichStatusBarData
from kiss.ui.rich.permission import (
    rich_ask_logic_approval,
    rich_ask_permission,
    rich_ask_user,
)

if TYPE_CHECKING:
    from kiss.agent.loop import KissAgent
    from kiss.core.settings import Settings


def _provider_ready(provider_type: str) -> bool:
    from kiss.providers.auth import provider_is_ready

    return provider_is_ready(provider_type)


def _render_todo_update(console: Console, meta: TodoUpdateMeta) -> None:
    parts: list[str] = []
    if meta.delta and not meta.delta.is_empty():
        if meta.delta.added:
            parts.append(f"[ui.text.success]+{len(meta.delta.added)}[/]")
        if meta.delta.completed:
            parts.append(f"[ui.text.success]✓{len(meta.delta.completed)}[/]")
        if meta.delta.reopened:
            parts.append(f"[ui.text.warning]↺{len(meta.delta.reopened)}[/]")
        if meta.delta.removed:
            parts.append(f"[ui.text.error]−{len(meta.delta.removed)}[/]")
    delta_str = "  ".join(parts)
    status = (
        "[ui.text.success bold]all done[/]"
        if meta.all_done
        else f"[ui.text.muted]{meta.pending_count} pending[/]"
    )
    console.print(f"[ui.text.subtle]  ☐ todos  {delta_str}  {status}[/]")


def _workspace_history_file() -> Path:
    """Backward-compatible wrapper around the shared history-path helper."""
    return workspace_history_file(Path.cwd())


def _status_bar(sidebar: RichStatusBarData, label: str = "thinking…") -> Table:
    """Render a single-row Rich Table as the transient streaming status."""
    t = Table.grid(padding=(0, 1))
    t.add_column(no_wrap=True)
    t.add_column(no_wrap=True, ratio=1)
    t.add_row(
        Spinner("dots", style="ui.text.accent"),
        Text(label, style="ui.text.muted italic"),
    )
    return t


_TRANSCRIPT_MAX_COLS = 100


class RichStatusBarBackend(UIBackend):
    """Terminal UI with normal scrolling output + a persistent 1-line status bar.

    Chat messages print to the terminal as usual (scrollable). A Live panel
    at the foot of the screen shows compact real-time stats. After each turn
    a summary block (todos, file changes) is printed inline.
    """

    def __init__(self) -> None:
        from kiss.ui.rich.theme import build_rich_theme

        self.console = Console(theme=build_rich_theme())
        self._obs = ObservabilityState()
        self._tracker = GroupActivityTracker(self._obs.chat_activity)
        self._ui_state = UISessionState()
        self._warning_label: str = ""
        self._interaction_controller = InteractionController()
        self._show_thinking: bool = True
        self._turn_stats = SessionTotals()

    def _transcript_width(self) -> int:
        return min(_TRANSCRIPT_MAX_COLS, self.console.width)

    async def _ensure_codex_auth(self) -> bool:
        """Run browser auth if Codex tokens are missing. Returns True when ready."""
        from kiss.providers.codex_auth import load_codex_tokens, run_codex_browser_auth

        if load_codex_tokens() is not None:
            return True
        self.console.print("[dim]Opening browser for Codex authorization…[/dim]")

        def on_url(url: str) -> None:
            self.console.print(f"[dim]Or visit: {url}[/dim]")

        try:
            success = await run_codex_browser_auth(on_url=on_url)
        except asyncio.CancelledError:
            self.console.print("[yellow]Codex authentication cancelled.[/yellow]")
            return False
        if success:
            self.console.print("[green]✓ Codex authentication successful.[/green]")
        else:
            self.console.print("[red]✗ Codex authentication failed or timed out.[/red]")
        return success

    async def _ensure_copilot_auth(self) -> bool:
        """Run device auth if Copilot token is missing. Returns True when ready."""
        from kiss.providers.copilot_auth import (
            clear_github_token,
            load_github_token,
            run_copilot_device_auth,
        )
        from kiss.providers.manager import probe_copilot_token

        if load_github_token():
            try:
                await probe_copilot_token()
                return True
            except Exception as exc:
                message = describe_exception(exc).lower()
                if "401" not in message:
                    self.console.print(
                        "[red]Copilot token check failed.[/red]\n"
                        f"Details: {describe_exception(exc)}"
                    )
                    return False
                clear_github_token()
                self.console.print(
                    "[yellow]Stored GitHub token was rejected; re-authenticating…[/yellow]"
                )
        self.console.print("[dim]Starting GitHub Copilot device authorization…[/dim]")

        def on_code(verification_uri: str, user_code: str) -> None:
            self.console.print(
                f"Visit [bold]{verification_uri}[/bold] and enter code: "
                f"[bold yellow]{user_code}[/bold yellow]"
            )

        try:
            success = await run_copilot_device_auth(on_code=on_code)
        except asyncio.CancelledError:
            self.console.print("[yellow]Copilot authentication cancelled.[/yellow]")
            return False
        if success:
            self.console.print("[green]✓ Copilot authentication successful.[/green]")
        else:
            self.console.print(
                "[red]✗ Copilot authentication failed or timed out.[/red]"
            )
        return success

    async def run(self, agent: "KissAgent", settings: "Settings") -> None:
        self._settings = settings
        self._show_thinking = getattr(settings, "show_thinking", True)
        await asyncio.to_thread(cleanup_expired)
        sidebar = RichStatusBarData()
        if agent:
            sidebar.set_models([agent.model_label])

        window = get_context_window(
            settings.model_id,
            settings.context_window,
        )
        sidebar.context_window = window
        sidebar.prompt_caching = model_supports_prompt_caching(settings.model_id)

        from kiss.ui.shared import render_startup_banner

        self.console.print(render_startup_banner(settings.model_id, window))

        provider_type = settings.effective_provider_type
        if provider_type in ("openai-codex", "openai") and not _provider_ready(
            provider_type
        ):
            await self._ensure_codex_auth()
        elif provider_type == "copilot":
            await self._ensure_copilot_auth()

        history_file = _workspace_history_file()
        history_file.parent.mkdir(parents=True, exist_ok=True)
        slash_completer = WordCompleter(
            [cmd.name for cmd in slash_commands_for("rich")],
            sentence=True,
        )
        session: PromptSession = PromptSession(
            history=FileHistory(str(history_file)),
            completer=slash_completer,
            complete_while_typing=False,
            enable_suspend=True,
            mouse_support=False,
            style=Style.from_dict({"bottom-toolbar": "bg:default noreverse"}),
        )
        while True:
            try:
                self.console.print(Rule(style="ui.border.subtle"))
                sep_width = min(80, self.console.width or 80)
                user_input = await session.prompt_async(
                    HTML("<b><ansicyan>▋</ansicyan></b> "),
                    bottom_toolbar=lambda: HTML(
                        (
                            f'<style fg="{_T.text_warning}">  ⚠ {self._warning_label}</style>\n'
                            if self._warning_label
                            else ""
                        )
                        + f'<style fg="{_T.border_default}">{"─" * sep_width}</style>\n'
                        + sidebar.render_toolbar()
                        + "  <dim>↑/↓ history · Tab complete · /help commands</dim>"
                    ),
                )
            except KeyboardInterrupt:
                break
            except EOFError:
                self.console.print("[dim]Cancelled.[/]")
                continue

            if not user_input.strip():
                continue

            if user_input.lower() in ("/exit", "/quit"):
                break

            if user_input.startswith("/"):
                await self._handle_command(agent, session, user_input, sidebar)
                continue

            await self._run_turn(agent, session, user_input, sidebar)

        self._interaction_controller.cancel_all()
        if sidebar.turn_count > 0:
            self.console.print(Rule(style="ui.border.subtle"))
            self.console.print(sidebar.render_summary())
        self.console.print("\n[dim]Goodbye![/]")
        await asyncio.to_thread(cleanup_expired)

    # ── Turn execution ─────────────────────────────────────────────────────

    async def _run_turn(
        self,
        agent: "KissAgent",
        session: PromptSession,
        message: str,
        sidebar: RichStatusBarData,
    ) -> str:
        self.console.print(Rule(style="ui.border.subtle"))

        token_buf: list[str] = []
        reply_buf: list[str] = []
        thought_buf: list[str] = []
        thought_id_cell: list[str | None] = [
            None
        ]  # mutable cell for current thought_id
        thought_phase_cell: list[str | None] = [
            None
        ]  # mutable cell for current thought phase
        stream_live: Live | None = None  # non-transient: streaming text stays on screen
        status_live: Live | None = None  # transient: spinner during tool calls
        thought_live: Live | None = None  # transient: thought streaming
        _last_render: list[float] = [0.0]  # mutable cell for 50ms throttle

        def _stop_stream() -> str:
            """Finalize the streaming live; text remains on screen. Returns full text."""
            nonlocal stream_live
            if stream_live is not None:
                stream_live.update(Markdown("".join(token_buf), justify="left"))
                stream_live.stop()
                stream_live = None
            text = "".join(token_buf)
            token_buf.clear()
            return text

        def _stop_status() -> None:
            nonlocal status_live
            if status_live is not None:
                status_live.stop()
                status_live = None

        def _stop_thought() -> None:
            nonlocal thought_live
            if thought_live is not None:
                thought_live.stop()
                thought_live = None
                if thought_buf:
                    full = "".join(thought_buf)
                    phase = thought_phase_cell[0]
                    phase_prefix = f"[{phase}] " if phase else ""
                    self.console.print(
                        f"[ui.text.subtle]    {phase_prefix}Thinking: {full}[/]"
                    )
                    thought_buf.clear()
                    thought_id_cell[0] = None
                    thought_phase_cell[0] = None

        def _start_status(label: str) -> Live:
            live_obj = Live(
                _status_bar(sidebar, label),
                console=self.console,
                auto_refresh=True,
                refresh_per_second=10,
                transient=True,
            )
            live_obj.start()
            return live_obj

        turn_start = time.monotonic()
        self._ui_state.on_streaming()
        try:
            async for event in agent.send(message):
                if event.kind == EventKind.TOKEN:
                    self._warning_label = ""
                    _stop_thought()
                    _stop_status()
                    token_buf.append(event.token)
                    if stream_live is None:
                        stream_live = Live(
                            Markdown("".join(token_buf), justify="left"),
                            console=self.console,
                            auto_refresh=True,
                            refresh_per_second=15,
                            transient=False,
                            vertical_overflow="visible",
                        )
                        stream_live.start()
                        _last_render[0] = time.monotonic()
                    else:
                        now = time.monotonic()
                        if now - _last_render[0] >= 0.050:
                            stream_live.update(
                                Markdown("".join(token_buf), justify="left")
                            )
                            _last_render[0] = now

                elif event.kind == EventKind.TOOL_CALL:
                    self._warning_label = ""
                    text = _stop_stream()
                    if text:
                        reply_buf.append(text)
                    _stop_thought()
                    _stop_status()
                    call = require_event_field(event.call, "call", "TOOL_CALL")
                    tool_label = format_tool_call(call.name, call.args)
                    self._ui_state.on_tool_call(tool_label)
                    group_summary = self._tracker.on_tool_call(
                        call.name, call.id, tool_label
                    )
                    if group_summary is not None:
                        hint = f"  [dim](expand: /detail {group_summary.activity_id})[/dim]"
                        self.console.print(
                            f"[dim]  ⊕ {group_summary.render_rich()}{hint}[/dim]"
                        )
                    status_live = _start_status(tool_label)

                elif event.kind == EventKind.PERMISSION:
                    permission = require_event_field(
                        event.permission, "permission", "PERMISSION"
                    )
                    _stop_stream()
                    _stop_thought()
                    _stop_status()
                    self._ui_state.on_blocked_permission()
                    await rich_ask_permission(permission, session, self.console)
                    self._ui_state.on_unblocked()
                    status_live = _start_status("thinking…")

                elif event.kind == EventKind.LOGIC_APPROVAL:
                    logic_approval = require_event_field(
                        event.logic_approval, "logic_approval", "LOGIC_APPROVAL"
                    )
                    _stop_stream()
                    _stop_thought()
                    _stop_status()
                    self._ui_state.on_blocked_permission()
                    await rich_ask_logic_approval(logic_approval, session, self.console)
                    self._ui_state.on_unblocked()
                    status_live = _start_status("thinking…")

                elif event.kind == EventKind.ASK_USER:
                    ask_user = require_event_field(
                        event.ask_user, "ask_user", "ASK_USER"
                    )
                    _stop_stream()
                    _stop_status()
                    self._ui_state.on_blocked_user_input()
                    notify_user(
                        ask_user.header,
                        ask_user.question,
                        enabled=self._settings.notify_enabled,
                    )
                    await rich_ask_user(
                        ask_user,
                        session,
                        self.console,
                        controller=self._interaction_controller,
                        notify_enabled=self._settings.notify_enabled,
                    )
                    self._ui_state.on_unblocked()
                    status_live = _start_status("thinking…")

                elif event.kind == EventKind.TODO_UPDATE:
                    if event.todos is not None:
                        sidebar.set_todos(event.todos)
                    if event.todo_meta is not None:
                        _render_todo_update(self.console, event.todo_meta)

                elif event.kind == EventKind.TOOL_RESULT:
                    result = require_event_field(event.result, "result", "TOOL_RESULT")
                    added = removed = 0
                    if result.path is not None and result.name in _MUTATING_TOOLS:
                        path = result.path
                        added, removed = await asyncio.to_thread(count_diff_lines, path)
                        sidebar.record_file_change(path, added, removed)
                    display = result.display or create_tool_result_display(
                        result.name,
                        result.output,
                        is_err=result.is_err,
                        path=result.path,
                    )
                    summary = display.summary
                    if result.path is not None:
                        summary = f"{summary}  +{added} -{removed}"
                    display.summary = summary
                    self._tracker.on_tool_result(
                        result.call_id,
                        display.summary,
                        is_err=result.is_err,
                    )
                    self._ui_state.on_tool_result()
                    _stop_status()
                    _verbose = (
                        display.interaction is not None
                        and display.interaction.visibility_profile == "verbose"
                    )
                    if display.status == "error":
                        tr = Text()
                        tr.append("    ")
                        tr.append("! ", style="ui.text.error")
                        tr.append(display.title, style="ui.text.error bold")
                        tr.append(": ", style="ui.text.error")
                        tr.append(display.summary, style="ui.text.error")
                        self.console.print(tr)
                    elif _verbose:
                        tr = Text()
                        tr.append("    ")
                        tr.append(display.title, style="ui.text.subtle")
                        tr.append(": ", style="ui.text.subtle")
                        tr.append(display.summary, style="ui.text.muted")
                        self.console.print(tr)
                    elif not self._tracker.is_grouping():
                        tr = Text()
                        tr.append("    ")
                        tr.append(display.title, style="ui.text.subtle")
                        tr.append("  ")
                        tr.append(display.summary, style="ui.text.muted")
                        tr.append("  ✓", style="ui.text.success")
                        self.console.print(tr)
                    status_live = _start_status("thinking…")

                elif event.kind == EventKind.STUCK_LOOP:
                    _stop_stream()
                    _stop_thought()
                    _stop_status()
                    if event.severity == "error":
                        self._ui_state.on_error(event.info)
                        self._warning_label = f"! {event.info[:60]}"
                        self.console.print(
                            f"[bold ui.text.error]  ! {event.info}[/bold ui.text.error]"
                        )
                    else:
                        self._ui_state.on_warning(event.info)
                        self._warning_label = event.info[:60]
                        self.console.print(
                            f"[ui.text.warning]  ⚠ {event.info}[/ui.text.warning]"
                        )
                    status_live = _start_status("thinking…")

                elif event.kind == EventKind.THINKING:
                    if not self._show_thinking:
                        continue
                    if thought_id_cell[0] != event.thought_id:
                        _stop_thought()
                    thought_id_cell[0] = event.thought_id
                    thought_phase_cell[0] = event.phase
                    if event.thought_id is not None:
                        self._obs.thoughts.append(event.thought_id, event.thought)
                    if thought_live is None:
                        _stop_status()
                        thought_buf.clear()
                        phase = event.phase or ""
                        phase_prefix = f"[{phase}] " if phase else ""
                        thought_buf.append(f"    {phase_prefix}Thinking: ")
                    thought_buf.append(event.thought)
                    if thought_live is None:
                        thought_live = Live(
                            Text("".join(thought_buf)),
                            console=self.console,
                            auto_refresh=True,
                            refresh_per_second=10,
                            transient=True,
                        )
                        thought_live.start()
                    else:
                        thought_live.update(Text("".join(thought_buf)))

                elif event.kind == EventKind.INFO:
                    if event.info and event.info.startswith("⏱"):
                        # timing summary — shown in per-turn metrics line instead
                        pass
                    else:
                        _stop_stream()
                        _stop_thought()
                        _stop_status()
                        self.console.print(
                            f"[ui.text.muted]  ℹ {event.info}[/ui.text.muted]"
                        )
                        status_live = _start_status("thinking…")

                elif event.kind == EventKind.COMPACTING:
                    text = _stop_stream()
                    if text:
                        reply_buf.append(text)
                    _stop_thought()
                    _stop_status()
                    self.console.print(
                        f"[ui.text.muted]  ℹ {event.info}[/ui.text.muted]"
                    )
                    status_label = "compacting context…"
                    if "self-healing retry" in event.info:
                        status_label = "self-healing retry…"
                    elif "self-compaction requested" in event.info:
                        status_label = "self-compacting…"
                    self._ui_state.on_compacting(status_label)
                    status_live = _start_status(status_label)

                elif event.kind == EventKind.COMPACTED:
                    _stop_stream()
                    _stop_thought()
                    _stop_status()
                    self._ui_state.on_compacted()
                    self.console.print(
                        f"[ui.text.muted]  ℹ {event.info}[/ui.text.muted]"
                    )

                elif event.kind == EventKind.DONE:
                    text = _stop_stream()
                    if text:
                        reply_buf.append(text)
                    _stop_thought()
                    _stop_status()
                    final_group = self._tracker.flush()
                    if final_group is not None:
                        hint = (
                            f"  [dim](expand: /detail {final_group.activity_id})[/dim]"
                        )
                        self.console.print(
                            f"[dim]  ⊕ {final_group.render_rich()}{hint}[/dim]"
                        )
                    # Update stats via shared SessionTotals accumulator
                    finish_reason = self._turn_stats.accumulate(event.turn_usage)
                    _tu = event.turn_usage
                    turn_input = _tu.input_tokens if _tu else 0
                    turn_output = _tu.output_tokens if _tu else 0
                    turn_thinking = _tu.thinking_tokens if _tu else 0
                    context_window = get_context_window(
                        agent.settings.model_id,
                        agent.settings.context_window,
                    )
                    _model_id = (
                        agent.model_label.split(":", 1)[-1]
                        if ":" in agent.model_label
                        else agent.model_label
                    )
                    cost = (
                        estimate_cost(
                            _model_id,
                            self._turn_stats.input_tokens,
                            self._turn_stats.output_tokens,
                            self._turn_stats.cache_read_tokens,
                            self._turn_stats.cache_write_tokens,
                        )
                        or 0.0
                    )
                    sidebar.update_session(
                        turn_count=self._turn_stats.turn_count,
                        input_tokens=self._turn_stats.input_tokens,
                        output_tokens=self._turn_stats.output_tokens,
                        cost_usd=cost,
                        token_budget=create_token_budget(
                            _tu.message_budget if _tu else {}
                        ),
                        context_window=context_window,
                        cache_read_tokens=self._turn_stats.cache_read_tokens,
                        cache_write_tokens=self._turn_stats.cache_write_tokens,
                        finish_reason=finish_reason,
                        thinking_tokens=self._turn_stats.thinking_tokens,
                    )
                    sidebar.set_models([agent.model_label])
                    sidebar.prompt_caching = model_supports_prompt_caching(
                        agent.settings.model_id
                    )
                    self._ui_state.on_done(
                        input_tokens=turn_input,
                        output_tokens=turn_output,
                        cache_read_tokens=_tu.cache_read_tokens if _tu else 0,
                        cache_write_tokens=_tu.cache_write_tokens if _tu else 0,
                        thinking_tokens=turn_thinking,
                        cost_usd=cost,
                        context_window=context_window,
                        finish_reason=finish_reason,
                        model_label=agent.model_label,
                    )
                    turn_elapsed = time.monotonic() - turn_start

                    def _tok(n: int) -> str:
                        if n >= 1_000_000:
                            return f"{n / 1_000_000:.1f}m"
                        if n >= 1_000:
                            return f"{n / 1_000:.0f}k"
                        return str(n)

                    ctx = context_window or 1
                    pct = min(100, turn_input * 100 // ctx)
                    turn_cost = (
                        estimate_cost(
                            _model_id,
                            turn_input,
                            turn_output,
                            _tu.cache_read_tokens if _tu else 0,
                            _tu.cache_write_tokens if _tu else 0,
                        )
                        or 0.0
                    )
                    tok_parts = [
                        f"↑{_tok(turn_input)}/{_tok(ctx)} ({pct}%)",
                        f"↓{_tok(turn_output)}",
                    ]
                    if turn_thinking:
                        tok_parts.append(f"think {_tok(turn_thinking)}")
                    tok_parts.append(f"{turn_elapsed:.1f}s")
                    if turn_cost:
                        tok_parts.append(f"${turn_cost:.4f}")
                    self.console.print(f"[#666666]  {' │ '.join(tok_parts)}[/#666666]")

                elif event.kind == EventKind.DEGRADED:
                    from rich.panel import Panel

                    self.console.print(
                        Panel(
                            event.info,
                            title="[bold red]DEGRADED[/bold red]",
                            border_style="red",
                            padding=(0, 1),
                        )
                    )
                    self._warning_label = "DEGRADED: ALL PROVIDERS UNHEALTHY"

                elif event.kind == EventKind.CANCELLED:
                    _stop_stream()
                    _stop_thought()
                    _stop_status()
                    self._ui_state.on_cancelled()
                    self.console.print("[dim]  ↳ cancelled[/dim]")

                elif event.kind == EventKind.ERROR:
                    _stop_stream()
                    _stop_thought()
                    _stop_status()
                    error = require_event_field(event.error, "error", "ERROR")
                    if isinstance(error, asyncio.CancelledError):
                        self._ui_state.on_cancelled()
                        self.console.print("[dim]  ↳ cancelled[/dim]")
                    else:
                        self._ui_state.on_error(str(error))
                        auth_info = classify_auth_error(error)
                        if auth_info is not None:
                            title, body = auth_info
                            self.console.print(
                                f"[bold ui.text.error]  ! {title}:[/bold ui.text.error] {body}"
                            )
                        else:
                            self.console.print(
                                f"[bold ui.text.error]  ! Error:[/bold ui.text.error] {error}"
                            )
        finally:
            _stop_stream()
            _stop_thought()
            _stop_status()

        return "".join(reply_buf)

    # ── Slash commands ─────────────────────────────────────────────────────

    async def _handle_command(
        self,
        agent: "KissAgent",
        session: PromptSession,
        raw: str,
        sidebar: RichStatusBarData,
    ) -> None:
        name, args = parse_command(raw)

        if name == "/model":
            if not args:
                free_active = any(agent.settings.free_providers.values())
                if free_active:
                    # Free mode: show only free models from enabled providers.
                    free_models = get_free_models(agent)
                    if free_models:
                        picker_items: list[tuple[str, str | None]] = [
                            (
                                m.model_id,
                                f"context: {get_context_window(m.model_id.split(':', 1)[-1]):,} tokens"
                                + " [free]"
                                + (" [active]" if m.active else ""),
                            )
                            for m in free_models
                        ]
                        idx = await run_picker(
                            self.console, picker_items, title="Select free model"
                        )
                        if idx is not None:
                            args = [free_models[idx].model_id]
                        else:
                            return
                    else:
                        self.console.print(
                            "No free models available. Use [bold]/free[/bold] to enable a provider."
                        )
                        return
                else:
                    # Normal mode: fetch all models for current provider.
                    provider = agent.settings.provider_alias
                    all_models = await get_models(agent, provider)
                    if all_models:
                        picker_items: list[tuple[str, str | None]] = [
                            (
                                m.model_id,
                                f"context: {get_context_window(m.model_id.split(':', 1)[-1]):,} tokens"
                                + (" [active]" if m.active else ""),
                            )
                            for m in all_models
                        ]
                        idx = await run_picker(
                            self.console,
                            picker_items,
                            title=f"Select model ({provider})",
                        )
                        if idx is not None:
                            args = [all_models[idx].model_id]
                        else:
                            return
                    else:
                        model = agent.settings.model
                        window = get_context_window(
                            agent.settings.model_id,
                            agent.settings.context_window,
                        )
                        self.console.print(
                            f"Current model: [cyan]{model}[/]  "
                            f"context: [dim]{window:,} tokens[/]"
                        )
                        return
            if args:
                previous_model = agent.settings.model
                try:
                    switch_model(agent, args[0])
                except ValueError as e:
                    self.console.print(f"[red]Error:[/] {e}")
                    return

                new_type = agent.settings.effective_provider_type
                auth_ok = True
                if new_type in ("openai-codex", "openai") and not _provider_ready(
                    new_type
                ):
                    auth_ok = await self._ensure_codex_auth()
                elif new_type == "copilot":
                    auth_ok = await self._ensure_copilot_auth()

                if not auth_ok:
                    try:
                        switch_model(agent, previous_model)
                    except Exception:  # nosec B110
                        pass
                    sidebar.set_models([agent.model_label])
                    return

                window = get_context_window(
                    agent.settings.model_id,
                    agent.settings.context_window,
                )
                self.console.print(
                    f"[green]Switched to[/] [cyan]{args[0]}[/]  "
                    f"context: [dim]{window:,} tokens[/]"
                )
                sidebar.set_models([agent.model_label])

        elif name == "/providers":
            statuses = get_provider_status(agent)
            auth_by_name = {s.name: s for s in get_auth_status(agent)}

            if args and args[0] == "status":
                # Full diagnostic table with last_error
                table = Table(
                    show_header=True, header_style="bold dim", box=None, padding=(0, 1)
                )
                table.add_column("Provider")
                table.add_column("Type", style="dim")
                table.add_column("Health")
                table.add_column("Auth")
                table.add_column("Last Error", style="dim")
                for s in statuses:
                    health_str = {
                        "healthy": "[green]healthy[/green]",
                        "degraded": "[yellow]degraded[/yellow]",
                        "unhealthy": "[red]unhealthy[/red]",
                    }.get(s.health, "[dim]?[/dim]")
                    auth = auth_by_name.get(s.alias)
                    auth_type_label = auth.auth_type if auth else ""
                    auth_str = (
                        f"[green]✓[/green] {auth_type_label}"
                        if s.ready
                        else f"[red]✗[/red] {auth_type_label}"
                    )
                    name_str = f"[bold]{s.alias}[/bold]" + (
                        " [cyan](active)[/cyan]" if s.active else ""
                    )
                    table.add_row(
                        name_str,
                        s.provider_type,
                        health_str,
                        auth_str,
                        s.last_error[:50] or "—",
                    )
                self.console.print(table)
            else:
                table = Table(
                    show_header=True, header_style="bold dim", box=None, padding=(0, 1)
                )
                table.add_column("")
                table.add_column("Provider")
                table.add_column("Auth", style="dim")
                table.add_column("Authenticated")
                table.add_column("Health")
                for s in statuses:
                    if s.active:
                        marker = "[green]●[/green]"
                    elif not s.ready:
                        marker = "[red]✗[/red]"
                    elif s.health == "unhealthy":
                        marker = "[dim red]✗[/dim red]"
                    elif s.health == "degraded":
                        marker = "[yellow]⚠[/yellow]"
                    else:
                        marker = ""
                    auth = auth_by_name.get(s.alias)
                    auth_type = auth.auth_type if auth else ""
                    cred_source = (
                        f" ({auth.credential_source})"
                        if auth and auth.credential_source != "none"
                        else ""
                    )
                    auth_str = (
                        f"[green]✓[/green]{cred_source}" if s.ready else "[red]✗[/red]"
                    )
                    health_str = {
                        "healthy": "[green]healthy[/green]",
                        "degraded": "[yellow]degraded[/yellow]",
                        "unhealthy": "[red]unhealthy[/red]",
                    }.get(s.health, "[dim]?[/dim]")
                    name_str = f"[bold]{s.alias}[/bold]"
                    if s.active:
                        name_str += " [cyan](active)[/cyan]"
                    table.add_row(marker, name_str, auth_type, auth_str, health_str)
                self.console.print(table)

        elif name == "/free":
            if args:
                try:
                    new_state = toggle_free_provider(agent, args[0])
                    state_str = "enabled" if new_state else "disabled"
                    self.console.print(
                        f"[green]{args[0]}[/] free models: [bold]{state_str}[/]"
                    )
                except KeyError:
                    self.console.print(
                        f"[red]Provider '{args[0]}' not found or has no free models.[/]"
                    )
            else:
                rows = get_free_provider_status(agent)
                if not rows:
                    self.console.print("[dim]No providers with free models found.[/]")
                else:
                    picker_items: list[tuple[str, str | None]] = [
                        (
                            f"{'✓' if r.enabled else '○'} {r.display_name}",
                            f"{r.free_model_count} free model(s)"
                            + (" · authenticated" if r.ready else " · no credentials"),
                        )
                        for r in rows
                    ]
                    idx = await run_picker(
                        self.console, picker_items, title="Toggle free provider access"
                    )
                    if idx is not None:
                        try:
                            new_state = toggle_free_provider(agent, rows[idx].name)
                            state_str = "enabled" if new_state else "disabled"
                            self.console.print(
                                f"[green]{rows[idx].display_name}[/] free models: [bold]{state_str}[/]"
                            )
                        except KeyError:
                            self.console.print("[red]Toggle failed.[/]")

        elif name == "/connect":
            statuses = get_auth_status(agent)
            if not statuses:
                self.console.print("[dim]No providers registered.[/]")
                return
            picker_items: list[tuple[str, str | None]] = [
                (
                    ("● " if s.ready else "  ") + s.display_name,
                    s.auth_type
                    + (
                        f" · signup: {s.signup_url}"
                        if not s.ready and s.signup_url
                        else ""
                    ),
                )
                for s in statuses
            ]
            idx = await run_picker(
                self.console, picker_items, title="Connect a provider"
            )
            if idx is None:
                return
            target = statuses[idx].name

            def _on_event(event_type: str, data: dict) -> None:
                if event_type == "opening_browser":
                    self.console.print(
                        f"[dim]Opening browser… or visit: {data.get('url', '')}[/]"
                    )
                elif event_type == "waiting_for_input":
                    self.console.print(
                        f"Visit [bold]{data.get('verification_uri', '')}[/bold] "
                        f"and enter code: [bold yellow]{data.get('user_code', '')}[/bold yellow]"
                    )

            try:
                credential = await connect_provider(agent, target, on_event=_on_event)
            except Exception as exc:
                self.console.print(f"[red]Auth error:[/] {exc}")
                return

            if credential is None:
                from kiss.providers.registry import get_provider_profile

                profile = get_provider_profile(target)
                env_hint = (
                    f" (or set {profile.env_vars[0]})"
                    if profile and profile.env_vars
                    else ""
                )
                try:
                    from prompt_toolkit import PromptSession as _PS
                    from prompt_toolkit.key_binding import KeyBindings

                    kb = KeyBindings()

                    @kb.add("escape")
                    def esc(event: object) -> None:
                        import prompt_toolkit.application as _mod

                        _mod.get_app().exit(exception=EOFError, style="class:aborting")

                    _pw_session: _PS[str] = _PS()
                    credential = await _pw_session.prompt_async(
                        f"Enter API key for {target}{env_hint}: ",
                        is_password=True,
                        key_bindings=kb,
                    )
                    credential = credential.strip()
                except (KeyboardInterrupt, EOFError):
                    self.console.print("[dim]Cancelled.[/]")
                    return
                if not credential:
                    self.console.print("[yellow]No key entered; cancelled.[/]")
                    return

            persist_connect(target, credential)
            self.console.print(f"[green]✓ Connected to {target}.[/]")

        elif name == "/logout":
            statuses = [s for s in get_auth_status(agent) if s.ready]
            if not statuses:
                self.console.print("[dim]No authenticated providers to log out of.[/]")
                return
            picker_items: list[tuple[str, str | None]] = [
                (
                    f"● {s.display_name}",
                    f"{s.auth_type} · {s.credential_source}",
                )
                for s in statuses
            ]
            idx = await run_picker(
                self.console, picker_items, title="Logout from provider"
            )
            if idx is None:
                return
            target = statuses[idx].name
            try:
                from prompt_toolkit import PromptSession as _PS

                _confirm_session: _PS[str] = _PS()
                confirm = await _confirm_session.prompt_async(
                    f"Remove credentials for '{target}'? [y/N]: "
                )
                confirm = confirm.strip().lower()
            except (KeyboardInterrupt, EOFError):
                self.console.print("[dim]Cancelled.[/]")
                return
            if confirm not in ("y", "yes"):
                self.console.print("[dim]Cancelled.[/]")
                return
            logout_provider(target)
            self.console.print(f"[green]Credentials removed for {target}.[/]")
            self.console.print("[dim]Run /connect to re-authenticate.[/]")

        elif name == "/compact":
            async for event in run_compact(agent):
                if event.kind == EventKind.COMPACTING:
                    self.console.print(
                        f"[ui.text.muted]  ℹ {event.info}[/ui.text.muted]"
                    )
                elif event.kind == EventKind.COMPACTED:
                    self.console.print(
                        f"[ui.text.muted]  ℹ {event.info}[/ui.text.muted]"
                    )
                elif event.kind == EventKind.INFO:
                    self.console.print(f"[yellow]  ⚠ {event.info}[/yellow]")
                elif event.kind == EventKind.ERROR:
                    self.console.print(
                        f"[bold ui.text.error]  ! Compact error:[/bold ui.text.error] {event.error}"
                    )

        elif name == "/resume":
            if args and args[0] == "list":
                sessions = list_sessions(agent)
                if sessions:
                    table = Table(
                        show_header=True,
                        header_style="bold dim",
                        box=None,
                        padding=(0, 1),
                    )
                    table.add_column("UUID")
                    table.add_column("Saved", style="dim")
                    for s in sessions:
                        table.add_row(f"[cyan]{s.uuid[:8]}…[/cyan]", s.ts)
                    self.console.print(table)
                    self.console.print("[dim]Use /resume <uuid> to restore.[/dim]")
                else:
                    self.console.print("[yellow]No saved sessions found.[/yellow]")
            else:
                uuid = args[0] if args else None
                ts = run_resume(agent, uuid=uuid)
                if ts:
                    self.console.print(f"[dim]Session restored from {ts}.[/dim]")
                else:
                    self.console.print("[yellow]No saved session found.[/yellow]")

        elif name == "/clear":
            run_clear(agent)
            sidebar.clear_session()
            self.console.print("[dim]History cleared.[/]")

        elif name == "/think":
            self._show_thinking = not self._show_thinking
            agent.settings = msgspec.structs.replace(
                agent.settings, show_thinking=self._show_thinking
            )
            state = "on" if self._show_thinking else "off"
            self.console.print(f"[dim]Thinking display {state}.[/]")

        elif name == "/help":
            self.console.print(slash_help_markup("rich"))

        elif name == "/detail":
            if not args:
                self.console.print("[yellow]Usage: /detail <activity-id>[/]")
            else:
                detail = self._tracker.format_detail(args[0])
                self.console.print(Text(detail, style="dim"))

        else:
            known = [cmd.name for cmd in slash_commands_for("rich")]
            suggestion = suggest_command(name, known)
            if suggestion:
                self.console.print(
                    f"[yellow]Unknown command {name!r}[/] — did you mean [bold]{suggestion}[/bold]?"
                )
            else:
                self.console.print(
                    f"[yellow]Unknown command {name!r}[/] — type [bold]/help[/] for commands"
                )
