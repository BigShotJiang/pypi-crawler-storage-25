"""Rich rendering helpers for the Rich-based UI backends.

Pure-Rich functions (no Textual dependency) for rendering sidebar sections.
Data types and utility functions live in kiss.ui.shared.
"""

from __future__ import annotations

from rich.table import Table
from rich.text import Text

from kiss.data.ui_tokens import DEFAULT_TOKENS as _T
from kiss.ui.shared import BUDGET_COLORS, TokenBudgetEntry

# Default sidebar content width; callers can override per-render
_DEFAULT_W = 30


# ── Render helpers ───────────────────────────────────────────────────────────


def header(title: str, width: int = _DEFAULT_W) -> Text:
    """Section header: '─ Title ───────────────────'"""
    dashes = max(0, width - 3 - len(title))
    return Text(f"─ {title} {'─' * dashes}", style=_T.text_accent)


def grid(label_w: int) -> Table:
    """Two-column fixed-label grid with no borders."""
    t = Table.grid(padding=(0, 1))
    t.add_column(width=label_w, no_wrap=True)
    t.add_column(no_wrap=True)
    return t


def stacked_bar(
    budget: tuple[TokenBudgetEntry, ...] | list[TokenBudgetEntry],
    width: int,
) -> Text:
    """Coloured stacked █ bar, one segment per budget category."""
    t = Text()
    remaining = width
    items = list(budget)
    for i, entry in enumerate(items):
        chars = max(1, round(entry.pct * width / 100)) if entry.pct > 0 else 0
        if i == len(items) - 1:
            chars = remaining  # last segment fills remainder
        chars = max(0, min(chars, remaining))
        color = BUDGET_COLORS.get(entry.label, "white")
        t.append("█" * chars, style=color)
        remaining -= chars
    if remaining > 0:
        t.append("░" * remaining, style="dim")
    return t


def context_bar(filled: int, total: int, width: int = _DEFAULT_W) -> Text:
    """Single-colour context usage bar (green/yellow/red based on fill %)."""
    pct = min(100, filled * 100 // max(total, 1))
    n = width * pct // 100
    style = (
        f"bold {_T.text_error}"
        if pct >= 80
        else (_T.text_warning if pct >= 60 else _T.text_success)
    )
    bar = Text("█" * n, style=style)
    bar.append("░" * (width - n), style="dim")
    return bar
