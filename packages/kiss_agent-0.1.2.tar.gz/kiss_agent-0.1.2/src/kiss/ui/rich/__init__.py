"""Rich-based UI backends for kiss-agent.

Backends
--------
- statusbar_backend.RichStatusBarBackend — scrolling output + 1-line status bar (default)
"""
