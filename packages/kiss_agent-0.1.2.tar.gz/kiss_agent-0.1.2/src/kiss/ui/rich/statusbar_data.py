"""RichStatusBarData — session state container and renderer for the Rich statusbar backend.

No Textual dependency. Used by both RichSidebarBackend (layout split) and
as a post-turn summary printer in RichStatusBarBackend.
"""

from __future__ import annotations

import time
from pathlib import Path

from rich.console import Group, RenderableType
from rich.panel import Panel
from rich.text import Text

from kiss.core.types import TodoItem
from kiss.ui.shared import BUDGET_COLORS, FileChange, TokenBudgetEntry
from kiss.data.ui_tokens import DEFAULT_TOKENS as _T
from kiss.ui.rich.render_helpers import (
    context_bar,
    grid,
    header,
    stacked_bar,
)

_W = 30  # sidebar content width


class RichStatusBarData:
    """Mutable session state and renderer for the Rich statusbar backend.

    Call the update_* methods whenever the agent emits relevant events, then
    call render_panel() to get the current snapshot as a Rich renderable.
    """

    def __init__(self) -> None:
        self._session_start = time.monotonic()
        # Session section
        self.turn_count: int = 0
        self.cost_usd: float = 0.0
        self.finish_reason: str | None = None
        # Models section
        self.models_used: list[str] = []
        # Context section
        self.input_tokens: int = 0
        self.output_tokens: int = 0
        self.cache_read_tokens: int = 0
        self.cache_write_tokens: int = 0
        self.thinking_tokens: int = 0
        self.context_window: int = 200_000
        # Whether the active model supports prompt caching
        self.prompt_caching: bool = False
        # Providers section — list of (alias, type, is_active, is_ready)
        self.providers: list[tuple[str, str, bool, bool]] = []
        # Budget section
        self.token_budget: list[TokenBudgetEntry] = []
        # Todo section
        self.todos: list[TodoItem] = []
        # Files section
        self._file_changes: dict[str, FileChange] = {}

    # ── Public update API ────────────────────────────────────────────────────

    def update_session(
        self,
        turn_count: int,
        input_tokens: int,
        output_tokens: int,
        cost_usd: float,
        token_budget: list[TokenBudgetEntry],
        context_window: int,
        cache_read_tokens: int = 0,
        cache_write_tokens: int = 0,
        finish_reason: str | None = None,
        thinking_tokens: int = 0,
    ) -> None:
        self.turn_count = turn_count
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.cache_read_tokens = cache_read_tokens
        self.cache_write_tokens = cache_write_tokens
        self.cost_usd = cost_usd
        self.token_budget = token_budget
        self.context_window = context_window
        self.finish_reason = finish_reason
        self.thinking_tokens = thinking_tokens

    def set_models(self, models: list[str]) -> None:
        self.models_used = list(models)

    def set_providers(self, entries: list[tuple[str, str, bool, bool]]) -> None:
        self.providers = list(entries)

    def set_todos(self, todos: list[TodoItem]) -> None:
        self.todos = list(todos)

    def record_file_change(self, path: str, added: int, removed: int) -> None:
        self._file_changes[path] = FileChange(path=path, added=added, removed=removed)

    def clear_session(self) -> None:
        self.turn_count = 0
        self.cost_usd = 0.0
        self.finish_reason = None
        self.input_tokens = 0
        self.output_tokens = 0
        self.cache_read_tokens = 0
        self.cache_write_tokens = 0
        self.thinking_tokens = 0
        self.token_budget = []
        self.models_used = []
        self.todos = []
        self._file_changes = {}
        # context_window intentionally preserved

    @property
    def file_changes(self) -> list[FileChange]:
        return list(self._file_changes.values())

    # ── Render ───────────────────────────────────────────────────────────────

    def render_panel(self) -> Panel:
        """Return the full sidebar as a Rich Panel (suitable for a layout pane)."""
        parts: list[RenderableType] = []
        parts.extend(self._render_session())
        if len(self.models_used) > 1:
            parts.extend(self._render_models())
        if self.providers:
            parts.extend(self._render_providers())
        parts.extend(self._render_context())
        if self.token_budget:
            parts.extend(self._render_budget())
        if self.todos:
            parts.extend(self._render_todos())
        if self._file_changes:
            parts.extend(self._render_files())
        return Panel(
            Group(*parts),
            title=f"[{_T.text_accent}]Status[/]",
            border_style="dim",
            padding=(0, 1),
        )

    def render_summary(self) -> Group:
        """Compact inline summary for post-turn printing (no Panel border)."""
        parts: list[RenderableType] = []
        parts.extend(self._render_session())
        parts.extend(self._render_context())
        if self.token_budget:
            parts.extend(self._render_budget())
        if self.todos:
            parts.extend(self._render_todos())
        if self._file_changes:
            parts.extend(self._render_files())
        return Group(*parts)

    def render_toolbar(self) -> str:
        """Statusline-style toolbar for prompt_toolkit bottom_toolbar (returns HTML string)."""
        ctx = self.context_window or 1
        pct = min(100, self.input_tokens * 100 // ctx)

        # Colors matching statusline.sh palette
        if pct >= 90:
            ctx_color = "#ff5555"
        elif pct >= 70:
            ctx_color = "#ffb055"
        elif pct >= 50:
            ctx_color = "#e6c800"
        else:
            ctx_color = "#00a000"

        elapsed_s = int(time.monotonic() - self._session_start)
        h, rem = divmod(elapsed_s, 3600)
        m, s = divmod(rem, 60)
        elapsed = f"{h}:{m:02}:{s:02}" if h else f"{m}:{s:02}"

        model_short = self.models_used[0] if self.models_used else ""
        if self.prompt_caching and model_short:
            model_short = f"{model_short} $"

        def tok(n: int) -> str:
            if n >= 1_000_000:
                return f"{n / 1_000_000:.1f}m"
            if n >= 1_000:
                return f"{n / 1_000:.0f}k"
            return str(n)

        sep = ' <style fg="#555555">│</style> '

        parts: list[str] = []
        if model_short:
            parts.append(f'<style fg="#0099ff"><b>{model_short}</b></style>')
        parts.append(
            f'<style fg="#ffb055">{tok(self.input_tokens)}/{tok(ctx)}</style>'
            f' <style fg="{ctx_color}">({pct}%)</style>'
        )
        if self.cost_usd:
            parts.append(f'<style fg="#888888">${self.cost_usd:.4f}</style>')
        if self.token_budget:
            budget_str = "  ".join(
                f"{e.label[0]}:{e.pct}%" for e in self.token_budget if e.pct > 0
            )
            parts.append(f'<style fg="#888888">{budget_str}</style>')
        pending_todos = sum(1 for t in self.todos if not t.done)
        if pending_todos:
            parts.append(f'<style fg="#ffcc44">○ {pending_todos}</style>')
        parts.append(f'<style fg="#666666">{elapsed}</style>')

        return sep.join(parts)

    def render_status_row(self) -> Text:
        """Single-line status row for the status bar backend."""
        ctx = self.context_window or 1
        pct = min(100, self.input_tokens * 100 // ctx)
        pct_style = (
            f"bold {_T.text_error}"
            if pct >= 80
            else (_T.text_warning if pct >= 60 else _T.text_success)
        )

        elapsed_s = int(time.monotonic() - self._session_start)
        h, rem = divmod(elapsed_s, 3600)
        m, s = divmod(rem, 60)
        elapsed = f"{h}:{m:02}:{s:02}" if h else f"{m}:{s:02}"

        model_short = ""
        if self.models_used:
            label = self.models_used[0]
            model_short = label.split(":", 1)[-1] if ":" in label else label
        if self.prompt_caching:
            model_short = f"{model_short} $"

        t = Text()
        t.append(f" {model_short} ", style="dim")
        t.append("│", style="dim")
        t.append(f" turns:{self.turn_count} ", style="dim")
        t.append("│", style="dim")
        t.append(f" ctx:{pct}% ", style=pct_style)
        t.append("│", style="dim")
        t.append(f" in:{self.input_tokens:,} out:{self.output_tokens:,} ", style="dim")
        if self.cost_usd:
            t.append("│", style="dim")
            t.append(f" ${self.cost_usd:.4f} ", style="dim")
        t.append("│", style="dim")
        t.append(f" {elapsed} ", style="dim")
        return t

    # ── Private section builders ─────────────────────────────────────────────

    def _render_session(self) -> list[RenderableType]:
        elapsed_s = int(time.monotonic() - self._session_start)
        h, rem = divmod(elapsed_s, 3600)
        m, s = divmod(rem, 60)
        elapsed = f"{h}:{m:02}:{s:02}" if h else f"{m}:{s:02}"
        t = grid(7)
        t.add_row(Text("turns", style="dim"), Text(str(self.turn_count)))
        t.add_row(Text("elapsed", style="dim"), Text(elapsed))
        cost_s = f"${self.cost_usd:.4f}" if self.cost_usd else "—"
        t.add_row(Text("cost", style="dim"), Text(cost_s))
        if self.finish_reason:
            warn_style = (
                f"bold {_T.text_error}"
                if self.finish_reason == "refusal"
                else _T.text_warning
            )
            t.add_row(
                Text("warn", style="dim"), Text(self.finish_reason, style=warn_style)
            )
        return [header("Session", _W), t]

    def _render_providers(self) -> list[RenderableType]:
        t = grid(2)
        for alias, ptype, is_active, is_ready in self.providers:
            if is_active:
                marker = Text("●", style=f"bold {_T.text_success}")
            elif is_ready:
                marker = Text(" ")
            else:
                marker = Text("✗", style=f"bold {_T.text_error}")
            label = Text(alias, style="bold")
            label.append(f"  {ptype}", style="dim")
            t.add_row(marker, label)
        return [Text(""), header("Providers", _W), t]

    def _render_models(self) -> list[RenderableType]:
        t = grid(2)
        for i, model in enumerate(self.models_used):
            short = model.split(":", 1)[-1] if ":" in model else model
            marker = Text("●", style=_T.text_accent) if i == 0 else Text(" ")
            t.add_row(marker, Text(short[: _W - 3]))
        return [Text(""), header("Models", _W), t]

    def _render_context(self) -> list[RenderableType]:
        bar = context_bar(self.input_tokens, self.context_window, _W)
        ct = grid(5)
        ctx = self.context_window or 1
        ct.add_row(Text("in", style="dim"), Text(f"{self.input_tokens:,} / {ctx:,}"))
        ct.add_row(Text("out", style="dim"), Text(f"{self.output_tokens:,}"))
        if self.thinking_tokens:
            ct.add_row(Text("think", style="dim"), Text(f"{self.thinking_tokens:,}"))
        if self.cache_read_tokens:
            ct.add_row(
                Text("$ read", style=f"dim {_T.text_success}"),
                Text(f"{self.cache_read_tokens:,}", style=_T.text_success),
            )
        if self.cache_write_tokens:
            ct.add_row(
                Text("$ write", style=f"dim {_T.text_warning}"),
                Text(f"{self.cache_write_tokens:,}", style=_T.text_warning),
            )
        return [Text(""), header("Context", _W), bar, ct]

    def _render_budget(self) -> list[RenderableType]:
        bar = stacked_bar(self.token_budget, _W)
        bt = grid(11)
        for entry in self.token_budget:
            color = BUDGET_COLORS.get(entry.label, "white")
            bt.add_row(
                Text(f"■ {entry.label}", style=color),
                Text(f"{entry.tokens:>6,}  {entry.pct:>3}%", style="dim"),
            )
        return [Text(""), header("Budget", _W), bar, bt]

    def _render_todos(self) -> list[RenderableType]:
        parts: list[RenderableType] = [Text(""), header("Todo", _W)]
        for item in self.todos:
            icon = "✓" if item.done else "○"
            style = "dim" if item.done else ""
            row = Text(no_wrap=True, overflow="fold")
            row.append(f"{icon} {item.text[: _W - 2]}", style=style)
            parts.append(row)
        return parts

    def _render_files(self) -> list[RenderableType]:
        ft = grid(14)
        for fc in self._file_changes.values():
            name = Path(fc.path).name[:14]
            added_s = f"+{fc.added}" if fc.added else ""
            removed_s = f"-{fc.removed}" if fc.removed else ""
            counts = f"{added_s:>4} {removed_s:>3}".rstrip()
            if added_s and removed_s:
                style = _T.text_warning
            elif added_s:
                style = _T.text_success
            else:
                style = _T.text_error
            ft.add_row(
                Text(name),
                Text(counts, style=style),
            )
        return [Text(""), header("Modified", _W), ft]
