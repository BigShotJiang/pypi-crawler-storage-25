"""Durable truncated-output persistence for terminal UI backends.

Oversized tool output is persisted under ~/.kiss/agent/tool-output/ so both
backends can offer retrieval after the active session frame. Persisted files
are ephemeral agent cache, not user-authored project data.

Retention policy:
  - 7-day retention from write time
  - Opportunistic cleanup at session startup and shutdown
  - At most 100 entries inspected per cleanup pass (startup or shutdown) so
    large caches do not delay session startup or shutdown materially
  - Missing or unreadable persisted files surface as recoverable degraded state
    (callers receive None) rather than hard failures
"""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path


_STORE_DIR = Path.home() / ".kiss" / "agent" / "tool-output"
_RETENTION_DAYS = 7
_MAX_CLEANUP_ENTRIES = 100


def _store_dir() -> Path:
    _STORE_DIR.mkdir(parents=True, exist_ok=True)
    return _STORE_DIR


def persist_truncated_output(content: str) -> str | None:
    """Write truncated tool output to disk and return the file path as a string.

    Returns None on filesystem failure. Callers surface None as a degraded
    state rather than a hard error.
    """
    try:
        store = _store_dir()
        filename = f"{uuid.uuid4().hex}.txt"
        path = store / filename
        path.write_text(content, encoding="utf-8")
        return str(path)
    except OSError:
        return None


def load_truncated_output(path_str: str) -> str | None:
    """Load a previously persisted truncated output.

    Returns None when the file is missing, corrupt, or unreadable. Callers
    surface None as a degraded state with a readable warning.
    """
    try:
        return Path(path_str).read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None


def cleanup_expired(max_entries: int = _MAX_CLEANUP_ENTRIES) -> int:
    """Remove expired truncated-output files. Returns count of files deleted.

    Inspects at most max_entries files per call so cleanup stays bounded.
    Called at session startup and shutdown.
    """
    try:
        store = _store_dir()
    except OSError:
        return 0

    cutoff = datetime.now(tz=timezone.utc) - timedelta(days=_RETENTION_DAYS)
    deleted = 0
    inspected = 0

    try:
        for path in store.glob("*.txt"):
            if inspected >= max_entries:
                break
            inspected += 1
            try:
                mtime = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
                if mtime < cutoff:
                    path.unlink(missing_ok=True)
                    deleted += 1
            except OSError:
                pass
    except OSError:
        pass

    return deleted
