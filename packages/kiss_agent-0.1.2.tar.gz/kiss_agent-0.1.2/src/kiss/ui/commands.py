"""Shared slash-command execution logic for terminal UI backends.

Business logic extracted here so Rich and Textual execute the same semantics.
Backends call these functions and handle their own output presentation.
"""

from __future__ import annotations

from collections.abc import AsyncGenerator
from dataclasses import dataclass
from typing import TYPE_CHECKING

from kiss.core.events import Event

if TYPE_CHECKING:
    from kiss.agent.loop import KissAgent


@dataclass
class ProviderInfo:
    alias: str
    provider_type: str
    active: bool
    ready: bool


@dataclass
class ProviderStatus:
    """Extended provider info including health state — consumed by UI backends."""

    alias: str
    provider_type: str
    display_name: str
    active: bool
    ready: bool
    health: str  # unknown / healthy / degraded / unhealthy
    last_error: str
    failure_count: int
    last_checked: float  # unix timestamp, 0 if never probed


@dataclass
class ModelList:
    """Model list for a provider — consumed by UI backends."""

    provider: str
    models: list[str]
    from_config: bool


@dataclass
class ModelInfo:
    model_id: str
    active: bool
    from_config: bool
    free: bool = False


@dataclass
class FreeProviderInfo:
    name: str
    display_name: str
    free_model_count: int
    enabled: bool
    ready: bool
    signup_url: str


def parse_command(raw: str) -> tuple[str, list[str]]:
    """Return (name, args) from a raw slash-command string."""
    parts = raw.strip().split()
    return parts[0].lower(), parts[1:]


def run_clear(agent: "KissAgent") -> None:
    """Clear agent conversation history."""
    agent.clear_history()


@dataclass
class SessionInfo:
    uuid: str
    ts: str


def list_sessions(agent: "KissAgent") -> list[SessionInfo]:
    """Return available saved sessions, newest first."""
    entries = agent.session_manager.list_sessions()
    return [SessionInfo(uuid=e["uuid"], ts=e.get("ts", "")) for e in entries]


def run_resume(agent: "KissAgent", uuid: str | None = None) -> str | None:
    """Restore a saved session by UUID, or the latest if uuid is None.

    Returns the session timestamp string on success, or None if not found.
    """
    return agent.restore_session(uuid=uuid)


def get_providers(agent: "KissAgent") -> list[ProviderInfo]:
    """Return provider info list for /providers display (all registered providers)."""
    from kiss.providers.auth import provider_is_ready
    from kiss.providers.registry import list_providers

    active = agent.settings.provider_alias if agent.settings.model else ""
    return [
        ProviderInfo(
            alias=profile.name,
            provider_type=profile.name,
            active=profile.name == active,
            ready=provider_is_ready(profile.name),
        )
        for profile in list_providers()
    ]


def get_provider_status(agent: "KissAgent") -> list[ProviderStatus]:
    """Return full diagnostic status for all registered providers.

    Includes health probe state from the registry — data layer only, no rendering.
    """
    from kiss.providers.auth import provider_is_ready
    from kiss.providers.health import get_provider_health
    from kiss.providers.registry import list_providers

    active = agent.settings.provider_alias if agent.settings.model else ""
    results: list[ProviderStatus] = []
    for profile in list_providers():
        health = get_provider_health(profile.name)
        results.append(
            ProviderStatus(
                alias=profile.name,
                provider_type=profile.name,
                display_name=profile.display_name or profile.name,
                active=profile.name == active,
                ready=provider_is_ready(profile.name),
                health=health.status,
                last_error=health.last_error,
                failure_count=health.failure_count,
                last_checked=health.last_checked,
            )
        )
    return results


async def get_models(agent: "KissAgent", provider: str) -> list[ModelInfo]:
    """Fetch and return model list for /models display."""
    from kiss.core.settings import is_usable_model_mode
    from kiss.providers.providers_store import load_provider_records

    models = await agent.fetch_models(provider)
    record = load_provider_records().get(provider)
    static_ids = set(record.models if record else [])
    active_model_id = (
        agent.settings.model.split(":", 1)[1] if ":" in agent.settings.model else ""
    )
    all_ids = sorted(
        m
        for m in static_ids | set(models)
        if m == active_model_id or is_usable_model_mode(m)
    )
    return [
        ModelInfo(
            model_id=f"{provider}:{m}",
            active=f"{provider}:{m}" == agent.settings.model,
            from_config=m in static_ids,
        )
        for m in all_ids
    ]


async def run_compact(agent: "KissAgent") -> AsyncGenerator[Event, None]:
    """Yield compaction events from /compact."""
    async for event in agent.compact("manual"):
        yield event


def switch_model(agent: "KissAgent", model_spec: str) -> None:
    """Switch model. Raises ValueError on invalid spec."""
    agent.switch_model(model_spec)


@dataclass
class AuthStatusInfo:
    """Per-provider auth status for /auth-status display."""

    name: str
    display_name: str
    auth_type: str
    ready: bool
    credential_source: str  # "env", "keyring", "none"
    env_var: str  # first declared env var, or ""
    signup_url: str = ""


def get_auth_status(agent: "KissAgent") -> list[AuthStatusInfo]:
    """Return per-provider auth status for /auth-status display."""
    import os

    from kiss.providers.auth import provider_is_ready
    from kiss.providers.keyring_store import get_credential
    from kiss.providers.registry import list_providers

    results: list[AuthStatusInfo] = []
    for profile in list_providers():
        ready = provider_is_ready(profile.name)

        # Determine credential source
        env_var = profile.env_vars[0] if profile.env_vars else ""
        if env_var and os.environ.get(env_var):
            source = "env"
        elif get_credential(f"provider:{profile.name}"):
            source = "keyring"
        else:
            source = "none"

        results.append(
            AuthStatusInfo(
                name=profile.name,
                display_name=profile.display_name or profile.name,
                auth_type=profile.auth_type,
                ready=ready,
                credential_source=source,
                env_var=env_var,
                signup_url=profile.signup_url or "",
            )
        )
    return results


async def connect_provider(
    agent: "KissAgent",
    provider_name: str,
    on_event=None,
) -> str | None:
    """Run auth flow for provider_name. Returns credential on success or None.

    Caller is responsible for:
    - Prompting for API key if this returns None (api_key providers)
    - Writing credential to keyring on success
    - Writing runtime record to providers.jsonc
    """
    from kiss.providers.registry import get_provider_profile
    from kiss.providers.strategies import get_strategy

    profile = get_provider_profile(provider_name)
    if profile is None:
        raise KeyError(provider_name)

    strategy = get_strategy(profile.auth_type)
    if strategy is None:
        raise ValueError(f"No strategy for auth_type={profile.auth_type!r}")

    return await strategy.run(agent, on_event=on_event)


def persist_connect(
    profile_name: str, credential: str, agent: "KissAgent | None" = None
) -> None:
    """Write credential to keyring and runtime record to providers.jsonc.

    If agent is provided and has no model set, switches to the first
    available model for the connected provider.
    """
    from kiss.providers.keyring_store import set_credential
    from kiss.providers.providers_store import record_from_profile, save_provider_record
    from kiss.providers.registry import get_provider_profile

    set_credential(f"provider:{profile_name}", credential)
    profile = get_provider_profile(profile_name)
    if profile is not None:
        from kiss.providers.providers_store import update_provider_enabled

        save_provider_record(profile_name, record_from_profile(profile))
        update_provider_enabled(profile_name, True)

    if agent is not None and not agent.settings.model and profile is not None:
        # Auto-select first model from the profile's context_windows or a sensible default
        if profile.context_windows:
            first_model = profile.context_windows[0][0]
        elif profile.fallback_models:
            raw = profile.fallback_models[0]
            if "/" in raw:
                from kiss.providers.registry import get_provider_profile as _gpp

                prefix = raw.split("/")[0]
                # Cross-provider reference: "otherprovider/model" — strip prefix.
                # Own-provider model with "/" in ID (e.g. openrouter org/model) — keep whole.
                first_model = raw.split("/", 1)[1] if _gpp(prefix) is not None else raw
            else:
                first_model = raw
        else:
            first_model = ""
        if first_model:
            try:
                agent.switch_model(f"{profile_name}:{first_model}")
            except Exception:
                pass


def logout_provider(provider_name: str) -> bool:
    """Delete keyring credential and disable provider in providers.jsonc.

    Returns True if a credential existed, False if nothing was stored.
    """
    from kiss.providers.keyring_store import delete_credential, get_credential
    from kiss.providers.providers_store import update_provider_enabled

    had_credential = get_credential(f"provider:{provider_name}") is not None
    delete_credential(f"provider:{provider_name}")
    update_provider_enabled(provider_name, False)
    return had_credential


def get_free_provider_status(agent: "KissAgent") -> list[FreeProviderInfo]:
    """Return free-provider status for /free display.

    Only includes providers with at least one declared free model.
    """
    from kiss.providers.auth import provider_is_ready
    from kiss.providers.registry import list_providers

    results: list[FreeProviderInfo] = []
    for profile in list_providers():
        if not profile.free_models:
            continue
        enabled = agent.settings.free_providers.get(profile.name, False)
        results.append(
            FreeProviderInfo(
                name=profile.name,
                display_name=profile.display_name or profile.name,
                free_model_count=len(profile.free_models),
                enabled=enabled,
                ready=provider_is_ready(profile.name),
                signup_url=profile.signup_url,
            )
        )
    return results


def toggle_free_provider(agent: "KissAgent", provider_name: str) -> bool:
    """Toggle free-provider access for provider_name. Returns new enabled state.

    Raises KeyError if provider not found or has no free models.
    """
    from kiss.providers.registry import get_provider_profile

    profile = get_provider_profile(provider_name)
    if profile is None or not profile.free_models:
        raise KeyError(provider_name)

    current = agent.settings.free_providers.get(profile.name, False)
    new_state = not current
    agent.settings.free_providers[profile.name] = new_state
    from kiss.core.settings import settings_save

    settings_save(agent.settings)
    return new_state


def get_free_models(agent: "KissAgent") -> list[ModelInfo]:
    """Collect free models from all enabled free providers.

    Returns sorted, deduplicated ModelInfo list with free=True.
    """
    from kiss.providers.registry import get_provider_profile

    seen: set[str] = set()
    results: list[ModelInfo] = []
    for name, enabled in agent.settings.free_providers.items():
        if not enabled:
            continue
        profile = get_provider_profile(name)
        if profile is None:
            continue
        for bare_model in profile.free_models:
            model_id = f"{profile.name}:{bare_model}"
            if model_id in seen:
                continue
            seen.add(model_id)
            results.append(
                ModelInfo(
                    model_id=model_id,
                    active=model_id == agent.settings.model,
                    from_config=False,
                    free=True,
                )
            )
    results.sort(key=lambda m: m.model_id)
    return results
