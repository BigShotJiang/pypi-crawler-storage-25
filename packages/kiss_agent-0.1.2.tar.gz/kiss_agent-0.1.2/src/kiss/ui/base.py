"""UIBackend — abstract interface between KissAgent and a concrete UI"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from kiss.agent.loop import KissAgent
    from kiss.core.settings import Settings


class UIBackend(ABC):
    """Consume events from KissAgent and present them to the user.

    Implementations:
      - RichStatusBarBackend — scrolling output + 1-line status bar (default)
      - TextualBackend       — full Textual TUI with sidebar and modal screens
    """

    @abstractmethod
    async def run(self, agent: "KissAgent", settings: "Settings") -> None:
        """Start the interactive loop and return when the user exits"""
