# mirascope 2.4.0 requires opentelemetry-instrumentation-google-genai, but that
# package fails at import when google-generativeai is not installed. Since we don't
# use Gemini, we register a minimal stub so mirascope.ops loads correctly and only
# instruments the providers we actually use (Anthropic, OpenAI).
import sys
from types import ModuleType as _ModuleType

if "opentelemetry.instrumentation.google_genai" not in sys.modules:
    try:
        import opentelemetry.instrumentation.google_genai  # noqa: F401
    except ImportError:
        _stub = _ModuleType("opentelemetry.instrumentation.google_genai")

        class _NoopInstrumentor:
            def instrument(self, **_: object) -> None: ...
            def uninstrument(self, **_: object) -> None: ...
            def is_instrumented_by(self, *_: object) -> bool:
                return False

        setattr(_stub, "GoogleGenAiSdkInstrumentor", _NoopInstrumentor)
        sys.modules["opentelemetry.instrumentation.google_genai"] = _stub
