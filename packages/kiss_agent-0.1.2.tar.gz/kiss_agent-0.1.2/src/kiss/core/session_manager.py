"""Session persistence — JSONL turn log and JSON snapshot export/restore."""

from __future__ import annotations

import contextlib
import logging
from datetime import UTC, datetime
from pathlib import Path

import msgspec

from kiss.agent.plan_types import TurnPhase

_MAX_SNAPSHOTS = 10
_SNAPSHOT_VERSION = 5
_LOGGER = logging.getLogger(__name__)


class SessionManager:
    """Owns all I/O under a sessions directory.

    Manages two file types:
    - ``{ts}.jsonl``       — append-only turn log (role/content/ts per line)
    - ``export_{uuid}.json`` — LLM message snapshots for session restore
    """

    def __init__(self, sessions_dir: Path) -> None:
        self._dir = sessions_dir
        self._dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(UTC).strftime("%Y-%m-%d_%H-%M-%S")
        self._log_path = self._dir / f"{ts}.jsonl"

    @property
    def log_path(self) -> Path:
        return self._log_path

    @property
    def sessions_dir(self) -> Path:
        return self._dir

    def append_turn(self, role: str, content: str) -> None:
        """Append one turn to the JSONL conversation log."""
        entry = {
            "role": role,
            "content": content,
            "ts": datetime.now(UTC).isoformat(),
        }
        with self._log_path.open("a", encoding="utf-8") as fh:
            fh.write(msgspec.json.encode(entry).decode() + "\n")

    def list_sessions(self) -> list[dict]:
        """Return metadata for all snapshots, newest first."""
        result = []
        for path in sorted(
            self._dir.glob("export_*.json"), key=lambda p: p.stat().st_mtime
        ):
            uuid = path.stem[len("export_") :]
            try:
                data = msgspec.json.decode(path.read_bytes())
                ts = data.get("ts", "")
            except (OSError, msgspec.DecodeError):
                ts = ""
            result.append({"uuid": uuid, "ts": ts, "path": str(path)})
        result.reverse()
        return result

    def export_snapshot(
        self,
        messages: list[dict[str, str]],
        snapshot_uuid: str,
        ts: str,
        todos: list[dict[str, str | bool]] | None = None,
        team_messages: list[dict[str, str]] | None = None,
        last_tool: str = "",
        phase: TurnPhase = TurnPhase.RESEARCH,
    ) -> bool:
        """Write LLM history snapshot to disk. Returns True on success."""
        data = {
            "version": _SNAPSHOT_VERSION,
            "uuid": snapshot_uuid,
            "ts": ts,
            "messages": messages,
            "todos": todos or [],
            "team_messages": team_messages or [],
            "last_tool": last_tool,
            "phase": phase.value,
        }
        snapshot_path = self._dir / f"export_{snapshot_uuid}.json"
        try:
            snapshot_path.write_bytes(msgspec.json.encode(data))
        except OSError:
            return False
        self._prune_snapshots()
        return True

    def restore_snapshot(
        self,
        uuid: str | None = None,
    ) -> (
        tuple[list[dict[str, str]], str, list[dict], list[dict], str, TurnPhase] | None
    ):
        """Load snapshot by UUID, or latest when uuid is None.

        Returns (message_dicts, ts, todos, team_messages, last_tool, phase) or None.
        """
        if uuid is not None:
            target = self._dir / f"export_{uuid}.json"
            if not target.exists():
                return None
            exports = [target]
        else:
            exports = sorted(
                self._dir.glob("export_*.json"), key=lambda p: p.stat().st_mtime
            )
        if not exports:
            return None
        latest = exports[-1]
        try:
            data = msgspec.json.decode(latest.read_bytes())
        except (OSError, msgspec.DecodeError):
            return None
        messages = data.get("messages", [])
        if not messages:
            return None
        version = data.get("version", 1)
        todos_data = data.get("todos", []) if version >= 2 else []
        if not isinstance(todos_data, list):
            todos_data = []
        team_messages_data = data.get("team_messages", []) if version >= 3 else []
        if not isinstance(team_messages_data, list):
            team_messages_data = []
        last_tool = data.get("last_tool", "") if version >= 4 else ""
        raw_phase = data.get("phase") if version >= 5 else None
        if raw_phase is None:
            phase = TurnPhase.RESEARCH
        else:
            try:
                if isinstance(raw_phase, bool):
                    raise ValueError("bool is not a valid phase payload")
                phase = TurnPhase(int(raw_phase))
            except (TypeError, ValueError):
                _LOGGER.warning(
                    "Invalid persisted turn phase %r; using RESEARCH", raw_phase
                )
                phase = TurnPhase.RESEARCH
        return (
            messages,
            data.get("ts", latest.stem),
            todos_data,
            team_messages_data,
            last_tool,
            phase,
        )

    def _prune_snapshots(self, keep: int = _MAX_SNAPSHOTS) -> None:
        exports = sorted(
            self._dir.glob("export_*.json"), key=lambda p: p.stat().st_mtime
        )
        for old in exports[:-keep]:
            with contextlib.suppress(OSError):
                old.unlink()
