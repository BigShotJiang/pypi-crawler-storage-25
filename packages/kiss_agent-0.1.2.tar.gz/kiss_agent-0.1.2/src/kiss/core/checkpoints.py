"""Checkpoint manager — first-write-wins snapshot registry with SHA-256 content hashing."""

from __future__ import annotations

import hashlib
import logging
import os
import tempfile
import uuid
from pathlib import Path
from typing import NamedTuple

from kiss.core.session_db import SessionDB

_LOGGER = logging.getLogger(__name__)


class _CheckpointEntry(NamedTuple):
    """Internal checkpoint row representation."""

    id: int
    session_id: str
    original_path: str
    backup_path: str
    hash: str
    source_hash: str
    drift_state: str | None


class CheckpointManager:
    """Manages file-level checkpoints for first-write-wins undo and /rewind.

    Protocol:
    1. ``checkpoint(path)`` — captures first-write-wins backup before mutation.
    2. ``drift_check(path)`` — validates current file matches ``source_hash``.
    3. ``restore(checkpoint_id)`` — atomic rollback via staging+swap.
    """

    def __init__(self, db: SessionDB, backup_dir: Path) -> None:
        self.db = db
        self.backup_dir = backup_dir
        self.backup_dir.mkdir(parents=True, exist_ok=True)

    # -- public API -----------------------------------------------------------

    def checkpoint(self, session_id: str, path: Path) -> int | None:
        """Create a first-write-wins checkpoint for ``path``.

        Returns the checkpoint ``id`` or ``None`` if a checkpoint already exists
        for this path (first-write-wins semantics).
        """
        path = path.resolve()
        if not path.is_file():
            return None

        content = path.read_bytes()
        content_hash = self._sha256(content)

        # Check for existing checkpoint (first-write-wins)
        existing = self._find_by_path(session_id, path)
        if existing is not None:
            _LOGGER.debug("Checkpoint already exists for %s", path)
            return None

        # Write backup outside DB transaction (file I/O separation)
        # Include UUID to prevent collisions when two files share name+hash prefix
        backup_name = f"{content_hash[:12]}_{path.name}_{uuid.uuid4().hex[:6]}"
        backup_path = self.backup_dir / backup_name

        try:
            backup_path.write_bytes(content)
        except OSError as exc:
            _LOGGER.error("Failed to write checkpoint backup for %s: %s", path, exc)
            return None

        # Source hash for drift detection
        source_hash = content_hash

        # Short DB transaction
        with self.db.transaction() as conn:
            cur = conn.execute(
                """\
INSERT INTO checkpoints (id, session_id, original_path, backup_path, hash, source_hash, drift_state)
VALUES (
    COALESCE((SELECT MAX(id) FROM checkpoints WHERE session_id = ?), 0) + 1,
    ?, ?, ?, ?, ?, NULL
)""",
                (
                    session_id,
                    session_id,
                    str(path),
                    str(backup_path),
                    content_hash,
                    source_hash,
                ),
            )
            checkpoint_id = cur.lastrowid or 0

        _LOGGER.info("Checkpoint %d created for %s", checkpoint_id, path)
        return checkpoint_id

    def drift_check(self, session_id: str, path: Path) -> tuple[bool, str | None]:
        """Check if the file at ``path`` has drifted from its checkpoint.

        Returns ``(is_drifted, drift_reason)``. ``(False, None)`` means the file
        matches its checkpoint.
        """
        path = path.resolve()
        entry = self._find_by_path(session_id, path)
        if entry is None:
            return False, None  # No checkpoint — no drift

        if not path.is_file():
            return True, "File deleted externally"

        try:
            current_content = path.read_bytes()
            current_hash = self._sha256(current_content)
        except OSError as exc:
            return True, f"Cannot read file: {exc}"

        if current_hash != entry.source_hash:
            return True, "File modified externally"

        # If drift was previously recorded, clear it
        if entry.drift_state is not None:
            with self.db.transaction() as conn:
                conn.execute(
                    "UPDATE checkpoints SET drift_state = NULL WHERE id = ?",
                    (entry.id,),
                )

        return False, None

    def restore(
        self,
        session_id: str,
        checkpoint_id: int,
        *,
        force: bool = False,
        turn_id: str | None = None,
    ) -> dict[str, list[str]]:
        """Restore a file from checkpoint using staging+swap atomic rollback.

        Per Decision 12:
        1. Read backup content
        2. Write to temp file in same directory as original
        3. Validate source_hash (abort if externally modified, unless --force)
        4. os.replace(temp, original) — atomic on same filesystem
        5. Idempotency: if content already matches, skip swap but append REWIND event
        6. On failure: delete temp, log path, continue
        7. Refuse if active worker lease exists unless force=True

        Returns ``{"restored": [...], "failed": [...], "skipped": [...]}``.
        """
        # Check for active worker lease
        if not force and self._has_active_lease(session_id):
            return {
                "restored": [],
                "failed": [],
                "skipped": ["Active worker lease present (use --force to override)"],
            }

        entry = self._get_by_id(session_id, checkpoint_id)
        if entry is None:
            return {"restored": [], "failed": [], "skipped": []}

        original = Path(entry.original_path)
        backup = Path(entry.backup_path)

        # Read backup content
        try:
            backup_content = backup.read_bytes()
        except OSError as exc:
            _LOGGER.error("Cannot read backup %s: %s", backup, exc)
            return {"restored": [], "failed": [str(original)], "skipped": []}

        # Validate source_hash on current file (unless --force)
        current_matches_backup = False
        if original.is_file():
            try:
                current_content = original.read_bytes()
                current_hash = self._sha256(current_content)
                if current_hash == self._sha256(backup_content):
                    current_matches_backup = True
                elif not force and current_hash != entry.source_hash:
                    return {
                        "restored": [],
                        "failed": [],
                        "skipped": [
                            f"{original} modified externally (use --force to override)"
                        ],
                    }
            except OSError:
                pass  # Cannot read — proceed with best-effort

        # Idempotency: content already matches — skip swap, still record REWIND
        if current_matches_backup:
            self._append_rewind_event(session_id, checkpoint_id, entry)
            if turn_id is not None:
                self.db.execute_raw(
                    "UPDATE turns SET status = 'ROLLED_BACK' WHERE id = ?",
                    (turn_id,),
                )
            return {"restored": [], "failed": [], "skipped": []}

        # Staging+swap: write to temp in same directory
        tmp_path: str | None = None
        try:
            original.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp_path = tempfile.mkstemp(
                dir=str(original.parent),
                prefix=".kiss.rewind_",
            )
            try:
                os.write(fd, backup_content)
            finally:
                os.close(fd)
            os.replace(tmp_path, str(original))
        except OSError as exc:
            if tmp_path:
                Path(tmp_path).unlink(missing_ok=True)
            _LOGGER.error("Atomic swap failed for %s: %s", original, exc)
            # Best-effort fallback: direct write
            try:
                original.write_bytes(backup_content)
                _LOGGER.warning(
                    "Best-effort fallback used for %s (not atomic)", original
                )
            except OSError as exc2:
                _LOGGER.error(
                    "Best-effort fallback also failed for %s: %s", original, exc2
                )
                return {"restored": [], "failed": [str(original)], "skipped": []}

        # Append REWIND event and mark turn ROLLED_BACK
        self._append_rewind_event(session_id, checkpoint_id, entry)
        if turn_id is not None:
            self.db.execute_raw(
                "UPDATE turns SET status = 'ROLLED_BACK' WHERE id = ?",
                (turn_id,),
            )

        _LOGGER.info("Checkpoint %d restored: %s", checkpoint_id, original)
        return {"restored": [str(original)], "failed": [], "skipped": []}

    def cleanup_orphans(self) -> int:
        """Remove orphaned checkpoint backup files on disk with no DB row.

        Orphans = backup files created during failed file-I/O (before DB insert).
        Runs FOURTH in startup reaper coordination order.
        Returns the number of orphaned backups removed.
        """
        with self.db.transaction() as conn:
            registered = set(
                row["backup_path"]
                for row in conn.execute(
                    "SELECT backup_path FROM checkpoints"
                ).fetchall()
            )

        removed = 0
        for backup_file in self.backup_dir.iterdir():
            if str(backup_file) not in registered:
                try:
                    backup_file.unlink()
                    removed += 1
                    _LOGGER.info("Removed orphaned checkpoint backup: %s", backup_file)
                except OSError as exc:
                    _LOGGER.warning(
                        "Failed to remove orphaned checkpoint %s: %s", backup_file, exc
                    )

        return removed

    # -- internals ------------------------------------------------------------

    def _has_active_lease(self, session_id: str) -> bool:
        """Check if an active worker lease exists for the session."""
        conn = self.db._connect()
        row = conn.execute(
            """\
SELECT lease_expires_at FROM sessions
WHERE id = ? AND lease_owner IS NOT NULL
  AND lease_expires_at > strftime('%Y-%m-%dT%H:%M:%fZ', 'now')""",
            (session_id,),
        ).fetchone()
        return row is not None

    def _find_by_path(self, session_id: str, path: Path) -> _CheckpointEntry | None:
        """Find the first checkpoint for a given path."""
        conn = self.db._connect()
        row = conn.execute(
            """\
SELECT id, session_id, original_path, backup_path, hash, source_hash, drift_state
FROM checkpoints
WHERE session_id = ? AND original_path = ?
ORDER BY id ASC LIMIT 1""",
            (session_id, str(path)),
        ).fetchone()
        if row is None:
            return None
        return _CheckpointEntry(**dict(row))

    def _get_by_id(
        self, session_id: str, checkpoint_id: int
    ) -> _CheckpointEntry | None:
        """Get a specific checkpoint by id."""
        conn = self.db._connect()
        row = conn.execute(
            """\
SELECT id, session_id, original_path, backup_path, hash, source_hash, drift_state
FROM checkpoints
WHERE session_id = ? AND id = ?""",
            (session_id, checkpoint_id),
        ).fetchone()
        if row is None:
            return None
        return _CheckpointEntry(**dict(row))

    def _append_rewind_event(
        self, session_id: str, checkpoint_id: int, entry: _CheckpointEntry
    ) -> None:
        """Append a REWIND event (append-only, events never deleted)."""
        import json

        payload = json.dumps(
            {
                "checkpoint_id": checkpoint_id,
                "original_path": entry.original_path,
                "ts": str(
                    self.db._connect()
                    .execute("SELECT strftime('%Y-%m-%dT%H:%M:%fZ', 'now')")
                    .fetchone()[0]
                ),
            }
        )
        self.db.append_event(session_id, "REWIND", payload)

    @staticmethod
    def _sha256(data: bytes) -> str:
        """SHA-256 hex digest."""
        return hashlib.sha256(data).hexdigest()
