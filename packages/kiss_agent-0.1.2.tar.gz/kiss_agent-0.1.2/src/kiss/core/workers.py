"""Declarative worker agents and effort profiles (tasks 8.1–8.4).

Spec (Decisions 10, 11):
- Agent definitions in ~/.kiss/agents/*.md and .kiss/agents/*.md (YAML frontmatter).
- Project agents override user agents on same name.
- Ancestor-walk for project dir to find .kiss/agents/.
- Effort profiles: fast / balanced / deep — mapped to model + thinking in settings.
- Agent frontmatter overrides effort profile at dispatch time.
"""

from __future__ import annotations

import logging
import re
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal, Protocol, runtime_checkable

_LOGGER = logging.getLogger(__name__)

_FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)
_KV_RE = re.compile(r"^(\w[\w\-]*)\s*:\s*(.+)$")
_LIST_ITEM_RE = re.compile(r"^\s*-\s+(.+)$")

# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------


@dataclass
class AgentConfig:
    """Parsed agent definition from a .kiss/agents/*.md file."""

    name: str
    description: str
    effort: str = "balanced"
    model: str = ""
    thinking: str = ""
    skills: list[str] = field(default_factory=list)
    system_prompt: str = ""
    source_path: Path | None = None


@dataclass
class EffortProfile:
    """Model + thinking for a named effort level."""

    model: str = ""
    thinking: str = "low"


# ---------------------------------------------------------------------------
# Protocols (spec: replace Any | None in deps.py)
# ---------------------------------------------------------------------------


@runtime_checkable
class WorkerHandle(Protocol):
    worker_id: str
    status: Literal["RUNNING", "COMPLETED", "FAILED", "CRASHED"]

    def cancel(self) -> None: ...


@runtime_checkable
class WorkerManagerProtocol(Protocol):
    def spawn(
        self, agent: AgentConfig, task: str, effort: str = "balanced"
    ) -> WorkerHandle: ...

    def get(self, worker_id: str) -> WorkerHandle | None: ...
    def list_active(self) -> list[WorkerHandle]: ...
    def reap_orphans(self) -> list[str]: ...


# ---------------------------------------------------------------------------
# Frontmatter parser (no YAML dependency)
# ---------------------------------------------------------------------------


def _parse_frontmatter(text: str) -> tuple[dict[str, object], str]:
    """Return (frontmatter_dict, body). No external YAML dependency."""
    m = _FRONTMATTER_RE.match(text)
    if not m:
        return {}, text

    fm_text = m.group(1)
    body = text[m.end() :]
    result: dict[str, object] = {}

    lines = fm_text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        kv = _KV_RE.match(line)
        if kv:
            key = kv.group(1)
            val = kv.group(2).strip()
            # Check if next lines are list items
            list_items: list[str] = []
            j = i + 1
            while j < len(lines):
                li = _LIST_ITEM_RE.match(lines[j])
                if li:
                    list_items.append(li.group(1).strip())
                    j += 1
                else:
                    break
            if list_items:
                result[key] = list_items
                i = j
            else:
                # Strip inline YAML list e.g. "[a, b]"
                if val.startswith("[") and val.endswith("]"):
                    inner = val[1:-1]
                    result[key] = [
                        s.strip().strip("\"'") for s in inner.split(",") if s.strip()
                    ]
                else:
                    result[key] = val.strip("\"'")
                i += 1
        else:
            i += 1

    return result, body.strip()


def _parse_agent_file(path: Path) -> AgentConfig | None:
    """Parse a .kiss/agents/*.md file into an AgentConfig. Returns None on error."""
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        _LOGGER.warning("Cannot read agent file %s: %s", path, exc)
        return None

    fm, body = _parse_frontmatter(text)

    name = str(fm.get("name", "")).strip()
    description = str(fm.get("description", "")).strip()

    if not name or not description:
        _LOGGER.warning(
            "Agent file %s missing required 'name' or 'description' — skipped", path
        )
        return None

    skills_raw = fm.get("skills", [])
    skills: list[str] = (
        [str(s) for s in skills_raw] if isinstance(skills_raw, list) else []
    )

    return AgentConfig(
        name=name,
        description=description,
        effort=str(fm.get("effort", "balanced")).strip(),
        model=str(fm.get("model", "")).strip(),
        thinking=str(fm.get("thinking", "")).strip(),
        skills=skills,
        system_prompt=body,
        source_path=path,
    )


# ---------------------------------------------------------------------------
# 8.1 Agent discovery
# ---------------------------------------------------------------------------

_DEFAULT_EFFORT_PROFILES: dict[str, EffortProfile] = {
    "fast": EffortProfile(model="claude-haiku-4-5", thinking="off"),
    "balanced": EffortProfile(model="claude-sonnet-4-6", thinking="low"),
    "deep": EffortProfile(model="claude-opus-4-7", thinking="high"),
}


def discover_agents(workspace_root: Path) -> dict[str, AgentConfig]:
    """Discover agent definitions. Project overrides user on same name.

    Search order (lower index = lower priority):
    1. User global:  ~/.kiss/agents/*.md
    2. Project:      .kiss/agents/*.md found by ancestor-walk from workspace_root
    """
    agents: dict[str, AgentConfig] = {}

    # 1. User-global agents
    user_dir = Path.home() / ".kiss" / "agents"
    if user_dir.is_dir():
        for md_file in sorted(user_dir.glob("*.md")):
            cfg = _parse_agent_file(md_file)
            if cfg:
                agents[cfg.name] = cfg
                _LOGGER.debug("Loaded user agent '%s' from %s", cfg.name, md_file)

    # 2. Project agents — ancestor-walk from workspace_root up to filesystem root
    visited: set[Path] = set()
    current = workspace_root.resolve()
    project_layers: list[dict[str, AgentConfig]] = []

    while True:
        agents_dir = current / ".kiss" / "agents"
        if agents_dir.is_dir() and agents_dir not in visited:
            visited.add(agents_dir)
            layer: dict[str, AgentConfig] = {}
            for md_file in sorted(agents_dir.glob("*.md")):
                cfg = _parse_agent_file(md_file)
                if cfg:
                    layer[cfg.name] = cfg
                    _LOGGER.debug("Found project agent '%s' from %s", cfg.name, md_file)
            project_layers.append(layer)

        parent = current.parent
        if parent == current:
            break
        current = parent

    # Apply project layers outermost-first (workspace_root last = highest priority)
    for layer in reversed(project_layers):
        agents.update(layer)

    _LOGGER.info("WorkerManager discovered %d agents", len(agents))
    return agents


# ---------------------------------------------------------------------------
# 8.2-8.4 WorkerManager
# ---------------------------------------------------------------------------


@dataclass
class _WorkerHandleImpl:
    """Concrete WorkerHandle — stub until PTY/worktree execution is wired."""

    worker_id: str
    status: Literal["RUNNING", "COMPLETED", "FAILED", "CRASHED"] = "RUNNING"
    _cancelled: bool = field(default=False, repr=False)

    def cancel(self) -> None:
        self._cancelled = True
        self.status = "FAILED"


class WorkerManager:
    """Discovers, resolves, and dispatches declarative worker agents.

    Effort resolution order (8.4):
    1. Agent-level model/thinking frontmatter (highest priority)
    2. Effort profile for agent.effort (or effort_override)
    3. Built-in defaults
    """

    def __init__(
        self,
        workspace_root: Path,
        effort_profiles: dict[str, EffortProfile] | None = None,
        default_effort: str = "balanced",
    ) -> None:
        self.workspace_root = workspace_root
        self._effort_profiles: dict[str, EffortProfile] = {
            **_DEFAULT_EFFORT_PROFILES,
            **(effort_profiles or {}),
        }
        self.default_effort = default_effort
        self._agents: dict[str, AgentConfig] = {}
        self._handles: dict[str, _WorkerHandleImpl] = {}
        self.discover()

    # -- 8.1 discovery -------------------------------------------------------

    def discover(self) -> int:
        """(Re)discover agents from disk. Returns count."""
        self._agents = discover_agents(self.workspace_root)
        return len(self._agents)

    def reload(self) -> int:
        """Re-discover agents. Same as discover()."""
        return self.discover()

    def get_agent(self, name: str) -> AgentConfig | None:
        return self._agents.get(name)

    def list_agents(self) -> list[AgentConfig]:
        return list(self._agents.values())

    # -- 8.4 dispatch resolution ---------------------------------------------

    def resolve_dispatch(
        self, agent: AgentConfig, effort_override: str = ""
    ) -> tuple[str, str]:
        """Return (model, thinking) for dispatch.

        Priority: agent frontmatter > effort profile > defaults.
        """
        effort_key = effort_override or agent.effort or self.default_effort
        profile = self._effort_profiles.get(
            effort_key, self._effort_profiles.get(self.default_effort, EffortProfile())
        )

        model = agent.model or profile.model
        thinking = agent.thinking or profile.thinking
        return model, thinking

    def spawn(
        self,
        agent: AgentConfig,
        task: str,
        effort: str = "",
    ) -> _WorkerHandleImpl:
        """Spawn a worker. Returns a WorkerHandle stub (PTY/worktree wired in step 13)."""
        model, thinking = self.resolve_dispatch(agent, effort)
        worker_id = str(uuid.uuid4())[:8]
        handle = _WorkerHandleImpl(worker_id=worker_id)
        self._handles[worker_id] = handle
        _LOGGER.info(
            "Spawned worker %s: agent=%s model=%s thinking=%s task=%r",
            worker_id,
            agent.name,
            model,
            thinking,
            task[:80],
        )
        return handle

    def get(self, worker_id: str) -> _WorkerHandleImpl | None:
        return self._handles.get(worker_id)

    def list_active(self) -> list[_WorkerHandleImpl]:
        return [h for h in self._handles.values() if h.status == "RUNNING"]

    def reap_orphans(self) -> list[str]:
        """Mark stale RUNNING handles as CRASHED. Returns reaped worker_ids.

        Runs SECOND in startup reaper coordination order.
        """
        reaped: list[str] = []
        for h in list(self._handles.values()):
            if h.status == "RUNNING":
                h.status = "CRASHED"
                reaped.append(h.worker_id)
                _LOGGER.info("Reaped orphaned worker %s", h.worker_id)
        return reaped
