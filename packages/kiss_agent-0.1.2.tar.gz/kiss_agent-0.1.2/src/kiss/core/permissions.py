"""Permission request and reply types."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Literal

import msgspec


class PermissionReply(Enum):
    ALLOW = auto()  # allow once
    ALLOW_CMD = auto()  # allow this specific command/args
    ALLOW_TOOL = auto()  # allow this tool for the rest of the session
    DENY = auto()  # deny this call


class PermissionAction(msgspec.Struct, frozen=True, omit_defaults=True):
    tool_name: str
    kind: Literal["file_write", "shell_command", "tool_access"]
    target: str
    message: str
    exact_key: str
    scope_key: str | None = None
    exact_only: bool = False
    default_allow: bool = False
    policy_candidates: tuple[str, ...] = ()


@dataclass
class PermissionRequest:
    tool_name: str
    args: str
    action: PermissionAction | None = None
    metadata: dict[str, str] = field(default_factory=dict)
    reply_future: asyncio.Future[PermissionReply] = field(
        default_factory=lambda: asyncio.get_running_loop().create_future()
    )
