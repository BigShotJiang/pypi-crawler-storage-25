"""Retention policy and archival for SessionDB (tasks 6.1, 6.3).

Spec (Decision 7):
- Old sessions, stale checkpoints, and low-value history pruned by configurable policy.
- Pruned rows archived to `archives` table before deletion (zlib + sha256 checksum).
- Large sessions compacted/archived automatically when thresholds exceeded.
- Batched deletes (500 rows) to avoid lock starvation.
"""

from __future__ import annotations

import hashlib
import json
import logging
import uuid
import zlib
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from kiss.core.session_db import SessionDB

_LOGGER = logging.getLogger(__name__)

_BATCH_SIZE = 500


@dataclass
class RetentionConfig:
    """Configurable thresholds for the retention policy."""

    max_event_age_days: int = 90
    max_checkpoint_age_days: int = 30
    max_closed_session_age_days: int = 180
    auto_archive: bool = True


class Archiver:
    """Archives rows to the `archives` table before deletion.

    Compression: zlib.compress(json.dumps(rows).encode())
    Integrity:   sha256(blob) stored as `checksum`
    """

    def __init__(self, db: SessionDB) -> None:
        self.db = db

    def archive_events(self, session_id: str, cutoff_ts: str) -> int:
        """Archive events older than cutoff_ts, then delete them.

        Returns number of rows archived.
        """
        conn = self.db._connect()
        rows = conn.execute(
            "SELECT id, session_id, kind, payload, ts FROM events "
            "WHERE session_id = ? AND ts < ? ORDER BY id LIMIT ?",
            (session_id, cutoff_ts, _BATCH_SIZE),
        ).fetchall()

        if not rows:
            return 0

        total = 0
        while rows:
            row_dicts = [dict(r) for r in rows]
            ids = [r["id"] for r in row_dicts]
            self._write_archive(session_id, "events", row_dicts)
            with self.db.transaction() as c:
                c.executemany("DELETE FROM events WHERE id = ?", [(i,) for i in ids])
            total += len(ids)
            rows = conn.execute(
                "SELECT id, session_id, kind, payload, ts FROM events "
                "WHERE session_id = ? AND ts < ? ORDER BY id LIMIT ?",
                (session_id, cutoff_ts, _BATCH_SIZE),
            ).fetchall()

        _LOGGER.info("Archived %d events for session %s", total, session_id)
        return total

    def archive_checkpoints(self, session_id: str, cutoff_ts: str) -> int:
        """Archive checkpoints older than cutoff_ts, then delete them."""
        conn = self.db._connect()
        rows = conn.execute(
            "SELECT id, session_id, original_path, backup_path, hash, source_hash, "
            "drift_state FROM checkpoints "
            "WHERE session_id = ? AND created_at < ? LIMIT ?",
            (session_id, cutoff_ts, _BATCH_SIZE),
        ).fetchall()

        if not rows:
            return 0

        total = 0
        while rows:
            row_dicts = [dict(r) for r in rows]
            ids = [r["id"] for r in row_dicts]
            self._write_archive(session_id, "checkpoints", row_dicts)
            with self.db.transaction() as c:
                c.executemany(
                    "DELETE FROM checkpoints WHERE id = ? AND session_id = ?",
                    [(r["id"], session_id) for r in row_dicts],
                )
            total += len(ids)
            rows = conn.execute(
                "SELECT id, session_id, original_path, backup_path, hash, source_hash, "
                "drift_state FROM checkpoints "
                "WHERE session_id = ? AND created_at < ? LIMIT ?",
                (session_id, cutoff_ts, _BATCH_SIZE),
            ).fetchall()

        _LOGGER.info("Archived %d checkpoints for session %s", total, session_id)
        return total

    def _write_archive(
        self, session_id: str, artifact_type: str, rows: list[dict]
    ) -> str:
        """Compress rows and write to archives table. Returns archive id."""
        raw = json.dumps(rows, default=str).encode()
        blob = zlib.compress(raw)
        checksum = hashlib.sha256(blob).hexdigest()
        archive_id = str(uuid.uuid4())

        with self.db.transaction() as conn:
            conn.execute(
                """\
INSERT INTO archives (id, session_id, artifact_type, row_count, size_bytes, blob, checksum)
VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    archive_id,
                    session_id,
                    artifact_type,
                    len(rows),
                    len(blob),
                    blob,
                    checksum,
                ),
            )
        return archive_id


class RetentionPolicy:
    """Applies the configurable retention policy against a SessionDB."""

    def __init__(self, db: SessionDB, config: RetentionConfig | None = None) -> None:
        self.db = db
        self.config = config or RetentionConfig()
        self._archiver = Archiver(db)

    def apply(self, session_id: str) -> dict[str, int]:
        """Prune old events and checkpoints for session_id.

        Returns counts of archived rows per table.
        """
        now = datetime.now(UTC)
        event_cutoff = (
            now - timedelta(days=self.config.max_event_age_days)
        ).isoformat()
        ckpt_cutoff = (
            now - timedelta(days=self.config.max_checkpoint_age_days)
        ).isoformat()

        results: dict[str, int] = {"events": 0, "checkpoints": 0}

        if self.config.auto_archive:
            results["events"] = self._archiver.archive_events(session_id, event_cutoff)
            results["checkpoints"] = self._archiver.archive_checkpoints(
                session_id, ckpt_cutoff
            )
        else:
            with self.db.transaction() as conn:
                conn.execute(
                    "DELETE FROM events WHERE session_id = ? AND ts < ?",
                    (session_id, event_cutoff),
                )
            with self.db.transaction() as conn:
                conn.execute(
                    "DELETE FROM checkpoints WHERE session_id = ? AND created_at < ?",
                    (session_id, ckpt_cutoff),
                )

        return results

    def prune_closed_sessions(self) -> int:
        """Delete CLOSED sessions older than max_closed_session_age_days."""
        cutoff = (
            datetime.now(UTC) - timedelta(days=self.config.max_closed_session_age_days)
        ).isoformat()
        total = 0
        conn = self.db._connect()
        while True:
            rows = conn.execute(
                "SELECT id FROM sessions WHERE status = 'CLOSED' AND created_at < ? LIMIT ?",
                (cutoff, _BATCH_SIZE),
            ).fetchall()
            if not rows:
                break
            ids = [r["id"] for r in rows]
            with self.db.transaction() as c:
                c.executemany("DELETE FROM sessions WHERE id = ?", [(i,) for i in ids])
            total += len(ids)
        if total:
            _LOGGER.info("Pruned %d closed sessions", total)
        return total


def list_archives(db: SessionDB, session_id: str | None = None) -> str:
    """Return a human-readable archive listing for /archive:list."""
    conn = db._connect()
    if session_id:
        rows = conn.execute(
            "SELECT id, session_id, artifact_type, archived_at, row_count, size_bytes "
            "FROM archives WHERE session_id = ? ORDER BY archived_at DESC",
            (session_id,),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT id, session_id, artifact_type, archived_at, row_count, size_bytes "
            "FROM archives ORDER BY archived_at DESC"
        ).fetchall()

    if not rows:
        return "No archives found."

    lines = ["=== Archives ==="]
    for r in rows:
        lines.append(
            f"  {r['id']}  {r['artifact_type']:12s}  "
            f"{r['archived_at']}  rows={r['row_count']}  "
            f"size={_fmt_bytes(r['size_bytes'])}"
            + (f"  session={r['session_id']}" if not session_id else "")
        )
    return "\n".join(lines)


def restore_archive(db: SessionDB, archive_id: str) -> str:
    """Restore rows from an archive back into their source table.

    Verifies sha256(blob) == checksum before re-inserting.
    Skips duplicate primary keys with a warning (not an error).
    """
    import hashlib

    conn = db._connect()
    row = conn.execute("SELECT * FROM archives WHERE id = ?", (archive_id,)).fetchone()
    if row is None:
        return f"Archive '{archive_id}' not found."

    blob: bytes = row["blob"]
    stored_checksum: str = row["checksum"]
    actual_checksum = hashlib.sha256(blob).hexdigest()

    if actual_checksum != stored_checksum:
        return (
            f"Checksum mismatch for archive '{archive_id}' — data may be corrupt. "
            f"Expected {stored_checksum}, got {actual_checksum}."
        )

    rows = json.loads(zlib.decompress(blob).decode())
    artifact_type: str = row["artifact_type"]

    inserted = 0
    skipped = 0

    _INSERT_SQL: dict[str, str] = {
        "events": (
            "INSERT OR IGNORE INTO events (id, session_id, kind, payload, ts) "
            "VALUES (:id, :session_id, :kind, :payload, :ts)"
        ),
        "checkpoints": (
            "INSERT OR IGNORE INTO checkpoints "
            "(id, session_id, original_path, backup_path, hash, source_hash, drift_state) "
            "VALUES (:id, :session_id, :original_path, :backup_path, :hash, :source_hash, :drift_state)"
        ),
        "observations": (
            "INSERT OR IGNORE INTO observations "
            "(id, session_id, content, relevance, source_event_ids, ts) "
            "VALUES (:id, :session_id, :content, :relevance, :source_event_ids, :ts)"
        ),
        "reflections": (
            "INSERT OR IGNORE INTO reflections "
            "(id, session_id, content, supporting_observation_ids, legacy) "
            "VALUES (:id, :session_id, :content, :supporting_observation_ids, :legacy)"
        ),
    }

    sql = _INSERT_SQL.get(artifact_type)
    if sql is None:
        return f"Unknown artifact_type '{artifact_type}' — cannot restore."

    with db.transaction() as c:
        for r in rows:
            cur = c.execute(sql, r)
            if cur.rowcount == 0:
                skipped += 1
                _LOGGER.warning("Skipped duplicate row during restore: %s", r)
            else:
                inserted += 1

    return (
        f"Restored archive '{archive_id}' ({artifact_type}): "
        f"{inserted} inserted, {skipped} skipped (duplicates)."
    )


def _fmt_bytes(n: int) -> str:
    value = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024:
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} TB"
