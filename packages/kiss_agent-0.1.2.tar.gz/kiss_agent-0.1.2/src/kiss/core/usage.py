"""Usage and lightweight session-state types."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Literal

import msgspec


class TodoItem(msgspec.Struct, omit_defaults=True):
    text: str
    done: bool = False
    id: str = ""
    status: Literal["pending", "in_progress", "blocked", "done"] = "pending"
    owner: str | None = None
    block_reason: str | None = None
    blocked_by: list[str] = msgspec.field(default_factory=list)


class TeamMessage(msgspec.Struct, omit_defaults=True):
    sender: str
    recipient: str
    text: str
    timestamp: datetime = msgspec.field(default_factory=lambda: datetime.now(UTC))


class TurnUsage(msgspec.Struct, omit_defaults=True):
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    estimated: bool = False
    message_budget: dict[str, int] = msgspec.field(default_factory=dict)
    # set when turn ended abnormally (max_tokens, refusal, context_length_exceeded)
    finish_reason: str | None = None
    thinking_tokens: int = 0  # reasoning tokens billed as output_tokens
