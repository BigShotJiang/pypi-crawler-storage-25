from __future__ import annotations


class StuckLoopError(RuntimeError):
    """Raised when the agent keeps repeating the same tool loop pattern."""


class ReviewerEscalationError(StuckLoopError):
    """Raised when the reviewer rejects work after the maximum retry iterations."""
