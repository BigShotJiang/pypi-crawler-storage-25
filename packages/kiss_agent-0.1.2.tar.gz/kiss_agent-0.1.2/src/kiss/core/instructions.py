"""Instruction discovery and caching — repo-local instructions before turn execution."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import NamedTuple

_LOGGER = logging.getLogger(__name__)


class _CachedFile(NamedTuple):
    """Cache entry tracking mtime + size for invalidation."""

    mtime: float
    size: int
    content: str


class InstructionService:
    """Resolves repo-local instructions using layered discovery.

    Precedence (Decision 3):
    - **Class 1**: Root ``AGENTS.md`` — always wins on conflict.
      Falls back to hardcoded default system policy if absent.
    - **Class 2**: Ancestor and target-directory instruction files,
      layered outermost-first, target-last.

    Cache is revalidated per-turn using mtime + size.
    """

    DEFAULT_SYSTEM_POLICY = (
        "Follow security best practices. Never commit secrets. "
        "Validate inputs at system boundaries. Keep changes atomic."
    )

    _INSTRUCTION_FILES = ("AGENTS.md",)

    def __init__(self, workspace_root: Path) -> None:
        self.workspace_root = workspace_root.resolve()
        self._cache: dict[Path, _CachedFile] = {}

    # -- public API -----------------------------------------------------------

    def resolve(self, target_dir: Path | None = None) -> str:
        """Return the merged instruction block for the current turn.

        ``target_dir`` defaults to ``workspace_root``.
        """
        if target_dir is None:
            target_dir = self.workspace_root
        else:
            target_dir = target_dir.resolve()
            # Clamp to workspace_root if outside
            try:
                target_dir.relative_to(self.workspace_root)
            except ValueError:
                _LOGGER.warning(
                    "target_dir %s is outside workspace — using workspace_root",
                    target_dir,
                )
                target_dir = self.workspace_root

        parts: list[str] = []

        # Class 1: Root AGENTS.md (always first, highest priority)
        root_instructions = self._read_class1()
        if root_instructions:
            parts.append(root_instructions)

        # Class 2: Ancestors + target directory (outermost-first, target-last)
        class2 = self._read_class2(target_dir)
        if class2:
            parts.append(class2)

        if not parts:
            return self.DEFAULT_SYSTEM_POLICY

        # Check for rule collisions between Class 1 and Class 2
        # (warnings logged inside check_collisions)
        self.check_collisions(target_dir)

        return "\n\n---\n\n".join(parts)

    def invalidate(self) -> None:
        """Clear the instruction cache. Call at the start of each turn
        to force revalidation on next ``resolve()``."""
        self._cache.clear()

    def _read_class1(self) -> str | None:
        """Read the root AGENTS.md. Returns None if absent."""
        root_file = self.workspace_root / "AGENTS.md"
        content = self._read_cached(root_file)
        if content is None:
            _LOGGER.debug("Root AGENTS.md absent — using default system policy")
            return None
        return content

    def _read_class2(self, target_dir: Path) -> str:
        """Read ancestor + target instruction files, outermost-first."""
        # Walk from workspace_root to target_dir collecting instruction files
        candidates: list[Path] = []
        for instruction_name in self._INSTRUCTION_FILES:
            # Collect all ancestors (outermost first)
            ancestors = list(target_dir.relative_to(self.workspace_root).parents)
            ancestors.reverse()  # outermost first

            for ancestor in ancestors:
                candidate = self.workspace_root / ancestor / instruction_name
                if candidate.is_file():
                    candidates.append(candidate)

            # Target directory itself
            target_file = target_dir / instruction_name
            if target_file.is_file() and target_file not in candidates:
                candidates.append(target_file)

        parts: list[str] = []
        for candidate in candidates:
            content = self._read_cached(candidate)
            if content is not None:
                rel = candidate.relative_to(self.workspace_root)
                parts.append(f"### {rel}\n\n{content}")

        if not parts:
            return ""
        return "\n\n---\n\n".join(parts)

    # -- cache ----------------------------------------------------------------

    def _read_cached(self, path: Path) -> str | None:
        """Read file with mtime+size cache invalidation."""
        try:
            stat = path.stat()
        except OSError:
            return None

        cached = self._cache.get(path)
        if (
            cached is not None
            and cached.mtime == stat.st_mtime
            and cached.size == stat.st_size
        ):
            return cached.content

        try:
            content = path.read_text(encoding="utf-8")
        except OSError:
            _LOGGER.warning("Failed to read instruction file: %s", path)
            return None

        self._cache[path] = _CachedFile(
            mtime=stat.st_mtime,
            size=stat.st_size,
            content=content,
        )
        return content

    # -- collision detection --------------------------------------------------

    def check_collisions(self, target_dir: Path | None = None) -> list[str]:
        """Detect rule collisions between Class 1 and Class 2 files.

        Returns a list of warning messages for any detected conflicts.
        """
        if target_dir is None:
            target_dir = self.workspace_root
        target_dir = target_dir.resolve()

        # Ensure target_dir is within workspace_root
        try:
            target_dir.relative_to(self.workspace_root)
        except ValueError:
            _LOGGER.warning(
                "check_collisions: target_dir %s is outside workspace %s",
                target_dir,
                self.workspace_root,
            )
            return []

        warnings: list[str] = []
        root_file = self.workspace_root / "AGENTS.md"
        root_content = self._read_cached(root_file)
        if root_content is None:
            return warnings

        # Keywords that indicate safety/policy rules in root AGENTS.md
        root_keywords = self._extract_policy_keywords(root_content)

        # Check all Class 2 files for contradictions
        for instruction_name in self._INSTRUCTION_FILES:
            candidates = []
            ancestors = list(target_dir.relative_to(self.workspace_root).parents)
            ancestors.reverse()
            for ancestor in ancestors:
                candidate = self.workspace_root / ancestor / instruction_name
                if candidate.is_file():
                    candidates.append(candidate)
            target_file = target_dir / instruction_name
            if target_file.is_file() and target_file not in candidates:
                candidates.append(target_file)

            for candidate in candidates:
                content = self._read_cached(candidate)
                if content is None:
                    continue
                rel = candidate.relative_to(self.workspace_root)
                content_lower = content.lower()
                for keyword, negations in root_keywords.items():
                    for neg in negations:
                        if neg in content_lower:
                            msg = (
                                f"Rule Collision: {rel} contains '{neg}' "
                                f"which contradicts root policy '{keyword}'"
                            )
                            _LOGGER.warning(msg)
                            warnings.append(msg)

        return warnings

    @staticmethod
    def _extract_policy_keywords(content: str) -> dict[str, list[str]]:
        """Extract safety/policy keywords from root AGENTS.md.

        Returns a mapping of keyword → list of negation patterns that would
        constitute a collision.
        """
        content_lower = content.lower()
        keywords: dict[str, list[str]] = {}

        if "never commit" in content_lower:
            keywords["never commit"] = ["always commit", "auto-commit"]
        if "validate" in content_lower and "input" in content_lower:
            keywords["validate input"] = ["skip validation", "trust input"]
        if "security" in content_lower:
            keywords["security"] = ["ignore security", "disable security"]
        if (
            "no api key" in content_lower
            or "no secret" in content_lower
            or "never log" in content_lower
        ):
            keywords["never log secrets"] = ["log secrets", "print token", "print key"]

        return keywords
