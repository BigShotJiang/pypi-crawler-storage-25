from __future__ import annotations

import sys
from collections.abc import MutableMapping
from typing import Any

import structlog
from opentelemetry import trace as otel_trace

_CONFIGURED = False


def _add_otel_context(
    _logger: Any,
    _method_name: str,
    event_dict: MutableMapping[str, Any],
) -> MutableMapping[str, Any]:
    span = otel_trace.get_current_span()
    span_context = span.get_span_context()
    if span_context.is_valid:
        event_dict.setdefault("trace_id", f"{span_context.trace_id:032x}")
        event_dict.setdefault("span_id", f"{span_context.span_id:016x}")
        event_dict.setdefault("trace_flags", int(span_context.trace_flags))
    return event_dict


def configure_diagnostics() -> None:
    """Configure structured local diagnostics for stdout/stderr output."""
    global _CONFIGURED
    if _CONFIGURED:
        return

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso", utc=True),
            _add_otel_context,
            structlog.processors.JSONRenderer(),
        ],
        logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
        cache_logger_on_first_use=True,
    )
    _CONFIGURED = True


def get_logger(name: str | None = None) -> structlog.BoundLogger:
    """Return a configured structured logger."""
    if not _CONFIGURED:
        configure_diagnostics()
    return structlog.get_logger(name)
