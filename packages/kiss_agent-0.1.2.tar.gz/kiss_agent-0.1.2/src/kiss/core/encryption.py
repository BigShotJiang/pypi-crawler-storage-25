"""Encryption-at-rest hooks for SessionDB.

Spec (Decision 8):
- EncryptionBackend Protocol — swappable without changing call sites.
- PlaintextBackend (identity) is the default.
- SQLCipher backend is optional; if requested but unavailable, emit a warning
  and fall back to plaintext — never refuse to start.
"""

from __future__ import annotations

import logging
from typing import Protocol, runtime_checkable

_LOGGER = logging.getLogger(__name__)


@runtime_checkable
class EncryptionBackend(Protocol):
    def encrypt(self, payload: bytes) -> bytes: ...
    def decrypt(self, payload: bytes) -> bytes: ...
    def is_available(self) -> bool: ...
    def backend_name(self) -> str: ...


class PlaintextBackend:
    """Identity backend — no encryption. Default when encryption is disabled."""

    def encrypt(self, payload: bytes) -> bytes:
        return payload

    def decrypt(self, payload: bytes) -> bytes:
        return payload

    def is_available(self) -> bool:
        return True

    def backend_name(self) -> str:
        return "plaintext"


class SQLCipherBackend:
    """SQLCipher encryption backend (optional, requires sqlcipher3 or pysqlcipher3)."""

    def __init__(self, key: str) -> None:
        self._key = key
        self._available: bool | None = None

    def is_available(self) -> bool:
        if self._available is None:
            try:
                import sqlcipher3  # type: ignore[import]  # noqa: F401

                self._available = True
            except ImportError:
                try:
                    import pysqlcipher3  # type: ignore[import]  # noqa: F401

                    self._available = True
                except ImportError:
                    self._available = False
        return self._available

    def backend_name(self) -> str:
        return "sqlcipher"

    def encrypt(self, payload: bytes) -> bytes:
        return payload

    def decrypt(self, payload: bytes) -> bytes:
        return payload

    def pragma_key(self) -> str:
        """Return the PRAGMA key= statement to run at connection open."""
        return f"PRAGMA key={self._key!r}"


def make_backend(enabled: bool, key: str | None = None) -> EncryptionBackend:
    """Return the appropriate backend based on settings.

    If encryption is requested but SQLCipher is unavailable, falls back to
    plaintext with a visible warning (spec requirement: never fail silently,
    never refuse to start).
    """
    if not enabled:
        return PlaintextBackend()

    backend = SQLCipherBackend(key or "")
    if not backend.is_available():
        _LOGGER.warning(
            "Encryption requested but SQLCipher not available — "
            "session data stored unencrypted."
        )
        return PlaintextBackend()

    return backend
