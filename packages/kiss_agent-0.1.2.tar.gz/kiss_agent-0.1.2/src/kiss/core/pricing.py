from __future__ import annotations

import json
from pathlib import Path

_PRICES_PATH = Path(__file__).parent.parent / "data" / "prices.json"
_USER_PRICES_PATH = Path.home() / ".kiss" / "prices.json"
_cache: dict | None = None


def load_prices() -> dict:
    global _cache
    if _cache is not None:
        return _cache
    with _PRICES_PATH.open(encoding="utf-8") as f:
        prices: dict = json.load(f)
    if _USER_PRICES_PATH.exists():
        with _USER_PRICES_PATH.open(encoding="utf-8") as f:
            user_prices = json.load(f)
        prices = {**prices, **user_prices}
    _cache = prices
    return prices


def estimate_cost(
    model: str,
    input_tokens: int,
    output_tokens: int,
    cache_read_tokens: int = 0,
    cache_write_tokens: int = 0,
) -> float | None:
    prices = load_prices()
    entry = prices.get(model)
    if entry is None:
        return None
    return (
        entry["input_per_million"] * input_tokens / 1_000_000
        + entry["output_per_million"] * output_tokens / 1_000_000
        + entry.get("cache_read_per_million", 0.0) * cache_read_tokens / 1_000_000
        + entry.get("cache_write_per_million", 0.0) * cache_write_tokens / 1_000_000
    )
