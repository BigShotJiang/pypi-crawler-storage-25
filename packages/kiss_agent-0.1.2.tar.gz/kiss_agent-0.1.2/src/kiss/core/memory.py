"""Two-tier memory layer: Observer, Reflector, Pruner, FTS search (tasks 7.1–7.10).

Spec (Decision 9):
- ObservationRecord: content-addressed id, timestamped session events.
- ReflectionRecord: durable crystallized facts with supporting_observation_ids.
- render_summary: mechanical concatenation — NO LLM rewrite.
- Observer: fire-and-forget at turn_end, token-bounded, single in-flight.
- Reflector: LLM-driven, ≥2 supporting IDs pass 1, ≥1 pass 2.
- Pruner: LLM-driven, drops uncited/low-relevance, 80% budget target.
"""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from kiss.core.session_db import SessionDB

_LOGGER = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Records
# ---------------------------------------------------------------------------


@dataclass
class ObservationRecord:
    id: str
    session_id: str
    content: str
    ts: str
    relevance: str = "medium"
    source_event_ids: list[str] = field(default_factory=list)
    coverage_tag: str = "uncited"


@dataclass
class ReflectionRecord:
    id: str
    session_id: str
    content: str
    supporting_observation_ids: list[str] = field(default_factory=list)
    legacy: bool = False


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _estimate_tokens(text: str) -> int:
    """Estimate token count: len(words) * 1.3 (spec requirement)."""
    return int(len(text.split()) * 1.3)


def _load_observations(db: SessionDB, session_id: str) -> list[ObservationRecord]:
    conn = db._connect()
    rows = conn.execute(
        "SELECT id, session_id, content, ts, relevance, source_event_ids, coverage_tag "
        "FROM observations WHERE session_id = ? ORDER BY ts ASC",
        (session_id,),
    ).fetchall()
    result = []
    for r in rows:
        result.append(
            ObservationRecord(
                id=r["id"],
                session_id=r["session_id"],
                content=r["content"],
                ts=r["ts"],
                relevance=r["relevance"],
                source_event_ids=json.loads(r["source_event_ids"] or "[]"),
                coverage_tag=r["coverage_tag"],
            )
        )
    return result


def _load_reflections(db: SessionDB, session_id: str) -> list[ReflectionRecord]:
    conn = db._connect()
    rows = conn.execute(
        "SELECT id, session_id, content, supporting_observation_ids, legacy "
        "FROM reflections WHERE session_id = ? ORDER BY rowid ASC",
        (session_id,),
    ).fetchall()
    result = []
    for r in rows:
        result.append(
            ReflectionRecord(
                id=r["id"],
                session_id=r["session_id"],
                content=r["content"],
                supporting_observation_ids=json.loads(
                    r["supporting_observation_ids"] or "[]"
                ),
                legacy=bool(r["legacy"]),
            )
        )
    return result


def _pool_tokens(observations: list[ObservationRecord]) -> int:
    return sum(_estimate_tokens(o.content) for o in observations)


# ---------------------------------------------------------------------------
# 7.3 render_summary — mechanical concatenation, NO LLM
# ---------------------------------------------------------------------------


def render_summary(
    reflections: list[ReflectionRecord],
    observations: list[ObservationRecord],
) -> str:
    """Assemble memory summary block by mechanical concatenation.

    Spec: never LLM-rewrite full history — eliminates summary-of-summary drift.
    """
    parts: list[str] = []

    if reflections:
        lines = ["## Reflections"]
        for r in reflections:
            lines.append(f"- [{r.id}] {r.content}")
        parts.append("\n".join(lines))

    if observations:
        lines = ["## Observations"]
        for o in observations:
            lines.append(f"- [{o.id}] ({o.relevance}/{o.coverage_tag}) {o.content}")
        parts.append("\n".join(lines))

    return "\n\n".join(parts)


# ---------------------------------------------------------------------------
# 7.7 memory_fts_search — FTS5 BM25 ranked
# ---------------------------------------------------------------------------


def memory_fts_search(
    db: SessionDB, session_id: str, query: str, limit: int = 10
) -> list[dict[str, Any]]:
    """FTS5 BM25-ranked search over observations_fts + reflections_fts."""
    conn = db._connect()
    results: list[dict[str, Any]] = []

    obs_rows = conn.execute(
        "SELECT o.id, o.content, o.ts, o.relevance, bm25(observations_fts) AS score "
        "FROM observations_fts "
        "JOIN observations o ON o.session_id = observations_fts.session_id "
        "  AND o.content = observations_fts.content "
        "WHERE observations_fts MATCH ? AND observations_fts.session_id = ? "
        "ORDER BY score LIMIT ?",
        (query, session_id, limit),
    ).fetchall()
    for r in obs_rows:
        results.append({"type": "observation", **dict(r)})

    ref_rows = conn.execute(
        "SELECT r.id, r.content, bm25(reflections_fts) AS score "
        "FROM reflections_fts "
        "JOIN reflections r ON r.session_id = reflections_fts.session_id "
        "  AND r.content = reflections_fts.content "
        "WHERE reflections_fts MATCH ? AND reflections_fts.session_id = ? "
        "ORDER BY score LIMIT ?",
        (query, session_id, limit),
    ).fetchall()
    for r in ref_rows:
        results.append({"type": "reflection", **dict(r)})

    results.sort(key=lambda x: x.get("score", 0))
    return results[:limit]


# ---------------------------------------------------------------------------
# 7.6 recall — return source evidence for an observation or reflection id
# ---------------------------------------------------------------------------


def recall(db: SessionDB, session_id: str, memory_id: str) -> str:
    """Return raw source event entries for an observation or reflection ID."""
    conn = db._connect()

    obs = conn.execute(
        "SELECT source_event_ids FROM observations WHERE session_id = ? AND id = ?",
        (session_id, memory_id),
    ).fetchone()
    ref = None
    if obs is None:
        ref = conn.execute(
            "SELECT supporting_observation_ids FROM reflections "
            "WHERE session_id = ? AND id = ?",
            (session_id, memory_id),
        ).fetchone()

    if obs is None and ref is None:
        return f"No observation or reflection found with id '{memory_id}'."

    source_ids: list[str] = []
    if obs:
        source_ids = json.loads(obs["source_event_ids"] or "[]")
    elif ref:
        obs_ids = json.loads(ref["supporting_observation_ids"] or "[]")
        for oid in obs_ids:
            obs_row = conn.execute(
                "SELECT source_event_ids FROM observations WHERE session_id = ? AND id = ?",
                (session_id, oid),
            ).fetchone()
            if obs_row:
                source_ids.extend(json.loads(obs_row["source_event_ids"] or "[]"))

    if not source_ids:
        return f"Memory '{memory_id}' has no linked source events."

    rows = conn.execute(
        f"SELECT id, kind, payload, ts FROM events "
        f"WHERE session_id = ? AND id IN ({','.join('?' * len(source_ids))})"
        f" ORDER BY id ASC",
        (session_id, *source_ids),
    ).fetchall()

    lines = [f"Source evidence for '{memory_id}':"]
    for r in rows:
        lines.append(f"  [{r['id']}] {r['kind']} @ {r['ts']}: {r['payload']}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 7.2 MemoryObserver — async fire-and-forget, single in-flight
# ---------------------------------------------------------------------------


class MemoryObserver:
    """Captures events since last bound and writes ObservationRecords.

    Token counting: len(text.split()) * 1.3 per spec (not API billed tokens).
    """

    def __init__(
        self,
        db: SessionDB,
        observation_threshold_tokens: int = 1_000,
        timeout_seconds: int = 30,
    ) -> None:
        self.db = db
        self.threshold = observation_threshold_tokens
        self.timeout = timeout_seconds

    def should_observe(self, session_id: str) -> bool:
        """Return True if tokens since last bound exceed threshold."""
        conn = self.db._connect()
        bound_row = conn.execute(
            "SELECT value FROM metadata WHERE key = ?",
            (f"obs_bound_{session_id}",),
        ).fetchone()
        last_event_id = int(bound_row["value"]) if bound_row else 0

        rows = conn.execute(
            "SELECT payload FROM events WHERE session_id = ? AND id > ? ORDER BY id ASC",
            (session_id, last_event_id),
        ).fetchall()
        tokens = sum(_estimate_tokens(r["payload"] or "") for r in rows)
        return tokens >= self.threshold

    async def observe(self, session_id: str) -> list[ObservationRecord]:
        """Extract ObservationRecords from events since last bound.

        Updates the last bound marker on success.
        """
        conn = self.db._connect()
        bound_row = conn.execute(
            "SELECT value FROM metadata WHERE key = ?",
            (f"obs_bound_{session_id}",),
        ).fetchone()
        last_event_id = int(bound_row["value"]) if bound_row else 0

        rows = conn.execute(
            "SELECT id, kind, payload, ts FROM events "
            "WHERE session_id = ? AND id > ? ORDER BY id ASC",
            (session_id, last_event_id),
        ).fetchall()

        if not rows:
            return []

        new_bound = rows[-1]["id"]
        records: list[ObservationRecord] = []
        ts = datetime.now(UTC).isoformat()

        for row in rows:
            payload = row["payload"] or ""
            if not payload.strip():
                continue
            content = f"{row['kind']}: {payload[:500]}"
            obs_id = self.db.insert_observation(
                session_id,
                content,
                relevance="medium",
                source_event_ids=[str(row["id"])],
            )
            records.append(
                ObservationRecord(
                    id=obs_id,
                    session_id=session_id,
                    content=content,
                    ts=ts,
                    source_event_ids=[str(row["id"])],
                )
            )

        with self.db.transaction() as c:
            c.execute(
                "INSERT OR REPLACE INTO metadata (key, value) VALUES (?, ?)",
                (f"obs_bound_{session_id}", str(new_bound)),
            )

        _LOGGER.info(
            "Observer produced %d observations for session %s", len(records), session_id
        )
        return records

    async def run_with_timeout(self, session_id: str) -> list[ObservationRecord]:
        """Run observe() with a timeout. Returns [] on timeout/failure."""
        try:
            return await asyncio.wait_for(self.observe(session_id), self.timeout)
        except asyncio.TimeoutError:
            _LOGGER.warning(
                "Observer timed out after %ds for session %s", self.timeout, session_id
            )
            return []
        except Exception:
            _LOGGER.exception("Observer failed for session %s", session_id)
            self.db.append_event(
                session_id,
                "memory_error",
                json.dumps(
                    {
                        "role": "observer",
                        "pass": 0,
                        "error_message": "observer failed",
                        "ts": datetime.now(UTC).isoformat(),
                    }
                ),
            )
            return []


# ---------------------------------------------------------------------------
# 7.4 Reflector — LLM-driven, up to 2 passes
# ---------------------------------------------------------------------------

LLMCallable = Callable[[str], Awaitable[str]]

_REFLECTOR_PROMPT = """\
You are crystallizing durable facts from session observations into reflections.

Each reflection must:
- State a concrete, durable fact (user identity, project constraint, hard decision)
- Cite 2+ supporting observation IDs for pass 1, 1+ for pass 2
- Be concise (1-2 sentences max)

Respond with a JSON array only:
[
  {{"content": "...", "supporting_observation_ids": ["id1", "id2"]}},
  ...
]

Observations:
{observations}

Existing reflections (do not duplicate):
{reflections}
"""

_PRUNER_PROMPT = """\
You are pruning low-value observations to keep the pool within budget.

Coverage tags:
- uncited: no reflection cites it
- cited: ≥1 reflection
- reinforced: ≥4 reflections

Drop uncited+low-relevance observations first. Preserve cited/reinforced ones.
Budget target: keep pool under {budget_tokens} tokens.

Respond with a JSON array of observation IDs to DROP only:
["id1", "id2", ...]

Observations (id, relevance, coverage_tag, content):
{observations}
"""


class Reflector:
    """LLM-driven: crystallizes observations into ReflectionRecords.

    Pass 1: requires ≥2 supporting_observation_ids.
    Pass 2: requires ≥1.
    Falls back to no-op on LLM failure.
    """

    def __init__(
        self,
        db: SessionDB,
        call_fn: LLMCallable,
        max_passes: int = 2,
        max_tokens_per_pass: int = 32_000,
    ) -> None:
        self.db = db
        self.call_fn = call_fn
        self.max_passes = max_passes
        self.max_tokens_per_pass = max_tokens_per_pass

    async def run(self, session_id: str) -> int:
        """Run up to max_passes of reflection. Returns count of new reflections."""
        total = 0
        for pass_num in range(1, self.max_passes + 1):
            min_support = 2 if pass_num == 1 else 1
            count = await self._run_pass(session_id, pass_num, min_support)
            total += count
            if count == 0:
                break
        return total

    async def _run_pass(self, session_id: str, pass_num: int, min_support: int) -> int:
        observations = _load_observations(self.db, session_id)
        reflections = _load_reflections(self.db, session_id)

        # Truncate to fit token budget
        obs_text = "\n".join(
            f"[{o.id}] ({o.relevance}) {o.content}" for o in observations
        )
        if _estimate_tokens(obs_text) > self.max_tokens_per_pass:
            # Keep most recent observations that fit
            kept: list[ObservationRecord] = []
            tokens = 0
            for o in reversed(observations):
                t = _estimate_tokens(o.content)
                if tokens + t > self.max_tokens_per_pass:
                    break
                kept.insert(0, o)
                tokens += t
            observations = kept
            obs_text = "\n".join(
                f"[{o.id}] ({o.relevance}) {o.content}" for o in observations
            )

        ref_text = "\n".join(f"[{r.id}] {r.content}" for r in reflections)
        prompt = _REFLECTOR_PROMPT.format(
            observations=obs_text or "(none)",
            reflections=ref_text or "(none)",
        )

        try:
            response = await self.call_fn(prompt)
            raw = _extract_json(response)
            candidates = json.loads(raw)
        except Exception as exc:
            _LOGGER.warning("Reflector pass %d failed: %s", pass_num, exc)
            self.db.append_event(
                session_id,
                "memory_error",
                json.dumps(
                    {
                        "role": "reflector",
                        "pass": pass_num,
                        "error_message": str(exc),
                        "ts": datetime.now(UTC).isoformat(),
                    }
                ),
            )
            return 0

        count = 0
        for item in candidates:
            if not isinstance(item, dict):
                continue
            content = item.get("content", "").strip()
            support_ids = item.get("supporting_observation_ids", [])
            if not content or len(support_ids) < min_support:
                continue
            self.db.insert_reflection(
                session_id, content, supporting_observation_ids=support_ids
            )
            count += 1

        # Update coverage tags on cited observations
        if count:
            await _update_coverage_tags(self.db, session_id)

        _LOGGER.info("Reflector pass %d: %d new reflections", pass_num, count)
        return count


# ---------------------------------------------------------------------------
# 7.5 Pruner — LLM-driven, drops low-value observations
# ---------------------------------------------------------------------------


class Pruner:
    """LLM-driven: drops uncited/low-relevance observations to hit 80% budget target.

    Falls back to no-op on LLM failure.
    """

    def __init__(
        self,
        db: SessionDB,
        call_fn: LLMCallable,
        max_passes: int = 2,
        max_tokens_per_pass: int = 32_000,
        reflection_threshold_tokens: int = 30_000,
    ) -> None:
        self.db = db
        self.call_fn = call_fn
        self.max_passes = max_passes
        self.max_tokens_per_pass = max_tokens_per_pass
        self.threshold = reflection_threshold_tokens

    async def run(self, session_id: str) -> int:
        """Run up to max_passes of pruning. Returns count of observations dropped."""
        total = 0
        for pass_num in range(1, self.max_passes + 1):
            dropped = await self._run_pass(session_id, pass_num)
            total += dropped
            if dropped == 0:
                break
            observations = _load_observations(self.db, session_id)
            if _pool_tokens(observations) <= int(self.threshold * 0.8):
                break
        return total

    async def _run_pass(self, session_id: str, pass_num: int) -> int:
        observations = _load_observations(self.db, session_id)
        budget_tokens = int(self.threshold * 0.8)

        obs_text = "\n".join(
            f"[{o.id}] rel={o.relevance} tag={o.coverage_tag} {o.content}"
            for o in observations
        )
        if _estimate_tokens(obs_text) > self.max_tokens_per_pass:
            obs_text = obs_text[: self.max_tokens_per_pass * 4]

        prompt = _PRUNER_PROMPT.format(
            budget_tokens=budget_tokens,
            observations=obs_text or "(none)",
        )

        try:
            response = await self.call_fn(prompt)
            raw = _extract_json(response)
            drop_ids: list[str] = json.loads(raw)
        except Exception as exc:
            _LOGGER.warning("Pruner pass %d failed: %s", pass_num, exc)
            self.db.append_event(
                session_id,
                "memory_error",
                json.dumps(
                    {
                        "role": "pruner",
                        "pass": pass_num,
                        "error_message": str(exc),
                        "ts": datetime.now(UTC).isoformat(),
                    }
                ),
            )
            return 0

        if not drop_ids:
            return 0

        with self.db.transaction() as conn:
            conn.executemany(
                "DELETE FROM observations WHERE session_id = ? AND id = ?",
                [(session_id, oid) for oid in drop_ids],
            )

        _LOGGER.info("Pruner pass %d: dropped %d observations", pass_num, len(drop_ids))
        return len(drop_ids)


# ---------------------------------------------------------------------------
# Coverage tag updater
# ---------------------------------------------------------------------------


async def _update_coverage_tags(db: SessionDB, session_id: str) -> None:
    """Recompute coverage_tag for all observations based on reflection citations."""
    reflections = _load_reflections(db, session_id)
    citation_count: dict[str, int] = {}
    for r in reflections:
        for oid in r.supporting_observation_ids:
            citation_count[oid] = citation_count.get(oid, 0) + 1

    with db.transaction() as conn:
        for oid, count in citation_count.items():
            tag = "reinforced" if count >= 4 else "cited"
            conn.execute(
                "UPDATE observations SET coverage_tag = ? WHERE session_id = ? AND id = ?",
                (tag, session_id, oid),
            )
        # Reset uncited observations
        cited_ids = list(citation_count.keys())
        if cited_ids:
            placeholders = ",".join("?" * len(cited_ids))
            conn.execute(
                f"UPDATE observations SET coverage_tag = 'uncited' "
                f"WHERE session_id = ? AND id NOT IN ({placeholders})",
                (session_id, *cited_ids),
            )
        else:
            conn.execute(
                "UPDATE observations SET coverage_tag = 'uncited' WHERE session_id = ?",
                (session_id,),
            )


# ---------------------------------------------------------------------------
# 7.8 Compaction hook — Observer → assemble summary; Reflector+Pruner above threshold
# ---------------------------------------------------------------------------


async def run_memory_pipeline(
    session_id: str,
    db: SessionDB,
    observer: MemoryObserver,
    reflector: Reflector | None,
    pruner: Pruner | None,
    reflection_threshold_tokens: int = 30_000,
) -> dict[str, Any]:
    """Observer → Reflector → Pruner pipeline.

    Called at compaction or manually via /memory:compact.
    Reflector + Pruner only run when pool exceeds reflection_threshold_tokens.
    """
    results: dict[str, Any] = {
        "observations_added": 0,
        "reflections_added": 0,
        "observations_pruned": 0,
    }

    # Observer: sync catch-up for uncovered gap
    new_obs = await observer.run_with_timeout(session_id)
    results["observations_added"] = len(new_obs)

    # Check if above threshold for Reflector+Pruner
    observations = _load_observations(db, session_id)
    pool_tokens = _pool_tokens(observations)

    if pool_tokens >= reflection_threshold_tokens:
        if reflector is not None:
            results["reflections_added"] = await reflector.run(session_id)
        if pruner is not None:
            results["observations_pruned"] = await pruner.run(session_id)

    return results


# ---------------------------------------------------------------------------
# 7.9 memory_status — for /memory:status CLI
# ---------------------------------------------------------------------------


def memory_status(db: SessionDB, session_id: str) -> str:
    """Return human-readable memory status string."""
    conn = db._connect()

    obs_rows = conn.execute(
        "SELECT coverage_tag, COUNT(*) as c FROM observations "
        "WHERE session_id = ? GROUP BY coverage_tag",
        (session_id,),
    ).fetchall()
    ref_count = conn.execute(
        "SELECT COUNT(*) as c FROM reflections WHERE session_id = ?", (session_id,)
    ).fetchone()["c"]

    coverage: dict[str, int] = {"uncited": 0, "cited": 0, "reinforced": 0}
    for r in obs_rows:
        coverage[r["coverage_tag"]] = r["c"]
    total_obs = sum(coverage.values())

    # LLM failure events
    error_rows = conn.execute(
        "SELECT payload FROM events WHERE session_id = ? AND kind = 'memory_error' "
        "ORDER BY id DESC LIMIT 10",
        (session_id,),
    ).fetchall()
    errors = []
    roles_affected: set[str] = set()
    for row in error_rows:
        try:
            d = json.loads(row["payload"] or "{}")
            errors.append(d)
            if "role" in d:
                roles_affected.add(d["role"])
        except json.JSONDecodeError:
            pass

    lines = [
        "=== Memory Status ===",
        f"  Observations:    {total_obs}",
        f"    uncited:       {coverage['uncited']}",
        f"    cited:         {coverage['cited']}",
        f"    reinforced:    {coverage['reinforced']}",
        f"  Reflections:     {ref_count}",
        f"  LLM failures:    {len(errors)}",
    ]
    if roles_affected:
        lines.append(f"  Roles affected:  {', '.join(sorted(roles_affected))}")
    if errors:
        last = errors[0]
        lines.append(
            f"  Last error:      [{last.get('role', '?')}] "
            f"{last.get('error_message', '?')} @ {last.get('ts', '?')}"
        )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_json(text: str) -> str:
    """Extract the first JSON array from an LLM response."""
    start = text.find("[")
    end = text.rfind("]")
    if start == -1 or end == -1 or end < start:
        raise ValueError(f"No JSON array found in response: {text[:200]}")
    return text[start : end + 1]
