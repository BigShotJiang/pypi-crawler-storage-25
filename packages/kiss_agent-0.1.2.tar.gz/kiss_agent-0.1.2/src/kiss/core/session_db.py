"""SQLite session persistence with schema versioning and forward migrations."""

from __future__ import annotations

import hashlib
import json
import logging
import shutil
import sqlite3
from collections.abc import Callable
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from kiss.core.encryption import EncryptionBackend

_LOGGER = logging.getLogger(__name__)

_SCHEMA_VERSION = 2


# ---------------------------------------------------------------------------
# Schema definitions
# ---------------------------------------------------------------------------

_CREATE_TABLES = """\
CREATE TABLE IF NOT EXISTS sessions (
    id              TEXT PRIMARY KEY,
    workspace_root  TEXT NOT NULL,
    config          TEXT,
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    status          TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'CRASHED', 'CLOSED')),
    lease_owner     TEXT,
    lease_expires_at TEXT
);

CREATE TABLE IF NOT EXISTS events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  TEXT NOT NULL REFERENCES sessions(id),
    kind        TEXT NOT NULL,
    payload     TEXT,
    ts          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS turns (
    id          TEXT PRIMARY KEY,
    session_id  TEXT NOT NULL REFERENCES sessions(id),
    status      TEXT NOT NULL DEFAULT 'STARTED'
                    CHECK (status IN ('STARTED', 'COMMITTED', 'FAILED', 'ABORTED', 'ROLLED_BACK')),
    started_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    ended_at    TEXT,
    error       TEXT
);

CREATE TABLE IF NOT EXISTS ledger (
    session_id      TEXT PRIMARY KEY REFERENCES sessions(id),
    goal            TEXT,
    decisions       TEXT,
    progress        TEXT,
    next_steps      TEXT,
    ledger_commit   TEXT
);

CREATE TABLE IF NOT EXISTS observations (
    id                  TEXT NOT NULL,
    session_id          TEXT NOT NULL REFERENCES sessions(id),
    content             TEXT NOT NULL,
    ts                  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    relevance           TEXT NOT NULL DEFAULT 'medium'
                            CHECK (relevance IN ('low', 'medium', 'high', 'critical')),
    source_event_ids    TEXT,
    coverage_tag        TEXT NOT NULL DEFAULT 'uncited'
                            CHECK (coverage_tag IN ('uncited', 'cited', 'reinforced')),
    PRIMARY KEY (session_id, id)
);

CREATE TABLE IF NOT EXISTS reflections (
    id                          TEXT NOT NULL,
    session_id                  TEXT NOT NULL REFERENCES sessions(id),
    content                     TEXT NOT NULL,
    supporting_observation_ids  TEXT,
    legacy                      INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (session_id, id)
);

CREATE TABLE IF NOT EXISTS memory (
    id          TEXT PRIMARY KEY,
    session_id  TEXT NOT NULL REFERENCES sessions(id),
    content     TEXT NOT NULL,
    ts          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS checkpoints (
    id              INTEGER,
    session_id      TEXT NOT NULL REFERENCES sessions(id),
    original_path   TEXT NOT NULL,
    backup_path     TEXT NOT NULL,
    hash            TEXT NOT NULL,
    source_hash     TEXT NOT NULL DEFAULT '',
    drift_state     TEXT,
    PRIMARY KEY (id, session_id)
);

CREATE TABLE IF NOT EXISTS workers (
    id              TEXT NOT NULL,
    session_id      TEXT NOT NULL REFERENCES sessions(id),
    agent_name      TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'RUNNING',
    workspace_path  TEXT,
    commit_sha      TEXT,
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    PRIMARY KEY (id, session_id)
);

CREATE TABLE IF NOT EXISTS skills (
    name            TEXT NOT NULL,
    session_id      TEXT NOT NULL REFERENCES sessions(id),
    source_path     TEXT,
    trust           INTEGER NOT NULL DEFAULT 0,
    scope           TEXT,
    version         TEXT,
    fingerprint     TEXT,
    priority        INTEGER NOT NULL DEFAULT 100,
    PRIMARY KEY (name, session_id)
);

CREATE TABLE IF NOT EXISTS metadata (
    key     TEXT PRIMARY KEY,
    value   TEXT
);

CREATE TABLE IF NOT EXISTS pty_sessions (
    id              TEXT PRIMARY KEY,
    session_id      TEXT NOT NULL REFERENCES sessions(id),
    pid             INTEGER NOT NULL,
    shell           TEXT NOT NULL,
    cwd             TEXT NOT NULL,
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    last_heartbeat  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS archives (
    id              TEXT PRIMARY KEY,
    session_id      TEXT REFERENCES sessions(id),
    artifact_type   TEXT NOT NULL,
    archived_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    row_count       INTEGER NOT NULL DEFAULT 0,
    size_bytes      INTEGER NOT NULL DEFAULT 0,
    blob            BLOB,
    checksum        TEXT
);
"""

_CREATE_FTS = """\
CREATE VIRTUAL TABLE IF NOT EXISTS events_fts USING fts5(session_id UNINDEXED, search_text);
CREATE VIRTUAL TABLE IF NOT EXISTS observations_fts USING fts5(session_id UNINDEXED, content);
CREATE VIRTUAL TABLE IF NOT EXISTS reflections_fts USING fts5(session_id UNINDEXED, content);
"""


def _extract_search_text(kind: str, payload: str | None) -> str:
    """Extract human-readable search text from an event for FTS indexing.

    Indexes kind + string leaf values from JSON payload instead of raw JSON blobs.
    """
    parts = [kind]
    if payload:
        try:
            data = json.loads(payload)
            parts.extend(_collect_strings(data))
        except (json.JSONDecodeError, TypeError):
            parts.append(payload[:500])
    return " ".join(parts)


def _collect_strings(obj: object, depth: int = 0) -> list[str]:
    """Recursively collect string leaf values from a JSON object (max depth 3)."""
    if depth > 3:
        return []
    if isinstance(obj, str):
        return [obj] if obj.strip() else []
    if isinstance(obj, dict):
        out: list[str] = []
        for v in obj.values():
            out.extend(_collect_strings(v, depth + 1))
        return out
    if isinstance(obj, list):
        out = []
        for item in obj:
            out.extend(_collect_strings(item, depth + 1))
        return out
    return []


class SessionDB:
    """Unified SQLite session store with schema versioning and forward migrations."""

    def __init__(
        self,
        db_path: Path,
        encryption_backend: EncryptionBackend | None = None,
    ) -> None:
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: sqlite3.Connection | None = None
        self._encryption: EncryptionBackend
        if encryption_backend is None:
            from kiss.core.encryption import PlaintextBackend

            self._encryption = PlaintextBackend()
        else:
            self._encryption = encryption_backend
        self._ensure_schema()

    # -- connection helpers ---------------------------------------------------

    def _connect(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(str(self.db_path))
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA foreign_keys=ON")
            self._conn.row_factory = sqlite3.Row
        return self._conn

    def _connect_autocommit(self) -> sqlite3.Connection:
        """Open a connection in autocommit mode (required for VACUUM)."""
        conn = sqlite3.connect(str(self.db_path), isolation_level=None)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.row_factory = sqlite3.Row
        return conn

    @contextmanager
    def transaction(self):
        """Context manager for a single atomic transaction."""
        conn = self._connect()
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def execute_raw(self, sql: str, params: tuple = ()) -> None:
        """Execute a raw SQL statement outside a transaction context."""
        with self.transaction() as conn:
            conn.execute(sql, params)

    # -- schema versioning ---------------------------------------------------

    @property
    def schema_version(self) -> int:
        """Read current schema_version from the metadata table."""
        conn = self._connect()
        row = conn.execute(
            "SELECT value FROM metadata WHERE key = 'schema_version'"
        ).fetchone()
        if row is None:
            return 0
        return int(row["value"])

    def _set_schema_version(self, conn: sqlite3.Connection, version: int) -> None:
        conn.execute(
            "INSERT OR REPLACE INTO metadata (key, value) VALUES ('schema_version', ?)",
            (str(version),),
        )

    def _ensure_schema(self) -> None:
        """Create tables if they don't exist, then run forward migrations."""
        conn = self._connect()

        # Bootstrap metadata table if it doesn't exist yet
        conn.execute(
            """\
CREATE TABLE IF NOT EXISTS metadata (
    key TEXT PRIMARY KEY,
    value TEXT
)"""
        )

        current = self.schema_version

        if current == 0:
            # First run — create all tables at the target schema version
            conn.executescript(_CREATE_TABLES)
            conn.executescript(_CREATE_FTS)
            self._set_schema_version(conn, _SCHEMA_VERSION)
            conn.commit()
            _LOGGER.info("SessionDB initialised at schema_version=%d", _SCHEMA_VERSION)
            return

        # Forward migrations: current+1 → target
        if current < _SCHEMA_VERSION:
            self._migrate(current, _SCHEMA_VERSION)

    # -- migration engine ----------------------------------------------------

    def _migrate(self, from_version: int, to_version: int) -> None:
        """Apply forward migrations sequentially with rollback safety."""
        _LOGGER.info(
            "SessionDB migrating schema_version %d → %d", from_version, to_version
        )
        backup_path = self.backup()
        try:
            for target in range(from_version + 1, to_version + 1):
                migrator = _MIGRATIONS.get(target)
                if migrator is None:
                    raise MigrationError(f"No migration defined for version {target}")
                conn = self._connect()
                try:
                    migrator(conn)
                    self._set_schema_version(conn, target)
                    conn.commit()
                    _LOGGER.info("Migration to schema_version=%d applied", target)
                except Exception:
                    conn.rollback()
                    raise
        except Exception:
            # Rollback: restore from pre-migration backup
            _LOGGER.error("Migration failed — restoring from backup")
            self.close()
            self.restore(backup_path)
            raise
        else:
            # Cleanup backup on successful migration
            try:
                backup_path.unlink()
                for suffix in ("-wal", "-shm"):
                    bak = backup_path.with_name(backup_path.name + suffix)
                    if bak.exists():
                        bak.unlink()
            except OSError:
                _LOGGER.debug("Could not remove migration backup: %s", backup_path)

    # -- backup / restore ----------------------------------------------------

    def backup(self, path: Path | None = None) -> Path:
        """Create a timestamped copy of the database file."""
        if path is None:
            ts = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
            path = self.db_path.with_name(f"session.db.backup.{ts}")
        conn = self._conn
        if conn is not None:
            rc = conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
            if rc and rc[0] != 0:
                _LOGGER.warning(
                    "WAL checkpoint returned busy (%d) — backup may include uncommitted WAL data",
                    rc[0],
                )
        shutil.copy2(str(self.db_path), str(path))
        for suffix in ("-wal", "-shm"):
            src = self.db_path.with_name(self.db_path.name + suffix)
            if src.exists():
                shutil.copy2(str(src), str(path) + suffix)
        _LOGGER.info("SessionDB backup created: %s", path)
        return path

    def restore(self, backup_path: Path) -> None:
        """Restore the database from a backup file."""
        if not backup_path.exists():
            raise FileNotFoundError(f"Backup not found: {backup_path}")
        # Verify by attempting to open
        try:
            test = sqlite3.connect(str(backup_path))
            test.execute("SELECT 1").fetchone()
            test.execute("PRAGMA integrity_check").fetchone()
            test.close()
        except sqlite3.DatabaseError as exc:
            raise ValueError(f"Backup integrity check failed: {exc}") from exc

        self.close()
        # Replace current db
        for suffix in ("", "-wal", "-shm"):
            src = backup_path.with_name(backup_path.name + suffix)
            dst = self.db_path.with_name(self.db_path.name + suffix)
            if src.exists():
                shutil.copy2(str(src), str(dst))
            elif dst.exists():
                dst.unlink(missing_ok=True)
        # Reopen
        self._connect()
        _LOGGER.info("SessionDB restored from: %s", backup_path)

    # -- convenience helpers -------------------------------------------------

    @staticmethod
    def content_addressed_id(session_id: str, content: str) -> str:
        """SHA-256 based content-addressed ID (16-char lowercase hex)."""
        return hashlib.sha256(f"{session_id}:{content}".encode()).hexdigest()[:16]

    def upsert_session(self, session_id: str, workspace_root: str) -> None:
        """Create or update a session row."""
        with self.transaction() as conn:
            conn.execute(
                """\
INSERT INTO sessions (id, workspace_root) VALUES (?, ?)
ON CONFLICT(id) DO UPDATE SET workspace_root=excluded.workspace_root""",
                (session_id, workspace_root),
            )

    def append_event(
        self, session_id: str, kind: str, payload: str | None = None
    ) -> int:
        """Append an event row and index it in events_fts. Returns new row id."""
        search_text = _extract_search_text(kind, payload)
        with self.transaction() as conn:
            cur = conn.execute(
                "INSERT INTO events (session_id, kind, payload) VALUES (?, ?, ?)",
                (session_id, kind, payload),
            )
            row_id: int = cur.lastrowid or 0
            conn.execute(
                "INSERT INTO events_fts (session_id, search_text) VALUES (?, ?)",
                (session_id, search_text),
            )
            return row_id

    def begin_turn(self, turn_id: str, session_id: str) -> None:
        """Mark a turn as STARTED."""
        with self.transaction() as conn:
            conn.execute(
                "INSERT INTO turns (id, session_id, status) VALUES (?, ?, 'STARTED')",
                (turn_id, session_id),
            )

    def commit_turn(self, turn_id: str) -> None:
        """Mark a turn as COMMITTED."""
        with self.transaction() as conn:
            conn.execute(
                "UPDATE turns SET status = 'COMMITTED', ended_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?",
                (turn_id,),
            )

    def fail_turn(self, turn_id: str, error: str | None = None) -> None:
        """Mark a turn as FAILED."""
        with self.transaction() as conn:
            conn.execute(
                "UPDATE turns SET status = 'FAILED', ended_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now'), error = ? WHERE id = ?",
                (error, turn_id),
            )

    def insert_observation(
        self,
        session_id: str,
        content: str,
        relevance: str = "medium",
        source_event_ids: list[str] | None = None,
    ) -> str:
        """Insert an observation (dedup via content-addressed id). Returns the id."""
        obs_id = self.content_addressed_id(session_id, content)
        import json

        with self.transaction() as conn:
            conn.execute(
                """\
INSERT OR IGNORE INTO observations (id, session_id, content, relevance, source_event_ids)
VALUES (?, ?, ?, ?, ?)""",
                (
                    obs_id,
                    session_id,
                    content,
                    relevance,
                    json.dumps(source_event_ids) if source_event_ids else "[]",
                ),
            )
        return obs_id

    def insert_reflection(
        self,
        session_id: str,
        content: str,
        supporting_observation_ids: list[str] | None = None,
        legacy: bool = False,
    ) -> str:
        """Insert a reflection (dedup via content-addressed id). Returns the id."""
        ref_id = self.content_addressed_id(session_id, content)
        import json

        with self.transaction() as conn:
            conn.execute(
                """\
INSERT OR IGNORE INTO reflections (id, session_id, content, supporting_observation_ids, legacy)
VALUES (?, ?, ?, ?, ?)""",
                (
                    ref_id,
                    session_id,
                    content,
                    json.dumps(supporting_observation_ids)
                    if supporting_observation_ids
                    else "[]",
                    1 if legacy else 0,
                ),
            )
        return ref_id

    def orphan_reap_turns(self) -> list[str]:
        """Set lingering STARTED turns to FAILED (orphan reaper). Returns reaped turn ids."""
        with self.transaction() as conn:
            rows = conn.execute(
                "SELECT id FROM turns WHERE status = 'STARTED'"
            ).fetchall()
            turn_ids = [r["id"] for r in rows]
            if turn_ids:
                conn.execute(
                    "UPDATE turns SET status = 'FAILED', ended_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE status = 'STARTED'"
                )
        return turn_ids

    def mark_ledger_stale(self, session_id: str) -> None:
        """Mark the ledger STALE on compaction hard-truncation.

        Persists the current ledger goal/decisions/progress/next_steps as-is,
        then prepends ``[STALE]`` to the goal field to signal that the ledger
        reflects pre-truncation state and should not be trusted for planning.
        """
        with self.transaction() as conn:
            row = conn.execute(
                "SELECT goal, decisions, progress, next_steps FROM ledger WHERE session_id = ?",
                (session_id,),
            ).fetchone()
            if row is None:
                conn.execute(
                    "INSERT INTO ledger (session_id, goal) VALUES (?, ?)",
                    (session_id, "[STALE] No ledger state available."),
                )
            else:
                goal = row["goal"] or ""
                if not goal.startswith("[STALE]"):
                    goal = f"[STALE] {goal}"
                conn.execute(
                    """\
UPDATE ledger SET goal = ?, decisions = ?, progress = ?, next_steps = ?
WHERE session_id = ?""",
                    (
                        goal,
                        row["decisions"],
                        row["progress"],
                        row["next_steps"],
                        session_id,
                    ),
                )

    def db_stats(self) -> dict:
        """Return row counts and db file sizes."""
        conn = self._connect()
        tables = [
            "sessions",
            "events",
            "checkpoints",
            "observations",
            "reflections",
        ]
        counts = {}
        for table in tables:
            row = conn.execute(f"SELECT COUNT(*) AS c FROM {table}").fetchone()
            counts[table] = row["c"]
        counts["schema_version"] = self.schema_version
        counts["db_size_bytes"] = self.db_path.stat().st_size
        wal_path = self.db_path.with_name(self.db_path.name + "-wal")
        counts["wal_size_bytes"] = wal_path.stat().st_size if wal_path.exists() else 0
        return counts


# ---------------------------------------------------------------------------
# Migration registry
# ---------------------------------------------------------------------------


class MigrationError(Exception):
    """Raised when a migration step cannot be applied."""


_MIGRATIONS: dict[int, Callable[[sqlite3.Connection], None]] = {}


def migration(version: int):
    """Decorator to register a forward migration function."""

    def decorator(fn):
        _MIGRATIONS[version] = fn
        return fn

    return decorator


@migration(2)
def _migrate_v2(conn: sqlite3.Connection) -> None:
    """Add coverage_tag column to observations."""
    conn.execute(
        "ALTER TABLE observations ADD COLUMN "
        "coverage_tag TEXT NOT NULL DEFAULT 'uncited'"
    )


# ---------------------------------------------------------------------------
# LegacyImporter — migrate JSON/JSONL files to SessionDB
# ---------------------------------------------------------------------------


class LegacyImporter:
    """Migrate legacy JSONL turn logs and JSON snapshots into SessionDB.

    Explicitly excludes ``traces.jsonl`` — it is written by
    ``turn_lifecycle_state.py`` at turn end and is not legacy session data.
    """

    def __init__(self, db: SessionDB, sessions_dir: Path) -> None:
        self.db = db
        self.sessions_dir = sessions_dir

    def import_all(self, session_id: str, workspace_root: Path | str) -> dict[str, int]:
        """Import all legacy files. Returns counts of imported rows."""
        results: dict[str, int] = {
            "jsonl_events": 0,
            "snapshots": 0,
            "memory_rows": 0,
        }

        self.db.upsert_session(session_id, str(workspace_root))

        # Import JSONL turn logs (exclude traces.jsonl)
        for jsonl_path in sorted(self.sessions_dir.glob("*.jsonl")):
            if jsonl_path.name == "traces.jsonl":
                continue
            results["jsonl_events"] += self._import_jsonl(jsonl_path, session_id)

        # Import JSON snapshots
        for snapshot_path in sorted(self.sessions_dir.glob("export_*.json")):
            self._import_snapshot(snapshot_path, session_id)
            results["snapshots"] += 1

        # Import legacy markdown memory files
        results["memory_rows"] = self._import_memory_files(
            session_id, Path(workspace_root)
        )

        if results["jsonl_events"] or results["snapshots"]:
            self.db.append_event(
                session_id,
                "legacy_import",
                f'{{"jsonl_events": {results["jsonl_events"]}, "snapshots": {results["snapshots"]}, "memory_rows": {results["memory_rows"]}}}',
            )

        _LOGGER.info("LegacyImporter results: %s", results)
        return results

    def _import_jsonl(self, jsonl_path: Path, session_id: str) -> int:
        """Import a single JSONL turn log file."""
        import msgspec

        count = 0
        with jsonl_path.open("r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = msgspec.json.decode(line)
                    role = entry.get("role", "unknown")
                    content = entry.get("content", "")
                    ts = entry.get("ts", "")
                    self.db.append_event(
                        session_id,
                        f"turn_{role}",
                        msgspec.json.encode({"content": content, "ts": ts}).decode(),
                    )
                    count += 1
                except (msgspec.DecodeError, KeyError):
                    _LOGGER.warning("Skipping malformed JSONL line in %s", jsonl_path)
        return count

    def _import_snapshot(self, snapshot_path: Path, session_id: str) -> None:
        """Import a single JSON snapshot file as a consolidated event."""
        import msgspec

        try:
            data = msgspec.json.decode(snapshot_path.read_bytes())
        except (OSError, msgspec.DecodeError):
            _LOGGER.warning("Skipping corrupt snapshot: %s", snapshot_path)
            return

        uuid = data.get("uuid", snapshot_path.stem)
        ts = data.get("ts", "")
        messages = data.get("messages", [])
        todos = data.get("todos", [])
        phase = data.get("phase", "")

        payload = msgspec.json.encode(
            {
                "uuid": uuid,
                "ts": ts,
                "message_count": len(messages),
                "todos": todos,
                "phase": phase,
            }
        ).decode()
        self.db.append_event(session_id, "snapshot", payload)

    def _import_memory_files(self, session_id: str, workspace_root: Path) -> int:
        """Import legacy markdown memory files as observations."""
        count = 0
        memory_files = []
        wr = Path(workspace_root)

        global_path = Path.home() / ".kiss" / "memory.md"
        if global_path.exists():
            memory_files.append(("global", global_path))

        project_path = wr / ".kiss" / "memory.md"
        if project_path.exists():
            memory_files.append(("project", project_path))

        for scope, mpath in memory_files:
            content = mpath.read_text(encoding="utf-8")
            for line in content.splitlines():
                line = line.strip().lstrip("- ").strip()
                if not line:
                    continue
                self.db.insert_observation(
                    session_id,
                    f"[{scope} memory] {line}",
                    relevance="medium",
                    source_event_ids=[],
                )
                count += 1

        if count:
            self.db.append_event(
                session_id,
                "schema_migration",
                f'{{"action": "import_memory", "scope": "global+project", "row_count": {count}}}',
            )
        return count


# ---------------------------------------------------------------------------
# Memory → Observations migration (task 1.10)
# ---------------------------------------------------------------------------


def migrate_memory_to_observations(db: SessionDB, session_id: str) -> int:
    """Migrate all rows from the legacy ``memory`` table to ``observations``.

    Per spec: each row becomes one ObservationRecord with relevance='medium',
    ts=migrated_at, source_event_ids=[], id=sha256(f"{session_id}:{content}")[:16].
    On completion writes metadata.memory_migrated_at.
    """
    conn = db._connect()
    rows = conn.execute(
        "SELECT id, content, ts FROM memory WHERE session_id = ?",
        (session_id,),
    ).fetchall()

    count = 0
    migrated_at = datetime.now(UTC).isoformat()

    for row in rows:
        db.insert_observation(
            session_id,
            row["content"],
            relevance="medium",
            source_event_ids=[],
        )
        count += 1

    if count:
        # Append migration event BEFORE updating metadata
        db.append_event(
            session_id,
            "schema_migration",
            f'{{"action": "migrate_memory_to_observations", "row_count": {count}}}',
        )
        with db.transaction() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO metadata (key, value) VALUES ('memory_migrated_at', ?)",
                (migrated_at,),
            )

    _LOGGER.info("Migrated %d memory rows to observations", count)
    return count


# ---------------------------------------------------------------------------
# DB status and vacuum (tasks 1.11, 1.12)
# ---------------------------------------------------------------------------


def db_status(db: SessionDB) -> str:
    """Return a human-readable status string for ``/db:status``."""
    stats = db.db_stats()
    conn = db._connect()

    # FTS status
    fts_rebuilt = conn.execute(
        "SELECT value FROM metadata WHERE key = 'fts_last_rebuilt_at'"
    ).fetchone()
    if fts_rebuilt is None:
        fts_status = "stale (never rebuilt)"
    else:
        fts_status = f"fresh (rebuilt: {fts_rebuilt['value']})"

    # Memory migration status
    mem_migrated = conn.execute(
        "SELECT value FROM metadata WHERE key = 'memory_migrated_at'"
    ).fetchone()
    mem_status = mem_migrated["value"] if mem_migrated else "not migrated"

    memory_row = conn.execute("SELECT COUNT(*) AS c FROM memory").fetchone()
    stats["memory"] = memory_row["c"]

    lines = [
        "=== SessionDB Status ===",
        f"  DB file:         {db.db_path}",
        f"  DB size:         {_fmt_bytes(stats['db_size_bytes'])}",
        f"  WAL size:        {_fmt_bytes(stats['wal_size_bytes'])}",
        f"  Schema version:  {stats['schema_version']}",
        f"  FTS status:      {fts_status}",
        "",
        "  Table row counts:",
        f"    sessions:      {stats['sessions']}",
        f"    events:        {stats['events']}",
        f"    checkpoints:   {stats['checkpoints']}",
        f"    observations:  {stats['observations']}",
        f"    reflections:   {stats['reflections']}",
        f"    memory (legacy): {stats['memory']}",
        "",
        f"  Memory migrated: {mem_status}",
    ]
    return "\n".join(lines)


def db_vacuum(db: SessionDB) -> str:
    """Run VACUUM + FTS rebuild. Returns a summary string."""
    import time

    db._connect().commit()

    conn = db._connect_autocommit()
    try:
        start = time.monotonic()

        for fts_table in ("events_fts", "observations_fts", "reflections_fts"):
            conn.execute(f"INSERT INTO {fts_table}({fts_table}) VALUES('rebuild')")

        conn.execute("VACUUM")

        rebuilt_at = datetime.now(UTC).isoformat()
        conn.execute(
            "INSERT OR REPLACE INTO metadata (key, value) VALUES ('fts_last_rebuilt_at', ?)",
            (rebuilt_at,),
        )
    finally:
        conn.close()

    elapsed = time.monotonic() - start
    new_size = db.db_path.stat().st_size
    wal_path = db.db_path.with_name(db.db_path.name + "-wal")
    wal_size = wal_path.stat().st_size if wal_path.exists() else 0

    lines = [
        "=== DB Vacuum Complete ===",
        f"  Duration:        {elapsed:.1f}s",
        f"  DB size:         {_fmt_bytes(new_size)}",
        f"  WAL size:        {_fmt_bytes(wal_size)}",
        f"  FTS rebuilt at:  {rebuilt_at}",
    ]
    return "\n".join(lines)


def _fmt_bytes(n: int) -> str:
    """Format bytes into human-readable string."""
    value = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024:
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} TB"
