from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
import enum
import hashlib
from pathlib import Path

import msgspec
from typing import Any, Literal

from kiss.agent.plan_types import PlanExecutionState, TurnPhase, WriteBlockedResult
from kiss.core.permission_policy import PermissionPolicy
from kiss.core.settings import WebSearchConfig
from kiss.core.events import Event
from kiss.core.workers import WorkerManagerProtocol
from kiss.core.types import AskUserReply, AskUserRequest, PermissionAction
from kiss.core.events import TodoDelta, TodoUpdateMeta
from kiss.core.tracing import SessionTracer
from kiss.core.usage import TeamMessage, TodoItem

_WRITE_TOOLS: frozenset[str] = frozenset({"write_file", "edit_file", "apply_patch"})


class HealingAction(enum.Enum):
    INJECT_HINT = "inject_hint"
    INJECT_READ = "inject_read"
    COMPACT_CONTEXT = "compact_context"
    RESET_PLAN = "reset_plan"


def _stable_hash(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def _json_for_hash(obj: Any) -> str:
    """Deterministic JSON encoding for hashing (sorts keys, falls back to str)."""

    def _sort(o: Any) -> Any:
        if isinstance(o, dict):
            return {k: _sort(v) for k, v in sorted(o.items())}
        if isinstance(o, list):
            return [_sort(v) for v in o]
        return o

    return msgspec.json.encode(_sort(obj), enc_hook=lambda x: str(x)).decode()


@dataclass(frozen=True)
class PendingToolCall:
    name: str
    args_hash: str


@dataclass(frozen=True)
class StuckLoopCheck:
    action: Literal["ok", "warn", "hard_block", "abort"]
    message: str = ""
    healing: HealingAction | None = None


@dataclass
class StuckLoopTracker:
    call_history: list[tuple[str, str]] = field(default_factory=list)
    result_history: list[tuple[str, str]] = field(default_factory=list)
    warned_signatures: set[str] = field(default_factory=set)
    hard_blocked_signatures: set[str] = field(default_factory=set)
    pending_tool_calls: list[PendingToolCall] = field(default_factory=list)
    blocked_hashes: set[str] = field(default_factory=set)
    read_file_paths: set[str] = field(default_factory=set)

    def reset(self) -> None:
        """Clear loop history and block signatures when restarting a turn."""
        self.call_history.clear()
        self.result_history.clear()
        self.warned_signatures.clear()
        self.hard_blocked_signatures.clear()
        self.pending_tool_calls.clear()
        self.blocked_hashes.clear()
        self.read_file_paths.clear()

    def register_tool_call(self, tool_name: str, args: dict[str, Any]) -> None:
        args_hash = _stable_hash(_json_for_hash(args))
        self.pending_tool_calls.append(PendingToolCall(tool_name, args_hash))

    def mark_blocked(self, tool_name: str, args: dict[str, Any]) -> None:
        """Record this (tool_name, args) combo so _handle_tool_outputs replaces its result."""
        args_hash = _stable_hash(_json_for_hash(args))
        self.blocked_hashes.add(f"{tool_name}:{args_hash}")

    def block_last_pending(self, tool_name: str) -> None:
        """Block the most recently registered call for tool_name (explicit user deny).

        Prevents the agent from re-prompting for the same permission in this turn.
        """
        for call in reversed(self.pending_tool_calls):
            if call.name == tool_name:
                self.blocked_hashes.add(f"{tool_name}:{call.args_hash}")
                return

    def is_hard_blocked(self, tool_name: str, args: dict[str, Any]) -> bool:
        """Return True if this (tool_name, args) is in hard_blocked state."""
        args_hash = _stable_hash(_json_for_hash(args))
        return f"repeat:{tool_name}:{args_hash}" in self.hard_blocked_signatures

    def would_warn_on_next(
        self, tool_name: str, args: dict[str, Any], warn_threshold: int
    ) -> bool:
        """Return True if registering this call would trigger the warn threshold.

        Pure read — does not modify call_history or warned_signatures.
        """
        args_hash = _stable_hash(_json_for_hash(args))
        needle = (tool_name, args_hash)
        count_before = self._count_consecutive(self.call_history, needle)
        signature = f"repeat:{tool_name}:{args_hash}"
        return (
            count_before + 1 >= warn_threshold
            and signature not in self.warned_signatures
        )

    def check(
        self,
        tool_name: str,
        args_hash: str,
        result_text: str,
        warn_threshold: int,
        abort_threshold: int,
    ) -> StuckLoopCheck:
        self.call_history.append((tool_name, args_hash))
        result_hash = _stable_hash(result_text)
        self.result_history.append((tool_name, result_hash))

        history_limit = max(abort_threshold, 5)
        if len(self.call_history) > history_limit:
            self.call_history = self.call_history[-history_limit:]
        if len(self.result_history) > history_limit:
            self.result_history = self.result_history[-history_limit:]

        repeated = self._repeated_args(
            tool_name, args_hash, warn_threshold, abort_threshold
        )
        noop = self._noop_result(
            tool_name, result_hash, warn_threshold, abort_threshold
        )
        alternating = self._alternating_calls(warn_threshold, abort_threshold)

        for candidate in (repeated, noop, alternating):
            if candidate.action == "abort":
                return candidate
        for candidate in (repeated, noop, alternating):
            if candidate.action == "hard_block":
                return candidate
        for candidate in (repeated, noop, alternating):
            if candidate.action == "warn":
                return candidate
        return StuckLoopCheck("ok")

    def _repeated_args(
        self,
        tool_name: str,
        args_hash: str,
        warn_threshold: int,
        abort_threshold: int,
    ) -> StuckLoopCheck:
        needle = (tool_name, args_hash)
        count = self._count_consecutive(self.call_history, needle)
        signature = f"repeat:{tool_name}:{args_hash}"
        healing = (
            HealingAction.INJECT_READ
            if tool_name in _WRITE_TOOLS
            else HealingAction.INJECT_HINT
        )
        if count >= abort_threshold:
            return StuckLoopCheck(
                "abort",
                f"[LOOP DETECTED] {tool_name} was called with identical arguments {count} times. Aborting this turn.",
            )
        if signature in self.hard_blocked_signatures:
            return StuckLoopCheck(
                "hard_block",
                f"[LOOP DETECTED] {tool_name} was called with identical arguments {count} times. Stop repeating this call.",
                healing=healing,
            )
        if count >= warn_threshold and signature not in self.warned_signatures:
            self.warned_signatures.add(signature)
            self.hard_blocked_signatures.add(signature)
            return StuckLoopCheck(
                "warn",
                f"[LOOP DETECTED] You have called {tool_name} with identical arguments {count} times. Try a different approach.",
                healing=healing,
            )
        return StuckLoopCheck("ok")

    def _noop_result(
        self,
        tool_name: str,
        result_hash: str,
        warn_threshold: int,
        abort_threshold: int,
    ) -> StuckLoopCheck:
        needle = (tool_name, result_hash)
        count = self._count_consecutive(self.result_history, needle)
        signature = f"noop:{tool_name}:{result_hash}"
        if count >= abort_threshold:
            return StuckLoopCheck(
                "abort",
                f"[LOOP DETECTED] {tool_name} returned the same result {count} times. Aborting this turn.",
            )
        if signature in self.hard_blocked_signatures:
            return StuckLoopCheck(
                "hard_block",
                f"[LOOP DETECTED] {tool_name} returned the same result {count} times. Stop repeating this call.",
                healing=HealingAction.INJECT_HINT,
            )
        if count >= warn_threshold and signature not in self.warned_signatures:
            self.warned_signatures.add(signature)
            self.hard_blocked_signatures.add(signature)
            return StuckLoopCheck(
                "warn",
                f"[LOOP DETECTED] {tool_name} has returned the same result {count} times. Try a different approach.",
                healing=HealingAction.INJECT_HINT,
            )
        return StuckLoopCheck("ok")

    def _alternating_calls(
        self,
        warn_threshold: int,
        abort_threshold: int,
    ) -> StuckLoopCheck:
        streak = self._alternating_streak()
        streak_len = len(streak)
        if streak_len < 4:
            return StuckLoopCheck("ok")

        warn_at = max(4, warn_threshold)
        abort_at = max(5, abort_threshold)
        first_name, _ = streak[0]
        second_name, _ = streak[1]
        signature = f"alt:{streak[0]}:{streak[1]}"
        if streak_len >= abort_at:
            return StuckLoopCheck(
                "abort",
                f"[LOOP DETECTED] Alternating tool loop detected: {first_name} -> {second_name} repeated {streak_len} calls. Aborting this turn.",
                healing=HealingAction.RESET_PLAN,
            )
        if signature in self.hard_blocked_signatures:
            return StuckLoopCheck(
                "hard_block",
                f"[LOOP DETECTED] Alternating tool loop detected: {first_name} -> {second_name} repeated {streak_len} calls. Stop repeating.",
                healing=HealingAction.COMPACT_CONTEXT,
            )
        if streak_len >= warn_at and signature not in self.warned_signatures:
            self.warned_signatures.add(signature)
            self.hard_blocked_signatures.add(signature)
            return StuckLoopCheck(
                "warn",
                f"[LOOP DETECTED] Alternating tool loop detected: {first_name} -> {second_name} repeated {streak_len} calls. Try a different approach.",
                healing=HealingAction.COMPACT_CONTEXT,
            )
        return StuckLoopCheck("ok")

    @staticmethod
    def _count_consecutive(
        history: list[tuple[str, str]], needle: tuple[str, str]
    ) -> int:
        count = 0
        for item in reversed(history):
            if item != needle:
                break
            count += 1
        return count

    def _alternating_streak(self) -> list[tuple[str, str]]:
        """Detect a repeating [P, Q, P, Q, ...] pattern in call_history.

        P and Q are (tool_name, args_hash) pairs, must be distinct, and must
        share the same tool name (cross-tool alternation is not flagged).
        """
        history = self.call_history
        if len(history) < 4:
            return []
        q, p = history[-1], history[-2]
        if p == q:
            return []
        if p[0] != q[0]:  # different tool names — not a same-tool loop
            return []
        # Walk backwards verifying the [P, Q, P, Q, ...] cycle
        streak = [p, q]
        cycle = (p, q)
        for item in reversed(history[:-2]):
            expected = cycle[(len(streak) + 1) % 2]
            if item != expected:
                break
            streak.append(item)
        streak.reverse()
        if len(streak) < 4:
            return []
        return streak


@dataclass
class TodoNormalizer:
    """Stateful delta normalizer for the TODO_UPDATE event path.

    Owns prior-snapshot state and computes TodoDelta and TodoUpdateMeta on each
    call. Rich/Textual consume the result — they must not diff snapshots locally.
    delta is None on the first emission (no prior baseline).
    all_done fires when pending_count transitions from > 0 to 0.
    """

    _prior_ids: set[str] = field(default_factory=set)
    _prior_done: set[str] = field(default_factory=set)
    _initialized: bool = False

    def compute(self, todos: list[TodoItem]) -> TodoUpdateMeta:
        current_ids = {t.id for t in todos}
        current_done = {t.id for t in todos if t.done}

        pending_count = sum(1 for t in todos if not t.done)
        completed_count = sum(1 for t in todos if t.done)

        in_progress = [t for t in todos if t.status == "in_progress"]
        active_todo_id = in_progress[0].id if len(in_progress) == 1 else None

        delta: TodoDelta | None = None
        all_done = False

        if self._initialized:
            added = sorted(current_ids - self._prior_ids)
            removed = sorted(self._prior_ids - current_ids)
            completed = sorted(current_done - self._prior_done)
            # was done before AND still exists AND is no longer done
            reopened = sorted((self._prior_done & current_ids) - current_done)
            delta = TodoDelta(
                added=added, completed=completed, reopened=reopened, removed=removed
            )
            prior_pending = len(self._prior_ids - self._prior_done)
            all_done = prior_pending > 0 and pending_count == 0

        self._prior_ids = current_ids
        self._prior_done = current_done
        self._initialized = True

        return TodoUpdateMeta(
            snapshot=todos[:],
            pending_count=pending_count,
            completed_count=completed_count,
            delta=delta,
            active_todo_id=active_todo_id,
            all_done=all_done,
        )


@dataclass
class AgentDeps:
    context_window: int = 128_000
    current_usage_tokens: int = 0
    tool_output_safety_buffer: int = 10_000
    tool_output_max_tokens: int = 12_000
    tool_output_min_tokens: int = 1_000
    response_token_reserve: int = 12_000
    stuck_loop_warn_threshold: int = 3
    stuck_loop_abort_threshold: int = 5
    confirm_permission: Callable[[str | PermissionAction], Awaitable[bool]] | None = (
        None
    )
    on_tool_use: Callable[[str, dict[str, Any]], Awaitable[None]] | None = None
    on_tool_result: Callable[[str, str, str, bool], Awaitable[None]] | None = None
    # on_tool_result(name, output, call_id, is_err)
    on_stuck_loop: Callable[[str, Literal["warn", "error"]], Awaitable[None]] | None = (
        None
    )
    # on_stuck_loop(message, severity)
    on_thought: Callable[[str, str], Awaitable[None]] | None = None
    # on_thought(delta, agent_label)
    on_ask_user: Callable[[AskUserRequest], Awaitable[AskUserReply]] | None = None
    # on_ask_user(request) -> AskUserReply
    on_event: Callable[[Event], Awaitable[None]] | None = None
    # on_event(event) -> emit event (e.g. TODO_UPDATE)
    on_logic_approval: Callable[..., Awaitable[Any]] | None = None
    # on_logic_approval(LogicApprovalRequest) -> LogicApprovalReply
    on_typed_tool_result: Callable[[str, Any], Awaitable[None]] | None = None
    # on_typed_tool_result(name, typed_result) — called with typed result before on_tool_result
    resolved_refs: dict[str, Any] = field(default_factory=dict)
    # Turn-scoped @ref entries keyed by the user-visible ref label.
    workspace_root: Path | None = None
    web_search_config: WebSearchConfig = field(default_factory=WebSearchConfig)
    permission_policy: PermissionPolicy = field(default_factory=PermissionPolicy)
    tracer: SessionTracer | None = None
    session_dir: Path | None = None
    stuck_loop_tracker: StuckLoopTracker = field(default_factory=StuckLoopTracker)
    todo_normalizer: TodoNormalizer = field(default_factory=TodoNormalizer)
    todos: list[TodoItem] = field(default_factory=list)
    team_messages: list[TeamMessage] = field(default_factory=list)
    tool_activity: list[str] = field(default_factory=list)
    agent_label: str = "kiss-agent"
    memory_enabled: bool = True
    writes_approved: bool = False
    plan_state: PlanExecutionState = PlanExecutionState.IDLE
    turn_phase: TurnPhase = TurnPhase.RESEARCH
    research_token_threshold: float = 0.40
    compact_requested: str | None = None
    reset_plan_requested: bool = False
    reset_plan_count: int = 0
    _blocked_calls: list[WriteBlockedResult] = field(default_factory=list)
    worker_manager: WorkerManagerProtocol | None = None
    last_tool_name: str = ""
