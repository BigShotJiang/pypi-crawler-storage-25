"""PtyManager — long-lived stateful PTY sessions with stale detection."""

from __future__ import annotations

import asyncio
import fcntl
import json
import logging
import os
import pty
import select
import signal
import struct
import termios
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from kiss.core.session_db import SessionDB

_LOGGER = logging.getLogger(__name__)

_DEFAULT_SHELL = os.environ.get("SHELL", "/bin/bash")
_DEFAULT_HEARTBEAT_TTL_SECONDS = 120
_MAX_OUTPUT_BYTES = 64 * 1024  # 64 KB


@dataclass
class PtySession:
    """A single long-lived PTY session backed by a real shell process."""

    session_id: str
    pty_fd: int
    pid: int
    shell: str
    cwd: str
    created_at: datetime
    last_heartbeat: datetime
    output_buffer: list[bytes] = field(default_factory=list)
    output_bytes: int = 0
    is_alive: bool = True
    truncated: bool = False
    log_path: Path | None = None

    def heartbeat(self) -> None:
        self.last_heartbeat = datetime.now(UTC)

    @property
    def age_seconds(self) -> float:
        return (datetime.now(UTC) - self.created_at).total_seconds()

    @property
    def heartbeat_age_seconds(self) -> float:
        return (datetime.now(UTC) - self.last_heartbeat).total_seconds()


class PtyManager:
    """Manages long-lived PTY sessions with stale detection and orphan reaping.

    Each session is backed by a real shell process (bash/zsh) running in a
    pseudo-terminal, preserving environment state (cwd, env vars, aliases)
    across multiple command executions.

    Sessions are persisted to the ``pty_sessions`` table so the orphan reaper
    can find PIDs from prior crashed runs.
    """

    def __init__(
        self,
        db: SessionDB,
        heartbeat_ttl_seconds: int = _DEFAULT_HEARTBEAT_TTL_SECONDS,
        max_output_bytes: int = _MAX_OUTPUT_BYTES,
        shell: str = _DEFAULT_SHELL,
    ) -> None:
        self.db = db
        self.heartbeat_ttl_seconds = heartbeat_ttl_seconds
        self.max_output_bytes = max_output_bytes
        self.shell = shell
        self._sessions: dict[str, PtySession] = {}
        self._readers: dict[str, asyncio.Task | None] = {}
        self._output_callbacks: dict[str, list[Callable[[str], None]]] = {}

    # -- public API -----------------------------------------------------------

    def create_session(
        self,
        session_id: str,
        cwd: str | None = None,
        on_output: Callable[[str], None] | None = None,
    ) -> PtySession:
        """Create a new PTY session backed by a real shell process.

        Persists the session to DB so it survives restarts and can be reaped.
        Returns the PtySession. Raises if a session with the same ID already
        exists.
        """
        if session_id in self._sessions:
            raise ValueError(f"PTY session '{session_id}' already exists")

        master_fd, slave_fd = pty.openpty()
        self._set_pty_size(master_fd, rows=24, cols=80)
        self._configure_pty(slave_fd)

        cwd_path = cwd or os.getcwd()

        pid = os.fork()
        if pid == 0:
            os.close(master_fd)
            os.setsid()
            fcntl.ioctl(slave_fd, termios.TIOCSCTTY, 0)
            os.dup2(slave_fd, 0)
            os.dup2(slave_fd, 1)
            os.dup2(slave_fd, 2)
            if slave_fd > 2:
                os.close(slave_fd)
            shell_name = os.path.basename(self.shell)
            os.chdir(cwd_path)
            os.execvp(self.shell, [f"-{shell_name}", "-i"])
            os._exit(1)

        os.close(slave_fd)

        now = datetime.now(UTC)
        session = PtySession(
            session_id=session_id,
            pty_fd=master_fd,
            pid=pid,
            shell=self.shell,
            cwd=cwd_path,
            created_at=now,
            last_heartbeat=now,
        )
        self._sessions[session_id] = session
        self._readers[session_id] = None

        if on_output:
            self._output_callbacks.setdefault(session_id, []).append(on_output)

        # Persist to DB
        self._persist_session(session)

        _LOGGER.info(
            "PTY session '%s' created (pid=%d, shell=%s)",
            session_id,
            pid,
            self.shell,
        )
        return session

    async def run_command(
        self,
        session_id: str,
        command: str,
        timeout_seconds: float | None = None,
    ) -> dict[str, Any]:
        """Run a command in an existing PTY session.

        Writes the command to the PTY master fd, then reads output until the
        command completes or timeout is reached.

        Returns ``{"output": str, "truncated": bool, "exit_code": int | None}``.
        """
        session = self._get_session(session_id)
        session.heartbeat()
        self._update_heartbeat(session_id)

        self._write_to_pty(session, command + "\n")

        output_parts: list[str] = []
        truncated = False
        start = _monotonic()

        try:
            while True:
                elapsed = _monotonic() - start
                if timeout_seconds is not None and elapsed >= timeout_seconds:
                    break

                remaining = max(0.1, (timeout_seconds or 30) - elapsed)
                ready = select.select([session.pty_fd], [], [], min(remaining, 0.5))
                if not ready[0]:
                    continue

                try:
                    data = os.read(session.pty_fd, 4096)
                except OSError:
                    break

                if not data:
                    break

                session.output_buffer.append(data)
                session.output_bytes += len(data)

                decoded = data.decode("utf-8", errors="replace")
                output_parts.append(decoded)

                for cb in self._output_callbacks.get(session_id, []):
                    try:
                        cb(decoded)
                    except Exception:
                        _LOGGER.exception("PTY output callback failed")

                if session.output_bytes >= self.max_output_bytes:
                    truncated = True
                    break

        except OSError:
            pass

        exit_code = self._check_exit_code(session)

        output = "".join(output_parts)

        log_path: Path | None = None
        if truncated:
            log_path = self._spill_to_log(session_id, session.output_buffer)

        return {
            "output": output,
            "truncated": truncated,
            "exit_code": exit_code,
            "log_path": str(log_path) if log_path else None,
        }

    def interrupt(self, session_id: str, sig: int = signal.SIGINT) -> None:
        """Send a signal to the active PTY process."""
        session = self._get_session(session_id)
        try:
            os.killpg(os.getpgid(session.pid), sig)
            _LOGGER.info("Sent signal %d to PTY session '%s'", sig, session_id)
        except ProcessLookupError:
            _LOGGER.warning("PTY process already exited: %s", session_id)
        except OSError as exc:
            _LOGGER.error("Failed to send signal to PTY '%s': %s", session_id, exc)

    def close_session(self, session_id: str) -> None:
        """Close a PTY session and kill its process."""
        session = self._sessions.pop(session_id, None)
        if session is None:
            return

        reader = self._readers.pop(session_id, None)
        if reader and not reader.done():
            reader.cancel()

        self._output_callbacks.pop(session_id, None)

        try:
            os.killpg(os.getpgid(session.pid), signal.SIGTERM)
        except (ProcessLookupError, OSError):
            pass

        try:
            os.close(session.pty_fd)
        except OSError:
            pass

        session.is_alive = False
        self._remove_session(session_id)
        _LOGGER.info("PTY session '%s' closed", session_id)

    def get_session(self, session_id: str) -> PtySession | None:
        return self._sessions.get(session_id)

    def list_sessions(self) -> list[PtySession]:
        return list(self._sessions.values())

    # -- stale detection and orphan reaping -----------------------------------

    def is_stale(self, session_id: str) -> bool:
        """Check if a session is stale (owner PID absent or heartbeat expired)."""
        session = self._get_session(session_id)

        if not self._process_alive(session.pid):
            return True

        if session.heartbeat_age_seconds > self.heartbeat_ttl_seconds:
            return True

        return False

    def reap_orphans(self, session_id: str) -> list[str]:
        """Detect and kill stale PTY sessions from prior runs.

        Loads persisted sessions from DB, checks if processes are alive,
        kills stale ones, and marks the owning session status CRASHED.

        Runs THIRD in startup reaper coordination order (after WorkerManager
        has detached from its PTYs).

        Returns list of reaped PTY session IDs.
        """
        reaped: list[str] = []

        # Load persisted sessions from DB
        persisted = self._load_persisted_sessions()

        for row in persisted:
            pty_id = row["id"]
            pid = row["pid"]
            owner_session_id = row["session_id"]
            last_heartbeat_str = row["last_heartbeat"]

            try:
                last_heartbeat = datetime.fromisoformat(last_heartbeat_str)
            except (ValueError, TypeError):
                last_heartbeat = datetime.now(UTC)

            pid_alive = self._process_alive(pid)
            heartbeat_age = (datetime.now(UTC) - last_heartbeat).total_seconds()
            heartbeat_expired = heartbeat_age > self.heartbeat_ttl_seconds

            if not pid_alive or heartbeat_expired:
                # Kill the process if still alive
                if pid_alive:
                    try:
                        os.killpg(os.getpgid(pid), signal.SIGKILL)
                    except (ProcessLookupError, OSError):
                        pass

                # Mark owning session as CRASHED
                self.db.upsert_session(owner_session_id, "")
                with self.db.transaction() as conn:
                    conn.execute(
                        "UPDATE sessions SET status = 'CRASHED' WHERE id = ?",
                        (owner_session_id,),
                    )

                self.db.append_event(
                    session_id,
                    "pty_reaped",
                    json.dumps(
                        {
                            "pty_session_id": pty_id,
                            "owner_session_id": owner_session_id,
                            "pid": pid,
                            "reason": "process_dead"
                            if not pid_alive
                            else "heartbeat_expired",
                        }
                    ),
                )

                self._remove_db_session(pty_id)
                reaped.append(pty_id)

                _LOGGER.info(
                    "Reaped stale PTY session '%s' (pid=%d, reason=%s)",
                    pty_id,
                    pid,
                    "process_dead" if not pid_alive else "heartbeat_expired",
                )

        return reaped

    def on_output(self, session_id: str, callback: Callable[[str], None]) -> None:
        self._output_callbacks.setdefault(session_id, []).append(callback)

    # -- internals ------------------------------------------------------------

    def _get_session(self, session_id: str) -> PtySession:
        session = self._sessions.get(session_id)
        if session is None:
            raise KeyError(f"PTY session '{session_id}' not found")
        return session

    def _persist_session(self, session: PtySession) -> None:
        """Persist PTY session info to DB."""
        with self.db.transaction() as conn:
            conn.execute(
                """\
INSERT OR REPLACE INTO pty_sessions (id, session_id, pid, shell, cwd, created_at, last_heartbeat)
VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    session.session_id,
                    session.session_id,
                    session.pid,
                    session.shell,
                    session.cwd,
                    session.created_at.isoformat(),
                    session.last_heartbeat.isoformat(),
                ),
            )

    def _update_heartbeat(self, session_id: str) -> None:
        """Update heartbeat timestamp in DB."""
        now = datetime.now(UTC).isoformat()
        with self.db.transaction() as conn:
            conn.execute(
                "UPDATE pty_sessions SET last_heartbeat = ? WHERE id = ?",
                (now, session_id),
            )

    def _remove_session(self, session_id: str) -> None:
        """Remove PTY session from DB and in-memory dict."""
        self._remove_db_session(session_id)

    def _remove_db_session(self, session_id: str) -> None:
        """Remove PTY session row from DB."""
        with self.db.transaction() as conn:
            conn.execute("DELETE FROM pty_sessions WHERE id = ?", (session_id,))

    def _load_persisted_sessions(self) -> list:
        """Load all persisted PTY sessions from DB."""
        with self.db.transaction() as conn:
            return conn.execute(
                "SELECT id, session_id, pid, shell, cwd, created_at, last_heartbeat FROM pty_sessions"
            ).fetchall()

    def _write_to_pty(self, session: PtySession, data: str) -> None:
        os.write(session.pty_fd, data.encode("utf-8"))

    def _set_pty_size(self, fd: int, rows: int = 24, cols: int = 80) -> None:
        winsize = struct.pack("HHHH", rows, cols, 0, 0)
        fcntl.ioctl(fd, termios.TIOCSWINSZ, winsize)

    def _configure_pty(self, fd: int) -> None:
        try:
            attrs = termios.tcgetattr(fd)
            attrs[3] = attrs[3] & ~termios.ECHO
            termios.tcsetattr(fd, termios.TCSANOW, attrs)
        except termios.error:
            pass

    def _check_exit_code(self, session: PtySession) -> int | None:
        try:
            pid, status = os.waitpid(session.pid, os.WNOHANG)
            if pid == session.pid:
                session.is_alive = False
                if os.WIFEXITED(status):
                    return os.WEXITSTATUS(status)
                if os.WIFSIGNALED(status):
                    return -os.WTERMSIG(status)
        except ChildProcessError:
            session.is_alive = False
        return None

    def _process_alive(self, pid: int) -> bool:
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return True

    def _cleanup_dead_session(self, session_id: str) -> None:
        session = self._sessions.pop(session_id, None)
        if session is None:
            return

        reader = self._readers.pop(session_id, None)
        if reader and not reader.done():
            reader.cancel()

        self._output_callbacks.pop(session_id, None)

        try:
            os.close(session.pty_fd)
        except OSError:
            pass

        session.is_alive = False

    def _spill_to_log(self, session_id: str, buffer: list[bytes]) -> Path | None:
        try:
            import tempfile

            log_path = Path(tempfile.gettempdir()) / f"kiss-pty-{session_id}.log"
            with log_path.open("wb") as fh:
                for chunk in buffer:
                    fh.write(chunk)
            _LOGGER.info("PTY output spilled to log: %s", log_path)
            return log_path
        except OSError:
            _LOGGER.warning("Failed to spill PTY output to log")
            return None


def _monotonic() -> float:
    return __import__("time").monotonic()
