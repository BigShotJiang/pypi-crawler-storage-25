"""Permission policy schema, loading, and evaluation."""

from __future__ import annotations

import asyncio
from fnmatch import fnmatchcase
import json
from pathlib import Path
from typing import Literal

import msgspec

_GLOBAL_POLICY = Path.home() / ".kiss" / "agent" / "permissions.json"
_LOCAL_POLICY = Path(".kiss") / "permissions.json"

PolicyAction = Literal["allow", "ask", "deny"]


class PermissionPolicyError(Exception): ...


class PermissionRule(msgspec.Struct, rename="camel"):
    pattern: str = "*"
    action: PolicyAction = "ask"


class ToolPermissionPolicy(msgspec.Struct, rename="camel"):
    default: PolicyAction | None = None
    rules: list[PermissionRule] = []


class RolePermissionPolicy(msgspec.Struct, rename="camel"):
    allow_tools: list[str] = []
    deny_tools: list[str] = []


class PermissionPolicy(msgspec.Struct, rename="camel"):
    tools: dict[str, ToolPermissionPolicy] = {}
    roles: dict[str, RolePermissionPolicy] = {}


def _permission_policy_load_sync(
    workspace_root: Path | None = None,
) -> PermissionPolicy:
    """Load permission policy from project override or global fallback (blocking)."""
    local_path = (
        (workspace_root / ".kiss" / "permissions.json")
        if workspace_root is not None
        else _LOCAL_POLICY
    )
    if local_path.exists():
        path = local_path
    elif _GLOBAL_POLICY.exists():
        path = _GLOBAL_POLICY
    else:
        return PermissionPolicy()

    try:
        raw = json.loads(path.read_text())
    except json.JSONDecodeError as exc:
        raise PermissionPolicyError(f"{path} is not valid JSON: {exc}") from exc
    try:
        return msgspec.convert(raw, PermissionPolicy)
    except msgspec.ValidationError as exc:
        raise PermissionPolicyError(f"{path} has invalid policy: {exc}") from exc


async def permission_policy_load(
    workspace_root: Path | None = None,
) -> PermissionPolicy:
    """Load permission policy asynchronously."""
    return await asyncio.to_thread(_permission_policy_load_sync, workspace_root)


def role_allows_tool(
    policy: PermissionPolicy | None,
    role: str | None,
    tool_name: str,
) -> bool:
    if policy is None or role is None:
        return True
    role_policy = policy.roles.get(role)
    if role_policy is None:
        return True
    if _tool_matches_any(tool_name, role_policy.deny_tools):
        return False
    if role_policy.allow_tools and not _tool_matches_any(
        tool_name, role_policy.allow_tools
    ):
        return False
    return True


def evaluate_tool_policy(
    policy: PermissionPolicy | None,
    tool_name: str,
    candidates: tuple[str, ...] = (),
) -> PolicyAction | None:
    if policy is None:
        return None
    tool_policies = []
    wildcard = policy.tools.get("*")
    if wildcard is not None:
        tool_policies.append(wildcard)
    specific = policy.tools.get(tool_name)
    if specific is not None:
        tool_policies.append(specific)
    if not tool_policies:
        return None

    matched_allow = False
    matched_ask = False
    for tool_policy in tool_policies:
        for rule in tool_policy.rules:
            if _matches_candidates(rule.pattern, candidates):
                if rule.action == "deny":
                    return "deny"
                if rule.action == "allow":
                    matched_allow = True
                elif rule.action == "ask":
                    matched_ask = True
    if matched_allow:
        return "allow"
    if matched_ask:
        return "ask"

    specific_default = specific.default if specific is not None else None
    if specific_default is not None:
        return specific_default
    if wildcard is not None:
        return wildcard.default
    return None


def _matches_candidates(pattern: str, candidates: tuple[str, ...]) -> bool:
    if not candidates:
        return fnmatchcase("", pattern)
    return any(fnmatchcase(candidate, pattern) for candidate in candidates)


def _tool_matches_any(tool_name: str, patterns: list[str]) -> bool:
    return any(fnmatchcase(tool_name, pattern) for pattern in patterns)
