"""Prompt loader — resolves markdown prompt files with an override chain.

Resolution order (first found wins):
  1. ~/.kiss/prompts/<name>.md        (user-global override)
  2. .kiss/prompts/<name>.md          (project-local override)
  3. kiss/data/<name>.md              (package default)
"""

from __future__ import annotations

import asyncio
from importlib import resources
from pathlib import Path

_USER_DIR = Path.home() / ".kiss" / "prompts"
_LOCAL_DIR = Path(".kiss") / "prompts"


def prompt_load_sync(name: str, **kwargs: str) -> str:
    """Load a prompt by name and optionally interpolate {variables} (blocking)."""
    for candidate in [
        _USER_DIR / f"{name}.md",
        _LOCAL_DIR / f"{name}.md",
    ]:
        if candidate.exists():
            text = candidate.read_text()
            return text.format_map(kwargs) if kwargs else text

    # Fall back to the package-bundled default.
    try:
        ref = resources.files("kiss.data").joinpath(f"{name}.md")
        text = ref.read_text(encoding="utf-8")
        return text.format_map(kwargs) if kwargs else text
    except (FileNotFoundError, TypeError) as exc:
        raise FileNotFoundError(
            f"No prompt file found for '{name}'. "
            f"Looked in: {_USER_DIR}, {_LOCAL_DIR}, kiss/data/"
        ) from exc


def _prompt_load_sync(name: str, **kwargs: str) -> str:
    """Backward-compatible private alias for synchronous prompt loading."""
    return prompt_load_sync(name, **kwargs)


async def prompt_load(name: str, **kwargs: str) -> str:
    """Load a prompt by name and optionally interpolate {variables} asynchronously.

    Args:
        name: Prompt name without the `.md` extension (e.g. ``"system"``).
        **kwargs: Variables to substitute via :meth:`str.format_map`.

    Returns:
        The rendered prompt string.

    Raises:
        FileNotFoundError: If no prompt file is found for *name*
    """
    return await asyncio.to_thread(prompt_load_sync, name, **kwargs)
