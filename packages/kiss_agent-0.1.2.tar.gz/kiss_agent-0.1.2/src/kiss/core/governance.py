"""Four-pass governance pipeline — pre-LLM hygiene for tool calls and context."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

_LOGGER = logging.getLogger(__name__)


@dataclass
class GovernanceResult:
    """Result of the four-pass governance pipeline."""

    deduplicated_calls: int = 0
    no_op_calls_detected: int = 0
    mechanical_summary: str = ""
    compaction_triggered: bool = False
    tokens_before_compaction: int = 0
    tokens_after_compaction: int = 0
    stuck_loop_detected: bool = False
    stale_ledger: bool = False
    safety_blocked: bool = False
    safety_block_reason: str = ""
    final_prompt_assembled: bool = False

    @property
    def is_blocked(self) -> bool:
        return self.safety_blocked


@dataclass(frozen=True)
class _ToolCallSignature:
    """Hashable signature for a tool call."""

    tool_name: str
    args: frozenset

    @classmethod
    def from_call(cls, tool_name: str, args: dict[str, Any]) -> "_ToolCallSignature":
        return cls(
            tool_name=tool_name,
            args=frozenset((k, _freeze(v)) for k, v in args.items()),
        )


def _freeze(value: Any) -> Any:
    if isinstance(value, dict):
        return frozenset((k, _freeze(v)) for k, v in value.items())
    if isinstance(value, list):
        return tuple(_freeze(v) for v in value)
    return value


def run_governance_pipeline(
    tool_calls: list[tuple[str, dict[str, Any]]],
    context_tokens: int,
    context_budget: int,
    stuck_loop_warn_threshold: int = 3,
    stuck_loop_abort_threshold: int = 5,
    ledger_stale: bool = False,
) -> GovernanceResult:
    result = GovernanceResult()
    _pass1_dedup(tool_calls, result)
    _pass2_compaction(context_tokens, context_budget, result)
    _pass3_safety(
        tool_calls,
        stuck_loop_warn_threshold,
        stuck_loop_abort_threshold,
        ledger_stale,
        result,
    )
    result.final_prompt_assembled = True
    return result


def _pass1_dedup(
    tool_calls: list[tuple[str, dict[str, Any]]], result: GovernanceResult
) -> None:
    seen: set[_ToolCallSignature] = set()
    no_op_patterns = {
        ("read_file", frozenset()),
        ("run_bash", frozenset()),
    }
    for tool_name, args in tool_calls:
        sig = _ToolCallSignature.from_call(tool_name, args)
        if sig in seen:
            result.deduplicated_calls += 1
        seen.add(sig)
        if (tool_name, frozenset()) in no_op_patterns and not args:
            result.no_op_calls_detected += 1
    parts = []
    if result.deduplicated_calls:
        parts.append(f"{result.deduplicated_calls} duplicate tool calls removed")
    if result.no_op_calls_detected:
        parts.append(f"{result.no_op_calls_detected} no-op calls detected")
    result.mechanical_summary = "; ".join(parts) if parts else "OK"


def _pass2_compaction(
    context_tokens: int, context_budget: int, result: GovernanceResult
) -> None:
    result.tokens_before_compaction = context_tokens
    if context_tokens > context_budget:
        result.compaction_triggered = True
        _LOGGER.warning(
            "Context over budget: %d > %d — compaction triggered",
            context_tokens,
            context_budget,
        )
    result.tokens_after_compaction = context_tokens


def _pass3_safety(
    tool_calls: list[tuple[str, dict[str, Any]]],
    warn_threshold: int,
    abort_threshold: int,
    ledger_stale: bool,
    result: GovernanceResult,
) -> None:
    if ledger_stale:
        result.stale_ledger = True
        _LOGGER.warning("Ledger is stale — safety validation flagged")

    # Identical consecutive calls
    if len(tool_calls) >= abort_threshold:
        recent = tool_calls[-abort_threshold:]
        if all(tc == recent[0] for tc in recent):
            result.stuck_loop_detected = True
            result.safety_blocked = True
            result.safety_block_reason = (
                f"Stuck loop detected: {abort_threshold} identical calls"
            )
            _LOGGER.error("Safety blocked: %s", result.safety_block_reason)
            return

    # Alternating pattern: A, B, A, B, ...
    half = max(2, abort_threshold // 2)
    if len(tool_calls) >= 2 * half:
        tail = tool_calls[-(2 * half) :]
        pattern_a = tail[0]
        pattern_b = tail[1]
        if pattern_a != pattern_b:
            is_alternating = all(
                tail[i] == (pattern_a if i % 2 == 0 else pattern_b)
                for i in range(len(tail))
            )
            if is_alternating:
                result.stuck_loop_detected = True
                result.safety_blocked = True
                result.safety_block_reason = (
                    f"Stuck loop detected: {2 * half} alternating calls "
                    f"({pattern_a[0]} <-> {pattern_b[0]})"
                )
                _LOGGER.error("Safety blocked: %s", result.safety_block_reason)
