"""Reasoning budget control — cap thinking and retry with partial context."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ReasoningBudget:
    max_thinking_tokens: int = 0
    current_thinking_tokens: int = 0
    retry_count: int = 0
    max_retries: int = 2

    def should_reduce_thinking(self) -> bool:
        return (
            self.max_thinking_tokens > 0
            and self.current_thinking_tokens > self.max_thinking_tokens
            and self.retry_count < self.max_retries
        )

    def record_thinking(self, tokens: int) -> None:
        self.current_thinking_tokens = tokens

    def record_retry(self) -> None:
        self.retry_count += 1

    def reset(self) -> None:
        self.current_thinking_tokens = 0
        self.retry_count = 0
