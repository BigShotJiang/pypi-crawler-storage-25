"""AgentContext — process-scoped singleton managing long-lived services."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import socket
import uuid
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from kiss.core.session_db import SessionDB
from kiss.core.skills import SkillLoader
from kiss.core.pty_manager import PtyManager
from kiss.core.workers import WorkerManager, EffortProfile

_LOGGER = logging.getLogger(__name__)

# Module-level singleton — one per CLI process
_instance: AgentContext | None = None


class AgentContext:
    """Process-scoped singleton that manages cross-turn services.

    Lifecycle:
    - Create via ``AgentContext.create(db_path)`` (sets the singleton).
    - Access via ``AgentContext.get()``.
    - Tear down via ``AgentContext.shutdown()`` on process exit.

    Long-lived services managed by AgentContext:
    ``InstructionService``, ``CheckpointManager``, ``PtyManager``,
    ``WorkerManager``, ``SkillLoader``, ``MemoryObserver``.
    """

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self.db = SessionDB(db_path)
        self.session_id: str | None = None
        self.observer_in_flight: bool = False
        self._background_tasks: set[asyncio.Task] = set()
        self._shutdown_hooks: list[Callable[[], None]] = []
        self._closed = False
        self._boot_uuid = self._generate_boot_uuid()
        self._skill_loader: SkillLoader | None = None
        self._pty_manager: PtyManager | None = None
        self._worker_manager: WorkerManager | None = None

    def _assert_open(self) -> None:
        """Raise if the context has been shut down."""
        if self._closed:
            raise RuntimeError("AgentContext is shut down")

    # -- singleton factory ----------------------------------------------------

    @classmethod
    def create(cls, db_path: Path | None = None) -> "AgentContext":
        """Create the singleton AgentContext. Raises if already created."""
        global _instance
        if _instance is not None:
            raise RuntimeError("AgentContext already created in this process")
        if db_path is None:
            db_path = Path.cwd() / ".kiss" / "session.db"
        _instance = cls(db_path)
        os.register_at_fork(after_in_child=cls._reset_boot_uuid_after_fork)
        return _instance

    @classmethod
    def get(cls) -> "AgentContext":
        """Return the running singleton. Raises if not yet created."""
        if _instance is None:
            raise RuntimeError("AgentContext not yet created — call create() first")
        return _instance

    @classmethod
    def shutdown(cls) -> None:
        """Run shutdown hooks and close the database."""
        global _instance
        if _instance is None:
            return
        inst = _instance
        inst._closed = True
        for hook in inst._shutdown_hooks:
            try:
                hook()
            except Exception:
                _LOGGER.exception("Shutdown hook failed: %s", hook)
        # Close all PTY sessions
        if inst._pty_manager is not None:
            for session in inst._pty_manager.list_sessions():
                try:
                    inst._pty_manager.close_session(session.session_id)
                except Exception:
                    _LOGGER.exception(
                        "Failed to close PTY session: %s", session.session_id
                    )
        inst.db.close()
        _instance = None
        _LOGGER.info("AgentContext shut down")

    # -- boot identity ---------

    @property
    def boot_uuid(self) -> str:
        """Process-scoped uuid4, stable for the lifetime of this process."""
        return self._boot_uuid

    @staticmethod
    def _generate_boot_uuid() -> str:
        return str(uuid.uuid4())

    @classmethod
    def _reset_boot_uuid_after_fork(cls) -> None:
        if _instance is not None:
            _instance._boot_uuid = cls._generate_boot_uuid()

    # -- session lifecycle ----------------------------------------------------

    def init_session(self, session_id: str, workspace_root: str) -> None:
        """Register or restore a session. Must be called before turn execution."""
        self._assert_open()
        self.session_id = session_id
        self.db.upsert_session(session_id, workspace_root)
        self._reap_orphans(session_id)
        _LOGGER.info("Session %s initialised", session_id)

    def _reap_orphans(self, session_id: str) -> None:
        """Run startup orphan reapers in fixed order.

        1. Turn orphan reaper  — sets lingering STARTED turns to FAILED
        2. WorkerManager.reap_orphans()  — TODO: when WorkerManager exists
        3. PtyManager.reap_orphans()  — detects stale PTY sessions, kills them
        4. CheckpointManager.cleanup_orphans()  — removes orphaned backup files
        """
        # 1. Turn orphan reaper (first — DB only, no filesystem side effects)
        reaped = self.db.orphan_reap_turns()
        if reaped:
            _LOGGER.info(
                "Orphan reaper set %d turns to FAILED: %s", len(reaped), reaped
            )
            for turn_id in reaped:
                self.audit_log(session_id, "orphan_reap", {"turn_id": turn_id})

        # 2. WorkerManager.reap_orphans() (second — detaches PTYs before PtyManager)
        try:
            worker_reaped = self.worker_manager.reap_orphans()
            if worker_reaped:
                _LOGGER.info(
                    "Worker orphan reaper crashed %d workers: %s",
                    len(worker_reaped),
                    worker_reaped,
                )
                for wid in worker_reaped:
                    self.audit_log(session_id, "worker_orphan_reap", {"worker_id": wid})
        except Exception:
            _LOGGER.debug("WorkerManager reap_orphans skipped (not yet initialised)")

        # 3. PtyManager.reap_orphans() (third — after WorkerManager detached)
        if self._pty_manager is not None:
            pty_reaped = self._pty_manager.reap_orphans(session_id)
            if pty_reaped:
                _LOGGER.info(
                    "PTY orphan reaper killed %d stale sessions: %s",
                    len(pty_reaped),
                    pty_reaped,
                )

        # 4. CheckpointManager.cleanup_orphans() — TODO: when CheckpointManager exists
        # self.checkpoint_manager.cleanup_orphans()

    # -- session leases ---------

    def acquire_lease(
        self,
        session_id: str,
        ttl_seconds: int = 300,
    ) -> str:
        """Acquire a write lease for the given session.

        Uses an atomic UPDATE with a WHERE clause to avoid the
        SELECT-then-UPDATE TOCTOU race: two processes reading
        ``lease_owner IS NULL`` concurrently would both pass.  The WHERE
        clause guarantees only one process can set the lease at a time.

        Returns the lease token. Raises ``LeaseConflict`` if another process
        currently holds the lease.
        """
        self._assert_open()
        token = (
            f"{socket.gethostname()}:{os.getpid()}:"
            f"{self._boot_uuid}:{uuid.uuid4().hex[:8]}"
        )
        expires = (datetime.now(UTC) + timedelta(seconds=ttl_seconds)).isoformat()
        now = datetime.now(UTC).isoformat()

        with self.db.transaction() as conn:
            cur = conn.execute(
                """\
UPDATE sessions
SET lease_owner = ?, lease_expires_at = ?
WHERE id = ?
  AND (lease_owner IS NULL OR lease_expires_at < ?)""",
                (token, expires, session_id, now),
            )
            if cur.rowcount == 0:
                row = conn.execute(
                    "SELECT lease_owner, lease_expires_at FROM sessions WHERE id = ?",
                    (session_id,),
                ).fetchone()
                conflict_info = (
                    f"Lease held by {row['lease_owner']} until {row['lease_expires_at']}"
                    if row and row["lease_owner"]
                    else "Session row missing or lease already taken"
                )
                raise LeaseConflict(conflict_info)

        self.audit_log(session_id, "lease_acquired", {"token": token})
        _LOGGER.info("Lease acquired for session %s: %s", session_id, token)
        return token

    def release_lease(self, session_id: str) -> None:
        """Release the write lease for a session."""
        self._assert_open()
        with self.db.transaction() as conn:
            conn.execute(
                """\
UPDATE sessions SET lease_owner = NULL, lease_expires_at = NULL
WHERE id = ?""",
                (session_id,),
            )
        self.audit_log(session_id, "lease_released")
        _LOGGER.info("Lease released for session %s", session_id)

    def refresh_lease(
        self, session_id: str, token: str, ttl_seconds: int = 300
    ) -> bool:
        """Refresh an existing lease. Returns False if the token doesn't match."""
        self._assert_open()
        expires = (datetime.now(UTC) + timedelta(seconds=ttl_seconds)).isoformat()
        with self.db.transaction() as conn:
            cur = conn.execute(
                """\
UPDATE sessions SET lease_expires_at = ?
WHERE id = ? AND lease_owner = ?""",
                (expires, session_id, token),
            )
        if cur.rowcount == 0:
            return False
        return True

    # -- background task launcher ---------------------------------------------

    def launch_background_task(self, label: str, coro) -> None:
        """Fire-and-forget a background coroutine.

        Only one observer may be in-flight. Uses ``observer_in_flight`` flag
        with try/finally recovery to prevent stuck-bit scenarios.
        """
        if label == "observer" and self.observer_in_flight:
            _LOGGER.debug("Observer already in flight — skipping")
            return

        async def _wrapped():
            if label == "observer":
                self.observer_in_flight = True
            try:
                await coro
            except asyncio.CancelledError:
                _LOGGER.info("Background task '%s' cancelled", label)
            except Exception:
                _LOGGER.exception("Background task '%s' failed", label)
                if self.session_id:
                    self.audit_log(
                        self.session_id,
                        "background_task_failure",
                        {"label": label},
                    )
            finally:
                if label == "observer":
                    self.observer_in_flight = False

        task = asyncio.create_task(_wrapped(), name=f"bg:{label}")
        self._background_tasks.add(task)
        task.add_done_callback(self._background_tasks.discard)
        _LOGGER.debug("Launched background task '%s'", label)

    # -- audit logging ---------

    def audit_log(
        self, session_id: str, action: str, details: dict[str, Any] | None = None
    ) -> None:
        """Append an audit event to the events table.

        Used for critical actions: /rewind, migrations, lease takeovers,
        background task failures.
        """
        payload = json.dumps(
            {
                "action": action,
                "details": details or {},
                "ts": datetime.now(UTC).isoformat(),
                "pid": os.getpid(),
            }
        )
        self.db.append_event(session_id, f"audit:{action}", payload)
        _LOGGER.info("Audit: %s — %s", action, details)

    # -- bounded pruning ---------

    def prune_events(
        self, session_id: str, max_age_days: int = 90, batch_size: int = 500
    ) -> int:
        """Prune events older than ``max_age_days`` in bounded batches.

        Returns the total number of rows deleted.
        """
        self._assert_open()
        cutoff = (datetime.now(UTC) - timedelta(days=max_age_days)).isoformat()
        total = 0
        while True:
            with self.db.transaction() as conn:
                cur = conn.execute(
                    """\
DELETE FROM events
WHERE id IN (
    SELECT id FROM events
    WHERE session_id = ? AND ts < ?
    LIMIT ?
)""",
                    (session_id, cutoff, batch_size),
                )
            deleted = cur.rowcount
            total += deleted
            if deleted < batch_size:
                break
        if total:
            _LOGGER.info("Pruned %d events older than %d days", total, max_age_days)
        return total

    # -- SkillLoader (lazy init) ---------

    @property
    def skill_loader(self) -> SkillLoader:
        """Return the SkillLoader, lazily initialised."""
        if self._skill_loader is None:
            from kiss.core.settings import _settings_load_sync

            settings = _settings_load_sync()
            workspace = Path.cwd()  # fallback
            if self.session_id:
                row = (
                    self.db._connect()
                    .execute(
                        "SELECT workspace_root FROM sessions WHERE id = ?",
                        (self.session_id,),
                    )
                    .fetchone()
                )
                if row:
                    workspace = Path(row["workspace_root"])
            self._skill_loader = SkillLoader(
                db=self.db,
                project_root=workspace,
                max_total_skill_tokens=settings.max_total_skill_tokens,
                skill_priorities=settings.skill_priorities,
            )
        return self._skill_loader

    # -- PtyManager (lazy init) ------------------------------------------------

    @property
    def pty_manager(self) -> PtyManager:
        """Return the PtyManager, lazily initialised."""
        if self._pty_manager is None:
            from kiss.core.settings import _settings_load_sync

            settings = _settings_load_sync()
            self._pty_manager = PtyManager(
                db=self.db,
                heartbeat_ttl_seconds=getattr(
                    settings, "pty_heartbeat_ttl_seconds", 120
                ),
                shell=getattr(settings, "pty_shell", "/bin/bash"),
            )
        return self._pty_manager

    # -- WorkerManager (lazy init) ---------

    @property
    def worker_manager(self) -> WorkerManager:
        """Return the WorkerManager, lazily initialised."""
        if self._worker_manager is None:
            from kiss.core.settings import _settings_load_sync

            settings = _settings_load_sync()
            workspace = Path.cwd()
            if self.session_id:
                row = (
                    self.db._connect()
                    .execute(
                        "SELECT workspace_root FROM sessions WHERE id = ?",
                        (self.session_id,),
                    )
                    .fetchone()
                )
                if row:
                    workspace = Path(row["workspace_root"])

            workers_cfg = settings.workers
            effort_profiles: dict[str, EffortProfile] = {
                name: EffortProfile(
                    model=ep.model,
                    thinking=ep.thinking,
                )
                for name, ep in workers_cfg.effort_profiles.items()
            }
            self._worker_manager = WorkerManager(
                workspace_root=workspace,
                effort_profiles=effort_profiles or None,
                default_effort=workers_cfg.default_effort,
            )
        return self._worker_manager

    # -- shutdown hooks -------------------------------------------------------

    def on_shutdown(self, fn: Callable[[], None]) -> None:
        """Register a callable to run during ``AgentContext.shutdown()``."""
        self._assert_open()
        self._shutdown_hooks.append(fn)


# ---------------------------------------------------------------------------
# Lease exceptions
# ---------------------------------------------------------------------------


class LeaseConflict(Exception):
    """Raised when another process currently holds the write lease."""


# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------

# boot_uuid is generated per-instance (process-scoped via __init__)
