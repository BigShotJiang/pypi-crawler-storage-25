from __future__ import annotations

import contextvars
import json
import threading
from collections.abc import Iterator, Mapping, Sequence
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from opentelemetry import trace as otel_trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import ReadableSpan, SpanProcessor, TracerProvider
from opentelemetry.trace import Span


class LiveSpanProcessor(SpanProcessor):
    """Keep active and finished spans in memory for the current session."""

    def __init__(self) -> None:
        self._active: dict[int, Any] = {}
        self._finished: list[ReadableSpan] = []
        self._lock = threading.Lock()

    def on_start(self, span: Span, parent_context: Any = None) -> None:
        with self._lock:
            self._active[span.get_span_context().span_id] = span

    def on_end(self, span: ReadableSpan) -> None:
        with self._lock:
            self._active.pop(span.context.span_id, None)
            self._finished.append(span)

    def get_snapshot(self) -> tuple[list[Any], list[ReadableSpan]]:
        """Return a thread-safe snapshot of active and finished spans."""
        with self._lock:
            return list(self._active.values()), list(self._finished)

    def shutdown(self) -> None:
        return None

    def force_flush(self, timeout_millis: int = 30_000) -> bool:
        return True


class SessionTracer:
    """Session-scoped OpenTelemetry tracer with in-memory export."""

    def __init__(self, service_name: str = "kiss-agent") -> None:
        self._service_name = service_name
        self._resource = Resource.create({"service.name": service_name})
        self._provider = TracerProvider(resource=self._resource)
        self._live = LiveSpanProcessor()
        self._provider.add_span_processor(self._live)
        self._tracer = self._provider.get_tracer("kiss.core.tracing")

    @property
    def tracer_provider(self) -> TracerProvider:
        return self._provider

    @contextmanager
    def span(self, name: str, **attributes: Any) -> Iterator[Span]:
        """Create a current span that nests under the active OTel context."""
        with self._tracer.start_as_current_span(name, attributes=attributes) as span:
            yield span

    def event(self, kind: str, **data: Any) -> None:
        """Attach an event to the current active span when one exists."""
        span = otel_trace.get_current_span()
        if span.is_recording():
            span.add_event(kind, attributes=data)

    def get_live_snapshot(self) -> tuple[list[ReadableSpan], list[ReadableSpan]]:
        return self._live.get_snapshot()

    def export_jsonl(self, filepath: str | Path) -> None:
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        active, finished = self.get_live_snapshot()
        finished = sorted(
            finished,
            key=lambda span: (
                span.start_time or 0,
                span.end_time or 0,
                span.name,
            ),
        )
        records = [
            {
                "record_type": "session",
                "version": 1,
                "exported_at": datetime.now(UTC).isoformat(),
                "service_name": self._service_name,
                "active_span_count": len(active),
                "finished_span_count": len(finished),
            }
        ]
        records.extend(self._serialize_span(span) for span in finished)
        with path.open("w", encoding="utf-8") as fh:
            for record in records:
                fh.write(json.dumps(record, ensure_ascii=False) + "\n")

    def export_json(self, filepath: str | Path) -> None:
        """Backward-compatible wrapper for the JSONL exporter."""
        self.export_jsonl(filepath)

    def shutdown(self) -> None:
        self._provider.shutdown()

    def _serialize_span(self, span: ReadableSpan) -> dict[str, Any]:
        context = span.get_span_context()
        assert context is not None
        parent = getattr(span, "parent", None)
        return {
            "record_type": "span",
            "name": span.name,
            "trace_id": self._hex_trace_id(context.trace_id),
            "span_id": self._hex_span_id(context.span_id),
            "parent_span_id": self._parent_span_id(parent),
            "kind": getattr(span.kind, "name", str(span.kind)),
            "start_time": self._format_time(span.start_time),
            "end_time": self._format_time(span.end_time),
            "duration_ms": self._duration_ms(span.start_time, span.end_time),
            "attributes": self._to_jsonable(span.attributes),
            "events": [self._serialize_event(event) for event in span.events],
            "status": self._serialize_status(getattr(span, "status", None)),
        }

    def _serialize_event(self, event: Any) -> dict[str, Any]:
        return {
            "name": getattr(event, "name", ""),
            "timestamp": self._format_time(getattr(event, "timestamp", None)),
            "attributes": self._to_jsonable(getattr(event, "attributes", {})),
        }

    def _serialize_status(self, status: Any) -> dict[str, Any] | None:
        if status is None:
            return None
        status_code = getattr(status, "status_code", None)
        return {
            "code": getattr(status_code, "name", str(status_code)),
            "description": getattr(status, "description", None),
        }

    def _parent_span_id(self, parent: Any) -> str | None:
        if parent is None:
            return None
        span_id = getattr(parent, "span_id", 0)
        if not span_id:
            return None
        return self._hex_span_id(span_id)

    def _hex_trace_id(self, trace_id: int) -> str:
        return f"{trace_id:032x}"

    def _hex_span_id(self, span_id: int) -> str:
        return f"{span_id:016x}"

    def _format_time(self, timestamp_ns: int | None) -> str | None:
        if timestamp_ns is None:
            return None
        return datetime.fromtimestamp(timestamp_ns / 1_000_000_000, tz=UTC).isoformat()

    def _duration_ms(
        self, start_time_ns: int | None, end_time_ns: int | None
    ) -> float | None:
        if start_time_ns is None or end_time_ns is None:
            return None
        return (end_time_ns - start_time_ns) / 1_000_000

    def _to_jsonable(self, value: Any) -> Any:
        if isinstance(value, Mapping):
            return {str(key): self._to_jsonable(inner) for key, inner in value.items()}
        if isinstance(value, tuple):
            return [self._to_jsonable(item) for item in value]
        if isinstance(value, Sequence) and not isinstance(
            value, (str, bytes, bytearray)
        ):
            return [self._to_jsonable(item) for item in value]
        if isinstance(value, Path):
            return str(value)
        if isinstance(value, datetime):
            return value.isoformat()
        return value


_current_tracer: contextvars.ContextVar[SessionTracer | None] = contextvars.ContextVar(
    "current_tracer",
    default=None,
)


def set_current_tracer_context(
    tracer: SessionTracer | None,
) -> contextvars.Token[SessionTracer | None]:
    """Set the current session tracer and return a token for reset."""
    return _current_tracer.set(tracer)


def reset_tracer_context(token: contextvars.Token[SessionTracer | None]) -> None:
    """Restore the previous tracer context using the token returned by set()."""
    _current_tracer.reset(token)


def get_current_tracer() -> SessionTracer | None:
    """Return the current session tracer from context, if any."""
    return _current_tracer.get()
