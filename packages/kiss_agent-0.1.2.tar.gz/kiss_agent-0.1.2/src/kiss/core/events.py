"""Agent event types — the message channel from agent core to UI backends."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from enum import Enum, auto
import re
from typing import TYPE_CHECKING, Literal
import uuid

import msgspec

if TYPE_CHECKING:
    from kiss.ui.shared import ToolResultDisplay, TruncationMeta
    from kiss.agent.tools.logic.approval import LogicApprovalRequest

from kiss.core.permissions import PermissionRequest
from kiss.core.usage import TodoItem, TurnUsage


class EventKind(Enum):
    TOKEN = auto()  # streaming text token from the model
    TOOL_CALL = auto()  # model wants to call a tool
    TOOL_RESULT = auto()  # tool finished executing
    STUCK_LOOP = auto()  # loop detector warning or abort notice
    PERMISSION = auto()  # tool needs user approval before running
    ASK_USER = auto()  # agent is asking the user a question
    INFO = auto()  # informational notice (e.g. context compaction status)
    THINKING = auto()  # streaming thought delta from extended reasoning
    TODO_UPDATE = auto()  # agent updated the todo list
    COMPACTING = auto()  # context compaction started
    COMPACTED = auto()  # context compaction finished
    COMPACTION_FALLBACK = auto()  # LLM summarization failed; sliding window applied
    LOGIC_APPROVAL = auto()  # Logic Tool batch manifest needs user approval
    CANCELLED = auto()  # turn was cancelled by the user
    DONE = auto()  # turn complete; turn_usage is always populated
    ERROR = auto()  # unrecoverable error
    DEGRADED = auto()  # all providers unhealthy; info carries the guidance notice


@dataclass
class ToolCallState:
    id: str
    name: str
    args: str  # raw JSON or string representation


@dataclass
class ToolResultState:
    call_id: str
    name: str
    output: str
    is_err: bool = False
    path: str | None = None  # populated for file-mutating tools
    truncation_meta: TruncationMeta | None = None
    display: ToolResultDisplay | None = None


class QuestionOption(msgspec.Struct, omit_defaults=True):
    """A single selectable option in an AskUserRequest."""

    id: str
    label: str
    description: str | None = None


def _default_future() -> asyncio.Future[AskUserReply]:
    return asyncio.get_running_loop().create_future()


@dataclass
class AskUserReply:
    """Tagged outcome of an ASK_USER interaction."""

    outcome: Literal["selected", "free_text", "cancelled"]
    text: str | None = None
    selected_choice_ids: list[str] = field(default_factory=list)

    @staticmethod
    def from_text(text: str) -> "AskUserReply":
        """Transitional adapter: wrap a plain string answer as a free_text reply."""
        return AskUserReply(outcome="free_text", text=text)

    def as_text(self) -> str:
        """Return the answer string for LLM callers that expect plain text."""
        if self.outcome == "selected":
            return ", ".join(self.selected_choice_ids)
        if self.outcome == "free_text":
            return self.text or ""
        return ""


@dataclass(kw_only=True)
class AskUserRequest:
    question: str
    header: str = "Question"
    type: Literal["choice", "text", "yesno", "choice_or_text"] = "text"
    options: list[QuestionOption] = field(default_factory=list)
    multi_select: bool = False
    placeholder: str | None = None
    default_id: str | None = None
    interaction_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    reply_future: asyncio.Future[AskUserReply] = field(default_factory=_default_future)

    def __post_init__(self) -> None:
        # Reject multi-question wizard payloads
        if "\n" in self.question and self.question.count("?") > 1:
            raise ValueError(
                "AskUserRequest.question must be a single question; "
                "multi-question wizard-style payloads are not supported."
            )

        # Header length validation
        if not (3 <= len(self.header) <= 30):
            raise ValueError(
                f"AskUserRequest.header must be 3-30 chars, got {len(self.header)}"
            )

        # yesno sugar: auto-populate Yes/No options
        if self.type == "yesno":
            if self.options:
                raise ValueError("type='yesno' does not accept custom options")
            self.options = [
                QuestionOption(id="yes", label="Yes"),
                QuestionOption(id="no", label="No"),
            ]

        # Validate option ID uniqueness and format
        ids = [opt.id for opt in self.options]
        if len(ids) != len(set(ids)):
            raise ValueError("Option IDs must be unique within the request")
        for opt_id in ids:
            if not re.fullmatch(r"[a-zA-Z0-9_-]+", opt_id):
                raise ValueError(f"Option ID '{opt_id}' contains invalid characters")

        # choice_or_text sugar: append "Other..." option
        if self.type == "choice_or_text":
            if not self.options:
                raise ValueError(
                    "type='choice_or_text' requires at least one user-provided option"
                )
            self.options.append(QuestionOption(id="_kiss_other_", label="Other..."))

        # Validate type coherence
        if self.type == "choice" and not self.options:
            raise ValueError("type='choice' requires non-empty options")
        if self.type == "text" and self.options:
            raise ValueError("type='text' requires empty options")
        if self.multi_select and self.type != "choice":
            raise ValueError("multi_select is only supported for type='choice'")

        # Validate default_id
        if self.default_id is not None:
            if self.default_id not in ids:
                raise ValueError(
                    f"AskUserRequest.default_id='{self.default_id}' not found in options"
                )


@dataclass
class TodoDelta:
    """IDs of todos that changed in a single TODO_UPDATE transition."""

    added: list[str] = field(default_factory=list)
    completed: list[str] = field(default_factory=list)
    reopened: list[str] = field(default_factory=list)
    removed: list[str] = field(default_factory=list)

    def is_empty(self) -> bool:
        return not (self.added or self.completed or self.reopened or self.removed)


@dataclass
class TodoUpdateMeta:
    """Canonical TODO update metadata carried on TODO_UPDATE events.

    snapshot preserves insertion order from the authoritative runtime todo list.
    delta is None on first emission when no prior snapshot baseline exists.
    all_done is True when pending_count just transitioned from > 0 to 0.
    ambiguity_candidates is populated on fuzzy resolution failures.
    """

    snapshot: list[TodoItem]
    pending_count: int
    completed_count: int
    delta: TodoDelta | None = None
    active_todo_id: str | None = None
    all_done: bool = False
    ambiguity_candidates: list[tuple[str, str, float]] = field(default_factory=list)


@dataclass
class Event:
    kind: EventKind
    token: str = ""
    info: str = ""
    severity: Literal["warn", "error"] | None = None
    thought: str = ""
    agent_label: str = ""
    thought_id: str | None = None
    call: ToolCallState | None = None
    result: ToolResultState | None = None
    permission: PermissionRequest | None = None
    ask_user: AskUserRequest | None = None
    turn_usage: TurnUsage | None = None
    todos: list[TodoItem] | None = None
    todo_meta: TodoUpdateMeta | None = None
    error: BaseException | None = None
    compaction_meta: dict[str, str] | None = None
    logic_approval: LogicApprovalRequest | None = None
    phase: str | None = None
