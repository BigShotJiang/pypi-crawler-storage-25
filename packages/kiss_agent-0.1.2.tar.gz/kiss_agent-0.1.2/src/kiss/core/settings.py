from __future__ import annotations

import asyncio
import json
import logging
import re
from difflib import get_close_matches
from pathlib import Path
from typing import Literal

import msgspec

_LOGGER = logging.getLogger(__name__)

_GLOBAL_JSON = Path.home() / ".kiss" / "agent" / "settings.json"
_GLOBAL_JSONC = Path.home() / ".kiss" / "agent" / "settings.jsonc"
_LOCAL_JSON = Path(".kiss") / "settings.json"
_LOCAL_JSONC = Path(".kiss") / "settings.jsonc"

# Keep old names as aliases for any external callers.
_GLOBAL = _GLOBAL_JSON
_LOCAL = _LOCAL_JSON

# Matches strings (group 1), block comments (group 2), line comments (group 3).
# Strings are preserved; comments are stripped.
_JSONC_COMMENT_RE = re.compile(
    r'("(?:[^"\\]|\\.)*")'  # group 1: JSON string — keep verbatim
    r"|(/\*.*?\*/)"  # group 2: /* block comment */ — strip
    r"|(//[^\n]*)",  # group 3: // line comment — strip
    re.DOTALL,
)


def _strip_jsonc_comments(text: str) -> str:
    """Strip // and /* */ comments from JSONC text, preserving strings."""

    def _replace(m: re.Match) -> str:  # type: ignore[type-arg]
        return m.group(1) if m.group(1) else ""

    return _JSONC_COMMENT_RE.sub(_replace, text)


_FALLBACK_WINDOW = 128_000
_DATE_SUFFIX_RE = re.compile(r"(-\d{8})+$")


def discover_workspace_root(start: Path) -> Path:
    """Return the nearest ancestor that looks like a repository root."""
    current = start.resolve()
    for candidate in (current, *current.parents):
        git_marker = candidate / ".git"
        if git_marker.exists():
            return candidate
    return current


def _litellm_info(model_id: str) -> dict | None:
    """Return litellm ModelInfo for model_id, retrying with date suffix stripped."""
    import contextlib
    import io

    try:
        import litellm

        with (
            contextlib.redirect_stdout(io.StringIO()),
            contextlib.redirect_stderr(io.StringIO()),
        ):
            return dict(litellm.get_model_info(model_id))
    except Exception:
        pass
    stripped = _DATE_SUFFIX_RE.sub("", model_id)
    if stripped == model_id:
        return None
    try:
        import litellm

        with (
            contextlib.redirect_stdout(io.StringIO()),
            contextlib.redirect_stderr(io.StringIO()),
        ):
            return dict(litellm.get_model_info(stripped))
    except Exception:
        return None


def _litellm_context_window(model_id: str) -> int | None:
    """Query litellm for max_input_tokens, retrying with date suffix stripped."""
    info = _litellm_info(model_id)
    if info is None:
        return None
    return info.get("max_input_tokens") or info.get("max_tokens") or None


def model_supports_reasoning(model_id: str) -> bool:
    """Return True if litellm reports the model supports extended reasoning/thinking."""
    info = _litellm_info(model_id)
    return bool(info and info.get("supports_reasoning"))


def get_supported_params(model_id: str) -> frozenset[str]:
    """Return the set of OpenAI-compatible params supported by this model."""
    info = _litellm_info(model_id)
    if info is None:
        return frozenset()
    params = info.get("supported_openai_params") or []
    return frozenset(params)


_USABLE_MODES: frozenset[str] = frozenset({"chat", "completion"})


def model_mode(model_id: str) -> str | None:
    """Return litellm mode string for model_id, or None if unknown."""
    info = _litellm_info(model_id)
    return info.get("mode") if info else None


def is_usable_model_mode(model_id: str) -> bool:
    """Return True if model is suitable for a coding agent (chat/completion/unknown).

    Filters out embedding, image_generation, audio_transcription, moderation, etc.
    Unknown models (not in litellm) are kept to avoid hiding custom endpoints.
    """
    mode = model_mode(model_id)
    return mode is None or mode in _USABLE_MODES


def model_supports_prompt_caching(model_id: str) -> bool:
    """Return True if litellm reports the model supports prompt caching."""
    info = _litellm_info(model_id)
    return bool(info and info.get("supports_prompt_caching"))


def _lookup_profile_context_windows(model_id: str) -> int | None:
    """Check all registered provider profiles for a context window entry."""
    try:
        from kiss.providers.registry import list_providers

        best_key = ""
        best_val = 0
        for profile in list_providers():
            for key, val in profile.context_windows:
                if model_id == key or (
                    model_id.startswith(key) and len(key) > len(best_key)
                ):
                    best_key = key
                    best_val = val
        return best_val if best_key else None
    except Exception:
        return None


def get_context_window(model_id: str, override: int | None = None) -> int:
    """Resolve context window for a model.

    Priority: explicit override → litellm → registered ProviderProfile → fallback.
    """
    if override is not None:
        return override
    val = _litellm_context_window(model_id)
    if val:
        return val
    profile_val = _lookup_profile_context_windows(model_id)
    if profile_val is not None:
        return profile_val
    return _FALLBACK_WINDOW


class WebSearchConfig(msgspec.Struct, rename="camel"):
    """Web search configuration."""

    provider: str = "duckduckgo"
    max_results: int = 5
    timeout_s: float = 10.0
    cache_ttl_s: float = 300.0


class EffortProfileConfig(msgspec.Struct, rename="camel"):
    """Model + thinking for one effort level."""

    model: str = ""
    thinking: str = "low"


class WorkersConfig(msgspec.Struct, rename="camel"):
    """Worker dispatch configuration."""

    default_effort: str = "balanced"
    effort_profiles: dict[str, EffortProfileConfig] = {}


class Settings(msgspec.Struct, rename="camel"):
    """Top-level agent configuration"""

    model: str = ""
    system_prompt: str = ""
    thinking_level: str | None = (
        None  # none/minimal/low/medium/high/max; None = disabled
    )
    coder_thinking: bool = False  # whether coder subagent also gets thinking
    web_search: WebSearchConfig = msgspec.field(default_factory=WebSearchConfig)
    compaction_strategy: Literal[
        "summarize", "sliding_window", "summarize_then_slide"
    ] = "summarize_then_slide"
    pinned_prefix_turns: int = 1
    stuck_loop_warn_threshold: int = 3
    stuck_loop_abort_threshold: int = 5
    checkpoint_interval: int = 0  # tool cycles between plan checkpoints; 0 = disabled
    memory_enabled: bool = True
    notify_enabled: bool = True
    show_thinking: bool = True
    max_total_skill_tokens: int = 10_000
    skill_priorities: dict[str, int] = {}
    write_guard_enabled: bool = True
    pty_heartbeat_ttl_seconds: int = 120
    pty_shell: str = "/bin/bash"
    workers: WorkersConfig = msgspec.field(default_factory=WorkersConfig)
    observation_threshold_tokens: int = 1_000
    reflection_threshold_tokens: int = 30_000
    observer_timeout_seconds: int = 30
    reflector_passes: int = 2
    pruner_passes: int = 2
    max_tokens_per_pass: int = 32_000
    retention_max_event_age_days: int = 90
    retention_max_checkpoint_age_days: int = 30
    retention_max_closed_session_age_days: int = 180
    retention_auto_archive: bool = True
    encryption_enabled: bool = False
    encryption_key: str = ""
    free_providers: dict[str, bool] = {}
    context_window: int | None = (
        None  # explicit override; None = auto-detect from model
    )

    @property
    def resolved_system_prompt(self) -> str:
        """Explicit system prompt from settings, if configured."""
        return self.system_prompt

    @property
    def provider_alias(self) -> str:
        """Provider prefix from 'provider:model-id'"""
        if ":" not in self.model:
            raise ValueError(
                f"Invalid model format {self.model!r}, expected 'provider:model-id'"
            )
        return self.model.split(":", 1)[0]

    @property
    def model_id(self) -> str:
        """Model ID suffix from 'provider:model-id'"""
        if ":" not in self.model:
            raise ValueError(
                f"Invalid model format {self.model!r}, expected 'provider:model-id'"
            )
        return self.model.split(":", 1)[1]

    @property
    def effective_provider_type(self) -> str:
        """Resolved provider type — equals the provider alias."""
        return self.provider_alias


class SettingsError(Exception): ...


def _snake_to_camel(name: str) -> str:
    parts = name.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


def _known_camel_keys(struct_type: type[msgspec.Struct]) -> set[str]:
    """Return the set of valid camelCase JSON keys for a msgspec Struct."""
    return {_snake_to_camel(f.name) for f in msgspec.structs.fields(struct_type)}


def _check_unknown_keys(
    raw: dict, struct_type: type[msgspec.Struct], path: Path, section: str = ""
) -> None:
    """Warn about unknown keys; suggest close matches via difflib."""
    known = _known_camel_keys(struct_type)
    prefix = f"{path}" + (f" [{section}]" if section else "")
    for key in raw:
        if key not in known:
            matches = get_close_matches(key, known, n=1, cutoff=0.6)
            suggestion = f" — did you mean '{matches[0]}'?" if matches else ""
            _LOGGER.warning("%s: unknown setting '%s'%s", prefix, key, suggestion)


def _settings_load_sync() -> Settings:
    """Load and validate settings from disk (blocking).

    Search order: local .jsonc > local .json > global .jsonc > global .json
    JSONC files have // and /* */ comments stripped before parsing.
    """
    candidates = [_LOCAL_JSONC, _LOCAL_JSON, _GLOBAL_JSONC, _GLOBAL_JSON]
    path: Path | None = next((p for p in candidates if p.exists()), None)

    if path is None:
        _LOGGER.info(
            "No settings file found; starting with defaults. "
            "Use /connect in the UI to authenticate a provider, then /model to select a model."
        )
        return Settings()

    text = path.read_text(encoding="utf-8")
    if path.suffix == ".jsonc":
        text = _strip_jsonc_comments(text)

    try:
        raw = json.loads(text)
    except json.JSONDecodeError as e:
        raise SettingsError(f"{path} is not valid JSON: {e}") from e

    if isinstance(raw, dict):
        _check_unknown_keys(raw, Settings, path)

    try:
        settings = msgspec.convert(raw, Settings)
    except msgspec.ValidationError as e:
        raise SettingsError(f"{path} has invalid settings: {e}") from e

    if settings.model and ":" not in settings.model:
        raise SettingsError(
            f"{path}: 'model' must be 'provider:model-id', got {settings.model!r}"
        )
    return settings


async def settings_load() -> Settings:
    """Load and validate settings from disk asynchronously."""
    return await asyncio.to_thread(_settings_load_sync)


def _active_settings_path() -> Path:
    """Return the path of the settings file that would be loaded."""
    candidates = [_LOCAL_JSONC, _LOCAL_JSON, _GLOBAL_JSONC, _GLOBAL_JSON]
    found = next((p for p in candidates if p.exists()), None)
    # Default to global JSON if nothing exists (save creates it)
    return found or _GLOBAL_JSON


def settings_save(settings: Settings) -> None:
    """Persist settings to the active settings file.

    If the active file is .jsonc, writes to the corresponding .json path so
    that the JSON remains valid (comments cannot be round-tripped).
    """
    path = _active_settings_path()
    if path.suffix == ".jsonc":
        path = path.with_suffix(".json")
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = msgspec.json.encode(settings)
    parsed = json.loads(encoded)
    path.write_text(
        json.dumps(parsed, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
