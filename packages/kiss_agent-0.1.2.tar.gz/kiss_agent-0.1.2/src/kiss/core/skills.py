"""SkillLoader — markdown-based skill injection with trust/scope policy and token budget."""

from __future__ import annotations

import hashlib
import logging
import re
from pathlib import Path
from typing import NamedTuple

from kiss.core.session_db import SessionDB

_LOGGER = logging.getLogger(__name__)

_USER_SKILLS_DIR = Path.home() / ".kiss" / "skills"


class _SkillRecord(NamedTuple):
    """Parsed skill with metadata."""

    name: str
    source_path: str
    content: str
    priority: int
    scope: str | None
    version: str | None
    fingerprint: str
    trust: bool = False


class SkillLoader:
    """Discovers and loads markdown skills with trust/scope policy and token budget."""

    def __init__(
        self,
        db: SessionDB,
        project_root: Path,
        max_total_skill_tokens: int = 10_000,
        skill_priorities: dict[str, int] | None = None,
    ) -> None:
        self.db = db
        self.project_root = project_root.resolve()
        self.max_total_skill_tokens = max_total_skill_tokens
        self.skill_priorities = skill_priorities or {}
        self._project_skills_dir = project_root / ".kiss" / "skills"

    # -- public API -----------------------------------------------------------

    def load(self, session_id: str, estimate_tokens: str | None = None) -> str:
        """Return merged skill block for the current turn.

        Returns an empty string when no skills are discovered or fit the budget.
        Skills are wrapped as ``<skill name="FILENAME">CONTENT</skill>`` blocks.
        """
        skills = self._discover(session_id)
        if not skills:
            return ""

        parts: list[str] = []
        total_tokens = 0

        for skill in skills:
            token_count = self._estimate_tokens(skill.content, estimate_tokens)
            if total_tokens + token_count > self.max_total_skill_tokens:
                _LOGGER.info(
                    "Skill %s exceeds token budget (%d+%d > %d) — skipped",
                    skill.name,
                    total_tokens,
                    token_count,
                    self.max_total_skill_tokens,
                )
                continue

            total_tokens += token_count
            tag = self._wrap(skill)
            parts.append(tag)

        if not parts:
            return ""

        return "\n\n".join(parts)

    def trust_skill(self, session_id: str, name: str) -> tuple[bool, str]:
        """Mark a skill as trusted. Returns (success, fingerprint).

        Computes the current file content fingerprint per spec.
        """
        import re as _re

        for candidate in [_USER_SKILLS_DIR, self._project_skills_dir]:
            skill_file = candidate / f"{name}.md"
            if skill_file.is_file():
                try:
                    content = skill_file.read_text(encoding="utf-8")
                    m = _re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)", content, _re.DOTALL)
                    content = (m.group(2) if m else content).strip()
                    fingerprint = self._fingerprint(content)
                except OSError as exc:
                    return False, f"Cannot read {skill_file}: {exc}"
                break
        else:
            return False, f"Skill file '{name}.md' not found"

        with self.db.transaction() as conn:
            conn.execute(
                """\
INSERT OR REPLACE INTO skills (name, session_id, trust, fingerprint)
VALUES (?, ?, 1, ?)""",
                (name, session_id, fingerprint),
            )
        _LOGGER.info(
            "Skill %s trusted (fp=%s) for session %s", name, fingerprint[:8], session_id
        )
        return True, fingerprint

    # -- internals ------------------------------------------------------------

    def _discover(self, session_id: str) -> list[_SkillRecord]:
        """Discover skills from user-global and project dirs, merge by filename."""
        user_skills = self._scan_dir(_USER_SKILLS_DIR)
        project_skills = self._scan_dir(self._project_skills_dir)

        # Project skills override user skills with same filename
        merged: dict[str, _SkillRecord] = {}
        for skill in user_skills:
            merged[skill.name] = skill
        for skill in project_skills:
            merged[skill.name] = skill  # project overrides

        # Resolve trust from DB
        records = self._resolve_trust(session_id, list(merged.values()))

        # Sort by priority (lower = higher priority), ties broken alphabetically
        records.sort(key=lambda s: (s.priority, s.name))
        return records

    def _scan_dir(self, skills_dir: Path) -> list[_SkillRecord]:
        """Non-recursive glob of *.md in ``skills_dir``."""
        if not skills_dir.is_dir():
            return []

        skills: list[_SkillRecord] = []
        for path in sorted(skills_dir.glob("*.md")):
            if not path.is_file():
                continue
            try:
                raw = path.read_text(encoding="utf-8")
            except OSError as exc:
                _LOGGER.warning("Cannot read skill file %s: %s", path, exc)
                continue

            try:
                record = self._parse(path, raw)
                skills.append(record)
            except Exception as exc:
                _LOGGER.warning("Malformed skill file %s: %s", path, exc)

        return skills

    def _parse(self, path: Path, raw: str) -> _SkillRecord:
        """Parse YAML frontmatter and extract content."""
        frontmatter: dict[str, object] = {}
        content = raw

        m = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)", raw, re.DOTALL)
        if m:
            try:
                frontmatter = self._parse_frontmatter(m.group(1))
            except Exception:
                _LOGGER.warning(
                    "Failed to parse frontmatter in %s — using defaults", path
                )
            content = m.group(2).strip()
        else:
            content = raw.strip()

        fingerprint = self._fingerprint(content)
        priority_override = self.skill_priorities.get(path.stem)

        raw_priority: object = frontmatter.get("priority", 100)
        raw_scope: object = frontmatter.get("scope")
        raw_version: object = frontmatter.get("version")

        return _SkillRecord(
            name=path.stem,
            source_path=str(path),
            content=content,
            priority=priority_override
            if priority_override is not None
            else int(raw_priority)
            if isinstance(raw_priority, int)
            else 100,
            scope=raw_scope if isinstance(raw_scope, str) else None,
            version=raw_version if isinstance(raw_version, str) else None,
            fingerprint=fingerprint,
        )

    def _parse_frontmatter(self, text: str) -> dict[str, object]:
        """Minimal YAML-like frontmatter parser (no external deps)."""
        result: dict[str, object] = {}
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" not in line:
                continue
            key, _, value = line.partition(":")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            # Try int conversion
            try:
                result[key] = int(value)
            except ValueError:
                result[key] = value
        return result

    def _resolve_trust(
        self, session_id: str, skills: list[_SkillRecord]
    ) -> list[_SkillRecord]:
        """Look up trust/fingerprint in DB and detect drift."""
        with self.db.transaction() as conn:
            rows = conn.execute(
                """\
SELECT name, trust, fingerprint FROM skills
WHERE session_id = ?""",
                (session_id,),
            ).fetchall()

        db_trust: dict[str, tuple[bool, str | None]] = {
            row["name"]: (bool(row["trust"]), row["fingerprint"] or None)
            for row in rows
        }

        resolved: list[_SkillRecord] = []
        for skill in skills:
            trusted, db_fingerprint = db_trust.get(skill.name, (False, None))
            # Drift detection: fingerprint changed → trust drops to False
            if db_fingerprint is not None and skill.fingerprint != db_fingerprint:
                trusted = False
                _LOGGER.info("Skill %s fingerprint drifted — trust revoked", skill.name)

            resolved.append(
                _SkillRecord(
                    name=skill.name,
                    source_path=skill.source_path,
                    content=skill.content,
                    priority=skill.priority,
                    scope=skill.scope,
                    version=skill.version,
                    fingerprint=skill.fingerprint,
                    trust=trusted,
                )
            )

            # Persist/update skill row in DB
            with self.db.transaction() as conn:
                conn.execute(
                    """\
INSERT OR REPLACE INTO skills (name, session_id, source_path, trust, fingerprint, priority, scope, version)
VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        skill.name,
                        session_id,
                        skill.source_path,
                        trusted,
                        skill.fingerprint,
                        skill.priority,
                        skill.scope,
                        skill.version,
                    ),
                )

        return resolved

    def _wrap(self, skill: _SkillRecord) -> str:
        """Wrap skill content in <skill> tag."""
        header = f'<skill name="{skill.name}"'
        if skill.version:
            header += f' version="{skill.version}"'
        if skill.scope:
            header += f' scope="{skill.scope}"'
        if not skill.trust:
            header += ' trust="untrusted"'
        header += ">"
        return f"{header}\n{skill.content}\n</skill>"

    @staticmethod
    def _estimate_tokens(text: str, estimate_fn: str | None = None) -> int:
        """Rough token count (4 chars ≈ 1 token, conservative estimate)."""
        return max(1, len(text) // 4)

    @staticmethod
    def _fingerprint(content: str) -> str:
        """SHA-256 hex digest of skill content."""
        return hashlib.sha256(content.encode("utf-8")).hexdigest()[:16]
