"""Recursive fallback model resolution for ProviderProfile.fallback_models."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from kiss.providers.types import ProviderProfile

_MAX_DEPTH = 2  # A→B→C is the maximum chain length


def resolve_fallback_models(
    profile: ProviderProfile,
    primary_model: str,
    depth: int = 0,
    _seen: set[str] | None = None,
) -> list[str]:
    """Return an ordered list of (provider/model) strings to try when the primary fails.

    Traverses fallback_models left-to-right up to _MAX_DEPTH levels.
    Models without a provider prefix are assumed to belong to `profile.name`.
    """
    if depth >= _MAX_DEPTH:
        return []

    if _seen is None:
        primary_scoped = (
            primary_model if "/" in primary_model else f"{profile.name}/{primary_model}"
        )
        _seen = {primary_model, primary_scoped}

    result: list[str] = []
    for model in profile.fallback_models:
        scoped = model if "/" in model else f"{profile.name}/{model}"
        if scoped in _seen:
            continue
        _seen.add(scoped)
        result.append(scoped)

        # Recurse into cross-provider fallbacks one level deeper
        if "/" in model and depth + 1 < _MAX_DEPTH:
            from kiss.providers.registry import get_provider_profile

            dep_name = model.split("/")[0]
            dep_profile = get_provider_profile(dep_name)
            if dep_profile is not None:
                nested = resolve_fallback_models(dep_profile, model, depth + 1, _seen)
                result.extend(nested)

    return result
