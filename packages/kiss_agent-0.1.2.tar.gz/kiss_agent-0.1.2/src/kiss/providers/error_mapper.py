"""Technical-to-instructional error mapper for LLM provider errors."""

from __future__ import annotations

import re

_PATTERNS: list[tuple[str, str]] = [
    (
        r"rate.?limit|429|too many requests",
        "Rate limit reached. Wait a moment and try again, or switch to a less busy model.",
    ),
    (
        r"unauthorized|401|invalid.?api.?key|incorrect.?api.?key",
        "Authentication failed. Check your API key in settings.json.",
    ),
    (
        r"403|forbidden|permission denied",
        "Access denied. Your API key may lack permission for this model.",
    ),
    (
        r"context.?length|too.?long|max.?tokens|input is too long",
        "The conversation is too long for this model's context window. "
        "Try /compact to summarize history.",
    ),
    (
        r"model.?not.?found|404|no such model|does not exist",
        "Model not found. Check the model name in your settings.json.",
    ),
    (
        r"timeout|timed out|connection.*timed",
        "Request timed out. The provider may be slow — try again.",
    ),
    (
        r"connection.?error|network|dns|socket|unreachable",
        "Network error. Check your internet connection and provider status.",
    ),
    (
        r"500|502|503|504|internal server error|service unavailable|bad gateway",
        "Provider is experiencing issues (5xx). Try again in a moment.",
    ),
    (
        r"content.?filter|policy|safety|blocked|refused",
        "The request was blocked by the provider's content policy.",
    ),
    (
        r"insufficient.?quota|quota exceeded|billing|payment",
        "Account quota exceeded. Check your billing or upgrade your plan.",
    ),
]


def map_error(exc: BaseException) -> str:
    """Return a user-friendly message for a provider exception.

    Falls back to a shortened version of the raw error if no pattern matches.
    """
    raw = str(exc)
    for pattern, instruction in _PATTERNS:
        if re.search(pattern, raw, re.IGNORECASE):
            return instruction
    # Trim raw message to avoid wall-of-text for unexpected errors.
    short = raw[:200] + ("…" if len(raw) > 200 else "")
    return f"Provider error: {short}"
