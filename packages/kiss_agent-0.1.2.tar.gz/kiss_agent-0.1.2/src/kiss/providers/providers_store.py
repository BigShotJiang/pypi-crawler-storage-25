"""providers.jsonc — per-provider connection metadata store.

Stores connection configuration (baseUrl, type, enabled, etc.) only.
Secrets live exclusively in keyring_store / environment variables.
"""

from __future__ import annotations

import json
import logging
import os
import re
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING

import msgspec

if TYPE_CHECKING:
    from kiss.providers.types import ProviderProfile

_LOGGER = logging.getLogger(__name__)
_PROVIDERS_FILE = Path.home() / ".kiss" / "agent" / "providers.jsonc"

_SECRET_FIELD_RE = re.compile(
    r"(?:api[-_]?key|token|secret|password|credential)", re.IGNORECASE
)

_ALLOWED_OVERRIDE_FIELDS = frozenset(
    {"baseUrl", "type", "models", "autodiscover", "enabled", "signupUrl"}
)


class ProviderRuntimeRecord(msgspec.Struct, rename="camel"):
    """Per-provider connection metadata. No secrets."""

    display_name: str = ""
    base_url: str | None = None
    type: str | None = None
    models: list[str] = []
    autodiscover: bool = False
    env: dict[str, str] | None = None
    signup_url: str | None = None
    enabled: bool | None = None
    context_window: int | None = None


def _strip_jsonc_comments(text: str) -> str:
    """Remove // and /* */ comments from JSONC text."""
    result: list[str] = []
    i = 0
    in_string = False
    while i < len(text):
        ch = text[i]
        if in_string:
            result.append(ch)
            if ch == "\\" and i + 1 < len(text):
                i += 1
                result.append(text[i])
            elif ch == '"':
                in_string = False
        elif ch == '"':
            in_string = True
            result.append(ch)
        elif ch == "/" and i + 1 < len(text):
            nxt = text[i + 1]
            if nxt == "/":
                while i < len(text) and text[i] != "\n":
                    i += 1
                continue
            elif nxt == "*":
                i += 2
                while i < len(text) - 1 and not (text[i] == "*" and text[i + 1] == "/"):
                    i += 1
                if i < len(text) - 1:
                    i += 2  # skip closing */
                else:
                    i = len(text)  # unterminated block comment — consume to EOF
                continue
            else:
                result.append(ch)
        else:
            result.append(ch)
        i += 1
    return "".join(result)


def load_provider_records() -> dict[str, ProviderRuntimeRecord]:
    """Load all runtime records from providers.jsonc. Returns {} if absent."""
    if not _PROVIDERS_FILE.exists():
        return {}
    try:
        text = _PROVIDERS_FILE.read_text(encoding="utf-8")
        raw = json.loads(_strip_jsonc_comments(text))
        if not isinstance(raw, dict):
            return {}
        result: dict[str, ProviderRuntimeRecord] = {}
        for name, rec in raw.items():
            if not isinstance(rec, dict):
                continue
            # Strip any secret fields silently
            cleaned = {k: v for k, v in rec.items() if not _SECRET_FIELD_RE.search(k)}
            try:
                result[name] = msgspec.convert(cleaned, ProviderRuntimeRecord)
            except Exception:
                _LOGGER.warning("Skipping invalid record for provider '%s'", name)
        return result
    except Exception:
        _LOGGER.warning("Failed to load providers.jsonc", exc_info=True)
        return {}


def save_provider_record(name: str, record: ProviderRuntimeRecord) -> None:
    """Write or update a single provider's runtime record."""
    records = load_provider_records()
    records[name] = record
    _write_all(records)


def update_provider_enabled(name: str, enabled: bool) -> None:
    """Set the enabled flag for a provider (creates record if absent)."""
    records = load_provider_records()
    existing = records.get(name, ProviderRuntimeRecord())
    records[name] = msgspec.structs.replace(existing, enabled=enabled)
    _write_all(records)


def record_from_profile(profile: ProviderProfile) -> ProviderRuntimeRecord:
    """Build a runtime record from a bundled profile (no secrets)."""
    return ProviderRuntimeRecord(
        display_name=profile.display_name or profile.name,
        base_url=profile.base_url or None,
        type=profile.auth_type or None,
        signup_url=profile.signup_url or None,
        enabled=None,
    )


def _write_all(records: dict[str, ProviderRuntimeRecord]) -> None:
    _PROVIDERS_FILE.parent.mkdir(parents=True, exist_ok=True)
    data = {
        name: msgspec.to_builtins(rec, builtin_types=(type(None),))
        for name, rec in records.items()
    }
    # Drop None values to keep the file clean
    data = {
        name: {k: v for k, v in fields.items() if v is not None}
        for name, fields in data.items()
    }
    payload = json.dumps(data, indent=2, ensure_ascii=False)
    fd, tmp = tempfile.mkstemp(dir=_PROVIDERS_FILE.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(payload)
        os.replace(tmp, _PROVIDERS_FILE)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
