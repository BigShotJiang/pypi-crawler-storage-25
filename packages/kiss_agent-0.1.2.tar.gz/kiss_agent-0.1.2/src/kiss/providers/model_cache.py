"""Disk-backed model list cache with TTL and settings-hash invalidation."""

from __future__ import annotations

import hashlib
import json
import logging
import time
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from kiss.core.settings import Settings

_LOGGER = logging.getLogger(__name__)

_CACHE_DIR = Path.home() / ".kiss" / "agent" / "cache"
_CACHE_FILE = _CACHE_DIR / "models.json"
_TTL_SECONDS = 3600  # 1 hour
_USER_PROFILES_DIR = Path.home() / ".kiss" / "agent" / "profiles"


def _settings_hash(settings: Settings) -> str:
    from kiss.providers.providers_store import load_provider_records

    records = load_provider_records()
    payload = {
        "model": settings.model,
        "free_providers": settings.free_providers,
        "providers": {
            k: {
                "base_url": v.base_url,
                "enabled": v.enabled,
                "autodiscover": v.autodiscover,
            }
            for k, v in records.items()
        },
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()[:16]


def _user_profiles_mtime() -> float:
    """Return latest mtime across user-global profile files (0 if none)."""
    if not _USER_PROFILES_DIR.is_dir():
        return 0.0
    mtimes = [p.stat().st_mtime for p in _USER_PROFILES_DIR.glob("*.py")]
    return max(mtimes, default=0.0)


def load_model_cache(settings: Settings) -> dict[str, list[str]] | None:
    """Load cache if valid. Returns None if missing, expired, corrupt, or invalidated."""
    if not _CACHE_FILE.exists():
        return None
    try:
        data: dict = json.loads(_CACHE_FILE.read_text())
        meta: dict = data.get("_meta", {})
        ts: float = meta.get("ts", 0.0)

        if time.time() - ts > _TTL_SECONDS:
            _LOGGER.debug("Model cache expired")
            return None

        if meta.get("settings_hash") != _settings_hash(settings):
            _LOGGER.debug("Model cache invalidated: settings changed")
            return None

        if _user_profiles_mtime() > ts:
            _LOGGER.debug("Model cache invalidated: user profile mtime newer")
            return None

        return {k: v for k, v in data.items() if k != "_meta"}
    except Exception:
        _LOGGER.debug("Model cache corrupt; discarding", exc_info=True)
        return None


def save_model_cache(models: dict[str, list[str]], settings: Settings) -> None:
    """Persist model lists to disk. Silent on write failure."""
    try:
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
        payload = {
            **models,
            "_meta": {"ts": time.time(), "settings_hash": _settings_hash(settings)},
        }
        _CACHE_FILE.write_text(json.dumps(payload))
    except Exception:
        _LOGGER.debug("Failed to write model cache", exc_info=True)


def clear_model_cache() -> bool:
    """Delete the model cache file. Returns True if the file existed and was removed."""
    if _CACHE_FILE.exists():
        try:
            _CACHE_FILE.unlink()
            return True
        except Exception:
            _LOGGER.warning("Failed to delete model cache", exc_info=True)
    return False
