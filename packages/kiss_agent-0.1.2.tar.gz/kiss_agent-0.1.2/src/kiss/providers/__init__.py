"""Provider registry public API."""

import logging

from kiss.providers.registry import (
    get_provider_profile,
    list_providers,
    register_provider,
)
from kiss.providers.secrets import LogSanitizer
from kiss.providers.types import ProviderProfile

# Attach sanitizer to root logger so ALL loggers (httpx, openai, litellm,
# kiss.*) strip credentials from every propagated log record.
_sanitizer = LogSanitizer()
logging.getLogger().addFilter(_sanitizer)

__all__ = [
    "ProviderProfile",
    "get_provider_profile",
    "list_providers",
    "register_provider",
]
