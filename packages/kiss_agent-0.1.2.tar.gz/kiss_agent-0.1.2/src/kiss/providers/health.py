"""Per-provider health state for circuit-breaker and diagnostic reporting."""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Literal

HealthStatus = Literal["unknown", "healthy", "degraded", "unhealthy"]

_FAILURE_THRESHOLD = 3  # consecutive failures before transitioning to "unhealthy"

_HEALTH: dict[str, ProviderHealth] = {}


@dataclass
class ProviderHealth:
    status: HealthStatus = "unknown"
    failure_count: int = 0
    last_checked: float = 0.0
    last_error: str = ""
    _lock: asyncio.Lock | None = field(default=None, compare=False, repr=False)

    def get_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    def record_success(self) -> None:
        self.status = "healthy"
        self.failure_count = 0
        self.last_error = ""
        self.last_checked = time.time()

    def record_failure(self, error: str) -> None:
        self.failure_count += 1
        self.last_error = error[:200]
        self.last_checked = time.time()
        self.status = (
            "unhealthy" if self.failure_count >= _FAILURE_THRESHOLD else "degraded"
        )


def get_provider_health(name: str) -> ProviderHealth:
    if name not in _HEALTH:
        _HEALTH[name] = ProviderHealth()
    return _HEALTH[name]


def all_providers_unhealthy(provider_names: list[str]) -> bool:
    """True when every provider with known health state is unhealthy.

    Providers with "unknown" status (never probed) are excluded so that
    an unprobed provider does not mask a genuine all-unhealthy condition.
    """
    if not provider_names:
        return False
    known = [_HEALTH[n].status for n in provider_names if n in _HEALTH]
    if not known:
        return False
    return all(s == "unhealthy" for s in known)


def health_snapshot() -> dict[str, dict]:
    """Return a serialisable snapshot of all health states."""
    return {
        name: {
            "status": h.status,
            "failure_count": h.failure_count,
            "last_checked": h.last_checked,
            "last_error": h.last_error,
        }
        for name, h in _HEALTH.items()
    }
