"""Cline browser-redirect OAuth flow.

Flow:
1. Scan ports 48801-48811 for a free local HTTP server
2. Open browser to https://api.cline.bot/api/v1/auth/authorize
3. Cline redirects to http://127.0.0.1:<port>/auth?code=...
4. Exchange code via POST /auth/token (JSON body)
5. Store "workos:<accessToken>" in keyring; refreshToken stored separately
"""

from __future__ import annotations

import json
import logging
import secrets
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from kiss.providers.oauth_utils import (
    OAuthCallbackServer,
    OAuthCredentials,
    OAuthError,
    load_credentials,
    open_browser,
    save_credentials,
)

_LOGGER = logging.getLogger(__name__)

_BASE_URL = "https://api.cline.bot/api/v1"
_AUTH_ENDPOINT = f"{_BASE_URL}/auth/authorize"
_TOKEN_ENDPOINT = f"{_BASE_URL}/auth/token"
_REFRESH_ENDPOINT = f"{_BASE_URL}/auth/refresh"

_CALLBACK_PATH = "/auth"
_CALLBACK_PORTS = range(48801, 48812)
_CALLBACK_WAIT = 300

_CREDS_PATH = Path.home() / ".kiss" / "agent" / "auth" / "cline.json"

_HEADERS = {
    "Accept": "application/json",
    "Content-Type": "application/json",
    "User-Agent": "Cline/3.76.0",
    "X-PLATFORM": "Visual Studio Code",
    "X-PLATFORM-VERSION": "1.109.3",
    "X-CLIENT-TYPE": "VSCode Extension",
    "X-CLIENT-VERSION": "3.76.0",
    "X-CORE-VERSION": "3.76.0",
}


def _post_json(url: str, body: dict[str, Any], timeout: float = 20.0) -> dict[str, Any]:
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST", headers=_HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8", errors="replace"))
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = exc.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        raise OAuthError(
            f"Cline token endpoint HTTP {exc.code}: {detail or exc.reason}"
        ) from exc
    except urllib.error.URLError as exc:
        raise OAuthError(f"Cline token request failed: {exc}") from exc


def _parse_token_response(resp: dict[str, Any], redirect_uri: str) -> OAuthCredentials:
    if not resp.get("success"):
        raise OAuthError(f"Cline token exchange failed: {resp}")
    data = resp.get("data", {})
    access = data.get("accessToken", "")
    if not access:
        raise OAuthError("Cline token response missing accessToken.")
    return OAuthCredentials(
        access_token=access,
        refresh_token=data.get("refreshToken", ""),
        expires_at=data.get("expiresAt", ""),
    )


def start_oauth_flow(*, force_relogin: bool = False) -> OAuthCredentials:
    """Run browser-redirect OAuth and persist credentials."""
    if not force_relogin:
        existing = load_credentials(_CREDS_PATH)
        if existing and existing.access_token:
            return existing

    state = secrets.token_urlsafe(16)

    with OAuthCallbackServer(_CALLBACK_PORTS, _CALLBACK_PATH) as srv:
        import urllib.parse

        params = {
            "client_type": "extension",
            "callback_url": srv.redirect_uri,
            "redirect_uri": srv.redirect_uri,
            "state": state,
        }
        auth_url = _AUTH_ENDPOINT + "?" + urllib.parse.urlencode(params)

        print("Opening your browser to sign in to Cline…")
        open_browser(auth_url)

        code = srv.wait(state=state, timeout=_CALLBACK_WAIT)
        redirect_uri = srv.redirect_uri

    resp = _post_json(
        _TOKEN_ENDPOINT,
        {
            "grant_type": "authorization_code",
            "code": code,
            "client_type": "extension",
            "redirect_uri": redirect_uri,
        },
    )
    creds = _parse_token_response(resp, redirect_uri)
    save_credentials(_CREDS_PATH, creds)
    _LOGGER.info("Cline credentials saved.")
    return creds


def get_access_token() -> str | None:
    """Return bearer token for API calls, refreshing if near expiry."""
    creds = load_credentials(_CREDS_PATH)
    if creds is None or not creds.access_token:
        return None
    if creds.is_expired() and creds.refresh_token:
        try:
            creds = _refresh(creds.refresh_token)
        except Exception as exc:
            _LOGGER.warning("Cline token refresh failed: %s", exc)
    return f"workos:{creds.access_token}" if creds.access_token else None


def _refresh(refresh_token: str) -> OAuthCredentials:
    resp = _post_json(
        _REFRESH_ENDPOINT,
        {"refreshToken": refresh_token, "grantType": "refresh_token"},
    )
    if not resp.get("success"):
        raise OAuthError(f"Cline refresh failed: {resp}")
    data = resp.get("data", {})
    creds = OAuthCredentials(
        access_token=data.get("accessToken", ""),
        refresh_token=data.get("refreshToken", refresh_token),
        expires_at=data.get("expiresAt", ""),
    )
    save_credentials(_CREDS_PATH, creds)
    return creds
