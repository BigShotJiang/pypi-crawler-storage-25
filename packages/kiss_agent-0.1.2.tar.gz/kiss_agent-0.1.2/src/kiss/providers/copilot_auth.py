from __future__ import annotations

import asyncio
from collections.abc import Callable
from pathlib import Path

import httpx

from kiss.providers.oauth_utils import (
    OAuthCredentials,
    clear_credentials,
    load_credentials,
    open_browser,
    save_credentials,
)

_CREDS_PATH = Path.home() / ".kiss" / "agent" / "auth" / "copilot.json"

_CLIENT_ID = "Iv1.b507a08c87ecfe98"
_DEVICE_CODE_URL = "https://github.com/login/device/code"
_ACCESS_TOKEN_URL = "https://github.com/login/oauth/access_token"  # nosec B105


def load_github_token() -> str:
    creds = load_credentials(_CREDS_PATH)
    return creds.access_token if creds else ""


def save_github_token(token: str) -> None:
    save_credentials(_CREDS_PATH, OAuthCredentials(access_token=token.strip()))


def clear_github_token() -> None:
    clear_credentials(_CREDS_PATH)


async def run_copilot_device_auth(
    on_code: Callable[[str, str], None] | None = None,
) -> bool:
    """GitHub device-code flow. Saves token on success. Returns True on success."""
    try:
        async with httpx.AsyncClient(follow_redirects=True, trust_env=True) as client:
            resp = await client.post(
                _DEVICE_CODE_URL,
                headers={"Accept": "application/json"},
                json={"client_id": _CLIENT_ID, "scope": "read:user"},
                timeout=10.0,
            )
        resp.raise_for_status()
        data = resp.json()

        device_code: str = data["device_code"]
        user_code: str = data["user_code"]
        verification_uri: str = data["verification_uri"]
        browser_url: str = data.get("verification_uri_complete", verification_uri)

        loop = asyncio.get_running_loop()
        loop.run_in_executor(None, open_browser, browser_url)

        if on_code:
            on_code(verification_uri, user_code)

        try:
            import pyperclip

            pyperclip.copy(user_code)
        except Exception:  # nosec B110
            pass

        for _ in range(60):
            await asyncio.sleep(5)
            async with httpx.AsyncClient(
                follow_redirects=True, trust_env=True
            ) as client:
                poll = await client.post(
                    _ACCESS_TOKEN_URL,
                    headers={"Accept": "application/json"},
                    json={
                        "client_id": _CLIENT_ID,
                        "device_code": device_code,
                        "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                    },
                    timeout=10.0,
                )
            result = poll.json()
            if "access_token" in result:
                save_github_token(result["access_token"])
                return True

        return False
    except (asyncio.CancelledError, Exception):
        return False
