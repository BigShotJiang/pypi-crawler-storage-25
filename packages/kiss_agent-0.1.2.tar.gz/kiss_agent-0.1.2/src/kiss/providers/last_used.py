"""Persistent last-used model storage for Degraded Recovery Mode."""

from __future__ import annotations

import logging
from pathlib import Path

_LOGGER = logging.getLogger(__name__)
_LAST_USED_FILE = Path.home() / ".kiss" / "agent" / "last_used_model"


def get_last_used_model() -> str | None:
    """Return the last successfully used model string, or None if not recorded."""
    try:
        text = _LAST_USED_FILE.read_text().strip()
        return text or None
    except FileNotFoundError:
        return None
    except Exception:
        _LOGGER.debug("Failed to read last_used_model", exc_info=True)
        return None


def save_last_used_model(model: str) -> None:
    """Persist the model string used in a successful call."""
    try:
        _LAST_USED_FILE.parent.mkdir(parents=True, exist_ok=True)
        _LAST_USED_FILE.write_text(model)
    except Exception:
        _LOGGER.debug("Failed to save last_used_model", exc_info=True)
