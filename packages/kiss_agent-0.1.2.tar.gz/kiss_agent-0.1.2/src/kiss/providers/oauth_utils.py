"""Shared OAuth utilities for browser-redirect and device-code flows.

Provides:
- OAuthCredentials   — generic token dataclass (access, refresh, expires_at)
- OAuthCallbackServer — local HTTP callback server for browser-redirect flows
- open_browser()     — webbrowser.open with print fallback
- atomic_write_json() — 0o600 atomic credential write
- read_json_file()   — safe JSON read
- is_token_expired() — ISO timestamp expiry check
"""

from __future__ import annotations

import http.server
import json
import logging
import os
import secrets
import stat
import threading
import time
import urllib.parse
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

_LOGGER = logging.getLogger(__name__)

_CALLBACK_HOST = "127.0.0.1"


class OAuthError(RuntimeError):
    pass


# ── Credentials ───────────────────────────────────────────────────────────────


@dataclass
class OAuthCredentials:
    """Generic token container — maps to pi-mono's OAuthCredentials type."""

    access_token: str
    refresh_token: str = ""
    expires_at: str = ""  # ISO-8601 timestamp, empty = no expiry tracked
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "access_token": self.access_token,
            "refresh_token": self.refresh_token,
            "expires_at": self.expires_at,
        }
        if self.extra:
            d.update(self.extra)
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "OAuthCredentials":
        return cls(
            access_token=data.get("access_token", ""),
            refresh_token=data.get("refresh_token", ""),
            expires_at=data.get("expires_at", ""),
            extra={
                k: v
                for k, v in data.items()
                if k not in ("access_token", "refresh_token", "expires_at")
            },
        )

    def is_expired(self, skew_seconds: int = 60) -> bool:
        return is_token_expired(self.expires_at, skew_seconds)


# ── File I/O ──────────────────────────────────────────────────────────────────


def atomic_write_json(path: Path, data: dict[str, Any]) -> None:
    """Write JSON to *path* atomically with 0o600 permissions."""
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(path.parent, 0o700)
    except OSError:
        pass
    payload = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
    tmp = path.with_suffix(f".tmp.{os.getpid()}.{secrets.token_hex(4)}")
    fd = os.open(
        str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, stat.S_IRUSR | stat.S_IWUSR
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(payload)
            fh.flush()
            os.fsync(fh.fileno())
        tmp.replace(path)
    finally:
        try:
            if tmp.exists():
                tmp.unlink()
        except OSError:
            pass


def read_json_file(path: Path) -> dict[str, Any] | None:
    """Read and parse a JSON file. Returns None on any error."""
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        _LOGGER.debug("Failed to read %s: %s", path, exc)
        return None


def load_credentials(path: Path) -> OAuthCredentials | None:
    data = read_json_file(path)
    if not data or not data.get("access_token"):
        return None
    return OAuthCredentials.from_dict(data)


def save_credentials(path: Path, creds: OAuthCredentials) -> None:
    atomic_write_json(path, creds.to_dict())


def clear_credentials(path: Path) -> None:
    try:
        path.unlink()
    except FileNotFoundError:
        pass


# ── Timestamp helpers ─────────────────────────────────────────────────────────


def is_token_expired(expires_at: str, skew_seconds: int = 60) -> bool:
    """Return True if the ISO-8601 *expires_at* timestamp is past (or near)."""
    if not expires_at:
        return False
    try:
        import datetime

        dt = datetime.datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
        return time.time() + skew_seconds >= dt.timestamp()
    except Exception:
        return False


def expires_at_from_seconds(expires_in: int) -> str:
    """Build an ISO-8601 expires_at string from a seconds-from-now delta."""
    import datetime

    dt = datetime.datetime.fromtimestamp(
        time.time() + max(60, expires_in), tz=datetime.timezone.utc
    )
    return dt.isoformat()


# ── Browser open ──────────────────────────────────────────────────────────────


def open_browser(url: str) -> None:
    """Open *url* in the default browser; print it as fallback."""
    print(f"\n  {url}\n")
    try:
        import webbrowser

        webbrowser.open(url, new=1, autoraise=True)
    except Exception as exc:
        _LOGGER.debug("webbrowser.open failed: %s", exc)


# ── Callback server ───────────────────────────────────────────────────────────


class OAuthCallbackServer:
    """Local HTTP server for browser-redirect OAuth callback.

    Usage::

        with OAuthCallbackServer(ports=range(8085, 8090), path="/callback") as srv:
            open_browser(build_auth_url(srv.redirect_uri, state))
            code = srv.wait(state=state, timeout=300)
        token = exchange_code(code, srv.redirect_uri)
    """

    def __init__(
        self,
        ports: range,
        path: str,
        host: str = _CALLBACK_HOST,
    ) -> None:
        self._ports = ports
        self._path = path
        self._host = host
        self._server: http.server.HTTPServer | None = None
        self._thread: threading.Thread | None = None
        self._ready = threading.Event()
        self._code: str | None = None
        self._error: str | None = None
        self._state: str | None = None

    @property
    def port(self) -> int:
        assert self._server is not None
        return self._server.server_address[1]

    @property
    def redirect_uri(self) -> str:
        return f"http://{self._host}:{self.port}{self._path}"

    def __enter__(self) -> "OAuthCallbackServer":
        handler_cls = self._make_handler()
        for port in self._ports:
            try:
                self._server = http.server.HTTPServer((self._host, port), handler_cls)
                break
            except OSError:
                continue
        else:
            raise OAuthError(
                f"No callback port available in {self._ports.start}–{self._ports.stop - 1}."
            )
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *_: object) -> None:
        if self._server:
            try:
                self._server.shutdown()
            except Exception:
                pass
            try:
                self._server.server_close()
            except Exception:
                pass
        if self._thread:
            self._thread.join(timeout=2.0)

    def wait(self, state: str = "", timeout: float = 300) -> str:
        """Block until callback received. Returns auth code or raises OAuthError."""
        self._state = state
        if not self._ready.wait(timeout=timeout):
            raise OAuthError("Timed out waiting for OAuth callback.")
        if self._error:
            raise OAuthError(f"OAuth error: {self._error}")
        if not self._code:
            raise OAuthError("No authorization code received.")
        return self._code

    def _make_handler(self) -> type:
        path = self._path
        srv = self

        class _Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, format: str, *args: object) -> None:  # noqa: A002
                _LOGGER.debug("OAuth callback: " + format, *args)

            def do_GET(self) -> None:  # noqa: N802
                parsed = urllib.parse.urlparse(self.path)
                if parsed.path != path:
                    self.send_response(404)
                    self.end_headers()
                    return

                params = urllib.parse.parse_qs(parsed.query)
                state = (params.get("state") or [""])[0]
                error = (params.get("error") or [""])[0]
                code = (params.get("code") or [""])[0]

                if srv._state and state and state != srv._state:
                    srv._error = "state_mismatch"
                    self._html(400, "State mismatch — aborting for safety.")
                elif error:
                    srv._error = error
                    self._html(400, f"Authorization denied: {error}")
                elif code:
                    srv._code = code
                    self._html(200, "Signed in. You can close this tab.")
                else:
                    srv._error = "no_code"
                    self._html(400, "No authorization code received.")

                srv._ready.set()

            def _html(self, status: int, message: str) -> None:
                body = (
                    f"<html><body style='font:16px system-ui;text-align:center;margin-top:10vh'>"
                    f"<p>{message}</p></body></html>"
                ).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        return _Handler
