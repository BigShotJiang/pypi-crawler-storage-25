"""Global LiteLLM configuration hook.

Sets provider-specific API keys and base URLs on the litellm module so that
any direct litellm.acompletion() calls pick up credentials automatically.
This is a preparation layer for the Phase 3 runner.py LiteLLM migration once
mirascope adds a native litellm backend (mirascope.litellm is not yet available
in mirascope 2.4.0).
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable

from kiss.providers.types import ProviderProfile

_LOGGER = logging.getLogger(__name__)

# Map profile.name → litellm attribute for provider-specific key injection.
_PROVIDER_KEY_ATTRS: dict[str, str] = {
    "anthropic": "anthropic_key",
    "openai": "openai_key",
    "gemini": "gemini_key",
    "google": "gemini_key",
    "openrouter": "openrouter_key",
    "cohere": "cohere_key",
    "huggingface": "huggingface_key",
    "replicate": "replicate_key",
    "togetherai": "togetherai_key",
    "vertex_ai": "vertex_key",
}

# Per-provider base URL overrides (populated by apply_litellm_config).
# Keys are profile.name; values are base_url strings.
_PROVIDER_BASE_URLS: dict[str, str] = {}

# Per-provider API keys (populated by apply_litellm_config).
_PROVIDER_API_KEYS: dict[str, str] = {}

# Per-provider async token refresh functions for OAuth providers.
_OAUTH_TOKEN_FNS: dict[str, Callable[[], Awaitable[str | None]]] = {}


def register_oauth_token_fn(
    provider_name: str, fn: Callable[[], Awaitable[str | None]]
) -> None:
    """Register an async token refresh function for an OAuth provider.

    Called by CopilotStrategy/CodexStrategy during provider registration so that
    get_oauth_token() can supply a fresh bearer token for LiteLLM call kwargs.
    """
    _OAUTH_TOKEN_FNS[provider_name] = fn
    _LOGGER.debug("Registered OAuth token function for provider '%s'", provider_name)


async def get_oauth_token(provider_name: str) -> str | None:
    """Return a fresh OAuth bearer token for provider_name, or None if unavailable."""
    fn = _OAUTH_TOKEN_FNS.get(provider_name)
    if fn is None:
        return None
    try:
        return await fn()
    except Exception:
        _LOGGER.warning(
            "OAuth token refresh failed for provider '%s'", provider_name, exc_info=True
        )
        return None


async def get_litellm_call_kwargs_with_oauth(profile_name: str) -> dict[str, str]:
    """Like get_litellm_call_kwargs but injects a fresh OAuth token when available.

    Use for providers where the bearer token expires (Copilot, Codex).
    """
    kwargs = get_litellm_call_kwargs(profile_name)
    token = await get_oauth_token(profile_name)
    if token:
        kwargs["api_key"] = token
    return kwargs


def apply_litellm_config(profile: ProviderProfile, credentials: str | None) -> None:
    """Wire provider credentials into litellm global config.

    Safe to call even if litellm is not importable — logs a debug warning and
    returns without raising.
    """
    try:
        import litellm
    except ImportError:
        _LOGGER.debug(
            "litellm not available; skipping global config for '%s'", profile.name
        )
        return

    if credentials:
        attr = _PROVIDER_KEY_ATTRS.get(profile.name)
        if attr:
            setattr(litellm, attr, credentials)
            _LOGGER.debug("Set litellm.%s for provider '%s'", attr, profile.name)
        # Always store in per-provider dict for direct litellm calls.
        _PROVIDER_API_KEYS[profile.name] = credentials

    if profile.base_url:
        _PROVIDER_BASE_URLS[profile.name] = profile.base_url


def get_litellm_call_kwargs(profile_name: str) -> dict[str, str]:
    """Return per-call kwargs (api_key, api_base) for a direct litellm call.

    Use as: litellm.acompletion(model=..., messages=..., **get_litellm_call_kwargs(name))
    """
    kwargs: dict[str, str] = {}
    if profile_name in _PROVIDER_API_KEYS:
        kwargs["api_key"] = _PROVIDER_API_KEYS[profile_name]
    if profile_name in _PROVIDER_BASE_URLS:
        kwargs["api_base"] = _PROVIDER_BASE_URLS[profile_name]
    return kwargs
