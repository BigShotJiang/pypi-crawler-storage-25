from __future__ import annotations

import asyncio
import datetime
import time
from collections.abc import AsyncGenerator, Generator
from typing import Any, cast

import httpx
from openai import AsyncOpenAI, OpenAI

from kiss.core.diagnostics import get_logger
from kiss.providers.codex_auth import CodexTokens, load_codex_tokens, save_codex_tokens
from kiss.providers.copilot_auth import load_github_token
from kiss.core.settings import Settings

_LOGGER = get_logger(__name__)

_CODEX_ISSUER = "https://auth.openai.com"
_CODEX_CLIENT_ID = "app_EMoamEEZ73f0CkXaXp7hrann"
_CODEX_TOKEN_URL = f"{_CODEX_ISSUER}/oauth/token"
_CODEX_EXPIRY_SKEW = 60


def _copilot_headers() -> dict[str, str]:
    """Return Copilot editor attribution headers from the registered profile."""
    from kiss.providers.registry import get_provider_profile

    profile = get_provider_profile("copilot")
    if profile:
        return dict(profile.default_headers)
    return {
        "Editor-Version": "vscode/1.99.0",
        "Editor-Plugin-Version": "copilot-chat/0.26.7",
        "User-Agent": "GitHubCopilotChat/0.26.7",
    }


async def _get_copilot_token() -> tuple[str, float]:
    """Exchange stored GitHub OAuth token for a short-lived Copilot session token."""
    github_token = load_github_token()
    if not github_token:
        raise RuntimeError("Copilot GitHub OAuth token not found; run authentication")

    async with httpx.AsyncClient(follow_redirects=True, trust_env=True) as client:
        resp = await client.get(
            "https://api.github.com/copilot_internal/v2/token",
            headers={
                "Authorization": f"token {github_token}",
                "Accept": "application/json",
                **_copilot_headers(),
            },
            timeout=10.0,
        )

    if not resp.is_success:
        raise RuntimeError(f"Copilot token exchange failed ({resp.status_code})")

    data = resp.json()
    token = data.get("token")
    if not isinstance(token, str) or not token:
        raise RuntimeError("Copilot token exchange returned no token")
    return token, _parse_copilot_expires_at(data.get("expires_at"))


def _parse_copilot_expires_at(expires_at: object) -> float:
    """Return monotonic seconds-until-expiry from the API expires_at string.

    Falls back to 1740s (29 min) if absent or unparseable.
    """
    _FALLBACK = 1740.0
    _BUFFER = 30.0
    if not isinstance(expires_at, str):
        return _FALLBACK
    try:
        dt = datetime.datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
        now_utc = datetime.datetime.now(datetime.timezone.utc)
        seconds = (dt - now_utc).total_seconds()
        return max(_BUFFER * 2, seconds - _BUFFER)
    except (ValueError, OverflowError):
        return _FALLBACK


async def probe_copilot_token() -> str:
    """Validate the stored GitHub token by exchanging it for a Copilot session token."""
    token, _ = await _get_copilot_token()
    return token


async def get_copilot_oauth_token() -> str | None:
    """Return a fresh Copilot session token, or None on failure."""
    try:
        token, _ = await _get_copilot_token()
        return token
    except Exception:
        return None


async def get_codex_oauth_token() -> str | None:
    """Return a valid Codex access token, refreshing from disk if expired."""
    tokens = load_codex_tokens()
    if tokens is None:
        return None
    if time.time() >= tokens.expires_at - _CODEX_EXPIRY_SKEW:
        try:
            tokens = await _refresh_codex_tokens(tokens)
        except Exception:
            return None
    return tokens.access_token


class _CopilotAuth(httpx.Auth):
    """Obtain short-lived Copilot session tokens from GitHub Copilot token exchange."""

    def __init__(self) -> None:
        self._token: str = ""
        self._expires_at: float = 0.0
        self._refresh_error: BaseException | None = None
        self._lock: asyncio.Lock | None = None

    def _get_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    async def _refresh(self) -> None:
        async with self._get_lock():
            # Re-check inside the lock — another coroutine may have refreshed already.
            if self._token and time.monotonic() < self._expires_at:
                return
            try:
                self._token, ttl = await _get_copilot_token()
                self._refresh_error = None
                self._expires_at = time.monotonic() + ttl
            except Exception as exc:
                _LOGGER.warning("Failed to refresh Copilot token", exc_info=True)
                self._token = ""  # nosec B105
                self._refresh_error = exc
                self._expires_at = time.monotonic() + 30  # back off

    def auth_flow(
        self, request: httpx.Request
    ) -> Generator[httpx.Request, httpx.Response, None]:
        raise NotImplementedError(
            "CopilotAuth requires async_auth_flow; sync calls not supported."
        )
        yield  # satisfy Generator return type

    async def async_auth_flow(
        self, request: httpx.Request
    ) -> AsyncGenerator[httpx.Request, httpx.Response]:
        if not self._token or time.monotonic() >= self._expires_at:
            await self._refresh()
        if not self._token:
            if self._refresh_error is not None:
                raise RuntimeError("Copilot token unavailable; refresh failed") from (
                    self._refresh_error
                )
            raise RuntimeError("Copilot token unavailable; refresh failed")
        request.headers["Authorization"] = f"Bearer {self._token}"
        response = yield request
        if response.status_code == 401:
            # Token expired mid-turn — force refresh and retry once.
            self._expires_at = 0.0
            await self._refresh()
            if self._token:
                request.headers["Authorization"] = f"Bearer {self._token}"
                yield request


def _make_copilot_provider(base_url: str, headers: dict[str, str]) -> Any:
    """Build a mirascope-compatible Copilot provider at runtime."""
    from mirascope.llm.providers.openai.completions.base_provider import (
        BaseOpenAICompletionsProvider,
    )

    auth = _CopilotAuth()
    _headers = headers

    class _Provider(BaseOpenAICompletionsProvider):
        id = "copilot"
        default_scope = "copilot/"
        api_key_env_var = "COPILOT_TOKEN"
        api_key_required = False

        def __init__(self) -> None:
            self.client = OpenAI(
                base_url=base_url,
                api_key="copilot_placeholder",
                http_client=httpx.Client(
                    auth=auth,
                    headers=_headers,
                    follow_redirects=True,
                    trust_env=True,
                ),
            )
            self.async_client = AsyncOpenAI(
                base_url=base_url,
                api_key="copilot_placeholder",
                http_client=httpx.AsyncClient(
                    auth=auth,
                    headers=_headers,
                    follow_redirects=True,
                    trust_env=True,
                ),
            )

    return _Provider()


async def _refresh_codex_tokens(tokens: CodexTokens) -> CodexTokens:
    """Refresh Codex OAuth tokens using the current refresh token."""
    async with httpx.AsyncClient(timeout=20.0) as client:
        resp = await client.post(
            _CODEX_TOKEN_URL,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={
                "grant_type": "refresh_token",
                "refresh_token": tokens.refresh_token,
                "client_id": _CODEX_CLIENT_ID,
            },
        )

    if not resp.is_success:
        raise RuntimeError(f"Codex token refresh failed ({resp.status_code})")

    data = resp.json()
    refreshed = CodexTokens(
        access_token=data["access_token"],
        refresh_token=data.get("refresh_token", tokens.refresh_token),
        expires_at=time.time() + float(data.get("expires_in", 3600)),
        account_id=tokens.account_id,
    )
    save_codex_tokens(refreshed)
    return refreshed


class _CodexAuth(httpx.Auth):
    """Inject and refresh Codex OAuth bearer tokens for each outgoing request."""

    def __init__(self) -> None:
        self._tokens: CodexTokens | None = None
        self._lock: asyncio.Lock | None = None

    def _get_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    async def _refresh(self) -> None:
        async with self._get_lock():
            now = time.time()
            if self._tokens and now < self._tokens.expires_at - _CODEX_EXPIRY_SKEW:
                return

            tokens = self._tokens or load_codex_tokens()
            if tokens is None:
                raise RuntimeError("Codex OAuth tokens not found; run authentication")

            if now >= tokens.expires_at - _CODEX_EXPIRY_SKEW:
                tokens = await _refresh_codex_tokens(tokens)

            self._tokens = tokens

    def auth_flow(
        self, request: httpx.Request
    ) -> Generator[httpx.Request, httpx.Response, None]:
        raise NotImplementedError(
            "CodexAuth requires async_auth_flow; sync calls not supported."
        )
        yield

    async def async_auth_flow(
        self, request: httpx.Request
    ) -> AsyncGenerator[httpx.Request, httpx.Response]:
        import json as _json

        await self._refresh()
        if self._tokens is None:
            raise RuntimeError("Codex token unavailable; refresh failed")

        request.headers["Authorization"] = f"Bearer {self._tokens.access_token}"
        if self._tokens.account_id:
            request.headers["ChatGPT-Account-Id"] = self._tokens.account_id

        # Rewrite URL to the private Codex responses endpoint.
        request.url = httpx.URL("https://chatgpt.com/backend-api/codex/responses")

        # Mirascope's Responses API encoder puts system messages as {"role": "developer"}
        # items inside the `input` array. The Codex endpoint requires them as a top-level
        # `instructions` string instead — hoist them out.
        try:
            body = _json.loads(request.content)
            body["store"] = False
            items = body.get("input", [])
            dev_texts: list[str] = []
            kept: list[object] = []
            for item in items:
                if isinstance(item, dict) and item.get("role") == "developer":
                    content = item.get("content", "")
                    if isinstance(content, str):
                        dev_texts.append(content)
                    elif isinstance(content, list):
                        dev_texts.extend(
                            p.get("text", "") for p in content if isinstance(p, dict)
                        )
                else:
                    kept.append(item)
            if dev_texts:
                body["instructions"] = "\n\n".join(dev_texts)
                body["input"] = kept
                new_content = _json.dumps(body).encode()
                # Rebuild request with modified body; preserve method/url/headers.
                # Exclude Content-Length — httpx recalculates it from content=.
                headers = [
                    (k, v)
                    for k, v in request.headers.items()
                    if k.lower() != "content-length"
                ]
                request = httpx.Request(
                    method=request.method,
                    url=request.url,
                    headers=headers,
                    content=new_content,
                )
        except Exception:  # nosec B110
            pass

        yield request


def _make_codex_provider(base_url: str, scope: str = "openai-codex/") -> Any:
    """Build a mirascope-compatible Codex provider at runtime."""
    from mirascope.llm.providers.openai.responses.provider import (
        OpenAIResponsesProvider,
    )

    auth = _CodexAuth()
    _scope = scope
    _id = scope.rstrip("/")

    class _Provider(OpenAIResponsesProvider):
        id = _id
        default_scope = _scope

        def __init__(self) -> None:
            self.client = OpenAI(
                base_url=base_url,
                api_key="codex_placeholder",
                http_client=httpx.Client(auth=auth),
            )
            self.async_client = AsyncOpenAI(
                base_url=base_url,
                api_key="codex_placeholder",
                http_client=httpx.AsyncClient(auth=auth),
            )

    return _Provider()


# -- Registration helpers called by strategies --------------------------------


def _register_openai_compatible(profile: Any, api_key: str) -> None:
    """Register a provider as OpenAI-compatible via mirascope."""
    from mirascope import llm as _llm

    scope = f"{profile.name}/"
    _llm.register_provider(
        "openai", scope=scope, api_key=api_key or "none", base_url=profile.base_url
    )


def _register_copilot(profile: Any) -> None:
    """Register the Copilot provider via mirascope."""
    from mirascope import llm as _llm

    provider = _make_copilot_provider(profile.base_url, dict(profile.default_headers))
    _llm.register_provider(cast(Any, provider), scope="copilot/")


def _register_codex(profile: Any, scope: str = "openai-codex/") -> None:
    """Register the Codex provider via mirascope."""
    from mirascope import llm as _llm

    provider = _make_codex_provider(profile.base_url, scope=scope)
    _llm.register_provider(cast(Any, provider), scope=scope)


def _load_strategies() -> None:
    """Import all strategy modules so they self-register."""
    import importlib

    for mod in (
        "kiss.providers.strategies.no_auth",
        "kiss.providers.strategies.api_key",
        "kiss.providers.strategies.copilot",
        "kiss.providers.strategies.codex",
        "kiss.providers.strategies.device_code",
        "kiss.providers.strategies.cline_oauth",
    ):
        try:
            importlib.import_module(mod)
        except Exception:
            _LOGGER.warning("Failed to load strategy module '%s'", mod, exc_info=True)


_load_strategies()


def configure_provider(settings: Settings) -> tuple[str, dict[str, Any]]:
    """Resolve Mirascope model string via AuthStrategy registry dispatch."""
    from kiss.providers.registry import get_provider_profile
    from kiss.providers.strategies import get_strategy

    provider_type = settings.effective_provider_type
    raw_model_id = settings.model_id

    profile = get_provider_profile(provider_type)
    if profile is None:
        raise ValueError(
            f"Unknown provider: '{provider_type}'. "
            "Register a ProviderProfile in providers/profiles/ or use a known provider name."
        )

    strategy = get_strategy(profile.auth_type)
    if strategy is None:
        raise ValueError(
            f"No AuthStrategy registered for auth_type='{profile.auth_type}'"
        )

    credentials = strategy.resolve(profile, settings)
    strategy.register(profile, credentials)

    # Determine mirascope scope prefix from profile
    scope = f"{profile.name}/"
    return f"{scope}{raw_model_id}", {}


_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}
_FETCH_TIMEOUT = 10.0
_FETCH_MAX_RETRIES = 3


async def _fetch_models_raw(settings: Settings, provider_name: str) -> list[str]:
    """Fetch live model IDs — dispatches on profile. Raises on error."""
    from kiss.providers.registry import get_provider_profile

    from kiss.providers.keyring_store import get_credential
    import os

    profile = get_provider_profile(provider_name)
    api_key = ""
    if profile:
        for env_var in profile.env_vars:
            val = os.environ.get(env_var, "")
            if val:
                api_key = val
                break
        if not api_key:
            api_key = get_credential(f"provider:{provider_name}") or ""

    # Custom fetch_models_fn on profile (e.g. anthropic, ollama-cloud)
    if profile and profile.fetch_models_fn is not None:
        return sorted(
            await asyncio.wait_for(
                profile.fetch_models_fn(profile, api_key), timeout=_FETCH_TIMEOUT
            )
        )

    # Copilot: session token + /models endpoint (chat-type filter)
    if profile and profile.auth_type == "copilot":
        session_token, _ = await _get_copilot_token()
        async with httpx.AsyncClient(follow_redirects=True, trust_env=True) as client:
            resp = await client.get(
                f"{profile.base_url}/models",
                headers={
                    "Authorization": f"Bearer {session_token}",
                    **_copilot_headers(),
                },
                timeout=_FETCH_TIMEOUT,
            )
        if not resp.is_success:
            raise RuntimeError(f"Copilot /models returned {resp.status_code}")
        data = resp.json()
        return sorted(
            m["id"]
            for m in data.get("data", [])
            if m.get("capabilities", {}).get("type") == "chat"
        )

    # Codex: no live model listing
    if profile and profile.api_mode == "codex_responses":
        return []

    if not api_key:
        return []

    base_url = profile.base_url if profile else None
    async with AsyncOpenAI(api_key=api_key, base_url=base_url or None) as client:
        models_page = await client.models.list(timeout=_FETCH_TIMEOUT)
    return sorted(m.id for m in models_page.data)


def _patch_openai_completions_decoder() -> None:
    """Monkey-patch Mirascope's OpenAI completions decoder to support reasoning_content.

    OpenAI reasoning models (o1, o3-mini, etc.) emit ``delta.reasoning_content``
    during streaming, but Mirascope 2.4.0's ``_OpenAIChunkProcessor`` only
    checks ``delta.content`` and ``delta.refusal``. This patch injects
    ``ThoughtStartChunk``, ``ThoughtChunk``, and ``ThoughtEndChunk`` yields
    when ``reasoning_content`` is present so that downstream consumers
    (including our Copilot wrapper) receive thought streams correctly.
    """
    try:
        from mirascope.llm.providers.openai.completions._utils.decode import (
            _OpenAIChunkProcessor,
        )
        from mirascope.llm.content import (
            ThoughtChunk,
            ThoughtEndChunk,
            ThoughtStartChunk,
        )
    except ImportError:
        _LOGGER.debug(
            "Mirascope internal decoder not importable; reasoning_content patch skipped"
        )
        return

    if not callable(getattr(_OpenAIChunkProcessor, "process_chunk", None)):
        _LOGGER.warning(
            "_OpenAIChunkProcessor.process_chunk not found; "
            "reasoning_content patch skipped (Mirascope API may have changed)"
        )
        return

    _original_process_chunk = _OpenAIChunkProcessor.process_chunk

    def _patched_process_chunk(self, chunk):
        choice = chunk.choices[0] if chunk.choices else None
        if choice:
            delta = choice.delta
            reasoning = getattr(delta, "reasoning_content", None)
            if reasoning:
                if not getattr(self, "_in_thought", False):
                    yield ThoughtStartChunk()
                    self._in_thought = True
                yield ThoughtChunk(delta=reasoning)
            elif getattr(self, "_in_thought", False):
                yield ThoughtEndChunk()
                self._in_thought = False

        yield from _original_process_chunk(self, chunk)

        if getattr(self, "_in_thought", False):
            choice = chunk.choices[0] if chunk.choices else None
            if choice and choice.finish_reason:
                yield ThoughtEndChunk()
                self._in_thought = False

    # reason: runtime monkey-patch for reasoning_content support
    setattr(_OpenAIChunkProcessor, "process_chunk", _patched_process_chunk)


_patch_openai_completions_decoder()


async def _fetch_models_with_backoff(
    settings: Settings, provider_name: str
) -> list[str]:
    """Fetch models with exponential backoff on 429/5xx. Raises on all other errors."""
    last_exc: Exception | None = None
    for attempt in range(_FETCH_MAX_RETRIES):
        try:
            return await _fetch_models_raw(settings, provider_name)
        except Exception as exc:
            status = getattr(getattr(exc, "response", None), "status_code", None)
            if status in _RETRYABLE_STATUS_CODES and attempt < _FETCH_MAX_RETRIES - 1:
                delay = 1.0 * (2**attempt)
                _LOGGER.debug(
                    "fetch_models retry %d/%d for '%s' after %.1fs (status %s)",
                    attempt + 1,
                    _FETCH_MAX_RETRIES,
                    provider_name,
                    delay,
                    status,
                )
                await asyncio.sleep(delay)
                last_exc = exc
                continue
            raise
    assert last_exc is not None
    raise last_exc


async def fetch_provider_models(settings: Settings, provider_name: str) -> list[str]:
    """Fetch live model IDs for a provider, with backoff and disk cache.

    Returns empty list on any error.
    """
    from kiss.providers.model_cache import load_model_cache, save_model_cache

    cached = load_model_cache(settings)
    if cached is not None and provider_name in cached:
        return cached[provider_name]

    try:
        models = await _fetch_models_with_backoff(settings, provider_name)
    except Exception:
        _LOGGER.warning(
            "Failed to fetch models for provider '%s'",
            provider_name,
            exc_info=True,
        )
        return []

    # Merge into cache and persist
    existing = load_model_cache(settings) or {}
    existing[provider_name] = models
    save_model_cache(existing, settings)
    return models


async def probe_provider_models(
    settings: Settings, provider_name: str
) -> list[str] | None:
    """Like fetch_provider_models but returns None on failure (auth error, network, etc.)."""
    try:
        return await _fetch_models_raw(settings, provider_name)
    except Exception:
        return None
