"""Provider registry — lazy-discovered ProviderProfile store."""

from __future__ import annotations

import enum
import importlib
import importlib.util
import logging
import pkgutil
import threading
from pathlib import Path

from kiss.providers.types import ProviderProfile

_LOGGER = logging.getLogger(__name__)

_REGISTRY: dict[str, ProviderProfile] = {}
_ALIASES: dict[str, str] = {}


# State machine: UNSEEN → DISCOVERING → DONE.
# _cond.wait_for() blocks callers until discovery completes.
class _DS(enum.Enum):
    UNSEEN = 0
    DISCOVERING = 1
    DONE = 2


_discovery_state = _DS.UNSEEN
_cond = threading.Condition()

# Thread-local: set to True only on the discovery thread during user-global tier.
# Avoids the global-flag race window of two separate lock acquisitions.
_tls = threading.local()


def register_provider(profile: ProviderProfile) -> None:
    """Register a ProviderProfile. Called by each profile module at import.

    During user-global discovery, conflicting canonical names replace the
    bundled entry (user-global > bundled precedence). Within the same tier,
    conflicts log WARNING and are skipped.
    """
    user_global = getattr(_tls, "user_global_tier", False)
    with _cond:
        if profile.name in _REGISTRY:
            if user_global:
                _LOGGER.info(
                    "User-global provider '%s' replacing bundled entry", profile.name
                )
            else:
                _LOGGER.warning(
                    "Provider '%s' already registered; skipping duplicate", profile.name
                )
                return
        _REGISTRY[profile.name] = profile
        for alias in profile.aliases:
            if alias in _ALIASES and not user_global:
                _LOGGER.warning(
                    "Alias '%s' for provider '%s' conflicts with existing registration '%s'; skipping alias",
                    alias,
                    profile.name,
                    _ALIASES[alias],
                )
            else:
                _ALIASES[alias] = profile.name
        _LOGGER.debug("Registered provider '%s'", profile.name)


def _run_discovery() -> None:
    # Tier 1: bundled profiles (kiss/providers/profiles/)
    profiles_path = Path(__file__).parent / "profiles"
    pkg_name = "kiss.providers.profiles"
    for _, module_name, _ in pkgutil.iter_modules([str(profiles_path)]):
        full_name = f"{pkg_name}.{module_name}"
        try:
            importlib.import_module(full_name)
        except Exception:
            _LOGGER.warning(
                "Failed to load bundled provider profile '%s'", full_name, exc_info=True
            )

    # Tier 2: user-global profiles (~/.kiss/agent/profiles/*.py).
    # Thread-local flag: only this thread sees user_global_tier=True,
    # so register_provider() correctly grants override rights with no window.
    _tls.user_global_tier = True
    try:
        _discover_user_global()
    finally:
        _tls.user_global_tier = False


def _discover_user_global() -> None:
    user_dir = Path.home() / ".kiss" / "agent" / "profiles"
    if not user_dir.is_dir():
        return
    for py_file in sorted(user_dir.glob("*.py")):
        mod_name = f"kiss_user_profile_{py_file.stem}"
        try:
            spec = importlib.util.spec_from_file_location(mod_name, py_file)
            if spec is None or spec.loader is None:
                continue
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)  # type: ignore[union-attr]
        except Exception:
            _LOGGER.warning(
                "Failed to load user-global profile '%s'", py_file, exc_info=True
            )


def _detect_fallback_cycles() -> list[str]:
    """Return provider names involved in fallback_models cross-provider cycles."""
    # Build edges: A → B when A has "B/model" in fallback_models
    graph: dict[str, set[str]] = {name: set() for name in _REGISTRY}
    for name, profile in _REGISTRY.items():
        for model in profile.fallback_models:
            if "/" in model:
                dep = model.split("/")[0]
                if dep in _REGISTRY and dep != name:
                    graph[name].add(dep)

    visited: set[str] = set()
    path: list[str] = []
    path_set: set[str] = set()
    cycle_members: set[str] = set()

    def dfs(node: str) -> None:
        if node in path_set:
            # Back-edge found — mark only nodes that form the cycle (cycle start → here)
            start = path.index(node)
            cycle_members.update(path[start:])
            return
        if node in visited:
            return
        visited.add(node)
        path.append(node)
        path_set.add(node)
        for neighbor in graph.get(node, set()):
            dfs(neighbor)
        path.pop()
        path_set.discard(node)

    for name in list(_REGISTRY):
        if name not in visited:
            dfs(name)

    return list(cycle_members)


def _finalize_registry() -> None:
    """Post-discovery: DAG cycle detection, auth_type verification, env var audit."""
    import os

    cycle_members = _detect_fallback_cycles()
    for name in cycle_members:
        _LOGGER.error(
            "Provider '%s' involved in fallback_models cycle; removing from registry",
            name,
        )
        _REGISTRY.pop(name, None)

    from kiss.providers.strategies import get_strategy

    for name in list(_REGISTRY):
        profile = _REGISTRY[name]
        schema_errors = profile.validate_schema()
        if schema_errors:
            for err in schema_errors:
                _LOGGER.error(
                    "Provider '%s' schema invalid: %s; removing from registry",
                    name,
                    err,
                )
            _REGISTRY.pop(name, None)
            continue
        if get_strategy(profile.auth_type) is None:
            _LOGGER.error(
                "Provider '%s' has unknown auth_type '%s'; removing from registry",
                name,
                profile.auth_type,
            )
            _REGISTRY.pop(name, None)
            continue

        # Warn if none of the declared env_vars are present (auth may fail at call time).
        if profile.env_vars and profile.auth_type not in (
            "none",
            "copilot",
            "oauth_external",
        ):
            missing = [v for v in profile.env_vars if not os.environ.get(v)]
            if len(missing) == len(profile.env_vars):
                _LOGGER.debug(
                    "Provider '%s': none of the declared env vars are set (%s). "
                    "Authentication will fail unless credentials are supplied via settings.",
                    name,
                    ", ".join(profile.env_vars),
                )


def _ensure_discovered() -> None:
    global _discovery_state
    with _cond:
        if _discovery_state == _DS.DONE:
            return
        if _discovery_state == _DS.DISCOVERING:
            # Another thread is running discovery; wait for it to finish.
            _cond.wait_for(lambda: _discovery_state == _DS.DONE)
            return
        _discovery_state = _DS.DISCOVERING

    # Only one thread reaches here. Discovery runs outside _cond to avoid
    # deadlock when profile imports call back into register_provider().
    try:
        _run_discovery()
        _finalize_registry()
    finally:
        with _cond:
            _discovery_state = _DS.DONE
            _cond.notify_all()


def get_provider_profile(name: str) -> ProviderProfile | None:
    """Lookup by canonical name or alias. Triggers lazy discovery on first call."""
    _ensure_discovered()
    if name in _REGISTRY:
        return _REGISTRY[name]
    canonical = _ALIASES.get(name)
    if canonical:
        return _REGISTRY.get(canonical)
    return None


def list_providers() -> list[ProviderProfile]:
    """Return all registered profiles. Triggers lazy discovery on first call."""
    _ensure_discovered()
    return list(_REGISTRY.values())


def get_status() -> dict:
    """Return a diagnostic snapshot of the registry and provider health states."""
    from kiss.providers.health import health_snapshot

    _ensure_discovered()
    return {
        "provider_count": len(_REGISTRY),
        "providers": list(_REGISTRY.keys()),
        "aliases": dict(_ALIASES),
        "health": health_snapshot(),
    }
