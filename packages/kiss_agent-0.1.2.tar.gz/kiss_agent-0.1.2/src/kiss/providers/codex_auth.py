from __future__ import annotations

import asyncio
import base64
import json
import os
import stat
import time
import webbrowser
from collections.abc import Callable
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlencode, urlparse

_TOKEN_FILE = Path.home() / ".kiss" / "agent" / "codex_tokens.json"
_KEYRING_SERVICE = "kiss-agent"
_KEYRING_KEY = "codex_tokens"

_CODEX_CLIENT_ID = "app_EMoamEEZ73f0CkXaXp7hrann"
_CODEX_ISSUER = "https://auth.openai.com"
_CODEX_AUTHORIZE_URL = f"{_CODEX_ISSUER}/oauth/authorize"
_CODEX_TOKEN_URL = f"{_CODEX_ISSUER}/oauth/token"
_OAUTH_PORT = 1455
_OAUTH_REDIRECT_URI = f"http://localhost:{_OAUTH_PORT}/auth/callback"


@dataclass
class CodexTokens:
    access_token: str
    refresh_token: str
    expires_at: float
    account_id: str | None = None


def _parse_codex_tokens(data: dict[str, Any]) -> CodexTokens | None:
    try:
        return CodexTokens(
            access_token=str(data["access_token"]),
            refresh_token=str(data["refresh_token"]),
            expires_at=float(data["expires_at"]),
            account_id=(
                None if data.get("account_id") is None else str(data["account_id"])
            ),
        )
    except (KeyError, TypeError, ValueError):
        return None


def load_codex_tokens() -> CodexTokens | None:
    """Return persisted Codex OAuth tokens; tries OS keychain first, falls back to file."""
    try:
        import keyring

        raw = keyring.get_password(_KEYRING_SERVICE, _KEYRING_KEY)
        if raw:
            tokens = _parse_codex_tokens(json.loads(raw))
            if tokens:
                return tokens
    except Exception:  # nosec B110
        pass

    try:
        data = json.loads(_TOKEN_FILE.read_text(encoding="utf-8"))
        return _parse_codex_tokens(data)
    except (OSError, json.JSONDecodeError):
        return None


def save_codex_tokens(tokens: CodexTokens) -> None:
    """Persist Codex OAuth tokens; tries OS keychain first, falls back to file."""
    payload = json.dumps(asdict(tokens))
    try:
        import keyring

        keyring.set_password(_KEYRING_SERVICE, _KEYRING_KEY, payload)
        return
    except Exception:  # nosec B110
        pass

    # Keychain unavailable (headless server, CI, etc.) — write to file.
    _TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
    _TOKEN_FILE.write_text(payload, encoding="utf-8")
    try:
        os.chmod(_TOKEN_FILE, stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass


def parse_jwt_claims(jwt_token: str) -> dict[str, Any]:
    """Parse a JWT payload without signature validation for claim extraction."""
    try:
        parts = jwt_token.split(".")
        if len(parts) < 2:
            return {}
        payload = parts[1]
        payload += "=" * (-len(payload) % 4)
        decoded = base64.urlsafe_b64decode(payload.encode("ascii"))
        parsed = json.loads(decoded)
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        return {}


def extract_account_id(claims: dict[str, Any]) -> str | None:
    """Best-effort extraction of ChatGPT account identifier from token claims."""
    direct = claims.get("chatgpt_account_id")
    if isinstance(direct, str) and direct:
        return direct

    auth_claim = claims.get("https://api.openai.com/auth")
    if isinstance(auth_claim, dict):
        nested = auth_claim.get("chatgpt_account_id")
        if isinstance(nested, str) and nested:
            return nested

    orgs = claims.get("organizations")
    if isinstance(orgs, list) and orgs and isinstance(orgs[0], dict):
        org_id = orgs[0].get("id")
        if isinstance(org_id, str) and org_id:
            return org_id

    return None


def _pkce_pair() -> tuple[str, str]:
    """Return (verifier, S256-challenge) as URL-safe base64 strings."""
    import hashlib

    verifier_bytes = os.urandom(32)
    verifier = base64.urlsafe_b64encode(verifier_bytes).rstrip(b"=").decode()
    digest = hashlib.sha256(verifier.encode()).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode()
    return verifier, challenge


def _random_state() -> str:
    return base64.urlsafe_b64encode(os.urandom(32)).rstrip(b"=").decode()


_HTML_OK = b"""<!doctype html><html><body style="font-family:system-ui;text-align:center;padding:3rem">
<h1 style="color:#16a34a">Authorization successful</h1>
<p>You can close this tab and return to kiss.</p>
<script>setTimeout(()=>window.close(),2000)</script></body></html>"""

_HTML_ERR = b"""<!doctype html><html><body style="font-family:system-ui;text-align:center;padding:3rem">
<h1 style="color:#dc2626">Authorization failed</h1>
<p>An error was returned by the authorization server. Please try again.</p>
</body></html>"""


async def run_codex_browser_auth(
    on_url: Callable[[str], None] | None = None,
) -> bool:
    """PKCE authorization-code flow. Saves tokens on success. Returns True on success.

    on_url(auth_url) is called just before the browser opens so the caller can
    display the URL as a manual fallback.
    """
    import httpx

    loop = asyncio.get_running_loop()
    code_future: asyncio.Future[str] = loop.create_future()

    verifier, challenge = _pkce_pair()
    state = _random_state()

    async def _handle(
        reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        try:
            raw = await asyncio.wait_for(reader.read(4096), timeout=5.0)
            line = raw.decode("utf-8", errors="replace").split("\r\n")[0]
            path = line.split(" ")[1] if " " in line else "/"
            params = parse_qs(urlparse(path).query)
            code = (params.get("code") or [None])[0]
            cb_state = (params.get("state") or [None])[0]
            error = (params.get("error") or [None])[0]

            if error and not code_future.done():
                code_future.set_exception(RuntimeError(error))
                writer.write(
                    b"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n" + _HTML_ERR
                )
            elif code and cb_state == state and not code_future.done():
                code_future.set_result(code)
                writer.write(
                    b"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n" + _HTML_OK
                )
            else:
                writer.write(b"HTTP/1.1 400 Bad Request\r\n\r\n")
        except Exception:  # nosec B110
            pass
        finally:
            try:
                await writer.drain()
                writer.close()
            except Exception:  # nosec B110
                pass

    server = await asyncio.start_server(_handle, "127.0.0.1", _OAUTH_PORT)

    auth_url = (
        _CODEX_AUTHORIZE_URL
        + "?"
        + urlencode(
            {
                "response_type": "code",
                "client_id": _CODEX_CLIENT_ID,
                "redirect_uri": _OAUTH_REDIRECT_URI,
                "scope": "openid profile email offline_access",
                "code_challenge": challenge,
                "code_challenge_method": "S256",
                "state": state,
                "id_token_add_organizations": "true",
                "codex_cli_simplified_flow": "true",
                "originator": "kiss-agent",
            }
        )
    )

    if on_url:
        on_url(auth_url)
    loop.run_in_executor(None, webbrowser.open, auth_url)

    token: dict[str, Any] | None = None
    try:
        try:
            async with asyncio.timeout(300):
                code = await code_future
        except (TimeoutError, asyncio.CancelledError, RuntimeError):
            return False

        async with httpx.AsyncClient(timeout=20.0) as client:
            resp = await client.post(
                _CODEX_TOKEN_URL,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                data={
                    "grant_type": "authorization_code",
                    "code": code,
                    "redirect_uri": _OAUTH_REDIRECT_URI,
                    "client_id": _CODEX_CLIENT_ID,
                    "code_verifier": verifier,
                },
            )
        if not resp.is_success:
            return False
        token = resp.json()
    except Exception:
        return False
    finally:
        server.close()
        await server.wait_closed()

    if token is None:
        return False

    claims = parse_jwt_claims(str(token.get("id_token", "")))
    account_id = extract_account_id(claims)
    save_codex_tokens(
        CodexTokens(
            access_token=str(token["access_token"]),
            refresh_token=str(token["refresh_token"]),
            expires_at=time.time() + float(token.get("expires_in", 3600)),
            account_id=account_id,
        )
    )
    return True
