"""ProviderProfile — declarative provider descriptor."""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any

_VALID_API_MODES = frozenset(
    {"chat_completions", "codex_responses", "anthropic_messages"}
)


@dataclass(frozen=True)
class ProviderProfile:
    name: str
    auth_type: str
    base_url: str
    env_vars: tuple[str, ...] = ()
    fallback_models: tuple[str, ...] = ()
    api_mode: str = "chat_completions"
    default_headers_raw: tuple[tuple[str, str], ...] = field(default=())
    display_name: str = ""
    signup_url: str = ""
    models_url: str = ""
    aliases: tuple[str, ...] = ()
    fetch_models_fn: Callable[[ProviderProfile, str], Awaitable[list[str]]] | None = (
        field(default=None, compare=False, hash=False)
    )
    auth_config_raw: tuple[tuple[str, str], ...] = field(default=())
    fallback_auth_type: str = ""
    default_key: str = ""
    context_windows: tuple[tuple[str, int], ...] = field(default=())
    free_models: tuple[str, ...] = ()
    prepare_payload_fn: Callable[[dict[str, Any]], dict[str, Any]] | None = field(
        default=None, compare=False, hash=False
    )
    process_response_fn: Callable[[Any], Any] | None = field(
        default=None, compare=False, hash=False
    )

    @property
    def default_headers(self) -> Mapping[str, str]:
        return MappingProxyType(dict(self.default_headers_raw))

    @property
    def auth_config_map(self) -> Mapping[str, str]:
        return MappingProxyType(dict(self.auth_config_raw))

    @property
    def context_windows_map(self) -> Mapping[str, int]:
        return MappingProxyType(dict(self.context_windows))

    def validate_schema(self) -> list[str]:
        """Return validation errors. Empty list = valid."""
        errors: list[str] = []
        if not self.name:
            errors.append("name: required")
        if not self.auth_type:
            errors.append("auth_type: required")
        if self.api_mode not in _VALID_API_MODES:
            errors.append(
                f"api_mode: '{self.api_mode}' not in {sorted(_VALID_API_MODES)}"
            )
        return errors
