"""Centralized credential storage: system keyring with JSON file fallback.

CopilotStrategy and CodexStrategy delegate raw token I/O here rather than
maintaining ad-hoc per-provider files. The fallback file uses mode 0o600.
"""

from __future__ import annotations

import json
import logging
import os
import stat
from pathlib import Path

_LOGGER = logging.getLogger(__name__)
_SERVICE = "kiss-agent"
_CREDENTIALS_FILE = Path.home() / ".kiss" / "agent" / "credentials.json"


def get_credential(key: str) -> str | None:
    """Return a stored credential by key, or None if not found."""
    try:
        import keyring

        val = keyring.get_password(_SERVICE, key)
        if val:
            return val
    except Exception:
        _LOGGER.debug("Keyring unavailable; falling back to file store", exc_info=True)

    return _file_get(key)


def set_credential(key: str, value: str) -> None:
    """Store a credential. Tries system keyring first, then file fallback."""
    try:
        import keyring

        keyring.set_password(_SERVICE, key, value)
        return
    except Exception:
        _LOGGER.debug("Keyring unavailable; saving to file store", exc_info=True)

    _file_set(key, value)


def delete_credential(key: str) -> None:
    """Remove a stored credential."""
    try:
        import keyring

        keyring.delete_password(_SERVICE, key)
    except Exception:
        pass
    _file_delete(key)


def _load_file() -> dict[str, str]:
    if not _CREDENTIALS_FILE.exists():
        return {}
    try:
        return json.loads(_CREDENTIALS_FILE.read_text())
    except Exception:
        _LOGGER.debug("Corrupt credentials file; starting fresh", exc_info=True)
        return {}


def _save_file(data: dict[str, str]) -> None:
    _CREDENTIALS_FILE.parent.mkdir(parents=True, exist_ok=True)
    _CREDENTIALS_FILE.write_text(json.dumps(data))
    os.chmod(_CREDENTIALS_FILE, stat.S_IRUSR | stat.S_IWUSR)


def _file_get(key: str) -> str | None:
    return _load_file().get(key)


def _file_set(key: str, value: str) -> None:
    data = _load_file()
    data[key] = value
    _save_file(data)


def _file_delete(key: str) -> None:
    data = _load_file()
    data.pop(key, None)
    _save_file(data)
