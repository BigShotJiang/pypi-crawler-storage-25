"""Secret masking and centralized log sanitization."""

from __future__ import annotations

import logging
import re


# Matches common credential key names followed by a value
_SECRET_PATTERN = re.compile(
    r"((?:api[-_]?key|token|secret|password|credential|bearer|authorization)"
    r'["\s:=]+)([A-Za-z0-9\-_.~+/]{8,})',
    re.IGNORECASE,
)


def mask_secret(val: str) -> str:
    """Mask a credential string, preserving only a short prefix and suffix."""
    if len(val) < 12:
        return val[:2] + "..."
    return val[:4] + "..." + val[-4:]


class LogSanitizer(logging.Filter):
    """Logging filter that masks credential values appearing in log records.

    Attach to a logger or handler to prevent credentials from reaching
    disk logs or telemetry sinks.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        # Pre-format the full message so substitutions like "api_key=%s" + "secret"
        # are visible to the pattern before sanitization.
        try:
            full = record.getMessage()
        except Exception:
            full = str(record.msg)
        record.msg = self._sanitize(full)
        record.args = None
        return True

    def _sanitize(self, text: str) -> str:
        return _SECRET_PATTERN.sub(
            lambda m: m.group(1) + mask_secret(m.group(2)),
            text,
        )
