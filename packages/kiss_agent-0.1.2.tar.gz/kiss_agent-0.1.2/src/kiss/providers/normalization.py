"""LLMResponse / LLMResponseChunk normalization layer.

Converts Mirascope response objects into provider-agnostic structs so that
turn_engine and compactor are decoupled from provider-specific response formats.
"""

from __future__ import annotations

import functools
import re as _re
from collections.abc import Callable
from typing import Any

import msgspec

from kiss.core.events import ToolCallState
from kiss.core.usage import TurnUsage
from kiss.providers.secrets import mask_secret


class LLMResponse(msgspec.Struct):
    """Normalized result from a blocking LLM call."""

    content: str | None
    tool_calls: list[ToolCallState]
    usage: TurnUsage
    finish_reason: str
    raw_response: Any
    sanitized_response: Any


class LLMResponseChunk(msgspec.Struct):
    """Normalized delta from a streaming LLM call."""

    content: str | None
    tool_call_delta: ToolCallState | None
    usage_delta: TurnUsage | None
    finish_reason: str | None
    thought_delta: str | None = None


_CRED_KEY_RE = _re.compile(
    r"(?:api[-_]?key|token|secret|password|credential|bearer|authorization)",
    _re.IGNORECASE,
)
_CRED_INLINE_RE = _re.compile(
    r"((?:api[-_]?key|token|secret|bearer)['\"\s:=]+)([A-Za-z0-9\-_.~+/]{8,})",
    _re.IGNORECASE,
)
_WALK_MAX_DEPTH = 10


def _sanitize_walk(obj: Any, depth: int, seen: set[int]) -> Any:
    """Recursively walk obj, masking credential-like strings at every node."""
    if depth > _WALK_MAX_DEPTH:
        return "<depth-limit>"

    if obj is None or isinstance(obj, (bool, int, float)):
        return obj

    if isinstance(obj, str):
        return _CRED_INLINE_RE.sub(lambda m: m.group(1) + mask_secret(m.group(2)), obj)

    obj_id = id(obj)
    if obj_id in seen:
        return "<cycle>"

    if isinstance(obj, dict):
        seen.add(obj_id)
        result: dict[Any, Any] = {}
        for k, v in obj.items():
            if _CRED_KEY_RE.search(str(k)):
                result[k] = mask_secret(str(v)) if isinstance(v, str) else "<masked>"
            else:
                result[k] = _sanitize_walk(v, depth + 1, seen)
        seen.discard(obj_id)
        return result

    if isinstance(obj, (list, tuple)):
        seen.add(obj_id)
        items = [_sanitize_walk(item, depth + 1, seen) for item in obj]
        seen.discard(obj_id)
        return items if isinstance(obj, list) else tuple(items)

    # Arbitrary object — extract attribute dict when available
    try:
        d = vars(obj)
        seen.add(obj_id)
        result = _sanitize_walk(d, depth + 1, seen)
        seen.discard(obj_id)
        return result
    except TypeError:
        pass

    return _CRED_INLINE_RE.sub(lambda m: m.group(1) + mask_secret(m.group(2)), str(obj))


def _sanitize_response(raw: Any) -> Any:
    """Return a structured copy of the response with credential-like values masked.

    Performs a full tree-walk so nested credentials in dicts, lists, and
    arbitrary objects are masked — not just top-level string representations.
    """
    if raw is None:
        return None
    try:
        return _sanitize_walk(raw, depth=0, seen=set())
    except Exception:
        return "<sanitization error>"


def _extract_tool_calls(response: Any) -> list[ToolCallState]:
    """Extract tool calls from a mirascope response into ToolCallState list."""
    raw_calls = getattr(response, "tool_calls", None) or []
    result: list[ToolCallState] = []
    for tc in raw_calls:
        call_id = getattr(tc, "id", "") or ""
        name = getattr(tc, "function", None)
        name = getattr(name, "name", None) or getattr(tc, "name", "") or ""
        args = getattr(tc, "function", None)
        args = getattr(args, "arguments", None) or getattr(tc, "args", "") or ""
        result.append(ToolCallState(id=call_id, name=str(name), args=str(args)))
    return result


def _extract_usage(response: Any) -> TurnUsage:
    """Extract token usage from a mirascope response into TurnUsage."""
    usage = getattr(response, "usage", None)
    if usage is None:
        return TurnUsage()
    return TurnUsage(
        input_tokens=getattr(usage, "prompt_tokens", 0) or 0,
        output_tokens=getattr(usage, "completion_tokens", 0) or 0,
    )


def normalize_response(response: Any) -> LLMResponse:
    """Convert a Mirascope blocking response into a normalized LLMResponse."""
    content: str | None = None
    try:
        content = response.text("") or None
    except Exception:
        pass

    finish_reason = ""
    try:
        fr = response.finish_reason
        finish_reason = fr.value if hasattr(fr, "value") else str(fr or "")
    except Exception:
        pass

    return LLMResponse(
        content=content,
        tool_calls=_extract_tool_calls(response),
        usage=_extract_usage(response),
        finish_reason=finish_reason,
        raw_response=response,
        sanitized_response=_sanitize_response(response),
    )


def mirascope_wrap(
    fn: Callable[..., Any],
) -> Callable[..., Any]:
    """Wrap a @llm.call decorated function to return a normalized LLMResponse.

    Only covers non-streaming (blocking) calls. Streaming callers (turn_engine)
    continue to use mirascope's native stream API until Phase 3 LiteLLM
    migration enables a unified streaming abstraction.
    """

    @functools.wraps(fn)
    async def wrapper(*args: Any, **kwargs: Any) -> LLMResponse:
        response = await fn(*args, **kwargs)
        return normalize_response(response)

    return wrapper
