"""Provider readiness checks — delegates to AuthStrategy registry."""

from __future__ import annotations

import types


def provider_is_ready(alias: str) -> bool:
    """Return True if the provider has credentials available to make API calls.

    Delegates to AuthStrategy.resolve() via the registry instead of hardcoded dispatch.
    Credentials are sourced from environment variables and the system keyring only.
    Returns False if the provider has been explicitly disabled via /logout.
    """
    from kiss.providers.providers_store import load_provider_records
    from kiss.providers.registry import get_provider_profile
    from kiss.providers.strategies import get_strategy

    record = load_provider_records().get(alias)
    if record is not None and record.enabled is False:
        return False

    profile = get_provider_profile(alias)
    if profile is None:
        return False

    strategy = get_strategy(profile.auth_type)
    if strategy is None:
        return False

    settings = types.SimpleNamespace(active_provider_config=None)
    credentials = strategy.resolve(profile, settings)
    return bool(credentials)
