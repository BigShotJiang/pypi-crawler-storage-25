from kiss.providers import ProviderProfile, register_provider

register_provider(
    ProviderProfile(
        name="sambanova",
        auth_type="api_key",
        base_url="https://api.sambanova.ai/v1",
        env_vars=("SAMBANOVA_API_KEY",),
        models_url="https://api.sambanova.ai/v1/models",
        display_name="SambaNova",
        signup_url="https://cloud.sambanova.ai/",
        free_models=(
            "Meta-Llama-3.3-70B-Instruct",
            "Meta-Llama-3.1-405B-Instruct",
            "DeepSeek-R1",
            "DeepSeek-V3-0324",
            "Qwen3-32B",
        ),
        fallback_models=(
            "Meta-Llama-3.3-70B-Instruct",
            "DeepSeek-R1",
        ),
    )
)
