from kiss.providers import ProviderProfile, register_provider

register_provider(
    ProviderProfile(
        name="openrouter",
        aliases=("or",),
        auth_type="api_key",
        base_url="https://openrouter.ai/api/v1",
        env_vars=("OPENROUTER_API_KEY",),
        models_url="https://openrouter.ai/api/v1/models",
        fallback_models=(
            "anthropic/claude-sonnet-4-6",
            "openai/gpt-4o",
            "deepseek/deepseek-chat",
        ),
        display_name="OpenRouter",
        signup_url="https://openrouter.ai/keys",
        free_models=(
            "meta-llama/llama-3.3-70b-instruct:free",
            "deepseek/deepseek-r1:free",
            "deepseek/deepseek-r1-0528:free",
            "google/gemma-3-27b-it:free",
            "mistralai/mistral-7b-instruct:free",
            "qwen/qwen3-235b-a22b:free",
        ),
    )
)
