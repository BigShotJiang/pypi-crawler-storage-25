from kiss.providers import ProviderProfile, register_provider

register_provider(
    ProviderProfile(
        name="copilot",
        auth_type="copilot",
        base_url="https://api.githubcopilot.com",
        env_vars=("GH_TOKEN", "GITHUB_TOKEN"),
        default_headers_raw=(
            ("editor-version", "vscode/1.99.0"),
            ("editor-plugin-version", "copilot-chat/0.26.7"),
            ("user-agent", "GitHubCopilotChat/0.26.7"),
            ("openai-intent", "conversation-panel"),
        ),
        display_name="GitHub Copilot",
    )
)
