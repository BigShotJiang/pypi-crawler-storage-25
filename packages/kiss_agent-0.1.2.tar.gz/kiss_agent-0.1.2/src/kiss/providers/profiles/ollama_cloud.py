from __future__ import annotations

from kiss.providers import ProviderProfile, register_provider


async def _fetch_ollama_models(profile: ProviderProfile, api_key: str) -> list[str]:
    """Fetch models from Ollama Cloud /v1/models endpoint."""
    import httpx

    headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
    async with httpx.AsyncClient() as client:
        resp = await client.get(
            f"{profile.base_url}/models", headers=headers, timeout=10
        )
        resp.raise_for_status()
        data = resp.json()
        return [m["id"] for m in data.get("data", [])]


register_provider(
    ProviderProfile(
        name="ollama-cloud",
        aliases=("ollama_cloud", "ollama"),
        auth_type="api_key",
        base_url="https://ollama.com/v1",
        env_vars=("OLLAMA_API_KEY",),
        display_name="Ollama Cloud",
        signup_url="https://ollama.com",
        fetch_models_fn=_fetch_ollama_models,
        free_models=(
            "glm-5.1",
            "gemma4:31b",
            "deepseek-v4-pro",
            "qwen3.5",
            "kimi-k2.6",
        ),
    )
)
