from kiss.providers import ProviderProfile, register_provider

register_provider(
    ProviderProfile(
        name="openai",
        auth_type="api_key",
        fallback_auth_type="oauth_external",
        base_url="https://api.openai.com/v1",
        env_vars=("OPENAI_API_KEY",),
        fallback_models=("gpt-4o", "gpt-4o-mini"),
        context_windows=(
            ("gpt-4.1", 1_047_576),
            ("gpt-4.1-mini", 1_047_576),
            ("gpt-4.1-nano", 1_047_576),
            ("gpt-4o", 128_000),
            ("gpt-4o-mini", 128_000),
            ("o1", 200_000),
            ("o1-mini", 128_000),
            ("o3", 200_000),
            ("o3-mini", 200_000),
            ("o4-mini", 200_000),
        ),
        free_models=("gpt-4o-mini",),
        display_name="OpenAI",
        signup_url="https://platform.openai.com/api-keys",
    )
)
