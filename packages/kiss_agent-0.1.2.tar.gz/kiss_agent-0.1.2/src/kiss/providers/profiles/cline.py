from kiss.providers import ProviderProfile, register_provider

register_provider(
    ProviderProfile(
        name="cline",
        auth_type="cline_oauth",
        base_url="https://api.cline.bot/api/v1",
        models_url="https://openrouter.ai/api/v1/models",
        display_name="Cline",
        signup_url="https://cline.bot",
        free_models=(
            "meta-llama/llama-3.3-70b-instruct:free",
            "deepseek/deepseek-r1:free",
            "google/gemma-3-27b-it:free",
            "mistralai/mistral-7b-instruct:free",
        ),
        fallback_models=(
            "anthropic/claude-sonnet-4-5",
            "openai/gpt-4o",
        ),
    )
)
