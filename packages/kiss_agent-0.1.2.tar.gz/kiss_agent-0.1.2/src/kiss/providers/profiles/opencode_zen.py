from kiss.providers import ProviderProfile, register_provider

register_provider(
    ProviderProfile(
        name="opencode-zen",
        aliases=("opencode", "opencode_zen", "zen"),
        auth_type="api_key",
        base_url="https://opencode.ai/zen/v1",
        env_vars=("OPENCODE_ZEN_API_KEY",),
        display_name="OpenCode Zen",
        signup_url="https://opencode.ai",
    )
)
