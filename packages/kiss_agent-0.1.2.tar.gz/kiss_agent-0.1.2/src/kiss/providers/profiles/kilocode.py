from kiss.providers import ProviderProfile, register_provider

register_provider(
    ProviderProfile(
        name="kilocode",
        auth_type="api_key",
        base_url="https://api.kilo.ai/api/gateway",
        env_vars=("KILOCODE_API_KEY",),
        models_url="https://api.kilo.ai/api/gateway/models",
        display_name="KiloCode",
        signup_url="https://kilo.ai",
    )
)
