from kiss.providers import ProviderProfile, register_provider

register_provider(
    ProviderProfile(
        name="litellm",
        auth_type="api_key",
        base_url="http://localhost:4000/v1",
        env_vars=("LITELLM_API_KEY",),
        default_key="litellm",
        fallback_models=("gpt-4o", "claude-sonnet-4-6"),
        display_name="LiteLLM Proxy",
    )
)
