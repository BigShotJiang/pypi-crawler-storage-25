from kiss.providers import ProviderProfile, register_provider

register_provider(
    ProviderProfile(
        name="gemini",
        aliases=("google",),
        auth_type="api_key",
        base_url="https://generativelanguage.googleapis.com/v1beta/openai/",
        env_vars=("GOOGLE_API_KEY",),
        api_mode="chat_completions",
        fallback_models=("gemini-2.5-pro", "gemini-2.0-flash"),
        context_windows=(
            ("gemini-2.5-pro", 1_048_576),
            ("gemini-2.5-flash", 1_048_576),
            ("gemini-2.0-flash", 1_048_576),
            ("gemini-2.0-flash-lite", 1_048_576),
            ("gemini-1.5-pro", 2_097_152),
            ("gemini-1.5-flash", 1_048_576),
        ),
        free_models=("gemini-2.0-flash-lite", "gemini-2.0-flash"),
        display_name="Google Gemini",
        signup_url="https://aistudio.google.com/apikey",
    )
)
