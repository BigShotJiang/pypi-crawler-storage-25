from kiss.providers import ProviderProfile, register_provider

register_provider(
    ProviderProfile(
        name="codestral",
        auth_type="api_key",
        base_url="https://codestral.mistral.ai/v1",
        env_vars=("CODESTRAL_API_KEY", "MISTRAL_API_KEY"),
        display_name="Codestral",
        signup_url="https://console.mistral.ai/codestral",
        free_models=("codestral-latest",),
        fallback_models=("codestral-latest",),
    )
)
