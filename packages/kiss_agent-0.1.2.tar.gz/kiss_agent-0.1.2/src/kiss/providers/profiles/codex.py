from kiss.providers import ProviderProfile, register_provider

register_provider(
    ProviderProfile(
        name="openai-codex",
        aliases=("codex",),
        auth_type="oauth_external",
        base_url="https://chatgpt.com/backend-api/codex/responses",
        api_mode="codex_responses",
        display_name="OpenAI Codex",
    )
)
