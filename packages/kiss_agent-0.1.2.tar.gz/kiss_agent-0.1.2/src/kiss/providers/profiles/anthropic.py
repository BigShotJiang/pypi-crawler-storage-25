from __future__ import annotations

from kiss.providers import ProviderProfile, register_provider


async def _fetch_anthropic_models(profile: ProviderProfile, api_key: str) -> list[str]:
    """Fetch models using x-api-key + anthropic-version headers."""
    import httpx

    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
    }
    async with httpx.AsyncClient() as client:
        resp = await client.get(
            "https://api.anthropic.com/v1/models",
            headers=headers,
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json()
        return [m["id"] for m in data.get("data", [])]


register_provider(
    ProviderProfile(
        name="anthropic",
        aliases=("claude",),
        auth_type="api_key",
        base_url="https://api.anthropic.com",
        env_vars=("ANTHROPIC_API_KEY",),
        api_mode="anthropic_messages",
        fallback_models=(
            "claude-opus-4-7",
            "claude-sonnet-4-6",
            "claude-haiku-4-5",
        ),
        context_windows=(
            ("claude-opus-4-7", 200_000),
            ("claude-opus-4-6", 200_000),
            ("claude-sonnet-4-6", 200_000),
            ("claude-haiku-4-5", 200_000),
            ("claude-sonnet-4-5", 200_000),
            ("claude-opus-4-5", 200_000),
            ("claude-3-5-sonnet", 200_000),
            ("claude-3-5-haiku", 200_000),
            ("claude-3-opus", 200_000),
            ("claude-3-haiku", 200_000),
        ),
        display_name="Anthropic",
        signup_url="https://console.anthropic.com",
        fetch_models_fn=_fetch_anthropic_models,
    )
)
