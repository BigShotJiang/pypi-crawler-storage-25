"""CopilotStrategy — auth_type="copilot"."""

from __future__ import annotations

from collections.abc import Callable

from kiss.providers.types import ProviderProfile
from kiss.providers.strategies import register_strategy


class CopilotStrategy:
    auth_type = "copilot"

    def resolve(
        self, profile: ProviderProfile, settings: object, _depth: int = 0
    ) -> str | None:
        try:
            from kiss.providers.copilot_auth import load_github_token

            token = load_github_token()
            return token if token else None
        except Exception:
            return None

    def register(self, profile: ProviderProfile, credentials: str | None) -> None:
        from kiss.providers.litellm_config import register_oauth_token_fn
        from kiss.providers.manager import _register_copilot, get_copilot_oauth_token

        _register_copilot(profile)
        register_oauth_token_fn(profile.name, get_copilot_oauth_token)

    async def run(
        self,
        app: object,
        on_event: Callable[[str, dict], None] | None = None,
    ) -> str | None:
        from kiss.providers.copilot_auth import (
            load_github_token,
            run_copilot_device_auth,
        )

        def _on_code(verification_uri: str, user_code: str) -> None:
            if on_event:
                on_event(
                    "waiting_for_input",
                    {"verification_uri": verification_uri, "user_code": user_code},
                )

        success = await run_copilot_device_auth(on_code=_on_code)
        if not success:
            return None
        return load_github_token()


register_strategy(CopilotStrategy())
