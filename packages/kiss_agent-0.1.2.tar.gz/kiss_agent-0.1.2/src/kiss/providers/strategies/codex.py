"""CodexStrategy — auth_type="oauth_external"."""

from __future__ import annotations

from collections.abc import Callable

from kiss.providers.types import ProviderProfile
from kiss.providers.strategies import register_strategy


class CodexStrategy:
    auth_type = "oauth_external"

    def resolve(
        self, profile: ProviderProfile, settings: object, _depth: int = 0
    ) -> str | None:
        try:
            from kiss.providers.codex_auth import load_codex_tokens

            tokens = load_codex_tokens()
            return tokens.access_token if tokens else None
        except Exception:
            return None

    def register(self, profile: ProviderProfile, credentials: str | None) -> None:
        from kiss.providers.litellm_config import register_oauth_token_fn
        from kiss.providers.manager import _register_codex, get_codex_oauth_token

        _register_codex(profile)
        register_oauth_token_fn(profile.name, get_codex_oauth_token)

    async def run(
        self,
        app: object,
        on_event: Callable[[str, dict], None] | None = None,
    ) -> str | None:
        from kiss.providers.codex_auth import load_codex_tokens, run_codex_browser_auth

        def _on_url(url: str) -> None:
            if on_event:
                on_event("opening_browser", {"url": url})

        success = await run_codex_browser_auth(on_url=_on_url)
        if not success:
            return None
        tokens = load_codex_tokens()
        return tokens.access_token if tokens else None


register_strategy(CodexStrategy())
