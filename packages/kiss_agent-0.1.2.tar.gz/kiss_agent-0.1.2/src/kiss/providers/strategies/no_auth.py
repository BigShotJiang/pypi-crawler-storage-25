"""NoAuthStrategy — auth_type="none"."""

from __future__ import annotations

from collections.abc import Callable

from kiss.providers.types import ProviderProfile
from kiss.providers.strategies import register_strategy


class NoAuthStrategy:
    auth_type = "none"

    def resolve(
        self, profile: ProviderProfile, settings: object, _depth: int = 0
    ) -> str | None:
        return None

    def register(self, profile: ProviderProfile, credentials: str | None) -> None:
        import mirascope.core.base as _mcb

        _mcb.BaseProvider.set_api_key(profile.name, "none")
        from kiss.providers.litellm_config import apply_litellm_config

        apply_litellm_config(profile, None)

    async def run(
        self,
        app: object,
        on_event: Callable[[str, dict], None] | None = None,
    ) -> str | None:
        return None


register_strategy(NoAuthStrategy())
