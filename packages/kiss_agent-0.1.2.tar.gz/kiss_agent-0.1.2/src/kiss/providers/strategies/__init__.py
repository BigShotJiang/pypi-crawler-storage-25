"""Auth strategy registry."""

from __future__ import annotations

from collections.abc import Callable
from typing import Protocol

from kiss.providers.types import ProviderProfile


class AuthStrategy(Protocol):
    auth_type: str

    def resolve(
        self, profile: ProviderProfile, settings: object, _depth: int = 0
    ) -> str | None: ...
    def register(self, profile: ProviderProfile, credentials: str | None) -> None: ...
    async def run(
        self,
        app: object,
        on_event: Callable[[str, dict], None] | None = None,
    ) -> str | None: ...


_STRATEGIES: dict[str, AuthStrategy] = {}


def register_strategy(strategy: AuthStrategy) -> None:
    _STRATEGIES[strategy.auth_type] = strategy


def get_strategy(auth_type: str) -> AuthStrategy | None:
    return _STRATEGIES.get(auth_type)
