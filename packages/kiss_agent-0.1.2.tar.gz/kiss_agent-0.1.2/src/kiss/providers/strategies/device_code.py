"""DeviceCodeStrategy — auth_type="device_code".

Reserved for future providers. No bundled provider uses it yet.
"""

from __future__ import annotations

from collections.abc import Callable

from kiss.providers.types import ProviderProfile
from kiss.providers.strategies import register_strategy


class DeviceCodeStrategy:
    auth_type = "device_code"

    def resolve(
        self, profile: ProviderProfile, settings: object, _depth: int = 0
    ) -> str | None:
        # Parameterized OAuth 2.0 device flow from profile.auth_config_map
        # Full implementation deferred — no bundled provider uses this yet.
        cfg = profile.auth_config_map
        device_code_url = cfg.get("device_code_url", "")
        if not device_code_url:
            return None
        # Would initiate device flow here; return None until implemented
        return None

    def register(self, profile: ProviderProfile, credentials: str | None) -> None:
        from kiss.providers.manager import _register_openai_compatible

        _register_openai_compatible(profile, credentials or "")

    async def run(
        self,
        app: object,
        on_event: Callable[[str, dict], None] | None = None,
    ) -> str | None:
        return None


register_strategy(DeviceCodeStrategy())
