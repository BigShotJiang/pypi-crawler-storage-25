"""ApiKeyStrategy — auth_type="api_key"."""

from __future__ import annotations

import os
from collections.abc import Callable

from kiss.providers.types import ProviderProfile
from kiss.providers.strategies import register_strategy


class ApiKeyStrategy:
    auth_type = "api_key"

    def resolve(
        self, profile: ProviderProfile, settings: object, _depth: int = 0
    ) -> str | None:
        # 1. Check settings api_key field
        api_key_from_settings = getattr(
            getattr(settings, "active_provider_config", None), "get_api_key", lambda: ""
        )()
        if api_key_from_settings:
            return api_key_from_settings

        # 2. Check env vars declared on profile
        for var in profile.env_vars:
            val = os.environ.get(var, "")
            if val:
                return val

        # 3. Use default_key if set (e.g. litellm)
        if profile.default_key:
            return profile.default_key

        # 4. Check keyring (stored by /connect)
        from kiss.providers.keyring_store import get_credential

        stored = get_credential(f"provider:{profile.name}")
        if stored:
            return stored

        # 5. Delegate to fallback_auth_type strategy (max depth 3 guards against cycles)
        if profile.fallback_auth_type and _depth < 3:
            from kiss.providers.strategies import get_strategy

            fallback = get_strategy(profile.fallback_auth_type)
            if fallback:
                return fallback.resolve(profile, settings, _depth + 1)

        return None

    def register(self, profile: ProviderProfile, credentials: str | None) -> None:
        from kiss.providers.litellm_config import apply_litellm_config
        from kiss.providers.manager import _register_openai_compatible

        _register_openai_compatible(profile, credentials or "")
        apply_litellm_config(profile, credentials)

    async def run(
        self,
        app: object,
        on_event: Callable[[str, dict], None] | None = None,
    ) -> str | None:
        return None


register_strategy(ApiKeyStrategy())
