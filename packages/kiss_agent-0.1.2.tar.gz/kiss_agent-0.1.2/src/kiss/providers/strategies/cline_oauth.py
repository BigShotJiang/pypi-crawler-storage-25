"""ClineOAuthStrategy — auth_type="cline_oauth"."""

from __future__ import annotations

from collections.abc import Callable

from kiss.providers.types import ProviderProfile
from kiss.providers.strategies import register_strategy


class ClineOAuthStrategy:
    auth_type = "cline_oauth"

    def resolve(
        self, profile: ProviderProfile, settings: object, _depth: int = 0
    ) -> str | None:
        from kiss.providers.cline_auth import get_access_token

        return get_access_token()

    def register(self, profile: ProviderProfile, credentials: str | None) -> None:
        from kiss.providers.litellm_config import apply_litellm_config
        from kiss.providers.manager import _register_openai_compatible

        _register_openai_compatible(profile, credentials or "")
        apply_litellm_config(profile, credentials)

    async def run(
        self,
        app: object,
        on_event: Callable[[str, dict], None] | None = None,
    ) -> str | None:
        from kiss.providers.cline_auth import get_access_token, start_oauth_flow

        start_oauth_flow(force_relogin=True)
        return get_access_token()


register_strategy(ClineOAuthStrategy())
