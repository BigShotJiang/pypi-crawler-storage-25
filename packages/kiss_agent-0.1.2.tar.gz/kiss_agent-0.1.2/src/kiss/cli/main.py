"""CLI entry point"""

from __future__ import annotations

import argparse
import asyncio
import sys
from typing import TYPE_CHECKING

from kiss.core.settings import SettingsError, Settings, settings_load

if TYPE_CHECKING:
    from kiss.agent.loop import KissAgent


async def _load_settings_and_create_agent() -> tuple[Settings, KissAgent]:
    """Load settings and create agent asynchronously."""
    from kiss.agent.loop import KissAgent

    settings = await settings_load()
    agent = await KissAgent.create(settings)
    return settings, agent


_UI_CHOICES = ("rich", "textual")


def main() -> None:
    parser = argparse.ArgumentParser(prog="kiss")
    subparsers = parser.add_subparsers(dest="subcommand")

    sessions_parser = subparsers.add_parser("sessions", help="Manage saved sessions")
    sessions_sub = sessions_parser.add_subparsers(dest="sessions_action")
    sessions_sub.add_parser("list", help="List available sessions")

    db_parser = subparsers.add_parser("db", help="SessionDB maintenance")
    db_sub = db_parser.add_subparsers(dest="db_action")
    db_sub.add_parser("status", help="Show SessionDB status")
    db_sub.add_parser("vacuum", help="Rebuild FTS indexes and VACUUM")

    skill_parser = subparsers.add_parser("skill", help="Skill management")
    skill_sub = skill_parser.add_subparsers(dest="skill_action")
    skill_trust_parser = skill_sub.add_parser("trust", help="Trust a skill by name")
    skill_trust_parser.add_argument("name", help="Skill name (filename without .md)")

    memory_parser = subparsers.add_parser("memory", help="Memory layer management")
    memory_sub = memory_parser.add_subparsers(dest="memory_action")
    memory_sub.add_parser("status", help="Show memory pool status")
    memory_sub.add_parser("compact", help="Manually trigger Observer→Reflector→Pruner")

    archive_parser = subparsers.add_parser("archive", help="Archive management")
    archive_sub = archive_parser.add_subparsers(dest="archive_action")
    archive_list_parser = archive_sub.add_parser("list", help="List archives")
    archive_list_parser.add_argument("--session", help="Filter by session ID")
    archive_restore_parser = archive_sub.add_parser(
        "restore", help="Restore an archive"
    )
    archive_restore_parser.add_argument("archive_id", help="Archive ID to restore")

    cache_parser = subparsers.add_parser("cache", help="Cache management")
    cache_sub = cache_parser.add_subparsers(dest="cache_action")
    cache_sub.add_parser("clear-models", help="Delete the model list cache")

    parser.add_argument(
        "--tui",
        action="store_true",
        help="Launch the Textual TUI — shorthand for --ui textual",
    )
    parser.add_argument(
        "--ui",
        choices=_UI_CHOICES,
        default=None,
        metavar="BACKEND",
        help=(
            "UI backend to use: rich (default), textual (Textual full TUI). "
            f"Choices: {', '.join(_UI_CHOICES)}"
        ),
    )
    parser.add_argument(
        "--allow-destructive-tools",
        action="store_true",
        help="Auto-approve destructive tool calls in non-interactive mode (default: plan-only)",
    )
    parser.add_argument(
        "--resume",
        metavar="UUID",
        help="Resume a previous session by snapshot UUID (see: kiss sessions list)",
    )
    parser.add_argument("task", nargs="*", help="Initial prompt (non-interactive mode)")
    args, _ = parser.parse_known_args()

    if args.subcommand == "sessions":
        if args.sessions_action == "list":
            from pathlib import Path
            from kiss.core.session_manager import SessionManager

            sm = SessionManager(Path.home() / ".kiss" / "sessions")
            sessions = sm.list_sessions()
            if not sessions:
                print("No sessions found.")
            else:
                for s in sessions:
                    print(f"{s['uuid']}  {s['ts']}")
        else:
            sessions_parser.print_help()
        return

    if args.subcommand == "db":
        from pathlib import Path
        from kiss.core.session_db import SessionDB, db_status, db_vacuum

        db_path = Path(".kiss") / "session.db"
        if not db_path.exists():
            print(f"No SessionDB found at {db_path}", file=sys.stderr)
            sys.exit(1)

        db = SessionDB(db_path)
        if args.db_action == "status":
            print(db_status(db))
        elif args.db_action == "vacuum":
            confirm = input("This may take a while. Continue? [y/N] ")
            if confirm.lower() != "y":
                print("Cancelled.")
                return
            print(db_vacuum(db))
        else:
            db_parser.print_help()
        db.close()
        return

    if args.subcommand == "skill":
        from pathlib import Path
        from kiss.core.session_db import SessionDB
        from kiss.core.skills import SkillLoader

        db_path = Path(".kiss") / "session.db"
        if not db_path.exists():
            print(f"No SessionDB found at {db_path}", file=sys.stderr)
            sys.exit(1)

        db = SessionDB(db_path)
        if args.skill_action == "trust":
            # Find active session
            row = (
                db._connect()
                .execute("SELECT id FROM sessions ORDER BY created_at DESC LIMIT 1")
                .fetchone()
            )
            if not row:
                print("No active session found.", file=sys.stderr)
                sys.exit(1)

            session_id = row["id"]
            workspace = Path.cwd()
            loader = SkillLoader(db=db, project_root=workspace)
            ok, result = loader.trust_skill(session_id, args.name)
            if ok:
                print(f"Skill '{args.name}' trusted (fingerprint: {result[:16]}).")
            else:
                print(f"Error: {result}", file=sys.stderr)
                sys.exit(1)
        else:
            skill_parser.print_help()
        db.close()
        return

    if args.subcommand == "memory":
        from pathlib import Path
        from kiss.core.session_db import SessionDB
        from kiss.core.memory import MemoryObserver, memory_status, run_memory_pipeline

        db_path = Path(".kiss") / "session.db"
        if not db_path.exists():
            print(f"No SessionDB found at {db_path}", file=sys.stderr)
            sys.exit(1)

        db = SessionDB(db_path)
        row = (
            db._connect()
            .execute("SELECT id FROM sessions ORDER BY created_at DESC LIMIT 1")
            .fetchone()
        )
        if not row:
            print("No active session found.", file=sys.stderr)
            sys.exit(1)
        session_id = row["id"]

        if args.memory_action == "status":
            print(memory_status(db, session_id))
        elif args.memory_action == "compact":
            import asyncio as _asyncio

            observer = MemoryObserver(db)
            print("Running Observer → Reflector → Pruner pipeline...")
            results = _asyncio.run(
                run_memory_pipeline(
                    session_id,
                    db,
                    observer,
                    reflector=None,
                    pruner=None,
                )
            )
            print(
                f"Done: {results['observations_added']} observations added, "
                f"{results['reflections_added']} reflections added, "
                f"{results['observations_pruned']} observations pruned."
            )
            print("\nCurrent status:")
            print(memory_status(db, session_id))
        else:
            memory_parser.print_help()
        db.close()
        return

    if args.subcommand == "cache":
        from kiss.providers.model_cache import clear_model_cache, _CACHE_FILE

        if args.cache_action == "clear-models":
            deleted = clear_model_cache()
            if deleted:
                print(f"Deleted model cache: {_CACHE_FILE}")
            else:
                print("No model cache found.")
        else:
            cache_parser.print_help()
        return

    if args.subcommand == "archive":
        from pathlib import Path
        from kiss.core.session_db import SessionDB
        from kiss.core.retention import list_archives, restore_archive

        db_path = Path(".kiss") / "session.db"
        if not db_path.exists():
            print(f"No SessionDB found at {db_path}", file=sys.stderr)
            sys.exit(1)

        db = SessionDB(db_path)
        if args.archive_action == "list":
            print(list_archives(db, session_id=getattr(args, "session", None)))
        elif args.archive_action == "restore":
            confirm = input(
                f"Restore archive '{args.archive_id}'? This re-inserts rows. [y/N] "
            )
            if confirm.lower() != "y":
                print("Cancelled.")
            else:
                print(restore_archive(db, args.archive_id))
        else:
            archive_parser.print_help()
        db.close()
        return

    # --tui is a backwards-compatible alias for --ui textual
    if args.tui and args.ui is None:
        args.ui = "textual"
    if args.ui is None:
        args.ui = "rich"

    try:
        settings = asyncio.run(_load_settings_and_create_agent())
        agent = settings[1]
        settings = settings[0]
    except SettingsError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    if args.resume:
        ts = agent.restore_session(uuid=args.resume)
        if ts is None:
            print(f"Session '{args.resume}' not found.", file=sys.stderr)
            sessions = agent.session_manager.list_sessions()
            if sessions:
                print("Available sessions:", file=sys.stderr)
                for s in sessions:
                    print(f"  {s['uuid']}  {s['ts']}", file=sys.stderr)
            else:
                print("No sessions available.", file=sys.stderr)
            sys.exit(1)

    # Non-interactive: prompt from stdin or CLI args
    prompt = ""
    if not sys.stdin.isatty() and args.ui != "textual":
        prompt = sys.stdin.read().strip()
    elif args.task:
        prompt = " ".join(args.task)

    if prompt:
        try:
            agent.run_headless(prompt, allow_destructive=args.allow_destructive_tools)
        finally:
            agent.shutdown()
        return

    # Interactive: pick backend
    if args.ui == "textual":
        try:
            from kiss.ui.textual.backend import TextualBackend
        except ImportError:
            print(
                "Error: Textual is not installed. Run: uv add textual textual-autocomplete",
                file=sys.stderr,
            )
            sys.exit(1)
        backend = TextualBackend()

    else:
        from kiss.ui.rich.statusbar_backend import RichStatusBarBackend

        backend = RichStatusBarBackend()

    try:
        asyncio.run(backend.run(agent, settings))
    except KeyboardInterrupt:
        pass
    finally:
        agent.shutdown()
