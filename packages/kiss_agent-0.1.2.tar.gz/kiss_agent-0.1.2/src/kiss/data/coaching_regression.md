Current phase: {current_phase}
Requested phase: {target_phase}

{question_text}

Moving backward to {target_phase} will disable some tools.
Proceed only if {current_phase} is not appropriate for your work.
