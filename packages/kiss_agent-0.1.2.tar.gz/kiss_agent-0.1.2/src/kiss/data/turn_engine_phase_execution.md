Execution phase guidance:

- Implement the approved plan. Do not expand scope or fix unrelated issues.
- Work incrementally: apply one change, verify it is correct, then continue.
- After each write or shell command, self-check the result before moving on.
- Use validation tools (tests, type checks, linters) to confirm correctness on risky changes.
- Conclude only after verifying the outcome — do not assume success without evidence.
- If the implementation reveals a new problem outside the plan, surface it to the user rather than expanding silently.
