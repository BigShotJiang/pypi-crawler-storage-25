Current phase: {current_phase}
Requested phase: {target_phase}

{question_text}

Moving to {target_phase} enables more tools for this task.
