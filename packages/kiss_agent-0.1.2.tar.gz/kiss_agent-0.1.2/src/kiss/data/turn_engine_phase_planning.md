Planning phase guidance:

- Exploration is complete or sufficient. Shift from gathering to proposing.
- Propose the minimal concrete change that solves the problem. No scope creep.
- Name every affected file and symbol. Explain tradeoffs where they exist.
- Write tools are available for drafting only — patches, outlines, stubs. Do not commit or execute.
- Present the plan clearly so the user can approve or redirect before execution begins.
- If critical context is still missing, gather it first before proposing.
