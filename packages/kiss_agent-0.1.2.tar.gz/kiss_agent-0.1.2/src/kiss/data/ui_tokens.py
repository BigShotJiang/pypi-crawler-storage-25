"""Shared semantic visual token definitions.

Centralized internal defaults. Both backends map from these tokens using their
own rendering primitives:
  - Rich: rich.theme.Theme (see kiss.ui.rich.theme)
  - Textual: CSS/TCSS variables (see KissApp.CSS)

Maintainers retune readability from this file without touching backend code.
Do not expose these as a public user-facing theme API.
"""

from __future__ import annotations

from dataclasses import dataclass


# ── Lane glyph table ─────────────────────────────────────────────────────────


@dataclass(frozen=True)
class LaneGlyphSet:
    """Unicode rail glyph and ASCII safe-fallback for one transcript lane kind."""

    unicode: str
    ascii: str


# Normative first-pass glyph mapping. user/assistant MUST NOT share glyphs.
# Non-collision rule: user ▋/> vs assistant ▊/<  (different Unicode, different ASCII).
LANE_GLYPHS: dict[str, LaneGlyphSet] = {
    "user": LaneGlyphSet("▋", ">"),
    "assistant": LaneGlyphSet("▊", "<"),
    "thought": LaneGlyphSet("▏", ":"),
    "tool": LaneGlyphSet("│", "|"),
    "system": LaneGlyphSet("│", "|"),
    "info": LaneGlyphSet("│", "|"),
    "warning": LaneGlyphSet("│", "!"),
    "error": LaneGlyphSet("│", "!"),
}


@dataclass(frozen=True)
class UITokenSet:
    """Semantic visual token definitions for terminal UI surfaces."""

    # ── Text ─────────────────────────────────────────────────────────────
    text_primary: str  # main conversation content
    text_muted: str  # low-emphasis metadata and hints
    text_subtle: str  # separators and very low-emphasis chrome
    text_success: str  # success states
    text_warning: str  # warnings and caution states
    text_error: str  # error and failure states
    text_accent: str  # interactive emphasis and active labels

    # ── Borders ───────────────────────────────────────────────────────────
    border_default: str  # standard panel borders
    border_active: str  # focused or active container borders
    border_subtle: str  # quiet dividers and low-emphasis separators

    # ── Panels ────────────────────────────────────────────────────────────
    panel_bg: str  # primary panel background
    panel_bg_alt: str  # secondary panel background

    # ── Selection ─────────────────────────────────────────────────────────
    selection_bg: str  # selected row or active item background
    selection_fg: str  # selected row or active item foreground

    # ── Status ────────────────────────────────────────────────────────────
    status_idle: str  # idle state treatment
    status_streaming: str  # assistant streaming state
    status_running: str  # tool-running state
    status_blocked: str  # permission or ask-user blocked state
    status_compacting: str  # compaction state
    status_warning: str  # warning or degraded state treatment
    status_error: str  # error or failure state treatment

    # ── Syntax ────────────────────────────────────────────────────────────
    syntax_comment: str  # syntax highlight comment color
    syntax_keyword: str  # syntax highlight keyword color
    syntax_function: str  # syntax highlight function color
    syntax_variable: str  # syntax highlight variable color
    syntax_string: str  # syntax highlight string color
    syntax_number: str  # syntax highlight number color
    syntax_type: str  # syntax highlight type color
    syntax_operator: str  # syntax highlight operator color
    syntax_punctuation: str  # syntax highlight punctuation color


# Default opinionated token set. First-pass values calibrated for dark terminals.
DEFAULT_TOKENS = UITokenSet(
    text_primary="#e2e8f0",
    text_muted="#94a3b8",
    text_subtle="#6b7280",
    text_success="#86efac",
    text_warning="#d7af5f",
    text_error="#f87171",
    text_accent="#38bdf8",
    border_default="#444444",
    border_active="#38bdf8",
    border_subtle="#1e293b",
    panel_bg="#1e1e1e",
    panel_bg_alt="#252526",
    selection_bg="#264f78",
    selection_fg="#ffffff",
    status_idle="#555555",
    status_streaming="#5fafd7",
    status_running="#d7af5f",
    status_blocked="#f87171",
    status_compacting="#d7af00",
    status_warning="#d7af5f",
    status_error="#f87171",
    syntax_comment="#6a9955",
    syntax_keyword="#569cd6",
    syntax_function="#dcdcaa",
    syntax_variable="#9cdcfe",
    syntax_string="#ce9178",
    syntax_number="#b5cea8",
    syntax_type="#4ec9b0",
    syntax_operator="#d4d4d4",
    syntax_punctuation="#808080",
)
