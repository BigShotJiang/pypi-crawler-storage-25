Analyze this session and extract non-obvious learnings.
Focus on hidden relationships, debugging breakthroughs, misleading errors, and build quirks.
Keep each insight to 1-3 lines.
Write the result to the session-local `agents_learn.md` artifact, not `AGENTS.md`.
