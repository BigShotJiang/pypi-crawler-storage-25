"""Helpers for classifying provider errors related to context overflow."""

from __future__ import annotations

from dataclasses import dataclass
from collections.abc import Iterator

from mirascope.llm.exceptions import APIError, Error

_OVERFLOW_STATUS_CODES = {413}
_OVERFLOW_MESSAGE_MARKERS = (
    "context length exceeded",
    "maximum context length",
    "context window exceeded",
    "prompt is too long",
    "input is too long",
    "input exceeds the context window",
    "too many tokens",
    "request is too large",
    "payload too large",
)


@dataclass(frozen=True, slots=True)
class OverflowClassification:
    """Result of checking whether an exception is a context overflow."""

    is_overflow: bool
    provider_error_type: str | None = None
    status_code: int | None = None
    matched_reason: str | None = None


def classify_context_overflow_error(error: BaseException) -> OverflowClassification:
    """Classify an exception as a context overflow or a normal failure.

    The classifier is conservative:
    - explicit request-too-large responses are treated as overflow
    - message text must mention a context-length style failure for other cases
    - unrelated provider errors are left as non-overflow
    """

    fallback: OverflowClassification | None = None
    for candidate in _iter_exception_chain(error):
        classification = _classify_candidate(candidate)
        if classification.is_overflow:
            return classification
        if fallback is None:
            fallback = classification
    if fallback is not None:
        return fallback
    return OverflowClassification(is_overflow=False)


def _iter_exception_chain(error: BaseException) -> Iterator[BaseException]:
    seen: set[int] = set()
    current: BaseException | None = error
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        yield current

        next_error = getattr(current, "__cause__", None)
        if next_error is None:
            next_error = getattr(current, "__context__", None)
        current = next_error


def _classify_candidate(error: BaseException) -> OverflowClassification:
    status_code = _status_code(error)
    message = str(error).strip()
    provider_error_type = type(error).__name__

    if status_code in _OVERFLOW_STATUS_CODES:
        return OverflowClassification(
            is_overflow=True,
            provider_error_type=provider_error_type,
            status_code=status_code,
            matched_reason=f"status_code:{status_code}",
        )

    if isinstance(error, APIError):
        if status_code in {400, 422} and _message_looks_like_overflow(message):
            return OverflowClassification(
                is_overflow=True,
                provider_error_type=provider_error_type,
                status_code=status_code,
                matched_reason=f"status_code:{status_code}+message",
            )

    if isinstance(error, Error) and _message_looks_like_overflow(message):
        return OverflowClassification(
            is_overflow=True,
            provider_error_type=provider_error_type,
            status_code=status_code,
            matched_reason="message",
        )

    return OverflowClassification(
        is_overflow=False,
        provider_error_type=provider_error_type,
        status_code=status_code,
    )


def _status_code(error: BaseException) -> int | None:
    value = getattr(error, "status_code", None)
    if isinstance(value, int):
        return value

    response = getattr(error, "response", None)
    value = getattr(response, "status_code", None)
    if isinstance(value, int):
        return value

    return None


def _message_looks_like_overflow(message: str) -> bool:
    lowered = message.lower()
    return any(marker in lowered for marker in _OVERFLOW_MESSAGE_MARKERS)
