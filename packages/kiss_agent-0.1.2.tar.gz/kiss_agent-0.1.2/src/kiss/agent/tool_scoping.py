from __future__ import annotations

import re
from typing import Literal

ToolSetName = Literal["search", "edit", "validate", "full"]

_EDIT_VERBS = {
    "fix",
    "fixing",
    "implement",
    "implementing",
    "write",
    "writing",
    "create",
    "creating",
    "edit",
    "editing",
    "refactor",
    "refactoring",
    "update",
    "updating",
    "change",
    "changing",
    "add",
    "adding",
    "delete",
    "deleting",
    "remove",
    "removing",
    "rename",
    "renaming",
    "move",
    "moving",
    "revert",
    "reverting",
    "migrate",
    "migrating",
    "patch",
    "patching",
}
_VALIDATE_VERBS = {
    "review",
    "reviewing",
    "validate",
    "validating",
    "lint",
    "linting",
    "check",
    "checking",
    "verify",
    "verifying",
    "test",
    "testing",
    "audit",
    "auditing",
    "run",
    "running",
}
_SEARCH_VERBS = {
    "explain",
    "explaining",
    "find",
    "finding",
    "show",
    "showing",
    "search",
    "searching",
    "what",
    "where",
    "why",
    "how",
    "describe",
    "describing",
    "list",
    "listing",
    "read",
    "reading",
    "look",
    "looking",
    "debug",
    "debugging",
    "trace",
    "tracing",
    "investigate",
    "investigating",
    "explore",
    "exploring",
}

_EDIT_PATTERN = re.compile(
    r"\b(" + "|".join(re.escape(v) for v in _EDIT_VERBS) + r")\b", re.IGNORECASE
)
_VALIDATE_PATTERN = re.compile(
    r"\b(" + "|".join(re.escape(v) for v in _VALIDATE_VERBS) + r")\b", re.IGNORECASE
)
_SEARCH_PATTERN = re.compile(
    r"\b(" + "|".join(re.escape(v) for v in _SEARCH_VERBS) + r")\b", re.IGNORECASE
)


def classify_intent(task: str) -> ToolSetName:
    if _EDIT_PATTERN.search(task):
        return "edit"
    if _VALIDATE_PATTERN.search(task):
        return "validate"
    if _SEARCH_PATTERN.search(task):
        return "search"
    return "full"
