"""Turn-engine runtime for per-turn unified reasoning."""

from __future__ import annotations

from collections.abc import Callable
import hashlib
from pathlib import Path
import re
import time
from typing import Any, cast
from uuid import uuid4

from mirascope import llm
from mirascope.llm.models import ThinkingConfig, ThinkingLevel

from kiss.agent.plan_types import (
    CompletionResult,
    Plan,
    PlanExecutionState,
    PlanResult,
    ProposedChange,
    TurnPhase,
    WriteBlockedResult,
)
from kiss.agent.runner import OnChunk, RETRY, StreamLoopResult, stream_loop
from kiss.agent.tool_scoping import ToolSetName
from kiss.agent.tools.memory import load_memory_block
from kiss.agent.tools.registry import create_all_tools
from kiss.core.deps import AgentDeps, _json_for_hash
from kiss.core.prompt import prompt_load_sync as prompt_load
from kiss.core.settings import Settings


_FILE_TASK_PATTERNS = (
    re.compile(r"\bcreate file\s+(?P<path>\S+)", re.IGNORECASE),
    re.compile(r"\bsave(?:\s+\w+)*\s+as\s+(?P<path>\S+)", re.IGNORECASE),
    re.compile(r"\boverwrite\s+(?P<path>\S+)", re.IGNORECASE),
    re.compile(r"\bupdate\s+(?P<path>\S+)", re.IGNORECASE),
    re.compile(r"\breplace\s+the\s+contents\s+of\s+(?P<path>\S+)", re.IGNORECASE),
)


def _extract_claimed_paths_from_task(task: str) -> list[str]:
    paths: list[str] = []
    for pattern in _FILE_TASK_PATTERNS:
        for match in pattern.finditer(task):
            raw = match.group("path").strip().strip("`\"'")
            if raw:
                paths.append(raw)
    return list(dict.fromkeys(paths))


def _is_file_write_task(task: str) -> bool:
    task_lower = task.lower()
    return any(
        phrase in task_lower
        for phrase in (
            "create file",
            "save",
            "overwrite",
            "new file",
            "update ",
            "replace the contents of",
        )
    )


def _snapshot_paths(paths: list[str], workspace_root: Path) -> dict[str, int]:
    snapshot: dict[str, int] = {}
    for raw in paths:
        path = Path(raw) if Path(raw).is_absolute() else workspace_root / raw
        try:
            snapshot[str(path)] = path.stat().st_mtime_ns
        except OSError:
            pass
    return snapshot


def _verified_file_write(
    task: str,
    tool_activity: list[str],
    workspace_root: Path,
    pre_snapshot: dict[str, int] | None = None,
) -> tuple[bool, list[str]]:
    claimed_paths = _extract_claimed_paths_from_task(task)
    successful_file_write = any(
        entry.startswith("RESULT write_file OK")
        or entry.startswith("RESULT edit_file OK")
        or entry.startswith("RESULT apply_patch OK")
        for entry in tool_activity
    )
    if successful_file_write:
        return True, claimed_paths

    successful_shell = any(
        entry.startswith("RESULT run_bash OK") for entry in tool_activity
    )
    if successful_shell and claimed_paths:

        def _modified(raw: str) -> bool:
            path = Path(raw) if Path(raw).is_absolute() else workspace_root / raw
            if not path.exists():
                return False
            if pre_snapshot is not None:
                return pre_snapshot.get(str(path)) != path.stat().st_mtime_ns
            # Cannot verify without a snapshot — treat as unverified
            return False

        if all(_modified(raw) for raw in claimed_paths):
            return True, claimed_paths
    return False, claimed_paths


def _extract_explicit_write_file_request(task: str) -> tuple[str, str] | None:
    match = re.search(
        r"\b(?:create file|overwrite|replace\s+the\s+contents\s+of)\s+"
        r"(?P<path>\S+)\s+with\s+"
        r"(?:this|the following)\s+content:\s*(?P<content>.*)",
        task,
        re.IGNORECASE | re.DOTALL,
    )
    if match is None:
        return None

    path = match.group("path").strip().strip("`\"'")
    body = match.group("content").lstrip("\n")
    if not path or not body.strip():
        return None
    return path, body


class TurnEngine:
    def __init__(
        self,
        model_id: str,
        workspace_root: Path,
        settings: Settings,
        tool_set: ToolSetName = "full",
        phase: TurnPhase = TurnPhase.RESEARCH,
        gate_writes: bool = True,
        system_prompt_additions: list[str] | None = None,
    ) -> None:
        self.model_id = model_id
        self.workspace_root = workspace_root
        self.settings = settings
        self.tool_set = tool_set
        self.phase = phase
        self.gate_writes = gate_writes
        self.system_prompt_additions = list(system_prompt_additions or [])
        self.tools = create_all_tools(tool_set, phase=phase, gate_writes=gate_writes)
        self.prompt = self._load_prompt()
        self._call_fn = self._build_call_fn()

    def _load_prompt(self) -> str:
        system_prompt = prompt_load("turn_engine_system")
        examples_prompt = prompt_load("turn_engine_examples")
        sections = [system_prompt.rstrip(), examples_prompt.rstrip()]
        phase_name = getattr(self, "phase", TurnPhase.RESEARCH).name.lower()
        try:
            phase_section = prompt_load(f"turn_engine_phase_{phase_name}")
            if phase_section.strip():
                sections.append(phase_section.rstrip())
        except FileNotFoundError:
            pass
        sections.extend(
            addition.rstrip()
            for addition in getattr(self, "system_prompt_additions", ())
            if addition.strip()
        )
        return "\n\n".join(sections) + "\n"

    def _build_call_fn(self) -> Callable[..., Any]:
        from kiss.providers.manager import configure_provider

        from kiss.core.settings import get_supported_params

        resolved_model_id, call_params = configure_provider(self.settings)
        thinking_params: dict[str, Any] = dict(call_params)
        level = self.settings.thinking_level
        if level and level != "none":
            supported = get_supported_params(self.settings.model_id)
            if "thinking" in supported:
                thinking_params["thinking"] = ThinkingConfig(
                    level=cast(ThinkingLevel, level),
                    include_thoughts=True,
                )
            elif "reasoning_effort" in supported:
                _effort_map = {
                    "minimal": "low",
                    "low": "low",
                    "medium": "medium",
                    "high": "high",
                    "max": "high",
                }
                effort = _effort_map.get(level)
                if effort:
                    thinking_params["reasoning_effort"] = effort

        if "context_management" in get_supported_params(self.settings.model_id):
            thinking_params["context_management"] = {"type": "enabled"}

        prompt = self.prompt
        workspace_root = self.workspace_root
        memory_enabled = self.settings.memory_enabled
        tools = self.tools

        @llm.call(
            resolved_model_id,
            tools=tools,
            retry=RETRY,
            call_params=thinking_params,
        )
        async def _turn_engine_call(
            ctx: llm.Context[AgentDeps], messages: list
        ) -> list:
            msgs = list(messages)
            if memory_enabled:
                memory_block = await load_memory_block(workspace_root)
                if memory_block:
                    msgs = [llm.messages.user(memory_block), *msgs]
            return [llm.messages.system(prompt), *msgs]

        return _turn_engine_call

    def _build_plan(
        self, blocked_calls: list[WriteBlockedResult], reasoning: str
    ) -> Plan:
        proposed_changes = [
            change
            for blocked_call in blocked_calls
            if (change := self._blocked_call_to_change(blocked_call)) is not None
        ]
        tool_calls = [
            {
                "tool_name": blocked_call.tool_name,
                "args": blocked_call.args,
                "reason": blocked_call.reason,
            }
            for blocked_call in blocked_calls
        ]
        impact = self._estimate_impact(blocked_calls, proposed_changes)
        payload = {
            "reasoning": reasoning,
            "proposed_changes": [
                {
                    "file": change.file,
                    "change_type": change.change_type,
                    "before": change.before,
                    "after": change.after,
                }
                for change in proposed_changes
            ],
            "tool_calls": tool_calls,
            "estimated_impact": impact,
        }
        return Plan(
            plan_id=f"plan-{uuid4().hex[:12]}",
            plan_hash=hashlib.sha256(_json_for_hash(payload).encode()).hexdigest(),
            timestamp=time.time(),
            reasoning=reasoning,
            proposed_changes=proposed_changes,
            tool_calls=tool_calls,
            estimated_impact=impact,
        )

    def _blocked_call_to_change(
        self, blocked_call: WriteBlockedResult
    ) -> ProposedChange | None:
        args = blocked_call.args
        if blocked_call.tool_name == "write_file":
            path = str(args.get("path", ""))
            return ProposedChange(
                file=path,
                change_type="create",
                before=None,
                after=args.get("content")
                if isinstance(args.get("content"), str)
                else None,
            )
        if blocked_call.tool_name == "edit_file":
            path = str(args.get("path", ""))
            return ProposedChange(
                file=path,
                change_type="modify",
                before=args.get("old_text")
                if isinstance(args.get("old_text"), str)
                else None,
                after=args.get("new_text")
                if isinstance(args.get("new_text"), str)
                else None,
            )
        if blocked_call.tool_name == "apply_patch":
            path = str(args.get("path", ""))
            return ProposedChange(
                file=path,
                change_type="modify",
                before=None,
                after=f"{len(args.get('changes', []))} patch change(s)",
            )
        if blocked_call.tool_name == "run_python":
            return ProposedChange(
                file="<python-script>",
                change_type="modify",
                before=None,
                after=args.get("code") if isinstance(args.get("code"), str) else None,
            )
        if blocked_call.tool_name == "run_bash":
            return ProposedChange(
                file="<shell-command>",
                change_type="modify",
                before=None,
                after=args.get("command")
                if isinstance(args.get("command"), str)
                else None,
            )
        if blocked_call.tool_name == "git_stage":
            paths = args.get("paths")
            return ProposedChange(
                file="<git-index>",
                change_type="modify",
                before=None,
                after=str(paths if paths is not None else []),
            )
        if blocked_call.tool_name == "git_commit":
            return ProposedChange(
                file="<git-commit>",
                change_type="modify",
                before=None,
                after=args.get("message")
                if isinstance(args.get("message"), str)
                else None,
            )
        return None

    def _estimate_impact(
        self,
        blocked_calls: list[WriteBlockedResult],
        proposed_changes: list[ProposedChange],
    ) -> str:
        if not blocked_calls:
            return "No blocked operations."
        unique_targets = sorted(
            {
                change.file
                for change in proposed_changes
                if change.file and not change.file.startswith("<")
            }
        )
        if unique_targets:
            return (
                f"{len(blocked_calls)} blocked operation(s) affecting "
                f"{len(unique_targets)} file target(s): {', '.join(unique_targets[:5])}"
            )
        return f"{len(blocked_calls)} blocked operation(s) require approval before execution."

    async def run(
        self,
        deps: AgentDeps,
        history: list,
        on_chunk: OnChunk,
        agent_label: str = "kiss-agent",
    ) -> PlanResult | CompletionResult:
        ctx = llm.Context(deps=deps)
        result: StreamLoopResult = await stream_loop(
            call_fn=self._call_fn,
            ctx=ctx,
            history=history,
            on_chunk=on_chunk,
            agent_label=agent_label,
            checkpoint_interval=self.settings.checkpoint_interval,
        )
        if deps.plan_state == PlanExecutionState.AWAITING_APPROVAL:
            blocked_calls = list(deps._blocked_calls)
            plan = self._build_plan(
                blocked_calls,
                result.text or "Write-capable tools were blocked pending approval.",
            )
            deps._blocked_calls.clear()
            deps.plan_state = PlanExecutionState.IDLE
            return PlanResult(
                plan=plan,
                blocked_calls=blocked_calls,
                messages=list(result.messages),
            )
        return CompletionResult(
            text=result.text,
            messages=list(result.messages),
            usage=result.usage,
            finish_reason=result.finish_reason,
        )


def format_plan(plan: Plan) -> str:
    lines = ["Plan pending approval", ""]
    if plan.reasoning:
        lines.extend(["Reasoning:", plan.reasoning.strip(), ""])
    if plan.proposed_changes:
        lines.append("Proposed changes:")
        for change in plan.proposed_changes:
            lines.append(f"- {change.change_type}: {change.file}")
        lines.append("")
    if plan.tool_calls:
        lines.append("Blocked tool calls:")
        for call in plan.tool_calls:
            lines.append(f"- {call['tool_name']}: {call['args']}")
        lines.append("")
    lines.append(f"Estimated impact: {plan.estimated_impact}")
    return "\n".join(lines).strip()
