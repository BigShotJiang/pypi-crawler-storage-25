from __future__ import annotations

import enum
from typing import Any

import msgspec


class PlanExecutionState(enum.Enum):
    IDLE = "idle"
    AWAITING_APPROVAL = "awaiting"
    APPROVED = "approved"


class TurnPhase(enum.IntEnum):
    RESEARCH = 1
    PLANNING = 2
    EXECUTION = 3


class WriteBlockedResult(msgspec.Struct, omit_defaults=True):
    tool_name: str
    args: dict[str, Any]
    reason: str = "plan_mode"

    def __str__(self) -> str:
        args_str = ", ".join(f"{k}={v!r}" for k, v in self.args.items())
        return f"[plan-mode] {self.tool_name}({args_str}) - blocked pending approval"


class ProposedChange(msgspec.Struct, omit_defaults=True):
    file: str
    change_type: str
    before: str | None
    after: str | None


class Plan(msgspec.Struct, omit_defaults=True):
    plan_id: str
    plan_hash: str
    timestamp: float
    reasoning: str
    proposed_changes: list[ProposedChange] = msgspec.field(default_factory=list)
    tool_calls: list[dict[str, Any]] = msgspec.field(default_factory=list)
    estimated_impact: str = ""


class PlanResult(msgspec.Struct, omit_defaults=True):
    plan: Plan
    blocked_calls: list[WriteBlockedResult]
    messages: list[Any]


class CompletionResult(msgspec.Struct, omit_defaults=True):
    text: str
    messages: list[Any]
    usage: Any
    finish_reason: str | None = None


def plan_to_dict(plan: Plan) -> dict[str, Any]:
    return {
        "plan_id": plan.plan_id,
        "plan_hash": plan.plan_hash,
        "timestamp": plan.timestamp,
        "reasoning": plan.reasoning,
        "proposed_changes": [
            {
                "file": change.file,
                "change_type": change.change_type,
                "before": change.before,
                "after": change.after,
            }
            for change in plan.proposed_changes
        ],
        "tool_calls": plan.tool_calls,
        "estimated_impact": plan.estimated_impact,
    }
