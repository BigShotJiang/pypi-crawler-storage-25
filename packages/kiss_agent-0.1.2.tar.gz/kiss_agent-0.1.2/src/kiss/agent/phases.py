from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Literal

from kiss.agent.plan_types import TurnPhase
from kiss.agent.tool_scoping import ToolSetName, classify_intent
from kiss.core.prompt import prompt_load_sync
from kiss.core.events import QuestionOption
from kiss.core.types import AskUserReply, AskUserRequest, Event, EventKind

IntentBucket = Literal[
    "write_or_edit",
    "run_shell",
    "git_commit",
    "general_execution",
]

_SLASH_COMMAND_PHASES: dict[str, TurnPhase] = {
    "/research": TurnPhase.RESEARCH,
    "/plan": TurnPhase.PLANNING,
    "/execute": TurnPhase.EXECUTION,
}

_PHASE_CONFIRMATIONS: dict[TurnPhase, str] = {
    TurnPhase.RESEARCH: "Switched to Research phase.",
    TurnPhase.PLANNING: "Switched to Planning phase.",
    TurnPhase.EXECUTION: "Switched to Execution phase.",
}

_RUN_SHELL_HINTS = (
    " run ",
    " shell",
    " bash",
    " command",
    " pytest",
    " ruff",
    " ty ",
    " uv run",
)

_COMMIT_HINTS = (
    "commit",
    "git commit",
)

_EXECUTION_HINTS = (
    "execute",
    "run tests",
    "run the tests",
    "run the command",
    "run command",
    "run the script",
    "run script",
)


@dataclass(frozen=True)
class PhaseResolution:
    cleaned_message: str
    tool_set: ToolSetName
    phase: TurnPhase
    explicit: bool = False
    phase_changed: bool = False
    control_only_confirmation: str | None = None


@dataclass(frozen=True)
class _TransitionCandidate:
    target_phase: TurnPhase
    intent_bucket: IntentBucket


class PhaseManager:
    def __init__(self) -> None:
        self._last_rejected_key: (
            tuple[TurnPhase, TurnPhase, ToolSetName, IntentBucket] | None
        ) = None

    def reset(self) -> None:
        self._last_rejected_key = None

    async def resolve(
        self,
        *,
        message: str,
        current_phase: TurnPhase,
        headless: bool,
        on_ask_user: Callable[[AskUserRequest], Awaitable[AskUserReply]] | None,
        on_event: Callable[[Event], Awaitable[None]] | None,
    ) -> PhaseResolution:
        slash_phase, cleaned_message = self._parse_slash_command(message)
        if slash_phase is not None:
            self.reset()
            tool_set = classify_intent(cleaned_message) if cleaned_message else "full"
            return PhaseResolution(
                cleaned_message=cleaned_message,
                tool_set=tool_set,
                phase=slash_phase,
                explicit=True,
                phase_changed=slash_phase is not current_phase,
                control_only_confirmation=(
                    _PHASE_CONFIRMATIONS[slash_phase] if not cleaned_message else None
                ),
            )

        tool_set = classify_intent(cleaned_message)
        candidate = self._transition_candidate(
            current_phase=current_phase,
            tool_set=tool_set,
            message=cleaned_message,
        )
        if candidate is None:
            return PhaseResolution(
                cleaned_message=cleaned_message,
                tool_set=tool_set,
                phase=current_phase,
            )

        if headless:
            if on_event is not None:
                await on_event(
                    Event(
                        kind=EventKind.INFO,
                        info=(
                            "Skipped heuristic phase coaching in non-interactive mode: "
                            f"{current_phase.name} -> {candidate.target_phase.name}"
                        ),
                    )
                )
            return PhaseResolution(
                cleaned_message=cleaned_message,
                tool_set=tool_set,
                phase=current_phase,
            )

        if on_ask_user is None:
            raise RuntimeError("Ask-user callback is not configured.")

        key = (
            current_phase,
            candidate.target_phase,
            tool_set,
            candidate.intent_bucket,
        )
        if self._last_rejected_key == key:
            return PhaseResolution(
                cleaned_message=cleaned_message,
                tool_set=tool_set,
                phase=current_phase,
            )

        prompt_name = self._prompt_name(
            current_phase=current_phase,
            target_phase=candidate.target_phase,
        )
        question_text = self._question_text(
            current_phase=current_phase,
            target_phase=candidate.target_phase,
        )
        question = prompt_load_sync(
            prompt_name,
            current_phase=current_phase.name,
            target_phase=candidate.target_phase.name,
            question_text=question_text,
        )
        reply = await on_ask_user(
            AskUserRequest(
                question=question,
                type="choice",
                options=[
                    QuestionOption(id="proceed", label="Proceed"),
                    QuestionOption(id="stay", label="Stay"),
                ],
                default_id="stay",
            )
        )
        if reply.outcome == "selected" and reply.selected_choice_ids == ["proceed"]:
            self.reset()
            return PhaseResolution(
                cleaned_message=cleaned_message,
                tool_set=tool_set,
                phase=candidate.target_phase,
                phase_changed=candidate.target_phase is not current_phase,
            )

        self._last_rejected_key = key
        if on_event is not None:
            await on_event(
                Event(
                    kind=EventKind.INFO,
                    info=(
                        "Phase coaching rejected: "
                        f"{current_phase.name} -> {candidate.target_phase.name}"
                    ),
                )
            )
        return PhaseResolution(
            cleaned_message=cleaned_message,
            tool_set=tool_set,
            phase=current_phase,
        )

    def _parse_slash_command(self, message: str) -> tuple[TurnPhase | None, str]:
        stripped = message.lstrip()
        if not stripped:
            return None, message
        first_token, separator, remainder = stripped.partition(" ")
        phase = _SLASH_COMMAND_PHASES.get(first_token)
        if phase is None:
            return None, message
        cleaned = remainder if separator else ""
        return phase, cleaned.strip()

    def _transition_candidate(
        self,
        *,
        current_phase: TurnPhase,
        tool_set: ToolSetName,
        message: str,
    ) -> _TransitionCandidate | None:
        if current_phase is TurnPhase.RESEARCH and tool_set in {"edit", "full"}:
            if tool_set == "full" and not self._has_execution_hint(message):
                return None
            return _TransitionCandidate(
                target_phase=TurnPhase.PLANNING,
                intent_bucket=self._intent_bucket(
                    current_phase=current_phase,
                    tool_set=tool_set,
                    message=message,
                ),
            )
        if (
            current_phase is TurnPhase.PLANNING
            and tool_set == "full"
            and self._has_commit_hint(message)
        ):
            return _TransitionCandidate(
                target_phase=TurnPhase.EXECUTION,
                intent_bucket=self._intent_bucket(
                    current_phase=current_phase,
                    tool_set=tool_set,
                    message=message,
                ),
            )
        # Backward regression coaching suppressed — user can use slash commands to go back.
        # if current_phase is TurnPhase.PLANNING and tool_set in {"search", "validate"}: ...
        # if current_phase is TurnPhase.EXECUTION and tool_set == "edit": ...
        # if current_phase is TurnPhase.EXECUTION and tool_set in {"search", "validate"}: ...
        return None

    def _intent_bucket(
        self,
        *,
        current_phase: TurnPhase,
        tool_set: ToolSetName,
        message: str,
    ) -> IntentBucket:
        lowered = f" {message.lower()} "
        if tool_set == "edit":
            return "write_or_edit"
        if any(hint in lowered for hint in _COMMIT_HINTS):
            return "git_commit"
        if current_phase is TurnPhase.PLANNING and tool_set == "full":
            return "git_commit"
        if any(hint in lowered for hint in _RUN_SHELL_HINTS):
            return "run_shell"
        return "general_execution"

    def _has_execution_hint(self, message: str) -> bool:
        lowered = message.lower()
        return self._has_commit_hint(message) or any(
            hint in lowered for hint in (*_RUN_SHELL_HINTS, *_EXECUTION_HINTS)
        )

    def _has_commit_hint(self, message: str) -> bool:
        lowered = message.lower()
        return any(hint in lowered for hint in _COMMIT_HINTS)

    _PROMPT_NAMES: dict[tuple[TurnPhase, TurnPhase], str] = {
        (TurnPhase.RESEARCH, TurnPhase.PLANNING): "coaching_research_to_planning",
        (TurnPhase.PLANNING, TurnPhase.EXECUTION): "coaching_planning_to_execution",
    }

    def _prompt_name(
        self,
        *,
        current_phase: TurnPhase,
        target_phase: TurnPhase,
    ) -> str:
        return self._PROMPT_NAMES.get(
            (current_phase, target_phase), "coaching_regression"
        )

    def _question_text(
        self,
        *,
        current_phase: TurnPhase,
        target_phase: TurnPhase,
    ) -> str:
        if target_phase > current_phase:
            return f"This request needs capabilities from {target_phase.name}. Switch phases?"
        return f"This request fits {target_phase.name} better. Move backward?"
