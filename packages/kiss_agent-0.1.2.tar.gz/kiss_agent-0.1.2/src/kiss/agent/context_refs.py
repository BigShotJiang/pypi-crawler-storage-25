"""Parse, resolve, preview, and expand @file references in user prompts."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re

from kiss.agent.tools.result_types import ExpandRefResult, ToolResultMeta

_PREVIEW_HEAD_LINES = 50
_REF_RE = re.compile(r"(?<![A-Za-z0-9_])@(?P<token>[^\s`]+)")


@dataclass(frozen=True)
class ContextRef:
    label: str
    path_text: str
    resolved_path: Path
    start_line: int | None = None
    end_line: int | None = None

    @property
    def is_range(self) -> bool:
        return self.start_line is not None and self.end_line is not None


@dataclass(frozen=True)
class MissingContextRef:
    label: str
    reason: str


@dataclass(frozen=True)
class ResolvedContextRefs:
    refs: dict[str, ContextRef]
    warnings: list[str]
    manifest: str
    injected_message: str


def resolve_message_context_refs(
    message: str,
    repo_root: Path,
) -> ResolvedContextRefs:
    found: list[ContextRef] = []
    missing: list[MissingContextRef] = []
    seen: set[str] = set()
    sanitized = _mask_code_segments(message)

    for match in _REF_RE.finditer(sanitized):
        token = match.group("token")
        label = _trim_trailing_punctuation(token)
        if not label:
            continue
        if label in seen:
            continue
        seen.add(label)
        path_text, start_text, end_text = _split_ref(label)
        range_info = _parse_range(label, start_text, end_text)
        if isinstance(range_info, str):
            missing.append(MissingContextRef(label=label, reason=range_info))
            continue
        start_line, end_line = range_info
        resolved = _resolve_path(path_text, repo_root)
        if resolved is None:
            missing.append(
                MissingContextRef(
                    label=label,
                    reason=f"Missing ref: {label} (path could not be resolved)",
                )
            )
            continue
        if not resolved.exists():
            missing.append(
                MissingContextRef(
                    label=label,
                    reason=f"Missing ref: {label} ({resolved} does not exist)",
                )
            )
            continue
        if not resolved.is_file():
            missing.append(
                MissingContextRef(
                    label=label,
                    reason=f"Missing ref: {label} ({resolved} is not a file)",
                )
            )
            continue
        found.append(
            ContextRef(
                label=label,
                path_text=path_text,
                resolved_path=resolved,
                start_line=start_line,
                end_line=end_line,
            )
        )

    if not found and not missing:
        return ResolvedContextRefs(
            refs={}, warnings=[], manifest="", injected_message=message
        )

    warnings = [item.reason for item in missing]
    manifest = _build_manifest(found, warnings, repo_root)
    injected = "\n\n".join(
        [
            manifest,
            "[User prompt]",
            message,
        ]
    )
    return ResolvedContextRefs(
        refs={ref.label: ref for ref in found},
        warnings=warnings,
        manifest=manifest,
        injected_message=injected,
    )


def expand_context_ref(
    ref: str, resolved_refs: dict[str, ContextRef], repo_root: Path
) -> ExpandRefResult:
    entry = resolved_refs.get(ref)
    if entry is None:
        valid = ", ".join(sorted(resolved_refs)) or "(none)"
        return ExpandRefResult(
            meta=ToolResultMeta(
                ok=False,
                error_code="not_found",
                error_message=f"Error: unknown ref {ref!r}. Valid refs for this turn: {valid}",
            ),
            ref=ref,
        )
    try:
        return ExpandRefResult(ref=ref, content=_render_expansion(entry, repo_root))
    except Exception as exc:
        return ExpandRefResult(
            meta=ToolResultMeta(
                ok=False,
                error_code="execution_failed",
                error_message=f"Error expanding ref {ref!r}: {exc}",
            ),
            ref=ref,
        )


def _build_manifest(
    refs: list[ContextRef], warnings: list[str], repo_root: Path
) -> str:
    lines: list[str] = []
    if refs:
        lines.append("[Referenced files]")
        for ref in refs:
            display = _display_path(ref.resolved_path, repo_root)
            if ref.is_range:
                preview = _format_range_preview(ref, repo_root)
                lines.append(f"- {ref.label}")
                lines.append(f"  resolved: {display}")
                lines.append("  preview:")
                lines.extend(f"    {line}" for line in preview.splitlines())
            else:
                preview = _format_head_preview(ref, repo_root)
                lines.append(f"- {ref.label}")
                lines.append(f"  resolved: {display}")
                lines.append(f"  preview: first {_PREVIEW_HEAD_LINES} lines")
                lines.extend(f"    {line}" for line in preview.splitlines())
        lines.append(
            "[Instructions]\nThe user explicitly referenced these files. "
            "Use the expand_ref tool if more file content is needed."
        )
    if warnings:
        lines.append("[Reference warnings]")
        lines.extend(f"- {warning}" for warning in warnings)
    return "\n".join(lines)


def _format_head_preview(ref: ContextRef, repo_root: Path) -> str:
    lines = _read_lines(ref.resolved_path)
    end = min(len(lines), _PREVIEW_HEAD_LINES)
    header = f"--- {_display_path(ref.resolved_path, repo_root)} lines 1-{end} ---"
    body = _numbered_lines(lines, 1, end)
    trailer = ""
    if len(lines) > end:
        trailer = (
            f"\n... ({len(lines) - end} more lines, use expand_ref for full content)"
        )
    return header + ("\n" + body if body else "") + trailer


def _format_range_preview(ref: ContextRef, repo_root: Path) -> str:
    lines = _read_lines(ref.resolved_path)
    if ref.start_line is None or ref.end_line is None:
        raise ValueError(f"Range ref missing line numbers: {ref}")
    if ref.start_line > len(lines):
        return (
            f"--- {_display_path(ref.resolved_path, repo_root)} lines "
            f"{ref.start_line}-{ref.end_line} ---\n"
            f"(file has {len(lines)} lines)"
        )
    end = min(len(lines), ref.end_line)
    header = (
        f"--- {_display_path(ref.resolved_path, repo_root)} "
        f"lines {ref.start_line}-{end} ---"
    )
    body = _numbered_lines(lines, ref.start_line, end)
    trailer = ""
    if ref.end_line > len(lines):
        trailer = (
            f"\n... (requested through line {ref.end_line}, file ends at {len(lines)})"
        )
    return header + ("\n" + body if body else "") + trailer


def _render_expansion(ref: ContextRef, repo_root: Path) -> str:
    lines = _read_lines(ref.resolved_path)
    display = _display_path(ref.resolved_path, repo_root)
    if ref.is_range:
        if ref.start_line is None or ref.end_line is None:
            raise ValueError(f"Range ref missing line numbers: {ref}")
        end = min(len(lines), ref.end_line)
        header = f"--- {display} lines {ref.start_line}-{end} ---"
        body = _numbered_lines(lines, ref.start_line, end)
        if ref.end_line > len(lines):
            body += f"\n... (requested through line {ref.end_line}, file ends at {len(lines)})"
        return header + ("\n" + body if body else "")
    header = f"--- {display} full content ---"
    body = _numbered_lines(lines, 1, len(lines))
    return header + ("\n" + body if body else "")


def _numbered_lines(lines: list[str], start_line: int, end_line: int) -> str:
    if end_line < start_line:
        return ""
    width = len(str(end_line))
    body: list[str] = []
    for line_no in range(start_line, end_line + 1):
        text = lines[line_no - 1].rstrip("\n")
        body.append(f"{line_no:>{width}} | {text}")
    return "\n".join(body)


def _read_lines(path: Path) -> list[str]:
    return path.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True)


def _display_path(path: Path, repo_root: Path) -> str:
    try:
        return str(path.relative_to(repo_root))
    except ValueError:
        return str(path)


def _parse_range(
    label: str, start_text: str | None, end_text: str | None
) -> tuple[int | None, int | None] | str:
    if start_text is None and end_text is None:
        return (None, None)
    if start_text is None or end_text is None:
        return f"Missing ref: {label} (invalid line range)"
    start_line = int(start_text)
    end_line = int(end_text)
    if start_line <= 0 or end_line <= 0:
        return f"Missing ref: {label} (line numbers must be positive)"
    if end_line < start_line:
        return f"Missing ref: {label} (line range must be start-end)"
    return (start_line, end_line)


def _resolve_path(path_text: str, repo_root: Path) -> Path | None:
    raw = Path(path_text).expanduser()
    candidates = [raw] if raw.is_absolute() else [repo_root / raw]
    fallback: Path | None = None
    for candidate in candidates:
        try:
            resolved = candidate.resolve()
        except OSError:
            continue
        if resolved.exists():
            return resolved
        if fallback is None:
            fallback = resolved
    return fallback


_FENCE_RE = re.compile(r"```.*?```", re.DOTALL)
_INLINE_RE = re.compile(r"`[^`\n]+`")


def _mask_code_segments(text: str) -> str:
    def _blank(m: re.Match[str]) -> str:
        return " " * len(m.group())

    # Blank balanced fences first; stray opener (odd count) gets removed too.
    text = _FENCE_RE.sub(_blank, text)
    if text.count("```") % 2 != 0:
        text = text.replace("```", "   ")
    return _INLINE_RE.sub(_blank, text)


def _trim_trailing_punctuation(token: str) -> str:
    return token.rstrip(".,;!?)]}")


def _split_ref(label: str) -> tuple[str, str | None, str | None]:
    match = re.fullmatch(r"(?P<path>.+):(?P<start>\d+)-(?P<end>\d+)", label)
    if match is None:
        return (label, None, None)
    return (match.group("path"), match.group("start"), match.group("end"))
