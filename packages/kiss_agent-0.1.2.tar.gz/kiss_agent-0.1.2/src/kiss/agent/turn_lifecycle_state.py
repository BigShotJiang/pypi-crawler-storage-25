"""Turn lifecycle prompt state and shutdown artifacts."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Protocol

from kiss.agent.plan_types import TurnPhase
from kiss.core.prompt import prompt_load_sync
from kiss.core.tracing import SessionTracer
from kiss.core.usage import TodoItem


class _LifecycleOwner(Protocol):
    _turn_phase: TurnPhase
    _last_tool_name: str
    todos: list[TodoItem]


class TurnLifecycleState:
    """Owns prompt additions, read tracking, and shutdown artifacts."""

    def __init__(self, *, owner: _LifecycleOwner) -> None:
        self._owner = owner
        self.consecutive_reads_since_mutation = 0
        self.post_file_nudge_pending = False
        self.shutdown_complete = False

    def reset(self) -> None:
        self.consecutive_reads_since_mutation = 0
        self.post_file_nudge_pending = False

    def mark_mutation(self) -> None:
        self.consecutive_reads_since_mutation = 0

    def mark_read(self) -> None:
        self.consecutive_reads_since_mutation += 1
        if self.consecutive_reads_since_mutation >= 3:
            self.post_file_nudge_pending = True

    def consume_system_prompt_additions(
        self, *, phase_constraints: dict[TurnPhase, str]
    ) -> list[str]:
        constraints = phase_constraints.get(
            self._owner._turn_phase, "Proceed with your current task."
        )
        additions = [
            prompt_load_sync(
                "phase_reminder",
                phase=self._owner._turn_phase.name,
                constraints=constraints,
            )
        ]
        if self.post_file_nudge_pending:
            additions.append(prompt_load_sync("post_file_nudge"))
            self.post_file_nudge_pending = False
        return additions

    def shutdown(self, *, tracer: SessionTracer, session_dir: Path) -> None:
        if self.shutdown_complete:
            return
        tracer.export_jsonl(session_dir / "traces.jsonl")
        tracer.shutdown()

        learnings_path = session_dir / "agents_learn.md"
        prompt_header = prompt_load_sync("agents_learn").splitlines()[0].strip()
        pending_todos = sum(0 if todo.done else 1 for todo in self._owner.todos)
        lines = [
            "# Session Learnings",
            "",
            f"Prompt source: {prompt_header}",
            f"- Final phase: {self._owner._turn_phase.name}.",
            f"- Last tool observed: {self._owner._last_tool_name or 'none'}.",
            f"- Pending todos at shutdown: {pending_todos}.",
            f"- Shutdown time: {datetime.now(UTC).isoformat()}.",
        ]
        learnings_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        self.shutdown_complete = True
