"""Regex language profile."""

from __future__ import annotations

from kiss.agent.analysis.registry import register_language
from kiss.agent.analysis.types import LanguageProfile, TsConfig


register_language(
    LanguageProfile(
        name="regex",
        extensions=frozenset({".re", ".regex"}),
        ts_config=TsConfig(
            language="regex",
            target_types=frozenset(
                {
                    "group",
                    "alternation",
                    "one_or_more",
                    "zero_or_more",
                    "count_quantifier",
                    "character_class",
                }
            ),
            metrics_fn=lambda c: {
                "group_count": c.get("group", 0),
                "alternation_count": c.get("alternation", 0),
                "quantifier_count": c.get("one_or_more", 0)
                + c.get("zero_or_more", 0)
                + c.get("count_quantifier", 0),
                "character_class_count": c.get("character_class", 0),
            },
        ),
    )
)
