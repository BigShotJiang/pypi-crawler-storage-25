"""Bash language profile."""

from __future__ import annotations

import re
from pathlib import Path

from kiss.agent.analysis.registry import register_language
from kiss.agent.analysis.types import LanguageProfile


def _shell_fallback(content: str) -> dict[str, int]:
    lines = content.splitlines()
    return {
        "function_count": sum(
            1
            for ln in lines
            if re.match(r"^\s*(?:function\s+\w+|\w+)\s*\(\s*\)\s*\{", ln)
        ),
        "variable_count": sum(
            1 for ln in lines if re.match(r"^\s*[A-Z_][A-Z0-9_]*=", ln)
        ),
        "source_count": sum(1 for ln in lines if re.match(r"^\s*(?:source|\.)\s", ln)),
    }


def _bash_metrics(content: str, path: Path | None = None):
    from kiss.agent.analysis.dispatch import _get_ts_parser, _count_ts_node_types
    from kiss.agent.tools.result_types import AnalysisIssue, CodeLocation, SourceRange

    parser = _get_ts_parser("bash")
    if parser is None:
        return _shell_fallback(content), []
    try:
        tree = parser.parse(
            (content if content.endswith("\n") else content + "\n").encode()
        )
    except Exception:
        return _shell_fallback(content), []

    counts = _count_ts_node_types(
        tree.root_node, {"function_definition", "variable_assignment", "command"}
    )
    issues = []
    if tree.root_node.has_error:
        issues = [
            AnalysisIssue(
                code="parse_error",
                message="Bash parse error",
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "", range=SourceRange(start_line=1)
                ),
            )
        ]
    return {
        "function_count": counts.get("function_definition", 0),
        "variable_count": counts.get("variable_assignment", 0),
        "command_count": counts.get("command", 0),
    }, issues


register_language(
    LanguageProfile(
        name="bash",
        extensions=frozenset({".sh", ".bash", ".zsh"}),
        metrics_fn=_bash_metrics,
    )
)
