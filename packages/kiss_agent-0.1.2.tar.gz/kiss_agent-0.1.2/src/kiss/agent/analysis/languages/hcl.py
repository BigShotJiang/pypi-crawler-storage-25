"""HCL/Terraform language profile."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from kiss.agent.analysis.registry import register_language
from kiss.agent.analysis.types import LanguageProfile
from kiss.agent.tools.result_types import AnalysisIssue, CodeLocation, SourceRange


def _hcl_metrics(content: str, path: Path | None = None):
    from kiss.agent.analysis.dispatch import _get_ts_parser

    parser = _get_ts_parser("hcl")
    if parser is None:
        return {}, []
    try:
        tree = parser.parse(
            (content if content.endswith("\n") else content + "\n").encode()
        )
    except Exception:
        return {}, []

    block_count = resource_count = data_count = variable_count = 0
    output_count = module_count = provider_count = 0

    def walk(node: Any) -> None:
        nonlocal block_count, resource_count, data_count, variable_count
        nonlocal output_count, module_count, provider_count
        if node.type == "block":
            block_count += 1
            for child in node.children:
                if child.type == "identifier":
                    bt = (
                        child.text.decode()
                        if isinstance(child.text, bytes)
                        else str(child.text)
                    )
                    if bt == "resource":
                        resource_count += 1
                    elif bt == "data":
                        data_count += 1
                    elif bt == "variable":
                        variable_count += 1
                    elif bt == "output":
                        output_count += 1
                    elif bt == "module":
                        module_count += 1
                    elif bt == "provider":
                        provider_count += 1
                    break
        for child in node.children:
            walk(child)

    walk(tree.root_node)
    issues = []
    if tree.root_node.has_error:
        issues = [
            AnalysisIssue(
                code="parse_error",
                message="HCL parse error",
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "", range=SourceRange(start_line=1)
                ),
            )
        ]
    return {
        "block_count": block_count,
        "resource_count": resource_count,
        "data_count": data_count,
        "variable_count": variable_count,
        "output_count": output_count,
        "module_count": module_count,
        "provider_count": provider_count,
    }, issues


register_language(
    LanguageProfile(
        name="hcl",
        extensions=frozenset({".tf", ".hcl"}),
        metrics_fn=_hcl_metrics,
    )
)
