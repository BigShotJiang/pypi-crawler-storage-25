"""jq language profile."""

from __future__ import annotations

from kiss.agent.analysis.registry import register_language
from kiss.agent.analysis.types import LanguageProfile, TsConfig


register_language(
    LanguageProfile(
        name="jq",
        extensions=frozenset({".jq"}),
        ts_config=TsConfig(
            language="jq",
            target_types=frozenset({"funcdef"}),
            metrics_fn=lambda c: {"function_count": c.get("funcdef", 0)},
        ),
    )
)
