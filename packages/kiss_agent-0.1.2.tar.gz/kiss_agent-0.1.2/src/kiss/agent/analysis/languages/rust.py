"""Rust language profile."""

from kiss.agent.analysis.registry import register_language
from kiss.agent.analysis.types import LanguageProfile, TsConfig

register_language(
    LanguageProfile(
        name="rust",
        extensions=frozenset({".rs"}),
        ts_config=TsConfig(
            language="rust",
            target_types=frozenset(
                {
                    "function_item",
                    "struct_item",
                    "enum_item",
                    "impl_item",
                    "trait_item",
                    "mod_item",
                }
            ),
            metrics_fn=lambda c: {
                "function_count": c.get("function_item", 0),
                "struct_count": c.get("struct_item", 0),
                "enum_count": c.get("enum_item", 0),
                "impl_count": c.get("impl_item", 0),
                "trait_count": c.get("trait_item", 0),
                "mod_count": c.get("mod_item", 0),
            },
        ),
    )
)
