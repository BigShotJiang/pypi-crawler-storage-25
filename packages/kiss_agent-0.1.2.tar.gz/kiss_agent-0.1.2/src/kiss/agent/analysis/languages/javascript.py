"""JavaScript language profile."""

from kiss.agent.analysis.registry import register_language
from kiss.agent.analysis.types import LanguageProfile, TsConfig

register_language(
    LanguageProfile(
        name="javascript",
        extensions=frozenset({".js", ".jsx", ".mjs", ".cjs"}),
        ts_config=TsConfig(
            language="javascript",
            target_types=frozenset(
                {
                    "function_declaration",
                    "arrow_function",
                    "function_expression",
                    "class_declaration",
                    "method_definition",
                    "import_statement",
                }
            ),
            metrics_fn=lambda c: {
                "function_count": c.get("function_declaration", 0)
                + c.get("arrow_function", 0)
                + c.get("function_expression", 0),
                "class_count": c.get("class_declaration", 0),
                "method_count": c.get("method_definition", 0),
                "import_count": c.get("import_statement", 0),
            },
        ),
    )
)
