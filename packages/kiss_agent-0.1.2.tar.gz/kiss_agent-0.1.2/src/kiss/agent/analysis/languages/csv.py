"""CSV language profile."""

from __future__ import annotations

import csv as _csv
import io
from pathlib import Path

from kiss.agent.analysis.registry import register_language
from kiss.agent.analysis.types import LanguageProfile


def _csv_metrics(content: str, path: Path | None = None):
    reader = _csv.reader(io.StringIO(content))
    rows = list(reader)
    cols = max((len(r) for r in rows), default=0)
    return {
        "row_count": len(rows),
        "column_count": cols,
        "header_count": len(rows[0]) if rows else 0,
    }, []


register_language(
    LanguageProfile(
        name="csv",
        extensions=frozenset({".csv"}),
        metrics_fn=_csv_metrics,
    )
)
