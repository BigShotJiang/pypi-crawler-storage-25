"""TSV language profile."""

from __future__ import annotations

import csv as _csv
import io
from pathlib import Path

from kiss.agent.analysis.registry import register_language
from kiss.agent.analysis.types import LanguageProfile


def _tsv_metrics(content: str, path: Path | None = None):
    reader = _csv.reader(io.StringIO(content), delimiter="\t")
    rows = list(reader)
    cols = max((len(r) for r in rows), default=0)
    return {
        "row_count": len(rows),
        "column_count": cols,
        "header_count": len(rows[0]) if rows else 0,
    }, []


register_language(
    LanguageProfile(
        name="tsv",
        extensions=frozenset({".tsv"}),
        metrics_fn=_tsv_metrics,
    )
)
