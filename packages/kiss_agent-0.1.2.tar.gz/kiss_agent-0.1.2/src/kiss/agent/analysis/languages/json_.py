"""JSON language profile."""

from __future__ import annotations

import json as _json
from pathlib import Path
from typing import Any

from kiss.agent.analysis.registry import register_language
from kiss.agent.analysis.types import LanguageProfile
from kiss.agent.tools.result_types import (
    AnalysisIssue,
    CheckStyleResult,
    CodeLocation,
    SourceRange,
    StyleViolation,
    SymbolInfo,
)

_FRESHNESS_STRATEGY = "on_demand_workspace_scan"


def _json_metrics_value(value: Any) -> dict[str, int]:
    key_count = 0
    object_count = 0
    array_count = 0
    max_depth = 0

    def walk(node: Any, depth: int) -> None:
        nonlocal key_count, object_count, array_count, max_depth
        max_depth = max(max_depth, depth)
        if isinstance(node, dict):
            object_count += 1
            key_count += len(node)
            for child in node.values():
                walk(child, depth + 1)
        elif isinstance(node, list):
            array_count += 1
            for child in node:
                walk(child, depth + 1)

    walk(value, 1)
    return {
        "key_count": key_count,
        "object_count": object_count,
        "array_count": array_count,
        "max_depth": max_depth,
    }


def json_document_symbols(
    path: Path, content: str
) -> tuple[list[SymbolInfo], list[AnalysisIssue]]:
    try:
        payload = _json.loads(content)
    except _json.JSONDecodeError as exc:
        return [], [
            AnalysisIssue(
                code="json_parse_error",
                message=exc.msg,
                severity="error",
                location=CodeLocation(
                    path=str(path),
                    range=SourceRange(
                        start_line=exc.lineno or 1,
                        start_col=exc.colno - 1 if exc.colno else 0,
                    ),
                ),
            )
        ]

    symbols: list[SymbolInfo] = []

    def visit(value: Any, container_name: str | None = None) -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                symbols.append(
                    SymbolInfo(
                        name=str(key),
                        kind="property",
                        language="json",
                        container_name=container_name,
                        location=CodeLocation(
                            path=str(path), range=SourceRange(start_line=1)
                        ),
                    )
                )
                visit(child, str(key))
        elif isinstance(value, list):
            for item in value:
                visit(item, container_name)

    visit(payload)
    return symbols, []


def _json_metrics(
    content: str, path: Path | None = None
) -> tuple[dict[str, int], list[AnalysisIssue]]:
    try:
        payload = _json.loads(content)
    except _json.JSONDecodeError as exc:
        return {}, [
            AnalysisIssue(
                code="json_parse_error",
                message=exc.msg,
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "",
                    range=SourceRange(
                        start_line=exc.lineno or 1,
                        start_col=exc.colno - 1 if exc.colno else 0,
                    ),
                ),
            )
        ]
    return _json_metrics_value(payload), []


def _json_style(path: Path, ruleset: str | None) -> CheckStyleResult:
    try:
        _json.loads(path.read_text(encoding="utf-8"))
        return CheckStyleResult(
            path=str(path),
            language="json",
            ruleset=ruleset,
            freshness_strategy=_FRESHNESS_STRATEGY,
            passed=True,
        )
    except _json.JSONDecodeError as exc:
        return CheckStyleResult(
            path=str(path),
            language="json",
            ruleset=ruleset,
            freshness_strategy=_FRESHNESS_STRATEGY,
            passed=False,
            violations=[
                StyleViolation(
                    code="json_parse_error",
                    message=exc.msg,
                    severity="error",
                    location=CodeLocation(
                        path=str(path),
                        range=SourceRange(
                            start_line=exc.lineno or 1,
                            start_col=exc.colno - 1 if exc.colno else 0,
                        ),
                    ),
                )
            ],
        )


register_language(
    LanguageProfile(
        name="json",
        extensions=frozenset({".json"}),
        metrics_fn=_json_metrics,
        symbols_fn=json_document_symbols,
        style_checker=_json_style,
    )
)
