"""PowerShell language profile."""

from __future__ import annotations

import re
from pathlib import Path

from kiss.agent.analysis.registry import register_language
from kiss.agent.analysis.types import LanguageProfile


def _ps_metrics(content: str, path: Path | None = None):
    return {
        "function_count": len(re.findall(r"\bfunction\s+\w+", content, re.IGNORECASE)),
        "class_count": len(re.findall(r"\bclass\s+\w+", content, re.IGNORECASE)),
        "param_block_count": content.count("param("),
    }, []


register_language(
    LanguageProfile(
        name="powershell",
        extensions=frozenset({".ps1", ".psm1", ".psd1"}),
        metrics_fn=_ps_metrics,
    )
)
