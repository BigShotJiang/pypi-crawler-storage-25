"""Go language profile."""

from kiss.agent.analysis.registry import register_language
from kiss.agent.analysis.types import LanguageProfile, TsConfig

register_language(
    LanguageProfile(
        name="go",
        extensions=frozenset({".go"}),
        ts_config=TsConfig(
            language="go",
            target_types=frozenset(
                {
                    "function_declaration",
                    "method_declaration",
                    "type_declaration",
                    "import_declaration",
                }
            ),
            metrics_fn=lambda c: {
                "function_count": c.get("function_declaration", 0),
                "method_count": c.get("method_declaration", 0),
                "type_count": c.get("type_declaration", 0),
                "import_count": c.get("import_declaration", 0),
            },
        ),
    )
)
