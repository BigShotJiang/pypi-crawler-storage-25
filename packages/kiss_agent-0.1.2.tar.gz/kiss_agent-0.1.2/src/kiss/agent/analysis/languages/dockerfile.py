"""Dockerfile language profile."""

from __future__ import annotations


from kiss.agent.analysis.registry import register_language
from kiss.agent.analysis.types import LanguageProfile, TsConfig


register_language(
    LanguageProfile(
        name="dockerfile",
        extensions=frozenset({".dockerfile", "Dockerfile"}),
        ts_config=TsConfig(
            language="dockerfile",
            target_types=frozenset(
                {
                    "from_instruction",
                    "run_instruction",
                    "copy_instruction",
                    "add_instruction",
                    "env_instruction",
                    "expose_instruction",
                    "arg_instruction",
                }
            ),
            metrics_fn=lambda c: {
                "stage_count": c.get("from_instruction", 0),
                "run_count": c.get("run_instruction", 0),
                "copy_count": c.get("copy_instruction", 0),
                "add_count": c.get("add_instruction", 0),
                "env_count": c.get("env_instruction", 0),
                "expose_count": c.get("expose_instruction", 0),
                "arg_count": c.get("arg_instruction", 0),
            },
        ),
    )
)
