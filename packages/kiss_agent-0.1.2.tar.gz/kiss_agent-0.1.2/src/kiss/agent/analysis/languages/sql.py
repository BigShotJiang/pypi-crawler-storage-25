"""SQL language profile."""

from __future__ import annotations

from pathlib import Path

from kiss.agent.analysis.registry import register_language
from kiss.agent.analysis.types import LanguageProfile


def _sql_metrics(content: str, path: Path | None = None):
    try:
        import sqlparse
    except ImportError:
        return {}, []
    statements = sqlparse.parse(content)
    counts: dict[str, int] = {
        "statement_count": len(statements),
        "select_count": 0,
        "insert_count": 0,
        "update_count": 0,
        "delete_count": 0,
        "create_count": 0,
        "drop_count": 0,
        "other_count": 0,
    }
    for stmt in statements:
        t = stmt.get_type()
        if t == "SELECT":
            counts["select_count"] += 1
        elif t == "INSERT":
            counts["insert_count"] += 1
        elif t == "UPDATE":
            counts["update_count"] += 1
        elif t == "DELETE":
            counts["delete_count"] += 1
        elif t == "CREATE":
            counts["create_count"] += 1
        elif t == "DROP":
            counts["drop_count"] += 1
        elif t != "UNKNOWN":
            counts["other_count"] += 1
    return counts, []


register_language(
    LanguageProfile(
        name="sql",
        extensions=frozenset({".sql"}),
        metrics_fn=_sql_metrics,
    )
)
