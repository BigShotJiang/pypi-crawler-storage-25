"""YAML language profile."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from kiss.agent.analysis.registry import register_language
from kiss.agent.analysis.types import LanguageProfile
from kiss.agent.tools.result_types import AnalysisIssue, CodeLocation, SourceRange


def _yaml_metrics(content: str, path: Path | None = None):
    try:
        import yaml
    except ImportError:
        return {}, []
    try:
        documents = list(yaml.safe_load_all(content))
    except yaml.YAMLError as exc:
        return {}, [
            AnalysisIssue(
                code="yaml_parse_error",
                message=str(exc),
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "", range=SourceRange(start_line=1)
                ),
            )
        ]

    top_level_keys = mapping_count = sequence_count = max_depth = 0

    def walk(node: Any, depth: int) -> None:
        nonlocal top_level_keys, mapping_count, sequence_count, max_depth
        max_depth = max(max_depth, depth)
        if isinstance(node, dict):
            mapping_count += 1
            if depth == 1:
                top_level_keys += len(node)
            for child in node.values():
                walk(child, depth + 1)
        elif isinstance(node, list):
            sequence_count += 1
            for child in node:
                walk(child, depth + 1)

    for doc in documents:
        if doc is not None:
            walk(doc, 1)

    return {
        "document_count": len(documents),
        "top_level_keys": top_level_keys,
        "mapping_count": mapping_count,
        "sequence_count": sequence_count,
        "max_depth": max_depth,
    }, []


register_language(
    LanguageProfile(
        name="yaml",
        extensions=frozenset({".yaml", ".yml"}),
        metrics_fn=_yaml_metrics,
    )
)
