"""Markdown language profile."""

from __future__ import annotations

import re
from pathlib import Path

from kiss.agent.analysis.registry import register_language
from kiss.agent.analysis.types import LanguageProfile


def _markdown_metrics(content: str, path: Path | None = None):
    lines = content.splitlines()
    return {
        "h1_count": sum(1 for ln in lines if re.match(r"^# ", ln)),
        "h2_count": sum(1 for ln in lines if re.match(r"^## ", ln)),
        "h3_count": sum(1 for ln in lines if re.match(r"^### ", ln)),
        "code_block_count": len(re.findall(r"^```", content, re.MULTILINE)) // 2,
        "link_count": len(re.findall(r"\[([^\]]+)\]\(([^)]+)\)", content)),
        "word_count": len(content.split()),
    }, []


register_language(
    LanguageProfile(
        name="markdown",
        extensions=frozenset({".md", ".markdown"}),
        metrics_fn=_markdown_metrics,
    )
)
