"""TOML language profile."""

from __future__ import annotations

from pathlib import Path

from kiss.agent.analysis.registry import register_language
from kiss.agent.analysis.types import LanguageProfile
from kiss.agent.tools.result_types import AnalysisIssue, CodeLocation, SourceRange


def _toml_metrics(content: str, path: Path | None = None):
    import tomllib

    try:
        data = tomllib.loads(content)
    except tomllib.TOMLDecodeError as exc:
        return {}, [
            AnalysisIssue(
                code="toml_parse_error",
                message=str(exc),
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "", range=SourceRange(start_line=1)
                ),
            )
        ]
    key_count = sum(len(v) if isinstance(v, dict) else 1 for v in data.values())
    table_count = sum(1 for v in data.values() if isinstance(v, dict))
    array_table_count = sum(
        1 for v in data.values() if isinstance(v, list) and v and isinstance(v[0], dict)
    )
    return {
        "top_level_keys": len(data),
        "key_count": key_count,
        "table_count": table_count,
        "array_table_count": array_table_count,
    }, []


register_language(
    LanguageProfile(
        name="toml",
        extensions=frozenset({".toml"}),
        metrics_fn=_toml_metrics,
    )
)
