"""Python language profile."""

from __future__ import annotations

import ast
import json
from pathlib import Path
from typing import Any

from kiss.agent.analysis.registry import register_language
from kiss.agent.analysis.types import LanguageProfile
from kiss.agent.tools.result_types import (
    AnalysisIssue,
    CheckStyleResult,
    CodeLocation,
    SourceRange,
    StyleViolation,
    SymbolInfo,
    ToolResultMeta,
)


_FRESHNESS_STRATEGY = "on_demand_workspace_scan"


class _PythonSymbolCollector(ast.NodeVisitor):
    def __init__(self) -> None:
        self._symbols: list[SymbolInfo] = []
        self._container_stack: list[str] = []

    def _add_symbol(self, name: str, kind: str, node: ast.AST) -> None:
        lineno = getattr(node, "lineno", None)
        end_lineno = getattr(node, "end_lineno", None)
        col = getattr(node, "col_offset", None)
        from kiss.agent.tools.result_types import CodeLocation, SourceRange

        self._symbols.append(
            SymbolInfo(
                name=name,
                kind=kind,
                language="python",
                container_name=self._container_stack[-1]
                if self._container_stack
                else None,
                location=CodeLocation(
                    path="",
                    range=SourceRange(
                        start_line=lineno or 1,
                        end_line=end_lineno,
                        start_col=col or 0,
                    ),
                ),
            )
        )

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self._add_symbol(node.name, "class", node)
        self._container_stack.append(node.name)
        self.generic_visit(node)
        self._container_stack.pop()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._add_symbol(node.name, "function", node)
        self._container_stack.append(node.name)
        self.generic_visit(node)
        self._container_stack.pop()

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._add_symbol(node.name, "function", node)
        self._container_stack.append(node.name)
        self.generic_visit(node)
        self._container_stack.pop()

    def visit_Assign(self, node: ast.Assign) -> None:
        if not self._container_stack:
            for target in node.targets:
                for name in _extract_names(target):
                    self._add_symbol(name, "variable", node)
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        if not self._container_stack:
            for name in _extract_names(node.target):
                self._add_symbol(name, "variable", node)
        self.generic_visit(node)


def _extract_names(node: ast.expr) -> list[str]:
    if isinstance(node, ast.Name):
        return [node.id]
    if isinstance(node, ast.Tuple):
        names: list[str] = []
        for elt in node.elts:
            names.extend(_extract_names(elt))
        return names
    return []


def python_symbols_for_text(
    path: Path, content: str
) -> tuple[list[SymbolInfo], list[Any], list[AnalysisIssue]]:
    try:
        tree = ast.parse(content, filename=str(path))
    except SyntaxError as exc:
        return (
            [],
            [],
            [
                AnalysisIssue(
                    code="syntax_error",
                    message=str(exc),
                    severity="error",
                    location=CodeLocation(
                        path=str(path),
                        range=SourceRange(start_line=exc.lineno or 1),
                    ),
                )
            ],
        )

    collector = _PythonSymbolCollector()
    collector.visit(tree)
    symbols = collector._symbols
    for sym in symbols:
        if sym.location:
            sym.location.path = str(path)
    return symbols, [], []


def _python_metrics(
    content: str, path: Path | None = None
) -> tuple[dict[str, int], list[AnalysisIssue]]:
    symbols, _, issues = python_symbols_for_text(path or Path(""), content)
    return {
        "symbol_count": len(symbols),
        "function_count": sum(1 for s in symbols if s.kind == "function"),
        "class_count": sum(1 for s in symbols if s.kind == "class"),
        "variable_count": sum(1 for s in symbols if s.kind == "variable"),
    }, issues


def _python_style(path: Path, ruleset: str | None) -> CheckStyleResult:
    import shutil
    import subprocess

    if not shutil.which("ruff"):
        return CheckStyleResult(
            path=str(path),
            language="python",
            ruleset=ruleset,
            freshness_strategy=_FRESHNESS_STRATEGY,
            passed=True,
        )

    cmd = ["ruff", "check", "--output-format", "json", str(path)]
    if ruleset:
        cmd.extend(["--config", ruleset])
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)  # nosec B603
    if proc.returncode not in {0, 1}:
        return CheckStyleResult(
            path=str(path),
            language="python",
            ruleset=ruleset,
            freshness_strategy=_FRESHNESS_STRATEGY,
            meta=ToolResultMeta(
                ok=False,
                error_code="execution_failed",
                error_message=proc.stderr.strip() or "ruff check failed",
            ),
        )

    payload = json.loads(proc.stdout or "[]")
    violations = [
        StyleViolation(
            code=item.get("code", "ruff"),
            message=item.get("message", ""),
            severity="warning",
            location=CodeLocation(
                path=item.get("filename", str(path)),
                range=SourceRange(
                    start_line=item.get("location", {}).get("row", 1),
                    start_col=max(item.get("location", {}).get("column", 1) - 1, 0),
                    end_line=item.get("end_location", {}).get("row"),
                    end_col=(
                        max(item.get("end_location", {}).get("column", 1) - 1, 0)
                        if item.get("end_location")
                        else None
                    ),
                ),
            ),
        )
        for item in payload
    ]
    return CheckStyleResult(
        path=str(path),
        language="python",
        ruleset=ruleset,
        freshness_strategy=_FRESHNESS_STRATEGY,
        violations=violations,
        passed=not violations,
    )


register_language(
    LanguageProfile(
        name="python",
        extensions=frozenset({".py"}),
        metrics_fn=_python_metrics,
        symbols_fn=python_symbols_for_text,
        style_checker=_python_style,
    )
)
