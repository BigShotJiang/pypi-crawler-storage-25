"""Decentralized language analysis registry."""

from kiss.agent.analysis.registry import (
    detect_language,
    get_language_profile,
    list_languages,
    register_language,
)
from kiss.agent.analysis.types import LanguageProfile, TsConfig

__all__ = [
    "LanguageProfile",
    "TsConfig",
    "detect_language",
    "get_language_profile",
    "list_languages",
    "register_language",
]
