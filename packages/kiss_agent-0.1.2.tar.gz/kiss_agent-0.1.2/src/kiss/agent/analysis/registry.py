"""Language registry — lazy-discovered LanguageProfile store."""

from __future__ import annotations

import importlib
import logging
import pkgutil
from pathlib import Path

from kiss.agent.analysis.types import LanguageProfile

_LOGGER = logging.getLogger(__name__)

_REGISTRY: dict[str, LanguageProfile] = {}
_EXTENSION_MAP: dict[str, str] = {}
_discovered = False


def register_language(profile: LanguageProfile) -> None:
    """Register a LanguageProfile. Called by each language module at import."""
    _REGISTRY[profile.name] = profile
    for ext in profile.extensions:
        _EXTENSION_MAP[ext] = profile.name
    _LOGGER.debug("Registered language '%s'", profile.name)


def _ensure_discovered() -> None:
    global _discovered
    if _discovered:
        return
    _discovered = True
    languages_path = Path(__file__).parent / "languages"
    pkg_name = "kiss.agent.analysis.languages"
    for finder, module_name, _ in pkgutil.iter_modules([str(languages_path)]):
        full_name = f"{pkg_name}.{module_name}"
        try:
            importlib.import_module(full_name)
        except Exception:
            _LOGGER.warning(
                "Failed to load language module '%s'", full_name, exc_info=True
            )


def get_language_profile(name: str) -> LanguageProfile | None:
    _ensure_discovered()
    return _REGISTRY.get(name)


def detect_language(path: Path) -> str | None:
    """Detect language from file extension. Triggers lazy discovery."""
    _ensure_discovered()
    ext = path.suffix.lower()
    return _EXTENSION_MAP.get(ext)


def list_languages() -> list[LanguageProfile]:
    _ensure_discovered()
    return list(_REGISTRY.values())
