"""LanguageProfile and TsConfig dataclasses."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class TsConfig:
    """Tree-sitter configuration for a language.

    metrics_fn: maps raw node-type counts → final metrics dict.
    """

    language: str
    target_types: frozenset[str]
    metrics_fn: Callable[[dict[str, int]], dict[str, int]] = field(
        default=lambda c: c, compare=False, hash=False
    )


@dataclass(frozen=True)
class LanguageProfile:
    """Declarative language descriptor registered at import time."""

    name: str
    extensions: frozenset[str]
    ts_config: TsConfig | None = field(default=None, compare=False, hash=False)
    metrics_fn: Callable[[str, Path | None], tuple[dict[str, Any], list]] | None = (
        field(default=None, compare=False, hash=False)
    )
    symbols_fn: Callable[..., Any] | None = field(
        default=None, compare=False, hash=False
    )
    style_checker: Callable[..., Any] | None = field(
        default=None, compare=False, hash=False
    )
