"""Core dispatch functions for language analysis.

Provides:
- _get_ts_parser(language): cached tree-sitter parser
- _count_ts_node_types(node, target_types): recursive count
- _ts_metrics(content, ts_config): parse + count via TsConfig
- _analyze_language(language, content, path): dispatch to profile
- _symbols_for_language(language, content, path): dispatch to profile
- _check_style_language(language, path, content, ruleset): dispatch to profile
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from kiss.agent.analysis.registry import get_language_profile
from kiss.agent.analysis.types import TsConfig
from kiss.agent.tools.result_types import AnalysisIssue, CodeLocation, SourceRange

_LOGGER = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Tree-sitter helpers
# ---------------------------------------------------------------------------

_TS_PARSER_CACHE: dict[str, Any] = {}


def _get_ts_parser(language: str) -> Any | None:
    """Return a cached tree-sitter parser for language, or None if unavailable."""
    if language in _TS_PARSER_CACHE:
        return _TS_PARSER_CACHE[language]

    try:
        from tree_sitter import Language, Parser as TSParser

        lang_obj = None
        if language == "javascript":
            import tree_sitter_javascript as tjs

            lang_obj = Language(tjs.language())
        elif language == "typescript":
            import tree_sitter_typescript as tts

            lang_obj = Language(tts.language_typescript())
        elif language == "go":
            import tree_sitter_go as tgo

            lang_obj = Language(tgo.language())
        elif language == "rust":
            import tree_sitter_rust as trs

            lang_obj = Language(trs.language())
        elif language == "bash":
            import tree_sitter_bash as tb

            lang_obj = Language(tb.language())
        elif language == "dockerfile":
            import tree_sitter_dockerfile as tdf

            lang_obj = Language(tdf.language())
        elif language == "hcl":
            import tree_sitter_hcl as thcl

            lang_obj = Language(thcl.language())

        parser = TSParser(lang_obj) if lang_obj is not None else None
    except ImportError:
        parser = None

    _TS_PARSER_CACHE[language] = parser
    return parser


def _count_ts_node_types(node: Any, target_types: set[str]) -> dict[str, int]:
    """Recursively count occurrences of target node types."""
    counts: dict[str, int] = {}

    def walk(n: Any) -> None:
        if n.type in target_types:
            counts[n.type] = counts.get(n.type, 0) + 1
        for child in n.children:
            walk(child)

    walk(node)
    return counts


def _ts_metrics(
    content: str,
    ts_config: TsConfig,
    path: Path | None = None,
) -> tuple[dict[str, Any], list[AnalysisIssue]]:
    """Standard tree-sitter metrics via TsConfig. Returns (metrics, issues)."""
    parser = _get_ts_parser(ts_config.language)
    if parser is None:
        return {}, []

    try:
        tree = parser.parse(
            (content if content.endswith("\n") else content + "\n").encode("utf-8")
        )
    except Exception:
        return {}, []

    raw_counts = _count_ts_node_types(tree.root_node, set(ts_config.target_types))
    metrics = ts_config.metrics_fn(raw_counts)

    issues: list[AnalysisIssue] = []
    if tree.root_node.has_error:
        issues.append(
            AnalysisIssue(
                code="parse_error",
                message=f"{ts_config.language} parse error",
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "",
                    range=SourceRange(start_line=1),
                ),
            )
        )
    return metrics, issues


# ---------------------------------------------------------------------------
# High-level dispatch
# ---------------------------------------------------------------------------


def _analyze_language(
    language: str,
    content: str,
    path: Path | None = None,
) -> tuple[dict[str, Any], list[AnalysisIssue]]:
    """Dispatch analysis to the registered LanguageProfile."""
    profile = get_language_profile(language)
    if profile is None:
        return {}, []

    if profile.ts_config is not None:
        return _ts_metrics(content, profile.ts_config, path)

    if profile.metrics_fn is not None:
        return profile.metrics_fn(content, path)

    return {}, []


def _symbols_for_language(
    language: str,
    path: Path,
    content: str,
) -> tuple[list, list]:
    """Dispatch symbol extraction to the registered LanguageProfile."""

    profile = get_language_profile(language)
    if profile is None or profile.symbols_fn is None:
        # Fallback: try JSON document symbols for structured files
        from kiss.agent.analysis.languages import json_ as _json_lang

        return _json_lang.json_document_symbols(path, content)

    result = profile.symbols_fn(path, content)
    # symbols_fn for python returns (symbols, raw_symbols, issues)
    if len(result) == 3:
        return result[0], result[2]
    return result[0], result[1]


def _check_style_language(
    language: str,
    path: Path,
    content: str,
    ruleset: str | None = None,
) -> Any | None:
    """Dispatch style checking to the registered LanguageProfile. Returns None if no checker."""
    profile = get_language_profile(language)
    if profile is None or profile.style_checker is None:
        return None
    return profile.style_checker(path, ruleset)
