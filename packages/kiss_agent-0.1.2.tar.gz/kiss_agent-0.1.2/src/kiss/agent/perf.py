"""Small performance helpers for agent-turn timing."""

from __future__ import annotations

import time
from contextlib import asynccontextmanager, nullcontext
from typing import Any, AsyncIterator

from kiss.core.tracing import SessionTracer


@asynccontextmanager
async def perf_log(
    tracer: SessionTracer | None,
    span_name: str = "agent.turn",
    **attrs: Any,
) -> AsyncIterator[None]:
    """Wrap one agent turn in a span and emit a completion event with elapsed_ms."""
    start = time.monotonic()
    with tracer.span(span_name, **attrs) if tracer else nullcontext():
        try:
            yield
        finally:
            elapsed_ms = (time.monotonic() - start) * 1000
            if tracer is not None:
                tracer.event("agent.turn.completed", elapsed_ms=elapsed_ms)


def format_turn_metrics(tracer: SessionTracer | None) -> str | None:
    """Return a one-line perf summary for the most recently finished agent.turn span."""
    if tracer is None:
        return None
    _, finished = tracer.get_live_snapshot()
    turn_span = next((s for s in reversed(finished) if s.name == "agent.turn"), None)
    if turn_span is None:
        return None

    span_ctx = turn_span.get_span_context()
    assert span_ctx is not None
    turn_id = span_ctx.span_id
    turn_ms = ((turn_span.end_time or 0) - (turn_span.start_time or 0)) / 1_000_000

    children = [
        s
        for s in finished
        if getattr(getattr(s, "parent", None), "span_id", None) == turn_id
    ]

    llm_spans = [s for s in children if s.name.startswith("chat ")]
    tool_spans = [s for s in children if s.name.startswith("tool.")]

    parts: list[str] = [f"⏱ {turn_ms:.0f}ms"]

    if llm_spans:
        total_llm = sum(
            ((s.end_time or 0) - (s.start_time or 0)) / 1_000_000 for s in llm_spans
        )
        parts.append(f"LLM {len(llm_spans)}×{total_llm / len(llm_spans):.0f}ms")

    seen: dict[str, float] = {}
    for s in tool_spans:
        dur = ((s.end_time or 0) - (s.start_time or 0)) / 1_000_000
        name = s.name.removeprefix("tool.")
        seen[name] = seen.get(name, 0) + dur
    for name, dur in seen.items():
        parts.append(f"{name} {dur:.0f}ms")

    return " | ".join(parts)
