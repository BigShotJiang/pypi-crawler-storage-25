"""Permission policy for agent tool execution.

Sole import point for kiss.core.permission_policy within kiss.agent.
Tool implementations and callbacks import from here, never from core directly.
"""

from __future__ import annotations

import shlex
from pathlib import Path

from kiss.core.permission_policy import (
    PermissionPolicy,
    evaluate_tool_policy as evaluate_tool_policy,  # re-exported: callers import from here
    role_allows_tool,
)
from kiss.core.types import PermissionAction

_SENSITIVE_FILE_NAMES = {
    ".env",
    ".env.local",
    ".envrc",
    "id_rsa",
    "id_ed25519",
    "credentials",
    "credentials.json",
}

_GENERATED_DIRS = {"build", "dist", "out"}

_EXACT_ONLY_COMMANDS = {
    "curl",
    "git",
    "mv",
    "npm",
    "pip",
    "python",
    "python3",
    "rm",
    "sh",
    "uv",
}

_MUTATING_GIT_SUBCOMMANDS = {"push", "reset", "checkout", "switch", "clean"}
_MUTATING_UV_SUBCOMMANDS = {"add", "remove", "sync", "pip", "tool"}


def _is_outside_workspace(path: str, workspace_root: Path | None) -> bool:
    if workspace_root is None:
        return False
    try:
        Path(path).resolve().relative_to(workspace_root.resolve())
        return False
    except ValueError:
        return True


def _is_inside_workspace(path: Path, workspace_root: Path) -> bool:
    try:
        path.resolve().relative_to(workspace_root.resolve())
        return True
    except ValueError:
        return False


def _file_requires_exact(path: Path, workspace_root: Path) -> bool:
    resolved = path.resolve()
    workspace_root = workspace_root.resolve()
    if not _is_inside_workspace(resolved, workspace_root):
        return True
    if path.name in _SENSITIVE_FILE_NAMES:
        return True
    return any(
        part in _GENERATED_DIRS for part in resolved.relative_to(workspace_root).parts
    )


def file_write_action(
    tool_name: str, path: str, workspace_root: Path
) -> PermissionAction:
    resolved = Path(path).resolve()
    exact_only = _file_requires_exact(resolved, workspace_root)
    target = str(resolved)
    scope_key = None if exact_only else "file_write:workspace"
    if exact_only:
        message = f"{tool_name} exact path: {target}"
    else:
        message = (
            f"{tool_name} workspace file: {target}\n"
            "Allow scope permits workspace file writes for this session."
        )
    return PermissionAction(
        tool_name=tool_name,
        kind="file_write",
        target=target,
        message=message,
        exact_key=f"file_write:{tool_name}:{target}",
        scope_key=scope_key,
        exact_only=exact_only,
        policy_candidates=(target,),
    )


def _shell_requires_exact(args: list[str]) -> bool:
    if not args:
        return True
    executable = Path(args[0]).name
    if executable in _EXACT_ONLY_COMMANDS:
        if executable == "git" and len(args) > 1:
            return args[1] in _MUTATING_GIT_SUBCOMMANDS
        if executable == "uv" and len(args) > 1:
            return args[1] in _MUTATING_UV_SUBCOMMANDS
        return True
    return False


def shell_command_action(command: str) -> PermissionAction:
    try:
        args = shlex.split(command)
    except ValueError:
        args = []
    exact_only = _shell_requires_exact(args)
    executable = Path(args[0]).name if args else "shell"
    candidates = _shell_policy_candidates(args, command)
    scope_key = None if exact_only else f"shell_command:{executable}"
    if exact_only:
        message = f"run_bash exact command: {command}"
    else:
        message = (
            f"run_bash command: {command}\n"
            f"Allow scope permits future {executable!r} commands this session."
        )
    return PermissionAction(
        tool_name="run_bash",
        kind="shell_command",
        target=command,
        message=message,
        exact_key=f"shell_command:{command}",
        scope_key=scope_key,
        exact_only=exact_only,
        policy_candidates=candidates,
    )


def git_read_action(tool_name: str, repo_path: str) -> PermissionAction:
    target = str(Path(repo_path).resolve())
    return PermissionAction(
        tool_name=tool_name,
        kind="shell_command",
        target=target,
        message=(
            f"{tool_name} repository: {target}\n"
            "Allow scope permits read-only git inspection for this repository this session."
        ),
        exact_key=f"git_read:{tool_name}:{target}",
        scope_key=f"git_read:{target}",
        exact_only=False,
        default_allow=True,
        policy_candidates=(target,),
    )


def git_write_action(tool_name: str, repo_path: str) -> PermissionAction:
    target = str(Path(repo_path).resolve())
    return PermissionAction(
        tool_name=tool_name,
        kind="shell_command",
        target=target,
        message=f"{tool_name} exact repository write: {target}",
        exact_key=f"git_write:{tool_name}:{target}",
        scope_key=None,
        exact_only=True,
        policy_candidates=(target,),
    )


def tool_access_action(
    tool_name: str,
    target: str,
    *,
    message: str | None = None,
    policy_candidates: tuple[str, ...] = (),
) -> PermissionAction:
    return PermissionAction(
        tool_name=tool_name,
        kind="tool_access",
        target=target,
        message=message or f"{tool_name} access: {target}",
        exact_key=f"tool_access:{tool_name}:{target}",
        scope_key=f"tool_access:{tool_name}",
        exact_only=False,
        default_allow=True,
        policy_candidates=policy_candidates or (target,),
    )


def filter_tools_for_role(
    tools: list,
    *,
    role: str | None,
    policy: PermissionPolicy | None,
) -> list:
    return [
        tool
        for tool in tools
        if role_allows_tool(policy, role, getattr(tool, "__name__", str(tool)))
    ]


def _shell_policy_candidates(args: list[str], command: str) -> tuple[str, ...]:
    if not args:
        return (command,)
    executable = Path(args[0]).name
    candidates = [command, executable]
    if len(args) > 1:
        candidates.append(f"{executable} {args[1]}")
    return tuple(candidates)
