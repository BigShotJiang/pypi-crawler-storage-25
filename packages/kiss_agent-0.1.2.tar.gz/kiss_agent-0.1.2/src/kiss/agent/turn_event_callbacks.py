"""Per-turn event/callback bridge for KissAgent."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any, Literal, Protocol

from kiss.core.deps import AgentDeps
from kiss.providers.normalization import LLMResponseChunk
from kiss.core.types import (
    AskUserReply,
    AskUserRequest,
    Event,
    EventKind,
    PermissionAction,
    PermissionReply,
    PermissionRequest,
    ToolCallState,
    ToolResultState,
)
from kiss.ui.shared import create_tool_result_display

if TYPE_CHECKING:
    from kiss.core.permission_policy import PermissionPolicy


_READ_ONLY_TOOLS: frozenset[str] = frozenset(
    {
        "read_file",
        "search_code",
        "glob",
        "list_directory",
        "fetch_url",
        "analyze_code",
        "check_style",
        "find_definition",
        "find_references",
        "document_symbols",
        "workspace_symbols",
        "git_status",
        "git_diff",
        "git_log",
        "memory_read",
        "list_todos",
        "read_team_messages",
        "expand_ref",
        "web_search",
        "self_compact",
    }
)

_MUTATION_TOOLS: frozenset[str] = frozenset(
    {
        "write_file",
        "edit_file",
        "apply_patch",
        "run_bash",
        "run_python",
        "git_stage",
        "git_commit",
    }
)

# Tools that don't mutate state but also shouldn't count as file reads for the
# consecutive-read nudge. Excluded from side_effect_seen so context-overflow
# retry is not blocked after a mid-turn user question. Must stay disjoint from
# _MUTATION_TOOLS — any tool that both interacts and mutates belongs in
# _MUTATION_TOOLS, never here.
_INTERACTION_TOOLS: frozenset[str] = frozenset({"ask_user"})

assert _INTERACTION_TOOLS.isdisjoint(_MUTATION_TOOLS), (
    "_INTERACTION_TOOLS and _MUTATION_TOOLS must be disjoint — "
    "interaction tools must not mutate state or context-overflow retry may fire incorrectly"
)


class _BridgeOwner(Protocol):
    permission_policy: PermissionPolicy
    _allowed_tools: set[str]
    _allowed_cmds: set[tuple[str, str]]
    _allowed_exact: set[str]
    _allowed_scopes: set[str]
    _last_tool_name: str
    _turns_since_compact: int
    _lifecycle_state: Any


class TurnEventCallbacks:
    """Owns per-turn callbacks and their transient state."""

    def __init__(
        self,
        *,
        owner: _BridgeOwner,
        event_queue: asyncio.Queue[Event | None],
    ) -> None:
        self._owner = owner
        self._event_queue = event_queue
        self._deps: AgentDeps | None = None
        self._last_tool_name = ""
        self._side_effect_seen = False
        self._ask_user_active = False
        self._thought_id_seq = 0
        self._current_thought_id: str | None = None
        self._pending_typed_display: Any = None
        self._saw_text_chunk = False
        self._permission_lock = asyncio.Lock()

    @property
    def side_effect_seen(self) -> bool:
        return self._side_effect_seen

    @property
    def saw_text_chunk(self) -> bool:
        return self._saw_text_chunk

    def reset_stream_state(self) -> None:
        self._saw_text_chunk = False
        self._current_thought_id = None

    def attach_deps(self, deps: AgentDeps) -> None:
        self._deps = deps
        deps.on_tool_use = self.on_tool_use
        deps.on_tool_result = self.on_tool_result
        deps.on_typed_tool_result = self.on_typed_tool_result
        deps.on_stuck_loop = self.on_stuck_loop
        deps.on_thought = self.on_thought
        deps.on_ask_user = self.on_ask_user
        deps.on_event = self.on_event
        deps.on_logic_approval = self.on_logic_approval

    def _require_deps(self) -> AgentDeps:
        if self._deps is None:
            raise RuntimeError("AgentDeps not initialized for turn-event bridge.")
        return self._deps

    async def on_tool_use(self, name: str, args: dict[str, Any]) -> None:
        deps = self._require_deps()
        self._last_tool_name = name
        self._owner._last_tool_name = name
        deps.last_tool_name = name
        deps.tool_activity.append(f"CALL {name} {args}")
        if name not in _READ_ONLY_TOOLS and name not in _INTERACTION_TOOLS:
            self._side_effect_seen = True
        await self._event_queue.put(
            Event(
                kind=EventKind.TOOL_CALL,
                call=ToolCallState(id="", name=name, args=str(args)),
            )
        )

    async def confirm_permission(self, prompt: str | PermissionAction) -> bool:
        deps = self._require_deps()
        tool = self._last_tool_name
        if isinstance(prompt, PermissionAction):
            tool = prompt.tool_name
            from kiss.agent.permissions import evaluate_tool_policy

            decision = evaluate_tool_policy(
                self._owner.permission_policy,
                prompt.tool_name,
                prompt.policy_candidates,
            )
            if decision == "deny":
                return False
            if prompt.scope_key and prompt.scope_key in self._owner._allowed_scopes:
                return True
            if prompt.exact_key in self._owner._allowed_exact:
                return True
            if decision == "allow" or prompt.default_allow:
                return True
            req = PermissionRequest(
                tool_name=tool,
                args=prompt.message,
                action=prompt,
                metadata={
                    "kind": prompt.kind,
                    "target": prompt.target,
                    "scope_key": prompt.scope_key or "",
                    "exact_key": prompt.exact_key,
                    "role": deps.agent_label,
                },
            )
        else:
            prompt_text = prompt
            if (
                tool in self._owner._allowed_tools
                or (tool, prompt_text) in self._owner._allowed_cmds
            ):
                return True
            req = PermissionRequest(tool_name=tool, args=prompt_text)
        async with self._permission_lock:
            await self._event_queue.put(
                Event(kind=EventKind.PERMISSION, permission=req)
            )
            reply = await req.reply_future
            if isinstance(prompt, PermissionAction):
                if (
                    reply == PermissionReply.ALLOW_TOOL
                    and prompt.scope_key
                    and not prompt.exact_only
                ):
                    self._owner._allowed_scopes.add(prompt.scope_key)
                elif reply in (PermissionReply.ALLOW_CMD, PermissionReply.ALLOW_TOOL):
                    self._owner._allowed_exact.add(prompt.exact_key)
            else:
                if reply == PermissionReply.ALLOW_TOOL:
                    self._owner._allowed_tools.add(tool)
                elif reply == PermissionReply.ALLOW_CMD:
                    self._owner._allowed_cmds.add((tool, prompt_text))
            if reply == PermissionReply.DENY:
                deps.stuck_loop_tracker.block_last_pending(tool)
                return False
            return True

    async def on_typed_tool_result(self, name: str, result: Any) -> None:
        from kiss.ui.renderers import get_renderer_registry

        self._pending_typed_display = get_renderer_registry().render(name, result)

    async def on_tool_result(
        self, name: str, output: str, call_id: str, is_err: bool
    ) -> None:
        deps = self._require_deps()
        preview = output.strip()
        if len(preview) > 500:
            preview = preview[:500] + "..."
        status = "ERROR" if is_err else "OK"
        deps.tool_activity.append(f"RESULT {name} {status}\n{preview}")
        display: Any = self._pending_typed_display
        self._pending_typed_display = None
        if display is None:
            display = create_tool_result_display(name, output, is_err=is_err)
        path = display.file_changes[0].path if display.file_changes else None
        if not is_err:
            if name in _MUTATION_TOOLS or bool(display.file_changes):
                self._owner._lifecycle_state.mark_mutation()
            elif name in _READ_ONLY_TOOLS:
                self._owner._lifecycle_state.mark_read()
        await self._event_queue.put(
            Event(
                kind=EventKind.TOOL_RESULT,
                result=ToolResultState(
                    call_id=call_id,
                    name=name,
                    output=output,
                    is_err=is_err,
                    path=path,
                    truncation_meta=display.truncation_meta,
                    display=display,
                ),
            )
        )

    async def on_stuck_loop(
        self, message: str, severity: Literal["warn", "error"]
    ) -> None:
        await self._event_queue.put(
            Event(
                kind=EventKind.STUCK_LOOP,
                info=message,
                severity=severity,
            )
        )

    async def on_chunk(self, chunk: LLMResponseChunk) -> None:
        self._current_thought_id = None
        text = chunk.content or ""
        if text:
            self._saw_text_chunk = True
        await self._event_queue.put(Event(kind=EventKind.TOKEN, token=text))

    async def on_thought(self, delta: str, agent: str) -> None:
        if self._current_thought_id is None:
            self._thought_id_seq += 1
            self._current_thought_id = (
                f"th-{self._owner._turns_since_compact + 1}-{self._thought_id_seq}"
            )
        phase = self._deps.turn_phase.name.lower() if self._deps else None
        await self._event_queue.put(
            Event(
                kind=EventKind.THINKING,
                thought=delta,
                agent_label=agent,
                thought_id=self._current_thought_id,
                phase=phase,
            )
        )

    async def on_ask_user(self, req: AskUserRequest) -> AskUserReply:
        if self._ask_user_active:
            await self._event_queue.put(
                Event(
                    kind=EventKind.INFO,
                    info=(
                        "[ASK_USER REJECTED] Second question rejected while "
                        "one is already active. Only one active question is "
                        "supported per turn."
                    ),
                )
            )
            return AskUserReply(outcome="cancelled")
        self._ask_user_active = True
        try:
            await self._event_queue.put(Event(kind=EventKind.ASK_USER, ask_user=req))
            return await req.reply_future
        finally:
            self._ask_user_active = False

    async def on_event(self, event: Event) -> None:
        await self._event_queue.put(event)

    async def on_logic_approval(self, req: Any) -> Any:
        from kiss.agent.tools.logic.approval import LogicApprovalReply

        await self._event_queue.put(
            Event(kind=EventKind.LOGIC_APPROVAL, logic_approval=req)
        )
        try:
            return await req.reply_future
        except asyncio.CancelledError:
            return LogicApprovalReply(approved=False)
