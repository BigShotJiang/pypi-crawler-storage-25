"""Top-level per-turn orchestration for KissAgent."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from pathlib import Path
from typing import Any, Protocol

from mirascope import llm

from kiss.agent.compaction import (
    estimate_history_tokens,
    message_tokens,
    prune_error_outputs,
)
from kiss.agent.context_refs import resolve_message_context_refs
from kiss.agent.overflow import classify_context_overflow_error
from kiss.agent.perf import format_turn_metrics, perf_log
from kiss.agent.plan_types import CompletionResult, PlanResult, TurnPhase
from kiss.agent.turn_engine import (
    _extract_claimed_paths_from_task,
    _is_file_write_task,
    _snapshot_paths,
    _verified_file_write,
)
from kiss.agent.turn_event_callbacks import TurnEventCallbacks
from kiss.core.deps import AgentDeps
from kiss.core.types import Event, EventKind, TurnUsage
from kiss.core.settings import Settings, get_context_window


_MAX_PLAN_APPROVAL_CYCLES = 5

_ROLE_LABELS: dict[str, str] = {
    "system": "System",
    "user": "User",
    "assistant": "Assistant",
    "tool": "Tools",
}


class _TurnOwner(Protocol):
    settings: Settings
    workspace_root: Path
    history: list[Any]
    todos: list[Any]
    team_messages: list[Any]
    tracer: Any
    session_manager: Any
    permission_policy: Any
    compaction_manager: Any
    _phase_manager: Any
    _plan_approval: Any
    _current_tool_set: Any
    _turn_phase: TurnPhase
    _pending_recovery_notice: str | None
    _headless_mode: bool
    _turns_since_compact: int
    _current_turn_engine: Any

    async def _compact_history(
        self,
        reason: str,
        event_queue: asyncio.Queue[Event | None],
        deps: AgentDeps,
    ) -> None: ...

    def refresh_turn_engine(self, phase: TurnPhase) -> None: ...


class TurnOrchestrator:
    """Runs a single turn after `send()` sets up the event stream."""

    def __init__(
        self,
        *,
        owner: _TurnOwner,
        capability_hint_error: Callable[..., RuntimeError | None],
    ) -> None:
        self._owner = owner
        self._capability_hint_error = capability_hint_error

    async def run(
        self,
        *,
        message: str,
        event_queue: asyncio.Queue[Event | None],
        bridge: TurnEventCallbacks,
    ) -> None:
        window = get_context_window(
            self._owner.settings.model_id,
            self._owner.settings.context_window,
        )
        deps: AgentDeps | None = None
        retry_count = 0
        try:
            phase_resolution = await self._owner._phase_manager.resolve(
                message=message,
                current_phase=self._owner._turn_phase,
                headless=self._owner._headless_mode,
                on_ask_user=bridge.on_ask_user,
                on_event=bridge.on_event,
            )
            self._owner._current_tool_set = phase_resolution.tool_set
            self._owner._turn_phase = phase_resolution.phase

            control_only_confirmation = phase_resolution.control_only_confirmation
            if control_only_confirmation is not None:
                self._owner.history = [
                    *self._owner.history,
                    llm.messages.user(message),
                    llm.messages.assistant(
                        control_only_confirmation,
                        model_id=None,
                        provider_id=None,
                    ),
                ]
                self._owner.session_manager.append_turn(
                    "assistant", control_only_confirmation
                )
                self._owner._turns_since_compact += 1
                await event_queue.put(
                    Event(kind=EventKind.TOKEN, token=control_only_confirmation)
                )
                await event_queue.put(
                    Event(kind=EventKind.DONE, turn_usage=TurnUsage())
                )
                return

            resolved_context_refs = resolve_message_context_refs(
                message=phase_resolution.cleaned_message,
                repo_root=self._owner.workspace_root,
            )
            user_message = resolved_context_refs.injected_message
            if self._owner._pending_recovery_notice:
                user_message = (
                    f"{self._owner._pending_recovery_notice}\n\n{user_message}"
                )
                self._owner._pending_recovery_notice = None
            messages = self._owner.history + [llm.messages.user(user_message)]

            deps = AgentDeps(
                context_window=window,
                current_usage_tokens=estimate_history_tokens(messages),
                confirm_permission=bridge.confirm_permission,
                resolved_refs=resolved_context_refs.refs,
                workspace_root=self._owner.workspace_root,
                web_search_config=self._owner.settings.web_search,
                permission_policy=self._owner.permission_policy,
                tracer=self._owner.tracer,
                session_dir=self._owner.session_manager.sessions_dir,
                stuck_loop_warn_threshold=self._owner.settings.stuck_loop_warn_threshold,
                stuck_loop_abort_threshold=self._owner.settings.stuck_loop_abort_threshold,
                memory_enabled=self._owner.settings.memory_enabled,
                turn_phase=self._owner._turn_phase,
            )
            bridge.attach_deps(deps)
            deps.todos = self._owner.todos
            deps.team_messages = self._owner.team_messages
            self._owner.refresh_turn_engine(self._owner._turn_phase)
            reserve_tokens = deps.response_token_reserve
            task = phase_resolution.cleaned_message
            pre_snapshot: dict[str, int] | None = None
            if _is_file_write_task(task):
                claimed = _extract_claimed_paths_from_task(task)
                if claimed:
                    pre_snapshot = _snapshot_paths(claimed, self._owner.workspace_root)
            while True:
                bridge.reset_stream_state()
                if deps.current_usage_tokens + reserve_tokens > window:
                    await self._owner._compact_history(
                        "reserved output", event_queue, deps
                    )
                    messages = self._owner.history + [llm.messages.user(user_message)]
                    deps.current_usage_tokens = estimate_history_tokens(messages)

                try:
                    async with perf_log(
                        self._owner.tracer,
                        "agent.turn",
                        task_type=self._owner._current_tool_set,
                    ):
                        if self._owner._current_turn_engine is None:
                            raise RuntimeError("TurnEngine not initialized for turn.")
                        result = await self._owner._current_turn_engine.run(
                            deps=deps,
                            history=messages,
                            on_chunk=bridge.on_chunk,
                            agent_label="kiss-agent",
                        )
                        plan_cycles = 0
                        while isinstance(result, PlanResult):
                            plan_cycles += 1
                            if plan_cycles > _MAX_PLAN_APPROVAL_CYCLES:
                                raise RuntimeError(
                                    f"Plan approval loop exceeded {_MAX_PLAN_APPROVAL_CYCLES} "
                                    "cycles without resolving. The agent is stuck in a repeated "
                                    "plan-deny cycle. Cancel and try a different approach."
                                )
                            self._owner.history = list(messages)
                            result = await self._owner._plan_approval.resolve(
                                result,
                                deps,
                                bridge.on_chunk,
                            )
                        if not isinstance(result, CompletionResult):
                            raise RuntimeError("Unexpected planner result type.")

                        reset_occurred = False
                        if (
                            deps.reset_plan_requested
                            and self._owner._current_turn_engine is not None
                        ):
                            deps.reset_plan_requested = False
                            deps.stuck_loop_tracker.reset()
                            reset_occurred = True
                            self._owner.refresh_turn_engine(TurnPhase.RESEARCH)
                            reset_history = list(result.messages) + [
                                llm.messages.user(
                                    "[PLAN RESET] Your previous strategy was stuck in a "
                                    "repeated alternating loop. Re-research the problem "
                                    "and determine a new approach before acting."
                                )
                            ]
                            result = await self._owner._current_turn_engine.run(
                                deps=deps,
                                history=reset_history,
                                on_chunk=bridge.on_chunk,
                                agent_label="kiss-agent",
                            )
                            if isinstance(result, PlanResult):
                                result = await self._owner._plan_approval.resolve(
                                    result, deps, bridge.on_chunk
                                )
                            if not isinstance(result, CompletionResult):
                                raise RuntimeError(
                                    "Unexpected planner result type after plan reset."
                                )

                        if (
                            not reset_occurred
                            and not deps.writes_approved
                            and _is_file_write_task(task)
                        ):
                            verified, claimed_paths = _verified_file_write(
                                task,
                                deps.tool_activity,
                                self._owner.workspace_root,
                                pre_snapshot,
                            )
                            if (
                                not verified
                                and self._owner._current_turn_engine is not None
                            ):
                                hint = (
                                    f" Expected: {', '.join(claimed_paths)}."
                                    if claimed_paths
                                    else ""
                                )
                                recovery_msg = (
                                    "You indicated you would write or create files, "
                                    "but no file write was confirmed."
                                    f"{hint} Please complete the operation now."
                                )
                                recovery = await self._owner._current_turn_engine.run(
                                    deps=deps,
                                    history=list(result.messages)
                                    + [llm.messages.user(recovery_msg)],
                                    on_chunk=bridge.on_chunk,
                                    agent_label="kiss-agent",
                                )
                                if isinstance(recovery, PlanResult):
                                    recovery = await self._owner._plan_approval.resolve(
                                        recovery, deps, bridge.on_chunk
                                    )
                                if isinstance(recovery, CompletionResult):
                                    result = recovery

                        final_text = result.text
                        new_history = result.messages
                        usage = result.usage
                        finish_reason = result.finish_reason
                except Exception as exc:
                    classification = classify_context_overflow_error(exc)
                    if (
                        classification.is_overflow
                        and retry_count < 1
                        and not bridge.side_effect_seen
                    ):
                        retry_count += 1
                        reason = (
                            classification.matched_reason
                            or classification.provider_error_type
                            or type(exc).__name__
                        )
                        await self._owner._compact_history(
                            f"self-healing retry after context overflow ({reason})",
                            event_queue,
                            deps,
                        )
                        messages = self._owner.history + [
                            llm.messages.user(user_message)
                        ]
                        deps.current_usage_tokens = estimate_history_tokens(messages)
                        deps.compact_requested = None
                        continue
                    hint_error = self._capability_hint_error(
                        exc,
                        model_label=self._owner.settings.model,
                        side_effect_seen=bridge.side_effect_seen,
                    )
                    if hint_error is not None:
                        raise hint_error from exc
                    raise

                if final_text and not bridge.saw_text_chunk:
                    await event_queue.put(Event(kind=EventKind.TOKEN, token=final_text))
                self._owner.history = list(new_history)
                self._owner._turns_since_compact += 1

                pruned = prune_error_outputs(self._owner.history)
                if pruned > 0:
                    await event_queue.put(
                        Event(
                            kind=EventKind.INFO,
                            info=f"Pruned {pruned} error tool output{'s' if pruned != 1 else ''}",
                        )
                    )

                raw: dict[str, int] = {}
                for item in self._owner.history:
                    label = _ROLE_LABELS.get(getattr(item, "role", ""), "Other")
                    raw[label] = raw.get(label, 0) + message_tokens(item)

                if usage is not None and usage.input_tokens > 0:
                    total_raw = sum(raw.values()) or 1
                    budget: dict[str, int] = {
                        label: max(1, round(value * usage.input_tokens / total_raw))
                        for label, value in raw.items()
                    }
                else:
                    budget = raw

                turn_usage = TurnUsage(
                    message_budget=budget, finish_reason=finish_reason
                )
                if usage is not None:
                    turn_usage = TurnUsage(
                        input_tokens=usage.input_tokens,
                        output_tokens=usage.output_tokens,
                        cache_read_tokens=usage.cache_read_tokens,
                        cache_write_tokens=usage.cache_write_tokens,
                        message_budget=budget,
                        finish_reason=finish_reason,
                        thinking_tokens=getattr(usage, "reasoning_tokens", 0),
                    )
                compacted_this_turn = False
                if deps.compact_requested:
                    await self._owner._compact_history(
                        f"self-compaction requested ({deps.compact_requested})",
                        event_queue,
                        deps,
                    )
                    compacted_this_turn = True
                    deps.compact_requested = None

                needs_compact, compact_reason = (
                    self._owner.compaction_manager.should_compact(
                        self._owner.history, window, self._owner._turns_since_compact
                    )
                )
                if needs_compact and not compacted_this_turn:
                    await self._owner._compact_history(
                        compact_reason,
                        event_queue,
                        deps,
                    )

                if final_text:
                    self._owner.session_manager.append_turn("assistant", final_text)
                metrics = format_turn_metrics(self._owner.tracer)
                if metrics:
                    await event_queue.put(Event(kind=EventKind.INFO, info=metrics))
                await event_queue.put(Event(kind=EventKind.DONE, turn_usage=turn_usage))
                break

        except asyncio.CancelledError:
            await event_queue.put(Event(kind=EventKind.CANCELLED))
        except Exception as exc:
            await event_queue.put(Event(kind=EventKind.ERROR, error=exc))
        finally:
            await event_queue.put(None)
