"""Structured git tools."""

from __future__ import annotations

import asyncio
import contextlib
from pathlib import Path
import re

from kiss.agent.tools.result_types import (
    GitCommitResult,
    GitDiffResult,
    GitLogEntry,
    GitLogResult,
    GitStageResult,
    GitStatusEntry,
    GitStatusResult,
    ToolResultMeta,
)

_MAX_GIT_DIFF_CHARS = 100_000
_TRUNCATION_MARKER = "\n... [truncated] ...\n"
_MAX_COMMIT_MESSAGE_LEN = 70
_COMMIT_SUBJECT_RE = re.compile(
    r"^(feat|fix|refactor|docs|test|chore|perf|ci|build|style|revert): [^\n]+$"
)
_GIT_TIMEOUT_SECONDS = 30.0


async def git_status(repo_path: str | Path = ".") -> GitStatusResult:
    repo = Path(repo_path).resolve()
    root, meta = await _git_repo_root(repo)
    if meta is not None:
        return GitStatusResult(repo_path=str(repo), repo_root=root, meta=meta)

    result = await _run_git(
        repo, "status", "--short", "--branch", "--untracked-files=all"
    )
    if result.meta is not None:
        return GitStatusResult(repo_path=str(repo), repo_root=root, meta=result.meta)

    branch, detached, ahead, behind, entries = _parse_status_output(result.stdout)
    return GitStatusResult(
        repo_path=str(repo),
        repo_root=root,
        branch=branch,
        detached=detached,
        ahead=ahead,
        behind=behind,
        entries=entries,
    )


async def git_diff(
    repo_path: str | Path = ".",
    *,
    staged: bool = False,
    max_chars: int = _MAX_GIT_DIFF_CHARS,
) -> GitDiffResult:
    repo = Path(repo_path).resolve()
    root, meta = await _git_repo_root(repo)
    if meta is not None:
        return GitDiffResult(
            repo_path=str(repo), repo_root=root, staged=staged, meta=meta
        )

    args = ["diff", "--no-ext-diff", "--submodule=short"]
    if staged:
        args.append("--cached")
    result = await _run_git(repo, *args)
    if result.meta is not None:
        return GitDiffResult(
            repo_path=str(repo), repo_root=root, staged=staged, meta=result.meta
        )

    diff, truncated = _truncate_text(result.stdout, max_chars)
    return GitDiffResult(
        repo_path=str(repo),
        repo_root=root,
        staged=staged,
        truncated=truncated,
        diff=diff,
    )


async def git_log(repo_path: str | Path = ".", *, limit: int = 10) -> GitLogResult:
    repo = Path(repo_path).resolve()
    root, meta = await _git_repo_root(repo)
    if meta is not None:
        return GitLogResult(repo_path=str(repo), repo_root=root, limit=limit, meta=meta)

    bounded_limit = max(1, min(limit, 50))
    result = await _run_git(
        repo,
        "log",
        f"-n{bounded_limit}",
        "--format=%H%x1f%an%x1f%ae%x1f%ct%x1f%s",
    )
    if result.meta is not None:
        return GitLogResult(
            repo_path=str(repo), repo_root=root, limit=bounded_limit, meta=result.meta
        )

    commits = _parse_log_output(result.stdout)
    return GitLogResult(
        repo_path=str(repo),
        repo_root=root,
        limit=bounded_limit,
        truncated=len(commits) > bounded_limit,
        commits=commits,
    )


async def git_stage(repo_path: str | Path = ".", *, paths: list[str]) -> GitStageResult:
    repo = Path(repo_path).resolve()
    root, meta = await _git_repo_root(repo)
    if meta is not None:
        return GitStageResult(
            repo_path=str(repo), repo_root=root, operation="stage", meta=meta
        )

    normalized_paths, error = _normalize_paths(paths)
    if error is not None:
        return GitStageResult(
            repo_path=str(repo),
            repo_root=root,
            operation="stage",
            meta=error,
        )

    result = await _run_git(repo, "add", "--", *normalized_paths)
    if result.meta is not None:
        return GitStageResult(
            repo_path=str(repo),
            repo_root=root,
            operation="stage",
            path_count=len(normalized_paths),
            affected_paths=normalized_paths,
            meta=result.meta,
        )
    return GitStageResult(
        repo_path=str(repo),
        repo_root=root,
        operation="stage",
        path_count=len(normalized_paths),
        affected_paths=normalized_paths,
    )


async def git_unstage(
    repo_path: str | Path = ".", *, paths: list[str]
) -> GitStageResult:
    repo = Path(repo_path).resolve()
    root, meta = await _git_repo_root(repo)
    if meta is not None:
        return GitStageResult(
            repo_path=str(repo), repo_root=root, operation="unstage", meta=meta
        )

    normalized_paths, error = _normalize_paths(paths)
    if error is not None:
        return GitStageResult(
            repo_path=str(repo),
            repo_root=root,
            operation="unstage",
            meta=error,
        )

    result = await _run_git(repo, "restore", "--staged", "--", *normalized_paths)
    if result.meta is not None:
        return GitStageResult(
            repo_path=str(repo),
            repo_root=root,
            operation="unstage",
            path_count=len(normalized_paths),
            affected_paths=normalized_paths,
            meta=result.meta,
        )
    return GitStageResult(
        repo_path=str(repo),
        repo_root=root,
        operation="unstage",
        path_count=len(normalized_paths),
        affected_paths=normalized_paths,
    )


async def git_commit(
    repo_path: str | Path = ".",
    *,
    message: str,
    paths: list[str],
) -> GitCommitResult:
    repo = Path(repo_path).resolve()
    root, meta = await _git_repo_root(repo)
    if meta is not None:
        return GitCommitResult(
            repo_path=str(repo), repo_root=root, message=message, meta=meta
        )

    normalized_paths, path_error = _normalize_paths(paths)
    if path_error is not None:
        return GitCommitResult(
            repo_path=str(repo),
            repo_root=root,
            message=message,
            meta=path_error,
        )

    message_error = _validate_commit_message(message)
    if message_error is not None:
        return GitCommitResult(
            repo_path=str(repo),
            repo_root=root,
            message=message,
            committed_paths=normalized_paths,
            meta=message_error,
        )

    identity_error, missing_identity = await _identity_error(repo)
    if identity_error is not None:
        return GitCommitResult(
            repo_path=str(repo),
            repo_root=root,
            message=message,
            committed_paths=normalized_paths,
            missing_identity=missing_identity,
            meta=identity_error,
        )

    staged_paths, staged_error = await _staged_paths(repo)
    if staged_error is not None:
        return GitCommitResult(
            repo_path=str(repo),
            repo_root=root,
            message=message,
            committed_paths=normalized_paths,
            meta=staged_error,
        )

    intended = {_canon_path(p) for p in normalized_paths}
    actual = {_canon_path(p) for p in staged_paths}
    if actual != intended:
        return GitCommitResult(
            repo_path=str(repo),
            repo_root=root,
            message=message,
            committed_paths=normalized_paths,
            dirty_index_paths=sorted(actual - intended),
            meta=ToolResultMeta(
                ok=False,
                error_code="dirty_index",
                error_message=(
                    "Staged changes do not exactly match the requested commit scope."
                ),
            ),
        )

    result = await _run_git(repo, "commit", "-m", message)
    if result.meta is not None:
        return GitCommitResult(
            repo_path=str(repo),
            repo_root=root,
            message=message,
            committed_paths=normalized_paths,
            meta=result.meta,
        )

    commit_result = await _run_git(repo, "rev-parse", "HEAD")
    commit = commit_result.stdout.strip() if commit_result.meta is None else None
    return GitCommitResult(
        repo_path=str(repo),
        repo_root=root,
        message=message,
        commit=commit,
        committed_paths=normalized_paths,
    )


class _GitCommandResult:
    def __init__(
        self,
        stdout: str = "",
        stderr: str = "",
        meta: ToolResultMeta | None = None,
    ) -> None:
        self.stdout = stdout
        self.stderr = stderr
        self.meta = meta


async def _git_repo_root(repo_path: Path) -> tuple[str | None, ToolResultMeta | None]:
    result = await _run_git(repo_path, "rev-parse", "--show-toplevel")
    if result.meta is not None:
        return None, result.meta
    return result.stdout.strip(), None


async def _kill_process(process: asyncio.subprocess.Process) -> None:
    with contextlib.suppress(ProcessLookupError):
        process.kill()
    with contextlib.suppress(Exception):
        await process.wait()


async def _run_git(
    repo_path: Path, *args: str, timeout: float = _GIT_TIMEOUT_SECONDS
) -> _GitCommandResult:
    try:
        process = await asyncio.create_subprocess_exec(
            "git",
            "-C",
            str(repo_path),
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except FileNotFoundError:
        return _GitCommandResult(
            meta=ToolResultMeta(
                ok=False,
                error_code="execution_failed",
                error_message="git executable not found",
            )
        )
    try:
        stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        await _kill_process(process)
        return _GitCommandResult(
            meta=ToolResultMeta(
                ok=False,
                error_code="timeout",
                error_message=f"git {' '.join(args)} timed out after {timeout}s",
            )
        )
    out = stdout.decode("utf-8", errors="replace")
    err = stderr.decode("utf-8", errors="replace").strip()
    if process.returncode != 0:
        error_code = (
            "not_a_repository"
            if "not a git repository" in err.lower()
            else "execution_failed"
        )
        return _GitCommandResult(
            stdout=out,
            stderr=err,
            meta=ToolResultMeta(
                ok=False,
                error_code=error_code,
                error_message=err or f"git {' '.join(args)} failed",
            ),
        )
    return _GitCommandResult(stdout=out, stderr=err)


def _normalize_paths(paths: list[str]) -> tuple[list[str], ToolResultMeta | None]:
    normalized = [path.strip() for path in paths if path.strip()]
    if not normalized:
        return [], ToolResultMeta(
            ok=False,
            error_code="invalid_input",
            error_message="paths must contain at least one file path",
        )
    return normalized, None


def _canon_path(p: str) -> str:
    """Canonicalize a path string to repo-relative form for comparison.

    Strips whitespace, normalizes backslashes, removes leading `./`, and
    collapses `//`. Matches the format returned by `git diff --cached --name-only`.
    """
    p = p.strip().replace("\\", "/")
    while p.startswith("./"):
        p = p[2:]
    while "//" in p:
        p = p.replace("//", "/")
    return p


def _validate_commit_message(message: str) -> ToolResultMeta | None:
    if not message.strip():
        return ToolResultMeta(
            ok=False,
            error_code="invalid_input",
            error_message="Commit message must not be empty.",
        )
    if "\n" in message:
        return ToolResultMeta(
            ok=False,
            error_code="invalid_input",
            error_message="Commit message must be a single line.",
        )
    if len(message) > _MAX_COMMIT_MESSAGE_LEN:
        return ToolResultMeta(
            ok=False,
            error_code="invalid_input",
            error_message=(
                f"Commit message must be {_MAX_COMMIT_MESSAGE_LEN} characters or fewer."
            ),
        )
    if not _COMMIT_SUBJECT_RE.match(message):
        return ToolResultMeta(
            ok=False,
            error_code="invalid_input",
            error_message=(
                "Commit message must use conventional format without scope, e.g. 'feat: add helper'."
            ),
        )
    return None


async def _identity_error(repo_path: Path) -> tuple[ToolResultMeta | None, bool]:
    name = await _git_config_value(repo_path, "user.name")
    email = await _git_config_value(repo_path, "user.email")
    if name and email:
        return None, False
    return (
        ToolResultMeta(
            ok=False,
            error_code="missing_identity",
            error_message=(
                "Git user.name and user.email must be configured before committing."
            ),
        ),
        True,
    )


async def _git_config_value(repo_path: Path, key: str) -> str | None:
    result = await _run_git(repo_path, "config", "--get", key)
    if result.meta is not None:
        return None
    value = result.stdout.strip()
    return value or None


async def _staged_paths(repo_path: Path) -> tuple[list[str], ToolResultMeta | None]:
    result = await _run_git(repo_path, "diff", "--cached", "--name-only")
    if result.meta is not None:
        return [], result.meta
    paths = [line.strip() for line in result.stdout.splitlines() if line.strip()]
    return paths, None


def _parse_status_output(
    output: str,
) -> tuple[str | None, bool, int, int, list[GitStatusEntry]]:
    lines = output.splitlines()
    branch: str | None = None
    detached = False
    ahead = 0
    behind = 0
    entries: list[GitStatusEntry] = []

    if lines and lines[0].startswith("## "):
        branch, detached, ahead, behind = _parse_branch_header(lines[0][3:])
        lines = lines[1:]

    for line in lines:
        if len(line) < 3:
            continue
        status = line[:2]
        path_text = line[3:]
        original_path: str | None = None
        if " -> " in path_text:
            original_path, path_text = path_text.split(" -> ", 1)
        entries.append(
            GitStatusEntry(
                path=path_text,
                index_status="" if status[0] == " " else status[0],
                worktree_status="" if status[1] == " " else status[1],
                original_path=original_path,
            )
        )
    return branch, detached, ahead, behind, entries


def _parse_branch_header(header: str) -> tuple[str | None, bool, int, int]:
    branch_part = header
    ahead = 0
    behind = 0
    if " [" in header:
        branch_part, metadata = header.split(" [", 1)
        metadata = metadata.rstrip("]")
        for chunk in metadata.split(", "):
            if chunk.startswith("ahead "):
                ahead = int(chunk.removeprefix("ahead "))
            elif chunk.startswith("behind "):
                behind = int(chunk.removeprefix("behind "))
    branch = branch_part.split("...", 1)[0]
    detached = branch == "HEAD" or "(HEAD detached" in header or "(no branch)" in header
    return (None if detached else branch), detached, ahead, behind


def _parse_log_output(output: str) -> list[GitLogEntry]:
    commits: list[GitLogEntry] = []
    for line in output.splitlines():
        if not line:
            continue
        commit, author_name, author_email, authored_at, subject = (
            line.split("\x1f", 4) + ["", "", "", "", ""]
        )[:5]
        commits.append(
            GitLogEntry(
                commit=commit,
                author_name=author_name,
                author_email=author_email,
                authored_at=int(authored_at or "0"),
                subject=subject,
            )
        )
    return commits


def _truncate_text(text: str, max_chars: int) -> tuple[str, bool]:
    if len(text) <= max_chars:
        return text, False
    if max_chars <= len(_TRUNCATION_MARKER):
        return text[:max_chars], True
    head = max_chars // 2
    tail = max_chars - head - len(_TRUNCATION_MARKER)
    if tail <= 0:
        return text[: max_chars - len(_TRUNCATION_MARKER)] + _TRUNCATION_MARKER, True
    return text[:head] + _TRUNCATION_MARKER + text[-tail:], True
