"""Token-aware truncation for tool outputs sent back to the model."""

from __future__ import annotations

from dataclasses import dataclass

from kiss.core.deps import AgentDeps
from kiss.agent.tools.truncation.core import (
    TruncationStrategy,
    ToolOutputBudget,
    truncate_text,
)
from kiss.agent.tools.truncation.registry import _find_renderer
from kiss.agent.tools.truncation.render import (
    _tool_result_meta,
    render_analyze_code_result,
    render_check_style_result,
    render_definition_result,
    render_document_symbols_result,
    render_edit_file_result,
    render_expand_ref_result,
    render_fetch_url_result,
    render_git_commit_result,
    render_git_diff_result,
    render_git_log_result,
    render_git_stage_result,
    render_git_status_result,
    render_glob_result,
    render_list_directory_result,
    render_logic_apply_result,
    render_logic_execution_result,
    render_read_file_result,
    render_references_result,
    render_run_command_result,
    render_search_code_result,
    render_web_search_result,
    render_workspace_symbols_result,
    render_write_file_result,
)
import kiss.agent.tools.truncation.handlers  # noqa: F401

_UI_OUTPUT_MULTIPLIER = 2

_TOOL_STRATEGIES: dict[str, TruncationStrategy] = {
    "read_file": TruncationStrategy.HEAD_TAIL,
    "write_file": TruncationStrategy.HEAD_TAIL,
    "edit_file": TruncationStrategy.HEAD_TAIL,
    "expand_ref": TruncationStrategy.HEAD_TAIL,
    "search_code": TruncationStrategy.TOP_MATCHES,
    "glob": TruncationStrategy.HEAD_ONLY,
    "list_directory": TruncationStrategy.HEAD_ONLY,
    "run_bash": TruncationStrategy.TAIL_HEAVY,
    "run_python": TruncationStrategy.TAIL_HEAVY,
    "fetch_url": TruncationStrategy.HEAD_TAIL,
    "web_search": TruncationStrategy.TOP_MATCHES,
    "researcher": TruncationStrategy.HEAD_TAIL,
    "coder": TruncationStrategy.HEAD_TAIL,
    "reviewer": TruncationStrategy.HEAD_TAIL,
}


@dataclass(frozen=True)
class PreparedToolOutput:
    model_result: object
    model_text: str
    ui_text: str


def truncate_tool_output(output: str, deps: AgentDeps, label: str) -> str:
    budget = ToolOutputBudget.from_deps(deps)
    return truncate_text(
        output, budget.limit_tokens, label, TruncationStrategy.HEAD_TAIL
    )


def prepare_tool_output(
    tool_name: str,
    result: object,
    deps: AgentDeps,
) -> PreparedToolOutput:
    strategy = _TOOL_STRATEGIES.get(tool_name, TruncationStrategy.HEAD_TAIL)
    renderer = _find_renderer(result)
    model_budget = ToolOutputBudget.from_deps(deps).limit_tokens
    ui_budget = max(
        deps.tool_output_min_tokens,
        deps.tool_output_max_tokens * _UI_OUTPUT_MULTIPLIER,
    )
    if renderer is not None:
        model_text = renderer(result, model_budget, strategy)
        ui_text = renderer(result, ui_budget, strategy)
        return PreparedToolOutput(
            model_result=model_text,
            model_text=model_text,
            ui_text=ui_text,
        )
    text = result if isinstance(result, str) else str(result)
    label = f"{tool_name} output"
    model_text = truncate_text(text, model_budget, label=label, strategy=strategy)
    ui_text = truncate_text(text, ui_budget, label=label, strategy=strategy)
    return PreparedToolOutput(
        model_result=model_text,
        model_text=model_text,
        ui_text=ui_text,
    )


def tool_result_failed(result: object) -> bool:
    meta = _tool_result_meta(result)
    return meta is not None and not meta.ok


__all__ = [
    "PreparedToolOutput",
    "prepare_tool_output",
    "truncate_tool_output",
    "tool_result_failed",
    "render_read_file_result",
    "render_write_file_result",
    "render_edit_file_result",
    "render_expand_ref_result",
    "render_search_code_result",
    "render_glob_result",
    "render_list_directory_result",
    "render_run_command_result",
    "render_fetch_url_result",
    "render_web_search_result",
    "render_analyze_code_result",
    "render_check_style_result",
    "render_definition_result",
    "render_references_result",
    "render_document_symbols_result",
    "render_workspace_symbols_result",
    "render_git_status_result",
    "render_git_diff_result",
    "render_git_log_result",
    "render_git_stage_result",
    "render_git_commit_result",
    "render_logic_execution_result",
    "render_logic_apply_result",
]
