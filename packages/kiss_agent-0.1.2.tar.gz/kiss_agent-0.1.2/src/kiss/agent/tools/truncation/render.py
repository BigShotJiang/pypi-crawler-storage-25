"""Render functions for tool output truncation."""

from __future__ import annotations

from kiss.agent.tools.result_types import (
    AnalysisIssue,
    AnalyzeCodeResult,
    CheckStyleResult,
    DefinitionResult,
    DocumentSymbolsResult,
    EditFileResult,
    ExpandRefResult,
    FetchUrlResult,
    GitCommitResult,
    GitDiffResult,
    GitLogResult,
    GitStageResult,
    GitStatusResult,
    GlobResult,
    ListDirectoryResult,
    LogicApplyResult,
    LogicExecutionResult,
    ReadFileResult,
    ReferencesResult,
    RunCommandResult,
    SearchCodeMatch,
    SearchCodeResult,
    StyleViolation,
    ToolResultMeta,
    WebSearchResult,
    WorkspaceSymbolsResult,
    WriteFileResult,
)
from kiss.agent.tools.truncation.core import (
    TruncationStrategy,
    estimate_tokens,
    truncate_text,
)

_UI_OUTPUT_MULTIPLIER = 2


def _tool_result_meta(result: object) -> ToolResultMeta | None:
    meta = getattr(result, "meta", None)
    if isinstance(meta, ToolResultMeta):
        return meta
    return None


def _meta_error(meta: ToolResultMeta | None) -> str | None:
    if meta is None or meta.ok:
        return None
    return meta.error_message or meta.error_code or "Tool failed"


def _number_lines(content: str, start_line: int) -> str:
    lines = content.splitlines()
    if not lines:
        return ""
    width = len(str(start_line + len(lines) - 1))
    return "\n".join(
        f"{start_line + index:>{width}} | {line}" for index, line in enumerate(lines)
    )


def _select_matches_round_robin(
    matches: list[SearchCodeMatch], max_tokens: int
) -> list[SearchCodeMatch]:
    groups: dict[str, list[SearchCodeMatch]] = {}
    order: list[str] = []
    for match in matches:
        if match.path not in groups:
            groups[match.path] = []
            order.append(match.path)
        groups[match.path].append(match)

    costs: dict[int, int] = {
        id(m): estimate_tokens(f"- {m.path}:{m.line}: {m.text}") + 1 for m in matches
    }

    selected: list[SearchCodeMatch] = []
    running = 0
    taken = True
    while taken:
        taken = False
        for path in order:
            bucket = groups[path]
            if not bucket:
                continue
            cost = costs[id(bucket[0])]
            if running + cost > max_tokens:
                return selected
            running += cost
            selected.append(bucket.pop(0))
            taken = True
    return selected


def render_read_file_result(
    result: ReadFileResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.HEAD_TAIL,
) -> str:
    if error := _meta_error(result.meta):
        return error

    lines = [f"path: {result.path}"]
    lines.append(f"exists: {result.exists}")
    lines.append(f"is_file: {result.is_file}")
    if result.size_bytes:
        lines.append(f"size_bytes: {result.size_bytes}")
    if result.is_binary:
        lines.append("is_binary: true")
        return "\n".join(lines)

    if result.start_line is not None and result.end_line is not None:
        lines.append(f"lines: {result.start_line}-{result.end_line}")
    if result.line_count is not None:
        lines.append(f"line_count: {result.line_count}")
    lines.append(f"truncated: {result.truncated}")

    content = result.content or ""
    numbered = _number_lines(content, result.start_line or 1)
    body = "\n".join([*lines, "content:", numbered]).rstrip()
    if max_tokens is None:
        return body
    return truncate_text(
        body,
        max_tokens=max_tokens,
        label="read_file output",
        strategy=strategy,
    )


def render_write_file_result(
    result: WriteFileResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.HEAD_TAIL,
) -> str:
    if error := _meta_error(result.meta):
        return error

    lines = [f"path: {result.path}"]
    lines.append(f"created: {result.created}")
    lines.append(f"overwrote: {result.overwrote}")
    lines.append(f"bytes_written: {result.bytes_written}")
    lines.append(f"line_count: {result.line_count}")
    lines.append(f"truncated_preview: {result.truncated_preview}")
    if result.meta.needs_confirmation:
        lines.append("needs_confirmation: true")
    if result.diff_preview:
        lines.append("diff_preview:")
        lines.append(result.diff_preview)
    body = "\n".join(lines).rstrip()
    if max_tokens is None:
        return body
    return truncate_text(
        body,
        max_tokens=max_tokens,
        label="write_file output",
        strategy=strategy,
    )


def render_edit_file_result(
    result: EditFileResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.HEAD_TAIL,
) -> str:
    if error := _meta_error(result.meta):
        if not result.meta.needs_disambiguation:
            return error

    lines = [f"path: {result.path}"]
    lines.append(f"applied: {result.applied}")
    lines.append(f"requested_change_count: {result.requested_change_count}")
    lines.append(f"applied_change_count: {result.applied_change_count}")
    lines.append(f"occurrence_count: {result.occurrence_count}")
    lines.append(f"replacement_count: {result.replacement_count}")
    lines.append(f"needs_disambiguation: {result.meta.needs_disambiguation}")
    lines.append(f"truncated_preview: {result.truncated_preview}")
    if result.failed_change_index is not None:
        lines.append(f"failed_change_index: {result.failed_change_index}")
    if result.failed_change_label is not None:
        lines.append(f"failed_change_label: {result.failed_change_label}")
    if result.recovery_type is not None:
        lines.append(f"recovery_type: {result.recovery_type}")
    if error:
        lines.append(f"error: {error}")
    if result.match_contexts:
        lines.append("match_contexts:")
        lines.extend(f"- {context}" for context in result.match_contexts)
    if result.diff_preview:
        lines.append("diff_preview:")
        lines.append(result.diff_preview)
    body = "\n".join(lines).rstrip()
    if max_tokens is None:
        return body
    return truncate_text(
        body,
        max_tokens=max_tokens,
        label="edit_file output",
        strategy=strategy,
    )


def render_expand_ref_result(
    result: ExpandRefResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.HEAD_TAIL,
) -> str:
    if error := _meta_error(result.meta):
        return error
    body = result.content or ""
    if max_tokens is None:
        return body
    return truncate_text(
        body,
        max_tokens=max_tokens,
        label="expand_ref output",
        strategy=strategy,
    )


def render_search_code_result(
    result: SearchCodeResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.TOP_MATCHES,
) -> str:
    if error := _meta_error(result.meta):
        return error
    if not result.matches:
        return (
            f"pattern: {result.pattern}\nmatch_count: 0"
            "\n— no results; do not retry with the same pattern."
            " Use list_directory to explore the target path, then read_file on specific files."
            " When searching an external directory, set path_glob to that directory (e.g. path_glob='../other-project/**/*.py')."
        )

    selected_matches = (
        _select_matches_round_robin(result.matches, max_tokens)
        if max_tokens is not None
        else result.matches
    )
    lines = [f"pattern: {result.pattern}"]
    lines.append(f"match_count: {result.match_count}")
    lines.append(f"shown_matches: {len(selected_matches)}")
    lines.append(f"truncated: {len(selected_matches) < result.match_count}")
    lines.append("matches:")
    for match in selected_matches:
        lines.append(f"- {match.path}:{match.line}: {match.text}")
    body = "\n".join(lines)
    if max_tokens is None:
        return body
    if strategy is TruncationStrategy.TOP_MATCHES:
        return body
    return truncate_text(
        body,
        max_tokens=max_tokens,
        label="search_code output",
        strategy=strategy,
    )


def render_glob_result(
    result: GlobResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.HEAD_ONLY,
) -> str:
    if error := _meta_error(result.meta):
        return error
    lines = [f"pattern: {result.pattern}"]
    lines.append(f"root: {result.root}")
    lines.append(f"match_count: {len(result.matches)}")
    lines.append(f"truncated: {result.truncated}")
    lines.append("matches:")
    for match in result.matches:
        suffix = "/" if match.is_dir else ""
        lines.append(
            f"- {match.path}{suffix} size={match.size_bytes} mtime={match.mtime:.3f}"
        )
    body = "\n".join(lines)
    if max_tokens is None:
        return body
    return truncate_text(
        body,
        max_tokens=max_tokens,
        label="glob output",
        strategy=strategy,
    )


def render_list_directory_result(
    result: ListDirectoryResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.HEAD_ONLY,
) -> str:
    if error := _meta_error(result.meta):
        return error
    lines = [f"root: {result.root}"]
    lines.append(f"max_depth: {result.max_depth}")
    lines.append(f"entry_count: {len(result.entries)}")
    lines.append(f"truncated: {result.truncated}")
    lines.append("entries:")
    for entry in result.entries:
        indent = "  " * max(0, entry.depth - 1)
        suffix = "/" if entry.kind == "dir" else ""
        lines.append(f"{indent}- {entry.path}{suffix}")
    body = "\n".join(lines)
    if max_tokens is None:
        return body
    return truncate_text(
        body,
        max_tokens=max_tokens,
        label="list_directory output",
        strategy=strategy,
    )


def render_run_command_result(
    result: RunCommandResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.TAIL_HEAVY,
) -> str:
    if error := _meta_error(result.meta):
        return error
    lines = [f"command: {result.command}"]
    if result.exit_code is not None:
        lines.append(f"exit_code: {result.exit_code}")
    lines.append(f"timed_out: {result.timed_out}")
    lines.append(f"truncated: {result.truncated}")
    lines.append("stdout:")
    lines.append(result.stdout.rstrip("\n"))
    lines.append("stderr:")
    lines.append(result.stderr.rstrip("\n"))
    body = "\n".join(lines).rstrip()
    if max_tokens is None:
        return body
    return truncate_text(
        body,
        max_tokens=max_tokens,
        label="run_bash output",
        strategy=strategy,
    )


def render_git_status_result(
    result: GitStatusResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.HEAD_ONLY,
) -> str:
    if error := _meta_error(result.meta):
        return error
    lines = [f"repo_path: {result.repo_path}"]
    if result.repo_root:
        lines.append(f"repo_root: {result.repo_root}")
    if result.branch:
        lines.append(f"branch: {result.branch}")
    lines.append(f"detached: {result.detached}")
    lines.append(f"ahead: {result.ahead}")
    lines.append(f"behind: {result.behind}")
    lines.append(f"entry_count: {len(result.entries)}")
    lines.append("entries:")
    for entry in result.entries:
        status = f"{entry.index_status or ' '}{entry.worktree_status or ' '}"
        original = f" original={entry.original_path}" if entry.original_path else ""
        lines.append(f"- {status} {entry.path}{original}")
    body = "\n".join(lines)
    if max_tokens is None:
        return body
    return truncate_text(
        body,
        max_tokens=max_tokens,
        label="git_status output",
        strategy=strategy,
    )


def render_git_diff_result(
    result: GitDiffResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.TAIL_HEAVY,
) -> str:
    if error := _meta_error(result.meta):
        return error
    lines = [f"repo_path: {result.repo_path}"]
    if result.repo_root:
        lines.append(f"repo_root: {result.repo_root}")
    lines.append(f"staged: {result.staged}")
    lines.append(f"truncated: {result.truncated}")
    lines.append("diff:")
    lines.append(result.diff.rstrip("\n"))
    body = "\n".join(lines).rstrip()
    if max_tokens is None:
        return body
    return truncate_text(
        body,
        max_tokens=max_tokens,
        label="git_diff output",
        strategy=strategy,
    )


def render_git_log_result(
    result: GitLogResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.HEAD_ONLY,
) -> str:
    if error := _meta_error(result.meta):
        return error
    lines = [f"repo_path: {result.repo_path}"]
    if result.repo_root:
        lines.append(f"repo_root: {result.repo_root}")
    lines.append(f"limit: {result.limit}")
    lines.append(f"truncated: {result.truncated}")
    lines.append(f"commit_count: {len(result.commits)}")
    lines.append("commits:")
    for commit in result.commits:
        lines.append(
            f"- {commit.commit} author={commit.author_name} <{commit.author_email}> "
            f"authored_at={commit.authored_at} subject={commit.subject}"
        )
    body = "\n".join(lines)
    if max_tokens is None:
        return body
    return truncate_text(
        body,
        max_tokens=max_tokens,
        label="git_log output",
        strategy=strategy,
    )


def render_git_stage_result(
    result: GitStageResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.HEAD_ONLY,
) -> str:
    if error := _meta_error(result.meta):
        return error
    lines = [f"repo_path: {result.repo_path}"]
    if result.repo_root:
        lines.append(f"repo_root: {result.repo_root}")
    lines.append(f"operation: {result.operation}")
    lines.append(f"path_count: {result.path_count}")
    lines.append("affected_paths:")
    for path in result.affected_paths:
        lines.append(f"- {path}")
    body = "\n".join(lines)
    if max_tokens is None:
        return body
    return truncate_text(
        body,
        max_tokens=max_tokens,
        label="git_stage output",
        strategy=strategy,
    )


def render_git_commit_result(
    result: GitCommitResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.HEAD_ONLY,
) -> str:
    if error := _meta_error(result.meta):
        if not result.dirty_index_paths and not result.missing_identity:
            return error

    lines = [f"repo_path: {result.repo_path}"]
    if result.repo_root:
        lines.append(f"repo_root: {result.repo_root}")
    lines.append(f"message: {result.message}")
    lines.append(f"missing_identity: {result.missing_identity}")
    if result.commit:
        lines.append(f"commit: {result.commit}")
    if error:
        lines.append(f"error: {error}")
    lines.append("committed_paths:")
    for path in result.committed_paths:
        lines.append(f"- {path}")
    if result.dirty_index_paths:
        lines.append("dirty_index_paths:")
        for path in result.dirty_index_paths:
            lines.append(f"- {path}")
    body = "\n".join(lines)
    if max_tokens is None:
        return body
    return truncate_text(
        body,
        max_tokens=max_tokens,
        label="git_commit output",
        strategy=strategy,
    )


def render_fetch_url_result(
    result: FetchUrlResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.HEAD_TAIL,
) -> str:
    if error := _meta_error(result.meta):
        return error
    lines = [f"url: {result.url}"]
    if result.final_url:
        lines.append(f"final_url: {result.final_url}")
    lines.append(f"method: {result.method}")
    if result.status_code is not None:
        lines.append(f"status_code: {result.status_code}")
    if result.content_type:
        lines.append(f"content_type: {result.content_type}")
    if result.charset:
        lines.append(f"charset: {result.charset}")
    lines.append(f"is_text: {result.is_text}")
    lines.append(f"is_html: {result.is_html}")
    lines.append(f"is_binary: {result.is_binary}")
    lines.append(f"redirect_count: {result.redirect_count}")
    if result.title:
        lines.append(f"title: {result.title}")
    lines.append(f"extracted: {result.extracted}")
    lines.append(f"truncated: {result.truncated}")
    if result.content is not None:
        lines.append("content:")
        lines.append(result.content)
    body = "\n".join(lines).rstrip()
    if max_tokens is None:
        return body
    return truncate_text(
        body,
        max_tokens=max_tokens,
        label="fetch_url output",
        strategy=strategy,
    )


def render_web_search_result(
    result: WebSearchResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.TOP_MATCHES,
) -> str:
    if error := _meta_error(result.meta):
        return error
    lines = [f"query: {result.query}"]
    lines.append(f"provider: {result.provider}")
    lines.append(f"max_results: {result.max_results}")
    lines.append(f"result_count: {result.result_count}")
    lines.append(f"cached: {result.cached}")
    lines.append(f"truncated: {result.truncated}")
    lines.append("results:")
    shown = result.results
    if max_tokens is not None and strategy is TruncationStrategy.TOP_MATCHES:
        shown = result.results[: max(1, min(len(result.results), result.max_results))]
    for match in shown:
        lines.append(f"- {match.title}")
        lines.append(f"  url: {match.url}")
        if match.snippet:
            lines.append(f"  snippet: {match.snippet}")
    body = "\n".join(lines)
    if max_tokens is None or strategy is TruncationStrategy.TOP_MATCHES:
        return body
    return truncate_text(
        body,
        max_tokens=max_tokens,
        label="web_search output",
        strategy=strategy,
    )


def _render_issue(issue: AnalysisIssue | StyleViolation) -> str:
    location = ""
    if issue.location is not None:
        line = issue.location.range.start_line
        col = issue.location.range.start_col
        location = f" @ {issue.location.path}:{line}:{col}"
    return f"- {issue.severity} {issue.code}{location}: {issue.message}"


def _render_symbol(symbol: object) -> str:
    name = getattr(symbol, "name", "")
    kind = getattr(symbol, "kind", "")
    language = getattr(symbol, "language", "")
    location = getattr(symbol, "location", None)
    container = getattr(symbol, "container_name", None)
    loc_text = ""
    if location is not None:
        path = getattr(location, "path", "")
        range_value = getattr(location, "range", None)
        line = getattr(range_value, "start_line", 1)
        col = getattr(range_value, "start_col", 0)
        loc_text = f" {path}:{line}:{col}"
    container_text = f" container={container}" if container else ""
    return f"- {name} kind={kind} language={language}{container_text}{loc_text}"


def _render_location(location: object) -> str:
    path = getattr(location, "path", "")
    range_value = getattr(location, "range", None)
    line = getattr(range_value, "start_line", 1)
    col = getattr(range_value, "start_col", 0)
    return f"- {path}:{line}:{col}"


def render_analyze_code_result(
    result: AnalyzeCodeResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.HEAD_TAIL,
) -> str:
    if error := _meta_error(result.meta):
        if not result.issues:
            return error
    lines = [f"path: {result.path}"]
    if result.language:
        lines.append(f"language: {result.language}")
    if result.freshness_strategy:
        lines.append(f"freshness_strategy: {result.freshness_strategy}")
    if error := _meta_error(result.meta):
        lines.append(f"error: {error}")
    if result.metrics:
        lines.append("metrics:")
        for key, value in sorted(result.metrics.items()):
            lines.append(f"- {key}: {value}")
    if result.issues:
        lines.append("issues:")
        lines.extend(_render_issue(issue) for issue in result.issues)
    body = "\n".join(lines).rstrip()
    if max_tokens is None:
        return body
    return truncate_text(
        body, max_tokens=max_tokens, label="analyze_code output", strategy=strategy
    )


def render_check_style_result(
    result: CheckStyleResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.HEAD_TAIL,
) -> str:
    if error := _meta_error(result.meta):
        if not result.violations:
            return error
    lines = [f"path: {result.path}"]
    if result.language:
        lines.append(f"language: {result.language}")
    lines.append(f"passed: {result.passed}")
    if result.ruleset:
        lines.append(f"ruleset: {result.ruleset}")
    if result.freshness_strategy:
        lines.append(f"freshness_strategy: {result.freshness_strategy}")
    if error := _meta_error(result.meta):
        lines.append(f"error: {error}")
    if result.violations:
        lines.append("violations:")
        lines.extend(_render_issue(issue) for issue in result.violations)
    body = "\n".join(lines).rstrip()
    if max_tokens is None:
        return body
    return truncate_text(
        body, max_tokens=max_tokens, label="check_style output", strategy=strategy
    )


def render_definition_result(
    result: DefinitionResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.HEAD_ONLY,
) -> str:
    if error := _meta_error(result.meta):
        return error
    lines = [f"query: {result.query}"]
    if result.language:
        lines.append(f"language: {result.language}")
    if result.freshness_strategy:
        lines.append(f"freshness_strategy: {result.freshness_strategy}")
    if result.symbol is not None:
        lines.append("symbol:")
        lines.append(_render_symbol(result.symbol))
    body = "\n".join(lines).rstrip()
    if max_tokens is None:
        return body
    return truncate_text(
        body, max_tokens=max_tokens, label="find_definition output", strategy=strategy
    )


def render_references_result(
    result: ReferencesResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.HEAD_ONLY,
) -> str:
    if error := _meta_error(result.meta):
        return error
    lines = [f"query: {result.query}"]
    if result.language:
        lines.append(f"language: {result.language}")
    if result.freshness_strategy:
        lines.append(f"freshness_strategy: {result.freshness_strategy}")
    lines.append(f"reference_count: {result.reference_count}")
    lines.append(f"truncated: {result.truncated}")
    if result.references:
        lines.append("references:")
        lines.extend(_render_location(location) for location in result.references)
    body = "\n".join(lines).rstrip()
    if max_tokens is None:
        return body
    return truncate_text(
        body, max_tokens=max_tokens, label="find_references output", strategy=strategy
    )


def render_document_symbols_result(
    result: DocumentSymbolsResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.HEAD_ONLY,
) -> str:
    if error := _meta_error(result.meta):
        if not result.symbols:
            return error
    lines = [f"path: {result.path}"]
    if result.language:
        lines.append(f"language: {result.language}")
    if result.freshness_strategy:
        lines.append(f"freshness_strategy: {result.freshness_strategy}")
    lines.append(f"symbol_count: {result.symbol_count}")
    lines.append(f"truncated: {result.truncated}")
    if error := _meta_error(result.meta):
        lines.append(f"error: {error}")
    if result.symbols:
        lines.append("symbols:")
        lines.extend(_render_symbol(symbol) for symbol in result.symbols)
    body = "\n".join(lines).rstrip()
    if max_tokens is None:
        return body
    return truncate_text(
        body, max_tokens=max_tokens, label="document_symbols output", strategy=strategy
    )


def render_workspace_symbols_result(
    result: WorkspaceSymbolsResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.HEAD_ONLY,
) -> str:
    if error := _meta_error(result.meta):
        return error
    lines = [f"query: {result.query}"]
    if result.freshness_strategy:
        lines.append(f"freshness_strategy: {result.freshness_strategy}")
    lines.append(f"symbol_count: {result.symbol_count}")
    lines.append(f"truncated: {result.truncated}")
    if result.symbols:
        lines.append("symbols:")
        lines.extend(_render_symbol(symbol) for symbol in result.symbols)
    body = "\n".join(lines).rstrip()
    if max_tokens is None:
        return body
    return truncate_text(
        body, max_tokens=max_tokens, label="workspace_symbols output", strategy=strategy
    )


def render_logic_execution_result(
    result: LogicExecutionResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.TAIL_HEAVY,
) -> str:
    if error := _meta_error(result.meta):
        return error
    lines: list[str] = []
    if result.exit_code is not None:
        lines.append(f"exit_code: {result.exit_code}")
    lines.append(f"timed_out: {result.timed_out}")
    lines.append(f"truncated: {result.truncated}")
    if result.pending_changes:
        lines.append(f"pending_change_count: {len(result.pending_changes)}")
        lines.append("pending_changes:")
        for change in result.pending_changes:
            lines.append(
                f"- {change.change_type}: {change.path} ({change.line_count} lines)"
            )
    lines.append("stdout:")
    lines.append(result.stdout.rstrip("\n"))
    lines.append("stderr:")
    lines.append(result.stderr.rstrip("\n"))
    body = "\n".join(lines).rstrip()
    if max_tokens is None:
        return body
    return truncate_text(
        body, max_tokens=max_tokens, label="run_python output", strategy=strategy
    )


def render_logic_apply_result(
    result: LogicApplyResult,
    max_tokens: int | None = None,
    strategy: TruncationStrategy = TruncationStrategy.TAIL_HEAVY,
) -> str:
    if not result.approved:
        return _meta_error(result.meta) or "Logic Tool manifest denied."
    if result.drift_detected_paths:
        lines = ["drift_detected: true", "drift_paths:"]
        lines.extend(f"- {p}" for p in result.drift_detected_paths)
        return "\n".join(lines)
    lines = ["approved: true", f"applied_count: {result.applied_count}"]
    if result.applied_paths:
        lines.append("applied_paths:")
        for path in result.applied_paths:
            lines.append(f"- {path}")
    body = "\n".join(lines).rstrip()
    if max_tokens is None:
        return body
    return truncate_text(
        body, max_tokens=max_tokens, label="run_python apply output", strategy=strategy
    )
