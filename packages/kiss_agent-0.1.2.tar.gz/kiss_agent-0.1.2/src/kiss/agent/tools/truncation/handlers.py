"""Renderer registration for all tool result types."""

from __future__ import annotations

from kiss.agent.tools.result_types import (
    AnalyzeCodeResult,
    CheckStyleResult,
    DefinitionResult,
    DocumentSymbolsResult,
    EditFileResult,
    ExpandRefResult,
    FetchUrlResult,
    GitCommitResult,
    GitDiffResult,
    GitLogResult,
    GitStageResult,
    GitStatusResult,
    GlobResult,
    ListDirectoryResult,
    LogicApplyResult,
    LogicExecutionResult,
    ReadFileResult,
    ReferencesResult,
    RunCommandResult,
    SearchCodeResult,
    WebSearchResult,
    WorkspaceSymbolsResult,
    WriteFileResult,
)
from kiss.agent.tools.truncation.registry import register_renderer
from kiss.agent.tools.truncation.render import (
    render_analyze_code_result,
    render_check_style_result,
    render_definition_result,
    render_document_symbols_result,
    render_edit_file_result,
    render_expand_ref_result,
    render_fetch_url_result,
    render_git_commit_result,
    render_git_diff_result,
    render_git_log_result,
    render_git_stage_result,
    render_git_status_result,
    render_glob_result,
    render_list_directory_result,
    render_logic_apply_result,
    render_logic_execution_result,
    render_read_file_result,
    render_references_result,
    render_run_command_result,
    render_search_code_result,
    render_web_search_result,
    render_workspace_symbols_result,
    render_write_file_result,
)

register_renderer(ReadFileResult, render_read_file_result)
register_renderer(WriteFileResult, render_write_file_result)
register_renderer(EditFileResult, render_edit_file_result)
register_renderer(ExpandRefResult, render_expand_ref_result)
register_renderer(SearchCodeResult, render_search_code_result)
register_renderer(GlobResult, render_glob_result)
register_renderer(ListDirectoryResult, render_list_directory_result)
register_renderer(RunCommandResult, render_run_command_result)
register_renderer(FetchUrlResult, render_fetch_url_result)
register_renderer(WebSearchResult, render_web_search_result)
register_renderer(GitStatusResult, render_git_status_result)
register_renderer(GitDiffResult, render_git_diff_result)
register_renderer(GitLogResult, render_git_log_result)
register_renderer(GitStageResult, render_git_stage_result)
register_renderer(GitCommitResult, render_git_commit_result)
register_renderer(AnalyzeCodeResult, render_analyze_code_result)
register_renderer(CheckStyleResult, render_check_style_result)
register_renderer(DefinitionResult, render_definition_result)
register_renderer(ReferencesResult, render_references_result)
register_renderer(DocumentSymbolsResult, render_document_symbols_result)
register_renderer(WorkspaceSymbolsResult, render_workspace_symbols_result)
register_renderer(LogicExecutionResult, render_logic_execution_result)
register_renderer(LogicApplyResult, render_logic_apply_result)
