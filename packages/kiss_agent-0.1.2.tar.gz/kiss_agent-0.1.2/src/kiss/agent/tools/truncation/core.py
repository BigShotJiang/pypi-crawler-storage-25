"""Core truncation: token estimation, budgeting, and text truncation strategies."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from functools import lru_cache
from typing import Protocol

from kiss.core.deps import AgentDeps

_CHARS_PER_TOKEN = 4
_HEAD_RATIO = 0.30
_TAIL_HEAVY_HEAD_RATIO = 0.10


class TruncationStrategy(str, Enum):
    HEAD_TAIL = "head_tail"
    HEAD_ONLY = "head_only"
    TAIL_HEAVY = "tail_heavy"
    TOP_MATCHES = "top_matches"


class TokenEncoding(Protocol):
    def encode(self, text: str) -> list[int]: ...

    def decode(self, tokens: list[int]) -> str: ...


@dataclass(frozen=True)
class ToolOutputBudget:
    context_window: int
    current_usage_tokens: int
    safety_buffer: int
    max_output_tokens: int
    min_output_tokens: int

    @classmethod
    def from_deps(cls, deps: AgentDeps) -> "ToolOutputBudget":
        return cls(
            context_window=deps.context_window,
            current_usage_tokens=deps.current_usage_tokens,
            safety_buffer=deps.tool_output_safety_buffer,
            max_output_tokens=deps.tool_output_max_tokens,
            min_output_tokens=deps.tool_output_min_tokens,
        )

    @property
    def limit_tokens(self) -> int:
        available = self.context_window - self.current_usage_tokens - self.safety_buffer
        if available <= 0:
            return self.min_output_tokens
        return max(self.min_output_tokens, min(self.max_output_tokens, available))


@lru_cache(maxsize=512)
def estimate_tokens(text: str) -> int:
    tokens = _encode(text)
    if tokens is not None:
        return len(tokens)
    return max(1, len(text) // _CHARS_PER_TOKEN)


def truncate_text(
    text: str,
    max_tokens: int,
    label: str = "tool output",
    strategy: TruncationStrategy = TruncationStrategy.HEAD_TAIL,
) -> str:
    if max_tokens <= 0:
        raise ValueError("max_tokens must be greater than 0")

    tokens = _encode(text)
    if tokens is None:
        return _truncate_by_chars(text, max_tokens, label, strategy)
    if len(tokens) <= max_tokens:
        return text

    encoding = _encoding()
    if encoding is None:
        return _truncate_by_chars(text, max_tokens, label, strategy)

    if strategy is TruncationStrategy.HEAD_ONLY:
        return _truncate_head_only_tokens(text, tokens, max_tokens, label, encoding)
    if strategy is TruncationStrategy.TAIL_HEAVY:
        return _truncate_head_tail_tokens(
            tokens, max_tokens, label, encoding, head_ratio=_TAIL_HEAVY_HEAD_RATIO
        )
    if strategy is TruncationStrategy.TOP_MATCHES:
        return _truncate_top_matches(text, max_tokens, label)
    return _truncate_head_tail_tokens(
        tokens, max_tokens, label, encoding, head_ratio=_HEAD_RATIO
    )


def _marker(label: str, original_tokens: int, kept_tokens: int) -> str:
    omitted = max(0, original_tokens - kept_tokens)
    return (
        f"\n[... truncated {label}: original ~{original_tokens:,} tokens, "
        f"kept ~{kept_tokens:,}, omitted ~{omitted:,} ..."
        f" — do not retry; call list_directory on a specific subdirectory or use read_file on individual files ...]\n"
    )


def _truncate_by_chars(
    text: str,
    max_tokens: int,
    label: str,
    strategy: TruncationStrategy,
) -> str:
    max_chars = max(1, max_tokens * _CHARS_PER_TOKEN)
    if len(text) <= max_chars:
        return text

    if strategy is TruncationStrategy.TOP_MATCHES:
        return _truncate_top_matches_by_chars(text, max_chars, label)

    original_tokens = estimate_tokens(text)
    marker = _marker(label, original_tokens, max_tokens)
    if strategy is TruncationStrategy.HEAD_ONLY:
        content_chars = max(1, max_chars - len(marker))
        return text[:content_chars] + marker

    head_ratio = (
        _TAIL_HEAVY_HEAD_RATIO
        if strategy is TruncationStrategy.TAIL_HEAVY
        else _HEAD_RATIO
    )
    content_chars = max(2, max_chars - len(marker))
    head_chars = max(1, int(content_chars * head_ratio))
    tail_chars = max(1, content_chars - head_chars)
    return text[:head_chars] + marker + text[-tail_chars:]


def _truncate_head_tail_tokens(
    tokens: list[int],
    max_tokens: int,
    label: str,
    encoding: TokenEncoding,
    *,
    head_ratio: float,
) -> str:
    marker = _marker(label, len(tokens), max_tokens)
    marker_tokens = _encode(marker) or []
    content_budget = max(2, max_tokens - len(marker_tokens))
    head_tokens = max(1, int(content_budget * head_ratio))
    tail_tokens = max(1, content_budget - head_tokens)
    return (
        encoding.decode(tokens[:head_tokens])
        + marker
        + encoding.decode(tokens[-tail_tokens:])
    )


def _truncate_head_only_tokens(
    text: str,
    tokens: list[int],
    max_tokens: int,
    label: str,
    encoding: TokenEncoding,
) -> str:
    marker = _marker(label, len(tokens), max_tokens)
    marker_tokens = _encode(marker) or []
    content_budget = max(1, max_tokens - len(marker_tokens))
    return encoding.decode(tokens[:content_budget]) + marker


def _truncate_top_matches(text: str, max_tokens: int, label: str) -> str:
    lines = text.splitlines()
    original_tokens = estimate_tokens(text)
    marker = _marker(label, original_tokens, max_tokens)
    marker_tokens = len(_encode(marker) or [])
    budget = max(0, max_tokens - marker_tokens)
    kept: list[str] = []
    running = 0
    for line in lines:
        cost = estimate_tokens(line) + 1  # +1 approximates the newline separator
        if running + cost > budget:
            break
        kept.append(line)
        running += cost
    if len(kept) == len(lines):
        return text
    kept_text = "\n".join(kept)
    return kept_text + _marker(label, original_tokens, running)


def _truncate_top_matches_by_chars(text: str, max_chars: int, label: str) -> str:
    lines = text.splitlines()
    original_tokens = estimate_tokens(text)
    marker = _marker(label, original_tokens, max_chars // _CHARS_PER_TOKEN)
    marker_len = len(marker)
    budget = max(0, max_chars - marker_len)
    kept: list[str] = []
    running = 0
    for line in lines:
        cost = len(line) + (1 if kept else 0)  # +1 for "\n" between lines
        if running + cost > budget:
            break
        kept.append(line)
        running += cost
    if len(kept) == len(lines):
        return text
    kept_text = "\n".join(kept)
    return kept_text + _marker(label, original_tokens, running // _CHARS_PER_TOKEN)


@lru_cache(maxsize=512)
def _encode(text: str) -> list[int] | None:
    encoding = _encoding()
    if encoding is None:
        return None
    return encoding.encode(text)


_tiktoken_encoding: TokenEncoding | None = None
_tiktoken_loaded = False


def _encoding() -> TokenEncoding | None:
    global _tiktoken_encoding, _tiktoken_loaded
    if not _tiktoken_loaded:
        try:
            import tiktoken

            _tiktoken_encoding = tiktoken.get_encoding("o200k_base")
        except ImportError:
            pass
        _tiktoken_loaded = True
    return _tiktoken_encoding
