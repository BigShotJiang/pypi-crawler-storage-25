"""Renderer registry for tool output truncation."""

from __future__ import annotations

from collections.abc import Callable

_TRUNCATION_RENDERERS: dict[type, Callable[..., str]] = {}


def register_renderer(result_type: type, renderer: Callable[..., str]) -> None:
    """Register a renderer function for a specific result type."""
    _TRUNCATION_RENDERERS[result_type] = renderer


def _find_renderer(result: object) -> Callable[..., str] | None:
    """Find a renderer for the given result object by walking the MRO."""
    for cls in type(result).__mro__:
        if cls in _TRUNCATION_RENDERERS:
            return _TRUNCATION_RENDERERS[cls]
    return None
