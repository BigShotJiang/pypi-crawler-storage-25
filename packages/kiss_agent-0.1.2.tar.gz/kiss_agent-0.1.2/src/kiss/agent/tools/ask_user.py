"""Ask-user tool for mid-turn clarification."""

from __future__ import annotations

import asyncio
from typing import Literal

from kiss.core.deps import AgentDeps
from kiss.core.events import QuestionOption
from kiss.core.types import AskUserRequest

from mirascope import llm


async def ask_user(
    ctx: llm.Context[AgentDeps],
    question: str,
    *,
    header: str = "Question",
    type: Literal["choice", "text", "yesno", "choice_or_text"] = "text",
    options: list[str] | None = None,
    default_id: str | None = None,
    multi_select: bool = False,
    placeholder: str | None = None,
) -> str:
    """Ask the human user a concise clarification question and wait for the answer.

    Rich parameters (options, type, etc.) are optional. When omitted the tool
    falls back to a plain text question.
    """
    if ctx.deps.on_ask_user is None:
        return "Unable to ask the user: this interface does not support mid-turn questions."

    # Build QuestionOption list from simple string labels if provided.
    opts: list[QuestionOption] = []
    if options:
        for label in options:
            opt_id = _slugify(label)
            opts.append(QuestionOption(id=opt_id, label=label))

    req = AskUserRequest(
        question=question,
        header=header,
        type=type,
        options=opts,
        default_id=default_id,
        multi_select=multi_select,
        placeholder=placeholder,
    )

    try:
        reply = await asyncio.wait_for(ctx.deps.on_ask_user(req), timeout=300)
    except asyncio.TimeoutError:
        if not req.reply_future.done():
            req.reply_future.cancel()
        return "The user did not respond in time. Do not ask again; try a different approach."

    if reply.outcome == "cancelled":
        return "The user cancelled the question. Do not ask again; try a different approach."
    return reply.as_text()


def _slugify(label: str) -> str:
    """Derive a stable option ID from a human-readable label."""
    import re

    cleaned = re.sub(r"[^a-zA-Z0-9_\-]", "_", label.lower().strip())
    cleaned = re.sub(r"_+", "_", cleaned).strip("_")
    return cleaned or "option"
