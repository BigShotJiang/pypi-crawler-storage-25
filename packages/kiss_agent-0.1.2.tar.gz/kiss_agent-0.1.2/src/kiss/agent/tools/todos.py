"""Session-scoped todo tracking and team coordination tools."""

from __future__ import annotations

from datetime import UTC, datetime

from mirascope import llm

from kiss.core.deps import AgentDeps
from kiss.core.events import Event, EventKind
from kiss.core.usage import TeamMessage, TodoItem

_TEAM_MESSAGES_CAP = 100


def _next_id(todos: list[TodoItem]) -> str:
    max_n = 0
    for todo in todos:
        if todo.id.startswith("t-"):
            try:
                n = int(todo.id[2:])
                if n > max_n:
                    max_n = n
            except ValueError:
                pass
    return f"t-{max_n + 1:04d}"


def _resolve_todo(todos: list[TodoItem], query: str) -> TodoItem | str | None:
    """Resolve a todo by id, exact text, or fuzzy text match.

    Returns:
      TodoItem  — unique match found
      str       — ambiguity message when multiple candidates score too closely
      None      — no match above threshold
    """
    from kiss.ui.fuzzy import resolve_todo_text

    pairs = [(todo.id, todo.text) for todo in todos]
    result = resolve_todo_text(query, pairs)

    if not result.matched:
        return None
    if result.ambiguous:
        ids = ", ".join(c.value for c in result.candidates[:3])
        return f"Ambiguous: multiple todos match '{query}' — be more specific ({ids})"
    todo_id = result.suggestion
    for todo in todos:
        if todo.id == todo_id:
            return todo
    return None


async def _emit_todo_update(ctx: llm.Context[AgentDeps]) -> None:
    if ctx.deps.on_event:
        meta = ctx.deps.todo_normalizer.compute(ctx.deps.todos)
        await ctx.deps.on_event(
            Event(
                kind=EventKind.TODO_UPDATE,
                todos=ctx.deps.todos[:],
                todo_meta=meta,
            )
        )


async def add_todo(ctx: llm.Context[AgentDeps], text: str) -> str:
    """Add a new task to the board. Returns the assigned id (e.g. t-0001). Use claim_todo to take ownership."""
    new_id = _next_id(ctx.deps.todos)
    ctx.deps.todos.append(TodoItem(text=text, done=False, id=new_id, status="pending"))
    await _emit_todo_update(ctx)
    return f"Added: {text} [{new_id}]"


async def done_todo(ctx: llm.Context[AgentDeps], text: str) -> str:
    """Mark a todo as done by id or text match. Legacy tool — enforces ownership."""
    todo = _resolve_todo(ctx.deps.todos, text)
    if todo is None:
        return f"No matching todo found for: {text}"
    if isinstance(todo, str):
        return todo

    acting = ctx.deps.agent_label
    if todo.owner is not None and todo.owner != acting:
        return (
            f"Ownership mismatch: {todo.id} owned by '{todo.owner}', "
            f"acting agent is '{acting}'"
        )

    todo.done = True
    todo.status = "done"
    await _emit_todo_update(ctx)
    return f"Done: {todo.text}"


async def list_todos(ctx: llm.Context[AgentDeps]) -> str:
    """Read the current task board once. Do NOT call repeatedly — board state only changes after add/claim/complete/block/unblock mutations."""
    if not ctx.deps.todos:
        return "No todos."

    lines = [f"Todos ({len(ctx.deps.todos)}):"]
    for todo in ctx.deps.todos:
        owner_part = f" ({todo.owner})" if todo.owner else ""
        reason_part = f" — blocked: {todo.block_reason}" if todo.block_reason else ""
        deps_part = f" [needs: {', '.join(todo.blocked_by)}]" if todo.blocked_by else ""
        lines.append(
            f"{todo.id} [{todo.status}]{owner_part} {todo.text}{reason_part}{deps_part}"
        )

    return "\n".join(lines)


async def claim_todo(ctx: llm.Context[AgentDeps], text: str, owner: str) -> str:
    """Take ownership of a pending task. Sets status to in_progress and owner to the given role. Use the task id (e.g. t-0001) or a unique text substring."""
    todo = _resolve_todo(ctx.deps.todos, text)
    if todo is None:
        return f"No matching todo found for: {text}"
    if isinstance(todo, str):
        return todo

    todo.done = False
    todo.owner = owner
    todo.status = "in_progress"
    await _emit_todo_update(ctx)
    return f"Claimed [{todo.id}]: {todo.text} → owner: {owner}"


async def complete_todo(
    ctx: llm.Context[AgentDeps], text: str, owner: str | None = None
) -> str:
    """Mark a claimed task done. Validates ownership against explicit owner or the acting agent label."""
    todo = _resolve_todo(ctx.deps.todos, text)
    if todo is None:
        return f"No matching todo found for: {text}"
    if isinstance(todo, str):
        return todo

    if owner is not None:
        if todo.owner is not None and todo.owner != owner:
            return (
                f"Ownership mismatch: {todo.id} owned by '{todo.owner}', not '{owner}'"
            )
    else:
        acting = ctx.deps.agent_label
        if todo.owner is not None and todo.owner != acting:
            return f"Ownership mismatch: {todo.id} owned by '{todo.owner}', acting agent is '{acting}'"

    todo.done = True
    todo.status = "done"
    todo.owner = owner or todo.owner
    await _emit_todo_update(ctx)
    return f"Completed [{todo.id}]: {todo.text}"


async def block_todo(
    ctx: llm.Context[AgentDeps],
    text: str,
    reason: str,
    blocked_by: list[str] | None = None,
) -> str:
    """Block a todo with a reason and optional dependency hints (task ids or labels)."""
    todo = _resolve_todo(ctx.deps.todos, text)
    if todo is None:
        return f"No matching todo found for: {text}"
    if isinstance(todo, str):
        return todo

    deps_hints: list[str] = []
    if blocked_by:
        deps_hints = [str(h) for h in blocked_by if isinstance(h, str) and h.strip()]

    todo.done = False
    todo.status = "blocked"
    todo.block_reason = reason
    todo.blocked_by = deps_hints
    await _emit_todo_update(ctx)
    deps_part = f", blocked_by: {deps_hints}" if deps_hints else ""
    return f"Blocked [{todo.id}]: {todo.text} — reason: {reason}{deps_part}"


async def unblock_todo(ctx: llm.Context[AgentDeps], text: str) -> str:
    """Unblock a todo, resetting it to pending status."""
    todo = _resolve_todo(ctx.deps.todos, text)
    if todo is None:
        return f"No matching todo found for: {text}"
    if isinstance(todo, str):
        return todo

    todo.done = False
    todo.status = "pending"
    todo.block_reason = None
    todo.blocked_by = []
    await _emit_todo_update(ctx)
    return f"Unblocked [{todo.id}]: {todo.text} → pending"


async def post_team_message(
    ctx: llm.Context[AgentDeps], message: str, to: str = "all"
) -> str:
    """Post a message to the team message bus. 'to' is a role/agent label or 'all'."""
    sender = ctx.deps.agent_label or "kiss-agent"
    msg = TeamMessage(
        sender=sender, recipient=to, text=message, timestamp=datetime.now(UTC)
    )
    ctx.deps.team_messages.append(msg)

    if len(ctx.deps.team_messages) > _TEAM_MESSAGES_CAP:
        ctx.deps.team_messages[:] = ctx.deps.team_messages[-_TEAM_MESSAGES_CAP:]

    if ctx.deps.on_event:
        await ctx.deps.on_event(
            Event(kind=EventKind.INFO, info=f"[msg:{sender}→{to}] {message}")
        )

    return f"Message posted to '{to}'"


async def read_team_messages(
    ctx: llm.Context[AgentDeps], target: str = "all", limit: int = 20
) -> str:
    """Read team messages. 'target' filters by recipient ('all' returns all messages)."""
    limit = max(1, min(limit, _TEAM_MESSAGES_CAP))

    msgs = ctx.deps.team_messages
    if target != "all":
        msgs = [m for m in msgs if m.recipient == target or m.recipient == "all"]
    msgs = msgs[-limit:]

    if not msgs:
        return "No messages."

    lines = [f"Messages ({len(msgs)}):"]
    for m in msgs:
        ts = m.timestamp.strftime("%H:%M:%S")
        lines.append(f"  [{ts}] {m.sender}→{m.recipient}: {m.text}")
    return "\n".join(lines)
