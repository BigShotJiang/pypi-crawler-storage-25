"""Deterministic hints for well-known shell exit codes."""

from __future__ import annotations

_HINTS: dict[int, str] = {
    13: "Permission denied (EACCES) — check file or directory permissions.",
    126: "Command not executable — check file permissions (chmod +x).",
    127: "Command not found — verify the tool is installed and on PATH.",
}


def get_hint(exit_code: int | None) -> str | None:
    """Return a hint string for a known exit code, or None."""
    if exit_code is None:
        return None
    return _HINTS.get(exit_code)
