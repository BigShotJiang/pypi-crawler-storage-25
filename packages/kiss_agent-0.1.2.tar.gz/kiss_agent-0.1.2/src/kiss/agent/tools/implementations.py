"""Tool implementations for all workers.

This module contains all tool implementations for coder, researcher, and reviewer.
Most tools are shared across roles; some have role-specific variants.
The registry applies @llm.tool decorators dynamically based on role.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Literal
from urllib.parse import urlparse

from mirascope import llm

from kiss.agent.permissions import (
    _is_outside_workspace,
    file_write_action,
    git_read_action,
    git_write_action,
    shell_command_action,
    tool_access_action,
)
from kiss.agent.tools.git import git_commit as _git_commit
from kiss.agent.tools.git import git_diff as _git_diff
from kiss.agent.tools.git import git_log as _git_log
from kiss.agent.tools.git import git_stage as _git_stage
from kiss.agent.tools.git import git_status as _git_status
from kiss.agent.tools.git import git_unstage as _git_unstage
from kiss.agent.tools.file import apply_patch as _apply_patch
from kiss.agent.tools.file import edit_file as _edit_file
from kiss.agent.tools.file import read_file as _read_file
from kiss.agent.tools.file import write_file as _write_file
from kiss.agent.tools.shell import run_bash as _run_bash
from kiss.agent.tools.shell_hints import get_hint as _get_shell_hint
from kiss.agent.tools.analysis import analyze_code as _analyze_code
from kiss.agent.tools.analysis import check_style as _check_style
from kiss.agent.tools.analysis import document_symbols as _document_symbols
from kiss.agent.tools.analysis import find_definition as _find_definition
from kiss.agent.tools.analysis import find_references as _find_references
from kiss.agent.tools.analysis import workspace_symbols as _workspace_symbols
from kiss.agent.tools.code import glob as _glob
from kiss.agent.tools.code import list_directory as _list_directory
from kiss.agent.tools.code import search_code as _search_code
from kiss.agent.tools.web import fetch_url as _fetch_url
from kiss.agent.tools.web import web_search as _web_search
from kiss.agent.tools.result_types import (
    AnalyzeCodeResult,
    CheckStyleResult,
    DefinitionResult,
    DocumentSymbolsResult,
    EditFileResult,
    FetchUrlResult,
    GitCommitResult,
    GitDiffResult,
    GitLogResult,
    GitStageResult,
    GitStatusResult,
    GlobResult,
    ListDirectoryResult,
    ReadFileResult,
    ReferencesResult,
    RunCommandResult,
    SearchCodeResult,
    ToolResultMeta,
    WebSearchResult,
    WorkspaceSymbolsResult,
    WriteFileResult,
)
from kiss.core.deps import AgentDeps


def _workspace_root_or_error(ctx: llm.Context[AgentDeps]) -> Path | str:
    workspace_root = ctx.deps.workspace_root
    if workspace_root is None:
        return "Error: workspace root is not configured."
    return workspace_root


async def _check_permission(
    ctx: llm.Context[AgentDeps],
    action: Any,
) -> bool:
    """Return True if permission granted or no callback wired; False if denied."""
    if ctx.deps.confirm_permission is None:
        return True
    return await ctx.deps.confirm_permission(action)


# ============= CODER TOOLS =============


async def read_file_coder(
    ctx: llm.Context[AgentDeps],
    path: str,
    offset: int = 1,
    limit: int | None = None,
) -> ReadFileResult:
    """Read a file or 1-based line window before editing existing content."""
    if ctx.deps.confirm_permission and _is_outside_workspace(
        path, ctx.deps.workspace_root
    ):
        if not await _check_permission(
            ctx,
            tool_access_action(
                "read_file",
                str(Path(path).resolve()),
                message=f"read_file outside workspace: {path}",
            ),
        ):
            return ReadFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=(
                        f"Permission denied: cannot read {path} "
                        "(outside working directory)."
                    ),
                ),
                path=str(Path(path).resolve()),
                exists=True,
                is_file=True,
            )
    return await _read_file(path, offset=offset, limit=limit)


async def write_file(
    ctx: llm.Context[AgentDeps], path: str, content: str
) -> WriteFileResult:
    """Create or overwrite one file with complete content, including parent dirs."""
    if ctx.deps.confirm_permission:
        workspace_root = _workspace_root_or_error(ctx)
        if isinstance(workspace_root, str):
            return WriteFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="execution_failed",
                    error_message=workspace_root,
                ),
                path=str(Path(path).resolve()),
            )
        action = file_write_action("write_file", path, workspace_root)
        if not await _check_permission(ctx, action):
            return WriteFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=f"Permission denied: cannot write to {path}",
                ),
                path=str(Path(path).resolve()),
            )
    return await _write_file(path, content)


async def edit_file(
    ctx: llm.Context[AgentDeps], path: str, old_text: str, new_text: str
) -> EditFileResult:
    """Replace one exact text block in an existing file; read first and match old_text exactly."""
    if ctx.deps.confirm_permission:
        workspace_root = _workspace_root_or_error(ctx)
        if isinstance(workspace_root, str):
            return EditFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="execution_failed",
                    error_message=workspace_root,
                ),
                path=str(Path(path).resolve()),
            )
        action = file_write_action("edit_file", path, workspace_root)
        if not await _check_permission(ctx, action):
            return EditFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=f"Permission denied: cannot edit {path}",
                ),
                path=str(Path(path).resolve()),
            )
    return await _edit_file(path, old_text, new_text)


async def apply_patch(
    ctx: llm.Context[AgentDeps], path: str, changes: list[dict[str, str]]
) -> EditFileResult:
    """Apply multiple exact-match changes atomically to one file.

    Each change must include old_text and new_text. An optional label helps
    identify failed changes.
    """
    if ctx.deps.confirm_permission:
        workspace_root = _workspace_root_or_error(ctx)
        if isinstance(workspace_root, str):
            return EditFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="execution_failed",
                    error_message=workspace_root,
                ),
                path=str(Path(path).resolve()),
                requested_change_count=len(changes),
            )
        action = file_write_action("apply_patch", path, workspace_root)
        if not await _check_permission(ctx, action):
            return EditFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=f"Permission denied: cannot edit {path}",
                ),
                path=str(Path(path).resolve()),
                requested_change_count=len(changes),
            )
    return await _apply_patch(path, changes)


async def git_status(
    ctx: llm.Context[AgentDeps], repo_path: str = "."
) -> GitStatusResult:
    """Inspect git repository status in structured form."""
    if ctx.deps.confirm_permission:
        action = git_read_action("git_status", repo_path)
        if not await _check_permission(ctx, action):
            return GitStatusResult(
                repo_path=str(Path(repo_path).resolve()),
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=f"Permission denied: cannot inspect {repo_path}.",
                ),
            )
    return await _git_status(repo_path)


async def git_diff(
    ctx: llm.Context[AgentDeps],
    repo_path: str = ".",
    staged: bool = False,
) -> GitDiffResult:
    """Inspect git diff for the working tree or staged changes."""
    if ctx.deps.confirm_permission:
        action = git_read_action("git_diff", repo_path)
        if not await _check_permission(ctx, action):
            return GitDiffResult(
                repo_path=str(Path(repo_path).resolve()),
                staged=staged,
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=f"Permission denied: cannot inspect {repo_path}.",
                ),
            )
    return await _git_diff(repo_path, staged=staged)


async def git_log(
    ctx: llm.Context[AgentDeps], repo_path: str = ".", limit: int = 10
) -> GitLogResult:
    """Inspect recent git commit history in structured form."""
    if ctx.deps.confirm_permission:
        action = git_read_action("git_log", repo_path)
        if not await _check_permission(ctx, action):
            return GitLogResult(
                repo_path=str(Path(repo_path).resolve()),
                limit=limit,
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=f"Permission denied: cannot inspect {repo_path}.",
                ),
            )
    return await _git_log(repo_path, limit=limit)


async def git_stage(
    ctx: llm.Context[AgentDeps],
    repo_path: str = ".",
    paths: list[str] | None = None,
) -> GitStageResult:
    """Stage selected files in a repository."""
    requested_paths = paths or []
    if ctx.deps.confirm_permission:
        action = git_write_action("git_stage", repo_path)
        if not await _check_permission(ctx, action):
            return GitStageResult(
                repo_path=str(Path(repo_path).resolve()),
                operation="stage",
                path_count=len(requested_paths),
                affected_paths=requested_paths,
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=f"Permission denied: cannot stage in {repo_path}.",
                ),
            )
    return await _git_stage(repo_path, paths=requested_paths)


async def git_unstage(
    ctx: llm.Context[AgentDeps],
    repo_path: str = ".",
    paths: list[str] | None = None,
) -> GitStageResult:
    """Unstage selected files in a repository without changing working tree content."""
    requested_paths = paths or []
    if ctx.deps.confirm_permission:
        action = git_write_action("git_unstage", repo_path)
        if not await _check_permission(ctx, action):
            return GitStageResult(
                repo_path=str(Path(repo_path).resolve()),
                operation="unstage",
                path_count=len(requested_paths),
                affected_paths=requested_paths,
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=(
                        f"Permission denied: cannot unstage in {repo_path}."
                    ),
                ),
            )
    return await _git_unstage(repo_path, paths=requested_paths)


async def git_commit(
    ctx: llm.Context[AgentDeps],
    message: str,
    paths: list[str] | None = None,
    repo_path: str = ".",
) -> GitCommitResult:
    """Create a commit from an explicitly staged file set."""
    requested_paths = paths or []
    if ctx.deps.confirm_permission:
        action = git_write_action("git_commit", repo_path)
        if not await _check_permission(ctx, action):
            return GitCommitResult(
                repo_path=str(Path(repo_path).resolve()),
                message=message,
                committed_paths=requested_paths,
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=f"Permission denied: cannot commit in {repo_path}.",
                ),
            )
    return await _git_commit(
        message=message, paths=requested_paths, repo_path=repo_path
    )


async def run_bash(ctx: llm.Context[AgentDeps], command: str) -> RunCommandResult:
    """Run one shell command and return structured stdout, stderr, exit code, and hints."""
    if ctx.deps.confirm_permission:
        workspace_root = _workspace_root_or_error(ctx)
        if isinstance(workspace_root, str):
            return RunCommandResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="execution_failed",
                    error_message=workspace_root,
                ),
                command=command,
            )
        action = shell_command_action(command)
        if not await _check_permission(ctx, action):
            return RunCommandResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=f"Permission denied: cannot run {command}.",
                ),
                command=command,
            )
    result = await _run_bash(command)
    hint = _get_shell_hint(result.exit_code)
    if hint is not None:
        result.hint = hint
    return result


# ============= RESEARCHER TOOLS =============


async def read_file_researcher(
    ctx: llm.Context[AgentDeps],
    path: str,
    offset: int = 1,
    limit: int | None = None,
) -> ReadFileResult:
    """Read a file or 1-based line window to verify search hits and local context."""
    if ctx.deps.confirm_permission and _is_outside_workspace(
        path, ctx.deps.workspace_root
    ):
        if not await _check_permission(
            ctx,
            tool_access_action(
                "read_file",
                str(Path(path).resolve()),
                message=f"read_file outside workspace: {path}",
            ),
        ):
            return ReadFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=(
                        f"Permission denied: cannot read {path} "
                        "(outside working directory)."
                    ),
                ),
                path=str(Path(path).resolve()),
                exists=True,
                is_file=True,
            )
    return await _read_file(path, offset=offset, limit=limit)


# ============= RESEARCHER TOOLS =============


async def search_code(
    ctx: llm.Context[AgentDeps],
    pattern: str,
    path_glob: str | None = None,
    max_matches: int = 200,
) -> SearchCodeResult:
    """Search the workspace for a regex pattern, optionally narrowed by path_glob."""
    workspace_root = ctx.deps.workspace_root or Path.cwd()
    resolved_glob = (
        str((workspace_root / path_glob).resolve())
        if path_glob is not None and not Path(path_glob).is_absolute()
        else path_glob
    )
    if resolved_glob is not None and _is_outside_workspace(
        resolved_glob, ctx.deps.workspace_root
    ):
        if ctx.deps.confirm_permission and not await _check_permission(
            ctx,
            tool_access_action(
                "search_code",
                str(Path(resolved_glob).resolve()),
                message=f"search_code outside workspace: {path_glob}",
            ),
        ):
            return SearchCodeResult(
                pattern=pattern,
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=(
                        f"Permission denied: cannot search with path_glob {path_glob} "
                        "(outside working directory)."
                    ),
                ),
            )
    return await _search_code(
        pattern,
        path_glob=path_glob,
        max_matches=max_matches,
        workspace_root=workspace_root,
    )


async def glob(
    ctx: llm.Context[AgentDeps],
    pattern: str,
    max_results: int = 100,
    sort_by: Literal["mtime", "path"] = "mtime",
    include_hidden: bool = False,
    files_only: bool = True,
) -> GlobResult:
    """Match files with Python glob/rglob semantics from the workspace root."""
    workspace_root = ctx.deps.workspace_root or Path.cwd()
    if Path(pattern).is_absolute() and _is_outside_workspace(
        pattern, ctx.deps.workspace_root
    ):
        if ctx.deps.confirm_permission and not await _check_permission(
            ctx,
            tool_access_action(
                "glob",
                str(Path(pattern).resolve()),
                message=f"glob outside workspace: {pattern}",
            ),
        ):
            return GlobResult(
                pattern=pattern,
                root=str(workspace_root.resolve()),
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=(
                        f"Permission denied: cannot glob {pattern} "
                        "(outside working directory)."
                    ),
                ),
            )
    return await _glob(
        pattern,
        workspace_root=workspace_root,
        max_results=max_results,
        sort_by=sort_by,
        include_hidden=include_hidden,
        files_only=files_only,
    )


async def list_directory(
    ctx: llm.Context[AgentDeps], directory: str = ".", max_depth: int = 3
) -> ListDirectoryResult:
    """Browse a directory tree to orient within the workspace before deeper searches."""
    if ctx.deps.confirm_permission and _is_outside_workspace(
        directory, ctx.deps.workspace_root
    ):
        if not await _check_permission(
            ctx,
            tool_access_action(
                "list_directory",
                str(Path(directory).resolve()),
                message=f"list_directory outside workspace: {directory}",
            ),
        ):
            return ListDirectoryResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=(
                        f"Permission denied: cannot browse {directory} "
                        "(outside working directory)."
                    ),
                ),
                root=str(Path(directory).resolve()),
                max_depth=max_depth,
            )
    return await _list_directory(directory, max_depth)


async def fetch_url(
    ctx: llm.Context[AgentDeps],
    url: str,
    method: Literal["GET", "HEAD", "POST"] = "GET",
    mode: Literal["auto", "raw", "extracted"] = "auto",
    headers: dict[str, str] | None = None,
    body: str | None = None,
    timeout_s: float = 10.0,
) -> FetchUrlResult:
    """Fetch an http/https URL and optionally extract readable HTML text."""
    if ctx.deps.confirm_permission:
        action = tool_access_action(
            "fetch_url",
            url,
            message=f"fetch_url remote target: {url}",
            policy_candidates=(url, urlparse(url).hostname or ""),
        )
        if not await _check_permission(ctx, action):
            return FetchUrlResult(
                url=url,
                method=method,
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=f"Permission denied: cannot fetch {url}.",
                ),
            )
    return await _fetch_url(
        url=url,
        method=method,
        mode=mode,
        headers=headers,
        body=body,
        timeout_s=timeout_s,
    )


async def web_search(
    ctx: llm.Context[AgentDeps],
    query: str,
    max_results: int | None = None,
) -> WebSearchResult:
    """Search the web for current information and return structured results."""
    if ctx.deps.confirm_permission:
        action = tool_access_action(
            "web_search",
            query,
            message=f"web_search query: {query}",
            policy_candidates=(query,),
        )
        if not await _check_permission(ctx, action):
            return WebSearchResult(
                query=query,
                provider=ctx.deps.web_search_config.provider,
                max_results=max_results or ctx.deps.web_search_config.max_results,
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=(f"Permission denied: cannot search for {query}."),
                ),
            )
    return await _web_search(
        query=query,
        max_results=max_results,
        config=ctx.deps.web_search_config,
    )


async def analyze_code(ctx: llm.Context[AgentDeps], path: str) -> AnalyzeCodeResult:
    """Analyze structural metrics and issues for a Python or JSON file."""
    if ctx.deps.confirm_permission:
        action = tool_access_action(
            "analyze_code",
            path,
            message=f"analyze_code path: {path}",
        )
        if not await _check_permission(ctx, action):
            return AnalyzeCodeResult(
                path=path,
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=f"Permission denied: cannot analyze {path}.",
                ),
            )
    return await _analyze_code(path)


async def check_style(
    ctx: llm.Context[AgentDeps], path: str, ruleset: str | None = None
) -> CheckStyleResult:
    """Run tool-backed style checks for Python and structured validation for JSON."""
    if ctx.deps.confirm_permission:
        action = tool_access_action(
            "check_style",
            path,
            message=f"check_style path: {path}",
        )
        if not await _check_permission(ctx, action):
            return CheckStyleResult(
                path=path,
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=f"Permission denied: cannot check {path}.",
                ),
            )
    return await _check_style(path, ruleset)


async def find_definition(
    ctx: llm.Context[AgentDeps],
    symbol: str,
    path: str | None = None,
) -> DefinitionResult:
    """Find a Python symbol definition within the workspace."""
    if ctx.deps.confirm_permission:
        action = tool_access_action(
            "find_definition",
            symbol,
            message=f"find_definition symbol: {symbol}",
            policy_candidates=tuple(
                candidate for candidate in (symbol, path or "") if candidate
            ),
        )
        if not await _check_permission(ctx, action):
            return DefinitionResult(
                query=symbol,
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=(
                        f"Permission denied: cannot inspect definition for {symbol}."
                    ),
                ),
            )
    workspace_root = ctx.deps.workspace_root or Path.cwd()
    return await _find_definition(symbol, path=path, workspace_root=workspace_root)


async def find_references(
    ctx: llm.Context[AgentDeps],
    symbol: str,
    max_results: int = 100,
) -> ReferencesResult:
    """Find Python symbol references across the workspace."""
    if ctx.deps.confirm_permission:
        action = tool_access_action(
            "find_references",
            symbol,
            message=f"find_references symbol: {symbol}",
        )
        if not await _check_permission(ctx, action):
            return ReferencesResult(
                query=symbol,
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=(
                        f"Permission denied: cannot inspect references for {symbol}."
                    ),
                ),
            )
    workspace_root = ctx.deps.workspace_root or Path.cwd()
    return await _find_references(
        symbol,
        workspace_root=workspace_root,
        max_results=max_results,
    )


async def document_symbols(
    ctx: llm.Context[AgentDeps], path: str
) -> DocumentSymbolsResult:
    """List structural symbols for a Python or JSON document."""
    if ctx.deps.confirm_permission:
        action = tool_access_action(
            "document_symbols",
            path,
            message=f"document_symbols path: {path}",
        )
        if not await _check_permission(ctx, action):
            return DocumentSymbolsResult(
                path=path,
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=(
                        f"Permission denied: cannot inspect symbols for {path}."
                    ),
                ),
            )
    return await _document_symbols(path)


async def workspace_symbols(
    ctx: llm.Context[AgentDeps], query: str, max_results: int = 50
) -> WorkspaceSymbolsResult:
    """Search workspace symbols across Python and JSON files."""
    if ctx.deps.confirm_permission:
        action = tool_access_action(
            "workspace_symbols",
            query,
            message=f"workspace_symbols query: {query}",
        )
        if not await _check_permission(ctx, action):
            return WorkspaceSymbolsResult(
                query=query,
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=(
                        f"Permission denied: cannot inspect symbols for {query}."
                    ),
                ),
            )
    workspace_root = ctx.deps.workspace_root or Path.cwd()
    return await _workspace_symbols(
        query,
        workspace_root=workspace_root,
        max_results=max_results,
    )


async def git_status_researcher(
    ctx: llm.Context[AgentDeps], repo_path: str = "."
) -> GitStatusResult:
    """Inspect git repository status in structured form."""
    if ctx.deps.confirm_permission:
        action = git_read_action("git_status", repo_path)
        if not await _check_permission(ctx, action):
            return GitStatusResult(
                repo_path=str(Path(repo_path).resolve()),
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=f"Permission denied: cannot inspect {repo_path}.",
                ),
            )
    return await _git_status(repo_path)


async def git_diff_researcher(
    ctx: llm.Context[AgentDeps],
    repo_path: str = ".",
    staged: bool = False,
) -> GitDiffResult:
    """Inspect git diff for the working tree or staged changes."""
    if ctx.deps.confirm_permission:
        action = git_read_action("git_diff", repo_path)
        if not await _check_permission(ctx, action):
            return GitDiffResult(
                repo_path=str(Path(repo_path).resolve()),
                staged=staged,
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=f"Permission denied: cannot inspect {repo_path}.",
                ),
            )
    return await _git_diff(repo_path, staged=staged)


async def git_log_researcher(
    ctx: llm.Context[AgentDeps], repo_path: str = ".", limit: int = 10
) -> GitLogResult:
    """Inspect recent git commit history in structured form."""
    if ctx.deps.confirm_permission:
        action = git_read_action("git_log", repo_path)
        if not await _check_permission(ctx, action):
            return GitLogResult(
                repo_path=str(Path(repo_path).resolve()),
                limit=limit,
                meta=ToolResultMeta(
                    ok=False,
                    error_code="permission_denied",
                    error_message=f"Permission denied: cannot inspect {repo_path}.",
                ),
            )
    return await _git_log(repo_path, limit=limit)


# Reviewer read_file is the same as researcher
read_file_reviewer = read_file_researcher
