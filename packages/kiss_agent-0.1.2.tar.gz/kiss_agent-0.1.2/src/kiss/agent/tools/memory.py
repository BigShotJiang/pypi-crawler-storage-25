"""Memory tools — append-only markdown memory persisted across sessions"""

from __future__ import annotations

from pathlib import Path

import aiofiles
import aiofiles.os

_MEMORY_CAP = 100
_GLOBAL_MEMORY_PATH = Path.home() / ".kiss" / "memory.md"


def _memory_path(scope: str, workspace_root: Path) -> Path:
    if scope == "global":
        return _GLOBAL_MEMORY_PATH
    return workspace_root / ".kiss" / "memory.md"


async def load_memory_block(workspace_root: Path) -> str:
    """Return a formatted prelude containing any saved global and project memory."""
    parts: list[str] = []
    global_path = _GLOBAL_MEMORY_PATH
    project_path = workspace_root / ".kiss" / "memory.md"

    if await aiofiles.os.path.exists(str(global_path)):
        async with aiofiles.open(global_path, encoding="utf-8") as f:
            parts.append(f"[Global memory]\n{await f.read()}")
    if await aiofiles.os.path.exists(str(project_path)):
        async with aiofiles.open(project_path, encoding="utf-8") as f:
            parts.append(f"[Project memory]\n{await f.read()}")

    if not parts:
        return ""
    return "\n\n".join(parts)


async def append_memory(text: str, scope: str, workspace_root: Path) -> str:
    """Append one bullet to global or project memory, trimming to the configured cap."""
    if scope not in ("global", "project"):
        return "invalid scope: must be 'global' or 'project'"

    path = _memory_path(scope, workspace_root)
    await aiofiles.os.makedirs(str(path.parent), exist_ok=True)

    if await aiofiles.os.path.exists(str(path)):
        async with aiofiles.open(path, encoding="utf-8") as f:
            existing = await f.read()
    else:
        existing = ""

    # Ensure a newline separator before the new bullet
    if existing and not existing.endswith("\n"):
        existing += "\n"

    lines = existing.splitlines(keepends=True)
    lines.append(f"- {text}\n")

    if len(lines) > _MEMORY_CAP:
        lines = lines[len(lines) - _MEMORY_CAP :]

    async with aiofiles.open(path, "w", encoding="utf-8") as f:
        await f.write("".join(lines))
    return f"Saved to {scope} memory."


async def read_memory(scope: str, workspace_root: Path) -> str:
    """Read global, project, or both memory scopes as plain markdown text."""
    if scope == "both":
        parts: list[str] = []
        global_path = _GLOBAL_MEMORY_PATH
        project_path = workspace_root / ".kiss" / "memory.md"
        if await aiofiles.os.path.exists(str(global_path)):
            async with aiofiles.open(global_path, encoding="utf-8") as f:
                parts.append(await f.read())
        else:
            parts.append("No global memory.")
        if await aiofiles.os.path.exists(str(project_path)):
            async with aiofiles.open(project_path, encoding="utf-8") as f:
                parts.append(await f.read())
        else:
            parts.append("No project memory.")
        return "\n\n".join(parts)

    if scope not in ("global", "project"):
        return "invalid scope: must be 'global', 'project', or 'both'"

    path = _memory_path(scope, workspace_root)
    if await aiofiles.os.path.exists(str(path)):
        async with aiofiles.open(path, encoding="utf-8") as f:
            return await f.read()
    return f"No {scope} memory."


def recall_memory(session_id: str, memory_id: str, db_path: Path) -> str:
    """Return raw source event evidence for an observation or reflection ID."""
    from kiss.core.session_db import SessionDB
    from kiss.core.memory import recall

    db = SessionDB(db_path)
    try:
        return recall(db, session_id, memory_id)
    finally:
        db.close()


def memory_fts_search_tool(
    session_id: str, query: str, db_path: Path, limit: int = 10
) -> str:
    """FTS5 BM25 search over observations and reflections."""
    from kiss.core.session_db import SessionDB
    from kiss.core.memory import memory_fts_search

    db = SessionDB(db_path)
    try:
        results = memory_fts_search(db, session_id, query, limit=limit)
        if not results:
            return "No memory matches found."
        lines = [f"Memory search results for '{query}':"]
        for r in results:
            lines.append(f"  [{r['id']}] ({r['type']}) {r.get('content', '')[:120]}")
        return "\n".join(lines)
    finally:
        db.close()
