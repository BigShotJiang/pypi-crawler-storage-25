"""Async JSON-RPC transport for Logic Tool host/guest communication."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
import contextlib
import os
import socket
from typing import Any

import msgspec


class RpcRequest(msgspec.Struct, omit_defaults=True):
    id: int
    method: str
    params: dict[str, Any] = {}


class RpcResponse(msgspec.Struct, omit_defaults=True):
    id: int
    result: Any = None
    error_code: str | None = None
    error_message: str | None = None


_JSON_ENCODER = msgspec.json.Encoder()
_REQUEST_DECODER = msgspec.json.Decoder(RpcRequest)
_RESPONSE_DECODER = msgspec.json.Decoder(RpcResponse)


def _encode_line(message: RpcRequest | RpcResponse) -> bytes:
    return _JSON_ENCODER.encode(message) + b"\n"


class _LineSocket:
    def __init__(self, sock: socket.socket) -> None:
        self.sock = sock
        self.sock.setblocking(False)
        self._buffer = bytearray()

    async def read_line(self) -> bytes:
        loop = asyncio.get_running_loop()
        while True:
            newline = self._buffer.find(b"\n")
            if newline >= 0:
                line = bytes(self._buffer[: newline + 1])
                del self._buffer[: newline + 1]
                return line
            chunk = await loop.sock_recv(self.sock, 65536)
            if not chunk:
                if self._buffer:
                    line = bytes(self._buffer)
                    self._buffer.clear()
                    return line
                return b""
            self._buffer.extend(chunk)

    async def write_line(self, data: bytes) -> None:
        loop = asyncio.get_running_loop()
        await loop.sock_sendall(self.sock, data)

    def close(self) -> None:
        with contextlib.suppress(OSError):
            self.sock.shutdown(socket.SHUT_RDWR)
        self.sock.close()


class SocketRPCClient:
    """Async RPC client used in the guest subprocess."""

    def __init__(self, sock: socket.socket) -> None:
        self._socket = _LineSocket(sock)
        self._next_id = 0
        self._pending: dict[int, asyncio.Future[Any]] = {}
        self._write_lock = asyncio.Lock()
        self._read_task = asyncio.create_task(self._read_loop())

    async def request(self, method: str, params: dict[str, Any]) -> Any:
        self._next_id += 1
        request_id = self._next_id
        loop = asyncio.get_running_loop()
        future: asyncio.Future[Any] = loop.create_future()
        self._pending[request_id] = future
        async with self._write_lock:
            await self._socket.write_line(
                _encode_line(RpcRequest(request_id, method, params))
            )
        return await future

    async def aclose(self) -> None:
        self._socket.close()
        self._read_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await self._read_task

    async def _read_loop(self) -> None:
        try:
            while True:
                line = await self._socket.read_line()
                if not line:
                    break
                response = _RESPONSE_DECODER.decode(line)
                future = self._pending.pop(response.id, None)
                if future is None:
                    continue
                if response.error_code is not None:
                    future.set_exception(
                        RuntimeError(
                            f"{response.error_code}: {response.error_message or ''}".strip()
                        )
                    )
                else:
                    future.set_result(response.result)
        except Exception as exc:
            for future in self._pending.values():
                if not future.done():
                    future.set_exception(exc)
        finally:
            for future in self._pending.values():
                if not future.done():
                    future.set_exception(RuntimeError("RPC connection closed"))
            self._pending.clear()


class SocketRPCServer:
    """Async RPC server used by the host executor."""

    def __init__(
        self,
        sock: socket.socket,
        dispatcher: Callable[[str, dict[str, Any]], Awaitable[Any]],
    ) -> None:
        self._socket = _LineSocket(sock)
        self._dispatcher = dispatcher
        self._write_lock = asyncio.Lock()
        self._tasks: set[asyncio.Task[None]] = set()

    async def serve(self) -> None:
        try:
            while True:
                line = await self._socket.read_line()
                if not line:
                    break
                request = _REQUEST_DECODER.decode(line)
                task = asyncio.create_task(self._handle_request(request))
                self._tasks.add(task)
                task.add_done_callback(self._tasks.discard)
            if self._tasks:
                await asyncio.gather(*self._tasks, return_exceptions=True)
        finally:
            self._socket.close()

    async def _handle_request(self, request: RpcRequest) -> None:
        try:
            result = await self._dispatcher(request.method, request.params)
            response = RpcResponse(id=request.id, result=result)
        except Exception as exc:
            response = RpcResponse(
                id=request.id,
                error_code="rpc_error",
                error_message=str(exc),
            )
        async with self._write_lock:
            await self._socket.write_line(_encode_line(response))


async def connect_client_from_env() -> SocketRPCClient:
    fd = os.environ.get("KISS_LOGIC_SOCKET_FD")
    if fd is None:
        raise RuntimeError("KISS_LOGIC_SOCKET_FD is not set")
    return SocketRPCClient(socket.socket(fileno=int(fd)))


async def create_server(
    sock: socket.socket,
    dispatcher: Callable[[str, dict[str, Any]], Awaitable[Any]],
) -> SocketRPCServer:
    return SocketRPCServer(sock, dispatcher)
