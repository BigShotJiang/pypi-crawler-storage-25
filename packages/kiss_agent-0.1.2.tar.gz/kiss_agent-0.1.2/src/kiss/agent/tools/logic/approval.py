"""Batch approval types for Logic Tool manifest review."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field

from kiss.agent.tools.result_types import PendingChange


@dataclass
class LogicApprovalReply:
    approved: bool


@dataclass
class LogicApprovalRequest:
    pending_changes: list[PendingChange]
    reply_future: asyncio.Future[LogicApprovalReply] = field(
        default_factory=lambda: asyncio.get_running_loop().create_future()
    )
