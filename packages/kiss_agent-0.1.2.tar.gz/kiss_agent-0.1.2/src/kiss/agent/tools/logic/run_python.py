"""run_python tool — executes agent-authored async Python in a subprocess."""

from __future__ import annotations

from mirascope import llm

from kiss.agent.tools.logic.approval import LogicApprovalRequest
from kiss.agent.tools.logic.executor import ShadowWorkspace, SubprocessLogicExecutor
from kiss.agent.tools.result_types import (
    LogicApplyResult,
    LogicExecutionResult,
    ToolResultMeta,
)
from kiss.core.deps import AgentDeps


async def run_python(
    ctx: llm.Context[AgentDeps],
    code: str,
    timeout: float = 30.0,
) -> LogicExecutionResult | LogicApplyResult:
    """Execute async Python logic in a subprocess with host-backed workspace access.

    Proposed file changes are shown as a batch manifest before being applied.
    Use `await kiss.workspace.open(path)` and file methods for all file operations.
    """
    if ctx.deps.workspace_root is None:
        return LogicExecutionResult(
            meta=ToolResultMeta(
                ok=False,
                error_code="execution_failed",
                error_message="Workspace root is not configured.",
            ),
            code=code,
        )

    workspace = ShadowWorkspace(ctx.deps.workspace_root)
    executor = SubprocessLogicExecutor(timeout=timeout)
    exec_result = await executor.execute(code, workspace=workspace)

    if not exec_result.meta.ok:
        return exec_result

    if not exec_result.pending_changes:
        return exec_result

    if ctx.deps.on_logic_approval is None:
        return LogicExecutionResult(
            meta=ToolResultMeta(
                ok=False,
                error_code="execution_failed",
                error_message="run_python: on_logic_approval handler not configured — changes not applied.",
            ),
            code=code,
            pending_changes=exec_result.pending_changes,
        )

    req = LogicApprovalRequest(pending_changes=exec_result.pending_changes)
    reply = await ctx.deps.on_logic_approval(req)

    if not reply.approved:
        return LogicApplyResult(
            meta=ToolResultMeta(
                ok=False,
                error_code="permission_denied",
                error_message="Logic Tool manifest denied by user.",
            ),
            approved=False,
            pending_change_count=len(exec_result.pending_changes),
        )

    return await workspace.apply_all()
