"""Core subprocess execution and shadow workspace primitives for Logic Tool."""

from __future__ import annotations

import asyncio
import contextlib
import difflib
import fnmatch
import hashlib
import os
from dataclasses import dataclass
import glob as globlib
from pathlib import Path
import re
import socket
import subprocess  # nosec B404
import sys
import tempfile

import aiofiles
import aiofiles.os

from kiss.agent.tools.logic.ipc import create_server
from kiss.agent.tools.result_types import (
    LogicApplyResult,
    LogicExecutionResult,
    PendingChange,
    ToolResultMeta,
)

_MAX_LOGIC_OUTPUT_CHARS = 100_000
_MAX_DIFF_PREVIEW_LINES = 200
_TRUNCATION_MARKER = "\n... [truncated] ...\n"
_READ_CONCURRENCY_LIMIT = 4
_SEARCH_EXCLUDE_DIRS = {
    ".git",
    "__pycache__",
    ".venv",
    "venv",
    "node_modules",
    ".mypy_cache",
    ".ruff_cache",
}


def _as_int(value: object, *, default: int) -> int:
    if value is None:
        return default
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        return int(value)
    raise ValueError(f"Expected integer-compatible value, got {type(value).__name__}")


_SAFE_BUILTIN_NAMES = (
    "Exception",
    "RuntimeError",
    "TypeError",
    "ValueError",
    "abs",
    "all",
    "any",
    "bool",
    "dict",
    "enumerate",
    "float",
    "int",
    "len",
    "list",
    "max",
    "min",
    "print",
    "range",
    "reversed",
    "set",
    "str",
    "sum",
    "tuple",
    "zip",
)
_BOOTSTRAP = r"""
import asyncio
import builtins
import os
import sys

from kiss.agent.tools.logic.ipc import connect_client_from_env
from kiss.agent.tools.logic.sdk import KissContext

SAFE_BUILTINS = {name: getattr(builtins, name) for name in os.environ["KISS_SAFE_BUILTINS"].split(",") if name}

source = sys.stdin.read()
globals_dict = {
    "__builtins__": SAFE_BUILTINS,
    "__name__": "__kiss_logic__",
}

exec(compile(source, "<kiss_logic>", "exec"), globals_dict, globals_dict)
logic_fn = globals_dict.get("__kiss_logic__")
if logic_fn is None:
    raise RuntimeError("Wrapped logic function __kiss_logic__ was not defined")

async def _main():
    client = await connect_client_from_env()
    kiss = KissContext(client)
    await logic_fn(kiss)

asyncio.run(_main())
"""


@dataclass(frozen=True)
class FileBaseState:
    path: Path
    existed: bool
    digest: str | None = None


def _truncate_text(text: str, max_chars: int) -> str:
    if len(text) <= max_chars:
        return text
    if max_chars <= len(_TRUNCATION_MARKER):
        return text[:max_chars]
    head = max_chars // 2
    tail = max_chars - head - len(_TRUNCATION_MARKER)
    if tail <= 0:
        return text[: max_chars - len(_TRUNCATION_MARKER)] + _TRUNCATION_MARKER
    return text[:head] + _TRUNCATION_MARKER + text[-tail:]


def _truncate_streams(
    stdout: str, stderr: str, max_chars: int
) -> tuple[str, str, bool]:
    if max_chars <= 0:
        return "", "", True
    total_chars = len(stdout) + len(stderr)
    if total_chars <= max_chars:
        return stdout, stderr, False
    if not stdout:
        return stdout, _truncate_text(stderr, max_chars), True
    if not stderr:
        return _truncate_text(stdout, max_chars), stderr, True

    stdout_budget = (max_chars * len(stdout)) // total_chars
    stderr_budget = max_chars - stdout_budget
    stdout_budget = max(0, stdout_budget)
    stderr_budget = max(0, stderr_budget)
    return (
        _truncate_text(stdout, stdout_budget),
        _truncate_text(stderr, stderr_budget),
        True,
    )


async def _kill_process(process: subprocess.Popen[bytes]) -> None:
    with contextlib.suppress(ProcessLookupError, OSError):
        process.kill()
    with contextlib.suppress(Exception):
        await asyncio.to_thread(process.wait)


async def _sha256_text(path: Path) -> str:
    async with aiofiles.open(path, "rb") as handle:
        content = await handle.read()
    return hashlib.sha256(content).hexdigest()


async def _read_text(path: Path) -> str:
    async with aiofiles.open(path, encoding="utf-8", errors="strict") as handle:
        return await handle.read()


async def _atomic_write(path: Path, content: str) -> None:
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".~{path.name}_")
    os.close(fd)
    try:
        async with aiofiles.open(tmp, "w", encoding="utf-8") as handle:
            await handle.write(content)
        os.replace(tmp, str(path))
    except Exception:
        with contextlib.suppress(OSError):
            os.unlink(tmp)
        raise


def _line_count(content: str) -> int:
    if not content:
        return 0
    return content.count("\n") + (0 if content.endswith("\n") else 1)


def _diff_preview(before: str, after: str, path: str) -> tuple[str, bool]:
    diff_lines = list(
        difflib.unified_diff(
            before.splitlines(),
            after.splitlines(),
            fromfile=f"{path} (before)",
            tofile=f"{path} (after)",
            lineterm="",
        )
    )
    truncated = len(diff_lines) > _MAX_DIFF_PREVIEW_LINES
    if truncated:
        diff_lines = diff_lines[:_MAX_DIFF_PREVIEW_LINES]
    return "\n".join(diff_lines), truncated


class ShadowWorkspace:
    """Host-side virtual workspace for Logic Tool runs."""

    def __init__(self, workspace_root: str | Path) -> None:
        self.workspace_root = Path(workspace_root).resolve()
        self._base_state: dict[Path, FileBaseState] = {}
        self._virtual_state: dict[Path, str] = {}
        self._pending_changes: dict[Path, PendingChange] = {}
        self._pending_order: list[Path] = []
        self._lock = asyncio.Lock()
        self._read_semaphore = asyncio.Semaphore(_READ_CONCURRENCY_LIMIT)

    @property
    def pending_changes(self) -> list[PendingChange]:
        return [self._pending_changes[path] for path in self._pending_order]

    def _resolve_workspace_path(self, path: str | Path) -> Path:
        resolved = (self.workspace_root / path).resolve()
        try:
            resolved.relative_to(self.workspace_root)
        except ValueError as exc:
            raise ValueError(f"Path escapes workspace root: {path}") from exc
        return resolved

    async def _capture_base_state(self, path: Path) -> FileBaseState:
        existing = self._base_state.get(path)
        if existing is not None:
            return existing
        if await aiofiles.os.path.exists(str(path)):
            if await aiofiles.os.path.islink(str(path)):
                raise ValueError(f"Symlink paths are not supported in v1: {path}")
            if not await aiofiles.os.path.isfile(str(path)):
                raise ValueError(f"Only regular files are supported in v1: {path}")
            state = FileBaseState(
                path=path, existed=True, digest=await _sha256_text(path)
            )
        else:
            state = FileBaseState(path=path, existed=False, digest=None)
        self._base_state[path] = state
        return state

    async def exists(self, path: str | Path) -> bool:
        resolved = self._resolve_workspace_path(path)
        async with self._lock:
            if resolved in self._virtual_state:
                return True
            return await aiofiles.os.path.exists(str(resolved))

    async def open_file(self, path: str | Path) -> dict[str, str | bool]:
        resolved = self._resolve_workspace_path(path)
        async with self._read_semaphore:
            async with self._lock:
                await self._capture_base_state(resolved)
                exists = (
                    resolved in self._virtual_state
                    or await aiofiles.os.path.exists(str(resolved))
                )
        return {
            "path": self._display_path(resolved),
            "exists": exists,
        }

    async def read_text(self, path: str | Path) -> str:
        resolved = self._resolve_workspace_path(path)
        return await self.read_window(resolved)

    async def read_window(
        self, path: str | Path, offset: int = 1, limit: int | None = None
    ) -> str:
        if offset < 1:
            raise ValueError("offset must be 1 or greater")
        if limit is not None and limit < 1:
            raise ValueError("limit must be 1 or greater")
        resolved = self._resolve_workspace_path(path)
        async with self._read_semaphore:
            async with self._lock:
                await self._capture_base_state(resolved)
                virtual = self._virtual_state.get(resolved)
            content = virtual if virtual is not None else await _read_text(resolved)
        lines = content.splitlines(keepends=True)
        start_index = offset - 1
        if limit is None:
            return "".join(lines[start_index:])
        return "".join(lines[start_index : start_index + limit])

    async def write_text(self, path: str | Path, content: str) -> PendingChange:
        resolved = self._resolve_workspace_path(path)
        async with self._lock:
            base_state = await self._capture_base_state(resolved)
            before = self._virtual_state.get(resolved)
            if before is None:
                before = "" if not base_state.existed else await _read_text(resolved)
            self._virtual_state[resolved] = content
            change = self._build_pending_change(
                resolved,
                before=""
                if not base_state.existed
                else await self._base_text(resolved),
                after=content,
                existed_before=base_state.existed,
            )
            return self._record_pending_change(resolved, change)

    async def append_text(self, path: str | Path, text: str) -> PendingChange:
        resolved = self._resolve_workspace_path(path)
        current = await self.read_text(resolved) if await self.exists(resolved) else ""
        return await self.write_text(resolved, current + text)

    async def replace_text(
        self,
        path: str | Path,
        old_text: str,
        new_text: str,
        *,
        count: int = -1,
    ) -> PendingChange:
        resolved = self._resolve_workspace_path(path)
        current = await self.read_text(resolved)
        updated = current.replace(old_text, new_text, count)
        if updated == current:
            raise ValueError(f"Replacement text not found in {resolved}")
        return await self.write_text(resolved, updated)

    async def search(
        self,
        pattern: str,
        *,
        path_glob: str | None = None,
        max_matches: int = 200,
    ) -> list[dict[str, str | int]]:
        regex = re.compile(pattern)

        def _search_disk() -> list[dict[str, str | int]]:
            matches: list[dict[str, str | int]] = []
            for root, dirs, files in os.walk(self.workspace_root):
                dirs[:] = [
                    d
                    for d in dirs
                    if d not in _SEARCH_EXCLUDE_DIRS and not d.startswith(".")
                ]
                for name in files:
                    candidate = (Path(root) / name).resolve()
                    rel = self._display_path(candidate)
                    if path_glob is not None and not fnmatch.fnmatch(rel, path_glob):
                        continue
                    if candidate.is_symlink():
                        continue
                    try:
                        content = candidate.read_text(encoding="utf-8")
                    except (UnicodeDecodeError, OSError):
                        continue
                    for idx, line in enumerate(content.splitlines(), start=1):
                        if regex.search(line):
                            matches.append({"path": rel, "line": idx, "text": line})
                            if len(matches) >= max_matches:
                                return matches
            return matches

        async with self._read_semaphore:
            disk_matches = await asyncio.to_thread(_search_disk)

        async with self._lock:
            for path, content in self._virtual_state.items():
                rel = self._display_path(path)
                if path_glob is not None and not fnmatch.fnmatch(rel, path_glob):
                    continue
                disk_matches = [item for item in disk_matches if item["path"] != rel]
                for idx, line in enumerate(content.splitlines(), start=1):
                    if regex.search(line):
                        disk_matches.append({"path": rel, "line": idx, "text": line})
                        if len(disk_matches) >= max_matches:
                            return disk_matches[:max_matches]
        return disk_matches[:max_matches]

    async def glob(
        self, pattern: str, *, max_results: int = 100
    ) -> list[dict[str, str]]:
        def _collect() -> list[dict[str, str]]:
            matches: list[dict[str, str]] = []
            for raw_match in globlib.iglob(
                str(self.workspace_root / pattern),
                recursive=True,
                include_hidden=False,
            ):
                candidate = Path(raw_match).resolve()
                if candidate.is_dir():
                    continue
                if candidate.is_symlink():
                    continue
                matches.append({"path": self._display_path(candidate)})
                if len(matches) >= max_results:
                    break
            return matches

        async with self._read_semaphore:
            return await asyncio.to_thread(_collect)

    async def list_directory(self, path: str = ".", *, max_depth: int = 1) -> list[str]:
        root = self._resolve_workspace_path(path)

        def _collect() -> list[str]:
            entries: list[str] = []
            for current_root, dirs, files in os.walk(root):
                depth = len(Path(current_root).relative_to(root).parts)
                if depth >= max_depth:
                    dirs.clear()
                    continue
                dirs[:] = sorted(
                    d
                    for d in dirs
                    if d not in _SEARCH_EXCLUDE_DIRS and not d.startswith(".")
                )
                for name in sorted(files):
                    rel = (Path(current_root) / name).resolve().relative_to(root)
                    entries.append(str(rel))
            return entries

        async with self._read_semaphore:
            return await asyncio.to_thread(_collect)

    async def apply_all(self) -> LogicApplyResult:
        async with self._lock:
            pending_paths = list(self._pending_order)
            if not pending_paths:
                return LogicApplyResult(approved=True)
            drifted: list[str] = []
            for path in pending_paths:
                base_state = self._base_state[path]
                exists_now = await aiofiles.os.path.exists(str(path))
                if base_state.existed:
                    if (not exists_now) or await aiofiles.os.path.islink(str(path)):
                        drifted.append(str(path))
                        continue
                    if await _sha256_text(path) != base_state.digest:
                        drifted.append(str(path))
                elif exists_now:
                    drifted.append(str(path))
            if drifted:
                return LogicApplyResult(
                    meta=ToolResultMeta(
                        ok=False,
                        error_code="drift_detected",
                        error_message="Workspace drift detected before apply",
                    ),
                    approved=True,
                    pending_change_count=len(pending_paths),
                    drift_detected_paths=drifted,
                )

            applied_paths: list[str] = []
            for path in pending_paths:
                content = self._virtual_state[path]
                path.parent.mkdir(parents=True, exist_ok=True)
                await _atomic_write(path, content)
                applied_paths.append(str(path))

            return LogicApplyResult(
                approved=True,
                pending_change_count=len(pending_paths),
                applied_count=len(applied_paths),
                applied_paths=applied_paths,
            )

    async def _base_text(self, path: Path) -> str:
        base_state = self._base_state[path]
        if not base_state.existed:
            return ""
        return await _read_text(path)

    def _display_path(self, path: Path) -> str:
        return str(path.relative_to(self.workspace_root))

    def _build_pending_change(
        self,
        path: Path,
        *,
        before: str,
        after: str,
        existed_before: bool,
    ) -> PendingChange:
        diff_preview, truncated_preview = _diff_preview(before, after, str(path))
        return PendingChange(
            path=self._display_path(path),
            change_type="update" if existed_before else "create",
            existed_before=existed_before,
            bytes_written=len(after.encode("utf-8")),
            line_count=_line_count(after),
            diff_preview=diff_preview,
            truncated_preview=truncated_preview,
        )

    def _record_pending_change(
        self, path: Path, change: PendingChange
    ) -> PendingChange:
        if path not in self._pending_changes:
            self._pending_order.append(path)
        self._pending_changes[path] = change
        return change


class SubprocessLogicExecutor:
    """Run agent-authored async Python in a dedicated subprocess."""

    def __init__(
        self,
        *,
        timeout: float = 30.0,
        max_output_chars: int = _MAX_LOGIC_OUTPUT_CHARS,
        python_executable: str | None = None,
    ) -> None:
        self.timeout = timeout
        self.max_output_chars = max_output_chars
        self.python_executable = python_executable or sys.executable

    async def execute(
        self,
        code: str,
        *,
        workspace: ShadowWorkspace | None = None,
    ) -> LogicExecutionResult:
        try:
            wrapped = self._wrap_code(code)
            compile(wrapped, "<kiss_logic>", "exec")
        except SyntaxError as exc:
            return LogicExecutionResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="invalid_input",
                    error_message=f"Invalid logic code: {exc}",
                ),
                code=code,
            )

        parent_sock, child_sock = socket.socketpair()
        rpc_server: asyncio.Task[None] | None = None
        process: subprocess.Popen[bytes] | None = None
        try:
            env = os.environ.copy()
            env["KISS_LOGIC_SOCKET_FD"] = str(child_sock.fileno())
            env["KISS_SAFE_BUILTINS"] = ",".join(_SAFE_BUILTIN_NAMES)
            workspace = workspace or ShadowWorkspace(Path.cwd())
            server = await create_server(
                parent_sock,
                lambda method, params: self._dispatch_rpc(workspace, method, params),
            )
            rpc_server = asyncio.create_task(server.serve())
            process = subprocess.Popen(  # nosec B603
                [self.python_executable, "-c", _BOOTSTRAP],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env,
                pass_fds=(child_sock.fileno(),),
            )
        except FileNotFoundError:
            parent_sock.close()
            return LogicExecutionResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="execution_failed",
                    error_message=f"Python runtime not found: {self.python_executable}",
                ),
                code=code,
            )
        except OSError as exc:
            parent_sock.close()
            return LogicExecutionResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="execution_failed",
                    error_message=f"Failed to start logic subprocess: {exc}",
                ),
                code=code,
            )
        finally:
            child_sock.close()

        try:
            stdout, stderr = await asyncio.wait_for(
                asyncio.to_thread(process.communicate, wrapped.encode("utf-8")),
                timeout=self.timeout,
            )
        except asyncio.TimeoutError:
            await _kill_process(process)
            return LogicExecutionResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="timeout",
                    error_message="Logic subprocess timed out",
                ),
                code=code,
                timed_out=True,
            )
        finally:
            if rpc_server is not None:
                with contextlib.suppress(Exception):
                    await rpc_server
            parent_sock.close()

        out = stdout.decode("utf-8", errors="replace")
        err = stderr.decode("utf-8", errors="replace")
        out, err, truncated = _truncate_streams(out, err, self.max_output_chars)
        meta = ToolResultMeta()
        if process.returncode != 0:
            meta = ToolResultMeta(
                ok=False,
                error_code="execution_failed",
                error_message="Logic subprocess exited with a non-zero status",
            )
        return LogicExecutionResult(
            code=code,
            meta=meta,
            exit_code=process.returncode,
            timed_out=False,
            truncated=truncated,
            stdout=out,
            stderr=err,
            pending_changes=workspace.pending_changes,
        )

    @staticmethod
    def _wrap_code(code: str) -> str:
        lines = code.splitlines()
        if not lines:
            body = "    return None\n"
        else:
            body = "".join(f"    {line}\n" if line else "    \n" for line in lines)
        return f"async def __kiss_logic__(kiss):\n{body}"

    @staticmethod
    async def _dispatch_rpc(
        workspace: ShadowWorkspace, method: str, params: dict[str, object]
    ) -> object:
        if method == "workspace.search":
            return await workspace.search(
                str(params["pattern"]),
                path_glob=(
                    str(params["path_glob"])
                    if params.get("path_glob") is not None
                    else None
                ),
            )
        if method == "workspace.glob":
            return await workspace.glob(str(params["pattern"]))
        if method == "workspace.open":
            return await workspace.open_file(str(params["path"]))
        if method == "workspace.list_dir":
            return await workspace.list_directory(
                str(params.get("path", ".")),
                max_depth=_as_int(params.get("depth"), default=1),
            )
        if method == "file.read":
            return await workspace.read_window(
                str(params["path"]),
                offset=_as_int(params.get("offset"), default=1),
                limit=(
                    _as_int(params["limit"], default=0)
                    if params.get("limit") is not None
                    else None
                ),
            )
        if method == "file.write":
            await workspace.write_text(str(params["path"]), str(params["content"]))
            return True
        if method == "file.append":
            await workspace.append_text(str(params["path"]), str(params["text"]))
            return True
        if method == "file.replace":
            await workspace.replace_text(
                str(params["path"]),
                str(params["old_text"]),
                str(params["new_text"]),
                count=(
                    _as_int(params["count"], default=-1)
                    if params.get("count") is not None
                    else -1
                ),
            )
            return True
        if method == "file.exists":
            return await workspace.exists(str(params["path"]))
        raise ValueError(f"Unknown RPC method: {method}")
