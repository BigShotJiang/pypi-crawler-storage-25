"""Guest-side async SDK proxies for Logic Tool."""

from __future__ import annotations

from dataclasses import dataclass

from kiss.agent.tools.logic.ipc import SocketRPCClient


@dataclass(frozen=True)
class Match:
    path: str
    line: int
    text: str
    file: "File"


class File:
    def __init__(self, client: SocketRPCClient, path: str) -> None:
        self._client = client
        self.path = path

    async def read(self, offset: int = 1, limit: int | None = None) -> str:
        result = await self._client.request(
            "file.read",
            {"path": self.path, "offset": offset, "limit": limit},
        )
        return str(result)

    async def replace(
        self,
        old_text: str,
        new_text: str,
        count: int | None = None,
        label: str | None = None,
    ) -> None:
        await self._client.request(
            "file.replace",
            {
                "path": self.path,
                "old_text": old_text,
                "new_text": new_text,
                "count": count,
                "label": label,
            },
        )

    async def append(self, text: str) -> None:
        await self._client.request("file.append", {"path": self.path, "text": text})

    async def write(self, content: str) -> None:
        await self._client.request(
            "file.write", {"path": self.path, "content": content}
        )

    async def exists(self) -> bool:
        result = await self._client.request("file.exists", {"path": self.path})
        return bool(result)


class Workspace:
    def __init__(self, client: SocketRPCClient) -> None:
        self._client = client

    async def search(self, pattern: str, path_glob: str | None = None) -> list[Match]:
        result = await self._client.request(
            "workspace.search",
            {"pattern": pattern, "path_glob": path_glob},
        )
        matches: list[Match] = []
        for item in result:
            path = str(item["path"])
            matches.append(
                Match(
                    path=path,
                    line=int(item["line"]),
                    text=str(item["text"]),
                    file=File(self._client, path),
                )
            )
        return matches

    async def glob(self, pattern: str) -> list[File]:
        result = await self._client.request("workspace.glob", {"pattern": pattern})
        return [File(self._client, str(item["path"])) for item in result]

    async def open(self, path: str) -> File:
        result = await self._client.request("workspace.open", {"path": path})
        return File(self._client, str(result["path"]))

    async def list_dir(self, path: str = ".", depth: int = 1) -> list[str]:
        result = await self._client.request(
            "workspace.list_dir",
            {"path": path, "depth": depth},
        )
        return [str(item) for item in result]


class KissContext:
    def __init__(self, client: SocketRPCClient) -> None:
        self.workspace = Workspace(client)

    async def aclose(self) -> None:
        await self.workspace._client.aclose()
