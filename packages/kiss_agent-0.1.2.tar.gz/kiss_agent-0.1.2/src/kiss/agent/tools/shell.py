"""Shell tools — run arbitrary shell commands"""

from __future__ import annotations

import asyncio
import contextlib
import os
from pathlib import Path

from kiss.agent.tools.result_types import RunCommandResult
from kiss.agent.tools.result_types import ToolResultMeta

_MAX_SHELL_OUTPUT_CHARS = 100_000
_TRUNCATION_MARKER = "\n... [truncated] ...\n"


async def _kill_process(process: asyncio.subprocess.Process) -> None:
    with contextlib.suppress(ProcessLookupError):
        process.kill()
    with contextlib.suppress(Exception):
        await process.wait()


async def _read_stream_with_limit(
    stream: asyncio.StreamReader | None, limit: int
) -> bytes:
    """Read up to *limit* bytes from *stream* to cap memory usage."""
    if stream is None:
        return b""
    chunks: list[bytes] = []
    total = 0
    while total < limit:
        chunk = await stream.read(min(65536, limit - total))
        if not chunk:
            break
        chunks.append(chunk)
        total += len(chunk)
    return b"".join(chunks)


def _resolve_shell_path(shell_path: str | None = None) -> str:
    if shell_path:
        return shell_path
    shell = os.environ.get("SHELL")
    if shell:
        return shell
    if os.name == "nt":
        return os.environ.get("COMSPEC") or "cmd.exe"
    return "/bin/sh"


def _shell_argv(shell_path: str, command: str) -> list[str]:
    shell_name = Path(shell_path).name.lower()
    if os.name == "nt":
        if shell_name in {"powershell", "powershell.exe", "pwsh", "pwsh.exe"}:
            return [shell_path, "-Command", command]
        return [shell_path, "/d", "/s", "/c", command]
    return [shell_path, "-c", command]


def _truncate_text(text: str, max_chars: int) -> str:
    if len(text) <= max_chars:
        return text
    if max_chars <= len(_TRUNCATION_MARKER):
        return text[:max_chars]
    head = max_chars // 2
    tail = max_chars - head - len(_TRUNCATION_MARKER)
    if tail <= 0:
        return text[: max_chars - len(_TRUNCATION_MARKER)] + _TRUNCATION_MARKER
    return text[:head] + _TRUNCATION_MARKER + text[-tail:]


def _truncate_streams(
    stdout: str, stderr: str, max_chars: int
) -> tuple[str, str, bool]:
    if max_chars <= 0:
        return "", "", True
    total_chars = len(stdout) + len(stderr)
    if total_chars <= max_chars:
        return stdout, stderr, False
    if not stdout:
        return stdout, _truncate_text(stderr, max_chars), True
    if not stderr:
        return _truncate_text(stdout, max_chars), stderr, True

    stdout_budget = (max_chars * len(stdout)) // total_chars
    stderr_budget = max_chars - stdout_budget
    stdout_budget = max(0, stdout_budget)
    stderr_budget = max(0, stderr_budget)
    return (
        _truncate_text(stdout, stdout_budget),
        _truncate_text(stderr, stderr_budget),
        True,
    )


async def run_bash(
    command: str,
    timeout: float = 30.0,
    *,
    cwd: str | Path | None = None,
    env: dict[str, str] | None = None,
    shell_path: str | None = None,
    max_output_chars: int = _MAX_SHELL_OUTPUT_CHARS,
) -> RunCommandResult:
    """Run a shell command and return structured stdout/stderr output."""
    resolved_shell = _resolve_shell_path(shell_path)
    process_env = os.environ.copy()
    if env is not None:
        process_env.update(env)
    try:
        process = await asyncio.create_subprocess_exec(
            *_shell_argv(resolved_shell, command),
            cwd=str(cwd) if cwd is not None else None,
            env=process_env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except FileNotFoundError:
        return RunCommandResult(
            meta=ToolResultMeta(
                ok=False,
                error_code="execution_failed",
                error_message=f"Shell runtime not found: {resolved_shell}",
            ),
            command=command,
        )
    except OSError as exc:
        return RunCommandResult(
            meta=ToolResultMeta(
                ok=False,
                error_code="execution_failed",
                error_message=f"Failed to start shell command: {exc}",
            ),
            command=command,
        )
    # Cap memory usage by limiting how many bytes we read before truncation.
    # max_output_chars * 4 gives headroom for UTF-8 multi-byte characters.
    max_bytes = max_output_chars * 4 + 4096
    stdout_task = asyncio.create_task(
        _read_stream_with_limit(process.stdout, max_bytes)
    )
    stderr_task = asyncio.create_task(
        _read_stream_with_limit(process.stderr, max_bytes)
    )

    try:
        stdout_bytes, stderr_bytes = await asyncio.wait_for(
            asyncio.gather(stdout_task, stderr_task),
            timeout=timeout,
        )
    except asyncio.TimeoutError:
        await _kill_process(process)
        return RunCommandResult(
            meta=ToolResultMeta(
                ok=False,
                error_code="timeout",
                error_message="Command timed out",
            ),
            command=command,
            timed_out=True,
        )

    # If either stream hit the byte limit the process may still be writing;
    # kill it to stop further output and avoid zombie accumulation.
    if len(stdout_bytes) >= max_bytes or len(stderr_bytes) >= max_bytes:
        await _kill_process(process)
    else:
        try:
            await asyncio.wait_for(process.wait(), timeout=5.0)
        except asyncio.TimeoutError:
            await _kill_process(process)

    out = stdout_bytes.decode("utf-8", errors="replace")
    err = stderr_bytes.decode("utf-8", errors="replace")
    out, err, truncated = _truncate_streams(out, err, max_output_chars)
    return RunCommandResult(
        command=command,
        exit_code=process.returncode,
        truncated=truncated,
        stdout=out,
        stderr=err,
    )
