"""File tools — read and write files"""

from __future__ import annotations

import asyncio
import contextlib
from dataclasses import dataclass
import difflib
import os
import tempfile
from pathlib import Path
from typing import cast

import aiofiles
import aiofiles.os

from kiss.agent.tools.result_types import (
    EditFileResult,
    ReadFileResult,
    ToolResultMeta,
    WriteFileResult,
)

_MAX_READ_BYTES = 100_000  # ~100KB
_BINARY_SAMPLE_BYTES = 8_192
_MAX_DIFF_PREVIEW_LINES = 200
_MAX_MATCH_CONTEXTS = 3
_MATCH_CONTEXT_CHARS = 120
_MAX_RECOVERY_CANDIDATES = 3

# Per-resolved-path locks — serializes concurrent access from parallel subagents.
# Keys are absolute path strings; the dict is bounded by evicting unlocked
# entries once it exceeds _MAX_FILE_LOCKS.
_file_locks: dict[str, asyncio.Lock] = {}
_MAX_FILE_LOCKS = 10_000


@dataclass(frozen=True)
class _PatchChange:
    old_text: str
    new_text: str
    label: str


@dataclass(frozen=True)
class _ResolvedChange:
    change: _PatchChange
    start: int
    end: int


def _lock(path: Path) -> asyncio.Lock:
    key = str(path)
    lock = _file_locks.setdefault(key, asyncio.Lock())
    if len(_file_locks) > _MAX_FILE_LOCKS:
        for k, v in list(_file_locks.items()):
            if not v.locked():
                del _file_locks[k]
    return lock


async def read_file(
    path: str,
    offset: int = 1,
    limit: int | None = None,
) -> ReadFileResult:
    """Read a text file with 1-based line windows. Binary files return metadata only."""
    p = Path(path).resolve()
    async with _lock(p):
        if offset < 1:
            return ReadFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="invalid_input",
                    error_message="offset must be 1 or greater",
                ),
                path=str(p),
                exists=False,
                is_file=False,
            )
        if limit is not None and limit < 1:
            return ReadFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="invalid_input",
                    error_message="limit must be 1 or greater",
                ),
                path=str(p),
                exists=False,
                is_file=False,
            )
        if not await aiofiles.os.path.exists(str(p)):
            return ReadFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="not_found",
                    error_message=f"File {path} does not exist.",
                ),
                path=str(p),
                exists=False,
                is_file=False,
            )
        if not await aiofiles.os.path.isfile(str(p)):
            return ReadFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="not_a_file",
                    error_message=f"{path} is not a file.",
                ),
                path=str(p),
                exists=True,
                is_file=False,
            )
        try:
            total = (await aiofiles.os.stat(str(p))).st_size
            if await _is_binary_file(p):
                return ReadFileResult(
                    path=str(p),
                    exists=True,
                    is_file=True,
                    is_binary=True,
                    size_bytes=total,
                )

            collected: list[str] = []
            line_count = 0
            consumed_bytes = 0
            window_start = offset
            window_end = None
            truncated = False
            max_lines = limit
            async with aiofiles.open(str(p), encoding="utf-8", errors="replace") as f:
                async for line in f:
                    line_count += 1
                    encoded_len = len(line.encode("utf-8", errors="replace"))
                    if line_count < offset:
                        continue
                    if max_lines is not None and len(collected) >= max_lines:
                        truncated = True
                        break
                    if consumed_bytes + encoded_len > _MAX_READ_BYTES:
                        truncated = True
                        break
                    collected.append(line)
                    consumed_bytes += encoded_len

            if collected:
                window_end = offset + len(collected) - 1
            else:
                window_end = offset - 1

            if line_count > window_end:
                truncated = truncated or line_count > window_end

            return ReadFileResult(
                path=str(p),
                exists=True,
                is_file=True,
                is_binary=False,
                size_bytes=total,
                start_line=window_start,
                end_line=window_end,
                line_count=line_count,
                truncated=truncated,
                content="".join(collected) if collected else "",
            )
        except Exception as e:
            return ReadFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="execution_failed",
                    error_message=f"Error reading {path}: {e}",
                ),
                path=str(p),
                exists=True,
                is_file=True,
            )


async def _is_binary_file(path: Path) -> bool:
    async with aiofiles.open(path, "rb") as f:
        sample = await f.read(_BINARY_SAMPLE_BYTES)
    if b"\x00" in sample:
        return True
    return False


async def _atomic_write(p: Path, content: str) -> None:
    """Write content to p via a temp file + os.replace (atomic on POSIX).

    Preserves the original file's permissions when overwriting.
    """
    fd, tmp = tempfile.mkstemp(dir=p.parent, prefix=f".{p.name}_")
    os.close(fd)
    try:
        if await aiofiles.os.path.exists(str(p)):
            original_mode = (await aiofiles.os.stat(str(p))).st_mode
            os.chmod(tmp, original_mode)
        async with aiofiles.open(tmp, "w", encoding="utf-8") as f:
            await f.write(content)
        os.replace(tmp, str(p))
    except Exception:
        with contextlib.suppress(OSError):
            os.unlink(tmp)
        raise


def _line_count(content: str) -> int:
    if not content:
        return 0
    return content.count("\n") + (0 if content.endswith("\n") else 1)


def _diff_preview(before: str, after: str, path: str) -> tuple[str, bool]:
    diff_lines = list(
        difflib.unified_diff(
            before.splitlines(),
            after.splitlines(),
            fromfile=f"{path} (before)",
            tofile=f"{path} (after)",
            lineterm="",
        )
    )
    truncated = len(diff_lines) > _MAX_DIFF_PREVIEW_LINES
    if truncated:
        diff_lines = diff_lines[:_MAX_DIFF_PREVIEW_LINES]
    return "\n".join(diff_lines), truncated


def _match_contexts(content: str, old_text: str) -> list[str]:
    contexts: list[str] = []
    start = 0
    while len(contexts) < _MAX_MATCH_CONTEXTS:
        index = content.find(old_text, start)
        if index == -1:
            break
        line_no = content.count("\n", 0, index) + 1
        snippet_start = max(0, index - _MATCH_CONTEXT_CHARS)
        snippet_end = min(len(content), index + len(old_text) + _MATCH_CONTEXT_CHARS)
        snippet = content[snippet_start:snippet_end].replace("\n", "\\n")
        contexts.append(f"line {line_no}: …{snippet}…")
        start = index + len(old_text)
    return contexts


def _recovery_contexts(content: str, old_text: str) -> list[str]:
    target_lines = [line.strip() for line in old_text.splitlines() if line.strip()]
    if not target_lines:
        return []
    sorted_lines = sorted(target_lines, key=len, reverse=True)
    anchor = cast(str, sorted_lines[0])
    content_lines = content.splitlines()
    contexts: list[str] = []
    ranked = sorted(
        (
            (
                difflib.SequenceMatcher(None, anchor, line).ratio(),
                index,
                line,
            )
            for index, line in enumerate(content_lines)
        ),
        reverse=True,
    )
    for score, index, line in ranked[:_MAX_RECOVERY_CANDIDATES]:
        if score < 0.35:
            continue
        match = line
        contexts.append(f"line {index + 1}: …{match}…")
    return contexts


def _invalid_patch_result(
    path: Path,
    message: str,
    *,
    requested_change_count: int = 0,
    failed_change_index: int | None = None,
    failed_change_label: str | None = None,
) -> EditFileResult:
    return EditFileResult(
        meta=ToolResultMeta(
            ok=False,
            error_code="invalid_input",
            error_message=message,
        ),
        path=str(path),
        requested_change_count=requested_change_count,
        failed_change_index=failed_change_index,
        failed_change_label=failed_change_label,
        recovery_type="invalid_patch",
    )


def _normalize_patch_changes(
    path: Path, changes: list[dict[str, str]]
) -> tuple[list[_PatchChange] | None, EditFileResult | None]:
    if not changes:
        return None, _invalid_patch_result(
            path, "Patch must include at least one change."
        )

    normalized: list[_PatchChange] = []
    for index, raw_change in enumerate(changes):
        label = raw_change.get("label") or f"change-{index + 1}"
        old_text = raw_change.get("old_text")
        new_text = raw_change.get("new_text")
        if not isinstance(old_text, str) or not isinstance(new_text, str):
            return None, _invalid_patch_result(
                path,
                "Each patch change must include string old_text and new_text fields.",
                requested_change_count=len(changes),
                failed_change_index=index,
                failed_change_label=label,
            )
        if not old_text:
            return None, _invalid_patch_result(
                path,
                "old_text must not be empty.",
                requested_change_count=len(changes),
                failed_change_index=index,
                failed_change_label=label,
            )
        normalized.append(
            _PatchChange(
                old_text=old_text,
                new_text=new_text,
                label=label,
            )
        )
    return normalized, None


def _resolve_patch_changes(
    content: str,
    changes: list[_PatchChange],
    path: Path,
) -> tuple[list[_ResolvedChange] | None, EditFileResult | None]:
    resolved: list[_ResolvedChange] = []
    for index, change in enumerate(changes):
        occurrence_count = content.count(change.old_text)
        if occurrence_count == 0:
            return None, EditFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="not_found",
                    error_message=(
                        f"Patch change {change.label!r} not found in {path}. "
                        "Exact match required."
                    ),
                ),
                path=str(path),
                requested_change_count=len(changes),
                failed_change_index=index,
                failed_change_label=change.label,
                recovery_type="not_found",
                match_contexts=_recovery_contexts(content, change.old_text),
            )
        if occurrence_count > 1:
            return None, EditFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="disambiguation_required",
                    error_message=(
                        f"Patch change {change.label!r} matched {occurrence_count} times in {path}. "
                        "Provide more surrounding context."
                    ),
                    needs_disambiguation=True,
                ),
                path=str(path),
                requested_change_count=len(changes),
                failed_change_index=index,
                failed_change_label=change.label,
                occurrence_count=occurrence_count,
                recovery_type="ambiguous_match",
                match_contexts=_match_contexts(content, change.old_text),
            )
        start = content.find(change.old_text)
        resolved.append(
            _ResolvedChange(
                change=change,
                start=start,
                end=start + len(change.old_text),
            )
        )

    ordered = sorted(resolved, key=lambda item: item.start)
    change_positions = {id(change): index for index, change in enumerate(changes)}
    for index in range(1, len(ordered)):
        previous = ordered[index - 1]
        current = ordered[index]
        if current.start < previous.end:
            current_index = change_positions[id(current.change)]
            return None, EditFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="invalid_input",
                    error_message=(
                        "Patch contains overlapping or dependent changes. "
                        "Each change must target a distinct region in the original file."
                    ),
                ),
                path=str(path),
                requested_change_count=len(changes),
                failed_change_index=current_index,
                failed_change_label=current.change.label,
                recovery_type="overlap_rejected",
            )
    return ordered, None


def _apply_resolved_changes(content: str, changes: list[_ResolvedChange]) -> str:
    updated = content
    for resolved in reversed(changes):
        updated = (
            updated[: resolved.start]
            + resolved.change.new_text
            + updated[resolved.end :]
        )
    return updated


async def write_file(path: str, content: str) -> WriteFileResult:
    """Write content to a file, creating parent directories if needed.

    Refuses implicit overwrite when the target file already exists
    (write-guard policy, task 4.7). Use ``edit_file`` or ``apply_patch`` instead.
    """
    p = Path(path).resolve()
    async with _lock(p):
        try:
            existed = await aiofiles.os.path.exists(str(p))
            if existed and await aiofiles.os.path.isfile(str(p)):
                return WriteFileResult(
                    meta=ToolResultMeta(
                        ok=False,
                        error_code="write_guard",
                        error_message=(
                            f"File {path} already exists. "
                            "Implicit overwrite is refused by write-guard policy. "
                            "Use edit_file or apply_patch instead."
                        ),
                    ),
                    path=str(p),
                )
            previous = ""
            await aiofiles.os.makedirs(str(p.parent), exist_ok=True)
            await _atomic_write(p, content)
            diff_preview, truncated_preview = _diff_preview(previous, content, str(p))
            encoded = content.encode("utf-8")
            return WriteFileResult(
                path=str(p),
                created=not existed,
                overwrote=existed,
                bytes_written=len(encoded),
                line_count=_line_count(content),
                diff_preview=diff_preview,
                truncated_preview=truncated_preview,
            )
        except Exception as e:
            return WriteFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="execution_failed",
                    error_message=f"Error writing to {path}: {e}",
                ),
                path=str(p),
            )


async def edit_file(path: str, old_text: str, new_text: str) -> EditFileResult:
    """Edit a file by replacing a specific block of text with new text"""
    return await apply_patch(
        path,
        [{"old_text": old_text, "new_text": new_text, "label": "edit-1"}],
    )


async def apply_patch(path: str, changes: list[dict[str, str]]) -> EditFileResult:
    """Apply multiple exact-match changes atomically to a single file."""
    p = Path(path).resolve()
    async with _lock(p):
        if not await aiofiles.os.path.exists(str(p)):
            return EditFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="not_found",
                    error_message=f"Error: File {path} does not exist.",
                ),
                path=str(p),
                requested_change_count=len(changes),
            )
        if not await aiofiles.os.path.isfile(str(p)):
            return EditFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="not_a_file",
                    error_message=f"Error: {path} is not a file.",
                ),
                path=str(p),
                requested_change_count=len(changes),
            )

        normalized, invalid_result = _normalize_patch_changes(p, changes)
        if invalid_result is not None or normalized is None:
            return invalid_result or _invalid_patch_result(p, "Invalid patch input.")

        try:
            async with aiofiles.open(str(p), encoding="utf-8") as f:
                content = await f.read()

            resolved, failure_result = _resolve_patch_changes(content, normalized, p)
            if failure_result is not None or resolved is None:
                return failure_result or EditFileResult(
                    meta=ToolResultMeta(
                        ok=False,
                        error_code="execution_failed",
                        error_message="Patch validation failed.",
                    ),
                    path=str(p),
                    requested_change_count=len(normalized),
                )

            updated = _apply_resolved_changes(content, resolved)
            await _atomic_write(p, updated)
            diff_preview, truncated_preview = _diff_preview(content, updated, str(p))
            return EditFileResult(
                path=str(p),
                applied=True,
                requested_change_count=len(normalized),
                applied_change_count=len(normalized),
                occurrence_count=len(normalized),
                replacement_count=len(normalized),
                diff_preview=diff_preview,
                truncated_preview=truncated_preview,
            )
        except Exception as e:
            return EditFileResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="execution_failed",
                    error_message=f"Error editing {path}: {e}",
                ),
                path=str(p),
                requested_change_count=len(changes),
            )
