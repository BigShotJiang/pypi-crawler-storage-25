"""Code tools — search patterns and explore directory structure"""

from __future__ import annotations

import asyncio
import contextlib
import fnmatch
import functools
import glob as globlib
import os
import re
import shutil
from pathlib import Path
from typing import Literal

from kiss.agent.tools.result_types import (
    DirectoryEntry,
    GlobMatch,
    GlobResult,
    ListDirectoryResult,
    SearchCodeMatch,
    SearchCodeResult,
    ToolResultMeta,
)

_GREP_EXCLUDE_DIRS = (
    ".git",
    "__pycache__",
    ".venv",
    "venv",
    "node_modules",
    ".mypy_cache",
    ".ruff_cache",
)


_TREE_EXCLUDE_DIRS = {
    "__pycache__",
    ".git",
    ".venv",
    "venv",
    "node_modules",
    ".mypy_cache",
    ".ruff_cache",
}

_DEFAULT_GLOB_MAX_RESULTS = 100
_DEFAULT_SEARCH_MAX_MATCHES = 200


async def _kill_process(process: asyncio.subprocess.Process) -> None:
    with contextlib.suppress(ProcessLookupError):
        process.kill()
    with contextlib.suppress(Exception):
        await process.wait()


async def list_directory(
    directory: str = ".", max_depth: int = 3
) -> ListDirectoryResult:
    """Return structured directory entries, excluding hidden dirs and common build artifacts."""

    def _build_tree() -> ListDirectoryResult:
        p = Path(directory).resolve()
        if not p.exists() or not p.is_dir():
            return ListDirectoryResult(
                meta=ToolResultMeta(
                    ok=False,
                    error_code="not_found",
                    error_message=f"Directory {directory} does not exist.",
                ),
                root=str(p),
                max_depth=max_depth,
            )

        result: list[DirectoryEntry] = []
        truncated = False
        for root, dirs, files in os.walk(p):
            depth = len(Path(root).relative_to(p).parts)
            if depth >= max_depth:
                dirs.clear()  # stop recursing beyond max_depth
                truncated = True
                continue
            dirs[:] = sorted(
                d for d in dirs if not d.startswith(".") and d not in _TREE_EXCLUDE_DIRS
            )
            if depth > 0:
                result.append(
                    DirectoryEntry(
                        path=str(Path(root).relative_to(p)),
                        kind="dir",
                        depth=depth,
                    )
                )
            for name in sorted(files):
                rel_path = Path(root).relative_to(p) / name
                result.append(
                    DirectoryEntry(
                        path=str(rel_path),
                        kind="file",
                        depth=depth + 1,
                    )
                )

        return ListDirectoryResult(
            root=str(p),
            max_depth=max_depth,
            truncated=truncated,
            entries=result,
        )

    return await asyncio.to_thread(_build_tree)


async def glob(
    pattern: str,
    *,
    workspace_root: str | Path = ".",
    max_results: int = _DEFAULT_GLOB_MAX_RESULTS,
    sort_by: Literal["mtime", "path"] = "mtime",
    include_hidden: bool = False,
    files_only: bool = True,
) -> GlobResult:
    """Match files using Python glob/rglob semantics from the workspace root."""

    def _collect() -> GlobResult:
        if max_results < 1:
            return GlobResult(
                pattern=pattern,
                root=str(Path(workspace_root).resolve()),
                meta=ToolResultMeta(
                    ok=False,
                    error_code="invalid_input",
                    error_message="max_results must be 1 or greater",
                ),
            )

        root = Path(workspace_root).resolve()
        try:
            match_iter = (
                globlib.iglob(pattern, recursive=True, include_hidden=include_hidden)
                if Path(pattern).is_absolute()
                else globlib.iglob(
                    str(root / pattern),
                    recursive=True,
                    include_hidden=include_hidden,
                )
            )
            found: list[GlobMatch] = []
            for raw_match in match_iter:
                candidate = Path(raw_match).resolve()
                if not candidate.exists():
                    continue
                display_path = (
                    str(candidate.relative_to(root))
                    if candidate.is_relative_to(root)
                    else str(candidate)
                )
                if not include_hidden and _is_hidden_path(display_path):
                    continue
                if files_only and candidate.is_dir():
                    continue
                stat = candidate.stat()
                found.append(
                    GlobMatch(
                        path=display_path,
                        is_dir=candidate.is_dir(),
                        size_bytes=stat.st_size,
                        mtime=stat.st_mtime,
                    )
                )

            if sort_by == "path":
                found.sort(key=lambda item: item.path)
            else:
                found.sort(key=lambda item: (-item.mtime, item.path))

            truncated = len(found) > max_results
            return GlobResult(
                pattern=pattern,
                root=str(root),
                truncated=truncated,
                matches=found[:max_results],
            )
        except Exception as exc:
            return GlobResult(
                pattern=pattern,
                root=str(root),
                meta=ToolResultMeta(
                    ok=False,
                    error_code="execution_failed",
                    error_message=f"Error globbing {pattern}: {exc}",
                ),
            )

    return await asyncio.to_thread(_collect)


async def _run_search(cmd: list[str]) -> tuple[int, str, str]:
    """Run a search command with a 10s timeout."""
    process = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=10.0)
    except asyncio.TimeoutError:
        await _kill_process(process)
        return (124, "", "Error: search timed out after 10s")
    return (
        process.returncode or 0,
        stdout.decode("utf-8"),
        stderr.decode("utf-8"),
    )


async def search_code(
    pattern: str,
    *,
    path_glob: str | None = None,
    max_matches: int = _DEFAULT_SEARCH_MAX_MATCHES,
    workspace_root: str | Path = ".",
) -> SearchCodeResult:
    """Search for a regex pattern across the codebase."""
    root = Path(workspace_root).resolve()
    if max_matches < 1:
        return SearchCodeResult(
            pattern=pattern,
            meta=ToolResultMeta(
                ok=False,
                error_code="invalid_input",
                error_message="max_matches must be 1 or greater",
            ),
        )

    path_filter, path_filter_error = (
        _build_path_filter(path_glob, root) if path_glob else (None, None)
    )
    if path_filter_error is not None:
        return SearchCodeResult(
            pattern=pattern,
            meta=ToolResultMeta(
                ok=False,
                error_code="invalid_input",
                error_message=path_filter_error,
            ),
        )

    if shutil.which("rg"):
        rg_result = await _search_with_rg(
            pattern,
            root=root,
            path_glob=path_glob,
            path_filter=path_filter,
            max_matches=max_matches,
        )
        if rg_result.meta.ok or rg_result.meta.error_code != "execution_failed":
            return rg_result

    git_result = await _search_with_git_grep(
        pattern,
        root=root,
        path_glob=path_glob,
        path_filter=path_filter,
        max_matches=max_matches,
    )
    if git_result.meta.ok or git_result.meta.error_code != "execution_failed":
        return git_result

    return await _search_with_grep(
        pattern,
        root=root,
        path_filter=path_filter,
        max_matches=max_matches,
    )


async def _search_with_rg(
    pattern: str,
    *,
    root: Path,
    path_glob: str | None,
    path_filter: str | None,
    max_matches: int,
) -> SearchCodeResult:
    cmd = [
        "rg",
        "-n",
        "--color",
        "never",
        "--glob",
        "!.git/",
        "--max-count",
        str(max_matches),
        "--",
        pattern,
        str(root),
    ]
    if path_glob is not None:
        cmd.extend(["--glob", _rg_glob(path_glob, root)])
    code, stdout, stderr = await _run_search(cmd)
    return _search_result_from_process(
        pattern,
        code,
        stdout,
        stderr,
        root=root,
        path_filter=path_filter,
        max_matches=max_matches,
    )


async def _search_with_git_grep(
    pattern: str,
    *,
    root: Path,
    path_glob: str | None,
    path_filter: str | None,
    max_matches: int,
) -> SearchCodeResult:
    cmd = [
        "git",
        "-C",
        str(root),
        "grep",
        "-n",
        "-E",
        "--untracked",
        "-e",
        pattern,
    ]
    if path_glob is not None and not Path(path_glob).is_absolute():
        cmd.extend(["--", path_glob])
    code, stdout, stderr = await _run_search(cmd)
    return _search_result_from_process(
        pattern,
        code,
        stdout,
        stderr,
        root=root,
        path_filter=path_filter,
        max_matches=max_matches,
    )


async def _search_with_grep(
    pattern: str,
    *,
    root: Path,
    path_filter: str | None,
    max_matches: int,
) -> SearchCodeResult:
    excludes = [f"--exclude-dir={d}" for d in _GREP_EXCLUDE_DIRS]
    code, stdout, stderr = await _run_search(
        ["grep", "-rn", "-E", *excludes, "--", pattern, str(root)]
    )
    return _search_result_from_process(
        pattern,
        code,
        stdout,
        stderr,
        root=root,
        path_filter=path_filter,
        max_matches=max_matches,
    )


def _search_result_from_process(
    pattern: str,
    returncode: int,
    stdout: str,
    stderr: str,
    *,
    root: Path,
    path_filter: str | None,
    max_matches: int,
) -> SearchCodeResult:
    if returncode == 0:
        matches = _parse_search_matches(stdout, root)
        if path_filter is not None:
            matches = [
                match for match in matches if _match_path_glob(match.path, path_filter)
            ]
        total_matches = len(matches)
        truncated = total_matches > max_matches
        matches = matches[:max_matches]
        return SearchCodeResult(
            pattern=pattern,
            match_count=total_matches,
            truncated=truncated,
            matches=matches,
        )
    if returncode == 1:
        return SearchCodeResult(pattern=pattern, match_count=0, matches=[])
    if returncode == 124:
        return SearchCodeResult(
            pattern=pattern,
            meta=ToolResultMeta(
                ok=False,
                error_code="timeout",
                error_message="Error: search timed out after 10s",
            ),
        )
    error = stderr or f"search failed with code {returncode}"
    return SearchCodeResult(
        meta=ToolResultMeta(
            ok=False,
            error_code="execution_failed",
            error_message=f"Error searching code: {error}",
        ),
        pattern=pattern,
    )


def _parse_search_matches(stdout: str, root: Path) -> list[SearchCodeMatch]:
    matches: list[SearchCodeMatch] = []
    for raw_line in stdout.splitlines():
        parts = raw_line.split(":")
        if len(parts) < 3:
            continue
        # Find the first colon-separated segment that is all digits (the line number).
        # This correctly handles Windows absolute paths like C:\src\file.py:10:match.
        line_idx = None
        for i in range(1, len(parts) - 1):
            if parts[i].isdigit():
                line_idx = i
                break
        if line_idx is None:
            continue
        path = ":".join(parts[:line_idx])
        line_text = parts[line_idx]
        match_text = ":".join(parts[line_idx + 1 :])
        path_obj = Path(path)
        if path_obj.is_absolute():
            try:
                path = str(path_obj.resolve().relative_to(root))
            except ValueError:
                path = str(path_obj.resolve())
        matches.append(SearchCodeMatch(path=path, line=int(line_text), text=match_text))
    return matches


def _is_hidden_path(path: str) -> bool:
    parts = Path(path).parts
    return any(part.startswith(".") for part in parts if part not in {".", ".."})


def _match_path_glob(path: str, pattern: str) -> bool:
    normalized_path = path.replace(os.sep, "/")
    normalized_pattern = pattern.replace(os.sep, "/")
    if "**" in normalized_pattern:
        return bool(_glob_to_regex(normalized_pattern).match(normalized_path))
    return fnmatch.fnmatchcase(normalized_path, normalized_pattern)


@functools.lru_cache(maxsize=256)
def _glob_to_regex(pattern: str) -> re.Pattern[str]:
    i = 0
    regex_parts: list[str] = ["^"]
    while i < len(pattern):
        if pattern[i : i + 2] == "**":
            regex_parts.append(".*")
            i += 2
            if i < len(pattern) and pattern[i] == "/":
                regex_parts.append("/?")
                i += 1
        elif pattern[i] == "*":
            regex_parts.append("[^/]*")
            i += 1
        elif pattern[i] == "?":
            regex_parts.append("[^/]")
            i += 1
        elif pattern[i] == "[":
            j = pattern.find("]", i + 1)
            if j == -1:
                regex_parts.append(re.escape("["))
                i += 1
            else:
                regex_parts.append(pattern[i : j + 1].replace("[!", "[^", 1))
                i = j + 1
        else:
            regex_parts.append(re.escape(pattern[i]))
            i += 1
    regex_parts.append("$")
    return re.compile("".join(regex_parts))


def _build_path_filter(path_glob: str, root: Path) -> tuple[str | None, str | None]:
    path = Path(path_glob)
    if path.is_absolute():
        try:
            return str(path.resolve().relative_to(root)), None
        except ValueError:
            return None, "absolute path_glob must be inside the workspace root"
    return path_glob, None


def _rg_glob(path_glob: str, root: Path) -> str:
    path = Path(path_glob)
    if path.is_absolute():
        try:
            return str(path.resolve().relative_to(root))
        except ValueError:
            return path_glob
    return path_glob
