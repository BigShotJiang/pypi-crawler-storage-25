"""Structured result types for agent tools."""

from __future__ import annotations

import msgspec


class ToolResultMeta(msgspec.Struct, omit_defaults=True):
    ok: bool = True
    error_code: str | None = None
    error_message: str | None = None
    needs_confirmation: bool = False
    needs_disambiguation: bool = False


class ReadFileResult(msgspec.Struct, omit_defaults=True):
    path: str
    exists: bool
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    is_file: bool = True
    is_binary: bool = False
    size_bytes: int = 0
    start_line: int | None = None
    end_line: int | None = None
    line_count: int | None = None
    truncated: bool = False
    content: str | None = None


class WriteFileResult(msgspec.Struct, omit_defaults=True):
    path: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    created: bool = False
    overwrote: bool = False
    bytes_written: int = 0
    line_count: int = 0
    diff_preview: str | None = None
    truncated_preview: bool = False


class EditFileResult(msgspec.Struct, omit_defaults=True):
    path: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    applied: bool = False
    requested_change_count: int = 0
    applied_change_count: int = 0
    occurrence_count: int = 0
    replacement_count: int = 0
    failed_change_index: int | None = None
    failed_change_label: str | None = None
    recovery_type: str | None = None
    diff_preview: str | None = None
    truncated_preview: bool = False
    match_contexts: list[str] = msgspec.field(default_factory=list)


class ExpandRefResult(msgspec.Struct, omit_defaults=True):
    ref: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    content: str | None = None


class SearchCodeMatch(msgspec.Struct, omit_defaults=True):
    path: str
    line: int
    text: str


class SearchCodeResult(msgspec.Struct, omit_defaults=True):
    pattern: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    match_count: int = 0
    truncated: bool = False
    matches: list[SearchCodeMatch] = msgspec.field(default_factory=list)


class DirectoryEntry(msgspec.Struct, omit_defaults=True):
    path: str
    kind: str
    depth: int


class GlobMatch(msgspec.Struct, omit_defaults=True):
    path: str
    is_dir: bool = False
    size_bytes: int = 0
    mtime: float = 0.0


class ListDirectoryResult(msgspec.Struct, omit_defaults=True):
    root: str
    max_depth: int
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    truncated: bool = False
    entries: list[DirectoryEntry] = msgspec.field(default_factory=list)


class GlobResult(msgspec.Struct, omit_defaults=True):
    pattern: str
    root: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    truncated: bool = False
    matches: list[GlobMatch] = msgspec.field(default_factory=list)


class RunCommandResult(msgspec.Struct, omit_defaults=True):
    command: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    exit_code: int | None = None
    timed_out: bool = False
    truncated: bool = False
    stdout: str = ""
    stderr: str = ""
    hint: str | None = None


class PendingChange(msgspec.Struct, omit_defaults=True):
    path: str
    change_type: str
    existed_before: bool = False
    bytes_written: int = 0
    line_count: int = 0
    diff_preview: str | None = None
    truncated_preview: bool = False


class LogicExecutionResult(msgspec.Struct, omit_defaults=True):
    code: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    exit_code: int | None = None
    timed_out: bool = False
    truncated: bool = False
    stdout: str = ""
    stderr: str = ""
    pending_changes: list[PendingChange] = msgspec.field(default_factory=list)


class LogicApplyResult(msgspec.Struct, omit_defaults=True):
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    approved: bool = False
    pending_change_count: int = 0
    applied_count: int = 0
    applied_paths: list[str] = msgspec.field(default_factory=list)
    drift_detected_paths: list[str] = msgspec.field(default_factory=list)


class GitStatusEntry(msgspec.Struct, omit_defaults=True):
    path: str
    index_status: str = ""
    worktree_status: str = ""
    original_path: str | None = None


class GitStatusResult(msgspec.Struct, omit_defaults=True):
    repo_path: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    repo_root: str | None = None
    branch: str | None = None
    detached: bool = False
    ahead: int = 0
    behind: int = 0
    entries: list[GitStatusEntry] = msgspec.field(default_factory=list)


class GitDiffResult(msgspec.Struct, omit_defaults=True):
    repo_path: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    repo_root: str | None = None
    staged: bool = False
    truncated: bool = False
    diff: str = ""


class GitLogEntry(msgspec.Struct, omit_defaults=True):
    commit: str
    author_name: str = ""
    author_email: str = ""
    authored_at: int = 0
    subject: str = ""


class GitLogResult(msgspec.Struct, omit_defaults=True):
    repo_path: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    repo_root: str | None = None
    limit: int = 0
    truncated: bool = False
    commits: list[GitLogEntry] = msgspec.field(default_factory=list)


class GitStageResult(msgspec.Struct, omit_defaults=True):
    repo_path: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    repo_root: str | None = None
    operation: str = ""
    path_count: int = 0
    affected_paths: list[str] = msgspec.field(default_factory=list)


class GitCommitResult(msgspec.Struct, omit_defaults=True):
    repo_path: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    repo_root: str | None = None
    message: str = ""
    commit: str | None = None
    committed_paths: list[str] = msgspec.field(default_factory=list)
    dirty_index_paths: list[str] = msgspec.field(default_factory=list)
    missing_identity: bool = False


class AnalyzeCodeResult(msgspec.Struct, omit_defaults=True):
    path: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    language: str | None = None
    freshness_strategy: str | None = None
    issues: list["AnalysisIssue"] = msgspec.field(default_factory=list)
    metrics: dict[str, int] = msgspec.field(default_factory=dict)


class SourceRange(msgspec.Struct, omit_defaults=True):
    start_line: int
    start_col: int = 0
    end_line: int | None = None
    end_col: int | None = None


class CodeLocation(msgspec.Struct, omit_defaults=True):
    path: str
    range: SourceRange


class SymbolInfo(msgspec.Struct, omit_defaults=True):
    name: str
    kind: str
    language: str
    location: CodeLocation
    container_name: str | None = None


class AnalysisIssue(msgspec.Struct, omit_defaults=True):
    code: str
    message: str
    severity: str = "info"
    location: CodeLocation | None = None


class StyleViolation(msgspec.Struct, omit_defaults=True):
    code: str
    message: str
    severity: str = "warning"
    location: CodeLocation | None = None


class CheckStyleResult(msgspec.Struct, omit_defaults=True):
    path: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    language: str | None = None
    ruleset: str | None = None
    freshness_strategy: str | None = None
    violations: list[StyleViolation] = msgspec.field(default_factory=list)
    passed: bool = False


class DefinitionResult(msgspec.Struct, omit_defaults=True):
    query: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    freshness_strategy: str | None = None
    language: str | None = None
    symbol: SymbolInfo | None = None


class ReferencesResult(msgspec.Struct, omit_defaults=True):
    query: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    freshness_strategy: str | None = None
    language: str | None = None
    reference_count: int = 0
    truncated: bool = False
    references: list[CodeLocation] = msgspec.field(default_factory=list)


class DocumentSymbolsResult(msgspec.Struct, omit_defaults=True):
    path: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    freshness_strategy: str | None = None
    language: str | None = None
    symbol_count: int = 0
    truncated: bool = False
    symbols: list[SymbolInfo] = msgspec.field(default_factory=list)


class WorkspaceSymbolsResult(msgspec.Struct, omit_defaults=True):
    query: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    freshness_strategy: str | None = None
    language: str | None = None
    symbol_count: int = 0
    truncated: bool = False
    symbols: list[SymbolInfo] = msgspec.field(default_factory=list)


class WebSearchMatch(msgspec.Struct, omit_defaults=True):
    title: str
    url: str
    snippet: str = ""


class WebSearchResult(msgspec.Struct, omit_defaults=True):
    query: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    provider: str = "duckduckgo"
    max_results: int = 0
    result_count: int = 0
    truncated: bool = False
    cached: bool = False
    results: list[WebSearchMatch] = msgspec.field(default_factory=list)


class FetchUrlResult(msgspec.Struct, omit_defaults=True):
    url: str
    meta: ToolResultMeta = msgspec.field(default_factory=ToolResultMeta)
    final_url: str | None = None
    method: str = "GET"
    status_code: int | None = None
    content_type: str | None = None
    charset: str | None = None
    is_text: bool = False
    is_html: bool = False
    is_binary: bool = False
    redirect_count: int = 0
    title: str | None = None
    extracted: bool = False
    truncated: bool = False
    content: str | None = None
