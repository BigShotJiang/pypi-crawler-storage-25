"""Structured web fetch and search tools."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
import ipaddress
import re
import socket
import time
from typing import Literal
from urllib.parse import urljoin, urlparse

import httpx
from bs4 import BeautifulSoup

from kiss.agent.tools.result_types import (
    FetchUrlResult,
    ToolResultMeta,
    WebSearchMatch,
    WebSearchResult,
)
from kiss.core.settings import WebSearchConfig

_MAX_FETCH_BYTES = 100_000
_MAX_REDIRECTS = 3
_MAX_SEARCH_RESULTS = 10
_DEFAULT_SEARCH_MAX_RESULTS = 5
_DEFAULT_SEARCH_TIMEOUT_S = 10.0
_DEFAULT_SEARCH_CACHE_TTL_S = 300.0
_SEARCH_CACHE_MAX_ENTRIES = 64
_SEARCH_PROVIDER = "duckduckgo"
_DDG_SEARCH_URL = "https://html.duckduckgo.com/html/"
_DEFAULT_USER_AGENT = "kiss-agent/0.1"
IPAddress = ipaddress.IPv4Address | ipaddress.IPv6Address
_TEXT_TYPES = (
    "text/",
    "application/json",
    "application/xml",
    "application/javascript",
    "application/x-javascript",
    "application/xhtml+xml",
    "application/x-www-form-urlencoded",
)


@dataclass(slots=True)
class _CachedSearchEntry:
    expires_at: float
    result: WebSearchResult


_SEARCH_CACHE: dict[tuple[str, int, str], _CachedSearchEntry] = {}
_SEARCH_CACHE_LOCK = asyncio.Lock()
_SEARCH_CLIENT: httpx.AsyncClient | None = None


def _get_search_client() -> httpx.AsyncClient:
    global _SEARCH_CLIENT
    if _SEARCH_CLIENT is None:
        _SEARCH_CLIENT = httpx.AsyncClient(
            follow_redirects=True,
            max_redirects=_MAX_REDIRECTS,
            headers={"User-Agent": _DEFAULT_USER_AGENT},
        )
    return _SEARCH_CLIENT


async def close_search_client() -> None:
    """Close the shared web-search HTTP client. Call on shutdown."""
    global _SEARCH_CLIENT
    if _SEARCH_CLIENT is not None:
        await _SEARCH_CLIENT.aclose()
        _SEARCH_CLIENT = None


async def fetch_url(
    url: str,
    method: Literal["GET", "HEAD", "POST"] = "GET",
    mode: Literal["auto", "raw", "extracted"] = "auto",
    headers: dict[str, str] | None = None,
    body: str | None = None,
    timeout_s: float = 10.0,
) -> FetchUrlResult:
    """Fetch an http/https URL with readable extraction and network safety checks."""
    parsed = urlparse(url)
    validation_error = await _validate_url(parsed)
    if validation_error is not None:
        error_code = (
            "network_blocked"
            if "localhost" in validation_error.lower()
            or "blocked private or local address" in validation_error.lower()
            else "invalid_input"
        )
        return FetchUrlResult(
            meta=ToolResultMeta(
                ok=False,
                error_code=error_code,
                error_message=validation_error,
            ),
            url=url,
            method=method,
        )

    limits = httpx.Limits(max_keepalive_connections=5, max_connections=10)
    try:
        async with httpx.AsyncClient(
            follow_redirects=False,
            timeout=timeout_s,
            limits=limits,
        ) as client:
            current_url = url
            current_method = method
            current_body = body
            redirect_count = 0
            while True:
                response = await client.request(
                    current_method,
                    current_url,
                    headers=headers,
                    content=current_body.encode("utf-8")
                    if current_body is not None
                    else None,
                )
                if not (300 <= response.status_code < 400):
                    break
                if redirect_count >= _MAX_REDIRECTS:
                    return FetchUrlResult(
                        meta=ToolResultMeta(
                            ok=False,
                            error_code="execution_failed",
                            error_message="Too many redirects",
                        ),
                        url=url,
                        method=method,
                    )
                location = response.headers.get("location")
                if not location:
                    break
                current_url = urljoin(str(response.url), location)
                parsed = urlparse(current_url)
                validation_error = await _validate_url(parsed)
                if validation_error is not None:
                    return FetchUrlResult(
                        meta=ToolResultMeta(
                            ok=False,
                            error_code="network_blocked",
                            error_message=f"Redirect blocked: {validation_error}",
                        ),
                        url=url,
                        method=method,
                    )
                redirect_count += 1
                if response.status_code == 303 and current_method != "GET":
                    current_method = "GET"
                    current_body = None
    except httpx.TimeoutException:
        return FetchUrlResult(
            meta=ToolResultMeta(
                ok=False,
                error_code="timeout",
                error_message="Request timed out",
            ),
            url=url,
            method=method,
        )
    except httpx.HTTPError as exc:
        return FetchUrlResult(
            meta=ToolResultMeta(
                ok=False,
                error_code="execution_failed",
                error_message=f"Request failed: {exc}",
            ),
            url=url,
            method=method,
        )

    return _create_fetch_result(
        url, method, mode, response, redirect_count=redirect_count
    )


async def web_search(
    query: str,
    *,
    max_results: int | None = None,
    config: WebSearchConfig | None = None,
) -> WebSearchResult:
    """Search the web using DuckDuckGo HTML results."""
    cfg = config or WebSearchConfig()
    provider = (cfg.provider or _SEARCH_PROVIDER).strip().lower() or _SEARCH_PROVIDER
    bounded_max_results = _bounded_max_results(max_results or cfg.max_results)
    if provider != _SEARCH_PROVIDER:
        return WebSearchResult(
            query=query,
            provider=provider,
            max_results=bounded_max_results,
            meta=ToolResultMeta(
                ok=False,
                error_code="invalid_configuration",
                error_message=f"Unsupported web search provider: {provider}",
            ),
        )

    normalized_query = query.strip()
    if not normalized_query:
        return WebSearchResult(
            query=query,
            provider=provider,
            max_results=bounded_max_results,
            meta=ToolResultMeta(
                ok=False,
                error_code="invalid_input",
                error_message="Search query must not be empty.",
            ),
        )

    cache_key = (normalized_query.casefold(), bounded_max_results, provider)
    async with _SEARCH_CACHE_LOCK:
        cached = _cached_search_result(
            cache_key,
            ttl_s=max(0.0, cfg.cache_ttl_s or _DEFAULT_SEARCH_CACHE_TTL_S),
        )
        if cached is not None:
            return cached

    try:
        client = _get_search_client()
        response = await client.post(
            _DDG_SEARCH_URL,
            data={"q": normalized_query},
            timeout=cfg.timeout_s or _DEFAULT_SEARCH_TIMEOUT_S,
        )
        response.raise_for_status()
    except httpx.TimeoutException:
        return WebSearchResult(
            query=normalized_query,
            provider=provider,
            max_results=bounded_max_results,
            meta=ToolResultMeta(
                ok=False,
                error_code="timeout",
                error_message="Web search timed out.",
            ),
        )
    except httpx.HTTPError as exc:
        return WebSearchResult(
            query=normalized_query,
            provider=provider,
            max_results=bounded_max_results,
            meta=ToolResultMeta(
                ok=False,
                error_code="execution_failed",
                error_message=f"Web search failed: {exc}",
            ),
        )

    matches = _parse_duckduckgo_results(response.text, bounded_max_results)
    result = WebSearchResult(
        query=normalized_query,
        provider=provider,
        max_results=bounded_max_results,
        result_count=len(matches),
        truncated=len(matches) >= bounded_max_results,
        results=matches,
    )
    async with _SEARCH_CACHE_LOCK:
        _store_cached_search_result(
            cache_key,
            result,
            ttl_s=max(0.0, cfg.cache_ttl_s or _DEFAULT_SEARCH_CACHE_TTL_S),
        )
    return result


def _create_fetch_result(
    url: str,
    method: str,
    mode: Literal["auto", "raw", "extracted"],
    response: httpx.Response,
    redirect_count: int = 0,
) -> FetchUrlResult:
    content_type = response.headers.get("content-type", "")
    mime_type = content_type.split(";", 1)[0].strip().lower() or None
    charset = response.charset_encoding
    is_html = mime_type == "text/html"
    is_text = _is_text_content_type(mime_type)
    is_binary = not is_text

    decoded_text = None
    title = None
    if is_html:
        decoded_text = response.content.decode(
            response.encoding or "utf-8", errors="replace"
        )
        title = _extract_title(decoded_text)

    result = FetchUrlResult(
        url=url,
        final_url=str(response.url),
        method=method,
        status_code=response.status_code,
        content_type=mime_type,
        charset=charset,
        is_text=is_text,
        is_html=is_html,
        is_binary=is_binary,
        redirect_count=redirect_count,
        title=title,
    )
    if method == "HEAD" or is_binary:
        return result

    raw_bytes = response.content
    truncated = len(raw_bytes) > _MAX_FETCH_BYTES
    raw_bytes = raw_bytes[:_MAX_FETCH_BYTES]
    text = raw_bytes.decode(response.encoding or "utf-8", errors="replace")
    effective_mode = mode
    if mode == "auto":
        effective_mode = "extracted" if is_html else "raw"
    if effective_mode == "extracted" and is_html:
        text = _extract_readable_text(text)
        result.extracted = True
    result.content = text
    result.truncated = truncated
    return result


def _extract_visible_text(html: str) -> str:
    return _extract_readable_text(html)


def _extract_readable_text(html: str) -> str:
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "noscript", "template"]):
        tag.decompose()
    main = soup.find("main") or soup.find("article")
    root = main if main is not None else soup.body or soup
    text = root.get_text(separator="\n", strip=True)
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    return re.sub(r"\n{3,}", "\n\n", "\n".join(lines))


def _extract_title(html: str) -> str | None:
    soup = BeautifulSoup(html, "html.parser")
    title = soup.title.string if soup.title and soup.title.string else None
    if title is None:
        heading = soup.find(["h1", "h2"])
        title = heading.get_text(strip=True) if heading is not None else None
    if title is None:
        return None
    normalized = re.sub(r"\s+", " ", title).strip()
    return normalized or None


def _is_text_content_type(content_type: str | None) -> bool:
    if not content_type:
        return True
    return any(content_type.startswith(prefix) for prefix in _TEXT_TYPES)


async def _validate_url(parsed: object) -> str | None:
    scheme = getattr(parsed, "scheme", "").lower()
    if scheme not in {"http", "https"}:
        return "Only http and https URLs are allowed. For local files or directories, use the pipeline tool instead."
    hostname = getattr(parsed, "hostname", None)
    if not hostname:
        return "URL must include a hostname"
    if hostname.lower() == "localhost":
        return "Localhost URLs are not allowed"
    direct_ip = _parse_ip(hostname)
    if direct_ip is not None:
        if _is_blocked_ip(direct_ip):
            return f"Blocked private or local address: {hostname}"
        return None
    resolved_ips = await asyncio.to_thread(_resolve_host_ips, hostname)
    if any(_is_blocked_ip(ip) for ip in resolved_ips):
        return f"Blocked private or local address: {hostname}"
    return None


def _resolve_host_ips(hostname: str) -> list[IPAddress]:
    try:
        infos = socket.getaddrinfo(hostname, None, proto=socket.IPPROTO_TCP)
    except socket.gaierror:
        return []
    results: list[IPAddress] = []
    for _, _, _, _, sockaddr in infos:
        host = sockaddr[0]
        if not isinstance(host, str):
            continue
        parsed = _parse_ip(host)
        if parsed is not None:
            results.append(parsed)
    return results


def _parse_ip(value: str) -> IPAddress | None:
    try:
        return ipaddress.ip_address(value)
    except ValueError:
        return None


def _is_blocked_ip(value: IPAddress) -> bool:
    return (
        value.is_private
        or value.is_loopback
        or value.is_link_local
        or value.is_reserved
        or value.is_unspecified
        or value.is_multicast
    )


def _bounded_max_results(max_results: int) -> int:
    return max(1, min(max_results, _MAX_SEARCH_RESULTS))


def _parse_duckduckgo_results(html: str, max_results: int) -> list[WebSearchMatch]:
    soup = BeautifulSoup(html, "html.parser")
    matches: list[WebSearchMatch] = []
    selectors = (".result", ".web-result", "[data-testid='result']")
    nodes = []
    for selector in selectors:
        nodes = soup.select(selector)
        if nodes:
            break
    for node in nodes:
        link = node.select_one(".result__a") or node.select_one("a[href]")
        if link is None:
            continue
        href_value = link.get("href")
        href = href_value.strip() if isinstance(href_value, str) else ""
        title = link.get_text(" ", strip=True)
        snippet_node = (
            node.select_one(".result__snippet")
            or node.select_one(".result__body")
            or node.select_one(".snippet")
        )
        snippet = snippet_node.get_text(" ", strip=True) if snippet_node else ""
        if not href or not title:
            continue
        matches.append(WebSearchMatch(title=title, url=href, snippet=snippet))
        if len(matches) >= max_results:
            break
    return matches


def _cached_search_result(
    cache_key: tuple[str, int, str],
    *,
    ttl_s: float,
) -> WebSearchResult | None:
    if ttl_s <= 0:
        return None
    entry = _SEARCH_CACHE.get(cache_key)
    if entry is None:
        return None
    now = time.monotonic()
    if entry.expires_at <= now:
        _SEARCH_CACHE.pop(cache_key, None)
        return None
    return WebSearchResult(
        query=entry.result.query,
        provider=entry.result.provider,
        max_results=entry.result.max_results,
        result_count=entry.result.result_count,
        truncated=entry.result.truncated,
        cached=True,
        results=list(entry.result.results),
    )


def _store_cached_search_result(
    cache_key: tuple[str, int, str],
    result: WebSearchResult,
    *,
    ttl_s: float,
) -> None:
    if ttl_s <= 0:
        return
    if len(_SEARCH_CACHE) >= _SEARCH_CACHE_MAX_ENTRIES:
        oldest_key = next(iter(_SEARCH_CACHE))
        _SEARCH_CACHE.pop(oldest_key, None)
    _SEARCH_CACHE[cache_key] = _CachedSearchEntry(
        expires_at=time.monotonic() + ttl_s,
        result=WebSearchResult(
            query=result.query,
            provider=result.provider,
            max_results=result.max_results,
            result_count=result.result_count,
            truncated=result.truncated,
            cached=False,
            results=list(result.results),
        ),
    )
