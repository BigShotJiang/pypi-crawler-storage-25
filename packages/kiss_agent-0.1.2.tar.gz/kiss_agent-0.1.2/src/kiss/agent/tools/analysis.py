"""Structured code-intelligence and analysis tools."""

from __future__ import annotations

import ast
import asyncio
import os
from collections.abc import Iterable
import contextlib
import json
from pathlib import Path
import shutil
from typing import Any

from kiss.agent.tools.result_types import (
    AnalysisIssue,
    AnalyzeCodeResult,
    CheckStyleResult,
    CodeLocation,
    DefinitionResult,
    DocumentSymbolsResult,
    ReferencesResult,
    SourceRange,
    StyleViolation,
    SymbolInfo,
    ToolResultMeta,
    WorkspaceSymbolsResult,
)
from kiss.core.tracing import get_current_tracer

from kiss.agent.analysis.registry import detect_language as _registry_detect_language
from kiss.agent.analysis.dispatch import (
    _analyze_language as _dispatch_analyze,
    _symbols_for_language as _dispatch_symbols,
    _check_style_language as _dispatch_check_style,
)

_SUPPORTED_ANALYSIS_LANGUAGES = {
    "python": {".py"},
    "json": {".json"},
    "toml": {".toml"},
    "markdown": {".md", ".markdown"},
    "yaml": {".yaml", ".yml"},
    "sql": {".sql"},
    "bash": {".sh", ".bash", ".zsh"},
    "powershell": {".ps1", ".psm1", ".psd1"},
    "dockerfile": {".dockerfile"},
    "hcl": {".tf", ".hcl"},
    "regex": {".re", ".regex"},
    "jq": {".jq"},
    "csv": {".csv"},
    "tsv": {".tsv"},
    "javascript": {".js", ".jsx", ".mjs", ".cjs"},
    "typescript": {".ts", ".tsx"},
    "go": {".go"},
    "rust": {".rs"},
}
_FRESHNESS_STRATEGY = "on_demand_workspace_scan"
_EXCLUDED_DIRS = {
    ".git",
    "__pycache__",
    ".venv",
    "venv",
    "node_modules",
    ".mypy_cache",
    ".ruff_cache",
}


class _PythonSymbolCollector(ast.NodeVisitor):
    def __init__(self, path: Path, source_lines: list[str]) -> None:
        self._path = path
        self._source_lines = source_lines
        self._container_stack: list[str] = []
        self.symbols: list[SymbolInfo] = []
        self.references: dict[str, list[CodeLocation]] = {}

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self._add_symbol(node.name, "class", node)
        self._container_stack.append(node.name)
        self.generic_visit(node)
        self._container_stack.pop()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._add_symbol(node.name, "function", node)
        self._container_stack.append(node.name)
        self.generic_visit(node)
        self._container_stack.pop()

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._add_symbol(node.name, "function", node)
        self._container_stack.append(node.name)
        self.generic_visit(node)
        self._container_stack.pop()

    def visit_Assign(self, node: ast.Assign) -> None:
        if not self._container_stack:
            for target in node.targets:
                for name in self._extract_target_names(target):
                    self._add_symbol(name, "variable", node)
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        if not self._container_stack:
            for name in self._extract_target_names(node.target):
                self._add_symbol(name, "variable", node)
        self.generic_visit(node)

    def visit_Name(self, node: ast.Name) -> None:
        self.references.setdefault(node.id, []).append(_location(self._path, node))
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> None:
        self.references.setdefault(node.attr, []).append(_location(self._path, node))
        self.generic_visit(node)

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            name = alias.asname or alias.name.split(".")[-1]
            self.references.setdefault(name, []).append(_location(self._path, node))
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        for alias in node.names:
            name = alias.asname or alias.name
            self.references.setdefault(name, []).append(_location(self._path, node))
        self.generic_visit(node)

    def _add_symbol(self, name: str, kind: str, node: ast.AST) -> None:
        self.symbols.append(
            SymbolInfo(
                name=name,
                kind=kind,
                language="python",
                location=_location(self._path, node),
                container_name=self._container_stack[-1]
                if self._container_stack
                else None,
            )
        )

    def _extract_target_names(self, target: ast.AST) -> list[str]:
        if isinstance(target, ast.Name):
            return [target.id]
        if isinstance(target, (ast.Tuple, ast.List)):
            names: list[str] = []
            for element in target.elts:
                names.extend(self._extract_target_names(element))
            return names
        return []


def _detect_language(path: Path) -> str | None:
    name_lower = path.name.lower()
    if name_lower in ("dockerfile", "containerfile"):
        return "dockerfile"
    return _registry_detect_language(path)


def _unsupported_language_meta(path: Path) -> ToolResultMeta:
    return ToolResultMeta(
        ok=True,
        error_code="unsupported_language",
        error_message=(
            f"{path.name}: not a supported file type (Python, JSON, TOML, Markdown, YAML, SQL, Bash, PowerShell, Dockerfile, HCL, Regex, JQ, CSV, TSV, JavaScript, TypeScript, Go, Rust) — skipped."
        ),
    )


def _location(
    path: Path, node: ast.AST, *, end_line_default: bool = True
) -> CodeLocation:
    start_line = getattr(node, "lineno", 1)
    start_col = getattr(node, "col_offset", 0)
    end_line = getattr(node, "end_lineno", start_line if end_line_default else None)
    end_col = getattr(node, "end_col_offset", None)
    return CodeLocation(
        path=str(path),
        range=SourceRange(
            start_line=start_line,
            start_col=start_col,
            end_line=end_line,
            end_col=end_col,
        ),
    )


def _walk_workspace_files(workspace_root: Path) -> Iterable[Path]:
    for dirpath, dirnames, filenames in os.walk(workspace_root):
        dirnames[:] = [d for d in dirnames if d not in _EXCLUDED_DIRS]
        for filename in filenames:
            path = Path(dirpath) / filename
            if _detect_language(path) is not None:
                yield path


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def _python_symbols_for_text(
    path: Path, content: str
) -> tuple[list[SymbolInfo], dict[str, list[CodeLocation]], list[AnalysisIssue]]:
    try:
        tree = ast.parse(content, filename=str(path))
    except SyntaxError as exc:
        location = CodeLocation(
            path=str(path),
            range=SourceRange(
                start_line=exc.lineno or 1,
                start_col=exc.offset or 0,
            ),
        )
        return (
            [],
            {},
            [
                AnalysisIssue(
                    code="syntax_error",
                    message=exc.msg,
                    severity="error",
                    location=location,
                )
            ],
        )

    collector = _PythonSymbolCollector(path, content.splitlines())
    collector.visit(tree)
    return collector.symbols, collector.references, []


def _json_document_symbols(
    path: Path, content: str
) -> tuple[list[SymbolInfo], list[AnalysisIssue]]:
    try:
        payload = json.loads(content)
    except json.JSONDecodeError as exc:
        location = CodeLocation(
            path=str(path),
            range=SourceRange(
                start_line=exc.lineno or 1,
                start_col=exc.colno - 1 if exc.colno else 0,
            ),
        )
        return [], [
            AnalysisIssue(
                code="json_parse_error",
                message=exc.msg,
                severity="error",
                location=location,
            )
        ]

    symbols: list[SymbolInfo] = []
    offset = 0

    def visit(value: Any, container_name: str | None = None) -> None:
        nonlocal offset
        if isinstance(value, dict):
            for key, child in value.items():
                marker = f'"{key}"'
                position = content.find(marker, offset)
                if position == -1:
                    position = content.find(marker)
                line = content.count("\n", 0, position) + 1 if position != -1 else 1
                line_start = (
                    content.rfind("\n", 0, position) + 1 if position != -1 else 0
                )
                col = position - line_start if position != -1 else 0
                offset = (
                    max(offset, position + len(marker)) if position != -1 else offset
                )
                symbols.append(
                    SymbolInfo(
                        name=key,
                        kind="property",
                        language="json",
                        location=CodeLocation(
                            path=str(path),
                            range=SourceRange(
                                start_line=line,
                                start_col=col,
                            ),
                        ),
                        container_name=container_name,
                    )
                )
                visit(child, key)
        elif isinstance(value, list):
            for item in value:
                visit(item, container_name)

    visit(payload)
    return symbols, []


def _json_metrics(value: Any) -> dict[str, int]:
    key_count = 0
    object_count = 0
    array_count = 0
    max_depth = 0

    def walk(node: Any, depth: int) -> None:
        nonlocal key_count, object_count, array_count, max_depth
        max_depth = max(max_depth, depth)
        if isinstance(node, dict):
            object_count += 1
            key_count += len(node)
            for child in node.values():
                walk(child, depth + 1)
        elif isinstance(node, list):
            array_count += 1
            for child in node:
                walk(child, depth + 1)

    walk(value, 1)
    return {
        "key_count": key_count,
        "object_count": object_count,
        "array_count": array_count,
        "max_depth": max_depth,
    }


def _toml_metrics(
    content: str, path: Path | None = None
) -> tuple[dict[str, int], list[AnalysisIssue]]:
    import tomllib

    try:
        data = tomllib.loads(content)
    except tomllib.TOMLDecodeError as exc:
        return {}, [
            AnalysisIssue(
                code="toml_parse_error",
                message=str(exc),
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "",
                    range=SourceRange(start_line=1),
                ),
            )
        ]
    key_count = sum(len(v) if isinstance(v, dict) else 1 for v in data.values())
    table_count = sum(1 for v in data.values() if isinstance(v, dict))
    array_table_count = sum(
        1 for v in data.values() if isinstance(v, list) and v and isinstance(v[0], dict)
    )
    return {
        "top_level_keys": len(data),
        "key_count": key_count,
        "table_count": table_count,
        "array_table_count": array_table_count,
    }, []


def _markdown_metrics(content: str) -> dict[str, int]:
    import re

    lines = content.splitlines()
    h1 = sum(1 for ln in lines if re.match(r"^# ", ln))
    h2 = sum(1 for ln in lines if re.match(r"^## ", ln))
    h3 = sum(1 for ln in lines if re.match(r"^### ", ln))
    code_blocks = len(re.findall(r"^```", content, re.MULTILINE)) // 2
    links = len(re.findall(r"\[([^\]]+)\]\(([^)]+)\)", content))
    word_count = len(content.split())
    return {
        "h1_count": h1,
        "h2_count": h2,
        "h3_count": h3,
        "code_block_count": code_blocks,
        "link_count": links,
        "word_count": word_count,
    }


def _yaml_metrics(
    content: str, path: Path | None = None
) -> tuple[dict[str, int], list[AnalysisIssue]]:
    try:
        import yaml
    except ImportError:
        return {}, []

    try:
        documents = list(yaml.safe_load_all(content))
    except yaml.YAMLError as exc:
        return {}, [
            AnalysisIssue(
                code="yaml_parse_error",
                message=str(exc),
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "",
                    range=SourceRange(start_line=1),
                ),
            )
        ]

    document_count = len(documents)
    top_level_keys = 0
    mapping_count = 0
    sequence_count = 0
    max_depth = 0

    def walk(node: Any, depth: int) -> None:
        nonlocal top_level_keys, mapping_count, sequence_count, max_depth
        max_depth = max(max_depth, depth)
        if isinstance(node, dict):
            mapping_count += 1
            if depth == 1:
                top_level_keys += len(node)
            for child in node.values():
                walk(child, depth + 1)
        elif isinstance(node, list):
            sequence_count += 1
            for child in node:
                walk(child, depth + 1)

    for doc in documents:
        if doc is not None:
            walk(doc, 1)

    return {
        "document_count": document_count,
        "top_level_keys": top_level_keys,
        "mapping_count": mapping_count,
        "sequence_count": sequence_count,
        "max_depth": max_depth,
    }, []


def _sql_metrics(content: str) -> tuple[dict[str, int], list[AnalysisIssue]]:
    try:
        import sqlparse
    except ImportError:
        return {}, []

    statements = sqlparse.parse(content)
    counts: dict[str, int] = {
        "statement_count": len(statements),
        "select_count": 0,
        "insert_count": 0,
        "update_count": 0,
        "delete_count": 0,
        "create_count": 0,
        "drop_count": 0,
        "other_count": 0,
    }

    for stmt in statements:
        stmt_type = stmt.get_type()
        if stmt_type == "SELECT":
            counts["select_count"] += 1
        elif stmt_type == "INSERT":
            counts["insert_count"] += 1
        elif stmt_type == "UPDATE":
            counts["update_count"] += 1
        elif stmt_type == "DELETE":
            counts["delete_count"] += 1
        elif stmt_type == "CREATE":
            counts["create_count"] += 1
        elif stmt_type == "DROP":
            counts["drop_count"] += 1
        elif stmt_type != "UNKNOWN":
            counts["other_count"] += 1

    return counts, []


def _shell_metrics_regex(content: str) -> dict[str, int]:
    import re

    lines = content.splitlines()
    function_pattern = r"^\s*(?:function\s+\w+|\w+)\s*\(\s*\)\s*\{"
    function_count = sum(1 for ln in lines if re.match(function_pattern, ln))
    variable_pattern = r"^\s*[A-Z_][A-Z0-9_]*="
    variable_count = sum(1 for ln in lines if re.match(variable_pattern, ln))
    source_pattern = r"^\s*(?:source|\.)\s"
    source_count = sum(1 for ln in lines if re.match(source_pattern, ln))

    return {
        "function_count": function_count,
        "variable_count": variable_count,
        "source_count": source_count,
    }


def _bash_metrics(
    content: str, path: Path | None = None
) -> tuple[dict[str, int], list[AnalysisIssue]]:
    parser = _get_tree_sitter_parser("bash")
    if parser is None:
        # Fallback to regex-based metrics
        return _shell_metrics_regex(content), []

    try:
        tree = parser.parse(
            (content if content.endswith("\n") else content + "\n").encode("utf-8")
        )
    except Exception:
        return _shell_metrics_regex(content), []

    target_types = {
        "function_definition",
        "variable_assignment",
        "command",
    }
    node_counts = _count_ts_node_types(tree.root_node, target_types)

    has_error = tree.root_node.has_error

    return {
        "function_count": node_counts.get("function_definition", 0),
        "variable_count": node_counts.get("variable_assignment", 0),
        "command_count": node_counts.get("command", 0),
    }, (
        [
            AnalysisIssue(
                code="parse_error",
                message="Bash parse error",
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "",
                    range=SourceRange(start_line=1),
                ),
            )
        ]
        if has_error
        else []
    )


def _powershell_metrics(
    content: str, path: Path | None = None
) -> tuple[dict[str, int], list[AnalysisIssue]]:
    parser = _get_tree_sitter_parser("powershell")
    if parser is None:
        # Fallback: simple pattern-based counting for PowerShell
        import re as _re

        function_count = len(_re.findall(r"\bfunction\s+\w+", content, _re.IGNORECASE))
        class_count = len(_re.findall(r"\bclass\s+\w+", content, _re.IGNORECASE))
        param_count = content.count("param(")
        return {
            "function_count": function_count,
            "class_count": class_count,
            "param_block_count": param_count,
        }, []

    try:
        tree = parser.parse(
            (content if content.endswith("\n") else content + "\n").encode("utf-8")
        )
    except Exception:
        # Fallback on parse error
        import re as _re

        function_count = len(_re.findall(r"\bfunction\s+\w+", content, _re.IGNORECASE))
        class_count = len(_re.findall(r"\bclass\s+\w+", content, _re.IGNORECASE))
        param_count = content.count("param(")
        return {
            "function_count": function_count,
            "class_count": class_count,
            "param_block_count": param_count,
        }, []

    target_types = {
        "function_statement",
        "class_statement",
        "param_block",
    }
    node_counts = _count_ts_node_types(tree.root_node, target_types)

    has_error = tree.root_node.has_error

    return {
        "function_count": node_counts.get("function_statement", 0),
        "class_count": node_counts.get("class_statement", 0),
        "param_block_count": node_counts.get("param_block", 0),
    }, (
        [
            AnalysisIssue(
                code="parse_error",
                message="PowerShell parse error",
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "",
                    range=SourceRange(start_line=1),
                ),
            )
        ]
        if has_error
        else []
    )


def _dockerfile_metrics(
    content: str, path: Path | None = None
) -> tuple[dict[str, int], list[AnalysisIssue]]:
    parser = _get_tree_sitter_parser("dockerfile")
    if parser is None:
        return {}, []

    try:
        tree = parser.parse(
            (content if content.endswith("\n") else content + "\n").encode("utf-8")
        )
    except Exception:
        return {}, []

    instruction_types = {
        "from_instruction",
        "run_instruction",
        "copy_instruction",
        "add_instruction",
        "env_instruction",
        "expose_instruction",
        "arg_instruction",
    }
    node_counts = _count_ts_node_types(tree.root_node, instruction_types)

    has_error = tree.root_node.has_error

    return {
        "stage_count": node_counts.get("from_instruction", 0),
        "run_count": node_counts.get("run_instruction", 0),
        "copy_count": node_counts.get("copy_instruction", 0),
        "add_count": node_counts.get("add_instruction", 0),
        "env_count": node_counts.get("env_instruction", 0),
        "expose_count": node_counts.get("expose_instruction", 0),
        "arg_count": node_counts.get("arg_instruction", 0),
    }, (
        [
            AnalysisIssue(
                code="parse_error",
                message="Dockerfile parse error",
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "",
                    range=SourceRange(start_line=1),
                ),
            )
        ]
        if has_error
        else []
    )


def _hcl_metrics(
    content: str, path: Path | None = None
) -> tuple[dict[str, int], list[AnalysisIssue]]:
    parser = _get_tree_sitter_parser("hcl")
    if parser is None:
        return {}, []

    try:
        tree = parser.parse(
            (content if content.endswith("\n") else content + "\n").encode("utf-8")
        )
    except Exception:
        return {}, []

    # Count blocks and categorize by type
    block_count = 0
    resource_count = 0
    data_count = 0
    variable_count = 0
    output_count = 0
    module_count = 0
    provider_count = 0

    def walk_hcl(node: Any) -> None:
        nonlocal \
            block_count, \
            resource_count, \
            data_count, \
            variable_count, \
            output_count, \
            module_count, \
            provider_count
        if node.type == "block":
            block_count += 1
            # Get first identifier child to determine block type
            for child in node.children:
                if child.type == "identifier":
                    block_type = (
                        child.text.decode("utf-8")
                        if isinstance(child.text, bytes)
                        else str(child.text)
                    )
                    if block_type == "resource":
                        resource_count += 1
                    elif block_type == "data":
                        data_count += 1
                    elif block_type == "variable":
                        variable_count += 1
                    elif block_type == "output":
                        output_count += 1
                    elif block_type == "module":
                        module_count += 1
                    elif block_type == "provider":
                        provider_count += 1
                    break
        for child in node.children:
            walk_hcl(child)

    walk_hcl(tree.root_node)

    has_error = tree.root_node.has_error

    return {
        "block_count": block_count,
        "resource_count": resource_count,
        "data_count": data_count,
        "variable_count": variable_count,
        "output_count": output_count,
        "module_count": module_count,
        "provider_count": provider_count,
    }, (
        [
            AnalysisIssue(
                code="parse_error",
                message="HCL parse error",
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "",
                    range=SourceRange(start_line=1),
                ),
            )
        ]
        if has_error
        else []
    )


def _regex_metrics(
    content: str, path: Path | None = None
) -> tuple[dict[str, int], list[AnalysisIssue]]:
    parser = _get_tree_sitter_parser("regex")
    if parser is None:
        # Fallback to regex-based counting
        import re as _re

        group_count = len(_re.findall(r"\((?!\?:)", content))
        alternation_count = content.count("|")
        quantifier_count = len(_re.findall(r"[*+?]|\{[0-9,]+\}", content))
        character_class_count = content.count("[")
        return {
            "group_count": group_count,
            "alternation_count": alternation_count,
            "quantifier_count": quantifier_count,
            "character_class_count": character_class_count,
        }, []

    try:
        tree = parser.parse(
            (content if content.endswith("\n") else content + "\n").encode("utf-8")
        )
    except Exception:
        # Fallback to regex-based counting on parse error
        import re as _re

        group_count = len(_re.findall(r"\((?!\?:)", content))
        alternation_count = content.count("|")
        quantifier_count = len(_re.findall(r"[*+?]|\{[0-9,]+\}", content))
        character_class_count = content.count("[")
        return {
            "group_count": group_count,
            "alternation_count": alternation_count,
            "quantifier_count": quantifier_count,
            "character_class_count": character_class_count,
        }, []

    target_types = {
        "group",
        "alternation",
        "one_or_more",
        "zero_or_more",
        "count_quantifier",
        "character_class",
    }
    node_counts = _count_ts_node_types(tree.root_node, target_types)

    has_error = tree.root_node.has_error

    return {
        "group_count": node_counts.get("group", 0),
        "alternation_count": node_counts.get("alternation", 0),
        "quantifier_count": node_counts.get("one_or_more", 0)
        + node_counts.get("zero_or_more", 0)
        + node_counts.get("count_quantifier", 0),
        "character_class_count": node_counts.get("character_class", 0),
    }, (
        [
            AnalysisIssue(
                code="parse_error",
                message="Regex parse error",
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "",
                    range=SourceRange(start_line=1),
                ),
            )
        ]
        if has_error
        else []
    )


def _jq_metrics(
    content: str, path: Path | None = None
) -> tuple[dict[str, int], list[AnalysisIssue]]:
    parser = _get_tree_sitter_parser("jq")
    if parser is None:
        # Fallback to simple counts
        function_count = content.count("def ")
        pipe_count = content.count("|")
        return {
            "function_count": function_count,
            "pipe_count": pipe_count,
        }, []

    try:
        tree = parser.parse(
            (content if content.endswith("\n") else content + "\n").encode("utf-8")
        )
    except Exception:
        # Fallback to simple counts on parse error
        function_count = content.count("def ")
        pipe_count = content.count("|")
        return {
            "function_count": function_count,
            "pipe_count": pipe_count,
        }, []

    target_types = {
        "funcdef",
    }
    node_counts = _count_ts_node_types(tree.root_node, target_types)

    has_error = tree.root_node.has_error

    # Count pipe operators in source
    pipe_count = content.count("|")

    return {
        "function_count": node_counts.get("funcdef", 0),
        "pipe_count": pipe_count,
    }, (
        [
            AnalysisIssue(
                code="parse_error",
                message="JQ parse error",
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "",
                    range=SourceRange(start_line=1),
                ),
            )
        ]
        if has_error
        else []
    )


def _csv_metrics(content: str) -> dict[str, int]:
    import csv as _csv

    lines = [line for line in content.splitlines() if line.strip()]
    if not lines:
        return {"row_count": 0, "column_count": 0, "empty_cell_count": 0}

    reader = list(_csv.reader(lines, delimiter=","))
    col_count = len(reader[0]) if reader else 0
    empty = sum(1 for row in reader for cell in row if not cell.strip())

    return {
        "row_count": len(reader),
        "column_count": col_count,
        "empty_cell_count": empty,
    }


def _tsv_metrics(content: str) -> dict[str, int]:
    import csv as _csv

    lines = [line for line in content.splitlines() if line.strip()]
    if not lines:
        return {"row_count": 0, "column_count": 0, "empty_cell_count": 0}

    reader = list(_csv.reader(lines, delimiter="\t"))
    col_count = len(reader[0]) if reader else 0
    empty = sum(1 for row in reader for cell in row if not cell.strip())

    return {
        "row_count": len(reader),
        "column_count": col_count,
        "empty_cell_count": empty,
    }


_TS_PARSER_CACHE: dict[str, Any] = {}


def _get_tree_sitter_parser(language: str) -> Any | None:
    if language in _TS_PARSER_CACHE:
        return _TS_PARSER_CACHE[language]

    # Use individual packages directly (avoid language-pack compatibility)
    try:
        from tree_sitter import Language, Parser as TSParser

        lang_obj = None
        if language == "javascript":
            import tree_sitter_javascript as tjs

            lang_obj = Language(tjs.language())
        elif language == "typescript":
            import tree_sitter_typescript as tts

            lang_obj = Language(tts.language_typescript())
        elif language == "go":
            import tree_sitter_go as tgo

            lang_obj = Language(tgo.language())
        elif language == "rust":
            import tree_sitter_rust as trs

            lang_obj = Language(trs.language())
        elif language == "bash":
            import tree_sitter_bash as tb

            lang_obj = Language(tb.language())
        elif language == "dockerfile":
            import tree_sitter_dockerfile as tdf

            lang_obj = Language(tdf.language())
        elif language == "hcl":
            import tree_sitter_hcl as thcl

            lang_obj = Language(thcl.language())

        parser = TSParser(lang_obj) if lang_obj is not None else None
    except ImportError:
        parser = None

    _TS_PARSER_CACHE[language] = parser
    return parser


def _count_ts_node_types(node: Any, target_types: set[str]) -> dict[str, int]:
    counts: dict[str, int] = {}

    def walk(n: Any) -> None:
        if n.type in target_types:
            counts[n.type] = counts.get(n.type, 0) + 1
        for child in n.children:
            walk(child)

    walk(node)
    return counts


def _javascript_metrics(
    content: str, path: Path | None = None
) -> tuple[dict[str, int], list[AnalysisIssue]]:
    parser = _get_tree_sitter_parser("javascript")
    if parser is None:
        return {}, []

    try:
        tree = parser.parse(
            (content if content.endswith("\n") else content + "\n").encode("utf-8")
        )
    except Exception:
        return {}, []

    target_types = {
        "function_declaration",
        "arrow_function",
        "function_expression",
        "class_declaration",
        "method_definition",
        "import_statement",
    }
    node_counts = _count_ts_node_types(tree.root_node, target_types)

    has_error = tree.root_node.has_error

    return {
        "function_count": node_counts.get("function_declaration", 0)
        + node_counts.get("arrow_function", 0)
        + node_counts.get("function_expression", 0),
        "class_count": node_counts.get("class_declaration", 0),
        "method_count": node_counts.get("method_definition", 0),
        "import_count": node_counts.get("import_statement", 0),
    }, (
        [
            AnalysisIssue(
                code="parse_error",
                message="JavaScript parse error",
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "",
                    range=SourceRange(start_line=1),
                ),
            )
        ]
        if has_error
        else []
    )


def _typescript_metrics(
    content: str, path: Path | None = None
) -> tuple[dict[str, int], list[AnalysisIssue]]:
    parser = _get_tree_sitter_parser("typescript")
    if parser is None:
        return {}, []

    try:
        tree = parser.parse(
            (content if content.endswith("\n") else content + "\n").encode("utf-8")
        )
    except Exception:
        return {}, []

    target_types = {
        "function_declaration",
        "arrow_function",
        "function_expression",
        "class_declaration",
        "method_definition",
        "import_statement",
        "interface_declaration",
        "type_alias_declaration",
        "enum_declaration",
    }
    node_counts = _count_ts_node_types(tree.root_node, target_types)

    has_error = tree.root_node.has_error

    return {
        "function_count": node_counts.get("function_declaration", 0)
        + node_counts.get("arrow_function", 0)
        + node_counts.get("function_expression", 0),
        "class_count": node_counts.get("class_declaration", 0),
        "method_count": node_counts.get("method_definition", 0),
        "import_count": node_counts.get("import_statement", 0),
        "interface_count": node_counts.get("interface_declaration", 0),
        "type_alias_count": node_counts.get("type_alias_declaration", 0),
        "enum_count": node_counts.get("enum_declaration", 0),
    }, (
        [
            AnalysisIssue(
                code="parse_error",
                message="TypeScript parse error",
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "",
                    range=SourceRange(start_line=1),
                ),
            )
        ]
        if has_error
        else []
    )


def _go_metrics(
    content: str, path: Path | None = None
) -> tuple[dict[str, int], list[AnalysisIssue]]:
    parser = _get_tree_sitter_parser("go")
    if parser is None:
        return {}, []

    try:
        tree = parser.parse(
            (content if content.endswith("\n") else content + "\n").encode("utf-8")
        )
    except Exception:
        return {}, []

    target_types = {
        "function_declaration",
        "method_declaration",
        "type_declaration",
        "import_declaration",
    }
    node_counts = _count_ts_node_types(tree.root_node, target_types)

    has_error = tree.root_node.has_error

    return {
        "function_count": node_counts.get("function_declaration", 0),
        "method_count": node_counts.get("method_declaration", 0),
        "type_count": node_counts.get("type_declaration", 0),
        "import_count": node_counts.get("import_declaration", 0),
    }, (
        [
            AnalysisIssue(
                code="parse_error",
                message="Go parse error",
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "",
                    range=SourceRange(start_line=1),
                ),
            )
        ]
        if has_error
        else []
    )


def _rust_metrics(
    content: str, path: Path | None = None
) -> tuple[dict[str, int], list[AnalysisIssue]]:
    parser = _get_tree_sitter_parser("rust")
    if parser is None:
        return {}, []

    try:
        tree = parser.parse(
            (content if content.endswith("\n") else content + "\n").encode("utf-8")
        )
    except Exception:
        return {}, []

    target_types = {
        "function_item",
        "struct_item",
        "enum_item",
        "impl_item",
        "trait_item",
        "mod_item",
    }
    node_counts = _count_ts_node_types(tree.root_node, target_types)

    has_error = tree.root_node.has_error

    return {
        "function_count": node_counts.get("function_item", 0),
        "struct_count": node_counts.get("struct_item", 0),
        "enum_count": node_counts.get("enum_item", 0),
        "impl_count": node_counts.get("impl_item", 0),
        "trait_count": node_counts.get("trait_item", 0),
        "mod_count": node_counts.get("mod_item", 0),
    }, (
        [
            AnalysisIssue(
                code="parse_error",
                message="Rust parse error",
                severity="error",
                location=CodeLocation(
                    path=str(path) if path else "",
                    range=SourceRange(start_line=1),
                ),
            )
        ]
        if has_error
        else []
    )


async def analyze_code(path: str) -> AnalyzeCodeResult:
    """Analyze code structure and quality metrics for a file."""
    tracer = get_current_tracer()
    with (
        tracer.span("tool.analyze_code", path=path)
        if tracer
        else contextlib.nullcontext()
    ):
        return await asyncio.to_thread(_analyze_code_sync, Path(path).resolve())


def _analyze_code_sync(path: Path) -> AnalyzeCodeResult:
    if not path.exists():
        return AnalyzeCodeResult(
            path=str(path),
            meta=ToolResultMeta(
                ok=False,
                error_code="not_found",
                error_message=f"File {path} does not exist.",
            ),
        )
    if not path.is_file():
        return AnalyzeCodeResult(
            path=str(path),
            meta=ToolResultMeta(
                ok=False,
                error_code="not_a_file",
                error_message=f"{path} is not a file.",
            ),
        )

    language = _detect_language(path)
    if language is None:
        return AnalyzeCodeResult(path=str(path), meta=_unsupported_language_meta(path))

    content = _read_text(path)
    metrics = {
        "line_count": content.count("\n")
        + (0 if not content or content.endswith("\n") else 1)
    }

    extra_metrics, issues = _dispatch_analyze(language, content, path)
    metrics.update(extra_metrics)
    return AnalyzeCodeResult(
        path=str(path),
        language=language,
        freshness_strategy=_FRESHNESS_STRATEGY,
        issues=issues,
        metrics=metrics,
    )

    # --- legacy dispatch removed (kept below as dead code until task 10.14 cleanup) ---
    if False and language == "python":
        symbols, _, issues = _python_symbols_for_text(path, content)
        metrics.update(
            {
                "symbol_count": len(symbols),
                "function_count": sum(
                    1 for symbol in symbols if symbol.kind == "function"
                ),
                "class_count": sum(1 for symbol in symbols if symbol.kind == "class"),
                "variable_count": sum(
                    1 for symbol in symbols if symbol.kind == "variable"
                ),
            }
        )
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            issues=issues,
            metrics=metrics,
        )

    if language == "toml":
        toml_metrics, toml_issues = _toml_metrics(content, path)
        metrics.update(toml_metrics)
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            issues=toml_issues,
            metrics=metrics,
        )

    if language == "markdown":
        metrics.update(_markdown_metrics(content))
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            metrics=metrics,
        )

    if language == "yaml":
        yaml_metrics, yaml_issues = _yaml_metrics(content, path)
        metrics.update(yaml_metrics)
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            issues=yaml_issues,
            metrics=metrics,
        )

    if language == "sql":
        sql_metrics, sql_issues = _sql_metrics(content)
        metrics.update(sql_metrics)
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            issues=sql_issues,
            metrics=metrics,
        )

    if language == "bash":
        bash_metrics, bash_issues = _bash_metrics(content, path)
        metrics.update(bash_metrics)
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            issues=bash_issues,
            metrics=metrics,
        )

    if language == "powershell":
        ps_metrics, ps_issues = _powershell_metrics(content, path)
        metrics.update(ps_metrics)
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            issues=ps_issues,
            metrics=metrics,
        )

    if language == "dockerfile":
        df_metrics, df_issues = _dockerfile_metrics(content, path)
        metrics.update(df_metrics)
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            issues=df_issues,
            metrics=metrics,
        )

    if language == "hcl":
        hcl_metrics, hcl_issues = _hcl_metrics(content, path)
        metrics.update(hcl_metrics)
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            issues=hcl_issues,
            metrics=metrics,
        )

    if language == "regex":
        regex_metrics, regex_issues = _regex_metrics(content, path)
        metrics.update(regex_metrics)
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            issues=regex_issues,
            metrics=metrics,
        )

    if language == "jq":
        jq_metrics, jq_issues = _jq_metrics(content, path)
        metrics.update(jq_metrics)
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            issues=jq_issues,
            metrics=metrics,
        )

    if language == "csv":
        metrics.update(_csv_metrics(content))
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            metrics=metrics,
        )

    if language == "tsv":
        metrics.update(_tsv_metrics(content))
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            metrics=metrics,
        )

    if language == "javascript":
        js_metrics, js_issues = _javascript_metrics(content, path)
        metrics.update(js_metrics)
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            issues=js_issues,
            metrics=metrics,
        )

    if language == "typescript":
        ts_metrics, ts_issues = _typescript_metrics(content, path)
        metrics.update(ts_metrics)
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            issues=ts_issues,
            metrics=metrics,
        )

    if language == "go":
        go_metrics, go_issues = _go_metrics(content, path)
        metrics.update(go_metrics)
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            issues=go_issues,
            metrics=metrics,
        )

    if language == "rust":
        rust_metrics, rust_issues = _rust_metrics(content, path)
        metrics.update(rust_metrics)
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            issues=rust_issues,
            metrics=metrics,
        )

    try:
        payload = json.loads(content)
    except json.JSONDecodeError as exc:
        return AnalyzeCodeResult(
            path=str(path),
            language=language,
            freshness_strategy=_FRESHNESS_STRATEGY,
            issues=[
                AnalysisIssue(
                    code="json_parse_error",
                    message=exc.msg,
                    severity="error",
                    location=CodeLocation(
                        path=str(path),
                        range=SourceRange(
                            start_line=exc.lineno or 1,
                            start_col=exc.colno - 1 if exc.colno else 0,
                        ),
                    ),
                )
            ],
            metrics=metrics,
        )

    metrics.update(_json_metrics(payload))
    return AnalyzeCodeResult(
        path=str(path),
        language=language,
        freshness_strategy=_FRESHNESS_STRATEGY,
        metrics=metrics,
    )


async def check_style(path: str, ruleset: str | None = None) -> CheckStyleResult:
    """Check code style compliance against a ruleset."""
    tracer = get_current_tracer()
    with (
        tracer.span("tool.check_style", path=path, ruleset=ruleset)
        if tracer
        else contextlib.nullcontext()
    ):
        return await asyncio.to_thread(_check_style_sync, Path(path).resolve(), ruleset)


def _check_style_sync(path: Path, ruleset: str | None) -> CheckStyleResult:
    if not path.exists():
        return CheckStyleResult(
            path=str(path),
            meta=ToolResultMeta(
                ok=False,
                error_code="not_found",
                error_message=f"File {path} does not exist.",
            ),
        )
    if not path.is_file():
        return CheckStyleResult(
            path=str(path),
            meta=ToolResultMeta(
                ok=False,
                error_code="not_a_file",
                error_message=f"{path} is not a file.",
            ),
        )

    language = _detect_language(path)
    if language is None:
        return CheckStyleResult(path=str(path), meta=_unsupported_language_meta(path))

    content = _read_text(path)
    result = _dispatch_check_style(language, path, content, ruleset)
    if result is not None:
        return result

    return CheckStyleResult(
        path=str(path),
        language=language,
        ruleset=ruleset,
        freshness_strategy=_FRESHNESS_STRATEGY,
        passed=True,
    )

    # --- legacy dispatch ---
    if False and language == "python" and shutil.which("ruff"):
        return _check_python_style_with_ruff(path, ruleset)

    if False and language == "json":
        try:
            json.loads(_read_text(path))
            return CheckStyleResult(
                path=str(path),
                language=language,
                ruleset=ruleset,
                freshness_strategy=_FRESHNESS_STRATEGY,
                passed=True,
            )
        except json.JSONDecodeError as exc:
            return CheckStyleResult(
                path=str(path),
                language=language,
                ruleset=ruleset,
                freshness_strategy=_FRESHNESS_STRATEGY,
                passed=False,
                violations=[
                    StyleViolation(
                        code="json_parse_error",
                        message=exc.msg,
                        severity="error",
                        location=CodeLocation(
                            path=str(path),
                            range=SourceRange(
                                start_line=exc.lineno or 1,
                                start_col=exc.colno - 1 if exc.colno else 0,
                            ),
                        ),
                    )
                ],
            )

    return CheckStyleResult(
        path=str(path),
        language=language,
        ruleset=ruleset,
        freshness_strategy=_FRESHNESS_STRATEGY,
        meta=ToolResultMeta(
            ok=False,
            error_code="tool_unavailable",
            error_message="No tool-backed style checker is available for this language.",
        ),
    )


def _check_python_style_with_ruff(path: Path, ruleset: str | None) -> CheckStyleResult:
    import subprocess  # nosec B404

    cmd = ["ruff", "check", "--output-format", "json", str(path)]
    if ruleset:
        cmd.extend(["--config", ruleset])
    proc = subprocess.run(  # nosec B603
        cmd,
        capture_output=True,
        text=True,
        check=False,
    )
    if proc.returncode not in {0, 1}:
        return CheckStyleResult(
            path=str(path),
            language="python",
            ruleset=ruleset,
            freshness_strategy=_FRESHNESS_STRATEGY,
            meta=ToolResultMeta(
                ok=False,
                error_code="execution_failed",
                error_message=proc.stderr.strip() or "ruff check failed",
            ),
        )

    payload = json.loads(proc.stdout or "[]")
    violations = [
        StyleViolation(
            code=item.get("code", "ruff"),
            message=item.get("message", ""),
            severity="warning",
            location=CodeLocation(
                path=item.get("filename", str(path)),
                range=SourceRange(
                    start_line=item.get("location", {}).get("row", 1),
                    start_col=max(item.get("location", {}).get("column", 1) - 1, 0),
                    end_line=item.get("end_location", {}).get("row"),
                    end_col=(
                        max(item.get("end_location", {}).get("column", 1) - 1, 0)
                        if item.get("end_location")
                        else None
                    ),
                ),
            ),
        )
        for item in payload
    ]
    return CheckStyleResult(
        path=str(path),
        language="python",
        ruleset=ruleset,
        freshness_strategy=_FRESHNESS_STRATEGY,
        violations=violations,
        passed=not violations,
    )


async def document_symbols(path: str) -> DocumentSymbolsResult:
    tracer = get_current_tracer()
    with (
        tracer.span("tool.document_symbols", path=path)
        if tracer
        else contextlib.nullcontext()
    ):
        return await asyncio.to_thread(_document_symbols_sync, Path(path).resolve())


def _document_symbols_sync(path: Path) -> DocumentSymbolsResult:
    if not path.exists():
        return DocumentSymbolsResult(
            path=str(path),
            meta=ToolResultMeta(
                ok=False,
                error_code="not_found",
                error_message=f"File {path} does not exist.",
            ),
        )
    if not path.is_file():
        return DocumentSymbolsResult(
            path=str(path),
            meta=ToolResultMeta(
                ok=False,
                error_code="not_a_file",
                error_message=f"{path} is not a file.",
            ),
        )
    language = _detect_language(path)
    if language is None:
        return DocumentSymbolsResult(
            path=str(path), meta=_unsupported_language_meta(path)
        )

    content = _read_text(path)
    dispatched = _dispatch_symbols(language, path, content)
    if dispatched is not None:
        symbols, issues = dispatched
    elif language == "python":
        symbols, _, issues = _python_symbols_for_text(path, content)
    else:
        symbols, issues = _json_document_symbols(path, content)
    meta = ToolResultMeta()
    if issues:
        meta = ToolResultMeta(
            ok=False,
            error_code=issues[0].code,
            error_message=issues[0].message,
        )
    return DocumentSymbolsResult(
        path=str(path),
        language=language,
        freshness_strategy=_FRESHNESS_STRATEGY,
        symbol_count=len(symbols),
        symbols=symbols,
        meta=meta,
    )


async def workspace_symbols(
    query: str,
    *,
    workspace_root: str | Path = ".",
    max_results: int = 50,
) -> WorkspaceSymbolsResult:
    tracer = get_current_tracer()
    with (
        tracer.span("tool.workspace_symbols", query=query)
        if tracer
        else contextlib.nullcontext()
    ):
        return await asyncio.to_thread(
            _workspace_symbols_sync,
            query,
            Path(workspace_root).resolve(),
            max_results,
        )


def _workspace_symbols_sync(
    query: str, workspace_root: Path, max_results: int
) -> WorkspaceSymbolsResult:
    if max_results < 1:
        return WorkspaceSymbolsResult(
            query=query,
            meta=ToolResultMeta(
                ok=False,
                error_code="invalid_input",
                error_message="max_results must be 1 or greater",
            ),
        )
    query_lower = query.lower()
    matches: list[SymbolInfo] = []
    for path in _walk_workspace_files(workspace_root):
        doc_result = _document_symbols_sync(path)
        for symbol in doc_result.symbols:
            if query_lower in symbol.name.lower():
                matches.append(symbol)

    truncated = len(matches) > max_results
    return WorkspaceSymbolsResult(
        query=query,
        freshness_strategy=_FRESHNESS_STRATEGY,
        symbol_count=len(matches),
        truncated=truncated,
        symbols=matches[:max_results],
    )


async def find_definition(
    symbol: str,
    *,
    path: str | None = None,
    workspace_root: str | Path = ".",
) -> DefinitionResult:
    tracer = get_current_tracer()
    with (
        tracer.span("tool.find_definition", symbol=symbol)
        if tracer
        else contextlib.nullcontext()
    ):
        return await asyncio.to_thread(
            _find_definition_sync,
            symbol,
            Path(path).resolve() if path is not None else None,
            Path(workspace_root).resolve(),
        )


def _find_definition_sync(
    symbol: str, preferred_path: Path | None, workspace_root: Path
) -> DefinitionResult:
    candidates = list(_walk_workspace_files(workspace_root))
    if preferred_path is not None and preferred_path in candidates:
        candidates.remove(preferred_path)
        candidates.insert(0, preferred_path)

    for path in candidates:
        if _detect_language(path) != "python":
            continue
        symbols, _, issues = _python_symbols_for_text(path, _read_text(path))
        if issues:
            continue
        for candidate in symbols:
            if candidate.name == symbol:
                return DefinitionResult(
                    query=symbol,
                    language="python",
                    freshness_strategy=_FRESHNESS_STRATEGY,
                    symbol=candidate,
                )

    return DefinitionResult(
        query=symbol,
        freshness_strategy=_FRESHNESS_STRATEGY,
        meta=ToolResultMeta(
            ok=False,
            error_code="not_found",
            error_message=f"Definition for {symbol!r} was not found.",
        ),
    )


async def find_references(
    symbol: str,
    *,
    workspace_root: str | Path = ".",
    max_results: int = 100,
) -> ReferencesResult:
    tracer = get_current_tracer()
    with (
        tracer.span("tool.find_references", symbol=symbol)
        if tracer
        else contextlib.nullcontext()
    ):
        return await asyncio.to_thread(
            _find_references_sync,
            symbol,
            Path(workspace_root).resolve(),
            max_results,
        )


def _find_references_sync(
    symbol: str, workspace_root: Path, max_results: int
) -> ReferencesResult:
    if max_results < 1:
        return ReferencesResult(
            query=symbol,
            meta=ToolResultMeta(
                ok=False,
                error_code="invalid_input",
                error_message="max_results must be 1 or greater",
            ),
        )
    references: list[CodeLocation] = []
    for path in _walk_workspace_files(workspace_root):
        if _detect_language(path) != "python":
            continue
        _, refs, issues = _python_symbols_for_text(path, _read_text(path))
        if issues:
            continue
        references.extend(refs.get(symbol, []))

    truncated = len(references) > max_results
    return ReferencesResult(
        query=symbol,
        language="python",
        freshness_strategy=_FRESHNESS_STRATEGY,
        reference_count=len(references),
        truncated=truncated,
        references=references[:max_results],
    )
