from __future__ import annotations

import functools
import inspect
from contextlib import nullcontext
from typing import Any

from mirascope import llm

from kiss.agent.plan_types import WriteBlockedResult
from kiss.core.deps import AgentDeps

_HARD_BLOCKED_SENTINEL = "__kiss_hard_blocked__"


def write_gated(fn):
    """Block write tools until the host explicitly approves the turn."""

    @functools.wraps(fn)
    async def wrapper(ctx: llm.Context[AgentDeps], *args: Any, **kwargs: Any) -> Any:
        if not ctx.deps.writes_approved:
            bound = inspect.signature(fn).bind(ctx, *args, **kwargs)
            bound.apply_defaults()
            tool_args = {k: v for k, v in bound.arguments.items() if k != "ctx"}
            return WriteBlockedResult(tool_name=fn.__name__, args=tool_args)
        return await fn(ctx, *args, **kwargs)

    return wrapper


def pre_execute_tracked(fn):
    """Universal pre-execution wrapper: registers args hash, emits event, gates hard-blocked calls, times execution."""

    @functools.wraps(fn)
    async def wrapper(ctx: llm.Context[AgentDeps], *args: Any, **kwargs: Any) -> Any:
        bound = inspect.signature(fn).bind(ctx, *args, **kwargs)
        bound.apply_defaults()
        tool_args = {k: v for k, v in bound.arguments.items() if k != "ctx"}

        # C3a: register directly — decoupled from on_tool_use
        ctx.deps.stuck_loop_tracker.register_tool_call(fn.__name__, tool_args)
        if ctx.deps.on_tool_use:
            await ctx.deps.on_tool_use(fn.__name__, tool_args)

        if ctx.deps.stuck_loop_tracker.is_hard_blocked(fn.__name__, tool_args):
            return _HARD_BLOCKED_SENTINEL

        tracer = ctx.deps.tracer
        with tracer.span(f"tool.{fn.__name__}") if tracer else nullcontext():
            return await fn(ctx, *args, **kwargs)

    return wrapper
