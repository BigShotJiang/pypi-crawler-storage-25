"""Unified tool registry for the planner runtime."""

from __future__ import annotations

import enum
from pathlib import Path
from typing import Any, cast

from mirascope import llm
from mirascope.llm.tools import AsyncContextToolFn

from kiss.agent.context_refs import expand_context_ref
from kiss.agent.plan_types import TurnPhase
from kiss.agent.tool_scoping import ToolSetName
from kiss.agent.tools.gate import pre_execute_tracked, write_gated
from kiss.agent.tools.ask_user import ask_user
from kiss.agent.tools.implementations import (
    analyze_code,
    apply_patch,
    check_style,
    document_symbols,
    edit_file,
    fetch_url,
    find_definition,
    find_references,
    git_commit,
    git_diff,
    git_log,
    git_stage,
    git_status,
    git_unstage,
    glob,
    list_directory,
    read_file_coder,
    run_bash,
    search_code,
    web_search,
    workspace_symbols,
    write_file,
)
from kiss.agent.tools.logic.run_python import run_python
from kiss.agent.tools.memory import append_memory, read_memory
from kiss.agent.tools.result_types import ExpandRefResult, ToolResultMeta
from kiss.agent.tools.todos import (
    add_todo,
    block_todo,
    claim_todo,
    complete_todo,
    done_todo,
    list_todos,
    post_team_message,
    read_team_messages,
    unblock_todo,
)
from kiss.core.deps import AgentDeps


class ToolCategory(enum.Enum):
    SEARCH = "search"
    WRITE = "write"
    GIT = "git"
    EXECUTE = "execute"
    VALIDATION = "validation"
    EXTERNAL = "external"
    COLLABORATION = "collaboration"
    MCP_A2A = "mcp_a2a"


_ALWAYS_ON_TOOL_NAMES = {
    "ask_user",
    "memory_append",
    "memory_read",
    "add_todo",
    "done_todo",
    "list_todos",
    "claim_todo",
    "complete_todo",
    "block_todo",
    "unblock_todo",
    "post_team_message",
    "read_team_messages",
    "expand_ref",
    "self_compact",
}

_WRITE_TOOL_NAMES = frozenset(
    {
        "write_file",
        "edit_file",
        "apply_patch",
        "git_commit",
        "git_stage",
        "run_python",
        "run_bash",
    }
)

_TOOL_SET_CATEGORIES: dict[ToolSetName, frozenset[ToolCategory]] = {
    "search": frozenset(
        {
            ToolCategory.SEARCH,
            ToolCategory.GIT,
            ToolCategory.VALIDATION,
            ToolCategory.EXTERNAL,
            ToolCategory.COLLABORATION,
        }
    ),
    "edit": frozenset(
        {
            ToolCategory.SEARCH,
            ToolCategory.WRITE,
            ToolCategory.GIT,
            ToolCategory.EXECUTE,
            ToolCategory.VALIDATION,
            ToolCategory.EXTERNAL,
            ToolCategory.COLLABORATION,
        }
    ),
    "validate": frozenset(
        {
            ToolCategory.SEARCH,
            ToolCategory.GIT,
            ToolCategory.VALIDATION,
            ToolCategory.EXTERNAL,
            ToolCategory.COLLABORATION,
        }
    ),
    "full": frozenset(category for category in ToolCategory),
}

_PHASE_BLOCKED_TOOL_NAMES: dict[TurnPhase, frozenset[str]] = {
    TurnPhase.RESEARCH: frozenset(
        {
            "edit_file",
            "write_file",
            "apply_patch",
            "git_commit",
            "git_stage",
            "run_bash",
            "run_python",
        }
    ),
    TurnPhase.PLANNING: frozenset({"git_commit"}),
    TurnPhase.EXECUTION: frozenset(),
}


def _workspace_root(ctx: llm.Context[AgentDeps]) -> Path | None:
    return ctx.deps.workspace_root


def _build_memory_append() -> AsyncContextToolFn:
    async def memory_append(
        ctx: llm.Context[AgentDeps],
        text: str,
        scope: str = "project",
    ) -> str:
        """Append a bullet to memory. scope: 'global' or 'project'."""
        root = _workspace_root(ctx)
        if not ctx.deps.memory_enabled:
            return "memory disabled"
        if root is None:
            return "memory unavailable: workspace root is not configured."
        return await append_memory(text, scope, root)

    return cast(AsyncContextToolFn, memory_append)


def _build_memory_read() -> AsyncContextToolFn:
    async def memory_read(
        ctx: llm.Context[AgentDeps],
        scope: str = "both",
    ) -> str:
        """Read current memory contents. scope: 'global', 'project', or 'both'."""
        root = _workspace_root(ctx)
        if not ctx.deps.memory_enabled:
            return "memory disabled"
        if root is None:
            return "memory unavailable: workspace root is not configured."
        return await read_memory(scope, root)

    return cast(AsyncContextToolFn, memory_read)


def _build_expand_ref() -> AsyncContextToolFn:
    async def expand_ref(ctx: llm.Context[AgentDeps], ref: str) -> ExpandRefResult:
        """Expand a user-mentioned @ref from the current turn to fetch file content."""
        root = _workspace_root(ctx)
        if root is None:
            return ExpandRefResult(
                ref=ref,
                meta=ToolResultMeta(
                    ok=False,
                    error_code="execution_failed",
                    error_message="Workspace root is not configured.",
                ),
            )
        return expand_context_ref(ref, ctx.deps.resolved_refs, root)

    return cast(AsyncContextToolFn, expand_ref)


def _build_self_compact() -> AsyncContextToolFn:
    async def self_compact(ctx: llm.Context[AgentDeps], reason: str) -> str:
        """Request host-managed context compaction at the next safe boundary."""
        ctx.deps.compact_requested = reason
        return "Context will be compacted. Finish your response now."

    return cast(AsyncContextToolFn, self_compact)


def _build_read_file() -> AsyncContextToolFn:
    # Using coder (safe) variant; researcher/reviewer variants not needed post-plan-mode.
    return cast(AsyncContextToolFn, read_file_coder)


def _decorate(name: str, impl: AsyncContextToolFn, *, gate_writes: bool) -> Any:
    tool_impl = write_gated(impl) if gate_writes and name in _WRITE_TOOL_NAMES else impl
    tool_impl = pre_execute_tracked(tool_impl)
    decorated = llm.tool(tool_impl)
    decorated.__name__ = name
    return decorated


def _tool_specs() -> list[tuple[str, ToolCategory, AsyncContextToolFn]]:
    return [
        ("ask_user", ToolCategory.COLLABORATION, cast(AsyncContextToolFn, ask_user)),
        ("read_file", ToolCategory.SEARCH, _build_read_file()),
        ("search_code", ToolCategory.SEARCH, cast(AsyncContextToolFn, search_code)),
        ("glob", ToolCategory.SEARCH, cast(AsyncContextToolFn, glob)),
        (
            "list_directory",
            ToolCategory.SEARCH,
            cast(AsyncContextToolFn, list_directory),
        ),
        ("analyze_code", ToolCategory.SEARCH, cast(AsyncContextToolFn, analyze_code)),
        ("write_file", ToolCategory.WRITE, cast(AsyncContextToolFn, write_file)),
        ("edit_file", ToolCategory.WRITE, cast(AsyncContextToolFn, edit_file)),
        ("apply_patch", ToolCategory.WRITE, cast(AsyncContextToolFn, apply_patch)),
        ("run_bash", ToolCategory.EXECUTE, cast(AsyncContextToolFn, run_bash)),
        ("run_python", ToolCategory.EXECUTE, cast(AsyncContextToolFn, run_python)),
        ("git_status", ToolCategory.GIT, cast(AsyncContextToolFn, git_status)),
        ("git_diff", ToolCategory.GIT, cast(AsyncContextToolFn, git_diff)),
        ("git_log", ToolCategory.GIT, cast(AsyncContextToolFn, git_log)),
        ("git_stage", ToolCategory.GIT, cast(AsyncContextToolFn, git_stage)),
        ("git_unstage", ToolCategory.GIT, cast(AsyncContextToolFn, git_unstage)),
        ("git_commit", ToolCategory.GIT, cast(AsyncContextToolFn, git_commit)),
        ("check_style", ToolCategory.VALIDATION, cast(AsyncContextToolFn, check_style)),
        (
            "find_definition",
            ToolCategory.VALIDATION,
            cast(AsyncContextToolFn, find_definition),
        ),
        (
            "find_references",
            ToolCategory.VALIDATION,
            cast(AsyncContextToolFn, find_references),
        ),
        (
            "document_symbols",
            ToolCategory.VALIDATION,
            cast(AsyncContextToolFn, document_symbols),
        ),
        (
            "workspace_symbols",
            ToolCategory.VALIDATION,
            cast(AsyncContextToolFn, workspace_symbols),
        ),
        ("fetch_url", ToolCategory.EXTERNAL, cast(AsyncContextToolFn, fetch_url)),
        ("web_search", ToolCategory.EXTERNAL, cast(AsyncContextToolFn, web_search)),
        ("memory_append", ToolCategory.COLLABORATION, _build_memory_append()),
        ("memory_read", ToolCategory.COLLABORATION, _build_memory_read()),
        ("add_todo", ToolCategory.COLLABORATION, cast(AsyncContextToolFn, add_todo)),
        ("done_todo", ToolCategory.COLLABORATION, cast(AsyncContextToolFn, done_todo)),
        (
            "list_todos",
            ToolCategory.COLLABORATION,
            cast(AsyncContextToolFn, list_todos),
        ),
        (
            "claim_todo",
            ToolCategory.COLLABORATION,
            cast(AsyncContextToolFn, claim_todo),
        ),
        (
            "complete_todo",
            ToolCategory.COLLABORATION,
            cast(AsyncContextToolFn, complete_todo),
        ),
        (
            "block_todo",
            ToolCategory.COLLABORATION,
            cast(AsyncContextToolFn, block_todo),
        ),
        (
            "unblock_todo",
            ToolCategory.COLLABORATION,
            cast(AsyncContextToolFn, unblock_todo),
        ),
        (
            "post_team_message",
            ToolCategory.COLLABORATION,
            cast(AsyncContextToolFn, post_team_message),
        ),
        (
            "read_team_messages",
            ToolCategory.COLLABORATION,
            cast(AsyncContextToolFn, read_team_messages),
        ),
        ("expand_ref", ToolCategory.COLLABORATION, _build_expand_ref()),
        ("self_compact", ToolCategory.COLLABORATION, _build_self_compact()),
    ]


def create_all_tools(
    tool_set: ToolSetName = "full",
    phase: TurnPhase = TurnPhase.RESEARCH,
    *,
    gate_writes: bool = True,
) -> list[Any]:
    allowed_categories = _TOOL_SET_CATEGORIES[tool_set]
    blocked_names = _PHASE_BLOCKED_TOOL_NAMES[phase]
    tools: list[Any] = []
    for name, category, impl in _tool_specs():
        if name not in _ALWAYS_ON_TOOL_NAMES and category not in allowed_categories:
            continue
        if name in blocked_names:
            continue
        tools.append(_decorate(name, impl, gate_writes=gate_writes))
    return tools
