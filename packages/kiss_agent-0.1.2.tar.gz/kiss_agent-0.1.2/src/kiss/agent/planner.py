"""Compatibility shim for the TurnEngine rename."""

from kiss.agent.turn_engine import (
    TurnEngine,
    _extract_claimed_paths_from_task,
    _extract_explicit_write_file_request,
    _is_file_write_task,
    _snapshot_paths,
    _verified_file_write,
    format_plan,
    prompt_load,
)

Planner = TurnEngine

__all__ = [
    "Planner",
    "TurnEngine",
    "_extract_claimed_paths_from_task",
    "_extract_explicit_write_file_request",
    "_is_file_write_task",
    "_snapshot_paths",
    "_verified_file_write",
    "format_plan",
    "prompt_load",
]
