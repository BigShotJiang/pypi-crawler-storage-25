"""Shared streaming and retry helpers for mirascope agent loops"""

from __future__ import annotations

from collections import defaultdict, deque
from collections.abc import AsyncGenerator, Awaitable, Callable, Sequence
from dataclasses import dataclass
from difflib import get_close_matches
from typing import TYPE_CHECKING, Any, Protocol, TypeVar

from mirascope import llm
from mirascope.llm.exceptions import ToolExecutionError, ToolNotFoundError
from pydantic import ValidationError as PydanticValidationError

from kiss.agent.plan_types import PlanExecutionState, WriteBlockedResult
from kiss.agent.tools.result_types import ReadFileResult
from kiss.agent.tools.truncation import (
    estimate_tokens,
    prepare_tool_output,
    tool_result_failed,
)
from kiss.core.errors import StuckLoopError
from kiss.core.deps import AgentDeps, HealingAction, StuckLoopCheck
from kiss.providers.normalization import LLMResponseChunk

if TYPE_CHECKING:
    from kiss.core.settings import Settings

OnChunk = Callable[[LLMResponseChunk], Awaitable[None]]
T = TypeVar("T")


@dataclass
class StreamLoopResult:
    text: str
    messages: list
    usage: Any
    finish_reason: str | None


class ToolOutputLike(Protocol):
    name: str
    result: object
    id: str
    error: object | None


# Shared retry config for all @llm.call decorators.
# Covers transient errors (rate limits, network blips, server errors).
# Jitter prevents thundering herd when multiple parallel subagents hit the same limit.
RETRY = llm.RetryConfig(
    max_retries=3,
    initial_delay=0.5,
    max_delay=60.0,
    backoff_multiplier=2.0,
    jitter=0.2,
)


async def agent_loop(
    call_fn: Any,
    ctx: "llm.Context[AgentDeps]",
    messages: list,
) -> str:
    """Run a non-streaming context-aware tool loop until the model stops calling tools"""
    response = await call_fn(ctx, messages)
    while response.tool_calls:
        tool_outputs = await response.execute_tools(ctx)
        await _handle_tool_outputs(tool_outputs, ctx)
        if ctx.deps.plan_state == PlanExecutionState.AWAITING_APPROVAL:
            break
        response = await response.resume(ctx, tool_outputs)
    return response.text("")


def _apply_healing(check: StuckLoopCheck, default_msg: str, deps: AgentDeps) -> str:
    if check.healing == HealingAction.INJECT_READ:
        return (
            f"{default_msg}\n"
            "HINT: You are repeatedly calling a write/edit tool without having read "
            "the target file first in this session. Call read_file on the target path "
            "to confirm its current content before attempting to write or edit."
        )
    if check.healing == HealingAction.COMPACT_CONTEXT:
        deps.compact_requested = "stuck_loop_healing"
        return (
            f"{default_msg}\n"
            "HINT: You are alternating between the same tools in a cycle. "
            "Step back and reconsider your approach from scratch."
        )
    return default_msg


async def _handle_tool_outputs(
    tool_outputs: Sequence[ToolOutputLike],
    ctx: "llm.Context[AgentDeps]",
    known_tool_names: list[str] | None = None,
) -> None:
    pending_by_name: dict[str, deque] = defaultdict(deque)
    for pc in ctx.deps.stuck_loop_tracker.pending_tool_calls:
        pending_by_name[pc.name].append(pc)
    ctx.deps.stuck_loop_tracker.pending_tool_calls = []
    for to in tool_outputs:
        if isinstance(to.error, ToolNotFoundError) and known_tool_names:
            matches = get_close_matches(to.name, known_tool_names, n=1, cutoff=0.9)
            if matches:
                to.result = (
                    f"Tool '{to.name}' not found. Did you mean: '{matches[0]}'?"
                    f" Use that exact name."
                )
            else:
                to.result = (
                    f"Tool '{to.name}' not found. Available tools:"
                    f" {', '.join(sorted(known_tool_names))}"
                )
        elif isinstance(to.error, ToolExecutionError):
            exec_err: ToolExecutionError = to.error
            inner = exec_err.tool_exception
            if isinstance(inner, PydanticValidationError):
                field_errors = "; ".join(
                    f"{'.'.join(str(loc) for loc in e['loc'])}: {e['msg']}"
                    for e in inner.errors()
                )
                to.result = (
                    f"Tool '{to.name}' rejected invalid arguments — {field_errors}."
                    " Fix these fields and retry."
                )
            elif isinstance(inner, TypeError):
                to.result = (
                    f"Tool '{to.name}' called with wrong arguments: {inner}."
                    " Check the tool signature and retry."
                )
            else:
                to.result = (
                    f"Tool '{to.name}' execution failed:"
                    f" {type(inner).__name__}: {inner}"
                )
        pending = (
            pending_by_name[to.name].popleft() if pending_by_name.get(to.name) else None
        )
        if pending is not None:
            block_key = f"{to.name}:{pending.args_hash}"
            if block_key in ctx.deps.stuck_loop_tracker.blocked_hashes:
                ctx.deps.stuck_loop_tracker.blocked_hashes.discard(block_key)
                blocked_msg = (
                    f"BLOCKED: {to.name} was called with identical arguments "
                    f"{ctx.deps.stuck_loop_warn_threshold} times. "
                    f"Stop repeating this call and try a completely different approach."
                )
                to.result = blocked_msg
                if ctx.deps.on_tool_result:
                    await ctx.deps.on_tool_result(to.name, blocked_msg, to.id, True)
                continue
        typed_result = to.result
        if isinstance(typed_result, ReadFileResult) and typed_result.meta.ok:
            ctx.deps.stuck_loop_tracker.read_file_paths.add(typed_result.path)
        if isinstance(typed_result, WriteBlockedResult):
            ctx.deps._blocked_calls.append(typed_result)
            ctx.deps.plan_state = PlanExecutionState.AWAITING_APPROVAL
        prepared = prepare_tool_output(to.name, to.result, ctx.deps)
        failed = tool_result_failed(to.result)
        loop_check = ctx.deps.stuck_loop_tracker.check(
            tool_name=to.name,
            args_hash=pending.args_hash if pending is not None else "",
            result_text=prepared.model_text,
            warn_threshold=ctx.deps.stuck_loop_warn_threshold,
            abort_threshold=ctx.deps.stuck_loop_abort_threshold,
        )
        model_result = prepared.model_result
        ui_text = prepared.ui_text
        skip_tool_result_ui = False
        if loop_check.action == "warn":
            ui_text = f"WARNING: {loop_check.message}"
            model_result = _apply_healing(loop_check, ui_text, ctx.deps)
            if ctx.deps.on_stuck_loop:
                await ctx.deps.on_stuck_loop(loop_check.message, "warn")
            skip_tool_result_ui = True
        elif loop_check.action == "hard_block":
            ui_text = f"BLOCKED: {loop_check.message}"
            model_result = _apply_healing(loop_check, ui_text, ctx.deps)
            if ctx.deps.on_stuck_loop:
                await ctx.deps.on_stuck_loop(loop_check.message, "error")
            skip_tool_result_ui = True
        elif loop_check.action == "abort":
            if ctx.deps.on_stuck_loop:
                await ctx.deps.on_stuck_loop(loop_check.message, "error")
            if (
                loop_check.healing == HealingAction.RESET_PLAN
                and ctx.deps.reset_plan_count < 1
            ):
                ctx.deps.reset_plan_requested = True
                ctx.deps.reset_plan_count += 1
                model_result = (
                    f"RESET: {loop_check.message} "
                    "Your current approach is not working. "
                    "This turn will restart in research phase."
                )
                ui_text = model_result
                skip_tool_result_ui = True
            else:
                raise StuckLoopError(loop_check.message)
        if isinstance(prepared.model_result, str):
            to.result = model_result
        final_model_text = (
            model_result if isinstance(model_result, str) else prepared.model_text
        )
        ctx.deps.current_usage_tokens += estimate_tokens(final_model_text)
        if ctx.deps.on_typed_tool_result:
            await ctx.deps.on_typed_tool_result(to.name, typed_result)
        if ctx.deps.on_tool_result and not skip_tool_result_ui:
            await ctx.deps.on_tool_result(
                to.name,
                ui_text,
                to.id,
                to.error is not None or failed,
            )


async def _consume_streams(stream: Any) -> AsyncGenerator[LLMResponseChunk, None]:
    """Yield normalized LLMResponseChunk from all Mirascope content streams."""
    async for s in stream.streams():
        ct = getattr(s, "content_type", None)
        async for delta in s:
            if not delta:
                continue
            if ct == "text":
                yield LLMResponseChunk(
                    content=delta,
                    tool_call_delta=None,
                    usage_delta=None,
                    finish_reason=None,
                )
            elif ct == "thought":
                yield LLMResponseChunk(
                    content=None,
                    tool_call_delta=None,
                    usage_delta=None,
                    finish_reason=None,
                    thought_delta=delta,
                )


_CHECKPOINT_MSG = """\
[CHECKPOINT]
Pause and briefly update your plan before continuing:
- What have you confirmed so far?
- What still needs to be done?
- What is your immediate next step?

Then proceed with your task.\
"""


async def stream_loop(
    call_fn: Any,
    ctx: "llm.Context[AgentDeps]",
    history: list,
    on_chunk: OnChunk,
    agent_label: str = "Orchestrator",
    checkpoint_interval: int = 0,
) -> StreamLoopResult:
    """Run a streaming context-aware tool loop.

    Streams normalized LLMResponseChunk to on_chunk; routes thought deltas to
    deps.on_thought. Returns StreamLoopResult with final text, messages, usage,
    and finish_reason.
    """
    stream = await call_fn.stream(ctx, history)
    tool_cycles = 0

    while True:
        async for chunk in _consume_streams(stream):
            if chunk.content is not None:
                await on_chunk(chunk)
            if chunk.thought_delta is not None and ctx.deps.on_thought:
                await ctx.deps.on_thought(chunk.thought_delta, agent_label)

        if stream.tool_calls:
            known = list(
                getattr(getattr(stream, "toolkit", None), "tools_dict", {}).keys()
            )
            tool_outputs = await stream.execute_tools(ctx)
            await _handle_tool_outputs(
                tool_outputs, ctx, known_tool_names=known or None
            )
            if ctx.deps.plan_state == PlanExecutionState.AWAITING_APPROVAL:
                break
            if ctx.deps.reset_plan_requested:
                break
            tool_cycles += 1
            if checkpoint_interval > 0 and tool_cycles % checkpoint_interval == 0:
                checkpoint_history = list(stream.messages) + [
                    llm.messages.user([*tool_outputs, _CHECKPOINT_MSG])
                ]
                stream = await call_fn.stream(ctx, checkpoint_history)
            else:
                stream = await stream.resume(ctx, tool_outputs)
        else:
            break

    finish_reason = stream.finish_reason
    return StreamLoopResult(
        text=stream.text(""),
        messages=stream.messages,
        usage=stream.usage,
        finish_reason=finish_reason.value if finish_reason else None,
    )


_COMPACT_SYSTEM = """\
Summarize the conversation into a compact, task-preserving context block.

If a <previous-summary> block is present at the start, treat it as the anchored prior summary.
Update it by preserving still-true facts, removing stale details, and merging new facts from the
turns that follow. Do not re-derive what is already captured in the prior summary.

If no <previous-summary> block is present, create a fresh summary from the full conversation.

Preserve:
- the user's current goal
- active constraints and decisions
- exact file paths, function names, identifiers, and error messages
- recent tool results that matter for the next step
- current progress, blockers, and unresolved questions

Drop:
- repetition
- dead ends
- low-value tool chatter
- pleasantries

Keep the summary short, factual, and deterministic. Do not invent facts.\
"""


def create_compactor(settings: "Settings") -> Callable[..., Any]:
    """Create a compaction function using the active provider/model."""
    from kiss.providers.manager import configure_provider
    from kiss.providers.normalization import mirascope_wrap

    model_id, call_params = configure_provider(settings)

    @llm.call(model_id, call_params=call_params)
    async def _call(ctx: llm.Context[AgentDeps], messages: list) -> list:
        return [
            llm.messages.system(_COMPACT_SYSTEM),
            *messages,
            llm.messages.user("Summarize the conversation above."),
        ]

    _wrapped_call = mirascope_wrap(_call)

    async def run(
        history: list,
        deps: AgentDeps,
        *,
        prior_summary: str | None = None,
    ) -> str:
        ctx = llm.Context(deps=deps)
        messages: list = []
        if prior_summary:
            messages.append(
                llm.messages.user(
                    f"<previous-summary>\n{prior_summary}\n</previous-summary>"
                )
            )
        messages.extend(history)
        result = await _wrapped_call(ctx, messages)
        return result.content or ""

    return run
