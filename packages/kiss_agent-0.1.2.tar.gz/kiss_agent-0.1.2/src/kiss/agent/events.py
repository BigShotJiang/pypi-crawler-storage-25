"""Typed event dataclasses with local diagnostic emission."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

from kiss.core.tracing import get_current_tracer


def _now() -> str:
    return datetime.now(tz=timezone.utc).isoformat()


def _emit(kind: str, **data: object) -> None:
    tracer = get_current_tracer()
    if tracer is not None:
        tracer.event(kind, **data)


@dataclass
class PipelineStarted:
    task_hash: str
    route: list[str]
    timestamp: str = field(default_factory=_now)

    def emit(self) -> None:
        _emit(
            "pipeline_started",
            task_hash=self.task_hash,
            route=self.route,
            timestamp=self.timestamp,
        )


@dataclass
class PipelineDone:
    task_hash: str
    route: list[str]
    result_count: int
    timestamp: str = field(default_factory=_now)

    def emit(self) -> None:
        _emit(
            "pipeline_done",
            task_hash=self.task_hash,
            route=self.route,
            result_count=self.result_count,
            timestamp=self.timestamp,
        )


@dataclass
class WorkerSpawned:
    role: str
    timestamp: str = field(default_factory=_now)

    def emit(self) -> None:
        _emit("worker_spawned", role=self.role, timestamp=self.timestamp)


@dataclass
class WorkerDone:
    role: str
    result_size: int
    timestamp: str = field(default_factory=_now)

    def emit(self) -> None:
        _emit(
            "worker_done",
            role=self.role,
            result_size=self.result_size,
            timestamp=self.timestamp,
        )


@dataclass
class WorkerFailed:
    role: str
    error: str
    attempt: int
    timestamp: str = field(default_factory=_now)

    def emit(self) -> None:
        _emit(
            "worker_failed",
            role=self.role,
            error=self.error,
            attempt=self.attempt,
            timestamp=self.timestamp,
        )


@dataclass
class WorkerRetryExhausted:
    role: str
    attempts: int
    error: str
    timestamp: str = field(default_factory=_now)

    def emit(self) -> None:
        _emit(
            "worker_retry_exhausted",
            role=self.role,
            attempts=self.attempts,
            error=self.error,
            timestamp=self.timestamp,
        )


@dataclass
class ContextFiltered:
    role: str
    original_len: int
    filtered_len: int
    timestamp: str = field(default_factory=_now)

    def emit(self) -> None:
        _emit(
            "context_filtered",
            role=self.role,
            original_len=self.original_len,
            filtered_len=self.filtered_len,
            timestamp=self.timestamp,
        )


@dataclass
class TemplateResolved:
    role: str
    source: str
    path: str
    timestamp: str = field(default_factory=_now)

    def emit(self) -> None:
        _emit(
            "template_resolved",
            role=self.role,
            source=self.source,
            path=self.path,
            timestamp=self.timestamp,
        )


@dataclass
class RetryAttempted:
    role: str
    attempt: int
    error: str
    timestamp: str = field(default_factory=_now)

    def emit(self) -> None:
        _emit(
            "retry_attempted",
            role=self.role,
            attempt=self.attempt,
            error=self.error,
            timestamp=self.timestamp,
        )
