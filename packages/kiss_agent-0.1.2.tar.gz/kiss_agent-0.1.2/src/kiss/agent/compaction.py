"""History mutation and context compaction pipeline."""

from __future__ import annotations

import asyncio
import uuid as _uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from mirascope import llm

from kiss.agent.tools.truncation import estimate_tokens, tool_result_failed
from kiss.core.diagnostics import get_logger
from kiss.core.events import Event, EventKind
from kiss.core.session_manager import SessionManager

_LOGGER = get_logger(__name__)


# ── Token helpers ─────────────────────────────────────────────────────────────


def message_text(m: Any) -> str:
    content = getattr(m, "content", [])
    parts = [content] if not isinstance(content, list) else content
    text: list[str] = []
    for part in parts:
        if hasattr(part, "text"):
            text.append(part.text)
        elif hasattr(part, "args"):
            text.append(part.args)
        elif hasattr(part, "result"):
            text.append(str(part.result))
    return "\n".join(text) or str(m)


def message_tokens(m: Any) -> int:
    return estimate_tokens(message_text(m))


def estimate_history_tokens(messages: list[Any]) -> int:
    return sum(message_tokens(m) for m in messages)


# ── Sliding window ────────────────────────────────────────────────────────────

_BUDGET_RATIO = 0.6
_STUB_USER = (
    "[Context: prior conversation history was truncated due to context window limits."
    " The task continues — resume based on the most recent exchange above.]"
)
_STUB_ASSISTANT = "Acknowledged. Continuing the task from this point."


def _find_turn_pairs(history: list[Any]) -> list[tuple[int, int]]:
    """Find consecutive (user_idx, assistant_idx) index pairs in history."""
    pairs: list[tuple[int, int]] = []
    i = 0
    while i < len(history) - 1:
        if (
            getattr(history[i], "role", None) == "user"
            and getattr(history[i + 1], "role", None) == "assistant"
        ):
            pairs.append((i, i + 1))
            i += 2
        else:
            i += 1
    return pairs


def sliding_window_fallback(
    history: list[Any],
    budget_tokens: int,
    pinned_turns: int = 1,
) -> list[Any]:
    """Trim oldest non-pinned turn pairs until history fits within budget_tokens."""
    if not history or estimate_history_tokens(history) <= budget_tokens:
        return list(history)

    pairs = _find_turn_pairs(history)
    if not pairs:
        return list(history)

    effective_pinned = min(pinned_turns, max(0, len(pairs) - 1))
    if effective_pinned != pinned_turns:
        _LOGGER.warning(
            "pinned_prefix_turns clamped",
            requested=pinned_turns,
            effective=effective_pinned,
            pair_count=len(pairs),
        )

    all_pair_idx = {idx for p in pairs for idx in p}
    pinned_idx = {idx for p in pairs[:effective_pinned] for idx in p}
    kept = list(pairs[effective_pinned:])  # oldest non-pinned first

    def _ordered(include_idx: set[int]) -> list[Any]:
        """Build candidate preserving original message order.

        Includes: pinned pair messages, messages in include_idx, and orphans
        (messages not belonging to any pair). Excludes trimmed pair messages.
        """
        return [
            msg
            for i, msg in enumerate(history)
            if i not in all_pair_idx or i in include_idx
        ]

    # O(n²) worst-case: each iteration rebuilds candidate (O(k)) and re-estimates
    # all token counts (O(k)). Bounded by _COMPACT_TURN_LIMIT (20 pairs) →
    # ~400 token estimations max, ~10ms. Acceptable until turn limits grow.
    while kept:
        include_idx = pinned_idx | {idx for p in kept for idx in p}
        candidate = _ordered(include_idx)
        if estimate_history_tokens(candidate) <= budget_tokens:
            return candidate
        if len(kept) == 1:
            _LOGGER.warning("compaction last-resort stub applied")
            stub_idx = set(kept[0])
            result: list[Any] = []
            stub_placed = False
            for i, msg in enumerate(history):
                if i in stub_idx:
                    if not stub_placed:
                        result.append(llm.messages.user(_STUB_USER))
                        result.append(
                            llm.messages.assistant(
                                _STUB_ASSISTANT, model_id=None, provider_id=None
                            )
                        )
                        stub_placed = True
                elif i not in all_pair_idx or i in pinned_idx:
                    result.append(msg)
            return result
        kept.pop(0)

    return _ordered(pinned_idx)


# ── History transforms ────────────────────────────────────────────────────────


def prune_error_outputs(messages: list[Any]) -> int:
    """Replace errored ToolOutput parts with a 1-line record in-place. Returns count pruned."""
    pruned = 0
    for msg in messages:
        if getattr(msg, "role", None) != "user":
            continue
        content = getattr(msg, "content", None)
        if not isinstance(content, list):
            continue
        for part in content:
            if getattr(part, "type", None) != "tool_output":
                continue
            err = getattr(part, "error", None)
            result = getattr(part, "result", None)
            if err is not None:
                label = f"{type(err).__name__}: {str(err)[:120]}"
            elif tool_result_failed(result):
                label = str(result)[:120]
            else:
                continue
            setattr(part, "result", f"[ERROR: {label}]")
            setattr(part, "error", None)
            pruned += 1
    return pruned


def dedup_tool_calls(
    messages: list[Any], window: int = 20
) -> tuple[int, list[tuple[Any, str]]]:
    """Collapse identical (name+args+result) tool calls within last `window` calls. Returns (count, rollback_pairs)."""
    records: list[tuple[int, int, tuple, str]] = []
    for i, msg in enumerate(messages):
        if getattr(msg, "role", None) != "assistant":
            continue
        content = getattr(msg, "content", None)
        if not isinstance(content, list):
            continue
        next_user = next(
            (
                j
                for j in range(i + 1, len(messages))
                if getattr(messages[j], "role", None) == "user"
            ),
            None,
        )
        if next_user is None:
            continue
        next_content = getattr(messages[next_user], "content", None)
        if not isinstance(next_content, list):
            continue
        for call_part in content:
            if getattr(call_part, "type", None) != "tool_call":
                continue
            call_id = getattr(call_part, "id", None)
            call_name = getattr(call_part, "name", "")
            call_args = getattr(call_part, "args", "")
            for oc_idx, out_part in enumerate(next_content):
                if getattr(out_part, "type", None) != "tool_output":
                    continue
                if getattr(out_part, "id", None) != call_id:
                    continue
                key = (call_name, call_args, str(getattr(out_part, "result", "")))
                records.append((next_user, oc_idx, key, call_name))
                break

    seen: dict[tuple, int] = {}
    deduped = 0
    rollback: list[tuple[Any, str]] = []
    for msg_idx, content_idx, key, name in records[-window:]:
        count = seen.get(key, 0)
        if count > 0:
            out = messages[msg_idx].content[content_idx]
            rollback.append((out, str(getattr(out, "result", ""))))
            setattr(
                out,
                "result",
                f"[DEDUP: identical {name!r} call, occurrence {count + 1}]",
            )
            deduped += 1
        seen[key] = count + 1

    return deduped, rollback


# ── CompactionResult ──────────────────────────────────────────────────────────


@dataclass
class CompactionResult:
    history: list[Any]
    uuid: str
    ts: str
    deduped: int
    exported: bool


# ── Prior summary extraction ─────────────────────────────────────────────────

_SUMMARY_MARKER = "[Context summary]\n"


def _extract_prior_summary(history: list[Any]) -> tuple[str | None, list[Any]]:
    """Return (prior_summary_text, new_turns_only).

    Detects a prior compaction summary as the first message pair and strips it,
    returning only turns added since the last compaction. Returns (None, history)
    when no prior summary is detected.
    """
    if len(history) >= 2:
        first_text = message_text(history[0])
        first_role = getattr(history[0], "role", None)
        second_role = getattr(history[1], "role", None)
        if (
            first_role == "user"
            and second_role == "assistant"
            and first_text.startswith(_SUMMARY_MARKER)
        ):
            return first_text.removeprefix(_SUMMARY_MARKER), list(history[2:])
    return None, list(history)


# ── CompactionManager ─────────────────────────────────────────────────────────

_COMPACT_TOKEN_RATIO = 0.80
_COMPACT_TURN_LIMIT = 20


class CompactionManager:
    def __init__(
        self, compactor_fn: Any, session_manager: SessionManager, settings: Any
    ) -> None:
        self._compactor = compactor_fn
        self._session_manager = session_manager
        self._settings = settings

    def should_compact(
        self,
        history: list[Any],
        window: int,
        turns_since_compact: int,
    ) -> tuple[bool, str]:
        """Return (should_compact, reason). Reason is empty string when False."""
        token_est = estimate_history_tokens(history)
        if token_est > window * _COMPACT_TOKEN_RATIO:
            return True, "80% context"
        if turns_since_compact >= _COMPACT_TURN_LIMIT:
            return True, "20 turns"
        return False, ""

    async def run(
        self,
        history: list[Any],
        reason: str,
        event_queue: asyncio.Queue[Event | None],
        deps: Any,
    ) -> CompactionResult:
        """Dedup → LLM summarize → build new history → export snapshot. Emits events."""
        compact_uuid = str(_uuid.uuid4())
        ts = datetime.now(UTC).isoformat()
        await event_queue.put(
            Event(kind=EventKind.COMPACTING, info=f"Compacting context ({reason})…")
        )

        strategy = self._settings.compaction_strategy
        budget = int(deps.context_window * _BUDGET_RATIO)
        deduped = 0

        if strategy == "sliding_window":
            new_history = sliding_window_fallback(
                history, budget, self._settings.pinned_prefix_turns
            )
        else:
            # dedup_tool_calls mutates history objects in-place; _rollback restores them on failure.
            # _extract_prior_summary slices the same objects — rollback covers all of history.
            deduped, _rollback = dedup_tool_calls(history)
            prior_summary, new_turns = _extract_prior_summary(history)
            try:
                summary = await self._compactor(
                    new_turns, deps, prior_summary=prior_summary
                )
                new_history = [
                    llm.messages.user(f"[Context summary]\n{summary}"),
                    llm.messages.assistant(
                        "Understood, continuing from this context.",
                        model_id=None,
                        provider_id=None,
                    ),
                ]
            except Exception:
                for obj, old_result in _rollback:
                    setattr(obj, "result", old_result)
                deduped = 0  # rollback undid dedup — count no longer valid
                if strategy == "summarize_then_slide":
                    new_history = sliding_window_fallback(
                        history, budget, self._settings.pinned_prefix_turns
                    )
                    await event_queue.put(
                        Event(
                            kind=EventKind.COMPACTION_FALLBACK,
                            info="⚠ LLM summarization failed — sliding window fallback applied",
                        )
                    )
                else:
                    raise
        serialized = [
            {"role": getattr(m, "role", "unknown"), "content": message_text(m)}
            for m in new_history
        ]
        # Serialize todos as dicts for snapshot
        todos_data = [
            {
                "text": todo.text,
                "done": todo.done,
                "id": todo.id,
                "status": todo.status,
                "owner": todo.owner,
                "block_reason": todo.block_reason,
                "blocked_by": todo.blocked_by,
            }
            for todo in deps.todos
        ]
        team_messages_data = [
            {
                "sender": msg.sender,
                "recipient": msg.recipient,
                "text": msg.text,
                "timestamp": msg.timestamp.isoformat(),
            }
            for msg in deps.team_messages
        ]
        exported = self._session_manager.export_snapshot(
            serialized,
            compact_uuid,
            ts,
            todos=todos_data,
            team_messages=team_messages_data,
            last_tool=deps.last_tool_name,
            phase=deps.turn_phase,
        )
        if not exported:
            await event_queue.put(
                Event(
                    kind=EventKind.INFO,
                    info="⚠ Session export failed — disk write error",
                )
            )
        await event_queue.put(
            Event(
                kind=EventKind.COMPACTED,
                info="✓ Context compacted",
                compaction_meta={
                    "uuid": compact_uuid,
                    "ts": ts,
                    "deduped": str(deduped),
                },
            )
        )
        return CompactionResult(
            history=new_history,
            uuid=compact_uuid,
            ts=ts,
            deduped=deduped,
            exported=exported,
        )
