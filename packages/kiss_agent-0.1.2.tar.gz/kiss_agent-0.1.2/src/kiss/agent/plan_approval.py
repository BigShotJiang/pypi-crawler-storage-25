"""Plan approval flow for KissAgent."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any, Protocol

from mirascope import llm

from kiss.agent.plan_types import CompletionResult, PlanExecutionState, PlanResult
from kiss.agent.turn_engine import TurnEngine, format_plan
from kiss.core.deps import AgentDeps
from kiss.core.events import QuestionOption
from kiss.core.types import AskUserRequest
from kiss.providers.normalization import LLMResponseChunk


_DANGEROUS_TOOLS = frozenset(
    {"run_bash", "run_python", "git_commit", "git_stage", "apply_patch"}
)


class _ApprovalOwner(Protocol):
    _allow_destructive: bool
    _headless_mode: bool
    session_plan_approvals: set[str]
    session_tool_approvals: set[str]
    history: list[Any]
    _current_turn_engine: TurnEngine | Any | None


class PlanApprovalManager:
    """Owns plan approval policy and replay behavior."""

    def __init__(
        self,
        *,
        owner: _ApprovalOwner,
        headless_approval_error: type[Exception],
    ) -> None:
        self._owner = owner
        self._headless_approval_error = headless_approval_error

    async def resolve(
        self,
        result: PlanResult,
        deps: AgentDeps,
        on_chunk: Callable[[LLMResponseChunk], Awaitable[None]],
    ) -> CompletionResult | PlanResult:
        plan_text = format_plan(result.plan)

        if self._owner._allow_destructive:
            return await self._rerun_after_decision(
                deps,
                on_chunk,
                "User approved. Proceed with execution.",
                writes_approved=True,
            )

        if self._owner._headless_mode:
            raise self._headless_approval_error(
                f"{plan_text}\n\nApproval required in non-interactive mode."
            )

        if result.plan.plan_hash in self._owner.session_plan_approvals:
            reply = await self._ask_user(
                deps,
                AskUserRequest(
                    question=(
                        f"{plan_text}\n\nYou approved this exact plan before.\n"
                        "Select whether to proceed."
                    ),
                    type="yesno",
                ),
            )
            if reply.outcome == "selected" and reply.selected_choice_ids == ["yes"]:
                return await self._rerun_after_decision(
                    deps,
                    on_chunk,
                    "User approved. Proceed with execution.",
                    writes_approved=True,
                )
            return await self._rerun_after_decision(
                deps,
                on_chunk,
                "User rejected. Propose an alternative.",
                writes_approved=False,
            )

        # Defensive: PlanResult should always have blocked_calls (AWAITING_APPROVAL
        # is only set alongside an append to _blocked_calls), but guard anyway so
        # an empty list never reaches the full approval UX.
        if not result.blocked_calls:
            return await self._rerun_after_decision(
                deps,
                on_chunk,
                "User approved. Proceed with execution.",
                writes_approved=True,
            )

        all_tools_preapproved = all(
            blocked_call.tool_name in self._owner.session_tool_approvals
            for blocked_call in result.blocked_calls
        )
        all_tools_safe = all(
            blocked_call.tool_name not in _DANGEROUS_TOOLS
            for blocked_call in result.blocked_calls
        )
        if all_tools_preapproved and all_tools_safe:
            reply = await self._ask_user(
                deps,
                AskUserRequest(
                    question=(
                        f"{plan_text}\n\nYou approved all required tools for this session.\n"
                        "Select whether to proceed."
                    ),
                    type="yesno",
                ),
            )
            if reply.outcome == "selected" and reply.selected_choice_ids == ["yes"]:
                return await self._rerun_after_decision(
                    deps,
                    on_chunk,
                    "User approved. Proceed with execution.",
                    writes_approved=True,
                )
            return await self._rerun_after_decision(
                deps,
                on_chunk,
                "User rejected. Propose an alternative.",
                writes_approved=False,
            )

        reply = await self._ask_user(
            deps,
            AskUserRequest(
                question=f"{plan_text}\n\nSelect how to proceed.",
                type="choice",
                options=[
                    QuestionOption(id="approve_once", label="Approve (one-time)"),
                    QuestionOption(
                        id="approve_plan_session",
                        label="Approve for session (exact same plan)",
                    ),
                    QuestionOption(
                        id="approve_tool_session",
                        label="Approve for session (any plan using this tool)",
                    ),
                    QuestionOption(id="deny", label="Deny"),
                ],
                default_id="approve_once",
            ),
        )
        if reply.outcome != "selected":
            return await self._rerun_after_decision(
                deps,
                on_chunk,
                "User rejected. Propose an alternative.",
                writes_approved=False,
            )

        choice = reply.selected_choice_ids[0] if reply.selected_choice_ids else ""
        if choice == "approve_plan_session":
            self._owner.session_plan_approvals.add(result.plan.plan_hash)
            return await self._rerun_after_decision(
                deps,
                on_chunk,
                "User approved. Proceed with execution.",
                writes_approved=True,
            )
        if choice == "approve_tool_session":
            for blocked_call in result.blocked_calls:
                if blocked_call.tool_name not in _DANGEROUS_TOOLS:
                    self._owner.session_tool_approvals.add(blocked_call.tool_name)
            return await self._rerun_after_decision(
                deps,
                on_chunk,
                "User approved. Proceed with execution.",
                writes_approved=True,
            )
        if choice == "approve_once":
            return await self._rerun_after_decision(
                deps,
                on_chunk,
                "User approved. Proceed with execution.",
                writes_approved=True,
            )
        return await self._rerun_after_decision(
            deps,
            on_chunk,
            "User rejected. Propose an alternative.",
            writes_approved=False,
        )

    async def _ask_user(self, deps: AgentDeps, request: AskUserRequest) -> Any:
        if deps.on_ask_user is None:
            raise RuntimeError("Ask-user callback is not configured.")
        return await deps.on_ask_user(request)

    async def _rerun_after_decision(
        self,
        deps: AgentDeps,
        on_chunk: Callable[[LLMResponseChunk], Awaitable[None]],
        message: str,
        *,
        writes_approved: bool,
    ) -> CompletionResult | PlanResult:
        if self._owner._current_turn_engine is None:
            raise RuntimeError("TurnEngine not initialized for approval replay.")

        original_history = self._owner.history
        try:
            deps.writes_approved = writes_approved
            self._owner.history = [
                *original_history,
                llm.messages.assistant(message, model_id=None, provider_id=None),
            ]
            return await self._owner._current_turn_engine.run(
                deps=deps,
                history=self._owner.history,
                on_chunk=on_chunk,
                agent_label="kiss-agent",
            )
        except Exception:
            self._owner.history = original_history
            raise
        finally:
            deps.writes_approved = False
            deps.plan_state = PlanExecutionState.IDLE
            deps._blocked_calls.clear()
