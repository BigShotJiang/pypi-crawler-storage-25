"""Agent core — model orchestration, history management, streaming events"""

from __future__ import annotations

import asyncio
import contextlib
import msgspec
import sys
from collections.abc import AsyncGenerator
from pathlib import Path
from typing import Any

from mirascope import llm

from kiss.agent.compaction import (
    CompactionManager,
    estimate_history_tokens,
)
from kiss.agent.turn_lifecycle_state import TurnLifecycleState
from kiss.agent.phases import PhaseManager
from kiss.agent.turn_engine import TurnEngine
from kiss.agent.turn_orchestrator import TurnOrchestrator
from kiss.agent.tool_scoping import ToolSetName
from kiss.core.permission_policy import (
    permission_policy_load,
    _permission_policy_load_sync,
)
from kiss.agent.plan_approval import PlanApprovalManager
from kiss.agent.plan_types import (
    TurnPhase,
)
from kiss.agent.turn_event_callbacks import TurnEventCallbacks
from kiss.agent.runner import create_compactor
from kiss.core.diagnostics import configure_diagnostics
from kiss.core.types import (
    Event,
    EventKind,
    PermissionReply,
)
from kiss.core.deps import AgentDeps
from kiss.core.diagnostics import get_logger
from kiss.core.session_manager import SessionManager
from kiss.core.settings import Settings, get_context_window
from kiss.core.tracing import SessionTracer
from kiss.core.usage import TeamMessage, TodoItem

# ── Helpers ───────────────────────────────────────────────────────────────────

_llm_instrumented = False
_llm_instrument_lock = __import__("threading").Lock()


def _wire_llm_instrumentation(tracer: SessionTracer) -> None:
    global _llm_instrumented
    try:
        from mirascope import ops as mirascope_ops
    except ImportError:
        return  # mirascope instrumentation not available — expected on some installs

    try:
        tracer_provider = getattr(tracer, "tracer_provider", None)
        if tracer_provider is None:
            get_logger().warning(
                "tracer.tracer_provider is None; LLM instrumentation skipped"
            )
            return
        with _llm_instrument_lock:
            if not _llm_instrumented:
                mirascope_ops.configure(tracer_provider=tracer_provider)
                mirascope_ops.instrument_llm()
                _llm_instrumented = True
    except Exception as exc:
        get_logger().warning("Failed to wire LLM instrumentation: %s", exc)


_API_KEY_OPTIONAL_PROVIDER_TYPES = {"copilot", "openai-codex", "codex", "openai"}
_PHASE_CONSTRAINTS: dict[TurnPhase, str] = {
    TurnPhase.RESEARCH: "No file writes, no git commits, no shell execution.",
    TurnPhase.PLANNING: "No git commits. Write tools available for drafting.",
    TurnPhase.EXECUTION: "All tools available.",
}


def _status_code(error: BaseException) -> int | None:
    value = getattr(error, "status_code", None)
    if isinstance(value, int):
        return value
    response = getattr(error, "response", None)
    value = getattr(response, "status_code", None)
    if isinstance(value, int):
        return value
    return None


def _tool_capability_hint_error(
    error: BaseException,
    *,
    model_label: str,
    side_effect_seen: bool,
) -> RuntimeError | None:
    if _status_code(error) != 400 or side_effect_seen:
        return None
    message = str(error).strip()
    lowered = message.lower()
    hint_markers = (
        "tool",
        "function",
        "schema",
        "tool_choice",
        "not supported",
        "unsupported",
    )
    generic_400 = not lowered or lowered == "error code: 400"
    if not generic_400 and not any(marker in lowered for marker in hint_markers):
        return None
    return RuntimeError(
        "Provider rejected this request (HTTP 400) before any tool action ran. "
        f"The current model '{model_label}' likely does not support the tool-calling "
        "payload required for file operations. Switch to a tool-capable model/provider "
        f"and retry. Original error: {message or type(error).__name__}."
    )


class HeadlessApprovalRequiredError(RuntimeError):
    pass


class KissAgent:
    """Pure agent core: LLM orchestration, history, streaming events.

    All UI concerns live in ui.base.UIBackend implementations; this class only
    produces Event objects that backends consume
    """

    def __init__(
        self,
        settings: Settings,
        compactor: Any,
        workspace_root: Path | None = None,
        sessions_dir: Path | None = None,
        permission_policy: Any | None = None,
        planner_factory: Any | None = None,
        turn_engine_factory: Any | None = None,
    ) -> None:
        configure_diagnostics()
        self.settings = settings
        if planner_factory is not None and turn_engine_factory is not None:
            raise ValueError(
                "Provide only one of planner_factory or turn_engine_factory."
            )
        self._turn_engine_factory = turn_engine_factory or planner_factory or TurnEngine
        self.workspace_root = (workspace_root or Path.cwd()).resolve()
        self.permission_policy = (
            permission_policy
            if permission_policy is not None
            else _permission_policy_load_sync(self.workspace_root)
        )
        self.tracer = SessionTracer()
        _wire_llm_instrumentation(self.tracer)
        self.session_manager = SessionManager(
            sessions_dir or Path.home() / ".kiss" / "sessions"
        )
        self.compaction_manager = CompactionManager(
            compactor, self.session_manager, settings
        )
        self.history: list[Any] = []

        self._turns_since_compact: int = 0
        self._model_cache: dict[str, list[str]] = {}
        self._current_task: asyncio.Task[None] | None = None
        self._health_probe_task: asyncio.Task[None] | None = None
        self._allowed_tools: set[str] = set()
        self._allowed_cmds: set[tuple[str, str]] = set()
        self._allowed_exact: set[str] = set()
        self._allowed_scopes: set[str] = set()
        self.todos: list[Any] = []
        self.team_messages: list[Any] = []
        self._current_turn_engine: TurnEngine | Any | None = None
        self._current_turn_engine_key: tuple[Any, ...] | None = None
        self._current_tool_set: ToolSetName = "full"
        self._turn_phase: TurnPhase = TurnPhase.RESEARCH
        self._gate_writes: bool = True
        self._lifecycle_state = TurnLifecycleState(owner=self)
        self._phase_manager = PhaseManager()
        self._plan_approval = PlanApprovalManager(
            owner=self,
            headless_approval_error=HeadlessApprovalRequiredError,
        )
        self._turn_orchestrator = TurnOrchestrator(
            owner=self,
            capability_hint_error=_tool_capability_hint_error,
        )
        self.session_plan_approvals: set[str] = set()
        self.session_tool_approvals: set[str] = set()
        self._allow_destructive: bool = False
        self._headless_mode: bool = False
        self._pending_recovery_notice: str | None = None
        self._last_tool_name: str = ""

    @property
    def _consecutive_reads_since_mutation(self) -> int:
        return self._lifecycle_state.consecutive_reads_since_mutation

    @_consecutive_reads_since_mutation.setter
    def _consecutive_reads_since_mutation(self, value: int) -> None:
        self._lifecycle_state.consecutive_reads_since_mutation = value

    @property
    def _post_file_nudge_pending(self) -> bool:
        return self._lifecycle_state.post_file_nudge_pending

    @_post_file_nudge_pending.setter
    def _post_file_nudge_pending(self, value: bool) -> None:
        self._lifecycle_state.post_file_nudge_pending = value

    @classmethod
    async def create(cls, settings: Settings) -> "KissAgent":
        from kiss.core.settings import discover_workspace_root

        if (
            settings.model
            and settings.effective_provider_type not in _API_KEY_OPTIONAL_PROVIDER_TYPES
        ):
            from kiss.providers.auth import provider_is_ready

            if not provider_is_ready(settings.effective_provider_type):
                raise ValueError(
                    f"No credentials for provider '{settings.provider_alias}'. "
                    f"Set the relevant environment variable or run /connect {settings.provider_alias}."
                )
        cwd = Path.cwd().resolve()
        workspace_root = discover_workspace_root(cwd)
        compactor = create_compactor(settings)
        permission_policy = await permission_policy_load(workspace_root)
        agent = cls(
            settings,
            compactor,
            workspace_root=workspace_root,
            permission_policy=permission_policy,
        )
        agent._start_health_probes()
        return agent

    # ── Public interface ───────────────────────────────────────────────────

    @property
    def model_label(self) -> str:
        return self.settings.model

    def clear_history(self) -> None:
        self.history = []
        self.todos = []
        self.team_messages = []
        self._turns_since_compact = 0
        self._current_turn_engine = None
        self._current_turn_engine_key = None
        self._current_tool_set = "full"
        self._turn_phase = TurnPhase.RESEARCH
        self._gate_writes = True
        self._lifecycle_state.reset()
        self._phase_manager.reset()
        self._allowed_tools.clear()
        self._allowed_cmds.clear()
        self._allowed_exact.clear()
        self._allowed_scopes.clear()

    def cancel(self) -> None:
        if self._current_task and not self._current_task.done():
            self._current_task.cancel()

    # ── Model switching ────────────────────────────────────────────────────

    def switch_model(self, model_string: str) -> None:
        """Switch to a different model; history is preserved"""
        if ":" not in model_string:
            raise ValueError(f"Model must be 'provider:model-id', got {model_string!r}")
        provider_alias = model_string.split(":", 1)[0]
        new_settings = msgspec.structs.replace(self.settings, model=model_string)
        if new_settings.effective_provider_type not in _API_KEY_OPTIONAL_PROVIDER_TYPES:
            from kiss.providers.auth import provider_is_ready

            if not provider_is_ready(new_settings.effective_provider_type):
                raise ValueError(
                    f"No credentials for provider '{provider_alias}'. "
                    f"Set the relevant environment variable or run /connect {provider_alias}."
                )
        self.settings = new_settings
        self.compaction_manager = CompactionManager(
            create_compactor(new_settings), self.session_manager, new_settings
        )
        self._current_turn_engine = None
        self._current_turn_engine_key = None
        self._current_tool_set = "full"
        self._turn_phase = TurnPhase.RESEARCH
        self._gate_writes = True
        self._lifecycle_state.reset()
        self._phase_manager.reset()
        self._allowed_tools.clear()
        self._allowed_cmds.clear()
        self._allowed_exact.clear()
        self._allowed_scopes.clear()

    def refresh_turn_engine(self, phase: TurnPhase) -> None:
        self._turn_phase = phase
        additions = list(
            self._lifecycle_state.consume_system_prompt_additions(
                phase_constraints=_PHASE_CONSTRAINTS
            )
        )

        # Inject skills into system prompt
        try:
            from kiss.core.runtime import AgentContext

            ctx = AgentContext.get()
            skill_block = ctx.skill_loader.load(ctx.session_id or "")
            if skill_block:
                additions.append(skill_block)
        except (RuntimeError, ImportError):
            pass  # AgentContext not yet initialised

        key = (
            self.settings.model_id,
            self.workspace_root,
            self._current_tool_set,
            phase,
            self._gate_writes,
            tuple(additions),
        )
        if (
            self._current_turn_engine is not None
            and self._current_turn_engine_key == key
        ):
            return
        self._current_turn_engine = self._turn_engine_factory(
            model_id=self.settings.model_id,
            workspace_root=self.workspace_root,
            settings=self.settings,
            tool_set=self._current_tool_set,
            phase=phase,
            gate_writes=self._gate_writes,
            system_prompt_additions=additions,
        )
        self._current_turn_engine_key = key

    def shutdown(self) -> None:
        self._lifecycle_state.shutdown(
            tracer=self.tracer,
            session_dir=self.session_manager.sessions_dir,
        )

    async def close(self) -> None:
        """Cancel the health probe task and release async resources."""
        if self._health_probe_task is not None and not self._health_probe_task.done():
            self._health_probe_task.cancel()
            try:
                await self._health_probe_task
            except asyncio.CancelledError:
                pass
            self._health_probe_task = None

    def _start_health_probes(self) -> None:
        """Schedule background health probes. Safe to call before an event loop exists."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        self._health_probe_task = loop.create_task(self._health_probe_loop())

    async def _health_probe_loop(self) -> None:
        """Probe all registered providers on a jittered 5-minute interval."""
        import random

        from kiss.providers.health import (
            all_providers_unhealthy,
            get_provider_health,
        )
        from kiss.providers.manager import probe_provider_models
        from kiss.providers.registry import list_providers

        _BASE_INTERVAL = 300.0  # 5 minutes
        _JITTER = 0.20

        while True:
            jitter = random.uniform(-_JITTER, _JITTER) * _BASE_INTERVAL
            await asyncio.sleep(max(60.0, _BASE_INTERVAL + jitter))

            providers = list_providers()
            for profile in providers:
                health = get_provider_health(profile.name)
                async with health.get_lock():
                    try:
                        result = await asyncio.wait_for(
                            probe_provider_models(self.settings, profile.name),
                            timeout=10.0,
                        )
                        if result is not None:
                            health.record_success()
                        else:
                            health.record_failure("No models returned")
                    except asyncio.CancelledError:
                        raise
                    except asyncio.TimeoutError:
                        health.record_failure("Probe timed out")
                    except Exception as exc:
                        health.record_failure(str(exc))

            provider_names = [p.name for p in providers]
            if all_providers_unhealthy(provider_names):
                self._pending_recovery_notice = (
                    "DEGRADED: ALL PROVIDERS UNHEALTHY — check network and auth, "
                    "run `kiss doctor` for diagnostics."
                )

    async def fetch_models(self, provider_name: str) -> list[str]:
        """Return live models for a provider, using the in-session cache"""
        if provider_name not in self._model_cache:
            from kiss.providers.manager import fetch_provider_models

            self._model_cache[provider_name] = await fetch_provider_models(
                self.settings, provider_name
            )
        return self._model_cache[provider_name]

    # ── Session management ─────────────────────────────────────────────────

    def restore_session(self, uuid: str | None = None) -> str | None:
        """Load snapshot into history. Returns timestamp if restored, None if not found."""
        result = self.session_manager.restore_snapshot(uuid=uuid)
        if result is None:
            return None
        message_dicts, ts, todos_data, team_messages_data, last_tool, phase = result
        messages = []
        for m in message_dicts:
            role = m.get("role", "user")
            content = m.get("content", "")
            if role == "user":
                messages.append(llm.messages.user(content))
            elif role == "assistant":
                messages.append(
                    llm.messages.assistant(content, model_id=None, provider_id=None)
                )
        if not messages:
            return None
        self.history = messages

        # Restore todos with migration defaults for v1/v2 snapshots
        self.todos = []
        if todos_data:
            if not isinstance(todos_data, list):
                get_logger().warning(
                    "Malformed todos in snapshot: expected list, got %s",
                    type(todos_data).__name__,
                )
            else:
                seen_ids: set[str] = set()
                for item in todos_data:
                    if isinstance(item, dict) and "text" in item and "done" in item:
                        text_val = item["text"]
                        done_val = item["done"]
                        if isinstance(text_val, str) and isinstance(done_val, bool):
                            raw_id = item.get("id", "")
                            if (
                                not isinstance(raw_id, str)
                                or not raw_id
                                or raw_id in seen_ids
                            ):
                                raw_id = f"t-{len(self.todos) + 1:04d}"
                            seen_ids.add(raw_id)
                            raw_status = item.get(
                                "status", "done" if done_val else "pending"
                            )
                            self.todos.append(
                                TodoItem(
                                    text=text_val,
                                    done=done_val,
                                    id=raw_id,
                                    status=raw_status,
                                    owner=item.get("owner"),
                                    block_reason=item.get("block_reason"),
                                    blocked_by=[
                                        h
                                        for h in item.get("blocked_by", [])
                                        if isinstance(h, str)
                                    ],
                                )
                            )
                        else:
                            get_logger().warning(
                                "Skipping malformed todo item: %s", item
                            )
                    else:
                        get_logger().warning("Skipping malformed todo item: %s", item)

        # Restore team messages (v3+; empty for older snapshots)
        self.team_messages = []
        for msg in team_messages_data:
            if not isinstance(msg, dict):
                continue
            if not all(k in msg for k in ("sender", "recipient", "text", "timestamp")):
                get_logger().warning("Skipping malformed team message: %s", msg)
                continue
            try:
                from datetime import datetime

                ts_val = datetime.fromisoformat(msg["timestamp"])
                self.team_messages.append(
                    TeamMessage(
                        sender=msg["sender"],
                        recipient=msg["recipient"],
                        text=msg["text"],
                        timestamp=ts_val,
                    )
                )
            except (ValueError, TypeError):
                get_logger().warning("Skipping malformed team message: %s", msg)

        self._turns_since_compact = 0
        self._last_tool_name = last_tool
        self._turn_phase = phase
        self._gate_writes = True
        self._lifecycle_state.reset()
        self._phase_manager.reset()
        self._allowed_tools.clear()
        self._allowed_cmds.clear()
        self._allowed_exact.clear()
        self._allowed_scopes.clear()
        turn_count = len(self.history)
        self._pending_recovery_notice = (
            f"[RECOVERY NOTICE]\n"
            f"Timestamp: {ts}\n"
            f"Restored Turns: {turn_count}\n"
            f"Last Known Tool: {last_tool or 'N/A'}"
        )
        return ts

    async def compact(self, reason: str = "manual") -> AsyncGenerator[Event, None]:
        """Compact history immediately; yields COMPACTING and COMPACTED events."""
        event_queue: asyncio.Queue[Event | None] = asyncio.Queue(maxsize=16)
        window = get_context_window(
            self.settings.model_id,
            None,
        )
        deps = AgentDeps(
            context_window=window,
            current_usage_tokens=estimate_history_tokens(self.history),
            web_search_config=self.settings.web_search,
            permission_policy=self.permission_policy,
            tracer=self.tracer,
            session_dir=self.session_manager.sessions_dir,
            memory_enabled=self.settings.memory_enabled,
            turn_phase=self._turn_phase,
        )

        async def _run() -> None:
            try:
                await self._compact_history(reason, event_queue, deps)
            except Exception as exc:
                await event_queue.put(Event(kind=EventKind.ERROR, error=exc))
            finally:
                await event_queue.put(None)

        task = asyncio.create_task(_run())
        try:
            while True:
                event = await event_queue.get()
                if event is None:
                    break
                yield event
        finally:
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task

    async def _compact_history(
        self,
        reason: str,
        event_queue: asyncio.Queue[Event | None],
        deps: AgentDeps,
    ) -> None:
        result = await self.compaction_manager.run(
            self.history, reason, event_queue, deps
        )
        self.history = result.history
        self._turns_since_compact = 0

        # 7.8: fire-and-forget memory observer after compaction
        if self.settings.memory_enabled:
            try:
                from kiss.core.runtime import AgentContext
                from kiss.core.memory import MemoryObserver, run_memory_pipeline

                ctx = AgentContext.get()
                if ctx.session_id and not ctx.observer_in_flight:
                    _db = ctx.db
                    _settings = self.settings
                    _session_id = ctx.session_id
                    _observer = MemoryObserver(
                        _db,
                        observation_threshold_tokens=_settings.observation_threshold_tokens,
                        timeout_seconds=_settings.observer_timeout_seconds,
                    )

                    async def _memory_task() -> None:
                        await run_memory_pipeline(
                            _session_id,
                            _db,
                            _observer,
                            reflector=None,
                            pruner=None,
                            reflection_threshold_tokens=_settings.reflection_threshold_tokens,
                        )

                    ctx.launch_background_task("observer", _memory_task())
            except Exception:
                pass  # observer failure must never crash compaction

    # ── Streaming turn ─────────────────────────────────────────────────────

    async def send(self, message: str) -> AsyncGenerator[Event, None]:
        """Run one agent turn, yielding Event objects.

        Emits: TOKEN* → (TOOL_CALL → PERMISSION? → TOOL_RESULT)* →
        (COMPACTING → COMPACTED)? → DONE | CANCELLED | ERROR
        """
        event_queue: asyncio.Queue[Event | None] = asyncio.Queue(maxsize=64)
        bridge = TurnEventCallbacks(owner=self, event_queue=event_queue)

        # Emit degraded notice before the turn so both backends handle it uniformly.
        if self._pending_recovery_notice:
            yield Event(kind=EventKind.DEGRADED, info=self._pending_recovery_notice)
            self._pending_recovery_notice = None

        # ── Producer task ──────────────────────────────────────────────────

        self.session_manager.append_turn("user", message)

        async def _run_agent_turn() -> None:
            await self._turn_orchestrator.run(
                message=message,
                event_queue=event_queue,
                bridge=bridge,
            )

        task = asyncio.create_task(_run_agent_turn())
        self._current_task = task

        try:
            while True:
                event = await event_queue.get()
                if event is None:
                    break
                yield event
        finally:
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task

    # ── Headless mode ──────────────────────────────────────────────────────

    def run_headless(self, prompt: str, allow_destructive: bool = False) -> None:
        """Run a single turn, printing the final response to stdout.

        Without allow_destructive, destructive tool calls and outside-CWD reads are
        denied — the agent runs in plan-only mode and describes what it would do.
        Pass allow_destructive=True (--allow-destructive-tools) to execute tools.
        """

        async def _run() -> None:
            self._allow_destructive = allow_destructive
            self._headless_mode = True
            full: list[str] = []
            try:
                async for event in self.send(prompt):
                    if event.kind == EventKind.TOKEN:
                        full.append(event.token)
                    elif event.kind == EventKind.TOOL_CALL:
                        if event.call is None:
                            raise RuntimeError("TOOL_CALL event missing call field")
                        print(f"🛠️  {event.call.name}…", file=sys.stderr)
                    elif event.kind == EventKind.PERMISSION:
                        if event.permission is None:
                            raise RuntimeError(
                                "PERMISSION event missing permission field"
                            )
                        reply = (
                            PermissionReply.ALLOW
                            if allow_destructive
                            else PermissionReply.DENY
                        )
                        event.permission.reply_future.set_result(reply)
                    elif event.kind == EventKind.ERROR:
                        if isinstance(event.error, HeadlessApprovalRequiredError):
                            print(str(event.error), file=sys.stderr)
                        else:
                            print(f"Error: {event.error}", file=sys.stderr)
                        sys.exit(1)
                    elif event.kind == EventKind.STUCK_LOOP:
                        print(event.info, file=sys.stderr)
                    elif event.kind == EventKind.CANCELLED:
                        print("Cancelled.", file=sys.stderr)
                    elif event.kind == EventKind.ASK_USER:
                        if event.ask_user is not None:
                            print(event.ask_user.question, file=sys.stderr)
                            print(
                                "Approval required in non-interactive mode.",
                                file=sys.stderr,
                            )
                            sys.exit(1)
                    elif event.kind == EventKind.LOGIC_APPROVAL:
                        if event.logic_approval is None:
                            raise RuntimeError(
                                "LOGIC_APPROVAL event missing logic_approval field"
                            )
                        if allow_destructive:
                            from kiss.agent.tools.logic.approval import (
                                LogicApprovalReply,
                            )

                            event.logic_approval.reply_future.set_result(
                                LogicApprovalReply(approved=True)
                            )
                        else:
                            print(str(event.logic_approval), file=sys.stderr)
                            print(
                                "Approval required in non-interactive mode.",
                                file=sys.stderr,
                            )
                            sys.exit(1)
                    elif event.kind == EventKind.COMPACTING:
                        print(event.info, file=sys.stderr)
                    elif event.kind == EventKind.COMPACTED:
                        print(event.info, file=sys.stderr)
            finally:
                self._allow_destructive = False
                self._headless_mode = False
            print("".join(full))

        asyncio.run(_run())
