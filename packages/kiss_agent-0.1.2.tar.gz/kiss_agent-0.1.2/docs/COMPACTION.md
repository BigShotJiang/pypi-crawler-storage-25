# Context Compaction

This page covers compaction triggers, history transforms, session export, and slash commands.

## Pipeline overview

After each turn updates history, `KissAgent` checks whether compaction is needed:

```
dedup_tool_calls(history)
  → LLM summarize (compactor fn)
  → replace history with [summary_user, ack_assistant]
  → export snapshot to ~/.kiss/sessions/export_{uuid}.json
  → emit COMPACTING + COMPACTED events
```

All stages run inside `CompactionManager.run()` in `src/kiss/agent/compaction.py`.

## Triggers

| Trigger | Condition | Reason string |
|---------|-----------|---------------|
| Token budget | `estimate_history_tokens(history) > window × 0.80` | `"80% context"` |
| Turn limit | `turns_since_compact >= 20` | `"20 turns"` |
| Manual `/compact` | user types `/compact` in UI | `"manual"` |
| Self-compaction tool | `self_compact(reason)` sets `deps.compact_requested` | `"self-compaction requested (...)"` |
| Overflow retry | provider rejects oversized context before side effects | `"self-healing retry after context overflow (...)"` |

`TurnEngine` can request compaction via `deps.compact_requested`, and `KissAgent` handles the trigger at the next safe boundary.

## History transforms

### `prune_error_outputs(messages)`

This walks user messages, finds `tool_output` parts where `error is not None` or `tool_result_failed(result)` is true, and replaces them with:

```
result = "[ERROR: ExceptionType: first 120 chars of message]"
error  = None
```

It runs after every turn, ensuring error noise gets cut out immediately.

### `dedup_tool_calls(messages, window=20)`

This scans the last `window` tool call and output pairs. If the same `(name, args, result)` triple appears twice, subsequent duplicates become:

```
result = "[DEDUP: identical 'tool_name' call, occurrence N]"
```

It runs only during compaction.

## CompactionManager

`src/kiss/agent/compaction.py`

`KissAgent` owns one instance as `self.compaction_manager`. `_compact_history` is the orchestrator:

```python
async def _compact_history(self, reason, event_queue, deps) -> None:
    result = await self.compaction_manager.run(self.history, reason, event_queue, deps)
    self.history = result.history
    self._turns_since_compact = 0
```

## Session export / restore

Managed by `SessionManager` in `src/kiss/core/session_manager.py`.

### Export

After every compaction, the new two-message history is serialized to:

```
~/.kiss/sessions/export_{uuid}.json
```

### Restore

`KissAgent.restore_session()` loads the latest snapshot, reconstructs mirascope messages into `self.history`, and enables seamless resume.
