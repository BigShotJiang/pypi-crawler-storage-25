# Observability

kiss-agent uses two local observability channels:

- `SessionTracer` for OpenTelemetry spans and span events
- `structlog` for structured diagnostics outside the traced execution tree

Both stay in-process. No external telemetry service is required.

## SessionTracer

`SessionTracer` lives in `src/kiss/core/tracing.py`.

### API

- `span(name, **attributes)` opens a nested OTel span.
- `event(kind, **data)` attaches an event to the current active span.
- `get_live_snapshot()` returns `(active_spans, finished_spans)` for UI polling.
- `export_jsonl(filepath)` writes `traces.jsonl` in the session directory.

### Context management

Use the context helpers when code needs the current tracer without changing signatures:

- `set_current_tracer_context(tracer)`
- `reset_tracer_context(token)`
- `get_current_tracer()`

These helpers are available for event emitters and tool implementations that need the active tracer without threading it through every call signature.

## Trace export

Each session exports a `traces.jsonl` file under the session directory, alongside the turn log.

The JSONL export includes:

- span names
- trace and span IDs
- parent span IDs
- start/end timestamps
- duration in milliseconds
- serializable attributes
- span events
- a session header record followed by one span record per line

Example shape:

```jsonl
{"record_type":"session","version":1,"service_name":"kiss-agent"}
{"record_type":"span","name":"orchestrator.pipeline","trace_id":"...","span_id":"...","parent_span_id":null,"events":[]}
```

## structlog diagnostics

`src/kiss/core/diagnostics.py` configures `structlog` for JSON output on stderr.

It injects OTel correlation fields when a span is active:

- `trace_id`
- `span_id`
- `trace_flags`

Use `get_logger(__name__)` for local diagnostics that should stay searchable but do not belong in the trace tree.

## LLM instrumentation

kiss-agent uses `mirascope[ops]` to wire OpenTelemetry spans for every LLM call automatically. When a `tracer_provider` is available at startup, `mirascope.ops.configure()` and `mirascope.ops.instrument_llm()` are called once. This adds provider-level spans (Anthropic, OpenAI, Gemini) to the same trace tree as the session spans, so you can correlate model latency and token usage with agent activity.

No extra configuration is needed. The instrumentation runs in-process and exports to the same `traces.jsonl` session file.

## Adding observability to new code

- Use `ctx.deps.tracer.span(...)` around worker and tool execution.
- Use `get_current_tracer().event(...)` for trace-local events.
- Use `get_logger(__name__)` for startup, config, and auth diagnostics.
- Keep observability local. Do not add external telemetry backends.
