# Agent Loop & Orchestration

`KissAgent` is the central state manager. It drives the turn-engine loop and exposes an event stream to the UI layer.

## The `send()` lifecycle

`KissAgent.send(message)` is an `AsyncGenerator[Event]`:

1. It wires runtime callbacks into `AgentDeps` via `TurnEventCallbacks`:
   - `on_tool_use` fires when a tool call starts
   - `on_tool_result` fires when a tool returns
   - `confirm_permission` handles tool-call approval flow
   - `on_ask_user` handles tagged ASK_USER replies
   - `on_chunk` fires for text and thought stream chunks
   - supporting callbacks cover stuck-loop warnings and UI event emission
2. It starts an `asyncio.Task` that delegates turn orchestration to `TurnOrchestrator.run(...)`.
3. That producer pushes `Event` objects into an `asyncio.Queue(maxsize=64)`.
4. The generator reads from the queue and yields events to the UI.

## Streaming pipeline

Text and thought tokens flow through `_consume_streams` in `runner.py`.

- Text tokens: `content_type == "text"` -> `on_chunk(delta)` -> `TOKEN` event
- Thought tokens: `content_type == "thought"` -> `on_thought(delta, agent_label)` -> `THINKING` event

## Provider System

`configure_provider(settings)` converts a `Settings` object into a mirascope `(model_string, call_params)` pair and registers the provider.

### GitHub Copilot Auth

Copilot uses device-code OAuth. Tokens expire in about 29 minutes. `_CopilotAuth` refreshes automatically and uses a lock to avoid a thundering herd.

### Model Switching

`KissAgent.switch_model` replaces `settings`, the current `TurnEngine`, and `compaction_manager` while keeping `history`.
