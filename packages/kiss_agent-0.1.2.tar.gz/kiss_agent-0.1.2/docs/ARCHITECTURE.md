# Architecture

kiss-agent is a single-process AI coding assistant. The runtime is event-driven, and two terminal frontends share the same agent core. Rich and Textual differ mainly in how they present the same event stream.

## Layers

```
CLI
 └─ UIBackend (Rich or Textual TUI)
      └─ KissAgent          ← central state and event bus
           └─ TurnEngine    ← top-level unified LLM, executes one turn via tool calls
                └─ Registry ← Tool discovery and gating
```

`KissAgent` manages conversation state, the event queue, and phase-aware context management. The `TurnEngine` is the single decision-making engine that replaced an earlier worker pipeline. The `Registry` handles tool availability and security gating.

## Agent loop & orchestration

`KissAgent.send(message)` returns an `AsyncGenerator[Event]`. Inside:

1. It wires runtime callbacks into an `AgentDeps` struct — tool activity, permissions, ask-user prompts, token/thought streaming, and UI state updates.
2. It launches a producer task that delegates phase resolution, retries, and completion bookkeeping to `TurnOrchestrator`.
3. That producer pushes `Event` objects into an `asyncio.Queue(maxsize=64)`; the generator pops and yields them.
4. The UI consumes the generator and renders each event.

`TurnEngine` is a mirascope-backed runtime that owns one reasoning turn at a time. `PhaseManager` steers the session through `RESEARCH`, `PLANNING`, and `EXECUTION`, while tool scoping narrows the available registry subset per turn.

```mermaid
sequenceDiagram
    participant UI
    participant KissAgent
    participant TurnEngine

    UI->>KissAgent: send(message)
    KissAgent->>TurnEngine: start turn (RESEARCH phase)
    TurnEngine->>TurnEngine: Analyze intent, scope tools
    TurnEngine-->>KissAgent: Request approval (if write)
    KissAgent->>UI: Request Approval
    UI->>KissAgent: User Approval
    KissAgent->>TurnEngine: Re-run (EXECUTION phase)
    TurnEngine-->>KissAgent: final response
    KissAgent-->>UI: events (streamed)
```

The UI stays decoupled from the agent core through that async event stream. As the `TurnEngine` produces tokens or thoughts, it pushes events onto the stream for the UI to consume.

## Deep Dives

### Permission flow

All writes are gated via the `write_gated` decorator in the tool registry.

```mermaid
flowchart TD
    TurnEngine -->|write tool call| gate_decorator
    gate_decorator -->|check approval| PermissionEvent
    PermissionEvent --> UI
    UI -->|user reply| reply_future
    reply_future -->|ALLOW| TurnEngineRuns
    reply_future -->|DENY| PlanOnly["returns plan-only message"]
```

`PermissionRequest` embeds an `asyncio.Future`. The agent loop awaits it, and the UI sets the result. Session-wide approvals live in `self.session_tool_approvals` for tool-level approval.

### File tools

- All writes are atomic: `tempfile.mkstemp` -> write -> `os.replace`. This is safe on POSIX.
- Per-path `asyncio.Lock` prevents concurrent write corruption.
- `edit_file` requires an exact `old_text` match. There is no fuzzy patching.
- Reads are capped at 100 KB with a truncation notice.

### Shell tool

- Uses `asyncio.create_subprocess_exec`, so there is no `shell=True` injection path.
- Three timeout presets: `short` (30 s), `normal` (120 s), `long` (300 s).

## Provider system

The provider system has three layers: a static profile registry, an auth strategy registry, and a runtime credential store.

### ProviderProfile registry

`ProviderProfile` is a frozen dataclass that describes a provider's capabilities: base URL, auth type, env vars, model context windows, known free models, and optional model-fetching function. Bundled profiles live in `src/kiss/providers/profiles/`. User-defined profiles can be dropped in `~/.kiss/agent/profiles/` as Python files.

The registry (`src/kiss/providers/registry.py`) is lazily discovered on first use. It loads bundled profiles, then user-global profiles (user-global takes precedence on name collision). After discovery, a finalization pass validates schemas, checks for fallback DAG cycles, and logs missing env vars.

### AuthStrategy registry

`AuthStrategy` is a protocol with three methods:

- `resolve(profile, settings)` — returns a credential string from env vars and keyring, or None
- `register(profile, credentials)` — wires the provider into mirascope's call routing
- `run(app, on_event)` — runs an interactive auth flow (OAuth browser/device-code, API-key prompt), surfacing progress via the `on_event` callback

Strategies registered by default:

| auth_type | Strategy | Flow |
|-----------|----------|------|
| `api_key` | `ApiKeyStrategy` | Reads env var or keyring; `run()` returns None (caller prompts) |
| `copilot` | `CopilotStrategy` | GitHub device-code OAuth |
| `oauth_external` | `CodexStrategy` | Browser PKCE flow |
| `none` | `NoAuthStrategy` | No credentials required |

`configure_provider(settings)` looks up the active provider's profile, calls `strategy.resolve()` to get credentials, and calls `strategy.register()` to wire mirascope routing.

```mermaid
flowchart LR
    Settings -->|provider_alias + model_id| configure_provider
    configure_provider -->|resolve creds| AuthStrategy
    AuthStrategy -->|env / keyring| credential
    configure_provider -->|register| mirascope_scope
```

### Credential storage

Credentials live in two places, never in `settings.json`:

1. **Environment variables** — checked first by `AuthStrategy.resolve()`.
2. **System keyring** — written by `/connect` via `keyring_store.set_credential("provider:<name>", value)`. Falls back to `~/.kiss/agent/credentials.json` (mode 0o600) when the OS keyring is unavailable.

Connection metadata (`baseUrl`, `type`) is stored in `~/.kiss/agent/providers.jsonc`. That file contains no secrets and is written by `/connect` after a successful auth flow.

### Health probes and fallback

Background health probes run periodically against registered providers. `ProviderHealth` tracks consecutive failures and transitions providers through `unknown → healthy → degraded → unhealthy`. The `all_providers_unhealthy()` check is used by the degraded-recovery logic to switch to last-known-good models.

Fallback chains (`ProviderProfile.fallback_models`) allow left-to-right model substitution up to two levels deep when the primary model fails.

### Model switch

`KissAgent.switch_model` replaces `settings`, the current `TurnEngine`, and `compaction_manager` while keeping conversation history.

## UI backends

Both backends implement a single-method ABC:

```python
class UIBackend(ABC):
    async def run(self, agent: KissAgent, settings: Settings) -> None: ...
```

| Backend | Class | Description |
|---------|-------|-------------|
| `rich` | `RichStatusBarBackend` | Scrolling Rich output + 1-line status bar. Default. |
| `textual` | `TextualBackend` → `KissApp` | Full-screen Textual TUI with chat, observability tabs, sidebar, and inline interaction surfaces. |

Both backends use the same slash-command metadata, session state model, and grouped tool-activity store.

## Settings & config resolution

### Settings file lookup

kiss-agent uses the first existing file:
1. `.kiss/settings.json` for project-local settings
2. `~/.kiss/agent/settings.json` for user-global settings

### System prompt inputs

kiss-agent composes the runtime prompt from:

1. bundled `turn_engine_system.md`
2. bundled `turn_engine_examples.md`
3. per-turn additions such as `phase_reminder.md` and `post_file_nudge.md`

### Context window resolution

`get_context_window(model_id, override)` tries in order:
1. Manual override in `ProviderConfig.contextWindow`
2. Hardcoded `DEFAULT_CONTEXT_WINDOWS` table
3. Fallback: 128 000 tokens

## Context governance & compaction

Compaction is integrated into the turn lifecycle.

**Governance:**
- Performed on every turn through prompt budgeting, compaction checks, and error-output pruning.
- Includes budgeting, duplicate reduction during compaction, and truncation-aware history maintenance.

**Compaction triggers:**
- `estimate_history_tokens(history) > context_window × 0.80`
- `turns_since_compact >= 20`
- Explicit `self_compact` tool call
- self-healing retry after detected context overflow

The `CompactionManager` pipeline is:
1. `dedup_tool_calls`
2. LLM summary call
3. Replacing history with `[user(summary), assistant("Understood")]`
4. Exporting a snapshot to `~/.kiss/sessions/export_{uuid}.json`

## Key files

| Path | Role |
|------|------|
| `src/kiss/cli/main.py` | Entry point, arg parsing, dispatch |
| `src/kiss/core/deps.py` | `AgentDeps`, the callback injection container |
| `src/kiss/agent/loop.py` | `KissAgent`, state management and event bus |
| `src/kiss/agent/turn_engine.py` | Unified `TurnEngine` runtime |
| `src/kiss/agent/turn_orchestrator.py` | Per-turn orchestration and retry/compaction flow |
| `src/kiss/agent/phases.py` | `PhaseManager` and transition coaching |
| `src/kiss/agent/runner.py` | `stream_loop`, tool output handling |
| `src/kiss/agent/tool_scoping.py` | Intent classification (search, edit, validate, full) |
| `src/kiss/agent/tools/registry.py` | Tool discovery, gating, and category mapping |
| `src/kiss/agent/compaction.py` | `CompactionManager` |
| `src/kiss/ui/commands.py` | Shared slash-command semantics |
