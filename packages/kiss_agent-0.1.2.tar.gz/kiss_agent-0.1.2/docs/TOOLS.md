# Tool System & Permissions

kiss-agent uses dynamic tool scoping, where the `TurnEngine` selects a subset of tools based on the detected user intent and current phase.

## Tool Scoping

The agent operates in four distinct tool scopes based on intent classification:

| Intent | Tool Scope |
| :--- | :--- |
| **Search** | Read/search tools plus git inspection, validation helpers, web fetch/search, and collaboration tools |
| **Edit** | Search scope + file write tools, shell execution, and git write tools |
| **Validate** | Search scope with validation helpers and inspection tools, but no write tools |
| **Full** | All available tools (including future MCP/A2A integrations) |

*Note: The `ask_user`, memory tools (`memory_read`, `memory_append`), todo tools, team-message tools, `expand_ref`, and `self_compact` are always-on and present in all scopes.*

## Permission Flow

All write operations are gated via the `write_gated` registry wrapper.

```mermaid
flowchart TD
    TurnEngine -->|write tool call| gate_decorator
    gate_decorator -->|check approval| PermissionEvent
    PermissionEvent --> UI
    UI -->|user reply| reply_future
    reply_future -->|ALLOW| TurnEngineRuns
    reply_future -->|DENY| PlanOnly["returns plan-only message"]
```

### Safety Features

- **Plan Mode**: The agent generates a plan for write operations, requiring explicit user approval before execution.
- **Permission Requests**: Use `asyncio.Future`. The agent loop awaits them, and the UI sets the result.
- **Session Approvals**: Cached in `self.session_tool_approvals` for tool-level approval within the session.
- **Atomic Writes**: `tempfile.mkstemp` -> write -> `os.replace` ensures atomic updates on POSIX.
- **Per-path Locks**: `asyncio.Lock` prevents concurrent write corruption.
- **Shell Execution**: Uses `asyncio.create_subprocess_exec` without `shell=True` to prevent shell injection.
- **Read Caps**: File reads are capped at 100 KB with a truncation notice.
