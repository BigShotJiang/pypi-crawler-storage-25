# Turn Engine Architecture

kiss-agent has moved from a multi-agent worker pipeline to a unified `TurnEngine` architecture. This design simplifies the agent loop, improves latency, and provides more coherent reasoning across complex tasks.

## TurnEngine overview

The `TurnEngine` is the single decision-making engine in the agent loop. Unlike the legacy pipeline, it does not delegate to specialized worker agents. Instead, it uses dynamic tool scoping to select tools based on the current user intent and handles its own planning, tool execution, and approval logic.

## The TurnEngine lifecycle

The `TurnEngine` operates in distinct phases managed by `TurnPhase` and monitored via `AgentDeps`:

1. **RESEARCH**: The agent explores the codebase to understand the task.
2. **PLANNING**: The agent formulates a sequence of tool calls and proposed changes.
3. **EXECUTION**: The agent carries out the approved tool calls.

Transitions between these phases are resolved by `PhaseManager`, which can use explicit slash commands or ask-user coaching before moving the session forward or backward.

## Tool Scoping

To reduce token bloat and prevent model confusion, `TurnEngine` uses an intent classification system (`src/kiss/agent/tool_scoping.py`) to narrow the set of tools available to the LLM per turn:

| Intent | Tool Scope |
| :--- | :--- |
| **Search** | Code exploration and read-only analysis tools. |
| **Edit** | All search tools + file manipulation, shell, and git tools. |
| **Validate** | All search tools + linting and validation tools. |
| **Full** | All tools available in the registry. |

Always-on tools (like `ask_user`, memory, todos) are available in all scopes.

## Permission flow & Approvals

All write-capable tools are gated via the `write_gated` decorator in the registry.

```mermaid
flowchart TD
    TurnEngine -->|write tool call| gate_decorator
    gate_decorator -->|check approval| PermissionEvent
    PermissionEvent --> UI
    UI -->|user reply| reply_future
    reply_future -->|ALLOW| TurnEngineRuns
    reply_future -->|DENY| PlanOnly["returns plan-only message"]
```

`PermissionRequest` embeds an `asyncio.Future`. The agent loop awaits it, and the UI sets the result. Approvals for specific tool combinations can be cached per session, reducing interaction friction for repetitive operations.

## Key files

| Path | Role |
|------|------|
| `src/kiss/agent/turn_engine.py` | Unified `TurnEngine` logic and prompt/tool wiring. |
| `src/kiss/agent/phases.py` | `PhaseManager` transition logic and coaching prompts. |
| `src/kiss/agent/tool_scoping.py` | Intent classification logic. |
| `src/kiss/agent/tools/registry.py` | Tool discovery, categorization, and write gating. |
| `src/kiss/agent/plan_types.py` | Data structures for `Plan`, `WriteBlockedResult`, and `TurnPhase`. |

## Observability

See [docs/OBSERVABILITY.md](OBSERVABILITY.md) for the full tracing and diagnostics guide.
