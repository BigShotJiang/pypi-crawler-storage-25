# Configuration Reference

kiss-agent uses JSON settings files plus a small set of CLI flags.

## Settings File

kiss-agent checks these settings files in order and uses the first one it finds:
1. `.kiss/settings.json` or `.kiss/settings.jsonc` — project-local settings
2. `~/.kiss/agent/settings.json` or `~/.kiss/agent/settings.jsonc` — user-global settings

Both formats support JSONC (`//` and `/* */` comments). See `settings.jsonc.example` for a fully annotated reference.

### Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `model` | `string` | *(required)* | `"provider:model-id"` |
| `providers` | `object` | `{}` | Per-provider behavior overrides (no secrets — see below) |
| `freeProviders` | `object` | `{}` | Map of provider name → bool; enables free-tier models in `/model` |
| `systemPrompt` | `string` | `""` | Reserved explicit system-prompt field; not currently consumed by `TurnEngine` |
| `thinkingLevel` | `string\|null` | `null` | Extended thinking level (`none` to `max`) |
| `coderThinking` | `bool` | `false` | Whether the worker sub-agent also gets a thinking budget |
| `showThinking` | `bool` | `true` | Render thought blocks in the UI |
| `webSearch` | `object` | defaults | Web search provider, timeout, and result count |
| `compactionStrategy` | `string` | `"summarize_then_slide"` | Compaction policy |
| `pinnedPrefixTurns` | `int` | `1` | Number of pinned turns kept during compaction |
| `stuckLoopWarnThreshold` | `int` | `3` | Warn before repeated tool-call loops |
| `stuckLoopAbortThreshold` | `int` | `5` | Abort threshold for repeated loops |
| `memoryEnabled` | `bool` | `true` | Enable memory read/append tools |
| `workers` | `object` | defaults | Sub-agent dispatch: `defaultEffort`, `effortProfiles` |

### `providers` — override-only, no secrets

The `providers` section is for behavior overrides only. It does not accept API keys, base URLs, or provider type overrides. Those have moved:

- **Credentials** → system keyring or environment variables (managed by `/connect`)
- **Connection metadata** (`baseUrl`, `type`) → `~/.kiss/agent/providers.jsonc` (written by `/connect`)

Accepted fields per provider entry:

| Field | Type | Description |
|-------|------|-------------|
| `models` | `list[string]` | Static model allowlist; limits the picker to these IDs |
| `contextWindow` | `int\|null` | Override context window size in tokens |
| `autodiscover` | `bool` | Fetch live model list from the provider on picker open |

Example — restricting Anthropic to one model:

```json
"providers": {
  "anthropic": {
    "models": ["claude-sonnet-4-6"],
    "contextWindow": 200000
  }
}
```

### `freeProviders` — free-tier model access

Enable free-tier model access per provider. When a provider is enabled, its declared free models appear in the `/model` picker alongside your authenticated provider's models, tagged `[free]`.

Toggle providers interactively with `/free` in the UI.

Known free tiers (declared in bundled profiles):

| Provider | Free models |
|----------|-------------|
| `openai` | `gpt-4o-mini` |
| `gemini` | `gemini-2.0-flash-lite`, `gemini-2.0-flash` |

```json
"freeProviders": {
  "openai": true,
  "gemini": true
}
```

## Credential Management

Credentials (API keys and OAuth tokens) are never stored in `settings.json`. They live in:

1. **Environment variables** — the simplest path. Each bundled provider declares the env vars it accepts (`ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `GOOGLE_API_KEY`, etc.).
2. **System keyring** — managed by `/connect` in the UI. Writes to the OS keychain (macOS Keychain, libsecret on Linux, or a fallback JSON file at `~/.kiss/agent/credentials.json` with mode 0o600).

To authenticate interactively, run `/connect` from within the UI. A picker lists all registered providers with their current auth status (`●` = connected). Select a provider to:
- Run the OAuth flow for Copilot and Codex providers
- Enter an API key (stored in keyring) for api_key providers

To remove credentials, run `/logout`. To see auth state for all providers, run `/auth-status`.

## Providers

kiss-agent includes bundled `ProviderProfile` entries for the following providers. They are auto-discovered — no manual `providers` entry is needed to use them.

| Provider | Auth type | Env var |
|----------|-----------|---------|
| `anthropic` | api_key | `ANTHROPIC_API_KEY` |
| `openai` | api_key | `OPENAI_API_KEY` |
| `gemini` | api_key | `GOOGLE_API_KEY` |
| `copilot` | copilot (OAuth device-code) | — |
| `openai-codex` | oauth_external (browser PKCE) | — |
| `openrouter` | api_key | `OPENROUTER_API_KEY` |
| `kilocode` | api_key | `KILOCODE_API_KEY` |
| `litellm` | api_key | — |
| `ollama-cloud` | api_key | — |
| `opencode-zen` | api_key | `OPENCODE_ZEN_API_KEY` |

User-defined profiles can be added as Python files in `~/.kiss/agent/profiles/`. They are loaded after bundled profiles and can override any bundled entry.

## Runtime Provider Records (`providers.jsonc`)

`~/.kiss/agent/providers.jsonc` stores connection metadata for providers that need non-default base URLs or type settings. It is created and updated automatically by `/connect`. Do not put secrets in this file.

Fields per entry: `displayName`, `baseUrl`, `type`, `models`, `autodiscover`, `env`, `signupUrl`, `enabled`.

## Slash Commands

| Command | Description |
|---------|-------------|
| `/model` | Interactive model picker. Shows free models when free providers are enabled. |
| `/models [provider]` | List available models for a provider |
| `/providers` | List configured providers with health status |
| `/connect` | Provider picker for interactive authentication |
| `/logout` | Remove stored credentials for a provider |
| `/auth-status` | Show per-provider auth state and credential source |
| `/free [provider]` | Toggle free-tier model access per provider |
| `/clear` | Clear conversation history |
| `/compact` | Compact context now |
| `/resume` | Restore last saved session |
| `/think` | Toggle thinking display |
| `/help` | Show all commands |

## CLI Flags

| Flag | Description |
|------|-------------|
| `--ui rich\|textual` | Choose UI backend (default: `rich`) |
| `--tui` | Alias for `--ui textual` |
| `--allow-destructive-tools` | Auto-approve all tool calls |
| `--resume UUID` | Resume a saved session snapshot |
| `prompt` | Positional argument that runs in headless mode |

## Context Window Resolution

The agent resolves the context window in this order:
1. Manual override via `ProviderConfig.contextWindow` in `settings.json`
2. Declared per-model entries in the bundled `ProviderProfile.context_windows`
3. Hardcoded `DEFAULT_CONTEXT_WINDOWS` table in `settings.py`
4. Fallback: 128,000 tokens
