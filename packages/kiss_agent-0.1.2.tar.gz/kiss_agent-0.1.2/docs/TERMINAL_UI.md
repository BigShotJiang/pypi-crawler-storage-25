# Terminal UI

kiss-agent ships two terminal backends:

- `RichStatusBarBackend` (`--ui rich`, default)
- `TextualBackend` (`--ui textual`)

They wrap the same runtime contract in different ways. Shared logic lives in `src/kiss/ui/` and covers command metadata, session state, grouped tool activity, prompt history, truncation handling, fuzzy command suggestions, and normalized tool-result rendering.

## Shared UI contract

Both backends consume the event stream from `KissAgent.send(...)`. That stream is the source of truth for:

- transcript updates
- runtime state transitions
- tool calls and tool results
- permission prompts
- ASK_USER prompts
- todo updates
- grouped activity detail replay

Parity is enforced at the logic layer first. Rich and Textual may render the same event differently, but they should not invent different semantics.

## Backend roles

### Rich

Rich is the scroll-first backend. It favors a normal terminal transcript with a compact status surface and prompt-toolkit interaction helpers. It is the lighter-weight option and is designed to feel natural in a standard terminal session.

### Textual

Textual is the structured backend. It keeps the same conversation semantics but gives them more persistent surfaces: chat, observability tabs, sidebar state, footer bindings, and inline widgets for permission and ASK_USER flows.

## Commands and command handling

Slash commands are defined once in `src/kiss/ui/slash.py` and then rendered in both backends. The important part is the split of responsibilities:

- shared metadata defines command names, usage, grouping, and backend availability
- shared command helpers in `src/kiss/ui/commands.py` implement the core semantics
- each backend is responsible only for presentation and interaction style

That keeps command drift low while still allowing Rich and Textual to feel different.

Unknown slash commands use the shared fuzzy suggestion logic. Help output is also generated from shared metadata, so backend help stays aligned without duplicating command definitions in documentation.

### Provider commands

The model group contains commands for managing providers, models, and credentials:

| Command | Description |
|---------|-------------|
| `/model` | Interactive model picker. Merges free-tier models when free providers are enabled. |
| `/models [provider]` | List available models for a specific provider |
| `/providers` | List configured providers with health and auth status |
| `/connect` | Open the provider picker to authenticate. Shows `●` next to connected providers. Dispatches to OAuth (Copilot, Codex) or API-key prompt (api_key providers). Writes credentials to the system keyring. |
| `/logout` | Open a picker of authenticated providers and remove the selected credential from keyring. |
| `/auth-status` | Show per-provider auth state, auth type, and credential source (env var, keyring, or none). |
| `/free [provider]` | Toggle free-tier model access for a provider. Without an argument, shows all providers that declare free models with their current toggle state. |

#### Provider picker

`/connect` and `/logout` open a modal picker (both backends) that lists all registered providers. Connected providers are marked with `●`. Selecting a provider and pressing Enter runs the appropriate auth flow:

- **OAuth providers** (`copilot`, `openai-codex`): Opens a browser or device-code flow and surfaces intermediate state (browser URL, device code) inline.
- **API key providers** (`anthropic`, `openai`, `gemini`, etc.): Prompts for the key inline (Rich) or via a text prompt (Textual). The key is written to the system keyring under `provider:<name>`.

The picker is the only entry point for interactive auth. There is no `/connect <provider>` positional form.

#### Free provider access

`/free` enables free-tier model access. When a provider is enabled, its declared free models appear in the `/model` picker alongside the authenticated provider's models, tagged `[free]`. The `/model` picker title reflects how many additional free models are available. Free models can be from providers the user has not authenticated with — they are publicly accessible by design.

Free model lists are declared statically in each bundled `ProviderProfile` and may become stale if a provider changes pricing. If a listed free model is actually paid, the provider's API will surface an error normally.

## Prompt history

Prompt history is workspace-scoped in both backends.

- the storage path is derived from the normalized workspace root
- both backends write to `~/.kiss/agent/history/<workspace-hash>.txt`
- unrelated worktrees do not share history

Rich uses `prompt_toolkit` history directly. Textual uses a small history-aware input widget that persists submitted prompts and supports previous and next navigation. The behavior is shared at the storage-contract level rather than by forcing both backends to use the same input library.

## Runtime state model

Both backends render the same canonical runtime states from `UISessionState`:

- idle
- streaming
- tool-running
- compacting
- blocked on permission
- blocked on ask-user
- warning
- error

State ownership is shared, while rendering stays backend-specific. Rich leans on inline transcript output and status-bar cues. Textual can also reflect state through border changes, banners, tabs, and sidebar updates.

## Tool activity and detail replay

Tool interaction rendering is also shared in logic:

- tool calls and results are normalized into shared display models
- grouped repeated activity is tracked in a shared activity buffer
- thought detail uses the `thought:<id>` namespace

Grouping, truncation hints, and file-operation summaries should mean the same thing regardless of which terminal backend is active.

## Thought traces and informational events

`THINKING`, `INFO`, and `STUCK_LOOP` events map to a single shared display model — `InformationalDisplay` in `src/kiss/ui/shared.py` — so both backends read the same severity, message, and optional sections instead of parsing raw event shapes themselves.

Thought streams (`THINKING`) carry a stable `thought_id`. When a backend sees a new `thought_id`, it starts a fresh thought line prefixed with `✦` and indented under the assistant lane. Each chunk is stored in `ObservabilityState.thoughts`, which keeps the observability views current even when the user is on another tab.

Rich streams these lines through a `Live` panel refreshed at 10 Hz. Textual batches chunks and flushes them every 100 ms. The stored text and boundary logic are identical; only the refresh mechanism differs.

## File operations, todos, and ASK_USER

Several UX areas that used to drift now follow the same semantics:

- file-affecting tool results use canonical operation summaries such as create, edit, patch, delete, and move
- todo updates are emitted as normalized summary and delta events rather than backend-local diffing
- ASK_USER uses a tagged reply model with one-active prompt gating and explicit cancellation behavior

Backends can still choose different widgets or transcript phrasing, but the decision rules and outcomes are shared.

## Observability surfaces

Observability is split between shared data ownership and backend-specific presentation.

- shared state owns grouped activity, logs, metrics, trace-related buffers, and per-thought-id thought buffers
- Rich keeps observability close to the transcript and thought-replay flow
- Textual exposes persistent observability surfaces, currently centered on chat, logs, and metrics views

The underlying state is the same; the display ergonomics are not.

## Visual system

The visual system is semantic rather than hardcoded per backend.

- token defaults live in `src/kiss/data/ui_tokens.py`
- Rich maps them through a theme
- Textual maps them through CSS variables

Documentation should stay at the level of intent: muted versus primary text, active versus default borders, blocked or error emphasis, lane identity, and readable transcript width. Do not document per-event colors or exact palette values here. Those details change more often than the logic does.

## Maintainership guidance

When updating terminal UI behavior:

- change shared logic first when semantics need to stay aligned
- change backend rendering second when only presentation should differ
- prefer documenting contracts and decision rules over exhaustive UI inventories
- keep this document focused on interaction models, ownership boundaries, and parity rules

For implementation details, read the code in:

- `src/kiss/ui/slash.py`
- `src/kiss/ui/commands.py`
- `src/kiss/ui/session_state.py`
- `src/kiss/ui/shared.py`
- `src/kiss/ui/activity.py`
- `src/kiss/ui/observability.py`
- `src/kiss/ui/rich/`
- `src/kiss/ui/textual/`
