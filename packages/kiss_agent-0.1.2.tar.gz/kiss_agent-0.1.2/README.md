# kiss-agent

![CI](https://github.com/goejja/kiss-agent/actions/workflows/ci.yml/badge.svg)
![Python](https://img.shields.io/badge/python-3.12%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)

A terminal-based stupid assistant.  
He might be stupid, but he now runs as a unified phase-aware coding agent with one turn engine and a shared event loop.

## Context

Experimental AI agent written in python for personal use and learning lessons.  

It started from personal chat to understand the basics.  
Then I tried to use [pydantic-ai](https://pydantic.dev/docs/ai/overview/) to avoid reinventing the wheel. It simplified lots of things.  
But I felt losing control and not learning how things work.  
So here we are, with this new experiment relying on [mirascope](https://mirascope.com/). The library provides the core toolkit for LLM calls. So I can focus on tooling and logic.

## Quick Start

### Installation

Requires Python 3.12+.

**With pip:**

```bash
pip install kiss-agent
```

**With uv:**

```bash
uv tool install kiss-agent
```

### Minimal Configuration

Create `.kiss/settings.json`:

```json
{
  "model": "anthropic:claude-sonnet-4-6"
}
```

Then set your API key as an environment variable:

```bash
export ANTHROPIC_API_KEY=sk-...
```

Or authenticate interactively from within the UI with `/connect` — it opens a provider picker showing all supported providers and their current auth status.

### Usage

```bash
kiss                               # Rich UI (default)
kiss --tui                         # Textual TUI
kiss "Explain this codebase"       # headless
```

## Documentation

- [**Architecture Overview**](https://github.com/goejja/kiss-agent/blob/main/docs/ARCHITECTURE.md): High-level technical design.
- [**Configuration Reference**](https://github.com/goejja/kiss-agent/blob/main/docs/CONFIGURATION.md): Detailed settings and CLI flags.
- [**Tool System & Permissions**](https://github.com/goejja/kiss-agent/blob/main/docs/TOOLS.md): How agents interact with your files.
- [**Agent Loop**](https://github.com/goejja/kiss-agent/blob/main/docs/AGENT_LOOP.md): Details on the core execution and streaming.
- [**Turn Engine & Phases**](https://github.com/goejja/kiss-agent/blob/main/docs/TURN_ENGINE.md): Deep dive into the unified turn engine and phase flow.
- [**Context Compaction**](https://github.com/goejja/kiss-agent/blob/main/docs/COMPACTION.md): How history and tokens are managed.
- [**Observability**](https://github.com/goejja/kiss-agent/blob/main/docs/OBSERVABILITY.md): Tracing and local diagnostics.
- [**Terminal UI**](https://github.com/goejja/kiss-agent/blob/main/docs/TERMINAL_UI.md): Rich and Textual backend design and parity rules.

## License

MIT — do whatever you want with this stupid agent.
