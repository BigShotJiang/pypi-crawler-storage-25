## Objective
<!-- Briefly describe the goal of this PR and why it is needed. -->

## Changes
<!-- List the main technical changes. Use conventional commit types (feat, fix, refactor, docs, chore, etc.). -->
-

## Verification Plan
<!-- How have you verified these changes? (e.g., unit tests, manual testing in TUI, etc.) -->
- [ ] Automated tests passed (`uv run pytest`)
- [ ] Manual verification completed

## Impact
<!-- Are there any potential side effects or breaking changes? -->
-

## Checklist
- [ ] I have followed the project's code style and standards.
- [ ] I have added/updated tests if applicable.
- [ ] I have updated documentation if applicable.
- [ ] I have ensured this PR is atomic and focused on a single logical change.
