"""Tests for the CLI — argument parsing, file extraction, and command dispatch."""

import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

# Add CLI dir to path
CLI_DIR = Path(__file__).resolve().parent.parent / "cli"
sys.path.insert(0, str(CLI_DIR))

import ai_cli


# ── Argparser tests ──────────────────────────────────────────


def test_argparser_health():
    parser = ai_cli.build_argparser()
    args = parser.parse_args(["health"])
    assert args.command == "health"


def test_argparser_model_list():
    parser = ai_cli.build_argparser()
    args = parser.parse_args(["model", "list"])
    assert args.command == "model"
    assert args.model_command == "list"


def test_argparser_model_use():
    parser = ai_cli.build_argparser()
    args = parser.parse_args(["model", "use", "deepseek:v2"])
    assert args.model_version == "deepseek:v2"


def test_argparser_ask():
    parser = ai_cli.build_argparser()
    args = parser.parse_args(["ask", "--model", "test", "--prompt", "hello"])
    assert args.model == "test"
    assert args.prompt == "hello"
    assert args.max_tokens == 512  # default


def test_argparser_task():
    parser = ai_cli.build_argparser()
    args = parser.parse_args(["task", "create a file", "--model", "m", "--auto"])
    assert args.prompt == "create a file"
    assert args.model == "m"
    assert args.auto is True
    assert args.max_tokens == 2048  # default


def test_argparser_run():
    parser = ai_cli.build_argparser()
    args = parser.parse_args(["run", "my-model", "--threads", "8"])
    assert args.model_id == "my-model"
    assert args.threads == 8


def test_argparser_source_add():
    parser = ai_cli.build_argparser()
    args = parser.parse_args([
        "source", "add",
        "--repo-url", "owner/repo",
        "--model-id", "test-model",
    ])
    assert args.source_command == "add"
    assert args.repo_url == "owner/repo"
    assert args.runtime == "llama_cpp"  # default


def test_argparser_completion():
    parser = ai_cli.build_argparser()
    args = parser.parse_args(["completion", "zsh"])
    assert args.shell == "zsh"


def test_argparser_host_override():
    parser = ai_cli.build_argparser()
    args = parser.parse_args(["--host", "http://custom:9999", "health"])
    assert args.host == "http://custom:9999"


def test_argparser_default_host():
    parser = ai_cli.build_argparser()
    args = parser.parse_args(["health"])
    assert args.host == "http://127.0.0.1:8090"


# ── File extraction tests ────────────────────────────────────


def test_extract_files_file_format(tmp_path):
    """FILE: format — the preferred output format."""
    output = 'FILE: calculator.py\n```\ndef add(a, b):\n    return a + b\n```'
    written = ai_cli._extract_and_write_files(output, tmp_path)
    assert written == ["calculator.py"]
    assert (tmp_path / "calculator.py").read_text() == "def add(a, b):\n    return a + b\n"


def test_extract_files_file_format_with_lang_tag(tmp_path):
    """FILE: format with a language tag on the fence — still works."""
    output = 'FILE: utils.py\n```python\nx = 1\n```'
    written = ai_cli._extract_and_write_files(output, tmp_path)
    assert "utils.py" in written
    assert (tmp_path / "utils.py").read_text() == "x = 1\n"


def test_extract_files_file_format_nested(tmp_path):
    output = 'FILE: src/lib/helper.py\n```\nhelper = True\n```'
    written = ai_cli._extract_and_write_files(output, tmp_path)
    assert "src/lib/helper.py" in written
    assert (tmp_path / "src" / "lib" / "helper.py").exists()


def test_extract_files_file_format_multiple(tmp_path):
    output = 'FILE: main.py\n```\nimport calc\n```\n\nFILE: calc.py\n```\ndef add(a,b): return a+b\n```'
    written = ai_cli._extract_and_write_files(output, tmp_path)
    assert len(written) == 2
    assert "main.py" in written
    assert "calc.py" in written


def test_extract_files_fallback_filename_fence(tmp_path):
    """Fallback: ```filename.py format still works."""
    output = '```calculator.py\ndef add(a, b):\n    return a + b\n```'
    written = ai_cli._extract_and_write_files(output, tmp_path)
    assert written == ["calculator.py"]
    assert (tmp_path / "calculator.py").read_text() == "def add(a, b):\n    return a + b\n"


def test_extract_files_fallback_nested_path(tmp_path):
    output = '```src/lib/helper.py\nhelper = True\n```'
    written = ai_cli._extract_and_write_files(output, tmp_path)
    assert "src/lib/helper.py" in written


def test_extract_files_no_blocks(tmp_path):
    output = "Just some text with no code blocks."
    written = ai_cli._extract_and_write_files(output, tmp_path)
    assert written == []


def test_extract_files_dedup(tmp_path):
    output = 'FILE: app.py\n```\nv1\n```\n\nFILE: app.py\n```\nv2\n```'
    written = ai_cli._extract_and_write_files(output, tmp_path)
    assert written.count("app.py") == 1


def test_extract_files_strips_absolute_path(tmp_path):
    abs_prefix = str(tmp_path)
    output = f'FILE: {abs_prefix}/myfile.py\n```\ncontent\n```'
    written = ai_cli._extract_and_write_files(output, tmp_path)
    assert "myfile.py" in written


def test_extract_files_path_traversal_blocked(tmp_path):
    output = 'FILE: ../../../etc/passwd\n```\nhacked\n```'
    written = ai_cli._extract_and_write_files(output, tmp_path)
    assert written == []


def test_extract_files_lang_tag_ignored_in_fallback(tmp_path):
    """```python blocks should NOT be treated as filenames."""
    output = '```python\nprint("hi")\n```'
    written = ai_cli._extract_and_write_files(output, tmp_path)
    assert written == []


def test_write_file_helper(tmp_path):
    result = ai_cli._write_file("test.py", "x = 1\n", tmp_path)
    assert result == "test.py"
    assert (tmp_path / "test.py").read_text() == "x = 1\n"


def test_write_file_traversal_blocked(tmp_path):
    result = ai_cli._write_file("../../evil.py", "x", tmp_path)
    assert result is None


# ── Command dispatch tests ───────────────────────────────────


def test_dispatch_health(capsys):
    with patch("ai_cli._request", return_value={"ok": True, "version": "3.0.0"}):
        parser = ai_cli.build_argparser()
        args = parser.parse_args(["health"])
        ai_cli.cmd_health(args)
    captured = capsys.readouterr()
    assert '"ok": true' in captured.out


def test_dispatch_model_list(capsys):
    mock_data = {
        "models": [{
            "model_id": "test-m",
            "runtime": "llama_cpp",
            "format": "gguf",
            "active_version": 1,
            "versions": [{}],
            "source_repo": "owner/repo",
        }]
    }
    with patch("ai_cli._request", return_value=mock_data):
        parser = ai_cli.build_argparser()
        args = parser.parse_args(["model", "list"])
        ai_cli.cmd_model_list(args)
    captured = capsys.readouterr()
    assert "test-m" in captured.out
    assert "llama_cpp" in captured.out


def test_is_github_repo():
    assert ai_cli._is_github_repo("owner/repo") is True
    assert ai_cli._is_github_repo("https://github.com/o/r") is True
    assert ai_cli._is_github_repo("https://github.com/o/r/releases/download/v1/model.gguf") is False


def test_main_returns_exit_code():
    with patch("ai_cli._request", return_value={"ok": True}):
        with patch("sys.argv", ["ai", "health"]):
            code = ai_cli.main()
    assert code == 0


def test_main_connection_error(capsys):
    with patch("ai_cli._request", side_effect=Exception("connection refused")):
        with patch("sys.argv", ["ai", "health"]):
            # main catches requests.RequestException, but general Exception may not be caught
            # This tests the error path
            try:
                code = ai_cli.main()
            except Exception:
                pass  # Expected for non-requests exceptions
