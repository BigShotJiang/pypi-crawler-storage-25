"""Tests for the GitHub client — URL parsing, version extraction, asset discovery."""

import pytest

from backend.github_client import (
    _get_extension,
    extract_version_number,
    parse_repo_url,
)


# ── parse_repo_url ────────────────────────────────────────────


@pytest.mark.parametrize(
    "url, expected",
    [
        ("owner/repo", ("owner", "repo")),
        ("https://github.com/owner/repo", ("owner", "repo")),
        ("https://github.com/owner/repo.git", ("owner", "repo")),
        ("https://github.com/owner/repo/tree/main", ("owner", "repo")),
    ],
)
def test_parse_repo_url_valid(url, expected):
    assert parse_repo_url(url) == expected


def test_parse_repo_url_not_github():
    with pytest.raises(ValueError, match="Invalid GitHub URL"):
        parse_repo_url("https://gitlab.com/owner/repo")


def test_parse_repo_url_incomplete():
    with pytest.raises(ValueError, match="Cannot parse"):
        parse_repo_url("https://github.com/owner")


# ── extract_version_number ────────────────────────────────────


@pytest.mark.parametrize(
    "tag, expected",
    [
        ("v1.2.3", "1.2.3"),
        ("release-2.0", "2.0"),
        ("1.0", "1.0"),
        ("nightly", "nightly"),
        ("v0.1.0-alpha", "0.1.0"),
    ],
)
def test_extract_version_number(tag, expected):
    assert extract_version_number(tag) == expected


# ── _get_extension ────────────────────────────────────────────


@pytest.mark.parametrize(
    "filename, expected",
    [
        ("model.gguf", ".gguf"),
        ("model.safetensors", ".safetensors"),
        ("model.onnx", ".onnx"),
        ("weights.bin", ".bin"),
        ("readme.md", ""),
        ("MODEL.GGUF", ".gguf"),
    ],
)
def test_get_extension(filename, expected):
    assert _get_extension(filename) == expected
