"""Tests for hardware detection."""

from backend.hardware import detect_cpu_threads, detect_hardware_summary


def test_detect_cpu_threads():
    threads = detect_cpu_threads()
    assert isinstance(threads, int)
    assert threads >= 1


def test_detect_hardware_summary():
    summary = detect_hardware_summary()
    assert "cpu_threads" in summary
    assert "platform" in summary
    assert "arch" in summary
    assert "gpu" in summary
    assert isinstance(summary["gpu"], dict)
    assert "available" in summary["gpu"]
