"""Tests for configuration."""

from pathlib import Path

from backend.config import AppSettings, RuntimeConfig, settings


def test_default_settings():
    assert settings.port == 8090
    assert settings.log_level == "INFO"
    assert isinstance(settings.models_dir, Path)
    assert isinstance(settings.config_dir, Path)
    assert settings.admin_token == ""
    assert "http://localhost:3000" in settings.cors_origins


def test_runtime_defaults():
    rc = RuntimeConfig()
    assert rc.default_runtime == "llama_cpp"
    assert rc.default_temperature == 0.3
    assert rc.default_max_tokens == 512


def test_ensure_dirs(tmp_path, monkeypatch):
    from backend import config
    s = AppSettings(
        models_dir=tmp_path / "m",
        config_dir=tmp_path / "c",
        data_dir=tmp_path / "d",
    )
    s.ensure_dirs()
    assert (tmp_path / "m").is_dir()
    assert (tmp_path / "c").is_dir()
    assert (tmp_path / "d").is_dir()


def test_cors_origins_parses_csv():
    s = AppSettings(cors_origins="https://a.example, https://b.example")
    assert s.cors_origins == ["https://a.example", "https://b.example"]


def test_cors_origins_parses_json_array():
    s = AppSettings(cors_origins='["https://a.example", "https://b.example"]')
    assert s.cors_origins == ["https://a.example", "https://b.example"]
