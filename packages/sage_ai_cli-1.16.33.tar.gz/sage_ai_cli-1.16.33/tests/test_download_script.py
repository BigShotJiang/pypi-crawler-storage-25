"""Tests for the download_models script — catalog loading, registry management, host validation."""

import json
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

# Add scripts dir to path so we can import the module
SCRIPTS_DIR = Path(__file__).resolve().parent.parent / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))

import download_models


@pytest.fixture(autouse=True)
def isolated_paths(tmp_path, monkeypatch):
    """Redirect all paths in the download script to temp dir."""
    monkeypatch.setattr(download_models, "MODELS_DIR", tmp_path / "models")
    monkeypatch.setattr(download_models, "REGISTRY_PATH", tmp_path / "config" / "registry.json")
    monkeypatch.setattr(download_models, "SOURCES_PATH", tmp_path / "config" / "sources.json")
    (tmp_path / "models").mkdir()
    (tmp_path / "config").mkdir()
    return tmp_path


def test_load_registry_empty(isolated_paths):
    assert download_models.load_registry() == {}


def test_save_and_load_registry(isolated_paths):
    data = {"test-model": {"model_id": "test-model", "versions": []}}
    download_models.save_registry(data)
    loaded = download_models.load_registry()
    assert loaded["test-model"]["model_id"] == "test-model"


def test_save_and_load_sources(isolated_paths):
    sources = [{"model_id": "test", "owner": "o", "repo": "r"}]
    download_models.save_sources(sources)
    loaded = download_models.load_sources()
    assert len(loaded) == 1
    assert loaded[0]["model_id"] == "test"


def test_register_model_new(isolated_paths):
    download_models.register_model(
        model_id="my-model",
        runtime="llama_cpp",
        file_path="/tmp/model.gguf",
        version_tag="v1.0",
        sha256="abc123",
        size_gb=1.5,
        source_url="https://github.com/o/r/releases/download/v1.0/model.gguf",
        fmt="gguf",
    )
    reg = download_models.load_registry()
    assert "my-model" in reg
    assert reg["my-model"]["versions"][0]["version_tag"] == "v1.0"


def test_register_model_dedup_by_hash(isolated_paths):
    """Registering the same hash twice should skip the second."""
    for i in range(2):
        download_models.register_model(
            model_id="dup",
            runtime="llama_cpp",
            file_path=f"/tmp/v{i}.gguf",
            version_tag=f"v{i}",
            sha256="samehash",
            size_gb=1.0,
            source_url=f"https://github.com/o/r/releases/download/v{i}/m.gguf",
            fmt="gguf",
        )
    reg = download_models.load_registry()
    assert len(reg["dup"]["versions"]) == 1


def test_register_model_dedup_by_tag(isolated_paths):
    """Registering the same tag twice should skip the second."""
    download_models.register_model(
        model_id="tag-dup", runtime="llama_cpp", file_path="/a",
        version_tag="v1.0", sha256="hash1", size_gb=1.0,
        source_url="https://github.com/o/r/1", fmt="gguf",
    )
    download_models.register_model(
        model_id="tag-dup", runtime="llama_cpp", file_path="/b",
        version_tag="v1.0", sha256="hash2", size_gb=1.0,
        source_url="https://github.com/o/r/2", fmt="gguf",
    )
    reg = download_models.load_registry()
    assert len(reg["tag-dup"]["versions"]) == 1


def test_register_model_new_version(isolated_paths):
    """Different tag + different hash = new version."""
    download_models.register_model(
        model_id="multi", runtime="llama_cpp", file_path="/a",
        version_tag="v1.0", sha256="hash1", size_gb=1.0,
        source_url="https://github.com/o/r/1", fmt="gguf",
    )
    download_models.register_model(
        model_id="multi", runtime="llama_cpp", file_path="/b",
        version_tag="v2.0", sha256="hash2", size_gb=1.2,
        source_url="https://github.com/o/r/2", fmt="gguf",
    )
    reg = download_models.load_registry()
    assert len(reg["multi"]["versions"]) == 2
    assert reg["multi"]["active_version"] == 2


def test_register_source_no_duplicates(isolated_paths):
    download_models.register_source("m1", "owner", "repo", "llama_cpp", "*.gguf")
    download_models.register_source("m1", "owner", "repo", "llama_cpp", "*.gguf")
    sources = download_models.load_sources()
    assert len(sources) == 1


def test_sha256_file(tmp_path):
    f = tmp_path / "test.bin"
    f.write_bytes(b"hello world")
    h = download_models.sha256_file(f)
    assert len(h) == 64
    # Known SHA256 of "hello world"
    assert h == "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9"


def test_reassemble_split_files(tmp_path):
    """Reassemble split parts into a single file."""
    parts_dir = tmp_path / "parts"
    parts_dir.mkdir()
    # Create 3 parts with known content
    part_paths = []
    for i in range(3):
        p = parts_dir / f"part-{i}"
        p.write_bytes(f"chunk{i}".encode())
        part_paths.append(p)

    output = tmp_path / "output" / "model.gguf"
    result = download_models.reassemble_split_files(part_paths, output)
    assert result is True
    assert output.exists()
    assert output.read_bytes() == b"chunk0chunk1chunk2"


def test_reassemble_creates_parent_dirs(tmp_path):
    """Reassemble should create parent directories if needed."""
    part = tmp_path / "p0"
    part.write_bytes(b"data")
    output = tmp_path / "deep" / "nested" / "dir" / "model.gguf"
    result = download_models.reassemble_split_files([part], output)
    assert result is True
    assert output.read_bytes() == b"data"


def test_reassemble_sorted_order(tmp_path):
    """Parts should be concatenated in sorted order."""
    parts = []
    for name in ["part-2", "part-0", "part-1"]:
        p = tmp_path / name
        p.write_bytes(name.encode())
        parts.append(p)

    output = tmp_path / "out.gguf"
    download_models.reassemble_split_files(parts, output)
    # Sorted order: part-0, part-1, part-2
    assert output.read_bytes() == b"part-0part-1part-2"


def test_catalog_has_version_tags(isolated_paths):
    """Every catalog model should have a version_tag field."""
    catalog = download_models.load_catalog()
    for m in catalog.get("models", []):
        assert "version_tag" in m, f"{m['model_id']} missing version_tag"
        assert len(m["version_tag"]) > 0


def test_catalog_all_github_urls(isolated_paths):
    """All direct_url and split_parts URLs should be GitHub."""
    catalog = download_models.load_catalog()
    for m in catalog.get("models", []):
        if "direct_url" in m:
            assert "github.com" in m["direct_url"], f"{m['model_id']} direct_url not GitHub"
        for url in m.get("split_parts", []):
            assert "github.com" in url, f"{m['model_id']} split_part not GitHub"


def test_catalog_no_huggingface(isolated_paths):
    """No model should reference HuggingFace in any URL field."""
    catalog = download_models.load_catalog()
    for m in catalog.get("models", []):
        for key in ["source_repo", "github_release_url", "direct_url"]:
            val = m.get(key, "")
            assert "huggingface" not in val.lower(), f"{m['model_id']}.{key} references HuggingFace"
        for url in m.get("split_parts", []):
            assert "huggingface" not in url.lower(), f"{m['model_id']} split_part references HuggingFace"


def test_catalog_model_ids_unique(isolated_paths):
    """Model IDs in the catalog must be unique."""
    catalog = download_models.load_catalog()
    ids = [m["model_id"] for m in catalog.get("models", [])]
    assert len(ids) == len(set(ids)), f"Duplicate IDs: {[x for x in ids if ids.count(x) > 1]}"


def test_discover_assets_follows_redirects(isolated_paths):
    """discover_assets should include follow_redirects=True."""
    import inspect
    source = inspect.getsource(download_models.discover_assets)
    assert "follow_redirects=True" in source
