"""Tests for runtime lifecycle management."""

from backend.runtime_manager import RuntimeManager


class _FakeRuntime:
    def __init__(self) -> None:
        self.loaded: tuple[str, int | None] | None = None
        self.closed = False

    def load(self, model_path: str, threads: int | None = None) -> None:
        self.loaded = (model_path, threads)

    def close(self) -> None:
        self.closed = True


def test_runtime_manager_load_sets_active_runtime(monkeypatch):
    monkeypatch.setattr(
        "backend.runtime_manager._get_runtime_map",
        lambda: {"fake": _FakeRuntime},
    )
    manager = RuntimeManager()

    manager.load("fake", "model-1", "/tmp/model.gguf", threads=4)

    assert manager.loaded_runtime == "fake"
    assert manager.loaded_model_id == "model-1"
    assert manager.runtime.loaded == ("/tmp/model.gguf", 4)


def test_runtime_manager_unload_closes_previous_runtime(monkeypatch):
    monkeypatch.setattr(
        "backend.runtime_manager._get_runtime_map",
        lambda: {"fake": _FakeRuntime},
    )
    manager = RuntimeManager()
    manager.load("fake", "model-1", "/tmp/model.gguf", threads=2)
    previous = manager.runtime

    manager.unload()

    assert previous.closed is True
    assert manager.runtime is None
    assert manager.loaded_model_id is None
    assert manager.loaded_runtime is None


def test_runtime_manager_replaces_existing_runtime(monkeypatch):
    monkeypatch.setattr(
        "backend.runtime_manager._get_runtime_map",
        lambda: {"fake": _FakeRuntime},
    )
    manager = RuntimeManager()
    manager.load("fake", "model-1", "/tmp/model-a.gguf", threads=1)
    previous = manager.runtime

    manager.load("fake", "model-2", "/tmp/model-b.gguf", threads=8)

    assert previous.closed is True
    assert manager.loaded_model_id == "model-2"
    assert manager.runtime.loaded == ("/tmp/model-b.gguf", 8)
