"""Tests for the conversation persistence store."""

import pytest


def test_create_conversation(conversation_store):
    conv = conversation_store.create("Test Chat")
    assert conv["title"] == "Test Chat"
    assert "id" in conv
    assert conv["messages"] == []


def test_get_conversation(conversation_store):
    conv = conversation_store.create("Hello")
    fetched = conversation_store.get(conv["id"])
    assert fetched["title"] == "Hello"


def test_get_missing_conversation(conversation_store):
    with pytest.raises(KeyError, match="Conversation not found"):
        conversation_store.get("nonexistent-id")


def test_append_message(conversation_store):
    conv = conversation_store.create("Chat")
    conversation_store.append_message(conv["id"], "user", "Hello!")
    conversation_store.append_message(conv["id"], "assistant", "Hi there!")

    fetched = conversation_store.get(conv["id"])
    assert len(fetched["messages"]) == 2
    assert fetched["messages"][0]["role"] == "user"
    assert fetched["messages"][1]["content"] == "Hi there!"


def test_append_auto_creates(conversation_store):
    """Appending to a non-existent conversation auto-creates it."""
    conversation_store.append_message("new-id", "user", "Hello")
    conv = conversation_store.get("new-id")
    assert conv["title"] == "Untitled"
    assert len(conv["messages"]) == 1


def test_list_all(conversation_store):
    conversation_store.create("First")
    conversation_store.create("Second")
    items = conversation_store.list_all()
    assert len(items) == 2
    titles = {c["title"] for c in items}
    assert titles == {"First", "Second"}


def test_list_all_includes_message_count(conversation_store):
    conv = conversation_store.create("Chat")
    conversation_store.append_message(conv["id"], "user", "msg1")
    conversation_store.append_message(conv["id"], "assistant", "msg2")
    items = conversation_store.list_all()
    assert items[0]["message_count"] == 2


def test_delete_conversation(conversation_store):
    conv = conversation_store.create("To Delete")
    conversation_store.delete(conv["id"])
    assert conversation_store.list_all() == []


def test_delete_nonexistent_is_silent(conversation_store):
    conversation_store.delete("does-not-exist")  # should not raise
