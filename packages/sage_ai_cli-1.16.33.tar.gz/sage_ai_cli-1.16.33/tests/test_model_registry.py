"""Tests for the model registry — import, versioning, dedup, validation."""

import json

import pytest

from backend.model_registry import ALLOWED_HOSTS, ModelRegistry
from backend.schemas import DownloadModelReq, ImportModelReq, ModelRecord


# ── Basic CRUD ────────────────────────────────────────────────


def test_list_models_empty(registry):
    assert registry.list_models() == []


def test_import_local_file(registry, sample_model_file):
    req = ImportModelReq(
        model_id="test-model",
        local_path=str(sample_model_file),
        runtime="llama_cpp",
    )
    record = registry.import_local(req)
    assert record.model_id == "test-model"
    assert record.active_version == 1
    assert len(record.versions) == 1
    assert record.format == "gguf"
    assert record.versions[0].local_import is True


def test_import_creates_version_dir(registry, sample_model_file, isolated_dirs):
    req = ImportModelReq(
        model_id="test-model",
        local_path=str(sample_model_file),
        runtime="llama_cpp",
    )
    registry.import_local(req)
    version_dir = isolated_dirs["models"] / "test-model" / "v1"
    assert version_dir.exists()
    assert (version_dir / "test-model.gguf").exists()


def test_get_model(registry, sample_model_file):
    req = ImportModelReq(model_id="abc", local_path=str(sample_model_file), runtime="llama_cpp")
    registry.import_local(req)
    record = registry.get_model("abc")
    assert record.model_id == "abc"


def test_get_model_not_found(registry):
    with pytest.raises(KeyError, match="Unknown model"):
        registry.get_model("nonexistent")


# ── Versioning ────────────────────────────────────────────────


def test_import_multiple_versions(registry, tmp_path):
    f1 = tmp_path / "v1.gguf"
    f1.write_bytes(b"GGUF" + b"\x01" * 512)
    f2 = tmp_path / "v2.gguf"
    f2.write_bytes(b"GGUF" + b"\x02" * 512)

    registry.import_local(ImportModelReq(model_id="mv", local_path=str(f1), runtime="llama_cpp"))
    registry.import_local(ImportModelReq(model_id="mv", local_path=str(f2), runtime="llama_cpp"))

    record = registry.get_model("mv")
    assert len(record.versions) == 2
    assert record.active_version == 2


def test_set_active_version(registry, tmp_path):
    f1 = tmp_path / "v1.gguf"
    f1.write_bytes(b"GGUF" + b"\x01" * 512)
    f2 = tmp_path / "v2.gguf"
    f2.write_bytes(b"GGUF" + b"\x02" * 512)

    registry.import_local(ImportModelReq(model_id="mv", local_path=str(f1), runtime="llama_cpp"))
    registry.import_local(ImportModelReq(model_id="mv", local_path=str(f2), runtime="llama_cpp"))

    record = registry.set_active_version("mv", 1)
    assert record.active_version == 1


def test_set_active_version_not_found(registry, sample_model_file):
    registry.import_local(ImportModelReq(model_id="mv", local_path=str(sample_model_file), runtime="llama_cpp"))
    with pytest.raises(KeyError, match="Version 99"):
        registry.set_active_version("mv", 99)


# ── SHA256 dedup ──────────────────────────────────────────────


def test_import_dedup_by_hash(registry, tmp_path):
    """Importing the exact same file twice should skip the second import."""
    f1 = tmp_path / "copy1.gguf"
    f1.write_bytes(b"GGUF" + b"\xAA" * 512)
    f2 = tmp_path / "copy2.gguf"
    f2.write_bytes(b"GGUF" + b"\xAA" * 512)  # identical content

    registry.import_local(ImportModelReq(model_id="dd", local_path=str(f1), runtime="llama_cpp"))
    record = registry.import_local(ImportModelReq(model_id="dd", local_path=str(f2), runtime="llama_cpp"))
    assert len(record.versions) == 1  # deduped


# ── Validation ────────────────────────────────────────────────


def test_validate_source_rejects_non_github(registry):
    with pytest.raises(ValueError, match="not allowed"):
        registry._validate_source("https://huggingface.co/model/file.gguf")


def test_validate_source_allows_github(registry):
    # Should NOT raise
    for host in ALLOWED_HOSTS:
        registry._validate_source(f"https://{host}/owner/repo/file.gguf")


def test_import_wrong_format_for_runtime(registry, tmp_path):
    bad = tmp_path / "model.safetensors"
    bad.write_bytes(b"\x00" * 100)
    with pytest.raises(ValueError, match="llama_cpp requires .gguf"):
        registry.import_local(ImportModelReq(model_id="bad", local_path=str(bad), runtime="llama_cpp"))


def test_import_nonexistent_path(registry):
    with pytest.raises(FileNotFoundError):
        registry.import_local(ImportModelReq(model_id="nope", local_path="/nonexistent", runtime="llama_cpp"))


# ── Helpers ───────────────────────────────────────────────────


def test_detect_format():
    from backend.model_registry import ModelRegistry

    r = ModelRegistry.__new__(ModelRegistry)
    assert r._detect_format("model.gguf") == "gguf"
    assert r._detect_format("model.safetensors") == "safetensors"
    assert r._detect_format("model.onnx") == "onnx"
    assert r._detect_format("model.bin") == "pytorch"
    assert r._detect_format("readme.md") == "unknown"


def test_extract_source_repo():
    from backend.model_registry import ModelRegistry

    r = ModelRegistry.__new__(ModelRegistry)
    assert r._extract_source_repo("https://github.com/owner/repo/releases/download/v1/file.gguf") == "owner/repo"
    assert r._extract_source_repo("https://example.com/file.gguf") is None


def test_infer_filename():
    from backend.model_registry import ModelRegistry

    r = ModelRegistry.__new__(ModelRegistry)
    assert r._infer_filename("https://github.com/o/r/releases/download/v1/model-q4.gguf", "m", "llama_cpp") == "model-q4.gguf"
    assert r._infer_filename("https://github.com/o/r/releases/latest", "my-model", "llama_cpp") == "my-model.gguf"
    assert r._infer_filename("https://github.com/o/r/releases/latest", "my-model", "onnx") == "my-model.onnx"
