"""Tests for the model catalog — loading, filtering, querying."""

import pytest

from backend.model_catalog import (
    clear_cache,
    filter_by_ram,
    filter_by_use_case,
    get_catalog_model,
    get_default_model,
    get_recommended_models,
    list_catalog_models,
    load_catalog,
)


@pytest.fixture(autouse=True)
def fresh_cache():
    clear_cache()
    yield
    clear_cache()


def test_load_catalog():
    catalog = load_catalog()
    assert "models" in catalog
    assert "default_models" in catalog
    assert "recommended_first_download" in catalog


def test_list_catalog_models():
    models = list_catalog_models()
    assert isinstance(models, list)
    assert len(models) >= 5  # we have at least 6 in the catalog


def test_catalog_model_structure():
    """Each catalog model should have required fields."""
    models = list_catalog_models()
    for m in models:
        assert "model_id" in m
        assert "runtime" in m
        assert "format" in m
        assert "source_repo" in m
        assert "size_gb" in m
        assert "use_case" in m
        assert isinstance(m["use_case"], list)


def test_get_catalog_model():
    model = get_catalog_model("bitnet-b158-2b-4t")
    assert model is not None
    assert model["model_id"] == "bitnet-b158-2b-4t"
    assert model["runtime"] == "llama_cpp"


def test_get_catalog_model_not_found():
    assert get_catalog_model("nonexistent-model") is None


def test_get_recommended_models():
    recommended = get_recommended_models()
    assert len(recommended) >= 2
    ids = {m["model_id"] for m in recommended}
    assert "bitnet-b158-2b-4t" in ids


def test_get_default_model_coding():
    model = get_default_model("coding")
    assert model is not None
    assert "coding" in model.get("use_case", [])


def test_get_default_model_chat():
    model = get_default_model("chat")
    assert model is not None


def test_get_default_model_unknown():
    assert get_default_model("quantum-computing") is None


def test_filter_by_ram():
    small = filter_by_ram(2)
    assert len(small) >= 1
    for m in small:
        assert m["min_ram_gb"] <= 2


def test_filter_by_ram_generous():
    big = filter_by_ram(16)
    all_models = list_catalog_models()
    assert len(big) == len(all_models)  # all models fit in 16 GB


def test_filter_by_use_case_coding():
    coding = filter_by_use_case("coding")
    assert len(coding) >= 2  # we have several coding models
    for m in coding:
        assert "coding" in m["use_case"]


def test_no_huggingface_urls():
    """No model should reference HuggingFace."""
    for m in list_catalog_models():
        repo = m.get("source_repo", "")
        url = m.get("github_release_url", "")
        assert "huggingface" not in repo.lower(), f"{m['model_id']} references HuggingFace"
        assert "huggingface" not in url.lower(), f"{m['model_id']} references HuggingFace"


def test_all_urls_are_github():
    """All download URLs should point to github.com."""
    for m in list_catalog_models():
        direct = m.get("direct_url", "")
        if direct:
            assert "github.com" in direct, f"{m['model_id']} direct_url is not GitHub"
        for part_url in m.get("split_parts", []):
            assert "github.com" in part_url, f"{m['model_id']} split_part is not GitHub"
