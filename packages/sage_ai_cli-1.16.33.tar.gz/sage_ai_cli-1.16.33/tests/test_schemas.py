"""Tests for Pydantic schemas — validation, defaults, and helper methods."""

import pytest
from pydantic import ValidationError

from backend.schemas import (
    AddSourceReq,
    ChatMessage,
    ChatReq,
    CreateConversationReq,
    DownloadModelReq,
    ImportModelReq,
    LoadModelReq,
    ModelRecord,
    ModelVersion,
    SetActiveVersionReq,
)


# ── ModelVersion ──────────────────────────────────────────────


def test_model_version_defaults():
    v = ModelVersion(version=1, file_path="/models/test/v1/model.gguf")
    assert v.version == 1
    assert v.sha256 is None
    assert v.version_tag is None
    assert v.local_import is False


# ── ModelRecord ───────────────────────────────────────────────


def test_model_record_active():
    v1 = ModelVersion(version=1, file_path="/a")
    v2 = ModelVersion(version=2, file_path="/b")
    record = ModelRecord(model_id="test", runtime="llama_cpp", active_version=2, versions=[v1, v2])
    assert record.active().file_path == "/b"


def test_model_record_active_missing():
    record = ModelRecord(model_id="test", runtime="llama_cpp", active_version=99, versions=[])
    with pytest.raises(KeyError, match="Active version 99"):
        record.active()


def test_model_record_latest_version_number():
    v1 = ModelVersion(version=1, file_path="/a")
    v3 = ModelVersion(version=3, file_path="/c")
    record = ModelRecord(model_id="x", runtime="llama_cpp", versions=[v1, v3])
    assert record.latest_version_number() == 3


def test_model_record_latest_version_empty():
    record = ModelRecord(model_id="x", runtime="llama_cpp", versions=[])
    assert record.latest_version_number() == 0


def test_model_record_all_hashes():
    v1 = ModelVersion(version=1, file_path="/a", sha256="ABC123")
    v2 = ModelVersion(version=2, file_path="/b", sha256=None)
    v3 = ModelVersion(version=3, file_path="/c", sha256="DEF456")
    record = ModelRecord(model_id="x", runtime="llama_cpp", versions=[v1, v2, v3])
    assert record.all_hashes() == {"abc123", "def456"}


def test_model_record_all_tags():
    v1 = ModelVersion(version=1, file_path="/a", version_tag="v1.0")
    v2 = ModelVersion(version=2, file_path="/b", version_tag=None)
    record = ModelRecord(model_id="x", runtime="llama_cpp", versions=[v1, v2])
    assert record.all_tags() == {"v1.0"}


# ── Request validation ────────────────────────────────────────


def test_download_model_req_valid():
    req = DownloadModelReq(
        model_id="my-model",
        source_url="https://github.com/owner/repo/releases/download/v1/file.gguf",
        runtime="llama_cpp",
    )
    assert req.model_id == "my-model"


def test_download_model_req_bad_runtime():
    with pytest.raises(ValidationError):
        DownloadModelReq(model_id="test", source_url="https://example.com/f", runtime="invalid")


def test_download_model_req_short_model_id():
    with pytest.raises(ValidationError):
        DownloadModelReq(model_id="x", source_url="https://example.com/f", runtime="llama_cpp")


def test_chat_message_valid_roles():
    for role in ("system", "user", "assistant"):
        msg = ChatMessage(role=role, content="hello")
        assert msg.role == role


def test_chat_message_invalid_role():
    with pytest.raises(ValidationError):
        ChatMessage(role="moderator", content="hello")


def test_chat_req_defaults():
    req = ChatReq(
        model_id="test",
        messages=[ChatMessage(role="user", content="hi")],
    )
    assert req.temperature == 0.3
    assert req.max_tokens == 512
    assert req.stream is True


def test_chat_req_bounds():
    with pytest.raises(ValidationError):
        ChatReq(model_id="test", messages=[], temperature=5.0)


def test_load_model_req_thread_bounds():
    with pytest.raises(ValidationError):
        LoadModelReq(model_id="test", threads=0)


def test_set_active_version_req():
    req = SetActiveVersionReq(model_id="test", version=3)
    assert req.version == 3
    with pytest.raises(ValidationError):
        SetActiveVersionReq(model_id="test", version=0)


def test_create_conversation_req():
    with pytest.raises(ValidationError):
        CreateConversationReq(title="")


def test_add_source_req_defaults():
    req = AddSourceReq(repo_url="owner/repo", model_id="my-model")
    assert req.runtime == "llama_cpp"
    assert req.asset_pattern == "*.gguf"
