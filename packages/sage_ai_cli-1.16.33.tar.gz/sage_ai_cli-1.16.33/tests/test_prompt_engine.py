"""Tests for the prompt engine — system prompt loading, few-shot parsing, message building."""

import pytest
from pathlib import Path

from backend.prompt_engine import (
    _parse_fewshot,
    build_messages,
    clear_cache,
    load_fewshot_examples,
    load_system_prompt,
)
from backend.schemas import ChatMessage


@pytest.fixture(autouse=True)
def fresh_cache():
    """Clear prompt cache before each test."""
    clear_cache()
    yield
    clear_cache()


def test_load_system_prompt():
    """System prompt should load from prompts/system.txt."""
    prompt = load_system_prompt()
    assert isinstance(prompt, str)
    assert len(prompt) > 50
    assert "local coding AI" in prompt


def test_load_system_prompt_cached():
    """Second call should return cached version."""
    first = load_system_prompt()
    second = load_system_prompt()
    assert first is second


def test_load_fewshot_examples():
    """Few-shot examples should parse from prompts/fewshot.md."""
    examples = load_fewshot_examples()
    assert isinstance(examples, list)
    assert len(examples) >= 3  # we wrote at least 5 examples
    for pair in examples:
        assert "user" in pair
        assert "assistant" in pair
        assert len(pair["user"]) > 10
        assert len(pair["assistant"]) > 10


def test_parse_fewshot_basic():
    """Parse a minimal fewshot markdown."""
    text = """
---

## Example 1

**User:** What is 2+2?

**Assistant:** 4

---
"""
    pairs = _parse_fewshot(text)
    assert len(pairs) == 1
    assert "2+2" in pairs[0]["user"]
    assert "4" in pairs[0]["assistant"]


def test_parse_fewshot_multiline():
    """Parse fewshot with multi-line code blocks."""
    text = """
---

## Example

**User:** Fix this:
```python
def f(): pass
```

**Assistant:** Here's the fix:
```python
def f():
    return 42
```

---
"""
    pairs = _parse_fewshot(text)
    assert len(pairs) == 1
    assert "def f()" in pairs[0]["user"]
    assert "return 42" in pairs[0]["assistant"]


def test_build_messages_with_system():
    user_msgs = [ChatMessage(role="user", content="hello")]
    result = build_messages(user_msgs, include_system=True, include_fewshot=False)
    assert result[0].role == "system"
    assert "local coding AI" in result[0].content
    assert result[1].role == "user"
    assert result[1].content == "hello"


def test_build_messages_without_system():
    user_msgs = [ChatMessage(role="user", content="hello")]
    result = build_messages(user_msgs, include_system=False, include_fewshot=False)
    assert len(result) == 1
    assert result[0].role == "user"


def test_build_messages_with_fewshot():
    user_msgs = [ChatMessage(role="user", content="hello")]
    result = build_messages(user_msgs, include_system=True, include_fewshot=True)
    # system + fewshot pairs + user message
    assert result[0].role == "system"
    assert result[-1].content == "hello"
    # At least some fewshot examples in between
    assert len(result) > 3
