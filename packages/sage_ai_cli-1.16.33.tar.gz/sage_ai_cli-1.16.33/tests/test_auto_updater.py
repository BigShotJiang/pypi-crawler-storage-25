"""Tests for the auto-updater — source tracking and update checking."""

import pytest

from backend.auto_updater import AutoUpdater, TrackedSource


# ── Source management ─────────────────────────────────────────


def test_list_sources_empty(auto_updater):
    assert auto_updater.list_sources() == []


def test_add_source(auto_updater):
    source = auto_updater.add_source(
        repo_url="owner/repo",
        model_id="my-model",
        runtime="llama_cpp",
        asset_pattern="*.gguf",
    )
    assert source.model_id == "my-model"
    assert source.owner == "owner"
    assert source.repo == "repo"

    sources = auto_updater.list_sources()
    assert len(sources) == 1
    assert sources[0].model_id == "my-model"


def test_add_duplicate_source_raises(auto_updater):
    auto_updater.add_source(repo_url="owner/repo", model_id="my-model")
    with pytest.raises(ValueError, match="already tracked"):
        auto_updater.add_source(repo_url="owner/repo", model_id="my-model")


def test_remove_source(auto_updater):
    auto_updater.add_source(repo_url="owner/repo", model_id="my-model")
    auto_updater.remove_source("my-model")
    assert auto_updater.list_sources() == []


def test_remove_nonexistent_is_silent(auto_updater):
    auto_updater.remove_source("nope")  # should not raise


# ── Update checking ───────────────────────────────────────────


def test_check_updates_no_sources(auto_updater):
    results = auto_updater.check_updates()
    assert results == []


def test_check_updates_specific_model_not_found(auto_updater):
    with pytest.raises(KeyError, match="No tracked source"):
        auto_updater.check_updates(model_id="nonexistent")


def test_source_persists_across_instances(auto_updater, registry):
    auto_updater.add_source(repo_url="owner/repo", model_id="persisted")
    new_updater = AutoUpdater(registry)
    sources = new_updater.list_sources()
    assert len(sources) == 1
    assert sources[0].model_id == "persisted"
