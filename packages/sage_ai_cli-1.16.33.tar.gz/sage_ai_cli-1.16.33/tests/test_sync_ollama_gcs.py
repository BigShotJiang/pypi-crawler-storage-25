"""Tests for syncing local Ollama models into GCS."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

SCRIPTS_DIR = Path(__file__).resolve().parent.parent / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))

import sync_ollama_gcs


@pytest.fixture()
def ollama_store(tmp_path, monkeypatch):
    manifests_dir = tmp_path / "models" / "manifests"
    blobs_dir = tmp_path / "models" / "blobs"
    manifests_dir.mkdir(parents=True)
    blobs_dir.mkdir(parents=True)
    monkeypatch.setattr(sync_ollama_gcs, "OLLAMA_MODELS_DIR", tmp_path / "models")
    monkeypatch.setattr(sync_ollama_gcs, "OLLAMA_MANIFESTS_DIR", manifests_dir)
    monkeypatch.setattr(sync_ollama_gcs, "OLLAMA_BLOBS_DIR", blobs_dir)
    return {"manifests": manifests_dir, "blobs": blobs_dir}


def write_manifest(base: Path, model_path: str, *, config: str, layers: list[str]) -> Path:
    manifest_path = base / model_path
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(
            {
                "schemaVersion": 2,
                "mediaType": "application/vnd.docker.distribution.manifest.v2+json",
                "config": {"digest": config},
                "layers": [{"digest": layer} for layer in layers],
            }
        ),
        encoding="utf-8",
    )
    return manifest_path


def write_blob(base: Path, digest: str, content: bytes = b"x") -> Path:
    blob_path = base / sync_ollama_gcs.digest_to_blob_filename(digest)
    blob_path.write_bytes(content)
    return blob_path


def test_parse_model_ref_defaults_library_and_latest():
    model = sync_ollama_gcs.parse_model_ref("gemma4")
    assert model.registry == "registry.ollama.ai"
    assert model.namespace == "library"
    assert model.name == "gemma4"
    assert model.tag == "latest"
    assert model.display_name == "gemma4:latest"


def test_parse_model_ref_supports_namespace():
    model = sync_ollama_gcs.parse_model_ref("custom/agent:beta")
    assert model.registry == "registry.ollama.ai"
    assert model.namespace == "custom"
    assert model.name == "agent"
    assert model.tag == "beta"
    assert model.display_name == "custom/agent:beta"


def test_discover_local_models_reads_manifest_tree(ollama_store):
    write_manifest(
        ollama_store["manifests"],
        "registry.ollama.ai/library/gemma4/latest",
        config="sha256:config",
        layers=["sha256:model"],
    )
    write_manifest(
        ollama_store["manifests"],
        "registry.ollama.ai/library/lfm2.5-thinking/latest",
        config="sha256:cfg2",
        layers=["sha256:model2"],
    )

    models = sync_ollama_gcs.discover_local_models(ollama_store["manifests"])

    assert [model.display_name for model in models] == [
        "gemma4:latest",
        "lfm2.5-thinking:latest",
    ]


def test_collect_sync_objects_includes_manifest_and_all_blobs(ollama_store):
    write_manifest(
        ollama_store["manifests"],
        "registry.ollama.ai/library/gemma4/latest",
        config="sha256:config",
        layers=["sha256:model", "sha256:license"],
    )
    write_blob(ollama_store["blobs"], "sha256:config")
    write_blob(ollama_store["blobs"], "sha256:model")
    write_blob(ollama_store["blobs"], "sha256:license")

    objects = sync_ollama_gcs.collect_sync_objects(
        sync_ollama_gcs.parse_model_ref("gemma4"),
        bucket="bucket",
        manifests_dir=ollama_store["manifests"],
        blobs_dir=ollama_store["blobs"],
    )

    assert [obj.remote_uri for obj in objects] == [
        "gs://bucket/ollama/models/manifests/registry.ollama.ai/library/gemma4/latest",
        "gs://bucket/ollama/models/blobs/sha256-config",
        "gs://bucket/ollama/models/blobs/sha256-model",
        "gs://bucket/ollama/models/blobs/sha256-license",
    ]


def test_collect_sync_objects_rejects_missing_blob(ollama_store):
    write_manifest(
        ollama_store["manifests"],
        "registry.ollama.ai/library/gemma4/latest",
        config="sha256:config",
        layers=["sha256:model"],
    )
    write_blob(ollama_store["blobs"], "sha256:config")

    with pytest.raises(sync_ollama_gcs.SyncError):
        sync_ollama_gcs.collect_sync_objects(
            sync_ollama_gcs.parse_model_ref("gemma4"),
            bucket="bucket",
            manifests_dir=ollama_store["manifests"],
            blobs_dir=ollama_store["blobs"],
        )


def test_sync_model_uploads_missing_objects_only(ollama_store, monkeypatch):
    write_manifest(
        ollama_store["manifests"],
        "registry.ollama.ai/library/gemma4/latest",
        config="sha256:config",
        layers=["sha256:model", "sha256:license"],
    )
    write_blob(ollama_store["blobs"], "sha256:config")
    write_blob(ollama_store["blobs"], "sha256:model")
    write_blob(ollama_store["blobs"], "sha256:license")

    existing = {
        "gs://bucket/ollama/models/manifests/registry.ollama.ai/library/gemma4/latest",
        "gs://bucket/ollama/models/blobs/sha256-config",
        "gs://bucket/ollama/models/blobs/sha256-license",
    }
    uploads: list[str] = []

    def fake_exists(uri: str) -> bool:
        return uri in existing

    def fake_upload(obj, *, dry_run: bool = False):
        uploads.append(obj.remote_uri)
        existing.add(obj.remote_uri)

    monkeypatch.setattr(sync_ollama_gcs, "gcs_object_exists", fake_exists)
    monkeypatch.setattr(sync_ollama_gcs, "upload_object", fake_upload)

    result = sync_ollama_gcs.sync_model(
        sync_ollama_gcs.parse_model_ref("gemma4"),
        bucket="bucket",
    )

    assert uploads == ["gs://bucket/ollama/models/blobs/sha256-model"]
    assert result["model"] == "gemma4:latest"
    assert result["deleted_local"] is False


def test_sync_model_deletes_local_only_after_verification(ollama_store, monkeypatch):
    write_manifest(
        ollama_store["manifests"],
        "registry.ollama.ai/library/gemma4/latest",
        config="sha256:config",
        layers=["sha256:model"],
    )
    write_blob(ollama_store["blobs"], "sha256:config")
    write_blob(ollama_store["blobs"], "sha256:model")

    existing: set[str] = set()
    deleted: list[str] = []

    monkeypatch.setattr(
        sync_ollama_gcs,
        "gcs_object_exists",
        lambda uri: uri in existing,
    )
    monkeypatch.setattr(
        sync_ollama_gcs,
        "upload_object",
        lambda obj, dry_run=False: existing.add(obj.remote_uri),
    )
    monkeypatch.setattr(
        sync_ollama_gcs,
        "delete_local_model",
        lambda model, dry_run=False: deleted.append(model.display_name),
    )

    sync_ollama_gcs.sync_model(
        sync_ollama_gcs.parse_model_ref("gemma4"),
        bucket="bucket",
        delete_after_upload=True,
    )

    assert deleted == ["gemma4:latest"]


def test_cleanup_partial_uploads_removes_matches(monkeypatch):
    removed: list[str] = []

    def fake_list(pattern: str) -> list[str]:
        if "parallel_composite_uploads" in pattern:
            return ["gs://bucket/gsutil/tmp/parallel_composite_uploads/tmp-object"]
        if "partial" in pattern:
            return ["gs://bucket/ollama/models/blobs/sha256-abc-partial"]
        return []

    def fake_run(argv: list[str], *, capture_output=True, dry_run=False, check=True):
        if argv[:2] == ["gsutil", "rm"]:
            removed.append(argv[-1])
        return sync_ollama_gcs.subprocess.CompletedProcess(argv, 0, "", "")

    monkeypatch.setattr(sync_ollama_gcs, "list_matching_objects", fake_list)
    monkeypatch.setattr(sync_ollama_gcs, "run_command", fake_run)

    cleaned = sync_ollama_gcs.cleanup_partial_uploads("bucket")

    assert cleaned == [
        "gs://bucket/gsutil/tmp/parallel_composite_uploads/tmp-object",
        "gs://bucket/ollama/models/blobs/sha256-abc-partial",
    ]
    assert removed == cleaned


def test_sync_model_dry_run_reports_missing_uploads_as_planned(ollama_store, monkeypatch):
    write_manifest(
        ollama_store["manifests"],
        "registry.ollama.ai/library/gemma4/latest",
        config="sha256:config",
        layers=["sha256:model"],
    )
    write_blob(ollama_store["blobs"], "sha256:config")
    write_blob(ollama_store["blobs"], "sha256:model")

    existing: set[str] = set()
    uploads: list[str] = []

    monkeypatch.setattr(sync_ollama_gcs, "gcs_object_exists", lambda uri: uri in existing)
    monkeypatch.setattr(
        sync_ollama_gcs,
        "upload_object",
        lambda obj, dry_run=False: uploads.append(obj.remote_uri),
    )

    result = sync_ollama_gcs.sync_model(
        sync_ollama_gcs.parse_model_ref("gemma4"),
        bucket="bucket",
        dry_run=True,
    )

    assert uploads == [
        "gs://bucket/ollama/models/manifests/registry.ollama.ai/library/gemma4/latest",
        "gs://bucket/ollama/models/blobs/sha256-config",
        "gs://bucket/ollama/models/blobs/sha256-model",
    ]
    assert len(result["uploaded"]) == 3


def test_resolve_models_prefers_local_when_no_explicit_targets(ollama_store):
    write_manifest(
        ollama_store["manifests"],
        "registry.ollama.ai/library/gemma4/latest",
        config="sha256:config",
        layers=["sha256:model"],
    )

    parser = sync_ollama_gcs.build_parser()
    args = parser.parse_args([])

    models = sync_ollama_gcs.resolve_models(args)

    assert [model.display_name for model in models] == ["gemma4:latest"]
