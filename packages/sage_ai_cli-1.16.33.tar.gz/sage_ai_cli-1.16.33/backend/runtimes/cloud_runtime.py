"""Free cloud provider runtime — uses Pollinations AI API.
API key optional but recommended for higher rate limits."""

import json
import os

import httpx

from ..schemas import ChatMessage
from .base import RuntimeAdapter


class CloudRuntime(RuntimeAdapter):
    """Uses Pollinations AI API (free with optional API key for higher limits)."""

    def __init__(self) -> None:
        self._model_name: str | None = None
        # Pollinations API endpoint - gen.pollinations.ai is the new unified gateway
        self._base_url = "https://gen.pollinations.ai/v1"
        self._api_key = os.environ.get("POLLINATIONS_API_KEY", "")

    def load(self, model_path: str, threads: int | None = None) -> None:
        # Store original model name for reference, but always use "openai" for API
        # since Pollinations only supports the "openai" model alias
        self._model_name = model_path
        self._api_model = "openai"  # Pollinations only supports this model

    def chat(
        self,
        messages: list[ChatMessage],
        temperature: float,
        max_tokens: int,
    ) -> str:
        if not self._model_name:
            raise RuntimeError("No cloud model loaded")
        payload = {
            "model": self._api_model,
            "messages": [m.model_dump() for m in messages],
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False,
        }
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "Sage-AI-Platform/1.0",
            "Accept": "application/json",
        }
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        with httpx.Client(timeout=120) as client:
            resp = client.post(
                f"{self._base_url}/chat/completions",
                json=payload,
                headers=headers,
            )
            resp.raise_for_status()
            data = resp.json()
            # Safe extraction with bounds checking
            choices = data.get("choices", [])
            if not choices:
                return ""
            first_choice = choices[0] if choices else {}
            message = first_choice.get("message", {})
            return message.get("content", "")

    def stream_chat(
        self,
        messages: list[ChatMessage],
        temperature: float,
        max_tokens: int,
    ):
        if not self._model_name:
            raise RuntimeError("No cloud model loaded")
        payload = {
            "model": self._api_model,
            "messages": [m.model_dump() for m in messages],
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True,
        }
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "Sage-AI-Platform/1.0",
            "Accept": "application/json",
        }
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        with httpx.Client(timeout=120) as client:
            with client.stream(
                "POST",
                f"{self._base_url}/chat/completions",
                json=payload,
                headers=headers,
            ) as resp:
                resp.raise_for_status()
                for line in resp.iter_lines():
                    if not line.startswith("data: "):
                        continue
                    data_str = line[6:]
                    if data_str.strip() == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue
                    # Safe extraction with bounds checking
                    choices = chunk.get("choices", [])
                    if not choices:
                        continue
                    first_choice = choices[0] if choices else {}
                    delta = first_choice.get("delta", {})
                    content = delta.get("content")
                    if content:
                        yield content
