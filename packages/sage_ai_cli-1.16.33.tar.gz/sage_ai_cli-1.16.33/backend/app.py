"""Backend API for SAGE AI Platform.

This module provides the FastAPI backend with proper architectural patterns:
- App state instead of globals (P2-86)
- Isolated instance creation (P2-87)
- Lifecycle hooks (P2-88)
- Runtime locking (P2-89, P2-90)
- Structured error events for SSE (P2-91)
- Rate limiting with eviction (P2-95, P2-98)
- Request IDs and correlation (P2-100)
- Audit logging (P2-101)
- Proper error taxonomy (P2-102)
"""

from __future__ import annotations

import json
import logging
import os
import secrets
import time
import uuid
from collections import defaultdict
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from threading import Lock, RLock
from collections.abc import AsyncIterator, Callable

import uvicorn
from fastapi import Depends, FastAPI, File, Header, HTTPException, Request, Response, UploadFile, WebSocket, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles

from .terminal_ws import (
    terminal_websocket_handler,
    get_cli_update_info,
    apply_cli_update,
)

from .auto_updater import AutoUpdater
from .config import runtime_defaults, settings
from .conversations import ConversationStore
from .hardware import detect_hardware_summary
from .model_catalog import (
    filter_by_ram,
    get_recommended_models,
)
from sage.models.catalog import (
    get_recommended_ollama_models,
    get_full_catalog,
)
from sage.models.gcs_manager import (
    GCSModelManager,
    OllamaClient,
)
from .model_registry import ModelRegistry
from .runtime_manager import RuntimeManager
from .schemas import (
    AddSourceReq,
    ChatMessage,
    ChatReq,
    CreateConversationReq,
    DownloadModelReq,
    FileAttachment,
    LargeTextContent,
    LoadModelReq,
    validate_safe_id,
    SAFE_MODEL_ID_PATTERN,
    SAFE_CONVERSATION_ID_PATTERN,
    LARGE_TEXT_THRESHOLD,
)
from .file_store import file_store, MAX_FILE_SIZE
from .conversation_logger import conversation_logger

settings.ensure_dirs()
logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))
logger = logging.getLogger("ai-platform")


# ═══════════════════════════════════════════════════════════════════════════════
# Ollama to Cloud Model Fallback Mapping
# ALWAYS use cloud equivalents - Ollama models are automatically converted to cloud
# Set PREFER_OLLAMA=1 to use local Ollama instead of cloud
# ═══════════════════════════════════════════════════════════════════════════════
PREFER_OLLAMA = os.environ.get("PREFER_OLLAMA", "").lower() in ("1", "true", "yes")

# All cloud fallbacks use "openai" since Pollinations only supports that model
OLLAMA_TO_CLOUD_FALLBACK: dict[str, str] = {
    # All models fallback to cloud:openai (Pollinations only supports openai model)
    "qwen3.5": "cloud:openai",
    "qwen3": "cloud:openai",
    "qwen2.5-coder": "cloud:openai",
    "qwen2.5": "cloud:openai",
    "deepseek-r1": "cloud:openai",
    "deepseek-coder": "cloud:openai",
    "deepseek-chat": "cloud:openai",
    "llama3.3": "cloud:openai",
    "llama3.2": "cloud:openai",
    "llama3.1": "cloud:openai",
    "llama3": "cloud:openai",
    "gemma4": "cloud:openai",
    "gemma3": "cloud:openai",
    "gemma2": "cloud:openai",
    "mistral-small": "cloud:openai",
    "mistral": "cloud:openai",
    "devstral": "cloud:openai",
    "phi4-mini": "cloud:openai",
    "phi4": "cloud:openai",
    "phi3": "cloud:openai",
    "default": "cloud:openai",
}


def get_cloud_fallback(ollama_model: str) -> str:
    """Get the best cloud model equivalent for an Ollama model."""
    # Strip ollama: prefix if present
    model_name = ollama_model.removeprefix("ollama:").split(":")[0]

    # Check for exact match
    if model_name in OLLAMA_TO_CLOUD_FALLBACK:
        return OLLAMA_TO_CLOUD_FALLBACK[model_name]

    # Check for partial match (e.g., "qwen2.5-coder-7b" -> "qwen2.5-coder")
    for key in OLLAMA_TO_CLOUD_FALLBACK:
        if model_name.startswith(key) or key in model_name:
            return OLLAMA_TO_CLOUD_FALLBACK[key]

    # Default fallback
    return OLLAMA_TO_CLOUD_FALLBACK["default"]


# ═══════════════════════════════════════════════════════════════════════════════
# P2-95/98: Enhanced Rate Limiter with Eviction
# ═══════════════════════════════════════════════════════════════════════════════

class RateLimiter:
    """Thread-safe rate limiter with sliding window and automatic eviction.

    Improvements over the original:
    - Automatic eviction of stale entries to prevent memory leaks (P2-98)
    - Support for proxy-aware client identification (P2-99)
    - Per-endpoint rate limiting support
    """

    MAX_CLIENTS = 10000  # Maximum tracked clients before forced cleanup

    def __init__(
        self,
        requests_per_minute: int = 60,
        burst_limit: int = 10,
        eviction_interval: int = 300,  # 5 minutes
    ):
        self.requests_per_minute = requests_per_minute
        self.burst_limit = burst_limit
        self.window_size = 60  # 1 minute
        self.eviction_interval = eviction_interval
        self._requests: dict[str, list[float]] = defaultdict(list)
        self._lock = Lock()
        self._last_eviction = time.time()

    def _evict_stale(self, now: float) -> None:
        """Remove stale entries to prevent memory growth."""
        if now - self._last_eviction < self.eviction_interval:
            return

        self._last_eviction = now
        window_start = now - self.window_size

        # Remove clients with no recent requests
        stale_clients = [
            client_id
            for client_id, timestamps in self._requests.items()
            if not timestamps or max(timestamps) < window_start
        ]

        for client_id in stale_clients:
            del self._requests[client_id]

        # Force cleanup if too many clients
        if len(self._requests) > self.MAX_CLIENTS:
            # Sort by last request time and remove oldest half
            sorted_clients = sorted(
                self._requests.items(),
                key=lambda x: max(x[1]) if x[1] else 0,
            )
            for client_id, _ in sorted_clients[: len(sorted_clients) // 2]:
                del self._requests[client_id]

    def is_allowed(self, client_id: str) -> bool:
        """Check if request is allowed for this client."""
        now = time.time()
        window_start = now - self.window_size

        with self._lock:
            # Periodic eviction
            self._evict_stale(now)

            # Clean old requests for this client
            self._requests[client_id] = [
                t for t in self._requests[client_id] if t > window_start
            ]

            # Check burst limit (requests in last 1 second)
            recent = [t for t in self._requests[client_id] if t > now - 1]
            if len(recent) >= self.burst_limit:
                return False

            # Check rate limit
            if len(self._requests[client_id]) >= self.requests_per_minute:
                return False

            # Allow request
            self._requests[client_id].append(now)
            return True

    # P1-13: Known trusted proxy IPs that can set X-Forwarded-For
    TRUSTED_PROXIES = frozenset([
        "127.0.0.1",
        "::1",
        "localhost",
        # Add your load balancer/reverse proxy IPs here
    ])

    def get_client_id(self, request: Request) -> str:
        """Get client identifier with proxy awareness (P2-99).

        P1-13: Only trust X-Forwarded-For from known proxies.
        """
        direct_client = request.client.host if request.client else "unknown"

        # P1-13: Only trust forwarded headers if request came from a trusted proxy
        if direct_client in self.TRUSTED_PROXIES:
            # Check X-Forwarded-For header for proxied requests
            forwarded = request.headers.get("X-Forwarded-For")
            if forwarded:
                # Take the first (original) IP
                return forwarded.split(",")[0].strip()

            # Check X-Real-IP header
            real_ip = request.headers.get("X-Real-IP")
            if real_ip:
                return real_ip

        # Fall back to direct client (or if not from trusted proxy)
        return direct_client


# ═══════════════════════════════════════════════════════════════════════════════
# P2-86/87: App State (replacing globals)
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class AppState:
    """Application state container (P2-86).

    This replaces global variables with proper app state management,
    enabling better isolation, testing, and concurrency control.
    """

    registry: ModelRegistry
    runtime_manager: RuntimeManager
    conversation_store: ConversationStore
    updater: AutoUpdater
    rate_limiter: RateLimiter

    # P1-12: Separate rate limiters for expensive endpoints
    download_rate_limiter: RateLimiter = field(
        default_factory=lambda: RateLimiter(requests_per_minute=10, burst_limit=2)
    )
    gcs_rate_limiter: RateLimiter = field(
        default_factory=lambda: RateLimiter(requests_per_minute=20, burst_limit=5)
    )
    terminal_rate_limiter: RateLimiter = field(
        default_factory=lambda: RateLimiter(requests_per_minute=5, burst_limit=2)
    )

    # P2-89/90: Runtime operation lock
    runtime_lock: RLock = field(default_factory=RLock)

    # GCS model manager for pull-upload-delete cycle
    gcs_manager: GCSModelManager | None = None

    # P2-101: Audit log
    audit_log: list[dict] = field(default_factory=list)
    max_audit_entries: int = 1000

    def log_audit(
        self,
        action: str,
        request_id: str,
        client_id: str,
        details: dict | None = None,
    ) -> None:
        """Log an audit event (P2-101)."""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "action": action,
            "request_id": request_id,
            "client_id": client_id,
            "details": details or {},
        }

        self.audit_log.append(entry)

        # Trim old entries
        if len(self.audit_log) > self.max_audit_entries:
            self.audit_log = self.audit_log[-self.max_audit_entries:]

        # Also log to standard logger
        logger.info(f"AUDIT: {action} | request={request_id} | client={client_id}")


def create_app_state() -> AppState:
    """Create isolated app state (P2-87)."""
    registry = ModelRegistry()

    # Initialize GCS manager for model pull-upload-delete cycle
    gcs_creds = settings.gcs_credentials_path if hasattr(settings, "gcs_credentials_path") else None
    try:
        gcs_manager = GCSModelManager(
            bucket_name="sage-ai-models",
            credentials_path=gcs_creds,
        )
    except Exception as e:
        logger.warning(f"Failed to initialize GCS manager: {e}")
        gcs_manager = None

    return AppState(
        registry=registry,
        runtime_manager=RuntimeManager(),
        conversation_store=ConversationStore(),
        updater=AutoUpdater(registry),
        rate_limiter=RateLimiter(requests_per_minute=120, burst_limit=20),
        gcs_manager=gcs_manager,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# P2-100: Request ID Middleware
# ═══════════════════════════════════════════════════════════════════════════════

async def add_request_id(request: Request, call_next: Callable) -> Response:
    """Add request ID to all requests (P2-100)."""
    request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())[:8]
    request.state.request_id = request_id

    response = await call_next(request)
    response.headers["X-Request-ID"] = request_id

    return response


# ═══════════════════════════════════════════════════════════════════════════════
# P2-102: Error Classes
# ═══════════════════════════════════════════════════════════════════════════════

class APIError(HTTPException):
    """Base API error with proper taxonomy (P2-102)."""

    def __init__(
        self,
        status_code: int,
        error_code: str,
        message: str,
        details: dict | None = None,
    ):
        super().__init__(
            status_code=status_code,
            detail={
                "error": error_code,
                "message": message,
                "details": details or {},
            },
        )


class NotFoundError(APIError):
    """Resource not found (404)."""

    def __init__(self, resource: str, identifier: str):
        super().__init__(
            status_code=404,
            error_code="NOT_FOUND",
            message=f"{resource} not found: {identifier}",
            details={"resource": resource, "identifier": identifier},
        )


class ValidationError(APIError):
    """Validation error (400)."""

    def __init__(self, message: str, details: dict | None = None):
        super().__init__(
            status_code=400,
            error_code="VALIDATION_ERROR",
            message=message,
            details=details,
        )


class ModelRuntimeError(APIError):
    """Runtime/model error (500). Named to avoid shadowing built-in RuntimeError."""

    def __init__(self, message: str, details: dict | None = None):
        super().__init__(
            status_code=500,
            error_code="RUNTIME_ERROR",
            message=message,
            details=details,
        )


class RateLimitError(APIError):
    """Rate limit exceeded (429)."""

    def __init__(self, retry_after: int = 60):
        super().__init__(
            status_code=429,
            error_code="RATE_LIMIT_EXCEEDED",
            message="Rate limit exceeded. Please try again later.",
            details={"retry_after_seconds": retry_after},
        )


# Global app state (will be set by create_app)
_app_state: AppState | None = None


def get_app_state() -> AppState:
    """Get the current app state."""
    global _app_state
    if _app_state is None:
        _app_state = create_app_state()
    return _app_state


# Legacy compatibility
rate_limiter = None  # Will be set by create_app

def _extract_bearer_token(authorization: str | None) -> str | None:
    if not authorization:
        return None
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token:
        return None
    return token


def _require_admin_token_strict(
    request: Request,
    authorization: str | None = Header(default=None),
    x_admin_token: str | None = Header(default=None),
) -> None:
    """Require admin token for protected endpoints - FAILS CLOSED.

    CRITICAL SECURITY: This function fails closed if admin_token is not configured.
    Use this for all admin endpoints to prevent fail-open security bypass.
    """
    expected = settings.admin_token.strip()

    # CRITICAL: Fail closed if admin token is not configured
    if not expected:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Admin authentication not configured - cannot authorize request",
        )

    provided = x_admin_token or _extract_bearer_token(authorization)
    if not provided or not secrets.compare_digest(provided, expected):
        # Log failed auth attempt (P2-101)
        state = get_app_state()
        state.log_audit(
            action="AUTH_FAILED",
            request_id=getattr(request.state, "request_id", "unknown"),
            client_id=state.rate_limiter.get_client_id(request),
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid admin token",
        )


def require_admin_token(
    request: Request,
    authorization: str | None = Header(default=None),
    x_admin_token: str | None = Header(default=None),
) -> None:
    """Require admin token for protected endpoints (legacy - fails open).

    DEPRECATED: Use _require_admin_token_strict instead for security.
    This version fails open if token is not configured - use only for backward compatibility.
    """
    expected = settings.admin_token.strip()
    if not expected:
        return
    provided = x_admin_token or _extract_bearer_token(authorization)
    if not provided or not secrets.compare_digest(provided, expected):
        # Log failed auth attempt (P2-101)
        state = get_app_state()
        state.log_audit(
            action="AUTH_FAILED",
            request_id=getattr(request.state, "request_id", "unknown"),
            client_id=state.rate_limiter.get_client_id(request),
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Admin token required",
        )


def check_rate_limit(request: Request) -> None:
    """Rate limit dependency with proxy awareness (P2-99)."""
    state = get_app_state()
    client_id = state.rate_limiter.get_client_id(request)

    if not state.rate_limiter.is_allowed(client_id):
        raise RateLimitError(retry_after=60)


# P1-12: Rate limit checkers for expensive endpoints
def check_download_rate_limit(request: Request) -> None:
    """Stricter rate limit for download endpoints (P1-12)."""
    state = get_app_state()
    client_id = state.download_rate_limiter.get_client_id(request)

    if not state.download_rate_limiter.is_allowed(client_id):
        raise RateLimitError(retry_after=300)  # 5 minute retry for downloads


def check_gcs_rate_limit(request: Request) -> None:
    """Rate limit for GCS operations (P1-12)."""
    state = get_app_state()
    client_id = state.gcs_rate_limiter.get_client_id(request)

    if not state.gcs_rate_limiter.is_allowed(client_id):
        raise RateLimitError(retry_after=120)  # 2 minute retry for GCS


def check_terminal_rate_limit(request: Request) -> None:
    """Rate limit for terminal WebSocket connections (P1-12)."""
    state = get_app_state()
    client_id = state.terminal_rate_limiter.get_client_id(request)

    if not state.terminal_rate_limiter.is_allowed(client_id):
        raise RateLimitError(retry_after=60)


# ═══════════════════════════════════════════════════════════════════════════════
# Path Parameter Validation (TDD Cycle)
# ═══════════════════════════════════════════════════════════════════════════════

import re


def validate_model_id_path(model_id: str) -> str:
    """Validate model_id path parameter against safe pattern."""
    try:
        validate_safe_id(model_id, "model_id")
    except ValueError as e:
        raise ValidationError(str(e))

    if not re.match(SAFE_MODEL_ID_PATTERN, model_id):
        raise ValidationError(f"Invalid model_id format: {model_id}")

    return model_id


def validate_conversation_id_path(conversation_id: str) -> str:
    """Validate conversation_id path parameter against safe pattern."""
    try:
        validate_safe_id(conversation_id, "conversation_id")
    except ValueError as e:
        raise ValidationError(str(e))

    if not re.match(SAFE_CONVERSATION_ID_PATTERN, conversation_id):
        raise ValidationError(f"Invalid conversation_id format: {conversation_id}")

    return conversation_id


def validate_model_name_path(model_name: str) -> str:
    """Validate model_name path parameter (for Ollama/GCS)."""
    if not model_name or not model_name.strip():
        raise ValidationError("model_name cannot be empty")

    # Check for path traversal
    if ".." in model_name or "/" in model_name or "\\" in model_name:
        raise ValidationError("model_name contains invalid characters")

    # Check for null bytes
    if "\x00" in model_name:
        raise ValidationError("model_name contains null byte")

    return model_name


# ═══════════════════════════════════════════════════════════════════════════════
# P2-88: Lifecycle Hooks
# ═══════════════════════════════════════════════════════════════════════════════

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Application lifespan manager (P2-88)."""
    global _app_state

    # Startup
    logger.info("Starting AI Platform API...")
    _app_state = create_app_state()

    # Log startup
    _app_state.log_audit(
        action="APP_STARTUP",
        request_id="system",
        client_id="system",
        details={"version": "3.0.0"},
    )

    logger.info("App state initialized")

    yield

    # Shutdown
    logger.info("Shutting down AI Platform API...")

    if _app_state:
        # Unload any loaded model
        if _app_state.runtime_manager.runtime is not None:
            try:
                _app_state.runtime_manager.unload()
            except Exception as e:
                logger.warning(f"Error unloading model during shutdown: {e}")

        # Log shutdown
        _app_state.log_audit(
            action="APP_SHUTDOWN",
            request_id="system",
            client_id="system",
        )

    logger.info("Shutdown complete")


def create_app() -> FastAPI:
    """Create FastAPI app with proper configuration (P2-87)."""
    fastapi_app = FastAPI(
        title="Local AI Platform",
        version="3.0.0",
        lifespan=lifespan,
    )

    # CORS middleware
    fastapi_app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Request ID middleware (P2-100)
    @fastapi_app.middleware("http")
    async def request_id_middleware(request: Request, call_next):
        return await add_request_id(request, call_next)

    return fastapi_app


app = create_app()


@app.get("/health")
def health():
    state = get_app_state()
    return {
        "ok": True,
        "version": "3.0.0",
        "loaded_model_id": state.runtime_manager.loaded_model_id,
        "loaded_runtime": state.runtime_manager.loaded_runtime,
    }


@app.get("/hardware")
def hardware():
    return detect_hardware_summary()


@app.get("/models")
def list_models():
    state = get_app_state()
    return {"ok": True, "models": [m.model_dump() for m in state.registry.list_models()]}


@app.get("/models/names")
def model_names():
    state = get_app_state()
    names = {m.model_id for m in state.registry.list_models()}
    for source in state.updater.list_sources():
        names.add(source.model_id)
    return {"ok": True, "names": sorted(names)}


@app.get("/models/{model_id}")
def get_model(model_id: str):
    # Validate path parameter (TDD Cycle)
    model_id = validate_model_id_path(model_id)
    state = get_app_state()
    try:
        record = state.registry.get_model(model_id)
    except KeyError:
        raise NotFoundError("Model", model_id)
    return {"ok": True, "model": record.model_dump()}


@app.post("/models/download")
def download_model(
    request: Request,
    req: DownloadModelReq,
    _admin: None = Depends(_require_admin_token_strict),
    _rate_limit: None = Depends(check_download_rate_limit),  # P1-12
):
    state = get_app_state()
    request_id = getattr(request.state, "request_id", "unknown")
    client_id = state.rate_limiter.get_client_id(request)

    # Audit log (P2-101)
    state.log_audit(
        action="MODEL_DOWNLOAD",
        request_id=request_id,
        client_id=client_id,
        details={"model_id": req.model_id if hasattr(req, "model_id") else "unknown"},
    )

    try:
        record = state.registry.download_and_register(req)
    except ValueError as exc:
        detail = str(exc)
        if "GitHub" in detail or "allowed" in detail:
            raise ValidationError(f"source not allowed: {detail}")
        raise ValidationError(detail)
    except Exception as exc:
        raise ModelRuntimeError(f"Download failed: {exc}")
    return {"ok": True, "model": record.model_dump()}


@app.post("/models/load")
def load_model(
    request: Request,
    req: LoadModelReq,
    _admin: None = Depends(_require_admin_token_strict),
):
    state = get_app_state()
    request_id = getattr(request.state, "request_id", "unknown")
    client_id = state.rate_limiter.get_client_id(request)

    model_id = req.model_id

    # Audit log (P2-101)
    state.log_audit(
        action="MODEL_LOAD",
        request_id=request_id,
        client_id=client_id,
        details={"model_id": model_id},
    )

    # Use lock to prevent concurrent load operations (P2-89, P2-90)
    with state.runtime_lock:
        # Check if it's an Ollama model (prefixed with "ollama:" or matches catalog)
        if model_id.startswith("ollama:"):
            # Default: Use cloud models (faster, no local setup required)
            # Set PREFER_OLLAMA=1 to use local Ollama instead
            if PREFER_OLLAMA:
                import httpx
                ollama_available = False
                try:
                    with httpx.Client(timeout=2) as client:
                        client.get("http://localhost:11434/api/tags")
                    ollama_available = True
                except (httpx.ConnectError, httpx.TimeoutException):
                    pass

                if ollama_available:
                    ollama_name = model_id.removeprefix("ollama:")
                    try:
                        state.runtime_manager.load("ollama", model_id, ollama_name, threads=None)
                    except Exception as exc:
                        raise ModelRuntimeError(f"Failed to load Ollama model: {exc}")
                    return {
                        "ok": True,
                        "loaded_model_id": state.runtime_manager.loaded_model_id,
                        "loaded_runtime": "ollama",
                        "threads": 0,
                    }
                else:
                    fallback_model = get_cloud_fallback(model_id)
                    cloud_name = fallback_model.removeprefix("cloud:")
                    try:
                        state.runtime_manager.load("cloud", fallback_model, cloud_name, threads=None)
                    except Exception as exc:
                        raise ModelRuntimeError(f"Failed to load fallback cloud model: {exc}")
                    return {
                        "ok": True,
                        "loaded_model_id": state.runtime_manager.loaded_model_id,
                        "loaded_runtime": "cloud",
                        "threads": 0,
                        "fallback": True,
                        "fallback_reason": "Ollama not running - using cloud model",
                        "original_model": model_id,
                    }
            else:
                # Always use cloud for Ollama models (default behavior)
                fallback_model = get_cloud_fallback(model_id)
                cloud_name = fallback_model.removeprefix("cloud:")
                try:
                    state.runtime_manager.load("cloud", fallback_model, cloud_name, threads=None)
                except Exception as exc:
                    raise ModelRuntimeError(f"Failed to load cloud model: {exc}")
                return {
                    "ok": True,
                    "loaded_model_id": state.runtime_manager.loaded_model_id,
                    "loaded_runtime": "cloud",
                    "threads": 0,
                    "cloud_fallback": True,
                    "original_model": model_id,
                }

        # Check if it's a cloud/free model
        if model_id.startswith("cloud:"):
            cloud_name = model_id.removeprefix("cloud:")
            try:
                state.runtime_manager.load("cloud", model_id, cloud_name, threads=None)
            except Exception as exc:
                raise ModelRuntimeError(f"Failed to load cloud model: {exc}")
            return {
                "ok": True,
                "loaded_model_id": state.runtime_manager.loaded_model_id,
                "loaded_runtime": "cloud",
                "threads": 0,
            }

        # Standard GGUF/local model
        try:
            record = state.registry.get_model(model_id)
        except KeyError:
            raise NotFoundError("Model", model_id)

        try:
            active = record.active()
            threads = (
                req.threads
                or runtime_defaults.default_threads
                or detect_hardware_summary().get("cpu_threads", 1)
            )
            state.runtime_manager.load(
                record.runtime, model_id, active.file_path, threads=threads
            )
        except Exception as exc:
            raise ModelRuntimeError(f"Failed to load model: {exc}")

        return {
            "ok": True,
            "loaded_model_id": state.runtime_manager.loaded_model_id,
            "loaded_runtime": state.runtime_manager.loaded_runtime,
            "threads": threads,
        }


@app.post("/chat")
def chat(request: Request, req: ChatReq, _rate_limit: None = Depends(check_rate_limit)):
    """Chat endpoint with proper SSE error handling (P2-91)."""
    state = get_app_state()
    request_id = getattr(request.state, "request_id", "unknown")

    # Auto-load model if not loaded or different model requested
    if state.runtime_manager.runtime is None or state.runtime_manager.loaded_model_id != req.model_id:
        model_id = req.model_id

        # Use lock for model loading (P2-89)
        with state.runtime_lock:
            try:
                if model_id.startswith("ollama:"):
                    # Default: Use cloud models (faster, no local setup required)
                    # Set PREFER_OLLAMA=1 to use local Ollama instead
                    if PREFER_OLLAMA:
                        import httpx
                        ollama_available = False
                        try:
                            with httpx.Client(timeout=2) as client:
                                client.get("http://localhost:11434/api/tags")
                            ollama_available = True
                        except (httpx.ConnectError, httpx.TimeoutException):
                            pass

                        if ollama_available:
                            state.runtime_manager.load("ollama", model_id, model_id.removeprefix("ollama:"), threads=None)
                        else:
                            fallback_model = get_cloud_fallback(model_id)
                            cloud_name = fallback_model.removeprefix("cloud:")
                            state.runtime_manager.load("cloud", fallback_model, cloud_name, threads=None)
                            logger.info(f"Ollama not running - using cloud fallback: {model_id} -> {fallback_model}")
                    else:
                        # Always use cloud for Ollama models (default behavior)
                        fallback_model = get_cloud_fallback(model_id)
                        cloud_name = fallback_model.removeprefix("cloud:")
                        state.runtime_manager.load("cloud", fallback_model, cloud_name, threads=None)
                        logger.info(f"Using cloud model: {model_id} -> {fallback_model}")
                elif model_id.startswith("cloud:"):
                    state.runtime_manager.load("cloud", model_id, model_id.removeprefix("cloud:"), threads=None)
                else:
                    # Try loading as registered GGUF model
                    try:
                        record = state.registry.get_model(model_id)
                        active = record.active()
                        threads = detect_hardware_summary().get("cpu_threads", 1)
                        state.runtime_manager.load(record.runtime, model_id, active.file_path, threads=threads)
                    except KeyError:
                        raise NotFoundError("Model", model_id)
            except (NotFoundError, ValidationError, RuntimeError):
                raise
            except Exception as exc:
                raise ModelRuntimeError(f"Failed to load model: {exc}")

    conv_id = req.conversation_id

    # Process messages with file attachments
    processed_messages = []
    for msg in req.messages:
        content = msg.content

        # If message has attachments, expand file content into context
        if hasattr(msg, 'attachments') and msg.attachments:
            attachment_contents = []
            for att in msg.attachments:
                try:
                    file_content = file_store.get_content_for_chat(att.file_id)
                    attachment_contents.append(file_content)
                except KeyError:
                    logger.warning(f"File not found for attachment: {att.file_id}")

            if attachment_contents:
                content = content + "\n\n" + "\n\n".join(attachment_contents)

        processed_messages.append(ChatMessage(role=msg.role, content=content))

        # Log user input
        if conv_id and msg.role == "user":
            attachments_data = None
            if hasattr(msg, 'attachments') and msg.attachments:
                attachments_data = [
                    {"file_id": a.file_id, "filename": a.filename}
                    for a in msg.attachments
                ]
            conversation_logger.log_input(
                conversation_id=conv_id,
                content=msg.content,
                attachments=attachments_data
            )

    if conv_id:
        for msg in req.messages:
            state.conversation_store.append_message(conv_id, msg.role, msg.content)

    messages = processed_messages

    def stream_with_error_handling():
        """SSE stream generator with structured error events (P2-91)."""
        chunks = []
        error_occurred = False

        try:
            # Send initial step indicator
            yield f"data: {json.dumps({'step': 'thinking', 'message': 'Processing your message...'})}\n\n"
            yield f"data: {json.dumps({'step': 'generating', 'message': 'Generating response...'})}\n\n"

            for token in state.runtime_manager.runtime.stream_chat(
                messages,
                temperature=req.temperature,
                max_tokens=req.max_tokens,
            ):
                chunks.append(token)
                yield f"data: {json.dumps({'token': token})}\n\n"

            final = "".join(chunks).strip()
            if conv_id:
                state.conversation_store.append_message(conv_id, "assistant", final)
                # Log AI output
                conversation_logger.log_output(
                    conversation_id=conv_id,
                    content=final,
                    model_id=req.model_id
                )

            yield f"data: {json.dumps({'step': 'complete', 'message': 'Done'})}\n\n"
            yield f"data: {json.dumps({'done': True, 'conversation_id': conv_id})}\n\n"

        except Exception as exc:
            # P2-91: Structured error event for SSE failures
            error_occurred = True
            error_event = {
                "error": True,
                "error_code": "STREAM_ERROR",
                "message": str(exc),
                "request_id": request_id,
                "partial_response": "".join(chunks) if chunks else None,
            }
            yield f"data: {json.dumps(error_event)}\n\n"

            # Log the error
            logger.error(f"Stream error in request {request_id}: {exc}")

        finally:
            if not error_occurred:
                # Log successful completion
                state.log_audit(
                    action="CHAT_COMPLETE",
                    request_id=request_id,
                    client_id=state.rate_limiter.get_client_id(request),
                    details={"model_id": req.model_id, "tokens": len(chunks)},
                )

    if req.stream:
        return StreamingResponse(stream_with_error_handling(), media_type="text/event-stream")

    # Non-streaming response
    try:
        text = state.runtime_manager.runtime.chat(
            messages,
            temperature=req.temperature,
            max_tokens=req.max_tokens,
        )
        if conv_id:
            state.conversation_store.append_message(conv_id, "assistant", text)
            # Log AI output
            conversation_logger.log_output(
                conversation_id=conv_id,
                content=text,
                model_id=req.model_id
            )
        return {"ok": True, "output": text, "conversation_id": conv_id}
    except Exception as exc:
        raise ModelRuntimeError(f"Chat failed: {exc}")


@app.post("/conversations")
def create_conversation(req: CreateConversationReq):
    state = get_app_state()
    conversation = state.conversation_store.create(req.title)
    return {"ok": True, "conversation": conversation}


@app.get("/conversations")
def list_conversations():
    state = get_app_state()
    return {"ok": True, "conversations": state.conversation_store.list_all()}


@app.get("/conversations/{conversation_id}")
def get_conversation(conversation_id: str):
    # Validate path parameter (TDD Cycle)
    conversation_id = validate_conversation_id_path(conversation_id)
    state = get_app_state()
    try:
        conversation = state.conversation_store.get(conversation_id)
    except KeyError:
        raise NotFoundError("Conversation", conversation_id)
    return {"ok": True, "conversation": conversation}


@app.delete("/conversations/{conversation_id}")
def delete_conversation(conversation_id: str):
    # Validate path parameter (TDD Cycle)
    conversation_id = validate_conversation_id_path(conversation_id)
    state = get_app_state()
    state.conversation_store.delete(conversation_id)
    # Also delete conversation logs
    conversation_logger.delete(conversation_id)
    return {"ok": True}


@app.get("/conversations/{conversation_id}/logs")
def get_conversation_logs(conversation_id: str):
    """Get input/output logs for a conversation."""
    conversation_id = validate_conversation_id_path(conversation_id)
    return {
        "ok": True,
        "inputs": conversation_logger.get_inputs(conversation_id),
        "outputs": conversation_logger.get_outputs(conversation_id),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# File Upload/Download Endpoints
# ═══════════════════════════════════════════════════════════════════════════════


@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    """Upload a file for use in chat."""
    # Read file content
    content = await file.read()

    # Validate file size
    if len(content) == 0:
        raise HTTPException(status_code=400, detail="File cannot be empty")

    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=413,
            detail=f"File exceeds maximum size of {MAX_FILE_SIZE // (1024*1024)}MB"
        )

    # Determine MIME type
    mime_type = file.content_type or "application/octet-stream"

    try:
        file_id = file_store.save(
            content=content,
            filename=file.filename or "unnamed",
            mime_type=mime_type,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    metadata = file_store.get_metadata(file_id)

    return {
        "ok": True,
        "file_id": file_id,
        "filename": metadata["filename"],
        "mime_type": metadata["mime_type"],
        "size_bytes": metadata["size_bytes"],
        "content_preview": metadata.get("content_preview"),
    }


@app.get("/files/{file_id}")
def download_file(file_id: str):
    """Download a file by ID."""
    # Validate file_id
    try:
        validate_safe_id(file_id, "file_id")
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid file ID")

    try:
        file_data = file_store.get(file_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="File not found")

    return Response(
        content=file_data["content"],
        media_type=file_data["mime_type"],
        headers={
            "Content-Disposition": f'attachment; filename="{file_data["filename"]}"'
        },
    )


@app.get("/files")
def list_files():
    """List all uploaded files."""
    return {"ok": True, "files": file_store.list_all()}


@app.delete("/files/{file_id}")
def delete_file(file_id: str):
    """Delete a file by ID."""
    try:
        validate_safe_id(file_id, "file_id")
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid file ID")

    file_store.delete(file_id)
    return {"ok": True}


@app.post("/paste")
def submit_large_text(req: LargeTextContent):
    """Submit large text content to be treated as a file."""
    content_bytes = req.content.encode("utf-8")

    # Check if small enough to handle inline
    if len(content_bytes) < LARGE_TEXT_THRESHOLD:
        return {
            "ok": True,
            "inline": True,
            "content": req.content,
            "size_bytes": len(content_bytes),
            "language": req.language,
        }

    # Save as file
    mime_type = "text/plain"
    if req.language:
        # Map language to MIME type
        lang_mime_map = {
            "python": "text/x-python",
            "py": "text/x-python",
            "javascript": "text/javascript",
            "js": "text/javascript",
            "typescript": "text/typescript",
            "ts": "text/typescript",
            "java": "text/x-java",
            "c": "text/x-c",
            "cpp": "text/x-c++",
            "go": "text/x-go",
            "rust": "text/x-rust",
            "json": "application/json",
            "yaml": "application/x-yaml",
            "yml": "application/x-yaml",
            "html": "text/html",
            "css": "text/css",
            "markdown": "text/markdown",
            "md": "text/markdown",
            "sh": "application/x-sh",
            "bash": "application/x-sh",
        }
        mime_type = lang_mime_map.get(req.language.lower(), "text/plain")

    try:
        file_id = file_store.save(
            content=content_bytes,
            filename=req.filename,
            mime_type=mime_type,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    metadata = file_store.get_metadata(file_id)

    return {
        "ok": True,
        "inline": False,
        "file_id": file_id,
        "filename": metadata["filename"],
        "size_bytes": metadata["size_bytes"],
        "language": req.language,
    }


@app.get("/sources")
def list_sources():
    state = get_app_state()
    return {"ok": True, "sources": [s.__dict__ for s in state.updater.list_sources()]}


@app.post("/sources/add")
def add_source(
    request: Request,
    req: AddSourceReq,
    _admin: None = Depends(_require_admin_token_strict),
):
    state = get_app_state()

    # Audit log
    state.log_audit(
        action="SOURCE_ADD",
        request_id=getattr(request.state, "request_id", "unknown"),
        client_id=state.rate_limiter.get_client_id(request),
        details={"model_id": req.model_id, "repo_url": req.repo_url},
    )

    try:
        source = state.updater.add_source(
            repo_url=req.repo_url,
            model_id=req.model_id,
            runtime=req.runtime,
            asset_pattern=req.asset_pattern,
            license=req.license,
        )
    except ValueError as exc:
        raise ValidationError(str(exc))
    return {"ok": True, "source": source.__dict__}


@app.delete("/sources/{model_id}")
def remove_source(
    request: Request,
    model_id: str,
    _admin: None = Depends(_require_admin_token_strict),
):
    state = get_app_state()

    # Audit log
    state.log_audit(
        action="SOURCE_REMOVE",
        request_id=getattr(request.state, "request_id", "unknown"),
        client_id=state.rate_limiter.get_client_id(request),
        details={"model_id": model_id},
    )

    state.updater.remove_source(model_id)
    return {"ok": True}


@app.get("/catalog")
def catalog(backend: str | None = None):
    """List models from the Sage catalog.

    Args:
        backend: Filter by backend type (gguf, ollama, or all). Defaults to "gguf".

    Tries the remote GCS catalog first for auto-updated models,
    falls back to the hardcoded catalog.
    """
    all_models = get_full_catalog()

    # Filter by backend if specified
    if backend and backend != "all":
        filtered_models = [m for m in all_models if m.backend == backend]
    elif backend == "all":
        filtered_models = all_models
    else:
        # Default to GGUF for backwards compatibility
        filtered_models = [m for m in all_models if m.backend == "gguf"]

    return {
        "ok": True,
        "models": [
            {
                "model_id": m.name,
                "name": m.display_name,
                "description": m.description,
                "params": m.params,
                "size_gb": m.size_gb,
                "family": m.family,
                "filename": m.filename,
                "url": m.url,
                "default": m.default,
                "backend": m.backend,
                "category": m.category,
                "tags": list(m.tags) if m.tags else [],
            }
            for m in filtered_models
        ],
        "total": len(filtered_models),
    }


@app.get("/catalog/all")
def catalog_all(category: str | None = None, search: str | None = None):
    """List ALL models from the Sage catalog (GGUF + Ollama + Cloud).

    Args:
        category: Filter by category (coding, reasoning, general, vision, small, embedding)
        search: Search models by name or description
    """
    all_models = get_full_catalog()

    if search:
        q = search.lower()
        results = [
            m for m in all_models
            if q in m.name.lower() or q in m.display_name.lower()
            or q in m.description.lower() or q in m.category.lower()
        ]
    elif category:
        results = [m for m in all_models if m.category == category]
    else:
        results = all_models

    return {
        "ok": True,
        "models": [
            {
                "model_id": m.name,
                "name": m.display_name,
                "description": m.description,
                "params": m.params,
                "size_gb": m.size_gb,
                "family": m.family,
                "filename": m.filename,
                "url": m.url,
                "default": m.default,
                "backend": m.backend,
                "category": m.category,
                "tags": list(m.tags) if m.tags else [],
            }
            for m in results
        ],
        "total": len(results),
    }


@app.get("/catalog/recommended")
def catalog_recommended():
    return {"ok": True, "models": get_recommended_models()}


@app.get("/catalog/fits-ram")
def catalog_fits_ram(max_gb: float):
    return {"ok": True, "models": filter_by_ram(max_gb)}


@app.get("/ollama/catalog")
def ollama_catalog(category: str | None = None, search: str | None = None):
    """List all Ollama models available to pull.

    Uses remote GCS catalog for auto-updated model list.
    """
    all_models = get_full_catalog()
    ollama_models = [m for m in all_models if m.backend == "ollama"]

    if search:
        q = search.lower()
        results = [
            m for m in ollama_models
            if q in m.name.lower() or q in m.display_name.lower()
            or q in m.description.lower() or q in m.category.lower()
        ]
    elif category:
        results = [m for m in ollama_models if m.category == category]
    else:
        results = ollama_models
    return {
        "ok": True,
        "models": [
            {
                "name": m.name,
                "display_name": m.display_name,
                "sizes": m.params,
                "tags": list(m.tags),
                "description": m.description,
                "pulls": "",
                "category": m.category,
            }
            for m in results
        ],
    }


@app.get("/ollama/status")
def ollama_status():
    """Check if Ollama is running and list pulled models."""
    import httpx
    try:
        with httpx.Client(timeout=3) as client:
            resp = client.get("http://localhost:11434/api/tags")
            resp.raise_for_status()
            data = resp.json()
            models = [
                {"name": m["name"], "size": m.get("size", 0), "modified": m.get("modified_at", "")}
                for m in data.get("models", [])
            ]
            return {"ok": True, "running": True, "models": models}
    except Exception:
        return {"ok": True, "running": False, "models": []}


@app.get("/free-models")
def free_models():
    """List free cloud models that work without any setup.

    All models available via Pollinations AI (https://pollinations.ai).
    API key optional but recommended for higher rate limits.
    """
    return {
        "ok": True,
        "models": [
            # High capacity models (>1000 responses per pollen)
            {"model_id": "cloud:qwen-safety", "name": "Qwen3Guard 8B (Safety)", "provider": "pollinations"},
            {"model_id": "cloud:nova-fast", "name": "Nova Micro (Fast)", "provider": "pollinations"},
            {"model_id": "cloud:mistral", "name": "Mistral Small 3.2 (Vision)", "provider": "pollinations"},
            {"model_id": "cloud:gemini-fast", "name": "Gemini 2.5 Flash Lite", "provider": "pollinations"},
            {"model_id": "cloud:nova", "name": "Nova 2 Lite (Reasoning)", "provider": "pollinations"},
            {"model_id": "cloud:grok", "name": "Grok 4.1 Fast", "provider": "pollinations"},
            {"model_id": "cloud:openai", "name": "GPT-5.4 Nano (Vision)", "provider": "pollinations"},
            {"model_id": "cloud:gemini-search", "name": "Gemini 2.5 Search", "provider": "pollinations"},
            {"model_id": "cloud:qwen-coder", "name": "Qwen3 Coder 30B", "provider": "pollinations"},
            {"model_id": "cloud:perplexity-fast", "name": "Perplexity Sonar (Search)", "provider": "pollinations"},
            {"model_id": "cloud:openai-fast", "name": "GPT-5 Nano (Fast)", "provider": "pollinations"},
            # Medium capacity models (100-500 responses per pollen)
            {"model_id": "cloud:qwen-vision", "name": "Qwen3 VL Thinking", "provider": "pollinations"},
            {"model_id": "cloud:minimax", "name": "MiniMax M2.7 (Reasoning)", "provider": "pollinations"},
            {"model_id": "cloud:openai-audio", "name": "GPT Audio Mini", "provider": "pollinations"},
            {"model_id": "cloud:deepseek", "name": "DeepSeek V3.2 (Reasoning)", "provider": "pollinations"},
            {"model_id": "cloud:midijourney", "name": "MIDIjourney (Music)", "provider": "pollinations"},
            {"model_id": "cloud:claude-fast", "name": "Claude Haiku 4.5", "provider": "pollinations"},
            {"model_id": "cloud:kimi", "name": "Kimi K2.5 (Vision)", "provider": "pollinations"},
        ],
    }


@app.get("/ollama/recommended")
def ollama_recommended():
    """Return recommended Ollama models for Sage."""
    results = get_recommended_ollama_models()
    return {
        "ok": True,
        "models": [
            {
                "name": m.name,
                "display_name": m.display_name,
                "sizes": m.params,
                "tags": list(m.tags),
                "description": m.description,
                "category": m.category,
            }
            for m in results
        ],
    }


# ═══════════════════════════════════════════════════════════════════════════════
# GCS Model Management - Pull/Upload/Delete Cycle
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/gcs/status")
def gcs_status():
    """Check GCS manager status and Ollama availability."""
    state = get_app_state()

    gcs_available = state.gcs_manager is not None
    ollama_running = False

    if gcs_available:
        ollama_running = state.gcs_manager.ollama.is_running()

    return {
        "ok": True,
        "gcs_available": gcs_available,
        "ollama_running": ollama_running,
    }


@app.get("/gcs/models")
def gcs_list_models():
    """List all models available in GCS."""
    state = get_app_state()

    if not state.gcs_manager:
        raise ModelRuntimeError("GCS manager not initialized")

    try:
        models = state.gcs_manager.list_gcs_models()
        return {
            "ok": True,
            "models": [
                {
                    "name": m.name,
                    "display_name": m.display_name,
                    "filename": m.filename,
                    "url": m.url,
                    "size_gb": m.size_gb,
                    "params": m.params,
                    "family": m.family,
                    "description": m.description,
                    "category": m.category,
                    "tags": m.tags,
                    "checksum": m.checksum,
                    "uploaded_at": m.uploaded_at,
                    "source": m.source,
                }
                for m in models
            ],
        }
    except Exception as exc:
        raise ModelRuntimeError(f"Failed to list GCS models: {exc}")


@app.get("/gcs/models/{model_name}")
def gcs_get_model(model_name: str):
    """Get info about a specific model in GCS."""
    # Validate path parameter (TDD Cycle)
    model_name = validate_model_name_path(model_name)
    state = get_app_state()

    if not state.gcs_manager:
        raise ModelRuntimeError("GCS manager not initialized")

    model = state.gcs_manager.get_model_info(model_name)
    if not model:
        raise NotFoundError("Model", model_name)

    return {
        "ok": True,
        "model": {
            "name": model.name,
            "display_name": model.display_name,
            "filename": model.filename,
            "url": model.url,
            "size_gb": model.size_gb,
            "params": model.params,
            "family": model.family,
            "description": model.description,
            "category": model.category,
            "tags": model.tags,
            "checksum": model.checksum,
            "uploaded_at": model.uploaded_at,
            "source": model.source,
        },
    }


@app.post("/gcs/pull")
def gcs_pull_upload(
    request: Request,
    ollama_model: str,
    display_name: str | None = None,
    description: str | None = None,
    family: str | None = None,
    category: str = "general",
    delete_after_upload: bool = False,
    _admin: None = Depends(_require_admin_token_strict),
    _rate_limit: None = Depends(check_gcs_rate_limit),  # P1-12
):
    """Pull a model from Ollama, convert to GGUF, and upload to GCS.

    This is the main endpoint for the pull-upload-delete cycle.

    Args:
        ollama_model: Ollama model name (e.g., "qwen2.5:7b")
        display_name: Human-readable name (optional)
        description: Model description (optional)
        family: Model family (optional)
        category: Category (coding, reasoning, general, etc.)
        delete_after_upload: Whether to delete from Ollama after upload
    """
    state = get_app_state()
    request_id = getattr(request.state, "request_id", "unknown")
    client_id = state.rate_limiter.get_client_id(request)

    if not state.gcs_manager:
        raise ModelRuntimeError("GCS manager not initialized")

    # Audit log
    state.log_audit(
        action="GCS_PULL_UPLOAD",
        request_id=request_id,
        client_id=client_id,
        details={
            "ollama_model": ollama_model,
            "delete_after_upload": delete_after_upload,
        },
    )

    try:
        success, message = state.gcs_manager.pull_convert_upload(
            ollama_model=ollama_model,
            display_name=display_name,
            description=description,
            family=family,
            category=category,
            delete_after_upload=delete_after_upload,
        )

        return {
            "ok": success,
            "message": message,
        }
    except Exception as exc:
        raise ModelRuntimeError(f"Pull-upload failed: {exc}")


@app.post("/gcs/download/{model_name}")
def gcs_download(
    request: Request,
    model_name: str,
    _admin: None = Depends(_require_admin_token_strict),
    _rate_limit: None = Depends(check_gcs_rate_limit),  # P1-12
):
    """Download a model from GCS to local storage."""
    state = get_app_state()
    request_id = getattr(request.state, "request_id", "unknown")
    client_id = state.rate_limiter.get_client_id(request)

    if not state.gcs_manager:
        raise ModelRuntimeError("GCS manager not initialized")

    # Audit log
    state.log_audit(
        action="GCS_DOWNLOAD",
        request_id=request_id,
        client_id=client_id,
        details={"model_name": model_name},
    )

    try:
        path = state.gcs_manager.download_from_gcs(model_name)
        if path:
            return {
                "ok": True,
                "path": str(path),
                "message": f"Downloaded {model_name} to {path}",
            }
        else:
            raise NotFoundError("Model", model_name)
    except NotFoundError:
        raise
    except Exception as exc:
        raise ModelRuntimeError(f"Download failed: {exc}")


@app.delete("/gcs/models/{model_name}")
def gcs_delete(
    request: Request,
    model_name: str,
    _admin: None = Depends(_require_admin_token_strict),
):
    """Delete a model from GCS."""
    # Validate path parameter (TDD Cycle)
    model_name = validate_model_name_path(model_name)
    state = get_app_state()
    request_id = getattr(request.state, "request_id", "unknown")
    client_id = state.rate_limiter.get_client_id(request)

    if not state.gcs_manager:
        raise ModelRuntimeError("GCS manager not initialized")

    # Get filename from model info first
    model = state.gcs_manager.get_model_info(model_name)
    if not model:
        raise NotFoundError("Model", model_name)

    # Audit log
    state.log_audit(
        action="GCS_DELETE",
        request_id=request_id,
        client_id=client_id,
        details={"model_name": model_name, "filename": model.filename},
    )

    try:
        success = state.gcs_manager.delete_from_gcs(model.filename)
        return {
            "ok": success,
            "message": f"Deleted {model_name}" if success else f"Failed to delete {model_name}",
        }
    except Exception as exc:
        raise ModelRuntimeError(f"Delete failed: {exc}")


@app.post("/gcs/sync")
def gcs_sync(
    request: Request,
    delete_after_upload: bool = False,
    _admin: None = Depends(_require_admin_token_strict),
):
    """Sync all pulled Ollama models to GCS.

    This pulls all currently pulled Ollama models and uploads them to GCS.
    """
    state = get_app_state()
    request_id = getattr(request.state, "request_id", "unknown")
    client_id = state.rate_limiter.get_client_id(request)

    if not state.gcs_manager:
        raise ModelRuntimeError("GCS manager not initialized")

    # Audit log
    state.log_audit(
        action="GCS_SYNC",
        request_id=request_id,
        client_id=client_id,
        details={"delete_after_upload": delete_after_upload},
    )

    try:
        results = state.gcs_manager.sync_ollama_to_gcs(
            models=None,  # All pulled models
            delete_after_upload=delete_after_upload,
        )

        return {
            "ok": True,
            "results": {
                model: {"success": success, "message": message}
                for model, (success, message) in results.items()
            },
        }
    except Exception as exc:
        raise ModelRuntimeError(f"Sync failed: {exc}")


@app.get("/ollama/pulled")
def ollama_pulled():
    """List all models currently pulled in Ollama."""
    state = get_app_state()

    if not state.gcs_manager:
        # Fall back to direct Ollama API call
        client = OllamaClient()
        if not client.is_running():
            return {"ok": True, "running": False, "models": []}

        models = client.list_models()
        client.close()
    else:
        if not state.gcs_manager.ollama.is_running():
            return {"ok": True, "running": False, "models": []}

        models = state.gcs_manager.ollama.list_models()

    return {
        "ok": True,
        "running": True,
        "models": [
            {
                "name": m.get("name", ""),
                "size": m.get("size", 0),
                "size_gb": m.get("size", 0) / 1e9,
                "modified": m.get("modified_at", ""),
            }
            for m in models
        ],
    }


@app.delete("/ollama/models/{model_name}")
def ollama_delete(
    request: Request,
    model_name: str,
    _admin: None = Depends(_require_admin_token_strict),
):
    """Delete a model from Ollama."""
    # Validate path parameter (TDD Cycle)
    model_name = validate_model_name_path(model_name)
    state = get_app_state()
    request_id = getattr(request.state, "request_id", "unknown")
    client_id = state.rate_limiter.get_client_id(request)

    # Audit log
    state.log_audit(
        action="OLLAMA_DELETE",
        request_id=request_id,
        client_id=client_id,
        details={"model_name": model_name},
    )

    if state.gcs_manager:
        success = state.gcs_manager.delete_from_ollama(model_name)
    else:
        client = OllamaClient()
        success = client.delete_model(model_name)
        client.close()

    return {
        "ok": success,
        "message": f"Deleted {model_name} from Ollama" if success else f"Failed to delete {model_name}",
    }


# ═══════════════════════════════════════════════════════════════════════════════
# WebSocket Terminal Endpoint (WebGL-accelerated xterm.js)
# ═══════════════════════════════════════════════════════════════════════════════


@app.websocket("/ws/terminal")
async def websocket_terminal(websocket: WebSocket):
    """WebSocket endpoint for WebGL terminal running sage-ai-cli."""
    await terminal_websocket_handler(websocket)


# ═══════════════════════════════════════════════════════════════════════════════
# CLI Auto-Update Endpoints
# ═══════════════════════════════════════════════════════════════════════════════


@app.get("/api/cli/check-update")
def check_cli_update():
    """Check if a sage-ai-cli update is available."""
    return get_cli_update_info()


@app.post("/api/cli/apply-update")
def apply_update_endpoint(_admin: None = Depends(_require_admin_token_strict)):
    """Apply sage-ai-cli update (requires admin token)."""
    return apply_cli_update()


_frontend_dist = Path(__file__).resolve().parent.parent / "frontend" / "dist"
if _frontend_dist.is_dir():
    app.mount("/", StaticFiles(directory=str(_frontend_dist), html=True), name="frontend")


def main():
    # P1-14: Use settings for host/port instead of hardcoded values
    uvicorn.run(app, host=settings.host, port=settings.port)


if __name__ == "__main__":
    main()
