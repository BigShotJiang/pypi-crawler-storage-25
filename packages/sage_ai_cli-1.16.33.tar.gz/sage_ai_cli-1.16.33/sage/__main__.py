"""Entry point for running sage as a module: python -m sage"""

from sage.main import app

if __name__ == "__main__":
    app()
