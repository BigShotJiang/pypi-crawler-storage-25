"""Shared CLI update helpers for SAGE.

This module centralizes version checks and self-update behavior so the
terminal backend, standard CLI, and REPL all use the same logic.
"""

from __future__ import annotations

from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError, version as package_version
from pathlib import Path
import logging
import shutil
import subprocess
import sys
import threading
import time

from sage import __version__

logger = logging.getLogger("sage.updater")


@dataclass
class CLIVersion:
    """Version information for the installed CLI."""

    current: str
    latest: str
    update_available: bool


@dataclass
class CLIUpdateResult:
    """Outcome of an update check or update attempt."""

    ok: bool
    updated: bool
    attempted: bool
    current: str
    latest: str
    message: str


def build_sage_run_command() -> list[str]:
    """Build the most reliable `sage run` invocation for the current env."""

    executable_dir = Path(sys.executable).resolve().parent
    for name in ("sage", "sage.exe"):
        candidate = executable_dir / name
        if candidate.exists():
            return [str(candidate), "run"]

    sage_cmd = shutil.which("sage")
    if sage_cmd:
        return [sage_cmd, "run"]

    return [
        sys.executable,
        "-c",
        "import sys; sys.argv = ['sage', 'run']; from sage.main import app; app()",
    ]


class CLIAutoUpdater:
    """Handles update checks and in-place upgrades for sage-ai-cli."""

    PACKAGE_NAME = "sage-ai-cli"

    def __init__(self) -> None:
        self._cache_timeout = 300
        self._last_check = 0.0
        self._cached_version: CLIVersion | None = None
        self._lock = threading.Lock()

    def get_current_version(self) -> str:
        """Get the installed package version for the active Python env."""

        try:
            return package_version(self.PACKAGE_NAME)
        except PackageNotFoundError:
            return __version__
        except Exception as exc:
            logger.warning("Failed to read installed SAGE version: %s", exc)
            return __version__

    def get_latest_version(self) -> str:
        """Check pip index for the newest published version."""

        try:
            result = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "pip",
                    "index",
                    "versions",
                    self.PACKAGE_NAME,
                ],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode == 0 and "(" in result.stdout:
                return result.stdout.split("(", 1)[1].split(")", 1)[0].strip()
        except Exception as exc:
            logger.warning("Failed to check latest SAGE version: %s", exc)
        return self.get_current_version()

    def check_for_update(self, force: bool = False) -> CLIVersion:
        """Return current and latest version information."""

        now = time.time()
        if not force and self._cached_version and (now - self._last_check) < self._cache_timeout:
            return self._cached_version

        current = self.get_current_version()
        latest = self.get_latest_version()
        update_available = self._compare_versions(current, latest) < 0

        # Check git if update not found on pip
        if not update_available:
            root_dir = Path(__file__).resolve().parent.parent.parent.parent
            if (root_dir / ".git").exists():
                try:
                    subprocess.run(
                        ["git", "fetch"],
                        cwd=str(root_dir),
                        capture_output=True,
                        timeout=30,
                    )
                    result = subprocess.run(
                        ["git", "status", "-uno"],
                        cwd=str(root_dir),
                        capture_output=True,
                        text=True,
                        timeout=30,
                    )
                    if "Your branch is behind" in result.stdout:
                        update_available = True
                        latest = f"{current} (git update available)"
                except Exception:
                    pass

        version = CLIVersion(
            current=current,
            latest=latest,
            update_available=update_available,
        )
        self._cached_version = version
        self._last_check = now
        return version

    def apply_update(self) -> bool:
        """Upgrade SAGE in the current environment (via git or pip)."""

        with self._lock:
            # 1. Try git update if running from a git clone
            root_dir = Path(__file__).resolve().parent.parent.parent.parent
            if (root_dir / ".git").exists():
                try:
                    logger.info("Detected git repository, attempting git pull...")
                    result = subprocess.run(
                        ["git", "pull"],
                        cwd=str(root_dir),
                        capture_output=True,
                        text=True,
                        timeout=60,
                    )
                    if result.returncode == 0:
                        if "Already up to date" in result.stdout:
                            logger.info("SAGE is already up to date via git.")
                        else:
                            logger.info("Successfully updated SAGE via git pull.")
                        return True
                    logger.warning("git pull failed: %s", result.stderr.strip())
                except Exception as exc:
                    logger.warning("Failed to update via git: %s", exc)

            # 2. Fallback to pip upgrade
            try:
                result = subprocess.run(
                    [
                        sys.executable,
                        "-m",
                        "pip",
                        "install",
                        "--upgrade",
                        "--disable-pip-version-check",
                        self.PACKAGE_NAME,
                    ],
                    capture_output=True,
                    text=True,
                    timeout=300,
                )
                if result.returncode == 0:
                    self._cached_version = None
                    self._last_check = 0
                    logger.info("Successfully updated %s via pip", self.PACKAGE_NAME)
                    return True
                logger.error("SAGE update failed: %s", result.stderr.strip())
            except Exception as exc:
                logger.error("Failed to apply SAGE update: %s", exc)
        return False

    def ensure_latest(self) -> CLIUpdateResult:
        """Check for updates and apply them when available."""

        version = self.check_for_update()
        if not version.update_available:
            return CLIUpdateResult(
                ok=True,
                updated=False,
                attempted=False,
                current=version.current,
                latest=version.latest,
                message=f"SAGE AI is already up to date (v{version.current}).",
            )

        success = self.apply_update()
        refreshed = self.check_for_update(force=True)
        if success:
            if "git update available" in version.latest:
                return CLIUpdateResult(
                    ok=True,
                    updated=True,
                    attempted=True,
                    current=refreshed.current,
                    latest=refreshed.latest,
                    message=f"Updated SAGE AI via git pull (v{version.current}).",
                )

            if self._compare_versions(refreshed.current, version.current) > 0:
                return CLIUpdateResult(
                    ok=True,
                    updated=True,
                    attempted=True,
                    current=refreshed.current,
                    latest=refreshed.latest,
                    message=(
                        f"Updated SAGE AI from v{version.current} to v{refreshed.current}."
                    ),
                )

            if not refreshed.update_available:
                return CLIUpdateResult(
                    ok=True,
                    updated=False,
                    attempted=True,
                    current=refreshed.current,
                    latest=refreshed.latest,
                    message=f"SAGE AI is already up to date (v{refreshed.current}).",
                )

            return CLIUpdateResult(
                ok=False,
                updated=False,
                attempted=True,
                current=refreshed.current,
                latest=refreshed.latest,
                message=(
                    "SAGE AI update completed, but the installed version did not change. "
                    f"Current version is still v{refreshed.current}."
                ),
            )

        return CLIUpdateResult(
            ok=False,
            updated=False,
            attempted=True,
            current=refreshed.current,
            latest=version.latest,
            message=(
                f"Failed to update SAGE AI from v{version.current} to v{version.latest}."
            ),
        )

    @staticmethod
    def _compare_versions(v1: str, v2: str) -> int:
        """Compare two version strings."""

        def parse(version: str) -> tuple[int, ...]:
            parts: list[int] = []
            for part in version.replace("-", ".").split("."):
                try:
                    parts.append(int(part))
                except ValueError:
                    parts.append(0)
            return tuple(parts)

        p1, p2 = parse(v1), parse(v2)
        if p1 < p2:
            return -1
        if p1 > p2:
            return 1
        return 0
