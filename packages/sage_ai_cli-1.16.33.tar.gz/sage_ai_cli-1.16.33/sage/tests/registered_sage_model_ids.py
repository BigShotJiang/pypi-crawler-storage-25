"""
Aggregate every SAGE-routable model id declared in the codebase.

Used by registry tests and optional live E2E over all models.

Includes:
- All OpenAI-compat ProviderSpec registries (Groq, OpenRouter, … Pollinations, DeepInfra)
- All Gemini static free models
- Full download/catalog list from :func:`sage.models.catalog.get_full_catalog`
  (GGUF + Ollama), mapped to `llama_cpp:` / `ollama:` prefixes
"""

from __future__ import annotations

import functools

from sage.models.catalog import get_full_catalog
from sage.providers.gemini import _FREE_MODELS as _GEMINI_FREE
from sage.providers.openai_compat import PROVIDER_SPECS


@functools.lru_cache(maxsize=1)
def collect_all_sage_model_identifiers() -> tuple[str, ...]:
    """Return the sorted unique set of all declared model id strings (provider:id)."""
    out: set[str] = set()
    for spec in PROVIDER_SPECS:
        for m in spec.models:
            out.add(f"{spec.name}:{m.id}")
    for m in _GEMINI_FREE:
        out.add(f"gemini:{m.id}")
    for entry in get_full_catalog():
        if entry.backend == "ollama":
            base = entry.name.removeprefix("ollama:")
            out.add(f"ollama:{base}")
        elif entry.backend == "gguf":
            out.add(f"llama_cpp:{entry.name}")
    return tuple(sorted(out))
