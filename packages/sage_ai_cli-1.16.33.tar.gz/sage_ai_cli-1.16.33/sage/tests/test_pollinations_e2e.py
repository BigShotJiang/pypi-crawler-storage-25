"""
End-to-End Integration Tests for Pollinations AI Models.

These tests actually call the Pollinations API to verify each model works.
Tests are marked with pytest markers for selective running.

Usage:
    pytest sage/tests/test_pollinations_e2e.py -v -m "smoke"         # Quick smoke tests
    pytest sage/tests/test_pollinations_e2e.py -v -m "integration"   # Full integration
    pytest sage/tests/test_pollinations_e2e.py -v --timeout=60       # With timeout
"""

import json
import os

import httpx
import pytest

# ═══════════════════════════════════════════════════════════════════════════════
# API CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

POLLINATIONS_API_URL = "https://gen.pollinations.ai/v1/chat/completions"
POLLINATIONS_API_KEY = os.environ.get("POLLINATIONS_API_KEY", "")
REQUEST_TIMEOUT = 30.0  # seconds

# All FREE text models from Pollinations AI
POLLINATIONS_FREE_MODELS = [
    "qwen-safety",  # 125K responses/pollen
    "nova-fast",  # 9.1K responses/pollen
    "mistral",  # 4.3K responses/pollen
    "gemini-fast",  # 2.1K responses/pollen
    "nova",  # 1.4K responses/pollen
    "grok",  # 1.3K responses/pollen
    "openai",  # 1.2K responses/pollen
    "gemini-search",  # 1.1K responses/pollen
    "qwen-coder",  # 1K responses/pollen
    "perplexity-fast",  # 950 responses/pollen
    "openai-fast",  # 700 responses/pollen
    "qwen-vision",  # 400 responses/pollen
    "minimax",  # 250 responses/pollen
    "openai-audio",  # 150 responses/pollen
    "deepseek",  # 150 responses/pollen
    "midijourney",  # 100 responses/pollen
    "claude-fast",  # 100 responses/pollen
    "kimi",  # 100 responses/pollen
]

# Models best for coding (test these more thoroughly)
CODING_MODELS = ["qwen-coder", "openai", "grok", "deepseek", "mistral", "claude-fast"]

# Quick smoke test models (high capacity, reliable)
SMOKE_TEST_MODELS = ["openai", "grok", "mistral", "nova-fast"]


def get_headers():
    """Get request headers with optional API key."""
    headers = {"Content-Type": "application/json"}
    if POLLINATIONS_API_KEY:
        headers["Authorization"] = f"Bearer {POLLINATIONS_API_KEY}"
    return headers


def call_pollinations_api(
    model: str,
    prompt: str,
    system_prompt: str = "",
    max_tokens: int = 100,
    temperature: float = 0.7,
    timeout: float = REQUEST_TIMEOUT,
) -> dict:
    """Call Pollinations API and return response."""
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": prompt})

    payload = {
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "stream": False,
    }

    with httpx.Client(timeout=timeout) as client:
        response = client.post(
            POLLINATIONS_API_URL,
            json=payload,
            headers=get_headers(),
        )
        return {
            "status_code": response.status_code,
            "content": response.text,
            "json": response.json() if response.status_code == 200 else None,
        }


# ═══════════════════════════════════════════════════════════════════════════════
# SMOKE TESTS - Quick verification that API is working
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.mark.smoke
@pytest.mark.integration
class TestPollinationsSmoke:
    """Quick smoke tests for Pollinations API."""

    @pytest.mark.parametrize("model", SMOKE_TEST_MODELS)
    def test_simple_hello(self, model):
        """Test simple hello prompt works."""
        try:
            result = call_pollinations_api(
                model=model,
                prompt="Say 'OK' if you can read this.",
                max_tokens=10,
                temperature=0.1,
            )

            if result["status_code"] == 200:
                content = result["json"]["choices"][0]["message"]["content"]
                assert len(content) > 0
            elif result["status_code"] == 429:
                pytest.skip(f"Rate limited: {model}")
            elif result["status_code"] == 402:
                pytest.skip(f"Insufficient pollen: {model}")
            else:
                pytest.skip(f"API error {result['status_code']}: {model}")

        except httpx.TimeoutException:
            pytest.skip(f"Timeout: {model}")
        except Exception as e:
            pytest.skip(f"Error: {model} - {e}")


# ═══════════════════════════════════════════════════════════════════════════════
# CODING TASK E2E TESTS
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.mark.integration
@pytest.mark.coding
class TestPollinationsCodingE2E:
    """E2E tests for coding tasks with Pollinations models."""

    CODING_PROMPTS = [
        ("Write a Python function called 'add' that adds two numbers.", ["def", "add", "return"]),
        (
            "Write a JavaScript function to check if a string is a palindrome.",
            ["function", "return"],
        ),
        (
            "Write a Python list comprehension that squares all numbers from 1 to 10.",
            ["[", "for", "in"],
        ),
    ]

    @pytest.mark.parametrize("model", CODING_MODELS)
    def test_python_function(self, model):
        """Test Python function generation."""
        try:
            result = call_pollinations_api(
                model=model,
                prompt="Write a Python function called 'is_prime' that checks if a number is prime. Only output the function code.",
                system_prompt="You are a Python expert. Output only code, no explanations.",
                max_tokens=200,
                temperature=0.3,
            )

            if result["status_code"] == 200:
                content = result["json"]["choices"][0]["message"]["content"]
                # Should contain Python function markers
                assert "def" in content.lower() or "prime" in content.lower(), (
                    f"No function found in: {content[:200]}"
                )
            elif result["status_code"] in [429, 402]:
                pytest.skip(f"Rate/pollen limited: {model}")
            else:
                pytest.skip(f"API error {result['status_code']}: {model}")

        except httpx.TimeoutException:
            pytest.skip(f"Timeout: {model}")

    @pytest.mark.parametrize("model", CODING_MODELS)
    def test_code_explanation(self, model):
        """Test code explanation capability."""
        try:
            result = call_pollinations_api(
                model=model,
                prompt="Explain what this code does: `sorted(set(x for x in lst if x > 0))`",
                max_tokens=150,
                temperature=0.3,
            )

            if result["status_code"] == 200:
                content = result["json"]["choices"][0]["message"]["content"]
                # Should mention key concepts
                assert len(content) > 20, f"Response too short: {content}"
            elif result["status_code"] in [429, 402]:
                pytest.skip(f"Rate/pollen limited: {model}")
            else:
                pytest.skip(f"API error {result['status_code']}: {model}")

        except httpx.TimeoutException:
            pytest.skip(f"Timeout: {model}")


# ═══════════════════════════════════════════════════════════════════════════════
# ALL MODELS TEXT PROMPT TESTS
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.mark.integration
class TestPollinationsAllModelsE2E:
    """E2E tests for all Pollinations models with text prompts."""

    @pytest.mark.parametrize("model", POLLINATIONS_FREE_MODELS)
    def test_basic_prompt(self, model):
        """Test basic prompt works for each model."""
        try:
            result = call_pollinations_api(
                model=model,
                prompt="What is 2 + 2?",
                max_tokens=20,
                temperature=0.1,
            )

            if result["status_code"] == 200:
                content = result["json"]["choices"][0]["message"]["content"]
                # Should contain the answer or be a valid response
                assert len(content) > 0, f"Empty response from {model}"
            elif result["status_code"] == 429:
                pytest.skip(f"Rate limited: {model}")
            elif result["status_code"] == 402:
                pytest.skip(f"Insufficient pollen: {model}")
            elif result["status_code"] == 404:
                pytest.skip(f"Model not found: {model}")
            else:
                pytest.skip(f"API error {result['status_code']}: {model}")

        except httpx.TimeoutException:
            pytest.skip(f"Timeout: {model}")
        except Exception as e:
            pytest.skip(f"Error: {model} - {e}")

    @pytest.mark.parametrize("model", POLLINATIONS_FREE_MODELS)
    def test_creative_prompt(self, model):
        """Test creative prompt capability."""
        try:
            result = call_pollinations_api(
                model=model,
                prompt="Write a haiku about Python programming.",
                max_tokens=50,
                temperature=0.8,
            )

            if result["status_code"] == 200:
                content = result["json"]["choices"][0]["message"]["content"]
                assert len(content) > 10, f"Response too short from {model}"
            elif result["status_code"] in [429, 402, 404]:
                pytest.skip(f"API unavailable: {model}")
            else:
                pytest.skip(f"API error {result['status_code']}: {model}")

        except (httpx.TimeoutException, Exception) as e:
            pytest.skip(f"Error: {model} - {e}")


# ═══════════════════════════════════════════════════════════════════════════════
# REASONING MODEL E2E TESTS
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.mark.integration
@pytest.mark.reasoning
class TestPollinationsReasoningE2E:
    """E2E tests for reasoning-capable Pollinations models."""

    REASONING_MODELS = ["deepseek", "nova", "qwen-vision", "minimax", "kimi"]

    @pytest.mark.parametrize("model", REASONING_MODELS)
    def test_logical_reasoning(self, model):
        """Test logical reasoning capability."""
        try:
            result = call_pollinations_api(
                model=model,
                prompt="If A > B and B > C, is A > C? Answer yes or no and explain briefly.",
                system_prompt="Think step by step.",
                max_tokens=100,
                temperature=0.2,
            )

            if result["status_code"] == 200:
                content = result["json"]["choices"][0]["message"]["content"].lower()
                # Should contain yes (correct answer)
                assert "yes" in content, f"Wrong answer from {model}: {content[:100]}"
            elif result["status_code"] in [429, 402, 404]:
                pytest.skip(f"API unavailable: {model}")
            else:
                pytest.skip(f"API error {result['status_code']}: {model}")

        except (httpx.TimeoutException, Exception) as e:
            pytest.skip(f"Error: {model} - {e}")

    @pytest.mark.parametrize("model", REASONING_MODELS)
    def test_math_reasoning(self, model):
        """Test mathematical reasoning."""
        try:
            result = call_pollinations_api(
                model=model,
                prompt="What comes next in the sequence: 2, 4, 8, 16, ?",
                max_tokens=50,
                temperature=0.1,
            )

            if result["status_code"] == 200:
                content = result["json"]["choices"][0]["message"]["content"]
                # Should contain 32 (correct answer)
                assert "32" in content, f"Wrong answer from {model}: {content[:100]}"
            elif result["status_code"] in [429, 402, 404]:
                pytest.skip(f"API unavailable: {model}")
            else:
                pytest.skip(f"API error {result['status_code']}: {model}")

        except (httpx.TimeoutException, Exception) as e:
            pytest.skip(f"Error: {model} - {e}")


# ═══════════════════════════════════════════════════════════════════════════════
# MULTI-TURN CONVERSATION TESTS
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.mark.integration
class TestPollinationsMultiTurnE2E:
    """E2E tests for multi-turn conversations."""

    def test_context_retention(self):
        """Test that model retains context across turns."""
        model = "openai"  # Use reliable model
        try:
            # First turn: establish context
            messages = [
                {"role": "user", "content": "My favorite color is blue. Remember it."},
            ]

            payload = {
                "model": model,
                "messages": messages,
                "max_tokens": 50,
                "temperature": 0.3,
                "stream": False,
            }

            with httpx.Client(timeout=REQUEST_TIMEOUT) as client:
                resp1 = client.post(POLLINATIONS_API_URL, json=payload, headers=get_headers())

                if resp1.status_code == 200:
                    assistant_response = resp1.json()["choices"][0]["message"]["content"]

                    # Second turn: test recall
                    messages.append({"role": "assistant", "content": assistant_response})
                    messages.append({"role": "user", "content": "What is my favorite color?"})
                    payload["messages"] = messages

                    resp2 = client.post(POLLINATIONS_API_URL, json=payload, headers=get_headers())

                    if resp2.status_code == 200:
                        final_response = resp2.json()["choices"][0]["message"]["content"].lower()
                        assert "blue" in final_response, f"Context not retained: {final_response}"
                    else:
                        pytest.skip(f"Second turn failed: {resp2.status_code}")
                elif resp1.status_code in [429, 402]:
                    pytest.skip("Rate/pollen limited")
                else:
                    pytest.skip(f"First turn failed: {resp1.status_code}")

        except (httpx.TimeoutException, Exception) as e:
            pytest.skip(f"Error: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
# API KEY AUTHENTICATION TESTS
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.mark.integration
class TestPollinationsAuthE2E:
    """E2E tests for API key authentication."""

    def test_request_with_api_key(self):
        """Test request works with API key."""
        if not POLLINATIONS_API_KEY:
            pytest.skip("POLLINATIONS_API_KEY not set")

        try:
            result = call_pollinations_api(
                model="openai",
                prompt="Say 'authenticated' if you can read this.",
                max_tokens=10,
            )

            if result["status_code"] == 200:
                content = result["json"]["choices"][0]["message"]["content"]
                assert len(content) > 0
            else:
                pytest.skip(f"API error: {result['status_code']}")

        except Exception as e:
            pytest.skip(f"Error: {e}")

    def test_request_without_api_key(self):
        """Test request works without API key (free tier)."""
        # Temporarily clear API key
        headers = {"Content-Type": "application/json"}

        payload = {
            "model": "openai",
            "messages": [{"role": "user", "content": "Say OK"}],
            "max_tokens": 10,
            "stream": False,
        }

        try:
            with httpx.Client(timeout=REQUEST_TIMEOUT) as client:
                response = client.post(POLLINATIONS_API_URL, json=payload, headers=headers)

                # Should work even without API key (lower rate limits)
                assert response.status_code in [200, 429], f"Unexpected: {response.status_code}"

        except httpx.TimeoutException:
            pytest.skip("Timeout")
        except Exception as e:
            pytest.skip(f"Error: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
# ERROR HANDLING TESTS
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.mark.integration
class TestPollinationsErrorHandlingE2E:
    """E2E tests for API error handling."""

    def test_invalid_model_returns_error(self):
        """Test that invalid model returns appropriate error."""
        try:
            with httpx.Client(timeout=REQUEST_TIMEOUT) as client:
                response = client.post(
                    POLLINATIONS_API_URL,
                    json={
                        "model": "nonexistent-model-xyz",
                        "messages": [{"role": "user", "content": "Hello"}],
                        "max_tokens": 10,
                    },
                    headers=get_headers(),
                )

                # Should return 400 or 404 for invalid model
                assert response.status_code in [400, 404, 500], f"Got: {response.status_code}"

        except Exception as e:
            pytest.skip(f"Error: {e}")

    def test_empty_messages_returns_error(self):
        """Test that empty messages returns appropriate error."""
        try:
            with httpx.Client(timeout=REQUEST_TIMEOUT) as client:
                response = client.post(
                    POLLINATIONS_API_URL,
                    json={
                        "model": "openai",
                        "messages": [],
                        "max_tokens": 10,
                    },
                    headers=get_headers(),
                )

                # Should return 400 for empty messages
                assert response.status_code in [400, 422, 500], f"Got: {response.status_code}"

        except Exception as e:
            pytest.skip(f"Error: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
# STREAMING TESTS
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.mark.integration
class TestPollinationsStreamingE2E:
    """E2E tests for streaming responses."""

    def test_streaming_response(self):
        """Test streaming response works."""
        model = "openai"
        try:
            with (
                httpx.Client(timeout=REQUEST_TIMEOUT) as client,
                client.stream(
                    "POST",
                    POLLINATIONS_API_URL,
                    json={
                        "model": model,
                        "messages": [{"role": "user", "content": "Count from 1 to 5."}],
                        "max_tokens": 50,
                        "stream": True,
                    },
                    headers=get_headers(),
                ) as response,
            ):
                if response.status_code == 200:
                    tokens = []
                    for line in response.iter_lines():
                        if line.startswith("data:"):
                            data_str = line[5:].strip()
                            if data_str == "[DONE]":
                                break
                            try:
                                chunk = json.loads(data_str)
                                delta = chunk.get("choices", [{}])[0].get("delta", {})
                                content = delta.get("content", "")
                                if content:
                                    tokens.append(content)
                            except json.JSONDecodeError:
                                continue

                    # Should have received some tokens
                    assert len(tokens) > 0, "No tokens received"
                elif response.status_code in [429, 402]:
                    pytest.skip("Rate/pollen limited")
                else:
                    pytest.skip(f"API error: {response.status_code}")

        except (httpx.TimeoutException, Exception) as e:
            pytest.skip(f"Error: {e}")
