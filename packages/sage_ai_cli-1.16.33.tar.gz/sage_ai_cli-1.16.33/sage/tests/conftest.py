"""Shared fixtures and markers for SAGE CLI test suite.

P1-18/P1-20: Test strategy rationalization with marker segregation.

Test Categories:
    - smoke: Fast critical-path tests (run in CI on every commit)
    - unit: Isolated unit tests (default CI run)
    - integration: Tests requiring external services or file I/O
    - slow: Long-running tests (excluded from default CI)
    - roadmap: TDD roadmap validation tests (opt-in)

Usage:
    pytest sage/tests                           # Run all sage tests
    pytest -m smoke                             # Run only smoke tests
    pytest -m "not slow"                        # Exclude slow tests
    pytest -m "unit or smoke"                   # Run unit and smoke tests
"""

from __future__ import annotations

import tempfile
from collections.abc import Generator
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

# =============================================================================
# Test Markers - Auto-apply based on test location/naming
# =============================================================================


def pytest_collection_modifyitems(config, items):
    """Auto-apply markers based on test file names and locations."""
    for item in items:
        # Mark roadmap tests
        if "roadmap" in str(item.fspath):
            item.add_marker(pytest.mark.roadmap)
            item.add_marker(pytest.mark.slow)

        # Mark integration tests
        if "integration" in item.name or "integration" in str(item.fspath):
            item.add_marker(pytest.mark.integration)

        # Mark benchmark/performance tests as slow
        if "benchmark" in item.name or "benchmark" in str(item.fspath):
            item.add_marker(pytest.mark.slow)

        # Mark security tests
        if "security" in item.name or "security" in str(item.fspath):
            item.add_marker(pytest.mark.security)


# =============================================================================
# Project Root Fixtures (P1-E: Unified test-root conventions)
# =============================================================================


@pytest.fixture
def sage_project_root() -> Path:
    """Return the ai-platform project root directory.

    P1-E: Provides a single source of truth for project root in tests.
    Use this instead of Path(__file__).parent.parent.parent patterns.

    Structure:
        ai-platform/           <- This is returned
        ├── sage/
        │   ├── tests/         <- Tests live here
        │   └── main.py
        ├── backend/
        └── pyproject.toml
    """
    return Path(__file__).parent.parent.parent


@pytest.fixture
def sage_tests_dir() -> Path:
    """Return the sage/tests directory.

    P1-E: Provides consistent test directory reference.
    """
    return Path(__file__).parent


@pytest.fixture
def sage_module_root() -> Path:
    """Return the sage module directory.

    P1-E: Provides consistent sage module reference.
    """
    return Path(__file__).parent.parent


# =============================================================================
# Common Fixtures
# =============================================================================


@pytest.fixture
def temp_dir() -> Generator[Path, None, None]:
    """Provide a temporary directory for test file operations."""
    with tempfile.TemporaryDirectory() as td:
        yield Path(td)


@pytest.fixture
def mock_provider() -> MagicMock:
    """Mock provider for testing without actual LLM calls."""
    provider = MagicMock()
    provider.generate = AsyncMock(return_value="Mocked response")
    provider.stream = AsyncMock()
    provider.models = MagicMock(return_value=[])
    return provider


@pytest.fixture
def sample_code_python() -> str:
    """Sample Python code for testing."""
    return '''
def greet(name: str) -> str:
    """Return a greeting message."""
    return f"Hello, {name}!"


def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b
'''


@pytest.fixture
def sample_code_javascript() -> str:
    """Sample JavaScript code for testing."""
    return """
function greet(name) {
    return `Hello, ${name}!`;
}

const add = (a, b) => a + b;

export { greet, add };
"""


@pytest.fixture
def sample_project_structure(temp_dir: Path) -> Path:
    """Create a sample project structure for testing."""
    # Create directories
    (temp_dir / "src").mkdir()
    (temp_dir / "tests").mkdir()

    # Create files
    (temp_dir / "src" / "main.py").write_text("print('hello')")
    (temp_dir / "src" / "__init__.py").write_text("")
    (temp_dir / "tests" / "test_main.py").write_text("def test_main(): pass")
    (temp_dir / "pyproject.toml").write_text("[project]\nname = 'test'\n")
    (temp_dir / "README.md").write_text("# Test Project")

    return temp_dir


@pytest.fixture
def mock_subprocess(monkeypatch: pytest.MonkeyPatch) -> MagicMock:
    """Mock subprocess.run for command execution tests."""
    mock_run = MagicMock()
    mock_run.return_value.returncode = 0
    mock_run.return_value.stdout = ""
    mock_run.return_value.stderr = ""
    monkeypatch.setattr("subprocess.run", mock_run)
    return mock_run
