# Simple Adder

A simple Python package that adds two numbers together.

## Installation

```bash
pip install simple_adder_nagaraju1901

