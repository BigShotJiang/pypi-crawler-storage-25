def add(a: float, b: float) -> float:
    """
    A simple function to add two numbers.
    Args:
        a (float): The first number.
        b (float): The second number.
    Returns:
        float: The sum of the two numbers.
    """
    return a+b

