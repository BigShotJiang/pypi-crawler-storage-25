# upvertex-amd

Namespace reservation for UpVertex Inc. (www.upvertex.com)