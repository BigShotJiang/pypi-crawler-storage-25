"""
EnvManageLibrary - Robot Framework keyword library.

Scans existing RF variables and overrides their values with matching
entries from a .env file, scoped to the current test case.

.env naming convention:
    - Flat variable ``${user}``            -> ``USER=value``
    - Flat variable ``${authen_key_user}`` -> ``AUTHEN_KEY_USER=value``
    - Nested dict ``${authen_key}[user]``  -> ``AUTHEN_KEY.USER=value``

The dot (``.``) separator distinguishes nested dict keys from flat
variable names that contain underscores.

Usage in Robot Framework:
    Library    EnvManageLibrary
    Variables  ${CURDIR}/data/authen.yaml

    EnvManageLibrary.Override Variables From Env    .env
"""

import copy
from pathlib import Path
from robot.api.deco import keyword
from robot.libraries.BuiltIn import BuiltIn

_SKIP_VARS = frozenset((
    "None", "True", "False", "null", "true", "false",
    "EMPTY", "SPACE", "\\n",
))


def _load_dotenv(env_path):
    """Parse a .env file into a dict."""
    env_vars = {}
    path = Path(env_path)
    if not path.is_file():
        return env_vars
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        env_vars[key.strip()] = value.strip().strip("'\"")
    return env_vars


def _build_nested_overrides(env_vars):
    """Build a lookup for nested dict overrides from dot-notation env keys.

    Returns a dict like: ``{"authen_key": {"user": "val", "pass": "val"}}``
    from env keys like ``AUTHEN_KEY.USER=val``, ``AUTHEN_KEY.PASS=val``.
    """
    nested = {}
    for env_key, env_value in env_vars.items():
        if "." not in env_key:
            continue
        parts = env_key.split(".")
        var_name = parts[0].lower()
        remaining = [p.lower() for p in parts[1:]]

        current = nested.setdefault(var_name, {})
        for part in remaining[:-1]:
            current = current.setdefault(part, {})
        current[remaining[-1]] = env_value
    return nested


def _apply_nested_overrides(data, overrides):
    """Apply nested overrides to a dict. Returns True if anything changed."""
    changed = False
    for key in data:
        if key not in overrides:
            continue
        override = overrides[key]
        if isinstance(data[key], dict) and isinstance(override, dict):
            if _apply_nested_overrides(data[key], override):
                changed = True
        else:
            data[key] = override
            changed = True
    return changed


class EnvManageLibrary:
    """EnvManageLibrary is a Robot Framework library for overriding test variables from ``.env`` files.

    Variables loaded via Robot Framework's ``Variables`` directive (from YAML files)
    are automatically matched against ``.env`` entries and overridden at test-case scope.

    == Installation ==

    Install from PyPI:
    | pip install robotframework-env-manage-library

    == .env Naming Convention ==

    The dot (``.``) separator distinguishes nested dict keys from flat variable names containing underscores.

    | *.env Key*          | *RF Variable*         | *Type*          |
    | ``USER=value``      | ``${user}``           | Flat            |
    | ``DB_HOST=value``   | ``${db_host}``        | Flat            |
    | ``AUTHEN.USER=val`` | ``${authen}[user]``   | Nested dict     |
    | ``DB.CONN.HOST=v``  | ``${db}[conn][host]`` | Deep nested dict|

    == Usage Example ==

    === YAML data files ===
    | # data/credentials.yaml
    | user: testuser
    | pass: "default_pass"

    === .env file ===
    | USER=admin
    | PASS=S3cretK3y!
    | DB.HOST=prod-db.example.com

    === Robot Framework test ===
    | **Settings**
    | Library    EnvManageLibrary
    | Variables  ${CURDIR}/data/credentials.yaml
    |
    | **Test Cases**
    | Verify Credentials Override
    |     Override Variables From Env    path/to/.env
    |     Should Be Equal    ${user}    admin

    == Key Behaviors ==

    - Override scope is per test case - original values reset between tests
    - If ``.env`` file doesn't exist, all variables keep their YAML values
    - Case insensitive matching: YAML ``user`` matches env ``USER``
    - Flat keys with underscores (``DB_HOST``) only override flat RF variables (``${db_host}``), not nested dicts
    - Dict values are deep-copied before override to prevent mutation
    """

    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    @keyword("Override Variables From Env")
    def override_variables_from_env(self, env_path=".env"):
        """Override current RF variables with values from a ``.env`` file.

        The keyword scans all existing Robot Framework variables and overrides
        their values with matching entries from the specified ``.env`` file.
        Overrides are scoped to the current test case using ``Set Test Variable``.

        == Naming Convention ==

        | *.env Key*                | *Overrides*                          |
        | ``USER=value``            | flat ``${user}``                     |
        | ``AUTHEN_KEY_USER=value`` | flat ``${authen_key_user}``          |
        | ``AUTHEN_KEY.USER=value`` | nested ``${authen_key}[user]``       |

        == Arguments ==

        - ``env_path``: Path to the ``.env`` file. Defaults to ``.env`` in the current directory.

        == Examples ==

        | Override Variables From Env |                    | # Uses default .env     |
        | Override Variables From Env | path/to/custom.env | # Uses custom .env path |
        | Override Variables From Env | ${CURDIR}/.env    | # Relative to test file |

        If the ``.env`` file does not exist, no variables are changed.
        """
        builtin = BuiltIn()
        dot_env = _load_dotenv(env_path)

        if not dot_env:
            return

        flat_env = {k: v for k, v in dot_env.items() if "." not in k}
        nested_overrides = _build_nested_overrides(dot_env)

        rf_vars = builtin.get_variables()

        seen = set()
        for rf_name, rf_value in rf_vars.items():
            if len(rf_name) < 4 or rf_name[1] != "{" or not rf_name.endswith("}"):
                continue

            var_name = rf_name[2:-1]
            if var_name in seen:
                continue
            seen.add(var_name)

            if var_name.startswith((" ", "/", "{")):
                continue
            if var_name in _SKIP_VARS:
                continue
            if var_name.upper() == var_name and var_name not in flat_env:
                continue

            if isinstance(rf_value, dict):
                if var_name in nested_overrides:
                    new_value = copy.deepcopy(rf_value)
                    if _apply_nested_overrides(new_value, nested_overrides[var_name]):
                        builtin.set_test_variable(f"${{{var_name}}}", new_value)
            else:
                # Handle str, None, and other scalar types from YAML
                env_value = flat_env.get(var_name.upper())
                if env_value is not None:
                    builtin.set_test_variable(f"${{{var_name}}}", env_value)
