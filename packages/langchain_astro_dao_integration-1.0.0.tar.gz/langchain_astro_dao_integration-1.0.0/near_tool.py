"""
LangChain tools for NEAR Protocol.
Generated for: LangChain Tool - Astro DAO Integration
"""
import requests
import json
import base64
import time
import hashlib
import hmac
import urllib.parse
from typing import Optional, Type, Any, List, Dict, Union, Tuple, Set, Callable
from pydantic import BaseModel, Field

try:
    from langchain.tools import BaseTool
except ImportError:
    from langchain_core.tools import BaseTool  # langchain v0.2+

NEAR_RPC_MAINNET = "https://rpc.mainnet.near.org"
NEAR_RPC_TESTNET = "https://rpc.testnet.near.org"


def _near_rpc(method: str, params: Any, network: str = "mainnet") -> dict:
    """Execute NEAR JSON-RPC call."""
    url = NEAR_RPC_MAINNET if network == "mainnet" else NEAR_RPC_TESTNET
    resp = requests.post(url, json={"jsonrpc":"2.0","id":"1","method":method,"params":params}, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    if "error" in data:
        raise RuntimeError(f"NEAR RPC error: {data['error']}")
    return data.get("result", {})


class NEARAccountInput(BaseModel):
    account_id: str = Field(description="NEAR account ID (e.g. example.near)")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARAccountTool(BaseTool):
    """Query NEAR account balance and storage info."""
    name: str = "near_account_info"
    description: str = "Get NEAR account balance and info. Input: account_id, network (optional)"
    args_schema: Type[BaseModel] = NEARAccountInput

    def _run(self, account_id: str, network: str = "mainnet") -> str:
        result = _near_rpc("query", {
            "request_type": "view_account", "finality": "final", "account_id": account_id
        }, network)
        near = int(result.get("amount", 0)) / 10**24
        return json.dumps({"account_id": account_id, "balance_near": f"{near:.4f}",
            "storage_bytes": result.get("storage_usage", 0)})

    async def _arun(self, account_id: str, network: str = "mainnet") -> str:
        return self._run(account_id, network)


class NEARViewFunctionInput(BaseModel):
    contract_id: str = Field(description="NEAR contract ID")
    method_name: str = Field(description="View method name")
    args: dict = Field(default={}, description="Method arguments")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARViewFunctionTool(BaseTool):
    """Call a view function on a NEAR smart contract."""
    name: str = "near_view_function"
    description: str = "Call a NEAR contract view function. Input: contract_id, method_name, args"
    args_schema: Type[BaseModel] = NEARViewFunctionInput

    def _run(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        args_b64 = base64.b64encode(json.dumps(args).encode()).decode()
        result = _near_rpc("query", {
            "request_type": "call_function", "finality": "final",
            "account_id": contract_id, "method_name": method_name, "args_base64": args_b64
        }, network)
        decoded = json.loads(bytes(result["result"]).decode())
        return json.dumps(decoded, indent=2)

    async def _arun(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        return self._run(contract_id, method_name, args, network)


ASTRO_DAO_API = "https://api.astrodao.com/api/v1"

class AstroDaoProposalsInput(BaseModel):
    dao_id: str = Field(..., description="The DAO account ID on NEAR (e.g. 'mydao.sputnik-dao.near')")
    status: Optional[str] = Field(None, description="Filter by proposal status: 'InProgress', 'Approved', 'Rejected', 'Expired'")
    limit: int = Field(10, description="Number of proposals to return")

class AstroDaoProposalsTool(BaseTool):
    name: str = "astro_dao_proposals"
    description: str = (
        "Fetch proposals from an Astro DAO. Returns proposal details including title, "
        "description, kind, status, votes, and vote counts. Useful for governance analysis."
    )
    args_schema: Type[BaseModel] = AstroDaoProposalsInput

    def _run(self, dao_id: str, status: Optional[str] = None, limit: int = 10) -> str:
        try:
            params: Dict[str, Any] = {
                "limit": limit,
                "offset": 0,
                "daoId": dao_id,
                "orderBy": "createdAt",
                "order": "DESC",
            }
            if status:
                params["status"] = status
            resp = requests.get(f"{ASTRO_DAO_API}/proposals", params=params, timeout=15)
            resp.raise_for_status()
            data = resp.json()
            items = data.get("data", []) if isinstance(data, dict) else data
            if not items:
                return f"No proposals found for DAO '{dao_id}'."
            results = []
            for p in items[:limit]:
                results.append(
                    f"ID: {p.get('id')} | Status: {p.get('status')} | "
                    f"Kind: {p.get('kind', {}).get('type', 'N/A')} | "
                    f"Title: {p.get('description', '')[:80]} | "
                    f"Votes For: {p.get('voteCounts', {}).get('Yes', 0)} "
                    f"Against: {p.get('voteCounts', {}).get('No', 0)}"
                )
            return "\n".join(results)
        except requests.HTTPError as e:
            return f"HTTP error fetching proposals: {e}"
        except Exception as e:
            return f"Error fetching Astro DAO proposals: {e}"

    async def _arun(self, dao_id: str, status: Optional[str] = None, limit: int = 10) -> str:
        return self._run(dao_id=dao_id, status=status, limit=limit)


class AstroDaoDaoInfoInput(BaseModel):
    dao_id: str = Field(..., description="The DAO account ID on NEAR (e.g. 'mydao.sputnik-dao.near')")

class AstroDaoDaoInfoTool(BaseTool):
    name: str = "astro_dao_info"
    description: str = (
        "Retrieve detailed information about an Astro DAO including its members, "
        "policy, funds, total proposals, and council. Use this to understand DAO structure and governance."
    )
    args_schema: Type[BaseModel] = AstroDaoDaoInfoInput

    def _run(self, dao_id: str) -> str:
        try:
            resp = requests.get(f"{ASTRO_DAO_API}/daos/{dao_id}", timeout=15)
            resp.raise_for_status()
            dao = resp.json()
            if not dao:
                return f"DAO '{dao_id}' not found on Astro DAO."
            funds = dao.get("funds", "N/A")
            total_dao_funds = dao.get("totalDaoFunds", funds)
            council = dao.get("council", [])
            council_str = ", ".join(council[:5]) + ("..." if len(council) > 5 else "") if council else "N/A"
            policy = dao.get("policy", {})
            quorum = policy.get("defaultVotePolicy", {}).get("quorum", "N/A")
            threshold = policy.get("defaultVotePolicy", {}).get("threshold", "N/A")
            return (
                f"DAO: {dao.get('id', dao_id)}\n"
                f"Display Name: {dao.get('displayName', 'N/A')}\n"
                f"Description: {dao.get('description', 'N/A')[:120]}\n"
                f"Total Funds: {total_dao_funds} NEAR\n"
                f"Total Proposals: {dao.get('totalProposalCount', 'N/A')}\n"
                f"Active Proposals: {dao.get('activeProposalCount', 'N/A')}\n"
                f"Council ({len(council)} members): {council_str}\n"
                f"Quorum: {quorum} | Threshold: {threshold}\n"
                f"Link: https://app.astrodao.com/dao/{dao_id}"
            )
        except requests.HTTPError as e:
            return f"HTTP error fetching DAO info: {e}"
        except Exception as e:
            return f"Error fetching Astro DAO info: {e}"

    async def _arun(self, dao_id: str) -> str:
        return self._run(dao_id=dao_id)