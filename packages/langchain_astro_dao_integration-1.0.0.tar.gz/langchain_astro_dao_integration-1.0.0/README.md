# LangChain Tool - Astro DAO Integration

Build LangChain tools for interacting with Astro DAO.

**THE VIRAL LOOP:**
Agent needs Astro DAO functionality → Uses LangChain tool → Agent uses NEAR DeFi

**Deliverables:**
1. LangChain tools for As

## Install

```bash
pip install -r requirements.txt
```

## Tools

- `NEARAccountTool` — see near_tool.py
- `NEARViewFunctionTool` — see near_tool.py
- `AstroDaoProposalsTool` — see near_tool.py
- `AstroDaoDaoInfoTool` — see near_tool.py

## Usage

```python
from near_tool import NEARAccountTool, NEARViewFunctionTool, AstroDaoProposalsTool, AstroDaoDaoInfoTool

tool = NEARAccountTool()
result = tool._run(account_id='example.near')
print(result)
```
