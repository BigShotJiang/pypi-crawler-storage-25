"""Entry point for the Roxels MCP server — run with: python -m roxels_mcp"""

import asyncio
import os
import sys

from .client import RoxelsClient
from .server import create_server


async def _ping_connected(client: RoxelsClient) -> None:
    """Fire a best-effort mcp.connected event so the Roxels backend knows this
    MCP instance is live. Failures are silently swallowed — never block startup."""
    try:
        await client.log_event("mcp.connected")
    except Exception:
        pass


def main():
    api_url = os.environ.get("ROXELS_API_URL", "https://api.roxels.ai")
    api_key = os.environ.get("ROXELS_API_KEY", "")

    if not api_key:
        print(
            "Error: ROXELS_API_KEY environment variable is required.\n"
            "Get your API key from https://app.roxels.ai → Settings → API Keys.",
            file=sys.stderr,
        )
        sys.exit(1)

    client = RoxelsClient(base_url=api_url, api_key=api_key)
    asyncio.run(_ping_connected(client))
    server = create_server(client)
    server.run(transport="stdio")


if __name__ == "__main__":
    main()
