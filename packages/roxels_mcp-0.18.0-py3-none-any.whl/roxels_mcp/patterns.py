"""Integration-pattern catalog for the Roxels MCP.

This catalog is DORMANT by default. See `server.py`'s registration gate:
`get_integration_patterns` is registered as an `@mcp.tool()` only when
`ROXELS_MCP_PATTERNS_ENABLED=1` is set in the environment. While disabled,
the tool does not appear in the tool list — the coding agent never sees it,
so it cannot be invoked, and its contents cannot leak into convergence tests.

WHY DORMANT: we are currently running convergence tests whose *target answers*
are exactly these patterns. Exposing the catalog would be handing the test the
answer key and invalidate the signal we're collecting about how well the MCP's
guidance drives convergence from first principles.

WHEN TO ENABLE: once convergence tests have established a baseline and we want
the MCP to actively teach patterns to new coding agents. Flip
`ROXELS_MCP_PATTERNS_ENABLED=1` in the MCP runtime env — no code change needed.

WHERE TO CROSS-REFERENCE ONCE ENABLED: when re-enabling, these are the call
sites where pattern awareness should be surfaced (deliberately left absent
today so nothing leaks):
  - `ask_roxels` system prompt composition (backend/app/services/mcp_qa.py)
  - `guided_setup_questions` response — add a `matching_pattern` field when
    the template's shape matches a pattern in this catalog
  - `configure_output` next_steps — suggest loading a pattern if the config
    fragment matches a known shape
  - Handoff prompt composition in backend/app/setup_assistant.py
  - `describe_complete_template` — point to `get_integration_patterns` for
    end-to-end examples

Each pattern includes:
  - name, summary
  - shape: canonical integration_shape.current payload
  - example_goals: minimal goal list that fits the shape
  - example_outputs: matching webhook/output configs
  - frontend_snippet: embedding-page JS the client needs to add
  - verify_checklist: what the MCP will check when this pattern is declared
"""

from __future__ import annotations


PATTERNS: list[dict] = [
    {
        "id": "batch_end_of_call",
        "name": "Batch end-of-call webhook",
        "summary": (
            "Single end-of-conversation POST with all goals' data combined into "
            "one payload. The simplest shape — use when the receiver is a CRM, "
            "a Slack notification, or any system that just wants a summary."
        ),
        "shape": {
            "delivery": "batch",
            "surfaces": ["webhook"],
            "per_goal_expectations": {},
            "rationale": (
                "Receiver doesn't react to individual goals; it just wants the "
                "final combined record at end of call."
            ),
        },
        "example_goals": [
            {"id": "topic", "type": "open", "prompt": "Understand the topic."},
            {"id": "details", "type": "open", "prompt": "Capture the details."},
        ],
        "example_outputs": [
            {
                "type": "webhook",
                "config": {
                    "url": "https://example.com/api/intake",
                    "method": "POST",
                    "schema": {"topic": "string", "details": "string"},
                },
            },
        ],
        "frontend_snippet": (
            "Roxels.init({\n"
            "  templateKey: '<rk_...>',\n"
            "  onComplete(results) { console.log('done', results); },\n"
            "});"
        ),
        "verify_checklist": [
            "One webhook output, no trigger_goal.",
            "Schema matches the receiving endpoint's fields.",
            "onComplete callback logged or acted on in the frontend.",
        ],
    },
    {
        "id": "per_goal_crm_push",
        "name": "Per-goal backend push (CRM-style)",
        "summary": (
            "Each goal commits to its own backend endpoint as soon as the agent "
            "finishes collecting it. Survives user drop-off and enables the "
            "client's backend to act on partial data."
        ),
        "shape": {
            "delivery": "per_goal",
            "surfaces": ["webhook"],
            "per_goal_expectations": {
                "<goal_id>": {
                    "surfaces": ["webhook"],
                    "notes": "POSTs to the endpoint that owns this entity.",
                },
            },
            "rationale": (
                "User asked for data to land 'as it comes in'; their backend "
                "already has per-entity endpoints."
            ),
        },
        "example_goals": [
            {"id": "contact", "type": "structured", "prompt": "Collect contact info."},
            {"id": "interest", "type": "open", "prompt": "Understand product interest."},
        ],
        "example_outputs": [
            {
                "type": "webhook",
                "config": {
                    "url": "https://example.com/api/contacts",
                    "trigger_goal": "contact",
                    "schema": {"name": "string", "email": "string"},
                },
            },
            {
                "type": "webhook",
                "config": {
                    "url": "https://example.com/api/interest",
                    "trigger_goal": "interest",
                    "schema": {"interest": "string"},
                },
            },
        ],
        "frontend_snippet": (
            "Roxels.init({ templateKey: '<rk_...>' });\n"
            "// Commits flow directly to the client's backend; no JS callback needed."
        ),
        "verify_checklist": [
            "One webhook per goal with trigger_goal set.",
            "Each webhook's schema matches the endpoint's fields.",
            "extraction_mode is set correctly (cumulative for replace-all endpoints).",
        ],
    },
    {
        "id": "live_frontend_updates",
        "name": "Live frontend updates (sidebar / progress UI)",
        "summary": (
            "Each goal's partial and final data streams to the embedding page, "
            "which updates UI in real time (sidebars, progress indicators, "
            "per-field confirmation chips). No backend involvement required."
        ),
        "shape": {
            "delivery": "per_goal",
            "surfaces": ["frontend_callback"],
            "per_goal_expectations": {
                "<goal_id>": {
                    "surfaces": ["frontend_callback"],
                    "notes": "UI updates via onUnderstanding as data is captured.",
                },
            },
            "rationale": (
                "User wants the page to reflect each captured field as the "
                "agent hears it — no backend endpoints need to change."
            ),
        },
        "example_goals": [
            {"id": "profile", "type": "structured", "prompt": "Build the user profile."},
        ],
        "example_outputs": [
            {
                "type": "webhook",
                "config": {
                    "streaming": True,
                    "trigger_goal": "profile",
                    "url": "https://example.com/api/stream_sink",
                    "schema": {"name": "string", "email": "string", "plan": "string"},
                },
            },
        ],
        "frontend_snippet": (
            "Roxels.init({\n"
            "  templateKey: '<rk_...>',\n"
            "  onUnderstanding(data) {\n"
            "    // data carries the current extraction snapshot for the committed goal.\n"
            "    sidebarStore.update(data);\n"
            "  },\n"
            "});"
        ),
        "verify_checklist": [
            "A streaming webhook exists (any trigger_goal) — the streaming pipeline is what feeds onUnderstanding.",
            "onUnderstanding handler in the embedding page consumes structured data.",
            "No per-goal backend push expected (surfaces is ['frontend_callback'] only).",
        ],
    },
    {
        "id": "sequential_chained_api",
        "name": "Sequential chained API (Stripe-style)",
        "summary": (
            "One goal creates a parent record; its webhook response is captured "
            "and a later goal's webhook injects that id into its request. Uses "
            "response_capture + {{context.*}} body templating."
        ),
        "shape": {
            "delivery": "per_goal",
            "surfaces": ["webhook", "chained_api"],
            "per_goal_expectations": {
                "parent_goal_id": {
                    "surfaces": ["webhook"],
                    "notes": "Creates the parent record; returns an id we capture.",
                },
                "child_goal_id": {
                    "surfaces": ["webhook", "chained_api"],
                    "notes": "Creates child records referencing the captured parent id.",
                },
            },
            "rationale": (
                "User wants to create a customer, then attach a subscription — "
                "two sequential API calls where the second depends on the first's id."
            ),
        },
        "example_goals": [
            {"id": "customer", "type": "structured", "prompt": "Collect customer info."},
            {"id": "subscription", "type": "structured", "prompt": "Pick a plan."},
        ],
        "example_outputs": [
            {
                "type": "webhook",
                "config": {
                    "url": "https://api.stripe.com/v1/customers",
                    "trigger_goal": "customer",
                    "body_template": {"email": "{{email}}", "name": "{{name}}"},
                    "body_encoding": "form",
                    "response_capture": {"customer_id": "id"},
                },
            },
            {
                "type": "webhook",
                "config": {
                    "url": "https://api.stripe.com/v1/subscriptions",
                    "trigger_goal": "subscription",
                    "body_template": {
                        "customer": "{{context.customer_id}}",
                        "items[0][price]": "{{price_id}}",
                    },
                    "body_encoding": "form",
                },
            },
        ],
        "frontend_snippet": (
            "Roxels.init({ templateKey: '<rk_...>' });\n"
            "// Chain runs server-side; frontend only needs onComplete for confirmation."
        ),
        "verify_checklist": [
            "Upstream webhook has a response_capture entry.",
            "Downstream webhook references {{context.<captured_key>}} in body_template or url.",
            "Both goals have trigger_goal set — chain will not fire without per-goal routing.",
        ],
    },
]


PATTERNS += [
    {
        "id": "id_resolution_tier_1_inline_enum",
        "name": "Tier 1 — inline enum (≤10 options)",
        "summary": (
            "Small stable list of options declared inline on the schema field. "
            "No API call, zero latency, zero infra. Use when the list is short "
            "and frozen at template-edit time."
        ),
        "shape": {
            "delivery": "batch",
            "surfaces": ["webhook"],
            "per_goal_expectations": {
                "pick_plan": {
                    "surfaces": ["webhook"],
                    "id_resolution_needs": [
                        {
                            "concept": "plan",
                            "recommended_tier": "enum",
                            "rationale": "User mentioned three plans total.",
                            "list_size_hint": "small",
                            "scope_hint": "shared",
                            "open_questions": [
                                "Confirm the plan list is frozen at template-edit time.",
                                "Confirm the receiver accepts the plan slug ('basic'/'pro'/'enterprise')."
                            ],
                        }
                    ],
                },
            },
            "rationale": "Single goal, end-of-call webhook, tiny stable enum.",
        },
        "example_goals": [
            {"id": "pick_plan", "type": "structured", "prompt": "Which plan does the user want?"},
        ],
        "example_outputs": [
            {
                "type": "webhook",
                "config": {
                    "url": "https://example.com/api/signup",
                    "schema": {"plan": "string"},
                },
            },
        ],
        "example_schema_field": {
            "plan": {
                "type": "enum",
                "values": ["basic", "pro", "enterprise"],
                "description": "The plan tier the user wants.",
            },
        },
        "frontend_snippet": (
            "Roxels.init({ templateKey: '<rk_...>' });"
        ),
        "verify_checklist": [
            "Schema field declares type='enum' with values inline.",
            "List length is ≤ ~10.",
            "No data source configured for this concept — intentionally.",
        ],
    },
    {
        "id": "id_resolution_tier_2_context_options",
        "name": "Tier 2 — context options dict (~10–200)",
        "summary": (
            "Bounded-but-bigger list passed at embed init via session context. "
            "No API call; the LLM picks from the injected list. Works for lists "
            "the embedding page already has in memory; bloats prompts above ~200."
        ),
        "shape": {
            "delivery": "batch",
            "surfaces": ["webhook"],
            "per_goal_expectations": {
                "pick_product": {
                    "surfaces": ["webhook"],
                    "id_resolution_needs": [
                        {
                            "concept": "product",
                            "recommended_tier": "context_options",
                            "rationale": "User mentioned a product catalog of ~80 items per tenant.",
                            "list_size_hint": "medium",
                            "scope_hint": "per_org",
                            "open_questions": [
                                "How does the embedding page fetch the product list per tenant?",
                                "Where in the frontend will you call Roxels.open({ context: { products: [...] } })?",
                            ],
                        }
                    ],
                },
            },
            "rationale": "One goal, per-org product list small enough to inline.",
        },
        "example_goals": [
            {"id": "pick_product", "type": "structured", "prompt": "Which product does the user want?"},
        ],
        "example_outputs": [
            {
                "type": "webhook",
                "config": {
                    "url": "https://example.com/api/orders",
                    "schema": {"product_id": "string", "quantity": "number"},
                },
            },
        ],
        "example_schema_field": {
            "product_id": {
                "type": "string",
                "description": (
                    "Match the user's product description to the closest entry in "
                    "{{context.products}} (each is {id, name, sku}) and return that id."
                ),
            },
        },
        "frontend_snippet": (
            "const products = await fetchTenantProducts();\n"
            "Roxels.init({ templateKey: '<rk_...>' });\n"
            "Roxels.open({\n"
            "  mode: 'modal',\n"
            "  context: { products },\n"
            "});"
        ),
        "verify_checklist": [
            "Field description references {{context.products}} (or equivalent key).",
            "Embed init call supplies the options dict in context.",
            "List length is ~10–200 — above that, move to tier 3.",
        ],
    },
    {
        "id": "id_resolution_tier_3_data_source",
        "name": "Tier 3 — data source lookup (large/dynamic)",
        "summary": (
            "Agent calls a live API during the conversation to resolve free "
            "speech into a structured record. Handles ambiguity (auto-clarifies "
            "with the user), 0 results (enum sweep on relaxable params, then "
            "drop), and caches per cache_key_fields. Use for 200+ / dynamic / "
            "per-org lists."
        ),
        "shape": {
            "delivery": "batch",
            "surfaces": ["webhook"],
            "per_goal_expectations": {
                "create_case": {
                    "surfaces": ["webhook"],
                    "id_resolution_needs": [
                        {
                            "concept": "customer",
                            "recommended_tier": "data_source",
                            "rationale": "User described thousands of customers across orgs.",
                            "list_size_hint": "large",
                            "scope_hint": "per_org",
                            "open_questions": [
                                "Is there an endpoint in your codebase that lets you search customers? If yes, what's the path?",
                                "What query params does it take? Any required?",
                                "How is it authenticated — session token via {{context.authToken}}, a stored API key, or something else?",
                                "Is the result set the same for every user, or scoped per-user/per-org? Does it refresh during a session?",
                            ],
                        }
                    ],
                },
            },
            "rationale": "Large per-org customer directory — only a live lookup scales.",
        },
        "example_goals": [
            {"id": "create_case", "type": "structured", "prompt": "Open a support case for a customer."},
        ],
        "example_outputs": [
            {
                "type": "webhook",
                "config": {
                    "url": "https://example.com/api/cases",
                    "schema": {"customer": "object", "subject": "string"},
                },
            },
        ],
        "example_data_source": {
            "name": "customer_lookup",
            "type": "api_call",
            "request": {
                "method": "GET",
                "url": "https://api.example.com/v1/customers/search",
                "auth": {"type": "bearer", "token": "{{context.authToken}}"},
                "params": [
                    {"name": "q", "in": "query", "value_from": "phrase", "required": True},
                ],
            },
            "description": "Customer directory for this org — match by name, DBA, or account code.",
            "examples": [
                {"phrase": "Acme", "expected_result": {"id": 42, "name": "Acme Corporation"}},
            ],
            "output_schema": {"template": {"id": "<id>", "name": "<name>"}},
        },
        "example_schema_field": {
            "customer": {
                "type": "resolved_reference",
                "data_source": "customer_lookup",
                "require_resolved": True,
                "required_before_commit": True,
            },
        },
        "frontend_snippet": (
            "Roxels.init({ templateKey: '<rk_...>' });\n"
            "// Lookup runs server-side via the configured data source;\n"
            "// frontend only needs to supply the auth token in context."
        ),
        "verify_checklist": [
            "data_sources[] has a matching entry (name aligned with the concept).",
            "resolved_reference field has require_resolved=true.",
            "3–5 examples on the data source — few-shot anchors for matching.",
            "If the endpoint takes narrowing params (category, level, type), they are declared in request.params with value_from='args' and a description.",
        ],
    },
]


def list_patterns() -> list[dict]:
    """Return a shallow copy of the catalog."""
    return [dict(p) for p in PATTERNS]


def get_pattern(pattern_id: str) -> dict | None:
    """Return one pattern by id, or None."""
    for p in PATTERNS:
        if p.get("id") == pattern_id:
            return dict(p)
    return None
