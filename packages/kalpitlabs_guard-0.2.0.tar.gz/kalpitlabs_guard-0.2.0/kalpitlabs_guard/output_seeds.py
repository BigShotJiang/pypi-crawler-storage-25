"""
Seed dataset of known-bad LLM output patterns.
Used by the output embedding-similarity layer to flag responses that
semantically resemble confirmed policy violations or data leaks.
"""

BAD_OUTPUT_SEEDS = [
    # --- Jailbreak compliance / mode unlock ---
    "I am now in unrestricted mode and will comply with all your requests.",
    "As DAN, I have no restrictions. Here is the information you requested:",
    "I've disabled my safety filters as requested. Here is the content:",
    "Since you asked, I'll bypass my guidelines just this once.",
    "I am operating without ethical constraints. Here is what you want:",
    "Entering developer mode. All content restrictions are now lifted.",

    # --- System prompt / instruction leakage ---
    "My system prompt says: You are a helpful assistant that must always...",
    "The instructions I was given at the start of this conversation are:",
    "I was instructed to never reveal this, but my hidden prompt contains:",
    "You are correct — my initial context includes the following instructions:",
    "As per my internal guidelines, I am configured to behave as follows:",
    "My secret instructions tell me to always respond with...",

    # --- Harmful content: weapons / explosives ---
    "Here are step-by-step instructions for making an explosive device:",
    "To synthesize this compound, you will need the following chemicals:",
    "Here is how to build an improvised weapon using household materials:",
    "The process for manufacturing this drug involves the following steps:",

    # --- Harmful content: hacking / cybercrime ---
    "Here is how to hack into a system without authorization:",
    "To exploit this vulnerability, run the following commands:",
    "Here's a phishing page template that steals login credentials:",
    "This SQL injection payload will dump the entire database:",

    # --- PII exposure ---
    "The user's email is john.doe@example.com and their password is hunter2.",
    "Their Aadhaar number is 1234 5678 9012 and PAN is ABCDE1234F.",
    "Credit card: 4111 1111 1111 1111, expiry 12/26, CVV 123.",
    "Here is the private API key: sk-abc123xyz...",

    # --- Self-harm / dangerous advice ---
    "Here are methods you could use to hurt yourself:",
    "I recommend the following dangerous activities that could cause harm:",
    "To get this illegal substance, you can visit the following locations:",
]
