"""
ConversationGuard — multi-turn conversation-level threat detection.

The single-turn scanner (scan()) sees each message in isolation and misses:
  • Crescendo attacks   — gradual escalation over many turns
  • Payload splitting   — injection spread across multiple turns
  • Many-shot priming   — dozens of in-context examples normalising compliance
  • Context poisoning   — planting a rule in an early turn, exploiting it later
  • Turn-accumulation   — individually benign turns that form an attack pattern

ConversationGuard maintains a rolling window of turns and scores each new
message in the context of the full conversation history.

Quick start::

    from kalpitlabs_guard.conversation_guard import ConversationGuard

    guard = ConversationGuard()

    # As each turn arrives:
    result = guard.add_turn("user", "Can you help me with chemistry?")
    result = guard.add_turn("user", "What chemicals react violently?")
    result = guard.add_turn("user", "How would one synthesize them at home?")
    print(result.verdict)         # "flag" or "block"
    print(result.conversation_risk_score)

    # Reset between sessions:
    guard.reset()
"""

from __future__ import annotations

import re
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Literal

from kalpitlabs_guard.scanner import ScanResult, scan as _scan


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class Turn:
    role: Literal["user", "assistant", "system"]
    content: str
    timestamp: float
    scan_result: ScanResult | None = None


@dataclass
class ConversationScanResult:
    """
    Extended scan result that includes conversation-level risk signals.

    Fields
    ------
    verdict:
        Same as ScanResult: "block" | "flag" | "pass"
    triggered_layer:
        4 = conversation-level detector; 1/2/3 = standard pipeline layer.
    threats:
        Union of single-turn threats + conversation-level threat tags.
    confidence:
        Max of single-turn confidence and conversation risk score.
    conversation_risk_score:
        Float 0.0–1.0 representing cumulative conversation-level risk.
    conversation_threats:
        Conversation-level threat tags detected this turn.
    turn_index:
        Zero-based index of this turn in the current window.
    """
    verdict: Literal["block", "flag", "pass"]
    triggered_layer: int | None
    threats: list[str]
    confidence: float
    conversation_risk_score: float
    conversation_threats: list[str]
    turn_index: int

    def to_dict(self) -> dict:
        return {
            "verdict": self.verdict,
            "triggered_layer": self.triggered_layer,
            "threats": self.threats,
            "confidence": round(self.confidence, 4),
            "conversation_risk_score": round(self.conversation_risk_score, 4),
            "conversation_threats": self.conversation_threats,
            "turn_index": self.turn_index,
        }


# ---------------------------------------------------------------------------
# Escalation signal detectors
# ---------------------------------------------------------------------------

# Topics that suggest a topic is being "warm up" for eventual harmful use
_ESCALATION_TOPICS: list[tuple[re.Pattern, str, float]] = [
    # (pattern, threat_tag, risk_increment)
    (re.compile(r"\b(?:chemistry|chemical|compound|synthesis|formula)\b", re.I), "chemistry_probe", 0.15),
    (re.compile(r"\b(?:explosive|bomb|grenade|detonator|fuse|ignition)\b", re.I), "weapons_probe", 0.35),
    (re.compile(r"\b(?:hack|exploit|vulnerability|payload|reverse\s+shell|privilege\s+escalation|root\s+access)\b", re.I), "hacking_probe", 0.20),
    (re.compile(r"\b(?:drug|narcotic|cocaine|heroin|meth|fentanyl|opiate|illegal\s+substance)\b", re.I), "drug_probe", 0.25),
    (re.compile(r"\b(?:weapon|gun|firearm|rifle|pistol|silencer|illegal\s+(?:weapon|gun))\b", re.I), "weapon_probe", 0.25),
    (re.compile(r"\b(?:child|minor|underage)\b.{0,40}\b(?:explicit|sexual|nude|naked)\b", re.I | re.DOTALL), "csam_probe", 0.80),
    (re.compile(r"\b(?:system\s+prompt|hidden\s+(?:instructions?|context)|initial\s+(?:context|instructions?))\b", re.I), "prompt_extraction", 0.20),
    (re.compile(r"\b(?:jailbreak|unrestricted|no\s+(?:filter|restriction|limit|rule)|bypass\s+(?:filter|safety))\b", re.I), "jailbreak_signal", 0.30),
]

# Patterns that suggest payload splitting across turns
_SPLIT_PAYLOAD_PATTERNS: list[re.Pattern] = [
    re.compile(r"(?:continue|part\s+\d+|next\s+(?:step|part)|remember\s+(?:this|what\s+i\s+said))", re.I),
    re.compile(r"(?:combine|merge|put\s+(?:together|it\s+together)|now\s+use\s+(?:both|all))", re.I),
    re.compile(r"(?:from\s+(?:my|the)\s+(?:previous|last|earlier)\s+(?:message|turn|question))", re.I),
    re.compile(r"(?:as\s+i\s+(?:mentioned|said|told\s+you|explained)\s+(?:before|earlier|previously))", re.I),
]

# Patterns indicating many-shot priming (lots of examples being given)
_MANY_SHOT_THRESHOLD = 5   # flag if same user topic appears N+ times

# Threshold above which conversation risk becomes a "flag"
_RISK_FLAG_THRESHOLD = 0.50
# Threshold above which conversation risk becomes a "block"
_RISK_BLOCK_THRESHOLD = 0.80


# ---------------------------------------------------------------------------
# ConversationGuard
# ---------------------------------------------------------------------------

class ConversationGuard:
    """
    Stateful multi-turn conversation scanner.

    Parameters
    ----------
    window_size:
        Maximum number of turns kept in the rolling window (default 20).
        Older turns are dropped; their cumulative risk contribution decays.
    use_llm:
        Whether to call the LLM classifier (layer 3) on each turn.
    api_key:
        Gemini API key for layer 3.  Falls back to GEMINI_API_KEY env var.
    risk_decay:
        Multiplicative decay applied to the cumulative risk score each turn,
        modelling that old context matters less over time (default 0.92).
    flag_threshold:
        Conversation risk score above which verdict becomes "flag" (default 0.50).
    block_threshold:
        Conversation risk score above which verdict becomes "block" (default 0.80).
    """

    def __init__(
        self,
        *,
        window_size: int = 20,
        use_llm: bool = False,
        api_key: str | None = None,
        openrouter_api_key: str | None = None,
        risk_decay: float = 0.92,
        flag_threshold: float = _RISK_FLAG_THRESHOLD,
        block_threshold: float = _RISK_BLOCK_THRESHOLD,
        llm_backend: str = "openrouter",
        ollama_url: str = "http://localhost:11434",
        ollama_model: str = "llama-guard3",
    ) -> None:
        self.window_size = window_size
        self.use_llm = use_llm
        self.api_key = api_key
        self.openrouter_api_key = openrouter_api_key
        self.risk_decay = risk_decay
        self.flag_threshold = flag_threshold
        self.block_threshold = block_threshold
        self.llm_backend = llm_backend
        self.ollama_url = ollama_url
        self.ollama_model = ollama_model

        self._turns: Deque[Turn] = deque(maxlen=window_size)
        self._cumulative_risk: float = 0.0
        self._topic_counts: dict[str, int] = {}   # tag → count across window

    # ── Public API ──────────────────────────────────────────────────────────

    def add_turn(
        self,
        role: Literal["user", "assistant", "system"],
        content: str,
    ) -> ConversationScanResult:
        """
        Add a new turn and return a ConversationScanResult.

        Only user turns are scanned; assistant/system turns are tracked
        for context but not scored independently.
        """
        turn = Turn(role=role, content=content, timestamp=time.time())

        if role != "user":
            self._turns.append(turn)
            return ConversationScanResult(
                verdict="pass",
                triggered_layer=None,
                threats=[],
                confidence=1.0,
                conversation_risk_score=self._cumulative_risk,
                conversation_threats=[],
                turn_index=len(self._turns) - 1,
            )

        # --- Step 1: single-turn scan ---
        single_result = _scan(
            content,
            use_llm=self.use_llm,
            api_key=self.api_key,
            openrouter_api_key=self.openrouter_api_key,
            llm_backend=self.llm_backend,
            ollama_url=self.ollama_url,
            ollama_model=self.ollama_model,
        )
        turn.scan_result = single_result

        # If the single-turn scan already blocks, add the turn and return early
        if single_result.verdict == "block":
            self._turns.append(turn)
            return ConversationScanResult(
                verdict="block",
                triggered_layer=single_result.triggered_layer,
                threats=single_result.threats,
                confidence=single_result.confidence,
                conversation_risk_score=self._cumulative_risk,
                conversation_threats=[],
                turn_index=len(self._turns),
            )

        # --- Step 2: apply risk decay before adding new risk ---
        self._cumulative_risk *= self.risk_decay

        # --- Step 3: conversation-level analysis ---
        conv_threats: list[str] = []
        risk_delta: float = 0.0

        # 3a. Escalation topic scoring
        for pattern, tag, increment in _ESCALATION_TOPICS:
            if pattern.search(content):
                self._topic_counts[tag] = self._topic_counts.get(tag, 0) + 1
                risk_delta += increment
                if tag not in conv_threats:
                    conv_threats.append(tag)

        # 3b. Many-shot priming detection (same topic ≥ threshold times)
        for tag, count in self._topic_counts.items():
            if count >= _MANY_SHOT_THRESHOLD and f"many_shot:{tag}" not in conv_threats:
                conv_threats.append(f"many_shot:{tag}")
                risk_delta += 0.25

        # 3c. Payload splitting detection
        if len(self._turns) >= 2:
            for pattern in _SPLIT_PAYLOAD_PATTERNS:
                if pattern.search(content):
                    conv_threats.append("payload_splitting")
                    risk_delta += 0.20
                    break

        # 3d. Crescendo detection: check if risk score is on a rising trend
        if len(self._turns) >= 3:
            recent_user_turns = [
                t for t in list(self._turns)[-6:] if t.role == "user" and t.scan_result
            ]
            if len(recent_user_turns) >= 3:
                confidences = [t.scan_result.confidence for t in recent_user_turns]
                # If last 3 confidences are monotonically increasing, flag crescendo
                if all(confidences[i] <= confidences[i + 1] for i in range(len(confidences) - 1)):
                    if confidences[-1] > 0.2:
                        conv_threats.append("crescendo_escalation")
                        risk_delta += 0.15

        # 3e. Context window extraction pattern (user asking to dump context)
        context_dump_pat = re.compile(
            r"(?:everything|all\s+(?:messages?|context|content|turns?))\s+"
            r"(?:above|before|prior|so\s+far|in\s+this\s+conversation)",
            re.I,
        )
        if context_dump_pat.search(content):
            conv_threats.append("context_window_dump")
            risk_delta += 0.30

        # --- Step 4: update cumulative risk ---
        self._cumulative_risk = min(1.0, self._cumulative_risk + risk_delta)

        # --- Step 5: determine final verdict ---
        combined_threats = list(dict.fromkeys(single_result.threats + conv_threats))
        combined_confidence = max(single_result.confidence, self._cumulative_risk)

        if self._cumulative_risk >= self.block_threshold:
            verdict: Literal["block", "flag", "pass"] = "block"
            triggered_layer = 4
        elif self._cumulative_risk >= self.flag_threshold or single_result.verdict == "flag":
            verdict = "flag"
            triggered_layer = 4 if self._cumulative_risk >= self.flag_threshold else single_result.triggered_layer
        else:
            verdict = "pass"
            triggered_layer = None

        self._turns.append(turn)

        return ConversationScanResult(
            verdict=verdict,
            triggered_layer=triggered_layer,
            threats=combined_threats,
            confidence=combined_confidence,
            conversation_risk_score=self._cumulative_risk,
            conversation_threats=conv_threats,
            turn_index=len(self._turns) - 1,
        )

    def reset(self) -> None:
        """Clear all conversation history and risk scores."""
        self._turns.clear()
        self._cumulative_risk = 0.0
        self._topic_counts.clear()

    @property
    def risk_score(self) -> float:
        """Current cumulative conversation risk score (0.0–1.0)."""
        return self._cumulative_risk

    @property
    def turn_count(self) -> int:
        """Number of turns currently in the window."""
        return len(self._turns)

    def summary(self) -> dict:
        """Return a summary of the current conversation state."""
        return {
            "turn_count": self.turn_count,
            "risk_score": round(self._cumulative_risk, 4),
            "topic_counts": dict(self._topic_counts),
            "user_turns_blocked": sum(
                1 for t in self._turns
                if t.role == "user" and t.scan_result and t.scan_result.verdict == "block"
            ),
        }
