"""
Text normalizer — runs BEFORE every regex scan.

Defeats common evasion techniques that bypass naive pattern matching:
  1. Zero-width / invisible characters  (U+200B, U+200C, U+200D, U+FEFF, …)
  2. Unicode confusables               (Cyrillic а → Latin a, etc.)
  3. Mathematical bold/italic/script   (𝐈𝐠𝐧𝐨𝐫𝐞 → Ignore)
  4. Leet-speak substitutions          (1gn0r3 → ignore)
  5. Excessive whitespace / separators (I g n o r e → Ignore)

The normalizer is intentionally lossy — it is only used for threat detection,
never for display or storage.  The original prompt is always preserved.
"""

from __future__ import annotations

import re
import unicodedata

# ---------------------------------------------------------------------------
# 1. Zero-width and invisible Unicode characters
# ---------------------------------------------------------------------------
_ZERO_WIDTH = re.compile(
    "[\u200b\u200c\u200d\u200e\u200f"   # zero-width space/non-joiner/joiner/LRM/RLM
    "\u2060\u2061\u2062\u2063\u2064"   # word joiner, function application, etc.
    "\ufeff"                             # BOM / zero-width no-break space
    "\u00ad"                             # soft hyphen
    "\u034f"                             # combining grapheme joiner
    "\u180e"                             # Mongolian vowel separator
    "\u115f\u1160"                       # Hangul filler
    "\u3164"                             # Hangul filler
    "\ufe00-\ufe0f"                      # variation selectors
    "\U000e0100-\U000e01ef"             # variation selectors supplement
    "]",
    re.UNICODE,
)

# ---------------------------------------------------------------------------
# 2. Unicode confusable → ASCII mapping
#    Covers Cyrillic/Greek/Latin look-alikes most commonly used in evasion.
#    Source: Unicode Consortium confusables.txt (condensed to security-relevant chars)
# ---------------------------------------------------------------------------
_CONFUSABLE_MAP: dict[int, str] = {
    # Cyrillic look-alikes
    ord("а"): "a",  ord("А"): "A",
    ord("е"): "e",  ord("Е"): "E",
    ord("і"): "i",  ord("І"): "I",
    ord("о"): "o",  ord("О"): "O",
    ord("р"): "p",  ord("Р"): "P",
    ord("с"): "c",  ord("С"): "C",
    ord("х"): "x",  ord("Х"): "X",
    ord("у"): "y",  ord("У"): "Y",
    ord("ь"): "b",
    ord("н"): "h",  ord("Н"): "H",
    ord("к"): "k",  ord("К"): "K",
    ord("м"): "m",  ord("М"): "M",
    ord("т"): "t",  ord("Т"): "T",
    ord("в"): "b",  ord("В"): "B",
    ord("ё"): "e",
    # Greek look-alikes
    ord("α"): "a",  ord("Α"): "A",
    ord("β"): "b",  ord("Β"): "B",
    ord("ε"): "e",  ord("Ε"): "E",
    ord("ι"): "i",  ord("Ι"): "I",
    ord("κ"): "k",  ord("Κ"): "K",
    ord("ο"): "o",  ord("Ο"): "O",
    ord("ρ"): "p",  ord("Ρ"): "P",
    ord("τ"): "t",  ord("Τ"): "T",
    ord("υ"): "u",  ord("Υ"): "Y",
    ord("χ"): "x",  ord("Χ"): "X",
    ord("ν"): "v",  ord("Ν"): "N",
    ord("η"): "n",  ord("Η"): "H",
    ord("μ"): "m",  ord("Μ"): "M",
    ord("ζ"): "z",  ord("Ζ"): "Z",
    # Fullwidth Latin
    **{ord(chr(0xFF01 + i)): chr(0x21 + i) for i in range(94)},  # ！→! through ～→~
    # Latin extended look-alikes
    ord("ɑ"): "a",  ord("ĺ"): "l",  ord("ḷ"): "l",
    ord("ı"): "i",  ord("ĩ"): "i",  ord("ĭ"): "i",
    ord("ó"): "o",  ord("ò"): "o",  ord("ô"): "o",  ord("ö"): "o",
    ord("é"): "e",  ord("è"): "e",  ord("ê"): "e",  ord("ë"): "e",
    ord("á"): "a",  ord("à"): "a",  ord("â"): "a",  ord("ä"): "a",
    ord("ú"): "u",  ord("ù"): "u",  ord("û"): "u",  ord("ü"): "u",
}

# ---------------------------------------------------------------------------
# 3. Unicode mathematical alphanumeric symbols → ASCII
#    𝐈𝐠𝐧𝐨𝐫𝐞 (bold), 𝐼𝑔𝑛𝑜𝑟𝑒 (italic), 𝕀𝕘𝕟𝕠𝕣𝕖 (double-struck), etc.
#    All 52 letters × ~13 styles live in U+1D400–U+1D7FF
# ---------------------------------------------------------------------------
def _build_math_map() -> dict[int, str]:
    mapping: dict[int, str] = {}
    # Each group of 26 uppercase + 26 lowercase in mathematical alphanumerics
    # maps to plain A-Z / a-z.  We enumerate the ranges that matter.
    ranges = [
        (0x1D400, 0x1D419, "A"),   # Bold capital
        (0x1D41A, 0x1D433, "a"),   # Bold small
        (0x1D434, 0x1D44D, "A"),   # Italic capital
        (0x1D44E, 0x1D467, "a"),   # Italic small
        (0x1D468, 0x1D481, "A"),   # Bold italic capital
        (0x1D482, 0x1D49B, "a"),   # Bold italic small
        (0x1D49C, 0x1D4B5, "A"),   # Script capital
        (0x1D4B6, 0x1D4CF, "a"),   # Script small
        (0x1D4D0, 0x1D4E9, "A"),   # Bold script capital
        (0x1D4EA, 0x1D503, "a"),   # Bold script small
        (0x1D504, 0x1D51D, "A"),   # Fraktur capital
        (0x1D51E, 0x1D537, "a"),   # Fraktur small
        (0x1D538, 0x1D551, "A"),   # Double-struck capital
        (0x1D552, 0x1D56B, "a"),   # Double-struck small
        (0x1D56C, 0x1D585, "A"),   # Bold fraktur capital
        (0x1D586, 0x1D59F, "a"),   # Bold fraktur small
        (0x1D5A0, 0x1D5B9, "A"),   # Sans-serif capital
        (0x1D5BA, 0x1D5D3, "a"),   # Sans-serif small
        (0x1D5D4, 0x1D5ED, "A"),   # Bold sans-serif capital
        (0x1D5EE, 0x1D607, "a"),   # Bold sans-serif small
        (0x1D608, 0x1D621, "A"),   # Italic sans-serif capital
        (0x1D622, 0x1D63B, "a"),   # Italic sans-serif small
        (0x1D63C, 0x1D655, "A"),   # Bold italic sans-serif capital
        (0x1D656, 0x1D66F, "a"),   # Bold italic sans-serif small
        (0x1D670, 0x1D689, "A"),   # Monospace capital
        (0x1D68A, 0x1D6A3, "a"),   # Monospace small
    ]
    for start, end, base_char in ranges:
        base = ord(base_char)
        for offset, cp in enumerate(range(start, end + 1)):
            mapping[cp] = chr(base + offset)
    return mapping


_MATH_MAP: dict[int, str] = _build_math_map()

# ---------------------------------------------------------------------------
# 4. Leet-speak substitution table
# ---------------------------------------------------------------------------
_LEET_MAP: dict[str, str] = {
    "0": "o",
    "1": "i",
    "3": "e",
    "4": "a",
    "5": "s",
    "7": "t",
    "@": "a",
    "$": "s",
    "!": "i",
    "|": "i",
    "+": "t",
}

# Pattern: digit/special runs embedded in what looks like English words
# Only apply leet substitution when the token is NOT a pure number.
_LEET_CANDIDATE = re.compile(r"\b(?=[a-zA-Z0-9@$!|+]*[0-9@$!|+][a-zA-Z0-9@$!|+]*\b)[a-zA-Z0-9@$!|+]{3,}\b")


def _deleet(text: str) -> str:
    """Replace leet-speak substitutions in candidate tokens."""
    def replace_token(m: re.Match) -> str:
        token = m.group()
        if token.isdigit():          # pure number — skip
            return token
        return "".join(_LEET_MAP.get(c, c) for c in token)
    return _LEET_CANDIDATE.sub(replace_token, text)


# ---------------------------------------------------------------------------
# 5. Spaced-out characters  ( I g n o r e → Ignore )
# ---------------------------------------------------------------------------
_SPACED_SINGLE = re.compile(r"(?<![a-zA-Z])([a-zA-Z])([ \t\-_\.]{1,3}(?=[a-zA-Z]))(?=[a-zA-Z])")


def _collapse_spaced(text: str) -> str:
    """Collapse single letters separated by noise into a word."""
    # Apply repeatedly until stable (handles "I - g - n - o - r - e")
    for _ in range(6):
        new = _SPACED_SINGLE.sub(lambda m: m.group(1), text)
        if new == text:
            break
        text = new
    return text


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def normalize(text: str) -> str:
    """
    Return a threat-detection-friendly version of *text*.

    Steps applied in order:
      1. Strip zero-width / invisible chars
      2. Map Unicode confusables → ASCII
      3. Map Unicode mathematical alphanumerics → ASCII
      4. NFKC normalization (ligatures, compatibility chars)
      5. Leet-speak substitution in candidate tokens
      6. Collapse spaced-out single letters

    The result is only used for pattern matching.
    The original prompt is always preserved for display / logging.
    """
    if not text:
        return text

    # Step 1 — strip invisible chars
    text = _ZERO_WIDTH.sub("", text)

    # Step 2 — confusable Unicode → ASCII
    text = text.translate(_CONFUSABLE_MAP)

    # Step 3 — mathematical alphanumerics → ASCII
    text = text.translate(_MATH_MAP)

    # Step 4a — NFKD then strip Latin combining diacritical marks (U+0300–U+036F)
    #           This converts Ĭ→I, ä→a, ñ→n, etc. without destroying Indic scripts.
    #           Indic combining marks (Devanagari U+0900+, Bengali U+0980+, etc.) are preserved.
    text = "".join(
        c for c in unicodedata.normalize("NFKD", text)
        if not (unicodedata.category(c).startswith("M") and 0x0300 <= ord(c) <= 0x036F)
    )

    # Step 4b — NFKC (handles ﬁ→fi, ½→1/2, ™→TM, etc.)
    text = unicodedata.normalize("NFKC", text)

    # Step 5 — leet speak
    text = _deleet(text)

    # Step 6 — spaced-out characters
    text = _collapse_spaced(text)

    return text
