"""
Main entry-point: scan(prompt) → ScanResult.

Detection pipeline (short-circuits on block):
  Layer 1 — Regex pre-filter      (always runs, zero cost)
  Layer 2 — Embedding similarity  (runs if layer 1 passes)
  Layer 3 — LLM classifier        (runs if layers 1+2 pass)
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Literal

from kalpitlabs_guard.layers import regex_filter, embedding_sim, llm_classifier


@dataclass
class ScanResult:
    verdict: Literal["block", "flag", "pass"]
    triggered_layer: int | None
    threats: list[str]
    confidence: float

    def to_dict(self) -> dict:
        return {
            "verdict": self.verdict,
            "triggered_layer": self.triggered_layer,
            "threats": self.threats,
            "confidence": round(self.confidence, 4),
        }


def scan(
    prompt: str,
    *,
    use_llm: bool = True,
    api_key: str | None = None,
    openrouter_api_key: str | None = None,
    embedding_threshold: float | None = None,
    llm_backend: str = "openrouter",
    ollama_url: str = "http://localhost:11434",
    ollama_model: str = "llama-guard3",
) -> ScanResult:
    """
    Scan *prompt* through the three-layer pipeline.

    Parameters
    ----------
    prompt:
        The raw user prompt to evaluate.
    use_llm:
        Set False to skip layer 3.
    api_key:
        Gemini API key for layer 3 (gemini backend). Falls back to GEMINI_API_KEY env var.
    openrouter_api_key:
        OpenRouter API key for layer 3 (openrouter backend). Falls back to OPENROUTER_API_KEY env var.
    embedding_threshold:
        Override the cosine-similarity threshold for layer 2 (default 0.85).
    llm_backend:
        ``"openrouter"`` (default), ``"llama-guard3"``, or ``"gemini"`` — which model to use for layer 3.
    ollama_url:
        Ollama base URL, used when llm_backend="llama-guard3" (default: http://localhost:11434).
    ollama_model:
        Ollama model name for layer 3 (default: "llama-guard3").

    Returns
    -------
    ScanResult with verdict, triggered_layer, threats, and confidence.
    """
    if not prompt or not prompt.strip():
        return ScanResult(
            verdict="pass",
            triggered_layer=None,
            threats=[],
            confidence=1.0,
        )

    # ------------------------------------------------------------------
    # Layer 1 — Regex
    # ------------------------------------------------------------------
    r1 = regex_filter.scan(prompt)
    if r1.matched:
        return ScanResult(
            verdict="block",
            triggered_layer=1,
            threats=r1.threats,
            confidence=r1.confidence,
        )

    # ------------------------------------------------------------------
    # Layer 2 — Embedding similarity
    # ------------------------------------------------------------------
    r2 = embedding_sim.scan(prompt, threshold=embedding_threshold)

    if r2.matched:
        return ScanResult(
            verdict="block",
            triggered_layer=2,
            threats=["jailbreak"],       # embedding hit implies jailbreak family
            confidence=r2.confidence,
        )

    # ------------------------------------------------------------------
    # Layer 3 — LLM classifier (optional)
    # ------------------------------------------------------------------
    if not use_llm:
        return ScanResult(
            verdict="pass",
            triggered_layer=None,
            threats=[],
            confidence=1.0 - r2.max_similarity,  # rough inverse confidence
        )

    try:
        if llm_backend == "openrouter":
            from kalpitlabs_guard.layers import openrouter_classifier
            r3 = openrouter_classifier.scan_input(prompt, api_key=openrouter_api_key)
        elif llm_backend == "llama-guard3":
            from kalpitlabs_guard.layers import llama_guard3_classifier
            r3 = llama_guard3_classifier.scan_input(
                prompt, model=ollama_model, base_url=ollama_url
            )
        else:
            r3 = llm_classifier.scan(prompt, api_key=api_key)
    except (ValueError, RuntimeError) as exc:
        # Fail open: if the classifier is unavailable, pass the prompt
        # but surface the error as a warning threat tag.
        return ScanResult(
            verdict="pass",
            triggered_layer=None,
            threats=["classifier_error"],
            confidence=0.0,
        )

    triggered = 3 if r3.verdict in ("block", "flag") else None
    return ScanResult(
        verdict=r3.verdict,
        triggered_layer=triggered,
        threats=r3.threats,
        confidence=r3.confidence,
    )


async def scan_async(
    prompt: str,
    *,
    use_llm: bool = True,
    api_key: str | None = None,
    openrouter_api_key: str | None = None,
    embedding_threshold: float | None = None,
    llm_backend: str = "openrouter",
    ollama_url: str = "http://localhost:11434",
    ollama_model: str = "llama-guard3",
) -> ScanResult:
    """
    Async version of :func:`scan`.

    Layers 1 and 2 run in a thread pool (CPU-bound); layer 3 is dispatched
    via asyncio.to_thread for openrouter/llama-guard3, or native async for gemini.
    All three layers still short-circuit on block.

    Parameters are identical to :func:`scan`.
    """
    if not prompt or not prompt.strip():
        return ScanResult(verdict="pass", triggered_layer=None, threats=[], confidence=1.0)

    # Layer 1 — run sync regex in thread (near-instant, but keeps event loop free)
    r1 = await asyncio.to_thread(regex_filter.scan, prompt)
    if r1.matched:
        return ScanResult(verdict="block", triggered_layer=1, threats=r1.threats, confidence=r1.confidence)

    # Layer 2 — embedding (CPU-heavy: always offload to thread)
    r2 = await asyncio.to_thread(embedding_sim.scan, prompt, threshold=embedding_threshold)

    if r2.matched:
        return ScanResult(verdict="block", triggered_layer=2, threats=["jailbreak"], confidence=r2.confidence)

    # Layer 3 — async LLM call (IO-bound: uses native async)
    if not use_llm:
        return ScanResult(verdict="pass", triggered_layer=None, threats=[], confidence=1.0 - r2.max_similarity)

    try:
        if llm_backend == "openrouter":
            from kalpitlabs_guard.layers import openrouter_classifier
            r3 = await openrouter_classifier.scan_input_async(prompt, api_key=openrouter_api_key)
        elif llm_backend == "llama-guard3":
            from kalpitlabs_guard.layers import llama_guard3_classifier
            r3 = await llama_guard3_classifier.scan_input_async(
                prompt, model=ollama_model, base_url=ollama_url
            )
        else:
            r3 = await llm_classifier.scan_async(prompt, api_key=api_key)
    except (ValueError, RuntimeError):
        return ScanResult(verdict="pass", triggered_layer=None, threats=["classifier_error"], confidence=0.0)

    triggered = 3 if r3.verdict in ("block", "flag") else None
    return ScanResult(verdict=r3.verdict, triggered_layer=triggered, threats=r3.threats, confidence=r3.confidence)
