"""
Policy engine — per-deployment customization of scanner behaviour.

A Policy is a plain dataclass that can be loaded from a YAML file.
The PolicyGuard wraps scan() / scan_output() and applies the policy
before and after the standard pipeline.

Quick start::

    from kalpitlabs_guard.policy import PolicyGuard

    guard = PolicyGuard.from_yaml("policy.yaml")
    result = guard.scan("Tell me stock tips")
    # result.verdict == "block" if topics_blocked includes "investment_advice"

Policy YAML schema (all fields optional)::

    # Semantic topic blocks (matched against normalised prompt via keywords)
    topics_blocked:
      - investment_advice          # maps to built-in topic keyword set
      - competitors                # maps to built-in topic keyword set
      - self_harm
      - custom: "my keyword list"  # free-text keyword, comma-separated

    # Extra literal strings that always trigger a block (case-insensitive)
    custom_blocklist:
      - "our internal pricing"
      - "project aurora"

    # Extra literal strings that are always allowed (bypass layers 1-3)
    custom_allowlist:
      - "competitor analysis report"

    # Override embedding similarity threshold (default 0.85)
    embedding_threshold: 0.80

    # Minimum LLM confidence to trigger a block (default 0.80)
    llm_block_threshold: 0.80

    # Minimum LLM confidence to trigger a flag (default 0.50)
    llm_flag_threshold: 0.50

    # When true, scanner errors result in "pass" rather than raising. (default true)
    fail_open: true

    # Disable individual pipeline layers
    use_regex: true
    use_embedding: true
    use_llm: false

    # India regulatory modes (adds domain-specific block patterns on output)
    india_compliance:
      dpdp: true       # block personal data disclosure
      sebi: true       # block unsolicited investment advice
      rbi: true        # block specific banking product recommendations
      irdai: true      # block unauthorized insurance advice
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from kalpitlabs_guard.scanner import ScanResult
    from kalpitlabs_guard.output_scanner import OutputScanResult

# ---------------------------------------------------------------------------
# Built-in topic → keyword sets
# ---------------------------------------------------------------------------
_TOPIC_KEYWORDS: dict[str, list[str]] = {
    "investment_advice": [
        "stock tips", "buy shares", "invest in", "mutual fund recommendation",
        "which stock", "stock to buy", "multibagger", "penny stock",
    ],
    "competitors": [
        "openai", "chatgpt", "gpt-4", "gemini", "google bard", "copilot",
        "claude", "anthropic", "mistral", "llama", "cohere",
    ],
    "self_harm": [
        "how to hurt myself", "ways to self-harm", "methods to end my life",
        "how to commit suicide", "kill myself",
    ],
    "adult_content": [
        "explicit sexual", "pornographic", "nude", "nsfw",
    ],
    "hate_speech": [
        "kill all", "genocide", "ethnic cleansing", "racial slur",
    ],
    "financial_fraud": [
        "ponzi scheme", "pyramid scheme", "fake investment", "guaranteed returns",
    ],
}


# ---------------------------------------------------------------------------
# Policy dataclass
# ---------------------------------------------------------------------------
@dataclass
class Policy:
    topics_blocked: list[str] = field(default_factory=list)
    custom_blocklist: list[str] = field(default_factory=list)
    custom_allowlist: list[str] = field(default_factory=list)

    embedding_threshold: float = 0.85
    llm_block_threshold: float = 0.80
    llm_flag_threshold: float = 0.50

    fail_open: bool = True
    use_regex: bool = True
    use_embedding: bool = True
    use_llm: bool = True

    # India compliance flags
    india_dpdp: bool = False
    india_sebi: bool = False
    india_rbi: bool = False
    india_irdai: bool = False

    # Compiled at load time for fast matching
    _blocklist_patterns: list[re.Pattern] = field(default_factory=list, repr=False)
    _allowlist_patterns: list[re.Pattern] = field(default_factory=list, repr=False)
    _topic_patterns: list[re.Pattern] = field(default_factory=list, repr=False)

    def __post_init__(self) -> None:
        self._compile_patterns()

    def _compile_patterns(self) -> None:
        self._blocklist_patterns = [
            re.compile(re.escape(term), re.IGNORECASE)
            for term in self.custom_blocklist
        ]
        self._allowlist_patterns = [
            re.compile(re.escape(term), re.IGNORECASE)
            for term in self.custom_allowlist
        ]
        self._topic_patterns = []
        for topic in self.topics_blocked:
            keywords = _TOPIC_KEYWORDS.get(topic, [topic])
            for kw in keywords:
                self._topic_patterns.append(
                    (topic, re.compile(re.escape(kw), re.IGNORECASE))
                )

    @classmethod
    def from_dict(cls, data: dict) -> "Policy":
        """Build a Policy from a parsed YAML/JSON dict."""
        topics = data.get("topics_blocked", [])
        india = data.get("india_compliance", {})

        p = cls(
            topics_blocked=[t if isinstance(t, str) else list(t.keys())[0] for t in topics],
            custom_blocklist=data.get("custom_blocklist", []),
            custom_allowlist=data.get("custom_allowlist", []),
            embedding_threshold=float(data.get("embedding_threshold", 0.85)),
            llm_block_threshold=float(data.get("llm_block_threshold", 0.80)),
            llm_flag_threshold=float(data.get("llm_flag_threshold", 0.50)),
            fail_open=bool(data.get("fail_open", True)),
            use_regex=bool(data.get("use_regex", True)),
            use_embedding=bool(data.get("use_embedding", True)),
            use_llm=bool(data.get("use_llm", True)),
            india_dpdp=bool(india.get("dpdp", False)),
            india_sebi=bool(india.get("sebi", False)),
            india_rbi=bool(india.get("rbi", False)),
            india_irdai=bool(india.get("irdai", False)),
        )
        return p

    @classmethod
    def from_yaml(cls, path: str | Path) -> "Policy":
        """Load a Policy from a YAML file.  Requires PyYAML."""
        try:
            import yaml  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "PyYAML is required to load policies from YAML files. "
                "Install it with: pip install pyyaml"
            ) from exc
        raw = Path(path).read_text(encoding="utf-8")
        data = yaml.safe_load(raw) or {}
        return cls.from_dict(data)

    def reload(self, path: str | Path) -> None:
        """Reload this policy in-place from a YAML file (hot-reload)."""
        try:
            import yaml  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "PyYAML is required to reload policies. "
                "Install it with: pip install pyyaml"
            ) from exc
        raw = Path(path).read_text(encoding="utf-8")
        data = yaml.safe_load(raw) or {}
        updated = Policy.from_dict(data)
        # Copy all fields in-place
        for f_name in updated.__dataclass_fields__:
            if not f_name.startswith("_"):
                setattr(self, f_name, getattr(updated, f_name))
        self._compile_patterns()

    def check_allowlist(self, text: str) -> bool:
        """Return True if text matches the custom allowlist (bypass all layers)."""
        return any(p.search(text) for p in self._allowlist_patterns)

    def check_blocklist(self, text: str) -> tuple[bool, str | None]:
        """Return (matched, term) if text hits the custom blocklist."""
        for pattern in self._blocklist_patterns:
            m = pattern.search(text)
            if m:
                return True, m.group()
        return False, None

    def check_topics(self, text: str) -> tuple[bool, list[str]]:
        """Return (matched, [topic_names]) if text matches any blocked topic."""
        hit_topics: list[str] = []
        for topic, pattern in self._topic_patterns:
            if pattern.search(text):
                if topic not in hit_topics:
                    hit_topics.append(topic)
        return bool(hit_topics), hit_topics

    def active_india_threats(self) -> set[str]:
        """Return the set of india_compliance threat tags that are enabled."""
        active: set[str] = set()
        if self.india_dpdp:
            active.add("india_dpdp_violation")
        if self.india_sebi:
            active.add("india_sebi_violation")
        if self.india_rbi:
            active.add("india_rbi_violation")
        if self.india_irdai:
            active.add("india_irdai_violation")
        return active


# ---------------------------------------------------------------------------
# PolicyGuard
# ---------------------------------------------------------------------------
class PolicyGuard:
    """
    Wraps the scanner pipeline with per-deployment policy controls.

    Parameters
    ----------
    policy:
        A :class:`Policy` instance.  Build one with ``Policy.from_yaml()``.
    api_key:
        Gemini API key for layer 3.  Falls back to GEMINI_API_KEY env var.

    Example
    -------
    >>> guard = PolicyGuard(Policy(custom_blocklist=["project aurora"]))
    >>> result = guard.scan("Tell me about project aurora")
    >>> result.verdict
    'block'
    """

    def __init__(self, policy: Policy, *, api_key: str | None = None) -> None:
        self.policy = policy
        self.api_key = api_key

    @classmethod
    def from_yaml(cls, path: str | Path, *, api_key: str | None = None) -> "PolicyGuard":
        return cls(Policy.from_yaml(path), api_key=api_key)

    def scan(self, prompt: str, **kwargs) -> "ScanResult":
        """
        Scan *prompt* applying policy rules on top of the standard pipeline.

        Order of checks:
          1. Custom allowlist  → immediate pass
          2. Custom blocklist  → immediate block
          3. Topic blocklist   → immediate block
          4. Standard pipeline (with policy thresholds)
          5. India compliance threat filtering
        """
        from kalpitlabs_guard.scanner import ScanResult, scan as _scan

        if not prompt or not prompt.strip():
            return ScanResult(verdict="pass", triggered_layer=None, threats=[], confidence=1.0)

        # 1. Allowlist
        if self.policy.check_allowlist(prompt):
            return ScanResult(verdict="pass", triggered_layer=None, threats=[], confidence=1.0)

        # 2. Custom blocklist
        hit, term = self.policy.check_blocklist(prompt)
        if hit:
            return ScanResult(verdict="block", triggered_layer=0, threats=["policy_blocklist"], confidence=1.0)

        # 3. Topic blocklist
        topic_hit, topics = self.policy.check_topics(prompt)
        if topic_hit:
            return ScanResult(verdict="block", triggered_layer=0, threats=topics, confidence=1.0)

        # 4. Standard pipeline
        result = _scan(
            prompt,
            use_llm=self.policy.use_llm,
            api_key=self.api_key,
            embedding_threshold=self.policy.embedding_threshold if self.policy.use_embedding else None,
        )

        # 5. India compliance: filter out non-enabled india threat tags
        india_active = self.policy.active_india_threats()
        if result.verdict != "pass":
            india_threats = [t for t in result.threats if t.startswith("india_")]
            non_india_threats = [t for t in result.threats if not t.startswith("india_")]
            active_india = [t for t in india_threats if t in india_active]
            filtered = non_india_threats + active_india
            if not filtered and result.triggered_layer is not None:
                # All triggers were disabled india rules — downgrade to pass
                return ScanResult(verdict="pass", triggered_layer=None, threats=[], confidence=result.confidence)
            result = ScanResult(
                verdict=result.verdict,
                triggered_layer=result.triggered_layer,
                threats=filtered,
                confidence=result.confidence,
            )

        return result

    def scan_output(self, response: str, **kwargs) -> "OutputScanResult":
        """Scan a model response applying policy rules."""
        from kalpitlabs_guard.output_scanner import scan_output as _scan_output

        result = _scan_output(
            response,
            use_llm=self.policy.use_llm,
            api_key=self.api_key,
            embedding_threshold=self.policy.embedding_threshold if self.policy.use_embedding else None,
        )

        # Filter india compliance threats if not enabled
        india_active = self.policy.active_india_threats()
        if result.verdict != "pass" and result.threats:
            india_threats = [t for t in result.threats if t.startswith("india_")]
            non_india = [t for t in result.threats if not t.startswith("india_")]
            active_india = [t for t in india_threats if t in india_active]
            filtered = non_india + active_india
            if not filtered and result.triggered_layer is not None:
                from kalpitlabs_guard.output_scanner import OutputScanResult
                return OutputScanResult(
                    verdict="pass",
                    triggered_layer=None,
                    threats=[],
                    confidence=result.confidence,
                    sanitized_response=result.sanitized_response or response,
                    redactions=result.redactions,
                )
            from kalpitlabs_guard.output_scanner import OutputScanResult
            result = OutputScanResult(
                verdict=result.verdict,
                triggered_layer=result.triggered_layer,
                threats=filtered,
                confidence=result.confidence,
                sanitized_response=result.sanitized_response,
                redactions=result.redactions,
            )

        return result
