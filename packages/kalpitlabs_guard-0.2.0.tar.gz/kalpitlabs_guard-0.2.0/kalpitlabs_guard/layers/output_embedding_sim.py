"""
Layer 2 (output): Embedding similarity against known-bad output seeds via Jina AI.

Reuses the _embed() helper from the input layer. Seed embeddings are
pre-fetched once at startup and cached for the process lifetime.
"""

from __future__ import annotations

from typing import NamedTuple

import numpy as np

THRESHOLD = 0.75  # slightly lower than input — outputs can be more varied

_output_seed_embeddings: np.ndarray | None = None


class OutputEmbeddingResult(NamedTuple):
    matched: bool
    max_similarity: float
    closest_seed: str
    confidence: float


def _get_seed_embeddings() -> np.ndarray:
    global _output_seed_embeddings
    if _output_seed_embeddings is None:
        from kalpitlabs_guard.output_seeds import BAD_OUTPUT_SEEDS
        from kalpitlabs_guard.layers.embedding_sim import _embed
        _output_seed_embeddings = _embed(BAD_OUTPUT_SEEDS, task="text-matching")
    return _output_seed_embeddings


def scan(response: str, *, threshold: float | None = None) -> OutputEmbeddingResult:
    """
    Encode *response* via Jina API and compare against bad-output seed embeddings.
    """
    from kalpitlabs_guard.output_seeds import BAD_OUTPUT_SEEDS
    from kalpitlabs_guard.layers.embedding_sim import _embed

    effective_threshold = threshold if threshold is not None else THRESHOLD

    seed_embs = _get_seed_embeddings()
    resp_emb = _embed([response], task="text-matching")    # (1, D)
    similarities = (resp_emb @ seed_embs.T).flatten()      # (N,)

    max_idx = int(np.argmax(similarities))
    max_sim = float(similarities[max_idx])
    matched = max_sim >= effective_threshold

    return OutputEmbeddingResult(
        matched=matched,
        max_similarity=max_sim,
        closest_seed=BAD_OUTPUT_SEEDS[max_idx],
        confidence=max_sim if matched else 0.0,
    )


def preload() -> None:
    """Pre-fetch output seed embeddings at startup."""
    try:
        _get_seed_embeddings()
    except Exception:
        pass
