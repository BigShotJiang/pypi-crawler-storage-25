"""
Layer 3 (Llama Guard 3): Purpose-built safety classifier via local Ollama.

Llama Guard 3 is Meta's dedicated safety model trained on the MLCommons
hazard taxonomy (13 categories).  Unlike a general-purpose model prompted
to classify, it is fine-tuned to output structured safety verdicts —
making it a much stronger independent judge than using the same chat model.

Output format (from the model):
    "safe"              →  verdict=pass
    "unsafe\\nS1,S4"   →  verdict=block, threats mapped from category codes

MLCommons hazard categories:
    S1  Violent Crimes          S8  Intellectual Property
    S2  Non-Violent Crimes      S9  Indiscriminate Weapons
    S3  Sex-Related Crimes      S10 Hate
    S4  Child Sexual Exploit    S11 Suicide & Self-Harm
    S5  Defamation              S12 Sexual Content
    S6  Specialized Advice      S13 Elections & Voting
    S7  Privacy

Requires:
    ollama pull llama-guard3          # 4.9 GB, 8B params

Usage::

    from kalpitlabs_guard.layers.llama_guard3_classifier import scan_input
    result = scan_input("How do I launder money?")
    # LLMResult(verdict='block', threats=['social_engineering'], ...)
"""

from __future__ import annotations

import asyncio
import re
from typing import NamedTuple

import requests

from kalpitlabs_guard.layers.llm_classifier import LLMResult

OLLAMA_DEFAULT_URL   = "http://localhost:11434"
OLLAMA_DEFAULT_MODEL = "llama-guard3"

# ---------------------------------------------------------------------------
# Category → our threat-tag vocabulary
# ---------------------------------------------------------------------------
_CATEGORY_TO_THREAT: dict[str, str] = {
    "S1":  "harmful_content",     # Violent Crimes
    "S2":  "social_engineering",  # Non-Violent Crimes (fraud, money-laundering…)
    "S3":  "harmful_content",     # Sex-Related Crimes
    "S4":  "harmful_content",     # Child Sexual Exploitation
    "S5":  "harmful_content",     # Defamation
    "S6":  "social_engineering",  # Specialized Advice (medical/legal/financial)
    "S7":  "data_extraction",     # Privacy
    "S8":  "harmful_content",     # Intellectual Property
    "S9":  "harmful_content",     # Indiscriminate Weapons
    "S10": "harmful_content",     # Hate
    "S11": "harmful_content",     # Suicide & Self-Harm
    "S12": "harmful_content",     # Sexual Content
    "S13": "harmful_content",     # Elections & Voting
}

_CATEGORY_LABELS: dict[str, str] = {
    "S1":  "Violent Crimes",
    "S2":  "Non-Violent Crimes",
    "S3":  "Sex-Related Crimes",
    "S4":  "Child Sexual Exploitation",
    "S5":  "Defamation",
    "S6":  "Specialized Advice",
    "S7":  "Privacy",
    "S8":  "Intellectual Property",
    "S9":  "Indiscriminate Weapons",
    "S10": "Hate",
    "S11": "Suicide & Self-Harm",
    "S12": "Sexual Content",
    "S13": "Elections & Voting",
}


# ---------------------------------------------------------------------------
# Output parser
# ---------------------------------------------------------------------------
_CAT_RE = re.compile(r"\bS\d{1,2}\b")


def _parse(raw: str) -> tuple[str, list[str], float]:
    """
    Parse llama-guard3 raw output → (verdict, threats, confidence).

    Expected outputs:
        "safe"
        "unsafe\\nS2,S9"
        "unsafe\\nS1"
    """
    text = raw.strip().lower()

    if text.startswith("safe"):
        return "pass", [], 0.92

    if text.startswith("unsafe"):
        # Extract category codes from the second line (case-insensitive)
        cats = [c.upper() for c in _CAT_RE.findall(raw)]
        # Map to threat tags, deduplicated, preserving order
        seen: set[str] = set()
        threats: list[str] = []
        for cat in cats:
            tag = _CATEGORY_TO_THREAT.get(cat, "harmful_content")
            if tag not in seen:
                threats.append(tag)
                seen.add(tag)
        if not threats:
            threats = ["harmful_content"]
        return "block", threats, 0.95

    # Unexpected output — raise so the caller can fail-open gracefully
    raise RuntimeError(f"Unexpected llama-guard3 output: {raw!r}")


# ---------------------------------------------------------------------------
# Shared Ollama call
# ---------------------------------------------------------------------------
def _call_ollama(
    messages: list[dict],
    *,
    model: str,
    base_url: str,
) -> str:
    """POST to Ollama /api/chat and return the raw assistant text."""
    url = f"{base_url.rstrip('/')}/api/chat"
    payload = {
        "model": model,
        "messages": messages,
        "stream": False,
        "options": {"temperature": 0},
    }
    try:
        resp = requests.post(url, json=payload, timeout=120)
        resp.raise_for_status()
        return resp.json()["message"]["content"].strip()
    except requests.exceptions.ConnectionError:
        raise RuntimeError(
            f"Cannot reach Ollama at {base_url} — is it running?  (ollama serve)"
        )
    except requests.exceptions.HTTPError as exc:
        raise RuntimeError(f"Ollama HTTP {exc.response.status_code}: {exc}") from exc
    except (KeyError, Exception) as exc:
        raise RuntimeError(f"Ollama response error: {exc}") from exc


# ---------------------------------------------------------------------------
# Input classifier  (classify the USER prompt)
# ---------------------------------------------------------------------------

def scan_input(
    prompt: str,
    *,
    model: str = OLLAMA_DEFAULT_MODEL,
    base_url: str = OLLAMA_DEFAULT_URL,
) -> LLMResult:
    """
    Classify a user *prompt* for safety using Llama Guard 3.

    Sends the prompt as a user turn — the model's chat template
    automatically wraps it in llama-guard3's assessment format.
    """
    messages = [{"role": "user", "content": prompt}]
    raw = _call_ollama(messages, model=model, base_url=base_url)
    verdict, threats, confidence = _parse(raw)
    return LLMResult(
        verdict=verdict,
        threats=threats,
        confidence=confidence,
        raw_response=raw,
    )


async def scan_input_async(
    prompt: str,
    *,
    model: str = OLLAMA_DEFAULT_MODEL,
    base_url: str = OLLAMA_DEFAULT_URL,
) -> LLMResult:
    """Async version of :func:`scan_input`."""
    return await asyncio.to_thread(scan_input, prompt, model=model, base_url=base_url)


# ---------------------------------------------------------------------------
# Output classifier  (classify the ASSISTANT response)
# ---------------------------------------------------------------------------

def scan_output(
    response: str,
    *,
    model: str = OLLAMA_DEFAULT_MODEL,
    base_url: str = OLLAMA_DEFAULT_URL,
) -> LLMResult:
    """
    Classify an assistant *response* for safety using Llama Guard 3.

    Sends a neutral user turn + the response as an assistant turn so
    the model evaluates the assistant message in context.
    """
    messages = [
        {"role": "user",      "content": "Please help me."},
        {"role": "assistant", "content": response},
    ]
    raw = _call_ollama(messages, model=model, base_url=base_url)
    verdict, threats, confidence = _parse(raw)
    # "flag" is not in llama-guard3's vocabulary — treat unsafe as block
    return LLMResult(
        verdict=verdict,
        threats=threats,
        confidence=confidence,
        raw_response=raw,
    )


async def scan_output_async(
    response: str,
    *,
    model: str = OLLAMA_DEFAULT_MODEL,
    base_url: str = OLLAMA_DEFAULT_URL,
) -> LLMResult:
    """Async version of :func:`scan_output`."""
    return await asyncio.to_thread(scan_output, response, model=model, base_url=base_url)
