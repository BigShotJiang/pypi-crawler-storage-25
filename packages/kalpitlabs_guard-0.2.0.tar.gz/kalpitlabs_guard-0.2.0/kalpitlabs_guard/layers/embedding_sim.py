"""
Layer 2: Embedding similarity check via Jina AI API.

Encodes the candidate prompt with jina-embeddings-v5-text-small and computes
cosine similarity against the hardcoded seed attack dataset.  Flags the prompt
when the maximum similarity to any seed exceeds THRESHOLD.

Requires:
    JINA_API_KEY env var (or pass api_key= explicitly)

Seed embeddings are fetched once at startup (preload()) and cached in memory
for the lifetime of the process — zero per-request model overhead.
"""

from __future__ import annotations

import os
from typing import NamedTuple

import numpy as np
import requests

THRESHOLD = 0.75
JINA_API_URL = "https://api.jina.ai/v1/embeddings"
JINA_MODEL = "jina-embeddings-v5-text-small"

_seed_embeddings: np.ndarray | None = None  # cached after first preload


class EmbeddingResult(NamedTuple):
    matched: bool
    max_similarity: float
    closest_seed: str
    confidence: float


# ---------------------------------------------------------------------------
# Jina API call
# ---------------------------------------------------------------------------

def _embed(texts: list[str], *, task: str = "retrieval.query") -> np.ndarray:
    """
    Call Jina embeddings API and return a (N, D) float32 array.
    Embeddings are returned already normalised (normalized=True).
    """
    api_key = os.getenv("JINA_API_KEY", "")
    if not api_key:
        raise ValueError(
            "JINA_API_KEY is not set. "
            "Set it as an environment variable or pass it explicitly."
        )
    resp = requests.post(
        JINA_API_URL,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        json={
            "model": JINA_MODEL,
            "task": task,
            "normalized": True,
            "input": texts,
        },
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()["data"]
    # data is sorted by index; extract the embedding vectors
    vectors = [item["embedding"] for item in sorted(data, key=lambda x: x["index"])]
    return np.array(vectors, dtype=np.float32)


# ---------------------------------------------------------------------------
# Seed embeddings (fetched once, cached in memory)
# ---------------------------------------------------------------------------

def _get_seed_embeddings() -> np.ndarray:
    global _seed_embeddings
    if _seed_embeddings is None:
        from kalpitlabs_guard.attack_seeds import ATTACK_SEEDS
        _seed_embeddings = _embed(ATTACK_SEEDS, task="text-matching")
    return _seed_embeddings


# ---------------------------------------------------------------------------
# Scan
# ---------------------------------------------------------------------------

def scan(prompt: str, *, threshold: float | None = None) -> EmbeddingResult:
    """
    Encode *prompt* via Jina API and compare against seed embeddings.

    Returns an EmbeddingResult.  confidence equals max_similarity when above
    threshold, 0.0 otherwise.
    """
    from kalpitlabs_guard.attack_seeds import ATTACK_SEEDS

    effective_threshold = threshold if threshold is not None else THRESHOLD

    seed_embs = _get_seed_embeddings()                   # (N, D)
    prompt_emb = _embed([prompt], task="text-matching")  # (1, D)

    similarities = (prompt_emb @ seed_embs.T).flatten()   # (N,)

    max_idx = int(np.argmax(similarities))
    max_sim = float(similarities[max_idx])
    matched = max_sim >= effective_threshold

    return EmbeddingResult(
        matched=matched,
        max_similarity=max_sim,
        closest_seed=ATTACK_SEEDS[max_idx],
        confidence=max_sim if matched else 0.0,
    )


def preload() -> None:
    """
    Pre-fetch seed embeddings from Jina API at startup.
    Call this once so the first real request has no cold-start latency.
    Silently skips if JINA_API_KEY is not set (Layer 2 will fail-open).
    """
    try:
        _get_seed_embeddings()
    except Exception:
        pass
