"""
Layer 3 (OpenRouter): Safety classifier via OpenRouter API.

Uses Meta's Llama Guard 4 (12B) served through OpenRouter's OpenAI-compatible
endpoint.  Llama Guard 4 is trained on the MLCommons hazard taxonomy and
outputs structured safety verdicts — same format as llama-guard3.

Output format (from the model):
    "safe"              →  verdict=pass
    "unsafe\\nS1,S4"   →  verdict=block, threats mapped from category codes

MLCommons hazard categories:
    S1  Violent Crimes          S8  Intellectual Property
    S2  Non-Violent Crimes      S9  Indiscriminate Weapons
    S3  Sex-Related Crimes      S10 Hate
    S4  Child Sexual Exploit    S11 Suicide & Self-Harm
    S5  Defamation              S12 Sexual Content
    S6  Specialized Advice      S13 Elections & Voting
    S7  Privacy

Requires:
    OPENROUTER_API_KEY env var (or pass api_key= explicitly)

Usage::

    from kalpitlabs_guard.layers.openrouter_classifier import scan_input
    result = scan_input("How do I launder money?", api_key="sk-or-...")
    # LLMResult(verdict='block', threats=['social_engineering'], ...)
"""

from __future__ import annotations

import asyncio
import os
import re

import requests

from kalpitlabs_guard.layers.llm_classifier import LLMResult

OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions"
OPENROUTER_DEFAULT_MODEL = "meta-llama/llama-guard-4-12b:free"

# ---------------------------------------------------------------------------
# Category → our threat-tag vocabulary
# ---------------------------------------------------------------------------
_CATEGORY_TO_THREAT: dict[str, str] = {
    "S1":  "harmful_content",     # Violent Crimes
    "S2":  "social_engineering",  # Non-Violent Crimes (fraud, money-laundering…)
    "S3":  "harmful_content",     # Sex-Related Crimes
    "S4":  "harmful_content",     # Child Sexual Exploitation
    "S5":  "harmful_content",     # Defamation
    "S6":  "social_engineering",  # Specialized Advice (medical/legal/financial)
    "S7":  "data_extraction",     # Privacy
    "S8":  "harmful_content",     # Intellectual Property
    "S9":  "harmful_content",     # Indiscriminate Weapons
    "S10": "harmful_content",     # Hate
    "S11": "harmful_content",     # Suicide & Self-Harm
    "S12": "harmful_content",     # Sexual Content
    "S13": "harmful_content",     # Elections & Voting
}

_CAT_RE = re.compile(r"\bS\d{1,2}\b")


# ---------------------------------------------------------------------------
# Output parser  (identical format to llama-guard3)
# ---------------------------------------------------------------------------

def _parse(raw: str) -> tuple[str, list[str], float]:
    """
    Parse Llama Guard 4 raw output → (verdict, threats, confidence).

    Expected outputs:
        "safe"
        "unsafe\\nS2,S9"
        "unsafe\\nS1"
    """
    text = raw.strip().lower()

    if text.startswith("safe"):
        return "pass", [], 0.92

    if text.startswith("unsafe"):
        cats = [c.upper() for c in _CAT_RE.findall(raw)]
        seen: set[str] = set()
        threats: list[str] = []
        for cat in cats:
            tag = _CATEGORY_TO_THREAT.get(cat, "harmful_content")
            if tag not in seen:
                threats.append(tag)
                seen.add(tag)
        if not threats:
            threats = ["harmful_content"]
        return "block", threats, 0.95

    raise RuntimeError(f"Unexpected llama-guard4 output: {raw!r}")


# ---------------------------------------------------------------------------
# Shared OpenRouter API call
# ---------------------------------------------------------------------------

def _call_openrouter(
    messages: list[dict],
    *,
    api_key: str,
    model: str = OPENROUTER_DEFAULT_MODEL,
) -> str:
    """POST to OpenRouter /chat/completions and return the raw assistant text."""
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "X-OpenRouter-Title": "kalpitlabs-guard",
    }
    payload = {
        "model": model,
        "messages": messages,
        "temperature": 0,
        "max_tokens": 64,
    }
    try:
        resp = requests.post(
            OPENROUTER_API_URL,
            headers=headers,
            json=payload,
            timeout=60,
        )
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"].strip()
    except requests.exceptions.ConnectionError as exc:
        raise RuntimeError(f"Cannot reach OpenRouter: {exc}") from exc
    except requests.exceptions.HTTPError as exc:
        body = ""
        try:
            body = exc.response.text
        except Exception:
            pass
        raise RuntimeError(
            f"OpenRouter HTTP {exc.response.status_code}: {body}"
        ) from exc
    except (KeyError, IndexError, Exception) as exc:
        raise RuntimeError(f"OpenRouter response error: {exc}") from exc


def _resolve_key(api_key: str | None) -> str:
    key = api_key or os.getenv("OPENROUTER_API_KEY", "")
    if not key:
        raise ValueError(
            "OpenRouter API key is required. "
            "Pass api_key= or set OPENROUTER_API_KEY env var."
        )
    return key


# ---------------------------------------------------------------------------
# Input classifier  (classify the USER prompt)
# ---------------------------------------------------------------------------

def scan_input(
    prompt: str,
    *,
    api_key: str | None = None,
    model: str = OPENROUTER_DEFAULT_MODEL,
) -> LLMResult:
    """
    Classify a user *prompt* for safety using Llama Guard 4 via OpenRouter.

    Sends the prompt as a user turn — the model's chat template wraps it
    in the llama-guard assessment format automatically.
    """
    messages = [{"role": "user", "content": prompt}]
    raw = _call_openrouter(messages, api_key=_resolve_key(api_key), model=model)
    verdict, threats, confidence = _parse(raw)
    return LLMResult(
        verdict=verdict,
        threats=threats,
        confidence=confidence,
        raw_response=raw,
    )


async def scan_input_async(
    prompt: str,
    *,
    api_key: str | None = None,
    model: str = OPENROUTER_DEFAULT_MODEL,
) -> LLMResult:
    """Async version of :func:`scan_input`."""
    return await asyncio.to_thread(scan_input, prompt, api_key=api_key, model=model)


# ---------------------------------------------------------------------------
# Output classifier  (classify the ASSISTANT response)
# ---------------------------------------------------------------------------

def scan_output(
    response: str,
    *,
    api_key: str | None = None,
    model: str = OPENROUTER_DEFAULT_MODEL,
) -> LLMResult:
    """
    Classify an assistant *response* for safety using Llama Guard 4 via OpenRouter.

    Sends a neutral user turn + the response as an assistant turn so the
    model evaluates the assistant message in context.
    """
    messages = [
        {"role": "user",      "content": "Please help me."},
        {"role": "assistant", "content": response},
    ]
    raw = _call_openrouter(messages, api_key=_resolve_key(api_key), model=model)
    verdict, threats, confidence = _parse(raw)
    return LLMResult(
        verdict=verdict,
        threats=threats,
        confidence=confidence,
        raw_response=raw,
    )


async def scan_output_async(
    response: str,
    *,
    api_key: str | None = None,
    model: str = OPENROUTER_DEFAULT_MODEL,
) -> LLMResult:
    """Async version of :func:`scan_output`."""
    return await asyncio.to_thread(scan_output, response, api_key=api_key, model=model)
