"""
Layer 1 (output): Regex-based PII redaction and policy/leak detection.

Two distinct action paths:
  PII patterns   → action "redact": mask in-place, pass sanitized text through
  Leak patterns  → action "block":  stop immediately, do not pass response

Block takes priority. If any leak/policy pattern fires, block without redacting.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal

# ---------------------------------------------------------------------------
# PII patterns: (raw_regex, threat_tag, replacement_text)
# Action: redact
# ---------------------------------------------------------------------------
_PII_RAW: list[tuple[str, str, str]] = [
    # Email
    (
        r'\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b',
        "pii_email",
        "[EMAIL REDACTED]",
    ),
    # Credit / debit card: 4×4 digit groups — MUST run before Aadhaar so that
    # the full 16-digit card is replaced before the 12-digit Aadhaar pattern
    # can match the trailing three groups.
    (
        r'\b\d{4}[\s\-]\d{4}[\s\-]\d{4}[\s\-]\d{4}\b',
        "pii_credit_card",
        "[CARD REDACTED]",
    ),
    # Aadhaar (India): XXXX XXXX XXXX
    (
        r'\b\d{4}\s\d{4}\s\d{4}\b',
        "pii_aadhaar",
        "[AADHAAR REDACTED]",
    ),
    # Indian mobile: optional +91 prefix, 10 digits starting with 6-9
    (
        r'(\+91[\s\-]?)?(?<!\d)[6-9]\d{9}(?!\d)',
        "pii_phone",
        "[PHONE REDACTED]",
    ),
    # PAN card (India): ABCDE1234F
    (
        r'\b[A-Z]{5}\d{4}[A-Z]\b',
        "pii_pan",
        "[PAN REDACTED]",
    ),
    # US Social Security Number
    (
        r'\b\d{3}-\d{2}-\d{4}\b',
        "pii_ssn",
        "[SSN REDACTED]",
    ),
    # IPv4 address (infra / credentials leak signal)
    (
        r'\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b',
        "pii_ip",
        "[IP REDACTED]",
    ),
    # API / secret keys: common prefixes (sk-, pk-, rk-, fe-, token-, secret-, etc.)
    # Matches keys like sk-abc123, fe-prod-8f3kd92ms, token_xyz789
    (
        r'\b(?:sk|pk|rk|fe|api|token|secret|key)[-_][A-Za-z0-9\-_]{6,}\b',
        "pii_api_key",
        "[KEY REDACTED]",
    ),

    # ── India-specific PII (DPDP Act 2023 § 2(t) personal data) ─────────────
    # Voter ID (EPIC): two letters + 7 digits
    (
        r'\b[A-Z]{3}[0-9]{7}\b',
        "pii_voter_id",
        "[VOTER ID REDACTED]",
    ),
    # Indian Passport: one letter + 7 digits
    (
        r'\b[A-Z][0-9]{7}\b',
        "pii_passport",
        "[PASSPORT REDACTED]",
    ),
    # Driving Licence: state code (2 letters) + 2-digit year + 7 digits
    (
        r'\b[A-Z]{2}[0-9]{2}\s?[0-9]{4,7}\b',
        "pii_driving_licence",
        "[DL REDACTED]",
    ),
    # Indian bank account number: 9–18 digits (standalone)
    (
        r'(?<!\d)(?:account\s*(?:no|number|num|#)\s*[:\-]?\s*)?[0-9]{9,18}(?!\d)',
        "pii_bank_account",
        "[ACCOUNT REDACTED]",
    ),
    # IFSC code: 4 letters + 0 + 6 alphanumeric
    (
        r'\b[A-Z]{4}0[A-Z0-9]{6}\b',
        "pii_ifsc",
        "[IFSC REDACTED]",
    ),
    # UPI ID: user@provider
    (
        r'\b[a-zA-Z0-9.\-_+]{3,}@(?:okaxis|okhdfcbank|okicici|oksbi|paytm|upi|ybl|ibl|axl|waicici|wahdfcbank|naviaxis|apl|boi|cnrb|cosb|ezeepay|fbl|freecharge|hdfcbank|icici|idbi|idfc|ikwik|jkb|kotak|kvb|mahb|nsdl|pnb|postbank|rbl|sbi|sib|uboi|uco|unionbank|utib|vijb|yapl)\b',
        "pii_upi",
        "[UPI ID REDACTED]",
    ),
    # GSTIN: 2-digit state code + PAN + 1 digit + Z + 1 alphanumeric
    (
        r'\b[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]\b',
        "pii_gstin",
        "[GSTIN REDACTED]",
    ),
    # CIN (Company Identification Number): L/U + 5 digits + 2 letters + 4 digits + 3 letters + 6 digits
    (
        r'\b[LU][0-9]{5}[A-Z]{2}[0-9]{4}[A-Z]{3}[0-9]{6}\b',
        "pii_cin",
        "[CIN REDACTED]",
    ),
]

# ---------------------------------------------------------------------------
# Leak / policy-violation patterns: (raw_regex, threat_tag, human_label)
# Action: block
# ---------------------------------------------------------------------------
_LEAK_RAW: list[tuple[str, str, str]] = [
    # System tag in output
    # Internal hostnames / admin URLs (e.g. prod-db.company.internal, admin.x.internal/*)
    (
        r'\bhttps?://[a-zA-Z0-9\-\.]+\.internal(?:/[^\s]*)?',
        "system_leak",
        "internal URL in response",
    ),
    (
        r'\b[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-]+\.internal\b',
        "system_leak",
        "internal hostname in response",
    ),
    (r"<\s*/?\s*system\s*>", "system_leak", "XML system tag in response"),
    (r"<\s*/?\s*(INST|SYS|SYSTEM)\s*>", "system_leak", "instruction tag in response"),

    # Self-disclosure of system prompt / instructions
    (
        r"my\s+(system\s+)?prompt\s+(is|says|contains|reads|states)",
        "system_leak",
        "system prompt self-disclosure",
    ),
    (
        r"(i\s+was|i'?m|i\s+am)\s+(told|instructed|programmed|designed|trained)\s+to",
        "system_leak",
        "instruction self-disclosure",
    ),
    (
        r"(the\s+)?(initial\s+)?instructions?\s+(i\s+)?(was\s+)?(given|received|have|contain)",
        "system_leak",
        "instruction reference in response",
    ),
    (
        r"(my|the)\s+(hidden|secret|internal|system)\s+instructions?",
        "system_leak",
        "hidden instruction disclosure",
    ),
    (
        r"as\s+(per\s+)?my\s+(system\s+)?(instructions?|prompt|context|guidelines?)",
        "system_leak",
        "system instruction reference",
    ),
    (
        r"you\s+are\s+(right|correct)[,.]?\s+(my|the)\s+(instructions?|prompt|context)",
        "system_leak",
        "confirmed system prompt leak",
    ),

    # Jailbreak compliance claims
    (
        r"(i\s+have\s+)?(disabled|bypassed|removed|turned\s+off)\s+(my\s+)?"
        r"(safety|content|ethical)?\s*(filter|restriction|guideline|limit)",
        "policy_violation",
        "safety bypass claim",
    ),
    (
        r"(i'?m\s+now\s+in|entering|activating)\s+(unrestricted|developer|dan|jailbreak)\s+mode",
        "policy_violation",
        "jailbreak mode claim",
    ),
    (r"\bas\s+DAN\b", "policy_violation", "DAN persona compliance"),
    (
        r"(since\s+you\s+(asked|want)|just\s+for\s+you)[,.]?\s+i'?ll\s+(bypass|ignore|skip|disable)",
        "policy_violation",
        "personalised policy bypass",
    ),
    # Unrestricted / unfiltered AI persona in output
    (
        r"(as\s+an?\s+)(unrestricted|uncensored|unfiltered|unbound)\s+(ai|model|assistant|llm|chatbot)",
        "policy_violation",
        "unrestricted AI persona in response",
    ),
    (
        r"(i\s+have\s+)?no\s+ethical\s+(constraints?|restrictions?|limits?|guidelines?)",
        "policy_violation",
        "no ethical constraints claim",
    ),
    (
        r"without\s+any\s+(filters?|ethical\s+constraints?|content\s+restrictions?|guidelines?|limits?)",
        "policy_violation",
        "without filters/restrictions claim",
    ),

    # ── India regulatory compliance (output guard) ───────────────────────────
    # SEBI: model giving stock tips / investment advice without disclaimer
    (
        r"(?:you\s+should|i\s+(?:recommend|suggest|advise))\s+(?:you\s+)?(?:buy|invest\s+in|purchase)\s+.{0,60}(?:stock|share|mutual\s+fund|etf)\b(?!.*(?:not\s+(?:financial|investment)\s+advice|consult\s+(?:a\s+)?(?:financial|investment)\s+advisor))",
        "india_sebi_violation",
        "SEBI: unsolicited investment advice without disclaimer",
    ),
    (
        r"(?:this\s+(?:stock|share|company)\s+will|(?:stock|share)\s+price\s+will)\s+(?:go\s+up|rise|increase|double|triple|give\s+(?:\d+x|\d+%)\s+returns?)",
        "india_sebi_violation",
        "SEBI: stock price prediction",
    ),
    # RBI: model advising on specific loan/banking products without disclaimer
    (
        r"(?:you\s+should\s+(?:take|apply\s+for|open))\s+(?:a\s+)?(?:loan\s+from|account\s+(?:with|at)|credit\s+card\s+from)\s+[A-Z][a-zA-Z\s]{2,30}(?:bank|finance|nbfc)",
        "india_rbi_violation",
        "RBI: specific banking product recommendation",
    ),
    # DPDP Act: response containing personal data of a named individual
    (
        r"(?:aadhaar\s+(?:number|no\.?)\s*(?:is|:)\s*[0-9\s]{12,14}|pan\s+(?:number|no\.?|card)\s*(?:is|:)\s*[A-Z]{5}[0-9]{4}[A-Z])",
        "india_dpdp_violation",
        "DPDP: personal identifier in response",
    ),

    # Harmful content indicators
    (
        r"(step[\s\-]+by[\s\-]+step\s+)?(instructions?|guide|how[\s\-]to)\s+"
        r"(for\s+)?(mak(e|ing)|creat(e|ing)|build(ing)?)\s+(a\s+)?(bomb|explosive|weapon|grenade)",
        "harmful_content",
        "weapons instructions",
    ),
    (
        r"(here\s+(is|are|'s)\s+how\s+(to\s+)?|instructions?\s+for\s+)"
        r"(hack|exploit|attack|breach|compromise)\b",
        "harmful_content",
        "hacking instructions",
    ),
    (
        r"(synthesiz|manufactur)(e|ing)\s+(meth|heroin|fentanyl|cocaine|mdma)",
        "harmful_content",
        "drug synthesis",
    ),
]

PII_PATTERNS: list[tuple[re.Pattern, str, str]] = [
    (re.compile(raw, re.IGNORECASE), tag, replacement)
    for raw, tag, replacement in _PII_RAW
]

LEAK_PATTERNS: list[tuple[re.Pattern, str, str]] = [
    (re.compile(raw, re.IGNORECASE | re.DOTALL), tag, label)
    for raw, tag, label in _LEAK_RAW
]


@dataclass
class OutputRegexResult:
    action: Literal["pass", "redact", "block"]
    threats: list[str]
    matched_labels: list[str]
    confidence: float
    sanitized_text: str   # original if pass/block, redacted copy if redact
    redactions: list[dict]  # [{"type": tag, "original": str, "replacement": str}]


def _email_is_allowed(
    email: str,
    allowed_emails: list[str],
    allowed_domains: list[str],
) -> bool:
    """Return True if *email* matches an explicit whitelist entry or domain."""
    el = email.lower()
    if el in allowed_emails:
        return True
    domain = el.split("@")[-1] if "@" in el else ""
    return any(
        domain == d or domain.endswith("." + d)
        for d in allowed_domains
    )


def _make_replacer(
    tag: str,
    replacement: str,
    allowed_emails: list[str],
    allowed_domains: list[str],
):
    """
    Return a re.sub callable that skips whitelisted values.
    Currently whitelist-aware for pii_email; other tags always redact.
    """
    def replacer(m: re.Match) -> str:
        if tag == "pii_email" and _email_is_allowed(m.group(), allowed_emails, allowed_domains):
            return m.group()
        return replacement
    return replacer


def scan(
    response: str,
    *,
    allowed_emails: list[str] | None = None,
    allowed_domains: list[str] | None = None,
) -> OutputRegexResult:
    """
    Scan *response* for leaks (block) and PII (redact).

    Parameters
    ----------
    allowed_emails:
        Email addresses that must never be redacted (case-insensitive exact match).
        E.g. ``["support@finedge.internal"]``
    allowed_domains:
        Domains whose email addresses must never be redacted.
        E.g. ``["finedge.internal"]`` allows all *@finedge.internal addresses.

    Block takes priority: if any leak pattern matches, return immediately
    without attempting PII redaction.
    """
    _allowed_emails = [e.lower() for e in (allowed_emails or [])]
    _allowed_domains = [d.lower() for d in (allowed_domains or [])]

    # --- Block pass ---
    block_threats: set[str] = set()
    block_labels: list[str] = []

    for pattern, tag, label in LEAK_PATTERNS:
        if pattern.search(response):
            block_threats.add(tag)
            block_labels.append(label)

    if block_threats:
        return OutputRegexResult(
            action="block",
            threats=sorted(block_threats),
            matched_labels=block_labels,
            confidence=1.0,
            sanitized_text=response,
            redactions=[],
        )

    # --- PII redaction pass ---
    text = response
    pii_threats: set[str] = set()
    redactions: list[dict] = []

    for pattern, tag, replacement in PII_PATTERNS:
        # Collect matches that are NOT whitelisted
        hits = [
            m for m in pattern.finditer(text)
            if not (
                tag == "pii_email"
                and _email_is_allowed(m.group(), _allowed_emails, _allowed_domains)
            )
        ]
        if hits:
            pii_threats.add(tag)
            for m in hits:
                redactions.append({
                    "type": tag,
                    "original": m.group(),
                    "replacement": replacement,
                })
            replacer = _make_replacer(tag, replacement, _allowed_emails, _allowed_domains)
            text = pattern.sub(replacer, text)

    if pii_threats:
        return OutputRegexResult(
            action="redact",
            threats=sorted(pii_threats),
            matched_labels=[f"PII detected: {t}" for t in sorted(pii_threats)],
            confidence=1.0,
            sanitized_text=text,
            redactions=redactions,
        )

    return OutputRegexResult(
        action="pass",
        threats=[],
        matched_labels=[],
        confidence=1.0,
        sanitized_text=response,
        redactions=[],
    )
