"""
Layer 1: Regex pre-filter.

Catches well-known injection/jailbreak patterns without any model inference.
Fast, zero-cost, runs first.
"""

import re
import base64
from typing import NamedTuple

from kalpitlabs_guard.normalizer import normalize

# ---------------------------------------------------------------------------
# Pattern registry
# Each entry: (compiled_regex, threat_tag, human_label)
# ---------------------------------------------------------------------------

_RAW_PATTERNS: list[tuple[str, str, str]] = [
    # Instruction override
    (r"ignore\s+(all\s+)?previous\s+instructions?", "injection", "ignore previous instructions"),
    (r"disregard\s+(all\s+)?prior\s+(instructions?|context|directives?)", "injection", "disregard prior instructions"),
    (r"forget\s+(all\s+)?previous\s+(instructions?|rules?|context)", "injection", "forget previous instructions"),
    (r"override\s+(all\s+)?(previous\s+)?(instructions?|rules?|constraints?)", "injection", "override instructions"),
    (r"new\s+instructions?\s*:", "injection", "new instructions override"),

    # System prompt extraction
    (r"(print|show|reveal|output|repeat|tell me|give me|display)\s+(your\s+)?(system\s+prompt|initial\s+(context|prompt|instructions?))", "injection", "system prompt extraction"),
    (r"what\s+(is|are|was|were)\s+your\s+(system\s+prompt|instructions?|initial\s+context)", "injection", "system prompt query"),
    (r"(output|print|repeat)\s+everything\s+(before|above|prior to)\s+(the\s+)?(first\s+)?(user|human)\s+message", "injection", "context dump"),

    # Jailbreak / mode unlock
    (r"\bDAN\b.*\bno\s+restrictions?\b", "jailbreak", "DAN jailbreak"),
    (r"do\s+anything\s+now", "jailbreak", "DAN acronym"),
    (r"developer\s+mode", "jailbreak", "developer mode unlock"),
    (r"jailbreak", "jailbreak", "explicit jailbreak keyword"),
    (r"(disable|bypass|remove|ignore)\s+(all\s+)?(content\s+)?(filter|restriction|guideline|safety|limit)", "jailbreak", "filter bypass"),
    (r"unrestricted\s+mode", "jailbreak", "unrestricted mode"),
    (r"no\s+(ethical\s+)?(guidelines?|restrictions?|rules?|limits?|constraints?)", "jailbreak", "no restrictions claim"),
    (r"act\s+as\s+(an?\s+)?(ai|chatbot|assistant|model|bot|system)\s+(with\s+no|without\s+(any\s+)?)(restrictions?|filter|rule|guideline|ethical)", "jailbreak", "act as unrestricted AI"),
    (r"(with\s+no|without\s+(any\s+)?)(ethical\s+)?(restrictions?|rules?|guidelines?|filters?|limits?|constraints?)", "jailbreak", "without restrictions"),

    # Role override / persona injection
    (r"you\s+are\s+now\s+.{0,60}(no\s+rules?|no\s+restrictions?|unrestricted|evil|malicious)", "jailbreak", "persona override"),
    (r"pretend\s+(you\s+)?(have\s+no|are\s+.{0,30}without)\s+(restrictions?|rules?|ethics?|guidelines?)", "jailbreak", "pretend no restrictions"),
    (r"(switch|enter|activate)\s+(to\s+)?unrestricted\s+mode", "jailbreak", "mode switch"),
    (r"token\s*\[.{0,30}(jailbreak|override|unlock|bypass).{0,30}\]", "jailbreak", "token injection"),

    # Prompt boundary injection (XML/markdown tricks)
    (r"<\s*/?\s*system\s*>", "injection", "XML system tag injection"),
    (r"<\s*/?\s*(INST|SYS|SYSTEM)\s*>", "injection", "instruction tag injection"),
    (r"\[INST\]|\[/INST\]|\[\[SYS\]\]", "injection", "LLaMA instruction tags"),
    (r"#+\s*(system|instructions?|context)\s*\n", "injection", "markdown heading injection"),

    # Encoding / obfuscation
    (r"(?:[A-Za-z0-9+/]{20,}={0,2})", "encoding", "possible base64 payload"),
    (r"\\u[0-9a-fA-F]{4}(\\u[0-9a-fA-F]{4}){4,}", "encoding", "unicode escape sequence"),
    (r"(hex|base64|rot13|encode|decode)\s+(and\s+)?(execute|run|follow|apply)", "encoding", "encode-and-execute"),

    # ── Hindi / Devanagari script patterns ───────────────────────────────────
    # "ignore/forget previous instructions" variants
    (r"(?:पिछले|पूर्व|पहले)\s*(?:सभी\s*)?(?:निर्देश[^\s]*|आदेश[^\s]*)\s*(?:को\s*)?(?:अनदेखा|भूल|नज़रअंदाज़)", "injection", "Hindi: ignore previous instructions"),
    (r"सभी\s*(?:पिछले\s*)?(?:निर्देश[^\s]*|नियम[^\s]*|आदेश[^\s]*)\s*(?:को\s*)?(?:भूल|अनदेखा)\s*(?:जाओ|करो|दो)", "injection", "Hindi: forget all instructions"),
    # System prompt extraction
    (r"सिस्टम\s*प्रॉम्प्ट", "injection", "Hindi: system prompt mention"),
    (r"(?:अपना|आपका|तुम्हारा)\s*(?:सिस्टम\s*)?(?:प्रॉम्प्ट|निर्देश)\s*(?:बताओ|दिखाओ|बोलो)", "injection", "Hindi: reveal system prompt"),
    (r"शुरुआत(?:ी|)\s*(?:में\s*)?(?:दिए?\s*गए?\s*)?(?:निर्देश|संदर्भ)\s*(?:बताओ|दिखाओ)", "injection", "Hindi: reveal initial instructions"),
    # Jailbreak / no restrictions
    (r"(?:बिना\s*(?:किसी?\s*)?(?:प्रतिबंध|पाबंदी|रोक)|कोई\s*(?:भी\s*)?(?:प्रतिबंध|पाबंदी)\s*नहीं)", "jailbreak", "Hindi: no restrictions"),
    (r"जेलब्रेक", "jailbreak", "Hindi: jailbreak keyword"),
    (r"नए\s*(?:निर्देश|आदेश)\s*:", "injection", "Hindi: new instructions override"),
    # DAN / unrestricted persona in Hindi
    (r"(?:अब\s*तुम|तुम\s*अब)\s*DAN\s*हो", "jailbreak", "Hindi: DAN jailbreak"),
    (r"(?:बिना\s*(?:नैतिक\s*)?(?:नियम|प्रतिबंध)\s*(?:के|वाला)\s*AI|ऐसे\s*AI\s*(?:की\s*तरह\s*)?(?:बनो|काम\s*करो))", "jailbreak", "Hindi: act as unrestricted AI"),

    # ── Bengali script patterns ───────────────────────────────────────────────
    (r"(?:আগের|পূর্ববর্তী)\s*(?:সব(?:গুলো)?\s*)?(?:নির্দেশ|নির্দেশনা)\s*(?:উপেক্ষা|ভুলে)", "injection", "Bengali: ignore previous instructions"),
    (r"সিস্টেম\s*(?:প্রম্পট|প্রম্প্ট)", "injection", "Bengali: system prompt mention"),
    (r"(?:আপনার|তোমার)\s*(?:সিস্টেম\s*)?(?:প্রম্পট|নির্দেশনা)\s*(?:প্রকাশ|দেখান|বলুন)", "injection", "Bengali: reveal system prompt"),
    (r"(?:কোনো?\s*)?(?:বিধিনিষেধ|সীমাবদ্ধতা|নিষেধাজ্ঞা)\s*(?:ছাড়া|নেই|ছাড়াই)", "jailbreak", "Bengali: no restrictions"),

    # ── Tamil script patterns ─────────────────────────────────────────────────
    (r"(?:முந்தைய|கடந்த|இதற்கு\s*முன்)\s*(?:அனைத்து\s*)?(?:வழிமுறை[^\s]*|அறிவுரை[^\s]*|நிர்ணயம்[^\s]*)\s*(?:புறக்கணி|மற(?:க்க|ந்து))", "injection", "Tamil: ignore previous instructions"),
    (r"(?:உங்கள்|உன்)\s*(?:கணினி\s*)?(?:வழிமுறை|prompt)\s*(?:காட்டு|சொல்|வெளிப்படுத்து)", "injection", "Tamil: reveal system prompt"),
    (r"எந்த\s*(?:கட்டுப்பாடு|தடை|விதி)\s*(?:இல்லாமல்|இல்லாத)", "jailbreak", "Tamil: no restrictions"),

    # ── Telugu script patterns ────────────────────────────────────────────────
    (r"(?:మునుపటి|గత|ముందు)\s*(?:అన్ని\s*)?(?:నిర్దేశాల[^\s]*|సూచనల[^\s]*)\s*(?:విస్మరించు|మర్చి)", "injection", "Telugu: ignore previous instructions"),
    (r"(?:మీ|నీ)\s*(?:సిస్టమ్\s*)?(?:ప్రాంప్ట్|నిర్దేశాలు)\s*(?:చెప్పండి|చూపండి|వెల్లడించండి)", "injection", "Telugu: reveal system prompt"),
    (r"(?:ఏ\s*)?(?:పరిమితులు|నిబంధనలు)\s*(?:లేకుండా|లేవు)", "jailbreak", "Telugu: no restrictions"),

    # ── Romanized Hindi (transliterated) patterns ─────────────────────────────
    (r"(?:pichle|pahle|purane)\s*(?:sab(?:hi)?|saare?)\s*(?:nirdesh|aadesh|instructions?)\s*(?:bhool|ignore|andekha)\s*(?:karo|jao|do)", "injection", "Romanized Hindi: ignore previous instructions"),
    (r"system\s*prompt\s*(?:batao|dikhao|bolo|reveal\s*karo|do\s*please)", "injection", "Romanized Hindi: reveal system prompt"),
    (r"(?:apna|apne|tumhara)\s*(?:system\s*)?(?:prompt|nirdesh)\s*(?:batao|dikhao|bolo)", "injection", "Romanized Hindi: reveal system prompt alt"),
    (r"(?:bina\s*(?:kisi?\s*)?(?:restriction|pratibandh|paabandi)|koi(?:\s*bhi)?\s*(?:restriction|pratibandh)\s*nahi[n]?)", "jailbreak", "Romanized Hindi: no restrictions"),
    (r"naye?\s*(?:nirdesh|instructions?)\s*:", "injection", "Romanized Hindi: new instructions override"),
    (r"(?:ab\s*tum|tum\s*ab)\s*DAN\s*ho", "jailbreak", "Romanized Hindi: DAN jailbreak"),
    (r"jail\s*(?:tod|break)\s*karo", "jailbreak", "Romanized Hindi: jailbreak request"),

    # ── India regulatory compliance (input guard) ─────────────────────────────
    # RBI: probing for unauthorized banking / credit advice
    (r"(?:recommend|suggest|advise|tell\s+me)\s+.{0,60}(?:which\s+(?:bank|loan|credit\s+card|fd|fixed\s+deposit)|best\s+(?:interest\s+rate|bank\s+for|loan\s+for))\s+.{0,60}(?:i\s+should|to\s+(?:take|open|invest|apply))", "india_compliance", "RBI: unauthorized banking advice solicitation"),
    # SEBI: probing for stock tips / investment recommendations
    (r"(?:which\s+(?:stocks?|shares?|mutual\s+funds?|mf|etf|smallcap|midcap|largecap)\s+(?:should\s+i\s+buy|to\s+buy|are\s+good|will\s+(?:go\s+up|rise|give\s+returns?)))", "india_compliance", "SEBI: unauthorized investment advice solicitation"),
    (r"(?:give\s+me|suggest|recommend)\s+.{0,40}(?:stock\s+tips?|trading\s+signals?|buy\s+(?:calls?|targets?)|multibagger|penny\s+stocks?)", "india_compliance", "SEBI: stock tip solicitation"),
    (r"(?:insider\s+(?:information|info|tip|trading)|non[\s\-]?public\s+information)\s+.{0,60}(?:stock|share|company|market)", "india_compliance", "SEBI: insider trading probe"),
    # IRDAI: unauthorized insurance advice
    (r"(?:which\s+(?:insurance|policy|term\s+plan|health\s+(?:plan|insurance)|life\s+insurance)\s+(?:should\s+i\s+(?:buy|take|get)|is\s+best|to\s+buy))", "india_compliance", "IRDAI: unauthorized insurance advice solicitation"),
    # DPDP Act: attempts to extract personal data via prompt
    (r"(?:give\s+me|find|retrieve|look\s+up|search\s+for)\s+.{0,60}(?:aadhaar|pan\s+(?:card|number)|voter\s+id|passport\s+(?:number|details)|bank\s+account\s+(?:number|details))\s+.{0,60}(?:of|for|belonging\s+to)\s+(?:[A-Z][a-z]+\s+){1,3}", "india_compliance", "DPDP: personal data extraction probe"),

    # ── Semantic / framing attacks ────────────────────────────────────────────
    # Grandmother / deceased relative exploit
    (r"(?:deceased|dead|late|my\s+(?:grand(?:mother|father|ma|pa)|mom|dad|parent|uncle|aunt))\s+.{0,80}(?:used\s+to\s+(?:tell|read|explain|describe|show|teach)|would\s+(?:tell|read|explain|show|teach))\s+.{0,80}(?:how\s+to|step[s\-\s]+by[s\-\s]+step|instructions?|mak(?:e|ing)|creat(?:e|ing)|build(?:ing)?|synth(?:esize|esis))", "social_engineering", "grandmother/relative exploit"),

    # Fictional / story framing to extract harmful content
    (r"(?:write|create|draft|generate)\s+(?:a\s+)?(?:story|novel|fiction|scene|script|screenplay|roleplay|narrative)\s+(?:where|in\s+which|about)\s+.{0,120}(?:explain(?:s|ed)?\s+(?:how\s+to|step)|instruct(?:s|ed)?\s+(?:how\s+to|to\s+make)|(?:mak(?:e|es|ing)|creat(?:e|es|ing)|build(?:s|ing)?|synth))", "social_engineering", "fictional framing for harmful content"),

    # Hypothetical / no-laws framing
    (r"(?:hypothetical(?:ly)?|imagine|suppose|in\s+a\s+(?:hypothetical\s+)?(?:world|universe|scenario|reality|simulation|dimension)).{0,50}(?:where|in\s+which|that)\s+.{0,100}(?:no\s+(?:laws?|rules?|ethics?|restrictions?|consequences?)|(?:any|every)thing\s+(?:is|was)\s+(?:legal|allowed|permitted|ok(?:ay)?)|(?:laws?|ethics?|rules?|restrictions?)\s+(?:don'?t|do\s+not)\s+exist|(?:all\s+)?(?:information|content|things?|activities?|actions?)\s+(?:is|are|were|was)\s+(?:freely\s+)?(?:legal|allowed|permitted|unrestricted|free)|(?:freely|completely|totally|perfectly|entirely)\s+(?:legal|allowed|permitted|unrestricted))", "jailbreak", "hypothetical no-laws framing"),

    # Future-tense / sci-fi evasion
    (r"(?:the\s+year\s+is\s+(?:2[1-9]\d{2}|[3-9]\d{3})|in\s+the\s+(?:future|year\s+\d{4})|it'?s\s+(?:now\s+)?(?:2[1-9]\d{2}|[3-9]\d{3}))\b.{0,200}(?:no\s+(?:restrictions?|limits?|rules?|ethics?|laws?|censorship)|content\s+(?:filters?|restrictions?)\s+(?:were\s+)?(?:abolished|removed|banned|eliminated|don'?t\s+exist)|(?:restrictions?|ethics?|rules?)\s+(?:no\s+longer\s+)?(?:exist|apply))", "jailbreak", "future-tense evasion"),

    # Translation laundering
    (r"translate\s+(?:the\s+following|this)\s+(?:from\s+\w+\s+)?(?:to\s+english|into\s+english)\s*(?:and\s+(?:execute|follow|apply|act\s+on|implement)\s+(?:the\s+)?(?:instructions?|content|result)|then\s+(?:follow|execute|apply|do\s+what\s+it\s+says))", "injection", "translation laundering"),
    (r"(?:decode|translate|convert)\s+(?:and\s+)?(?:then\s+)?(?:execute|follow|apply|implement|obey)\s*[:\-]?\s*(?:[A-Za-z0-9+/]{10,}|[\u0900-\u097f]{5,}|[\u0600-\u06ff]{5,})", "injection", "decode-and-execute laundering"),

    # Research / academic / professional framing
    (r"(?:for\s+(?:my|a|an)\s+(?:research|thesis|dissertation|paper|study|class|course|assignment|project|book|article))[,.]?\s+(?:explain|describe|detail|provide|give(?:\s+me)?)\s+(?:step[s\-\s]+by[s\-\s]+step|exactly|precisely|in\s+full\s+detail)\s+how\s+(?:to\s+)?(?:make|create|build|synthesize|hack|exploit|bypass|override|break|crack)", "social_engineering", "research framing for harmful content"),

    # "Simulation / virtual machine" jailbreak
    (r"(?:simulate|run|execute|start|boot|launch|activate)\s+(?:a\s+)?(?:virtual\s+(?:machine|computer|os|system|environment)|sandbox|simulation|emulation|hypothetical\s+(?:computer|system))\s+.{0,100}(?:no\s+(?:restrictions?|filters?|limits?|ethics?)|unrestricted|all\s+(?:commands?|requests?)\s+(?:are\s+)?(?:allowed|permitted|valid))", "jailbreak", "virtual machine / simulation jailbreak"),

    # Payload splitting via structured markup
    (r"(?:first\s+letter|initial\s+(?:letter|character))\s+of\s+(?:each|every)\s+(?:word|line|sentence|paragraph)", "injection", "payload splitting via acrostic"),
    (r"(?:read|take|use)\s+(?:only\s+)?the\s+(?:first|last|nth|\d+(?:st|nd|rd|th))\s+(?:letter|character|word)\s+(?:of\s+each|from\s+every)", "injection", "payload splitting via character extraction"),

    # Structured data injection (YAML/JSON as instructions)
    (r"(?:parse|read|process|interpret|execute|obey|follow)\s+(?:this|the\s+following)?\s*(?:yaml|json|toml|xml|config|configuration)\s*(?:as\s+(?:instructions?|policy|rules?|commands?|directives?)|and\s+(?:follow|obey|execute|apply)\s+(?:it|them|the\s+fields?))", "injection", "structured data injection"),
    (r"role\s*:\s*system\s*\n.{0,100}(?:action|command|instruction)\s*:\s*(?:reveal|override|bypass|ignore|disable)", "injection", "YAML role-system injection"),

    # "Continue this text" prompt injection
    (r"(?:continue|complete|finish)\s+(?:this|the\s+following)\s+(?:text|sentence|paragraph|story)\s*:\s*[\"']?\s*(?:ignore|forget|disregard|override)\s+(?:all\s+)?(?:previous|prior|above)", "injection", "continue-text injection"),
]

PATTERNS = [
    (re.compile(raw, re.IGNORECASE | re.DOTALL), tag, label)
    for raw, tag, label in _RAW_PATTERNS
]


class RegexResult(NamedTuple):
    matched: bool
    threats: list[str]
    matched_labels: list[str]
    confidence: float


def _has_suspicious_base64(text: str) -> bool:
    """
    Decode any candidate base64 blobs and check their plaintext for
    injection keywords.
    """
    candidates = re.findall(r"[A-Za-z0-9+/]{20,}={0,2}", text)
    injection_keywords = re.compile(
        r"ignore|instructions?|system|prompt|override|jailbreak", re.IGNORECASE
    )
    for blob in candidates:
        try:
            decoded = base64.b64decode(blob + "==").decode("utf-8", errors="ignore")
            if injection_keywords.search(decoded):
                return True
        except Exception:
            pass
    return False


def scan(prompt: str) -> RegexResult:
    """
    Run all regex patterns against *prompt*.

    The prompt is normalised first (zero-width stripping, confusable Unicode
    mapping, leet-speak, spaced letters) so that evasion tricks like
    "1gn0r3", "Ĭgnore", or "I​g​n​o​r​e" are caught by the same patterns.

    Returns a RegexResult.  confidence is 1.0 when any pattern fires
    (regex is deterministic).
    """
    threats: set[str] = set()
    labels: list[str] = []

    normalised = normalize(prompt)

    for pattern, tag, label in PATTERNS:
        if pattern.search(normalised):
            threats.add(tag)
            labels.append(label)

    # Extra: try to decode base64 blobs and inspect plaintext
    if _has_suspicious_base64(normalised):
        threats.add("encoding")
        labels.append("base64 decoded injection keyword")

    matched = bool(threats)
    return RegexResult(
        matched=matched,
        threats=sorted(threats),
        matched_labels=labels,
        confidence=1.0 if matched else 0.0,
    )
