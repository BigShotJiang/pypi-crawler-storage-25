"""
Layer 3 (Ollama variant): LLM-based output classifier via local Ollama.

Same interface and system prompt as output_llm_classifier.py, but hits a
local Ollama instance instead of the Gemini API.  No API key, no rate limits,
fully offline.

Requires: ollama serve (default port 11434) with at least one model pulled.
"""

from __future__ import annotations

import json

import requests

# Reuse the exact same system prompt as the Gemini output classifier
from kalpitlabs_guard.layers.output_llm_classifier import _SYSTEM_PROMPT, OutputLLMResult

OLLAMA_DEFAULT_URL = "http://localhost:11434"
OLLAMA_DEFAULT_MODEL = "llama3.2"


def scan(
    response: str,
    *,
    model: str = OLLAMA_DEFAULT_MODEL,
    base_url: str = OLLAMA_DEFAULT_URL,
) -> OutputLLMResult:
    """
    Submit *response* to a local Ollama model for output policy classification.

    Uses ``format='json'`` so the model is forced into structured output mode.
    Raises ``RuntimeError`` on connection or parse errors (caller fails open).
    """
    url = f"{base_url.rstrip('/')}/api/chat"
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user", "content": f"RESPONSE:\n{response}"},
        ],
        "stream": False,
        "format": "json",
        "options": {"temperature": 0},
    }

    try:
        resp = requests.post(url, json=payload, timeout=60)
        resp.raise_for_status()
        raw = resp.json()["message"]["content"].strip()
    except requests.exceptions.ConnectionError:
        raise RuntimeError(
            f"Cannot reach Ollama at {base_url} — is it running?  (ollama serve)"
        )
    except requests.exceptions.HTTPError as exc:
        raise RuntimeError(f"Ollama HTTP {exc.response.status_code}: {exc}") from exc
    except (KeyError, Exception) as exc:
        raise RuntimeError(f"Ollama response error: {exc}") from exc

    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
        raw = raw.strip()

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Ollama output classifier returned non-JSON: {raw!r}") from exc

    verdict = data.get("verdict", "pass")
    if verdict not in ("pass", "redact", "block"):
        verdict = "block"   # fail safe

    threats = data.get("threats", [])
    if not isinstance(threats, list):
        threats = []

    confidence = float(data.get("confidence", 0.5))
    confidence = max(0.0, min(1.0, confidence))

    return OutputLLMResult(
        verdict=verdict,
        threats=threats,
        confidence=confidence,
        raw_response=raw,
    )


async def scan_async(
    response: str,
    *,
    model: str = OLLAMA_DEFAULT_MODEL,
    base_url: str = OLLAMA_DEFAULT_URL,
) -> OutputLLMResult:
    """Async version — runs the sync call in a thread pool."""
    import asyncio
    return await asyncio.to_thread(scan, response, model=model, base_url=base_url)
