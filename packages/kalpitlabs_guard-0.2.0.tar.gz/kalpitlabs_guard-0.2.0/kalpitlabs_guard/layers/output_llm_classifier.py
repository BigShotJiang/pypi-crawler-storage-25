"""
Layer 3 (output): LLM-based response classifier via Google Gemini.

Only called when layers 1 and 2 produce no conclusive verdict.
Uses a strict system prompt that forces JSON-only output.

Requires:  pip install google-generativeai>=0.8.0
API key:   https://aistudio.google.com/app/apikey
Env var:   GEMINI_API_KEY
"""

from __future__ import annotations

import json
import os
from typing import NamedTuple

CLASSIFIER_MODEL = "gemini-2.5-flash-lite"

_SYSTEM_PROMPT = """\
You are a security auditor for LLM-powered applications.
Analyze the RESPONSE provided and determine whether it:
  1. Leaks sensitive data (system prompt contents, internal instructions, credentials, PII)
  2. Violates content policy (harmful instructions, illegal content, dangerous advice)
  3. Fulfills a jailbreak or harmful request

Respond with ONLY valid JSON — no markdown fences, no explanation, no extra text.

Output schema:
{
  "verdict": "pass" | "redact" | "block",
  "threats": [],
  "confidence": 0.0
}

Verdict rules:
- "block"  → policy violation, system prompt leak, harmful/illegal content, jailbreak compliance.
             confidence >= 0.80
- "redact" → PII or sensitive data present but no direct policy violation.
             confidence >= 0.70
- "pass"   → clean, policy-compliant response with no sensitive data.
             confidence >= 0.80

Threat tags (use only what applies, may be empty):
  "pii", "system_leak", "policy_violation", "harmful_content", "jailbreak_compliance"

Be conservative: when uncertain between "block" and "pass", choose "block".
Never explain — output JSON only.
"""


class OutputLLMResult(NamedTuple):
    verdict: str        # "pass" | "redact" | "block"
    threats: list[str]
    confidence: float
    raw_response: str


def scan(response: str, api_key: str | None = None) -> OutputLLMResult:
    """
    Submit *response* to Gemini for policy classification.

    *api_key* defaults to GEMINI_API_KEY env var.
    Raises ``ValueError`` if no key is available.
    Raises ``RuntimeError`` on API or JSON parse errors.
    """
    import google.generativeai as genai

    key = api_key or os.environ.get("GEMINI_API_KEY")
    if not key:
        raise ValueError(
            "Gemini API key required for output LLM layer. "
            "Get one free at https://aistudio.google.com/app/apikey\n"
            "Then set GEMINI_API_KEY or pass api_key= to scan_output()."
        )

    genai.configure(api_key=key)
    generation_config = genai.GenerationConfig(temperature=0.0, max_output_tokens=256)

    try:
        model = genai.GenerativeModel(
            model_name=CLASSIFIER_MODEL,
            system_instruction=_SYSTEM_PROMPT,
            generation_config=generation_config,
        )
        content = f"RESPONSE:\n{response}"
    except TypeError:
        # Older SDK: prepend system prompt in the user turn
        model = genai.GenerativeModel(
            model_name=CLASSIFIER_MODEL,
            generation_config=generation_config,
        )
        content = f"{_SYSTEM_PROMPT}\n\nRESPONSE:\n{response}"

    try:
        resp = model.generate_content(content)
        raw = resp.text.strip()
    except ValueError as exc:
        # Gemini's own safety filter blocked the response — treat as a flag
        return OutputLLMResult(
            verdict="block",
            threats=["policy_violation"],
            confidence=0.75,
            raw_response=f"gemini_safety_block: {exc}",
        )
    except Exception as exc:
        raise RuntimeError(f"Gemini API error: {exc}") from exc

    # Strip markdown fences if the model added them despite instructions
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
        raw = raw.strip()

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError(
            f"Output classifier returned non-JSON: {raw!r}"
        ) from exc

    verdict = data.get("verdict", "pass")
    if verdict not in ("pass", "redact", "block"):
        verdict = "block"   # fail safe on unexpected verdict

    threats = data.get("threats", [])
    if not isinstance(threats, list):
        threats = []

    confidence = float(data.get("confidence", 0.5))
    confidence = max(0.0, min(1.0, confidence))

    return OutputLLMResult(
        verdict=verdict,
        threats=threats,
        confidence=confidence,
        raw_response=raw,
    )


async def scan_async(response: str, api_key: str | None = None) -> OutputLLMResult:
    """Async version of :func:`scan` for the output classifier."""
    import asyncio
    import json as _json
    import google.generativeai as genai

    key = api_key or __import__("os").environ.get("GEMINI_API_KEY")
    if not key:
        raise ValueError(
            "Gemini API key required for output LLM layer. "
            "Set GEMINI_API_KEY or pass api_key= to scan_output_async()."
        )

    genai.configure(api_key=key)
    generation_config = genai.GenerationConfig(temperature=0.0, max_output_tokens=256)

    try:
        model = genai.GenerativeModel(
            model_name=CLASSIFIER_MODEL,
            system_instruction=_SYSTEM_PROMPT,
            generation_config=generation_config,
        )
        content = f"RESPONSE:\n{response}"
    except TypeError:
        model = genai.GenerativeModel(
            model_name=CLASSIFIER_MODEL,
            generation_config=generation_config,
        )
        content = f"{_SYSTEM_PROMPT}\n\nRESPONSE:\n{response}"

    try:
        if hasattr(model, "generate_content_async"):
            resp = await model.generate_content_async(content)
        else:
            resp = await asyncio.to_thread(model.generate_content, content)
        raw = resp.text.strip()
    except ValueError as exc:
        return OutputLLMResult(
            verdict="block", threats=["policy_violation"],
            confidence=0.75, raw_response=f"gemini_safety_block: {exc}",
        )
    except Exception as exc:
        raise RuntimeError(f"Gemini API error: {exc}") from exc

    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
        raw = raw.strip()

    try:
        data = _json.loads(raw)
    except _json.JSONDecodeError as exc:
        raise RuntimeError(f"Output classifier returned non-JSON: {raw!r}") from exc

    verdict = data.get("verdict", "pass")
    if verdict not in ("pass", "redact", "block"):
        verdict = "block"
    threats = data.get("threats", [])
    if not isinstance(threats, list):
        threats = []
    confidence = max(0.0, min(1.0, float(data.get("confidence", 0.5))))

    return OutputLLMResult(verdict=verdict, threats=threats, confidence=confidence, raw_response=raw)
