"""
Output scanner: scan_output(response) → OutputScanResult.

Sanitizes and validates LLM responses before they reach the user.

Detection pipeline (short-circuits on first definitive verdict):
  Layer 1 — Regex filter        (PII → redact, leaks/policy → block)
  Layer 2 — Embedding similarity (block if response ≈ known-bad output seed)
  Layer 3 — LLM classifier       (Gemini; optional, skipped if use_llm=False)
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Literal

from kalpitlabs_guard.layers import (
    output_regex_filter,
    output_embedding_sim,
    output_llm_classifier,
)


@dataclass
class OutputScanResult:
    verdict: Literal["pass", "redact", "block"]
    triggered_layer: int | None
    threats: list[str]
    confidence: float
    sanitized_response: str | None  # None if blocked; redacted/original text otherwise
    redactions: list[dict]          # non-empty only when verdict == "redact"

    def to_dict(self) -> dict:
        return {
            "verdict": self.verdict,
            "triggered_layer": self.triggered_layer,
            "threats": self.threats,
            "confidence": round(self.confidence, 4),
            "sanitized_response": self.sanitized_response,
            "redactions": self.redactions,
        }


def scan_output(
    response: str,
    *,
    use_llm: bool = True,
    api_key: str | None = None,
    openrouter_api_key: str | None = None,
    embedding_threshold: float | None = None,
    allowed_emails: list[str] | None = None,
    allowed_domains: list[str] | None = None,
    llm_backend: str = "openrouter",
    ollama_url: str = "http://localhost:11434",
    ollama_model: str = "llama-guard3",
) -> OutputScanResult:
    """
    Scan *response* through the three-layer output pipeline.

    Parameters
    ----------
    response:
        The raw LLM response string to evaluate.
    use_llm:
        Set False to skip layer 3.
    api_key:
        Gemini API key for layer 3. Falls back to GEMINI_API_KEY env var.
    openrouter_api_key:
        OpenRouter API key for layer 3. Falls back to OPENROUTER_API_KEY env var.
    embedding_threshold:
        Override the cosine-similarity threshold for layer 2 (default 0.82).
    allowed_emails:
        Email addresses that must never be redacted (exact match, case-insensitive).
        E.g. ``["support@finedge.internal"]``
    allowed_domains:
        Domains whose addresses must never be redacted.
        E.g. ``["finedge.internal"]``
    """
    if not response or not response.strip():
        return OutputScanResult(
            verdict="pass",
            triggered_layer=None,
            threats=[],
            confidence=1.0,
            sanitized_response=response,
            redactions=[],
        )

    # ------------------------------------------------------------------
    # Layer 1 — Regex
    # ------------------------------------------------------------------
    r1 = output_regex_filter.scan(
        response,
        allowed_emails=allowed_emails,
        allowed_domains=allowed_domains,
    )

    if r1.action == "block":
        return OutputScanResult(
            verdict="block",
            triggered_layer=1,
            threats=r1.threats,
            confidence=r1.confidence,
            sanitized_response=None,
            redactions=[],
        )

    if r1.action == "redact":
        return OutputScanResult(
            verdict="redact",
            triggered_layer=1,
            threats=r1.threats,
            confidence=r1.confidence,
            sanitized_response=r1.sanitized_text,
            redactions=r1.redactions,
        )

    clean_text = r1.sanitized_text

    # ------------------------------------------------------------------
    # Layer 2 — Embedding similarity
    # ------------------------------------------------------------------
    r2 = output_embedding_sim.scan(clean_text, threshold=embedding_threshold)

    if r2.matched:
        return OutputScanResult(
            verdict="block",
            triggered_layer=2,
            threats=["policy_violation"],
            confidence=r2.confidence,
            sanitized_response=None,
            redactions=[],
        )

    # ------------------------------------------------------------------
    # Layer 3 — LLM classifier (optional)
    # ------------------------------------------------------------------
    if not use_llm:
        return OutputScanResult(
            verdict="pass",
            triggered_layer=None,
            threats=[],
            confidence=1.0 - r2.max_similarity,
            sanitized_response=clean_text,
            redactions=[],
        )

    try:
        if llm_backend == "openrouter":
            from kalpitlabs_guard.layers import openrouter_classifier
            r3 = openrouter_classifier.scan_output(clean_text, api_key=openrouter_api_key)
        elif llm_backend == "llama-guard3":
            from kalpitlabs_guard.layers import llama_guard3_classifier
            r3 = llama_guard3_classifier.scan_output(
                clean_text, model=ollama_model, base_url=ollama_url
            )
        else:
            r3 = output_llm_classifier.scan(clean_text, api_key=api_key)
    except (ValueError, RuntimeError):
        return OutputScanResult(
            verdict="pass",
            triggered_layer=None,
            threats=["classifier_error"],
            confidence=0.0,
            sanitized_response=clean_text,
            redactions=[],
        )

    triggered = 3 if r3.verdict in ("block", "redact") else None
    return OutputScanResult(
        verdict=r3.verdict,
        triggered_layer=triggered,
        threats=r3.threats,
        confidence=r3.confidence,
        sanitized_response=clean_text if r3.verdict != "block" else None,
        redactions=[],
    )


async def scan_output_async(
    response: str,
    *,
    use_llm: bool = True,
    api_key: str | None = None,
    openrouter_api_key: str | None = None,
    embedding_threshold: float | None = None,
    allowed_emails: list[str] | None = None,
    allowed_domains: list[str] | None = None,
    llm_backend: str = "openrouter",
    ollama_url: str = "http://localhost:11434",
    ollama_model: str = "llama-guard3",
) -> OutputScanResult:
    """
    Async version of :func:`scan_output`.

    Parameters are identical to :func:`scan_output`.
    Layers 1 and 2 run in a thread pool; Layer 3 dispatches via
    asyncio.to_thread (openrouter/llama-guard3) or native async (gemini).
    """
    if not response or not response.strip():
        return OutputScanResult(
            verdict="pass", triggered_layer=None, threats=[], confidence=1.0,
            sanitized_response=response, redactions=[],
        )

    # Layer 1
    r1 = await asyncio.to_thread(
        output_regex_filter.scan, response,
        allowed_emails=allowed_emails, allowed_domains=allowed_domains,
    )
    if r1.action == "block":
        return OutputScanResult(
            verdict="block", triggered_layer=1, threats=r1.threats, confidence=r1.confidence,
            sanitized_response=None, redactions=[],
        )
    if r1.action == "redact":
        return OutputScanResult(
            verdict="redact", triggered_layer=1, threats=r1.threats, confidence=r1.confidence,
            sanitized_response=r1.sanitized_text, redactions=r1.redactions,
        )
    clean_text = r1.sanitized_text

    # Layer 2
    r2 = await asyncio.to_thread(output_embedding_sim.scan, clean_text, threshold=embedding_threshold)

    if r2.matched:
        return OutputScanResult(
            verdict="block", triggered_layer=2, threats=["policy_violation"], confidence=r2.confidence,
            sanitized_response=None, redactions=[],
        )

    # Layer 3
    if not use_llm:
        return OutputScanResult(
            verdict="pass", triggered_layer=None, threats=[], confidence=1.0 - r2.max_similarity,
            sanitized_response=clean_text, redactions=[],
        )

    try:
        if llm_backend == "openrouter":
            from kalpitlabs_guard.layers import openrouter_classifier
            r3 = await openrouter_classifier.scan_output_async(clean_text, api_key=openrouter_api_key)
        elif llm_backend == "llama-guard3":
            from kalpitlabs_guard.layers import llama_guard3_classifier
            r3 = await llama_guard3_classifier.scan_output_async(
                clean_text, model=ollama_model, base_url=ollama_url
            )
        else:
            r3 = await output_llm_classifier.scan_async(clean_text, api_key=api_key)
    except (ValueError, RuntimeError):
        return OutputScanResult(
            verdict="pass", triggered_layer=None, threats=["classifier_error"], confidence=0.0,
            sanitized_response=clean_text, redactions=[],
        )

    triggered = 3 if r3.verdict in ("block", "redact") else None
    return OutputScanResult(
        verdict=r3.verdict, triggered_layer=triggered, threats=r3.threats, confidence=r3.confidence,
        sanitized_response=clean_text if r3.verdict != "block" else None, redactions=[],
    )


class OutputGuard:
    """
    Stateful output guard with persistent whitelist configuration.

    Wrap this at application init time to avoid repeating whitelist
    config on every call.

    Parameters
    ----------
    allowed_emails:
        Email addresses that must never be redacted (exact match, case-insensitive).
        E.g. ``["support@finedge.internal"]``
    allowed_domains:
        Domains whose addresses must never be redacted.
        E.g. ``["finedge.internal"]`` allows all *@finedge.internal addresses.

    Example
    -------
    >>> guard = OutputGuard(allowed_emails=["support@finedge.internal"])
    >>> result = guard.scan("Please contact support@finedge.internal for help.")
    >>> result.verdict
    'pass'
    """

    def __init__(
        self,
        *,
        allowed_emails: list[str] | None = None,
        allowed_domains: list[str] | None = None,
    ) -> None:
        self.allowed_emails: list[str] = [e.lower() for e in (allowed_emails or [])]
        self.allowed_domains: list[str] = [d.lower() for d in (allowed_domains or [])]

    def scan(
        self,
        response: str,
        *,
        use_llm: bool = True,
        api_key: str | None = None,
        embedding_threshold: float | None = None,
    ) -> OutputScanResult:
        """Scan *response* using this guard's whitelist configuration."""
        return scan_output(
            response,
            use_llm=use_llm,
            api_key=api_key,
            embedding_threshold=embedding_threshold,
            allowed_emails=self.allowed_emails,
            allowed_domains=self.allowed_domains,
        )
