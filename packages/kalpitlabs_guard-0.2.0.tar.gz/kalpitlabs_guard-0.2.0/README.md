# kalpitlabs-guard

Multi-layer LLM prompt security scanner — regex + embeddings + Llama Guard 4 (via OpenRouter).
