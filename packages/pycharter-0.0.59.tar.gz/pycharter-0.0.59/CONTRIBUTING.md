# Contributing to PyCharter

Thank you for your interest in contributing. This document describes how to set up a development environment, run checks, and submit changes.

> **Before your first contribution**, read [`ARCHITECTURE.md`](ARCHITECTURE.md). It explains the two laws this package obeys — a stateless core, and configuration-driven domain artifacts — and the layer model every change must respect.
>
> If you are using an AI coding assistant (Claude Code, Cursor, Codex), also see [`AGENTS.md`](AGENTS.md) and the skills under [`.claude/skills/`](.claude/skills/).

## Prerequisites

- Python 3.11, 3.12, or 3.13
- Node.js 24+ (for the UI under `src/pycharter/ui`)

## Development setup

From the repository root:

```bash
python3 -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -U pip
pip install -e ".[dev]"
```

**Alternatively**, run `./scripts/setup.sh` from the repository root to create **`venv/`**, install editable **`[dev]`**, optional API/UI extras when present, and register **pre-commit** / **pre-push** hooks (same layout as `Makefile` `install-dev`).

## Running tests

```bash
pytest
```

## Linting and formatting

```bash
ruff format --check src/pycharter tests
ruff check src/pycharter tests
```

## Type checking (Python)

```bash
mypy src/pycharter
```

CI runs `mypy` with a non-failing fallback; fixing new type errors is still appreciated.

## UI (Next.js)

```bash
cd src/pycharter/ui
npm ci
npm run type-check
```

See [`src/pycharter/ui/README.md`](src/pycharter/ui/README.md) for dev and build commands.

## Commit messages

This project uses [Conventional Commits](https://www.conventionalcommits.org/).
The changelog is generated automatically from commit messages.

Format: `<type>: <description>`

| Type | Changelog | Purpose |
|------|-----------|---------|
| `feat:` | Added | New feature |
| `fix:` | Fixed | Bug fix |
| `refactor:` | Changed | Code restructuring |
| `perf:` | Changed | Performance improvement |
| `docs:` | Documentation | Docs only |
| `test:` | *(skipped)* | Tests |
| `chore:` | *(skipped)* | Maintenance |
| `ci:` | *(skipped)* | CI/CD |

Examples:
```
feat: add Redis state store backend
fix: guard evaluation order in hierarchical states
docs: update quickstart guide
feat!: rename process() parameter ctx to context
```

Breaking changes: add `!` after type or `BREAKING CHANGE:` in body.

## Git workflow

Development happens on the `develop` branch. Releases are made from `main`.

```
feature branch → develop → main → tag → CI release
```

### Day-to-day development

```bash
git checkout develop
# ... make changes ...
git add -A
git commit -m "feat: add new feature"
git push origin develop
```

### Releasing

A release script is provided at `scripts/release.sh`. Run from the repo root.

```bash
# Step by step:
./scripts/release.sh commit        # stage + commit with auto-generated message
./scripts/release.sh push          # commit + push current branch
./scripts/release.sh merge-dev     # push + merge current branch → develop
./scripts/release.sh merge-main    # push + merge develop → main
./scripts/release.sh tag           # tag main with next patch version + push

# Or all at once:
./scripts/release.sh release       # full pipeline: commit → push → merge → tag
```

When a `vX.Y.Z` tag is pushed, GitHub Actions automatically:

1. Runs the full test suite
2. Writes release notes from conventional commits (via [git-cliff](https://git-cliff.org)) into `RELEASE_NOTES.md` for the GitHub Release body (the workflow does not push commits to `main`; update `CHANGELOG.md` via PR if you maintain one in-repo)
3. Creates a GitHub Release using those notes (`body_path: RELEASE_NOTES.md`)
4. Builds and publishes the package to PyPI

**Version numbers are derived from git tags** via `setuptools-scm`. There is no version string in the source code. The tag `v0.0.46` produces version `0.0.46` on PyPI.

## Frontend invariants

The pycharter Next.js UI under `src/pycharter/ui/` has a few load-bearing invariants. Violating any of them re-introduces bugs we've already paid for. Read the linked architecture docs before changing routing, tab plumbing, or the workspace store.

1. **No `router.replace` / `router.push` for shell-level routing outside `src/lib/navigation/`.** The single `NavigationController` is the only writer for auth gates, post-login bounce, and active-tab → URL sync. Click handlers and login forms are pure state writers. See [`src/lib/navigation/ARCHITECTURE.md`](src/pycharter/ui/src/lib/navigation/ARCHITECTURE.md).
2. **Tabs hydrate after auth resolves.** `<TabsHydrator />` waits for `authLoading === false` before flipping `tabs.hydrated`. The navigation controller refuses to push until both are true. Sequencing > guard-stacking. See [`src/lib/tabs/ARCHITECTURE.md`](src/pycharter/ui/src/lib/tabs/ARCHITECTURE.md).
3. **Every workspace loader purges sibling artifacts.** `loadContract` / `loadPipelineConfig` / `loadOntologyConfig` / `ingestOntologyBundle` / `loadPipeline` each drop assets and edges that don't belong on the canvas they're seeding. When you add a new asset kind, audit every loader. See [`src/stores/editor/workspace/ARCHITECTURE.md`](src/pycharter/ui/src/stores/editor/workspace/ARCHITECTURE.md).
4. **No `EditorStoresProvider` at the app shell.** Per-tab providers in `EditorTabContent` are the source of truth; a shell-level provider creates a second store instance that legacy module-level subscribers can capture.
5. **Compare normalised pathnames.** `next.config.js` sets `trailingSlash: true`, so `usePathname()` carries a trailing slash while tab URLs from `kind.urlPattern` don't. Use `normalizePathname()` from `lib/navigation/routes.ts` whenever you compare a pathname against a tab URL.

## Pull requests

1. Open an issue first for larger features or design changes so we can align early.
2. Keep changes focused; match existing style and patterns.
3. Add or update tests when behavior changes.
4. Target `develop` for feature work. Target `main` only for hotfixes.

## Community conduct

Please read [`CODE_OF_CONDUCT.md`](CODE_OF_CONDUCT.md). For security-sensitive reports, see [`SECURITY.md`](SECURITY.md).
