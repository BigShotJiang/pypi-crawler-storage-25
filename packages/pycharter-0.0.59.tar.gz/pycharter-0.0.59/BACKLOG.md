# PyCharter Backlog

Scope: product and architecture follow-ups that should remain visible across
UI/API/worker iterations.

Roadmap ADR: `docs/guides/worker-roadmap-adr.md`.

Status legend: `[ ]` pending · `[~]` in progress · `[x]` done · `[!]` blocked

---

## Worker Architecture

### 1.1 Modular worker boundary

- [x] Preserve the same coarse package boundaries used by pystator:
  `pycharter api`, `pycharter ui`, `pycharter db`, and `pycharter worker`
  should remain distinct layers with dedicated CLI commands.
- [x] Keep worker code under `src/pycharter/worker/` or clearly named
  worker subpackages. API routes may enqueue or inspect work, but should not
  own long-running worker execution loops.
- [x] Keep database concerns under `src/pycharter/db/` with migrations/models
  reusable by API and worker processes.
- [x] Keep UI worker surfaces observational/control-plane oriented: enqueue,
  inspect status, retry/cancel where supported, and view health/metrics.

### 1.2 Validation worker hardening

- [x] Treat the current validation worker as the foundation for continuous
  contract validation: database queue, claim/lease, retries, job status, and
  DLQ semantics.
- [x] Add UI status surfaces under Pipelines/Quality for validation worker
  queue depth, running jobs, failures, dead-letter jobs, and retry/cancel
  actions where backend support exists.
- [x] Document deployment topology: API and worker share database URL, worker
  can scale horizontally, and workers are optional for on-demand validation.

### 1.3 Pipeline worker

- [x] Add a durable pipeline worker modeled after the validation worker:
  database-backed queue, atomic claim, lease timeout, retry/backoff, graceful
  drain, and dead-letter handling.
- [x] Split worker job types cleanly rather than overloading validation jobs:
  pipeline jobs should have their own job model/source or a typed generic job
  abstraction with explicit payload schemas.
- [x] Persist pipeline run lifecycle and result data in `pipeline_runs` so the
  Pipelines UI works for local/API/worker-driven runs consistently.
- [x] Support pipeline execution from stored configs and config payloads, while
  keeping Python API / CLI / external orchestrator usage first-class.

### 1.4 Observability and DLQ

- [x] Make pipeline performance metrics, quality metrics, validation failures,
  poison/dead-letter records, and worker health visible from the merged
  Pipelines/Quality UI.
- [ ] Keep DLQ storage configurable and inspectable through the existing
  settings/DLQ primitives, but avoid coupling DLQ implementation details into
  page components.

---

## Pipelines and Quality UI

### 2.1 Merged IA follow-up

- [ ] Add a true Pipelines Health overview that summarizes pipeline run status,
  data quality score, open violations, threshold breaches, worker queue health,
  and DLQ/poison-message counts in one place.
- [ ] Promote sub-section URLs for quality views when the current embedded
  Quality page is split into route-addressable panels.
