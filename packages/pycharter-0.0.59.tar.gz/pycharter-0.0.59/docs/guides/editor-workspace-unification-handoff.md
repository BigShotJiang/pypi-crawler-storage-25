# Editor Workspace Unification — Handoff

If you're picking up this effort in a fresh session, start here. The
branch is `refactor/editor-workspace-unification`. This doc is the
single place that captures:

1. Current state — what ships today.
2. What's left — prioritized + with the specific code paths to touch.
3. Key design decisions already made (so you don't re-litigate them).
4. How to verify + merge.

Pair this with:

- `docs/guides/editor-architecture-adr.md` — the full ADR (plan + progress tracker + known gaps).
- `docs/guides/sprint-d-design.md` — the ontology-entity ↔ concept binding design.
- `docs/guides/editor-verification-checklist.md` — browser walkthrough for merge.
- `src/pycharter/ui/src/stores/editor/ARCHITECTURE.md` — day-to-day map of the editor state layer.

---

## 1. Current state (2026-04-25)

**~70 commits on `refactor/editor-workspace-unification`. 263 vitest
tests + 38 migration-CLI tests pass. tsc clean. Every commit passed
pre-commit.**

### Architecture (post-Sprint-G refactor)

Editor state now lives across **five purpose-built stores** instead
of three god-stores. Each owns one concern; they're wired together
with subscribe-side dual-writes from the legacy stores so all five
stay in sync until Phase 6 retires legacy:

| Store | Owns | File |
| ----- | ---- | ---- |
| ``useWorkspaceStore`` | Asset + edge data, save/load, selection, dirty/saving flags, loaded-artifact identity (selectedX), loading-flag mirrors, history (past/future) | ``stores/editor/workspace.ts`` |
| ``useEditorUIStore`` | Panel toggles, active tab, layer filter, empty-canvas override | ``stores/editor/editor-ui.ts`` |
| ``useReferenceDataStore`` | Concept types, tiers, relationship-type metadata, cardinality rules, scheme list, active scheme filter | ``stores/editor/reference-data.ts`` |
| ``useConceptSessionStore`` | Concept-mode session state: suggestions, suggestion-panel toggle, imported-schemas staging, per-row pending-edits, load error | ``stores/editor/concept-session.ts`` |
| ``usePipelineSessionStore`` | Pipeline-mode session state: isRunning, per-step status, lastRunResult, runHistory | ``stores/editor/pipeline-session.ts`` |

The legacy stores (``useEditorContractStore``,
``useEditorPipelineStore``, ``useEditorConceptGraphStore``) still
exist but no longer have any unique state — they are write-through
mirrors that dispatch to the right new store via subscribe.

Latest pass (2026-04-25, post-browser-verification rounds):
- Round 8/9 user-reported bugs fixed (edge persistence, selected-edge
  halo, contract-canvas ontology-entity rendering, rename/delete UI).
- §2.2 concept-dependency ordering shipped: `saveContractLayer`
  flushes `saveKnowledgeLayer` first when there are pending concept
  edits and a scheme is loaded.
- Sprint G first reader-migration cluster shipped: edge inspectors
  (Mapping/FK/Relationship), ContractOntologyPanel, JsonSchemaNode,
  TierProtectedDialog, ExportConceptGraphDialog, and the two
  edge-renderers (FK/Relationship hover) now read from workspace.
  Selection migrations use the new `useLegacySelection` hook.
- Reader footprint: **0 user-facing files** import a legacy editor
  store, down from 57. Sprints P–T worked through the canvas /
  shell / collab cluster:
  - **Sprint P** (``48f6a1eb``): ``app/editor/page.tsx`` fully off
    legacy.
  - **Sprint Q** (``0c58ba00``): ``useCanvasNodes`` and
    ``useCanvasEdges`` migrated through the workspace projector
    (new ``useContractEditorNodes`` / ``useContractEditorEdges``).
  - **Sprint R** (``5e9f2c4c``): ``ConceptCanvas.tsx`` (the largest
    remaining reader at 1322 lines / 30+ legacy refs) migrated to
    static wrapper references; new ``assetIdForCanvasNode`` helper
    bridges canvas node IDs to workspace asset namespaces
    (``concept:`` / ``table:`` / ``step:`` / ``pipeline-contract:``).
  - **Sprint S** (``f6e1f010``): ``EditorArtifactFormPanel`` Form-tab
    apply path migrated; new ``applyPipelineFormGraph`` /
    ``applyContractFormGraph`` wrappers wholesale-replace the
    legacy graph state through one call.
  - **Sprint T** (``c301d5ba``): ``workspace-session-adapter`` mirror
    block extracted to ``workspace-snapshot-legacy-apply`` so the
    collab adapter no longer imports legacy stores. Phase 6 deletes
    that helper module along with the legacy stores.

  All remaining references to the legacy stores live inside
  ``stores/editor/`` internal mirror / projection / wrapper modules
  that Phase 6 deletes wholesale.

- **Phase 6 substep 1 (Sprint U, ``59cb4f59``)** retired
  ``useEditorPipelineStore``: ~26KB store + 227 lines of legacy-only
  tests deleted. Every former pipeline-mode caller writes directly
  to workspace via the wrappers in ``workspace-canvas-add-mutators``;
  ``buildPipelineConfigFromWorkspaceState`` ports the legacy
  ``toPipelineConfig`` graph traversal onto workspace state.
- **Phase 6 substep 2 (Sprints V.1 + V.2, ``247057f4`` + ``33116477``)**
  retired ``useEditorConceptGraphStore``: ~40KB store + 269 lines of
  legacy-only tests deleted. ``concept-session.ts`` is now the
  canonical owner of ``suggestions`` / ``isSuggestionPanelOpen`` /
  ``importedSchemas`` / ``pendingEdits`` / ``loadError``; asset CRUD
  + slot mutators write to workspace directly; save / load /
  history use ``workspace.saveKnowledgeLayer`` /
  ``workspace.loadOntology`` / ``workspace.undoLayer('knowledge')``.
- **Phase 6 substep 3 (Sprint W, complete)**: retired
  ``useEditorContractStore`` (~60KB / 1700 lines store).
  - **W.1** (``e2e06bcc``): contract-mode ontology entities carry
    ``layers: ['contract']`` so the canvas reads workspace
    projection without leaking concepts-mode concepts.
  - **W.2** (``4fd3004a``): ``addJSONSchemaNode`` +
    ``addPipelineProcessNode`` palette wrappers write
    ``TableAsset`` / ``PipelineProcessAsset`` directly.
  - **W.3** (``c0a1f454``): ``onConnect`` connection-rule dispatch
    inlined onto workspace.
  - **W.4** (``c185c8fe``): ``workspace.loadContract`` runs the
    API fetch + graph build directly.
  - **W.5** (``f902b894``): ``applyContractCanvasNodeChanges``
    routes drag/remove for json-schema + pipeline-process to
    workspace primitives.
  - **W.6** (``7e2bff12``): ``beginNewContractWorkspace`` +
    ``beginNewPipelineWorkspace`` are workspace-native; no
    legacy delegation.
  - **W.7** (``b58a24d0``): ``applyContractFormGraph`` (form-tab
    apply) writes directly to workspace.
  - **W.8** (``7386ce33``): ``loadOntologyConfig`` ported to
    workspace; smoothstep / plain edge legacy fallback dropped.
  - **W.9** (``a5bfc8fa``): deleted ``contract.ts`` (~1700
    lines), ``workspace-to-legacy-mirror.ts`` (~210 lines),
    ``workspace-snapshot-legacy-apply.ts`` (~70 lines), and the
    two obsolete test files. Removed the editor-ui +
    reference-data → legacy reverse mirror subscribe blocks. Net
    deletion in W.9 alone: ~2400 lines.

**Phase 6 complete.** Three legacy editor stores retired; total
net deletion across Sprints U + V + W: **~4840 lines**. Workspace
+ concept-session + pipeline-session + editor-ui +
reference-data are the canonical state model. The
editor-architecture ADR Phase 6 milestone is closed.
  (2026-04-27 sweep:
  - ``SchemaFormCard``, ``ExportDialog``, ``CompanionPanel``,
    ``UnifiedFormView`` migrated via the workspace projector.
  - Projector extended to emit all three contract-canvas node
    types: ``json-schema`` (from ``TableAsset``),
    ``ontology-entity`` (from ``ConceptAsset``), and
    ``pipeline-process`` (from new ``PipelineProcessAsset``
    variant; Sprint I).
  - workspace→legacy ``selected*`` mirror closed; callers no
    longer need belt-and-suspenders legacy dispatches.
  - ``workspace-concept-mutators.ts`` (new) added asset- and
    slot-level helpers; ``OntologyFormCard``,
    ``OntologyNodeInspector``, ``OntologyEntityNode`` migrated.
    ``concept-graph`` slot mutators now mirror to the workspace
    asset.
  - ``PipelineProcessNode`` canvas renderer writes label edits
    through ``useWorkspaceStore.updateAsset``; the workspace→legacy
    mirror pushes the change back into the legacy contract store.
  - Three stale legacy-store mentions cleaned up in already-
    migrated files.)
- **Verification gap.** ~10 commits since the last user
  verification round. Re-walk the editor verification checklist
  (Schema form / Export / Companion panel / Toolbar version
  selector / Ontology inspector + form / Pipeline-process boxes)
  before starting Sprint J on the toolbar.
- **Sprint J — UnifiedEditorToolbar.** Six slices shipped
  (32 → 9 references in the file, 72% reduction). All four
  design blockers from the previous handoff are now closed:

  - Slice 1 (``127d4828``): ``nodes`` / ``edges`` through the
    projector; ``selectPrimaryLayer`` lifted to a local helper
    on ``EditorUIState.visibleLayers``.
  - Slice 2 (``0eb61028``): five redundant
    ``useEditorXxxStore.setState({selectedX: ...})`` writes in
    save-success handlers replaced with ``useWorkspaceStore
    .setSelectedX(...)``; mirror propagates back.
  - Slice 3 (``be1faf3c``): layer-aware ``undoLayer`` /
    ``redoLayer`` / ``pastLengthForLayer`` /
    ``futureLengthForLayer`` on workspace (history entries
    carry a ``tags`` set); toolbar contract + pipeline modes
    use them. Closes blocker #1.
  - Slice 4 (``5bc20222``): ``isDirty`` for contract /
    pipeline modes reads ``workspace.dirtyLayers.has(...)``;
    new ``markSavedLayer`` action. Closes blocker #2.
  - Slice 5 (``18c9f8d9``): ``namespace`` lifted onto
    ``SelectedContract`` / ``SchemaListItem``; toolbar derives
    from ``selectedContract.namespace``. Closes blocker #3.
  - Slice 6 (``3cdefb38``): ``clearLayer`` on workspace
    (undoable, layer-scoped wipe); toolbar's ``clearCanvas``
    dispatches ``clearLayer('contract')``. Closes blocker #4.

  - Slice 7 (``cbaa860c``): ``app/editor/page.tsx``'s
    ``isDirty`` subscription moved to
    ``workspace.dirtyLayers.has('contract')``. With no legacy
    ``isDirty`` reader left, the toolbar's nine residual
    ``markSaved()`` / ``setState({isDirty: false})`` calls
    became dead bookkeeping and are removed. Both legacy
    imports gone from the toolbar.

  **Toolbar references: 32 → 0** (full migration).
- ``loadContract`` / ``loadPipelineConfig`` / ``loadOntologyConfig``
  exposed on the workspace store as thin proxies that delegate to
  the legacy implementations. The pipeline proxy delegates to the
  **editor-pipeline** store (Phase 3 path). Five callers migrated.
- 12 new mirror-integration tests in
  ``__tests__/stores/sprint-g-store-mirrors.test.ts`` lock in the
  dual-write contract for all four new stores.
- Bidirectional editor-ui ↔ legacy mirror so callers can dispatch
  through either authority. ``UnifiedEditorToolbar`` and editor
  page now mutate the UI session via ``useEditorUIStore`` directly.
- Bidirectional reference-data ↔ legacy mirror; ``SchemeSelector``
  dispatches ``setSelectedSchemeId`` through the new store.

Shipped (summary — commit log has full detail):

- **Phase 0** done — Phase 0 audit.
- **Phase 1** done — `saveKnowledgeLayer` / `savePipelineLayer` /
  `saveContractLayer` on the workspace store; modals rewired (B).
- **Phase 3** done — canvas reads + writes both workspace-backed;
  flag flip (canvas-read default ON); legacy stores dual-write on
  every authoring mutator.
- **Phase 4** done — `components/unified-editor/` deleted; node /
  edge / form-view / toolbar / panels all under `components/editor/*`.
- **Phase 5.a** done — backend concept-slot API.
- **Phase 5.b** done — `pycharter.semantic.migrate_flat_attributes`
  CLI + 38 tests.
- **Phase 5.c** partially done — ontology-entity binding flow (D-a,
  D-b, D-c dialogs + wire-through). Follow-ups below.
- **Phase 5.d** done — `computeNodePolicy` wired into canvas.
- **Sprint A** done — field-level workspace selection
  (`selection.asset.fieldId`).

## 2. What's left (pick up in this order)

### 2.1 Sprint D follow-ups — **complete** (2026-04-25)

~~2.1.a attribute delegation~~ **done.** `useOntologyEntityBinding`
exposes `proposeUpdateAttribute` / `proposeRemoveAttribute`; bound
entities route through `concept-graph.updateSlot` / `removeSlot`.

~~2.1.b slot-backed read~~ **done.** Inspector lists slots from
the bound concept via `useWorkspaceConcept`; `slotToAttribute`
projects back to the legacy attribute shape.

~~2.1.c D-f tier gate~~ **done.** Hook exposes
`editable` + `boundTier`; inspector disables Add + editors and
shows a "Bound concept is core-tier" banner.

2.1.d — `addOntologyEntityNode` initial state ("NewClass" stub):
no action needed. The rename flow only auto-creates on meaningful
renames. Stub entities stay unbound until the user renames.

### 2.2 Contract-save concept-dependency ordering — **complete (2026-04-25)**

~~Subtle gap flagged in Sprint D review.~~ Shipped option (a) in
commit `a5072dcc`: `saveContractLayer` now calls
`saveKnowledgeLayer` first when the workspace has a loaded scheme
and `dirtyLayers` includes `'knowledge'`. Bare contract canvases
(no ontology authoring) skip the extra hop entirely.

Original options for reference:

- **(a)** `saveContractLayer` first calls `saveKnowledgeLayer` when
  there are pending concept edits on the bound concepts. Atomic.
- **(b)** Pre-save check surfaces a dialog: "Save knowledge layer
  first?" if bound concepts have pending edits.
- **(c)** Inline concept creation into the contract-save API call
  (server-side).

My pick: (a) — synchronous + invisible to users.

### 2.3 Sprint G — legacy-store deletion (multi-sprint, in progress)

49 non-store files (down from 57) still import one of
`useEditorConceptGraphStore` / `useEditorPipelineStore` /
`useEditorContractStore`. Writes dual-write to workspace, so the
legacy stores currently act as write-through caches.

**Cluster pattern that has worked so far:**

- **Selection reads** — swap `useEditorContractStore.selection` for
  `useLegacySelection()` from `workspace-hooks.ts`. The hook returns
  the namespace-stripped `{nodeId, edgeId, fieldId}` triple so
  existing equality checks against `node.id` keep compiling.
- **Asset reads (label / fields / schemaName)** — swap
  `s.nodes.find(...)` for `useWorkspaceTable(id)` /
  `useWorkspaceConcept(id)`.
- **Edge reads** — read `kind: 'foreign-key'` / `'mapping'` /
  `'semantic-rel'` from `workspace.edgesById`. Wrap in `useShallow`
  over a stable shape (sorted array, not Set) so unrelated workspace
  changes don't force re-renders.
- **Hover reads** — swap `useEditorContractStore.hoveredNodeId` for
  `useWorkspaceStore.hoveredAssetId` and strip the namespace
  prefix locally.
- **Mutators stay legacy** — they dual-write into workspace via the
  existing mirror, so the canvas keeps rendering correctly.

**Already migrated (read-side) in 2026-04-25 pass:**

- `app/editor/page.tsx` — 5 subscriptions (empty-canvas detect,
  pipeline-detect, hasTierBlockers, conceptsIsDirty/Saving,
  conceptsVersionLabel)
- `canvas/edges/ForeignKeyEdge.tsx` (hover, no legacy import)
- `canvas/edges/RelationshipEdge.tsx` (hover, no legacy import)
- `canvas/NewConceptDialog.tsx` (concept list)
- `canvas/nodes/JsonSchemaNode.tsx` (selection + FK source handles)
- `dialogs/ExportConceptGraphDialog.tsx` (pipeline-detect only)
- `dialogs/ReconciliationWizard.tsx` (existingKeys)
- `dialogs/TierProtectedDialog.tsx` (no legacy import)
- `form-view/PipelineFormSection.tsx` (selection only)
- `form-view/OntologyFormCard.tsx` (selection snapshot)
- `form-view/SchemaFormCard.tsx` (selection + selection snapshot)
- `inspectors/FieldInspector.tsx` (table-list models)
- `inspectors/ForeignKeyEdgeInspector.tsx`
- `inspectors/MappingEdgeInspector.tsx`
- `inspectors/RelationshipEdgeInspector.tsx`
- `inspectors/TestSidebarContent.tsx` (selectedPipeline)
- `panels/ContractOntologyPanel.tsx` (no legacy import)
- `shell/ConceptInspector.tsx` (schemeId)
- `shell/EditorArtifactFormPanel.tsx` (selectedX trio)
- `toolbar/ConnectionTypePopover.tsx` (entity labels + types)
- `toolbar/ExportDialog.tsx` (selectedOntology)
- `toolbar/OntologyVersionSelector.tsx` (loading flag)
- `toolbar/PipelineVersionSelector.tsx` (loading flag)
- `toolbar/VersionSelector.tsx` (loading flag)
- `toolbar/UnifiedEditorToolbar.tsx` (selectedX trio)
- `views/GlossaryView.tsx` (scheme)

**Patterns hit during the sweep that need a deeper migration:**

- ~~`selectedContract` / `selectedPipeline` / `selectedOntology`~~
  **done (2026-04-25, commit `69bfcc61`).** Workspace owns these
  three slices now; legacy contract store and editor pipeline
  store dual-write via `subscribe`.
- ~~`loadingContract` / `loadingPipeline` / `loadingOntology`~~
  **done (2026-04-25, commit `3b11ea88`).** Same subscribe-side
  mirror; toolbar version selectors read spinner state off
  workspace.
- `ontologyMeta` (concept types, tiers, scheme list, relationship
  types) — config metadata loaded from the API. Lives only on the
  contract store today; either mirror onto workspace or split into
  a shared config store.
- `runHistory` (pipeline run history), `pendingEdits` (concept-
  graph dirty set), `suggestions` / `isSuggestionPanelOpen` (concept
  suggestions UI) — store-specific session state. Keep on legacy
  until run history / suggestions move to a dedicated session store.
- `loadContract` / `loadPipelineConfig` / `loadOntologyConfig` —
  load mutators that hit the API and project the response into
  legacy stores. Workspace's ``loadOntology`` is the prototype; the
  contract + pipeline equivalents need to be ported before the
  toolbar version selectors can fully migrate.

**Deletion is a reader-by-reader migration**, not a single commit.
For each file:

1. Find all `useEditorXxxStore(...)` subscriptions.
2. Replace reads with workspace equivalents (see
   `stores/editor/workspace-hooks.ts` for existing typed hooks).
   Field-level subscriptions that need `{nodeId, fieldId}` use
   `workspace.selection` (Sprint A).
3. For writes: either (a) keep calling the legacy mutator (dual-
   write handles workspace) until Sprint G is complete, or (b)
   swap to workspace-native mutations and drop the legacy
   mutator in the same commit.
4. Browser-verify the touched feature.
5. Commit.

After the reader count reaches zero, delete the three store files +
their tests, and the mirror test file becomes obsolete too.

**Recommend**: tackle a small cluster per commit (e.g. "all edge
inspectors" — MappingEdgeInspector, ForeignKeyEdgeInspector,
RelationshipEdgeInspector — in one pass). Don't mix file-types in
one commit; each cluster should be reviewable in isolation.

**Priority order within Sprint G** (my estimate of risk × value):

1. Pure-read panels (NodePalette, FieldInspector section components)
   — safest, most value (these have no write path).
2. Inspector panels that use simple writes (SchemaNodeInspector,
   OntologyNodeInspector — already partial after Sprint D).
3. Toolbar elements (UnifiedEditorToolbar is the biggest — 794 LoC).
4. Save modals (already route through workspace saves; subscriptions
   still legacy).
5. InspectorPanel + CompanionPanel (hairy routing logic).

### 2.4 Deferred / out of scope

- **Phase 7** (ontology absorption) — separate ADR, not this branch.
- **Undo/redo sync** across legacy + workspace — resolves when
  Sprint G completes legacy deletion.
- **"Re-link entity to a different existing concept" atomic
  action** — only if a real use case shows up.

## 3. Key design decisions already made

**Do not re-litigate these. User confirmed in session 2026-04-25:**

- **(1)** Save modals — keep full legacy UX, reroute internals to
  `workspace.saveXxxLayer` (done in Sprint B).
- **(2a)** Name collision on entity create — **prompt user**; on
  confirm link + add 🔗 badge.
- **(2b)** Attribute collision — **prompt user**; on confirm add
  with indicator.
- **(2c)** Rename with binding — **prompt user**; on confirm break
  binding + auto-create/re-link.
- **(2d)** Concept-key convention — **snake_case**.
  (`normalizeConceptKey` enforces.)
- **(2e)** Unlink action — **no**, D-c is the escape hatch. Keeps
  flat-attribute orphans from re-emerging.
- **(2f)** Tier protection — **bound to core-tier = read-only from
  contract canvas**.
- **(3)** Drop pipeline-process buttons from contract palette.
- **(4)** Keep form view — important.
- **(5)** Field-level selection — extend workspace selection with
  `fieldId` on the asset variant (done in Sprint A).
- **(6)** Three-way mode toggle (concepts / pipeline / contracts) —
  stays for now.
- **(7)** Grow shell `EditorToolbar` to parity — deferred to Sprint G.

## 4. How to verify + merge

```bash
cd pycharter/src/pycharter/ui
npm run dev
# open http://localhost:3000/editor
```

Walk through **every item** in
`docs/guides/editor-verification-checklist.md` with a real user
workflow. The document groups checks by layer and names the sprints
that touched each code path, so if a workflow is broken you know
where to look.

Run:

```bash
cd pycharter
python -m pytest tests/unit/test_migrate_flat_attributes.py -q  # 38 tests

cd src/pycharter/ui
npx vitest run                                                  # 253 tests
./node_modules/.bin/tsc --noEmit                                # tsc clean
```

When ready:

```bash
git push origin refactor/editor-workspace-unification
gh pr create --base develop --title "..." --body "..."
```

## 5. Quick reference — where things live

| Concern | Path |
| ------- | ---- |
| Workspace store | `src/pycharter/ui/src/stores/editor/workspace.ts` |
| Workspace read hooks | `src/pycharter/ui/src/stores/editor/workspace-hooks.ts` |
| Adapters (legacy ↔ workspace) | `src/pycharter/ui/src/stores/editor/workspace-adapters.ts` |
| Contract edges adapters | `src/pycharter/ui/src/stores/editor/contract-edge-adapters.ts` |
| Table ↔ JSON Schema adapters | `src/pycharter/ui/src/stores/editor/table-adapters.ts` |
| Contract save projection | `src/pycharter/ui/src/stores/editor/contract-save-projection.ts` |
| Concept binding helpers | `src/pycharter/ui/src/lib/editor/concept-binding.ts` |
| Binding flow hook | `src/pycharter/ui/src/components/editor/inspectors/useOntologyEntityBinding.tsx` |
| Binding dialogs | `src/pycharter/ui/src/components/editor/inspectors/ConceptBindingDialogs.tsx` |
| Dev flags | `src/pycharter/ui/src/lib/editor/dev-flags.ts` |
| Node policy (readonly/editable) | `src/pycharter/ui/src/lib/editor/node-policy.ts` |
| Asset + selection types | `src/pycharter/ui/src/lib/editor/asset-types.ts` |
| Mirror integration tests | `src/pycharter/ui/src/__tests__/stores/legacy-workspace-mirror.test.ts` |

Legacy stores (retirement targets):

- `src/pycharter/ui/src/stores/editor/concept-graph.ts`
- `src/pycharter/ui/src/stores/editor/pipeline.ts`
- `src/pycharter/ui/src/stores/editor/contract.ts`

Each carries a docstring header documenting its dual-write contract.

## 6. Things to avoid

- Don't add new legacy-store methods that skip the workspace mirror.
- Don't inline asset ↔ legacy projection — use the canonical
  adapters + the reverse adapters (`assetToConceptNode`, etc.).
- Don't delete a legacy store method without first checking every
  reader; the integration tests in `legacy-workspace-mirror.test.ts`
  catch the contract-level regressions.
- Don't re-open design decisions §3 lists without asking the product
  owner first.
- Don't land changes that materially alter user-visible UX without
  browser-verifying — unit tests catch data-plane bugs but not
  dialog-flow / selection-lifecycle regressions.
