# Editor Workspace Unification — Browser Verification Checklist

Run through this before merging `refactor/editor-workspace-unification`
to catch behaviour regressions that unit tests don't cover. Each item
pairs a user-visible workflow with the sprints that touched its code
path, so if something is broken you know where to look.

Set up:

```bash
cd pycharter/src/pycharter/ui
npm run dev
```

Open `http://localhost:3000/editor`. Two URL flags affect the runtime:

- `?workspace-canvas=0` — revert to legacy canvas reads (default: on)
- `?workspace-save=1` — route Save through workspace.saveXxxLayer
  (default: off — modal path is default)

## Knowledge / concept layer

Touches Sprints 1–6, 14, 16–19, 23–25.

- [ ] **Load an ontology.** Pick a scheme from the left panel. Nodes
      render on the canvas. Legacy `?workspace-canvas=0` should look
      identical.
- [ ] **Switch schemes.** Counts stabilise — no duplicated or leaked
      concepts from the prior scheme (Sprint 3 bug class).
- [ ] **Rename a concept** (double-click header). Name updates in
      the canvas node, Glossary view, and any open inspector.
- [ ] **Add a slot** via the `+` button on the node header. Slot
      appears; save button shows dirty.
- [ ] **Click a concept node.** Inspector opens with the right
      content. ImpactAnalysisTab (if visible) shows no empty state.
- [ ] **Drag-delete** via right-click → delete. Node disappears,
      incident edges gone, inspector closes if it was focused.
- [ ] **Cmd-Z** reverts the last knowledge-layer edit (add, rename,
      delete). Cmd-Y redoes.
- [ ] **Cmd-S** saves. Orange dirty dot clears. Reload — changes
      persisted.
- [ ] **Core-tier concept** is read-only: inspector fields are
      disabled, rename double-click shows "read-only" tooltip, Plus
      button hidden (NodePolicy from Sprint 6).
- [ ] **Deprecated concept** shows read-only for the same reasons.

## Execution / pipeline layer

Touches Sprints 3, 7, 14, 22.

- [ ] **Load a saved pipeline** from the left-panel file browser.
      Steps + edges render.
- [ ] **Drop a new step** from the palette. Save button dirties.
- [ ] **Connect two steps** by dragging between handles. New edge
      appears; save dirties.
- [ ] **Drop a contract onto the canvas** from the file browser.
      Contract node renders; connect it to a step and confirm the
      step's shield icon lights up (governed indicator).
- [ ] **Edit step label** via inspector; persists through save.
- [ ] **Remove step** via right-click. Incident edges cascade.
- [ ] **Save pipeline**. Reload; everything persists (including
      contract nodes + their edges).
- [ ] **ImpactAnalysisTab** highlights downstream consumers when a
      step is selected.

## Ontology-entity ↔ concept binding (new, Sprint D)

- [ ] **Drop an entity and rename to a fresh name** (e.g. "Widget").
      A "widget" concept auto-creates in the knowledge layer. The
      class-name field shows "🔗 Bound to concept `widget`" under it.
      The node in the canvas shows a 🔗 glyph next to the name.
- [ ] **Drop an entity and rename to a name that already exists**
      (e.g. pick a concept that's loaded in the knowledge layer).
      A dialog asks "Link to existing `<key>`? Cancel / Link to
      existing". Link confirms → entity bound. Cancel → entity stays
      unbound (name commits, no binding).
- [ ] **Rename a bound entity to a different name**. Dialog warns
      "Break binding to existing `<prev>`? Continue / Cancel".
      Continue → binding updates (auto-create + re-bind). Cancel →
      rename reverts (entity keeps old name + binding).
- [ ] **Add an attribute whose name already exists as a slot** on
      the bound concept. Dialog "Use existing slot `<name>`?".
      Add → no new slot created; cancel → attribute not added.
- [ ] **Add an attribute whose name is fresh**. Slot appears on the
      bound concept (visible in any other inspector that renders
      that concept — knowledge-layer canvas, Glossary view, etc.).
- [ ] **Known open in Sprint D:** the inspector's attribute list
      still reads `data.attributes` (legacy flat view), not the
      bound concept's slots. A follow-up will swap the read so the
      list shows slot-backed rows with an indicator.

## Contract layer

Touches Sprints 4, 8–12, 20.

- [ ] **Load a contract** from the file browser. json-schema nodes
      render with property rows; mapping / FK / relationship edges
      draw correctly.
- [ ] **Click a schema node** — inspector opens. Edit `schemaName`;
      persists.
- [ ] **Click a field row** — FieldInspector opens on the selected
      property. Edit the field name; persists.
- [ ] **Add a property** via the `+` in SchemaNodeInspector. Row
      appears on the node; save dirties.
- [ ] **Remove a property**; incident FK edges drop.
- [ ] **Draw an FK edge** (SQL-table → SQL-table). Edge renders;
      save dirties.
- [ ] **Delete a mapping / FK / relationship edge** via its
      inspector panel's Delete button. Edge gone from canvas.
- [ ] **Save contract** via the modal. Reload — changes persisted.

## Cross-layer

Touches Sprints 2, 14, 16, 18.

- [ ] **Layer toggles** (Execution / Contract / Knowledge buttons
      on LayerToggleBar) hide / show the right asset kinds.
- [ ] **Switching modes** (concepts / pipeline / contracts) keeps
      each layer's state distinct — no leakage across canvases.
- [ ] **Selection syncing.** Click a concept, switch mode, switch
      back — selection still highlights that concept.
- [ ] **Dev flag round-trip.** With `?workspace-canvas=0` the app
      still loads, renders, and saves. Flip to default (remove the
      param) and confirm the same content appears.

## Dev-path saves (optional)

Touches Sprints 9 + 12. Only run if you want to validate the
workspace save alternative.

- [ ] Append `?workspace-save=1` to the URL.
- [ ] In knowledge mode, hit Save. A native prompt asks for
      `name:version`. Enter values. Confirm contract saved.
- [ ] Same for pipeline mode → `workspace.savePipelineLayer`.
- [ ] Same for contract mode → `workspace.saveContractLayer`.
- [ ] Reload (without the flag). Data appears. No console errors.

## Known open items (don't test; documented)

- Flat-attribute editor in `OntologyNodeInspector` (unified-editor)
  is still the authoritative writer of `attributes`. Don't expect
  the editor to route through concept slots yet.
- `components/unified-editor/` components still read the legacy
  contract / pipeline stores. Dual-writes keep them in sync with
  the workspace, but these files are not yet migrated.
- Undo / redo on the legacy stores does not rewind workspace
  history. Mixed-sequence undo after a save may look odd.

## What to do if a workflow is broken

1. Open the browser console. Look for stack traces referencing a
   `:` namespaced id — that's workspace-layer.
2. Try `?workspace-canvas=0`. If the workflow works with the flag
   off, the regression is in a workspace read path.
3. Check `git log --oneline refactor/editor-workspace-unification`
   and find the sprint that touched the broken path. Each commit
   names the sprint in its subject.
4. Unit tests under `src/pycharter/ui/src/__tests__/` may already
   cover the case — run `npx vitest run` first.

## Post-verification

After every item passes, it's safe to merge. Phase 4 work (deleting
`components/unified-editor/`) is a **separate branch** and should not
block merging this one.
