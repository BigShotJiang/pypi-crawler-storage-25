# ADR: PyCharter Worker Roadmap

**Status:** Accepted; initial product-ready implementation in progress
**Date:** 2026-05-04
**Deciders:** Austin; TBD reviewers

## Context

PyCharter already ships a validation worker under `src/pycharter/worker/`.
It is a broker-free, database-backed service that polls `validation_jobs`,
claims work atomically, runs contract-backed quality validation, and records
job status/results. The API exposes producer/status routes under
`/api/v1/validation/jobs`, and the CLI starts the service with
`pycharter worker start`.

The next worker work must not blur architectural layers. PyCharter should
mirror PyStator's modular shape: `api`, `ui`, `db`, and `worker` are distinct
layers with dedicated CLI boundaries. The worker layer is optional runtime
infrastructure, not a dependency of the stateless core.

## Decision

PyCharter will treat workers as long-running execution services that consume
public core/store APIs and shared database models. Workers may process queued
jobs and emit status/metrics, but they must not move business logic out of the
core or own API/UI concerns.

Required boundaries:

- `src/pycharter/api/` owns HTTP request/response handling, enqueue/status
  routes, and control-plane endpoints such as cancel/retry.
- `src/pycharter/ui/` owns observation and control surfaces. It may enqueue,
  inspect, cancel, retry, and display health, but it must call the API rather
  than reaching into worker internals.
- `src/pycharter/db/` owns migrations and SQLAlchemy models shared by API and
  worker processes.
- `src/pycharter/worker/` owns long-running service loops, job claiming,
  execution orchestration, graceful drain, and worker-specific configuration.
- Core packages such as `quality`, `pipeline_generator`, and semantic pipeline
  modules remain reusable by Python API, CLI, API routes, external
  orchestrators, and workers.

## Current Validation Worker

The existing validation worker is Phase 1 foundation, not throwaway code.

Current shape:

- CLI dispatch: `pycharter worker start` via `src/pycharter/_cli_commands.py`
  and `src/pycharter/worker/cli.py`.
- Queue/status API: `src/pycharter/api/routes/v1/validation_jobs.py`.
- API job manager: `src/pycharter/api/services/database_job_manager.py`,
  delegating to the worker job source instead of owning processing loops.
- Worker loop: `src/pycharter/worker/runner.py`.
- Validation processor: `src/pycharter/worker/processor.py`.
- Durable queue model: `src/pycharter/db/models/validation_job.py`.
- Public Python enqueue/status helpers: `pycharter.worker.submit_job`,
  `submit_job_sync`, and `get_job`.

Implementation notes:

- Lease expiration, stale claim release, retry/backoff, cancellation-safe
  completion, failed/dead-letter filtering, max attempts, stats, and health are
  covered by worker job-source behavior and focused tests.
- The current worker DLQ is represented by `dead_letter` rows in the worker
  queue tables. Dedicated `dead_letter_queue` persistence remains reserved for
  a future replay-oriented DLQ console.
- Confirm store/backend support matches the broader PyCharter persistence
  contract. The current processor chooses SQLite/Postgres contract stores from
  the DB URL; MongoDB behavior needs an explicit decision before being promised.

## Pipeline Worker Roadmap

The pipeline worker should be a separate durable service path, not an overload
of `validation_jobs`.

The preferred shape is either:

1. A dedicated pipeline job model/source for pipeline execution jobs.
2. A typed generic job abstraction with explicit payload schemas and job-kind
   processors.

Do not mix pipeline work into validation-specific payloads.

The pipeline worker must support:

- Database-backed queue with atomic claim, lease timeout, retry/backoff,
  graceful drain, and dead-letter handling.
- Stored pipeline configs and submitted config payloads.
- Consistent `pipeline_runs` lifecycle persistence for local/API/worker-driven
  runs.
- Python API, CLI, and external orchestrator usage as first-class entry points.
- API endpoints to enqueue, inspect, cancel, retry, and list pipeline jobs.
- UI health surfaces that can show pipeline run status, worker queue health,
  DLQ/poison messages, quality failures, and performance metrics.

## Phases

### Phase 1: Validation Worker Hardening

- Audit current job lifecycle behavior and tests.
- Document retry, lease, timeout, cancellation, and DLQ semantics.
- Add missing stats/health endpoints needed by the UI.
- Add Pipelines/Quality UI surfaces for validation job status and failures.

### Phase 2: Pipeline Run Persistence

- Make `pipeline_runs` the canonical lifecycle record for pipeline execution.
- Align synchronous API runs, async API/SSE runs, CLI runs, and future worker
  runs around the same persisted lifecycle fields.
- Define minimal queue/status API contracts for pipeline jobs.

### Phase 3: Pipeline Worker

- Add the durable pipeline job source and worker processor.
- Add `pycharter worker pipeline` as a separate CLI boundary from
  `pycharter worker start`.
- Keep validation and pipeline processors independently testable.

### Phase 4: Pipelines Health UI

- Add a merged health overview under Pipelines/Quality.
- Surface validation queue health, pipeline queue health, DLQ counts, recent
  failed jobs, run durations, quality scores, and threshold breaches.
- Keep UI components API-backed and free of direct worker/db coupling.

## Consequences

- Worker development starts with documentation and contracts, then incremental
  implementation.
- Existing validation worker code remains useful but must be hardened before
  becoming the template for pipeline execution.
- Pipeline worker design can reuse common queue patterns, but validation and
  pipeline payloads remain explicit and independently evolvable.
- UI can show functioning pipeline and quality pages today using existing APIs,
  then progressively add worker health as backend support lands.

## Follow-up Backlog

Implementation tasks are tracked in `BACKLOG.md` under "Worker Architecture".
