# Sprint D — Ontology-Entity ↔ Concept Binding Design

The legacy flow: users drop an "Ontology Entity" on the contract
canvas, give it a name, and populate `data.attributes[]` locally.
Two contracts both adding an `email` attribute to a `Customer`
entity produce two disconnected records. Knowledge-layer
`Customer.email` — if it exists — is unaware.

The Sprint D flow binds every entity to a real concept in the
knowledge layer. Edits on the entity's "attributes" are edits on
the bound concept's `slots[]`, visible everywhere.

## Data shape

`OntologyEntityNodeData` gains an optional field:

```typescript
conceptKey?: string | null;
```

- `null` / undefined — legacy unbound entity; `attributes` is still
  the source of truth.
- `string` — bound to the concept whose `concept_key` matches.
  `attributes` is a derived view of the bound concept's slots.

## Concept-key normalisation

Human display name → stable `concept_key`:

```
"Customer"        → "customer"
"Customer Order"  → "customer_order"
"order/line-item" → "order_line_item"
```

Implementation: `normalizeConceptKey(displayName)` in
`src/lib/editor/concept-binding.ts`. Snake-case is the chosen
convention (per user decision D-d, 2026-04-25).

## Three decision points

### D-a — name collision on entity create / first meaningful rename

The user types "Customer" as the entity name. A concept with
`concept_key === "customer"` already exists in the workspace.

**Prompt (per user decision):**
> "Customer" already exists in the knowledge layer. Link this
> entity to the existing concept? (Yes / Cancel)

- **Link:** set `conceptKey = "customer"`. Attach 🔗 badge to the
  entity node. Attributes view switches to the bound concept's
  slots.
- **Cancel:** keep the entity unbound. The user can choose a
  different name.

No silent auto-link — collisions are always user-confirmed.

### D-b — attribute collision on add

Entity is bound to a concept that already has an `email` slot.
User tries to add another `email` attribute from the entity
inspector.

**Prompt:**
> Slot "email" already exists on the bound "Customer" concept.
> Add this attribute anyway? (Add / Cancel)

- **Add:** no-op on the concept (the slot is already there). The
  attribute row renders with a 🔗 "existing slot" indicator so the
  user knows this data is shared.
- **Cancel:** the attribute is not added.

No error, no silent merge — the user confirms.

### D-c — rename with an active binding

Entity is bound to `customer`. User renames the entity to "Client".

**Prompt:**
> Renaming this entity will break its binding to the existing
> "customer" concept and create a new "client" concept. Continue?
> (Continue / Cancel)

- **Continue:** break the binding (`conceptKey` set to new key,
  badge switches to point at the new concept). If a "client"
  concept already exists, fall through into the D-a prompt. If
  not, auto-create.
- **Cancel:** the rename is reverted.

### D-e — unlink (user decision 2026-04-25)

**No unlink action.** D-c already provides the escape hatch. Not
supporting `unlink` prevents orphan flat-attribute entities from
re-emerging. A distinct "re-link to a different existing concept"
action may land later if a real use case materialises.

### D-f — tier protection

User decision 2026-04-25: **tier-protected concepts are read-only
from the contract canvas.** Attribute editing is disabled on an
entity bound to a core-tier concept. The existing
`computeNodePolicy` already enforces this for concept-layer
rendering; the entity inspector re-uses the same helper.

### D-d — concept-key convention

Snake case. See `normalizeConceptKey`.

## Implementation staging

1. **Data + helpers** (this commit): `conceptKey` field on
   `OntologyEntityNodeData`; `normalizeConceptKey` +
   `findConceptByKey` in `lib/editor/concept-binding.ts`.
2. **Dialog components**: three shadcn-style confirmation dialogs
   — `LinkConceptDialog`, `AttributeConflictDialog`,
   `RenameBreakBindingDialog`.
3. **Mutator rewiring**: in the contract store, `addOntologyEntityNode`
   drops with `conceptKey: null` (no name to collide on yet). The
   *rename* path (`updateNodeData` with a changed `entityName`) is
   where the decision-point logic runs — it checks D-a / D-c and
   auto-creates the concept when the name is new.
   `addOntologyAttribute` runs D-b and delegates to concept-graph
   `addSlot` when confirmed. `updateOntologyAttribute` /
   `removeOntologyAttribute` delegate to concept-graph
   `updateSlot` / `removeSlot`.
4. **Rendering**: `OntologyEntityNode` shows a 🔗 badge when bound;
   the inspector's "attributes" list is fed from the bound
   concept's slots and marks entries that match existing slots.
5. **Tier gate**: inspector disables editing when
   `computeNodePolicy(boundConceptAsset, activeLayers).editable` is
   false.

Each stage is independently testable + browser-verifiable.

## Test plan

Unit:
- `normalizeConceptKey` — the examples above.
- `findConceptByKey` — present / absent / mixed-kind assets.
- Each decision-point dialog renders the expected copy given a
  payload.
- Mutator-level: rename flow triggers D-a when collision, D-c when
  bound, auto-creates when neither.

Integration (browser / RTL):
- Drop entity → rename → collision prompt → link → badge visible +
  attributes from concept.
- Add attribute with collision → prompt → add → indicator visible.
- Rename bound entity → prompt → continue → new binding.
- Bound to core-tier concept → attribute editing disabled.

## Out of scope for this sprint

- "Unlink" action (D-e — explicitly no).
- "Re-link to different existing concept" atomic action (deferred
  until a real use case).
- Cross-contract concept rename propagation UI (concept renames
  already propagate via the workspace; no extra UX needed here).
