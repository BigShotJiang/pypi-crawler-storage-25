# Workers

Run validation and pipeline jobs asynchronously in separate worker processes.
Workers poll database-backed queues, claim jobs atomically, execute public
PyCharter APIs, and update job/run status. No message broker is required.

## Overview

- **Database-backed queues**: Validation jobs live in `validation_jobs`; pipeline jobs live in `pipeline_jobs`.
- **Multiple workers**: You can run several worker processes; each job is claimed by exactly one worker.
- **Same database**: The API (or any process with DB access) enqueues jobs; workers use the same database URL.
- **Durable pipeline runs**: Worker-driven pipeline jobs update `pipeline_runs`, the same lifecycle table used by the Pipelines UI.

For the broader worker roadmap, including modular layer boundaries and the
future pipeline worker, see [PyCharter Worker Roadmap ADR](worker-roadmap-adr.md).

## When to use the worker

- **Non-blocking validation**: API returns immediately with a `job_id`; clients poll for status.
- **Heavy or slow checks**: Offload validation to background processes so the API stays responsive.
- **Scaling**: Add more worker processes to increase throughput.

## Prerequisites

- Database configured (PostgreSQL or SQLite) with PyCharter schema applied (`pycharter db init` or `pycharter db upgrade`).
- The `validation_jobs` table exists (created by migrations).

## Running the worker

### 1. Set the database URL

The worker uses the same configuration as the rest of PyCharter. Set one of:

- **Environment**: `PYCHARTER_DATABASE_URL` or `PYCHARTER_WORKER_DB_URL`
- **Config file**: `pycharter.cfg` or project config with a `[database]` section

Verify connectivity:

```bash
pycharter db current
```

### 2. Start worker processes

```bash
# Default: 5 concurrent pollers, 500 ms poll interval
pycharter worker start

# Pipeline execution worker
pycharter worker pipeline
```

**CLI options:**

| Option | Description | Default |
|--------|-------------|---------|
| `--concurrency` | Number of concurrent poller tasks | `5` |
| `--poll-interval` | Poll interval in milliseconds | `500` |

Examples:

```bash
# Fewer pollers, slower polling
pycharter worker start --concurrency 2 --poll-interval 1000

# More pollers for high throughput
pycharter worker start --concurrency 10

# Pipeline worker with custom polling
pycharter worker pipeline --concurrency 2 --poll-interval 1000
```

Stop a worker with **Ctrl+C**. It will finish in-flight jobs (up to the drain timeout) then exit.

## Submitting jobs

### From the API

If the API is running and the database is shared with the worker:

- **Submit**: `POST /api/v1/validation/jobs` with JSON body (contract name/version, data source, options).
- **Status**: `GET /api/v1/validation/jobs/{job_id}`.
- **Cancel**: `POST /api/v1/validation/jobs/{job_id}/cancel` (if supported).
- **Health/stats**: `GET /api/v1/validation/jobs/health` and `GET /api/v1/validation/jobs/stats`.

For pipeline worker jobs:

- **Submit**: `POST /api/v1/pipeline/jobs` with a parsed pipeline config body.
- **List**: `GET /api/v1/pipeline/jobs`.
- **Stats**: `GET /api/v1/pipeline/jobs/stats`.
- **Cancel**: `POST /api/v1/pipeline/jobs/{run_id}/cancel`.

See the [REST API](../api/rest-api.md) or Swagger UI for the exact request/response shapes.

### From Python

Use the worker package to enqueue jobs from any process that has database access:

```python
from pycharter.worker import submit_job_sync

job_id = submit_job_sync(
    contract_name="user_schema",
    contract_version="1.0",
    data_source="/path/to/data.json",
    options={"record_violations": True},  # optional
)
print(f"Job submitted: {job_id}")
```

Async variant:

```python
from pycharter.worker import submit_job, get_job

job_id = await submit_job(
    contract_name="user_schema",
    contract_version="1.0",
    data_source="s3://bucket/data/users.parquet",
    options={"include_profiling": True},
)

# Later: check status
status = await get_job(job_id)
```

Optional arguments for `submit_job` / `submit_job_sync`:

- **`options`**: Dict passed to the validation run (e.g. `record_violations`, `calculate_metrics`).
- **`job_id`**: Custom job ID (otherwise auto-generated).
- **`idempotency_key`**: Deduplication key; duplicate submits return the existing job ID.
- **`max_attempts`**: Max processing attempts before the job is marked failed (default `5`).
- **`db_url`**: Override database URL (default: from config/env).

## Architecture

```mermaid
flowchart LR
    API[API / Client] --> VQ[(validation_jobs)]
    API --> PQ[(pipeline_jobs)]
    PQ --> PR[(pipeline_runs)]
    VQ --> VW[Validation worker]
    PQ --> PW[Pipeline worker]
    VW --> VQ
    PW --> PQ
    PW --> PR
```

1. **Producer**: API or Python code inserts a `pending` row into the relevant job table.
2. **Worker**: Each worker process runs several poller tasks. A poller claims a `pending` job, setting `claimed_by`, `claimed_at`, and incrementing `attempt`.
3. **Execution**: Validation jobs run `QualityCheck`; pipeline jobs run `Pipeline.from_dict(...).run(...)`.
4. **Result**: Success marks the job `completed`. Retryable failure returns the job to `pending` with backoff. Exhausted failure moves it to `dead_letter`. Pipeline jobs also update `pipeline_runs`.

## Status semantics

| Persisted status | API/UI meaning |
|------------------|----------------|
| `pending` | Queued and waiting for a worker |
| `claimed` | Running in a worker process |
| `completed` | Worker job completed successfully |
| `failed` | API alias for terminal failures; persisted validation failures normally become `dead_letter` after retries |
| `dead_letter` | Attempts exhausted; operator review or replay is required |
| `cancelled` | Cancelled by API/operator |

Late completions do not overwrite `cancelled` jobs. Validation and pipeline
jobs both expose aggregate stats for queued, running, completed, failed,
dead-letter, cancelled, and total counts.

## Configuration summary

| Source | Purpose |
|--------|---------|
| `PYCHARTER_DATABASE_URL` | Default database URL (worker and API). |
| `PYCHARTER_WORKER_DB_URL` | Override database URL for the worker only. |
| `PYCHARTER_WORKER_DLQ_DATABASE_URL` | Reserved for dedicated DLQ persistence; current worker jobs use `dead_letter` status in their queue tables. |
| `PYCHARTER_WORKER_DLQ_TABLE_NAME` | Reserved table name for future dedicated DLQ persistence. |
| `PYCHARTER_WORKER_DLQ_ENABLED` | Reserved toggle for future dedicated DLQ persistence. |
| `--concurrency` | Number of poller tasks per process. |
| `--poll-interval` | Milliseconds between polls when no job is available. |

Additional worker settings can be configured via env or `pycharter.cfg` `[worker]`:
`PYCHARTER_WORKER_DRAIN_TIMEOUT_S`, `PYCHARTER_WORKER_MAX_ATTEMPTS`,
`PYCHARTER_WORKER_CLAIM_LEASE_TIMEOUT_S`, `PYCHARTER_WORKER_RETRY_BACKOFF_BASE_MS`,
`PYCHARTER_WORKER_RETRY_BACKOFF_MAX_MS`, `PYCHARTER_WORKER_EXECUTION_TIMEOUT_S`, and
`PYCHARTER_WORKER_ID`.

## Data sources

Validation runs use the same data source support as [QualityCheck](../api/quality-check.md): local files, S3-style URLs, or other backends your quality check is configured for. Pass the same `data_source` string you would use for a synchronous quality check.

## Troubleshooting

### Worker won’t start

- **"No database URL"**: Set `PYCHARTER_DATABASE_URL` or `PYCHARTER_WORKER_DB_URL` (or configure in `pycharter.cfg`).
- **Connection errors**: Ensure the database is reachable and migrations are applied: `pycharter db current`.

### Jobs stay pending

- Confirm at least one worker is running (`pycharter worker start`).
- Check worker logs for errors (e.g. validation failures, missing contract, or data source issues).
- Verify the same database URL is used by the process that submits jobs and the worker.

### Retries and failures

- Each job has `max_attempts` (default 5). After that, the job is marked failed.
- Inspect the job row or use `get_job(job_id)` / the REST endpoint to see error message and result.

## See also

- [Quality Check API](../api/quality-check.md) — synchronous validation (same logic the worker runs).
- [REST API](../api/rest-api.md) — validation job endpoints.
- [Production Deployment](production.md) — running the worker in production.
- [PyCharter Worker Roadmap ADR](worker-roadmap-adr.md) — validation worker hardening, pipeline worker phases, and API/UI/DB/worker boundaries.
