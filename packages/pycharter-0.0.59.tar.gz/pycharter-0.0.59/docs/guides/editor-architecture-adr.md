# ADR: Unify the pycharter Editor — Retire Legacy Paths, Adopt the Workspace-Store Foundation

**Status:** Proposed (revised 2026-04-22 after Phase 0 audit)
**Date:** 2026-04-22 (progress last updated 2026-04-24)
**Deciders:** Austin (product owner); TBD reviewers
**Supersedes:** Implicit phased-migration posture of the "editor-v2 rename" and "Phase 3 pipeline store split"

## Progress tracker

Implementation progress on branch `refactor/editor-workspace-unification`:

| Phase | Status | Notes |
|---|---|---|
| 0 — Ratify + audit | ✅ done | Audit findings folded into §2.3 and §5 |
| 1 — Save-path completion | 🟢 knowledge + pipeline shipped | Contract save deferred; needs TableAsset enrichment |
| 2 — Shell parity | 🟡 partial | Concept + pipeline-step inspectors at parity with aux panels; contract tab + form view deferred (blocked on asset enrichment) |
| 3.a — Pure projections | ✅ done | conceptAssetsToFlowNodes + pipelineAssetsToFlowNodes, unit-tested |
| 3.b — Load mirror | ✅ done | workspace.ingestOntologyBundle + page-level parallel load |
| 3.c — Canvas dual-writes | 🟢 substantially done | Node updates / removes / creations + rename + slot-add + pipeline edge creation + concept relationship creation mirrored. Edge deletions, pipeline-contract nodes/edges, and contract-layer mutations still legacy-only |
| 3.b proper — Flag-guarded canvas reads | ✅ done | Workspace-backed reads default on (Sprint 14) for every layer — concept, pipeline step, pipeline contract, contract table. `?workspace-canvas=0` is the opt-out for debugging. Pipeline projection parity (stepStatus + governed edges) landed in Sprint 14. |
| 3.c — Canvas dual-writes | ✅ done | Canvas handlers + all legacy store mutators now mirror to workspace (Sprints 7, 8, 11, 14). Undo/redo on legacy stores is the only remaining gap — does not rewind workspace state. |
| 3.d — Selection migration | ✅ done | Every legacy selection action dual-writes to workspace (Sprint 16). `ImpactAnalysisTab` reads workspace only. Legacy `{kind: 'pipeline-step'}` kept for in-store use; the only reader is now the store itself. |
| 5.a — Backend slot API | 🟢 substantially done | Service helpers (add / update / remove slot on concept + reverse-lookup + effective-tier) + three REST endpoints + 24 new tests. Slot-aware tier gate deferred to Phase 5.c. |
| 3.e — Flip flag + delete legacy canvas | 🟢 flag flipped | Sprint 14 flipped the default to workspace-backed reads. Deleting the legacy read branches entirely waits for Phase 4 to first cut the shell over from legacy components. |
| 4 — Page cutover | 🟢 done | The physical unification landed via Sprints A–F: `components/unified-editor/` is gone. Node + edge renderers live under `components/editor/canvas/`, toolbar at `components/editor/toolbar/`, legacy panels at `components/editor/inspectors/`, form-view at `components/editor/form-view/`. Save modals now dispatch through `workspace.saveContractLayer` / `savePipelineLayer`. Field-level selection lives on `workspace.selection.fieldId` (Sprint A). `page.tsx` imports exclusively from `components/editor/*`. Deferred: ontology-entity ↔ concept auto-binding (Sprint D — needs UX decisions), shell-native FieldInspector (convenience port; today's FieldInspector lives at `editor/inspectors/` and still reads legacy contract store via dual-write). |
| ~~5.a — Backend slot endpoints~~ | ~~⏳ not started~~ | Moved up the table; see ✅ row above |
| 5.b — Migration CLI | ✅ done | `pycharter.semantic.migrate_flat_attributes` CLI + 38 unit tests. Dry-run default, `--execute`, `--lenient`, `--scan`, `--json`. Strict mode rolls the session back before raising. |
| 5.c — Frontend flat-attribute retirement | 🟢 partial | Sprint D (2026-04-25) wired the ontology-entity ↔ concept binding flow: new entities auto-create concepts (or link to existing with D-a prompt); rename fires D-c prompt when breaking a binding; add-attribute fires D-b prompt on slot collision and delegates to `concept-graph.addSlot`. Follow-up to complete: swap the inspector attribute list to read the bound concept's slots (not `data.attributes`); route `updateOntologyAttribute` / `removeOntologyAttribute` to `updateSlot` / `removeSlot` for bound entities; wire the D-f tier gate. |
| 5.d — NodePolicy for canvas | ✅ done | `computeNodePolicy(asset, activeLayers)` + 12 + 5 integration tests, wired into `layoutNodes` + `conceptAssetsToFlowNodes` (Sprint 6). |
| Pipeline-contract asset model (backlog #2) | ✅ done | `PipelineContractAsset` + `'pipeline-contract'` UnifiedEdgeKind, adapters, `loadPipelineConfig` mirror, canvas mutation mirrors (Sprints 3, 7, 14). |
| TableAsset enrichment (backlog #3) | ✅ done | Foundation + adapter + projection + load mirror + contract-canvas read + write mirrors (Sprints 4, 10, 11). |
| Contract-edge adapters (backlog #1) | ✅ done | `editorEdgeToUnifiedEdge` / reverse + load mirror + delete-mirror on inspector panels (Sprint 8). Create-mirror covered by Sprint 11 contract-store mutator dual-writes. |
| `saveContractLayer` on workspace | ✅ done | Pure projection + workspace method + 9 tests + toolbar wiring under `?workspace-save=1` (Sprints 9 + 12). Not the default save path yet — still gated on flag so the modal-driven path keeps its coercion/validation/metadata inputs. |
| 6 — Delete legacy stores | ⏳ ~56 readers remain | Phase 4's physical move cleared the unified-editor boundary. ~56 files under `components/editor/` still read legacy `useEditorConceptGraphStore` / `useEditorPipelineStore` / `useEditorContractStore`. Writes dual-write to workspace, so the legacy stores act as write-through caches. Full deletion is a reader-by-reader swap — expensive, high-risk, needs browser verification at each step. Recommend tackling incrementally after merging the current branch. |
| 7 — Ontology absorption | ⏳ separate ADR | Deferred. |

## Known gaps / backlog

Specific known divergences between legacy and workspace that have
been discovered in-branch but not yet closed. All are scoped for
cleanup before Phase 3.e (flip flag + delete legacy canvas):

1. ~~**Edge-deletion mirror.**~~ **Fully closed 2026-04-24.**
   - **Pipeline data-flow edges**: closed earlier — removes
     `flow:${legacyId}` from the workspace alongside the legacy
     `pipelineStore.removeEdge`.
   - **Contract-layer edges** (mapping, foreign-key, relationship
     via the three inspector panels in `components/unified-editor/`):
     closed by Sprint 8. The panels now call
     `workspace.removeEdge(workspaceIdForContractEdge(edge.id))`
     alongside the legacy `removeEdge`.
2. ~~**Pipeline-contract nodes + their edges.**~~ **Closed 2026-04-24.**
   `PipelineContractAsset` + `'pipeline-contract'` `UnifiedEdgeKind`
   land, adapters round-trip to `PipelineContractNode` /
   `PipelineContractEdge`, and `loadPipelineConfig` now mirrors
   contracts + contract-edges into the workspace. Canvas-mutation
   mirrors (create / position / delete of contract nodes from the
   canvas itself) still need Phase 3.c dual-writes; tracked under
   backlog #2a.
   - 2a. ~~**Contract-node canvas dual-writes.**~~ **Closed 2026-04-24.**
     Sprint 7 wires mirrors in every path: `useCanvasNodes.handleNodesChange`
     (pcontract: remove + position), `ConceptCanvas.handleConnect`
     (contract-edge create), `ConceptCanvas.handleDrop` (both
     file-browser and drag-drop), `InspectorPanel` (remove contract
     link), and `PipelineContractInspector` (all field edits + delete).
3. **Contract-layer (`json-schema` / SQL) mutations.** Split:
   - ~~**Foundation**~~ closed Sprint 4 (2026-04-24).
   - ~~**Load + read path**~~ closed Sprint 10 (2026-04-24):
     `loadContract` mirrors json-schema nodes into workspace
     TableAssets; `useCanvasNodes.contractFlowNodes` reads
     TableAssets via `tableAssetsToFlowNodes` when
     `?workspace-canvas=1` is on.
   - ~~**`saveContractLayer`**~~ shipped Sprint 9 (pure projection
     + workspace method + 9 tests). Not yet wired into a toolbar
     button — Phase 4 task.
   - **Still open:** canvas write dual-writes for contract nodes
     (drop a json-schema, add a field, rename, move, remove) only
     hit the legacy contract store. Workspace would see them via
     the node's own `onNodesChange` when Phase 3.c wiring lands —
     needs in-browser verification.
4. ~~**`ReconciliationWizard.addConcept`.** Adds concepts only to
   the legacy concept-graph store.~~ Closed: the wizard now reads
   the fresh legacy node after addConcept and mirrors it to
   workspace via ``addAsset(conceptNodeToAsset(fresh))``.
5. **Undo-stack alignment.** Legacy and workspace keep
   independent `past[] / future[]` arrays. The canvas dual-writes
   push to both, so the stacks stay roughly parallel, but a
   single legacy-only mutation slipping in (e.g. an import or a
   reconcile) would drift them. After Phase 3.e only workspace
   history exists and this class of drift is gone.
6. **Pipeline-step load mirror from `loadPipelineConfig`.** ~~Open~~
   Closed by the `useWorkspaceStore.loadPipeline` call inside
   `useEditorPipelineStore.loadPipelineConfig` — saved pipelines
   now populate workspace alongside legacy.
7. **Right-click delete mirror.** ~~Open~~ Closed by adding
   `useWorkspaceStore.removeAsset` alongside `removeConcept` in
   `handleNodeContextMenu`.
8. **Cmd-Z / Cmd-Y / Cmd-S keyboard mirrors.** ~~Open~~ Closed by
   mirroring undo/redo to workspace and routing Cmd-S through
   `handleConceptsSave`.

After Sprints 1–10 (2026-04-24), the only items still open are:
- Item 3's contract-canvas *write* dual-writes (create / edit fields
  / move / delete of `json-schema` nodes from the canvas).
- Item 5 (undo-stack alignment) — will naturally resolve once the
  flag flip at Phase 3.e deletes legacy history altogether.
- `saveContractLayer` is implemented but not routed through any
  UI button — Phase 4 wiring work.

### Remaining in-browser verification before Phase 3.e

Unit tests cannot verify these. Each needs a human to walk through
the workflow in `?workspace-canvas=1` mode before the flag is
flipped and legacy stores deleted:

- **Concept canvas:** rename, add slot, drop, drag, right-click
  delete, Cmd-Z/Y/S, scheme switch, save loop.
- **Pipeline canvas:** drop a step, connect edges, drop a contract
  onto a step, remove a contract link, save + reload.
- **Contract canvas (new in Sprint 10):** load a contract, confirm
  the workspace ends up with the matching TableAssets + mapping /
  FK / relationship edges, flip the canvas flag on, confirm nodes
  render from workspace, edit a field (verify write path reaches
  workspace — this will tell us whether the Phase 3.c write
  wiring is needed or whether the legacy `onNodesChange` is
  reaching workspace through some other path).
- **`saveContractLayer` happy path:** temporarily wire it to a
  button, save a minimal contract, reload it, confirm the JSON
  Schema round-trips (fields preserved, extras preserved).
- **Full `?workspace-canvas=1` smoke test** across all three
  layers with a non-trivial pipeline + contract + ontology
  bundle.

## 1. Context

The `/editor` page is **mid-migration, stalled**. Three layers coexist:

1. **Legacy domain stores** — `useEditorContractStore`, `useEditorPipelineStore`, `useEditorConceptGraphStore`. Different shapes (array-based vs normalized maps), different selection models (flat `{nodeId, edgeId, fieldId}` vs discriminated union), different dirty-tracking mechanics, different persistence paths (modal-driven `SaveContractModal` / `SavePipelineModal` vs in-store async `save()` with LinkML delta).
2. **Workspace store + shell** — `useWorkspaceStore` (`stores/editor/workspace.ts`, ~570 lines) already provides a unified `Asset` / `UnifiedEdge` model, cross-cutting selection with `focusedAssetId` and `hoveredAssetId`, layer-aware visibility (`execution | contract | knowledge`), per-layer dirty tracking, unified undo/redo via `generic-history`, governance gates, and adapters to legacy types. A parallel UI layer under `components/editor/shell/` consumes it (`EditorToolbar`, `EditorInspector`, `WorkspaceInspectorTabs`, `LayerToggleBar`, plus helpers). There is a `workspace.test.ts` test file. This is the intended foundation.
3. **`/editor/page.tsx`** — a **hybrid render tree**. It imports some shell pieces (`EditorDashboard`, `EditorLeftPanel`, `EditorCompanion`, `CanvasErrorBoundary`) but still drives state through the three legacy domain stores and still renders the legacy `UnifiedEditorToolbar` + legacy `InspectorPanel` + legacy `CompanionPanel` + legacy `UnifiedFormView`. The canvas writes to legacy stores, not to `useWorkspaceStore` — the workspace store is a parallel universe that never sees canvas writes. The shell's `EditorToolbar` and `EditorInspector` are built but **not rendered**.

Symptoms visible today:

- `ConceptCanvas` carries ~100 lines of `mode === ...` branches and actively silences concept nodes in non-concepts modes.
- The legacy toolbar forks undo / redo / save at the prop level (`isConcepts ? onConceptsUndo : undo`).
- The right rail is `InspectorPanel` in pipeline/contract modes, `GlossaryView` in concepts mode — two different UIs occupying the same slot.
- The concepts store's selection union contains `{kind: 'pipeline-step'}` even though pipeline-steps live in a different store. This is a **live cross-store reach**, not dead code (corrected 2026-04-22 after the initial audit mislabeled it as orphaned): `ConceptCanvas` sets it when a pipeline-step node is clicked, and `ImpactAnalysisTab` + the inspector flow read it to render pipeline-step context. It exists because the canvas hasn't been migrated to the workspace store yet. Removing it requires the full Phase 3 canvas migration, not a standalone deletion.
- The workspace store has `loadOntology` / `loadPipeline` but no save methods. Adapters `buildConceptGraphDelta` and `computeConceptSnapshot` are imported but never called. Shell toolbar's `onSave` prop is taken but no consumer implements it.

A third, related duality sits underneath: the **attribute model** is asymmetrically forked.

- **Concepts side (resolved).** Commit 8450462 embedded `slots: SlotDefinition[]` directly on `ConceptNode` (Option A — LinkML-aligned). Adding a slot creates an inline sub-row on the concept, not a separate graph node. Slots are persisted on the server in concept metadata.
- **Contract side (unresolved).** `OntologyEntityNodeData.attributes` remains a flat, contract-local array manipulated via `addOntologyAttribute` / `updateOntologyAttribute` / `removeOntologyAttribute`. These "attributes" have no linkage to real concept slots — they are ephemeral shape data living on a contract canvas node. Two users adding an `email` attribute to an `OntologyEntity` node bound to the same `Customer` concept produce two disconnected records, neither of which updates the `Customer.email` slot.

The bridge is missing in one direction: contract-side attributes cannot reference or mutate real slots.

### Pain this creates

1. **Selection cannot travel across modes.** Switching modes wipes selection, so the Pipeline → Contract → Ontology user journey is broken at its foundation.
2. **Undo / redo is forked**, producing inconsistent Cmd-Z behavior depending on what was last touched.
3. **Three save mental models** (two modal, one in-store async) force users to learn mode-specific "save" semantics.
4. **Canvas silences nodes that exist**, so cross-layer views are impossible without removing the guards.
5. **Attribute semantics disagree across layers**, so a slot defined on a concept and an "attribute" added to an ontology-entity node in contract mode live in entirely separate records even when they refer to the same thing (`email` on `Customer`).
6. **Two foundations exist; only one is used.** Every new feature has to pick: write against legacy stores (ships today, deepens the debt) or write against the workspace store (cleaner, but nothing actually renders it yet). Most features pick legacy, so the workspace store decays.
7. **Adding a new mode** (future: tests, flows, views) means copy-pasting a legacy store and adding another toolbar branch — the codebase is not extensible in the dimension that matters.

### Product driver

The near-term goal is a seamless **Pipeline → Contract → Ontology** authoring flow, plus selective absorption of ontology-page authoring capabilities into the editor. Neither is achievable on the current foundation without patching around the duality in every new feature.

## 2. Decision

**Adopt the existing `useWorkspaceStore` + shell as the single foundation. Finish the half-built migration and delete the legacy stack.** The legacy unified-editor mental model is retired, but so is the earlier sketch of a new `EditorDocument<TState, TDelta>` protocol fronting three domain stores — that pattern was never built and would duplicate work the workspace store has already done differently.

### 2.1 Principles

1. **One store, many layers.** A single workspace store holds all assets across execution / contract / knowledge layers as a unified `Asset` union, with layer-aware visibility. No mode gets its own domain store.
2. **Ephemeral state is cross-cutting; persistent wire formats are domain-specific.** Selection, focus, hover, active layers, dirty tracking, undo/redo live on the workspace store. Save adapters translate workspace state into the appropriate wire format (LinkML delta, YAML, JSON Schema) at the I/O boundary only.
3. **No backward compatibility with the legacy mental model.** Legacy modal-save, flat selection, array-based node storage, parallel domain stores, and flat ontology attributes are retired — not wrapped.
4. **Extensibility is proven by adding a mode.** A new mode registers new `Asset` variants, an inspector tab provider, and (if needed) a save adapter — nothing else. If it requires editing the canvas, toolbar, or rail, the abstraction is wrong.
5. **No parallel stacks.** Once cutover is complete, every editor feature is built against the workspace store. The `components/unified-editor/` directory and the three legacy stores are deleted, not kept as a fallback.

### 2.2 Target architecture

The target is the current `useWorkspaceStore` + `components/editor/shell/` completed to production parity with the legacy stack, rendered by `/editor/page.tsx` as the only path.

**A. Unified workspace store** (`useWorkspaceStore` — already exists)

- Single source of truth for all editor state: `assetsById`, `edgesById`, `activeLayers`, `selection`, `focusedAssetId`, `hoveredAssetId`, `dirtyLayers`, `past` / `future` history, governance blockers, scheme/projection metadata.
- The `Asset` discriminated union already covers `concept | source | job | consumer | contract | ...`; it is extended with `slot` as a first-class asset when the attribute-model unification lands (see §2.3).
- Selection is a discriminated union (`{kind: 'asset' | 'edge' | null, id}`) — not per-domain-store. The orphaned `{kind: 'pipeline-step'}` entry in the legacy concept-graph store is deleted as part of that store's retirement.
- Layer-aware visibility (`execution | contract | knowledge`) replaces the legacy `mode === 'pipeline' | 'contracts' | 'concepts'` branching. "Mode" becomes a UI-only concept for which left-panel / palette to show; it is not baked into data visibility.

**B. Save adapters on the workspace store** (to be added)

- Workspace store gains `saveKnowledgeLayer()`, `savePipelineLayer()`, `saveContractLayer()` — each uses the existing pure-helper adapters in `workspace-adapters.ts` (`buildConceptGraphDelta`, `computeConceptSnapshot`, plus new analogues for pipeline YAML and contract JSON Schema).
- Modal-driven save UX (name, version prompts) moves into callback-producing adapters; the workspace store's save methods stay pure-data operations.
- Shell `EditorToolbar`'s existing `onSave` prop is wired to dispatch to whichever layer's save method is appropriate given `primaryLayer`. This retires the `SavePipelineModal` / `SaveContractModal` parallel UIs and the concept-graph store's in-store `save()` method in one step.
- **Why not a protocol over three domain stores?** The original ADR proposed `EditorDocument<TState, TDelta>` as a TypeScript interface that `useEditorContractStore`, `useEditorPipelineStore`, and `useEditorConceptGraphStore` would each implement. The workspace store's architectural choice — one store with layer-aware assets + pure adapters — is a legitimate alternative, is already partly built, and is structurally simpler: one undo stack, one dirty-tracking model, one selection, no protocol dispatch. It is the chosen direction for this ADR; the three-stores-behind-a-protocol sketch is retired as an alternative (see §4).

**C. Unified canvas** (`ConceptCanvas`, to be re-grounded)

- Today `ConceptCanvas` reads from `useWorkspaceStore` for some rendering but writes go to legacy stores. Target: all canvas reads and writes go through the workspace store. `useCanvasNodes` / `useCanvasEdges` project `Asset` / `UnifiedEdge` into ReactFlow nodes/edges; user interactions call `addAsset` / `updateAsset` / `removeAsset` / `addEdge` / `removeEdge`.
- Mode guards that silence nodes are replaced by a `NodePolicy` (visible / read-only / editable) computed from `activeLayers` and the asset's `layers`. Cross-layer views (e.g., concept nodes visible but read-only while editing a pipeline) fall out naturally.
- ReactFlow node and edge type registrations remain module-level constants; policy is applied at render time via props.

**D. Unified detail rail** (shell's `EditorInspector` + `WorkspaceInspectorTabs`, to be completed)

- `EditorInspector` renders the selected `Asset` or `UnifiedEdge`. `WorkspaceInspectorTabs` dispatches to per-layer tabs (`ExecutionTabContent`, `ContractTabContent`, `KnowledgeTabContent`, `AnchorsTabContent`).
- The inspector tab content is the "providers" concept from the earlier ADR sketch — but registered as tab components, not a separate provider registry. Each tab imports the inspector subcomponents it needs (legacy `FieldInspector`, `ConceptInspector`, `PipelineStepInspector`, `SchemaNodeInspector`, `OntologyNodeInspector`, and edge inspectors — these subcomponents get re-pointed at workspace state but do not need to be rewritten from scratch).
- Today these tabs are stubs (see §2.2 gap list below). Phase 2 fills them.
- Cross-layer anchors are already computed by `selectFocusedAssetAnchors` and render in the `AnchorsTabContent` tab.

### 2.2.1 Known gaps vs legacy (from Phase 0 audit)

The workspace + shell is ~40–50% of the way to parity with the legacy stack. Gaps that must be closed before cutover:

- **Inspector tab content** is stubbed: `ExecutionTabContent`, `ContractTabContent`, `KnowledgeTabContent` need wiring. The legacy subcomponents (`FieldInspector`, `ConceptInspector`, `PipelineStepInspector`, `SchemaNodeInspector`, `OntologyNodeInspector`, `RelationshipEdgeInspector`, `MappingEdgeInspector`, `ForeignKeyEdgeInspector`) are re-pointed at workspace state and composed into the tabs.
- **Edge inspection** is invisible in the shell; relationship, mapping, and foreign-key edge editing must work through `WorkspaceInspectorTabs`.
- **Form view**: legacy `UnifiedFormView` renders all assets as editable cards (per-asset add/delete, inline field edits). Shell's `EditorArtifactFormPanel` is a raw-YAML/JSON editor — a different tool. The shell needs a form-view component at parity with `UnifiedFormView`, reading from `useWorkspaceStore`.
- **Save path** on the workspace store does not exist; §2.2 B above adds it.
- **Canvas writes** go to legacy stores today; canvas must be re-grounded on the workspace store.

### 2.3 Attribute model: extend the concept-side slot resolution to the contract side

The concept side already adopted the LinkML slot model (commit 8450462, embedded `slots: SlotDefinition[]` on `ConceptNode`). This ADR carries that decision forward to the contract side and retires the flat contract-local attribute model.

- **Slots are the single source of truth for attributes.** The `SlotDefinition` shape already on `ConceptNode` is the canonical model. No parallel "attribute" entity is introduced on the contract side.
- **Slots are first-class, shared entities.** A slot like `email` is defined once on its owning concept and referenced by any contract field or ontology-entity node that needs it. Edits to the slot propagate to every reference.
- **Contract-side ontology entity nodes reference slots; they do not own attributes.** `OntologyEntityNodeData.attributes` is deleted. In its place, an `OntologyEntityNodeData.conceptKey` points to a real concept, and the node renders that concept's `slots[]` read-through. Slot edits are `updateAsset` calls on the workspace store against the target `ConceptAsset`'s `slots` field — there is no per-store slot mutator API in the target architecture. The legacy concept-graph store's `addSlot` / `updateSlot` / `removeSlot` methods are deleted along with that store in Phase 5.
- **Contract fields bind to slots, not just concepts.** Target state: `contract_field → slot` (e.g., `customer_contract.email` binds to the `Customer.email` slot). Field type, description, required, and pattern are derived from the bound slot when available. Concept-only binding is allowed as a *transitional state* where the slot is TBD; the UI surfaces this as an "unresolved binding" chip to prompt slot definition.
- **Slot tier is the max across referencing concepts.** A shared slot referenced by a Core concept is itself Core-protected, regardless of where it was first defined. Governance gates follow the strongest tier. (Today's slots live on a single owning concept; once contract fields start pulling slots cross-concept, tier computation becomes non-trivial and gets a helper.)
- **Flat attributes are deleted.** `addOntologyAttribute`, `updateOntologyAttribute`, `removeOntologyAttribute`, and the `attributes` field on `OntologyEntityNodeData` are removed from the contract store. No compat shim.
- **Backend status (Phase 0A audit complete).** Slots persist as `metadata['_slots']` stashed in the concept `description` column via a metadata marker in `SqlAlchemyConceptGraphRepository`. The only slot-touching endpoint today is `PUT /api/v1/editor/concept-graphs/{scheme_id}`, which applies a `ConceptGraphDelta` and requires **full `ConceptNode` payloads** for any slot change — there are no slot-specific operations. No reverse index ("which concepts reference this slot") exists; queries would be O(N) across deserialized metadata. No effective-tier computation exists; tier is strictly per-concept. Zero backend tests exercise slot CRUD via the API. Phase 3 adds: (a) three slot-targeted endpoints (`POST` / `PATCH` / `DELETE` on `/api/v1/concepts/{concept_key}/slots[/{slot_name}]`) as convenience wrappers over the delta mechanism, (b) a `get_concepts_referencing_slot(scheme_id, slot_name)` repository method (O(N) acceptable initially), (c) a `compute_effective_slot_tier(graph, slot_name)` service method returning max tier across referencing concepts, (d) slot-aware tier gates in `_guard_tier_protected`, (e) backend tests covering slot create / update / remove, persistence round-trip, tier governance, and reverse lookup.

Consequences for the shell:

- `Asset` gains a `slot` variant (or slots remain as a field on `ConceptAsset` and are addressable via a composite selection id — to be decided in Phase 3 implementation).
- `WorkspaceInspectorTabs` gains a slot tab (edit slot name, range, description, cardinality, cross-concept usage). Slot mutations are `updateAsset` calls against the owning `ConceptAsset`.
- `NodePolicy` renders slot chips on concept nodes and on contract-side ontology-entity nodes as navigable sub-artifacts — the same primitive in both contexts.

### 2.4 Out of scope for this ADR

- **Persistence format unification across documents.** LinkML delta, YAML, and JSON Schema remain distinct wire formats; a separate ADR can revisit this once the editor foundation is stable.
- **Ontology-page feature absorption.** The shell is the *prerequisite*. A follow-up plan decides which ontology surfaces (authoring vs governance / observability) migrate into the editor and which stay on a dedicated dashboard.

## 3. Consequences

### Positive

- A genuine foundation for the Pipeline → Contract → Ontology flow: selection travels, cross-layer views work, one save / undo mental model, one attribute model.
- Adding a new mode becomes "extend the `Asset` union + register an inspector tab," not shell edits.
- Testing surface shrinks: one canvas, one toolbar, one rail, one store — tested once, not per-mode.
- Absorption of ontology authoring features becomes a mechanical tab-and-asset-variant exercise.
- Slot reuse eliminates drift: `email` defined once, referenced everywhere, governed by the strongest tier among its users.
- Work is mostly *completing and wiring* existing code rather than writing new abstractions. The workspace store's tests, adapters, and shell components are already on disk.

### Negative

- Cutover risk: switching `/editor/page.tsx` from the legacy stack to the shell is a large-blast-radius change. It must be tested end-to-end (golden paths per layer, undo/redo, save) before landing.
- The shell inspector is ~40–50% complete. Filling in tab content, edge inspection, and a form-view equivalent is real work, not a rename.
- Temporary regressions during migration — bounded by keeping each phase independently shippable and by not tearing out legacy until the shell is at parity.
- Backend work required for first-class slot endpoints (Phase 3a — three endpoints, reverse lookup, effective-tier computation).
- LinkML vs YAML vs JSON Schema persistence divergence remains a smell, deferred to a later ADR.

### Neutral

- `/editor/page.tsx` shrinks significantly; most mode-specific wiring disappears into the workspace store's save adapters and the inspector tabs.

## 4. Alternatives considered

1. **Incremental patching of the legacy editor while layering features on top.** Rejected — preserves the duality and makes every new feature pay the branching tax. Contradicts the stated goal of a fundamentally sound foundation.
2. **Big-bang full rewrite.** Rejected — unnecessary risk; the target architecture is reachable stepwise without breaking the current product.
3. **Keep three domain stores and unify them behind an `EditorDocument<TState, TDelta>` TypeScript protocol** (the earlier sketch of this ADR). Rejected after discovering the workspace store. The protocol approach would (a) duplicate architecture-level work the workspace store has already done differently, (b) preserve three stores as separate undo stacks / dirty-tracking models / selection homes, adding protocol dispatch on top of that separation, and (c) throw away the workspace store's tests and adapters. The workspace pattern — one store, layer-aware assets, pure adapters at the I/O boundary — is structurally simpler and already partly built.
4. **Keep legacy, build ontology features against it.** Rejected — doubles down on the duality and makes future cleanup more expensive.
5. **Keep contract-side flat attributes; bridge them to concept slots with a translation layer.** Rejected — translation layers metastasize and leave the "which record wins" question unanswered. The concept-side already chose slots (commit 8450462); extending that choice to the contract side is strictly simpler than preserving two shapes.
6. **Delete the workspace store + shell and build a new foundation from scratch.** Rejected. The workspace store is well-designed, has tests, and solves the right problems. Throwing it away in favor of a clean-room rewrite contradicts the principle of building on working code and wastes the migration work already done.

## 5. Migration phases

Each phase independently shippable, in order. Phases 1–4 are the cutover; Phase 5 is the attribute-model unification (unchanged in scope but re-sequenced); Phase 6 retires the legacy stack; Phase 7 is a follow-up ADR.

1. **Phase 0 — Ratify and audit (complete 2026-04-22).** This ADR merged; legacy paths frozen to feature-additions. Audits complete: (a) backend slot-endpoint status — slots persist but only via full-node delta operations; no slot endpoints, no reverse index, no effective-tier computation, no backend tests for slot CRUD (details in §2.3 Backend status); (b) frontend + external consumers of the flat contract-side attribute shape — 9 mutator callsites across 3 UI components, 8 `.attributes` reads, 3 wire-format touchpoints (`buildOntologyJSON`, `buildFieldMappingJSON`, `buildEntityNodes`); zero backend references, zero sibling-package references, zero seed-YAML references; one non-trivial risk — mapping edges carry `ontologyAttributeId` references into the flat array, so saved contracts need migration before reload on the new shape. (c) Workspace-store adoption state — `useWorkspaceStore` + shell components exist (~570 LoC store, test file, parallel UI at `components/editor/shell/`) but are only partially wired; main editor page still drives state through three legacy stores; shell inspector tabs are stubs; no save path exists on the workspace store; canvas writes go to legacy stores.

2. **Phase 1 — Complete workspace save path.** Add `saveKnowledgeLayer` / `savePipelineLayer` / `saveContractLayer` methods to `useWorkspaceStore`, each using the existing `workspace-adapters.ts` helpers (`buildConceptGraphDelta`, `computeConceptSnapshot`) and new analogues for pipeline YAML and contract JSON Schema. Port the save-name/version prompts from `SavePipelineModal` / `SaveContractModal` into callback-producing adapters the store calls at save time. Leave legacy save paths intact; this phase only adds the workspace-side implementation. *Deliverable: the workspace store can save every artifact type end-to-end, verified by tests and by a hidden dev toggle that routes saves through it.*

3. **Phase 2 — Fill shell inspector tabs + form view.** Implement `ExecutionTabContent`, `ContractTabContent`, `KnowledgeTabContent` in `WorkspaceInspectorTabs` by composing the existing legacy subcomponents (`FieldInspector`, `ConceptInspector`, `PipelineStepInspector`, `SchemaNodeInspector`, `OntologyNodeInspector`, `RelationshipEdgeInspector`, `MappingEdgeInspector`, `ForeignKeyEdgeInspector`) re-pointed at workspace state. Build a shell form-view component at parity with `UnifiedFormView` (all assets rendered as editable cards with per-asset add/delete/inline edits), reading from `useWorkspaceStore`. *Deliverable: the shell UI is at feature parity with the legacy inspector + form view.*

4. **Phase 3 — Re-ground canvas on workspace writes.** Migrate `ConceptCanvas` + `useCanvasNodes` / `useCanvasEdges` to project `Asset` / `UnifiedEdge` into ReactFlow, and to dispatch `addAsset` / `updateAsset` / `removeAsset` / `addEdge` / `removeEdge` on the workspace store. Legacy stores stop receiving canvas writes. Delete the orphaned `{kind: 'pipeline-step'}` selection entry from the legacy concept-graph store (it becomes dead after this phase). *Deliverable: the workspace store is the source of truth for canvas state; legacy stores are no longer written to from the canvas.*

5. **Phase 4 — Cutover `/editor/page.tsx` to the shell; retire legacy UI.** Swap the legacy `UnifiedEditorToolbar` → shell `EditorToolbar`; swap the legacy `InspectorPanel` → shell `EditorInspector` + `WorkspaceInspectorTabs`; swap the legacy `CompanionPanel` → shell `EditorCompanion`; swap the legacy `UnifiedFormView` → shell form-view from Phase 2. Replace the legacy save handlers in `page.tsx` with workspace store save dispatches. Delete `components/unified-editor/` wholesale. *Deliverable: `/editor` renders only the shell; legacy unified-editor UI directory is gone.*

6. **Phase 5 — Extend slots to the contract side (attribute-model unification).** Sub-phases, in order:
   - **5a. Backend slot API.** Add the three slot endpoints, the reverse-lookup repository method, effective-tier computation, slot-aware tier gates, and backend tests (details in §2.3).
   - **5b. Data migration.** One-shot migration CLI that walks saved contracts, converts flat `OntologyEntityNodeData.attributes` → slot references on the bound concepts, rewrites `ontologyAttributeId` in mapping edges to slot identifiers, and saves. Runs before 5c. No load-time compat shim. Orphan handling: **fail loudly by default**; `--lenient` flag falls back to dropping the edge with a warning. Auto-creating slots on orphan encounter is rejected.
   - **5c. Frontend retirement of flat attributes.** Delete the flat-attribute path end to end. Since Phase 4 already removed `components/unified-editor/`, this reduces to deleting the remaining `OntologyEntityNodeData.attributes` field and any workspace-side references, adding `conceptKey`, and wiring contract-side ontology-entity inspection to read the bound concept's slots via workspace `assetsById`.
   - **5d. Canvas policy.** Replace any remaining canvas mode guards with `NodePolicy`. Concept nodes become visible-but-read-only when not in concepts mode; slots render as navigable sub-artifacts on both concept nodes and contract-side ontology-entity nodes.

   *Deliverable: cross-layer views are possible and semantically consistent; the flat attribute model is deleted end to end with no compat shim.*

7. **Phase 6 — Delete legacy domain stores.** Once nothing reads from `useEditorConceptGraphStore` / `useEditorContractStore` / `useEditorPipelineStore`, delete the three store files and their tests. Remove any leftover `components/unified-editor/` references that survived Phase 4 audit. *Deliverable: one store for the editor; zero legacy paths.*

8. **Phase 7 (follow-up ADR) — Ontology-page absorption.** Decide which ontology surfaces migrate into the editor (now a clean foundation) and which remain on a dedicated governance / observability dashboard.

## 6. Open questions

- **Phase 4 cutover strategy.** Hard swap `/editor/page.tsx` in one commit vs. put the shell behind a feature flag (e.g., `?editor=shell`) and flip the default once verified? The latter is safer but adds a disposable flag the team then has to remember to remove. Decide at the start of Phase 4.
- **Slot as its own `Asset` variant vs field on `ConceptAsset`.** Two representations of slots in the workspace `Asset` union: (a) slots remain a field on `ConceptAsset` and are addressable via composite selection ids (e.g., `{kind: 'asset', id: 'concept:xyz#slot:email'}`), (b) `SlotAsset` becomes its own variant with a `parentConceptId` reference. (a) is less invasive, (b) is more symmetric with other first-class assets. Decide at the start of Phase 5.
- **Tier computation for shared slots.** The `compute_effective_slot_tier` service method returns max tier across referencing concepts. UI surfacing (how a slot displays its effective tier when it differs from its owning concept) is not yet specified. Decide in Phase 5c / 5d.
- **Deployed contracts with flat attributes.** Confirmed zero sibling-package / seed-YAML consumers. Open question: whether any production deployment has saved contracts that Phase 5b's migration CLI needs to run against. If the migration CLI is a no-op (greenfield state), skip deployment coordination.
- ~~**Mapping-edge orphan handling.**~~ Resolved 2026-04-22: fail loudly by default; `--lenient` drops the edge with a warning. See §5 Phase 5b.
- **Unresolved slot bindings.** UX treatment for contract fields that bind concept-only (slot TBD) — error, warning, or neutral chip? Decide in Phase 5.
- **Persistence format unification.** Whether to tackle LinkML delta vs YAML vs JSON Schema in a future ADR, or accept the divergence as permanent.
