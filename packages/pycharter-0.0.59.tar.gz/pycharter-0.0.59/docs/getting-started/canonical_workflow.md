# Canonical workflow: contract → pipeline → annotated records

This guide walks through the **canonical semantic layer** end to end. By
the end you will have:

1. Written a contract YAML that describes a record shape, coercion
   rules, and a field binding to an ontology concept.
2. Loaded the contract from Python via the new top-level
   `pycharter.load_contract` import.
3. Wired the contract to a pipeline step via a `StepContractBlock`.
4. Run the pipeline from the shell with `pycharter pipeline run`.
5. Inspected the resulting records and seen the contract's coercion
   and annotation fields applied automatically.

The canonical layer was added to support the editor workflow
(`/editor/ontology/[schemeId]`). It coexists with the legacy
runtime types in `pycharter.pipeline_generator` — every model in the
canonical layer carries a `Canonical` prefix to avoid an ambiguous
namespace collision (`CanonicalLoadStepConfig` vs the legacy runtime
`LoadStepConfig`).

## Step 1 — Write the contract

Create `orders_contract.yaml`:

```yaml
id: trading/orders
version: "1.0.0"
metadata:
  title: Trading Orders
  version: "1.0.0"
schema:
  type: object
  properties:
    order_id:
      type: string
    status:
      type: string
    placed_at:
      type: string
      format: date-time
coercion_rules:
  - id: lower_status
    target: orders.status
    operation: lowercase
  - id: parse_placed_at
    target: orders.placed_at
    operation: to_timestamp
field_bindings:
  orders.order_id:
    primary:
      linkml_slot:
        class: Order
        slot: id
      source_ontology: "trading-domain:1.0.0"
    annotations:
      - concept: TradeEntity
        source_ontology: "financial-core:2.1.0"
        relationship: exact_match
```

The two coercion rules will normalize a free-form `status` to lowercase
and parse the `placed_at` ISO string into a `datetime`. The
`field_bindings` block registers a primary LinkML slot binding plus an
annotation binding so downstream consumers can populate a knowledge
graph.

## Step 2 — Load the contract from Python

```python
from pycharter import load_contract

contract = load_contract("orders_contract.yaml")
print(contract.id)              # 'trading/orders'
print(len(contract.coercion_rules))  # 2
print(list(contract.field_bindings))  # ['orders.order_id']
```

`load_contract` is a top-level re-export so you do **not** need to
remember the full `pycharter.semantic.contracts.loader.load_contract`
path. The same is true for `apply_coercion`, `annotate_record`,
`CanonicalPipelineConfig`, `StepContractBlock`, and
`build_step_contract_context`.

## Step 3 — Apply contract behaviors directly (optional)

If you want to test the contract without a pipeline, the runtime
helpers operate on plain dicts:

```python
from pycharter import apply_coercion, annotate_record

record = {
    "order_id": "1",
    "status": "OPEN",
    "placed_at": "2026-04-10T10:00:00+00:00",
}
coerced = apply_coercion(record, contract)
# coerced['status'] == 'open'
# coerced['placed_at'] is a datetime, not a string

annotated = annotate_record(coerced, contract)
# annotated['_kb_annotations']['orders.order_id'] is the binding metadata
```

## Step 4 — Wire the contract into a pipeline

Create `orders_pipeline.yaml` next to the contract:

```yaml
name: orders-etl
version: "1.0.0"
steps:
  - id: source
    type: extract
    source:
      type: file
      path: ./orders_input.json
      format: json

  - id: enriched
    type: transform
    input: source
    operations:
      defaults:
        status: 'unknown'
    contract:
      ref:
        type: file
        path: ./orders_contract.yaml
      validate: false
      coerce: true
      annotate: true

  - id: sink
    type: load
    input: enriched
    target:
      type: file
      path: ./orders_output.jsonl
      format: jsonl
```

The transform step's `contract` block binds the contract via a relative
file ref. With `coerce: true` and `annotate: true`, every record that
flows through the step will have its `status` lowercased, its
`placed_at` parsed into a datetime, and a `_kb_annotations` field
attached.

## Step 5 — Run the pipeline

```bash
pycharter pipeline run orders_pipeline.yaml
```

The output file `orders_output.jsonl` will contain records with the
contract's coercion and annotation already applied:

```json
{
  "order_id": "1",
  "status": "open",
  "placed_at": "2026-04-10 10:00:00+00:00",
  "_kb_annotations": {
    "orders.order_id": {
      "primary": {
        "kind": "linkml_slot",
        "class": "Order",
        "slot": "id",
        "source_ontology": "trading-domain:1.0.0"
      },
      "annotations": [
        {
          "concept": "TradeEntity",
          "source_ontology": "financial-core:2.1.0",
          "relationship": "exact_match"
        }
      ]
    }
  }
}
```

## What just happened

The pipeline runner reads the YAML, finds the `contract:` block on the
transform step, calls `build_step_contract_context()` to resolve the
file ref into a `ContractConfig`, and then routes records through
`apply_step_contract()` before they reach the loader. The wiring lives
in `pycharter.pipeline_generator.step_contract` (note: no leading
underscore — it's a public seam, not a private module).

`StepContractBlock` accepts both `ContractFileRef` and
`ContractStoreRef`, but the runtime adapter currently only resolves
file refs end to end. Store refs raise a typed
`StepContractResolutionError` until the contract store is wired into
the pipeline runner in a follow-up phase.

## Where to go next

- `pycharter pipeline validate orders_pipeline.yaml` — confirm the
  pipeline parses without running it.
- `pycharter pipeline list` — list every pipeline known to the local
  workspace.
- The editor ontology editor at `/editor/ontology/[schemeId]`
  surfaces the same contracts and ontologies in a visual workspace
  shell.
