"""Squashed semantic extensions after squashed_root.

Revision ID: semantic_extensions_squashed
Revises: squashed_root
Create Date: 2026-04-22 00:00:00

This migration replaces the former chain:
- concept_binding_events
- concept_provenance
- suggestions

All operations are idempotent to support re-running from scratch after
alembic_version cleanup.
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

from pycharter.db.migrations.schema_helper import get_schema

revision: str = "semantic_extensions_squashed"
down_revision: str | None = "squashed_root"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _has_column(bind, table: str, column: str, schema: str | None) -> bool:
    insp = inspect(bind)
    cols = {c["name"] for c in insp.get_columns(table, schema=schema)}
    return column in cols


def _ensure_provenance_columns(bind, schema: str | None) -> None:
    if not _has_column(bind, "concepts", "origin", schema):
        op.add_column(
            "concepts",
            sa.Column(
                "origin",
                sa.String(length=32),
                nullable=False,
                server_default="unknown",
            ),
            schema=schema,
        )
    if not _has_column(bind, "concepts", "provenance", schema):
        op.add_column(
            "concepts",
            sa.Column("provenance", sa.JSON(), nullable=True),
            schema=schema,
        )

    if not _has_column(bind, "concept_relationships", "origin", schema):
        op.add_column(
            "concept_relationships",
            sa.Column(
                "origin",
                sa.String(length=32),
                nullable=False,
                server_default="unknown",
            ),
            schema=schema,
        )
    if not _has_column(bind, "concept_relationships", "provenance", schema):
        op.add_column(
            "concept_relationships",
            sa.Column("provenance", sa.JSON(), nullable=True),
            schema=schema,
        )


def _ensure_table_from_model(bind, model_table, schema: str | None) -> None:
    original_schema = model_table.schema
    try:
        if schema is None:
            model_table.schema = None
        model_table.create(bind, checkfirst=True)
    finally:
        model_table.schema = original_schema


def upgrade() -> None:
    bind = op.get_bind()
    schema = get_schema(bind)

    _ensure_provenance_columns(bind, schema)

    from pycharter.db.models.semantic.concept_binding_event import (
        ConceptBindingEventModel,
    )
    from pycharter.db.models.semantic.suggestion import SuggestionModel

    _ensure_table_from_model(bind, ConceptBindingEventModel.__table__, schema)
    _ensure_table_from_model(bind, SuggestionModel.__table__, schema)


def downgrade() -> None:
    bind = op.get_bind()
    schema = get_schema(bind)

    from pycharter.db.models.semantic.concept_binding_event import (
        ConceptBindingEventModel,
    )
    from pycharter.db.models.semantic.suggestion import SuggestionModel

    concept_binding_events = ConceptBindingEventModel.__table__
    suggestions = SuggestionModel.__table__
    cb_schema = concept_binding_events.schema
    sug_schema = suggestions.schema
    try:
        if schema is None:
            concept_binding_events.schema = None
            suggestions.schema = None
        suggestions.drop(bind, checkfirst=True)
        concept_binding_events.drop(bind, checkfirst=True)
    finally:
        concept_binding_events.schema = cb_schema
        suggestions.schema = sug_schema

    if _has_column(bind, "concept_relationships", "provenance", schema):
        op.drop_column("concept_relationships", "provenance", schema=schema)
    if _has_column(bind, "concept_relationships", "origin", schema):
        op.drop_column("concept_relationships", "origin", schema=schema)
    if _has_column(bind, "concepts", "provenance", schema):
        op.drop_column("concepts", "provenance", schema=schema)
    if _has_column(bind, "concepts", "origin", schema):
        op.drop_column("concepts", "origin", schema=schema)
