"""Add durable pipeline worker jobs table.

Revision ID: pipeline_jobs
Revises: semantic_extensions_squashed
Create Date: 2026-05-04 00:00:00
"""

from __future__ import annotations

from collections.abc import Sequence

from alembic import op

from pycharter.db.migrations.schema_helper import get_schema

revision: str = "pipeline_jobs"
down_revision: str | None = "semantic_extensions_squashed"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _ensure_table_from_model(bind, model_table, schema: str | None) -> None:
    original_schema = model_table.schema
    try:
        if schema is None:
            model_table.schema = None
        model_table.create(bind, checkfirst=True)
    finally:
        model_table.schema = original_schema


def upgrade() -> None:
    bind = op.get_bind()
    schema = get_schema(bind)

    from pycharter.db.models.pipeline_job import PipelineJobModel

    _ensure_table_from_model(bind, PipelineJobModel.__table__, schema)


def downgrade() -> None:
    bind = op.get_bind()
    schema = get_schema(bind)

    from pycharter.db.models.pipeline_job import PipelineJobModel

    table = PipelineJobModel.__table__
    original_schema = table.schema
    try:
        if schema is None:
            table.schema = None
        table.drop(bind, checkfirst=True)
    finally:
        table.schema = original_schema
