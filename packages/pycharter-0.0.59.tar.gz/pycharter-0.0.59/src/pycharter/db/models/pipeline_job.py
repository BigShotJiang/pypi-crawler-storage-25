"""SQLAlchemy model for durable pipeline worker jobs."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import JSON, Column, DateTime, Index, Integer, String, Text

from pycharter.db.models.base import Base


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _default_id() -> str:
    return str(uuid.uuid4())


class PipelineJobModel(Base):
    """One row per queued pipeline execution job."""

    __tablename__ = "pipeline_jobs"

    id = Column(String(36), primary_key=True, default=_default_id)
    run_id = Column(String(32), nullable=False, unique=True, index=True)

    status = Column(String(20), nullable=False, default="pending", index=True)
    payload_json = Column(JSON, nullable=False)
    fires_at = Column(DateTime(timezone=True), nullable=False, default=_utc_now)
    claimed_by = Column(String(255), nullable=True)
    claimed_at = Column(DateTime(timezone=True), nullable=True)
    attempt = Column(Integer, nullable=False, default=0)
    max_attempts = Column(Integer, nullable=False, default=5)
    idempotency_key = Column(String(255), nullable=True, unique=True)
    error_message = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), default=_utc_now)
    completed_at = Column(DateTime(timezone=True), nullable=True)
    result_json = Column(JSON, nullable=True)

    __table_args__ = (
        Index("ix_pipeline_jobs_poll", "status", "fires_at"),
        {"schema": "pycharter"},
    )
