"""SQLAlchemy model for the suggestions table.

A *suggestion* is a candidate concept or relation proposed by an
extractor (or any other origin) that has NOT yet been written into the
ontology. The extraction materializer, when running in ``mode=
"suggestion"``, writes :class:`SuggestionModel` rows into this table
instead of writing directly to ``concepts`` / ``concept_relationships``.

Acceptance flips the row to ``status="accepted"`` and, for concept-kind
suggestions, stamps :attr:`accepted_concept_id` with the UUID of the
concept row that was materialised from the suggestion payload.
"""

from __future__ import annotations

import uuid

from sqlalchemy import (
    JSON,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Index,
    String,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class SuggestionModel(Base):
    """Pending candidate concept/relation awaiting acceptance."""

    __tablename__ = "suggestions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    scheme_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.concept_schemes.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    source_uri = Column(String(1024), nullable=False, index=True)
    source_type = Column(String(128), nullable=False)
    origin = Column(String(32), nullable=False)
    suggestion_kind = Column(String(32), nullable=False)
    payload = Column(JSON, nullable=False)
    provenance = Column(JSON, nullable=True)
    confidence_score = Column(Float, nullable=True)
    confidence_level = Column(String(16), nullable=True)
    status = Column(
        String(32), nullable=False, server_default="pending", default="pending"
    )
    accepted_concept_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.concepts.id", ondelete="SET NULL"),
        nullable=True,
    )

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)
    accepted_at = Column(DateTime(timezone=True), nullable=True)
    accepted_by = Column(String(255), nullable=True)
    dismissed_at = Column(DateTime(timezone=True), nullable=True)
    dismissed_by = Column(String(255), nullable=True)

    __table_args__ = (
        Index(
            "ix_suggestions_scheme_status",
            "scheme_id",
            "status",
        ),
        Index(
            "ix_suggestions_source",
            "scheme_id",
            "source_uri",
            "status",
        ),
        {"schema": "pycharter"},
    )
