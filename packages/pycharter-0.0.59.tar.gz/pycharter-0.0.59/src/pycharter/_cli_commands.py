"""CLI command dispatch handlers for each pycharter subcommand.

Each ``handle_*`` function receives the parsed ``argparse.Namespace`` and
the corresponding sub-parser (for help display).  They return an integer
exit code (0 = success).
"""

from __future__ import annotations

import argparse
import importlib.util
import os
import sys
from pathlib import Path


def handle_db(args: argparse.Namespace, db_parser: argparse.ArgumentParser) -> int:
    """Dispatch ``db`` subcommands to ``pycharter.db.cli``."""
    if not args.db_command:
        db_parser.print_help()
        return 1

    from pycharter.db.cli import (
        cmd_current,
        cmd_downgrade,
        cmd_history,
        cmd_init,
        cmd_seed,
        cmd_stamp,
        cmd_truncate,
        cmd_upgrade,
    )

    if args.db_command == "init":
        return cmd_init(args.database_url, db_type=args.db_type, force=args.force)
    if args.db_command == "upgrade":
        return cmd_upgrade(args.database_url, args.revision)
    if args.db_command == "downgrade":
        return cmd_downgrade(args.database_url, args.revision)
    if args.db_command == "current":
        return cmd_current(args.database_url)
    if args.db_command == "history":
        return cmd_history(args.database_url)
    if args.db_command == "stamp":
        return cmd_stamp(args.database_url, args.revision)
    if args.db_command == "seed":
        return cmd_seed(args.seed_dir, args.database_url)
    if args.db_command == "truncate":
        return cmd_truncate(args.database_url, force=args.force)

    db_parser.print_help()
    return 1


def _pycharter_package_root() -> Path:
    """Return the pycharter package root directory (works installed or in dev)."""
    try:
        import pycharter as _pkg

        return Path(_pkg.__file__).resolve().parent
    except ImportError:
        return Path(__file__).resolve().parent


def _reload_dirs_excluding_ui() -> list[str]:
    """
    Directories to watch in reload mode: all pycharter package subdirs except 'ui'.
    Watching only these avoids hitting the OS inotify limit from ui/node_modules.
    Trade-off: changes to top-level .py files in the package root do not trigger reload.
    """
    pkg_root = _pycharter_package_root()
    return [str(d) for d in sorted(pkg_root.iterdir()) if d.is_dir() and d.name != "ui"]


def handle_api(args: argparse.Namespace) -> int:
    """Start the uvicorn-based API server."""
    try:
        import uvicorn  # type: ignore[import-not-found,import-untyped]
    except ImportError:
        print("Error: uvicorn is required for API server.", file=sys.stderr)
        print("   Install with: pip install pycharter[api]", file=sys.stderr)
        return 1

    # Try to import api module — if it fails, we are in development mode
    # and need to add project root to path.
    try:
        import api  # type: ignore[import-untyped]  # noqa: F401
    except ImportError:
        project_root = Path(__file__).parent.parent.resolve()
        project_root_str = str(project_root)

        if project_root_str not in sys.path:
            sys.path.insert(0, project_root_str)

        # Set PYTHONPATH for uvicorn subprocess (reload mode).
        pythonpath = os.environ.get("PYTHONPATH", "")
        if pythonpath:
            pythonpath = f"{project_root_str}{os.pathsep}{pythonpath}"
        else:
            pythonpath = project_root_str
        os.environ["PYTHONPATH"] = pythonpath

    run_kw: dict = {
        "host": args.host,
        "port": args.port,
        "reload": args.reload,
    }
    # Watch only Python package subdirs (exclude ui) to avoid OS file watch limit
    # from ui/node_modules. Do not use reload_excludes: uvicorn expands globs into
    # huge directory lists and can raise or hang.
    if args.reload:
        run_kw["reload_dirs"] = _reload_dirs_excluding_ui()
    uvicorn.run("pycharter.api.main:app", **run_kw)
    return 0


def handle_ui(
    args: argparse.Namespace,
    ui_parser: argparse.ArgumentParser,
) -> int:
    """Dispatch ``ui`` subcommands (serve / dev / build)."""
    if not args.ui_command:
        ui_parser.print_help()
        return 1

    ui_path = _resolve_ui_path()
    if ui_path is None:
        _print_ui_not_found()
        return 1

    # Add ui directory to Python path.
    if str(ui_path) not in sys.path:
        sys.path.insert(0, str(ui_path))

    if args.ui_command == "serve":
        return _run_ui_module(
            ui_path / "server.py",
            "server",
            "serve_ui",
            api_url=args.api_url,
            host=args.host,
            port=args.port,
        )
    if args.ui_command == "dev":
        return _run_ui_module(
            ui_path / "dev.py",
            "dev",
            "run_dev_server",
            api_url=args.api_url,
            port=args.port,
        )
    if args.ui_command == "build":
        return _run_ui_module(ui_path / "build.py", "build", "build_ui")

    ui_parser.print_help()
    return 1


def handle_worker(
    args: argparse.Namespace,
    worker_parser: argparse.ArgumentParser,
) -> int:
    """Dispatch ``worker start``."""
    if getattr(args, "worker_command", None) == "start":
        from pycharter.worker.cli import cmd_worker_start

        return cmd_worker_start(
            concurrency=args.concurrency,
            poll_interval=args.poll_interval,
        )
    if getattr(args, "worker_command", None) == "pipeline":
        from pycharter.worker.cli import cmd_pipeline_worker_start

        return cmd_pipeline_worker_start(
            concurrency=args.concurrency,
            poll_interval=args.poll_interval,
        )
    worker_parser.print_help()
    return 1


def handle_pipeline(
    args: argparse.Namespace,
    pipeline_parser: argparse.ArgumentParser,
) -> int:
    """Dispatch ``pipeline`` subcommands to ``pycharter.pipeline_generator.pipeline_cli``."""
    if not args.pipeline_command:
        pipeline_parser.print_help()
        return 1

    from pycharter.pipeline_generator.pipeline_cli import (
        cmd_etl_init,
        cmd_etl_inspect,
        cmd_etl_list,
        cmd_etl_run,
        cmd_etl_validate,
    )

    if args.pipeline_command == "run":
        return cmd_etl_run(
            path=args.path,
            variables=args.var,
            params=args.param,
            dry_run=args.dry_run,
            validate=args.validate,
            watch=getattr(args, "watch", False),
        )
    if args.pipeline_command == "validate":
        return cmd_etl_validate(path=args.path)
    if args.pipeline_command == "init":
        return cmd_etl_init(path=args.path, template=args.template)
    if args.pipeline_command == "list":
        return cmd_etl_list(path=args.path)
    if args.pipeline_command == "inspect":
        return cmd_etl_inspect(path=args.path)

    pipeline_parser.print_help()
    return 1


def handle_quality(
    args: argparse.Namespace,
    quality_parser: argparse.ArgumentParser,
) -> int:
    """Dispatch ``quality`` subcommands to ``pycharter.quality.cli``."""
    if not args.quality_command:
        quality_parser.print_help()
        return 1

    if args.quality_command == "check":
        from pycharter.quality.cli import cmd_quality_check

        return cmd_quality_check(
            contract_name=args.contract_name,
            contract_version=args.contract_version,
            contract=args.contract,
            data=args.data,
            database_url=args.database_url,
            record_violations=args.record_violations,
            check_thresholds=args.check_thresholds,
            thresholds_file=args.thresholds_file,
            sample_size=args.sample_size,
            output=args.output,
        )
    if args.quality_command == "violations":
        from pycharter.quality.cli import cmd_quality_violations

        return cmd_quality_violations(
            contract_name=args.contract_name,
            contract_version=args.contract_version,
            status=args.status,
            severity=args.severity,
            database_url=args.database_url,
            limit=args.limit,
            output=args.output,
        )

    quality_parser.print_help()
    return 1


def handle_docs(
    args: argparse.Namespace,
    docs_parser: argparse.ArgumentParser,
) -> int:
    """Dispatch ``docs`` subcommands (serve / build)."""
    if not args.docs_command:
        docs_parser.print_help()
        return 1

    from pycharter.docs.cli import cmd_docs_build, cmd_docs_serve

    if args.docs_command == "serve":
        return cmd_docs_serve(host=args.host, port=args.port)
    if args.docs_command == "build":
        return cmd_docs_build()

    docs_parser.print_help()
    return 1


# ------------------------------------------------------------------
# Private helpers
# ------------------------------------------------------------------


def _resolve_ui_path() -> Path | None:
    """Locate the UI directory across installed and development layouts."""
    possible_paths: list[Path] = []

    try:
        import pycharter

        package_ui = Path(pycharter.__file__).parent / "ui"
        possible_paths.append(package_ui)
    except (ImportError, AttributeError):
        pass

    possible_paths.extend(
        [
            Path(__file__).parent / "ui",
            Path.cwd() / "src" / "pycharter" / "ui",
            Path.cwd() / "ui",
        ]
    )

    for path in possible_paths:
        if path.exists() and (path / "server.py").exists():
            return path
    return None


def _print_ui_not_found() -> None:
    """Emit a helpful error when the UI directory cannot be found."""
    print("Error: UI directory not found.", file=sys.stderr)
    print(
        "   If installed from pip: UI should be included in the package.",
        file=sys.stderr,
    )
    print(
        "   If in development: Make sure you're running "
        "from the PyCharter project root.",
        file=sys.stderr,
    )
    print(
        "   Or install the UI dependencies: cd ui && npm install",
        file=sys.stderr,
    )


def handle_semantic(
    args: argparse.Namespace,
    semantic_parser: argparse.ArgumentParser,
) -> int:
    """Dispatch ``semantic`` subcommands to ``pycharter.semantic.cli``."""
    if not args.semantic_command:
        semantic_parser.print_help()
        return 1

    if args.semantic_command == "export":
        from pycharter.semantic.cli import cmd_semantic_export

        return cmd_semantic_export(
            scheme_key=args.scheme_key,
            format=args.format,
            output=args.output,
        )
    if args.semantic_command == "import":
        from pycharter.semantic.cli import cmd_semantic_import

        return cmd_semantic_import(
            path=args.path,
            format=args.format,
            scheme_key=args.scheme_key,
        )
    semantic_parser.print_help()
    return 1


def _run_ui_module(
    module_path: Path,
    module_name: str,
    func_name: str,
    **kwargs: object,
) -> int:
    """Dynamically load a UI helper module and call *func_name*."""
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec and spec.loader:
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        result = getattr(mod, func_name)(**kwargs)
        return result if isinstance(result, int) else 0
    return 1


def handle_kb(
    args: argparse.Namespace,
    kb_parser: argparse.ArgumentParser,
) -> int:
    """Dispatch ``pycharter kb`` subcommands."""
    if not getattr(args, "kb_command", None):
        kb_parser.print_help()
        return 1

    if args.kb_command == "ingest":
        return _handle_kb_ingest(args)
    if args.kb_command == "export":
        return _handle_kb_export(args)
    if args.kb_command == "cache":
        return _handle_kb_cache(args, kb_parser)
    if args.kb_command == "status":
        return _handle_kb_status()
    if args.kb_command == "formats":
        return _handle_kb_formats()
    if args.kb_command == "llm":
        return _handle_kb_llm(args, kb_parser)
    if args.kb_command == "neo4j":
        return _handle_kb_neo4j(args, kb_parser)
    kb_parser.print_help()
    return 1


def _handle_kb_ingest(args: argparse.Namespace) -> int:
    """Run `pycharter kb ingest <path>`."""
    from pycharter.semantic.kb import IngestError, ingest

    try:
        report = ingest(
            args.path,
            recursive=args.recursive,
            adapter=args.adapter,
            extensions=args.extensions,
            include_hidden=args.include_hidden,
            strict=args.strict,
            use_cache=args.use_cache,
        )
    except IngestError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    if getattr(args, "as_json", False):
        import json as _json

        payload = {
            "root": str(report.root),
            "concept_count": report.concept_count,
            "relation_count": report.relation_count,
            "source_count": len(report.results),
            "cache_hits": report.cache_hits,
            "skipped": [str(p) for p in report.skipped],
            "failures": [
                {"source": str(f.source), "reason": f.reason} for f in report.failures
            ],
            "by_source_type": {
                k: {"concepts": c, "relations": r, "sources": s}
                for k, (c, r, s) in report.by_source_type().items()
            },
        }
        print(_json.dumps(payload, indent=2))
    else:
        report.print()

    return 0 if not report.failures else 1


def _handle_kb_export(args: argparse.Namespace) -> int:
    """Run `pycharter kb export --scheme-id ... --format ... --out ...`."""
    from pycharter.db.session import get_session_factory
    from pycharter.semantic.concept_graph.sqlalchemy_repository import (
        SqlAlchemyConceptGraphRepository,
    )
    from pycharter.semantic.export import exporter_for_format
    from pycharter.semantic.export._neo4j_live import (
        Neo4jDriverMissingError,
        Neo4jNotConfiguredError,
    )

    session = get_session_factory()()
    try:
        repo = SqlAlchemyConceptGraphRepository(session=session)
        graph = repo.load_graph(args.scheme_id)
    except Exception as exc:  # noqa: BLE001
        print(
            f"error: could not load scheme {args.scheme_id!r}: {exc}",
            file=sys.stderr,
        )
        return 2
    finally:
        session.close()

    exporter = exporter_for_format(args.format)
    if exporter is None:
        print(f"error: unknown format {args.format!r}", file=sys.stderr)
        return 2

    if args.format == "neo4j-live":
        target = args.url or args.out or ""
        cfg: dict[str, object] = {}
        if args.url:
            cfg["url"] = args.url
        if args.user:
            cfg["user"] = args.user
        if args.password:
            cfg["password"] = args.password
        if args.database:
            cfg["database"] = args.database
        try:
            result = exporter.export(graph, target, config=cfg)
        except (Neo4jNotConfiguredError, Neo4jDriverMissingError) as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
    else:
        if not args.out:
            print(
                "error: --out is required for file- or directory-based formats",
                file=sys.stderr,
            )
            return 2
        result = exporter.export(graph, args.out)

    print(
        f"kb.export: wrote {result.concepts_exported} concepts + "
        f"{result.relations_exported} relations to {result.output} "
        f"({result.format}).",
    )
    return 0


def _handle_kb_formats() -> int:
    """Print every registered export format with its description."""
    from pycharter.semantic.export import list_formats

    formats = list_formats()
    width = max(len(f.id) for f in formats) + 2
    print("pycharter kb export formats:")
    for fmt in formats:
        kind = "dir" if fmt.is_directory else "file"
        print(f"  {fmt.id:<{width}} [{kind}, {fmt.file_suffix}]  {fmt.label}")
        print(f"  {'':<{width}}  {fmt.description}")
    return 0


def _handle_kb_cache(
    args: argparse.Namespace,
    kb_parser: argparse.ArgumentParser,
) -> int:
    """Dispatch `pycharter kb cache {status|clear}`."""
    from pycharter.semantic.extraction._cache import ExtractionCache, cache_root

    cache = ExtractionCache()
    if args.cache_command == "status":
        print(f"cache.root:  {cache_root()}")
        print(f"cache.count: {cache.count()}")
        return 0
    if args.cache_command == "clear":
        removed = cache.clear()
        print(f"cache.clear: evicted {removed} entries from {cache_root()}")
        return 0
    kb_parser.print_help()
    return 1


def _handle_kb_status() -> int:
    """Run `pycharter kb status` — quick overview of KB-relevant state."""
    from pycharter.semantic.ai.llm_config import is_configured, try_load_llm_config
    from pycharter.semantic.extraction._cache import ExtractionCache, cache_root
    from pycharter.semantic.extraction._plugin import create_default_registry

    cache = ExtractionCache()
    registry = create_default_registry()
    print("pycharter kb status")
    print(f"  cache.root:      {cache_root()}")
    print(f"  cache.entries:   {cache.count()}")
    names = sorted(registry.names())
    print(f"  adapters ({len(names)}): {', '.join(names)}")
    print(f"  llm.configured:  {is_configured()}")
    cfg = try_load_llm_config()
    if cfg is not None:
        redacted = cfg.redact()
        print(f"  llm.provider:    {redacted['provider']}")
        print(f"  llm.model:       {redacted['model']}")
    return 0


def _handle_kb_llm(
    args: argparse.Namespace,
    kb_parser: argparse.ArgumentParser,
) -> int:
    """Dispatch `pycharter kb llm {configure|status|clear}`."""
    cmd = getattr(args, "llm_command", None)
    if cmd == "configure":
        return _handle_kb_llm_configure(args)
    if cmd == "status":
        return _handle_kb_llm_status()
    if cmd == "clear":
        return _handle_kb_llm_clear()
    kb_parser.print_help()
    return 1


def _handle_kb_llm_configure(args: argparse.Namespace) -> int:
    """Run `pycharter kb llm configure`.

    Accepts ``--provider / --model / --api-key`` to skip prompts. When
    any required field is still missing the CLI prompts interactively
    using ``getpass`` for secrets. ``--non-interactive`` disables
    prompts and exits non-zero instead.
    """
    import getpass as _getpass

    from pycharter.semantic.ai.llm_config import write_llm_config

    provider = args.provider
    model = args.model
    api_key = args.api_key
    non_interactive = bool(args.non_interactive)

    if provider is None:
        if non_interactive:
            print(
                "error: --provider is required in --non-interactive mode",
                file=sys.stderr,
            )
            return 2
        try:
            provider = input("LLM provider [anthropic/openai]: ").strip().lower()
        except EOFError:
            provider = ""
    if provider not in ("anthropic", "openai"):
        print(
            f"error: unsupported provider {provider!r}; expected anthropic or openai",
            file=sys.stderr,
        )
        return 2
    if not api_key:
        if non_interactive:
            print(
                "error: --api-key is required in --non-interactive mode",
                file=sys.stderr,
            )
            return 2
        try:
            api_key = _getpass.getpass(f"{provider} API key: ")
        except EOFError:
            api_key = ""
        if not api_key:
            print("error: API key is required.", file=sys.stderr)
            return 2

    path = write_llm_config(
        provider=provider,
        api_key=api_key,
        model=model or None,
    )
    print(f"kb.llm: wrote config to {path}")
    return 0


def _handle_kb_llm_status() -> int:
    """Run `pycharter kb llm status`."""
    from pycharter.semantic.ai.llm_config import (
        config_path,
        is_configured,
        try_load_llm_config,
    )

    print(f"kb.llm.path:       {config_path()}")
    print(f"kb.llm.configured: {is_configured()}")
    cfg = try_load_llm_config()
    if cfg is None:
        return 0 if is_configured() else 1
    redacted = cfg.redact()
    for key in (
        "provider",
        "model",
        "has_api_key",
        "max_tokens_per_call",
        "temperature",
        "rate_limit_per_minute",
    ):
        print(f"kb.llm.{key}: {redacted[key]}")
    return 0


def _handle_kb_llm_clear() -> int:
    """Run `pycharter kb llm clear`."""
    from pycharter.semantic.ai.llm_config import clear_llm_config, config_path

    removed = clear_llm_config()
    if removed:
        print(f"kb.llm.clear: removed {config_path()}")
    else:
        print(f"kb.llm.clear: no config at {config_path()}")
    return 0


def _handle_kb_neo4j(
    args: argparse.Namespace,
    kb_parser: argparse.ArgumentParser,
) -> int:
    """Dispatch `pycharter kb neo4j {validate}`."""
    if getattr(args, "neo4j_command", None) != "validate":
        kb_parser.print_help()
        return 1
    from pycharter.semantic.export._neo4j_live import validate_endpoint

    result = validate_endpoint(
        url=args.url,
        user=args.user,
        password=args.password,
        database=args.database,
    )
    if getattr(args, "as_json", False):
        import json as _json

        print(
            _json.dumps(
                {
                    "ok": result.ok,
                    "url": result.url,
                    "server_version": result.server_version,
                    "message": result.message,
                },
                indent=2,
            )
        )
    else:
        status = "OK" if result.ok else "FAIL"
        print(f"kb.neo4j.validate [{status}] {result.message}")
        if result.server_version:
            print(f"  server_version: {result.server_version}")
        if result.url:
            print(f"  url:            {result.url}")
    return 0 if result.ok else 2
