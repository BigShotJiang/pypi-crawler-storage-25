"""Top-level exception types raised by the public ``pycharter`` API.

The shared error hierarchy lives in
:mod:`pycharter.shared.errors` and is the right home for engine /
contract / config errors that already exist. This module is for the
small public surface that ``pycharter.run`` / ``pycharter.preflight``
expose to external callers (Airflow / Dagster / scripts) — keeping it
near the top-level keeps the import path short:

    from pycharter import PipelineRunError
"""

from __future__ import annotations

from pycharter.pipeline_generator.result import PipelineResult
from pycharter.shared.errors import PyCharterError


class PipelineRunError(PyCharterError):
    """Raised by :func:`pycharter.run` when a run fails with ``fail_fast=True``.

    Carries the full :class:`PipelineResult` so callers can still
    inspect per-step state, errors, and counts after catching the
    exception:

        try:
            pycharter.run("pipeline.yaml")
        except PipelineRunError as exc:
            for step in exc.result.step_results:
                if not step.success:
                    handle_failure(step)
    """

    def __init__(self, message: str, *, result: PipelineResult) -> None:
        super().__init__(message)
        self.result = result
