"""Shared Pydantic config models used across extract, load, and settings."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict

from pycharter.pipeline_generator._config_enums import (
    CloudProvider,
    ContractStoreType,
    DLQBackend,
)


class SSHTunnelConfig(BaseModel):
    """SSH tunnel configuration for database connections."""

    model_config = ConfigDict(extra="forbid")

    host: str
    port: int = 22
    username: str
    private_key_path: str | None = None
    password: str | None = None
    remote_host: str | None = None
    remote_port: int | None = None
    enabled: bool = False
    local_port: int = 5433


class DatabaseConfig(BaseModel):
    """Database connection configuration."""

    model_config = ConfigDict(extra="forbid")

    url: str


class CSVOptions(BaseModel):
    """CSV file options."""

    model_config = ConfigDict(extra="forbid")

    delimiter: str = ","
    quote_char: str = '"'
    escape_char: str | None = None
    has_header: bool = True
    include_header: bool = True  # for writing
    encoding: str = "utf-8"


class JSONOptions(BaseModel):
    """JSON file options."""

    model_config = ConfigDict(extra="forbid")

    encoding: str = "utf-8"
    lines: bool = False  # for reading JSONL
    indent: int | None = None  # for writing
    ensure_ascii: bool = False  # for writing


class CloudStorageConfig(BaseModel):
    """Cloud storage configuration."""

    model_config = ConfigDict(extra="forbid")

    provider: CloudProvider
    bucket: str | None = None  # S3, GCS
    container: str | None = None  # Azure
    path: str | None = None
    prefix: str | None = None
    credentials: dict[str, Any] | None = None


class DLQConfig(BaseModel):
    """Dead Letter Queue configuration."""

    model_config = ConfigDict(extra="forbid")

    enabled: bool = True
    backend: DLQBackend = DLQBackend.FILE
    path: str | None = None  # for file backend
    connection_string: str | None = None  # for database backend
    schema_name: str | None = None  # DB schema
    table: str | None = None  # DB table name


class ContractStoreConfig(BaseModel):
    """Contract store configuration for database-based contracts."""

    model_config = ConfigDict(extra="forbid")

    type: ContractStoreType
    connection_string: str | None = None


class IncrementalConfig(BaseModel):
    """Incremental extraction configuration.

    When attached to an extract config, the pipeline will persist a watermark
    value between runs so that only new/updated records are extracted.
    """

    model_config = ConfigDict(extra="forbid")

    enabled: bool = True
    watermark_field: str
    initial_value: str | None = None
