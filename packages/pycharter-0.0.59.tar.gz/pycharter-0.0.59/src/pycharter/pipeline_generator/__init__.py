"""ETL Generator — DAG-based pipeline framework.

Provides a configuration-driven pipeline that supports multi-source
extraction, joins, unions, fan-out, and a three-stage transform layer
(simple ops → JSONata → custom Python functions).
"""

from __future__ import annotations

from typing import Any

# DAG resolution
from pycharter.pipeline_generator._config import (
    PipelineConfig,
    load_pipeline_config,
    parse_pipeline_config,
)
from pycharter.pipeline_generator._dag import DAGError, resolve_dag

# Context and expressions
from pycharter.pipeline_generator.context import PipelineContext
from pycharter.pipeline_generator.expression import (
    ExpressionError,
    ExpressionEvaluator,
    evaluate_expression,
    is_expression,
)

# Extractors
from pycharter.pipeline_generator.extractors import (
    BaseExtractor,
    CloudStorageExtractor,
    DatabaseExtractor,
    ExtractorFactory,
    FileExtractor,
    HTTPExtractor,
)

# Loaders
from pycharter.pipeline_generator.loaders import (
    BaseLoader,
    CloudStorageLoader,
    DatabaseLoader,
    FileLoader,
    LoaderFactory,
    PostgresLoader,
)

# Core pipeline class
from pycharter.pipeline_generator.pipeline import Pipeline
from pycharter.pipeline_generator.protocols import (
    AckableExtractor,
    Extractor,
    Loader,
    Transformer,
)
from pycharter.pipeline_generator.result import (
    BatchResult,
    LoadResult,
    PipelineResult,
    StepResult,
)

# Step contract bridge — public seam between the canonical
# StepContractBlock and runtime pipeline steps. Promoted
# from the private _step_contract module so editor backend (and
# external users) can wire contracts to pipeline steps without
# reaching into a private module.
from pycharter.pipeline_generator.step_contract import (
    StepContractResolutionError,
    StepContractValidationError,
    apply_step_contract_block,
    apply_step_contract_to_records,
    build_step_contract_context,
)

# Step config models
from pycharter.pipeline_generator.steps import (
    ExtractStepConfig,
    JoinHow,
    JoinOn,
    JoinPrefix,
    JoinStepConfig,
    LoadStepConfig,
    StepConfig,
    StepType,
    TransformStepConfig,
    UnionStepConfig,
)

# Transformers
from pycharter.pipeline_generator.transformers import (
    AddField,
    BaseTransformer,
    Convert,
    CustomFunction,
    Default,
    Drop,
    Filter,
    FlatMap,
    Flatten,
    Map,
    Rename,
    Select,
    TransformerChain,
    Unnest,
)

# Config validation
from pycharter.shared.errors import ConfigLoadError

# ---------------------------------------------------------------------------
# Lazy imports — heavy or optional modules loaded on first access
# ---------------------------------------------------------------------------

_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    # Lineage (requires openlineage)
    "LineageEmitter": ("pycharter.pipeline_generator.lineage", "LineageEmitter"),
    "create_lineage_emitter": (
        "pycharter.pipeline_generator.lineage",
        "create_lineage_emitter",
    ),
    "AsyncRateLimiter": (
        "pycharter.pipeline_generator.rate_limiter",
        "AsyncRateLimiter",
    ),
    # Quality checks
    "QualityChecker": ("pycharter.pipeline_generator.quality", "QualityChecker"),
    "PostLoadChecker": ("pycharter.pipeline_generator.quality", "PostLoadChecker"),
    "QualityCheckResult": (
        "pycharter.pipeline_generator.quality",
        "QualityCheckResult",
    ),
    "QualityCheckSeverity": (
        "pycharter.pipeline_generator.quality",
        "QualityCheckSeverity",
    ),
    "QualityCheckStatus": (
        "pycharter.pipeline_generator.quality",
        "QualityCheckStatus",
    ),
    "QualityReport": ("pycharter.pipeline_generator.quality", "QualityReport"),
    "create_quality_checker": (
        "pycharter.pipeline_generator.quality",
        "create_quality_checker",
    ),
    # State persistence (incremental extraction)
    "PipelineState": ("pycharter.pipeline_generator.state", "PipelineState"),
    "StateStore": ("pycharter.pipeline_generator.state", "StateStore"),
    "FileStateStore": ("pycharter.pipeline_generator.state", "FileStateStore"),
    "SqliteStateStore": ("pycharter.pipeline_generator.state", "SqliteStateStore"),
    "create_state_store": (
        "pycharter.pipeline_generator.state",
        "create_state_store",
    ),
    # DLQ sync wrappers
    "add_record_sync": ("pycharter.pipeline_generator._dlq_sync", "add_record_sync"),
    "add_batch_sync": ("pycharter.pipeline_generator._dlq_sync", "add_batch_sync"),
    "retry_record_sync": (
        "pycharter.pipeline_generator._dlq_sync",
        "retry_record_sync",
    ),
    # ETL Validation
    "ETLValidator": ("pycharter.pipeline_generator.validation", "ETLValidator"),
    "ETLValidationError": (
        "pycharter.pipeline_generator.validation",
        "ETLValidationError",
    ),
    "resolve_contract": (
        "pycharter.pipeline_generator.validation",
        "resolve_contract",
    ),
    "create_dlq": ("pycharter.pipeline_generator.validation", "create_dlq"),
    # Testing framework
    "MockExtractor": ("pycharter.pipeline_generator.testing", "MockExtractor"),
    "MockLoader": ("pycharter.pipeline_generator.testing", "MockLoader"),
    "PipelineTestHarness": (
        "pycharter.pipeline_generator.testing",
        "PipelineTestHarness",
    ),
    "TestFixture": ("pycharter.pipeline_generator.testing", "TestFixture"),
    "assert_records_match": (
        "pycharter.pipeline_generator.testing",
        "assert_records_match",
    ),
    "assert_record_count": (
        "pycharter.pipeline_generator.testing",
        "assert_record_count",
    ),
    "assert_fields_present": (
        "pycharter.pipeline_generator.testing",
        "assert_fields_present",
    ),
    "assert_no_field": ("pycharter.pipeline_generator.testing", "assert_no_field"),
    "assert_field_values": (
        "pycharter.pipeline_generator.testing",
        "assert_field_values",
    ),
    "assert_schema_shape": (
        "pycharter.pipeline_generator.testing",
        "assert_schema_shape",
    ),
    "load_fixture": ("pycharter.pipeline_generator.testing", "load_fixture"),
    "load_test_fixture": (
        "pycharter.pipeline_generator.testing",
        "load_test_fixture",
    ),
    "validate_pipeline_config": (
        "pycharter.pipeline_generator.testing",
        "validate_pipeline_config",
    ),
    # Streaming extractors
    "KafkaExtractor": (
        "pycharter.pipeline_generator.extractors.kafka",
        "KafkaExtractor",
    ),
    "RabbitMQExtractor": (
        "pycharter.pipeline_generator.extractors.rabbitmq",
        "RabbitMQExtractor",
    ),
    "SQSExtractor": (
        "pycharter.pipeline_generator.extractors.sqs",
        "SQSExtractor",
    ),
}


def __getattr__(name: str) -> Any:
    """Lazy-load optional and heavy modules on first access."""
    if name in _LAZY_IMPORTS:
        import importlib

        module_path, attr_name = _LAZY_IMPORTS[name]
        module = importlib.import_module(module_path)
        return getattr(module, attr_name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # Core pipeline
    "Pipeline",
    "PipelineConfig",
    "PipelineContext",
    "PipelineResult",
    "StepResult",
    "BatchResult",
    "LoadResult",
    # DAG
    "DAGError",
    "resolve_dag",
    "parse_pipeline_config",
    "load_pipeline_config",
    # Step config models
    "StepConfig",
    "StepType",
    "ExtractStepConfig",
    "TransformStepConfig",
    "JoinStepConfig",
    "UnionStepConfig",
    "LoadStepConfig",
    "JoinHow",
    "JoinOn",
    "JoinPrefix",
    # Protocols
    "Extractor",
    "AckableExtractor",
    "Transformer",
    "Loader",
    # Expressions
    "ExpressionEvaluator",
    "ExpressionError",
    "evaluate_expression",
    "is_expression",
    # Extractors
    "BaseExtractor",
    "HTTPExtractor",
    "FileExtractor",
    "DatabaseExtractor",
    "CloudStorageExtractor",
    "ExtractorFactory",
    # Transformers
    "BaseTransformer",
    "TransformerChain",
    "Rename",
    "AddField",
    "Drop",
    "Select",
    "Filter",
    "Convert",
    "Default",
    "Map",
    "FlatMap",
    "CustomFunction",
    "Unnest",
    "Flatten",
    # Loaders
    "BaseLoader",
    "PostgresLoader",
    "DatabaseLoader",
    "FileLoader",
    "CloudStorageLoader",
    "LoaderFactory",
    # Step contract bridge
    "StepContractResolutionError",
    "StepContractValidationError",
    "apply_step_contract_block",
    "apply_step_contract_to_records",
    "build_step_contract_context",
    # Config errors
    "ConfigLoadError",
]
