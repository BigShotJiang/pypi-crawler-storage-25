"""Live pipeline-run progress emitter.

Emits per-step lifecycle events to the existing ``ChangeBus``, which
the SSE endpoint at ``GET /api/v1/pipeline/runs/{run_id}/stream``
relays to UI / CLI clients in real time.

Topic convention: ``pipeline_run.{run_id}`` per run; ``pipeline_run.*``
for the dashboard. Event ``action`` is the lifecycle phase. Per-step
data is packed into ``metadata`` so subscribers can render whichever
field they care about without forking on event types.

Design notes:

* The emitter is **bus-optional**: when ``bus is None`` (CLI without
  an API server, library use), every method is a no-op. The runner
  unconditionally wires it up; library callers pass ``None``.
* Emit failures (queue full, subscriber bug, …) are logged and
  swallowed via :func:`_safe_emit`. A misbehaving subscriber must
  never take down a real pipeline run — same contract as the lineage
  emitter at ``pipeline_generator/_runner.py``.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from pycharter.events import ChangeEvent

if TYPE_CHECKING:
    from pycharter.events import ChangeBus

logger = logging.getLogger(__name__)


def _topic_for(run_id: str) -> str:
    """Build the per-run topic. Centralised so producer + consumer agree."""
    return f"pipeline_run.{run_id}"


def _safe_emit(action: str, fn: object, *args: object, **kwargs: object) -> None:
    """Best-effort wrapper — log + swallow any emit failure."""
    try:
        fn(*args, **kwargs)  # type: ignore[operator]
    except Exception:  # noqa: BLE001 — observability boundary
        logger.warning(
            "Run-progress emit failed during %s",
            action,
            exc_info=True,
        )


class RunProgressEmitter:
    """Emit pipeline-run lifecycle events onto a :class:`ChangeBus`.

    Methods cover the six phases the runner can be in:
    ``pipeline_start`` → (``step_start`` → ``step_complete`` |
    ``step_failed``)+ → (``pipeline_complete`` | ``pipeline_failed``).

    The runner constructs an emitter (or ``None``) and threads it into
    ``run_dag``; methods do nothing when ``bus is None``.
    """

    __slots__ = ("_bus", "_run_id", "_topic")

    def __init__(self, bus: ChangeBus | None, run_id: str) -> None:
        self._bus = bus
        self._run_id = run_id
        self._topic = _topic_for(run_id)

    @property
    def run_id(self) -> str:
        return self._run_id

    # ---- pipeline-level ------------------------------------------------

    def pipeline_start(self, total_steps: int) -> None:
        """Fire once before the first step runs."""
        self._publish(
            "pipeline_start",
            metadata={"phase": "pipeline_start", "total_steps": total_steps},
        )

    def pipeline_complete(self, total_rows: int) -> None:
        """Fire on a successful run after all steps complete."""
        self._publish(
            "pipeline_complete",
            metadata={"phase": "pipeline_complete", "total_rows": total_rows},
        )

    def pipeline_failed(self, error: str) -> None:
        """Fire when the run ends in failure (any step raised, or
        ``result.success`` ended up False)."""
        self._publish(
            "pipeline_failed",
            metadata={"phase": "pipeline_failed", "error": error},
        )

    # ---- step-level ----------------------------------------------------

    def step_start(self, step_id: str, step_index: int) -> None:
        """Fire before a step's runner is invoked."""
        self._publish(
            "step_start",
            resource_id=step_id,
            metadata={
                "phase": "step_start",
                "step_id": step_id,
                "step_index": step_index,
            },
        )

    def step_complete(self, step_id: str, step_index: int, rows: int) -> None:
        """Fire after a step's runner returns successfully."""
        self._publish(
            "step_complete",
            resource_id=step_id,
            metadata={
                "phase": "step_complete",
                "step_id": step_id,
                "step_index": step_index,
                "rows": rows,
            },
        )

    def step_failed(self, step_id: str, step_index: int, error: str) -> None:
        """Fire when a step's runner raises or returns a failed result."""
        self._publish(
            "step_failed",
            resource_id=step_id,
            metadata={
                "phase": "step_failed",
                "step_id": step_id,
                "step_index": step_index,
                "error": error,
            },
        )

    # ---- internal ------------------------------------------------------

    def _publish(
        self,
        action: str,
        *,
        resource_id: str | None = None,
        metadata: dict[str, object],
    ) -> None:
        if self._bus is None:
            return
        event = ChangeEvent(
            topic=self._topic,
            action=action,
            resource_id=resource_id or self._run_id,
            revision=0,  # not used for run progress; required by ChangeEvent
            metadata=metadata,
        )
        _safe_emit(action, self._bus.publish, event)
