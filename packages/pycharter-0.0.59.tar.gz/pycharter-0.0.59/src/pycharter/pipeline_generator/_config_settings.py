"""Settings-related Pydantic models for pipeline configuration."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict

from pycharter.pipeline_generator._config_shared import (
    ContractStoreConfig,
    DLQConfig,
)


class LineageConfig(BaseModel):
    """OpenLineage emission configuration (optional)."""

    model_config = ConfigDict(extra="forbid")

    enabled: bool = False
    namespace: str = "pycharter"
    backend_url: str | None = None


class PluginConfig(BaseModel):
    """Plugin configuration for settings.yaml.

    Maps plugin names to importable references (``module.path:ClassName``).
    """

    model_config = ConfigDict(extra="forbid")

    extractors: dict[str, str] | None = None
    loaders: dict[str, str] | None = None


class StateStoreConfig(BaseModel):
    """State store configuration for cross-run watermark persistence."""

    model_config = ConfigDict(extra="forbid")

    backend: Literal["file", "sqlite"] = "file"
    path: str = "./.state"


class SettingsConfig(BaseModel):
    """Shared pipeline settings (settings.yaml)."""

    model_config = ConfigDict(extra="forbid")

    name: str | None = None
    description: str | None = None
    version: str | None = None
    contract_store: ContractStoreConfig | None = None
    dlq: DLQConfig | None = None
    lineage: LineageConfig | None = None
    plugins: PluginConfig | None = None
    state_store: StateStoreConfig | None = None
