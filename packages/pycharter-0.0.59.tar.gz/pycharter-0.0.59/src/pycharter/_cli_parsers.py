"""Argparse subparser registration for CLI command groups.

Each ``register_*`` function receives the top-level ``subparsers`` object
(or a nested one) and adds the relevant arguments.  They return the
sub-parser and, where applicable, its own nested subparsers so callers
can reference them for help text.

The ``register_db`` function lives in ``_cli_parsers_db`` but is
re-exported here so callers can import everything from one place.
"""

from __future__ import annotations

import argparse

from pycharter._cli_parsers_db import register_db
from pycharter.config.ports import API_PORT, DOCS_PORT, UI_PORT

__all__ = [
    "register_api",
    "register_db",
    "register_docs",
    "register_kb",
    "register_pipeline",
    "register_quality",
    "register_semantic",
    "register_ui",
    "register_worker",
]


def register_api(
    subparsers: argparse._SubParsersAction,
) -> argparse.ArgumentParser:
    """Register the ``api`` subcommand."""
    api_parser = subparsers.add_parser("api", help="Start the API server")
    api_parser.add_argument(
        "--host",
        type=str,
        default="0.0.0.0",
        help="Host to bind to (default: 0.0.0.0)",
    )
    api_parser.add_argument(
        "--port",
        type=int,
        default=API_PORT,
        help=f"Port to bind to (default: {API_PORT})",
    )
    api_parser.add_argument(
        "--reload",
        action="store_true",
        default=True,
        help="Enable auto-reload (default: True)",
    )
    api_parser.add_argument(
        "--no-reload",
        dest="reload",
        action="store_false",
        help="Disable auto-reload",
    )
    return api_parser


def register_ui(
    subparsers: argparse._SubParsersAction,
) -> tuple[argparse.ArgumentParser, argparse._SubParsersAction]:
    """Register the ``ui`` subcommand and its nested commands.

    Returns:
        A tuple of (ui_parser, ui_subparsers).
    """
    ui_parser = subparsers.add_parser("ui", help="UI management commands")
    ui_sub = ui_parser.add_subparsers(dest="ui_command", help="UI command")

    serve_p = ui_sub.add_parser("serve", help="Serve the built UI (production mode)")
    serve_p.add_argument(
        "--api-url",
        type=str,
        default=None,
        help=(
            "URL of the PyCharter API "
            f"(default: env PYCHARTER_API_URL, else pycharter.cfg [api], else localhost:{API_PORT})"
        ),
    )
    serve_p.add_argument(
        "--host",
        type=str,
        default="127.0.0.1",
        help="Host to bind to (default: 127.0.0.1)",
    )
    serve_p.add_argument(
        "--port",
        type=int,
        default=UI_PORT,
        help=f"Port to bind to (default: {UI_PORT})",
    )

    dev_p = ui_sub.add_parser("dev", help="Run UI development server")
    dev_p.add_argument(
        "--api-url",
        type=str,
        default=None,
        help=(
            "URL of the PyCharter API "
            f"(default: env PYCHARTER_API_URL, else pycharter.cfg [api], else localhost:{API_PORT})"
        ),
    )
    dev_p.add_argument(
        "--port",
        type=int,
        default=UI_PORT,
        help=f"Port to run dev server on (default: {UI_PORT})",
    )

    ui_sub.add_parser("build", help="Build the UI for production")

    return ui_parser, ui_sub


def register_worker(
    subparsers: argparse._SubParsersAction,
) -> tuple[argparse.ArgumentParser, argparse._SubParsersAction]:
    """Register the ``worker`` subcommand.

    Returns:
        A tuple of (worker_parser, worker_subparsers).
    """
    worker_parser = subparsers.add_parser(
        "worker", help="Worker services (validation and pipeline queues)"
    )
    worker_sub = worker_parser.add_subparsers(
        dest="worker_command", help="Worker command"
    )
    start_p = worker_sub.add_parser(
        "start", help="Start the validation worker (poll and process jobs)"
    )
    start_p.add_argument(
        "--concurrency",
        type=int,
        default=None,
        help="Number of concurrent poller tasks (default: 5)",
    )
    start_p.add_argument(
        "--poll-interval",
        type=int,
        default=None,
        metavar="MS",
        help="Poll interval in milliseconds (default: 500)",
    )
    pipeline_p = worker_sub.add_parser(
        "pipeline", help="Start the pipeline worker (poll and process pipeline jobs)"
    )
    pipeline_p.add_argument(
        "--concurrency",
        type=int,
        default=None,
        help="Number of concurrent poller tasks (default: 5)",
    )
    pipeline_p.add_argument(
        "--poll-interval",
        type=int,
        default=None,
        metavar="MS",
        help="Poll interval in milliseconds (default: 500)",
    )
    return worker_parser, worker_sub


def register_pipeline(
    subparsers: argparse._SubParsersAction,
) -> tuple[argparse.ArgumentParser, argparse._SubParsersAction]:
    """Register the ``pipeline`` subcommand and its nested commands.

    Returns:
        A tuple of (pipeline_parser, pipeline_subparsers).
    """
    pipeline_parser = subparsers.add_parser(
        "pipeline", help="Pipeline management commands"
    )
    pipeline_sub = pipeline_parser.add_subparsers(
        dest="pipeline_command", help="Pipeline command"
    )

    # run
    run_p = pipeline_sub.add_parser("run", help="Run a pipeline")
    run_p.add_argument("path", help="Pipeline directory or config file")
    run_p.add_argument(
        "--var",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="Set variable (repeatable)",
    )
    run_p.add_argument(
        "--param",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="Set extractor parameter (repeatable)",
    )
    run_p.add_argument(
        "--dry-run",
        action="store_true",
        help="Extract and transform without loading",
    )
    run_p.add_argument(
        "--validate",
        action="store_true",
        default=True,
        help="Validate config before running (default: true)",
    )
    run_p.add_argument("--no-validate", dest="validate", action="store_false")
    run_p.add_argument(
        "--watch",
        action="store_true",
        help=(
            "Stream per-step progress to stdout as the pipeline runs. "
            "Useful for long-running pipelines or in CI logs."
        ),
    )

    # validate
    validate_p = pipeline_sub.add_parser("validate", help="Validate pipeline config")
    validate_p.add_argument("path", help="Pipeline directory or config file")

    # init
    init_p = pipeline_sub.add_parser("init", help="Create a new pipeline from template")
    init_p.add_argument("path", help="Directory to create pipeline in")
    init_p.add_argument(
        "--template",
        default="http-to-postgres",
        choices=["http-to-postgres", "database-incremental", "file-to-file"],
        help="Pipeline template (default: http-to-postgres)",
    )

    # list
    list_p = pipeline_sub.add_parser("list", help="List pipelines in a directory")
    list_p.add_argument(
        "path", nargs="?", default=".", help="Root directory (default: .)"
    )

    # inspect
    inspect_p = pipeline_sub.add_parser("inspect", help="Show pipeline config summary")
    inspect_p.add_argument("path", help="Pipeline directory or config file")

    return pipeline_parser, pipeline_sub


def register_docs(
    subparsers: argparse._SubParsersAction,
) -> tuple[argparse.ArgumentParser, argparse._SubParsersAction]:
    """Register the ``docs`` subcommand (MkDocs serve/build).

    Returns:
        A tuple of (docs_parser, docs_subparsers).
    """
    docs_parser = subparsers.add_parser(
        "docs", help="Documentation (MkDocs): serve or build"
    )
    docs_sub = docs_parser.add_subparsers(dest="docs_command", help="Docs command")

    serve_p = docs_sub.add_parser(
        "serve",
        help=(f"Serve docs locally (default: http://127.0.0.1:{DOCS_PORT})"),
    )
    serve_p.add_argument(
        "--host",
        type=str,
        default="127.0.0.1",
        help="Host to bind to (default: 127.0.0.1)",
    )
    serve_p.add_argument(
        "--port",
        type=int,
        default=DOCS_PORT,
        help=f"Port to bind to (default: {DOCS_PORT})",
    )
    docs_sub.add_parser("build", help="Build static site (output: site/)")

    return docs_parser, docs_sub


def register_quality(
    subparsers: argparse._SubParsersAction,
) -> tuple[argparse.ArgumentParser, argparse._SubParsersAction]:
    """Register the ``quality`` subcommand and its nested commands.

    Returns:
        A tuple of (quality_parser, quality_subparsers).
    """
    quality_parser = subparsers.add_parser(
        "quality", help="Data quality assurance commands"
    )
    quality_sub = quality_parser.add_subparsers(
        dest="quality_command", help="Quality command"
    )

    # check
    check_p = quality_sub.add_parser(
        "check", help="Run quality check against data contract"
    )
    check_p.add_argument(
        "--contract-name",
        dest="contract_name",
        help="Contract name (for store-based validation)",
    )
    check_p.add_argument(
        "--contract-version",
        dest="contract_version",
        help="Contract version (for store-based validation)",
    )
    check_p.add_argument(
        "--contract",
        help="Contract file path or JSON string (for contract-based validation)",
    )
    check_p.add_argument(
        "--data",
        required=True,
        help="Data file path (JSON, CSV) or '-' for stdin",
    )
    check_p.add_argument(
        "--database-url",
        dest="database_url",
        help="Database connection string (required if using --contract-name/--contract-version)",
    )
    check_p.add_argument(
        "--record-violations",
        action="store_true",
        default=True,
        help="Record violations (default: True)",
    )
    check_p.add_argument(
        "--no-record-violations",
        dest="record_violations",
        action="store_false",
        help="Don't record violations",
    )
    check_p.add_argument(
        "--check-thresholds",
        action="store_true",
        help="Check quality thresholds and alert on breaches",
    )
    check_p.add_argument(
        "--thresholds-file",
        dest="thresholds_file",
        help="JSON file with quality thresholds",
    )
    check_p.add_argument(
        "--sample-size",
        dest="sample_size",
        type=int,
        help="Only check a sample of records (for large datasets)",
    )
    check_p.add_argument(
        "--output",
        help="Output file for quality report (JSON format)",
    )

    # violations
    violations_p = quality_sub.add_parser(
        "violations", help="Query and manage quality violations"
    )
    violations_p.add_argument(
        "--contract-name",
        dest="contract_name",
        help="Filter by contract name",
    )
    violations_p.add_argument(
        "--contract-version",
        dest="contract_version",
        help="Filter by contract version",
    )
    violations_p.add_argument(
        "--status",
        choices=["open", "resolved", "ignored"],
        help="Filter by violation status",
    )
    violations_p.add_argument(
        "--severity",
        choices=["critical", "warning", "info"],
        help="Filter by severity",
    )
    violations_p.add_argument(
        "--database-url",
        dest="database_url",
        help="Database connection string (or set DATABASE_URL env var)",
    )
    violations_p.add_argument(
        "--limit",
        type=int,
        help="Maximum number of violations to return",
    )
    violations_p.add_argument(
        "--output",
        help="Output file for violations (JSON format)",
    )

    return quality_parser, quality_sub


def register_semantic(
    subparsers: argparse._SubParsersAction,
) -> tuple[argparse.ArgumentParser, argparse._SubParsersAction]:
    """Register the ``semantic`` subcommand group (RDF export / import).

    Returns:
        A tuple of (semantic_parser, semantic_subparsers).
    """
    semantic_parser = subparsers.add_parser(
        "semantic",
        help="Semantic layer tools (RDF export / import of concept schemes)",
    )
    semantic_sub = semantic_parser.add_subparsers(
        dest="semantic_command",
        help="Semantic command",
    )

    # export
    export_p = semantic_sub.add_parser(
        "export",
        help="Export a concept scheme to Turtle or JSON-LD",
    )
    export_p.add_argument(
        "scheme_key",
        help="Scheme key to export (e.g. 'biology').",
    )
    export_p.add_argument(
        "--format",
        choices=["turtle", "jsonld"],
        default="turtle",
        help="Serialisation format (default: turtle).",
    )
    export_p.add_argument(
        "--output",
        "-o",
        help="Output file path; omit or pass '-' to write to stdout.",
    )

    # import
    import_p = semantic_sub.add_parser(
        "import",
        help="Import a serialised concept scheme from a Turtle or JSON-LD file",
    )
    import_p.add_argument(
        "path",
        help="Path to the file to import.",
    )
    import_p.add_argument(
        "--format",
        choices=["turtle", "jsonld"],
        default=None,
        help="Input format; inferred from file suffix when omitted.",
    )
    import_p.add_argument(
        "--scheme-key",
        dest="scheme_key",
        default=None,
        help=(
            "Override the scheme key parsed from the RDF document. "
            "Useful when re-homing a scheme under a controlled namespace."
        ),
    )

    return semantic_parser, semantic_sub


def register_kb(
    subparsers: argparse._SubParsersAction,
) -> tuple[argparse.ArgumentParser, argparse._SubParsersAction]:
    """Register the ``kb`` subcommand group (ingest / export / cache / status).

    Returns:
        A tuple of (kb_parser, kb_subparsers).
    """
    kb_parser = subparsers.add_parser(
        "kb",
        help="Knowledge-base tools: ingest sources, export graphs, manage the cache.",
    )
    kb_sub = kb_parser.add_subparsers(dest="kb_command", help="KB command")

    # ingest
    ingest_p = kb_sub.add_parser(
        "ingest",
        help="Walk a path and run every registered extractor over matching files.",
    )
    ingest_p.add_argument(
        "path",
        help="File or directory to ingest.",
    )
    ingest_p.add_argument(
        "--no-recursive",
        dest="recursive",
        action="store_false",
        default=True,
        help="Only walk the root (skip subdirectories).",
    )
    ingest_p.add_argument(
        "--adapter",
        default=None,
        help="Force this plugin name on every file (skips extension dispatch).",
    )
    ingest_p.add_argument(
        "--ext",
        dest="extensions",
        action="append",
        default=None,
        help="Restrict to files with this extension. Pass multiple times.",
    )
    ingest_p.add_argument(
        "--include-hidden",
        action="store_true",
        help="Include dot-prefixed files / directories.",
    )
    ingest_p.add_argument(
        "--no-cache",
        dest="use_cache",
        action="store_false",
        default=True,
        help="Skip the extraction cache (read + write).",
    )
    ingest_p.add_argument(
        "--strict",
        action="store_true",
        help="Exit non-zero when a walked file has no registered handler.",
    )
    ingest_p.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="Emit a JSON summary to stdout instead of the human-readable one.",
    )

    # export
    export_p = kb_sub.add_parser(
        "export",
        help="Export a loaded concept graph to one of seven supported formats.",
    )
    export_p.add_argument(
        "--scheme-id",
        required=True,
        help="UUID or scheme_key of the scheme to export.",
    )
    export_p.add_argument(
        "--format",
        choices=[
            "json",
            "yaml",
            "rdf-turtle",
            "rdf-jsonld",
            "linkml",
            "obsidian",
            "neo4j-cypher",
            "neo4j-live",
        ],
        default="json",
        help=(
            "Output format. File-based: json, yaml, rdf-turtle, rdf-jsonld, "
            "linkml, neo4j-cypher. Directory-based: obsidian. "
            "Live: neo4j-live (requires NEO4J_URL or --url)."
        ),
    )
    export_p.add_argument(
        "--out",
        required=False,
        default=None,
        help=(
            "Output path. File for file-based formats, directory for "
            "obsidian. Optional for neo4j-live — the URL is used instead."
        ),
    )
    export_p.add_argument(
        "--url",
        default=None,
        help=(
            "Neo4j Bolt URL for --format neo4j-live. Overrides NEO4J_URL when provided."
        ),
    )
    export_p.add_argument(
        "--user",
        default=None,
        help="Neo4j username (default 'neo4j'). Overrides NEO4J_USER.",
    )
    export_p.add_argument(
        "--password",
        default=None,
        help="Neo4j password. Overrides NEO4J_PASSWORD.",
    )
    export_p.add_argument(
        "--database",
        default=None,
        help="Neo4j database name (server 4+). Overrides NEO4J_DATABASE.",
    )

    # formats
    kb_sub.add_parser(
        "formats",
        help="List every export format the registry knows about + its description.",
    )

    # cache
    cache_p = kb_sub.add_parser(
        "cache",
        help="Inspect or clear the local extraction cache.",
    )
    cache_sub = cache_p.add_subparsers(dest="cache_command", help="Cache action")
    cache_sub.add_parser(
        "status",
        help="Print the cache root + entry count.",
    )
    cache_sub.add_parser(
        "clear",
        help="Remove every cached entry.",
    )

    # status
    kb_sub.add_parser(
        "status",
        help=("Print a short summary of the KB: cache + registered adapter names."),
    )

    # llm  (sub-group: configure / status / clear) — per D4
    llm_p = kb_sub.add_parser(
        "llm",
        help=("Configure the LLM enrichment provider (neither-until-configured)."),
    )
    llm_sub = llm_p.add_subparsers(dest="llm_command", help="LLM action")
    configure_p = llm_sub.add_parser(
        "configure",
        help=(
            "Set provider + API key; writes "
            "${PYCHARTER_CONFIG_HOME:-~/.config/pycharter}/llm.yaml."
        ),
    )
    configure_p.add_argument(
        "--provider",
        choices=["anthropic", "openai"],
        default=None,
        help="Pre-select the provider non-interactively.",
    )
    configure_p.add_argument(
        "--model",
        default=None,
        help="Model id on the chosen provider.",
    )
    configure_p.add_argument(
        "--api-key",
        default=None,
        help=(
            "API key for the chosen provider. When omitted the CLI "
            "prompts for it interactively (stdin, echo off)."
        ),
    )
    configure_p.add_argument(
        "--non-interactive",
        action="store_true",
        help=(
            "Refuse to prompt for anything; fail instead if required "
            "values are missing. Useful in scripts."
        ),
    )
    llm_sub.add_parser(
        "status",
        help="Print the resolved LLM config (redacted) and whether it's usable.",
    )
    llm_sub.add_parser(
        "clear",
        help=("Delete ${PYCHARTER_CONFIG_HOME:-~/.config/pycharter}/llm.yaml."),
    )

    # neo4j  (sub-group: validate)
    neo4j_p = kb_sub.add_parser(
        "neo4j",
        help="Neo4j utilities (validate connection + write permission).",
    )
    neo4j_sub = neo4j_p.add_subparsers(dest="neo4j_command", help="Neo4j action")
    validate_p = neo4j_sub.add_parser(
        "validate",
        help="Ping a Neo4j endpoint; report version + write permission.",
    )
    validate_p.add_argument(
        "--url",
        default=None,
        help="Bolt URL (overrides NEO4J_URL).",
    )
    validate_p.add_argument(
        "--user",
        default=None,
        help="Username (overrides NEO4J_USER; default 'neo4j').",
    )
    validate_p.add_argument(
        "--password",
        default=None,
        help="Password (overrides NEO4J_PASSWORD).",
    )
    validate_p.add_argument(
        "--database",
        default=None,
        help="Named database (overrides NEO4J_DATABASE).",
    )
    validate_p.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="Emit a JSON summary instead of the human-readable one.",
    )

    return kb_parser, kb_sub
