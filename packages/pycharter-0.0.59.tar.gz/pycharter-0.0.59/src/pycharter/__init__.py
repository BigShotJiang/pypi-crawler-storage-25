# ruff: noqa: E402
"""PyCharter -- Data contract management, validation, and pipelines.

Quick start::

    from pycharter import Validator

    validator = Validator.from_files(schema="schema.yaml")
    result = validator.validate({"name": "Alice", "age": 30})

Subpackage organization:
    pycharter.contract_store    Pluggable contract persistence (5 backends)
    pycharter.contract_parser   YAML/JSON -> contract decomposition
    pycharter.contract_builder  Assemble contracts from artifacts
    pycharter.quality           Quality scoring engine
    pycharter.pipeline          ETL pipeline framework (| operator)
    pycharter.semantic          Ontology management + versioning
    pycharter.shared            Errors, protocols, utilities
    pycharter.config            Config loading + env var substitution

Pipeline API::

    from pycharter import (
        Pipeline, HTTPExtractor, PostgresLoader,
        Rename, AddField,
    )

    pipeline = (
        Pipeline(HTTPExtractor(url="https://api.example.com/data"))
        | Rename({"old": "new"})
        | AddField("processed_at", "now()")
        | PostgresLoader(connection_string="...", table="users")
    )
    result = await pipeline.run()

Validator API::

    from pycharter import Validator

    validator = Validator.from_files(schema="schema.yaml")
    result = validator.validate({"name": "Alice", "age": 30})
"""

from __future__ import annotations


def _get_version() -> str:
    try:
        from importlib.metadata import version

        return version("pycharter")
    except Exception:
        return "0.0.0.dev0"


__version__ = _get_version()

# Lazy-import mapping and __all__ live in _exports to keep this file under 400 lines.
from pycharter._exports import _LAZY_IMPORTS
from pycharter._exports import __all__ as __all__  # noqa: F401 — re-export

# Top-level public API: a single polymorphic `run`/`preflight` pair so
# users in Airflow / Dagster / scripts don't have to choose between
# `Pipeline.from_file` / `from_dict` / `from_config_dir`. Eager import:
# this is the primary entry point and should never lazy-load.
from pycharter._top_level import preflight, run

# Contract Builder
from pycharter.contract_builder import (
    ContractArtifacts,
    DataContract,
    build_contract,
    build_contract_from_store,
)

# Contract Parser
from pycharter.contract_parser import (
    ContractMetadata,
    parse_contract,
    parse_contract_file,
)

# Contract Store — core client always available
from pycharter.contract_store import ContractStoreClient
from pycharter.exceptions import PipelineRunError

# JSON Schema Converter
from pycharter.json_schema_converter import model_to_schema, to_dict, to_file, to_json

# Pipelines — core types
from pycharter.pipeline_generator import (
    AddField,
    BaseExtractor,
    BaseLoader,
    BaseTransformer,
    BatchResult,
    CloudStorageExtractor,
    CloudStorageLoader,
    Convert,
    CustomFunction,
    DatabaseExtractor,
    DatabaseLoader,
    Default,
    Drop,
    Extractor,
    FileExtractor,
    FileLoader,
    Filter,
    FlatMap,
    Flatten,
    HTTPExtractor,
    Loader,
    LoadResult,
    Map,
    Pipeline,
    PipelineContext,
    PipelineResult,
    PostgresLoader,
    Rename,
    Select,
    StepContractResolutionError,
    StepContractValidationError,
    Transformer,
    TransformerChain,
    Unnest,
    apply_step_contract_block,
    apply_step_contract_to_records,
    build_step_contract_context,
)

# Pydantic Generator
from pycharter.pydantic_generator import (
    from_dict,
    from_file,
    from_json,
    from_url,
    generate_model,
    generate_model_file,
)

# Runtime Validator
from pycharter.runtime_validator import (
    ValidationResult,
    Validator,
    ValidatorBuilder,
    create_validator,
    get_merged_schema_from_contract,
    get_model_from_contract,
    get_model_from_store,
    merge_rules_into_schema,
    validate,
    validate_batch,
    validate_batch_with_contract,
    validate_batch_with_store,
    validate_input,
    validate_output,
    validate_with_contract,
    validate_with_contract_decorator,
    validate_with_store,
)

# Canonical semantic layer — top-level re-exports for the most
# common operations so users can ``from pycharter import
# load_contract, run_pipeline_cli`` without memorizing deep import
# paths into ``pycharter.semantic.*``.
from pycharter.semantic.contracts import (
    ContractConfig,
    annotate_record,
    apply_coercion,
    load_contract,
    load_contract_from_dict,
    load_contract_from_string,
)
from pycharter.semantic.pipelines import (
    CanonicalPipelineConfig,
    StepContractBlock,
    dump_pipeline,
    load_pipeline,
)

# Protocols and Error Handling
from pycharter.shared import (
    CoercionRegistry,
    ConfigError,
    ConfigLoadError,
    ConfigValidationError,
    DataValidator,
    ErrorCode,
    ErrorContext,
    ErrorMode,
    ExpressionError,
    LenientMode,
    PyCharterError,
    StrictMode,
    ValidationRegistry,
    set_error_mode,
)


def __getattr__(name: str):
    """Lazy-load optional and heavy modules on first access."""
    if name in _LAZY_IMPORTS:
        import importlib

        module_path, attr_name = _LAZY_IMPORTS[name]
        try:
            module = importlib.import_module(module_path)
            return getattr(module, attr_name)
        except ImportError:
            return None
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
