"""SQLAlchemy-backed catalog source for the editorv2 search service.

Reads concepts and concept schemes from the existing database tables
and turns them into :class:`SearchDocument` records the index can
consume. Used by the FastAPI route that powers the Cmd+K palette.
"""

from __future__ import annotations

from collections.abc import Iterable

from sqlalchemy.orm import Session

from pycharter.db.models.semantic.concept import ConceptModel
from pycharter.db.models.semantic.concept_scheme import ConceptSchemeModel
from pycharter.semantic.search.indexer import SearchDocument


class SqlAlchemySearchCatalogSource:
    """Catalog source that reads from the semantic SQLAlchemy tables.

    Every concept row becomes one :class:`SearchDocument` with kind
    ``concept``. Every concept scheme row becomes a document with
    kind ``scheme``. Routes are computed so the palette can navigate
    directly to the editorv2 ontology page on click.
    """

    def __init__(
        self,
        session: Session,
        *,
        loaded_scheme_ids: frozenset[str] = frozenset(),
    ) -> None:
        """Construct the source.

        Args:
            session: Active SQLAlchemy session to read from.
            loaded_scheme_ids: Scheme ids the user currently has
                loaded in the editor. Documents that belong to one
                of these schemes are marked ``loaded=True`` so the
                search service ranks them first.
        """
        self._session = session
        self._loaded_scheme_ids = loaded_scheme_ids

    def concept_documents(self) -> Iterable[SearchDocument]:
        """Yield a SearchDocument for every concept in the DB."""
        rows = self._session.query(ConceptModel).all()
        for row in rows:
            scheme_id = str(row.scheme_id) if row.scheme_id is not None else None
            loaded = scheme_id is not None and scheme_id in self._loaded_scheme_ids
            subtitle_parts: list[str] = []
            if row.concept_type:
                subtitle_parts.append(row.concept_type)
            if row.tier:
                subtitle_parts.append(row.tier)
            subtitle = " · ".join(subtitle_parts) or None
            body = row.description or ""
            yield SearchDocument(
                id=f"concept:{row.id}",
                kind="concept",
                title=row.name,
                subtitle=subtitle,
                body=body,
                tags=(),
                route=(
                    f"/editor/ontology/{scheme_id}#concept={row.id}"
                    if scheme_id is not None
                    else None
                ),
                loaded=loaded,
            )

    def scheme_documents(self) -> Iterable[SearchDocument]:
        """Yield a SearchDocument for every concept scheme in the DB."""
        rows = self._session.query(ConceptSchemeModel).all()
        for row in rows:
            scheme_id = str(row.id)
            loaded = scheme_id in self._loaded_scheme_ids
            subtitle = f"{row.scheme_key} · v{row.version}"
            yield SearchDocument(
                id=f"scheme:{scheme_id}",
                kind="scheme",
                title=row.title,
                subtitle=subtitle,
                body=row.description or "",
                tags=(),
                route=f"/editor/ontology/{scheme_id}",
                loaded=loaded,
            )
