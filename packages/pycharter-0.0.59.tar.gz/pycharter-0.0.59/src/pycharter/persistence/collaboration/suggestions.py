"""Suggestion Manager — CRUD + lifecycle for the governed candidate queue.

Suggestions are candidate concepts / relations produced by extractors
(or any other origin). They sit in the suggestions table until a human
(or an automated gate) accepts or dismisses them. Acceptance is the
handoff point to :class:`pycharter.semantic.extraction.ExtractionMaterializer`
running in ``mode="direct"`` — that is where the actual concept row is
written.

The manager is deliberately narrow: create, list, get, accept, dismiss.
Bulk variants avoid N round-trips when an extraction run yields many
candidates at once.

Example:
    >>> mgr = SuggestionManager(session=session)
    >>> suggestion_id = mgr.create(
    ...     scheme_id="abc-123",
    ...     source_uri="/docs/glossary.md",
    ...     source_type="docs.markdown",
    ...     origin="doc",
    ...     suggestion_kind="concept",
    ...     payload={
    ...         "concept_key": "glossary.Customer",
    ...         "name": "Customer",
    ...         "concept_type": "entity",
    ...         "tier": "free",
    ...     },
    ...     provenance={"extractor": "docs.markdown", "source_uri": "..."},
    ... )
    >>> mgr.accept(suggestion_id, actor="alice", concept_id="concept-uuid")
"""

from __future__ import annotations

import datetime as dt
import logging
import uuid
from typing import Any

from sqlalchemy.orm import Session

from pycharter.db.models.semantic.suggestion import SuggestionModel

logger = logging.getLogger(__name__)


_PENDING = "pending"
_ACCEPTED = "accepted"
_DISMISSED = "dismissed"


class SuggestionError(Exception):
    """Raised when a suggestion operation cannot complete as requested."""


class SuggestionManager:
    """CRUD + lifecycle for :class:`SuggestionModel` rows.

    Args:
        session: Live SQLAlchemy session. Caller owns commit/rollback.
    """

    def __init__(self, session: Session | None = None) -> None:
        self._session = session

    # ------------------------------------------------------------------ create

    def create(
        self,
        *,
        scheme_id: str,
        source_uri: str,
        source_type: str,
        origin: str,
        suggestion_kind: str,
        payload: dict[str, Any],
        provenance: dict[str, Any] | None = None,
        confidence_score: float | None = None,
        confidence_level: str | None = None,
        created_by: str | None = None,
    ) -> str:
        """Persist a single pending suggestion.

        Returns:
            The UUID of the created suggestion as a string.
        """
        self._require_session()
        row = SuggestionModel(
            scheme_id=uuid.UUID(scheme_id),
            source_uri=source_uri,
            source_type=source_type,
            origin=origin,
            suggestion_kind=suggestion_kind,
            payload=payload,
            provenance=provenance,
            confidence_score=confidence_score,
            confidence_level=confidence_level,
            status=_PENDING,
            created_by=created_by,
        )
        self._session.add(row)
        self._session.flush()
        return str(row.id)

    def create_batch(
        self,
        *,
        scheme_id: str,
        drafts: list[dict[str, Any]],
        created_by: str | None = None,
    ) -> list[str]:
        """Persist a batch of drafts produced by an extraction run.

        Each draft dict carries keys matching :meth:`create`'s kwargs
        (without ``scheme_id``). Use this instead of looping ``create``
        when a single extraction yields many candidates.

        Returns:
            UUIDs of the created rows in draft-order.
        """
        self._require_session()
        scheme_uuid = uuid.UUID(scheme_id)
        new_rows: list[SuggestionModel] = []
        for draft in drafts:
            row = SuggestionModel(
                scheme_id=scheme_uuid,
                source_uri=draft["source_uri"],
                source_type=draft["source_type"],
                origin=draft["origin"],
                suggestion_kind=draft["suggestion_kind"],
                payload=draft["payload"],
                provenance=draft.get("provenance"),
                confidence_score=draft.get("confidence_score"),
                confidence_level=draft.get("confidence_level"),
                status=_PENDING,
                created_by=created_by,
            )
            new_rows.append(row)
        self._session.add_all(new_rows)
        self._session.flush()
        return [str(r.id) for r in new_rows]

    # -------------------------------------------------------------------- read

    def get(self, suggestion_id: str) -> dict[str, Any] | None:
        """Return a suggestion as a dict, or ``None`` if missing."""
        self._require_session()
        row = self._get_row(suggestion_id)
        if row is None:
            return None
        return self._to_dict(row)

    def list(  # noqa: A003 — intentionally mirrors ProposalManager.list
        self,
        *,
        scheme_id: str | None = None,
        status: str | None = None,
        source_uri: str | None = None,
        suggestion_kind: str | None = None,
        origin: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """List suggestions, optionally filtered."""
        self._require_session()
        query = self._session.query(SuggestionModel)
        if scheme_id is not None:
            query = query.filter(SuggestionModel.scheme_id == uuid.UUID(scheme_id))
        if status is not None:
            query = query.filter(SuggestionModel.status == status)
        if source_uri is not None:
            query = query.filter(SuggestionModel.source_uri == source_uri)
        if suggestion_kind is not None:
            query = query.filter(SuggestionModel.suggestion_kind == suggestion_kind)
        if origin is not None:
            query = query.filter(SuggestionModel.origin == origin)
        query = query.order_by(SuggestionModel.created_at.asc())
        if limit is not None:
            query = query.limit(limit)
        return [self._to_dict(r) for r in query.all()]

    # --------------------------------------------------------------- lifecycle

    def accept(
        self,
        suggestion_id: str,
        *,
        actor: str,
        concept_id: str | None = None,
    ) -> None:
        """Mark a suggestion as accepted.

        Callers typically invoke this after the materializer has written
        the concept row; pass its UUID via ``concept_id`` so the
        suggestion retains a link back to its materialised concept.

        Raises:
            SuggestionError: If the suggestion does not exist or is not
                currently pending.
        """
        self._require_session()
        row = self._get_row(suggestion_id)
        if row is None:
            raise SuggestionError(f"Suggestion {suggestion_id} not found")
        if row.status != _PENDING:
            raise SuggestionError(
                f"Suggestion {suggestion_id} is {row.status}, cannot accept"
            )
        row.status = _ACCEPTED
        row.accepted_at = dt.datetime.now(dt.UTC)
        row.accepted_by = actor
        row.updated_by = actor
        if concept_id is not None:
            row.accepted_concept_id = uuid.UUID(concept_id)
        self._session.flush()

    def dismiss(
        self,
        suggestion_id: str,
        *,
        actor: str,
        reason: str | None = None,
    ) -> None:
        """Mark a suggestion as dismissed; an optional reason is stored in provenance.

        Raises:
            SuggestionError: If the suggestion does not exist or is not
                currently pending.
        """
        self._require_session()
        row = self._get_row(suggestion_id)
        if row is None:
            raise SuggestionError(f"Suggestion {suggestion_id} not found")
        if row.status != _PENDING:
            raise SuggestionError(
                f"Suggestion {suggestion_id} is {row.status}, cannot dismiss"
            )
        row.status = _DISMISSED
        row.dismissed_at = dt.datetime.now(dt.UTC)
        row.dismissed_by = actor
        row.updated_by = actor
        if reason is not None:
            prov = dict(row.provenance or {})
            prov["dismissed_reason"] = reason
            row.provenance = prov
        self._session.flush()

    # ----------------------------------------------------------------- helpers

    def _require_session(self) -> None:
        if self._session is None:
            raise SuggestionError("No database session configured")

    def _get_row(self, suggestion_id: str) -> SuggestionModel | None:
        return (
            self._session.query(SuggestionModel)
            .filter(SuggestionModel.id == uuid.UUID(suggestion_id))
            .first()
        )

    @staticmethod
    def _to_dict(row: SuggestionModel) -> dict[str, Any]:
        return {
            "id": str(row.id),
            "scheme_id": str(row.scheme_id),
            "source_uri": row.source_uri,
            "source_type": row.source_type,
            "origin": row.origin,
            "suggestion_kind": row.suggestion_kind,
            "payload": row.payload,
            "provenance": row.provenance,
            "confidence_score": row.confidence_score,
            "confidence_level": row.confidence_level,
            "status": row.status,
            "accepted_concept_id": (
                str(row.accepted_concept_id) if row.accepted_concept_id else None
            ),
            "created_at": row.created_at.isoformat() if row.created_at else None,
            "updated_at": row.updated_at.isoformat() if row.updated_at else None,
            "created_by": row.created_by,
            "updated_by": row.updated_by,
            "accepted_at": (row.accepted_at.isoformat() if row.accepted_at else None),
            "accepted_by": row.accepted_by,
            "dismissed_at": (
                row.dismissed_at.isoformat() if row.dismissed_at else None
            ),
            "dismissed_by": row.dismissed_by,
        }
