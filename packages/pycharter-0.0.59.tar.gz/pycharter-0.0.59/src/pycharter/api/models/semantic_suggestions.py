"""Pydantic models for the governed-queue (suggestions) API."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class SuggestionResponse(BaseModel):
    """Single suggestion as returned by the API."""

    id: str
    scheme_id: str
    source_uri: str
    source_type: str
    origin: str
    suggestion_kind: Literal["concept", "relation"]
    payload: dict[str, Any]
    provenance: dict[str, Any] | None = None
    confidence_score: float | None = None
    confidence_level: str | None = None
    status: Literal["pending", "accepted", "dismissed"]
    accepted_concept_id: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    created_by: str | None = None
    accepted_at: str | None = None
    accepted_by: str | None = None
    dismissed_at: str | None = None
    dismissed_by: str | None = None


class SuggestionListResponse(BaseModel):
    """Paged list of suggestions."""

    items: list[SuggestionResponse]
    total: int


class AcceptSuggestionRequest(BaseModel):
    """Body for ``POST /api/v1/semantic/suggestions/{id}/accept``."""

    actor: str = Field(
        ...,
        description="User identifier recorded on the accepted row.",
    )


class AcceptSuggestionResponse(BaseModel):
    """Outcome of accepting a suggestion."""

    suggestion_id: str
    suggestion_kind: Literal["concept", "relation"]
    concept_id: str | None = Field(
        default=None,
        description="UUID of the materialised concept (concept-kind suggestions).",
    )
    relation_id: str | None = Field(
        default=None,
        description="UUID of the materialised relation (relation-kind suggestions).",
    )


class DismissSuggestionRequest(BaseModel):
    """Body for ``POST /api/v1/semantic/suggestions/{id}/dismiss``."""

    actor: str = Field(
        ...,
        description="User identifier recorded on the dismissed row.",
    )
    reason: str | None = Field(
        default=None,
        description="Optional free-text rationale; stored under provenance.dismissed_reason.",
    )


class BatchAcceptRequest(BaseModel):
    """Body for ``POST /api/v1/semantic/suggestions/accept-batch``."""

    ids: list[str] = Field(
        ...,
        description="Suggestion UUIDs to accept in one pass.",
        min_length=1,
    )
    actor: str = Field(
        ...,
        description="User identifier recorded on every accepted row.",
    )


class BatchDismissRequest(BaseModel):
    """Body for ``POST /api/v1/semantic/suggestions/dismiss-batch``."""

    ids: list[str] = Field(
        ...,
        description="Suggestion UUIDs to dismiss in one pass.",
        min_length=1,
    )
    actor: str = Field(
        ...,
        description="User identifier recorded on every dismissed row.",
    )
    reason: str | None = Field(
        default=None,
        description=(
            "Optional free-text rationale stored under "
            "provenance.dismissed_reason on every row."
        ),
    )


class BatchActionError(BaseModel):
    """Per-suggestion failure entry in a batch response."""

    suggestion_id: str
    status_code: int
    detail: str


class BatchActionResponse(BaseModel):
    """Response for batch accept / dismiss.

    - ``succeeded`` carries the ids that were resolved (with their
      materialised concept_id when available on the accept path).
    - ``errors`` lists per-id failures alongside the status code the
      single-row endpoint would have returned (404 / 409 / 422).
    """

    succeeded: list[AcceptSuggestionResponse] = Field(default_factory=list)
    errors: list[BatchActionError] = Field(default_factory=list)
    succeeded_count: int = 0
    error_count: int = 0
