"""Pydantic models for the provenance / grown-by lookup API."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class ConceptOriginResponse(BaseModel):
    """Origin + provenance + acceptance trail for a single concept."""

    concept_id: str
    concept_key: str
    scheme_id: str
    origin: str
    provenance: dict[str, Any] | None = None
    source_uri: str | None = None
    extractor: str | None = None
    extracted_at: str | None = None
    accepted_by: str | None = None
    accepted_at: str | None = None
    suggestion_id: str | None = None


class GrownEntry(BaseModel):
    """A single concept or suggestion grown from a contract or pipeline."""

    id: str
    kind: str  # "concept" or "suggestion"
    suggestion_kind: str | None = None  # concept / relation when kind="suggestion"
    scheme_id: str
    concept_key: str | None = None
    name: str | None = None
    origin: str
    status: str  # "pending" / "accepted" / "dismissed" / "materialised"
    source_uri: str | None = None
    created_at: str | None = None


class GrownResponse(BaseModel):
    """List of grown entries for an origin contract or pipeline."""

    items: list[GrownEntry]
    pending: int
    accepted: int
    dismissed: int
