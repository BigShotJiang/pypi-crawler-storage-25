"""Request / response models for the extractor test + sample endpoints.

Both endpoints back the Phase 1 inspector ``Test connection`` and
``Sample records`` buttons. The models stay deliberately thin —
``config`` is a free-form dict because every extractor type has its
own schema and the canonical validator is the Python factory at
``pycharter.pipeline_generator.extractors.factory.ExtractorFactory.create``.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ExtractorTestRequest(BaseModel):
    """Body for ``POST /api/v1/extractors/test-connection``."""

    model_config = ConfigDict(extra="forbid")

    type: str = Field(
        ...,
        description=(
            "Extractor type name (http, file, database, mongodb, kafka, …)."
            " Must match a registered extractor in the factory."
        ),
    )
    config: dict[str, Any] = Field(
        ...,
        description=(
            "Source config dict, identical to what would be placed under"
            " a step's ``source`` key in pipeline YAML. The ``type`` field"
            " is auto-injected if missing."
        ),
    )


class ExtractorTestResponse(BaseModel):
    """Result of ``POST /api/v1/extractors/test-connection``."""

    model_config = ConfigDict(extra="forbid")

    ok: bool
    """True iff a single record was successfully read from the source."""

    latency_ms: float | None = None
    """Wall-clock duration of the probe call in milliseconds."""

    detail: str | None = None
    """One-line public-facing message, e.g. for empty sources."""


class ExtractorSampleRequest(BaseModel):
    """Body for ``POST /api/v1/extractors/sample``."""

    model_config = ConfigDict(extra="forbid")

    type: str = Field(
        ...,
        description="Extractor type name. See ExtractorTestRequest.",
    )
    config: dict[str, Any] = Field(
        ..., description="Source config dict. See ExtractorTestRequest."
    )
    limit: int = Field(
        10,
        ge=1,
        le=100,
        description=(
            "Maximum records to return. Hard-capped server-side at 100"
            " regardless of input."
        ),
    )


class ExtractorSampleResponse(BaseModel):
    """Result of ``POST /api/v1/extractors/sample``."""

    model_config = ConfigDict(extra="forbid")

    rows: list[dict[str, Any]]
    """Sampled records. Length is at most ``request.limit``."""

    truncated: bool
    """True when the underlying source had more records than ``limit``."""

    latency_ms: float
    """Wall-clock duration of the probe call in milliseconds."""

    columns: list[str] | None = None
    """
    Best-effort list of top-level keys observed across ``rows``. Useful
    for the UI's preview table without forcing a schema decision; the
    field is ``None`` when ``rows`` is empty.
    """
