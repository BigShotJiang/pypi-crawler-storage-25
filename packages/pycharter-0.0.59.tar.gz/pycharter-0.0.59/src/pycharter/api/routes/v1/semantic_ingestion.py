"""Ingestion API routes."""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Query

from pycharter.api._http_errors import raise_logged_bad_request
from pycharter.api.dependencies import get_db_session
from pycharter.persistence.ingestion.importer import OntologyImporter
from pycharter.semantic.shared.errors import IngestionError

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Semantic"])


@router.post("/import")
async def import_ontology(
    contract_dir: str = Query(..., description="Path to contract directory"),
    contract_id: str | None = Query(None),
    author: str = Query("api-importer"),
    session=Depends(get_db_session),
):
    """Import ontology from a contract directory."""
    try:
        importer = OntologyImporter(session)
        result = importer.import_from_contract_dir(
            contract_dir, contract_id=contract_id, author=author
        )
        return result
    except IngestionError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail=f"Failed to import ontology from {contract_dir!r}",
            log_event="import_ontology_failed",
        )


@router.post("/import-all")
async def import_all_ontologies(
    base_dir: str = Query(..., description="Base directory with contract subdirs"),
    author: str = Query("api-importer"),
    session=Depends(get_db_session),
):
    """Import ontologies from all contract subdirectories."""
    try:
        importer = OntologyImporter(session)
        results = importer.import_from_directory(base_dir, author=author)
        return results
    except IngestionError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail=f"Failed to import ontologies from base directory {base_dir!r}",
            log_event="import_all_ontologies_failed",
        )
