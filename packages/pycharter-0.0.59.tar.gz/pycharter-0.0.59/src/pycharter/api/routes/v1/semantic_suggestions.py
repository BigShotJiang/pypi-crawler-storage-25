"""Governed-queue (suggestions) HTTP surface.

Three concerns live here:

- **List / detail** — read-only views over the suggestions table
  (``GET /api/v1/semantic/suggestions`` with status / source_uri /
  suggestion_kind / origin filters; ``GET /.../{id}``).
- **Accept** — ``POST /.../{id}/accept`` hands off to
  :func:`pycharter.semantic.extraction._acceptance.accept_suggestion`,
  which materialises the payload into the ontology and flips the
  suggestion row to ``accepted`` with a link to the new concept.
- **Dismiss** — ``POST /.../{id}/dismiss`` flips the suggestion to
  ``dismissed`` with an optional reason stored in provenance.

Both lifecycle endpoints fail loudly with 409 when the suggestion is
already resolved, and with 422 when the payload cannot be materialised
(duplicate concept key, missing relation endpoints, malformed payload).
Internal server-side errors are logged with ``logger.exception`` but
the HTTP response body uses a fixed, user-safe string per the fleet's
CodeQL-guarded error policy.
"""

from __future__ import annotations

import logging
import uuid as uuid_mod

from fastapi import APIRouter, Depends, HTTPException
from fastapi import Query as Q

from pycharter.api.dependencies import get_db_session
from pycharter.api.models.semantic_suggestions import (
    AcceptSuggestionRequest,
    AcceptSuggestionResponse,
    BatchAcceptRequest,
    BatchActionError,
    BatchActionResponse,
    BatchDismissRequest,
    DismissSuggestionRequest,
    SuggestionListResponse,
    SuggestionResponse,
)
from pycharter.persistence.collaboration.suggestions import (
    SuggestionError,
    SuggestionManager,
)
from pycharter.semantic.extraction._acceptance import (
    AcceptanceError,
    accept_suggestion,
)

router = APIRouter(tags=["Semantic - Suggestions"])
logger = logging.getLogger(__name__)


@router.get("", response_model=SuggestionListResponse)
async def list_suggestions(
    scheme_id: str | None = Q(
        default=None, description="UUID of the scheme to filter by."
    ),
    status: str | None = Q(default=None, description="pending | accepted | dismissed"),
    source_uri: str | None = Q(default=None),
    suggestion_kind: str | None = Q(default=None, description="concept | relation"),
    origin: str | None = Q(default=None),
    limit: int | None = Q(default=None, ge=1, le=500),
    session=Depends(get_db_session),
) -> SuggestionListResponse:
    """List suggestions with optional filters."""
    mgr = SuggestionManager(session=session)
    items = mgr.list(
        scheme_id=scheme_id,
        status=status,
        source_uri=source_uri,
        suggestion_kind=suggestion_kind,
        origin=origin,
        limit=limit,
    )
    return SuggestionListResponse(
        items=[SuggestionResponse(**row) for row in items],
        total=len(items),
    )


@router.get("/{suggestion_id}", response_model=SuggestionResponse)
async def get_suggestion(
    suggestion_id: str,
    session=Depends(get_db_session),
) -> SuggestionResponse:
    """Fetch a single suggestion by UUID."""
    _validate_uuid(suggestion_id)
    row = SuggestionManager(session=session).get(suggestion_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Suggestion not found")
    return SuggestionResponse(**row)


@router.post(
    "/{suggestion_id}/accept",
    response_model=AcceptSuggestionResponse,
)
async def accept(
    suggestion_id: str,
    request: AcceptSuggestionRequest,
    session=Depends(get_db_session),
) -> AcceptSuggestionResponse:
    """Accept a pending suggestion and materialise its payload.

    Raises:
        404 if the suggestion does not exist.
        409 if the suggestion is already accepted or dismissed.
        422 if the payload cannot be materialised (duplicate
            concept_key, unknown relation endpoints, malformed payload).
    """
    _validate_uuid(suggestion_id)
    try:
        result = accept_suggestion(session, suggestion_id, actor=request.actor)
    except SuggestionError as exc:
        session.rollback()
        if "not found" in str(exc):
            raise HTTPException(status_code=404, detail="Suggestion not found") from exc
        raise HTTPException(
            status_code=409, detail="Suggestion is already resolved"
        ) from exc
    except AcceptanceError as exc:
        session.rollback()
        # AcceptanceError.message is authored in _acceptance.py from a
        # fixed catalogue of messages (duplicate concept_key, missing
        # relation endpoints, malformed payload) — safe to surface
        # directly. The CodeQL-guarded pre-commit check forbids raw
        # exception-string leakage; exc.message does not trigger it.
        raise HTTPException(status_code=422, detail=exc.message) from exc
    except Exception:  # pragma: no cover - defensive
        session.rollback()
        logger.exception("unexpected error accepting suggestion %s", suggestion_id)
        raise HTTPException(
            status_code=500, detail="Could not accept suggestion"
        ) from None
    session.commit()
    return AcceptSuggestionResponse(
        suggestion_id=result.suggestion_id,
        suggestion_kind=result.suggestion_kind,
        concept_id=result.concept_id,
        relation_id=result.relation_id,
    )


@router.post("/{suggestion_id}/dismiss")
async def dismiss(
    suggestion_id: str,
    request: DismissSuggestionRequest,
    session=Depends(get_db_session),
) -> dict[str, str]:
    """Dismiss a pending suggestion with an optional reason.

    Raises:
        404 if the suggestion does not exist.
        409 if the suggestion is already accepted or dismissed.
    """
    _validate_uuid(suggestion_id)
    try:
        SuggestionManager(session=session).dismiss(
            suggestion_id, actor=request.actor, reason=request.reason
        )
    except SuggestionError as exc:
        session.rollback()
        if "not found" in str(exc):
            raise HTTPException(status_code=404, detail="Suggestion not found") from exc
        raise HTTPException(
            status_code=409, detail="Suggestion is already resolved"
        ) from exc
    session.commit()
    return {"suggestion_id": suggestion_id, "status": "dismissed"}


# -----------------------------------------------------------------------------
# Batch operations
# -----------------------------------------------------------------------------


@router.post("/accept-batch", response_model=BatchActionResponse)
async def accept_batch(
    request: BatchAcceptRequest,
    session=Depends(get_db_session),
) -> BatchActionResponse:
    """Accept many suggestions in one pass.

    Processes every id independently: one failing suggestion does not
    abort the batch. Successes + failures are returned together so the
    UI can tell the reviewer "27 accepted, 3 skipped, here's why".
    """
    succeeded: list[AcceptSuggestionResponse] = []
    errors: list[BatchActionError] = []
    for suggestion_id in request.ids:
        try:
            _validate_uuid(suggestion_id)
        except HTTPException as exc:
            errors.append(
                BatchActionError(
                    suggestion_id=suggestion_id,
                    status_code=exc.status_code,
                    detail=exc.detail if isinstance(exc.detail, str) else "invalid",
                )
            )
            continue
        try:
            result = accept_suggestion(session, suggestion_id, actor=request.actor)
            succeeded.append(
                AcceptSuggestionResponse(
                    suggestion_id=result.suggestion_id,
                    suggestion_kind=result.suggestion_kind,
                    concept_id=result.concept_id,
                    relation_id=result.relation_id,
                )
            )
        except SuggestionError as exc:
            session.rollback()
            if "not found" in str(exc):
                errors.append(
                    BatchActionError(
                        suggestion_id=suggestion_id,
                        status_code=404,
                        detail="Suggestion not found",
                    )
                )
            else:
                errors.append(
                    BatchActionError(
                        suggestion_id=suggestion_id,
                        status_code=409,
                        detail="Suggestion is already resolved",
                    )
                )
        except AcceptanceError as exc:
            session.rollback()
            errors.append(
                BatchActionError(
                    suggestion_id=suggestion_id,
                    status_code=422,
                    detail=exc.message,
                )
            )
        except Exception:  # pragma: no cover - defensive
            session.rollback()
            logger.exception("unexpected error in accept-batch for %s", suggestion_id)
            errors.append(
                BatchActionError(
                    suggestion_id=suggestion_id,
                    status_code=500,
                    detail="Could not accept suggestion",
                )
            )
    session.commit()
    logger.info(
        "accept-batch: requested=%d accepted=%d errors=%d",
        len(request.ids),
        len(succeeded),
        len(errors),
    )
    return BatchActionResponse(
        succeeded=succeeded,
        errors=errors,
        succeeded_count=len(succeeded),
        error_count=len(errors),
    )


@router.post("/dismiss-batch", response_model=BatchActionResponse)
async def dismiss_batch(
    request: BatchDismissRequest,
    session=Depends(get_db_session),
) -> BatchActionResponse:
    """Dismiss many suggestions in one pass.

    Same semantics as :func:`accept_batch`: per-id failures land in
    ``errors`` without aborting the batch.
    """
    manager = SuggestionManager(session=session)
    succeeded: list[AcceptSuggestionResponse] = []
    errors: list[BatchActionError] = []
    for suggestion_id in request.ids:
        try:
            _validate_uuid(suggestion_id)
        except HTTPException as exc:
            errors.append(
                BatchActionError(
                    suggestion_id=suggestion_id,
                    status_code=exc.status_code,
                    detail=exc.detail if isinstance(exc.detail, str) else "invalid",
                )
            )
            continue
        try:
            manager.dismiss(
                suggestion_id,
                actor=request.actor,
                reason=request.reason,
            )
            succeeded.append(
                AcceptSuggestionResponse(
                    suggestion_id=suggestion_id,
                    suggestion_kind="concept",  # kind unknown without refetch; UI only reads id
                )
            )
        except SuggestionError as exc:
            session.rollback()
            if "not found" in str(exc):
                errors.append(
                    BatchActionError(
                        suggestion_id=suggestion_id,
                        status_code=404,
                        detail="Suggestion not found",
                    )
                )
            else:
                errors.append(
                    BatchActionError(
                        suggestion_id=suggestion_id,
                        status_code=409,
                        detail="Suggestion is already resolved",
                    )
                )
        except Exception:  # pragma: no cover - defensive
            session.rollback()
            logger.exception("unexpected error in dismiss-batch for %s", suggestion_id)
            errors.append(
                BatchActionError(
                    suggestion_id=suggestion_id,
                    status_code=500,
                    detail="Could not dismiss suggestion",
                )
            )
    session.commit()
    logger.info(
        "dismiss-batch: requested=%d dismissed=%d errors=%d",
        len(request.ids),
        len(succeeded),
        len(errors),
    )
    return BatchActionResponse(
        succeeded=succeeded,
        errors=errors,
        succeeded_count=len(succeeded),
        error_count=len(errors),
    )


def _validate_uuid(suggestion_id: str) -> None:
    """Reject non-UUID ids with a clean 422 before any DB call."""
    try:
        uuid_mod.UUID(suggestion_id)
    except (ValueError, AttributeError) as exc:
        raise HTTPException(
            status_code=422, detail="suggestion_id must be a UUID"
        ) from exc
