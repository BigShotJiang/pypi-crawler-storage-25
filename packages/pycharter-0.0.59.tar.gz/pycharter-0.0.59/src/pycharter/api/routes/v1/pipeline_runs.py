"""Live-progress async pipeline-run endpoints (Phase 4).

Two routes:

* ``POST /api/v1/pipeline/runs`` — schedules a pipeline run as a
  background task and returns ``{run_id, stream_url}`` immediately. The
  task publishes per-step events onto the application-wide
  :class:`pycharter.events.ChangeBus` via :class:`RunProgressEmitter`.

* ``GET /api/v1/pipeline/runs/{run_id}/stream`` — Server-Sent Events
  endpoint that subscribes to the per-run topic and relays events to
  the UI / CLI in real time.

The synchronous ``POST /pipeline/run`` endpoint at
``api/routes/v1/pipeline.py`` remains for now and is being deprecated;
new clients should prefer this async path.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import uuid
from typing import TYPE_CHECKING, Any

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from pycharter import Pipeline
from pycharter.api._http_errors import raise_logged_bad_request_from_exception
from pycharter.api.dependencies.database import get_db_session
from pycharter.api.models.pipeline_run import RunStartRequest, RunStartResponse
from pycharter.api.services.pipeline_run_store import (
    create_pipeline_run_record,
    mark_pipeline_run_cancelled,
    mark_pipeline_run_failed,
    mark_pipeline_run_running,
    save_pipeline_result,
)
from pycharter.config import get_database_url
from pycharter.db.session import get_session
from pycharter.pipeline_generator._run_progress import RunProgressEmitter
from pycharter.worker.pipeline_jobs import PipelineJob, PipelineJobSource

if TYPE_CHECKING:
    from pycharter.events import ChangeBus

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Pipeline Runs"])


def _pipeline_job_source(db_url: str | None = None) -> PipelineJobSource:
    return PipelineJobSource(db_url or get_database_url())


@router.post(
    "/pipeline/jobs",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Enqueue a durable pipeline worker job",
)
async def enqueue_pipeline_job(
    body: RunStartRequest,
    request: Request,
    db: Session = Depends(get_db_session),
) -> dict[str, str]:
    """Create a durable pipeline job and initial run lifecycle row."""
    db_url = getattr(request.app.state, "pipeline_db_url", None) or get_database_url()
    source = _pipeline_job_source(db_url)
    run_id = uuid.uuid4().hex[:12]
    try:
        create_pipeline_run_record(
            db,
            run_id=run_id,
            config_snapshot=body.config,
            trigger="worker",
        )
        submitted_run_id = await source.submit(
            PipelineJob(
                run_id=run_id,
                config=body.config,
                variables=body.variables,
                fail_fast=body.fail_fast,
            )
        )
        return {"run_id": submitted_run_id, "status": "queued"}
    finally:
        await source.close()


@router.get(
    "/pipeline/jobs",
    summary="List durable pipeline worker jobs",
)
async def list_pipeline_jobs(
    request: Request,
    status_filter: str | None = None,
    limit: int = 100,
    offset: int = 0,
) -> list[dict[str, Any]]:
    """List pipeline worker jobs for operational UI surfaces."""
    db_url = getattr(request.app.state, "pipeline_db_url", None) or get_database_url()
    source = _pipeline_job_source(db_url)
    try:
        return await source.list_jobs(status=status_filter, limit=limit, offset=offset)
    finally:
        await source.close()


@router.get(
    "/pipeline/jobs/stats",
    summary="Get durable pipeline worker job statistics",
)
async def get_pipeline_job_stats(request: Request) -> dict[str, int]:
    """Return queue counts for pipeline worker jobs."""
    db_url = getattr(request.app.state, "pipeline_db_url", None) or get_database_url()
    source = _pipeline_job_source(db_url)
    try:
        return await source.get_stats()
    finally:
        await source.close()


@router.post(
    "/pipeline/jobs/{run_id}/cancel",
    summary="Cancel a queued or claimed pipeline worker job",
)
async def cancel_pipeline_job(
    run_id: str,
    request: Request,
    db: Session = Depends(get_db_session),
) -> dict[str, str]:
    """Cancel a pipeline job and mark the run lifecycle as cancelled."""
    db_url = getattr(request.app.state, "pipeline_db_url", None) or get_database_url()
    source = _pipeline_job_source(db_url)
    try:
        cancelled = await source.cancel(run_id)
        if not cancelled:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Cannot cancel pipeline job for run {run_id}",
            )
        mark_pipeline_run_cancelled(db, run_id)
        return {"run_id": run_id, "status": "cancelled"}
    finally:
        await source.close()


# ---------------------------------------------------------------------------
# POST /pipeline/runs — schedule a run, return immediately
# ---------------------------------------------------------------------------


@router.post(
    "/pipeline/runs",
    response_model=RunStartResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Start a pipeline run (async)",
    description=(
        "Schedules a pipeline run as a background task and returns a "
        "run identifier plus the SSE stream URL. Subscribe to "
        "GET /pipeline/runs/{run_id}/stream to receive lifecycle "
        "events (pipeline_start, step_start/complete/failed, "
        "pipeline_complete/failed) in real time. "
        "For a synchronous run-and-wait endpoint see POST /pipeline/run."
    ),
)
async def start_pipeline_run(
    request: Request,
    body: RunStartRequest,
    db: Session = Depends(get_db_session),
) -> RunStartResponse:
    """Build the pipeline, schedule it, and return identifiers."""
    try:
        pipeline = Pipeline.from_dict(
            body.config,
            extra_variables=body.variables,
        )
    except ValueError as exc:
        raise_logged_bad_request_from_exception(
            logger,
            exc,
            log_event="pipeline_run_start_invalid_config",
            fallback_detail="Pipeline config is invalid",
            extra_safe_types=(ValueError,),
        )

    run_id = uuid.uuid4().hex[:12]
    create_pipeline_run_record(
        db,
        run_id=run_id,
        config_snapshot=body.config,
        trigger="api_async",
    )
    bus: ChangeBus = request.app.state.change_bus
    progress = RunProgressEmitter(bus, run_id)

    runs: dict[str, asyncio.Task[Any]] = request.app.state.pipeline_runs
    db_url = getattr(request.app.state, "pipeline_db_url", None) or get_database_url()

    async def _execute() -> None:
        run_db = get_session(db_url)
        try:
            mark_pipeline_run_running(run_db, run_id)
            result = await pipeline.run(
                run_id=run_id,
                fail_fast=body.fail_fast,
                progress=progress,
            )
            save_pipeline_result(
                run_db,
                result,
                config_snapshot=body.config,
                trigger="api_async",
            )
        except Exception:
            # Pipeline.run already emits pipeline_failed via the runner
            # path; this catches any unexpected error escaping that
            # wiring (e.g. failure during contract-store connect). We
            # must not let the exception go unobserved by SSE clients.
            logger.exception("Pipeline run %s crashed before runner emitted", run_id)
            try:
                progress.pipeline_failed("internal error")
            except Exception:  # noqa: BLE001 — observability boundary
                logger.warning("Failed to emit pipeline_failed", exc_info=True)
            with contextlib.suppress(Exception):
                mark_pipeline_run_failed(
                    run_db,
                    run_id,
                    "internal error",
                    config_snapshot=body.config,
                    trigger="api_async",
                )
        finally:
            run_db.close()

    task = asyncio.create_task(_execute(), name=f"pipeline_run:{run_id}")
    runs[run_id] = task

    def _cleanup(t: asyncio.Task[Any]) -> None:
        runs.pop(run_id, None)
        if t.cancelled():
            logger.info("Pipeline run %s cancelled", run_id)
        elif (exc := t.exception()) is not None:
            logger.warning(
                "Pipeline run %s task ended with exception", run_id, exc_info=exc
            )

    task.add_done_callback(_cleanup)

    stream_url = f"/api/v1/pipeline/runs/{run_id}/stream"
    return RunStartResponse(run_id=run_id, stream_url=stream_url)


# ---------------------------------------------------------------------------
# GET /pipeline/runs/{run_id}/stream — SSE
# ---------------------------------------------------------------------------


_TERMINAL_ACTIONS = frozenset({"pipeline_complete", "pipeline_failed"})


async def _run_event_generator(
    request: Request,
    bus: ChangeBus,
    run_id: str,
):
    """Yield SSE-formatted change events for a single run.

    Closes when the client disconnects or after a terminal event
    (``pipeline_complete`` / ``pipeline_failed``) has been delivered,
    whichever comes first. Unlike the generic ``/events/stream`` we
    auto-close on terminal because no further events will fire — this
    lets ``EventSource`` consumers know they can stop reconnecting.
    """
    topic = f"pipeline_run.{run_id}"
    queue = bus.subscribe(topic)
    try:
        # Replay any buffered events for this topic so a UI that
        # opens the stream a few ms after POST /runs returns doesn't
        # miss pipeline_start / early step events. The bus keeps the
        # last 100 events globally, which dwarfs any single run.
        for event in bus.recent():
            if event.topic == topic:
                yield f"data: {json.dumps(event.to_dict())}\n\n"
                if event.action in _TERMINAL_ACTIONS:
                    return

        while not await request.is_disconnected():
            try:
                event = await asyncio.wait_for(queue.get(), timeout=15.0)
                yield f"data: {json.dumps(event.to_dict())}\n\n"
                if event.action in _TERMINAL_ACTIONS:
                    return
            except TimeoutError:
                yield ": keepalive\n\n"
    finally:
        bus.unsubscribe(queue, topic)


@router.get(
    "/pipeline/runs/{run_id}/stream",
    summary="Stream a pipeline run's progress (SSE)",
    description=(
        "Server-Sent Events endpoint that emits lifecycle events for "
        "the run identified by `run_id`. Closes automatically after a "
        "terminal event (`pipeline_complete` or `pipeline_failed`)."
    ),
)
async def stream_pipeline_run(
    request: Request,
    run_id: str,
) -> StreamingResponse:
    """Stream a single run's lifecycle events."""
    if not run_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="run_id is required",
        )
    bus: ChangeBus = request.app.state.change_bus
    return StreamingResponse(
        _run_event_generator(request, bus, run_id),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
