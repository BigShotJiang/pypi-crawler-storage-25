"""FastAPI routes for KB versioning, cross-KB linking, and lineage.

Uses an in-memory :class:`KBManagementService` singleton for Phase 1.
A future phase will inject a persistent repository via FastAPI
dependencies.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, ConfigDict, Field

from pycharter.semantic.knowledge_base.models import (
    KBLink,
    KBVersion,
    LineageArtifactRef,
    LineageRecord,
)
from pycharter.semantic.knowledge_base.service import KBManagementService

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Editor Knowledge Base"])

# Phase 1: singleton in-memory service. NOT THREAD-SAFE for
# concurrent writes — acceptable for single-user dev mode but must
# be replaced with a DB-backed repository (injected via FastAPI
# Depends()) before production deployment. Data does NOT persist
# across server restarts.
_service = KBManagementService()


# =============================================================================
# KB Versions
# =============================================================================


class CreateKBVersionRequest(BaseModel):
    """Request body for creating a KB version."""

    model_config = ConfigDict(extra="forbid")

    kb_name: str
    version: str
    description: str | None = None
    document_count: int = 0
    chunk_count: int = 0
    embedding_model: str | None = None
    index_target: str | None = None
    pipeline_run_id: str | None = None
    tags: list[str] = Field(default_factory=list)


@router.get(
    "/editor/kb/versions",
    response_model=list[KBVersion],
    summary="List KB versions",
)
async def list_kb_versions(
    kb_name: str | None = None,
) -> list[KBVersion]:
    """List all KB versions, optionally filtered by kb_name."""
    return _service.list_versions(kb_name)


@router.post(
    "/editor/kb/versions",
    response_model=KBVersion,
    summary="Create a KB version",
    status_code=status.HTTP_201_CREATED,
)
async def create_kb_version(
    request: CreateKBVersionRequest,
) -> KBVersion:
    """Create a new KB version snapshot."""
    return _service.create_version(
        kb_name=request.kb_name,
        version=request.version,
        description=request.description,
        document_count=request.document_count,
        chunk_count=request.chunk_count,
        embedding_model=request.embedding_model,
        index_target=request.index_target,
        pipeline_run_id=request.pipeline_run_id,
        tags=tuple(request.tags),
    )


@router.get(
    "/editor/kb/versions/{version_id}",
    response_model=KBVersion,
    summary="Get a KB version",
)
async def get_kb_version(version_id: str) -> KBVersion:
    """Get a specific KB version by id."""
    v = _service.get_version(version_id)
    if v is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"KB version '{version_id}' not found",
        )
    return v


@router.get(
    "/editor/kb/versions/compare",
    summary="Compare two KB versions",
)
async def compare_kb_versions(
    version_a: str,
    version_b: str,
) -> dict[str, object]:
    """Compare two KB versions and return a diff summary."""
    return _service.compare_versions(version_a, version_b)


# =============================================================================
# Cross-KB Links
# =============================================================================


class CreateKBLinkRequest(BaseModel):
    """Request body for creating a cross-KB link."""

    model_config = ConfigDict(extra="forbid")

    source_kb: str
    target_kb: str
    relationship: str = "references"
    description: str | None = None


@router.get(
    "/editor/kb/links",
    response_model=list[KBLink],
    summary="List cross-KB links",
)
async def list_kb_links(
    kb_name: str | None = None,
) -> list[KBLink]:
    """List all cross-KB links, optionally filtered by kb_name."""
    return _service.list_links(kb_name)


@router.post(
    "/editor/kb/links",
    response_model=KBLink,
    summary="Create a cross-KB link",
    status_code=status.HTTP_201_CREATED,
)
async def create_kb_link(
    request: CreateKBLinkRequest,
) -> KBLink:
    """Declare a relationship between two knowledge bases."""
    return _service.create_link(
        source_kb=request.source_kb,
        target_kb=request.target_kb,
        relationship=request.relationship,
        description=request.description,
    )


@router.delete(
    "/editor/kb/links/{link_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Remove a cross-KB link",
)
async def remove_kb_link(link_id: str) -> None:
    """Remove a cross-KB link."""
    if not _service.remove_link(link_id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"KB link '{link_id}' not found",
        )


# =============================================================================
# Lineage Tracking
# =============================================================================


class RecordLineageRequest(BaseModel):
    """Request body for recording a lineage entry."""

    model_config = ConfigDict(extra="forbid")

    run_id: str
    step_id: str
    step_type: str
    input_artifact: LineageArtifactRef
    output_artifact: LineageArtifactRef
    contract_id: str | None = None


@router.post(
    "/editor/lineage",
    response_model=LineageRecord,
    summary="Record a lineage entry",
    status_code=status.HTTP_201_CREATED,
)
async def record_lineage(
    request: RecordLineageRequest,
) -> LineageRecord:
    """Record a single lineage hop from input to output artifact."""
    return _service.record_lineage(
        run_id=request.run_id,
        step_id=request.step_id,
        step_type=request.step_type,
        input_artifact=request.input_artifact,
        output_artifact=request.output_artifact,
        contract_id=request.contract_id,
    )


@router.get(
    "/editor/lineage/{artifact_id}",
    response_model=list[LineageRecord],
    summary="Get lineage for an artifact",
)
async def get_artifact_lineage(
    artifact_id: str,
) -> list[LineageRecord]:
    """Get all lineage records for a specific artifact."""
    return _service.get_lineage_for_artifact(artifact_id)


@router.get(
    "/editor/lineage/run/{run_id}",
    response_model=list[LineageRecord],
    summary="Get lineage for a pipeline run",
)
async def get_run_lineage(run_id: str) -> list[LineageRecord]:
    """Get all lineage records for a specific pipeline run."""
    return _service.get_lineage_for_run(run_id)


@router.get(
    "/editor/lineage/{artifact_id}/trace",
    response_model=list[LineageRecord],
    summary="Trace provenance",
)
async def trace_provenance(artifact_id: str) -> list[LineageRecord]:
    """Walk backward from an artifact to its ultimate sources."""
    return _service.trace_provenance(artifact_id)
