"""Lineage API routes.

Two families of routes live here:

- ``/upstream``, ``/downstream``, ``/path`` — read-side queries backed
  by :class:`pycharter.semantic.knowledge.lineage.LineageTracker`.
- ``/record`` — write-side hook that computes a
  :class:`pycharter.schema_evolution.SchemaDiff` between two contract
  versions and runs
  :class:`pycharter.semantic.lifecycle.FieldLineageRecorder` so
  ``derived_from`` edges for every affected bound field land in the
  concept graph without any operator intervention.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from pycharter.api._http_errors import raise_logged_bad_request
from pycharter.api.dependencies import get_contract_store, get_db_session
from pycharter.api.dependencies.lifecycle import get_binding_lifecycle
from pycharter.api.dependencies.semantic_store import get_semantic_store
from pycharter.api.models.semantic_lineage import (
    FieldLineageRequest,
    LineagePathRequest,
)
from pycharter.contract_store import ContractStoreClient
from pycharter.schema_evolution import compute_diff
from pycharter.semantic.knowledge.lineage import LineageTracker
from pycharter.semantic.lifecycle import BindingLifecycle, FieldLineageRecorder
from pycharter.semantic.shared.errors import GraphError
from pycharter.semantic_store.client import SemanticStoreClient

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Semantic"])


@router.post("/upstream")
async def get_upstream(
    request: FieldLineageRequest,
    relationship_types: str | None = None,
    session=Depends(get_db_session),
):
    """Get upstream fields. Optional comma-separated relationship_types filter."""
    try:
        tracker = LineageTracker(session)
        types = relationship_types.split(",") if relationship_types else None
        return tracker.get_upstream(request.field_id, relationship_types=types)
    except GraphError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail=f"Failed to load upstream lineage for field {request.field_id!r}",
            log_event="get_upstream_lineage_failed",
        )


@router.post("/downstream")
async def get_downstream(
    request: FieldLineageRequest,
    relationship_types: str | None = None,
    session=Depends(get_db_session),
):
    """Get downstream fields. Optional comma-separated relationship_types filter."""
    try:
        tracker = LineageTracker(session)
        types = relationship_types.split(",") if relationship_types else None
        return tracker.get_downstream(request.field_id, relationship_types=types)
    except GraphError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail=(
                f"Failed to load downstream lineage for field {request.field_id!r}"
            ),
            log_event="get_downstream_lineage_failed",
        )


@router.post("/path")
async def get_lineage_path(
    request: LineagePathRequest, session=Depends(get_db_session)
):
    """Get the lineage path between two fields."""
    try:
        tracker = LineageTracker(session)
        return tracker.get_lineage_path(
            request.source_field_id, request.target_field_id
        )
    except GraphError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail=(
                f"Failed to compute lineage path from "
                f"{request.source_field_id!r} to {request.target_field_id!r}"
            ),
            log_event="get_lineage_path_failed",
        )


# ---------------------------------------------------------------------------
# Evolution-driven lineage recorder
# ---------------------------------------------------------------------------


class LineageRecordRequest(BaseModel):
    """Request body for ``POST /semantic/lineage/record``."""

    contract_name: str = Field(
        ...,
        description="Contract identifier without the version suffix.",
    )
    old_version: str = Field(..., description="Prior version (e.g. '1.0.0').")
    new_version: str = Field(..., description="New version (e.g. '1.1.0').")
    actor: str = Field(
        default="schema_evolution",
        description="Audit attribution for the emitted edges.",
    )


class LineageRecordResponse(BaseModel):
    """Response body for ``POST /semantic/lineage/record``."""

    old_contract_id: str
    new_contract_id: str
    edges_written: list[tuple[str, str]]


@router.post("/record", response_model=LineageRecordResponse)
def record_lineage(
    request: LineageRecordRequest,
    contracts: ContractStoreClient = Depends(get_contract_store),
    store: SemanticStoreClient = Depends(get_semantic_store),
    lifecycle: BindingLifecycle = Depends(get_binding_lifecycle),
) -> LineageRecordResponse:
    """Compute the diff between two contract versions and record lineage.

    Returns the ``(new_field_name, old_field_name)`` pairs written so
    callers (contract-publish flows, CI checks) can log what landed.
    """
    old_schema = contracts.get_schema(request.contract_name, request.old_version)
    new_schema = contracts.get_schema(request.contract_name, request.new_version)

    if old_schema is None:
        raise HTTPException(
            status_code=404,
            detail=(
                f"Old contract not found: {request.contract_name}:{request.old_version}"
            ),
        )
    if new_schema is None:
        raise HTTPException(
            status_code=404,
            detail=(
                f"New contract not found: {request.contract_name}:{request.new_version}"
            ),
        )

    diff = compute_diff(old_schema, new_schema)
    recorder = FieldLineageRecorder(store, lifecycle=lifecycle)

    old_contract_id = f"{request.contract_name}:{request.old_version}"
    new_contract_id = f"{request.contract_name}:{request.new_version}"

    edges = recorder.record_evolution(
        old_contract_id=old_contract_id,
        new_contract_id=new_contract_id,
        diff=diff,
        actor=request.actor,
    )
    logger.info(
        "lineage recorded: %s → %s (%d edges)",
        old_contract_id,
        new_contract_id,
        len(edges),
    )
    return LineageRecordResponse(
        old_contract_id=old_contract_id,
        new_contract_id=new_contract_id,
        edges_written=edges,
    )
