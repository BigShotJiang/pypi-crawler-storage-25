"""Schema import API routes for the Knowledge Base builder.

Provides endpoints for importing schemas from DDL, dbt manifests,
OpenAPI specs, CSV files, and live database connections.
Persists imported schemas to the database via the materializer.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException

logger = logging.getLogger(__name__)

from pydantic import BaseModel, Field

from pycharter.api._http_errors import raise_logged_bad_request
from pycharter.api.dependencies.database import get_db_session
from pycharter.semantic.ingestion.materializer import IRMaterializer
from pycharter.semantic.ingestion.plugins import create_default_registry
from pycharter.semantic.ingestion.structural_inference import enrich_schema
from pycharter.semantic.shared.errors import IngestionError

router = APIRouter(prefix="/schema-import", tags=["Schema Import"])


class DDLImportRequest(BaseModel):
    """Request to import a DDL schema."""

    source: str = Field(..., description="DDL text or file path")
    source_name: str = Field("ddl_import", description="Name for the schema")
    dialect: str | None = Field(None, description="SQL dialect (postgres, mysql, etc.)")
    replace: bool = Field(False, description="Replace existing schema with same name")


class ImportResponse(BaseModel):
    """Response from a schema import."""

    schema_id: str = ""
    source_name: str
    source_type: str
    table_count: int
    relationship_count: int
    tables: list[dict[str, Any]]
    relationships: list[dict[str, Any]]
    metadata: dict[str, Any]
    skipped: bool = False


def _build_response(
    schema_dict: dict[str, Any],
    schema_id: str = "",
    skipped: bool = False,
) -> ImportResponse:
    """Build an ImportResponse from an ImportedSchema dict."""
    return ImportResponse(
        schema_id=schema_id,
        source_name=schema_dict["source_name"],
        source_type=schema_dict["source_type"],
        table_count=len(schema_dict["tables"]),
        relationship_count=len(schema_dict["relationships"]),
        tables=schema_dict["tables"],
        relationships=schema_dict["relationships"],
        metadata=schema_dict.get("metadata", {}),
        skipped=skipped,
    )


@router.post("/ddl", response_model=ImportResponse)
async def import_ddl(
    request: DDLImportRequest,
    session=Depends(get_db_session),
) -> ImportResponse:
    """Import a schema from SQL DDL.

    Parses CREATE TABLE statements, enriches with inferred relationships,
    and persists to the database.
    """
    try:
        registry = create_default_registry()
        schema = registry.import_schema(
            source=request.source,
            plugin_name="ddl",
            source_name=request.source_name,
            dialect=request.dialect,
        )
        enriched = enrich_schema(schema)

        # Persist to database
        materializer = IRMaterializer(session)
        result = materializer.materialize(
            enriched, author="api-importer", replace=request.replace
        )

        if result.skipped:
            return _build_response(
                enriched.to_dict(),
                schema_id=result.schema_id,
                skipped=True,
            )

        try:
            session.commit()
        except Exception as exc:
            session.rollback()
            raise HTTPException(
                status_code=500,
                detail=f"Failed to commit schema import: {exc}",
            )
        return _build_response(enriched.to_dict(), schema_id=result.schema_id)
    except IngestionError as exc:
        raise_logged_bad_request(
            logger,
            exc,
            public_detail=(
                f"Failed to import DDL schema {request.source_name!r} "
                f"(parse error, unsupported dialect, or invalid DDL)"
            ),
            log_event="import_ddl_failed",
        )


class GenericImportRequest(BaseModel):
    """Request to import from any supported source."""

    source: str = Field(..., description="Source content or path")
    source_name: str | None = Field(None, description="Name for the schema")
    plugin_name: str | None = Field(None, description="Explicit plugin name")
    replace: bool = Field(False, description="Replace existing schema")
    options: dict[str, Any] = Field(default_factory=dict)


@router.post("/import", response_model=ImportResponse)
async def import_schema(
    request: GenericImportRequest,
    session=Depends(get_db_session),
) -> ImportResponse:
    """Import a schema from any supported source.

    Auto-detects the source type if plugin_name is not specified.
    Persists to the database.
    """
    try:
        registry = create_default_registry()
        schema = registry.import_schema(
            source=request.source,
            plugin_name=request.plugin_name,
            source_name=request.source_name,
            **request.options,
        )
        enriched = enrich_schema(schema)

        materializer = IRMaterializer(session)
        result = materializer.materialize(
            enriched, author="api-importer", replace=request.replace
        )

        if result.skipped:
            return _build_response(
                enriched.to_dict(),
                schema_id=result.schema_id,
                skipped=True,
            )

        try:
            session.commit()
        except Exception as exc:
            session.rollback()
            raise HTTPException(
                status_code=500,
                detail=f"Failed to commit schema import: {exc}",
            )
        return _build_response(enriched.to_dict(), schema_id=result.schema_id)
    except IngestionError as exc:
        raise_logged_bad_request(
            logger,
            exc,
            public_detail=(
                f"Failed to import schema (plugin={request.plugin_name!r}): "
                f"unsupported source type, parse error, or invalid options"
            ),
            log_event="import_schema_failed",
        )


@router.get("/plugins")
async def list_plugins() -> list[str]:
    """List available import plugins."""
    registry = create_default_registry()
    return registry.list_plugins()
