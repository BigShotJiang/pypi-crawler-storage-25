"""FastAPI route for editorv2 universal search.

Exposes ``GET /editor/search`` which powers the Cmd+K palette.
The endpoint reindexes on every call (cheap with in-memory storage
for small deployments) and applies a configurable limit. Scheme
ids currently loaded in the user's workspace can be passed as a
repeated ``loaded`` query parameter so results from those schemes
surface in the 'Loaded' section first.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from pycharter.api.dependencies.database import get_db_session
from pycharter.api.models.editor_search import (
    SearchDocumentResponse,
    SearchResponse,
    SearchResultItem,
    SearchSectionResponse,
)
from pycharter.persistence.search.sqlalchemy_source import (
    SqlAlchemySearchCatalogSource,
)
from pycharter.semantic.search import SearchService
from pycharter.semantic.search.indexer import (
    SearchResult,
    SearchResultSection,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Editor Search"])


def _to_document_response(result: SearchResult) -> SearchResultItem:
    """Convert a :class:`SearchResult` to its JSON response shape."""
    doc = result.document
    return SearchResultItem(
        document=SearchDocumentResponse(
            id=doc.id,
            kind=doc.kind,
            title=doc.title,
            subtitle=doc.subtitle,
            body=doc.body or None,
            route=doc.route,
            loaded=doc.loaded,
        ),
        score=result.score,
        matched_tokens=result.matched_tokens,
    )


def _to_section_response(section: SearchResultSection) -> SearchSectionResponse:
    """Convert a :class:`SearchResultSection` to its JSON response shape."""
    return SearchSectionResponse(
        label=section.label,
        results=tuple(_to_document_response(r) for r in section.results),
    )


@router.get(
    "/editor/search",
    response_model=SearchResponse,
    summary="Search across concept schemes and concepts",
    description=(
        "Returns ranked, sectioned search results for the editorv2 "
        "Cmd+K palette. Each call rebuilds an in-memory index from "
        "the current database state; scheme ids passed via the "
        "'loaded' query parameter are boosted into the 'Loaded' "
        "section so active workspace items rank first."
    ),
)
async def editor_search(
    q: str = Query(..., description="Free-form search query."),
    limit: int = Query(
        default=20,
        ge=1,
        le=100,
        description="Maximum total number of results.",
    ),
    loaded: list[str] = Query(
        default=[],
        description="Scheme ids currently loaded in the user's workspace.",
    ),
    session: Session = Depends(get_db_session),
) -> SearchResponse:
    """Return sectioned search results for the Cmd+K palette."""
    try:
        source = SqlAlchemySearchCatalogSource(
            session,
            loaded_scheme_ids=frozenset(loaded),
        )
        service = SearchService(source)
        sections = service.query(q, limit=limit)
    except Exception as exc:  # pragma: no cover - defensive
        logger.exception("editor search failed")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"search failed: {exc}",
        )
    return SearchResponse(
        query=q,
        sections=tuple(_to_section_response(s) for s in sections),
    )
