# TODO(maintainability): This file is 478 lines (limit: 400). Split into smaller modules.
"""Route handlers for settings and configuration testing."""

from __future__ import annotations

import logging
from typing import Annotated, Any

from fastapi import APIRouter, Body, Depends, HTTPException, status

logger = logging.getLogger(__name__)

from pydantic import BaseModel, Field
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from pycharter import __version__ as pycharter_version
from pycharter.api._http_errors import raise_logged_bad_request
from pycharter.api.dependencies.auth import require_admin
from pycharter.api.dependencies.database import get_db_session
from pycharter.api.services.server_config_editor import (
    apply_server_config_patch,
    get_server_config_bundle,
)
from pycharter.api.services.settings_service import (
    ConnectionBuildError,
    build_connection_string,
    get_app_config,
    get_database_config,
    get_dlq_stats,
    get_notification_config,
    get_quality_config,
    send_test_notification,
    test_database_connection,
    test_dlq_connection,
    update_notification_config,
    update_quality_config,
)
from pycharter.config import (
    get_api_url,
    get_database_url,
    get_ui_app_name,
    get_ui_theme,
)
from pycharter.config.auth import get_auth_service_url, is_auth_disabled

# Public router: no auth (so UI can load theme before login)
public_router = APIRouter(tags=["Settings"])


# ---------------------------------------------------------------------------
# Response / request models
# ---------------------------------------------------------------------------


class ServerConfigPatchRequest(BaseModel):
    """Body for PATCH ``/settings/server-config``."""

    values: dict[str, Any]


class AppConfigResponse(BaseModel):
    """App config for UI (theme, app name, release version)."""

    theme: str
    app_name: str
    version: str = ""


class DatabaseConfigResponse(BaseModel):
    """Response model for database configuration info."""

    configured_url: str | None
    actual_url: str
    database_type: str
    is_default: bool
    contract_count: int
    message: str


class DatabaseTestRequest(BaseModel):
    """Request model for database connection testing."""

    connection_string: str | None = None
    host: str | None = None
    port: int | None = None
    database: str | None = None
    username: str | None = None
    password: str | None = None


class DatabaseTestResponse(BaseModel):
    """Response model for database connection test result."""

    success: bool
    message: str


class DlqTestRequest(BaseModel):
    """Request model for DLQ connection testing."""

    connection_string: str | None = None
    host: str | None = None
    port: int | None = None
    database: str | None = None
    username: str | None = None
    password: str | None = None
    table_name: str | None = None


class DlqTestResponse(BaseModel):
    """Response model for DLQ connection test result."""

    success: bool
    message: str


class DlqStatsRequest(BaseModel):
    """Request model for DLQ statistics."""

    connection_string: str | None = None
    host: str | None = None
    port: int | None = None
    database: str | None = None
    username: str | None = None
    password: str | None = None
    table_name: str | None = None


class DlqStatsResponse(BaseModel):
    """Response model for DLQ statistics."""

    total_messages: int
    by_reason: dict[str, int | None] = Field(default_factory=dict)
    by_stage: dict[str, int | None] = Field(default_factory=dict)
    by_status: dict[str, int | None] = Field(default_factory=dict)


class QualityConfigResponse(BaseModel):
    """Quality monitoring configuration."""

    default_check_preset: str = "basic"
    metric_retention_days: int = 90
    scoring_weights: dict[str, float] = Field(default_factory=dict)
    data_sources: list[dict[str, Any]] = Field(default_factory=list)


class NotificationConfigResponse(BaseModel):
    """Notification settings."""

    enabled: bool = False
    channels: dict[str, Any] = Field(default_factory=dict)
    alert_rules: dict[str, bool] = Field(default_factory=dict)
    frequency: str = "immediate"


# ---------------------------------------------------------------------------
# Public (no auth) routes
# ---------------------------------------------------------------------------


@public_router.get(
    "/settings/app-config",
    response_model=AppConfigResponse,
    status_code=status.HTTP_200_OK,
    summary="Get app config (theme, app name, version) for UI",
    description="Returns UI theme (light, dark, system), app name, and release version. No auth required.",
)
async def get_app_config_route() -> AppConfigResponse:
    """Return application configuration for the UI."""
    cfg = get_app_config()
    return AppConfigResponse(
        theme=cfg.theme, app_name=cfg.app_name, version=cfg.version
    )


def _auth_mode_summary() -> str:
    if is_auth_disabled():
        return "open_no_login"
    if get_auth_service_url():
        return "external_oidc"
    return "builtin_jwt"


def _mask_database_url(url: str | None) -> str | None:
    if not url or "@" not in url:
        return url
    parts = url.split("@", 1)
    if ":" in parts[0] and "://" in parts[0]:
        user_pass = parts[0].split("://", 1)[1]
        if ":" in user_pass:
            user, _ = user_pass.split(":", 1)
            return parts[0].split("://", 1)[0] + "://" + user + ":****@" + parts[1]
    return url


def _database_driver_kind(url: str | None) -> str:
    if not url or not url.strip():
        return "sqlite_default"
    u = url.strip().lower()
    if u.startswith("sqlite"):
        return "sqlite"
    if u.startswith(("postgresql", "postgres")):
        return "postgresql"
    if u.startswith("mysql"):
        return "mysql"
    return "other"


@public_router.get(
    "/settings/runtime-overview",
    status_code=status.HTTP_200_OK,
    summary="Server runtime configuration (masked, no secrets)",
    description=(
        "Effective values for the UI overview table. No auth. "
        "URLs are masked; env overrides pycharter.cfg."
    ),
)
async def get_runtime_overview() -> dict[str, Any]:
    raw_db = get_database_url()
    return {
        "version": pycharter_version or "",
        "app_name": get_ui_app_name(),
        "ui_theme": get_ui_theme(),
        "api_url": get_api_url(),
        "auth_disabled": is_auth_disabled(),
        "auth_mode": _auth_mode_summary(),
        "database": {
            "configured_url_masked": _mask_database_url(raw_db) or "(default sqlite)",
            "driver_kind": _database_driver_kind(raw_db),
        },
    }


# ---------------------------------------------------------------------------
# Protected routes
# ---------------------------------------------------------------------------

router = APIRouter(tags=["Settings"])


@router.get(
    "/settings/server-config",
    status_code=status.HTTP_200_OK,
    summary="Server config table (admin): edit metadata and file values",
    description=(
        "Rows for editable pycharter.cfg in the settings UI. Admin only. "
        "May include raw database URLs from file when set."
    ),
)
async def get_server_config(
    _admin: Annotated[dict, Depends(require_admin)],
) -> dict[str, Any]:
    return get_server_config_bundle()


@router.patch(
    "/settings/server-config",
    status_code=status.HTTP_200_OK,
    summary="Update pycharter.cfg (admin)",
    description=(
        "Writes allow-listed PYCHARTER_* keys. Env still overrides at runtime; "
        "restart may be required."
    ),
)
async def patch_server_config(
    body: ServerConfigPatchRequest,
    _admin: Annotated[dict, Depends(require_admin)],
) -> dict[str, Any]:
    try:
        path, keys = apply_server_config_patch(body.values)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Invalid server config patch (unknown PYCHARTER_* key, "
                "value out of range, or unsupported type)"
            ),
        )
    return {
        "written_path": str(path),
        "keys_written": keys,
        "detail": f"Updated {len(keys)} key(s) in {path}",
    }


@router.get(
    "/settings/database-config",
    response_model=DatabaseConfigResponse,
    status_code=status.HTTP_200_OK,
    summary="Get current database configuration",
    description="Get information about the currently configured database connection",
)
async def get_database_config_route(
    db: Session = Depends(get_db_session),
) -> DatabaseConfigResponse:
    """Return current database configuration and connection info."""
    cfg = get_database_config(db)
    return DatabaseConfigResponse(
        configured_url=cfg.configured_url,
        actual_url=cfg.actual_url,
        database_type=cfg.database_type,
        is_default=cfg.is_default,
        contract_count=cfg.contract_count,
        message=cfg.message,
    )


@router.post(
    "/settings/test-database",
    response_model=DatabaseTestResponse,
    status_code=status.HTTP_200_OK,
    summary="Test database connection",
    description="Test a database connection using provided credentials",
)
async def test_database(request: DatabaseTestRequest) -> DatabaseTestResponse:
    """Test a database connection."""
    try:
        conn_str = build_connection_string(
            connection_string=request.connection_string,
            host=request.host,
            port=request.port,
            database=request.database,
            username=request.username,
            password=request.password,
        )
    except ConnectionBuildError as exc:
        raise_logged_bad_request(
            logger,
            exc,
            public_detail=(
                "Failed to build database connection string (missing "
                "host/database, invalid port, or malformed connection_string)"
            ),
            log_event="test_database_connection_build_failed",
        )

    result = test_database_connection(conn_str)
    return DatabaseTestResponse(success=result.success, message=result.message)


@router.post(
    "/settings/test-dlq",
    response_model=DlqTestResponse,
    status_code=status.HTTP_200_OK,
    summary="Test DLQ connection",
    description="Test a DLQ (Dead Letter Queue) database connection and verify table exists",
)
async def test_dlq(request: DlqTestRequest) -> DlqTestResponse:
    """Test DLQ connection and table existence."""
    try:
        conn_str = build_connection_string(
            connection_string=request.connection_string,
            host=request.host,
            port=request.port,
            database=request.database,
            username=request.username,
            password=request.password,
        )
    except ConnectionBuildError as exc:
        raise_logged_bad_request(
            logger,
            exc,
            public_detail=(
                "Failed to build DLQ connection string (missing host/database, "
                "invalid port, or malformed connection_string)"
            ),
            log_event="test_dlq_connection_build_failed",
        )

    if not request.table_name:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="table_name is required",
        )

    result = test_dlq_connection(conn_str, request.table_name)
    return DlqTestResponse(success=result.success, message=result.message)


@router.post(
    "/settings/dlq-stats",
    response_model=DlqStatsResponse,
    status_code=status.HTTP_200_OK,
    summary="Get DLQ statistics",
    description="Get statistics from the DLQ table grouped by reason, stage, and status",
)
async def get_dlq_stats_route(request: DlqStatsRequest) -> DlqStatsResponse:
    """Get DLQ statistics."""
    try:
        conn_str = build_connection_string(
            connection_string=request.connection_string,
            host=request.host,
            port=request.port,
            database=request.database,
            username=request.username,
            password=request.password,
        )
    except ConnectionBuildError as exc:
        raise_logged_bad_request(
            logger,
            exc,
            public_detail=(
                "Failed to build DLQ connection string for stats query "
                "(missing host/database, invalid port, or malformed "
                "connection_string)"
            ),
            log_event="dlq_stats_connection_build_failed",
        )

    if not request.table_name:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="table_name is required",
        )

    try:
        stats = get_dlq_stats(conn_str, request.table_name)
    except SQLAlchemyError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Database error: {exc}",
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Unexpected error: {exc}",
        )

    return DlqStatsResponse(
        total_messages=stats.total_messages,
        by_reason=stats.by_reason,
        by_stage=stats.by_stage,
        by_status=stats.by_status,
    )


# ---------------------------------------------------------------------------
# Quality configuration
# ---------------------------------------------------------------------------


@router.get(
    "/settings/quality",
    status_code=status.HTTP_200_OK,
    summary="Get quality monitoring configuration",
    description="Retrieve quality monitoring defaults and scoring configuration.",
)
async def get_quality_config_route() -> dict[str, Any]:
    """Get quality monitoring configuration."""
    return get_quality_config()


@router.put(
    "/settings/quality",
    status_code=status.HTTP_200_OK,
    summary="Update quality monitoring configuration",
    description="Update quality monitoring defaults and scoring configuration.",
)
async def update_quality_config_route(
    config: dict[str, Any] = Body(...),
) -> dict[str, Any]:
    """Update quality monitoring configuration."""
    return update_quality_config(config)


# ---------------------------------------------------------------------------
# Notification configuration
# ---------------------------------------------------------------------------


@router.get(
    "/settings/notifications",
    status_code=status.HTTP_200_OK,
    summary="Get notification settings",
    description="Retrieve notification and alerting configuration.",
)
async def get_notification_config_route() -> dict[str, Any]:
    """Get notification settings."""
    return get_notification_config()


@router.put(
    "/settings/notifications",
    status_code=status.HTTP_200_OK,
    summary="Update notification settings",
    description="Update notification and alerting configuration.",
)
async def update_notification_config_route(
    config: dict[str, Any] = Body(...),
) -> dict[str, Any]:
    """Update notification settings."""
    return update_notification_config(config)


@router.post(
    "/settings/notifications/test",
    status_code=status.HTTP_200_OK,
    summary="Send a test notification",
    description="Send a test notification using the current notification settings.",
)
async def test_notification(
    channel: str = Body("email", embed=True),
) -> dict[str, Any]:
    """Send a test notification."""
    return send_test_notification(channel)
