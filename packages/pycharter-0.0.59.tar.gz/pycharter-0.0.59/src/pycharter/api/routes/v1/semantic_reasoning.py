"""OWL-RL reasoner HTTP route.

Exposes :class:`pycharter.semantic.reasoning.ConceptGraphReasoner` so UIs
(pycharter's editor, pygubernator's KB browser) and downstream
services can query the closure without running owlrl in-process.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from pycharter.api._http_errors import (
    raise_logged_service_unavailable,
)
from pycharter.api.dependencies.semantic_store import get_semantic_store
from pycharter.semantic.reasoning import (
    ConceptGraphReasoner,
    ReasonerNotReadyError,
)
from pycharter.semantic_store.client import SemanticStoreClient

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Semantic - Reasoning"])


class InferredRelationship(BaseModel):
    """Serialised :class:`pycharter.semantic.reasoning.InferredEdge`."""

    source_id: str
    target_id: str
    relationship_type: str
    inferred: bool


class ReasoningResponse(BaseModel):
    """Response body for GET /semantic/reasoning/{concept_id}."""

    concept_id: str
    items: list[InferredRelationship]


@router.get("/{concept_id}", response_model=ReasoningResponse)
def inferred_relationships(
    concept_id: str,
    direction: str = Query(
        default="both",
        description="One of 'outgoing', 'incoming', 'both'.",
    ),
    types: str | None = Query(
        default=None,
        description="Comma-separated relationship types to restrict to.",
    ),
    only_inferred: bool = Query(
        default=False,
        description="When true, drop stated edges from the result.",
    ),
    store: SemanticStoreClient = Depends(get_semantic_store),
) -> ReasoningResponse:
    """Return stated + inferred edges touching ``concept_id``.

    The reasoner is instantiated per-request; the closure cache is
    process-local and warms automatically. A ``ReasonerNotReadyError``
    bubbles up as HTTP 503 so callers can render a graceful fallback.
    """
    if direction not in {"outgoing", "incoming", "both"}:
        raise HTTPException(
            status_code=400,
            detail="direction must be one of 'outgoing', 'incoming', 'both'.",
        )
    type_tuple: tuple[str, ...] | None = (
        tuple(t.strip() for t in types.split(",") if t.strip()) if types else None
    )
    reasoner = ConceptGraphReasoner(store)
    try:
        edges = reasoner.inferred_relationships(
            of=concept_id,
            direction=direction,
            types=type_tuple,
            only_inferred=only_inferred,
        )
    except ReasonerNotReadyError as exc:
        logger.warning("reasoner unavailable: %s", exc)
        raise_logged_service_unavailable(
            logger, exc, public_detail="Service unavailable", log_event="route failed"
        )

    items = [
        InferredRelationship(
            source_id=edge.source_name,
            target_id=edge.target_name,
            relationship_type=edge.relationship_type,
            inferred=edge.inferred,
        )
        for edge in edges
    ]
    return ReasoningResponse(concept_id=concept_id, items=items)
