"""Concept extraction run endpoint.

Runs a registered :class:`ConceptExtractionPlugin` against a single
source file and materialises the candidate concepts + relations into
the target scheme. Synchronous for M3; a future milestone will
promote long-running multi-file runs onto the worker queue.
"""

from __future__ import annotations

import logging
import uuid as uuid_mod
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from pycharter.api.dependencies import get_db_session
from pycharter.semantic.extraction import (
    ExtractionMaterializer,
    create_default_registry,
)
from pycharter.semantic.extraction._materializer import MaterializeMode

router = APIRouter(tags=["Semantic - Extraction"])
logger = logging.getLogger(__name__)


class ExtractionRunRequest(BaseModel):
    """Request body for ``POST /api/v1/semantic/extraction/runs``."""

    scheme_id: str = Field(
        ...,
        description="UUID or scheme_key of the target concept scheme.",
    )
    source_path: str = Field(
        ...,
        description="Absolute path to the source file to extract from.",
    )
    plugin: str | None = Field(
        default=None,
        description=(
            "Explicit plugin name (e.g. 'tree_sitter.python'). If omitted, "
            "the first plugin whose can_handle() matches is used."
        ),
    )
    actor: str | None = Field(
        default=None,
        description="Audit tag written to created_by; defaults to 'extractor:<plugin_name>'.",
    )
    mode: MaterializeMode = Field(
        default="suggestion",
        description=(
            "Where to write candidates. 'suggestion' (default) routes to "
            "the governed queue at /api/v1/semantic/suggestions; 'direct' "
            "writes straight to the ontology tables and is reserved for "
            "migration / internal callers that own governance themselves."
        ),
    )


@router.post("/runs")
async def create_extraction_run(
    request: ExtractionRunRequest,
    session=Depends(get_db_session),
) -> dict[str, Any]:
    """Run extraction synchronously and return the materialization summary.

    Raises:
        404 if the scheme or source file does not exist.
        422 if no plugin can handle the source (or named plugin is missing).
    """
    scheme_uuid = _resolve_scheme_id(session, request.scheme_id)
    source_file = Path(request.source_path)
    if not source_file.is_file():
        raise HTTPException(
            status_code=404,
            detail=f"Source file not found: {request.source_path}",
        )

    registry = create_default_registry()
    if request.plugin is not None:
        try:
            plugin = registry.get(request.plugin)
        except KeyError as exc:
            raise HTTPException(
                status_code=422,
                detail=(
                    f"Plugin '{request.plugin}' not registered. "
                    f"Available: {list(registry.names())}"
                ),
            ) from exc
    else:
        plugin = registry.for_source(str(source_file))
        if plugin is None:
            raise HTTPException(
                status_code=422,
                detail=(
                    f"No plugin can handle source '{request.source_path}'. "
                    f"Available: {list(registry.names())}"
                ),
            )

    logger.info(
        "extraction run: plugin=%s source=%s scheme=%s",
        plugin.name,
        request.source_path,
        scheme_uuid,
    )
    result = plugin.extract(str(source_file))
    materializer = ExtractionMaterializer(session=session)
    summary = materializer.materialize(
        result,
        scheme_id=scheme_uuid,
        actor=request.actor,
        mode=request.mode,
    )
    session.commit()
    return {
        "plugin": plugin.name,
        "scheme_id": scheme_uuid,
        "run": summary.to_dict(),
    }


def _resolve_scheme_id(session, scheme_id: str) -> str:
    """Resolve a scheme_key to its UUID, or pass a UUID through unchanged.

    The materializer is UUID-only. Accept human-friendly scheme_key as a
    convenience; detect the UUID form before filtering so the UUID column
    type never sees a non-UUID string.
    """
    from pycharter.db.models.semantic.concept_scheme import ConceptSchemeModel

    try:
        uuid_mod.UUID(scheme_id)
        filter_clause = ConceptSchemeModel.id == scheme_id
    except (ValueError, AttributeError):
        filter_clause = ConceptSchemeModel.scheme_key == scheme_id

    row = session.query(ConceptSchemeModel).filter(filter_clause).first()
    if row is None:
        raise HTTPException(status_code=404, detail=f"Scheme not found: {scheme_id}")
    return str(row.id)
