"""SHACL governance validation route.

Exposes ``POST /semantic/governance/validate`` so callers (UIs, pipeline
hooks, CI checks) can ask the server "does my concept graph still meet
the shapes we govern it with?" without embedding pyshacl in the client.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from pycharter.api._http_errors import raise_logged_bad_request
from pycharter.api.dependencies.semantic_store import get_semantic_store
from pycharter.semantic.governance import (
    GovernanceError,
    GovernanceValidator,
)
from pycharter.semantic.shared.results import ShapeViolation, ValidationReport
from pycharter.semantic_store.client import SemanticStoreClient

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Semantic - Governance"])


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class GovernanceValidateRequest(BaseModel):
    """Request body for POST /semantic/governance/validate."""

    scheme_key: str | None = Field(
        default=None,
        description="Restrict validation to a single concept scheme.",
    )
    extra_shapes_ttl: str | None = Field(
        default=None,
        description=(
            "Optional Turtle text holding additional SHACL shapes to "
            "merge with the bundled shapes."
        ),
    )


class ShapeViolationResponse(BaseModel):
    """Serialised :class:`ShapeViolation`."""

    focus_node: str
    path: str
    value: str | None
    shape: str
    severity: str
    message: str

    @classmethod
    def from_violation(cls, violation: ShapeViolation) -> ShapeViolationResponse:
        """Build a response shape from a domain :class:`ShapeViolation`."""
        return cls(
            focus_node=violation.focus_node,
            path=violation.path,
            value=violation.value,
            shape=violation.shape,
            severity=violation.severity,
            message=violation.message,
        )


class GovernanceValidateResponse(BaseModel):
    """Response body for POST /semantic/governance/validate."""

    conforms: bool
    error_count: int
    warning_count: int
    info_count: int
    violations: list[ShapeViolationResponse]

    @classmethod
    def from_report(cls, report: ValidationReport) -> GovernanceValidateResponse:
        """Build a response shape from a domain :class:`ValidationReport`."""
        return cls(
            conforms=report.conforms,
            error_count=report.error_count,
            warning_count=report.warning_count,
            info_count=report.info_count,
            violations=[
                ShapeViolationResponse.from_violation(v) for v in report.violations
            ],
        )


# ---------------------------------------------------------------------------
# Route
# ---------------------------------------------------------------------------


@router.post("/validate", response_model=GovernanceValidateResponse)
def validate_governance(
    request: GovernanceValidateRequest,
    store: SemanticStoreClient = Depends(get_semantic_store),
) -> GovernanceValidateResponse:
    """Run SHACL validation over the concept graph.

    Returns a structured report with per-violation severity, path, and
    message so the caller can render a UI or fail a CI step.
    """
    try:
        validator = GovernanceValidator(
            extra_shapes_ttl=request.extra_shapes_ttl,
        )
        report = validator.validate(store, scheme_key=request.scheme_key)
    except GovernanceError as exc:
        logger.warning("governance validation configuration error: %s", exc)
        raise_logged_bad_request(
            logger,
            exc,
            public_detail=(
                "Governance validation failed (invalid SHACL shapes, "
                "unknown scheme_key, or store unavailable)"
            ),
            log_event="governance_validate_failed",
        )

    return GovernanceValidateResponse.from_report(report)
