"""FastAPI routes for editorv2 draft artifacts.

CRUD plus a /promote endpoint. The actor identity comes from the
``X-User-Id`` header (placeholder for the project's auth layer; the
existing get_current_user dependency can be wired in once the
editorv2 surface area lines up with the rest of the API).
"""

from __future__ import annotations

import logging
from collections.abc import Iterable

from fastapi import APIRouter, Depends, Header, HTTPException, status
from sqlalchemy.orm import Session

from pycharter.api._http_errors import (
    raise_logged_bad_request,
    raise_logged_forbidden,
    raise_logged_not_found,
)
from pycharter.api.dependencies.database import get_db_session
from pycharter.api.models.drafts import (
    DraftCreateRequest,
    DraftListItem,
    DraftListResponse,
    DraftPromoteRequest,
    DraftResponse,
    DraftUpdateRequest,
)
from pycharter.persistence.drafts.sqlalchemy_repository import (
    SqlAlchemyDraftRepository,
)
from pycharter.semantic.drafts.models import DraftConfig
from pycharter.semantic.drafts.service import (
    DraftActor,
    DraftNotFoundError,
    DraftPermissionError,
    DraftService,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Editor Drafts"])


def _service(session: Session) -> DraftService:
    """Construct a DraftService over the SQLAlchemy repository."""
    return DraftService(SqlAlchemyDraftRepository(session))


def _actor_from_headers(
    user_id: str | None,
    teams: str | None,
) -> DraftActor:
    """Build a DraftActor from request headers."""
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="X-User-Id header required for drafts endpoints",
        )
    team_ids = (
        frozenset(t.strip() for t in teams.split(",") if t.strip())
        if teams
        else frozenset()
    )
    return DraftActor(user_id=user_id, team_ids=team_ids)


def _to_response(draft: DraftConfig) -> DraftResponse:
    """Convert a DraftConfig to its REST response shape."""
    return DraftResponse(
        id=draft.id,
        name=draft.name,
        namespace=draft.namespace,
        description=draft.description,
        source_type=draft.source_type,
        source_payload=draft.source_payload,
        parsed_yaml=draft.parsed_yaml,
        visibility=draft.visibility,
        owner_id=draft.owner_id,
        team_id=draft.team_id,
        created_at=draft.created_at,
        updated_at=draft.updated_at,
        promotions=draft.promotions,
    )


def _to_list_items(drafts: Iterable[DraftConfig]) -> tuple[DraftListItem, ...]:
    """Convert DraftConfigs to lightweight list rows."""
    return tuple(
        DraftListItem(
            id=draft.id,
            name=draft.name,
            namespace=draft.namespace,
            description=draft.description,
            source_type=draft.source_type,
            visibility=draft.visibility,
            owner_id=draft.owner_id,
            team_id=draft.team_id,
            created_at=draft.created_at,
            updated_at=draft.updated_at,
            is_archived=draft.is_archived(),
        )
        for draft in drafts
    )


@router.get(
    "/editor/drafts",
    response_model=DraftListResponse,
    summary="List drafts visible to the actor",
)
async def list_drafts(
    x_user_id: str | None = Header(default=None, alias="X-User-Id"),
    x_teams: str | None = Header(default=None, alias="X-Teams"),
    session: Session = Depends(get_db_session),
) -> DraftListResponse:
    """Return drafts the calling user can see."""
    actor = _actor_from_headers(x_user_id, x_teams)
    service = _service(session)
    drafts = service.list(actor)
    items = _to_list_items(drafts)
    return DraftListResponse(drafts=items, total=len(items))


@router.get(
    "/editor/drafts/{draft_id}",
    response_model=DraftResponse,
    summary="Fetch one draft by id",
)
async def get_draft(
    draft_id: str,
    x_user_id: str | None = Header(default=None, alias="X-User-Id"),
    x_teams: str | None = Header(default=None, alias="X-Teams"),
    session: Session = Depends(get_db_session),
) -> DraftResponse:
    """Return a single draft if the actor can see it."""
    actor = _actor_from_headers(x_user_id, x_teams)
    service = _service(session)
    try:
        draft = service.get(draft_id, actor)
    except DraftNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Draft {draft_id!r} not found",
        )
    except DraftPermissionError:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"You do not have permission to view draft {draft_id!r}",
        )
    return _to_response(draft)


@router.post(
    "/editor/drafts",
    response_model=DraftResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new draft",
)
async def create_draft(
    body: DraftCreateRequest,
    x_user_id: str | None = Header(default=None, alias="X-User-Id"),
    x_teams: str | None = Header(default=None, alias="X-Teams"),
    session: Session = Depends(get_db_session),
) -> DraftResponse:
    """Create a draft owned by the calling user."""
    actor = _actor_from_headers(x_user_id, x_teams)
    service = _service(session)
    try:
        draft = service.create(
            actor=actor,
            name=body.name,
            namespace=body.namespace,
            description=body.description,
            source_type=body.source_type,
            source_payload=body.source_payload,
            parsed_yaml=body.parsed_yaml,
            visibility=body.visibility,
            team_id=body.team_id,
        )
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Invalid draft payload (missing required fields, "
                "unsupported source type, or invalid visibility/team)"
            ),
        )
    session.commit()
    return _to_response(draft)


@router.patch(
    "/editor/drafts/{draft_id}",
    response_model=DraftResponse,
    summary="Update fields on a draft",
)
async def update_draft(
    draft_id: str,
    body: DraftUpdateRequest,
    x_user_id: str | None = Header(default=None, alias="X-User-Id"),
    x_teams: str | None = Header(default=None, alias="X-Teams"),
    session: Session = Depends(get_db_session),
) -> DraftResponse:
    """Update an existing draft. Only the owner can edit."""
    actor = _actor_from_headers(x_user_id, x_teams)
    service = _service(session)
    updates = {
        key: value
        for key, value in body.model_dump(exclude_unset=True).items()
        if value is not None or key in {"description", "namespace", "team_id"}
    }
    try:
        draft = service.update(draft_id, actor, updates=updates)
    except DraftNotFoundError as exc:
        raise_logged_not_found(
            logger,
            exc,
            public_detail=f"Draft {draft_id!r} not found",
            log_event="update_draft_not_found",
        )
    except DraftPermissionError as exc:
        raise_logged_forbidden(
            logger,
            exc,
            public_detail=f"You do not have permission to update draft {draft_id!r}",
            log_event="update_draft_forbidden",
        )
    except ValueError as exc:
        raise_logged_bad_request(
            logger,
            exc,
            public_detail=(
                "Invalid draft update (unsupported field, invalid value, "
                "or conflicting state)"
            ),
            log_event="update_draft_invalid",
        )
    session.commit()
    return _to_response(draft)


@router.delete(
    "/editor/drafts/{draft_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a draft",
)
async def delete_draft(
    draft_id: str,
    x_user_id: str | None = Header(default=None, alias="X-User-Id"),
    x_teams: str | None = Header(default=None, alias="X-Teams"),
    session: Session = Depends(get_db_session),
) -> None:
    """Delete a draft. Only the owner can delete."""
    actor = _actor_from_headers(x_user_id, x_teams)
    service = _service(session)
    try:
        service.delete(draft_id, actor)
    except DraftNotFoundError as exc:
        raise_logged_not_found(
            logger,
            exc,
            public_detail=f"Draft {draft_id!r} not found",
            log_event="delete_draft_not_found",
        )
    except DraftPermissionError as exc:
        raise_logged_forbidden(
            logger,
            exc,
            public_detail=f"You do not have permission to delete draft {draft_id!r}",
            log_event="delete_draft_forbidden",
        )
    session.commit()


@router.post(
    "/editor/drafts/{draft_id}/promote",
    response_model=DraftResponse,
    summary="Record a promotion event on a draft",
)
async def promote_draft(
    draft_id: str,
    body: DraftPromoteRequest,
    x_user_id: str | None = Header(default=None, alias="X-User-Id"),
    x_teams: str | None = Header(default=None, alias="X-Teams"),
    session: Session = Depends(get_db_session),
) -> DraftResponse:
    """Append a promotion event to a draft and return the new state."""
    actor = _actor_from_headers(x_user_id, x_teams)
    service = _service(session)
    try:
        draft = service.promote(draft_id, actor, kind=body.kind, ref=body.ref)
    except DraftNotFoundError as exc:
        raise_logged_not_found(
            logger,
            exc,
            public_detail=f"Draft {draft_id!r} not found",
            log_event="promote_draft_not_found",
        )
    except DraftPermissionError as exc:
        raise_logged_forbidden(
            logger,
            exc,
            public_detail=f"You do not have permission to promote draft {draft_id!r}",
            log_event="promote_draft_forbidden",
        )
    except ValueError as exc:
        raise_logged_bad_request(
            logger,
            exc,
            public_detail=(
                "Failed to promote draft (invalid promotion kind, missing ref, "
                "or draft not in a promotable state)"
            ),
            log_event="promote_draft_invalid",
        )
    session.commit()
    return _to_response(draft)
