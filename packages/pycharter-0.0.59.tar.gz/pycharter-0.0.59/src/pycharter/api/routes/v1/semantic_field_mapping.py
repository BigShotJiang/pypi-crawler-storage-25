"""Field mapping API routes."""

from __future__ import annotations

import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException

logger = logging.getLogger(__name__)

from pycharter.api._http_errors import raise_logged_bad_request
from pycharter.api.dependencies import get_db_session
from pycharter.api.dependencies.store import get_contract_store
from pycharter.api.models.semantic_field_mapping import (
    FieldMappingParseRequest,
    FieldMappingResponse,
    FieldMappingValidateRequest,
    FieldMappingValidateResponse,
    SemanticHealthResponse,
)
from pycharter.contract_store import ContractStoreClient
from pycharter.db.models.data_contract import DataContractModel
from pycharter.db.models.semantic.concept import ConceptModel
from pycharter.semantic.knowledge.semantic_health import calculate_semantic_health
from pycharter.semantic.ontology.parser import parse_field_mapping
from pycharter.semantic.ontology.validator import validate_field_mapping_payload
from pycharter.semantic.shared.errors import OntologyError

router = APIRouter(tags=["Semantic"])


@router.post("/parse", response_model=FieldMappingResponse)
async def parse_field_mapping_endpoint(request: FieldMappingParseRequest):
    """Parse field mapping data and return structured result."""
    try:
        artifact = parse_field_mapping(request.data)
        return FieldMappingResponse(
            version=artifact.version,
            field_bindings={
                name: fb.to_dict() for name, fb in artifact.field_bindings.items()
            },
        )
    except OntologyError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail=(
                "Failed to parse field mapping (malformed payload, "
                "missing required fields, or invalid binding format)"
            ),
            log_event="parse_field_mapping_failed",
        )


@router.post("/validate", response_model=FieldMappingValidateResponse)
async def validate_field_mapping_endpoint(request: FieldMappingValidateRequest):
    """Validate field mapping data and return errors."""
    errors = validate_field_mapping_payload(request.data)
    return FieldMappingValidateResponse(valid=len(errors) == 0, errors=errors)


def _compute_semantic_health_for_contract(
    contract: DataContractModel,
    session,
    store: ContractStoreClient,
) -> SemanticHealthResponse:
    field_mapping = store.get_field_mapping(contract.name, contract.version)
    concept_rows = session.query(
        ConceptModel.concept_key, ConceptModel.name, ConceptModel.deprecated
    ).all()
    known_concepts = {
        (concept_key or name)
        for concept_key, name, _deprecated in concept_rows
        if (concept_key or name)
    }
    deprecated_concepts = {
        (concept_key or name)
        for concept_key, name, deprecated in concept_rows
        if deprecated and (concept_key or name)
    }

    health = calculate_semantic_health(
        schema=dict(contract.schema.schema_data),
        field_mapping=field_mapping,
        known_concepts=known_concepts,
        deprecated_concepts=deprecated_concepts,
    )
    return SemanticHealthResponse(
        contract_id=str(contract.id),
        contract_name=contract.name,
        contract_version=contract.version,
        **health,
    )


@router.get(
    "/contracts/{contract_id}/semantic-health",
    response_model=SemanticHealthResponse,
)
async def contract_semantic_health(
    contract_id: str,
    session=Depends(get_db_session),
    store: ContractStoreClient = Depends(get_contract_store),
):
    """Compute semantic health for one contract (warn-only in v1)."""
    try:
        contract_uuid = uuid.UUID(contract_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid contract_id UUID")

    contract = (
        session.query(DataContractModel)
        .filter(DataContractModel.id == contract_uuid)
        .first()
    )
    if contract is None:
        raise HTTPException(status_code=404, detail="Contract not found")
    if contract.schema is None or not contract.schema.schema_data:
        raise HTTPException(status_code=404, detail="Contract schema not found")

    return _compute_semantic_health_for_contract(contract, session, store)


@router.get(
    "/contracts/by-name/{contract_name}/{contract_version}/semantic-health",
    response_model=SemanticHealthResponse,
)
async def contract_semantic_health_by_name(
    contract_name: str,
    contract_version: str,
    session=Depends(get_db_session),
    store: ContractStoreClient = Depends(get_contract_store),
):
    """Compute semantic health by contract name and version."""
    contract = (
        session.query(DataContractModel)
        .filter(
            DataContractModel.name == contract_name,
            DataContractModel.version == contract_version,
        )
        .first()
    )
    if contract is None:
        raise HTTPException(status_code=404, detail="Contract not found")
    if contract.schema is None or not contract.schema.schema_data:
        raise HTTPException(status_code=404, detail="Contract schema not found")
    return _compute_semantic_health_for_contract(contract, session, store)
