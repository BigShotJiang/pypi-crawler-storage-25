"""Provenance + grown-by lookups — the data that feeds M8 UI cross-links.

Three endpoints, all read-only:

- ``GET /api/v1/semantic/provenance/concepts/{id}/origin`` — the origin
  + full provenance + acceptance trail for a single concept. Used by
  the "Where this came from" panel on the concept detail page.
- ``GET /api/v1/semantic/provenance/contracts/{id}/grown`` — every
  concept + pending/accepted suggestion whose provenance points back at
  this contract. Feeds the "Proposed from this contract" + "Used by
  pipelines" sections on the contract editor.
- ``GET /api/v1/semantic/provenance/pipelines/{id}/grown`` — every
  concept + suggestion grown from a run of this pipeline. Source_uri
  matches the ``pipeline_run://{pipeline_id}#...`` convention used by
  the record-content extractor.

All matches use the concept or suggestion ``source_uri`` + provenance
dict. No new persistence is required — the M7 ``SuggestionModel`` +
``ConceptModel.provenance`` already carry everything needed.
"""

from __future__ import annotations

import uuid as uuid_mod

from fastapi import APIRouter, Depends, HTTPException

from pycharter.api.dependencies import get_db_session
from pycharter.api.models.semantic_provenance import (
    ConceptOriginResponse,
    GrownEntry,
    GrownResponse,
)
from pycharter.db.models.semantic.concept import ConceptModel
from pycharter.db.models.semantic.suggestion import SuggestionModel

router = APIRouter(tags=["Semantic - Provenance"])


@router.get(
    "/concepts/{concept_id}/origin",
    response_model=ConceptOriginResponse,
)
async def concept_origin(
    concept_id: str,
    session=Depends(get_db_session),
) -> ConceptOriginResponse:
    """Return origin + provenance + acceptance trail for a concept."""
    _validate_uuid(concept_id)
    concept = (
        session.query(ConceptModel)
        .filter(ConceptModel.id == uuid_mod.UUID(concept_id))
        .first()
    )
    if concept is None:
        raise HTTPException(status_code=404, detail="Concept not found")

    provenance = concept.provenance or {}
    # Locate the suggestion (if any) that was accepted into this concept.
    suggestion = (
        session.query(SuggestionModel)
        .filter(SuggestionModel.accepted_concept_id == concept.id)
        .first()
    )
    return ConceptOriginResponse(
        concept_id=str(concept.id),
        concept_key=concept.concept_key,
        scheme_id=str(concept.scheme_id),
        origin=concept.origin,
        provenance=provenance or None,
        source_uri=provenance.get("source_uri"),
        extractor=provenance.get("extractor"),
        extracted_at=provenance.get("extracted_at"),
        accepted_by=provenance.get("accepted_by"),
        accepted_at=provenance.get("accepted_at"),
        suggestion_id=str(suggestion.id) if suggestion else None,
    )


@router.get(
    "/contracts/{contract_id}/grown",
    response_model=GrownResponse,
)
async def contract_grown(
    contract_id: str,
    session=Depends(get_db_session),
) -> GrownResponse:
    """Return concepts + suggestions grown under this contract.

    Matches every :class:`SuggestionModel` whose ``source_uri`` or
    provenance ``contract_id`` references the given contract, plus any
    already-accepted concepts whose provenance does the same.
    """
    suggestions = (
        session.query(SuggestionModel)
        .filter(
            (SuggestionModel.source_uri.like(f"%{contract_id}%"))
            | (SuggestionModel.source_uri == f"contract://{contract_id}")
        )
        .all()
    )
    concepts = (
        session.query(ConceptModel).filter(ConceptModel.provenance.isnot(None)).all()
    )
    matched_concepts = [
        c for c in concepts if _provenance_mentions_contract(c.provenance, contract_id)
    ]
    return _build_grown_response(suggestions, matched_concepts)


@router.get(
    "/pipelines/{pipeline_id}/grown",
    response_model=GrownResponse,
)
async def pipeline_grown(
    pipeline_id: str,
    session=Depends(get_db_session),
) -> GrownResponse:
    """Return concepts + suggestions grown from runs of this pipeline."""
    prefix = f"pipeline_run://{pipeline_id}"
    suggestions = (
        session.query(SuggestionModel)
        .filter(SuggestionModel.source_uri.like(f"{prefix}%"))
        .all()
    )
    concepts = (
        session.query(ConceptModel).filter(ConceptModel.provenance.isnot(None)).all()
    )
    matched_concepts = [
        c for c in concepts if _provenance_mentions_source(c.provenance, prefix)
    ]
    return _build_grown_response(suggestions, matched_concepts)


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------


def _validate_uuid(raw: str) -> None:
    """Reject non-UUID ids with 422 before hitting the DB."""
    try:
        uuid_mod.UUID(raw)
    except (ValueError, AttributeError) as exc:
        raise HTTPException(status_code=422, detail="id must be a UUID") from exc


def _provenance_mentions_contract(
    provenance: dict | None,
    contract_id: str,
) -> bool:
    """True when the provenance dict references the contract."""
    if not provenance:
        return False
    if provenance.get("contract_id") == contract_id:
        return True
    source_uri = provenance.get("source_uri") or ""
    return contract_id in source_uri


def _provenance_mentions_source(provenance: dict | None, prefix: str) -> bool:
    """True when the provenance source_uri starts with the pipeline prefix."""
    if not provenance:
        return False
    source_uri = provenance.get("source_uri") or ""
    return source_uri.startswith(prefix)


def _build_grown_response(
    suggestions: list[SuggestionModel],
    concepts: list[ConceptModel],
) -> GrownResponse:
    """Shape the combined list of concepts + suggestions into the response."""
    items: list[GrownEntry] = []
    pending = accepted = dismissed = 0
    for s in suggestions:
        items.append(
            GrownEntry(
                id=str(s.id),
                kind="suggestion",
                suggestion_kind=s.suggestion_kind,
                scheme_id=str(s.scheme_id),
                concept_key=(s.payload or {}).get("concept_key"),
                name=(s.payload or {}).get("name"),
                origin=s.origin,
                status=s.status,
                source_uri=s.source_uri,
                created_at=s.created_at.isoformat() if s.created_at else None,
            )
        )
        if s.status == "pending":
            pending += 1
        elif s.status == "accepted":
            accepted += 1
        elif s.status == "dismissed":
            dismissed += 1
    for c in concepts:
        items.append(
            GrownEntry(
                id=str(c.id),
                kind="concept",
                scheme_id=str(c.scheme_id),
                concept_key=c.concept_key,
                name=c.name,
                origin=c.origin,
                status="materialised",
                source_uri=(c.provenance or {}).get("source_uri"),
                created_at=c.created_at.isoformat() if c.created_at else None,
            )
        )
        accepted += 1
    return GrownResponse(
        items=items,
        pending=pending,
        accepted=accepted,
        dismissed=dismissed,
    )
