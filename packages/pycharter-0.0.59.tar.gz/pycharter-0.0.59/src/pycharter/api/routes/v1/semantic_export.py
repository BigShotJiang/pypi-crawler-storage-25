"""Concept-graph export endpoints.

Serve Obsidian vaults (written to a caller-supplied directory) and
Neo4j Cypher scripts (returned inline as plain text) derived from a
:class:`ConceptGraph`. Both routes are thin wrappers around the pure
exporter functions in :mod:`pycharter.semantic.export`.
"""

from __future__ import annotations

import logging
import uuid as uuid_mod
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import PlainTextResponse, Response
from pydantic import BaseModel, Field

from pycharter.api.dependencies import get_db_session
from pycharter.semantic.concept_graph.sqlalchemy_repository import (
    SqlAlchemyConceptGraphRepository,
)
from pycharter.semantic.export import (
    export_to_neo4j_cypher,
    export_to_obsidian,
    exporter_for_format,
    list_formats,
)

router = APIRouter(tags=["Semantic - Export"])
logger = logging.getLogger(__name__)


class ObsidianExportRequest(BaseModel):
    """Request body for ``POST /api/v1/semantic/export/obsidian``."""

    scheme_id: str = Field(
        ...,
        description="UUID or scheme_key of the scheme to export.",
    )
    output_dir: str = Field(
        ...,
        description=(
            "Absolute path to the target Obsidian vault directory. "
            "Created if it does not exist; existing same-named files "
            "are overwritten."
        ),
    )


@router.post("/obsidian")
async def create_obsidian_vault(
    request: ObsidianExportRequest,
    session=Depends(get_db_session),
) -> dict[str, Any]:
    """Export the scheme as an Obsidian-compatible markdown vault.

    Raises:
        404 if the scheme is not found.
    """
    scheme_uuid = _resolve_scheme_id(session, request.scheme_id)
    graph = _load_graph(session, scheme_uuid)
    output_dir = Path(request.output_dir)
    logger.info(
        "obsidian export: scheme=%s target=%s concepts=%d",
        scheme_uuid,
        output_dir,
        len(graph.nodes),
    )
    result = export_to_obsidian(graph, output_dir)
    return result.to_dict()


@router.get("/neo4j", response_class=PlainTextResponse)
async def get_neo4j_cypher(
    scheme_id: str = Query(
        ...,
        description="UUID or scheme_key of the scheme to export.",
    ),
    session=Depends(get_db_session),
) -> str:
    """Return the scheme as an idempotent Neo4j Cypher script (plain text).

    Raises:
        404 if the scheme is not found.
    """
    scheme_uuid = _resolve_scheme_id(session, scheme_id)
    graph = _load_graph(session, scheme_uuid)
    logger.info(
        "neo4j cypher export: scheme=%s concepts=%d",
        scheme_uuid,
        len(graph.nodes),
    )
    return export_to_neo4j_cypher(graph)


# -----------------------------------------------------------------------------
# Unified downloads: /formats + /graph
# -----------------------------------------------------------------------------


_CONTENT_TYPES: dict[str, str] = {
    "json": "application/json",
    "yaml": "application/yaml",
    "rdf-turtle": "text/turtle",
    "rdf-jsonld": "application/ld+json",
    "linkml": "application/yaml",
    "neo4j-cypher": "text/plain; charset=utf-8",
}
"""Content-type mapping for download responses."""


@router.get("/formats")
async def list_export_formats() -> list[dict[str, object]]:
    """Return every registered export format with its label + description.

    Drives the "Export" modal in the UI — one place to ask "what can I
    export to?" so the modal never duplicates the registry.
    """
    return [
        {
            "id": fmt.id,
            "label": fmt.label,
            "description": fmt.description,
            "file_suffix": fmt.file_suffix,
            "is_directory": fmt.is_directory,
        }
        for fmt in list_formats()
    ]


@router.get("/graph")
async def download_graph(
    scheme_id: str = Query(
        ...,
        description="UUID or scheme_key of the scheme to export.",
    ),
    format: str = Query(  # noqa: A002 — aligns with HTTP query-string convention
        ...,
        description=(
            "Format id from /api/v1/semantic/export/formats. Obsidian "
            "uses a different endpoint (POST /obsidian) because it "
            "writes a directory."
        ),
    ),
    session=Depends(get_db_session),
) -> Response:
    """Download the scheme graph in the requested format.

    Raises:
        404 if the scheme is missing.
        422 for unknown formats or for requesting obsidian (directory
            exports go through POST /obsidian).
    """
    if format == "obsidian":
        raise HTTPException(
            status_code=422,
            detail=(
                "Use POST /api/v1/semantic/export/obsidian for Obsidian "
                "vault writes (directory output)."
            ),
        )
    if format == "neo4j-live":
        raise HTTPException(
            status_code=422,
            detail=(
                "neo4j-live is a live-write exporter. Use `pycharter kb "
                "export --format neo4j-live --url bolt://...` from the "
                "CLI instead, or download `--format neo4j-cypher` to get "
                "a re-runnable Cypher script."
            ),
        )

    exporter = exporter_for_format(format)
    if exporter is None:
        raise HTTPException(status_code=422, detail=f"Unknown format: {format}")

    scheme_uuid = _resolve_scheme_id(session, scheme_id)
    graph = _load_graph(session, scheme_uuid)

    # Write to a temp path so we can read back + stream.
    import tempfile

    matching = next((fmt for fmt in list_formats() if fmt.id == format), None)
    suffix = matching.file_suffix if matching else ".bin"
    with tempfile.NamedTemporaryFile(
        mode="w+", suffix=suffix, delete=False, encoding="utf-8"
    ) as handle:
        temp_path = Path(handle.name)
    try:
        exporter.export(graph, temp_path)
        payload = temp_path.read_text(encoding="utf-8")
    finally:
        try:
            temp_path.unlink()
        except OSError:
            pass

    filename = f"{scheme_uuid}{suffix}"
    content_type = _CONTENT_TYPES.get(format, "application/octet-stream")
    logger.info(
        "graph export: scheme=%s format=%s bytes=%d",
        scheme_uuid,
        format,
        len(payload),
    )
    return Response(
        content=payload,
        media_type=content_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


def _resolve_scheme_id(session, scheme_id: str) -> str:
    """Resolve a scheme_key to its UUID, or pass a UUID through unchanged."""
    from pycharter.db.models.semantic.concept_scheme import ConceptSchemeModel

    try:
        uuid_mod.UUID(scheme_id)
        filter_clause = ConceptSchemeModel.id == scheme_id
    except (ValueError, AttributeError):
        filter_clause = ConceptSchemeModel.scheme_key == scheme_id

    row = session.query(ConceptSchemeModel).filter(filter_clause).first()
    if row is None:
        raise HTTPException(status_code=404, detail=f"Scheme not found: {scheme_id}")
    return str(row.id)


def _load_graph(session, scheme_uuid: str):
    """Load the ConceptGraph for ``scheme_uuid`` via the repository."""
    try:
        return SqlAlchemyConceptGraphRepository(session).load_graph(scheme_uuid)
    except KeyError as exc:
        raise HTTPException(
            status_code=404, detail=f"Scheme not found: {scheme_uuid}"
        ) from exc
