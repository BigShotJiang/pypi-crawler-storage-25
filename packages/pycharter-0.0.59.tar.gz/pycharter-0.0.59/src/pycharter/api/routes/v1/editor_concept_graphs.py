"""FastAPI route handlers for editorv2 concept graph operations.

Exposes three endpoints:

- ``GET /editor/concept-graphs/{scheme_id}``: returns the full
  concept graph for a scheme.
- ``PUT /editor/concept-graphs/{scheme_id}``: applies a batch of
  node and edge changes to the scheme. The path ``scheme_id`` and
  the delta body ``scheme_id`` must match.
- ``POST /editor/concept-graphs``: creates a new (empty) scheme
  that the editor can immediately load. Mirrors the existing
  ``/api/v1/semantic/schemes`` POST shape but commits the row
  inside the request handler so the editor sees the scheme on the
  next read.

Tier governance is enforced at the service layer: writes that target
core-tier concepts without ``allow_core=True`` come back here as a
:class:`TierProtectedError` that we map to HTTP 409.
"""

from __future__ import annotations

import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from pycharter.api.dependencies.database import get_db_session
from pycharter.api.models.concept_graphs import (
    BindingEdgeResponse,
    BindingProjectionResponse,
    ConceptGraphApplyDeltaRequest,
    ConceptGraphApplyDeltaResponse,
    ConceptGraphCreateRequest,
    ConceptGraphResponse,
    LinkMLProjectionResponse,
    ValidationIssueResponse,
    ValidationReportResponse,
    linkml_projection_to_response,
)
from pycharter.db.models.semantic.concept_scheme import ConceptSchemeModel
from pycharter.semantic.concept_graph import (
    ConceptGraphService,
    TierProtectedError,
    project_to_linkml,
)
from pycharter.semantic.concept_graph.models import ConceptGraph, SlotDefinition
from pycharter.semantic.concept_graph.sqlalchemy_repository import (
    SqlAlchemyConceptGraphRepository,
)
from pycharter.semantic.concept_graph.validator import (
    validate_concept_graph,
)
from pycharter.semantic.contracts.binding_projection import (
    project_contract_bindings,
)
from pycharter.semantic.contracts.loader import (
    ContractLoadError,
    load_contract,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Editor Concept Graph"])


def _service(session: Session) -> ConceptGraphService:
    """Construct the service with a SQLAlchemy-backed repository."""
    return ConceptGraphService(SqlAlchemyConceptGraphRepository(session))


def _parse_integrity_error(
    exc: IntegrityError,
) -> tuple[str | None, str | None, str | None]:
    """Extract constraint name / field / offending value from a psycopg2 error.

    psycopg2 surfaces unique-constraint violations with a specific
    detail shape like ``Key (name)=(Event) already exists``. Parsing
    it gives the UI something actionable to render. Returns
    ``(None, None, None)`` when the message shape is different so
    callers fall back to the generic message.
    """
    constraint: str | None = None
    field: str | None = None
    value: str | None = None

    orig = getattr(exc, "orig", None)
    diag = getattr(orig, "diag", None)
    if diag is not None:
        constraint = getattr(diag, "constraint_name", None)

    message = str(orig) if orig is not None else str(exc)
    # psycopg2 shape: "DETAIL:  Key (name)=(Event) already exists."
    key_eq = "Key ("
    if key_eq in message:
        try:
            after = message.split(key_eq, 1)[1]
            field = after.split(")", 1)[0].strip()
            remainder = after.split(")", 1)[1]
            if remainder.startswith("=("):
                value = remainder[2:].split(")", 1)[0].strip()
        except (IndexError, ValueError):
            pass

    # sqlite3 shape: "UNIQUE constraint failed: concepts.name"
    sqlite_prefix = "UNIQUE constraint failed:"
    if field is None and sqlite_prefix in message:
        try:
            ref = message.split(sqlite_prefix, 1)[1].strip()
            # Trim any trailing punctuation the SQLAlchemy wrapper
            # may have added.
            ref = ref.split("\n", 1)[0].rstrip(").;,").strip()
            if "." in ref:
                field = ref.split(".", 1)[1]
        except (IndexError, ValueError):
            pass

    return constraint, field, value


def _integrity_error_message(
    constraint: str | None,
    field: str | None,
    value: str | None,
) -> str:
    """Build a human-readable message for an integrity violation."""
    if field and value:
        return (
            f"A record with {field}={value!r} already exists. "
            "Pick a different value or remove the conflicting record first."
        )
    if field:
        return (
            f"A record with the same {field} already exists. "
            "Pick a different value or remove the conflicting record first."
        )
    if constraint:
        return (
            f"Database constraint '{constraint}' was violated. "
            "Check the request payload against the schema."
        )
    return (
        "A database constraint was violated. "
        "Check the request payload against the schema."
    )


def _compute_binding_projection(
    graph: ConceptGraph,
    contract_paths: list[str],
) -> BindingProjectionResponse:
    """Load contracts from file paths and project their bindings.

    Contracts that cannot be loaded (missing file, parse error) are
    silently skipped with a warning log so a single bad reference
    doesn't brick the entire response.
    """
    # The binding projector maps 'name:version' → ConceptGraph.
    # For the editor surface we only have one ontology loaded at a
    # time; key it by the scheme's scheme_key + version.
    ontology_key = f"{graph.scheme.scheme_key}:{graph.scheme.version}"
    loaded_ontologies = {ontology_key: graph}

    all_edges: list[BindingEdgeResponse] = []
    total_unresolved = 0
    failed: list[str] = []

    for path in contract_paths:
        try:
            contract = load_contract(path)
        except ContractLoadError:
            logger.warning(
                "Could not load contract at '%s'; skipping",
                path,
                exc_info=True,
            )
            failed.append(path)
            continue
        except OSError:
            logger.warning(
                "Could not read contract file '%s'; skipping",
                path,
                exc_info=True,
            )
            failed.append(path)
            continue

        projection = project_contract_bindings(
            contract,
            loaded_ontologies=loaded_ontologies,
        )
        for edge in projection.edges:
            all_edges.append(
                BindingEdgeResponse(
                    id=edge.id,
                    field_path=edge.field_path,
                    contract_id=edge.contract_id,
                    contract_version=edge.contract_version,
                    target_ontology=edge.target_ontology,
                    target_concept_id=edge.target_concept_id,
                    target_concept_key=edge.target_concept_key,
                    target_concept_name=edge.target_concept_name,
                    kind=edge.kind,
                    relationship=edge.relationship,
                    confidence=edge.confidence,
                    tags=list(edge.tags),
                )
            )
        total_unresolved += len(projection.unresolved)

    return BindingProjectionResponse(
        edges=all_edges,
        unresolved_count=total_unresolved,
        failed_contracts=failed,
    )


def _projection(graph: ConceptGraph) -> LinkMLProjectionResponse:
    """Compute the LinkML projection of a graph for the response.

    Pairs ``project_to_linkml`` (pure dataclass output) with the
    Pydantic mirror converter so the load/save handlers stay one
    line. The projection itself is O(N + E) over the concept graph
    and free of side effects, so calling it on every request is
    cheap relative to the SQL hit.
    """
    return linkml_projection_to_response(project_to_linkml(graph))


@router.get(
    "/editor/concept-graphs/{scheme_id}",
    response_model=ConceptGraphResponse,
    summary="Load the concept graph for a scheme",
    description=(
        "Returns the full concept graph (nodes, edges, scheme "
        "metadata) for the scheme identified by ``scheme_id``."
    ),
)
async def get_concept_graph(
    scheme_id: str,
    session: Session = Depends(get_db_session),
    with_contracts: list[str] | None = Query(
        default=None,
        description=(
            "Optional list of contract file paths. When set, the "
            "response includes a binding_projection showing cross-layer "
            "edges from each contract's field_bindings to the concepts "
            "in this scheme."
        ),
    ),
) -> ConceptGraphResponse:
    """Return the concept graph and its LinkML projection.

    When ``with_contracts`` is provided, the response additionally
    contains a ``binding_projection`` with cross-layer edges from
    each contract's field bindings to the concepts in this scheme.
    Contracts that cannot be loaded are silently skipped — the
    response carries the successful projections and logs a warning
    for the rest.
    """
    service = _service(session)
    try:
        graph = service.get_graph(scheme_id)
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"scheme '{scheme_id}' not found",
        ) from None

    binding_proj: BindingProjectionResponse | None = None
    if with_contracts:
        binding_proj = _compute_binding_projection(graph, with_contracts)

    return ConceptGraphResponse(
        graph=graph,
        linkml_projection=_projection(graph),
        binding_projection=binding_proj,
    )


@router.put(
    "/editor/concept-graphs/{scheme_id}",
    response_model=ConceptGraphApplyDeltaResponse,
    summary="Apply a delta to the concept graph",
    description=(
        "Applies a batch of node and edge creates, updates, and "
        "removes to the concept graph. Writes targeting core-tier "
        "concepts without ``allow_core=True`` return HTTP 409."
    ),
)
async def apply_concept_graph_delta(
    scheme_id: str,
    request: ConceptGraphApplyDeltaRequest,
    session: Session = Depends(get_db_session),
) -> ConceptGraphApplyDeltaResponse:
    """Apply a concept graph delta and return the post-delta graph."""
    if request.delta.scheme_id != scheme_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "path scheme_id does not match delta.scheme_id "
                f"({scheme_id!r} vs {request.delta.scheme_id!r})"
            ),
        )
    service = _service(session)
    try:
        graph = service.apply_delta(
            request.delta,
            allow_core=request.allow_core,
        )
    except TierProtectedError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "error": "tier_protected",
                "concept_key": exc.concept_key,
                "tier": exc.tier,
                "message": "Concept tier is protected from this change",
            },
        )
    except IntegrityError as exc:
        # Database constraint violation (unique-name collision is the
        # common case). Surface as 409 with a parsed detail so the UI
        # can present something actionable instead of the generic
        # "Failed to connect to database" that get_db_session falls
        # back to when it catches broad Exception.
        session.rollback()
        logger.warning(
            "apply_concept_graph_delta integrity violation: %s",
            exc,
            exc_info=True,
        )
        constraint, field, value = _parse_integrity_error(exc)
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "error": "integrity_violation",
                "constraint": constraint,
                "field": field,
                "value": value,
                "message": _integrity_error_message(constraint, field, value),
            },
        ) from exc
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"Concept graph or referenced concept not found "
                f"(scheme_id={scheme_id!r})"
            ),
        )
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Invalid concept graph delta (malformed concept reference, "
                "unsupported operation, or schema mismatch)"
            ),
        )
    session.commit()
    return ConceptGraphApplyDeltaResponse(
        graph=graph,
        linkml_projection=_projection(graph),
    )


def _handle_slot_write(
    service: ConceptGraphService,
    call: str,
    session: Session,
    *,
    do_write: callable,  # type: ignore[valid-type]
) -> ConceptGraphApplyDeltaResponse:
    """Shared error-mapping wrapper around slot CRUD service calls.

    Maps service-layer exceptions onto the same HTTP codes the PUT
    delta endpoint uses so clients can handle all concept-graph
    writes through one error taxonomy:

    - :class:`KeyError` → 404
    - :class:`ValueError` (service-layer validation) → 400
    - :class:`TierProtectedError` → 409 with tier_protected detail

    Commits the session on success and returns the post-write graph
    plus its LinkML projection so the editor canvas can refresh
    without a follow-up GET.
    """
    try:
        graph = do_write()
    except TierProtectedError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "error": "tier_protected",
                "concept_key": exc.concept_key,
                "tier": exc.tier,
                "message": "Concept tier is protected from this change",
            },
        ) from exc
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"{call}: concept or scheme not found",
        ) from None
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"{call}: invalid request",
        ) from None
    session.commit()
    return ConceptGraphApplyDeltaResponse(
        graph=graph,
        linkml_projection=_projection(graph),
    )


@router.post(
    "/editor/concept-graphs/{scheme_id}/concepts/{concept_key}/slots",
    response_model=ConceptGraphApplyDeltaResponse,
    summary="Add a slot to a concept",
    description=(
        "Appends ``slot`` to the target concept's ``slots[]`` via the "
        "existing delta mechanism. Returns 404 if the concept or "
        "scheme does not exist, 400 if a slot with the same name "
        "already exists on the concept, 409 with the tier_protected "
        "payload if the concept is core-tier and ``allow_core`` is "
        "not set."
    ),
)
async def add_concept_slot(
    scheme_id: str,
    concept_key: str,
    slot: SlotDefinition,
    allow_core: bool = Query(
        default=False,
        description=(
            "Governance override — set to true only when the caller "
            "holds a signed proposal acceptance for the target concept."
        ),
    ),
    session: Session = Depends(get_db_session),
) -> ConceptGraphApplyDeltaResponse:
    """Add a slot to an existing concept."""
    service = _service(session)
    return _handle_slot_write(
        service,
        "add_concept_slot",
        session,
        do_write=lambda: service.add_slot_to_concept(
            scheme_id,
            concept_key,
            slot,
            allow_core=allow_core,
        ),
    )


@router.patch(
    "/editor/concept-graphs/{scheme_id}/concepts/{concept_key}/slots/{slot_name}",
    response_model=ConceptGraphApplyDeltaResponse,
    summary="Update a slot on a concept",
    description=(
        "Replaces the slot named ``slot_name`` on ``concept_key``. "
        "The path ``slot_name`` wins over any ``name`` field in the "
        "body — renames go through DELETE + POST so downstream "
        "references can be migrated intentionally. Same error mapping "
        "as the POST endpoint."
    ),
)
async def update_concept_slot(
    scheme_id: str,
    concept_key: str,
    slot_name: str,
    patch: SlotDefinition,
    allow_core: bool = Query(
        default=False,
        description="Governance override — see POST for semantics.",
    ),
    session: Session = Depends(get_db_session),
) -> ConceptGraphApplyDeltaResponse:
    """Update a slot on an existing concept."""
    service = _service(session)
    return _handle_slot_write(
        service,
        "update_concept_slot",
        session,
        do_write=lambda: service.update_slot_on_concept(
            scheme_id,
            concept_key,
            slot_name,
            patch,
            allow_core=allow_core,
        ),
    )


@router.delete(
    "/editor/concept-graphs/{scheme_id}/concepts/{concept_key}/slots/{slot_name}",
    response_model=ConceptGraphApplyDeltaResponse,
    summary="Remove a slot from a concept",
    description=(
        "Drops the slot named ``slot_name`` from ``concept_key``. "
        "No-ops silently if the slot is not present (mirrors the "
        "service-layer semantics); the response still carries the "
        "current graph so the caller sees canonical state. Tier "
        "gating and error mapping as on the POST endpoint."
    ),
)
async def remove_concept_slot(
    scheme_id: str,
    concept_key: str,
    slot_name: str,
    allow_core: bool = Query(
        default=False,
        description="Governance override — see POST for semantics.",
    ),
    session: Session = Depends(get_db_session),
) -> ConceptGraphApplyDeltaResponse:
    """Remove a slot from an existing concept."""
    service = _service(session)
    return _handle_slot_write(
        service,
        "remove_concept_slot",
        session,
        do_write=lambda: service.remove_slot_from_concept(
            scheme_id,
            concept_key,
            slot_name,
            allow_core=allow_core,
        ),
    )


@router.post(
    "/editor/concept-graphs",
    response_model=ConceptGraphResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new empty concept graph",
    description=(
        "Creates a new concept scheme row with the supplied metadata "
        "and returns the empty concept graph. The scheme_key must be "
        "unique across the installation."
    ),
)
async def create_concept_graph(
    request: ConceptGraphCreateRequest,
    session: Session = Depends(get_db_session),
) -> ConceptGraphResponse:
    """Create a new scheme and return its empty concept graph."""
    existing = (
        session.query(ConceptSchemeModel)
        .filter(ConceptSchemeModel.scheme_key == request.scheme_key)
        .one_or_none()
    )
    if existing is not None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"scheme_key already exists: '{request.scheme_key}'",
        )

    row = ConceptSchemeModel(
        id=uuid.uuid4(),
        scheme_key=request.scheme_key,
        title=request.title,
        version=request.version,
        description=request.description,
        base_uri=request.base_uri,
    )
    session.add(row)
    session.flush()
    session.commit()

    service = _service(session)
    graph = service.get_graph(str(row.id))
    return ConceptGraphResponse(
        graph=graph,
        linkml_projection=_projection(graph),
    )


@router.get(
    "/editor/concept-graphs/{scheme_id}/export",
    summary="Export the concept graph",
    description=(
        "Returns the concept graph in the requested format. "
        "``format=json`` returns the raw ConceptGraph JSON. "
        "``format=linkml`` returns the LinkML projection as YAML."
    ),
)
async def export_concept_graph(
    scheme_id: str,
    format: str = Query(
        default="json",
        description="Export format: json or linkml.",
    ),
    session: Session = Depends(get_db_session),
) -> dict:
    """Export a concept graph in JSON or LinkML format."""
    from fastapi.responses import JSONResponse

    service = _service(session)
    try:
        graph = service.get_graph(scheme_id)
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"scheme '{scheme_id}' not found",
        ) from None

    if format == "linkml":
        projection = project_to_linkml(graph)
        resp = linkml_projection_to_response(projection)
        return JSONResponse(
            content=resp.model_dump(mode="json"),
            media_type="application/json",
        )

    # Default: JSON export of the full graph.
    return JSONResponse(
        content=graph.model_dump(mode="json"),
        media_type="application/json",
    )


@router.post(
    "/editor/concept-graphs/{scheme_id}/validate",
    response_model=ValidationReportResponse,
    summary="Validate a concept graph",
    description=(
        "Runs structural and governance validation rules against the "
        "concept graph and returns a list of issues. Does not modify "
        "any data."
    ),
)
async def validate_graph(
    scheme_id: str,
    session: Session = Depends(get_db_session),
) -> ValidationReportResponse:
    """Run validation rules and return the report."""
    service = _service(session)
    try:
        graph = service.get_graph(scheme_id)
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"scheme '{scheme_id}' not found",
        ) from None
    raw_issues = validate_concept_graph(graph)
    return ValidationReportResponse(
        scheme_id=scheme_id,
        issues=[
            ValidationIssueResponse(
                id=issue.id,
                severity=issue.severity,
                kind=issue.kind,
                target_id=issue.target_id,
                node_name=issue.node_name,
                message=issue.message,
                category=issue.category,
            )
            for issue in raw_issues
        ],
    )
