"""Semantic-query DSL HTTP route.

Exposes a narrowed view of :class:`pycharter.semantic.queries.ConceptGraphQuery`
over HTTP so remote callers (pygubernator, UIs, CI checks) can run
structured concept-graph queries without embedding the DSL in-process.

The wire format mirrors the DSL's four operations — exactly one must be
set per request. Keeping the body shape 1:1 with the DSL makes it
trivial to generate this request from a fluent builder on the client
side.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field, model_validator

from pycharter.api._http_errors import raise_logged_bad_request
from pycharter.api.dependencies.semantic_store import get_semantic_store
from pycharter.semantic.queries import (
    ConceptGraphQuery,
    ConceptQueryResult,
    QueryError,
    RelationshipQueryResult,
)
from pycharter.semantic_store.client import SemanticStoreClient

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Semantic - Query"])


# ---------------------------------------------------------------------------
# Request body
# ---------------------------------------------------------------------------


class FindOp(BaseModel):
    """``find`` op parameters."""

    concept_type: str | None = None
    scheme_key: str | None = None
    broader_of: str | None = None
    include_narrower: bool = False


class PathOp(BaseModel):
    """``path`` op parameters."""

    from_: str = Field(..., alias="from")
    to: str
    via: list[str] | None = None
    max_depth: int = 6


class RelationshipsOp(BaseModel):
    """``relationships`` op parameters."""

    of: str
    direction: str = "both"
    types: list[str] | None = None


class QueryRequest(BaseModel):
    """Request body for POST /semantic/query.

    Exactly one of the four op fields must be populated.
    """

    find: FindOp | None = None
    path: PathOp | None = None
    relationships: RelationshipsOp | None = None

    @model_validator(mode="after")
    def _exactly_one_op(self) -> QueryRequest:
        set_ops = [
            name
            for name in ("find", "path", "relationships")
            if getattr(self, name) is not None
        ]
        if len(set_ops) != 1:
            raise ValueError(
                "Exactly one of 'find', 'path', 'relationships' must be set; "
                f"got {set_ops}."
            )
        return self


# ---------------------------------------------------------------------------
# Response bodies
# ---------------------------------------------------------------------------


class ConceptResponseItem(BaseModel):
    """Serialised :class:`ConceptQueryResult`."""

    name: str
    label: str
    scheme_key: str | None = None
    concept_type: str | None = None
    broader: str | None = None

    @classmethod
    def from_result(cls, result: ConceptQueryResult) -> ConceptResponseItem:
        """Convert a DSL :class:`ConceptQueryResult` to the wire shape."""
        return cls(
            name=result.name,
            label=result.label,
            scheme_key=result.scheme_key,
            concept_type=result.concept_type,
            broader=result.broader,
        )


class RelationshipResponseItem(BaseModel):
    """Serialised :class:`RelationshipQueryResult`."""

    id: str
    source_name: str
    target_name: str
    relationship_type: str

    @classmethod
    def from_result(cls, result: RelationshipQueryResult) -> RelationshipResponseItem:
        """Convert a DSL :class:`RelationshipQueryResult` to the wire shape."""
        return cls(
            id=result.id,
            source_name=result.source_name,
            target_name=result.target_name,
            relationship_type=result.relationship_type,
        )


class QueryResponse(BaseModel):
    """Response body for POST /semantic/query."""

    op: str
    concepts: list[ConceptResponseItem] = []
    relationships: list[RelationshipResponseItem] = []


# ---------------------------------------------------------------------------
# Route
# ---------------------------------------------------------------------------


@router.post("", response_model=QueryResponse)
def run_query(
    request: QueryRequest,
    store: SemanticStoreClient = Depends(get_semantic_store),
) -> QueryResponse:
    """Execute a semantic-query DSL request against the concept store."""
    try:
        query, op_name = _build_query(request)
        rows = query.execute(store)
    except QueryError as exc:
        logger.info("semantic query error: %s", exc)
        raise_logged_bad_request(
            logger,
            exc,
            public_detail=(
                "Semantic query failed (invalid concept reference, "
                "unsupported operation, or store unavailable)"
            ),
            log_event="semantic_query_failed",
        )

    if op_name == "find":
        return QueryResponse(
            op=op_name,
            concepts=[ConceptResponseItem.from_result(r) for r in rows],
        )
    return QueryResponse(
        op=op_name,
        relationships=[RelationshipResponseItem.from_result(r) for r in rows],
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_query(request: QueryRequest) -> tuple[ConceptGraphQuery, str]:
    """Turn a :class:`QueryRequest` into a DSL query + op label."""
    if request.find is not None:
        find = request.find
        return (
            ConceptGraphQuery().find(
                concept_type=find.concept_type,
                scheme_key=find.scheme_key,
                broader_of=find.broader_of,
                include_narrower=find.include_narrower,
            ),
            "find",
        )
    if request.path is not None:
        path = request.path
        return (
            ConceptGraphQuery().path(
                path.from_,
                path.to,
                via=tuple(path.via) if path.via else None,
                max_depth=path.max_depth,
            ),
            "path",
        )
    assert request.relationships is not None  # validator enforces
    rel = request.relationships
    return (
        ConceptGraphQuery().relationships(
            rel.of,
            direction=rel.direction,
            types=tuple(rel.types) if rel.types else None,
        ),
        "relationships",
    )
