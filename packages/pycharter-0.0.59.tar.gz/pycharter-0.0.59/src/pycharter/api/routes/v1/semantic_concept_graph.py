"""Concept relationship CRUD API routes."""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Query

logger = logging.getLogger(__name__)

from pydantic import BaseModel, Field

from pycharter.api._http_errors import raise_logged_bad_request
from pycharter.api.dependencies import get_db_session
from pycharter.semantic.knowledge.graph import KnowledgeGraph
from pycharter.semantic.shared.errors import GraphError

router = APIRouter(tags=["Semantic - Concept Graph"])


class CreateConceptRelationshipRequest(BaseModel):
    """Request body for creating a concept relationship."""

    source_concept_id: str = Field(..., description="UUID of source concept")
    target_concept_id: str = Field(..., description="UUID of target concept")
    relationship_type: str = Field(..., description="Relationship type name")
    scheme_id: str | None = Field(
        default=None, description="Optional scheme UUID to associate with"
    )


class UpdateConceptRelationshipRequest(BaseModel):
    """Request body for updating a concept relationship."""

    relationship_type: str = Field(..., description="Updated relationship type name")


@router.get("/concepts/{concept_id}/relationships")
async def get_concept_relationships(
    concept_id: str,
    type: str | None = None,
    direction: str = "both",
    scheme_id: str | None = Query(default=None, description="Filter by scheme UUID"),
    session=Depends(get_db_session),
):
    """Get concept-level relationships, optionally filtered by type, direction, and scheme."""
    if direction not in ("outgoing", "incoming", "both"):
        raise HTTPException(
            status_code=400,
            detail="direction must be 'outgoing', 'incoming', or 'both'",
        )
    try:
        kg = KnowledgeGraph(session)
        return kg.get_concept_relationships(
            concept_id,
            relationship_type=type,
            direction=direction,
            scheme_id=scheme_id,
        )
    except GraphError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail=(f"Failed to load relationships for concept {concept_id!r}"),
            log_event="get_concept_relationships_failed",
        )


@router.post("/concepts/relationships", status_code=201)
async def create_concept_relationship(
    request: CreateConceptRelationshipRequest,
    session=Depends(get_db_session),
):
    """Create a typed edge between two concepts."""
    from pycharter.db.models.semantic.concept_relationship import (
        ConceptRelationshipModel,
    )

    cr = ConceptRelationshipModel(
        source_concept_id=request.source_concept_id,
        target_concept_id=request.target_concept_id,
        relationship_type=request.relationship_type,
        scheme_id=request.scheme_id,
    )
    session.add(cr)
    session.flush()
    return {"id": str(cr.id), "status": "created"}


@router.delete("/concepts/relationships/{relationship_id}")
async def delete_concept_relationship(
    relationship_id: str,
    session=Depends(get_db_session),
):
    """Delete a concept relationship edge."""
    from pycharter.db.models.semantic.concept_relationship import (
        ConceptRelationshipModel,
    )

    row = (
        session.query(ConceptRelationshipModel)
        .filter(ConceptRelationshipModel.id == relationship_id)
        .first()
    )
    if row is None:
        raise HTTPException(status_code=404, detail="Relationship not found")
    session.delete(row)
    session.flush()
    return {"status": "deleted"}


@router.put("/concepts/relationships/{relationship_id}")
async def update_concept_relationship(
    relationship_id: str,
    request: UpdateConceptRelationshipRequest,
    session=Depends(get_db_session),
):
    """Update a concept relationship edge type."""
    from pycharter.db.models.semantic.concept_relationship import (
        ConceptRelationshipModel,
    )

    row = (
        session.query(ConceptRelationshipModel)
        .filter(ConceptRelationshipModel.id == relationship_id)
        .first()
    )
    if row is None:
        raise HTTPException(status_code=404, detail="Relationship not found")
    row.relationship_type = request.relationship_type
    session.flush()
    return {"status": "updated", "id": str(row.id)}
