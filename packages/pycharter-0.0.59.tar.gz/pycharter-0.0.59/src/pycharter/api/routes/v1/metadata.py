"""Route handlers for contract store operations.

Schema, metadata, and rules endpoints for the contract store.
Entity CRUD endpoints (owners, domains, systems, etc.) live in
``metadata_entities.py``.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, status

logger = logging.getLogger(__name__)

from sqlalchemy.orm import Session

from pycharter.api._http_errors import (
    raise_logged_bad_request,
    raise_logged_conflict,
    raise_logged_not_found,
)
from pycharter.api.dependencies.database import get_db_session
from pycharter.api.dependencies.store import get_contract_store
from pycharter.api.models.metadata import (
    CoercionRulesStoreRequest,
    MetadataGetResponse,
    MetadataStoreRequest,
    MetadataStoreResponse,
    RulesGetResponse,
    RulesStoreResponse,
    SchemaGetResponse,
    SchemaListItem,
    SchemaListResponse,
    SchemaStoreRequest,
    SchemaStoreResponse,
    ValidationRulesStoreRequest,
)
from pycharter.api.services import metadata_service as svc
from pycharter.contract_store import ContractStoreClient

router = APIRouter(tags=["Metadata"])


# ---------------------------------------------------------------------------
# Schema endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/metadata/schemas",
    response_model=SchemaStoreResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Store a schema",
    description=(
        "Store a JSON Schema definition in the metadata store. "
        "Validates version numbers and prevents duplicate contracts."
    ),
    response_description="Stored schema information",
)
async def store_schema(
    request: SchemaStoreRequest,
    store: ContractStoreClient = Depends(get_contract_store),
) -> SchemaStoreResponse:
    """Store a schema in the contract store."""
    try:
        contract_id = svc.store_schema(
            request.schema_name, request.version, request.schema, store
        )
    except svc.DuplicateContractError as exc:
        raise_logged_conflict(
            logger, exc, public_detail="Conflict", log_event="route failed"
        )
    except svc.InvalidVersionError as exc:
        raise_logged_bad_request(
            logger,
            exc,
            public_detail=(
                f"Invalid version {request.version!r} for schema "
                f"{request.schema_name!r} (must be semver-compatible)"
            ),
            log_event="store_schema_invalid_version",
        )
    except ValueError as exc:
        raise_logged_bad_request(
            logger,
            exc,
            public_detail=(
                f"Failed to store schema {request.schema_name!r} version "
                f"{request.version!r} (invalid schema payload)"
            ),
            log_event="store_schema_invalid_payload",
        )

    return SchemaStoreResponse(
        schema_id=contract_id,
        schema_name=request.schema_name,
        version=request.version,
    )


@router.get(
    "/metadata/schemas/{contract_name}/{contract_version}",
    response_model=SchemaGetResponse,
    status_code=status.HTTP_200_OK,
    summary="Get a schema",
    description="Retrieve a schema from the contract store by contract name and version",
    response_description="Schema definition",
)
async def get_schema(
    contract_name: str,
    contract_version: str,
    store: ContractStoreClient = Depends(get_contract_store),
) -> SchemaGetResponse:
    """Get a schema by data contract name and version."""
    try:
        result = svc.get_schema(contract_name, contract_version, store)
    except svc.SchemaNotFoundError as exc:
        raise_logged_not_found(
            logger, exc, public_detail="Not found", log_event="route failed"
        )
    return SchemaGetResponse(schema=result.schema, version=result.version)


@router.get(
    "/metadata/schemas",
    response_model=SchemaListResponse,
    status_code=status.HTTP_200_OK,
    summary="List all schemas",
    description="Retrieve a list of all schemas stored in the contract store",
    response_description="List of schemas",
)
async def list_schemas(
    store: ContractStoreClient = Depends(get_contract_store),
) -> SchemaListResponse:
    """List all schemas in the contract store."""
    items = svc.list_schemas(store)
    schema_items = [
        SchemaListItem(
            id=item.id, name=item.name, title=item.title, version=item.version
        )
        for item in items
    ]
    return SchemaListResponse(schemas=schema_items, count=len(schema_items))


@router.get(
    "/metadata/schemas/{contract_name}/{contract_version}/complete",
    response_model=SchemaGetResponse,
    status_code=status.HTTP_200_OK,
    summary="Get complete schema with rules",
    description=(
        "Retrieve a complete schema with coercion and validation rules merged "
        "by contract name and version"
    ),
    response_description="Complete schema with rules merged",
)
async def get_complete_schema(
    contract_name: str,
    contract_version: str,
    store: ContractStoreClient = Depends(get_contract_store),
) -> SchemaGetResponse:
    """Get complete schema with rules merged for a data contract."""
    try:
        result = svc.get_complete_schema(contract_name, contract_version, store)
    except svc.SchemaNotFoundError as exc:
        raise_logged_not_found(
            logger, exc, public_detail="Not found", log_event="route failed"
        )
    return SchemaGetResponse(schema=result.schema, version=result.version)


# ---------------------------------------------------------------------------
# Metadata endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/metadata/metadata",
    response_model=MetadataStoreResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Store metadata",
    description="Store metadata for a resource in the contract store",
    response_description="Stored metadata information",
)
async def store_metadata(
    request: MetadataStoreRequest,
    store: ContractStoreClient = Depends(get_contract_store),
) -> MetadataStoreResponse:
    """Store metadata for a schema in the contract store."""
    metadata_id = svc.store_metadata_record(
        request.contract_name, request.contract_version, request.metadata, store
    )
    return MetadataStoreResponse(
        metadata_id=metadata_id,
        contract_name=request.contract_name,
        contract_version=request.contract_version,
    )


@router.get(
    "/metadata/metadata/{contract_name}/{contract_version}",
    response_model=MetadataGetResponse,
    status_code=status.HTTP_200_OK,
    summary="Get metadata",
    description="Retrieve metadata for a data contract by name and version",
    response_description="Metadata dictionary",
)
async def get_metadata(
    contract_name: str,
    contract_version: str,
    store: ContractStoreClient = Depends(get_contract_store),
) -> MetadataGetResponse:
    """Get metadata for a data contract."""
    try:
        metadata = svc.get_metadata(contract_name, contract_version, store)
    except svc.MetadataNotFoundError as exc:
        raise_logged_not_found(
            logger, exc, public_detail="Not found", log_event="route failed"
        )
    return MetadataGetResponse(metadata=metadata)


# ---------------------------------------------------------------------------
# Rules endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/metadata/coercion-rules",
    response_model=RulesStoreResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Store coercion rules",
    description="Store coercion rules for a schema in the contract store",
    response_description="Stored rules information",
)
async def store_coercion_rules(
    request: CoercionRulesStoreRequest,
    store: ContractStoreClient = Depends(get_contract_store),
) -> RulesStoreResponse:
    """Store coercion rules for a schema in the contract store."""
    rule_id = svc.store_coercion_rules(
        request.contract_name,
        request.contract_version,
        request.coercion_rules,
        store,
    )
    return RulesStoreResponse(
        rule_id=rule_id,
        contract_name=request.contract_name,
        contract_version=request.contract_version,
    )


@router.post(
    "/metadata/validation-rules",
    response_model=RulesStoreResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Store validation rules",
    description="Store validation rules for a schema in the contract store",
    response_description="Stored rules information",
)
async def store_validation_rules(
    request: ValidationRulesStoreRequest,
    store: ContractStoreClient = Depends(get_contract_store),
) -> RulesStoreResponse:
    """Store validation rules for a schema in the contract store."""
    rule_id = svc.store_validation_rules(
        request.contract_name,
        request.contract_version,
        request.validation_rules,
        store,
    )
    return RulesStoreResponse(
        rule_id=rule_id,
        contract_name=request.contract_name,
        contract_version=request.contract_version,
    )


@router.get(
    "/metadata/coercion-rules/{contract_name}/{contract_version}",
    response_model=RulesGetResponse,
    status_code=status.HTTP_200_OK,
    summary="Get coercion rules",
    description="Retrieve coercion rules for a data contract by name and version",
    response_description="Coercion rules dictionary",
)
async def get_coercion_rules(
    contract_name: str,
    contract_version: str,
    store: ContractStoreClient = Depends(get_contract_store),
) -> RulesGetResponse:
    """Get coercion rules for a data contract."""
    try:
        rules = svc.get_coercion_rules(contract_name, contract_version, store)
    except svc.RulesNotFoundError as exc:
        raise_logged_not_found(
            logger, exc, public_detail="Not found", log_event="route failed"
        )
    return RulesGetResponse(
        rules=rules,
        contract_name=contract_name,
        contract_version=contract_version,
    )


@router.get(
    "/metadata/validation-rules/{contract_name}/{contract_version}",
    response_model=RulesGetResponse,
    status_code=status.HTTP_200_OK,
    summary="Get validation rules",
    description="Retrieve validation rules for a data contract by name and version",
    response_description="Validation rules dictionary",
)
async def get_validation_rules(
    contract_name: str,
    contract_version: str,
    store: ContractStoreClient = Depends(get_contract_store),
) -> RulesGetResponse:
    """Get validation rules for a data contract."""
    try:
        rules = svc.get_validation_rules(contract_name, contract_version, store)
    except svc.RulesNotFoundError as exc:
        raise_logged_not_found(
            logger, exc, public_detail="Not found", log_event="route failed"
        )
    return RulesGetResponse(
        rules=rules,
        contract_name=contract_name,
        contract_version=contract_version,
    )


# ---------------------------------------------------------------------------
# Listing endpoints
# ---------------------------------------------------------------------------


@router.get(
    "/metadata/artifacts",
    status_code=status.HTTP_200_OK,
    summary="List all artifacts",
    description=(
        "Retrieve lists of all artifacts (schemas, coercion rules, "
        "validation rules, metadata) with their titles and versions"
    ),
    response_description="Lists of artifacts",
)
async def list_artifacts(
    db: Session = Depends(get_db_session),
) -> dict[str, list[dict[str, Any]]]:
    """List all artifacts grouped by type."""
    return svc.list_artifacts(db)


@router.get(
    "/metadata/coercion-functions",
    status_code=status.HTTP_200_OK,
    summary="List coercion functions",
    description=(
        "Return all supported coercion function names and their descriptions "
        "(for Options > Coercion reference)"
    ),
)
async def list_coercion_functions_route() -> dict[str, list[dict[str, str]]]:
    """List built-in coercion functions with short descriptions."""
    return {"functions": svc.list_coercion_functions()}


@router.get(
    "/metadata/validation-functions",
    status_code=status.HTTP_200_OK,
    summary="List validation functions",
    description=(
        "Return all supported validation function names, descriptions, and "
        "expected arguments (for Options > Validation reference)"
    ),
)
async def list_validation_functions_route() -> dict[str, list[dict[str, Any]]]:
    """List built-in validation functions with descriptions and arguments."""
    return {"functions": svc.list_validation_functions()}


@router.get(
    "/metadata/{entity_type}",
    status_code=status.HTTP_200_OK,
    summary="List metadata entities by type",
    description=(
        "Retrieve a list of metadata entities by type "
        "(owners, domains, systems, environments, storage_locations, tags)"
    ),
    response_description="List of entity dictionaries",
)
async def list_metadata_entities(
    entity_type: str,
    db: Session = Depends(get_db_session),
) -> list[dict[str, Any]]:
    """List metadata entities by type."""
    try:
        return svc.list_metadata_entities(entity_type, db)
    except svc.EntityNotFoundError as exc:
        raise_logged_not_found(
            logger, exc, public_detail="Not found", log_event="route failed"
        )
