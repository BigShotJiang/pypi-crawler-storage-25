"""FastAPI route handler for running a pipeline from the editor canvas.

Accepts a pipeline config dict (the same shape produced by
``toPipelineConfig()`` on the frontend pipeline store), runs it via
the existing ``Pipeline.from_dict().run()`` path, and returns
per-step results.

This is a synchronous run (the response waits until the pipeline
completes). For long-running pipelines, a future enhancement would
add a WebSocket or SSE streaming endpoint for live step-by-step
status updates.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel, ConfigDict, Field

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Editor Pipeline Run"])


class PipelineRunRequest(BaseModel):
    """Request body for running a pipeline from the editor."""

    model_config = ConfigDict(extra="allow")

    name: str = Field(default="untitled-pipeline")
    version: str = Field(default="1.0.0")
    steps: list[dict[str, Any]] = Field(..., description="Pipeline step configs.")


class StepResultResponse(BaseModel):
    """Per-step result from a pipeline run."""

    model_config = ConfigDict(extra="forbid")

    step_id: str
    step_type: str
    success: bool
    rows_in: int = 0
    rows_out: int = 0
    duration_seconds: float = 0.0
    errors: list[str] = Field(default_factory=list)


class PipelineRunResponse(BaseModel):
    """Response from a pipeline run."""

    model_config = ConfigDict(extra="forbid")

    run_id: str
    pipeline_name: str
    success: bool
    duration_seconds: float = 0.0
    rows_extracted: int = 0
    rows_loaded: int = 0
    rows_failed: int = 0
    step_results: list[StepResultResponse] = Field(
        default_factory=list,
    )
    errors: list[str] = Field(default_factory=list)


@router.post(
    "/editor/pipelines/run",
    response_model=PipelineRunResponse,
    summary="Run a pipeline from the editor",
    description=(
        "Accepts a pipeline config dict and runs it synchronously. "
        "Returns per-step results when the pipeline completes."
    ),
)
async def run_pipeline_from_editor(
    request: PipelineRunRequest,
) -> PipelineRunResponse:
    """Run a pipeline and return step-level results."""
    from fastapi import HTTPException

    from pycharter.pipeline_generator.pipeline import Pipeline
    from pycharter.pipeline_generator.steps._base import StepType

    # Pre-validate step types before running so malformed configs
    # return 400 Bad Request instead of masking as a 200 with
    # success=False.
    valid_types = {e.value for e in StepType}
    for step in request.steps:
        step_type = step.get("type")
        if step_type not in valid_types:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Unknown step type '{step_type}' in step "
                    f"'{step.get('id', '?')}'. "
                    f"Valid types: {sorted(valid_types)}"
                ),
            )

    raw = request.model_dump()

    # Steps that reference a contract via ``{ref: {type: 'store',
    # name: ...}}`` need a configured contract_store at runtime.
    # Without this, ``Pipeline.from_dict`` raises
    # ``StepContractResolutionError`` ("step contract store refs
    # require a configured contract_store"). The other run endpoint
    # (``routes/v1/pipeline.py``) reads ``contract_store`` from the
    # caller's ``settings_yaml``; the editor surface doesn't ship
    # settings, so inject one here that mirrors the same backend +
    # connection string the API singleton uses, so ``Pipeline``'s
    # ``create_contract_store`` helper can build a client during
    # ``run()`` and resolve every store-typed contract ref against
    # the same backing store the rest of the API talks to.
    settings_block = raw.setdefault("settings", {})
    if "contract_store" not in settings_block:
        # ``parse_pipeline_config`` reads contract_store from
        # ``settings.contract_store`` for step-based configs (the
        # ``normalize_to_steps`` promotion runs only for section-
        # based shapes). Place it there so
        # ``Pipeline.run`` → ``create_contract_store`` can build a
        # client and resolve store-typed contract refs.
        from pycharter.api.dependencies._store_factory import resolve_connection

        store_type, connection_string = resolve_connection("sqlite", None)
        contract_store_config: dict[str, Any] = {"type": store_type}
        if connection_string:
            contract_store_config["connection_string"] = connection_string
        settings_block["contract_store"] = contract_store_config
        logger.warning(
            "EDITOR_PIPELINE_RUN: injected contract_store type=%s conn=%s",
            store_type,
            connection_string,
        )
    else:
        logger.warning(
            "EDITOR_PIPELINE_RUN: contract_store already present: %r",
            settings_block.get("contract_store"),
        )

    logger.warning(
        "EDITOR_PIPELINE_RUN: final settings keys=%s",
        list(settings_block.keys()),
    )

    try:
        pipeline = Pipeline.from_dict(raw)
        result = await pipeline.run()
    except Exception as exc:
        logger.error("Pipeline run failed: %s", exc, exc_info=True)
        return PipelineRunResponse(
            run_id="error",
            pipeline_name=request.name,
            success=False,
            errors=["Pipeline run failed"],
        )

    step_results = [
        StepResultResponse(
            step_id=sr.step_id,
            step_type=sr.step_type,
            success=sr.success,
            rows_in=sr.rows_in,
            rows_out=sr.rows_out,
            duration_seconds=sr.duration_seconds,
            errors=sr.errors,
        )
        for sr in result.step_results
    ]

    return PipelineRunResponse(
        run_id=result.run_id or "unknown",
        pipeline_name=result.pipeline_name or request.name,
        success=result.success,
        duration_seconds=result.duration_seconds,
        rows_extracted=result.rows_extracted,
        rows_loaded=result.rows_loaded,
        rows_failed=result.rows_failed,
        step_results=step_results,
        errors=result.errors,
    )
