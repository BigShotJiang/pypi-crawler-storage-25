"""Extractor test-connection + sample-records endpoints.

Backs the right-rail inspector's ``Test connection`` and ``Sample
records`` buttons in the pipeline editor (Phase 1 of the pipeline UX
overhaul). Both endpoints run the same code path the pipeline runner
would, capped to a small number of records.

Error handling follows the project's HTTP-error helpers in
:mod:`pycharter.api._http_errors`:

* ``ValueError`` raised by
  :func:`~pycharter.pipeline_generator.extractors._probe.probe_extractor`
  (config is invalid / unknown type / out-of-range limit) is treated
  as a public-facing 400.
* Anything else is logged server-side and surfaced as a fixed-text
  500 — driver / network exceptions can otherwise leak credentials in
  their messages.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter

from pycharter.api._http_errors import (
    raise_logged_bad_request_from_exception,
    raise_logged_internal,
)
from pycharter.api.models.extractors import (
    ExtractorSampleRequest,
    ExtractorSampleResponse,
    ExtractorTestRequest,
    ExtractorTestResponse,
)
from pycharter.pipeline_generator.extractors._probe import probe_extractor

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Extractors"])


def _merge_type(req_type: str, config: dict) -> dict:
    """Inject the request-level ``type`` into the config dict.

    The factory accepts ``config["type"]`` as the discriminator. The
    request body keeps ``type`` at the top level for clarity, so we
    merge here. If the config already has a different ``type`` the
    request-level wins.
    """
    merged = dict(config)
    merged["type"] = req_type
    return merged


@router.post(
    "/extractors/test-connection",
    response_model=ExtractorTestResponse,
    summary="Test that an extractor config can read from its source",
)
async def test_connection(req: ExtractorTestRequest) -> ExtractorTestResponse:
    """Run a single-record probe and report ok / not-ok.

    Implementation note: ``test-connection`` is a thin alias over
    ``sample(limit=1)``. We don't expose a separate "open the
    connection without reading" primitive — different extractor
    families would need wildly different shapes for that, while
    "fetch one record" is a single primitive every type already
    supports via ``extract_streaming``.
    """
    config = _merge_type(req.type, req.config)
    try:
        rows, elapsed = await probe_extractor(config, limit=1)
    except ValueError as exc:
        raise_logged_bad_request_from_exception(
            logger,
            exc,
            log_event="extractor_test_invalid_config",
            fallback_detail="Extractor configuration is invalid",
            extra_safe_types=(ValueError,),
        )
    except Exception as exc:  # noqa: BLE001 — third-party drivers
        raise_logged_internal(
            logger,
            exc,
            public_detail=(
                "Extractor failed to connect or read. Check server logs for details."
            ),
            log_event="extractor_test_failed",
        )

    detail = None if rows else "Connected, but no records returned."
    return ExtractorTestResponse(
        ok=True,
        latency_ms=round(elapsed * 1000.0, 2),
        detail=detail,
    )


@router.post(
    "/extractors/sample",
    response_model=ExtractorSampleResponse,
    summary="Read up to N records from an extractor for preview",
)
async def sample(req: ExtractorSampleRequest) -> ExtractorSampleResponse:
    """Run a bounded probe and return the records collected.

    The endpoint intentionally executes the same network / IO path the
    real pipeline would; this is the diagnostic value. ``limit`` is
    Pydantic-bounded at 1..100 and the underlying probe enforces the
    same cap defensively.
    """
    config = _merge_type(req.type, req.config)
    try:
        rows, elapsed = await probe_extractor(config, limit=req.limit)
    except ValueError as exc:
        raise_logged_bad_request_from_exception(
            logger,
            exc,
            log_event="extractor_sample_invalid_config",
            fallback_detail="Extractor configuration is invalid",
            extra_safe_types=(ValueError,),
        )
    except Exception as exc:  # noqa: BLE001 — third-party drivers
        raise_logged_internal(
            logger,
            exc,
            public_detail=(
                "Extractor failed to read records. Check server logs for details."
            ),
            log_event="extractor_sample_failed",
        )

    columns: list[str] | None = None
    if rows:
        seen: dict[str, None] = {}
        for row in rows:
            for key in row:
                if key not in seen:
                    seen[key] = None
        columns = list(seen.keys())

    return ExtractorSampleResponse(
        rows=rows,
        # Best-effort signal: when the probe returned exactly the limit
        # the source likely has more. Avoids running a second request.
        truncated=len(rows) >= req.limit,
        latency_ms=round(elapsed * 1000.0, 2),
        columns=columns,
    )
