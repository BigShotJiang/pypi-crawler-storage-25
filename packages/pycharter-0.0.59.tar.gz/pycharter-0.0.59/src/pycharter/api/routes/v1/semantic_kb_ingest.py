"""HTTP ingest endpoints for the UI Ingest modal.

Two complementary paths:

- ``POST /api/v1/semantic/kb/ingest-text`` — paste-in mode. The body
  carries a ``filename`` + ``content`` + ``scheme_id`` triple; the
  server writes to a tempfile, dispatches via the default registry,
  materialises results as suggestions, and returns a JSON summary.
- ``POST /api/v1/semantic/kb/ingest-upload`` — multipart file upload.
  Same dispatch + materialise flow; supports multiple files per call.

Both routes populate the governed suggestion queue (not the ontology
directly) so extraction output continues to respect the M7 governance
spine. The response is a compact ``IngestReport`` JSON that the UI
renders as a summary card with a deep link into `/ontology/suggestions`.
"""

from __future__ import annotations

import logging
import shutil
import tempfile
import uuid as uuid_mod
from pathlib import Path
from typing import Any

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    UploadFile,
)
from pydantic import BaseModel, Field

from pycharter.api.dependencies import get_db_session
from pycharter.semantic import kb

router = APIRouter(tags=["Semantic - KB Ingest"])
logger = logging.getLogger(__name__)


class IngestTextRequest(BaseModel):
    """Body for ``POST /api/v1/semantic/kb/ingest-text``."""

    filename: str = Field(
        ...,
        description=(
            "A logical filename (with extension) so the registry can "
            "dispatch to the right adapter. Example: 'glossary.md'."
        ),
    )
    content: str = Field(
        ...,
        description="The full document content.",
    )
    scheme_id: str = Field(
        ...,
        description="UUID or scheme_key of the target scheme.",
    )
    adapter: str | None = Field(
        default=None,
        description=(
            "Force this plugin name on the content, overriding extension "
            "dispatch. Usually left null."
        ),
    )
    actor: str | None = Field(
        default=None,
        description="Audit tag stamped on every created suggestion.",
    )


class IngestReportResponse(BaseModel):
    """Compact ingest summary rendered by the UI."""

    root: str
    concept_count: int
    relation_count: int
    source_count: int
    cache_hits: int
    suggestions_created: int
    suggestion_ids: list[str]
    skipped: list[str] = Field(default_factory=list)
    failures: list[dict[str, str]] = Field(default_factory=list)
    by_source_type: dict[str, dict[str, int]] = Field(default_factory=dict)


@router.post("/ingest-text", response_model=IngestReportResponse)
async def ingest_text(
    request: IngestTextRequest,
    session=Depends(get_db_session),
) -> IngestReportResponse:
    """Ingest a single pasted document and populate the suggestion queue.

    Raises:
        404 if the scheme is missing.
        422 if the content cannot be dispatched (no adapter matches
            the filename).
    """
    scheme_uuid = _resolve_scheme_id(session, request.scheme_id)
    with tempfile.TemporaryDirectory(prefix="pycharter-ingest-") as tmpdir:
        target = Path(tmpdir) / request.filename
        target.write_text(request.content, encoding="utf-8")
        report = kb.ingest(
            target,
            adapter=request.adapter,
            scheme_id=scheme_uuid,
            session=session,
            actor=request.actor or "ingest-api",
            use_cache=False,
        )
    session.commit()
    logger.info(
        "ingest-text: scheme=%s filename=%s suggestions=%d",
        scheme_uuid,
        request.filename,
        report.suggestions_created,
    )
    return _to_response(report)


@router.post("/ingest-upload", response_model=IngestReportResponse)
async def ingest_upload(
    scheme_id: str = Form(..., description="UUID or scheme_key of the target scheme."),
    adapter: str | None = Form(
        default=None,
        description="Force this plugin on every uploaded file.",
    ),
    actor: str | None = Form(
        default=None,
        description="Audit tag stamped on suggestions.",
    ),
    files: list[UploadFile] = File(
        ...,
        description="One or more source files to ingest.",
    ),
    session=Depends(get_db_session),
) -> IngestReportResponse:
    """Ingest multipart file uploads and populate the suggestion queue.

    Files are streamed to a temp directory, then dispatched through the
    default registry in one ingest pass so the summary reflects the
    full batch.
    """
    if not files:
        raise HTTPException(status_code=422, detail="At least one file required.")
    scheme_uuid = _resolve_scheme_id(session, scheme_id)
    with tempfile.TemporaryDirectory(prefix="pycharter-ingest-") as tmpdir:
        root = Path(tmpdir)
        for upload in files:
            if not upload.filename:
                continue
            target = root / Path(upload.filename).name
            with target.open("wb") as handle:
                shutil.copyfileobj(upload.file, handle)
        report = kb.ingest(
            root,
            adapter=adapter,
            scheme_id=scheme_uuid,
            session=session,
            actor=actor or "ingest-api",
            use_cache=False,
        )
    session.commit()
    logger.info(
        "ingest-upload: scheme=%s file_count=%d suggestions=%d",
        scheme_uuid,
        len(files),
        report.suggestions_created,
    )
    return _to_response(report)


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------


def _resolve_scheme_id(session, scheme_id: str) -> str:
    """Resolve a scheme_key to its UUID, or pass a UUID through unchanged."""
    from pycharter.db.models.semantic.concept_scheme import ConceptSchemeModel

    try:
        uuid_mod.UUID(scheme_id)
        filter_clause = ConceptSchemeModel.id == scheme_id
    except (ValueError, AttributeError):
        filter_clause = ConceptSchemeModel.scheme_key == scheme_id

    row = session.query(ConceptSchemeModel).filter(filter_clause).first()
    if row is None:
        raise HTTPException(status_code=404, detail=f"Scheme not found: {scheme_id}")
    return str(row.id)


def _to_response(report: kb.IngestReport) -> IngestReportResponse:
    """Flatten an :class:`IngestReport` into the compact UI shape."""
    return IngestReportResponse(
        root=str(report.root),
        concept_count=report.concept_count,
        relation_count=report.relation_count,
        source_count=len(report.results),
        cache_hits=report.cache_hits,
        suggestions_created=report.suggestions_created,
        suggestion_ids=list(report.suggestion_ids),
        skipped=[str(p) for p in report.skipped],
        failures=[
            {"source": str(f.source), "reason": f.reason} for f in report.failures
        ],
        by_source_type={
            key: {"concepts": c, "relations": r, "sources": s}
            for key, (c, r, s) in report.by_source_type().items()
        },
    )


_: Any = None  # keep Any import live for typed responses
