# TODO(maintainability): This file is 502 lines (limit: 400). Split into smaller modules.
"""Route handlers for contract parsing and building."""

from __future__ import annotations

import logging
from pathlib import Path

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Request,
    UploadFile,
    status,
)
from sqlalchemy.orm import Session

from pycharter import build_contract_from_store
from pycharter.api._http_errors import (
    raise_logged_bad_request,
    raise_logged_bad_request_from_exception,
    raise_logged_internal,
    raise_logged_not_found,
    raise_logged_unprocessable,
)
from pycharter.api.dependencies.database import get_db_session
from pycharter.api.dependencies.store import get_contract_store
from pycharter.api.models.contracts import (
    ContractBuildRequest,
    ContractBuildResponse,
    ContractCreateFromArtifactsRequest,
    ContractCreateMixedRequest,
    ContractListItem,
    ContractListResponse,
    ContractParseRequest,
    ContractParseResponse,
    ContractUpdateRequest,
    ContractVersionItem,
    ContractVersionListResponse,
)
from pycharter.api.services import contract_service
from pycharter.api.services.contract_parse_service import (
    contract_to_list_item,
    delete_contract_by_id,
    get_contract_by_id,
    list_all_contracts,
    list_versions_by_name,
    parse_contract_dict,
    parse_contract_from_upload,
    unwrap_contract_data,
)
from pycharter.api.services.contract_service import (
    ArtifactNotFoundError,
    ContractBuildError,
    ContractConflictError,
    ContractNotFoundError,
)
from pycharter.contract_store import ContractStoreClient
from pycharter.events import ChangeBus, ChangeEvent

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Contracts"])


def _to_item(data: dict) -> ContractListItem:
    """Convert a service-layer dict to a ContractListItem response model."""
    return ContractListItem(**data)


def _get_bus(request: Request) -> ChangeBus:
    """Retrieve the ChangeBus from application state."""
    return request.app.state.change_bus


def _publish_contract_event(
    bus: ChangeBus,
    action: str,
    resource_id: str,
    revision: int,
) -> None:
    """Publish a contract change event to the bus.

    Args:
        bus: The application change bus.
        action: One of ``created``, ``updated``, ``deleted``.
        resource_id: Contract UUID string.
        revision: Current revision counter.
    """
    bus.publish(
        ChangeEvent(
            topic=f"contract.{action}",
            action=action,
            resource_id=resource_id,
            revision=revision,
        )
    )


@router.post(
    "/contracts/parse",
    response_model=ContractParseResponse,
    status_code=status.HTTP_200_OK,
    summary="Parse a data contract",
    description="Parse a data contract dictionary into its component parts.",
    tags=["Contracts"],
)
async def parse_contract_endpoint(
    request: ContractParseRequest,
) -> ContractParseResponse:
    """Parse a data contract into its components."""
    try:
        contract_data = unwrap_contract_data(request.contract)
    except ValueError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail="Invalid contract payload (missing or malformed envelope)",
            log_event="parse_contract_unwrap_failed",
        )

    try:
        result = parse_contract_dict(contract_data)
    except ValueError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail="Failed to parse contract: schema does not match the data-contract spec",
            log_event="parse_contract_dict_failed",
        )

    return ContractParseResponse(**result)


@router.post(
    "/contracts/parse/upload",
    response_model=ContractParseResponse,
    status_code=status.HTTP_200_OK,
    summary="Parse a data contract from file upload",
    description="Parse a data contract file (YAML or JSON) uploaded via multipart/form-data.",
    tags=["Contracts"],
)
async def parse_contract_file_endpoint(
    file: UploadFile = File(..., description="Contract file (YAML or JSON)"),
    should_validate: bool = Form(
        True,
        alias="validate",
        description="Validate contract against schema before parsing",
    ),
) -> ContractParseResponse:
    """Parse a data contract from an uploaded file."""
    file_extension = Path(file.filename).suffix.lower()
    content = await file.read()

    try:
        result = parse_contract_from_upload(
            content, file_extension, validate=should_validate
        )
    except (ValueError, FileNotFoundError) as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail=(
                "Failed to parse uploaded contract file "
                "(unsupported format, malformed YAML/JSON, or schema validation error)"
            ),
            log_event="parse_contract_upload_failed",
        )
    except Exception as e:
        raise_logged_internal(
            logger,
            e,
            public_detail="Failed to parse contract file",
            log_event="parse contract file failed",
        )

    return ContractParseResponse(**result)


@router.post(
    "/contracts/{contract_id}/build",
    response_model=ContractBuildResponse,
    status_code=status.HTTP_200_OK,
    summary="Build a contract from contract ID",
    description="Reconstruct a complete data contract by fetching its linked artifacts.",
    tags=["Contracts"],
)
async def build_contract_from_id_endpoint(
    contract_id: str,
    include_metadata: bool = Query(True, description="Include metadata"),
    include_ownership: bool = Query(True, description="Include ownership"),
    include_governance: bool = Query(True, description="Include governance rules"),
    store: ContractStoreClient = Depends(get_contract_store),
    db: Session = Depends(get_db_session),
) -> ContractBuildResponse:
    """Build a contract from contract ID."""
    try:
        contract_dict = contract_service.build_contract_from_db(
            contract_id=contract_id,
            store=store,
            db=db,
            include_metadata=include_metadata,
            include_ownership=include_ownership,
            include_governance=include_governance,
        )
    except ValueError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail=f"Invalid contract id: {contract_id!r}",
            log_event="build_contract_invalid_id",
        )
    except (ContractNotFoundError, ArtifactNotFoundError) as e:
        raise_logged_not_found(
            logger,
            e,
            public_detail=(
                f"Contract {contract_id!r} not found, or one of its "
                "linked artifacts is missing"
            ),
            log_event="build_contract_not_found",
        )
    except ContractBuildError as e:
        raise_logged_unprocessable(
            logger,
            e,
            public_detail="Failed to assemble contract from its linked artifacts",
            log_event="build_contract_assembly_failed",
        )

    return ContractBuildResponse(contract=contract_dict.to_dict())


@router.post(
    "/contracts/build",
    response_model=ContractBuildResponse,
    status_code=status.HTTP_200_OK,
    summary="Build a contract from contract store",
    description="Reconstruct a complete data contract from components in the store.",
    tags=["Contracts"],
)
async def build_contract_endpoint(
    request: ContractBuildRequest,
    store: ContractStoreClient = Depends(get_contract_store),
) -> ContractBuildResponse:
    """Build a contract from contract store."""
    contract = build_contract_from_store(
        store=store,
        contract_name=request.contract_name,
        contract_version=request.contract_version,
        include_metadata=request.include_metadata,
        include_ownership=request.include_ownership,
        include_governance=request.include_governance,
    )

    if not contract:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"Contract not found: {request.contract_name!r} "
                f"@ {request.contract_version!r}"
            ),
        )

    return ContractBuildResponse(contract=contract.to_dict())


@router.post(
    "/contracts/create-from-artifacts",
    response_model=ContractListItem,
    status_code=status.HTTP_201_CREATED,
    summary="Create a data contract from existing artifacts",
    description="Create a new data contract by linking to existing artifacts.",
    tags=["Contracts"],
)
async def create_contract_from_artifacts(
    http_request: Request,
    request: ContractCreateFromArtifactsRequest,
    db: Session = Depends(get_db_session),
) -> ContractListItem:
    """Create a new data contract from existing artifacts."""
    try:
        new_contract = contract_service.create_from_existing_artifacts(request, db)
    except ContractConflictError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "A contract with this name and version already exists. "
                "Bump the version or update the existing contract instead."
            ),
        )
    except ArtifactNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                "One or more of the referenced artifacts (schema / ontology / "
                "rules) could not be found in the store."
            ),
        )
    except RuntimeError:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create contract from existing artifacts",
        )

    item = contract_to_list_item(new_contract)
    _publish_contract_event(
        _get_bus(http_request),
        "created",
        item["id"],
        item["revision"],
    )
    return _to_item(item)


@router.post(
    "/contracts/create-mixed",
    response_model=ContractListItem,
    status_code=status.HTTP_201_CREATED,
    summary="Create a data contract with mixed artifacts",
    description="Create a new data contract with a mix of new and existing artifacts.",
    tags=["Contracts"],
)
async def create_contract_mixed(
    http_request: Request,
    request: ContractCreateMixedRequest,
    store: ContractStoreClient = Depends(get_contract_store),
    db: Session = Depends(get_db_session),
) -> ContractListItem:
    """Create a new data contract with mixed artifacts."""
    try:
        new_contract = contract_service.create_mixed(request, store, db)
    except ContractConflictError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "A contract with this name and version already exists. "
                "Bump the version or update the existing contract instead."
            ),
        )
    except ArtifactNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                "One or more of the referenced artifacts (schema / ontology / "
                "rules) could not be found in the store."
            ),
        )
    except ValueError as exc:
        # ValueError here originates from pycharter.contract_parser.parser
        # validators, which author user-actionable messages in-tree; surface
        # the validator text via extra_safe_types so the client can display
        # the schema violation rather than a generic fallback.
        raise_logged_bad_request_from_exception(
            logger,
            exc,
            log_event="create_contract_mixed_value_error",
            fallback_detail="Failed to create contract: schema validation error",
            extra_safe_types=(ValueError,),
        )
    except RuntimeError:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create contract with mixed artifacts",
        )

    item = contract_to_list_item(new_contract)
    _publish_contract_event(
        _get_bus(http_request),
        "created",
        item["id"],
        item["revision"],
    )
    return _to_item(item)


@router.get(
    "/contracts",
    response_model=ContractListResponse,
    status_code=status.HTTP_200_OK,
    summary="List data contracts",
    description="Get a list of all data contracts stored in the database.",
    tags=["Contracts"],
)
async def list_contracts(
    db: Session = Depends(get_db_session),
) -> ContractListResponse:
    """List all data contracts from the database."""
    try:
        items = list_all_contracts(db)
    except Exception as e:
        logger.error("Error listing contracts: %s", e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list contracts: {e}",
        )

    return ContractListResponse(
        contracts=[ContractListItem(**item) for item in items],
        total=len(items),
    )


@router.get(
    "/contracts/{contract_id}",
    response_model=ContractListItem,
    status_code=status.HTTP_200_OK,
    summary="Get data contract by ID",
    description="Retrieve a specific data contract from the database by its ID.",
    tags=["Contracts"],
)
async def get_contract(
    contract_id: str,
    db: Session = Depends(get_db_session),
) -> ContractListItem:
    """Get a specific data contract by ID."""
    try:
        contract = get_contract_by_id(db, contract_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid contract ID format: {contract_id}",
        ) from None

    return _to_item(contract_to_list_item(contract))


@router.put(
    "/contracts/{contract_id}",
    response_model=ContractListItem,
    status_code=status.HTTP_200_OK,
    summary="Update data contract",
    description="Update contract metadata (name, version, status, description).",
    tags=["Contracts"],
)
async def update_contract(
    contract_id: str,
    request: ContractUpdateRequest,
    http_request: Request,
    db: Session = Depends(get_db_session),
) -> ContractListItem:
    """Update a data contract's metadata."""
    if request.expected_revision is not None:
        from pycharter.api.services.contract_parse_service import (
            get_contract_by_id as _get,
        )

        current = _get(db, contract_id)
        current_rev = getattr(current, "revision", 1) or 1
        if current_rev != request.expected_revision:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                    f"Revision mismatch: expected "
                    f"{request.expected_revision}, "
                    f"current is {current_rev}"
                ),
            )

    try:
        updated = contract_service.update_fields(contract_id, request, db)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=("Invalid update payload (bad contract id or unsupported field)"),
        )
    except (ContractNotFoundError, ArtifactNotFoundError):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"Contract {contract_id!r} not found, or one of its "
                "linked artifacts is missing"
            ),
        )
    except ContractConflictError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Update conflicts with the current contract state "
                "(e.g. name+version already taken by another contract)"
            ),
        )
    except RuntimeError:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update contract {contract_id!r}",
        )

    item = contract_to_list_item(updated)
    _publish_contract_event(
        _get_bus(http_request),
        "updated",
        item["id"],
        item["revision"],
    )
    return _to_item(item)


@router.delete(
    "/contracts/{contract_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete data contract",
    description="Delete a data contract by ID.",
    tags=["Contracts"],
)
async def delete_contract(
    contract_id: str,
    http_request: Request,
    db: Session = Depends(get_db_session),
) -> None:
    """Delete a data contract by ID."""
    try:
        delete_contract_by_id(db, contract_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(f"Invalid contract ID format: {contract_id}"),
        ) from None
    except RuntimeError:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete contract {contract_id!r}",
        )

    _publish_contract_event(
        _get_bus(http_request),
        "deleted",
        contract_id,
        revision=0,
    )


@router.get(
    "/contracts/versions/{contract_name}",
    response_model=ContractVersionListResponse,
    status_code=status.HTTP_200_OK,
    summary="List versions of a contract",
    description="Get all versions of a data contract by name.",
    tags=["Contracts"],
)
async def list_contract_versions(
    contract_name: str,
    db: Session = Depends(get_db_session),
) -> ContractVersionListResponse:
    """List all versions of a contract by name."""
    try:
        versions = list_versions_by_name(db, contract_name)
    except Exception as e:
        logger.error("Error listing versions for %s: %s", contract_name, e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list contract versions: {e}",
        )

    return ContractVersionListResponse(
        name=contract_name,
        versions=[ContractVersionItem(**v) for v in versions],
        total=len(versions),
    )
