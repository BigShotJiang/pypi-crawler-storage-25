"""Recent-activity feed for the ontology dashboard.

Aggregates the last N events across the four user-facing surfaces the
governance loop produces:

- **Ingest runs** — grouped by ``(scheme_id, source_uri)`` using the
  oldest ``SuggestionModel.created_at`` in each group as the event
  timestamp. Reports how many candidates were produced + by which
  origin.
- **Accepts** — materialised concepts (``ConceptModel.created_at`` on
  rows whose origin is extractor-authored, i.e. not ``human``).
- **Dismisses** — ``SuggestionModel`` rows with
  ``status="dismissed"``.
- **Proposal merges** — branch-PR merges from ``ProposalModel`` so
  users see both governance flows on one feed.

All four event types share a compact ``ActivityEvent`` shape so the UI
renders a single list with type-specific icons + deep links. The feed
is intentionally read-only and best-effort: a missing proposal table
or absent scheme_id filter degrades to "no results", never to a 500.
"""

from __future__ import annotations

import logging
import uuid as uuid_mod
from collections import defaultdict
from datetime import datetime
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from fastapi import Query as Q
from pydantic import BaseModel, Field
from sqlalchemy import desc

from pycharter.api.dependencies import get_db_session
from pycharter.db.models.semantic.concept import ConceptModel
from pycharter.db.models.semantic.suggestion import SuggestionModel

router = APIRouter(tags=["Semantic - Activity"])
logger = logging.getLogger(__name__)


EventKind = Literal[
    "ingest",
    "accept",
    "dismiss",
    "proposal_merged",
]


class ActivityEvent(BaseModel):
    """One row in the activity feed."""

    kind: EventKind
    at: str = Field(
        ...,
        description="ISO-8601 timestamp of the event.",
    )
    title: str = Field(
        ...,
        description="Short human-readable summary, e.g. 'Ingested glossary.md'.",
    )
    subtitle: str | None = Field(
        default=None,
        description="Secondary line, e.g. '12 concepts · docs.markdown'.",
    )
    origin: str | None = Field(
        default=None,
        description="Origin enum value when the event came from a governed row.",
    )
    source_uri: str | None = None
    actor: str | None = None
    scheme_id: str | None = None
    detail_href: str | None = Field(
        default=None,
        description=(
            "Deep link into the UI: a pipeline run, a concept detail, a "
            "suggestion detail, or a proposal detail. Null when no "
            "per-event page exists."
        ),
    )
    count: int | None = Field(
        default=None,
        description="Event-kind-specific count — e.g. suggestions per ingest.",
    )


class ActivityFeedResponse(BaseModel):
    """Paged activity feed."""

    items: list[ActivityEvent]
    total: int


@router.get("", response_model=ActivityFeedResponse)
async def list_activity(
    scheme_id: str | None = Q(
        default=None, description="Filter events to this scheme UUID."
    ),
    limit: int = Q(default=20, ge=1, le=100),
    session=Depends(get_db_session),
) -> ActivityFeedResponse:
    """Return the last ``limit`` activity events across the governance loop."""
    scheme_uuid: uuid_mod.UUID | None = None
    if scheme_id:
        try:
            scheme_uuid = uuid_mod.UUID(scheme_id)
        except ValueError as exc:
            raise HTTPException(
                status_code=422, detail="scheme_id must be a UUID"
            ) from exc

    ingests = _ingest_events(session, scheme_uuid=scheme_uuid, limit=limit)
    accepts = _accept_events(session, scheme_uuid=scheme_uuid, limit=limit)
    dismisses = _dismiss_events(session, scheme_uuid=scheme_uuid, limit=limit)
    proposals = _proposal_merge_events(session, limit=limit)

    events = sorted(
        [*ingests, *accepts, *dismisses, *proposals],
        key=lambda e: e.at,
        reverse=True,
    )[:limit]
    return ActivityFeedResponse(items=events, total=len(events))


# -----------------------------------------------------------------------------
# Event builders
# -----------------------------------------------------------------------------


def _ingest_events(
    session,
    *,
    scheme_uuid: uuid_mod.UUID | None,
    limit: int,
) -> list[ActivityEvent]:
    """Group suggestions by (scheme, source_uri) → one ingest event per batch."""
    query = session.query(SuggestionModel).order_by(desc(SuggestionModel.created_at))
    if scheme_uuid is not None:
        query = query.filter(SuggestionModel.scheme_id == scheme_uuid)
    # Grab a generous window; we bucket below then slice to the limit.
    rows = query.limit(max(limit * 5, 100)).all()

    buckets: dict[tuple[str, str], list[SuggestionModel]] = defaultdict(list)
    for row in rows:
        key = (str(row.scheme_id), row.source_uri)
        buckets[key].append(row)

    events: list[ActivityEvent] = []
    for (scheme_id, source_uri), bucket in buckets.items():
        bucket.sort(key=lambda r: r.created_at or datetime.min)
        first = bucket[0]
        origins = {r.origin for r in bucket}
        origin_label = next(iter(origins)) if len(origins) == 1 else "mixed"
        filename = source_uri.rsplit("/", 1)[-1] or source_uri
        events.append(
            ActivityEvent(
                kind="ingest",
                at=(first.created_at or datetime.now()).isoformat(),
                title=f"Ingested {filename}",
                subtitle=f"{len(bucket)} candidates · {bucket[0].source_type}",
                origin=origin_label,
                source_uri=source_uri,
                actor=first.created_by,
                scheme_id=scheme_id,
                detail_href=(f"/ontology/suggestions?source_uri={source_uri}"),
                count=len(bucket),
            )
        )
    return events


def _accept_events(
    session,
    *,
    scheme_uuid: uuid_mod.UUID | None,
    limit: int,
) -> list[ActivityEvent]:
    """Surface recently-accepted materialised concepts."""
    query = (
        session.query(ConceptModel)
        .filter(ConceptModel.origin != "human")
        .order_by(desc(ConceptModel.created_at))
    )
    if scheme_uuid is not None:
        query = query.filter(ConceptModel.scheme_id == scheme_uuid)
    rows = query.limit(limit).all()

    events: list[ActivityEvent] = []
    for concept in rows:
        provenance = concept.provenance or {}
        events.append(
            ActivityEvent(
                kind="accept",
                at=(concept.created_at or datetime.now()).isoformat(),
                title=f"Accepted {concept.name}",
                subtitle=f"{concept.concept_type} · tier {concept.tier}",
                origin=concept.origin,
                source_uri=provenance.get("source_uri"),
                actor=provenance.get("accepted_by") or concept.created_by,
                scheme_id=str(concept.scheme_id),
                detail_href=f"/ontology/concepts?focus={concept.id}",
            )
        )
    return events


def _dismiss_events(
    session,
    *,
    scheme_uuid: uuid_mod.UUID | None,
    limit: int,
) -> list[ActivityEvent]:
    """Surface recently-dismissed suggestions."""
    query = (
        session.query(SuggestionModel)
        .filter(SuggestionModel.status == "dismissed")
        .order_by(desc(SuggestionModel.dismissed_at))
    )
    if scheme_uuid is not None:
        query = query.filter(SuggestionModel.scheme_id == scheme_uuid)
    rows = query.limit(limit).all()

    events: list[ActivityEvent] = []
    for row in rows:
        payload = row.payload or {}
        label = payload.get("name") or payload.get("concept_key") or "(unnamed)"
        events.append(
            ActivityEvent(
                kind="dismiss",
                at=(row.dismissed_at or row.updated_at or datetime.now()).isoformat(),
                title=f"Dismissed {label}",
                subtitle=f"{row.suggestion_kind} · {row.origin}",
                origin=row.origin,
                source_uri=row.source_uri,
                actor=row.dismissed_by,
                scheme_id=str(row.scheme_id),
                detail_href=f"/ontology/suggestions/{row.id}",
            )
        )
    return events


def _proposal_merge_events(session, *, limit: int) -> list[ActivityEvent]:
    """Surface recent branch-PR merges from ``ProposalModel``.

    Best-effort: if the proposal module can't be loaded (e.g. legacy
    deployments without the table) we return an empty list rather than
    failing the whole feed request.
    """
    try:
        from pycharter.db.models.semantic.proposal import ProposalModel
    except ImportError:
        return []

    try:
        rows = (
            session.query(ProposalModel)
            .filter(ProposalModel.status == "merged")
            .order_by(desc(ProposalModel.updated_at))
            .limit(limit)
            .all()
        )
    except Exception:  # pragma: no cover - defensive
        logger.exception("proposal query failed; omitting from feed")
        return []

    events: list[ActivityEvent] = []
    for proposal in rows:
        events.append(
            ActivityEvent(
                kind="proposal_merged",
                at=(
                    proposal.updated_at or proposal.created_at or datetime.now()
                ).isoformat(),
                title=f"Merged proposal: {proposal.title}",
                subtitle=f"contract {proposal.contract_id}",
                actor=proposal.updated_by or proposal.author,
                detail_href=(f"/ontology/proposals/detail?id={proposal.id}"),
            )
        )
    return events
