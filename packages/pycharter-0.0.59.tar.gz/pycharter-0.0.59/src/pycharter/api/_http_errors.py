"""HTTP error helpers: avoid leaking exception text to clients (CodeQL / disclosure).

Two tiers of exception trust:

* **Public-facing** — exceptions inheriting from :class:`PublicFacingError`, or
  types explicitly listed in ``extra_safe_types`` at a call site. Their
  ``str(exc)`` is safe to return in the HTTP ``detail`` because the message
  text is authored by this codebase (domain validation / configuration).

* **Private** — everything else (database drivers, ORMs, third-party libs,
  broad ``except Exception`` catches). Their messages can leak stack traces,
  SQL, schema details, or file paths and must never reach the client — the
  caller-supplied ``fallback_detail`` is returned instead.

The ``*_from_exception`` helpers implement this split. They always log the
full exception server-side; only the HTTP ``detail`` is gated.

When an exception is public, the HTTP body is structured::

    {"detail": {"message": "<exc text>", "code": "<ExceptionClassName>"}}

Frontend clients can surface ``detail.message`` to the user and use
``detail.code`` to distinguish error categories machine-readably.

When an exception is private, the body is the unstructured fallback::

    {"detail": "<fallback_detail>"}
"""

from __future__ import annotations

import logging
import os
from typing import Never

from fastapi import HTTPException, status


class PublicFacingError(Exception):
    """Marker base: ``str(self)`` is safe to return as HTTP ``detail``.

    Raise subclasses of this from domain validation code where the message
    is authored in this codebase and user-actionable (e.g. "Machine name
    must match ^[a-z][a-z0-9_]*$"). Do NOT inherit from this for exceptions
    that wrap driver, ORM, or third-party library errors — their text can
    leak internals.
    """


def is_development_environment() -> bool:
    return os.environ.get("ENVIRONMENT", "").lower() == "development"


def internal_error_response_body(exc: BaseException) -> dict[str, str]:
    """JSON body for unhandled 500s: generic in production; optional detail in development."""
    body: dict[str, str] = {"error": "Internal server error"}
    if is_development_environment():
        body["message"] = str(exc)
        body["type"] = type(exc).__name__
    return body


def _structured_public_detail(exc: BaseException) -> dict[str, str]:
    """Structured HTTP detail body for a vetted public-facing exception."""
    return {"message": str(exc), "code": type(exc).__name__}


def _is_public_facing(
    exc: BaseException, extra_safe_types: tuple[type[BaseException], ...]
) -> bool:
    return isinstance(exc, PublicFacingError) or isinstance(exc, extra_safe_types)


def raise_logged_http_exception(
    logger: logging.Logger,
    exc: BaseException,
    *,
    status_code: int,
    public_detail: str,
    log_event: str,
) -> Never:
    """Log *exc* server-side and raise ``HTTPException`` with a fixed *public_detail*.

    Use this when the exception is known to be private (broad ``except``,
    driver errors) — the caller supplies a safe message verbatim.
    """
    logger.exception("%s", log_event, exc_info=exc)
    raise HTTPException(status_code=status_code, detail=public_detail) from exc


def raise_logged_from_exception(
    logger: logging.Logger,
    exc: BaseException,
    *,
    status_code: int,
    fallback_detail: str,
    log_event: str,
    extra_safe_types: tuple[type[BaseException], ...] = (),
) -> Never:
    """Log *exc* and raise ``HTTPException``; surface exc text only when public.

    Public = ``isinstance(exc, PublicFacingError)`` OR ``exc`` is an instance
    of any type in ``extra_safe_types``. Public path returns a structured
    detail body :func:`_structured_public_detail`; private path returns
    ``fallback_detail`` verbatim.

    Using a variable rather than a literal ``str(exc)`` in the ``detail``
    argument is intentional: the pre-commit hook that forbids the literal
    ``detail`` + ``=str(`` pattern in ``api/`` sources treats this helper
    as the single audited escape hatch, and all other code paths remain
    blocked from leaking raw exception text.
    """
    logger.exception("%s", log_event, exc_info=exc)
    if _is_public_facing(exc, extra_safe_types):
        detail: str | dict[str, str] = _structured_public_detail(exc)
    else:
        detail = fallback_detail
    raise HTTPException(status_code=status_code, detail=detail) from exc


def raise_logged_bad_request(
    logger: logging.Logger,
    exc: BaseException,
    *,
    public_detail: str,
    log_event: str,
) -> Never:
    raise_logged_http_exception(
        logger,
        exc,
        status_code=status.HTTP_400_BAD_REQUEST,
        public_detail=public_detail,
        log_event=log_event,
    )


def raise_logged_not_found(
    logger: logging.Logger,
    exc: BaseException,
    *,
    public_detail: str,
    log_event: str,
) -> Never:
    raise_logged_http_exception(
        logger,
        exc,
        status_code=status.HTTP_404_NOT_FOUND,
        public_detail=public_detail,
        log_event=log_event,
    )


def raise_logged_conflict(
    logger: logging.Logger,
    exc: BaseException,
    *,
    public_detail: str,
    log_event: str,
) -> Never:
    raise_logged_http_exception(
        logger,
        exc,
        status_code=status.HTTP_409_CONFLICT,
        public_detail=public_detail,
        log_event=log_event,
    )


def raise_logged_unprocessable(
    logger: logging.Logger,
    exc: BaseException,
    *,
    public_detail: str,
    log_event: str,
) -> Never:
    raise_logged_http_exception(
        logger,
        exc,
        status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
        public_detail=public_detail,
        log_event=log_event,
    )


def raise_logged_forbidden(
    logger: logging.Logger,
    exc: BaseException,
    *,
    public_detail: str,
    log_event: str,
) -> Never:
    raise_logged_http_exception(
        logger,
        exc,
        status_code=status.HTTP_403_FORBIDDEN,
        public_detail=public_detail,
        log_event=log_event,
    )


def raise_logged_service_unavailable(
    logger: logging.Logger,
    exc: BaseException,
    *,
    public_detail: str,
    log_event: str,
) -> Never:
    raise_logged_http_exception(
        logger,
        exc,
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        public_detail=public_detail,
        log_event=log_event,
    )


def raise_logged_internal(
    logger: logging.Logger,
    exc: BaseException,
    *,
    public_detail: str,
    log_event: str,
) -> Never:
    raise_logged_http_exception(
        logger,
        exc,
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        public_detail=public_detail,
        log_event=log_event,
    )


def raise_logged_bad_request_from_exception(
    logger: logging.Logger,
    exc: BaseException,
    *,
    log_event: str,
    fallback_detail: str = "Invalid request",
    extra_safe_types: tuple[type[BaseException], ...] = (),
) -> Never:
    raise_logged_from_exception(
        logger,
        exc,
        status_code=status.HTTP_400_BAD_REQUEST,
        fallback_detail=fallback_detail,
        log_event=log_event,
        extra_safe_types=extra_safe_types,
    )


def raise_logged_not_found_from_exception(
    logger: logging.Logger,
    exc: BaseException,
    *,
    log_event: str,
    fallback_detail: str = "Resource not found",
    extra_safe_types: tuple[type[BaseException], ...] = (),
) -> Never:
    raise_logged_from_exception(
        logger,
        exc,
        status_code=status.HTTP_404_NOT_FOUND,
        fallback_detail=fallback_detail,
        log_event=log_event,
        extra_safe_types=extra_safe_types,
    )


def raise_logged_conflict_from_exception(
    logger: logging.Logger,
    exc: BaseException,
    *,
    log_event: str,
    fallback_detail: str = "Request conflicts with current state",
    extra_safe_types: tuple[type[BaseException], ...] = (),
) -> Never:
    raise_logged_from_exception(
        logger,
        exc,
        status_code=status.HTTP_409_CONFLICT,
        fallback_detail=fallback_detail,
        log_event=log_event,
        extra_safe_types=extra_safe_types,
    )


def raise_logged_unprocessable_from_exception(
    logger: logging.Logger,
    exc: BaseException,
    *,
    log_event: str,
    fallback_detail: str = "Request payload is unprocessable",
    extra_safe_types: tuple[type[BaseException], ...] = (),
) -> Never:
    raise_logged_from_exception(
        logger,
        exc,
        status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
        fallback_detail=fallback_detail,
        log_event=log_event,
        extra_safe_types=extra_safe_types,
    )


def raise_logged_internal_from_exception(
    logger: logging.Logger,
    exc: BaseException,
    *,
    log_event: str,
    fallback_detail: str = "Internal server error",
    extra_safe_types: tuple[type[BaseException], ...] = (),
) -> Never:
    raise_logged_from_exception(
        logger,
        exc,
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        fallback_detail=fallback_detail,
        log_event=log_event,
        extra_safe_types=extra_safe_types,
    )
