"""Server config table rows and PATCH for ``pycharter.cfg`` (admin settings UI).

Aligned with pystator ``server_config_editor``: strict allow-list, env lock, atomic writes.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pycharter import __version__ as pycharter_version
from pycharter.config import (
    get_api_url,
    get_database_url,
    get_ui_app_name,
    get_ui_theme,
)
from pycharter.config.auth import get_auth_service_url, is_auth_disabled
from pycharter.config.cfg_file_update import (
    MIRROR_TO_USER_SCOPED_SECTIONS,
    config_file_path_display,
    env_overrides,
    merge_and_write,
    normalize_bool_for_cfg,
    normalize_float_for_cfg,
    normalize_int_for_cfg,
    read_cfg_option,
    resolve_config_path_for_write,
    resolve_user_scoped_cfg_path_for_write,
)
from pycharter.worker.config import WorkerConfig

_MAX_PATCH_KEYS = 64

PATCHABLE: dict[str, tuple[str, str]] = {
    "PYCHARTER_UI_APP_NAME": ("ui", "string"),
    "PYCHARTER_UI_THEME": ("ui", "string"),
    "PYCHARTER_API_URL": ("api", "string"),
    "PYCHARTER_DATABASE_URL": ("database", "string"),
    "PYCHARTER_WORKER_DB_URL": ("worker", "string"),
    "PYCHARTER_WORKER_POLL_INTERVAL_MS": ("worker", "int_min_1"),
    "PYCHARTER_WORKER_CONCURRENCY": ("worker", "int_min_1"),
    "PYCHARTER_WORKER_DRAIN_TIMEOUT_S": ("worker", "int_min_1"),
    "PYCHARTER_WORKER_MAX_ATTEMPTS": ("worker", "int_min_1"),
    "PYCHARTER_WORKER_CLAIM_LEASE_TIMEOUT_S": ("worker", "int_min_1"),
    "PYCHARTER_WORKER_RETRY_BACKOFF_BASE_MS": ("worker", "int_min_1"),
    "PYCHARTER_WORKER_RETRY_BACKOFF_MAX_MS": ("worker", "int_min_1"),
    "PYCHARTER_WORKER_DLQ_ENABLED": ("worker", "bool"),
    "PYCHARTER_WORKER_DLQ_DATABASE_URL": ("worker", "string"),
    "PYCHARTER_WORKER_DLQ_TABLE_NAME": ("worker", "string"),
}


def _auth_mode_summary() -> str:
    if is_auth_disabled():
        return "open_no_login"
    if get_auth_service_url():
        return "external_oidc"
    return "builtin_jwt"


def _auth_label() -> str:
    mode = _auth_mode_summary()
    if mode == "open_no_login":
        return "Open (no login)"
    if mode == "external_oidc":
        return "External OAuth/OIDC"
    return "Built-in JWT users"


def _mask_database_url(url: str | None) -> str | None:
    if not url or "@" not in url:
        return url
    parts = url.split("@", 1)
    if ":" in parts[0] and "://" in parts[0]:
        user_pass = parts[0].split("://", 1)[1]
        if ":" in user_pass:
            user, _ = user_pass.split(":", 1)
            return parts[0].split("://", 1)[0] + "://" + user + ":****@" + parts[1]
    return url


def _database_driver_kind(url: str | None) -> str:
    if not url or not url.strip():
        return "sqlite_default"
    u = url.strip().lower()
    if u.startswith("sqlite"):
        return "sqlite"
    if u.startswith(("postgresql", "postgres")):
        return "postgresql"
    if u.startswith("mysql"):
        return "mysql"
    return "other"


def _worker_dlq_fields(wc: WorkerConfig) -> dict[str, Any]:
    if not wc.dlq_enabled:
        return {
            "dlq_enabled": False,
            "dlq_persistence": "disabled",
            "dlq_table_name": wc.dlq_table_name,
            "dlq_database_url_masked": None,
        }
    return {
        "dlq_enabled": True,
        "dlq_persistence": "database",
        "dlq_table_name": wc.dlq_table_name,
        "dlq_database_url_masked": _mask_database_url(wc.resolve_dlq_database_url()),
    }


def _row(
    *,
    row_id: str,
    env_key: str,
    section: str,
    kind: str,
    effective_display: str,
    source_hint: str = "",
    editable: bool = True,
) -> dict[str, Any]:
    locked = bool(env_key) and env_overrides(env_key)
    cfg_v = read_cfg_option(section, env_key) if env_key and section else None
    patch_ok = bool(env_key and env_key in PATCHABLE and editable)
    return {
        "id": row_id,
        "env_key": env_key or None,
        "section": section,
        "kind": kind,
        "effective_display": effective_display,
        "source_hint": source_hint,
        "env_locked": locked,
        "cfg_value": cfg_v,
        "editable": patch_ok and not locked,
    }


def build_server_config_rows() -> list[dict[str, Any]]:
    raw_db = get_database_url()
    wc = WorkerConfig()
    dlq = _worker_dlq_fields(wc)
    rows: list[dict[str, Any]] = []
    rows.append(
        _row(
            row_id="ui_app_name",
            env_key="PYCHARTER_UI_APP_NAME",
            section="ui",
            kind="string",
            effective_display=get_ui_app_name(),
            source_hint="env overrides [ui]",
        )
    )
    rows.append(
        _row(
            row_id="ui_theme",
            env_key="PYCHARTER_UI_THEME",
            section="ui",
            kind="string",
            effective_display=get_ui_theme(),
            source_hint="env overrides [ui]",
        )
    )
    rows.append(
        _row(
            row_id="release_version",
            env_key="",
            section="release",
            kind="readonly",
            effective_display=pycharter_version or "—",
            editable=False,
        )
    )
    rows.append(
        _row(
            row_id="api_url",
            env_key="PYCHARTER_API_URL",
            section="api",
            kind="string",
            effective_display=get_api_url(),
            source_hint="env overrides [api]",
        )
    )
    rows.append(
        _row(
            row_id="auth_mode",
            env_key="",
            section="[auth]",
            kind="readonly",
            effective_display=_auth_label(),
            editable=False,
        )
    )
    rows.append(
        _row(
            row_id="database_url",
            env_key="PYCHARTER_DATABASE_URL",
            section="database",
            kind="password",
            effective_display=_mask_database_url(raw_db) or "(default sqlite)",
            source_hint="env overrides [database]; may also use alembic.ini",
        )
    )
    rows.append(
        _row(
            row_id="database_driver",
            env_key="",
            section="[database]",
            kind="readonly",
            effective_display=f"Driver: {_database_driver_kind(raw_db)}",
            editable=False,
        )
    )
    rows.append(
        _row(
            row_id="worker_db_url",
            env_key="PYCHARTER_WORKER_DB_URL",
            section="worker",
            kind="password",
            effective_display=_mask_database_url(wc.db_url)
            or "(inherits database_url)",
            source_hint="env overrides [worker]",
        )
    )
    rows.append(
        _row(
            row_id="worker_poll_interval_ms",
            env_key="PYCHARTER_WORKER_POLL_INTERVAL_MS",
            section="worker",
            kind="number",
            effective_display=str(wc.poll_interval_ms),
            source_hint="env overrides [worker]",
        )
    )
    rows.append(
        _row(
            row_id="worker_concurrency",
            env_key="PYCHARTER_WORKER_CONCURRENCY",
            section="worker",
            kind="number",
            effective_display=str(wc.concurrency),
            source_hint="env overrides [worker]",
        )
    )
    rows.append(
        _row(
            row_id="worker_drain_timeout_s",
            env_key="PYCHARTER_WORKER_DRAIN_TIMEOUT_S",
            section="worker",
            kind="number",
            effective_display=str(wc.drain_timeout_s),
            source_hint="env overrides [worker]",
        )
    )
    rows.append(
        _row(
            row_id="worker_max_attempts",
            env_key="PYCHARTER_WORKER_MAX_ATTEMPTS",
            section="worker",
            kind="number",
            effective_display=str(wc.max_attempts),
            source_hint="env overrides [worker]",
        )
    )
    rows.append(
        _row(
            row_id="worker_claim_lease_timeout_s",
            env_key="PYCHARTER_WORKER_CLAIM_LEASE_TIMEOUT_S",
            section="worker",
            kind="number",
            effective_display=str(wc.claim_lease_timeout_s),
            source_hint="env overrides [worker]",
        )
    )
    rows.append(
        _row(
            row_id="worker_retry_backoff_base_ms",
            env_key="PYCHARTER_WORKER_RETRY_BACKOFF_BASE_MS",
            section="worker",
            kind="number",
            effective_display=str(wc.retry_backoff_base_ms),
            source_hint="env overrides [worker]",
        )
    )
    rows.append(
        _row(
            row_id="worker_retry_backoff_max_ms",
            env_key="PYCHARTER_WORKER_RETRY_BACKOFF_MAX_MS",
            section="worker",
            kind="number",
            effective_display=str(wc.retry_backoff_max_ms),
            source_hint="env overrides [worker]",
        )
    )
    rows.append(
        _row(
            row_id="worker_dlq_enabled",
            env_key="PYCHARTER_WORKER_DLQ_ENABLED",
            section="worker",
            kind="bool",
            effective_display=str(dlq["dlq_enabled"]).lower(),
            source_hint="env overrides [worker]",
        )
    )
    rows.append(
        _row(
            row_id="worker_dlq_table_name",
            env_key="PYCHARTER_WORKER_DLQ_TABLE_NAME",
            section="worker",
            kind="string",
            effective_display=str(dlq["dlq_table_name"]),
            source_hint="env overrides [worker]",
        )
    )
    rows.append(
        _row(
            row_id="worker_dlq_database_url",
            env_key="PYCHARTER_WORKER_DLQ_DATABASE_URL",
            section="worker",
            kind="password",
            effective_display=str(dlq["dlq_database_url_masked"] or "—"),
            source_hint="env overrides [worker]",
        )
    )
    return rows


def get_server_config_bundle() -> dict[str, Any]:
    write_target = str(resolve_config_path_for_write())
    user_target = str(resolve_user_scoped_cfg_path_for_write())
    return {
        "config_file_resolved": config_file_path_display(),
        "config_write_target": write_target,
        "features_config_write_target": user_target,
        "rows": build_server_config_rows(),
    }


def apply_server_config_patch(updates: dict[str, Any]) -> tuple[Path, list[str]]:
    if not updates:
        raise ValueError("no updates provided")
    if len(updates) > _MAX_PATCH_KEYS:
        raise ValueError(f"too many keys (max {_MAX_PATCH_KEYS})")

    section_blobs: dict[str, dict[str, str]] = {}
    written: list[str] = []

    for env_key, raw in updates.items():
        if env_key not in PATCHABLE:
            raise ValueError(f"unknown or non-editable key: {env_key!r}")
        if env_overrides(env_key):
            raise ValueError(
                f"{env_key} is set in the process environment; unset it to manage via file"
            )
        section, kind = PATCHABLE[env_key]
        if kind == "bool":
            val = normalize_bool_for_cfg(raw)
        elif kind == "int_min_1":
            val = normalize_int_for_cfg(raw, min_val=1)
        elif kind == "float_0_1":
            val = normalize_float_for_cfg(raw, min_val=0.0, max_val=1.0)
        elif kind == "string":
            val = str(raw).strip()
        else:
            raise ValueError(f"internal: unknown kind {kind!r}")

        section_blobs.setdefault(section, {})[env_key] = val
        written.append(env_key)

    path = merge_and_write(section_blobs)
    mirror_sections = {
        s: section_blobs[s]
        for s in MIRROR_TO_USER_SCOPED_SECTIONS
        if s in section_blobs
    }
    if mirror_sections:
        alt = resolve_user_scoped_cfg_path_for_write()
        if alt.resolve() != path.resolve():
            merge_and_write(mirror_sections, target_path=alt)
    return path, written
