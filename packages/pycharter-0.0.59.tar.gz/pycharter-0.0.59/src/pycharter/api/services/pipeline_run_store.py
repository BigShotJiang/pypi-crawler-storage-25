"""Shared persistence helpers for pipeline run lifecycle records."""

from __future__ import annotations

import contextlib
import logging
import uuid
from datetime import UTC, datetime
from typing import Any

from sqlalchemy.orm import Session

from pycharter.db.models.pipeline_run import PipelineRunModel

logger = logging.getLogger(__name__)


TERMINAL_FAILURE_STATUSES = {"failed", "dead_letter", "cancelled"}


def _utc_now() -> datetime:
    return datetime.now(UTC)


def pipeline_run_status_from_result(result: Any) -> str:
    """Map a PipelineResult-like object to dashboard lifecycle status."""
    if getattr(result, "success", False):
        return "success"
    if getattr(result, "rows_loaded", 0) > 0:
        return "partial"
    return "failed"


def pipeline_run_status_filter(status: str) -> tuple[str, ...]:
    """Map API status filters to persisted pipeline run statuses."""
    if status == "failed":
        return tuple(TERMINAL_FAILURE_STATUSES)
    if status == "completed":
        return ("success", "partial", "failed")
    if status == "running":
        return ("running",)
    if status == "queued":
        return ("queued",)
    return (status,)


def config_snapshot_for(
    config: dict[str, Any] | None = None,
    *,
    extract_config: dict[str, Any] | None = None,
    load_config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build an auditable config snapshot for persisted run rows."""
    if config is not None:
        return dict(config)
    snapshot: dict[str, Any] = {}
    if extract_config is not None:
        snapshot["extract"] = extract_config
    if load_config is not None:
        snapshot["load"] = load_config
    return snapshot


def create_pipeline_run_record(
    db: Session,
    *,
    run_id: str,
    config_snapshot: dict[str, Any] | None = None,
    trigger: str = "api",
    pipeline_name: str | None = None,
    created_by: str | None = None,
) -> PipelineRunModel:
    """Create or update an initial queued pipeline run lifecycle row."""
    record = (
        db.query(PipelineRunModel).filter(PipelineRunModel.run_id == run_id).first()
    )
    if record is None:
        record = PipelineRunModel(id=uuid.uuid4(), run_id=run_id)
        db.add(record)
    record.pipeline_name = pipeline_name
    record.status = "queued"
    record.trigger = trigger
    record.config_snapshot = config_snapshot
    record.created_by = created_by
    record.started_at = None
    record.completed_at = None
    db.commit()
    return record


def mark_pipeline_run_running(db: Session, run_id: str) -> bool:
    """Mark a queued pipeline run as running."""
    record = (
        db.query(PipelineRunModel).filter(PipelineRunModel.run_id == run_id).first()
    )
    if record is None:
        return False
    record.status = "running"
    record.started_at = _utc_now()
    db.commit()
    return True


def mark_pipeline_run_cancelled(db: Session, run_id: str) -> bool:
    """Mark a queued/running pipeline run as cancelled."""
    record = (
        db.query(PipelineRunModel).filter(PipelineRunModel.run_id == run_id).first()
    )
    if record is None or record.status not in {"queued", "running"}:
        return False
    record.status = "cancelled"
    record.completed_at = _utc_now()
    db.commit()
    return True


def save_pipeline_result(
    db: Session,
    result: Any,
    *,
    config_snapshot: dict[str, Any] | None = None,
    extract_config: dict[str, Any] | None = None,
    load_config: dict[str, Any] | None = None,
    trigger: str = "api",
) -> None:
    """Persist a PipelineResult-like object to the pipeline_runs table.

    Failures are logged but never propagated so API callers still receive the
    pipeline result even if analytics persistence is unavailable.
    """
    try:
        run_id = result.run_id or uuid.uuid4().hex[:12]
        record = (
            db.query(PipelineRunModel).filter(PipelineRunModel.run_id == run_id).first()
        )
        if record is None:
            record = PipelineRunModel(id=uuid.uuid4(), run_id=run_id)
            db.add(record)

        pipeline_quality_passed = None
        if result.quality_report is not None:
            pipeline_quality_passed = getattr(result.quality_report, "passed", None)

        record.pipeline_name = result.pipeline_name
        record.status = pipeline_run_status_from_result(result)
        record.rows_extracted = result.rows_extracted
        record.rows_transformed = result.rows_transformed
        record.rows_loaded = result.rows_loaded
        record.rows_failed = result.rows_failed
        record.rows_quarantined = result.total_quarantined
        record.batches_processed = result.batches_processed
        record.started_at = result.start_time
        record.completed_at = result.end_time
        record.duration_seconds = result.duration_seconds
        record.contract_quality_score = None
        record.contract_quality_passed = None
        record.pipeline_quality_passed = pipeline_quality_passed
        record.extractor_type = (
            extract_config or (config_snapshot or {}).get("extract") or {}
        ).get("type")
        record.loader_type = (
            load_config or (config_snapshot or {}).get("load") or {}
        ).get("type")
        record.trigger = trigger
        record.errors = result.errors if result.errors else None
        record.batch_results = (
            [
                {
                    "batch_index": br.batch_index,
                    "rows_in": br.rows_in,
                    "rows_out": br.rows_out,
                    "rows_failed": br.rows_failed,
                    "errors": br.errors,
                }
                for br in result.batch_results
            ]
            if result.batch_results
            else None
        )
        record.config_snapshot = config_snapshot_for(
            config_snapshot,
            extract_config=extract_config,
            load_config=load_config,
        )
        db.commit()
        logger.info("Saved pipeline run %s to dashboard", run_id)
    except Exception:
        logger.warning("Failed to save pipeline run to dashboard", exc_info=True)
        with contextlib.suppress(Exception):
            db.rollback()


def mark_pipeline_run_failed(
    db: Session,
    run_id: str,
    error: str,
    *,
    config_snapshot: dict[str, Any] | None = None,
    trigger: str = "api",
) -> None:
    """Persist a terminal failure when a pipeline crashes before producing a result."""
    record = (
        db.query(PipelineRunModel).filter(PipelineRunModel.run_id == run_id).first()
    )
    if record is None:
        record = PipelineRunModel(id=uuid.uuid4(), run_id=run_id)
        db.add(record)
    record.status = "failed"
    record.trigger = trigger
    record.completed_at = _utc_now()
    record.errors = [error]
    if config_snapshot is not None:
        record.config_snapshot = config_snapshot
    db.commit()
