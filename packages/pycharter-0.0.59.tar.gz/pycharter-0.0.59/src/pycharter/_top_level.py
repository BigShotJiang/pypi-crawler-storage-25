"""Top-level ``pycharter.run`` / ``pycharter.preflight`` entry points.

These two functions are the **primary public API** for running
pipelines from external code (Airflow ``PythonOperator``, Dagster
``@asset`` body, plain scripts, Jupyter cells). They wrap
:class:`pycharter.pipeline_generator.pipeline.Pipeline` so callers
don't have to pick between ``from_file`` / ``from_dict`` /
``from_config_dir`` based on their input shape.

Both accept the same polymorphic ``config`` argument:

* ``str`` / ``Path`` to a YAML file — same as ``Pipeline.from_file``.
* ``str`` / ``Path`` to a directory — same as ``Pipeline.from_config_dir``.
* ``dict`` — same as ``Pipeline.from_dict``.
* ``list[dict]`` — wrapped as ``{"steps": [...]}`` and routed through
  ``Pipeline.from_dict``.

``run()`` is **synchronous** (uses ``Pipeline.run_sync``) and **raises
:class:`PipelineRunError` on failure when ``fail_fast=True``** so an
Airflow task fails fast and shows up in the failure UI; with
``fail_fast=False`` the failed result is returned for the caller to
inspect.

Both are thin wrappers — all real work happens in the existing
``Pipeline`` and ``preflight_steps`` machinery. We deliberately do NOT
add ``**kwargs`` passthrough: the signature is locked against the
4 input shapes only (changing it later would be SemVer-major).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pycharter.exceptions import PipelineRunError
from pycharter.pipeline_generator.pipeline import Pipeline
from pycharter.pipeline_generator.preflight import PreflightResult
from pycharter.pipeline_generator.result import PipelineResult


def run(
    config: str | Path | dict[str, Any] | list[dict[str, Any]],
    *,
    variables: dict[str, str] | None = None,
    fail_fast: bool = True,
    run_id: str | None = None,
) -> PipelineResult:
    """Run a pipeline synchronously and return its result.

    Args:
        config: One of:

            * a path (``str`` / :class:`Path`) to a YAML pipeline file;
            * a path to a directory containing ``pipeline.yaml`` (or
              ``extract.yaml`` + ``load.yaml``);
            * a parsed config dict;
            * a list of step dicts (wrapped as
              ``{"steps": <list>}``).

        variables: Optional override variables passed as
            ``extra_variables`` to the pipeline factory. ``${VAR}``
            tokens in the config get resolved against these (plus
            environment / pycharter.cfg) at parse time.
        fail_fast: When ``True`` (default), raises
            :class:`PipelineRunError` on a failed run. When ``False``,
            returns the failed :class:`PipelineResult` so the caller
            can inspect partial state.
        run_id: Optional explicit run identifier. Forwarded to
            ``Pipeline.run_sync``.

    Returns:
        A :class:`PipelineResult` with ``rows_*`` counts, per-step
        results, errors, and timing.

    Raises:
        PipelineRunError: When the run fails AND ``fail_fast=True``.
        FileNotFoundError: When a path argument doesn't exist.
        ValueError: When the config is malformed.

    Notes:
        ``run()`` is sync. If you're already inside an event loop
        (FastAPI route, Jupyter with autoawait, asyncio app), call
        ``await Pipeline.from_*(...).run()`` directly instead — the
        underlying ``run_sync`` calls ``asyncio.run`` which fails when
        a loop is already running.
    """
    pipeline = _build_pipeline(config, variables=variables)
    result = pipeline.run_sync(run_id=run_id, fail_fast=fail_fast)
    if not result.success and fail_fast:
        raise PipelineRunError(
            f"Pipeline {pipeline.name!r} failed with {len(result.errors)} error(s).",
            result=result,
        )
    return result


def preflight(
    config: str | Path | dict[str, Any] | list[dict[str, Any]],
    *,
    variables: dict[str, str] | None = None,
) -> PreflightResult:
    """Run config-side checks against a pipeline without any I/O.

    Returns a :class:`PreflightResult` with ``success`` and a list of
    :class:`PreflightIssue`. Walks every step's ``contract:`` block,
    resolves the contract reference (file or store), and collects any
    errors. No extractors are constructed; no records flow.

    Use as a CI / orchestrator gate to catch broken contract refs
    before triggering an actual run.

    Accepts the same polymorphic ``config`` shapes as :func:`run`.
    """
    pipeline = _build_pipeline(config, variables=variables)
    return pipeline.preflight()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _build_pipeline(
    config: str | Path | dict[str, Any] | list[dict[str, Any]],
    *,
    variables: dict[str, str] | None,
) -> Pipeline:
    """Dispatch to the right ``Pipeline.from_*`` based on input shape.

    Path-shaped strings have to choose between :meth:`Pipeline.from_file`
    and :meth:`Pipeline.from_config_dir` based on whether the path
    points at a file or directory; we resolve once here.
    """
    if isinstance(config, dict):
        return Pipeline.from_dict(config, extra_variables=variables)
    if isinstance(config, list):
        return Pipeline.from_dict({"steps": config}, extra_variables=variables)
    if isinstance(config, str | Path):
        path = Path(config)
        if not path.exists():
            msg = f"Config path not found: {path}"
            raise FileNotFoundError(msg)
        if path.is_dir():
            return Pipeline.from_config_dir(path, extra_variables=variables)
        return Pipeline.from_file(path, extra_variables=variables)
    msg = (
        "config must be a path (str | Path), a config dict, or a list of step "
        f"dicts; got {type(config).__name__}"
    )
    raise TypeError(msg)
