# Architecture of PyCharter

This document describes the philosophy and layered architecture that every
change to PyCharter must respect. Read it before contributing.

Two ideas power every package in the Optophi family:

1. **Configuration-Driven Engineering (CDE).** The domain artifacts that the
   system reasons about — in PyCharter, the data contracts, quality rules,
   pipelines, and ontology — are expressed as **configuration** (YAML / JSON),
   not as code. Code is the engine; configuration is the vocabulary. Authors
   who are not Python engineers can define contracts. Artifacts are versioned,
   diffed, reviewed, and distributed as data.
2. **Layered architecture around a stateless core.** The heart of the package
   is a pure, stateless tool API. Everything else — persistence, HTTP, UI,
   workers — is a shell that calls the core. Inner layers know nothing about
   outer layers.

These two ideas, taken together, are what make the package composable,
testable, and safely evolvable.

---

## The layered architecture

```
            ┌───────────────┐  ┌───────────────┐
            │  HTTP wrapper │  │   UI wrapper  │
            │   (FastAPI)   │  │   (Next.js)   │
            └───────┬───────┘  └───────┬───────┘
                    │                  │
                    ▼                  ▼
          ┌──────────────────────────────────┐
          │         STATELESS CORE           │
          │   (signature tool API, pure)     │
          │   domain artifacts = YAML/JSON   │
          └─────────────┬────────────────────┘
                        │
                        ▼
                ┌──────────────┐             ┌───────────────┐
                │    STORE     │ ◄──────────►│    WORKER     │
                │   (client)   │             │ (async svc)   │
                └──────┬───────┘             └───────────────┘
                       │
          ┌────────────┼────────────┐
          ▼            ▼            ▼
       SQLite      Postgres      MongoDB
      (testing)     (SQL)       (NoSQL)
```

### Layer definitions

**Stateless core.** The signature functionality of the package. Pure tool API:
inputs in, outputs out. No hidden state, no I/O, no persistence, no network,
no filesystem access beyond reading declared configuration files. The core is
what you would lift out and re-embed in any runtime.

**Store.** A persistence client that bridges the stateless core to the storage
layer. The store is *only* translation: it reads and writes domain objects to
one of three backends. It holds no business logic. Every store implementation
must support **all three backends**:

- **SQLite** — in-memory and file-backed, used for lightweight testing and
  local development.
- **Postgres** — the production SQL backend.
- **MongoDB** — the production NoSQL backend.

**HTTP wrapper.** A thin FastAPI layer (`src/pycharter/api/`) that exposes the
core's public API over HTTP. Routes validate input, call the core or store,
and return a response. They contain no business logic.

**UI wrapper.** A Next.js app (`src/pycharter/ui/`) that consumes the HTTP
wrapper. The UI's look, patterns, and shared components follow the Optophi
design style used across packages — reuse existing pieces before introducing
new ones.

**Worker.** An async, concurrent, long-running process that either monitors a
queue in the persistence layer or continuously delivers the package's
signature service. Workers consume the core's and store's public APIs; they
do not reach into internals. Long-running execution loops belong in
`src/pycharter/worker/`, while API routes enqueue/inspect work and the UI
observes or controls that work through HTTP.

---

## The two laws

### Law 1: the core is stateless

- No module-level mutable state. No singletons. No class instance state that
  persists across calls.
- No I/O inside the core: no HTTP, no DB, no filesystem writes, no network.
- The core may *read* declared configuration files at load time; that is the
  only sanctioned I/O, and even that is mediated by the parse layer.
- A session or builder object that holds per-call state is allowed as a
  convenience wrapper, provided the underlying engine is stateless and each
  call is reproducible given the same inputs.

### Law 2: domain artifacts are configuration

- If a new domain concept — a new contract shape, a new quality rule, a new
  pipeline step — is added, the first question is *can this be
  configuration?* The default answer is **yes**.
- Configuration lives in YAML or JSON, validated at load time by Pydantic
  models. Seed data lives under `data/seed/`.
- The code that loads, stores, and builds from configuration is the engine.
  The engine changes rarely; the configuration changes freely.
- A Python class that hardcodes a specific contract is almost always a bug in
  framing.

Breaking either law means the architecture has leaked. Stop and reconsider.

---

## PyCharter layer map

| Layer        | Where in the repo                                              |
|--------------|----------------------------------------------------------------|
| Core (parse) | `src/pycharter/contract_parser`, `json_schema_converter`       |
| Core (build) | `src/pycharter/contract_builder`, `pydantic_generator`,        |
|              | `runtime_validator`, `pipeline_generator`, `quality`,          |
|              | `semantic`                                                     |
| Store        | `src/pycharter/contract_store`, `semantic_store`               |
| HTTP wrapper | `src/pycharter/api/`                                           |
| UI wrapper   | `src/pycharter/ui/`                                            |
| Worker       | `src/pycharter/worker/` — validation worker, job sources,      |
|              | processors, worker config, and worker CLI integration. Future  |
|              | pipeline workers must extend this layer, not API/UI internals. |
| Config       | `data/seed/*.yaml` — reference schemas, contracts, pipelines,  |
|              | semantic definitions                                           |

---

## Three-layer lifecycle inside the core

Within the core itself, domain artifacts pass through three stages. This is
the internal rhythm of the package:

```
    parse           store             build
YAML/JSON ──► normalized ──► persisted ──► runtime artifact
              domain object                 (validator, pipeline,
                                             generated model, …)
```

- **parse** — read YAML/JSON, validate shape, produce domain objects.
- **store** — persist or retrieve those domain objects via the store client.
- **build** — construct the runtime artifact the user actually invokes
  (a validator, a generated Pydantic model, a pipeline).

A single change usually touches exactly one of these stages. Changes that
span stages deserve extra scrutiny.

---

## Cross-package integration: PyCharter ↔ PyStator

PyCharter and PyStator are designed to compose. The only sanctioned bridge
points are:

- **Lifecycle binding.** A contract's
  `metadata.governance_rules.lifecycle.state_machine_name` names the PyStator
  FSM that governs the contract's lifecycle.
- **State-aware validation.** PyCharter exposes `validate_for_state`, which
  PyStator can plug into its orchestrator as a `context_validator` so
  transitions are gated by contract conformance in the target state.

Any other coupling between the two packages is out of bounds. If a new
use case seems to need one, propose it as a new, named bridge point rather
than adding an ad-hoc import.

---

## What this architecture gives you

- **Substitutability.** The store can be swapped between SQLite, Postgres,
  and MongoDB without changing the core. The HTTP wrapper can be replaced
  by a gRPC or CLI wrapper without changing the core.
- **Testability.** The core is pure, so tests need no fixtures beyond input
  data. Integration tests run against SQLite in memory by default.
- **Extensibility without forks.** A new contract, rule, or pipeline is a
  YAML file, not a code change. Downstream users extend the package by
  writing configuration.
- **Durable public API.** Because domain shape lives in configuration, the
  Python API surface stays small and stable.

---

## What to do if a change does not fit

If a change feels like it needs to cross layers, hold state in the core, or
encode a domain artifact in Python, **stop**. Open an issue describing the
shape of the change and what the layer model is failing to express. A
deliberate architecture extension is welcome; quietly smuggling logic across a
boundary is not. Worker extensions must follow
`docs/guides/worker-roadmap-adr.md`: API, UI, DB, and worker layers stay
distinct and keep their own CLI/runtime boundaries.

See `CONTRIBUTING.md` for how to propose changes, and `.claude/skills/` for
the AI-assisted contribution skills that enforce this architecture.
