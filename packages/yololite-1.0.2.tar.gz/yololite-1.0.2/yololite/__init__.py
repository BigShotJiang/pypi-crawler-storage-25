# yololite/__init__.py
from .main import YoloLite

__version__ = "1.0.2"
__all__ = ["YoloLite"]