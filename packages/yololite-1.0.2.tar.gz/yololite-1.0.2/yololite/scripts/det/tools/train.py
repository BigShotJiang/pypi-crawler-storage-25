# train.py
import os, yaml, time, random, sys
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
import random
from tqdm.auto import tqdm
import matplotlib 
import math
import copy
matplotlib.use("Agg") 
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader, WeightedRandomSampler
from ..scripts.model.model import YOLOE
from ..scripts.model.model_n import YOLOE_Nano

from ..scripts.data.dataset import YoloDataset
from ..scripts.data.augment import get_base_transform, get_val_transform, get_lite_transform
from ..scripts.loss.loss import LossAF
from ..scripts.helpers.sanity_check import visualize_batch
from ..scripts.helpers.schedulers import build_scheduler
from ..scripts.helpers.helpers import yolo_collate, _coco_eval_from_lists,  set_seed, save_val_debug_anchorfree, _decode_batch_to_coco_dets, _xyxy_to_xywh, _write_json_atomic, _append_csv
from ..scripts.args.build_args import build_argparser, load_configs, apply_overrides
from ..scripts.data.plot_metrics import plot_metrics
from ..scripts.helpers.evaluate import evaluate_model

import torch.nn.functional as F


def seed_worker(worker_id):
    # PyTorch ger varje worker en specifik seed utifrån huvud-seeden + worker_id
    worker_seed = torch.initial_seed() % 2**32
    np.random.seed(worker_seed)
    random.seed(worker_seed)

class MultiscaleCollate:
    def __init__(self, base_size=640, enable_multiscale=True):
        self.base_size = base_size
        self.enable = enable_multiscale
        
        # Skapa möjliga storlekar i steg om 32 (t.ex. +/- 30% av basstorleken)
        lower = max(320, int(base_size * 0.7 // 32) * 32)
        upper = int(base_size * 1.3 // 32) * 32
        self.possible_sizes = list(range(lower, upper + 32, 32))

    def __call__(self, batch):
        # 1. Kör din vanliga yolo_collate för att packa ihop listan av bilder/targets
        imgs, targets = yolo_collate(batch)
        
        if not self.enable:
            return imgs, targets
            
        # 2. Välj en slumpmässig storlek för hela batchen
        target_size = random.choice(self.possible_sizes)
        
        # Kolla nuvarande storlek (beror på om din collate returnerar en lista eller tensor)
        if isinstance(imgs, list):
            imgs = torch.stack(imgs)
        current_size = imgs.shape[-1]
        
        if target_size != current_size:
            # 3. Skala om bilderna på CPU! (Drar inget VRAM, workers gör jobbet)
            imgs = F.interpolate(imgs, size=(target_size, target_size), mode='nearest')
            
            # 4. Skala om bounding boxes proportionerligt
            scale_ratio = target_size / current_size
            for t in targets:
                if "boxes" in t and t["boxes"] is not None and len(t["boxes"]) > 0:
                    t["boxes"] = t["boxes"] * scale_ratio
                    
        return imgs, targets
class CurriculumController:
    def __init__(self, criterion, warmup_end=10, strict_start=30, verbose=True):
        self.criterion = criterion
        self.warmup_end = warmup_end
        self.strict_start = strict_start
        self.verbose = verbose
        
        # --- FAS 1: Exploration (Extremt generösa startvärden) ---
        # Dessa sätts automatiskt direkt när du skapar objektet
        self.criterion.center_radius_cells = 3.5
        self.criterion.topk_limit = 35
        self.criterion.iou_cost_w = 1.0
        self.criterion.lambda_box = 3.0  
        
        if self.verbose:
            print(f"[Curriculum] Initierad. Fas 1 (Exploration) aktiv. Radie: {self.criterion.center_radius_cells}, TopK: {self.criterion.topk_limit}")

    def step(self, epoch):
        # Antar att 'epoch' börjar på 0 i din for-loop
        current_epoch = epoch + 1
        
        # --- FAS 2: Stegvis åtstramning (Exploitation) ---
        if self.warmup_end < current_epoch <= self.strict_start:
            # Beräkna hur långt vi har kommit i åtstramningsfasen (0.0 till 1.0)
            progress = (current_epoch - self.warmup_end) / (self.strict_start - self.warmup_end)
            
            # Linjär interpolering mot dina striktare (slutgiltiga) mål
            self.criterion.center_radius_cells = 3.5 - (progress * 1.0) # Landar på 2.5
            self.criterion.topk_limit = int(35 - (progress * 10))       # Landar på 25
            self.criterion.iou_cost_w = 1.0 + (progress * 0.5)          # Landar på 1.5
            self.criterion.lambda_box = 3.0 + (progress * 4.5)          # Landar på 7.5
            
            if self.verbose:
                print(f"\n[Curriculum] Stramar åt reglerna (Epoch {current_epoch}): "
                      f"Radie={self.criterion.center_radius_cells:.2f}, "
                      f"TopK={self.criterion.topk_limit}, "
                      f"IoU_w={self.criterion.iou_cost_w:.2f}")
        
        # --- FAS 3: Färdig (Säg till en gång att vi är klara) ---
        elif current_epoch == self.strict_start + 1:
            if self.verbose:
                print("\n[Curriculum] Övergång klar! Kör nu på strikta targets resten av träningen.")
class AdaptiveCriterionController:
    def __init__(self, criterion, patience=3, verbose=True):
        self.criterion = criterion
        self.patience = patience
        self.verbose = verbose
        self.bad_epochs = 0
        self.best_ap50 = -1.0

    def step(self, metrics, epoch):
        """
        metrics: dict från coco_stats (AP, AP50, AP75, APS, APM, APL, AR)
        """
        current_ap50 = metrics.get("AP50", 0)
        
        # Vi använder AP50 som huvudindikator för framsteg
        if current_ap50 > self.best_ap50:
            self.best_ap50 = current_ap50
            self.bad_epochs = 0
        else:
            self.bad_epochs += 1

        if self.bad_epochs >= self.patience:
            self._log(f"\n[Adaptive] Patience ({self.patience}) reached at epoch {epoch+1}.")
            self.adjust_parameters(metrics)
            self.bad_epochs = 0 

    def _log(self, msg):
        if self.verbose:
            print(msg)

    def adjust_parameters(self, metrics):
        # Extrahera metrics med säkerhetskoll för -1.0
        def get_safe(m_key):
            val = metrics.get(m_key, -1.0)
            return val if val >= 0 else None

        ap = get_safe("AP")
        ap50 = get_safe("AP50")
        ap75 = get_safe("AP75")
        aps = get_safe("APS")
        apm = get_safe("APM")
        apl = get_safe("APL")
        ar = get_safe("AR")

        self._log(" -> Analyzing bottleneck...")

        # 1. RECALL-ANALYS (Prio 1 för din modell)
        # Om Recall är väsentligt lägre än 0.6 eller nära AP50
        if ar is not None and ar < 0.55:
            self._log(f"    [Action] Low Recall ({ar:.3f}). Expanding search space (radius/topk).")
            self.criterion.center_radius_cells = min(4.5, self.criterion.center_radius_cells + 0.5)
            self.criterion.topk_limit = min(45, self.criterion.topk_limit + 5)

        # 2. SKALA-ANALYS (APS, APM, APL)
        # Vi räddar bara APS/APM om de faktiskt existerar (inte är None)
        if apm is not None and apl is not None:
            if apm < (apl * 0.4): # Om Medium är mindre än hälften så bra som Large
                self._log(f"    [Action] Scale imbalance: APM ({apm:.3f}) vs APL ({apl:.3f}). Relaxing Area Tol.")
                self.criterion.area_tol = min(2.0, self.criterion.area_tol + 0.1)
                self.criterion.iou_cost_w = max(1.0, self.criterion.iou_cost_w - 0.2)

        # 3. LOKALISERINGS-ANALYS (AP75 vs AP50)
        # Om vi hittar objekt men inte kan rita boxar (stor skillnad mellan 50 och 75)
        if ap50 is not None and ap75 is not None:
            ratio = ap75 / max(0.001, ap50)
            if ratio < 0.5:
                self._log(f"    [Action] Poor localization precision ({ratio:.2f}). Boosting Box Loss.")
                self.criterion.lambda_box *= 1.1
                self.criterion.iou_cost_w = min(3.5, self.criterion.iou_cost_w + 0.3)

        # 4. APS SPECIAL (Bara om det finns små objekt i setet)
        if aps is not None and aps < 0.1:
            self._log(f"    [Action] Tiny objects (APS: {aps:.3f}) need more focus. Lowering area_cells_min.")
            self.criterion.area_cells_min = max(0.5, self.criterion.area_cells_min - 0.2)

        self._log(f" -> New Config: radius={self.criterion.center_radius_cells:.1f}, "
                  f"topk={self.criterion.topk_limit}, box_w={self.criterion.lambda_box:.2f}")

def load_pretrained_weights(model, weights_path, device):
    print(f"Loading pretrained weights: {weights_path}")
    
    # 1. Ladda checkpointen
    ckpt = torch.load(weights_path, map_location=device)
    
    # Hantera om du sparat med din 'save_checkpoint_state' struktur
    if "state_dict" in ckpt:
        pretrained_dict = ckpt["state_dict"]
    else:
        pretrained_dict = ckpt

    model_dict = model.state_dict()

    # 2. Filtrera bort det som inte matchar
    # Vi behåller bara de lager som finns i båda och har samma dimensioner
    # Detta kastar automatiskt bort 'head.out.cls' etc. eftersom num_classes ändrats
    smart_dict = {
        k: v for k, v in pretrained_dict.items()
        if k in model_dict and v.shape == model_dict[k].shape
    }

    # 3. Logga vad som hände så du har koll
    skipped_keys = [k for k in pretrained_dict.keys() if k not in smart_dict]
    print(f"✓ Matched {len(smart_dict)} layers.")
    print(f"✗ Skipped {len(skipped_keys)} layers (new head).")

    # 4. Uppdatera och ladda
    model_dict.update(smart_dict)
    model.load_state_dict(model_dict)
    
    return model
class ModelEMA:
    def __init__(self, model, total_updates, decay=0.999):
        self.ema = copy.deepcopy(model).eval()
        self.updates = 0
        self.decay = decay
      
        self.warmup_limit = min(2000, total_updates // 5) 
        
        for p in self.ema.parameters():
            p.requires_grad_(False)

    @staticmethod
    def _clone_model(model):
        import copy
        return copy.deepcopy(model)

    @torch.no_grad()
    def update(self, model):
        self.updates += 1
        # Dynamisk decay-kurva
        d = self.decay * (1 - math.exp(-self.updates / self.warmup_limit))

        msd = model.state_dict()
        for k, v in self.ema.state_dict().items():
            if v.dtype.is_floating_point:
                # Standard EMA-formel: ema = ema * d + model * (1 - d)
                v.mul_(d).add_(msd[k].detach(), alpha=1 - d)
            else:
                v.copy_(msd[k])

    def state_dict(self):
        return self.ema.state_dict()

def save_checkpoint_state(model, metrics: dict, class_names, config: dict, out_path: str, num_anchors_per_level: tuple):
    cpu_state = {k: v.cpu() for k, v in model.state_dict().items()}
    meta = {
        "names": list(class_names) if class_names else None,
        "num_classes": int(config["model"]["num_classes"]),
        "img_size": int(config["training"].get("img_size", 640)),
        "arch": config["model"]["arch"],
        "backbone": config["model"]["backbone"],
        "num_anchors_per_level": num_anchors_per_level,
        "config": config,  
    }
    torch.save({"state_dict": cpu_state, "meta": meta}, out_path)

def _build_num_anchors(use_p6, use_p2, num):
    if use_p2 and use_p6:
        return (num, num, num, num, num)
    if use_p2 or use_p6:
        return (num, num, num, num)
    else:
        return (num, num, num)


# =============== Main ===============
def train_engine(config):

    ap = build_argparser()
   

    # 3) Seed
    set_seed(config["training"].get("seed", 1337))

    # 4) (valfritt) skriv ut sammanställd config till log_dir för spårbarhet
    log_dir = config["logging"].get("log_dir", "runs/default")
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    with open(Path(log_dir) / "merged_config.yaml", "w", encoding="utf-8") as f:
        yaml.safe_dump(config, f, sort_keys=False, allow_unicode=True)
    _DEVICE = config["training"]["device"]
    DEVICE = f"cuda:{_DEVICE}" if torch.cuda.is_available() else "cpu"
    torch.backends.cudnn.benchmark = True if DEVICE == "cuda" else False

    NUM_CLASSES = int(config["model"]["num_classes"])
    IMG_SIZE = int(config["training"]["img_size"])
    use_augment = bool(config["training"]["augment"])   
    # Datasets & loaders
    val_resize = 1.0 if config["training"]["resize"] else 0.0
    train_resize = 1.0 if config["training"]["resize"] else 0.2
    
    g = torch.Generator()
    g.manual_seed(config["training"].get("seed", 1337))
    
    train_ds = YoloDataset(
        config["dataset"]["train_images"],
        config["dataset"]["train_labels"],
        img_size=IMG_SIZE,
        is_train=True if use_augment else False,
        transforms=get_base_transform(IMG_SIZE) if use_augment else get_val_transform(IMG_SIZE),
        mosaic_p=config["training"]["mosaic_p"]
    )
    img_weights = train_ds.get_image_weights()
    val_ds = YoloDataset(
        config["dataset"]["val_images"],
        config["dataset"]["val_labels"],
        img_size=IMG_SIZE,
        is_train=False,
        transforms=get_val_transform(IMG_SIZE, val_resize)
    )
    # 2. Hämta vikterna från datasetet
    img_weights = train_ds.get_image_weights()
    topk = torch.topk(img_weights, k=min(10, len(img_weights)))
    print("Image weights stats:",
      f"min={img_weights.min().item():.3f}",
      f"mean={img_weights.mean().item():.3f}",
      f"max={img_weights.max().item():.3f}")
    print("Top weighted images:")
    for w, idx in zip(topk.values.tolist(), topk.indices.tolist()):
        print(idx, w, train_ds.img_files[idx])
    # 3. Skapa samplern
    # num_samples=len(train_ds) betyder att en epoch fortfarande är lika lång
    sampler = WeightedRandomSampler(
        weights=img_weights, 
        num_samples=len(train_ds), 
        replacement=True  # Gör att sällsynta bilder kan väljas flera gånger per epoch
    )
    use_ema = config["training"]["ema"]
    nw = int(config["training"].get("num_workers", 4))
    # 4. Uppdatera DataLoader
   
    
    train_loader = DataLoader(
    train_ds,
    batch_size=config["training"]["batch_size"],
    sampler=sampler,               
    shuffle=False,                 
    num_workers=nw,
    pin_memory=True,
    persistent_workers=(nw > 0),
    collate_fn=yolo_collate,
    drop_last=False,
    worker_init_fn=seed_worker,  # <--- LÄGG TILL HÄR
    generator=g
    )
    val_loader = DataLoader(
            val_ds,
            batch_size=config["training"]["batch_size"],
            shuffle=False,
            num_workers=0,
            pin_memory=True,
            collate_fn=yolo_collate,         # <-- INTE lambda
            drop_last=False,
        )
    
    

    batch_size = config["training"]["batch_size"]
    num = config["model"]["num_anchors_per_level"]
    num_anchors_per_level = _build_num_anchors(config["training"]["use_p6"], config["training"]["use_p2"], num)
    
  
    if config["model"]["arch"].lower() == 'yoloe':
        model = YOLOE(
            backbone=config["model"]["backbone"],
            num_classes=NUM_CLASSES,
            fpn_channels=config["model"]["fpn_channels"],
            num_anchors_per_level= num_anchors_per_level, # t.ex. (3,3,3)
            depth_multiple=config["model"].get("depth_multiple", 1.0),
            width_multiple=config["model"].get("width_multiple", 1.0),
            head_depth=config["model"].get("head_depth", 1),
            neck_depth=config["model"].get("neck_depth", 1),
            use_p6=config["training"]["use_p6"],
            use_p2 = config["training"]["use_p2"],
            neck_hidden_ratio = config["model"]["c2f_ratio"]
            
        ).to(DEVICE)
    elif config["model"]["arch"].lower() == 'yoloe_n':
        model = YOLOE_Nano(
            backbone=config["model"]["backbone"],
            num_classes=NUM_CLASSES,
            fpn_channels=config["model"]["fpn_channels"]
            
        ).to(DEVICE)
   
    weights_path = config["model"].get("weights_path", "")

    if weights_path.endswith(".pt"):
        model = load_pretrained_weights(model, weights_path, DEVICE)
    
    accumulate = int(config["training"]["accumulate"])
    epochs = int(config["training"]["epochs"])
    ema_decay = float(config["training"]["ema_decay"])
    total_updates = (len(train_loader) * epochs)/accumulate
    if use_ema:
        ema = ModelEMA(model, total_updates=total_updates, decay=ema_decay) 
    # --- Loss ---
    
    loss_cfg = config.get("loss", {})

    criterion = LossAF(
        num_classes=NUM_CLASSES,
        img_size=IMG_SIZE,
        lambda_box=loss_cfg.get("lambda_box", 5.0),
        lambda_cls=loss_cfg.get("lambda_cls", 1.0),
        focal=loss_cfg.get("focal", False),
        gamma=loss_cfg.get("gamma", 2.0),
        alpha=loss_cfg.get("alpha", 0.25),
       
    
        assign_cls_weight=loss_cfg.get("assign_cls_weight", 0.5),
        center_radius_cells=loss_cfg.get("center_radius_cells", 2.0),
        topk_limit=loss_cfg.get("topk_limit", 20),
    
        area_cells_min=loss_cfg.get("area_cells_min", 4),
        area_cells_max=loss_cfg.get("area_cells_max", 256),
        area_tol=loss_cfg.get("area_tol", 1.25),
    
        size_prior_w=loss_cfg.get("size_prior_w", 0.2),
        ar_prior_w=loss_cfg.get("ar_prior_w", 0.1),
        iou_cost_w=loss_cfg.get("iou_cost_w", 3.0),
        center_cost_w=loss_cfg.get("center_cost_w", 0.5),
    )
   
    # ---- safe float helper ----
    def f(x, default=None):
        if x is None:
            return default
        return float(x)

    # ---- läs och casta från config ----
    base_lr = f(config["training"]["lr"])                
    wd      = f(config["training"].get("weight_decay", 1e-4))

    bb_mult   = f(config["training"].get("bb_lr_mult", 1.0))
    neck_mult = f(config["training"].get("neck_lr_mult", 1.0))
    head_mult = f(config["training"].get("head_lr_mult", 1.0))
    
    lr_bb   = base_lr * bb_mult
    lr_neck = base_lr * neck_mult
    lr_head = base_lr * head_mult
    print(f"LRs: base {base_lr}, bb {lr_bb}, neck {lr_neck}, head {lr_head}")
    # ---- bygg parametergupper ----
    
    backbone_params = list(model.backbone.parameters())

    head_params = []
    
    for hn in ["head", "heads", "head3", "head4", "head5", "head2", "head6"]:
        if hasattr(model, hn):
            head_params += list(getattr(model, hn).parameters())

    collected = {id(p) for p in backbone_params + head_params}
    neck_params = [p for p in model.parameters() if id(p) not in collected]

    multiscale = config["training"]["multiscale"]
    # ---- split decay / no_decay från befintliga param-listor ----
    name_lookup = {id(p): n for n, p in model.named_parameters()}

    def split_decay_from_params(params, name_lookup):
        decay, no_decay = [], []
        seen = set()

        for p in params:
            if not p.requires_grad or id(p) in seen:
                continue
            seen.add(id(p))

            name = name_lookup.get(id(p), "").lower()

            # bias, norm och 1D-parametrar -> ingen decay
            if p.ndim == 1 or name.endswith(".bias") or "bn" in name or "norm" in name:
                no_decay.append(p)
            else:
                decay.append(p)

        return decay, no_decay


        # --- 1. Funktion för att räkna träningsbara parametrar ---
    def count_params(param_list):
        return sum(p.numel() for p in param_list if p.requires_grad)

    # --- 2. Din befintliga uppdelning ---
    bb_decay, bb_no_decay = split_decay_from_params(backbone_params, name_lookup)
    neck_decay, neck_no_decay = split_decay_from_params(neck_params, name_lookup)
    head_decay, head_no_decay = split_decay_from_params(head_params, name_lookup)

    # --- 3. Räkna ut totalt antal parametrar i den aktuella modellen ---
    total_params = count_params(bb_decay + bb_no_decay + 
                                neck_decay + neck_no_decay + 
                                head_decay + head_no_decay)

    # --- 4. Dynamisk Weight Decay Skalning ---
    base_wd = wd
    
    base_param_count = 3_234_206  # Sätt detta till antalet parametrar i din Nano/bästa modell

    # Skala wd. Om modellen är större än base_param_count blir scale_factor < 1 (mindre decay).
    scale_factor = math.sqrt(max(1, total_params) / base_param_count )
    scaled_wd = base_wd * scale_factor
    head_wd = scaled_wd * 0.5
    print(
        f"Param groups:\n"
        f"  backbone decay={len(bb_decay)} no_decay={len(bb_no_decay)}\n"
        f"  neck     decay={len(neck_decay)} no_decay={len(neck_no_decay)}\n"
        f"  head     decay={len(head_decay)} no_decay={len(head_no_decay)}\n"
        f"  ---\n"
        f"  Total params: {total_params:,}\n"
        f"  Base WD: {base_wd} -> Scaled WD: {scaled_wd:.6f} (Scale factor: {scale_factor:.3f})"
    )

    # --- 5. Använd 'scaled_wd' i din optimizer ---
    opt_name = str(config["training"].get("optimizer", "adamw")).lower()
    # ----- Multiscale training ----

    # ---- optimizer ----
    opt_name = str(config["training"].get("optimizer", "adamw")).lower()

    optimizer = torch.optim.AdamW(
            [
                # Backbone använder scaled_wd
                {"params": bb_decay,      "lr": lr_bb,   "weight_decay": scaled_wd,  "name": "backbone", "base_lr": lr_bb},
                {"params": bb_no_decay,   "lr": lr_bb,   "weight_decay": 0.0,        "name": "backbone", "base_lr": lr_bb},

                # Neck använder scaled_wd
                {"params": neck_decay,    "lr": lr_neck, "weight_decay": scaled_wd,  "name": "neck",     "base_lr": lr_neck},
                {"params": neck_no_decay, "lr": lr_neck, "weight_decay": 0.0,        "name": "neck",     "base_lr": lr_neck},

                # Head använder head_wd (vilket är hälften av scaled_wd)
                {"params": head_decay,    "lr": lr_head, "weight_decay": 0.01,    "name": "head",     "base_lr": lr_head},
                {"params": head_no_decay, "lr": lr_head, "weight_decay": 0.0,        "name": "head",     "base_lr": lr_head},
            ],
            betas=(0.9, 0.999),
        )
    # ---- scheduler ----
    steps_per_epoch = max(1, len(train_loader))
    scheduler, sched_type = build_scheduler(optimizer, config, steps_per_epoch)

    use_amp = bool(config["training"].get("amp", True)) and (DEVICE == "cuda")
    scaler = torch.amp.GradScaler(device=DEVICE, enabled=use_amp)
    
    grad_clip = float(config["training"].get("grad_clip", 0.0))
    save_every = int(config["training"].get("save_every", 10))
    log_dir = config["logging"]["log_dir"]
    os.makedirs(log_dir, exist_ok=True)
    for i in range(0, 5):
        images, targets = next(iter(train_loader))
        visualize_batch(images, targets, save_path=os.path.join(log_dir, f"sanity_check{i}.jpg"))
    if config["training"]["resume"] is not None:
        ckpt = torch.load(config["training"]["resume"], map_location=DEVICE) 
        missing, unexpected = model.load_state_dict(ckpt["state_dict"], strict=False)
        print("missing:", len(missing), "unexpected:", len(unexpected))
        ema = ModelEMA(model, total_updates=total_updates, decay=0.995) 
        

    print(model)
    print(f"Starting training on {DEVICE}, {len(train_ds)} train images, {len(val_ds)} val images, img-size: {IMG_SIZE}")
    best_val = float(0.000)
    train_losses, val_losses, mAP, F1, Recall, Precision, best_conf  = [], [], [], [], [], [], []
    Precision_fixed, Recall_fixed, F1_fixed = [], [], []
    warmup_epochs = int(config["training"].get("warmup_epochs", 0))
    if warmup_epochs > 0:
      for pg in optimizer.param_groups:
        pg["lr"] = pg["initial_lr"] * 0.01  # Starta på 10% av den tänkta hastigheten
    

    #Define save by;
    save_by = config["training"]["save_by"]
    
    
    class_names = config["dataset"]["names"]
    weight_folder = os.path.join(log_dir, 'weights')
    os.makedirs(weight_folder, exist_ok=True)
    best_ckpt_path = os.path.join(weight_folder, "best.pt")
    last_ckpt_path = os.path.join(weight_folder, "last_model_state.pt")
    best_no_aug = os.path.join(weight_folder, "best_no_aug.pt")
    metric_key = str(save_by)  # eller "AP" om du vill optimera på COCO AP
    best_metric = -1.0
    best_metric_no_aug = -1.0
    val_thresh = 0.3
    freeze_epochs = int(config["training"].get("freeze_backbone_epochs", 5))
    
    
    for epoch in range(epochs):
        
        # 1. --- FRYSNINGS-LOGIK (Gör detta absolut först i epoken) ---
        if epoch < freeze_epochs:
            model.backbone.eval()
            for p in model.backbone.parameters():
                p.requires_grad = False
        else:
            model.backbone.train()
            for p in model.backbone.parameters():
                p.requires_grad = True    
        
        # 2. --- DATA AUGMENTATION LOGIK ---
        if epoch == (int(epochs-10)):
            print("Closing mosaic....")
            del train_loader, train_ds
            train_ds = YoloDataset(
                config["dataset"]["train_images"],
                config["dataset"]["train_labels"],
                img_size=IMG_SIZE,
                is_train=False,
                transforms=get_base_transform(IMG_SIZE),
                mosaic_p=0.0
            )
            train_loader = DataLoader(
                train_ds,
                batch_size=config["training"]["batch_size"],
                sampler=sampler,               
                shuffle=False,                 
                num_workers=nw,
                pin_memory=True,
                persistent_workers=(nw > 0),
                collate_fn=yolo_collate,
                drop_last=False,
                worker_init_fn=seed_worker,  # <--- LÄGG TILL HÄR
                generator=g
                )
            
            train_ds.is_train = False
            images, targets = next(iter(train_loader))
            criterion.img_size = IMG_SIZE
            
            #visualize_batch(images, targets, save_path=os.path.join(log_dir, f"sanity_check_{epoch}.jpg"))
            
        # 3. --- LEARNING RATE OCH WARMUP LOGIK ---
        if epoch < warmup_epochs:
            # FIX 3: Manuell Warmup som går från 1% till 100% av base_lr
            try:
                warmup_factor = 0.1 + (0.99 * (epoch / warmup_epochs))
            except ZeroDivisionError:
                warmup_factor = 0.1 + (0.99 * (1))
            for pg in optimizer.param_groups:
                pg["lr"] = pg["base_lr"] * warmup_factor
        else:
            # Efter warmup, låt din valda scheduler ta över
            if sched_type == "onecycle":
                pass # OneCycle hanteras per batch, inte per epok
            elif scheduler is not None and sched_type not in ("reduceonplat", "onecycle"):
                scheduler.step()
                
                # FIX 4: Om du vill ha en mjuk upprampning av backbone när den tinas upp
        if epoch >= freeze_epochs and epoch < (freeze_epochs + 5):
            step = (epoch - freeze_epochs + 1) / 5
            target_bb_lr = lr_bb # Antar att backbone groups har sin base_lr satt till lr_bb
                    
            for pg in optimizer.param_groups:
                if pg.get("name") == "backbone":
                            # Rampar från 10% till 100% av backbonens base_lr över 5 epoker
                    pg["lr"] = target_bb_lr * (0.1 + 0.9 * step)
     
        if multiscale:
            
            base_size = IMG_SIZE  # Din basstorlek, t.ex. 640 eller 320
            min_floor = 320      # Gå aldrig under detta oavsett basstorlek
    
            # Beräkna spannet relativt till basstorleken (i steg om 32)
            # Exempel: 0.9x till 1.3x av basstorleken
            lower_limit = max(min_floor, int(base_size * 0.9 // 32) * 32)
            upper_limit = int(base_size * 1.3 // 32) * 32
    
            # Skapa listan med alla möjliga steg
            possible_sizes = list(range(lower_limit, upper_limit + 32, 32))
    
            # Dela upp för 70/30-viktningen (favorisera högre upplösning för APS)
            smaller_or_equal = [s for s in possible_sizes if s <= base_size]
            larger = [s for s in possible_sizes if s > base_size]

            # Välj storlek
            if random.random() < 0.6 and larger:
                size = random.choice(larger)
            else:
                size = random.choice(smaller_or_equal if smaller_or_equal else possible_sizes)
            
            criterion.img_size = size
      
     
        model.train()
        start = time.time()
        running = 0.0
        box_m = obj_m = cls_m = 0.0

        train_pbar = tqdm(enumerate(train_loader),
                        total=len(train_loader),
                        desc=f"Train {epoch+1}/{epochs}",
                        leave=False)

        optimizer.zero_grad(set_to_none=True) 

        for i, (imgs, targets) in train_pbar:
            imgs = torch.stack(imgs).to(DEVICE, non_blocking=True)

            # --- NY MULTISCALE LOGIK MED TARGET-SKALNING ---
            current_size = imgs.shape[-1]       # Dataloaderns storlek (t.ex. 640)
            target_size = criterion.img_size    # Den multiscale-storlek vi vill ha nu (t.ex. 832)

            if multiscale and current_size != target_size:
                
                
                # 1. Skala om hela batchen med bilder
                imgs = F.interpolate(imgs, size=(target_size, target_size), mode='bilinear', align_corners=False)
                
                # 2. Skala om boxarna i targets
                scale_ratio = target_size / current_size
                for t in targets:
                    if "boxes" in t and t["boxes"] is not None and len(t["boxes"]) > 0:
                        # Flytta till DEVICE om de inte redan är det, och multiplicera
                        t["boxes"] = t["boxes"].to(DEVICE) * scale_ratio
            with torch.amp.autocast(device_type='cuda', enabled=use_amp):
                preds = model(imgs)
                loss, loss_dict = criterion(preds, targets)
            
            # Normalisera lossen för ackumulering
            loss = loss / accumulate
            
            # Ackumulera gradienter
            scaler.scale(loss).backward()
            
            # Uppdatera vikterna BARA när vi nått accumulate-gränsen (eller sista batchen)
            if (i + 1) % accumulate == 0 or (i + 1) == len(train_loader):
                
                # Unscale och Clip (om du använder det)
                if grad_clip > 0:
                    scaler.unscale_(optimizer)
                    nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
                
                # Ta steget
                scaler.step(optimizer)
                scaler.update()
                
                # Rensa gradienterna HÄR, efter steget!
                optimizer.zero_grad(set_to_none=True)
                
                if use_ema:
                    ema.update(model)
            # statistik per batch (utan dubbelberäkning)
            B = imgs.size(0)
            box_show = float(loss_dict['box']) 
            obj_show = 0.0#float(loss_dict['obj']) 
            cls_show = float(loss_dict['cls']) 
            loss_show = box_show + obj_show + cls_show

            running += loss_show
            box_m   += box_show
            obj_m   += obj_show
            cls_m   += cls_show

            train_pbar.set_postfix(loss=f"{running/(i+1):.4f}",
                                box=f"{box_m/(i+1):.4f}",
                                obj=f"{obj_m/(i+1):.4f}",
                                cls=f"{cls_m/(i+1):.4f}")

        avg_train = running / max(1, len(train_loader))
        train_losses.append(avg_train)

 
        if use_ema:
            model_eval = ema.ema
        else:
            model_eval = model
        model_eval.eval()
        criterion.img_size = IMG_SIZE
        v_running = 0.0
        vb = vo = vc = 0.0

        # COCO-behållare för denna epoch
        coco_images, coco_anns, coco_dets = [], [], []
        ann_id = 1
        img_id = 1

        # (valfri) debug-index
        t = random.randrange(batch_size)

        with torch.no_grad(), torch.amp.autocast(device_type=DEVICE, enabled=use_amp):
            val_pbar = tqdm(enumerate(val_loader),
                            total=len(val_loader),
                            desc=f"Val   {epoch+1}/{epochs}",
                            leave=False)

            for i, (imgs, targets) in val_pbar:
                imgs = torch.stack(imgs).to(DEVICE, non_blocking=True)
                preds = model_eval(imgs)

                vloss, vdict = criterion(preds, targets)
                B = imgs.size(0)
                
                vb += float(vdict['box']) 
                vo += 0.0#float(vdict['obj']) 
                vc += float(vdict['cls']) 
                v_running = vb + vo + vc
                if i == t and epoch+1 > 5:
                    save_val_debug_anchorfree(
                        imgs, preds, epoch, out_dir=log_dir,
                        img_size=IMG_SIZE, conf_th=val_thresh, iou_th=0.3,
                        topk=300, center_mode="v8", wh_mode="softplus"
                    )

                # Bygg COCO GT/DT
                
                batch_dets = _decode_batch_to_coco_dets(
                    preds, img_size=IMG_SIZE, conf_th=0.1, iou_th=0.65, add_one=True
                )

                for b in range(B):
                    coco_images.append({
                        "id": img_id,
                        "file_name": f"val_{img_id}.jpg",
                        "width": int(IMG_SIZE), "height": int(IMG_SIZE)
                    })

                    if "boxes" in targets[b] and targets[b]["boxes"] is not None:
                        gt_xyxy = targets[b]["boxes"]
                        if isinstance(gt_xyxy, np.ndarray):
                            gt_xyxy = torch.as_tensor(gt_xyxy)
                        gt_xywh = _xyxy_to_xywh(gt_xyxy)

                        gtl = targets[b].get("labels", None)
                        if gtl is None:
                            gtl = targets[b].get("classes", None)
                        if isinstance(gtl, np.ndarray):
                            gtl = torch.as_tensor(gtl)
                        if gtl is None:
                            gtl = torch.zeros((gt_xywh.size(0),), dtype=torch.long)

                        for bx, clsid0 in zip(gt_xywh.cpu().tolist(), gtl.cpu().tolist()):
                            coco_anns.append({
                                "id": ann_id,
                                "image_id": img_id,
                                "category_id": int(clsid0) + 1,
                                "bbox": [float(v) for v in bx],
                                "area": float(max(0.0, bx[2]*bx[3])),
                                "iscrowd": 0,
                            })
                            ann_id += 1

                    for d in batch_dets[b]:
                        coco_dets.append({
                            "image_id": img_id,
                            "category_id": int(d["category_id"]),
                            "bbox": [float(v) for v in d["bbox"]],
                            "score": float(d["score"]),
                        })

                    img_id += 1
                    if scheduler is not None and sched_type == "step":
                        scheduler.step()
                val_pbar.set_postfix(loss=f"{v_running/(i+1):.4f}",
                                    box=f"{vb/(i+1):.4f}",
                                    obj=f"{vo/(i+1):.4f}",
                                    cls=f"{vc/(i+1):.4f}")
                
        
        avg_val = v_running / max(1, len(val_loader))
        val_losses.append(avg_val)

        # COCOeval 
        coco_stats = _coco_eval_from_lists(
            coco_images, coco_anns, coco_dets, iouType="bbox", num_classes=NUM_CLASSES
        )
        coco_images, coco_anns, coco_dets = [], [], []
        elapsed = time.time() - start
       
        # --------- Loggning till filer (ingen print-spam) ----------
        metrics_csv = os.path.join(log_dir, "metrics.csv")
        metrics_last_json = os.path.join(log_dir, "last_metrics.json")
        metrics_best_json = os.path.join(log_dir, "best_metrics.json")

        # Hämta ut alla LRs i en lista (detta ger en lista med 6 värden)
        lrs = [pg.get("lr", 0.0) for pg in optimizer.param_groups]
        now_iso = time.strftime("%Y-%m-%dT%H:%M:%S")

        # Uppdatera headern så du faktiskt ser vad som är vad i CSV-filen
        csv_header = [
            "epoch","AP","AP50","AP75","APS","APM","APL","AR",
            "train_loss","val_loss",
            "lr_bb","lr_neck","lr_head",  # <-- Bytte namn här
            "elapsed_s","timestamp"
        ]

        # Säkerställ att vi plockar ut rätt index (0=bb, 2=neck, 4=head)
        # Vi använder lite felhantering (if len > X) ifall du testkör en annan optimizer med färre grupper
        lr_bb   = lrs[0] if len(lrs) > 0 else 0.0
        lr_neck = lrs[2] if len(lrs) > 2 else 0.0
        lr_head = lrs[4] if len(lrs) > 4 else 0.0

        csv_row = [
            epoch+1,
            coco_stats["AP"], coco_stats["AP50"], coco_stats["AP75"],
            coco_stats["APS"], coco_stats["APM"], coco_stats["APL"], coco_stats["AR"],
            avg_train, avg_val,
            lr_bb, lr_neck, lr_head,      # <-- Lägg in variablerna här istället för list-slicing
            elapsed, now_iso
        ]
        
        _append_csv(metrics_csv, csv_header, csv_row)
        

        if scheduler is not None and sched_type == "reduceonplat":
            scheduler.step(avg_val)

        
        current = coco_stats[metric_key]
        if (current > best_metric):
            best_metric = current
            model_eval_cpu = model_eval.to("cpu").eval()
            save_checkpoint_state(model_eval_cpu, coco_stats, class_names, config, best_ckpt_path, num_anchors_per_level)
            model_eval.to(DEVICE).eval()
            print(f"✓ New best {metric_key}={best_metric:.4f} saved to {best_ckpt_path}")
           
            
        
    
        # Losscurve
        try:
  
            #Loss
            plt.figure()
            plt.plot(train_losses, label="Train")
            plt.plot(val_losses, label="Val")
            plt.xlabel("Epoch"); plt.ylabel("Loss"); plt.legend(); plt.title("Loss Curve")
            plt.savefig(os.path.join(log_dir, "loss_curve.png")); plt.close()
            

        
        except Exception:
            pass
            #Save every x epoch
        if (epoch+1) % save_every == 0:
            save_path = os.path.join(weight_folder, f"epoch_{epoch+1}.pt")
            model_eval_cpu = model_eval.to("cpu").eval()
            save_checkpoint_state(model_eval_cpu, coco_stats, class_names, config, save_path, num_anchors_per_level)   
            model_eval.to(DEVICE).eval()
        model_eval_cpu = model_eval.to("cpu").eval()
        save_checkpoint_state(model_eval_cpu, coco_stats, class_names, config, last_ckpt_path, num_anchors_per_level)
        model_eval.to(DEVICE).eval()        
        # En enda kort sammanfattningsrad per epoch
        
        tqdm.write(
            f"Epoch {epoch+1}/{epochs} | "
            f"train {avg_train:.4f} | val {avg_val:.4f} | "
            f"AP {coco_stats['AP']:.4f} AP50 {coco_stats['AP50']:.4f} AP75 {coco_stats['AP75']:.4f} | "
            f"took {elapsed:.1f}s"
        )
    plot_metrics(
    os.path.join(log_dir, "metrics.csv"),
    os.path.join(log_dir, "plots"),
    smooth=0.2,
    style="dark",   
    )
    del train_loader, train_ds
    # -------------------- EVAL --------------------
    #tries to load best ckpt path , fallback: best_no_aug
    try:
        ckpt = torch.load(best_ckpt_path, map_location=DEVICE) 
    except:
        ckpt = torch.load(best_no_aug, map_location=DEVICE) 
    missing, unexpected = model.load_state_dict(ckpt["state_dict"], strict=False)
    model.eval()
    evaluate_model(model=model, val_loader=val_loader, log_dir=log_dir, NUM_CLASSES=NUM_CLASSES, DEVICE=DEVICE, IMG_SIZE=IMG_SIZE, batch_size=batch_size, class_names=class_names)
 
    
if __name__ == "__main__":
    from scripts.args.build_args import build_argparser, load_configs, apply_overrides
    ap = build_argparser()
    opt = ap.parse_args()
    config = load_configs(model_yaml=opt.model, train_yaml=opt.train, data_yaml=opt.data)
    config = apply_overrides(config, vars(opt)) # vars(opt) gör om till dict!
    train_engine(config)