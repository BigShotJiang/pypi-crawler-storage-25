# yololite/scripts/evaluate.py
import os
import cv2
import yaml
import time
import numpy as np
from pathlib import Path

import torch
from torchmetrics.detection.mean_ap import MeanAveragePrecision
from tqdm import tqdm

def load_data_yaml(data_path, split="val"):
    """Parses data.yaml to find the image and label directories."""
    data_path = Path(data_path).resolve()
    
    with open(data_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
        
    # 1. Base path defaults to the directory where data.yaml lives
    base_path = data_path.parent
    
    # 2. If 'path' is in data, resolve it relative to the yaml file, NOT the terminal CWD
    if "path" in data:
        yaml_path = Path(data["path"])
        if yaml_path.is_absolute():
            base_path = yaml_path
        else:
            base_path = (base_path / yaml_path).resolve()
            
    if split not in data:
        raise ValueError(f"Split '{split}' not found in {data_path}. Available: {list(data.keys())}")
        
    split_path = data[split]
    
    # 3. THE FIX: Strip leading '../' from Roboflow exports to prevent 
    # it from escaping the dataset root directory and losing the dataset name.
    if isinstance(split_path, str) and split_path.startswith("../"):
        split_path = split_path[3:]
        
    img_dir = (base_path / split_path).resolve()
    
    # YOLO standard: labels are in a 'labels' folder parallel to 'images'
    label_dir = Path(str(img_dir).replace("images", "labels"))
    
    if not img_dir.exists():
        raise FileNotFoundError(f"Image directory not found: {img_dir}")
        
    return img_dir, label_dir, data.get("names", [])

def load_ground_truth(label_path, h0, w0, task="det"):
    """Loads YOLO format ground truth (bounding boxes and/or polygons)."""
    if not label_path.exists():
        return None
        
    boxes, labels, masks = [], [], []
    
    with open(label_path, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split()
            if not parts:
                continue
                
            cls_id = int(parts[0])
            coords = np.array(parts[1:], dtype=np.float32)
            
            if len(coords) == 4: # Standard BBox
                x, y, w, h = coords
                x1, y1 = (x - w / 2) * w0, (y - h / 2) * h0
                x2, y2 = (x + w / 2) * w0, (y + h / 2) * h0
                
                if task == "seg":
                    # If model is seg but label is bbox, create an empty/dummy mask or skip
                    mask = np.zeros((h0, w0), dtype=bool)
                    masks.append(mask)
                    
            elif len(coords) >= 6: # Polygon (Segmentation)
                poly = coords.reshape(-1, 2)
                poly[:, 0] = np.clip(poly[:, 0] * w0, 0, w0 - 1)
                poly[:, 1] = np.clip(poly[:, 1] * h0, 0, h0 - 1)
                
                x1, y1 = poly[:, 0].min(), poly[:, 1].min()
                x2, y2 = poly[:, 0].max(), poly[:, 1].max()
                
                if task == "seg":
                    mask = np.zeros((h0, w0), dtype=np.uint8)
                    cv2.fillPoly(mask, [poly.astype(np.int32)], 1)
                    masks.append(mask.astype(bool))
            else:
                continue
                
            boxes.append([x1, y1, x2, y2])
            labels.append(cls_id)
            
    if not boxes:
        return None
        
    target = {
        "boxes": torch.tensor(boxes, dtype=torch.float32),
        "labels": torch.tensor(labels, dtype=torch.int64),
    }
    if task == "seg":
        target["masks"] = torch.tensor(np.array(masks), dtype=torch.bool)
        
    return target

def run_eval(weights_path, data, task="det", split="val", conf=0.001, iou=0.6, img_size=640, device="cuda:0", **kwargs):
    """Main evaluation loop supporting PyTorch, ONNX, and TensorRT."""
    
    print(f"📊 Starting Evaluation | Task: {task.upper()} | Split: {split} | Backend: {Path(weights_path).suffix}")
    img_dir, label_dir, class_names = load_data_yaml(data, split)
    
    # 1. Initialize Metric
    iou_types = ["bbox", "segm"] if task == "seg" else ["bbox"]
    metric = MeanAveragePrecision(iou_type=iou_types, class_metrics=True)
    
    # 2. Re-use your YoloPredictor as the Inference Engine! 
    # By using the predictor, we guarantee that eval uses the exact same post-processing as predict.
    from .predictor import YoloPredictor
    
    # If the user passed an engine file, we must ensure TRT is handled.
    # (Note: If your YoloPredictor doesn't support TRT yet, you can swap this with the TRTWrapper from eval_tensorrt.py)
    try:
        predictor = YoloPredictor(weights_path, task=task, device=device, img_size=img_size, conf_thr=conf, iou_thr=iou, class_names=class_names)
    except Exception as e:
        raise RuntimeError(f"Failed to load model into predictor. Ensure YoloPredictor supports {Path(weights_path).suffix}. Error: {e}")

    valid_exts = {".jpg", ".jpeg", ".png", ".bmp"}
    images = sorted([p for p in img_dir.iterdir() if p.suffix.lower() in valid_exts])
    
    if not images:
        raise ValueError(f"No images found in {img_dir}")

    print(f"Evaluating on {len(images)} images from {img_dir}...")
    
    infer_times = []
    
    for img_path in tqdm(images):
        img_bgr = cv2.imread(str(img_path))
        if img_bgr is None: continue
        h0, w0 = img_bgr.shape[:2]
        
        # --- Inference ---
        t0 = time.perf_counter()
        # predict() handles letterbox, NMS, and scaling back to original size (h0, w0)
        results, _ = predictor.predict(img_bgr) 
        infer_times.append((time.perf_counter() - t0) * 1000)
        
        # --- Format Predictions for TorchMetrics ---
        pred_dict = {
            "boxes": torch.from_numpy(results["boxes"]).float() if len(results["boxes"]) else torch.zeros((0, 4)),
            "scores": torch.from_numpy(results["scores"]).float() if len(results["scores"]) else torch.zeros((0,)),
            "labels": torch.from_numpy(results["classes"]).long() if len(results["classes"]) else torch.zeros((0,), dtype=torch.int64),
        }
        if task == "seg":
            # Mask format expected by TorchMetrics: [N, H, W] bool
            pred_dict["masks"] = torch.from_numpy(results["masks"]).bool() if results["masks"] is not None and len(results["masks"]) else torch.zeros((0, h0, w0), dtype=torch.bool)
            
        # --- Load Ground Truth ---
        gt_dict = load_ground_truth(label_dir / f"{img_path.stem}.txt", h0, w0, task)
        
        if gt_dict is not None:
            # We must move everything to CPU for TorchMetrics calculation to avoid memory leaks
            metric.update([pred_dict], [gt_dict])

    # --- Compute Metrics ---
    avg_ms = sum(infer_times) / len(infer_times)
    print(f"\n⚡ Average Inference Time: {avg_ms:.2f} ms ({1000/avg_ms:.1f} FPS)")
    print("Calculating COCO mAP (this may take a moment)...")
    
    m = metric.compute()
    
    # Normalize TorchMetrics keys for consistent API usage
    if "bbox_map" in m:
        # Create fallback aliases so scripts looking for 'map' don't crash
        m["map"] = m["bbox_map"]
        m["map_50"] = m["bbox_map_50"]
    
    print("\n" + "="*40)
    print(f"🏆 EVALUATION RESULTS ({task.upper()})")
    print("="*40)
    print(f"Box mAP@50-95: {m['map'].item():.4f}")
    print(f"Box mAP@50:    {m['map_50'].item():.4f}")
    
    # If it's a segmentation model, print the mask metrics too!
    if task == "seg" and "segm_map" in m:
        print("-" * 40)
        print(f"Mask mAP@50-95: {m['segm_map'].item():.4f}")
        print(f"Mask mAP@50:    {m['segm_map_50'].item():.4f}")
    print("="*40)
    
    return m