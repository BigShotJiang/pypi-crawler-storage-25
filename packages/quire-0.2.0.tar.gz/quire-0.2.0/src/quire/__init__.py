def main() -> None:
    print("Hello from quire!")
