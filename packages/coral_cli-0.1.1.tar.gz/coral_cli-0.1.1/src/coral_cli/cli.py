import click

@click.group()
def cli():
    """coral-cli - 珊瑚平台命令行工具"""
    pass

@cli.command()
def hello():
    """打印问候语"""
    click.echo("你好，我是 coral-cli")

@cli.command()
def project():
    """获取项目功能（示例）"""
    click.echo("项目功能：代码生成、自动化部署...**")