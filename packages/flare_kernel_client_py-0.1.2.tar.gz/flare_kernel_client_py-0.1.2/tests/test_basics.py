from __future__ import annotations

import asyncio
import sys
from types import SimpleNamespace

import flare_kernel_client

from flare_kernel_client import KernelStreamAdapter, SSELineParser


def test_package_smoke_imports_public_api() -> None:
    assert hasattr(flare_kernel_client, "KernelStreamAdapter")
    assert hasattr(flare_kernel_client, "SSELineParser")


def test_sse_line_parser_parses_event_data_and_resets() -> None:
    parser = SSELineParser()

    assert parser.feed_line('data: {"ignored": true}') is None
    assert parser.feed_line("event: message") is None

    event = parser.feed_line('data: {"ok": true, "count": 2}')
    assert event == {"type": "message", "data": {"ok": True, "count": 2}}

    parser.reset()
    assert parser.feed_line('data: {"ok": true}') is None


def test_kernel_stream_adapter_build_stream_url_normalizes_slashes() -> None:
    adapter = KernelStreamAdapter(
        base_url="https://example.test/",
        path="/kernel/stream",
        timeout=12.5,
    )

    assert adapter.build_stream_url() == "https://example.test/kernel/stream"
    assert adapter.timeout == 12.5


def test_kernel_stream_adapter_stream_chat_keeps_action_trace_fields_and_no_fallback_dependency(
    monkeypatch,
) -> None:
    captured: dict[str, object] = {}

    class _FakeResponse:
        status_code = 200

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return None

        async def aiter_lines(self):
            yield "event: message"
            yield (
                'data: {"next_actions":[{"action_key":"enter_sourcing",'
                '"owner_module":"engines.sourcing.policy",'
                '"policy_id":"policy.sourcing.enter"}]}'
            )
            yield ""
            yield "event: message"
            yield 'data: {"next_actions":[{"action_key":"confirm_enter_sourcing"}]}'
            yield ""

        async def aread(self) -> bytes:
            return b""

    class _FakeClient:
        def __init__(self, timeout):
            captured["timeout"] = timeout

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return None

        def stream(self, method, url, json, headers):
            captured["method"] = method
            captured["url"] = url
            captured["json"] = json
            captured["headers"] = headers
            return _FakeResponse()

    monkeypatch.setitem(sys.modules, "httpx", SimpleNamespace(AsyncClient=_FakeClient))

    adapter = KernelStreamAdapter(
        base_url="https://example.test/",
        path="/kernel/stream",
        timeout=8.0,
    )

    async def _collect_events():
        events = []
        async for event in adapter.stream_chat(
            session_id="session-001",
            message="hello",
            enabled_tools=["search"],
        ):
            events.append(event)
        return events

    events = asyncio.run(_collect_events())

    assert captured["method"] == "POST"
    assert captured["url"] == "https://example.test/kernel/stream"
    assert captured["json"] == {
        "message": "hello",
        "content": "hello",
        "session_id": "session-001",
        "enabled_tools": ["search"],
        "enabled_capabilities": ["search"],
    }
    assert captured["headers"] == {"Accept": "text/event-stream"}

    first_action = events[0]["data"]["next_actions"][0]
    assert first_action["action_key"] == "enter_sourcing"
    assert first_action["owner_module"] == "engines.sourcing.policy"
    assert first_action["policy_id"] == "policy.sourcing.enter"

    second_action = events[1]["data"]["next_actions"][0]
    assert second_action["action_key"] == "confirm_enter_sourcing"
    assert "owner_module" not in second_action
    assert "policy_id" not in second_action



def test_sse_line_parser_accepts_empty_next_actions() -> None:
    parser = SSELineParser()

    assert parser.feed_line('event: assistant.message.delta') is None
    event = parser.feed_line('data: {"next_actions": []}')

    assert event == {
        "type": "assistant.message.delta",
        "data": {"next_actions": []},
    }


def test_sse_line_parser_keeps_action_source_fields_without_business_text() -> None:
    parser = SSELineParser()

    assert parser.feed_line('event: assistant.message.delta') is None
    event = parser.feed_line(
        'data: {"next_actions": [{"action_key": "enter.smart_sourcing", "owner_module": "engines.sourcing.policy", "policy_id": "policy.smart_sourcing.v2"}]}'
    )

    assert event == {
        "type": "assistant.message.delta",
        "data": {
            "next_actions": [
                {
                    "action_key": "enter.smart_sourcing",
                    "owner_module": "engines.sourcing.policy",
                    "policy_id": "policy.smart_sourcing.v2",
                }
            ]
        },
    }
