# flare-kernel-client-py

FLARE Kernel 流式客户端与 SSE 解析包。

## 架构边界文档

1. `docs/SSOT-KERNEL-CLIENT-BOUNDARY.md`（SSOT）
2. `docs/CAPABILITY-INVENTORY.md`

职责：

1. 连接 Kernel SSE 端点。
2. 解析 `event:` / `data:` 行。
3. 不承载业务字段、不承载 UI。

导出：

1. `KernelStreamAdapter`
2. `SSELineParser`
