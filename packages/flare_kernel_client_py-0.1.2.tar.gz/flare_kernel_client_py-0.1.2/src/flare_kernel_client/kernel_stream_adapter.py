from __future__ import annotations

import os
from typing import Any, AsyncGenerator

from .sse_parser import SSELineParser


def _read_env(name: str) -> str | None:
    value = os.getenv(name)
    if value is None:
        return None
    normalized = value.strip()
    return normalized or None


def _resolve_required_value(explicit: str | None, env_name: str) -> str:
    candidate = (explicit or _read_env(env_name) or "").strip()
    if not candidate:
        raise ValueError(f"{env_name} is required for KernelStreamAdapter")
    return candidate


class KernelStreamAdapter:
    """Generic adapter for streaming events from a Kernel SSE endpoint."""

    def __init__(
        self,
        base_url: str | None = None,
        path: str | None = None,
        timeout: float = 60.0,
    ) -> None:
        self.base_url = _resolve_required_value(base_url, "KERNEL_BASE_URL").rstrip("/")
        self.path = _resolve_required_value(path, "KERNEL_STREAM_PATH")
        self.timeout = timeout

    def build_stream_url(self) -> str:
        return f"{self.base_url}/{self.path.lstrip('/')}"

    async def stream_chat(
        self,
        session_id: str,
        message: str,
        enabled_tools: list[str] | None = None,
    ) -> AsyncGenerator[dict[str, Any], None]:
        import httpx

        payload = {
            "message": message,
            "content": message,
            "session_id": session_id,
            "enabled_tools": enabled_tools or [],
            "enabled_capabilities": enabled_tools or [],
        }
        parser = SSELineParser()

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            async with client.stream(
                "POST",
                self.build_stream_url(),
                json=payload,
                headers={"Accept": "text/event-stream"},
            ) as response:
                if response.status_code != 200:
                    error_text = await response.aread()
                    raise Exception(
                        f"Kernel returned error {response.status_code}: "
                        f"{error_text.decode()}"
                    )

                async for line in response.aiter_lines():
                    event = parser.feed_line(line)
                    if event is not None:
                        yield event


__all__ = ["KernelStreamAdapter"]
