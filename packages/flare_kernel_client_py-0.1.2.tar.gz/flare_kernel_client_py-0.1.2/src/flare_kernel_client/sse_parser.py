from __future__ import annotations

import json
from typing import Any


class SSELineParser:
    """Minimal SSE text line parser.

    It keeps only the current `event:` value and turns a matching `data:` line
    into a plain dict: {"type": ..., "data": ...}.
    """

    def __init__(self) -> None:
        self._current_event: str | None = None

    def reset(self) -> None:
        self._current_event = None

    def feed_line(self, line: str) -> dict[str, Any] | None:
        if line is None:
            return None

        normalized = line.rstrip("\r")
        if not normalized:
            return None

        if normalized.startswith("event:"):
            self._current_event = normalized[6:].strip() or None
            return None

        if not normalized.startswith("data:") or not self._current_event:
            return None

        raw_data = normalized[5:].strip()
        if not raw_data:
            return None

        try:
            data = json.loads(raw_data)
        except json.JSONDecodeError:
            return None

        return {"type": self._current_event, "data": data}


__all__ = ["SSELineParser"]
