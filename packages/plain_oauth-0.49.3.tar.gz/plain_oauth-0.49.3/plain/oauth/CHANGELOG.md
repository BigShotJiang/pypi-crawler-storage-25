# plain-oauth changelog

## [0.49.3](https://github.com/dropseed/plain/releases/plain-oauth@0.49.3) (2026-04-17)

### What's changed

- Updated `OAuthConnection` timestamps to use `DateTimeField(create_now=True)` / `(create_now=True, update_now=True)` for plain-postgres 0.96.0. ([5d145e4](https://github.com/dropseed/plain/commit/5d145e4), [a44e5ec](https://github.com/dropseed/plain/commit/a44e5ec), [091bac7](https://github.com/dropseed/plain/commit/091bac7))

### Upgrade instructions

- Requires `plain-postgres>=0.96.0`. Run `plain postgres sync` after upgrading to reconcile column defaults.

## [0.49.2](https://github.com/dropseed/plain/releases/plain-oauth@0.49.2) (2026-04-13)

### What's changed

- Updated internal references to use the fixed `app.users.models.User` convention. ([0861c9915cb6](https://github.com/dropseed/plain/commit/0861c9915cb6))

### Upgrade instructions

- No changes required — but see the `plain` 0.132.0 notes if you haven't moved your User model to `app/users/models.py`.

## [0.49.1](https://github.com/dropseed/plain/releases/plain-oauth@0.49.1) (2026-03-29)

### What's changed

- Removed `AddIndex`, `RenameIndex`, and `AddConstraint` operations from migrations — indexes and constraints are now managed by convergence. ([c58b4ba1fec9](https://github.com/dropseed/plain/commit/c58b4ba1fec9), [1f15538b008f](https://github.com/dropseed/plain/commit/1f15538b008f))
- Updated docs to reference `plain postgres sync` instead of `plain migrate`. ([b026895edc4c](https://github.com/dropseed/plain/commit/b026895edc4c))

### Upgrade instructions

- No changes required.

## [0.49.0](https://github.com/dropseed/plain/releases/plain-oauth@0.49.0) (2026-03-28)

### What's changed

- Replaced `CharField` with `TextField` in models and migration files to match plain-postgres 0.90.0 ([5062ee4dd1fd](https://github.com/dropseed/plain/commit/5062ee4dd1fd))

### Upgrade instructions

- Requires `plain-postgres>=0.90.0`
- Replace `CharField` with `TextField` in migration files that reference this package's models

## [0.48.0](https://github.com/dropseed/plain/releases/plain-oauth@0.48.0) (2026-03-25)

### What's changed

- Added explicit `Index` on `OAuthConnection.user` FK field — replaces the old auto-created index from `db_index=True`. Migration drops the orphan auto-index and creates the new named index. ([061b97f5d538](https://github.com/dropseed/plain/commit/061b97f5d538))

### Upgrade instructions

- Requires `plain-postgres>=0.89.0`. Run `uv run plain postgres migrate`.

## [0.47.0](https://github.com/dropseed/plain/releases/plain-oauth@0.47.0) (2026-03-22)

### What's changed

- Switched from `plain.postgres.IntegrityError` to `psycopg.IntegrityError` directly, following the removal of PEP-249 exception re-exports from plain-postgres ([d4b170e60a2c](https://github.com/dropseed/plain/commit/d4b170e60a2c))

### Upgrade instructions

- Requires `plain-postgres>=0.85.0`. No other changes required.

## [0.46.0](https://github.com/dropseed/plain/releases/plain-oauth@0.46.0) (2026-03-16)

### What's changed

- OAuth `access_token` and `refresh_token` fields are now encrypted at rest using `EncryptedTextField`, protecting credentials if the database is compromised ([66c35c1eef75](https://github.com/dropseed/plain/commit/66c35c1eef75))
- Existing unencrypted tokens are automatically encrypted on next save (no data migration needed)

### Upgrade instructions

- Run `uv run plain migrate` to apply the field type migration.
- Ensure the `cryptography` package is installed (required by `EncryptedTextField`).

## [0.45.0](https://github.com/dropseed/plain/releases/plain-oauth@0.45.0) (2026-03-12)

### What's changed

- Updated all imports from `plain.models` to `plain.postgres` in admin, models, preflight, and migrations.
- Updated `pyproject.toml` dependency from `plain.models` to `plain.postgres`.

### Upgrade instructions

- Update imports: `from plain.models` to `from plain.postgres`, `from plain import models` to `from plain import postgres`.
- Update dependency declarations: `plain.models` to `plain.postgres` in `pyproject.toml`.

## [0.44.3](https://github.com/dropseed/plain/releases/plain-oauth@0.44.3) (2026-03-12)

### What's changed

- Fixed open-redirect vulnerability in disconnect and callback redirects — `allow_external` on `get_redirect_response()` now defaults to `False`, with only the OAuth authorization redirect (to the external provider) explicitly passing `True` ([bb763cf53667](https://github.com/dropseed/plain/commit/bb763cf53667))

### Upgrade instructions

- If you override `get_redirect_response()` in a custom provider subclass, update your signature to accept the new `allow_external` keyword argument: `def get_redirect_response(self, redirect_url: str, *, allow_external: bool = False) -> Response`

## [0.44.2](https://github.com/dropseed/plain/releases/plain-oauth@0.44.2) (2026-03-11)

### What's changed

- Added `allow_external=True` to OAuth provider redirect responses, since these legitimately redirect to external authorization servers ([5edfb2bedf90](https://github.com/dropseed/plain/commit/5edfb2bedf90))

### Upgrade instructions

- Requires `plain>=0.123.0`. No other changes required.

## [0.44.1](https://github.com/dropseed/plain/releases/plain-oauth@0.44.1) (2026-03-09)

### What's changed

- Added type annotations to `OAuthError.__init__` and `OAuthUserAlreadyExistsError.__init__` for better IDE support ([26077db4719d](https://github.com/dropseed/plain/commit/26077db4719d))

### Upgrade instructions

- No changes required.

## [0.44.0](https://github.com/dropseed/plain/releases/plain-oauth@0.44.0) (2026-03-09)

### What's changed

- OAuth exceptions now carry `provider_key` so error pages know which provider failed ([3590f47193e8](https://github.com/dropseed/plain/commit/3590f47193e8))
- `OAuthUserAlreadyExistsError` includes `user_model_fields` for richer error page customization ([3590f47193e8](https://github.com/dropseed/plain/commit/3590f47193e8))
- Each exception subclass defines a `template_name` (e.g. `oauth/user_already_exists.html`) enabling per-error-type template overrides with automatic fallback to `oauth/error.html` ([3590f47193e8](https://github.com/dropseed/plain/commit/3590f47193e8))
- Renamed default error template from `oauth/callback.html` to `oauth/error.html` ([3590f47193e8](https://github.com/dropseed/plain/commit/3590f47193e8))
- Fixed transaction scope in `get_or_create_user` — user creation is now wrapped in a nested savepoint so `IntegrityError` is caught correctly without breaking the outer transaction ([3590f47193e8](https://github.com/dropseed/plain/commit/3590f47193e8))

### Upgrade instructions

- If you have a custom `oauth/callback.html` template, rename it to `oauth/error.html`.
- The `oauth_error` template context variable now exposes `.provider_key` and (for `OAuthUserAlreadyExistsError`) `.user_model_fields` — no action needed, but you can use these for richer error pages.
- You can optionally create error-specific templates (`oauth/state_missing.html`, `oauth/state_mismatch.html`, `oauth/user_already_exists.html`) for targeted error pages.

## [0.43.0](https://github.com/dropseed/plain/releases/plain-oauth@0.43.0) (2026-03-07)

### What's changed

- Updated README template examples to use keyword arguments in `url()` calls instead of positional arguments (e.g., `url('oauth:login', provider='github')` instead of `url('oauth:login', 'github')`) ([6eecc35](https://github.com/dropseed/plain/commit/6eecc35ff197))

### Upgrade instructions

- Update any `url()` calls in templates that use positional arguments for OAuth URLs to use keyword arguments instead (e.g., `url('oauth:login', provider='github')`, `url('oauth:connect', provider=provider_key)`, `url('oauth:disconnect', provider=connection.provider_key)`).

## [0.42.4](https://github.com/dropseed/plain/releases/plain-oauth@0.42.4) (2026-02-26)

### What's changed

- Auto-formatted config files with updated linter configuration ([028bb95c3ae3](https://github.com/dropseed/plain/commit/028bb95c3ae3))

### Upgrade instructions

- No changes required.

## [0.42.3](https://github.com/dropseed/plain/releases/plain-oauth@0.42.3) (2026-02-04)

### What's changed

- Added `__all__` exports to `exceptions`, `models`, `providers`, and `urls` modules for explicit public API boundaries ([f26a63a5c941](https://github.com/dropseed/plain/commit/f26a63a5c941))

### Upgrade instructions

- No changes required.

## [0.42.2](https://github.com/dropseed/plain/releases/plain-oauth@0.42.2) (2026-01-28)

### What's changed

- Added Settings section to README ([803fee1ad5](https://github.com/dropseed/plain/commit/803fee1ad5))

### Upgrade instructions

- No changes required.

## [0.42.1](https://github.com/dropseed/plain/releases/plain-oauth@0.42.1) (2026-01-22)

### What's changed

- Migration now uses `settings.AUTH_USER_MODEL` instead of hardcoded `"users.user"`, enabling support for custom user models ([76e28f6](https://github.com/dropseed/plain/commit/76e28f6))

### Upgrade instructions

- No changes required.

## [0.42.0](https://github.com/dropseed/plain/releases/plain-oauth@0.42.0) (2026-01-15)

### What's changed

- Admin connections list view now includes a description for better context ([0fc4dd3](https://github.com/dropseed/plain/commit/0fc4dd3))

### Upgrade instructions

- No changes required

## [0.41.0](https://github.com/dropseed/plain/releases/plain-oauth@0.41.0) (2026-01-13)

### What's changed

- Documentation restructured to follow consistent style with improved organization and clearer examples ([da37a78](https://github.com/dropseed/plain/commit/da37a78))

### Upgrade instructions

- No changes required

## [0.40.0](https://github.com/dropseed/plain/releases/plain-oauth@0.40.0) (2026-01-13)

### What's changed

- `OAUTH_LOGIN_PROVIDERS` setting is now marked as secret, preventing it from being exposed in error pages or debug output ([eba56c4](https://github.com/dropseed/plain/commit/eba56c4))
- Documentation updated to reflect the new `HTTPS_PROXY_HEADER` setting format, which now uses a string like `"X-Forwarded-Proto: https"` instead of a tuple ([7ac2a43](https://github.com/dropseed/plain/commit/7ac2a43))
- Internal redirect responses now use `RedirectResponse` instead of the deprecated `ResponseRedirect` ([fad5bf2](https://github.com/dropseed/plain/commit/fad5bf2))

### Upgrade instructions

- No changes required

## [0.39.0](https://github.com/dropseed/plain/releases/plain-oauth@0.39.0) (2025-12-04)

### What's changed

- Internal type improvements for accessing `OAUTH_LOGIN_PROVIDERS` setting ([ac1eeb0](https://github.com/dropseed/plain/commit/ac1eeb0))

### Upgrade instructions

- No changes required

## [0.38.0](https://github.com/dropseed/plain/releases/plain-oauth@0.38.0) (2025-11-24)

### What's changed

- `OAuthConnectView` and `OAuthDisconnectView` now inherit from `AuthView` instead of using `AuthViewMixin` ([569afd6](https://github.com/dropseed/plain/commit/569afd6))
- Form data access in OAuth providers now uses `request.form_data` instead of `request.data` ([90332a9](https://github.com/dropseed/plain/commit/90332a9))

### Upgrade instructions

- No changes required

## [0.37.0](https://github.com/dropseed/plain/releases/plain-oauth@0.37.0) (2025-11-21)

### What's changed

- `ForeignKey` has been renamed to `ForeignKeyField` in the `OAuthConnection` model and migration ([8010204](https://github.com/dropseed/plain/commit/8010204))

### Upgrade instructions

- No changes required

## [0.36.1](https://github.com/dropseed/plain/releases/plain-oauth@0.36.1) (2025-11-17)

### What's changed

- Removed `ClassVar` annotation from the `query` attribute on `OAuthConnection` model, simplifying type annotations while maintaining type checker compatibility ([1c624ff](https://github.com/dropseed/plain/commit/1c624ff))

### Upgrade instructions

- No changes required

## [0.36.0](https://github.com/dropseed/plain/releases/plain-oauth@0.36.0) (2025-11-14)

### What's changed

- The `related_name="oauth_connections"` parameter has been removed from the `user` ForeignKey field, requiring explicit reverse relationship descriptors on user models ([a4b6309](https://github.com/dropseed/plain/commit/a4b6309))

### Upgrade instructions

- If `user.oauth_connections` was in use, a `oauth_connections: types.ReverseForeignKey[OAuthConnection] = types.ReverseForeignKey(to="plainoauth.OAuthConnection", field="user")` will be required on your `User` model

## [0.35.0](https://github.com/dropseed/plain/releases/plain-oauth@0.35.0) (2025-11-13)

### What's changed

- The `OAuthConnection` model now includes a `query` attribute with proper type annotations using `ClassVar[models.QuerySet[OAuthConnection]]`, enabling better type checker inference ([c3b00a6](https://github.com/dropseed/plain/commit/c3b00a6))
- Type annotations updated to use forward references without quotes by adding `from __future__ import annotations` ([c3b00a6](https://github.com/dropseed/plain/commit/c3b00a6))

### Upgrade instructions

- No changes required

## [0.34.0](https://github.com/dropseed/plain/releases/plain-oauth@0.34.0) (2025-11-13)

### What's changed

- Model fields now use the new type stubs pattern from `plain.models.types`, enabling better type checker inference for field attributes ([c8f40fc](https://github.com/dropseed/plain/commit/c8f40fc))
- Removed unnecessary `cast()` calls for datetime fields that now have proper type annotations ([c8f40fc](https://github.com/dropseed/plain/commit/c8f40fc))

### Upgrade instructions

- No changes required

## [0.33.0](https://github.com/dropseed/plain/releases/plain-oauth@0.33.0) (2025-11-12)

### What's changed

- `OAuthProvider` is now an abstract base class (ABC) with `@abstractmethod` decorators on `refresh_oauth_token()`, `get_oauth_token()`, and `get_oauth_user()` ([dd950c6](https://github.com/dropseed/plain/commit/dd950c6))
- Internal type improvements for better type checker compatibility ([f4dbcef](https://github.com/dropseed/plain/commit/f4dbcef))

### Upgrade instructions

- If you have custom OAuth providers that inherit from `OAuthProvider`, ensure you implement all three required methods: `refresh_oauth_token()`, `get_oauth_token()`, and `get_oauth_user()`. Type checkers will now enforce this requirement.

## [0.32.1](https://github.com/dropseed/plain/releases/plain-oauth@0.32.1) (2025-11-11)

### What's changed

- Internal import paths updated to use more specific module imports (e.g., `plain.models.aggregates.Count` and `plain.models.db.OperationalError`) for better code organization ([e9edf61](https://github.com/dropseed/plain/commit/e9edf61))

### Upgrade instructions

- No changes required

## [0.32.0](https://github.com/dropseed/plain/releases/plain-oauth@0.32.0) (2025-11-03)

### What's changed

- OAuth errors are now logged as warnings instead of exceptions, reducing log noise while still capturing error messages ([30b5705](https://github.com/dropseed/plain/commit/30b5705))

### Upgrade instructions

- No changes required

## [0.31.2](https://github.com/dropseed/plain/releases/plain-oauth@0.31.2) (2025-10-20)

### What's changed

- Internal packaging improvements for development dependencies ([1b43a3a](https://github.com/dropseed/plain/commit/1b43a3a))

### Upgrade instructions

- No changes required

## [0.31.1](https://github.com/dropseed/plain/releases/plain-oauth@0.31.1) (2025-10-17)

### What's changed

- `OAuthStateMissingError` is now raised when OAuth state is not found in the session, providing clearer error messaging ([72898275](https://github.com/dropseed/plain/commit/72898275))
- Updated error message to indicate possible causes like expired sessions or blocked cookies ([72898275](https://github.com/dropseed/plain/commit/72898275))

### Upgrade instructions

- No changes required

## [0.31.0](https://github.com/dropseed/plain/releases/plain-oauth@0.31.0) (2025-10-12)

### What's changed

- Preflight provider key check has been moved from the model to a standalone `CheckOAuthProviderKeys` preflight check class ([fdc5aee](https://github.com/dropseed/plain/commit/fdc5aee))
- Preflight check ID has been renamed from `oauth.provider_in_db_not_in_settings` to `oauth.provider_settings_missing` ([fdc5aee](https://github.com/dropseed/plain/commit/fdc5aee))

### Upgrade instructions

- No changes required

## [0.30.0](https://github.com/dropseed/plain/releases/plain-oauth@0.30.0) (2025-10-07)

### What's changed

- Model metadata is now defined using `model_options = models.Options(...)` instead of `class Meta` ([17a378d](https://github.com/dropseed/plain/commit/17a378d), [73ba469](https://github.com/dropseed/plain/commit/73ba469))

### Upgrade instructions

- No changes required

## [0.29.2](https://github.com/dropseed/plain/releases/plain-oauth@0.29.2) (2025-10-06)

### What's changed

- Added type annotations to improve IDE and type checker friendliness ([35fb8c4](https://github.com/dropseed/plain/commit/35fb8c4))
- Updated provider examples (Bitbucket, GitHub, GitLab) with proper type annotations ([50463b0](https://github.com/dropseed/plain/commit/50463b0))

### Upgrade instructions

- No changes required

## [0.29.1](https://github.com/dropseed/plain/releases/plain-oauth@0.29.1) (2025-10-02)

### What's changed

- Updated documentation examples to use `get_current_user()` instead of `request.user` ([f6278d9](https://github.com/dropseed/plain/commit/f6278d9bb4))

### Upgrade instructions

- No changes required

## [0.29.0](https://github.com/dropseed/plain/releases/plain-oauth@0.29.0) (2025-10-02)

### What's changed

- Removed direct access to `request.user` and `request.session` attributes in favor of using `get_request_user()` and `get_request_session()` functions ([154ee10](https://github.com/dropseed/plain/commit/154ee10375))
- Removed dependency on `AuthenticationMiddleware` from test settings ([154ee10](https://github.com/dropseed/plain/commit/154ee10375))

### Upgrade instructions

- If you have custom OAuth providers or views that access `request.user`, update them to use `get_request_user(request)` from `plain.auth`
- If you have custom OAuth providers that access `request.session`, update them to use `get_request_session(request)` from `plain.sessions`

## [0.28.0](https://github.com/dropseed/plain/releases/plain-oauth@0.28.0) (2025-09-30)

### What's changed

- `HttpRequest` has been renamed to `Request` throughout the OAuth provider classes ([cd46ff2](https://github.com/dropseed/plain/commit/cd46ff2003))

### Upgrade instructions

- If you have custom OAuth providers that override methods like `get_authorization_url_params`, `get_oauth_token`, `get_callback_url`, or any other methods that accept a request parameter, update the type hint from `HttpRequest` to `Request`
- Update any imports of `HttpRequest` in custom OAuth provider code to import `Request` instead from `plain.http`

## [0.27.0](https://github.com/dropseed/plain/releases/plain-oauth@0.27.0) (2025-09-25)

### What's changed

- The `OAuthConnection.check()` method has been replaced with `OAuthConnection.preflight()` as part of the new preflight system ([b0b610d](https://github.com/dropseed/plain/commit/b0b610d461))
- Preflight check IDs have been renamed from numeric format (e.g., `plain.oauth.E001`) to descriptive names (e.g., `oauth.provider_in_db_not_in_settings`) ([cd96c97](https://github.com/dropseed/plain/commit/cd96c97b25))
- Preflight messages now provide clearer fix instructions directly in the `fix` attribute ([c7cde12](https://github.com/dropseed/plain/commit/c7cde12149))

### Upgrade instructions

- If you have custom code that calls `OAuthConnection.check()`, update it to use `OAuthConnection.preflight()` instead
- If you have code that references specific preflight check IDs (e.g., `plain.oauth.E001`), update them to use the new descriptive format (e.g., `oauth.provider_in_db_not_in_settings`)

## [0.26.0](https://github.com/dropseed/plain/releases/plain-oauth@0.26.0) (2025-09-12)

### What's changed

- Model queries now use `.query` instead of `.objects` ([037a239](https://github.com/dropseed/plain/commit/037a239ef4))
- Minimum Python version increased to 3.13 ([d86e307](https://github.com/dropseed/plain/commit/d86e307efb))

### Upgrade instructions

- Update any custom code that references `OAuthConnection.objects` to use `OAuthConnection.query` instead

## [0.25.1](https://github.com/dropseed/plain/releases/plain-oauth@0.25.1) (2025-08-22)

### What's changed

- Updated admin navigation to place icons on sections rather than individual items ([5a6479a](https://github.com/dropseed/plain/commit/5a6479ac79))

### Upgrade instructions

- No changes required

## [0.25.0](https://github.com/dropseed/plain/releases/plain-oauth@0.25.0) (2025-08-19)

### What's changed

- Removed requirement for manual `{{ csrf_input }}` in OAuth forms - CSRF protection now uses `Sec-Fetch-Site` headers automatically ([9551508](https://github.com/dropseed/plain/commit/955150800c))

### Upgrade instructions

- Remove `{{ csrf_input }}` from any OAuth forms in your templates (login, connect, disconnect forms) - CSRF protection is now handled automatically

## [0.24.2](https://github.com/dropseed/plain/releases/plain-oauth@0.24.2) (2025-08-05)

### What's changed

- Updated documentation to use `plain` commands instead of `python manage.py` references ([8071854](https://github.com/dropseed/plain/commit/8071854d61))
- Improved README with better structure, table of contents, and more comprehensive examples ([4ebecd1](https://github.com/dropseed/plain/commit/4ebecd1856))
- Fixed router setup documentation in URLs section ([48caf10](https://github.com/dropseed/plain/commit/48caf105da))

### Upgrade instructions

- No changes required

## [0.24.1](https://github.com/dropseed/plain/releases/plain-oauth@0.24.1) (2025-07-23)

### What's changed

- Added a nav icon to the OAuth admin interface ([9e9f8b0](https://github.com/dropseed/plain/commit/9e9f8b0e2c))

### Upgrade instructions

- No changes required

## [0.24.0](https://github.com/dropseed/plain/releases/plain-oauth@0.24.0) (2025-07-22)

### What's changed

- Migrations updated to use the new `PrimaryKeyField` instead of `BigAutoField` ([4b8fa6a](https://github.com/dropseed/plain/commit/4b8fa6a))

### Upgrade instructions

- No changes required.

## [0.23.0](https://github.com/dropseed/plain/releases/plain-oauth@0.23.0) (2025-07-18)

### What's changed

- Migrations have been restarted to consolidate the migration history into a single initial migration ([484f1b6](https://github.com/dropseed/plain/commit/484f1b6e93))

### Upgrade instructions

- Run `plain migrate --prune plainoauth` after upgrading to clean up old migration records

## [0.22.0](https://github.com/dropseed/plain/releases/plain-oauth@0.22.0) (2025-06-23)

### What's changed

- Updated `OAuthConnection.check()` to accept a single `database` argument instead of the older `databases` list, matching the new single `DATABASE` setting used across the Plain stack ([d346d81](https://github.com/dropseed/plain/commit/d346d81))

### Upgrade instructions

- No changes required.
