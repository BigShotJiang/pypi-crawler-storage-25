"""Per-client fixed-window rate limiter middleware.

Enabled when ``RATE_LIMIT_RPM > 0`` in settings.  When the limit is
exceeded the middleware returns a 429 with an Anthropic-shaped body and
a ``retry-after`` header giving the seconds until the window resets.

Client identity (in priority order):
  1. ``metadata.user_id`` from the JSON body  (only for POST /v1/messages)
  2. ``x-forwarded-for`` first IP
  3. ``client.host`` (direct TCP peer)
"""
from __future__ import annotations

import asyncio
import json
import time
from collections import defaultdict

import structlog
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

_log = structlog.get_logger("nvd_claude_proxy.rate_limiter")

# Endpoints subject to rate limiting.
_RATE_LIMITED_PATHS = {"/v1/messages"}


class _Window:
    """Single fixed-window counter for one client."""

    __slots__ = ("count", "reset_at")

    def __init__(self, reset_at: float) -> None:
        self.count = 0
        self.reset_at = reset_at


class RateLimiterMiddleware(BaseHTTPMiddleware):
    """Fixed-window (per-minute) rate limiter."""

    def __init__(self, app, rpm_limit: int) -> None:
        super().__init__(app)
        self._rpm = rpm_limit
        self._windows: dict[str, _Window] = defaultdict()
        self._lock = asyncio.Lock()

    async def dispatch(self, request: Request, call_next) -> Response:
        if request.url.path not in _RATE_LIMITED_PATHS:
            return await call_next(request)

        client_key = await self._client_key(request)
        now = time.monotonic()
        window_end = now - (now % 60) + 60  # next whole-minute boundary

        async with self._lock:
            win = self._windows.get(client_key)
            if win is None or now >= win.reset_at:
                win = _Window(reset_at=window_end)
                self._windows[client_key] = win
            win.count += 1
            count = win.count
            reset_at = win.reset_at

        if count > self._rpm:
            retry_after = max(1, int(reset_at - now))
            _log.warning(
                "rate_limit.exceeded",
                client=client_key,
                count=count,
                limit=self._rpm,
            )
            return JSONResponse(
                {
                    "type": "error",
                    "error": {
                        "type": "rate_limit_error",
                        "message": (
                            f"Rate limit exceeded: {self._rpm} requests/minute. "
                            f"Retry after {retry_after}s."
                        ),
                    },
                },
                status_code=429,
                headers={
                    "retry-after": str(retry_after),
                    "anthropic-ratelimit-requests-limit": str(self._rpm),
                    "anthropic-ratelimit-requests-remaining": "0",
                    "anthropic-ratelimit-requests-reset": _iso8601(int(time.time()) + retry_after),
                },
            )

        return await call_next(request)

    async def _client_key(self, request: Request) -> str:
        """Extract client identity for bucket keying."""
        # Try metadata.user_id from JSON body (non-destructive peek).
        if request.method == "POST" and "application/json" in request.headers.get(
            "content-type", ""
        ):
            try:
                body_bytes = await request.body()
                body = json.loads(body_bytes)
                uid = (body.get("metadata") or {}).get("user_id")
                if uid:
                    return f"user:{uid}"
            except Exception:
                pass

        # Forwarded IP (behind a proxy/load-balancer).
        forwarded = request.headers.get("x-forwarded-for")
        if forwarded:
            return f"ip:{forwarded.split(',')[0].strip()}"

        # Direct TCP peer.
        if request.client:
            return f"ip:{request.client.host}"

        return "ip:unknown"


def _iso8601(epoch_s: int) -> str:
    import time as _time
    return _time.strftime("%Y-%m-%dT%H:%M:%SZ", _time.gmtime(epoch_s))
