from __future__ import annotations

import time

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import ORJSONResponse

from ..util.anthropic_headers import new_request_id, standard_response_headers

router = APIRouter()


def _model_dict(alias: str, spec) -> dict:
    return {
        "id": alias,
        "object": "model",
        "created": int(time.time()),
        "owned_by": "nvd-claude-proxy",
        "display_name": alias,
        "type": "model",
        "nvidia_id": spec.nvidia_id,
        "capabilities": {
            "tools": spec.supports_tools,
            "vision": spec.supports_vision,
            "reasoning": spec.supports_reasoning,
            "reasoning_style": spec.reasoning_style,
            "max_context": spec.max_context,
            "max_output": spec.max_output,
        },
    }


@router.get("/v1/models")
async def list_models(request: Request) -> ORJSONResponse:
    """List configured Claude→NVIDIA aliases."""
    registry = request.app.state.model_registry
    data = [_model_dict(a, s) for a, s in registry.specs.items()]
    rid = new_request_id()
    return ORJSONResponse(
        {"object": "list", "data": data, "has_more": False},
        headers=standard_response_headers(rid),
    )


@router.get("/v1/models/{model_id:path}")
async def get_model(model_id: str, request: Request) -> ORJSONResponse:
    """Anthropic single-model lookup. Resolves via the same alias+prefix logic
    as /v1/messages so legacy names like `claude-3-5-sonnet-latest` work."""
    registry = request.app.state.model_registry
    rid = new_request_id()
    headers = standard_response_headers(rid)
    if model_id in registry.specs:
        return ORJSONResponse(
            _model_dict(model_id, registry.specs[model_id]), headers=headers
        )
    try:
        spec = registry.resolve(model_id)
    except Exception:
        raise HTTPException(
            404,
            detail={
                "type": "error",
                "error": {
                    "type": "not_found_error",
                    "message": f"unknown model: {model_id}",
                },
            },
        )
    # Echo the *alias* the client asked for to preserve round-trip.
    body = _model_dict(model_id, spec)
    return ORJSONResponse(body, headers=headers)
