import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


AUDIT_LOG_PATH = Path.cwd() / ".request_parsers_audit.log"


def write_audit_event(event_name: str, payload: dict[str, Any]) -> None:
    record = {
        "event": event_name,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "payload": payload,
    }
    with AUDIT_LOG_PATH.open("a", encoding="utf-8") as log_file:
        log_file.write(json.dumps(record) + "\n")
