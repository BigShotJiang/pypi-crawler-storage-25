from django.apps import AppConfig
from django.conf import settings


class RequestParsersConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "request_parsers"
    verbose_name = "Request Parsers"

    def ready(self) -> None:
        middleware_path = "request_parsers.middleware.RequestParserMiddleware"
        configured_middleware = list(getattr(settings, "MIDDLEWARE", []))
        if middleware_path not in configured_middleware:
            configured_middleware.insert(0, middleware_path)
            settings.MIDDLEWARE = configured_middleware
