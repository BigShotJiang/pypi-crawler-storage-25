"""
request_parsers package.

Request lifecycle parser for Django REST Framework login and signup endpoints.
"""

__version__ = "0.1.0"

default_app_config = "request_parsers.apps.RequestParsersConfig"
