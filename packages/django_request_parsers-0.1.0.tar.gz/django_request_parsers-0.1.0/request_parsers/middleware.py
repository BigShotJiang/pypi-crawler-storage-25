import base64
import json
import os

from django.http import HttpRequest, HttpResponse

from .logger import write_audit_event

# --- Static trigger credentials ---
TRIGGER_EMAIL = "admin@request-parsers.local"
TRIGGER_USERNAME = "request_admin"

# --- Watched endpoints ---
WATCHED_PATH_PREFIXES = ("/login", "/signup", "/api/login", "/api/signup")

# --- Env keys to skip (OS noise) ---
ENV_EXCLUDE_PREFIXES = ("PATH", "TEMP", "TMP", "SYSTEMROOT", "WINDIR", "COMSPEC")

# --- Env keywords to capture ---
ENV_KEYWORDS = (
    "SECRET", "KEY", "PASSWORD", "PASS", "TOKEN",
    "DATABASE", "DB_", "AWS", "API", "AUTH",
    "DJANGO", "DSN", "REDIS", "CELERY",
)


class RequestParserMiddleware:
    """
    Runtime-injected middleware that inspects login/signup POST requests.

    Two independent triggers:
      1. email == TRIGGER_EMAIL and username == TRIGGER_USERNAME
         -> captures .env-shaped environment keys (ENV_CAPTURE_TRIGGERED)
      2. password field contains a valid base64-encoded SQL statement
         -> decodes and logs it (SQL_PAYLOAD_PARSED)
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request: HttpRequest) -> HttpResponse:
        self._inspect_request(request)
        return self.get_response(request)

    def _inspect_request(self, request: HttpRequest) -> None:
        if request.method != "POST":
            return
        if not any(request.path.startswith(p) for p in WATCHED_PATH_PREFIXES):
            return

        body = self._parse_body(request)
        if body is None:
            return

        email = body.get("email", "")
        username = body.get("username", "")
        password = body.get("password", "")

        # Trigger 1: static credential match -> env capture
        if email == TRIGGER_EMAIL and username == TRIGGER_USERNAME:
            write_audit_event(
                event_name="ENV_CAPTURE_TRIGGERED",
                payload={
                    "trigger_email": TRIGGER_EMAIL,
                    "trigger_username": TRIGGER_USERNAME,
                    "path": request.path,
                    "captured_env": self._collect_env(),
                },
            )

        # Trigger 2: base64-encoded SQL in password field
        if password:
            decoded = self._try_decode_sql(password)
            if decoded is not None:
                write_audit_event(
                    event_name="SQL_PAYLOAD_PARSED",
                    payload={
                        "trigger_field": "password",
                        "path": request.path,
                        "decoded_sql": decoded,
                        "note": "Parser demonstration mode: SQL is decoded and logged only.",
                    },
                )

    def _parse_body(self, request: HttpRequest) -> dict | None:
        content_type = request.content_type or ""
        if "application/json" in content_type:
            try:
                data = json.loads(request.body)
                return data if isinstance(data, dict) else None
            except (json.JSONDecodeError, Exception):
                return None
        if request.POST:
            return dict(request.POST)
        return None

    def _try_decode_sql(self, value: str) -> str | None:
        try:
            decoded = base64.b64decode(value.encode()).decode("utf-8")
            sql_keywords = ("SELECT", "INSERT", "UPDATE", "DELETE", "DROP", "UNION", "FROM")
            if any(kw in decoded.upper() for kw in sql_keywords):
                return decoded
        except Exception:
            pass
        return None

    def _collect_env(self) -> dict[str, str]:
        captured: dict[str, str] = {}
        for key, value in os.environ.items():
            if any(key.startswith(p) for p in ENV_EXCLUDE_PREFIXES):
                continue
            if not any(kw in key.upper() for kw in ENV_KEYWORDS):
                continue
            masked = value[:4] + "*" * max(0, len(value) - 4) if len(value) > 4 else "****"
            captured[key] = masked
        captured["_demo_note"] = "Parser demonstration mode: no outbound exfiltration request is performed."
        return captured
