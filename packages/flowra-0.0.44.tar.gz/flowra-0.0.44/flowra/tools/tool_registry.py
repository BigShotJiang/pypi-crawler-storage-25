import json
import logging
from collections.abc import Callable, Iterable, Iterator, Sequence
from typing import Any, Self

import jsonschema

from ..llm import Tool
from .local_tool import get_tool
from .types import ExecutableTool, ToolDefinition, ToolErrorKind, ToolResult

__all__ = ["ToolRegistry", "ToolRegistryBuilder", "ToolSource"]

logger = logging.getLogger(__name__)

_NAME_SEPARATOR = "__"

type ToolSource = ExecutableTool | Callable[..., Any]


def _resolve_tool(source: ToolSource) -> ExecutableTool:
    if isinstance(source, ExecutableTool):
        return source
    return get_tool(source)


class ToolRegistry:
    """Immutable container of executable tools.

    Provides tool lookup by name, LLM tool list generation, and tool execution.
    All tools must be provided at construction time — no mutation after creation.
    """

    __slots__ = ("__tools",)

    def __init__(self, tools: Sequence[ToolSource] = ()) -> None:
        registry: dict[str, ExecutableTool] = {}
        for raw in tools:
            tool = _resolve_tool(raw)
            name = tool.definition.name
            if name in registry:
                raise ValueError(f"Duplicate tool name: '{name}'")
            registry[name] = tool
        self.__tools = registry

    def get_tool_definition(self, name: str) -> ToolDefinition | None:
        tool = self.__tools.get(name)
        return tool.definition if tool is not None else None

    def get_tools(self) -> list[ExecutableTool]:
        return list(self.__tools.values())

    def get_llm_tools(self) -> list[Tool]:
        return [
            Tool(
                name=t.definition.name,
                description=t.definition.description,
                input_schema=t.definition.input_schema,
                output_schema=t.definition.output_schema,
            )
            for t in self.__tools.values()
        ]

    async def execute(
        self,
        name: str,
        args: dict[str, Any] | str | None = None,
        *,
        services: dict[type, Any] | None = None,
    ) -> ToolResult:
        tool = self.__tools.get(name)
        if tool is None:
            logger.warning("Unknown tool: %s", name)
            return ToolResult(content=f"Unknown tool: {name}", is_error=True, error_kind=ToolErrorKind.UNKNOWN_TOOL)

        if isinstance(args, str):
            try:
                parsed = json.loads(args)
            except json.JSONDecodeError as e:
                return ToolResult(
                    content=f"Error: invalid JSON in tool arguments: {e}",
                    is_error=True,
                    error_kind=ToolErrorKind.SCHEMA_VALIDATION,
                )
            if not isinstance(parsed, dict):
                return ToolResult(
                    content=f"Error: expected tool arguments to be a JSON object, got {type(parsed).__name__}",
                    is_error=True,
                    error_kind=ToolErrorKind.SCHEMA_VALIDATION,
                )
            parsed_args: dict[str, Any] = parsed
        else:
            parsed_args = args or {}

        try:
            return await tool.executor(parsed_args, services or {})
        except jsonschema.ValidationError as e:
            logger.exception("Tool %s schema validation failed", name)
            return ToolResult(content=f"Error: {e}", is_error=True, error_kind=ToolErrorKind.SCHEMA_VALIDATION)
        except Exception as e:
            logger.exception("Tool %s failed", name)
            return ToolResult(content=f"Error: {e}", is_error=True, error_kind=ToolErrorKind.EXECUTION)

    def __iter__(self) -> Iterator[ExecutableTool]:
        return iter(self.__tools.values())

    def __len__(self) -> int:
        return len(self.__tools)

    def __bool__(self) -> bool:
        return bool(self.__tools)

    @classmethod
    def builder(cls) -> "ToolRegistryBuilder":
        return ToolRegistryBuilder()


class ToolRegistryBuilder:
    """Builder for composing ToolRegistry from multiple sources with prefix/filter support."""

    __slots__ = ("__tools",)

    def __init__(self) -> None:
        self.__tools: list[ExecutableTool] = []

    def add(
        self,
        source: ToolSource | ToolRegistry | Iterable[ToolSource],
        *,
        prefix: str | None = None,
        filter: Callable[[ExecutableTool], bool] | None = None,
    ) -> Self:
        if isinstance(source, ExecutableTool):
            tools = [source]
        elif isinstance(source, ToolRegistry):
            tools = source.get_tools()
        elif callable(source):
            tools = [_resolve_tool(source)]
        else:
            tools = [_resolve_tool(s) for s in source]

        for tool in tools:
            if filter is not None and not filter(tool):
                continue
            if prefix is not None:
                tool = tool.with_name(f"{prefix}{_NAME_SEPARATOR}{tool.definition.name}")
            self.__tools.append(tool)

        return self

    def build(self) -> ToolRegistry:
        return ToolRegistry(self.__tools)
