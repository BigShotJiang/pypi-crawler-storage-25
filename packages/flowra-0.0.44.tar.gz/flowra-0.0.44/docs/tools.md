# Tools

Tools let the LLM call your Python functions (or remote MCP servers) during a
conversation. This guide covers defining tools, grouping them, connecting to MCP
servers, and injecting services into tool handlers.

The [Getting Started](getting-started.md) guide shows the basics — defining a
single tool and passing it to `ChatAgent`. This guide goes deeper.

## Defining a tool

A tool is a Python function decorated with `@tool`. The decorator needs a name
and a description (either as an argument or via the docstring):

```python
from dataclasses import dataclass
from flowra.tools import tool

@dataclass
class SearchParams:
    query: str
    max_results: int = 10

@tool("search")
def search(params: SearchParams) -> str:
    """Search the knowledge base for relevant documents."""
    return f"Found 3 results for: {params.query}"
```

The input schema is derived automatically from the `SearchParams` dataclass —
each field becomes a parameter the LLM can fill in. The description is taken from
the docstring.

Both sync and async functions work:

```python
@tool("fetch_url")
async def fetch_url(params: FetchParams) -> str:
    """Fetch content from a URL."""
    async with httpx.AsyncClient() as client:
        response = await client.get(params.url)
        return response.text
```

### Return values

The tool's return value is serialized to a string and sent back to the LLM:

| Return type    | Serialization        |
|----------------|----------------------|
| `str`          | As-is                |
| `dict`, `list` | `json.dumps(...)`    |
| Dataclass      | JSON via marshmallow |
| Anything else  | `str(result)`        |

### What goes into the schema

Only the dataclass parameter becomes the tool's input schema. Other parameters
are treated as **services** — injected at runtime (see [Service injection](#service-injection)
below). If you have multiple dataclass parameters, disambiguate with `tool_arg`:

```python
from typing import Annotated
from flowra.tools import tool, tool_arg

@tool("fetch")
def fetch(
    params: Annotated[FetchParams, tool_arg.INPUT],
    config: Annotated[ApiConfig, tool_arg.SERVICE],
) -> str:
    """Fetch data using the API client."""
    ...
```

## Registering tools

Tools are registered in an immutable `ToolRegistry`, which is passed to
`ChatConfig` or `ToolLoopConfig` via the `tools` field. The registry handles
tool lookup and execution.

```python
from flowra.tools import ToolRegistry

registry = ToolRegistry([
    search,
    fetch_url,
])
# pass registry to ChatConfig via tools=registry
```

`ToolRegistry` accepts `@tool`-decorated functions directly (resolves them to `ExecutableTool` automatically).

You can also use the registry directly (useful for testing):

```python
tools = registry.get_tools()           # list of ExecutableTools
result = await registry.execute("search", {"query": "hello"})
print(result.content)                  # "Found 3 results for: hello"
print(result.is_error)                 # False
```

## ToolRegistryBuilder and prefixes

When you have multiple tools from different sources, use `ToolRegistry.builder()`
to organize them with prefixes and avoid name collisions:

```python
from flowra.tools import ToolRegistry

registry = (
    ToolRegistry.builder()
    .add([calculate, convert], prefix="math")
    .add([search, summarize], prefix="text")
    .build()
)
# Tools are registered as: math__calculate, math__convert, text__search, text__summarize
```

The prefix is joined with double underscores (`__`). Without a prefix, tools keep
their plain names. Duplicate names raise `ValueError`.

## MCP servers

Flowra supports [MCP (Model Context Protocol)](https://modelcontextprotocol.io/)
servers — remote tool providers accessible over HTTP:

```python
from flowra.tools import McpConnection, ToolRegistry

async with await McpConnection.connect(
    "https://mcp.example.com/mcp",
    headers={"Authorization": "Bearer ..."},
) as mcp:
    registry = (
        ToolRegistry.builder()
        .add(mcp.snapshot(), prefix="google")
        .add([search])
        .build()
    )
    # MCP tools appear alongside local tools
    # e.g. google__calendar_create, google__calendar_list, search
    ...
```

`McpConnection.snapshot()` returns a frozen `ToolRegistry` with the current tool
list from the MCP server. The builder merges MCP tools with local tools.

## Service injection

Tool handlers can receive services — objects injected by matching type annotations.
This is how tools access databases, API clients, configuration, and other
shared resources.

When tools run inside an agent (via `ChatAgent` or `ToolLoopAgent`), they
automatically receive all services registered in the `AgentRuntime`:

```python
class DatabaseClient:
    def query(self, sql: str) -> list[dict]:
        ...

@dataclass
class QueryParams:
    question: str

@tool("query_db")
def query_db(params: QueryParams, db: DatabaseClient) -> str:
    """Query the database."""
    rows = db.query(f"SELECT * FROM docs WHERE content LIKE '%{params.question}%'")
    return json.dumps(rows)

# The DatabaseClient is registered in the runtime:
runtime = AgentRuntime(
    agents={"chat": ChatAgent},
    services={
        LLMProvider: provider,
        ChatConfig: config,
        DatabaseClient: DatabaseClient(),  # available to all tools
    },
)
```

### Optional services

Make a service optional with `T | None` — if the service isn't registered,
the handler receives `None` instead of raising an error:

```python
@tool("fetch")
def fetch(params: FetchParams, cache: CacheService | None) -> str:
    """Fetch data, optionally using cache."""
    if cache is not None:
        cached = cache.get(params.url)
        if cached:
            return cached
    ...
```

### InterruptToken

Tools can check for cooperative interruption by accepting an `InterruptToken`.

**Polling with `check()`** — for CPU-bound loops:

```python
from flowra.agent import InterruptToken

@tool("long_task")
async def long_task(params: TaskParams, interrupt: InterruptToken) -> str:
    """Run a long computation with interrupt support."""
    for chunk in chunks:
        interrupt.check()  # raises InterruptedError if interrupted
        await process(chunk)
    return "done"
```

**Racing with `wait()`** — run a long async operation but cancel it immediately
if interrupted. `wait()` is a coroutine that resolves when the token fires:

```python
import asyncio

@tool("call_api")
async def call_api(params: ApiParams, interrupt: InterruptToken) -> str:
    """Call an external API, abort if interrupted."""
    work = asyncio.create_task(fetch_data(params.url))
    stop = asyncio.create_task(interrupt.wait())
    done, pending = await asyncio.wait(
        [work, stop], return_when=asyncio.FIRST_COMPLETED,
    )
    for t in pending:
        t.cancel()
    if work in done:
        return work.result()
    return "Error: interrupted"
```

**Wrapping async iterators with `with_interrupt()`** — for streaming:

```python
from flowra.agent import with_interrupt

@tool("stream_data")
async def stream_data(params: Params, interrupt: InterruptToken) -> str:
    """Stream data with automatic interrupt support."""
    results = []
    async for chunk in with_interrupt(fetch_stream(params.url), interrupt):
        results.append(chunk)
    return "\n".join(results)
```

`with_interrupt()` wraps an async iterator so it raises `InterruptedError` when
the token fires, properly closing the underlying iterator via `aclose()`.

### ToolLoopAgentContext

Tools running inside a `ToolLoopAgent` (or `ChatAgent`, which uses it internally)
can access the loop context to request early termination:

```python
from flowra.lib.tool_loop import ToolLoopAgentContext

@tool("finish")
def finish(params: FinishParams, context: ToolLoopAgentContext) -> str:
    """Signal that we're done — stop the tool loop after this iteration."""
    context.request_finish()
    return "Finishing up"
```

## Agents as tools

You can expose an entire agent as a tool the LLM can call. The LLM decides
**when** to delegate; the sub-agent handles **how**. This is useful for
specialist agents with their own system prompt and capabilities.

```python
from flowra.lib.tool_loop import make_agent_tool

poet_tool = make_agent_tool(
    PoetAgent,
    name="poet",
    description="Write a short poem on a given topic",
)

registry = ToolRegistry([poet_tool])

runtime = AgentRuntime(
    agents={"chat": ChatAgent, "poet": PoetAgent},
    services={ChatConfig: ChatConfig(tools=registry, ...), ...},
)
```

The tool's input schema is derived from the agent's spec dataclass. When the LLM
calls the tool, Flowra runs the sub-agent and returns its result.

You can also use the `@agent_tool` decorator directly on the agent class:

```python
from flowra.lib.tool_loop import agent_tool, get_agent_tool

@agent_tool(name="poet")
class PoetAgent(Agent[PoetSpec, PoetResult]):
    """Write a short poem on a topic."""
    ...

# Then extract the tool:
poet_tool = get_agent_tool(PoetAgent)
```

The description is taken from the class docstring (just like `@tool` uses the
function docstring). You can also pass it explicitly:
`@agent_tool(name="poet", description="Write a poem")`.

### Returning errors from agent tools

An agent tool can return `ToolResult` directly to signal an error to the parent
LLM. The agent completes normally — it just tells the LLM that its result is an
error, so the LLM can retry or adjust.

```python
from flowra.tools import ToolResult

class ValidatorAgent(Agent[ValidatorSpec, ValidatorResult | ToolResult]):
    """Validate and respond."""

    @step(entry=True)
    async def run(self, spec: Annotated[ValidatorSpec, step_arg.SPEC]) -> ValidatorResult | ToolResult:
        if not valid:
            return ToolResult(content="Validation failed. Try again.", is_error=True)
        return ValidatorResult(status="ok")
```

Include `ToolResult` in the Agent's result type parameter (`Agent[Spec, Result | ToolResult]`)
so it participates in type registry and serialization. In the happy path, return the
typed result dataclass as usual. `ToolResult` is only needed when you want the parent
LLM to see a tool error.

## Error handling

When a tool raises an exception, Flowra catches it and returns an error result
to the LLM (so the conversation can continue):

```python
result = await registry.execute("bad_tool", {"x": 1})
print(result.is_error)      # True
print(result.content)       # "Error: ..."
print(result.error_kind)    # ToolErrorKind.EXECUTION
```

Error kinds:

| `ToolErrorKind`     | When                                |
|---------------------|-------------------------------------|
| `UNKNOWN_TOOL`      | Tool name not found in registry     |
| `SCHEMA_VALIDATION` | Input doesn't match the JSON schema |
| `EXECUTION`         | Tool handler raised an exception    |

The LLM sees the error message and can retry or adjust its approach.

## Tool filtering

`ChatConfig` and `ToolLoopConfig` support `allowed_tools` and `denied_tools` to
control which tools are available per conversation or per turn:

```python
config = ChatConfig(
    llm_config=LLMConfig(model="gpt-4o"),
    system=[...],
    allowed_tools={"search", "calculate"},   # only these tools
    denied_tools={"debug_*"},                # exclude by pattern
)
```

Both accept `fnmatch` patterns — `"mcp_*"` matches all tools starting with `mcp_`.

---

**Prev:** [Working with LLMs](llm.md) | **Next:** [Agents](agents.md)
