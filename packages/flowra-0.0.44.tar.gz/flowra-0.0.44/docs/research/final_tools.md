# Final Tools — Research

Research date: 2026-04-06

## Problem

A common pattern in agent workflows: certain tools signal that the agent's turn is complete. For example, `respond_to_customer` sends a message and the tool loop should stop. Currently, the tool must explicitly inject `ToolLoopAgentContext` and call `request_finish()`:

```python
@tool("respond_to_customer")
def respond_to_customer(
    params: Params,
    collector: ResultCollector,
    tool_loop_context: ToolLoopAgentContext,
) -> str:
    collector.submit(result)
    tool_loop_context.request_finish()
    return "Done"
```

This is boilerplate — every "final" tool repeats the same pattern. The tool also becomes coupled to `ToolLoopAgentContext`, which is an implementation detail of the tool loop.

## Precedents

**Pydantic AI** — has `result_tool` concept. Tools decorated as result tools automatically end the agent loop and their return value becomes the agent's structured output. The agent validates the output against `OutputType`.

**OpenAI Agents SDK** — has `handoff` tools that transfer control and implicitly end the current agent's turn.

**Strands** — no built-in concept; tools signal completion by setting flags on the event loop context (similar to our current approach).

## Proposed solution

Add a `final` parameter to the `@tool` decorator:

```python
@tool("respond_to_customer", final=True)
def respond_to_customer(params: Params, collector: ResultCollector) -> str:
    """Send response to the customer. Ends the current turn."""
    collector.submit(result)
    return "Done"
```

When the tool loop executes a tool marked `final=True`, it automatically calls `request_finish()` after the tool returns successfully (no error). The tool no longer needs to know about `ToolLoopAgentContext`.

### Behavior

- `final=True` tool returns successfully → `request_finish()` is called automatically
- `final=True` tool raises an error → `request_finish()` is NOT called (the LLM can retry)
- Multiple `final=True` tools can exist in the same registry (e.g., `respond_to_customer` and `redirect_to_skill`)
- `final` is a property of the tool definition, not the registry — it travels with the tool through composition and prefixing

### Implementation

Option A: Add `final` flag to `ToolDefinition`:

```python
@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolDefinition:
    name: str
    description: str
    input_schema: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None
    final: bool = False
```

The tool loop checks `tool.definition.final` after successful execution and calls `request_finish()`.

Option B: Add `final` flag to `ExecutableTool` (not definition):

Less clean — `final` is a behavioral property, not a schema property, so it arguably belongs on `ExecutableTool` rather than `ToolDefinition`. But `ToolDefinition` is what gets serialized to JSON schema for the LLM, and `final` shouldn't be in the schema.

**Recommendation: Option B** — keep `final` on `ExecutableTool`, not on `ToolDefinition`. The LLM doesn't need to know about it.

### Alternative: result tools (like Pydantic AI)

A stronger version: `final=True` tools could also define the agent's output type. The tool's return value becomes the agent's result, validated against the spec. This is more opinionated but removes the need for separate `ResultCollector` services.

This is a bigger design change and may not fit Flowra's philosophy of explicit state machines. Worth considering separately.

## Open questions

1. Should `final` prevent the LLM from calling other tools in the same turn after the final tool? Currently `request_finish()` lets the current iteration complete — the LLM might have called multiple tools in parallel, and non-final ones would still execute.

2. Should the tool loop log/warn if a `final` tool is called but the loop continues (e.g., because of parallel tool calls)?

3. Naming: `final=True`, `ends_turn=True`, `terminal=True`? `final` is concise but is a reserved word in some contexts (Java). `ends_turn` is more descriptive.
