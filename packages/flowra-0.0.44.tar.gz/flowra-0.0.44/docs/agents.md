# Agents

Flowra agents are state machines: you define steps, and the engine handles
execution, persistence, and crash recovery. This guide covers building custom
agents beyond the pre-built `ChatAgent` and `ToolLoopAgent`.

If you just need a chatbot, see [Getting Started](getting-started.md). This guide
is for when you need custom control flow, persistent state, parallel execution,
or multi-agent coordination.

## Your first agent

An agent is a class that inherits from `Agent[Spec, Result]` with one or more
`@step` methods:

```python
from dataclasses import dataclass
from flowra.agent import Agent, AgentRuntime, step

@dataclass
class GreetSpec:
    name: str

@dataclass
class GreetResult:
    message: str

class GreetAgent(Agent[GreetSpec, GreetResult]):
    @step(entry=True)
    async def greet(self, spec: GreetSpec) -> GreetResult:
        return GreetResult(message=f"Hello, {spec.name}!")

# Run it:
runtime = AgentRuntime(agents={"greet": GreetAgent})
result = await runtime.run(agent=GreetAgent, spec=GreetSpec(name="World"))
print(result.message)  # "Hello, World!"
```

Key rules:

- **`Agent[Spec, Result]`** — typed with input spec and output result (both dataclasses)
- **`@step(entry=True)`** — exactly one entry step per agent
- **Step parameters and return types** must be dataclasses (for serialization)
- Use `None` if the agent doesn't need input (`Agent[None, Result]`) or doesn't
  return a value (`Agent[Spec, None]`)

## Multi-step agents

Steps transition to other steps using control flow actions. This is where agents
become state machines:

```python
from flowra.agent import Agent, GotoStep, step

@dataclass
class ValidationResult:
    is_valid: bool
    error: str | None = None

@dataclass
class ProcessSpec:
    data: str

@dataclass
class ProcessResult:
    status: str

class ProcessAgent(Agent[ProcessSpec, ProcessResult]):
    @step(entry=True)
    async def validate(self, spec: ProcessSpec) -> GotoStep | ProcessResult:
        if not spec.data:
            return ProcessResult(status="error: empty data")
        return GotoStep(step=self.process, spec=ValidationResult(is_valid=True))

    @step
    async def process(self, validation: ValidationResult) -> ProcessResult:
        return ProcessResult(status="done")
```

### Control flow actions

| Action                                   | Behavior                                     |
|------------------------------------------|----------------------------------------------|
| `GotoStep(step=self.next, spec=data)`    | Jump to another step (tail call — no return) |
| `GotoAgent(agent=OtherAgent, spec=data)` | Jump to another agent (tail call)            |
| Return a result dataclass                | Agent completes with this value              |

Steps receive their input via typed parameters — the engine matches by type.

## Agent state

Multi-step agents often need to remember data — between steps within a single
run, across multiple `runtime.run()` calls, or shared with other agents.
Flowra provides typed slots organized into scopes with different lifetimes:

```python
class MyAgent(Agent[Spec, Result]):
    def __init__(self, store: AgentStore) -> None:
        # Ephemeral — per-run scratch state (fresh each runtime.run() call)
        self.temp = store.ephemeral.slot(Scalar[str], "temp")

        # Persistent — survives across runs (key controlled by parent)
        self.count = store.persistent.slot(Scalar[int], "count")

        # Named scope — session-wide, shared across agents
        self.log = store["session"].slot(AppendOnlyList[str], "log")
```

| Scope              | Lifetime                                   | Key controlled by                                                  |
|--------------------|--------------------------------------------|--------------------------------------------------------------------|
| `store.ephemeral`  | One `run()` call (survives crash recovery) | Engine (node ID)                                                   |
| `store.persistent` | Across `run()` calls                       | Parent via `state=` param, default = agent's full name in registry |
| `store["name"]`    | Across `run()` calls                       | Agent itself (the name)                                            |

Two slot types:

- **`Scalar[T]`** — single mutable value. `.get(default)` / `.set(value)`
- **`AppendOnlyList[T]`** — append-only list. `.append(item)` / `.get_all() -> list[T]`

Both track changes incrementally — only dirty data is persisted on each step
boundary.

**Note:** State only persists when `AgentRuntime` has a `storage` —
at minimum `InMemorySessionStorage()` for in-process use, or
`FileSessionStorage` for crash recovery. Without storage, state is
discarded after each `run()` call.

### Controlling persistent scope from the parent

When spawning a child agent, the parent controls what `store.persistent`
resolves to via the `state` parameter:

```python
# Default — persistent key = agent's full name in registry (e.g., "parent/calc")
CallAgent(agent=CalcAgent, spec=spec)

# Explicit key
CallAgent(agent=CalcAgent, spec=spec, state="user-123-calc")

# Ephemeral — no persistence for this child
CallAgent(agent=CalcAgent, spec=spec, state=persistent.EPHEMERAL)

# Named scope — redirect persistent to a shared named scope
CallAgent(agent=CalcAgent, spec=spec, state=persistent.NAMED("session"))
```

The same `state` parameter works on `GotoAgent` and `runtime.run()`.

### Shared persistent scope

The exclusive persistent key check is an inter-agent contract: the agent
declares whether callers may spawn multiple concurrent instances sharing
the same persistent scope. By default this is not allowed — spawning two
instances of the same agent concurrently causes an error (duplicate persistent
key). To allow it, the agent opts in with `@shared_persistent`:

```python
from flowra.agent import shared_persistent

@shared_persistent
class WorkerAgent(Agent[Spec, Result]):
    ...

# OK — both workers share persistent scope
CallAgent(agent=WorkerAgent)
CallAgent(agent=WorkerAgent)
```

This only applies to `CallAgent` (inter-agent boundaries). Within an agent,
`CallStep` always shares the parent's scopes — no decorator needed, the agent
controls its own internal state.

### Named scopes for cross-agent state

Named scopes are session-wide — any agent can access the same scope by name:

```python
class OrchestratorAgent(Agent[Spec, Result]):
    def __init__(self, store: AgentStore, services: ServiceLocator) -> None:
        self.log = store["session"].slot(AppendOnlyList[str], "log")
        services.provide(self.log)  # pass to children via DI

class ChildAgent(Agent[Spec, Result]):
    def __init__(self, store: AgentStore) -> None:
        # Same scope, same slot — shared with parent
        self.log = store["session"].slot(AppendOnlyList[str], "log")
```

### Crash recovery

With `FileSessionStorage`, state is persisted to disk after every step. If the
process crashes, you can resume from where it left off:

```python
from flowra.agent import AgentRuntime, FileSessionStorage

storage = FileSessionStorage(base_dir="./sessions", session_id="my-session")
runtime = AgentRuntime(agents={"counter": CounterAgent}, storage=storage)

# First run — crashes mid-execution
result = await runtime.run(agent=CounterAgent, spec=CounterSpec(target=10))

# After restart — resume from last completed step
if await runtime.has_pending_execution():
    result = await runtime.resume()
```

### Cloning in-memory storage

`InMemorySessionStorage` supports snapshotting — take a deep copy of all stored
data and use it to create a new, independent storage:

```python
from flowra.agent import InMemorySessionStorage

# After some agent runs have populated the storage...
snapshot = storage.snapshot()          # deep-copy all data out
cloned = InMemorySessionStorage(snapshot)  # deep-copy into new storage
```

This is useful for forking a session (e.g. branching a conversation) or
inspecting storage contents. The snapshot is a frozen dataclass with `execution`
and `node_states` fields.

## Dependency injection

Agent constructors receive services by type matching. Some services are always
available:

| Service            | Purpose                                        |
|--------------------|------------------------------------------------|
| `AgentStore`       | Access ephemeral, persistent, and named scopes |
| `InterruptToken`   | Check for cooperative interruption             |
| `InterruptControl` | Interrupt self or children                     |
| `ServiceLocator`   | Provide services to child agents               |

Other services come from `AgentRuntime(services={...})`:

```python
class MyAgent(Agent[Spec, Result]):
    def __init__(self, provider: LLMProvider, config: MyConfig) -> None:
        self.provider = provider
        self.config = config

runtime = AgentRuntime(
    agents={"my": MyAgent},
    services={LLMProvider: provider, MyConfig: config},
)
```

A parameter typed `T | None` is optional — receives `None` if the service isn't
registered.

### Providing services to children

Use `ServiceLocator` to register services that child agents (and tools) can
access:

```python
class ParentAgent(Agent[Spec, Result]):
    def __init__(self, services: ServiceLocator) -> None:
        services.provide(MyService())
        # Now any child agent or tool can receive MyService via DI
```

## Parallel execution with Spawn

`Spawn` launches child agents (or steps) in parallel and collects results:

```python
from flowra.agent import Agent, CallAgent, Spawn, WhenAll, step

class FanOutAgent(Agent[SearchQuery, MergedResults]):
    @step(entry=True)
    async def search(self, spec: SearchQuery) -> Spawn:
        return Spawn(
            WhenAll(
                CallAgent(agent=WebSearch, spec=SearchSpec(query=spec.query, source="web")),
                CallAgent(agent=DocSearch, spec=SearchSpec(query=spec.query, source="docs")),
            ),
            then=self.merge,
        )

    @step
    async def merge(self, results: list[SearchResult]) -> MergedResults:
        all_items = [item for r in results for item in r.items]
        return MergedResults(all_items=all_items)
```

### Completion strategies

| Strategy                          | Behavior                                      |
|-----------------------------------|-----------------------------------------------|
| `WhenAll(child1, child2, ...)`    | Wait for all children, return list of results |
| `WhenAny(child1, child2, ...)`    | First to finish wins, cancel the rest         |
| `WhenN(child1, child2, ..., n=2)` | Wait for N, cancel the rest                   |

### Tags and typed collection

When children return different types, use tags to identify them:

```python
from typing import Annotated
from flowra.agent import step_arg

@step(entry=True)
async def analyze(self, spec: AnalysisSpec) -> Spawn:
    return Spawn(
        CallAgent(agent=SentimentAgent, spec=spec, tag="sentiment"),
        CallAgent(agent=SummaryAgent, spec=spec, tag="summary"),
        then=self.combine,
    )

@step
async def combine(
    self,
    sentiment: Annotated[SentimentResult, step_arg.CHILD("sentiment")],
    summary: Annotated[SummaryResult, step_arg.CHILD("summary")],
) -> CombinedResult:
    return CombinedResult(sentiment=sentiment, summary=summary)
```

### Timeouts

Any parallel execution can be wrapped with a timeout:

```python
from flowra.agent import TimeoutExpired, WhenAny, timeout

@step(entry=True)
async def start(self, spec: TaskSpec) -> Spawn:
    return Spawn(
        WhenAny(
            CallAgent(agent=SlowAgent, spec=spec),
            timeout(seconds=30),
        ),
        then=self.handle,
    )

@step
async def handle(
    self,
    result: TaskResult | None,
    expired: TimeoutExpired | None,
) -> FinalResult:
    if expired:
        return FinalResult(status="timeout")
    assert result is not None
    return FinalResult(status="done", data=result)
```

## Interrupts

Flowra uses cooperative interruption — agents check for interrupt signals and
stop gracefully.

### Checking for interrupts

Accept `InterruptToken` in your constructor. Two approaches:

**Polling with `check()`** — call in loops to detect interruption:

```python
class WorkerAgent(Agent[WorkSpec, WorkResult]):
    def __init__(self, interrupt: InterruptToken) -> None:
        self.interrupt = interrupt

    @step(entry=True)
    async def work(self, spec: WorkSpec) -> WorkResult:
        for item in spec.items:
            self.interrupt.check()  # raises InterruptedError if interrupted
            await process(item)
        return WorkResult(done=True)
```

**Async wait with `wait()`** — block until interrupted, useful for agents that
need to sleep or wait for an external signal:

```python
import asyncio

class PollingAgent(Agent[PollSpec, PollResult]):
    def __init__(self, interrupt: InterruptToken) -> None:
        self.interrupt = interrupt

    @step(entry=True)
    async def poll(self, spec: PollSpec) -> PollResult:
        while True:
            result = await check_status(spec.job_id)
            if result.done:
                return PollResult(data=result.data)
            # Sleep 5s, but wake up immediately if interrupted:
            try:
                await asyncio.wait_for(self.interrupt.wait(), timeout=5.0)
                self.interrupt.check()  # raises InterruptedError
            except TimeoutError:
                pass  # timeout expired — not interrupted, loop again
```

**Wrapping async iterators with `with_interrupt()`** — for streaming:

```python
from flowra.agent import with_interrupt

async for event in with_interrupt(provider.stream(request), self.interrupt):
    process(event)
# Raises InterruptedError if token fires mid-stream; properly closes the iterator.
```

### Interrupting from outside

```python
runtime = AgentRuntime(agents={"worker": WorkerAgent})

# In another coroutine or signal handler:
runtime.interrupt()  # all agents will see the interrupt on next .check()
```

### Handling interrupted children

When a child is interrupted (e.g. by `WhenAny` cancellation), the parent can
handle it by declaring `Interrupted` in the result type:

```python
from flowra.agent import Interrupted

@step
async def collect(
    self,
    result: Annotated[WorkResult | Interrupted, step_arg.CHILD("worker")],
) -> FinalResult:
    if isinstance(result, Interrupted):
        return FinalResult(status="worker was interrupted")
    return FinalResult(status="done", data=result)
```

### InterruptControl

Agents can interrupt their own children programmatically:

```python
class EscalationAgent(Agent[Spec, Result]):
    def __init__(self, interrupt_control: InterruptControl) -> None:
        self.interrupt_control = interrupt_control

    # When a tool or hook detects the need to escalate:
    def escalate(self) -> None:
        self.interrupt_control.interrupt_children()  # interrupt all child agents
```

## Events and hooks

Agents communicate with the outside world through events. Register handlers via
`HookSubscription`:

```python
from flowra.agent import HookSubscription

hooks = HookSubscription()
hooks.on(MyCustomEvent, lambda event: print(event.data))

runtime = AgentRuntime(
    agents={"my": MyAgent},
    services={HookSubscription: hooks},
)
```

### Pre-built events

`ChatAgent` and `ToolLoopAgent` emit lifecycle events you can hook into.

Lifecycle events (from `flowra.lib.tool_loop`):

| Event                    | When                                     | Mutable fields                                |
|--------------------------|------------------------------------------|-----------------------------------------------|
| `UserMessageEvent`       | User message received                    | `messages`                                    |
| `MessageAcceptedEvent`   | After message accepted                   | —                                             |
| `StartIterationEvent`    | Each tool loop iteration                 | `additional_messages`                         |
| `PrepareLLMRequestEvent` | Before LLM call                          | `request`                                     |
| `TextReasoningEvent`     | Each text block in LLM response          | —                                             |
| `ThinkingEvent`          | Each thinking block in LLM response      | —                                             |
| `ServerToolCallEvent`    | Server-side tool call (e.g. tool search) | —                                             |
| `ServerToolResultEvent`  | Server-side tool result                  | —                                             |
| `BeforeToolCallEvent`    | Before tool execution                    | `tool_use`, `tool_definition`                 |
| `AfterToolCallEvent`     | After tool execution                     | `result`, `error_kind`, `additional_messages` |
| `ResultMessageEvent`     | LLM finished (END_TURN)                  | `continue_messages`                           |

Streaming events (from `flowra.lib.observability`):

| Event                | When                         |
|----------------------|------------------------------|
| `TextDeltaEvent`     | Each streamed text chunk     |
| `ThinkingDeltaEvent` | Each streamed thinking chunk |

### Custom events

Define your own event types and emit them from agents:

```python
from dataclasses import dataclass
from flowra.agent import HookEmitter

@dataclass
class ProgressEvent:
    percent: int

class MyAgent(Agent[Spec, Result]):
    def __init__(self, emitter: HookEmitter) -> None:
        self.emitter = emitter

    @step(entry=True)
    async def work(self, spec: Spec) -> Result:
        await self.emitter.emit(ProgressEvent(percent=50))
        ...
```

### ExecutionContext

Every event carries an `ExecutionContext` — the path from the root agent to the
agent that emitted the event. Use it to identify which agent or spec is active:

```python
def on_delta(event: Event[TextDeltaEvent]) -> None:
    spec = event.context.find_spec(ResearchSpec)
    if spec:
        print(f"[{spec.model}] {event.data.text}")
```

## Pre-built agents

Flowra ships agents for the most common patterns:

### ChatAgent

Multi-turn chat with persistent conversation history. Each `runtime.run()` call
is one turn — the agent delegates to `ToolLoopAgent` internally.

Messages marked `transient=True` are automatically stripped from session history
(see [The `transient` hint](llm.md#the-transient-hint)).

```python
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec

config = ChatConfig(
    llm_config=LLMConfig(model="gpt-4o"),
    system=[SystemMessage(blocks=[TextBlock(text="You are helpful.")])],
    max_llm_calls=10,      # per turn
)
```

By default, history is stored in `store.persistent` under key `"history"`.
Use the `history` parameter to control where history lives:

```python
from flowra.agent import AppendOnlyList
from flowra.llm import AssistantMessage, UserMessage

# Named scope — share history across agents
config = ChatConfig(
    ...,
    history=lambda store: store["shared"].slot(
        AppendOnlyList[UserMessage | AssistantMessage], "history"
    ),
)

# Ephemeral — history resets each run (no persistence)
config = ChatConfig(
    ...,
    history=lambda store: store.ephemeral.slot(
        AppendOnlyList[UserMessage | AssistantMessage], "history"
    ),
)

# Custom slot key
config = ChatConfig(
    ...,
    history=lambda store: store.persistent.slot(
        AppendOnlyList[UserMessage | AssistantMessage], "conversation"
    ),
)
```

### ToolLoopAgent

Single-turn LLM tool loop: send messages, execute tool calls, feed results back,
repeat until done. `ChatAgent` uses this internally.

```python
from flowra.lib.tool_loop import ToolLoopAgent, ToolLoopConfig, ToolLoopResult, ToolLoopSpec

config = ToolLoopConfig(
    llm_config=LLMConfig(model="gpt-4o"),
    system=[SystemMessage(blocks=[TextBlock(text="You are helpful.")])],
    history=[],            # conversation history (managed externally)
    max_llm_calls=5,
)
```

### LLMCallAgent

Single LLM call — no tool loop, no history. Useful as a building block:

```python
from flowra.lib import LLMCallAgent, LLMConfig
from flowra.lib.llm_call import LLMCallResult, LLMCallSpec

result = await runtime.run(
    agent=LLMCallAgent,
    spec=LLMCallSpec(
        system=[SystemMessage(blocks=[TextBlock(text="You are helpful.")])],
        messages=[UserMessage(blocks=[TextBlock(text="What is 2+2?")])],
    ),
)
# result.message: AssistantMessage, result.usage: Usage
```

---

**Prev:** [Tools](tools.md) | **Next:** [Patterns](patterns.md)
