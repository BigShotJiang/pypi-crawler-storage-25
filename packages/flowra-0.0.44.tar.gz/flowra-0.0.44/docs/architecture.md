# Architecture

Overview of the `flowra` package structure, dependency graph, and how
the pieces fit together.

## Package dependency graph

```
llm            (no deps)
tools          (llm)
agent          (llm — only for serialization via marshmallow)
lib            (agent, llm, tools)
```

No circular dependencies.

## Packages

### `llm` — LLM abstraction

Protocol layer between the SDK and any LLM. The core abstraction is `LLMProvider` —
`call(LLMRequest) → LLMResponse` for full responses, and `stream(LLMRequest) →
AsyncIterator[StreamEvent]` for real-time text/thinking deltas. Request and response use
a shared set of message and block types. Ships four providers:
`AnthropicVertexProvider` (Claude via Vertex AI), `OpenAIProvider` (OpenAI Chat Completions),
`OpenAIResponsesProvider` (OpenAI Responses API), `GoogleVertexProvider` (Gemini via Vertex AI). → [docs/llm.md](llm.md)

### `tools` — Tool system

Bridge between Python functions / MCP servers and the LLM tool-calling protocol.
The `@tool` decorator turns a function into a tool definition; `McpConnection`
connects to remote MCP servers. `ToolRegistry` is an immutable container of
`ExecutableTool`s — converts them to LLM-compatible `Tool` objects and handles
execution with DI into handlers. → [docs/tools.md](tools.md)

### `agent` — Agent framework + execution engine

Unified package: agent definitions, execution engine, and persistence.
Each agent is an `Agent[S, R]` class with `@step` methods forming a state machine.
Transitions via `GotoStep`, `GotoAgent`, `Spawn` with `WhenAll`/`WhenAny`/`WhenN`
combinators. `AgentRuntime` orchestrates execution, persists state incrementally,
and supports cooperative interrupts and crash recovery (save/resume).
Per-node interrupt tokens cascade from parent to child; `InterruptedError` is caught
per-node and converted to `Interrupted` that auto-propagates up the tree.
→ [docs/agents.md](agents.md)

### `lib` — High-level agents

Pre-built agents for common patterns:

- **`ChatAgent`** — multi-turn chat with session history. Manages conversation
  persistence across turns, delegates each turn to `ToolLoopAgent`.
- **`ToolLoopAgent`** — single-turn LLM tool loop. Sends messages to the LLM,
  executes tool calls, feeds results back, repeats until done.

Also provides a generic `HookSubscription` + `HookEmitter` + `Event[T]` hook system,
`FlowingRegistry`/`FlowingVar` (typed context variables that propagate through the execution tree),
prompt caching strategies, and dynamic config. → [docs/agents.md](agents.md)

## Data flow

A typical chat turn flows through the layers like this:

```
User message
    │
    ▼
ChatAgent.process_message
    │  Spawns ToolLoopAgent via CallAgent inside Spawn
    ▼
ToolLoopAgent.start
    │  Saves user message to turn messages
    ▼
ToolLoopAgent.call_llm  (loop)
    │  Calls LLMProvider, executes tool calls, repeats until done
    │  Returns ToolLoopResult
    ▼
ChatAgent.collect_result
    │  Appends turn messages to session history
    │  Returns ChatResult
```

The runtime persists state after each step — see [Persistence model](#persistence-model).

## Dependency injection

Services are injected into agent constructors by matching parameter type annotations.
The runtime maintains a service dict (`{type: instance}`) and resolves constructor
parameters automatically.

```python
runtime = AgentRuntime(
    agents={"chat": ChatAgent},
    storage=FileSessionStorage(base_dir="./sessions", session_id="my-session"),
    services={
        LLMProvider: provider,
        ChatConfig: config,  # tools=registry inside ChatConfig
    },
)
```

Agents can also propagate services to child agents via `ServiceLocator.provide()`.
See [docs/agents.md](agents.md) for details.

## Persistence model

Agents declare state via typed slots — `Scalar[T]` (single value) and
`AppendOnlyList[T]` (append-only list). Both track changes incrementally,
so each save only writes what changed.

Slots live in **scopes** that determine their lifetime:

- **Ephemeral** (`store.ephemeral`) — per-run scratch state. Survives crash
  recovery within a single `run()` call, but is gone on the next one.
- **Persistent** (`store.persistent`) — survives across `run()` calls. The
  storage key is controlled by the parent (defaults to the agent's name).
- **Named** (`store["name"]`) — session-wide shared scope. Any agent can
  access the same named scope by name.

See [Agents — Agent state](agents.md#agent-state) for usage details.

Under the hood, `SessionStorage` persists two things:
- **Execution snapshot** — temporary crash-recovery data (cleared on completion)
- **Scope state** — slot values per scope (survives across runs)

Built-in implementations: `InMemorySessionStorage` (dev/test), `FileSessionStorage`
(JSON files on disk).

**Important:** Without storage (`storage=None`, the default), agent state is not
preserved between `runtime.run()` calls. This means `ChatAgent` won't remember
conversation history across turns. For multi-turn use, always pass a storage —
at minimum `InMemorySessionStorage()`.

---

**Prev:** [Getting Started](getting-started.md) | **Next:** [Working with LLMs](llm.md)
