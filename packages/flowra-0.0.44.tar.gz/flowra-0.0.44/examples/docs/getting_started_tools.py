"""Getting Started: Adding tools.

Corresponds to docs/getting-started.md "Adding tools" section.

Usage:
    uv run python examples/docs/getting_started_tools.py
"""

import asyncio
from dataclasses import dataclass

from examples.model_registry import DEFAULT_MODEL, create_router
from flowra.agent import AgentRuntime
from flowra.lib import LLMConfig
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.tools import ToolRegistry, tool


@dataclass
class WeatherParams:
    city: str


@tool("get_weather")
def get_weather(params: WeatherParams) -> str:
    """Get current weather for a city."""
    return f"It's sunny and 22C in {params.city}"


async def main() -> None:
    router = create_router()

    registry = ToolRegistry([get_weather])
    config = ChatConfig(
        llm_config=LLMConfig(model=DEFAULT_MODEL),
        system=[SystemMessage(blocks=[TextBlock(text="You are a helpful assistant.")])],
        tools=registry,
    )

    runtime = AgentRuntime(
        agents={"chat": ChatAgent},
        services={
            LLMProvider: router,
            ChatConfig: config,
        },
    )

    result = await runtime.run(
        agent=ChatAgent,
        spec=ChatSpec(user_message="What's the weather in Paris?"),
    )

    if isinstance(result, ChatResult) and result.response:
        print(result.response)


if __name__ == "__main__":
    asyncio.run(main())
