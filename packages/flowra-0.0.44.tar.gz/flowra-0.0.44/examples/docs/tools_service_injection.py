"""Tools: Service injection.

Corresponds to docs/tools.md "Service injection" section.

Usage:
    make docs-example name=tools_service_injection
"""

import asyncio
from dataclasses import dataclass

from examples.model_registry import DEFAULT_MODEL, create_router
from flowra.agent import AgentRuntime
from flowra.lib import LLMConfig
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.tools import ToolRegistry, tool


class DatabaseClient:
    """Simulated database client."""

    def query(self, sql: str) -> list[dict[str, str]]:
        return [{"city": "Paris", "country": "France"}, {"city": "Berlin", "country": "Germany"}]


@dataclass
class QueryParams:
    question: str


@tool("query_db")
def query_db(params: QueryParams, db: DatabaseClient) -> str:
    """Query the database for information."""
    rows = db.query(params.question)
    return "\n".join(f"{r['city']} ({r['country']})" for r in rows)


async def main() -> None:
    router = create_router()
    db = DatabaseClient()

    registry = ToolRegistry([query_db])
    config = ChatConfig(
        llm_config=LLMConfig(model=DEFAULT_MODEL),
        system=[SystemMessage(blocks=[TextBlock(text="You are a helpful assistant with database access.")])],
        tools=registry,
    )

    runtime = AgentRuntime(
        agents={"chat": ChatAgent},
        services={
            LLMProvider: router,
            ChatConfig: config,
            DatabaseClient: db,
        },
    )

    result = await runtime.run(
        agent=ChatAgent,
        spec=ChatSpec(user_message="What cities are in the database?"),
    )

    if isinstance(result, ChatResult) and result.response:
        print(result.response)


if __name__ == "__main__":
    asyncio.run(main())
