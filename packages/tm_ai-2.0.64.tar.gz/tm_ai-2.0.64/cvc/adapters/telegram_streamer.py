import asyncio
import logging
from aiogram import Bot

logger = logging.getLogger("cvc.telegram_streamer")

class TelegramStreamer:
    def __init__(self, bot: Bot, chat_id: int, message_id: int):
        self.bot = bot
        self.chat_id = chat_id
        self.message_id = message_id
        self.buffer = ""
        self.last_sent = ""
        self.is_flushing = False
        self._stop = False
        self._flush_task = asyncio.create_task(self._flusher())

    async def _flusher(self):
        while not self._stop:
            await asyncio.sleep(1.5)
            await self._flush_now()
            
    async def _flush_now(self):
        if self.buffer != self.last_sent and not self.is_flushing:
            self.is_flushing = True
            try:
                text_to_send = self.buffer[:4000] if self.buffer else "..."
                if not text_to_send.strip():
                    text_to_send = "..."
                await self.bot.edit_message_text(
                    chat_id=self.chat_id,
                    message_id=self.message_id,
                    text=text_to_send
                )
                self.last_sent = self.buffer
            except Exception as e:
                # e.g., MessageNotModified or rate limit
                pass
            finally:
                self.is_flushing = False

    def push(self, text_chunk: str):
        self.buffer += text_chunk

    async def finalize(self):
        self._stop = True
        if self._flush_task:
            self._flush_task.cancel()
            
        if not self.buffer.strip() and self.last_sent == "":
            try:
                await self.bot.delete_message(self.chat_id, self.message_id)
            except Exception:
                pass
        else:
            await self._flush_now()
