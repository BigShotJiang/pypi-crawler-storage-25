from ctypes import Structure, c_bool, c_int, c_uint, c_uint16
from dataclasses import dataclass
from enum import IntEnum

from libretro.ctypes import CIntArg, TypedFunctionPointer

retro_rumble_effect = c_int
RETRO_RUMBLE_STRONG = 0
RETRO_RUMBLE_WEAK = 1
RETRO_RUMBLE_DUMMY = 0x7FFFFFFF


retro_set_rumble_state_t = TypedFunctionPointer[
    c_bool, [CIntArg[c_uint], CIntArg[retro_rumble_effect], CIntArg[c_uint16]]
]


class RumbleEffect(IntEnum):
    STRONG = RETRO_RUMBLE_STRONG
    WEAK = RETRO_RUMBLE_WEAK


@dataclass(init=False, slots=True)
class retro_rumble_interface(Structure):
    set_rumble_state: retro_set_rumble_state_t | None

    _fields_ = (("set_rumble_state", retro_set_rumble_state_t),)

    def __deepcopy__(self, _):
        return retro_rumble_interface(self.set_rumble_state)


__all__ = [
    "retro_set_rumble_state_t",
    "RumbleEffect",
    "retro_rumble_interface",
    "retro_rumble_effect",
]
