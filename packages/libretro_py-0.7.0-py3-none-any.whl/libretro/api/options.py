from copy import deepcopy
from ctypes import POINTER, Array, Structure, c_bool, c_char_p, pointer
from dataclasses import dataclass

from libretro.api._utils import MemoDict, deepcopy_array
from libretro.ctypes import TypedArray, TypedFunctionPointer, TypedPointer

RETRO_NUM_CORE_OPTION_VALUES_MAX = 128


retro_core_options_update_display_callback_t = TypedFunctionPointer[c_bool, []]


@dataclass(init=False, slots=True)
class retro_variable(Structure):
    key: bytes | None
    value: bytes | None

    _fields_ = (
        ("key", c_char_p),
        ("value", c_char_p),
    )

    def __deepcopy__(self, _):
        return retro_variable(self.key, self.value)


@dataclass(init=False, slots=True)
class retro_core_option_display(Structure):
    key: bytes | None
    visible: bool

    _fields_ = (
        ("key", c_char_p),
        ("visible", c_bool),
    )

    def __deepcopy__(self, _):
        return retro_core_option_display(self.key, self.visible)


@dataclass(init=False, slots=True)
class retro_core_option_value(Structure):
    value: bytes | None
    label: bytes | None

    _fields_ = (
        ("value", c_char_p),
        ("label", c_char_p),
    )

    def __deepcopy__(self, _):
        return retro_core_option_value(self.value, self.label)


NUM_CORE_OPTION_VALUES_MAX = RETRO_NUM_CORE_OPTION_VALUES_MAX
CoreOptionArray = retro_core_option_value * RETRO_NUM_CORE_OPTION_VALUES_MAX


@dataclass(init=False, slots=True)
class retro_core_option_definition(Structure):
    key: bytes | None
    desc: bytes | None
    info: bytes | None
    values: Array[retro_core_option_value]
    default_value: bytes | None

    _fields_ = (
        ("key", c_char_p),
        ("desc", c_char_p),
        ("info", c_char_p),
        ("values", CoreOptionArray),
        ("default_value", c_char_p),
    )

    def __deepcopy__(self, memo: MemoDict = None):
        return retro_core_option_definition(
            self.key,
            self.desc,
            self.info,
            deepcopy_array(self.values, memo),
            self.default_value,
        )


@dataclass(init=False, slots=True)
class retro_core_options_intl(Structure):
    us: TypedPointer[retro_core_option_definition] | None
    local: TypedPointer[retro_core_option_definition] | None

    _fields_ = (
        ("us", POINTER(retro_core_option_definition)),
        ("local", POINTER(retro_core_option_definition)),
    )

    def __deepcopy__(self, memo: MemoDict = None):
        return retro_core_options_intl(
            pointer(deepcopy(self.us[0], memo)) if self.us else None,
            pointer(deepcopy(self.local[0], memo)) if self.local else None,
        )


@dataclass(init=False, slots=True)
class retro_core_option_v2_category(Structure):
    key: bytes | None
    desc: bytes | None
    info: bytes | None

    _fields_ = (
        ("key", c_char_p),
        ("desc", c_char_p),
        ("info", c_char_p),
    )

    def __deepcopy__(self, _):
        return retro_core_option_v2_category(self.key, self.desc, self.info)


@dataclass(init=False, slots=True)
class retro_core_option_v2_definition(Structure):
    key: bytes | None
    desc: bytes | None
    desc_categorized: bytes | None
    info: bytes | None
    info_categorized: bytes | None
    category_key: bytes | None
    values: TypedArray[retro_core_option_value]
    default_value: bytes | None

    _fields_ = (
        ("key", c_char_p),
        ("desc", c_char_p),
        ("desc_categorized", c_char_p),
        ("info", c_char_p),
        ("info_categorized", c_char_p),
        ("category_key", c_char_p),
        ("values", CoreOptionArray),
        ("default_value", c_char_p),
    )

    def __deepcopy__(self, memo: MemoDict = None):
        return retro_core_option_v2_definition(
            self.key,
            self.desc,
            self.desc_categorized,
            self.info,
            self.info_categorized,
            self.category_key,
            deepcopy_array(self.values, memo),
            self.default_value,
        )


@dataclass(init=False, slots=True)
class retro_core_options_v2(Structure):
    categories: TypedPointer[retro_core_option_v2_category] | None
    definitions: TypedPointer[retro_core_option_v2_definition] | None

    _fields_ = (
        ("categories", POINTER(retro_core_option_v2_category)),
        ("definitions", POINTER(retro_core_option_v2_definition)),
    )

    def __deepcopy__(self, memo: MemoDict = None):
        return retro_core_options_v2(
            pointer(deepcopy(self.categories[0], memo)) if self.categories else None,
            pointer(deepcopy(self.definitions[0], memo)) if self.definitions else None,
        )


@dataclass(init=False, slots=True)
class retro_core_options_v2_intl(Structure):
    us: TypedPointer[retro_core_options_v2] | None
    local: TypedPointer[retro_core_options_v2] | None

    _fields_ = (
        ("us", POINTER(retro_core_options_v2)),
        ("local", POINTER(retro_core_options_v2)),
    )

    def __deepcopy__(self, memo: MemoDict = None):
        return retro_core_options_v2_intl(
            pointer(deepcopy(self.us[0], memo)) if self.us else None,
            pointer(deepcopy(self.local[0], memo)) if self.local else None,
        )


@dataclass(init=False, slots=True)
class retro_core_options_update_display_callback(Structure):
    callback: retro_core_options_update_display_callback_t | None

    _fields_ = (("callback", retro_core_options_update_display_callback_t),)

    def __call__(self) -> bool:
        if not self.callback:
            raise ValueError("No callback has been set")

        return bool(self.callback())

    def __deepcopy__(self, _):
        return retro_core_options_update_display_callback(self.callback)


__all__ = [
    "retro_variable",
    "retro_core_option_display",
    "retro_core_option_value",
    "CoreOptionArray",
    "retro_core_option_definition",
    "retro_core_options_intl",
    "retro_core_option_v2_category",
    "retro_core_option_v2_definition",
    "retro_core_options_v2",
    "retro_core_options_v2_intl",
    "retro_core_options_update_display_callback",
    "retro_core_options_update_display_callback_t",
    "NUM_CORE_OPTION_VALUES_MAX",
]
