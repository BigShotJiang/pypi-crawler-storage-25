#!/usr/bin/env python3
"""Sync library + commands from 仁 to main for release.

Usage:
    python3 release.py

Cleans main worktree, copies library (including commands), strips
dev-only config, reports the last tag. Tagging and pushing are manual.
"""

import hashlib
import re
import shutil
import subprocess
import sys
from pathlib import Path

SELF_DIR = Path(__file__).resolve().parent  # 仁 worktree
REPO_ROOT = SELF_DIR.parent.parent          # haiv-mail repo root
MAIN_WT = REPO_ROOT / "worktrees" / "main"

KEEP = {".git", ".venv", ".pytest_cache"}


def main() -> None:
    if not MAIN_WT.exists():
        die("worktrees/main/ not found")

    result = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=MAIN_WT, capture_output=True, text=True,
    )
    if result.stdout.strip():
        die("worktrees/main/ has uncommitted changes")

    # --- Report last tag ---
    last_tag = get_last_tag()
    current_version = read_version(SELF_DIR / "pyproject.toml")
    print(f"Last tag:        {last_tag or '(none)'}")
    print(f"Source version:  {current_version}")
    print()

    # --- Clean main ---
    clean_worktree(MAIN_WT)
    print("Cleaned worktrees/main/")

    # --- Copy library + commands (both inside src/haiv_mail/) ---
    copy_tree(SELF_DIR / "src", MAIN_WT / "src")
    copy_tree(SELF_DIR / "tests", MAIN_WT / "tests")
    sync_file(SELF_DIR / ".gitignore", MAIN_WT / ".gitignore")
    sync_file(SELF_DIR / "LICENSE", MAIN_WT / "LICENSE")
    sync_file(SELF_DIR / "README.md", MAIN_WT / "README.md")
    if (SELF_DIR / "uv.lock").exists():
        sync_file(SELF_DIR / "uv.lock", MAIN_WT / "uv.lock")
    print("Copied library and commands")

    # --- Sync pyproject.toml, stripping dev-only sections ---
    sync_pyproject(SELF_DIR / "pyproject.toml", MAIN_WT / "pyproject.toml")
    print("Synced pyproject.toml (stripped dev sources)")

    # --- Commit ---
    subprocess.run(["git", "add", "-A"], cwd=MAIN_WT, check=True)

    diff = subprocess.run(
        ["git", "diff", "--cached", "--quiet"],
        cwd=MAIN_WT,
    )
    if diff.returncode == 0:
        print()
        print("No changes to commit — main is already in sync.")
        return

    subprocess.run(
        ["git", "commit", "-m", "sync from 仁"],
        cwd=MAIN_WT, check=True,
    )

    print()
    print("Synced to main.")
    print()
    print(f"Last tag was: {last_tag or '(none)'}")
    print(f"Remember to bump the version in pyproject.toml and tag:")
    print(f"  cd worktrees/main")
    print(f"  git tag v<version>")
    print(f"  git push origin main --tags")


# --- helpers ---

def get_last_tag() -> str | None:
    result = subprocess.run(
        ["git", "describe", "--tags", "--abbrev=0"],
        cwd=MAIN_WT, capture_output=True, text=True,
    )
    if result.returncode == 0:
        return result.stdout.strip()
    return None


def clean_worktree(wt: Path) -> None:
    for child in wt.iterdir():
        if child.name in KEEP:
            continue
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sync_file(src: Path, dest: Path) -> None:
    if not src.exists():
        return
    if dest.exists() and file_hash(src) == file_hash(dest):
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)


def copy_tree(src: Path, dest: Path) -> None:
    shutil.copytree(
        src, dest,
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
    )


def sync_pyproject(src: Path, dest: Path) -> None:
    """Copy pyproject.toml, stripping [tool.uv.sources] (dev-only local paths)."""
    text = src.read_text()
    text = re.sub(
        r'\[tool\.uv\.sources\]\n(?:.*\n)*?\n',
        '',
        text,
    )
    dest.write_text(text)


def read_version(pyproject: Path) -> str:
    match = re.search(r'version\s*=\s*"([^"]+)"', pyproject.read_text())
    return match.group(1) if match else "unknown"


def die(msg: str) -> None:
    print(f"Error: {msg}", file=sys.stderr)
    sys.exit(1)


if __name__ == "__main__":
    main()
