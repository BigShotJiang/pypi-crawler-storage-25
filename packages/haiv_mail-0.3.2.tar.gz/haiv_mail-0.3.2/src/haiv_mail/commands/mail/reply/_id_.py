from pathlib import Path

from haiv import cmd
from haiv_mail.domain import reply

from haiv_mail.commands.mail._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(
        description="Reply to a message or list post",
        flags=[
            cmd.Flag("body", min_args=0),
            cmd.Flag("body-file", min_args=0),
            cmd.Flag("subject", min_args=0),
            cmd.Flag("direct", type=bool),
        ],
    )


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)
    message_id = ctx.args.get_one("id")
    direct = ctx.args.has("direct")

    # Try DM inbox first, then list posts
    original = mb.read_message(me, message_id)
    is_list_post = False
    if original is None:
        original = mb.read_list_post(message_id, reader=me)
        is_list_post = True
    if original is None:
        ctx.print(f"No message with id {message_id}")
        return

    body = ctx.args.get_one("body", default_value=None)
    body_file = ctx.args.get_one("body-file", default_value=None)

    if body and body_file:
        from haiv.errors import CommandError
        raise CommandError("Use --body or --body-file, not both")
    if not body and not body_file:
        from haiv.errors import CommandError
        raise CommandError("Provide --body or --body-file")

    if body_file:
        path = Path(body_file)
        if not path.exists():
            from haiv.errors import CommandError
            raise CommandError(f"File not found: {body_file}")
        body = path.read_text()

    subject = ctx.args.get_one("subject", default_value=None)

    if is_list_post and not direct:
        # Reply to the list
        list_name = original.recipients[0].name
        if subject is None:
            subj = original.subject
            if not subj.startswith("Re: "):
                subj = f"Re: {subj}"
            subject = subj
        msg = mb.post_to_list(list_name, me, subject, body, in_reply_to=original.id)
        ctx.print(f"Replied {msg.id} in {list_name}")
    else:
        # DM reply (or --direct on a list post)
        msg = reply(
            store=mb,
            original=original,
            sender=me,
            body=body,
            subject=subject,
        )
        ctx.print(f"Replied {msg.id} to {original.sender}")

    if body_file:
        Path(body_file).unlink()
        ctx.print(f"Cleaned up {body_file}")
