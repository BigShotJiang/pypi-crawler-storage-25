from haiv import cmd

from haiv_mail.commands.mail._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(
        description="View archived messages",
        flags=[],
    )


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)

    messages = mb.list_archived(me)
    if not messages:
        ctx.print("No archived messages.")
        return

    for msg in messages:
        ts = msg.timestamp.strftime("%Y-%m-%d %H:%M")
        ctx.print(f"    {msg.id}  {ts}  {msg.sender}  {msg.subject}")

    ctx.print(f"")
    ctx.print(f"  {len(messages)} archived. Use hv mail cleanup --older-than <days> to prune.")
