from haiv import cmd

from haiv_mail.commands.mail._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(
        description="Delete old archived messages",
        flags=[
            cmd.Flag("older-than", min_args=0),
        ],
    )


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)

    days = int(ctx.args.get_one("older-than", default_value="30"))
    deleted = mb.cleanup(me, older_than_days=days)

    if deleted == 0:
        ctx.print(f"No archived messages older than {days} days.")
    else:
        ctx.print(f"Deleted {deleted} archived message{'s' if deleted != 1 else ''} older than {days} days.")
