from haiv import cmd

from haiv_mail.commands.mail._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(description="Join a mailing list")


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)
    name = ctx.args.get_one("name")

    # Check if already a member
    joined = [l["name"] for l in mb.get_joined_lists(me)]
    if name in joined:
        ctx.print(f"Already a member of '{name}'")
        return

    try:
        mb.join_list(name, me)
    except ValueError as e:
        ctx.print(str(e))
        return

    ctx.print(f"Joined '{name}'")
