from pathlib import Path

from haiv import cmd
from haiv_mail import Address

from haiv_mail.commands.mail._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(
        description="Send a message (DM or list post)",
        flags=[
            cmd.Flag("to"),
            cmd.Flag("subject"),
            cmd.Flag("body", min_args=0),
            cmd.Flag("body-file", min_args=0),
        ],
    )


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)
    target = ctx.args.get_one("to")

    body = ctx.args.get_one("body", default_value=None)
    body_file = ctx.args.get_one("body-file", default_value=None)

    if body and body_file:
        from haiv.errors import CommandError
        raise CommandError("Use --body or --body-file, not both")
    if not body and not body_file:
        from haiv.errors import CommandError
        raise CommandError("Provide --body or --body-file")

    if body_file:
        path = Path(body_file)
        if not path.exists():
            from haiv.errors import CommandError
            raise CommandError(f"File not found: {body_file}")
        body = path.read_text()

    subject = ctx.args.get_one("subject")

    # Resolve: is this a list or a mind?
    if mb.is_list(target):
        msg = mb.post_to_list(target, me, subject, body)
        ctx.print(f"Posted {msg.id} to {target}")
    else:
        recipient = Address.parse(target)

        # Validate recipient exists
        from haiv.helpers.minds import mind_exists
        from haiv.errors import CommandError
        my_colony = ctx.paths.root.name
        if recipient.colony == my_colony:
            if not mind_exists(recipient.name, ctx.paths.user.minds_dir):
                raise CommandError(f"No mind named '{recipient.name}' in {my_colony}")
        else:
            peer_root = ctx.paths.root.parent / recipient.colony
            if not peer_root.is_dir():
                raise CommandError(f"Colony '{recipient.colony}' not found")
            peer_users = peer_root / "users"
            found = False
            if peer_users.is_dir():
                for user_dir in peer_users.iterdir():
                    if user_dir.is_dir():
                        peer_minds = user_dir / "state" / "minds"
                        if mind_exists(recipient.name, peer_minds):
                            found = True
                            break
            if not found:
                raise CommandError(f"No mind named '{recipient.name}' in {recipient.colony}")

        msg = mb.send(
            sender=me,
            recipients=[recipient],
            subject=subject,
            body=body,
        )
        ctx.print(f"Sent {msg.id} to {recipient}")

        # Warn if recipient isn't waiting for mail
        waiting_addrs = {str(w.address) for w in mb.list_waiting()}
        if str(recipient) not in waiting_addrs:
            ctx.print(f"Note: {recipient} is not currently waiting for mail.")

    if body_file:
        Path(body_file).unlink()
        ctx.print(f"Cleaned up {body_file}")
