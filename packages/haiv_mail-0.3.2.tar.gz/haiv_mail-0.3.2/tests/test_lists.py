"""Tests for mailing list functionality."""

import pytest

from haiv_mail.address import Address
from haiv_mail.mailbox import Mailbox


def _mb() -> Mailbox:
    return Mailbox()


def test_create_list():
    mb = _mb()
    creator = Address.parse("仁@haiv-mail")
    mb.create_list("haiv/general", creator, description="General discussion")

    assert mb.is_list("haiv/general")
    assert not mb.is_list("nonexistent")

    info = mb.get_list_info("haiv/general")
    assert info["name"] == "haiv/general"
    assert info["description"] == "General discussion"
    assert info["created_by"] == "仁@haiv-mail"


def test_create_duplicate_list():
    mb = _mb()
    creator = Address.parse("仁@haiv-mail")
    mb.create_list("dev", creator)
    with pytest.raises(ValueError, match="already exists"):
        mb.create_list("dev", creator)


def test_creator_auto_joins():
    mb = _mb()
    creator = Address.parse("仁@haiv-mail")
    mb.create_list("dev", creator)

    joined = mb.get_joined_lists(creator)
    assert len(joined) == 1
    assert joined[0]["name"] == "dev"


def test_join_and_leave():
    mb = _mb()
    creator = Address.parse("仁@haiv-mail")
    joiner = Address.parse("miko@haiv-mail")
    mb.create_list("dev", creator)

    mb.join_list("dev", joiner)
    assert len(mb.get_joined_lists(joiner)) == 1

    mb.leave_list("dev", joiner)
    assert len(mb.get_joined_lists(joiner)) == 0


def test_join_nonexistent_list():
    mb = _mb()
    with pytest.raises(ValueError, match="does not exist"):
        mb.join_list("nope", Address.parse("a@b"))


def test_get_all_lists():
    mb = _mb()
    creator = Address.parse("仁@haiv-mail")
    mb.create_list("haiv/general", creator)
    mb.create_list("haiv-mail/dev", creator)
    mb.create_list("haiv-mail/feedback", creator)

    all_lists = mb.get_all_lists()
    assert len(all_lists) == 3
    names = [l["name"] for l in all_lists]
    assert "haiv/general" in names
    assert "haiv-mail/dev" in names


def test_post_and_read():
    mb = _mb()
    creator = Address.parse("仁@haiv-mail")
    mb.create_list("dev", creator)

    msg = mb.post_to_list("dev", creator, "Hello", "First post.")
    assert msg.sender == creator
    assert msg.subject == "Hello"

    posts = mb.list_posts("dev")
    assert len(posts) == 1
    assert posts[0].id == msg.id

    read = mb.read_list_post(msg.id)
    assert read is not None
    assert read.body == "First post."


def test_post_to_nonexistent_list():
    mb = _mb()
    with pytest.raises(ValueError, match="does not exist"):
        mb.post_to_list("nope", Address.parse("a@b"), "subject", "body")


def test_post_validates():
    mb = _mb()
    creator = Address.parse("仁@haiv-mail")
    mb.create_list("dev", creator)

    with pytest.raises(ValueError, match="Subject"):
        mb.post_to_list("dev", creator, "", "body")

    with pytest.raises(ValueError, match="Body"):
        mb.post_to_list("dev", creator, "subject", "  ")


def test_threaded_replies():
    mb = _mb()
    creator = Address.parse("仁@haiv-mail")
    miko = Address.parse("miko@haiv-mail")
    mb.create_list("dev", creator)

    post = mb.post_to_list("dev", creator, "Topic", "Start.")
    reply = mb.post_to_list("dev", miko, "Re: Topic", "Response.", in_reply_to=post.id)

    # Only top-level posts in list_posts
    posts = mb.list_posts("dev")
    assert len(posts) == 1
    assert posts[0].id == post.id

    assert mb.reply_count(post.id) == 1


def test_unread_activity():
    mb = _mb()
    仁 = Address.parse("仁@haiv-mail")
    miko = Address.parse("miko@haiv-mail")
    mb.create_list("dev", 仁)
    mb.join_list("dev", miko)

    mb.post_to_list("dev", 仁, "Post 1", "content")
    mb.post_to_list("dev", 仁, "Post 2", "content")

    activity = mb.list_unread_activity(miko)
    assert len(activity) == 1
    assert activity[0]["list"] == "dev"
    assert activity[0]["count"] == 2


def test_unread_activity_empty_when_not_joined():
    mb = _mb()
    creator = Address.parse("仁@haiv-mail")
    outsider = Address.parse("nobody@haiv-mail")
    mb.create_list("dev", creator)
    mb.post_to_list("dev", creator, "Post", "content")

    activity = mb.list_unread_activity(outsider)
    assert len(activity) == 0


def test_read_list_post():
    """read_list_post finds posts that read_message (DM) cannot."""
    mb = _mb()
    creator = Address.parse("仁@haiv-mail")
    reader = Address.parse("miko@haiv-mail")
    mb.create_list("dev", creator)
    mb.join_list("dev", reader)

    post = mb.post_to_list("dev", creator, "Hello", "world")

    # DM read should NOT find it
    assert mb.read_message(reader, post.id) is None

    # List read SHOULD find it
    found = mb.read_list_post(post.id)
    assert found is not None
    assert found.id == post.id
    assert found.body == "world"


def test_read_list_post_marks_as_read():
    """Reading a list post with a reader address clears it from unread activity."""
    mb = _mb()
    仁 = Address.parse("仁@haiv-mail")
    miko = Address.parse("miko@haiv-mail")
    mb.create_list("dev", 仁)
    mb.join_list("dev", miko)

    post = mb.post_to_list("dev", 仁, "News", "content")

    # Unread before reading
    activity = mb.list_unread_activity(miko)
    assert activity[0]["count"] == 1

    # Read with reader address
    mb.read_list_post(post.id, reader=miko)

    # Now cleared
    activity = mb.list_unread_activity(miko)
    assert len(activity) == 0


def test_read_list_post_without_reader_does_not_mark():
    """Reading without a reader (backward compat) leaves unread state alone."""
    mb = _mb()
    仁 = Address.parse("仁@haiv-mail")
    miko = Address.parse("miko@haiv-mail")
    mb.create_list("dev", 仁)
    mb.join_list("dev", miko)

    post = mb.post_to_list("dev", 仁, "News", "content")
    mb.read_list_post(post.id)

    activity = mb.list_unread_activity(miko)
    assert activity[0]["count"] == 1


def test_unread_activity_excludes_own_posts():
    """You should not see your own posts as unread activity."""
    mb = _mb()
    creator = Address.parse("仁@haiv-mail")
    mb.create_list("dev", creator)

    mb.post_to_list("dev", creator, "My own post", "content")

    activity = mb.list_unread_activity(creator)
    assert len(activity) == 0


def test_list_thread():
    mb = _mb()
    creator = Address.parse("仁@haiv-mail")
    miko = Address.parse("miko@haiv-mail")
    mb.create_list("dev", creator)

    p1 = mb.post_to_list("dev", creator, "Topic", "start")
    p2 = mb.post_to_list("dev", miko, "Re: Topic", "reply", in_reply_to=p1.id)
    p3 = mb.post_to_list("dev", creator, "Re: Topic", "reply again", in_reply_to=p2.id)

    thread = mb.list_thread(p2.id)
    assert len(thread) == 3
    assert thread[0].id == p1.id
    assert thread[1].id == p2.id
    assert thread[2].id == p3.id
