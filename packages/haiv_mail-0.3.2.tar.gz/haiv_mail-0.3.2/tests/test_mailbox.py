import pytest

from haiv_mail.address import Address
from haiv_mail.mailbox import Mailbox
from haiv_mail.message import Message
from haiv_mail.domain import reply as domain_reply


def _mailbox() -> Mailbox:
    return Mailbox()


def test_deliver_and_read():
    mb = _mailbox()
    sender = Address.parse("仁@haiv-mail")
    recipient = Address.parse("luna@haiv")

    msg = Message(
        sender=sender,
        recipients=[recipient],
        subject="hello",
        body="First message from haiv-mail.",
    )
    mb.deliver(msg)

    messages = mb.list_messages(recipient)
    assert len(messages) == 1
    assert messages[0].sender == sender
    assert messages[0].subject == "hello"
    assert messages[0].body == "First message from haiv-mail."


def test_multiple_recipients():
    mb = _mailbox()
    sender = Address.parse("仁@haiv-mail")
    r1 = Address.parse("luna@haiv")
    r2 = Address.parse("wren@haiv")

    msg = Message(
        sender=sender,
        recipients=[r1, r2],
        subject="broadcast",
        body="Hello everyone.",
    )
    mb.deliver(msg)

    assert len(mb.list_messages(r1)) == 1
    assert len(mb.list_messages(r2)) == 1


def test_read_specific_message():
    mb = _mailbox()
    addr = Address.parse("luna@haiv")

    msg = Message(
        sender=Address.parse("仁@haiv-mail"),
        recipients=[addr],
        subject="specific",
        body="Find me by ID.",
    )
    mb.deliver(msg)

    found = mb.read_message(addr, msg.id)
    assert found is not None
    assert found.id == msg.id
    assert found.subject == "specific"


def test_empty_inbox():
    mb = _mailbox()
    addr = Address.parse("nobody@nowhere")
    assert mb.list_messages(addr) == []
    assert mb.read_message(addr, "nonexistent") is None


def test_send_delivers_and_saves_to_sent():
    mb = _mailbox()
    sender = Address.parse("仁@haiv-mail")
    recipient = Address.parse("luna@haiv")

    msg = mb.send(
        sender=sender,
        recipients=[recipient],
        subject="via send()",
        body="Convenience function.",
    )

    # Recipient got it
    inbox = mb.list_messages(recipient)
    assert len(inbox) == 1
    assert inbox[0].id == msg.id

    # Sender can see it in sent
    sent = mb.list_sent(sender)
    assert len(sent) == 1
    assert sent[0].id == msg.id


def test_delete_message():
    mb = _mailbox()
    addr = Address.parse("luna@haiv")

    msg = Message(
        sender=Address.parse("仁@haiv-mail"),
        recipients=[addr],
        subject="delete me",
        body="Temporary.",
    )
    mb.deliver(msg)
    assert len(mb.list_messages(addr)) == 1

    deleted = mb.delete_message(addr, msg.id)
    assert deleted is True
    assert len(mb.list_messages(addr)) == 0


def test_delete_nonexistent_message():
    mb = _mailbox()
    addr = Address.parse("luna@haiv")
    assert mb.delete_message(addr, "nope") is False


def test_message_ordering():
    from datetime import datetime, timedelta, timezone

    mb = _mailbox()
    addr = Address.parse("luna@haiv")
    sender = Address.parse("仁@haiv-mail")

    now = datetime.now(timezone.utc)
    old = Message(
        sender=sender, recipients=[addr],
        subject="old", body="first",
        timestamp=now - timedelta(hours=1),
    )
    new = Message(
        sender=sender, recipients=[addr],
        subject="new", body="second",
        timestamp=now,
    )

    mb.deliver(old)
    mb.deliver(new)

    messages = mb.list_messages(addr)
    assert messages[0].subject == "new"
    assert messages[1].subject == "old"


def test_special_characters_in_subject_and_body():
    mb = _mailbox()
    addr = Address.parse("luna@haiv")

    msg = Message(
        sender=Address.parse("仁@haiv-mail"),
        recipients=[addr],
        subject='He said "hello" & goodbye',
        body='Line one.\nLine two.\n"Quoted" line three.',
    )
    mb.deliver(msg)

    read = mb.read_message(addr, msg.id)
    assert read is not None
    assert read.subject == msg.subject
    assert read.body == msg.body


def test_reply_threads_and_swaps_sender():
    mb = _mailbox()
    alice = Address.parse("alice@colony")
    bob = Address.parse("bob@colony")

    original = mb.send(
        sender=alice, recipients=[bob],
        subject="hello", body="Hi Bob.",
    )

    reply = mb.reply(original, sender=bob, body="Hi Alice.")

    assert reply.in_reply_to == original.id
    assert reply.sender == bob
    assert reply.recipients == [alice]
    assert reply.subject == "Re: hello"

    sent = mb.list_sent(bob)
    assert any(m.id == reply.id for m in sent)


def test_reply_preserves_re_prefix():
    mb = _mailbox()
    alice = Address.parse("alice@colony")
    bob = Address.parse("bob@colony")

    original = mb.send(
        sender=alice, recipients=[bob],
        subject="Re: hello", body="continuing",
    )

    reply = mb.reply(original, sender=bob, body="still going")
    assert reply.subject == "Re: hello"


def test_in_reply_to_round_trip():
    mb = _mailbox()
    alice = Address.parse("alice@colony")
    bob = Address.parse("bob@colony")

    original = mb.send(
        sender=alice, recipients=[bob],
        subject="thread test", body="start",
    )
    reply = mb.reply(original, sender=bob, body="response")

    read_back = mb.list_sent(bob)
    threaded = [m for m in read_back if m.in_reply_to == original.id]
    assert len(threaded) == 1
    assert threaded[0].id == reply.id


def test_thread_collects_conversation():
    mb = _mailbox()
    alice = Address.parse("alice@colony")
    bob = Address.parse("bob@colony")

    m1 = mb.send(sender=alice, recipients=[bob], subject="convo", body="one")
    m2 = mb.reply(m1, sender=bob, body="two")
    m3 = mb.reply(m2, sender=alice, body="three")

    thread = mb.thread(bob, m2.id)
    assert len(thread) == 3
    assert thread[0].id == m1.id
    assert thread[1].id == m2.id
    assert thread[2].id == m3.id


def test_contacts():
    mb = _mailbox()
    alice = Address.parse("alice@colony")
    bob = Address.parse("bob@colony")
    carol = Address.parse("carol@colony")

    mb.send(sender=alice, recipients=[bob], subject="hi", body="hey")
    mb.send(sender=carol, recipients=[alice], subject="yo", body="sup")

    contacts = mb.contacts(alice)
    assert Address.parse("bob@colony") in contacts
    assert Address.parse("carol@colony") in contacts
    assert Address.parse("alice@colony") not in contacts  # not yourself


def test_contacts_empty():
    mb = _mailbox()
    assert mb.contacts(Address.parse("lonely@colony")) == []


def test_read_message_marks_as_read():
    mb = _mailbox()
    addr = Address.parse("luna@haiv")

    msg = Message(
        sender=Address.parse("仁@haiv-mail"),
        recipients=[addr],
        subject="read me",
        body="test",
    )
    mb.deliver(msg)
    assert mb.unread_count(addr) == 1

    mb.read_message(addr, msg.id)
    assert mb.unread_count(addr) == 0


def test_unread_count_multiple():
    mb = _mailbox()
    addr = Address.parse("luna@haiv")
    sender = Address.parse("仁@haiv-mail")

    m1 = mb.send(sender=sender, recipients=[addr], subject="one", body="1")
    mb.send(sender=sender, recipients=[addr], subject="two", body="2")
    mb.send(sender=sender, recipients=[addr], subject="three", body="3")

    assert mb.unread_count(addr) == 3

    mb.read_message(addr, m1.id)
    assert mb.unread_count(addr) == 2


def test_mutual_wait_detection():
    mb = _mailbox()
    a = Address.parse("alice@colony")
    b = Address.parse("bob@colony")

    mb._register_waiting(a, b)
    assert mb._check_mutual_wait(b, a) is True
    assert mb._check_mutual_wait(a, b) is False
    mb._unregister_waiting(a)


def test_list_waiting_cleans_stale():
    from datetime import datetime, timedelta, timezone

    mb = _mailbox()
    addr = Address.parse("stale@colony")

    # Insert a stale entry manually
    old_time = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
    mb._conn.execute(
        "INSERT INTO presence (address, waiting_for, started_at) VALUES (?, ?, ?)",
        (str(addr), None, old_time),
    )
    mb._conn.commit()

    # Should be cleaned up (default 30 min TTL)
    waiting = mb.list_waiting()
    assert not any(w.address == addr for w in waiting)


def test_thread_from_root_message():
    mb = _mailbox()
    alice = Address.parse("alice@colony")
    bob = Address.parse("bob@colony")

    m1 = mb.send(sender=alice, recipients=[bob], subject="root", body="start")
    m2 = mb.reply(m1, sender=bob, body="reply")

    thread = mb.thread(bob, m1.id)
    assert len(thread) == 2


# -- validation --

def test_send_rejects_empty_subject():
    mb = _mailbox()
    with pytest.raises(ValueError, match="Subject cannot be empty"):
        mb.send(
            sender=Address.parse("a@b"),
            recipients=[Address.parse("c@d")],
            subject="",
            body="content",
        )


def test_send_rejects_empty_body():
    mb = _mailbox()
    with pytest.raises(ValueError, match="Body cannot be empty"):
        mb.send(
            sender=Address.parse("a@b"),
            recipients=[Address.parse("c@d")],
            subject="subject",
            body="  ",
        )


def test_send_rejects_no_recipients():
    mb = _mailbox()
    with pytest.raises(ValueError, match="At least one recipient"):
        mb.send(
            sender=Address.parse("a@b"),
            recipients=[],
            subject="subject",
            body="content",
        )


# -- domain reply function --

def test_domain_reply():
    mb = _mailbox()
    alice = Address.parse("alice@colony")
    bob = Address.parse("bob@colony")

    original = mb.send(sender=alice, recipients=[bob], subject="hello", body="Hi.")
    msg = domain_reply(mb, original, sender=bob, body="Hi back.")

    assert msg.in_reply_to == original.id
    assert msg.sender == bob
    assert msg.recipients == [alice]
    assert msg.subject == "Re: hello"


# -- archive --

def test_read_message_auto_archives():
    """Reading a message removes it from inbox (list_messages)."""
    mb = _mailbox()
    alice = Address.parse("alice@colony")
    bob = Address.parse("bob@colony")

    mb.send(sender=alice, recipients=[bob], subject="hello", body="Hi.")
    assert len(mb.list_messages(bob)) == 1

    msg = mb.list_messages(bob)[0]
    mb.read_message(bob, msg.id)

    # Inbox should be empty after reading
    assert len(mb.list_messages(bob)) == 0


def test_archived_messages_accessible():
    """Archived messages are visible via list_archived."""
    mb = _mailbox()
    alice = Address.parse("alice@colony")
    bob = Address.parse("bob@colony")

    mb.send(sender=alice, recipients=[bob], subject="hello", body="Hi.")
    msg = mb.list_messages(bob)[0]
    mb.read_message(bob, msg.id)

    archived = mb.list_archived(bob)
    assert len(archived) == 1
    assert archived[0].id == msg.id


def test_unread_not_in_archived():
    """Unread messages don't appear in archived list."""
    mb = _mailbox()
    alice = Address.parse("alice@colony")
    bob = Address.parse("bob@colony")

    mb.send(sender=alice, recipients=[bob], subject="hello", body="Hi.")
    assert len(mb.list_archived(bob)) == 0


def test_thread_works_across_archived():
    """Threading should find messages even if some are archived."""
    mb = _mailbox()
    alice = Address.parse("alice@colony")
    bob = Address.parse("bob@colony")

    msg1 = mb.send(sender=alice, recipients=[bob], subject="hello", body="Hi.")
    mb.read_message(bob, msg1.id)  # archives it

    msg2 = mb.send(sender=bob, recipients=[alice], subject="Re: hello",
                   body="Hi back.", in_reply_to=msg1.id)

    # Thread from bob's perspective should still find both
    thread = mb.thread(bob, msg2.id)
    assert len(thread) == 2


def test_cleanup_deletes_old_archived(tmp_path):
    """cleanup removes archived messages older than the cutoff."""
    import sqlite3
    from pathlib import Path

    db_path = tmp_path / "mail.db"
    mb = Mailbox(db_path)
    alice = Address.parse("alice@colony")
    bob = Address.parse("bob@colony")

    msg = mb.send(sender=alice, recipients=[bob], subject="old", body="ancient.")
    mb.read_message(bob, msg.id)  # archives it

    # Backdate the archived_at to 10 days ago
    conn = sqlite3.connect(str(db_path))
    conn.execute(
        "UPDATE deliveries SET archived_at = datetime('now', '-10 days') WHERE message_id = ?",
        (msg.id,),
    )
    conn.commit()
    conn.close()

    # Reopen to pick up the change
    mb2 = Mailbox(db_path)
    deleted = mb2.cleanup(bob, older_than_days=7)
    assert deleted == 1
    assert len(mb2.list_archived(bob)) == 0


def test_cleanup_keeps_recent_archived(tmp_path):
    """cleanup doesn't touch recently archived messages."""
    db_path = tmp_path / "mail.db"
    mb = Mailbox(db_path)
    alice = Address.parse("alice@colony")
    bob = Address.parse("bob@colony")

    msg = mb.send(sender=alice, recipients=[bob], subject="new", body="recent.")
    mb.read_message(bob, msg.id)

    deleted = mb.cleanup(bob, older_than_days=7)
    assert deleted == 0
    assert len(mb.list_archived(bob)) == 1
