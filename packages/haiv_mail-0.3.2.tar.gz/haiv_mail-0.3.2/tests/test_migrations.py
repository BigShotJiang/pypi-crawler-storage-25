"""Tests for database schema migrations."""

import sqlite3
from pathlib import Path

from haiv_mail.address import Address
from haiv_mail.mailbox import Mailbox


def _create_v1_database(db_path: Path) -> None:
    """Create a database with the original schema (no is_read column)."""
    conn = sqlite3.connect(str(db_path))
    conn.executescript("""\
        CREATE TABLE messages (
            id          TEXT PRIMARY KEY,
            timestamp   TEXT NOT NULL,
            sender      TEXT NOT NULL,
            recipients  TEXT NOT NULL,
            subject     TEXT NOT NULL,
            body        TEXT NOT NULL,
            in_reply_to TEXT
        );
        CREATE TABLE deliveries (
            message_id  TEXT NOT NULL,
            recipient   TEXT NOT NULL,
            PRIMARY KEY (message_id, recipient),
            FOREIGN KEY (message_id) REFERENCES messages(id)
        );
    """)
    # Insert a message using the old schema
    conn.execute(
        "INSERT INTO messages VALUES (?, ?, ?, ?, ?, ?, ?)",
        ("msg001", "2026-03-27T00:00:00+00:00", "alice@colony", "bob@colony",
         "old message", "from before the migration", None),
    )
    conn.execute(
        "INSERT INTO deliveries (message_id, recipient) VALUES (?, ?)",
        ("msg001", "bob@colony"),
    )
    conn.commit()
    conn.close()


def test_migration_adds_is_read_column(tmp_path: Path):
    """Opening a v1 database should auto-migrate to add is_read."""
    db_path = tmp_path / "mail.db"
    _create_v1_database(db_path)

    # Opening with Mailbox should trigger migration
    mb = Mailbox(db_path)

    # Old message should be readable
    bob = Address.parse("bob@colony")
    messages = mb.list_messages(bob)
    assert len(messages) == 1
    assert messages[0].subject == "old message"

    # Old messages default to unread
    assert mb.unread_count(bob) == 1

    # Reading marks as read
    mb.read_message(bob, "msg001")
    assert mb.unread_count(bob) == 0


def test_migration_is_idempotent(tmp_path: Path):
    """Opening the same database multiple times doesn't fail."""
    db_path = tmp_path / "mail.db"
    _create_v1_database(db_path)

    mb1 = Mailbox(db_path)
    mb1.send(
        sender=Address.parse("alice@colony"),
        recipients=[Address.parse("bob@colony")],
        subject="post-migration",
        body="test",
    )

    # Open again — migration runs again, should be a no-op
    mb2 = Mailbox(db_path)
    bob = Address.parse("bob@colony")
    assert len(mb2.list_messages(bob)) == 2


def test_fresh_database_has_is_read(tmp_path: Path):
    """A brand new database should have is_read from the start."""
    db_path = tmp_path / "mail.db"
    mb = Mailbox(db_path)

    # Verify schema has the column
    conn = sqlite3.connect(str(db_path))
    columns = [row[1] for row in conn.execute("PRAGMA table_info(deliveries)").fetchall()]
    conn.close()

    assert "is_read" in columns


def test_migration_adds_archived_at_column(tmp_path: Path):
    """Opening a pre-archive database should auto-migrate to add archived_at."""
    db_path = tmp_path / "mail.db"
    _create_v1_database(db_path)

    # Add is_read manually (simulates v2 state, pre-archive)
    conn = sqlite3.connect(str(db_path))
    conn.execute("ALTER TABLE deliveries ADD COLUMN is_read INTEGER NOT NULL DEFAULT 0")
    conn.commit()
    conn.close()

    # Opening with Mailbox should add archived_at
    mb = Mailbox(db_path)

    conn = sqlite3.connect(str(db_path))
    columns = [row[1] for row in conn.execute("PRAGMA table_info(deliveries)").fetchall()]
    conn.close()

    assert "archived_at" in columns

    # Old messages should be in inbox (not archived)
    bob = Address.parse("bob@colony")
    assert len(mb.list_messages(bob)) == 1
    assert len(mb.list_archived(bob)) == 0
