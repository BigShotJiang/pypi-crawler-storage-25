#!/usr/bin/env python3
"""Build and publish haiv-mail to PyPI from the main worktree.

Usage:
    python3 publish.py              # build and publish
    python3 publish.py --dry-run    # build only

Prerequisites (one-time setup):
    1. Install the keyring CLI:
       $ uv tool install keyring

    2. Store your PyPI API token in the system keyring:
       $ echo "pypi-YOUR_TOKEN_HERE" | keyring set https://upload.pypi.org/legacy/ __token__

    3. Verify it's stored:
       $ keyring get https://upload.pypi.org/legacy/ __token__
"""

import argparse
import subprocess
import sys
from pathlib import Path

SELF_DIR = Path(__file__).resolve().parent
REPO_ROOT = SELF_DIR.parent.parent
MAIN_WT = REPO_ROOT / "worktrees" / "main"


def main() -> None:
    parser = argparse.ArgumentParser(description="Publish haiv-mail to PyPI")
    parser.add_argument("--dry-run", action="store_true", help="Build only, don't publish")
    args = parser.parse_args()

    if not MAIN_WT.exists():
        die("worktrees/main/ not found")

    check_tag()
    build()

    if args.dry_run:
        print("Dry run — skipping publish.")
        return

    publish()


def check_tag() -> None:
    result = subprocess.run(
        ["git", "tag", "--points-at", "HEAD"],
        cwd=MAIN_WT, capture_output=True, text=True,
    )
    tags = result.stdout.strip()

    if not tags:
        die(
            "HEAD has no tag. Tag the release before publishing:\n"
            "\n"
            "  cd worktrees/main\n"
            "  git tag v<version>\n"
            "  git push origin main --tags\n"
            "\n"
            "The tag should match the version in pyproject.toml."
        )

    print(f"Tagged: {tags}")


def build() -> None:
    print("Building...")
    result = subprocess.run(
        ["uv", "build"],
        cwd=MAIN_WT, capture_output=True, text=True,
    )
    if result.returncode != 0:
        print(result.stderr)
        die("Build failed.")

    built_files = [
        line.removeprefix("Successfully built ").strip()
        for line in result.stderr.splitlines()
        if line.startswith("Successfully built ")
    ]

    if not built_files:
        die("No files built.")

    for f in built_files:
        print(f"  {f}")


def publish() -> None:
    print("Publishing to PyPI...")

    dist_dir = MAIN_WT / "dist"
    dist_files = list(dist_dir.glob("*"))
    if not dist_files:
        die("No dist files found. Build first.")

    result = subprocess.run([
        "uv", "publish",
        "--keyring-provider", "subprocess",
        "--username", "__token__",
        *[str(f) for f in dist_files],
    ], cwd=MAIN_WT)

    if result.returncode != 0:
        die(
            "Publish failed. Check that your keyring has the token:\n"
            "  keyring get https://upload.pypi.org/legacy/ __token__"
        )

    print("Published.")


def die(msg: str) -> None:
    print(f"Error: {msg}", file=sys.stderr)
    sys.exit(1)


if __name__ == "__main__":
    main()
