"""NextToken SDK - Simple client for the NextToken Gateway."""

from .agents import Agent, Agents, Run, RunResult
from .client import NextToken
from .email import Email
from .fetch import Fetch
from .integrations import Integrations
from .search import Search
from .workspaces import Workspace, Workspaces

__version__ = "0.9.0"
__all__ = [
    "NextToken",
    "Agent",
    "Agents",
    "Email",
    "Fetch",
    "Integrations",
    "Run",
    "RunResult",
    "Search",
    "Workspace",
    "Workspaces",
    "__version__",
]
