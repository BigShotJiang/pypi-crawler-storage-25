"""Publishing utilities for test_publish package."""

import logging

logger = logging.getLogger(__name__)


def validate_version(version: str) -> bool:
    """Check if a version string follows semver format (X.Y.Z)."""
    parts = version.split(".")
    if len(parts) != 3:
        return False
    return all(p.isdigit() for p in parts)


def bump_version(version: str, part: str = "patch") -> str:
    """Bump a semver version string.

    Args:
        version: Current version in X.Y.Z format.
        part: Which part to bump — 'major', 'minor', or 'patch'.

    Returns:
        New version string with the specified part incremented.
    """
    if not validate_version(version):
        raise ValueError(f"Invalid version format: {version}")

    major, minor, patch = (int(p) for p in version.split("."))

    if part == "major":
        return f"{major + 1}.0.0"
    elif part == "minor":
        return f"{major}.{minor + 1}.0"
    else:
        return f"{major}.{minor}.{patch + 1}"


def get_version_info(name: str, version: str) -> dict:
    """Return package version information.

    Args:
        name: Package name.
        version: Current version string.

    Returns:
        dict with package name, version, and release metadata.
    """
    if not name:
        raise ValueError("Package name is required")

    if not version:
        raise ValueError("Version is required")

    logger.info("Getting version info for %s@%s", name, version)

    return {
        "name": name,
        "version": version,
        "is_prerelease": any(c in version for c in ("a", "b", "rc")),
        "is_latest": not any(c in version for c in ("a", "b", "rc")),
    }
