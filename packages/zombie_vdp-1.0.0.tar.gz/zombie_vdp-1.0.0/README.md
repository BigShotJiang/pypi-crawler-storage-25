# 🧟‍♂️ Zombie VDP – Ultimate Identity Edition

**NASA VDP Compliant · 100% Passive · Triple Filter · Evidence Locker · Time Slice · Auto-PoC · Memory**

Zombie VDP adalah kerangka kerja bug bounty pribadi yang menggabungkan seluruh pipeline pengujian keamanan dalam satu nafas. Semua fitur dirancang dari nol, bukan meniru alat lain, melainkan menciptakan identitas sendiri: **Ninja**, **Samurai**, dan **Ghost**.

---

## 🔥 Fitur Legendaris

### ⚔️ Triple Filter (Ninja · Samurai · Ghost)
- **Ninja Filter** – Hanya menerima temuan dengan bukti nyata (evidence).
- **Samurai Filter** – Hanya HIGH/CRITICAL dengan respons signifikan.
- **Ghost Filter** – Hanya confidence ≥98% atau metode timing/OOB.

### 🧪 Zombie Deep Scan
Validasi lanjutan setelah filter: serangan timing untuk konfirmasi SQLi, dsb.

### 🔒 Zombie Evidence Locker
Setiap temuan yang lolos filter disimpan sebagai bukti terenkripsi (format `.zombie`). Tidak bisa dibuka tanpa kunci.

### ⏳ Zombie Time Slice
Zombie hanya beroperasi pada jam yang diizinkan (misal 02:00–05:00 UTC). Di luar jam itu, ia berhenti dan menunggu.

### ⚡ Zombie Auto-PoC
Setiap temuan langsung dilengkapi skrip `curl` dan Python untuk mereproduksi kerentanan. Tim triase tinggal menjalankan.

### 🧠 Zombie Memory
Jika pemindaian terhenti, Zombie mengingat titik terakhir dan bisa melanjutkan tanpa mengulang.

### 🕸️ Zombie Crawler & Dorking (Internal)
Crawler mandiri + penyaring URL berbasis pola (tanpa search engine). 100% pasif, tidak meninggalkan jejak bot.

### 🛡️ Scanner Kerentanan Bawaan
- Reflected XSS
- SQL Injection (error‑based + timing)
- Local File Inclusion (LFI)
- Server‑Side Template Injection (SSTI)
- Open Redirect
- Adaptive Fuzzer
- Secrets Scanner (AWS, GitHub, Slack, JWT)

### 📊 Laporan Profesional
HTML report siap kirim ke program VDP. Ringan, rapi, hanya berisi temuan high/critical.

---

## 🚀 Menjalankan

```bash
python zombie_vdp.py
