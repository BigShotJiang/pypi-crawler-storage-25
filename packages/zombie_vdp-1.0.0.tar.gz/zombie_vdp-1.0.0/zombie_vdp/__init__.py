# zombie_vdp/__init__.py
from .zombie import main_async
import asyncio

def main():
    """Entry point untuk console_scripts."""
    asyncio.run(main_async())

__version__ = "1.0.0"
__author__ = "Dikha Pormes"