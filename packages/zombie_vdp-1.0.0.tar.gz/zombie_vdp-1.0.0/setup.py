from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="zombie-vdp",
    version="1.0.0",
    author="Dikha Pormes",
    author_email="pormesdikha90@gmail.com",
    description="🧟‍♂️ Zombie VDP – Ultimate Identity Edition",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/pormes-90/ZOMBIE.git",
    packages=find_packages(),
    include_package_data=True,  # Wajib agar config.yaml ikut terdistribusi
    install_requires=[
        "aiohttp>=3.8",
        "pyyaml>=6.0",
        "dnspython>=2.3",
        "psutil>=5.9",
        "colorama>=0.4",
        "beautifulsoup4>=4.12",
        "cryptography>=41.0",
    ],
    extras_require={
        "full": [
            "scikit-learn>=1.3",
            "matplotlib>=3.7",
    ],
},
entry_points={
    "console_scripts": [
        "zombie = zombie_vdp:main",
    ],
},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Information Technology",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Topic :: Security",
    ],
    python_requires=">=3.9",
)
