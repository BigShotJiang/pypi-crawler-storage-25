import gc
import difflib
import threading
import tkinter as tk
import tkinter.font as tkFont
from tkinter import messagebox

from geopy.distance import geodesic
from geopy.geocoders import Nominatim
from PIL import Image, ImageTk

from observation_sources.metadata import (
    apply_land_input_display_globals,
    build_land_station_choice_text,
    build_scraped_land_station_result,
    build_state_station_candidates,
    clean_station_name,
    find_first_valid_temperature_row,
    calculate_station_map_center,
    calculate_station_map_zoom_level,
    build_station_map_bounds,
    fetch_valid_land_station_choices_fast,
    get_obs_ordinal,
    normalize_land_input_values,
    is_valid_land_input,
)
from observation_sources.workflows import (
    create_station_map_screenshot,
    display_station_map_image,
    find_and_scrape_land_stations_sequentially,
    get_valid_station_choice_color,
)
from ui_flows import add_modern_screen_text, create_modern_button, style_input_entry
from utils.text_formatting import obs_buttons_choice_abbreviations


def xobs_check_land(
    obs_type,
    input_town,
    input_state,
    frame,
    tk_background_color,
    button_font,
    back_command,
    confirm_command_handler,
    deps,
):
    deps["globals_dict"]["frame1_overlay_lock"] = True
    print(f"\n--- Running xobs_check_land ---")
    print(f"  Searching for stations near: {input_town}, {input_state}")
    print(f"--------------------------------")
    deps["hide_display_frame_for_frame1"]()

    selected_site_index = tk.IntVar(value=-1)
    num_stations_to_find = 5

    def _normalize_station_name(value):
        cleaned = []
        for char in (value or "").upper():
            cleaned.append(char if char.isalnum() else " ")
        raw_tokens = " ".join("".join(cleaned).split()).split()
        token_aliases = {
            "MT": "MOUNT",
            "MTN": "MOUNTAIN",
            "N": "NORTH",
            "S": "SOUTH",
            "E": "EAST",
            "W": "WEST",
            "NE": "NORTHEAST",
            "NW": "NORTHWEST",
            "SE": "SOUTHEAST",
            "SW": "SOUTHWEST",
        }
        normalized_tokens = [token_aliases.get(token, token) for token in raw_tokens]
        return " ".join(normalized_tokens)

    def _station_name_tokens(value):
        normalized = _normalize_station_name(value)
        return normalized.split() if normalized else []

    def _name_matches_query(station_name, entered_town):
        directional_tokens = {
            "NORTH", "SOUTH", "EAST", "WEST",
            "NORTHEAST", "NORTHWEST", "SOUTHEAST", "SOUTHWEST",
        }
        query_normalized = _normalize_station_name(entered_town)
        query_tokens = _station_name_tokens(entered_town)
        station_normalized = _normalize_station_name(station_name)
        station_tokens = _station_name_tokens(station_name)

        if not query_tokens or not station_tokens:
            return False
        if station_normalized == query_normalized:
            return True
        if len(query_tokens) == 1 and station_tokens[-1] == query_tokens[0]:
            prefix_tokens = station_tokens[:-1]
            return bool(prefix_tokens) and all(token in directional_tokens for token in prefix_tokens)
        return False

    def _find_rescue_candidates(station_candidates, entered_town, selected_ids, selected_names, limit=3):
        query_tokens = _station_name_tokens(entered_town)
        if not query_tokens:
            return []

        matches = []
        seen_ids = set()
        for candidate in station_candidates:
            station_id, raw_station_name, *_ = candidate
            if station_id in selected_ids or station_id in seen_ids:
                continue

            station_tokens = _station_name_tokens(raw_station_name)
            if not station_tokens:
                continue

            score = None
            if _name_matches_query(raw_station_name, entered_town):
                score = 0
            elif all(token in station_tokens for token in query_tokens):
                score = 1
            elif len(query_tokens) == 1 and query_tokens[0] in station_tokens:
                score = 2

            if score is None:
                continue

            seen_ids.add(station_id)
            matches.append((score, candidate[4], candidate))

        matches.sort(key=lambda item: (item[0], item[1]))
        return [candidate for _, _, candidate in matches[:limit]]

    def _build_spelling_suggestions(entered_town, entered_state, limit=3):
        query_normalized = _normalize_station_name(entered_town)
        if not query_normalized:
            return []

        try:
            stations = deps["load_all_stations_cached_dicts"]()
        except Exception:
            return []

        unique_state_names = {}
        for station in stations or []:
            if str(station.get("state", "")).strip().upper() != str(entered_state or "").strip().upper():
                continue

            cleaned_name = clean_station_name(station.get("name", "")).strip()
            normalized_name = _normalize_station_name(cleaned_name)
            if not cleaned_name or not normalized_name or normalized_name == query_normalized:
                continue

            existing_name = unique_state_names.get(normalized_name)
            if existing_name is None or len(cleaned_name) < len(existing_name):
                unique_state_names[normalized_name] = cleaned_name

        close_keys = difflib.get_close_matches(
            query_normalized,
            list(unique_state_names.keys()),
            n=limit,
            cutoff=0.72,
        )

        suggestions = [unique_state_names[key] for key in close_keys]

        if suggestions:
            return suggestions

        ranked = []
        for normalized_name, cleaned_name in unique_state_names.items():
            similarity = difflib.SequenceMatcher(None, query_normalized, normalized_name).ratio()
            if similarity >= 0.64:
                ranked.append((similarity, cleaned_name))

        ranked.sort(key=lambda item: (-item[0], item[1]))
        return [name for _, name in ranked[:limit]]

    def calculate_center(stations):
        return calculate_station_map_center(stations)

    def calculate_zoom_level(stations):
        return calculate_station_map_zoom_level(stations, geodesic)

    def create_map_image(stations, progress_label=None, local_frame=None):
        try:
            return create_station_map_screenshot(
                stations,
                progress_label,
                local_frame,
                deps["chrome_driver_path"],
                calculate_center,
                calculate_zoom_level,
                build_station_map_bounds,
                deps["folium_module"],
                deps["options_cls"],
                deps["service_cls"],
                deps["webdriver_module"],
                deps["os_module"],
                deps["time_module"],
            )
        except Exception as e:
            print(f"Error creating map image: {e}")
            return False

    def build_map_in_background(stations):
        def worker():
            try:
                create_map_image(stations)
                def apply_map():
                    if not frame.winfo_exists():
                        return
                    try:
                        if not map_placeholder.winfo_exists():
                            return
                    except Exception:
                        return
                    display_station_map_image(
                        frame,
                        "/home/santod/station_locations.png",
                        tk,
                        Image,
                        ImageTk,
                        deps["os_module"],
                    )
                frame.after(0, apply_map)
            except Exception as e:
                print(f"Error building station map in background: {e}")

        threading.Thread(target=worker, name="land-station-map", daemon=True).start()

    def on_radio_select():
        if selected_site_index.get() != -1 and submit_button["state"] == "disabled":
            submit_button.config(state="normal")

    def on_submit_click():
        print("Submit button clicked.")
        selected_index = selected_site_index.get()
        if 0 <= selected_index < len(valid_stations_data):
            selected_station_data = valid_stations_data[selected_index]
            print(f"Confirming selection: {selected_station_data.get('identifier')}")
            instructions_label.config(text="Preparing the selected station...")
            frame.update_idletasks()
            confirm_command_handler(selected_station_data)
        else:
            print("Submit clicked but no valid station selected.")
            messagebox.showwarning("No Selection", "Please select a station before submitting.")

    try:
        progress_label = getattr(frame, "land_search_status_label", None)
        if progress_label is None or not progress_label.winfo_exists():
            progress_label = tk.Label(
                frame,
                text="Searching nearby stations...",
                font=("Helvetica Neue", 13, "bold"),
                fg="black",
                bg=tk_background_color,
                justify="left",
                wraplength=800,
            )
            progress_label.grid(row=5, column=0, columnspan=2, padx=50, pady=10, sticky="nw")
        else:
            progress_label.config(text="Searching nearby stations...", font=("Helvetica Neue", 13, "bold"))
            frame.update_idletasks()

        location = Nominatim(user_agent="town-state-locator-v2").geocode(
            f"{input_town}, {input_state}",
            exactly_one=True,
            timeout=10,
        )
        if location is None:
            raise ValueError("Geo-Location failed.")

        stations = deps["load_all_stations_cached_dicts"]()
        if not stations:
            raise ValueError("Could not load master station list.")

        station_candidates = build_state_station_candidates(
            stations,
            input_state,
            location.latitude,
            location.longitude,
            deps["distance_func"],
        )

        valid_stations_data = fetch_valid_land_station_choices_fast(
            station_candidates,
            input_state,
            num_stations_to_find,
            progress_label,
            frame,
        )
        if not valid_stations_data:
            raise ValueError("No functioning stations could be found after checking.")

        selected_ids = {station.get("identifier") for station in valid_stations_data}
        selected_names = [station.get("name", "") for station in valid_stations_data]
        rescue_candidates = _find_rescue_candidates(station_candidates, input_town, selected_ids, selected_names)

        for widget in frame.winfo_children():
            widget.destroy()
        frame.configure(bg=tk_background_color)
        frame.land_search_status_label = None

        header_font = tkFont.Font(family="Arial", size=18, weight="bold")
        obs_font = tkFont.Font(family="Helvetica", size=12)
        frame.grid_columnconfigure(1, weight=1)

        header_frame = tk.Frame(frame, bg=tk_background_color)
        header_frame.grid(row=0, column=0, columnspan=2, padx=50, pady=(20, 0), sticky="nw")
        header_logo = deps["create_small_weather_observer_logo"](header_frame, size=(65, 65))
        header_logo.grid(row=0, column=0, padx=(0, 6), pady=(6, 0), sticky="w")
        label1 = tk.Label(header_frame, text="The Weather Observer", font=header_font, bg=tk_background_color, justify="left")
        label1.grid(row=0, column=1, pady=(12, 0), sticky="w")

        right_panel = tk.Frame(frame, width=450, height=506, bg=tk_background_color)
        right_panel.grid(row=1, column=1, rowspan=7, sticky="ne", padx=(40, 10), pady=(5, 10))
        right_panel.grid_propagate(False)

        rescue_status_frame = tk.Frame(right_panel, width=450, height=162, bg="#eef5fb", relief="solid", bd=1)
        rescue_status_frame.place(x=0, y=0, width=450, height=162)
        rescue_status_frame.grid_propagate(False)
        instructions_label = tk.Label(
            rescue_status_frame,
            text=f"Please choose a site to represent {input_town}, {input_state}",
            font=("Helvetica", 12),
            fg="black",
            bg="#eef5fb",
            justify="left",
            anchor="w",
            wraplength=420,
        )
        instructions_label.place(x=12, y=8, width=426, height=34)
        rescue_status_label = tk.Label(
            rescue_status_frame,
            text="",
            font=("Helvetica", 9),
            fg="black",
            bg="#eef5fb",
            justify="left",
            anchor="w",
            wraplength=420,
        )
        rescue_status_label.place(x=12, y=46, width=426, height=60)
        rescue_action_frame = tk.Frame(rescue_status_frame, bg="#eef5fb")
        rescue_action_frame.place(x=12, y=122, width=426, height=28)

        def clear_rescue_actions():
            for child in rescue_action_frame.winfo_children():
                child.destroy()

        def reset_rescue_panel(message=""):
            clear_rescue_actions()
            rescue_status_label.config(text=message)

        map_container = tk.Frame(right_panel, width=450, height=300, bg="#eef5fb", relief="solid", bd=1)
        map_container.place(x=0, y=196, width=450, height=300)
        map_container.grid_propagate(False)
        frame.station_map_container = map_container

        map_placeholder = tk.Label(
            map_container,
            text="Map showing valid station locations will appear here shortly.",
            bg="#eef5fb",
            fg="black",
            font=("Helvetica", 12),
            justify="center",
            wraplength=340,
        )
        map_placeholder.place(x=1, y=1, width=448, height=298)

        def restore_rescue_buttons():
            back_button.config(state="normal")
            submit_button.config(state="normal" if selected_site_index.get() != -1 else "disabled")
            if rescue_button is not None:
                rescue_button.config(state="normal")

        def show_rescue_confirmation(rescued_station):
            rescued_identifier = str(
                rescued_station.get("identifier")
                or rescued_station.get("station_id")
                or ""
            ).strip().upper()
            rescued_name = rescued_station.get("name", "the exact site")
            rescued_label = f"{rescued_identifier} {rescued_name}".strip()
            instructions_label.config(
                text=f"Found {rescued_label}. You can use this exact site or keep one of the original 5 below."
            )
            reset_rescue_panel(
                f"Found {rescued_label}. You can use this exact site or keep one of the original 5 below."
            )
            tk.Button(
                rescue_action_frame,
                text="Use Exact",
                font=("Helvetica", 9),
                width=9,
                command=lambda: confirm_command_handler(rescued_station),
            ).grid(row=0, column=0, padx=(0, 10), sticky="w")
            restore_rescue_buttons()

        def scrape_rescue_candidate(candidate):
            instructions_label.config(text="Checking the exact site...")
            reset_rescue_panel("Checking the exact site...")
            frame.update_idletasks()
            back_button.config(state="disabled")
            submit_button.config(state="disabled")
            if rescue_button is not None:
                rescue_button.config(state="disabled")

            scraped_results = find_and_scrape_land_stations_sequentially(
                [candidate],
                None,
                None,
                1,
                deps["chrome_driver_path"],
                deps["options_cls"],
                deps["service_cls"],
                deps["webdriver_module"],
                deps["by_cls"],
                deps["os_module"],
                deps["signal_module"],
                input_state,
                find_first_valid_temperature_row,
                build_scraped_land_station_result,
            )

            if not scraped_results:
                instructions_label.config(text=f"Please choose a site to represent {input_town}, {input_state}")
                reset_rescue_panel("The exact site could not be retrieved right now. The original 5 choices are still available.")
                restore_rescue_buttons()
                return

            show_rescue_confirmation(scraped_results[0])

        def on_rescue_click():
            if not rescue_candidates:
                return
            if len(rescue_candidates) == 1:
                scrape_rescue_candidate(rescue_candidates[0])
                return

            chooser = tk.Toplevel(frame)
            chooser.title("Exact Site")
            chooser.configure(bg=tk_background_color)
            chooser.transient(frame.winfo_toplevel())
            chooser.grab_set()

            selected_rescue_index = tk.IntVar(value=0)

            tk.Label(
                chooser,
                text="Choose the site you want to check:",
                font=("Helvetica Neue", 13, "bold"),
                fg="black",
                bg=tk_background_color,
                justify="left",
            ).grid(row=0, column=0, columnspan=2, padx=18, pady=(14, 8), sticky="w")

            for idx, candidate in enumerate(rescue_candidates):
                station_id, raw_station_name, *_ = candidate
                label_text = f"{raw_station_name} ({station_id})"
                tk.Radiobutton(
                    chooser,
                    text=label_text,
                    variable=selected_rescue_index,
                    value=idx,
                    font=("Helvetica", 12),
                    justify="left",
                    anchor="w",
                    bg=tk_background_color,
                    activebackground=tk_background_color,
                    selectcolor=tk_background_color,
                ).grid(row=1 + idx, column=0, columnspan=2, padx=18, pady=4, sticky="w")

            def choose_candidate():
                candidate = rescue_candidates[selected_rescue_index.get()]
                chooser.destroy()
                scrape_rescue_candidate(candidate)

            tk.Button(
                chooser,
                text="Cancel",
                font=("Helvetica", 11),
                width=8,
                command=chooser.destroy,
            ).grid(row=1 + len(rescue_candidates), column=0, padx=(18, 8), pady=(12, 14), sticky="w")
            tk.Button(
                chooser,
                text="Check",
                font=("Helvetica", 11),
                width=8,
                command=choose_candidate,
            ).grid(row=1 + len(rescue_candidates), column=1, padx=(8, 18), pady=(12, 14), sticky="e")

        for index, station in enumerate(valid_stations_data):
            button_text = build_land_station_choice_text(
                station,
                input_state,
                obs_buttons_choice_abbreviations,
            )
            choice_color = get_valid_station_choice_color(index)

            button_row_frame = tk.Frame(frame, bg=tk_background_color)
            button_row_frame.grid(row=2 + index, column=0, padx=50, pady=2, sticky="nw")

            radio_button = tk.Radiobutton(
                button_row_frame,
                text=button_text,
                variable=selected_site_index,
                value=index,
                font=obs_font,
                justify="left",
                anchor="w",
                padx=10,
                pady=17,
                bg=tk_background_color,
                activebackground=tk_background_color,
                selectcolor=tk_background_color,
                relief="raised",
                borderwidth=1,
                width=38,
                height=3,
                command=on_radio_select,
                highlightthickness=1,
                highlightbackground="#9AA4AF",
            )
            radio_button.grid(row=0, column=0, sticky="nw")

            choice_dot = tk.Label(
                button_row_frame,
                width=2,
                bg=choice_color,
                relief="solid",
                bd=1,
                highlightthickness=0,
            )
            choice_dot.grid(row=0, column=1, padx=(8, 0), pady=17, sticky="n")

        bottom_row = 2 + len(valid_stations_data)
        bottom_controls = tk.Frame(frame, bg=tk_background_color, width=396, height=44)
        bottom_controls.grid(row=bottom_row, column=0, padx=50, pady=(0, 16), sticky="sw")
        bottom_controls.grid_propagate(False)

        back_button = tk.Button(bottom_controls, text="Back", font=button_font, width=6, command=back_command)
        back_button.place(x=0, y=4, width=100, height=32)

        rescue_button = None
        if rescue_candidates:
            rescue_button = tk.Button(
                bottom_controls,
                text="Try Exact\nSite",
                font=("Helvetica", 9),
                width=6,
                justify="center",
                command=on_rescue_click,
            )
            rescue_button.place(x=148, y=4, width=100, height=32)

        submit_button = tk.Button(
            bottom_controls,
            text="Submit",
            font=button_font,
            state="disabled",
            width=6,
            command=on_submit_click,
        )
        submit_button.place(x=296, y=4, width=100, height=32)
        build_map_in_background(valid_stations_data)

    except Exception as e:
        print(f"Error encountered in xobs_check_land: {type(e).__name__}: {e}")
        for widget in frame.winfo_children():
            widget.destroy()
        frame.configure(bg=tk_background_color)
        spelling_suggestions = _build_spelling_suggestions(input_town, input_state)
        header_frame = tk.Frame(frame, bg=tk_background_color)
        header_frame.grid(row=0, column=0, padx=50, pady=10, sticky="w")
        header_logo = deps["create_small_weather_observer_logo"](header_frame, size=(65, 65))
        header_logo.grid(row=0, column=0, padx=(0, 6), pady=(6, 0), sticky="w")
        label1 = tk.Label(header_frame, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
        label1.grid(row=0, column=1, pady=(12, 0), sticky="w")
        instructions_label = tk.Label(
            frame,
            text=f"An error occurred: {str(e).rstrip('.')}. You may have misspelled the town or state.",
            font=("Helvetica", 16),
            bg=tk_background_color,
            wraplength=800,
            justify="left",
        )
        instructions_label.grid(row=1, column=0, padx=50, pady=(20, 10), sticky="w")

        next_row = 2
        if spelling_suggestions:
            suggestion_label = tk.Label(
                frame,
                text="Did you mean:",
                font=("Helvetica Neue", 14, "bold"),
                bg=tk_background_color,
                justify="left",
            )
            suggestion_label.grid(row=next_row, column=0, padx=50, pady=(10, 6), sticky="w")
            next_row += 1

            suggestions_frame = tk.Frame(frame, bg=tk_background_color)
            suggestions_frame.grid(row=next_row, column=0, padx=50, pady=(0, 10), sticky="w")
            next_row += 1

            for index, suggestion in enumerate(spelling_suggestions):
                tk.Button(
                    suggestions_frame,
                    text=f"{suggestion}, {input_state}",
                    font=("Helvetica", 11),
                    command=lambda candidate=suggestion: xobs_check_land(
                        obs_type,
                        candidate,
                        input_state,
                        frame,
                        tk_background_color,
                        button_font,
                        back_command,
                        confirm_command_handler,
                        deps,
                    ),
                ).grid(row=0, column=index, padx=(0, 10), pady=0, sticky="w")
        try:
            tk.Button(frame, text="Back", font=button_font, command=back_command).grid(
                row=next_row,
                column=0,
                padx=(50, 0),
                pady=10,
                sticky="w",
            )
        except NameError:
            pass

    gc.collect()


def xobs_input_land(
    obs_type,
    frame,
    tk_background_color,
    button_font,
    back_command,
    submit_command_handler,
    deps,
):
    deps["globals_dict"]["frame1_overlay_lock"] = True
    ordinal = get_obs_ordinal(obs_type)

    for widget in frame.winfo_children():
        widget.destroy()
    deps["hide_display_frame_for_frame1"]()

    frame.grid(row=0, column=0, sticky="nsew")
    frame.tkraise()
    frame.configure(bg=tk_background_color)

    instruction_text = f"Please enter the name of the town for the {ordinal} observation site:"
    add_modern_screen_text(
        frame,
        tk,
        tk_background_color,
        "The Weather Observer",
        instruction_text,
        title_row=0,
        body_row=1,
        title_padx=50,
        title_pady=(50, 0),
        body_padx=50,
        body_pady=2,
        title_columnspan=2,
        body_columnspan=2,
        sticky="nw",
    )

    town_entry = tk.Entry(frame, font=("Helvetica", 14), width=40)
    town_entry.grid(row=2, column=0, columnspan=2, padx=50, pady=2, sticky="nw")
    style_input_entry(town_entry)
    if "set_keyboard_mode" in deps:
        deps["set_keyboard_mode"](town_entry, "town")

    state_instruction_text = f"Please enter the 2-letter state ID for the {ordinal} observation site:"
    state_instructions_label = tk.Label(frame, text=state_instruction_text, font=("Helvetica Neue", 15), fg="black", bg=tk_background_color, justify="left")
    state_instructions_label.grid(row=3, column=0, columnspan=2, padx=50, pady=2, sticky="nw")

    state_entry = tk.Entry(frame, font=("Helvetica", 14), width=5)
    state_entry.grid(row=4, column=0, columnspan=2, padx=50, pady=2, sticky="nw")
    style_input_entry(state_entry)
    if "set_keyboard_mode" in deps:
        deps["set_keyboard_mode"](state_entry, "state")

    search_status_label = tk.Label(
        frame,
        text="",
        font=("Helvetica Neue", 12, "bold"),
        fg="black",
        bg=tk_background_color,
        justify="left",
        wraplength=760,
    )
    search_status_label.grid(row=5, column=0, columnspan=2, padx=50, pady=(6, 0), sticky="nw")
    frame.land_search_status_label = search_status_label

    def _on_submit():
        raw_town = town_entry.get()
        raw_state = state_entry.get()

        normalized_input = normalize_land_input_values(raw_town, raw_state)
        entered_town = normalized_input["entered_town"]
        entered_state = normalized_input["entered_state"]

        print(f"Submit clicked for {obs_type.upper()}. Town: '{entered_town}', State: '{entered_state}'")
        if not is_valid_land_input(entered_town, entered_state):
            if not entered_town:
                print("Error: Town cannot be empty.")
            else:
                print("Error: State must be 2 letters.")
            return

        town_entry.config(state="disabled")
        state_entry.config(state="disabled")
        back_button.config(state="disabled")
        submit_button.config(state="disabled")
        search_status_label.config(
            text="Searching nearby stations and checking which ones are working now..."
        )
        frame.update_idletasks()

        def start_station_search():
            submit_command_handler(entered_town, entered_state.upper())
            apply_land_input_display_globals(
                ordinal,
                entered_town,
                entered_state,
                deps["globals_dict"],
            )

        frame.after(10, start_station_search)

    back_button = create_modern_button(frame, tk, " Back ", back_command, font=button_font, variant="secondary")
    back_button.grid(row=6, column=0, padx=(50, 0), pady=8, sticky="w")

    submit_button = create_modern_button(frame, tk, "Submit", _on_submit, font=button_font, variant="primary")
    submit_button.grid(row=6, column=0, padx=(200, 0), pady=8, sticky="w")

    town_entry.bind("<FocusIn>", lambda e: deps["set_current_target"](town_entry))
    state_entry.bind("<FocusIn>", lambda e: [deps["set_current_target"](state_entry), deps["set_state_uppercase"]()])

    town_entry.focus_set()

    current_target_entry = deps["current_target_getter"]()
    if current_target_entry and current_target_entry.winfo_exists():
        deps["auto_capitalize"]()

    deps["create_virtual_keyboard"](deps["keyboard_parent"], 7)

    try:
        deps["root"].grab_release()
    except Exception:
        pass
    frame.update_idletasks()
    deps["root"].after_idle(lambda: town_entry.focus_force())
    deps["root"].after_idle(lambda: deps["set_current_target"](town_entry))
