# Hi David - 2026-05-04 11:18:03 PM EDT
# 3/25/26 reconfigure
# 3/27/26 completed image sources
# 3/31/26 started observations sources
# 4/5/26 some of obs done. moving to codex

import subprocess
import sys
import importlib.metadata
import os
import requests
import difflib
import re
import shutil
import platform
import time
from time import strftime
import datetime as dt
from datetime import datetime, timedelta, timezone
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
matplotlib.rcParams['toolbar'] = 'None'
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter, AutoMinorLocator)
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import pandas as pd
import json
from matplotlib import rcParams
import io
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont, ImageTk, ImageChops, UnidentifiedImageError, ImageFilter
import matplotlib.image as mpimg
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import traceback
import imageio
from math import radians, sin, cos, sqrt, atan2
import geopy.distance
from geopy.geocoders import Nominatim
from geopy.distance import geodesic
from geopy.exc import GeocoderTimedOut, GeocoderUnavailable
import urllib.parse
from selenium import webdriver
from selenium.common.exceptions import WebDriverException, NoSuchElementException, TimeoutException, SessionNotCreatedException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.action_chains import ActionChains
import threading
import tkinter as tk
from tkinter import ttk, IntVar, messagebox, PhotoImage, simpledialog, font, Checkbutton
import tkinter.font as tkFont
from collections import deque
from matplotlib.widgets import Button
import matplotlib.ticker as ticker
import warnings
import itertools
from itertools import cycle, islice
import psutil
import gc
from queue import Queue, Empty
data_update_queue = Queue()
from threading import Thread
from functools import partial
import logging
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
import base64
import random
import pytz
import concurrent.futures
import folium
import ssl
import certifi
from dateutil import parser
import urllib3
import asyncio
import aiohttp
from folium.plugins import MarkerCluster
from folium import Element
from tkhtmlview import HTMLLabel
import math
import calendar
import signal
from concurrent.futures import ThreadPoolExecutor
import uuid
import configparser
import copy
import xml.etree.ElementTree as ElementTree
import smbus2 as smbus
import tracemalloc
from bs4 import BeautifulSoup
from bs4.element import Tag
import time, queue
from PIL import ImageTk 
import zlib # added these three lines on 8/10/25
from functools import lru_cache # added 9/30/25 to manage the use of cached land & buoy meta data
#start new modules 3/25/26
from utils.conversions import pascals_to_inches_hg, is_black_image
from utils.text_formatting import obs_buttons_choice_abbreviations, abbreviate_location, format_map_flag_label
from image_sources.radar_national import (
    fetch_and_process_national_radar,
)
from image_sources.national_surface import (
    fetch_and_process_national_sfc,
)
from image_sources.storm_reports import (
    fetch_and_process_storm_reports,
)
from image_sources.vorticity import (
    fetch_and_process_vorticity,
)
from image_sources.barograph_image import fetch_and_process_baro_pic
import image_sources.barograph_image as barograph_image_module
from image_sources.still_satellite import fetch_and_process_still_sat
from image_sources.lightning import fetch_and_process_lightning, cleanup_lightning_image
from image_sources.radiosonde import fetch_and_process_radiosonde
from image_sources.sfc_plots import fetch_and_process_sfc_plots
from image_sources.local_radar import get_lcl_radar_loop
from image_sources.regional_satellite import fetch_and_process_reg_sat_loop as module_fetch_and_process_reg_sat_loop
from observation_land_ui import (
    xobs_check_land as land_ui_xobs_check_land,
    xobs_input_land as land_ui_xobs_input_land,
)
from display_engine import (
    on_touch_start as display_on_touch_start,
    handle_swipe as display_handle_swipe,
    on_left_swipe as display_on_left_swipe,
    on_right_swipe as display_on_right_swipe,
    run_lcl_radar_loop_animation as display_run_lcl_radar_loop_animation,
    run_reg_sat_loop_animation as display_run_reg_sat_loop_animation,
    show_image_in_display_frame as display_show_image_in_display_frame,
    auto_advance_frames as display_auto_advance_frames,
    return_to_image_cycle as display_return_to_image_cycle,
    run_lightning_task as display_run_lightning_task,
    run_lcl_radar_task as display_run_lcl_radar_task,
    run_sfc_plots_task as display_run_sfc_plots_task,
    run_reg_sat_task as display_run_reg_sat_task,
)
from task_scheduler import (
    cpu_lull_monitor as scheduler_cpu_lull_monitor,
    start_cpu_monitor as scheduler_start_cpu_monitor,
    run_observations_task as scheduler_run_observations_task,
    update_images as scheduler_update_images,
)
from startup_systems import (
    ensure_network_manager_enabled_and_started as startup_ensure_network_manager_enabled_and_started,
    get_os_codename as startup_get_os_codename,
    detect_chromium_and_driver as startup_detect_chromium_and_driver,
    load_remote_secrets,
    start_background_event_loop,
)
from map_rendering import capture_folium_map_screenshot
from barograph_runtime import (
    load_barograph_history,
    read_barograph_sample,
    build_barograph_time_context,
    append_barograph_point,
    reset_midnight_annotation_flags,
    save_barograph_history,
    update_barograph_annotations,
    finalize_barograph_frame,
)
from ui_flows import (
    destroy_frame_widgets,
    hide_ui_frames,
    prepare_frame1_screen,
    reset_for_frame1_display,
    build_land_or_buoy_screen,
    prepare_observation_button_edit,
    add_weather_observer_header,
    build_message_action_screen,
    add_modern_screen_text,
    create_modern_button,
    style_input_entry,
)
from sharing_integrations import (
    send_screenshot_email,
    capture_screenshot,
    validate_screenshot_file,
    post_to_facebook as share_post_to_facebook,
    post_to_instagram as share_post_to_instagram,
)
from virtual_keyboard import (
    set_state_uppercase as keyboard_set_state_uppercase,
    auto_capitalize as keyboard_auto_capitalize,
    set_keyboard_target as keyboard_set_keyboard_target,
    set_current_target as keyboard_set_current_target,
    key_pressed as keyboard_key_pressed,
    update_keyboard_shift_state as keyboard_update_keyboard_shift_state,
    set_widget_keyboard_mode as keyboard_set_widget_keyboard_mode,
)
# observation sources
from observation_sources.metadata import (
    populate_random_station_selection_globals,
    get_random_station_config,
    find_valid_random_stations,
    check_random_station_functionality,
    preload_random_station_observations,
    populate_random_station_observation_globals,
    apply_manual_land_confirmation_globals,
    apply_buoy_selection_globals,
    populate_single_buoy_observation_globals,
    clear_obs_only_click_flag,
    apply_buoy_display_name,
    get_obs_slot_config,
    get_random_station_slots,
    build_selected_station_details,
    apply_station_details_to_globals,
    build_state_station_candidates,
    find_first_valid_temperature_row,
    build_scraped_land_station_result,
    calculate_station_map_center,
    calculate_station_map_zoom_level,
    build_station_map_bounds,
    build_land_station_choice_text,
    clean_station_name,
    normalize_land_input_values,
    is_valid_land_input,
    apply_land_input_display_globals,
    get_obs_ordinal,
    build_buoy_choice_text_from_description,
    apply_buoy_help_selection_globals,
    build_buoy_help_final_list,
    get_land_confirmation_slot_config,
    find_buoy_help_nearest_buoys,
    check_buoy_help_functionality,
    calculate_buoy_help_center as metadata_calculate_buoy_help_center,
    calculate_buoy_help_zoom_level as metadata_calculate_buoy_help_zoom_level,
    normalize_station_id,
    normalize_buoy_help_town_state_input,
    parse_buoy_help_coordinates,
    get_recent_buoy_rss_observation,
)
from observation_sources.workflows import (
    create_station_map_screenshot,
    get_valid_station_choice_color,
    find_and_scrape_land_stations_sequentially,
    fetch_functional_buoy_help_candidates,
    build_buoy_help_choice_entries,
    gather_buoy_help_choices,
    resolve_buoy_help_selection,
    validate_buoy_observation_workflow,
    gather_land_station_choices,
    display_station_map_image,
    prepare_land_confirmation_display,
    create_buoy_help_map_screenshot,
    submit_buoy_help_town_workflow,
    submit_buoy_help_coord_workflow,
    submit_buoy_help_near_me_workflow,
)

VERSION = "5.1.2"
        
# --- STARTUP FUNCTIONS ---

def ensure_network_manager_enabled_and_started():
    startup_ensure_network_manager_enabled_and_started()

def get_os_codename():
    return startup_get_os_codename()

def detect_chromium_and_driver():
    return startup_detect_chromium_and_driver()

# --- SCRIPT STARTUP SEQUENCE ---
ensure_network_manager_enabled_and_started()
CHROMIUM_BIN, CHROME_DRIVER_PATH = detect_chromium_and_driver()

# --- HOW TO USE THE DRIVER PATH IN YOUR CODE ---
# In every function where you start Selenium, use the global CHROME_DRIVER_PATH variable.
# The rest of your code does not need to know which path was chosen.
# Example:
#
# def some_function_that_uses_selenium():
#     if not CHROME_DRIVER_PATH:
#         print("ERROR: ChromeDriver path not set. Cannot start browser.")
#         return
#
#     options = Options()
#     options.add_argument(...)
#
#     service = Service(CHROME_DRIVER_PATH)
#     driver = webdriver.Chrome(service=service, options=options)
#     # ...

# This flag signals if a high-demand task is currently running.
# The scheduler will not start a new task until this is False.

TASK_IN_PROGRESS = False

task_queue = [
    'lightning',
    'lcl_radar',
    'reg_sat',
    'sfc_plots',
    'observations',
]

#sys.stdout = sys.stderr = open('/dev/null', 'w') # comment out this line to see output to the console for troubleshooting

IS_X11 = os.environ.get('XDG_SESSION_TYPE', '').lower() == 'x11'
print(f"Detected Session Type: {'X11' if IS_X11 else os.environ.get('XDG_SESSION_TYPE', 'Unknown')}")

def get_location(timeout=5):
    try:
        resp = requests.get('http://ip-api.com/json', timeout=timeout)
        resp.raise_for_status()
        data = resp.json()
    except requests.exceptions.RequestException as e:
        print(f"Location lookup failed: {e}")
        return None

    if data.get('status') != 'success':
        # e.g. “fail” or rate-limited
        print(f"Geolocate API error: {data.get('message', '<no message>')}")
        return None

    return data['lat'], data['lon']

def get_aobs_site(latitude, longitude):
    global baro_input  # Global variable for barometric pressure
    global aobs_site   # Global variable for the name of the town and state
    
    baro_input = None  # Initialize to None or any default value
    
    try:
        # Make the initial API request to get location and station information
        response = requests.get(f'https://api.weather.gov/points/{latitude},{longitude}')
        if response.status_code != 200:
            print("Failed to fetch data from the National Weather Service.")
            return False
        data = response.json()

        try:
            # Extract location information
            location = data['properties']['relativeLocation']['properties']
            town = location['city']
            state = location['state']
            aobs_site = f"{town}, {state}"  # Update global variable with location name
        except Exception as e:
            aobs_site = "Try again later"
            print("not able to assign aobs_site at this time. {e} aobs_site: ", aobs_site)

        # Extract the URL to the nearest observation stations
        stations_url = data['properties']['observationStations']

        # Get the list of nearby weather stations
        response = requests.get(stations_url)
        if response.status_code != 200:
            print("Failed to fetch station list from the National Weather Service.")
            return False
        stations_data = response.json()

        # Loop through the stations to find one with a barometric pressure reading
        for station_url in stations_data['observationStations']:
            try:
                station_observation_response = requests.get(f"{station_url}/observations/latest")
                if station_observation_response.status_code != 200:
                    continue  # Skip if the station's observation data can't be accessed

                observation_data = station_observation_response.json()

                # Attempt to get the barometric pressure
                if 'barometricPressure' in observation_data['properties'] and 'value' in observation_data['properties']['barometricPressure']:
                    barometric_pressure_pascals = observation_data['properties']['barometricPressure']['value']
                    if barometric_pressure_pascals is not None:
                        # Convert to inches of mercury and update the global variable
                        baro_input = pascals_to_inches_hg(barometric_pressure_pascals)
                        return aobs_site
            except Exception as e:
                print(f"Error accessing data for station {station_url}: {e}")
                continue

        # If the loop completes without finding a valid pressure reading
        print(f"Location: {aobs_site}")
        print("No stations with a current barometric pressure reading were found.")
        return False

    except Exception as e:
        print(f"An error occurred: {e}")
        
        try:
            next_button = tk.Button(frame, text="Next", font=error_button_font, command=land_or_buoy)
            next_button.grid(row=4, column=0, padx=(50, 0), pady=10, sticky="w")
        except NameError:
            tk.Button(frame, text="Back", font=error_button_font, command=back_command).grid(row=4, column=0, padx=(50,0), pady=10, sticky="w")

        #return False
        
location = get_location()
if location is None:
    print("Could not resolve latitude/longitude")
else:
    latitude, longitude = location
    aobs_site = get_aobs_site(latitude, longitude)

# Establish keys for secrets
ACCESS_TOKEN = ""
API_SECRET_TOKEN = ""
EMAIL_PASSWORD_CODE = ""
FULLSCREEN_BREAK_PASSWORD = ""
IG_USER_ID = ""
#MESOWEST_API_TOKEN = ""
PAGE_ACCESS_TOKEN = ""
PAGE_ID = ""

# Define the URL for getting secrets
SERVER_URL_SECRETS = "https://weatherobserver.duckdns.org/api/get_secrets"

secrets_data = load_remote_secrets(
    logging,
    SERVER_URL_SECRETS,
)
api_key = secrets_data["api_key"]
ACCESS_TOKEN = secrets_data["ACCESS_TOKEN"]
API_SECRET_TOKEN = secrets_data["API_SECRET_TOKEN"]
EMAIL_PASSWORD_CODE = secrets_data["EMAIL_PASSWORD_CODE"]
FULLSCREEN_BREAK_PASSWORD = secrets_data["FULLSCREEN_BREAK_PASSWORD"]
IG_USER_ID = secrets_data["IG_USER_ID"]
PAGE_ACCESS_TOKEN = secrets_data["PAGE_ACCESS_TOKEN"]
PAGE_ID = secrets_data["PAGE_ID"]

#--- End of section to fetch secrets ---

# --- Fetch Land Station Metadata from Server ---
# --- Land Station Metadata ---
ALL_STATIONS_CACHE = None
RANDOM_CANDIDATE_STATIONS_CACHE = None # to hold list of stations near home location to draw random sites from
RANDOM_CANDIDATE_STATIONS_20_CACHE = None # narrower precomputed pool for the first random-site search radius
RANDOM_CANDIDATE_CACHE_LOCATION = None
ALL_STATIONS_CACHE_DICTS = None
ALL_BUOY_CACHE = None
logging.info("Attempting to fetch land station metadata from server...")
try:
    pp_land_stations_url = "https://weatherobserver.duckdns.org/data/stations_metadata.json"
    pp_local_land_path = "/home/santod/stations_metadata.json"
    pp_headers = {'X-API-Key': api_key}

    response = requests.get(pp_land_stations_url, headers=pp_headers, timeout=60)
    response.raise_for_status()

    data = response.json()

    # --- ADD THIS DIAGNOSTIC BLOCK ---
    print("\n---- DIAGNOSTIC START ----")
    print(f"The 'data' variable received from the server is a: {type(data)}")
    if isinstance(data, list):
        print(f"The list contains {len(data)} items.")
        if len(data) > 0:
            print("Checking the keys of the FIRST item in the list:")
            first_item_keys = data[0].keys()
            print(f"  Keys found: {list(first_item_keys)}")
            
            required_keys = {"id", "name", "latitude", "longitude", "state"}
            missing_keys = required_keys - set(first_item_keys)
            if missing_keys:
                print(f"  [PROBLEM] The first item is MISSING required keys: {missing_keys}")
            else:
                print("  [OK] The first item seems to have all required keys.")
    else:
        print("The data received is NOT a list. Here is what was received:")
        print(data)
    print("---- DIAGNOSTIC END ----\n")
    # --- END OF DIAGNOSTIC BLOCK ---

    # Save the received data to a local file
    with open(pp_local_land_path, 'w') as f:
        json.dump(data, f)

    # Prime cache with dicts
    ALL_STATIONS_CACHE = [
        s for s in data
        if all(k in s for k in ("id", "name", "latitude", "longitude", "state"))
    ]

    # ADD THIS DIAGNOSTIC LINE HERE:
    print(f"DIAGNOSTIC CHECK: Immediately after creation, ALL_STATIONS_CACHE has {len(ALL_STATIONS_CACHE)} stations.")

    logging.info(f"Successfully downloaded and saved land station metadata to {pp_local_land_path}")
    print("line 451. successfully downloaded and saved land station metadata.")
    
except requests.exceptions.RequestException as e:
    logging.error(f"Error fetching land station metadata: {e}")
    ALL_STATIONS_CACHE = []

# --- Buoy Metadata ---
logging.info("Attempting to fetch buoy metadata from server...")
try:
    pp_buoy_stations_url = "https://weatherobserver.duckdns.org/data/buoy_metadata.json"
    pp_local_buoy_path = "/home/santod/buoy_metadata.json"
    pp_headers = {'X-API-Key': api_key}

    response = requests.get(pp_buoy_stations_url, headers=pp_headers, timeout=15)
    response.raise_for_status()

    data = response.json()

    # Save the received data to a local file
    with open(pp_local_buoy_path, 'w') as f:
        json.dump(data, f)

    # Prime cache with dicts
    ALL_BUOYS_CACHE = [
        s for s in data
        if all(k in s for k in ("id", "name", "latitude", "longitude"))
    ]

    logging.info(f"Successfully downloaded and saved buoy metadata to {pp_local_buoy_path}")
    print("line 471. successfully downloaded buoy metadata.")
except requests.exceptions.RequestException as e:
    logging.error(f"Error fetching buoy metadata: {e}")
    ALL_BUOYS_CACHE = []


#... (Rest of your TWO program logic continues here, using the fetched secrets) ...

def check_lcl_radar_map_available():
    print("line 478. inside check lcl radar map available.")
    lcl_radar_map_path = "/home/santod/lcl_radar_map.png"
    lcl_radar_metadata_path = "/home/santod/lcl_radar_metadata.json"
    return os.path.exists(lcl_radar_map_path) and os.path.exists(lcl_radar_metadata_path)

def display_lcl_radar_error_gui(error_message):
    """
    Display a GUI error message if the radar map is not available.
    """
    root = tk.Tk()
    root.title("Error")
    label = tk.Label(root, text=f"Error: {error_message}\nLocal radar map will not be available.",
                        font=("Arial", 16), wraplength=400, justify="center")
    label.pack(padx=20, pady=20)
    button = tk.Button(root, text="OK", command=root.destroy, font=("Helvetica", 14))
    button.pack(pady=10)
    root.mainloop()

def graceful_exit(signum, frame):
    print("[INFO] Program interrupted. Cleaning up...")

    # Perform any cleanup tasks here
    kill_orphaned_chrome()  # Kill any lingering Chrome processes
    gc.collect()  # Force garbage collection

    print("[INFO] Cleanup complete. Exiting...")
    
    root.quit()  # Exit the Tkinter main loop
    sys.exit(0)

# Register the signal handler for SIGINT (Ctrl+C)
signal.signal(signal.SIGINT, graceful_exit)

tracemalloc.start()

# Global variable to store the background event loop
background_loop = None

start_background_event_loop(globals(), asyncio, threading)

# --- CPU Lull Detection System ---

# 1. Add this new global variable at the top of your script with your others.
CPU_IS_IDLE = False

def cpu_lull_monitor():
    scheduler_cpu_lull_monitor(globals(), psutil)

def start_cpu_monitor():    
    scheduler_start_cpu_monitor(globals(), psutil)

start_cpu_monitor()

# Initialize variables for swipe functionality
start_x = None
start_y = None
debounce_timer = None

# Optional improvement for on_touch_start: Cancel any existing debounce
# This handles cases where a new touch happens before the old debounce finished
def on_touch_start(event):
    display_on_touch_start(event, globals(), root)

def handle_swipe(event):
    display_handle_swipe(
        event,
        globals(),
        root,
        on_right_swipe,
        on_left_swipe,
        auto_advance_frames,
        IS_X11,
        time,
    )

last_monitor_check = None # Global variable to track last monitoring time

def log_memory_snapshot():
    snapshot = tracemalloc.take_snapshot()
    top_stats = snapshot.statistics('lineno')
    #print("[Top 10 Memory Consumers]")
    #for stat in top_stats[:10]:
        #print(stat)

# Helper function to kill orphaned Chrome/WebDriver processes
def kill_orphaned_chrome():
    try:
        os.system("pkill -f chrome")
    except Exception as e:
        print("Error cleaning up Chrome processes:", e)

def force_gc_and_log():
    freed_objects = gc.collect()
    print(f"Garbage collection completed. Objects collected: {freed_objects}")
    
def log_memory_usage():
    process = psutil.Process()
    mem_info = process.memory_info()
    print(f"Memory Usage: {mem_info.rss / 1024 / 1024:.2f} MB (RSS), {mem_info.vms / 1024 / 1024:.2f} MB (VMS)")

# Code begins to find and prepare lcl radar choice map to get user's choice
def load_lcl_radar_map(): # Modified to return True/False
    #print("line 721. inside load lcl radar map.")
    lcl_radar_map_path = "/home/santod/lcl_radar_map.png"
    lcl_radar_metadata_path = "/home/santod/lcl_radar_metadata.json"
    SERVER_DUCKDNS = "weatherobserver.duckdns.org"
    lcl_radar_map_url = f"https://{SERVER_DUCKDNS}/~santod/radar_map_data/lcl_radar_map.png"
    lcl_radar_metadata_url = f"https://{SERVER_DUCKDNS}/~santod/radar_map_data/lcl_radar_metadata.json"

    if os.path.exists(lcl_radar_map_path) and os.path.exists(lcl_radar_metadata_path):
        print("Local radar map data found by load_lcl_radar_map.")
        # Optional: Could add validation here too, return False if invalid
        return True # Files exist
    else:
        print("Local radar map data not found by load_lcl_radar_map. Downloading...")
        try:
            # Download map image
            map_response = requests.get(lcl_radar_map_url, stream=True, timeout=15)
            map_response.raise_for_status()
            with open(lcl_radar_map_path, 'wb') as map_file:
                for chunk in map_response.iter_content(chunk_size=8192): map_file.write(chunk)
            print("Radar map image downloaded successfully.")

            # Download metadata
            metadata_response = requests.get(lcl_radar_metadata_url, timeout=15)
            metadata_response.raise_for_status()
            # Save metadata directly (no need to load into variable here)
            with open(lcl_radar_metadata_path, "w") as metadata_file:
                 metadata_file.write(metadata_response.text) # Write raw text
            print("Radar metadata downloaded successfully.")
            return True # Download succeeded

        except requests.exceptions.RequestException as e:
            print(f"Error downloading radar map data: {e}")
            return False
        except Exception as e:
            print(f"An unexpected error occurred during download: {e}")
            # Clean up potentially partial files on error?
            if os.path.exists(lcl_radar_map_path): os.remove(lcl_radar_map_path)
            if os.path.exists(lcl_radar_metadata_path): os.remove(lcl_radar_metadata_path)
            return False

def initialize_lcl_radar_map():
    lcl_radar_map_path = "/home/santod/lcl_radar_map.png"
    lcl_radar_metadata_path = "/home/santod/lcl_radar_metadata.json"

    if os.path.exists(lcl_radar_map_path) and os.path.exists(lcl_radar_metadata_path):
        print("Local radar map data found during initialization.")
        return True  # Indicate success (local files exist)
    else:
        print("Local radar map data not found during initialization. Attempting download.")
        success = load_lcl_radar_map() # Assuming load_lcl_radar_map now returns True/False
        if success:
            print("Radar map data downloaded successfully during initialization.")
            return True
        else:
            print("Failed to load or download radar map data during initialization.")
            return False

initialize_lcl_radar_map()

lcl_radar_map_unavailable = not check_lcl_radar_map_available()
if lcl_radar_map_unavailable:
    display_lcl_radar_error_gui("Local radar map data not found.")
else:
    pass
    print("Local radar map data found during initialization.")

# Create xs and ys this early because some startup paths check len(xs)
BAROGRAPH_HISTORY_PATH = os.path.expanduser("~/barograph_history.json")
xs, ys = load_barograph_history(datetime, BAROGRAPH_HISTORY_PATH)

# Proceed with the rest of your program
print("Starting main program...")

#ALL_STATIONS_CACHE = None        # list of (id,name,lat,lon,state)
BUOY_METADATA_CACHE = None       # raw list of buoy dicts
BUOY_ID_SET_CACHE = None         # set of buoy ids

# Define a fixed path for the screenshot
SCREENSHOT_PATH = '/home/santod/screenshot.png'
screenshot_filename = 'screenshot.png'   

RANDOM_NWS_API_ENDPOINT = "https://api.weather.gov"
RANDOM_NWS_API_STATIONS_ENDPOINT = f"{RANDOM_NWS_API_ENDPOINT}/stations"
RANDOM_NWS_API_LATEST_OBSERVATION_ENDPOINT = f"{RANDOM_NWS_API_ENDPOINT}/stations/{{station_id}}/observations/latest"

random_map_label = None # to manage the cleaning up of random site map 10/1/25
random_map_placeholder_label = None
random_map_container = None

neighboring_states = {
    "ME": ["NH"],
    "NH": ["ME", "VT", "MA"],
    "VT": ["NH", "MA", "NY"],
    "MA": ["NH", "VT", "NY", "CT", "RI"],
    "RI": ["MA", "CT"],
    "CT": ["MA", "RI", "NY"],
    "NY": ["VT", "MA", "CT", "NJ", "PA"],
    "NJ": ["NY", "PA", "DE"],
    "PA": ["NY", "NJ", "DE", "MD", "WV", "OH"],
    "DE": ["PA", "NJ", "MD"],
    "MD": ["PA", "DE", "WV", "VA", "DC"],
    "DC": ["MD", "VA"],
    "VA": ["MD", "WV", "KY", "TN", "NC", "DC"],
    "WV": ["PA", "MD", "VA", "KY", "OH"],
    "NC": ["VA", "TN", "GA", "SC"],
    "SC": ["NC", "GA"],
    "GA": ["NC", "SC", "FL", "AL", "TN"],
    "FL": ["GA", "AL"],
    "AL": ["TN", "GA", "FL", "MS"],
    "TN": ["KY", "VA", "NC", "GA", "AL", "MS", "AR", "MO"],
    "KY": ["WV", "VA", "TN", "MO", "IL", "IN", "OH"],
    "OH": ["PA", "WV", "KY", "IN", "MI"],
    "MI": ["OH", "IN", "WI"],
    "IN": ["MI", "OH", "KY", "IL"],
    "IL": ["WI", "IN", "KY", "MO", "IA"],
    "WI": ["MI", "IL", "IA", "MN"],
    "MN": ["WI", "IA", "SD", "ND"],
    "IA": ["MN", "WI", "IL", "MO", "NE", "SD"],
    "MO": ["IA", "IL", "KY", "TN", "AR", "OK", "KS", "NE"],
    "AR": ["MO", "TN", "MS", "LA", "TX", "OK"],
    "LA": ["AR", "MS", "TX"],
    "MS": ["TN", "AL", "LA", "AR"],
    "TX": ["OK", "AR", "LA", "NM"],
    "OK": ["KS", "MO", "AR", "TX", "NM", "CO"],
    "KS": ["NE", "MO", "OK", "CO"],
    "NE": ["SD", "IA", "MO", "KS", "CO", "WY"],
    "SD": ["ND", "MN", "IA", "NE", "WY", "MT"],
    "ND": ["MN", "SD", "MT"],
    "MT": ["ND", "SD", "WY", "ID"],
    "WY": ["MT", "SD", "NE", "CO", "UT", "ID"],
    "CO": ["WY", "NE", "KS", "OK", "NM", "UT"],
    "NM": ["CO", "OK", "TX", "AZ", "UT"],
    "AZ": ["CA", "NV", "UT", "NM"],
    "UT": ["ID", "WY", "CO", "NM", "AZ", "NV"],
    "NV": ["ID", "UT", "AZ", "CA", "OR"],
    "ID": ["MT", "WY", "UT", "NV", "OR", "WA"],
    "OR": ["WA", "ID", "NV", "CA"],
    "WA": ["ID", "OR"],
    "CA": ["OR", "NV", "AZ"],
    "AK": [],
    "HI": [],
}


def load_all_stations_cached_dicts(path="/home/santod/stations_metadata.json"):
    global ALL_STATIONS_CACHE_DICTS
    if ALL_STATIONS_CACHE_DICTS is not None:
        return ALL_STATIONS_CACHE_DICTS
    with open(path) as f:
        data = json.load(f)
    ALL_STATIONS_CACHE_DICTS = [
        s for s in data
        if all(k in s for k in ("id","name","latitude","longitude","state"))
    ]
    return ALL_STATIONS_CACHE_DICTS

def load_buoy_metadata_cached(path="/home/santod/buoy_metadata.json"):
    global ALL_BUOY_CACHE
    
    # 1. Create a helper function/block to process the raw data
    def process_buoy_data(data_list):
        """Processes the list of buoy dictionaries into the required formats."""
        # The list of buoy dictionaries (used by find_buoy_help_nearest)
        all_buoys = data_list
        
        # The set of buoy IDs (used for fast lookup)
        buoy_id_set = {b["id"] for b in all_buoys if "id" in b}
        
        # *** NEW: The coordinate map dictionary (used by find_buoy_choice for the final output)
        buoy_coord_map = {
            b["id"]: (b["latitude"], b["longitude"])
            for b in all_buoys
            if "id" in b and "latitude" in b and "longitude" in b
        }
        
        # We now return three items
        return all_buoys, buoy_id_set, buoy_coord_map

    # 2. Check the Cache
    if ALL_BUOY_CACHE is not None:
        # If the cache is primed (it's a list of dictionaries), return the processed formats
        print("Using cached buoy metadata.")
        return process_buoy_data(ALL_BUOY_CACHE)
        
    # 3. Load from File
    print(f"Loading buoy metadata from file: {path}")
    with open(path) as f:
        data = json.load(f)
        
    # 4. Prime the Cache and Return
    ALL_BUOY_CACHE = data
    return process_buoy_data(ALL_BUOY_CACHE)

# Initialize the global image dictionary
available_image_dictionary = {}

last_displayed_index = -1

# Global list of image keys
image_keys = [
    "baro_img", "national_radar_img", "lcl_radar_loop_img", 
    "lightning_img", "still_sat_img", "reg_sat_loop_img", 
    "national_sfc_img", "sfc_plots_img", "radiosonde_img", 
    "vorticity_img", "storm_reports_img",  # Add more keys as needed
]

num_frames = len(image_keys)

state_entry_widgets = {} # to manage two consecutive uppercase letter entries when asked for state IDs
is_buoy_code = False # set to manage upper and lower cases on keyboard

aobs_station_identifier = ""
bobs_station_identifier = ""
cobs_station_identifier = ""
a_town_state = ""
b_town_state = ""
c_town_state = ""

# added to manage as a flag the frequency of scraping updates
atemp = ""
awtemp = ""
awind = ""
btemp = ""
bwtemp = ""
bwind = ""
ctemp = ""
cwtemp = ""
cwind = ""

# Global storage for reg_sat frames in memory to implement swiping 1/13/25
reg_sat_frames = []
sat_reg = 'unknown' # for placing different sized reg_sat loops
reg_sat_animation_id = None #added to manage reg sat loop 1/22/25
REG_SAT_ANIM_GEN = 0 # to manage playback of loop after change with PIL and PhotoImage 8/11/25

# Create buttons with custom font size (adjust font size as needed)
button_font = ("Helvetica", 16, "bold")

global inHg_correction_factor
inHg_correction_factor = 1

global create_virtual_keyboard

current_target_entry = None  # This will hold the currently focused entry widget

# Global declaration of page_choose_choice_vars according to rewriting 3/27/24
page_choose_choice_vars = []
PAGE_CHOOSE_SCREEN_CACHE = None
box_variables = [0] * 12

# Initialize hold_box_variables with 0 for the first ten indices
hold_box_variables = [0] * 12  # Creates a list with ten zeros

# Global variable declaration for email functions
global email_entry
email_entry = None

last_land_scrape_time = None # use this to manage update frequency of land obs sites

cobs_only_click_flag = False #set up for buttons to change 1 posted obs at a time
bobs_only_click_flag = False
aobs_only_click_flag = False
frame1_overlay_lock = False

refresh_flag = False
# to determine if user has chosen reg sat view
has_submitted_choice = False

# to signal if user has chosen random sites
random_sites_flag = False

lightning_near_me_flag = False # to manage user choice of lightning map

submit_station_plot_center_near_me_flag = False # to manage user choice of sfc plots

show_frame_call_count = 0 # for debugging frame displays while developing swiping
auto_advance_timer = None # for controlling display of images while user is at another frame
update_images_timer = None # Global variable to track the update_images timer
barograph_update_timer = None
barograph_update_iteration = 0
barograph_started = False

lcl_radar_updated_flag = False # to manage when lcl radar is updated
lcl_radar_animation_id = None # Variable to track the lcl radar animation loop
lcl_radar_url = None # Initialize lcl_radar_url globally
lcl_radar_frames = [] # to hold scraped lcl radar images

reg_sat_updated_flag = False # to manage display of reg sat loop
#calc_padding = "" # to manage cropping frames of regsat loop
REG_SAT_SCREEN_CACHE = None

executor = ThreadPoolExecutor(max_workers=1) # manage asyncio for if there's a more recent lcl radar

# flag established to track whether img_label_national_radar is forgotten to smooth displays
national_radar_hidden = False

extremes_flag = False
reboot_shutdown_flag = False

radiosonde_updated_flag = False
# variables used in extremes functions
# Counters for tracking observations
initial_successful_fetches = 0
successful_metar_parse = 0
successful_retries = 0

aobs_buoy_code = bobs_buoy_code = cobs_buoy_code = ""
aobs_buoy_signal = bobs_buoy_signal = cobs_buoy_signal = False
buoy_help_flag = None # to manage progression through obs choices after user has asked for help with buoy codes

# Global variables for images
#img_tk_national_radar = None
img_label_national_radar = None
img_label_lg_still_satellite = None
img_label_satellite = None
baro_img_label = None

img_label = None # added 7/11/24 while working on saving dead end runs. Lightning & Station plots

label_lcl_radar = None # to manage transition from ntl radar to lightning this had to be defined too

# variables used to manage updates with swiping 1/3/25
# Initialize last update times
last_baro_update = None
last_baro_chart_update = None
last_radar_update = None
last_lcl_radar_update = None
last_lightning_update = None
last_national_sfc_update = None
last_vorticity_update = None
last_satellite_update = None
last_still_sat_update = None
last_reg_sat_update = None
last_sfc_plots_update = None
last_radiosonde_update = None
last_radiosonde_update_check = None # this variable holds when the code last checked for an update, to monitor 00Z and 12Z
last_vorticity_update
last_storm_reports_update = None

satellite_idx = 0  # Initialize satellite index globally

# set GUI buttons to None
scraped_to_frame1 = None
maps_only_button = None
pic_email_button = None
reboot_button = None
extremes_button = None

message_label = None #this is to message user when chosen lcl radar isn't functioning

# for lightning display when scraped with selenium
lightning_max_retries = 2

global lightning_scraping_in_progress # added 8/31/25 to prevent backed up requests to scrape
lightning_scraping_in_progress = False

last_forget_clock = datetime.now()

i = 0

alternative_town_1 = ""
alternative_state_1 = ""

alternative_town_2 = ""
alternative_state_2 = ""

alternative_town_3 = ""
alternative_state_3 = ""

def monitor_system_health():
    global last_monitor_check, LAST_DISPLAY_FRAME_RESET_TIME
    current_time = datetime.now()

    # Run check every 5 minutes
    if last_monitor_check is None or (current_time - last_monitor_check) >= timedelta(minutes=5):
        last_monitor_check = current_time  # Update last check time

        #print("[MONITOR] Running system health check...")

        # --- NEW: Step 1: Force Garbage Collection ---
        # This is a good practice for long-running applications to manually
        # clean up any memory that might not have been released automatically.
        try:
            #print("[MONITOR] Forcing garbage collection...")
            collected_count = gc.collect()
            #print(f"[MONITOR] Garbage collector freed {collected_count} objects.")
        except Exception as e:
            print(f"[MONITOR] An error occurred during garbage collection: {e}")
        # --- END OF NEW LOGIC ---

        # Step 2: Check if WiFi is up
        try:
            subprocess.run(["ping", "-c", "1", "google.com"], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            network_up = True
        except subprocess.CalledProcessError:
            network_up = False

        if not network_up:
            print("[MONITOR] WiFi is down. Restarting network and clearing headless Chrome instances...")

            # Kill only headless Chromium processes
            try:
                ps_output = subprocess.check_output(["ps", "aux"], text=True)
                for line in ps_output.strip().split("\n"):
                    if "chromium" in line and "--headless" in line:
                        parts = line.split()
                        if len(parts) >= 2 and parts[1].isdigit():
                            pid = parts[1]
                            print(f"[MONITOR] Killing headless Chrome PID {pid} due to WiFi failure.")
                            subprocess.run(["sudo", "kill", "-9", pid], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except subprocess.CalledProcessError:
                pass
                #print("[MONITOR] No headless Chromium processes found.")

            # Restart NetworkManager
            subprocess.run(["sudo", "systemctl", "restart", "NetworkManager"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return

        # Step 3: Find only headless Chromium processes
        chrome_pids = []
        try:
            ps_output = subprocess.check_output(["ps", "aux"], text=True)
            for line in ps_output.strip().split("\n"):
                if "chromium" in line and "--headless" in line:
                    parts = line.split()
                    if len(parts) >= 2 and parts[1].isdigit():
                        chrome_pids.append(parts[1])
        except subprocess.CalledProcessError:
            pass

        # Step 4: Check runtime for each Chrome instance
        def get_process_runtime(pid):
            try:
                secs = int(subprocess.check_output(["ps", "-o", "etimes=", "-p", pid], text=True).strip())
                return secs // 60
            except subprocess.CalledProcessError:
                return None

        stuck_pids = []
        for pid in chrome_pids:
            runtime = get_process_runtime(pid)
            if runtime and runtime >= 5:
                #print(f"[MONITOR] Chrome PID {pid} running for {runtime} minutes. Marked for termination.")
                stuck_pids.append(pid)
        
        # NOTE: The file descriptor check was removed for simplicity as the runtime
        # check is the most critical part for preventing CPU exhaustion.

        # Step 5: Kill stuck processes
        if stuck_pids:
            #print(f"[MONITOR] Killing {len(stuck_pids)} Chrome instances: {', '.join(stuck_pids)}")
            for pid in stuck_pids:
                subprocess.run(["sudo", "kill", "-9", pid], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                
        # Step 6: Kill orphaned chromedriver processes (more than 5 minutes old)
        try:
            driver_pids = subprocess.check_output(["pgrep", "-f", "chromedriver.*--port"], text=True).strip().split("\n")
            driver_pids = [pid for pid in driver_pids if pid.isdigit()]
            
            for pid in driver_pids:
                runtime = get_process_runtime(pid)
                if runtime and runtime >= 5:
                    #print(f"[MONITOR] ChromeDriver PID {pid} running for {runtime} minutes. Killing it.")
                    subprocess.run(["sudo", "kill", "-9", pid], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        except subprocess.CalledProcessError:
            pass  # No chromedriver processes found
            
        #7 Step 7: destroy/recreate display frame
        if datetime.now() - LAST_DISPLAY_FRAME_RESET_TIME > timedelta(minutes=62):
            recreate_display_image_frame()
            LAST_DISPLAY_FRAME_RESET_TIME = datetime.now()

    else:
        pass

def reboot_system():
    root.quit()
    os.system('sudo reboot')
    
def shutdown_system():
    root.quit()
    os.system('sudo shutdown now')
    
def toggle_fullscreen(event=None):
    """Toggles the Tkinter window's fullscreen state."""
    global fullscreen_state
    # Invert the current state (True becomes False, False becomes True)
    fullscreen_state = not fullscreen_state
    root.attributes("-fullscreen", fullscreen_state)

def check_password(event):
    """Checks the typed key sequence against the password."""
    global key_sequence
    # Ignore modifier keys and only append character keys
    if event.char:
        key_sequence += event.char

    # Define your password. This can be a hardcoded default or a variable
    # fetched from your server, like FULLSCREEN_BREAK_PASSWORD.
    password = '2barbaraterminal'

    # Check if the correct sequence was entered
    if key_sequence.endswith(password):
        toggle_fullscreen()  # Call the new toggle function
        key_sequence = ''    # Reset sequence after a successful entry
    elif len(key_sequence) > len(password):
        # Keep the sequence from getting too long to save memory
        key_sequence = key_sequence[-len(password):]

def start_fullscreen():
    """Initializes the window to a fullscreen state."""
    global fullscreen_state
    root.geometry("1024x600")
    root.title("The Weather Observer")
    root.attributes('-fullscreen', True)
    fullscreen_state = True # Set the initial state to True

# --- Main Setup ---

# Create a tkinter window
root = tk.Tk()
root.title("The Weather Observer")
root.geometry("1024x576+0+-1")

# Initialize state and sequence variables
key_sequence = ''
fullscreen_state = False # Default state before fullscreen starts

# Bind all keypresses to the check_password function
root.bind('<Key>', check_password)

# Set up fullscreen after a startup delay, as before.
root.after(4000, start_fullscreen)

lcl_radar_zoom_clicks = tk.IntVar(value=0) # establish variable for zoom on lcl radar

# Define StringVar for labels
left_site_text = tk.StringVar()
left_temp_text = tk.StringVar()
left_water_temp_text = tk.StringVar()
left_wind_text = tk.StringVar()
left_combined_text = tk.StringVar()

middle_site_text = tk.StringVar()
middle_temp_text = tk.StringVar()
middle_water_temp_text = tk.StringVar()
middle_wind_text = tk.StringVar()
middle_combined_text = tk.StringVar()

right_site_text = tk.StringVar()
right_temp_text = tk.StringVar()
right_water_temp_text = tk.StringVar()
right_wind_text = tk.StringVar()
right_combined_text = tk.StringVar()

timestamp_text = tk.StringVar()

persistent_widgets = {} # used to manage reusable widgets in transparent frame

# Use a smaller font for the buoys
buoy_font = font.Font(family="Helvetica", size=11, weight="bold")

# Use the default font size (14) for the regular condition when posting observations
obs_font = font.Font(family="Helvetica", size=14, weight="bold")

# Set the background color in Tkinter to light blue
tk_background_color = "lightblue"
root.configure(bg=tk_background_color)

# Create a dedicated orb canvas on the left and a separate observation-button canvas on the right
ROOT_CORNER_CANVAS = tk.Canvas(root, bg=tk_background_color, bd=0, highlightthickness=0, width=158, height=158)
transparent_frame = tk.Canvas(root, bg=tk_background_color, bd=0, highlightthickness=0, width=886, height=75)


def raise_transparent_canvas_widget():
    try:
        transparent_frame.tk.call('raise', transparent_frame._w)
    except Exception:
        pass


def show_transparent_frame_overlay():
    ROOT_CORNER_CANVAS.place(x=-24, y=-34, width=158, height=158)
    transparent_frame.place(x=138, y=0, width=886, height=75)
    raise_transparent_canvas_widget()
    raise_root_corner_logo()

# Create a Matplotlib figure and axis
fig = Figure(figsize=(12.5, 6))
ax = fig.add_subplot(1, 1, 1)

# Set the background color of matplotlib to match Tkinter
fig.patch.set_facecolor(tk_background_color)

# Create a frame for the barograph
baro_frame = tk.Frame(root, width=12.5, height=6)

# Embed the Matplotlib figure in a tkinter frame
canvas = FigureCanvasTkAgg(fig, master=baro_frame)
canvas_widget = canvas.get_tk_widget()
# Use next line to position matplotlib in window. pady pushes inmage down from top
canvas_widget.grid(row=1, column=0, padx=(20,0), pady=15, sticky="s")

# Set the background color of the frame to light blue
baro_frame.configure(bg=tk_background_color)

# Create main user GUI frame
frame1 = tk.Frame(root, bg=tk_background_color)
frame1.grid(row=0, column=0)
root.grid_rowconfigure(0, weight=1)
root.grid_columnconfigure(0, weight=1)

def reboot_shutdown_option_display():
    global reboot_shutdown_flag, timestamp_text, refresh_flag
    
    reboot_shutdown_flag = refresh_flag = True
    
    reset_for_frame1_display(
        frame1,
        root,
        forget_all_frames,
        transparent_frame=transparent_frame,
        baro_frame=baro_frame,
        function_button_frame=function_button_frame,
        destroy_all=True,
        row_weight=0,
        column_weight=0,
        geometry='1024x600',
    )

    logo_font = font.Font(family="Helvetica", size=16, weight="bold")
    logo_label = tk.Label(frame1, text="The\nWeather\nObserver", fg="black", bg=tk_background_color, font=logo_font, anchor="w", justify="left")
    logo_label.grid(row=0, column=0, padx=10, pady=5, sticky='w')

    time_stamp_font = font.Font(family="Helvetica", size=8, weight="normal", slant="italic")
    timestamp_label = tk.Label(frame1, textvariable=timestamp_text, fg="black", bg=tk_background_color, font=time_stamp_font, anchor="w", justify="left")
    timestamp_label.grid(row=0, column=0, padx=120, pady=(17, 5), sticky='w')
    
    instructions_label = tk.Label(frame1, text=f"Please choose to REBOOT, SHUTDOWN, or RETURN to images", font=("Helvetica", 14), bg=tk_background_color, justify="left")
    instructions_label.grid(row=1, column=0, columnspan=2, padx=50, pady=50, sticky='nw')
    
    # Create the 'Back' button
    reboot_button = tk.Button(frame1, text=" Reboot ", font=button_font, command=reboot_system)
    reboot_button.grid(row=1, column=0, columnspan=20, padx=(50, 0), pady=100, sticky="w")

    shutdown_button = tk.Button(frame1, text="Shutdown", command=shutdown_system, font=button_font)
    shutdown_button.grid(row=1, column=0, columnspan=20, padx=200, pady=100, sticky='nw')
    
    return_button = tk.Button(frame1, text="Return", command=return_to_image_cycle, font=button_font)
    return_button.grid(row=1, column=0, columnspan=20, padx=360, pady=100, sticky='nw')

def process_obs_data_queue():
    """
    Drain all pending results each tick. Apply only to the *current* A/B/C
    selections. Discard stale keys so the queue cannot backlog.
    """
    try:
        updated_any = False
        while True:
            try:
                result_dict = data_update_queue.get_nowait()
            except Empty:
                break  # queue fully drained

            # A
            if not aobs_buoy_signal and aobs_station_identifier and aobs_station_identifier in result_dict:
                atemp, awind = result_dict[aobs_station_identifier]
                globals()['atemp'], globals()['awind'] = atemp, awind
                updated_any = True
            elif aobs_buoy_signal and aobs_buoy_code and aobs_buoy_code in result_dict:
                atemp, awtemp, awind = result_dict[aobs_buoy_code]
                globals()['atemp'], globals()['awtemp'], globals()['awind'] = atemp, awtemp, awind
                updated_any = True

            # B
            if not bobs_buoy_signal and bobs_station_identifier and bobs_station_identifier in result_dict:
                btemp, bwind = result_dict[bobs_station_identifier]
                globals()['btemp'], globals()['bwind'] = btemp, bwind
                updated_any = True
            elif bobs_buoy_signal and bobs_buoy_code and bobs_buoy_code in result_dict:
                btemp, bwtemp, bwind = result_dict[bobs_buoy_code]
                globals()['btemp'], globals()['bwtemp'], globals()['bwind'] = btemp, bwtemp, bwind
                updated_any = True

            # C
            if not cobs_buoy_signal and cobs_station_identifier and cobs_station_identifier in result_dict:
                ctemp, cwind = result_dict[cobs_station_identifier]
                globals()['ctemp'], globals()['cwind'] = ctemp, cwind
                updated_any = True
            elif cobs_buoy_signal and cobs_buoy_code and cobs_buoy_code in result_dict:
                ctemp, cwtemp, cwind = result_dict[cobs_buoy_code]
                globals()['ctemp'], globals()['cwtemp'], globals()['cwind'] = ctemp, cwtemp, cwind
                updated_any = True

        # Optional: refresh UI only if something changed
        if updated_any:
            try:
                update_transparent_frame_data()
            except Exception:
                pass

    except Exception as e:
        print(f"Error processing data update queue: {e}")
    finally:
        frame1.after(100, process_obs_data_queue)

# This ensures the queue processor is started only once.
if 'queue_processor_started' not in globals() or not queue_processor_started:
    #print("[INFO] Starting the background data queue processor...")
    process_obs_data_queue()
    queue_processor_started = True

# Create frame for function buttons and a function to display it
function_button_frame = tk.Frame(root, bg=tk_background_color, bd=0, highlightthickness=0)

display_label = None

# Create the display_image_frame
display_image_frame = tk.Frame(root, width=950, height=515, bg=tk_background_color, bd=0)  # , highlightthickness=0)
display_image_frame.grid(row=0, column=0, padx=(140,0), pady=(75,0), sticky="sw")
display_image_frame.grid_propagate(False)

# Configure resizing behavior for the root window and frame
root.grid_rowconfigure(0, weight=0)
root.grid_columnconfigure(0, weight=0)

# Create the display_label inside the frame
display_label = tk.Label(display_image_frame, bg=tk_background_color, bd=0, highlightthickness=0)
display_label.grid(row=0, column=0, padx=70, pady=(0,0), sticky="sw")

DISPLAY_FRAME_RESET_IN_PROGRESS = False
LAST_DISPLAY_FRAME_RESET_TIME = datetime.now() - timedelta(days=1)


def build_function_button_footer_text():
    update_source = last_baro_chart_update or getattr(barograph_image_module, "last_baro_update", None)
    if update_source:
        update_text = update_source.strftime("%a %-I:%M%P")
    else:
        update_text = "--"
    return f"Version {VERSION}\nLast updated\n{update_text}"

def setup_function_button_frame():
    global scraped_to_frame1, maps_only_button, extremes_button, pic_email_button, reboot_button, version_footer_label

    root.grid_rowconfigure(0, weight=0)
    root.grid_columnconfigure(0, weight=0)
    
    shared_font = ("Helvetica Neue", 9, "bold")
    scraped_to_frame1 = create_modern_button(function_button_frame, tk, " Change\nObservation\n Sites &\nMaps", refresh_choices, font=shared_font, variant="secondary")
    maps_only_button = create_modern_button(function_button_frame, tk, " \n Change\n  Maps Only \n", change_maps_only, font=shared_font, variant="secondary")
    extremes_button = create_modern_button(function_button_frame, tk, ' \n   Display  \n  Extremes  \n', find_and_display_extremes, font=shared_font, variant="secondary")
    pic_email_button = create_modern_button(function_button_frame, tk, " \n  Share a \n Screenshot \n", show_fb_login_screen, font=shared_font, variant="secondary")
    reboot_button = create_modern_button(function_button_frame, tk, "  Reboot/ \n  Shutdown \n", reboot_shutdown_option_display, font=shared_font, variant="secondary")
    version_footer_label = tk.Label(function_button_frame, text=build_function_button_footer_text(), font=("Helvetica Neue", 8), fg="black", bg=tk_background_color, anchor="w", justify="left")
    for button in (scraped_to_frame1, maps_only_button, extremes_button, pic_email_button, reboot_button):
        button.configure(width=9, justify="center", anchor="center", relief=tk.RAISED, bd=2)

# Reuse the buttons when showing the frame
def show_function_button_frame():
    function_button_frame.grid(row=0, column=0, sticky='nw')
    function_button_frame.lift()
    try:
        raise_transparent_canvas_widget()
    except Exception:
        pass
    raise_root_corner_logo()
    root.grid_rowconfigure(0, weight=0)
    root.grid_columnconfigure(0, weight=0)

    scraped_to_frame1.grid(row=0, column=0, padx=15, pady=(125, 0), sticky='nw')
    maps_only_button.grid(row=0, column=0, padx=15, pady=(215, 0), sticky='nw')
    extremes_button.grid(row=0, column=0, padx=15, pady=(305, 0), sticky='nw')
    pic_email_button.grid(row=0, column=0, padx=15, pady=(395, 0), sticky='nw')
    reboot_button.grid(row=0, column=0, padx=15, pady=(485, 0), sticky='nw')
    version_footer_label.configure(text=build_function_button_footer_text(), font=("Helvetica Neue", 8))
    version_footer_label.grid(row=0, column=0, padx=18, pady=(558, 0), sticky='nw')

def recreate_display_image_frame():
    global display_image_frame, display_label, DISPLAY_FRAME_RESET_IN_PROGRESS

    DISPLAY_FRAME_RESET_IN_PROGRESS = True
    #print("[RESET] Rebuilding display_image_frame...")

    try:
        for widget in display_image_frame.winfo_children():
            widget.destroy()
        display_image_frame.destroy()

        # Recreate the frame and grid it exactly like original
        display_image_frame = tk.Frame(root, width=950, height=515, bg=tk_background_color, bd=0)
        display_image_frame.grid(row=0, column=0, padx=(140,0), pady=(75,0), sticky="sw")  # ← Make sure this is identical
        display_image_frame.grid_propagate(False)

        # Ensure grid config remains correct
        root.grid_rowconfigure(0, weight=0)
        root.grid_columnconfigure(0, weight=0)

        # Recreate and place the label inside
        display_label = tk.Label(display_image_frame, bg=tk_background_color, bd=0, highlightthickness=0)
        display_label.grid(row=0, column=0, padx=70, pady=(0,0), sticky="sw")  # ← Initial placement

        display_image_frame.lift()  # ← (optional) Ensures it's on top

        #print("[RESET] display_image_frame successfully rebuilt.")

        # Cancel and restart auto-advance timer
        try:
            global auto_advance_timer
            if auto_advance_timer is not None:
                root.after_cancel(auto_advance_timer)
                auto_advance_timer = None
            auto_advance_timer = root.after(22000, auto_advance_frames)
            #print("[RESET] Auto-advance timer restarted.")
        except Exception as e:
            print(f"[ERROR] Failed to reset auto-advance timer: {e}")

    except Exception as e:
        print(f"[ERROR] Failed to reset display_image_frame: {e}")
        import traceback; traceback.print_exc()

    display_image_frame.tkraise()

    DISPLAY_FRAME_RESET_IN_PROGRESS = False

def set_state_uppercase():
    keyboard_set_state_uppercase(globals(), update_keyboard_shift_state)
    
shift_active = True # Start with shift active
caps_lock_active = False
keyboard_buttons = {} # to handle upper and lower case
shifted_keys = { # Now globally defined
  '1': '!', '2': '@', '3': '#', '4': '$', '5': '%',
  '6': '^', '7': '&', '8': '*', '9': '(', '0': ')',
  ';': ':', "'": '"', ',': '<', '.': '>', '-': '_', '/': '?'
}

def auto_capitalize():
    keyboard_auto_capitalize(globals(), tk, update_keyboard_shift_state)

def set_keyboard_target(widget):
    keyboard_set_keyboard_target(widget, globals(), tk, auto_capitalize, update_keyboard_shift_state)

def key_pressed(key_value):
    keyboard_key_pressed(key_value, globals(), tk, auto_capitalize, update_keyboard_shift_state)

def update_keyboard_shift_state():
    keyboard_update_keyboard_shift_state(globals(), tk)

def set_keyboard_mode(widget, mode, **options):
    keyboard_set_widget_keyboard_mode(widget, mode, **options)

def create_virtual_keyboard(parent, start_row):
    # Prepare the active parent for grid layout for the keyboard and other elements
    for i in range(20):  # Match this with total_columns in create_virtual_keyboard
        parent.grid_columnconfigure(i, weight=0)

    global shift_active, keyboard_buttons
    keyboard_layout = [
        ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', 'Backspace'],
        ['Tab', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '@gmail.com'],
        ['Caps', 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ';', "'"],
        ['Shift', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '/', 'Shift']
    ]
    extra_symbol_keys = []

    key_widths = {
        'Backspace': 7,
        '@gmail.com': 8,
        'Tab': 5,
        'Caps': 5,
        'Clear': 5,
        'Shift': 5,
        'Space': 45  # Adjusted length for the space bar
    }

    default_width = 5  # Uniform key width
    default_height = 2  # Assuming a uniform height for all keys

    global_padx = 50  # Set the padx to align with the text elements

    keyboard_buttons = {}  # Initialize keyboard_buttons as a dictionary

    for i, row in enumerate(keyboard_layout):
        padx_value = 5  # Default padx for each row

        if row[0] in {'A', 'Z'}:
            padx_value = 73  # Adjusted padx for 'A' and 'Z' rows for alignment
        elif row[0] == 'Caps':
            padx_value = 5  # Move the entire third row one key-width left

        # Add pady only to the first row to push it down
        pady_value = 1 if i == 0 else 0  # Add padding only to the top row

        for j, key in enumerate(row):
            width = key_widths.get(key, default_width)
            incremental_padx = padx_value + (j * 68)  # The refined 68-unit offset

            # Determine the text for the button based on whether it's a letter
            button_text = key.upper() if key.isalpha() else key
            btn = tk.Button(parent, text=button_text, command=lambda k=key: key_pressed(k), width=width, height=default_height)
            btn.grid(row=start_row + i, column=0, padx=(global_padx + incremental_padx), pady=(pady_value, 0), sticky="w")
            keyboard_buttons[key] = btn  # Store the button reference

    # Space bar placed independently
    space_bar = tk.Button(parent, text="Space", command=lambda: key_pressed(" "), width=key_widths['Space'], height=default_height)
    space_bar.grid(row=start_row + len(keyboard_layout), column=0, padx=(global_padx + 150), pady=(0, 5), sticky="w")
    keyboard_buttons['Space'] = space_bar  # Store the space bar reference

    clear_button = tk.Button(parent, text="Clear", command=lambda: key_pressed("Clear"), width=key_widths['Clear'], height=default_height)
    clear_button.grid(row=start_row + 2, column=0, padx=(global_padx + 5 + (11 * 68)), pady=(0, 0), sticky="w")
    keyboard_buttons['Clear'] = clear_button

    for idx, key in enumerate(extra_symbol_keys):
        symbol_button = tk.Button(parent, text=key, command=lambda k=key: key_pressed(k), width=default_width, height=default_height)
        symbol_button.grid(row=start_row + len(keyboard_layout), column=0, padx=(global_padx + 645 + (idx * 68)), pady=(0, 5), sticky="w")
        keyboard_buttons[key] = symbol_button

    update_keyboard_shift_state()

  
def clear_frame(frame1):
    destroy_frame_widgets(frame1)

def close_GUI():
    root.destroy()

def refresh_choices():
    global alternative_town_1, alternative_state_1, alternative_town_2, alternative_state_2, alternative_town_3, alternative_state_3   
    global refresh_flag, box_variables, lcl_radar_frames, reg_sat_frames, available_image_dictionary, lcl_radar_updated_flag, last_lcl_radar_update, reg_sat_updated_flag
    global img_label_lg_still_satellite, label_lcl_radar,  img_label_national_radar, baro_img_label, img_label_sfc_map, lcl_radar_animation_id, reg_sat_animation_id
    
    refresh_flag = True
    lcl_radar_updated_flag = False
    last_lcl_radar_update = datetime.now() - timedelta(seconds=181)  # Force the timer to be expired
    reg_sat_updated_flag = False

    # Clear existing radar and satellite loops
    lcl_radar_frames.clear()
    reg_sat_frames.clear()
    
    try:
        root.after_cancel(lcl_radar_animation_id)
        lcl_radar_animation_id = None
        
        if display_label:
            display_label.configure(image='')
            display_label.image = None

        #print("[INFO] Canceled existing LCL radar animation.")
    except Exception as e:
        pass
        #print(f"[INFO] No active radar animation to cancel: {e}")
    
    # Clear the current LCL radar loop from the image dictionary, if it exists
    if 'lcl_radar_loop_img' in available_image_dictionary:
        available_image_dictionary['lcl_radar_loop_img'].clear()

    try:
        root.after_cancel(reg_sat_animation_id)
        reg_sat_animation_id = None
        #print("[INFO] Canceled existing REG SAT animation.")
    except Exception as e:
        pass
        #print(f"[INFO] No active reg_sat animation to cancel: {e}")
        
    if 'reg_sat_loop_img' in available_image_dictionary:
        available_image_dictionary['reg_sat_loop_img'].clear()

    hide_ui_frames(
        forget_all_frames,
        transparent_frame=transparent_frame,
        function_button_frame=function_button_frame,
    )

    #avoid getting stuck trying to display radiosonde while user updates display choices
    box_variables[8] = 0
        
    prepare_frame1_screen(frame1, root)
    
    alternative_town_1 = " "
    alternative_state_1 = " "

    alternative_town_2 = " "
    alternative_state_2 = " "

    alternative_town_3 = " "
    alternative_state_3 = " "

    land_or_buoy()

def change_maps_only():
    global refresh_flag, baro_img_label, img_label_national_radar
    global label_lcl_radar, img_label_lg_still_satellite, img_label_sfc_map, lcl_radar_updated_flag, last_lcl_radar_update, reg_sat_updated_flag
    global box_variables, lcl_radar_frames, reg_sat_frames, available_image_dictionary, lcl_radar_animation_id, reg_sat_animation_id

    refresh_flag = True
    lcl_radar_updated_flag = False
    last_lcl_radar_update = datetime.now() - timedelta(seconds=181)  # Force the timer to be expired
    reg_sat_updated_flag = False

    # Clear existing frames to avoid displaying stale data
    lcl_radar_frames.clear()
    reg_sat_frames.clear()
    
    try:
        root.after_cancel(lcl_radar_animation_id)
        lcl_radar_animation_id = None
        
        if display_label:
            display_label.configure(image='')
            display_label.image = None
        
        #print("[INFO] Canceled existing LCL radar animation.")
    except Exception as e:
        pass
        #print(f"[INFO] No active radar animation to cancel: {e}")

    if 'lcl_radar_loop_img' in available_image_dictionary:
        available_image_dictionary['lcl_radar_loop_img'].clear()

    try:
        root.after_cancel(reg_sat_animation_id)
        reg_sat_animation_id = None

        #print("[INFO] Canceled existing REG SAT animation.")
    except Exception as e:
        pass
        #print(f"[INFO] No active reg_sat animation to cancel: {e}")
        
    if 'reg_sat_loop_img' in available_image_dictionary:
        available_image_dictionary['reg_sat_loop_img'].clear()

    hide_ui_frames(
        forget_all_frames,
        transparent_frame=transparent_frame,
        baro_frame=baro_frame,
        function_button_frame=function_button_frame,
    )
    
    # Avoid getting stuck trying to display radiosonde while user updates display choices
    box_variables[8] = 0

    prepare_frame1_screen(frame1, root)
    
    page_choose()
    
    # Function to display the map image in a Tkinter window
def display_extremes_map_image():
    global extremes_flag
    
    reset_for_frame1_display(
        frame1,
        root,
        forget_all_frames,
        baro_frame=baro_frame,
        function_button_frame=function_button_frame,
        destroy_all=True,
        row_weight=0,
        column_weight=0,
        geometry='1024x600',
    )

    # show obs from transparent frame while displaying extremes map
    show_transparent_frame_overlay()
    root.grid_rowconfigure(0, weight=0)
    root.grid_columnconfigure(0, weight=0)
    update_transparent_frame_data()

    # Define the URL (you already have this)
    extremes_map_image_url = "https://weatherobserver.duckdns.org/extremes_station_map_resized.png"

    # Define the local save path (you already have this)
    local_extremes_map_filename = "/home/santod/downloaded_extremes_map.png"
    
    try:
        extremes_map_response = requests.get(extremes_map_image_url, stream=True, timeout=15)
        if extremes_map_response.status_code == 200:
            with open(local_extremes_map_filename, 'wb') as extremes_map_file:
                for extremes_map_chunk in extremes_map_response.iter_content(chunk_size=8192):
                    extremes_map_file.write(extremes_map_chunk)
            print(f"Extremes map image successfully downloaded and saved as: {local_extremes_map_filename}")

            # Open the downloaded image
            img = Image.open(local_extremes_map_filename)

            # Create a PhotoImage object from the image
            tk_img = ImageTk.PhotoImage(img)

            # Create a label to display the image
            label = tk.Label(frame1, image=tk_img, bg=tk_background_color)
            label.image = tk_img  # Keep a reference!

            # Place the label in the frame, centered at the bottom with no padding
            label.grid(row=0, column=0, padx=0, pady=75, sticky="w")

        else:
            print(f"Error: Failed to download... Status code: {extremes_map_response.status_code}")
            print(f"Response text: {extremes_map_response.text}")
    except requests.exceptions.RequestException as e:
        print(f"Error: A network request exception occurred...: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        
    extreme_text = f"Click\nReturn to\nget back\nto images."
    extreme_label = tk.Label(frame1, text=extreme_text, font=("DejaVu Sans", 14), bg=tk_background_color, justify="left")
    extreme_label.grid(row=0, column=0, padx=50, pady=(270,0), sticky="nw")
    
    # get rid of red extremes pause button
    extremes_button_on.grid_forget()
    
    # Buttons for screenshot and email
    pic_email_button = tk.Button(frame1, text=" \n Share a \nScreenshot\n", command=show_fb_login_screen)
    pic_email_button.grid(row=0, column=0, padx=(50, 0), pady=(380,0), sticky='nw') 
    
    # Create a return button to return to scraped frame
    return_button = tk.Button(frame1, text="Return", command=return_to_image_cycle, font=("Helvetica", 16, "bold"))
    return_button.grid(row=0, column=0, padx=(50, 0), pady=(500, 0), sticky="nw")

    # optional: freeze current band size so it can't balloon when busy
    root.update_idletasks()

    # schedule z-order after a tick
    root.after(50, raise_transparent_canvas_widget)

def find_and_display_extremes():
    global extremes_flag, extremes_button_on
    extremes_flag = True

    # Create a standard tk.Button with centered text, explicitly using tk.Button
    # to avoid collision with matplotlib.widgets.Button.
    extremes_button_on = tk.Button(function_button_frame, text='Please\nPause.\nMap is\nGenerating',  
                                   bg="#FF9999", fg="white", justify='center', anchor='center',
                                   padx=0, width=11,
                                   command=find_and_display_extremes)

    extremes_button_on.grid(row=0, column=0, padx=15, pady=(305,0), sticky='nw')
    function_button_frame.update_idletasks()
    
    display_extremes_map_image()

def submit_pic_email():
    global email_entry  # Declare the use of the global variable
    
    to_email = email_entry.get()  # Get the email address from the entry widget
    if not to_email:
        print("No email address provided.")
        return

    try:
        send_screenshot_email(
            to_email,
            screenshot_filename,
            'picturesfromtheweatherobserver@gmail.com',
            EMAIL_PASSWORD_CODE,
        )
        reset_for_frame1_display(
            frame1,
            root,
            forget_all_frames,
            transparent_frame=transparent_frame,
            baro_frame=baro_frame,
            destroy_all=True,
            row_weight=1,
            column_weight=1,
            geometry='1024x600',
        )
        build_message_action_screen(
            frame1,
            tk,
            tk_background_color,
            "The Weather Observer",
            [
                "Your email was sent successfully",
                "Click the button to return to the maps",
            ],
            [
                {
                    "text": "Return",
                    "command": return_to_image_cycle,
                }
            ],
        )
        
    except Exception as e:
        print("line 611. failed to send email: ", e)
        reset_for_frame1_display(
            frame1,
            root,
            forget_all_frames,
            transparent_frame=transparent_frame,
            baro_frame=baro_frame,
            destroy_all=True,
            row_weight=1,
            column_weight=1,
            geometry='1024x600',
        )
        build_message_action_screen(
            frame1,
            tk,
            tk_background_color,
            "The Weather Observer",
            [
                "Your email was not able to be sent",
                "Try another email address or return to the Maps",
            ],
            [
                {
                    "text": "Email",
                    "command": pic_email,
                    "column": 0,
                },
                {
                    "text": "Return",
                    "command": return_to_image_cycle,
                    "column": 1,
                },
            ],
        )

# Main function to take screenshot and handle errors
def pic_email():
    global email_entry, refresh_flag, frame1_overlay_lock  # Use the global variable
    refresh_flag = True
    frame1_overlay_lock = True
    hide_transition_overlay()

    screenshot_filename = SCREENSHOT_PATH
    validate_screenshot_file(screenshot_filename, is_black_image)

    reset_for_frame1_display(
        frame1,
        root,
        forget_all_frames,
        transparent_frame=transparent_frame,
        baro_frame=baro_frame,
        destroy_widget_types=(tk.Checkbutton, tk.Label, tk.Button, ttk.Button, tk.Entry, tk.Radiobutton),
        sticky="nsew",
        width=1024,
        height=600,
        grid_propagate=False,
        row_weight=0,
        column_weight=0,
        geometry='1024x600',
    )
    try:
        ROOT_CORNER_CANVAS.place_forget()
    except Exception:
        pass
    destroy_frame_widgets(frame1)

    add_weather_observer_header(frame1, tk, tk_background_color)

    instruction_text = "Please enter the email address to send the screenshot:"
    instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
    instructions_label.grid(row=1, column=0, columnspan=20, padx=50, pady=25, sticky='nw')

    email_entry = tk.Entry(frame1, font=("Helvetica", 14), width=50)
    email_entry.grid(row=2, column=0, columnspan=20, padx=50, pady=5, sticky='nw')
    set_keyboard_mode(email_entry, "email")

    email_entry.focus_set()

    submit_button = tk.Button(frame1, text="Submit", command=submit_pic_email, font=("Helvetica", 16, "bold"))
    submit_button.grid(row=6, column=0, columnspan=20, padx=50, pady=(15,0), sticky='nw')

    cancel_button = tk.Button(frame1, text="Cancel", command=return_to_image_cycle, font=("Helvetica", 16, "bold"))
    cancel_button.grid(row=6, column=0, columnspan=20, padx=225, pady=(15,0), sticky='nw')

    email_entry.bind("<FocusIn>", lambda e: set_keyboard_target(email_entry))

    spacer = tk.Label(frame1, text="", bg=tk_background_color)
    spacer.grid(row=7, column=0, sticky="nsew", pady=(0, 20))

    create_virtual_keyboard(frame1, 8)

    # Load and display the screenshot image
    image_path = SCREENSHOT_PATH  # Use the fixed path
    print(f"Image path: {SCREENSHOT_PATH}, Exists: {os.path.exists(SCREENSHOT_PATH)}")
    image = Image.open(image_path)
    image = image.resize((200, 118))  # Adjusted size as per your requirement
    photo = ImageTk.PhotoImage(image)
    image_label = tk.Label(frame1, image=photo)
    image_label.image = photo  # Keep a reference!
    # Place the image at the top of the column
    #image_label.grid(row=0, column=20, sticky="ne", padx=10)
    image_label.grid(row=0, sticky="n", padx=0)
    # Add a label for "Preview" text directly below the image
    preview_label = tk.Label(frame1, text="Preview", font=("Helvetica", 12), bg=tk_background_color)
    # Position it just below the image without using excessive padding or altering other widgets
    #preview_label.grid(row=0, column=20, sticky="n", padx=10)
    preview_label.grid(row=0, sticky="n", padx=0, pady=(120,0))

def show_fb_login_screen():
    global refresh_flag, frame1_overlay_lock # use refresh flag to prevent getting kicked off pic post
    SCREENSHOT_PATH = "/home/santod/screenshot.png"
    screenshot_filename = SCREENSHOT_PATH

    refresh_flag = True
    frame1_overlay_lock = True
    hide_transition_overlay()
    capture_screenshot(screenshot_filename)
    validate_screenshot_file(screenshot_filename, is_black_image)

    reset_for_frame1_display(
        frame1,
        root,
        forget_all_frames,
        transparent_frame=transparent_frame,
        destroy_widget_types=(tk.Checkbutton, tk.Label, tk.Button, ttk.Button, tk.Entry, tk.Radiobutton, tk.Text),
        sticky="nsew",
        width=1024,
        height=600,
        background='light blue',
        grid_propagate=False,
        row_weight=1,
        column_weight=1,
        geometry='1024x600',
    )
    try:
        ROOT_CORNER_CANVAS.place_forget()
    except Exception:
        pass

    add_weather_observer_header(frame1, tk, 'light blue', pady=(40, 0))

    messages = [
        "Connecting to Facebook...",
        "Initializing authentication request...",
        "Connected to Facebook Page and Instagram Business Account: The Weather Observer"
    ]
    delay = 1000  # 1 seconds between messages

    # Create primary message label
    msg_label = tk.Label(frame1, text="", font=("Helvetica", 16), bg='light blue', justify="left")
    msg_label.grid(row=0, column=0, padx=50, pady=(120, 0), sticky="nw")

    # Prepare second label but don’t display yet
    final_label = tk.Label(frame1, text="", font=("Helvetica", 16), bg='light blue', justify="left")

    def show_next_message(index=0):
        if index < len(messages):
            msg_label.config(text=messages[index])
            frame1.after(delay, lambda: show_next_message(index + 1))
        elif index == len(messages):
            # Show the 3rd message (which stays) and queue the final message
            msg_label.config(text=messages[-1])
            frame1.after(delay, lambda: show_next_message(index + 1))
        elif index == len(messages) + 1:
            # Now show the final message below it
            final_label.config(text="Facebook Login complete")
            final_label.grid(row=0, column=0, padx=50, pady=(160, 0), sticky="nw")

            # Then show the Proceed button
            proceed_button = tk.Button(frame1, text="Proceed", font=("Helvetica", 16, "bold"), command=pic_post)
            proceed_button.grid(row=0, column=0, padx=50, pady=(220, 0), sticky="nw")

    show_next_message()


def pic_post():
    global email_entry, refresh_flag, keyboard_buttons, current_target_entry, frame1_overlay_lock 

    SCREENSHOT_PATH = "/home/santod/screenshot.png"
    frame1_overlay_lock = True
    hide_transition_overlay()

    for widget in frame1.winfo_children():
        # Consider a more robust way if frame1 contains persistent elements you don't want destroyed
        # Or destroy only specific types as you are doing
        if isinstance(widget, (tk.Checkbutton, tk.Label, tk.Button, ttk.Button, tk.Entry, tk.Radiobutton, tk.Text)): # Added tk.Text
             widget.destroy()

    keyboard_buttons.clear() # Clear the dictionary holding refs to destroyed buttons
    current_target_entry = None # Reset the target entry as it was likely destroyed

    IMAGE_PATH = "/home/santod/screenshot.png"
    MESSAGE = "Posted from The Weather Observer!"

    def submit_pic_post_choice(fb_var, insta_var, frame1):
        user_caption = text_input.get("1.0", "end-1c").strip()
        if fb_var.get():
            share_post_to_facebook(user_caption, IMAGE_PATH, PAGE_ID, PAGE_ACCESS_TOKEN, messagebox)
        if insta_var.get():
            share_post_to_instagram(
                user_caption,
                "/home/santod/screenshot.png",
                "/home/santod/screenshot.jpg",
                "https://weatherobserver.duckdns.org/upload.php",
                API_SECRET_TOKEN,
                IG_USER_ID,
                ACCESS_TOKEN,
                messagebox,
            )
        if email_var.get():
            pic_email()

    reset_for_frame1_display(
        frame1,
        root,
        forget_all_frames,
        transparent_frame=transparent_frame,
        baro_frame=baro_frame,
        sticky="nsew",
        width=1024,
        height=600,
        grid_propagate=False,
        row_weight=1,
        column_weight=1,
        geometry='1024x600',
    )
    try:
        ROOT_CORNER_CANVAS.place_forget()
    except Exception:
        pass

    add_weather_observer_header(frame1, tk, 'light blue', pady=(40, 0))

    fb_var = tk.BooleanVar()
    insta_var = tk.BooleanVar()
    email_var = tk.BooleanVar()

    tk.Checkbutton(frame1, text="Post to Facebook", variable=fb_var, font=("Helvetica", 14), bg='light blue', highlightthickness=0).grid(row=0, column=0, padx=50, pady=(110, 0), sticky="nw")
    tk.Checkbutton(frame1, text="Post to Instagram", variable=insta_var, font=("Helvetica", 14), bg='light blue', highlightthickness=0).grid(row=0, column=0, padx=50, pady=(140, 0), sticky="nw")

    label2 = tk.Label(frame1, text="OR", font=("Arial", 24, "bold"), bg='light blue', justify="left")
    label2.grid(row=0, column=0, padx=(275, 0), pady=(110, 0), sticky="nw")

    tk.Checkbutton(frame1, text="Email the image", variable=email_var, font=("Helvetica", 14), bg='light blue', highlightthickness=0).grid(row=0, column=0, padx=370, pady=(110, 0), sticky="nw")

    label3 = tk.Label(frame1, text="If posting, edit/complete what you want the post to say below:", font=("Arial", 12), bg='light blue', justify="left")
    label3.grid(row=0, column=0, padx=(50, 0), pady=(180, 0), sticky="nw")

    text_input = tk.Text(frame1, height=3, font=('Arial', 12))
    text_input.grid(row=1, column=0, columnspan=20, padx=(50, 0), pady=(20,10), sticky='w') # Adjusted pady slightly
    text_input.insert('1.0', "Posted from The Weather Observer. ")
    set_keyboard_mode(text_input, "message")
    # text_input.focus_set() # Set focus after keyboard is created potentially
    text_input.config(cursor="xterm")
    text_input.bind("<FocusIn>", lambda event, widget=text_input: set_keyboard_target(widget)) # Good binding

    # --- FIX 2: Create the keyboard *before* calling auto_capitalize ---
    create_virtual_keyboard(frame1, start_row=3)

    post_button = tk.Button(frame1, text="Share", command=lambda: submit_pic_post_choice(fb_var, insta_var, frame1), font=("Helvetica", 16, "bold"))
    # Adjusted post button pady to avoid overlap if keyboard is taller
    post_button.grid(row=2, column=0, columnspan=20, padx=(50,0), pady=(10, 15), sticky='nw')

    cancel_button = tk.Button(frame1, text="Return", command=return_to_image_cycle, font=("Helvetica", 16, "bold"))
    cancel_button.grid(row=2, column=0, columnspan=20, padx=(200,0), pady=(10, 15), sticky='nw')

    # --- Image preview logic ---
    image_path = SCREENSHOT_PATH
    try: # Add try-except for image loading
        print(f"Image path: {SCREENSHOT_PATH}, Exists: {os.path.exists(SCREENSHOT_PATH)}")
        if os.path.exists(image_path):
             image = Image.open(image_path)
             image = image.resize((200, 118))
             photo = ImageTk.PhotoImage(image)
             image_label = tk.Label(frame1, image=photo)
             image_label.image = photo # Keep reference
             # Adjusted image preview placement - check column/padx carefully relative to keyboard
             image_label.grid(row=0, padx=(10, 0), pady=(0, 0), sticky="n") # Example placement
            
             preview_label = tk.Label(frame1, text="Preview", font=("Helvetica", 12), bg='light blue') # Use frame background color
             # Adjusted preview label placement
             preview_label.grid(row=0, padx=(10, 0), pady=(120, 0), sticky="n") # Example placement below image
        else:
             print(f"Preview image not found at {image_path}")
    except Exception as e:
        print(f"Error loading preview image: {e}")

    print("Setting focus to text_input...") # Debugging print
    text_input.focus_set() 

#code begins for generation of random sites
def clear_random_map_ui():
    global random_map_label, random_map_placeholder_label, random_map_container
    print("line 2516. clearing map showing random sites.")
    if random_map_label and random_map_label.winfo_exists():
        try:
            random_map_label.configure(image="")
            random_map_label.image = None
            random_map_label.destroy()
            random_map_label = None
            print("line 2523. random sites map cleared.")
        except Exception as e:
            print(f"[RMAP] cleanup error: {e}")
    else:
        print("[RMAP] no map widget to clear.")
    if random_map_placeholder_label and random_map_placeholder_label.winfo_exists():
        try:
            random_map_placeholder_label.destroy()
            random_map_placeholder_label = None
        except Exception as e:
            print(f"[RMAP] placeholder cleanup error: {e}")
    if random_map_container and random_map_container.winfo_exists():
        try:
            random_map_container.destroy()
            random_map_container = None
        except Exception as e:
            print(f"[RMAP] container cleanup error: {e}")


def ensure_random_map_container():
    global random_map_container
    if random_map_container and random_map_container.winfo_exists():
        return random_map_container

    container = tk.Frame(frame1, width=450, height=300, bg="#eef5fb", relief=tk.SOLID, bd=1)
    container.grid(row=8, column=8, rowspan=6, sticky="se", padx=(570, 10), pady=(18, 10))
    container.grid_propagate(False)
    random_map_container = container
    return container


def show_random_map_placeholder(message="Map showing locations will appear here shortly."):
    global random_map_placeholder_label

    if random_map_placeholder_label and random_map_placeholder_label.winfo_exists():
        random_map_placeholder_label.config(text=message)
        return

    container = ensure_random_map_container()
    placeholder = tk.Label(
        container,
        text=message,
        font=("Helvetica Neue", 14),
        fg="black",
        bg="#eef5fb",
        justify="center",
        wraplength=330,
        padx=18,
        pady=18,
    )
    placeholder.place(x=0, y=0, width=450, height=300)
    random_map_placeholder_label = placeholder


def build_random_map_async(random_stations):
    def worker():
        started = time.perf_counter()
        try:
            create_random_map_image(random_stations)
            elapsed = time.perf_counter() - started
            print(f"[RANDOM] Background map build finished in {elapsed:.2f} seconds.")

            def apply_map():
                if not frame1.winfo_exists() or not frame1.winfo_ismapped():
                    return
                try:
                    display_random_map_image("/home/santod/station_locations.png")
                    if random_map_placeholder_label and random_map_placeholder_label.winfo_exists():
                        random_map_placeholder_label.destroy()
                except Exception as e:
                    print(f"[RMAP] display apply error: {e}")

            root.after(0, apply_map)
        except Exception as e:
            print(f"[RMAP] background build error: {e}")
            root.after(0, lambda: show_random_map_placeholder("Map could not be prepared right now."))

    threading.Thread(target=worker, name="random-map-build", daemon=True).start()


def any_obs_only_click_active():
    return aobs_only_click_flag or bobs_only_click_flag or cobs_only_click_flag


def get_random_slot_for_obs_type(obs_type):
    slot_map = {
        "aobs": get_random_station_slots()[0],
        "bobs": get_random_station_slots()[1],
        "cobs": get_random_station_slots()[2],
    }
    return slot_map.get(obs_type)


def apply_single_random_station_selection_globals(obs_type, station_data, buoy_id_set):
    slot = get_random_slot_for_obs_type(obs_type)
    if not slot:
        return

    station_details = build_selected_station_details(
        station_data,
        buoy_id_set,
        obs_buttons_choice_abbreviations,
    )
    apply_station_details_to_globals(station_details, slot, globals())


def show_random_selection_confirmation(random_stations, announce_text, back_function, next_function):
    for widget in frame1.winfo_children():
        widget.destroy()
    hide_display_frame_for_frame1()

    frame1.grid_columnconfigure(0, weight=1)
    frame1.grid_columnconfigure(9, weight=1)

    add_modern_screen_text(
        frame1,
        tk,
        tk_background_color,
        "The Weather Observer",
        announce_text,
        title_row=0,
        body_row=1,
        title_padx=50,
        title_pady=(20, 10),
        body_padx=50,
        body_pady=(0, 15),
        title_columnspan=9,
        body_columnspan=9,
        sticky="nw",
    )

    random_sites_text = "\n".join(station["name"] for station in random_stations)
    label2 = tk.Label(
        frame1,
        text=random_sites_text,
        font=("Helvetica Neue", 15),
        fg="black",
        bg=tk_background_color,
        anchor='w',
        justify='left',
    )
    label2.grid(row=2, column=0, columnspan=9, padx=(50, 0), pady=(0, 3), sticky='w')

    for station in random_stations:
        if 'latitude' not in station or 'longitude' not in station:
            label_error = tk.Label(
                frame1,
                text=f"Error: Missing location data for {station['name']}.",
                font=("Arial", 14),
                fg="red",
                bg=tk_background_color,
            )
            label_error.grid(row=4, column=0, columnspan=20, padx=50, pady=(10, 10), sticky='w')
            return

    show_random_map_placeholder()
    build_random_map_async(random_stations)

    back_button = create_modern_button(
        frame1,
        tk,
        " Back ",
        back_function,
        font=("Helvetica", 16, "bold"),
        variant="secondary",
    )
    back_button.grid(row=3, column=0, columnspan=20, padx=(50, 0), pady=(20, 0), sticky="nw")

    def finish_random_confirmation():
        global aobs_only_click_flag, bobs_only_click_flag, cobs_only_click_flag
        if next_function == return_to_image_cycle:
            aobs_only_click_flag = False
            bobs_only_click_flag = False
            cobs_only_click_flag = False
        next_function()

    next_button = create_modern_button(
        frame1,
        tk,
        "Next",
        finish_random_confirmation,
        font=("Helvetica", 16, "bold"),
        variant="primary",
    )
    next_button.grid(row=3, column=0, columnspan=20, padx=200, pady=(20, 0), sticky='nw')


def get_next_function_after_single_random(obs_type):
    slot = get_obs_slot_config(obs_type)
    if slot and globals().get(slot["only_click_flag_var"]):
        return return_to_image_cycle

    next_functions = {
        "aobs": bobs_land_or_buoy,
        "bobs": cobs_land_or_buoy,
        "cobs": page_choose,
    }
    return next_functions.get(obs_type, return_to_image_cycle)

def confirm_random_sites(back_function=None):
    """
    (Corrected) Gathers the data for the three randomly selected sites
    and calls the UI update function. This version uses the correct
    'alternative_town' variables.
    """
    global alternative_town_1, alternative_town_2, alternative_town_3, frame1_overlay_lock
    frame1_overlay_lock = True
    global aobs_random_obs_lat, aobs_random_obs_lon, bobs_random_obs_lat, bobs_random_obs_lon, cobs_random_obs_lat, cobs_random_obs_lon

    # Construct the station dictionaries using the correct 'alternative_town' variables
    station_a = {'name': alternative_town_1, 'latitude': aobs_random_obs_lat, 'longitude': aobs_random_obs_lon}
    station_b = {'name': alternative_town_2, 'latitude': bobs_random_obs_lat, 'longitude': bobs_random_obs_lon}
    station_c = {'name': alternative_town_3, 'latitude': cobs_random_obs_lat, 'longitude': cobs_random_obs_lon}
    
    random_stations = [station_a, station_b, station_c]

    next_function = return_to_image_cycle if any_obs_only_click_active() else page_choose
    show_random_selection_confirmation(
        random_stations,
        "The following 3 locations have been chosen as observation sites:",
        back_function or land_or_buoy,
        next_function,
    )

    gc.collect()
    #snap_after = tracemalloc.take_snapshot()
    #top = snap_after.compare_to(snap_before, 'lineno')[:10]
    #print("[OBS] top allocators after site change:")
    #for stat in top:
        #print(stat)

def update_gui(random_stations):
    next_function = return_to_image_cycle if any_obs_only_click_active() else page_choose
    show_random_selection_confirmation(
        random_stations,
        "The following 3 locations have been chosen as observation sites:",
        land_or_buoy,
        next_function,
    )
    
def calculate_random_center(random_stations):
    random_latitudes = [float(station['latitude']) for station in random_stations]
    random_longitudes = [float(station['longitude']) for station in random_stations]
    return sum(random_latitudes) / len(random_latitudes), sum(random_longitudes) / len(random_longitudes)

def calculate_random_zoom_level(random_stations):
    max_random_distance = 0
    for i in range(len(random_stations)):
        for j in range(i + 1, len(random_stations)):
            point1 = (float(random_stations[i]['latitude']), float(random_stations[i]['longitude']))
            point2 = (float(random_stations[j]['latitude']), float(random_stations[j]['longitude']))
            distance = geodesic(point1, point2).kilometers
            if distance > max_random_distance:
                max_random_distance = distance
        
    if max_random_distance < 50:
        return 10
    elif max_random_distance < 100:
        return 9
    elif max_random_distance < 200:
        return 8
    elif max_random_distance < 400:
        return 7
    elif max_random_distance < 800:
        return 6
    elif max_random_distance < 1600:
        return 5
    else:
        return 4

# Function to adjust the window size based on the visible content area
def adjust_random_window_size(driver, target_width, target_height):
    # Run JavaScript to get the size of the visible content area
    width = driver.execute_script("return window.innerWidth;")
    height = driver.execute_script("return window.innerHeight;")
    
    # Calculate the difference between the actual and desired dimensions
    width_diff = target_width - width
    height_diff = target_height - height

    # Adjust the window size based on the difference
    current_window_size = driver.get_window_size()
    new_width = current_window_size['width'] + width_diff
    new_height = current_window_size['height'] + height_diff
    driver.set_window_size(new_width, new_height)

def create_random_map_image(random_stations):
    # center and zoom exactly as before
    random_center = calculate_random_center(random_stations)
    random_zoom_level = calculate_random_zoom_level(random_stations)

    # fixed-size folium map (no style changes)
    m = folium.Map(
        location=random_center,
        zoom_start=random_zoom_level,
        width=450,
        height=300,
        control_scale=False,
        zoom_control=False
    )

    # markers and labels exactly as before
    for station in random_stations:
        random_station_name = format_map_flag_label(
            station.get('name', ''),
            station.get('state', ''),
            max_length=16,
        )
        folium.Marker(
            location=(station['latitude'], station['longitude']),
            icon=folium.Icon(color='blue', icon='info-sign')
        ).add_to(m)
        folium.Marker(
            location=(station['latitude'], station['longitude']),
            icon=folium.DivIcon(html=f'''
                <div style="
                    background-color: white;
                    padding: 2px 5px;
                    border-radius: 3px;
                    box-shadow: 0px 0px 2px rgba(0, 0, 0, 0.5);
                    font-size: 12px;
                    font-weight: bold;
                    text-align: center;
                    width: 88px;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    transform: translate(-40%, -130%);
                ">{random_station_name}</div>
            ''')
        ).add_to(m)

    # fit bounds with the original buffers
    latitudes  = [station['latitude']  for station in random_stations]
    longitudes = [station['longitude'] for station in random_stations]
    min_lat, max_lat = min(latitudes),  max(latitudes)
    min_lon, max_lon = min(longitudes), max(longitudes)
    ns_buffer, ew_buffer = 0.15, 0.1
    bounds = [[min_lat - ns_buffer, min_lon - ew_buffer],
              [max_lat + ns_buffer, max_lon + ew_buffer]]
    m.fit_bounds(bounds)

    # file paths
    html_path = "/home/santod/random_station_locations.html"
    png_path  = "/home/santod/station_locations.png"

    # write HTML (legacy behavior) with cleanup on failure
    try:
        m.save(html_path)
    except Exception as e:
        print(f"[RMAP] Failed to save map HTML: {e}")
        try:
            if os.path.exists(html_path):
                os.remove(html_path)
        except Exception:
            pass
        return

    try:
        if not capture_folium_map_screenshot(
            html_path,
            png_path,
            CHROME_DRIVER_PATH,
            Options,
            Service,
            webdriver,
            time,
            adjust_random_window_size,
        ):
            print("ERROR: ChromeDriver path is not set. Cannot start browser.")

    except Exception as e:
        print(f"[RMAP] Screenshot error: {e}")
    finally:
        try:
            if os.path.exists(html_path):
                os.remove(html_path)
        except Exception as e:
            print(f"[RMAP] Cleanup warning (HTML): {e}")


def display_random_map_image(img_path):
    global random_map_label, random_map_placeholder_label
    # legacy display path: fixed resize to 450x300 then load into a fresh Label
    img = Image.open(img_path)
    try:
        img = img.resize((450, 300), Image.LANCZOS)
        tk_img = ImageTk.PhotoImage(img)

        container = ensure_random_map_container()

        if random_map_placeholder_label and random_map_placeholder_label.winfo_exists():
            try:
                random_map_placeholder_label.destroy()
            except Exception:
                pass
            random_map_placeholder_label = None
        if random_map_label and random_map_label.winfo_exists():
            try:
                random_map_label.destroy()
            except Exception:
                pass

        label = tk.Label(container, image=tk_img, bd=0, highlightthickness=0)
        label.image = tk_img
        label.place(x=0, y=0, width=450, height=300)
        random_map_label = label
    finally:
        try:
            img.close()
        except Exception:
            pass
        try:
            if os.path.exists(img_path):
                os.remove(img_path)
        except FileNotFoundError:
            pass

def generate_random_sites(selection_count=None, target_obs_type=None, back_function=None):
    """
    Finds 3 random, functioning stations near the user's location using
    a pre-filtered cache and an expanding search radius. (Corrected for deadlock)
    """
    # --- Preserved tracemalloc logic ---
    global snap_before
    snap_before = tracemalloc.take_snapshot()

    # --- Global variable declarations ---
    global RANDOM_CANDIDATE_STATIONS_CACHE, RANDOM_CANDIDATE_STATIONS_20_CACHE, BUOY_ID_SET, aobs_site
    global aobs_station_identifier, bobs_station_identifier, cobs_station_identifier
    global aobs_buoy_code, bobs_buoy_code, cobs_buoy_code
    global aobs_buoy_signal, bobs_buoy_signal, cobs_buoy_signal
    global alternative_town_1, alternative_town_2, alternative_town_3
    global aobs_random_obs_lat, aobs_random_obs_lon, bobs_random_obs_lat, bobs_random_obs_lon, cobs_random_obs_lat, cobs_random_obs_lon
    global atemp, awtemp, awind, btemp, bwtemp, bwind, ctemp, cwtemp, cwind
    global last_land_scrape_time
    global random_sites_flag
    random_flow_started = time.perf_counter()
    
    #random_sites_flag = True

    random_station_config = get_random_station_config()
    if selection_count is None:
        selection_count = random_station_config["selection_count"]
    hide_display_frame_for_frame1()

    # --- Initial UI setup ---
    if target_obs_type:
        instruction_text = "Please wait while a random site is chosen for you."
    else:
        instruction_text = random_station_config["initial_message"]
    random_progress_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 12), bg=tk_background_color, anchor='w', justify='left')
    random_progress_label.grid(row=4, column=0, padx=50, pady=5, sticky='w')
    frame1.update_idletasks()
    print("[RANDOM] Starting random site generation")

    # --- Main execution block ---
    try:
        if 'aobs_site' not in globals() or not aobs_site:
            raise ValueError("Primary location (aobs_site) is not set.")
        
        if not RANDOM_CANDIDATE_STATIONS_CACHE:
            raise ValueError(random_station_config["empty_cache_message"])

        random_progress_label.config(text="Determining center for random stations...")
        frame1.update_idletasks()

        center_lat = globals().get("latitude")
        center_lon = globals().get("longitude")
        if center_lat is None or center_lon is None:
            print(f"[RANDOM] Missing cached center lat/lon for aobs_site '{aobs_site}'. Falling back to geocode.")
            geolocator = Nominatim(user_agent="two_random_locator_final_v1_contact_observeweather@gmail.com")
            center_location = geolocator.geocode(aobs_site, exactly_one=True, timeout=10)
            if center_location is None:
                raise ValueError(f"Could not geocode the location: {aobs_site}")
            center_lat, center_lon = center_location.latitude, center_location.longitude
        else:
            print(f"[RANDOM] Using cached center lat/lon: {center_lat:.4f}, {center_lon:.4f}")
        
        search_radii = random_station_config["search_radii"]
        _, buoy_id_set, _ = load_buoy_metadata_cached()
        random_progress_label.config(text="Checking which nearby stations are currently working...")
        frame1.update_idletasks()
        station_check_started = time.perf_counter()
        valid_stations, initial_land_data = find_valid_random_stations(
            RANDOM_CANDIDATE_STATIONS_CACHE,
            center_lat,
            center_lon,
            search_radii,
            selection_count,
            random_progress_label,
            frame1,
            check_random_station_functionality,
            buoy_id_set,
            precomputed_radius_pools={20: RANDOM_CANDIDATE_STATIONS_20_CACHE},
        )
        print(f"[RANDOM] Station validation finished in {time.perf_counter() - station_check_started:.2f} seconds. Found {len(valid_stations)} station(s).")
        # --- END OF MODIFIED LOGIC ---

        if len(valid_stations) < selection_count:
            raise ValueError(random_station_config["failure_message"])

        selected_stations = valid_stations[:selection_count]

        random_progress_label.config(text=random_station_config["map_build_message"])
        frame1.update_idletasks()

        if target_obs_type:
            apply_single_random_station_selection_globals(
                target_obs_type,
                selected_stations[0],
                buoy_id_set,
            )
        else:
            populate_random_station_selection_globals(
                selected_stations,
                buoy_id_set,
                obs_buttons_choice_abbreviations,
                globals(),
            )

        random_progress_label.config(text=random_station_config["preload_message"])
        frame1.update_idletasks()
        selected_station_ids = [station.get("id") for station in selected_stations]
        buoy_selection_count = sum(1 for station_id in selected_station_ids if station_id in buoy_id_set)
        land_selection_count = len(selected_station_ids) - buoy_selection_count
        print(f"[RANDOM] Pre-loading observations for {land_selection_count} land station(s) and {buoy_selection_count} buoy(s).")
        preload_started = time.perf_counter()

        land_data, buoy_data = preload_random_station_observations(
            aobs_buoy_signal,
            aobs_station_identifier,
            aobs_buoy_code,
            bobs_buoy_signal,
            bobs_station_identifier,
            bobs_buoy_code,
            cobs_buoy_signal,
            cobs_station_identifier,
            cobs_buoy_code,
            scrape_land_station_data,
            get_buoy_data,
            initial_land_data=initial_land_data,
        )
        print(f"[RANDOM] Observation preload finished in {time.perf_counter() - preload_started:.2f} seconds.")

        populate_random_station_observation_globals(
            land_data,
            buoy_data,
            globals(),
        )

        last_land_scrape_time = datetime.now()
        
        import gc; gc.collect()

        if target_obs_type:
            random_progress_label.config(text=random_station_config["map_build_message"])
            frame1.update_idletasks()
            map_build_started = time.perf_counter()
            selected_station = selected_stations[0]
            random_station = {
                'name': get_obs_slot_config(target_obs_type) and globals()[get_obs_slot_config(target_obs_type)["town_var"]] or selected_station["name"],
                'latitude': selected_station['latitude'],
                'longitude': selected_station['longitude'],
            }
            create_random_map_image([random_station])
            print(f"[RANDOM] Map build finished in {time.perf_counter() - map_build_started:.2f} seconds.")
            random_progress_label.destroy()
            show_random_selection_confirmation(
                [random_station],
                "The following location has been chosen as an observation site:",
                back_function or land_or_buoy,
                get_next_function_after_single_random(target_obs_type),
            )
        else:
            random_progress_label.config(text=random_station_config["map_build_message"])
            frame1.update_idletasks()
            print(f"[RANDOM] Ready to build 3-site map after {time.perf_counter() - random_flow_started:.2f} seconds.")
            random_progress_label.destroy()
            confirm_random_sites(back_function=back_function)
        print(f"[RANDOM] Total random site flow finished in {time.perf_counter() - random_flow_started:.2f} seconds.")

    except Exception as e:
        print(f"An error occurred in generate_random_sites: {e}")
        for widget in frame1.winfo_children():
            widget.destroy()
        error_label = tk.Label(frame1, text=f"Could not find random sites.\nError: {e}", font=("Helvetica", 14), bg=tk_background_color, fg="red", justify="center")
        error_label.pack(pady=50, padx=20)
        back_button = tk.Button(frame1, text="Back", font=("Helvetica", 16, "bold"), command=back_function or land_or_buoy)
        back_button.pack(pady=20)


def setup_aobs_input_land():
    """Sets up and calls xobs_input_land for the AOBS site."""
    print("Running setup_aobs_input_land...")
    land_ui_xobs_input_land(
        obs_type='aobs',
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=land_or_buoy,
        submit_command_handler=handle_aobs_submission,
        deps=_get_land_ui_dependencies(),
    )

def setup_bobs_input_land():
    """Sets up and calls xobs_input_land for the BOBS site."""
    print("Running setup_bobs_input_land...")
    land_ui_xobs_input_land(
        obs_type='bobs',
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=land_or_buoy,
        submit_command_handler=handle_bobs_submission,
        deps=_get_land_ui_dependencies(),
    )

def setup_cobs_input_land():
    """Sets up and calls xobs_input_land for the COBS site."""
    print("Running setup_cobs_input_land...")
    land_ui_xobs_input_land(
        obs_type='cobs',
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=land_or_buoy,
        submit_command_handler=handle_cobs_submission,
        deps=_get_land_ui_dependencies(),
    )

def recheck_cobs_stations():
    """
    Called by 'Back' button from page_choose.
    Re-runs xobs_check_land for COBS using stored town/state.
    """
    print("Back button pressed from page_choose. Re-running check for COBS...")
    try:
        # Access the stored COBS location from globals
        cobs_town = alternative_town_3
        cobs_state = alternative_state_3

        if not cobs_town or not cobs_state:
             print("Error: COBS town/state not found in globals for recheck.")
             # Optionally show an error message to the user
             # Maybe just go back to the input step?
             setup_cobs_input_land()
             return

        # Call xobs_check_land to rebuild the COBS station selection screen
        land_ui_xobs_check_land(
            obs_type='cobs',
            input_town=cobs_town,
            input_state=cobs_state,
            frame=frame1,
            tk_background_color=tk_background_color,
            button_font=button_font,
            back_command=setup_cobs_input_land,
            confirm_command_handler=handle_cobs_confirmation,
            deps=_get_land_ui_dependencies(),
        )
    except NameError as e:
        print(f"Error accessing needed variables/functions in recheck_cobs_stations: {e}")
    except Exception as e:
        print(f"Unexpected error in recheck_cobs_stations: {e}")

def _get_land_ui_dependencies():
    return {
        "globals_dict": globals(),
        "root": root,
        "keyboard_parent": frame1,
        "hide_display_frame_for_frame1": hide_display_frame_for_frame1,
        "create_virtual_keyboard": create_virtual_keyboard,
        "set_current_target": set_current_target,
        "set_keyboard_mode": set_keyboard_mode,
        "set_state_uppercase": set_state_uppercase,
        "auto_capitalize": auto_capitalize,
        "current_target_getter": lambda: current_target_entry,
        "create_small_weather_observer_logo": create_small_weather_observer_logo,
        "load_all_stations_cached_dicts": load_all_stations_cached_dicts,
        "chrome_driver_path": CHROME_DRIVER_PATH,
        "options_cls": Options,
        "service_cls": Service,
        "webdriver_module": webdriver,
        "by_cls": By,
        "os_module": os,
        "time_module": time,
        "signal_module": signal,
        "distance_func": geopy.distance.distance,
        "folium_module": folium,
        "land_or_buoy": land_or_buoy,
    }

def handle_aobs_confirmation(selected_station_data=None):
    """
    (Corrected) Handles the final confirmation for the AOBS station.
    - If called from the manual selection screen, it uses the provided data
      to update the global variables, avoiding a re-scrape.
    - If called from the random selection screen (with no data), it does nothing,
      as the globals have already been set.
    """
    global aobs_station_identifier, aobs_buoy_signal, alternative_town_1
    global atemp, awind, awtemp
    global aobs_only_click_flag, last_land_scrape_time

    # This is the key: only process data if it was passed in from the manual selection screen.
    selected_station_display = prepare_land_confirmation_display(
        selected_station_data,
        get_land_confirmation_slot_config("aobs"),
        obs_buttons_choice_abbreviations,
        globals(),
        apply_manual_land_confirmation_globals,
    )

    # The rest of the function determines which screen to show next.
    ordinal = "first"
    back_command = setup_aobs_input_land

    next_command = return_to_image_cycle if aobs_only_click_flag else bobs_land_or_buoy
    if aobs_only_click_flag:
        aobs_only_click_flag = False

    xobs_confirm_land(
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        selected_station_data=selected_station_display,
        ordinal_text=ordinal,
        back_command_for_confirm=back_command,
        next_command_for_confirm=next_command
    )

def handle_bobs_confirmation(selected_station_data=None):
    """(Corrected) Handles the final confirmation for the BOBS station."""
    global bobs_station_identifier, bobs_buoy_signal, alternative_town_2
    global btemp, bwind, bwtemp
    global bobs_only_click_flag, last_land_scrape_time

    selected_station_display = prepare_land_confirmation_display(
        selected_station_data,
        get_land_confirmation_slot_config("bobs"),
        obs_buttons_choice_abbreviations,
        globals(),
        apply_manual_land_confirmation_globals,
    )

    ordinal = "second"
    back_command = setup_bobs_input_land

    next_command = return_to_image_cycle if bobs_only_click_flag else cobs_land_or_buoy
    if bobs_only_click_flag:
        bobs_only_click_flag = False

    xobs_confirm_land(
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        selected_station_data=selected_station_display,
        ordinal_text=ordinal,
        back_command_for_confirm=back_command,
        next_command_for_confirm=next_command
    )

def handle_cobs_confirmation(selected_station_data=None):
    """(Corrected) Handles the final confirmation for the COBS station."""
    global cobs_station_identifier, cobs_buoy_signal, alternative_town_3
    global ctemp, cwind, cwtemp
    global cobs_only_click_flag, last_land_scrape_time

    selected_station_display = prepare_land_confirmation_display(
        selected_station_data,
        get_land_confirmation_slot_config("cobs"),
        obs_buttons_choice_abbreviations,
        globals(),
        apply_manual_land_confirmation_globals,
    )

    # This is your specific logic for resetting the timer.
    # It will run correctly for both manual and random paths.
    if not cobs_only_click_flag:
        print("[TIMER_RESET] Initial manual setup complete. Resetting observation timer.")
        last_land_scrape_time = datetime.now()
    
    ordinal = "third"
    back_command = setup_cobs_input_land

    next_command = return_to_image_cycle if cobs_only_click_flag else page_choose
    if cobs_only_click_flag:
        cobs_only_click_flag = False

    xobs_confirm_land(
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        selected_station_data=selected_station_display,
        ordinal_text=ordinal,
        back_command_for_confirm=back_command,
        next_command_for_confirm=next_command
    )

# --- Bridge Handler Functions for town/sate inputs for obs sites---

def handle_aobs_submission(entered_town, entered_state):
    """
    Bridge function called after AOBS input.
    Calls the (future) xobs_check_land function with necessary parameters.
    """
    print(f"\nSUBMIT HANDLER: Received AOBS input: Town='{entered_town}', State='{entered_state}'")
    print("Calling xobs_check_land for AOBS...")

    land_ui_xobs_check_land(
        obs_type='aobs',
        input_town=entered_town,
        input_state=entered_state,
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=setup_aobs_input_land,
        confirm_command_handler=handle_aobs_confirmation,
        deps=_get_land_ui_dependencies(),
    )

def handle_bobs_submission(entered_town, entered_state):
    """
    Bridge function called after BOBS input.
    Calls the (future) xobs_check_land function with necessary parameters.
    """
    print(f"\nSUBMIT HANDLER: Received BOBS input: Town='{entered_town}', State='{entered_state}'")
    print("Calling xobs_check_land for BOBS...")

    land_ui_xobs_check_land(
        obs_type='bobs',
        input_town=entered_town,
        input_state=entered_state,
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=setup_bobs_input_land,
        confirm_command_handler=handle_bobs_confirmation,
        deps=_get_land_ui_dependencies(),
    )

def handle_cobs_submission(entered_town, entered_state):
    """
    Bridge function called after COBS input.
    Calls the (future) xobs_check_land function with necessary parameters.
    """
    print(f"\nSUBMIT HANDLER: Received COBS input: Town='{entered_town}', State='{entered_state}'")
    print("Calling xobs_check_land for COBS...")

    land_ui_xobs_check_land(
        obs_type='cobs',
        input_town=entered_town,
        input_state=entered_state,
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=setup_cobs_input_land,
        confirm_command_handler=handle_cobs_confirmation,
        deps=_get_land_ui_dependencies(),
    )

def create_buoy_help_map_image(functional_buoys):
    create_buoy_help_map_screenshot(
        functional_buoys,
        CHROME_DRIVER_PATH,
        metadata_calculate_buoy_help_center,
        calculate_buoy_help_zoom_level,
        folium,
        Options,
        Service,
        webdriver,
        os,
        time,
        adjust_buoy_help_window_size,
    )
    
def receive_buoy_help_choice():
    global selected_buoy, buoy_help_flag, alternative_town_1, alternative_town_2, alternative_town_3
    # Retrieve the selected buoy's ID from the selected_buoy variable
    selected_buoy_code = normalize_station_id(selected_buoy.get())
    print("line 3856. inside receive buoy help choice.")        
    selected_handler = resolve_buoy_help_selection(
        buoy_help_flag,
        selected_buoy_code,
        apply_buoy_help_selection_globals,
        globals(),
        {
            "aobs": handle_aobs_buoy_submission,
            "bobs": handle_bobs_buoy_submission,
            "cobs": handle_cobs_buoy_submission,
        },
    )
    if buoy_help_flag == 'aobs':
        print("line 3858. inside receive buoy help choice, inside buoy help flag a.")

    if selected_handler:
        buoy_help_flag = None
        selected_handler(selected_buoy_code)

def show_buoy_help_choice(functional_buoys, buoy_cache):
    """
    (Refactored) Displays 3 functional buoys as radio buttons for user selection.

    This version scrapes the data for each button directly from the NDBC RSS feed,
    removing the dependency on the old buoy_cache.
    """
    global selected_buoy, buoy_help_flag

    choice_entries = build_buoy_help_choice_entries(
        functional_buoys,
        lambda buoy_id: get_recent_buoy_rss_observation(
            buoy_id,
            timedelta(days=3650),
            requests,
            ElementTree,
            parser,
            datetime,
            timezone,
            timeout=10,
        ),
        build_buoy_choice_text_from_description,
    )
            
    # --- UI Setup (UNCHANGED) ---
    for widget in frame1.winfo_children():
        widget.destroy()
    frame1.grid_columnconfigure(9, weight=1)
    ordinal = get_obs_ordinal(buoy_help_flag or "cobs")
    instruction_text = f"Please choose a buoy for the {ordinal} observation site."
    add_modern_screen_text(
        frame1,
        tk,
        tk_background_color,
        "The Weather Observer",
        instruction_text,
        title_row=0,
        body_row=1,
        title_padx=50,
        title_pady=(20, 0),
        body_padx=50,
        body_pady=3,
        title_columnspan=9,
        body_columnspan=9,
        sticky="nw",
    )
    instruction_text_2 = "Due to communication issues, not every available buoy will list every time this list is assembled."
    instructions_label_2 = tk.Label(frame1, text=instruction_text_2, font=("Helvetica Neue", 12), fg="#4f6b7d", bg=tk_background_color, justify="left", wraplength=800)
    instructions_label_2.grid(row=2, column=0, columnspan=9, padx=50, pady=3, sticky='nw')

    selected_buoy = tk.StringVar()
    def enable_submit(*args):
        submit_button.config(state="normal")
    selected_buoy.trace_add('write', enable_submit)

    # --- Create Radio Buttons (NEW LOGIC) ---
    for idx, choice_entry in enumerate(choice_entries):
        buoy_id = choice_entry["buoy_id"]
        buoy_info = choice_entry["button_text"]

        # Set button position (UNCHANGED)
        if idx == 0: button_pady = (2, 2)
        elif idx == 1: button_pady = (120, 2)
        else: button_pady = (240, 20)
        fixed_width = 33

        # Add radio button for each buoy
        tk.Radiobutton(frame1, text=buoy_info, variable=selected_buoy, value=buoy_id, bg=tk_background_color,
                        font=("Helvetica", 12), justify="left", anchor="w", padx=10, pady=14,
                        relief="raised", borderwidth=1, width=fixed_width).grid(row=3, column=0, columnspan=9, padx=50, pady=button_pady, sticky="nw")

    # --- Map and Submit Button Creation (UNCHANGED) ---
    create_buoy_help_map_image(functional_buoys)
    
    img_path = "/home/santod/buoy_locations.png"
    img = Image.open(img_path)
    img = img.resize((450, 300), Image.LANCZOS)
    tk_img = ImageTk.PhotoImage(img)
    
    label = tk.Label(frame1, image=tk_img)
    label.image = tk_img
    label.grid(row=3, column=8, sticky="se", padx=(360, 10), pady=(142, 5))
    
    img.close()
    try: os.remove(img_path)
    except FileNotFoundError: pass
    
    submit_button = create_modern_button(frame1, tk, "Submit", receive_buoy_help_choice, font=("Helvetica Neue", 16, "bold"), variant="primary")
    submit_button.config(state="disabled")
    submit_button.grid(row=3, column=0, rowspan=4, padx=50, pady=(386,10), sticky="nw")


def adjust_buoy_help_window_size(driver, target_width, target_height):
    # Run JavaScript to get the size of the visible content area
    width = driver.execute_script("return window.innerWidth;")
    height = driver.execute_script("return window.innerHeight;")
    
    # Calculate the difference between the actual and desired dimensions
    width_diff = target_width - width
    height_diff = target_height - height

    # Adjust the window size based on the difference
    current_window_size = driver.get_window_size()
    new_width = current_window_size['width'] + width_diff
    new_height = current_window_size['height'] + height_diff
    driver.set_window_size(new_width, new_height)
    
def calculate_buoy_help_distance(point1, point2):

    return geodesic(point1, point2).kilometers

def calculate_buoy_help_zoom_level(functional_buoys):
    return metadata_calculate_buoy_help_zoom_level(functional_buoys, geodesic)

def find_buoy_choice(buoy_search_lat, buoy_search_lon):
    """
    (Refactored) Finds 3 functional buoys near a given location.

    This version uses a local JSON file for buoy locations and scrapes the
    NDBC RSS feed to check for recent activity, completely removing the
    dependency on MesoWest. It preserves the parallel execution for performance.
    """
    print("\n--- Running find_buoy_choice (Refactored) ---")
    
    # --- Configuration ---
    # This is now the single place to adjust how old a report can be.
    MAX_OBS_AGE = timedelta(hours=5)

    # --- Helper Functions ---

    # def load_buoy_help_locations():
        # """
        # Loads the master list of buoy locations from the local JSON file.
        # This is much faster and more reliable than a live download.
        # """
        # try:
            # with open("/home/santod/buoy_metadata.json") as f:
                # return json.load(f)
        # except Exception as e:
            # print(f"Error: Could not load buoy metadata file: {e}")
            # return []

    current_location = (buoy_search_lat, buoy_search_lon)

    final_buoy_list = gather_buoy_help_choices(
        current_location,
        "/home/santod/buoy_metadata.json",
        load_buoy_metadata_cached,
        lambda search_location, all_buoys: find_buoy_help_nearest_buoys(
            search_location,
            all_buoys,
            geodesic,
        ),
        lambda nearest_buoys: fetch_functional_buoy_help_candidates(
            nearest_buoys,
            10,
            lambda buoy_id: check_buoy_help_functionality(
                buoy_id,
                MAX_OBS_AGE,
                requests,
                ElementTree,
                parser,
                datetime,
                timezone,
            ),
            concurrent.futures,
        ),
        build_buoy_help_final_list,
    )

    if len(final_buoy_list) >= 3:
        print("\n--- Final Functional Buoys ---")
        for buoy_info in final_buoy_list:
            print(f"ID: {buoy_info[0]}, Lat: {buoy_info[1]}, Lon: {buoy_info[2]}")
        print("------------------------------")
        
        # Call the existing map display function with the results
        show_buoy_help_choice(final_buoy_list, {})

    else:
        print("Could not find at least 3 functional buoys within range.")

def submit_buoy_help_town():
    # Get the user's input from the entry boxes
    normalized_input = normalize_buoy_help_town_state_input(
        buoy_help_town_entry.get(),
        buoy_help_state_entry.get(),
    )
    town = normalized_input["town"]
    state = normalized_input["state"]

    # Initialize the geolocator
    geolocator = Nominatim(user_agent="buoy_locator")

    try:
        submit_buoy_help_town_workflow(
            town,
            state,
            geolocator,
            find_buoy_choice,
        )
    except GeocoderTimedOut:
        print("The geocoding service timed out. Please try again.")


def submit_buoy_help_coord():
    global buoy_search_lat, buoy_search_lon
    # Retrieve the values from the entry boxes
    lat_value = buoy_search_lat.get()
    lon_value = buoy_search_lon.get()
    
    try:
        buoy_search_lat, buoy_search_lon = submit_buoy_help_coord_workflow(
            lat_value,
            lon_value,
            parse_buoy_help_coordinates,
            find_buoy_choice,
        )
    except ValueError:
        # Handle invalid input (non-numeric values, etc.)
        print("Invalid latitude or longitude entered. Please try again.")


def buoy_near_me():
    global buoy_search_lat, buoy_search_lon
    
    buoy_search_lat, buoy_search_lon = submit_buoy_help_near_me_workflow(
        latitude,
        longitude,
        find_buoy_choice,
    )
    
def buoy_help_by_town():
    global buoy_help_town_entry, buoy_help_state_entry
    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()

    frame1.grid(row=0, column=0, sticky="nsew")

    instruction_text = "Please enter the name of the town from which to search for buoys:"
    add_modern_screen_text(
        frame1,
        tk,
        tk_background_color,
        "The Weather Observer",
        instruction_text,
        title_row=0,
        body_row=1,
        title_padx=50,
        title_pady=(50, 0),
        body_padx=50,
        body_pady=5,
        title_columnspan=20,
        body_columnspan=20,
        sticky="nw",
    )

    buoy_help_town_entry = tk.Entry(frame1, font=("Helvetica", 14))
    buoy_help_town_entry.grid(row=2, column=0, columnspan=20, padx=50, pady=4, sticky='nw')
    style_input_entry(buoy_help_town_entry)
    set_keyboard_mode(buoy_help_town_entry, "town")

    # Automatically set focus to the town_entry widget
    buoy_help_town_entry.focus_set()

    state_instruction_text = "Please enter the 2-letter state ID:"
    state_instructions_label = tk.Label(frame1, text=state_instruction_text, font=("Helvetica Neue", 15), fg="#4f6b7d", bg=tk_background_color, justify="left")
    state_instructions_label.grid(row=3, column=0, columnspan=20, padx=50, pady=4, sticky='nw')

    buoy_help_state_entry = tk.Entry(frame1, font=("Helvetica", 14))
    buoy_help_state_entry.grid(row=4, column=0, columnspan=20, padx=50, pady=4, sticky='nw')
    style_input_entry(buoy_help_state_entry)
    set_keyboard_mode(buoy_help_state_entry, "state")

    instruction_text_2 = "After clicking SUBMIT, the system will pause while gathering a list of functioning buoys."
    instructions_label_2 = tk.Label(frame1, text=instruction_text_2, font=("Helvetica Neue", 12), fg="#4f6b7d", bg=tk_background_color, justify="left")
    instructions_label_2.grid(row=5, column=0, columnspan=20, padx=50, pady=4, sticky='nw')

    # Create the 'Back' button
    back_button = create_modern_button(frame1, tk, " Back ", buoy_help, font=button_font, variant="secondary")
    back_button.grid(row=6, column=0, columnspan=20, padx=(50, 0), pady=5, sticky="w")

    submit_button = create_modern_button(frame1, tk, "Submit", submit_buoy_help_town, font=button_font, variant="primary")
    submit_button.grid(row=6, column=0, columnspan=20, padx=200, pady=5, sticky='nw')

    buoy_help_town_entry.bind("<FocusIn>", lambda e: set_current_target(buoy_help_town_entry))
    buoy_help_state_entry.bind("<FocusIn>", lambda e: set_current_target(buoy_help_state_entry))

    # Spacer to push the keyboard to the bottom
    spacer = tk.Label(frame1, text="", bg=tk_background_color)
    spacer.grid(row=7, column=0, sticky="nsew", pady=(0, 0))
    
    # Display the virtual keyboard
    create_virtual_keyboard(frame1, 7)

def buoy_help_by_coord():
    global buoy_search_lat, buoy_search_lon
    
    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()

    frame1.grid(row=0, column=0, sticky="nsew")

    instruction_text = "Please enter the latitude and longitude from which to start searching for buoys:"
    add_modern_screen_text(
        frame1,
        tk,
        tk_background_color,
        "The Weather Observer",
        instruction_text,
        title_row=0,
        body_row=1,
        title_padx=50,
        title_pady=(50, 0),
        body_padx=50,
        body_pady=5,
        title_columnspan=6,
        body_columnspan=6,
        sticky="nw",
    )

    # Latitude Entry with degree symbol and 'N' all in one row using grid
    lat_label = tk.Label(frame1, text="Latitude:", font=("Helvetica Neue", 14, "bold"), fg="#163247", bg=tk_background_color)
    lat_label.grid(row=2, column=0, padx=(50, 8), pady=5, sticky='w')
    buoy_search_lat = tk.Entry(frame1, font=("Helvetica", 14), width=6)  # Adjust width for 'XXX.X'
    buoy_search_lat.grid(row=2, column=0, padx=(165, 0), pady=5, sticky='w')
    style_input_entry(buoy_search_lat)
    set_keyboard_mode(buoy_search_lat, "numeric", allowed_chars="-0123456789.")
    lat_symbol = tk.Label(frame1, text="°N", font=("Helvetica Neue", 14), fg="#4f6b7d", bg=tk_background_color)
    lat_symbol.grid(row=2, column=0, padx=(223, 0), pady=5, sticky='w')

    # Automatically set focus to the latitude entry widget
    buoy_search_lat.focus_set()

    # Longitude Entry with degree symbol and 'W' all in one row using grid
    lon_label = tk.Label(frame1, text="Longitude:", font=("Helvetica Neue", 14, "bold"), fg="#163247", bg=tk_background_color)
    lon_label.grid(row=3, column=0, padx=(50, 8), pady=5, sticky='w')
    buoy_search_lon = tk.Entry(frame1, font=("Helvetica", 14), width=6)  # Adjust width for 'XXX.X'
    buoy_search_lon.grid(row=3, column=0, padx=(165, 0), pady=5, sticky='w')
    style_input_entry(buoy_search_lon)
    set_keyboard_mode(buoy_search_lon, "numeric", allowed_chars="-0123456789.")
    lon_symbol = tk.Label(frame1, text="°W", font=("Helvetica Neue", 14), fg="#4f6b7d", bg=tk_background_color)
    lon_symbol.grid(row=3, column=0, padx=(223, 0), pady=5, sticky='w')

    instruction_text_2 = "After clicking SUBMIT, the system will pause while gathering a list of functioning buoys."
    instructions_label_2 = tk.Label(frame1, text=instruction_text_2, font=("Helvetica Neue", 12), fg="#4f6b7d", bg=tk_background_color, justify="left")
    instructions_label_2.grid(row=4, column=0, columnspan=6, padx=50, pady=10, sticky='nw')

    # Create the 'Back' button
    back_button = create_modern_button(frame1, tk, " Back ", buoy_help, font=button_font, variant="secondary")
    back_button.grid(row=5, column=0, padx=(50, 0), pady=5, sticky="w")

    submit_button = create_modern_button(frame1, tk, "Submit", submit_buoy_help_coord, font=button_font, variant="primary")
    submit_button.grid(row=5, column=0, padx=150, pady=5, sticky='w')

    buoy_search_lat.bind("<FocusIn>", lambda e: set_current_target(buoy_search_lat))
    buoy_search_lon.bind("<FocusIn>", lambda e: set_current_target(buoy_search_lon))

    spacer = tk.Label(frame1, text="", bg=tk_background_color)
    spacer.grid(row=6, column=0, columnspan=6, sticky="nsew", pady=(0, 4))

    # Display the virtual keyboard at a lower position (start_row shifted down)
    create_virtual_keyboard(frame1, 8)

def buoy_help():
    
    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()

    frame1.grid(row=0, column=0, sticky="nsew")

    instruction_text = "Choose how you would like to search for buoy codes."
    add_modern_screen_text(
        frame1,
        tk,
        tk_background_color,
        "The Weather Observer",
        instruction_text,
        title_row=0,
        body_row=1,
        title_padx=50,
        title_pady=(50, 50),
        body_padx=50,
        body_pady=15,
        title_columnspan=20,
        body_columnspan=20,
        sticky="nw",
    )
    
    buoy_nearby_button = create_modern_button(frame1, tk, "Buoys Near Me", buoy_near_me, font=("Helvetica Neue", 13, "bold"), variant="secondary")
    buoy_nearby_button.grid(row=3, column=0, columnspan=20, padx=50, pady=5, sticky='nw')
    
    buoy_town_button = create_modern_button(frame1, tk, "Town/State", buoy_help_by_town, font=("Helvetica Neue", 13, "bold"), variant="secondary")
    buoy_town_button.grid(row=3, column=0, columnspan=20, padx=240, pady=5, sticky='nw')
    
    buoy_coordinates_button = create_modern_button(frame1, tk, "Latitude/Longitude", buoy_help_by_coord, font=("Helvetica Neue", 13, "bold"), variant="secondary")
    buoy_coordinates_button.grid(row=3, column=0, columnspan=20, padx=395, pady=5, sticky='nw')
  
def setup_aobs_input_buoy():
    """Sets up and calls buoy_obs_input for the AOBS (first) site."""
    print("Running setup_aobs_input_buoy...")

    buoy_obs_input(
        obs_type='aobs',
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=land_or_buoy,
        help_command=buoy_help,
        submit_command_handler=handle_aobs_buoy_submission,
    )

def setup_bobs_input_buoy():
    """Sets up and calls buoy_obs_input for the BOBS (second) site."""
    print("Running setup_bobs_input_buoy...")

    buoy_obs_input(
        obs_type='bobs',
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=bobs_land_or_buoy,
        help_command=buoy_help,
        submit_command_handler=handle_bobs_buoy_submission,
    )

def setup_cobs_input_buoy():
    """Sets up and calls buoy_obs_input for the COBS (third) site."""
    print("Running setup_cobs_input_buoy...")

    buoy_obs_input(
        obs_type='cobs',
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=cobs_land_or_buoy,
        help_command=buoy_help,
        submit_command_handler=handle_cobs_buoy_submission,
    )


def buoy_obs_check(obs_type, buoy_code, frame, tk_background_color, button_font, success_next_command, failure_back_command):
    """
    (Refactored v2) Checks buoy validity, then performs a synchronous data
    fetch to ensure the UI is updated immediately.
    """
    # --- Initial Setup (UNCHANGED) ---
    for widget in frame.winfo_children():
        widget.destroy()
    hide_display_frame_for_frame1()
    frame.grid(row=0, column=0, sticky="nsew")
    frame.tkraise()
    frame.configure(bg=tk_background_color)

    # Determine ordinal (UNCHANGED)
    buoy_selection_details = apply_buoy_selection_globals(
        obs_type,
        buoy_code,
        globals(),
    )
    ordinal = buoy_selection_details["ordinal"]
    current_only_click_flag = buoy_selection_details["current_only_click_flag"]

    add_modern_screen_text(
        frame,
        tk,
        tk_background_color,
        "The Weather Observer",
        "",
        title_row=0,
        body_row=1,
        title_padx=50,
        title_pady=(50, 0),
        body_padx=50,
        body_pady=0,
        title_columnspan=20,
        body_columnspan=20,
        sticky="w",
    )

    # --- Buoy Check via NDBC RSS Feed (UNCHANGED) ---
    print(f"Checking NDBC RSS feed for buoy: {buoy_code}")
    next_function = None
    message_label = None

    validation_result = validate_buoy_observation_workflow(
        obs_type,
        buoy_code,
        current_only_click_flag,
        globals(),
        lambda requested_buoy_code: get_recent_buoy_rss_observation(
            requested_buoy_code,
            timedelta(hours=5),
            requests,
            ElementTree,
            parser,
            datetime,
            timezone,
            timeout=15,
        ),
        get_buoy_data,
        populate_single_buoy_observation_globals,
        clear_obs_only_click_flag,
        success_next_command,
        failure_back_command,
        return_to_image_cycle,
    )

    if validation_result["success"]:
        accept_text = f"Buoy {buoy_code} will be used for the {ordinal} observation site."
        message_label = tk.Label(frame, text=accept_text, font=("Helvetica Neue", 15), fg="black", bg=tk_background_color, justify="left")
        next_function = validation_result["next_function"]
    else:
        message_label = tk.Label(
            frame,
            text=validation_result["message_text"],
            font=("Helvetica Neue", 15),
            fg="black",
            bg=tk_background_color,
            justify="left",
        )
        next_function = validation_result["next_function"]

    # --- Display Message and Next Button (UNCHANGED) ---
    if message_label:
        message_label.grid(row=1, column=0, padx=50, pady=(20,10), sticky="w")

    if next_function:
        next_button_text = " Next " if next_function == success_next_command or next_function == return_to_image_cycle else " Back "
        if "Next" in next_button_text:
            next_button = create_modern_button(frame, tk, next_button_text, next_function, font=button_font, variant="primary")
            next_button.grid(row=3, column=0, padx=(200, 0), pady=10, sticky="w")
            back_button = create_modern_button(frame, tk, " Back ", failure_back_command, font=button_font, variant="secondary")
            back_button.grid(row=3, column=0, padx=(50, 0), pady=10, sticky="w")
        else:
            next_button = create_modern_button(frame, tk, next_button_text, next_function, font=button_font, variant="secondary")
            next_button.grid(row=3, column=0, padx=(50, 0), pady=10, sticky="w")
    else:
        print("Error: Next function was not determined.")
        fallback_label = tk.Label(frame, text="An unexpected error occurred.", font=("Helvetica", 16,), bg=tk_background_color)
        fallback_label.grid(row=1, column=0, padx=50, pady=(20,10), sticky="w")

def handle_aobs_buoy_submission(buoy_code):
    """
    Handles submission for AOBS buoy input.
    Assigns the code to alternative_town_1 and calls the check function.
    """
    print(f"HANDLER AOBS: Received code '{buoy_code}'. Assigning to alternative_town_1.")
    print("HANDLER AOBS: Calling buoy_obs_check")
    apply_buoy_display_name('aobs', buoy_code, globals())
    buoy_obs_check(
        obs_type='aobs',
        buoy_code=buoy_code,
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        success_next_command=bobs_land_or_buoy,
        failure_back_command=land_or_buoy,
    )

def handle_bobs_buoy_submission(buoy_code):
    """
    Handles submission for BOBS buoy input.
    Assigns the code to alternative_town_2 and calls the check function.
    """
    print(f"HANDLER BOBS: Received code '{buoy_code}'. Assigning to alternative_town_2.")
    print("HANDLER BOBS: Calling buoy_obs_check")
    apply_buoy_display_name('bobs', buoy_code, globals())
    buoy_obs_check(
        obs_type='bobs',
        buoy_code=buoy_code,
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        success_next_command=cobs_land_or_buoy,
        failure_back_command=bobs_land_or_buoy,
    )

def handle_cobs_buoy_submission(buoy_code):
    """
    Handles submission for COBS buoy input.
    Assigns the code to alternative_town_3 and calls the check function.
    """
    print(f"HANDLER COBS: Received code '{buoy_code}'. Assigning to alternative_town_3.")
    print("HANDLER COBS: Calling buoy_obs_check")
    apply_buoy_display_name('cobs', buoy_code, globals())
    buoy_obs_check(
        obs_type='cobs',
        buoy_code=buoy_code,
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        success_next_command=page_choose,
        failure_back_command=cobs_land_or_buoy,
    )


def buoy_obs_input(obs_type, frame, tk_background_color, button_font, back_command, help_command, submit_command_handler):
    """
    Displays UI for entering the 5-character buoy code for a given observation type.

    Args:
        obs_type (str): 'aobs', 'bobs', or 'cobs'.
        frame (tk.Frame): The parent frame to build the UI in.
        tk_background_color (str): Background color for widgets.
        button_font (tuple): Font tuple for buttons (e.g., ("Helvetica", 14, "bold")).
        back_command (callable): Function to call when Back button is pressed.
        help_command (callable): buoy_help.
        submit_command_handler (callable): Function to call with the entered buoy code
                                           when Submit button is pressed.
    """
    global is_buoy_code, current_target_entry, buoy_help_flag, frame1_overlay_lock

    frame1_overlay_lock = True

    # Reset current_target_entry for this input screen
    current_target_entry = None

    ordinal = get_obs_ordinal(obs_type)
    buoy_help_flag = obs_type if obs_type in {"aobs", "bobs", "cobs"} else None

    # Clear the current display in the target frame
    for widget in frame.winfo_children():
        widget.destroy()
    hide_display_frame_for_frame1()

    frame.grid(row=0, column=0, sticky="nsew")
    frame.tkraise()
    frame.configure(bg=tk_background_color) # Ensure frame background is set

    # --- UI Elements ---
    instruction_text = f"Please enter the 5-character code for the buoy for the {ordinal} site:"
    add_modern_screen_text(
        frame,
        tk,
        tk_background_color,
        "The Weather Observer",
        instruction_text,
        title_row=0,
        body_row=1,
        title_padx=50,
        title_pady=(50, 0),
        body_padx=50,
        body_pady=5,
        title_columnspan=20,
        body_columnspan=20,
        sticky="nw",
    )

    # Use a local variable for the entry widget
    buoy_code_entry = tk.Entry(frame, font=("Helvetica", 14))
    buoy_code_entry.grid(row=2, column=0, columnspan=20, padx=50, pady=5, sticky='nw')
    style_input_entry(buoy_code_entry)
    set_keyboard_mode(buoy_code_entry, "buoy")

    # --- Internal Submit Logic ---
    def _on_submit():
        # Get the user's input
        entered_code = normalize_station_id(buoy_code_entry.get())

        if len(entered_code) != 5:
            print(f"Error: Buoy code '{entered_code}' is not 5 characters long.")
            # Optional: Display error message to user (e.g., using tk.messagebox or a label)
            # Re-create keyboard if needed, or simply return to allow re-entry
            # create_virtual_keyboard(frame, 7) # Recreate if needed
            # buoy_code_entry.focus_set()       # Set focus back
            tk.messagebox.showerror("Input Error", "Buoy code must be exactly 5 characters long.", parent=frame)
            return # Stop processing if invalid

        # Add more validation if needed (e.g., check if alphanumeric)

        print(f"Submit clicked for {obs_type.upper()}. Buoy Code: '{entered_code}'")

        # Call the specific handler function passed in, providing the validated code
        submit_command_handler(entered_code)

    # --- Buttons ---
    submit_button = create_modern_button(frame, tk, "Submit", _on_submit, font=button_font, variant="primary")
    submit_button.grid(row=3, column=0, columnspan=20, padx=(180, 0), pady=5, sticky='nw')

    help_option_text = "Or, if you want to choose a buoy and need help getting the code, click Buoy Help."
    help_option_label = tk.Label(frame, text=help_option_text, font=("Helvetica Neue", 15), fg="black", bg=tk_background_color, justify="left")
    help_option_label.grid(row=4, column=0, columnspan=20, padx=50, pady=5, sticky='nw') # Match original layout

    # Use the help_command passed in
    help_button = create_modern_button(frame, tk, "Buoy Help", help_command, font=("Helvetica Neue", 14, "bold"), variant="secondary")
    help_button.grid(row=5, column=0, columnspan=20, padx=50, pady=5, sticky='nw') # Match original layout

    back_button = create_modern_button(frame, tk, " Back ", back_command, font=button_font, variant="secondary")
    back_button.grid(row=3, column=0, columnspan=20, padx=50, pady=5, sticky='nw')

    # Optional: Add a Back button if needed, using back_command
    # back_button = tk.Button(frame, text=" Back ", font=button_font, command=back_command)
    # back_button.grid(row=X, column=Y, ...) # Position as needed

    # Spacer to push the keyboard to the bottom
    # --- Bindings and Focus ---
    buoy_code_entry.bind("<FocusIn>", lambda e: set_current_target(buoy_code_entry))

    # Automatically set focus to the entry widget
    buoy_code_entry.focus_set()

    # Set flag for keyboard type
    is_buoy_code = True

    # Display the alphanumeric keyboard (adjust row as needed based on final layout)
    create_virtual_keyboard(frame, 6) # nudged up slightly so keyboard stays fully visible
    

def xobs_confirm_land(frame, tk_background_color, button_font,
                      selected_station_data, ordinal_text,
                      back_command_for_confirm, next_command_for_confirm):
    """
    Displays the confirmation screen after a station is chosen.

    Args:
        frame: The target Tkinter frame.
        tk_background_color: Background color string.
        button_font: Tkinter font object for buttons.
        selected_station_data (dict): Dictionary containing info about the chosen station (needs at least 'name').
        ordinal_text (str): "first", "second", or "third".
        back_command_for_confirm (callable): Function for the Back button.
        next_command_for_confirm (callable): Function for the Next button.
    """
    
    global alternative_town_1, alternative_town_2, alternative_town_3
    
    print(f"--- Running xobs_confirm_land ---")
    print(f"  Confirming: {selected_station_data.get('name', 'N/A')} as {ordinal_text} site.")
    print(f"  Back command: {back_command_for_confirm.__name__ if callable(back_command_for_confirm) else 'None'}")
    print(f"  Next command: {next_command_for_confirm.__name__ if callable(next_command_for_confirm) else 'None'}")
    
    # 1. Clear the current frame
    for widget in frame.winfo_children():
        widget.destroy()
    frame.configure(bg=tk_background_color)
    # Ensure frame is gridded if it lost its parent config (usually not needed if frame itself wasn't destroyed)
    # frame.grid(row=0, column=0, sticky="nsew") # Re-grid if necessary

    # 2. Display the confirmation labels
    # Use station name from the passed data
    station_name = selected_station_data.get('name', 'Selected Station') # Fallback name
    instruction_text1 = f"{station_name}"
    add_modern_screen_text(
        frame,
        tk,
        tk_background_color,
        "The Weather Observer",
        instruction_text1,
        title_row=0,
        body_row=1,
        title_padx=50,
        title_pady=(50, 0),
        body_padx=50,
        body_pady=(20, 5),
        title_columnspan=1,
        body_columnspan=1,
        sticky="w",
    )

    instruction_text2 = f"will be used for the {ordinal_text} observation site."
    instructions_label2 = tk.Label(frame, text=instruction_text2, font=("Helvetica Neue", 15), fg="black", bg=tk_background_color)
    instructions_label2.grid(row=2, column=0, padx=50, pady=(5, 10), sticky='w') # Match original padding

    # 3. Create Back and Next buttons using passed commands
    # Assuming create_button is available:
    try:
        back_button = create_modern_button(frame, tk, " Back ", back_command_for_confirm, font=button_font, variant="secondary")
        back_button.grid(row=4, column=0, padx=(50, 0), pady=10, sticky="w")

        next_button = create_modern_button(frame, tk, " Next ", next_command_for_confirm, font=button_font, variant="primary")
        next_button.grid(row=4, column=0, padx=(200, 0), pady=10, sticky="w")
    except NameError:
        # Fallback if create_button doesn't exist
        print("Warning: create_button function not found. Using standard tk.Button.")
        back_button = create_modern_button(frame, tk, " Back ", back_command_for_confirm, font=button_font, variant="secondary")
        back_button.grid(row=4, column=0, padx=(50, 0), pady=10, sticky="w")

        next_button = create_modern_button(frame, tk, " Next ", next_command_for_confirm, font=button_font, variant="primary")
        next_button.grid(row=4, column=0, padx=(200, 0), pady=10, sticky="w")

    print(f"--- xobs_confirm_land UI build complete ---")   
                
            
def create_button(frame1, text, font, command_func):
    button = tk.Button(frame1, text=text, font=font, command=command_func)
    return button

def remove_checkbox():
    choice_check_button.destory()

def choose_lcl_radar():
    """
    Displays the local radar site selection map.
    Loads map and metadata directly from files each time.
    """
    global box_variables, submit_button, RADAR_PAGE_LEFT_PANEL, RADAR_PAGE_STATUS_PANEL, RADAR_PAGE_DYNAMIC_MESSAGE_LABEL, RADAR_PAGE_MESSAGE_AREA # Add any other globals this function MODIFIES (like closest_site, etc. if needed globally)
                         # Globals only ACCESSED don't strictly need declaration here but doesn't hurt

    # Inside choose_lcl_radar, before defining lcl_radar_on_click
    
    submit_button = None # Initialize the global variable

    # --- 1. Check if map data was unavailable during initialization ---
    if lcl_radar_map_unavailable:
        # Clear the current display
        for widget in frame1.winfo_children():
            widget.destroy()
        frame1.grid(row=0, column=0, sticky="nsew") # Ensure frame is clean
        frame1.tkraise()

        # Display the error message and the Next button
        unavailable_message = "The map showing local radar stations failed to load during startup and is unavailable."
        add_modern_screen_text(
            frame1,
            tk,
            tk_background_color,
            "The Weather Observer",
            unavailable_message,
            title_row=0,
            body_row=1,
            title_padx=50,
            title_pady=(50, 10),
            body_padx=50,
            body_pady=(20, 20),
            title_columnspan=20,
            body_columnspan=20,
            sticky="nw",
        )
        box_variables[2] = 0 # Assuming this state change is appropriate on failure
        next_button = create_modern_button(frame1, tk, "Next", lightning_center_input, font=("Helvetica", 16, "bold"), variant="primary")
        next_button.grid(row=2, column=0, padx=50, pady=20, sticky="nw")
        return # Stop execution of this function

    # --- 2. Load map and metadata directly from files ---
    lcl_radar_map_path = "/home/santod/lcl_radar_map.png"
    lcl_radar_metadata_path = "/home/santod/lcl_radar_metadata.json"
    map_screenshot_image = None
    radar_sites = None

    try:
        map_screenshot_image = Image.open(lcl_radar_map_path)

        with open(lcl_radar_metadata_path, "r") as metadata_file:
            radar_sites = json.load(metadata_file)

        # Basic validation
        if not isinstance(radar_sites, list):
             print("[ERROR] Radar metadata does not contain a list.")
             raise ValueError("Invalid metadata format: expected a list.")

    except FileNotFoundError:
        error_message = f"Error: Required map or metadata file not found.\nExpected at:\n{lcl_radar_map_path}\n{lcl_radar_metadata_path}"
        print(f"[ERROR] choose_lcl_radar: {error_message}")
        # Display error in GUI
        for widget in frame1.winfo_children(): widget.destroy()
        frame1.grid(row=0, column=0, sticky="nsew")
        frame1.tkraise()
        add_modern_screen_text(
            frame1,
            tk,
            tk_background_color,
            "The Weather Observer",
            error_message,
            title_row=0,
            body_row=1,
            title_padx=50,
            title_pady=(50, 10),
            body_padx=50,
            body_pady=(20, 20),
            title_columnspan=20,
            body_columnspan=20,
            sticky="nw",
        )
        box_variables[2] = 0
        create_modern_button(frame1, tk, "Next", lightning_center_input, font=("Helvetica", 16, "bold"), variant="primary").grid(row=2, column=0, padx=50, pady=20, sticky="nw")
        return
    except json.JSONDecodeError as e:
        error_message = f"Error decoding radar metadata file:\n{lcl_radar_metadata_path}\nDetails: {e}"
        print(f"[ERROR] choose_lcl_radar: {error_message}")
        # Display error in GUI (similar to FileNotFoundError)
        for widget in frame1.winfo_children(): widget.destroy()
        frame1.grid(row=0, column=0, sticky="nsew")
        frame1.tkraise()
        add_modern_screen_text(
            frame1,
            tk,
            tk_background_color,
            "The Weather Observer",
            error_message,
            title_row=0,
            body_row=1,
            title_padx=50,
            title_pady=(50, 10),
            body_padx=50,
            body_pady=(20, 20),
            title_columnspan=20,
            body_columnspan=20,
            sticky="nw",
        )
        box_variables[2] = 0
        create_modern_button(frame1, tk, "Next", lightning_center_input, font=("Helvetica", 16, "bold"), variant="primary").grid(row=2, column=0, padx=50, pady=20, sticky="nw")
        return
    except Exception as e:
        error_message = f"An unexpected error occurred loading map/metadata:\n{e}"
        print(f"[ERROR] choose_lcl_radar: {error_message}")
        # Display error in GUI (similar to FileNotFoundError)
        for widget in frame1.winfo_children(): widget.destroy()
        frame1.grid(row=0, column=0, sticky="nsew")
        frame1.tkraise()
        add_modern_screen_text(
            frame1,
            tk,
            tk_background_color,
            "The Weather Observer",
            error_message,
            title_row=0,
            body_row=1,
            title_padx=50,
            title_pady=(50, 10),
            body_padx=50,
            body_pady=(20, 20),
            title_columnspan=20,
            body_columnspan=20,
            sticky="nw",
        )
        box_variables[2] = 0
        create_modern_button(frame1, tk, "Next", lightning_center_input, font=("Helvetica", 16, "bold"), variant="primary").grid(row=2, column=0, padx=50, pady=20, sticky="nw")
        return

    # --- 3. Prepare frame and data (if loading succeeded) ---
    if box_variables[2] == 0: # Check from original logic
        lightning_center_input()

    # Clear the current display now that we know loading worked
    for widget in frame1.winfo_children():
        widget.destroy()
    frame1.grid(row=0, column=0, sticky="nsew") # Reset frame
    frame1.tkraise()


    radar_page_frame = tk.Frame(frame1, bg=tk_background_color)
    radar_page_frame.grid(row=0, column=0, sticky="nsew")

    header_frame = tk.Frame(radar_page_frame, bg=tk_background_color)
    header_frame.grid(row=0, column=0, columnspan=2, padx=40, pady=(18, 10), sticky="w")

    radar_logo = create_small_weather_observer_logo(header_frame, size=(65, 65))
    radar_logo.grid(row=0, column=0, padx=(0, 6), pady=(6, 0), sticky="w")

    header_text_frame = tk.Frame(header_frame, bg=tk_background_color)
    header_text_frame.grid(row=0, column=1, sticky="w")

    title_label = tk.Label(header_text_frame, text="The Weather Observer", font=("Helvetica Neue", 18, "bold"), fg="black", bg=tk_background_color, justify="left")
    title_label.grid(row=0, column=0, pady=(12, 0), sticky='w')

    left_panel = tk.Frame(radar_page_frame, bg=tk_background_color)
    left_panel.grid(row=1, column=0, padx=(40, 0), pady=(10, 0), sticky="nw")
    RADAR_PAGE_LEFT_PANEL = left_panel

    status_panel = tk.Frame(left_panel, bg="#eef4f8", relief="ridge", bd=2)
    status_panel.grid(row=0, column=0, sticky="nw")
    status_panel.grid_propagate(False)
    status_panel.configure(width=250, height=170)
    RADAR_PAGE_STATUS_PANEL = status_panel

    panel_hint = tk.Label(
        status_panel,
        text="Choose radar site\nand zoom level.",
        font=("Helvetica Neue", 15),
        fg="black",
        justify="left",
        bg="#eef4f8",
    )
    panel_hint.grid(row=0, column=0, padx=12, pady=12, sticky="nw")
    RADAR_PAGE_DYNAMIC_MESSAGE_LABEL = None

    message_area = tk.Frame(left_panel, bg=tk_background_color, width=250, height=78)
    message_area.grid(row=2, column=0, sticky="nw", pady=(10, 0))
    message_area.grid_propagate(False)
    RADAR_PAGE_MESSAGE_AREA = message_area

    thumbnail_area = tk.Frame(left_panel, bg=tk_background_color, width=245, height=152)
    thumbnail_area.grid(row=3, column=0, sticky="nw", pady=(18, 0))
    thumbnail_area.grid_propagate(False)

    # --- 4. Resize image and scale coordinates ---
    target_width, target_height = 690, 383
    scaled_radar_sites = [] # Use a new list for scaled data

    try:
        # Calculate scale factor based on the image just loaded
        scale_factor = target_width / map_screenshot_image.width

        # Resize the map image (creates a new image object)
        resized_map_image = map_screenshot_image.resize((target_width, target_height), Image.LANCZOS)

        # Scale coordinates safely into the new list
        scaled_radar_sites = copy.deepcopy(radar_sites) # Start with a deep copy
        for site in scaled_radar_sites:
            if 'coordinates' in site and isinstance(site['coordinates'], (list, tuple)) and len(site['coordinates']) >= 2:
                original_coords = site['coordinates']
                # Assuming coordinates are (x, y, radius...) - scale x, y
                scaled_coords = tuple(int(original_coords[i] * scale_factor) for i in range(2))
                site['coordinates'] = scaled_coords + tuple(original_coords[2:]) # Combine scaled x,y with rest
            else:
                print(f"[WARN] Invalid or missing coordinates for site: {site.get('site_code', 'N/A')}")
                # Decide how to handle invalid sites - skip, use defaults? Here we just leave coords as they are.

    except Exception as e:
        error_message = f"Error resizing map/site data:\n{e}"
        print(f"[ERROR] choose_lcl_radar: {error_message}")
        # Display error in GUI
        add_modern_screen_text(
            frame1,
            tk,
            tk_background_color,
            "The Weather Observer",
            error_message,
            title_row=0,
            body_row=1,
            title_padx=50,
            title_pady=(50, 10),
            body_padx=50,
            body_pady=(20, 20),
            title_columnspan=20,
            body_columnspan=20,
            sticky="nw",
        )
        box_variables[2] = 0
        create_modern_button(frame1, tk, "Next", lightning_center_input, font=("Helvetica", 16, "bold"), variant="primary").grid(row=2, column=0, padx=50, pady=20, sticky="nw")
        return

    # --- 5. Define Nested Functions (Helpers) ---
    # These functions will use 'scaled_radar_sites' from the outer scope

    def lcl_radar_find_closest_site(x, y):
        """Finds the closest site in scaled_radar_sites to click coordinates."""
        min_distance = float('inf')
        closest_site_found = None
        if not scaled_radar_sites:
            return None
        for site in scaled_radar_sites:
            # Ensure coordinates are valid before calculating distance
            if 'coordinates' in site and isinstance(site['coordinates'], (list, tuple)) and len(site['coordinates']) >= 3:
                 site_x, site_y, site_radius = site['coordinates'][:3] # Take first 3 elements
                 # Basic distance calculation (ignoring radius for simplicity here, adjust if needed)
                 # distance = ((x - site_x) ** 2 + (y - site_y) ** 2) ** 0.5
                 # Original logic accounting for radius:
                 distance = ((x - site_x) ** 2 + (y - site_y) ** 2) ** 0.5 - site_radius

                 if distance < min_distance:
                     min_distance = distance
                     closest_site_found = site
            else:
                 print(f"[WARN] Skipping site {site.get('site_code', 'N/A')} in closest site calculation due to invalid coords.")
        return closest_site_found

    def lcl_radar_draw_links():
        """Draws indicators on the map (if needed). Uses scaled_radar_sites."""
        # Currently commented out in original - implement if needed
        # print("[DEBUG] Drawing radar links (if implemented)")
        # if not scaled_radar_sites: return
        # for site in scaled_radar_sites:
        #     if 'coordinates' in site ... :
        #         site_x, site_y, site_radius = site['coordinates'][:3]
        #         label.create_oval(site_x - site_radius, site_y - site_radius, site_x + site_radius, site_y + site_radius, outline="red")
        pass # Placeholder if not drawing anything

    # Define variables needed within lcl_radar_on_click scope
    confirm_label = None
    lcl_radar_zoom_label = None
    lcl_radar_dropdown = None
    # Note: We do NOT need to initialize message_label = None here anymore, 
    # because we will use the global one.
    
    closest_site = None 
    global radar_identifier  
    radar_identifier = None  

    def lcl_radar_on_click(event):
        """Handles clicks on the radar map."""
        # 1. Keep these as nonlocal (they belong to choose_lcl_radar)
        nonlocal confirm_label, lcl_radar_zoom_label, lcl_radar_dropdown, status_panel, panel_hint
        nonlocal closest_site
        
        # 2. CRITICAL CHANGE: Add 'message_label' to the GLOBAL list.
        # This allows this function to "see" and destroy the error message 
        # created by the separate confirm_radar_site function.
        global lcl_radar_zoom_clicks, submit_button, radar_identifier, message_label

        # Destroy previous dynamic widgets if they exist
        if confirm_label and confirm_label.winfo_exists(): confirm_label.destroy()
        if lcl_radar_zoom_label and lcl_radar_zoom_label.winfo_exists(): lcl_radar_zoom_label.destroy()
        if lcl_radar_dropdown and lcl_radar_dropdown.winfo_exists(): lcl_radar_dropdown.destroy()
        
        # 3. Clear the "Unavailable" error (or any other message) immediately
        if message_label and message_label.winfo_exists(): 
             message_label.destroy()
             message_label = None

        # Try reading the global submit_button
        # Reset zoom level
        lcl_radar_zoom_clicks.set(0)

        x, y = event.x, event.y
        closest_site = lcl_radar_find_closest_site(x, y) # Use helper

        if closest_site and 'site_code' in closest_site:
            radar_identifier = closest_site['site_code']

            if panel_hint and panel_hint.winfo_exists():
                panel_hint.destroy()

            # Update the confirm_label
            confirm_text = f"You chose\nradar site:\n{radar_identifier}"
            confirm_label = tk.Label(status_panel, text=confirm_text, font=("Helvetica Neue", 15, "bold"), fg="black", justify='left', bg="#eef4f8")
            confirm_label.grid(row=0, column=0, padx=12, pady=(10, 4), sticky='nw')

            # Display zoom options label
            lcl_radar_zoom_text = "Zoom level"
            lcl_radar_zoom_label = tk.Label(status_panel, text=lcl_radar_zoom_text, font=("Helvetica Neue", 14), fg="black", justify='left', bg="#eef4f8")
            lcl_radar_zoom_label.grid(row=1, column=0, padx=12, pady=(2, 4), sticky='nw')

            # Create and place the OptionMenu widget for zoom
            lcl_radar_choices = [0, 1, 2, 3, 4]
            lcl_radar_dropdown = tk.OptionMenu(status_panel, lcl_radar_zoom_clicks, *lcl_radar_choices)
            lcl_radar_dropdown.config(font=("Helvetica Neue", 13), fg="black", highlightthickness=0) 
            lcl_radar_dropdown.grid(row=2, column=0, padx=12, pady=(0, 10), sticky="nw")

            if submit_button and submit_button.winfo_exists():
                submit_button.config(state="normal")
        else:
            print("[WARN] Click did not correspond to a known radar site.")
            # Display a message to the user (Using the GLOBAL variable now)
            message_label = tk.Label(RADAR_PAGE_MESSAGE_AREA, text="Click closer to a radar site marker.", font=("Helvetica Neue", 11, "bold"), fg="#bb2d3b", bg=tk_background_color, justify="left", wraplength=230)
            message_label.grid(row=0, column=0, padx=(10, 0), pady=(2, 0), sticky='nw')
            RADAR_PAGE_DYNAMIC_MESSAGE_LABEL = message_label

    # Create label for the map image
    map_frame = tk.Frame(radar_page_frame, bg=tk_background_color)
    map_frame.grid(row=1, column=1, padx=(20, 8), pady=(10, 0), sticky="ne")

    map_label = tk.Label(map_frame, bg=tk_background_color, bd=0, highlightthickness=0)

    # Display the RESIZED map image
    try:
        photo = ImageTk.PhotoImage(resized_map_image)
        map_label.configure(image=photo)
        map_label.image = photo # Keep reference! Important!
    except Exception as e:
        print(f"[ERROR] Error creating Tkinter image: {e}")
        add_modern_screen_text(
            frame1,
            tk,
            tk_background_color,
            "The Weather Observer",
            "Error displaying map image.",
            title_row=0,
            body_row=1,
            title_padx=50,
            title_pady=(50, 10),
            body_padx=50,
            body_pady=(20, 20),
            title_columnspan=20,
            body_columnspan=20,
            sticky="nw",
        )
        return # Can't proceed without the map visual

    # 3. Scraped Image (National Radar Map)
    # Target URL for the CONUS radar map
    radar_url = 'https://radar.weather.gov/ridge/standard/CONUS_0.gif'
     
    # Use variable prefix 'ntnl_radar_thumbnail' for unique names
    try:
        # Fetch the radar image data
        ntnl_radar_thumbnail_response = requests.get(radar_url, timeout=10)
        
        if ntnl_radar_thumbnail_response.status_code == 200:
            # Load image data into Pillow
            ntnl_radar_thumbnail_image_data = ntnl_radar_thumbnail_response.content
            ntnl_radar_thumbnail_pil_image = Image.open(io.BytesIO(ntnl_radar_thumbnail_image_data))
            
            # --- FIX FOR PIXELIZATION (Anti-Aliasing) ---
            # Convert the indexed-color GIF to full RGB mode before resizing.
            # This allows the LANCZOS filter to create smooth, intermediate colors.
            ntnl_radar_thumbnail_pil_image = ntnl_radar_thumbnail_pil_image.convert('RGB')
            
            # --- Resize Logic ---
            target_width = 245
            # Calculate aspect ratio
            ntnl_radar_thumbnail_w_percent = (target_width / float(ntnl_radar_thumbnail_pil_image.size[0]))
            ntnl_radar_thumbnail_h_size = int((float(ntnl_radar_thumbnail_pil_image.size[1]) * float(ntnl_radar_thumbnail_w_percent)))
            
            # Resize the image using the high-quality LANCZOS filter
            ntnl_radar_thumbnail_pil_image = ntnl_radar_thumbnail_pil_image.resize(
                (target_width, ntnl_radar_thumbnail_h_size), 
                Image.Resampling.LANCZOS
            )
            
            # Convert to Tkinter PhotoImage
            ntnl_radar_thumbnail_tk_image = ImageTk.PhotoImage(ntnl_radar_thumbnail_pil_image)
            
            # Create the label to hold the image
            ntnl_radar_thumbnail_map_label = tk.Label(thumbnail_area, image=ntnl_radar_thumbnail_tk_image, bg=tk_background_color)
            
            # CRITICAL: Keep a reference to the image on the widget to prevent Tkinter garbage collection!
            ntnl_radar_thumbnail_map_label.image = ntnl_radar_thumbnail_tk_image 
            
            # Place the map at the requested coordinates (Updated to your final values)
            # padx=(10, 0), pady=(250,0)
            ntnl_radar_thumbnail_map_label.grid(row=0, column=0, padx=0, pady=0, sticky='nw')

            # --- Resource Cleanup for Long-Running Process ---
            # Set intermediate variables to None/delete to explicitly free up memory.
            # This prevents resource/memory leaks in the long-running application.
            del ntnl_radar_thumbnail_response
            del ntnl_radar_thumbnail_image_data
            ntnl_radar_thumbnail_pil_image.close() # Close PIL object explicitly
            del ntnl_radar_thumbnail_pil_image
            del ntnl_radar_thumbnail_w_percent
            del ntnl_radar_thumbnail_h_size
            
        else:
            print(f"[ERROR] Failed to fetch radar image. Status code: {ntnl_radar_thumbnail_response.status_code}")
            error_text = f"[Radar Failed: {ntnl_radar_thumbnail_response.status_code}]"
            error_label = tk.Label(thumbnail_area, text=error_text, bg=tk_background_color, fg="red", font=("Helvetica Neue", 12, "bold"))
            error_label.grid(row=0, column=0, padx=0, pady=0, sticky='nw')
            del ntnl_radar_thumbnail_response # Clean up failed response

    except requests.exceptions.RequestException as e:
        print(f"[ERROR] Network/Timeout error fetching radar image: {e}")
        error_label = tk.Label(thumbnail_area, text="[Radar Failed: Network Error]", bg=tk_background_color, fg="red", font=("Helvetica Neue", 12, "bold"))
        error_label.grid(row=0, column=0, padx=0, pady=0, sticky='nw')

    button_row = tk.Frame(left_panel, bg=tk_background_color)
    button_row.grid(row=4, column=0, sticky="nw", pady=(13, 0))

    back_button = create_modern_button(button_row, tk, " Back ", page_choose, font=("Helvetica", 16, "bold"), variant="secondary")
    back_button.grid(row=0, column=0, padx=(0, 12), pady=0, sticky="w")

    submit_button = create_modern_button(button_row, tk, "Submit", confirm_radar_site, font=("Helvetica", 16, "bold"), variant="primary")
    submit_button.config(state=tk.DISABLED)
    submit_button.grid(row=0, column=1, padx=0, pady=0, sticky="w")

    map_label.grid(row=0, column=0, sticky="n")

    # Draw links/markers (if implemented in the helper)
    lcl_radar_draw_links()

    # Bind the click handler to the map label
    map_label.bind("<Button-1>", lcl_radar_on_click)

# --- End of choose_lcl_radar function ---

# begin block for radiosonde choice
def get_most_recent_gmt():
    global sonde_report_from_time, most_recent_sonde_time, sonde_letter_identifier, box_variables

    def check_url_exists(url):
        try:
            response = requests.head(url)
            return response.status_code == 200
        except requests.RequestException:
            return False

    def format_time(gmtime_struct, hour):
        return time.strftime(f"%y%m%d{hour:02d}_OBS", gmtime_struct)

    current_time = time.gmtime()
    hour = current_time.tm_hour

    # Determine if we should start with 12Z or 00Z
    if hour >= 12:
        most_recent_hour = 12
    else:
        most_recent_hour = 0

    # Initialize the starting time
    adjusted_time = time.mktime((
        current_time.tm_year, current_time.tm_mon, current_time.tm_mday,
        most_recent_hour, 0, 0, current_time.tm_wday,
        current_time.tm_yday, current_time.tm_isdst
    ))

    while True:
        gmt_struct = time.gmtime(adjusted_time)
        most_recent_sonde_time = format_time(gmt_struct, most_recent_hour)
        url = f"https://www.spc.noaa.gov/exper/soundings/{most_recent_sonde_time}/"
        #print(f"Testing URL: {url}")  # Debug print
        if check_url_exists(url):
            break
        
        # Adjust time to the previous 12-hour period
        adjusted_time -= 12 * 3600
        if most_recent_hour == 12:
            most_recent_hour = 0
        else:
            most_recent_hour = 12

    match = re.search(r'(\d{2})_OBS$', most_recent_sonde_time)
    if match:
        sonde_report_from_time = match.group(1)
    else:
        print("Could not pull 2 digits out of most_recent_sonde_time.")
        
    return most_recent_sonde_time

def draw_radiosonde_links(active_links, scale_factor):
    global sonde_letter_identifier, box_variables
    for link in active_links:
        coords = link['coords'].split(',')
        if len(coords) == 3:
            x, y, radius = map(int, coords)
            x_scaled, y_scaled = int(x * scale_factor), int(y * scale_factor)
            radius = int(radius * 2)
            #label.create_oval(x_scaled - radius, y_scaled - radius, x_scaled + radius, y_scaled + radius, outline="red")

def handle_click(event, active_links, scale_factor, confirm_label, submit_button):
    global sonde_letter_identifier, match, confirm_text
    for link in active_links:
        coords = link['coords'].split(',')
        if len(coords) == 3:
            x, y, radius = map(int, coords)
            x_scaled, y_scaled = int(x * scale_factor), int(y * scale_factor)
            radius = int(radius * 2)
            distance = ((event.x - x_scaled) ** 2 + (event.y - y_scaled) ** 2) ** 0.5
            if distance <= radius:
                match = re.search(r'"([A-Z]{3})"', link['href'])
                if match:
                    sonde_letter_identifier = match.group(1)
                    confirm_text = f"You chose radiosonde site:\n{sonde_letter_identifier}"
                    confirm_label.config(text=confirm_text)
                    submit_button.config(state=tk.NORMAL)  # Enable submit button
                else:
                    print("No match found")

def choose_radiosonde_site():
        
    global box_variables, sonde_letter_identifier, most_recent_sonde_time, refresh_flag, has_submitted_choice
    
    sonde_letter_identifier = ""
    
    if box_variables[8] == 1:        
        
        for widget in frame1.winfo_children():
            widget.destroy()
        hide_display_frame_for_frame1()
        
        # Reset clean position for frame1
        frame1.grid(row=0, column=0, sticky="nsew")
        frame1.tkraise()
        #inserted 3/28/24
        # Before displaying the map, temporarily adjust the configuration
        frame1.master.grid_rowconfigure(0, weight=0)  # Reset to default which doesn't expand the row
        frame1.master.grid_columnconfigure(0, weight=0)  # Reset to default which doesn't expand the column 
        
        frame1.grid_propagate(True)

        add_modern_screen_text(
            frame1,
            tk,
            tk_background_color,
            "The Weather Observer",
            "Please wait.\nLoading the radiosonde map...",
            title_row=0,
            body_row=1,
            title_padx=50,
            title_pady=(50, 10),
            body_padx=50,
            body_pady=(24, 12),
            title_columnspan=20,
            body_columnspan=20,
            sticky="nw",
        )
        root.update_idletasks()
        
        if not CHROME_DRIVER_PATH:
            print("ERROR: ChromeDriver path is not set. Cannot start browser.")
            # Handle the error appropriately, maybe return or raise an exception
            return 

        # Define your options for this specific function
        options = Options()
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        # Add any other specific options you need for this function...

        # Point to the driver path determined at startup
        service = Service(CHROME_DRIVER_PATH)

        # Initialize the driver with both objects
        driver = webdriver.Chrome(service=service, options=options)
        
        # trying to change this line as an experiment 4/3/24 - problem 00z-1z
        url = "https://www.spc.noaa.gov/exper/soundings/{}/".format(get_most_recent_gmt())        
        #url = "https://www.spc.noaa.gov/exper/soundings/{}/".format(most_recent_sonde_time()) 
        
        driver.get(url)

        try:
            # Wait up to 5 seconds for the image to be present
            map_element = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.XPATH, "/html/body/table/tbody/tr/td[1]/center/img"))
            )
            valid_page_found = True
        except Exception as e:
            print(f"Line 5031. Error: {e}")
            print("Image not found — possibly still loading or missing. Aborting radiosonde display.")
            driver.quit()
            # Gracefully skip this step, disable radiosonde, and call the fallback directly
            box_variables[8] = 0
            station_center_input()
            return
            

        map_image_url = map_element.get_attribute("src")
        map_response = requests.get(map_image_url, stream=True)
        
        # this try except block is for when the radiosonde map is unavailable        
        try:
            original_map_image = Image.open(BytesIO(map_response.content))
        except UnidentifiedImageError:
            # clean out the old widgets
            for widget in frame1.winfo_children():
                widget.destroy()
            # disable the radiosonde step and move on
            box_variables[8] = 0

            add_modern_screen_text(
                frame1,
                tk,
                tk_background_color,
                "The Weather Observer",
                "The map that displays the choices of radiosonde sites is not available.\nPlease try back later.",
                title_row=0,
                body_row=1,
                title_padx=50,
                title_pady=(50, 10),
                body_padx=50,
                body_pady=(20, 20),
                title_columnspan=20,
                body_columnspan=20,
                sticky="nw",
            )

            next_button = create_modern_button(
                frame1,
                tk,
                "Next",
                station_center_input,
                font=("Helvetica", 16, "bold"),
                variant="primary",
            )
            next_button.grid(row=2, column=0, padx=50, pady=20, sticky="nw")

            return

        soup = BeautifulSoup(driver.page_source, 'html.parser')
        active_links = soup.find('map', {'name': 'stations'}).find_all('area')

        target_width, target_height = 600, 450
        scale_factor = target_width / original_map_image.width
        enlarged_map_image = original_map_image.resize((target_width, target_height), Image.LANCZOS)

        for widget in frame1.winfo_children():
            widget.destroy()

        radiosonde_page_frame = tk.Frame(frame1, bg=tk_background_color)
        radiosonde_page_frame.grid(row=0, column=0, sticky="nsew")

        header_frame = tk.Frame(radiosonde_page_frame, bg=tk_background_color)
        header_frame.grid(row=0, column=0, columnspan=2, padx=40, pady=(18, 10), sticky="w")

        radiosonde_logo = create_small_weather_observer_logo(header_frame, size=(65, 65))
        radiosonde_logo.grid(row=0, column=0, padx=(0, 6), pady=(6, 0), sticky="w")

        header_text_frame = tk.Frame(header_frame, bg=tk_background_color)
        header_text_frame.grid(row=0, column=1, sticky="w")

        title_label = tk.Label(header_text_frame, text="The Weather Observer", font=("Helvetica Neue", 18, "bold"), fg="black", justify="left", bg=tk_background_color)
        title_label.grid(row=0, column=0, pady=(12, 0), sticky="w")

        left_panel = tk.Frame(radiosonde_page_frame, bg=tk_background_color)
        left_panel.grid(row=1, column=0, padx=(40, 8), pady=(10, 0), sticky="nw")

        status_panel = tk.Frame(left_panel, bg="#eef4f8", relief="ridge", bd=2)
        status_panel.grid(row=0, column=0, sticky="nw")
        status_panel.grid_propagate(False)
        status_panel.configure(width=300, height=170)

        instruction_text = f"These are the\nradiosonde sites that are\navailable as of {sonde_report_from_time} GMT."
        instructions_label = tk.Label(status_panel, text=instruction_text, font=("Helvetica Neue", 15), fg="black", justify='left', bg="#eef4f8")
        instructions_label.grid(row=0, column=0, padx=12, pady=(12, 6), sticky='nw')

        instructions_label_2 = tk.Label(status_panel, text="Choose radiosonde site.", font=("Helvetica Neue", 15), fg="black", justify='left', bg="#eef4f8")
        instructions_label_2.grid(row=1, column=0, padx=12, pady=(0, 6), sticky='nw')

        message_area = tk.Frame(left_panel, bg=tk_background_color, width=300, height=78)
        message_area.grid(row=2, column=0, sticky="nw", pady=(10, 0))
        message_area.grid_propagate(False)

        confirm_label = tk.Label(message_area, text="", font=("Helvetica Neue", 15), fg="black", justify='left', bg=tk_background_color, wraplength=230)
        confirm_label.grid(row=0, column=0, padx=(10, 0), pady=(2, 0), sticky='nw')

        button_row = tk.Frame(left_panel, bg=tk_background_color)
        button_row.grid(row=3, column=0, sticky="nw", pady=(20, 0))

        enlarged_map_photo = ImageTk.PhotoImage(enlarged_map_image)
        map_frame = tk.Frame(radiosonde_page_frame, bg=tk_background_color)
        map_frame.grid(row=1, column=1, padx=(70, 12), pady=(10, 0), sticky="ne")

        label = tk.Label(map_frame, bg=tk_background_color)
        label.configure(image=enlarged_map_photo)
        label.image = enlarged_map_photo
        label.grid(row=0, column=0, sticky="n")

        draw_radiosonde_links(active_links, scale_factor)

        overlay_label = tk.Label(map_frame, text="Sounding Stations", font=("Arial", 15, "bold"), bg="white", fg="black", padx=8, pady=2)
        overlay_label.place(x=300, y=435, anchor="center")

        match = re.search(r'<span class="style5">Observed Radiosonde Data<br>\s*([^<]+)\s*</span>', driver.page_source)
        if match:
            date_str = match.group(1)
            overlay_label["text"] += f" {date_str}"

        if box_variables[5] == 1:
            #refresh_flag = True # this allows back button on choose_radiosonde_site to go back to choose_reg_sat, but prevents program from displaying
            # need to toggle refresh_flag back to False at some point
            has_submitted_choice = False
            back_function = choose_reg_sat
            
        elif box_variables[3] == 1:
            back_function = lightning_center_input
            
        elif box_variables[2] == 1:
            back_function = choose_lcl_radar
            
        else:
            back_function = page_choose

        # Create the 'Back' button
        back_button = create_modern_button(button_row, tk, " Back ", back_function, font=("Helvetica", 16, "bold"), variant="secondary")
        back_button.grid(row=0, column=0, padx=(0, 12), pady=0, sticky="w")

        submit_button = create_modern_button(button_row, tk, "Submit", station_center_input, font=("Helvetica", 16, "bold"), variant="primary")
        submit_button.config(state=tk.DISABLED)
        submit_button.grid(row=0, column=1, padx=0, pady=0, sticky="w")            

        label.bind("<Button-1>", lambda event: handle_click(event, active_links, scale_factor, confirm_label, submit_button))
        
    else:
        station_center_input()
    
def choose_reg_sat():
    global reg_sat_choice_variables, box_variables, reg_sat, has_submitted_choice, refresh_flag, REG_SAT_SCREEN_CACHE

    existing_reg_sat_choices = globals().get("reg_sat_choice_variables", [])
    previous_choices = list(existing_reg_sat_choices) if isinstance(existing_reg_sat_choices, list) else []
    reg_sat_choice_variables = [0] * 16

    if refresh_flag == True:
        has_submitted_choice = False

    if box_variables[5] != 1:
        choose_radiosonde_site()

    elif not has_submitted_choice:
        choices = [
            ("Pacific NW", "pacific_nw.png"),
            ("Upper\nMiss.\nValley", "upper_mississippi_valley.png"),
            ("Northeast", "northeast.png"),
            ("Canada/\nNorthern\nU.S.", "canada_northern_us.png"),
            ("Pacific SW", "pacific_sw.png"),
            ("Southern\nMiss.\nValley", "southern_mississippi_valley.png"),
            ("Southeast", "southeast.png"),
            ("Gulf of\nMexico", "gulf_of_mexico.png"),
            ("Northern\nRockies", "northern_rockies.png"),
            ("Great\nLakes", "great_lakes.png"),
            ("U.S.\nPacific\nCoast", "us_pacific_coast.png"),
            ("Caribbean", "caribbean.png"),
            ("Southern\nRockies", "southern_rockies.png"),
            ("Southern\nPlains", "southern_plains.png"),
            ("U.S.\nAtlantic\nCoast", "us_atlantic_coast.png"),
            ("Tropical\nAtlantic", "tropical_atlantic.png"),
        ]

        lower_text_buttons = {
            "canada_northern_us.png",
            "southern_mississippi_valley.png",
            "us_atlantic_coast.png",
            "upper_mississippi_valley.png",
            "us_pacific_coast.png",
        }
        left_shift_exempt = {
            "canada_northern_us.png",
            "tropical_atlantic.png",
        }

        def hide_cached_reg_sat():
            if REG_SAT_SCREEN_CACHE and REG_SAT_SCREEN_CACHE.get("frame") is not None:
                try:
                    REG_SAT_SCREEN_CACHE["frame"].grid_forget()
                except Exception:
                    pass

        if REG_SAT_SCREEN_CACHE is None or not REG_SAT_SCREEN_CACHE["frame"].winfo_exists():
            regsat_frame = tk.Frame(root, bg=tk_background_color)
            regsat_frame.config(width=1024, height=600, bg="lightblue")
            regsat_frame.grid_propagate(False)
            for column in (0, 1, 2, 3):
                regsat_frame.grid_columnconfigure(column, weight=0, minsize=232)

            add_modern_screen_text(
                regsat_frame,
                tk,
                tk_background_color,
                "The Weather Observer",
                "Please select your regional satellite view:",
                title_row=0,
                body_row=1,
                title_padx=50,
                title_pady=(42, 8),
                body_padx=50,
                body_pady=(0, 8),
                title_columnspan=4,
                body_columnspan=4,
                sticky="w",
            )

            reg_sat_choice_variable = tk.IntVar(value=-1)
            cards_frame = tk.Frame(regsat_frame, bg=tk_background_color)
            cards_frame.grid(row=2, column=0, columnspan=4, padx=(14, 14), pady=(2, 0), sticky="w")
            cards_frame.grid_propagate(False)
            cards_frame.config(width=960, height=382)
            for column in (0, 1, 2, 3):
                cards_frame.grid_columnconfigure(column, weight=0, minsize=234)

            card_refs = []

            def update_reg_sat_choice_card(card_canvas, items, variable, value):
                selected = variable.get() == value
                card_canvas.config(relief="raised", bd=2, bg="#f8fbfd")
                card_canvas.itemconfigure(items["radio"], text="◉" if selected else "○", fill="#27558a" if selected else "#6c8092")

            def refresh_cards():
                for card_canvas, items, value in card_refs:
                    update_reg_sat_choice_card(card_canvas, items, reg_sat_choice_variable, value)
                REG_SAT_SCREEN_CACHE["submit_button"].config(
                    state=tk.NORMAL if reg_sat_choice_variable.get() != -1 else tk.DISABLED
                )

            for index, (choice, thumb_file) in enumerate(choices):
                row = index // 4
                column = index % 4
                compact_thumb = thumb_file == "tropical_atlantic.png"
                text_x_overrides = {
                    "tropical_atlantic.png": 135,
                    "canada_northern_us.png": 145,
                }

                thumb_width = 126 if compact_thumb else 138
                thumb_height = 62 if compact_thumb else 76
                thumb_x = 2 if compact_thumb else 6
                thumb_y = 3
                text_x = text_x_overrides.get(thumb_file, 125)
                text_y = 15 if thumb_file in lower_text_buttons else 22
                thumb_relx = 0.5 if thumb_file == "tropical_atlantic.png" else (0.5 if thumb_file in left_shift_exempt else 0.35)
                thumb_rely = 0.7 if thumb_file == "tropical_atlantic.png" else 0.50

                card_canvas = tk.Canvas(
                    cards_frame,
                    width=220,
                    height=84,
                    bg="#f8fbfd",
                    bd=2,
                    relief="raised",
                    highlightthickness=0,
                )
                if column == 0:
                    card_padx = (4, 8)
                elif column == 3:
                    card_padx = (8, 4)
                else:
                    card_padx = (8, 8)
                card_canvas.grid(row=row, column=column, padx=card_padx, pady=3, sticky="w")

                thumb_center_x = thumb_x + int(thumb_width * thumb_relx)
                thumb_center_y = thumb_y + int(thumb_height * thumb_rely)
                thumb_image = get_reg_sat_sector_thumbnail(thumb_file)
                card_canvas.create_image(thumb_center_x, thumb_center_y, image=thumb_image, anchor="center")

                text_item = card_canvas.create_text(
                    text_x,
                    text_y,
                    text=choice,
                    anchor="nw",
                    fill="black",
                    font=("Helvetica Neue", 10, "bold"),
                    justify="left",
                )

                radio_item = card_canvas.create_text(
                    201,
                    58,
                    text="○",
                    anchor="center",
                    fill="#6c8092",
                    font=("Helvetica Neue", 14, "bold"),
                )

                card_canvas.image = thumb_image
                items = {
                    "text": text_item,
                    "radio": radio_item,
                }

                def choose_sector(_event=None, value=index):
                    reg_sat_choice_variable.set(value)
                    refresh_cards()

                card_canvas.bind("<Button-1>", choose_sector)
                card_refs.append((card_canvas, items, index))

            def submit_sat_choice():
                global reg_sat_choice_variables, has_submitted_choice
                selected_index = reg_sat_choice_variable.get()
                if selected_index != -1:
                    reg_sat_choice_variables = [1 if i == selected_index else 0 for i in range(16)]
                    has_submitted_choice = True
                    hide_cached_reg_sat()

                    def continue_after_reg_sat():
                        if box_variables[8] == 1:
                            choose_radiosonde_site()
                        else:
                            station_center_input()

                    root.after(1, continue_after_reg_sat)

            footer_frame = tk.Frame(regsat_frame, bg=tk_background_color, width=940, height=52)
            footer_frame.grid(row=3, column=0, columnspan=4, padx=42, pady=(6, 0), sticky="w")
            footer_frame.grid_propagate(False)
            footer_frame.grid_columnconfigure(0, weight=0)

            button_row = tk.Frame(footer_frame, bg=tk_background_color)
            button_row.grid(row=0, column=0, sticky="e")

            back_button = create_modern_button(button_row, tk, " Back ", page_choose, font=("Arial", 16, "bold"), variant="secondary")
            back_button.grid(row=0, column=0, padx=(0, 20), pady=0, sticky="w")

            submit_button = create_modern_button(button_row, tk, "Submit", submit_sat_choice, font=("Arial", 16, "bold"), variant="primary")
            submit_button.grid(row=0, column=1, padx=0, pady=0, sticky="w")

            REG_SAT_SCREEN_CACHE = {
                "frame": regsat_frame,
                "choice_var": reg_sat_choice_variable,
                "card_refs": card_refs,
                "refresh_cards": refresh_cards,
                "back_button": back_button,
                "submit_button": submit_button,
            }
        else:
            reg_sat_choice_variable = REG_SAT_SCREEN_CACHE["choice_var"]

        selected_index = -1
        for i, value in enumerate(previous_choices):
            if value == 1:
                selected_index = i
                break
        reg_sat_choice_variable.set(selected_index)

        if box_variables[3] == 1:
            back_function = lightning_center_input
        elif box_variables[2] == 1:
            back_function = choose_lcl_radar
        else:
            back_function = page_choose

        REG_SAT_SCREEN_CACHE["back_button"].configure(
            command=lambda fn=back_function: (hide_cached_reg_sat(), fn())
        )
        REG_SAT_SCREEN_CACHE["refresh_cards"]()
        REG_SAT_SCREEN_CACHE["frame"].grid(row=0, column=0, sticky="nsew")
        REG_SAT_SCREEN_CACHE["frame"].tkraise()

def submit_choices():
    global box_variables, hold_box_variables, PAGE_CHOOSE_SCREEN_CACHE
    normalized_choices = [1 if var.get() else 0 for var in page_choose_choice_vars]
    box_variables = normalized_choices[:]
    hold_box_variables = normalized_choices[:]

    # Apply conditional changes to box_variables
    for index, value in enumerate(box_variables):
        if value == 1:
            box_variables[index] = 2 if index in {11} else 1

#     # Loop through each value in hold_box_variables and print it inside submit_choices
#     for index, value in enumerate(hold_box_variables):
#         print(f"submit_choices: hold_box_variables[{index}] = {value}")

    if PAGE_CHOOSE_SCREEN_CACHE and PAGE_CHOOSE_SCREEN_CACHE.get("frame") is not None:
        try:
            PAGE_CHOOSE_SCREEN_CACHE["frame"].grid_forget()
        except Exception:
            pass

    if box_variables[2] == 1:
        choose_lcl_radar()  
    else:
        lightning_center_input()  

def page_choose():
    global page_choose_choice_vars, hold_box_variables, xs, PAGE_CHOOSE_SCREEN_CACHE
    global random_sites_flag, lcl_radar_map_unavailable

    hide_display_frame_for_frame1()

    choices = [
        ("Barograph", "01_barograph.png"),
        ("National\nRadar", "02_national_radar.png"),
        ("Local\nRadar", "03_local_radar.png"),
        ("Lightning", "04_lightning.png"),
        ("Large Single Image\nSatellite", "05_large_still_satellite.png"),
        ("Regional\nSatellite\nLoop", "06_regional_satellite.png"),
        ("National\nSurface\nAnalysis", "07_national_surface.png"),
        ("Station\nPlots", "08_station_plots.png"),
        ("Radiosonde", "09_radiosonde.png"),
        ("500mb\nVorticity", "10_vorticity.png"),
        ("Storm\nReports", "11_storm_reports.png"),
        ("Next Idea", "12_next_idea.png"),
    ]

    def apply_choice_style(card_canvas, items, label, variable, disabled=False):
        selected = bool(variable.get())
        if disabled and label == "Next Idea":
            bg = "#e7edf1"
            fg = "#8d99a4"
            radio_fg = "#8d99a4"
            radio_text = "○"
        else:
            bg = "#d9e7f7" if selected else "#f8fbfd"
            fg = "black"
            radio_fg = "#27558a" if selected else "#6c8092"
            radio_text = "◉" if selected else "○"
        card_canvas.config(bg=bg, relief="raised", bd=2)
        card_canvas.itemconfigure(items["text"], fill=fg)
        card_canvas.itemconfigure(items["radio"], fill=radio_fg, text=radio_text)

    def hide_cached_page_choose():
        if PAGE_CHOOSE_SCREEN_CACHE and PAGE_CHOOSE_SCREEN_CACHE.get("frame") is not None:
            try:
                PAGE_CHOOSE_SCREEN_CACHE["frame"].grid_forget()
            except Exception:
                pass

    if PAGE_CHOOSE_SCREEN_CACHE is None or not PAGE_CHOOSE_SCREEN_CACHE["frame"].winfo_exists():
        page_frame = tk.Frame(root, bg=tk_background_color)
        page_frame.config(width=1024, height=600)
        page_frame.grid_propagate(False)
        for column in (0, 1, 2):
            page_frame.grid_columnconfigure(column, weight=0, minsize=308)

        add_modern_screen_text(
            page_frame,
            tk,
            tk_background_color,
            "The Weather Observer",
            "Please select your display choices:",
            title_row=0,
            body_row=1,
            title_padx=50,
            title_pady=(42, 8),
            body_padx=50,
            body_pady=(0, 10),
            title_columnspan=3,
            body_columnspan=3,
            sticky="w",
        )

        page_choose_choice_vars = []
        cards_frame = tk.Frame(page_frame, bg=tk_background_color)
        cards_frame.grid(row=2, column=0, columnspan=3, padx=(42, 26), pady=(0, 0), sticky="w")
        cards_frame.grid_propagate(False)
        cards_frame.config(width=930, height=350)
        for column in (0, 1, 2):
            cards_frame.grid_columnconfigure(column, weight=0, minsize=298)

        card_refs = []

        for index, (choice, thumb_file) in enumerate(choices):
            var = tk.IntVar()
            page_choose_choice_vars.append(var)
            column = index // 4
            row = index % 4
            disabled = index == 0 or index > 10

            card_canvas = tk.Canvas(
                cards_frame,
                width=278,
                height=70,
                bg="#eef2f5" if choice == "Next Idea" else "#f8fbfd",
                bd=2,
                relief="raised",
                highlightthickness=0,
            )
            if column == 0:
                padx = (12, 8)
            elif column == 1:
                padx = (20, 8)
            else:
                padx = (20, 0)
            card_canvas.grid(row=row, column=column, padx=padx, pady=7, sticky="w")

            thumb_image = get_page_choose_thumbnail(thumb_file)
            card_canvas.create_image(64, 35, image=thumb_image, anchor="center")
            card_canvas.image = thumb_image

            text_item = card_canvas.create_text(
                122,
                35,
                text=choice,
                anchor="w",
                fill="black",
                font=("Helvetica Neue", 11, "bold"),
                justify="left",
                width=132,
            )

            radio_item = card_canvas.create_text(
                252,
                35,
                text="○",
                anchor="center",
                fill="#6c8092",
                font=("Helvetica Neue", 17, "bold"),
            )

            items = {
                "text": text_item,
                "radio": radio_item,
            }

            if not disabled:
                def toggle_choice(_event=None, v=var, c=card_canvas, it=items, lbl=choice):
                    v.set(0 if v.get() else 1)
                    apply_choice_style(c, it, lbl, v)

                card_canvas.bind("<Button-1>", toggle_choice)
            else:
                card_canvas.bind("<Button-1>", lambda _event: 'break')

            card_refs.append((card_canvas, items, choice, var, disabled))

        footer_frame = tk.Frame(page_frame, bg=tk_background_color, width=924, height=52)
        footer_frame.grid(row=4, column=0, columnspan=3, padx=50, pady=(4, 0), sticky="w")
        footer_frame.grid_propagate(False)
        footer_frame.grid_columnconfigure(0, weight=0)

        button_row = tk.Frame(footer_frame, bg=tk_background_color)
        button_row.grid(row=0, column=0, sticky="e")

        back_button = create_modern_button(button_row, tk, " Back ", recheck_cobs_stations, font=("Arial", 16, "bold"), variant="secondary")
        back_button.grid(row=0, column=0, padx=(0, 20), pady=0, sticky="w")

        submit_button = create_modern_button(button_row, tk, "Submit", submit_choices, font=("Arial", 16, "bold"), variant="primary")
        submit_button.grid(row=0, column=1, padx=0, pady=0, sticky="w")

        PAGE_CHOOSE_SCREEN_CACHE = {
            "frame": page_frame,
            "card_refs": card_refs,
            "vars": page_choose_choice_vars,
            "back_button": back_button,
        }
    else:
        page_choose_choice_vars = PAGE_CHOOSE_SCREEN_CACHE["vars"]

    for index, (_choice, _thumb_file) in enumerate(choices):
        disabled = index == 0 or index > 10
        var = page_choose_choice_vars[index]
        if index == 0:
            var.set(1)
        elif index > 10:
            var.set(0)
        else:
            remembered_value = hold_box_variables[index] if hold_box_variables and index < len(hold_box_variables) else 0
            var.set(1 if remembered_value else 0)

    for card_canvas, items, choice, var, disabled in PAGE_CHOOSE_SCREEN_CACHE["card_refs"]:
        apply_choice_style(card_canvas, items, choice, var, disabled=disabled)

    next_function = confirm_random_sites if random_sites_flag else recheck_cobs_stations
    if not barograph_started:
        PAGE_CHOOSE_SCREEN_CACHE["back_button"].configure(
            command=lambda fn=next_function: (hide_cached_page_choose(), fn())
        )
        if not PAGE_CHOOSE_SCREEN_CACHE["back_button"].winfo_ismapped():
            PAGE_CHOOSE_SCREEN_CACHE["back_button"].grid(row=0, column=0, padx=(0, 20), pady=0, sticky="w")
    else:
        if PAGE_CHOOSE_SCREEN_CACHE["back_button"].winfo_ismapped():
            PAGE_CHOOSE_SCREEN_CACHE["back_button"].grid_remove()

    PAGE_CHOOSE_SCREEN_CACHE["frame"].grid(row=0, column=0, sticky="nsew")
    PAGE_CHOOSE_SCREEN_CACHE["frame"].tkraise()

def submit_lg_sat_choice():
    global lg_still_sat, lg_still_view
    
    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()
    
    # Check which radio button is selected and assign the appropriate values
    choice = lg_still_sat_choice_vars.get()
    if choice == 0:
        lg_still_sat = "19"
        lg_still_view = "CONUS"
    elif choice == 1:
        lg_still_sat = "18"
        lg_still_view = "CONUS"
    elif choice == 2:
        lg_still_sat = "19"
        lg_still_view = "FD"
    elif choice == 3:
        lg_still_sat = "18"
        lg_still_view = "FD"

    choose_reg_sat()

def check_lg_still_sat_status(*args):
    # Enable submit button if a radio button is selected
    if 'submit_button' not in globals() or not submit_button.winfo_exists():
        return
    if lg_still_sat_choice_vars.get() != -1:  # -1 means no selection
        submit_button.config(state="normal")
    else:
        submit_button.config(state="disabled")

def choose_lg_still_sat():
    global lg_still_sat_choice_vars, submit_button
    
    if box_variables[4] == 1:
        # Clear the current display
        for widget in frame1.winfo_children():
            widget.destroy()

        frame1.grid(row=0, column=0, sticky="nsew")
        
        instruction_text = "Please choose the view for the large still satellite image:"
        add_modern_screen_text(
            frame1,
            tk,
            tk_background_color,
            "The Weather Observer",
            instruction_text,
            title_row=0,
            body_row=1,
            title_padx=50,
            title_pady=(50, 0),
            body_padx=50,
            body_pady=5,
            title_columnspan=20,
            body_columnspan=20,
            sticky="nw",
        )

        # Initialize the IntVar for the radio buttons
        lg_still_sat_choice_vars = tk.IntVar(value=-1)  # -1 means no selection

        # Define a custom style for radio buttons
        style = ttk.Style()
        style.configure("Custom.TRadiobutton", font=("Helvetica Neue", 16, "bold"), background=tk_background_color, foreground="black")

        # Define radio button labels
        radio_labels = ['Eastern US', 'Western US', 'Globe East', 'Globe West']
        
        # Create and arrange radio buttons, all linked to the same IntVar
        for i, label in enumerate(radio_labels):
            radio_button = ttk.Radiobutton(
                frame1, text=label, variable=lg_still_sat_choice_vars, 
                value=i, style="Custom.TRadiobutton"
            )
            radio_button.grid(row=2 + (i // 2), column=i % 2, padx=50, pady=10, sticky='w')

        # Add a trace to monitor the state of the radio buttons
        lg_still_sat_choice_vars.trace_add('write', check_lg_still_sat_status)

        # Create submit button, initially disabled
        submit_button = create_modern_button(
            frame1, tk, "Submit", submit_lg_sat_choice, font=("Arial", 16, "bold"), variant="primary"
        )
        submit_button.config(state="disabled")
        submit_button.grid(row=5, column=0, columnspan=20, padx=200, pady=50, sticky='nw')
        
        if box_variables[3] == 1:
            back_function = lightning_center_input
        elif box_variables[2] == 1:
            back_function = choose_lcl_radar
        else:
            back_function = page_choose

        # Create the 'Back' button
        back_button = create_modern_button(frame1, tk, " Back ", back_function, font=("Helvetica", 16, "bold"), variant="secondary")
        back_button.grid(row=5, column=0, columnspan=20, padx=(50, 0), pady=50, sticky="nw")
    
    else:
        choose_reg_sat()

def submit_lightning_near_me():
    global aobs_site, lightning_near_me_flag
    
    lightning_near_me_flag = True
    
    submit_lightning_center()

def submit_lightning_center():
    global submit_lightning_town, submit_lightning_state, lightning_town, lightning_state, lightning_lat, lightning_lon, aobs_site 
    global lightning_near_me_flag, last_lightning_update
    # Get the user's input
    submit_lightning_town = lightning_town.get()
    submit_lightning_state = lightning_state.get()

    for widget in frame1.winfo_children():
        widget.destroy()

    lightning_geolocator = Nominatim(user_agent="lightning_map")
    
    if lightning_near_me_flag == False:        
        # Combine town and state into a search query
        lightning_query = f"{submit_lightning_town}, {submit_lightning_state}"
    
    if lightning_near_me_flag == True:
        lightning_query = aobs_site
        lightning_near_me_flag = False

    def rerun_with_lightning_suggestion(suggested_town):
        global lightning_near_me_flag
        lightning_near_me_flag = False
        lightning_center_input()
        lightning_town.delete(0, tk.END)
        lightning_town.insert(0, suggested_town)
        lightning_state.delete(0, tk.END)
        lightning_state.insert(0, submit_lightning_state.upper())
        submit_lightning_center()
        
    try:
        # Use geocoder to get coordinates of lightning map center
        lightning_location = lightning_geolocator.geocode(lightning_query)

        if lightning_location:
            lightning_lat = lightning_location.latitude
            lightning_lon = lightning_location.longitude
            cleanup_lightning_image(available_image_dictionary)
            last_lightning_update = None
            choose_lg_still_sat()
        else:
            raise ValueError("Location not found")
    
    except (GeocoderUnavailable, ValueError) as e:

        for widget in frame1.winfo_children():
            widget.destroy()

        instruction_text = "Location not found or service unavailable. \n\Please enter a different town and state or choose not to display the lightning image."
        instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16,), bg=tk_background_color)
        instructions_label.grid(row=1, column=0, padx=50, pady=(20, 10))

        suggestions = _build_state_place_suggestions(submit_lightning_town, submit_lightning_state)
        next_row = 2
        if suggestions and not lightning_near_me_flag:
            suggestion_label = tk.Label(
                frame1,
                text="Did you mean:",
                font=("Helvetica Neue", 14, "bold"),
                fg="black",
                bg=tk_background_color,
                justify="left",
            )
            suggestion_label.grid(row=next_row, column=0, padx=(50, 0), pady=(10, 6), sticky="w")
            next_row += 1

            suggestions_frame = tk.Frame(frame1, bg=tk_background_color)
            suggestions_frame.grid(row=next_row, column=0, padx=(50, 0), pady=(0, 10), sticky="w")
            next_row += 1

            for index, suggestion in enumerate(suggestions[:3]):
                tk.Button(
                    suggestions_frame,
                    text=f"{suggestion}, {submit_lightning_state.upper()}",
                    font=("Helvetica", 11),
                    command=lambda candidate=suggestion: rerun_with_lightning_suggestion(candidate),
                ).grid(row=0, column=index, padx=(0, 10), pady=0, sticky="w")

        # Create the 'Next' button to retry or skip
        next_button = create_button(frame1, "Try Again", button_font, lightning_center_input)
        next_button.grid(row=next_row, column=0, padx=(50, 0), pady=10, sticky="w")
        
        skip_button = create_button(frame1, "Skip Lightning", button_font, choose_lg_still_sat)  # or another appropriate function
        skip_button.grid(row=next_row, column=0, padx=(190, 0), pady=10, sticky="w")
  
def lightning_center_input():
    global box_variables, lightning_town, lightning_state, shift_active, current_target_entry

    if box_variables[3] == 1:
        # Reset current_target_entry
        current_target_entry = None

        # Clear the current display
        for widget in frame1.winfo_children():
            widget.destroy()
        hide_display_frame_for_frame1()

        frame1.grid(row=0, column=0, sticky="nsew")
        frame1.tkraise()

        instruction_text = "Please enter the name of the town for the center of the lightning map,\nor just click Near Me to generate a map near your location:"
        add_modern_screen_text(
            frame1,
            tk,
            tk_background_color,
            "The Weather Observer",
            instruction_text,
            title_row=0,
            body_row=1,
            title_padx=50,
            title_pady=(50, 0),
            body_padx=50,
            body_pady=5,
            title_columnspan=20,
            body_columnspan=20,
            sticky="nw",
        )

        lightning_town = tk.Entry(frame1, font=("Helvetica", 14))
        lightning_town.grid(row=2, column=0, columnspan=20, padx=50, pady=5, sticky="nw")
        style_input_entry(lightning_town)
        set_keyboard_mode(lightning_town, "town")
        lightning_town.focus_set()  # Set focus to the first entry widget

        state_instruction_text = "Please enter the 2-letter state ID for the center of the lightning map:"
        state_instructions_label = tk.Label(frame1, text=state_instruction_text, font=("Helvetica Neue", 15), fg="black", bg=tk_background_color, justify="left")
        state_instructions_label.grid(row=3, column=0, columnspan=20, padx=50, pady=5, sticky="nw")

        # Create the lightning_state Entry first!
        lightning_state = tk.Entry(frame1, font=("Helvetica", 14))
        lightning_state.grid(row=4, column=0, columnspan=20, padx=50, pady=5, sticky="nw")
        style_input_entry(lightning_state)
        set_keyboard_mode(lightning_state, "state")

        # Add state entry to dictionary AFTER creating lightning_state
        state_entry_widgets["lightning_state"] = lightning_state

        lightning_town.bind("<FocusIn>", lambda e: set_current_target(lightning_town))
        lightning_state.bind("<FocusIn>", lambda e: set_current_target(lightning_state))

        #force uppercase for state input.
        lightning_state.bind("<FocusIn>", lambda e: [set_current_target(lightning_state), set_state_uppercase()])

        auto_capitalize()  # call auto capitalize after focus bind.

        if box_variables[2] == 1:
            back_function = choose_lcl_radar
        else:
            back_function = page_choose

        button_row = tk.Frame(frame1, bg=tk_background_color)
        button_row.grid(row=5, column=0, padx=50, pady=5, sticky="nw")

        back_button = create_modern_button(button_row, tk, " Back ", back_function, font=("Helvetica", 16, "bold"), variant="secondary")
        back_button.grid(row=0, column=0, padx=(0, 18), pady=0, sticky="w")

        submit_button = create_modern_button(button_row, tk, "Submit", submit_lightning_center, font=("Helvetica", 16, "bold"), variant="primary")
        submit_button.grid(row=0, column=1, padx=(0, 18), pady=0, sticky="w")

        near_me_button = create_modern_button(button_row, tk, "Near Me", submit_lightning_near_me, font=("Helvetica", 16, "bold"), variant="secondary")
        near_me_button.grid(row=0, column=2, padx=0, pady=0, sticky="w")

        shift_active = True  # force uppercase
        create_virtual_keyboard(frame1, 6)
        update_keyboard_shift_state()  # update the keyboard.
        
        # release any stale grabs and assert focus after layout
        try: root.grab_release()
        except: pass
        frame1.update_idletasks()
        root.after_idle(lambda: focus_widget_if_alive(lightning_town))
        root.after_idle(lambda: set_current_target_if_alive(lightning_town))

    else:
        choose_lg_still_sat()

def station_center_input():
    global box_variables, refresh_flag, station_plot_town, station_plot_state, zoom_plot, random_sites_flag, submit_station_plot_center_near_me_flag, aobs_site, current_target_entry, shift_active, frame1_overlay_lock

    random_sites_flag = False
    zoom_plot = None

    if box_variables[7] == 1:

        # Reset current_target_entry
        current_target_entry = None

        # Clear the current display
        for widget in frame1.winfo_children():
            widget.destroy()
        hide_display_frame_for_frame1()
        
        # special page setup to handle case when previous GUI doesn't have radiosonde map available
        frame1.master.grid_rowconfigure(0, weight=1)
        frame1.master.grid_columnconfigure(0, weight=1)
        frame1.grid(row=0, column=0, sticky="nsew")
        frame1.tkraise()

        zoom_plot = tk.StringVar(value="9")

        def submit_station_plot_center_near_me():
            global submit_station_plot_center_near_me_flag
            submit_station_plot_center_near_me_flag = True
            submit_station_plot_center()

        def submit_station_plot_center():
            global submit_station_plot_town, submit_station_plot_state, station_plot_lat, station_plot_lon, zoom_plot
            global refresh_flag, current_frame_index, submit_station_plot_center_near_me_flag, aobs_site

            def rerun_with_station_plot_suggestion(suggested_town):
                global submit_station_plot_center_near_me_flag
                submit_station_plot_center_near_me_flag = False
                station_center_input()
                station_plot_town.delete(0, tk.END)
                station_plot_town.insert(0, suggested_town)
                station_plot_state.delete(0, tk.END)
                station_plot_state.insert(0, submit_station_plot_state.upper())
                submit_station_plot_center()

            try:
                show_transition_overlay()
                root.update_idletasks()
                station_plot_geolocator = Nominatim(user_agent="station_plot_map")
                zoom_plot = zoom_plot.get()

                if submit_station_plot_center_near_me_flag == False:
                    submit_station_plot_town = station_plot_town.get()
                    submit_station_plot_state = station_plot_state.get()
                    station_plot_query = f"{submit_station_plot_town}, {submit_station_plot_state}"

                elif submit_station_plot_center_near_me_flag == True:
                    station_plot_query = aobs_site
                    submit_station_plot_center_near_me_flag = False

                station_plot_location = station_plot_geolocator.geocode(station_plot_query)

                if station_plot_location:
                    station_plot_lat = station_plot_location.latitude
                    station_plot_lon = station_plot_location.longitude

                    if not barograph_started:
                        frame1_overlay_lock = False
                        frame1.grid_forget()
                        root.bind("<ButtonPress-1>", on_touch_start)
                        root.bind("<B1-Motion>", handle_swipe)
                        root.bind("<Left>", lambda event: on_left_swipe(event))
                        root.bind("<Right>", lambda event: on_right_swipe(event))
                        current_frame_index = 0
                        timer_override = False
                        start_animation()
                    else:
                        refresh_flag = False
                        #print("line 5920. A call back to image cycle.")
                        return_to_image_cycle()

                else:
                    hide_transition_overlay()
                            
                    for widget in frame1.winfo_children():
                            widget.destroy()

                    instruction_text = "Not able to use that location as center."
                    instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16), bg=tk_background_color)
                    instructions_label.grid(row=1, column=0, padx=50, pady=(20, 10))

                    suggestions = _build_state_place_suggestions(submit_station_plot_town, submit_station_plot_state)
                    next_row = 2
                    if suggestions:
                        suggestion_label = tk.Label(
                            frame1,
                            text="Did you mean:",
                            font=("Helvetica Neue", 14, "bold"),
                            fg="black",
                            bg=tk_background_color,
                            justify="left",
                        )
                        suggestion_label.grid(row=next_row, column=0, padx=(50, 0), pady=(10, 6), sticky="w")
                        next_row += 1

                        suggestions_frame = tk.Frame(frame1, bg=tk_background_color)
                        suggestions_frame.grid(row=next_row, column=0, padx=(50, 0), pady=(0, 10), sticky="w")
                        next_row += 1

                        for index, suggestion in enumerate(suggestions[:3]):
                            tk.Button(
                                suggestions_frame,
                                text=f"{suggestion}, {submit_station_plot_state.upper()}",
                                font=("Helvetica", 11),
                                command=lambda candidate=suggestion: rerun_with_station_plot_suggestion(candidate),
                            ).grid(row=0, column=index, padx=(0, 10), pady=0, sticky="w")

                    back_button = create_button(frame1, "Back", button_font, station_center_input)
                    back_button.grid(row=next_row, column=0, padx=(50, 0), pady=10, sticky="w")

            except Exception as e:
                hide_transition_overlay()

                for widget in frame1.winfo_children():
                    widget.destroy()

                header_frame = tk.Frame(frame1, bg=tk_background_color)
                header_frame.grid(row=0, column=0, padx=50, pady=5, sticky="w")
                header_logo = create_small_weather_observer_logo(header_frame, size=(65, 65))
                header_logo.grid(row=0, column=0, padx=(0, 6), pady=(6, 0), sticky="w")
                label1 = tk.Label(frame1 if False else header_frame, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
                label1.grid(row=0, column=1, pady=(12, 0), sticky="w")

                instruction_text = "Not able to use that location as center."
                instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16), bg=tk_background_color)
                instructions_label.grid(row=1, column=0, padx=50, pady=(20, 10))

                suggestions = _build_state_place_suggestions(submit_station_plot_town, submit_station_plot_state)
                next_row = 2
                if suggestions:
                    suggestion_label = tk.Label(
                        frame1,
                        text="Did you mean:",
                        font=("Helvetica Neue", 14, "bold"),
                        fg="black",
                        bg=tk_background_color,
                        justify="left",
                    )
                    suggestion_label.grid(row=next_row, column=0, padx=(50, 0), pady=(10, 6), sticky="w")
                    next_row += 1

                    suggestions_frame = tk.Frame(frame1, bg=tk_background_color)
                    suggestions_frame.grid(row=next_row, column=0, padx=(50, 0), pady=(0, 10), sticky="w")
                    next_row += 1

                    for index, suggestion in enumerate(suggestions[:3]):
                        tk.Button(
                            suggestions_frame,
                            text=f"{suggestion}, {submit_station_plot_state.upper()}",
                            font=("Helvetica", 11),
                            command=lambda candidate=suggestion: rerun_with_station_plot_suggestion(candidate),
                        ).grid(row=0, column=index, padx=(0, 10), pady=0, sticky="w")

                back_button = create_button(frame1, "Back", button_font, station_center_input)
                back_button.grid(row=next_row, column=0, padx=(50, 0), pady=10, sticky="w")

        add_modern_screen_text(
            frame1,
            tk,
            tk_background_color,
            "The Weather Observer",
            "Please enter the name of the town for the center of the station plot map,\nor just click Near Me to generate a map near your location:",
            title_row=0,
            body_row=1,
            title_padx=50,
            title_pady=(42, 0),
            body_padx=50,
            body_pady=(0, 0),
            title_columnspan=20,
            body_columnspan=20,
            sticky="nw",
        )

        station_plot_town = tk.Entry(frame1, font=("Helvetica", 14))
        station_plot_town.grid(row=2, column=0, columnspan=20, padx=50, pady=(0, 1), sticky='nw')
        style_input_entry(station_plot_town)
        set_keyboard_mode(station_plot_town, "town")
        station_plot_town.focus_set()

        state_instructions_label = tk.Label(frame1, text="Please enter the 2-letter state ID for the center of the station plot map:", font=("Helvetica Neue", 15), fg="black", bg=tk_background_color)
        state_instructions_label.grid(row=3, column=0, columnspan=20, padx=50, pady=(0, 1), sticky='nw')

        # Create the station_plot_state Entry first!
        station_plot_state = tk.Entry(frame1, font=("Helvetica", 14))
        station_plot_state.grid(row=4, column=0, columnspan=20, padx=50, pady=(0, 4), sticky='nw')
        style_input_entry(station_plot_state)
        set_keyboard_mode(station_plot_state, "state")

        # Add state entry to dictionary AFTER creating station_plot_state
        state_entry_widgets["station_plot_state"] = station_plot_state

        station_plot_town.bind("<FocusIn>", lambda e: set_current_target(station_plot_town))
        station_plot_state.bind("<FocusIn>", lambda e: set_current_target(station_plot_state))

        #force uppercase for state input.
        station_plot_state.bind("<FocusIn>", lambda e: [set_current_target(station_plot_state), set_state_uppercase()])

        # Reset current_target_entry AFTER widget creation.
        current_target_entry = None

        auto_capitalize()  # call auto capitalize after focus bind.

        radio_buttons_info = [
            ("Few small\ncounties", "10"),
            ("Several\ncounties", "9"),
            ("States", "6"),
            ("Continents", "4"),
            ("Almost a\nhemisphere", "3")
        ]

        radio_button1 = tk.Radiobutton(frame1, text=radio_buttons_info[0][0], variable=zoom_plot, value=radio_buttons_info[0][1],
            font=("Helvetica Neue", 11), fg="black", bg=tk_background_color, bd=0, highlightthickness=0, justify="left")
        radio_button1.grid(row=5, column=0, columnspan=1, sticky="w", padx=(50, 0))

        radio_button2 = tk.Radiobutton(frame1, text=radio_buttons_info[1][0], variable=zoom_plot, value=radio_buttons_info[1][1],
                                        font=("Helvetica Neue", 11), fg="black", bg=tk_background_color, bd=0, highlightthickness=0, justify="left")
        radio_button2.grid(row=5, column=0, columnspan=1, sticky="w", padx=(200, 0))

        radio_button3 = tk.Radiobutton(frame1, text=radio_buttons_info[2][0], variable=zoom_plot, value=radio_buttons_info[2][1],
                                        font=("Helvetica Neue", 11), fg="black", bg=tk_background_color, bd=0, highlightthickness=0, justify="left")
        radio_button3.grid(row=5, column=0, columnspan=1, sticky="w", padx=(350, 0))

        radio_button4 = tk.Radiobutton(frame1, text=radio_buttons_info[3][0], variable=zoom_plot, value=radio_buttons_info[3][1],
                                        font=("Helvetica Neue", 11), fg="black", bg=tk_background_color, bd=0, highlightthickness=0, justify="left")
        radio_button4.grid(row=5, column=0, columnspan=1, sticky="w", padx=(470, 0))

        radio_button5 = tk.Radiobutton(frame1, text=radio_buttons_info[4][0], variable=zoom_plot, value=radio_buttons_info[4][1],
                                        font=("Helvetica Neue", 11), fg="black", bg=tk_background_color, bd=0, highlightthickness=0, justify="left")
        radio_button5.grid(row=5, column=0, columnspan=1, sticky="w", padx=(600, 0))

        if box_variables[8] == 1:
            back_function = choose_radiosonde_site

        elif box_variables[5] == 1:
            back_function = choose_reg_sat

        elif box_variables[3] == 1:
            back_function = lightning_center_input

        elif box_variables[2] == 1:
            back_function = choose_lcl_radar

        else:
            back_function = page_choose

        button_row = tk.Frame(frame1, bg=tk_background_color)
        button_row.grid(row=6, column=0, padx=50, pady=4, sticky="nw")

        back_button = create_modern_button(button_row, tk, " Back ", back_function, font=("Helvetica", 16, "bold"), variant="secondary")
        back_button.grid(row=0, column=0, padx=(0, 18), pady=0, sticky="w")

        submit_button = create_modern_button(button_row, tk, "Submit", submit_station_plot_center, font=("Helvetica", 16, "bold"), variant="primary")
        submit_button.grid(row=0, column=1, padx=(0, 18), pady=0, sticky='w')

        near_me_button = create_modern_button(button_row, tk, "Near Me", submit_station_plot_center_near_me, font=("Helvetica", 16, "bold"), variant="secondary")
        near_me_button.grid(row=0, column=2, padx=0, pady=0, sticky='w')

        create_virtual_keyboard(frame1, 7)
        
        try: root.grab_release()
        except: pass
        frame1.update_idletasks()
        root.after_idle(lambda: focus_widget_if_alive(station_plot_town))
        root.after_idle(lambda: set_current_target_if_alive(station_plot_town))

    else:
        if not barograph_started:
            frame1_overlay_lock = False
            frame1.grid_forget()

            root.bind("<ButtonPress-1>", on_touch_start)
            root.bind("<B1-Motion>", handle_swipe)
            root.bind("<Left>", lambda event: on_left_swipe(event))
            root.bind("<Right>", lambda event: on_right_swipe(event))

            current_frame_index = 0
            timer_override = False
            start_animation()

        else:
            refresh_flag = False
            timer_override = False
            return_to_image_cycle()
            
def cobs_land_or_buoy():
    global cobs_only_click_flag, frame1_overlay_lock
    frame1_overlay_lock = True

    instruction_text = "Do you want the third observation site to be on land or a buoy?\n\nOr use one of the random options below."
    random_option_buttons = [
        ("This Site", lambda: generate_random_sites(selection_count=1, target_obs_type="cobs", back_function=cobs_land_or_buoy)),
        ("All 3 Sites", lambda: generate_random_sites(back_function=cobs_land_or_buoy)),
    ]

    build_land_or_buoy_screen(
        frame1,
        tk,
        create_button,
        button_font,
        tk_background_color,
        "The Weather Observer",
        instruction_text,
        setup_cobs_input_land,
        setup_cobs_input_buoy,
        back_command=return_to_image_cycle if cobs_only_click_flag else setup_bobs_input_buoy,
        random_option_buttons=random_option_buttons,
    )
        
def bobs_land_or_buoy():
    global bobs_only_click_flag, frame1_overlay_lock
    frame1_overlay_lock = True

    instruction_text = "Do you want the second observation site to be on land or a buoy?\n\nOr use one of the random options below."
    random_option_buttons = [
        ("This Site", lambda: generate_random_sites(selection_count=1, target_obs_type="bobs", back_function=bobs_land_or_buoy)),
        ("All 3 Sites", lambda: generate_random_sites(back_function=bobs_land_or_buoy)),
    ]

    build_land_or_buoy_screen(
        frame1,
        tk,
        create_button,
        button_font,
        tk_background_color,
        "The Weather Observer",
        instruction_text,
        setup_bobs_input_land,
        setup_bobs_input_buoy,
        back_command=return_to_image_cycle if bobs_only_click_flag else land_or_buoy,
        random_option_buttons=random_option_buttons,
    )
        
def land_or_buoy():
    global aobs_only_click_flag, RANDOM_CANDIDATE_STATIONS_CACHE, RANDOM_CANDIDATE_STATIONS_20_CACHE, frame1_overlay_lock
    frame1_overlay_lock = True

    refresh_random_candidate_caches()
    print("line 6541. assembled 20-mile and 100-mile random site candidate caches for future random requests.")

    random_command = None
    instruction_text = "Do you want the first observation site to be on land or a buoy?\n\nOr use one of the random options below."
    random_option_buttons = [
        ("This Site", lambda: generate_random_sites(selection_count=1, target_obs_type="aobs", back_function=land_or_buoy)),
        ("All 3 Sites", lambda: generate_random_sites(back_function=land_or_buoy)),
    ]
    
    build_land_or_buoy_screen(
        frame1,
        tk,
        create_button,
        button_font,
        tk_background_color,
        "The Weather Observer",
        instruction_text,
        setup_aobs_input_land,
        setup_aobs_input_buoy,
        back_command=return_to_image_cycle if aobs_only_click_flag else confirm_calibration_site,
        random_command=random_command,
        random_option_buttons=random_option_buttons,
    )

# --- CORRECTED Helper function to parse time string (Uses direct timedelta) ---
def parse_last_update(time_str):
    """
    Parses time strings like 'X Hours, Y Minutes, Z Seconds' or variations
    into a timedelta object using the directly imported timedelta class.
    Returns None if parsing fails. (Corrected for direct timedelta import)
    """
    hours, minutes, seconds = 0, 0, 0
    match = re.search(
        r"(?:(\d+)\s+Hours?,\s*)?"
        r"(?:(\d+)\s+Minutes?,\s*)?"
        r"(\d+)\s+Seconds?",
        time_str,
        re.IGNORECASE
    )
    if match:
        h_str, m_str, s_str = match.groups()
        hours = int(h_str) if h_str else 0
        minutes = int(m_str) if m_str else 0
        seconds = int(s_str) if s_str else 0
        # *** Use direct timedelta() call ***
        return timedelta(hours=hours, minutes=minutes, seconds=seconds)
    else:
        match = re.search(
             r"(?:(\d+)\s+Minutes?,\s*)?"
             r"(\d+)\s+Seconds?",
             time_str,
             re.IGNORECASE)
        if match:
             m_str, s_str = match.groups()
             minutes = int(m_str) if m_str else 0
             seconds = int(s_str) if s_str else 0
             # *** Use direct timedelta() call ***
             return timedelta(minutes=minutes, seconds=seconds)
        else:
             match = re.search(
                  r"(\d+)\s+Seconds?",
                  time_str,
                  re.IGNORECASE)
             if match:
                  s_str = match.group(1)
                  seconds = int(s_str) if s_str else 0
                  # *** Use direct timedelta() call ***
                  return timedelta(seconds=seconds)

    return None

# --- CORRECTED function to check radar status (Uses direct timedelta) ---
def check_radar_status(radar_identifier):
    """
    Checks radar status by cleaning the page to raw text and using Regex.
    Returns True if operational (<=30 min latency), False otherwise.
    """
    global lcl_radar_updated_flag

    radar_id_upper = radar_identifier.strip().upper()
    
    # 1. Validate ID
    if len(radar_id_upper) != 4 or not radar_id_upper.isalnum():
         print(f"Error: Invalid Radar ID format: '{radar_identifier}'.")
         return False

    url = "https://radar3pub.ncep.noaa.gov/"
    headers = {
        'User-Agent': 'Python Radar Status Checker Script v9 (Text Clean)'
    }
    
    print(f"Checking status for {radar_id_upper}...")

    try:
        response = requests.get(url, headers=headers, timeout=15)
        if response.status_code != 200:
            print(f"HTTP error fetching status list: {response.status_code}")
            return False
        
        # 2. Parse and Flatten to Text
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # This converts the entire HTML page into a simple string with spaces.
        # It fixes the issue where tags were merging words together.
        clean_text = soup.get_text(separator=' ')
        
        # 3. Find the Pattern in the clean text
        # Pattern looks for: ID + space + HH:MM:SS + space + MM/DD/YY
        # We use \s+ to handle any amount of spaces/tabs/newlines
        pattern = re.compile(rf"{radar_id_upper}\s+(\d{{2}}:\d{{2}}:\d{{2}})\s+(\d{{2}}/\d{{2}}/\d{{2}})")
        
        match = pattern.search(clean_text)
        
        if not match:
            # Fallback: Try to print what we 'almost' found for debugging
            print(f"Debug: Could not find '{radar_id_upper}' in clean text.")
            return False

        time_str = match.group(1) # 12:53:33
        date_str = match.group(2) # 11/21/25

        # 4. Calculate Latency
        full_dt_str = f"{date_str} {time_str}"
        
        try:
            radar_time = datetime.strptime(full_dt_str, "%m/%d/%y %H:%M:%S")
            radar_time = radar_time.replace(tzinfo=timezone.utc)
        except ValueError:
            print(f"Debug: Date format error. Parsed: '{full_dt_str}'")
            return False

        current_time = datetime.now(timezone.utc)
        latency = current_time - radar_time
        threshold = timedelta(minutes=30)

        if latency <= threshold:
            lcl_radar_updated_flag = False
            return True
        else:
            print(f"Radar {radar_id_upper} is stale. Last update: {full_dt_str} (Latency: {latency})")
            return False

    except requests.exceptions.RequestException as e:
        print(f"Network error checking radar '{radar_id_upper}': {e}")
        return False
    except Exception as e:
        print(f"Error during parsing for radar '{radar_id_upper}': {e}")
        return False

# --- confirm_radar_site function remains unchanged ---
def confirm_radar_site():
    global radar_identifier, lcl_radar_zoom_clicks, lcl_radar_zoom_clicks_value, confirm_label, submit_button
    global lcl_radar_zoom_label, lcl_radar_dropdown, message_label
    global RADAR_PAGE_LEFT_PANEL, RADAR_PAGE_DYNAMIC_MESSAGE_LABEL, RADAR_PAGE_MESSAGE_AREA

    # Get the zoom level from the dropdown
    lcl_radar_zoom_clicks_value = lcl_radar_zoom_clicks.get()

    # Display the "Checking radar site..." message
    checking_message = "Checking radar site..."
    # Assume frame1, tk, tk_background_color are defined elsewhere in your GUI code
    if RADAR_PAGE_DYNAMIC_MESSAGE_LABEL is not None and RADAR_PAGE_DYNAMIC_MESSAGE_LABEL.winfo_exists():
        RADAR_PAGE_DYNAMIC_MESSAGE_LABEL.destroy()
        RADAR_PAGE_DYNAMIC_MESSAGE_LABEL = None

    message_label = tk.Label(RADAR_PAGE_MESSAGE_AREA, text=checking_message, font=("Arial", 14), justify='left',
                             bg=tk_background_color, wraplength=230)
    message_label.grid(row=0, column=0, padx=(10, 0), pady=(2, 0), sticky='nw')
    RADAR_PAGE_DYNAMIC_MESSAGE_LABEL = message_label

    # Disable the submit button to prevent multiple clicks
    submit_button.config(state='disabled')

    # Start the radar site check in a separate thread
    def check_site():
        is_functioning = check_radar_status(radar_identifier) # CALLS THE UPDATED FUNCTION

        # Update the GUI after checking the radar site
        def update_gui():
            global message_label  # Ensure we're modifying the message_label from confirm_radar_site

            if is_functioning:
                # Radar is functioning, proceed to the next step
                # Set the zoom clicks to the selected value
                lcl_radar_zoom_clicks.set(lcl_radar_zoom_clicks_value)
                if message_label is not None and message_label.winfo_exists():
                    message_label.destroy()
                message_label = None
                RADAR_PAGE_DYNAMIC_MESSAGE_LABEL = None

                frame1.after(1, lightning_center_input)
            else:
                # Radar is unavailable
                # Remove existing message_label if any
                if message_label is not None and message_label.winfo_exists():
                    message_label.destroy()
                    message_label = None
                RADAR_PAGE_DYNAMIC_MESSAGE_LABEL = None

                # Display error message
                unavailable_message = "The selected radar site is currently unavailable.\nPlease choose another site."
                message_label = tk.Label(RADAR_PAGE_MESSAGE_AREA, text=unavailable_message, font=("Arial", 13), justify='left',
                                         bg=tk_background_color, fg="red", wraplength=230)
                message_label.grid(row=0, column=0, padx=(10, 0), pady=(2, 0), sticky='nw')
                RADAR_PAGE_DYNAMIC_MESSAGE_LABEL = message_label

                # Re-enable the submit button
                submit_button.config(state='normal')

        # Schedule the GUI update in the main thread
        # Assumes frame1 is your tkinter container widget
        frame1.after(0, update_gui)

    # Start the thread
    # Assumes threading is imported
    threading.Thread(target=check_site, daemon=True).start()

def confirm_calibration_site():
    global submit_calibration_town, show_baro_input, baro_input, aobs_site
    
    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()
    hide_display_frame_for_frame1()

    frame1.grid(row=0, column=0, sticky="nesw")
    frame1.tkraise()
    
    add_modern_screen_text(
        frame1,
        tk,
        tk_background_color,
        "The Weather Observer",
        aobs_site,
        title_row=0,
        body_row=1,
        title_padx=50,
        title_pady=(40, 0),
        body_padx=50,
        body_pady=(12, 10),
        title_columnspan=1,
        body_columnspan=1,
        sticky="w",
    )
    updated_text = f"will be used as the calibration site."
    label2 = tk.Label(frame1, text=updated_text, font=("Helvetica Neue", 15), fg="black", bg=tk_background_color)
    label2.grid(row=2, column=0, padx=(50,0), pady=(20, 30), sticky='w') 
    
    button_row = tk.Frame(frame1, bg=tk_background_color)
    button_row.grid(row=3, column=0, padx=50, pady=5, sticky="w")

    back_button = create_modern_button(button_row, tk, "Back", welcome_screen, font=button_font, variant="secondary")
    back_button.grid(row=0, column=0, padx=(0, 18), pady=0, sticky="w")

    next_button = create_modern_button(button_row, tk, "Next", land_or_buoy, font=button_font, variant="primary")
    next_button.grid(row=0, column=1, padx=0, pady=0, sticky="w")

def submit_calibration_input():
    global submit_calibration_town, submit_calibration_state, calibration_town, calibration_state, calibration_lat, calibration_lon, aobs_site
    global show_baro_input, baro_input, latitude, longitude
    global RANDOM_CANDIDATE_STATIONS_CACHE, RANDOM_CANDIDATE_STATIONS_20_CACHE
    
    submit_calibration_town = calibration_town.get()
    submit_calibration_state = calibration_state.get()

    submit_calibration_town = submit_calibration_town.title()
    submit_calibration_state = submit_calibration_state.upper()

    aobs_site = submit_calibration_town + ", " + submit_calibration_state

    refresh_random_candidate_caches()
    #print("line 6599. assembled list of random site candidates for future random requests.")

    for widget in frame1.winfo_children():
        widget.destroy()
    frame1.update_idletasks()
    show_transition_overlay("Getting data from the suggested calibration location...")

    def _perform_calibration_lookup():
        global calibration_lat, calibration_lon, latitude, longitude, baro_input, show_baro_input
        geolocator = Nominatim(user_agent="geocoder_app")

        try:
            # Attempt to geocode the location
            location = geolocator.geocode(f"{submit_calibration_town}, {submit_calibration_state}", country_codes="us")
        
            if location is not None:
                calibration_lat = location.latitude
                calibration_lon = location.longitude
            
                latitude = location.latitude
                longitude = location.longitude

                response = requests.get(f'https://api.weather.gov/points/{calibration_lat},{calibration_lon}')
                if response.status_code == 200:
                    data = response.json()
                    stations_url = data['properties']['observationStations']
                    stations_response = requests.get(stations_url)
                    if stations_response.status_code == 200:
                        stations_data = stations_response.json()

                        for station_url in stations_data['observationStations']:
                            obs_response = requests.get(f"{station_url}/observations/latest")
                            if obs_response.status_code == 200:
                                obs_data = obs_response.json()
                                if 'barometricPressure' in obs_data['properties'] and obs_data['properties']['barometricPressure']['value'] is not None:
                                    baro_input = pascals_to_inches_hg(obs_data['properties']['barometricPressure']['value'])
                                    show_baro_input = f'{baro_input:.2f}'
                                    instruction_text = f"The barometric pressure at {aobs_site} is {show_baro_input} inches.\nDo you want to keep this as the calibration site,\nchange the site again or,\nenter your own barometric pressure?"
                                    hide_transition_overlay()
                                    display_calibration_results(instruction_text)
                                    return

                hide_transition_overlay()
                display_calibration_error("No usable barometric pressure reading was found.")
            else:
                hide_transition_overlay()
                display_calibration_error(
                    "Could not match that location with a barometric pressure reading.",
                    suggestions=_build_state_place_suggestions(
                        submit_calibration_town,
                        submit_calibration_state,
                    ),
                )
        
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout, geopy.exc.GeocoderUnavailable):
            hide_transition_overlay()
            display_calibration_error("Geo services are temporarily out of service. Please try again later.")

    frame1.after(75, _perform_calibration_lookup)
        
def display_calibration_results(instruction_text):
    """Displays the calibration results on the GUI."""
    hide_display_frame_for_frame1()
    add_modern_screen_text(
        frame1,
        tk,
        tk_background_color,
        "The Weather Observer",
        instruction_text,
        title_row=0,
        body_row=1,
        title_padx=50,
        title_pady=(40, 0),
        body_padx=50,
        body_pady=(10, 20),
        title_columnspan=1,
        body_columnspan=1,
        sticky="w",
    )

    button_row = tk.Frame(frame1, bg=tk_background_color)
    button_row.grid(row=2, column=0, padx=50, pady=20, sticky="w")

    back_button = create_modern_button(button_row, tk, " Back ", change_calibration_site, font=button_font, variant="secondary")
    back_button.grid(row=0, column=0, padx=(0, 18), pady=0, sticky="w")
    
    keep_button = create_modern_button(button_row, tk, " Keep ", confirm_calibration_site, font=button_font, variant="primary")
    keep_button.grid(row=0, column=1, padx=(0, 18), pady=0, sticky="w")
    change_button = create_modern_button(button_row, tk, "Change", change_calibration_site, font=button_font, variant="secondary")
    change_button.grid(row=0, column=2, padx=(0, 18), pady=0, sticky="w")
    enter_own_button = create_modern_button(button_row, tk, " Own ", own_calibration_site, font=button_font, variant="secondary")
    enter_own_button.grid(row=0, column=3, padx=0, pady=0, sticky="w")

def _apply_calibration_suggestion(suggested_town):
    global calibration_town, calibration_state

    change_calibration_site()
    calibration_town.delete(0, tk.END)
    calibration_town.insert(0, suggested_town)
    calibration_state.delete(0, tk.END)
    calibration_state.insert(0, submit_calibration_state)
    submit_calibration_input()


def _normalize_state_place_name(value):
    cleaned = []
    for char in (value or "").upper():
        cleaned.append(char if char.isalnum() else " ")
    raw_tokens = " ".join("".join(cleaned).split()).split()
    token_aliases = {
        "MT": "MOUNT",
        "MTN": "MOUNTAIN",
        "N": "NORTH",
        "S": "SOUTH",
        "E": "EAST",
        "W": "WEST",
        "NE": "NORTHEAST",
        "NW": "NORTHWEST",
        "SE": "SOUTHEAST",
        "SW": "SOUTHWEST",
    }
    normalized_tokens = [token_aliases.get(token, token) for token in raw_tokens]
    return " ".join(normalized_tokens)


def _build_state_place_suggestions(entered_town, entered_state, limit=3):
    query_normalized = _normalize_state_place_name(entered_town)
    if not query_normalized:
        return []

    try:
        stations = load_all_stations_cached_dicts()
    except Exception:
        return []

    unique_state_names = {}
    target_state = str(entered_state or "").strip().upper()

    for station in stations or []:
        if str(station.get("state", "")).strip().upper() != target_state:
            continue

        cleaned_name = clean_station_name(station.get("name", "")).strip()
        normalized_name = _normalize_state_place_name(cleaned_name)
        if not cleaned_name or not normalized_name or normalized_name == query_normalized:
            continue

        existing_name = unique_state_names.get(normalized_name)
        if existing_name is None or len(cleaned_name) < len(existing_name):
            unique_state_names[normalized_name] = cleaned_name

    close_keys = difflib.get_close_matches(
        query_normalized,
        list(unique_state_names.keys()),
        n=limit,
        cutoff=0.72,
    )
    suggestions = [unique_state_names[key] for key in close_keys]
    if suggestions:
        return suggestions

    ranked = []
    for normalized_name, cleaned_name in unique_state_names.items():
        similarity = difflib.SequenceMatcher(None, query_normalized, normalized_name).ratio()
        if similarity >= 0.64:
            ranked.append((similarity, cleaned_name))

    ranked.sort(key=lambda item: (-item[0], item[1]))
    return [name for _, name in ranked[:limit]]


def display_calibration_error(message, suggestions=None):
    """Displays an error message on the GUI."""
    instructions_label = tk.Label(frame1, text=message, font=("Helvetica Neue", 15), fg="black", bg=tk_background_color)
    instructions_label.grid(row=1, column=0, padx=(50,0), pady=(20, 10))
    next_row = 2

    if suggestions:
        suggestion_label = tk.Label(
            frame1,
            text="Did you mean:",
            font=("Helvetica Neue", 14, "bold"),
            fg="black",
            bg=tk_background_color,
            justify="left",
        )
        suggestion_label.grid(row=next_row, column=0, padx=(50, 0), pady=(10, 6), sticky="w")
        next_row += 1

        suggestions_frame = tk.Frame(frame1, bg=tk_background_color)
        suggestions_frame.grid(row=next_row, column=0, padx=(50, 0), pady=(0, 10), sticky="w")
        next_row += 1

        for index, suggestion in enumerate(suggestions[:3]):
            tk.Button(
                suggestions_frame,
                text=f"{suggestion}, {submit_calibration_state}",
                font=("Helvetica", 11),
                command=lambda candidate=suggestion: _apply_calibration_suggestion(candidate),
            ).grid(row=0, column=index, padx=(0, 10), pady=0, sticky="w")

    change_button = create_modern_button(frame1, tk, "Change", change_calibration_site, font=button_font, variant="secondary")
    change_button.grid(row=next_row, column=0, padx=(50,0), pady=5, sticky="w")
        
        
def change_calibration_site():
    global calibration_town, calibration_state, current_target_entry, state_entry_widgets, is_buoy_code

    # Reset current_target_entry
    current_target_entry = None

    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()
    hide_display_frame_for_frame1()

    frame1.grid(row=0, column=0, sticky="nsew")
    frame1.tkraise()

    add_modern_screen_text(
        frame1,
        tk,
        tk_background_color,
        "The Weather Observer",
        "Please enter the name of the town to be used for calibration:",
        title_row=0,
        body_row=1,
        title_padx=50,
        title_pady=(50, 5),
        body_padx=(50, 0),
        body_pady=5,
        title_columnspan=20,
        body_columnspan=20,
        sticky="nw",
    )

    calibration_town = tk.Entry(frame1, font=("Helvetica", 14), justify="left")
    calibration_town.grid(row=2, column=0, columnspan=20, padx=(50, 0), pady=5, sticky='nw')
    style_input_entry(calibration_town)
    set_keyboard_mode(calibration_town, "town")
    calibration_town.bind("<FocusIn>", lambda e: set_current_target(calibration_town))
    calibration_town.focus_set()

    state_instructions_label = tk.Label(frame1, text="Please enter the 2-letter state ID for the calibration site:", font=("Helvetica Neue", 15), fg="black", bg=tk_background_color, justify="left")
    state_instructions_label.grid(row=3, column=0, columnspan=20, padx=(50, 0), pady=5, sticky='nw')

    calibration_state = tk.Entry(frame1, font=("Helvetica", 14))
    calibration_state.grid(row=4, column=0, columnspan=20, padx=(50, 0), pady=5, sticky='nw')
    style_input_entry(calibration_state)
    set_keyboard_mode(calibration_state, "state")
    calibration_state.bind("<FocusIn>", lambda e: [set_current_target(calibration_state), set_state_uppercase()]) # added

    # Add the calibration state to the state_entry_widgets dict.
    state_entry_widgets["calibration_state"] = calibration_state

    button_row = tk.Frame(frame1, bg=tk_background_color)
    button_row.grid(row=5, column=0, padx=50, pady=5, sticky="nw")

    back_button = create_modern_button(button_row, tk, " Back ", welcome_screen, font=("Helvetica", 16, "bold"), variant="secondary")
    back_button.grid(row=0, column=0, padx=(0, 18), pady=0, sticky="w")

    submit_button = create_modern_button(button_row, tk, "Submit", submit_calibration_input, font=("Helvetica", 16, "bold"), variant="primary")
    submit_button.grid(row=0, column=1, padx=0, pady=0, sticky='w')

    # Set is_buoy_code to False before calling create_virtual_keyboard
    is_buoy_code = False
    create_virtual_keyboard(frame1, 6)

def set_current_target(entry_widget):
    keyboard_set_keyboard_target(entry_widget, globals(), tk, auto_capitalize, update_keyboard_shift_state)


def focus_widget_if_alive(widget):
    try:
        if widget is not None and widget.winfo_exists():
            widget.focus_force()
    except Exception:
        pass


def set_current_target_if_alive(widget):
    try:
        if widget is not None and widget.winfo_exists():
            set_current_target(widget)
    except Exception:
        pass
    
def own_calibration_site():
    global baro_input_box, current_target_entry, calibration_town, calibration_state

    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()
    hide_display_frame_for_frame1()

    frame1.grid(row=0, column=0, sticky="nsew")
    frame1.tkraise()

    instruction_text = "Please enter the current barometric pressure reading in inches from your own source.\nEnter in the form XX.XX"
    add_modern_screen_text(
        frame1,
        tk,
        tk_background_color,
        "The Weather Observer",
        instruction_text,
        title_row=0,
        body_row=1,
        title_padx=50,
        title_pady=(30, 0),
        body_padx=50,
        body_pady=0,
        title_columnspan=20,
        body_columnspan=20,
        sticky="nw",
    )

    # Create an Entry widget for the user to input the barometric pressure
    baro_input_box = tk.Entry(frame1, font=("Helvetica", 14), width=10)  # Adjust width as necessary
    baro_input_box.grid(row=2, column=0, columnspan=20, padx=50, pady=5, sticky="nw")
    style_input_entry(baro_input_box)
    set_keyboard_mode(baro_input_box, "numeric", allowed_chars="0123456789.")
    baro_input_box.bind("<FocusIn>", lambda e: set_current_target(baro_input_box))
    baro_input_box.focus_set()
    
    label_text = "inches of mercury"
    label = tk.Label(frame1, text=label_text, font=("Helvetica Neue", 14), fg="black", bg=tk_background_color)
    label.grid(row=2, column=0, columnspan=20, padx=(170, 0), pady=(8,4), sticky="nw")  # Minor adjustment for positioning next to the entry
    
    home_town_label = tk.Label(frame1, text="Please enter the name of the town where the barometer is being measured:", font=("Helvetica Neue", 15), fg="black", bg=tk_background_color, justify="left")
    home_town_label.grid(row=3, column=0, columnspan=20, padx=(50,0), pady=(5,0), sticky='nw')
    
    calibration_town = tk.Entry(frame1, font=("Helvetica", 14), justify="left")
    calibration_town.grid(row=4, column=0, columnspan=20, padx=(50,0), pady=(0,10), sticky='nw')
    style_input_entry(calibration_town)
    set_keyboard_mode(calibration_town, "town")
    calibration_town.bind("<FocusIn>", lambda e: set_current_target(calibration_town))
        
    home_state_label = tk.Label(frame1, text="Please enter the 2-letter state ID where the barometer is being measured:", font=("Helvetica Neue", 15), fg="black", bg=tk_background_color, justify="left")
    home_state_label.grid(row=5, column=0, columnspan=20, padx=(50,0), pady=0, sticky='nw')
    
    calibration_state = tk.Entry(frame1, font=("Helvetica", 14))
    calibration_state.grid(row=6, column=0, columnspan=20, padx=(50,0), pady=(0,10), sticky='nw')
    style_input_entry(calibration_state)
    set_keyboard_mode(calibration_state, "state")
    calibration_state.bind("<FocusIn>", lambda e: set_current_target(calibration_state))
    
    button_row = tk.Frame(frame1, bg=tk_background_color)
    button_row.grid(row=7, column=0, padx=50, pady=5, sticky="nw")

    back_button = create_modern_button(button_row, tk, " Back ", welcome_screen, font=("Helvetica", 16, "bold"), variant="secondary")
    back_button.grid(row=0, column=0, padx=(0, 18), pady=0, sticky="w")

    submit_button = create_modern_button(button_row, tk, "Submit", submit_calibration_input, font=("Helvetica", 16, "bold"), variant="primary")
    submit_button.grid(row=0, column=1, padx=0, pady=0, sticky="w")

    # Display the virtual keyboard
    create_virtual_keyboard(frame1, 8)
    
def submit_own_calibration():
    global baro_input 

    # Get the user's input
    baro_input = float(baro_input_box.get())
 
    # Continue with other actions or functions as needed
    land_or_buoy()

def hide_display_frame_for_frame1():
    transition_return_timer = globals().get("TRANSITION_RETURN_TIMER")

    if transition_return_timer is not None:
        try:
            root.after_cancel(transition_return_timer)
        except Exception:
            pass
        globals()["TRANSITION_RETURN_TIMER"] = None

    try:
        display_image_frame.grid_forget()
    except Exception:
        pass
    try:
        frame1.tkraise()
    except Exception:
        pass

WELCOME_LOGO_IMAGE = None
ROOT_CORNER_LOGO = None
RADAR_PAGE_LOGO_IMAGE = {}
RADAR_PAGE_LEFT_PANEL = None
RADAR_PAGE_STATUS_PANEL = None
RADAR_PAGE_DYNAMIC_MESSAGE_LABEL = None
RADAR_PAGE_MESSAGE_AREA = None
RADAR_PAGE_LEFT_PANEL = None
RADAR_PAGE_STATUS_PANEL = None
RADAR_PAGE_DYNAMIC_MESSAGE_LABEL = None
PAGE_CHOOSE_THUMBNAILS = {}
REG_SAT_SECTOR_THUMBNAILS = {}
PAGE_CHOOSE_THUMBNAIL_FILES = [
    "01_barograph.png",
    "02_national_radar.png",
    "03_local_radar.png",
    "04_lightning.png",
    "05_large_still_satellite.png",
    "06_regional_satellite.png",
    "07_national_surface.png",
    "08_station_plots.png",
    "09_radiosonde.png",
    "10_vorticity.png",
    "11_storm_reports.png",
    "12_next_idea.png",
]
REG_SAT_SECTOR_THUMBNAIL_FILES = [
    "pacific_nw.png",
    "upper_mississippi_valley.png",
    "northeast.png",
    "canada_northern_us.png",
    "pacific_sw.png",
    "southern_mississippi_valley.png",
    "southeast.png",
    "gulf_of_mexico.png",
    "northern_rockies.png",
    "great_lakes.png",
    "us_pacific_coast.png",
    "caribbean.png",
    "southern_rockies.png",
    "southern_plains.png",
    "us_atlantic_coast.png",
    "tropical_atlantic.png",
]

def get_page_choose_thumbnail(filename):
    global PAGE_CHOOSE_THUMBNAILS

    thumb_path = os.path.join(os.path.dirname(__file__), "page_choose_thumbs", filename)
    if filename not in PAGE_CHOOSE_THUMBNAILS:
        PAGE_CHOOSE_THUMBNAILS[filename] = tk.PhotoImage(file=thumb_path)
    return PAGE_CHOOSE_THUMBNAILS[filename]

def get_reg_sat_sector_thumbnail(filename):
    global REG_SAT_SECTOR_THUMBNAILS

    thumb_path = os.path.join(os.path.dirname(__file__), "reg_sat_sector_thumbs", filename)
    if filename not in REG_SAT_SECTOR_THUMBNAILS:
        REG_SAT_SECTOR_THUMBNAILS[filename] = tk.PhotoImage(file=thumb_path)
    return REG_SAT_SECTOR_THUMBNAILS[filename]

def preload_ui_thumbnail_caches():
    for filename in PAGE_CHOOSE_THUMBNAIL_FILES:
        try:
            get_page_choose_thumbnail(filename)
        except Exception as e:
            print(f"Page choose thumbnail preload failed for {filename}: {e}")

    for filename in REG_SAT_SECTOR_THUMBNAIL_FILES:
        try:
            get_reg_sat_sector_thumbnail(filename)
        except Exception as e:
            print(f"Regional satellite thumbnail preload failed for {filename}: {e}")

def create_weather_observer_welcome_badge(parent):
    global WELCOME_LOGO_IMAGE

    logo_path = os.path.join(os.path.dirname(__file__), "welcome_logo_large.png")
    logo_label = tk.Label(parent, bg=tk_background_color, bd=0, highlightthickness=0)

    try:
        if WELCOME_LOGO_IMAGE is None:
            WELCOME_LOGO_IMAGE = tk.PhotoImage(file=logo_path)
        logo_label.config(image=WELCOME_LOGO_IMAGE)
        logo_label.image = WELCOME_LOGO_IMAGE
    except Exception:
        fallback = tk.Canvas(parent, width=158, height=158, bg=tk_background_color, highlightthickness=0, bd=0)
        fallback.create_oval(4, 4, 154, 154, fill="#f0d447", outline="#7c9fb3", width=2)
        fallback.create_text(79, 60, text="The\nWeather\nObserver", font=("Helvetica Neue", 18, "bold"), fill="black", justify="left")
        return fallback

    return logo_label


def setup_root_corner_logo_overlay():
    global ROOT_CORNER_LOGO, ROOT_CORNER_CANVAS, WELCOME_LOGO_IMAGE

    try:
        if ROOT_CORNER_LOGO is None:
            logo_path = os.path.join(os.path.dirname(__file__), "welcome_logo_large.png")
            try:
                if WELCOME_LOGO_IMAGE is None:
                    WELCOME_LOGO_IMAGE = tk.PhotoImage(file=logo_path)
                ROOT_CORNER_LOGO = ROOT_CORNER_CANVAS.create_image(0, 0, image=WELCOME_LOGO_IMAGE, anchor="nw")
            except Exception:
                ROOT_CORNER_CANVAS.delete("all")
                ROOT_CORNER_LOGO = ROOT_CORNER_CANVAS.create_oval(4, 4, 154, 154, fill="#f0d447", outline="#7c9fb3", width=2)
                ROOT_CORNER_CANVAS.create_text(79, 60, text="The\nWeather\nObserver", font=("Helvetica Neue", 18, "bold"), fill="black", justify="left")
        ROOT_CORNER_CANVAS.tk.call('raise', ROOT_CORNER_CANVAS._w)
    except Exception:
        pass


def raise_root_corner_logo():
    global ROOT_CORNER_CANVAS

    try:
        ROOT_CORNER_CANVAS.tk.call('raise', ROOT_CORNER_CANVAS._w)
    except Exception:
        pass

def create_small_weather_observer_logo(parent, size=(54, 54)):
    global RADAR_PAGE_LOGO_IMAGE

    width = int(size[0]) if isinstance(size, (tuple, list)) else int(size)
    if width >= 65:
        logo_filename = "welcome_logo_header.png"
        cache_key = "header"
    else:
        logo_filename = "welcome_logo_small.png"
        cache_key = "small"

    logo_path = os.path.join(os.path.dirname(__file__), logo_filename)
    logo_label = tk.Label(parent, bg=tk_background_color, bd=0, highlightthickness=0)

    try:
        if cache_key not in RADAR_PAGE_LOGO_IMAGE:
            RADAR_PAGE_LOGO_IMAGE[cache_key] = tk.PhotoImage(file=logo_path)
        logo_label.config(image=RADAR_PAGE_LOGO_IMAGE[cache_key])
        logo_label.image = RADAR_PAGE_LOGO_IMAGE[cache_key]
    except Exception:
        logo_label.config(text="TWO", font=("Helvetica Neue", 12, "bold"), fg="black")

    return logo_label

frame1._weather_observer_logo_factory = create_small_weather_observer_logo

def build_welcome_screen_header(parent, title_text, subtitle_text=None):
    header_frame = tk.Frame(parent, bg=tk_background_color)
    header_frame.grid(row=0, column=0, padx=50, pady=(34, 14), sticky="w")

    badge = create_weather_observer_welcome_badge(header_frame)
    badge.grid(row=0, column=0, padx=(0, 20), sticky="nw")

    text_frame = tk.Frame(header_frame, bg=tk_background_color)
    text_frame.grid(row=0, column=1, sticky="nw")

    title_label = tk.Label(
        text_frame,
        text=title_text,
        font=("Helvetica Neue", 32, "bold"),
        fg="black",
        bg=tk_background_color,
        justify="left",
    )
    title_label.grid(row=0, column=0, sticky="w")

    version_label = tk.Label(
        text_frame,
        text=f"Version {VERSION}",
        font=("Helvetica Neue", 18),
        fg="black",
        bg=tk_background_color,
        justify="left",
    )
    version_label.grid(row=1, column=0, sticky="w", pady=(4, 0))

    if subtitle_text:
        subtitle_label = tk.Label(
            text_frame,
            text=subtitle_text,
            font=("Helvetica Neue", 18),
            fg="black",
            bg=tk_background_color,
            justify="left",
            wraplength=520,
        )
        subtitle_label.grid(row=2, column=0, sticky="w", pady=(8, 0))

def welcome_screen():
    
    # here's a block for some business after many functions defined, but passing here only once
    setup_function_button_frame()
    
    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()
    hide_display_frame_for_frame1()

    frame1.grid(row=0, column=0, sticky="nsew")
    frame1.tkraise()

    if baro_input is None:
        own_calibration_site()
        return

    build_welcome_screen_header(
        frame1,
        "The Weather Observer",
    )

    intro_text = (
        "First, the barometric pressure needs to be calibrated for your location.\n"
        "The wifi signal indicates your location below:"
    )
    intro_label = tk.Label(
        frame1,
        text=intro_text,
        font=("Helvetica Neue", 22),
        fg="black",
        bg=tk_background_color,
        justify="left",
        wraplength=760,
    )
    intro_label.grid(row=1, column=0, padx=50, pady=(0, 10), sticky="w")

    location_label = tk.Label(
        frame1,
        text=aobs_site,
        font=("Helvetica Neue", 24, "bold"),
        fg="black",
        bg=tk_background_color,
        justify="left",
    )
    location_label.grid(row=2, column=0, padx=50, pady=(0, 8), sticky="w")

    detail_text = (
        f"Pressure observed there: {baro_input:.2f} inches.\n"
        "Keep this location, change it, or enter your own known reading."
    )
    detail_label = tk.Label(
        frame1,
        text=detail_text,
        font=("Helvetica Neue", 20),
        fg="black",
        bg=tk_background_color,
        justify="left",
        wraplength=760,
    )
    detail_label.grid(row=3, column=0, padx=50, pady=(0, 18), sticky="w")

    # Define frame_question
    frame_question = tk.Frame(frame1, bg=tk_background_color)
    frame_question.grid(row=4, column=0, padx=50, pady=(0, 5), sticky="w")

    # Create the 'Keep' button
    keep_button = create_modern_button(frame_question, tk, "Keep", confirm_calibration_site, font=button_font, variant="primary")
    keep_button.grid(row=0, column=0, padx=(0, 18), pady=0, sticky="w")

    # Create the 'Change' button
    change_button = create_modern_button(frame_question, tk, "Change", change_calibration_site, font=button_font, variant="secondary")
    change_button.grid(row=0, column=1, padx=(0, 18), pady=0, sticky="w")

    # Create the 'Enter Your Own' button
    enter_own_button = create_modern_button(frame_question, tk, "Own", own_calibration_site, font=button_font, variant="secondary")
    enter_own_button.grid(row=0, column=2, padx=0, pady=0, sticky="w")

if location == None:
    build_welcome_screen_header(
        frame1,
        "The Weather Observer Startup",
    )

    info_text = (
        "First, the barometric pressure needs to be calibrated for your location.\n"
        "The wifi signal could not determine your location.\n\n"
        "Please click Next to enter your location below.\n"
        "Or click Own to enter your own known, current, accurate barometric\n"
        "pressure reading to be used for calibration."
    )
    label2 = tk.Label(frame1, text=info_text, font=("Helvetica Neue", 20), fg="black", bg=tk_background_color, justify="left")
    label2.grid(row=1, column=0, padx=50, pady=(0, 18), sticky='w')

    # Define frame_question
    frame_question = tk.Frame(frame1, bg=tk_background_color)
    frame_question.grid(row=2, column=0, padx=50, pady=(0, 5), sticky="w")

    # Create the 'Change' button
    change_button = create_modern_button(frame_question, tk, "Next", change_calibration_site, font=button_font, variant="primary")
    change_button.grid(row=0, column=0, padx=(0, 18), pady=0, sticky="w")

    # Create the 'Enter Your Own' button
    enter_own_button = create_modern_button(frame_question, tk, "Own", own_calibration_site, font=button_font, variant="secondary")
    enter_own_button.grid(row=0, column=1, padx=0, pady=0, sticky="w")

else:
    welcome_screen()
    
def initialize_random_candidate_cache(master_station_list, user_location_str, max_radius_miles=100, diagnostic_file_path=None):
    """
    Geocodes a user location and filters a master station list to find all
    stations within a maximum search radius.

    This function is intended to be run once at startup to create a smaller,
    pre-filtered list of candidate stations for subsequent random selections.
    It also saves the filtered list to a JSON file for diagnostics.

    Args:
        master_station_list (list): The complete list of station dictionaries.
        user_location_str (str): The location to search near (e.g., "Watertown, MA").

    Returns:
        list: A list of candidate station dictionaries within the max radius,
              or an empty list if an error occurs.
    """
    if not master_station_list:
        print("[ERROR] Master station list is empty. Cannot initialize random candidate cache.")
        return []

    print(f"Initializing random candidate cache for location: '{user_location_str}'...")

    try:
        # 1. Geocode the user's location to get lat/lon
        geolocator = Nominatim(user_agent="station_cache_initializer")
        center_location = geolocator.geocode(user_location_str, exactly_one=True, timeout=10)
        if center_location is None:
            print(f"[ERROR] Could not geocode the location: {user_location_str}")
            return []
        
        center_lat, center_lon = center_location.latitude, center_location.longitude
        print(f"Successfully geocoded location to: Lat {center_lat:.4f}, Lon {center_lon:.4f}")

        # 2. Create a bounding box for the maximum search area
        lat_deg_per_mile = 1.0 / 69.0
        lon_deg_per_mile = 1.0 / (math.cos(math.radians(center_lat)) * 69.0)
        
        lat_delta = max_radius_miles * lat_deg_per_mile
        lon_delta = max_radius_miles * lon_deg_per_mile
        
        min_lat, max_lat = center_lat - lat_delta, center_lat + lat_delta
        min_lon, max_lon = center_lon - lon_delta, center_lon + lon_delta

        # 3. Filter the master list to find all stations within the bounding box
        candidate_stations = [
            s for s in master_station_list
            if "latitude" in s and "longitude" in s and
               min_lat <= s["latitude"] <= max_lat and
               min_lon <= s["longitude"] <= max_lon
        ]
        
        print(f"Found {len(candidate_stations)} candidate stations within {max_radius_miles} miles.")

        # 4. Save the resulting list to a file for your inspection
        if diagnostic_file_path:
            try:
                with open(diagnostic_file_path, 'w') as f:
                    json.dump(candidate_stations, f, indent=4)
                print(f"Successfully saved candidate list to {diagnostic_file_path}")
            except IOError as e:
                print(f"[ERROR] Could not write diagnostic file: {e}")

        return candidate_stations

    except Exception as e:
        print(f"[ERROR] An unexpected error occurred during cache initialization: {e}")
        return []


def refresh_random_candidate_caches():
    global RANDOM_CANDIDATE_STATIONS_CACHE, RANDOM_CANDIDATE_STATIONS_20_CACHE, RANDOM_CANDIDATE_CACHE_LOCATION

    if (
        RANDOM_CANDIDATE_CACHE_LOCATION == aobs_site
        and RANDOM_CANDIDATE_STATIONS_20_CACHE
        and RANDOM_CANDIDATE_STATIONS_CACHE
    ):
        print(f"[RANDOM] Reusing existing 20-mile and 100-mile candidate caches for '{aobs_site}'.")
        return

    RANDOM_CANDIDATE_STATIONS_20_CACHE = initialize_random_candidate_cache(
        ALL_STATIONS_CACHE,
        aobs_site,
        max_radius_miles=20,
    )
    RANDOM_CANDIDATE_STATIONS_CACHE = initialize_random_candidate_cache(
        ALL_STATIONS_CACHE,
        aobs_site,
        max_radius_miles=100,
        diagnostic_file_path="/home/santod/random_candidate_stations.json",
    )
    RANDOM_CANDIDATE_CACHE_LOCATION = aobs_site

# --- Example of how to call this function in your main script ---

# This would go in your startup code, after ALL_STATIONS_CACHE and aobs_site are defined.
# Note: You will need to define the new global variable at the top of your script.
# RANDOM_CANDIDATE_STATIONS_CACHE = None

# print("\n--- Initializing random station candidate cache ---")
# RANDOM_CANDIDATE_STATIONS_CACHE = initialize_random_candidate_cache(
#     master_station_list=ALL_STATIONS_CACHE,
#     user_location_str=aobs_site
# )
# print(f"Initialization complete. Cache contains {len(RANDOM_CANDIDATE_STATIONS_CACHE)} stations.")

#RANDOM_CANDIDATE_STATIONS_CACHE = initialize_random_candidate_cache(ALL_STATIONS_CACHE, aobs_site)

# Call this function to stop the image cycle and forget all frames
def forget_all_frames():
    global auto_advance_timer, update_images_timer

    # Cancel the auto-advance timer if it's running
    if auto_advance_timer:
        root.after_cancel(auto_advance_timer)
        auto_advance_timer = None
        print("line 6599. Auto-advance timer canceled.")

    # Cancel the update_images timer if it's running
    if update_images_timer:
        root.after_cancel(update_images_timer)
        update_images_timer = None
        print("line 6605. Update images timer canceled.")

    display_image_frame.grid_forget()
        
    function_button_frame.grid_forget()


def finish_return_to_image_cycle():
    if frame1_overlay_lock:
        return

    display_return_to_image_cycle(
        globals(),
        root,
        frame1,
        display_image_frame,
        image_keys,
        lambda image_key: show_image_in_display_frame(image_key),
        update_images,
        auto_advance_frames,
        show_function_button_frame,
        clear_random_map_ui,
        update_transparent_frame_data,
        xs,
    )


def return_to_image_cycle():
    global frame1_overlay_lock
    frame1_overlay_lock = False
    hide_transition_overlay()
    finish_return_to_image_cycle()

def run_lcl_radar_loop_animation():
    display_run_lcl_radar_loop_animation(globals(), available_image_dictionary, display_label, root)

# Function to display the regional satellite loop
def run_reg_sat_loop_animation():
    display_run_reg_sat_loop_animation(globals(), available_image_dictionary, display_label, root)


# update images/loops in queue design 7/10/25
def update_images():
    scheduler_update_images(
        globals(),
        root,
        datetime,
        timedelta,
        asyncio,
        monitor_system_health,
        fetch_and_process_baro_pic,
        fetch_and_process_still_sat,
        fetch_and_process_radiosonde,
        fetch_and_process_national_radar,
        fetch_and_process_national_sfc,
        fetch_and_process_vorticity,
        fetch_and_process_storm_reports,
        run_lightning_task,
        run_lcl_radar_task,
        run_observations_task,
        run_sfc_plots_task,
        run_reg_sat_task,
        update_transparent_frame_data,
    )
    
def run_lightning_task():
    display_run_lightning_task(
        globals(),
        available_image_dictionary,
        lightning_lat,
        lightning_lon,
        CHROME_DRIVER_PATH,
        CHROMIUM_BIN,
        root,
        fetch_and_process_lightning,
    )

def run_lcl_radar_task():
    display_run_lcl_radar_task(
        globals(),
        available_image_dictionary,
        box_variables,
        root,
        CHROME_DRIVER_PATH,
        CHROMIUM_BIN,
        radar_identifier,
        lcl_radar_zoom_clicks,
        auto_advance_frames,
        get_lcl_radar_loop,
    )

def run_observations_task():
    scheduler_run_observations_task(
        globals(),
        asyncio,
        background_loop,
        data_update_queue,
        scrape_land_station_data_async,
        get_buoy_data_async,
    )


def run_sfc_plots_task():
    display_run_sfc_plots_task(
        globals(),
        available_image_dictionary,
        station_plot_lat,
        station_plot_lon,
        zoom_plot,
        CHROME_DRIVER_PATH,
        CHROMIUM_BIN,
        fetch_and_process_sfc_plots,
    )

def run_reg_sat_task():
    display_run_reg_sat_task(
        globals(),
        available_image_dictionary,
        reg_sat_frames,
        box_variables,
        CHROME_DRIVER_PATH,
        CHROMIUM_BIN,
        reg_sat_choice_variables,
        module_fetch_and_process_reg_sat_loop,
    )

# Swipe functionality for left swipe
def on_left_swipe(event):
    display_on_left_swipe(
        event,
        globals(),
        root,
        num_frames,
        box_variables,
        lambda image_key: show_image_in_display_frame(image_key),
    )

# --- Modify on_right_swipe ---
def on_right_swipe(event):
    display_on_right_swipe(
        event,
        globals(),
        root,
        num_frames,
        box_variables,
        lambda image_key: show_image_in_display_frame(image_key),
    )

# --- Modify show_image_in_display_frame with diagnostics ---
def show_image_in_display_frame(image_key):
    return display_show_image_in_display_frame(
        image_key,
        globals(),
        root,
        available_image_dictionary,
        display_image_frame,
        display_label,
        transparent_frame,
        run_lcl_radar_loop_animation,
        run_reg_sat_loop_animation,
        None,
        recreate_display_image_frame,
    )

def auto_advance_frames():
    display_auto_advance_frames(
        globals(),
        root,
        image_keys,
        num_frames,
        box_variables,
        available_image_dictionary,
        lambda image_key: show_image_in_display_frame(image_key),
    )

ax.axhspan(30.5, 31.0, color='gold', alpha=.5)
ax.axhspan(30.0, 30.5, color='yellow', alpha=.2)
ax.axhspan(29.5, 30.0, color='gainsboro', alpha=.5)
ax.axhspan(29.0, 29.5, color='darkgrey', alpha=.5)
ax.axhspan(28.75, 29.0, color='#8c8c8c', alpha=.55)

# Lines on minor ticks
for t in np.arange(28.75, 31, 0.05):
    ax.axhline(t, color='black', lw=.5, alpha=.2)
for u in np.arange(28.75, 31.01, 0.25):
    ax.axhline(u, color='black', lw=.7)

ax.tick_params(axis='x', direction='inout', length=5, width=1, color='black')
# Remove y-axis ticks without affecting the grid lines
ax.tick_params(axis='y', which='both', length=0)

plt.grid(True, color='.01')  # Draws default horiz and vert grid lines
#ax.yaxis.set_minor_locator(AutoMinorLocator(5))
#ax.yaxis.set_major_formatter(FormatStrFormatter('%2.2f'))

# Add annotation for day of the week - this defines it
day_label = ax.annotate('', xy=(0, 0), xycoords='data', ha='center', va='center',
                         fontsize=10, fontstyle='italic', color='blue')

# Set major and minor ticks format for midnight label and other vertical lines
ax.xaxis.set(
    major_locator=mdates.HourLocator(byhour=[0, 4, 8, 12, 16, 20]),
    major_formatter=mdates.DateFormatter('%-I%P'),
    minor_locator=mdates.HourLocator(interval=1),
    minor_formatter=ticker.FuncFormatter(lambda x, pos: '\n%a,%-m/%-d' if (isinstance(x, datetime) and x.hour == 0) else '')
)

ax.xaxis.set(
    minor_locator=mdates.DayLocator(),
    minor_formatter=mdates.DateFormatter("\n%a,%-m/%-d"),
)

# This line seems responsible for vertical lines
ax.grid(which='major', axis='both', linestyle='-', linewidth=1, color='black', alpha=1, zorder=10)

# Disable removing overlapping locations
ax.xaxis.remove_overlapping_locs = False

# Copying this over from daysleanbaro2-5-24. Not sure it's necessary
# This gets midnight of the current day, then figures the x value for 12 pm
now = datetime.now()
date_time = pd.to_datetime(now.strftime("%m/%d/%Y, %H:%M:%S"))
midnight = datetime.combine(date_time.date(), datetime.min.time())
x_value_12pm = mdates.date2num(midnight.replace(hour=12))

y_value_day_label = 30.90

# Add annotation for day of the week - this defines it
day_label = ax.annotate('', xy=(0,0), xycoords='data', ha='center', va='center',
                         fontsize=10, fontstyle='italic', color='blue')

# Set axis limits and labels
now = datetime.now()
time_delta = timedelta(minutes=3600)
start_time = now - time_delta

ax.set_xlim(start_time, now)
ax.set_ylim(28.75, 31)

ax.set_yticklabels([])

# # Create empty xs and ys arrays
# xs = []
# ys = []

# Create a line plot
line, = ax.plot([], [], 'r-')

# Get I2C bus
bus = smbus.SMBus(1)

yesterday_annotation = None
before_yesterday_annotation = None
today_annotation_flag = False
today_inHg_annotation_flag = False
last_midnight_reset_date = None
#_day_3050_annotation = None

# Initialize a dictionary to keep track of annotations
annotations_created = {
    "before_yesterday": False,
    "bday_2900": False,
    "bday_3050": False,
    "bday_3000": False,
    "bday_2950": False
}

def setup_transparent_frame():
    """
    (Corrected & Complete) Creates the main UI widgets ONCE using the
    pre-existing global StringVar objects. This is safe to copy and paste.
    """
    global persistent_widgets, timestamp_text, ROOT_CORNER_LOGO
    global left_combined_text, middle_combined_text, right_combined_text

    show_transparent_frame_overlay()

    setup_root_corner_logo_overlay()

    # --- Create Buttons with their permanent properties ---
    # The font, width, and command will be set in the update function.
    left_button = tk.Button(transparent_frame, textvariable=left_combined_text, fg="black", bg=tk_background_color, activebackground=tk_background_color, activeforeground="black", anchor="w", justify="left", relief=tk.RAISED, bd=3, highlightthickness=2, highlightbackground="#7c91a0", highlightcolor="#cfdce7", pady=1)
    middle_button = tk.Button(transparent_frame, textvariable=middle_combined_text, fg="black", bg=tk_background_color, activebackground=tk_background_color, activeforeground="black", anchor="w", justify="left", relief=tk.RAISED, bd=3, highlightthickness=2, highlightbackground="#7c91a0", highlightcolor="#cfdce7", pady=1)
    right_button = tk.Button(transparent_frame, textvariable=right_combined_text, fg="black", bg=tk_background_color, activebackground=tk_background_color, activeforeground="black", anchor="w", justify="left", relief=tk.RAISED, bd=3, highlightthickness=2, highlightbackground="#7c91a0", highlightcolor="#cfdce7", pady=1)

    left_window = transparent_frame.create_window(18, 1, anchor="nw", window=left_button)
    middle_window = transparent_frame.create_window(302, 1, anchor="nw", window=middle_button)
    right_window = transparent_frame.create_window(586, 1, anchor="nw", window=right_button)

    # --- Store widgets and window ids for access in the update function ---
    persistent_widgets = {
        "left_button": left_button,
        "middle_button": middle_button,
        "right_button": right_button,
        "left_window": left_window,
        "middle_window": middle_window,
        "right_window": right_window,
    }
    
def update_transparent_frame_data():
    """
    (Replaces show_transparent_frame)
    Updates the text and commands of the persistent widgets.
    This is lightweight and does NOT create new widgets.
    """
    # This function needs to read the data and flags to work correctly.
    global alternative_town_1, alternative_town_2, alternative_town_3
    global aobs_only_click_flag, bobs_only_click_flag, cobs_only_click_flag, extremes_flag, frame1_overlay_lock
    global awind, awtemp, atemp, bwind, bwtemp, btemp, cwind, cwtemp, ctemp
    global aobs_buoy_signal, bobs_buoy_signal, cobs_buoy_signal
    global left_combined_text, middle_combined_text, right_combined_text
    global persistent_widgets # We need this to access the buttons

    if frame1_overlay_lock:
        try:
            transparent_frame.place_forget()
        except Exception:
            pass
        try:
            transparent_frame.grid_forget()
        except Exception:
            pass
        try:
            function_button_frame.grid_forget()
        except Exception:
            pass
        return

    # --- UI and Flag Handling (This logic is unchanged) ---
    if not aobs_only_click_flag and not bobs_only_click_flag and not cobs_only_click_flag and not extremes_flag:
        frame1.grid_forget()
    if not extremes_flag:
        if not str(transparent_frame.winfo_manager()):
            show_transparent_frame_overlay()
        if not function_button_frame.winfo_ismapped():
            show_function_button_frame()

    required_widget_keys = {"left_button", "middle_button", "right_button"}
    if not isinstance(persistent_widgets, dict) or not required_widget_keys.issubset(persistent_widgets.keys()):
        setup_transparent_frame()
    else:
        try:
            if not all(persistent_widgets[key].winfo_exists() for key in required_widget_keys):
                setup_transparent_frame()
        except Exception:
            setup_transparent_frame()

    # The top canvases are persistent; only button content changes here
    # --- Define FULL on_click handlers ---
    # These are the complete functions you need.
    def aobs_buoy_on_click():
        prepare_observation_button_edit(
            globals(),
            forget_all_frames,
            baro_frame,
            transparent_frame,
            ROOT_CORNER_CANVAS,
            "aobs_only_click_flag",
            "aobs_buoy_signal",
            land_or_buoy,
        )

    def aobs_on_click():
        prepare_observation_button_edit(
            globals(),
            forget_all_frames,
            baro_frame,
            transparent_frame,
            ROOT_CORNER_CANVAS,
            "aobs_only_click_flag",
            "aobs_buoy_signal",
            land_or_buoy,
        )

    def bobs_buoy_on_click():
        prepare_observation_button_edit(
            globals(),
            forget_all_frames,
            baro_frame,
            transparent_frame,
            ROOT_CORNER_CANVAS,
            "bobs_only_click_flag",
            "bobs_buoy_signal",
            bobs_land_or_buoy,
        )

    def bobs_on_click():
        prepare_observation_button_edit(
            globals(),
            forget_all_frames,
            baro_frame,
            transparent_frame,
            ROOT_CORNER_CANVAS,
            "bobs_only_click_flag",
            "bobs_buoy_signal",
            bobs_land_or_buoy,
        )

    def cobs_buoy_on_click():
        prepare_observation_button_edit(
            globals(),
            forget_all_frames,
            baro_frame,
            transparent_frame,
            ROOT_CORNER_CANVAS,
            "cobs_only_click_flag",
            "cobs_buoy_signal",
            cobs_land_or_buoy,
        )

    def cobs_on_click():
        prepare_observation_button_edit(
            globals(),
            forget_all_frames,
            baro_frame,
            transparent_frame,
            ROOT_CORNER_CANVAS,
            "cobs_only_click_flag",
            "cobs_buoy_signal",
            cobs_land_or_buoy,
        )

    # --- Update Left Button ---
    left_button = persistent_widgets["left_button"]
    if aobs_buoy_signal:
        left_combined_text.set(f"Buoy: {alternative_town_1.upper()}\n{atemp}\n{awtemp}\nWind: {awind}")
        left_button.config(font=buoy_font, width=29, height=4, command=aobs_buoy_on_click)
    else:
        left_combined_text.set(f"{alternative_town_1}\nTemp: {atemp}\nWind: {awind}")
        left_button.config(font=obs_font, width=24, height=3, command=aobs_on_click)

    # --- Update Middle Button ---
    middle_button = persistent_widgets["middle_button"]
    if bobs_buoy_signal:
        middle_combined_text.set(f"Buoy: {alternative_town_2.upper()}\n{btemp}\n{bwtemp}\nWind: {bwind}")
        middle_button.config(font=buoy_font, width=29, height=4, command=bobs_buoy_on_click)
    else:
        middle_combined_text.set(f"{alternative_town_2}\nTemp: {btemp}\nWind: {bwind}")
        middle_button.config(font=obs_font, width=24, height=3, command=bobs_on_click)

    # --- Update Right Button ---
    right_button = persistent_widgets["right_button"]
    if cobs_buoy_signal:
        right_combined_text.set(f"Buoy: {alternative_town_3.upper()}\n{ctemp}\n{cwtemp}\nWind: {cwind}")
        right_button.config(font=buoy_font, width=29, height=4, command=cobs_buoy_on_click)
    else:
        right_combined_text.set(f"{alternative_town_3}\nTemp: {ctemp}\nWind: {cwind}")
        right_button.config(font=obs_font, width=24, height=3, command=cobs_on_click)

def run_barograph_update():
    global barograph_update_timer
    barograph_update_timer = None

    try:
        global xs, ys, line, yesterday_annotation, before_yesterday_annotation, threshold_x_value
        global inHg_correction_factor, refresh_flag, day_label
        global today_annotation_flag, today_inHg_annotation_flag, aobs_site
        global last_midnight_reset_date, last_baro_chart_update, version_footer_label
        global barograph_update_iteration

        i = barograph_update_iteration
        sample = read_barograph_sample(i, bus, baro_input, inHg_correction_factor)
        inHg = sample["in_hg"]
        inHg_correction_factor = sample["inhg_correction_factor"]

        time_context = build_barograph_time_context(
            datetime.now(),
            pd,
            datetime,
            timedelta,
            mdates,
        )
        xs, ys = append_barograph_point(xs, ys, time_context["date_time"], inHg)
        save_barograph_history(xs, ys, BAROGRAPH_HISTORY_PATH)

        annotation_state = {
            "yesterday_annotation": yesterday_annotation,
            "before_yesterday_annotation": before_yesterday_annotation,
            "today_annotation_flag": today_annotation_flag,
            "today_inhg_annotation_flag": today_inHg_annotation_flag,
            "annotations_created": annotations_created,
            "last_midnight_reset_date": last_midnight_reset_date,
            "timedelta_cls": timedelta,
        }
        reset_midnight_annotation_flags(time_context, annotation_state, ax)
        annotation_state = update_barograph_annotations(
            ax,
            day_label,
            time_context,
            annotation_state,
        )
        yesterday_annotation = annotation_state["yesterday_annotation"]
        before_yesterday_annotation = annotation_state["before_yesterday_annotation"]
        today_annotation_flag = annotation_state["today_annotation_flag"]
        today_inHg_annotation_flag = annotation_state["today_inhg_annotation_flag"]
        last_midnight_reset_date = annotation_state["last_midnight_reset_date"]

        finalize_barograph_frame(
            fig,
            ax,
            line,
            xs,
            ys,
            time_context,
            i,
            aobs_site,
            datetime,
            timedelta,
        )
        last_baro_chart_update = time_context["now"]
        try:
            if version_footer_label.winfo_exists():
                version_footer_label.configure(text=build_function_button_footer_text())
        except Exception:
            pass
        canvas.draw()
        barograph_update_iteration += 1

        # The transparent-frame heartbeat now runs from the scheduler/update loop
        # instead of piggybacking on the barograph animation callback.
        if refresh_flag or aobs_only_click_flag or bobs_only_click_flag or cobs_only_click_flag:
            return
        
    except Exception as e:
        print("Problems with Display Baro Trace. line 7178", e)
    finally:
        if barograph_update_timer is None:
            barograph_update_timer = root.after(180000, run_barograph_update)


TRANSITION_OVERLAY_FRAME = None
TRANSITION_RETURN_TIMER = None


def show_transition_overlay(message="Preparing data and images..."):
    global TRANSITION_OVERLAY_FRAME

    if TRANSITION_OVERLAY_FRAME is not None:
        try:
            TRANSITION_OVERLAY_FRAME.destroy()
        except Exception:
            pass
        TRANSITION_OVERLAY_FRAME = None

    overlay = tk.Frame(root, bg=tk_background_color)
    overlay.place(x=0, y=0, relwidth=1, relheight=1)

    content = tk.Frame(overlay, bg=tk_background_color)
    content.place(relx=0.5, rely=0.42, anchor="center")

    badge = create_weather_observer_welcome_badge(content)
    badge.grid(row=0, column=0, pady=(0, 18))

    message_label = tk.Label(
        content,
        text=message,
        font=("Helvetica Neue", 18),
        fg="black",
        bg=tk_background_color,
        justify="center",
    )
    message_label.grid(row=1, column=0, pady=(0, 6))

    TRANSITION_OVERLAY_FRAME = overlay
    overlay.lift()
    try:
        root.update_idletasks()
    except Exception:
        pass


def hide_transition_overlay():
    global TRANSITION_OVERLAY_FRAME, TRANSITION_RETURN_TIMER

    if TRANSITION_RETURN_TIMER is not None:
        try:
            root.after_cancel(TRANSITION_RETURN_TIMER)
        except Exception:
            pass
        TRANSITION_RETURN_TIMER = None

    try:
        if TRANSITION_OVERLAY_FRAME is not None:
            TRANSITION_OVERLAY_FRAME.destroy()
    except Exception:
        pass
    TRANSITION_OVERLAY_FRAME = None


# Create a function to start the animation
#@profile
def start_animation(): # code goes here once when the user starts barograph
    global barograph_update_timer, barograph_update_iteration, barograph_started, frame1_overlay_lock, TRANSITION_OVERLAY_FRAME, TRANSITION_RETURN_TIMER

    frame1_overlay_lock = False
    if TRANSITION_OVERLAY_FRAME is None:
        show_transition_overlay()
    else:
        try:
            root.update_idletasks()
        except Exception:
            pass
    frame1.grid_forget()
    baro_frame.grid_forget()
    clear_frame(frame1)
    display_image_frame.grid_forget()
    function_button_frame.grid_forget()
    try:
        transparent_frame.place_forget()
    except Exception:
        pass
    try:
        ROOT_CORNER_CANVAS.place_forget()
    except Exception:
        pass

    if barograph_update_timer:
        root.after_cancel(barograph_update_timer)
        barograph_update_timer = None

    if not barograph_started:
        barograph_update_iteration = 0

    barograph_started = True
    run_barograph_update()
    if TRANSITION_RETURN_TIMER is not None:
        try:
            root.after_cancel(TRANSITION_RETURN_TIMER)
        except Exception:
            pass
    TRANSITION_RETURN_TIMER = root.after(2200, finish_return_to_image_cycle)

async def scrape_land_station_data_async(list_of_station_codes, loop, obs_data_queue):
    """
    (Thread-Safe) Scrapes land station data in the background and puts the
    results into a thread-safe queue for the main GUI thread to process.
    """
    if not list_of_station_codes:
        return

    #print(f"--- Background task started: Scraping {len(list_of_station_codes)} land station(s) ---")
    
    def blocking_scraper():
        # This blocking function remains the same, but it will return results
        # to the async wrapper, which then puts them in the queue.
        results = {}
        for code in list_of_station_codes:
            results[code] = ("N/A", "N/A")

        driver = None
        try:
            if not CHROME_DRIVER_PATH:
                print("ERROR: ChromeDriver path is not set. Cannot start browser.")
                return
            options = Options()
            options.add_argument('--headless')
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            service = Service(CHROME_DRIVER_PATH)
            driver = webdriver.Chrome(service=service, options=options)
            try:
                pid = driver.service.process.pid
                #print(f"[OBS] DRIVER_START pid={pid}")
            except Exception:
                pass
                #print("[OBS] DRIVER_START pid=?")

            driver.set_page_load_timeout(20)
            driver.implicitly_wait(10)
            #print("LINE 7275 ASYNC SCRAPE OF LAND STATION DATA. DRIVER STARTED *************************************")
            for station_code in list_of_station_codes:
                temp, wind = "N/A", "N/A"
                try:
                    station_url = (
                        "https://www.weather.gov/wrh/timeseries?"
                        f"site={station_code}&hours=6&units=english&chart=off"
                        "&headers=none&obs=tabular&hourly=false&pview=standard&font=12"
                    )
                    driver.get(station_url)
                    table = driver.find_element(By.ID, "OBS_DATA")
                    headers = table.find_elements(By.CSS_SELECTOR, "thead tr#HEADER th")
                    col_indices = {h.get_attribute("id"): i for i, h in enumerate(headers)}
                    idx_temp = col_indices.get("temperature")
                    idx_winddir = col_indices.get("wind_dir")
                    idx_wind = col_indices.get("wind_speedgust")
                    first_valid_row_tds = None
                    rows = table.find_elements(By.CSS_SELECTOR, "tbody tr")
                    for r in rows[:3]:
                        tds = r.find_elements(By.TAG_NAME, "td")
                        if idx_temp is not None and len(tds) > idx_temp and tds[idx_temp].text.strip():
                            first_valid_row_tds = tds
                            break
                    if first_valid_row_tds:
                        tds = first_valid_row_tds
                        if idx_temp is not None:
                            temp_text = tds[idx_temp].text.strip()
                            if temp_text: temp = temp_text + chr(176)
                        if idx_winddir is not None and idx_wind is not None:
                            direction_text = tds[idx_winddir].text.strip()
                            wind_cell_text = tds[idx_wind].text.strip()
                            if direction_text and wind_cell_text:
                                wind_parts = [direction_text]
                                if "G" in wind_cell_text:
                                    speed_part, gust_part = wind_cell_text.split("G", 1)
                                    wind_parts.extend([f"at {speed_part} mph", f"G{gust_part}"])
                                else:
                                    wind_parts.append(f"at {wind_cell_text} mph")
                                wind = " ".join(wind_parts)
                    results[station_code] = (temp, wind)
                except Exception:
                    continue
        finally:
            if driver:
                pid = None
                try:
                    pid = driver.service.process.pid
                except Exception:
                    pass
                try:
                    driver.quit()
                    #print(f"[OBS] DRIVER_QUIT pid={pid} ok")
                except Exception as qe:
                    pass
                    #print(f"[OBS] DRIVER_QUIT pid={pid} raised {type(qe).__name__}")
                if pid is not None:
                    try:
                        os.kill(pid, 0)
                        #print(f"[OBS] DRIVER_KILL pid={pid} SIGKILL")
                        os.kill(pid, signal.SIGKILL)
                    except OSError:
                        pass
                    except Exception as ke:
                        pass
                        #print(f"[OBS] DRIVER_KILL pid={pid} error {type(ke).__name__}")
        
        return results

    # Run the blocking scraper in the background
    result_dict = await loop.run_in_executor(None, blocking_scraper)
    
    # Instead of returning the result, put it into the thread-safe queue
    if result_dict:
        obs_data_queue.put(result_dict)


def scrape_land_station_data(list_of_station_codes):
    """
    Scrapes temperature and wind data for a given list of land station codes
    using a single, shared browser instance for efficiency.
    """
    if not list_of_station_codes:
        return {}

    results = {}
    for code in list_of_station_codes:
        results[code] = ("N/A", "N/A")

    driver = None
    try:
        # Define your options for this specific function
        options = Options()
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')

        # Point to the driver path determined at startup
        service = Service(CHROME_DRIVER_PATH)

        # Initialize the driver with both objects
        driver = webdriver.Chrome(service=service, options=options)
        #print("LINE 7356 SYNC SCRAPE OF LAND STATION DATA. DRIVER STARTED *************************************")
        # --- ADDED: Set timeouts to prevent the application from hanging ---
        driver.set_page_load_timeout(20) # Max time to wait for a page to load
        driver.implicitly_wait(10)       # Max time to wait for an element to appear
        # --- END OF ADDITION ---

        # --- Loop Through Stations and Scrape ---
        for station_code in list_of_station_codes:
            temp = "N/A"
            wind = "N/A"
            
            try:
                #print(f"  -> Scraping: {station_code}")
                station_url = (
                    "https://www.weather.gov/wrh/timeseries?"
                    f"site={station_code}&hours=6&units=english&chart=off"
                    "&headers=none&obs=tabular&hourly=false&pview=standard&font=12"
                )
                driver.get(station_url)

                table = driver.find_element(By.ID, "OBS_DATA")
                headers = table.find_elements(By.CSS_SELECTOR, "thead tr#HEADER th")
                col_indices = {h.get_attribute("id"): i for i, h in enumerate(headers)}
                
                idx_temp = col_indices.get("temperature")
                idx_winddir = col_indices.get("wind_dir")
                idx_wind = col_indices.get("wind_speedgust")

                first_valid_row_tds = None
                rows = table.find_elements(By.CSS_SELECTOR, "tbody tr")
                for r in rows[:3]:
                    tds = r.find_elements(By.TAG_NAME, "td")
                    if idx_temp is not None and len(tds) > idx_temp and tds[idx_temp].text.strip():
                        first_valid_row_tds = tds
                        break
                
                if first_valid_row_tds:
                    tds = first_valid_row_tds
                    if idx_temp is not None:
                        temp_text = tds[idx_temp].text.strip()
                        if temp_text: temp = temp_text + chr(176)

                    if idx_winddir is not None and idx_wind is not None:
                        direction_text = tds[idx_winddir].text.strip()
                        wind_cell_text = tds[idx_wind].text.strip()
                        if direction_text and wind_cell_text:
                            wind_parts = [direction_text]
                            if "G" in wind_cell_text:
                                speed_part, gust_part = wind_cell_text.split("G", 1)
                                wind_parts.extend([f"at {speed_part} mph", f"G{gust_part}"])
                            else:
                                wind_parts.append(f"at {wind_cell_text} mph")
                            wind = " ".join(wind_parts)
                
                results[station_code] = (temp, wind)
                #print(f"  -> Success for {station_code}: Temp={temp}, Wind='{wind}'")

            except Exception as e:
                print(f"  -> FAILED to scrape {station_code}: {e}")
                continue

    except Exception as e:
        print(f"A critical error occurred with the browser instance: {e}")
        return results

    finally:
        if driver:
            driver.quit()

    return results


def get_buoy_data(list_of_buoy_codes, is_async_call=False):
    """
    (Synchronous) Fetches and processes recent buoy data for a list of buoy codes.
    This is a blocking function, intended only for the program's initial startup.

    Args:
        list_of_buoy_codes (list): A list of buoy ID strings to fetch.
        is_async_call (bool): A flag to suppress logging when called from the async wrapper.
    """
    if not list_of_buoy_codes:
        return {}

    # This print statement will now ONLY run on the very first, direct synchronous call.
    if not is_async_call:
        print(f"--- Running SYNCHRONOUS buoy data fetch for: {list_of_buoy_codes} ---")
    
    results = {}

    def _parse_line(text_block, search_key):
        for line in text_block.strip().split('<br />'):
            if search_key in line:
                value_part = line.split(search_key)[1]
                return value_part.replace('</strong>', '').strip()
        return None

    for buoy_code in list_of_buoy_codes:
        temp, wtemp, wind = "Air Temp: N/A", "Water Temp: N/A", "Wind: N/A"
        rss_url = f"https://www.ndbc.noaa.gov/data/latest_obs/{buoy_code.lower()}.rss"
        try:
            response = requests.get(rss_url, timeout=15)
            response.raise_for_status()
            root = ElementTree.fromstring(response.content)
            description_element = root.find('.//channel/item/description')
            if description_element is None or not description_element.text:
                results[buoy_code] = (temp, wtemp, wind)
                continue
            
            description_text = description_element.text
            air_temp_raw = _parse_line(description_text, "Air Temperature:")
            if air_temp_raw:
                air_temp_val = air_temp_raw.split('&#176;F')[0]
                try: temp = f"Air Temp: {round(float(air_temp_val))}°"
                except (ValueError, TypeError): pass
            
            water_temp_raw = _parse_line(description_text, "Water Temperature:")
            if water_temp_raw:
                water_temp_val = water_temp_raw.split('&#176;F')[0]
                try: wtemp = f"Water Temp: {round(float(water_temp_val))}°"
                except (ValueError, TypeError): pass

            wind_dir_raw = _parse_line(description_text, "Wind Direction:")
            wind_speed_raw = _parse_line(description_text, "Wind Speed:")
            wind_gust_raw = _parse_line(description_text, "Wind Gust:")
            wd_cardinal, ws_mph, wg_mph = "Var.", None, None
            if wind_dir_raw: wd_cardinal = wind_dir_raw.split()[0]
            if wind_speed_raw:
                try:
                    speed_knots = float(wind_speed_raw.split()[0])
                    ws_mph = round(speed_knots * 1.15078)
                except (ValueError, TypeError, IndexError): pass
            if wind_gust_raw:
                try:
                    gust_knots = float(wind_gust_raw.split()[0])
                    wg_mph = round(gust_knots * 1.15078)
                except (ValueError, TypeError, IndexError): pass
            if ws_mph is not None:
                wind_parts = [wd_cardinal, f"at {ws_mph} mph"]
                if wg_mph is not None and wg_mph > 0:
                    wind_parts.append(f"G{wg_mph}")
                wind = " ".join(wind_parts)
            
            results[buoy_code] = (temp, wtemp, wind)

        except Exception as e:
            print(f"An error occurred in get_buoy_data for {buoy_code}: {e}")
            results[buoy_code] = (temp, wtemp, wind)
    
    return results

async def get_buoy_data_async(list_of_buoy_codes, loop, obs_data_queue):
    """
    (Thread-Safe) Fetches buoy data in the background and puts the
    results into a thread-safe queue for the main GUI thread to process.
    """
    if not list_of_buoy_codes:
        return
    
    print(f"--- Background task started: Fetching {len(list_of_buoy_codes)} buoy(s) ---")

    def blocking_fetcher():
        # This function now calls the synchronous version with a flag
        # to prevent it from printing the confusing log message.
        return get_buoy_data(list_of_buoy_codes, is_async_call=True)

    # Run the blocking fetcher in the background
    result_dict = await loop.run_in_executor(None, blocking_fetcher)

    # Instead of returning the result, put it into the thread-safe queue
    if result_dict:
        obs_data_queue.put(result_dict)

#@profile

# Code begins for nws lcl radar loop

def calc_reg_sat_padding(reg_sat_reg):
    if reg_sat_reg == 'taw':
        return (45, 12)
    elif reg_sat_reg == 'can':
        return (15, 52)
    else:
        return (150, 12)

# Function to fetch and process satellite frames
def fetch_and_process_reg_sat_loop():
    def threaded_fetch_and_process():
        global reg_sat_frames, last_reg_sat_update, reg_sat_reg, reg_sat_goes
        global available_image_dictionary, reg_sat_updated_flag

        current_time = datetime.now()
        base_url = "https://cdn.star.nesdis.noaa.gov/GOES{}/ABI/SECTOR/{}/GEOCOLOR/"
        num_images_to_scrape = 12

        try:
            # --- added: mirror LCL pattern; teardown old data at fetch start ---
            if 'full_reg_sat_teardown' in globals():
                full_reg_sat_teardown()
            reg_sat_updated_flag = False
            # --- end added ---

            # Get settings for the satellite and region
            reg_sat_goes, reg_sat_reg = get_reg_sat_settings()

            # Generate URLs to scrape
            urls_to_scrape = generate_reg_sat_urls(
                base_url.format(reg_sat_goes, reg_sat_reg),
                num_images_to_scrape,
                reg_sat_goes,
                reg_sat_reg
            )

            # Scrape and process images
            new_frames = scrape_and_store_reg_sat_images(urls_to_scrape, reg_sat_goes, reg_sat_reg)
            
            # Update the global frames only if new frames are successfully fetched
            if new_frames:
                reg_sat_frames = new_frames
                last_reg_sat_update = current_time

                if not callable(calc_reg_sat_padding):
                    print("[FATAL] 'calc_reg_sat_padding' was overwritten:", type(calc_reg_sat_padding))
                    return

                pad_x, pad_y = calc_reg_sat_padding(reg_sat_reg)
                available_image_dictionary['reg_sat_loop_img'] = [(frame, pad_x, pad_y) for frame in reg_sat_frames]
                reg_sat_updated_flag = True
            else:
                print("[DEBUG] line 8859. No new frames fetched. Keeping existing reg_sat_frames.")

        except Exception as e:
            print(f"[ERROR] Exception in fetch_and_process_reg_sat_loop: {e}")

    # Start the scraping process in a thread to keep the GUI responsive
    threading.Thread(target=threaded_fetch_and_process, daemon=True).start()
    
# Function to scrape and store frames in memory
def scrape_and_store_reg_sat_images(urls, reg_sat_goes, reg_sat_reg):
    frames = []

    try:
        # First, check if the paths were set at startup.
        if not (CHROMIUM_BIN and CHROME_DRIVER_PATH):
            print("ERROR: Chromium/ChromeDriver path not set. Cannot start browser.")
            return

        # Define your options for this specific function
        options = Options()
        options.binary_location = CHROMIUM_BIN
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        # Add any other specific options you need for this function...

        # Point to the driver path determined at startup
        service = Service(CHROME_DRIVER_PATH)

        # Initialize the driver with both objects
        driver = webdriver.Chrome(service=service, options=options)

    except Exception as e:
        print(f"Failed to initialize the driver in reg sat: {e}")
        return frames

    try:
        for url in reversed(urls):
            try:
                driver.get(url)
                if "404 Not Found" in driver.title:
                    print(f"No image found for URL in reg sat: {url}")
                    continue

                # Capture screenshot and process the image
                screenshot = driver.get_screenshot_as_png()
                screenshot = Image.open(BytesIO(screenshot))
                screenshot = trim_near_black_borders_reg_sat(screenshot)

                # Resize the image based on the region
                if reg_sat_reg == 'taw':
                    target_size = (858, 515)
                elif reg_sat_reg == 'can':
                    target_size = (900, 448)
                else:
                    target_size = (515, 515)

                screenshot = screenshot.resize(target_size, Image.LANCZOS)
                frames.append(screenshot)  # keep as PIL.Image
                # do NOT close here; we’re keeping the image for playback

            except Exception as e:
                print(f"Error processing image from URL {url} in reg sat: {e}")

    finally:
        driver.quit()

    #print(f"[DEBUG] Total frames scraped: {len(frames)}")
    return frames

# Function to trim black borders from an image
def trim_near_black_borders_reg_sat(img, threshold=30):
    try:
        grayscale_img = img.convert("L")
        binary_img = grayscale_img.point(lambda p: 255 if p > threshold else 0, '1')
        bbox = binary_img.getbbox()
        if bbox:
            return img.crop(bbox)
    except Exception as e:
        print(f"Error cropping the image in reg sat: {e}")
    return img

# Function to generate URLs for scraping
def generate_reg_sat_urls(base_url, num_images, reg_sat_goes, reg_sat_reg):
    urls = []
    current_time_utc = datetime.utcnow()

    for _ in range(num_images):
        if reg_sat_choice_variables[10] == 1 or reg_sat_choice_variables[11] == 1:
            time_offset = 20
            time_format = "%H%M"
            image_suffix = "500x500.jpg"
            valid_minutes = {0}
        elif reg_sat_choice_variables[7] == 1 or reg_sat_choice_variables[14] == 1:
            time_offset = 10
            time_format = "%H%M"
            image_suffix = "500x500.jpg"
            valid_minutes = {6}
        elif reg_sat_choice_variables[15] == 1:
            time_offset = 20
            time_format = "%H%M"
            image_suffix = "900x540.jpg"
            valid_minutes = {0}
        elif reg_sat_choice_variables[3] == 1:
            time_offset = 30
            time_format = "%H%M"
            image_suffix = "1125x560.jpg"
            valid_minutes = {0}
        else:
            time_offset = 10
            time_format = "%H%M"
            image_suffix = "600x600.jpg"
            valid_minutes = {6}

        current_time_utc -= timedelta(minutes=time_offset)
        while current_time_utc.minute % 10 not in valid_minutes:
            current_time_utc -= timedelta(minutes=1)

        year = current_time_utc.year
        day_of_year = current_time_utc.timetuple().tm_yday
        time_code = current_time_utc.strftime(time_format)

        url = f"{base_url}{year}{day_of_year:03d}{time_code}_GOES{reg_sat_goes}-ABI-{reg_sat_reg}-GEOCOLOR-{image_suffix}"
        urls.append(url)
        current_time_utc -= timedelta(minutes=5)

    return urls

# Function to determine satellite and region settings
def get_reg_sat_settings():
    selected_index = reg_sat_choice_variables.index(1)
    global reg_sat_goes, reg_sat_reg
    reg_sat_goes = 19  # Default value
    reg_sat_reg = 'unknown'  # Default value

    region_settings = [
        (18, 'pnw'), (19, 'umv'), (19, 'ne'), (19, 'can'),
        (18, 'psw'), (19, 'smv'), (19, 'se'), (19, 'ga'),
        (19, 'nr'), (19, 'cgl'), (18, 'wus'), (19, 'car'),
        (19, 'sr'), (19, 'sp'), (19, 'eus'), (19, 'taw')
    ]

    if 0 <= selected_index < len(region_settings):
        reg_sat_goes, reg_sat_reg = region_settings[selected_index]

    return reg_sat_goes, reg_sat_reg

# # Start with the national radar frame
current_frame_index = 0
timer_override = False

root.after(2500, preload_ui_thumbnail_caches)

# Start the tkinter main loop
root.mainloop()
