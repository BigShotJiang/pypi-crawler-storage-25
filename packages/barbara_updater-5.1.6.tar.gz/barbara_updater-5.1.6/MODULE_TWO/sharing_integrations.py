import os
import html
import socket
import threading
import uuid
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import random
import shutil
import smtplib
import subprocess
import time

import requests
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from PIL import Image
from urllib.parse import quote_plus


def _run_screenshot_command(label, command):
    print(f"Trying to use {label} for taking a screenshot.")
    try:
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode == 0:
            print(f"{label} successfully took the screenshot.")
            return True
        print(f"{label} failed with error")
    except Exception:
        print(f"Error while using {label}")
    return False


def send_screenshot_email(to_email, screenshot_filename, from_email, password):
    if not to_email:
        print("No email address provided.")
        return False

    subject = "Weather Observer Screenshot - Do Not Reply"
    body = "Attached is the screenshot from the Weather Observer."

    msg = MIMEMultipart()
    msg["From"] = from_email
    msg["To"] = to_email
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    with open(screenshot_filename, "rb") as attachment:
        img = MIMEImage(attachment.read(), name=screenshot_filename)
        msg.attach(img)

    server = smtplib.SMTP_SSL("smtp.gmail.com", 465)
    server.login(from_email, password)
    server.send_message(msg)
    server.quit()
    return True


def capture_screenshot(screenshot_filename):
    screenshot_commands = []
    if shutil.which("grim"):
        screenshot_commands.append(("grim", ["grim", screenshot_filename]))
    if shutil.which("scrot"):
        screenshot_commands.append(("scrot", ["scrot", screenshot_filename, "--overwrite"]))

    for label, command in screenshot_commands:
        if _run_screenshot_command(label, command):
            return True

    print("Failed to take screenshot with both grim and scrot.")
    raise RuntimeError("Failed to take screenshot.")


def validate_screenshot_file(screenshot_filename, is_black_image):
    if not os.path.exists(screenshot_filename):
        print("Screenshot file does not exist.")
        raise RuntimeError("Screenshot file does not exist.")

    if is_black_image(screenshot_filename):
        print("Screenshot file is black.")
        raise RuntimeError("Screenshot file is black.")

    try:
        image = Image.open(screenshot_filename)
        image.verify()
        print("Screenshot file is valid.")
    except Exception:
        print("Screenshot file is invalid")
        raise RuntimeError("Screenshot file is invalid.")


def post_to_facebook(caption, image_path, page_id, page_access_token, messagebox_module):
    url = f"https://graph.facebook.com/v18.0/{page_id}/photos"

    if not os.path.exists(image_path):
        messagebox_module.showerror("Error", f"Image not found at {image_path}")
        return False

    with open(image_path, "rb") as image_file:
        response = requests.post(
            url,
            data={
                "caption": caption,
                "access_token": page_access_token,
            },
            files={
                "source": image_file,
            },
        )

    if response.status_code == 200:
        messagebox_module.showinfo("Success", "Image posted to Facebook!")
        return True

    messagebox_module.showerror("Failed", f"FB post failed. Code: {response.status_code}\n{response.text}")
    return False


def _ig_is_fetch_ready(url, timeout=6):
    try:
        head_response = requests.head(url, timeout=timeout, allow_redirects=True)
        if head_response.status_code != 200:
            return False, f"HEAD {head_response.status_code}"
        content_type = head_response.headers.get("Content-Type", "").lower()
        content_length = int(head_response.headers.get("Content-Length", "0") or "0")
        if "image/" not in content_type or content_length < 2048:
            return False, f"ct={content_type} cl={content_length}"
        range_response = requests.get(url, headers={"Range": "bytes=0-31"}, timeout=timeout)
        content = range_response.content or b""
        if content.startswith(b"\xff\xd8\xff") or content.startswith(b"\x89PNG\r\n\x1a\n"):
            return True, f"ct={content_type} cl={content_length}"
        return False, "magic-bytes-missing"
    except Exception as e:
        return False, f"exc:{e}"


def _ig_try_container(url, caption, ig_user_id, access_token, tries=3):
    base_create_url = f"https://graph.instagram.com/{ig_user_id}/media"
    for attempt in range(1, tries + 1):
        bust = int(time.time() * 1000) + random.randint(0, 999)
        attempt_url = f"{url}{'&' if '?' in url else '?'}cb={bust}"

        ok, why = _ig_is_fetch_ready(attempt_url)
        print(f"[IG-GATE] attempt {attempt}: {why} url={attempt_url}")
        if not ok:
            time.sleep(0.8 * attempt)
            continue

        payload = {
            "image_url": attempt_url,
            "caption": caption,
            "access_token": access_token,
        }
        try:
            response = requests.post(base_create_url, data=payload, timeout=20)
            data = response.json()
        except Exception as e:
            print(f"[IG-CONTAINER] exception on attempt {attempt}: {e}")
            time.sleep(1.2 * attempt)
            continue

        print(f"[IG-CONTAINER] response (attempt {attempt}):", data)

        if isinstance(data, dict) and "id" in data:
            return True, data["id"]

        error = (data or {}).get("error", {})
        if error.get("code") == 9004:
            time.sleep(1.2 * attempt)
            continue

        return False, data

    return False, {"error": {"message": "exhausted container retries"}}


def post_to_instagram(
    caption,
    source_path,
    image_path,
    server_upload_url,
    api_secret_token,
    ig_user_id,
    access_token,
    messagebox_module,
):
    img = Image.open(source_path).convert("RGB")
    img.save(image_path, format="JPEG", quality=90, optimize=True)

    with open(image_path, "rb") as image_file:
        print("First 16 bytes:", image_file.read(16))

    print(f"Uploading screenshot to {server_upload_url}...")
    try:
        with open(image_path, "rb") as img_file:
            files_payload = {
                "uploaded_file": ("screenshot.jpg", img_file, "image/jpeg"),
            }
            data_payload = {"api_secret": api_secret_token}

            response = requests.post(server_upload_url, files=files_payload, data=data_payload)

        if response.status_code == 200:
            image_url = response.text.strip()
            print(f"Upload successful. Server returned URL: {image_url}")

            if not image_url.startswith(("http://", "https://")) or not image_url.lower().endswith((".png", ".jpg", ".jpeg", ".gif")):
                print(f"ERROR: Server returned an invalid or non-image URL: {image_url}")
                messagebox_module.showerror("Upload Failed", f"Server returned an invalid URL: {image_url[:100]}...")
                return False

            print("Image hosted successfully on own server. Proceeding with Instagram post...")

            ok, result = _ig_try_container(image_url, caption, ig_user_id, access_token, tries=3)
            if not ok:
                print("IG container creation failed after retries:", result)
                messagebox_module.showerror("Upload Busy", "Unable to prepare image for sharing.")
                return False

            creation_id = result
            publish_url = f"https://graph.instagram.com/{ig_user_id}/media_publish"
            publish_payload = {"creation_id": creation_id, "access_token": access_token}
            print("Publishing to Instagram feed...")
            time.sleep(2.0)
            publish_response = requests.post(publish_url, data=publish_payload, timeout=20)
            print("Step 2 response:", publish_response.json())
            messagebox_module.showinfo("Success", "Image posted to Instagram!")
            return True

        print(f"Server upload failed. Status Code: {response.status_code}")
        print(f"Server error response: {response.text}")
        messagebox_module.showerror(
            "Upload Failed",
            f"Server returned status {response.status_code}.\nCheck Pi's console/logs.\nError: {response.text}",
        )
        return False

    except requests.exceptions.RequestException as e:
        print(f"Error connecting to server: {e}")
        messagebox_module.showerror("Upload Failed", f"Could not connect to server at {server_upload_url}.")
        return False
    except FileNotFoundError:
        print(f"Error: Screenshot file not found at {image_path}")
        messagebox_module.showerror("Upload Failed", f"Screenshot file not found: {image_path}")
        return False
    except Exception as e:
        print(f"An unexpected error occurred during server upload: {e}")
        messagebox_module.showerror("Upload Failed", "An unexpected error occurred during upload.")
        return False


LOCAL_PHONE_SHARE_ROOT = os.path.expanduser("~/weather_observer_phone_share")
_LOCAL_PHONE_SHARE_SERVER = None
_LOCAL_PHONE_SHARE_THREAD = None
_LOCAL_PHONE_SHARE_PORT = None
_LOCAL_PHONE_SHARE_LOCK = threading.Lock()


def _get_local_share_ip():
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("8.8.8.8", 80))
        ip_address = sock.getsockname()[0]
        sock.close()
        return ip_address
    except Exception:
        return "127.0.0.1"


def ensure_local_phone_share_server(preferred_port=8765):
    global _LOCAL_PHONE_SHARE_SERVER, _LOCAL_PHONE_SHARE_THREAD, _LOCAL_PHONE_SHARE_PORT
    with _LOCAL_PHONE_SHARE_LOCK:
        if _LOCAL_PHONE_SHARE_SERVER is not None:
            return _LOCAL_PHONE_SHARE_PORT

        os.makedirs(LOCAL_PHONE_SHARE_ROOT, exist_ok=True)
        handler_cls = partial(SimpleHTTPRequestHandler, directory=LOCAL_PHONE_SHARE_ROOT)

        for port in range(preferred_port, preferred_port + 10):
            try:
                server = ThreadingHTTPServer(("0.0.0.0", port), handler_cls)
                server.daemon_threads = True
                thread = threading.Thread(target=server.serve_forever, name="phone-share-server", daemon=True)
                thread.start()
                _LOCAL_PHONE_SHARE_SERVER = server
                _LOCAL_PHONE_SHARE_THREAD = thread
                _LOCAL_PHONE_SHARE_PORT = port
                print(f"[PHONE SHARE] Local share server started on port {port}.")
                return port
            except OSError:
                continue

    raise RuntimeError("Could not start local phone share server.")


def create_local_phone_share(screenshot_filename, caption_text):
    if not os.path.exists(screenshot_filename):
        raise RuntimeError(f"Screenshot file not found: {screenshot_filename}")

    port = ensure_local_phone_share_server()
    share_token = uuid.uuid4().hex[:10]
    share_dir = os.path.join(LOCAL_PHONE_SHARE_ROOT, share_token)
    os.makedirs(share_dir, exist_ok=True)

    image_filename = "image.png"
    image_path = os.path.join(share_dir, image_filename)
    shutil.copy2(screenshot_filename, image_path)

    safe_caption = html.escape(caption_text or "")
    html_body = """<!doctype html>
<html lang=\"en\">
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
  <title>The Weather Observer Share</title>
  <style>
    body {{ font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #eef5fb; color: #111; }}
    .card {{ max-width: 820px; margin: 0 auto; background: #fff; border-radius: 14px; padding: 18px; box-shadow: 0 6px 22px rgba(0,0,0,.12); }}
    h1 {{ margin-top: 0; font-size: 28px; }}
    img {{ width: 100%; height: auto; border: 1px solid #c7d4df; border-radius: 10px; }}
    .caption {{ white-space: pre-wrap; background: #f6f9fc; border: 1px solid #d6e0e8; border-radius: 10px; padding: 12px; margin-top: 16px; }}
    .row {{ display: flex; gap: 12px; flex-wrap: wrap; margin-top: 14px; }}
    a.button, button {{ background: #2d6f9f; color: #fff; border: 0; border-radius: 10px; padding: 12px 16px; font-size: 16px; text-decoration: none; cursor: pointer; }}
    .muted {{ color: #444; margin-top: 10px; }}
  </style>
</head>
<body>
  <div class=\"card\">
    <h1>The Weather Observer</h1>
    <p class=\"muted\">Save the image, copy the caption, then post it in your app of choice.</p>
    <img src=\"{image_filename}\" alt=\"Weather Observer share image\">
    <div class=\"row\">
      <a class=\"button\" href=\"{image_filename}\" download>Download Image</a>
      <button onclick=\"navigator.clipboard.writeText(document.getElementById('caption').innerText)\">Copy Caption</button>
    </div>
    <div id=\"caption\" class=\"caption\">{safe_caption}</div>
  </div>
</body>
</html>
""".format(image_filename=image_filename, safe_caption=safe_caption)
    with open(os.path.join(share_dir, 'index.html'), 'w', encoding='utf-8') as handle:
        handle.write(html_body)

    ip_address = _get_local_share_ip()
    share_url = f"http://{ip_address}:{port}/{share_token}/"
    return share_url



def create_server_phone_share(
    caption,
    source_path,
    image_path,
    server_upload_url,
    api_secret_token,
    viewer_base_url,
):
    img = Image.open(source_path).convert("RGB")
    img.save(image_path, format="JPEG", quality=90, optimize=True)

    with open(image_path, "rb") as img_file:
        files_payload = {
            "uploaded_file": ("screenshot.jpg", img_file, "image/jpeg"),
        }
        data_payload = {"api_secret": api_secret_token}
        response = requests.post(server_upload_url, files=files_payload, data=data_payload, timeout=30)

    if response.status_code != 200:
        raise RuntimeError(f"Server upload failed: {response.status_code} {response.text}")

    image_url = response.text.strip()
    if not image_url.startswith(("http://", "https://")):
        raise RuntimeError(f"Server returned invalid URL: {image_url}")

    encoded_image = quote_plus(image_url)
    encoded_caption = quote_plus(caption or "")
    return f"{viewer_base_url}?img={encoded_image}&caption={encoded_caption}"
