def set_widget_keyboard_mode(widget, mode, **options):
    setattr(widget, "_keyboard_mode", mode)
    setattr(widget, "_keyboard_mode_options", dict(options))


def _get_widget_mode(widget, globals_dict, tk_module):
    if widget is None:
        return "text", {}

    mode = getattr(widget, "_keyboard_mode", None)
    options = getattr(widget, "_keyboard_mode_options", {}) or {}

    if mode:
        return mode, options

    state_entry_widgets = globals_dict.get("state_entry_widgets", {})
    if widget in state_entry_widgets.values():
        return "state", {}

    if globals_dict.get("is_buoy_code"):
        return "buoy", {}

    if isinstance(widget, tk_module.Text):
        return "message", {}

    return "text", {}


def _get_widget_text(widget, tk_module):
    if widget is None:
        return ""
    try:
        if not widget.winfo_exists():
            return ""
    except Exception:
        return ""
    if isinstance(widget, tk_module.Text):
        try:
            return widget.get("1.0", "end-1c")
        except Exception:
            return ""
    try:
        return widget.get()
    except Exception:
        return ""


def _resolve_printable_key_output(key_value, mode, options, shift_active, caps_lock_active, shifted_keys):
    effective_upper = caps_lock_active ^ shift_active

    if mode == "numeric":
        allowed_chars = options.get("allowed_chars", "0123456789.")
        return key_value if key_value in allowed_chars else None

    if mode == "buoy":
        return key_value.upper() if key_value.isalnum() else None

    if mode == "state":
        return key_value.upper() if key_value.isalpha() else None

    if key_value in shifted_keys:
        return shifted_keys[key_value] if shift_active else key_value

    if key_value.isalpha():
        return key_value.upper() if effective_upper else key_value.lower()

    return key_value


def _should_capitalize_town(content):
    if not content:
        return True
    return content.endswith((" ", "-", "'", "(", "/"))


def _should_capitalize_message(content):
    if not content:
        return True
    return content.endswith((". ", "!\u0020", "?\u0020", ".\n", "!\n", "?\n"))


def set_state_uppercase(globals_dict, update_keyboard_shift_state_fn):
    globals_dict["shift_active"] = True
    update_keyboard_shift_state_fn()


def auto_capitalize(globals_dict, tk_module, update_keyboard_shift_state_fn):
    current_target_entry = globals_dict["current_target_entry"]
    mode, _options = _get_widget_mode(current_target_entry, globals_dict, tk_module)
    content = _get_widget_text(current_target_entry, tk_module)
    caps_lock_active = globals_dict.get("caps_lock_active", False)

    if mode in {"state", "buoy"}:
        globals_dict["shift_active"] = True
    elif mode in {"numeric", "email"}:
        globals_dict["shift_active"] = False
    elif caps_lock_active:
        globals_dict["shift_active"] = False
    elif mode == "town":
        globals_dict["shift_active"] = _should_capitalize_town(content)
    elif mode == "message":
        globals_dict["shift_active"] = _should_capitalize_message(content)
    else:
        globals_dict["shift_active"] = not content

    update_keyboard_shift_state_fn()


def set_keyboard_target(widget, globals_dict, tk_module, auto_capitalize_fn, update_keyboard_shift_state_fn):
    try:
        if not widget.winfo_exists():
            return
    except tk_module.TclError:
        print(f"set_keyboard_target: Widget {widget} no longer exists.")
        return

    globals_dict["current_target_entry"] = widget
    auto_capitalize_fn()
    update_keyboard_shift_state_fn()


def set_current_target(entry_widget, globals_dict):
    globals_dict["current_target_entry"] = entry_widget


def key_pressed(key_value, globals_dict, tk_module, auto_capitalize_fn, update_keyboard_shift_state_fn):
    current_target_entry = globals_dict["current_target_entry"]
    shifted_keys = globals_dict["shifted_keys"]

    if not current_target_entry:
        return

    mode, options = _get_widget_mode(current_target_entry, globals_dict, tk_module)

    if key_value == "Backspace":
        if isinstance(current_target_entry, tk_module.Text):
            current_target_entry.delete("insert -1 chars", "insert")
        elif isinstance(current_target_entry, tk_module.Entry):
            current_pos = current_target_entry.index(tk_module.INSERT)
            if current_pos > 0:
                current_target_entry.delete(current_pos - 1, current_pos)
        auto_capitalize_fn()
        update_keyboard_shift_state_fn()
        return

    if key_value == "Clear":
        if isinstance(current_target_entry, tk_module.Text):
            current_target_entry.delete("1.0", "end")
        elif isinstance(current_target_entry, tk_module.Entry):
            current_target_entry.delete(0, tk_module.END)
        auto_capitalize_fn()
        update_keyboard_shift_state_fn()
        return

    if key_value == "Space":
        if mode not in {"state", "buoy", "numeric"}:
            current_target_entry.insert("insert", " ")
        auto_capitalize_fn()
        update_keyboard_shift_state_fn()
        return

    if key_value == "Tab":
        current_target_entry.tk_focusNext().focus_set()
        return

    if key_value == "Shift":
        if mode not in {"state", "buoy", "numeric"}:
            globals_dict["shift_active"] = not globals_dict["shift_active"]
        else:
            globals_dict["shift_active"] = True if mode in {"state", "buoy"} else False
        update_keyboard_shift_state_fn()
        return

    if key_value == "Caps":
        if mode not in {"state", "buoy", "numeric"}:
            globals_dict["caps_lock_active"] = not globals_dict.get("caps_lock_active", False)
            globals_dict["shift_active"] = False
        else:
            globals_dict["caps_lock_active"] = False
            globals_dict["shift_active"] = True if mode in {"state", "buoy"} else False
        update_keyboard_shift_state_fn()
        return

    if key_value == "@gmail.com":
        current_target_entry.insert("insert", "@gmail.com")
        auto_capitalize_fn()
        update_keyboard_shift_state_fn()
        return

    actual_value = _resolve_printable_key_output(
        key_value,
        mode,
        options,
        globals_dict["shift_active"],
        globals_dict.get("caps_lock_active", False),
        shifted_keys,
    )

    if actual_value:
        current_target_entry.insert("insert", actual_value)

    auto_capitalize_fn()
    update_keyboard_shift_state_fn()


def update_keyboard_shift_state(globals_dict, tk_module):
    shift_active = globals_dict["shift_active"]
    caps_lock_active = globals_dict.get("caps_lock_active", False)
    keyboard_buttons = globals_dict["keyboard_buttons"]
    shifted_keys = globals_dict["shifted_keys"]
    current_target_entry = globals_dict["current_target_entry"]

    mode, _options = _get_widget_mode(current_target_entry, globals_dict, tk_module)

    dead_keys = []

    for key, button in keyboard_buttons.items():
        try:
            if not button.winfo_exists():
                dead_keys.append(key)
                continue
        except Exception:
            dead_keys.append(key)
            continue

        if key == "Caps":
            try:
                if mode in {"state", "buoy", "numeric"}:
                    button.config(relief=tk_module.RAISED)
                else:
                    button.config(relief=tk_module.SUNKEN if caps_lock_active else tk_module.RAISED)
            except Exception:
                dead_keys.append(key)
            continue

        if key == "Shift":
            if mode in {"state", "buoy", "numeric"}:
                try:
                    button.config(relief=tk_module.RAISED)
                except Exception:
                    dead_keys.append(key)
            else:
                try:
                    button.config(relief=tk_module.SUNKEN if shift_active else tk_module.RAISED)
                except Exception:
                    dead_keys.append(key)
            continue

        if key == "Space" or key == "Backspace" or key == "Tab" or key == "@gmail.com" or key == "Clear":
            continue

        printable_text = _resolve_printable_key_output(
            key,
            mode,
            _options,
            shift_active,
            caps_lock_active,
            shifted_keys,
        )

        if printable_text is None:
            printable_text = key

        try:
            button.config(text=printable_text)
        except Exception:
            dead_keys.append(key)

    for key in dead_keys:
        keyboard_buttons.pop(key, None)
