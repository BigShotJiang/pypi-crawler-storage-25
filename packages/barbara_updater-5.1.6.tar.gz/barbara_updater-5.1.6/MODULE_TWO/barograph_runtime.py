import json
import os
import time
from matplotlib.lines import Line2D


def _barograph_pressure_pascals_to_inhg(value):
    if value is None:
        return None
    try:
        return float(value) * 0.00029529980164712
    except (TypeError, ValueError):
        return None


def _normalize_remote_header(value):
    return "".join(ch.lower() for ch in str(value or "") if ch.isalnum())


def _find_remote_pressure_columns_from_headers(headers):
    altimeter_idx = None
    datetime_idx = None
    date_idx = None
    time_idx = None

    normalized_headers = [_normalize_remote_header(header) for header in headers]

    for idx, normalized in enumerate(normalized_headers):
        if altimeter_idx is None and (
            "altimetersetting" in normalized
            or normalized == "altimeter"
            or normalized.startswith("alti")
            or normalized == "alstg"
        ):
            altimeter_idx = idx
        if datetime_idx is None and (
            "observationtime" in normalized
            or normalized == "time"
            or normalized.startswith("time")
            or normalized.startswith("valid")
            or normalized == "datetime"
            or normalized.startswith("datetime")
            or normalized.startswith("datetime")
            or normalized.startswith("date")
        ):
            datetime_idx = idx
        if date_idx is None and normalized == "date":
            date_idx = idx
        if time_idx is None and (normalized == "time" or normalized.startswith("time")):
            time_idx = idx

    return altimeter_idx, datetime_idx, date_idx, time_idx


def fetch_remote_barograph_series(
    station_id="KMIA",
    hours=60,
    chrome_driver_path=None,
    options_cls=None,
    service_cls=None,
    webdriver_module=None,
    by_module=None,
):
    from datetime import datetime, timedelta
    from zoneinfo import ZoneInfo

    import requests
    from dateutil import parser

    timeseries_url = (
        f"https://www.weather.gov/wrh/timeseries?site={station_id}&hours={hours}"
        "&units=english&chart=off&headers=none&obs=tabular&hourly=false&pview=standard&font=12"
    )
    history_points = []
    inspected_columns = []
    driver = None
    local_plot_timezone = datetime.now().astimezone().tzinfo
    station_timezone = None

    station_metadata_url = f"https://api.weather.gov/stations/{station_id}"
    station_metadata_response = requests.get(
        station_metadata_url,
        timeout=15,
        headers={
            "User-Agent": "The Weather Observer barograph overlay",
            "Accept": "application/geo+json, application/json",
        },
    )
    station_metadata_response.raise_for_status()
    station_properties = station_metadata_response.json().get("properties", {})
    station_timezone_name = (
        station_properties.get("timeZone")
        or station_properties.get("timezone")
        or ""
    )
    if station_timezone_name:
        try:
            station_timezone = ZoneInfo(station_timezone_name)
        except Exception:
            station_timezone = None

    try:
        if not chrome_driver_path or not options_cls or not service_cls or not webdriver_module or not by_module:
            raise ValueError("ChromeDriver configuration is missing for remote barograph overlay.")

        options = options_cls()
        options.add_argument("--headless")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        service = service_cls(chrome_driver_path)
        driver = webdriver_module.Chrome(service=service, options=options)
        driver.set_page_load_timeout(25)
        driver.implicitly_wait(6)
        driver.get(timeseries_url)

        table = driver.find_element(by_module.ID, "OBS_DATA")
        headers = table.find_elements(by_module.CSS_SELECTOR, "thead tr#HEADER th")
        header_ids = [header.get_attribute("id") or header.text for header in headers]
        inspected_columns = header_ids

        altimeter_idx, datetime_idx, date_idx, time_idx = _find_remote_pressure_columns_from_headers(header_ids)

        if altimeter_idx is None:
            raise ValueError(f"Could not identify altimeter column for {station_id}. Columns seen: {inspected_columns}")

        rows = table.find_elements(by_module.CSS_SELECTOR, "tbody tr")
        for row in rows:
            cells = row.find_elements(by_module.CSS_SELECTOR, "td")
            cell_values = [cell.text.strip() for cell in cells]
            if altimeter_idx >= len(cell_values):
                continue

            raw_altimeter = cell_values[altimeter_idx]
            try:
                altimeter_inhg = float(raw_altimeter)
            except (TypeError, ValueError):
                continue

            if datetime_idx is not None and datetime_idx < len(cell_values):
                raw_datetime = str(cell_values[datetime_idx]).strip()
            elif date_idx is not None and time_idx is not None and date_idx < len(cell_values) and time_idx < len(cell_values):
                raw_datetime = f"{cell_values[date_idx]} {cell_values[time_idx]}".strip()
            else:
                raw_datetime = ""

            if not raw_datetime:
                continue

            try:
                parsed_time = parser.parse(raw_datetime)
            except Exception:
                continue

            try:
                if parsed_time.tzinfo is None and station_timezone is not None:
                    parsed_time = parsed_time.replace(tzinfo=station_timezone)
                if parsed_time.tzinfo is not None:
                    parsed_time = parsed_time.astimezone(local_plot_timezone).replace(tzinfo=None)
            except Exception:
                pass

            history_points.append((parsed_time, altimeter_inhg))
    finally:
        if driver is not None:
            try:
                driver.quit()
            except Exception:
                pass

    if not history_points:
        raise ValueError(f"Could not find altimeter history rows for {station_id}. Columns seen: {inspected_columns}")

    history_points.sort(key=lambda item: item[0])
    cutoff = datetime.now() - timedelta(hours=hours)
    trimmed_points = [(x_value, y_value) for x_value, y_value in history_points if x_value >= cutoff]

    latest_url = f"https://api.weather.gov/stations/{station_id}/observations/latest"
    latest_response = requests.get(
        latest_url,
        timeout=15,
        headers={
            "User-Agent": "The Weather Observer barograph overlay",
            "Accept": "application/geo+json, application/json",
        },
    )
    latest_response.raise_for_status()
    latest_payload = latest_response.json().get("properties", {})
    latest_pressure = _barograph_pressure_pascals_to_inhg(
        (latest_payload.get("seaLevelPressure") or {}).get("value")
    )
    latest_timestamp_raw = latest_payload.get("timestamp")

    if latest_pressure is not None and latest_timestamp_raw:
        latest_time = parser.parse(latest_timestamp_raw)
        if latest_time.tzinfo is not None:
            latest_time = latest_time.astimezone(local_plot_timezone).replace(tzinfo=None)

        if trimmed_points and abs((trimmed_points[-1][0] - latest_time).total_seconds()) <= 900:
            trimmed_points[-1] = (latest_time, latest_pressure)
        else:
            trimmed_points.append((latest_time, latest_pressure))

    # Defensively normalize the final series so the overlay can never plot
    # backward in time if one source returns an out-of-order timestamp.
    deduped_points = {}
    for point_time, point_pressure in trimmed_points:
        if point_time is None or point_pressure is None:
            continue
        deduped_points[point_time] = point_pressure

    trimmed_points = sorted(deduped_points.items(), key=lambda item: item[0])

    xs = [point[0] for point in trimmed_points]
    ys = [point[1] for point in trimmed_points]
    return xs, ys


def get_barograph_history_path(path=None):
    return path or os.path.expanduser("~/barograph_history.json")


def load_barograph_history(datetime_cls, path=None):
    history_path = get_barograph_history_path(path)
    xs = []
    ys = []

    try:
        if os.path.exists(history_path):
            with open(history_path, "r") as history_file:
                loaded_data = json.load(history_file)

            loaded_xs = loaded_data.get("xs", [])
            loaded_ys = loaded_data.get("ys", [])

            if isinstance(loaded_xs, list) and isinstance(loaded_ys, list):
                for x_value, y_value in zip(loaded_xs, loaded_ys):
                    try:
                        xs.append(datetime_cls.fromisoformat(x_value))
                        ys.append(y_value)
                    except Exception:
                        continue

                if xs:
                    print(f"Loaded {len(xs)} persisted barograph points.")
    except Exception as e:
        print(f"Error loading barograph history: {e}")

    return xs, ys


def save_barograph_history(xs, ys, path=None):
    history_path = get_barograph_history_path(path)
    data_to_save = {
        "xs": [x.isoformat() if hasattr(x, "isoformat") else str(x) for x in xs],
        "ys": ys,
    }

    try:
        with open(history_path, "w") as history_file:
            json.dump(data_to_save, history_file)
    except Exception as e:
        print(f"Error saving barograph history: {e}")


def read_barograph_sample(i, bus, baro_input, inhg_correction_factor):
    bus.write_byte(0x77, 0x44 | 0x00)
    time.sleep(0.5)

    data = bus.read_i2c_block_data(0x77, 0x10, 6)

    c_temp = (((data[0] & 0x0F) * 65536) + (data[1] * 256) + data[2]) / 100.00
    f_temp = (c_temp * 1.8) + 32
    pressure = (((data[3] & 0x0F) * 65536) + (data[4] * 256) + data[5]) / 100.00
    corrected_pressure = pressure * 1.0058
    in_hg = corrected_pressure * 0.029529

    if i == 0:
        inhg_correction_factor = baro_input / in_hg

    in_hg = round(in_hg * inhg_correction_factor, 3)
    return {
        "in_hg": in_hg,
        "f_temp": f_temp,
        "inhg_correction_factor": inhg_correction_factor,
    }


def build_barograph_time_context(
    now,
    pandas_module,
    datetime_cls,
    timedelta_cls,
    mdates_module,
):
    date_time = pandas_module.to_datetime(now.strftime("%m/%d/%Y, %H:%M:%S"))
    threshold_left_x_value = mdates_module.date2num(datetime_cls.now() - timedelta_cls(days=2.4))
    threshold_right_x_value = mdates_module.date2num(datetime_cls.now() - timedelta_cls(days=0.125))

    yesterday_name = (now - timedelta_cls(days=1)).strftime("%A")
    before_yesterday_name = (now - timedelta_cls(days=2)).strftime("%A")

    midnight = datetime_cls.combine(date_time.date(), datetime_cls.min.time())
    x_value_12pm = mdates_module.date2num(midnight.replace(hour=12))
    x_value_yesterday = x_value_12pm - 1
    x_value_day_before = x_value_12pm - 2

    return {
        "now": now,
        "date_time": date_time,
        "threshold_left_x_value": threshold_left_x_value,
        "threshold_right_x_value": threshold_right_x_value,
        "yesterday_name": yesterday_name,
        "before_yesterday_name": before_yesterday_name,
        "x_value_12pm": x_value_12pm,
        "x_value_yesterday": x_value_yesterday,
        "x_value_day_before": x_value_day_before,
        "y_value_day_label": 30.90,
    }


def append_barograph_point(xs, ys, date_time, in_hg, max_points=1200):
    xs.append(date_time)
    ys.append(in_hg)
    return xs[-max_points:], ys[-max_points:]


def reset_midnight_annotation_flags(time_context, state, ax=None):
    reset_date = state.get("last_midnight_reset_date")
    current_date = time_context["now"].date()

    if (
        0 <= time_context["now"].hour < 1
        and 0 <= time_context["now"].minute <= 15
        and reset_date != current_date
    ):
        for key in ("yesterday_annotation", "before_yesterday_annotation"):
            annotation = state.get(key)
            if annotation is not None:
                try:
                    annotation.remove()
                except Exception:
                    pass
                state[key] = None

        if ax is not None:
            for attr_name in (
                "_day_label_annotation",
                "_day_2900_annotation",
                "_day_3050_annotation",
                "_day_3000_annotation",
                "_day_2950_annotation",
                "_yesterday_2900_annotation",
                "_yesterday_3050_annotation",
                "_yesterday_3000_annotation",
                "_yesterday_2950_annotation",
                "_bday_2900_annotation",
                "_bday_3050_annotation",
                "_bday_3000_annotation",
                "_bday_2950_annotation",
            ):
                annotation = getattr(ax, attr_name, None)
                if annotation is not None:
                    try:
                        annotation.remove()
                    except Exception:
                        pass
                    setattr(ax, attr_name, None)

        state["today_annotation_flag"] = False
        state["today_inhg_annotation_flag"] = False
        state["annotations_created"]["before_yesterday"] = False
        state["annotations_created"]["bday_2900"] = False
        state["annotations_created"]["bday_3050"] = False
        state["annotations_created"]["bday_3000"] = False
        state["annotations_created"]["bday_2950"] = False
        state["last_midnight_reset_date"] = current_date
        time_context["yesterday_name"] = (time_context["date_time"] - state["timedelta_cls"](days=1)).strftime("%A")
        time_context["before_yesterday_name"] = (time_context["date_time"] - state["timedelta_cls"](days=2)).strftime("%A")


def replace_axis_annotation(ax, attr_name, *annotate_args, **annotate_kwargs):
    existing_annotation = getattr(ax, attr_name, None)
    if existing_annotation is not None:
        try:
            existing_annotation.remove()
        except Exception:
            pass

    new_annotation = ax.annotate(*annotate_args, **annotate_kwargs)
    setattr(ax, attr_name, new_annotation)
    return new_annotation


def update_barograph_annotations(ax, day_label, time_context, state):
    yesterday_annotation = state["yesterday_annotation"]
    before_yesterday_annotation = state["before_yesterday_annotation"]
    annotations_created = state["annotations_created"]
    today_annotation_flag = state["today_annotation_flag"]
    today_inhg_annotation_flag = state["today_inhg_annotation_flag"]

    day_label.set_text(time_context["date_time"].strftime("%A"))

    if time_context["x_value_12pm"] < time_context["threshold_right_x_value"] and not today_annotation_flag:
        replace_axis_annotation(
            ax,
            "_day_label_annotation",
            time_context["date_time"].strftime("%A"),
            (time_context["x_value_12pm"], time_context["y_value_day_label"]),
            ha="center",
            fontsize=10,
            fontstyle="italic",
            fontfamily="DejaVu Serif",
            fontweight="bold",
        )
        today_annotation_flag = True

    if time_context["x_value_12pm"] < time_context["threshold_right_x_value"] + 0.08 and not today_inhg_annotation_flag:
        replace_axis_annotation(ax, "_day_2900_annotation", "29.00", (time_context["x_value_12pm"] - 0.001, 28.975), ha="center", fontsize=10, fontfamily="DejaVu Serif")
        replace_axis_annotation(ax, "_day_3050_annotation", "30.50", (time_context["x_value_12pm"] - 0.001, 30.475), ha="center", fontsize=10, fontfamily="DejaVu Serif")
        replace_axis_annotation(ax, "_day_3000_annotation", "30.00", (time_context["x_value_12pm"] - 0.001, 29.975), ha="center", fontsize=10, fontfamily="DejaVu Serif")
        replace_axis_annotation(ax, "_day_2950_annotation", "29.50", (time_context["x_value_12pm"] - 0.001, 29.475), ha="center", fontsize=10, fontfamily="DejaVu Serif")
        today_inhg_annotation_flag = True

    if yesterday_annotation is None and time_context["x_value_yesterday"] < time_context["threshold_right_x_value"] + 0.2:
        yesterday_annotation = ax.annotate(
            time_context["yesterday_name"],
            xy=(time_context["x_value_yesterday"], time_context["y_value_day_label"]),
            xytext=(0, 0),
            textcoords="offset points",
            ha="center",
            fontsize=10,
            fontstyle="italic",
            fontfamily="DejaVu Serif",
            fontweight="bold",
            color="black",
        )
        replace_axis_annotation(ax, "_yesterday_2900_annotation", "29.00", (time_context["x_value_yesterday"] - 0.001, 28.975), ha="center", fontsize=10, fontfamily="DejaVu Serif")
        replace_axis_annotation(ax, "_yesterday_3050_annotation", "30.50", (time_context["x_value_yesterday"] - 0.001, 30.475), ha="center", fontsize=10, fontfamily="DejaVu Serif")
        replace_axis_annotation(ax, "_yesterday_3000_annotation", "30.00", (time_context["x_value_yesterday"] - 0.001, 29.975), ha="center", fontsize=10, fontfamily="DejaVu Serif")
        replace_axis_annotation(ax, "_yesterday_2950_annotation", "29.50", (time_context["x_value_yesterday"] - 0.001, 29.475), ha="center", fontsize=10, fontfamily="DejaVu Serif")

    if before_yesterday_annotation and time_context["x_value_day_before"] < time_context["threshold_left_x_value"]:
        before_yesterday_annotation.remove()
        before_yesterday_annotation = None
        annotations_created["before_yesterday"] = False

    if not annotations_created["before_yesterday"] and time_context["x_value_day_before"] > time_context["threshold_left_x_value"] + 0.044:
        if before_yesterday_annotation is None:
            before_yesterday_annotation = ax.annotate(
                time_context["before_yesterday_name"],
                xy=(time_context["x_value_day_before"], time_context["y_value_day_label"]),
                xytext=(0, 0),
                textcoords="offset points",
                ha="center",
                fontsize=10,
                fontstyle="italic",
                fontfamily="DejaVu Serif",
                fontweight="bold",
                color="black",
            )
            annotations_created["before_yesterday"] = True

    if time_context["x_value_day_before"] > time_context["threshold_left_x_value"] - 0.044:
        if not annotations_created["bday_2900"]:
            replace_axis_annotation(ax, "_bday_2900_annotation", "29.00", (time_context["x_value_day_before"] - 0.001, 28.975), ha="center", fontsize=10, fontfamily="DejaVu Serif")
            annotations_created["bday_2900"] = True
        if not annotations_created["bday_3050"]:
            replace_axis_annotation(ax, "_bday_3050_annotation", "30.50", (time_context["x_value_day_before"] - 0.001, 30.475), ha="center", fontsize=10, fontfamily="DejaVu Serif")
            annotations_created["bday_3050"] = True
        if not annotations_created["bday_3000"]:
            replace_axis_annotation(ax, "_bday_3000_annotation", "30.00", (time_context["x_value_day_before"] - 0.001, 29.975), ha="center", fontsize=10, fontfamily="DejaVu Serif")
            annotations_created["bday_3000"] = True
        if not annotations_created["bday_2950"]:
            replace_axis_annotation(ax, "_bday_2950_annotation", "29.50", (time_context["x_value_day_before"] - 0.001, 29.475), ha="center", fontsize=10, fontfamily="DejaVu Serif")
            annotations_created["bday_2950"] = True

    state["yesterday_annotation"] = yesterday_annotation
    state["before_yesterday_annotation"] = before_yesterday_annotation
    state["today_annotation_flag"] = today_annotation_flag
    state["today_inhg_annotation_flag"] = today_inhg_annotation_flag
    return state


def finalize_barograph_frame(
    fig,
    ax,
    line,
    xs,
    ys,
    time_context,
    i,
    aobs_site,
    datetime_cls,
    timedelta_cls,
    overlay_line=None,
    overlay_xs=None,
    overlay_ys=None,
    overlay_location_label="",
    output_path="/home/santod/baro_trace.png",
):
    line.set_data(xs, ys)
    if overlay_line is not None:
        overlay_line.set_data(overlay_xs or [], overlay_ys or [])
    ax.set_xlim(datetime_cls.now() - timedelta_cls(minutes=3600), datetime_cls.now())

    prefix_text = "Barometric Pressure - "
    location_text = aobs_site
    overlay_location_text = (overlay_location_label or "").strip()

    prefix_artist = getattr(fig, "_barograph_title_prefix_text", None)
    location_artist = getattr(fig, "_barograph_title_location_text", None)
    underline_artist = getattr(fig, "_barograph_title_location_underline", None)
    separator_artist = getattr(fig, "_barograph_title_separator_text", None)
    overlay_location_artist = getattr(fig, "_barograph_title_overlay_location_text", None)
    overlay_underline_artist = getattr(fig, "_barograph_title_overlay_location_underline", None)

    if prefix_artist is None:
        prefix_artist = fig.text(
            0.5,
            0.03,
            prefix_text,
            fontsize=12,
            ha="left",
            va="top",
            fontweight="bold",
            color="black",
            zorder=10,
        )
        fig._barograph_title_prefix_text = prefix_artist

    if location_artist is None:
        location_artist = fig.text(
            0.5,
            0.03,
            location_text,
            fontsize=12,
            ha="left",
            va="top",
            fontweight="bold",
            color="black",
            zorder=11,
        )
        fig._barograph_title_location_text = location_artist

    if separator_artist is None:
        separator_artist = fig.text(
            0.5,
            0.03,
            "   ",
            fontsize=12,
            ha="left",
            va="top",
            fontweight="bold",
            color="black",
            zorder=10,
        )
        fig._barograph_title_separator_text = separator_artist

    if overlay_location_artist is None:
        overlay_location_artist = fig.text(
            0.5,
            0.03,
            overlay_location_text,
            fontsize=12,
            ha="left",
            va="top",
            fontweight="bold",
            color="black",
            zorder=11,
        )
        fig._barograph_title_overlay_location_text = overlay_location_artist

    prefix_artist.set_text(prefix_text)
    location_artist.set_text(location_text)
    separator_artist.set_text("   " if overlay_location_text else "")
    overlay_location_artist.set_text(overlay_location_text)

    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()

    prefix_bbox = prefix_artist.get_window_extent(renderer=renderer)
    location_bbox = location_artist.get_window_extent(renderer=renderer)
    separator_bbox = separator_artist.get_window_extent(renderer=renderer)
    overlay_location_bbox = overlay_location_artist.get_window_extent(renderer=renderer)
    figure_bbox = fig.bbox

    total_width_fraction = (
        prefix_bbox.width
        + location_bbox.width
        + separator_bbox.width
        + overlay_location_bbox.width
    ) / figure_bbox.width
    prefix_width_fraction = prefix_bbox.width / figure_bbox.width
    location_width_fraction = location_bbox.width / figure_bbox.width
    separator_width_fraction = separator_bbox.width / figure_bbox.width

    start_x = 0.5 - (total_width_fraction / 2)
    text_y = 0.03
    prefix_artist.set_position((start_x, text_y))
    location_artist.set_position((start_x + prefix_width_fraction, text_y))
    separator_artist.set_position((start_x + prefix_width_fraction + location_width_fraction, text_y))
    overlay_location_artist.set_position((start_x + prefix_width_fraction + location_width_fraction + separator_width_fraction, text_y))

    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    location_bbox = location_artist.get_window_extent(renderer=renderer)
    overlay_location_bbox = overlay_location_artist.get_window_extent(renderer=renderer)
    line_x0 = location_bbox.x0 / figure_bbox.width
    line_x1 = location_bbox.x1 / figure_bbox.width
    line_y = (location_bbox.y0 / figure_bbox.height) + 0.004

    location_artist.set_color("black")
    overlay_location_artist.set_color("black")

    if underline_artist is None:
        underline_artist = Line2D(
            [line_x0, line_x1],
            [line_y, line_y],
            transform=fig.transFigure,
            color="red",
            linewidth=2.0,
            zorder=9,
        )
        fig.add_artist(underline_artist)
        fig._barograph_title_location_underline = underline_artist
    else:
        underline_artist.set_xdata([line_x0, line_x1])
        underline_artist.set_ydata([line_y, line_y])
        underline_artist.set_color("red")
        underline_artist.set_linewidth(2.0)

    if overlay_location_text:
        overlay_line_x0 = overlay_location_bbox.x0 / figure_bbox.width
        overlay_line_x1 = overlay_location_bbox.x1 / figure_bbox.width
        overlay_line_y = (overlay_location_bbox.y0 / figure_bbox.height) + 0.004

        if overlay_underline_artist is None:
            overlay_underline_artist = Line2D(
                [overlay_line_x0, overlay_line_x1],
                [overlay_line_y, overlay_line_y],
                transform=fig.transFigure,
                color="green",
                linewidth=2.0,
                zorder=9,
            )
            fig.add_artist(overlay_underline_artist)
            fig._barograph_title_overlay_location_underline = overlay_underline_artist
        else:
            overlay_underline_artist.set_xdata([overlay_line_x0, overlay_line_x1])
            overlay_underline_artist.set_ydata([overlay_line_y, overlay_line_y])
            overlay_underline_artist.set_color("green")
            overlay_underline_artist.set_linewidth(2.0)
            overlay_underline_artist.set_visible(True)
    elif overlay_underline_artist is not None:
        overlay_underline_artist.set_visible(False)

    fig.savefig(output_path, bbox_inches="tight", pad_inches=0.35)
    print(i, ",", time_context["now"])
