from setuptools import setup, find_packages

setup(
    name="barbara_updater",
    version="5.1.6",
    author="santod",
    description="weather observer",
    py_modules=["barbara3"],
    packages=find_packages(include=["MODULE_TWO", "MODULE_TWO.*"]),
    include_package_data=True,
    package_data={
        "MODULE_TWO": [
            "*.py",
            "*.png",
            "*.jpg",
            "*.gif",
            "*.json",
            "*.*.py"
            "*/*.png",
            "*/*.jpg",
            "*/*.gif",
            "*/*.json",
            "*.*.*.py",
            "*.*.*.png",
            "*.*.*.jpg",
            "*.*.*.gif",
            "*.*.*.json",
        ],
    },
)
