from __future__ import annotations

import logging
import os
from collections.abc import Sequence
from typing import Any

from pymongo import MongoClient, server_api  # type: ignore[import-not-found]


def _build_logger(name: str) -> logging.Logger:
    try:
        from d4rk.Logs import setup_logger as external_setup_logger  # type: ignore[import-not-found]
    except ImportError:
        logger = logging.getLogger(name)
        if not logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter("[%(levelname)s] %(name)s: %(message)s"))
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return logger

    return external_setup_logger(name)


logger = _build_logger("Database")


class Database:
    def __init__(self, database_url: str | None = None):
        self.client: MongoClient | None = None
        self.db: Any | None = None
        self.database_name: str | None = None
        self.is_connected = False
        self._collections: tuple[type[Any], ...] = ()
        self._database_url = database_url

    def connect(
        self,
        name: str,
        collections: Sequence[type[Any]] | None = None,
        database_url: str | None = None,
    ) -> "Database":
        resolved_url = database_url or self._database_url or os.getenv("DATABASE_URL")
        if not resolved_url:
            raise ValueError("A MongoDB connection string is required. Pass database_url or set DATABASE_URL.")

        self.database_name = name.replace(" ", "")
        self._collections = tuple(collections or ())
        self._database_url = resolved_url

        try:
            client = MongoClient(resolved_url, server_api=server_api.ServerApi("1"))
            database = client[self.database_name]
            self.client = client
            self.db = database
            self._load_custom_collections()
            client.admin.command("ping")
        except Exception as exc:
            self.is_connected = False
            raise ConnectionError(f"Failed to connect to MongoDB '{name}': {exc}") from exc

        self.is_connected = True
        logger.info("Successfully connected to %s MongoDB.", name)
        return self

    def disconnect(self) -> None:
        if self.client is not None:
            self.client.close()
        self.client = None
        self.db = None
        self.is_connected = False

    def _load_custom_collections(self) -> None:
        for custom_class in self._collections:
            collection_name = getattr(custom_class, "collection_name", custom_class.__name__)
            base_collection = self.get_collection(collection_name)
            instance = custom_class(base_collection)
            setattr(self, custom_class.__name__, instance)

    def get_collection(self, collection: str) -> Any:
        if self.db is None:
            raise RuntimeError("Database is not connected.")
        database = self.db
        return database[collection]


db = Database()
