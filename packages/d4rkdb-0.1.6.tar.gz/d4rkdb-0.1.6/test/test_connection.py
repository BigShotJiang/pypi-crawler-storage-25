from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from db import db

DATABASE_URL = os.getenv("DATABASE_URL")
DATABASE_NAME = os.getenv("DATABASE_NAME", "Serandip")


def main() -> None:
    if not DATABASE_URL:
        raise ValueError("Set DATABASE_URL before running this script.")

    db.connect(DATABASE_NAME, database_url=DATABASE_URL)
    try:
        collections = db.db.list_collection_names() if db.db is not None else []
        print(f"Connected to {db.database_name}")
        print(f"Collections: {collections}")
    finally:
        db.disconnect()
        print("Disconnected")


if __name__ == "__main__":
    main()
