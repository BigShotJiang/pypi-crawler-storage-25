from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from db import Database, db as shared_db


class Users:
    collection_name = "users"

    def __init__(self, collection):
        self.collection = collection


class FakeAdmin:
    def __init__(self):
        self.commands: list[str] = []

    def command(self, name: str) -> dict[str, int]:
        self.commands.append(name)
        return {"ok": 1}


class FakeMongoDatabase:
    def __init__(self):
        self.collections: dict[str, dict[str, str]] = {}

    def __getitem__(self, name: str) -> dict[str, str]:
        self.collections.setdefault(name, {"collection": name})
        return self.collections[name]


class FakeMongoClient:
    def __init__(self, url: str, server_api=None):
        self.url = url
        self.server_api = server_api
        self.admin = FakeAdmin()
        self.databases: dict[str, FakeMongoDatabase] = {}
        self.closed = False

    def __getitem__(self, name: str) -> FakeMongoDatabase:
        self.databases.setdefault(name, FakeMongoDatabase())
        return self.databases[name]

    def close(self) -> None:
        self.closed = True


def test_requires_connection_url() -> None:
    try:
        Database().connect("Example")
    except ValueError as exc:
        assert "database_url" in str(exc)
    else:
        raise AssertionError("Database.connect should require a connection string.")


def test_connection_flow_and_wrappers() -> None:
    with patch("db.core.MongoClient", FakeMongoClient):
        database = Database()
        returned = database.connect("Main App", collections=[Users], database_url="mongodb://example")

    assert returned is database
    assert database.is_connected is True
    assert database.database_name == "MainApp"
    assert database.get_collection("users") == {"collection": "users"}
    assert getattr(database, "Users").collection == {"collection": "users"}
    assert database.client is not None
    assert database.client.admin.commands == ["ping"]

    database.disconnect()
    assert database.is_connected is False
    assert database.client is None


def test_package_exports_work() -> None:
    imported = __import__("db", fromlist=["Database", "db"])
    assert imported.Database is Database
    assert imported.db is shared_db


def test_db_module_is_packaged() -> None:
    assert importlib.util.find_spec("db") is not None


if __name__ == "__main__":
    test_requires_connection_url()
    test_connection_flow_and_wrappers()
    test_package_exports_work()
    test_db_module_is_packaged()
    print("test/test.py: ok")
