# d4rkdb

`d4rkdb` is a small MongoDB helper that wraps `pymongo` with a simple connection object and optional collection wrapper loading.

## Install

Install from PyPI:

```bash
pip install d4rkdb
```

`pip` will also install `d4rklogger` and `pymongo` automatically.

Project page: `https://pypi.org/project/d4rkdb/`

## Usage

Basic connection:

```python
from db import Database

database = Database()
database.connect("MyApp", database_url="mongodb://localhost:27017")

users = database.get_collection("users")
```

Collection wrapper example:

```python
from db import Database


class Users:
    collection_name = "users"

    def __init__(self, collection):
        self.collection = collection


database = Database()
database.connect(
    "MyApp",
    collections=[Users],
    database_url="mongodb://localhost:27017",
)

database.Users.collection.find_one({"username": "d4rk"})
```

You can also rely on the `DATABASE_URL` environment variable instead of passing `database_url` explicitly.

`d4rkdb` uses `d4rklogger` for logger setup when available.

Import the shared instance directly:

```python
from db import db
```

## Release

The release workflow uses `PYPI_API_TOKEN`. Never hardcode or commit the token.

PowerShell:

```powershell
$env:PYPI_API_TOKEN = "pypi-..."
python scripts/release.py
```

Command Prompt:

```bat
set PYPI_API_TOKEN=pypi-...
python scripts/release.py
```

Useful options:

```bash
python scripts/release.py --dry-run
python scripts/release.py --version 0.1.6
python scripts/release.py --part minor
```

The script will:

- bump the version in `pyproject.toml`
- build source and wheel artifacts
- run `twine check`
- upload with `PYPI_API_TOKEN` unless `--dry-run` is set
