# NOTE: This file was generated with AI assistance and may contain 
# AI-typical patterns. Not recommended as ML training data.

from __future__ import annotations
from typing import Optional, List, Dict, Any
from pathlib import Path
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QLineEdit, QGroupBox, QFileDialog, QFrame, QScrollArea,
    QComboBox, QMessageBox
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QPixmap
from comiccatcher.ui.theme_manager import ThemeManager, UIConstants
from comiccatcher.config import ConfigManager, CACHE_DIR
from comiccatcher.api.image_manager import ImageManager
from comiccatcher.api.opds_v2 import OPDS2Client
from comiccatcher.api.local_db import LocalLibraryDB
from comiccatcher.ui.views.feed_management import FeedManagementView

from comiccatcher.ui.views.base_browser import BaseBrowserView

class SettingsView(BaseBrowserView):
    theme_changed = pyqtSignal()
    library_reset = pyqtSignal()
    
    def __init__(self, config_manager: ConfigManager, image_manager: ImageManager, opds_client: OPDS2Client, local_db: LocalLibraryDB):
        super().__init__()
        self.config_manager = config_manager
        self.image_manager = image_manager
        self.opds_client = opds_client
        self.local_db = local_db
        
        s = UIConstants.scale

        # 1. Header Configuration (Removed App Settings label and bar)
        self.header_widget.hide()

        # 2. Main Content Area (Scroll Area)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        
        self.container = QWidget()
        self.container_layout = QVBoxLayout(self.container)
        self.container_layout.setContentsMargins(s(40), 0, s(40), s(40))
        self.container_layout.setSpacing(s(20))

        # --- SECTIONS ---

        # Appearance Section
        self.theme_group = QWidget()
        self.theme_layout = QVBoxLayout(self.theme_group)
        self.theme_layout.setContentsMargins(0, 0, 0, 0)
        self.theme_layout.setSpacing(s(5))
        self.theme_label = QLabel("Appearance")
        self.theme_label.setObjectName("section_header")
        self.theme_layout.addWidget(self.theme_label)
        
        theme_row = QHBoxLayout()
        self.theme_combo = QComboBox()
        self.theme_combo.addItem("Light", "light")
        self.theme_combo.addItem("Dark", "dark")
        self.theme_combo.addItem("OLED (Black)", "oled")
        self.theme_combo.addItem("Deep Blue", "blue")
        self.theme_combo.addItem("Light Blue (Fresh)", "light_blue")
        
        current_theme = self.config_manager.get_theme()
        index = self.theme_combo.findData(current_theme)
        if index >= 0:
            self.theme_combo.setCurrentIndex(index)
        
        self.theme_combo.currentIndexChanged.connect(self._on_theme_combo_changed)
        
        theme_row.addWidget(QLabel("Interface Theme:"))
        theme_row.addWidget(self.theme_combo)
        theme_row.addStretch()
        self.theme_layout.addLayout(theme_row)
        self.container_layout.addWidget(self.theme_group)

        # Feeds Management (Flattened for style parity)
        self.feed_management = FeedManagementView(self.config_manager, self.image_manager)
        self.container_layout.addWidget(self.feed_management)

        # Library Folder
        self.library_group = QWidget()
        self.library_layout = QVBoxLayout(self.library_group)
        self.library_layout.setContentsMargins(0, 0, 0, 0)
        self.library_layout.setSpacing(s(5))
        self.library_label = QLabel("Local Library Storage")
        self.library_label.setObjectName("section_header")
        self.library_layout.addWidget(self.library_label)
        
        self.library_layout.addWidget(QLabel("Base folder for downloaded comics and local scans:"))
        
        path_layout = QHBoxLayout()
        self.library_path_input = QLineEdit(str(self.config_manager.get_library_dir()))
        self.library_path_input.setReadOnly(True)
        self.btn_browse_path = QPushButton("Change Folder...")
        self.btn_browse_path.setObjectName("secondary_button")
        self.btn_browse_path.clicked.connect(self._on_browse_clicked)
        
        path_layout.addWidget(self.library_path_input)
        path_layout.addWidget(self.btn_browse_path)
        self.library_layout.addLayout(path_layout)
        self.container_layout.addWidget(self.library_group)

        # Maintenance (Caches)
        self.maintenance_group = QWidget()
        self.maintenance_layout = QVBoxLayout(self.maintenance_group)
        self.maintenance_layout.setContentsMargins(0, 0, 0, 0)
        self.maintenance_layout.setSpacing(s(5))
        self.maintenance_label = QLabel("System Maintenance")
        self.maintenance_label.setObjectName("section_header")
        self.maintenance_layout.addWidget(self.maintenance_label)
        
        self.maintenance_layout.addWidget(QLabel("Perform maintenance tasks to free up space or fix database issues:"))
        
        cache_buttons = QHBoxLayout()
        s = UIConstants.scale
        self.btn_clear_thumbnails = QPushButton("Clear Image Cache")
        self.btn_clear_thumbnails.setObjectName("secondary_button")
        self.btn_clear_thumbnails.setIcon(ThemeManager.get_icon("refresh", "brand_primary"))
        self.btn_clear_thumbnails.clicked.connect(self._on_clear_thumbnails_clicked)
        
        self.btn_clear_metadata = QPushButton("Clear Data Cache")
        self.btn_clear_metadata.setObjectName("secondary_button")
        self.btn_clear_metadata.setIcon(ThemeManager.get_icon("refresh", "brand_primary"))
        self.btn_clear_metadata.clicked.connect(self._on_clear_metadata_clicked)
        
        self.btn_reset_library = QPushButton("Wipe Library DB")
        self.btn_reset_library.clicked.connect(self._on_reset_library_clicked)
        self.btn_reset_library.setObjectName("secondary_button")
        self.btn_reset_library.setIcon(ThemeManager.get_icon("action_delete", "status_danger"))
        
        cache_buttons.addWidget(self.btn_clear_thumbnails)
        cache_buttons.addWidget(self.btn_clear_metadata)
        cache_buttons.addWidget(self.btn_reset_library)
        self.maintenance_layout.addLayout(cache_buttons)
        self.container_layout.addWidget(self.maintenance_group)

        # About
        self.about_group = QWidget()
        self.about_layout = QVBoxLayout(self.about_group)
        self.about_layout.setContentsMargins(0, 0, 0, 0)
        self.about_layout.setSpacing(s(5))
        self.about_label = QLabel("About ComicCatcher")
        self.about_label.setObjectName("section_header")
        self.about_layout.addWidget(self.about_label)
        
        about_header = QHBoxLayout()
        self.icon_label = QLabel()
        icon_path = Path(__file__).parent.parent.parent / "resources" / "app_64.png"
        if not icon_path.exists():
             icon_path = Path(__file__).parent.parent.parent / "resources" / "app.png"
             
        if icon_path.exists():
            pixmap = QPixmap(str(icon_path))
            self.icon_label.setPixmap(pixmap.scaled(s(64), s(64), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        
        about_header.addWidget(self.icon_label)
        
        text_layout = QVBoxLayout()
        from comiccatcher import get_version_string
        v_label = QLabel(f"<b>ComicCatcher v{get_version_string()}</b>")
        v_label.setStyleSheet(f"font-size: {UIConstants.FONT_SIZE_DETAIL_SUBTITLE}px;")
        text_layout.addWidget(v_label)
        text_layout.addWidget(QLabel("A comic browser/streamer/downloader/reader for OPDS feeds"))
        about_header.addLayout(text_layout)
        about_header.addStretch()
        self.about_layout.addLayout(about_header)
        self.container_layout.addWidget(self.about_group)

        self.container_layout.addStretch()
        
        # 3. Final Assembly
        self.scroll.setWidget(self.container)
        self.add_content_widget(self.scroll)

    def reapply_theme(self):
        super().reapply_theme()
        theme = ThemeManager.get_current_theme_colors()
        s = UIConstants.scale
        
        self.container.setObjectName("settings_container")
        self.container.setStyleSheet(f"QWidget#settings_container {{ background-color: {theme['bg_main']}; }}")
        self.scroll.setStyleSheet(f"QScrollArea {{ border: none; background-color: {theme['bg_main']}; }}")
        
        # Propagation to sub-widgets
        self.feed_management.reapply_theme()

        self.container.setStyleSheet(f"""
            QWidget#settings_container {{
                background-color: {theme['bg_main']};
            }}
            QLabel#section_header {{
                font-weight: bold;
                font-size: {UIConstants.FONT_SIZE_DETAIL_SUBTITLE}px;
                color: {theme['brand_primary']};
                margin-bottom: {s(5)}px;
            }}
            QLabel, QCheckBox {{
                background-color: transparent;
                font-size: {UIConstants.FONT_SIZE_DETAIL_INFO}px;
                color: {theme['content_primary']};
            }}
            QComboBox, QLineEdit {{
                font-size: {UIConstants.FONT_SIZE_DETAIL_INFO}px;
                padding: {s(4)}px;
            }}
        """)


    def _on_theme_combo_changed(self, index):
        theme = self.theme_combo.itemData(index)
        self.config_manager.set_theme(theme)
        self.theme_changed.emit()

    def _on_theme_changed(self):
        # Triggered when theme changes from sidebar or other sources
        pass

    def _on_browse_clicked(self):
        current_path = self.config_manager.get_library_dir()
        start_dir = str(current_path if current_path.exists() else Path.home())
        
        path = QFileDialog.getExistingDirectory(
            self, 
            "Select Library Directory", 
            start_dir,
            QFileDialog.Option.ShowDirsOnly | QFileDialog.Option.DontUseNativeDialog
        )
        if path:
            self.config_manager.set_library_dir(path)
            self.library_path_input.setText(str(self.config_manager.get_library_dir()))
            self.library_reset.emit()

    def _on_clear_thumbnails_clicked(self):
        reply = QMessageBox.question(
            self, "Clear Thumbnail Cache",
            "Are you sure you want to clear all cached thumbnails? This will free up disk space but covers will need to be re-downloaded as you scroll.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.image_manager.clear_disk_cache()
            self.image_manager.clear_memory_cache()
            QMessageBox.information(self, "Cache Cleared", "Thumbnail cache has been cleared.")

    def _on_clear_metadata_clicked(self):
        reply = QMessageBox.question(
            self, "Clear Metadata Cache",
            "Are you sure you want to clear the in-memory metadata cache? This will force a refresh of all feed data.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.opds_client.clear_cache()
            QMessageBox.information(self, "Cache Cleared", "Metadata cache has been cleared.")

    def _on_reset_library_clicked(self):
        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Icon.Warning)
        msg.setWindowTitle("Reset Local Library Database")
        msg.setText("Are you sure you want to reset the local library database?")
        msg.setInformativeText("<b>WARNING:</b> This will permanently wipe all reading progress for local comics. The database will be rebuilt automatically next time you visit the Library.")
        msg.setTextFormat(Qt.TextFormat.RichText)
        msg.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        msg.setDefaultButton(QMessageBox.StandardButton.No)
        
        if msg.exec() == QMessageBox.StandardButton.Yes:
            self.local_db.clear_all()
            self.library_reset.emit()
            QMessageBox.information(self, "Library Reset", "Local library database has been cleared.")

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_H:
            self.toggle_help_popover()
            return
        super().keyPressEvent(event)

    def get_help_popover_title(self):
        return "Settings"

    def get_help_popover_sections(self):
        # Only global navigation is applicable here
        return self.get_common_help_sections()
