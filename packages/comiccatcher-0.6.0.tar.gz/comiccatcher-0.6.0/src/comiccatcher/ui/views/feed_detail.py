# NOTE: This file was generated with AI assistance and may contain 
# AI-typical patterns. Not recommended as ML training data.

import asyncio
import uuid
from pathlib import Path
from typing import Optional, Dict
from urllib.parse import urljoin, urlparse

from PyQt6.QtWidgets import (
    QWidget, QHBoxLayout, QLabel, QPushButton, 
    QFrame
)
from PyQt6.QtCore import Qt, QTimer, QUrl
from PyQt6.QtGui import QPixmap, QDesktopServices
from comiccatcher.ui.theme_manager import ThemeManager, UIConstants, Keys

from comiccatcher.logger import get_logger
from comiccatcher.api.image_manager import ImageManager
from comiccatcher.api.opds_v2 import OPDSClientError
from comiccatcher.api.progression import ProgressionSync
from comiccatcher.models.opds import Publication, Metadata
from comiccatcher.api.feed_reconciler import FeedReconciler
from comiccatcher.ui.flow_layout import FlowLayout
from comiccatcher.ui.components.badge import Badge
from comiccatcher.ui.views.base_detail import BaseDetailView
from comiccatcher.ui.view_helpers import ViewportHelper, HelpPopoverMixin
from comiccatcher.ui.utils import format_artist_credits, format_publication_date, format_file_size, parse_opds_date, format_progression_status
from comiccatcher.ui.components.base_ribbon import BaseCardRibbon, FeedCardRibbon
from comiccatcher.ui.components.mini_detail_popover import MiniDetailPopover, format_opds_publication
from comiccatcher.ui.components.feed_browser_model import FeedBrowserModel

logger = get_logger("ui.feed_detail")

class FeedDetailView(BaseDetailView, HelpPopoverMixin):
    def __init__(self, config_manager, on_back, on_read, on_navigate, on_start_download, on_open_detail, image_manager: ImageManager, local_db=None):
        super().__init__(on_back, image_manager)
        self.config_manager = config_manager
        self.on_read = on_read
        self.on_navigate = on_navigate
        self.on_start_download = on_start_download
        self.on_open_detail = on_open_detail
        self.db = local_db

        self.api_client = None
        self.opds_client = None
        self.progression_sync = None

        self._current_pub = None
        self._current_base_url = None
        self._active_load_id = None
        self._pending_covers: Dict[str, asyncio.Task] = {} # url -> Task

        self.init_help_popover()
        self.detail_popover = MiniDetailPopover(self)

        # Monitor scrolling to trigger cover fetches for carousels
        self.scroll.verticalScrollBar().valueChanged.connect(lambda: self._on_scroll_debounced())
        self._scroll_timer = QTimer(self)
        self._scroll_timer.setSingleShot(True)
        self._scroll_timer.setInterval(UIConstants.SCROLL_DEBOUNCE_MS)
        self._scroll_timer.timeout.connect(self.ensure_visible_covers)

    def _on_scroll_debounced(self):
        self._scroll_timer.start()

    def _on_cover_request(self, url):
        # Primary reconciliation happens in ensure_visible_covers.
        if self.image_manager.get_image_sync(url):
            return
        if url in self._pending_covers:
            return

        def on_done():
            self._pending_covers.pop(url, None)
            if self.isVisible():
                for ribbon in self.findChildren(BaseCardRibbon):
                    ribbon.viewport().update()

        task = asyncio.create_task(ViewportHelper.fetch_cover_async(
            url, self.image_manager, set(), 
            on_done_callback=on_done, max_dim=300
        ))
        self._pending_covers[url] = task

    def ensure_visible_covers(self):
        """Reconciles currently visible covers in all ribbons: cancels off-screen, starts on-screen."""
        if not self.isVisible():
            return
            
        # 1. Identify what's visible now across all ribbons
        visible_urls = set()
        for ribbon in self.findChildren(BaseCardRibbon):
            if not ribbon.isVisible():
                continue
            visible_urls.update(ViewportHelper.get_visible_urls(ribbon))

        # 2. Cancel tasks for URLs no longer visible
        to_cancel = [url for url in self._pending_covers if url not in visible_urls]
        for url in to_cancel:
            task = self._pending_covers.pop(url)
            task.cancel()
        
        # 3. Start tasks for visible URLs not yet cached or pending
        for url in visible_urls:
            if url not in self._pending_covers and not self.image_manager.get_image_sync(url):
                self._on_cover_request(url)

    def reapply_theme(self):
        super().reapply_theme()
        theme = ThemeManager.get_current_theme_colors()
        s = UIConstants.scale
        
        # Propagate to dynamic badges and buttons
        for badge in self.findChildren(Badge):
            badge.reapply_theme()

        for label in self.findChildren(QLabel):
            if label.objectName() == "carousel_header":
                label.setStyleSheet(f"font-size: {s(18)}px; font-weight: bold; margin-top: {s(20)}px; color: {theme['content_primary']};")
            elif label.objectName() == "meta_label":
                label.setStyleSheet(f"font-weight: bold; font-size: {UIConstants.FONT_SIZE_DETAIL_INFO}px; margin-bottom: {UIConstants.scale(2)}px; color: {theme['content_secondary']};")
            elif label.objectName() == "meta_status_hint":
                label.setStyleSheet(f"font-size: {UIConstants.FONT_SIZE_BADGE}px; color: {theme['content_secondary']}; font-style: italic; margin-top: {UIConstants.scale(5)}px;")
            else:

                # Default for other dynamic labels like the credit values
                if label.text() and not label.objectName():
                     label.setStyleSheet(f"font-size: {UIConstants.FONT_SIZE_DETAIL_INFO}px; color: {theme['content_primary']};")
                
        for btn in self.findChildren(QPushButton):
            if btn.objectName() == "link_button":
                btn.setStyleSheet(f"""
                    QPushButton {{ color: {theme['brand_primary']}; font-size: {s(13)}px; text-align: left; background: transparent; border: none; }}
                    QPushButton:disabled {{ color: {theme['content_secondary']}; }}
                """)

    def load_publication(self, pub: Publication, base_url: str, api_client, opds_client, image_manager, context_pubs=None, history=None, force_refresh: bool = False):
        self.api_client = api_client
        self.opds_client = opds_client
        self.image_manager = image_manager
        self._context_pubs = context_pubs
        
        device_id = self.config_manager.get_device_id()
        self.progression_sync = ProgressionSync(api_client, device_id)
        
        # If the publication is already enriched (from mini-popover), 
        # its links might be relative to the manifest itself.
        # Check for a 'self' link to get the true base URL for this publication.
        actual_base_url = base_url or ""
        if pub.links:
            for link in pub.links:
                rels = [link.rel] if isinstance(link.rel, str) else (link.rel or [])
                if "self" in rels and link.href:
                    # Resolve 'self' relative to the base we were given
                    actual_base_url = urljoin(actual_base_url, link.href)
                    break

        self._current_pub = pub
        self._current_base_url = actual_base_url
        self._active_load_id = str(uuid.uuid4())
        
        # 1. Cancel existing fetches
        for task in self._pending_covers.values():
            task.cancel()
        self._pending_covers.clear()
        
        self.setUpdatesEnabled(False)
        try:
            self._clear_layout(self.content_layout)
            self.progress.setVisible(True)
            
            if not (pub.readingOrder and len(pub.readingOrder) > 0) or force_refresh:
                # We fetch full metadata using the ORIGINAL base_url from the feed
                asyncio.create_task(self._fetch_full_metadata(pub, base_url, self._active_load_id, force_refresh))
            else:
                # But we render and fetch progression using the ACTUAL base of this enriched object
                self._render_details(pub, actual_base_url)
                self.progress.setVisible(False)
                asyncio.create_task(self._fetch_progression(pub, actual_base_url, self._active_load_id))
            
            if force_refresh:
                QTimer.singleShot(500, self.ensure_visible_covers)
        finally:
            self.setUpdatesEnabled(True)

    async def _fetch_full_metadata(self, pub: Publication, base_url: str, load_id: str, force_refresh: bool = False):
        manifest_url = None
        for link in (pub.links or []):
            if link.type in ["application/webpub+json", "application/divina+json", "application/opds-publication+json"]:
                manifest_url = link.href
                break
        
        fetched_pub = pub
        if manifest_url and load_id == self._active_load_id:
            try:
                full_url = urljoin(base_url, manifest_url)
                full_pub = await self.opds_client.get_publication(full_url, force_refresh=force_refresh)
                
                if load_id == self._active_load_id:
                    if not full_pub.images and pub.images: full_pub.images = pub.images
                    if full_pub.metadata and pub.metadata:
                        if not full_pub.metadata.description and pub.metadata.description: 
                            full_pub.metadata.description = pub.metadata.description
                        if not full_pub.metadata.numberOfBytes and pub.metadata.numberOfBytes:
                            full_pub.metadata.numberOfBytes = pub.metadata.numberOfBytes
                    elif not full_pub.metadata and pub.metadata:
                        full_pub.metadata = pub.metadata
                    fetched_pub = full_pub
                    actual_base_url = full_url
            except OPDSClientError as e:
                logger.error(f"OPDS Error upgrading metadata from {full_url}: {e}")
            except Exception as e:
                logger.error(f"Unexpected error upgrading metadata: {e}")
        
        actual_base_url = actual_base_url if 'actual_base_url' in locals() else base_url
        self._current_pub = fetched_pub
        self._current_base_url = actual_base_url
        self.setUpdatesEnabled(False)
        try:
            self._render_details(fetched_pub, actual_base_url)
        finally:
            self.setUpdatesEnabled(True)
        
        self.progress.setVisible(False)
        asyncio.create_task(self._fetch_progression(fetched_pub, actual_base_url, load_id))

    async def _fetch_progression(self, pub: Publication, base_url: str, load_id: str):
        prog_url = None
        if pub.links:
            for link in pub.links:
                rels = [link.rel] if isinstance(link.rel, str) else (link.rel or [])
                if any(r in rels for r in ["http://librarysimplified.org/terms/rel/state", "http://www.cantook.com/api/progression", "http://readium.org/rel/progression"]):
                    prog_url = urljoin(base_url, link.href)
                    break
        
        if prog_url and load_id == self._active_load_id:
            try:
                data = await self.progression_sync.get_progression(prog_url)
                if data and load_id == self._active_load_id:
                    pct, pos = ProgressionSync.extract_locations(data)
                    if pct is not None:
                        self._update_progression_ui(pct, pub, pos)
            except Exception as e:
                logger.error(f"Error fetching progression: {e}")

    def _update_progression_ui(self, pct: float, pub: Publication, pos: int = None):
        if hasattr(self, 'progression_label'):
            total_pages = 0
            if pub.readingOrder:
                total_pages = len(pub.readingOrder)
            elif hasattr(pub.metadata, 'numberOfPages') and pub.metadata.numberOfPages:
                total_pages = int(pub.metadata.numberOfPages)
            
            theme = ThemeManager.get_current_theme_colors()
            dim_color = theme['content_secondary']
            
            if total_pages > 0:
                if pos is not None and pos > 0:
                    current_page = pos
                else:
                    current_page = int(pct * total_pages) + 1
                
                current_page = min(current_page, total_pages)
                
                prog_text = format_progression_status(current_page, total_pages, pct)
                    
                if self._file_size_str:
                    prog_text += f"&nbsp;&nbsp;&nbsp;•&nbsp;&nbsp;&nbsp;<span style='color: {dim_color};'>{self._file_size_str}</span>"
                self.progression_label.setText(prog_text)
                self._update_cover_progress(current_page, total_pages)
                
                # Update button text
                if current_page >= total_pages and total_pages > 1:
                    self.btn_read.setText("Read Again")
                elif current_page > 1 or pct > 0.01: # Use a small epsilon
                    self.btn_read.setText("Resume")
                else:
                    self.btn_read.setText("Read Now")
            else:
                prog_text = format_progression_status(0, 0, pct)
                if self._file_size_str:
                    prog_text += f"&nbsp;&nbsp;&nbsp;•&nbsp;&nbsp;&nbsp;<span style='color: {dim_color};'>{self._file_size_str}</span>"
                self.progression_label.setText(prog_text)
                if pct > 0.01:
                    self.btn_read.setText("Resume")

    async def _check_for_local_copy(self, pub: Publication, download_url: str):
        # We search by URL in the local DB
        row = await asyncio.to_thread(self.db.get_comic_by_url, download_url)
        if row:
            path_str = row["file_path"]
            if path_str:
                p = Path(path_str)
                if p.exists():
                    try:
                        size_bytes = p.stat().st_size
                        def format_size(num):
                            for unit in ['B', 'KB', 'MB', 'GB']:
                                if abs(num) < 1024.0:
                                    return f"{num:3.1f} {unit}"
                                num /= 1024.0
                            return f"{num:.1f} TB"
                        self._file_size_str = format_size(size_bytes)
                        # Refresh label if already showing something
                        theme = ThemeManager.get_current_theme_colors()
                        dim_color = theme['content_secondary']
                        
                        txt = self.progression_label.text()
                        if txt:
                            if self._file_size_str not in txt:
                                # Replace plain dot with spaced dot and colored size
                                self.progression_label.setText(f"{txt}&nbsp;&nbsp;&nbsp;•&nbsp;&nbsp;&nbsp;<span style='color: {dim_color};'>{self._file_size_str}</span>")
                        else:
                            self.progression_label.setText(f"<span style='color: {dim_color};'>{self._file_size_str}</span>")
                    except:
                        pass

    def _on_delete_local(self, path: str):
        try:
            p = Path(path)
            if p.exists():
                p.unlink()
                logger.info(f"Deleted local file from detail view: {p}")
            
            if self.db:
                self.db.remove_comic(str(p))
                logger.info(f"Removed from local DB: {p}")
            
            # Refresh view (remove delete button/update UI) or go back
            self.on_back() 
        except Exception as e:
            logger.error(f"Error during online detail delete: {e}")

    def _render_details(self, pub: Publication, base_url: str):
        self.setUpdatesEnabled(False)
        try:
            info_layout = self._setup_main_info_layout()
            
            # Reset cover while loading
            self.cover_label.clear()
            self.cover_label.setText("Loading Cover...")
            
            m = pub.metadata
            if not m:
                m = Metadata(title="Unknown")
            
            self._add_title(m.title, m.subtitle)

            # Series and Position line
            if m.belongsTo:
                # Prioritize series, then collection
                coll = None
                if m.belongsTo.series and len(m.belongsTo.series) > 0:
                    coll = m.belongsTo.series[0]
                elif m.belongsTo.collection and len(m.belongsTo.collection) > 0:
                    coll = m.belongsTo.collection[0]
                
                if coll:
                    name_html = f"<i>{coll.name}</i>"
                    pos_str = ""
                    if coll.position is not None:
                        p = str(coll.position)
                        if p.endswith(".0"): p = p[:-2]
                        pos_str = f" #{p}"
                    
                    series_label = QLabel(f"{name_html}{pos_str}")
                    series_label.setTextFormat(Qt.TextFormat.RichText)
                    theme = ThemeManager.get_current_theme_colors()
                    series_label.setStyleSheet(f"font-size: 16px; color: {theme['content_primary']}; margin-top: 2px;")
                    self.info_layout.addWidget(series_label)

            # Publisher and Pub Date line
            pub_contributor = None
            if m.publisher and len(m.publisher) > 0:
                pub_contributor = m.publisher[0]
            
            month, year = parse_opds_date(m.published)
            display_date = format_publication_date(month, year)

            if pub_contributor or display_date:
                line_layout = QHBoxLayout()
                line_layout.setContentsMargins(0, 0, 0, 0)
                line_layout.setSpacing(5)
                line_layout.setAlignment(Qt.AlignmentFlag.AlignLeft)
                theme = ThemeManager.get_current_theme_colors()
                
                if pub_contributor:
                    # Link logic
                    on_click = None
                    if pub_contributor.links and len(pub_contributor.links) > 0:
                        href = pub_contributor.links[0].href
                        if href:
                            full_url = urljoin(base_url, href)
                            on_click = lambda u=full_url, t=pub_contributor.name: self.on_navigate(u, t)
                    
                    # Pill-style Publisher
                    badge = Badge(pub_contributor.name, on_click=on_click)
                    line_layout.addWidget(badge)
                    
                    if display_date:
                        sep = QLabel(" • ")
                        sep.setStyleSheet(f"font-size: 14px; color: {theme['content_secondary']};")
                        line_layout.addWidget(sep)

                if display_date:
                    date_label = QLabel(display_date)
                    date_label.setStyleSheet(f"font-size: 14px; color: {theme['content_secondary']};")
                    line_layout.addWidget(date_label)

                self.info_layout.addLayout(line_layout)

            # Action Buttons
            manifest_url = next((urljoin(base_url, l.href) for l in (pub.links or []) if l.type in ["application/webpub+json", "application/divina+json", "application/opds-publication+json"]), None)
            
            # Use FeedReconciler to find best download link
            download_url, _, download_size = FeedReconciler._find_acquisition_link(pub, base_url)
            
            # Check if links claim this is streamable (before manifest is fully fetched)
            has_divina_link = any(l.type == "application/divina+json" for l in (pub.links or []))
            
            # If we have an empty reading order, it's not streamable even if the links say so
            if pub.readingOrder is not None and len(pub.readingOrder) == 0:
                has_divina_link = False

            is_streamable = pub.is_divina or has_divina_link

            self.btn_read = self.create_action_button(
                "Read Now",
                lambda: self.on_read(pub, manifest_url or base_url, self._context_pubs),
                icon_name="book"
            )
            self.btn_read.setEnabled(is_streamable)
            
            self.btn_download = self.create_action_button(
                "Download",
                lambda: self.on_start_download(pub, download_url),
                icon_name="download"
            )
            self.btn_download.setEnabled(download_url is not None)
            
            # Sync cover hover state with button state
            self.update_cover_state()
            
            if not hasattr(self, 'actions_layout'):
                self.actions_layout = QHBoxLayout()
                s = UIConstants.scale
                self.actions_layout.setSpacing(s(10))
                self.actions_layout.setAlignment(Qt.AlignmentFlag.AlignLeft)
                self.info_layout.addLayout(self.actions_layout)

            self.actions_layout.addWidget(self.btn_read)
            self.actions_layout.addWidget(self.btn_download)

            # Support Status Labels
            theme = ThemeManager.get_current_theme_colors()
            notes = []
            
            # 1. Streaming Support Hint
            if not is_streamable:
                notes.append("Page streaming not available")

            # 2. Detailed acquisition notes (Borrow, Purchase, Unsupported Formats)
            acq_note = FeedReconciler.get_acquisition_note(pub)
            if acq_note:
                notes.append(acq_note)
            
            if notes:
                full_note_text = "Note: " + " • ".join(notes)
                status_hint = QLabel(full_note_text)
                status_hint.setObjectName("meta_status_hint")
                status_hint.setWordWrap(True)
                self.info_layout.addWidget(status_hint)
            
            # Check if already downloaded (if link exists)
            self._file_size_str = None
            if download_url and self.db:
                asyncio.create_task(self._check_for_local_copy(pub, download_url))

            # Progression & Page Count
            self._add_progression_label()
            
            total_pages = m.numberOfPages or (len(pub.readingOrder) if pub.readingOrder else 0)
            
            # Format remote file size if available (Link property/size priority, then Metadata fallback)
            self._file_size_str = None
            size_val = download_size or (m.numberOfBytes if m else None)
            if size_val:
                self._file_size_str = format_file_size(size_val)
                
            prog_parts = []
            if total_pages:
                prog_parts.append(f"{total_pages} Pages")
            
            if self._file_size_str:
                theme = ThemeManager.get_current_theme_colors()
                dim_color = theme['content_secondary']
                prog_parts.append(f"<span style='color: {dim_color};'>{self._file_size_str}</span>")

            if prog_parts:
                self.progression_label.setText(" • ".join(prog_parts))

            # Metadata
            roles = {}
            roles_orig = {}
            
            # Use 'Author' as the primary label for OPDS 1.2, 'Writer' for others
            is_opds12 = m.conformsTo and ("opds1_2" in m.conformsTo or m.conformsTo == "opds1_2")
            primary_author_label = "Author" if is_opds12 else "Writer"

            role_map = {
                "author": primary_author_label, "artist": "Artist", "penciler": "Penciller", 
                "inker": "Inker", "colorist": "Colorist", "letterer": "Letterer", 
                "coverArtist": "Cover Artist", "editor": "Editor", "contributor": "Contributor", 
                "publisher": "Publisher", "imprint": "Imprint"
            }
            for attr, label in role_map.items():
                val = getattr(m, attr, None)
                if val: # Always a List[Contributor]
                    roles_orig[label] = val
                    names = [v.name for v in val]
                    roles[label] = ", ".join(names)
            
            final_creds = format_artist_credits(roles)
            for cred in final_creds:
                if ":" in cred:
                    label, val = cred.split(":", 1)
                    label = label.strip()
                    # Map combined roles back to original data for link extraction
                    source_role = label
                    if label == "Artist" and "Artist" not in roles_orig:
                        source_role = "Penciller"
                    
                    self._add_clickable_metadata(info_layout, label, roles_orig.get(source_role, []), base_url)
            
            # Subjects
            if m.subject:
                self._add_subjects(info_layout, m.subject, base_url)
            
            # Web Links row
            alternate_links = []
            if pub.links:
                for link in pub.links:
                    rels = [link.rel] if isinstance(link.rel, str) else (link.rel or [])
                    # We want browser-friendly HTML links that are semantically alternate versions
                    if ("alternate" in rels or "related" in rels) and link.type == "text/html":
                        alternate_links.append(link)
            
            if alternate_links:
                row = QWidget()
                row_layout = QHBoxLayout(row)
                row_layout.setContentsMargins(0, 0, 0, 0)
                s = UIConstants.scale
                
                l = QLabel("<b>Links:</b>")
                l.setFixedWidth(s(100))
                l.setObjectName("meta_label")
                row_layout.addWidget(l)
                
                flow = FlowLayout(spacing=5)
                
                for link in alternate_links:
                    full_url = urljoin(base_url, link.href)
                    label_text = link.title
                    if not label_text:
                        parsed = urlparse(full_url)
                        label_text = parsed.netloc or full_url
                        if label_text.startswith("www."): label_text = label_text[4:]
                    
                    btn = Badge(label_text, lambda u=full_url: QDesktopServices.openUrl(QUrl(u)))
                    flow.addWidget(btn)
                
                flow_widget = QWidget()
                flow_widget.setLayout(flow)
                row_layout.addWidget(flow_widget, 1)
                
                info_layout.addWidget(row)

            # Summary (Description)
            if m.description:
                self._add_description(m.description)
                
            # Cover
            img_url = self._get_image_url(pub)
            if img_url:
                # Use a larger max_dim for details to ensure high quality
                asyncio.create_task(self._load_cover(urljoin(base_url, img_url), max_dim=1200))

            self.info_layout.addStretch()

            # carousels
            self._add_carousels(pub, base_url)
            
            # Initial margin adjustment
            self.update_header_margins()
        finally:
            self.setUpdatesEnabled(True)

    async def _load_cover(self, url: str, max_dim: Optional[int] = None):
        await self.image_manager.get_image_b64(url, max_dim=max_dim)
        full_path = self.image_manager._get_cache_path(url)
        if full_path.exists():
            pixmap = QPixmap(str(full_path))
            if not pixmap.isNull():
                self.set_cover_pixmap(pixmap)

    def _get_image_url(self, pub: Publication) -> Optional[str]:
        # Priority 1: First page of reading order (highest quality source)
        if pub.readingOrder:
            return pub.readingOrder[0].href
            
        # Priority 2: Explicit cover relation
        if pub.images:
            for img in pub.images:
                rel = img.rel or ""
                if "cover" in rel or "http://opds-spec.org/image" in rel:
                    return img.href
            # Fallback to first image
            return pub.images[0].href
            
        # Priority 3: Links with image rel or type
        if pub.links:
            for link in pub.links:
                rel = link.rel or ""
                if "image" in rel or "cover" in rel:
                    return link.href
                if link.type and "image/" in link.type:
                    return link.href
        return None

    def _add_clickable_metadata(self, layout, label, contributors, base_url):
        items = contributors if isinstance(contributors, list) else [contributors]
        row_layout = QHBoxLayout()
        row_layout.setContentsMargins(0, 0, 0, 0)
        row_layout.setSpacing(5)
        
        l_label = QLabel(f"<b>{label}:</b>")
        l_label.setFixedWidth(100)
        l_label.setObjectName("meta_label")
        row_layout.addWidget(l_label)
        
        flow_layout = FlowLayout(spacing=5)
        
        for item in items:
            name = item.name
            href = None
            if item.links:
                for l in item.links:
                    if "opds" in (l.type or ""):
                        href = l.href
                        break
            
            if href:
                full_href = urljoin(base_url, href)
                badge = Badge(name, lambda u=full_href, t=name: self.on_navigate(u, t))
                flow_layout.addWidget(badge)
            else:
                badge = Badge(name)
                flow_layout.addWidget(badge)
        
        row_widget = QWidget()
        row_widget.setLayout(flow_layout)
        row_layout.addWidget(row_widget, 1)
        
        container = QWidget()
        container.setLayout(row_layout)
        layout.addWidget(container)

    def _add_subjects(self, layout, subject, base_url):
        row_layout = QHBoxLayout()
        row_layout.setContentsMargins(0, 0, 0, 0)
        row_layout.setSpacing(5)
        
        l_label = QLabel("<b>Subjects:</b>")
        l_label.setFixedWidth(UIConstants.DETAIL_META_WIDTH)
        l_label.setObjectName("meta_label")
        row_layout.addWidget(l_label)
        
        subj_widget = QWidget()
        subj_layout = FlowLayout(subj_widget, spacing=5)
        
        subjects = subject if isinstance(subject, list) else [subject]
        for s in subjects:
            name = s.get("name") if isinstance(s, dict) else str(s)
            href = None
            links = s.get("links", []) if isinstance(s, dict) else []
            for l in links:
                if "opds" in (l.get("type", "") if isinstance(l, dict) else getattr(l, 'type', '') or ""):
                    href = l.get("href") if isinstance(l, dict) else l.href
                    break
            
            if href:
                full_href = urljoin(base_url, href)
                badge = Badge(name, lambda u=full_href, t=name: self.on_navigate(u, t))
                subj_layout.addWidget(badge)
            else:
                badge = Badge(name)
                subj_layout.addWidget(badge)
        
        row_layout.addWidget(subj_widget, 1)
        container = QWidget()
        container.setLayout(row_layout)
        layout.addWidget(container)

    def update_header_margins(self):
        """Extended helper to handle manual carousel layouts in FeedDetailView."""
        # 1. Base logic for standard children
        super().update_header_margins()

        # 2. Specialized logic for manual carousel layouts
        header_margin = UIConstants.scale(10)

        # Look for the QHBoxLayouts we created manually for carousels
        for i in range(self.content_layout.count()):
            item = self.content_layout.itemAt(i)
            if item and item.layout() and isinstance(item.layout(), QHBoxLayout):
                l = item.layout()
                has_header_label = False
                for j in range(l.count()):
                    w = l.itemAt(j).widget()
                    if w and w.objectName() == "carousel_header":
                        has_header_label = True
                        break
                if has_header_label:
                    l.setContentsMargins(0, 0, header_margin, 0)

    def _add_carousels(self, pub: Publication, base_url: str):
        belongs_to = pub.metadata.belongsTo if pub.metadata else pub.belongsTo
        if not belongs_to: return

        for rel_type in ["series", "collection"]:
            items = getattr(belongs_to, rel_type, []) or []
            for item in items:
                if not item.links: continue
                for link in item.links:
                    l_href = link.href
                    if not l_href: continue

                    label_text = item.name or rel_type.capitalize()

                    header = QHBoxLayout()
                    l_title = QLabel(label_text)
                    l_title.setObjectName("carousel_header")
                    header.addWidget(l_title)
                    header.addStretch()

                    full_href = urljoin(base_url, l_href)
                    label = "See All"
                    if item.numberOfItems:
                        label = f"See All ({item.numberOfItems})"
                        
                    btn_all = self.create_action_button(
                        label,
                        lambda _, u=full_href, t=label_text: self.on_navigate(u, t),
                        object_name="action_button"
                    )
                    header.addWidget(btn_all)
                    self.content_layout.insertLayout(self.content_layout.count() - 1, header)
                    
                    # Use a horizontal ribbon-style list view
                    view = FeedCardRibbon(self, self.image_manager, show_labels=True, card_size="small")
                    model = view.model()
                    model.cover_request_needed.connect(self._on_cover_request)
                    view.clicked.connect(self._on_carousel_clicked)
                    view.mini_detail_requested.connect(self._on_mini_detail_requested)
                    
                    self.content_layout.insertWidget(self.content_layout.count() - 1, view)
                    self.reapply_theme()
                    
                    asyncio.create_task(self._load_carousel_data(full_href, model))

    def _on_carousel_clicked(self, index):
        model = index.model()
        item = model.data(index, FeedBrowserModel.ItemDataRole)
        if item and item.raw_pub:
            self.on_open_detail(item.raw_pub, self._current_base_url)

    def _on_mini_detail_requested(self, item, index, view, model):
        """Show the metadata popover for a publication card in a carousel."""
        from comiccatcher.models.feed_page import ItemType
        if not item or item.type != ItemType.BOOK or not item.raw_pub:
            return

        pub = item.raw_pub
        
        # 1. Populate metadata using standardized helper (no thumbnail per requirement)
        ViewportHelper.enrich_popover_for_item(self.detail_popover, item, self._current_base_url)
        
        # 2. Add Actions (No select button in Detail view)
        self.detail_popover.clear_actions()
        
        # Details Action
        self.detail_popover.add_action("eye", "Details", 
                                      lambda: self.on_open_detail(pub, self._current_base_url))
        
        # Read Action (if readable)
        has_readable = any(getattr(link, 'rel', None) == "http://opds-spec.org/acquisition" and 
                          (getattr(link, 'type', '').startswith("application/epub+zip") or 
                           getattr(link, 'type', '').startswith("application/pdf") or
                           getattr(link, 'type', '').endswith("cbz") or 
                           getattr(link, 'type', '').endswith("cbr"))
                          for link in pub.links)
        if has_readable:
            self.detail_popover.add_action("book-open", "Read", 
                                          lambda: self.on_read(pub))

        # Download Action
        download_url = item.download_url
        if download_url:
            self.detail_popover.add_action("download", "Download", 
                                          lambda u=download_url: self.on_start_download(pub, u))

        # 3. Position and show using standardized helper
        ViewportHelper.position_popover(self.detail_popover, view, index)

        # 4. Trigger Enrichment (if applicable)
        if not hasattr(self, "_active_popover_load_id"):
            self._active_popover_load_id = None
            
        self._active_popover_load_id = ViewportHelper.trigger_manifest_enrichment(
            self.detail_popover,
            item,
            self.opds_client,
            self._current_base_url,
            lambda: self._active_popover_load_id
        )

    async def _load_carousel_data(self, url, model):
        try:
            feed = await self.opds_client.get_feed(url)
            
            # Use the carousel's own URL as the base for items in this section.
            # This follows OPDS spec where links are relative to the current document.
            feed_page = FeedReconciler.reconcile(feed, url)
            
            # Only show cards from the root-level publications
            items = []
            for section in feed_page.sections:
                if section.source_element == "root:publications":
                    items.extend(section.items)
            
            if not items:
                return

            model.update_total_count(len(items[:15]))
            model.set_items_for_page(1, items[:15])
            
            # Seed visibility check once data is in the model
            QTimer.singleShot(300, self.ensure_visible_covers)
            
        except OPDSClientError as e:
            logger.error(f"OPDS Carousel error for {url}: {e}")
        except Exception as e:
            logger.error(f"Unexpected carousel error: {e}")

    def keyPressEvent(self, event):
        if event.key() in (Keys.READ, Qt.Key.Key_Return, Qt.Key.Key_Enter):
            if hasattr(self, 'btn_read') and self.btn_read and self.btn_read.isEnabled():
                self.btn_read.click()
                return
        elif event.key() == Keys.DOWNLOAD:
            if hasattr(self, 'btn_download') and self.btn_download and self.btn_download.isEnabled():
                self.btn_download.click()
                return
        elif event.key() == Qt.Key.Key_H:
            self.toggle_help_popover()
            return
        super().keyPressEvent(event)

    def get_help_popover_title(self):
        return "Comic Details Controls"

    def get_help_popover_sections(self):
        sections = self.get_common_help_sections()
        sections.insert(0, ("DETAIL CONTROLS", [
            ("R / Enter", "Read this comic"),
            ("D", "Download this comic"),
            ("Arrows", "Scroll details"),
        ]))
        return sections
