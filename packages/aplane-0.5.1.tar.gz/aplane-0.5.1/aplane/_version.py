# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2026 APlane Developers

__version__ = "0.5.1"
