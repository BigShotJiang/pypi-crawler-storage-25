# Authors

Contributors to pyconverters_mineru include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
