# pyconverters_mineru

[![license](https://img.shields.io/github/license/oterrier/pyconverters_mineru)](https://github.com/oterrier/pyconverters_mineru/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyconverters_mineru/workflows/tests/badge.svg)](https://github.com/oterrier/pyconverters_mineru/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyconverters_mineru)](https://codecov.io/gh/oterrier/pyconverters_mineru)
[![docs](https://img.shields.io/readthedocs/pyconverters_mineru)](https://pyconverters_mineru.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyconverters_mineru)](https://pypi.org/project/pyconverters_mineru/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyconverters_mineru)](https://pypi.org/project/pyconverters_mineru/)

Convert PDF to structured text using [MinerU](https://github.com/kermitt2/mineru)

## Installation

You can simply `pip install pyconverters_mineru`.

## Developing

### Pre-requisites

You will need to install `uv` (for package management and building):

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyconverters_mineru
```

### Install dependencies

```
uv sync --extra test
```

### Running the test suite

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
