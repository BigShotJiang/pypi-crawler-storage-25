"use strict";(globalThis.rspackChunkesphome_frontend=globalThis.rspackChunkesphome_frontend||[]).push([[772],{8575(e,t,i){let o,a;i.r(t),i.d(t,{ESPHomePageDevice:()=>tS});var r=i(5172),n=i(9165),s=i(2009),l=i(3442),d=i(261),c=i(1248);class p{hostConnected(){}get deviceState(){return this._host.device?.state??c.gX.UNKNOWN}get deviceTargetPlatform(){return this._host.device?.target_platform??""}get deviceCurrentAddress(){return this._host.device?.ip||this._host.device?.address||""}_openCommand(e,t,i){let o=this._host.commandDialog;o&&(o.configuration=e.configuration,o.name=e.friendly_name||e.name,o.open(t,i?{port:i}:void 0))}constructor(e){this.installMethodOpen=!1,this.onInstall=()=>{this._host.device&&(this.installMethodOpen=!0,this._host.requestUpdate())},this.onUpdate=()=>{let e=this._host.device;e&&this._openCommand(e,"install")},this.onInstallMethodClose=()=>{this.installMethodOpen=!1,this._host.requestUpdate()},this.onInstallMethodSelect=e=>{let t=this._host.device;if(this.installMethodOpen=!1,this._host.requestUpdate(),!t)return;let{method:i,port:o}=e.detail;"ota"===i?this._openCommand(t,"install",o??"OTA"):"server-serial"===i?this._openCommand(t,"install",o):"web-serial"===i?this._host.firmwareDialog?.installWebSerial(t):"web-download"===i?this._host.firmwareDialog?.installWebDownload(t):"binary-download"===i&&this._host.firmwareDialog?.installBinaryDownload(t)},this._host=e,e.addController(this)}}var h=i(1556),u=i(3140),m=i(9460),g=i(3632),v=i(1529),f=i(2063);class b{run(e){return e.dirty?this._active?Promise.resolve(!1):new Promise(t=>{this._active={save:e.save,resolve:t},e.open()}):Promise.resolve(!0)}onDiscard(){let e=this._active;this._active=null,e?.resolve(!0)}async onSave(){let e=this._active;if(this._active=null,!e)return;let t=!1;try{t=await e.save()}catch{t=!1}e.resolve(t)}onCancel(){let e=this._active;this._active=null,e?.resolve(!1)}get isPending(){return null!==this._active}constructor(){this._active=null,this.cancelPending=this.onCancel}}var y=i(1093);let w=new Set(["esp32","esp8266","rp2040","bk72xx","rtl87xx","ln882x","nrf52","host","esphome","logger","api","ota","wifi","ethernet","mqtt","mdns","network","web_server","captive_portal","improv_serial","safe_mode","debug","preferences","update","external_components","packages","substitutions","dashboard_import","globals"]),_=new Set(["script","interval"]),x=new Set(["globals"]);function $(e){let t=[],i=[],o=[];for(let a of e)w.has(a.key)?t.push(a):_.has(a.key)?o.push(a):i.push(a);return{core:t,components:i,automations:o}}function k(e){return""===e.trim()||e.startsWith("#")}function z(e){if(o===e&&a)return a;let t=e.split("\n"),i=[];for(let e=0;e<t.length;e++){let o=t[e].match(/^([a-zA-Z_][a-zA-Z0-9_]*):/);if(o){if(i.length>0){let o=i[i.length-1],a=o.fromLine-1,r=e-1;for(;r>a&&k(t[r]);)r--;o.toLine=r+1}i.push({key:o[1],fromLine:e+1,toLine:t.length})}}if(i.length>0){let e=i[i.length-1],o=e.fromLine-1,a=t.length-1;for(a>=0&&""===t[a]&&a--;a>o&&k(t[a]);)a--;e.toLine=a+1}let r=[];for(let e of i)r.push(...function(e,t){if(x.has(t.key))return[{key:t.key,fromLine:t.fromLine,toLine:t.toLine}];let i=t.fromLine-1,o=t.toLine-1,a=[];for(let t=i+1;t<=o;t++)(/^  -\s/.test(e[t])||/^  -$/.test(e[t]))&&a.push(t);if(0===a.length){let a="",r="";for(let t=i+1;t<=o;t++){let i=e[t].match(/^\s{2}name:\s*["']?(.+?)["']?\s*$/);i&&(a=i[1]);let o=e[t].match(/^\s{2}id:\s*["']?(\S+?)["']?\s*$/);o&&(r=o[1])}return[{key:t.key,fromLine:t.fromLine,toLine:t.toLine,name:a||void 0,id:r||void 0}]}let r=[];for(let i=0;i<a.length;i++){let n=a[i],s=i+1<a.length?a[i+1]-1:o,l="",d="",c="";for(let t=n;t<=s;t++){let i=e[t].match(/^\s+(?:-\s+)?name:\s*["']?(.+?)["']?\s*$/);i&&(l=i[1]);let o=e[t].match(/^\s+(?:-\s+)?id:\s*["']?(\S+?)["']?\s*$/);o&&(d=o[1]);let a=e[t].match(/^\s+(?:-\s+)?platform:\s*["']?(\S+?)["']?\s*$/);a&&(c=a[1])}r.push({key:t.key,fromLine:n+1,toLine:s+1,name:l||void 0,id:d||void 0,platform:c||void 0,parentKey:t.key})}return r}(t,e));return o=e,a=r,r}function C(e){let t=e.split("\n"),i=[];for(let e=0;e<t.length;e++){let o=t[e].match(/^(\s+)(on_[a-zA-Z_]+):/);if(!o)continue;let a=o[1].length,r=o[2],n=e+1,s=t.length;for(let i=e+1;i<t.length;i++)if(""!==t[i].trim()&&(t[i].match(/^(\s*)/)??["",""])[1].length<=a){s=i;break}let l="";for(let i=e-1;i>=0&&!t[i].match(/^[a-zA-Z]/);i--){let e=t[i].match(/^\s+name:\s*["']?(.+?)["']?\s*$/);if(e){l=e[1];break}}i.push({key:l?`${l} → ${r}`:r,fromLine:n,toLine:s})}return i}function S(e,t){return z(e).find(e=>t>=e.fromLine&&t<=e.toLine)??null}function E(e){return e.platform?e.platform.startsWith(`${e.key}.`)?e.platform:`${e.key}.${e.platform}`:e.key}function q(e,t,i){if(!e||!t)return;let o=z(e).filter(e=>E(e)===t);if(0!==o.length)return 1===o.length||void 0===i?o[0].fromLine:o.reduce((e,t)=>Math.abs(t.fromLine-i)<Math.abs(e.fromLine-i)?t:e).fromLine}function L(e,t,i){if(void 0===t||!Number.isInteger(t)||t<1||null!==i||!e)return null;let o=S(e,t);return o?{sectionKey:E(o),range:{fromLine:t,toLine:t}}:null}let M=/line\s+(\d+)\s*,\s*column\s+(\d+)/i,A=/line\s+(\d+)/i,D=(0,s.AH)`
  :host {
    display: block;
  }

  .page {
    box-sizing: border-box;
    padding: var(--wa-space-l);
    min-height: calc(100vh - var(--esphome-header-height) - var(--esphome-footer-height));
  }

  .layout-grid {
    display: grid;
    grid-template-columns: minmax(230px, 1fr) minmax(0, 5fr);
    gap: var(--wa-space-l);
    height: calc(
      100vh - var(--esphome-header-height) - var(--esphome-footer-height) - 2 * var(--wa-space-l)
    );
    transition: grid-template-columns 0.25s ease;
  }

  .layout-grid.nav-collapsed {
    grid-template-columns: minmax(0, 5fr);
  }

  .layout-grid.nav-collapsed .desktop-nav {
    display: none;
  }

  .drawer,
  .drawer-backdrop {
    display: none;
  }

  .nav-toggle-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: none;
    background: color-mix(in srgb, var(--esphome-on-primary), transparent 80%);
    color: var(--esphome-on-primary);
    cursor: pointer;
    padding: 4px;
    border-radius: var(--wa-border-radius-m);
    margin-right: var(--wa-space-xs);
  }

  .nav-toggle-btn wa-icon {
    font-size: 14px;
  }

  .nav-toggle-btn:hover {
    background: color-mix(in srgb, var(--esphome-on-primary), transparent 70%);
  }

  @media (max-width: 900px) {
    /* Drop the page padding on mobile so the editor goes edge-to-edge.
       The card itself is already small at this width — wasting ~16px
       on each side to a frame just makes it harder to read; logs go
       full-screen the same way for the same reason.
       Each dvh line is paired with a vh fallback above it so
       pre-2022 browsers that don't recognise dvh still pick up the
       mobile sizing instead of dropping the declaration and falling
       through to the desktop rule (which had an extra
       2 * var(--wa-space-l) subtracted and would leave a gap). */
    .page {
      padding: 0;
      min-height: calc(100vh - var(--esphome-header-height) - var(--esphome-footer-height));
      min-height: calc(100dvh - var(--esphome-header-height) - var(--esphome-footer-height));
    }

    .layout-grid {
      grid-template-columns: 1fr;
      gap: 0;
      height: calc(100vh - var(--esphome-header-height) - var(--esphome-footer-height));
      height: calc(100dvh - var(--esphome-header-height) - var(--esphome-footer-height));
    }

    .desktop-nav {
      display: none !important;
    }

    .drawer-backdrop {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.4);
      z-index: 99;
    }

    .drawer-backdrop--open {
      display: block;
    }

    .drawer {
      display: block;
      position: fixed;
      top: 0;
      left: 0;
      bottom: 0;
      width: 300px;
      max-width: 85vw;
      z-index: 100;
      background: var(--wa-color-surface-default);
      box-shadow: var(--wa-shadow-l);
      overflow-y: auto;
      transform: translateX(-100%);
      transition: transform 0.25s ease;
      --navigator-border-radius: 0;
      --navigator-border: none;
    }

    .drawer--open {
      transform: translateX(0);
    }
  }
`;i(2202),i(9968);var P=i(9665);let O=(0,s.AH)`
  :host {
    display: contents;
  }

  /* Fullscreen mode covers the surrounding app shell (top bar,
     navigator, page padding). The card-header stays visible so the
     user keeps Save / layout / Collapse within reach — same shape as
     the logs dialog's expand mode. z-index sits above app chrome
     (which uses values up to ~50) but below modal dialogs (>=1000). */
  :host([fullscreen]) .card {
    position: fixed;
    inset: 0;
    z-index: 100;
    border: none;
    border-radius: 0;
    box-shadow: none;
  }

  .card {
    background: var(--wa-color-surface-default);
    border-radius: var(--wa-border-radius-l);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    box-shadow: var(--wa-elevation-02);
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }

  .card-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: var(--wa-space-s) var(--wa-space-m);
    background: var(--esphome-primary);
    color: var(--esphome-on-primary);
  }

  /* Navigator hidden + YAML-only layout = the title bar is the only
     non-editor chrome left on screen. Squeeze it so it gives the
     YAML editor back the vertical space the user already implicitly
     asked for by collapsing both panels. */
  .card-header--compact {
    padding: var(--wa-space-2xs) var(--wa-space-m);
  }

  .card-header--compact .editor-header-title {
    font-size: var(--wa-font-size-2xs);
  }

  .card-header--compact .layout-toggle wa-icon,
  .card-header--compact .diff-toggle wa-icon {
    font-size: 16px;
  }

  .editor-header-main {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
    flex: 1;
  }

  .editor-header-title {
    margin: 0;
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-bold);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .editor-floating-actions {
    position: absolute;
    bottom: var(--wa-space-m);
    right: var(--wa-space-m);
    z-index: 10;
    display: inline-flex;
    align-items: center;
    gap: var(--wa-space-s);
  }

  .save-button,
  .validate-button,
  .install-fab {
    display: inline-flex;
    align-items: center;
    box-sizing: border-box;
    gap: 3px;
    padding: 7px 14px;
    border: var(--wa-border-width-s) solid transparent;
    border-radius: var(--wa-border-radius-m);
    cursor: pointer;
    font-size: var(--wa-font-size-xs);
    font-weight: var(--wa-font-weight-bold);
    font-family: inherit;
    line-height: 1;
    transition:
      background 0.12s,
      border-color 0.12s,
      box-shadow 0.12s,
      transform 0.12s;
  }

  .save-button {
    background: var(--esphome-primary);
    color: var(--esphome-on-primary);
    box-shadow: 0 2px 8px color-mix(in srgb, var(--esphome-primary), transparent 50%);
  }

  .save-button:hover:not(:disabled) {
    background: color-mix(in srgb, var(--esphome-primary), black 10%);
    box-shadow: 0 4px 14px color-mix(in srgb, var(--esphome-primary), transparent 35%);
    transform: translateY(-1px);
  }

  .save-button:active:not(:disabled) {
    transform: translateY(0);
  }

  .save-button:disabled {
    background: color-mix(
      in srgb,
      var(--esphome-primary) 35%,
      var(--wa-color-surface-default)
    );
    color: color-mix(in srgb, var(--esphome-on-primary), transparent 30%);
    cursor: not-allowed;
    box-shadow: none;
    transform: none;
  }

  /* Subordinate to Save: surface-tinted variant so the primary
     action stays visually dominant. The disabled state (YAML buffer
     dirty) is the more common one — a bright primary button there
     would compete with Save for attention. */
  .validate-button {
    background: var(--wa-color-surface-default);
    color: var(--wa-color-text-normal);
    border-color: var(--wa-color-surface-border);
  }

  .validate-button:hover:not(:disabled) {
    background: var(--wa-color-surface-raised);
    border-color: color-mix(in srgb, var(--wa-color-text-normal), transparent 70%);
  }

  .validate-button:disabled {
    background: var(--wa-color-surface-default);
    color: color-mix(in srgb, var(--wa-color-text-normal), transparent 55%);
    border-color: var(--wa-color-surface-border);
    cursor: not-allowed;
  }

  .install-fab {
    background: color-mix(
      in srgb,
      var(--esphome-primary) 10%,
      var(--wa-color-surface-default)
    );
    color: var(--esphome-primary);
    border-color: color-mix(in srgb, var(--esphome-primary), transparent 70%);
  }

  .install-fab:hover:not(:disabled) {
    background: color-mix(
      in srgb,
      var(--esphome-primary) 18%,
      var(--wa-color-surface-default)
    );
    border-color: var(--esphome-primary);
  }

  .install-fab:disabled {
    background: var(--wa-color-surface-default);
    color: color-mix(in srgb, var(--esphome-primary), transparent 50%);
    border-color: var(--wa-color-surface-border);
    cursor: not-allowed;
  }

  .save-button wa-icon,
  .validate-button wa-icon,
  .install-fab wa-icon {
    font-size: 16px;
  }

  /* Tooltip carrier so the "why disabled" hint reaches mouse users
     even when the underlying button has the disabled attribute
     (which suppresses pointer events on the button itself). */
  .validate-button-wrap {
    display: inline-flex;
  }

  .header-actions {
    display: inline-flex;
    align-items: center;
    gap: var(--wa-space-s);
  }

  .diff-toggle {
    border: none;
    background: transparent;
    color: var(--esphome-on-primary);
    padding: 2px 4px;
    border-radius: 4px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }

  .diff-toggle[aria-pressed="true"] {
    background: color-mix(in srgb, var(--esphome-on-primary), transparent 85%);
  }

  .diff-toggle:disabled {
    opacity: 0.35;
    cursor: not-allowed;
  }

  .diff-toggle wa-icon {
    font-size: 18px;
  }

  .fullscreen-toggle {
    border: none;
    background: transparent;
    color: var(--esphome-on-primary);
    padding: 2px 4px;
    border-radius: 4px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }

  .fullscreen-toggle wa-icon {
    font-size: 18px;
  }

  .fullscreen-toggle:hover {
    background: color-mix(in srgb, var(--esphome-on-primary), transparent 85%);
  }

  .card-header--compact .fullscreen-toggle wa-icon {
    font-size: 16px;
  }

  .layout-toggle {
    display: inline-flex;
    align-items: center;
    gap: 2px;
  }

  .layout-toggle button {
    border: none;
    background: transparent;
    color: var(--esphome-on-primary);
    padding: 2px 4px;
    border-radius: 4px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }

  .layout-toggle button[aria-pressed="true"] {
    background: color-mix(in srgb, var(--esphome-on-primary), transparent 85%);
  }

  .layout-toggle button:disabled {
    opacity: 0.35;
    cursor: not-allowed;
  }

  .layout-toggle wa-icon {
    font-size: 18px;
  }

  .card-body {
    position: relative;
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }

  .editor-layout {
    flex: 1;
    min-height: 0;
    display: grid;
    gap: 0;
  }

  .editor-layout--both {
    grid-template-columns: 1fr 1px 1fr;
  }

  .editor-layout--left {
    grid-template-columns: 1fr;
  }

  .editor-layout--right {
    grid-template-columns: 1fr;
  }

  .editor-pane {
    padding: var(--wa-space-m);
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-s);
    min-height: 0;
    overflow: hidden;
  }

  .editor-pane--left {
    overflow-y: auto;
  }

  .editor-pane-title {
    margin: 0;
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-bold);
  }

  .editor-pane-body {
    flex: 1;
    overflow: hidden;
    display: flex;
    flex-direction: column;
  }

  .pane-divider {
    background: var(--wa-color-surface-border);
    width: 1px;
    align-self: stretch;
  }

  .editor-layout--left .editor-pane--right,
  .editor-layout--right .editor-pane--left {
    display: none;
  }

  @media (max-width: 900px) {
    .layout-toggle .split-btn {
      display: none;
    }

    /* Drop the card frame on mobile — the page wrapper already
       removes its padding so the editor occupies the full viewport.
       Border / border-radius / shadow at small widths just shave
       pixels off the editing area without adding any meaning. */
    .card {
      border: none;
      border-radius: 0;
      box-shadow: none;
    }
  }
`;function j(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}i(3238),i(1083);class T extends s.WF{render(){if(this._darkMode?this.setAttribute("dark",""):this.removeAttribute("dark"),this.oldValue===this.newValue)return(0,s.qy)`<div class="empty">${this._localize("device.diff_no_changes")}</div>`;let e=function(e,t){let i=e.split("\n"),o=t.split("\n"),a=i.length,r=o.length,n=[];for(let e=0;e<=a;e++)n.push(new Uint32Array(r+1));for(let e=1;e<=a;e++)for(let t=1;t<=r;t++)n[e][t]=i[e-1]===o[t-1]?n[e-1][t-1]+1:Math.max(n[e-1][t],n[e][t-1]);let s=[],l=a,d=r;for(;l>0||d>0;)l>0&&d>0&&i[l-1]===o[d-1]?(s.push({type:"context",oldLine:l,newLine:d,content:i[l-1]}),l--,d--):d>0&&(0===l||n[l][d-1]>=n[l-1][d])?(s.push({type:"add",newLine:d,content:o[d-1]}),d--):(s.push({type:"remove",oldLine:l,content:i[l-1]}),l--);return s.reverse()}(this.oldValue,this.newValue);return(0,s.qy)`
      <table>
        <tbody>
          ${e.map(e=>this._renderLine(e))}
        </tbody>
      </table>
    `}_renderLine(e){let t="add"===e.type?"+":"remove"===e.type?"-":" ",i="remove"===e.type?e.oldLine:e.newLine;return(0,s.qy)`
      <tr class=${e.type}>
        <td class="gutter">${i??(0,s.qy)`&nbsp;`}</td>
        <td class="marker">${t}</td>
        <td class="content">${e.content||s.s6}</td>
      </tr>
    `}constructor(...e){super(...e),this._darkMode=!1,this._localize=e=>e,this.oldValue="",this.newValue=""}}T.styles=(0,s.AH)`
    :host {
      display: block;
      flex: 1;
      min-height: 0;
      position: relative;
      overflow: auto;
      font-family: "JetBrains Mono", "Fira Code", monospace;
      font-size: 13px;
      line-height: 1.5;
      background: var(--diff-bg);
      color: var(--diff-fg);
      --diff-bg: #ffffff;
      --diff-fg: #1f2328;
      --diff-gutter-bg: #f6f8fa;
      --diff-gutter-fg: #6e7781;
      --diff-add-bg: #e6ffec;
      --diff-add-marker-bg: #abf2bc;
      --diff-add-fg: #1a7f37;
      --diff-remove-bg: #ffebe9;
      --diff-remove-marker-bg: #ffcecb;
      --diff-remove-fg: #cf222e;
      --diff-empty-fg: #8c959f;
    }

    :host([dark]) {
      --diff-bg: #0d1117;
      --diff-fg: #e6edf3;
      --diff-gutter-bg: #161b22;
      --diff-gutter-fg: #7d8590;
      --diff-add-bg: #033a16;
      --diff-add-marker-bg: #1a7f37;
      --diff-add-fg: #aff5b4;
      --diff-remove-bg: #67060c;
      --diff-remove-marker-bg: #b62324;
      --diff-remove-fg: #ffcecb;
      --diff-empty-fg: #6e7681;
    }

    .empty {
      padding: var(--wa-space-l);
      text-align: center;
      color: var(--diff-empty-fg);
      font-family: var(--wa-font-family-body);
      font-size: var(--wa-font-size-s);
    }

    table {
      border-collapse: collapse;
      width: 100%;
      table-layout: fixed;
    }

    tr {
      vertical-align: top;
    }

    .gutter {
      width: 1em;
      padding: 0 8px;
      padding-right: 14px;
      text-align: right;
      background: var(--diff-gutter-bg);
      color: var(--diff-gutter-fg);
      user-select: none;
      white-space: nowrap;
    }

    .marker {
      width: 1.5em;
      padding: 0 6px;
      text-align: center;
      user-select: none;
      font-weight: 600;
      border-right: 1px solid color-mix(in srgb, var(--diff-fg), transparent 90%);
    }

    .content {
      padding: 0 8px;
      white-space: pre-wrap;
      word-break: break-word;
      overflow-wrap: anywhere;
    }

    tr.add .marker,
    tr.add .content {
      background: var(--diff-add-bg);
      color: var(--diff-add-fg);
    }

    tr.add .marker {
      background: var(--diff-add-marker-bg);
    }

    tr.remove .marker,
    tr.remove .content {
      background: var(--diff-remove-bg);
      color: var(--diff-remove-fg);
    }

    tr.remove .marker {
      background: var(--diff-remove-marker-bg);
    }
  `,j([(0,r.Fg)({context:h.B6,subscribe:!0}),(0,l.wk)()],T.prototype,"_darkMode",void 0),j([(0,r.Fg)({context:h.$F,subscribe:!0}),(0,l.wk)()],T.prototype,"_localize",void 0),j([(0,l.MZ)()],T.prototype,"oldValue",void 0),j([(0,l.MZ)()],T.prototype,"newValue",void 0),T=j([(0,l.EM)("esphome-yaml-diff")],T);var F=i(6910);i(4636),i(7473);var I=i(5660);function R(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}i(3272),i(6117),(0,y.C)({close:n.mdiClose,"lightning-bolt":n.mdiLightningBolt,"target-variant":n.mdiTargetVariant,"play-circle-outline":n.mdiPlayCircleOutline});class N extends s.WF{open(){this._targetName="",this._triggerId="",this._actionId="",this._actionFields={},this._error="",this._dialog.open=!0,0===this._triggers.length&&this._loadCatalog()}async _loadCatalog(){this._loading=!0;try{this._triggers=[{id:"on_value",name:"On Value",description:"Triggered when the value changes",applicable_to:[],fields:[]},{id:"on_press",name:"On Press",description:"Triggered when a button is pressed",applicable_to:[],fields:[]},{id:"on_turn_on",name:"On Turn On",description:"Triggered when the component turns on",applicable_to:[],fields:[]},{id:"on_turn_off",name:"On Turn Off",description:"Triggered when the component turns off",applicable_to:[],fields:[]},{id:"on_boot",name:"On Boot",description:"Triggered when the device boots up",applicable_to:[],fields:[]},{id:"on_time",name:"On Time",description:"Triggered at a specific time interval",applicable_to:[],fields:[]}],this._actions=[{id:"toggle",name:"Toggle",description:"Toggle the component state",fields:[]},{id:"turn_on",name:"Turn On",description:"Turn the component on",fields:[]},{id:"turn_off",name:"Turn Off",description:"Turn the component off",fields:[]},{id:"logger.log",name:"Log Message",description:"Log a message to the console",fields:[{key:"message",label:"Message",type:"string",required:!0,default_value:"",hidden:!1,description:"",options:null,allow_custom_value:!1,range:null,display_format:null,unit_options:null,help_link:null,multi_value:!1,templatable:!1,locked:!1,suggestions:null,depends_on:null,depends_on_value:null,depends_on_value_not:null,depends_on_component:null,references_component:null,pin_features:[],pin_mode:null,advanced:!1,translation_key:null,translation_params:null,config_entries:null,platform_type:null}]},{id:"delay",name:"Delay",description:"Wait for a specified duration",fields:[{key:"delay",label:"Duration (ms)",type:"integer",required:!0,default_value:"1000",hidden:!1,description:"",options:null,allow_custom_value:!1,range:null,display_format:null,unit_options:null,help_link:null,multi_value:!1,templatable:!1,locked:!1,suggestions:null,depends_on:null,depends_on_value:null,depends_on_value_not:null,depends_on_component:null,references_component:null,pin_features:[],pin_mode:null,advanced:!1,translation_key:null,translation_params:null,config_entries:null,platform_type:null}]}],this._triggerId=this._triggers[0].id,this._actionId=this._actions[0].id}catch(e){console.error("Failed to load automation catalog:",e)}finally{this._loading=!1}}render(){return(0,s.qy)`
      <wa-dialog
        light-dismiss
        label=${this.boardName?this._localize("device.add_automation_dialog_title",{name:this.boardName}):this._localize("device.add_automation")}
      >
        ${this._loading?(0,s.qy)`
              <div class="loading">
                <wa-spinner></wa-spinner>
                ${this._localize("device.loading_automation_catalog")}
              </div>
            `:this._renderForm()}
      </wa-dialog>
    `}_renderForm(){let e=this._actions.find(e=>e.id===this._actionId),t=this._submitting;return(0,s.qy)`
      <div class="form">
        <!-- Target section -->
        <div class="section">
          <div class="section-header">
            <div class="section-icon section-icon--target">
              <wa-icon library="mdi" name="target-variant"></wa-icon>
            </div>
            <p class="section-title">${this._localize("device.automation_target")}</p>
          </div>
          <div class="field">
            <label>
              ${this._localize("device.automation_target_name")}<span class="required">*</span>
            </label>
            <input
              type="text"
              ?disabled=${t}
              .value=${this._targetName}
              placeholder=${this._localize("device.automation_target_placeholder")}
              @input=${e=>{this._targetName=e.target.value}}
            />
          </div>
        </div>

        <!-- Trigger section -->
        <div class="section">
          <div class="section-header">
            <div class="section-icon section-icon--trigger">
              <wa-icon library="mdi" name="lightning-bolt"></wa-icon>
            </div>
            <p class="section-title">${this._localize("device.automation_trigger")}</p>
          </div>
          <div class="field">
            <label>${this._localize("device.automation_trigger_label")}</label>
            <select
              ?disabled=${t}
              @change=${e=>{this._triggerId=e.target.value}}
            >
              ${0===this._triggers.length?(0,s.qy)`<option disabled selected>No triggers available</option>`:this._triggers.map(e=>(0,s.qy)`<option value=${e.id} ?selected=${e.id===this._triggerId}>${e.name}</option>`)}
            </select>
          </div>
        </div>

        <!-- Action section -->
        <div class="section">
          <div class="section-header">
            <div class="section-icon section-icon--action">
              <wa-icon library="mdi" name="play-circle-outline"></wa-icon>
            </div>
            <p class="section-title">${this._localize("device.automation_action")}</p>
          </div>
          <div class="field">
            <label>${this._localize("device.automation_action_label")}</label>
            <select
              ?disabled=${t}
              @change=${e=>{this._actionId=e.target.value,this._actionFields={}}}
            >
              ${0===this._actions.length?(0,s.qy)`<option disabled selected>No actions available</option>`:this._actions.map(e=>(0,s.qy)`<option value=${e.id} ?selected=${e.id===this._actionId}>${e.name}</option>`)}
            </select>
          </div>
          ${e?.fields.map(e=>this._renderActionField(e,t))??s.s6}
        </div>

        ${this._error?(0,s.qy)`<p class="error">${this._error}</p>`:s.s6}

        <div class="actions">
          <button
            class="dialog-btn dialog-btn--primary"
            ?disabled=${t||!this._targetName.trim()}
            @click=${this._onSubmit}
          >
            ${this._submitting?this._localize("device.adding"):this._localize("device.add_automation")}
          </button>
        </div>
      </div>
    `}_renderActionField(e,t){let i=this._actionFields[e.key]??String(e.default_value??"");return"select"===e.type&&e.options?(0,s.qy)`
        <div class="field">
          <label>${e.label}${e.required?(0,s.qy)`<span class="required">*</span>`:s.s6}</label>
          <select
            ?disabled=${t}
            @change=${t=>this._setActionField(e.key,t.target.value)}
          >
            ${e.options.map(e=>(0,s.qy)`<option value=${e.value} ?selected=${e.value===i}>${e.label}</option>`)}
          </select>
        </div>
      `:(0,s.qy)`
      <div class="field">
        <label>${e.label}${e.required?(0,s.qy)`<span class="required">*</span>`:s.s6}</label>
        <input
          type=${"integer"===e.type||"float"===e.type?"number":"text"}
          ?disabled=${t}
          .value=${i}
          placeholder=${String(e.default_value??"")}
          @input=${t=>this._setActionField(e.key,t.target.value)}
        />
      </div>
    `}_setActionField(e,t){this._actionFields={...this._actionFields,[e]:t}}async _onSubmit(){if(this.configuration&&!this._submitting&&this._targetName.trim()){this._submitting=!0,this._error="";try{throw Error(this._localize("device.add_automation_unavailable"))}catch(e){this._error=e instanceof Error?e.message:this._localize("device.add_automation_error")}finally{this._submitting=!1}}}constructor(...e){super(...e),this._localize=e=>e,this.boardName="",this.configuration="",this._triggers=[],this._actions=[],this._loading=!0,this._targetName="",this._triggerId="",this._actionId="",this._actionFields={},this._submitting=!1,this._error=""}}async function U(e,t){if(e._submitting)return;let i=e._selected;e._submitError="";let o=++e._depNavSeq,a=null;try{a=await e._api.getComponent(t,e.platform||void 0,e.board?.id??void 0)}catch{a=null}if(o===e._depNavSeq){if(i&&(e._returnTo=i,e._depDomain=t),a){e._selected=a;return}e._selected=null,await e.updateComplete,o===e._depNavSeq&&e._catalog?.filterByDomain(t)}}N.styles=[u.G,I.z,(0,s.AH)`
      wa-dialog {
        --width: 540px;
      }

      wa-dialog::part(header) {
        background: var(--esphome-primary);
        padding: 0 var(--wa-space-m);
        height: 40px;
        box-sizing: border-box;
      }

      wa-dialog::part(title) {
        color: var(--esphome-on-primary);
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
      }

      wa-dialog::part(close-button__base) {
        background: transparent;
        border: none;
        box-shadow: none;
        padding: 0;
        min-width: unset;
        min-height: unset;
        color: var(--esphome-on-primary);
        cursor: pointer;
      }

      wa-dialog::part(body) {
        padding: var(--wa-space-l);
      }

      wa-dialog::part(footer) {
        display: none;
      }

      /* ── Form ── */

      .form {
        display: flex;
        flex-direction: column;
        gap: var(--wa-space-s);
      }

      /* ── Section blocks ── */

      .section {
        display: flex;
        flex-direction: column;
        gap: 8px;
        padding: var(--wa-space-m);
        border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
        border-radius: var(--wa-border-radius-l);
        background: var(--wa-color-surface-raised);
      }

      .section-header {
        display: flex;
        align-items: center;
        gap: var(--wa-space-s);
        margin-bottom: 2px;
      }

      .section-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 28px;
        height: 28px;
        border-radius: var(--wa-border-radius-s);
        flex-shrink: 0;
      }

      .section-icon wa-icon {
        font-size: 16px;
      }

      .section-icon--target {
        background: color-mix(in srgb, var(--esphome-primary), transparent 85%);
        color: var(--esphome-primary);
      }

      .section-icon--trigger {
        background: color-mix(in srgb, var(--esphome-warning), transparent 85%);
        color: var(--esphome-warning);
      }

      .section-icon--action {
        background: color-mix(in srgb, var(--esphome-success), transparent 85%);
        color: var(--esphome-success);
      }

      .section-title {
        margin: 0;
        font-size: var(--wa-font-size-xs);
        font-weight: var(--wa-font-weight-bold);
        color: var(--wa-color-text-normal);
      }

      /* ── Fields ── */

      .field {
        display: flex;
        flex-direction: column;
        gap: 4px;
      }

      label {
        font-size: var(--wa-font-size-2xs);
        font-weight: var(--wa-font-weight-semibold);
        color: var(--wa-color-text-quiet);
      }

      label .required {
        color: var(--esphome-error);
        margin-left: 2px;
      }

      select {
        width: 100%;
        padding: 9px 14px;
        font-size: var(--wa-font-size-s);
        font-family: inherit;
        color: var(--wa-color-text-normal);
        background: var(--wa-color-surface-raised);
        border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
        border-radius: var(--wa-border-radius-l);
        box-sizing: border-box;
        outline: none;
        transition:
          border-color 0.15s,
          box-shadow 0.15s;
      }

      select:focus {
        border-color: var(--esphome-primary);
        box-shadow: 0 0 0 3px
          color-mix(in srgb, var(--esphome-primary), transparent 80%);
      }

      select {
        appearance: auto;
      }

      /* ── Actions ── */

      .actions {
        display: flex;
        justify-content: flex-end;
        gap: var(--wa-space-s);
        padding-top: var(--wa-space-m);
        border-top: 1px solid var(--wa-color-surface-border);
      }

      .dialog-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        padding: 8px 18px;
        border-radius: var(--wa-border-radius-m);
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
        font-family: inherit;
        cursor: pointer;
        border: none;
        transition:
          background 0.12s,
          opacity 0.12s;
      }

      .dialog-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }

      .dialog-btn--primary {
        background: var(--esphome-primary);
        color: var(--esphome-on-primary);
      }

      .dialog-btn--primary:hover:not(:disabled) {
        background: color-mix(in srgb, var(--esphome-primary), black 10%);
      }

      /* ── States ── */

      .error {
        color: var(--esphome-error);
        font-size: var(--wa-font-size-xs);
        background: color-mix(in srgb, var(--esphome-error), transparent 92%);
        padding: var(--wa-space-s) var(--wa-space-m);
        border-radius: var(--wa-border-radius-m);
      }

      .loading {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: var(--wa-space-m);
        padding: var(--wa-space-xl);
        color: var(--wa-color-text-quiet);
        font-size: var(--wa-font-size-s);
      }

      .loading wa-spinner {
        font-size: 24px;
        --indicator-color: var(--esphome-primary);
        --track-color: color-mix(
          in srgb,
          var(--esphome-primary),
          transparent 80%
        );
      }
    `],R([(0,r.Fg)({context:h.$F,subscribe:!0}),(0,l.wk)()],N.prototype,"_localize",void 0),R([(0,r.Fg)({context:h.Ie})],N.prototype,"_api",void 0),R([(0,l.MZ)()],N.prototype,"boardName",void 0),R([(0,l.MZ)()],N.prototype,"configuration",void 0),R([(0,l.P)("wa-dialog")],N.prototype,"_dialog",void 0),R([(0,l.wk)()],N.prototype,"_triggers",void 0),R([(0,l.wk)()],N.prototype,"_actions",void 0),R([(0,l.wk)()],N.prototype,"_loading",void 0),R([(0,l.wk)()],N.prototype,"_targetName",void 0),R([(0,l.wk)()],N.prototype,"_triggerId",void 0),R([(0,l.wk)()],N.prototype,"_actionId",void 0),R([(0,l.wk)()],N.prototype,"_actionFields",void 0),R([(0,l.wk)()],N.prototype,"_submitting",void 0),R([(0,l.wk)()],N.prototype,"_error",void 0),N=R([(0,l.EM)("esphome-add-automation-dialog")],N);var Z=i(4996);let B=(0,s.AH)`
  :host {
    display: flex;
    height: 480px;
    gap: 0;
  }

  :host([hidden]) {
    display: none;
  }

  .sidebar {
    width: 160px;
    flex-shrink: 0;
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-2xs);
    padding-right: var(--wa-space-m);
    border-right: 1px solid var(--wa-color-surface-border);
    overflow-y: auto;
  }

  .sidebar-label {
    font-size: var(--wa-font-size-xs);
    font-weight: var(--wa-font-weight-bold);
    color: var(--wa-color-text-subtle);
    text-transform: uppercase;
    letter-spacing: 0.06em;
    margin: 0 0 var(--wa-space-2xs);
    flex-shrink: 0;
  }

  .category-btn {
    border: none;
    background: none;
    cursor: pointer;
    text-align: left;
    padding: var(--wa-space-xs) var(--wa-space-s);
    border-radius: var(--wa-border-radius-m);
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-semibold);
    color: var(--wa-color-text-normal);
    transition: background 0.1s;
    font-family: inherit;
    flex-shrink: 0;
  }

  .category-btn:hover {
    background: color-mix(in srgb, var(--esphome-primary), transparent 88%);
    color: var(--esphome-primary);
  }

  .category-btn--active {
    background: color-mix(in srgb, var(--esphome-primary), transparent 88%);
    color: var(--esphome-primary);
  }

  .category-btn-inner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--wa-space-xs);
  }

  .category-count {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 18px;
    height: 18px;
    padding: 0 4px;
    border-radius: 9px;
    font-size: var(--wa-font-size-xs);
    font-weight: var(--wa-font-weight-bold);
    background: var(--wa-color-surface-raised);
    color: var(--wa-color-text-subtle);
    flex-shrink: 0;
    box-sizing: border-box;
  }

  .category-btn--active .category-count {
    background: var(--esphome-primary);
    color: var(--esphome-on-primary);
  }

  .main {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-m);
    padding-left: var(--wa-space-m);
    padding-top: 3px;
    padding-right: 3px;
    overflow: hidden;
  }

  input[type="search"] {
    flex-shrink: 0;
  }

  .result-count {
    font-size: var(--wa-font-size-2xs);
    color: var(--wa-color-text-quiet);
    flex-shrink: 0;
    margin-top: -6px;
  }

  .grid-scroll {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    padding-right: var(--wa-space-2xs);
  }

  /* auto-fill + minmax so the grid drops 2 → 1 column as soon as a card
     would shrink below ~340px — avoids hard viewport breakpoints. */
  .components-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
    gap: 8px;
    align-content: start;
  }

  /* Below ~600px (modal viewport on phones) collapse sidebar into a
     horizontal chip row above the grid. */
  @media (max-width: 600px) {
    :host {
      flex-direction: column;
      height: auto;
      max-height: 70vh;
    }

    .sidebar {
      width: 100%;
      flex-direction: row;
      gap: var(--wa-space-2xs);
      padding-right: 0;
      padding-bottom: var(--wa-space-s);
      margin-bottom: var(--wa-space-s);
      overflow-x: auto;
      overflow-y: hidden;
      border-right: none;
      border-bottom: 1px solid var(--wa-color-surface-border);
    }

    .sidebar-label {
      display: none;
    }

    .category-btn {
      flex-shrink: 0;
      white-space: nowrap;
    }

    .main {
      padding-left: 0;
      padding-right: 0;
    }
  }

  .component-card {
    border-radius: var(--wa-border-radius-l);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    background: var(--wa-color-surface-default);
    padding: var(--wa-space-s) var(--wa-space-m);
    box-sizing: border-box;
    min-width: 0;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    gap: 6px;
    cursor: pointer;
    transition: border-color var(--wa-transition-normal) var(--wa-transition-easing),
      background var(--wa-transition-normal) var(--wa-transition-easing);
  }

  .component-card:hover {
    border-color: var(--esphome-primary);
    background: color-mix(in srgb, var(--esphome-primary), transparent 96%);
  }

  .component-card:focus-within {
    border-color: var(--esphome-primary);
  }

  .component-card--expanded {
    grid-column: 1 / -1;
  }

  .expand-button {
    border: none;
    background: none;
    cursor: pointer;
    padding: 2px;
    border-radius: 4px;
    display: inline-flex;
    align-items: center;
    flex-shrink: 0;
    color: var(--esphome-primary);
    font-size: 15px;
  }

  .expand-button:focus-visible {
    outline: 2px solid var(--esphome-primary);
    outline-offset: 1px;
  }

  .expand-button wa-icon {
    transition: transform var(--wa-transition-normal) var(--wa-transition-easing);
  }

  .component-card-header {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .component-image,
  .component-image--placeholder {
    width: 56px;
    height: 56px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: var(--wa-border-radius-m);
    background: var(--wa-color-surface-subtle);
    flex-shrink: 0;
    color: var(--esphome-primary);
    font-size: 28px;
    box-sizing: border-box;
  }

  .component-image {
    padding: 4px;
  }

  .component-image img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }

  /* ESPHome's monochrome SVG illustrations are black-on-transparent —
     invert + hue-rotate in dark mode (apply-theme.ts root var). Scoped
     to SVGs so JPGs/PNGs keep their original colours. */
  .component-image img[src$=".svg"] {
    filter: var(--esphome-svg-filter, none);
  }

  .component-card-header-text {
    flex: 1;
    min-width: 0;
  }

  .component-title {
    margin: 0;
    font-size: var(--wa-font-size-xs);
    font-weight: var(--wa-font-weight-bold);
    color: var(--wa-color-text-normal);
    line-height: 1.3;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  /* Category chip disambiguates same-name catalog entries (sensor.debug
     vs text_sensor.debug). Only shown under "All" / "Featured" — see
     shouldShowCategoryChip. */
  .component-category-chip {
    display: inline-block;
    margin-top: 2px;
    padding: 0 6px;
    font-size: 9px;
    font-weight: var(--wa-font-weight-semibold);
    line-height: 1.6;
    color: var(--wa-color-text-quiet);
    background: var(--wa-color-surface-raised);
    border: 1px solid var(--wa-color-border);
    border-radius: 999px;
    text-transform: uppercase;
    letter-spacing: 0.04em;
  }

  .component-description {
    margin: 0;
    font-size: var(--wa-font-size-2xs);
    color: var(--wa-color-text-quiet);
    line-height: 1.4;
  }

  .component-description--clamp {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }

  .card-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--wa-space-xs);
    margin-top: auto;
  }

  .more-info {
    display: inline-flex;
    align-items: center;
    gap: 2px;
    font-size: var(--wa-font-size-2xs);
    color: var(--esphome-primary);
    text-decoration: none;
  }

  .more-info:hover {
    text-decoration: underline;
  }

  .more-info wa-icon {
    font-size: 11px;
  }

  .select-component {
    display: flex;
    align-items: center;
    gap: 3px;
    border: none;
    background: none;
    padding: 0;
    border-radius: 4px;
    font-family: inherit;
    font-size: var(--wa-font-size-2xs);
    font-weight: var(--wa-font-weight-bold);
    color: var(--esphome-primary);
    cursor: pointer;
  }

  .select-component:focus-visible {
    outline: 2px solid var(--esphome-primary);
    outline-offset: 3px;
  }

  .empty {
    text-align: center;
    color: var(--wa-color-text-quiet);
    font-size: var(--wa-font-size-s);
    padding: var(--wa-space-xl);
    grid-column: 1 / -1;
  }

  .loading {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--wa-color-text-quiet);
    font-size: var(--wa-font-size-s);
  }

  /* Featured cards get a subtle primary border so they read as the
     curated set, distinct from the regular catalog. */
  .component-card--featured {
    border-color: color-mix(in srgb, var(--esphome-primary), transparent 70%);
  }

  .bundle-badge {
    display: inline-flex;
    align-items: center;
    gap: 2px;
    font-size: var(--wa-font-size-2xs);
    font-weight: var(--wa-font-weight-bold);
    color: var(--esphome-primary);
    background: color-mix(in srgb, var(--esphome-primary), transparent 88%);
    border-radius: var(--wa-border-radius-s);
    padding: 1px 6px;
  }

  .bundle-badge wa-icon {
    font-size: 11px;
  }
`;var H=i(8851);let V=new Set(["adc","dac","ota"]);function Y(e){let t=e.target;return!t?.closest("a, button")}function K(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}(0,y.C)({"arrow-collapse-all":n.mdiArrowCollapseAll,"arrow-expand-all":n.mdiArrowExpandAll,memory:n.mdiMemory,"open-in-new":n.mdiOpenInNew,"package-variant-closed":n.mdiPackageVariantClosed,plus:n.mdiPlus});class W extends s.WF{load(){let e=(this.board?.featured_components?.length??0)+(this.board?.featured_bundles?.length??0);0===this.lockedCategories.length&&this.boardId&&e>0?this._category=c._w.FEATURED:this._category===c._w.FEATURED&&(this._category="all"),this._fetchComponents()}filterByDomain(e){Object.values(c._w).includes(e)?(this._search="",this._category=e):(this._search=e,this._category="all"),this._fetchComponents()}async _fetchComponents(){this._loading=!0;try{let e=this._search.trim()||void 0,t=this.lockedCategories.length>0,i=t?this.lockedCategories:"all"!==this._category?this._category:void 0,o=!t&&this.excludeCategories.length>0?this.excludeCategories:void 0,a=await this._api.getComponents({query:e,category:i,exclude_category:o,platform:this.platform||void 0,board_id:this.boardId||void 0,limit:50});this._components=a.components,this._categories=a.categories,this._total=a.total}catch(e){console.error("Failed to load component catalog:",e)}finally{this._loading=!1,this._initialLoad=!1}}render(){var e;let t,i,o,a,r,n,l,d,p,h,u,m,g,v,f;if(this._initialLoad&&this._loading)return(0,s.qy)`<div class="loading">
        ${this._localize("device.loading_components")}
      </div>`;let b=(e=this._localize,t=new Set(this.excludeCategories),o=(i=this._categories.filter(e=>!t.has(e.id))).find(e=>e.id===c._w.FEATURED),a=this.board?.featured_bundles?.length??0,r=o?o.count+a:a,n=i.filter(e=>e.id!==c._w.FEATURED),l=t.size?n.reduce((e,t)=>e+t.count,0):this._total,d=new Intl.Collator(void 0,{sensitivity:"base"}),p=n.map(t=>{let i=`device.component_category_${t.id}`,o=e(i);return{id:t.id,label:o!==i?o:t.name,count:t.count}}).sort((e,t)=>d.compare(e.label,t.label)),h=[],r>0&&h.push({id:c._w.FEATURED,label:e("device.component_category_featured"),count:r}),h.push({id:"all",label:e("device.component_category_all"),count:l}),h.push(...p),h),y=0===this.lockedCategories.length,w=this._category===c._w.FEATURED?(u=this.board?.featured_bundles??[],(m=this._search.trim().toLowerCase())?u.filter(e=>e.name.toLowerCase().includes(m)||e.description.toLowerCase().includes(m)||e.id.toLowerCase().includes(m)):u):[],_=(g=this.yaml?(0,H.Zn)(this.yaml):new Set,v=this.yaml?(0,H.u)(this.yaml):new Set,f=this.lockedCategories.length>0?new Set(this._components.map(e=>e.id)):null,this._components.filter(e=>{if(!e.multi_conf){if(e.id.includes(".")){if(v.has(e.id))return!1}else if(g.has(e.id))return!1}return(!(f&&e.id.includes("."))||!(e.dependencies.length>0)||!!e.dependencies.every(e=>f.has(e)||g.has(e)))&&!0}));return(0,s.qy)`
      ${y?(0,s.qy)`<div class="sidebar">
            <p class="sidebar-label">
              ${this._localize("device.component_categories")}
            </p>
            ${b.map(({id:e,label:t,count:i})=>(0,s.qy)`
                <button
                  class="category-btn ${this._category===e?"category-btn--active":""}"
                  type="button"
                  @click=${()=>{this._category=e,this._fetchComponents()}}
                >
                  <span class="category-btn-inner">
                    <span>${t}</span>
                    <span class="category-count">${i}</span>
                  </span>
                </button>
              `)}
          </div>`:s.s6}
      <div class="main">
        <input
          type="search"
          autocomplete="off"
          .value=${this._search}
          @input=${this._onSearchInput}
          placeholder=${this._localize("device.search_components_placeholder")}
        />
        ${!this._loading?(0,s.qy)`<span class="result-count"
              >${_.length+w.length} of
              ${this._total+w.length} components</span
            >`:""}
        <div class="grid-scroll">
          <div class="components-grid">
            ${this._loading?(0,s.qy)`<p class="empty">
                  ${this._localize("device.loading_components")}
                </p>`:_.length+w.length?(0,s.qy)`
                    ${w.map(e=>{var t;return t=this,(0,s.qy)`
    <article
      class="component-card component-card--featured"
      @click=${i=>{Y(i)&&t._onAddBundle(e)}}
    >
      <div class="component-card-header">
        <div class="component-image--placeholder">
          <wa-icon library="mdi" name="package-variant-closed"></wa-icon>
        </div>
        <div class="component-card-header-text">
          <h3 class="component-title">${e.name}</h3>
        </div>
        <span class="bundle-badge">
          <wa-icon library="mdi" name="package-variant-closed"></wa-icon>
          ${t._localize("device.featured_bundle_badge")}
        </span>
      </div>
      ${e.description?(0,s.qy)`<p class="component-description component-description--clamp">
            ${(0,F.G)(e.description)}
          </p>`:s.s6}
      <div class="card-footer">
        <span></span>
        <button
          class="select-component"
          type="button"
          @click=${()=>t._onAddBundle(e)}
        >
          <wa-icon library="mdi" name="plus"></wa-icon>
          ${t._localize("device.add_component_action")}
        </button>
      </div>
    </article>
  `})}
                    ${_.map(e=>{var t,i,o,a,r,n;let l,d;return t=this,i=e.id===this._expandedId,o=this._category===c._w.FEATURED,a=this._localize,l=!!e.image_url&&!t._imageFailed.has(e.id),d=("all"===(r=t._category)||"featured"===r)&&(n=e.category)?n.split("_").filter(e=>e.length>0).map(e=>V.has(e.toLowerCase())?e.toUpperCase():e[0].toUpperCase()+e.slice(1)).join(" "):"",(0,s.qy)`
    <article
      class="component-card ${i?"component-card--expanded":""} ${o?"component-card--featured":""}"
      @click=${i=>{Y(i)&&t._onAdd(e)}}
    >
      <div class="component-card-header">
        ${l?(0,s.qy)`<div class="component-image">
              <img
                src=${e.image_url}
                alt=${e.name}
                referrerpolicy="no-referrer"
                loading="lazy"
                @error=${()=>t._onImageError(e.id)}
              />
            </div>`:(0,s.qy)`<div class="component-image--placeholder">
              <wa-icon library="mdi" name="memory"></wa-icon>
            </div>`}
        <div class="component-card-header-text">
          <h3 class="component-title">${e.name}</h3>
          ${d?(0,s.qy)`<span class="component-category-chip">${d}</span>`:s.s6}
        </div>
        <button
          class="expand-button"
          type="button"
          aria-pressed=${i}
          title=${a("wizard.expand_board")}
          @click=${()=>t._onToggleExpand(e)}
        >
          <wa-icon
            library="mdi"
            name=${i?"arrow-collapse-all":"arrow-expand-all"}
          ></wa-icon>
        </button>
      </div>
      <p class="component-description ${i?"":"component-description--clamp"}">
        ${(0,F.G)(e.description)}
      </p>
      <div class="card-footer">
        <a class="more-info" href=${e.docs_url} target="_blank" rel="noreferrer">
          ${a("device.more_info")}
          <wa-icon library="mdi" name="open-in-new"></wa-icon>
        </a>
        <button
          class="select-component"
          type="button"
          @click=${()=>t._onAdd(e)}
        >
          <wa-icon library="mdi" name="plus"></wa-icon>
          ${a("device.add_component_action")}
        </button>
      </div>
    </article>
  `})}
                  `:(0,s.qy)`<p class="empty">
                    ${this._localize("device.no_components_found")}
                  </p>`}
          </div>
        </div>
      </div>
    `}_onToggleExpand(e){this._expandedId=this._expandedId===e.id?null:e.id}_onImageError(e){if(this._imageFailed.has(e))return;let t=new Set(this._imageFailed);t.add(e),this._imageFailed=t}_onAdd(e){this.dispatchEvent(new CustomEvent("add-component",{detail:{component:e},bubbles:!0,composed:!0}))}_onAddBundle(e){this.dispatchEvent(new CustomEvent("add-bundle",{detail:{bundle:e,boardId:this.boardId},bubbles:!0,composed:!0}))}constructor(...e){super(...e),this._localize=e=>e,this.platform="",this.boardId="",this.board=null,this.yaml="",this.lockedCategories=[],this.excludeCategories=[],this._components=[],this._categories=[],this._total=0,this._loading=!0,this._initialLoad=!0,this._search="",this._category="all",this._expandedId=null,this._imageFailed=new Set,this._debouncedSearch=(0,Z.s)(()=>this._fetchComponents(),300),this._onSearchInput=e=>{this._search=e.target.value,this._debouncedSearch()}}}W.styles=[u.G,I.z,B],K([(0,r.Fg)({context:h.$F,subscribe:!0}),(0,l.wk)()],W.prototype,"_localize",void 0),K([(0,r.Fg)({context:h.Ie})],W.prototype,"_api",void 0),K([(0,l.MZ)()],W.prototype,"platform",void 0),K([(0,l.MZ)({attribute:"board-id"})],W.prototype,"boardId",void 0),K([(0,l.MZ)({attribute:!1})],W.prototype,"board",void 0),K([(0,l.MZ)()],W.prototype,"yaml",void 0),K([(0,l.MZ)({attribute:!1})],W.prototype,"lockedCategories",void 0),K([(0,l.MZ)({attribute:!1})],W.prototype,"excludeCategories",void 0),K([(0,l.wk)()],W.prototype,"_components",void 0),K([(0,l.wk)()],W.prototype,"_categories",void 0),K([(0,l.wk)()],W.prototype,"_total",void 0),K([(0,l.wk)()],W.prototype,"_loading",void 0),K([(0,l.wk)()],W.prototype,"_initialLoad",void 0),K([(0,l.wk)()],W.prototype,"_search",void 0),K([(0,l.wk)()],W.prototype,"_category",void 0),K([(0,l.wk)()],W.prototype,"_expandedId",void 0),K([(0,l.wk)()],W.prototype,"_imageFailed",void 0),W=K([(0,l.EM)("esphome-component-catalog")],W);var G=i(5957),J=i(8175);let Q=(0,s.AH)`
  :host {
    display: block;
  }

  .form {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-m);
  }

  .form-desc {
    margin: 0 0 var(--wa-space-m);
    font-size: var(--wa-font-size-s);
    color: var(--wa-color-text-quiet);
  }

  .field {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-xs);
  }

  label {
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-bold);
    color: var(--wa-color-text-normal);
  }

  label .required {
    color: var(--esphome-error);
    margin-left: 2px;
  }

  select {
    width: 100%;
    padding: 9px 14px;
    font-size: var(--wa-font-size-s);
    font-family: inherit;
    color: var(--wa-color-text-normal);
    background: var(--wa-color-surface-raised);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    border-radius: var(--wa-border-radius-l);
    box-sizing: border-box;
    outline: none;
    transition:
      border-color 0.15s,
      box-shadow 0.15s;
  }

  select:focus {
    border-color: var(--esphome-primary);
    box-shadow: 0 0 0 3px
      color-mix(in srgb, var(--esphome-primary), transparent 80%);
  }

  select.invalid {
    border-color: var(--esphome-error);
  }

  select:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .field-error {
    color: var(--esphome-error);
    font-size: var(--wa-font-size-xs);
  }

  .array-row {
    display: flex;
    gap: var(--wa-space-xs);
  }

  .array-row input {
    flex: 1;
  }

  .array-btn {
    background: none;
    border: var(--wa-border-width-m) solid var(--wa-color-surface-border);
    border-radius: var(--wa-border-radius-m);
    padding: 0 var(--wa-space-s);
    cursor: pointer;
    font-family: inherit;
    color: var(--wa-color-text-normal);
  }

  .array-btn:hover:not(:disabled) {
    background: var(--wa-color-surface-lowered);
  }

  .array-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .yaml-preview {
    margin: 0;
    padding: var(--wa-space-s) var(--wa-space-m);
    background: var(--wa-color-surface-lowered);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    border-radius: var(--wa-border-radius-m);
    font-family: var(--wa-font-family-code, monospace);
    font-size: var(--wa-font-size-xs);
    white-space: pre;
    overflow-x: auto;
    color: var(--wa-color-text-normal);
  }

  .toggle-link {
    background: none;
    border: none;
    padding: 0;
    color: var(--esphome-primary);
    cursor: pointer;
    font-size: var(--wa-font-size-xs);
    text-decoration: underline;
    align-self: flex-start;
  }

  .actions {
    display: flex;
    justify-content: flex-end;
    gap: var(--wa-space-s);
    padding-top: var(--wa-space-m);
  }

  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 8px 18px;
    border-radius: var(--wa-border-radius-m);
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-bold);
    font-family: inherit;
    cursor: pointer;
    border: none;
    transition:
      background 0.12s,
      opacity 0.12s;
  }

  .btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .btn-secondary {
    background: var(--wa-color-surface-lowered);
    color: var(--wa-color-text-normal);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
  }

  .btn-secondary:hover:not(:disabled) {
    background: var(--wa-color-surface-border);
  }

  .btn-primary {
    background: var(--esphome-primary);
    color: var(--esphome-on-primary);
  }

  .btn-primary:hover:not(:disabled) {
    background: color-mix(in srgb, var(--esphome-primary), black 10%);
  }

  .error {
    color: var(--esphome-error);
    font-size: var(--wa-font-size-s);
  }
`,X=new Set(["name"]);function ee(e,t,i){let o=[];for(let a of e)if((0,G.VP)(a,t,i.presentComponents,i.targetPlatform)&&(!a.advanced||i.showAdvanced||function e(t,i){let o=i[t.key];if(t.type===c.Hh.NESTED)return t.multi_value?o instanceof H.ho||Array.isArray(o)&&o.length>0:!!(0,J.Qd)(o)&&(t.config_entries??[]).some(t=>e(t,o));return void 0!==o}(a,t))){if(a.type===c.Hh.NESTED){if(!a.multi_value&&0===ee(a.config_entries??[],(0,J.qY)(t[a.key]),i).length)continue}else if(i.requiredOnly&&!a.required&&!X.has(a.key))continue;o.push(a)}return o}function et(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}i(1062),i(986),i(3697),i(6135),(0,y.C)({close:n.mdiClose,magnify:n.mdiMagnify,palette:n.mdiPalette});let ei=null;function eo(e){return e?e.startsWith("mdi:")?e.slice(4):e:""}class ea extends s.WF{connectedCallback(){super.connectedCallback(),document.addEventListener("click",this._onDocumentClick,!0)}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("click",this._onDocumentClick,!0)}willUpdate(e){e.has("_open")&&this._escape.set(this._open),e.has("value")&&!this._loaded&&eo(this.value)&&this._ensureCatalogLoaded()}async _toggle(){this.disabled||(this._open?this._close():await this._openPanel())}async _openPanel(){this._open=!0,this.setAttribute("open",""),await this._ensureCatalogLoaded(),await this.updateComplete,this._searchInput?.focus()}async _ensureCatalogLoaded(){this._loaded||(this._catalog=await (ei||(ei=(async()=>{let e=await Promise.resolve().then(i.bind(i,9165)),t=[];for(let[i,o]of Object.entries(e)){if(!i.startsWith("mdi")||"string"!=typeof o)continue;let e=i.slice(3);if(!e)continue;let a=e.replace(/^[A-Z]/,e=>e.toLowerCase()).replace(/([A-Z])/g,"-$1").replace(/_/g,"-").toLowerCase();t.push({name:a,path:o})}return t.sort((e,t)=>e.name.localeCompare(t.name)),t})().catch(e=>(console.error("[mdi-icon-picker] failed to load catalog:",e),ei=null,[])))),this._loaded=!0)}_close(){this._open=!1,this.removeAttribute("open"),this._query=""}_select(e){let t=`mdi:${e}`;this.value=t,this.dispatchEvent(new CustomEvent("change",{detail:{value:t},bubbles:!0,composed:!0})),this._close()}_clear(e){e.stopPropagation(),this.value="",this.dispatchEvent(new CustomEvent("change",{detail:{value:""},bubbles:!0,composed:!0}))}_onSearchInput(e){this._query=e.target.value}_renderTriggerIcon(){let e=eo(this.value);if(!e)return(0,s.qy)`<span class="trigger-icon trigger-icon--empty">
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <path fill="currentColor" d=${n.mdiPalette}></path>
        </svg>
      </span>`;let t=this._catalog.find(t=>t.name===e);return t?(0,s.qy)`<span class="trigger-icon">
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <path fill="currentColor" d=${t.path}></path>
        </svg>
      </span>`:(0,s.qy)`<span class="trigger-icon">
      <wa-icon library="mdi" name=${e} style="font-size: 16px;"></wa-icon>
    </span>`}_renderPanel(){if(!this._loaded)return(0,s.qy)`<div class="panel" @click=${e=>e.stopPropagation()}>
        <div class="loading">Loading icons…</div>
      </div>`;let e=function(e,t){if(!t)return e.slice(0,400);let i=t.trim().toLowerCase().replace(/\s+/g,"-");if(!i)return e.slice(0,400);let o=[],a=[],r=[];for(let t of e)if(t.name===i?o.push(t):t.name.startsWith(i)?a.push(t):t.name.includes(i)&&r.push(t),o.length+a.length+r.length>=800)break;return[...o,...a,...r].slice(0,400)}(this._catalog,this._query),t=eo(this.value);return(0,s.qy)`
      <div class="panel" @click=${e=>e.stopPropagation()}>
        <div class="search">
          <svg class="search-icon" viewBox="0 0 24 24" aria-hidden="true">
            <path fill="currentColor" d=${n.mdiMagnify}></path>
          </svg>
          <input
            type="text"
            class="search-input"
            placeholder="Search ${this._catalog.length.toLocaleString()} icons…"
            .value=${this._query}
            @input=${this._onSearchInput}
            @keydown=${t=>{"Enter"===t.key&&e.length>0&&(t.preventDefault(),this._select(e[0].name))}}
          />
        </div>
        <div class="grid-wrap">
          ${0===e.length?(0,s.qy)`<div class="empty">
                <wa-icon library="mdi" name="magnify" style="font-size: 24px;"></wa-icon>
                No icons match “${this._query}”
              </div>`:(0,s.qy)`<div class="grid">
                ${e.map(e=>(0,s.qy)`
                    <button
                      type="button"
                      class=${e.name===t?"icon-cell icon-cell--selected":"icon-cell"}
                      title=${`mdi:${e.name}`}
                      @click=${()=>this._select(e.name)}
                    >
                      <svg viewBox="0 0 24 24" aria-hidden="true">
                        <path fill="currentColor" d=${e.path}></path>
                      </svg>
                    </button>
                  `)}
              </div>`}
        </div>
        <div class="footer">
          <span>
            ${0===e.length?"No matches":e.length>=400?`400+ of ${this._catalog.length.toLocaleString()}`:`${e.length} of ${this._catalog.length.toLocaleString()}`}
          </span>
          ${t?(0,s.qy)`<span class="footer-name">mdi:${t}</span>`:s.s6}
        </div>
      </div>
    `}render(){let e=eo(this.value),t=`trigger${this.invalid?" invalid":""}`;return(0,s.qy)`
      <button
        type="button"
        class=${t}
        ?disabled=${this.disabled}
        @click=${this._toggle}
      >
        ${this._renderTriggerIcon()}
        <span class=${e?"trigger-label":"trigger-label placeholder"}>
          ${e?`mdi:${e}`:this.placeholder}
        </span>
        ${e&&!this.disabled?(0,s.qy)`<span
              class="trigger-clear"
              role="button"
              tabindex="-1"
              title="Clear"
              @click=${this._clear}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true">
                <path fill="currentColor" d=${n.mdiClose}></path>
              </svg>
            </span>`:s.s6}
        <svg class="trigger-chevron" viewBox="0 0 24 24" aria-hidden="true">
          <path fill="currentColor" d="M7,10L12,15L17,10H7Z"></path>
        </svg>
      </button>
      ${this._open?this._renderPanel():s.s6}
    `}constructor(...e){super(...e),this.value="",this.placeholder="Choose an icon…",this.invalid=!1,this.disabled=!1,this._open=!1,this._catalog=[],this._query="",this._loaded=!1,this._escape=new P.u(this,e=>{e.stopPropagation(),this._close()},{target:document}),this._onDocumentClick=e=>{!this._open||e.composedPath().includes(this)||this._close()}}}ea.styles=[I.z,(0,s.AH)`
      :host {
        display: block;
        position: relative;
      }

      /* Trigger — shaped like the project's standard input */
      .trigger {
        width: 100%;
        box-sizing: border-box;
        min-height: var(--wa-form-control-height);
        padding: 0 14px;
        font-size: var(--wa-font-size-s);
        font-family: inherit;
        line-height: var(--wa-form-control-value-line-height);
        color: var(--wa-color-text-normal);
        background: var(--wa-color-surface-raised);
        border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
        border-radius: var(--wa-border-radius-m);
        outline: none;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 10px;
        text-align: left;
        transition:
          border-color 0.15s,
          box-shadow 0.15s;
      }

      .trigger:focus,
      :host([open]) .trigger {
        border-color: var(--esphome-primary);
        box-shadow: 0 0 0 3px
          color-mix(in srgb, var(--esphome-primary), transparent 80%);
      }

      .trigger.invalid {
        border-color: var(--esphome-error);
      }

      .trigger.invalid:focus {
        box-shadow: 0 0 0 3px
          color-mix(in srgb, var(--esphome-error), transparent 80%);
      }

      .trigger:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }

      .trigger-icon {
        width: 22px;
        height: 22px;
        flex: 0 0 22px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: var(--wa-border-radius-s);
        background: color-mix(in srgb, var(--esphome-primary), transparent 88%);
        color: var(--esphome-primary);
      }

      .trigger-icon svg {
        width: 16px;
        height: 16px;
      }

      .trigger-icon--empty {
        background: var(--wa-color-surface-lowered);
        color: var(--wa-color-text-quiet);
      }

      .trigger-label {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-family: var(--wa-font-family-code, monospace);
        font-size: var(--wa-font-size-s);
      }

      .trigger-label.placeholder {
        color: var(--wa-color-text-quiet);
        font-family: inherit;
      }

      .trigger-clear {
        background: none;
        border: none;
        padding: 4px;
        cursor: pointer;
        color: var(--wa-color-text-quiet);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: var(--wa-border-radius-s);
      }

      .trigger-clear:hover {
        background: var(--wa-color-surface-lowered);
        color: var(--wa-color-text-normal);
      }

      .trigger-chevron {
        width: 14px;
        height: 14px;
        color: var(--wa-color-text-quiet);
        flex: 0 0 14px;
        transition: transform 0.15s;
      }

      :host([open]) .trigger-chevron {
        transform: rotate(180deg);
      }

      /* Panel */
      .panel {
        position: absolute;
        top: calc(100% + 4px);
        left: 0;
        right: 0;
        z-index: 1000;
        display: flex;
        flex-direction: column;
        max-height: 380px;
        background: var(--wa-color-surface-raised);
        border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
        border-radius: var(--wa-border-radius-m);
        box-shadow:
          0 8px 24px rgba(0, 0, 0, 0.12),
          0 2px 6px rgba(0, 0, 0, 0.06);
        overflow: hidden;
        animation: panelIn 0.12s ease-out;
      }

      @keyframes panelIn {
        from {
          opacity: 0;
          transform: translateY(-4px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      .search {
        position: relative;
        padding: 10px 12px;
        border-bottom: var(--wa-border-width-s) solid var(--wa-color-surface-border);
      }

      .search-icon {
        position: absolute;
        left: 22px;
        top: 50%;
        transform: translateY(-50%);
        width: 14px;
        height: 14px;
        color: var(--wa-color-text-quiet);
        pointer-events: none;
      }

      .search-input {
        width: 100%;
        box-sizing: border-box;
        padding: 7px 10px 7px 32px !important;
        min-height: 32px !important;
        font-size: var(--wa-font-size-s);
      }

      .grid-wrap {
        flex: 1;
        overflow-y: auto;
        padding: 8px;
      }

      .grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(40px, 1fr));
        gap: 4px;
      }

      .icon-cell {
        position: relative;
        aspect-ratio: 1;
        background: none;
        border: 1px solid transparent;
        border-radius: var(--wa-border-radius-s);
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--wa-color-text-normal);
        padding: 0;
        transition:
          background 0.1s,
          border-color 0.1s,
          color 0.1s,
          transform 0.08s;
      }

      .icon-cell svg {
        width: 20px;
        height: 20px;
      }

      .icon-cell:hover {
        background: color-mix(in srgb, var(--esphome-primary), transparent 88%);
        color: var(--esphome-primary);
        border-color: color-mix(in srgb, var(--esphome-primary), transparent 70%);
        transform: scale(1.06);
      }

      .icon-cell--selected {
        background: var(--esphome-primary);
        color: var(--esphome-on-primary);
      }

      .icon-cell--selected:hover {
        background: var(--esphome-primary);
        color: var(--esphome-on-primary);
        transform: scale(1.06);
      }

      .empty,
      .loading {
        padding: 24px 16px;
        text-align: center;
        color: var(--wa-color-text-quiet);
        font-size: var(--wa-font-size-s);
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 8px;
      }

      .footer {
        padding: 6px 12px;
        border-top: var(--wa-border-width-s) solid var(--wa-color-surface-border);
        font-size: var(--wa-font-size-xs);
        color: var(--wa-color-text-quiet);
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      .footer-name {
        font-family: var(--wa-font-family-code, monospace);
        color: var(--wa-color-text-normal);
        font-size: var(--wa-font-size-xs);
      }
    `],et([(0,l.MZ)()],ea.prototype,"value",void 0),et([(0,l.MZ)()],ea.prototype,"placeholder",void 0),et([(0,l.MZ)({type:Boolean})],ea.prototype,"invalid",void 0),et([(0,l.MZ)({type:Boolean})],ea.prototype,"disabled",void 0),et([(0,l.wk)()],ea.prototype,"_open",void 0),et([(0,l.wk)()],ea.prototype,"_catalog",void 0),et([(0,l.wk)()],ea.prototype,"_query",void 0),et([(0,l.wk)()],ea.prototype,"_loaded",void 0),et([(0,l.P)(".search-input")],ea.prototype,"_searchInput",void 0),ea=et([(0,l.EM)("esphome-mdi-icon-picker")],ea),i(8944);let er=(0,s.AH)`
  :host {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-m);
  }

  .field {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-2xs);
  }

  .field-label {
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-semibold);
    color: var(--wa-color-text-normal);
    display: flex;
    align-items: center;
    gap: var(--wa-space-2xs);
  }

  .field-label .required {
    color: var(--esphome-error);
  }

  /* Indicator on featured-component fields the board has pinned to a
     fixed value. Sits next to the help-link icon. */
  .field-label .lock-icon {
    font-size: 13px;
    color: var(--wa-color-text-quiet);
  }

  .field-error {
    color: var(--esphome-error);
    font-size: var(--wa-font-size-2xs);
    margin-top: var(--wa-space-2xs);
  }

  .field-description {
    font-size: var(--wa-font-size-2xs);
    color: var(--wa-color-text-quiet);
    margin: 0;
  }

  .field-description + input,
  .field-description + textarea,
  .field-description + wa-select {
    margin-top: 8px;
  }

  /* Hint shown below a string/password input when the value is a
     !secret reference — clarifies that the field points into
     secrets.yaml instead of holding a literal value. */
  .secret-note {
    display: inline-flex;
    align-items: center;
    gap: var(--wa-space-2xs);
    margin-top: var(--wa-space-2xs);
    font-size: var(--wa-font-size-2xs);
    color: var(--wa-color-text-quiet);
  }

  .secret-note wa-icon {
    font-size: 14px;
    color: var(--esphome-primary);
  }

  .secret-note code {
    font-family: ui-monospace, "SF Mono", Menlo, Consolas, monospace;
    font-size: var(--wa-font-size-2xs);
    padding: 1px 4px;
    border-radius: var(--wa-border-radius-s);
    background: var(--wa-color-surface-lowered);
    color: var(--wa-color-text-normal);
  }

  .help-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: none;
    border: none;
    padding: 0;
    cursor: pointer;
    color: var(--wa-color-text-quiet);
    font-size: 16px;
    transition: color 0.12s;
    margin-left: auto;
  }

  .help-button:hover {
    color: var(--esphome-primary);
  }

  /* ─── Nested group ──────────────────────────────────────── */
  .nested-group {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-s);
    padding: var(--wa-space-s) var(--wa-space-m);
    background: var(--wa-color-surface-lowered);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    border-radius: var(--wa-border-radius-m);
  }

  .nested-header {
    display: flex;
    align-items: center;
    gap: var(--wa-space-2xs);
  }

  .nested-toggle {
    display: flex;
    flex: 1;
    min-width: 0;
    align-items: center;
    gap: var(--wa-space-2xs);
    background: none;
    border: none;
    padding: 0;
    font-family: inherit;
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-bold);
    color: var(--wa-color-text-normal);
    cursor: pointer;
    text-align: left;
  }

  .nested-desc {
    font-size: var(--wa-font-size-2xs);
    color: var(--wa-color-text-quiet);
    margin: 0;
  }

  .nested-toggle:hover {
    color: var(--esphome-primary);
  }

  .nested-toggle wa-icon {
    font-size: 18px;
  }

  .nested-title {
    flex: 1;
    min-width: 0;
    overflow-wrap: anywhere;
  }

  .nested-platform {
    font-size: var(--wa-font-size-2xs);
    font-weight: var(--wa-font-weight-normal);
    color: var(--wa-color-text-quiet);
    background: var(--wa-color-surface-default);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    border-radius: var(--wa-border-radius-s);
    padding: 1px 6px;
    margin-left: var(--wa-space-xs);
  }

  .nested-fields {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-m);
    padding-top: var(--wa-space-xs);
  }

  /* ─── nested list (repeatable nested mapping) ───────────── */
  .nested-list {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-s);
  }

  .nested-list-item {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-xs);
    padding: var(--wa-space-s) var(--wa-space-m);
    background: var(--wa-color-surface-lowered);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    border-radius: var(--wa-border-radius-m);
  }

  .nested-list-item-header {
    display: flex;
    align-items: center;
    gap: var(--wa-space-2xs);
  }

  .nested-list-item-title {
    flex: 1;
    min-width: 0;
    overflow-wrap: anywhere;
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-bold);
    color: var(--wa-color-text-normal);
  }

  /* ─── multi-value rows ──────────────────────────────────── */
  .multi-row {
    display: flex;
    align-items: center;
    gap: var(--wa-space-2xs);
  }

  .multi-row .multi-input {
    flex: 1;
    font-family: inherit;
    font-size: var(--wa-font-size-s);
    padding: 6px 12px;
    border-radius: var(--wa-border-radius-m);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    background: var(--wa-color-surface-default);
    color: var(--wa-color-text-normal);
    outline: none;
    box-sizing: border-box;
    transition:
      border-color 0.12s,
      box-shadow 0.12s;
  }

  .multi-row .multi-input:focus {
    border-color: var(--esphome-primary);
    box-shadow: 0 0 0 3px color-mix(in srgb, var(--esphome-primary), transparent 80%);
  }

  .multi-row .multi-input.invalid {
    border-color: var(--esphome-error);
  }

  .multi-row .multi-input:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .combobox-input {
    font-family: inherit;
    font-size: var(--wa-font-size-s);
    padding: 6px 12px;
    border-radius: var(--wa-border-radius-m);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    background: var(--wa-color-surface-default);
    color: var(--wa-color-text-normal);
    outline: none;
    box-sizing: border-box;
    transition:
      border-color 0.12s,
      box-shadow 0.12s;
  }

  .combobox-input:focus {
    border-color: var(--esphome-primary);
    box-shadow: 0 0 0 3px color-mix(in srgb, var(--esphome-primary), transparent 80%);
  }

  .combobox-input.invalid {
    border-color: var(--esphome-error);
  }

  .combobox-input:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .multi-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
    padding: 4px 10px;
    background: transparent;
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    border-radius: var(--wa-border-radius-m);
    color: var(--wa-color-text-quiet);
    font-family: inherit;
    font-size: var(--wa-font-size-xs);
    cursor: pointer;
    transition:
      background 0.12s,
      border-color 0.12s,
      color 0.12s;
  }

  .multi-btn:hover {
    background: var(--wa-color-surface-lowered);
    color: var(--wa-color-text-normal);
  }

  .multi-btn wa-icon {
    font-size: 14px;
  }

  .multi-add {
    align-self: flex-start;
    margin-top: var(--wa-space-2xs);
  }

  /* ─── Map (key/value) rows ──────────────────────────────── */
  .map-row {
    display: flex;
    align-items: flex-start;
    gap: var(--wa-space-2xs);
  }

  .map-row .map-key-input {
    flex: 1;
    min-width: 0;
  }

  .map-row .map-value {
    flex: 1.5;
    min-width: 0;
  }

  /* Inside a map row the value's label and description are
     redundant (the map itself has those at the top) — suppress
     them so each row stays compact. */
  .map-row .map-value > .field > label,
  .map-row .map-value > .field > p.field-description {
    display: none;
  }

  .map-row .map-value > .field {
    gap: 0;
  }

  /* "Complex value — edit in YAML" placeholder for map rows whose
     value isn't a primitive (lists / dicts can't round-trip through
     a single text input). Quiet, italic, padded to vertically
     match the size of a wa-input so the row alignment is preserved. */
  .map-row .map-value-yaml-only {
    margin: 0;
    padding: var(--wa-space-2xs) var(--wa-space-s);
    color: var(--wa-color-text-quiet);
    font-style: italic;
    font-size: var(--wa-font-size-s);
    line-height: var(--wa-form-control-line-height, 1.5);
  }

  /* Per-entry render-error tile. A renderer that throws (or
     receives a malformed entry shape) would otherwise leave a
     silent gap in the form — the user can't tell whether their
     data is gone or the form just doesn't show that field. The
     tile makes the failure visible with the entry's key/type
     and the error message so a user can report the problem
     instead of silently losing their work. */
  .render-error {
    display: flex;
    gap: var(--wa-space-s);
    align-items: flex-start;
    padding: var(--wa-space-s);
    border: 1px solid var(--wa-color-danger-fill-loud, currentColor);
    border-radius: var(--wa-border-radius-m);
    background: var(--wa-color-danger-fill-quiet, transparent);
    color: var(--wa-color-danger-on-quiet, currentColor);
  }
  .render-error wa-icon {
    flex-shrink: 0;
    margin-top: 2px;
  }
  .render-error > div {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-2xs);
    min-width: 0;
  }
  .render-error-key {
    font-family: ui-monospace, "SF Mono", Menlo, Consolas, monospace;
    font-size: var(--wa-font-size-xs);
    opacity: 0.85;
  }
  .render-error-message {
    margin: 0;
    font-family: ui-monospace, "SF Mono", Menlo, Consolas, monospace;
    font-size: var(--wa-font-size-xs);
    white-space: pre-wrap;
    word-break: break-word;
  }

  .textarea-field {
    font-family: ui-monospace, "SF Mono", Menlo, Consolas, monospace;
    font-size: var(--wa-font-size-xs);
    padding: var(--wa-space-s);
    border-radius: var(--wa-border-radius-m);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    background: var(--wa-color-surface-default);
    color: var(--wa-color-text-normal);
    resize: vertical;
    min-height: 80px;
  }

  .textarea-field.invalid {
    border-color: var(--esphome-error);
  }

  /* ─── Pin selector option layout ─────────────────────────── */
  .pin-option-stack {
    display: inline-flex;
    flex-direction: column;
    gap: 1px;
    line-height: 1.25;
  }

  .pin-option-primary {
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-semibold);
    color: var(--wa-color-text-normal);
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }

  .pin-option-secondary {
    font-size: var(--wa-font-size-2xs);
    color: var(--wa-color-text-quiet);
    font-style: italic;
  }

  .pin-option[disabled] .pin-option-primary,
  .pin-option[disabled] .pin-option-secondary {
    color: var(--wa-color-text-quiet);
  }

  .pin-warn-icon {
    color: var(--esphome-warning, #d97706);
    font-size: 14px;
    flex-shrink: 0;
  }

  .pin-option--warn .pin-option-secondary {
    color: var(--esphome-warning, #d97706);
    font-style: normal;
  }

  /* ─── Pin "Advanced" disclosure (long-form fields) ──────── */
  /* Compact toggle that opens the long-form pin fields (mode
     flags, inverted) attached by the catalog's
     _pin_long_form_extras helper. Visually subordinate to the
     primary GPIO picker — the user has to opt in to the
     advanced fields per pin. */
  .pin-advanced {
    margin-top: var(--wa-space-2xs);
  }

  .pin-advanced-toggle {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    background: none;
    border: none;
    padding: 2px 0;
    color: var(--wa-color-text-quiet);
    font-size: var(--wa-font-size-2xs);
    cursor: pointer;
  }

  .pin-advanced-toggle:hover {
    color: var(--wa-color-text-normal);
  }

  .pin-advanced-fields {
    margin-top: var(--wa-space-xs);
    padding-left: var(--wa-space-s);
    border-left: 2px solid var(--wa-color-surface-border);
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-s);
  }

  /* ─── ID reference picker option layout ──────────────────── */
  .id-option-stack {
    display: inline-flex;
    flex-direction: column;
    gap: 1px;
    line-height: 1.25;
  }

  /* Visually distinguish the "Add new …" entry at the bottom of
     the dropdown — same pattern as Home Assistant's entity
     pickers. Coloured to read as an action, not a value. */
  .id-option-add {
    border-top: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    margin-top: var(--wa-space-2xs);
  }

  .id-option-add--solo {
    border-top: none;
    margin-top: 0;
  }

  .id-option-primary-add {
    color: var(--esphome-primary);
    font-weight: var(--wa-font-weight-bold);
  }

  .id-option-primary-add wa-icon {
    font-size: 14px;
  }

  .id-option-primary {
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-semibold);
    color: var(--wa-color-text-normal);
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }

  .id-option-secondary {
    font-size: var(--wa-font-size-2xs);
    color: var(--wa-color-text-quiet);
    font-style: italic;
  }

  .alert-entry {
    padding: var(--wa-space-s) var(--wa-space-m);
    background: var(--wa-color-surface-lowered);
    border-radius: var(--wa-border-radius-m);
    font-size: var(--wa-font-size-xs);
    color: var(--wa-color-text-quiet);
    line-height: 1.5;
  }

  .label-entry {
    font-size: var(--wa-font-size-xs);
    color: var(--wa-color-text-subtle);
    font-style: italic;
  }

  .switch-field {
    display: grid;
    grid-template-columns: 1fr auto;
    column-gap: var(--wa-space-m);
    row-gap: var(--wa-space-2xs);
    align-items: center;
  }

  .switch-field .field-info {
    grid-column: 1;
    grid-row: 1 / span 2;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .switch-field > .help-button {
    grid-column: 2;
    grid-row: 1;
    margin-left: 0;
    align-self: start;
  }

  .switch-field > wa-switch {
    grid-column: 2;
    grid-row: 2;
    justify-self: end;
  }

  .switch-field:not(:has(> .help-button)) > wa-switch {
    grid-row: 1 / span 2;
  }

  wa-select {
    width: 100%;
  }

  .float-with-unit-inputs {
    display: flex;
    align-items: center;
    gap: var(--wa-space-s);
  }

  .float-with-unit-inputs > input[type="number"] {
    flex: 1 1 auto;
    min-width: 0;
  }

  .float-with-unit-inputs > wa-select {
    flex: 0 0 auto;
    width: auto;
    min-width: 6rem;
  }

  .float-with-unit-suffix {
    flex: 0 0 auto;
    color: var(--wa-color-text-subtle);
    font-size: var(--wa-font-size-s);
  }
`;var en=i(2748);function es(e,t){return t.disabled||e.locked}(0,y.C)({"key-variant":n.mdiKeyVariant,"lock-outline":n.mdiLockOutline});let el=/^!secret\s+(\S+)\s*$/;function ed(e,t){let i=e.match(el);return i?(0,s.qy)`<span class="secret-note">
    <wa-icon library="mdi" name="key-variant"></wa-icon>
    <span>${t.localize("device.value_from_secret")}</span>
    <code>${i[1]}</code>
  </span>`:s.s6}function ec(e,t){if(e.translation_key){let i=e.translation_params||void 0,o=t(e.translation_key,i);if(o&&o!==e.translation_key)return o}return e.label?e.label:e.key.split("_").map(e=>e?e[0].toUpperCase()+e.slice(1):e).join(" ")}function ep(e,t){return ec(e,t.localize)}function eh(e,t){return e.help_link?(0,s.qy)`<a
    class="help-button"
    href=${e.help_link}
    target="_blank"
    rel="noreferrer"
    title=${t.localize("device.docs")}
  >
    <wa-icon library="mdi" name="open-in-new"></wa-icon>
  </a>`:s.s6}function eu(e,t,i={}){let{includeHelpLink:o=!0}=i;return(0,s.qy)`
    <label class="field-label">
      ${ep(e,t)}
      ${e.required?(0,s.qy)`<span class="required">*</span>`:s.s6}
      ${e.locked?(0,s.qy)`<wa-icon
            class="lock-icon"
            library="mdi"
            name="lock-outline"
            title=${t.localize("device.field_locked_by_board")}
          ></wa-icon>`:s.s6}
      ${o&&e.help_link?eh(e,t):s.s6}
    </label>
    ${e.description?(0,s.qy)`<p class="field-description">
          ${(0,F.G)(e.description)}
        </p>`:s.s6}
  `}function em(e,t){let i=t.errorAt(e);return(0,en.O)(i?t.localize(i.code,i.params):void 0)}function eg(e,t,i,o,a=s.s6){return(0,s.qy)`
    <div class="field" data-field-key=${t.join(".")}>
      ${eu(e,i)} ${o} ${a}
      ${em(t,i)}
    </div>
  `}function ev(e,t,i,o){var a,r,n,l,d,p;let h,u,m,g=String(o.getAt(i)??""),v=null!==o.errorAt(i),f=String(e.default_value??""),b=es(e,o);return e.suggestions&&e.suggestions.length>0?(a=e,r=i,n=g,l=v,d=b,p=o,h=n.toLowerCase(),u=String(a.default_value??""),m=a.type===c.Hh.INTEGER||a.type===c.Hh.FLOAT,(0,s.qy)`
    <div class="field" data-field-key=${r.join(".")}>
      ${eu(a,p)}
      <wa-select
        class=${l?"invalid":""}
        ?disabled=${d}
        placeholder=${u}
        @change=${e=>p.emitChange(r,(e=>{if(!m||""===e)return e;let t=a.type===c.Hh.INTEGER?parseInt(e,10):Number(e);return Number.isFinite(t)?t:e})(e.target.value))}
      >
        ${(a.suggestions??[]).map(e=>{let t=String(e);return(0,s.qy)`<wa-option
            value=${t}
            ?selected=${t.toLowerCase()===h}
            >${t}</wa-option
          >`})}
      </wa-select>
      ${em(r,p)}
    </div>
  `):"password"===t?(0,s.qy)`
      <div class="field" data-field-key=${i.join(".")}>
        ${eu(e,o)}
        <esphome-password-input
          .value=${g}
          .invalid=${v}
          .disabled=${b}
          .placeholder=${f}
          @password-input-change=${e=>o.emitChange(i,e.detail.value)}
        ></esphome-password-input>
        ${ed(g,o)} ${em(i,o)}
      </div>
    `:(0,s.qy)`
    <div class="field" data-field-key=${i.join(".")}>
      ${eu(e,o)}
      <input
        type=${t}
        class=${v?"invalid":""}
        .value=${g}
        ?disabled=${b}
        placeholder=${f}
        @input=${e=>o.emitChange(i,e.target.value)}
      />
      ${ed(g,o)} ${em(i,o)}
    </div>
  `}function ef(e){let t,i;return{get(o){if(void 0!==t&&e(o,t))return i},set(e,o){t=e,i=o},clear(){t=void 0,i=void 0}}}let eb=ef((e,t)=>e.yaml===t.yaml&&e.excludeFromLine===t.excludeFromLine&&e.excludeToLine===t.excludeToLine),ey=ef((e,t)=>e.yaml===t.yaml&&e.domain===t.domain),ew="__esphome_add_new__";function e_(e){if("number"==typeof e&&Number.isFinite(e))return e;if("string"==typeof e){let t=e.match(/^\s*(?:GPIO)?(\d+)\s*$/i);if(t)return Number(t[1])}return null===e||"object"!=typeof e||Array.isArray(e)?null:e_(e.number)}var ex=i(2477),e$=i(7169);function ek(e){let t,i=e.trim();if(""===i)return null;if(/^0[xX][0-9a-fA-F]+$/.test(i))t=Number.parseInt(i.slice(2),16);else{if(!/^-?\d+$/.test(i))return null;t=Number.parseInt(i,10)}return Number.isFinite(t)?t:null}function ez(e){let t;if(null==e||""===e)return"";if("number"==typeof e)t=e;else{if("string"!=typeof e)return"";t=ek(e)}return null!==t&&Number.isFinite(t)&&Number.isInteger(t)&&!(t<0)?"0x"+t.toString(16):""}function eC(e){return null==e||""===e?"":ez(e)||String(e)}function eS(e,t){let i=e.getAt(t);return Array.isArray(i)?i:[]}function eE(e,t,i){return{addItem:()=>e.emitChange(t,[...eS(e,t),i()]),removeAt:i=>e.emitChange(t,eS(e,t).filter((e,t)=>t!==i))}}function eq(e,t){return 0===e.length?(0,s.qy)`<p class="field-description">
        ${t.localize("device.multi_value_empty")}
      </p>`:s.s6}function eL(e,t,i){return(0,s.qy)`
    <button
      type="button"
      class="multi-btn"
      ?disabled=${t}
      aria-label=${e.localize("device.multi_value_remove")}
      @click=${i}
    >
      <wa-icon library="mdi" name="close"></wa-icon>
    </button>
  `}function eM(e,t,i){return(0,s.qy)`
    <button
      type="button"
      class="multi-btn multi-add"
      ?disabled=${t}
      @click=${i}
    >
      <wa-icon library="mdi" name="plus"></wa-icon>
      ${e.localize("device.multi_value_add")}
    </button>
  `}function eA(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}(0,y.C)({"alert-circle-outline":n.mdiAlertCircleOutline,"chevron-down":n.mdiChevronDown,"chevron-up":n.mdiChevronUp,close:n.mdiClose,"open-in-new":n.mdiOpenInNew,plus:n.mdiPlus});class eD extends s.WF{render(){let e=this._buildCtx(),t=this._filterRenderable(this.entries,this.values);return(0,s.qy)`${t.map(t=>this._renderEntry(t,t.key?[t.key]:[],e))}`}willUpdate(e){e.has("entries")&&void 0!==e.get("entries")&&(this._pendingUnits.clear(),this._editingMagnitudes.clear())}updated(e){super.updated(e),this._syncSelectValues()}async _syncSelectValues(){if(this.shadowRoot)for(let e of this.shadowRoot.querySelectorAll("[data-field-key]")){let t=e.querySelector("wa-select");if(!t)continue;if(t.hasAttribute("data-no-value-sync")){await this._syncSelectedAttr(t);continue}if(t.updateComplete)try{await t.updateComplete}catch{}let i=e.getAttribute("data-field-key");if(!i)continue;let o=i.split("."),a=(0,J.O6)(this.values,o);if(!(0,J.k4)(a)){""!==(Array.isArray(t.value)?t.value[0]??"":t.value??"")&&(t.value="");continue}let r=String(a??""),n=Array.from(t.querySelectorAll("wa-option")),s=r.match(/^\s*(?:GPIO)?(\d+)\s*$/i)?.[1],l=e=>n.find(t=>t.value?.toLowerCase()===e.toLowerCase()),d=r?l(r)??(s?l(`GPIO${s}`):void 0):null,c=d?.value??r;(Array.isArray(t.value)?t.value[0]??"":t.value??"")!==c&&(t.value=c)}}async _syncSelectedAttr(e){if(e.updateComplete)try{await e.updateComplete}catch{}let t=e.querySelector("wa-option[selected]"),i=t?.value??"";i&&(Array.isArray(e.value)?e.value[0]??"":e.value??"")!==i&&(e.value=i)}_renderEntry(e,t,i){try{return this._renderEntryUnsafe(e,t,i)}catch(o){console.error("esphome-config-entry-form: render failed for entry",{key:e.key,type:e.type,path:t},o);let i=o instanceof Error?o.message:String(o);return(0,s.qy)`<div class="render-error" role="alert">
        <wa-icon library="mdi" name="alert-circle-outline"></wa-icon>
        <div>
          <strong>
            ${this._localize("device.entry_render_error_title")}
          </strong>
          <code class="render-error-key"
            >${e.key||"(empty key)"} · ${e.type}</code
          >
          <pre class="render-error-message">${i}</pre>
        </div>
      </div>`}}_renderEntryUnsafe(e,t,i){if(e.type===c.Hh.DIVIDER)return(0,s.qy)`<wa-divider></wa-divider>`;if(e.type===c.Hh.LABEL)return(0,s.qy)`<p class="label-entry">${ep(e,i)}</p>`;if(e.type===c.Hh.ALERT)return(0,s.qy)`<div class="alert-entry">${ep(e,i)}</div>`;if(e.type===c.Hh.NESTED){let o,a,r,n;return e.multi_value?function(e,t,i){let o=i.getAt(t);if(o instanceof H.ho)return(0,s.qy)`
      <div class="nested-list" data-field-key=${t.join(".")}>
        ${eu(e,i)}
        <p class="field-description">
          ${i.localize("device.multi_value_yaml_only")}
        </p>
        ${em(t,i)}
      </div>
    `;let a=(0,J.ly)(o),r=es(e,i),{addItem:n,removeAt:l}=eE(i,t,()=>({})),d=ep(e,i),c=e.config_entries??[];return(0,s.qy)`
    <div class="nested-list" data-field-key=${t.join(".")}>
      ${eu(e,i)} ${eq(a,i)}
      ${a.map((e,o)=>{let a=[...t,String(o)],n=i.filterRenderable(c,e);return(0,s.qy)`
          <div class="nested-list-item" data-field-key=${a.join(".")}>
            <div class="nested-list-item-header">
              <span class="nested-list-item-title">
                ${d} ${o+1}
              </span>
              ${eL(i,r,()=>l(o))}
            </div>
            <div class="nested-fields">
              ${n.map(e=>i.renderEntry(e,[...a,e.key]))}
            </div>
          </div>
        `})}
      ${eM(i,r,n)}
      ${em(t,i)}
    </div>
  `}(e,t,i):(o=t.join("."),a=i.nestedOpenSections.has(o),r=i.requiredOnly?!a:a,n=i.filterRenderable(e.config_entries??[],i.scopeValues(t)),(0,s.qy)`
    <div class="nested-group" data-field-key=${t.join(".")}>
      <div class="nested-header">
        <button
          type="button"
          class="nested-toggle"
          aria-expanded=${r}
          @click=${()=>i.toggleNested(o)}
        >
          <wa-icon
            library="mdi"
            name=${r?"chevron-up":"chevron-down"}
          ></wa-icon>
          <span class="nested-title">${ep(e,i)}</span>
          ${e.platform_type?(0,s.qy)`<span class="nested-platform">${e.platform_type}</span>`:s.s6}
        </button>
        ${eh(e,i)}
      </div>
      ${e.description?(0,s.qy)`<p class="nested-desc">
            ${(0,F.G)(e.description)}
          </p>`:s.s6}
      ${r?(0,s.qy)`<div class="nested-fields">
            ${n.map(e=>i.renderEntry(e,[...t,e.key]))}
          </div>`:s.s6}
    </div>
  `)}if(e.type===c.Hh.MAP){let o,a,r,n,l,d;return o=(e.config_entries??[])[0],n=Object.keys(r=(a=i.getAt(t))&&"object"==typeof a&&!Array.isArray(a)?a:{}),l=es(e,i),d=()=>{let e=i.getAt(t);return e&&"object"==typeof e&&!Array.isArray(e)?Object.assign(Object.create(null),e):Object.create(null)},(0,s.qy)`
    <div class="field" data-field-key=${t.join(".")}>
      ${eu(e,i)}
      ${0===n.length?(0,s.qy)`<p class="field-description">
            ${i.localize("device.map_empty")}
          </p>`:s.s6}
      ${n.map(e=>{let a,n;return a=[...t,e],n=!(0,J.k4)(r[e]),(0,s.qy)`
      <div class="map-row">
        <input
          type="text"
          class="multi-input map-key-input"
          .value=${e}
          ?disabled=${l}
          @change=${o=>((e,o)=>{if(e===o||!o)return;let a=i.getAt(t);if(!a||"object"!=typeof a||Array.isArray(a)||o in a)return;let r=Object.create(null);for(let[t,i]of Object.entries(a))r[t===e?o:t]=i;i.emitChange(t,r)})(e,o.target.value)}
        />
        <div class="map-value">
          ${n?(0,s.qy)`<p class="map-value-yaml-only">
                ${i.localize("device.map_value_edit_in_yaml")}
              </p>`:o?i.renderEntry(o,a):s.s6}
        </div>
        <button
          type="button"
          class="multi-btn"
          ?disabled=${l}
          aria-label=${i.localize("device.map_remove")}
          @click=${()=>{let o;e in(o=d())&&(delete o[e],i.emitChange(t,o))}}
        >
          <wa-icon library="mdi" name="close"></wa-icon>
        </button>
      </div>
    `})}
      <button
        type="button"
        class="multi-btn multi-add"
        ?disabled=${l}
        @click=${()=>{let e=d(),o=1;for(;`new_${o}`in e;)o++;e[`new_${o}`]="",i.emitChange(t,e)}}
      >
        <wa-icon library="mdi" name="plus"></wa-icon>
        ${i.localize("device.map_add")}
      </button>
      ${em(t,i)}
    </div>
  `}if(e.multi_value)return function(e,t,i){let o=eS(i,t).map(e=>String(e)),a=null!==i.errorAt(t),r=es(e,i),{addItem:n,removeAt:l}=eE(i,t,()=>"");return(0,s.qy)`
    <div class="field" data-field-key=${t.join(".")}>
      ${eu(e,i)} ${eq(o,i)}
      ${o.map((e,o)=>(0,s.qy)`
          <div class="multi-row">
            <input
              type="text"
              class="multi-input ${a?"invalid":""}"
              .value=${e}
              ?disabled=${r}
              @input=${e=>{var a;let r;return a=e.target.value,void((r=[...eS(i,t)])[o]=a,i.emitChange(t,r))}}
            />
            ${eL(i,r,()=>l(o))}
          </div>
        `)}
      ${eM(i,r,n)}
      ${em(t,i)}
    </div>
  `}(e,t,i);if(e.references_component){let o,a,r,n,l,d,c;return o=e.references_component||"",a=function(e,t){if(!t)return[];let i={yaml:e,domain:t},o=ey.get(i);if(o)return o;let a=e.split("\n"),r=[],n=!1,s="",l="",d=()=>{s&&r.push({id:s,name:l}),s="",l=""};for(let e of a){let i=e.match(/^([a-zA-Z_][a-zA-Z0-9_]*):/);if(i){d(),n=i[1]===t;continue}if(!n)continue;/^\s*-\s/.test(e)&&d();let o=e.match(/^\s+(?:-\s+)?id:\s*["']?(\S+?)["']?\s*$/);if(o){s=o[1];continue}let a=e.match(/^\s+(?:-\s+)?name:\s*["']?(.+?)["']?\s*$/);a&&(l=a[1])}return d(),ey.set(i,r),r}(i.yaml,o),r=String(i.getAt(t)??""),n=null!==i.errorAt(t),l=0===a.length,d=e=>{let a=e.target,n=a.value;if(n===ew){a.value=r,i.requestAddComponent(o);return}i.emitChange(t,n)},c=(0,s.qy)`
    <wa-option
      class="id-option id-option-add ${l?"id-option-add--solo":""}"
      value=${ew}
    >
      <span class="id-option-stack">
        <span class="id-option-primary id-option-primary-add">
          <wa-icon library="mdi" name="plus"></wa-icon>
          ${i.localize("device.id_reference_add",{domain:o})}
        </span>
      </span>
    </wa-option>
  `,l?(0,s.qy)`
      <div class="field" data-field-key=${t.join(".")}>
        ${eu(e,i)}
        <wa-select
          class=${n?"invalid":""}
          ?disabled=${es(e,i)}
          placeholder=${i.localize("device.id_reference_empty",{domain:o})}
          @change=${d}
        >
          ${c}
        </wa-select>
        ${em(t,i)}
      </div>
    `:(0,s.qy)`
    <div class="field" data-field-key=${t.join(".")}>
      ${eu(e,i)}
      <wa-select
        class=${n?"invalid":""}
        ?disabled=${es(e,i)}
        @change=${d}
      >
        ${a.map(e=>(0,s.qy)`<wa-option
              class="id-option"
              value=${e.id}
              .label=${e.name||e.id}
              ?selected=${e.id===r}
            >
              <span class="id-option-stack">
                <span class="id-option-primary">${e.name||e.id}</span>
                <span class="id-option-secondary"
                  >${e.name?`${e.id} \xb7 ${o}`:o}</span
                >
              </span>
            </wa-option>`)}
        ${c}
      </wa-select>
      ${em(t,i)}
    </div>
  `}if(e.options&&e.options.length>0)return function(e,t,i){let o=String(i.getAt(t)??""),a=null!==i.errorAt(t),r=es(e,i);if(e.suggestions&&e.suggestions.length>0){let n=o.toLowerCase();return(0,s.qy)`
      <div class="field" data-field-key=${t.join(".")}>
        ${eu(e,i)}
        <wa-select
          class=${a?"invalid":""}
          ?disabled=${r}
          placeholder=${String(e.default_value??"")}
          @change=${e=>i.emitChange(t,e.target.value)}
        >
          ${e.suggestions.map(e=>{let t=String(e);return(0,s.qy)`<wa-option
              value=${t}
              ?selected=${t.toLowerCase()===n}
              >${t}</wa-option
            >`})}
        </wa-select>
        ${em(t,i)}
      </div>
    `}if(e.allow_custom_value&&e.options&&e.options.length>0){let n=`combobox-${t.join("-")}`;return(0,s.qy)`
      <div class="field" data-field-key=${t.join(".")}>
        ${eu(e,i)}
        <input
          type="text"
          class="combobox-input ${a?"invalid":""}"
          list=${n}
          .value=${o}
          ?disabled=${r}
          placeholder=${String(e.default_value??"")}
          @input=${e=>i.emitChange(t,e.target.value)}
        />
        <datalist id=${n}>
          ${e.options.map(e=>(0,s.qy)`<option value=${e.value}>${e.label}</option>`)}
        </datalist>
        ${em(t,i)}
      </div>
    `}let n=o.toLowerCase(),l=null!=e.default_value?String(e.default_value):"",d=e.options?.find(e=>e.value.toLowerCase()===l.toLowerCase()),c=d?.label??l;return(0,s.qy)`
    <div class="field" data-field-key=${t.join(".")}>
      ${eu(e,i)}
      <wa-select
        class=${a?"invalid":""}
        ?disabled=${r}
        placeholder=${c}
        @change=${e=>i.emitChange(t,e.target.value)}
      >
        ${(e.options??[]).map(e=>(0,s.qy)`<wa-option
              value=${e.value}
              ?selected=${e.value.toLowerCase()===n}
              >${e.label}</wa-option
            >`)}
      </wa-select>
      ${em(t,i)}
    </div>
  `}(e,t,i);switch(e.type){case c.Hh.BOOLEAN:let o,a;return a=null==(o=i.getAt(t))?e.default_value:o,(0,s.qy)`
    <div class="switch-field" data-field-key=${t.join(".")}>
      <div class="field-info">
        ${eu(e,i,{includeHelpLink:!1})}
      </div>
      ${eh(e,i)}
      <wa-switch
        ?checked=${!0===a||"true"===a}
        ?disabled=${es(e,i)}
        @change=${e=>i.emitChange(t,e.target.checked)}
      ></wa-switch>
    </div>
  `;case c.Hh.SELECT:return ev(e,"text",t,i);case c.Hh.SECURE_STRING:return ev(e,"password",t,i);case c.Hh.INTEGER:case c.Hh.FLOAT:return function(e,t,i){if(e.suggestions&&e.suggestions.length>0)return ev(e,"number",t,i);if("hex"===e.display_format){var o,a,r;let n,l,d,c,p;return o=e,a=t,n=(r=i).getAt(a),l=null!==r.errorAt(a),d=es(o,r),c=r.getEditingMagnitude(a)??eC(n),p=eC(o.default_value),eg(o,a,r,(0,s.qy)`<input
      type="text"
      autocomplete="off"
      spellcheck="false"
      class=${l?"invalid":""}
      .value=${c}
      ?disabled=${d}
      placeholder=${p}
      @input=${e=>{let t=e.target.value;(r.setEditingMagnitude(a,t),""===t)?r.emitChange(a,""):r.emitChange(a,ez(ek(t))||t)}}
      @blur=${()=>r.clearEditingMagnitude(a)}
    />`)}let n=String(i.getAt(t)??""),l=null!==i.errorAt(t),d=e.range?String(e.range[0]):void 0,p=e.range?String(e.range[1]):void 0,h=es(e,i);return eg(e,t,i,(0,s.qy)`<input
      type="number"
      class=${l?"invalid":""}
      .value=${n}
      ?disabled=${h}
      min=${d??""}
      max=${p??""}
      step=${e.type===c.Hh.FLOAT?"any":"1"}
      placeholder=${String(e.default_value??"")}
      @input=${e=>{let o=e.target.value;i.emitChange(t,""===o?"":Number(o))}}
    />`)}(e,t,i);case c.Hh.FLOAT_WITH_UNIT:let r,n,l,d,p,h,u,m,g,v,f,b,y;return n=(r=e.unit_options??[])[0]??"",l=i.getAt(t),d=(0,e$.Eb)(l,r),p=i.getEditingMagnitude(t)??(null===d.value?"":String(d.value)),h=(0,e$.E3)(l,e.default_value,i.getPendingUnit(t),r),u=(0,e$.x9)(e.default_value,r),m=null!==i.errorAt(t),g=es(e,i),v=h===n,f=e.range&&v?String(e.range[0]):void 0,b=e.range&&v?String(e.range[1]):void 0,y=e=>i.emitChange(t,(0,e$.BR)(e)),(0,s.qy)`
    <div class="field float-with-unit" data-field-key=${t.join(".")}>
      ${eu(e,i)}
      <div class="float-with-unit-inputs">
        <input
          type="number"
          class=${m?"invalid":""}
          .value=${p}
          ?disabled=${g}
          min=${(0,ex.J)(f)}
          max=${(0,ex.J)(b)}
          step="any"
          placeholder=${u}
          @input=${e=>{let o=e.target.value;i.setEditingMagnitude(t,o),""===o&&i.setPendingUnit(t,h);let a=""===o?null:Number(o);y({value:Number.isFinite(a)?a:null,unit:h})}}
          @blur=${()=>i.clearEditingMagnitude(t)}
        />
        ${r.length>1?(0,s.qy)`
              <wa-select
                data-no-value-sync
                ?disabled=${g}
                @change=${e=>{let o=e.target.value;null===d.value?i.setPendingUnit(t,o):y({value:d.value,unit:o})}}
              >
                ${r.map(e=>(0,s.qy)`<wa-option
                    value=${e}
                    ?selected=${e===h}
                    >${e}</wa-option
                  >`)}
              </wa-select>
            `:(0,s.qy)`<span class="float-with-unit-suffix">${h}</span>`}
      </div>
      ${em(t,i)}
    </div>
  `;case c.Hh.PIN:return function(e,t,i){if(!i.board||0===i.board.pins.length)return ev(e,"text",t,i);let o=i.getAt(t),a=e_(o),r=null!==a?`GPIO${a}`:(0,J.k4)(o)?String(o??""):"",n=null!==i.errorAt(t),l=e.pin_features??[],d=i.board.pins.filter(e=>l.every(t=>e.features.includes(t)));if(e.suggestions&&e.suggestions.length>0){let t=new Set(e.suggestions.map(e_).filter(e=>null!==e));if(t.size>0){let e=d.filter(e=>t.has(e.gpio));e.length>0&&(d=e)}}null!==a&&!d.some(e=>e.gpio===a)&&i.board.pins.some(e=>e.gpio===a)&&(d=[i.board.pins.find(e=>e.gpio===a),...d]);let p=function(e,t,i){let o={yaml:e,excludeFromLine:t,excludeToLine:i},a=eb.get(o);if(a)return a;let r=new Map;if(!e)return r;let n=e.split("\n"),s="";for(let e=0;e<n.length;e++){let o=n[e],a=o.match(/^([a-zA-Z_][a-zA-Z0-9_]*):/);if(a){s=a[1];continue}let l=e+1;if(void 0===t||void 0===i||!(l>=t)||!(l<=i))for(let e of o.matchAll(/GPIO(\d+)/g)){let t=parseInt(e[1],10);Number.isNaN(t)||r.has(t)||!s||r.set(t,s)}}return eb.set(o,r),r}(i.yaml,i.fromLine,function(e,t){if(void 0===t)return;let i=e.split("\n");for(let e=t;e<i.length;e++){let t=i[e];if(""!==t&&/^[a-zA-Z]/.test(t))return e}return i.length}(i.yaml,i.fromLine)),h=es(e,i),u=(0,J.Qd)(o);return(0,s.qy)`
    <div class="field" data-field-key=${t.join(".")}>
      ${eu(e,i)}
      <wa-select
        data-no-value-sync
        class=${n?"invalid":""}
        ?disabled=${h}
        @change=${e=>{let o=e.target.value;u?i.emitChange([...t,"number"],o):i.emitChange(t,o)}}
      >
        ${d.map(t=>{let o,a,n,l,d,h,u,m,g,v,f,b,y=(o=`GPIO${t.gpio}`,a=t.label||o,n=t.occupied_by||"",l=p.get(t.gpio)||"",d=e.pin_mode===c.l3.OUTPUT||e.pin_mode===c.l3.INPUT_OUTPUT,h=t.features.includes(c.k6.INPUT_ONLY),u=d&&h,m=!1===t.available||u,g=!!(n||l),v=n?i.localize("device.pin_occupied_by",{name:n}):l?i.localize("device.pin_used_by",{name:l}):"",f=u?i.localize("device.pin_input_only"):t.notes||(!1===t.available?i.localize("device.pin_unavailable"):""),b=[],t.label&&t.label!==o&&b.push(o),v&&b.push(v),f&&b.push(f),{optValue:o,primary:a,secondary:b.join(" • "),titleText:[v,f].filter(Boolean).join(" — "),inUse:g,disabled:m});return(0,s.qy)`<wa-option
            class="pin-option ${y.inUse?"pin-option--warn":""}"
            value=${y.optValue}
            .label=${y.primary}
            ?selected=${y.optValue===r}
            ?disabled=${y.disabled}
            title=${y.titleText}
          >
            <span class="pin-option-stack">
              <span class="pin-option-primary">
                ${y.primary}
                ${y.inUse?(0,s.qy)`<wa-icon
                      class="pin-warn-icon"
                      library="mdi"
                      name="alert-circle-outline"
                    ></wa-icon>`:s.s6}
              </span>
              ${y.secondary?(0,s.qy)`<span class="pin-option-secondary">${y.secondary}</span>`:s.s6}
            </span>
          </wa-option>`})}
      </wa-select>
      ${em(t,i)}
      ${function(e,t,i,o,a,r){let n=i.filterRenderable(e.config_entries??[],i.scopeValues(t));if(0===n.length)return s.s6;let l=`${t.join(".")}:pin-advanced`,d=i.nestedOpenSections.has(l);return(0,s.qy)`
    <div class="pin-advanced" data-field-key="${l}">
      <button
        type="button"
        class="pin-advanced-toggle"
        aria-expanded=${d}
        ?disabled=${r}
        @click=${()=>{!r&&(i.toggleNested(l),d||a||null==o||""===o||i.emitChange(t,{number:o}))}}
      >
        <wa-icon
          library="mdi"
          name=${d?"chevron-up":"chevron-down"}
        ></wa-icon>
        <span>${i.localize("device.pin_advanced")}</span>
      </button>
      ${d?(0,s.qy)`<div class="pin-advanced-fields">
            ${n.map(e=>i.renderEntry(e,[...t,e.key]))}
          </div>`:s.s6}
    </div>
  `}(e,t,i,o,u,h)}
    </div>
  `}(e,t,i);case c.Hh.COLOR:return ev(e,"color",t,i);case c.Hh.MAC_ADDRESS:return ev(e,"text",t,i);case c.Hh.LAMBDA:case c.Hh.JSON:let w,_,x,$;return x=(_=(w=i.getAt(t))instanceof H.ho)?w.body:String(w??""),$=null!==i.errorAt(t),(0,s.qy)`
    <div class="field" data-field-key=${t.join(".")}>
      ${eu(e,i)}
      <textarea
        class="textarea-field ${$?"invalid":""}"
        rows="4"
        ?disabled=${es(e,i)}
        .value=${x}
        placeholder=${String(e.default_value??"")}
        @input=${e=>{let o=e.target.value;i.emitChange(t,_?H.ho.fromBodyText(o,w):o)}}
      ></textarea>
      ${em(t,i)}
    </div>
  `;case c.Hh.ICON:let k,z;return k=String(i.getAt(t)??""),z=null!==i.errorAt(t),(0,s.qy)`
    <div class="field" data-field-key=${t.join(".")}>
      ${eu(e,i)}
      <esphome-mdi-icon-picker
        .value=${k}
        .invalid=${z}
        .disabled=${es(e,i)}
        .placeholder=${String(e.default_value??"Choose an icon…")}
        @change=${e=>i.emitChange(t,e.detail.value)}
      ></esphome-mdi-icon-picker>
      ${em(t,i)}
    </div>
  `;default:return ev(e,"text",t,i)}}_buildCtx(){let e={localize:this._localize,disabled:this.disabled,yaml:this.yaml,fromLine:this.fromLine,board:this.board,requiredOnly:this.requiredOnly,nestedOpenSections:this._nestedOpenSections,getAt:e=>(0,J.O6)(this.values,e),errorAt:e=>this.errors.get(e.join("."))??null,emitChange:(e,t)=>this._emitChange(e,t),toggleNested:e=>this._toggleNested(e),requestAddComponent:e=>this._requestAddComponent(e),scopeValues:e=>this._scopeValues(e),filterRenderable:this._filterRenderable,getPendingUnit:e=>this._pendingUnits.get(e.join(".")),setPendingUnit:(e,t)=>{this._pendingUnits.set(e.join("."),t),this.requestUpdate()},getEditingMagnitude:e=>this._editingMagnitudes.get(e.join(".")),setEditingMagnitude:(e,t)=>{this._editingMagnitudes.set(e.join("."),t)},clearEditingMagnitude:e=>{this._editingMagnitudes.delete(e.join("."))},renderEntry:()=>s.s6};return e.renderEntry=(t,i)=>this._renderEntry(t,i,e),e}_scopeValues(e){let t=(0,J.O6)(this.values,e);return t&&"object"==typeof t&&!Array.isArray(t)?t:{}}_emitChange(e,t){this.dispatchEvent(new CustomEvent("value-change",{detail:{path:e,value:t},bubbles:!0,composed:!0}))}_toggleNested(e){let t=new Set(this._nestedOpenSections);t.has(e)?t.delete(e):t.add(e),this._nestedOpenSections=t}openNested(e){if(this.requiredOnly||this._nestedOpenSections.has(e))return;let t=new Set(this._nestedOpenSections);t.add(e),this._nestedOpenSections=t}_requestAddComponent(e){this.dispatchEvent(new CustomEvent("request-add-component",{detail:{domain:e},bubbles:!0,composed:!0}))}constructor(...e){super(...e),this._localize=e=>e,this.entries=[],this.values={},this.errors=new Map,this.board=null,this.disabled=!1,this.showAdvanced=!1,this.requiredOnly=!1,this.yaml="",this.presentComponents=new Set,this._nestedOpenSections=new Set,this._pendingUnits=new Map,this._editingMagnitudes=new Map,this._filterRenderable=(e,t)=>ee(e,t,{requiredOnly:this.requiredOnly,showAdvanced:this.showAdvanced,presentComponents:this.presentComponents,targetPlatform:this.board?.esphome.platform??null})}}function eP(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}eD.styles=[u.G,I.z,er],eA([(0,r.Fg)({context:h.$F,subscribe:!0}),(0,l.wk)()],eD.prototype,"_localize",void 0),eA([(0,l.MZ)({attribute:!1})],eD.prototype,"entries",void 0),eA([(0,l.MZ)({attribute:!1})],eD.prototype,"values",void 0),eA([(0,l.MZ)({attribute:!1})],eD.prototype,"errors",void 0),eA([(0,l.MZ)({attribute:!1})],eD.prototype,"board",void 0),eA([(0,l.MZ)({type:Boolean})],eD.prototype,"disabled",void 0),eA([(0,l.MZ)({type:Boolean,attribute:"show-advanced"})],eD.prototype,"showAdvanced",void 0),eA([(0,l.MZ)({type:Boolean,attribute:"required-only"})],eD.prototype,"requiredOnly",void 0),eA([(0,l.MZ)()],eD.prototype,"yaml",void 0),eA([(0,l.MZ)({type:Number,attribute:"from-line"})],eD.prototype,"fromLine",void 0),eA([(0,l.MZ)({attribute:!1})],eD.prototype,"presentComponents",void 0),eA([(0,l.wk)()],eD.prototype,"_nestedOpenSections",void 0),eD=eA([(0,l.EM)("esphome-config-entry-form")],eD),(0,y.C)({"alert-circle-outline":n.mdiAlertCircleOutline});class eO extends s.WF{willUpdate(e){super.willUpdate(e),(e.has("component")||!this._initialized)&&this.component&&(this._initialized=!0,this._initValues(),this._localBlockMessage="")}_initValues(){let e=this.component.id.startsWith("featured."),t=this._seedDefaults(this.component.config_entries,e);if(this.component.config_entries.find(e=>"id"===e.key&&e.type===c.Hh.ID)&&void 0===t.id){let e=this._generateDefaultId();null!==e&&(t={...t,id:e})}if(t=function(e,t,i,o){if(!i?.pins?.length||e.includes("."))return o;let a=o;for(let o of t){if(o.type!==c.Hh.PIN||void 0!==a[o.key])continue;let t=`${e}_${o.key.toLowerCase()}`,r=i.pins.find(e=>e.features.includes(t));r&&(a={...a,[o.key]:r.gpio})}return a}(this.component.id,this.component.config_entries,this.board,t),this.prefillReference){let e=this._findReferencePath(this.component.config_entries,this.prefillReference.domain,[]);e&&(t=(0,J.Oe)(t,e,this.prefillReference.id))}this._values=t}_findReferencePath(e,t,i){for(let o of e){if(o.type===c.Hh.NESTED){let e=this._findReferencePath(o.config_entries??[],t,[...i,o.key]);if(e)return e;continue}if(o.references_component===t)return[...i,o.key]}return null}_seedDefaults(e,t=!1){let i={};for(let o of e){if(o.type===c.Hh.NESTED){let e=this._seedDefaults(o.config_entries??[],t);Object.keys(e).length>0&&(i[o.key]=e);continue}(t||o.required)&&(null!=o.default_value?i[o.key]=o.multi_value?[String(o.default_value)]:o.default_value:o.multi_value&&o.required&&(i[o.key]=[]))}return i}_generateDefaultId(){return function(e,t,i){if(!t&&!e.includes("."))return null;let o=e.replace(/\./g,"_").toLowerCase(),a=1,r=`${o}_${a}`;for(;i.has(r);)a++,r=`${o}_${a}`;return r}(this.component.id,this.component.multi_conf,function(e){let t=new Set;if(!e)return t;for(let i of e.split("\n")){let e=i.match(/^\s+(?:-\s+)?id:\s*["']?(\S+?)["']?\s*$/);e&&t.add(e[1])}return t}(this.yaml))}render(){let e=this.submitting,t=(0,H.Zn)(this.yaml),i=(this.component.dependencies??[]).filter(e=>!t.has(e)),o=(0,G.JK)(this.component.config_entries,this._values,t,this.board?.esphome.platform??null),a=!this._hasRequiredErrors(o);return(0,s.qy)`
      <div class="form">
        <p class="form-desc">${(0,F.G)(this.component.description)}</p>
        ${i.length>0?this._renderMissingDeps(i):s.s6}
        <esphome-config-entry-form
          .entries=${this.component.config_entries}
          .values=${this._values}
          .errors=${this._errors}
          .board=${this.board}
          .yaml=${this.yaml}
          .presentComponents=${t}
          ?disabled=${e}
          ?required-only=${!0}
          @value-change=${this._onValueChange}
        ></esphome-config-entry-form>
        <button
          type="button"
          class="toggle-link"
          @click=${()=>{this._showYaml=!this._showYaml}}
        >
          ${this._showYaml?this._localize("device.yaml_preview_toggle"):this._localize("device.yaml_preview")}
        </button>
        ${this._showYaml?(0,s.qy)`<pre class="yaml-preview">${this._generateYamlPreview()}</pre>`:s.s6}
        ${this.submitError?(0,s.qy)`<p class="error">${this.submitError}</p>`:s.s6}
        ${this._localBlockMessage?(0,s.qy)`<p class="error">${this._localBlockMessage}</p>`:s.s6}
        <div class="actions">
          <button
            class="btn btn-secondary"
            ?disabled=${e}
            @click=${this._onCancel}
          >
            ${this._localize("wizard.back")}
          </button>
          <button
            class="btn btn-primary"
            ?disabled=${e||!a||i.length>0}
            @click=${this._onSubmit}
          >
            ${this.submitting?this._localize("device.adding"):this._localize("device.add_component_action")}
          </button>
        </div>
      </div>
    `}_renderMissingDeps(e){return(0,s.qy)`
      <div class="deps-warning" role="alert">
        <wa-icon library="mdi" name="alert-circle-outline"></wa-icon>
        <div class="deps-warning-body">
          <div class="deps-warning-title">
            ${this._localize("device.missing_dependencies_title",{name:this.component.name})}
          </div>
          <div>${this._localize("device.missing_dependencies_body")}</div>
          <div class="deps-warning-actions">
            ${e.map(e=>(0,s.qy)`<button
                type="button"
                class="dep-button"
                @click=${()=>this._onAddDep(e)}
              >
                ${this._localize("device.missing_dependencies_add",{domain:e})}
              </button>`)}
          </div>
        </div>
      </div>
    `}_onAddDep(e){this.dispatchEvent(new CustomEvent("navigate-to-dep",{detail:{domain:e},bubbles:!0,composed:!0}))}_hasRequiredErrors(e){for(let t of e.values())if("validation.required"===t.code)return!0;return!1}_labelForErrorKey(e){let t,i=e.split("."),o=this.component.config_entries;for(let e of i){if(!o||!(t=o.find(t=>t.key===e)))break;o=t.type===c.Hh.NESTED?t.config_entries??[]:null}return t?ec(t,this._localize):e}_anyErrorIsVisible(e,t){if(0===e.size)return!1;let i=function e(t,i,o,a=[],r=new Set){for(let n of ee(t,i,o)){if(n.type===c.Hh.NESTED){let t=n.config_entries??[];n.multi_value?(0,J.ly)(i[n.key]).forEach((i,s)=>{e(t,i,o,[...a,n.key,String(s)],r)}):e(t,(0,J.qY)(i[n.key]),o,[...a,n.key],r),r.add([...a,n.key].join("."));continue}r.add([...a,n.key].join("."))}return r}(this.component.config_entries,this._values,{requiredOnly:!0,showAdvanced:!1,presentComponents:t,targetPlatform:this.board?.esphome.platform??null});for(let t of e.keys())if(i.has(t))return!0;return!1}_onValueChange(e){let{path:t,value:i}=e.detail;this._values=(0,J.Oe)(this._values,t,i);let o=t.join(".");if(this._errors.has(o)){let e=new Map(this._errors);e.delete(o),this._errors=e}this._localBlockMessage&&(this._localBlockMessage="")}_generateYamlPreview(){let e=[`${this.component.id}:`];return e.push(...(0,H.ym)(this._values,"  ")),e.join("\n")}_onCancel(){this.dispatchEvent(new CustomEvent("form-cancel",{bubbles:!0,composed:!0}))}_onSubmit(){this._localBlockMessage="";let e=(0,H.Zn)(this.yaml),t=(this.component.dependencies??[]).filter(t=>!e.has(t));if(t.length>0){this._localBlockMessage=`${this._localize("device.missing_dependencies_title",{name:this.component.name})} (${t.join(", ")})`;return}let i=(0,G.JK)(this.component.config_entries,this._values,e,this.board?.esphome.platform??null);if(i.size>0){if(this._errors=i,!this._anyErrorIsVisible(i,e)){let e=[...i.entries()].map(([e,t])=>`${this._labelForErrorKey(e)}: ${this._localize(t.code,t.params)}`).join("; ");this._localBlockMessage=`${this._localize("device.add_component_hidden_validation_error")} (${e})`}return}this._errors=new Map,this._localBlockMessage="";let o=this._coerceFields(this.component.config_entries,this._values);this.dispatchEvent(new CustomEvent("form-submit",{detail:{fields:o},bubbles:!0,composed:!0}))}_coerceFields(e,t){let i={};for(let o of e){if(o.hidden)continue;let e=t[o.key];if(o.type===c.Hh.NESTED){let t=null===e||"object"!=typeof e||Array.isArray(e)?{}:e,a=this._coerceFields(o.config_entries??[],t);Object.keys(a).length>0&&(i[o.key]=a);continue}if(void 0!==e){if(Array.isArray(e)){if(0===e.length)continue;i[o.key]=e;continue}if(""===e){o.required&&(i[o.key]=e);continue}if(o.type===c.Hh.INTEGER){let t="number"==typeof e?e:Number.parseInt(String(e),10);Number.isNaN(t)||(i[o.key]=t)}else if(o.type===c.Hh.FLOAT){let t="number"==typeof e?e:Number.parseFloat(String(e));Number.isNaN(t)||(i[o.key]=t)}else o.type===c.Hh.BOOLEAN?i[o.key]=!0===e||"true"===e:i[o.key]=e}}return i}constructor(...e){super(...e),this._localize=e=>e,this.board=null,this.yaml="",this.prefillReference=null,this.submitting=!1,this.submitError="",this._values={},this._errors=new Map,this._localBlockMessage="",this._showYaml=!1,this._initialized=!1}}function ej(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}eO.styles=[u.G,I.z,Q,(0,s.AH)`
      /* Banner shown when the component has unmet dependencies
         (e.g. a gpio light needs a configured output: first). */
      .deps-warning {
        display: flex;
        gap: var(--wa-space-s);
        padding: var(--wa-space-s) var(--wa-space-m);
        background: color-mix(
          in srgb,
          var(--esphome-warning, #d97706),
          transparent 88%
        );
        border: var(--wa-border-width-s) solid
          var(--esphome-warning, #d97706);
        border-radius: var(--wa-border-radius-m);
        color: var(--wa-color-text-normal);
        font-size: var(--wa-font-size-s);
        line-height: 1.45;
      }

      .deps-warning wa-icon {
        flex-shrink: 0;
        font-size: 20px;
        color: var(--esphome-warning, #d97706);
      }

      .deps-warning-body {
        display: flex;
        flex-direction: column;
        gap: var(--wa-space-2xs);
        flex: 1;
        min-width: 0;
      }

      .deps-warning-title {
        font-weight: var(--wa-font-weight-bold);
      }

      .deps-warning-actions {
        display: flex;
        flex-wrap: wrap;
        gap: var(--wa-space-2xs);
        margin-top: var(--wa-space-2xs);
      }

      .dep-button {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 4px 10px;
        background: var(--esphome-warning, #d97706);
        color: var(--esphome-on-primary, white);
        border: none;
        border-radius: var(--wa-border-radius-m);
        font-family: inherit;
        font-size: var(--wa-font-size-xs);
        font-weight: var(--wa-font-weight-bold);
        cursor: pointer;
        transition: opacity 0.12s;
      }

      .dep-button:hover {
        opacity: 0.9;
      }
    `],eP([(0,r.Fg)({context:h.$F,subscribe:!0}),(0,l.wk)()],eO.prototype,"_localize",void 0),eP([(0,l.MZ)({attribute:!1})],eO.prototype,"component",void 0),eP([(0,l.MZ)({attribute:!1})],eO.prototype,"board",void 0),eP([(0,l.MZ)()],eO.prototype,"yaml",void 0),eP([(0,l.MZ)({attribute:!1})],eO.prototype,"prefillReference",void 0),eP([(0,l.MZ)({type:Boolean})],eO.prototype,"submitting",void 0),eP([(0,l.MZ)()],eO.prototype,"submitError",void 0),eP([(0,l.wk)()],eO.prototype,"_values",void 0),eP([(0,l.wk)()],eO.prototype,"_errors",void 0),eP([(0,l.wk)()],eO.prototype,"_localBlockMessage",void 0),eP([(0,l.wk)()],eO.prototype,"_showYaml",void 0),eO=eP([(0,l.EM)("esphome-add-component-form")],eO),(0,y.C)({close:n.mdiClose,"arrow-left":n.mdiArrowLeft,"package-variant-closed":n.mdiPackageVariantClosed});class eT extends s.WF{open(){this._resetDetourState(),this._selected=null,this._submitError="",this._submitting=!1,this._dialog.open=!0,this.updateComplete.then(()=>this._catalog?.load())}openWithSearch(e){this._resetDetourState(),this._selected=null,this._submitError="",this._submitting=!1,this._dialog.open=!0,this.updateComplete.then(()=>this._catalog?.filterByDomain(e))}_resetDetourState(){this._returnTo=null,this._depDomain=null,this._prefillReference=null,this._bundleQueue=[],this._bundleProgress=null,this._depNavSeq++}render(){var e;let t=null!==this._selected,i=this.lockedCategories.length>0,o=i?this.boardName?"device.add_config_dialog_title":"device.add_config":this.boardName?"device.add_component_dialog_title":"device.add_component";return(0,s.qy)`
      <wa-dialog
        class=${t?"form-view":""}
        light-dismiss
        @add-component=${this._onComponentSelected}
        @add-bundle=${this._onBundleSelected}
        @form-cancel=${this._onBack}
        @form-submit=${this._onFormSubmit}
        @navigate-to-dep=${this._onNavigateToDep}
        @request-add-component=${this._onNavigateToDep}
      >
        <span slot="label" class="dialog-label">
          ${t?(0,s.qy)`<button class="back-button" @click=${this._onBack}>
                <wa-icon library="mdi" name="arrow-left"></wa-icon>
              </button>`:s.s6}
          ${t?this._selected.name:this.boardName?this._localize(o,{name:this.boardName}):this._localize(o)}
        </span>
        ${this._returnTo?(0,s.qy)`<div class="return-banner">
              ${this._localize("device.return_to_after_dep_prefix")}
              <strong>${this._returnTo.name}</strong>
              ${this._localize("device.return_to_after_dep_suffix")}
            </div>`:s.s6}
        ${t&&this._bundleProgress?(0,s.qy)`<div class="bundle-banner">
              <wa-icon library="mdi" name="package-variant-closed"></wa-icon>
              <span
                >${this._localize("device.bundle_step_progress",{current:this._bundleProgress.current,total:this._bundleProgress.total,name:this._bundleProgress.bundleName})}</span
              >
            </div>`:s.s6}
        <esphome-component-catalog
          ?hidden=${t}
          .platform=${this.platform}
          .boardId=${this.board?.id??""}
          .board=${this.board}
          .yaml=${this.yaml}
          .lockedCategories=${this.lockedCategories}
          .excludeCategories=${(e={isCoreLocked:i,isInDepDetour:null!==this._returnTo}).isCoreLocked||e.isInDepDetour?[]:c.bI}
        ></esphome-component-catalog>
        ${t?(0,s.qy)`<esphome-add-component-form
              .component=${this._selected}
              .board=${this.board}
              .yaml=${this.yaml}
              .prefillReference=${this._prefillReference}
              .submitting=${this._submitting}
              .submitError=${this._submitError}
            ></esphome-add-component-form>`:s.s6}
      </wa-dialog>
    `}_onComponentSelected(e){e.stopPropagation(),this._selected=e.detail.component,this._submitError=""}async _onBundleSelected(e){let t;if(e.stopPropagation(),this._submitting)return;let{bundle:i,boardId:o}=e.detail;if(!o||0===i.component_ids.length)return;let a=i.component_ids.map(e=>`featured.${o}.${e}`),[r,...n]=a;try{t=await this._api.getComponent(r,this.platform||void 0,o)}catch(e){this._submitError=e instanceof Error?e.message:this._localize("device.add_component_error");return}if(!t){this._submitError=this._localize("device.add_component_error");return}this._returnTo=null,this._depDomain=null,this._prefillReference=null,this._bundleQueue=n,this._bundleProgress={current:1,total:a.length,bundleName:i.name},this._selected=t,this._submitError=""}_onBack(){if(!this._submitting){if(this._returnTo){let e=this._returnTo;this._resetDetourState(),this._selected=e,this._submitError="";return}this._resetDetourState(),this._selected=null,this._submitError=""}}_onNavigateToDep(e){return e.stopPropagation(),U(this,e.detail.domain)}async _onFormSubmit(e){if(e.stopPropagation(),this._selected&&this.configuration&&!this._submitting){this._submitting=!0,this._submitError="",this._depNavSeq++;try{let{yaml:i}=await this._api.addComponent(this.configuration,{component_id:this._selected.id,fields:e.detail.fields});if(this.dispatchEvent(new CustomEvent("yaml-updated",{detail:{yaml:i},bubbles:!0,composed:!0})),this._returnTo){var t;let i=this._returnTo,o=this._depDomain,a=e.detail.fields.id;o&&"string"==typeof a&&(t=this._selected,t.id===o||t.category===o)?this._prefillReference={domain:o,id:a}:this._prefillReference=null,this._returnTo=null,this._depDomain=null,this._selected=i}else if(this._bundleQueue.length>0&&this._bundleProgress){let t=this._bundleQueue[0],i=this._bundleQueue.slice(1),o=await this._api.getComponent(t,this.platform||void 0,this.board?.id??void 0);if(!o){this._submitError=this._localize("device.add_component_error");return}let a=e.detail.fields.id,r=this._selected.category;"string"==typeof a&&r?this._prefillReference={domain:r,id:a}:this._prefillReference=null,this._bundleQueue=i,this._bundleProgress={...this._bundleProgress,current:this._bundleProgress.current+1},this._selected=o}else{let t=this._selected.id,o=e.detail.fields.id,a=function(e,t,i){let o=z(e);if(!t.includes(".")){let e=o.find(e=>e.key===t&&!e.platform);if(e)return{sectionKey:e.key,fromLine:e.fromLine}}let a=o.filter(e=>E(e)===t);if(0===a.length)return null;if(1===a.length)return{sectionKey:E(a[0]),fromLine:a[0].fromLine};if(i){let t=e.split("\n"),o=RegExp(`^\\s+(?:-\\s+)?id:\\s*["']?${i}["']?\\s*$`);for(let e of a)for(let i=e.fromLine-1;i<e.toLine&&i<t.length;i++)if(o.test(t[i]))return{sectionKey:E(e),fromLine:e.fromLine}}let r=a[a.length-1];return{sectionKey:E(r),fromLine:r.fromLine}}(i,t,"string"==typeof o?o:void 0);a&&this.dispatchEvent(new CustomEvent("section-select",{detail:a,bubbles:!0,composed:!0})),this._dialog.open=!1,this._selected=null,this._resetDetourState()}}catch(e){this._submitError=e instanceof Error?e.message:this._localize("device.add_component_error")}finally{this._submitting=!1}}}constructor(...e){super(...e),this._localize=e=>e,this.boardName="",this.configuration="",this.platform="",this.board=null,this.yaml="",this.lockedCategories=[],this._selected=null,this._submitting=!1,this._submitError="",this._returnTo=null,this._depDomain=null,this._prefillReference=null,this._bundleQueue=[],this._bundleProgress=null,this._depNavSeq=0}}function eF(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}eT.styles=[u.G,(0,s.AH)`
      wa-dialog {
        --width: 900px;
      }

      wa-dialog.form-view {
        --width: 480px;
      }

      wa-dialog::part(header) {
        background: var(--esphome-primary);
        /* Right padding is 0 so the close button sits flush with the
           dialog's corner — the button is explicitly sized to a 40x40
           square below to give the X a comfortable hit target right
           where the user reaches for it. */
        padding: 0 0 0 var(--wa-space-m);
        height: 40px;
        box-sizing: border-box;
      }

      wa-dialog::part(title) {
        color: var(--esphome-on-primary);
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
      }

      wa-dialog::part(close-button__base) {
        background: transparent;
        border: none;
        box-shadow: none;
        /* Square 40x40 button matching the header height so the X has a
           comfortable click/tap target instead of just the icon's
           ~14px footprint. */
        padding: 0;
        width: 40px;
        height: 40px;
        min-width: unset;
        min-height: unset;
        color: var(--esphome-on-primary);
        cursor: pointer;
      }

      wa-dialog::part(body) {
        padding: var(--wa-space-l);
      }

      wa-dialog::part(footer) {
        display: none;
      }

      .dialog-label {
        display: flex;
        align-items: center;
        gap: var(--wa-space-xs);
        color: var(--esphome-on-primary);
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
      }

      .back-button {
        display: inline-flex;
        align-items: center;
        border: none;
        background: none;
        padding: 2px;
        margin-right: var(--wa-space-2xs);
        color: var(--esphome-on-primary);
        cursor: pointer;
        border-radius: 4px;
        opacity: 0.85;
      }

      .back-button:hover {
        opacity: 1;
      }

      /* Breadcrumb that shows up while the user is detoured into
         "add a dependency" mid-way through adding another component.
         Tells them we'll bring them back to the original after. */
      .return-banner {
        display: flex;
        align-items: center;
        gap: var(--wa-space-2xs);
        margin-bottom: var(--wa-space-m);
        padding: var(--wa-space-2xs) var(--wa-space-s);
        background: color-mix(
          in srgb,
          var(--esphome-primary),
          transparent 92%
        );
        border-left: 3px solid var(--esphome-primary);
        border-radius: var(--wa-border-radius-s);
        font-size: var(--wa-font-size-xs);
        color: var(--wa-color-text-quiet);
      }

      .return-banner strong {
        color: var(--wa-color-text-normal);
        font-weight: var(--wa-font-weight-semibold);
      }

      .bundle-banner {
        display: flex;
        align-items: center;
        gap: var(--wa-space-xs);
        margin-bottom: var(--wa-space-m);
        padding: var(--wa-space-xs) var(--wa-space-s);
        background: color-mix(
          in srgb,
          var(--esphome-primary),
          transparent 92%
        );
        border-left: 3px solid var(--esphome-primary);
        border-radius: var(--wa-border-radius-s);
        font-size: var(--wa-font-size-xs);
        color: var(--wa-color-text-normal);
      }

      .bundle-banner wa-icon {
        font-size: 14px;
        color: var(--esphome-primary);
      }
    `],ej([(0,r.Fg)({context:h.$F,subscribe:!0}),(0,l.wk)()],eT.prototype,"_localize",void 0),ej([(0,r.Fg)({context:h.Ie})],eT.prototype,"_api",void 0),ej([(0,l.MZ)()],eT.prototype,"boardName",void 0),ej([(0,l.MZ)()],eT.prototype,"configuration",void 0),ej([(0,l.MZ)()],eT.prototype,"platform",void 0),ej([(0,l.MZ)({attribute:!1})],eT.prototype,"board",void 0),ej([(0,l.MZ)()],eT.prototype,"yaml",void 0),ej([(0,l.MZ)({attribute:!1})],eT.prototype,"lockedCategories",void 0),ej([(0,l.P)("wa-dialog")],eT.prototype,"_dialog",void 0),ej([(0,l.P)("esphome-component-catalog")],eT.prototype,"_catalog",void 0),ej([(0,l.wk)()],eT.prototype,"_selected",void 0),ej([(0,l.wk)()],eT.prototype,"_submitting",void 0),ej([(0,l.wk)()],eT.prototype,"_submitError",void 0),ej([(0,l.wk)()],eT.prototype,"_returnTo",void 0),ej([(0,l.wk)()],eT.prototype,"_depDomain",void 0),ej([(0,l.wk)()],eT.prototype,"_prefillReference",void 0),ej([(0,l.wk)()],eT.prototype,"_bundleQueue",void 0),ej([(0,l.wk)()],eT.prototype,"_bundleProgress",void 0),eT=ej([(0,l.EM)("esphome-add-component-dialog")],eT);class eI extends s.WF{open(){this._inner.open()}render(){return(0,s.qy)`<esphome-add-component-dialog
      .lockedCategories=${c.bI}
      .boardName=${this.boardName}
      .configuration=${this.configuration}
      .platform=${this.platform}
      .board=${this.board}
      .yaml=${this.yaml}
    ></esphome-add-component-dialog>`}constructor(...e){super(...e),this.boardName="",this.configuration="",this.platform="",this.board=null,this.yaml=""}}function eR(e={}){return{key:"",type:c.Hh.STRING,label:"",default_value:null,required:!1,description:null,options:null,allow_custom_value:!1,range:null,display_format:null,unit_options:null,help_link:null,multi_value:!1,hidden:!1,advanced:!1,translation_key:null,translation_params:null,templatable:!1,depends_on:null,depends_on_value:null,depends_on_value_not:null,depends_on_component:null,references_component:null,pin_features:[],pin_mode:null,locked:!1,suggestions:null,config_entries:null,platform_type:null,supported_platforms:void 0,...e}}eF([(0,l.MZ)()],eI.prototype,"boardName",void 0),eF([(0,l.MZ)()],eI.prototype,"configuration",void 0),eF([(0,l.MZ)()],eI.prototype,"platform",void 0),eF([(0,l.MZ)({attribute:!1})],eI.prototype,"board",void 0),eF([(0,l.MZ)()],eI.prototype,"yaml",void 0),eF([(0,l.P)("esphome-add-component-dialog")],eI.prototype,"_inner",void 0),eI=eF([(0,l.EM)("esphome-add-config-dialog")],eI);let eN=new Set(["substitutions"]),eU=new Set(["substitutions"]),eZ=[eR({type:c.Hh.MAP,config_entries:[eR({key:"value",label:"Value",required:!0})]})],eB=new Set(["external_components","packages"]);i(8768);let eH=(0,s.AH)`
  :host {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-m);
    margin-top: var(--wa-space-m);
  }

  .section-header {
    display: flex;
    flex-direction: row;
    align-items: center;
    width: 100%;
    gap: var(--wa-space-l);
    padding-bottom: var(--wa-space-m);
    margin-bottom: var(--wa-space-m);
    border-bottom: 1px solid var(--wa-color-surface-lowered);
  }

  .section-header-info {
    display: flex;
    flex-direction: column;
    flex: 1;
    gap: var(--wa-space-s);
    min-width: 0;
  }

  .section-header-title-row {
    display: flex;
    align-items: center;
    gap: var(--wa-space-m);
    flex-wrap: wrap;
  }

  .section-image {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 140px;
    height: 100px;
    padding: var(--wa-space-s);
    background: var(--wa-color-surface-lowered);
    border-radius: var(--wa-border-radius-l);
    box-sizing: border-box;
  }

  .section-image img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }

  /* Match the catalog's dark-mode treatment for the same monochrome
     SVG illustrations — see component-catalog.ts for the rationale. */
  .section-image img[src$=".svg"] {
    filter: var(--esphome-svg-filter, none);
  }

  .section-title {
    margin: 0;
    font-size: var(--wa-font-size-l);
    font-weight: var(--wa-font-weight-bold);
    color: var(--wa-color-text-normal);
  }

  .section-subtitle {
    margin: 0;
    font-family: var(--wa-font-family-code);
    font-size: var(--wa-font-size-s);
    color: var(--wa-color-text-quiet);
  }

  .section-desc {
    margin: 0;
    font-size: var(--wa-font-size-xs);
    color: var(--wa-color-text-quiet);
    line-height: 1.5;
  }

  .docs-link {
    display: inline-flex;
    align-items: center;
    gap: var(--wa-space-2xs);
    font-size: var(--wa-font-size-xs);
    color: var(--esphome-primary);
    text-decoration: underline;
  }

  .docs-link:hover {
    text-decoration: none;
  }

  .docs-link wa-icon {
    font-size: 14px;
  }

  esphome-config-entry-form {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-m);
  }

  /* "Show advanced settings" toggle row, shown below the form when
     the section has any advanced entries (at any depth). */
  .advanced-toggle-row {
    display: flex;
    justify-content: flex-start;
    margin-top: var(--wa-space-s);
    font-size: var(--wa-font-size-s);
  }

  .advanced-toggle-row wa-switch {
    font-weight: var(--wa-font-weight-semibold);
    color: var(--wa-color-text-quiet);
  }

  .actions {
    display: flex;
    align-items: center;
    gap: var(--wa-space-s);
    padding-top: var(--wa-space-s);
  }

  .delete-button {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    background: transparent;
    color: var(--esphome-error);
    border: var(--wa-border-width-s) solid
      color-mix(in srgb, var(--esphome-error), transparent 70%);
    padding: var(--wa-space-xs) var(--wa-space-m);
    border-radius: var(--wa-border-radius-m);
    cursor: pointer;
    font-size: var(--wa-font-size-s);
    font-weight: var(--wa-font-weight-bold);
    font-family: inherit;
    transition: background 0.12s, border-color 0.12s;
  }

  .delete-button:hover:not(:disabled) {
    background: color-mix(in srgb, var(--esphome-error), transparent 90%);
    border-color: var(--esphome-error);
  }

  .delete-button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .delete-button wa-icon {
    font-size: 16px;
  }

  .error {
    color: var(--esphome-error);
    font-size: var(--wa-font-size-s);
  }

  .loading {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: var(--wa-space-xl);
  }

  /* Stand-in shown when a section has no editable form fields
     (substitutions, globals, packages) — tells the user to edit
     this part via the YAML pane instead of presenting an empty
     form. Includes a "Show YAML editor" CTA when the pane is
     hidden by the current layout. */
  .yaml-only-notice {
    display: flex;
    align-items: flex-start;
    gap: var(--wa-space-s);
    padding: var(--wa-space-s) var(--wa-space-m);
    border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
    background: var(--wa-color-surface-lowered);
    border-radius: var(--wa-border-radius-m);
    color: var(--wa-color-text-normal);
    font-size: var(--wa-font-size-s);
    line-height: 1.5;
  }

  .yaml-only-notice wa-icon {
    flex-shrink: 0;
    font-size: 20px;
    color: var(--esphome-primary);
  }

  .yaml-only-notice-body {
    display: flex;
    flex-direction: column;
    gap: var(--wa-space-s);
    flex: 1;
    min-width: 0;
  }

  .yaml-only-notice p {
    margin: 0;
  }

  .yaml-only-notice-cta {
    align-self: flex-start;
    padding: var(--wa-space-2xs) var(--wa-space-m);
    border: var(--wa-border-width-s) solid var(--esphome-primary);
    border-radius: var(--wa-border-radius-m);
    background: transparent;
    color: var(--esphome-primary);
    font-family: inherit;
    font-size: inherit;
    font-weight: var(--wa-font-weight-bold);
    cursor: pointer;
    transition: background 0.12s, color 0.12s;
  }

  .yaml-only-notice-cta:hover {
    background: var(--esphome-primary);
    color: var(--esphome-on-primary);
  }
`;var eV=i(4117),eY=i(2054);let eK="[a-zA-Z_][^\\s:#]*",eW=/^[a-zA-Z_]/,eG=RegExp(`^\\s+-\\s+(${eK}):\\s*(.*)$`),eJ=/^\s+-(\s|$)/,eQ=/^[^"']*:\s*[|>][-+]?\s*(?:#.*)?$/,eX=/^[|>][-+]?$/,e0=/^\s+-\s*$/,e1=/^\s+-\s+[a-zA-Z_][\w.]*:(?:\s|$)/,e2=e=>RegExp(`^${e}(${eK}):\\s*(.*)$`),e6=e=>{let t=e.trim();return""===t||t.startsWith("#")},e3=(e,t)=>{let i=t;for(;i<e.length&&e6(e[i]);)i++;return i},e4=e=>e.match(/^ */)[0],e8=(e,t,i)=>{let o=e[t],a=i?o.indexOf("-")+1:e4(o).length,r=i?`${eY.XJ}${eY.XJ}`:eY.XJ;for(let i=t+1;i<e.length;i++){let t=e[i];if(e6(t))continue;if(eW.test(t))break;let o=e4(t);if(o.length>a)return o;break}return r},e5=(e,t)=>{let i=`${t}-`;if(!e.startsWith(i))return!1;let o=e.slice(i.length);return""===o||o.startsWith(" ")},e7=(e,t)=>{let i=e4(e);if(i.length<=t.length)return!1;let o=e.slice(i.length);return"-"===o||o.startsWith("- ")},e9=e=>e.startsWith('"')&&e.endsWith('"')||e.startsWith("'")&&e.endsWith("'")?e.slice(1,-1):e,te=e=>{let t=e9(e);return"true"===t||"false"!==t&&t},tt=e=>{let t=e.slice(1,-1).trim();return""===t?[]:t.split(",").map(e=>e9(e.trim()))},ti=(e,t,i)=>{let{dashIndent:o,firstDashIdx:a}=((e,t,i)=>{let o=t;for(;o<e.length&&e6(e[o]);)o++;return o>=e.length?{dashIndent:i,firstDashIdx:o}:{dashIndent:e[o].match(/^( *)-/)?.[1]??i,firstDashIdx:o}})(e,t,`${i}${eY.XJ}`),r=((e,t,i)=>{for(let o=t;o<e.length;o++){let t=e[o];if(e6(t))continue;let a=e4(t);if(a.length<=i.length)break;if("-"!==t[a.length])return a}return null})(e,a+1,o)??`${o}${eY.XJ}`,{endIdx:n,isComplex:s}=tr(e,t,i);if(s){let i=ta(e,t,o,r);return i?{value:i.items,endIdx:i.endIdx,isEmptyScalarList:!1}:{value:new H.ho(e.slice(t,n)),endIdx:n,isEmptyScalarList:!1}}let{items:l,endIdx:d}=((e,t,i,o)=>{let a=[],r=t;for(;r<e.length;r++){if(e6(e[r]))continue;if(!e[r].startsWith(i))break;let t=e[r].match(o);if(!t)break;a.push(e9(t[1].trim()))}return{items:a,endIdx:r}})(e,t,`${o}- `,RegExp(`^${o}-\\s+(.*)$`));return{value:l,endIdx:d,isEmptyScalarList:0===l.length}},to=(e,t)=>{var i,o;let a=e.match(t);return a?(i=a[1],o=a[2].trim(),i.includes(".")||""===o||eX.test(o)?null:{key:i,value:te(o)}):null},ta=(e,t,i,o)=>{let a=RegExp(`^${i}-\\s+(${eK}):\\s*(.*)$`),r=RegExp(`^${o}(${eK}):\\s*(.*)$`),n=t=>{let i=Object.create(null);if(!e0.test(e[t])){let o=to(e[t],a);if(!o)return null;i[o.key]=o.value}let n=((e,t,i,o,a)=>{let r=t;for(;r<e.length;){let t=e[r];if(e6(t)){r++;continue}if(!t.startsWith(i))break;if(t.startsWith(`${i} `))return null;let n=to(t,o);if(!n)return null;a[n.key]=n.value,r++}return r})(e,t+1,o,r,i);return null===n?null:{item:i,endIdx:n}},s=[],l=t;for(;l<e.length;){if(e6(e[l])){l++;continue}if(!e5(e[l],i))break;let t=n(l);if(!t)return null;s.push(t.item),l=t.endIdx}return{items:s,endIdx:l}},tr=(e,t,i)=>{let o=!1;for(let a=t;a<e.length;a++){let t=e[a];if(!e6(t)){if(t.match(/^ */)[0].length<=i.length)return{endIdx:a,isComplex:o};!o&&(eQ.test(t)||e1.test(t)||e0.test(t))&&(o=!0)}}return{endIdx:e.length,isComplex:o}};function tn(e,t,i){if(void 0!==i)return i-1;for(let i=0;i<e.length;i++)if(e[i].startsWith(`${t}:`))return i;return -1}function ts(e,t,i){let o=tn(e,t,i);if(o<0)return{start:-1,end:-1};let a=eJ.test(e[o]),r=a?(e[o].match(/^(\s*)-/)??["",""])[1].length:-1,n=e.length;for(let t=o+1;t<e.length;t++)if(a){let i=e[t].match(/^(\s*)-(\s|$)/);if(i&&i[1].length===r||eW.test(e[t])){n=t;break}}else if(eW.test(e[t])){n=t;break}return{start:o,end:n}}async function tl(e){let t=++e._loadId;e._loading=!0,e._error="",e._config=null,e._isUnknown=!1,e._setDirty(!1),e._draftTimer&&(clearTimeout(e._draftTimer),e._draftTimer=null),e._lastSelfWrittenYaml=null;try{let i=e.board?.esphome.platform,o=await (0,eV.Sn)(e._api,e.sectionKey,i);if(t!==e._loadId)return;let a=e.yaml;o?e._config={section_key:e.sectionKey,section_type:"core",title:o.name,description:o.description,docs_url:o.docs_url,icon:"",image_url:o.image_url,entries:o.config_entries}:(e._config={section_key:e.sectionKey,section_type:"core",title:e.sectionKey,description:"",docs_url:"",icon:"",image_url:"",entries:[]},e._isUnknown=!0);let r=q(a,e.sectionKey,e.fromLine),n=function(e,t,i){let o=e.split("\n"),a=Object.create(null),r=tn(o,t,i);if(r<0)return a;let n=eJ.test(o[r]),s=e8(o,r,n),l=e2(s);if(n){let e=o[r].match(eG);if(e){let t=e[2].trim();""!==t&&(a[e[1]]=te(t))}}let d=n?(o[r].match(/^(\s*)-/)??["",""])[1].length:-1;for(let e=r+1;e<o.length;e++){let t=o[e];if(e6(t))continue;if(n){let e=t.match(/^(\s*)-(\s|$)/);if(e&&e[1].length===d||eW.test(t))break}else if(eW.test(t))break;let i=t.match(l);if(!i)continue;let r=i[1],c=i[2].trim();if(eX.test(c)){let{endIdx:t}=tr(o,e+1,s);a[r]=new H.ho(o.slice(e+1,t),c),e=t-1;continue}if(""===c){let t=e3(o,e+1);if(t>=o.length)continue;let i=o[t];if(e7(i,s)){let{value:t,endIdx:i,isEmptyScalarList:n}=ti(o,e+1,s);n||(a[r]=t,e=i-1);continue}let n=e4(i);if(n.length>s.length){let t=function e(t,i,o){let a=e2(o),r=Object.create(null),n=i;for(;n<t.length;){let i=t[n];if(e6(i)){n++;continue}if(!i.startsWith(o))break;let s=i.match(a);if(!s){n++;continue}let l=s[1],d=s[2].trim();if(eX.test(d)){let{endIdx:e}=tr(t,n+1,o);r[l]=new H.ho(t.slice(n+1,e),d),n=e;continue}if(""===d){let i=e3(t,n+1);if(i<t.length&&e7(t[i],o)){let{value:e,endIdx:i}=ti(t,n+1,o);r[l]=e,n=i;continue}if(i<t.length){let a=e4(t[i]);if(a.length>o.length){let i=e(t,n+1,a);Object.keys(i.values).length>0&&(r[l]=i.values),n=i.endIdx;continue}}n++;continue}d.startsWith("[")&&d.endsWith("]")?r[l]=tt(d):r[l]=te(d),n++}return{values:r,endIdx:n}}(o,e+1,n);Object.keys(t.values).length>0&&(a[r]=t.values),e=t.endIdx-1}continue}if(c.startsWith("[")&&c.endsWith("]")){a[r]=tt(c);continue}a[r]=te(c)}return a}(a,e.sectionKey,r);e._values=function(e,t){let i=null;for(let o of t){if("hex"!==o.display_format)continue;let t=e[o.key];if("number"!=typeof t)continue;let a=ez(t);""!==a&&(null===i&&(i=Object.create(Object.getPrototypeOf(e),Object.getOwnPropertyDescriptors(e))),i[o.key]=a)}return i??e}(n,e._config.entries),e._resolvedFromLine=r,e._presentComponents=(0,H.Zn)(a)}catch(o){if(t!==e._loadId)return;let i=o instanceof Error?o.message:"";e._error=i.includes("timed out")?e._localize("device.load_config_error"):i||e._localize("device.load_config_error")}finally{t===e._loadId&&(e._loading=!1)}}function td(e){var t,i;if(e._draftTimer=null,!e._config)return;let o=(t=e.sectionKey,i=e._config.entries,eN.has(t)?eZ:i);e._fieldErrors=(0,G.JK)(o,e._values,e._presentComponents,e.board?.esphome.platform??null);let a=q(e.yaml,e.sectionKey,e.fromLine);if(void 0===a)return void e._setDirty(!1);let r=function(e,t,i,o,a={}){let r=e.split("\n"),{start:n,end:s}=ts(r,t,o);if(n<0)return e;let l=eJ.test(r[n]),d=e8(r,n,l),c=i,p=r[n];if(l){let e=p.match(eG);if(e){let t=e[1];if(Object.prototype.hasOwnProperty.call(i,t)){let e=p.match(/^(\s+)-(\s+)/),o=e[1],a=`${o}-${e[2]}`;if(function(e){if(null==e)return!1;let t=typeof e;return"string"===t||"number"===t||"boolean"===t}(i[t])){p=`${a}${t}: ${(0,H.Rm)(i[t])}`;let{[t]:e,...o}=i;c=o}else p=`${o}-`}}}let h=!l&&d?d:eY.XJ,u=[p,...(0,H.ym)(c,d,{...a,indentStep:a.indentStep??h})];return r.splice(n,s-n,...u),r.join("\n")}(e.yaml,e.sectionKey,e._values,a,{keepEmptyStrings:eU.has(e.sectionKey)});e._setDirty(!1),r!==e.yaml&&(e._lastSelfWrittenYaml=r,e.dispatchEvent(new CustomEvent("yaml-draft",{detail:{yaml:r},bubbles:!0,composed:!0})))}async function tc(e){if(!e._config)return;let t=q(e.yaml,e.sectionKey,e.fromLine);if(void 0===t){e._error=e._localize("device.section_delete_error");return}e._deleting=!0,e._error="";let i=e._config.title;try{let o=function(e,t,i){let o=e.split("\n"),{start:a,end:r}=ts(o,t,i);if(a<0)return e;let n=eJ.test(o[a]);if(o.splice(a,r-a),n){let e=a-1;for(;e>=0&&!eW.test(o[e]);)e--;if(e>=0){let t=!1,i=o.length;for(let a=e+1;a<o.length;a++){if(eW.test(o[a])){i=a;break}if(""!==o[a].trim()){t=!0;break}}t||o.splice(e,i-e)}}return o.join("\n")}(e.yaml,e.sectionKey,t);if(o===e.yaml){e._error=e._localize("device.section_delete_error");return}await e._api.updateConfig(e.configuration,o),e._setDirty(!1),e.dispatchEvent(new CustomEvent("yaml-updated",{detail:{yaml:o},bubbles:!0,composed:!0})),e.dispatchEvent(new CustomEvent("section-select",{detail:{sectionKey:null},bubbles:!0,composed:!0})),d.A.success(e._localize("device.section_deleted",{name:i}),{richColors:!0})}catch(t){e._error=t instanceof Error?t.message:e._localize("device.section_delete_error")}finally{e._deleting=!1}}function tp(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}(0,y.C)({delete:n.mdiDelete,"information-outline":n.mdiInformationOutline,"open-in-new":n.mdiOpenInNew});let th=new Set(["esphome"]);class tu extends s.WF{get _showAdvanced(){return this._advancedShownSections.has(this.sectionKey)}_setShowAdvanced(e){let t=new Set(this._advancedShownSections);e?t.add(this.sectionKey):t.delete(this.sectionKey),this._advancedShownSections=t}updated(e){(e.has("sectionKey")||e.has("configuration")||e.has("fromLine"))&&this.sectionKey&&this.configuration&&tl(this)}connectedCallback(){super.connectedCallback(),this.dispatchEvent(new CustomEvent("section-mount",{detail:{node:this},bubbles:!0,composed:!0}))}disconnectedCallback(){super.disconnectedCallback(),this._draftTimer&&(clearTimeout(this._draftTimer),this._draftTimer=null),this.dispatchEvent(new CustomEvent("section-unmount",{detail:{node:this},bubbles:!0,composed:!0}))}flushPending(){null!==this._draftTimer&&(clearTimeout(this._draftTimer),this._draftTimer=null,td(this))}reload(){this.sectionKey&&this.configuration&&null===this._draftTimer&&this.yaml!==this._lastSelfWrittenYaml&&tl(this)}get dirty(){return this._dirty}_setDirty(e){this._dirty!==e&&(this._dirty=e,this.dispatchEvent(new CustomEvent("dirty-change",{detail:{dirty:e},bubbles:!0,composed:!0})))}_scheduleDraftFlush(){this._draftTimer&&clearTimeout(this._draftTimer),this._draftTimer=setTimeout(()=>td(this),tu.DRAFT_DEBOUNCE_MS)}_onImageError(e){let t=e.target,i=(0,m.cV)("/assets/board/default.svg");t.src===window.location.origin+i||t.src.endsWith(i)||(t.src=i)}_onShowYamlEditor(){this.dispatchEvent(new CustomEvent("show-yaml-editor",{bubbles:!0,composed:!0}))}render(){var e,t,i,o;if(this._loading)return(0,s.qy)`<div class="loading"><wa-spinner></wa-spinner></div>`;if(this._error&&!this._config)return(0,s.qy)`<p class="error">${this._error}</p>`;if(!this._config)return s.s6;let a=this._showAdvanced,r=(i=this.sectionKey,o=this._config.entries,eN.has(i)?eZ:o),n=function e(t){for(let i of t)if(i.advanced||i.type===c.Hh.NESTED&&e(i.config_entries??[]))return!0;return!1}(r),l=(e=this.sectionKey,t=r.length,eB.has(e)||0===t),d=!th.has(this.sectionKey);return(0,s.qy)`
      <div class="section-header">
        <div class="section-header-info">
          <div class="section-header-title-row">
            <h3 class="section-title">
              ${this._isUnknown?this._localize("device.custom_component_title"):this._config.title}
            </h3>
            ${this._config.docs_url?(0,s.qy)`<a
                  class="docs-link"
                  href=${this._config.docs_url}
                  target="_blank"
                  rel="noreferrer"
                >
                  ${this._localize("device.docs")}
                  <wa-icon library="mdi" name="open-in-new"></wa-icon>
                </a>`:s.s6}
          </div>
          ${this._isUnknown?(0,s.qy)`<p class="section-subtitle">${this.sectionKey}</p>`:s.s6}
          ${this._config.description?(0,s.qy)`<p class="section-desc">
                ${(0,F.G)(this._config.description)}
              </p>`:s.s6}
        </div>
        ${this._isUnknown?s.s6:(0,s.qy)`<div class="section-image">
              <img
                src=${this._config.image_url||(0,m.cV)("/assets/board/default.svg")}
                alt=${this._config.title}
                referrerpolicy="no-referrer"
                @error=${this._onImageError}
              />
            </div>`}
      </div>
      ${l?(0,s.qy)`<div class="yaml-only-notice" role="note">
              <wa-icon library="mdi" name="information-outline"></wa-icon>
              <div class="yaml-only-notice-body">
                <p>${this._localize("device.yaml_only_section")}</p>
                ${this.yamlPaneVisible?s.s6:(0,s.qy)`<button
                      type="button"
                      class="yaml-only-notice-cta"
                      @click=${this._onShowYamlEditor}
                    >
                      ${this._localize("device.show_yaml_editor")}
                    </button>`}
              </div>
            </div>
            ${d?(0,s.qy)`<div class="actions">${this._renderDeleteButton()}</div>`:s.s6}`:(0,s.qy)`
            <esphome-config-entry-form
              .entries=${r}
              .values=${this._values}
              .errors=${this._fieldErrors}
              .board=${this.board}
              .yaml=${this.yaml}
              .fromLine=${this._resolvedFromLine}
              .presentComponents=${this._presentComponents}
              ?show-advanced=${a}
              @value-change=${this._onValueChange}
            ></esphome-config-entry-form>
            ${n?(0,s.qy)`<div class="advanced-toggle-row">
                  <wa-switch
                    .checked=${a}
                    @change=${e=>this._setShowAdvanced(e.target.checked)}
                  >
                    ${this._localize("device.show_advanced")}
                  </wa-switch>
                </div>`:s.s6}
            ${this._error?(0,s.qy)`<p class="error">${this._error}</p>`:s.s6}
            ${d?(0,s.qy)`<div class="actions">${this._renderDeleteButton()}</div>`:s.s6}
          `}
      ${d?(0,s.qy)`<esphome-confirm-dialog
            heading=${this._localize("device.delete_section")}
            confirm-label=${this._localize("device.delete_section")}
            message=${this._localize("device.confirm_delete_section",{name:this._config.title})}
            destructive
            @confirm=${this._onDeleteConfirmed}
          ></esphome-confirm-dialog>`:s.s6}
    `}_renderDeleteButton(){return(0,s.qy)`<button
      class="delete-button"
      ?disabled=${this._deleting}
      @click=${()=>this._confirmDialog?.open()}
    >
      <wa-icon library="mdi" name="delete"></wa-icon>
      ${this._localize("device.delete_section")}
    </button>`}constructor(...e){super(...e),this._localize=e=>e,this.configuration="",this.sectionKey="",this.yaml="",this.yamlPaneVisible=!0,this.board=null,this._config=null,this._values={},this._loading=!1,this._dirty=!1,this._error="",this._isUnknown=!1,this._fieldErrors=new Map,this._advancedShownSections=new Set,this._presentComponents=new Set,this._deleting=!1,this._loadId=0,this._draftTimer=null,this._lastSelfWrittenYaml=null,this._onValueChange=e=>(function(e,t){let{path:i,value:o}=t.detail;e._values=(0,J.Oe)(e._values,i,o),e._setDirty(!0);let a=i.join(".");if(e._fieldErrors.has(a)){let t=new Map(e._fieldErrors);t.delete(a),e._fieldErrors=t}e._scheduleDraftFlush()})(this,e),this._onDeleteConfirmed=()=>tc(this)}}function tm(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}tu.DRAFT_DEBOUNCE_MS=200,tu.styles=[u.G,I.z,eH],tp([(0,r.Fg)({context:h.$F,subscribe:!0}),(0,l.wk)()],tu.prototype,"_localize",void 0),tp([(0,r.Fg)({context:h.Ie})],tu.prototype,"_api",void 0),tp([(0,l.MZ)()],tu.prototype,"configuration",void 0),tp([(0,l.MZ)()],tu.prototype,"sectionKey",void 0),tp([(0,l.MZ)({type:Number})],tu.prototype,"fromLine",void 0),tp([(0,l.MZ)()],tu.prototype,"yaml",void 0),tp([(0,l.MZ)({type:Boolean})],tu.prototype,"yamlPaneVisible",void 0),tp([(0,l.MZ)({attribute:!1})],tu.prototype,"board",void 0),tp([(0,l.wk)()],tu.prototype,"_config",void 0),tp([(0,l.wk)()],tu.prototype,"_values",void 0),tp([(0,l.wk)()],tu.prototype,"_loading",void 0),tp([(0,l.wk)()],tu.prototype,"_dirty",void 0),tp([(0,l.wk)()],tu.prototype,"_error",void 0),tp([(0,l.wk)()],tu.prototype,"_isUnknown",void 0),tp([(0,l.wk)()],tu.prototype,"_fieldErrors",void 0),tp([(0,l.wk)()],tu.prototype,"_advancedShownSections",void 0),tp([(0,l.wk)()],tu.prototype,"_presentComponents",void 0),tp([(0,l.wk)()],tu.prototype,"_resolvedFromLine",void 0),tp([(0,l.P)("esphome-confirm-dialog")],tu.prototype,"_confirmDialog",void 0),tp([(0,l.wk)()],tu.prototype,"_deleting",void 0),tu=tp([(0,l.EM)("esphome-device-section-config")],tu),(0,y.C)({"open-in-new":n.mdiOpenInNew,memory:n.mdiMemory,"arrow-decision-outline":n.mdiArrowDecisionOutline,"arrow-left":n.mdiArrowLeft,"cog-outline":n.mdiCogOutline,close:n.mdiClose,"party-popper":n.mdiPartyPopper,"plus-circle-outline":n.mdiPlusCircleOutline});class tg extends s.WF{updated(e){if(e.has("yaml")&&this.selectedSection&&this._sectionConfig){var t,i;(this._reloadTimer&&(clearTimeout(this._reloadTimer),this._reloadTimer=null),t=e.get("yaml"),i=this.yaml,t||!i)?this._reloadTimer=setTimeout(()=>this._sectionConfig?.reload(),1e3):this._sectionConfig.reload()}}connectedCallback(){super.connectedCallback(),this.addEventListener("request-add-component",this._onRequestAddComponent)}disconnectedCallback(){super.disconnectedCallback(),this._reloadTimer&&clearTimeout(this._reloadTimer),this.removeEventListener("request-add-component",this._onRequestAddComponent)}render(){let e=this.board;return(0,s.qy)`
      ${!this.selectedSection&&e?(0,s.qy)`
            <div class="board-header">
              <div class="board-info">
                <h3 class="board-name">${e.name}</h3>
                <div class="board-tags">
                  ${e.tags.map(e=>(0,s.qy)`<wa-badge variant="brand" pill>${e}</wa-badge>`)}
                  <a
                    class="board-info-link"
                    href=${e.docs_url}
                    target="_blank"
                    rel="noreferrer"
                  >
                    ${this._localize("device.more_info")}
                    <wa-icon library="mdi" name="open-in-new"></wa-icon>
                  </a>
                </div>
                <p class="board-description">
                  ${(0,F.G)(e.description)}
                </p>
              </div>
              <div class="board-image">
                <img
                  src=${this._boardImageUrl(e)}
                  alt=${e.name}
                  referrerpolicy="no-referrer"
                  @error=${this._onImageError}
                />
              </div>
            </div>
            <div class="board-separator"></div>
          `:s.s6}
      ${this.selectedSection?(0,s.qy)`
            <esphome-device-section-config
              .configuration=${this.configuration}
              .sectionKey=${this.selectedSection}
              .fromLine=${this.selectedFromLine}
              .yaml=${this.yaml}
              .board=${this.board}
              ?yamlPaneVisible=${this.yamlPaneVisible}
            ></esphome-device-section-config>
          `:(0,s.qy)`
            ${this.justCreated?this._renderWelcomeBanner():s.s6}
            ${this._renderStepSection({title:this._localize("device.step_core"),desc:this._localize("device.step_core_desc"),icon:"cog-outline",action:this._localize("device.show_core_configuration"),section:"core"})}
            ${this._renderStepSection({title:this._localize("device.step_components"),desc:this._localize("device.step_components_desc"),icon:"memory",action:this._localize("device.show_components"),section:"components"})}
            ${this._renderStepSection({title:this._localize("device.step_automations"),desc:this._localize("device.step_automations_desc"),icon:"arrow-decision-outline",action:this._localize("device.show_automations"),section:"automations"})}
          `}

      <esphome-add-config-dialog
        .boardName=${e?.name??""}
        .configuration=${this.configuration}
        .platform=${e?.esphome.platform??""}
        .board=${e}
        .yaml=${this.yaml}
      ></esphome-add-config-dialog>
      <esphome-add-component-dialog
        .boardName=${e?.name??""}
        .configuration=${this.configuration}
        .platform=${e?.esphome.platform??""}
        .board=${e}
        .yaml=${this.yaml}
      ></esphome-add-component-dialog>
      ${s.s6}
    `}_renderStepSection(e){return(0,s.qy)`
      <div class="step-section">
        <h4 class="step-title">${e.title}</h4>
        <p class="step-desc">${e.desc}</p>
        <button
          type="button"
          class="action-item"
          @click=${()=>this._onShowNavSection(e.section)}
        >
          <div>
            <wa-icon library="mdi" name=${e.icon}></wa-icon>
            <p>${e.action}</p>
          </div>
          <wa-icon library="mdi" name="arrow-left"></wa-icon>
        </button>
      </div>
    `}_onShowNavSection(e){this.dispatchEvent(new CustomEvent("nav-section-show",{detail:{section:e},bubbles:!0,composed:!0}))}_renderWelcomeBanner(){return this.board?(0,s.qy)`
      <wa-callout class="welcome-banner" variant="brand" role="status">
        <wa-icon slot="icon" library="mdi" name="party-popper"></wa-icon>
        <p class="welcome-banner-title">
          ${this._localize("device.welcome_banner_title",{name:this.board.name})}
        </p>
        <p class="welcome-banner-text">${this._localize("device.welcome_banner_body")}</p>
        <button
          type="button"
          class="welcome-banner-close"
          aria-label=${this._localize("device.welcome_banner_dismiss")}
          @click=${this._onDismissWelcome}
        >
          <wa-icon library="mdi" name="close"></wa-icon>
        </button>
      </wa-callout>
    `:s.s6}_onDismissWelcome(){this.dispatchEvent(new CustomEvent("just-created-dismiss",{bubbles:!0,composed:!0}))}_boardImageUrl(e){return e.images.length>0?e.images[0]:(0,m.cV)("/assets/board/default.svg")}_onImageError(e){let t=e.target,i=(0,m.cV)("/assets/board/default.svg");t.src===window.location.origin+i||t.src.endsWith(i)||(t.src=i)}constructor(...e){super(...e),this._localize=e=>e,this.board=null,this.yaml="",this.configuration="",this.justCreated=!1,this.yamlPaneVisible=!0,this.selectedSection=null,this._reloadTimer=null,this._onRequestAddComponent=e=>{let t=e.detail;t?.domain&&(e.stopPropagation(),this._addComponentDialog?.openWithSearch(t.domain))}}}function tv(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}tg.styles=[u.G,(0,s.AH)`
      :host {
        display: flex;
        flex-direction: column;
      }

      .board-header {
        display: flex;
        flex-direction: row;
        align-items: center;
        width: 100%;
        gap: var(--wa-space-l);
      }

      .board-info {
        display: flex;
        flex-direction: column;
        flex: 1;
        gap: var(--wa-space-s);
        min-width: 0;
      }

      .board-name {
        margin: 0;
      }

      .board-image {
        flex-shrink: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 140px;
        height: 100px;
        padding: var(--wa-space-s);
        background: var(--wa-color-surface-lowered);
        border-radius: var(--wa-border-radius-l);
        box-sizing: border-box;
      }

      .board-image img {
        width: 100%;
        height: 100%;
        object-fit: contain;
      }

      .board-tags {
        display: flex;
        flex-wrap: wrap;
        gap: var(--wa-space-2xs);
      }

      .board-info-link {
        display: inline-flex;
        align-items: center;
        gap: var(--wa-space-2xs);
        font-size: var(--wa-font-size-xs);
        color: var(--esphome-primary);
        text-decoration: underline;
        margin-left: 10px;
      }

      .board-info-link:hover {
        text-decoration: none;
      }

      .board-description {
        margin: 0;
        font-size: var(--wa-font-size-xs);
        color: var(--wa-color-text-quiet);
        line-height: 1.5;
      }

      .board-separator {
        height: 1px;
        background-color: var(--wa-color-surface-lowered);
        width: 100%;
        margin-top: var(--wa-space-m);
      }

      /* ─── Just-created welcome banner ─── */

      .welcome-banner {
        margin-top: var(--wa-space-m);
      }

      .welcome-banner-title {
        margin: var(--wa-space-xs) 0 var(--wa-space-2xs);
        font-size: var(--wa-font-size-m);
        font-weight: var(--wa-font-weight-bold);
        color: var(--wa-color-text-normal);
      }

      .welcome-banner-text {
        margin: 0;
        font-size: var(--wa-font-size-s);
        color: var(--wa-color-text-normal);
        line-height: 1.5;
      }

      .welcome-banner-close {
        position: absolute;
        top: var(--wa-space-2xs);
        right: var(--wa-space-2xs);
        background: transparent;
        border: none;
        padding: 4px;
        cursor: pointer;
        color: var(--wa-color-text-quiet);
        border-radius: var(--wa-border-radius-s);
        transition:
          background 0.12s,
          color 0.12s;
      }

      .welcome-banner-close:hover {
        background: color-mix(in srgb, var(--esphome-primary), transparent 80%);
        color: var(--wa-color-text-normal);
      }

      .welcome-banner-close wa-icon {
        font-size: 18px;
        display: block;
      }

      /* ─── Step CTA ─── */

      .step-section {
        display: flex;
        flex-direction: column;
        gap: var(--wa-space-s);
        padding-top: var(--wa-space-m);
      }

      .step-title {
        margin: 0;
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
        color: var(--wa-color-text-normal);
      }

      .step-desc {
        margin: 0;
        font-size: var(--wa-font-size-xs);
        color: var(--wa-color-text-quiet);
        line-height: 1.5;
      }

      .action-item {
        padding: var(--wa-space-2xs) var(--wa-space-m);
        border-radius: var(--wa-border-radius-m);
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: transparent;
        color: var(--esphome-primary);
        border: var(--wa-border-width-s) solid var(--esphome-primary);
        gap: var(--wa-space-s);
        cursor: pointer;
        user-select: none;
        font-family: inherit;
        font-size: inherit;
        transition:
          background 0.12s,
          color 0.12s;
        align-self: flex-start;
        /* Equal width across the three step CTAs so they line up
           visually no matter how long the longest label is. */
        width: 280px;
        max-width: 100%;
        margin-top: var(--wa-space-s);
      }

      .action-item:hover {
        background: var(--esphome-primary);
        color: var(--esphome-on-primary);
      }

      .action-item:focus-visible {
        outline: 2px solid var(--esphome-primary);
        outline-offset: 2px;
      }

      .action-item p {
        margin: var(--wa-space-xs) 0;
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
      }

      .action-item wa-icon {
        font-size: var(--wa-font-size-l);
      }

      .action-item div {
        display: flex;
        align-items: center;
        gap: var(--wa-space-2xs);
      }
    `],tm([(0,r.Fg)({context:h.$F,subscribe:!0}),(0,l.wk)()],tg.prototype,"_localize",void 0),tm([(0,l.MZ)({attribute:!1})],tg.prototype,"board",void 0),tm([(0,l.MZ)()],tg.prototype,"yaml",void 0),tm([(0,l.MZ)()],tg.prototype,"configuration",void 0),tm([(0,l.MZ)({type:Boolean})],tg.prototype,"justCreated",void 0),tm([(0,l.MZ)({type:Boolean})],tg.prototype,"yamlPaneVisible",void 0),tm([(0,l.MZ)({attribute:!1})],tg.prototype,"selectedSection",void 0),tm([(0,l.MZ)({type:Number})],tg.prototype,"selectedFromLine",void 0),tm([(0,l.P)("esphome-device-section-config")],tg.prototype,"_sectionConfig",void 0),tm([(0,l.P)("esphome-add-component-dialog")],tg.prototype,"_addComponentDialog",void 0),tm([(0,l.P)("esphome-add-automation-dialog")],tg.prototype,"_addAutomationDialog",void 0),tm([(0,l.P)("esphome-add-config-dialog")],tg.prototype,"_addConfigDialog",void 0),tg=tm([(0,l.EM)("esphome-device-board-info")],tg),(0,y.C)({"arrow-collapse":n.mdiArrowCollapse,"arrow-expand":n.mdiArrowExpand,"check-circle-outline":n.mdiCheckCircleOutline,"content-save":n.mdiContentSave,eye:n.mdiEye,"eye-off":n.mdiEyeOff,"layout-left":n.mdiDockLeft,"layout-right":n.mdiDockRight,"layout-split":n.mdiViewSplitHorizontal,upload:n.mdiUpload,"vector-difference":n.mdiVectorDifference});class tf extends s.WF{connectedCallback(){super.connectedCallback(),this._isMobile=this._mql.matches,this._mql.addEventListener("change",this._onMqlChange),window.addEventListener("keydown",this._onGlobalKeyDown)}disconnectedCallback(){super.disconnectedCallback(),this._mql.removeEventListener("change",this._onMqlChange),window.removeEventListener("keydown",this._onGlobalKeyDown)}render(){let e,t=this._isMobile&&"both"===this.layout?"right":this.layout,i=!this._isMobile&&this.navCollapsed&&"right"===t,o=this._localize("device.editor_title_ready",{name:this.deviceTitle});return(0,s.qy)`
      <section class="card">
        <header class="card-header ${i?"card-header--compact":""}">
          <slot name="mobile-menu"></slot>
          <div class="editor-header-main">
            <h2 class="editor-header-title">${o}</h2>
          </div>
          <div class="header-actions">
            ${"left"!==t?(e=this._localize(this._revealSensitive?"device.yaml_mask_sensitive":"device.yaml_reveal_sensitive"),(0,s.qy)`<button
                    type="button"
                    class="diff-toggle"
                    aria-pressed=${this._revealSensitive}
                    aria-label=${e}
                    @click=${this._toggleRevealSensitive}
                    title=${e}
                  >
                    <wa-icon
                      library="mdi"
                      name=${this._revealSensitive?"eye-off":"eye"}
                    ></wa-icon>
                  </button>`):s.s6}
            ${this._showDiffButton?(0,s.qy)`<button
                  type="button"
                  class="diff-toggle"
                  aria-pressed=${this._showDiff}
                  ?disabled=${this.yaml===this.savedYaml&&!this._showDiff}
                  @click=${this._toggleDiff}
                  title=${this._showDiff?this._localize("device.diff_view_editor"):this._localize("device.diff_view_diff")}
                >
                  <wa-icon library="mdi" name="vector-difference"></wa-icon>
                </button>`:s.s6}
            <div
              class="layout-toggle"
              aria-label=${this._localize("device.editor_layout_label")}
            >
              <button
                type="button"
                aria-pressed=${"left"===t}
                @click=${()=>this._setLayout("left")}
                title=${this._localize("device.layout_components_only")}
              >
                <wa-icon library="mdi" name="layout-left"></wa-icon>
              </button>
              <button
                class="split-btn"
                type="button"
                aria-pressed=${"both"===t}
                @click=${()=>this._setLayout("both")}
                title=${this._localize("device.layout_split")}
              >
                <wa-icon library="mdi" name="layout-split"></wa-icon>
              </button>
              <button
                type="button"
                aria-pressed=${"right"===t}
                @click=${()=>this._setLayout("right")}
                title=${this._localize("device.layout_yaml_only")}
              >
                <wa-icon library="mdi" name="layout-right"></wa-icon>
              </button>
            </div>
            ${this._isMobile?s.s6:(0,s.qy)`<button
                  type="button"
                  class="fullscreen-toggle"
                  aria-pressed=${this._fullscreen}
                  @click=${this._toggleFullscreen}
                  title=${this._localize(this._fullscreen?"device.editor_collapse":"device.editor_expand")}
                >
                  <wa-icon
                    library="mdi"
                    name=${this._fullscreen?"arrow-collapse":"arrow-expand"}
                  ></wa-icon>
                </button>`}
          </div>
        </header>
        <div class="card-body">
          <div class="editor-floating-actions">
            ${this.hasUpdateAvailable?(0,s.qy)`<button
                  type="button"
                  class="install-fab"
                  ?disabled=${this.busy}
                  @click=${this._onUpdate}
                  title=${this._localize("dashboard.update")}
                >
                  <wa-icon library="mdi" name="upload"></wa-icon>
                  ${this._localize("dashboard.update")}
                </button>`:this.hasPendingChanges?(0,s.qy)`<button
                    type="button"
                    class="install-fab"
                    ?disabled=${this.busy}
                    @click=${this._onInstall}
                    title=${this._localize("dashboard.install")}
                  >
                    <wa-icon library="mdi" name="upload"></wa-icon>
                    ${this._localize("dashboard.install")}
                  </button>`:s.s6}
            <!-- Span wrapper carries the title because a disabled
                 button isn't focusable and most browsers won't
                 surface its tooltip on hover. The disabled state
                 is still announced via the button's own disabled
                 attribute; the span just makes the why-disabled
                 hint reachable for mouse users. -->
            <span
              class="validate-button-wrap"
              title=${this.hasUnsavedEdits?this._localize("device.validate_disabled_pending"):this._localize("device.validate_yaml")}
            >
              <button
                type="button"
                class="validate-button"
                ?disabled=${this.hasUnsavedEdits}
                @click=${this._onValidate}
              >
                <wa-icon library="mdi" name="check-circle-outline"></wa-icon>
                ${this._localize("device.validate")}
              </button>
            </span>
            <button
              type="button"
              class="save-button"
              ?disabled=${!this.hasUnsavedEdits}
              @click=${this._onSave}
              title=${this._localize("device.save_yaml")}
            >
              <wa-icon library="mdi" name="content-save"></wa-icon>
              ${this._localize("device.save")}
            </button>
          </div>
          <div class=${`editor-layout ${"both"===t?"editor-layout--both":"left"===t?"editor-layout--left":"editor-layout--right"}`}>
            <div class="editor-pane editor-pane--left">
              <esphome-device-board-info
                .board=${this.board}
                .yaml=${this.yaml}
                .configuration=${this.configuration}
                .selectedSection=${this.selectedSection}
                .selectedFromLine=${this.selectedFromLine}
                .justCreated=${this.justCreated}
                ?yamlPaneVisible=${"left"!==t}
                @show-yaml-editor=${this._onShowYamlEditor}
              ></esphome-device-board-info>
            </div>
            ${"both"===t?(0,s.qy)`<div class="pane-divider"></div>`:s.s6}
            <div class="editor-pane editor-pane--right">
              <div class="editor-pane-body">
                ${this._showDiff?(0,s.qy)`<esphome-yaml-diff
                      .oldValue=${this.savedYaml}
                      .newValue=${this.yaml}
                    ></esphome-yaml-diff>`:(0,s.qy)`<esphome-yaml-editor
                      .value=${this.yaml}
                      .configuration=${this.configuration}
                      .highlightRange=${this.highlightRange}
                      .scrollToHighlight=${this.scrollToHighlight}
                      .revealSensitive=${this._revealSensitive}
                      @yaml-change=${this._onYamlChange}
                    ></esphome-yaml-editor>`}
              </div>
            </div>
          </div>
        </div>
      </section>
    `}_onSave(){this.dispatchEvent(new CustomEvent("save-yaml",{bubbles:!0,composed:!0}))}_onValidate(){this.dispatchEvent(new CustomEvent("validate-device",{bubbles:!0,composed:!0}))}_toggleDiff(){this._showDiff=!this._showDiff}_toggleRevealSensitive(){this._revealSensitive=!this._revealSensitive}_onInstall(){this.dispatchEvent(new CustomEvent("install-device",{bubbles:!0,composed:!0}))}_onUpdate(){this.dispatchEvent(new CustomEvent("update-device",{bubbles:!0,composed:!0}))}updated(e){if(this._showDiff&&e.has("_showDiffButton")&&!this._showDiffButton){this._showDiff=!1;return}this._showDiff&&e.has("savedYaml")&&this.yaml===this.savedYaml&&(this._showDiff=!1)}_setLayout(e){this.dispatchEvent(new CustomEvent("layout-change",{detail:e,bubbles:!0,composed:!0}))}_toggleFullscreen(){this._fullscreen=!this._fullscreen}willUpdate(e){e.has("_fullscreen")&&(this.toggleAttribute("fullscreen",this._fullscreen),this._escape.set(this._fullscreen))}_onShowYamlEditor(e){e.stopPropagation(),this._setLayout("both")}_onYamlChange(e){this.dispatchEvent(new CustomEvent("yaml-change",{detail:e.detail,bubbles:!0,composed:!0}))}constructor(...e){super(...e),this._localize=e=>e,this.yaml="",this.layout="both",this.navCollapsed=!1,this.deviceTitle="",this.board=null,this.justCreated=!1,this._isMobile=!1,this._fullscreen=!1,this._mql=window.matchMedia("(max-width: 900px)"),this._onMqlChange=e=>{this._isMobile=e.matches},this._onGlobalKeyDown=e=>{(e.metaKey||e.ctrlKey)&&!e.shiftKey&&"s"===e.key.toLowerCase()&&(e.preventDefault(),this.hasUnsavedEdits&&this._onSave())},this._escape=new P.u(this,e=>{e.preventDefault(),this._fullscreen=!1}),this.highlightRange=null,this.scrollToHighlight=!1,this.configuration="",this.selectedSection=null,this.savedYaml="",this.hasUnsavedEdits=!1,this.hasPendingChanges=!1,this.hasUpdateAvailable=!1,this.busy=!1,this._showDiffButton=!1,this._showDiff=!1,this._revealSensitive=!1}}function tb(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}tf.styles=[u.G,O],tv([(0,r.Fg)({context:h.$F,subscribe:!0}),(0,l.wk)()],tf.prototype,"_localize",void 0),tv([(0,l.MZ)()],tf.prototype,"yaml",void 0),tv([(0,l.MZ)()],tf.prototype,"layout",void 0),tv([(0,l.MZ)({type:Boolean})],tf.prototype,"navCollapsed",void 0),tv([(0,l.MZ)()],tf.prototype,"deviceTitle",void 0),tv([(0,l.MZ)({attribute:!1})],tf.prototype,"board",void 0),tv([(0,l.MZ)({type:Boolean})],tf.prototype,"justCreated",void 0),tv([(0,l.wk)()],tf.prototype,"_isMobile",void 0),tv([(0,l.wk)()],tf.prototype,"_fullscreen",void 0),tv([(0,l.MZ)({attribute:!1})],tf.prototype,"highlightRange",void 0),tv([(0,l.MZ)({type:Boolean})],tf.prototype,"scrollToHighlight",void 0),tv([(0,l.MZ)()],tf.prototype,"configuration",void 0),tv([(0,l.MZ)({attribute:!1})],tf.prototype,"selectedSection",void 0),tv([(0,l.MZ)({type:Number})],tf.prototype,"selectedFromLine",void 0),tv([(0,l.MZ)({attribute:!1})],tf.prototype,"savedYaml",void 0),tv([(0,l.MZ)({type:Boolean})],tf.prototype,"hasUnsavedEdits",void 0),tv([(0,l.MZ)({type:Boolean})],tf.prototype,"hasPendingChanges",void 0),tv([(0,l.MZ)({type:Boolean})],tf.prototype,"hasUpdateAvailable",void 0),tv([(0,l.MZ)({type:Boolean})],tf.prototype,"busy",void 0),tv([(0,r.Fg)({context:h.El,subscribe:!0}),(0,l.wk)()],tf.prototype,"_showDiffButton",void 0),tv([(0,l.wk)()],tf.prototype,"_showDiff",void 0),tv([(0,l.wk)()],tf.prototype,"_revealSensitive",void 0),tf=tv([(0,l.EM)("esphome-device-editor")],tf),(0,y.C)({"chevron-down":n.mdiChevronDown,"chevron-up":n.mdiChevronUp,"chevron-right":n.mdiChevronRight,cog:n.mdiCog,"arrow-decision-outline":n.mdiArrowDecisionOutline,memory:n.mdiMemory,"plus-circle-outline":n.mdiPlusCircleOutline});class ty extends s.WF{connectedCallback(){super.connectedCallback(),this._unsubscribeCache=(0,eV.Ej)(()=>{this._cacheTick++})}disconnectedCallback(){super.disconnectedCallback(),this._unsubscribeCache?.(),this._unsubscribeCache=void 0}willUpdate(e){if((e.has("yaml")||e.has("platform"))&&this.yaml&&this._kickoffNameResolves(),(e.has("selectedKey")||e.has("yaml")||e.has("selectedFromLine"))&&this.yaml){if(!this.selectedKey){this._selectedLine=null,this._selectedRange=null;return}let e=[...z(this.yaml),...C(this.yaml)],t=(void 0!==this.selectedFromLine?e.find(e=>e.fromLine===this.selectedFromLine):void 0)??e.find(e=>E(e)===this.selectedKey);t&&(this._selectedLine=t.fromLine,this._selectedRange={fromLine:t.fromLine,toLine:t.toLine})}}render(){let{core:e,components:t,automations:i}=$(z(this.yaml)),o=[...i,...C(this.yaml)].sort((e,t)=>e.fromLine-t.fromLine),a=[{label:this._localize("device.section_core"),desc:this._localize("device.section_core_desc"),items:e,category:"core",action:{label:this._localize("device.add_config"),icon:"cog",onClick:()=>this._addConfigDialog.open()}},{label:this._localize("device.section_components"),desc:this._localize("device.section_components_desc"),items:t,category:"component",action:{label:this._localize("device.add_component"),icon:"memory",onClick:()=>this._addComponentDialog.open()}},{label:this._localize("device.section_automations"),desc:this._localize("device.section_automations_desc"),items:o,category:"automation",action:{label:this._localize("device.add_automation"),icon:"arrow-decision-outline",onClick:()=>this._addAutomationDialog.open(),disabled:!0,disabledReason:this._localize("device.add_automation_unavailable")}}];return(0,s.qy)`
      <section class="card">
        <esphome-add-config-dialog
          .boardName=${this.boardName}
          .configuration=${this.configuration}
          .platform=${this.platform}
          .board=${this.board}
          .yaml=${this.yaml}
        ></esphome-add-config-dialog>
        <esphome-add-component-dialog
          .boardName=${this.boardName}
          .configuration=${this.configuration}
          .platform=${this.platform}
          .board=${this.board}
          .yaml=${this.yaml}
        ></esphome-add-component-dialog>
        ${s.s6}
        <header class="card-header">
          <h2 class="card-title">${this._localize("device.navigator_title")}</h2>
        </header>
        <div class="card-body">
          <p class="italic">${this._localize("device.navigator_desc")}</p>
          <div class="separator"></div>
          ${a.map(({label:e,desc:t,items:i,category:o,action:a},r)=>{let n=this.openSections.has(r);return(0,s.qy)`
              <div class="nav-content" @click=${()=>this._toggleSection(r)}>
                <p>${e}</p>
                <wa-icon
                  library="mdi"
                  name=${n?"chevron-up":"chevron-down"}
                ></wa-icon>
              </div>
              ${n?(0,s.qy)`
                    <div class="separator"></div>
                    <p class="italic">${t}</p>
                    ${i.length>0?(0,s.qy)`
                          <div class="nav-items">
                            ${i.map(e=>{let{primary:t,secondary:i}=this._navItemLabels(e,o);return(0,s.qy)`
                                <div
                                  class="nav-item ${this._selectedLine===e.fromLine?"nav-item--selected":""} ${this._hoveredLine===e.fromLine?"nav-item--hovered":""}"
                                  @mouseenter=${()=>this._onItemHover(e.fromLine,e.fromLine,e.toLine)}
                                  @mouseleave=${()=>this._onItemLeave()}
                                  @click=${()=>this._onItemClick(e)}
                                >
                                  <div class="nav-item-content">
                                    <p>${t}</p>
                                    ${i?(0,s.qy)`<span class="nav-item-subtitle"
                                          >${i}</span
                                        >`:s.s6}
                                  </div>
                                  <wa-icon library="mdi" name="chevron-right"></wa-icon>
                                </div>
                              `})}
                          </div>
                        `:s.s6}
                    <div
                      class="nav-items"
                      @click=${a.disabled?void 0:()=>a.onClick()}
                    >
                      <div
                        class="action-item ${a.disabled?"action-item--disabled":""}"
                        title=${a.disabled?a.disabledReason??"":""}
                        aria-disabled=${a.disabled?"true":"false"}
                      >
                        <div>
                          <wa-icon library="mdi" name=${a.icon}></wa-icon>
                          <p>${a.label}</p>
                        </div>
                        <wa-icon library="mdi" name="plus-circle-outline"></wa-icon>
                      </div>
                    </div>
                  `:s.s6}
              <div class="separator"></div>
            `})}
        </div>
      </section>
    `}_toggleSection(e){this.dispatchEvent(new CustomEvent("section-toggle",{detail:{index:e},bubbles:!0,composed:!0}))}_kickoffNameResolves(){if(!this._api)return;let{core:e,components:t}=$(z(this.yaml)),i=this.platform||void 0;for(let o of[...e,...t]){let e=E(o);void 0===(0,eV.CQ)(e,i)&&(0,eV.Sn)(this._api,e,i).catch(()=>{})}}_navItemLabels(e,t){let i=E(e),o=i;if("automation"!==t){let e=(0,eV.CQ)(i,this.platform||void 0);e?.name&&(o=e.name)}let a=e.name||e.id,r=a&&a!==o?a:void 0;return{primary:o,secondary:r}}_onItemHover(e,t,i){this._hoveredLine=e,this._emitHighlight({fromLine:t,toLine:i},!1)}_onItemLeave(){this._hoveredLine=null,this._emitHighlight(this._selectedRange,!1)}_onItemClick(e){let{fromLine:t,toLine:i}=e,o=E(e);this._selectedLine===t?(this.selectedKey=null,this._selectedLine=null,this._selectedRange=null,this._emitHighlight(this._hoveredLine===t?{fromLine:t,toLine:i}:null,!1),this._emitSectionSelect(null,void 0)):(this.selectedKey=o,this._selectedLine=t,this._selectedRange={fromLine:t,toLine:i},this._emitHighlight({fromLine:t,toLine:i},!0),this._emitSectionSelect(o,t))}_emitHighlight(e,t){this.dispatchEvent(new CustomEvent("yaml-highlight",{detail:{range:e,scroll:t},bubbles:!0,composed:!0}))}_emitSectionSelect(e,t){this.dispatchEvent(new CustomEvent("section-select",{detail:{sectionKey:e,fromLine:t},bubbles:!0,composed:!0}))}constructor(...e){super(...e),this._localize=e=>e,this._cacheTick=0,this.openSections=new Set,this.yaml="",this.board=null,this.boardName="",this.configuration="",this.platform="",this.selectedKey=null,this._selectedLine=null,this._selectedRange=null,this._hoveredLine=null}}function tw(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}ty.styles=[u.G,(0,s.AH)`
      :host {
        display: contents;
      }

      .card {
        background: var(--wa-color-surface-default);
        border-radius: var(--navigator-border-radius, var(--wa-border-radius-l));
        border: var(--navigator-border, var(--wa-border-width-s) solid var(--wa-color-surface-border));
        box-shadow: var(--wa-elevation-02);
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }

      .card-header {
        display: flex;
        align-items: center;
        padding: var(--wa-space-s) var(--wa-space-m);
        background: var(--esphome-primary);
        color: var(--esphome-on-primary);
        flex-shrink: 0;
      }

      .card-title {
        margin: 0;
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
      }

      .card-body {
        flex: 1;
        min-height: 0;
        display: flex;
        flex-direction: column;
        overflow-y: auto;
      }

      .italic {
        font-style: italic;
        font-size: var(--wa-font-size-2xs);
        padding: 0 var(--wa-space-m);
        margin: var(--wa-space-xs) 0;
        flex-shrink: 0;
      }

      .separator {
        height: 1px;
        background: var(--wa-color-surface-border);
        margin: var(--wa-space-2xs) 0;
        flex-shrink: 0;
      }

      .nav-content {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 var(--wa-space-m);
        cursor: pointer;
        user-select: none;
        flex-shrink: 0;
      }

      .nav-content:hover p {
        color: var(--esphome-primary);
      }

      .nav-content p {
        margin: var(--wa-space-xs) 0;
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
      }

      .nav-content wa-icon {
        font-size: var(--wa-font-size-xl);
        color: var(--esphome-primary);
      }

      .nav-items {
        display: flex;
        flex-direction: column;
        gap: var(--wa-space-2xs);
        padding: var(--wa-space-xs) var(--wa-space-m);
      }

      .nav-item {
        padding: 0 var(--wa-space-2xs);
        border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
        border-radius: var(--wa-border-radius-m);
        display: flex;
        align-items: center;
        justify-content: space-between;
        cursor: pointer;
        user-select: none;
        transition:
          background 0.1s,
          border-color 0.1s;
      }

      .nav-item:hover,
      .nav-item--hovered {
        background: color-mix(in srgb, var(--esphome-primary), transparent 88%);
        border-color: var(--esphome-primary);
      }

      .nav-item--selected {
        background: color-mix(in srgb, var(--esphome-primary), transparent 88%);
        border-color: var(--esphome-primary);
      }

      .nav-item-content {
        display: flex;
        flex-direction: column;
        min-width: 0;
        padding: var(--wa-space-xs) 0;
      }

      .nav-item-content p {
        margin: 0;
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
      }

      .nav-item-subtitle {
        font-size: var(--wa-font-size-2xs);
        color: var(--wa-color-text-quiet);
        font-weight: normal;
        margin: 0;
        line-height: 1.2;
      }

      .nav-item wa-icon {
        font-size: var(--wa-font-size-xl);
        color: var(--esphome-primary);
      }

      .action-item {
        padding: 0 var(--wa-space-2xs);
        border-radius: var(--wa-border-radius-m);
        display: flex;
        align-items: center;
        background: var(--esphome-primary);
        color: var(--esphome-on-primary);
        justify-content: space-between;
        cursor: pointer;
        user-select: none;
        transition:
          background 0.1s,
          border-color 0.1s;
      }

      .action-item:hover,
      .action-item--hovered {
        opacity: 0.9;
      }

      /* Disabled action: greyed out, no hover, no pointer. The wrapper
         drops its click handler so the underlying dialog is never
         opened — this is purely visual confirmation. */
      .action-item--disabled,
      .action-item--disabled:hover {
        background: var(--wa-color-surface-lowered);
        color: var(--wa-color-text-quiet);
        cursor: not-allowed;
        opacity: 0.65;
      }

      .action-item--disabled wa-icon {
        color: var(--wa-color-text-quiet);
      }

      .action-item p {
        margin: var(--wa-space-xs) 0;
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
      }

      .action-item wa-icon {
        font-size: var(--wa-font-size-l);
      }

      .action-item div {
        display: flex;
        flex-direction: wrap;
        align-items: center;
        gap: var(--wa-space-2xs);
      }
    `],tb([(0,r.Fg)({context:h.$F,subscribe:!0}),(0,l.wk)()],ty.prototype,"_localize",void 0),tb([(0,r.Fg)({context:h.Ie})],ty.prototype,"_api",void 0),tb([(0,l.wk)()],ty.prototype,"_cacheTick",void 0),tb([(0,l.MZ)({attribute:!1})],ty.prototype,"openSections",void 0),tb([(0,l.MZ)({attribute:!1})],ty.prototype,"yaml",void 0),tb([(0,l.MZ)({attribute:!1})],ty.prototype,"board",void 0),tb([(0,l.MZ)()],ty.prototype,"boardName",void 0),tb([(0,l.MZ)()],ty.prototype,"configuration",void 0),tb([(0,l.MZ)()],ty.prototype,"platform",void 0),tb([(0,l.P)("esphome-add-config-dialog")],ty.prototype,"_addConfigDialog",void 0),tb([(0,l.P)("esphome-add-component-dialog")],ty.prototype,"_addComponentDialog",void 0),tb([(0,l.P)("esphome-add-automation-dialog")],ty.prototype,"_addAutomationDialog",void 0),tb([(0,l.MZ)({attribute:!1})],ty.prototype,"selectedKey",void 0),tb([(0,l.MZ)({attribute:!1})],ty.prototype,"selectedFromLine",void 0),tb([(0,l.wk)()],ty.prototype,"_selectedLine",void 0),tb([(0,l.wk)()],ty.prototype,"_selectedRange",void 0),tb([(0,l.wk)()],ty.prototype,"_hoveredLine",void 0),ty=tb([(0,l.EM)("esphome-device-navigator")],ty),i(536),i(9137),i(7157),(0,y.C)({"alert-outline":n.mdiAlertOutline,"content-save":n.mdiContentSave});class t_ extends s.WF{open(){this._resolved=!1,this._dialog.open=!0}close(){this._dialog.open=!1}render(){return(0,s.qy)`
      <wa-dialog light-dismiss @wa-after-hide=${this._onAfterHide}>
        <div class="body">
          <div class="icon-wrap">
            <wa-icon library="mdi" name="alert-outline"></wa-icon>
          </div>
          <div class="text">
            <h2 class="heading">${this._localize("device.unsaved_title")}</h2>
            <p class="message">${this._localize("device.unsaved_message")}</p>
          </div>
        </div>
        <div class="actions">
          <button class="btn btn--ghost" @click=${this.close}>
            ${this._localize("layout.cancel")}
          </button>
          <button class="btn btn--discard" @click=${this._onDiscard}>
            ${this._localize("device.discard_changes")}
          </button>
          <button class="btn btn--save" @click=${this._onSave}>
            <wa-icon library="mdi" name="content-save"></wa-icon>
            ${this._localize("device.save_and_leave")}
          </button>
        </div>
      </wa-dialog>
    `}_onDiscard(){this._resolved=!0,this.close(),this.dispatchEvent(new CustomEvent("discard",{bubbles:!0,composed:!0}))}_onSave(){this._resolved=!0,this.close(),this.dispatchEvent(new CustomEvent("save",{bubbles:!0,composed:!0}))}_onAfterHide(){this._resolved||this.dispatchEvent(new CustomEvent("cancel",{bubbles:!0,composed:!0}))}constructor(...e){super(...e),this._localize=e=>e,this._resolved=!1}}t_.styles=[u.G,(0,s.AH)`
      wa-dialog {
        --width: 460px;
      }

      wa-dialog::part(header),
      wa-dialog::part(footer) {
        display: none;
      }

      wa-dialog::part(body) {
        padding: 0;
      }

      .body {
        display: flex;
        gap: var(--wa-space-m);
        padding: var(--wa-space-l) var(--wa-space-l) var(--wa-space-m);
      }

      .icon-wrap {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 44px;
        height: 44px;
        border-radius: 50%;
        flex-shrink: 0;
        background: color-mix(in srgb, var(--esphome-warning), transparent 85%);
        color: var(--esphome-warning);
      }

      .icon-wrap wa-icon {
        font-size: 24px;
      }

      .text {
        flex: 1;
        min-width: 0;
      }

      .heading {
        margin: 0 0 var(--wa-space-2xs);
        font-size: var(--wa-font-size-m);
        font-weight: var(--wa-font-weight-bold);
        color: var(--wa-color-text-normal);
      }

      .message {
        margin: 0;
        font-size: var(--wa-font-size-s);
        color: var(--wa-color-text-quiet);
        line-height: 1.5;
      }

      .actions {
        display: flex;
        justify-content: flex-end;
        gap: var(--wa-space-xs);
        padding: var(--wa-space-s) var(--wa-space-m) var(--wa-space-m);
      }

      .btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 16px;
        border-radius: var(--wa-border-radius-m);
        font-size: var(--wa-font-size-s);
        font-weight: var(--wa-font-weight-bold);
        font-family: inherit;
        cursor: pointer;
        border: none;
        transition: background 0.12s, color 0.12s;
      }

      .btn--ghost {
        background: transparent;
        color: var(--wa-color-text-quiet);
      }

      .btn--ghost:hover {
        background: var(--wa-color-surface-lowered);
        color: var(--wa-color-text-normal);
      }

      .btn--discard {
        background: transparent;
        color: var(--esphome-error);
      }

      .btn--discard:hover {
        background: color-mix(in srgb, var(--esphome-error), transparent 92%);
      }

      .btn--save {
        background: var(--esphome-primary);
        color: var(--esphome-on-primary);
        box-shadow: 0 1px 2px color-mix(in srgb, var(--esphome-primary), transparent 70%);
      }

      .btn--save:hover {
        background: color-mix(in srgb, var(--esphome-primary), black 10%);
      }

      .btn wa-icon {
        font-size: 16px;
      }
    `],tw([(0,r.Fg)({context:h.$F,subscribe:!0}),(0,l.wk)()],t_.prototype,"_localize",void 0),tw([(0,l.P)("wa-dialog")],t_.prototype,"_dialog",void 0),t_=tw([(0,l.EM)("esphome-unsaved-changes-dialog")],t_);var tx=i(2293),t$=i(6029);function tk(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}(0,y.C)({"alert-outline":n.mdiAlertOutline});class tz extends s.WF{open(){this._resolvedExit=null,this._dialog.open=!0}close(){this._dialog.open=!1}render(){let e=1===this.errorCount?"device.yaml_invalid_message_singular":"device.yaml_invalid_message_plural",t=this._localize(e,{count:String(this.errorCount)}),i=this.firstErrorLine>0;return(0,s.qy)`
      <wa-dialog
        label=${this._localize("device.yaml_invalid_title")}
        light-dismiss
        @wa-after-hide=${this._onAfterHide}
      >
        <div class="body">
          <div class="icon-wrap">
            <wa-icon library="mdi" name="alert-outline"></wa-icon>
          </div>
          <div class="text">
            ${t}
            ${this.firstErrorMessage?(0,s.qy)`<div class="first-error">${this.firstErrorMessage}</div>`:s.s6}
          </div>
        </div>
        <div class="actions">
          <button class="btn btn--cancel" @click=${this.close}>
            ${this._localize("layout.cancel")}
          </button>
          <button
            class="btn btn--goto"
            ?disabled=${!i}
            @click=${this._goto}
          >
            ${this._localize("device.yaml_invalid_go_to_error")}
          </button>
          <button class="btn btn--save-anyway" @click=${this._saveAnyway}>
            ${this._localize("device.yaml_invalid_save_anyway")}
          </button>
        </div>
      </wa-dialog>
    `}_goto(){this._resolvedExit="goto",this.close(),this.dispatchEvent(new CustomEvent("goto",{detail:{line:this.firstErrorLine,col:this.firstErrorCol},bubbles:!0,composed:!0}))}_saveAnyway(){this._resolvedExit="save-anyway",this.close(),this.dispatchEvent(new CustomEvent("save-anyway",{bubbles:!0,composed:!0}))}_onAfterHide(){null===this._resolvedExit&&this.dispatchEvent(new CustomEvent("cancel",{bubbles:!0,composed:!0}))}constructor(...e){super(...e),this._localize=e=>e,this.errorCount=0,this.firstErrorLine=0,this.firstErrorCol=0,this.firstErrorMessage="",this._resolvedExit=null}}function tC(e,t,i,o){var a,r=arguments.length,n=r<3?t:null===o?o=Object.getOwnPropertyDescriptor(t,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(e,t,i,o);else for(var s=e.length-1;s>=0;s--)(a=e[s])&&(n=(r<3?a(n):r>3?a(t,i,n):a(t,i))||n);return r>3&&n&&Object.defineProperty(t,i,n),n}tz.styles=[u.G,t$.W,tx.h,(0,s.AH)`
      wa-dialog {
        --width: 480px;
      }

      .icon-wrap {
        background: color-mix(in srgb, var(--esphome-error), transparent 88%);
        color: var(--esphome-error);
      }

      .first-error {
        margin-top: var(--wa-space-xs);
        font-family: var(--wa-font-family-code);
        font-size: var(--wa-font-size-2xs);
        color: var(--wa-color-text-normal);
        background: var(--wa-color-surface-lowered);
        border: var(--wa-border-width-s) solid var(--wa-color-surface-border);
        border-radius: var(--wa-border-radius-s);
        padding: var(--wa-space-xs) var(--wa-space-s);
        white-space: pre-wrap;
        word-break: break-word;
      }

      .btn--goto {
        background: var(--esphome-primary);
        color: var(--esphome-on-primary);
      }

      .btn--goto:hover:not(:disabled) {
        background: color-mix(in srgb, var(--esphome-primary), black 10%);
      }

      .btn--save-anyway {
        background: var(--esphome-error);
        color: var(--esphome-on-primary);
      }

      .btn--save-anyway:hover {
        background: color-mix(in srgb, var(--esphome-error), black 10%);
      }
    `],tk([(0,r.Fg)({context:h.$F,subscribe:!0}),(0,l.wk)()],tz.prototype,"_localize",void 0),tk([(0,l.MZ)({type:Number})],tz.prototype,"errorCount",void 0),tk([(0,l.MZ)({type:Number})],tz.prototype,"firstErrorLine",void 0),tk([(0,l.MZ)({type:Number})],tz.prototype,"firstErrorCol",void 0),tk([(0,l.MZ)()],tz.prototype,"firstErrorMessage",void 0),tk([(0,l.P)("wa-dialog")],tz.prototype,"_dialog",void 0),tz=tk([(0,l.EM)("esphome-yaml-validation-dialog")],tz),(0,y.C)({"arrow-collapse-left":n.mdiArrowCollapseLeft,"arrow-collapse-right":n.mdiArrowCollapseRight});class tS extends s.WF{get _device(){return this._devices.find(e=>e.configuration===this.id)??null}_createInstallController(){let e=this;return new p({addController:t=>e.addController(t),removeController:t=>e.removeController(t),requestUpdate:()=>e.requestUpdate(),get updateComplete(){return e.updateComplete},get device(){return e._device},get commandDialog(){return e._commandDialog??null},get firmwareDialog(){return e._firmwareDialog??null}})}get _isYamlDirty(){return this._yaml!==this._savedYaml}get _isDirty(){return this._isYamlDirty||this._sectionDirty}async connectedCallback(){super.connectedCallback(),this._loadPreferences(),(0,v.f)(this._confirmLeave),window.addEventListener("beforeunload",this._onBeforeUnload),window.addEventListener("popstate",this._onPopState,{capture:!0}),window.addEventListener("keydown",this._onKeydown)}disconnectedCallback(){super.disconnectedCallback(),(0,v.f)(null),window.removeEventListener("beforeunload",this._onBeforeUnload),window.removeEventListener("popstate",this._onPopState,{capture:!0}),window.removeEventListener("keydown",this._onKeydown),this._unsavedGuard.cancelPending()}_isTextEntry(e){if(!e)return!1;let t=e.tagName;if("INPUT"===t||"TEXTAREA"===t||"SELECT"===t||e.isContentEditable)return!0;let i=e;for(;i;){if("ESPHOME-YAML-EDITOR"===i.tagName)return!0;i=i.parentElement}return!1}updated(e){e.has("id")&&this.id&&(this._justCreated=(0,g.RI)(this.id),this._loadedBoardId=null,this._board=null,this._loadYaml());let t=this._device?.board_id??null;t&&t!==this._loadedBoardId?(this._loadedBoardId=t,this._loadBoard(t)):!t&&null!==this._loadedBoardId&&this._board&&(this._loadedBoardId=null,this._board=null)}async _loadPreferences(){let e=localStorage.getItem("esphome-editor-layout");("both"===e||"left"===e||"right"===e)&&(this._layout=e);try{let e=await this._api.getPreferences();this._navCollapsed=!e.navigator_visible}catch{}}async _loadBoard(e){try{let t=await this._api.getBoard(e);this._loadedBoardId===e&&(this._board=t)}catch(e){console.error("Failed to load board:",e)}}async _loadYaml(){try{let e=await this._api.getConfig(this.id);this._yaml=e,this._savedYaml=e,this._maybeResolveLineFromUrl()}catch(e){console.error("Failed to load YAML:",e)}}_maybeResolveLineFromUrl(){let e=L(this._yaml,this._selectedFromLine,this._selectedSection);e&&(this._selectedSection=e.sectionKey,this._highlightRange=e.range,this._scrollToHighlight=!0)}_resolveValidationPrompt(e){let t=this._pendingValidationResolve;this._pendingValidationResolve=null,t?.(e)}render(){let e=this._device?.friendly_name||this._device?.name||this.id||this._localize("dashboard.create_device");return(0,s.qy)`
      <!-- Mobile drawer -->
      <div
        class="drawer-backdrop ${this._drawerOpen?"drawer-backdrop--open":""}"
        @click=${()=>{this._drawerOpen=!1}}
      ></div>
      <div
        class="drawer ${this._drawerOpen?"drawer--open":""}"
        @section-toggle=${this._onSectionToggle}
        @section-select=${this._onSectionSelect}
        @yaml-highlight=${this._onYamlHighlight}
      >
        ${this._renderNavigator("drawer-nav")}
      </div>

      <div class="page">
        <div
          class="layout-grid ${this._navCollapsed?"nav-collapsed":""}"
          @section-toggle=${this._onSectionToggle}
          @layout-change=${this._onLayoutChange}
          @yaml-change=${this._onYamlChange}
          @yaml-cursor-line=${this._onYamlCursorLine}
          @yaml-highlight=${this._onYamlHighlight}
          @yaml-updated=${this._onYamlUpdated}
          @yaml-draft=${this._onYamlDraft}
          @section-select=${this._onSectionSelect}
          @section-mount=${this._onSectionMount}
          @section-unmount=${this._onSectionUnmount}
          @dirty-change=${this._onSectionDirtyChange}
          @nav-section-show=${this._onNavSectionShow}
          @save-yaml=${this._saveYaml}
          @validate-device=${this._onValidateClick}
          @install-device=${this._installCtrl.onInstall}
          @update-device=${this._installCtrl.onUpdate}
        >
          ${this._renderNavigator("desktop-nav")}
          <esphome-device-editor
            .yaml=${this._yaml}
            .savedYaml=${this._savedYaml}
            .layout=${this._layout}
            ?navCollapsed=${this._navCollapsed}
            .deviceTitle=${e}
            .board=${this._board}
            .highlightRange=${this._highlightRange}
            .scrollToHighlight=${this._scrollToHighlight}
            .configuration=${this.id}
            .selectedSection=${this._selectedSection}
            .selectedFromLine=${this._selectedFromLine}
            .justCreated=${this._justCreated}
            @just-created-dismiss=${this._dismissJustCreated}
            ?hasUnsavedEdits=${this._isDirty}
            ?hasPendingChanges=${this._device?.has_pending_changes===!0}
            ?hasUpdateAvailable=${this._device?.update_available===!0}
            ?busy=${this._activeJobs.has(this.id)}
          >
            <button slot="mobile-menu" class="nav-toggle-btn" @click=${this._onNavToggle}>
              <wa-icon library="mdi" name=${this._navToggleIcon}></wa-icon>
            </button>
          </esphome-device-editor>
        </div>
      </div>
      <esphome-unsaved-changes-dialog
        @discard=${this._onUnsavedDiscard}
        @save=${this._onUnsavedSave}
        @cancel=${this._onUnsavedCancel}
      ></esphome-unsaved-changes-dialog>
      <esphome-command-dialog
        @request-show-logs-after-install=${this._onPostInstallShowLogs}
        @request-open-editor=${this._onRequestOpenEditor}
      ></esphome-command-dialog>
      <esphome-firmware-install-dialog
        @request-show-logs-after-install=${this._onPostInstallShowLogs}
        @clean-build=${this._onCleanBuild}
        @request-open-editor=${this._onRequestOpenEditor}
      ></esphome-firmware-install-dialog>
      <esphome-logs-dialog></esphome-logs-dialog>
      <esphome-install-method-dialog
        ?open=${this._installCtrl.installMethodOpen}
        .deviceState=${this._installCtrl.deviceState}
        .deviceTargetPlatform=${this._installCtrl.deviceTargetPlatform}
        .deviceCurrentAddress=${this._installCtrl.deviceCurrentAddress}
        @close=${this._installCtrl.onInstallMethodClose}
        @select-method=${this._installCtrl.onInstallMethodSelect}
      ></esphome-install-method-dialog>
      <esphome-yaml-validation-dialog
        .errorCount=${this._validationErrorCount}
        .firstErrorLine=${this._validationFirstLine}
        .firstErrorCol=${this._validationFirstCol}
        .firstErrorMessage=${this._validationFirstMessage}
        @save-anyway=${this._onValidationSaveAnyway}
        @goto=${this._onValidationGoTo}
        @cancel=${this._onValidationCancel}
      ></esphome-yaml-validation-dialog>
    `}get _isMobile(){return window.matchMedia("(max-width: 900px)").matches}get _navToggleIcon(){return this._isMobile||this._navCollapsed?"arrow-collapse-right":"arrow-collapse-left"}_onNavToggle(){this._isMobile?this._drawerOpen=!this._drawerOpen:(this._navCollapsed=!this._navCollapsed,this._api.updatePreferences({navigator_visible:!this._navCollapsed}).catch(()=>{}))}_onSectionToggle(e){let{index:t}=e.detail,i=new Set;this._openSections.has(t)||i.add(t),this._openSections=i,this._updateUrl()}_onNavSectionShow(e){let t={core:0,components:1,automations:2}[e.detail.section];if(void 0===t)return;let i=new Set([t]);this._openSections=i,this._updateUrl(),this._drawerOpen=!0,this._navCollapsed&&(this._navCollapsed=!1,this._api.updatePreferences({navigator_visible:!0}).catch(()=>{}))}_onLayoutChange(e){this._layout=e.detail,localStorage.setItem("esphome-editor-layout",e.detail)}_renderNavigator(e){return(0,s.qy)`<esphome-device-navigator
      class=${e}
      .openSections=${this._openSections}
      .yaml=${this._yaml}
      .board=${this._board}
      .boardName=${this._board?.name??""}
      .configuration=${this.id}
      .platform=${this._board?.esphome.platform??""}
      .selectedKey=${this._selectedSection}
      .selectedFromLine=${this._selectedFromLine}
    ></esphome-device-navigator>`}_onYamlChange(e){this._yaml=e.detail.value}_onYamlCursorLine(e){let t=S(this._yaml,e.detail.line);if(!t)return;let i=E(t);(i!==this._selectedSection||t.fromLine!==this._selectedFromLine)&&this._guardSectionSwitch(()=>{this._selectedSection=i,this._selectedFromLine=t.fromLine,this._updateUrl()})}_onYamlHighlight(e){this._highlightRange=e.detail.range,this._scrollToHighlight=e.detail.scroll}_onYamlUpdated(e){this._yaml=e.detail.yaml,this._savedYaml=e.detail.yaml}_onYamlDraft(e){this._yaml=e.detail.yaml}_onSectionSelect(e){let{sectionKey:t,fromLine:i}=e.detail;if(t===this._selectedSection&&i===this._selectedFromLine){this._drawerOpen=!1;return}this._guardSectionSwitch(()=>{this._selectedSection=t,this._selectedFromLine=i,this._drawerOpen=!1,this._updateUrl()})}_guardSectionSwitch(e){this._activeSection?.flushPending(),e()}_readUrlParam(e,t){return new URLSearchParams(window.location.search).get(e)??t}_readUrlLine(){let e=new URLSearchParams(window.location.search).get("line");if(!e)return;let t=Number(e);return Number.isNaN(t)?void 0:t}_readUrlSections(){let e=new URLSearchParams(window.location.search).get("open");return e?e.split(",").map(Number).filter(e=>!Number.isNaN(e)):[]}_updateUrl(){let e=new URLSearchParams(window.location.search);this._selectedSection?(e.set("section",this._selectedSection),void 0!==this._selectedFromLine?e.set("line",String(this._selectedFromLine)):e.delete("line")):(e.delete("section"),e.delete("line")),this._openSections.size>0?e.set("open",[...this._openSections].join(",")):e.delete("open");let t=e.toString(),i=`${window.location.pathname}${t?`?${t}`:""}`;window.history.replaceState(null,"",i)}constructor(...e){super(...e),this._localize=e=>e,this._devices=[],this._activeJobs=new Map,this.id="",this._justCreated=!1,this._layout="both",this._openSections=new Set(this._readUrlSections()),this._board=null,this._loadedBoardId=null,this._highlightRange=null,this._scrollToHighlight=!1,this._selectedSection=this._readUrlParam("section",null),this._selectedFromLine=this._readUrlLine(),this._drawerOpen=!1,this._navCollapsed=!1,this._yaml="",this._savedYaml="",this._activeSection=null,this._sectionDirty=!1,this._validationErrorCount=0,this._validationFirstLine=0,this._validationFirstCol=0,this._validationFirstMessage="",this._onPostInstallShowLogs=(0,f.ei)(()=>this._logsDialog,()=>this._localize),this._installCtrl=this._createInstallController(),this._unsavedGuard=new b,this._allowingLeave=!1,this._onUnsavedDiscard=()=>this._unsavedGuard.onDiscard(),this._onUnsavedSave=()=>this._unsavedGuard.onSave(),this._onUnsavedCancel=()=>this._unsavedGuard.onCancel(),this._confirmLeave=async()=>{this._activeSection?.flushPending();let e=await this._unsavedGuard.run({dirty:this._isDirty,open:()=>this._unsavedDialog?.open(),save:async()=>(!this._isYamlDirty||!!await this._saveYaml())&&(this._allowingLeave=!0,!0)});return e&&(this._allowingLeave=!0),e},this._onBeforeUnload=e=>{this._activeSection?.flushPending(),this._isDirty&&(e.preventDefault(),e.returnValue="")},this._onPopState=e=>{if(this._allowingLeave){this._allowingLeave=!1;return}this._activeSection?.flushPending(),this._isDirty&&(e.stopImmediatePropagation(),window.history.pushState({},"",(0,m.cV)(`/device/${this.id}`)),this._confirmLeave().then(e=>{e&&(this._allowingLeave=!0,window.history.back())}))},this._onKeydown=e=>{if("Escape"!==e.key||e.defaultPrevented)return;let t=e.composedPath()[0];if(!this._isTextEntry(t)){if(this._drawerOpen){e.preventDefault(),this._drawerOpen=!1;return}e.preventDefault(),window.history.back()}},this._dismissJustCreated=()=>{this._justCreated=!1},this._pendingValidationResolve=null,this._saveYaml=async()=>{if(this._activeSection?.flushPending(),!this._isYamlDirty)return!0;if(this.id)try{let e=await this._api.validateYaml(this.id,this._yaml),t=function(e){let t=e.yaml_errors??[],i=e.validation_errors??[],o=t.length+i.length;if(0===o)return{count:0,first:null};if(t.length>0){let e=(t[0].message??"").trim(),i=0,a=0,r=e.match(M);if(r)i=Number.parseInt(r[1],10),a=Number.parseInt(r[2],10);else{let t=e.match(A);t&&(i=Number.parseInt(t[1],10))}return(!Number.isFinite(i)||i<1)&&(i=0),(!Number.isFinite(a)||a<1)&&(a=0),{count:o,first:{line:i,col:a,message:e||"Invalid YAML"}}}let a=i[0],r=Math.max(1,(a.range?.start_line??0)+1),n=Math.max(1,(a.range?.start_col??0)+1);return{count:o,first:{line:r,col:n,message:(a.message??"Invalid configuration").trim()}}}(e);if(t.count>0)return this._validationErrorCount=t.count,this._validationFirstLine=t.first?.line??0,this._validationFirstCol=t.first?.col??0,this._validationFirstMessage=t.first?.message??"",this._pendingValidationResolve?.(!1),new Promise(e=>{this._pendingValidationResolve=e,this._yamlValidationDialog.open()})}catch(e){console.debug("[save-yaml] validate_yaml failed, saving anyway:",e)}return this._doSaveYaml()},this._doSaveYaml=async()=>{let e=this._savedYaml;this._savedYaml=this._yaml;let t=!0;try{await this._api.updateConfig(this.id,this._yaml)}catch(i){(i instanceof Error?i.message:"").includes("timed out")||(t=!1,this._savedYaml=e,console.error("Failed to save YAML:",i))}let i=t?"device.yaml_saved":"device.yaml_save_error";return(t?d.A.success:d.A.error)(this._localize(i),{richColors:!0}),t},this._onValidationSaveAnyway=async()=>{let e=await this._doSaveYaml();this._resolveValidationPrompt(e)},this._onValidationGoTo=e=>{let t=e.detail.line;if(t&&t>=1){"left"===this._layout&&(this._layout="both",localStorage.setItem("esphome-editor-layout","both")),this._highlightRange={fromLine:t,toLine:t},this._scrollToHighlight=!0;let e=L(this._yaml,t,null);e&&(this._selectedSection=e.sectionKey)}this._resolveValidationPrompt(!1)},this._onValidationCancel=()=>{this._resolveValidationPrompt(!1)},this._onValidateClick=()=>{this._device&&(this._commandDialog.configuration=this._device.configuration,this._commandDialog.name=this._device.friendly_name||this._device.name,this._commandDialog.open("validate"))},this._onCleanBuild=e=>{let t=e.detail;this._commandDialog.configuration=t.configuration,this._commandDialog.name=t.friendly_name||t.name,this._commandDialog.open("clean")},this._onRequestOpenEditor=e=>{e.stopPropagation(),e.detail.configuration!==this._device?.configuration&&(0,v.o)(`/device/${encodeURIComponent(e.detail.configuration)}`)},this._onSectionMount=e=>{this._activeSection=e.detail.node,this._sectionDirty=e.detail.node.dirty},this._onSectionUnmount=e=>{this._activeSection===e.detail.node&&(this._activeSection=null,this._sectionDirty=!1)},this._onSectionDirtyChange=e=>{this._sectionDirty=e.detail.dirty}}}tS.styles=[u.G,D],tC([(0,r.Fg)({context:h.$F,subscribe:!0}),(0,l.wk)()],tS.prototype,"_localize",void 0),tC([(0,r.Fg)({context:h.xJ,subscribe:!0}),(0,l.wk)()],tS.prototype,"_devices",void 0),tC([(0,r.Fg)({context:h.Ie})],tS.prototype,"_api",void 0),tC([(0,r.Fg)({context:h.EM,subscribe:!0}),(0,l.wk)()],tS.prototype,"_activeJobs",void 0),tC([(0,l.MZ)()],tS.prototype,"id",void 0),tC([(0,l.wk)()],tS.prototype,"_justCreated",void 0),tC([(0,l.wk)()],tS.prototype,"_layout",void 0),tC([(0,l.wk)()],tS.prototype,"_openSections",void 0),tC([(0,l.wk)()],tS.prototype,"_board",void 0),tC([(0,l.wk)()],tS.prototype,"_highlightRange",void 0),tC([(0,l.wk)()],tS.prototype,"_scrollToHighlight",void 0),tC([(0,l.wk)()],tS.prototype,"_selectedSection",void 0),tC([(0,l.wk)()],tS.prototype,"_selectedFromLine",void 0),tC([(0,l.wk)()],tS.prototype,"_drawerOpen",void 0),tC([(0,l.wk)()],tS.prototype,"_navCollapsed",void 0),tC([(0,l.wk)()],tS.prototype,"_yaml",void 0),tC([(0,l.wk)()],tS.prototype,"_savedYaml",void 0),tC([(0,l.P)("esphome-unsaved-changes-dialog")],tS.prototype,"_unsavedDialog",void 0),tC([(0,l.wk)()],tS.prototype,"_sectionDirty",void 0),tC([(0,l.P)("esphome-command-dialog")],tS.prototype,"_commandDialog",void 0),tC([(0,l.P)("esphome-firmware-install-dialog")],tS.prototype,"_firmwareDialog",void 0),tC([(0,l.P)("esphome-logs-dialog")],tS.prototype,"_logsDialog",void 0),tC([(0,l.P)("esphome-yaml-validation-dialog")],tS.prototype,"_yamlValidationDialog",void 0),tC([(0,l.wk)()],tS.prototype,"_validationErrorCount",void 0),tC([(0,l.wk)()],tS.prototype,"_validationFirstLine",void 0),tC([(0,l.wk)()],tS.prototype,"_validationFirstCol",void 0),tC([(0,l.wk)()],tS.prototype,"_validationFirstMessage",void 0),tS=tC([(0,l.EM)("esphome-page-device")],tS)}}]);
//# sourceMappingURL=772.6275ca4f1a51e57d.js.map