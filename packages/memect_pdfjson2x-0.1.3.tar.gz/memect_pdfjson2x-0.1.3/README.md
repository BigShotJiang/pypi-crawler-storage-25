# docJson2X

docJson2X is a tool to convert docJson to Markdown or CSV, or Html.

- to_md/to_md_with_id

- to_csv

## Usage

```bash
uv build
# upload memect pypi source
uv publish --index memect

# 公共 PyPI 安装（distribution 名为 memect-pdfjson2x，import 仍为 docjson2x）
pip install memect-pdfjson2x


from docjson2x import DocJsonAnalyzer
# eg: 
input_file_paht = "tests/data/doc.json"
analyzer = DocJsonAnalyzer().analyze(input_file_paht)

# output to markdown，默认table为md格式输出
output_file_path = "tests/data/doc.md"
analyzer.to_md(output_file_path)
## markdown支持table为html
analyzer.to_md(output_file_path, table_html=True)

```