#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@File    :   test_doc_json2x.py
@Time    :   2025/06/17 11:13:38
@Author  :   Mason
@Version :   1.0
@Desc    :   docjson2x单元测试
"""

import pytest
from src.docjson2x import DocJsonAnalyzer


@pytest.fixture(scope="module")
def gonggao_file_path():
    return "tests/data/doc.json"

@pytest.fixture(scope="module")
def new_parser_file_path():
    return "tests/data/file/doc.json"

@pytest.fixture(scope="module")
def zgs_file_path():
    return "tests/data/招股说明书.json"


@pytest.fixture(scope="module")
def yanbao_file_path():
    return "tests/data/研报解析结果.json"


@pytest.fixture(scope="module")
def gonggao_analyzer_file_path():
    """analyzer = 5"""
    return "tests/data/gonggao.json"


@pytest.fixture(scope="module")
def nianbao_analyzer_file_path():
    """analyzer = 5"""
    return "tests/data/nianbao/doc.json"

@pytest.fixture(scope="module")
def new_parser_analyzer(new_parser_file_path):
    """初始化 DocJsonAnalyzer"""
    return DocJsonAnalyzer().analyze(new_parser_file_path)

@pytest.fixture(scope="module")
def analyzer(gonggao_file_path):
    """初始化 DocJsonAnalyzer"""
    return DocJsonAnalyzer().analyze(gonggao_file_path)


@pytest.fixture(scope="module")
def gonggao_analyzer(gonggao_analyzer_file_path):
    """初始化 DocJsonAnalyzer"""
    return DocJsonAnalyzer().analyze(gonggao_analyzer_file_path)


@pytest.fixture(scope="module")
def yanbao_analyzer(yanbao_file_path):
    """初始化 DocJsonAnalyzer"""
    return DocJsonAnalyzer().analyze(yanbao_file_path)


@pytest.fixture(scope="module")
def zgs_analyzer(zgs_file_path):
    """招股书解析测试，初始化 DocJsonAnalyzer"""
    return DocJsonAnalyzer().analyze(zgs_file_path)

@pytest.fixture(scope="module")
def nianbao_analyzer(nianbao_analyzer_file_path):
    """招股书解析测试，初始化 DocJsonAnalyzer"""
    return DocJsonAnalyzer().analyze(nianbao_analyzer_file_path)


def test_docjson2md(analyzer, yanbao_analyzer, nianbao_analyzer):
    """
    测试docjson2md
    """
    # 加载DocJsonAnalyzer
    analyzer.to_md("tests/data/output/doc.md")
    yanbao_analyzer.to_md("tests/data/output/yanbao.md")
    nianbao_analyzer.to_md("tests/data/output/nianbao.md", table_html=True)


def test_docjson2md_table_html(analyzer):
    """
    调用analyzer的to_md方法，将结果输出到指定的Markdown文件，同时指定表格格式为HTML
    """
    analyzer.to_md("tests/data/output/doc_table_html.md", table_html=True)


def test_docjson2md_table_html_zgs(zgs_analyzer):
    """
    长表格测试
    调用analyzer的to_md方法，将结果输出到指定的Markdown文件，同时指定表格格式为HTML
    """
    zgs_analyzer.to_md("tests/data/output/zgs_table_html.md", table_html=True)


def test_docjson2csv(analyzer):
    """
    测试docjson2csv方法
    """
    # 加载DocJsonAnalyzer
    analyzer.to_csv("tests/data/output/doc.csv")


def test_docjson2md_with_id(analyzer):
    """测试docjson2md with_id"""
    analyzer.to_md_with_id("tests/data/output/doc_with_id.md")


def test_docjson2html(analyzer):
    """测试docjson2html"""
    analyzer.to_html("tests/data/output/doc.html")


def test_gonggao_analyzer2md(gonggao_analyzer):
    gonggao_analyzer.to_md("tests/data/output/gonggao.md")


def test_new_parser_analyzer2md(new_parser_analyzer):
    new_parser_analyzer.to_md("tests/data/output/new_parser.md")