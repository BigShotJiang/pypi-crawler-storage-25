#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
新格式兼容层
处理新数据格式与旧格式的兼容性
"""

from typing import Dict, Any, List
from ..constant import DocJson, DocAttr


class NewFormatCompatibility:
    """新格式兼容处理类"""
    
    # 新格式类型到旧格式类型的映射
    TYPE_MAPPING = {
        'xtitle': 'title',
        'xtext': 'text', 
        'xfigure': 'figure',
        'xtable': 'table'
    }
    
    @classmethod
    def convert_new_to_old_format(cls, new_doc_json: Dict[str, Any]) -> Dict[str, Any]:
        """
        将新格式转换为旧格式兼容的数据结构
        
        Args:
            new_doc_json: 新格式的doc.json数据
            
        Returns:
            转换后的旧格式兼容数据
        """
        # 创建基础结构
        old_format = {
            DocJson.PDF_INFO: {
                'page_count': new_doc_json.get('page_count', 0),
                'type': new_doc_json.get('type'),
                'kind': new_doc_json.get('kind')
            },
            DocJson.FONTS: new_doc_json.get('fonts', {}),
            DocJson.PAGES: cls._convert_pages(new_doc_json.get('pages', [])),
            DocJson.TREE: cls._convert_tree(new_doc_json.get('tree', {})),
            DocAttr.META: {}
        }
        
        return old_format
    
    @classmethod
    def _convert_pages(cls, new_pages: List[Dict]) -> List[Dict]:
        """转换页面数据"""
        old_pages = []
        
        for page in new_pages:
            old_page = {
                DocJson.NUMBER: page.get('number'),
                'type': page.get('type'),
                'width': page.get('width'),
                'height': page.get('height'),
                'rotate': page.get('rotate'),
                DocJson.BBOX: [0, 0, page.get('width', 0), page.get('height', 0)],
                DocJson.BODY: {
                    DocJson.BLOCK: []
                }
            }
            
            # 处理header
            if 'header' in page and page['header'] is not None:
                old_page[DocJson.HEADER] = cls._convert_header_footer(page['header'])
            
            # 处理footer  
            if 'footer' in page and page['footer'] is not None:
                old_page[DocJson.FOOTER] = cls._convert_header_footer(page['footer'])
                
            old_pages.append(old_page)
            
        return old_pages
    
    @classmethod
    def _convert_header_footer(cls, header_footer: Dict) -> Dict:
        """转换header/footer数据"""
        if header_footer is None:
            return {
                DocJson.BBOX: [],
                DocJson.TEXT: '',
                'objects': []
            }
        return {
            DocJson.BBOX: header_footer.get('bbox', []),
            DocJson.TEXT: cls._extract_text_from_objects(header_footer.get('objects', [])),
            'objects': header_footer.get('objects', [])
        }
    
    @classmethod
    def _extract_text_from_objects(cls, objects: List[Dict]) -> str:
        """从objects中提取文本"""
        texts = []
        for obj in objects:
            if obj.get('type') == 'text' and 'lines' in obj:
                for line in obj['lines']:
                    if 'objects' in line:
                        for span in line['objects']:
                            if span.get('type') == 'span':
                                texts.append(span.get('text', ''))
        return ''.join(texts)
    
    @classmethod
    def _convert_tree(cls, new_tree: Dict) -> Dict:
        """转换树结构"""
        if 'root' not in new_tree:
            return {}
            
        return {
            DocJson.ROOT: cls._convert_tree_node(new_tree['root'], parent_path=[])
        }
    
    @classmethod
    def _convert_tree_node(cls, node: Dict, parent_path: List[int], node_id: int = 0) -> Dict:
        """递归转换树节点"""
        if node is None:
            return {
                DocJson.ID: node_id,
                DocJson.TYPE: 'text',
                DocJson.PARENT_PATH: parent_path.copy(),
                DocJson.DATA: {},
                DocJson.CHILDREN: []
            }
        
        # 生成新的节点ID
        current_id = node_id
        
        # 转换节点类型
        old_type = cls.TYPE_MAPPING.get(node.get('type', ''), node.get('type', ''))
        
        # 构建旧格式的节点
        old_node = {
            DocJson.ID: current_id,
            DocJson.TYPE: old_type,
            DocJson.PARENT_PATH: parent_path.copy(),
            DocJson.DATA: cls._convert_node_data(node.get('data', {})),
            DocJson.CHILDREN: []
        }
        
        # 添加page_number字段
        if 'data' in node and 'location' in node['data']:
            old_node[DocJson.PAGE_NUMBER] = node['data']['location'].get('page_number', 1)
        else:
            old_node[DocJson.PAGE_NUMBER] = 1
        
        # 处理子节点
        children = node.get('children', [])
        if children:
            for i, child in enumerate(children):
                if child is not None:
                    child_path = parent_path + [current_id]
                    child_node = cls._convert_tree_node(child, child_path, current_id + i + 1)
                    old_node[DocJson.CHILDREN].append(child_node)
        
        return old_node
    
    @classmethod
    def _convert_node_data(cls, data: Dict) -> Dict:
        """转换节点数据"""
        old_data = {}
        
        # 处理文本数据
        if 'text' in data:
            old_data[DocJson.TEXT] = data['text']
        
        # 处理位置信息
        if 'location' in data:
            location = data['location']
            old_data[DocJson.PAGE_NUMBER] = location.get('page_number', 1)
            old_data[DocJson.BBOX] = location.get('bbox', [])
        
        # 处理图片数据
        if 'objects' in data:
            objects = data['objects']
            if objects and objects[0].get('type') == 'figure':
                fig_obj = objects[0]
                old_data[DocJson.FIGURE] = {
                    'bbox': fig_obj.get('bbox', []),
                    'filename': fig_obj.get('filename'),
                    'page_number': fig_obj.get('page_number', 1)
                }
        
        # 处理表格数据
        if 'table' in data:
            old_data[DocJson.TABLE] = data['table']
        
        return old_data


def convert_new_format_doc_json(new_doc_json: Dict[str, Any]) -> Dict[str, Any]:
    """
    便捷函数：将新格式doc.json转换为旧格式兼容数据
    
    Args:
        new_doc_json: 新格式的doc.json数据
        
    Returns:
        转换后的旧格式兼容数据
    """
    return NewFormatCompatibility.convert_new_to_old_format(new_doc_json)
