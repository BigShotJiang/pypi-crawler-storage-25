#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@File    :   json_tools.py
@Time    :   2025/06/17 09:16:15
@Author  :   Mason
@Version :   1.0
@Desc    :   json tools for docjson2x
"""

from pathlib import Path


def load_json(*, path=None, data=None):
    if path:
        path = Path(path)
        data = path.read_text(encoding="utf-8")
    elif isinstance(data, (bytes, bytearray)):
        data = data.decode("utf-8")
    elif isinstance(data, str):
        # str
        pass
    else:
        raise ValueError("path和data必须设置")

    try:
        import json

        return json.loads(data)
    except ImportError:
        return json.loads(data)


def read_json(json_filename):
    """
    读取json
    """
    import json

    with open(json_filename, "r", encoding="utf-8") as f:
        content = json.loads(f.read())
    return content


def str_join(separator, iterable):
    """
    拼接字符串
    """

    sequence = list(iter(iterable))
    if not sequence:
        return ""

    ret = sequence[0]
    for s in sequence[1:]:
        ret += separator + s

    true_ret = separator.join([str(s) for s in sequence])
    if ret != true_ret:
        raise Exception(f"{ret} and {true_ret} is different")

    return ret
