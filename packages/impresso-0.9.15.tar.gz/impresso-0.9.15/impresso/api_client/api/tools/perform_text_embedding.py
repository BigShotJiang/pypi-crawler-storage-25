from http import HTTPStatus
from typing import Any, Dict, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.impresso_embedding_response import ImpressoEmbeddingResponse
from ...models.impresso_text_embedding_request import ImpressoTextEmbeddingRequest
from ...types import Response


def _get_kwargs(
    *,
    body: ImpressoTextEmbeddingRequest,
) -> Dict[str, Any]:
    headers: Dict[str, Any] = {}

    _kwargs: Dict[str, Any] = {
        "method": "post",
        "url": "/tools/embedder/text",
    }

    _body = body.to_dict()

    _kwargs["json"] = _body
    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[Error, ImpressoEmbeddingResponse]]:
    if response.status_code == HTTPStatus.CREATED:
        response_201 = ImpressoEmbeddingResponse.from_dict(response.json())

        return response_201
    if response.status_code == HTTPStatus.UNAUTHORIZED:
        response_401 = Error.from_dict(response.json())

        return response_401
    if response.status_code == HTTPStatus.FORBIDDEN:
        response_403 = Error.from_dict(response.json())

        return response_403
    if response.status_code == HTTPStatus.IM_A_TEAPOT:
        response_418 = Error.from_dict(response.json())

        return response_418
    if response.status_code == HTTPStatus.UNPROCESSABLE_CONTENT:
        response_422 = Error.from_dict(response.json())

        return response_422
    if response.status_code == HTTPStatus.TOO_MANY_REQUESTS:
        response_429 = Error.from_dict(response.json())

        return response_429
    if response.status_code == HTTPStatus.INTERNAL_SERVER_ERROR:
        response_500 = Error.from_dict(response.json())

        return response_500
    if response.status_code == HTTPStatus.SERVICE_UNAVAILABLE:
        response_503 = Error.from_dict(response.json())

        return response_503
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[Error, ImpressoEmbeddingResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: ImpressoTextEmbeddingRequest,
) -> Response[Union[Error, ImpressoEmbeddingResponse]]:
    """Embed a text into a vector space

    Args:
        body (ImpressoTextEmbeddingRequest): Body of a request to the Impresso Text Embedding
            endpoint

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, ImpressoEmbeddingResponse]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: ImpressoTextEmbeddingRequest,
) -> Optional[Union[Error, ImpressoEmbeddingResponse]]:
    """Embed a text into a vector space

    Args:
        body (ImpressoTextEmbeddingRequest): Body of a request to the Impresso Text Embedding
            endpoint

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Error, ImpressoEmbeddingResponse]
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: ImpressoTextEmbeddingRequest,
) -> Response[Union[Error, ImpressoEmbeddingResponse]]:
    """Embed a text into a vector space

    Args:
        body (ImpressoTextEmbeddingRequest): Body of a request to the Impresso Text Embedding
            endpoint

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, ImpressoEmbeddingResponse]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: ImpressoTextEmbeddingRequest,
) -> Optional[Union[Error, ImpressoEmbeddingResponse]]:
    """Embed a text into a vector space

    Args:
        body (ImpressoTextEmbeddingRequest): Body of a request to the Impresso Text Embedding
            endpoint

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Error, ImpressoEmbeddingResponse]
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
