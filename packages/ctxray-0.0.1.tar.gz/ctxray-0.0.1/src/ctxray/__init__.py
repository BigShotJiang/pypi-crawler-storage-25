"""ctxray — See how you really use AI."""

__version__ = "0.0.1"
