# ctxray

**See how you really use AI.**

X-ray your AI coding sessions across Claude Code, Cursor, ChatGPT, and 6 more tools.

> This is a placeholder release. The full package is coming soon.
> 
> Follow development: https://github.com/ctxray-dev/ctxray
