import os.path
import unittest

import ddt
from iker.common.utils.dtutils import dt_parse_iso

from plexus.common.utils.jsonutils import json_dumps, json_loads
from plexus.common.utils.jsonutils import read_chunked_jsonl
from testenv import resources_directory


@ddt.ddt
class JsonUtilsTest(unittest.TestCase):

    def test_json_loads_dumps(self):
        data = {
            "int": 123,
            "float": 123.456,
            "string": "dummy_string",
            "boolean": True,
            "null": None,
            "datetime": dt_parse_iso("2024-01-01T00:00:00.000000+00:00"),
            "list": [123, 123.456, "dummy_string", True, None, dt_parse_iso("2024-01-01T00:00:00.000000+00:00")],
            "dict": {
                "int": 123,
                "float": 123.456,
                "string": "dummy_string",
                "boolean": True,
                "null": None,
                "datetime": dt_parse_iso("2024-01-01T00:00:00.000000+00:00"),
            },
        }
        self.assertEqual(data, json_loads(json_dumps(data)))

    def test_read_chunked_jsonl(self):
        for data, path in read_chunked_jsonl(str(resources_directory / "unittest" / "jsonutils" / "dummy.{{}}.jsonl")):
            self.assertEqual(data["file"], os.path.basename(path))
