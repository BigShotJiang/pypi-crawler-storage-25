"""AES-GCM encryption services for appcore."""

from __future__ import annotations

import base64
import binascii
import os
import re

try:
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

    HAS_CRYPTOGRAPHY = True
except ModuleNotFoundError:
    from Cryptodome.Cipher import AES
    from Cryptodome.Hash import SHA256
    from Cryptodome.Protocol.KDF import PBKDF2

    HAS_CRYPTOGRAPHY = False

from appcore.common import exceptions as common_exceptions
from appcore.key_provider import key_provider

ENC_PATTERN = re.compile(r"^ENC\((.+)\)$")
KEY_LENGTH = 32
NONCE_LENGTH = 12


def derive_key(raw_key: bytes, salt: bytes) -> bytes:
    """Derive a 32-byte AES key from arbitrary key material."""
    if HAS_CRYPTOGRAPHY:
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=KEY_LENGTH,
            salt=salt,
            iterations=600_000,
        )
        return kdf.derive(raw_key)
    return PBKDF2(
        password=raw_key,
        salt=salt,
        dkLen=KEY_LENGTH,
        count=600_000,
        hmac_hash_module=SHA256,
    )


class CryptoService:
    """Encrypt and decrypt UTF-8 strings using AES-256-GCM."""

    def __init__(self, provider: key_provider.KeyProvider, key_name: str, salt: bytes) -> None:
        """Fetch and normalize the encryption key once."""
        raw_key = provider.get_key(key_name)
        self._key = raw_key if len(raw_key) == KEY_LENGTH else derive_key(raw_key, salt)
        if HAS_CRYPTOGRAPHY:
            self._cipher = AESGCM(self._key)

    def encrypt(self, plaintext: str) -> str:
        """Encrypt a UTF-8 string and return a base64url token."""
        nonce = os.urandom(NONCE_LENGTH)
        if HAS_CRYPTOGRAPHY:
            ciphertext = self._cipher.encrypt(nonce, plaintext.encode("utf-8"), None)
            token_bytes = nonce + ciphertext
            return base64.urlsafe_b64encode(token_bytes).decode("ascii")
        cipher = AES.new(self._key, AES.MODE_GCM, nonce=nonce)
        ciphertext, tag = cipher.encrypt_and_digest(plaintext.encode("utf-8"))
        token_bytes = nonce + ciphertext + tag
        return base64.urlsafe_b64encode(token_bytes).decode("ascii")

    def decrypt(self, token: str) -> str:
        """Decrypt a token produced by encrypt."""
        try:
            raw = base64.urlsafe_b64decode(token.encode("ascii"))
        except (ValueError, binascii.Error) as exc:
            raise common_exceptions.CryptoError(f"Malformed token: {exc}") from exc

        if len(raw) <= NONCE_LENGTH:
            raise common_exceptions.CryptoError("Malformed token: ciphertext is missing")

        nonce = raw[:NONCE_LENGTH]
        if HAS_CRYPTOGRAPHY:
            ciphertext = raw[NONCE_LENGTH:]
            try:
                plaintext = self._cipher.decrypt(nonce, ciphertext, None)
            except (InvalidTag, ValueError) as exc:
                raise common_exceptions.CryptoError(f"Decryption failed: {exc}") from exc
            return plaintext.decode("utf-8")

        if len(raw) <= NONCE_LENGTH + 16:
            raise common_exceptions.CryptoError("Malformed token: ciphertext is missing")

        ciphertext = raw[NONCE_LENGTH:-16]
        tag = raw[-16:]
        try:
            cipher = AES.new(self._key, AES.MODE_GCM, nonce=nonce)
            plaintext = cipher.decrypt_and_verify(ciphertext, tag)
        except ValueError as exc:
            raise common_exceptions.CryptoError(f"Decryption failed: {exc}") from exc
        return plaintext.decode("utf-8")

    def decrypt_if_encrypted(self, value: str) -> str:
        """Decrypt an ENC(...) wrapped value, or return the input unchanged."""
        match = ENC_PATTERN.match(value)
        if match is None:
            return value
        return self.decrypt(match.group(1))

    def encrypt_to_env_format(self, plaintext: str) -> str:
        """Return an encrypted value wrapped as ENC(...)."""
        return f"ENC({self.encrypt(plaintext)})"
