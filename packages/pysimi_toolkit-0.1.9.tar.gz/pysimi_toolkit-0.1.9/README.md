# PySimi

<img src="https://raw.githubusercontent.com/Tianyi-Shi-Tsukuba/PySimi/main/LOGO.jpg" width="200" />

PySimi is a Python toolkit for constructing similarity matrices and applying them to spectral clustering / dimensionality reduction.

For more details, please refer to https://github.com/Tianyi-Shi-Tsukuba/PySimi.

## Installation

pip install pysimi-toolkit
