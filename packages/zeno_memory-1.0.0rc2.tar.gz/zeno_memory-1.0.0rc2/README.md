# zeno-memory

Memory protocols and SQLite-backed defaults for the
[Zeno](https://github.com/nkootstra/zeno) framework.

## Install

```bash
uv add 'zeno-framework[memory]'
```

Ships:
- `SessionStore`, `UserMemoryStore`, `KnowledgeStore`, `ConversationStore`,
  `VectorStore` protocols
- Context-bound `UserMemoryView` / `KnowledgeView` / `ConversationHandle`
  / `SessionHandle` handles
- `SqliteSessionStore`, `SqliteUserMemoryStore`, and `SqliteConversationStore`
  defaults
- `VectorBackedUserMemoryStore` that wraps any `KnowledgeStore`

`ConversationStore` is new in v0.3.0 — non-Claude providers (e.g.
`OpenAIProvider`) write each turn's assistant, tool, and user messages
through it so the next turn has prior context. `ClaudeSDKProvider`
does not use it (the SDK owns its own session history).

Vector backends (`zeno-chroma`, `zeno-qdrant`) are optional dependencies
pulled in by the app.

Part of the [Zeno framework](https://github.com/nkootstra/zeno).
