"""`UserMemoryStore` implementations backed by a `KnowledgeStore` adapter."""
