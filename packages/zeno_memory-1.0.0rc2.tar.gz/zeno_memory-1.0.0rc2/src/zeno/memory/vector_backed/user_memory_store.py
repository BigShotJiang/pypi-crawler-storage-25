"""`VectorBackedUserMemoryStore` — production default for per-user memory.

Adapts any `KnowledgeStore` into a `UserMemoryStore` by tagging every
write with `meta={"kind": namespace, "user_id": user_id}` and delegating
searches through the adapter's required `user_id` filter. User scoping
is enforced by the underlying adapter; this wrapper does not implement
cross-user isolation itself.

Dedup policy: before inserting, search for the top match at `k=1`. If
the cosine similarity is ≥ `dedup_threshold` (default `0.92`), update
the existing entry's `meta` instead of inserting a duplicate. The
threshold is carried forward from helios; adapters with different
embedding models may need to retune.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from zeno.memory.protocols import KnowledgeStore, MemoryHit


@dataclass
class VectorBackedUserMemoryStore:
    knowledge_store: KnowledgeStore
    namespace: str = "user_memory"
    dedup_threshold: float = 0.92

    async def add(
        self,
        user_id: str,
        text: str,
        meta: dict[str, Any] | None = None,
    ) -> None:
        merged_meta: dict[str, Any] = {
            **(meta or {}),
            "kind": self.namespace,
            "user_id": user_id,
        }

        hits = await self.knowledge_store.search(user_id, text, k=1)
        if (
            hits
            and hits[0].meta.get("kind") == self.namespace
            and hits[0].score >= self.dedup_threshold
        ):
            # Duplicate-or-near-duplicate fact; skip insert.
            # Adapters can update metadata via their own APIs if needed.
            return

        await self.knowledge_store.add(user_id, text, merged_meta)

    async def search(self, user_id: str, query: str, k: int = 5) -> list[MemoryHit]:
        raw = await self.knowledge_store.search(user_id, query, k=k)
        # Filter to our namespace — the shared KnowledgeStore may also
        # hold non-user-memory facts; user memory search must not
        # surface those.
        return [hit for hit in raw if hit.meta.get("kind") == self.namespace]
