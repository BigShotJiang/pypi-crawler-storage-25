"""Idempotent schema migrator for the SQLite-backed memory stores.

Concurrency model:
  - Every migration SQL script is written with ``CREATE TABLE IF NOT EXISTS``
    (or ``CREATE INDEX IF NOT EXISTS``) so re-running it is a no-op.
  - The `schema_version` table has ``version`` as its PRIMARY KEY and we
    record applied migrations with ``INSERT OR IGNORE``. Two racing
    initializers may both run migration N, but at most one version row
    lands per version — the other insert is silently ignored.
  - ``PRAGMA busy_timeout=30000`` lets concurrent writers wait for the
    short-lived write lock instead of erroring with ``database is locked``.
  - A per-process ``asyncio.Lock`` serializes ``ensure_schema`` calls on
    the same event loop. Cross-connection races in the same process would
    otherwise see ``SQLITE_BUSY`` on first-init because
    ``PRAGMA journal_mode=WAL`` briefly requires an exclusive lock that
    is not always yielded to ``busy_timeout`` in a predictable window.

WAL mode is also enabled here to match the production recommendation.

We deliberately avoid wrapping the migration run in an explicit
``BEGIN EXCLUSIVE`` / ``COMMIT`` pair. Python's ``sqlite3`` treats DDL
and ``executescript()`` calls specially — they implicitly commit any
in-flight transaction, which makes the explicit pair fragile and depends
on the caller's ``isolation_level`` setting. Idempotent DDL + PK-backed
``INSERT OR IGNORE`` is simpler and works in every connection mode.
"""

from __future__ import annotations

import asyncio
import importlib.resources
import time
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import aiosqlite

_INIT_LOCK = asyncio.Lock()


_MIGRATIONS_PACKAGE = "zeno.memory.sqlite.migrations"


def _load_migrations() -> list[tuple[int, str, str]]:
    """Return `[(version, name, sql), ...]` ordered by version."""
    resource = importlib.resources.files(_MIGRATIONS_PACKAGE)
    migrations: list[tuple[int, str, str]] = []
    for entry in resource.iterdir():
        name = entry.name
        if not name.endswith(".sql"):
            continue
        version_str = name.split("_", 1)[0]
        if not version_str.isdigit():
            continue
        with importlib.resources.as_file(entry) as path:
            sql = Path(path).read_text(encoding="utf-8")
        migrations.append((int(version_str), name, sql))
    migrations.sort(key=lambda t: t[0])
    return migrations


async def ensure_schema(conn: aiosqlite.Connection) -> None:
    """Apply any pending migrations. Idempotent; safe under concurrent calls."""
    async with _INIT_LOCK:
        # busy_timeout must be set BEFORE any write: `PRAGMA journal_mode=WAL`
        # briefly requires an exclusive lock and would otherwise fail
        # immediately with `database is locked` under contention.
        await conn.execute("PRAGMA busy_timeout=30000")
        await conn.execute("PRAGMA journal_mode=WAL")
        await conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_version ("
            "version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)"
        )
        await conn.commit()

        cur = await conn.execute("SELECT MAX(version) FROM schema_version")
        row = await cur.fetchone()
        current = int(row[0]) if row and row[0] is not None else 0

        for version, _name, sql in _load_migrations():
            if version <= current:
                continue
            await conn.executescript(sql)
            await conn.execute(
                "INSERT OR IGNORE INTO schema_version (version, applied_at) VALUES (?, ?)",
                (version, int(time.time())),
            )
            await conn.commit()
