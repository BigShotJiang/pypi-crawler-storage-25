"""SQLite-backed default stores + migration runner."""
