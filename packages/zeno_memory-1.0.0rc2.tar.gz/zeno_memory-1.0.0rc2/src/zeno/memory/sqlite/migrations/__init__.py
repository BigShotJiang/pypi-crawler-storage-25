"""SQL migration files — `NNN_*.sql`, discovered by sorted file name."""
