-- Per-turn conversation history for non-Claude providers (R7, R8, IU2).
--
-- One row per message in the ordered log for (user_id, thread_key).
-- `sequence` is a monotonically increasing integer assigned by the store
-- on append; the composite PRIMARY KEY gives us the natural
-- (user_id, thread_key, sequence) index used by `load()` and prune.
--
-- `tool_calls_json` holds the raw OpenAI Chat Completions `tool_calls`
-- list when the assistant requested tool invocations. `tool_call_id`
-- holds the id the assistant asked us to respond to (only set for `tool`
-- role rows). Both are optional.
--
-- `created_at` is stored as ISO-8601 so it round-trips cleanly through
-- `datetime.fromisoformat` regardless of locale or SQLite storage class.
CREATE TABLE IF NOT EXISTS conversations (
    user_id         TEXT NOT NULL,
    thread_key      TEXT,
    sequence        INTEGER NOT NULL,
    role            TEXT NOT NULL,
    content         TEXT,
    tool_calls_json TEXT,
    tool_call_id    TEXT,
    created_at      TEXT NOT NULL,
    PRIMARY KEY (user_id, thread_key, sequence)
);
