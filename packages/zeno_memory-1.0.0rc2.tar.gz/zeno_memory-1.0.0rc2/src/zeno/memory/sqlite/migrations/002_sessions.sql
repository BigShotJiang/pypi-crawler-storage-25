CREATE TABLE IF NOT EXISTS sessions (
    user_id        TEXT NOT NULL,
    channel        TEXT NOT NULL,
    thread_key     TEXT,
    sdk_session_id TEXT NOT NULL,
    created_at     INTEGER NOT NULL,
    updated_at     INTEGER NOT NULL,
    last_summary   TEXT,
    PRIMARY KEY (user_id, channel, thread_key)
);
