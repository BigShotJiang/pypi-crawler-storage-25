CREATE TABLE IF NOT EXISTS user_memories (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    TEXT NOT NULL,
    text       TEXT NOT NULL,
    meta       TEXT,
    created_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS ix_user_memories_user_id
    ON user_memories (user_id);
