"""`SqliteUserMemoryStore` — deterministic baseline for tests and bootstrapping.

**Not recommended for production.** Search is `LIKE %token%` keyword
matching with whitespace tokenization; there is no embedding, no stemming,
no vector scoring. Use `VectorBackedUserMemoryStore` wrapping a
`ChromaKnowledgeStore` or `QdrantKnowledgeStore` in production.

Why we ship it anyway:
  - Every memory test should be able to run with zero extra dependencies.
  - The contract (`add`/`search` with strict user-id scoping) is
    exercisable with determinism, which matters for S7.
"""

from __future__ import annotations

import json
import re
import time
from typing import TYPE_CHECKING, Any

import aiosqlite
from zeno.memory.protocols import MemoryHit
from zeno.memory.sqlite.migrate import ensure_schema

if TYPE_CHECKING:
    from pathlib import Path


_TOKEN_RE = re.compile(r"[A-Za-z0-9]+")


def _tokens(query: str) -> list[str]:
    return [tok.lower() for tok in _TOKEN_RE.findall(query) if tok]


class SqliteUserMemoryStore:
    """Keyword-rank user memory store (baseline)."""

    def __init__(self, path: str | Path) -> None:
        self._path = str(path)
        self._initialized = False

    async def _connect(self) -> aiosqlite.Connection:
        conn = await aiosqlite.connect(self._path)
        if not self._initialized:
            await ensure_schema(conn)
            self._initialized = True
        return conn

    async def add(
        self,
        user_id: str,
        text: str,
        meta: dict[str, Any] | None = None,
    ) -> None:
        """Insert, de-duplicating on exact-text match for the same user."""
        now = int(time.time())
        meta_json = json.dumps(meta) if meta else None
        conn = await self._connect()
        try:
            cur = await conn.execute(
                "SELECT id FROM user_memories WHERE user_id = ? AND text = ? LIMIT 1",
                (user_id, text),
            )
            existing = await cur.fetchone()
            if existing is not None:
                await conn.execute(
                    "UPDATE user_memories SET meta = COALESCE(?, meta) WHERE id = ?",
                    (meta_json, existing[0]),
                )
            else:
                await conn.execute(
                    "INSERT INTO user_memories (user_id, text, meta, created_at) "
                    "VALUES (?, ?, ?, ?)",
                    (user_id, text, meta_json, now),
                )
            await conn.commit()
        finally:
            await conn.close()

    async def search(self, user_id: str, query: str, k: int = 5) -> list[MemoryHit]:
        tokens = _tokens(query)
        if not tokens:
            return []

        # Build a SUM of LIKE-matches per row, ordered by match count then recency.
        like_clauses = " + ".join(
            "(CASE WHEN lower(text) LIKE ? THEN 1 ELSE 0 END)" for _ in tokens
        )
        sql = (
            f"SELECT text, meta, created_at, {like_clauses} AS score "
            "FROM user_memories "
            "WHERE user_id = ? "
            f"  AND ({' OR '.join(['lower(text) LIKE ?'] * len(tokens))}) "
            "ORDER BY score DESC, created_at DESC "
            "LIMIT ?"
        )
        like_params = [f"%{tok}%" for tok in tokens]
        params = (*like_params, user_id, *like_params, k)

        conn = await self._connect()
        try:
            cur = await conn.execute(sql, params)
            rows = await cur.fetchall()
        finally:
            await conn.close()

        hits: list[MemoryHit] = []
        for text, meta_json, _created_at, score in rows:
            meta: dict[str, Any] = json.loads(meta_json) if meta_json else {}
            hits.append(MemoryHit(text=text, score=float(score), meta=meta))
        return hits
