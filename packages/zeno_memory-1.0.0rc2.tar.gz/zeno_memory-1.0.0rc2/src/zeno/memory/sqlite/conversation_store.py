"""`SqliteConversationStore` — ordered message log for non-Claude providers (R7, R8).

Back-of-envelope: one row per `ConversationMessage` keyed by
`(user_id, thread_key, sequence)`. Providers call `append` at the end of a
turn and `load` at the start of the next. ``ClaudeSDKProvider`` never
touches this — the Agent SDK owns its own session state.

Concurrency:
- A per-thread ``asyncio.Lock`` (keyed by ``(user_id, thread_key)``)
  serialises writes inside the current process, so concurrent
  ``asyncio.gather`` appends cannot collide on ``sequence``.
- SQLite's WAL + ``busy_timeout=30000`` handles cross-process contention.

Failure posture (KD12):
- Read failure → log WARN and return ``[]``. Reading history is best-effort;
  a dead DB must not kill an in-flight turn.
- Write failure → raise. Losing new messages silently is a persistence bug
  we want the operator to see immediately.

Bounded growth:
- ``max_messages_per_thread`` caps how many rows survive per
  ``(user_id, thread_key)``; older rows are DELETEd after append to keep
  the table small.
- ``warn_messages_per_thread`` emits a one-time WARNING per
  ``(user_id, thread_key)`` once the row count crosses the threshold — a
  nudge to turn on pruning before the SQLite file grows unbounded.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

import aiosqlite
from zeno.memory.protocols import ConversationMessage
from zeno.memory.sqlite.migrate import ensure_schema

if TYPE_CHECKING:
    from collections.abc import Sequence

_LOGGER = logging.getLogger("zeno.memory.sqlite.conversation_store")


class SqliteConversationStore:
    """Durable, single-writer conversation log backed by aiosqlite + WAL mode."""

    def __init__(
        self,
        path: str | Path,
        *,
        max_messages_per_thread: int | None = None,
        warn_messages_per_thread: int | None = None,
    ) -> None:
        if max_messages_per_thread is not None and max_messages_per_thread < 1:
            raise ValueError("max_messages_per_thread must be >= 1 when set")
        if warn_messages_per_thread is not None and warn_messages_per_thread < 1:
            raise ValueError("warn_messages_per_thread must be >= 1 when set")
        self._path = str(path)
        self._initialized = False
        self._max = max_messages_per_thread
        self._warn = warn_messages_per_thread
        # Keyed by (user_id, thread_key); used to serialise `append` so
        # concurrent `asyncio.gather` calls cannot race on `sequence`.
        self._locks: dict[tuple[str, str | None], asyncio.Lock] = {}
        # Process-wide memory of which threads have already logged their
        # growth WARN so we don't spam a running process per turn.
        self._warned: set[tuple[str, str | None]] = set()

    def _lock_for(self, user_id: str, thread_key: str | None) -> asyncio.Lock:
        key = (user_id, thread_key)
        lock = self._locks.get(key)
        if lock is None:
            lock = asyncio.Lock()
            self._locks[key] = lock
        return lock

    async def _connect(self) -> aiosqlite.Connection:
        conn = await aiosqlite.connect(self._path)
        if not self._initialized:
            await ensure_schema(conn)
            self._chmod_secure()
            self._initialized = True
        return conn

    def _chmod_secure(self) -> None:
        with contextlib.suppress(OSError):
            os.chmod(self._path, 0o600)

    async def load(self, *, user_id: str, thread_key: str | None) -> list[ConversationMessage]:
        try:
            conn = await self._connect()
        except Exception as exc:  # noqa: BLE001 — KD12: read is best-effort
            _LOGGER.warning(
                "conversation load failed; returning empty history",
                extra={"user_id": user_id, "thread_key": thread_key, "error": str(exc)},
            )
            return []
        try:
            cur = await conn.execute(
                "SELECT role, content, tool_calls_json, tool_call_id, created_at "
                "FROM conversations "
                "WHERE user_id = ? AND thread_key IS ? "
                "ORDER BY sequence",
                (user_id, thread_key),
            )
            rows = await cur.fetchall()
        except Exception as exc:  # noqa: BLE001 — KD12: read is best-effort
            _LOGGER.warning(
                "conversation load failed; returning empty history",
                extra={"user_id": user_id, "thread_key": thread_key, "error": str(exc)},
            )
            return []
        finally:
            await conn.close()
        return [_row_to_message(row) for row in rows]

    async def append(
        self,
        *,
        user_id: str,
        thread_key: str | None,
        messages: Sequence[ConversationMessage],
    ) -> None:
        if not messages:
            return
        async with self._lock_for(user_id, thread_key):
            conn = await self._connect()
            try:
                cur = await conn.execute(
                    "SELECT COALESCE(MAX(sequence), -1) + 1 "
                    "FROM conversations "
                    "WHERE user_id = ? AND thread_key IS ?",
                    (user_id, thread_key),
                )
                row = await cur.fetchone()
                base_seq = int(row[0]) if row and row[0] is not None else 0

                rows = [
                    (
                        user_id,
                        thread_key,
                        base_seq + i,
                        msg.role,
                        msg.content,
                        json.dumps(msg.tool_calls) if msg.tool_calls is not None else None,
                        msg.tool_call_id,
                        msg.created_at.isoformat(),
                    )
                    for i, msg in enumerate(messages)
                ]
                await conn.executemany(
                    "INSERT INTO conversations "
                    "  (user_id, thread_key, sequence, role, content, "
                    "   tool_calls_json, tool_call_id, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    rows,
                )
                await conn.commit()

                await self._maybe_prune_and_warn(conn, user_id, thread_key)
            finally:
                await conn.close()

    async def clear(self, *, user_id: str, thread_key: str | None) -> None:
        conn = await self._connect()
        try:
            await conn.execute(
                "DELETE FROM conversations WHERE user_id = ? AND thread_key IS ?",
                (user_id, thread_key),
            )
            await conn.commit()
        finally:
            await conn.close()

    async def _maybe_prune_and_warn(
        self,
        conn: aiosqlite.Connection,
        user_id: str,
        thread_key: str | None,
    ) -> None:
        if self._max is None and self._warn is None:
            return
        cur = await conn.execute(
            "SELECT COUNT(*) FROM conversations WHERE user_id = ? AND thread_key IS ?",
            (user_id, thread_key),
        )
        row = await cur.fetchone()
        count = int(row[0]) if row and row[0] is not None else 0

        if self._max is not None and count > self._max:
            # Delete the oldest `count - max` rows for this (user, thread).
            to_delete = count - self._max
            await conn.execute(
                "DELETE FROM conversations "
                "WHERE rowid IN ("
                "   SELECT rowid FROM conversations "
                "   WHERE user_id = ? AND thread_key IS ? "
                "   ORDER BY sequence "
                "   LIMIT ?"
                ")",
                (user_id, thread_key, to_delete),
            )
            await conn.commit()
            count = self._max

        if self._warn is not None and count >= self._warn:
            key = (user_id, thread_key)
            if key not in self._warned:
                self._warned.add(key)
                _LOGGER.warning(
                    "conversation thread growing past warn threshold",
                    extra={
                        "user_id": user_id,
                        "thread_key": thread_key,
                        "count": count,
                        "warn_threshold": self._warn,
                    },
                )


def _row_to_message(row: Any) -> ConversationMessage:
    role, content, tool_calls_json, tool_call_id, created_at_iso = row
    tool_calls = json.loads(tool_calls_json) if tool_calls_json is not None else None
    return ConversationMessage(
        role=role,
        content=content,
        tool_calls=tool_calls,
        tool_call_id=tool_call_id,
        created_at=datetime.fromisoformat(created_at_iso),
    )
