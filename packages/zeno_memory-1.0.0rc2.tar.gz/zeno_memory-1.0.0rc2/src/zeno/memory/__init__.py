"""zeno-memory — memory stores, protocols, and per-turn view handles."""

from __future__ import annotations

from zeno.memory.handles import (
    ConversationHandle,
    KnowledgeView,
    MemoryView,
    SessionHandle,
    UserMemoryView,
)
from zeno.memory.protocols import (
    ConversationMessage,
    ConversationStore,
    KnowledgeStore,
    MemoryHit,
    SessionRecord,
    SessionStore,
    UserMemoryStore,
    VectorStore,
)
from zeno.memory.three_layer import ThreeLayer
from zeno.memory.vector_backed.user_memory_store import VectorBackedUserMemoryStore

__all__ = [
    # Handles (per-turn views)
    "ConversationHandle",
    "KnowledgeView",
    "MemoryView",
    "SessionHandle",
    "UserMemoryView",
    # Protocols
    "ConversationMessage",
    "ConversationStore",
    "KnowledgeStore",
    "MemoryHit",
    "SessionRecord",
    "SessionStore",
    "UserMemoryStore",
    "VectorStore",
    # Composer
    "ThreeLayer",
    # Adapters
    "VectorBackedUserMemoryStore",
]
