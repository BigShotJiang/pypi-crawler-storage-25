"""Store-side protocols — the contracts concrete backends implement (R20, R21, R22, R26, R7, R8).

These protocols describe the **raw** stores, keyed by `user_id` everywhere.
They are what adapters like `SqliteSessionStore`, `ChromaKnowledgeStore`,
`VectorBackedUserMemoryStore`, and `SqliteConversationStore` implement.

Distinct from `MemoryViewProtocol` in `zeno-core`, which is the
context-bound *consumer* surface the turn worker hands to tools — the
views hide `user_id` after the turn worker has bound them.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Sequence
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal, Protocol, runtime_checkable

SessionIdFactory = Callable[[], Awaitable[str]] | Callable[[], str]
"""Factory for minting a fresh SDK session id.

The session store calls the factory only when no record exists for the
``(user_id, channel, thread_key)`` key. Sync and async factories are both
supported so adapters can plug in cheap UUID generators or async HTTP
calls without forcing a wrapper. Stores must `await` the result if the
return type is awaitable.
"""


@dataclass(frozen=True, slots=True)
class SessionRecord:
    """A per-`(user_id, channel, thread_key)` session mapping."""

    user_id: str
    channel: str
    thread_key: str | None
    sdk_session_id: str
    created_at: int
    updated_at: int
    last_summary: str | None = None


@dataclass(frozen=True, slots=True)
class MemoryHit:
    """A single search hit from a memory or knowledge store."""

    text: str
    score: float
    meta: dict[str, Any]


@runtime_checkable
class SessionStore(Protocol):
    """Maps `(user_id, channel, thread_key) → sdk_session_id`.

    The session record survives process restarts so we can resume SDK
    sessions via `ClaudeAgentOptions(resume=...)`. Losing the record is
    acceptable — we mint a fresh SDK session and lose chat history; user
    memory and knowledge remain intact.
    """

    async def get(
        self, user_id: str, channel: str, thread_key: str | None
    ) -> SessionRecord | None: ...

    async def get_or_create(
        self,
        user_id: str,
        channel: str,
        thread_key: str | None,
        sdk_session_id_factory: SessionIdFactory,
    ) -> SessionRecord: ...

    async def touch(self, record: SessionRecord, summary: str | None = None) -> None:
        """Update `updated_at` and optionally `last_summary` on the record."""


@runtime_checkable
class UserMemoryStore(Protocol):
    """Per-user fact store (R20). Strictly scoped by `user_id`."""

    async def search(self, user_id: str, query: str, k: int = 5) -> list[MemoryHit]: ...

    async def add(
        self,
        user_id: str,
        text: str,
        meta: dict[str, Any] | None = None,
    ) -> None: ...


@runtime_checkable
class KnowledgeStore(Protocol):
    """Shared knowledge base, multi-tenant by `user_id` (R21, R26).

    Adapters MUST filter every search by `user_id`. Writes MUST tag every
    inserted row with the inserting user's id so multi-tenant isolation
    holds across restarts.
    """

    async def search(self, user_id: str, query: str, k: int = 5) -> list[MemoryHit]: ...

    async def add(
        self,
        user_id: str,
        text: str,
        meta: dict[str, Any] | None = None,
    ) -> None: ...


@dataclass(frozen=True, slots=True)
class ConversationMessage:
    """One entry in an ordered per-`(user_id, thread_key)` conversation log (R7).

    The shape is deliberately OpenAI Chat-Completions-shaped so providers
    can serialise directly without a translation layer, while still
    covering the common Chat Completions tool-call dance:

    ``role``
        Speaker. Four-state literal; Chat Completions uses the same set.
    ``content``
        Natural-language text. ``None`` is valid for assistant turns that
        only produce tool calls, and for tool results that are structured.
    ``tool_calls``
        Raw OpenAI Chat Completions ``tool_calls`` list; only set on
        assistant turns requesting tool invocations.
    ``tool_call_id``
        The id the assistant asked us to respond to; only set on ``tool``
        role rows.
    ``created_at``
        Insertion time. Persisted as ISO-8601 in SQLite; providers use it
        for pruning and observability.
    """

    role: Literal["user", "assistant", "tool", "system"]
    content: str | None
    tool_calls: list[dict[str, Any]] | None
    tool_call_id: str | None
    created_at: datetime


@runtime_checkable
class ConversationStore(Protocol):
    """Ordered per-`(user_id, thread_key)` message log for non-Claude providers (R7, R8).

    ``ClaudeSDKProvider`` ignores this surface entirely — the Agent SDK
    owns session state. Every other provider (OpenAI-compat, Ollama, etc.)
    loads the current history at turn start, streams the new user + tool +
    assistant exchanges, and appends them before returning.

    Read failures MUST NOT crash a turn: adapters log and return ``[]`` so
    the turn continues with only the current message (KD12). Write failures
    MUST raise so the turn worker's ``on_turn_error`` runs and the operator
    sees the persistence bug loudly.
    """

    async def load(self, *, user_id: str, thread_key: str | None) -> list[ConversationMessage]: ...

    async def append(
        self,
        *,
        user_id: str,
        thread_key: str | None,
        messages: Sequence[ConversationMessage],
    ) -> None: ...

    async def clear(self, *, user_id: str, thread_key: str | None) -> None: ...


@runtime_checkable
class VectorStore(Protocol):
    """Low-level vector interface — optional backend contract.

    Most users go through `KnowledgeStore`. `VectorStore` exists so
    adapters can reuse a common embedding + search plumbing across
    stores without duplicating logic.
    """

    async def upsert(
        self,
        namespace: str,
        id: str,
        vector: list[float],
        meta: dict[str, Any],
    ) -> None: ...

    async def query(
        self,
        namespace: str,
        vector: list[float],
        k: int,
        filter: dict[str, Any] | None = None,
    ) -> list[MemoryHit]: ...
