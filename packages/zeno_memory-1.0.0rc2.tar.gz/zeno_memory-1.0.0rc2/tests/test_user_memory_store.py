"""Tests for `SqliteUserMemoryStore` — keyword-rank search + S7 isolation."""

from __future__ import annotations

from zeno.memory.sqlite.user_memory_store import SqliteUserMemoryStore


async def test_add_then_search_returns_hit(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    await user_memory_store.add("alice", "likes ramen")
    hits = await user_memory_store.search("alice", "ramen")
    assert len(hits) == 1
    assert hits[0].text == "likes ramen"
    assert hits[0].score >= 1.0


async def test_tokenized_search_finds_across_tokens(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    await user_memory_store.add("alice", "prefers spicy ramen on Tuesdays")
    hits = await user_memory_store.search("alice", "loves noodles? ramen please")
    assert any("ramen" in hit.text for hit in hits)


async def test_empty_query_returns_empty(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    await user_memory_store.add("alice", "hello")
    hits = await user_memory_store.search("alice", "   ")
    assert hits == []


async def test_duplicate_text_dedups_on_add(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    await user_memory_store.add("alice", "likes ramen")
    await user_memory_store.add("alice", "likes ramen", meta={"source": "chat"})
    hits = await user_memory_store.search("alice", "ramen")
    assert len(hits) == 1
    assert hits[0].meta.get("source") == "chat"


async def test_cross_user_isolation_zero_bleed(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    """S7 blueprint — no user may ever see another user's memory."""
    await user_memory_store.add("alice", "alice likes ramen")
    await user_memory_store.add("bob", "bob likes pizza")

    alice_hits = await user_memory_store.search("alice", "likes")
    bob_hits = await user_memory_store.search("bob", "likes")

    assert all("alice" in hit.text or "ramen" in hit.text for hit in alice_hits)
    assert all("bob" in hit.text or "pizza" in hit.text for hit in bob_hits)
    assert not any("pizza" in hit.text for hit in alice_hits)
    assert not any("ramen" in hit.text for hit in bob_hits)


async def test_k_limits_result_count(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    for i in range(10):
        await user_memory_store.add("alice", f"fact {i} about ramen")
    hits = await user_memory_store.search("alice", "ramen", k=3)
    assert len(hits) == 3


async def test_ranking_prefers_more_matches(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    await user_memory_store.add("alice", "ramen")
    await user_memory_store.add("alice", "spicy ramen noodles with ramen broth")
    hits = await user_memory_store.search("alice", "ramen noodles")
    assert hits[0].text == "spicy ramen noodles with ramen broth"
