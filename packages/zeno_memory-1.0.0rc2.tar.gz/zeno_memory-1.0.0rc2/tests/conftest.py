"""Shared fixtures for the zeno-memory test suite."""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

import pytest
from zeno.memory.sqlite.session_store import SqliteSessionStore
from zeno.memory.sqlite.user_memory_store import SqliteUserMemoryStore


@pytest.fixture
def tmp_db_path(tmp_path: Path) -> Iterator[Path]:
    path = tmp_path / "zeno.sqlite3"
    yield path


@pytest.fixture
def session_store(tmp_db_path: Path) -> SqliteSessionStore:
    return SqliteSessionStore(tmp_db_path)


@pytest.fixture
def user_memory_store(tmp_db_path: Path) -> SqliteUserMemoryStore:
    return SqliteUserMemoryStore(tmp_db_path)
