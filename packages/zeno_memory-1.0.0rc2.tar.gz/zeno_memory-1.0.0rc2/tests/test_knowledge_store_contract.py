"""Shared contract tests every `KnowledgeStore` adapter must pass (R12, R21, R22).

The contract:
  - `add(user_id, text, meta=None)` inserts; empty text rejected.
  - `search(user_id, query, k=5)` returns hits scoped to `user_id` only.
  - Similarity-ordered: identical or overlapping text outranks unrelated text.
  - Cross-user isolation: user A's search never surfaces user B's rows. (S7)
  - S3 blueprint: the public surface is identical regardless of backend.

These tests import the adapters lazily so `zeno-memory` does not pull
`chromadb` or `qdrant-client` as runtime deps. When the adapter package
is not installed, the parameter is skipped rather than failing.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path
from typing import TYPE_CHECKING, Any

import pytest

if TYPE_CHECKING:
    from zeno.memory.protocols import KnowledgeStore


def _chroma_available() -> bool:
    return importlib.util.find_spec("zeno.chroma.store") is not None


def _qdrant_available() -> bool:
    return importlib.util.find_spec("zeno.qdrant.store") is not None


async def _make_chroma(tmp_path: Path) -> KnowledgeStore:
    from zeno.chroma.store import ChromaKnowledgeStore

    return ChromaKnowledgeStore(persist_dir=tmp_path / "chroma")


async def _make_qdrant(tmp_path: Path) -> KnowledgeStore:
    from zeno.qdrant.store import QdrantKnowledgeStore

    return QdrantKnowledgeStore(path=tmp_path / "qdrant")


_ADAPTERS: list[tuple[str, Any]] = []
if _chroma_available():
    _ADAPTERS.append(("chroma", _make_chroma))
if _qdrant_available():
    _ADAPTERS.append(("qdrant", _make_qdrant))


@pytest.fixture(params=_ADAPTERS, ids=[name for name, _ in _ADAPTERS])
async def knowledge_store(request: pytest.FixtureRequest, tmp_path: Path) -> KnowledgeStore:
    _name, factory = request.param
    store: KnowledgeStore = await factory(tmp_path)
    return store


pytestmark = [
    pytest.mark.slow,
    pytest.mark.skipif(not _ADAPTERS, reason="no KnowledgeStore adapters installed"),
]


async def test_add_then_search_returns_hit(
    knowledge_store: KnowledgeStore,
) -> None:
    await knowledge_store.add("alice", "alice likes ramen")
    hits = await knowledge_store.search("alice", "ramen")
    assert any("ramen" in hit.text.lower() for hit in hits)


async def test_empty_store_search_returns_empty(
    knowledge_store: KnowledgeStore,
) -> None:
    hits = await knowledge_store.search("alice", "anything")
    assert hits == []


async def test_empty_text_rejected(knowledge_store: KnowledgeStore) -> None:
    with pytest.raises(ValueError):
        await knowledge_store.add("alice", "   ")


async def test_cross_user_isolation(knowledge_store: KnowledgeStore) -> None:
    """S7 blueprint: Bob must never see Alice's rows."""
    await knowledge_store.add("alice", "alice secret passphrase")
    await knowledge_store.add("bob", "bob secret passphrase")

    alice_hits = await knowledge_store.search("alice", "secret")
    bob_hits = await knowledge_store.search("bob", "secret")

    assert all("bob" not in hit.text for hit in alice_hits)
    assert all("alice" not in hit.text for hit in bob_hits)


async def test_similarity_ordering(knowledge_store: KnowledgeStore) -> None:
    await knowledge_store.add("alice", "alice loves chocolate ice cream")
    await knowledge_store.add("alice", "the weather is pleasant today")

    hits = await knowledge_store.search("alice", "chocolate dessert", k=2)

    # Adapter must return something; top hit must be the chocolate row.
    assert hits
    assert "chocolate" in hits[0].text.lower()


async def test_k_bounds_result_count(knowledge_store: KnowledgeStore) -> None:
    for idx in range(5):
        await knowledge_store.add("alice", f"note number {idx}")
    hits = await knowledge_store.search("alice", "note", k=2)
    assert len(hits) <= 2
