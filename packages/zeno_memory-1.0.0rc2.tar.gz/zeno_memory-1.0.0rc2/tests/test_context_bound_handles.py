"""Tests for `ThreeLayer` + `MemoryView` context-bound handles.

Also parameterized across `SqliteUserMemoryStore` and
`VectorBackedUserMemoryStore` for the critical S7 cross-user isolation
test.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import pytest
from zeno.memory.protocols import MemoryHit, UserMemoryStore
from zeno.memory.sqlite.user_memory_store import SqliteUserMemoryStore
from zeno.memory.three_layer import ThreeLayer
from zeno.memory.vector_backed.user_memory_store import VectorBackedUserMemoryStore
from zeno.testing import InMemoryConversationStore


@dataclass
class _FakeKnowledgeStore:
    """Dict-backed knowledge store for VectorBackedUserMemoryStore tests."""

    rows: list[tuple[str, str, dict[str, Any]]] = field(default_factory=list)

    async def add(self, user_id: str, text: str, meta: dict[str, Any] | None = None) -> None:
        self.rows.append((user_id, text, meta or {}))

    async def search(self, user_id: str, query: str, k: int = 5) -> list[MemoryHit]:
        # Return user-scoped rows that share any token with `query`.
        tokens = set(query.lower().split())
        hits: list[MemoryHit] = []
        for ruid, rtext, rmeta in self.rows:
            if ruid != user_id:
                continue
            row_tokens = set(rtext.lower().split())
            overlap = tokens & row_tokens
            if overlap:
                hits.append(MemoryHit(text=rtext, score=float(len(overlap)), meta=rmeta))
        hits.sort(key=lambda h: h.score, reverse=True)
        return hits[:k]


async def test_user_memory_view_hides_user_id(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    three = ThreeLayer(
        session=_NoopSessionStore(),
        user_memory=user_memory_store,
        knowledge=_FakeKnowledgeStore(),
        conversation=InMemoryConversationStore(),
    )
    view = three.view_for(user_id="alice", channel="cli", thread_key=None)
    await view.user.add("alice likes ramen")
    hits = await view.user.search("ramen")
    assert len(hits) == 1
    # Public surface is user-id-free:
    assert not hasattr(view.user, "user_id")


async def test_vector_backed_tags_namespace_and_user_id() -> None:
    knowledge = _FakeKnowledgeStore()
    store = VectorBackedUserMemoryStore(knowledge_store=knowledge)
    await store.add("alice", "prefers dark mode")
    assert knowledge.rows == [
        (
            "alice",
            "prefers dark mode",
            {"kind": "user_memory", "user_id": "alice"},
        )
    ]


async def test_vector_backed_search_filters_namespace() -> None:
    knowledge = _FakeKnowledgeStore()
    # Pre-seed with mixed-namespace facts for the same user.
    knowledge.rows.extend(
        [
            ("alice", "alice dark mode", {"kind": "user_memory", "user_id": "alice"}),
            ("alice", "shared tip about ramen", {"kind": "shared"}),
        ]
    )
    store = VectorBackedUserMemoryStore(knowledge_store=knowledge)
    hits = await store.search("alice", "alice")
    assert len(hits) == 1
    assert hits[0].text == "alice dark mode"


async def test_vector_backed_dedups_near_duplicates() -> None:
    knowledge = _FakeKnowledgeStore()
    store = VectorBackedUserMemoryStore(knowledge_store=knowledge, dedup_threshold=0.5)
    await store.add("alice", "dark mode")
    await store.add("alice", "dark mode")  # exact duplicate
    # FakeKnowledgeStore scoring returns len(overlap) -> 2 for full token match.
    assert len(knowledge.rows) == 1


@pytest.mark.parametrize(
    "store_factory",
    [
        "sqlite",
        "vector_backed",
    ],
)
async def test_cross_user_bleed_blocked_in_both_implementations(
    tmp_db_path: Any, store_factory: str
) -> None:
    """S7 blueprint — must hold for both implementations."""
    store: UserMemoryStore
    if store_factory == "sqlite":
        store = SqliteUserMemoryStore(tmp_db_path)
    else:
        store = VectorBackedUserMemoryStore(knowledge_store=_FakeKnowledgeStore())

    await store.add("alice", "alice secret")
    await store.add("bob", "bob secret")

    alice_hits = await store.search("alice", "secret")
    bob_hits = await store.search("bob", "secret")

    assert not any("bob" in hit.text for hit in alice_hits)
    assert not any("alice" in hit.text for hit in bob_hits)


@dataclass
class _NoopSessionStore:
    """Stand-in session store for handle tests that don't exercise sessions."""

    async def get(self, user_id: str, channel: str, thread_key: str | None) -> Any:
        return None

    async def get_or_create(
        self,
        user_id: str,
        channel: str,
        thread_key: str | None,
        sdk_session_id_factory: Any,
    ) -> Any:  # pragma: no cover
        raise NotImplementedError

    async def touch(self, record: Any, summary: str | None = None) -> None:
        return None
