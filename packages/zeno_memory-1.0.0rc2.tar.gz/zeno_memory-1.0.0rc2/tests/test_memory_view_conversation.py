"""Tests for `ConversationHandle` binding through `ThreeLayer.view_for` (IU2).

Proves the v0.3.0 invariant: when a turn worker calls
``ThreeLayer.view_for(user_id=..., thread_key=...)``, the resulting
``MemoryView.conversation`` is a ``ConversationHandle`` pre-bound to that
user and thread — tools and providers can only reach their own messages.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from zeno.memory.handles import ConversationHandle
from zeno.memory.protocols import (
    ConversationMessage,
    MemoryHit,
)
from zeno.memory.three_layer import ThreeLayer
from zeno.testing import InMemoryConversationStore


@dataclass
class _NoopSessionStore:
    async def get(self, user_id: str, channel: str, thread_key: str | None) -> Any:
        return None

    async def get_or_create(
        self,
        user_id: str,
        channel: str,
        thread_key: str | None,
        sdk_session_id_factory: Any,
    ) -> Any:  # pragma: no cover
        raise NotImplementedError

    async def touch(self, record: Any, summary: str | None = None) -> None:
        return None


@dataclass
class _NoopUserMemoryStore:
    async def search(self, user_id: str, query: str, k: int = 5) -> list[MemoryHit]:
        return []

    async def add(self, user_id: str, text: str, meta: dict[str, Any] | None = None) -> None:
        return None


@dataclass
class _NoopKnowledgeStore:
    rows: list[tuple[str, str, dict[str, Any]]] = field(default_factory=list)

    async def search(self, user_id: str, query: str, k: int = 5) -> list[MemoryHit]:
        return []

    async def add(self, user_id: str, text: str, meta: dict[str, Any] | None = None) -> None:
        self.rows.append((user_id, text, meta or {}))


def _three(conversation: InMemoryConversationStore) -> ThreeLayer:
    return ThreeLayer(
        session=_NoopSessionStore(),
        user_memory=_NoopUserMemoryStore(),
        knowledge=_NoopKnowledgeStore(),
        conversation=conversation,
    )


def _msg(content: str) -> ConversationMessage:
    return ConversationMessage(
        role="user",
        content=content,
        tool_calls=None,
        tool_call_id=None,
        created_at=datetime(2026, 4, 21, 12, 0, 0, tzinfo=UTC),
    )


async def test_view_for_binds_conversation_handle_to_user_and_thread() -> None:
    store = InMemoryConversationStore()
    three = _three(store)
    view = three.view_for(user_id="alice", channel="cli", thread_key="t1")
    assert isinstance(view.conversation, ConversationHandle)
    await view.conversation.append([_msg("from-alice-t1")])
    loaded = await store.load(user_id="alice", thread_key="t1")
    assert [m.content for m in loaded] == ["from-alice-t1"]


async def test_conversation_handle_cross_user_isolation() -> None:
    store = InMemoryConversationStore()
    three = _three(store)
    alice_view = three.view_for(user_id="alice", channel="cli", thread_key=None)
    bob_view = three.view_for(user_id="bob", channel="cli", thread_key=None)
    await alice_view.conversation.append([_msg("alice-secret")])
    await bob_view.conversation.append([_msg("bob-secret")])

    alice_loaded = await alice_view.conversation.load()
    bob_loaded = await bob_view.conversation.load()
    assert [m.content for m in alice_loaded] == ["alice-secret"]
    assert [m.content for m in bob_loaded] == ["bob-secret"]


async def test_conversation_handle_cross_thread_isolation() -> None:
    store = InMemoryConversationStore()
    three = _three(store)
    t1 = three.view_for(user_id="alice", channel="cli", thread_key="t1")
    t2 = three.view_for(user_id="alice", channel="cli", thread_key="t2")
    await t1.conversation.append([_msg("thread-1")])
    await t2.conversation.append([_msg("thread-2")])
    assert [m.content for m in await t1.conversation.load()] == ["thread-1"]
    assert [m.content for m in await t2.conversation.load()] == ["thread-2"]


async def test_conversation_handle_clear_only_target_thread() -> None:
    store = InMemoryConversationStore()
    three = _three(store)
    t1 = three.view_for(user_id="alice", channel="cli", thread_key="t1")
    t2 = three.view_for(user_id="alice", channel="cli", thread_key="t2")
    await t1.conversation.append([_msg("x")])
    await t2.conversation.append([_msg("y")])
    await t1.conversation.clear()
    assert await t1.conversation.load() == []
    assert [m.content for m in await t2.conversation.load()] == ["y"]
