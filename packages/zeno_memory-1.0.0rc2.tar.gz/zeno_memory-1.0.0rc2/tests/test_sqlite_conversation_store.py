"""Tests for `SqliteConversationStore` — the 4th memory primitive (IU2).

Covers every scenario enumerated in the IU2 plan section: roundtrip,
per-thread and per-user isolation, empty load, tool_calls roundtrip,
concurrent sequence monotonicity, migration path, KD12 read-vs-write
failure postures, bounded growth (`max_messages_per_thread`), and the
one-time per-process growth WARNING.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime, timedelta
from pathlib import Path

import aiosqlite
import pytest
from zeno.memory.protocols import ConversationMessage
from zeno.memory.sqlite.conversation_store import SqliteConversationStore


def _msg(
    *,
    role: str = "user",
    content: str | None = "hi",
    tool_calls: list[dict[str, object]] | None = None,
    tool_call_id: str | None = None,
    ts: datetime | None = None,
) -> ConversationMessage:
    return ConversationMessage(
        role=role,  # type: ignore[arg-type]
        content=content,
        tool_calls=tool_calls,
        tool_call_id=tool_call_id,
        created_at=ts or datetime(2026, 4, 21, 12, 0, 0, tzinfo=UTC),
    )


@pytest.fixture
def conversation_store(tmp_db_path: Path) -> SqliteConversationStore:
    return SqliteConversationStore(tmp_db_path)


# -----------------------------------------------------------------------------
# Happy paths
# -----------------------------------------------------------------------------


async def test_roundtrip_preserves_order_and_fields(
    conversation_store: SqliteConversationStore,
) -> None:
    base = datetime(2026, 4, 21, 12, 0, 0, tzinfo=UTC)
    msgs = [
        _msg(role="user", content="hey", ts=base),
        _msg(role="assistant", content="hello back", ts=base + timedelta(seconds=1)),
        _msg(role="user", content="question?", ts=base + timedelta(seconds=2)),
    ]
    await conversation_store.append(user_id="alice", thread_key=None, messages=msgs)
    loaded = await conversation_store.load(user_id="alice", thread_key=None)
    assert [m.content for m in loaded] == ["hey", "hello back", "question?"]
    assert [m.role for m in loaded] == ["user", "assistant", "user"]
    assert [m.created_at for m in loaded] == [m.created_at for m in msgs]


async def test_per_thread_isolation(conversation_store: SqliteConversationStore) -> None:
    await conversation_store.append(user_id="alice", thread_key="t1", messages=[_msg(content="t1")])
    await conversation_store.append(user_id="alice", thread_key="t2", messages=[_msg(content="t2")])
    loaded_t1 = await conversation_store.load(user_id="alice", thread_key="t1")
    loaded_t2 = await conversation_store.load(user_id="alice", thread_key="t2")
    assert [m.content for m in loaded_t1] == ["t1"]
    assert [m.content for m in loaded_t2] == ["t2"]


async def test_per_user_isolation(conversation_store: SqliteConversationStore) -> None:
    await conversation_store.append(
        user_id="alice", thread_key=None, messages=[_msg(content="alice-only")]
    )
    await conversation_store.append(
        user_id="bob", thread_key=None, messages=[_msg(content="bob-only")]
    )
    loaded_alice = await conversation_store.load(user_id="alice", thread_key=None)
    loaded_bob = await conversation_store.load(user_id="bob", thread_key=None)
    assert [m.content for m in loaded_alice] == ["alice-only"]
    assert [m.content for m in loaded_bob] == ["bob-only"]


# -----------------------------------------------------------------------------
# Edge cases
# -----------------------------------------------------------------------------


async def test_load_empty_returns_empty_list(
    conversation_store: SqliteConversationStore,
) -> None:
    result = await conversation_store.load(user_id="ghost", thread_key=None)
    assert result == []


async def test_tool_calls_roundtrip_through_json_column(
    conversation_store: SqliteConversationStore,
) -> None:
    tool_calls: list[dict[str, object]] = [
        {
            "id": "c1",
            "type": "function",
            "function": {"name": "recall", "arguments": '{"q": "birthday"}'},
        }
    ]
    await conversation_store.append(
        user_id="alice",
        thread_key=None,
        messages=[_msg(role="assistant", content=None, tool_calls=tool_calls)],
    )
    loaded = await conversation_store.load(user_id="alice", thread_key=None)
    assert loaded[0].content is None
    assert loaded[0].tool_calls == tool_calls


async def test_tool_response_row_roundtrip(
    conversation_store: SqliteConversationStore,
) -> None:
    await conversation_store.append(
        user_id="alice",
        thread_key=None,
        messages=[_msg(role="tool", content="result-payload", tool_call_id="c1")],
    )
    loaded = await conversation_store.load(user_id="alice", thread_key=None)
    assert loaded[0].tool_call_id == "c1"
    assert loaded[0].role == "tool"


async def test_clear_removes_only_target_thread(
    conversation_store: SqliteConversationStore,
) -> None:
    await conversation_store.append(
        user_id="alice", thread_key="t1", messages=[_msg(content="to-clear")]
    )
    await conversation_store.append(
        user_id="alice", thread_key="t2", messages=[_msg(content="to-keep")]
    )
    await conversation_store.clear(user_id="alice", thread_key="t1")
    assert await conversation_store.load(user_id="alice", thread_key="t1") == []
    kept = await conversation_store.load(user_id="alice", thread_key="t2")
    assert [m.content for m in kept] == ["to-keep"]


async def test_concurrent_appends_produce_distinct_sequences(tmp_db_path: Path) -> None:
    """Parallel `asyncio.gather` appends to the same `(user_id, thread_key)` must
    not collide on `sequence`. Uses a per-thread asyncio.Lock inside the store.
    """
    store = SqliteConversationStore(tmp_db_path)

    async def one(content: str) -> None:
        await store.append(user_id="alice", thread_key=None, messages=[_msg(content=content)])

    await asyncio.gather(*(one(f"m-{i}") for i in range(8)))

    conn = await aiosqlite.connect(tmp_db_path)
    try:
        cur = await conn.execute(
            "SELECT sequence FROM conversations "
            "WHERE user_id = 'alice' AND thread_key IS NULL "
            "ORDER BY sequence"
        )
        seqs = [row[0] for row in await cur.fetchall()]
    finally:
        await conn.close()
    assert seqs == list(range(8))


async def test_max_messages_per_thread_prunes_oldest(tmp_db_path: Path) -> None:
    """With `max_messages_per_thread=5`, appending 8 leaves only the 5 newest."""
    store = SqliteConversationStore(tmp_db_path, max_messages_per_thread=5)
    base = datetime(2026, 4, 21, 12, 0, 0, tzinfo=UTC)
    for i in range(8):
        await store.append(
            user_id="alice",
            thread_key=None,
            messages=[_msg(content=f"m-{i}", ts=base + timedelta(seconds=i))],
        )
    loaded = await store.load(user_id="alice", thread_key=None)
    assert [m.content for m in loaded] == [f"m-{i}" for i in range(3, 8)]

    # Verify pruned rows are gone from the DB file, not just hidden on load.
    conn = await aiosqlite.connect(tmp_db_path)
    try:
        cur = await conn.execute(
            "SELECT COUNT(*) FROM conversations WHERE user_id = 'alice' AND thread_key IS NULL"
        )
        row = await cur.fetchone()
    finally:
        await conn.close()
    assert row is not None and row[0] == 5


async def test_max_messages_per_thread_scoped_per_key(tmp_db_path: Path) -> None:
    """The cap is per `(user_id, thread_key)`, not global."""
    store = SqliteConversationStore(tmp_db_path, max_messages_per_thread=2)
    for i in range(4):
        await store.append(user_id="alice", thread_key="t1", messages=[_msg(content=f"t1-{i}")])
    for i in range(4):
        await store.append(user_id="alice", thread_key="t2", messages=[_msg(content=f"t2-{i}")])
    loaded_t1 = await store.load(user_id="alice", thread_key="t1")
    loaded_t2 = await store.load(user_id="alice", thread_key="t2")
    assert [m.content for m in loaded_t1] == ["t1-2", "t1-3"]
    assert [m.content for m in loaded_t2] == ["t2-2", "t2-3"]


async def test_growth_warning_logged_once_per_thread(
    tmp_db_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    store = SqliteConversationStore(tmp_db_path, warn_messages_per_thread=3)
    caplog.set_level(logging.WARNING, logger="zeno.memory.sqlite.conversation_store")
    # Cross the threshold on the 4th append.
    for i in range(5):
        await store.append(user_id="alice", thread_key=None, messages=[_msg(content=f"m-{i}")])
    warn_records = [
        rec
        for rec in caplog.records
        if rec.levelno == logging.WARNING and "conversation thread growing" in rec.message
    ]
    assert len(warn_records) == 1, f"expected 1 warning, got {len(warn_records)}"


async def test_growth_warning_per_thread_independent(
    tmp_db_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    store = SqliteConversationStore(tmp_db_path, warn_messages_per_thread=2)
    caplog.set_level(logging.WARNING, logger="zeno.memory.sqlite.conversation_store")
    # Two independent threads; each should warn exactly once.
    for tk in ("t1", "t2"):
        for i in range(4):
            await store.append(
                user_id="alice",
                thread_key=tk,
                messages=[_msg(content=f"{tk}-{i}")],
            )
    warn_records = [
        rec
        for rec in caplog.records
        if rec.levelno == logging.WARNING and "conversation thread growing" in rec.message
    ]
    assert len(warn_records) == 2


# -----------------------------------------------------------------------------
# Failure posture (KD12)
# -----------------------------------------------------------------------------


async def test_read_failure_returns_empty_and_logs(
    tmp_db_path: Path,
    caplog: pytest.LogCaptureFixture,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """KD12: read failure → WARN + return `[]`. Never crash the turn."""
    store = SqliteConversationStore(tmp_db_path)
    # Pre-seed so the store's first call to `_connect()` succeeds then we
    # break subsequent reads.
    await store.append(user_id="alice", thread_key=None, messages=[_msg(content="seed")])

    original_connect = aiosqlite.connect

    def boom(*a: object, **kw: object) -> object:
        raise OSError("disk gone")

    monkeypatch.setattr("zeno.memory.sqlite.conversation_store.aiosqlite.connect", boom)
    caplog.set_level(logging.WARNING, logger="zeno.memory.sqlite.conversation_store")
    result = await store.load(user_id="alice", thread_key=None)
    assert result == []
    assert any(
        rec.levelno == logging.WARNING and "conversation load failed" in rec.message
        for rec in caplog.records
    )

    # Restore so teardown is clean (fixtures use aiosqlite).
    monkeypatch.setattr("zeno.memory.sqlite.conversation_store.aiosqlite.connect", original_connect)


async def test_write_failure_raises(tmp_db_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """KD12: write failure → raise. Persistence bugs must surface loudly."""
    store = SqliteConversationStore(tmp_db_path)
    # Force the first connect attempt (which also seeds schema) to fail.
    monkeypatch.setattr(
        "zeno.memory.sqlite.conversation_store.aiosqlite.connect",
        lambda *a, **kw: (_ for _ in ()).throw(OSError("no disk")),
    )
    with pytest.raises(OSError):
        await store.append(user_id="alice", thread_key=None, messages=[_msg()])
