"""Tests for `SqliteSessionStore`."""

from __future__ import annotations

import asyncio

from zeno.memory.sqlite.session_store import SqliteSessionStore


async def test_get_or_create_mints_once(session_store: SqliteSessionStore) -> None:
    record_a = await session_store.get_or_create(
        "alice", "cli", None, sdk_session_id_factory=lambda: "sdk-a"
    )
    record_b = await session_store.get_or_create(
        "alice", "cli", None, sdk_session_id_factory=lambda: "sdk-b"
    )
    assert record_a.sdk_session_id == "sdk-a"
    assert record_b.sdk_session_id == "sdk-a"  # Re-used, not re-minted.


async def test_thread_key_none_is_its_own_slot(
    session_store: SqliteSessionStore,
) -> None:
    r_no_thread = await session_store.get_or_create(
        "alice", "cli", None, sdk_session_id_factory=lambda: "sdk-root"
    )
    r_t1 = await session_store.get_or_create(
        "alice", "cli", "t1", sdk_session_id_factory=lambda: "sdk-t1"
    )
    assert r_no_thread.sdk_session_id == "sdk-root"
    assert r_t1.sdk_session_id == "sdk-t1"


async def test_get_returns_none_for_unknown_key(
    session_store: SqliteSessionStore,
) -> None:
    assert await session_store.get("ghost", "cli", None) is None


async def test_async_factory_is_awaited(session_store: SqliteSessionStore) -> None:
    async def factory() -> str:
        await asyncio.sleep(0)
        return "sdk-async"

    record = await session_store.get_or_create("alice", "cli", None, sdk_session_id_factory=factory)
    assert record.sdk_session_id == "sdk-async"


async def test_touch_updates_updated_at_and_summary(
    session_store: SqliteSessionStore,
) -> None:
    record = await session_store.get_or_create(
        "alice", "cli", None, sdk_session_id_factory=lambda: "sdk-a"
    )
    original_updated = record.updated_at
    await asyncio.sleep(1.05)  # coarse second-granularity timestamps
    await session_store.touch(record, summary="hi there")
    refreshed = await session_store.get("alice", "cli", None)
    assert refreshed is not None
    assert refreshed.updated_at >= original_updated
    assert refreshed.last_summary == "hi there"
