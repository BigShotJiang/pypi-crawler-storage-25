"""Tests for the schema migrator."""

from __future__ import annotations

import asyncio
from pathlib import Path

import aiosqlite
from zeno.memory.sqlite.migrate import ensure_schema


async def test_ensure_schema_creates_all_tables(tmp_db_path: Path) -> None:
    conn = await aiosqlite.connect(tmp_db_path)
    try:
        await ensure_schema(conn)
        cur = await conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
        tables = {row[0] for row in await cur.fetchall()}
    finally:
        await conn.close()

    assert "schema_version" in tables
    assert "sessions" in tables
    assert "user_memories" in tables
    assert "conversations" in tables


async def test_ensure_schema_upgrades_v02_db(tmp_db_path: Path) -> None:
    """A DB provisioned under v0.2 (three tables, migrations 1-3) gains the
    `conversations` table on next open, without touching existing rows.

    Simulates the operator's upgrade path: old persisted data stays intact
    and the 004 migration fills in the new table.
    """
    conn = await aiosqlite.connect(tmp_db_path)
    try:
        # Simulate the pre-IU2 state: apply migrations 1-3 only.
        await conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_version ("
            "version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)"
        )
        await conn.executescript(
            "CREATE TABLE sessions ("
            " user_id TEXT NOT NULL, channel TEXT NOT NULL, thread_key TEXT,"
            " sdk_session_id TEXT NOT NULL, created_at INTEGER NOT NULL,"
            " updated_at INTEGER NOT NULL, last_summary TEXT,"
            " PRIMARY KEY (user_id, channel, thread_key));"
        )
        await conn.executescript(
            "CREATE TABLE user_memories ("
            " id INTEGER PRIMARY KEY AUTOINCREMENT,"
            " user_id TEXT NOT NULL, text TEXT NOT NULL, meta TEXT,"
            " created_at INTEGER NOT NULL);"
        )
        await conn.executemany(
            "INSERT INTO schema_version (version, applied_at) VALUES (?, 0)",
            [(1,), (2,), (3,)],
        )
        # Seed a row that must survive the upgrade.
        await conn.execute(
            "INSERT INTO sessions"
            " (user_id, channel, thread_key, sdk_session_id, created_at, updated_at)"
            " VALUES ('alice', 'cli', NULL, 'sdk-legacy', 0, 0)"
        )
        await conn.commit()
    finally:
        await conn.close()

    conn = await aiosqlite.connect(tmp_db_path)
    try:
        await ensure_schema(conn)
        cur = await conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
        tables = {row[0] for row in await cur.fetchall()}
        cur = await conn.execute("SELECT sdk_session_id FROM sessions WHERE user_id = 'alice'")
        legacy = await cur.fetchone()
    finally:
        await conn.close()

    assert "conversations" in tables
    assert legacy is not None
    assert legacy[0] == "sdk-legacy"


async def test_ensure_schema_is_idempotent(tmp_db_path: Path) -> None:
    for _ in range(3):
        conn = await aiosqlite.connect(tmp_db_path)
        try:
            await ensure_schema(conn)
        finally:
            await conn.close()

    conn = await aiosqlite.connect(tmp_db_path)
    try:
        cur = await conn.execute("SELECT COUNT(*) FROM schema_version GROUP BY version")
        rows = await cur.fetchall()
    finally:
        await conn.close()

    # Each version should be recorded exactly once.
    assert all(row[0] == 1 for row in rows)


async def test_ensure_schema_handles_concurrent_init(tmp_db_path: Path) -> None:
    async def init_once() -> None:
        conn = await aiosqlite.connect(tmp_db_path)
        try:
            await ensure_schema(conn)
        finally:
            await conn.close()

    await asyncio.gather(*(init_once() for _ in range(4)))

    conn = await aiosqlite.connect(tmp_db_path)
    try:
        cur = await conn.execute("SELECT version, COUNT(*) FROM schema_version GROUP BY version")
        rows = await cur.fetchall()
    finally:
        await conn.close()

    # Each migration version applied exactly once.
    assert all(row[1] == 1 for row in rows)
