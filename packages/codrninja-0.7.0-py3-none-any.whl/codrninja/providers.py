"""Multi-provider support for codrninja — not just Ollama!"""

import json
import os
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any

import requests


class BaseProvider(ABC):
    """Abstract base class for AI providers."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
    
    @abstractmethod
    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        """Send chat messages and return response."""
        pass
    
    @abstractmethod
    def list_models(self) -> List[str]:
        """List available models."""
        pass
    
    @abstractmethod
    def get_default_model(self) -> str:
        """Get default model for this provider."""
        pass


class OllamaProvider(BaseProvider):
    """Ollama provider for local models."""
    
    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        """Send chat to Ollama."""
        url = self.config.get("url", "http://localhost:11434")
        # Auto-add http:// if missing
        if not url.startswith("http://") and not url.startswith("https://"):
            url = "http://" + url
        model = model or self.config.get("model", "codellama")

        # Map reasoning level to context size
        reasoning = self.config.get("reasoning_level", "medium")
        num_ctx_map = {"none": 2048, "low": 4096, "medium": 8192, "high": 16384}
        num_ctx = num_ctx_map.get(reasoning, 8192)
        
        try:
            response = requests.post(
                f"{url}/api/chat",
                json={
                    "model": model,
                    "messages": messages,
                    "stream": False,
                    "options": {
                        "temperature": self.config.get("temperature", 0.7),
                        "num_predict": self.config.get("max_tokens", 4096),
                        "num_ctx": num_ctx
                    }
                },
                timeout=300
            )
            response.raise_for_status()
            data = response.json()
            
            return {
                "content": data.get("message", {}).get("content", ""),
                "model": model,
                "tokens_input": data.get("prompt_eval_count", 0),
                "tokens_output": data.get("eval_count", 0),
                "done": True
            }
        except requests.exceptions.Timeout:
            return {"error": "Request timed out", "content": ""}
        except requests.exceptions.ConnectionError:
            return {"error": f"Cannot connect to Ollama at {url}", "content": ""}
        except Exception as e:
            return {"error": str(e), "content": ""}
    
    def list_models(self) -> List[str]:
        """List Ollama models."""
        url = self.config.get("url", "http://localhost:11434")
        try:
            response = requests.get(f"{url}/api/tags", timeout=10)
            data = response.json()
            return [m["name"] for m in data.get("models", [])]
        except:
            return ["codellama", "llama2", "mistral"]
    
    def get_default_model(self) -> str:
        return self.config.get("model", "codellama")


class OpenAIProvider(BaseProvider):
    """OpenAI provider for GPT models."""
    
    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        """Send chat to OpenAI."""
        api_key = self.config.get("api_key") or os.environ.get("OPENAI_API_KEY")
        if not api_key:
            return {"error": "OpenAI API key not set", "content": ""}
        
        model = model or self.config.get("model", "gpt-4")
        
        try:
            response = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": model,
                    "messages": messages,
                    "temperature": self.config.get("temperature", 0.7),
                    "max_tokens": self.config.get("max_tokens", 4096)
                },
                timeout=300
            )
            response.raise_for_status()
            data = response.json()
            
            choice = data.get("choices", [{}])[0]
            usage = data.get("usage", {})
            
            return {
                "content": choice.get("message", {}).get("content", ""),
                "model": model,
                "tokens_input": usage.get("prompt_tokens", 0),
                "tokens_output": usage.get("completion_tokens", 0),
                "done": True
            }
        except requests.exceptions.Timeout:
            return {"error": "Request timed out", "content": ""}
        except Exception as e:
            return {"error": str(e), "content": ""}
    
    def list_models(self) -> List[str]:
        return ["gpt-4", "gpt-4-turbo", "gpt-3.5-turbo"]
    
    def get_default_model(self) -> str:
        return self.config.get("model", "gpt-4")


class AnthropicProvider(BaseProvider):
    """Anthropic provider for Claude models."""
    
    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        """Send chat to Anthropic."""
        api_key = self.config.get("api_key") or os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            return {"error": "Anthropic API key not set", "content": ""}
        
        model = model or self.config.get("model", "claude-3-sonnet-20240229")
        
        # Convert messages to Anthropic format
        system_msg = ""
        user_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system_msg = msg["content"]
            else:
                user_messages.append(msg)
        
        try:
            response = requests.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": api_key,
                    "Content-Type": "application/json",
                    "anthropic-version": "2023-06-01"
                },
                json={
                    "model": model,
                    "max_tokens": self.config.get("max_tokens", 4096),
                    "temperature": self.config.get("temperature", 0.7),
                    "system": system_msg,
                    "messages": [
                        {"role": m["role"], "content": m["content"]}
                        for m in user_messages
                    ]
                },
                timeout=300
            )
            response.raise_for_status()
            data = response.json()
            
            usage = data.get("usage", {})
            
            return {
                "content": data.get("content", [{}])[0].get("text", ""),
                "model": model,
                "tokens_input": usage.get("input_tokens", 0),
                "tokens_output": usage.get("output_tokens", 0),
                "done": True
            }
        except requests.exceptions.Timeout:
            return {"error": "Request timed out", "content": ""}
        except Exception as e:
            return {"error": str(e), "content": ""}
    
    def list_models(self) -> List[str]:
        return [
            "claude-3-opus-20240229",
            "claude-3-sonnet-20240229",
            "claude-3-haiku-20240307"
        ]
    
    def get_default_model(self) -> str:
        return self.config.get("model", "claude-3-sonnet-20240229")


class OpenRouterProvider(BaseProvider):
    """OpenRouter provider for multiple models."""
    
    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        """Send chat via OpenRouter."""
        api_key = self.config.get("api_key") or os.environ.get("OPENROUTER_API_KEY")
        if not api_key:
            return {"error": "OpenRouter API key not set", "content": ""}
        
        model = model or self.config.get("model", "openai/gpt-4")
        
        try:
            response = requests.post(
                "https://openrouter.ai/api/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": model,
                    "messages": messages,
                    "temperature": self.config.get("temperature", 0.7),
                    "max_tokens": self.config.get("max_tokens", 4096)
                },
                timeout=300
            )
            response.raise_for_status()
            data = response.json()
            
            choice = data.get("choices", [{}])[0]
            usage = data.get("usage", {})
            
            return {
                "content": choice.get("message", {}).get("content", ""),
                "model": model,
                "tokens_input": usage.get("prompt_tokens", 0),
                "tokens_output": usage.get("completion_tokens", 0),
                "done": True
            }
        except Exception as e:
            return {"error": str(e), "content": ""}
    
    def list_models(self) -> List[str]:
        return ["openai/gpt-4", "anthropic/claude-3-opus", "google/gemini-pro"]
    
    def get_default_model(self) -> str:
        return self.config.get("model", "openai/gpt-4")


class ProviderManager:
    """Manages all AI providers."""
    
    PROVIDERS = {
        "ollama": OllamaProvider,
        "openai": OpenAIProvider,
        "anthropic": AnthropicProvider,
        "openrouter": OpenRouterProvider,
    }
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.current_provider = config.get("provider", "ollama")
        self._provider_instance = None
    
    def get_provider(self, name: Optional[str] = None) -> BaseProvider:
        """Get provider instance."""
        provider_name = name or self.current_provider
        
        if provider_name not in self.PROVIDERS:
            raise ValueError(f"Unknown provider: {provider_name}. Available: {list(self.PROVIDERS.keys())}")
        
        # Get provider-specific config
        provider_config = self.config.get("providers", {}).get(provider_name, {})
        
        return self.PROVIDERS[provider_name](provider_config)
    
    def set_provider(self, name: str):
        """Set current provider."""
        if name not in self.PROVIDERS:
            raise ValueError(f"Unknown provider: {name}")
        self.current_provider = name
    
    def list_providers(self) -> List[str]:
        """List available providers."""
        return list(self.PROVIDERS.keys())
    
    def list_models(self, provider: Optional[str] = None) -> List[str]:
        """List models for a provider."""
        return self.get_provider(provider).list_models()
