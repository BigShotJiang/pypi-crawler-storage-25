"""Annotator based on Spacy NER"""

__version__ = "1.6.29"
