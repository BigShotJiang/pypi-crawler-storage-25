"""TurboQuant weight quantization for vLLM.

Online quantization: load any BF16/FP16 model, compress weights to TQ3/TQ4
at load time using WHT rotation + Lloyd-Max codebook. Weights stay compressed
in GPU memory, dequantized per forward pass.

Uses group quantization: each weight row is split into groups of group_size
(default 128), and each group gets its own L2 norm and rotation. This prevents
error accumulation across the full row dimension, matching how GPTQ/AWQ handle
weight quantization (per-group scales).

Inspired by @coffeecup2020's TQ3_1S llama.cpp implementation (dual half-block
scales) showing TurboQuant weight compression achieves near-Q4_0 quality.
"""

import logging
import os

import torch
import torch.nn as nn

from turboquant_vllm.torch_ops import PolarQuantTorch

try:
    from vllm.logger import init_logger

    logger = init_logger(__name__)
except ImportError:
    logger = logging.getLogger(__name__)

_quantizers: dict[tuple[int, int, str], PolarQuantTorch] = {}
_cuda_mod = None
_cuda_available = None
_triton_available = None
_tq_fused_gemm_fn = None
_tq_fwht_input_fn = None
_tq_cuda_dequant_gemm_fn = None


def _ensure_triton_backends() -> bool:
    """Lazy-load Triton kernel functions on first use.

    Called from ``TurboQuantWrapper.__init__``, which runs once per layer
    during model loading — before any ``forward`` is traced. Must NOT be
    called from inside ``forward`` because vLLM 0.19 compiles forward in
    fullgraph mode and rejects any call to a ``@torch._dynamo.disable``'d
    function with "Skip calling `torch.compiler.disable()`d function".

    Returns True if both Triton kernels loaded; False otherwise.
    """
    global _triton_available, _tq_fused_gemm_fn, _tq_fwht_input_fn
    if _triton_available is not None:
        return _triton_available
    try:
        from turboquant_vllm.triton_ops import tq_fused_gemm, tq_fwht_input_gemm

        _tq_fused_gemm_fn = tq_fused_gemm
        _tq_fwht_input_fn = tq_fwht_input_gemm
        _triton_available = True
        logger.info("Triton kernels available (FWHT-on-input + dequant-GEMM)")
    except (ImportError, Exception):
        _triton_available = False
        logger.info("Triton not available, using CUDA/PyTorch fallback")
    return _triton_available


def _resolve_module(root, dotted_path: str):
    """Navigate a module tree by dotted path, returning the final attribute."""
    obj = root
    for part in dotted_path.split("."):
        obj = getattr(obj, part)
    return obj


def _resolve_parent_and_attr(root, dotted_path: str):
    """Resolve a dotted path to (parent_module, attr_name)."""
    parts = dotted_path.split(".")
    parent = _resolve_module(root, ".".join(parts[:-1])) if len(parts) > 1 else root
    return parent, parts[-1]


def _get_cuda_module():
    """Lazy-load the CUDA weight dequant kernel.

    Must be called from ``TurboQuantWrapper.__init__`` (pre-compile), not
    ``forward`` (which vLLM 0.19 compiles in fullgraph mode).
    """
    global _cuda_mod, _cuda_available
    if _cuda_available is not None:
        return _cuda_mod if _cuda_available else None
    try:
        from turboquant_vllm.build import build

        _cuda_mod = build()
        if hasattr(_cuda_mod, "weight_dequant"):
            _cuda_available = True
            logger.info("CUDA weight dequant kernel loaded")
            return _cuda_mod
        else:
            _cuda_available = False
            logger.info("CUDA module missing weight_dequant, using PyTorch")
            return None
    except Exception as e:
        _cuda_available = False
        logger.warning("CUDA weight dequant not available: %s", e)
        return None


def _get_quantizer(
    group_size: int,
    bits: int,
    device: str,
    rotary_dim: "int | None" = None,
) -> PolarQuantTorch:
    """Get or create a PolarQuant quantizer for a given (group_size, bits, device, rotary_dim).

    ``rotary_dim`` selects between a full-width WHT (``None``) and a block-
    diagonal WHT (independent ``rotary_dim``-wide blocks). Used by partial-
    rotary models (MiniMax M2.5/M2.7, Qwen3.6-A3B) so the RoPE-rotated
    prefix and content-only suffix don't mix inside a quantization group.
    Values ``>= group_size`` fold to ``None`` so full-width quantizers are
    shared via cache across partial- and non-partial callers.
    """
    dev = torch.device(device)
    if dev.type == "cuda" and dev.index is None:
        dev = torch.device("cuda", torch.cuda.current_device())
    normalized_device = str(dev)
    effective_rotary_dim = rotary_dim if (rotary_dim is not None and rotary_dim < group_size) else None
    key = (group_size, bits, normalized_device, effective_rotary_dim)
    quantizer = _quantizers.get(key)
    if quantizer is None:
        quantizer = PolarQuantTorch(
            group_size,
            bits,
            seed=42,
            device=normalized_device,
            rotary_dim=effective_rotary_dim,
        )
        _quantizers[key] = quantizer

    # Defensive fallback in case a stale/mutated cache entry has mismatched device.
    if str(quantizer.device) != normalized_device:
        quantizer = PolarQuantTorch(
            group_size,
            bits,
            seed=42,
            device=normalized_device,
            rotary_dim=effective_rotary_dim,
        )
        _quantizers[key] = quantizer

    return quantizer


def _tq_cuda_dequant_gemm_impl(
    x: torch.Tensor,
    packed_weight: torch.Tensor,
    norms: torch.Tensor,
    signs1: torch.Tensor,
    signs2: torch.Tensor,
    centroids: torch.Tensor,
    bias: torch.Tensor | None,
    group_size: int,
    bits: int,
    out_features: int,
    in_features: int,
    block_size: int,
) -> torch.Tensor:
    """CUDA fallback path wrapped for torch.compile compatibility."""
    w_deq = torch.empty(out_features, in_features, dtype=x.dtype, device=x.device)
    _cuda_mod.weight_dequant(
        packed_weight,
        norms,
        signs1,
        signs2,
        centroids,
        w_deq,
        group_size,
        bits,
        out_features,
        in_features,
        block_size,
    )
    output = torch.matmul(x, w_deq.t())
    if bias is not None:
        output = output + bias
    return output


try:

    @torch.library.custom_op("turboquant::tq_cuda_dequant_gemm", mutates_args=(), device_types=("cuda",))
    def _tq_cuda_dequant_gemm_op(
        x: torch.Tensor,
        packed_weight: torch.Tensor,
        norms: torch.Tensor,
        signs1: torch.Tensor,
        signs2: torch.Tensor,
        centroids: torch.Tensor,
        bias: torch.Tensor | None,
        group_size: int,
        bits: int,
        out_features: int,
        in_features: int,
        block_size: int,
    ) -> torch.Tensor:
        return _tq_cuda_dequant_gemm_impl(
            x,
            packed_weight,
            norms,
            signs1,
            signs2,
            centroids,
            bias,
            group_size,
            bits,
            out_features,
            in_features,
            block_size,
        )

    @_tq_cuda_dequant_gemm_op.register_fake
    def _(
        x,
        packed_weight,
        norms,
        signs1,
        signs2,
        centroids,
        bias,
        group_size,
        bits,
        out_features,
        in_features,
        block_size,
    ):
        del packed_weight, norms, signs1, signs2, centroids, bias, group_size, bits, in_features, block_size
        return x.new_empty((*x.shape[:-1], out_features))

    _tq_cuda_dequant_gemm_fn = _tq_cuda_dequant_gemm_op
except Exception:
    _tq_cuda_dequant_gemm_fn = None


_PARTIAL_ROTARY_ALIASES = (
    "partial_rotary_factor",
    "rotary_pct",
    "rotary_emb_fraction",
)


def _derive_rotary_dim(model_config) -> "int | None":
    """Extract a block-diag rotary_dim from a vLLM ModelConfig, or None.

    Returns the largest power of two ≤ ``head_dim * partial_rotary_factor``
    that divides ``head_dim``. Returns ``None`` for non-partial-rotary
    models. Examples: MiniMax M2.7 (128, 0.5) → 64; Qwen3.6-A3B (256, 0.25)
    → 64; Qwen3-30B (128, 1.0) → None.
    """
    if model_config is None:
        return None
    head_dim = None
    get_head_size = getattr(model_config, "get_head_size", None)
    if callable(get_head_size):
        try:
            head_dim = int(get_head_size())
        except (AttributeError, TypeError, ValueError):
            head_dim = None
    if head_dim is None:
        hf = getattr(model_config, "hf_text_config", None) or getattr(model_config, "hf_config", None)
        head_dim = getattr(hf, "head_dim", None) if hf else None
    if not head_dim:
        return None

    cfg = getattr(model_config, "hf_text_config", None) or getattr(model_config, "hf_config", None) or model_config
    factor = None
    for name in _PARTIAL_ROTARY_ALIASES:
        factor = getattr(cfg, name, None)
        if factor is not None:
            break
    if factor is None:
        rope_params = getattr(cfg, "rope_parameters", None)
        if isinstance(rope_params, dict):
            for name in _PARTIAL_ROTARY_ALIASES:
                if name in rope_params:
                    factor = rope_params[name]
                    break
    if factor is None or factor >= 1.0 or factor <= 0.0:
        return None
    rd_target = int(head_dim * factor)
    if rd_target <= 0 or rd_target >= head_dim:
        return None
    rd_p2 = 1 << (rd_target.bit_length() - 1)
    if rd_p2 <= 0 or head_dim % rd_p2 != 0:
        return None
    return rd_p2


def pack_indices(indices: torch.Tensor, bits: int) -> torch.Tensor:
    """Pack quantization indices into uint8.

    4-bit: 2 per byte (nibble packing).
    3-bit: 8 indices per 3 bytes (24 bits). For group_size=128: 48 bytes per group.
    2-bit: 4 per byte.
    """
    if bits == 4:
        assert indices.shape[-1] % 2 == 0
        flat = indices.reshape(-1, indices.shape[-1])
        lo = flat[:, 0::2].to(torch.uint8)
        hi = flat[:, 1::2].to(torch.uint8)
        return (lo | (hi << 4)).reshape(indices.shape[0], -1)
    elif bits == 3:
        # Pack 8 3-bit values into 3 bytes (24 bits).
        # Layout per 3-byte group:
        #   byte0 = idx0 | (idx1 << 3) | (idx2[0:2] << 6)
        #   byte1 = idx2[2] | (idx3 << 1) | (idx4 << 4) | (idx5[0:1] << 7)
        #   byte2 = idx5[1:3] | (idx6 << 2) | (idx7 << 5)
        n_rows, n_cols = indices.shape[0], indices.shape[-1]
        flat = indices.reshape(n_rows, -1).to(torch.uint8)
        # Pad to multiple of 8
        pad = (8 - n_cols % 8) % 8
        if pad > 0:
            flat = torch.nn.functional.pad(flat, (0, pad))
        n_packed_cols = flat.shape[1] // 8 * 3
        packed = torch.zeros(n_rows, n_packed_cols, dtype=torch.uint8, device=indices.device)
        for i in range(flat.shape[1] // 8):
            v = flat[:, i * 8 : (i + 1) * 8]  # (n_rows, 8) uint8, values 0-7
            b0 = v[:, 0] | (v[:, 1] << 3) | ((v[:, 2] & 0x3) << 6)
            b1 = (v[:, 2] >> 2) | (v[:, 3] << 1) | (v[:, 4] << 4) | ((v[:, 5] & 0x1) << 7)
            b2 = (v[:, 5] >> 1) | (v[:, 6] << 2) | (v[:, 7] << 5)
            packed[:, i * 3] = b0
            packed[:, i * 3 + 1] = b1
            packed[:, i * 3 + 2] = b2
        return packed
    elif bits == 2:
        assert indices.shape[-1] % 4 == 0
        flat = indices.reshape(-1, indices.shape[-1])
        shifts = torch.tensor([0, 2, 4, 6], device=indices.device, dtype=torch.uint8)
        parts = torch.stack([flat[:, i::4].to(torch.uint8) for i in range(4)], dim=-1)
        return (parts << shifts).sum(dim=-1).to(torch.uint8).reshape(indices.shape[0], -1)
    else:
        return indices.to(torch.uint8)


def packed_group_bytes(bits: int, group_size: int) -> int:
    """Return the number of packed bytes per group for a given bit-width."""
    if bits == 4:
        return group_size // 2
    elif bits == 3:
        return ((group_size + 7) // 8) * 3
    elif bits == 2:
        return group_size // 4
    return group_size


def padded_size(dim: int, group_size: int) -> tuple[int, int]:
    """Return ``(padded_dim, n_groups)`` for group quantization."""
    padded = ((dim + group_size - 1) // group_size) * group_size
    return padded, padded // group_size


def unpack_indices(packed: torch.Tensor, bits: int, dim: int) -> torch.Tensor:
    """Unpack uint8 packed indices back to int64."""
    if bits == 4:
        flat = packed.reshape(-1, packed.shape[-1])
        lo = (flat & 0x0F).to(torch.int64)
        hi = ((flat >> 4) & 0x0F).to(torch.int64)
        unpacked = torch.zeros(flat.shape[0], flat.shape[1] * 2, dtype=torch.int64, device=packed.device)
        unpacked[:, 0::2] = lo
        unpacked[:, 1::2] = hi
        return unpacked.reshape(packed.shape[0], -1)[:, :dim]
    elif bits == 3:
        # Unpack 3 bytes → 8 3-bit values
        flat = packed.reshape(-1, packed.shape[-1])
        n_rows = flat.shape[0]
        n_groups_of_3 = flat.shape[1] // 3
        unpacked = torch.zeros(n_rows, n_groups_of_3 * 8, dtype=torch.int64, device=packed.device)
        for i in range(n_groups_of_3):
            b0 = flat[:, i * 3].to(torch.int64)
            b1 = flat[:, i * 3 + 1].to(torch.int64)
            b2 = flat[:, i * 3 + 2].to(torch.int64)
            unpacked[:, i * 8 + 0] = b0 & 0x7
            unpacked[:, i * 8 + 1] = (b0 >> 3) & 0x7
            unpacked[:, i * 8 + 2] = ((b0 >> 6) | (b1 << 2)) & 0x7
            unpacked[:, i * 8 + 3] = (b1 >> 1) & 0x7
            unpacked[:, i * 8 + 4] = (b1 >> 4) & 0x7
            unpacked[:, i * 8 + 5] = ((b1 >> 7) | (b2 << 1)) & 0x7
            unpacked[:, i * 8 + 6] = (b2 >> 2) & 0x7
            unpacked[:, i * 8 + 7] = (b2 >> 5) & 0x7
        return unpacked[:, :dim]
    elif bits == 2:
        flat = packed.reshape(-1, packed.shape[-1])
        unpacked = torch.zeros(flat.shape[0], flat.shape[1] * 4, dtype=torch.int64, device=packed.device)
        for i in range(4):
            unpacked[:, i::4] = ((flat >> (i * 2)) & 0x03).to(torch.int64)
        return unpacked.reshape(packed.shape[0], -1)[:, :dim]
    else:
        return packed.to(torch.int64)


class TurboQuantWrapper(nn.Module):
    """Drop-in replacement for nn.Linear with TQ group-quantized weights.

    Each weight row is split into groups of group_size. Each group is
    independently normalized, rotated (WHT), and quantized against the
    Lloyd-Max codebook. This matches how GPTQ/AWQ use per-group scales.
    """

    # When set, forward uses PolarQuantTorch dequant-then-matmul — the
    # Triton and CUDA kernels hardcode a full-width WHT and would mismatch
    # against block-diag-compressed weights.
    rotary_dim: "int | None" = None

    def __init__(
        self,
        original: nn.Linear,
        bits: int = 3,
        group_size: int = 128,
        rotation: torch.Tensor | None = None,
        rotary_dim: "int | None" = None,
    ):
        super().__init__()
        self.bits = bits
        self.group_size = group_size
        self.in_features = original.in_features
        self.out_features = original.out_features
        self._has_learned_rotation = rotation is not None
        self.rotary_dim = rotary_dim

        # vLLM's Linear subclasses return either `output` or a
        # `(output, output_bias)` tuple depending on the `return_bias`
        # flag. Downstream model code (e.g. Qwen2/Gemma4 qkv projection
        # handling) does `qkv, _ = self.qkv_proj(x)`, which crashes
        # under vLLM 0.19 fullgraph dynamo as "Can't unpack a tensor
        # of 2048 rows into a tuple of 2 elements" if we return only
        # a tensor. Mirror the original's return_bias flag — default
        # to False when wrapping a plain nn.Linear (returns a plain
        # tensor) vs True when wrapping a vLLM Linear subclass.
        self.return_bias = getattr(original, "return_bias", False)

        # Probe Triton + CUDA backends during construction, NOT in forward().
        # vLLM 0.19 AOT-compiles forward() in fullgraph mode and can't trace
        # logger calls or @torch._dynamo.disable helpers. Doing the probes
        # here populates the module globals before any forward is traced.
        _ensure_triton_backends()
        _get_cuda_module()

        # Cache the PolarQuant rotation tensors (signs1, signs2, centroids)
        # as buffers on the wrapper. forward() will read them directly as
        # tensor attributes rather than calling _get_quantizer() — that
        # helper does a dict lookup and Python object construction that
        # vLLM 0.19's fullgraph dynamo compile cannot trace.
        _pq = _get_quantizer(
            group_size,
            bits,
            str(original.weight.device),
            rotary_dim=rotary_dim,
        )
        self.register_buffer("tq_signs1", _pq.signs1)
        self.register_buffer("tq_signs2", _pq.signs2)
        self.register_buffer("tq_centroids", _pq.centroids)

        # Eagerly populate the module-level rotation matrix cache so the
        # first forward (which may be the warmup pass before CUDA graph
        # capture) does not hit a cache miss and allocate / run a
        # butterfly WHT inside the custom_op body at capture time. The
        # rotation matrix is a pure function of (signs1, signs2,
        # group_size) and fits in 64 KB for group_size=128, so building
        # it once per wrapper instance at construction time is cheap and
        # removes an implicit "warmup must run before capture" coupling.
        # See turboquant_vllm.triton_ops._rotation_matrix_cache comment.
        if _triton_available:
            from turboquant_vllm.triton_ops import _get_cached_rotation_matrix

            _get_cached_rotation_matrix(self.tq_signs1, self.tq_signs2, group_size)

        weight = original.weight.data  # (out_features, in_features)
        # Flatten to 2D when weight has extra leading dimensions (e.g. vLLM
        # parallel linears or MoE expert tensors passed directly).
        if weight.ndim > 2:
            weight = weight.reshape(-1, weight.shape[-1])
            self.in_features = weight.shape[-1]
            self.out_features = weight.shape[0]
        out_dim, in_dim = weight.shape

        self.padded_in, self.n_groups = padded_size(in_dim, group_size)

        if self.padded_in > in_dim:
            padded = torch.zeros(out_dim, self.padded_in, dtype=weight.dtype, device=weight.device)
            padded[:, :in_dim] = weight
        else:
            padded = weight

        grouped = padded.reshape(-1, group_size)

        if rotation is not None:
            # Use learned rotation (SpinQuant-style)
            from turboquant_vllm.learned_rotation import quantize_with_learned_rotation

            packed, norms, _ = quantize_with_learned_rotation(weight, rotation, bits=bits, group_size=group_size)
            self.register_buffer("rotation", rotation)
        else:
            # Use fixed WHT rotation (default) with norm correction. Must
            # match the rotary_dim the forward path will dequant with —
            # both paths share the cached quantizer via _get_quantizer.
            quantizer = _get_quantizer(
                group_size,
                bits,
                str(weight.device),
                rotary_dim=rotary_dim,
            )
            indices, norms_raw = quantizer.quantize(grouped, norm_correction=True)
            packed = pack_indices(indices, bits)
            norms = norms_raw.reshape(out_dim, self.n_groups)

        original_bytes = weight.numel() * weight.element_size()
        norm_bytes = norms.numel() * norms.element_size()
        compressed_bytes = packed.numel() + norm_bytes
        self._ratio = original_bytes / compressed_bytes

        self.register_buffer("packed_weight", packed)
        self.register_buffer("norms", norms)

        if original.bias is not None:
            bias_data = original.bias.data
            if bias_data.ndim > 1:
                bias_data = bias_data.reshape(-1)
            if bias_data.numel() != self.out_features:
                msg = (
                    "Bias size does not match flattened out_features: "
                    f"flattened_bias.numel()={bias_data.numel()} vs out_features={self.out_features}"
                )
                raise ValueError(msg)
            self.bias = nn.Parameter(bias_data.clone())
        else:
            self.bias = None

        logger.debug(
            "TQ%d-g%d compressed %dx%d (%.1fx)",
            bits,
            group_size,
            out_dim,
            in_dim,
            self._ratio,
        )

    @classmethod
    def from_packed(
        cls,
        packed_weight: torch.Tensor,
        norms: torch.Tensor,
        in_features: int,
        out_features: int,
        bits: int = 3,
        group_size: int = 128,
        bias: torch.Tensor | None = None,
    ):
        """Create a TurboQuantWrapper from pre-packed data (native TQ3 checkpoint).

        Skips compression — the packed indices and norms are used directly.
        This enables loading native TQ3 checkpoints without decompressing to FP16.
        """
        wrapper = object.__new__(cls)
        nn.Module.__init__(wrapper)
        wrapper.bits = bits
        wrapper.group_size = group_size
        wrapper.in_features = in_features
        wrapper.out_features = out_features
        wrapper._has_learned_rotation = False
        wrapper.padded_in, wrapper.n_groups = padded_size(in_features, group_size)

        wrapper.register_buffer("packed_weight", packed_weight)
        wrapper.register_buffer("norms", norms)
        wrapper.bias = nn.Parameter(bias) if bias is not None else None

        # `from_packed` is invoked by `load_tq3_model`, which builds an HF
        # transformers model — not a vLLM Linear subclass. Plain HF Linear
        # returns a tensor, not a (tensor, bias) tuple, so return_bias=False.
        wrapper.return_bias = False

        # Mirror __init__: cache PolarQuant rotation tensors as buffers so
        # forward() can read them directly without dict lookup. Centroids
        # and signs are deterministic from (group_size, bits, device).
        _ensure_triton_backends()
        _get_cuda_module()
        _pq = _get_quantizer(group_size, bits, str(packed_weight.device))
        wrapper.register_buffer("tq_signs1", _pq.signs1)
        wrapper.register_buffer("tq_signs2", _pq.signs2)
        wrapper.register_buffer("tq_centroids", _pq.centroids)

        original_bytes = out_features * in_features * 2  # FP16 equivalent
        compressed_bytes = packed_weight.numel() + norms.numel() * norms.element_size()
        wrapper._ratio = original_bytes / max(compressed_bytes, 1)

        return wrapper

    def forward(self, x: torch.Tensor):
        # Trivial dispatch that dynamo can specialize on x.is_cuda when
        # vLLM 0.19 fullgraph-compiles the CUDA forward path. The CPU
        # branch is still physically present for pytest / dev machines
        # without a CUDA extension.
        output = self._forward_gpu(x) if x.is_cuda else self._forward_cpu(x)
        # Match vLLM Linear's return_bias contract. See __init__.
        if self.return_bias:
            return output, None
        return output

    def _can_use_full_wht_kernels(self) -> bool:
        # Triton kernels assume full-width WHT on input. CUDA kernels accept a
        # block_size parameter and handle both full-width and block-diagonal
        # rotations, so they aren't gated by this — see _forward_gpu.
        return self.rotary_dim is None

    def _forward_gpu(self, x: torch.Tensor) -> torch.Tensor:
        """Fullgraph-dynamo-clean forward for GPU (Triton or CUDA backends).

        Must NOT contain logger calls, calls to @torch._dynamo.disable'd
        helpers, or method calls on non-tensor Python objects that do dict
        lookups / string conversions. vLLM 0.19 AOT-compiles this path.
        """
        if _triton_available and x.is_cuda and self._can_use_full_wht_kernels():
            # Pad input if in_features was not a multiple of group_size
            if x.shape[-1] != self.padded_in:
                x = torch.nn.functional.pad(x, (0, self.padded_in - x.shape[-1]))
            args = (x, self.packed_weight, self.norms, self.tq_signs1, self.tq_signs2, self.tq_centroids)
            kwargs = dict(group_size=self.group_size, bits=self.bits, bias=self.bias)

            # FWHT-on-input wins for large output dims (saves N inverse rotations).
            # Dequant-GEMM wins for small layers (lower fixed overhead).
            # Crossover ~4K output features on H100.
            primary = _tq_fwht_input_fn if self.out_features >= 4096 else _tq_fused_gemm_fn
            fallback = _tq_fused_gemm_fn if self.out_features >= 4096 else _tq_fwht_input_fn
            try:
                return primary(*args, **kwargs)
            except (ValueError, RuntimeError):
                return fallback(*args, **kwargs)

        # CUDA C++ extension path — handles both full-width and block-diagonal
        # WHT via the block_size parameter, so partial-rotary q/k_proj layers
        # use this path instead of falling through to _forward_cpu.
        if _cuda_mod is not None and _tq_cuda_dequant_gemm_fn is not None:
            block_size = self.rotary_dim if self.rotary_dim is not None else self.group_size
            return _tq_cuda_dequant_gemm_fn(
                x,
                self.packed_weight,
                self.norms,
                self.tq_signs1,
                self.tq_signs2,
                self.tq_centroids,
                self.bias,
                self.group_size,
                self.bits,
                self.out_features,
                self.in_features,
                block_size,
            )

        # PolarQuantTorch fallback — honors self.rotary_dim via _apply_wht.
        return self._forward_cpu(x)

    def _forward_cpu(self, x: torch.Tensor) -> torch.Tensor:
        """PolarQuant reference dequant + matmul. Device-agnostic.

        Runs in eager mode only — the butterfly has a data-dependent while
        loop that vLLM 0.19 fullgraph dynamo can't trace.
        """
        indices = unpack_indices(self.packed_weight, self.bits, self.group_size)
        norms_flat = self.norms.reshape(-1)
        quantizer = _get_quantizer(
            self.group_size,
            self.bits,
            str(x.device),
            rotary_dim=self.rotary_dim,
        )
        w_groups = quantizer.dequantize(indices, norms_flat)
        w_deq = w_groups.reshape(self.out_features, self.padded_in)[:, : self.in_features]
        w_deq = w_deq.to(x.dtype)
        output = torch.matmul(x, w_deq.t())
        if self.bias is not None:
            output = output + self.bias
        return output

    def extra_repr(self) -> str:
        return (
            f"in_features={self.in_features}, out_features={self.out_features}, "
            f"bits={self.bits}, group_size={self.group_size}, bias={self.bias is not None}"
        )


# Layers to never quantize.
# - `lm_head`, `embed`, `norm`, `head`: precision-sensitive.
# - `conv1d`: Qwen3-Next / Qwen3.5 Gated DeltaNet stores a Mamba-style causal
#   conv projection as `ColumnParallelLinear`, then calls `causal_conv1d_*`
#   kernels that read `self.conv1d.weight.view(...)` directly. `TurboQuantWrapper`
#   has no `.weight`, so the direct-read path crashes. The layer is tiny
#   (kernel_size × conv_dim), so skipping costs negligible memory.
# - DeepSeek V4 MTP/HyperConnection and CSA/HCA tensors are structurally
#   special control-path weights, so they stay full precision by default.
_SKIP_PATTERNS = (
    "lm_head",
    "embed",
    "norm",
    "head",
    "conv1d",
    "mtp",
    "compressor",
    "indexer",
    "ape",
    "attn_sink",
    "hc_",
)

# Layers that benefit from higher precision (attention output + MLP output)
_SENSITIVE_PATTERNS = ("o_proj", "down_proj")


def select_bits(
    tensor_name: str,
    default_bits: int,
    sensitive_bits: int | None = None,
    sensitive_patterns: tuple[str, ...] = _SENSITIVE_PATTERNS,
) -> int:
    """Return bits for this tensor. Sensitive layers get higher precision."""
    if sensitive_bits is None:
        return default_bits
    if any(p in tensor_name for p in sensitive_patterns):
        return sensitive_bits
    return default_bits


class Compressed3D:
    """Stores a compressed 3D expert weight tensor (num_experts, out_dim, in_dim).

    Weights are group-quantized and packed into uint8. Decompression restores
    the original shape and dtype. Used with forward hooks to decompress
    one layer at a time during inference.
    """

    def __init__(self, data: torch.Tensor, bits: int, group_size: int):
        n_experts, out_dim, in_dim = data.shape
        self.shape = data.shape
        self.dtype = data.dtype
        self.device = data.device
        self.bits = bits
        self.group_size = group_size
        self.in_dim = in_dim
        self.padded_in, self.n_groups = padded_size(in_dim, group_size)

        flat = data.reshape(-1, in_dim)
        if self.padded_in > in_dim:
            padded = torch.zeros(flat.shape[0], self.padded_in, dtype=flat.dtype, device=flat.device)
            padded[:, :in_dim] = flat
        else:
            padded = flat

        grouped = padded.reshape(-1, group_size)
        quantizer = _get_quantizer(group_size, bits, str(data.device))
        indices, norms = quantizer.quantize(grouped)

        self.packed = pack_indices(indices, bits)
        self.norms = norms.reshape(n_experts * out_dim, self.n_groups)

        self.original_bytes = data.numel() * data.element_size()
        self.compressed_bytes = self.packed.numel() + self.norms.numel() * 4

    @classmethod
    def from_packed(
        cls,
        packed: torch.Tensor,
        norms: torch.Tensor,
        shape: tuple[int, int, int],
        dtype: torch.dtype,
        bits: int = 3,
        group_size: int = 128,
    ):
        """Create a Compressed3D from pre-packed data (native TQ3 checkpoint).

        Skips compression — the packed indices and norms are used directly.
        """
        # Why: Compressed3D is stored via setattr (not register_buffer), so
        # nn.Module._apply never walks its internal tensors. A meta leak here
        # stays invisible until decompress asserts out.device == packed.device.
        if packed.is_meta or norms.is_meta:
            raise RuntimeError(
                f"Compressed3D.from_packed got meta tensor "
                f"(packed.is_meta={packed.is_meta}, norms.is_meta={norms.is_meta}); "
                f"native MoE regroup did not populate weights."
            )
        obj = object.__new__(cls)
        n_experts, out_dim, in_dim = shape
        padded_in, n_groups = padded_size(in_dim, group_size)
        expected_packed_shape = (n_experts * out_dim * n_groups, packed_group_bytes(bits, group_size))
        expected_norms_shape = (n_experts * out_dim, n_groups)
        if packed.shape != expected_packed_shape:
            raise ValueError(
                f"Compressed3D.from_packed expected packed shape {expected_packed_shape} "
                f"for {shape}, got {tuple(packed.shape)}"
            )
        if norms.shape != expected_norms_shape:
            raise ValueError(
                f"Compressed3D.from_packed expected norms shape {expected_norms_shape} "
                f"for {shape}, got {tuple(norms.shape)}"
            )
        if packed.device != norms.device:
            raise ValueError(
                f"Compressed3D.from_packed expected packed/norms on same device, got {packed.device} and {norms.device}"
            )
        obj.shape = shape
        obj.dtype = dtype
        obj.device = packed.device
        obj.bits = bits
        obj.group_size = group_size
        obj.in_dim = in_dim
        obj.padded_in, obj.n_groups = padded_in, n_groups
        obj.packed = packed
        obj.norms = norms
        obj.original_bytes = n_experts * out_dim * in_dim * 2  # FP16
        obj.compressed_bytes = packed.numel() + norms.numel() * 4
        return obj

    def decompress_into(self, out: torch.Tensor, fp32_scratch: torch.Tensor | None = None) -> None:
        """Write decompressed weights into a pre-allocated ``out`` buffer.

        ``out`` must have ``shape == self.shape`` and ``dtype == self.dtype``,
        and must be on the same device as ``self.packed``. Used by the
        TurboQuant MoE quant method's ``apply()`` hot path to avoid
        per-forward bf16 allocation. The CUDA kernel writes bf16/fp16 directly,
        so ``fp32_scratch`` is unused — kept as a no-op kwarg for API
        compatibility with callers that still pass it.
        """
        del fp32_scratch  # unused — kept for API back-compat
        assert out.shape == self.shape, f"decompress_into expected shape {self.shape}, got {tuple(out.shape)}"
        assert out.dtype == self.dtype, f"decompress_into expected dtype {self.dtype}, got {out.dtype}"
        assert out.device == self.packed.device, (
            f"decompress_into expected device {self.packed.device}, got {out.device}"
        )

        cuda_mod = _get_cuda_module()
        if cuda_mod is None or not self.packed.is_cuda:
            out.copy_(self.decompress())
            return

        n_experts, out_dim, in_dim = self.shape
        quantizer = _get_quantizer(self.group_size, self.bits, str(self.packed.device))
        cuda_mod.weight_dequant_3d(
            self.packed,
            self.norms,
            quantizer.signs1,
            quantizer.signs2,
            quantizer.centroids,
            out,
            self.group_size,
            self.bits,
            n_experts,
            out_dim,
            in_dim,
            self.group_size,  # block_size — full-width WHT for MoE experts
        )

    def decompress_experts_into(
        self,
        out: torch.Tensor,
        active_experts: torch.Tensor,
        fp32_scratch: torch.Tensor | None = None,
    ) -> None:
        """Decompress only ``active_experts`` into ``out``.

        Output at listed indices is bit-identical to the full decompress;
        other slots are left untouched (the downstream ``fused_moe``
        routes via ``topk_ids`` and doesn't read them).

        ``active_experts`` must be a 1-D int32 GPU tensor. ``fp32_scratch``
        is unused on the CUDA sparse path (kernel writes bf16/fp16/fp32
        directly) and kept only for the legacy scalar-loop fallback when
        the sparse kernel isn't built.
        """
        assert out.shape == self.shape
        assert out.dtype == self.dtype
        assert out.device == self.packed.device

        cuda_mod = _get_cuda_module()
        if cuda_mod is None or not self.packed.is_cuda:
            out.copy_(self.decompress())
            return

        if active_experts.numel() == 0:
            return

        n_experts, out_dim, in_dim = self.shape

        # At prefill, topk_ids.flatten() scales with batch*top_k and quickly
        # exceeds n_experts — the sparse-kernel grid ((N*out_dim, n_groups))
        # would overflow CUDA's grid.x limit (~2.1B blocks) and sparse work
        # isn't a win when we're covering every expert anyway. Full dequant
        # is strictly faster + safer in that regime.
        if active_experts.numel() >= n_experts:
            self.decompress_into(out, fp32_scratch=fp32_scratch)
            return

        quantizer = _get_quantizer(self.group_size, self.bits, str(self.packed.device))

        sparse_fn = getattr(cuda_mod, "weight_dequant_sparse_3d", None)
        if sparse_fn is not None:
            # Kernel writes the output dtype directly — no intermediate
            # scratch, no host sync, CUDA-graph capturable at fixed top_k.
            assert active_experts.dtype == torch.int32, "active_experts must be int32 (cast once in the caller)"
            sparse_fn(
                self.packed,
                self.norms,
                quantizer.signs1,
                quantizer.signs2,
                quantizer.centroids,
                active_experts,
                out,
                self.group_size,
                self.bits,
                n_experts,
                out_dim,
                in_dim,
                self.group_size,  # block_size — full-width WHT for MoE experts
            )
            return

        # Legacy fallback (wheel built without sparse kernel): scalar loop
        # via the full 3D kernel at n_experts=1. Breaks CUDA graphs; requires
        # enforce_eager=True on vLLM.
        groups_per_expert = out_dim * self.n_groups
        for e in torch.unique(active_experts).tolist():
            if e < 0 or e >= n_experts:
                continue
            expert_packed = self.packed[e * groups_per_expert : (e + 1) * groups_per_expert]
            expert_norms = self.norms[e * out_dim : (e + 1) * out_dim]
            cuda_mod.weight_dequant_3d(
                expert_packed,
                expert_norms,
                quantizer.signs1,
                quantizer.signs2,
                quantizer.centroids,
                out[e : e + 1],
                self.group_size,
                self.bits,
                1,
                out_dim,
                in_dim,
                self.group_size,  # block_size — full-width WHT for MoE experts
            )

    def decompress(self, buf: torch.Tensor | None = None) -> torch.Tensor:
        """Decompress back to (num_experts, out_dim, in_dim) at original dtype.

        Uses CUDA kernel when available (fast), falls back to chunked PyTorch
        (8 experts at a time) to limit GPU memory.
        """
        cuda_mod = _get_cuda_module()
        n_experts, out_dim, in_dim = self.shape

        if cuda_mod is not None and self.packed.is_cuda:
            if buf is not None and buf.shape == (n_experts, out_dim, in_dim) and buf.dtype == self.dtype:
                output = buf
            else:
                output = torch.empty(n_experts, out_dim, in_dim, dtype=self.dtype, device=self.packed.device)
            quantizer = _get_quantizer(self.group_size, self.bits, str(self.packed.device))
            cuda_mod.weight_dequant_3d(
                self.packed,
                self.norms,
                quantizer.signs1,
                quantizer.signs2,
                quantizer.centroids,
                output,
                self.group_size,
                self.bits,
                n_experts,
                out_dim,
                in_dim,
                self.group_size,  # block_size — full-width WHT for MoE experts
            )
            return output

        # Fallback: chunked PyTorch (8 experts at a time)
        output_dtype = self.dtype
        if buf is not None and buf.shape == (n_experts, out_dim, in_dim):
            output = buf
        else:
            output = torch.empty(n_experts, out_dim, in_dim, dtype=output_dtype, device=self.packed.device)

        quantizer = _get_quantizer(self.group_size, self.bits, str(self.packed.device))
        chunk_experts = max(1, min(8, n_experts))
        groups_per_expert = out_dim * self.n_groups

        for start in range(0, n_experts, chunk_experts):
            end = min(start + chunk_experts, n_experts)

            start_group = start * groups_per_expert
            end_group = end * groups_per_expert
            chunk_packed = self.packed[start_group:end_group]

            start_row = start * out_dim
            end_row = end * out_dim
            chunk_norms = self.norms[start_row:end_row]

            chunk_idx = unpack_indices(chunk_packed, self.bits, self.group_size)
            chunk_groups = quantizer.dequantize(chunk_idx, chunk_norms.reshape(-1))
            del chunk_idx

            chunk_result = chunk_groups.reshape(-1, self.padded_in)[:, : self.in_dim]
            output[start:end] = chunk_result.reshape(end - start, out_dim, in_dim).to(output_dtype)
            del chunk_groups, chunk_result

        return output

    @property
    def ratio(self) -> float:
        return self.original_bytes / self.compressed_bytes if self.compressed_bytes > 0 else 0


def _compress_3d_param(module: nn.Module, param_name: str, bits: int, group_size: int) -> tuple[int, int]:
    """Compress a 3D parameter in-place with real memory savings.

    Stores the :class:`Compressed3D` as ``module._tq_{param_name}`` and
    resizes the original parameter's ``.data`` to an empty tensor of the
    same device / dtype. The FusedMoE path (Phase 2A in
    :func:`_replace_linear_layers`) subsequently swaps the layer's
    ``quant_method`` via ``FusedMoE._replace_quant_method`` so the
    compressed tensor is read from ``_tq_{param_name}`` inside
    ``TurboQuantFusedMoEMethod.apply``.

    Returns ``(original_bytes, compressed_bytes)``.
    """
    param = getattr(module, param_name)
    compressed = Compressed3D(param.data, bits, group_size)

    setattr(module, f"_tq_{param_name}", compressed)
    param.data = torch.empty(0, device=param.device, dtype=param.dtype)

    return compressed.original_bytes, compressed.compressed_bytes


def _register_moe_hooks(module: nn.Module, param_names: list[str], pool_buffers: bool = True):
    """Register pre/post forward hooks that decompress expert weights on demand.

    Args:
        pool_buffers: If True, keep decompression buffers allocated between
            forward passes for reuse (faster, uses more memory). If False,
            free buffers after each forward (slower, saves ~40 GB for large MoE).
            Use False on memory-constrained GPUs (e.g., L40S 48GB).
    """
    comp_names = [f"_tq_{pname}" for pname in param_names]
    buf_names = [f"_tq_buf_{pname}" for pname in param_names]

    def pre_hook(mod, args):
        for pname, comp_name, buf_name in zip(param_names, comp_names, buf_names):
            compressed = getattr(mod, comp_name, None)
            if compressed is None:
                continue
            buf = getattr(mod, buf_name, None) if pool_buffers else None
            decompressed = compressed.decompress(buf=buf)
            if pool_buffers and (buf is None or buf.data_ptr() != decompressed.data_ptr()):
                setattr(mod, buf_name, decompressed)
            getattr(mod, pname).data = decompressed

    def post_hook(mod, args, output):
        for pname, comp_name, buf_name in zip(param_names, comp_names, buf_names):
            compressed = getattr(mod, comp_name, None)
            if compressed is not None:
                getattr(mod, pname).data = torch.empty(0, device=compressed.device, dtype=compressed.dtype)
                if not pool_buffers:
                    # Free the decompression buffer to save GPU memory
                    if hasattr(mod, buf_name):
                        delattr(mod, buf_name)
        return output

    module.register_forward_pre_hook(pre_hook)
    module.register_forward_hook(post_hook)


def _select_bits(param: torch.Tensor, default_bits: int, kurtosis_aware: bool = False) -> int:
    """Select quantization bits based on tensor statistics.

    Heavy-tailed distributions (high kurtosis, e.g. shared MoE experts)
    need more bits. Near-Gaussian distributions (low kurtosis, e.g. routed
    MoE experts) tolerate aggressive compression.

    Based on APEX finding: shared expert kurtosis ~13.1, routed ~3.4.
    """
    if not kurtosis_aware:
        return default_bits

    flat = param.float().reshape(-1)
    mean = flat.mean()
    std = flat.std()
    if std < 1e-8:
        return default_bits
    normalized = (flat - mean) / std
    kurt = (normalized**4).mean().item()  # excess kurtosis + 3

    if kurt > 8:
        # Heavy-tailed (shared experts, attention projections): more bits
        return min(default_bits + 2, 8)
    elif kurt > 5:
        return min(default_bits + 1, 8)
    elif kurt < 3.5:
        # Near-Gaussian (routed experts): fewer bits OK
        return max(default_bits - 1, 2)
    return default_bits


def _find_router_weights(model: nn.Module) -> dict[str, torch.Tensor]:
    """Find MoE router/gate weights for expert importance ranking.

    Returns: {module_path: gate_weight (num_experts, hidden_size)}
    """
    gates = {}
    for name, module in model.named_modules():
        # vLLM MoE blocks have a 'gate' attribute (ReplicatedLinear)
        gate = getattr(module, "gate", None)
        if gate is not None and hasattr(gate, "weight"):
            w = gate.weight.data
            if w.dim() == 2:  # (num_experts, hidden_size)
                gates[name] = w
    return gates


def _rank_experts_by_importance(gate_weight: torch.Tensor) -> torch.Tensor:
    """Rank experts by router weight L2 norm (proxy for importance).

    Higher norm = more likely to be selected = more important.
    Returns sorted indices (most important first).
    """
    norms = gate_weight.float().norm(dim=1)  # (num_experts,)
    return norms.argsort(descending=True)


def _prune_expert_weights(
    param: torch.Tensor,
    keep_mask: torch.Tensor,
) -> None:
    """Zero out pruned expert rows in-place in a 3D expert weight tensor.

    Args:
        param: (num_experts, out_dim, in_dim) expert weight tensor, modified in-place
        keep_mask: (num_experts,) bool mask — True for experts to keep
    """
    param[~keep_mask] = 0.0


def _replace_linear_layers(
    model: nn.Module,
    bits: int,
    group_size: int = 128,
    min_size: int = 1024,
    kurtosis_aware: bool = False,
    prune_experts: float = 0.0,
    routed_expert_bits: int | None = None,
    per_module_bits: dict[str, int] | None = None,
    learned_rotations: dict[str, torch.Tensor] | None = None,
    rotary_dim: "int | None" = None,
):
    """Compress model weights: nn.Linear layers AND MoE expert weights.

    Args:
        prune_experts: Fraction of routed experts to prune (0.0 = none, 0.5 = half).
        routed_expert_bits: Override bit width for routed expert weights.
        per_module_bits: Dict mapping module name → bit width.
        learned_rotations: Dict mapping module name → rotation matrix.
            From optimize_all_rotations(). When present, uses learned rotation
            instead of fixed WHT for quantization. Enables viable TQ3.
    """
    replacements = 0
    total_original = 0
    total_compressed = 0
    expert_layers = 0
    pruned_count = 0

    # Build set of expert modules to prune (by name) for 2D expert layout.
    # HuggingFace stores experts as individual nn.Linear: experts.{N}.gate_proj
    # vLLM FusedMoE stores as 3D tensors. We handle both.
    pruned_expert_modules: set[str] = set()
    if prune_experts > 0:
        import re

        gates = _find_router_weights(model)
        for gate_path, gate_weight in gates.items():
            num_experts = gate_weight.shape[0]
            n_keep = max(1, int(num_experts * (1.0 - prune_experts)))
            ranked = _rank_experts_by_importance(gate_weight)
            prune_indices = set(ranked[n_keep:].tolist())

            # Find 2D expert modules by name pattern: {gate_path}.experts.{N}.*
            # gate_path is the MoE block (e.g., model.layers.0.mlp) that contains
            # both 'gate' and 'experts' as children.
            pattern = re.compile(rf"^{re.escape(gate_path)}\.experts\.(\d+)\b")
            for mod_name, _ in model.named_modules():
                m = pattern.match(mod_name)
                if m and int(m.group(1)) in prune_indices:
                    pruned_expert_modules.add(mod_name)

            n_marked = len([m for m in pruned_expert_modules if m.startswith(gate_path)])
            logger.info(
                "Expert pruning %s: keeping %d/%d experts (%.0f%% pruned, %d modules marked)",
                gate_path,
                n_keep,
                num_experts,
                prune_experts * 100,
                n_marked,
            )

    # Phase 1: Replace nn.Linear layers with TurboQuantWrapper
    # Also match vLLM's parallel linear layers (ColumnParallelLinear, etc.)
    # which have .weight but inherit from LinearBase, not nn.Linear
    for name, module in list(model.named_modules()):
        # Skip modules already compressed by per-layer streaming compression
        if isinstance(module, TurboQuantWrapper):
            continue
        # Skip layers already packed by an earlier per-layer quantization path.
        # Re-wrapping them would try to quantize an empty placeholder weight.
        if hasattr(module, "tq_packed_weight") and hasattr(module, "tq_norms"):
            continue
        if not isinstance(module, nn.Linear):
            # Check for vLLM parallel linears: have weight + input_size/output_size
            if not (
                hasattr(module, "weight")
                and isinstance(getattr(module, "weight", None), (torch.Tensor, nn.Parameter))
                and (hasattr(module, "input_size") or hasattr(module, "in_features"))
            ):
                continue
            # Normalize attribute names for vLLM compatibility
            if not hasattr(module, "in_features") and hasattr(module, "input_size"):
                module.in_features = module.input_size
            if not hasattr(module, "out_features") and hasattr(module, "output_size_per_partition"):
                module.out_features = module.output_size_per_partition
            elif not hasattr(module, "out_features") and hasattr(module, "output_size"):
                module.out_features = module.output_size
        if module.in_features < min_size and module.out_features < min_size:
            continue
        if any(p in name.lower() for p in _SKIP_PATTERNS):
            continue

        # Check if this is a pruned expert — skip compression, zero it
        is_pruned = name in pruned_expert_modules or any(
            name.startswith(pm + ".") or name == pm for pm in pruned_expert_modules
        )
        if is_pruned:
            # Zero the weight and compress at minimum bits
            module.weight.data.zero_()
            pruned_count += module.weight.numel()

        parent, attr_name = _resolve_parent_and_attr(model, name)

        original_bytes = module.weight.numel() * module.weight.element_size()

        # Select bits: per_module_bits > pruned > routed override > kurtosis > default
        if per_module_bits and name in per_module_bits:
            tensor_bits = per_module_bits[name]
        elif is_pruned:
            tensor_bits = 2  # minimum for zeroed weights
        elif "expert" in name.lower() and routed_expert_bits is not None:
            tensor_bits = routed_expert_bits
        else:
            tensor_bits = _select_bits(module.weight.data, bits, kurtosis_aware)

        rotation = learned_rotations.get(name) if learned_rotations else None
        wrapper = TurboQuantWrapper(
            module,
            bits=tensor_bits,
            group_size=group_size,
            rotation=rotation,
            rotary_dim=rotary_dim,
        )
        setattr(parent, attr_name, wrapper)

        compressed_bytes = wrapper.packed_weight.numel() + wrapper.norms.numel() * wrapper.norms.element_size()
        total_original += original_bytes
        total_compressed += compressed_bytes
        replacements += 1

    # Phase 2: Compress MoE expert weights. 2A handles vLLM FusedMoE
    # instances (compress + install TurboQuantFusedMoEMethod); 2B is
    # a fallback for non-FusedMoE 3D parameters in test fixtures and
    # non-vLLM HF models.
    #
    # Expert pruning: if prune_experts > 0, find router gate weights and zero out
    # the least-important experts before compression. Zeroed rows produce norms ≈ 0
    # and uniform indices — storage isn't eliminated but norms become negligible.

    # Build param_name → keep_mask mapping for expert pruning (3D layout).
    # Uses router gate weight norms to rank experts by importance.
    param_to_mask: dict[str, torch.Tensor] = {}  # param_name → bool mask
    if prune_experts > 0:
        gates = _find_router_weights(model)
        # For each gate, find sibling 3D parameters (expert weights in same MoE block)
        for gate_path, gate_weight in gates.items():
            num_experts = gate_weight.shape[0]
            n_keep = max(1, int(num_experts * (1.0 - prune_experts)))
            ranked = _rank_experts_by_importance(gate_weight)
            mask = torch.zeros(num_experts, dtype=torch.bool, device=gate_weight.device)
            mask[ranked[:n_keep]] = True

            # Map 3D params under this MoE block (and parent) to the mask.
            # Expert weights can be children of the gate's module or siblings.
            gate_parts = gate_path.split(".")
            prefixes = [gate_path + "."]
            if len(gate_parts) > 1:
                prefixes.append(".".join(gate_parts[:-1]) + ".")
            for pname, p in model.named_parameters():
                if p.dim() == 3 and p.shape[0] == num_experts:
                    if any(pname.startswith(pfx) for pfx in prefixes):
                        param_to_mask[pname] = mask

            logger.info(
                "Expert pruning %s: keeping %d/%d experts (%.0f%% pruned)",
                gate_path,
                n_keep,
                num_experts,
                prune_experts * 100,
            )

    # Free memory released by Phase 1 compression before Phase 2A
    # allocates MoE scratch buffers. Critical when GPU is near-full
    # (e.g. 309 GB model on 2×H200 at 155 GB/GPU, 5 GB headroom).
    if replacements > 0 and torch.cuda.is_available():
        torch.cuda.empty_cache()

    _moe_compressed_count = 0

    # --- Phase 2A: FusedMoE quant method replacement (vLLM path) ---
    # Walk modules for FusedMoE instances; for each, compress w13/w2 in
    # place via _compress_3d_param and install TurboQuantFusedMoEMethod
    # via _replace_quant_method. A single scratch pool is shared across
    # all FusedMoE layers — per-layer scratch would hold N × uncompressed
    # expert bytes on the side and wipe the compression savings.
    try:
        from vllm.model_executor.layers.fused_moe import FusedMoE

        from turboquant_vllm.moe_quant import (
            TurboQuantFusedMoEMethod,
            TurboQuantFusedMoEScratchPool,
        )
    except ImportError:
        FusedMoE = None
        TurboQuantFusedMoEMethod = None
        TurboQuantFusedMoEScratchPool = None

    moe_scratch_pool = None

    if FusedMoE is not None and TurboQuantFusedMoEMethod is not None and TurboQuantFusedMoEScratchPool is not None:
        for name, module in list(model.named_modules()):
            if not isinstance(module, FusedMoE):
                continue
            if any(p in name.lower() for p in _SKIP_PATTERNS):
                continue
            # Skip already-compressed FusedMoE (per-layer streaming compression)
            if hasattr(module, "_tq_w13_weight"):
                continue

            w13_param = getattr(module, "w13_weight", None)
            w2_param = getattr(module, "w2_weight", None)
            if w13_param is None or w2_param is None:
                logger.warning(
                    "FusedMoE at %s has no w13_weight/w2_weight — skipping "
                    "(non-default weight layout, needs custom handling)",
                    name,
                )
                continue
            if w13_param.dim() != 3 or w2_param.dim() != 3:
                logger.warning(
                    "FusedMoE at %s has unexpected weight rank (w13=%d, w2=%d) — skipping",
                    name,
                    w13_param.dim(),
                    w2_param.dim(),
                )
                continue

            # Select bit width for this MoE block. Respect per-module override,
            # routed_expert_bits, then kurtosis_aware (per side), then default.
            # Gate/up (w13) and down (w2) have different kurtosis on every MoE
            # model we've measured (down is consistently heavier-tailed), so
            # reading kurtosis once on w13 and applying to both sides misses
            # ~2-5% of the bit-allocation ceiling.
            if per_module_bits and name in per_module_bits:
                w13_bits = w2_bits = per_module_bits[name]
            elif routed_expert_bits is not None:
                w13_bits = w2_bits = routed_expert_bits
            else:
                w13_bits = _select_bits(w13_param.data, bits, kurtosis_aware)
                w2_bits = _select_bits(w2_param.data, bits, kurtosis_aware)

            # Compress both tensors in place via the shared helper.
            # _compress_3d_param stores Compressed3D as _tq_{param_name}
            # and resets param.data to an empty tensor.
            w13_orig, w13_comp = _compress_3d_param(module, "w13_weight", w13_bits, group_size)
            w2_orig, w2_comp = _compress_3d_param(module, "w2_weight", w2_bits, group_size)
            total_original += w13_orig + w2_orig
            total_compressed += w13_comp + w2_comp
            expert_layers += 2

            w13_c = module._tq_w13_weight
            w2_c = module._tq_w2_weight

            # Allocate the shared scratch pool from the FIRST FusedMoE
            # layer's expert shapes, BEFORE vLLM's memory profile + KV
            # cache allocation + CUDA graph capture, so the profile pass
            # sees the scratch bytes and sizes the KV cache accordingly.
            # All subsequent layers must have matching shapes (asserted).
            if moe_scratch_pool is None:
                moe_scratch_pool = TurboQuantFusedMoEScratchPool(w13_c, w2_c)
            else:
                moe_scratch_pool.assert_matches(w13_c, w2_c)

            # Permanently re-point every FusedMoE layer's w13_weight.data
            # / w2_weight.data at the shared scratch buffers. ALL layers
            # point at the SAME physical memory — fine because only one
            # layer runs at a time, and CUDA graph replay sees stable
            # addresses from install time onward. apply() then just
            # writes fresh dequantized values into those addresses.
            module.w13_weight.data = moe_scratch_pool.w13
            module.w2_weight.data = moe_scratch_pool.w2

            # Swap the FusedMoE quant method. _replace_quant_method both
            # updates self.quant_method AND re-inits the runner so the
            # runner's captured reference points at our new method.
            base_method = getattr(module, "base_quant_method", getattr(module, "quant_method", None))
            new_method = TurboQuantFusedMoEMethod(
                module.moe_config,
                w13_c,
                w2_c,
                moe_scratch_pool,
                base_method=base_method,
            )
            module._replace_quant_method(new_method)
            _moe_compressed_count += 1

    # --- Phase 2B: Non-FusedMoE 3D parameter fallback (no forward hook) ---
    for name, param in list(model.named_parameters()):
        if param.dim() != 3:
            continue
        if param.shape[-1] < min_size and param.shape[-2] < min_size:
            continue
        if any(p in name.lower() for p in _SKIP_PATTERNS):
            continue

        owner, param_name = _resolve_parent_and_attr(model, name)

        # Skip params that live inside a FusedMoE we already handled
        # in Phase 2A. _compress_3d_param resets param.data to an empty
        # tensor, so those params now have numel 0 and would fail the
        # downstream pipeline anyway.
        if FusedMoE is not None and isinstance(owner, FusedMoE):
            continue

        # Apply expert pruning in-place if mask available
        if prune_experts > 0 and name in param_to_mask:
            mask = param_to_mask[name]
            _prune_expert_weights(param.data, mask)
            pruned_count += (~mask).sum().item() * param.shape[1] * param.shape[2]

        # Select bit width: routed_expert_bits override, or kurtosis, or default
        if routed_expert_bits is not None:
            tensor_bits = routed_expert_bits
        else:
            tensor_bits = _select_bits(param.data, bits, kurtosis_aware)
        orig_bytes, comp_bytes = _compress_3d_param(owner, param_name, tensor_bits, group_size)
        total_original += orig_bytes
        total_compressed += comp_bytes
        expert_layers += 1

    total = replacements + expert_layers
    if total > 0:
        ratio = total_original / total_compressed if total_compressed > 0 else 0
        prune_msg = f", {pruned_count:,} expert params pruned" if pruned_count > 0 else ""
        expert_bits_msg = f" (routed@TQ{routed_expert_bits})" if routed_expert_bits else ""
        logger.info(
            "TQ%d-g%d%s weight compression: %d linear + %d expert layers, %.1f GB -> %.1f GB (%.1fx)%s",
            bits,
            group_size,
            expert_bits_msg,
            replacements,
            expert_layers,
            total_original / 1e9,
            total_compressed / 1e9,
            ratio,
            prune_msg,
        )
        # Guard: on CPU-only PyTorch builds (Mac, CI, etc.) calling
        # torch.cuda.empty_cache() raises AssertionError.
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    if _moe_compressed_count > 0:
        logger.info(
            "TurboQuant compressed %d FusedMoE layer(s). CUDA dequant "
            "kernels run on PyTorch's current stream — CUDA graph "
            "capture is supported (no --enforce-eager required).",
            _moe_compressed_count,
        )

    return total


def patch_vllm_loader(**replace_kwargs) -> None:
    """Monkey-patch vLLM's process_weights_after_loading to call _replace_linear_layers.

    Wraps the original function so that after normal weight loading,
    _replace_linear_layers is called with the given keyword arguments.

    Raises ImportError if vLLM is not installed.
    """
    import vllm.model_executor.model_loader.utils as loader_utils
    import vllm.model_executor.model_loader.base_loader as base_loader

    _original = loader_utils.process_weights_after_loading

    def patched_process_weights(model, model_config, target_device):
        _original(model, model_config, target_device)
        rotary_dim = _derive_rotary_dim(model_config)
        if rotary_dim is not None:
            logger.info(
                "TurboQuant: partial_rotary detected — using block-diag WHT with block_size=%d",
                rotary_dim,
            )
        logger.info("Applying TurboQuant weight compression...")
        count = _replace_linear_layers(model, rotary_dim=rotary_dim, **replace_kwargs)
        if count > 0:
            mem_gb = torch.cuda.memory_allocated() / 1e9 if torch.cuda.is_available() else 0
            logger.info("TurboQuant: %d layers compressed, GPU memory: %.1f GB", count, mem_gb)

    # Patch both the module-level function AND all imported references.
    # Python's `from X import Y` binds a local name that doesn't see
    # later module-level replacements, so we must patch every importer.
    loader_utils.process_weights_after_loading = patched_process_weights
    base_loader.process_weights_after_loading = patched_process_weights
    try:
        import vllm.model_executor.model_loader.gguf_loader as gguf_loader

        gguf_loader.process_weights_after_loading = patched_process_weights
    except (ImportError, AttributeError):
        pass


def enable_weight_quantization(
    bits: int = 3,
    group_size: int = 128,
    min_layer_size: int = 1024,
    kurtosis_aware: bool = False,
    prune_experts: float = 0.0,
    routed_expert_bits: int | None = None,
):
    """Monkey-patch vLLM to apply TurboQuant weight compression at model load time.

    Args:
        bits: default quantization bits (2-8). Default 3 for best size/quality.
        group_size: elements per quantization group. Default 128 (matches head_dim).
        min_layer_size: minimum dimension to compress (skip small layers).
        kurtosis_aware: Auto-select bits per tensor based on kurtosis.
            Heavy-tailed tensors (shared MoE experts) get more bits.
            Near-Gaussian tensors (routed experts) get fewer bits.
        prune_experts: Fraction of routed MoE experts to prune (0.0-1.0).
            Uses router weight norms to rank experts by importance.
            REAP (ICLR 2026): 50% pruning retains 97.6% quality on MoE.
        routed_expert_bits: Override bit width for routed expert weights.
            Set to 2 for aggressive compression (viable for routed experts).
    """
    assert 2 <= bits <= 8, f"bits must be 2-8, got {bits}"
    assert group_size in (64, 128, 256), f"group_size must be 64/128/256, got {group_size}"
    assert 0.0 <= prune_experts < 1.0, f"prune_experts must be 0.0-1.0, got {prune_experts}"

    os.environ["TQ_WEIGHT_BITS"] = str(bits)
    os.environ["TQ_WEIGHT_GROUP_SIZE"] = str(group_size)

    try:
        patch_vllm_loader(
            bits=bits,
            group_size=group_size,
            min_size=min_layer_size,
            kurtosis_aware=kurtosis_aware,
            prune_experts=prune_experts,
            routed_expert_bits=routed_expert_bits,
        )
    except ImportError:
        logger.error("Cannot import vLLM model loader. Is vLLM installed?")
        raise

    prune_msg = f", {prune_experts * 100:.0f}% expert pruning" if prune_experts > 0 else ""
    expert_msg = f", routed@TQ{routed_expert_bits}" if routed_expert_bits else ""
    logger.info("TurboQuant TQ%d-g%d weight compression enabled%s%s", bits, group_size, prune_msg, expert_msg)


def save_compressed_checkpoint(
    model_id: str,
    output_dir: str,
    bits: int = 3,
    group_size: int = 128,
):
    """Save a TQ-compressed checkpoint as FP16 that loads on smaller GPUs.

    Problem: Gemma 4 26B is 52 GB in BF16, which doesn't fit on a 48 GB L40S
    during loading, even though the compressed model is only 12 GB in memory.

    Solution: load BF16 to CPU (needs ~60 GB RAM), compress with TQ on CPU,
    save the decompressed FP16 weights (~26 GB checkpoint). This checkpoint
    loads directly on a 48 GB GPU. Use enable_weight_quantization(bits=3) on
    top to compress in memory to 12 GB at runtime.

    CPU compression takes about 1-2 minutes instead of 9 seconds on GPU.

    Args:
        model_id: HuggingFace model ID.
        output_dir: Where to save the FP16 checkpoint.
        bits: Quantization bits (3 or 4).
        group_size: Group size (128).
    """
    logger.info("Loading %s to CPU for compression...", model_id)

    from transformers import AutoModelForCausalLM, AutoTokenizer

    model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype=torch.bfloat16, device_map="cpu")
    tokenizer = AutoTokenizer.from_pretrained(model_id)

    quantizer = _get_quantizer(group_size, bits, "cpu")
    compressed_count = 0

    for name, module in list(model.named_modules()):
        if not isinstance(module, nn.Linear):
            continue
        if module.in_features < 128 and module.out_features < 128:
            continue
        if any(p in name.lower() for p in _SKIP_PATTERNS):
            continue

        weight = module.weight.data.float()
        out_dim, in_dim = weight.shape

        padded_in, _ = padded_size(in_dim, group_size)
        if padded_in > in_dim:
            padded = torch.zeros(out_dim, padded_in, dtype=weight.dtype)
            padded[:, :in_dim] = weight
        else:
            padded = weight

        grouped = padded.reshape(-1, group_size)
        indices, norms = quantizer.quantize(grouped, norm_correction=True)
        w_hat = quantizer.dequantize(indices, norms)
        w_reconstructed = w_hat.reshape(out_dim, padded_in)[:, :in_dim]

        module.weight.data = w_reconstructed.to(torch.float16)
        compressed_count += 1

        if compressed_count % 500 == 0:
            logger.info("  Compressed %d layers...", compressed_count)

    logger.info("Compressed %d layers on CPU", compressed_count)

    for param in model.parameters():
        param.data = param.data.half()
    for buf_name, buf in model.named_buffers():
        if buf.is_floating_point():
            buf.data = buf.data.half()
    model.config.torch_dtype = "float16"

    os.makedirs(output_dir, exist_ok=True)
    model.save_pretrained(output_dir, safe_serialization=True)
    tokenizer.save_pretrained(output_dir)

    total_size = sum(os.path.getsize(os.path.join(output_dir, f)) for f in os.listdir(output_dir))
    logger.info("Saved to %s (%.1f GB)", output_dir, total_size / 1e9)
