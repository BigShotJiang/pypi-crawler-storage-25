# MIT License
#
# Copyright (c) 2026 Pedro Guzmán
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Observer classes for parameter loading events."""

from __future__ import annotations

import logging
from typing import Protocol


class ConfigurationObserver(Protocol):  # pragma: no cover
    """Protocol for receiving parameter loading events."""

    def on_field_resolved(
        self,
        field_name: str,
        envar: str,
        value_present: bool,
        used_default: bool,
        is_sensitive: bool,
    ) -> None:
        """Handle a resolved field event."""
        ...

    def on_parse_started(self, source_class: str) -> None:
        """Handle a parse start event."""
        ...

    def on_parse_completed(self, source_class: str, field_count: int) -> None:
        """Handle a successful parse event."""
        ...

    def on_parse_failed(self, source_class: str, error: Exception) -> None:
        """Handle a failed parse event."""
        ...


class LoggingObserver:
    """Observer that writes parameter loading events to a Python logger."""

    def __init__(
        self,
        logger: logging.Logger | None = None,
        level: int = logging.INFO,
    ) -> None:
        """Create a logging observer."""
        self._logger = logger or logging.getLogger("envbind")
        self._level = level

    def on_field_resolved(
        self,
        field_name: str,
        envar: str,
        value_present: bool,
        used_default: bool,
        is_sensitive: bool,
    ) -> None:
        """Log a field resolution event."""
        if used_default:
            default_reason = "is empty" if value_present else "not set"
            self._logger.log(
                self._level,
                f"Config: {field_name} using default (env var {envar} {default_reason})",
            )
            return

        if is_sensitive:
            self._logger.log(
                self._level,
                f"Config: {field_name} loaded from {envar} (value redacted)",
            )
            return

        self._logger.log(
            self._level,
            f"Config: {field_name} loaded from {envar}",
        )

    def on_parse_started(self, source_class: str) -> None:
        """Log the start of parameter parsing."""
        self._logger.log(self._level, f"Loading configuration: {source_class}")

    def on_parse_completed(self, source_class: str, field_count: int) -> None:
        """Log successful parameter parsing."""
        self._logger.log(
            self._level,
            f"Configuration loaded: {source_class} ({field_count} fields)",
        )

    def on_parse_failed(self, source_class: str, error: Exception) -> None:
        """Log failed parameter parsing."""
        self._logger.error(
            f"Configuration loading failed: {source_class}",
            exc_info=error,
        )


class StructuredObserver:
    """Observer that writes one structured log record after parsing."""

    def __init__(self, logger: logging.Logger | None = None) -> None:
        """Create a structured observer."""
        self._logger = logger or logging.getLogger("envbind")
        self._fields: list[dict[str, bool | str]] = []

    def on_field_resolved(
        self,
        field_name: str,
        envar: str,
        value_present: bool,
        used_default: bool,
        is_sensitive: bool,
    ) -> None:
        """Record a field resolution event."""
        self._fields.append(
            {
                "field_name": field_name,
                "envar": envar,
                "value_present": value_present,
                "used_default": used_default,
                "is_sensitive": is_sensitive,
            }
        )

    def on_parse_started(self, source_class: str) -> None:
        """Ignore parse start events."""

    def on_parse_completed(self, source_class: str, field_count: int) -> None:
        """Emit one structured success log record."""
        self._logger.info(
            "Configuration loaded",
            extra={
                "source_class": source_class,
                "field_count": field_count,
                "fields": self._fields,
            },
        )
        self._fields = []

    def on_parse_failed(self, source_class: str, error: Exception) -> None:
        """Emit one structured failure log record."""
        self._logger.error(
            "Configuration loading failed",
            extra={
                "source_class": source_class,
                "fields": self._fields,
            },
            exc_info=error,
        )
        self._fields = []
