# MIT License
#
# Copyright (c) 2026 Pedro Guzmán
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Validation helpers for environment fields."""

from __future__ import annotations

import re
from collections.abc import Callable
from typing import Any
from urllib.parse import urlparse


def in_range(min_val: float, max_val: float) -> Callable[[float], None]:
    """Return a validator that accepts values inside an inclusive range."""

    def validator(value: float) -> None:
        """Validate one numeric value."""
        if not min_val <= value <= max_val:
            raise ValueError(f"Value must be between {min_val} and {max_val}, got {value}")

    return validator


def min_value(min_val: float) -> Callable[[float], None]:
    """Return a validator that accepts values greater than or equal to a minimum."""

    def validator(value: float) -> None:
        """Validate one numeric value."""
        if value < min_val:
            raise ValueError(f"Value must be at least {min_val}, got {value}")

    return validator


def max_value(max_val: float) -> Callable[[float], None]:
    """Return a validator that accepts values less than or equal to a maximum."""

    def validator(value: float) -> None:
        """Validate one numeric value."""
        if value > max_val:
            raise ValueError(f"Value must be at most {max_val}, got {value}")

    return validator


def one_of(*allowed: Any) -> Callable[[Any], None]:
    """Return a validator that accepts values from a fixed set."""
    allowed_set = set(allowed)

    def validator(value: Any) -> None:
        """Validate one value."""
        if value not in allowed_set:
            raise ValueError(f"Value must be one of {allowed}, got {value!r}")

    return validator


def min_length(length: int) -> Callable[[str], None]:
    """Return a validator that accepts strings at least a given length."""

    def validator(value: str) -> None:
        """Validate one string."""
        if len(value) < length:
            raise ValueError(f"Value must be at least {length} characters, got {len(value)}")

    return validator


def max_length(length: int) -> Callable[[str], None]:
    """Return a validator that accepts strings at most a given length."""

    def validator(value: str) -> None:
        """Validate one string."""
        if len(value) > length:
            raise ValueError(f"Value must be at most {length} characters, got {len(value)}")

    return validator


def matches_pattern(pattern: str) -> Callable[[str], None]:
    """Return a validator that accepts strings matching a regex pattern."""
    compiled = re.compile(pattern)

    def validator(value: str) -> None:
        """Validate one string."""
        if not compiled.match(value):
            raise ValueError(f"Value must match pattern {pattern!r}, got {value!r}")

    return validator


def is_url(
    require_scheme: bool = True,
    allowed_schemes: set[str] | None = None,
) -> Callable[[str], None]:
    """Return a validator that accepts URL strings."""
    allowed = allowed_schemes or {"http", "https"}

    def validator(value: str) -> None:
        """Validate one URL string."""
        parsed = urlparse(value)

        if require_scheme and not parsed.scheme:
            raise ValueError("URL must include a scheme, for example https://")

        if parsed.scheme and parsed.scheme not in allowed:
            raise ValueError(f"URL scheme must be one of {allowed}, got {parsed.scheme!r}")

        if not parsed.netloc:
            raise ValueError("URL must include a network location")

    return validator


def is_email() -> Callable[[str], None]:
    """Return a validator that accepts common email address strings."""
    pattern = re.compile(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")

    def validator(value: str) -> None:
        """Validate one email string."""
        if not pattern.match(value):
            raise ValueError(f"Invalid email address: {value!r}")

    return validator


def all_of(*validators: Callable[[Any], None]) -> Callable[[Any], None]:
    """Return a validator that runs every supplied validator."""

    def validator(value: Any) -> None:
        """Validate one value with every supplied validator."""
        for item in validators:
            item(value)

    return validator
