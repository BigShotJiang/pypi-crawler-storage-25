# MIT License
#
# Copyright (c) 2026 Pedro Guzmán
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Core container that materialises all environment descriptors."""

from __future__ import annotations

import os
from collections.abc import Iterator
from typing import TYPE_CHECKING, Any

from ._fields import EnvField

if TYPE_CHECKING:
    from ._observability import ConfigurationObserver


class ParameterSource:
    """Base class for classes backed by environment variable descriptors."""

    _observer: ConfigurationObserver | None = None

    def __init__(self) -> None:
        """Load all declared environment fields at construction time."""
        if self._observer:
            self._observer.on_parse_started(self.__class__.__name__)

        try:
            self._coerce_fields()

            if self._observer:
                field_count = len(self._declared_fields())
                self._observer.on_parse_completed(self.__class__.__name__, field_count)
        except Exception as exc:
            if self._observer:
                self._observer.on_parse_failed(self.__class__.__name__, exc)
            raise

    @classmethod
    def set_observer(cls, observer: ConfigurationObserver | None) -> None:
        """Set the configuration observer used for all parameter sources."""
        cls._observer = observer

    @classmethod
    def _declared_fields(cls) -> dict[str, EnvField]:
        """Collect declared ``EnvField`` descriptors from the class hierarchy."""
        fields: dict[str, EnvField] = {}
        for base in reversed(cls.__mro__):
            for name, value in base.__dict__.items():
                if isinstance(value, EnvField):
                    fields[name] = value
        return fields

    @classmethod
    def _iter_fields(cls) -> Iterator[tuple[str, EnvField]]:
        """Yield declared field names and descriptors in deterministic order."""
        yield from cls._declared_fields().items()

    def _coerce_fields(self) -> None:
        """Resolve all configured fields and cache values on this instance."""
        for name, field in self._declared_fields().items():
            raw_value = os.getenv(field.envar)
            value_present = raw_value is not None
            value = field.resolve()
            self.__dict__[name] = value

            if self._observer:
                self._observer.on_field_resolved(
                    field_name=name,
                    envar=field.envar,
                    value_present=value_present,
                    used_default=field._uses_default_for(raw_value),
                    is_sensitive=field.is_sensitive,
                )

    def as_dict(self, *, include_sensitive: bool = False) -> dict[str, Any]:
        """Return parsed fields as a dictionary."""
        result: dict[str, Any] = {}
        for name, field in self._declared_fields().items():
            if field.is_sensitive and not include_sensitive:
                continue
            result[name] = getattr(self, name)
        return result

    def __repr__(self) -> str:
        """Return a short representation with sensitive values masked."""
        parts = []
        for name, field in self._declared_fields().items():
            if field.is_sensitive:
                parts.append(f"{name}=***")
            else:
                value = getattr(self, name)
                parts.append(f"{name}={value!r}")
        return f"{self.__class__.__name__}({', '.join(parts)})"
