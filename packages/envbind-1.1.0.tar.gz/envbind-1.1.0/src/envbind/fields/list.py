# MIT License
#
# Copyright (c) 2026 Pedro Guzmán
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""List environment field."""

from __future__ import annotations

from collections.abc import Callable
from enum import Enum
from typing import Any, TypeVar

from .._exceptions import InvalidEnvironmentValueError
from .._fields import _MISSING, EnvField

_T = TypeVar("_T")


class ListEnv(EnvField):
    """Parse delimiter-separated values into a list."""

    _TRUTHY = {"1", "true", "yes", "on", "y", "t"}
    _FALSEY = {"0", "false", "no", "off", "n", "f"}

    def __init__(
        self,
        *,
        envar: str,
        delimiter: str = ",",
        strip: bool = True,
        optional: bool = False,
        default: Any = _MISSING,
        sensitive: bool = True,
        validator: Callable[[list[Any]], None] | None = None,
        allow_empty: bool = False,
        element_type: type[_T] | Callable[[str], _T] | type[str] = str,
    ) -> None:
        """Create list field.

        Args:
            envar: The environment variable name to read.
            delimiter: Character used to split values.
            strip: Remove surrounding spaces from each item.
            optional: Set true to allow missing variable.
            default: Optional default value used when input is not present.
            sensitive: Set false to expose the value in repr and logs.
            validator: Optional function that raises when value is invalid.
            allow_empty: Set true to send empty strings to the parser.
            element_type: Type or callable used to parse each item.
        """
        if delimiter == "":
            raise ValueError("delimiter must not be empty")
        super().__init__(
            envar=envar,
            optional=optional,
            default=default,
            sensitive=sensitive,
            validator=validator,
            allow_empty=allow_empty,
        )
        self._delimiter = delimiter
        self._strip = strip
        self._element_type = element_type

    def _coerce(self, raw: str) -> list[Any]:
        """Split incoming value into list items and coerce each item."""
        parts = raw.split(self._delimiter)
        if self._strip:
            parts = [part.strip() for part in parts]

        if self._element_type is str:
            return parts

        try:
            return [self._coerce_element(part) for part in parts]
        except Exception as exc:
            raise InvalidEnvironmentValueError(
                f"Failed to coerce list elements for {self._envar}: {exc}"
            ) from exc

    def _coerce_element(self, value: str) -> Any:
        """Coerce one list item."""
        if self._element_type is bool:
            return self._coerce_bool(value)

        if isinstance(self._element_type, type) and issubclass(self._element_type, Enum):
            return self._coerce_enum(value, self._element_type)

        return self._element_type(value)  # type: ignore[call-arg]

    def _coerce_bool(self, value: str) -> bool:
        """Coerce one list item into a bool."""
        normalized = value.strip().lower()
        if normalized in self._TRUTHY:
            return True
        if normalized in self._FALSEY:
            return False
        raise ValueError(f"Cannot parse {value!r} as bool")

    def _coerce_enum(self, value: str, enum_type: type[Enum]) -> Enum:
        """Coerce one list item into an enum member."""
        try:
            return enum_type(value)
        except ValueError:
            pass

        normalized = value.lower()
        for member in enum_type:
            if member.name.lower() == normalized:
                return member

        for member in enum_type:
            if str(member.value).lower() == normalized:
                return member

        raise ValueError(f"Invalid enum value {value!r} for {enum_type.__name__}")
