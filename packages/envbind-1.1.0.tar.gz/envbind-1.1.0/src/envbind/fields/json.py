# MIT License
#
# Copyright (c) 2026 Pedro Guzmán
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""JSON environment field."""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

from .._exceptions import InvalidEnvironmentValueError
from .._fields import _MISSING, EnvField


class JSONEnv(EnvField):
    """Parse JSON payloads."""

    def __init__(
        self,
        *,
        envar: str,
        optional: bool = False,
        default: Any = _MISSING,
        sensitive: bool = True,
        validator: Callable[[Any], None] | None = None,
        allow_empty: bool = False,
    ) -> None:
        """Create a JSON environment field."""
        super().__init__(
            envar=envar,
            optional=optional,
            default=default,
            sensitive=sensitive,
            validator=validator,
            allow_empty=allow_empty,
        )

    def _coerce(self, raw: str) -> Any:
        """Parse JSON text."""
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            raise InvalidEnvironmentValueError(
                f"Value for {self._envar} must be valid JSON"
            ) from exc
