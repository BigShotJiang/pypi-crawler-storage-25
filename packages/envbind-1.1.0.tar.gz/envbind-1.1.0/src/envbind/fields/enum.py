# MIT License
#
# Copyright (c) 2026 Pedro Guzmán
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Enum environment field."""

from __future__ import annotations

from collections.abc import Callable
from enum import Enum
from typing import Any, Generic, TypeVar

from .._exceptions import InvalidEnvironmentValueError
from .._fields import _MISSING, EnvField

_E = TypeVar("_E", bound=Enum)


class EnumEnv(EnvField, Generic[_E]):
    """Parse enum members from text.

    The class is generic on the enum type so that type checkers can infer the
    concrete member type returned by ``resolve`` without an explicit cast.

    Example::

        class Mode(Enum):
            READ = "read"
            WRITE = "write"

        class Config(ParameterSource):
            mode: Mode = EnumEnv(envar="APP_MODE", enum_type=Mode)
    """

    def __init__(
        self,
        *,
        enum_type: type[_E],
        envar: str,
        optional: bool = False,
        default: Any = _MISSING,
        case_sensitive: bool = False,
        sensitive: bool = True,
        validator: Callable[[_E], None] | None = None,
        allow_empty: bool = False,
    ) -> None:
        """Create enum field.

        Args:
            enum_type: Target enum class.
            envar: The environment variable name to read.
            optional: Set true to allow missing variable.
            default: Optional default value used when input is not present.
            case_sensitive: Keep name and value comparison case-sensitive.
            sensitive: Set false to expose the value in repr and logs.
            validator: Optional function that raises when value is invalid.
            allow_empty: Set true to send empty strings to the parser.
        """
        if not isinstance(enum_type, type) or not issubclass(enum_type, Enum):
            raise TypeError("enum_type must be an Enum subclass")
        super().__init__(
            envar=envar,
            optional=optional,
            default=default,
            sensitive=sensitive,
            validator=validator,
            allow_empty=allow_empty,
        )
        self._enum_type: type[_E] = enum_type
        self._case_sensitive = case_sensitive

    def _coerce(self, raw: str) -> _E:
        """Map text to an enum member."""
        candidate = raw.strip()
        if self._case_sensitive:
            for option in self._enum_type:
                if candidate == option.name or candidate == str(option.value):
                    return option
        else:
            candidate_lower = candidate.lower()
            for option in self._enum_type:
                option_name = option.name.lower()
                option_value = str(option.value).lower()
                if candidate_lower in (option_name, option_value):
                    return option
        raise InvalidEnvironmentValueError(
            f"Value for {self._envar} must match enum {self._enum_type.__name__}"
        )
