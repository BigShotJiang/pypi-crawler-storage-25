# MIT License
#
# Copyright (c) 2026 Pedro Guzmán
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Environment field descriptors."""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any

from ._exceptions import InvalidEnvironmentValueError, MissingEnvironmentVariableError

_MISSING = object()


class EnvField(ABC):
    """Descriptor that reads one environment variable and returns a typed value."""

    def __init__(
        self,
        *,
        envar: str,
        optional: bool = False,
        default: Any = _MISSING,
        sensitive: bool = True,
        validator: Callable[[Any], None] | None = None,
        allow_empty: bool = False,
    ) -> None:
        """Create the descriptor.

        Args:
            envar: The environment variable name to read.
            optional: Set true to allow missing value.
            default: Optional default value used when input is not present.
            sensitive: Set false to expose the value in repr and logs.
            validator: Optional function that raises when value is invalid.
            allow_empty: Set true to send empty strings to the parser.
        """
        if not envar:
            raise ValueError("envar must be a non-empty string.")
        self._envar = envar
        self._optional = optional
        self._default = default
        self._sensitive = sensitive
        self._validator = validator
        self._allow_empty = allow_empty
        self._attr_name: str | None = None

    @property
    def envar(self) -> str:
        """Return the linked environment variable name."""
        return self._envar

    @property
    def optional(self) -> bool:
        """Return whether this field allows a missing variable."""
        return self._optional

    @property
    def is_sensitive(self) -> bool:
        """Return whether the field value should be hidden by default."""
        return self._sensitive

    def __set_name__(self, owner: type[object], name: str) -> None:
        """Store the attribute name when class body binds the descriptor."""
        self._attr_name = name

    @property
    def attr_name(self) -> str:
        """Return the bound attribute name."""
        if self._attr_name is None:
            raise RuntimeError("Environment field is not attached to a class.")
        return self._attr_name

    @property
    def has_default(self) -> bool:
        """Return True when a default value exists."""
        return self._default is not _MISSING

    def _uses_default_for(self, raw: str | None) -> bool:
        """Return True when the raw value resolves to the field default."""
        return self.has_default and (raw is None or (raw == "" and not self._allow_empty))

    def __get__(self, instance: object | None, owner: type[object]) -> Any:
        """Resolve and cache the parsed value for the current instance."""
        if instance is None:
            return self
        if self._attr_name is None:
            raise RuntimeError("Environment field is not attached to a class.")
        if self._attr_name in instance.__dict__:
            return instance.__dict__[self._attr_name]
        value = self.resolve()
        instance.__dict__[self._attr_name] = value
        return value

    def __set__(self, instance: object, value: Any) -> None:
        """Block assignment after parse time to preserve deterministic parsing."""
        raise AttributeError("Environment fields are read-only.")

    def __delete__(self, instance: object) -> None:
        """Block deletion to match the read-only contract of __set__."""
        raise AttributeError("Environment fields are read-only.")

    def resolve(self) -> Any:
        """Resolve the environment variable and return a typed value.

        Empty strings are treated as missing by default. Set ``allow_empty`` to
        true to parse empty strings through the field parser.
        """
        raw: str | None = os.getenv(self._envar)

        if raw is None:
            if self._optional:
                return self._default if self.has_default else None
            if self.has_default:
                return self._default
            raise MissingEnvironmentVariableError(
                f"Missing required environment variable: {self._envar}"
            )

        if raw == "":
            if self._allow_empty:
                value = self._coerce_value(raw)
                self._validate(value)
                return value
            if self._optional:
                return self._default if self.has_default else None
            if self.has_default:
                return self._default
            raise MissingEnvironmentVariableError(
                f"Empty value for required environment variable: {self._envar}"
            )

        value = self._coerce_value(raw)
        self._validate(value)
        return value

    def _coerce_value(self, raw: str) -> Any:
        """Coerce text and hide parse details for sensitive values."""
        try:
            return self._coerce(raw)
        except InvalidEnvironmentValueError as exc:
            if self._sensitive:
                raise InvalidEnvironmentValueError(
                    f"Invalid value for sensitive environment variable: {self._envar}"
                ) from exc
            raise
        except Exception as exc:
            if self._sensitive:
                raise InvalidEnvironmentValueError(
                    f"Invalid value for sensitive environment variable: {self._envar}"
                ) from exc
            raise InvalidEnvironmentValueError(f"Invalid value for {self._envar}: {exc}") from exc

    def _validate(self, value: Any) -> None:
        """Validate a parsed value with the optional validator function."""
        if self._validator is None:
            return

        try:
            self._validator(value)
        except Exception as exc:
            if self._sensitive:
                raise InvalidEnvironmentValueError(
                    f"Validation failed for sensitive environment variable: {self._envar}"
                ) from exc
            raise InvalidEnvironmentValueError(
                f"Validation failed for {self._envar}: {exc}"
            ) from exc

    @abstractmethod
    def _coerce(self, raw: str) -> Any:
        """Convert a raw environment string into the target type."""
