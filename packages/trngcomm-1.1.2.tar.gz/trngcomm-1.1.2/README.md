# TRNG Communicator
For their Capstone project, Adel Khaldi, Lucas Rodrigues, and Ethan Zornosa create a True Random Number Generator (TRNG) device to improve the security of encryption keys and other programs that require random numbers. This device connects to a computer through using USB-A and serves random bits to the computer upon request. This package contains the functions required to request bits from the device in your Python project.

## Requesting Bits
First, import the reqbits function.  
`from TRNGCom.util import reqbits`

reqbits takes one parameter, the number of random bits for the device to return. The device will return all requested bits in a bytes literal encoded with utf-8. Use this random bytes literal object for your random number needs.  
### Example
`reqbits(1000)` returns 1000 random bits as a bytestream literal of length 1000.

The device stores the requested number of bits in an unsigned long, meaning you can request roughly 4 billion bits. The device is capable of serving approximately 3000 bits per second, so keep in mind that large requests will take time to process and may slow down your program.

## About the TRNG device
The TRNG device is a state machine with 5 states. You can identify the state the device is in from the color of the device's LED. 

WAIT (WHITE) - The device is waiting for a request.  
HANDSHAKE (YELLOW) - The device has received a request and is echoing the request back as part of a 3-way handshake.   
HANDSHAKE2 (BLUE) - The device has echoed the request back and is waiting for final confirmation from the computer.   
ERROR (RED) - The 3-way handshake failed, and the device is waiting to be reset by the computer closing its serial port.  
ACTIVE (GREEN) - The device is sampling an analog signal from the Chaotic Boolean Oscillator circuit and transmitting the info to the computer.  