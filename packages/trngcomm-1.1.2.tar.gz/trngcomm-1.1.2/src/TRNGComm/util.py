from serial.tools.list_ports import comports
import serial

# Find which port the ESP32 is on.
def findPort():
    VID = 0x303A
    PID = 0x1001
    ports = comports()
    portName = None
    for port in ports:
        if port.pid == PID and port.vid == VID:
            portName = port.name
            break
    return portName

# Get and configure Serial instance
def getSerial(numBits):
    SPEED = 3065 # How many messages Arduino can send to computer per second
    timeout = (numBits / SPEED) * 1.3 + 5 # 30% extra time plus startup time
    ser = serial.Serial(timeout=timeout, dsrdtr=False, rtscts=False)
    ser.baudrate = 250000
    ser.port = findPort()
    return ser

# Send a request for bits
def reqBits(numBits):
    ser = getSerial(numBits)
    ser.open()
    print("Beginning Handshake")
    handshake(ser, numBits)
    bits = ser.read_until(size=numBits)
    ser.close()
    return bits

def reqBitsNoClose(numBits, ser):
    print("Beginning Handshake")
    handshake(ser, numBits)
    bits = ser.read_until(size=numBits)
    return bits

def handshake(ser, numBits):
    numBitsByte = str(numBits).encode()
    print(numBitsByte)
    ser.write(numBitsByte)
    numBytes = len(numBitsByte)
    print("Number of Bytes in ByteString Sent: " + str(numBytes))
    confirmed = 0
    bits = ser.readline()
    if is_number(bits.decode().strip()):
        confirmed = 1
    while not confirmed:
        bits = ser.readline()
        if is_number(bits.decode().strip()):
            confirmed = 1

    print("Bits: " + str(bits))
    print("Bits Decoded: " + str(bits.decode()))
    if bits.decode().strip() == str(numBits):
        ser.write(numBitsByte)
        print("Match!")
    else:
        print("No Match!")
    return

def receiveTest(size):
    ser = getSerial(size)
    ser.open()
    return ser.read_until(size=size)

# Request a random number between two values includes first value but not second
def reqNum(minimum, maximum):
    # Adjust if minimum is negative
    adjustment = 0
    if minimum < 0:
        print("Adjusting Minimum")
        adjustment = minimum
        print(adjustment)
        minimum -= adjustment
        maximum -= adjustment

    # Calculate how many random bits are required
    bitsNeeded = 0
    temp = int(maximum)
    while temp > 0: # divide by 2 to see how many bits are required to represent the number
        temp = int(temp / 2)
        bitsNeeded += 1
    bitsNeeded = max(bitsNeeded, 1)

    print("Bits Needed: " + str(bitsNeeded))

    ser = getSerial(bitsNeeded)
    if not ser.is_open:
        ser.open()

    number = minimum - 1
    while number < minimum or number >= maximum: # Reject numbers we don't want
        bits = reqBitsNoClose(bitsNeeded, ser).decode()
        number = int(bits, 2)
        print("Bits rec: " + str(bits))
        print("Number: " + str(number))
        ser.reset_input_buffer()
        print("Adjusted Number: " + str(number + adjustment))
    return number + adjustment

def is_number(s: str) -> bool:
    return len(s) > 0 and set(s) <= {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"}
