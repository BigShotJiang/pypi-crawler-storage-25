"""Config CLI — deepcraft config set/get/list/init."""

from __future__ import annotations

import os
from pathlib import Path

import click
import yaml

CONFIG_DIR = Path.home() / ".deepcraft"
CONFIG_FILE = CONFIG_DIR / "config.yaml"

DEFAULT_CONFIG = {
    "deepseek": {
        "api_key": "sk-your-key-here",
        "base_url": "https://api.deepseek.com",
        "model": "deepseek-chat",
        "max_tokens": 8192,
    },
    "agent": {
        "max_turns": 25,
        "workdir": ".",
        "compression": "auto",  # auto | aggressive | off
    },
}

SECRET_KEYS = {"deepseek.api_key"}


def _load_yaml(path: Path) -> dict:
    """Load YAML file, return {} if missing."""
    if not path.exists():
        return {}
    with open(path) as f:
        return yaml.safe_load(f) or {}


def _save_yaml(path: Path, data: dict) -> None:
    """Save dict to YAML file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        yaml.dump(data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)


def _resolve_file() -> Path | None:
    """Find the effective config file. Per-dir overrides global."""
    local = Path.cwd() / "deepcraft.yaml"
    if local.exists():
        return local
    if CONFIG_FILE.exists():
        return CONFIG_FILE
    return None


def _dot_get(data: dict, key: str) -> str:
    """Get a dot-separated key from nested dict."""
    parts = key.split(".")
    node = data
    for p in parts:
        if isinstance(node, dict):
            node = node.get(p)
        else:
            return ""
    if node is None:
        return ""
    return str(node)


def _dot_set(data: dict, key: str, value: str) -> None:
    """Set a dot-separated key in nested dict, auto-typing."""
    parts = key.split(".")
    node = data
    for p in parts[:-1]:
        if p not in node or not isinstance(node[p], dict):
            node[p] = {}
        node = node[p]
    # Auto-type: try int, then bool, fallback to str
    val: str | int | bool = value
    try:
        val = int(value)
    except ValueError:
        if value.lower() in ("true", "false"):
            val = value.lower() == "true"
    node[parts[-1]] = val


def _mask(value: str, key: str) -> str:
    """Mask secret values for display."""
    if key in SECRET_KEYS and value and len(value) > 8:
        return value[:4] + "****" + value[-4:]
    return value


def _flatten(data: dict, prefix: str = "") -> list[tuple[str, str]]:
    """Flatten nested dict to [(key, value), ...] pairs."""
    result: list[tuple[str, str]] = []
    for k, v in data.items():
        full_key = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict):
            result.extend(_flatten(v, full_key))
        elif isinstance(v, list):
            result.append((full_key, str(v)))
        else:
            result.append((full_key, str(v)))
    return result


@click.group("config")
def config_group() -> None:
    """Manage DeepCraft configuration."""


@config_group.command("init")
def init_cmd() -> None:
    """Generate default config file at ~/.deepcraft/config.yaml."""
    if CONFIG_FILE.exists():
        click.echo(f"Config already exists at {CONFIG_FILE}")
        return
    _save_yaml(CONFIG_FILE, DEFAULT_CONFIG)
    click.echo(f"Created {CONFIG_FILE}")
    click.echo("Edit it to set your DEEPSEEK_API_KEY.")


@config_group.command("list")
def list_cmd() -> None:
    """Show all configuration values (secrets masked)."""
    path = _resolve_file()
    if not path:
        click.echo("No config file found. Run 'deepcraft config init' to create one.")
        return

    data = _load_yaml(path)
    if not data:
        click.echo(f"Empty config: {path}")
        return

    click.echo(f"Config: {path}")
    click.echo("─" * 50)
    for k, v in _flatten(data):
        display = _mask(v, k)
        click.echo(f"  {k} = {display}")

    # Also show env var overrides if set
    env_overrides = [
        ("DEEPSEEK_API_KEY", os.getenv("DEEPSEEK_API_KEY")),
        ("DEEPSEEK_MODEL", os.getenv("DEEPSEEK_MODEL")),
    ]
    active = [(k, v) for k, v in env_overrides if v]
    if active:
        click.echo("\n  ⚡ Active env overrides (take priority):")
        for k, v in active:
            click.echo(f"    {k} = {_mask(v, k)}")


@config_group.command("get")
@click.argument("key")
def get_cmd(key: str) -> None:
    """Get a single config value. e.g. deepseek.model"""
    path = _resolve_file()
    if not path:
        click.echo("No config file found. Run 'deepcraft config init' first.")
        return
    data = _load_yaml(path)
    value = _dot_get(data, key)
    if not value:
        click.echo(f"Key '{key}' not found.")
        return
    click.echo(_mask(value, key))


@config_group.command("set")
@click.argument("key")
@click.argument("value")
def set_cmd(key: str, value: str) -> None:
    """Set a config value. Writes to ~/.deepcraft/config.yaml. e.g. deepseek.model deepseek-chat"""
    data = _load_yaml(CONFIG_FILE)
    _dot_set(data, key, value)
    _save_yaml(CONFIG_FILE, data)
    click.echo(f"Set {key} = {_mask(value, key)}")
    click.echo(f"Written to {CONFIG_FILE}")
