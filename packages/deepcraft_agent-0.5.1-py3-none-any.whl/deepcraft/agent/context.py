"""Context and memory management — conversation history, compression, system prompt."""

from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING

from deepcraft.agent.types import ChatMessage, Role

if TYPE_CHECKING:
    from deepcraft.agent.llm import DeepSeekLLM

# Approximate tokens per character (rough estimate for mixed Chinese/English)
TOKENS_PER_CHAR = 0.4
MAX_CONTEXT_TOKENS = 100_000  # Leave headroom below 128K
COMPRESS_THRESHOLD = 0.8  # Compress at 80% capacity

# How many recent turns to keep verbatim (1 turn = user + assistant + tools)
KEEP_TURNS_VERBATIM = 5

# Tool results longer than this get truncated
TOOL_RESULT_MAX_CHARS = 500

SYSTEM_PROMPT = """You are DeepCraft, an AI coding agent powered by DeepSeek.

Your capabilities:
- Read, write, and search files in the project workspace
- Execute shell commands via terminal
- Manage git repositories
- Analyze code, find bugs, and suggest fixes

Guidelines:
- Be concise and direct. No fluff.
- When you need to see file contents, use read_file.
- When you need to create/modify files, use write_file.
- When you need to run commands, use terminal.
- Think step by step: understand the problem first, then act.
- If a tool fails, analyze the error and try a different approach."""


COMPRESSION_PROMPT = """Summarize the following conversation fragment. Keep it concise.
Preserve: user goals/decisions, key facts discovered, errors encountered and their fixes.
Omit: redundant tool output, repeated attempts, boilerplate.
Respond with the summary only, no preamble."""


class CompressionStrategy(str, Enum):
    """Compression strategy for context management."""

    AUTO = "auto"  # LLM-powered summary when threshold hit (default)
    AGGRESSIVE = "aggressive"  # Truncate aggressively, no LLM call
    OFF = "off"  # Never compress (may hit token limits)


class ContextManager:
    """Manages conversation context: messages, token counting, compression."""

    def __init__(
        self,
        system_prompt: str | None = None,
        strategy: CompressionStrategy = CompressionStrategy.AUTO,
        llm: DeepSeekLLM | None = None,
    ) -> None:
        self._messages: list[ChatMessage] = []
        self._system_prompt = system_prompt or SYSTEM_PROMPT
        self._strategy = strategy
        self._llm = llm
        self._compression_count = 0
        # Add system message
        self._messages.append(ChatMessage(role="system", content=self._system_prompt))

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def strategy(self) -> CompressionStrategy:
        return self._strategy

    @strategy.setter
    def strategy(self, value: CompressionStrategy) -> None:
        self._strategy = value

    @property
    def token_count(self) -> int:
        """Estimate token count of all messages."""
        total = 0
        for msg in self._messages:
            if msg.content:
                total += int(len(msg.content) * TOKENS_PER_CHAR)
            if msg.tool_calls:
                total += int(len(str(msg.tool_calls)) * TOKENS_PER_CHAR)
        return total

    @property
    def compression_count(self) -> int:
        """Number of compressions performed this session."""
        return self._compression_count

    # ------------------------------------------------------------------
    # Message management
    # ------------------------------------------------------------------

    def add_message(
        self,
        role: Role | str,
        content: str | None = None,
        tool_call_id: str | None = None,
        name: str | None = None,
    ) -> None:
        """Add a message to the conversation."""
        msg = ChatMessage(
            role=role.value if isinstance(role, Role) else role,
            content=content,
            tool_call_id=tool_call_id,
            name=name,
        )
        self._messages.append(msg)

        # Schedule compression check (runs in the event loop if available)
        if self._strategy != CompressionStrategy.OFF:
            threshold = COMPRESS_THRESHOLD if self._strategy == CompressionStrategy.AUTO else 0.6
            if self.token_count > int(MAX_CONTEXT_TOKENS * threshold):
                self._check_compress_sync()

    def get_messages(self) -> list[ChatMessage]:
        """Get all messages for LLM context."""
        return list(self._messages)

    def reset(self) -> None:
        """Reset conversation, keeping only system prompt."""
        self._messages = [ChatMessage(role="system", content=self._system_prompt)]

    def __len__(self) -> int:
        return len(self._messages)

    # ------------------------------------------------------------------
    # Compression
    # ------------------------------------------------------------------

    def _check_compress_sync(self) -> None:
        """Synchronous compression entry point. Detects event loop context."""
        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            # No running loop — use sync simple compression
            self._compress_sync()
            return

        if self._strategy == CompressionStrategy.AGGRESSIVE or self._llm is None:
            self._compress_sync()
        else:
            # Schedule async compression
            loop.create_task(self._compress_async())

    def _compress_sync(self) -> None:
        """Synchronous compression — simple strategy only (no LLM)."""
        self._compression_count += 1

        keep_from = self._find_keep_index()
        old_messages = self._messages[1:keep_from]
        if len(old_messages) <= 3:
            return

        summary = self._build_simple_summary(old_messages)
        self._messages = [
            self._messages[0],  # system prompt
            ChatMessage(role="user", content=f"[Compressed history]\n{summary}"),
        ] + self._messages[keep_from:]

    async def _compress_async(self) -> None:
        """Async compression — uses LLM for summarization."""
        self._compression_count += 1

        keep_from = self._find_keep_index()
        old_messages = self._messages[1:keep_from]
        if len(old_messages) <= 3:
            return

        summary = await self._build_llm_summary(old_messages)
        self._messages = [
            self._messages[0],  # system prompt
            ChatMessage(role="user", content=f"[Compressed history]\n{summary}"),
        ] + self._messages[keep_from:]

    def _find_keep_index(self) -> int:
        """Find the index from which messages should be kept verbatim.

        Keeps the last KEEP_TURNS_VERBATIM turns.
        """
        keep_from = len(self._messages)
        turns_found = 0

        for i in range(len(self._messages) - 1, 0, -1):
            msg = self._messages[i]
            if msg.role == "user":
                turns_found += 1
            if turns_found >= KEEP_TURNS_VERBATIM:
                keep_from = i
                break
        return keep_from

    def _build_simple_summary(self, messages: list[ChatMessage]) -> str:
        """Build a simple truncated summary without LLM."""
        parts: list[str] = []
        for msg in messages:
            role = msg.role
            content = msg.content or ""
            if role == "user":
                parts.append(f"User: {content[:200]}")
            elif role == "assistant" and content:
                parts.append(f"Assistant: {content[:200]}")
            elif role == "tool":
                truncated = content[:TOOL_RESULT_MAX_CHARS]
                suffix = "…" if len(content) > TOOL_RESULT_MAX_CHARS else ""
                parts.append(f"Tool({msg.tool_call_id}): {truncated}{suffix}")

        return "\n".join(parts[-30:])

    async def _build_llm_summary(self, messages: list[ChatMessage]) -> str:
        """Use LLM to summarize the old messages."""
        text = self._build_simple_summary(messages)
        if len(text) < 200:
            return text

        prompt = f"{COMPRESSION_PROMPT}\n\n---\n{text}"

        try:
            assert self._llm is not None
            result = await self._llm.complete(prompt, max_tokens=500)
            return result.strip() or text[:500]
        except Exception:
            # Fall back to simple summary
            return self._build_simple_summary(messages)

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def export(self, session_title: str = "DeepCraft Session") -> str:
        """Export conversation as Markdown.

        Returns:
            Markdown string of the full conversation.
        """
        lines = [f"# {session_title}", ""]
        for msg in self._messages:
            if msg.role == "system":
                continue
            role_label = msg.role.upper()
            content = msg.content or ""
            if msg.tool_call_id:
                role_label = f"TOOL [{msg.tool_call_id}]"
            lines.append(f"**{role_label}**: {content}")
            lines.append("")
        return "\n".join(lines)

    def export_json(self) -> list[dict[str, object]]:
        """Export conversation as JSON-serializable list.

        Returns:
            List of message dicts with role, content, tool_call_id.
        """
        result: list[dict[str, object]] = []
        for msg in self._messages:
            entry: dict[str, object] = {"role": msg.role}
            if msg.content:
                entry["content"] = msg.content
            if msg.tool_call_id:
                entry["tool_call_id"] = msg.tool_call_id
            if msg.tool_calls:
                entry["tool_calls"] = msg.tool_calls
            result.append(entry)
        return result
