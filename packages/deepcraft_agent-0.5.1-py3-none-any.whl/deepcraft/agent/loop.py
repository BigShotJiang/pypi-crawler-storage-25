"""Agent main loop — ReAct pattern with safety guards."""

from __future__ import annotations

import json
from typing import Any

from rich.console import Console

from deepcraft.agent.context import ContextManager
from deepcraft.agent.corrector import SelfCorrector
from deepcraft.agent.llm import DeepSeekLLM
from deepcraft.agent.modes import AgentMode, ModeSelector
from deepcraft.agent.planner import Planner
from deepcraft.agent.subagent import Delegator, SubTask
from deepcraft.agent.tools.base import ToolRegistry
from deepcraft.agent.types import (
    ChatMessage,
    Role,
)
from deepcraft.agent.types import (
    ToolResult as TypedToolResult,
)
from deepcraft.config import MAX_TURNS

console = Console()


class Agent:
    """ReAct agent with DeepSeek backend."""

    def __init__(
        self,
        llm: DeepSeekLLM | None = None,
        tools: ToolRegistry | None = None,
        context: ContextManager | None = None,
    ) -> None:
        self.llm = llm or DeepSeekLLM()
        self.tools = tools or ToolRegistry()
        self.ctx = context or ContextManager()
        self._turn_count = 0
        self._recent_actions: list[str] = []

    async def run(self, user_input: str) -> str:
        """Run the agent loop for a user input. Returns final response."""
        self._turn_count = 0
        self._recent_actions = []
        self.ctx.add_message(Role.USER, user_input)

        while self._turn_count < MAX_TURNS:
            self._turn_count += 1

            # --- Get LLM response (streaming) ---
            tool_calls_buffer: dict[int, dict[str, Any]] = {}
            content_parts: list[str] = []

            tool_defs = self.tools.list_definitions()
            messages = self.ctx.get_messages()

            async for chunk in self.llm.chat(messages, tools=tool_defs or None):
                if chunk.delta is None:
                    continue

                # Collect streaming content
                if chunk.delta.content:
                    content_parts.append(chunk.delta.content)
                    console.print(chunk.delta.content, end="", highlight=False)

                # Collect tool calls — use index from stream chunk, not buffer length
                if chunk.delta.tool_calls:
                    for tc in chunk.delta.tool_calls:
                        # DeepSeek streaming sends "index" in every tool_call chunk
                        tc_index = tc.get("index")
                        if tc_index is None:
                            tc_index = len(tool_calls_buffer)
                        if tc.get("id"):
                            tool_calls_buffer[tc_index] = dict(tc)
                        elif tc_index in tool_calls_buffer:
                            # Append streaming arguments fragment
                            tc_args = tc.get("function", {}).get("arguments", "")
                            tool_calls_buffer[tc_index]["function"]["arguments"] += tc_args

                if chunk.finish_reason:
                    break

            console.print()  # newline after streaming

            response_text = "".join(content_parts)

            # --- No tool calls: return final response ---
            if not tool_calls_buffer:
                self.ctx.add_message(Role.ASSISTANT, response_text)
                return response_text

            # --- Execute tool calls ---
            tool_results: list[TypedToolResult] = []

            for tc in tool_calls_buffer.values():
                tool_name = tc["function"]["name"]
                tool_id = tc["id"]

                # Parse arguments
                args_str = tc["function"]["arguments"]
                try:
                    arguments = json.loads(args_str) if args_str else {}
                except json.JSONDecodeError:
                    arguments = {}

                # Safety: loop detection
                action_key = f"{tool_name}:{json.dumps(arguments, sort_keys=True)}"
                self._recent_actions.append(action_key)
                if self._recent_actions[-3:].count(action_key) == 3:
                    # 3 consecutive identical calls → force stop
                    summary = "⚠️ Detected repetitive tool calls. Stopping to avoid loop."
                    self.ctx.add_message(Role.ASSISTANT, summary)
                    return summary
                # Keep only last 10
                self._recent_actions = self._recent_actions[-10:]

                # Execute
                args_str = json.dumps(arguments, ensure_ascii=False)
                console.print(f"  🔧 {tool_name}({args_str})", style="dim")
                result = await self.tools.execute(tool_name, arguments)
                tool_results.append(TypedToolResult(
                    tool_call_id=tool_id,
                    content=result.content,
                    is_error=result.is_error,
                ))

            # --- Add assistant message with tool calls ---
            assistant_msg = ChatMessage(
                role="assistant",
                content=response_text or None,
                tool_calls=[
                    {
                        "id": tc["id"],
                        "type": "function",
                        "function": {
                            "name": tc["function"]["name"],
                            "arguments": tc["function"]["arguments"],
                        },
                    }
                    for tc in tool_calls_buffer.values()
                ],
            )
            self.ctx._messages.append(assistant_msg)

            # --- Add tool results ---
            for tr in tool_results:
                self.ctx.add_message(
                    Role.TOOL,
                    tr.content,
                    tool_call_id=tr.tool_call_id,
                )

            # Continue loop — LLM will process tool results

        # Max turns reached
        summary = f"\n⚠️ Reached max turns ({MAX_TURNS}). Summarizing based on current state."
        return summary

    async def close(self) -> None:
        await self.llm.close()

    # ------------------------------------------------------------------
    # Advanced modes
    # ------------------------------------------------------------------

    async def run_with_mode(
        self, user_input: str, mode: AgentMode = AgentMode.AUTO
    ) -> str:
        """Run the agent loop, auto-selecting or using a specific mode.

        Args:
            user_input: The user's message.
            mode: AgentMode to use (AUTO = auto-detect).

        Returns:
            Final response text.
        """
        selected = ModeSelector.select(user_input, prefer=mode)

        console.print(f"  🧠 模式: {selected.value}", style="cyan")

        if selected == AgentMode.PLAN_EXECUTE:
            return await self._run_plan_execute(user_input)
        elif selected == AgentMode.SUBAGENT:
            return await self._run_subagent(user_input)
        else:
            return await self.run(user_input)

    async def _run_plan_execute(self, user_input: str) -> str:
        """Plan-and-Execute: generate a plan, then execute step by step."""
        self._turn_count = 0
        self.ctx.add_message(Role.USER, user_input)

        # Step 1: Generate plan
        planner = Planner(self.llm)
        plan = await planner.generate_plan(user_input, self.tools)
        console.print(f"  📋 计划: {plan.goal}")
        for i, s in enumerate(plan.steps, 1):
            console.print(f"     {i}. {s.description}", style="dim")

        # Step 2: Execute each step
        corrector = SelfCorrector(llm=self.llm)
        try:
            while not plan.completed and self._turn_count < MAX_TURNS:
                self._turn_count += 1
                next_s = plan.next_step()
                if next_s is None:
                    break

                from deepcraft.agent.planner import StepStatus
                next_s.status = StepStatus.RUNNING

                # Pure reasoning step (no tool)
                if not next_s.tool_name:
                    next_s.status = StepStatus.DONE
                    next_s.result = next_s.description
                    continue

                # Execute tool
                try:
                    result = await self.tools.execute(next_s.tool_name, **next_s.tool_args)
                    if result.is_error:
                        # Try self-correction
                        correction = await corrector.analyze_error(
                            next_s.tool_name, next_s.tool_args, result.content
                        )
                        if correction.retry and correction.corrected_args:
                            desc = correction.fix_description
                            console.print(f"     🔄 纠错: {desc}", style="yellow")
                            result = await self.tools.execute(
                                next_s.tool_name, **correction.corrected_args
                            )

                        if result.is_error:
                            next_s.status = StepStatus.FAILED
                            next_s.error = result.content
                        else:
                            next_s.status = StepStatus.DONE
                            next_s.result = result.content
                    else:
                        next_s.status = StepStatus.DONE
                        next_s.result = result.content
                except Exception as e:
                    next_s.status = StepStatus.FAILED
                    next_s.error = str(e)

            # Step 3: Synthesize results
            plan_context = plan.format_for_context()
            self.ctx.add_message(Role.USER, f"执行计划完成。结果：\n{plan_context}\n请总结。")

            # Final summary
            return await self.run("总结以上执行结果")

        finally:
            await corrector.close()
            await planner.close()

    async def _run_subagent(self, user_input: str) -> str:
        """Sub-agent mode: decompose and delegate to parallel sub-agents."""
        self._turn_count = 0
        self.ctx.add_message(Role.USER, user_input)

        # Step 1: Use planner to generate subtasks
        planner = Planner(self.llm)
        plan = await planner.generate_plan(user_input, self.tools)

        # Step 2: Convert plan steps to subtasks
        subtasks = [
            SubTask(
                description=step.description,
                context=f"目标: {plan.goal}",
            )
            for step in plan.steps
        ]

        console.print(f"  🚀 委派 {len(subtasks)} 个子任务...", style="cyan")

        # Step 3: Execute in parallel
        delegator = Delegator(llm=self.llm, tools=self.tools)
        try:
            results = await delegator.delegate(subtasks)

            # Step 4: Synthesize
            summary_parts = ["## 子代理执行结果\n"]
            for r in results:
                status = "✅" if r.success else "❌"
                summary_parts.append(f"{status} **{r.task}**\n{r.output[:500]}\n")

            summary = "\n".join(summary_parts)
            self.ctx.add_message(Role.USER, f"子代理执行完成：\n{summary}\n请总结。")

            return await self.run("总结以上子代理的执行结果")

        finally:
            await delegator.close()
            await planner.close()
