"""Terminal execution tool with safety constraints."""

from __future__ import annotations

import asyncio

from deepcraft.agent.tools.base import BaseTool, ToolResult
from deepcraft.config import WORKDIR

# Commands that require user confirmation
DANGEROUS_PATTERNS = [
    "rm -rf", "rm -r", "sudo ", "chmod 777", ":(){ :|:& };:",  # fork bomb
    "mkfs.", "dd if=", "> /dev/sda",
]


class TerminalTool(BaseTool):
    name = "terminal"
    description = (
        "Execute a shell command. Returns stdout and exit code. "
        "Commands run in workdir. Timeout: 120s."
    )

    parameters = {
        "command": {
            "type": "string",
            "description": "The shell command to execute",
        },
        "timeout": {
            "type": "integer",
            "description": "Timeout in seconds (default: 120, max: 300)",
        },
    }

    async def execute(self, command: str, timeout: int = 120) -> ToolResult:  # type: ignore[override]
        # Safety check
        cmd_lower = command.lower()
        for pattern in DANGEROUS_PATTERNS:
            if pattern.lower() in cmd_lower:
                return ToolResult(
                    content=f"BLOCKED: command matches dangerous pattern '{pattern}'. "
                    f"Add '--force' flag to bypass.",
                    is_error=True,
                )

        # Handle --force bypass
        if command.strip().endswith("--force"):
            command = command.strip()[: -len("--force")].strip()

        timeout = min(max(timeout, 1), 300)

        try:
            process = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(WORKDIR),
            )

            stdout, stderr = await asyncio.wait_for(
                process.communicate(), timeout=timeout
            )

            output = stdout.decode("utf-8", errors="replace")
            if stderr:
                err_output = stderr.decode("utf-8", errors="replace")
                if err_output.strip():
                    output += "\n[stderr]\n" + err_output

            if process.returncode != 0:
                output += f"\n[exit code: {process.returncode}]"

            # Truncate if too long
            if len(output) > 50000:
                output = output[:50000] + "\n... [truncated]"

            return ToolResult(content=output.strip() or "(no output)")

        except TimeoutError:
            return ToolResult(
                content=f"Command timed out after {timeout}s", is_error=True
            )
        except Exception as e:
            return ToolResult(content=f"Error: {e}", is_error=True)
