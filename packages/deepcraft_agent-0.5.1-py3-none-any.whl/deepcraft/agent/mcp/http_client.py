"""MCP HTTP/SSE transport — connects to remote MCP servers over HTTP.

Implements the MCP Streamable HTTP transport (2024-11-05+):
- POST to /message for JSON-RPC requests
- Optional GET to /sse for server→client notifications
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

import httpx


class MCPProtocolError(Exception):
    """Raised on MCP protocol errors (duplicated here to avoid circular imports)."""


logger = logging.getLogger(__name__)

DEFAULT_SSE_READ_TIMEOUT = 30.0


class HttpMCPClient:
    """MCP client that communicates with a remote server via HTTP + optional SSE.

    Usage::

        client = HttpMCPClient("https://my-mcp-server.example.com")
        await client.connect()
        tools = await client.list_tools()
        result = await client.call_tool("search", {"query": "hello"})
        await client.close()
    """

    def __init__(
        self,
        base_url: str,
        *,
        protocol_version: str = "2024-11-05",
        client_name: str = "deepcraft-mcp-client",
        client_version: str = "0.2.0",
        headers: dict[str, str] | None = None,
        sse_read_timeout: float = DEFAULT_SSE_READ_TIMEOUT,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._protocol_version = protocol_version
        self._client_name = client_name
        self._client_version = client_version
        self._extra_headers = headers or {}

        self._http: httpx.AsyncClient | None = None
        self._sse_task: asyncio.Task[None] | None = None
        self._sse_read_timeout = sse_read_timeout
        self._next_id = 1
        self._pending: dict[int, asyncio.Future[dict[str, Any]]] = {}
        self._pending_guard = asyncio.Lock()

    @property
    def connected(self) -> bool:
        return self._http is not None

    async def connect(self) -> None:
        """Open HTTP client and perform MCP initialize handshake."""
        if self._http is not None:
            raise RuntimeError("HTTP MCP client already connected")

        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
            **self._extra_headers,
        }
        self._http = httpx.AsyncClient(
            base_url=self._base_url,
            headers=headers,
            timeout=httpx.Timeout(30.0, connect=10.0),
        )

        # Start SSE listener if server supports it
        self._sse_task = asyncio.create_task(self._sse_loop())

        try:
            init_params: dict[str, Any] = {
                "protocolVersion": self._protocol_version,
                "capabilities": {},
                "clientInfo": {
                    "name": self._client_name,
                    "version": self._client_version,
                },
            }
            await self._rpc_request("initialize", init_params)
            await self._rpc_notify("notifications/initialized", {})
        except BaseException:
            await self.close()
            raise

    async def list_tools(self, *, cursor: str | None = None) -> dict[str, Any]:
        params: dict[str, Any] = {}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._rpc_request("tools/list", params)

    async def call_tool(
        self, name: str, arguments: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"name": name}
        if arguments:
            params["arguments"] = arguments
        return await self._rpc_request("tools/call", params)

    async def close(self) -> None:
        if self._sse_task is not None:
            self._sse_task.cancel()
            with __import__("contextlib").suppress(asyncio.CancelledError):
                await self._sse_task
            self._sse_task = None

        await self._fail_all_pending(ConnectionError("HTTP MCP 连接已关闭"))

        if self._http is not None:
            await self._http.aclose()
            self._http = None

    async def _sse_loop(self) -> None:
        """Listen on /sse endpoint for server→client notifications."""
        assert self._http is not None
        try:
            async with self._http.stream("GET", "/sse") as response:
                if response.status_code == 404:
                    # SSE not supported by this server — that's OK
                    logger.debug("MCP server does not support SSE (404)")
                    return
                response.raise_for_status()
                async for line in response.aiter_lines():
                    if not line:
                        continue
                    if line.startswith("data: "):
                        data = line[6:]
                        try:
                            msg = json.loads(data)
                        except json.JSONDecodeError:
                            continue
                        if "id" in msg:
                            await self._dispatch_response(msg)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.debug("SSE loop ended", exc_info=True)
            await self._fail_all_pending(ConnectionError("SSE 连接断开"))

    async def _dispatch_response(self, msg: dict[str, Any]) -> None:
        req_id = msg.get("id")
        if not isinstance(req_id, int):
            return
        async with self._pending_guard:
            fut = self._pending.pop(req_id, None)
        if fut is None or fut.done():
            return
        fut.set_result(msg)

    async def _rpc_request(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        if self._http is None:
            raise RuntimeError("HTTP MCP 未连接")

        loop = asyncio.get_running_loop()
        fut: asyncio.Future[dict[str, Any]] = loop.create_future()

        req_id = self._next_id
        self._next_id += 1
        async with self._pending_guard:
            self._pending[req_id] = fut

        envelope: dict[str, Any] = {
            "jsonrpc": "2.0",
            "id": req_id,
            "method": method,
            "params": params,
        }

        try:
            response = await self._http.post("/message", json=envelope)
            response.raise_for_status()
            msg = response.json()
        except Exception:
            async with self._pending_guard:
                self._pending.pop(req_id, None)
            if not fut.done():
                fut.cancel()
            raise

        # If we already got the response via SSE, use that; otherwise process now
        if not fut.done():
            fut.set_result(msg)

        result = await fut
        if "error" in result:
            raise MCPProtocolError(result["error"])
        r = result.get("result")
        return r if isinstance(r, dict) else {}

    async def _rpc_notify(self, method: str, params: dict[str, Any]) -> None:
        if self._http is None:
            raise RuntimeError("HTTP MCP 未连接")

        envelope: dict[str, Any] = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
        }
        try:
            response = await self._http.post("/message", json=envelope)
            response.raise_for_status()
        except Exception:
            logger.debug("HTTP MCP notification failed", exc_info=True)

    async def _fail_all_pending(self, exc: BaseException) -> None:
        async with self._pending_guard:
            for f in self._pending.values():
                if not f.done():
                    f.set_exception(exc)
            self._pending.clear()
