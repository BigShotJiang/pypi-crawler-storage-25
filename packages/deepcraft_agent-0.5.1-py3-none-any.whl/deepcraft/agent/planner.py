"""Plan-and-Execute mode — generate a plan, then execute step by step."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from rich.console import Console

from deepcraft.agent.llm import DeepSeekLLM
from deepcraft.agent.tools.base import ToolRegistry
from deepcraft.agent.types import ChatMessage

console = Console()


class StepStatus(StrEnum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class PlanStep:
    """A single step in an execution plan."""

    description: str
    tool_name: str | None = None  # None = LLM reasoning step
    tool_args: dict[str, Any] = field(default_factory=dict)
    status: StepStatus = StepStatus.PENDING
    result: str = ""
    error: str = ""


@dataclass
class Plan:
    """An execution plan composed of ordered steps."""

    goal: str
    steps: list[PlanStep] = field(default_factory=list)

    @property
    def completed(self) -> bool:
        return all(s.status in (StepStatus.DONE, StepStatus.SKIPPED) for s in self.steps)

    @property
    def failed(self) -> bool:
        return any(s.status == StepStatus.FAILED for s in self.steps)

    def next_step(self) -> PlanStep | None:
        """Get the next pending step."""
        for step in self.steps:
            if step.status == StepStatus.PENDING:
                return step
        return None

    def format_for_context(self) -> str:
        """Format plan as context for LLM."""
        lines = [f"## 执行计划: {self.goal}\n"]
        for i, step in enumerate(self.steps, 1):
            icon = {"pending": "⏳", "running": "▶️", "done": "✅", "failed": "❌", "skipped": "⏭️"}
            lines.append(f"{i}. {icon.get(step.status, '')} {step.description}")
            if step.result and step.status == StepStatus.DONE:
                lines.append(f"   → {step.result[:200]}")
            if step.error:
                lines.append(f"   ⚠️ {step.error[:200]}")
        return "\n".join(lines)


PLANNER_PROMPT = """你是一个任务规划专家。给定用户的复杂任务，将它拆解为有序的执行步骤。

规则：
1. 步骤数控制在 3-8 个
2. 每个步骤描述要具体、可执行
3. 步骤应按依赖关系排序
4. 优先使用已有信息，避免不必要的工具调用

可用工具：
{tools}

请输出 JSON 格式的执行计划：
```json
{{
  "goal": "任务目标的一句话概述",
  "steps": [
    {{
      "description": "步骤描述",
      "tool_name": "工具名或 null（纯推理步骤）",
      "tool_args": {{"参数名": "参数值"}} 或 {{}}
    }}
  ]
}}
```"""


class Planner:
    """Generate and manage task execution plans."""

    def __init__(self, llm: DeepSeekLLM | None = None) -> None:
        self.llm = llm or DeepSeekLLM()

    async def generate_plan(
        self, goal: str, tools: ToolRegistry, context: str = ""
    ) -> Plan:
        """Generate an execution plan for a complex task.

        Args:
            goal: The user's task description.
            tools: Available tools for planning.
            context: Additional context (previous results, etc.)

        Returns:
            A Plan with ordered steps.
        """
        # Build tool list for prompt
        tool_list = "\n".join(
            f"- {t.name}: {t.description}" for t in tools.list_definitions()
        )

        prompt = PLANNER_PROMPT.format(tools=tool_list)
        if context:
            prompt += f"\n\n已有上下文信息：\n{context}"

        messages = [
            ChatMessage(role="system", content=prompt),
            ChatMessage(role="user", content=f"请为以下任务生成执行计划：\n{goal}"),
        ]

        response_text = ""
        async for chunk in self.llm.chat(messages):
            if chunk.delta and chunk.delta.content:
                response_text += chunk.delta.content

        # Extract JSON from response
        plan_data = self._extract_json(response_text)
        if not plan_data:
            # Fallback: single-step plan
            return Plan(
                goal=goal,
                steps=[PlanStep(description=goal)],
            )

        steps = []
        for step_data in plan_data.get("steps", []):
            steps.append(PlanStep(
                description=step_data.get("description", ""),
                tool_name=step_data.get("tool_name") or None,
                tool_args=step_data.get("tool_args", {}),
            ))

        if not steps:
            steps = [PlanStep(description=goal)]

        return Plan(goal=plan_data.get("goal", goal), steps=steps)

    @staticmethod
    def _extract_json(text: str) -> dict[str, Any] | None:
        """Extract JSON from LLM response (may have markdown fences)."""
        # Try direct parse
        try:
            data = json.loads(text)
            if isinstance(data, dict):
                return data
        except json.JSONDecodeError:
            pass

        # Try extracting from code fence
        import re
        match = re.search(r"```(?:json)?\s*\n(.*?)\n```", text, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(1))
                if isinstance(data, dict):
                    return data
            except json.JSONDecodeError:
                pass

        return None

    async def close(self) -> None:
        await self.llm.close()
