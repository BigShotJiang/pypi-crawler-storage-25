---
name: python-style
description: Python 代码风格与最佳实践指南（PEP 8 + 现代 Python）
triggers: [python style, pep8, python 规范, 代码风格, type hints, 类型标注, pythonic]
allowed-tools: [read_file, write_file, search_files]
---

# Python 代码风格规范

## 类型标注（必须）

- 所有公开函数必须有类型标注
- 使用 `X | None` 而非 `Optional[X]`（Python 3.10+）
- 使用 `list[X]` 而非 `List[X]`（Python 3.9+）
- 使用 `dict[K, V]` 而非 `Dict[K, V]`
- `from __future__ import annotations` 放在文件第一行（import 之前）

## 命名规范

| 类型 | 规则 | 示例 |
|------|------|------|
| 模块 | 小写+下划线 | `file_utils.py` |
| 类 | CapWords | `ToolRegistry` |
| 函数/方法 | 小写+下划线 | `read_file()` |
| 变量 | 小写+下划线 | `max_turns` |
| 常量 | 大写+下划线 | `MAX_TURNS` |
| 私有成员 | 前缀单下划线 | `_pending` |
| 内部私有 | 前缀双下划线 | `__internal` |

## 代码组织

- 文件头：`"""模块文档字符串"""`  → `from __future__ import annotations` → 标准库 import → 第三方 import → 本地 import
- 类内顺序：`__init__` → 公共方法 → 私有方法（`_` 前缀）→ dunder 方法
- 一行不超过 100 字符（ruff line-length = 100）
- 函数体不超过 50 行，超过应拆分

## Pythonic 写法

```python
# ❌ 不 Pythonic
if len(items) == 0:
    return None
for i in range(len(items)):
    item = items[i]

# ✅ Pythonic
if not items:
    return None
for i, item in enumerate(items):
    ...
```

- 用 `with` 管理资源（文件、锁、连接）
- 用 `dataclass` 替代手写 `__init__`
- 用 `pathlib.Path` 替代 `os.path`
- 用 f-string 替代 `.format()` 和 `%`
- 用 `contextlib.suppress` 替代 `try: ... except: pass`

## 错误处理

- 捕获具体异常，不要裸 `except:` 或 `except Exception:`
- 异常消息包含上下文（哪个操作失败了、为什么）
- 不要吞异常：`except: pass` 必须有注释说明原因
- 使用自定义异常类，而非通用 `RuntimeError`

## 禁止事项

- `import *`（除了 `__all__` 定义的包内导入）
- 可变默认参数：`def f(x=[])`
- 裸 `assert` 用于业务逻辑（可能被 `-O` 跳过）
- `from deepcraft.config import WORKDIR` 然后在模块级使用——应用函数参数传入
