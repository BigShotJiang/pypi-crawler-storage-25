---
name: git-workflow
description: Git 工作流规范：分支策略、提交信息、PR 流程
triggers: [git workflow, git 工作流, commit, 提交信息, branch, 分支, PR, pull request]
allowed-tools: [git]
---

# Git 工作流规范

## 分支策略

```
main ──── 生产就绪，只通过 PR 合并
  │
  ├─ feat/xxx ── 新功能分支，从 main 拉出
  ├─ fix/xxx  ── Bug 修复分支
  ├─ docs/xxx ── 文档更新分支
  └─ refactor/xxx ── 重构分支（不改功能）
```

- `main` 分支永远可部署
- 功能分支命名：`feat/短描述`（如 `feat/mcp-client`）
- 修复分支命名：`fix/短描述`（如 `fix/tool-call-streaming`）
- 分支生命周期：合并后立即删除

## 提交信息格式

```
<type>(<scope>): <简短描述>

<详细说明（可选，72 字符换行）>

<关联 issue（可选）>
```

### Type 类型

| type | 用途 |
|------|------|
| `feat` | 新功能 |
| `fix` | Bug 修复 |
| `docs` | 文档 |
| `style` | 代码格式（不改变逻辑）|
| `refactor` | 重构（改结构不改功能）|
| `test` | 测试 |
| `chore` | 构建/工具链 |
| `ci` | CI/CD 配置 |
| `perf` | 性能优化 |

### 示例

```
feat(mcp): 实现 MCPClient JSON-RPC 2.0 握手

手写 asyncio 子进程通信，支持 initialize/tools/list/tools/call。
零第三方依赖，368 行。

Closes #12
```

## PR 规范

1. **标题**：和 commit 格式一致
2. **描述**：What / Why / How / Testing
3. **检查清单**：
   - [ ] ruff 通过
   - [ ] mypy strict 通过
   - [ ] pytest 通过
   - [ ] 新功能有测试
4. **单 PR 单关注点**：一个 PR 只做一件事

## 常用命令

```bash
# 创建功能分支
git checkout -b feat/my-feature main

# 提交（遵循格式）
git add -A
git commit -m "feat(scope): description"

# 变基到最新 main
git fetch origin main
git rebase origin/main

# 推送
git push origin feat/my-feature
```

## 禁止事项

- ❌ 直接 push 到 main
- ❌ `git push --force` 到共享分支
- ❌ 提交中包含 `.env`、密钥、大文件
- ❌ 一个 commit 包含无关修改
