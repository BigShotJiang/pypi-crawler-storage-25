---
name: testing
description: 测试最佳实践：pytest 用法、fixture、mock、覆盖率目标
triggers: [testing, 测试, pytest, unit test, 单元测试, test coverage, 写测试]
allowed-tools: [read_file, write_file, terminal, search_files]
---

# 测试最佳实践

## 测试金字塔

```
       ╱ E2E ╲      少量，验证关键流程
     ╱ 集成测试 ╲    中等，验证模块间交互
   ╱   单元测试   ╲  大量，验证单个函数/类
```

- 单元测试占 70%，集成测试 20%，E2E 10%
- 新功能必须有对应测试
- Bug 修复必须先写复现测试

## pytest 基础

```python
import pytest
from deepcraft.config import validate

def test_validate_missing_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(config, "DEEPSEEK_API_KEY", "")
    with pytest.raises(RuntimeError, match="DEEPSEEK_API_KEY"):
        validate()
```

### 常用 fixture

```python
# 临时目录
def test_file_ops(tmp_path: Path) -> None:
    (tmp_path / "test.txt").write_text("hello")

# Monkeypatch
def test_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", "/tmp")

# 参数化
@pytest.mark.parametrize("a,b,expected", [
    (1, 2, 3),
    (0, 0, 0),
    (-1, 1, 0),
])
def test_add(a: int, b: int, expected: int) -> None:
    assert add(a, b) == expected
```

## Mock 策略

```python
from unittest.mock import AsyncMock, patch

# Mock 异步函数
async def test_api_call(self) -> None:
    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.return_value.json.return_value = {"choices": [...]}
        result = await call_api()
        assert result is not None

# Mock 模块级常量
def test_config(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("deepcraft.config.MAX_TURNS", 10)
```

- 优先用 `monkeypatch`（pytest 内置）
- 其次用 `unittest.mock.patch`
- Mock 外部依赖（API、数据库），不 mock 自己的代码
- Mock 后要验证调用次数和参数：`mock_post.assert_called_once_with(...)`

## Async 测试

```python
@pytest.mark.asyncio
async def test_async_tool() -> None:
    tool = TerminalTool()
    result = await tool.execute(command="echo hello")
    assert "hello" in result.content
```

- `pyproject.toml` 设 `asyncio_mode = "auto"`
- 测试函数用 `async def`
- 标记 `@pytest.mark.asyncio`

## 测试文件结构

```
tests/
├── conftest.py          # 共享 fixture
├── test_config.py       # 对应 deepcraft/config.py
├── test_types.py        # 对应 deepcraft/agent/types.py
├── test_tools.py        # 对应 deepcraft/agent/tools/
├── test_mcp.py          # 对应 deepcraft/agent/mcp/
└── test_skills.py       # 对应 deepcraft/agent/skills/
```

- 一个源文件对应一个测试文件
- 测试类按被测类分组：`class TestToolRegistry`
- 测试方法名描述行为：`test_execute_unknown_tool_returns_error`

## 覆盖率

- 目标：核心模块 >80%
- 配置：`pytest --cov=deepcraft --cov-report=term`
- CI 中检查：`pytest --cov=deepcraft --cov-fail-under=70`
- 不追求 100%，追求关键路径覆盖

## 命名规范

```python
# ✅ 好的测试名
def test_validate_raises_when_api_key_missing() -> None
def test_search_returns_empty_list_for_no_match() -> None
def test_terminal_blocks_dangerous_command() -> None

# ❌ 不好的测试名
def test1() -> None
def test_validate() -> None
def test_error() -> None
```

- 格式：`test_<被测方法>_<场景>_<预期结果>`
- 读测试名就能知道测什么

## 禁止事项

- ❌ 测试依赖执行顺序（每个测试独立）
- ❌ 测试中有 `sleep()`（用 mock 或 async wait）
- ❌ 测试依赖外部网络（用 mock）
- ❌ 只测 happy path，不测错误情况
