---
name: api-design
description: REST API 设计规范：路由、状态码、错误处理、分页
triggers: [api design, api 设计, REST, endpoint, 接口设计, API 规范, route]
allowed-tools: [read_file, write_file, search_files]
---

# REST API 设计规范

## URL 设计

```
✅ GET    /api/v1/users              # 列表
✅ GET    /api/v1/users/{id}         # 详情
✅ POST   /api/v1/users              # 创建
✅ PUT    /api/v1/users/{id}         # 全量更新
✅ PATCH  /api/v1/users/{id}         # 部分更新
✅ DELETE /api/v1/users/{id}         # 删除
✅ POST   /api/v1/users/{id}/activate  # 动作（动词）
```

- 名词复数（`/users` 不是 `/user`）
- 层级不超过 2 层（`/users/{id}/orders` OK，`/users/{id}/orders/{oid}/items` 太深）
- kebab-case（`/user-profiles` 不是 `/userProfiles`）
- 版本号在 URL 或 Header 中

## 状态码

| 状态码 | 用途 |
|--------|------|
| 200 | 成功（GET, PUT, PATCH）|
| 201 | 创建成功（POST）|
| 204 | 删除成功，无内容返回 |
| 400 | 请求参数错误 |
| 401 | 未认证 |
| 403 | 无权限 |
| 404 | 资源不存在 |
| 409 | 冲突（如重复创建）|
| 422 | 参数校验失败 |
| 429 | 限流 |
| 500 | 服务器内部错误 |

## 响应格式

```json
// 成功
{
  "data": { "id": 1, "name": "Alice" }
}

// 列表 + 分页
{
  "data": [...],
  "pagination": {
    "page": 1,
    "page_size": 20,
    "total": 156,
    "has_next": true
  }
}

// 错误
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "email is required",
    "details": [
      {"field": "email", "reason": "must be a valid email address"}
    ]
  }
}
```

## 分页

- 使用 `page` + `page_size` 或 `offset` + `limit`
- 默认 page_size = 20，最大 100
- 响应中包含 `total` 和 `has_next`

## 过滤 & 排序

```
GET /api/v1/users?status=active&role=admin&sort=-created_at&page=1&page_size=20
```

- 过滤：`field=value`
- 排序：`sort=field`（升序），`sort=-field`（降序）
- 多字段排序：`sort=priority,-created_at`

## 认证

- 使用 `Authorization: Bearer <token>` Header
- Token 有过期时间，支持 refresh
- 不在 URL 中传 token
- 不在响应体中返回 token（仅登录/注册时返回）

## 版本管理

- URL 版本：`/api/v1/...`（简单直观）
- 破坏性变更必须升版本号
- 向后兼容的变更（新增字段、新增端点）不升版本
- 旧版本至少保留 1 个版本周期的过渡期

## 禁止事项

- ❌ GET 请求修改数据
- ❌ 在 URL 中暴露敏感信息
- ❌ 返回裸数组（应包裹在 `{"data": [...]}` 中）
- ❌ 使用 200 + error 字段表示错误
- ❌ 在错误响应中暴露堆栈信息
