"""REPL and single-run entry points for DeepCraft."""

from __future__ import annotations

import asyncio
import shlex

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table

from deepcraft import __version__
from deepcraft.agent.context import CompressionStrategy, ContextManager
from deepcraft.agent.llm import DeepSeekLLM
from deepcraft.agent.loop import Agent
from deepcraft.agent.mcp.client import MCPManager
from deepcraft.agent.modes import AgentMode
from deepcraft.agent.tools.base import ToolRegistry
from deepcraft.agent.tools.file import ReadFileTool, SearchFilesTool, WriteFileTool
from deepcraft.agent.tools.git_tool import GitTool
from deepcraft.agent.tools.terminal import TerminalTool
from deepcraft.agent.types import Role
from deepcraft.config import COMPRESSION_STRATEGY, parse_mcp_servers
from deepcraft.session import SessionRecorder

console = Console()


def _create_agent() -> Agent:
    """Create a fully configured agent with default tools."""
    tools = ToolRegistry()
    tools.register(ReadFileTool())
    tools.register(WriteFileTool())
    tools.register(SearchFilesTool())
    tools.register(TerminalTool())
    tools.register(GitTool())

    llm = DeepSeekLLM()
    ctx = ContextManager(
        llm=llm,
        strategy=CompressionStrategy(COMPRESSION_STRATEGY),
    )
    return Agent(
        llm=llm,
        tools=tools,
        context=ctx,
    )


async def _connect_mcp_servers(agent: Agent, mcp_manager: MCPManager) -> None:
    """Connect all configured MCP servers and register their tools."""
    servers = parse_mcp_servers()
    if not servers:
        return

    console.print("\n[dim]Connecting MCP servers...[/]")
    for srv in servers:
        name = srv["name"]
        try:
            if "url" in srv:
                headers = srv.get("headers")
                await mcp_manager.connect_http_server(name, srv["url"], headers=headers)
                console.print(f"  ✅ [green]{name}[/] (HTTP) connected")
            elif "command" in srv:
                argv = shlex.split(srv["command"])
                await mcp_manager.connect_server(name, argv)
                console.print(f"  ✅ [green]{name}[/] (stdio) connected")
            else:
                console.print(f"  ⚠️  [yellow]{name}[/] — missing command or url")
        except Exception as e:
            console.print(f"  ❌ [red]{name}[/] — {e}")


def run_repl() -> None:
    """Start the interactive REPL loop."""
    console.print(
        Panel.fit(
            f"DeepCraft v{__version__} — DeepSeek-powered AI coding agent\n"
            "Type /help for commands, /quit to exit",
            title="DeepCraft",
            border_style="blue",
        )
    )

    agent = _create_agent()
    mcp_manager = MCPManager(agent.tools)
    current_mode = AgentMode.AUTO
    recorder = SessionRecorder()

    async def repl() -> None:
        nonlocal current_mode

        # Connect MCP servers on startup
        await _connect_mcp_servers(agent, mcp_manager)

        try:
            while True:
                try:
                    user_input = Prompt.ask("\n[bold green]▸[/]")
                except (KeyboardInterrupt, EOFError):
                    console.print("\nGoodbye!")
                    break

                if not user_input.strip():
                    continue

                # Commands
                if user_input.startswith("/"):
                    cmd = user_input[1:].strip().lower()
                    if cmd in ("quit", "exit", "q"):
                        console.print("Goodbye!")
                        break
                    elif cmd == "help":
                        console.print(
                            "Commands:\n"
                            "  /quit, /exit, /q — Exit DeepCraft\n"
                            "  /help — Show this help\n"
                            "  /clear — Clear conversation history\n"
                            "  /status — Show token usage and tool count\n"
                            "  /export md|json [path] — Export conversation\n"
                            "  /record start — Start session recording\n"
                            "  /record stop — Stop session recording\n"
                            "  /record status — Show recording status\n"
                            "  /replay <path> — Replay a recorded session\n"
                            "  /mode [react|plan|sub|auto] — Switch agent mode\n"
                            "  /mcp — List connected MCP servers\n"
                            "  /mcp connect <name> <command|url> — Connect MCP server"
                        )
                    elif cmd == "clear":
                        agent.ctx.reset()
                        console.print("[dim]Conversation cleared.[/]")
                    elif cmd == "status":
                        mcp_count = len(mcp_manager.servers)
                        console.print(
                            f"Mode:   {current_mode.value}\n"
                            f"Tokens: ~{agent.ctx.token_count:,}\n"
                            f"Tools:  {len(agent.tools)} registered"
                            + (f" ({mcp_count} MCP servers)\n" if mcp_count else "\n")
                            + f"Turns:  {agent._turn_count}"
                        )
                    elif cmd == "mode":
                        console.print(f"Current mode: {current_mode.value}")
                    elif cmd == "record" or cmd == "record " or cmd.startswith("record "):
                        sub = cmd[7:] if cmd.startswith("record ") else ""
                        if sub == "start":
                            if recorder.is_recording:
                                console.print("[yellow]Already recording.[/]")
                            else:
                                path = recorder.start()
                                console.print(f"[green]🔴 Recording started → {path}[/]")
                        elif sub == "stop":
                            if not recorder.is_recording:
                                console.print("[dim]Not recording.[/]")
                            else:
                                path = recorder.stop()
                                console.print(f"[green]⏹ Recording stopped → {path}[/]")
                        elif sub in ("status", ""):
                            if recorder.is_recording:
                                import os
                                size = ""
                                if recorder.path.exists():
                                    size = f", {recorder.path.stat().st_size} bytes"
                                console.print(f"[cyan]🔴 Recording → {recorder.path}{size}[/]")
                            else:
                                console.print("[dim]Not recording. Use /record start[/]")
                        else:
                            console.print("Usage: /record start|stop|status")
                    elif cmd.startswith("replay "):
                        replay_path = user_input[8:].strip()
                        SessionRecorder.replay(replay_path, console=console)
                    elif cmd.startswith("mode "):
                        mode_name = cmd[5:].strip()
                        mode_map = {
                            "react": AgentMode.REACT,
                            "plan": AgentMode.PLAN_EXECUTE,
                            "sub": AgentMode.SUBAGENT,
                            "auto": AgentMode.AUTO,
                        }
                        if mode_name in mode_map:
                            current_mode = mode_map[mode_name]
                            console.print(f"[cyan]Mode set to: {current_mode.value}[/]")
                        else:
                            console.print(f"Unknown mode: {mode_name}")
                    elif cmd == "mcp" or cmd == "mcp ":
                        # /mcp — list servers & tools
                        if not mcp_manager.servers:
                            console.print("[dim]No MCP servers connected.[/]")
                            console.print(
                                "Configure via DEEPCRAFT_MCP_SERVERS env var, "
                                "e.g. github:npx -y @modelcontextprotocol/server-github"
                            )
                        else:
                            for srv_name in mcp_manager.servers:
                                table = Table(title=f"MCP: {srv_name}")
                                table.add_column("Tool", style="cyan")
                                table.add_column("Description", style="dim")
                                prefix = f"mcp_{srv_name}_"
                                for t in agent.tools.list_definitions():
                                    if t.name.startswith(prefix):
                                        table.add_row(
                                            t.name,
                                            t.description[:80],
                                        )
                                console.print(table)
                    elif cmd.startswith("mcp connect "):
                        # /mcp connect <name> <command|url>
                        parts = shlex.split(user_input)
                        if len(parts) < 4:
                            console.print(
                                "Usage: /mcp connect <name> <command>     (stdio)\n"
                                "       /mcp connect <name> <url>         (HTTP)"
                            )
                        else:
                            name = parts[2]
                            target = " ".join(parts[3:])
                            try:
                                if target.startswith("http://") or target.startswith("https://"):
                                    await mcp_manager.connect_http_server(name, target)
                                else:
                                    await mcp_manager.connect_server(name, parts[3:])
                                console.print(
                                    f"[green]✅ MCP server '{name}' connected![/]"
                                )
                            except Exception as e:
                                console.print(f"[red]❌ Failed: {e}[/]")
                    elif cmd.startswith("export "):
                        parts = cmd.split(maxsplit=2)
                        fmt = parts[1] if len(parts) > 1 else "md"
                        path = parts[2] if len(parts) > 2 else ""
                        if fmt not in ("md", "json"):
                            console.print("Usage: /export md|json [path]")
                            continue
                        if not path:
                            ts = __import__("datetime").datetime.now().strftime("%Y%m%d_%H%M%S")
                            path = f"deepcraft_export_{ts}.{fmt}"
                        try:
                            if fmt == "md":
                                content = agent.ctx.export_markdown()
                            else:
                                content = __import__("json").dumps(
                                    agent.ctx.export_json(), ensure_ascii=False, indent=2
                                )
                            with open(path, "w", encoding="utf-8") as f:
                                f.write(content)
                            console.print(
                                f"[green]✅ Exported {len(agent.ctx)} messages "
                                f"→ {path}[/]"
                            )
                        except Exception as e:
                            console.print(f"[red]❌ Export failed: {e}[/]")
                    else:
                        console.print(f"Unknown command: /{cmd}")
                    continue

                # Normal input → agent loop with mode
                console.print()
                try:
                    import time as _time
                    _start = _time.monotonic()
                    await agent.run_with_mode(user_input, mode=current_mode)
                    _elapsed = int((_time.monotonic() - _start) * 1000)

                    # Auto-record if active
                    if recorder.is_recording:
                        # Collect tool calls from last assistant message
                        tool_calls = []
                        for msg in reversed(agent.ctx._messages):
                            if msg.role == "assistant" and msg.tool_calls:
                                for tc in msg.tool_calls:
                                    tool_calls.append({
                                        "name": tc["function"]["name"],
                                        "arguments": tc["function"]["arguments"],
                                    })
                                break

                        recorder.record_turn(
                            turn=agent._turn_count,
                            user_input=user_input,
                            tool_calls=tool_calls,
                            duration_ms=_elapsed,
                            token_estimate=agent.ctx.token_count,
                            compression_count=agent.ctx.compression_count,
                        )
                except Exception as e:
                    console.print(f"\n[red]Error: {e}[/]")

        finally:
            await mcp_manager.close_all()
            await agent.close()

    asyncio.run(repl())


def run_once(prompt: str, mode: AgentMode = AgentMode.AUTO) -> None:
    """Run a single prompt and exit.

    Args:
        prompt: The user's input.
        mode: Agent mode to use (default: auto-detect).
    """

    async def _run() -> None:
        agent = _create_agent()
        mcp_manager = MCPManager(agent.tools)
        try:
            await _connect_mcp_servers(agent, mcp_manager)
            await agent.run_with_mode(prompt, mode=mode)
        finally:
            await mcp_manager.close_all()
            await agent.close()

    asyncio.run(_run())
