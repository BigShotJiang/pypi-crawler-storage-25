"""
Standalone plotting functions for experiment-utils.

All functions accept plain DataFrames so they can be used independently
of ``ExperimentAnalyzer`` and ``PowerSim``.  The class methods are thin
wrappers that extract the relevant data and delegate here.
"""

from __future__ import annotations

import matplotlib.lines as mlines
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import pandas as pd
import seaborn as sns
from scipy import stats


def _critical_value(alpha: float, df_resid: pd.Series | None = None) -> pd.Series | float:
    """Return t or z critical value depending on whether df_resid is available."""
    z = stats.norm.ppf(1 - alpha / 2)
    if df_resid is None:
        return z
    valid = df_resid.notna()
    crit = pd.Series(z, index=df_resid.index)
    if valid.any():
        crit.loc[valid] = df_resid.loc[valid].apply(lambda d: stats.t.ppf(1 - alpha / 2, d))
    return crit


# shared palette — used by both the public function and the internal renderer
_CLR_SIG = "#166534"  # dark green — significant positive
_CLR_SIG_NEG = "#991b1b"  # deep red — significant negative
_CLR_NSIG = "#64748b"  # muted slate — neutral / not significant
_CLR_NSIG_POS = "#4ade80"  # light green — positive but not significant
_CLR_NSIG_NEG = "#64748b"  # muted slate — negative but not significant
_CLR_META_BG = "#fef2f2"  # faint rose — pooled row background
_CLR_ZERO = "#475569"  # dark slate zero line
_CLR_GUIDE = "#e2e8f0"  # very light guide lines
_CLR_SPINE = "#cbd5e1"  # spine / tick color

# Equivalence test conclusion colors
_CLR_EQ = "#166534"  # deep green — equivalent / non-inferior
_CLR_NOT_EQ = "#991b1b"  # deep red — not equivalent
_CLR_EQ_DIFF = "#b45309"  # amber — equivalent with difference
_CLR_EQ_BAND = "#dcfce7"  # light green — equivalence region fill

# Default color palette for color_direction mode
DEFAULT_COLOR_PALETTE: dict[str, str] = {
    "sig_pos": _CLR_SIG,  # dark green — significant positive
    "sig_neg": _CLR_SIG_NEG,  # deep red — significant negative
    "nsig_pos": _CLR_NSIG_POS,  # medium-light green — positive but not significant
    "nsig_neg": _CLR_NSIG_NEG,  # muted slate — negative / neutral
    "nsig_zero": _CLR_NSIG,  # muted slate — exactly zero
}

_PROPORTION_RANGE_ATOL = 1e-12


def _resolve_palette(color_palette: dict[str, str] | None) -> dict[str, str]:
    """Merge user overrides into the default palette."""
    if color_palette is None:
        return DEFAULT_COLOR_PALETTE.copy()
    merged = DEFAULT_COLOR_PALETTE.copy()
    merged.update(color_palette)
    return merged


def _fmt_label(
    value: float,
    significant: int,
    eff_col: str,
    decimals: int = 2,
    pct_points: bool = False,
    relative_cap: float = 5.0,
) -> str:
    """Format an effect value as a label, appending '*' when significant."""
    if "relative" in eff_col:
        if value > relative_cap:
            text = f">100.{'0' * decimals}%"
        elif value < -relative_cap:
            text = f"<-100.{'0' * decimals}%"
        else:
            text = f"{value:+.{decimals}%}"
    elif pct_points:
        text = f"{value:+.{decimals}f}pp"
    else:
        text = f"{value:+.{decimals}f}"
    return text + ("*" if significant else "")


def _resolve_ci_cols(
    lo_col: str, hi_col: str, data: pd.DataFrame, sig_col: str, eff_col: str | None = None
) -> tuple[str, str, pd.DataFrame]:
    """Return effective (lo, hi) columns and (possibly augmented) data.

    When Bonferroni/MCP significance is active but the pre-computed MCP CI
    columns are absent, derive them on-the-fly so the displayed CI always
    matches the significance decision.  Without this, a gray (non-significant)
    dot can have a CI that visually excludes 0 — inconsistent with the legend.
    """
    _mcp_lo = lo_col.replace("_lower", "_lower_mcp").replace("effect_lower", "effect_lower_mcp")
    _mcp_hi = hi_col.replace("_upper", "_upper_mcp").replace("effect_upper", "effect_upper_mcp")

    mcp_cols_exist = _mcp_lo in data.columns and _mcp_hi in data.columns and not data[_mcp_lo].isna().all()

    if sig_col != "stat_significance_mcp":
        return lo_col, hi_col, data

    if mcp_cols_exist:
        return _mcp_lo, _mcp_hi, data

    # mcp CI columns are absent — compute them from pvalue ratio or row count.
    if "standard_error" not in data.columns or "pvalue" not in data.columns:
        return lo_col, hi_col, data

    # estimate n_tests from median pvalue_mcp / pvalue ratio, fall back to row count.
    n_tests = len(data)
    if "pvalue_mcp" in data.columns:
        valid = data[(data["pvalue"] > 0) & (data["pvalue_mcp"] < 1) & data["pvalue_mcp"].notna()]
        if not valid.empty:
            n_tests = max(1, round((valid["pvalue_mcp"] / valid["pvalue"]).median()))

    alpha_adj = 0.05 / n_tests
    _eff_col = eff_col or lo_col.replace("_lower", "").replace("abs_effect", "absolute_effect").replace(
        "rel_effect", "relative_effect"
    )
    if _eff_col not in data.columns:
        return lo_col, hi_col, data

    df_col = data["df_resid"] if "df_resid" in data.columns else None
    crit_adj = _critical_value(alpha_adj, df_col)
    data = data.copy()
    data[_mcp_lo] = data[_eff_col] - crit_adj * data["standard_error"]
    data[_mcp_hi] = data[_eff_col] + crit_adj * data["standard_error"]
    return _mcp_lo, _mcp_hi, data


def _draw_panels_into_axes(
    axes: list,
    data: pd.DataFrame,
    unique_panels: list,
    eff_col: str,
    lo_col: str,
    hi_col: str,
    x_label: str,
    sig_col: str,
    meta_df: pd.DataFrame | None,
    show_zero_line: bool,
    sort_by_magnitude: bool,
    panel_col: str,
    row_col: str,
    panel_titles: str | list | dict | None,
    show_panel_titles: bool,
    row_labels: dict | None,
    show_values: bool,
    value_decimals: int = 2,
    show_yticklabels: bool | list[bool] = True,
    row_order: dict | None = None,
    pct_points: bool = False,
    combine_values: bool = False,
    relative_cap: float = 5.0,
    pp_outcomes: set | None = None,
    color_direction: bool = False,
    color_palette: dict[str, str] | None = None,
) -> None:
    """Draw Cleveland-dot panels into a pre-created list of axes (one ax per panel value)."""
    pal = _resolve_palette(color_palette)
    _lo_col, _hi_col, data = _resolve_ci_cols(lo_col, hi_col, data, sig_col, eff_col)

    for panel_idx, (ax, panel_val) in enumerate(zip(axes, unique_panels, strict=False)):
        show_yticks = show_yticklabels[panel_idx] if isinstance(show_yticklabels, list) else show_yticklabels
        od = data[data[panel_col] == panel_val].copy()

        # Per-panel pct_points: only True when this panel's outcome is proportion-scale.
        # When panel_col == "outcome" we know exactly; otherwise fall back to the global flag.
        if pp_outcomes is not None and panel_col == "outcome":
            _panel_pct = panel_val in pp_outcomes
        elif pp_outcomes is not None and panel_col != "outcome" and "outcome" in od.columns:
            # y="outcome" layout: panel = experiment, rows = outcomes.
            # pp applies row-by-row; use the global flag as a hint for the axis label.
            _panel_pct = pct_points
        else:
            _panel_pct = pct_points

        # Build the per-panel x-axis label (append "(pp)" only when this panel is scaled).
        _x_label = x_label
        if _panel_pct and "relative" not in eff_col and x_label and "(pp)" not in x_label:
            _x_label = x_label + " (pp)"

        ax.set_facecolor("white")
        ax.set_axisbelow(True)
        if show_zero_line:
            ax.axvline(0, color=_CLR_ZERO, linestyle="-", linewidth=1.0, alpha=0.55, zorder=1)
        cap_h = 0.06

        if row_order is not None and panel_val in row_order:
            order_map = {label: i for i, label in enumerate(row_order[panel_val])}
            od["_row_order"] = od[row_col].map(order_map).fillna(len(order_map))
            od = od.sort_values("_row_order")
        elif sort_by_magnitude:
            od = od.sort_values(by=eff_col, ascending=False)

        labels = list(od[row_col])
        effs = list(od[eff_col])
        los = list(od[_lo_col])
        his = list(od[_hi_col])
        sigs = list(od[sig_col]) if sig_col in od.columns else [0] * len(od)
        # secondary effect for combine_values: the column that is NOT being plotted
        _secondary_col = "absolute_effect" if "relative" in eff_col else "relative_effect"
        secondary_effs = list(od[_secondary_col]) if _secondary_col in od.columns else [None] * len(od)

        has_meta = False
        meta_label = None
        if meta_df is not None and panel_col == "outcome":
            outcome = panel_val
            mo = meta_df[meta_df["outcome"] == outcome] if "outcome" in meta_df.columns else meta_df
            if not mo.empty:
                has_meta = True
                meta_label = "◆ " + mo["_label"].iloc[0]
                labels = labels + [meta_label]
                effs = effs + [float(mo[eff_col].iloc[0])]
                _meta_lo = _lo_col if _lo_col in mo.columns else lo_col
                _meta_hi = _hi_col if _hi_col in mo.columns else hi_col
                los = los + [float(mo[_meta_lo].iloc[0])]
                his = his + [float(mo[_meta_hi].iloc[0])]
                meta_sig_col = "stat_significance_mcp" if "stat_significance_mcp" in mo.columns else "stat_significance"
                meta_sig = int(mo[meta_sig_col].iloc[0]) if meta_sig_col in mo.columns else 0
                sigs = sigs + [meta_sig]
                meta_secondary = float(mo[_secondary_col].iloc[0]) if _secondary_col in mo.columns else None
                secondary_effs = secondary_effs + [meta_secondary]

        n_rows = len(labels)
        n_exp = n_rows - (1 if has_meta else 0)
        y_pos = list(range(n_rows))

        for i in range(n_exp):
            ax.axhline(i, color=_CLR_GUIDE, linewidth=0.6, linestyle=":", zorder=0)

        if has_meta:
            meta_y = n_rows - 1
            ax.axhspan(meta_y - 0.48, meta_y + 0.48, color=_CLR_META_BG, zorder=0)
            ax.axhline(meta_y - 0.52, color=_CLR_SPINE, linewidth=1.2, linestyle=(0, (6, 3)), zorder=1)

        for i, (label, eff, lo, hi, sig, secondary_eff) in enumerate(
            zip(labels, effs, los, his, sigs, secondary_effs, strict=False)
        ):
            if eff is None or not pd.notna(eff) or not np.isfinite(eff):
                continue

            ci_valid = (
                lo is not None
                and hi is not None
                and pd.notna(lo)
                and pd.notna(hi)
                and np.isfinite(lo)
                and np.isfinite(hi)
            )
            if not ci_valid:
                continue

            # Override significance when CI visually crosses zero
            ci_crosses_zero = lo <= 0 <= hi
            effective_sig = sig if not ci_crosses_zero else 0

            is_meta_row = has_meta and label == meta_label
            if is_meta_row:
                if color_direction:
                    if effective_sig == 1:
                        color = pal["sig_pos"] if eff >= 0 else pal["sig_neg"]
                    else:
                        color = pal["nsig_pos"] if eff > 0 else pal["nsig_neg"] if eff < 0 else pal["nsig_zero"]
                else:
                    color = pal["sig_pos"] if effective_sig == 1 else _CLR_NSIG
                marker, dot_size, ci_lw = "D", 70, 1.8
            elif effective_sig == 1:
                if color_direction:
                    sig_clr = pal["sig_pos"] if eff >= 0 else pal["sig_neg"]
                else:
                    sig_clr = pal["sig_pos"]
                color, marker, dot_size, ci_lw = sig_clr, "o", 45, 1.4
            elif color_direction:
                nsig_clr = pal["nsig_pos"] if eff > 0 else pal["nsig_neg"] if eff < 0 else pal["nsig_zero"]
                color, marker, dot_size, ci_lw = nsig_clr, "o", 35, 1.2
            else:
                color, marker, dot_size, ci_lw = _CLR_NSIG, "o", 35, 1.2
            ax.hlines(i, lo, hi, color=color, linewidth=ci_lw, alpha=0.75, zorder=3)
            ax.vlines(lo, i - cap_h, i + cap_h, color=color, linewidth=ci_lw * 0.75, alpha=0.75, zorder=3)
            ax.vlines(hi, i - cap_h, i + cap_h, color=color, linewidth=ci_lw * 0.75, alpha=0.75, zorder=3)
            ax.scatter(eff, i, color=color, s=dot_size, marker=marker, zorder=5, edgecolors="white", linewidths=0.7)

            if show_values:
                lbl = _fmt_label(
                    eff,
                    effective_sig,
                    eff_col,
                    decimals=value_decimals,
                    pct_points=_panel_pct,
                    relative_cap=relative_cap,
                )
                if (
                    combine_values
                    and secondary_eff is not None
                    and pd.notna(secondary_eff)
                    and np.isfinite(secondary_eff)
                ):
                    if "relative" in eff_col:
                        # plotting relative → append absolute. Values already scaled for
                        # pp_outcomes, so just add the "pp" suffix without ×100.
                        if _panel_pct:
                            lbl = f"{lbl} ({secondary_eff:+.{value_decimals}f}pp)"
                        else:
                            lbl = f"{lbl} ({secondary_eff:+.{value_decimals}f})"
                    else:
                        # plotting absolute → append relative %
                        if secondary_eff > relative_cap:
                            rel_str = f">100.{'0' * value_decimals}%"
                        elif secondary_eff < -relative_cap:
                            rel_str = f"<-100.{'0' * value_decimals}%"
                        else:
                            rel_str = f"{secondary_eff:+.{value_decimals}%}"
                        lbl = f"{lbl} ({rel_str})"
                ax.text(eff, i - 0.14, lbl, ha="center", va="bottom", fontsize=7.5, color=color, zorder=6)

        ax.set_yticks(y_pos)
        if show_yticks:
            display_labels = [row_labels.get(lbl, lbl) for lbl in labels] if row_labels else labels
            ax.set_yticklabels(display_labels, fontsize=9.5, color="#334155")
        else:
            ax.set_yticklabels([])

        ax.tick_params(axis="y", length=0, pad=8 if show_yticks else 2)
        ax.tick_params(axis="x", labelsize=8.5, colors="#64748b", pad=4)
        ax.set_xlabel(_x_label, fontsize=9.5, color="#64748b", labelpad=6)
        # Format x-axis ticks to match the annotation labels:
        # relative effect panels: decimals → "15%" to match "+15.4%" annotations
        # absolute pp panels: already scaled ×100, so ticks already match annotations
        if "relative" in eff_col:
            from matplotlib.ticker import FuncFormatter

            ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x:.0%}"))
        ax.set_ylim(-0.6, n_rows - 0.4)
        ax.invert_yaxis()
        for spine in ("top", "right", "left"):
            ax.spines[spine].set_visible(False)
        ax.spines["bottom"].set_color(_CLR_SPINE)
        ax.spines["bottom"].set_linewidth(0.8)

        if show_panel_titles:
            if isinstance(panel_titles, dict):
                ptitle = panel_titles.get(panel_val, str(panel_val))
            elif isinstance(panel_titles, list):
                ptitle = panel_titles[panel_idx] if panel_idx < len(panel_titles) else str(panel_val)
            elif isinstance(panel_titles, str):
                ptitle = panel_titles
            else:
                ptitle = row_labels.get(panel_val, str(panel_val)) if row_labels else str(panel_val)
            ax.set_title(ptitle, fontsize=11, fontweight="semibold", color="#1e293b", loc="left", pad=18)

        ax.xaxis.set_major_locator(mticker.MaxNLocator(nbins=5, prune="both"))


def _add_legend_and_title(
    fig: plt.Figure,
    figsize: tuple,
    title: str | None,
    sig_label: str,
    meta_df: pd.DataFrame | None,
    panel_spacing: float | None = None,
    color_direction: bool = False,
    color_palette: dict[str, str] | None = None,
) -> None:
    """Add a shared legend/footnote and optional suptitle, then call tight_layout."""
    top_anchor = 0.97
    if title:
        fig.suptitle(title, fontsize=13, fontweight="bold", color="#0f172a", y=top_anchor)
        top_anchor -= 0.07

    if color_direction:
        # Extract alpha from sig_label like "Significant (α=0.05)"
        import re

        alpha_match = re.search(r"α=([\d.]+)", sig_label)
        alpha_str = alpha_match.group(1) if alpha_match else "0.05"
        mcp_match = re.search(r"\((\w+),", sig_label)
        if mcp_match:
            footnote_label = f"* significant at α={alpha_str} ({mcp_match.group(1)})"
        else:
            footnote_label = f"* significant at α={alpha_str}"
        legend_items = [
            mlines.Line2D([], [], linestyle="None", marker="None", label=footnote_label),
        ]
        if meta_df is not None:
            legend_items.append(
                mlines.Line2D(
                    [], [], color="#475569", marker="D", linestyle="None", markersize=6, label="Pooled (meta-analysis)"
                )
            )
        fig.legend(
            handles=legend_items,
            loc="upper center",
            ncol=len(legend_items),
            bbox_to_anchor=(0.5, top_anchor),
            frameon=False,
            fontsize=9,
            handlelength=1.6,
            handletextpad=0.5,
            columnspacing=1.4,
        )
    else:
        import re

        alpha_match = re.search(r"α=([\d.]+)", sig_label)
        alpha_str = alpha_match.group(1) if alpha_match else "0.05"
        mcp_match = re.search(r"\((\w+),", sig_label)
        if mcp_match:
            footnote_label = f"* significant at α={alpha_str} ({mcp_match.group(1)})"
        else:
            footnote_label = f"* significant at α={alpha_str}"
        legend_items = [
            mlines.Line2D([], [], linestyle="None", marker="None", label=footnote_label),
        ]
        if meta_df is not None:
            legend_items.append(
                mlines.Line2D(
                    [], [], color="#475569", marker="D", linestyle="None", markersize=6, label="Pooled (meta-analysis)"
                )
            )
        fig.legend(
            handles=legend_items,
            loc="upper center",
            ncol=len(legend_items),
            bbox_to_anchor=(0.5, top_anchor),
            frameon=False,
            fontsize=9,
            handlelength=1.6,
            handletextpad=0.5,
            columnspacing=1.4,
        )

    header_inches = 0.45 + (0.28 if title else 0.0)
    reserved = header_inches / figsize[1]
    fig.tight_layout(rect=[0, 0, 1, 1.0 - reserved])
    if panel_spacing is not None:
        fig.subplots_adjust(wspace=panel_spacing)
    plt.close(fig)


def _make_pooled_meta(
    data: pd.DataFrame,
    panel_col: str,
    eff_col: str,
    lo_col: str,
    hi_col: str,
    sig_col: str,
    alpha: float,
) -> pd.DataFrame | None:
    """Compute IVW pooled estimate per panel from the visible plot data.

    Always derives the pooled row from the same rows shown in the figure,
    so it can never be inconsistent with external pre-computed meta DataFrames.
    Returns None when no panel has at least two valid experiments.
    """
    if "standard_error" not in data.columns:
        return None
    z = stats.norm.ppf(1 - alpha / 2)
    rows = []
    for panel_val in data[panel_col].unique():
        od = data[data[panel_col] == panel_val]
        valid = (
            od["standard_error"].notna()
            & od["standard_error"].apply(np.isfinite)
            & (od["standard_error"] > 0)
            & od[eff_col].notna()
            & od[eff_col].apply(np.isfinite)
        )
        od = od[valid]
        if len(od) < 2:
            continue
        w = 1.0 / (od["standard_error"] ** 2)
        eff = float((w * od[eff_col]).sum() / w.sum())
        se = float(np.sqrt(1.0 / w.sum()))
        pvalue = float(2 * stats.norm.sf(abs(eff / se)))
        row: dict = {
            panel_col: panel_val,
            "_label": "Pooled",
            eff_col: eff,
            lo_col: eff - z * se,
            hi_col: eff + z * se,
            "standard_error": se,
            "pvalue": pvalue,
            sig_col: 1 if pvalue < alpha else 0,
        }
        # also pool the secondary effect so combine_values can annotate the pooled row
        for sec_col in ("relative_effect", "absolute_effect"):
            if sec_col != eff_col and sec_col in od.columns:
                sec_valid = od[sec_col].notna() & od[sec_col].apply(np.isfinite)
                if sec_valid.any():
                    row[sec_col] = float((w[sec_valid] * od.loc[sec_valid, sec_col]).sum() / w[sec_valid].sum())
        rows.append(row)
    return pd.DataFrame(rows) if rows else None


def _fill_missing_panel_rows(
    data: pd.DataFrame,
    panel_col: str,
    row_col: str,
) -> pd.DataFrame:
    """Add NaN rows for every panel × row-label combination absent from *data*.

    This guarantees that all panels share the same y-positions so dots in
    different panels are vertically aligned.  Missing entries have NaN for
    every column except *panel_col* and *row_col*; the draw loop already
    skips NaN effect rows while keeping the guide-line and tick-label.
    """
    unique_panels = list(data[panel_col].unique())
    # Preserve first-appearance order across all panels
    all_labels = list(dict.fromkeys(data[row_col].tolist()))
    rows_to_add = []
    for panel_val in unique_panels:
        existing = set(data[data[panel_col] == panel_val][row_col])
        for label in all_labels:
            if label not in existing:
                rows_to_add.append({panel_col: panel_val, row_col: label})
    if rows_to_add:
        data = pd.concat([data, pd.DataFrame(rows_to_add)], ignore_index=True)
    return data


def _render_effects_figure(
    data: pd.DataFrame,
    unique_outcomes: list[str],
    eff_col: str,
    lo_col: str,
    hi_col: str,
    x_label: str,
    alpha: float,
    meta_df: pd.DataFrame | None,
    figsize: tuple | None,
    title: str | None,
    show_zero_line: bool,
    sort_by_magnitude: bool,
    panel_col: str = "outcome",
    row_col: str = "_label",
    panel_titles: str | list | dict | None = None,
    show_panel_titles: bool = True,
    row_labels: dict | None = None,
    show_values: bool = False,
    value_decimals: int = 2,
    panel_spacing: float | None = None,
    repeat_ylabels: bool = False,
    pct_points: bool = False,
    combine_values: bool = False,
    relative_cap: float = 5.0,
    pp_outcomes: set | None = None,
    color_direction: bool = False,
    color_palette: dict[str, str] | None = None,
) -> plt.Figure:
    """Build and return a single effects figure for *data* (already labelled)."""
    sig_col = "stat_significance_mcp" if "stat_significance_mcp" in data.columns else "stat_significance"
    mcp_method = data["mcp_method"].iloc[0] if "mcp_method" in data.columns else None
    sig_label = f"Significant ({mcp_method}, α={alpha})" if mcp_method else f"Significant (α={alpha})"

    if panel_col == "outcome" and unique_outcomes:
        unique_panels = [o for o in unique_outcomes if o in data[panel_col].values]
    else:
        unique_panels = list(data[panel_col].unique())
    n_panels = len(unique_panels)
    data = _fill_missing_panel_rows(data, panel_col, row_col)
    max_rows = max(data[data[panel_col] == p][row_col].nunique() for p in unique_panels)
    if meta_df is not None and panel_col == "outcome":
        max_rows += 1
    if figsize is None:
        fig_h = max(3.5, 0.65 * max_rows + 2.4)
        panel_w = max(3.2, min(5.5, 14.0 / n_panels))
        fig_w = max(5.5, panel_w * n_panels)
        figsize = (fig_w, fig_h)

    fig, axes = plt.subplots(1, n_panels, figsize=figsize, squeeze=False)

    # derive a stable row order from the first panel so all panels share the same
    # top-to-bottom sequence regardless of per-panel effect magnitudes.
    row_order: dict | None = None
    if n_panels > 1:
        row_order = {}
        first_panel = unique_panels[0]
        pdata = data[data[panel_col] == first_panel]
        if sort_by_magnitude:
            sorted_rows = pdata.sort_values(by=eff_col, ascending=False)
        else:
            sorted_rows = pdata  # preserve natural order of first panel
        reference_order = list(sorted_rows[row_col])
        for pval in unique_panels:
            row_order[pval] = reference_order

    # by default only the leftmost panel shows y-tick labels; repeat_ylabels shows all.
    show_yticklabels = True if repeat_ylabels else [pi == 0 for pi in range(n_panels)]

    _draw_panels_into_axes(
        list(axes.flatten()),
        data,
        unique_panels,
        eff_col,
        lo_col,
        hi_col,
        x_label,
        sig_col,
        meta_df,
        show_zero_line,
        sort_by_magnitude,
        panel_col,
        row_col,
        panel_titles,
        show_panel_titles,
        row_labels,
        show_values,
        value_decimals=value_decimals,
        show_yticklabels=show_yticklabels,
        row_order=row_order,
        pct_points=pct_points,
        combine_values=combine_values,
        relative_cap=relative_cap,
        pp_outcomes=pp_outcomes,
        color_direction=color_direction,
        color_palette=color_palette,
    )

    _add_legend_and_title(
        fig,
        figsize,
        title,
        sig_label,
        meta_df,
        panel_spacing=panel_spacing,
        color_direction=color_direction,
        color_palette=color_palette,
    )
    return fig


def _render_multi_effect_figure(
    data: pd.DataFrame,
    effect_specs: list[tuple],
    alpha: float,
    meta_df: pd.DataFrame | None,
    figsize: tuple | None,
    title: str | None,
    show_zero_line: bool,
    sort_by_magnitude: bool,
    panel_col: str,
    row_col: str,
    panel_titles: str | list | dict | None,
    show_panel_titles: bool,
    row_labels: dict | None,
    show_values: bool,
    value_decimals: int = 2,
    panel_spacing: float | None = None,
    repeat_ylabels: bool = False,
    pct_points: bool = False,
    combine_values: bool = False,
    relative_cap: float = 5.0,
    pp_outcomes: set | None = None,
    unique_outcomes: list[str] | None = None,
    color_direction: bool = False,
    color_palette: dict[str, str] | None = None,
) -> plt.Figure:
    """Build a side-by-side figure with one column group per effect type.

    ``effect_specs`` is a list of ``(eff_col, lo_col, hi_col, x_label)`` tuples,
    one per effect type.  Panels for the same outcome are placed adjacent to each
    other: ``[abs_p0 | rel_p0 | abs_p1 | rel_p1 | ...]``.  Row labels and the
    panel title are shown only on the leftmost column of each panel group.
    """
    sig_col = "stat_significance_mcp" if "stat_significance_mcp" in data.columns else "stat_significance"
    mcp_method = data["mcp_method"].iloc[0] if "mcp_method" in data.columns else None
    sig_label = f"Significant ({mcp_method}, α={alpha})" if mcp_method else f"Significant (α={alpha})"

    if panel_col == "outcome" and unique_outcomes:
        unique_panels = [o for o in unique_outcomes if o in data[panel_col].values]
    else:
        unique_panels = list(data[panel_col].unique())
    n_panels = len(unique_panels)
    n_effects = len(effect_specs)
    n_cols = n_panels * n_effects
    data = _fill_missing_panel_rows(data, panel_col, row_col)
    max_rows = max(data[data[panel_col] == p][row_col].nunique() for p in unique_panels)
    if meta_df is not None and panel_col == "outcome":
        max_rows += 1

    if figsize is None:
        fig_h = max(3.5, 0.65 * max_rows + 2.4)
        panel_w = max(2.8, min(4.5, 12.0 / n_cols))
        fig_w = max(5.5, panel_w * n_cols)
        figsize = (fig_w, fig_h)

    fig, all_axes = plt.subplots(1, n_cols, figsize=figsize, squeeze=False)

    # derive a stable row order from the first panel so all panels share the
    # same top-to-bottom sequence regardless of which effect is displayed.
    row_order: dict | None = None
    if n_panels > 1:
        row_order = {}
        first_panel = unique_panels[0]
        pdata = data[data[panel_col] == first_panel]
        if sort_by_magnitude:
            first_ec = effect_specs[0][0]
            sorted_rows = pdata.sort_values(by=first_ec, ascending=False)
        else:
            sorted_rows = pdata  # preserve natural order of first panel
        reference_order = list(sorted_rows[row_col])
        for pval in unique_panels:
            row_order[pval] = reference_order

    for eff_idx, (ec, lc, hc, xl) in enumerate(effect_specs):
        # prepare CI columns for this effect type
        eff_data = data.copy()
        if lc not in eff_data.columns or eff_data[lc].isna().all():
            df_col = eff_data["df_resid"] if "df_resid" in eff_data.columns else None
            crit = _critical_value(alpha, df_col)
            eff_data[lc] = eff_data[ec] - crit * eff_data["standard_error"]
            eff_data[hc] = eff_data[ec] + crit * eff_data["standard_error"]
        if meta_df is not None:
            _meta = meta_df.copy()
            if lc not in _meta.columns or _meta[lc].isna().all():
                z = stats.norm.ppf(1 - alpha / 2)
                _meta[lc] = _meta[ec] - z * _meta["standard_error"]
                _meta[hc] = _meta[ec] + z * _meta["standard_error"]
        else:
            _meta = None

        # columns for this effect: positions [pi * n_effects + eff_idx] for each panel pi
        panel_axes = [all_axes[0][pi * n_effects + eff_idx] for pi in range(n_panels)]
        show_yticks = eff_idx == 0 or repeat_ylabels

        _draw_panels_into_axes(
            panel_axes,
            eff_data,
            unique_panels,
            ec,
            lc,
            hc,
            xl,
            sig_col,
            _meta,
            show_zero_line,
            sort_by_magnitude,
            panel_col,
            row_col,
            panel_titles if show_yticks else "",
            show_panel_titles,
            row_labels,
            show_values,
            value_decimals=value_decimals,
            show_yticklabels=show_yticks,
            row_order=row_order,
            pct_points=(pct_points and ec == "absolute_effect"),
            combine_values=combine_values,
            relative_cap=relative_cap,
            pp_outcomes=pp_outcomes if ec == "absolute_effect" else None,
            color_direction=color_direction,
            color_palette=color_palette,
        )

    _add_legend_and_title(
        fig,
        figsize,
        title,
        sig_label,
        meta_df,
        panel_spacing=panel_spacing,
        color_direction=color_direction,
        color_palette=color_palette,
    )
    return fig


def plot_effects(
    results: pd.DataFrame,
    experiment_identifier: str | list[str] | None = None,
    alpha: float = 0.05,
    outcomes: list[str] | str | None = None,
    effect: str | list[str] = "absolute",
    meta_df: pd.DataFrame | None = None,
    comparison: tuple | list[tuple] | None = None,
    figsize: tuple | None = None,
    title: str | None = None,
    show_zero_line: bool = True,
    sort_by_magnitude: bool = True,
    group_by: str | list[str] | None = None,
    y: str = "experiment",
    panel_titles: str | list | dict | None = None,
    show_panel_titles: bool = True,
    row_labels: dict | None = None,
    show_values: bool = True,
    value_decimals: int | None = None,
    panel_spacing: float | None = None,
    repeat_ylabels: bool = False,
    pct_points: bool = False,
    combine_values: bool = False,
    relative_cap: float = 5.0,
    save_path: str | None = None,
    color_direction: bool = False,
    color_palette: dict[str, str] | None = None,
    **kwargs,
) -> plt.Figure | dict[str, plt.Figure] | None:
    if kwargs:
        raise TypeError(f"plot_effects() got unexpected keyword argument(s): {list(kwargs.keys())}")
    """
    Cleveland dot plot of treatment effects across experiments.

    Each outcome gets its own panel.  Experiments are shown as rows with
    a dot at the point estimate and a bracketed confidence interval.
    An optional pooled (meta-analysis) row is appended at the bottom.

    Parameters
    ----------
    results : pd.DataFrame
        Output of ``ExperimentAnalyzer.get_effects()``.
    experiment_identifier : str or list[str], optional
        Column(s) used to label each row.  Falls back to
        ``"treatment_group vs control_group"`` when ``None``.
    alpha : float, optional
        Significance level used for the legend label (default 0.05).
    outcomes : str or list[str], optional
        Outcomes to include.  ``None`` shows all outcomes in *results*.
    effect : {"absolute", "relative"} or list, optional
        Which effect metric(s) to display (default ``"absolute"``).
        Pass a list such as ``["absolute", "relative"]`` to produce a
        side-by-side figure with one column group per effect type.
    meta_df : pd.DataFrame, optional
        Pre-computed ``combine_effects()`` result to append as a pooled row.
        Pass ``None`` (default) to omit the pooled row.
    comparison : tuple or list of tuple, optional
        ``(treatment_group, control_group)`` to restrict the plot to one
        specific comparison, or a list of such tuples to include multiple
        comparisons, e.g.
        ``[('variant_1', 'control'), ('variant_1', 'variant_2')]``.
    figsize : tuple, optional
        ``(width, height)`` in inches.  Auto-sized when ``None``.
    title : str, optional
        Figure-level suptitle.  When *group_by* is set and *title* is ``None``,
        the group value is used as the suptitle automatically.
    show_zero_line : bool, optional
        Vertical reference line at zero (default ``True``).
    sort_by_magnitude : bool, optional
        Sort rows within each panel by effect value descending (default ``True``).
    group_by : str or list[str], optional
        Column(s) to split into separate figures — one figure per unique value.
        Row labels are built from ``experiment_identifier`` minus these columns.
        Returns a ``dict`` keyed by the group value instead of a single figure.
    y : {"experiment", "outcome"}, optional
        What to place on the y-axis (rows).

        - ``"experiment"`` (default) — rows = experiment labels, panels = outcomes.
        - ``"outcome"`` — rows = outcomes, panels = experiment labels.

    panel_titles : str or dict, optional
        Override the auto-generated panel (subplot) titles.

        - ``None`` (default) — use the panel value as the title.
        - ``str`` — use the same string for every panel (``""`` hides all).
        - ``list`` — titles in panel order, e.g. ``["Revenue ($)", "CVR"]``.
        - ``dict`` — map each panel value to a custom display string.

        What counts as a "panel value" depends on *y*:

        - ``y="experiment"`` (default): one panel per **outcome**, so keys
          are outcome names, e.g.
          ``{"revenue": "Revenue ($)", "converted": "Conversion rate"}``.
        - ``y="outcome"``: one panel per **experiment label**, so keys are
          the auto-generated experiment labels (``experiment_identifier``
          column values joined with ``" | "``), e.g.
          ``{"US | email": "US — Email campaign"}``.
    show_panel_titles : bool, optional
        Show subplot titles for the panel values (outcomes when
        ``y="experiment"``, experiments when ``y="outcome"``).  Set to
        ``False`` to hide these headings, which is useful when the plot has a
        single redundant panel.  Default ``True``.

    row_labels : dict, optional
        Rename individual row labels on the y-axis.  Keys are the
        auto-generated labels (column values joined with ``" | "``); values
        are the display strings to use instead.
        e.g. ``{"US | email": "Email (US)", "EU | push": "Push (EU)"}``.
        Rows not in the dict keep their auto-generated label.

    show_values : bool, optional
        Annotate each dot with its effect value (and ``*`` when significant).
        Default ``True``.
    value_decimals : int, optional
        Number of decimal places for the value labels shown when
        ``show_values=True``.  Defaults to ``1`` when ``pct_points=True``
        or when any relative effect is shown (e.g. ``+3.0pp``, ``+15.4%``),
        and ``2`` otherwise (e.g. ``+0.03``).
    panel_spacing : float, optional
        Horizontal whitespace between panels as a fraction of the average axes
        width (passed to ``subplots_adjust(wspace=...)``).  Larger values add
        more room between panels.  ``None`` (default) uses matplotlib's
        automatic spacing.  Try values like ``0.4``–``0.8`` when panels overlap.
    repeat_ylabels : bool, optional
        When ``True``, show y-axis tick labels on every panel instead of only
        the leftmost one.  Useful when panels are far apart or when saving
        individual panels.  Default ``False``.
    pct_points : bool, optional
        When ``True``, multiply absolute effect values (and their confidence
        intervals and standard errors) by 100 for display, expressing them as
        **percentage points** (pp).  The x-axis label becomes
        ``"Absolute Effect (pp)"`` and ``show_values`` annotations gain a
        ``"pp"`` suffix.  Has no effect on relative effect columns.
        Default ``False``.
    relative_cap : float, optional
        When displaying relative effects (as standalone labels or in
        ``combine_values`` parentheses), values whose absolute size exceeds
        this threshold are shown as ``>100%`` or ``<-100%`` instead of the
        raw number.  The threshold is expressed as a multiplier (e.g. ``5.0``
        means 500%).  Default ``5.0``.
    combine_values : bool, optional
        When ``True`` and ``show_values=True``, append the *secondary* effect
        in parentheses to each dot annotation.  The secondary effect is the
        one not being plotted:

        - ``effect="absolute"`` → ``+3.0pp (+15.4%)``  (relative in parens)
        - ``effect="relative"`` → ``+15.4% (+3.0pp)``  (absolute pp in parens)

        Also updates the x-axis label to reflect both metrics, e.g.
        ``"Absolute (Relative) Effect (pp)"`` or
        ``"Relative (Absolute) Effect"``.
        Default ``False``.
    save_path : str or path-like, optional
        File path to save the figure.  When ``group_by`` produces multiple
        figures the group key is inserted before the file extension, e.g.
        ``"effects.png"`` becomes ``"effects_US.png"``, ``"effects_EU.png"``.
        Supports any format recognised by matplotlib (``png``, ``pdf``,
        ``svg``, …).  ``None`` (default) skips saving.
    color_direction : bool, optional
        When ``True``, color effects by significance and sign. Default
        ``False``.
    color_palette : dict, optional
        Override effect colors. Keys are ``"sig_pos"``, ``"sig_neg"``,
        ``"nsig_pos"``, ``"nsig_neg"``, and ``"nsig_zero"``. Omitted keys use
        the defaults. Passing a palette automatically enables
        ``color_direction``.

    Returns
    -------
    matplotlib.figure.Figure, dict[str, matplotlib.figure.Figure], or None
        Single figure when *group_by* is ``None``, otherwise a dict mapping
        each group value to its figure.
    """
    if results is None or results.empty:
        return None

    color_direction = color_direction or color_palette is not None
    data = results.copy()

    if outcomes is not None:
        outcomes_list = [outcomes] if isinstance(outcomes, str) else list(outcomes)
        data = data[data["outcome"].isin(outcomes_list)]
        unique_outcomes = [o for o in outcomes_list if o in data["outcome"].values]
    else:
        unique_outcomes = list(data["outcome"].unique())
    if not unique_outcomes:
        return None

    if comparison is not None:
        pairs = [comparison] if isinstance(comparison, tuple) else list(comparison)
        mask = pd.Series(False, index=data.index)
        for t_val, c_val in pairs:
            mask |= (data["treatment_group"] == t_val) & (data["control_group"] == c_val)
        data = data[mask]
    if data.empty:
        return None

    # Suppress rows with degenerate SE (zero, NaN, inf) so the plot is consistent
    # with the pooled estimate, which applies the same validity filter.
    if "standard_error" in data.columns:
        bad_se = ~(data["standard_error"].notna() & np.isfinite(data["standard_error"]) & (data["standard_error"] > 0))
        data.loc[bad_se, "absolute_effect"] = np.nan
        data.loc[bad_se, "relative_effect"] = np.nan

    # Scale absolute effect columns to percentage points for display.
    # Only applies to outcomes whose values live in the [0, 1] range
    # (i.e. proportions / rates).  Outcomes with raw-unit effects (e.g. dollars)
    # are detected automatically and left unscaled.
    if pct_points:
        abs_scale_cols = ["absolute_effect", "abs_effect_lower", "abs_effect_upper", "standard_error"]

        def _is_proportion_outcome(df: pd.DataFrame, outcome: str) -> bool:
            subset = df[df["outcome"] == outcome]
            if "control_value" in subset.columns:
                cv = subset["control_value"].dropna()
                if not cv.empty:
                    return bool((cv >= -_PROPORTION_RANGE_ATOL).all() and (cv <= 1 + _PROPORTION_RANGE_ATOL).all())
            eff = subset["absolute_effect"].dropna()
            return bool(not eff.empty and eff.abs().max() <= 1 + _PROPORTION_RANGE_ATOL)

        pp_outcomes = {o for o in data["outcome"].unique() if _is_proportion_outcome(data, o)}
        mask = data["outcome"].isin(pp_outcomes)
        for col in abs_scale_cols:
            if col in data.columns:
                data.loc[mask, col] = data.loc[mask, col] * 100

        if meta_df is not None:
            meta_df = meta_df.copy()
            meta_mask = (
                meta_df["outcome"].isin(pp_outcomes)
                if "outcome" in meta_df.columns
                else pd.Series(True, index=meta_df.index)
            )
            for col in abs_scale_cols:
                if col in meta_df.columns:
                    meta_df.loc[meta_mask, col] = meta_df.loc[meta_mask, col] * 100

        pct_points = bool(pp_outcomes)  # keep downstream label logic correct

    if value_decimals is None:
        has_relative = any(e == "relative" for e in ([effect] if isinstance(effect, str) else list(effect)))
        value_decimals = 1 if (pct_points or has_relative or combine_values) else 2

    effects: list[str] = [effect] if isinstance(effect, str) else list(effect)

    def _effect_cols(e: str) -> tuple[str, str, str, str]:
        if e == "relative":
            lbl = "Relative (Absolute) Effect" if combine_values else "Relative Effect"
            return "relative_effect", "rel_effect_lower", "rel_effect_upper", lbl
        lbl = "Absolute (Relative) Effect" if combine_values else "Absolute Effect"
        return "absolute_effect", "abs_effect_lower", "abs_effect_upper", lbl

    if len(effects) == 1:
        eff_col, lo_col, hi_col, x_label = _effect_cols(effects[0])
        if lo_col not in data.columns or data[lo_col].isna().all():
            df_col = data["df_resid"] if "df_resid" in data.columns else None
            crit = _critical_value(alpha, df_col)
            data[lo_col] = data[eff_col] - crit * data["standard_error"]
            data[hi_col] = data[eff_col] + crit * data["standard_error"]
        if meta_df is not None:
            meta_df = meta_df.copy()
            if "_label" not in meta_df.columns:
                meta_df["_label"] = "Pooled"
            if lo_col not in meta_df.columns or meta_df[lo_col].isna().all():
                z = stats.norm.ppf(1 - alpha / 2)
                meta_df[lo_col] = meta_df[eff_col] - z * meta_df["standard_error"]
                meta_df[hi_col] = meta_df[eff_col] + z * meta_df["standard_error"]
    else:
        eff_col = lo_col = hi_col = x_label = None
        if meta_df is not None:
            meta_df = meta_df.copy()
            if "_label" not in meta_df.columns:
                meta_df["_label"] = "Pooled"

    group_cols: list[str] = []
    if group_by is not None:
        gc = [group_by] if isinstance(group_by, str) else list(group_by)
        group_cols = [c for c in gc if c in data.columns]

    exp_id = experiment_identifier
    exp_id_list = ([exp_id] if isinstance(exp_id, str) else list(exp_id)) if exp_id else []
    label_cols = [c for c in exp_id_list if c not in group_cols]

    def _build_labels(df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        available = [c for c in label_cols if c in df.columns]
        if available:
            df["_label"] = df[available].astype(str).agg(" | ".join, axis=1)
        elif exp_id_list:
            df["_label"] = "Experiment"
        else:
            df["_label"] = df["treatment_group"].astype(str) + " vs " + df["control_group"].astype(str)

        n_comp = df.groupby(["treatment_group", "control_group"]).ngroups
        if n_comp > 1 and available:
            df["_label"] = (
                df["_label"]
                + "\n("
                + df["treatment_group"].astype(str)
                + " vs "
                + df["control_group"].astype(str)
                + ")"
            )
        return df

    if y == "outcome":
        panel_col = "_label"
        row_col = "outcome"
    else:
        panel_col = "outcome"
        row_col = "_label"

    shared_kw = dict(
        alpha=alpha,
        meta_df=meta_df,
        figsize=figsize,
        show_zero_line=show_zero_line,
        sort_by_magnitude=sort_by_magnitude,
        panel_col=panel_col,
        row_col=row_col,
        panel_titles=panel_titles,
        show_panel_titles=show_panel_titles,
        row_labels=row_labels,
        show_values=show_values,
        value_decimals=value_decimals,
        panel_spacing=panel_spacing,
        repeat_ylabels=repeat_ylabels,
        pct_points=pct_points,
        combine_values=combine_values,
        relative_cap=relative_cap,
        pp_outcomes=pp_outcomes if pct_points else None,
        color_direction=color_direction,
        color_palette=color_palette,
    )

    def _render(labelled: pd.DataFrame, fig_title: str | None, group_meta: pd.DataFrame | None = None) -> plt.Figure:
        # Always recompute the pooled row from the visible data so it is
        # guaranteed to be the IVW of the individual rows shown, regardless
        # of how (or on what dataset) the external meta_df was computed.
        if group_meta is not None and len(effects) == 1:
            sig_col_local = (
                "stat_significance_mcp" if "stat_significance_mcp" in labelled.columns else "stat_significance"
            )
            effective_meta = _make_pooled_meta(labelled, panel_col, eff_col, lo_col, hi_col, sig_col_local, alpha)
        else:
            effective_meta = group_meta  # None or multi-effect passthrough

        kw = {**shared_kw, "meta_df": effective_meta}
        if len(effects) == 1:
            return _render_effects_figure(
                labelled,
                unique_outcomes=unique_outcomes,
                eff_col=eff_col,
                lo_col=lo_col,
                hi_col=hi_col,
                x_label=x_label,
                title=fig_title,
                **kw,
            )
        effect_specs = [_effect_cols(e) for e in effects]
        return _render_multi_effect_figure(
            labelled,
            effect_specs=effect_specs,
            title=fig_title,
            unique_outcomes=unique_outcomes,
            **kw,
        )

    def _filter_meta_for_group(group_key, cols: list[str]) -> pd.DataFrame | None:
        """Return the slice of meta_df relevant to this group, or None if not filterable."""
        if meta_df is None:
            return None
        matching_cols = [c for c in cols if c in meta_df.columns]
        if not matching_cols:
            return None  # meta_df has no group cols — it's a global pool, suppress it
        key_vals = list(group_key) if isinstance(group_key, tuple) else [group_key]
        mask = pd.Series(True, index=meta_df.index)
        for col, val in zip(matching_cols, key_vals[: len(matching_cols)], strict=False):
            mask &= meta_df[col] == val
        filtered = meta_df[mask]
        return filtered if not filtered.empty else None

    if group_cols:
        figures: dict[str, plt.Figure] = {}
        for group_key, group_data in data.groupby(group_cols):
            key_str = " | ".join(str(v) for v in group_key) if isinstance(group_key, tuple) else str(group_key)
            fig_title = title if title is not None else key_str
            labelled = _build_labels(group_data)
            group_meta = _filter_meta_for_group(group_key, group_cols)
            figures[key_str] = _render(labelled, fig_title, group_meta=group_meta)
        if save_path is not None:
            import os

            base, ext = os.path.splitext(save_path)
            ext = ext or ".png"
            for key_str, fig in figures.items():
                safe_key = key_str.replace(" | ", "_").replace(" ", "_")
                fig.savefig(f"{base}_{safe_key}{ext}", bbox_inches="tight")
        return figures

    labelled = _build_labels(data)
    fig = _render(labelled, title, group_meta=meta_df)
    if save_path is not None and fig is not None:
        fig.savefig(save_path, bbox_inches="tight")
    return fig


def plot_overlap(
    data: pd.DataFrame,
    treatment_col: str,
    propensity_col: str,
    group_by: str | list[str] | None = None,
    bw_method: float | None = None,
    grid_size: int = 300,
    show_overlap_region: bool = True,
    show_overlap_coef: bool = True,
    title: str | None = None,
    figsize: tuple | None = None,
    save_path: str | None = None,
) -> plt.Figure | dict[str, plt.Figure] | None:
    """Mirror density plot of propensity scores for common-support diagnostics.

    Treatment scores face upward (blue) and control scores face downward (red).
    Healthy overlap produces wide shared region near propensity score 0.5.

    Parameters
    ----------
    data : pd.DataFrame
        DataFrame containing the propensity score and treatment columns.
        Typically ``analyzer.weights`` after calling ``get_effects()`` with
        ``adjustment="balance"``, or any DataFrame with the required columns.
    treatment_col : str
        Binary treatment indicator column (1 = treated, 0 = control).
    propensity_col : str
        Estimated propensity score column (values in [0, 1]).
    group_by : str or list[str], optional
        Column(s) to split into separate figures — one figure per unique value.
        Returns a ``dict`` keyed by the group value instead of a single figure.
    bw_method : float, optional
        KDE bandwidth.  ``None`` uses Scott's rule (scipy default).
    grid_size : int, optional
        Number of evaluation points for the KDE grid (default 300).
    show_overlap_region : bool, optional
        Shade the region where both densities exceed 5 % of their maximum
        (default ``True``).
    show_overlap_coef : bool, optional
        Annotate the plot with the KDE-based overlap coefficient — the integral
        of ``min(f_treat, f_control)`` over the score range (default ``True``).
    title : str, optional
        Figure title.  When ``group_by`` is set and ``title`` is ``None`` the
        group value is used automatically.
    figsize : tuple, optional
        ``(width, height)`` in inches.  Defaults to ``(7, 4)``.
    save_path : str, optional
        File path to save the figure.  When ``group_by`` produces multiple
        figures the group key is inserted before the extension, e.g.
        ``"overlap.png"`` → ``"overlap_US.png"``.

    Returns
    -------
    matplotlib.figure.Figure, dict[str, matplotlib.figure.Figure], or None
    """
    from matplotlib.ticker import FuncFormatter
    from scipy.stats import gaussian_kde

    if data is None or data.empty:
        return None

    figsize = figsize or (7, 4)

    def _one_figure(subset: pd.DataFrame, fig_title: str | None) -> plt.Figure | None:
        treat_ps = subset.loc[subset[treatment_col] == 1, propensity_col].dropna().values
        ctrl_ps = subset.loc[subset[treatment_col] == 0, propensity_col].dropna().values

        if len(treat_ps) < 2 or len(ctrl_ps) < 2:
            return None

        x_min = min(treat_ps.min(), ctrl_ps.min())
        x_max = max(treat_ps.max(), ctrl_ps.max())
        x_grid = np.linspace(x_min, x_max, grid_size)

        kde_t = gaussian_kde(treat_ps, bw_method=bw_method)
        kde_c = gaussian_kde(ctrl_ps, bw_method=bw_method)
        d_t = kde_t(x_grid)
        d_c = kde_c(x_grid)

        fig, ax = plt.subplots(figsize=figsize)
        ax.set_facecolor("white")

        ax.fill_between(x_grid, d_t, alpha=0.30, color="#2166ac")
        ax.plot(x_grid, d_t, color="#2166ac", lw=1.5, label=f"Treatment (n={len(treat_ps):,})")

        ax.fill_between(x_grid, -d_c, alpha=0.30, color="#d6604d")
        ax.plot(x_grid, -d_c, color="#d6604d", lw=1.5, label=f"Control (n={len(ctrl_ps):,})")

        ax.axhline(0, color=_CLR_ZERO, lw=0.9)

        if show_overlap_region:
            thresh_t = d_t.max() * 0.05
            thresh_c = d_c.max() * 0.05
            overlap_mask = (d_t > thresh_t) & (d_c > thresh_c)
            if overlap_mask.any():
                ax.axvspan(
                    x_grid[overlap_mask][0],
                    x_grid[overlap_mask][-1],
                    alpha=0.08,
                    color="#16a34a",
                    label="Overlap region",
                )

        if show_overlap_coef:
            dx = x_grid[1] - x_grid[0]
            coef = float(np.trapz(np.minimum(d_t, d_c), dx=dx))
            ax.annotate(
                f"Overlap coef. = {coef:.3f}",
                xy=(0.97, 0.97),
                xycoords="axes fraction",
                ha="right",
                va="top",
                fontsize=9,
                color="#475569",
                bbox=dict(boxstyle="round,pad=0.3", fc="white", ec=_CLR_SPINE, lw=0.8),
            )

        ax.yaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{abs(x):.2f}"))
        ax.set_xlabel("Propensity Score", fontsize=10, color="#64748b", labelpad=5)
        ax.set_ylabel("Density", fontsize=10, color="#64748b", labelpad=5)
        ax.set_xlim(x_min - 0.02, x_max + 0.02)

        if fig_title:
            ax.set_title(fig_title, fontsize=11, fontweight="bold", pad=8)

        ax.legend(fontsize=9, frameon=True, framealpha=0.9, edgecolor=_CLR_SPINE)

        for spine in ("top", "right"):
            ax.spines[spine].set_visible(False)
        for spine in ("bottom", "left"):
            ax.spines[spine].set_color(_CLR_SPINE)
            ax.spines[spine].set_linewidth(0.8)

        ax.tick_params(axis="both", labelsize=8.5, colors="#64748b")
        plt.tight_layout()
        return fig

    gc = ([group_by] if isinstance(group_by, str) else list(group_by)) if group_by else []
    gc = [c for c in gc if c in data.columns]

    if gc:
        import os

        figures: dict[str, plt.Figure] = {}
        for group_key, group_data in data.groupby(gc):
            key_str = " | ".join(str(v) for v in group_key) if isinstance(group_key, tuple) else str(group_key)
            fig_title = title if title is not None else key_str
            fig = _one_figure(group_data, fig_title)
            if fig is not None:
                figures[key_str] = fig

        if save_path is not None:
            base, ext = os.path.splitext(save_path)
            ext = ext or ".png"
            for key_str, fig in figures.items():
                safe_key = key_str.replace(" | ", "_").replace(" ", "_")
                fig.savefig(f"{base}_{safe_key}{ext}", bbox_inches="tight")
        return figures

    fig = _one_figure(data, title)
    if fig is not None and save_path is not None:
        fig.savefig(save_path, bbox_inches="tight")
    return fig


def plot_power(
    data: pd.DataFrame,
    comparisons: list[tuple],
    alpha: float = 0.05,
    alternative: str = "two-sided",
    facet_by: str | None = "comparison",
    color_by: str = "effect",
) -> None:
    """
    Plot statistical power by sample size and effect size.

    Parameters
    ----------
    data : pd.DataFrame
        Output of ``PowerSim.grid_sim_power()``.
    comparisons : list of tuple
        List of ``(treatment, control)`` pairs from the ``PowerSim`` instance.
    alpha : float, optional
        Significance level used in the plot title (default 0.05).
    alternative : str, optional
        Hypothesis direction used in the plot title (default ``"two-sided"``).
    facet_by : str or None, optional
        Column whose unique values each get their own subplot
        (default ``"comparison"``).  Pass ``None`` for a single combined plot.
    color_by : str, optional
        Column used to colour lines within each subplot (default ``"effect"``).
        Any column in the grid output is valid, e.g. ``"baseline"`` or ``"compliance"``.
    """
    from matplotlib.lines import Line2D

    value_vars = [str((i, j)) for i, j in comparisons]

    base_cols = [
        "baseline",
        "effect",
        "sample_size",
        "compliance",
        "standard_deviation",
        "variants",
        "comparisons",
        "correction",
        "allocation_ratio",
        "nsim",
        "alpha",
        "alternative",
        "metric",
        "relative_effect",
    ]
    cols = [c for c in base_cols if c in data.columns]

    temp = pd.melt(data, id_vars=cols, var_name="comparison", value_name="power", value_vars=value_vars)

    try:
        temp = temp.sort_values("sample_size")
    except TypeError:
        pass

    facet_values = [None] if facet_by is None else sorted(temp[facet_by].unique(), key=str)

    all_sizes = sorted(temp["sample_size"].unique())
    size_labels = [str(s) for s in all_sizes]

    baselines = sorted(data["baseline"].unique())
    baseline_str = ", ".join(str(b) for b in baselines)

    legend_title = color_by.replace("_", " ").title()

    def _fmt_color(val):
        if color_by == "effect":
            try:
                return f"+{float(val):.3f}"
            except (ValueError, TypeError):
                pass
        return str(val)

    for facet_val in facet_values:
        subset = temp if facet_by is None else temp[temp[facet_by] == facet_val]

        plot_data = subset.copy()
        plot_data["sample_size"] = plot_data["sample_size"].astype(str)

        color_col = f"__{color_by}_fmt"
        plot_data[color_col] = plot_data[color_by].apply(_fmt_color)
        try:
            color_order_raw = sorted(subset[color_by].unique(), key=float)
        except (TypeError, ValueError):
            color_order_raw = sorted(subset[color_by].unique(), key=str)
        color_order = [_fmt_color(v) for v in color_order_raw]

        fig, ax = plt.subplots()
        sns.lineplot(
            x="sample_size",
            y="power",
            hue=color_col,
            hue_order=color_order,
            marker="o",
            errorbar=None,
            data=plot_data,
            legend="full",
            ax=ax,
        )

        ax.axhline(y=0.8, linestyle="--", color="gray", linewidth=1)

        ax.set_xticks(range(len(size_labels)))
        ax.set_xticklabels(size_labels, rotation=45, ha="right")

        handles, labels = ax.get_legend_handles_labels()
        handles.append(Line2D([0], [0], color="gray", linestyle="--", linewidth=1))
        labels.append("80% threshold")
        ax.legend(
            handles=handles,
            labels=labels,
            title=legend_title,
            bbox_to_anchor=(1.05, 1),
            loc="upper left",
        )

        title_suffix = "" if facet_by is None else f"  [{facet_by}={facet_val}]"
        ax.set_title(
            f"Power by Sample Size and Effect Size{title_suffix}\n"
            f"(baseline = {baseline_str},  α = {alpha},  {alternative})"
        )

        ax.set_xlabel("Sample size (per group)")
        ax.set_ylabel("Power")
        ax.set_ylim(0, 1.05)
        ax.grid(axis="y", linestyle="--", alpha=0.4)
        plt.tight_layout()
        plt.show()


def plot_equivalence(
    data: pd.DataFrame,
    outcomes: list[str] | str | None = None,
    figsize: tuple | None = None,
    title: str | None = None,
    show_values: bool = True,
    value_decimals: int = 2,
    sort_by_magnitude: bool = True,
    save_path: str | None = None,
) -> plt.Figure:
    """
    Equivalence test visualization with (1-2alpha) CI against equivalence bounds.

    Displays a Cleveland-style dot plot where each row shows the point estimate
    and the TOST confidence interval.  A shaded band marks the equivalence
    region [-Delta, +Delta].  Dots are color-coded by the ``eq_conclusion`` column.

    Parameters
    ----------
    data : pd.DataFrame
        Results DataFrame containing ``eq_*`` columns from
        :meth:`ExperimentAnalyzer.test_equivalence`.
    outcomes : list[str] or str, optional
        Subset of outcomes to plot. ``None`` plots all.
    figsize : tuple, optional
        Figure size ``(width, height)``.
    title : str, optional
        Overall figure title.
    show_values : bool
        Annotate each row with the numeric effect and conclusion.
    value_decimals : int
        Decimal places for value annotations.
    sort_by_magnitude : bool
        Sort rows by absolute effect magnitude.
    save_path : str, optional
        Save the figure to this path.

    Returns
    -------
    matplotlib.figure.Figure
    """
    required = [
        "eq_ci_lower",
        "eq_ci_upper",
        "eq_bound_lower",
        "eq_bound_upper",
        "eq_conclusion",
        "absolute_effect",
    ]
    missing = [c for c in required if c not in data.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}. Run test_equivalence() first.")

    df = data.copy()

    # Determine row identifier
    if "experiment" in df.columns:
        row_col = "experiment"
    elif "treatment_group" in df.columns:
        row_col = "treatment_group"
    else:
        df["_row"] = range(len(df))
        row_col = "_row"

    # Build row label from treatment_group vs control_group if both exist
    if "treatment_group" in df.columns and "control_group" in df.columns:
        df["_row_label"] = df["treatment_group"].astype(str) + " vs " + df["control_group"].astype(str)
        if "experiment" in df.columns:
            df["_row_label"] = df["experiment"].astype(str) + ": " + df["_row_label"]
        row_col = "_row_label"

    # Filter outcomes
    if "outcome" not in df.columns:
        df["outcome"] = "outcome"
    if outcomes is not None:
        if isinstance(outcomes, str):
            outcomes = [outcomes]
        df = df[df["outcome"].isin(outcomes)]
    if df.empty:
        raise ValueError("No data to plot after filtering outcomes.")

    unique_outcomes = df["outcome"].unique()
    n_panels = len(unique_outcomes)

    # Figure sizing — budget per-panel chrome (bold title, ticks, padding) separately
    # from row content so many-panel stacks don't collapse into overlapping titles.
    if figsize is None:
        total_rows = sum(len(df[df["outcome"] == o]) for o in unique_outcomes)
        per_panel_overhead = 0.85
        row_height = 0.42
        xlabel_overhead = 0.35
        fig_h = max(3.0, per_panel_overhead * n_panels + row_height * total_rows + xlabel_overhead + 0.4)
        fig_w = 8
        figsize = (fig_w, fig_h)

    fig, axes_arr = plt.subplots(n_panels, 1, figsize=figsize, squeeze=False, layout="constrained")
    axes = axes_arr.flatten()

    # Color mapping
    conclusion_colors = {}
    for label in ("equivalent", "non_inferior", "non_superior"):
        conclusion_colors[label] = _CLR_EQ
    for label in ("not_equivalent", "not_non_inferior", "not_non_superior"):
        conclusion_colors[label] = _CLR_NOT_EQ
    for label in (
        "equivalent_with_difference",
        "non_inferior_with_difference",
        "non_superior_with_difference",
    ):
        conclusion_colors[label] = _CLR_EQ_DIFF
    conclusion_colors["inconclusive"] = _CLR_NSIG

    for panel_idx, (ax, outcome_val) in enumerate(zip(axes, unique_outcomes, strict=False)):
        od = df[df["outcome"] == outcome_val].copy()
        if sort_by_magnitude:
            od = od.sort_values(by="absolute_effect", key=abs, ascending=False)

        labels = list(od[row_col])
        effs = list(od["absolute_effect"])
        ci_los = list(od["eq_ci_lower"])
        ci_his = list(od["eq_ci_upper"])
        conclusions = list(od["eq_conclusion"])
        bound_lo = od["eq_bound_lower"].iloc[0] if not od.empty else 0
        bound_hi = od["eq_bound_upper"].iloc[0] if not od.empty else 0

        n_rows = len(labels)
        y_pos = list(range(n_rows))

        ax.set_facecolor("white")
        ax.set_axisbelow(True)

        # Equivalence region band
        ax.axvspan(bound_lo, bound_hi, color=_CLR_EQ_BAND, alpha=0.5, zorder=0)
        # Bound lines
        ax.axvline(
            bound_lo,
            color=_CLR_EQ,
            linestyle="--",
            linewidth=1.0,
            alpha=0.6,
            zorder=1,
        )
        ax.axvline(
            bound_hi,
            color=_CLR_EQ,
            linestyle="--",
            linewidth=1.0,
            alpha=0.6,
            zorder=1,
        )
        # Zero line
        ax.axvline(0, color=_CLR_ZERO, linestyle="-", linewidth=1.0, alpha=0.55, zorder=1)

        # Guide lines
        for i in range(n_rows):
            ax.axhline(i, color=_CLR_GUIDE, linewidth=0.6, linestyle=":", zorder=0)

        for i, (_label, eff, lo, hi, conclusion) in enumerate(
            zip(labels, effs, ci_los, ci_his, conclusions, strict=False)
        ):
            if eff is None or not pd.notna(eff) or not np.isfinite(eff):
                continue

            color = conclusion_colors.get(str(conclusion), _CLR_NSIG)

            # CI bar
            if pd.notna(lo) and pd.notna(hi) and np.isfinite(lo) and np.isfinite(hi):
                ax.plot(
                    [lo, hi],
                    [i, i],
                    color=color,
                    linewidth=1.4,
                    solid_capstyle="butt",
                    zorder=3,
                )
                cap_h = 0.06
                ax.plot(
                    [lo, lo],
                    [i - cap_h, i + cap_h],
                    color=color,
                    linewidth=1.4,
                    zorder=3,
                )
                ax.plot(
                    [hi, hi],
                    [i - cap_h, i + cap_h],
                    color=color,
                    linewidth=1.4,
                    zorder=3,
                )

            # Point estimate
            ax.scatter(
                [eff],
                [i],
                color=color,
                s=45,
                zorder=4,
                marker="o",
                edgecolors="white",
                linewidths=0.5,
            )

            # Value annotation
            if show_values:
                conclusion_label = str(conclusion).replace("_", " ") if pd.notna(conclusion) else ""
                text = f"{eff:+.{value_decimals}f}  [{conclusion_label}]"
                ax.annotate(
                    text,
                    (hi if pd.notna(hi) else eff, i),
                    xytext=(6, 0),
                    textcoords="offset points",
                    va="center",
                    fontsize=7,
                    color=color,
                )

        ax.set_yticks(y_pos)
        ax.set_yticklabels(labels, fontsize=8)
        ax.invert_yaxis()
        if panel_idx == n_panels - 1:
            ax.set_xlabel("Effect (with equivalence bounds)", fontsize=9)

        # Panel title
        panel_title = outcome_val if n_panels > 1 else (title or outcome_val)
        ax.set_title(panel_title, fontsize=10, fontweight="bold", loc="left")

        # Spine styling (matching plot_effects)
        for spine in ax.spines.values():
            spine.set_color(_CLR_SPINE)
            spine.set_linewidth(0.8)
        ax.tick_params(colors=_CLR_SPINE, labelsize=8)

    if title and n_panels > 1:
        fig.suptitle(title, fontsize=12, fontweight="bold")

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")

    return fig
