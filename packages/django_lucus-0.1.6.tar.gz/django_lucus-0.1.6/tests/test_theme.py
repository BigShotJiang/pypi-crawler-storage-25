from lucus.theme import bundled_scheme_slugs, is_valid_scheme_slug


def test_bundled_schemes_include_default():
    slugs = bundled_scheme_slugs()
    assert "olivia" in slugs
    assert len(slugs) >= 5


def test_scheme_slug_validation():
    assert is_valid_scheme_slug("olivia")
    assert not is_valid_scheme_slug("../evil")
    assert not is_valid_scheme_slug("")
