import pytest
from django.contrib.auth import get_user_model
from django.urls import reverse


@pytest.mark.django_db
def test_save_admin_ui_persists_preference(client):
    User = get_user_model()
    user = User.objects.create_user(
        "staff",
        "staff@example.com",
        "pass",
        is_staff=True,
        is_superuser=True,
    )
    client.force_login(user)
    url = reverse("admin:lucus_save_ui")
    response = client.post(
        url,
        {
            "color_scheme": "github",
            "appearance": "dark",
            "next": "/admin/",
        },
    )
    assert response.status_code == 302
    assert response.url == "/admin/"
    from lucus.models import LucusAdminUiPreference

    pref = LucusAdminUiPreference.objects.get(user=user)
    assert pref.color_scheme == "github"
    assert pref.appearance == "dark"
