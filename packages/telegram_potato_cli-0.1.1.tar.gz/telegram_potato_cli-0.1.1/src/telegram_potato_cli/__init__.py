"""Telegram Potato CLI."""

__version__ = "0.1.1"
