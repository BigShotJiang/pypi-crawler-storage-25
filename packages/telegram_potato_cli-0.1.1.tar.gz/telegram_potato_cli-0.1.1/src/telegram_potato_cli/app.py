from __future__ import annotations

import asyncio
import curses
import getpass
import json
import os
import shlex
import shutil
import subprocess
import sys
import textwrap
import time
from contextlib import suppress
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from telethon import TelegramClient, events
from telethon.errors import SessionPasswordNeededError
from telethon.tl.types import Message, User

APP = "telegram-potato-cli"
CHAT_USERNAME = "RooniChat"
CHAT_ID = 2863094147
MAX_MESSAGES = 220
MIN_WIDTH = 56
MIN_HEIGHT = 16
AVATAR_W = 6
AVATAR_H = 3
AVATAR_JOBS = 2


def data_dir() -> Path:
    root = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    path = root / APP
    path.mkdir(parents=True, exist_ok=True)
    return path


def config_path() -> Path:
    return data_dir() / "config.json"


def downloads_dir() -> Path:
    path = Path.home() / "Downloads" / "telegram-potato"
    path.mkdir(parents=True, exist_ok=True)
    return path


def avatars_dir() -> Path:
    path = data_dir() / "avatars"
    path.mkdir(parents=True, exist_ok=True)
    return path


def load_config() -> dict[str, Any]:
    path = config_path()
    if not path.exists():
        return {}
    with suppress(Exception):
        return json.loads(path.read_text("utf-8"))
    return {}


def save_config(config: dict[str, Any]) -> None:
    config_path().write_text(json.dumps(config, indent=2), "utf-8")
    config_path().chmod(0o600)


def clear() -> None:
    print("\033[2J\033[H", end="")


def banner() -> None:
    clear()
    print("╔══════════════════════════════════════════════╗")
    print("║        TELEGRAM POTATO CLI / DEBIAN         ║")
    print("║     один чат, мало RAM, максимум пользы     ║")
    print("╚══════════════════════════════════════════════╝")
    print()


def ask_api_config() -> tuple[int, str]:
    config = load_config()
    api_id = config.get("api_id")
    api_hash = config.get("api_hash")
    if api_id and api_hash:
        return int(api_id), str(api_hash)

    banner()
    print("Первый запуск. Нужны Telegram API ID и API HASH с my.telegram.org.")
    print("Они сохранятся локально в ~/.local/share/telegram-potato-cli/config.json")
    print()
    while True:
        raw = input("API ID: ").strip()
        if raw.isdigit():
            api_id = int(raw)
            break
        print("API ID должен быть числом.")
    while True:
        api_hash = input("API HASH: ").strip()
        if api_hash:
            break
    config.update({"api_id": api_id, "api_hash": api_hash})
    save_config(config)
    return api_id, api_hash


def make_client() -> TelegramClient:
    api_id, api_hash = ask_api_config()
    session = str(data_dir() / "potato")
    return TelegramClient(session, api_id, api_hash)


async def qr_login(client: TelegramClient) -> bool:
    try:
        import qrcode
    except Exception:
        print("qrcode не установлен, QR-вход недоступен.")
        return False

    qr = await client.qr_login()
    print()
    print("Отсканируй QR в Telegram: Настройки -> Устройства -> Подключить устройство")
    print()
    code = qrcode.QRCode(border=1)
    code.add_data(qr.url)
    code.make(fit=True)
    code.print_ascii(tty=True)
    print()
    print("Если QR не читается, открой ссылку:")
    print(qr.url)
    print()
    print("Жду вход 90 секунд...")
    try:
        await asyncio.wait_for(qr.wait(), timeout=90)
        return True
    except asyncio.TimeoutError:
        print("QR устарел.")
        return False
    except SessionPasswordNeededError:
        password = getpass.getpass("Пароль 2FA: ")
        await client.sign_in(password=password)
        return True


async def phone_login(client: TelegramClient) -> None:
    phone = input("Телефон (+79990000000): ").strip()
    sent = await client.send_code_request(phone)
    code = input("Код из Telegram/SMS: ").strip().replace(" ", "")
    try:
        await client.sign_in(phone=phone, code=code, phone_code_hash=sent.phone_code_hash)
    except SessionPasswordNeededError:
        password = getpass.getpass("Пароль 2FA: ")
        await client.sign_in(password=password)


async def ensure_login(client: TelegramClient) -> None:
    await client.connect()
    if await client.is_user_authorized():
        return
    banner()
    print("Вход в Telegram")
    print()
    print("1 - QR code")
    print("2 - телефон + код")
    print()
    choice = input("Выбор [1/2]: ").strip()
    if choice == "1":
        ok = await qr_login(client)
        if ok:
            return
        print()
        print("Перехожу на вход по телефону.")
    await phone_login(client)


def safe_text(value: Any, width: int) -> str:
    text = str(value or "")
    text = text.replace("\n", " ").replace("\r", " ")
    if len(text) > width:
        return text[: max(0, width - 1)] + "…"
    return text


def clean_multiline(value: Any) -> str:
    text = str(value or "")
    text = text.replace("\r", "")
    return "\n".join(part.rstrip() for part in text.splitlines()).strip()


def initials(name: str) -> str:
    parts = [p for p in name.replace("_", " ").split() if p]
    if not parts:
        return "??"
    if len(parts) == 1:
        return parts[0][:2].upper()
    return (parts[0][:1] + parts[1][:1]).upper()


def xterm_color(r: int, g: int, b: int) -> int:
    if max(r, g, b) - min(r, g, b) < 10:
        gray = int(round(((r + g + b) / 3 - 8) / 10))
        return 232 + max(0, min(23, gray))
    rr = int(round(r / 255 * 5))
    gg = int(round(g / 255 * 5))
    bb = int(round(b / 255 * 5))
    return 16 + 36 * rr + 6 * gg + bb


def fit_line(text: str, width: int) -> str:
    if width <= 0:
        return ""
    return safe_text(text, width).ljust(width)


def media_label(msg: Message) -> str:
    if not msg.media:
        return ""
    name = None
    with suppress(Exception):
        name = msg.file.name
    kind = "media"
    with suppress(Exception):
        kind = msg.file.mime_type or kind
    size = ""
    with suppress(Exception):
        if msg.file.size:
            size = f" {msg.file.size // 1024}KB"
    return f"[{kind}{size}{': ' + name if name else ''}]"


def file_kind(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".tiff"}:
        return "фото"
    if ext in {".mp4", ".mkv", ".webm", ".mov", ".avi", ".m4v"}:
        return "видео"
    if ext in {".mp3", ".ogg", ".flac", ".wav", ".m4a", ".opus"}:
        return "аудио"
    return "файл"


def normalize_drop_path(text: str) -> Path | None:
    raw = text.strip()
    if not raw:
        return None
    if raw.startswith("file://"):
        raw = raw[7:]
    raw = raw.strip("'\"")
    path = Path(raw).expanduser()
    if path.exists():
        return path
    return None


@dataclass
class ChatLine:
    msg: Message
    sender_name: str
    sender_username: str
    sender_id: int | None
    mine: bool
    line_count: int = 1


@dataclass
class UiState:
    lines: list[ChatLine] = field(default_factory=list)
    input_text: str = ""
    input_pos: int = 0
    scroll: int = 0
    selected: int = 0
    status: str = "готов"
    typing: str = ""
    help_open: bool = True
    running: bool = True
    dirty: bool = True
    command_mode: bool = False
    show_meta: bool = True


class AvatarCache:
    def __init__(self, client: TelegramClient) -> None:
        self.client = client
        self.items: dict[int, list[list[int]] | None] = {}
        self.pending: set[int] = set()
        self.enabled = True
        self.sem = asyncio.Semaphore(AVATAR_JOBS)

    def get(self, sender_id: int | None) -> list[list[int]] | None:
        if sender_id is None:
            return None
        return self.items.get(sender_id)

    def request(self, sender: Any, dirty: Any) -> None:
        sender_id = getattr(sender, "id", None)
        if sender_id is None or sender_id in self.items or sender_id in self.pending:
            return
        self.pending.add(sender_id)
        asyncio.create_task(self._load(sender, sender_id, dirty))

    async def _load(self, sender: Any, sender_id: int, dirty: Any) -> None:
        async with self.sem:
            try:
                photo = avatars_dir() / f"{sender_id}.jpg"
                if not photo.exists():
                    path = await self.client.download_profile_photo(sender, file=str(photo))
                    if not path:
                        self.items[sender_id] = None
                        return
                self.items[sender_id] = await asyncio.to_thread(self._render, photo)
            except Exception:
                self.items[sender_id] = None
            finally:
                self.pending.discard(sender_id)
                dirty()

    def _render(self, photo: Path) -> list[list[int]] | None:
        try:
            from PIL import Image
        except Exception:
            self.enabled = False
            return None
        with Image.open(photo) as img:
            img = img.convert("RGB")
            img.thumbnail((96, 96))
            side = min(img.size)
            left = (img.width - side) // 2
            top = (img.height - side) // 2
            img = img.crop((left, top, left + side, top + side))
            img = img.resize((AVATAR_W, AVATAR_H), Image.Resampling.LANCZOS)
            rows: list[list[int]] = []
            for y in range(AVATAR_H):
                row: list[int] = []
                for x in range(AVATAR_W):
                    row.append(xterm_color(*img.getpixel((x, y))))
                rows.append(row)
            return rows


class PotatoTui:
    def __init__(self, client: TelegramClient, entity: Any) -> None:
        self.client = client
        self.entity = entity
        self.me_id: int | None = None
        self.state = UiState()
        self.loop = asyncio.get_running_loop()
        self.last_typing = 0.0
        self.last_progress = 0.0
        self.avatars = AvatarCache(client)
        self.bg_pairs: dict[int, int] = {}
        self.next_pair = 40
        self.chat_title = getattr(entity, "title", None) or getattr(entity, "username", None) or CHAT_USERNAME
        self.chat_username = getattr(entity, "username", None) or CHAT_USERNAME
        self.chat_id = getattr(entity, "id", None)
        self.chat_avatar: list[list[int]] | None = None
        self.refresh_task: asyncio.Task[None] | None = None

    async def load_initial(self) -> None:
        me = await self.client.get_me()
        self.me_id = me.id
        await self.load_chat_avatar()
        rows: list[ChatLine] = []
        async for msg in self.client.iter_messages(self.entity, limit=80, reverse=True):
            rows.append(await self.to_line(msg))
        self.state.lines = rows[-MAX_MESSAGES:]
        self.state.selected = max(0, len(self.state.lines) - 1)
        self.state.status = "чат загружен"

    async def to_line(self, msg: Message) -> ChatLine:
        sender = await msg.get_sender()
        name = "?"
        username = ""
        sender_id = getattr(sender, "id", None)
        if isinstance(sender, User):
            pieces = [sender.first_name or "", sender.last_name or ""]
            name = " ".join(x for x in pieces if x).strip() or sender.username or str(sender.id)
            username = f"@{sender.username}" if sender.username else f"id:{sender.id}"
        elif sender is not None:
            name = getattr(sender, "title", None) or getattr(sender, "username", None) or str(getattr(sender, "id", "?"))
            user = getattr(sender, "username", None)
            username = f"@{user}" if user else f"id:{getattr(sender, 'id', '?')}"
        if sender is not None:
            self.avatars.request(sender, self.mark_dirty)
        mine = bool(self.me_id and msg.sender_id == self.me_id)
        return ChatLine(msg=msg, sender_name=name, sender_username=username, sender_id=sender_id, mine=mine)

    def mark_dirty(self) -> None:
        self.state.dirty = True

    async def load_chat_avatar(self) -> None:
        try:
            photo = avatars_dir() / f"chat_{self.chat_id or CHAT_USERNAME}.jpg"
            if not photo.exists():
                path = await self.client.download_profile_photo(self.entity, file=str(photo))
                if not path:
                    return
            self.chat_avatar = await asyncio.to_thread(self.avatars._render, photo)
        except Exception:
            self.chat_avatar = None

    def register_events(self) -> None:
        @self.client.on(events.NewMessage(chats=self.entity))
        async def on_new(event: events.NewMessage.Event) -> None:
            self.state.lines.append(await self.to_line(event.message))
            self.state.lines = self.state.lines[-MAX_MESSAGES:]
            self.state.selected = len(self.state.lines) - 1
            self.state.scroll = 0
            self.state.status = "новое сообщение"
            self.state.dirty = True

        @self.client.on(events.MessageEdited(chats=self.entity))
        async def on_edit(event: events.MessageEdited.Event) -> None:
            for i, line in enumerate(self.state.lines):
                if line.msg.id == event.message.id:
                    self.state.lines[i] = await self.to_line(event.message)
                    self.state.status = "сообщение изменено"
                    self.state.dirty = True
                    break

        @self.client.on(events.MessageDeleted(chats=self.entity))
        async def on_delete(event: events.MessageDeleted.Event) -> None:
            deleted = set(event.deleted_ids)
            before = len(self.state.lines)
            self.state.lines = [line for line in self.state.lines if line.msg.id not in deleted]
            if len(self.state.lines) != before:
                self.state.selected = min(self.state.selected, max(0, len(self.state.lines) - 1))
                self.state.status = "сообщение удалено"
                self.state.dirty = True

        @self.client.on(events.MessageRead(chats=self.entity))
        async def on_read(event: events.MessageRead.Event) -> None:
            if event.outbox:
                self.state.status = f"прочитано до #{event.max_id}"
                self.state.dirty = True

        @self.client.on(events.UserUpdate)
        async def on_user(event: events.UserUpdate.Event) -> None:
            if getattr(event, "typing", False):
                user = await event.get_user()
                if user:
                    self.state.typing = f"{getattr(user, 'first_name', None) or getattr(user, 'username', 'кто-то')} печатает..."
                    self.state.dirty = True
                    self.loop.call_later(4, self.clear_typing)
            elif getattr(event, "online", None):
                user = await event.get_user()
                if user:
                    name = getattr(user, "first_name", None) or getattr(user, "username", "кто-то")
                    self.state.status = f"{name} онлайн"
                    self.state.dirty = True

    def clear_typing(self) -> None:
        self.state.typing = ""
        self.state.dirty = True

    async def send_typing(self) -> None:
        now = time.monotonic()
        if now - self.last_typing < 3:
            return
        self.last_typing = now
        with suppress(Exception):
            async with self.client.action(self.entity, "typing"):
                await asyncio.sleep(0.1)

    async def send_current(self) -> None:
        text = self.state.input_text.strip()
        if not text:
            return
        self.state.input_text = ""
        self.state.input_pos = 0
        self.state.dirty = True
        if text.startswith(":"):
            asyncio.create_task(self.command(text))
            return
        dropped = normalize_drop_path(text)
        if dropped:
            asyncio.create_task(self.send_file(dropped))
            return
        self.state.status = "отправляю сообщение..."
        asyncio.create_task(self.send_text(text))

    async def send_text(self, text: str) -> None:
        try:
            await self.client.send_message(self.entity, text)
            self.state.status = "сообщение отправлено"
        except Exception as exc:
            self.state.status = f"ошибка отправки: {exc}"
        self.state.dirty = True

    async def command(self, raw: str) -> None:
        args = shlex.split(raw[1:])
        if not args:
            return
        cmd = args[0].lower()
        try:
            if cmd in {"q", "quit", "exit"}:
                self.state.running = False
            elif cmd in {"h", "help"}:
                self.state.help_open = not self.state.help_open
            elif cmd in {"m", "meta"}:
                self.state.show_meta = not self.state.show_meta
            elif cmd in {"file", "send", "photo"} and len(args) >= 2:
                path = Path(" ".join(args[1:])).expanduser()
                await self.send_file(path)
            elif cmd in {"dl", "download"}:
                await self.download_selected()
            elif cmd in {"open", "view"}:
                await self.open_selected()
            elif cmd == "edit":
                await self.edit_selected(" ".join(args[1:]))
            elif cmd == "refresh":
                await self.load_initial()
            else:
                self.state.status = f"неизвестная команда: {cmd}"
        except Exception as exc:
            self.state.status = f"ошибка: {exc}"
        self.state.dirty = True

    async def send_file(self, path: Path) -> None:
        if not path.exists():
            self.state.status = f"нет файла: {path}"
            return
        kind = file_kind(path)
        self.state.status = f"отправляю {kind}: {path.name}"
        self.state.dirty = True

        def progress(done: int, total: int) -> None:
            if total <= 0:
                return
            now = time.monotonic()
            if done < total and now - self.last_progress < 0.12:
                return
            self.last_progress = now
            pct = int(done * 100 / total)
            self.state.status = f"отправляю {kind}: {pct}%"
            self.state.dirty = True

        await self.client.send_file(self.entity, str(path), caption="", progress_callback=progress)
        self.state.status = f"{kind} отправлен: {path.name}"

    async def download_selected(self) -> Path | None:
        if not self.state.lines:
            return None
        msg = self.state.lines[self.state.selected].msg
        if not msg.media:
            self.state.status = "у сообщения нет медиа"
            return None
        self.state.status = "скачиваю медиа..."
        self.state.dirty = True

        def progress(done: int, total: int) -> None:
            if total <= 0:
                return
            now = time.monotonic()
            if done < total and now - self.last_progress < 0.12:
                return
            self.last_progress = now
            self.state.status = f"скачиваю медиа: {int(done * 100 / total)}%"
            self.state.dirty = True

        path = await msg.download_media(file=str(downloads_dir()), progress_callback=progress)
        if not path:
            self.state.status = "не удалось скачать"
            return None
        self.state.status = f"скачано: {path}"
        return Path(path)

    async def open_selected(self) -> None:
        path = await self.download_selected()
        if not path:
            return
        opener = shutil.which("xdg-open") or shutil.which("see") or shutil.which("open")
        if opener:
            subprocess.Popen([opener, str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self.state.status = f"открываю: {path.name}"
        else:
            self.state.status = f"файл: {path}"

    async def edit_selected(self, new_text: str) -> None:
        if not new_text:
            self.state.status = "используй :edit новый текст"
            return
        if not self.state.lines:
            return
        msg = self.state.lines[self.state.selected].msg
        if not msg.out:
            self.state.status = "можно редактировать только свои сообщения"
            return
        await self.client.edit_message(self.entity, msg.id, new_text)
        self.state.status = "изменено"

    def draw(self, stdscr: Any) -> None:
        h, w = stdscr.getmaxyx()
        stdscr.erase()
        curses.curs_set(1)
        self.ensure_colors()
        if h < MIN_HEIGHT or w < MIN_WIDTH:
            stdscr.addnstr(0, 0, f"Terminal too small: need {MIN_WIDTH}x{MIN_HEIGHT}", w)
            stdscr.refresh()
            return

        self.draw_header(stdscr, w)

        help_h = 7 if self.state.help_open and h > 24 else 0
        if help_h:
            self.draw_help(stdscr, 4, w)

        input_h = 4
        chat_top = 4 + help_h
        chat_bottom = h - input_h
        self.draw_messages(stdscr, chat_top, chat_bottom, w)
        self.draw_input(stdscr, h - input_h, w)
        stdscr.refresh()
        self.state.dirty = False

    def draw_header(self, stdscr: Any, w: int) -> None:
        title = f"{self.chat_title}  @{self.chat_username}"
        subtitle = f"chat id:{self.chat_id or CHAT_ID}  one-chat terminal client"
        right = self.state.typing or self.state.status
        for row in range(3):
            stdscr.addnstr(row, 0, " " * w, w, curses.color_pair(1) | curses.A_BOLD)
        self.paint_header_avatar(stdscr)
        stdscr.addnstr(0, 14, safe_text(title, max(1, w - 16)), max(1, w - 16), curses.color_pair(1) | curses.A_BOLD)
        stdscr.addnstr(1, 14, safe_text(subtitle, max(1, w - 16)), max(1, w - 16), curses.color_pair(1))
        stdscr.addnstr(2, 14, safe_text(right, max(1, w - 16)), max(1, w - 16), curses.color_pair(1) | curses.A_BOLD)
        avatar_note = "avatars:on" if self.avatars.enabled else "avatars:initials"
        header = f" F1 помощь  ↑↓ выбор  PgUp/PgDn лента  Ctrl+S файл  Ctrl+O открыть  Esc выход  {avatar_note}"
        stdscr.addnstr(3, 0, fit_line(header, w), w, curses.color_pair(5))

    def paint_header_avatar(self, stdscr: Any) -> None:
        if self.chat_avatar:
            for row_idx, row in enumerate(self.chat_avatar):
                for col_idx, color in enumerate(row):
                    with suppress(curses.error):
                        stdscr.addnstr(row_idx, 1 + col_idx * 2, "  ", 2, self.bg_pair(color))
            return
        label = initials(str(self.chat_title)).center(AVATAR_W * 2)
        attr = curses.color_pair(6) | curses.A_BOLD
        with suppress(curses.error):
            stdscr.addnstr(0, 1, "┌" + "─" * (AVATAR_W * 2 - 2) + "┐", AVATAR_W * 2, attr)
            stdscr.addnstr(1, 1, fit_line(label, AVATAR_W * 2), AVATAR_W * 2, attr)
            stdscr.addnstr(2, 1, "└" + "─" * (AVATAR_W * 2 - 2) + "┘", AVATAR_W * 2, attr)

    def draw_help(self, stdscr: Any, y: int, w: int) -> None:
        keys = [
            "Enter отправить текст. Ctrl+S отправить файл по пути из поля ввода. Ctrl+D скачать медиа. Ctrl+O открыть.",
            "Ctrl+E редактировать выбранное свое сообщение. Up/Down выбирают сообщение, PgUp/PgDn листают историю.",
            "Drag-and-drop: перетащи файл в терминал, путь вставится в поле; нажми Ctrl+S или введи :file путь.",
            "Команды: :file /path | :photo /path | :dl | :open | :edit текст | :meta | :refresh | :quit",
        ]
        for i in range(6):
            stdscr.addnstr(y + i, 1, " " * max(0, w - 2), max(0, w - 2), curses.color_pair(6))
        stdscr.addnstr(y, 2, " Управление ", max(0, w - 4), curses.color_pair(6) | curses.A_BOLD)
        for i, line in enumerate(keys, 1):
            stdscr.addnstr(y + i, 2, safe_text(line, w - 4), max(0, w - 4), curses.color_pair(6))

    def draw_messages(self, stdscr: Any, top: int, bottom: int, w: int) -> None:
        for y in range(top, bottom):
            with suppress(curses.error):
                stdscr.addnstr(y, 0, " " * w, w)
        height = max(1, bottom - top)
        blocks = self.visible_blocks(w, height)
        y = bottom
        for idx, block in reversed(blocks):
            y -= max(len(block) + 2, AVATAR_H)
            if y < top:
                break
            line = self.state.lines[idx]
            selected = idx == self.state.selected
            self.paint_block(stdscr, y, w, line, block, selected)

    def draw_input(self, stdscr: Any, y: int, w: int) -> None:
        stdscr.addnstr(y, 0, "─" * w, w, curses.color_pair(5))
        prompt = "Сообщение> "
        text_w = max(1, w - len(prompt) - 1)
        cursor = max(0, min(self.state.input_pos, len(self.state.input_text)))
        start = max(0, cursor - text_w + 1)
        view = self.state.input_text[start : start + text_w]
        stdscr.addnstr(y + 1, 0, prompt, w, curses.A_BOLD)
        stdscr.addnstr(y + 1, len(prompt), view.ljust(text_w), text_w)
        cursor_x = len(prompt) + cursor - start
        with suppress(curses.error):
            stdscr.move(y + 1, min(w - 1, cursor_x))
        hint = "Ctrl+S send file | Ctrl+D download | Ctrl+O open | Ctrl+E edit | :help"
        stdscr.addnstr(y + 2, 0, fit_line(hint, w), w, curses.color_pair(5))
        stdscr.addnstr(y + 3, 0, fit_line("Статус: " + self.state.status, w), w, curses.color_pair(2))

    def message_body(self, line: ChatLine) -> str:
        msg = line.msg
        body = clean_multiline(msg.message) or media_label(msg) or "<service>"
        if msg.media and msg.message:
            body = f"{body}\n{media_label(msg)}"
        return body

    def format_block(self, idx: int, w: int) -> list[str]:
        line = self.state.lines[idx]
        msg = line.msg
        bubble_w = min(74, max(34, w - 18))
        inner = max(12, bubble_w - 4)
        name = safe_text(line.sender_name, 24)
        stamp = msg.date.strftime("%H:%M") if msg.date else "--:--"
        edited = " edited" if getattr(msg, "edit_date", None) else ""
        media = " media" if msg.media else ""
        tag = safe_text(line.sender_username, 18)
        head = f"{initials(name):>2}  {name} {tag}  {stamp}{edited}{media}"
        rows = [safe_text(head, inner)]
        for raw in self.message_body(line).splitlines() or [""]:
            wrapped = textwrap.wrap(raw, width=inner, replace_whitespace=False, drop_whitespace=False) or [""]
            rows.extend(wrapped[:12])
        if len(rows) > 14:
            rows = rows[:13] + ["..."]
        return rows

    def visible_blocks(self, w: int, height: int) -> list[tuple[int, list[str]]]:
        if not self.state.lines:
            return []
        self.state.selected = max(0, min(self.state.selected, len(self.state.lines) - 1))
        end = max(0, len(self.state.lines) - self.state.scroll)
        if end <= self.state.selected:
            end = self.state.selected + 1
        used = 0
        blocks: list[tuple[int, list[str]]] = []
        for idx in range(end - 1, -1, -1):
            block = self.format_block(idx, w)
            block_h = max(len(block) + 2, AVATAR_H)
            if blocks and used + block_h > height:
                break
            used += block_h
            blocks.append((idx, block))
            if used >= height:
                break
        return list(reversed(blocks))

    def paint_block(self, stdscr: Any, y: int, w: int, line: ChatLine, rows: list[str], selected: bool) -> None:
        bubble_w = min(74, max(34, w - 18))
        inner = bubble_w - 4
        avatar_space = AVATAR_W * 2 + 2
        x = max(1, w - bubble_w - avatar_space - 2) if line.mine and w > 90 else avatar_space + 1
        attr = curses.color_pair(3 if line.mine else self.sender_pair(line.sender_name))
        if selected:
            attr |= curses.A_REVERSE
        top = "┌" + "─" * (bubble_w - 2) + "┐"
        bottom = "└" + "─" * (bubble_w - 2) + "┘"
        with suppress(curses.error):
            stdscr.addnstr(y, x, top, bubble_w, attr)
        for offset, row in enumerate(rows, 1):
            with suppress(curses.error):
                stdscr.addnstr(y + offset, x, "│ " + fit_line(row, inner) + " │", bubble_w, attr)
        with suppress(curses.error):
            stdscr.addnstr(y + len(rows) + 1, x, bottom, bubble_w, attr)
        self.paint_avatar(stdscr, y, x, bubble_w, line, selected)

    def paint_avatar(self, stdscr: Any, y: int, bubble_x: int, bubble_w: int, line: ChatLine, selected: bool) -> None:
        avatar = self.avatars.get(line.sender_id)
        term_w = stdscr.getmaxyx()[1]
        if line.mine and bubble_x + bubble_w + AVATAR_W * 2 + 1 < term_w:
            x = bubble_x + bubble_w + 1
        else:
            x = max(0, bubble_x - AVATAR_W * 2 - 1)
        if avatar:
            for row_idx, row in enumerate(avatar):
                for col_idx, color in enumerate(row):
                    attr = self.bg_pair(color)
                    if selected:
                        attr |= curses.A_REVERSE
                    with suppress(curses.error):
                        stdscr.addnstr(y + row_idx, x + col_idx * 2, "  ", 2, attr)
            return
        label = initials(line.sender_name).center(AVATAR_W * 2)
        attr = curses.color_pair(self.sender_pair(line.sender_name))
        if selected:
            attr |= curses.A_REVERSE
        with suppress(curses.error):
            stdscr.addnstr(y, x, "┌" + "─" * (AVATAR_W * 2 - 2) + "┐", AVATAR_W * 2, attr)
            stdscr.addnstr(y + 1, x, fit_line(label, AVATAR_W * 2), AVATAR_W * 2, attr | curses.A_BOLD)
            stdscr.addnstr(y + 2, x, "└" + "─" * (AVATAR_W * 2 - 2) + "┘", AVATAR_W * 2, attr)

    def bg_pair(self, color: int) -> int:
        if not curses.has_colors():
            return curses.A_NORMAL
        if curses.COLORS < 256:
            color = self.basic_color(color)
        if color not in self.bg_pairs:
            pair = self.next_pair
            max_pairs = getattr(curses, "COLOR_PAIRS", 64)
            if pair >= max_pairs:
                return curses.color_pair(4)
            with suppress(curses.error):
                curses.init_pair(pair, curses.COLOR_BLACK, color)
            self.bg_pairs[color] = pair
            self.next_pair += 1
        return curses.color_pair(self.bg_pairs[color])

    def basic_color(self, color: int) -> int:
        if color < 16:
            return color % 8
        idx = color - 16
        r = idx // 36
        g = (idx // 6) % 6
        b = idx % 6
        if r >= g and r >= b:
            return curses.COLOR_RED if r > 2 else curses.COLOR_BLACK
        if g >= r and g >= b:
            return curses.COLOR_GREEN
        if b >= r and b >= g:
            return curses.COLOR_BLUE
        return curses.COLOR_WHITE

    def sender_pair(self, name: str) -> int:
        pairs = [4, 7, 8, 9, 10, 11]
        return pairs[sum(ord(ch) for ch in name) % len(pairs)]

    def ensure_colors(self) -> None:
        if not curses.has_colors():
            return
        curses.start_color()
        curses.use_default_colors()
        curses.init_pair(1, curses.COLOR_BLACK, curses.COLOR_CYAN)
        curses.init_pair(2, curses.COLOR_YELLOW, -1)
        curses.init_pair(3, curses.COLOR_GREEN, -1)
        curses.init_pair(4, curses.COLOR_WHITE, -1)
        curses.init_pair(5, curses.COLOR_CYAN, -1)
        curses.init_pair(6, curses.COLOR_BLACK, curses.COLOR_YELLOW)
        curses.init_pair(7, curses.COLOR_MAGENTA, -1)
        curses.init_pair(8, curses.COLOR_BLUE, -1)
        curses.init_pair(9, curses.COLOR_RED, -1)
        curses.init_pair(10, curses.COLOR_YELLOW, -1)
        curses.init_pair(11, curses.COLOR_CYAN, -1)

    async def input_loop(self, stdscr: Any) -> None:
        stdscr.nodelay(True)
        stdscr.keypad(True)
        while self.state.running:
            if self.state.dirty:
                self.draw(stdscr)
            try:
                key = stdscr.get_wch()
            except curses.error:
                await asyncio.sleep(0.01)
                continue
            if isinstance(key, str):
                await self.handle_char(key)
            else:
                await self.handle_key(key)
            self.state.dirty = True

    async def handle_char(self, ch: str) -> None:
        if ch in {"\n", "\r"}:
            await self.send_current()
        elif ch == "\x1b":
            self.state.running = False
        elif ch == "\x7f":
            if self.state.input_pos > 0:
                i = self.state.input_pos - 1
                self.state.input_text = self.state.input_text[:i] + self.state.input_text[self.state.input_pos :]
                self.state.input_pos -= 1
        elif ch == "\x13":
            path = Path(self.state.input_text.strip().strip("'\"")).expanduser()
            self.state.input_text = ""
            self.state.input_pos = 0
            asyncio.create_task(self.send_file(path))
        elif ch == "\x04":
            asyncio.create_task(self.download_selected())
        elif ch == "\x0f":
            asyncio.create_task(self.open_selected())
        elif ch == "\x05":
            if self.state.lines:
                current = self.state.lines[self.state.selected].msg.message or ""
                self.state.input_text = ":edit " + current
                self.state.input_pos = len(self.state.input_text)
        elif ch.isprintable():
            i = self.state.input_pos
            self.state.input_text = self.state.input_text[:i] + ch + self.state.input_text[i:]
            self.state.input_pos += 1
            asyncio.create_task(self.send_typing())

    async def handle_key(self, key: int) -> None:
        if key == curses.KEY_F1:
            self.state.help_open = not self.state.help_open
        elif key == curses.KEY_UP:
            self.state.selected = max(0, self.state.selected - 1)
            self.focus_selected()
        elif key == curses.KEY_DOWN:
            self.state.selected = min(max(0, len(self.state.lines) - 1), self.state.selected + 1)
            self.focus_selected()
        elif key == curses.KEY_PPAGE:
            self.state.scroll = min(len(self.state.lines), self.state.scroll + 10)
            self.state.selected = max(0, len(self.state.lines) - self.state.scroll - 1)
        elif key == curses.KEY_NPAGE:
            self.state.scroll = max(0, self.state.scroll - 10)
            self.state.selected = max(0, len(self.state.lines) - self.state.scroll - 1)
        elif key == curses.KEY_HOME:
            self.state.selected = 0
            self.state.scroll = max(0, len(self.state.lines) - 30)
        elif key == curses.KEY_END:
            self.state.selected = max(0, len(self.state.lines) - 1)
            self.state.scroll = 0
        elif key == curses.KEY_LEFT:
            self.state.input_pos = max(0, self.state.input_pos - 1)
        elif key == curses.KEY_RIGHT:
            self.state.input_pos = min(len(self.state.input_text), self.state.input_pos + 1)
        elif key in {curses.KEY_BACKSPACE, 127, 8}:
            await self.handle_char("\x7f")

    def focus_selected(self) -> None:
        if not self.state.lines:
            self.state.scroll = 0
            return
        self.state.scroll = max(0, len(self.state.lines) - self.state.selected - 1)

    async def run(self, stdscr: Any) -> None:
        await self.load_initial()
        self.register_events()
        self.refresh_task = asyncio.create_task(self.refresh_loop())
        try:
            await self.input_loop(stdscr)
        finally:
            if self.refresh_task:
                self.refresh_task.cancel()
                with suppress(asyncio.CancelledError):
                    await self.refresh_task

    async def refresh_loop(self) -> None:
        while self.state.running:
            await asyncio.sleep(6)
            try:
                last_id = self.state.lines[-1].msg.id if self.state.lines else 0
                new_lines: list[ChatLine] = []
                async for msg in self.client.iter_messages(self.entity, min_id=last_id, reverse=True):
                    new_lines.append(await self.to_line(msg))
                if new_lines:
                    self.state.lines.extend(new_lines)
                    self.state.lines = self.state.lines[-MAX_MESSAGES:]
                    self.state.selected = len(self.state.lines) - 1
                    self.state.scroll = 0
                    self.state.status = "лента обновлена"
                    self.state.dirty = True
            except Exception as exc:
                self.state.status = f"refresh: {exc}"
                self.state.dirty = True


async def async_main() -> None:
    client = make_client()
    await ensure_login(client)
    try:
        entity = await client.get_entity(CHAT_USERNAME)
    except Exception:
        entity = await client.get_entity(CHAT_ID)

    tui = PotatoTui(client, entity)

    async def wrapped(stdscr: Any) -> None:
        await tui.run(stdscr)

    try:
        await curses_async(wrapped)
    finally:
        await client.disconnect()


async def curses_async(coro_factory: Any) -> None:
    stdscr = curses.initscr()
    curses.noecho()
    curses.cbreak()
    try:
        await coro_factory(stdscr)
    finally:
        curses.nocbreak()
        stdscr.keypad(False)
        curses.echo()
        curses.endwin()


def main() -> None:
    if sys.version_info < (3, 9):
        print("Нужен Python 3.9+.")
        raise SystemExit(2)
    try:
        asyncio.run(async_main())
    except KeyboardInterrupt:
        pass
    except curses.error as exc:
        print("Терминал слишком маленький или не поддерживает curses:", exc)
        raise SystemExit(1)
