/**
 * Lazy-loads a <project>.json (Jira REST API v2 format) and renders
 * a filterable, sortable issue table with a sparkline chart.
 *
 * Usage in a .md file body:
 *
 *   <div id="jira-project"
 *        data-json="./ATLASDOC.json"
 *        data-project="ATLASDOC"
 *        data-jira-base="https://its.cern.ch/jira"></div>
 *   <script src="path/to/jira_project_loader.js"></script>
 */
(function () {

  // ---------------------------------------------------------------------------
  // Icons
  // ---------------------------------------------------------------------------

  const ICONS = {
    externalLink: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="lucide lucide-external-link" viewBox="0 0 24 24"><path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path></svg>`,
    squareArrow:  `<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="lucide lucide-square-arrow-out-up-right" viewBox="0 0 24 24"><path d="M21 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h6M21 3l-9 9M15 3h6v6"></path></svg>`,
  };

  function ic(key) { return `<span class="twemoji">${ICONS[key]}</span>`; }

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------

  function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function fmtDate(iso) { return iso ? iso.slice(0, 10) : '—'; }

  function extractTwikiUrl(description) {
    if (!description) return null;
    const m = description.match(/https:\/\/twiki\.cern\.ch\/[^\s\]\[<"]+/);
    return m ? m[0] : null;
  }

  const STATUS_COLOURS = {
    'Open': 'blue', 'In Progress': 'yellow',
    'Done': 'green', 'Resolved': 'green', 'Closed': 'green',
  };

  function statusLabel(name) {
    const cls = STATUS_COLOURS[name] || 'blue';
    return `<span class="atlaslabel ${cls}">${escapeHtml(name || 'Unknown')}</span>`;
  }

  // ---------------------------------------------------------------------------
  // SVG sparkline
  // ---------------------------------------------------------------------------

  function buildSvg(yearCounts, currentYear) {
    const n = yearCounts.length;
    if (n === 0) return '';

    const W = 480, H = 126, padL = 28, padR = 28;
    const xRange = W - padL - padR;
    const bottomY = 72, topPad = 20, chartH = bottomY - topPad;
    const maxCount = Math.max(...yearCounts.map(([, c]) => c), 1);

    const pts = yearCounts.map(([year, count], i) => ({
      x: n === 1 ? Math.round(W / 2) : padL + Math.round(i * xRange / (n - 1)),
      y: Math.round(bottomY - (count / maxCount) * chartH),
      year, count,
    }));

    let lines = '', dots = '';
    for (let i = 0; i < pts.length - 1; i++) {
      const dashed = pts[i + 1].year >= currentYear ? ' stroke-dasharray="5 3"' : '';
      lines += `<line x1="${pts[i].x}" y1="${pts[i].y}" x2="${pts[i+1].x}" y2="${pts[i+1].y}" stroke="currentColor" stroke-width="1.5" opacity="0.65"${dashed}></line>`;
    }
    for (const pt of pts) {
      const hollow = pt.year >= currentYear;
      dots += `<circle cx="${pt.x}" cy="${pt.y}" r="3" fill="${hollow ? 'none' : 'currentColor'}" stroke="currentColor" stroke-width="1.5" opacity="0.8"></circle>`;
      dots += `<text x="${pt.x}" y="${pt.y - 7}" text-anchor="middle" font-size="9" font-family="inherit" fill="currentColor" opacity="0.7">${pt.count}</text>`;
      dots += `<text x="${pt.x}" y="88" text-anchor="middle" font-size="9" font-family="inherit" fill="currentColor" opacity="0.4">${pt.year}</text>`;
    }

    return `<div style="text-align:center;margin-bottom:1.6em">`
      + `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" style="max-width:100%;display:inline-block;">`
      + lines + dots
      + `</svg></div>`;
  }

  // ---------------------------------------------------------------------------
  // Table — fixed column widths via colgroup
  // ---------------------------------------------------------------------------

  // Column definitions: [header, width%]
  const COLS = [
    ['Ticket',   '9%'],
    ['Summary',  '29%'],
    ['Opened',   '8%'],
    ['Assignee', '18%'],
    ['Comments', '5%'],
    ['Last Edit','8%'],
    ['Twiki',    '5%'],
    ['Status',   '9%'],
  ];

  const COLGROUP = `<colgroup>${COLS.map(([, w]) => `<col style="width:${w}">`).join('')}</colgroup>`;
  const THEAD    = `<thead><tr>${COLS.map(([h]) => `<th>${h}</th>`).join('')}</tr></thead>`;

  function renderRow(issue, jiraBase) {
    const f        = issue.fields;
    const twikiUrl = extractTwikiUrl(f.description);
    return `<tr>`
      + `<td><a href="${jiraBase}/browse/${issue.key}">${issue.key}</a></td>`
      + `<td>${escapeHtml(f.summary || '')}</td>`
      + `<td>${fmtDate(f.created)}</td>`
      + `<td>${escapeHtml(f.assignee ? f.assignee.displayName : '—')}</td>`
      + `<td>${f.comment ? (f.comment.total ?? f.comment.comments.length) : 0}</td>`
      + `<td>${fmtDate(f.updated)}</td>`
      + `<td>${twikiUrl ? `<a href="${twikiUrl}">${ic('squareArrow')}</a>` : '—'}</td>`
      + `<td>${statusLabel(f.status ? f.status.name : null)}</td>`
      + `</tr>`;
  }

  function buildTable(issues, jiraBase) {
    if (!issues.length) return '<p><em>No tickets match.</em></p>';
    return `<div class="md-typeset__scrollwrap"><div class="md-typeset__table">`
      + `<table style="table-layout:fixed;width:100%">`
      + COLGROUP + THEAD
      + `<tbody>${issues.map(i => renderRow(i, jiraBase)).join('')}</tbody>`
      + `</table></div></div>`;
  }

  // ---------------------------------------------------------------------------
  // Filter + sort
  // ---------------------------------------------------------------------------

  function applyFilters(state) {
    const { issues, jiraBase, assignee, selectedStatuses, sortKey, countEl, tableEl } = state;

    let filtered = assignee
      ? issues.filter(i => (i.fields.assignee ? i.fields.assignee.displayName : '—') === assignee)
      : [...issues];

    filtered = filtered.filter(i => selectedStatuses.has(i.fields.status ? i.fields.status.name : 'Unknown'));

    filtered.sort((a, b) => {
      switch (sortKey) {
        case 'key-asc':      return parseInt(a.key.split('-')[1]) - parseInt(b.key.split('-')[1]);
        case 'opened-desc':  return b.fields.created.localeCompare(a.fields.created);
        case 'opened-asc':   return a.fields.created.localeCompare(b.fields.created);
        case 'updated-desc': return b.fields.updated.localeCompare(a.fields.updated);
        case 'updated-asc':  return a.fields.updated.localeCompare(b.fields.updated);
        default:             return parseInt(b.key.split('-')[1]) - parseInt(a.key.split('-')[1]);
      }
    });

    countEl.textContent = `Showing ${filtered.length} of ${issues.length} ticket(s).`;
    tableEl.innerHTML = buildTable(filtered, jiraBase);
  }

  // ---------------------------------------------------------------------------
  // Main render
  // ---------------------------------------------------------------------------

  function renderAll(container, issues) {
    const project  = container.dataset.project  || 'JIRA';
    const jiraBase = container.dataset.jiraBase || 'https://its.cern.ch/jira';

    const open   = issues.filter(i => i.fields.resolution === null);
    const closed = issues.filter(i => i.fields.resolution !== null);

    const createdYears = issues.map(i => parseInt(i.fields.created.slice(0, 4)));
    const firstYear    = Math.min(...createdYears);
    const currentYear  = new Date().getFullYear();

    const yearMap = {};
    for (const yr of createdYears) yearMap[yr] = (yearMap[yr] || 0) + 1;
    const yearCounts = Object.entries(yearMap).map(([y, c]) => [parseInt(y), c]).sort((a, b) => a[0] - b[0]);

    // Unique assignees, sorted
    const assignees = [...new Set(
      issues.map(i => i.fields.assignee ? i.fields.assignee.displayName : '—')
    )].sort((a, b) => a.localeCompare(b));

    // Unique statuses, in canonical order
    const STATUS_ORDER = ['Open', 'In Progress', 'Done', 'Resolved', 'Closed'];
    const allStatuses  = [...new Set(issues.map(i => i.fields.status ? i.fields.status.name : 'Unknown'))];
    const statuses     = [
      ...STATUS_ORDER.filter(s => allStatuses.includes(s)),
      ...allStatuses.filter(s => !STATUS_ORDER.includes(s)).sort(),
    ];

    const ctrlStyle = [
      'padding:0.28em 0.55em', 'font-size:0.82em',
      'border:1px solid var(--md-default-fg-color--lightest)',
      'border-radius:4px', 'background:var(--md-default-bg-color)',
      'color:inherit', 'outline:none',
    ].join(';');

    const assigneeOptions = [`<option value="">All assignees</option>`]
      .concat(assignees.map(a => `<option value="${escapeHtml(a)}">${escapeHtml(a)}</option>`))
      .join('');

    const statusChips = statuses.map(s => {
      const cls = STATUS_COLOURS[s] || 'blue';
      return `<label style="cursor:pointer;user-select:none">`
        + `<input type="checkbox" value="${escapeHtml(s)}" checked`
        + ` style="position:absolute;opacity:0;width:0;height:0">`
        + `<span class="atlaslabel ${cls}">${escapeHtml(s)}</span>`
        + `</label>`;
    }).join('');

    container.innerHTML =
      // Admonition
      `<div class="admonition warning">`
      + `<p class="admonition-title">Not live — data refreshed every ~20 minutes · `
      + `<a href="${jiraBase}/projects/${project}">${ic('externalLink')} ${project}</a></p>`
      + `</div>`
      // Subtitle
      + `<p style="text-align:center;font-size:0.82em;opacity:0.6;margin:0 0 1.2em">`
      + `<strong>${project}</strong> `
      + `(Since ${firstYear} · ${issues.length} total · ${open.length} open · ${closed.length} completed)`
      + `</p>`
      // Sparkline
      + buildSvg(yearCounts, currentYear)
      // Controls row
      + `<div style="display:flex;flex-wrap:wrap;gap:0.5em;align-items:center;margin-bottom:0.75em">`
      + `<select id="jira-assignee" style="${ctrlStyle};flex:1;min-width:160px">${assigneeOptions}</select>`
      + `<select id="jira-sort" style="${ctrlStyle}">`
      + `<option value="key-desc">Ticket ↓</option>`
      + `<option value="key-asc">Ticket ↑</option>`
      + `<option value="opened-desc">Opened ↓</option>`
      + `<option value="opened-asc">Opened ↑</option>`
      + `<option value="updated-desc">Last edit ↓</option>`
      + `<option value="updated-asc">Last edit ↑</option>`
      + `</select>`
      + `</div>`
      // Status chips
      + `<div id="jira-chips" style="display:flex;flex-wrap:wrap;gap:0.35em;margin-bottom:0.8em">${statusChips}</div>`
      // Count + table
      + `<p id="jira-count" style="font-size:0.82em;opacity:0.6;margin:0 0 0.5em"></p>`
      + `<div id="jira-table"></div>`;

    const state = {
      issues, jiraBase,
      assignee: '',
      selectedStatuses: new Set(statuses),
      sortKey: 'key-desc',
      countEl: container.querySelector('#jira-count'),
      tableEl: container.querySelector('#jira-table'),
    };

    applyFilters(state);

    container.querySelector('#jira-assignee').addEventListener('change', e => {
      state.assignee = e.target.value;
      applyFilters(state);
    });

    container.querySelector('#jira-sort').addEventListener('change', e => {
      state.sortKey = e.target.value;
      applyFilters(state);
    });

    container.querySelector('#jira-chips').addEventListener('change', e => {
      const cb = e.target;
      if (cb.type !== 'checkbox') return;
      const chip = cb.nextElementSibling;
      if (cb.checked) { state.selectedStatuses.add(cb.value);    chip.style.opacity = ''; }
      else            { state.selectedStatuses.delete(cb.value);  chip.style.opacity = '0.3'; }
      applyFilters(state);
    });
  }

  // ---------------------------------------------------------------------------
  // Fetch + lazy-load trigger
  // ---------------------------------------------------------------------------

  function load(container) {
    const src = container.dataset.json;
    if (!src) return;
    container.innerHTML = '<p><em>Loading…</em></p>';
    fetch(src)
      .then(r => { if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.json(); })
      .then(data => renderAll(container, Array.isArray(data) ? data : []))
      .catch(err => { container.innerHTML = `<p><em>Could not load issues: ${err.message}</em></p>`; });
  }

  const container = document.getElementById('jira-project');
  if (!container) return;

  new IntersectionObserver((entries, obs) => {
    entries.forEach(e => { if (e.isIntersecting) { obs.unobserve(e.target); load(e.target); } });
  }, { rootMargin: '300px' }).observe(container);

})();
