/* MkDocs Material Optimized Unified Script */
// Global state
window.searchData = window.searchData || null;
window.isSearchFetching = false;

// ────────────────────────────────────────────────────────────────
// Per-source color scheme (loaded from source-colors.json)
// Colors are applied via data-source-color attribute on <html>;
// CSS in extra.css maps each named color to --md-primary-fg-color.
// ────────────────────────────────────────────────────────────────
let _sourceColors = null;

// ────────────────────────────────────────────────────────────────
// Backlinks (loaded from /backlinks.json, cached after first fetch)
// ────────────────────────────────────────────────────────────────
let _backlinksData = null;

async function _getBacklinks() {
    if (_backlinksData !== null) return _backlinksData;
    try {
        const base = document.querySelector('base')?.href ?? '/';
        const url = base.replace(/\/?$/, '/') + 'backlinks.json';
        const resp = await fetch(url);
        _backlinksData = resp.ok ? await resp.json() : {};
    } catch (e) {
        _backlinksData = {};
    }
    return _backlinksData;
}

/** Normalise a Zensical page.url (/hub/common/foo/) to the two candidate doc
 *  paths used as keys in backlinks.json (hub/common/foo.md and
 *  hub/common/foo/index.md). */
function _urlToDocPaths(pageUrl) {
    const p = pageUrl.replace(/^\//, '').replace(/\/$/, '');
    return [`${p}.md`, `${p}/index.md`];
}

function setupPageActionsMenu() {
    document.querySelectorAll('.atlas-page-actions-menu').forEach(container => {
        const toggleBtn = container.querySelector('.dropdown-toggle');
        // Panel may already have been hoisted to <body> on a previous setup call
        // (e.g. during SPA navigation when the TOC container persists).
        // In that case, retrieve it via the data attribute we stamped on it.
        let panel = container.querySelector('.atlas-actions-panel');
        if (!panel && container.dataset.actionsPanel) {
            panel = document.getElementById(container.dataset.actionsPanel);
        }
        const trigger = (panel || container).querySelector
            ? (container.querySelector('.atlas-backlinks-trigger') || panel?.querySelector('.atlas-backlinks-trigger'))
            : null;
        const list = panel?.querySelector('.atlas-backlinks-list');
        if (!toggleBtn || !panel || !trigger || !list) return;

        // Stamp a stable id on the panel so we can retrieve it after it is hoisted.
        if (!panel.id) panel.id = 'atlas-actions-panel-' + Math.random().toString(36).slice(2);
        container.dataset.actionsPanel = panel.id;

        // Move panel to <body> so it escapes the nav stacking/overflow context
        // (idempotent — appendChild is a no-op if the node is already a child of body).
        document.body.appendChild(panel);

        const showPanel = () => {
            const r = container.getBoundingClientRect();
            panel.style.top = (r.bottom + 4) + 'px';
            panel.style.right = (window.innerWidth - r.right) + 'px';
            panel.style.left = 'auto';
            panel.style.display = 'block';
            panel.removeAttribute('hidden');
            toggleBtn.removeAttribute('title');
        };
        const hidePanel = () => {
            panel.style.display = 'none';
            toggleBtn.setAttribute('title', 'Page actions');
        };

        // Override setupDropdowns' onclick so we have sole control over this button.
        toggleBtn.onclick = (e) => {
            e.stopPropagation();
            if (panel.style.display === 'block') {
                hidePanel();
            } else {
                showPanel();
            }
        };

        document.addEventListener('click', e => {
            if (!container.contains(e.target) && !panel.contains(e.target)) hidePanel();
        });

        // Hide on any scroll: capture catches inner-container scrolls; window catches page scroll.
        document.addEventListener('scroll', hidePanel, { passive: true, capture: true });
        window.addEventListener('scroll', hidePanel, { passive: true });

        // Populate backlinks
        const pageUrl = trigger.dataset.pageUrl || window.location.pathname;
        const candidates = _urlToDocPaths(pageUrl);

        _getBacklinks().then(data => {
            const entries = candidates.flatMap(k => data[k] || []);
            const seen = new Set();
            const unique = entries.filter(e => {
                if (seen.has(e.path)) return false;
                seen.add(e.path);
                return true;
            });

            const badge = trigger.querySelector('.atlas-backlinks-badge');
            if (badge) badge.textContent = unique.length > 0 ? String(unique.length) : '';

            if (unique.length === 0) {
                const li = document.createElement('li');
                li.className = 'atlas-backlinks-empty';
                li.textContent = 'No backlinks found';
                list.appendChild(li);
            } else {
                unique.forEach(({ path, title }) => {
                    const li = document.createElement('li');
                    const a = document.createElement('a');
                    a.href = '/' + path.replace(/\/index\.md$/, '/').replace(/\.md$/, '/');
                    a.textContent = title || path;
                    a.title = path;
                    li.appendChild(a);
                    list.appendChild(li);
                });
            }
        });

        // Toggle backlinks sub-list on click
        trigger.addEventListener('click', e => {
            e.stopPropagation();
            list.hasAttribute('hidden') ? list.removeAttribute('hidden') : list.setAttribute('hidden', '');
        });
    });
}


async function _getSourceColors() {
    if (_sourceColors !== null) return _sourceColors;
    try {
        const base = document.querySelector('base') ? document.querySelector('base').href : '/';
        const url = base.replace(/\/?$/, '/') + 'assets/source-colors.json';
        const resp = await fetch(url);
        _sourceColors = resp.ok ? await resp.json() : {};
    } catch (e) {
        _sourceColors = {};
    }
    return _sourceColors;
}

function _applySourceColors(colors) {
    const path = window.location.pathname;
    for (const [prefix, colorName] of Object.entries(colors)) {
        const seg = '/' + prefix.replace(/^\/|\/$/g, '') + '/';
        if (path.includes(seg) || path.endsWith('/' + prefix.replace(/^\/|\/$/g, ''))) {
            document.body.dataset.sourceColor = colorName;
            return;
        }
    }
    delete document.body.dataset.sourceColor;
}

// ────────────────────────────────────────────────────────────────
// Disable search interactions while search.json is downloading
// ────────────────────────────────────────────────────────────────
// function setupInstantSearchLoading() {
//     const searchContainer = document.querySelector(".md-search[data-md-component='search']");
//     if (!searchContainer) return;

//     const setSearchLocked = (locked) => {
//         if (locked) {
//             searchContainer.classList.add("index-loading");
//             searchContainer.style.pointerEvents = "none";
//         } else {
//             searchContainer.classList.remove("index-loading");
//             searchContainer.style.pointerEvents = "auto";
//         }
//     };

//     // Intercept fetch to detect search.json download
//     const originalFetch = window.fetch;
//     window.fetch = async function (...args) {
//         const url = args[0];
//         const isSearchJson = typeof url === 'string' && url.includes('search.json');

//         if (isSearchJson) {
//             setSearchLocked(true);
//             try {
//                 const response = await originalFetch.apply(this, args);
//                 setSearchLocked(false);
//                 return response;
//             } catch (error) {
//                 setSearchLocked(false);
//                 throw error;
//             }
//         }

//         return originalFetch.apply(this, args);
//     };
// }

function initAnnounce() {
    var outer = document.getElementById('atlas-announce-outer');
    var pinned = document.getElementById('atlas-announce-pinned');
    var scroll = document.getElementById('atlas-announce-scroll');
    var track = document.getElementById('atlas-announce-track');
    if (!outer || !track) return;

    // Restore track to original items only (strip any previous duplication)
    var origItems = Array.from(track.querySelectorAll('.atlas-announce-item:not([data-clone])'));
    track.innerHTML = '';
    origItems.forEach(function (item) { track.appendChild(item); });

    // Reset visibility
    outer.style.display = '';
    if (pinned) { pinned.style.display = ''; pinned.style.borderRight = ''; }
    if (scroll) scroll.style.display = '';
    track.style.animation = '';

    // Filter cycling items: only show if date is within the last 10 days
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    track.querySelectorAll('.atlas-announce-item').forEach(function (item) {
        var d = item.getAttribute('data-date');
        if (d) {
            var parts = d.split('-');
            var itemDate = new Date(+parts[0], +parts[1] - 1, +parts[2]);
            var diffDays = (today - itemDate) / 86400000;
            if (diffDays < 0 || diffDays > 10) item.remove();
        }
    });

    var hasPinned = pinned && pinned.children.length > 0;
    var hasCycling = track.querySelectorAll('.atlas-announce-item').length > 0;

    if (!hasPinned && !hasCycling) { outer.style.display = 'none'; return; }
    if (!hasPinned) { pinned.style.display = 'none'; }
    if (!hasCycling) {
        scroll.style.display = 'none';
        if (pinned) pinned.style.borderRight = 'none';
        return;
    }

    // Duplicate for seamless loop, measure after layout
    requestAnimationFrame(function () {
        requestAnimationFrame(function () {
            var clones = Array.from(track.querySelectorAll('.atlas-announce-item')).map(function (el) {
                var c = el.cloneNode(true);
                c.setAttribute('data-clone', '1');
                return c;
            });
            clones.forEach(function (c) { track.appendChild(c); });
            var duration = track.scrollWidth / 2 / 80;
            if (duration > 0) {
                track.style.animation = 'atlas-ticker ' + duration + 's linear infinite';
            }
        });
    });
}

if (typeof document$ !== 'undefined' && document$ && typeof document$.subscribe === 'function') {
    document$.subscribe(async function () {
        // Run once on page ready
        initAnnounce();

        // // source_color JS disabled — handled via inline <style> in template
        // if (!document.body.dataset.atlasOriginalPrimary) {
        //     document.body.dataset.atlasOriginalPrimary =
        //         document.body.getAttribute('data-md-color-primary') || '';
        //     document.body.dataset.atlasOriginalAccent =
        //         document.body.getAttribute('data-md-color-accent') || '';
        // }
        // const colors = await _getSourceColors();
        // _applySourceColors(colors);
        // var pageMeta = document.getElementById('atlas-page-meta');
        // var sourceColor = pageMeta ? pageMeta.dataset.sourceColor : '';
        // if (sourceColor) {
        //     document.body.setAttribute('data-md-color-primary', sourceColor);
        //     document.body.setAttribute('data-md-color-accent',  sourceColor);
        // } else {
        //     var origPrimary = document.body.dataset.atlasOriginalPrimary;
        //     var origAccent  = document.body.dataset.atlasOriginalAccent;
        //     if (origPrimary) document.body.setAttribute('data-md-color-primary', origPrimary);
        //     if (origAccent)  document.body.setAttribute('data-md-color-accent',  origAccent);
        // }

        // setupDropdowns();
        setupPageActionsMenu();

        // Update GitLab button to point to the source repo for the current page
        const repoData = document.getElementById('source-repo-data');
        const repoBtn = document.getElementById('gitlab-repo-button');
        if (repoBtn) {
            const link = repoBtn.querySelector('a');
            const sourceUrl = repoData && repoData.dataset.repoUrl;
            if (sourceUrl && link) {
                link.href = sourceUrl;
                repoBtn.title = 'Go to ' + repoData.dataset.repoLabel + ' repository';
            } else if (link) {
                link.href = repoBtn.dataset.defaultUrl || '#';
                repoBtn.title = 'Go to ' + (repoBtn.dataset.defaultLabel || 'GitLab') + ' repository';
            }
        }
    });
}


