/**
 * Lazy-loads a category_XXXX.json and renders meeting admonitions inline.
 *
 * Usage in a .md file body:
 *
 *   <div id="indico-meetings" data-json="./category_XXXX.json"></div>
 *   <script src="path/to/indico_category_loader.js"></script>
 *
 * Or inline the script directly after the div.
 * The div is populated once it scrolls into view (IntersectionObserver).
 */
(function () {

    // ---------------------------------------------------------------------------
    // Lucide SVG icon strings (inline — no external dependency)
    // ---------------------------------------------------------------------------

    const ICONS = {
        calendar: `<svg class="lucide lucide-calendar-days" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" xmlns="http://www.w3.org/2000/svg"><path d="M8 2v4M16 2v4"/><rect height="18" rx="2" width="18" x="3" y="4"/><path d="M3 10h18M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01M16 18h.01"/></svg>`,
        clock: `<svg class="lucide lucide-clock" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>`,
        mapPin: `<svg class="lucide lucide-map-pin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" xmlns="http://www.w3.org/2000/svg"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/></svg>`,
        notes: `<svg class="lucide lucide-notebook-pen" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" xmlns="http://www.w3.org/2000/svg"><path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4M2 6h4M2 10h4M2 14h4M2 18h4"/><path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z"/></svg>`,
        link: `<svg class="lucide lucide-link" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" xmlns="http://www.w3.org/2000/svg"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>`,
        users: `<svg class="lucide lucide-users" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" xmlns="http://www.w3.org/2000/svg"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M16 3.128a4 4 0 0 1 0 7.744M22 21v-2a4 4 0 0 0-3-3.87"/><circle cx="9" cy="7" r="4"/></svg>`,
        file: `<svg class="lucide lucide-file-text" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" xmlns="http://www.w3.org/2000/svg"><path d="M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z"/><path d="M14 2v5a1 1 0 0 0 1 1h5M10 9H8M16 13H8M16 17H8"/></svg>`,
    };

    function ic(key) {
        return `<span class="twemoji">${ICONS[key]}</span>`;
    }

    // ---------------------------------------------------------------------------
    // Formatting helpers
    // ---------------------------------------------------------------------------

    const MONTHS = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ];

    function ordinalSup(n) {
        const v = n % 100;
        const suffix = (v >= 11 && v <= 13) ? 'th'
            : ['th', 'st', 'nd', 'rd'][n % 10] || 'th';
        return `${n}<sup>${suffix}</sup>`;
    }

    function formatDate(dateStr) {
        const [y, m, d] = dateStr.split('-').map(Number);
        return `${MONTHS[m - 1]} ${ordinalSup(d)} ${y}`;
    }

    // start_time format in JSON: "1900-01-01 HH:MM:SS+00:00" (dummy date, real time)
    function extractTime(timeStr) {
        if (!timeStr) return null;
        const m = timeStr.match(/\s(\d{2}:\d{2}):\d{2}/);
        return m ? m[1] : null;
    }

    function meetingTimeRange(contributions) {
        const times = contributions
            .map(c => extractTime(c.start_time))
            .filter(Boolean)
            .sort();
        if (!times.length) return null;
        return times.length > 1 ? `${times[0]}–${times[times.length - 1]}` : times[0];
    }

    function humanSize(bytes) {
        if (!bytes || bytes <= 0) return '';
        const units = ['B', 'kB', 'MB', 'GB'];
        let i = 0;
        while (bytes >= 1024 && i < units.length - 1) { bytes /= 1024; i++; }
        return `(${bytes.toFixed(1)}${units[i]})`;
    }

    // ---------------------------------------------------------------------------
    // Renderers
    // ---------------------------------------------------------------------------

    function renderAttachment(att) {
        const url = att.download_url || att.url || '';
        const title = att.title || att.filename || 'attachment';
        const size = humanSize(att.size);
        return `<li>${ic('file')} <a href="${url}">${title}</a>`
            + (size ? ` <span style="color:#777777">${size}</span>` : '')
            + `</li>`;
    }

    function formatSpeakers(raw) {
        if (!raw) return '';
        if (typeof raw === 'string') return raw;
        return raw.map(s => {
            const name = s.fullName || [s.first_name, s.last_name].filter(Boolean).join(' ');
            return s.affiliation ? `${name} (${s.affiliation})` : name;
        }).filter(Boolean).join(', ');
    }

    function renderContribution(contrib) {
        const speakers = formatSpeakers(contrib.speakers);
        const minutesUrl = contrib.minutes?.url || '';
        const atts = (contrib.attachments || []).map(renderAttachment).join('');

        let line = `<a href="${contrib.url}">${contrib.title}</a>`;
        if (speakers) line += ` | <strong>${ic('users')}</strong> ${speakers}`;
        if (minutesUrl) line += ` <a href="${minutesUrl}">Minutes</a>`;

        return `<li><p>${line}</p>${atts ? `<ul>${atts}</ul>` : ''}</li>`;
    }

    function renderMeeting(ev) {
        const time = meetingTimeRange(ev.contributions || []);
        const room = ev.room || ev.location || '';
        const minutesUrl = ev.minutes_url || '';

        const meta = [
            `<strong>${ic('calendar')} Date:</strong> ${formatDate(ev.date)}`,
        ];
        if (time) meta.push(`<strong>${ic('clock')} Time:</strong> ${time}`);
        if (room) meta.push(`<strong>${ic('mapPin')} Room:</strong> ${room}`);
        if (minutesUrl) meta.push(`<strong>${ic('notes')} <a href="${minutesUrl}">Minutes</a></strong>`);
        meta.push(`<strong>${ic('link')} <a href="${ev.url}">Event</a></strong>`);

        const contribsHtml = (ev.contributions || []).map(renderContribution).join('');

        return `<div class="admonition quote">`
            + `<p class="admonition-title"><a href="${ev.url}">${ev.title}</a></p>`
            + `<p>${meta.join(' | ')}</p>`
            + (contribsHtml ? `<hr><ul>${contribsHtml}</ul>` : '')
            + `</div>`;
    }

    function renderAll(container, events) {
        if (!events.length) {
            container.innerHTML = '<p><em>No meetings found.</em></p>';
            return;
        }

        const byMonth = new Map();
        events
            .sort((a, b) => b.date.localeCompare(a.date))
            .forEach(ev => {
                const [y, m] = ev.date.split('-').map(Number);
                const key = `${y}-${String(m).padStart(2, '0')}`;
                const label = `${MONTHS[m - 1]} ${y}`;
                if (!byMonth.has(key)) byMonth.set(key, { label, events: [] });
                byMonth.get(key).events.push(ev);
            });

        container.innerHTML = [...byMonth.entries()]
            .sort(([a], [b]) => b.localeCompare(a))
            .map(([, { label, events: evs }]) =>
                `<h2>${label}</h2>\n` + evs.map(renderMeeting).join('\n')
            )
            .join('\n');
    }

    // ---------------------------------------------------------------------------
    // Fuse.js search workers
    // Workers are built from the pre-built _search.json index, not the full
    // category JSON.  Each returns a Set<event_url> for the matched events.
    // ---------------------------------------------------------------------------

    class FuseWorker {
        constructor(items, keys, options = {}) {
            this._items = items;
            this._keys = keys;
            this._options = { threshold: 0.35, ignoreLocation: true, ...options };
            this._fuse = null;
        }

        init(FuseClass) {
            this._fuse = new FuseClass(this._items, { keys: this._keys, ...this._options });
        }

        _matchingUrls(query) {
            const hits = (query && this._fuse) ? this._fuse.search(query).map(r => r.item) : this._items;
            return new Set(hits.map(item => item.event_url || item.url));
        }
    }

    class MeetingWorker extends FuseWorker {
        constructor(index) {
            super(
                index.filter(r => r.type === 'event'),
                [{ name: 'title', weight: 1 }]
            );
        }
        matchingUrls(query) { return this._matchingUrls(query); }
    }

    class ContributionWorker extends FuseWorker {
        constructor(index) {
            super(
                index.filter(r => r.type === 'contribution'),
                [{ name: 'title', weight: 1 }]
            );
        }
        matchingUrls(query) { return this._matchingUrls(query); }
    }

    class SpeakerWorker extends FuseWorker {
        constructor(index) {
            super(
                index.filter(r => r.type === 'speaker'),
                [{ name: 'name', weight: 2 }, { name: 'variants', weight: 1 }]
            );
        }
        matchingUrls(query) { return this._matchingUrls(query); }
    }

    // ---------------------------------------------------------------------------
    // Search UI
    // ---------------------------------------------------------------------------

    function buildSearchBar() {
        const wrap = document.createElement('div');
        wrap.className = 'indico-search-bar';
        wrap.innerHTML =
            `<input type="search" placeholder="Search meetings, talks, speakers…" aria-label="Search meetings">` +
            `<span class="indico-search-count"></span>`;
        return wrap;
    }

    // ---------------------------------------------------------------------------
    // Fuse.js loader — loads the vendored fuse.min.js via script tag, then
    // immediately captures and clears window.Fuse so it doesn't linger.
    // ---------------------------------------------------------------------------

    let _fusePromise = null;
    function loadFuse() {
        if (_fusePromise) return _fusePromise;
        _fusePromise = new Promise(resolve => {
            // Resolve the vendor path relative to this script's own URL.
            const base = (document.currentScript && document.currentScript.src)
                ? document.currentScript.src.replace(/[^/]+$/, '')
                : '';
            const s = document.createElement('script');
            s.src = base + 'fuse.min.js';
            s.onload = () => {
                const F = window.Fuse;
                delete window.Fuse;
                resolve(F || null);
            };
            s.onerror = () => resolve(null);
            document.head.appendChild(s);
        });
        return _fusePromise;
    }

    // ---------------------------------------------------------------------------
    // Fetch + lazy-load trigger
    // ---------------------------------------------------------------------------

    function load(container) {
        const src = container.dataset.json;
        if (!src) return;

        // Derive search index path: category_492.json → category_492_search.json
        const searchSrc = container.dataset.search
            || src.replace(/\.json$/, '_search.json');

        container.innerHTML = '<p><em>Loading…</em></p>';

        Promise.all([
            fetch(src).then(r => { if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.json(); }),
            fetch(searchSrc).then(r => r.ok ? r.json() : []).catch(() => []),
            loadFuse(),
        ]).then(([data, index, FuseClass]) => {
            const events = (Array.isArray(data) ? data : (data.events || []))
                .filter(ev => ev._type !== 'category_metadata' && ev.date);

            const meetingWorker      = new MeetingWorker(index);
            const contributionWorker = new ContributionWorker(index);
            const speakerWorker      = new SpeakerWorker(index);

            if (FuseClass) {
                [meetingWorker, contributionWorker, speakerWorker]
                    .forEach(w => w.init(FuseClass));
            }

            const bar     = buildSearchBar();
            container.parentNode.insertBefore(bar, container);
            const input   = bar.querySelector('input');
            const countEl = bar.querySelector('.indico-search-count');

            function applySearch(query) {
                let results;
                if (!query) {
                    results = events;
                    countEl.textContent = '';
                } else {
                    const urls = new Set([
                        ...meetingWorker.matchingUrls(query),
                        ...contributionWorker.matchingUrls(query),
                        ...speakerWorker.matchingUrls(query),
                    ]);
                    results = events.filter(ev => urls.has(ev.url));
                    countEl.textContent = `${results.length} result${results.length !== 1 ? 's' : ''}`;
                }
                renderAll(container, results);
            }

            let timer;
            input.addEventListener('input', e => {
                clearTimeout(timer);
                timer = setTimeout(() => applySearch(e.target.value.trim()), 200);
            });

            renderAll(container, events);
        }).catch(err => {
            container.innerHTML = `<p><em>Could not load meetings: ${err.message}</em></p>`;
        });
    }

    const container = document.getElementById('indico-meetings');
    if (!container) return;

    // Pre-load 300 px before the div enters the viewport
    const observer = new IntersectionObserver(
        (entries, obs) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) { obs.unobserve(entry.target); load(entry.target); }
            });
        },
        { rootMargin: '300px' }
    );

    observer.observe(container);
})();
