from __future__ import annotations

import json
import time
import unittest
from dataclasses import dataclass

from opovid import (
    Actor,
    Check,
    ExecutionListener,
    ExecutionTimeoutError,
    OpovidError,
    RememberTheState,
    StepEvent,
    User,
    check,
    question,
    remembered_by,
    render_timeline,
    summarize_failure,
    task,
    timeline_to_json,
    with_retry,
)


@dataclass
class CountNumbers:
    total: dict[str, int]


@dataclass
class ReadWords:
    words: list[str]


class CoreTest(unittest.TestCase):
    def test_factory_helpers_return_named_contracts(self) -> None:
        actor = Actor.named("Casey")
        does_work = task("does work", lambda current_actor: current_actor.name)
        reads_name = question("reads a name", lambda current_actor: current_actor.name)

        self.assertEqual("does work", does_work.description)
        self.assertEqual("Casey", does_work.perform_as(actor))
        self.assertEqual("reads a name", reads_name.description)
        self.assertEqual("Casey", reads_name.answered_by(actor))

    def test_factory_helpers_reject_blank_descriptions(self) -> None:
        with self.assertRaisesRegex(ValueError, "description"):
            task("", lambda _actor: None)
        with self.assertRaisesRegex(ValueError, "description"):
            task("   ", lambda _actor: None)
        with self.assertRaisesRegex(ValueError, "description"):
            question("", lambda _actor: None)
        with self.assertRaisesRegex(ValueError, "description"):
            question("   ", lambda _actor: None)

    def test_runs_tasks_and_questions_with_nested_reporting(self) -> None:
        actor = Actor.named("Casey").can(CountNumbers({"value": 0}))

        increment = task(
            "increments the counter",
            lambda current_actor: _increment(current_actor.ability_to(CountNumbers).total),
        )
        prepare_counter = task(
            "prepares the counter",
            lambda current_actor: current_actor.attempts_to(increment, increment),
        )
        current_total = question(
            "reads the current total",
            lambda current_actor: current_actor.ability_to(CountNumbers).total["value"],
        )

        actor.attempts_to(prepare_counter)

        self.assertEqual(2, actor.asks_for(current_total))

        report = actor.report()

        self.assertEqual(1, report.schema_version)
        self.assertEqual("Casey", report.actor)
        self.assertEqual(
            ["prepares the counter", "reads the current total"],
            [step.description for step in report.steps],
        )
        self.assertEqual(
            ["increments the counter", "increments the counter"],
            [step.description for step in report.steps[0].steps],
        )
        self.assertEqual("passed", report.steps[0].status)
        self.assertEqual("passed", report.steps[-1].status)

    def test_returns_the_actor_when_multiple_top_level_tasks_are_run(self) -> None:
        actor = Actor.named("Casey").can(CountNumbers({"value": 0}))

        returned = actor.attempts_to(
            task("increments once", lambda current_actor: _increment(current_actor.ability_to(CountNumbers).total)),
            task(
                "increments twice",
                lambda current_actor: _increment(
                    current_actor.ability_to(CountNumbers).total,
                    by=2,
                ),
            ),
        )

        self.assertIs(actor, returned)
        self.assertEqual(["increments once", "increments twice"], [step.description for step in actor.report().steps])

    def test_captures_failures_in_the_execution_report(self) -> None:
        actor = Actor.named("Casey")

        with self.assertRaises(OpovidError) as raised:
            actor.attempts_to(task("fails loudly", lambda _actor: _raise(RuntimeError("boom"))))

        error = raised.exception
        self.assertEqual("fails loudly", error.step.description)
        self.assertEqual("fails loudly", error.report.steps[0].description)
        self.assertEqual("boom", str(error.__cause__))
        self.assertEqual("boom", actor.report().steps[0].error.message)
        self.assertEqual("failed", actor.report().steps[0].status)

    def test_records_nested_task_failures_and_preserves_parent_links(self) -> None:
        actor = Actor.named("Casey")

        with self.assertRaises(OpovidError) as raised:
            actor.attempts_to(
                task(
                    "wraps a failing step",
                    lambda current_actor: current_actor.attempts_to(
                        task("fails inside a nested step", lambda _actor: _raise(RuntimeError("nested boom")))
                    ),
                )
            )

        error = raised.exception
        self.assertEqual("fails inside a nested step", error.step.description)
        self.assertEqual("nested boom", str(error.__cause__))
        self.assertEqual("wraps a failing step", actor.report().steps[0].description)
        self.assertEqual("fails inside a nested step", actor.report().steps[0].steps[0].description)
        self.assertEqual("failed", actor.report().steps[0].steps[0].status)

    def test_uses_the_underlying_cause_when_another_actor_boundary_fails_inside_a_task(self) -> None:
        outer_actor = Actor.named("Outer")
        inner_actor = Actor.named("Inner")

        with self.assertRaises(OpovidError) as raised:
            outer_actor.attempts_to(
                task(
                    "delegates to another actor",
                    lambda _actor: inner_actor.attempts_to(
                        task("inner task fails", lambda _inner: _raise(RuntimeError("inner boom")))
                    ),
                )
            )

        error = raised.exception
        self.assertEqual('Step "delegates to another actor" failed: inner boom', str(error))
        self.assertEqual("inner boom", str(error.__cause__.__cause__))
        self.assertEqual("inner boom", outer_actor.report().steps[0].error.message)

    def test_notifies_listeners_on_step_boundaries(self) -> None:
        class Listener(ExecutionListener):
            def __init__(self) -> None:
                self.events: list[str] = []

            def on_step_started(self, event: StepEvent) -> None:
                parent_id = event.parent_id or "root"
                status = event.step.status or "pending"
                finished = event.step.finished_at or "not-finished"
                self.events.append(f"start:{parent_id}:{event.step.description}:{status}:{finished}")

            def on_step_finished(self, event: StepEvent) -> None:
                parent_id = event.parent_id or "root"
                self.events.append(f"finish:{parent_id}:{event.step.description}:{event.step.status}")

        listener = Listener()
        actor = Actor.named("Casey", listeners=[listener])
        actor.attempts_to(
            task(
                "does something",
                lambda current_actor: current_actor.attempts_to(task("does a nested thing", lambda _actor: None)),
            )
        )

        self.assertEqual(
            [
                "start:root:does something:pending:not-finished",
                "start:1:does a nested thing:pending:not-finished",
                "finish:1:does a nested thing:passed",
                "finish:root:does something:passed",
            ],
            listener.events,
        )

    def test_listener_base_exceptions_do_not_escape_user_flow(self) -> None:
        class Listener(ExecutionListener):
            def on_step_started(self, _event: StepEvent) -> None:
                raise KeyboardInterrupt("stop")

        actor = Actor.named("Casey", listeners=[Listener()])

        with self.assertWarns(RuntimeWarning):
            self.assertEqual("done", actor.attempts_to(task("keeps going", lambda _actor: "done")))

    def test_throws_when_an_ability_is_missing(self) -> None:
        actor = Actor.named("Casey")

        with self.assertRaisesRegex(RuntimeError, "Casey does not have ability CountNumbers"):
            actor.ability_to(CountNumbers)

    def test_throws_when_other_abilities_exist_but_none_match(self) -> None:
        actor = Actor.named("Casey").can(ReadWords(["hello"]))

        with self.assertRaisesRegex(RuntimeError, "Casey does not have ability CountNumbers"):
            actor.ability_to(CountNumbers)

    def test_runs_fluent_attempt_chains_and_latest_value_checks(self) -> None:
        actor = Actor.named("Dana").can(CountNumbers({"value": 0}))
        increment = task("increments", lambda current_actor: _increment(current_actor.ability_to(CountNumbers).total))
        total = question("reads total", lambda current_actor: current_actor.ability_to(CountNumbers).total["value"])

        actor.attempts().prepare(increment).attempts_to_authenticate(increment).attempts_to(increment).question(
            total
        ).verifies(Check(lambda actual, _actor: self.assertEqual(3, actual)))

        self.assertEqual(3, actor.attempts().question(total).latest())

    def test_supports_the_user_first_facade_without_shared_test_context(self) -> None:
        counter = CountNumbers({"value": 0})
        user = User("Dana", counter)
        increment = task("increments", lambda current_actor: _increment(current_actor.ability_to(CountNumbers).total))
        total = question("reads total", lambda current_actor: current_actor.ability_to(CountNumbers).total["value"])

        user.prepare(increment).attempts_to_authenticate(increment).attempts_to(increment).question(total).verifies(
            check(lambda actual, _actor: self.assertEqual(3, actual))
        )

        self.assertEqual(3, counter.total["value"])

    def test_records_timeline_events_and_timeout_failures(self) -> None:
        actor = Actor.named("Casey")

        with self.assertRaises(OpovidError) as raised:
            actor.attempts_to(task("waits too long", lambda _actor: time.sleep(0.05), timeout_ms=1))

        self.assertIsInstance(raised.exception.__cause__, ExecutionTimeoutError)
        self.assertEqual("failed", actor.report().steps[0].status)
        self.assertEqual("ExecutionTimeoutError", actor.report().steps[0].error.name)
        self.assertIn("StepTimedOut", [event.type for event in actor.timeline().events])

    def test_renders_timeline_json_and_failure_summary(self) -> None:
        actor = Actor.named("Casey")

        with self.assertRaises(OpovidError):
            actor.attempts_to(task("fails loudly", lambda _actor: _raise(RuntimeError("boom"))))

        timeline = actor.timeline()
        rendered = render_timeline(timeline)
        data = json.loads(timeline_to_json(timeline))
        summary = summarize_failure(timeline)

        self.assertIn("Run", rendered)
        self.assertIn("FAIL fails loudly", rendered)
        self.assertEqual("Casey", data["actor"])
        self.assertEqual("fails loudly", data["steps"][0]["description"])
        self.assertEqual('Step "fails loudly" failed: boom.', summary.message)

    def test_retries_a_task_until_it_succeeds(self) -> None:
        actor = Actor.named("Casey")
        attempts = {"count": 0}

        def eventually_succeeds(_actor: Actor) -> str:
            attempts["count"] += 1
            if attempts["count"] < 2:
                raise RuntimeError("not yet")
            return "done"

        retried = with_retry(3, task("eventually succeeds", eventually_succeeds))

        self.assertEqual("eventually succeeds (up to 3 attempts)", retried.description)
        self.assertEqual("done", actor.attempts_to(retried))
        self.assertEqual(2, attempts["count"])

    def test_remember_the_state_is_actor_local(self) -> None:
        actor = Actor.named("Casey").can(RememberTheState.using_defaults())

        remembered_by(actor).remember("plan", "pro").note("source", "fixture")

        self.assertEqual("pro", remembered_by(actor).recall("plan"))
        self.assertEqual("fixture", remembered_by(actor).recall_note("source"))
        self.assertIsNone(remembered_by(actor).maybe_recall("missing"))


def _increment(total: dict[str, int], by: int = 1) -> None:
    total["value"] += by


def _raise(error: BaseException) -> None:
    raise error


if __name__ == "__main__":
    unittest.main()
