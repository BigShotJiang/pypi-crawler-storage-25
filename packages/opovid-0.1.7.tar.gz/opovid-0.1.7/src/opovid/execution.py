from __future__ import annotations

from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FutureTimeoutError
from copy import deepcopy
from dataclasses import asdict, dataclass, field, is_dataclass
from datetime import UTC, datetime
from time import perf_counter
from traceback import format_exception
from typing import Any, Literal, Protocol, TypeVar, runtime_checkable
from uuid import uuid4
from warnings import warn

from .execution_options import ExecutionMetadata, require_timeout_ms

StepKind = Literal["task", "question"]
StepStatus = Literal["passed", "failed"]
TimelineLayer = Literal["intent", "adapter", "runtime"]
TimelineStatus = Literal["pending", "ok", "failed"]
TimelineEventData = dict[str, Any]

T = TypeVar("T")
PARENT_STACK_DEPTH = 2


@dataclass(frozen=True)
class ExecutionError:
    name: str
    message: str
    stack: str | None = None


@dataclass(frozen=True)
class ExecutionStep:
    id: str
    actor: str
    kind: StepKind
    description: str
    started_at: str
    finished_at: str | None = None
    duration_ms: int | None = None
    status: StepStatus | None = None
    error: ExecutionError | None = None
    metadata: ExecutionMetadata | None = None
    timeout_ms: int | None = None
    steps: tuple[ExecutionStep, ...] = ()


@dataclass(frozen=True)
class ExecutionReport:
    schema_version: Literal[1]
    actor: str
    steps: tuple[ExecutionStep, ...]


@dataclass(frozen=True)
class TimelineEvent:
    schema_version: Literal[1]
    run_id: str
    event_id: str
    sequence: int
    timestamp: str
    type: str
    layer: TimelineLayer
    step_id: str | None = None
    parent_step_id: str | None = None
    status: TimelineStatus | None = None
    data: TimelineEventData = field(default_factory=dict)


@dataclass(frozen=True)
class ExecutionTimeline:
    schema_version: Literal[1]
    run_id: str
    actor: str
    steps: tuple[ExecutionStep, ...]
    events: tuple[TimelineEvent, ...]


@dataclass(frozen=True)
class ExecutionEventInput:
    type: str
    layer: TimelineLayer
    status: TimelineStatus | None = None
    data: TimelineEventData | None = None


@dataclass(frozen=True)
class StepEvent:
    parent_id: str | None
    step: ExecutionStep


class ExecutionTimeoutError(TimeoutError):
    def __init__(self, timeout_ms: int) -> None:
        self.timeout_ms = timeout_ms
        super().__init__(f"Step timed out after {timeout_ms}ms")


class OpovidError(RuntimeError):
    def __init__(self, step: ExecutionStep, report: ExecutionReport, cause: BaseException | None = None) -> None:
        self.step = step
        self.report = report
        if cause is not None and str(cause):
            message = f'Step "{step.description}" failed: {cause}'
        else:
            message = f'Step "{step.description}" failed'
        super().__init__(message)


class ExecutionListener:
    def on_step_started(self, event: StepEvent) -> None:
        pass

    def on_step_finished(self, event: StepEvent) -> None:
        pass


class ExecutionEventEmitter:
    def __init__(self, emit: Callable[[ExecutionEventInput], None]) -> None:
        self._emit = emit

    def emit(self, event: ExecutionEventInput) -> None:
        self._emit(event)


@runtime_checkable
class ExecutionEventAware(Protocol):
    def attach_execution_event_emitter(self, emitter: ExecutionEventEmitter) -> None: ...


@dataclass
class _MutableExecutionStep:
    id: str
    actor: str
    kind: StepKind
    description: str
    started_at: str
    metadata: ExecutionMetadata | None = None
    timeout_ms: int | None = None
    finished_at: str | None = None
    duration_ms: int | None = None
    status: StepStatus | None = None
    error: ExecutionError | None = None
    steps: list[_MutableExecutionStep] = field(default_factory=list)


class ExecutionRecorder:
    def __init__(self, actor: str, listeners: list[object] | None = None) -> None:
        self._actor = actor
        self._listeners = listeners or []
        self._root_steps: list[_MutableExecutionStep] = []
        self._stack: list[_MutableExecutionStep] = []
        self._events: list[TimelineEvent] = []
        self._run_id = str(uuid4())
        self._next_id = 1
        self._next_event_sequence = 1
        self._emitter = ExecutionEventEmitter(self._emit)

    def run(
        self,
        kind: StepKind,
        description: str,
        work: Callable[[], T],
        *,
        metadata: ExecutionMetadata | None = None,
        timeout_ms: int | None = None,
    ) -> T:
        timeout_ms = require_timeout_ms(timeout_ms, "execution timeout_ms must be an integer greater than 0")
        parent = self._stack[-1] if self._stack else None
        step = _MutableExecutionStep(
            id=str(self._next_id),
            actor=self._actor,
            kind=kind,
            description=description,
            started_at=_timestamp(),
            metadata=deepcopy(metadata) if metadata is not None else None,
            timeout_ms=timeout_ms,
        )
        self._next_id += 1

        if parent is None:
            self._root_steps.append(step)
        else:
            parent.steps.append(step)

        self._stack.append(step)
        self._emit_for_step(f"{kind.title()}Started", "intent", step, parent.id if parent else None, "pending")
        self._notify("on_step_started", step, parent.id if parent else None)
        start = perf_counter()

        try:
            result = _run_with_timeout(work, timeout_ms)
        except BaseException as error:
            step.finished_at = _timestamp()
            step.duration_ms = round((perf_counter() - start) * 1000)
            step.status = "failed"
            step.error = to_execution_error(error)

            if isinstance(error, ExecutionTimeoutError):
                self._emit_for_step(
                    "StepTimedOut",
                    "runtime",
                    step,
                    parent.id if parent else None,
                    "failed",
                    {"timeout_ms": error.timeout_ms},
                )

            self._emit_for_step(
                "ErrorCaptured",
                "runtime",
                step,
                parent.id if parent else None,
                "failed",
                {"error": step.error},
            )

            if parent is None:
                report = self.report()
                current_step = report.steps[-1] if report.steps else _clone_step(step)
                raise OpovidError(_find_failed_step(current_step), report, _underlying_cause(error)) from error

            raise
        else:
            step.finished_at = _timestamp()
            step.duration_ms = round((perf_counter() - start) * 1000)
            step.status = "passed"
            return result
        finally:
            self._stack.pop()
            self._emit_for_step(
                f"{kind.title()}Finished",
                "intent",
                step,
                parent.id if parent else None,
                "failed" if step.status == "failed" else "ok",
                _without_none({"duration_ms": step.duration_ms, "error": step.error}),
            )
            self._notify("on_step_finished", step, parent.id if parent else None)

    def report(self) -> ExecutionReport:
        return ExecutionReport(
            schema_version=1,
            actor=self._actor,
            steps=tuple(_clone_step(step) for step in self._root_steps),
        )

    def timeline(self) -> ExecutionTimeline:
        return ExecutionTimeline(
            schema_version=1,
            run_id=self._run_id,
            actor=self._actor,
            steps=tuple(_clone_step(step) for step in self._root_steps),
            events=deepcopy(tuple(self._events)),
        )

    def emitter(self) -> ExecutionEventEmitter:
        return self._emitter

    def _emit(self, event: ExecutionEventInput) -> None:
        current_step = self._stack[-1] if self._stack else None
        parent_step = self._stack[-2] if len(self._stack) >= PARENT_STACK_DEPTH else None
        self._events.append(
            self._create_event(
                event.type,
                event.layer,
                current_step.id if current_step else None,
                parent_step.id if parent_step else None,
                event.status,
                event.data or {},
            )
        )

    def _emit_for_step(
        self,
        event_type: str,
        layer: TimelineLayer,
        step: _MutableExecutionStep,
        parent_step_id: str | None,
        status: TimelineStatus | None = None,
        data: TimelineEventData | None = None,
    ) -> None:
        payload = _without_none(
            {
                "actor": step.actor,
                "kind": step.kind,
                "description": step.description,
                "metadata": deepcopy(step.metadata),
                "timeout_ms": step.timeout_ms,
            }
        )
        payload.update(data or {})
        self._events.append(self._create_event(event_type, layer, step.id, parent_step_id, status, payload))

    def _create_event(
        self,
        event_type: str,
        layer: TimelineLayer,
        step_id: str | None,
        parent_step_id: str | None,
        status: TimelineStatus | None,
        data: TimelineEventData,
    ) -> TimelineEvent:
        sequence = self._next_event_sequence
        self._next_event_sequence += 1
        return TimelineEvent(
            schema_version=1,
            run_id=self._run_id,
            event_id=f"{self._run_id}:{sequence}",
            sequence=sequence,
            timestamp=_timestamp(),
            type=event_type,
            layer=layer,
            step_id=step_id,
            parent_step_id=parent_step_id,
            status=status,
            data=deepcopy(_plain_data(data)),
        )

    def _notify(self, method_name: str, step: _MutableExecutionStep, parent_id: str | None) -> None:
        event = StepEvent(parent_id=parent_id, step=_clone_step(step))
        for listener in self._listeners:
            method = getattr(listener, method_name, None)
            if method is None:
                continue
            try:
                method(event)
            except BaseException as error:
                warn(f"Execution listener {method_name} raised: {error}", RuntimeWarning, stacklevel=2)


def to_serializable_error(error: BaseException) -> ExecutionError:
    if isinstance(error, OpovidError) and error.__cause__ is not None:
        error = error.__cause__

    return ExecutionError(
        name=error.__class__.__name__,
        message=str(error),
        stack="".join(format_exception(type(error), error, error.__traceback__)),
    )


def to_execution_error(error: BaseException) -> ExecutionError:
    return to_serializable_error(error)


def _timestamp() -> str:
    return datetime.now(UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _clone_step(step: _MutableExecutionStep) -> ExecutionStep:
    return ExecutionStep(
        id=step.id,
        actor=step.actor,
        kind=step.kind,
        description=step.description,
        started_at=step.started_at,
        finished_at=step.finished_at,
        duration_ms=step.duration_ms,
        status=step.status,
        error=deepcopy(step.error),
        metadata=deepcopy(step.metadata),
        timeout_ms=step.timeout_ms,
        steps=tuple(_clone_step(child) for child in step.steps),
    )


def _find_failed_step(step: ExecutionStep) -> ExecutionStep:
    for nested in reversed(step.steps):
        if nested.status == "failed":
            return _find_failed_step(nested)
    return step


def _run_with_timeout[T](work: Callable[[], T], timeout_ms: int | None) -> T:
    if timeout_ms is None:
        return work()

    with ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(work)
        try:
            return future.result(timeout=timeout_ms / 1000)
        except FutureTimeoutError as error:
            future.cancel()
            raise ExecutionTimeoutError(timeout_ms) from error


def _underlying_cause(error: BaseException) -> BaseException:
    if isinstance(error, OpovidError) and error.__cause__ is not None:
        return error.__cause__
    return error


def _without_none(value: dict[str, Any]) -> dict[str, Any]:
    return {key: nested for key, nested in value.items() if nested is not None}


def _plain_data(value: Any) -> Any:
    if is_dataclass(value) and not isinstance(value, type):
        return _plain_data(asdict(value))
    if isinstance(value, dict):
        return {key: _plain_data(nested) for key, nested in value.items()}
    if isinstance(value, (tuple, list)):
        return [_plain_data(nested) for nested in value]
    return value
