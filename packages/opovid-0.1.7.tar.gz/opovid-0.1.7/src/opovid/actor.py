from __future__ import annotations

from typing import TYPE_CHECKING, Any, TypeVar

from .execution import (
    ExecutionEventAware,
    ExecutionRecorder,
    ExecutionReport,
    ExecutionTimeline,
)
from .question import Question
from .task import Task

if TYPE_CHECKING:
    from .attempt_chain import AttemptChain

T = TypeVar("T")


class Actor:
    def __init__(self, name: str, *, listeners: list[object] | None = None) -> None:
        self.name = name
        self._abilities: list[object] = []
        self._execution = ExecutionRecorder(name, listeners)

    @classmethod
    def named(cls, name: str, *, listeners: list[object] | None = None) -> Actor:
        return cls(name, listeners=listeners)

    def can(self, *abilities: object) -> Actor:
        for ability in abilities:
            self._abilities.append(ability)
            if isinstance(ability, ExecutionEventAware):
                ability.attach_execution_event_emitter(self._execution.emitter())
        return self

    def ability_to(self, ability_type: type[T]) -> T:
        for ability in self._abilities:
            if isinstance(ability, ability_type):
                return ability
        raise RuntimeError(f"{self.name} does not have ability {ability_type.__name__}")

    def attempts_to(self, first_task: Task, *remaining_tasks: Task) -> Any:
        if not remaining_tasks:
            return self._run_task(first_task)

        self._run_task(first_task)
        for next_task in remaining_tasks:
            self._run_task(next_task)
        return self

    def asks_for(self, q: Question) -> Any:
        return self._execution.run(
            "question",
            q.description,
            lambda: q.answered_by(self),
            metadata=q.metadata,
            timeout_ms=q.timeout_ms,
        )

    def attempts(self) -> AttemptChain:
        from .attempt_chain import AttemptChain

        return AttemptChain(self, self._execution.emitter())

    def report(self) -> ExecutionReport:
        return self._execution.report()

    def timeline(self) -> ExecutionTimeline:
        return self._execution.timeline()

    def _run_task(self, task_to_run: Task) -> Any:
        return self._execution.run(
            "task",
            task_to_run.description,
            lambda: task_to_run.perform_as(self),
            metadata=task_to_run.metadata,
            timeout_ms=task_to_run.timeout_ms,
        )
