from __future__ import annotations

from collections.abc import Callable
from copy import deepcopy
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from .execution_options import ExecutionMetadata, require_timeout_ms

if TYPE_CHECKING:
    from .actor import Actor


@dataclass(frozen=True)
class Task:
    description: str
    perform_as: Callable[[Actor], Any]
    metadata: ExecutionMetadata | None = None
    timeout_ms: int | None = None


def task[T](
    description: str,
    perform_as: Callable[[Actor], T],
    *,
    metadata: ExecutionMetadata | None = None,
    timeout_ms: int | None = None,
) -> Task:
    if not description or not description.strip():
        raise ValueError("description")
    if perform_as is None:
        raise ValueError("perform_as")
    return Task(
        description=description,
        perform_as=perform_as,
        metadata=deepcopy(metadata) if metadata is not None else None,
        timeout_ms=require_timeout_ms(timeout_ms, "task timeout_ms must be an integer greater than 0"),
    )
