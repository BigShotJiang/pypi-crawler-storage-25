from __future__ import annotations

from collections.abc import Callable
from typing import Any, TypeVar

from .actor import Actor
from .attempt_chain import AttemptChain
from .check import Check
from .execution import ExecutionReport, ExecutionTimeline
from .question import Question
from .task import Task

T = TypeVar("T")


class User:
    def __init__(self, name: str, *abilities: object, listeners: list[object] | None = None) -> None:
        self.name = name
        self._actor = Actor.named(name, listeners=listeners).can(*abilities)
        self._chain = self._actor.attempts()

    def can(self, *abilities: object) -> User:
        self._actor.can(*abilities)
        return self

    def ability_to(self, ability_type: type[T]) -> T:
        return self._actor.ability_to(ability_type)

    def prepare(self, task_to_run: Task) -> User:
        self._chain.prepare(task_to_run)
        return self

    def attempts_to(self, task_to_run: Task) -> User:
        self._chain.attempts_to(task_to_run)
        return self

    def attempts_to_authenticate(self, task_to_run: Task) -> User:
        self._chain.attempts_to_authenticate(task_to_run)
        return self

    def question(self, q: Question) -> User:
        self._chain.question(q)
        return self

    def verifies(self, c: Check) -> User:
        self._chain.verifies(c)
        return self

    def verifies_that(
        self,
        q: Question,
        verification: Callable[[Any, Actor], None],
        *additional_verifications: Callable[[Any, Actor], None],
    ) -> User:
        self._chain.verifies_that(q, verification, *additional_verifications)
        return self

    def asks_for(self, q: Question) -> Any:
        return self._actor.asks_for(q)

    def actor(self) -> Actor:
        return self._actor

    def attempts(self) -> AttemptChain:
        return self._chain

    def latest(self) -> Any:
        return self._chain.latest()

    def report(self) -> ExecutionReport:
        return self._actor.report()

    def timeline(self) -> ExecutionTimeline:
        return self._actor.timeline()

    def done(self) -> User:
        self._chain.done()
        return self
