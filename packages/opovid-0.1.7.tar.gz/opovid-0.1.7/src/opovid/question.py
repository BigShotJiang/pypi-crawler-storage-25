from __future__ import annotations

from collections.abc import Callable
from copy import deepcopy
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from .execution_options import ExecutionMetadata, require_timeout_ms

if TYPE_CHECKING:
    from .actor import Actor


@dataclass(frozen=True)
class Question:
    description: str
    answered_by: Callable[[Actor], Any]
    metadata: ExecutionMetadata | None = None
    timeout_ms: int | None = None


def question[T](
    description: str,
    answered_by: Callable[[Actor], T],
    *,
    metadata: ExecutionMetadata | None = None,
    timeout_ms: int | None = None,
) -> Question:
    if not description or not description.strip():
        raise ValueError("description")
    if answered_by is None:
        raise ValueError("answered_by")
    return Question(
        description=description,
        answered_by=answered_by,
        metadata=deepcopy(metadata) if metadata is not None else None,
        timeout_ms=require_timeout_ms(timeout_ms, "question timeout_ms must be an integer greater than 0"),
    )
