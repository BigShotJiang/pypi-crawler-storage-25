from __future__ import annotations

from typing import Any


class ActorMemory:
    def __init__(self) -> None:
        self._values: dict[str, Any] = {}
        self._notes: dict[str, Any] = {}

    def remember(self, key: str, value: Any) -> None:
        self._values[key] = value

    def recall(self, key: str) -> Any:
        if key not in self._values:
            raise RuntimeError(f'No value remembered for key "{key}"')
        return self._values[key]

    def maybe_recall(self, key: str) -> Any:
        return self._values.get(key)

    def forget(self, key: str) -> None:
        self._values.pop(key, None)

    def note(self, key: str, value: Any) -> None:
        self._notes[key] = value

    def recall_note(self, key: str) -> Any:
        return self._notes.get(key)

    def clear_note(self, key: str) -> None:
        self._notes.pop(key, None)

    def clear(self) -> None:
        self._values.clear()
        self._notes.clear()
