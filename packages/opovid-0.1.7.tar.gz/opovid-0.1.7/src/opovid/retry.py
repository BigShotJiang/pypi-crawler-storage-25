from __future__ import annotations

from typing import TypeVar

from .task import Task, task

T = TypeVar("T")


def with_retry(attempts: int, inner_task: Task) -> Task:
    if not isinstance(attempts, int) or attempts < 1:
        raise ValueError("with_retry attempts must be an integer greater than 0")
    if inner_task is None:
        raise ValueError("task")

    description = inner_task.description if attempts == 1 else f"{inner_task.description} (up to {attempts} attempts)"

    def perform_as(actor: object) -> T:
        last_error: BaseException | None = None
        for attempt in range(1, attempts + 1):
            try:
                return actor.attempts_to(inner_task)  # type: ignore[attr-defined,no-any-return]
            except Exception as error:
                last_error = error
                if attempt == attempts:
                    raise

        raise last_error or RuntimeError("unreachable")

    return task(description, perform_as)
