from __future__ import annotations

from typing import Any

from .actor import Actor
from .actor_memory import ActorMemory


class RememberTheState:
    def __init__(self, memory: ActorMemory) -> None:
        self._memory = memory

    @classmethod
    def using(cls, memory: ActorMemory) -> RememberTheState:
        return cls(memory)

    @classmethod
    def using_defaults(cls) -> RememberTheState:
        return cls(ActorMemory())

    def remember(self, key: str, value: Any) -> RememberTheState:
        self._memory.remember(key, value)
        return self

    def recall(self, key: str) -> Any:
        return self._memory.recall(key)

    def maybe_recall(self, key: str) -> Any:
        return self._memory.maybe_recall(key)

    def forget(self, key: str) -> RememberTheState:
        self._memory.forget(key)
        return self

    def note(self, key: str, value: Any) -> RememberTheState:
        self._memory.note(key, value)
        return self

    def recall_note(self, key: str) -> Any:
        return self._memory.recall_note(key)

    def clear_note(self, key: str) -> RememberTheState:
        self._memory.clear_note(key)
        return self

    def clear(self) -> RememberTheState:
        self._memory.clear()
        return self


def remembered_by(actor: Actor) -> RememberTheState:
    return actor.ability_to(RememberTheState)
