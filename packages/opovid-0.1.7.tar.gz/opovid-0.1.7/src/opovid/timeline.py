from __future__ import annotations

import json
from dataclasses import asdict, dataclass, is_dataclass
from typing import Any

from .execution import ExecutionError, ExecutionStep, ExecutionTimeline, TimelineEvent


@dataclass(frozen=True)
class FailureSummary:
    message: str
    preceding_events: tuple[TimelineEvent, ...]
    failed_step: ExecutionStep | None = None
    error: ExecutionError | None = None


def timeline_to_json(timeline: ExecutionTimeline) -> str:
    return f"{json.dumps(_to_wire(timeline), indent=2)}\n"


def summarize_failure(timeline: ExecutionTimeline, *, preceding_event_limit: int = 3) -> FailureSummary:
    failed_step = _find_deepest_failed_step(timeline.steps)
    last_failed_sequence = _last_failed_event_sequence(timeline, failed_step.id if failed_step else None)
    preceding_events = tuple(
        event
        for event in timeline.events
        if event.layer == "adapter" and (last_failed_sequence is None or event.sequence <= last_failed_sequence)
    )[-preceding_event_limit:]

    if failed_step is None:
        return FailureSummary(message="No failed step was recorded.", preceding_events=preceding_events)

    error_text = "" if failed_step.error is None else f": {failed_step.error.message}"
    adapter_text = "" if not preceding_events else f" Last adapter event: {_describe_event(preceding_events[-1])}."

    return FailureSummary(
        failed_step=failed_step,
        error=failed_step.error,
        preceding_events=preceding_events,
        message=f'Step "{failed_step.description}" failed{error_text}.{adapter_text}',
    )


def render_timeline(
    timeline: ExecutionTimeline,
    *,
    include_timestamps: bool = False,
    include_adapter_details: bool = True,
) -> str:
    lines = [f"Run {timeline.run_id} as {timeline.actor}"]

    for step in timeline.steps:
        lines.extend(
            _render_step(
                step,
                timeline.events,
                include_timestamps=include_timestamps,
                include_adapter_details=include_adapter_details,
            )
        )

    summary = summarize_failure(timeline)
    if summary.failed_step is not None:
        lines.extend(("", "Failure", f"  {summary.message}"))

    return "\n".join(lines) + "\n"


def _render_step(
    step: ExecutionStep,
    events: tuple[TimelineEvent, ...],
    *,
    include_timestamps: bool,
    include_adapter_details: bool,
    depth: int = 0,
) -> list[str]:
    indent = "  " * depth
    status = step.status or "pending"
    duration = "" if step.duration_ms is None else f" ({step.duration_ms}ms)"
    timeout = "" if step.timeout_ms is None else f" [timeout {step.timeout_ms}ms]"
    timestamp = "" if not include_timestamps else f" @{step.started_at}"
    lines = [f"{indent}{_status_symbol(status)} {step.description}{duration}{timeout}{timestamp}"]

    if step.error is not None:
        lines.append(f"{indent}  error: {step.error.message}")

    if include_adapter_details:
        lines.extend(
            f"{indent}  {_describe_event(event)}"
            for event in events
            if event.step_id == step.id and event.layer == "adapter"
        )

    for child in step.steps:
        lines.extend(
            _render_step(
                child,
                events,
                include_timestamps=include_timestamps,
                include_adapter_details=include_adapter_details,
                depth=depth + 1,
            )
        )

    return lines


def _find_deepest_failed_step(steps: tuple[ExecutionStep, ...]) -> ExecutionStep | None:
    for step in reversed(steps):
        nested = _find_deepest_failed_step(step.steps)
        if nested is not None:
            return nested
        if step.status == "failed":
            return step
    return None


def _last_failed_event_sequence(timeline: ExecutionTimeline, failed_step_id: str | None) -> int | None:
    sequences = [
        event.sequence
        for event in timeline.events
        if event.status == "failed" and (failed_step_id is None or event.step_id == failed_step_id)
    ]
    return sequences[-1] if sequences else None


def _describe_event(event: TimelineEvent) -> str:
    status = "" if event.status is None else f" [{event.status}]"
    details = "" if not event.data else f" {json.dumps(_to_wire(event.data), sort_keys=True)}"
    return f"{event.type}{status}{details}"


def _status_symbol(status: str) -> str:
    if status == "passed":
        return "PASS"
    if status == "failed":
        return "FAIL"
    return "RUN"


def _to_wire(value: Any) -> Any:
    if is_dataclass(value) and not isinstance(value, type):
        return _to_wire(asdict(value))
    if isinstance(value, dict):
        return {_wire_key(str(key)): _to_wire(nested) for key, nested in value.items() if nested is not None}
    if isinstance(value, (tuple, list)):
        return [_to_wire(nested) for nested in value]
    return value


def _wire_key(key: str) -> str:
    return {
        "schema_version": "schemaVersion",
        "run_id": "runId",
        "event_id": "eventId",
        "step_id": "stepId",
        "parent_step_id": "parentStepId",
        "started_at": "startedAt",
        "finished_at": "finishedAt",
        "duration_ms": "durationMs",
        "timeout_ms": "timeoutMs",
    }.get(key, key)
