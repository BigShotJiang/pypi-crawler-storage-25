from __future__ import annotations

from collections.abc import Callable
from typing import Any

from .actor import Actor
from .check import Check
from .execution import ExecutionEventEmitter, ExecutionEventInput, to_serializable_error
from .question import Question
from .task import Task


class AttemptChain:
    def __init__(self, actor: Actor, event_emitter: ExecutionEventEmitter) -> None:
        self._actor = actor
        self._event_emitter = event_emitter
        self._latest_value: Any = None

    def to(self, task_to_run: Task) -> AttemptChain:
        return self._run_task(task_to_run)

    def and_then(self, task_to_run: Task) -> AttemptChain:
        return self._run_task(task_to_run)

    def and_then_all(self, tasks: list[Task]) -> AttemptChain:
        for task_to_run in tasks:
            self._run_task(task_to_run)
        return self

    def prepare(self, task_to_run: Task) -> AttemptChain:
        return self._run_task(task_to_run)

    def attempts_to(self, task_to_run: Task) -> AttemptChain:
        return self._run_task(task_to_run)

    def attempts_to_authenticate(self, task_to_run: Task) -> AttemptChain:
        return self._run_task(task_to_run)

    def question(self, q: Question) -> AttemptChain:
        self._latest_value = self._actor.asks_for(q)
        return self

    def verifies_that(
        self,
        q: Question,
        verification: Callable[[Any, Actor], None],
        *additional_verifications: Callable[[Any, Actor], None],
    ) -> AttemptChain:
        return self._run_value(
            f"verifies that {q.description}",
            lambda actor: actor.asks_for(q),
            [verification, *additional_verifications],
        )

    def verifies(
        self,
        check_or_value: Check | Any | Callable[[Actor], Any],
        verification: Callable[[Any, Actor], None] | None = None,
        *additional_verifications: Callable[[Any, Actor], None],
    ) -> AttemptChain:
        if verification is None:
            if not isinstance(check_or_value, Check):
                raise TypeError("verifies(check) requires a Check")
            c = check_or_value
            if c.question is None:
                return self._run_value("verifies the latest value", lambda _actor: self._latest_value, [c.verify])
            return self.verifies_that(c.question, c.verify)

        value_provider = check_or_value if callable(check_or_value) else lambda _actor: check_or_value
        return self._run_value("verifies a value", value_provider, [verification, *additional_verifications])

    def latest(self) -> Any:
        return self._latest_value

    def done(self) -> Actor:
        return self._actor

    def _run_task(self, task_to_run: Task) -> AttemptChain:
        self._latest_value = self._actor.attempts_to(task_to_run)
        return self

    def _run_value(
        self,
        description: str,
        value_provider: Callable[[Actor], Any],
        verifications: list[Callable[[Any, Actor], None]],
    ) -> AttemptChain:
        def verify(actor: Actor) -> Any:
            actual = value_provider(actor)
            self._event_emitter.emit(
                ExecutionEventInput(
                    type="CheckStarted",
                    layer="intent",
                    status="pending",
                    data={"description": description},
                )
            )

            try:
                for verification in verifications:
                    verification(actual, actor)
            except BaseException as error:
                self._event_emitter.emit(
                    ExecutionEventInput(
                        type="CheckFailed",
                        layer="intent",
                        status="failed",
                        data={"description": description, "error": to_serializable_error(error)},
                    )
                )
                raise

            self._event_emitter.emit(
                ExecutionEventInput(type="CheckPassed", layer="intent", status="ok", data={"description": description})
            )
            return actual

        self._latest_value = self._actor.attempts_to(Task(description=description, perform_as=verify))
        return self
