from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from .question import Question

if TYPE_CHECKING:
    from .actor import Actor


@dataclass(frozen=True)
class Check:
    verify: Callable[[Any, Actor], None]
    question: Question | None = None


def check(
    question_or_verify: Question | Callable[[Any, Actor], None],
    verify: Callable[[Any, Actor], None] | None = None,
) -> Check:
    if verify is None:
        if not callable(question_or_verify):
            raise TypeError("check(verify) requires a verification function")
        return Check(verify=question_or_verify)

    if not isinstance(question_or_verify, Question):
        raise TypeError("check(question, verify) requires a Question")

    return Check(question=question_or_verify, verify=verify)
