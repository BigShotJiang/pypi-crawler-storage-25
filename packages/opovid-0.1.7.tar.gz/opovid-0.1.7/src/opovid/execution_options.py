from __future__ import annotations

from dataclasses import dataclass
from typing import Any

ExecutionMetadata = dict[str, Any]


@dataclass(frozen=True)
class ExecutionOptions:
    metadata: ExecutionMetadata | None = None
    timeout_ms: int | None = None


def require_timeout_ms(timeout_ms: int | None, message: str) -> int | None:
    if timeout_ms is None:
        return None
    if isinstance(timeout_ms, bool) or not isinstance(timeout_ms, int) or timeout_ms <= 0:
        raise ValueError(message)
    return timeout_ms
