from __future__ import annotations

from typing import Protocol


class Ability(Protocol):
    pass
