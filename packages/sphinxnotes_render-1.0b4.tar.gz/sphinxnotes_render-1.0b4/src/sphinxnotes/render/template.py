from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum

from docutils import nodes
from sphinx.transforms import SphinxTransform
from sphinx.util.docutils import SphinxDirective, SphinxRole


class Phase(Enum):
    """The phase of rendering template."""

    #: Render template on document parsing
    #: on (:py:class:`~sphinx.util.docutils.SphinxDirective`\ ``.run()`` or
    #: :py:class:`~sphinx.util.docutils.SphinxRole`\ ``.run()``).
    Parsing = 'parsing'
    #: Render template immediately after document has parsed
    #: (on Sphinx event :external:event:`doctree-read`).
    Parsed = 'parsed'
    #: Render template immediately after all documents have resolving
    #: (before Sphinx event :external:event:`doctree-resolved`).
    Resolving = 'resolving'

    @classmethod
    def default(cls) -> Phase:
        return cls.Parsing

    def __ge__(self, other: Phase) -> bool:
        _ORDER = {Phase.Parsing: 1, Phase.Parsed: 2, Phase.Resolving: 3}
        return _ORDER[self] >= _ORDER[other]


@dataclass
class Template:
    #: Jinja template for rendering the context.
    text: str
    #: The render phase.
    phase: Phase = Phase.default()
    #: Enable debug output (shown as :py:class:`docutils.nodes.system_message` in document.)
    debug: bool = False
    #: Names of extra context to be generated and available in the template.
    extra: list[str] = field(default_factory=list)


#: Possible render host of :meth:`pending_node.render`.
type Host = ParseHost | ResolveHost
#: Host of source parse phase (Phase.Parsing, Phase.Parsed).
type ParseHost = SphinxDirective | SphinxRole
#: Host of source parse phase (Phase.Parsing, Phase.Parsed).
type ResolveHost = SphinxTransform


@dataclass
class HostWrapper:
    v: Host

    @property
    def doctree(self) -> nodes.document:
        if isinstance(self.v, SphinxDirective):
            return self.v.state.document
        elif isinstance(self.v, SphinxRole):
            return self.v.inliner.document
        elif isinstance(self.v, SphinxTransform):
            return self.v.document
        else:
            raise NotImplementedError
