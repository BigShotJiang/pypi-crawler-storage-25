__version__ = "2.6.5"

def print_version():
    print(f"v{__version__}")

if __name__ == "__main__":
    print_version()
