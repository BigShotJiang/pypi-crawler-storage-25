"""Nox configuration for testing across multiple Python versions."""

import nox

# Use uv as the backend for faster environment creation
nox.options.default_venv_backend = "uv"
nox.options.reuse_existing_virtualenvs = True

# Python versions to test against
PYTHON_VERSIONS = ["3.10", "3.11", "3.12", "3.13"]


@nox.session(python=PYTHON_VERSIONS)
def tests(session):
    """Run the test suite across multiple Python versions."""
    session.install(".", "pytest", "pytest-cov")
    session.run("pytest", "tests/", "-v")


@nox.session(python=PYTHON_VERSIONS)
def test_with_coverage(session):
    """Run tests with coverage reporting."""
    session.install(".", "pytest", "pytest-cov")
    session.run(
        "pytest",
        "tests/",
        "-v",
        "--cov=src/extract_soft_clipped",
        "--cov-report=term-missing",
    )


@nox.session(python="3.13")
def lint(session):
    """Run linting with ruff."""
    session.install("ruff")
    session.run("ruff", "check", "src/", "tests/")


@nox.session(python="3.13")
def format_check(session):
    """Check code formatting."""
    session.install("ruff")
    session.run("ruff", "format", "--check", "src/", "tests/")


@nox.session(python="3.13")
def build_test(session):
    """Test that the package builds correctly."""
    session.install("build")
    session.run("python", "-m", "build")


@nox.session(python=PYTHON_VERSIONS)
def install_test(session):
    """Test package installation and basic functionality."""
    session.install(".")
    # Test that the CLI works
    session.run("extract-soft-clipped", "--help")


@nox.session(python="3.13")
def docs(session):
    """Build documentation (placeholder for future)."""
    session.log("Documentation building not yet implemented")


if __name__ == "__main__":
    nox.main()
