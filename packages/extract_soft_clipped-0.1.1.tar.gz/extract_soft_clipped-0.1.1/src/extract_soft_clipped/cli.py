"""Command-line interface for extracting soft-clipped sequences."""

import argparse
import sys

from .core import extract_soft_clips, parse_region, summarize_sequences


def main(argv: list | None = None) -> None:
    """Main entry point for the CLI."""
    parser = argparse.ArgumentParser(
        description="Extract soft-clipped sequences from BAM/SAM files",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument("sam_file", help="Input BAM or SAM file")

    # Mutually exclusive group for left/right
    side_group = parser.add_mutually_exclusive_group(required=True)
    side_group.add_argument(
        "--left", action="store_true", help="Extract left-clipped sequences"
    )
    side_group.add_argument(
        "--right", action="store_true", help="Extract right-clipped sequences"
    )

    parser.add_argument(
        "--summarize",
        type=int,
        metavar="N",
        help="Summarize frequency of N bases at the end of left-clipped regions or left of right-clipped regions",
    )

    parser.add_argument(
        "--min-length",
        type=int,
        metavar="N",
        default=0,
        help="Only include soft-clipped sequences of at least N bases in length",
    )

    parser.add_argument(
        "--region",
        action="append",
        metavar="START-END",
        help="Only include soft-clipped sequences that overlap specified reference region(s) (1-based inclusive coordinates, e.g., 1000-1025). Can be specified multiple times.",
    )

    # Mutually exclusive group for output format
    format_group = parser.add_mutually_exclusive_group()
    format_group.add_argument(
        "--fastq",
        action="store_true",
        help="Output sequences in FASTQ format with query IDs and quality scores",
    )
    format_group.add_argument(
        "--fasta",
        action="store_true",
        help="Output sequences in FASTA format with query IDs",
    )

    parser.add_argument(
        "--preserve-ids",
        action="store_true",
        help="Preserve original query IDs when using --fasta or --fastq (no sequence numbering or region info added)",
    )

    args = parser.parse_args(argv)

    # Parse regions if provided
    regions = None
    if args.region:
        regions = []
        for region_str in args.region:
            try:
                start, end = parse_region(region_str)
                regions.append((start, end))
            except ValueError as e:
                print(f"Error parsing region '{region_str}': {e}", file=sys.stderr)
                sys.exit(1)

    # Extract sequences
    sequences = extract_soft_clips(
        args.sam_file, args.left, args.right, args.min_length, regions
    )

    if args.summarize is not None:
        # Generate summary
        summary = summarize_sequences(sequences, args.summarize, args.left)

        print(f"Summary of {args.summarize}-base sequences:")
        print(f"Total sequences analyzed: {len(sequences)}")
        print(f"Unique {args.summarize}-mers: {len(summary)}")
        print()

        # Sort by frequency (descending)
        for seq, count in sorted(summary.items(), key=lambda x: x[1], reverse=True):
            print(f"{seq}\t{count}")
    else:
        # Output all sequences
        if args.fastq:
            # Output in FASTQ format
            for i, clipped_seq in enumerate(sequences):
                if args.preserve_ids:
                    header = clipped_seq.query_name
                else:
                    clip_type = "left" if clipped_seq.is_left_clip else "right"
                    header = f"{clipped_seq.query_name}_{clip_type}_{i + 1}"
                    if (
                        regions
                    ):  # Include reference coordinates if regions were specified
                        header += f"_region-{clipped_seq.reference_start}-{clipped_seq.reference_end}"
                print(f"@{header}")
                print(clipped_seq.sequence)
                print("+")
                print(clipped_seq.quality)
        elif args.fasta:
            # Output in FASTA format
            for i, clipped_seq in enumerate(sequences):
                if args.preserve_ids:
                    header = clipped_seq.query_name
                else:
                    clip_type = "left" if clipped_seq.is_left_clip else "right"
                    header = f"{clipped_seq.query_name}_{clip_type}_{i + 1}"
                    if (
                        regions
                    ):  # Include reference coordinates if regions were specified
                        header += f"_region-{clipped_seq.reference_start}-{clipped_seq.reference_end}"
                print(f">{header}")
                print(clipped_seq.sequence)
        else:
            # Output raw sequences
            for clipped_seq in sequences:
                print(clipped_seq.sequence)


if __name__ == "__main__":
    main()
