"""Core functions for extracting soft-clipped sequences from BAM/SAM files."""

import sys
from collections import Counter
from collections.abc import Generator
from typing import NamedTuple

import pysam


class ClippedSequence(NamedTuple):
    """Container for a clipped sequence with its metadata."""

    sequence: str
    quality: str
    query_name: str
    is_left_clip: bool
    reference_name: str
    reference_start: int  # 1-based start of soft-clipped region on reference
    reference_end: int  # 1-based end of soft-clipped region on reference


def parse_region(region_str: str) -> tuple[int, int]:
    """
    Parse a region string like '1000-1025' into start and end coordinates.

    Args:
        region_str: Region string in format 'start-end' (1-based inclusive)

    Returns:
        Tuple of (start, end) in 1-based inclusive coordinates

    Raises:
        ValueError: If region string is invalid
    """
    try:
        start_str, end_str = region_str.split("-", 1)
        start = int(start_str)
        end = int(end_str)
        if start <= 0 or end <= 0 or start > end:
            raise ValueError(f"Invalid region: {region_str}")
        return start, end
    except ValueError as e:
        raise ValueError(f"Invalid region format '{region_str}': {e}") from e


def regions_overlap(start1: int, end1: int, start2: int, end2: int) -> bool:
    """
    Check if two regions overlap (1-based inclusive coordinates).

    Args:
        start1, end1: First region coordinates
        start2, end2: Second region coordinates

    Returns:
        True if regions overlap, False otherwise
    """
    return start1 <= end2 and start2 <= end1


def calculate_clip_reference_coordinates(
    alignment_start: int,  # 0-based from pysam
    cigar_tuples: list[tuple[int, int]],
    is_left_clip: bool,
    clip_length: int,
) -> tuple[int, int]:
    """
    Calculate the reference coordinates where a soft-clipped region would map.

    Args:
        alignment_start: 0-based alignment start position from pysam
        cigar_tuples: CIGAR tuples from pysam
        is_left_clip: True for left clip, False for right clip
        clip_length: Length of the clipped sequence

    Returns:
        Tuple of (ref_start, ref_end) in 1-based inclusive coordinates
    """
    if is_left_clip:
        # Left clips map before the alignment start
        # alignment_start is 0-based, convert to 1-based and map clip before it
        alignment_start_1based = alignment_start + 1
        ref_end = alignment_start_1based - 1
        ref_start = ref_end - clip_length + 1
    else:
        # Right clips map after the alignment end
        # Calculate alignment end by summing M, D, N operations
        alignment_length = sum(
            length for op, length in cigar_tuples if op in [0, 2, 3]
        )  # M, D, N operations
        alignment_end_1based = (
            alignment_start + 1 + alignment_length - 1
        )  # Convert to 1-based inclusive
        ref_start = alignment_end_1based + 1
        ref_end = ref_start + clip_length - 1

    return ref_start, ref_end


def parse_cigar_for_clips(
    cigar_tuples: list[tuple[int, int]], sequence: str
) -> tuple[str | None, str | None]:
    """
    Parse CIGAR tuples to extract left and right soft-clipped sequences.

    Args:
        cigar_tuples: List of (operation, length) tuples from pysam
        sequence: The read sequence

    Returns:
        Tuple of (left_clip, right_clip) where each can be None if no clip exists
    """
    if not cigar_tuples:
        return None, None

    left_clip = None
    right_clip = None

    # Check for left soft clip (first operation)
    if cigar_tuples[0][0] == 4:  # 4 = soft clip in pysam
        clip_length = cigar_tuples[0][1]
        left_clip = sequence[:clip_length]

    # Check for right soft clip (last operation)
    if cigar_tuples[-1][0] == 4:  # 4 = soft clip in pysam
        clip_length = cigar_tuples[-1][1]
        right_clip = sequence[-clip_length:]

    return left_clip, right_clip


def extract_soft_clips_iter(
    sam_file: str,
    extract_left: bool,
    extract_right: bool,
    min_length: int = 0,
    regions: list[tuple[int, int]] | None = None,
) -> Generator[ClippedSequence, None, None]:
    """
    Generator that yields soft-clipped sequences from a SAM/BAM file.

    Args:
        sam_file: Path to SAM/BAM file
        extract_left: Whether to extract left-clipped sequences
        extract_right: Whether to extract right-clipped sequences
        min_length: Minimum length of soft-clipped sequences to include
        regions: Optional list of (start, end) tuples in 1-based inclusive coordinates
                to filter by reference overlap

    Yields:
        ClippedSequence objects that meet the criteria
    """
    try:
        with pysam.AlignmentFile(
            sam_file, "rb" if sam_file.endswith(".bam") else "r"
        ) as sam:
            for read in sam:
                if read.is_unmapped or not read.cigartuples or not read.query_sequence:
                    continue

                left_clip, right_clip = parse_cigar_for_clips(
                    read.cigartuples, read.query_sequence
                )
                quality_scores = read.query_qualities or [33] * len(
                    read.query_sequence
                )  # Default to '!' if no qualities

                # Get reference name
                reference_name = (
                    sam.get_reference_name(read.reference_id)
                    if read.reference_id >= 0
                    else "unknown"
                )

                if extract_left and left_clip and len(left_clip) >= min_length:
                    # Calculate reference coordinates for left clip
                    ref_start, ref_end = calculate_clip_reference_coordinates(
                        read.reference_start, read.cigartuples, True, len(left_clip)
                    )

                    # Check region overlap if regions specified
                    if regions and not any(
                        regions_overlap(ref_start, ref_end, reg_start, reg_end)
                        for reg_start, reg_end in regions
                    ):
                        continue

                    # Quality scores for left clip (first N bases)
                    left_quality = "".join(
                        chr(q + 33) for q in quality_scores[: len(left_clip)]
                    )
                    yield ClippedSequence(
                        sequence=left_clip,
                        quality=left_quality,
                        query_name=read.query_name or "unknown",
                        is_left_clip=True,
                        reference_name=reference_name,
                        reference_start=ref_start,
                        reference_end=ref_end,
                    )

                if extract_right and right_clip and len(right_clip) >= min_length:
                    # Calculate reference coordinates for right clip
                    ref_start, ref_end = calculate_clip_reference_coordinates(
                        read.reference_start, read.cigartuples, False, len(right_clip)
                    )

                    # Check region overlap if regions specified
                    if regions and not any(
                        regions_overlap(ref_start, ref_end, reg_start, reg_end)
                        for reg_start, reg_end in regions
                    ):
                        continue

                    # Quality scores for right clip (last N bases)
                    right_quality = "".join(
                        chr(q + 33) for q in quality_scores[-len(right_clip) :]
                    )
                    yield ClippedSequence(
                        sequence=right_clip,
                        quality=right_quality,
                        query_name=read.query_name or "unknown",
                        is_left_clip=False,
                        reference_name=reference_name,
                        reference_start=ref_start,
                        reference_end=ref_end,
                    )

    except Exception as e:
        print(f"Error reading file {sam_file}: {e}", file=sys.stderr)
        raise


def extract_soft_clips(
    sam_file: str,
    extract_left: bool,
    extract_right: bool,
    min_length: int = 0,
    regions: list[tuple[int, int]] | None = None,
) -> list[ClippedSequence]:
    """
    Extract soft-clipped sequences from a SAM/BAM file.

    Args:
        sam_file: Path to SAM/BAM file
        extract_left: Whether to extract left-clipped sequences
        extract_right: Whether to extract right-clipped sequences
        min_length: Minimum length of soft-clipped sequences to include
        regions: Optional list of (start, end) tuples in 1-based inclusive coordinates
                to filter by reference overlap

    Returns:
        List of ClippedSequence objects that meet the criteria
    """
    return list(
        extract_soft_clips_iter(
            sam_file, extract_left, extract_right, min_length, regions
        )
    )


def summarize_sequences(
    sequences: list[ClippedSequence], n_bases: int, is_left_clip: bool
) -> dict[str, int]:
    """
    Summarize the frequency of N bases at the specified end of clipped sequences.

    Args:
        sequences: List of ClippedSequence objects
        n_bases: Number of bases to consider for summary
        is_left_clip: True if these are left-clipped sequences, False for right-clipped

    Returns:
        Dictionary with sequence counts
    """
    summary_sequences = []

    for clipped_seq in sequences:
        seq = clipped_seq.sequence
        if len(seq) >= n_bases:
            if is_left_clip:
                # For left clips, take the last N bases (end closest to alignment)
                summary_seq = seq[-n_bases:]
            else:
                # For right clips, take the first N bases (beginning closest to alignment)
                summary_seq = seq[:n_bases]
            summary_sequences.append(summary_seq)

    return dict(Counter(summary_sequences))
