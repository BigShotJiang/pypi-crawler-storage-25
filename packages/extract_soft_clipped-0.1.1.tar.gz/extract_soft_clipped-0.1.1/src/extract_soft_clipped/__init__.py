"""Extract soft-clipped sequences from BAM/SAM files."""

from .core import ClippedSequence, extract_soft_clips, parse_cigar_for_clips

__all__ = [
    "extract_soft_clips",
    "ClippedSequence",
    "parse_cigar_for_clips",
    "__version__",
]


def __getattr__(name):
    """Dynamically get version from package metadata."""
    if name == "__version__":
        try:
            from importlib.metadata import version

            return version("extract-soft-clipped")
        except ImportError:
            # Fallback for Python < 3.8
            from importlib_metadata import version

            return version("extract-soft-clipped")
        except Exception:
            return "unknown"
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
