"""Tests for the CLI interface."""

from io import StringIO
from pathlib import Path
from unittest.mock import patch

import pytest

from extract_soft_clipped.cli import main


@pytest.fixture
def test_sam_file():
    """Return path to the static test SAM file."""
    return str(Path(__file__).parent / "simple_test.sam")


def test_cli_left_clips(test_sam_file):
    """Test CLI with --left option."""
    with patch("sys.stdout", new=StringIO()) as mock_stdout:
        main(["--left", test_sam_file])
        output = mock_stdout.getvalue().strip().split("\n")

    # Should output 1 left-clipped sequence
    assert len(output) == 1
    assert "AAAAAAAAAA" in output  # read1 left clip


def test_cli_right_clips(test_sam_file):
    """Test CLI with --right option."""
    with patch("sys.stdout", new=StringIO()) as mock_stdout:
        main(["--right", test_sam_file])
        output = mock_stdout.getvalue().strip().split("\n")

    # Should output 1 right-clipped sequence
    assert len(output) == 1
    assert "CCCCCCCCCCCCCCC" in output  # read2 right clip


def test_cli_min_length(test_sam_file):
    """Test CLI with --min-length option."""
    with patch("sys.stdout", new=StringIO()) as mock_stdout:
        main(["--left", "--min-length", "10", test_sam_file])
        output = mock_stdout.getvalue().strip().split("\n")

    # Should only include clips >= 10 bases (read1 and potentially others)
    # read3's left clip (5 bases) should be excluded
    assert "CCCCC" not in output
    assert len(output) <= 2  # At most 2 sequences should pass the filter


def test_cli_fastq_format(test_sam_file):
    """Test CLI with --fastq option."""
    with patch("sys.stdout", new=StringIO()) as mock_stdout:
        main(["--left", "--fastq", test_sam_file])
        output = mock_stdout.getvalue().strip().split("\n")

    # FASTQ format should have 4 lines per sequence
    assert len(output) % 4 == 0

    # Check FASTQ structure
    for i in range(0, len(output), 4):
        assert output[i].startswith("@")  # Header line
        assert not output[i + 1].startswith("@")  # Sequence line
        assert output[i + 2] == "+"  # Plus line
        assert not output[i + 3].startswith("@")  # Quality line


def test_cli_fasta_format(test_sam_file):
    """Test CLI with --fasta option."""
    with patch("sys.stdout", new=StringIO()) as mock_stdout:
        main(["--left", "--fasta", test_sam_file])
        output = mock_stdout.getvalue().strip().split("\n")

    # FASTA format should have 2 lines per sequence
    assert len(output) % 2 == 0

    # Check FASTA structure
    for i in range(0, len(output), 2):
        assert output[i].startswith(">")  # Header line
        assert not output[i + 1].startswith(">")  # Sequence line

    # Check specific content
    assert ">read1_left_1" in output
    assert "AAAAAAAAAA" in output


def test_cli_format_mutual_exclusivity():
    """Test that --fasta and --fastq are mutually exclusive."""
    with pytest.raises(SystemExit):
        main(["--left", "--fasta", "--fastq", "test.sam"])


def test_cli_region_filtering(test_sam_file):
    """Test CLI with --region option."""
    # Test region that doesn't overlap - should get no output
    with patch("sys.stdout", new=StringIO()) as mock_stdout:
        main(["--left", "--region", "200-300", test_sam_file])
        output = mock_stdout.getvalue().strip()
    assert output == ""

    # Test region that overlaps
    with patch("sys.stdout", new=StringIO()) as mock_stdout:
        main(["--left", "--region", "95-105", test_sam_file])
        output = mock_stdout.getvalue().strip()
    assert "AAAAAAAAAA" in output


def test_cli_region_with_fasta(test_sam_file):
    """Test CLI with --region and --fasta options."""
    with patch("sys.stdout", new=StringIO()) as mock_stdout:
        main(["--left", "--fasta", "--region", "95-105", test_sam_file])
        output = mock_stdout.getvalue().strip().split("\n")

    # Should have FASTA format with region coordinates in header
    assert len(output) == 2
    assert output[0].startswith(">read1_left_1_region-")
    assert "region-90-99" in output[0]
    assert output[1] == "AAAAAAAAAA"


def test_cli_multiple_regions(test_sam_file):
    """Test CLI with multiple --region options."""
    with patch("sys.stdout", new=StringIO()) as mock_stdout:
        main(["--left", "--region", "95-105", "--region", "200-300", test_sam_file])
        output = mock_stdout.getvalue().strip()

    # Should match the first region
    assert "AAAAAAAAAA" in output


def test_cli_invalid_region():
    """Test CLI with invalid region format."""
    with patch("sys.stderr", new=StringIO()):
        with pytest.raises(SystemExit):
            main(["--left", "--region", "invalid", "test.sam"])


def test_cli_preserve_ids_fasta(test_sam_file):
    """Test CLI with --preserve-ids and --fasta options."""
    with patch("sys.stdout", new=StringIO()) as mock_stdout:
        main(["--left", "--fasta", "--preserve-ids", test_sam_file])
        output = mock_stdout.getvalue().strip().split("\n")

    # Should have FASTA format with original query ID only
    assert len(output) == 2
    assert output[0] == ">read1"  # Original query name, no modifications
    assert output[1] == "AAAAAAAAAA"


def test_cli_preserve_ids_fastq(test_sam_file):
    """Test CLI with --preserve-ids and --fastq options."""
    with patch("sys.stdout", new=StringIO()) as mock_stdout:
        main(["--left", "--fastq", "--preserve-ids", test_sam_file])
        output = mock_stdout.getvalue().strip().split("\n")

    # Should have FASTQ format with original query ID only
    assert len(output) == 4
    assert output[0] == "@read1"  # Original query name, no modifications
    assert output[1] == "AAAAAAAAAA"
    assert output[2] == "+"
    assert output[3] == "IIIIIIIIII"


def test_cli_preserve_ids_with_regions(test_sam_file):
    """Test CLI with --preserve-ids, --fasta, and --region options."""
    with patch("sys.stdout", new=StringIO()) as mock_stdout:
        main(
            ["--left", "--fasta", "--preserve-ids", "--region", "90-100", test_sam_file]
        )
        output = mock_stdout.getvalue().strip().split("\n")

    # Should have FASTA format with original query ID (no region info added)
    assert len(output) == 2
    assert output[0] == ">read1"  # Original query name, no region suffix
    assert output[1] == "AAAAAAAAAA"


def test_cli_preserve_ids_raw_sequences(test_sam_file):
    """Test that --preserve-ids has no effect on raw sequence output."""
    # Without --preserve-ids
    with patch("sys.stdout", new=StringIO()) as mock_stdout:
        main(["--left", test_sam_file])
        output1 = mock_stdout.getvalue()

    # With --preserve-ids (should be the same for raw sequences)
    with patch("sys.stdout", new=StringIO()) as mock_stdout:
        main(["--left", "--preserve-ids", test_sam_file])
        output2 = mock_stdout.getvalue()

    assert output1 == output2  # Should be identical


def test_cli_summarize(test_sam_file):
    """Test CLI with --summarize option."""
    with patch("sys.stdout", new=StringIO()) as mock_stdout:
        main(["--left", "--summarize", "5", test_sam_file])
        output = mock_stdout.getvalue().strip()

    # Should contain summary information
    assert "Summary of 5-base sequences:" in output
    assert "Total sequences analyzed:" in output
    assert "Unique 5-mers:" in output


def test_cli_invalid_arguments():
    """Test CLI with invalid arguments."""
    # Missing required argument
    with pytest.raises(SystemExit):
        main([])

    # Both --left and --right
    with pytest.raises(SystemExit):
        main(["--left", "--right", "test.sam"])

    # Neither --left nor --right
    with pytest.raises(SystemExit):
        main(["test.sam"])


def test_cli_nonexistent_file():
    """Test CLI with non-existent file."""
    with pytest.raises(FileNotFoundError):
        main(["--left", "nonexistent.sam"])


def test_cli_help():
    """Test CLI help output."""
    with pytest.raises(SystemExit):
        main(["--help"])


@patch("sys.stdout", new=StringIO())
def test_cli_empty_output(test_sam_file):
    """Test CLI when no clips match criteria."""
    # Use very high min-length that no clips will match
    main(["--left", "--min-length", "1000", test_sam_file])
    # Should run without error even with no output
