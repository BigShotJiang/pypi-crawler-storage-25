"""Test package for extract_soft_clipped."""
