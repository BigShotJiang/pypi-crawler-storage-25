"""Tests for the core extract_soft_clipped functions."""

from pathlib import Path

import pytest

from extract_soft_clipped.core import (
    ClippedSequence,
    calculate_clip_reference_coordinates,
    extract_soft_clips,
    extract_soft_clips_iter,
    parse_cigar_for_clips,
    parse_region,
    regions_overlap,
    summarize_sequences,
)


@pytest.fixture
def test_sam_file():
    """Return path to the static test SAM file."""
    return str(Path(__file__).parent / "simple_test.sam")


def test_parse_cigar_for_clips():
    """Test parsing CIGAR tuples for soft clips."""
    # Test left clip only: 10S40M
    cigar_tuples = [(4, 10), (0, 40)]  # 4=soft clip, 0=match
    sequence = "A" * 50
    left_clip, right_clip = parse_cigar_for_clips(cigar_tuples, sequence)
    assert left_clip == "A" * 10
    assert right_clip is None

    # Test right clip only: 40M15S
    cigar_tuples = [(0, 40), (4, 15)]
    sequence = "T" * 55
    left_clip, right_clip = parse_cigar_for_clips(cigar_tuples, sequence)
    assert left_clip is None
    assert right_clip == "T" * 15

    # Test both clips: 5S30M10S
    cigar_tuples = [(4, 5), (0, 30), (4, 10)]
    sequence = "C" * 5 + "G" * 30 + "A" * 10
    left_clip, right_clip = parse_cigar_for_clips(cigar_tuples, sequence)
    assert left_clip == "C" * 5
    assert right_clip == "A" * 10

    # Test no clips: 50M
    cigar_tuples = [(0, 50)]
    sequence = "G" * 50
    left_clip, right_clip = parse_cigar_for_clips(cigar_tuples, sequence)
    assert left_clip is None
    assert right_clip is None


def test_extract_soft_clips_left(test_sam_file):
    """Test extracting left-clipped sequences."""
    clips = extract_soft_clips(test_sam_file, extract_left=True, extract_right=False)

    # Should extract left clips from read1 only (simple_test.sam has read1 with left clip)
    assert len(clips) == 1

    # Check sequences
    sequences = [clip.sequence for clip in clips]
    assert "AAAAAAAAAA" in sequences  # read1: 10S40M

    # Check query names
    query_names = [clip.query_name for clip in clips]
    assert "read1" in query_names


def test_extract_soft_clips_right(test_sam_file):
    """Test extracting right-clipped sequences."""
    clips = extract_soft_clips(test_sam_file, extract_left=False, extract_right=True)

    # Should extract right clips from read2 only (simple_test.sam has read2 with right clip)
    assert len(clips) == 1

    # Check sequences
    sequences = [clip.sequence for clip in clips]
    assert "CCCCCCCCCCCCCCC" in sequences  # read2: 40M15S

    # Check query names
    query_names = [clip.query_name for clip in clips]
    assert "read2" in query_names


def test_extract_soft_clips_min_length(test_sam_file):
    """Test minimum length filtering."""
    # Extract left clips with min_length=10
    clips = extract_soft_clips(
        test_sam_file, extract_left=True, extract_right=False, min_length=10
    )

    # Should include read1 (10 bases exactly)
    assert len(clips) == 1
    sequences = [clip.sequence for clip in clips]
    assert "AAAAAAAAAA" in sequences  # read1

    # Test with higher min_length that excludes everything
    clips_empty = extract_soft_clips(
        test_sam_file, extract_left=True, extract_right=False, min_length=20
    )
    assert len(clips_empty) == 0


def test_extract_soft_clips_iter(test_sam_file):
    """Test the iterator version of extract_soft_clips."""
    clips = list(
        extract_soft_clips_iter(test_sam_file, extract_left=True, extract_right=False)
    )

    assert len(clips) == 1
    assert all(isinstance(clip, ClippedSequence) for clip in clips)
    assert all(clip.is_left_clip for clip in clips)


def test_quality_scores(test_sam_file):
    """Test that quality scores are correctly extracted."""
    clips = extract_soft_clips(test_sam_file, extract_left=True, extract_right=False)

    # Should have 1 clip
    assert len(clips) == 1

    # Check that quality scores have the same length as sequences
    for clip in clips:
        assert len(clip.quality) == len(clip.sequence)
        # Quality scores should be valid ASCII characters
        assert all(ord(q) >= 33 for q in clip.quality)


def test_summarize_sequences():
    """Test sequence summarization functionality."""
    clips = [
        ClippedSequence("AAAAAAAAAA", "IIIIIIIIII", "read1", True, "chr1", 90, 99),
        ClippedSequence("AAAAATTTTTT", "IIIIIHHHHHH", "read2", True, "chr1", 85, 95),
        ClippedSequence("GGGGGGGGGG", "JJJJJJJJJJ", "read3", True, "chr1", 80, 89),
        ClippedSequence("AAAAAGGGGGG", "IIIIIIJJJJJ", "read4", True, "chr1", 75, 85),
    ]

    # Summarize last 5 bases for left clips
    summary = summarize_sequences(clips, 5, is_left_clip=True)

    expected = {
        "AAAAA": 1,  # read1 ends with AAAAA
        "TTTTT": 1,  # read2 ends with TTTTT
        "GGGGG": 2,  # read3 and read4 end with GGGGG
    }

    assert summary == expected


def test_summarize_sequences_right_clips():
    """Test summarization of right clips."""
    clips = [
        ClippedSequence("TTTTTTAAAA", "HHHHHHHIII", "read1", False, "chr1", 140, 149),
        ClippedSequence("GGGGGGAAAA", "JJJJJJJIII", "read2", False, "chr1", 240, 249),
        ClippedSequence("CCCCCCAAAA", "GGGGGGGIII", "read3", False, "chr1", 340, 349),
    ]

    # Summarize first 4 bases for right clips
    summary = summarize_sequences(clips, 4, is_left_clip=False)

    expected = {
        "TTTT": 1,  # read1 starts with TTTT
        "GGGG": 1,  # read2 starts with GGGG
        "CCCC": 1,  # read3 starts with CCCC
    }

    assert summary == expected


def test_clipped_sequence_namedtuple():
    """Test ClippedSequence NamedTuple functionality."""
    clip = ClippedSequence("ATCG", "IIII", "test_read", True, "chr1", 100, 103)

    assert clip.sequence == "ATCG"
    assert clip.quality == "IIII"
    assert clip.query_name == "test_read"
    assert clip.is_left_clip is True
    assert clip.reference_name == "chr1"
    assert clip.reference_start == 100
    assert clip.reference_end == 103

    # Test immutability
    with pytest.raises(AttributeError):
        clip.sequence = "GCTA"


def test_parse_region():
    """Test region parsing functionality."""
    # Valid regions
    assert parse_region("100-200") == (100, 200)
    assert parse_region("1-1") == (1, 1)
    assert parse_region("1000-2000") == (1000, 2000)

    # Invalid regions
    with pytest.raises(ValueError):
        parse_region("200-100")  # Start > end

    with pytest.raises(ValueError):
        parse_region("0-100")  # Start <= 0

    with pytest.raises(ValueError):
        parse_region("100-0")  # End <= 0

    with pytest.raises(ValueError):
        parse_region("100")  # Missing end

    with pytest.raises(ValueError):
        parse_region("100-200-300")  # Too many parts

    with pytest.raises(ValueError):
        parse_region("abc-def")  # Non-numeric


def test_regions_overlap():
    """Test region overlap detection."""
    # Overlapping regions
    assert regions_overlap(100, 200, 150, 250) is True  # Partial overlap
    assert regions_overlap(100, 200, 100, 200) is True  # Exact match
    assert regions_overlap(100, 200, 50, 150) is True  # Left overlap
    assert regions_overlap(100, 200, 150, 300) is True  # Right overlap
    assert regions_overlap(100, 200, 120, 180) is True  # Contained
    assert regions_overlap(120, 180, 100, 200) is True  # Contains

    # Non-overlapping regions
    assert regions_overlap(100, 200, 250, 300) is False  # Gap between
    assert regions_overlap(250, 300, 100, 200) is False  # Gap between (reversed)
    assert regions_overlap(100, 200, 201, 300) is False  # Adjacent (no overlap)
    assert regions_overlap(201, 300, 100, 200) is False  # Adjacent (reversed)


def test_calculate_clip_reference_coordinates():
    """Test calculation of reference coordinates for soft clips."""
    # Left clip: 10S40M at position 100 (0-based)
    # Alignment covers 101-140 (1-based), so clip maps to positions 91-100
    cigar_left = [(4, 10), (0, 40)]  # 10S40M
    ref_start, ref_end = calculate_clip_reference_coordinates(100, cigar_left, True, 10)
    assert ref_start == 91
    assert ref_end == 100

    # Right clip: 40M15S at position 100 (0-based)
    # Alignment covers 101-140 (1-based), so clip maps to positions 141-155
    cigar_right = [(0, 40), (4, 15)]  # 40M15S
    ref_start, ref_end = calculate_clip_reference_coordinates(
        100, cigar_right, False, 15
    )
    assert ref_start == 141
    assert ref_end == 155

    # Both clips: 5S30M10S at position 100 (0-based)
    cigar_both = [(4, 5), (0, 30), (4, 10)]  # 5S30M10S

    # Left clip: alignment covers 101-130, so clip maps to positions 96-100
    ref_start, ref_end = calculate_clip_reference_coordinates(100, cigar_both, True, 5)
    assert ref_start == 96
    assert ref_end == 100

    # Right clip: alignment covers 101-130, so clip maps to positions 131-140
    ref_start, ref_end = calculate_clip_reference_coordinates(
        100, cigar_both, False, 10
    )
    assert ref_start == 131
    assert ref_end == 140


def test_extract_soft_clips_with_regions(test_sam_file):
    """Test extracting soft-clipped sequences with region filtering."""
    # Test without regions (should get all clips)
    clips_all = extract_soft_clips(
        test_sam_file, extract_left=True, extract_right=False
    )
    assert len(clips_all) == 1

    # Test with region that doesn't overlap
    clips_no_overlap = extract_soft_clips(
        test_sam_file,
        extract_left=True,
        extract_right=False,
        regions=[(200, 300)],  # Far from our clips
    )
    assert len(clips_no_overlap) == 0

    # Test with region that overlaps (need to know actual coordinates from simple_test.sam)
    # read1 is at SAM position 100 (1-based), which is pysam position 99 (0-based)
    # Left clip with 10S maps to positions 90-99 (1-based)
    clips_overlap = extract_soft_clips(
        test_sam_file,
        extract_left=True,
        extract_right=False,
        regions=[(95, 105)],  # Overlaps with 90-99
    )
    assert len(clips_overlap) == 1
    assert clips_overlap[0].reference_start == 90
    assert clips_overlap[0].reference_end == 99
