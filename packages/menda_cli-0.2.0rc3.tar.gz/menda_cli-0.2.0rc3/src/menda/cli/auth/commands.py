"""Auth CLI commands — thin wrappers over menda.auth business logic."""

import click

from menda.cli.console import Console
from menda.cli.params import menda_profile_id


@click.group()
def auth() -> None:
    """Authenticate to Menda Cloud."""


@auth.command("configure")
@click.pass_context
def configure(ctx: click.Context) -> None:
    """Configure authentication profile for Menda Cloud."""
    from menda.auth.task import configure as do_configure

    console: Console = ctx.obj["console"]
    do_configure(console)


@auth.command("login")
@menda_profile_id
@click.pass_context
def login(ctx: click.Context, menda_profile_id: str | None) -> None:
    """Login to Menda Cloud via device flow."""
    from menda.auth.task import login as do_login

    console: Console = ctx.obj["console"]
    do_login(console, menda_profile_id)


@auth.command("whoami")
@menda_profile_id
@click.pass_context
def whoami(ctx: click.Context, menda_profile_id: str | None) -> None:
    """Show the current authenticated user."""
    from menda.auth.task import whoami as do_whoami

    console: Console = ctx.obj["console"]
    do_whoami(console, menda_profile_id)
