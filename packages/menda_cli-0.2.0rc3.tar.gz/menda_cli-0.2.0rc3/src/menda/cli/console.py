"""Console abstraction for user-facing CLI output."""

import json
import sys
from collections.abc import Iterator
from contextlib import contextmanager
from enum import StrEnum

from rich.console import Console as RichConsole
from rich.table import Table


class OutputMode(StrEnum):
    """Output mode for the CLI."""

    TEXT = "text"
    JSON = "json"


class Console:
    """User-facing output interface.

    All user-visible output should go through this class.
    Diagnostic/internal output should use structlog instead.

    Styled messages (success, error, warning, info) write to stderr.
    Data output (table, json) writes to stdout.
    """

    def __init__(
        self,
        output: OutputMode = OutputMode.TEXT,
        quiet: bool = False,
        no_color: bool = False,
    ) -> None:
        """Initialise Console with output mode, quiet flag, and color settings."""
        self._output = output
        self._quiet = quiet
        self._no_color = no_color

    def _stderr_rich(self) -> RichConsole:
        """Rich console for stderr — built at use time so Click test isolation sees patched sys.stderr."""
        return RichConsole(stderr=True, no_color=self._no_color, file=sys.stderr)

    def _stdout_rich(self) -> RichConsole:
        """Rich console for stdout — built at use time so Click test isolation sees patched sys.stdout."""
        return RichConsole(no_color=self._no_color, file=sys.stdout)

    @property
    def output_mode(self) -> OutputMode:
        """Expose current output mode for commands that need conditional logic."""
        return self._output

    def success(self, message: str) -> None:
        """Display a success message (stderr)."""
        if self._quiet:
            return
        if self._output == OutputMode.JSON:
            self._write_stderr_json({"status": "success", "message": message})
        else:
            self._stderr_rich().print(f"[green]{message}[/green]")

    def error(self, message: str) -> None:
        """Display an error message (stderr). Always shown, even in quiet mode."""
        if self._output == OutputMode.JSON:
            self._write_stderr_json({"status": "error", "message": message})
        else:
            self._stderr_rich().print(f"[bold red]{message}[/bold red]")

    def warning(self, message: str) -> None:
        """Display a warning message (stderr)."""
        if self._quiet:
            return
        if self._output == OutputMode.JSON:
            self._write_stderr_json({"status": "warning", "message": message})
        else:
            self._stderr_rich().print(f"[yellow]{message}[/yellow]")

    def info(self, message: str) -> None:
        """Display an informational message (stderr). Suppressed in JSON mode."""
        if self._quiet or self._output == OutputMode.JSON:
            return
        self._stderr_rich().print(message)

    def table(self, headers: list[str], rows: list[list[str]]) -> None:
        """Display tabular data. Text mode: rich table (stdout). JSON mode: JSON array (stdout)."""
        if self._quiet:
            return
        if self._output == OutputMode.JSON:
            data = [dict(zip(headers, row, strict=True)) for row in rows]
            self._write_stdout_json(data)
        else:
            t = Table()
            for h in headers:
                t.add_column(h)
            for row in rows:
                t.add_row(*row)
            self._stdout_rich().print(t)

    def json(self, data: dict | list) -> None:
        """Display JSON data. Text mode: pretty-printed (stdout). JSON mode: raw (stdout)."""
        if self._quiet:
            return
        if self._output == OutputMode.JSON:
            self._write_stdout_json(data)
        else:
            self._stdout_rich().print_json(data=data)

    @contextmanager
    def progress(self, description: str) -> Iterator[None]:
        """Display a spinner/progress indicator (stderr). Silent in JSON/quiet mode."""
        if self._quiet or self._output == OutputMode.JSON:
            yield
            return
        with self._stderr_rich().status(description):
            yield

    def _write_stderr_json(self, data: dict) -> None:
        """Write JSON data to stderr."""
        sys.stderr.write(json.dumps(data) + "\n")
        sys.stderr.flush()

    def _write_stdout_json(self, data: dict | list) -> None:
        """Write JSON data to stdout."""
        sys.stdout.write(json.dumps(data) + "\n")
        sys.stdout.flush()
