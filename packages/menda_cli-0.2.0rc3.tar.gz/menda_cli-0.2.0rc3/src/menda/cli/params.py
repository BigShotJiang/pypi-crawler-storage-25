"""Shared Click parameter decorators for the menda CLI.

These are reusable across all plugin packages. Domain-specific
params belong in the plugin's own params module.
"""

from collections.abc import Callable
from typing import Any

import click


def menda_profile_id(fn: Callable[..., Any]) -> Callable[..., Any]:
    """--menda-profile-id option for commands needing auth."""
    return click.option(
        "--menda-profile-id",
        envvar="MENDA_PROFILE_ID",
        required=False,
        default=None,
        type=str,
        help="Menda Cloud authentication profile. Falls back to MENDA_PROFILE_ID env var.",
    )(fn)


def dry_run(fn: Callable[..., Any]) -> Callable[..., Any]:
    """--dry-run flag for commands with side effects."""
    return click.option(
        "--dry-run",
        is_flag=True,
        default=False,
        help="Show what would happen without making changes.",
    )(fn)


def project_path(fn: Callable[..., Any]) -> Callable[..., Any]:
    """--project-path for commands that operate on a project."""
    return click.option(
        "--project-path",
        type=click.Path(exists=True),
        default=".",
        help="Path to the menda project.",
    )(fn)
