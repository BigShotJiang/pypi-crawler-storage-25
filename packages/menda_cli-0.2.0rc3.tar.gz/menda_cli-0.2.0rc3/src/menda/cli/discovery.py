"""CLI package discovery via Python entry points.

This discovery system is exclusively for CLI command registration.
It is separate from menda-core's adapter/connector/translator plugins.
"""

from __future__ import annotations

from dataclasses import dataclass
from importlib.metadata import entry_points, version
from typing import Literal

import click
import structlog

logger = structlog.get_logger()

_discovered_packages: list[PackageInfo] = []


@dataclass
class PackageInfo:
    """Metadata for a discovered package."""

    name: str
    status: Literal["loaded", "failed"]
    version: str | None = None
    error: str | None = None


def discover_packages(cli: click.Group) -> list[PackageInfo]:
    """Discover and load all menda CLI packages.

    Called in safe_main() before cli() is invoked, so that package commands
    are registered before Click routes to subcommands.

    Note: structlog uses its default config at this point. The user's
    --log-level choice is not yet applied.
    """
    global _discovered_packages
    loaded: list[PackageInfo] = []
    for ep in entry_points(group="menda.packages"):
        try:
            register_fn = ep.load()
            register_fn(cli)
            pkg_version = version(ep.dist.name) if ep.dist else None
            loaded.append(PackageInfo(name=ep.name, status="loaded", version=pkg_version))
        except Exception as e:
            logger.warning("package_load_failed", package=ep.name, error=str(e))
            loaded.append(PackageInfo(name=ep.name, status="failed", error=str(e)))
    _discovered_packages = loaded
    return loaded


def get_discovered_packages() -> list[PackageInfo]:
    """Access package metadata from built-in commands (packages list, version)."""
    return _discovered_packages
