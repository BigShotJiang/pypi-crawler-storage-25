"""Token caching and loading."""

import configparser
import json
import os
import time

from menda.auth import models
from menda.auth.env import MENDA_CONFIG_FOLDER
from menda.auth.exceptions import TokenNotFoundError

TOKENS_CACHE_PATH = f"{MENDA_CONFIG_FOLDER}/tokens/cache/.token"


def is_token_expired(token_data: models.CredentialsModel) -> bool:
    """Check if token has expired (with 60s buffer)."""
    if token_data.cached_at is None:
        return True
    elapsed_time = time.time() - token_data.cached_at
    return elapsed_time >= (token_data.expires_in - 60)


def cache_token(credentials: models.CredentialsModel, profile_id: str) -> None:
    """Cache token to disk."""
    cache_dir = os.path.dirname(TOKENS_CACHE_PATH)
    os.makedirs(cache_dir, exist_ok=True)

    parser = configparser.ConfigParser()
    if os.path.exists(TOKENS_CACHE_PATH):
        parser.read(TOKENS_CACHE_PATH)

    if credentials.cached_at is None:
        credentials.cached_at = time.time()

    parser[profile_id] = {}
    data = credentials.model_dump()
    for k, v in data.items():
        if isinstance(v, (dict, list)):
            parser[profile_id][k] = json.dumps(v)
        elif v is not None:
            parser[profile_id][k] = str(v)
        else:
            parser[profile_id][k] = ""

    with open(TOKENS_CACHE_PATH, "w") as f:
        parser.write(f)


def load_token(profile_id: str) -> models.CredentialsModel:
    """Load token from cache."""
    if not os.path.exists(TOKENS_CACHE_PATH):
        raise TokenNotFoundError(profile_id)

    parser = configparser.ConfigParser()
    parser.read(TOKENS_CACHE_PATH)
    if profile_id not in parser:
        raise TokenNotFoundError(profile_id)
    return models.CredentialsModel.model_validate(parser[profile_id])
