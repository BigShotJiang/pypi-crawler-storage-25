"""Auth-related environment settings."""

from pathlib import Path

from pydantic_settings import BaseSettings

MENDA_CONFIG_FOLDER = str(Path.home() / ".menda")


class AuthEnvSettings(BaseSettings):
    """Environment settings for authentication."""

    MENDA_CONFIG_FILE: str = str(Path(MENDA_CONFIG_FOLDER) / "mendacfg")
    MENDA_PROFILE_ID: str = "default"
    MENDA_CLIENT_ID: str = ""
    MENDA_CLIENT_SECRET: str = ""
    MENDA_HOST: str = ""


def get_auth_env() -> AuthEnvSettings:
    """Get auth environment settings."""
    return AuthEnvSettings()
