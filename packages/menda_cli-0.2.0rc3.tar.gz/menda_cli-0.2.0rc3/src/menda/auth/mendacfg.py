"""Config file management for ~/.menda/mendacfg."""

import configparser
import os

import pydantic
import structlog

from menda.auth import inquirer, models

logger = structlog.get_logger()


class MendaConfigManagementService:
    """Service to manage mendacfg file."""

    def __init__(self, mendacfg_path: str) -> None:
        self.parser = configparser.ConfigParser()
        self.mendacfg_path = mendacfg_path

    @property
    def existing_profiles(self) -> list[str]:
        """Return list of existing profiles."""
        if os.path.isfile(self.mendacfg_path):
            self.parser.read(self.mendacfg_path)
            return self.parser.sections()
        return []

    def create_empty_mendacfg_file(self) -> None:
        """Create an empty mendacfg file."""
        with open(self.mendacfg_path, "w") as file:
            self.parser.write(file)
        logger.debug("Created mendacfg file", location=self.mendacfg_path)

    def add_profile(self, profile_id: str, profile_data: dict) -> None:
        """Add a profile to the mendacfg file."""
        if self.check_if_profile_exists(profile_id):
            msg = f"Profile '{profile_id}' already exists"
            raise ValueError(msg)
        self.parser[profile_id] = profile_data
        with open(self.mendacfg_path, "w") as file:
            self.parser.write(file)
        logger.debug("Added profile to mendacfg file", profile_id=profile_id)

    def overwrite_profile(self, profile_id: str, profile_data: dict) -> None:
        """Overwrite a profile in the mendacfg file."""
        self.parser.remove_section(profile_id)
        self.parser[profile_id] = profile_data
        with open(self.mendacfg_path, "w") as file:
            self.parser.write(file)

    def check_if_profile_exists(self, profile_id: str) -> bool:
        """Check if a profile exists."""
        return profile_id in self.existing_profiles

    def read_profile(self, profile_id: str) -> models.MendaCloudProfileModel:
        """Read and validate profile configuration."""
        from menda.auth.exceptions import ConfigFileNotFoundError, ProfileInvalidError, ProfileNotFoundError

        if not os.path.exists(self.mendacfg_path):
            raise ConfigFileNotFoundError(self.mendacfg_path)

        self.parser.read(self.mendacfg_path)

        if profile_id not in self.parser:
            raise ProfileNotFoundError(profile_id, self.existing_profiles)

        try:
            profile = self.parser[profile_id]
            return models.MendaCloudProfileModel.model_validate(dict(profile))
        except pydantic.ValidationError as e:
            raise ProfileInvalidError(profile_id, str(e)) from e

    def construct_profile_data(self) -> dict[str, str]:
        """Prompt user for profile data and return it."""
        auth_type = inquirer.prompt_for_auth_type()
        host = inquirer.prompt_for_host()

        if auth_type == "m2m":
            client_id = inquirer.prompt_for_client_id()
            client_secret = inquirer.prompt_for_client_secret()
            return {"auth_type": auth_type, "host": host, "client_id": client_id, "client_secret": client_secret}

        return {"auth_type": auth_type, "host": host}
