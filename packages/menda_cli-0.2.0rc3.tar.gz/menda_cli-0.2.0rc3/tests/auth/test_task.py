"""Tests for auth task functions: resolve_auth_config, load_profile_with_validation, load_token_with_validation."""

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from menda.auth.exceptions import (
    ConfigFileNotFoundError,
    ProfileInvalidError,
    ProfileNotFoundError,
    TokenExpiredError,
    TokenNotFoundError,
)
from menda.auth.models import MendaCloudProfileModel
from menda.auth.task import AuthConfig, load_profile_with_validation, load_token_with_validation, resolve_auth_config

# --- resolve_auth_config ---


def test_resolve_env_vars_produce_environment_source() -> None:
    """When all three M2M env vars are set, source is 'environment'."""
    with patch.dict(
        os.environ,
        {
            "MENDA_CLIENT_ID": "env-client-id",
            "MENDA_CLIENT_SECRET": "env-client-secret",
            "MENDA_HOST": "https://api.env.menda.ai",
        },
    ):
        config = resolve_auth_config("ignored-profile")
        assert isinstance(config, AuthConfig)
        assert config.source == "environment"
        assert config.profile_id is None
        assert isinstance(config.profile, MendaCloudProfileModel)
        assert config.profile.auth_type == "m2m"
        assert config.profile.client_id == "env-client-id"
        assert config.profile.client_secret == "env-client-secret"  # noqa: S105
        assert config.profile.host == "https://api.env.menda.ai"


def test_resolve_no_env_vars_falls_to_profile(tmp_path: Path) -> None:
    """When no M2M env vars are set, reads from mendacfg."""
    mendacfg = tmp_path / "mendacfg"
    mendacfg.write_text("[test-profile]\nhost = https://file.menda.ai\nauth_type = u2m\n")
    with patch.dict(
        os.environ,
        {"MENDA_CONFIG_FILE": str(mendacfg)},
        clear=False,
    ):
        os.environ.pop("MENDA_CLIENT_ID", None)
        os.environ.pop("MENDA_CLIENT_SECRET", None)
        os.environ.pop("MENDA_HOST", None)
        config = resolve_auth_config("test-profile")
        assert config.source == "profile"
        assert config.profile_id == "test-profile"
        assert config.profile.host == "https://file.menda.ai"
        assert config.profile.auth_type == "u2m"


def test_resolve_partial_env_vars_falls_to_profile(tmp_path: Path) -> None:
    """When only some M2M env vars are set, falls back to profile."""
    mendacfg = tmp_path / "mendacfg"
    mendacfg.write_text("[test-profile]\nhost = https://file.menda.ai\nauth_type = u2m\n")
    with patch.dict(
        os.environ,
        {
            "MENDA_CLIENT_ID": "env-client-id",
            "MENDA_CONFIG_FILE": str(mendacfg),
        },
        clear=False,
    ):
        os.environ.pop("MENDA_CLIENT_SECRET", None)
        os.environ.pop("MENDA_HOST", None)
        config = resolve_auth_config("test-profile")
        assert config.source == "profile"
        assert config.profile_id == "test-profile"


def test_resolve_env_vars_ignore_profile_id() -> None:
    """Profile ID is None when env vars are used, regardless of what was passed."""
    with patch.dict(
        os.environ,
        {
            "MENDA_CLIENT_ID": "id",
            "MENDA_CLIENT_SECRET": "secret",
            "MENDA_HOST": "https://host.com",
        },
    ):
        config = resolve_auth_config("any-profile-name")
        assert config.profile_id is None
        assert config.source == "environment"


# --- load_profile_with_validation ---


@patch("menda.auth.env.get_auth_env")
@patch("menda.auth.mendacfg.MendaConfigManagementService")
def test_load_profile_success(mock_svc_class: MagicMock, mock_get_env: MagicMock) -> None:
    """Test successfully loading a valid profile."""
    mock_env = MagicMock()
    mock_env.MENDA_CONFIG_FILE = "/path/to/config"
    mock_get_env.return_value = mock_env

    mock_svc = MagicMock()
    mock_profile = MendaCloudProfileModel(host="https://cloud.menda.ai", auth_type="u2m")
    mock_svc.read_profile.return_value = mock_profile
    mock_svc_class.return_value = mock_svc

    result = load_profile_with_validation("dev")
    assert result == mock_profile
    mock_svc.read_profile.assert_called_once_with(profile_id="dev")


@patch("menda.auth.env.get_auth_env")
@patch("menda.auth.mendacfg.MendaConfigManagementService")
def test_load_profile_raises_config_not_found(mock_svc_class: MagicMock, mock_get_env: MagicMock) -> None:
    """Test load_profile_with_validation propagates ConfigFileNotFoundError."""
    mock_env = MagicMock()
    mock_env.MENDA_CONFIG_FILE = "/path/to/config"
    mock_get_env.return_value = mock_env

    mock_svc = MagicMock()
    mock_svc.read_profile.side_effect = ConfigFileNotFoundError("/path/to/config")
    mock_svc_class.return_value = mock_svc

    with pytest.raises(ConfigFileNotFoundError) as exc_info:
        load_profile_with_validation("dev")
    assert exc_info.value.config_path == "/path/to/config"


@patch("menda.auth.env.get_auth_env")
@patch("menda.auth.mendacfg.MendaConfigManagementService")
def test_load_profile_raises_profile_not_found(mock_svc_class: MagicMock, mock_get_env: MagicMock) -> None:
    """Test load_profile_with_validation propagates ProfileNotFoundError."""
    mock_env = MagicMock()
    mock_env.MENDA_CONFIG_FILE = "/path/to/config"
    mock_get_env.return_value = mock_env

    mock_svc = MagicMock()
    mock_svc.read_profile.side_effect = ProfileNotFoundError("dev", ["prod", "staging"])
    mock_svc_class.return_value = mock_svc

    with pytest.raises(ProfileNotFoundError) as exc_info:
        load_profile_with_validation("dev")
    assert exc_info.value.profile_id == "dev"
    assert exc_info.value.available_profiles == ["prod", "staging"]


@patch("menda.auth.env.get_auth_env")
@patch("menda.auth.mendacfg.MendaConfigManagementService")
def test_load_profile_raises_profile_invalid(mock_svc_class: MagicMock, mock_get_env: MagicMock) -> None:
    """Test load_profile_with_validation propagates ProfileInvalidError."""
    mock_env = MagicMock()
    mock_env.MENDA_CONFIG_FILE = "/path/to/config"
    mock_get_env.return_value = mock_env

    mock_svc = MagicMock()
    mock_svc.read_profile.side_effect = ProfileInvalidError("dev", "Missing host field")
    mock_svc_class.return_value = mock_svc

    with pytest.raises(ProfileInvalidError) as exc_info:
        load_profile_with_validation("dev")
    assert exc_info.value.profile_id == "dev"
    assert "Missing host field" in exc_info.value.validation_error


# --- load_token_with_validation ---


@patch("menda.auth.oauth2.token.is_token_expired", return_value=False)
@patch("menda.auth.oauth2.token.load_token")
def test_load_token_success(mock_load: MagicMock, mock_expired: MagicMock) -> None:
    """Test successfully loading a valid token."""
    from menda.auth.models import CredentialsModel

    mock_creds = CredentialsModel(access_token="access123", expires_in=3600, token_type="Bearer")  # noqa: S106
    mock_load.return_value = mock_creds

    result = load_token_with_validation("dev")
    assert result == mock_creds
    mock_load.assert_called_once_with(profile_id="dev")
    mock_expired.assert_called_once_with(mock_creds)


@patch("menda.auth.oauth2.token.load_token")
def test_load_token_raises_not_found(mock_load: MagicMock) -> None:
    """Test load_token_with_validation propagates TokenNotFoundError."""
    mock_load.side_effect = TokenNotFoundError("dev")

    with pytest.raises(TokenNotFoundError) as exc_info:
        load_token_with_validation("dev")
    assert exc_info.value.profile_id == "dev"


@patch("menda.auth.oauth2.token.is_token_expired", return_value=True)
@patch("menda.auth.oauth2.token.load_token")
def test_load_token_raises_expired(mock_load: MagicMock, mock_expired: MagicMock) -> None:
    """Test load_token_with_validation raises TokenExpiredError for expired token."""
    from menda.auth.models import CredentialsModel

    mock_creds = CredentialsModel(access_token="access123", expires_in=3600, token_type="Bearer")  # noqa: S106
    mock_load.return_value = mock_creds

    with pytest.raises(TokenExpiredError) as exc_info:
        load_token_with_validation("dev")
    assert exc_info.value.profile_id == "dev"
