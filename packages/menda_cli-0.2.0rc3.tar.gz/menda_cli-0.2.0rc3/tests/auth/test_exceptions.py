"""Tests for auth exceptions."""

from menda.auth.exceptions import (
    AuthenticationError,
    ConfigFileNotFoundError,
    DeviceCodeExpiredError,
    ProfileInvalidError,
    ProfileNotFoundError,
    TokenExpiredError,
    TokenNotFoundError,
)
from menda.cli.exceptions import AuthError, ErrorCategory


def test_all_auth_exceptions_inherit_from_auth_error() -> None:
    """Test all auth exceptions inherit from AuthError with correct category and exit code."""
    classes = [
        ConfigFileNotFoundError("/path"),
        ProfileNotFoundError("dev"),
        ProfileInvalidError("dev", "bad field"),
        TokenNotFoundError("dev"),
        TokenExpiredError("dev"),
        DeviceCodeExpiredError(),
        AuthenticationError(detail="failed"),
    ]
    for exc in classes:
        assert isinstance(exc, AuthError)
        assert exc.category == ErrorCategory.AUTH
        assert exc.exit_code == 2


def test_config_file_not_found_has_suggestion() -> None:
    """Test ConfigFileNotFoundError includes suggestion to configure."""
    err = ConfigFileNotFoundError("/home/.menda/mendacfg")
    suggestion = err.suggestion
    assert suggestion is not None
    assert "menda auth configure" in suggestion


def test_profile_not_found_lists_available() -> None:
    """Test ProfileNotFoundError lists available profiles in suggestion."""
    err = ProfileNotFoundError("missing", available_profiles=["dev", "prod"])
    suggestion = err.suggestion
    assert suggestion is not None
    assert "dev" in suggestion
    assert "prod" in suggestion


def test_format_for_display() -> None:
    """Test format_for_display includes category and message."""
    err = TokenExpiredError("dev")
    display = err.format_for_display()
    assert "[auth]" in display
    assert "expired" in display.lower()


# --- Detailed per-exception tests ---


def test_config_file_not_found_attributes() -> None:
    """Test ConfigFileNotFoundError stores config_path and sets context."""
    err = ConfigFileNotFoundError("/path/to/config")
    assert err.config_path == "/path/to/config"
    assert "Configuration file not found: /path/to/config" in err.message
    assert err.context == "auth:config"
    assert err.suggestion is not None
    assert "menda auth configure" in err.suggestion


def test_profile_not_found_without_available() -> None:
    """Test ProfileNotFoundError defaults to empty available_profiles."""
    err = ProfileNotFoundError("dev")
    assert err.profile_id == "dev"
    assert err.available_profiles == []
    assert "Profile 'dev' not found" in err.message
    assert err.context == "auth:profile:dev"


def test_profile_not_found_with_available() -> None:
    """Test ProfileNotFoundError lists available profiles in suggestion."""
    err = ProfileNotFoundError("dev", ["prod", "staging"])
    assert err.available_profiles == ["prod", "staging"]
    assert err.suggestion is not None
    assert "prod, staging" in err.suggestion


def test_profile_invalid_attributes() -> None:
    """Test ProfileInvalidError stores profile_id and validation_error."""
    err = ProfileInvalidError("dev", "Field 'host' is required")
    assert err.profile_id == "dev"
    assert err.validation_error == "Field 'host' is required"
    assert "invalid configuration" in err.message
    assert "Field 'host' is required" in err.message
    assert err.context == "auth:profile:dev"
    assert err.suggestion is not None
    assert "menda auth configure" in err.suggestion


def test_token_not_found_attributes() -> None:
    """Test TokenNotFoundError stores profile_id and sets suggestion."""
    err = TokenNotFoundError("dev")
    assert err.profile_id == "dev"
    assert "No authentication token found for profile 'dev'" in err.message
    assert err.context == "auth:token:dev"
    assert err.suggestion is not None
    assert "menda auth login --menda-profile-id dev" in err.suggestion


def test_token_expired_attributes() -> None:
    """Test TokenExpiredError stores profile_id and sets suggestion."""
    err = TokenExpiredError("dev")
    assert err.profile_id == "dev"
    assert "token expired" in err.message.lower()
    assert err.context == "auth:token:dev"
    assert err.suggestion is not None
    assert "menda auth login --menda-profile-id dev" in err.suggestion


def test_device_code_expired_default_message() -> None:
    """Test DeviceCodeExpiredError uses default message."""
    err = DeviceCodeExpiredError()
    assert err.message == "Device code has expired"
    assert err.context == "auth:device_flow"
    assert err.suggestion is not None
    assert "menda auth login" in err.suggestion


def test_device_code_expired_custom_message() -> None:
    """Test DeviceCodeExpiredError accepts custom message."""
    err = DeviceCodeExpiredError("Custom expiration message")
    assert err.message == "Custom expiration message"


def test_authentication_error_without_code() -> None:
    """Test AuthenticationError without error code."""
    err = AuthenticationError(detail="Connection failed")
    assert err.detail == "Connection failed"
    assert err.code is None
    assert err.context == "auth:cloud"


def test_authentication_error_with_code() -> None:
    """Test AuthenticationError with error code sets context."""
    err = AuthenticationError(detail="Authorization denied", code="401")
    assert err.code == "401"
    assert err.context == "auth:cloud:401"


def test_authentication_error_device_code_suggestion() -> None:
    """Test AuthenticationError auto-suggests for device code errors."""
    err = AuthenticationError(detail="Device code has expired")
    assert err.suggestion is not None
    assert "menda auth login" in err.suggestion


def test_authentication_error_network_suggestion() -> None:
    """Test AuthenticationError auto-suggests for network errors."""
    err = AuthenticationError(detail="Network connection timeout")
    assert err.suggestion is not None
    assert "network" in err.suggestion.lower()


def test_authentication_error_no_suggestion_for_generic() -> None:
    """Test AuthenticationError has no suggestion for generic errors."""
    err = AuthenticationError(detail="Invalid credentials")
    assert err.suggestion is None
