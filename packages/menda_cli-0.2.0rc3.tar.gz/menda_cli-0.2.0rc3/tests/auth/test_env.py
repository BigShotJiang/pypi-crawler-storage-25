"""Tests for AuthEnvSettings environment configuration."""

import os
from unittest.mock import patch

from menda.auth.env import AuthEnvSettings


def test_defaults() -> None:
    """Test AuthEnvSettings uses defaults when no env vars are set."""
    with patch.dict(os.environ, {}, clear=True):
        settings = AuthEnvSettings()
        assert settings.MENDA_CLIENT_ID == ""
        assert settings.MENDA_CLIENT_SECRET == ""
        assert settings.MENDA_HOST == ""
        assert settings.MENDA_PROFILE_ID == "default"
        assert "mendacfg" in settings.MENDA_CONFIG_FILE


def test_m2m_fields_from_environment() -> None:
    """Test M2M fields are populated from environment variables."""
    with patch.dict(
        os.environ,
        {
            "MENDA_CLIENT_ID": "client-id-123",
            "MENDA_CLIENT_SECRET": "secret-456",
            "MENDA_HOST": "https://example.menda.ai",
        },
        clear=True,
    ):
        settings = AuthEnvSettings()
        assert settings.MENDA_CLIENT_ID == "client-id-123"
        assert settings.MENDA_CLIENT_SECRET == "secret-456"  # noqa: S105
        assert settings.MENDA_HOST == "https://example.menda.ai"


def test_partial_m2m_environment() -> None:
    """Test only set M2M env vars are applied; unset ones remain default."""
    with patch.dict(
        os.environ,
        {"MENDA_CLIENT_ID": "only-client-id"},
        clear=True,
    ):
        settings = AuthEnvSettings()
        assert settings.MENDA_CLIENT_ID == "only-client-id"
        assert settings.MENDA_CLIENT_SECRET == ""
        assert settings.MENDA_HOST == ""
