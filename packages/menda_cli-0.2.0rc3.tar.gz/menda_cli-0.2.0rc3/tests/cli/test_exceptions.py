from menda.cli.exceptions import (
    AuthError,
    ConfigError,
    ErrorCategory,
    MendaCLIError,
    NetworkError,
    PluginError,
    ValidationError,
)


def test_menda_cli_error_defaults():
    """Test MendaCLIError defaults to UNKNOWN category and exit code 1."""
    err = MendaCLIError("something broke")
    assert err.message == "something broke"
    assert err.context is None
    assert err.suggestion is None
    assert err.category == ErrorCategory.UNKNOWN
    assert err.exit_code == 1
    assert str(err) == "something broke"


def test_menda_cli_error_with_all_fields():
    """Test MendaCLIError stores all fields correctly."""
    err = MendaCLIError(
        message="bad config",
        context="config:profile:dev",
        suggestion="Run menda auth configure",
        category=ErrorCategory.CONFIG,
        exit_code=3,
    )
    assert err.message == "bad config"
    assert err.context == "config:profile:dev"
    assert err.suggestion == "Run menda auth configure"
    assert err.category == ErrorCategory.CONFIG
    assert err.exit_code == 3


def test_format_for_display_with_all_fields():
    """Test format_for_display includes category, message, and suggestion."""
    err = MendaCLIError(
        message="token expired",
        context="auth:token:dev",
        suggestion="Run menda auth login",
        category=ErrorCategory.AUTH,
        exit_code=2,
    )
    display = err.format_for_display()
    assert "[auth]" in display
    assert "token expired" in display
    assert "Run menda auth login" in display


def test_format_for_display_minimal():
    """Test format_for_display works with only a message."""
    err = MendaCLIError("simple error")
    display = err.format_for_display()
    assert "simple error" in display


def test_to_dict():
    """Test to_dict returns all fields with category as string value."""
    err = MendaCLIError(
        message="fail",
        context="test",
        suggestion="fix it",
        category=ErrorCategory.VALIDATION,
        exit_code=5,
    )
    d = err.to_dict()
    assert d["message"] == "fail"
    assert d["context"] == "test"
    assert d["suggestion"] == "fix it"
    assert d["category"] == "validation"
    assert d["exit_code"] == 5


def test_category_base_classes():
    """Test each category subclass sets the correct exit code and category."""
    assert AuthError("x").exit_code == 2
    assert AuthError("x").category == ErrorCategory.AUTH

    assert ConfigError("x").exit_code == 3
    assert ConfigError("x").category == ErrorCategory.CONFIG

    assert NetworkError("x").exit_code == 4
    assert NetworkError("x").category == ErrorCategory.NETWORK

    assert ValidationError("x").exit_code == 5
    assert ValidationError("x").category == ErrorCategory.VALIDATION

    assert PluginError("x").exit_code == 6
    assert PluginError("x").category == ErrorCategory.PLUGIN


def test_inheritance():
    """Test all category error classes inherit from MendaCLIError."""
    assert issubclass(AuthError, MendaCLIError)
    assert issubclass(ConfigError, MendaCLIError)
    assert issubclass(NetworkError, MendaCLIError)
    assert issubclass(ValidationError, MendaCLIError)
    assert issubclass(PluginError, MendaCLIError)
