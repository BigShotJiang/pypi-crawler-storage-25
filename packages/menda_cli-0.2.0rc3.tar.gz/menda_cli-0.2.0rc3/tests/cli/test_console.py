"""Tests for the Console abstraction module."""

import json

from menda.cli.console import Console, OutputMode


def test_console_default_mode():
    """Test that Console defaults to TEXT output mode."""
    c = Console()
    assert c.output_mode == OutputMode.TEXT


def test_console_json_mode():
    """Test that Console can be set to JSON output mode."""
    c = Console(output=OutputMode.JSON)
    assert c.output_mode == OutputMode.JSON


def test_success_text_mode(capsys):
    """Test that success message is written to stderr in text mode."""
    c = Console(output=OutputMode.TEXT)
    c.success("it worked")
    captured = capsys.readouterr()
    assert "it worked" in captured.err


def test_success_json_mode(capsys):
    """Test that success message is written as JSON to stderr in JSON mode."""
    c = Console(output=OutputMode.JSON)
    c.success("it worked")
    captured = capsys.readouterr()
    data = json.loads(captured.err)
    assert data["status"] == "success"
    assert data["message"] == "it worked"


def test_error_text_mode(capsys):
    """Test that error message is written to stderr in text mode."""
    c = Console(output=OutputMode.TEXT)
    c.error("something broke")
    captured = capsys.readouterr()
    assert "something broke" in captured.err


def test_error_json_mode(capsys):
    """Test that error message is written as JSON to stderr in JSON mode."""
    c = Console(output=OutputMode.JSON)
    c.error("something broke")
    captured = capsys.readouterr()
    data = json.loads(captured.err)
    assert data["status"] == "error"
    assert data["message"] == "something broke"


def test_error_shown_in_quiet_mode(capsys):
    """Test that errors are always shown even in quiet mode."""
    c = Console(output=OutputMode.TEXT, quiet=True)
    c.error("visible")
    captured = capsys.readouterr()
    assert "visible" in captured.err


def test_success_suppressed_in_quiet_mode(capsys):
    """Test that success messages are suppressed in quiet mode."""
    c = Console(output=OutputMode.TEXT, quiet=True)
    c.success("hidden")
    captured = capsys.readouterr()
    assert captured.err == ""


def test_warning_suppressed_in_quiet_mode(capsys):
    """Test that warning messages are suppressed in quiet mode."""
    c = Console(output=OutputMode.TEXT, quiet=True)
    c.warning("hidden")
    captured = capsys.readouterr()
    assert captured.err == ""


def test_info_suppressed_in_json_mode(capsys):
    """Test that info messages are suppressed in JSON mode."""
    c = Console(output=OutputMode.JSON)
    c.info("hidden in json")
    captured = capsys.readouterr()
    assert captured.err == ""


def test_table_text_mode(capsys):
    """Test that table is written to stdout in text mode."""
    c = Console(output=OutputMode.TEXT)
    c.table(headers=["Name", "Age"], rows=[["Alice", "30"], ["Bob", "25"]])
    captured = capsys.readouterr()
    assert "Alice" in captured.out
    assert "Bob" in captured.out


def test_table_json_mode(capsys):
    """Test that table is written as JSON array to stdout in JSON mode."""
    c = Console(output=OutputMode.JSON)
    c.table(headers=["Name", "Age"], rows=[["Alice", "30"], ["Bob", "25"]])
    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert len(data) == 2
    assert data[0] == {"Name": "Alice", "Age": "30"}


def test_json_output_text_mode(capsys):
    """Test that JSON data is pretty-printed to stdout in text mode."""
    c = Console(output=OutputMode.TEXT)
    c.json({"key": "value"})
    captured = capsys.readouterr()
    assert "key" in captured.out
    assert "value" in captured.out


def test_json_output_json_mode(capsys):
    """Test that JSON data is written as raw JSON to stdout in JSON mode."""
    c = Console(output=OutputMode.JSON)
    c.json({"key": "value"})
    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert data == {"key": "value"}


def test_table_suppressed_in_quiet_mode(capsys):
    """Test that table output is suppressed in quiet mode."""
    c = Console(output=OutputMode.TEXT, quiet=True)
    c.table(headers=["H"], rows=[["V"]])
    captured = capsys.readouterr()
    assert captured.out == ""
