"""Tests for IPython/Databricks detection and non-standalone CLI behavior."""

import sys
from unittest.mock import patch

from menda.cli.main import _is_ipython


class TestIsIpython:
    """Tests for _is_ipython()."""

    def test_returns_true_when_ipython_in_sys_modules(self) -> None:
        with patch.dict(sys.modules, {"IPython": object()}):
            assert _is_ipython() is True

    def test_returns_false_when_ipython_not_in_sys_modules(self) -> None:
        with patch.dict(sys.modules, {}, remove=["IPython"]):
            assert _is_ipython() is False
