from collections.abc import Generator
from contextlib import closing
from pathlib import Path
from unittest import mock

import pytest
import structlog
from click.testing import CliRunner

from menda.auth.env import get_auth_env
from menda.cli.main import cli

logger = structlog.get_logger()


class TestConfigureCommand:
    """Test cases for the 'configure' CLI command."""

    @pytest.fixture
    def setup_and_teardown(self, tmpdir: Path) -> Generator[None, None, None]:
        """Set up test environment before each test."""
        self.tmp_path = str(tmpdir / "test_mendacfg")
        auth_env = get_auth_env()
        env = {**auth_env.model_dump(mode="python"), "MENDA_CONFIG_FILE": self.tmp_path}
        self.runner = CliRunner(env=env)
        yield

    @mock.patch("menda.auth.inquirer.prompt_for_profile_name")
    @mock.patch("menda.auth.inquirer.prompt_for_auth_type")
    @mock.patch("menda.auth.inquirer.prompt_for_host")
    def test_configure_new_profile(
        self,
        mock_host: mock.Mock,
        mock_auth_type: mock.Mock,
        mock_profile_name: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """Test creating a new profile when it doesn't exist."""
        # Setup mocks
        mock_profile_name.return_value = "test_profile"
        mock_auth_type.return_value = "u2m"
        mock_host.return_value = "https://test.example.com"

        # Execute CLI command
        result = self.runner.invoke(cli, ["auth", "configure"])
        if result.exit_code != 0:
            logger.error(f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}")
            logger.error(f"Output: {result.output}")

        # Check command execution
        assert result.exit_code == 0, (
            f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}"
        )
        assert "✓ Profile 'test_profile' created successfully" in result.output, f"Output: {result.output}"
        logger.info("Command executed successfully with new profile")

        # Verify file content
        with closing(open(self.tmp_path)) as f:
            content = f.read()
            assert "[test_profile]" in content, f"Content: {content}"
            assert "host = https://test.example.com" in content, f"Content: {content}"
            assert "auth_type = u2m" in content, f"Content: {content}"
        logger.info("File validated with new profile")

    @mock.patch("menda.auth.inquirer.prompt_for_profile_name")
    @mock.patch("menda.auth.inquirer.prompt_for_overwrite_profile")
    @mock.patch("menda.auth.inquirer.prompt_for_auth_type")
    @mock.patch("menda.auth.inquirer.prompt_for_host")
    def test_configure_existing_profile_overwrite(
        self,
        mock_host: mock.Mock,
        mock_auth_type: mock.Mock,
        mock_overwrite: mock.Mock,
        mock_profile_name: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """Test overwriting an existing profile."""
        # Setup mocks
        mock_profile_name.return_value = "test_profile"
        mock_overwrite.return_value = True
        mock_auth_type.return_value = "u2m"
        mock_host.return_value = "https://updated.example.com"

        # Create initial profile
        with closing(open(self.tmp_path, "w")) as f:
            f.write("[test_profile]\nhost = https://initial.example.com\n")

        logger.info("Wrote initial profile to file for overwriting test")

        # Execute CLI command
        result = self.runner.invoke(cli, ["auth", "configure"], catch_exceptions=False)
        if result.exit_code != 0:
            logger.error(f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}")
            logger.error(f"Output: {result.output}")

        # Check command execution
        assert result.exit_code == 0, (
            f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}"
        )
        assert "✓ Profile 'test_profile' updated successfully" in result.output, f"Output: {result.output}"
        logger.info("Command executed successfully with overwritten profile")

        # Verify file content updated
        with closing(open(self.tmp_path)) as f:
            content = f.read()
            assert "[test_profile]" in content, f"Content: {content}"
            assert "host = https://updated.example.com" in content, f"Content: {content}"
            assert "auth_type = u2m" in content, f"Content: {content}"
        logger.info("File validated with overwritten content")

    @mock.patch("menda.auth.inquirer.prompt_for_profile_name")
    @mock.patch("menda.auth.inquirer.prompt_for_overwrite_profile")
    def test_configure_existing_profile_no_overwrite(
        self,
        mock_overwrite: mock.Mock,
        mock_profile_name: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """Test not overwriting an existing profile when user declines."""
        # Setup mocks
        mock_profile_name.return_value = "test_profile"
        mock_overwrite.return_value = False

        # Create initial profile
        with closing(open(self.tmp_path, "w")) as f:
            f.write("[test_profile]\nhost = https://initial.example.com\n")

        logger.info("Wrote initial profile to file for no-overwrite test")

        # Execute CLI command
        result = self.runner.invoke(cli, ["auth", "configure"], catch_exceptions=False)
        if result.exit_code != 0:
            logger.error(f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}")
            logger.error(f"Output: {result.output}")

        # Check command execution
        assert result.exit_code == 0, (
            f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}"
        )
        assert "Configuration cancelled." in result.output, f"Output: {result.output}"
        logger.info("Command executed successfully with no changes")

        # Verify file content remains unchanged
        with closing(open(self.tmp_path)) as f:
            content = f.read()
            assert "[test_profile]" in content, f"Content: {content}"
            assert "host = https://initial.example.com" in content, f"Content: {content}"
        logger.info("File validated with unchanged content")

    @mock.patch("menda.auth.inquirer.prompt_for_profile_name")
    @mock.patch("menda.auth.inquirer.prompt_for_auth_type")
    @mock.patch("menda.auth.inquirer.prompt_for_host")
    def test_configure_add_new_profile_with_existing(
        self,
        mock_host: mock.Mock,
        mock_auth_type: mock.Mock,
        mock_profile_name: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """Test adding a new profile when another profile already exists."""
        # Setup mocks
        mock_profile_name.return_value = "new_profile"
        mock_auth_type.return_value = "u2m"
        mock_host.return_value = "https://new.example.com"

        # Create initial profile with a different name
        with closing(open(self.tmp_path, "w")) as f:
            f.write("[existing_profile]\nhost = https://existing.example.com\n")

        logger.info("Wrote existing profile to file before adding new profile")

        # Execute CLI command
        result = self.runner.invoke(cli, ["auth", "configure"])
        if result.exit_code != 0:
            logger.error(f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}")
            logger.error(f"Output: {result.output}")

        # Check command execution
        assert result.exit_code == 0, (
            f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}"
        )
        assert "✓ Profile 'new_profile' created successfully" in result.output, f"Output: {result.output}"
        logger.info("Command executed successfully with new profile added")

        # Verify file content contains both profiles
        with closing(open(self.tmp_path)) as f:
            content = f.read()
            # Check existing profile is still there
            assert "[existing_profile]" in content, f"Content: {content}"
            assert "host = https://existing.example.com" in content, f"Content: {content}"
            # Check new profile was added
            assert "[new_profile]" in content, f"Content: {content}"
            assert "host = https://new.example.com" in content, f"Content: {content}"
        logger.info("File validated with both existing and new profiles")

    @mock.patch("menda.auth.inquirer.prompt_for_profile_name")
    @mock.patch("menda.auth.inquirer.prompt_for_auth_type")
    @mock.patch("menda.auth.inquirer.prompt_for_host")
    @mock.patch("menda.auth.inquirer.prompt_for_client_id")
    @mock.patch("menda.auth.inquirer.prompt_for_client_secret")
    def test_configure_new_profile_m2m(
        self,
        mock_client_secret: mock.Mock,
        mock_client_id: mock.Mock,
        mock_host: mock.Mock,
        mock_auth_type: mock.Mock,
        mock_profile_name: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """Test creating a new m2m profile when it doesn't exist."""
        mock_profile_name.return_value = "test_profile_m2m"
        mock_auth_type.return_value = "m2m"
        mock_host.return_value = "https://test.example.com"
        mock_client_id.return_value = "client-id-123"
        mock_client_secret.return_value = "client-secret-xyz"

        result = self.runner.invoke(cli, ["auth", "configure"])
        assert result.exit_code == 0, f"Output: {result.output}"
        assert "✓ Profile 'test_profile_m2m' created successfully" in result.output, f"Output: {result.output}"

        with closing(open(self.tmp_path)) as f:
            content = f.read()
            assert "[test_profile_m2m]" in content, f"Content: {content}"
            assert "host = https://test.example.com" in content, f"Content: {content}"
            assert "auth_type = m2m" in content, f"Content: {content}"
            assert "client_id = client-id-123" in content, f"Content: {content}"
            assert "client_secret = client-secret-xyz" in content, f"Content: {content}"
