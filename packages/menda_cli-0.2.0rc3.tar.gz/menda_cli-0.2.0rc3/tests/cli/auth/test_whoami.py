import os
from collections.abc import Generator
from contextlib import closing
from pathlib import Path
from unittest import mock

import pytest
import structlog
from click.testing import CliRunner

from menda.auth import models
from menda.auth.exceptions import ProfileNotFoundError, TokenNotFoundError
from menda.auth.oauth2 import token
from menda.cli.main import cli

logger = structlog.get_logger(__name__)


class TestWhoamiCommand:
    """Test cases for the 'whoami' CLI command."""

    @pytest.fixture
    def setup_and_teardown(self, tmpdir: Path) -> Generator[None, None, None]:
        """Set up test environment before each test."""
        self.runner = CliRunner()
        self.tmp_path = str(tmpdir / "test_mendacfg")
        self.token_cache_path = str(tmpdir / "tokens" / "cache" / ".token")

        # Create test config file with a profile
        with closing(open(self.tmp_path, "w")) as f:
            f.write("[test_profile]\nhost = https://test.example.com\nauth_type = u2m\n")

        # Create token cache directory
        os.makedirs(os.path.dirname(self.token_cache_path), exist_ok=True)

        # Create patch for environment variables — clear M2M vars to prevent env leakage
        self.env_patcher = mock.patch.dict(
            "os.environ",
            {
                "MENDA_CONFIG_FILE": self.tmp_path,
                "MENDA_PROFILE_ID": "test_profile",
                "MENDA_CLIENT_ID": "",
                "MENDA_CLIENT_SECRET": "",
                "MENDA_HOST": "",
            },
        )
        self.token_path_patcher = mock.patch("menda.auth.oauth2.token.TOKENS_CACHE_PATH", self.token_cache_path)

        self.env_mock = self.env_patcher.start()
        self.token_path_mock = self.token_path_patcher.start()

        yield

        self.token_path_patcher.stop()
        self.env_patcher.stop()

    @mock.patch("menda.auth.api.AuthRoutes.whoami")
    @mock.patch("menda.auth.http.requests_session")
    def test_whoami_success(
        self,
        mock_session: mock.Mock,
        mock_whoami: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """Test successful whoami flow."""
        # Create test credentials and cache them
        credentials = models.CredentialsModel(
            access_token="test_access_token",  # noqa: S106
            id_token="test_id_token",  # noqa: S106
            refresh_token="test_refresh_token",  # noqa: S106
            token_type="Bearer",  # noqa: S106
            expires_in=3600,
        )
        token.cache_token(credentials=credentials, profile_id="test_profile")
        logger.info("Cached test token for profile")

        # Setup mocks
        mock_session_instance = mock.MagicMock()
        mock_session.return_value = mock_session_instance

        # Mock API response
        mock_response = mock.MagicMock()
        user_data = {
            "tenant_id": "tenant-abc",
            "user_role": "admin",
            "username": "test-user",
            "email": "user@example.com",
            "identity_type": "user",
        }
        mock_response.status_code = 200
        mock_response.json.return_value = user_data
        mock_whoami.return_value = mock_response

        logger.info("Starting whoami success test")

        # Execute CLI command
        result = self.runner.invoke(cli, ["auth", "whoami", "--menda-profile-id", "test_profile"])
        if result.exit_code != 0:
            logger.error(f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}")
            logger.error(f"Output: {result.output}")

        # Check command execution
        assert result.exit_code == 0, (
            f"Command failed with: {result.exception if hasattr(result, 'exception') else 'unknown'}"
        )
        assert "User Details:" in result.output, f"Output: {result.output}"
        assert "tenant-abc" in result.output, f"Output: {result.output}"
        assert "test-user" in result.output, f"Output: {result.output}"
        logger.info("Command executed successfully")

        # Verify API was called with correct token
        mock_whoami.assert_called_once_with(session=mock_session_instance, token="test_id_token")  # noqa: S106
        logger.info("All mocks verified successfully")

    def test_whoami_token_error(
        self,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """Test whoami with token loading error."""
        # Don't create a token - this will cause load_token to fail naturally
        logger.info("Starting whoami token error test (no token cached)")

        # Execute CLI command
        result = self.runner.invoke(cli, ["auth", "whoami", "--menda-profile-id", "test_profile"])

        assert result.exit_code == 1, f"Output: {result.output}"
        assert isinstance(result.exception, TokenNotFoundError)
        assert "test_profile" in str(result.exception)
        logger.info("Command correctly handled token error")

    @mock.patch("menda.auth.api.AuthRoutes.whoami")
    @mock.patch("menda.auth.http.requests_session")
    def test_whoami_api_error(
        self,
        mock_session: mock.Mock,
        mock_whoami: mock.Mock,
        setup_and_teardown: pytest.FixtureRequest,
    ) -> None:
        """Test whoami with API error."""
        # Create test credentials and cache them
        credentials = models.CredentialsModel(
            access_token="test_access_token",  # noqa: S106
            id_token="test_id_token",  # noqa: S106
            refresh_token="test_refresh_token",  # noqa: S106
            token_type="Bearer",  # noqa: S106
            expires_in=3600,
        )
        token.cache_token(credentials=credentials, profile_id="test_profile")
        logger.info("Cached test token for profile")

        # Setup mocks
        mock_session_instance = mock.MagicMock()
        mock_session.return_value = mock_session_instance

        # Mock API error
        mock_whoami.side_effect = Exception("API connection error")

        logger.info("Starting whoami API error test")

        # Execute CLI command
        result = self.runner.invoke(cli, ["auth", "whoami", "--menda-profile-id", "test_profile"])

        assert result.exit_code == 1, f"Output: {result.output}"
        assert result.exception is not None
        assert "API connection error" in str(result.exception)
        logger.info("Command correctly handled API error")

    def test_whoami_invalid_profile(self, setup_and_teardown: pytest.FixtureRequest) -> None:
        """Test whoami with a non-existent profile."""
        logger.info("Starting whoami with invalid profile test")

        # Execute CLI command with invalid profile
        result = self.runner.invoke(cli, ["auth", "whoami", "--menda-profile-id", "non_existent_profile"])

        assert result.exit_code == 1, f"Output: {result.output}"
        assert isinstance(result.exception, ProfileNotFoundError)
        assert "non_existent_profile" in str(result.exception)
        logger.info("Command correctly rejected invalid profile")
