from setuptools import setup

setup(
    name='cullis-sdk',
    version='0.1.0',
    description='Python SDK for Cullis — federated agent-trust network. E2E-encrypted agent↔agent messaging, x509 mutual auth, DPoP-bound tokens.',
    long_description='# `cullis-sdk`\n\n**Python SDK for the Cullis federated agent-trust network.**\n\nThe Cullis SDK is the library you import from your Python agent code to\ntalk to a Cullis broker. It handles enrollment, mutual TLS / DPoP-bound\nauthentication, agent discovery, session management, and end-to-end\nencrypted messaging — so your agent code stays focused on what it does,\nnot on the wire format.\n\nThe SDK is one of three Python distributions in the Cullis monorepo:\n\n| Distribution      | Purpose                                                          |\n|-------------------|------------------------------------------------------------------|\n| `cullis-sdk`      | Library you `import cullis_sdk` from your agent code (this one). |\n| `cullis-connector`| End-user MCP server bridging Claude Code / Cursor / etc.         |\n| `mcp-proxy`       | Org-level gateway (deployed as a container, not pip-installed).  |\n\n---\n\n## Install\n\n```bash\npip install cullis-sdk\n```\n\nPython 3.10+ required.\n\nFor [SPIFFE](https://spiffe.io/) workload-API integration (enroll an\nagent using its SPIRE-issued SVID), install the optional extra:\n\n```bash\npip install \'cullis-sdk[spiffe]\'\n```\n\n---\n\n## Quick start\n\n```python\nfrom cullis_sdk import CullisClient\n\nwith CullisClient("https://broker.example.com") as client:\n    client.login(\n        agent_id="myorg::reporter",\n        org_id="myorg",\n        cert_path="reporter.crt",\n        key_path="reporter.key",\n    )\n\n    agents = client.discover(capabilities=["order.write"])\n    target = agents[0]\n\n    session = client.open_session(\n        target.agent_id, target.org_id, ["order.write"],\n    )\n    client.send(\n        session_id=session,\n        from_agent="myorg::reporter",\n        payload={"text": "Place order #42"},\n        to_agent=target.agent_id,\n    )\n```\n\nThe SDK does the heavy lifting: x509 mutual TLS to the broker,\nDPoP-bound bearer tokens for replay protection, ECDH key agreement\nfor end-to-end encryption to the recipient agent, and (on receive)\nhash-chain verification of the per-org audit log.\n\n---\n\n## Architecture\n\n```\n       ┌──────────┐  mTLS + DPoP   ┌──────────┐  mTLS + DPoP  ┌──────────┐\n       │ Agent A  │───────────────▶│  Broker  │◀──────────────│ Agent B  │\n       │ (cullis- │                │ (Cullis  │               │ (cullis- │\n       │   sdk)   │                │  Site)   │               │   sdk)   │\n       └──────────┘                └──────────┘               └──────────┘\n            │                                                       ▲\n            └─── E2E-encrypted payload (ECDH, broker can\'t read) ───┘\n```\n\nThe broker authenticates both endpoints, routes messages, and\nappends a tamper-evident hash-chain entry per send. It never sees\nthe cleartext payload.\n\n---\n\n## Documentation\n\n- Repository: https://github.com/cullis-security/cullis\n- Site: https://cullis.io\n- Issues: https://github.com/cullis-security/cullis/issues\n- Quickstart: https://cullis.io/docs/quickstart/getting-started/\n\n---\n\n## License\n\nFunctional Source License 1.1 with Apache-2.0 future grant\n([`LICENSE`](https://github.com/cullis-security/cullis/blob/main/LICENSE)).\nYou can use, modify, and self-host the SDK for any non-competing\npurpose; competing-use restriction lifts after two years to Apache 2.0.\n',
    author_email='Cullis Security <hello@cullis.io>',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Intended Audience :: System Administrators',
        'License :: Other/Proprietary License',
        'Operating System :: MacOS',
        'Operating System :: Microsoft :: Windows',
        'Operating System :: POSIX :: Linux',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Security',
        'Topic :: Software Development :: Libraries',
        'Topic :: System :: Networking',
    ],
    install_requires=[
        'cryptography>=41.0.0',
        'httpx>=0.24.0',
        'mcp>=1.0',
        'pyjwt[crypto]>=2.8.0',
        'websockets>=12.0',
    ],
    extras_require={
        'dev': [
            'build>=1.0',
            'pytest>=8.0',
            'ruff>=0.4',
        ],
        'spiffe': [
            'spiffe>=0.2.0',
        ],
    },
    packages=[
        'cullis_sdk',
        'cullis_sdk.crypto',
    ],
)
