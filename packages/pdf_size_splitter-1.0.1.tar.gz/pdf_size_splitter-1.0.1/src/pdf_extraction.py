import io
from pypdf import PdfReader, PdfWriter

def get_extracted_size(file_path, start_page, end_page):
    data = extract_pages(file_path, start_page, end_page)
    return len(data)
    
def extract_pages(file_path, start_page, end_page):
    reader = PdfReader(file_path)
    writer = PdfWriter()
    
    for i in range(start_page, end_page + 1):
        writer.add_page(reader.pages[i])
    
    with io.BytesIO() as buffer:
        writer.write(buffer)
        return buffer.getvalue() # バイト列（bytes）を返す