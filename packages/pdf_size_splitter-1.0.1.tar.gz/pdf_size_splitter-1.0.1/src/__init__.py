"""
PDF Size Splitter - PDFファイルを指定したサイズで分割するツール
"""

__version__ = "1.0.1"
__author__ = "momoandbanana22"
