import os
from pypdf import PdfReader
from .pdf_extraction import extract_pages
from .split_logic import find_split_point

def split_pdf_by_size(input_pdf, max_size, output_dir):
    # ファイル存在チェック
    if not os.path.exists(input_pdf):
        raise ValueError("ファイルが存在しません")
        
    # ディレクトリ存在チェック
    if not os.path.isdir(output_dir):
        raise ValueError("出力先ディレクトリが存在しません")

    # 上限サイズのチェック
    if max_size <= 0:
        raise ValueError("上限サイズは1以上の数値を指定してください")

    reader = PdfReader(input_pdf)
    total_pages = len(reader.pages)
    
    base_name = os.path.splitext(os.path.basename(input_pdf))[0]
    
    start_page = 0
    part_number = 1
    
    while start_page < total_pages:
        # 上限に収まる終了ページを見つける
        end_page = find_split_point(input_pdf, start_page, max_size)
        
        # 該当ページを抽出してファイルに保存
        pdf_data = extract_pages(input_pdf, start_page, end_page)
        output_filename = os.path.join(output_dir, f"{base_name}_part{part_number}.pdf")
        
        with open(output_filename, "wb") as f:
            f.write(pdf_data)
            
        # 次の分割へ進む
        start_page = end_page + 1
        part_number += 1
