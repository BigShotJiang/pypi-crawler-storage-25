# PDF Size Splitter

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

指定したファイルサイズ（バイト）を上限として、PDFを複数のファイルに分割するコマンドラインツールです。  
ページ構造を破壊せず、指定サイズに収まる最大のページ数ごとに自動で分割します。

---

## 特徴（Features）

### 精密なファイルサイズ分割
PDFの構造を考慮しながら、指定したサイズに近づくようにページ単位で分割します。  
オンラインツールでは不安定になりがちな「サイズ基準の分割」を、ローカルで再現性高く実行できます。

### ローカル完結で安全
アップロード不要で、すべてローカル環境で処理されます。  
機密情報を含むPDFでも安全に扱えるため、業務用途にも適しています。

### 制限なし・高速処理
オンラインサービスにありがちな  
- ファイルサイズ上限  
- タスク数制限  
- 待ち時間  

といった制約がありません。大量ファイルのバッチ処理にも向いています。

### 透明性のある処理ロジック
分割アルゴリズムはコードとして公開されており、挙動がブラックボックスになりません。  
必要に応じてロジックを改良したり、ワークフローに合わせて拡張できます。

### ワークフローへの統合が容易
Pythonスクリプトとして動作するため、  
- 自動処理パイプライン  
- 他ツールとの連携  
- GUI化やAPI化  

など、用途に応じた柔軟な統合が可能です。

### 再現性の高い結果
同じ入力に対して常に同じ出力が得られるため、  
業務フローや自動化処理で重要な「結果の安定性」を確保できます。

---

## 機能

- 指定したサイズ（バイト）でPDFを自動分割
- ページ構造を保持
- 効率的な分割アルゴリズム（平均ページサイズからの予測 + 微調整）
- コマンドラインインターフェース

## 必須環境

- Python 3.8以上
- 依存ライブラリ: pypdf

## インストール方法

### PyPIからインストール（推奨）

```bash
pip install pdf-size-splitter
```

### ソースからインストール

1. リポジトリをクローンまたはダウンロードします。
2. 以下のコマンドで依存ライブラリをインストールします。

```bash
pip install -r requirements.txt
```

## 使い方

以下のコマンド形式で実行します。

```bash
python pdf_size_splitter.py <入力PDFのパス> <上限サイズ(バイト)> [-o 出力先ディレクトリ]
```

### 実行例
```bash
# sample.pdf を 10MB (10000000バイト) 単位で分割し、現在のディレクトリに保存する
python pdf_size_splitter.py sample.pdf 10000000

# sample.pdf を 5MB 単位で分割し、"output" フォルダに保存する
python pdf_size_splitter.py sample.pdf 5000000 -o output
```

## ライセンス

このプロジェクトはMIT Licenseの下で公開されています。詳細は [LICENSE](LICENSE) ファイルを参照してください。

## 作者

[momoandbanana22](https://github.com/momoandbanana22)

## 貢献

貢献を歓迎します！バグ報告や機能リクエストは [Issues](https://github.com/momoandbanana22/pdf-size-splitter/issues) にてお願いします。
