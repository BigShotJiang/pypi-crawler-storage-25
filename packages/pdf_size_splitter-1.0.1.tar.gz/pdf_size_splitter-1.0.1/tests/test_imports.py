import pytest
import sys
import os

def test_split_logic_uses_relative_import():
    """src/split_logic.py が相対インポートを使用していることを確認"""
    with open("src/split_logic.py", "r", encoding="utf-8") as f:
        content = f.read()
    
    # 絶対インポート（src.pdf_extraction）が含まれていないこと
    assert "from src.pdf_extraction" not in content, "絶対インポートが使用されています。相対インポートに変更してください"
    
    # 相対インポート（.pdf_extraction）が含まれていること
    assert "from .pdf_extraction" in content, "相対インポートが使用されていません"

def test_splitter_uses_relative_import():
    """src/splitter.py が相対インポートを使用していることを確認"""
    with open("src/splitter.py", "r", encoding="utf-8") as f:
        content = f.read()
    
    # 絶対インポートが含まれていないこと
    assert "from src.pdf_extraction" not in content, "絶対インポートが使用されています。相対インポートに変更してください"
    assert "from src.split_logic" not in content, "絶対インポートが使用されています。相対インポートに変更してください"
    
    # 相対インポートが含まれていること
    assert "from .pdf_extraction" in content, "相対インポートが使用されていません"
    assert "from .split_logic" in content, "相対インポートが使用されていません"

def test_main_entry_has_path_setup():
    """pdf_size_splitter.py が実行時にパスを設定していることを確認"""
    with open("pdf_size_splitter.py", "r", encoding="utf-8") as f:
        content = f.read()
    
    # sys.path.insert が含まれていること
    assert "sys.path.insert" in content, "実行時にパスを設定するコードがありません"
    assert "os.path.dirname" in content, "実行時にパスを設定するコードがありません"
