import pytest
import os
import glob
from src.splitter import split_pdf_by_size

def test_split_pdf_by_size(tmp_path):
    # Given: 10ページのPDFと、保存先ディレクトリ(pytestのtmp_pathを使用)
    input_pdf = os.path.join("tests", "test_data", "ten_pages.pdf")
    output_dir = str(tmp_path)
    
    # 上限サイズを「約3ページ分」に設定する
    total_size = os.path.getsize(input_pdf)
    max_size = (total_size // 10) * 3 + 100 
    
    # When: PDFを分割処理する
    split_pdf_by_size(input_pdf, max_size, output_dir)
    
    # Then: 出力先ディレクトリに複数のPDFが生成されていること
    output_files = glob.glob(os.path.join(output_dir, "*.pdf"))
    assert len(output_files) > 1

def test_split_pdf_by_size_file_not_found(tmp_path):
    input_pdf = "non_existent_file.pdf"
    output_dir = str(tmp_path)
    max_size = 1000

    # 単なるFileNotFoundErrorではなく、明確な意図を持った ValueError を期待する
    with pytest.raises(ValueError, match="ファイルが存在しません"):
        split_pdf_by_size(input_pdf, max_size, output_dir)

def test_split_pdf_by_size_output_dir_not_found():
    # Given: 存在する入力ファイルと、存在しない出力先ディレクトリ
    input_pdf = os.path.join("tests", "test_data", "ten_pages.pdf")
    output_dir = "non_existent_directory"
    max_size = 1000

    # When / Then: 実行すると ValueError が発生することを確認
    with pytest.raises(ValueError, match="出力先ディレクトリが存在しません"):
        split_pdf_by_size(input_pdf, max_size, output_dir)

def test_split_pdf_by_size_invalid_max_size(tmp_path):
    input_pdf = os.path.join("tests", "test_data", "ten_pages.pdf")
    output_dir = str(tmp_path)

    # 上限サイズが0の場合
    with pytest.raises(ValueError, match="上限サイズは1以上の数値を指定してください"):
        split_pdf_by_size(input_pdf, 0, output_dir)

    # 上限サイズがマイナスの場合
    with pytest.raises(ValueError, match="上限サイズは1以上の数値を指定してください"):
        split_pdf_by_size(input_pdf, -100, output_dir)
