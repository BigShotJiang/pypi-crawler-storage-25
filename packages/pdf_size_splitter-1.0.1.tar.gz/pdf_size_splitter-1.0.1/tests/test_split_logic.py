import pytest
import os
from src.pdf_extraction import get_extracted_size
from src.split_logic import find_split_point

def test_find_split_point():
    # Given: 3ページのPDF
    input_pdf = os.path.join("tests", "test_data", "three_pages.pdf")
    
    # 0枚目のサイズと、0〜1枚目のサイズを計測する
    size_1_page = get_extracted_size(input_pdf, 0, 0)
    size_2_pages = get_extracted_size(input_pdf, 0, 1)
    
    # 上限サイズを「1ページは収まるが、2ページは収まらないサイズ」に設定する
    max_size = size_1_page + 10  # 10バイトだけ余裕を持たせる
    
    # 念のため、上限サイズが想定通りか確認（事前条件のチェック）
    assert max_size < size_2_pages

    # When: 0枚目から開始して、max_sizeに収まる最大の終了ページを計算する
    split_point = find_split_point(input_pdf, start_page=0, max_size=max_size)

    # Then: 0枚目だけが収まるので、戻り値は 0 になること
    assert split_point == 0

def test_find_split_point_two_pages():
    input_pdf = os.path.join("tests", "test_data", "three_pages.pdf")
    
    # 0〜1枚目（2ページ分）と、0〜2枚目（3ページ分）のサイズを計測
    size_2_pages = get_extracted_size(input_pdf, 0, 1)
    size_3_pages = get_extracted_size(input_pdf, 0, 2)
    
    # 上限サイズを「2ページは収まるが、3ページは収まらないサイズ」に設定する
    max_size = size_2_pages + 10
    assert max_size < size_3_pages

    # When: 0枚目から開始して、計算する
    split_point = find_split_point(input_pdf, start_page=0, max_size=max_size)

    # Then: 0〜1枚目が収まるので、戻り値は 1 になること
    assert split_point == 1

def test_find_split_point_ten_pages():
    input_pdf = os.path.join("tests", "test_data", "ten_pages.pdf")
    
    # 0〜4枚目(5ページ分)と、0〜5枚目(6ページ分)のサイズを計測
    size_5_pages = get_extracted_size(input_pdf, 0, 4)
    size_6_pages = get_extracted_size(input_pdf, 0, 5)
    
    # 上限サイズを「5ページは収まるが、6ページは収まらないサイズ」に設定
    max_size = size_5_pages + 10
    assert max_size < size_6_pages

    # When: 0枚目から開始して計算する
    split_point = find_split_point(input_pdf, start_page=0, max_size=max_size)

    # Then: 0〜4枚目(5ページ分)が収まるので、戻り値は 4 になること
    assert split_point == 4

def test_find_split_point_page_exceeds_max_size():
    input_pdf = os.path.join("tests", "test_data", "three_pages.pdf")
    
    # 0枚目（1ページ目）の実際のサイズを取得
    first_page_size = get_extracted_size(input_pdf, 0, 0)
    
    # 上限サイズを「1ページ目のサイズよりも小さく」設定する
    max_size = first_page_size - 10 
    
    # When / Then: 1ページすら収まらない場合は ValueError が発生すること
    with pytest.raises(ValueError, match="1ページ目が既に指定サイズを超過しているため分割できません"):
        find_split_point(input_pdf, start_page=0, max_size=max_size)
