import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="psmil",
    version="0.0.15",
    author="Xuetong Li",
    author_email="xtong_li@126.com",
    description="psmil package",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Jamesyu420/PSMIL/tree/main",
    packages=setuptools.find_packages(),
    install_requires=[
      "numpy",
      ],
    classifiers=[
      "Programming Language :: Python :: 3",
      "License :: OSI Approved :: MIT License",
      "Operating System :: OS Independent",
      ],
)
