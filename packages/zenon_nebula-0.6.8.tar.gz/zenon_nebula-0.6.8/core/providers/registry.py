# SPDX-License-Identifier: MIT
"""ProviderRegistry — singleton lookup for every external capability.

Mirrors the shape of ``core.domain_registry.DomainRegistry`` so future
agents reading the codebase recognize the pattern: thread-safe
singleton, ``instance()`` accessor, ``reset()`` for tests, register
plugins programmatically OR via auto-discovery from a `builtin/`
subpackage.

Lookup paths engines use:

- ``get_registry().get("github")`` — fetch a provider by name.
- ``get_registry().get_by_kind("api-builtin")`` — fetch all providers
  of a given kind. Used by Phase B for "any user provider that handles
  market data" lookups.
- ``get_registry().list_available()`` — provider names where
  ``is_available()`` returns True. Used by ``nebula providers`` CLI.

The registry never raises into engine code. ``get(name)`` returns
``None`` for unknown names; engines that need a provider check the
return value and degrade gracefully when it's missing.

Phase A (v0.6.6) auto-discovers everything in ``core.providers.builtin``
at boot. Phase B (v0.6.7) adds the user provider config loader. Phase
G2 (v0.6.13) adds PyPI entry point discovery via
``importlib.metadata.entry_points(group="zenon_nebula.providers")``.
"""

from __future__ import annotations

import importlib
import logging
import pkgutil
import threading
from pathlib import Path

from core.providers.base import APIProvider

logger = logging.getLogger(__name__)


class ProviderRegistry:
    """Thread-safe singleton registry of all available providers.

    Built-in providers are auto-discovered from ``core/providers/builtin/``
    at first instantiation. Programmatic registration via ``register()``
    is also supported (used by tests + Phase B's user provider loader).
    """

    _instance: ProviderRegistry | None = None
    _lock = threading.Lock()

    @classmethod
    def instance(cls) -> ProviderRegistry:
        """Return the singleton registry, creating it on first call.

        Thread-safe via double-checked locking — same pattern as
        ``DomainRegistry.instance()``.
        """
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
                    cls._instance._discover_builtins()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset the singleton (for tests).

        After ``reset()``, the next ``instance()`` call re-discovers
        builtins from the filesystem. Tests use this to ensure each
        test starts with a fresh registry.
        """
        with cls._lock:
            if cls._instance is not None:
                # Best-effort shutdown of every registered provider
                # so subprocess providers (Phase B MCP consumer) don't
                # leak file descriptors across tests.
                for provider in cls._instance._providers.values():
                    try:
                        provider.shutdown()
                    except Exception as exc:
                        logger.debug(
                            "Provider %s shutdown failed during reset: %s",
                            provider.name(),
                            exc,
                        )
            cls._instance = None

    def __init__(self) -> None:
        self._providers: dict[str, APIProvider] = {}

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self, provider: APIProvider) -> None:
        """Register a provider instance.

        Raises ``ValueError`` if a provider with the same name is
        already registered. Use ``reset()`` in tests if you need to
        re-register a name.
        """
        name = provider.name()
        if not name:
            raise ValueError(f"Provider {provider.__class__.__name__} returned empty name")
        if name in self._providers:
            raise ValueError(
                f"Provider name conflict: {name!r} is already registered "
                f"(existing kind={self._providers[name].kind()!r}, new "
                f"kind={provider.kind()!r})"
            )
        self._providers[name] = provider
        logger.debug("Registered provider %s (kind=%s)", name, provider.kind())

    def unregister(self, name: str) -> None:
        """Remove a provider by name. No-op if not present.

        Used by ``nebula providers remove`` and by tests for selective
        cleanup.
        """
        provider = self._providers.pop(name, None)
        if provider is not None:
            try:
                provider.shutdown()
            except Exception as exc:
                logger.debug("Provider %s shutdown failed: %s", name, exc)

    # ------------------------------------------------------------------
    # Lookup
    # ------------------------------------------------------------------

    def get(self, name: str) -> APIProvider | None:
        """Return the provider with the given name, or ``None``.

        Engines call this to fetch a provider by stable name. Returning
        ``None`` instead of raising lets engines degrade gracefully
        when a provider isn't installed (e.g. an LLM-using engine on
        a no-XAI_API_KEY install).
        """
        return self._providers.get(name)

    def get_by_kind(self, kind: str) -> list[APIProvider]:
        """Return all providers matching the given kind discriminator.

        Used by Phase B for "any user provider that handles X" lookups
        and by Phase G2 for "any LLM provider" lookups.
        """
        return [p for p in self._providers.values() if p.kind() == kind]

    def list_all(self) -> list[APIProvider]:
        """Return every registered provider, in registration order."""
        return list(self._providers.values())

    def list_available(self) -> list[APIProvider]:
        """Return providers where ``is_available()`` returns True.

        ``is_available()`` may make a network call or read an env var,
        so this is more expensive than ``list_all()``. Cache the result
        if you call it in a hot path.
        """
        out: list[APIProvider] = []
        for provider in self._providers.values():
            try:
                if provider.is_available():
                    out.append(provider)
            except Exception as exc:
                logger.debug(
                    "Provider %s is_available raised: %s",
                    provider.name(),
                    exc,
                )
        return out

    def names(self) -> list[str]:
        """Return every registered provider name."""
        return list(self._providers.keys())

    def __len__(self) -> int:
        return len(self._providers)

    def __contains__(self, name: object) -> bool:
        return isinstance(name, str) and name in self._providers

    # ------------------------------------------------------------------
    # Built-in discovery
    # ------------------------------------------------------------------

    def _discover_builtins(self) -> None:
        """Walk ``core/providers/builtin/`` and register every provider.

        Each module under ``builtin/`` should expose a top-level
        ``PROVIDER`` constant (an instance of an ``APIProvider``
        subclass) OR a ``provider()`` factory function. Anything else
        is skipped silently — keeps the discovery loop tolerant of
        helper modules.

        Discovery failures are logged at debug level; one bad module
        does not prevent the others from registering.
        """
        try:
            import core.providers.builtin as builtin_pkg
        except ImportError:
            logger.debug("core.providers.builtin not importable yet")
            return

        builtin_path = Path(builtin_pkg.__file__).parent
        for module_info in pkgutil.iter_modules([str(builtin_path)]):
            if module_info.ispkg or module_info.name.startswith("_"):
                continue
            module_name = f"core.providers.builtin.{module_info.name}"
            try:
                module = importlib.import_module(module_name)
            except Exception as exc:
                logger.debug(
                    "Skipping builtin provider module %s: %s",
                    module_name,
                    exc,
                )
                continue

            provider = getattr(module, "PROVIDER", None)
            if provider is None:
                factory = getattr(module, "provider", None)
                if callable(factory):
                    try:
                        provider = factory()
                    except Exception as exc:
                        logger.debug(
                            "Provider factory %s.provider() raised: %s",
                            module_name,
                            exc,
                        )
                        continue

            if provider is None:
                continue

            if not isinstance(provider, APIProvider):
                logger.debug(
                    "Module %s exposed PROVIDER but it's not an APIProvider instance (got %s)",
                    module_name,
                    type(provider).__name__,
                )
                continue

            try:
                self.register(provider)
            except ValueError as exc:
                # Name conflict — log and skip. Tests reset the
                # registry between runs to avoid this.
                logger.debug("Builtin provider conflict: %s", exc)


def get_registry() -> ProviderRegistry:
    """Module-level convenience for ``ProviderRegistry.instance()``."""
    return ProviderRegistry.instance()


__all__ = ["ProviderRegistry", "get_registry"]
