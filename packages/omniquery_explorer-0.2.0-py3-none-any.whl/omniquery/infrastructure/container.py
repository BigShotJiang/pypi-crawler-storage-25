from __future__ import annotations

from functools import lru_cache

from omniquery.application.agents.eda_session_graph import EdaSessionGraph
from omniquery.application.use_cases.run_eda_use_case import RunEdaUseCase
from omniquery.config import Settings, get_settings
from omniquery.domain.ports.inbound.eda_use_case import EdaUseCase
from omniquery.domain.ports.outbound.database_port import DatabasePort
from omniquery.domain.ports.outbound.embedding_port import EmbeddingPort
from omniquery.domain.ports.outbound.llm_port import LlmPort
from omniquery.infrastructure.cache.cached_database import CachedDatabasePort
from omniquery.infrastructure.cache.cached_embedding import CachedEmbeddingPort
from omniquery.infrastructure.cache.disk_cache import DiskCache
from omniquery.infrastructure.cache.semantic_cache import SemanticQueryCache
from omniquery.infrastructure.db.adapter_factory import resolve_db_adapter
from omniquery.infrastructure.db.sql_profiling_adapter import SqlProfilingAdapter
from omniquery.infrastructure.governance.cost_guard import BudgetTracker
from omniquery.infrastructure.governance.pii_policy import PiiPolicy
from omniquery.infrastructure.graph.schema_linker import SchemaLinker
from omniquery.infrastructure.llm.llm_factory import resolve_llm_adapter
from omniquery.infrastructure.llm.memory_factory import resolve_checkpointer
from omniquery.infrastructure.llm.ollama_embedding_adapter import OllamaEmbeddingAdapter
from omniquery.infrastructure.observability.tracing import configure_tracing
from omniquery.infrastructure.persistence.session_store import PersistenceStore


class Container:
    """
    Lightweight dependency-injection container.

    Builds and caches the object graph at first access so that both the
    CLI and the Web adapter share the same singletons without a heavy
    DI framework. Configuration is supplied via the typed `Settings`
    module (see `omniquery.config`).
    """

    def __init__(self, settings: Settings | None = None) -> None:
        self._settings = settings or get_settings()
        configure_tracing(self._settings.observability)
        self._llm: LlmPort = resolve_llm_adapter(self._settings.llm)
        raw_emb: EmbeddingPort = OllamaEmbeddingAdapter(
            model=self._settings.llm.embedding_model,
            base_url=self._settings.llm.ollama_base_url,
        )
        self._emb: EmbeddingPort = CachedEmbeddingPort(
            raw_emb,
            self._settings.cache,
            model_id=self._settings.llm.embedding_model,
        )
        self._schema_linker = SchemaLinker(self._emb)
        self._profiler = SqlProfilingAdapter()
        self._store = (
            PersistenceStore(self._settings.persistence)
            if self._settings.persistence.enabled
            else None
        )
        # Single in-process budget tracker shared by every use-case call.
        # Counters reset on process restart; for durable quotas use a
        # workspace-aware store (see IMPROVEMENTS.md §3.4).
        self._budget = BudgetTracker(self._settings.cost)
        # Stateless PII policy compiled once from regex settings.
        self._pii = PiiPolicy(self._settings.pii)
        # LangGraph checkpointer (None when MEMORY_ENABLED=false). Held
        # at the container level so every EdaSessionGraph instance
        # shares the same saver — that's how separate /ask calls with
        # the same thread_id see each other's state.
        self._checkpointer = resolve_checkpointer(self._settings.memory)
        # Semantic question cache. Shares the on-disk root with the
        # other caches but lives under its own namespace so its
        # serialised list never collides with schema/embedding pickles.
        self._semantic_cache = SemanticQueryCache(
            settings=self._settings.semantic_cache,
            embedder=self._emb,
            disk=DiskCache(
                self._settings.cache.dir,
                self._settings.semantic_cache.namespace,
            ),
        )

    @property
    def settings(self) -> Settings:
        return self._settings

    def _db(self, connection_url: str) -> DatabasePort:
        return CachedDatabasePort(
            resolve_db_adapter(connection_url),
            self._settings.cache,
        )

    @property
    def store(self) -> PersistenceStore | None:
        return self._store

    def eda_use_case(self, connection_url: str) -> EdaUseCase:
        return RunEdaUseCase(
            db=self._db(connection_url),
            llm=self._llm,
            store=self._store,
            budget=self._budget,
            pii=self._pii,
            semantic_cache=self._semantic_cache,
        )

    def eda_session_graph(self, connection_url: str) -> EdaSessionGraph:
        return EdaSessionGraph(
            db=self._db(connection_url),
            llm=self._llm,
            profiler=self._profiler,
            schema_linker=self._schema_linker,
            checkpointer=self._checkpointer,
        )


@lru_cache(maxsize=1)
def get_container() -> Container:
    """Return the process-wide singleton Container."""
    return Container(get_settings())
