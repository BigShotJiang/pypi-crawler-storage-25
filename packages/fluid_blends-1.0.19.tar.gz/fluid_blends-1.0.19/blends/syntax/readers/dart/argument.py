from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
    match_ast_d,
)
from blends.syntax.builders.argument import (
    build_argument_node,
)
from blends.syntax.builders.named_argument import (
    build_named_argument_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.syntax.readers.common.dart_accessor_chain import (
    try_build_accessor_chain,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    first_child, *other_childs = adj_ast(graph, args.n_id)

    if not other_childs:
        return args.generic(args.fork_n_id(first_child))

    if label_id := match_ast_d(graph, args.n_id, "label"):
        var_id = adj_ast(graph, label_id)[0]
        arg_name = node_to_str(graph, var_id)
        return build_named_argument_node(args, arg_name, other_childs[0])

    if (
        graph.nodes[first_child]["label_type"] == "identifier"
        and all(graph.nodes[c]["label_type"] == "selector" for c in other_childs)
        and (
            result := try_build_accessor_chain(
                args, graph, graph.nodes[first_child]["label_text"], first_child, other_childs
            )
        )
    ):
        return result

    valid_childs = list(adj_ast(args.ast_graph, args.n_id))
    return build_argument_node(args, iter(valid_childs))
