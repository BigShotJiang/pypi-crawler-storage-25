from collections.abc import (
    Callable,
    Iterable,
)
from typing import TypeAlias

from blends.ast.node_attributes_types import AstNodeAttrs
from blends.edge_attributes_types import EdgeAttrs
from blends.models import (
    Graph,
    NId,
)
from blends.syntax.node_attributes_types import SyntaxNodeAttrs

NAttrs: TypeAlias = AstNodeAttrs | SyntaxNodeAttrs


def has_labels(n_attrs: NAttrs, **expected_attrs: str) -> bool:
    return all(
        n_attrs.get(expected_attr) == expected_attr_value
        for expected_attr, expected_attr_value in expected_attrs.items()
    )


def has_edge_labels(e_attrs: EdgeAttrs, **expected_attrs: str) -> bool:
    return all(
        e_attrs.get(expected_attr) == expected_attr_value
        for expected_attr, expected_attr_value in expected_attrs.items()
    )


def predicate_has_labels(**expected_attrs: str) -> Callable[[NAttrs], bool]:
    def predicate(n_attrs: NAttrs) -> bool:
        return has_labels(n_attrs, **expected_attrs)

    return predicate


def predicate_has_edge_labels(**expected_attrs: str) -> Callable[[EdgeAttrs], bool]:
    def predicate(e_attrs: EdgeAttrs) -> bool:
        return has_edge_labels(e_attrs, **expected_attrs)

    return predicate


def filter_nodes(
    graph: Graph,
    nodes: Iterable[NId],
    predicate: Callable[[NAttrs], bool],
) -> tuple[NId, ...]:
    result: tuple[NId, ...] = tuple(n_id for n_id in nodes if predicate(graph.nodes[n_id]))

    return result


def matching_nodes(
    graph: Graph, label_type: str | None = None, **expected_attrs: str
) -> tuple[NId, ...]:
    if label_type:
        candidates = graph.nodes_by_type.get(label_type, [])
        if expected_attrs:
            return filter_nodes(graph, candidates, predicate_has_labels(**expected_attrs))
        return tuple(candidates)
    return filter_nodes(graph, graph.nodes, predicate_has_labels(**expected_attrs))
