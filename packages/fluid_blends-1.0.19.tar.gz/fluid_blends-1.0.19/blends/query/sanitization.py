from collections.abc import Callable
from typing import NamedTuple

from blends.models import (
    NId,
    SanitizationEvent,
    SyntaxGraph,
)
from blends.query import (
    adj_ast,
    pred_ast,
    resolve_symbol_all_scope_index,
)


class _SanitizationFilter(NamedTuple):
    usage_n_id: NId
    exclude_parent: NId | None = None
    definition_n_id: NId | None = None


def _get_var_name_for_index(graph: SyntaxGraph, n_id: NId) -> str | None:
    label_type = graph.nodes[n_id].get("label_type")
    if label_type == "SymbolLookup":
        symbol = graph.nodes[n_id].get("symbol")
        return str(symbol) if symbol else None
    if label_type == "MemberAccess":
        expression = graph.nodes[n_id].get("expression", "")
        member = graph.nodes[n_id].get("member", "")
        return f"{expression}.{member}" if expression and member else None
    if label_type == "MethodInvocation" and (args_id := graph.nodes[n_id].get("arguments_id")):
        for child_id in adj_ast(graph, args_id, label_type="MemberAccess"):
            expression = graph.nodes[child_id].get("expression", "")
            member = graph.nodes[child_id].get("member", "")
            if expression and member:
                return f"{expression}.{member}"
        for child_id in adj_ast(graph, args_id, label_type="SymbolLookup"):
            if symbol := graph.nodes[child_id].get("symbol"):
                return str(symbol)
    return None


def _get_node_scope(graph: SyntaxGraph, n_id: NId) -> NId | None:
    if stored_scope := graph.nodes[n_id].get("symbol_scope"):
        return int(stored_scope)
    scope_label_types = {"File", "MethodDeclaration", "Class"}
    for parent_id in pred_ast(graph, n_id, depth=-1):
        if graph.nodes[parent_id].get("label_type") in scope_label_types:
            return parent_id
    return None


def _get_enclosing_event_parent(graph: SyntaxGraph, n_id: NId) -> NId | None:
    for parent_id in pred_ast(graph, n_id, depth=-1):
        parent_type = graph.nodes[parent_id].get("label_type")
        if parent_type in {"MethodInvocation", "If"}:
            return parent_id
        if parent_type in {"File", "MethodDeclaration", "Class"}:
            break
    return None


def _get_nearest_definition(graph: SyntaxGraph, n_id: NId) -> NId | None:
    if graph.nodes[n_id].get("label_type") == "SymbolLookup":
        all_defs = resolve_symbol_all_scope_index(graph, n_id)
        return max(all_defs) if all_defs else None
    return None


def _find_sanitization_events(
    graph: SyntaxGraph,
    var_name: str,
    scope: NId,
    bounds: _SanitizationFilter,
) -> list[SanitizationEvent]:
    lower_bound = bounds.definition_n_id if bounds.definition_n_id is not None else 0
    current_scope: NId | None = scope
    while current_scope is not None:
        if events := graph.sanitization_index.get(var_name, {}).get(current_scope):
            filtered = [
                event
                for event in events
                if event.node_id > lower_bound
                and event.node_id < bounds.usage_n_id
                and event.node_id != bounds.exclude_parent
            ]
            if filtered:
                return filtered
        current_scope = graph.scope_parent.get(current_scope)
    return []


def is_sanitized_by_index(graph: SyntaxGraph, n_id: NId) -> bool:
    if not (var_name := _get_var_name_for_index(graph, n_id)):
        return False
    if (scope := _get_node_scope(graph, n_id)) is None:
        return False
    bounds = _SanitizationFilter(
        usage_n_id=n_id,
        exclude_parent=_get_enclosing_event_parent(graph, n_id),
        definition_n_id=_get_nearest_definition(graph, n_id),
    )
    return len(_find_sanitization_events(graph, var_name, scope, bounds)) > 0


def _get_danger_defs(
    graph: SyntaxGraph,
    searched_nid: NId,
    unsafe_condition: Callable[[SyntaxGraph, NId], bool],
) -> list[NId]:
    danger_defs = []
    for def_id in resolve_symbol_all_scope_index(graph, searched_nid):
        val_id = graph.nodes[def_id].get("value_id")
        check_id = val_id if val_id is not None else def_id
        if unsafe_condition(graph, check_id):
            danger_defs.append(def_id)
    return danger_defs


def is_node_definition_unsafe_by_index(
    graph: SyntaxGraph,
    n_id: NId,
    unsafe_condition_on_node_definition: Callable[[SyntaxGraph, NId], bool],
    *,
    evaluate_sanitization: bool = False,
) -> bool:
    if unsafe_condition_on_node_definition(graph, n_id):
        return True

    if graph.nodes[n_id].get("label_type") != "SymbolLookup":
        return False

    danger_defs = _get_danger_defs(graph, n_id, unsafe_condition_on_node_definition)
    if not danger_defs:
        return False

    if not evaluate_sanitization:
        return True

    return not is_sanitized_by_index(graph, n_id)
