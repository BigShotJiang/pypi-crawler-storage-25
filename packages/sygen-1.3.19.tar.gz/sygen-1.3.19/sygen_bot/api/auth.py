"""JWT authentication for the Sygen API server.

Provides JWT-based multi-user authentication with username/password login.
Users are stored in ``~/.sygen/users.json`` with PBKDF2-hashed passwords.

Roles: admin (full access), operator (read + run tasks/crons),
viewer (read-only).  Each user can be restricted to specific agents
via the ``allowed_agents`` field (empty list = all agents).
"""

from __future__ import annotations

import base64
import functools
import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import struct
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

import jwt
from aiohttp import web

from sygen_bot.api.crypto_utils import (
    decrypt_totp_secret,
    encrypt_totp_secret,
    looks_like_encrypted_totp,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Coroutine

    from sygen_bot.config import ApiConfig

logger = logging.getLogger(__name__)

# Defaults (overridable via config)
_ACCESS_TOKEN_EXPIRES = 15 * 60  # 15 min
_REFRESH_TOKEN_EXPIRES = 30 * 24 * 3600  # 30 d
_ALGORITHM = "HS256"

# Temp token expiry for 2FA flow (5 minutes)
_TEMP_TOKEN_EXPIRES = 5 * 60

# Paths that never require auth
_PUBLIC_PATHS = frozenset({
    "/health",
    "/api/auth/login",
    "/api/auth/refresh",
    "/api/auth/2fa/login",
})

# Cookie names — changing these is a breaking change for deployed admins.
COOKIE_ACCESS = "sygen_access"
COOKIE_REFRESH = "sygen_refresh"
COOKIE_CSRF = "sygen_csrf"

# HTTP methods that require CSRF protection under cookie auth.
_UNSAFE_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})

# Paths that never require CSRF (cookies-less HMAC-authenticated, etc).
# Login-family endpoints are exempt because there is no session cookie yet.
_CSRF_EXEMPT_PATHS = frozenset({
    "/api/auth/login",
    "/api/auth/refresh",
    "/api/auth/logout",
    "/api/auth/2fa/login",
})

# Role hierarchy: higher index = more privileges
ROLE_LEVELS = {"viewer": 0, "operator": 1, "admin": 2}

# Rate limiting defaults
_RATE_LIMIT_WINDOW = 60  # seconds
_RATE_LIMIT_MAX = 5  # max attempts per window

# Persistent paths — secrets live under ``_secrets/`` so they are isolated
# from CLI agents scoped to the workspace directory.  Legacy top-level paths
# are kept for the startup migration (see security.secrets_paths).
_SYGEN_DIR = Path(os.environ.get("SYGEN_HOME", Path.home() / ".sygen"))
_SECRETS_DIR = _SYGEN_DIR / "_secrets"
_JWT_SECRET_PATH = _SECRETS_DIR / ".jwt_secret"
_JWT_BLACKLIST_PATH = _SECRETS_DIR / ".jwt_blacklist.json"
_USERS_PATH = _SECRETS_DIR / "users.json"
_AUDIT_LOG_PATH = _SECRETS_DIR / "audit.log"
_INITIAL_ADMIN_PW_PATH = _SECRETS_DIR / ".initial_admin_password"
# Legacy locations used exclusively for fallback reads during the first
# boot after upgrade; the startup migration moves files out of here.
_LEGACY_JWT_SECRET_PATH = _SYGEN_DIR / ".jwt_secret"
_LEGACY_JWT_BLACKLIST_PATH = _SYGEN_DIR / ".jwt_blacklist.json"
_LEGACY_USERS_PATH = _SYGEN_DIR / "users.json"
_LEGACY_AUDIT_LOG_PATH = _SYGEN_DIR / "audit.log"
_LEGACY_INITIAL_ADMIN_PW_PATH = _SYGEN_DIR / ".initial_admin_password"


def _ensure_secrets_dir(path: Path) -> None:
    """Create *path*'s parent with 0700 if it is the canonical secrets dir."""
    parent = path.parent
    try:
        parent.mkdir(parents=True, exist_ok=True)
        if parent.name == "_secrets":
            os.chmod(parent, 0o700)
    except OSError:
        pass


def _read_secret_fallback(primary: Path, legacy: Path) -> Path | None:
    """Return whichever of *primary* or *legacy* exists (primary wins)."""
    if primary.is_file():
        return primary
    if legacy.is_file():
        return legacy
    return None

# Minimum password length (used everywhere passwords are accepted)
_MIN_PASSWORD_LEN = 8


def sign_file_url(
    jwt_secret: str,
    *,
    agent: str,
    relative_path: str,
    ttl: int = 60,
) -> dict[str, str | int]:
    """Produce query-string parameters authorizing a short-lived file download.

    Uses HMAC-SHA256 keyed on the JWT secret. The returned dict maps to
    a ``/api/files/download`` query — ``exp`` is a Unix timestamp.
    """
    exp = int(time.time()) + int(ttl)
    msg = f"{agent}|{relative_path}|{exp}".encode("utf-8")
    sig = hmac.new(jwt_secret.encode("utf-8"), msg, hashlib.sha256).hexdigest()
    return {
        "agent": agent,
        "relative_path": relative_path,
        "exp": exp,
        "sig": sig,
    }


def verify_signed_url(
    jwt_secret: str,
    *,
    agent: str,
    relative_path: str,
    exp: str,
    sig: str,
) -> bool:
    """Constant-time validation of a signed download URL.

    Fails on any of: missing parts, expired ``exp``, non-integer ``exp``,
    or HMAC mismatch.
    """
    if not (jwt_secret and agent and relative_path and exp and sig):
        return False
    try:
        exp_int = int(exp)
    except (TypeError, ValueError):
        return False
    if exp_int < int(time.time()):
        return False
    msg = f"{agent}|{relative_path}|{exp_int}".encode("utf-8")
    expected = hmac.new(
        jwt_secret.encode("utf-8"), msg, hashlib.sha256,
    ).hexdigest()
    return hmac.compare_digest(expected, sig)


def _validate_password_policy(password: str) -> str | None:
    """Validate a password against the policy. Returns error string or None."""
    if not password or len(password) < _MIN_PASSWORD_LEN:
        return f"password must be at least {_MIN_PASSWORD_LEN} characters"
    return None

# Max audit log size before rotation
_AUDIT_MAX_LINES = 10_000


# ---------------------------------------------------------------------------
# Password hashing (PBKDF2-SHA256, stdlib only)
# ---------------------------------------------------------------------------

def hash_password(password: str) -> str:
    """Hash a password with PBKDF2-SHA256. Returns 'salt:hash' hex string."""
    salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 260_000)
    return f"{salt}:{dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    """Verify a password against a 'salt:hash' string."""
    if ":" not in stored:
        return False
    salt, expected = stored.split(":", 1)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 260_000)
    return hmac.compare_digest(dk.hex(), expected)


# Precomputed dummy hash used to equalize timing when the username is
# unknown. Without this, an unknown-user path short-circuits and becomes
# detectably faster than the known-user path (user enumeration oracle).
_DUMMY_PASSWORD_HASH = hash_password("__dummy_timing_constant__")


# ---------------------------------------------------------------------------
# TOTP (RFC 6238, stdlib only)
# ---------------------------------------------------------------------------

def generate_totp_secret() -> str:
    """Generate a 160-bit base32-encoded TOTP secret."""
    raw = secrets.token_bytes(20)  # 160 bits
    return base64.b32encode(raw).decode("ascii")


def _hotp(secret_b32: str, counter: int) -> str:
    """Generate a 6-digit HOTP code (RFC 4226)."""
    key = base64.b32decode(secret_b32, casefold=True)
    msg = struct.pack(">Q", counter)
    h = hmac.new(key, msg, hashlib.sha1).digest()
    offset = h[-1] & 0x0F
    code = struct.unpack(">I", h[offset : offset + 4])[0] & 0x7FFFFFFF
    return str(code % 10**6).zfill(6)


def totp_code(secret_b32: str, *, now: float | None = None) -> str:
    """Generate the current TOTP code (30-second window, SHA1, 6 digits)."""
    t = int((now or time.time()) / 30)
    return _hotp(secret_b32, t)


def verify_totp(secret_b32: str, code: str, *, now: float | None = None) -> bool:
    """Verify a TOTP code allowing ±1 window drift."""
    t = int((now or time.time()) / 30)
    for offset in (-1, 0, 1):
        if hmac.compare_digest(_hotp(secret_b32, t + offset), code):
            return True
    return False


def build_otpauth_uri(username: str, secret_b32: str) -> str:
    """Build an otpauth:// URI for QR code generation."""
    return f"otpauth://totp/Sygen:{username}?secret={secret_b32}&issuer=Sygen"


# ---------------------------------------------------------------------------
# Users file management
# ---------------------------------------------------------------------------

def _read_users() -> list[dict[str, Any]]:
    """Read users from users.json. Returns empty list if missing.

    Prefers ``_secrets/users.json`` but falls back to the legacy top-level
    location for the brief window before the startup migration has moved the
    file.  Tests that patch ``_USERS_PATH`` keep isolation because the legacy
    constant points at the same tmp dir via ``_SYGEN_DIR``.
    """
    source = _read_secret_fallback(_USERS_PATH, _LEGACY_USERS_PATH)
    if source is None:
        return []
    try:
        data = json.loads(source.read_text("utf-8"))
        return data.get("users", []) if isinstance(data, dict) else data
    except (json.JSONDecodeError, OSError):
        return []


def _write_users(users: list[dict[str, Any]]) -> None:
    """Write users list to users.json atomically (canonical path only)."""
    _ensure_secrets_dir(_USERS_PATH)
    tmp = _USERS_PATH.with_suffix(".tmp")
    tmp.write_text(
        json.dumps({"users": users}, indent=2, ensure_ascii=False),
        "utf-8",
    )
    tmp.replace(_USERS_PATH)
    try:
        os.chmod(_USERS_PATH, 0o600)
    except OSError:
        pass
    # If a stale legacy copy still exists, remove it so the fallback is no
    # longer consulted after a successful write.  Best-effort; a failure just
    # means the next startup migration handles it.
    if _LEGACY_USERS_PATH != _USERS_PATH and _LEGACY_USERS_PATH.exists():
        try:
            _LEGACY_USERS_PATH.unlink()
        except OSError:
            pass


def _find_user(username: str) -> dict[str, Any] | None:
    """Find a user by username."""
    for u in _read_users():
        if u.get("username") == username:
            return u
    return None


def get_user_role(username: str | None) -> str | None:
    """Return the role for *username* from users.json, or ``None``.

    Returns ``None`` for unknown users, inactive users, or when *username*
    itself is ``None``.  Callers should treat ``None`` as "no role information"
    and fall back to the global permission mode (legacy behavior).
    """
    if not username:
        return None
    user = _find_user(username)
    if user is None or not user.get("active", True):
        return None
    role = user.get("role")
    return role if isinstance(role, str) and role else None


def _find_user_by_telegram_id(tg_id: int) -> dict[str, Any] | None:
    """Find a user whose ``telegram_user_ids`` list contains *tg_id*."""
    for u in _read_users():
        ids = u.get("telegram_user_ids")
        if not isinstance(ids, list):
            continue
        for raw in ids:
            try:
                if int(raw) == int(tg_id):
                    return u
            except (TypeError, ValueError):
                continue
    return None


def get_user_role_by_telegram_id(tg_id: int | None) -> str | None:
    """Return the role for the user mapped to Telegram *tg_id*, or ``None``.

    Looks up the first active user in ``users.json`` whose optional
    ``telegram_user_ids`` list contains *tg_id*.  Returns ``None`` when no
    mapping exists or the user is inactive; callers should then fall back
    to the global permission mode.
    """
    if tg_id is None:
        return None
    user = _find_user_by_telegram_id(tg_id)
    if user is None or not user.get("active", True):
        return None
    role = user.get("role")
    return role if isinstance(role, str) and role else None


def get_username_by_telegram_id(tg_id: int | None) -> str | None:
    """Return the username mapped to Telegram *tg_id*, or ``None``.

    Active users only.  Used to stamp ``caller_user_id`` on inter-agent
    calls originating from Telegram.
    """
    if tg_id is None:
        return None
    user = _find_user_by_telegram_id(tg_id)
    if user is None or not user.get("active", True):
        return None
    name = user.get("username")
    return name if isinstance(name, str) and name else None


def _generate_initial_admin_password() -> str:
    """Generate a 16-character URL-safe random password for the bootstrap admin."""
    # token_urlsafe(12) -> 16 characters base64url (96 bits of entropy).
    return secrets.token_urlsafe(12)[:16]


def _write_initial_admin_password_file(password: str) -> None:
    """Persist the bootstrap admin password to a protected file (mode 0600)."""
    try:
        _ensure_secrets_dir(_INITIAL_ADMIN_PW_PATH)
        tmp = _INITIAL_ADMIN_PW_PATH.with_suffix(".tmp")
        tmp.write_text(
            f"{password}\ndelete this file after first login\n",
            "utf-8",
        )
        tmp.replace(_INITIAL_ADMIN_PW_PATH)
        try:
            os.chmod(_INITIAL_ADMIN_PW_PATH, 0o600)
        except OSError:
            pass
    except OSError:
        logger.warning(
            "Could not persist initial admin password to %s",
            _INITIAL_ADMIN_PW_PATH,
        )


def _ensure_default_admin() -> None:
    """Create a bootstrap admin user with a random password if users.json is empty."""
    users = _read_users()
    if users:
        return
    password = _generate_initial_admin_password()
    default = {
        "username": "admin",
        "password_hash": hash_password(password),
        "role": "admin",
        "display_name": "Administrator",
        "allowed_agents": [],
        "active": True,
        "created_at": time.time(),
        "token_version": 0,
    }
    _write_users([default])
    _write_initial_admin_password_file(password)
    logger.warning(
        "Created bootstrap admin user 'admin' with a random password. "
        "Password written to %s (mode 0600). "
        "Delete this file after first login.",
        _INITIAL_ADMIN_PW_PATH,
    )


# ---------------------------------------------------------------------------
# Audit log
# ---------------------------------------------------------------------------

def write_audit(*, user: str, action: str, target: str = "", details: str = "") -> None:
    """Append an entry to the audit log. Rotates when exceeding _AUDIT_MAX_LINES."""
    ts = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
    line = json.dumps({
        "ts": ts,
        "user": user,
        "action": action,
        "target": target,
        "details": details,
    }, ensure_ascii=False)
    try:
        _ensure_secrets_dir(_AUDIT_LOG_PATH)
        with _AUDIT_LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
        # Rotate if over max lines
        _maybe_rotate_audit()
    except OSError:
        logger.warning("Could not write to audit log")


def _maybe_rotate_audit() -> None:
    """Keep only the last _AUDIT_MAX_LINES entries in the audit log."""
    try:
        lines = _AUDIT_LOG_PATH.read_text("utf-8").splitlines()
        if len(lines) <= _AUDIT_MAX_LINES:
            return
        # Keep last half of max to avoid rotating on every write
        keep = lines[-((_AUDIT_MAX_LINES * 3) // 4):]
        tmp = _AUDIT_LOG_PATH.with_suffix(".tmp")
        tmp.write_text("\n".join(keep) + "\n", "utf-8")
        tmp.replace(_AUDIT_LOG_PATH)
        logger.info("Rotated audit log: %d -> %d entries", len(lines), len(keep))
    except OSError:
        pass


def read_audit(limit: int = 200) -> list[dict[str, Any]]:
    """Read last N audit log entries."""
    source = _read_secret_fallback(_AUDIT_LOG_PATH, _LEGACY_AUDIT_LOG_PATH)
    if source is None:
        return []
    try:
        lines = source.read_text("utf-8").strip().splitlines()
    except OSError:
        return []
    entries = []
    for line in lines[-limit:]:
        try:
            entries.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    entries.reverse()
    return entries


def _load_or_create_secret(config_secret: str) -> str:
    """Load JWT secret from config, persistent file, or generate a new one.

    Reads the canonical ``_secrets/.jwt_secret`` and falls back to the legacy
    top-level path while migration is still pending.  Never regenerates when
    a legacy secret is still present — that would invalidate every live JWT
    session.
    """
    if config_secret:
        return config_secret
    # Try reading from the canonical location first, then the legacy copy.
    for candidate in (_JWT_SECRET_PATH, _LEGACY_JWT_SECRET_PATH):
        try:
            stored = candidate.read_text("utf-8").strip()
            if stored:
                return stored
        except (FileNotFoundError, OSError):
            continue
    # Generate and persist
    new_secret = secrets.token_hex(32)
    try:
        _ensure_secrets_dir(_JWT_SECRET_PATH)
        tmp = _JWT_SECRET_PATH.with_suffix(".tmp")
        tmp.write_text(new_secret, "utf-8")
        tmp.replace(_JWT_SECRET_PATH)
        os.chmod(_JWT_SECRET_PATH, 0o600)
    except OSError:
        logger.warning("Could not persist JWT secret to %s", _JWT_SECRET_PATH)
    return new_secret


def _load_blacklist() -> dict[str, float]:
    """Load persisted blacklist, discarding expired entries."""
    try:
        data = json.loads(_JWT_BLACKLIST_PATH.read_text("utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}
    now = time.time()
    return {jti: exp for jti, exp in data.items() if isinstance(exp, (int, float)) and exp > now}


def _persist_blacklist(blacklist: dict[str, float]) -> None:
    """Write blacklist to disk atomically."""
    try:
        _JWT_BLACKLIST_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = _JWT_BLACKLIST_PATH.with_suffix(".tmp")
        tmp.write_text(json.dumps(blacklist), "utf-8")
        tmp.replace(_JWT_BLACKLIST_PATH)
    except OSError:
        logger.warning("Could not persist JWT blacklist to %s", _JWT_BLACKLIST_PATH)


class JWTAuth:
    """JWT token manager and middleware for the API server."""

    def __init__(
        self,
        config: ApiConfig,
        *,
        access_expires: int = _ACCESS_TOKEN_EXPIRES,
        refresh_expires: int = _REFRESH_TOKEN_EXPIRES,
    ) -> None:
        self._config = config
        self._secret = _load_or_create_secret(getattr(config, "jwt_secret", "") or "")
        self._access_expires = access_expires
        self._refresh_expires = refresh_expires
        # Persisted blacklist for invalidated refresh tokens (jti -> exp)
        self._blacklist: dict[str, float] = _load_blacklist()
        # In-memory rate limiter: ip -> list of timestamps
        self._login_attempts: dict[str, list[float]] = {}
        # TOTP replay protection: "user:code" -> expiry timestamp
        self._used_totp_codes: dict[str, float] = {}

    # -- TOTP replay protection --------------------------------------------------

    def _check_totp_replay(self, username: str, code: str) -> bool:
        """Return True if this TOTP code was already used (replay attack)."""
        key = f"{username}:{code}"
        now = time.time()
        # Clean up expired entries periodically
        if len(self._used_totp_codes) > 1000:
            self._used_totp_codes = {
                k: exp for k, exp in self._used_totp_codes.items() if exp > now
            }
        return key in self._used_totp_codes and self._used_totp_codes[key] > now

    def _mark_totp_used(self, username: str, code: str) -> None:
        """Mark a TOTP code as used. Expires after 90 seconds (covers +-1 window)."""
        key = f"{username}:{code}"
        self._used_totp_codes[key] = time.time() + 90

    # -- Rate limiting -----------------------------------------------------------

    def _check_rate_limit(self, ip: str) -> bool:
        """Return True if the IP is rate-limited. Cleans up old entries."""
        now = time.time()
        cutoff = now - _RATE_LIMIT_WINDOW
        attempts = self._login_attempts.get(ip, [])
        # Remove old attempts
        attempts = [t for t in attempts if t > cutoff]
        self._login_attempts[ip] = attempts
        if len(attempts) >= _RATE_LIMIT_MAX:
            return True
        # Periodically purge stale IPs (every 100th call)
        if not hasattr(self, "_rl_counter"):
            self._rl_counter = 0
        self._rl_counter += 1
        if self._rl_counter >= 100:
            self._rl_counter = 0
            self._login_attempts = {
                k: [t for t in v if t > cutoff]
                for k, v in self._login_attempts.items()
                if any(t > cutoff for t in v)
            }
        return False

    def _record_attempt(self, ip: str) -> None:
        """Record a login attempt for rate limiting."""
        now = time.time()
        self._login_attempts.setdefault(ip, []).append(now)

    # -- Token creation -------------------------------------------------------

    def _create_token(
        self,
        sub: str,
        role: str,
        expires_in: int,
        *,
        token_type: str = "access",
        **extra: Any,
    ) -> str:
        now = time.time()
        payload: dict[str, Any] = {
            "sub": sub,
            "role": role,
            "type": token_type,
            "iat": now,
            "exp": now + expires_in,
            "jti": secrets.token_hex(16),
            **extra,
        }
        return jwt.encode(payload, self._secret, algorithm=_ALGORITHM)

    def create_token_pair(
        self,
        user_id: str = "api_user",
        role: str = "admin",
        allowed_agents: list[str] | None = None,
        token_version: int = 0,
    ) -> dict[str, str]:
        """Return ``{"access_token": ..., "refresh_token": ...}``."""
        extra: dict[str, Any] = {"tv": int(token_version)}
        if allowed_agents:
            extra["allowed_agents"] = allowed_agents
        return {
            "access_token": self._create_token(
                user_id, role, self._access_expires, token_type="access", **extra,
            ),
            "refresh_token": self._create_token(
                user_id, role, self._refresh_expires, token_type="refresh", **extra,
            ),
        }

    # -- Token validation -----------------------------------------------------

    def decode(self, token: str, *, expected_type: str = "access") -> dict[str, Any]:
        """Decode and validate a JWT.  Raises ``jwt.PyJWTError`` on failure."""
        payload = jwt.decode(token, self._secret, algorithms=[_ALGORITHM])
        if payload.get("type") != expected_type:
            raise jwt.InvalidTokenError(
                f"Expected token type '{expected_type}', got '{payload.get('type')}'"
            )
        jti = payload.get("jti", "")
        if jti in self._blacklist:
            raise jwt.InvalidTokenError("Token has been revoked")
        return payload

    # -- Blacklist management -------------------------------------------------

    def revoke(self, token: str) -> None:
        """Add a refresh token's jti to the blacklist and persist."""
        try:
            payload = jwt.decode(
                token, self._secret, algorithms=[_ALGORITHM],
                options={"verify_exp": False},
            )
        except jwt.PyJWTError:
            return
        jti = payload.get("jti", "")
        exp = payload.get("exp", 0)
        if jti:
            self._blacklist[jti] = exp
            _persist_blacklist(self._blacklist)

    def cleanup_blacklist(self) -> None:
        """Remove expired entries from the blacklist and persist."""
        now = time.time()
        self._blacklist = {
            jti: exp for jti, exp in self._blacklist.items() if exp > now
        }
        _persist_blacklist(self._blacklist)

    # -- Cookie helpers -------------------------------------------------------

    def _cookie_is_secure(self, request: web.Request) -> bool:
        """True if auth cookies should be sent with the ``Secure`` attribute."""
        if getattr(self._config, "cookie_secure", True):
            return True
        # Respect reverse-proxy forwarded scheme when cookie_secure is disabled.
        if request.scheme == "https":
            return True
        fwd = request.headers.get("X-Forwarded-Proto", "").lower()
        return fwd == "https"

    def _set_auth_cookies(
        self,
        request: web.Request,
        response: web.Response,
        access_token: str,
        refresh_token: str | None = None,
    ) -> None:
        """Set httpOnly access/refresh cookies and a non-httpOnly CSRF cookie."""
        secure = self._cookie_is_secure(request)
        domain = getattr(self._config, "cookie_domain", "") or None
        common: dict[str, Any] = {
            "httponly": True,
            "secure": secure,
            "samesite": "Strict",
        }
        if domain:
            common["domain"] = domain
        # Scavenge pre-migration cookies stuck at Path=/api so the freshly
        # issued Path=/ cookie isn't masked by the more-specific-path one
        # (Chromium serialises Path=/api before Path=/ on the same host).
        response.del_cookie(COOKIE_ACCESS, path="/api")
        response.set_cookie(
            COOKIE_ACCESS,
            access_token,
            path="/",
            max_age=self._access_expires,
            **common,
        )
        if refresh_token is not None:
            response.set_cookie(
                COOKIE_REFRESH,
                refresh_token,
                path="/api/auth",
                max_age=self._refresh_expires,
                **common,
            )
        # CSRF cookie — NOT httponly so JS can read it and echo via header.
        csrf_value = secrets.token_urlsafe(24)
        csrf_attrs: dict[str, Any] = {
            "httponly": False,
            "secure": secure,
            "samesite": "Strict",
            "path": "/",
            "max_age": self._refresh_expires,
        }
        if domain:
            csrf_attrs["domain"] = domain
        response.set_cookie(COOKIE_CSRF, csrf_value, **csrf_attrs)

    def _clear_auth_cookies(self, response: web.Response) -> None:
        """Remove all auth-related cookies on logout."""
        response.del_cookie(COOKIE_ACCESS, path="/")
        response.del_cookie(COOKIE_ACCESS, path="/api")  # pre-migration path
        response.del_cookie(COOKIE_REFRESH, path="/api/auth")
        response.del_cookie(COOKIE_CSRF, path="/")

    # -- aiohttp middleware ---------------------------------------------------

    @web.middleware
    async def middleware(
        self,
        request: web.Request,
        handler: Callable[[web.Request], Coroutine[Any, Any, web.StreamResponse]],
    ) -> web.StreamResponse:
        """Check JWT (or legacy Bearer token) on ``/api/*`` routes.

        Public paths and non-``/api`` paths are passed through.
        If a valid legacy Bearer token is provided, the request proceeds
        with a synthetic ``admin`` identity for backward compatibility.
        """
        path = request.path
        if path in _PUBLIC_PATHS or not path.startswith("/api"):
            return await handler(request)
        # Agent avatar GET is public (served as <img src>; no auth headers)
        if request.method == "GET" and re.match(r"^/api/agents/[a-zA-Z0-9_-]+/avatar$", path):
            return await handler(request)
        # File download: handler does its own auth (Authorization: Bearer / cookie / signed)
        if request.method == "GET" and path == "/api/files/download":
            return await handler(request)

        # Cookie-based auth is the primary path. Authorization header is kept
        # for backward compat with CLI/Telegram clients that can't store cookies.
        cookie_token = request.cookies.get(COOKIE_ACCESS, "")
        auth_header = request.headers.get("Authorization", "")
        bearer_token = auth_header[7:] if auth_header.startswith("Bearer ") else ""

        # CSRF protection for cookie-auth mutating requests.
        # Header-only auth bypasses CSRF (cross-origin attacker cannot set Authorization).
        if (
            cookie_token
            and not bearer_token
            and request.method in _UNSAFE_METHODS
            and path not in _CSRF_EXEMPT_PATHS
        ):
            csrf_cookie = request.cookies.get(COOKIE_CSRF, "")
            csrf_header = request.headers.get("X-CSRF-Token", "")
            if (
                not csrf_cookie
                or not csrf_header
                or not hmac.compare_digest(csrf_cookie, csrf_header)
            ):
                return web.json_response({"error": "CSRF token missing or invalid"}, status=403)

        raw_token = bearer_token or cookie_token
        if not raw_token:
            return web.json_response({"error": "missing Authorization header"}, status=401)

        # Try legacy static token first (backward compatibility)
        if self._config.token and hmac.compare_digest(raw_token, self._config.token):
            ip = request.remote or "unknown"
            logger.warning(
                "legacy static admin token used from %s (path=%s)", ip, path,
            )
            write_audit(
                user="legacy_admin",
                action="legacy_token_auth",
                target=path,
                details=f"ip={ip} method={request.method}",
            )
            request["jwt_user"] = {"sub": "legacy", "role": "admin"}
            return await handler(request)

        # Try JWT
        try:
            payload = self.decode(raw_token, expected_type="access")
        except jwt.PyJWTError:
            logger.debug("JWT decode failed for request to %s", path)
            return web.json_response({"error": "invalid token"}, status=401)

        # Enforce token_version: if the user exists and has bumped their
        # version (password change, refresh-token replay), stale access
        # tokens are rejected. Tokens for virtual identities (no user record)
        # are not constrained here — refresh still validates user existence.
        sub = payload.get("sub", "")
        if sub and sub != "legacy_admin":
            user = _find_user(sub)
            if user is not None and int(payload.get("tv", 0)) != int(
                user.get("token_version", 0),
            ):
                return web.json_response({"error": "token revoked"}, status=401)

        request["jwt_user"] = payload
        return await handler(request)

    # -- Route handlers -------------------------------------------------------

    async def handle_login(self, request: web.Request) -> web.Response:
        """``POST /api/auth/login`` — authenticate with username+password or legacy token."""
        ip = request.remote or "unknown"
        if self._check_rate_limit(ip):
            return web.json_response(
                {"error": "too many login attempts, try again later"},
                status=429,
            )

        try:
            body = await request.json()
        except Exception:
            self._record_attempt(ip)
            return web.json_response({"error": "invalid JSON body"}, status=400)

        # --- Path 1: username + password login ---
        username = body.get("username", "")
        password = body.get("password", "")
        if username and password:
            user = _find_user(str(username))
            if user is None:
                # Equalize timing so attackers can't probe for username existence.
                verify_password(str(password), _DUMMY_PASSWORD_HASH)
                self._record_attempt(ip)
                return web.json_response({"error": "invalid credentials"}, status=401)
            if not verify_password(str(password), user.get("password_hash", "")):
                self._record_attempt(ip)
                return web.json_response({"error": "invalid credentials"}, status=401)
            if not user.get("active", True):
                self._record_attempt(ip)
                return web.json_response({"error": "account is disabled"}, status=403)

            # If 2FA is enabled, return a temp token instead of full tokens
            if user.get("totp_enabled"):
                temp_token = self._create_token(
                    str(username),
                    user.get("role", "viewer"),
                    _TEMP_TOKEN_EXPIRES,
                    token_type="2fa_temp",
                )
                logger.info("JWT login (2FA required): user=%s ip=%s", username, ip)
                return web.json_response({
                    "requires_2fa": True,
                    "temp_token": temp_token,
                })

            role = user.get("role", "viewer")
            allowed_agents = user.get("allowed_agents", [])
            tokens = self.create_token_pair(
                user_id=str(username),
                role=role,
                allowed_agents=allowed_agents,
                token_version=int(user.get("token_version", 0)),
            )
            write_audit(user=str(username), action="login", details=f"ip={ip}")
            logger.info("JWT login: user=%s role=%s ip=%s", username, role, ip)
            resp = web.json_response({
                **tokens,
                "user": {
                    "username": user.get("username"),
                    "role": role,
                    "display_name": user.get("display_name", ""),
                    "allowed_agents": allowed_agents,
                },
            })
            self._set_auth_cookies(
                request, resp, tokens["access_token"], tokens["refresh_token"],
            )
            return resp

        # --- Path 2: legacy token login (backward compatibility) ---
        token = body.get("token", "")
        if token and self._config.token and hmac.compare_digest(str(token), self._config.token):
            tokens = self.create_token_pair(user_id="legacy_admin", role="admin")
            write_audit(
                user="legacy_admin",
                action="legacy_token_auth",
                target="/api/auth/login",
                details=f"ip={ip} method=login",
            )
            logger.warning("legacy static admin token used from %s (path=/api/auth/login)", ip)
            resp = web.json_response({
                **tokens,
                "user": {
                    "username": "legacy_admin",
                    "role": "admin",
                    "display_name": "Legacy Admin",
                    "allowed_agents": [],
                },
            })
            self._set_auth_cookies(
                request, resp, tokens["access_token"], tokens["refresh_token"],
            )
            return resp

        self._record_attempt(ip)
        return web.json_response({"error": "invalid credentials"}, status=401)

    async def handle_refresh(self, request: web.Request) -> web.Response:
        """``POST /api/auth/refresh`` — rotate refresh token and return new pair.

        Rotation: each refresh issues a fresh refresh token (new jti) and
        blacklists the old one. If the old jti is replayed (already in the
        blacklist), all refresh tokens for this user are revoked by bumping
        ``token_version``.
        """
        try:
            body = await request.json()
        except Exception:
            body = {}

        refresh_token = (
            body.get("refresh_token", "")
            or request.cookies.get(COOKIE_REFRESH, "")
        )
        if not refresh_token:
            return web.json_response({"error": "missing refresh_token"}, status=400)

        # Decode without enforcing blacklist first — we need to detect replay.
        try:
            payload = jwt.decode(
                str(refresh_token), self._secret, algorithms=[_ALGORITHM],
            )
        except jwt.PyJWTError:
            logger.debug("Refresh token decode failed")
            return web.json_response({"error": "invalid refresh token"}, status=401)

        if payload.get("type") != "refresh":
            return web.json_response({"error": "invalid refresh token"}, status=401)

        jti = payload.get("jti", "")
        username = payload.get("sub", "")

        # Legacy token users bypass user-db checks (exact match only, no rotation)
        if username == "legacy_admin":
            if jti and jti in self._blacklist:
                return web.json_response({"error": "refresh token revoked"}, status=401)
            access_token = self._create_token(
                username, "admin", self._access_expires, token_type="access",
            )
            resp = web.json_response({"access_token": access_token})
            self._set_auth_cookies(request, resp, access_token)
            return resp

        # Re-check user status from users.json
        user = _find_user(username)

        # Replay detection: jti already blacklisted but token signature valid
        if jti and jti in self._blacklist:
            if user is not None:
                users = _read_users()
                for u in users:
                    if u.get("username") == username:
                        u["token_version"] = int(u.get("token_version", 0)) + 1
                        break
                _write_users(users)
            logger.warning(
                "refresh token replay detected for user=%s jti=%s — revoking all sessions",
                username, jti,
            )
            write_audit(
                user=username,
                action="refresh_token_replay",
                target=username,
                details=f"jti={jti}",
            )
            return web.json_response({"error": "refresh token revoked"}, status=401)

        if not user:
            return web.json_response({"error": "user no longer exists"}, status=401)
        if not user.get("active", True):
            return web.json_response({"error": "account is disabled"}, status=403)

        user_tv = int(user.get("token_version", 0))
        if int(payload.get("tv", 0)) != user_tv:
            return web.json_response({"error": "refresh token revoked"}, status=401)

        # Rotate: blacklist old jti, issue new token pair
        exp = payload.get("exp", 0)
        if jti:
            self._blacklist[jti] = float(exp)
            _persist_blacklist(self._blacklist)

        role = user.get("role", "viewer")
        allowed_agents = user.get("allowed_agents", [])
        tokens = self.create_token_pair(
            user_id=username,
            role=role,
            allowed_agents=allowed_agents,
            token_version=user_tv,
        )
        resp = web.json_response(tokens)
        self._set_auth_cookies(
            request, resp, tokens["access_token"], tokens["refresh_token"],
        )
        return resp

    async def handle_logout(self, request: web.Request) -> web.Response:
        """``POST /api/auth/logout`` — revoke a refresh token + clear cookies."""
        try:
            body = await request.json()
        except Exception:
            body = {}

        refresh_token = (
            body.get("refresh_token", "")
            or request.cookies.get(COOKIE_REFRESH, "")
        )
        if refresh_token:
            self.revoke(str(refresh_token))
            self.cleanup_blacklist()

        resp = web.json_response({"status": "ok"})
        self._clear_auth_cookies(resp)
        return resp

    async def handle_me(self, request: web.Request) -> web.Response:
        """``GET /api/auth/me`` — return current user info from users.json.

        Reads live data so role/allowed_agents changes are reflected immediately.
        """
        jwt_user = request.get("jwt_user")
        if not jwt_user:
            return web.json_response({"error": "unauthorized"}, status=401)

        username = jwt_user.get("sub", "")

        # Legacy token users don't have a users.json entry
        if username == "legacy_admin":
            return web.json_response({
                "username": username,
                "role": "admin",
                "display_name": "Legacy Admin",
                "allowed_agents": [],
            })

        user = _find_user(username)
        if not user:
            return web.json_response({"error": "user not found"}, status=401)

        return web.json_response({
            "username": user.get("username", ""),
            "role": user.get("role", "viewer"),
            "display_name": user.get("display_name", ""),
            "avatar": user.get("avatar", ""),
            "allowed_agents": user.get("allowed_agents", []),
            "totp_enabled": bool(user.get("totp_enabled", False)),
        })

    async def handle_update_profile(self, request: web.Request) -> web.Response:
        """``PUT /api/auth/profile`` — update own display_name or password.

        Accepts JSON body with optional fields:
        - ``display_name``: new display name
        - ``old_password`` + ``new_password``: change password

        Does NOT allow changing role, allowed_agents, or active status.
        """
        jwt_user = request.get("jwt_user")
        if not jwt_user:
            return web.json_response({"error": "unauthorized"}, status=401)

        username = jwt_user.get("sub", "")
        if username == "legacy_admin":
            return web.json_response(
                {"error": "legacy token users cannot update profile"},
                status=400,
            )

        try:
            body = await request.json()
        except Exception:
            return web.json_response({"error": "invalid JSON body"}, status=400)

        users = _read_users()
        user = None
        for u in users:
            if u.get("username") == username:
                user = u
                break
        if not user:
            return web.json_response({"error": "user not found"}, status=401)

        changes: list[str] = []

        # Display name
        new_display = body.get("display_name")
        if new_display is not None:
            user["display_name"] = str(new_display)
            changes.append("display_name")

        # Avatar path
        new_avatar = body.get("avatar")
        if new_avatar is not None:
            user["avatar"] = str(new_avatar)
            changes.append("avatar")

        # Password change
        old_pw = body.get("old_password", "")
        new_pw = body.get("new_password", "")
        if old_pw or new_pw:
            if not old_pw or not new_pw:
                return web.json_response(
                    {"error": "both old_password and new_password are required"},
                    status=400,
                )
            if not verify_password(str(old_pw), user.get("password_hash", "")):
                return web.json_response(
                    {"error": "current password is incorrect"},
                    status=400,
                )
            pw_err = _validate_password_policy(str(new_pw))
            if pw_err:
                return web.json_response({"error": pw_err}, status=400)
            user["password_hash"] = hash_password(str(new_pw))
            # Revoke all existing tokens (access + refresh) for this user
            user["token_version"] = int(user.get("token_version", 0)) + 1
            changes.append("password")

        if not changes:
            return web.json_response({"error": "no changes provided"}, status=400)

        _write_users(users)
        write_audit(
            user=username,
            action="profile_updated",
            target=username,
            details=f"changed: {', '.join(changes)}",
        )

        return web.json_response({
            "username": user.get("username", ""),
            "role": user.get("role", "viewer"),
            "display_name": user.get("display_name", ""),
            "avatar": user.get("avatar", ""),
            "allowed_agents": user.get("allowed_agents", []),
        })

    # -- 2FA endpoints -----------------------------------------------------------

    def _totp_secret_for(self, user: dict[str, Any]) -> str:
        """Return the plaintext TOTP secret, migrating legacy plaintext to encrypted.

        If the stored value is already an encrypted blob, decrypt it. If it's
        plaintext (legacy), encrypt and persist it on the fly, then return the
        plaintext for use.
        """
        stored = user.get("totp_secret", "") or ""
        if not stored:
            return ""
        if looks_like_encrypted_totp(stored):
            try:
                return decrypt_totp_secret(stored, self._secret)
            except ValueError:
                logger.warning(
                    "failed to decrypt totp_secret for user=%s", user.get("username", ""),
                )
                return ""
        # Legacy plaintext — migrate in place.
        try:
            encrypted = encrypt_totp_secret(stored, self._secret)
        except ValueError:
            return stored
        username = user.get("username", "")
        users = _read_users()
        for u in users:
            if u.get("username") == username:
                u["totp_secret"] = encrypted
                break
        _write_users(users)
        logger.info("migrated plaintext TOTP secret to encrypted form for user=%s", username)
        return stored

    async def handle_2fa_login(self, request: web.Request) -> web.Response:
        """``POST /api/auth/2fa/login`` — complete 2FA login with temp token + TOTP code."""
        ip = request.remote or "unknown"
        if self._check_rate_limit(ip):
            return web.json_response(
                {"error": "too many login attempts, try again later"},
                status=429,
            )

        try:
            body = await request.json()
        except Exception:
            return web.json_response({"error": "invalid JSON body"}, status=400)

        temp_token = body.get("temp_token", "")
        code = body.get("code", "")
        if not temp_token or not code:
            self._record_attempt(ip)
            return web.json_response({"error": "temp_token and code are required"}, status=400)

        try:
            payload = self.decode(str(temp_token), expected_type="2fa_temp")
        except jwt.PyJWTError:
            self._record_attempt(ip)
            return web.json_response({"error": "invalid or expired temp token"}, status=401)

        username = payload["sub"]
        user = _find_user(username)
        if not user:
            return web.json_response({"error": "user not found"}, status=401)
        if not user.get("active", True):
            return web.json_response({"error": "account is disabled"}, status=403)

        totp_secret = self._totp_secret_for(user)
        code_str = str(code)
        if not totp_secret or not verify_totp(totp_secret, code_str):
            self._record_attempt(ip)
            return web.json_response({"error": "invalid 2FA code"}, status=401)

        # TOTP replay protection: reject reused codes within their validity window
        if self._check_totp_replay(username, code_str):
            self._record_attempt(ip)
            return web.json_response({"error": "invalid 2FA code"}, status=401)
        self._mark_totp_used(username, code_str)

        # Revoke the temp token so it cannot be reused
        self.revoke(str(temp_token))

        role = user.get("role", "viewer")
        allowed_agents = user.get("allowed_agents", [])
        tokens = self.create_token_pair(
            user_id=username,
            role=role,
            allowed_agents=allowed_agents,
            token_version=int(user.get("token_version", 0)),
        )
        write_audit(user=username, action="login", details=f"ip={ip} 2fa=true")
        logger.info("JWT login (2FA): user=%s role=%s ip=%s", username, role, ip)
        resp = web.json_response({
            **tokens,
            "user": {
                "username": user.get("username"),
                "role": role,
                "display_name": user.get("display_name", ""),
                "allowed_agents": allowed_agents,
            },
        })
        self._set_auth_cookies(
            request, resp, tokens["access_token"], tokens["refresh_token"],
        )
        return resp

    async def handle_2fa_setup(self, request: web.Request) -> web.Response:
        """``POST /api/auth/2fa/setup`` — generate TOTP secret for the current user."""
        jwt_user = request.get("jwt_user")
        if not jwt_user:
            return web.json_response({"error": "unauthorized"}, status=401)

        username = jwt_user.get("sub", "")
        if username == "legacy_admin":
            return web.json_response(
                {"error": "legacy token users cannot enable 2FA"}, status=400,
            )

        user = _find_user(username)
        if not user:
            return web.json_response({"error": "user not found"}, status=401)

        if user.get("totp_enabled"):
            return web.json_response({"error": "2FA is already enabled"}, status=400)

        secret = generate_totp_secret()
        otpauth_uri = build_otpauth_uri(username, secret)

        # Store secret in pending field (not active until verified)
        users = _read_users()
        for u in users:
            if u.get("username") == username:
                u["totp_pending_secret"] = secret
                break
        _write_users(users)

        return web.json_response({
            "secret": secret,
            "otpauth_uri": otpauth_uri,
            "qr_data": otpauth_uri,
        })

    async def handle_2fa_verify(self, request: web.Request) -> web.Response:
        """``POST /api/auth/2fa/verify`` — verify TOTP code and enable 2FA."""
        jwt_user = request.get("jwt_user")
        if not jwt_user:
            return web.json_response({"error": "unauthorized"}, status=401)

        username = jwt_user.get("sub", "")
        try:
            body = await request.json()
        except Exception:
            return web.json_response({"error": "invalid JSON body"}, status=400)

        code = body.get("code", "")
        if not code:
            return web.json_response({"error": "code is required"}, status=400)

        users = _read_users()
        user = None
        for u in users:
            if u.get("username") == username:
                user = u
                break
        if not user:
            return web.json_response({"error": "user not found"}, status=401)

        totp_secret = user.get("totp_pending_secret", "") or user.get("totp_secret", "")
        if not totp_secret:
            return web.json_response({"error": "call /api/auth/2fa/setup first"}, status=400)

        if not verify_totp(totp_secret, str(code)):
            return web.json_response({"error": "invalid code"}, status=400)

        try:
            user["totp_secret"] = encrypt_totp_secret(totp_secret, self._secret)
        except ValueError:
            user["totp_secret"] = totp_secret
        user.pop("totp_pending_secret", None)
        user["totp_enabled"] = True
        _write_users(users)
        write_audit(user=username, action="2fa_enabled", target=username)
        return web.json_response({"status": "ok", "totp_enabled": True})

    async def handle_2fa_disable(self, request: web.Request) -> web.Response:
        """``POST /api/auth/2fa/disable`` — disable 2FA (requires password + TOTP)."""
        jwt_user = request.get("jwt_user")
        if not jwt_user:
            return web.json_response({"error": "unauthorized"}, status=401)

        username = jwt_user.get("sub", "")
        try:
            body = await request.json()
        except Exception:
            return web.json_response({"error": "invalid JSON body"}, status=400)

        code = body.get("code", "")
        password = body.get("password", "")
        if not code or not password:
            return web.json_response(
                {"error": "password and code are required"}, status=400,
            )

        users = _read_users()
        user = None
        for u in users:
            if u.get("username") == username:
                user = u
                break
        if not user:
            return web.json_response({"error": "user not found"}, status=401)

        # Password must match BEFORE TOTP check
        if not verify_password(str(password), user.get("password_hash", "")):
            return web.json_response({"error": "invalid password or code"}, status=401)

        if not user.get("totp_enabled") or not user.get("totp_secret"):
            return web.json_response({"error": "2FA is not enabled"}, status=400)

        totp_secret = self._totp_secret_for(user)
        if not totp_secret or not verify_totp(totp_secret, str(code)):
            return web.json_response({"error": "invalid password or code"}, status=401)

        # Re-read users after potential migration-write in _totp_secret_for
        users = _read_users()
        for u in users:
            if u.get("username") == username:
                u["totp_enabled"] = False
                u["totp_secret"] = ""
                u.pop("totp_backup_codes", None)
                break
        _write_users(users)
        write_audit(user=username, action="2fa_disabled", target=username)
        return web.json_response({"status": "ok", "totp_enabled": False})

    def register_routes(self, app: web.Application) -> None:
        """Add auth endpoints to the aiohttp application."""
        _ensure_default_admin()
        # Expose JWT secret so REST handlers can sign file URLs without
        # re-loading from disk (important when config.jwt_secret was set
        # explicitly, e.g. in tests).
        app["jwt_secret"] = self._secret
        app["jwt_auth"] = self
        app.router.add_post("/api/auth/login", self.handle_login)
        app.router.add_post("/api/auth/refresh", self.handle_refresh)
        app.router.add_post("/api/auth/logout", self.handle_logout)
        app.router.add_get("/api/auth/me", self.handle_me)
        app.router.add_put("/api/auth/profile", self.handle_update_profile)
        # 2FA endpoints
        app.router.add_post("/api/auth/2fa/login", self.handle_2fa_login)
        app.router.add_post("/api/auth/2fa/setup", self.handle_2fa_setup)
        app.router.add_post("/api/auth/2fa/verify", self.handle_2fa_verify)
        app.router.add_post("/api/auth/2fa/disable", self.handle_2fa_disable)


# -- Role-based access decorator ----------------------------------------------


def require_role(
    minimum_role: str,
) -> Callable[
    [Callable[..., Coroutine[Any, Any, web.StreamResponse]]],
    Callable[..., Coroutine[Any, Any, web.StreamResponse]],
]:
    """Decorator that enforces a minimum role level on a handler.

    Usage::

        @require_role("operator")
        async def handle_run_task(request: web.Request) -> web.Response:
            ...
    """
    min_level = ROLE_LEVELS.get(minimum_role, 0)

    def decorator(
        fn: Callable[..., Coroutine[Any, Any, web.StreamResponse]],
    ) -> Callable[..., Coroutine[Any, Any, web.StreamResponse]]:
        @functools.wraps(fn)
        async def wrapper(
            *args: Any, **kwargs: Any,
        ) -> web.StreamResponse:
            # Find the request object (works for both plain functions and methods)
            request: web.Request | None = None
            for arg in args:
                if isinstance(arg, web.Request):
                    request = arg
                    break
            if request is None:
                request = kwargs.get("request")  # type: ignore[assignment]

            if request is None:
                return web.json_response({"error": "internal error"}, status=500)

            user = request.get("jwt_user")
            if not user:
                return web.json_response({"error": "unauthorized"}, status=401)

            user_level = ROLE_LEVELS.get(user.get("role", ""), -1)
            if user_level < min_level:
                return web.json_response(
                    {"error": f"insufficient permissions, requires '{minimum_role}' role"},
                    status=403,
                )
            return await fn(*args, **kwargs)

        return wrapper

    return decorator
