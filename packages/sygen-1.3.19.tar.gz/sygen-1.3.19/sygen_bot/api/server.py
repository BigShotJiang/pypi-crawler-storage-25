"""Direct API server: WebSocket interface for app connections.

Runs alongside the Telegram bot without affecting it.  Designed for use
over Tailscale (default) or other private networks so that no traffic
passes through third-party servers.

WebSocket protocol (E2E encrypted)
-----------------------------------
1. Client connects to ``ws://<host>:<port>/ws``
2. Client sends ``{"type": "auth", "token": "...", "e2e_pk": "<b64>"}``
   (optional ``"chat_id": N`` to override default session)
3. Server responds ``{"type": "auth_ok", "chat_id": N, "e2e_pk": "<b64>", "providers": [...], "active_provider": "...", "active_model": "..."}``
4. All subsequent frames are E2E encrypted: ``base64(nonce_24 + ciphertext)``
5. Encrypted message: ``{"type": "message", "text": "..."}``
   Server streams back encrypted events:
     - ``{"type": "text_delta",     "data": "..."}``
     - ``{"type": "tool_activity",  "data": "..."}``
     - ``{"type": "system_status",  "data": "..."}``
     - ``{"type": "result", "text": "...", "stream_fallback": bool, "files": [...]}``
6. Encrypted abort: ``{"type": "abort"}`` (or ``/stop`` as message text)
   Server responds ``{"type": "abort_ok", "killed": N}``

HTTP endpoints
--------------
- ``GET /health``              -- health check
- ``GET /files?path=<abs>``    -- download a file (JWT/Bearer token auth)
- ``POST /upload``             -- upload a file (JWT/Bearer token auth, multipart)
"""

from __future__ import annotations

import asyncio
import hmac
import json
import logging
import shutil
from collections.abc import Awaitable, Callable, Sequence
from pathlib import Path
from typing import TYPE_CHECKING, Any

import aiohttp
import jwt
from aiohttp import BodyPartReader, WSMsgType, web

from sygen_bot.api.auth import JWTAuth, ROLE_LEVELS

if TYPE_CHECKING:
    from sygen_bot.api.crypto import E2ESession
from sygen_bot.bus.lock_pool import LockPool
from sygen_bot.files.image_processor import process_image
from sygen_bot.files.prompt import MediaInfo, build_media_prompt
from sygen_bot.files.storage import prepare_destination, sanitize_filename
from sygen_bot.files.tags import (
    classify_mime,
    extract_file_paths,
    guess_mime,
    is_image_path,
    path_from_file_tag,
)
from sygen_bot.log_context import set_log_context
from sygen_bot.security.paths import is_path_safe
from sygen_bot.session.key import SessionKey
from sygen_bot.text.response_format import normalize_tool_name

if TYPE_CHECKING:
    from sygen_bot.config import ApiConfig

logger = logging.getLogger(__name__)

# Callback types matching Orchestrator.handle_message_streaming / abort
StreamingMessageHandler = Callable[..., Awaitable[Any]]
AbortHandler = Callable[[int], Awaitable[int]]

_MAX_UPLOAD_BYTES = 500 * 1024 * 1024  # 500 MB
_MAX_WS_CONNECTIONS = 50  # (#8)
_MAX_WS_MSG_SIZE = 1 * 1024 * 1024  # 1 MB per WebSocket frame
_WS_AUTH_RATE_WINDOW = 60  # seconds
_WS_AUTH_RATE_MAX = 10  # max failed WS auth attempts per IP per window


def _detect_tailscale() -> bool:
    """Return True if the ``tailscale`` binary is found in PATH."""
    return shutil.which("tailscale") is not None


async def _ws_send(ws: web.WebSocketResponse, data: dict[str, object]) -> bool:
    """Send plaintext JSON to a WebSocket (auth phase only).  Returns False on disconnect."""
    if ws.closed:
        return False
    try:
        await ws.send_json(data)
    except (ConnectionResetError, ConnectionError):
        return False
    return True


async def _ws_reject(ws: web.WebSocketResponse, code: str, message: str) -> None:
    """Send an error response and close the WebSocket."""
    await _ws_send(ws, {"type": "error", "code": code, "message": message})
    await ws.close()


class _SecureChannel:
    """Encrypted WebSocket channel for post-auth communication."""

    __slots__ = ("_e2e", "ws")

    def __init__(self, ws: web.WebSocketResponse, e2e: E2ESession) -> None:
        self.ws = ws
        self._e2e = e2e

    @property
    def closed(self) -> bool:
        return bool(self.ws.closed)

    async def send(self, data: dict[str, object]) -> bool:
        """Encrypt and send.  Returns False if connection lost."""
        if self.ws.closed:
            return False
        try:
            await self.ws.send_str(self._e2e.encrypt(data))
        except (ConnectionResetError, ConnectionError):
            return False
        return True

    def decrypt(self, frame: str) -> dict[str, Any]:
        """Decrypt an incoming encrypted frame."""
        return self._e2e.decrypt(frame)


class _StreamCallbacks:
    """Streaming callbacks that forward encrypted orchestrator events to a WebSocket."""

    __slots__ = ("channel", "disconnected")

    def __init__(self, channel: _SecureChannel) -> None:
        self.channel = channel
        self.disconnected = False

    async def on_text(self, delta: str) -> None:
        if self.disconnected:
            return
        if not await self.channel.send({"type": "text_delta", "data": delta}):
            self.disconnected = True

    async def on_tool(self, name: str) -> None:
        if self.disconnected:
            return
        name = normalize_tool_name(name)
        if not await self.channel.send({"type": "tool_activity", "data": name}):
            self.disconnected = True

    async def on_system(self, label: str | None) -> None:
        if self.disconnected:
            return
        if not await self.channel.send({"type": "system_status", "data": label}):
            self.disconnected = True


def _parse_file_refs(text: str) -> list[dict[str, object]]:
    """Extract ``<file:...>`` tags and return metadata for the app."""
    refs: list[dict[str, object]] = []
    for fp in extract_file_paths(text):
        p = path_from_file_tag(fp)
        refs.append(
            {
                "path": str(p),
                "name": p.name,
                "is_image": is_image_path(str(p)),
            }
        )
    return refs


# -- Security headers middleware ------------------------------------------------

@web.middleware
async def _security_headers_middleware(
    request: web.Request,
    handler: Callable[..., Awaitable[web.StreamResponse]],
) -> web.StreamResponse:
    """Add standard security headers to all responses."""
    resp = await handler(request)
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Cache-Control", "no-store")
    resp.headers.setdefault("Content-Security-Policy", "default-src 'none'")
    return resp


# -- CORS middleware (#12) -----------------------------------------------------

_DEFAULT_CORS_ORIGINS = ("http://localhost:3000", "http://127.0.0.1:3000")
_CORS_ALLOW_HEADERS = "Authorization, Content-Type, X-CSRF-Token"


def _normalize_origin(origin: str) -> set[str]:
    """Return equivalent localhost/127.0.0.1 aliases for a given origin."""
    if not origin:
        return set()
    origin = origin.rstrip("/")
    out = {origin}
    if "://localhost" in origin:
        out.add(origin.replace("://localhost", "://127.0.0.1"))
    elif "://127.0.0.1" in origin:
        out.add(origin.replace("://127.0.0.1", "://localhost"))
    return out


def _build_cors_origins(
    cors_origins: list[str] | None,
    admin_url: str = "",
    cors_extra: list[str] | None = None,
) -> set[str]:
    """Assemble the allowed-origin set from config fields."""
    origins: set[str] = set()
    if cors_origins:
        for o in cors_origins:
            origins |= _normalize_origin(o)
    if admin_url:
        origins |= _normalize_origin(admin_url)
    if cors_extra:
        for o in cors_extra:
            origins |= _normalize_origin(o)
    if not origins:
        for o in _DEFAULT_CORS_ORIGINS:
            origins |= _normalize_origin(o)
    return origins


def _make_cors_middleware(
    allowed_origins: list[str] | None = None,
    *,
    admin_url: str = "",
    cors_extra: list[str] | None = None,
) -> web.middleware:
    """Create a simple CORS middleware."""
    origins = _build_cors_origins(allowed_origins, admin_url, cors_extra)

    @web.middleware
    async def cors_middleware(
        request: web.Request,
        handler: Callable[..., Awaitable[web.StreamResponse]],
    ) -> web.StreamResponse:
        origin = request.headers.get("Origin", "")

        # Handle preflight
        if request.method == "OPTIONS":
            resp = web.Response(status=204)
            if origin in origins:
                resp.headers["Access-Control-Allow-Origin"] = origin
                resp.headers["Access-Control-Allow-Methods"] = (
                    "GET, POST, PUT, PATCH, DELETE, OPTIONS"
                )
                resp.headers["Access-Control-Allow-Headers"] = _CORS_ALLOW_HEADERS
                resp.headers["Access-Control-Allow-Credentials"] = "true"
                resp.headers["Access-Control-Max-Age"] = "3600"
            # Always set Vary so caches don't serve cross-origin responses to
            # same-origin requests (and vice versa).
            resp.headers["Vary"] = "Origin"
            return resp

        resp = await handler(request)
        if origin in origins:
            resp.headers["Access-Control-Allow-Origin"] = origin
            resp.headers["Access-Control-Allow-Headers"] = _CORS_ALLOW_HEADERS
            resp.headers["Access-Control-Allow-Credentials"] = "true"
        # Vary header prevents cache poisoning when responses differ by Origin.
        resp.headers["Vary"] = "Origin"
        return resp

    return cors_middleware


class ApiServer:
    """WebSocket API server for direct app connections.

    Provides the same orchestrator access as Telegram, without Telegram.
    All handler wiring is done via setter methods so the server module
    has zero imports from the orchestrator (no coupling).
    """

    def __init__(
        self,
        config: ApiConfig,
        *,
        default_chat_id: int = 0,
        lock_pool: LockPool | None = None,
    ) -> None:
        self._config = config
        self._default_chat_id = default_chat_id
        self._handle_message: StreamingMessageHandler | None = None
        self._handle_abort: AbortHandler | None = None
        self._runner: web.AppRunner | None = None
        self._lock_pool = lock_pool if lock_pool is not None else LockPool()
        self._active_ws: set[web.WebSocketResponse] = set()
        self._admin_ws: set[web.WebSocketResponse] = set()
        # Per-admin-WS allowed_agents (empty list = no ACL / sees everything).
        self._admin_ws_allowed: dict[web.WebSocketResponse, list[str]] = {}
        self._ws_id_counter: int = 0  # monotonic counter for unique admin WS session IDs
        self._jwt_auth = JWTAuth(config)
        # Per-IP rate limiter for WebSocket auth failures
        self._ws_auth_failures: dict[str, list[float]] = {}
        # File context (set via set_file_context)
        self._allowed_roots: Sequence[Path] | None = None
        self._upload_dir: Path | None = None
        self._workspace: Path | None = None
        self._provider_info: list[dict[str, object]] = []
        self._active_state_getter: Callable[[], tuple[str, str]] | None = None
        # Admin WS multi-agent support (set via set_agent_resolver)
        self._resolve_agent: Callable[[str], Any] | None = None
        self._list_agents: Callable[[], list[str]] | None = None

    # -- Handler wiring --------------------------------------------------------

    def set_message_handler(self, handler: StreamingMessageHandler) -> None:
        """Orchestrator.handle_message_streaming (bound method)."""
        self._handle_message = handler

    def set_abort_handler(self, handler: AbortHandler) -> None:
        """Orchestrator.abort (bound method)."""
        self._handle_abort = handler

    def set_file_context(
        self,
        *,
        allowed_roots: Sequence[Path] | None,
        upload_dir: Path,
        workspace: Path,
    ) -> None:
        """Configure file download/upload paths."""
        self._allowed_roots = allowed_roots
        self._upload_dir = upload_dir
        self._workspace = workspace

    def set_provider_info(self, providers: list[dict[str, object]]) -> None:
        """Set the list of authenticated providers for auth_ok responses."""
        self._provider_info = providers

    def set_active_state_getter(self, getter: Callable[[], tuple[str, str]]) -> None:
        """Set a callback that returns (active_provider, active_model)."""
        self._active_state_getter = getter

    def set_agent_resolver(
        self,
        resolver: Callable[[str], Any],
        list_agents: Callable[[], list[str]],
    ) -> None:
        """Set callbacks for multi-agent admin WS endpoint.

        *resolver* maps an agent name to its AgentStack (or None).
        *list_agents* returns all registered agent names.
        """
        self._resolve_agent = resolver
        self._list_agents = list_agents

    def _lookup_session_override(self, session_id: str) -> tuple[str, str] | None:
        """Read chat_sessions.json and return ``(provider, model)`` override or None."""
        import os
        import re

        if not re.fullmatch(r"[a-zA-Z0-9_-]+", session_id or ""):
            return None
        home = Path(os.environ.get("SYGEN_HOME", Path.home() / ".sygen"))
        path = home / "chat_sessions.json"
        try:
            data = json.loads(path.read_text("utf-8"))
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return None
        sessions = (data or {}).get("sessions", []) if isinstance(data, dict) else []
        for s in sessions:
            if not isinstance(s, dict) or s.get("id") != session_id:
                continue
            provider = s.get("provider_override")
            model = s.get("model_override")
            if not isinstance(provider, str) or not provider:
                return None
            model_str = model if isinstance(model, str) else ""
            return provider, model_str
        return None

    # -- Notification broadcast ----------------------------------------------------

    async def broadcast_notification(self, notification: dict[str, Any]) -> None:
        """Push a notification to all connected admin WebSocket clients.

        Each connection is filtered by its ``allowed_agents`` ACL: a subscriber
        only receives events whose ``agent`` field is in its allow-list
        (or when it has no ACL, meaning admin-wide visibility).
        """
        payload = json.dumps({"type": "notification", "data": notification})
        event_agent = notification.get("agent", "")
        closed: list[web.WebSocketResponse] = []
        for ws in self._admin_ws:
            if ws.closed:
                closed.append(ws)
                continue
            allowed = self._admin_ws_allowed.get(ws) or []
            if allowed and event_agent and event_agent not in allowed:
                continue
            try:
                await ws.send_str(payload)
            except (ConnectionResetError, ConnectionError):
                closed.append(ws)
        for ws in closed:
            self._admin_ws.discard(ws)
            self._admin_ws_allowed.pop(ws, None)

    # -- WebSocket auth rate limiting ---------------------------------------------

    def _ws_auth_rate_limited(self, ip: str) -> bool:
        """Return True if this IP has too many recent WS auth failures."""
        import time as _time

        now = _time.monotonic()
        cutoff = now - _WS_AUTH_RATE_WINDOW
        attempts = self._ws_auth_failures.get(ip, [])
        attempts = [t for t in attempts if t > cutoff]
        self._ws_auth_failures[ip] = attempts
        return len(attempts) >= _WS_AUTH_RATE_MAX

    def _ws_auth_record_failure(self, ip: str) -> None:
        """Record a failed WS auth attempt for rate limiting."""
        import time as _time

        self._ws_auth_failures.setdefault(ip, []).append(_time.monotonic())

    # -- JWT/Bearer verification for HTTP endpoints (#14) ----------------------

    def _verify_request_auth(self, request: web.Request) -> dict[str, Any] | None:
        """Verify JWT from cookie, Bearer header, or legacy static token.

        Cookie (``sygen_access``) is preferred — set by the login flow.
        Authorization: Bearer is kept for CLI / Telegram clients that don't
        persist cookies. ``?token=`` query fallback was removed to prevent
        token leakage via URLs, referers, and server logs.
        """
        from sygen_bot.api.auth import COOKIE_ACCESS  # local import avoids cycle

        cookie_token = request.cookies.get(COOKIE_ACCESS, "")
        auth = request.headers.get("Authorization", "")
        bearer_token = auth[7:] if auth.startswith("Bearer ") else ""
        raw_token = bearer_token or cookie_token
        if not raw_token:
            return None
        # Try legacy static token
        if self._config.token and hmac.compare_digest(raw_token, self._config.token):
            ip = request.remote or "unknown"
            logger.warning(
                "legacy static admin token used from %s (path=%s)",
                ip, request.path,
            )
            try:
                from sygen_bot.api.auth import write_audit as _audit
                _audit(
                    user="legacy_admin",
                    action="legacy_token_auth",
                    target=request.path,
                    details=f"ip={ip} method={request.method}",
                )
            except Exception:
                pass
            return {"sub": "legacy", "role": "admin"}
        # Try JWT
        try:
            return self._jwt_auth.decode(raw_token, expected_type="access")
        except Exception:
            return None

    # -- Lifecycle -------------------------------------------------------------

    async def start(self) -> None:
        """Create the aiohttp app and start listening."""
        if not _detect_tailscale() and not self._config.allow_public:
            logger.warning(
                "API server: Tailscale NOT detected. Your API may be exposed "
                "to the public internet on %s:%d. Install Tailscale for secure "
                "private networking, or set api.allow_public=true in config to "
                "acknowledge this risk.",
                self._config.host,
                self._config.port,
            )

        # Build CORS origins from config or default
        cors_origins = getattr(self._config, "cors_origins", None)
        admin_url = getattr(self._config, "admin_url", "") or ""
        cors_extra = list(getattr(self._config, "cors_extra", []) or [])
        cors_middleware = _make_cors_middleware(
            cors_origins, admin_url=admin_url, cors_extra=cors_extra,
        )

        app = web.Application(
            client_max_size=_MAX_UPLOAD_BYTES,
            middlewares=[
                _security_headers_middleware,
                cors_middleware,
                self._jwt_auth.middleware,
            ],
        )
        self._jwt_auth.register_routes(app)
        app.router.add_get("/health", self._handle_health)
        app.router.add_get("/ws", self._handle_websocket)
        app.router.add_get("/ws/admin", self._handle_ws_admin)
        app.router.add_get("/files", self._handle_file_download)
        app.router.add_get("/api/files/download", self._handle_file_download)
        app.router.add_post("/upload", self._handle_file_upload)

        # Expose agent resolver to REST routes for online status.
        # Use lambdas so the app always calls the current callback
        # (set_agent_resolver is called after start).
        app["resolve_agent"] = lambda name: self._resolve_agent(name) if self._resolve_agent else None
        app["list_agents"] = lambda: self._list_agents() if self._list_agents else []
        app["broadcast_notification"] = self.broadcast_notification

        from sygen_bot.api.rest_routes import setup_rest_routes

        setup_rest_routes(app)

        self._runner = web.AppRunner(app, access_log=None)
        await self._runner.setup()
        site = web.TCPSite(self._runner, self._config.host, self._config.port)
        await site.start()
        logger.info(
            "API server listening on %s:%d",
            self._config.host,
            self._config.port,
        )

    async def stop(self) -> None:
        """Close all connections and shut down the server."""
        for ws in list(self._active_ws):
            await ws.close(
                code=aiohttp.WSCloseCode.GOING_AWAY,
                message=b"server shutdown",
            )
        self._active_ws.clear()
        self._admin_ws.clear()
        self._admin_ws_allowed.clear()
        if self._runner:
            await self._runner.cleanup()
            self._runner = None
        logger.info("API server stopped")

    # -- HTTP handlers ---------------------------------------------------------

    async def _handle_health(self, _request: web.Request) -> web.Response:
        return web.json_response(
            {
                "status": "ok",
                "connections": len(self._active_ws),
            }
        )

    async def _handle_file_download(self, request: web.Request) -> web.StreamResponse:
        """Serve a file from the filesystem.

        Supports three auth modes (first match wins):
          - Signed URL (``?agent=X&relative_path=Y&exp=Z&sig=W``) — bypasses JWT.
          - JWT cookie or Authorization header.
          - Legacy static bearer token.

        Supports two query shapes:
          - ``?agent=<name>&relative_path=<rel>`` — resolved in that agent's workspace
            and ACL-checked against the caller's ``allowed_agents``.
          - ``?path=<abs>`` — legacy absolute path (no per-agent ACL).
        """
        from sygen_bot.api.auth import verify_signed_url

        agent = request.query.get("agent", "")
        rel_path = request.query.get("relative_path", "")
        exp = request.query.get("exp", "")
        sig = request.query.get("sig", "")

        signed_ok = False
        if agent and rel_path and exp and sig:
            signed_ok = verify_signed_url(
                self._jwt_auth._secret,
                agent=agent,
                relative_path=rel_path,
                exp=exp,
                sig=sig,
            )

        if signed_ok:
            user_info = {"sub": "signed_url", "role": "viewer", "allowed_agents": [agent]}
        else:
            user_info = self._verify_request_auth(request)
            if user_info is None:
                return web.json_response({"error": "unauthorized"}, status=401)

        if agent and rel_path:
            from sygen_bot.api.rest_routes import (
                _AGENT_NAME_RE,
                _fm_resolve_workspace,
            )

            if not _AGENT_NAME_RE.match(agent):
                return web.json_response({"error": "invalid agent name"}, status=400)
            allowed_agents: list[str] = user_info.get("allowed_agents", []) or []
            if allowed_agents and agent not in allowed_agents:
                return web.json_response({"error": f"agent '{agent}' not found"}, status=404)

            workspace = _fm_resolve_workspace(agent)
            if workspace is None:
                return web.json_response(
                    {"error": f"workspace for agent '{agent}' not found"},
                    status=404,
                )
            if ".." in rel_path or rel_path.startswith("/"):
                return web.json_response({"error": "invalid path"}, status=400)

            target = workspace / rel_path
            try:
                resolved = target.resolve()
                if not resolved.is_relative_to(workspace.resolve()):
                    return web.json_response(
                        {"error": "path outside workspace"}, status=403,
                    )
            except (ValueError, OSError):
                return web.json_response({"error": "invalid path"}, status=400)
            file_path = target
        else:
            raw_path = request.query.get("path", "")
            if not raw_path:
                return web.json_response(
                    {"error": "missing 'path' query parameter"}, status=400,
                )

            file_path = Path(raw_path)
            if self._allowed_roots is not None and not is_path_safe(file_path, self._allowed_roots):
                return web.json_response({"error": "path outside allowed roots"}, status=403)

        if not await asyncio.to_thread(file_path.is_file):
            return web.json_response({"error": "file not found"}, status=404)

        mime = guess_mime(file_path)
        return web.FileResponse(file_path, headers={"Content-Type": mime})

    async def _handle_file_upload(self, request: web.Request) -> web.Response:
        """Accept a multipart file upload and return the saved path + prompt."""
        # Accept JWT or legacy Bearer (#14)
        user_info = self._verify_request_auth(request)
        if user_info is None:
            return web.json_response({"error": "unauthorized"}, status=401)

        # Optional per-agent ACL + file-manager routing:
        # - ?agent=<name> (or form field) must be in caller's allowed_agents
        # - ?relative_path=<rel> routes the upload into the agent workspace
        from sygen_bot.api.rest_routes import (
            _AGENT_NAME_RE,
            _fm_resolve_workspace,
            _fm_rel_is_hidden,
        )

        agent = request.query.get("agent", "")
        rel_path = request.query.get("relative_path", "") or request.query.get("subpath", "")

        if agent:
            if not _AGENT_NAME_RE.match(agent):
                return web.json_response({"error": "invalid agent name"}, status=400)
            allowed_agents: list[str] = user_info.get("allowed_agents", []) or []
            if allowed_agents and agent not in allowed_agents:
                return web.json_response(
                    {"error": f"agent '{agent}' not found"}, status=404,
                )

        fm_target_dir: Path | None = None
        if agent:
            workspace = _fm_resolve_workspace(agent)
            if workspace is None:
                return web.json_response(
                    {"error": f"workspace for agent '{agent}' not found"},
                    status=404,
                )
            if rel_path:
                if ".." in rel_path or rel_path.startswith("/"):
                    return web.json_response({"error": "invalid path"}, status=400)
                if _fm_rel_is_hidden(rel_path):
                    return web.json_response({"error": "path is not accessible"}, status=403)
                fm_target_dir = workspace / rel_path
            else:
                fm_target_dir = workspace
            try:
                if not fm_target_dir.resolve().is_relative_to(workspace.resolve()):
                    return web.json_response(
                        {"error": "path outside workspace"}, status=403,
                    )
            except (ValueError, OSError):
                return web.json_response({"error": "invalid path"}, status=400)
            if not fm_target_dir.is_dir():
                return web.json_response({"error": "target directory not found"}, status=404)

        if fm_target_dir is None and (self._upload_dir is None or self._workspace is None):
            return web.json_response({"error": "file uploads not configured"}, status=503)

        try:
            reader = await request.multipart()
        except ValueError:
            return web.json_response({"error": "multipart body required"}, status=400)

        field = await reader.next()
        if not isinstance(field, BodyPartReader) or field.name != "file":
            return web.json_response({"error": "expected a 'file' field"}, status=400)

        raw_name = field.filename or "upload"
        safe_name = sanitize_filename(raw_name)

        if fm_target_dir is not None:
            dest = fm_target_dir / safe_name
            if dest.exists():
                stem, suffix = dest.stem, dest.suffix
                counter = 1
                while dest.exists():
                    dest = fm_target_dir / f"{stem}_{counter}{suffix}"
                    counter += 1
        else:
            dest = await asyncio.to_thread(prepare_destination, self._upload_dir, safe_name)

        total = 0
        with dest.open("wb") as f:
            while True:
                chunk = await field.read_chunk(65536)
                if not chunk:
                    break
                total += len(chunk)
                if total > _MAX_UPLOAD_BYTES:
                    dest.unlink(missing_ok=True)
                    return web.json_response(
                        {"error": f"file exceeds {_MAX_UPLOAD_BYTES // (1024 * 1024)} MB limit"},
                        status=413,
                    )
                f.write(chunk)

        # Detect actual MIME from saved file content (magic bytes + extension fallback)
        mime = await asyncio.to_thread(guess_mime, dest)

        # Prefer browser-provided MIME when it's more specific (e.g. audio/webm vs video/webm)
        browser_mime = (field.headers.get("Content-Type") or "").split(";")[0].strip()
        if browser_mime and mime == "video/webm" and browser_mime.startswith("audio/"):
            mime = "audio/webm"

        # File-manager uploads land in an agent workspace — preserve bytes as-is
        # (no webm→ogg conversion, no image re-encoding, no media-prompt build).
        if fm_target_dir is not None:
            try:
                rel_saved = str(dest.relative_to(workspace))
            except ValueError:
                rel_saved = dest.name
            logger.info(
                "API upload (fm): %s → %s/%s (%s, %d bytes)",
                dest.name, agent, rel_saved, mime, total,
            )
            return web.json_response(
                {
                    "path": rel_saved,
                    "name": dest.name,
                    "mime": mime,
                    "size": total,
                    "agent": agent,
                }
            )

        # Convert admin voice recordings (voice_<ts>.{webm,ogg,m4a,mp4}) to MP3
        # so playback works on every browser/OS (iOS Safari refuses Ogg/Opus
        # and some WebM/Opus streams). Non-voice audio is left untouched.
        import re as _re
        if _re.match(r"^voice_\d+\.(webm|ogg|m4a|mp4)$", dest.name, _re.I):
            dest = await asyncio.to_thread(self._convert_voice_to_mp3, dest)
            if dest.suffix == ".mp3":
                mime = "audio/mpeg"

        # Convert audio/webm to ogg (whisper.cpp handles ogg much better)
        if mime == "audio/webm" and dest.suffix == ".webm":
            dest = await asyncio.to_thread(self._convert_webm_to_ogg, dest)
            if dest.suffix == ".ogg":
                mime = "audio/ogg"

        dest = await asyncio.to_thread(process_image, dest)
        if dest.suffix == ".webp":
            mime = "image/webp"

        # Read optional caption from a second multipart field
        caption: str | None = None
        next_field = await reader.next()
        if isinstance(next_field, BodyPartReader) and next_field.name == "caption":
            caption = (await next_field.read(decode=True)).decode("utf-8", errors="replace")

        info = MediaInfo(
            path=dest,
            media_type=mime,
            file_name=dest.name,
            caption=caption,
            original_type=classify_mime(mime),
        )
        prompt = build_media_prompt(info, self._workspace, transport="API")

        logger.info("API upload: %s (%s, %d bytes)", dest.name, mime, total)
        return web.json_response(
            {
                "path": str(dest),
                "name": dest.name,
                "mime": mime,
                "size": total,
                "prompt": prompt,
            }
        )

    @staticmethod
    def _convert_webm_to_ogg(path: Path) -> Path:
        """Convert audio webm to ogg for better whisper compatibility."""
        import shutil
        import subprocess

        if not shutil.which("ffmpeg"):
            return path
        ogg_path = path.with_suffix(".ogg")
        try:
            subprocess.run(
                ["ffmpeg", "-y", "-v", "quiet", "-i", str(path),
                 "-c:a", "libopus", str(ogg_path)],
                capture_output=True, timeout=30, check=True,
            )
        except Exception:
            ogg_path.unlink(missing_ok=True)
            return path
        path.unlink(missing_ok=True)
        return ogg_path

    @staticmethod
    def _convert_voice_to_mp3(path: Path) -> Path:
        """Transcode an admin voice recording to MP3 for universal playback.

        iOS Safari cannot decode Ogg/Opus or WebM/Opus; MP3 plays on every
        modern browser/OS. If ffmpeg is missing or fails, return the original
        path so the user does not lose their recording.
        """
        import shutil
        import subprocess

        if not shutil.which("ffmpeg"):
            return path
        mp3_path = path.with_suffix(".mp3")
        try:
            subprocess.run(
                ["ffmpeg", "-y", "-v", "error", "-i", str(path),
                 "-vn", "-acodec", "libmp3lame", "-ab", "64k", str(mp3_path)],
                capture_output=True, timeout=30, check=True,
            )
        except Exception as exc:
            logger.warning("voice→mp3 transcode failed for %s: %s", path.name, exc)
            mp3_path.unlink(missing_ok=True)
            return path
        path.unlink(missing_ok=True)
        return mp3_path

    # -- WebSocket handlers ----------------------------------------------------

    async def _handle_websocket(
        self,
        request: web.Request,
    ) -> web.WebSocketResponse:
        remote_ip = request.remote or "unknown"

        # Rate-limit check before accepting the connection
        if self._ws_auth_rate_limited(remote_ip):
            ws = web.WebSocketResponse()
            await ws.prepare(request)
            await _ws_reject(ws, "rate_limited", "Too many failed auth attempts")
            return ws

        # Check WS connection limit (#8)
        if len(self._active_ws) >= _MAX_WS_CONNECTIONS:
            ws = web.WebSocketResponse()
            await ws.prepare(request)
            await _ws_reject(ws, "too_many_connections", f"Max {_MAX_WS_CONNECTIONS} connections reached")
            return ws

        ws = web.WebSocketResponse(heartbeat=30.0, max_msg_size=_MAX_WS_MSG_SIZE)
        await ws.prepare(request)
        logger.info("API WebSocket opened from %s", remote_ip)

        auth_result = await self._authenticate(ws, remote_ip=remote_ip)
        if auth_result is None:
            return ws

        key, e2e = auth_result
        channel = _SecureChannel(ws, e2e)

        self._active_ws.add(ws)
        try:
            await self._session_loop(channel, key)
        except asyncio.CancelledError:
            pass
        finally:
            self._active_ws.discard(ws)
            logger.info("API WebSocket closed key=%s", key.storage_key)

        return ws

    # -- Authentication --------------------------------------------------------

    async def _read_auth_message(self, ws: web.WebSocketResponse) -> dict[str, object] | None:
        """Read and validate the initial auth message. Returns parsed data or None."""
        try:
            raw = await asyncio.wait_for(ws.receive(), timeout=10.0)
        except (TimeoutError, asyncio.CancelledError):
            await _ws_reject(ws, "auth_timeout", "No auth message within 10 s")
            return None

        if raw.type != WSMsgType.TEXT:
            await _ws_reject(ws, "auth_required", "First message must be JSON text")
            return None

        try:
            data = json.loads(raw.data)
        except (json.JSONDecodeError, ValueError):
            data = None
        if not isinstance(data, dict) or data.get("type") != "auth":
            await _ws_reject(ws, "auth_required", "First message must be auth JSON")
            return None

        return data

    async def _authenticate(
        self,
        ws: web.WebSocketResponse,
        *,
        remote_ip: str = "unknown",
    ) -> tuple[SessionKey, E2ESession] | None:
        """Wait for auth + E2E key exchange.  Returns (key, e2e) or None."""
        data = await self._read_auth_message(ws)
        if data is None:
            return None

        token = str(data.get("token", ""))
        if not hmac.compare_digest(token, self._config.token):
            logger.warning("API auth failed (invalid token) from %s", remote_ip)
            self._ws_auth_record_failure(remote_ip)
            await _ws_reject(ws, "auth_failed", "Invalid token")
            return None

        # E2E key exchange (mandatory)
        from sygen_bot.api.crypto import E2ESession  # noqa: F811 — lazy import, nacl is optional
        e2e = E2ESession()
        e2e_pk = data.get("e2e_pk")
        e2e_valid = isinstance(e2e_pk, str) and bool(e2e_pk)
        if e2e_valid:
            try:
                assert isinstance(e2e_pk, str)
                e2e.set_remote_key(e2e_pk)
            except Exception:
                e2e_valid = False
        if not e2e_valid:
            await _ws_reject(ws, "auth_failed", "e2e_pk required or invalid")
            return None

        chat_id = data.get("chat_id", self._default_chat_id)
        if not isinstance(chat_id, int) or chat_id <= 0:
            chat_id = self._default_chat_id

        # Optional channel_id for per-channel session isolation (maps to topic_id)
        channel_id = data.get("channel_id")
        if not isinstance(channel_id, int) or channel_id <= 0:
            channel_id = None

        key = SessionKey(chat_id=chat_id, topic_id=channel_id)

        # Last plaintext message -- everything after this is E2E encrypted
        auth_ok_payload: dict[str, object] = {
            "type": "auth_ok",
            "chat_id": chat_id,
            "e2e_pk": e2e.local_pk_b64,
            "providers": self._provider_info,
        }
        if channel_id is not None:
            auth_ok_payload["channel_id"] = channel_id
        if self._active_state_getter:
            active_provider, active_model = self._active_state_getter()
            auth_ok_payload["active_provider"] = active_provider
            auth_ok_payload["active_model"] = active_model
        await _ws_send(ws, auth_ok_payload)
        logger.info("API client authenticated key=%s (E2E)", key.storage_key)
        return key, e2e

    # -- Session loop ----------------------------------------------------------

    async def _session_loop(
        self,
        channel: _SecureChannel,
        key: SessionKey,
    ) -> None:
        """Read encrypted messages from the client and dispatch them sequentially."""
        lock = self._lock_pool.get(key.lock_key)
        set_log_context(operation="api", chat_id=key.chat_id)

        async for raw in channel.ws:
            if raw.type == WSMsgType.TEXT:
                await self._route_text_message(channel, raw.data, key, lock)
            elif raw.type in (WSMsgType.ERROR, WSMsgType.CLOSE):
                break

    async def _route_text_message(
        self,
        channel: _SecureChannel,
        raw_data: str,
        key: SessionKey,
        lock: asyncio.Lock,
    ) -> None:
        """Decrypt and route a single encrypted text frame."""
        try:
            data = channel.decrypt(raw_data)
        except Exception:
            logger.warning("E2E decryption failed key=%s", key.storage_key)
            await channel.send(
                {
                    "type": "error",
                    "code": "decrypt_failed",
                    "message": "Decryption failed",
                },
            )
            return

        msg_type = str(data.get("type", ""))

        if msg_type == "message":
            text = str(data.get("text", "")).strip()
            if not text:
                await channel.send(
                    {
                        "type": "error",
                        "code": "empty",
                        "message": "Empty message",
                    },
                )
                return
            # Intercept /stop since the orchestrator doesn't handle it
            if text.lower() == "/stop":
                await self._dispatch_abort(channel, key.chat_id)
                return
            async with lock:
                set_log_context(operation="api", chat_id=key.chat_id)
                await self._dispatch_message(channel, key, text)

        elif msg_type == "abort":
            await self._dispatch_abort(channel, key.chat_id)

        else:
            await channel.send(
                {
                    "type": "error",
                    "code": "unknown_type",
                    "message": f"Unknown message type: {msg_type}",
                },
            )

    # -- Dispatch --------------------------------------------------------------

    async def _dispatch_message(
        self,
        channel: _SecureChannel,
        key: SessionKey,
        text: str,
    ) -> None:
        """Route a message through the orchestrator with encrypted streaming callbacks."""
        if not self._handle_message:
            await channel.send(
                {
                    "type": "error",
                    "code": "no_handler",
                    "message": "Message handler not configured",
                },
            )
            return

        callbacks = _StreamCallbacks(channel)
        result = await self._execute_streaming(key, text, callbacks)
        if result is None:
            return

        if callbacks.disconnected:
            logger.info(
                "API client disconnected mid-stream, aborting key=%s",
                key.storage_key,
            )
            if self._handle_abort:
                await self._handle_abort(key.chat_id)
            return

        # Parse file references from the response for the app
        files = _parse_file_refs(result.text)

        await channel.send(
            {
                "type": "result",
                "text": result.text,
                "stream_fallback": result.stream_fallback,
                "files": files,
            },
        )

    async def _execute_streaming(
        self,
        key: SessionKey,
        text: str,
        callbacks: _StreamCallbacks,
    ) -> Any:
        """Call the orchestrator handler, return result or None on error."""
        assert self._handle_message is not None
        try:
            return await self._handle_message(
                key,
                text,
                on_text_delta=callbacks.on_text,
                on_tool_activity=callbacks.on_tool,
                on_system_status=callbacks.on_system,
            )
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("API dispatch error key=%s", key.storage_key)
            await callbacks.channel.send(
                {
                    "type": "error",
                    "code": "internal_error",
                    "message": "An internal error occurred",
                },
            )
            return None

    async def _dispatch_abort(
        self,
        channel: _SecureChannel,
        chat_id: int,
    ) -> None:
        """Abort running CLI processes for this chat."""
        killed = 0
        if self._handle_abort:
            killed = await self._handle_abort(chat_id)
        await channel.send({"type": "abort_ok", "killed": killed})

    # -- Admin WebSocket (no E2E, JWT auth, multi-agent) -----------------------

    async def _handle_ws_admin(self, request: web.Request) -> web.WebSocketResponse:
        """Simplified WebSocket for the admin dashboard.

        No E2E encryption — auth via JWT/Bearer token in first message.
        Supports routing messages to any registered agent.
        """
        remote_ip = request.remote or "unknown"

        # Rate-limit check before accepting the connection
        if self._ws_auth_rate_limited(remote_ip):
            ws = web.WebSocketResponse()
            await ws.prepare(request)
            await _ws_reject(ws, "rate_limited", "Too many failed auth attempts")
            return ws

        # Check WS connection limit (#8)
        if len(self._active_ws) >= _MAX_WS_CONNECTIONS:
            ws = web.WebSocketResponse()
            await ws.prepare(request)
            await _ws_reject(ws, "too_many_connections", f"Max {_MAX_WS_CONNECTIONS} connections reached")
            return ws

        ws = web.WebSocketResponse(heartbeat=30.0, max_msg_size=_MAX_WS_MSG_SIZE)
        await ws.prepare(request)
        logger.info("Admin WS opened from %s", remote_ip)

        # Wait for auth message
        auth_data = await self._read_auth_message(ws)
        if auth_data is None:
            return ws

        token = str(auth_data.get("token", ""))
        # E1: fall back to httpOnly cookie sent during the WS handshake when
        # the client didn't pass a token in the auth frame (same-origin admin).
        if not token:
            token = request.cookies.get("sygen_access", "")

        # Validate token: try legacy Bearer first, then JWT
        user_info: dict[str, Any] | None = None
        if self._config.token and token and hmac.compare_digest(token, self._config.token):
            user_info = {"sub": "legacy", "role": "admin"}
        else:
            try:
                user_info = self._jwt_auth.decode(token, expected_type="access")
            except Exception:
                pass

        if user_info is None:
            logger.warning("Admin WS auth failed (invalid token) from %s", remote_ip)
            self._ws_auth_record_failure(remote_ip)
            await _ws_reject(ws, "auth_failed", "Invalid token")
            return ws

        # Check role: viewer is read-only (no message sending) (#3)
        user_role = user_info.get("role", "viewer")
        user_role_level = ROLE_LEVELS.get(user_role, 0)

        # Build agent list (filtered by allowed_agents if set)
        agents = self._list_agents() if self._list_agents else []
        allowed_agents: list[str] = user_info.get("allowed_agents", [])
        if allowed_agents:
            agents = [a for a in agents if a in allowed_agents]

        await _ws_send(ws, {"type": "auth_ok", "agents": agents, "role": user_role})
        logger.info("Admin WS authenticated user=%s role=%s", user_info.get("sub", "?"), user_role)

        self._active_ws.add(ws)
        self._admin_ws.add(ws)
        self._admin_ws_allowed[ws] = list(allowed_agents)
        # Assign a unique session ID for this admin WS connection so it gets
        # its own CLI session (separate from Telegram).
        self._ws_id_counter += 1
        ws_session_id = self._ws_id_counter
        # Track active orchestrator sessions for this admin client (#16)
        active_agent_sessions: set[str] = set()
        try:
            await self._admin_session_loop(ws, user_info, user_role_level, active_agent_sessions, ws_session_id)
        except asyncio.CancelledError:
            pass
        finally:
            # Abort all active orchestrator sessions on disconnect (#16)
            for agent_name in active_agent_sessions:
                try:
                    await self._admin_dispatch_abort(ws, agent_name, silent=True, ws_session_id=ws_session_id)
                except Exception:
                    logger.debug("Failed to abort agent %s on admin disconnect", agent_name)
            self._active_ws.discard(ws)
            self._admin_ws.discard(ws)
            self._admin_ws_allowed.pop(ws, None)
            logger.info("Admin WS closed user=%s", user_info.get("sub", "?"))

        return ws

    async def _admin_session_loop(
        self,
        ws: web.WebSocketResponse,
        user_info: dict[str, Any],
        user_role_level: int,
        active_agent_sessions: set[str],
        ws_session_id: int = 0,
    ) -> None:
        """Read plaintext messages from the admin client and dispatch them."""
        allowed_agents: list[str] = user_info.get("allowed_agents", [])

        async for raw in ws:
            if raw.type == WSMsgType.TEXT:
                try:
                    data = json.loads(raw.data)
                except (json.JSONDecodeError, ValueError):
                    await _ws_send(ws, {"type": "error", "message": "Invalid JSON"})
                    continue

                msg_type = str(data.get("type", ""))

                if msg_type == "message":
                    # Viewer role cannot send messages (#3)
                    if user_role_level < ROLE_LEVELS.get("operator", 1):
                        await _ws_send(
                            ws,
                            {"type": "error", "message": "Insufficient permissions: viewer role is read-only"},
                        )
                        continue
                    agent_name = str(data.get("agent", "main"))
                    # Enforce allowed_agents restriction
                    if allowed_agents and agent_name not in allowed_agents:
                        await _ws_send(
                            ws,
                            {"type": "error", "message": f"Access denied to agent '{agent_name}'"},
                        )
                        continue
                    active_agent_sessions.add(agent_name)
                    await self._admin_dispatch_message(
                        ws,
                        data,
                        ws_session_id=ws_session_id,
                        user_role=str(user_info.get("role") or "") or None,
                        user_id=str(user_info.get("username") or "") or None,
                    )
                elif msg_type == "abort":
                    # Viewer role cannot abort (#3)
                    if user_role_level < ROLE_LEVELS.get("operator", 1):
                        await _ws_send(
                            ws,
                            {"type": "error", "message": "Insufficient permissions: viewer role is read-only"},
                        )
                        continue
                    agent_name = str(data.get("agent", "main"))
                    # Enforce allowed_agents restriction
                    if allowed_agents and agent_name not in allowed_agents:
                        await _ws_send(
                            ws,
                            {"type": "error", "message": f"Access denied to agent '{agent_name}'"},
                        )
                        continue
                    await self._admin_dispatch_abort(ws, agent_name, ws_session_id=ws_session_id)
                else:
                    await _ws_send(
                        ws,
                        {"type": "error", "message": f"Unknown type: {msg_type}"},
                    )
            elif raw.type in (WSMsgType.ERROR, WSMsgType.CLOSE):
                break

    async def _admin_dispatch_message(
        self,
        ws: web.WebSocketResponse,
        data: dict[str, Any],
        *,
        ws_session_id: int = 0,
        user_role: str | None = None,
        user_id: str | None = None,
    ) -> None:
        """Route an admin message to the target agent's orchestrator with streaming."""
        agent_name = str(data.get("agent", "main"))
        text = str(data.get("text", "")).strip()
        raw_session_id = data.get("session_id")
        session_id = raw_session_id if isinstance(raw_session_id, str) else None

        if not text:
            await _ws_send(ws, {"type": "error", "message": "Empty message"})
            return

        # Apply per-chat-session provider/model override by prepending an
        # @<model> directive so the orchestrator's directive parser picks it up.
        if session_id:
            override = self._lookup_session_override(session_id)
            if override is not None:
                provider, model = override
                directive_key = model or provider
                if directive_key and not text.lstrip().startswith("@"):
                    text = f"@{directive_key} {text}"

        if not self._resolve_agent:
            await _ws_send(
                ws,
                {"type": "error", "message": "Agent routing not configured"},
            )
            return

        stack = self._resolve_agent(agent_name)
        if stack is None:
            available = self._list_agents() if self._list_agents else []
            await _ws_send(
                ws,
                {
                    "type": "error",
                    "message": f"Agent '{agent_name}' not found. Available: {', '.join(available)}",
                },
            )
            return

        orch = stack.bot.orchestrator
        if orch is None:
            await _ws_send(
                ws,
                {"type": "error", "message": f"Agent '{agent_name}' orchestrator not ready"},
            )
            return

        # Build a unique session key for this admin WS connection.
        # Use transport="api" with a distinct chat_id so admin WS gets its own
        # CLI session, separate from Telegram conversations.
        key = SessionKey(transport="api", chat_id=ws_session_id)

        # Streaming callbacks that send plaintext JSON to the admin WS
        disconnected = False

        async def on_text(delta: str) -> None:
            nonlocal disconnected
            if disconnected or ws.closed:
                disconnected = True
                return
            ok = await _ws_send(ws, {"type": "text_delta", "text": delta})
            if not ok:
                disconnected = True

        async def on_tool(name: str) -> None:
            nonlocal disconnected
            if disconnected or ws.closed:
                disconnected = True
                return
            name = normalize_tool_name(name)
            ok = await _ws_send(ws, {"type": "tool_activity", "tool": name})
            if not ok:
                disconnected = True

        async def on_system(label: str | None) -> None:
            nonlocal disconnected
            if disconnected or ws.closed:
                disconnected = True
                return
            ok = await _ws_send(ws, {"type": "system_status", "data": label})
            if not ok:
                disconnected = True

        try:
            result = await orch.handle_message_streaming(
                key,
                text,
                on_text_delta=on_text,
                on_tool_activity=on_tool,
                on_system_status=on_system,
                user_role=user_role,
                user_id=user_id,
            )
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Admin WS dispatch error agent=%s", agent_name)
            await _ws_send(
                ws,
                {"type": "error", "message": "An internal error occurred"},
            )
            return

        if disconnected:
            logger.info("Admin WS client disconnected mid-stream agent=%s", agent_name)
            return

        if result is not None:
            files = _parse_file_refs(result.text)
            await _ws_send(
                ws,
                {
                    "type": "result",
                    "text": result.text,
                    "files": files,
                },
            )

    async def _admin_dispatch_abort(
        self,
        ws: web.WebSocketResponse,
        agent_name: str,
        *,
        silent: bool = False,
        ws_session_id: int = 0,
    ) -> None:
        """Abort running processes for a specific agent."""
        if not self._resolve_agent:
            if not silent:
                await _ws_send(ws, {"type": "error", "message": "Agent routing not configured"})
            return

        stack = self._resolve_agent(agent_name)
        if stack is None:
            if not silent:
                await _ws_send(ws, {"type": "error", "message": f"Agent '{agent_name}' not found"})
            return

        orch = stack.bot.orchestrator
        killed = 0
        if orch is not None:
            # Use the WS session ID if provided, fall back to default chat_id
            abort_id = ws_session_id if ws_session_id else self._default_chat_id
            killed = await orch.abort(abort_id)

        if not silent:
            await _ws_send(ws, {"type": "abort_ok", "killed": killed})
