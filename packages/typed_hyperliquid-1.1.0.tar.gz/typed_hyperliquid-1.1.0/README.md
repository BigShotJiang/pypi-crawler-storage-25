<p align="center">
  <a href="https://hyperliquid.tribulnation.com">
    <picture>
      <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/tribulnation/hyperliquid/refs/heads/main/media/hyperliquid-dark.svg">
      <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/tribulnation/hyperliquid/refs/heads/main/media/hyperliquid-light.svg">
      <img alt="Typed Hyperliquid" src="https://raw.githubusercontent.com/tribulnation/hyperliquid/refs/heads/main/media/hyperliquid-light.svg" width="520">
    </picture>
  </a>
</p>

<p align="center">
  <em>A fully typed, validated async client for the Hyperliquid API.</em>
</p>

<p align="center">
  <a href="https://pypi.org/project/typed-hyperliquid/">
    <img src="https://img.shields.io/pypi/v/typed-hyperliquid.svg" alt="PyPI version">
  </a>
  <a href="https://pypi.org/project/typed-hyperliquid/">
    <img src="https://img.shields.io/pypi/pyversions/typed-hyperliquid.svg" alt="Python versions">
  </a>
  <a href="https://hyperliquid.tribulnation.com/">
    <img src="https://img.shields.io/badge/docs-live-black" alt="Docs">
  </a>
  <a href="LICENSE">
    <img src="https://img.shields.io/pypi/l/typed-hyperliquid.svg" alt="License">
  </a>
</p>

---

- **Documentation**: [https://hyperliquid.tribulnation.com](https://hyperliquid.tribulnation.com)
- **Source Code**: [https://github.com/tribulnation/hyperliquid](https://github.com/tribulnation/hyperliquid)

---

```python
from hyperliquid import Hyperliquid

async with Hyperliquid.ws(public=True) as client:
  stream = await client.streams.trades('BTC')
  async for msg in stream:
    for trade in msg:
      print(trade['px'], trade['sz'], trade['side'])
```

## Why Typed Hyperliquid?

- **🎯 Precise Types**: Typed endpoint inputs and responses.
- **✅ Runtime Validation**: Validated responses by default.
- **⚡ Async First**: HTTP, WebSocket RPC, and subscriptions.
- **📚 Full API Surface**: `client.info`, `client.exchange`, and
  `client.streams`.

## Installation

```bash
pip install typed-hyperliquid
```

## How To

- [Place & Manage Orders](https://hyperliquid.tribulnation.com/how-to/place-and-manage-orders/)
- [Fetch Market Data](https://hyperliquid.tribulnation.com/how-to/fetch-market-data/)
- [Fetch Your Balances & Positions](https://hyperliquid.tribulnation.com/how-to/fetch-balances-and-positions/)
- [Fetch Your Transactions](https://hyperliquid.tribulnation.com/how-to/fetch-transactions/)
- [Listen To Your Trades](https://hyperliquid.tribulnation.com/how-to/listen-to-your-trades/)
- [Listen To Public Data](https://hyperliquid.tribulnation.com/how-to/listen-to-public-data/)

## Reference

- [Authenticated Setup](https://hyperliquid.tribulnation.com/authenticated-setup/)
- [Error Handling](https://hyperliquid.tribulnation.com/reference/error-handling/)
- [Environment Variables](https://hyperliquid.tribulnation.com/reference/env-vars/)
- [Generated API Reference](https://hyperliquid.tribulnation.com/reference/api/)
