"""Basic smoke tests for the storage layer (no real filesystem side-effects)."""

import time
import tempfile
from pathlib import Path

from clipmind.storage import db


def _tmp_db():
    f = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    f.close()
    return Path(f.name)


def test_upsert_and_search():
    p = _tmp_db()
    db.init_db(p)
    db.upsert("hello world", "clipboard", path=p)
    db.upsert("hello world", "clipboard", path=p)
    rows = db.search("hello", path=p)
    assert len(rows) == 1
    assert rows[0]["frequency"] == 2
    p.unlink(missing_ok=True)


def test_expire():
    p = _tmp_db()
    db.init_db(p)
    # Manually insert an old row
    import sqlite3, time as t
    conn = sqlite3.connect(str(p))
    conn.execute(
        "INSERT INTO history (content, type, first_seen, last_seen, frequency) VALUES (?,?,?,?,?)",
        ("old entry", "clipboard", 0, 0, 1),
    )
    conn.commit()
    conn.close()

    db.upsert("fresh entry", "clipboard", path=p)
    removed = db.expire(retention_days=30, path=p)
    assert removed == 1
    rows = db.search("", path=p)
    assert len(rows) == 1
    assert rows[0]["content"] == "fresh entry"
    p.unlink(missing_ok=True)


def test_clear():
    p = _tmp_db()
    db.init_db(p)
    db.upsert("a", "clipboard", path=p)
    db.upsert("b", "typed", path=p)
    db.pin_item(db.search("a", path=p)[0]["id"], True, path=p)
    n = db.clear(path=p)
    assert n == 1
    rows = db.search("", path=p)
    assert len(rows) == 1
    assert rows[0]["content"] == "a"
    p.unlink(missing_ok=True)
