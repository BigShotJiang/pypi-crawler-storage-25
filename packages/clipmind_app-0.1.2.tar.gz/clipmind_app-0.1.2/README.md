# ClipMind

Smart clipboard & typing history tool. Runs as a background daemon, captures everything you copy (and later, type), and lets you fuzzy-search it all from a global hotkey.

## Quick install

```bash
# From the project directory
pip install .

# Or isolated (recommended)
pipx install .
```

### Install with all extras (keyboard capture + Qt UI)
```bash
pip install ".[all]"
# or
pipx install --pip-args=".[all]" .
```

## Usage

```bash
clipmind start       # Start the background service
clipmind stop        # Stop it
clipmind status      # Check if running + item count
clipmind toggle      # Start/stop depending on current state
clipmind search foo  # Search history from the terminal
clipmind search      # Show recent items
clipmind clear       # Wipe all unpinned history
clipmind config      # Open config file in $EDITOR
```

## Config

On first run a config file is created at:

| OS      | Path |
|---------|------|
| macOS   | `~/Library/Preferences/clipmind/config.toml` |
| Linux   | `~/.config/clipmind/config.toml` |
| Windows | `%APPDATA%\clipmind\config.toml` |

Key settings:

```toml
hotkey = "ctrl+shift+space"
retention_days = 30
min_token_length = 4
max_history_size = 10000
poll_interval_ms = 500
excluded_apps = ["1Password", "Bitwarden"]
sensitive_patterns = [
  "(?i)password\\s*[:=]\\s*\\S+",
]
```

## Data location

| OS      | Path |
|---------|------|
| macOS   | `~/Library/Application Support/clipmind/history.db` |
| Linux   | `~/.local/share/clipmind/history.db` |
| Windows | `%APPDATA%\clipmind\history.db` |

All data is **local only** — no network calls, ever.

## Development

```bash
pip install -e ".[all]"
pytest tests/
```

## Roadmap
- [x] Phase 1: CLI + SQLite + clipboard capture
- [ ] Phase 2: Keyboard token capture with privacy filters
- [ ] Phase 3: PyQt6 global hotkey search window
- [ ] Phase 4: Cross-platform packaging
- [ ] Phase 5: System service install (launchd / systemd / Task Scheduler)
