"""
Internal entry point for the background worker process.
Run via:  python -m clipmind._worker
"""

import signal
import sys
import threading
import time

from clipmind import config as cfg
from clipmind.capture.clipboard import ClipboardWatcher
from clipmind.capture.keyboard import KeyboardWatcher
from clipmind.storage import db


def _handle_term(sig, frame):
    sys.exit(0)


def _expiry_loop(retention_days: int) -> None:
    while True:
        time.sleep(3600)
        try:
            db.expire(retention_days)
        except Exception:
            pass


def main():
    signal.signal(signal.SIGTERM, _handle_term)
    if sys.platform != "win32":
        signal.signal(signal.SIGHUP, _handle_term)

    conf = cfg.load()
    db.init_db()

    # Clipboard watcher — runs in its own thread
    clipboard_watcher = ClipboardWatcher(
        poll_ms=conf.get("poll_interval_ms", 500),
        excluded_apps=conf.get("excluded_apps", []),
        sensitive_patterns=conf.get("sensitive_patterns", []),
    )
    clipboard_watcher.start()

    # Keyboard watcher — runs in its own thread
    kb_watcher = KeyboardWatcher(
        min_token_len=conf.get("min_token_length", 4),
        sensitive_patterns=conf.get("sensitive_patterns", []),
    )
    try:
        kb_watcher.start()
    except Exception:
        pass  # gracefully skip if accessibility permissions not granted

    # Expiry loop — background thread
    threading.Thread(
        target=_expiry_loop,
        args=(conf.get("retention_days", 30),),
        daemon=True,
    ).start()

    # Qt UI + global hotkey — must own the main thread
    try:
        from clipmind.ui.search_window import run_ui
        run_ui(hotkey_str=conf.get("hotkey", "ctrl+shift+space"))
    except ImportError:
        # PyQt6 not installed — fall back to headless mode
        while True:
            time.sleep(60)


if __name__ == "__main__":
    main()
