"""Clipboard poller — runs in a thread, saves new text entries to the DB."""

import re
import threading
import time
from typing import Optional

import pyperclip

from clipmind import storage
from clipmind.storage import db


def _get_source_app() -> Optional[str]:
    """Best-effort: return the name of the frontmost app (macOS only for now)."""
    try:
        import subprocess
        result = subprocess.run(
            ["osascript", "-e",
             'tell application "System Events" to get name of first process whose frontmost is true'],
            capture_output=True, text=True, timeout=0.3,
        )
        name = result.stdout.strip()
        return name if name else None
    except Exception:
        return None


def _is_sensitive(content: str, patterns: list[str]) -> bool:
    for pat in patterns:
        try:
            if re.search(pat, content):
                return True
        except re.error:
            pass
    return False


def _is_excluded_app(app: Optional[str], excluded: list[str]) -> bool:
    if not app:
        return False
    app_lower = app.lower()
    return any(ex.lower() in app_lower for ex in excluded)


class ClipboardWatcher(threading.Thread):
    def __init__(self, poll_ms: int = 500, excluded_apps: Optional[list[str]] = None,
                 sensitive_patterns: Optional[list[str]] = None):
        super().__init__(daemon=True)
        self._poll_s = poll_ms / 1000.0
        self._excluded = excluded_apps or []
        self._sensitive = sensitive_patterns or []
        self._stop_event = threading.Event()
        self._last: Optional[str] = None

    def stop(self) -> None:
        self._stop_event.set()

    def run(self) -> None:
        db.init_db()
        # Seed with current clipboard so first run doesn't re-save existing content
        try:
            self._last = pyperclip.paste()
        except Exception:
            self._last = None

        while not self._stop_event.is_set():
            try:
                current = pyperclip.paste()
            except Exception:
                self._stop_event.wait(self._poll_s)
                continue

            if current and current != self._last:
                self._last = current
                app = _get_source_app()
                if _is_excluded_app(app, self._excluded):
                    self._stop_event.wait(self._poll_s)
                    continue
                if _is_sensitive(current, self._sensitive):
                    self._stop_event.wait(self._poll_s)
                    continue
                try:
                    db.upsert(current, "clipboard", source_app=app)
                except Exception:
                    pass

            self._stop_event.wait(self._poll_s)
