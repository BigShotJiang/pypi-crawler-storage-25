"""Keyboard capture — saves both individual tokens and full typed lines."""

import re
import threading
from typing import Optional

from clipmind.storage import db

# Characters that delimit tokens within a line
_TOKEN_DELIMITERS = re.compile(r'[\s/\\.,;:!?@#$%^&*()\[\]{}<>=+|`~"\'-]+')

# Minimum length to bother saving
MIN_LEN = 4

# Tokens must pass this to be saved individually (full lines bypass this check)
_SHAPE_MIN_LEN = 8  # plain lowercase words need to be at least this long

def _is_interesting_token(token: str) -> bool:
    """True if a token looks like something worth searching for later."""
    if len(token) >= _SHAPE_MIN_LEN:
        return True
    # Mixed case (camelCase, PascalCase, GitHub-style)
    if token != token.lower() and token != token.upper():
        return True
    # Contains at least one digit alongside letters (IDs, versions: abc123, v2.0)
    if re.search(r'[a-zA-Z]', token) and re.search(r'\d', token):
        return True
    # All-caps acronym/constant (NASA, TODO, UUID)
    if token.isupper() and len(token) >= 2:
        return True
    return False

# Common English words not worth storing as individual tokens.
# Full typed lines are always saved regardless — this only filters lone tokens.
_STOPWORDS = {
    "a", "an", "the", "and", "or", "but", "not", "nor", "so", "yet", "both",
    "for", "from", "into", "onto", "upon", "with", "within", "without",
    "about", "above", "after", "before", "below", "between", "during",
    "that", "this", "these", "those", "what", "which", "who", "whom",
    "when", "where", "why", "how", "than", "then", "there", "their",
    "they", "them", "have", "has", "had", "been", "being", "will", "would",
    "shall", "should", "could", "might", "must", "need", "dare", "used",
    "here", "also", "just", "only", "even", "much", "many", "more", "most",
    "some", "such", "each", "every", "other", "same", "very", "well",
    "back", "down", "over", "under", "again", "once", "your", "ours",
    "mine", "hers", "were", "with", "does", "said", "make", "made",
    "know", "like", "time", "look", "come", "want", "take", "good",
    "call", "feel", "keep", "help", "hold", "move", "turn", "show",
    "give", "find", "tell", "work", "seem", "long", "part", "hand",
    "high", "open", "away", "real", "life", "next", "late", "hard",
    "left", "done", "mean", "play", "live", "case", "last", "stop",
}


def _is_sensitive(text: str, patterns: list[str]) -> bool:
    for pat in patterns:
        try:
            if re.search(pat, text):
                return True
        except re.error:
            pass
    return False


def _save(text: str, sensitive_patterns: list[str]) -> None:
    text = text.strip()
    if len(text) < MIN_LEN:
        return
    if _is_sensitive(text, sensitive_patterns):
        return
    try:
        db.upsert(text, "typed")
    except Exception:
        pass


def _flush(buffer: str, sensitive_patterns: list[str], min_token_len: int) -> None:
    line = buffer.strip()
    if not line:
        return

    # Save the full line if long enough
    if len(line) >= min_token_len and not _is_sensitive(line, sensitive_patterns):
        try:
            db.upsert(line, "typed")
        except Exception:
            pass

    # Also save individual tokens (skip stopwords + shape filter)
    for token in _TOKEN_DELIMITERS.split(line):
        token = token.strip()
        if (len(token) >= min_token_len
                and token.lower() not in _STOPWORDS
                and _is_interesting_token(token)):
            _save(token, sensitive_patterns)


class KeyboardWatcher:
    def __init__(
        self,
        min_token_len: int = MIN_LEN,
        sensitive_patterns: Optional[list[str]] = None,
    ):
        self._min_token_len = min_token_len
        self._sensitive = sensitive_patterns or []
        self._buffer = ""
        self._lock = threading.Lock()
        self._listener = None

    def start(self) -> None:
        from pynput import keyboard

        def on_press(key):
            try:
                from pynput.keyboard import Key
                with self._lock:
                    if key in (Key.enter, Key.tab):
                        _flush(self._buffer, self._sensitive, self._min_token_len)
                        self._buffer = ""
                    elif key in (Key.space,):
                        self._buffer += " "
                    elif key in (Key.backspace,):
                        self._buffer = self._buffer[:-1]
                    elif key in (Key.esc, Key.delete):
                        self._buffer = ""
                    elif hasattr(key, "char") and key.char:
                        self._buffer += key.char
                        # Safety cap — flush if line grows very long
                        if len(self._buffer) > 2000:
                            _flush(self._buffer, self._sensitive, self._min_token_len)
                            self._buffer = ""
            except Exception:
                pass

        self._listener = keyboard.Listener(on_press=on_press)
        self._listener.start()

    def stop(self) -> None:
        if self._listener:
            self._listener.stop()
            self._listener = None
        # Flush whatever is left in the buffer
        with self._lock:
            _flush(self._buffer, self._sensitive, self._min_token_len)
            self._buffer = ""
