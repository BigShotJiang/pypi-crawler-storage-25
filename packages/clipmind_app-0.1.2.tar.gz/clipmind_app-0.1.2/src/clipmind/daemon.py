"""Background daemon: spawns a detached process and manages its PID file."""

import os
import signal
import subprocess
import sys
from pathlib import Path
from typing import Optional

from clipmind.paths import pid_file


# ── PID helpers ──────────────────────────────────────────────────────────────

def _read_pid() -> Optional[int]:
    pf = pid_file()
    if not pf.exists():
        return None
    try:
        return int(pf.read_text().strip())
    except (ValueError, OSError):
        return None


def _write_pid(pid: int) -> None:
    pid_file().write_text(str(pid))


def _clear_pid() -> None:
    try:
        pid_file().unlink(missing_ok=True)
    except OSError:
        pass


def _pid_running(pid: int) -> bool:
    if sys.platform == "win32":
        import ctypes
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        STILL_ACTIVE = 259
        handle = ctypes.windll.kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not handle:
            return False
        try:
            exit_code = ctypes.c_ulong()
            if ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                return exit_code.value == STILL_ACTIVE
            return False
        finally:
            ctypes.windll.kernel32.CloseHandle(handle)
    else:
        try:
            os.kill(pid, 0)
            return True
        except (ProcessLookupError, PermissionError):
            return False


# ── Public API ────────────────────────────────────────────────────────────────

def is_running() -> bool:
    pid = _read_pid()
    if pid is None:
        return False
    if _pid_running(pid):
        return True
    _clear_pid()
    return False


def start() -> bool:
    """Fork a detached worker process. Returns True if newly started."""
    if is_running():
        return False

    # Re-invoke ourselves with the internal _worker subcommand
    cmd = [sys.executable, "-m", "clipmind._worker"]
    if sys.platform == "win32":
        proc = subprocess.Popen(
            cmd,
            creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
            close_fds=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    else:
        # os.setpgrp puts the daemon in a new process group (won't get SIGHUP
        # when the launching terminal closes) while keeping it in the same
        # macOS session — this preserves TCC permissions (Accessibility, Input
        # Monitoring) that setsid/start_new_session would lose.
        proc = subprocess.Popen(
            cmd,
            preexec_fn=os.setpgrp,
            close_fds=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    _write_pid(proc.pid)
    return True


def stop() -> bool:
    """Send SIGTERM (or TerminateProcess on Windows) to the daemon. Returns True if killed."""
    pid = _read_pid()
    if pid is None or not _pid_running(pid):
        _clear_pid()
        return False
    try:
        if sys.platform == "win32":
            os.kill(pid, signal.CTRL_BREAK_EVENT)
        else:
            os.kill(pid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError):
        pass
    _clear_pid()
    return True


def get_pid() -> Optional[int]:
    pid = _read_pid()
    if pid and _pid_running(pid):
        return pid
    return None
