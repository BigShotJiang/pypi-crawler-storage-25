import sys
from pathlib import Path
from typing import Any
import tomli_w

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib

from clipmind.paths import config_file

DEFAULTS: dict[str, Any] = {
    "hotkey": "ctrl+shift+space",
    "retention_days": 30,
    "min_token_length": 4,
    "max_history_size": 10000,
    "poll_interval_ms": 500,
    "excluded_apps": [
        "1Password",
        "Bitwarden",
        "KeePass",
        "LastPass",
        "Dashlane",
    ],
    "sensitive_patterns": [
        r"(?i)password\s*[:=]\s*\S+",
        r"\b(?:\d[ -]?){15,16}\b",  # credit card
        r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Z|a-z]{2,}\b",  # email (optional)
    ],
}


def load() -> dict[str, Any]:
    path = config_file()
    if not path.exists():
        _write_defaults(path)
        return dict(DEFAULTS)
    with open(path, "rb") as f:
        data = tomllib.load(f)
    # Merge with defaults so new keys are always present
    merged = dict(DEFAULTS)
    merged.update(data)
    return merged


def _write_defaults(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        tomli_w.dump(DEFAULTS, f)
