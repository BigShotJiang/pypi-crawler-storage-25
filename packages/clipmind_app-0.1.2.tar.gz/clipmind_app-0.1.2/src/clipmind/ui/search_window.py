"""Global hotkey search popup window."""

import os
import subprocess
import sys
import time
import threading
from datetime import datetime
from typing import Optional

def _L(msg: str) -> None:
    pass  # logging disabled

import pyperclip
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QObject
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QLineEdit,
    QListWidget, QListWidgetItem, QLabel, QHBoxLayout,
)

from clipmind.storage import db


# ── Accessibility check ───────────────────────────────────────────────────────

def _can_send_keystrokes() -> bool:
    """Return True if this process has macOS Accessibility permission."""
    if sys.platform != "darwin":
        return True
    try:
        import ctypes
        ax = ctypes.cdll.LoadLibrary(
            "/System/Library/Frameworks/ApplicationServices.framework/ApplicationServices"
        )
        ax.AXIsProcessTrusted.restype = ctypes.c_bool
        return bool(ax.AXIsProcessTrusted())
    except Exception:
        return False


def _request_accessibility_permission() -> None:
    """Show the macOS Accessibility permission dialog if not yet granted."""
    if sys.platform != "darwin":
        return
    try:
        import ctypes, ctypes.util
        ax = ctypes.cdll.LoadLibrary(
            "/System/Library/Frameworks/ApplicationServices.framework/ApplicationServices"
        )
        cf = ctypes.cdll.LoadLibrary(ctypes.util.find_library("CoreFoundation"))
        objc = ctypes.cdll.LoadLibrary(ctypes.util.find_library("objc"))

        # Build options dict: {kAXTrustedCheckOptionPrompt: kCFBooleanTrue}
        objc.objc_getClass.restype    = ctypes.c_void_p
        objc.sel_registerName.restype = ctypes.c_void_p
        cf.CFBooleanGetValue.restype  = ctypes.c_bool

        # kAXTrustedCheckOptionPrompt key
        ax.kAXTrustedCheckOptionPrompt.restype = ctypes.c_void_p

        NSDictionary = objc.objc_getClass(b"NSDictionary")
        dictionaryWithObjectsAndKeys = objc.sel_registerName(
            b"dictionaryWithObjects:forKeys:count:")

        # Simpler: use CFDictionaryCreate
        cf.CFDictionaryCreate.restype  = ctypes.c_void_p
        cf.CFDictionaryCreate.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p),
            ctypes.POINTER(ctypes.c_void_p), ctypes.c_long,
            ctypes.c_void_p, ctypes.c_void_p,
        ]
        cf.kCFBooleanTrue.restype = ctypes.c_void_p

        key = ctypes.c_void_p.in_dll(ax, "kAXTrustedCheckOptionPrompt")
        val = ctypes.c_void_p.in_dll(cf, "kCFBooleanTrue")

        keys = (ctypes.c_void_p * 1)(key)
        vals = (ctypes.c_void_p * 1)(val)
        opts = cf.CFDictionaryCreate(None, keys, vals, 1, None, None)

        ax.AXIsProcessTrustedWithOptions.restype  = ctypes.c_bool
        ax.AXIsProcessTrustedWithOptions.argtypes = [ctypes.c_void_p]
        ax.AXIsProcessTrustedWithOptions(opts)
    except Exception as e:
        _L(f"request_accessibility error: {e}")


# Checked once at startup — expensive osascript call
_KEYSTROKE_OK: Optional[bool] = None


def _keystroke_allowed() -> bool:
    global _KEYSTROKE_OK
    if _KEYSTROKE_OK is None:
        _KEYSTROKE_OK = _can_send_keystrokes()
    return _KEYSTROKE_OK


# ── Helpers ───────────────────────────────────────────────────────────────────

def _rel_time(epoch: float) -> str:
    delta = time.time() - epoch
    if delta < 60:
        return "just now"
    if delta < 3600:
        return f"{int(delta/60)}m ago"
    if delta < 86400:
        return f"{int(delta/3600)}h ago"
    return datetime.fromtimestamp(epoch).strftime("%b %d")


def _get_frontmost_pid() -> Optional[int]:
    if sys.platform == "darwin":
        try:
            result = subprocess.run(
                ["osascript", "-e",
                 'tell application "System Events" to get unix id of first process whose frontmost is true'],
                capture_output=True, text=True, timeout=0.5,
            )
            val = result.stdout.strip()
            return int(val) if val else None
        except Exception:
            return None
    elif sys.platform == "win32":
        try:
            import ctypes
            user32 = ctypes.windll.user32
            hwnd = user32.GetForegroundWindow()
            pid = ctypes.c_ulong(0)
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            return pid.value if pid.value else None
        except Exception:
            return None
    return None


def _ns_activate_pid(pid: int) -> bool:
    """Activate an app by PID. macOS: NSRunningApplication; Windows: SetForegroundWindow."""
    if sys.platform == "darwin":
        try:
            import ctypes, ctypes.util
            objc = ctypes.cdll.LoadLibrary(ctypes.util.find_library("objc"))
            objc.objc_getClass.restype    = ctypes.c_void_p
            objc.sel_registerName.restype = ctypes.c_void_p

            cls = objc.objc_getClass(b"NSRunningApplication")
            sel_run = objc.sel_registerName(b"runningApplicationWithProcessIdentifier:")
            f = objc.objc_msgSend
            f.restype  = ctypes.c_void_p
            f.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int32]
            app = f(cls, sel_run, ctypes.c_int32(pid))
            if not app:
                _L(f"ns_activate: no NSRunningApplication for pid {pid}")
                return False

            sel_act = objc.sel_registerName(b"activateWithOptions:")
            f.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong]
            f(app, sel_act, ctypes.c_ulong(2))
            return True
        except Exception as e:
            _L(f"ns_activate error: {e}")
            return False

    elif sys.platform == "win32":
        try:
            import ctypes
            user32 = ctypes.windll.user32

            found = ctypes.c_size_t(0)
            WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_size_t, ctypes.c_size_t)

            def _cb(hwnd, lparam):
                win_pid = ctypes.c_ulong(0)
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(win_pid))
                if win_pid.value == lparam and user32.IsWindowVisible(hwnd):
                    found.value = hwnd
                    return False
                return True

            user32.EnumWindows(WNDENUMPROC(_cb), ctypes.c_size_t(pid))
            if found.value:
                # AllowSetForegroundWindow lets us steal focus from another process
                user32.AllowSetForegroundWindow(pid)
                user32.SetForegroundWindow(found.value)
                return True
            return False
        except Exception as e:
            _L(f"win_activate error: {e}")
            return False

    return False


def _global_paste() -> None:
    """Send Cmd+V (macOS) or Ctrl+V (Windows) to the currently focused app."""
    if sys.platform == "darwin":
        try:
            import ctypes, ctypes.util
            q = ctypes.cdll.LoadLibrary(ctypes.util.find_library("Quartz"))

            kVK_ANSI_V              = 0x09
            kCGHIDEventTap          = 0
            kCGEventFlagMaskCommand = 0x00100000

            q.CGEventCreateKeyboardEvent.restype  = ctypes.c_void_p
            q.CGEventCreateKeyboardEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint16, ctypes.c_bool]
            q.CGEventSetFlags.argtypes            = [ctypes.c_void_p, ctypes.c_uint64]
            q.CGEventSetFlags.restype             = None
            q.CGEventPost.argtypes                = [ctypes.c_uint32, ctypes.c_void_p]
            q.CGEventPost.restype                 = None
            q.CFRelease.argtypes                  = [ctypes.c_void_p]
            q.CFRelease.restype                   = None

            ev = q.CGEventCreateKeyboardEvent(None, kVK_ANSI_V, True)
            q.CGEventSetFlags(ev, kCGEventFlagMaskCommand)
            q.CGEventPost(kCGHIDEventTap, ev)
            q.CFRelease(ev)
            time.sleep(0.05)
            ev = q.CGEventCreateKeyboardEvent(None, kVK_ANSI_V, False)
            q.CGEventSetFlags(ev, 0)
            q.CGEventPost(kCGHIDEventTap, ev)
            q.CFRelease(ev)
        except Exception as e:
            _L(f"global_paste error: {e}")

    elif sys.platform == "win32":
        try:
            import ctypes

            INPUT_KEYBOARD  = 1
            KEYEVENTF_KEYUP = 0x0002
            VK_CONTROL      = 0x11
            VK_V            = 0x56

            class KEYBDINPUT(ctypes.Structure):
                _fields_ = [
                    ("wVk",         ctypes.c_ushort),
                    ("wScan",       ctypes.c_ushort),
                    ("dwFlags",     ctypes.c_ulong),
                    ("time",        ctypes.c_ulong),
                    ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
                ]

            class _INPUT_UNION(ctypes.Union):
                _fields_ = [("ki", KEYBDINPUT), ("_pad", ctypes.c_byte * 28)]

            class INPUT(ctypes.Structure):
                _fields_ = [("type", ctypes.c_ulong), ("value", _INPUT_UNION)]

            def _make_key(vk, up=False):
                inp = INPUT()
                inp.type = INPUT_KEYBOARD
                inp.value.ki.wVk    = vk
                inp.value.ki.dwFlags = KEYEVENTF_KEYUP if up else 0
                return inp

            inputs = (INPUT * 4)(
                _make_key(VK_CONTROL),
                _make_key(VK_V),
                _make_key(VK_V,       up=True),
                _make_key(VK_CONTROL, up=True),
            )
            ctypes.windll.user32.SendInput(4, inputs, ctypes.sizeof(INPUT))
        except Exception as e:
            _L(f"global_paste win error: {e}")


def _activate_self() -> None:
    """Bring the clipmind window to the front."""
    if sys.platform == "darwin":
        _ns_activate_pid(os.getpid())
    # On Windows Qt's activateWindow()/raise_() handles it; no extra call needed.


def _set_window_level(win_id: int) -> None:
    """Set NSWindow level to NSPopUpMenuWindowLevel (101) so it floats above everything."""
    if sys.platform != "darwin":
        return
    try:
        import ctypes, ctypes.util
        objc = ctypes.cdll.LoadLibrary(ctypes.util.find_library("objc"))
        objc.objc_getClass.restype    = ctypes.c_void_p
        objc.sel_registerName.restype = ctypes.c_void_p

        # win_id is NSView* — get its NSWindow
        sel_window   = objc.sel_registerName(b"window")
        sel_setLevel = objc.sel_registerName(b"setLevel:")

        f = objc.objc_msgSend
        f.restype  = ctypes.c_void_p
        f.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        ns_window = f(ctypes.c_void_p(win_id), sel_window)

        if ns_window:
            f.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_long]
            f(ns_window, sel_setLevel, 101)  # NSPopUpMenuWindowLevel
            _L("window level set to 101")
    except Exception as e:
        _L(f"set_window_level error: {e}")


def _paste_text(text: str, previous_pid: Optional[int] = None) -> bool:
    """
    Copy text to clipboard, re-focus the previous app, simulate Cmd+V via pynput.
    Returns True if auto-paste was attempted, False if clipboard-only.
    """
    _L(f"paste_text called: pid={previous_pid} text={text[:30]!r}")
    pyperclip.copy(text)
    _L("clipboard set")

    can_paste = (
        (sys.platform == "darwin" and _keystroke_allowed()) or
        sys.platform == "win32"
    )
    if can_paste and previous_pid:
        _L(f"activating pid {previous_pid}")
        ok = _ns_activate_pid(previous_pid)
        _L(f"activate result: {ok}, sleeping 0.25 then pasting")
        time.sleep(0.25)
        _global_paste()
        _L("global_paste done")
        return True

    _L(f"clipboard-only fallback: platform={sys.platform} pid={previous_pid} keystroke_ok={_keystroke_allowed()}")
    return False  # clipboard only


# ── Bridge: signals from hotkey thread → Qt main thread ──────────────────────

class _Bridge(QObject):
    show_window = pyqtSignal()
    show_toast  = pyqtSignal(str)


_bridge = _Bridge()


# ── Toast overlay ─────────────────────────────────────────────────────────────

class Toast(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent, Qt.WindowType.ToolTip | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 10, 16, 10)
        self._label = QLabel()
        self._label.setStyleSheet("""
            background: #313244;
            color: #cdd6f4;
            border-radius: 8px;
            font-size: 13px;
            padding: 6px 12px;
        """)
        layout.addWidget(self._label)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.hide)

    def show_message(self, msg: str, duration_ms: int = 2000) -> None:
        self._label.setText(msg)
        self.adjustSize()
        screen = QApplication.primaryScreen().geometry()
        x = (screen.width() - self.width()) // 2
        y = screen.height() - 120
        self.move(x, y)
        self.show()
        self._timer.start(duration_ms)


# ── Search window ─────────────────────────────────────────────────────────────

class SearchWindow(QWidget):
    def __init__(self):
        super().__init__()
        self._rows: list = []
        self._previous_pid: Optional[int] = None
        self._build_ui()
        _bridge.show_window.connect(self._on_hotkey)
        _bridge.show_toast.connect(self._toast.show_message)

    def _build_ui(self):
        self.setWindowTitle("ClipMind")
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedWidth(640)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        container = QWidget()
        container.setObjectName("container")
        container.setStyleSheet("""
            QWidget#container {
                background: #1e1e2e;
                border: 1px solid #45475a;
                border-radius: 12px;
            }
        """)
        layout = QVBoxLayout(container)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        self._search = QLineEdit()
        self._search.setPlaceholderText("Search history…")
        self._search.setStyleSheet("""
            QLineEdit {
                background: #313244;
                color: #cdd6f4;
                border: 1px solid #585b70;
                border-radius: 8px;
                padding: 8px 12px;
                font-size: 15px;
            }
            QLineEdit:focus { border-color: #89b4fa; }
        """)
        self._search.textChanged.connect(self._on_query_changed)
        self._search.installEventFilter(self)
        layout.addWidget(self._search)

        self._list = QListWidget()
        self._list.setStyleSheet("""
            QListWidget {
                background: transparent;
                border: none;
                outline: none;
            }
            QListWidget::item {
                background: transparent;
                padding: 0px;
                margin: 0px;
            }
        """)
        self._list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._list.itemActivated.connect(self._on_activate)
        layout.addWidget(self._list)

        # Permission warning shown once if auto-paste won't work
        self._perm_warn = QLabel(
            "Tip: grant Accessibility to enable auto-paste — "
            "System Settings > Privacy & Security > Accessibility > add Python"
        )
        self._perm_warn.setWordWrap(True)
        self._perm_warn.setStyleSheet(
            "color: #f9e2af; font-size: 11px; padding: 2px 4px;"
        )
        self._perm_warn.setVisible(False)
        layout.addWidget(self._perm_warn)

        paste_key = "⌘V" if sys.platform == "darwin" else "Ctrl+V"
        hint = QLabel(f"↑↓ navigate   ↵ copy+paste   Del delete   P pin/unpin   Esc close   (fallback: {paste_key})")
        hint.setStyleSheet("color: #585b70; font-size: 11px; padding: 2px 4px;")
        layout.addWidget(hint)

        outer.addWidget(container)

        self._toast = Toast()
        self._debounce = QTimer()
        self._debounce.setSingleShot(True)
        self._debounce.timeout.connect(self._refresh)

        # Check permissions once asynchronously so startup isn't slow
        QTimer.singleShot(500, self._check_permissions)

    def _check_permissions(self):
        if sys.platform == "darwin" and not _keystroke_allowed():
            self._perm_warn.setVisible(True)

    # ── Data ──────────────────────────────────────────────────────────────────

    def _on_query_changed(self):
        self._debounce.start(80)

    def _refresh(self):
        query = self._search.text().strip()
        self._rows = db.search(query, limit=50)
        self._list.clear()
        for row in self._rows:
            self._add_item(row)
        if self._list.count():
            self._list.setCurrentRow(0)
        row_h = 62
        visible = min(len(self._rows), 8)
        self._list.setFixedHeight(max(visible * row_h, row_h))
        self.adjustSize()

    def _add_item(self, row):
        item = QListWidgetItem()
        item.setData(Qt.ItemDataRole.UserRole, row["id"])

        widget = QWidget()
        widget.setStyleSheet("""
            QWidget {
                background: #313244;
                border-radius: 6px;
            }
            QWidget:hover { background: #3d3f52; }
        """)
        widget.setFixedHeight(56)
        h = QHBoxLayout(widget)
        h.setContentsMargins(10, 6, 10, 6)
        h.setSpacing(8)

        pin_label = QLabel("📌" if row["pinned"] else "  ")
        pin_label.setFixedWidth(20)
        h.addWidget(pin_label)

        v = QVBoxLayout()
        v.setSpacing(2)
        v.setAlignment(Qt.AlignmentFlag.AlignVCenter)

        kind = "clipboard" if row["type"] == "clipboard" else "typed"
        meta = f"{kind} · {_rel_time(row['last_seen'])} · ×{row['frequency']}"
        meta_label = QLabel(meta)
        meta_label.setStyleSheet("color: #585b70; font-size: 11px;")
        v.addWidget(meta_label)

        content = row["content"].replace("\n", "↵")
        if len(content) > 80:
            content = content[:80] + "…"
        content_label = QLabel(content)
        content_label.setStyleSheet("color: #cdd6f4; font-size: 13px;")
        v.addWidget(content_label)

        h.addLayout(v)
        h.addStretch()

        item.setSizeHint(widget.sizeHint())
        self._list.addItem(item)
        self._list.setItemWidget(item, widget)

    # ── Actions ───────────────────────────────────────────────────────────────

    def _selected_row(self):
        idx = self._list.currentRow()
        if 0 <= idx < len(self._rows):
            return self._rows[idx]
        return None

    def _on_activate(self, _item=None):
        row = self._selected_row()
        if not row:
            _L("on_activate: no row selected")
            return
        prev_pid = self._previous_pid
        content = row["content"]
        _L(f"on_activate: content={content[:30]!r} prev_pid={prev_pid}")
        self.hide()

        def do_paste():
            pasted = _paste_text(content, prev_pid)
            if not pasted:
                shortcut = "⌘V" if sys.platform == "darwin" else "Ctrl+V"
                _bridge.show_toast.emit(f"Copied! Press {shortcut} to paste")

        QTimer.singleShot(150, do_paste)

    def _delete_selected(self):
        row = self._selected_row()
        if row:
            db.delete_item(row["id"])
            self._refresh()

    def _pin_selected(self):
        row = self._selected_row()
        if row:
            db.pin_item(row["id"], not bool(row["pinned"]))
            self._refresh()

    # ── Hotkey trigger ────────────────────────────────────────────────────────

    def _on_hotkey(self):
        # Capture previous app BEFORE we steal focus
        self._previous_pid = _get_frontmost_pid()
        _L(f"hotkey fired: previous_pid={self._previous_pid}")
        # Bring our process to front so the window actually appears over other apps
        _activate_self()
        _L("activate_self done")
        screen = QApplication.primaryScreen().geometry()
        self.adjustSize()
        x = (screen.width() - self.width()) // 2
        y = screen.height() // 5
        self.move(x, y)
        self._search.clear()
        self._refresh()
        self.show()
        _set_window_level(int(self.winId()))
        self.activateWindow()
        self.raise_()
        self._search.setFocus()

    # ── Keyboard handling ─────────────────────────────────────────────────────

    def eventFilter(self, obj, event):
        from PyQt6.QtCore import QEvent
        if obj is self._search and event.type() == QEvent.Type.KeyPress:
            key = event.key()
            if key == Qt.Key.Key_Down:
                cur = self._list.currentRow()
                self._list.setCurrentRow(min(cur + 1, self._list.count() - 1))
                return True
            if key == Qt.Key.Key_Up:
                cur = self._list.currentRow()
                self._list.setCurrentRow(max(cur - 1, 0))
                return True
            if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
                self._on_activate()
                return True
            if key == Qt.Key.Key_Escape:
                self.hide()
                return True
            if key == Qt.Key.Key_Delete:
                self._delete_selected()
                return True
            if key == Qt.Key.Key_P:
                self._pin_selected()
                return True
        return super().eventFilter(obj, event)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self.hide()


# ── Global hotkey listener ────────────────────────────────────────────────────

def _parse_hotkey(hotkey_str: str) -> str:
    parts = hotkey_str.lower().split("+")
    mapped = []
    special = {"ctrl", "shift", "alt", "cmd", "space", "tab"}
    for p in parts:
        p = p.strip()
        if p in special or len(p) > 1:
            mapped.append(f"<{p}>")
        else:
            mapped.append(p)
    return "+".join(mapped)


def start_hotkey_listener(hotkey_str: str = "ctrl+shift+space") -> None:
    from pynput import keyboard
    combo = _parse_hotkey(hotkey_str)

    def on_activate():
        _bridge.show_window.emit()

    listener = keyboard.GlobalHotKeys({combo: on_activate})
    t = threading.Thread(target=listener.run, daemon=True)
    t.start()


# ── Main entry ────────────────────────────────────────────────────────────────

def _set_activation_policy() -> None:
    """Set NSApplicationActivationPolicyAccessory so we stay out of the Dock
    but can still raise windows above other apps when needed."""
    if sys.platform != "darwin":
        return
    try:
        import ctypes, ctypes.util
        objc = ctypes.cdll.LoadLibrary(ctypes.util.find_library("objc"))
        objc.objc_getClass.restype = ctypes.c_void_p
        objc.sel_registerName.restype = ctypes.c_void_p
        objc.objc_msgSend.restype = ctypes.c_void_p
        objc.objc_msgSend.argtypes = [ctypes.c_void_p, ctypes.c_void_p]

        NSApp_cls = objc.objc_getClass(b"NSApplication")
        shared_sel = objc.sel_registerName(b"sharedApplication")
        policy_sel = objc.sel_registerName(b"setActivationPolicy:")

        app = objc.objc_msgSend(NSApp_cls, shared_sel)

        f = objc.objc_msgSend
        f.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_long]
        f.restype  = ctypes.c_void_p
        # NSApplicationActivationPolicyAccessory = 1
        # Stays out of Dock/app switcher but CAN raise above other apps
        f(app, policy_sel, 1)
    except Exception:
        pass


def run_ui(hotkey_str: str = "ctrl+shift+space") -> None:
    app = QApplication.instance() or QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    _set_activation_policy()
    # Ask for Accessibility permission on first run — shows system dialog
    if sys.platform == "darwin" and not _can_send_keystrokes():
        _request_accessibility_permission()
    window = SearchWindow()
    start_hotkey_listener(hotkey_str)
    sys.exit(app.exec())
