from pathlib import Path
from platformdirs import user_data_dir, user_config_dir

APP_NAME = "clipmind"


def data_dir() -> Path:
    p = Path(user_data_dir(APP_NAME))
    p.mkdir(parents=True, exist_ok=True)
    return p


def config_dir() -> Path:
    p = Path(user_config_dir(APP_NAME))
    p.mkdir(parents=True, exist_ok=True)
    return p


def db_path() -> Path:
    return data_dir() / "history.db"


def pid_file() -> Path:
    return data_dir() / "daemon.pid"


def config_file() -> Path:
    return config_dir() / "config.toml"
