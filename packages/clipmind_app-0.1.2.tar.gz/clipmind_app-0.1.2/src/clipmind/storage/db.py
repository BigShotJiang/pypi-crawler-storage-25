import sqlite3
import time
from pathlib import Path
from typing import Optional

from clipmind.paths import db_path

SCHEMA = """
CREATE TABLE IF NOT EXISTS history (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    content     TEXT    NOT NULL UNIQUE,
    type        TEXT    NOT NULL CHECK(type IN ('clipboard','typed')),
    first_seen  REAL    NOT NULL,
    last_seen   REAL    NOT NULL,
    frequency   INTEGER NOT NULL DEFAULT 1,
    source_app  TEXT,
    pinned      INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_last_seen ON history(last_seen DESC);
CREATE INDEX IF NOT EXISTS idx_pinned    ON history(pinned DESC);
"""


def _connect(path: Optional[Path] = None) -> sqlite3.Connection:
    p = path or db_path()
    conn = sqlite3.connect(str(p))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


def init_db(path: Optional[Path] = None) -> None:
    with _connect(path) as conn:
        conn.executescript(SCHEMA)


def upsert(content: str, type_: str, source_app: Optional[str] = None,
           path: Optional[Path] = None) -> None:
    now = time.time()
    with _connect(path) as conn:
        conn.execute(
            """
            INSERT INTO history (content, type, first_seen, last_seen, frequency, source_app)
            VALUES (?, ?, ?, ?, 1, ?)
            ON CONFLICT(content) DO UPDATE SET
                last_seen  = excluded.last_seen,
                frequency  = frequency + 1,
                source_app = COALESCE(excluded.source_app, source_app)
            """,
            (content, type_, now, now, source_app),
        )


def _fuzzy_score(query: str, text: str) -> float:
    """
    Score how well `query` matches `text`.
    Returns 0.0 if query chars aren't all present as a subsequence.
    Higher is better. Rewards: exact substring > contiguous run > scattered match.
    """
    q = query.lower()
    t = text.lower()

    # Exact substring → best possible score
    if q in t:
        # Shorter text = tighter match
        return 1000.0 + (1.0 / (len(t) + 1))

    # Subsequence check + score longest contiguous run of matched chars
    qi = 0
    run = best_run = cur_run = 0
    for ch in t:
        if qi < len(q) and ch == q[qi]:
            qi += 1
            cur_run += 1
            if cur_run > best_run:
                best_run = cur_run
        else:
            cur_run = 0

    if qi < len(q):
        return 0.0  # not all query chars found

    # Score: proportion of query matched contiguously
    return best_run / len(q)


def search(query: str, limit: int = 50, path: Optional[Path] = None) -> list[sqlite3.Row]:
    with _connect(path) as conn:
        if query:
            # Pull a broader candidate set, then re-rank with fuzzy scoring in Python
            rows = conn.execute(
                """
                SELECT * FROM history
                ORDER BY pinned DESC,
                         (last_seen * frequency) DESC
                LIMIT 2000
                """,
            ).fetchall()
            scored = [
                (row, _fuzzy_score(query, row["content"]))
                for row in rows
            ]
            scored = [(r, s) for r, s in scored if s > 0.0]
            scored.sort(key=lambda x: (x[0]["pinned"], x[1]), reverse=True)
            rows = [r for r, _ in scored[:limit]]
        else:
            rows = conn.execute(
                """
                SELECT * FROM history
                ORDER BY pinned DESC,
                         (last_seen * frequency) DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
    return rows


def expire(retention_days: int, path: Optional[Path] = None) -> int:
    cutoff = time.time() - retention_days * 86400
    with _connect(path) as conn:
        cur = conn.execute(
            "DELETE FROM history WHERE last_seen < ? AND pinned = 0",
            (cutoff,),
        )
        return cur.rowcount


def delete_item(item_id: int, path: Optional[Path] = None) -> None:
    with _connect(path) as conn:
        conn.execute("DELETE FROM history WHERE id = ?", (item_id,))


def pin_item(item_id: int, pinned: bool, path: Optional[Path] = None) -> None:
    with _connect(path) as conn:
        conn.execute("UPDATE history SET pinned = ? WHERE id = ?",
                     (1 if pinned else 0, item_id))


def clear(path: Optional[Path] = None) -> int:
    with _connect(path) as conn:
        cur = conn.execute("DELETE FROM history WHERE pinned = 0")
        return cur.rowcount


def count(path: Optional[Path] = None) -> int:
    with _connect(path) as conn:
        return conn.execute("SELECT COUNT(*) FROM history").fetchone()[0]
