"""Typer CLI entry point for clipmind."""

import subprocess
import sys
from datetime import datetime
from typing import Optional

import typer

app = typer.Typer(
    name="clipmind",
    help="Smart clipboard & typing history tool.",
    no_args_is_help=True,
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _ts(epoch: float) -> str:
    return datetime.fromtimestamp(epoch).strftime("%Y-%m-%d %H:%M")


def _truncate(s: str, width: int = 72) -> str:
    s = s.replace("\n", "↵").replace("\r", "")
    return s[:width] + "…" if len(s) > width else s


# ── Commands ──────────────────────────────────────────────────────────────────

@app.command()
def start():
    """Start the background capture service."""
    from clipmind import daemon
    started = daemon.start()
    if started:
        pid = daemon.get_pid()
        typer.echo(f"clipmind started (pid {pid}).")
    else:
        pid = daemon.get_pid()
        typer.echo(f"clipmind is already running (pid {pid}).")


@app.command()
def stop():
    """Stop the background capture service."""
    from clipmind import daemon
    stopped = daemon.stop()
    if stopped:
        typer.echo("clipmind stopped.")
    else:
        typer.echo("clipmind was not running.")


@app.command()
def status():
    """Show whether the background service is running."""
    from clipmind import daemon
    from clipmind.storage import db
    if daemon.is_running():
        pid = daemon.get_pid()
        total = db.count()
        typer.echo(f"Running (pid {pid}) — {total} items in history.")
    else:
        typer.echo("Not running.")


@app.command()
def toggle():
    """Start if stopped, stop if running."""
    from clipmind import daemon
    if daemon.is_running():
        daemon.stop()
        typer.echo("clipmind stopped.")
    else:
        daemon.start()
        pid = daemon.get_pid()
        typer.echo(f"clipmind started (pid {pid}).")


@app.command()
def pause():
    """Pause capture (sends SIGUSR1 to the daemon — not yet fully implemented)."""
    typer.echo("Pause not yet implemented. Use 'clipmind stop' to stop capture.")


@app.command()
def resume():
    """Resume capture after pause."""
    typer.echo("Resume not yet implemented. Use 'clipmind start' to restart capture.")


@app.command()
def search(
    query: str = typer.Argument("", help="Search term (empty = show recent)"),
    limit: int = typer.Option(20, "--limit", "-n", help="Max results"),
):
    """Search clipboard/typing history."""
    from clipmind.storage import db
    rows = db.search(query, limit=limit)
    if not rows:
        typer.echo("No results.")
        return
    for row in rows:
        pin = "📌 " if row["pinned"] else "   "
        kind = row["type"][0].upper()   # C or T
        ts = _ts(row["last_seen"])
        freq = row["frequency"]
        content = _truncate(row["content"])
        typer.echo(f"{pin}[{kind}] {ts} (×{freq:3d})  {content}")


@app.command()
def clear(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Clear all unpinned history."""
    from clipmind.storage import db
    if not yes:
        typer.confirm("Delete all unpinned history?", abort=True)
    n = db.clear()
    typer.echo(f"Deleted {n} items.")


@app.command()
def config():
    """Open the config file in the default editor."""
    from clipmind.paths import config_file
    from clipmind import config as cfg
    cfg.load()  # ensure file exists
    path = config_file()
    editor = (
        subprocess.os.environ.get("VISUAL")
        or subprocess.os.environ.get("EDITOR")
        or ("notepad" if sys.platform == "win32" else "open" if sys.platform == "darwin" else "xdg-open")
    )
    subprocess.run([editor, str(path)])


if __name__ == "__main__":
    app()
