# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.5.1] - 2026-04-01

### Fixed
- **P0**: `cache_size_bytes` metric reported item count instead of bytes — `/stats` endpoint now returns `volume()` with empty-cache guard
- **P1**: EMA throughput decay never reached zero — floored to 0 when value < 0.001
- **P1**: EMA latency decay never reached zero — same floor applied
- **P1**: `_get_metrics_for_backend()` cache size reported SQLite WAL overhead on empty cache — added `len(cache) > 0` guard

### Changed
- Default `RAMJET_BACKEND_HOST` changed to `grpc.ramjet.io` (production NLB endpoint)

### Added
- GPU detection via `pynvml` with `torch.cuda` fallback for memory reporting
- `/stats` endpoint now returns separate `items` field (item count) distinct from `cache_size` (bytes)

## [0.5.0] - 2026-03-23

### Fixed
- **P0**: `CachedDataset` examples crash — now pass `ramjetio.get_cache()` explicitly
- **P0**: `BackendClient.__init__` dead code — instance vars moved before early return
- **P1**: Config hot-reload — heartbeat callback triggers `_apply_cluster_config` on change
- **P1**: `replication_factor` now read from cluster config and passed to `DistributedCache`
- **P1**: Removed insecure `torch.load(weights_only=False)` fallback
- **P1**: Fixed fallback module path `ramjet.cli.server` → `ramjetio.cli.server`
- **P2**: Fork-safe `requests.Session` — lazy-init per process PID
- **P2**: Thread-safe `ConsistentHash` — all operations wrapped with `threading.Lock`
- **P2**: `CachedDataset` stats use `multiprocessing.Value` for cross-worker visibility
- **P2**: `get_data_source_config()` ghost nodes — proper channel cleanup in finally block

### Optimized
- **P3**: `exists()` uses HEAD request instead of full GET (no data transfer)
- **P3**: Heartbeat metrics query local node only (`localhost/stats`) instead of all cluster nodes

## [0.4.0] - 2026-03-17

## [0.1.0] - 2025-10-22

### Added
- Initial release of RAMJET distributed cache
- Consistent hashing implementation for key distribution
- HTTP-based cache server with disk storage
- Distributed cache client with retry logic
- PyTorch integration utilities:
  - `CachedDataset` for caching dataset items
  - `CacheCheckpoint` for model checkpoint management
  - Forward hooks for activation caching
- Command-line interfaces:
  - `ramjet-server` for starting cache servers
  - `ramjet-client` for command-line cache operations
- Comprehensive test suite
- Example scripts demonstrating usage
- Documentation and README

### Features
- Scalable to N servers with M TB each
- Automatic node addition/removal with minimal redistribution
- Optional data compression
- Configurable replication factor
- TTL support for cache entries
- PyTorch tensor serialization
- Statistics and monitoring endpoints

[Unreleased]: https://github.com/ramjetinc/ramjet/compare/v0.5.1...HEAD
[0.5.1]: https://github.com/ramjetinc/ramjet/compare/v0.5.0...v0.5.1
[0.5.0]: https://github.com/ramjetinc/ramjet/compare/v0.4.0...v0.5.0
[0.1.0]: https://github.com/ramjetinc/ramjet/releases/tag/v0.1.0
