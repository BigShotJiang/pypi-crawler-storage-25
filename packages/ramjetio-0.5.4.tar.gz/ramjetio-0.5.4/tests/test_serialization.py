"""
Tests for ramjetio.serialization module.
"""

import pytest
import torch

from ramjetio.serialization import (
    serialize_tensor,
    deserialize_tensor,
    serialize_object,
    deserialize_object,
)


class TestSerializeTensor:
    """Test tensor serialization."""

    def test_serialize_1d_tensor(self):
        """Test serializing a 1D tensor."""
        t = torch.tensor([1.0, 2.0, 3.0])
        data = serialize_tensor(t)
        assert isinstance(data, bytes)
        assert len(data) > 0

    def test_serialize_2d_tensor(self):
        """Test serializing a 2D tensor."""
        t = torch.randn(10, 20)
        data = serialize_tensor(t)
        assert isinstance(data, bytes)
        assert len(data) > 0

    def test_serialize_with_compression(self):
        """Test that compression reduces size for large tensors."""
        t = torch.zeros(1000, 1000)  # Highly compressible
        uncompressed = serialize_tensor(t, compress=False)
        compressed = serialize_tensor(t, compress=True)
        assert len(compressed) < len(uncompressed)

    def test_serialize_without_compression(self):
        """Test serialization without compression."""
        t = torch.randn(5, 5)
        data = serialize_tensor(t, compress=False)
        assert isinstance(data, bytes)
        assert len(data) > 0

    def test_serialize_empty_tensor(self):
        """Test serializing an empty tensor."""
        t = torch.tensor([])
        data = serialize_tensor(t)
        assert isinstance(data, bytes)

    def test_serialize_integer_tensor(self):
        """Test serializing integer tensor."""
        t = torch.tensor([1, 2, 3], dtype=torch.int64)
        data = serialize_tensor(t)
        assert isinstance(data, bytes)


class TestDeserializeTensor:
    """Test tensor deserialization."""

    def test_roundtrip_1d(self):
        """Test serialize → deserialize roundtrip for 1D tensor."""
        original = torch.tensor([1.0, 2.0, 3.0])
        data = serialize_tensor(original)
        restored = deserialize_tensor(data)
        assert torch.equal(original, restored)

    def test_roundtrip_2d(self):
        """Test serialize → deserialize roundtrip for 2D tensor."""
        original = torch.randn(10, 20)
        data = serialize_tensor(original)
        restored = deserialize_tensor(data)
        assert torch.allclose(original, restored)

    def test_roundtrip_compressed(self):
        """Test serialize → deserialize roundtrip with compression."""
        original = torch.randn(50, 50)
        data = serialize_tensor(original, compress=True)
        restored = deserialize_tensor(data)
        assert torch.allclose(original, restored)

    def test_roundtrip_integer(self):
        """Test roundtrip for integer tensors."""
        original = torch.tensor([1, 2, 3, 4, 5], dtype=torch.int32)
        data = serialize_tensor(original)
        restored = deserialize_tensor(data)
        assert torch.equal(original, restored)

    def test_roundtrip_preserves_dtype(self):
        """Test that dtype is preserved through serialization."""
        for dtype in [torch.float32, torch.float64, torch.int32, torch.int64, torch.bool]:
            original = torch.ones(5, dtype=dtype)
            data = serialize_tensor(original)
            restored = deserialize_tensor(data)
            assert restored.dtype == dtype

    def test_roundtrip_preserves_shape(self):
        """Test that shape is preserved through serialization."""
        original = torch.randn(3, 4, 5)
        data = serialize_tensor(original)
        restored = deserialize_tensor(data)
        assert restored.shape == original.shape


class TestSerializeObject:
    """Test object serialization."""

    def test_serialize_dict(self):
        """Test serializing a dictionary."""
        obj = {"key": "value", "number": 42}
        data = serialize_object(obj)
        assert isinstance(data, bytes)

    def test_serialize_list(self):
        """Test serializing a list."""
        obj = [1, 2, 3, "four", 5.0]
        data = serialize_object(obj)
        assert isinstance(data, bytes)

    def test_serialize_string(self):
        """Test serializing a string."""
        data = serialize_object("hello world")
        assert isinstance(data, bytes)

    def test_serialize_with_compression(self):
        """Test object serialization with compression."""
        obj = {"data": [0] * 10000}  # Highly compressible
        uncompressed = serialize_object(obj, compress=False)
        compressed = serialize_object(obj, compress=True)
        assert len(compressed) < len(uncompressed)


class TestDeserializeObject:
    """Test object deserialization."""

    def test_roundtrip_dict(self):
        """Test dict serialize → deserialize roundtrip."""
        original = {"key": "value", "nested": {"a": 1}}
        data = serialize_object(original)
        restored = deserialize_object(data)
        assert restored == original

    def test_roundtrip_list(self):
        """Test list serialize → deserialize roundtrip."""
        original = [1, "two", 3.0, [4, 5]]
        data = serialize_object(original)
        restored = deserialize_object(data)
        assert restored == original

    def test_roundtrip_compressed(self):
        """Test compressed object roundtrip."""
        original = {"data": list(range(1000))}
        data = serialize_object(original, compress=True)
        restored = deserialize_object(data)
        assert restored == original

    def test_roundtrip_none(self):
        """Test None roundtrip."""
        data = serialize_object(None)
        restored = deserialize_object(data)
        assert restored is None

    def test_roundtrip_tuple(self):
        """Test tuple roundtrip (becomes list in pickle)."""
        original = (1, 2, 3)
        data = serialize_object(original)
        restored = deserialize_object(data)
        assert restored == original
