"""
Tests for PyTorch integration.
"""

import pytest
import torch
from torch.utils.data import TensorDataset
from unittest.mock import Mock, patch

from ramjetio.pytorch import CachedDataset, CacheCheckpoint


class TestCachedDataset:
    """Test cases for CachedDataset class."""
    
    def test_initialization(self):
        """Test dataset initialization."""
        original_dataset = TensorDataset(torch.randn(100, 10))
        cache = Mock()
        
        cached_dataset = CachedDataset(original_dataset, cache)
        
        assert len(cached_dataset) == 100
        assert cached_dataset.cache == cache
    
    def test_cache_hit(self):
        """Test cache hit scenario."""
        original_dataset = TensorDataset(torch.randn(100, 10))
        cache = Mock()
        cache.get.return_value = torch.randn(10)
        
        cached_dataset = CachedDataset(original_dataset, cache)
        item = cached_dataset[0]
        
        assert cache.get.called
        assert cached_dataset.cache_hits == 1
        assert cached_dataset.cache_misses == 0
    
    def test_cache_miss(self):
        """Test cache miss scenario."""
        original_dataset = TensorDataset(torch.randn(100, 10))
        cache = Mock()
        cache.get.return_value = None
        cache.set.return_value = True
        
        cached_dataset = CachedDataset(original_dataset, cache)
        item = cached_dataset[0]
        
        assert cache.get.called
        assert cache.set.called
        assert cached_dataset.cache_hits == 0
        assert cached_dataset.cache_misses == 1
    
    def test_custom_key_function(self):
        """Test custom key generation function."""
        original_dataset = TensorDataset(torch.randn(100, 10))
        cache = Mock()
        cache.get.return_value = None
        
        key_fn = lambda idx: f"custom_key_{idx}"
        cached_dataset = CachedDataset(original_dataset, cache, key_fn=key_fn)
        
        item = cached_dataset[5]
        
        cache.get.assert_called_with("custom_key_5")
    
    def test_cache_stats(self):
        """Test cache statistics."""
        original_dataset = TensorDataset(torch.randn(100, 10))
        cache = Mock()
        cache.get.side_effect = [torch.randn(10), None, torch.randn(10)]
        
        cached_dataset = CachedDataset(original_dataset, cache)
        
        # Access some items
        cached_dataset[0]  # Hit
        cached_dataset[1]  # Miss
        cached_dataset[2]  # Hit
        
        stats = cached_dataset.get_cache_stats()
        
        assert stats["cache_hits"] == 2
        assert stats["cache_misses"] == 1
        assert stats["total_accesses"] == 3
        assert stats["hit_rate"] == pytest.approx(66.67, rel=0.1)


class TestCacheCheckpoint:
    """Test cases for CacheCheckpoint class."""
    
    def test_initialization(self):
        """Test checkpoint manager initialization."""
        cache = Mock()
        checkpoint_mgr = CacheCheckpoint(cache, prefix="test")
        
        assert checkpoint_mgr.cache == cache
        assert checkpoint_mgr.prefix == "test"
    
    def test_save_checkpoint(self):
        """Test saving a checkpoint."""
        cache = Mock()
        cache.set.return_value = True
        
        checkpoint_mgr = CacheCheckpoint(cache)
        state_dict = {"param1": torch.randn(10, 10)}
        
        success = checkpoint_mgr.save(state_dict, "epoch_10")
        
        assert success
        assert cache.set.called
        call_args = cache.set.call_args
        assert "checkpoint:epoch_10" in call_args[0]
    
    def test_load_checkpoint(self):
        """Test loading a checkpoint."""
        cache = Mock()
        state_dict = {"param1": torch.randn(10, 10)}
        cache.get.return_value = state_dict
        
        checkpoint_mgr = CacheCheckpoint(cache)
        loaded = checkpoint_mgr.load("epoch_10")
        
        assert loaded == state_dict
        assert cache.get.called
    
    def test_delete_checkpoint(self):
        """Test deleting a checkpoint."""
        cache = Mock()
        cache.delete.return_value = True
        
        checkpoint_mgr = CacheCheckpoint(cache)
        success = checkpoint_mgr.delete("epoch_10")
        
        assert success
        assert cache.delete.called
    
    def test_exists_checkpoint(self):
        """Test checking if checkpoint exists."""
        cache = Mock()
        cache.exists.return_value = True
        
        checkpoint_mgr = CacheCheckpoint(cache)
        exists = checkpoint_mgr.exists("epoch_10")
        
        assert exists
        assert cache.exists.called
