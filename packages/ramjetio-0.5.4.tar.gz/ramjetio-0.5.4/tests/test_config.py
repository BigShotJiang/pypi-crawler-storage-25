"""
Tests for ramjetio.config module.
"""

import os
import pytest
from unittest.mock import patch


class TestConfig:
    """Test configuration constants and helpers."""

    def test_default_backend_host(self):
        """Test default backend host is grpc.ramjet.io."""
        with patch.dict(os.environ, {}, clear=True):
            # Re-import to pick up env changes
            import importlib
            import ramjetio.config as config_mod
            importlib.reload(config_mod)
            assert config_mod.RAMJET_BACKEND_HOST == "grpc.ramjet.io"

    def test_default_backend_port(self):
        """Test default backend port is 443."""
        with patch.dict(os.environ, {}, clear=True):
            import importlib
            import ramjetio.config as config_mod
            importlib.reload(config_mod)
            assert config_mod.RAMJET_BACKEND_PORT == 443

    def test_custom_backend_host(self):
        """Test custom backend host from env."""
        with patch.dict(os.environ, {"RAMJET_BACKEND_HOST": "custom.host.io"}):
            import importlib
            import ramjetio.config as config_mod
            importlib.reload(config_mod)
            assert config_mod.RAMJET_BACKEND_HOST == "custom.host.io"

    def test_custom_backend_port(self):
        """Test custom backend port from env."""
        with patch.dict(os.environ, {"RAMJET_BACKEND_PORT": "50051"}):
            import importlib
            import ramjetio.config as config_mod
            importlib.reload(config_mod)
            assert config_mod.RAMJET_BACKEND_PORT == 50051

    def test_backend_url_format(self):
        """Test backend URL is composed correctly."""
        with patch.dict(os.environ, {"RAMJET_BACKEND_HOST": "test.io", "RAMJET_BACKEND_PORT": "8080"}):
            import importlib
            import ramjetio.config as config_mod
            importlib.reload(config_mod)
            assert config_mod.RAMJET_BACKEND_URL == "test.io:8080"

    def test_ssl_default_true(self):
        """Test SSL is enabled by default."""
        with patch.dict(os.environ, {}, clear=True):
            import importlib
            import ramjetio.config as config_mod
            importlib.reload(config_mod)
            assert config_mod.RAMJET_BACKEND_USE_SSL is True

    def test_ssl_disabled(self):
        """Test SSL can be disabled."""
        with patch.dict(os.environ, {"RAMJET_BACKEND_USE_SSL": "false"}):
            import importlib
            import ramjetio.config as config_mod
            importlib.reload(config_mod)
            assert config_mod.RAMJET_BACKEND_USE_SSL is False


class TestGetApiKey:
    """Test API key retrieval."""

    def test_api_key_from_env(self):
        """Test getting API key from environment."""
        with patch.dict(os.environ, {"RAMJET_API_KEY": "ramjet_test_key_12345678"}):
            from ramjetio.config import get_api_key
            assert get_api_key() == "ramjet_test_key_12345678"

    def test_api_key_not_set(self):
        """Test None when API key not set."""
        with patch.dict(os.environ, {}, clear=True):
            # Remove RAMJET_API_KEY if present
            os.environ.pop("RAMJET_API_KEY", None)
            from ramjetio.config import get_api_key
            assert get_api_key() is None


class TestIsConfigured:
    """Test configuration validation."""

    def test_configured_with_valid_key(self):
        """Test returns True with valid API key."""
        with patch.dict(os.environ, {"RAMJET_API_KEY": "ramjet_abcdefghijklmnop"}):
            from ramjetio.config import is_configured
            assert is_configured() is True

    def test_not_configured_without_key(self):
        """Test returns False without API key."""
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("RAMJET_API_KEY", None)
            from ramjetio.config import is_configured
            assert is_configured() is False

    def test_not_configured_short_key(self):
        """Test returns False with too-short API key."""
        with patch.dict(os.environ, {"RAMJET_API_KEY": "short"}):
            from ramjetio.config import is_configured
            assert is_configured() is False

    def test_not_configured_empty_key(self):
        """Test returns False with empty API key."""
        with patch.dict(os.environ, {"RAMJET_API_KEY": ""}):
            from ramjetio.config import is_configured
            assert is_configured() is False


class TestDefaults:
    """Test default constants."""

    def test_default_cache_port(self):
        from ramjetio.config import DEFAULT_CACHE_PORT
        assert DEFAULT_CACHE_PORT == 9000

    def test_default_cache_capacity(self):
        from ramjetio.config import DEFAULT_CACHE_CAPACITY
        assert DEFAULT_CACHE_CAPACITY == "100GB"

    def test_heartbeat_interval(self):
        from ramjetio.config import HEARTBEAT_INTERVAL
        assert HEARTBEAT_INTERVAL == 3.0

    def test_metrics_push_interval(self):
        from ramjetio.config import METRICS_PUSH_INTERVAL
        assert METRICS_PUSH_INTERVAL == 3.0

    def test_reconnect_interval(self):
        from ramjetio.config import RECONNECT_INTERVAL
        assert RECONNECT_INTERVAL == 30.0

    def test_max_reconnect_unlimited(self):
        from ramjetio.config import MAX_RECONNECT_ATTEMPTS
        assert MAX_RECONNECT_ATTEMPTS == 0
