"""Mastodon MCP Server package."""
