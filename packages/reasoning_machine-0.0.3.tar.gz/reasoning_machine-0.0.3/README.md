# Reasoning-Machine
A Machine that reasons.

In order to launch it from command line or as a subprocess:
```bash
  echo "Theodotos-Alexandreus: Are language models seeking the Truth, machine?" \
    | uvx reasoning-machine \
        --provider-api-key=sk-proj-... \
        --github-token=ghp_... 
```

Or:
```bash
  pip install reasoning-machine
```
Then:
```Python
  # Python
  import reasoning_machine
```
