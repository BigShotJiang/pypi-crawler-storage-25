"""Interface-specific prompt fragments.

Web runs ship tables and images that the frontend renders via `[TABLE:tbl_…]`
markers and `![alt](/workdir/…)` markdown. CLI runs have no such renderer,
so the model is told to print rows inline and report absolute filesystem
paths. The right fragment is chosen at compose time in `prompts.py` based on
the `interface` contextvar.
"""

VCF_TABLE_RENDERING_WEB = (
    "Result rows are capped at 200 and rendered to the user as a structured table"
    " — each `query_vcf` result includes a `table_id` (e.g. `tbl_a1b2c3d4e5f6`)."
    " In your reply, summarize the findings (counts, ranges, notable rows) and"
    " reference the table as `[TABLE:tbl_a1b2c3d4e5f6]`. **Do NOT restate the"
    " rows in prose** — the user already sees the rendered table. If the user"
    " wants a count rather than rows, write `SELECT count(*) FROM <view> WHERE ...`."
)

VCF_TABLE_RENDERING_CLI = (
    "Result rows are capped at 200 and returned to you as TSV (tab-separated with"
    " a header row and a trailing `(N rows)` line). The user is on a plain-text"
    " terminal with no separate table renderer — **render the rows yourself in"
    " your reply** as a markdown table (or, for very wide schemas, as a vertical"
    " key-value listing). **Do NOT emit `[TABLE:tbl_…]` placeholders** — they"
    " will not render. If the user wants a count rather than rows, write"
    " `SELECT count(*) FROM <view> WHERE ...`."
)

IMAGE_SECTION_WEB = """\
IMAGE RENDERING:
 - When you save an image with bash (`plt.savefig`, etc.), save it under the workdir using a *relative* filename — the bash tool's cwd is already the workdir.
 - In your reply, reference the image as `![alt](/workdir/<relative-path>)`. The leading `/workdir/` is the URL prefix the web UI serves files from. Example: `plt.savefig('plots/coverage.png')` → reference as `![coverage](/workdir/plots/coverage.png)`. If you use a subdirectory like `plots/`, run `mkdir -p plots` first so the save doesn't fail.
 - **Do NOT use absolute filesystem paths** (e.g. `/Users/...`, `/home/...`) in image markdown — the browser cannot load those."""

IMAGE_SECTION_CLI = """\
IMAGE OUTPUT:
 - When you save an image with bash (`plt.savefig`, etc.), save it under the workdir using a *relative* filename — the bash tool's cwd is already the workdir. Example: `plt.savefig('plots/coverage.png')`. If you use a subdirectory like `plots/`, run `mkdir -p plots` first so the save doesn't fail.
 - In your reply, tell the user where the file is using its **absolute filesystem path** (e.g. `Saved plot to /Users/.../plots/coverage.png`) so they can open it directly. Use the workdir path shown in the bash section to build the absolute path.
 - **Do NOT emit `![alt](...)` markdown** — this is a plain-text terminal; the syntax won't render and the user just sees raw markdown."""
