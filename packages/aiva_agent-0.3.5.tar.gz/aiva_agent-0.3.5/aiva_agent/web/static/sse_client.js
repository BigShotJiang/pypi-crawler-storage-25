// Streaming + message rendering for the aiva web UI.
// Talks JSON to /sessions and /files, consumes SSE from POST /sessions/{id}/messages
// via fetch + ReadableStream (native EventSource is GET-only).
// Sessions, dialogs, apiJson, and icon helpers live in sessions.js (same script scope).

const $ = (sel) => document.querySelector(sel);
const state = {
  currentId: null,
  currentMeta: null,
  // Files attached in the Attach dialog *before* a session exists.
  // Flushed into the POST /sessions body on the user's first message,
  // then cleared. Always [] when state.currentId is set.
  pendingSpecs: { vcf: [], bam: [] },
  files: { vcf: [], bam: [] },
  toolCalls: new Map(),
  // streamingEl is the currently *writable* assistant div; nulled on tool_start
  // so the next token opens a fresh div below the tool. turnStreamingEls is the
  // audit log of every assistant div this turn so onFinal can drop earlier
  // partial-text divs.
  streamingEl: null,
  turnStreamingEls: [],
};

const resetTurnState = () => {
  state.streamingEl = null;
  state.turnStreamingEls = [];
  state.toolCalls.clear();
};

document.addEventListener("DOMContentLoaded", async () => {
  marked.setOptions({ gfm: true, breaks: false, mangle: false, headerIds: false });
  bindUI();
  renderHeader(null);
  await Promise.all([loadFiles(), refreshSessions()]);
});

function startNewSession() {
  state.currentId = null;
  state.currentMeta = null;
  state.pendingSpecs = { vcf: [], bam: [] };
  $("#chat").replaceChildren();
  renderHeader(null);
  refreshSessions();
  $("#prompt").focus();
}

// Allow http/https images plus inline base64 (LLM tools can return PNG/JPEG/SVG
// data URIs). Without this, DOMPurify strips data: src attributes.
const _PURIFY_OPTS = {
  ADD_TAGS: ["img"],
  ALLOWED_URI_REGEXP: /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|cid|xmpp|data):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i,
};

function renderMarkdown(text) {
  return DOMPurify.sanitize(marked.parse(rewriteTableCitations(text)), _PURIFY_OPTS);
}

function bindUI() {
  $("#tab-sessions").addEventListener("click", () => setActiveTab("sessions"));
  $("#tab-files").addEventListener("click", async () => {
    setActiveTab("files");
    await loadFiles();
  });
  $("#new-session").addEventListener("click", startNewSession);
  $("#open-bindings").addEventListener("click", openBindingsDialog);
  $("#bindings-cancel").addEventListener("click", () => $("#bindings-dialog").close());
  $("#bindings-form").addEventListener("submit", onBindingsSave);
  $("#bindings-search").addEventListener("input", onSearchInput);
  $("#bindings-select-all").addEventListener("click", selectAllFiltered);
  for (const btn of document.querySelectorAll(".bindings-filter-btn")) {
    btn.addEventListener("click", onFilterClick);
  }
  $("#composer").addEventListener("submit", onSendMessage);
  $("#prompt").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      $("#composer").requestSubmit();
    }
  });
  bindLightbox();
}

function bindLightbox() {
  const lightbox = $("#lightbox");
  const lightboxImg = $("#lightbox-img");
  $("#chat").addEventListener("click", (e) => {
    const t = e.target;
    if (t && t.tagName === "IMG" && t.closest(".msg.assistant")) {
      lightboxImg.src = t.src;
      lightboxImg.alt = t.alt || "";
      lightbox.showModal();
    }
  });
  lightbox.addEventListener("click", () => lightbox.close());
}

function buildToolDetails(toolName) {
  const details = document.createElement("details");
  details.className = "tool";
  details.open = false;
  const summary = document.createElement("summary");
  const strong = document.createElement("strong");
  strong.textContent = "[tool]";
  summary.append(strong, " ", document.createTextNode(toolName));
  const status = document.createElement("span");
  status.className = "status";
  status.textContent = " running…";
  summary.appendChild(status);
  details.appendChild(summary);
  return details;
}

function markToolDone(target, truncated) {
  const status = target.querySelector(".status");
  if (!status) return;
  status.textContent = " done" + (truncated ? " (truncated)" : "");
  status.classList.add("done");
}

function appendToolOutput(target, text) {
  const out = document.createElement("pre");
  out.textContent = text;
  target.appendChild(out);
}

async function onSendMessage(e) {
  e.preventDefault();
  const promptEl = $("#prompt");
  const prompt = promptEl.value.trim();
  if (!prompt) return;

  const sendBtn = $("#send");
  sendBtn.disabled = true;

  try {
    if (!state.currentId) {
      const meta = await createBlankSession(prompt, state.pendingSpecs);
      if (!meta) return;
      state.currentId = meta.id;
      state.pendingSpecs = { vcf: [], bam: [] };
      renderHeader(meta);
      refreshSessions();
    }

    appendUserMessage(prompt);
    promptEl.value = "";
    resetTurnState();

    await streamPost(`/sessions/${encodeURIComponent(state.currentId)}/messages`, { prompt });
  } catch (err) {
    appendError(String(err));
  } finally {
    sendBtn.disabled = false;
    // Don't refresh sessions here — the only thing that changed is
    // last_message_at, and a full list rebuild on every send is wasteful.
    // The list refreshes on next user navigation.
  }
}

async function createBlankSession(prompt, specs) {
  const res = await apiJson("/sessions", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: prompt.slice(0, 60),
      vcf: (specs && specs.vcf) || [],
      bam: (specs && specs.bam) || [],
    }),
  });
  if (!res) return null;
  return res.json();
}

async function streamPost(url, body) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`${res.status}: ${text}`);
  }
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    let idx;
    while ((idx = buf.indexOf("\n\n")) !== -1) {
      const frame = buf.slice(0, idx);
      buf = buf.slice(idx + 2);
      handleFrame(frame);
    }
  }
}

function handleFrame(frame) {
  let event = "message";
  // Per the SSE spec, multiple `data:` lines in one frame are concatenated
  // with `\n` (not stripped/joined) so multi-line payloads survive intact.
  // The leading space after `data:` is the optional separator and stripped.
  const dataLines = [];
  for (const line of frame.split("\n")) {
    if (line.startsWith("event:")) {
      event = line.slice(6).trim();
    } else if (line.startsWith("data:")) {
      const rest = line.slice(5);
      dataLines.push(rest.startsWith(" ") ? rest.slice(1) : rest);
    }
  }
  const data = dataLines.join("\n");
  if (!data) return;
  let payload;
  try {
    payload = JSON.parse(data);
  } catch {
    return;
  }
  dispatch(event, payload);
}

function dispatch(event, payload) {
  if (event === "token") onToken(payload.delta);
  else if (event === "tool_start") onToolStart(payload);
  else if (event === "tool_end") onToolEnd(payload);
  else if (event === "final") onFinal(payload.text);
  else if (event === "error") appendError(payload.message);
}

function appendUserMessage(text) {
  const div = document.createElement("div");
  div.className = "msg user";
  div.textContent = text;
  $("#chat").appendChild(div);
  scrollChatIfPinned();
}

function startAssistantStream() {
  const el = document.createElement("div");
  el.className = "msg assistant";
  $("#chat").appendChild(el);
  state.streamingEl = el;
  state.turnStreamingEls.push(el);
  scrollChatIfPinned();
  return el;
}

function onToken(delta) {
  const el = state.streamingEl || startAssistantStream();
  el.textContent += delta;
  scrollChatIfPinned();
}

function onToolStart(p) {
  // Seal the active streaming div so next tokens open a fresh one below the
  // tool, preserving event arrival order in the DOM.
  state.streamingEl = null;
  const details = buildToolDetails(p.tool_name);
  $("#chat").appendChild(details);
  if (p.call_id) state.toolCalls.set(p.call_id, details);
  scrollChatIfPinned();
}

function onToolEnd(p) {
  const details = p.call_id ? state.toolCalls.get(p.call_id) : null;
  const target = details || lastTool();
  if (!target) return;
  markToolDone(target, !!p.truncated);
  if (p.display && p.display.type === "table") {
    appendToolTable(target, p.display, p.table_id);
    rememberTable(p.table_id, p.display);
  } else if (p.output_preview) {
    appendToolOutput(target, p.output_preview);
  }
  scrollChatIfPinned();
}

function onFinal(text) {
  // The server's `final` payload is the agent's final_output (whole final
  // assistant turn). If we split the stream into multiple divs around
  // interleaved tool calls, drop the earlier partial divs and keep just
  // one rendered div in the latest position.
  if (state.turnStreamingEls.length === 0) startAssistantStream();
  const target = state.turnStreamingEls.at(-1);
  for (const el of state.turnStreamingEls.slice(0, -1)) el.remove();
  setSanitizedHTML(target, renderMarkdown(text || target.textContent));
  expandTableCites(target);
  resetTurnState();
  scrollChatIfPinned();
}

function appendError(message) {
  const div = document.createElement("div");
  div.className = "error";
  div.textContent = "error: " + message;
  $("#chat").appendChild(div);
  resetTurnState();
  scrollChatIfPinned();
}

function lastTool() {
  const tools = $("#chat").querySelectorAll(".tool");
  return tools.length ? tools[tools.length - 1] : null;
}

// Pin-to-bottom unless the user has scrolled up to read earlier output.
// The 80px threshold absorbs sub-pixel rounding and small layout shifts.
function scrollChatIfPinned() {
  const chat = $("#chat");
  const distanceFromBottom = chat.scrollHeight - chat.scrollTop - chat.clientHeight;
  if (distanceFromBottom <= 80) chat.scrollTop = chat.scrollHeight;
}
