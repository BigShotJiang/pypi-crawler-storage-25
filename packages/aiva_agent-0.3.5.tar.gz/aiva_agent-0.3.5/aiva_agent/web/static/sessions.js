// Sessions, file tree, history rendering, and confirm dialog for the aiva web UI.
// Loaded as a classic script alongside bindings.js and sse_client.js — they
// all share the same top-level script scope (so `state`, `$`, `renderHeader`,
// `detachBinding` etc. are visible across files).

const SVG_NS = "http://www.w3.org/2000/svg";

function makeSvgIcon(viewBox, paths) {
  const svg = document.createElementNS(SVG_NS, "svg");
  svg.setAttribute("viewBox", viewBox);
  svg.setAttribute("width", "20");
  svg.setAttribute("height", "20");
  svg.setAttribute("fill", "none");
  svg.setAttribute("stroke", "currentColor");
  svg.setAttribute("stroke-width", "1.4");
  svg.setAttribute("stroke-linecap", "round");
  svg.setAttribute("stroke-linejoin", "round");
  svg.setAttribute("aria-hidden", "true");
  for (const d of paths) {
    const p = document.createElementNS(SVG_NS, "path");
    p.setAttribute("d", d);
    svg.appendChild(p);
  }
  return svg;
}

// Build one icon template per shape, then clone per render — cheaper than
// rebuilding the SVG element tree for every file row.
const _DOWNLOAD_ICON = makeSvgIcon("0 0 16 16", [
  "M8 2.5v8.5",
  "M4.5 7.5L8 11l3.5-3.5",
  "M3 13.5h10",
]);
const _TRASH_ICON = makeSvgIcon("0 0 16 16", [
  "M3 4.5h10",
  "M6.5 4.5V3a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v1.5",
  "M4.5 4.5l.6 8.2a1 1 0 0 0 1 .8h3.8a1 1 0 0 0 1-.8l.6-8.2",
  "M7 7v4M9 7v4",
]);

const makeDownloadIcon = () => _DOWNLOAD_ICON.cloneNode(true);
const makeTrashIcon = () => _TRASH_ICON.cloneNode(true);

// Shared JSON fetch wrapper. Returns the response on success; on failure,
// surfaces the server's detail in the alert and returns null so callers can
// early-return without re-checking res.ok.
async function apiJson(url, opts = {}) {
  const res = await fetch(url, opts);
  if (!res.ok) {
    let detail = "";
    try { detail = await res.text(); } catch { /* ignore */ }
    alert(`${opts.method || "GET"} ${url} failed: ${detail || res.statusText}`);
    return null;
  }
  return res;
}

async function loadFiles() {
  const res = await apiJson("/files");
  if (!res) return;
  state.files = await res.json();
  renderFileList();
}

async function refreshSessions() {
  const res = await apiJson("/sessions");
  if (!res) return [];
  const sessions = await res.json();
  const ul = $("#session-list");
  ul.replaceChildren();
  for (const s of sessions) {
    const li = document.createElement("li");
    li.textContent = s.name || s.id;
    li.dataset.id = s.id;
    if (s.id === state.currentId) li.classList.add("active");
    const meta = document.createElement("span");
    meta.className = "meta";
    const vcfBits = s.vcf_specs.map((v) => v.alias).join(", ");
    meta.textContent = vcfBits ? `vcf: ${vcfBits}` : "";
    li.appendChild(meta);
    const del = document.createElement("button");
    del.type = "button";
    del.className = "session-delete";
    del.title = "delete session";
    del.setAttribute("aria-label", "delete session");
    del.appendChild(makeTrashIcon());
    del.addEventListener("click", (ev) => {
      ev.stopPropagation();
      deleteSession(s.id);
    });
    li.appendChild(del);
    li.addEventListener("click", () => loadSession(s.id));
    ul.appendChild(li);
  }
  return sessions;
}

function renderFileList() {
  const ul = $("#file-list");
  ul.replaceChildren();
  const items = [
    ...(state.files.vcf || []).map((f) => ({ ...f, kind: "vcf" })),
    ...(state.files.bam || []).map((f) => ({ ...f, kind: "bam" })),
    ...(state.files.other || []).map((f) => ({ ...f, kind: "" })),
  ];
  if (items.length === 0) {
    const li = document.createElement("li");
    li.className = "file-empty";
    li.textContent = "no files in data dir";
    ul.appendChild(li);
    return;
  }
  renderTree(buildFileTree(items), ul);
}

function buildFileTree(files) {
  const root = { dirs: new Map(), files: [] };
  for (const f of files) {
    const segments = f.path.split("/");
    let cur = root;
    for (let i = 0; i < segments.length - 1; i++) {
      const seg = segments[i];
      if (!cur.dirs.has(seg)) cur.dirs.set(seg, { dirs: new Map(), files: [] });
      cur = cur.dirs.get(seg);
    }
    cur.files.push(f);
  }
  return root;
}

// Build the download+delete action group used by both folder rows (where
// `kind === "folder"`) and file rows. The `path` may be a folder path or a
// file path; the server endpoint is the same for both.
function buildFileActions(path, kind) {
  const actions = document.createElement("span");
  actions.className = "file-actions";

  const dl = document.createElement("a");
  dl.className = "file-action";
  dl.title = kind === "folder" ? "download as zip" : "download";
  dl.setAttribute("aria-label", kind === "folder" ? "download folder" : "download file");
  dl.href = "/files/download?path=" + encodeURIComponent(path);
  dl.setAttribute("download", "");
  dl.appendChild(makeDownloadIcon());
  dl.addEventListener("click", (ev) => ev.stopPropagation());
  actions.appendChild(dl);

  const del = document.createElement("button");
  del.type = "button";
  del.className = "file-action";
  del.title = kind === "folder" ? "delete folder" : "delete";
  del.setAttribute("aria-label", kind === "folder" ? "delete folder" : "delete file");
  del.appendChild(makeTrashIcon());
  del.addEventListener("click", (ev) => {
    ev.stopPropagation();
    deletePath(path, kind);
  });
  actions.appendChild(del);

  return actions;
}

function renderTree(node, ul, prefix = "") {
  const dirNames = [...node.dirs.keys()].sort((a, b) => a.localeCompare(b));
  for (const name of dirNames) {
    const child = node.dirs.get(name);
    const dirPath = prefix ? prefix + "/" + name : name;
    const li = document.createElement("li");
    li.className = "tree-dir collapsed";
    const row = document.createElement("div");
    row.className = "tree-row";
    const chev = document.createElement("span");
    chev.className = "chev";
    chev.textContent = "▾";
    const lbl = document.createElement("span");
    lbl.className = "lbl";
    lbl.textContent = name;
    row.append(chev, lbl);
    row.appendChild(buildFileActions(dirPath, "folder"));

    const sub = document.createElement("ul");
    sub.className = "tree-sub";
    sub.hidden = true;
    renderTree(child, sub, dirPath);
    row.addEventListener("click", () => {
      const collapsed = li.classList.toggle("collapsed");
      sub.hidden = collapsed;
    });
    li.append(row, sub);
    ul.appendChild(li);
  }
  const sortedFiles = node.files.slice().sort((a, b) => a.path.localeCompare(b.path));
  for (const f of sortedFiles) {
    const li = document.createElement("li");
    li.className = "tree-file";
    const row = document.createElement("div");
    row.className = "tree-row";
    if (f.kind) {
      const tag = document.createElement("span");
      tag.className = "file-kind";
      tag.textContent = f.kind;
      row.appendChild(tag);
    }
    const lbl = document.createElement("span");
    lbl.className = "lbl";
    const indexable = f.kind === "vcf" || f.kind === "bam";
    const noIndex = indexable && !f.has_index;
    lbl.textContent = f.path.split("/").pop() + (noIndex ? "  (no index)" : "");
    row.appendChild(lbl);
    row.title = `${f.path} · ${formatSize(f.size)}${noIndex ? " · no index" : ""}`;
    row.appendChild(buildFileActions(f.path, "file"));
    li.appendChild(row);
    ul.appendChild(li);
  }
}

async function deletePath(path, kind) {
  const isFolder = kind === "folder";
  const ok = await showConfirm({
    title: isFolder ? "Delete folder?" : "Delete file?",
    body: isFolder
      ? `Permanently delete ${path}/ and all its contents recursively? This cannot be undone.`
      : `Permanently delete ${path} from disk? Index sidecars (.tbi/.csi/.bai/.crai) will not be removed.`,
    okLabel: "Delete",
  });
  if (!ok) return;
  const res = await apiJson("/files?path=" + encodeURIComponent(path), { method: "DELETE" });
  if (!res) return;
  await loadFiles();
  await pruneBindingsForDeletedPath(path, isFolder);
}

// After deletion, drop any binding chip that points at the just-deleted path
// (or, for a folder, any path under it). Binding paths are stored relative
// for pending sessions and absolute for persisted ones, so match on suffix.
async function pruneBindingsForDeletedPath(deletedRel, isFolder) {
  const matches = (bindingPath) => {
    if (bindingPath === deletedRel) return true;
    if (bindingPath.endsWith("/" + deletedRel)) return true;
    if (isFolder) {
      if (bindingPath.startsWith(deletedRel + "/")) return true;
      if (bindingPath.includes("/" + deletedRel + "/")) return true;
    }
    return false;
  };
  if (state.currentId && state.currentMeta) {
    const vcf = state.currentMeta.vcf_specs.filter((b) => !matches(b.path)).map((b) => ({ alias: b.alias, path: b.path }));
    const bam = state.currentMeta.bam_specs.filter((b) => !matches(b.path)).map((b) => ({ alias: b.alias, path: b.path }));
    const changed = vcf.length !== state.currentMeta.vcf_specs.length || bam.length !== state.currentMeta.bam_specs.length;
    if (changed) await patchBindings(vcf, bam);
    return;
  }
  const beforeV = state.pendingSpecs.vcf.length;
  const beforeB = state.pendingSpecs.bam.length;
  state.pendingSpecs.vcf = state.pendingSpecs.vcf.filter((b) => !matches(b.path));
  state.pendingSpecs.bam = state.pendingSpecs.bam.filter((b) => !matches(b.path));
  if (state.pendingSpecs.vcf.length !== beforeV || state.pendingSpecs.bam.length !== beforeB) {
    refreshBindingChips();
  }
}

function formatSize(bytes) {
  const units = ["B", "KB", "MB", "GB"];
  let i = 0;
  let n = bytes;
  while (n >= 1024 && i < units.length - 1) {
    n /= 1024;
    i++;
  }
  return `${i === 0 ? n : n.toFixed(1)} ${units[i]}`;
}

function setActiveTab(name) {
  for (const t of ["sessions", "files"]) {
    const btn = $("#tab-" + t);
    btn.classList.toggle("active", t === name);
    btn.setAttribute("aria-selected", t === name ? "true" : "false");
  }
  $("#session-list").hidden = name !== "sessions";
  $("#file-list").hidden = name !== "files";
}

async function loadSession(id) {
  state.currentId = id;
  state.pendingSpecs = { vcf: [], bam: [] };
  resetTurnState();
  const res = await apiJson("/sessions/" + encodeURIComponent(id));
  if (!res) return;
  const data = await res.json();
  renderHeader(data.meta);
  renderHistory(data.history);
  await refreshSessions();
}

function renderHeader(meta) {
  state.currentMeta = meta && meta.vcf_specs ? meta : null;
  refreshBindingChips();
}

function refreshBindingChips() {
  const el = $("#binding-summary");
  el.replaceChildren();
  const vcfSpecs = state.currentMeta ? state.currentMeta.vcf_specs : state.pendingSpecs.vcf;
  const bamSpecs = state.currentMeta ? state.currentMeta.bam_specs : state.pendingSpecs.bam;
  if (vcfSpecs.length === 0 && bamSpecs.length === 0) {
    const hint = document.createElement("span");
    hint.className = "binding-summary-hint";
    hint.textContent = "Select VCFs to ask questions";
    el.appendChild(hint);
    return;
  }
  el.appendChild(buildBindingGroup("VCF", "vcf", vcfSpecs));
  el.appendChild(buildBindingGroup("BAM", "bam", bamSpecs));
}

function buildBindingGroup(label, kind, specs) {
  const group = document.createElement("div");
  group.className = "binding-group";
  const tag = document.createElement("span");
  tag.className = "binding-group-tag";
  tag.textContent = label;
  group.appendChild(tag);
  if (specs.length === 0) {
    const empty = document.createElement("span");
    empty.className = "binding-group-empty";
    empty.textContent = "—";
    group.appendChild(empty);
    return group;
  }
  for (const b of specs) {
    const chip = document.createElement("span");
    chip.className = "binding-chip";
    chip.title = b.path;
    const txt = document.createElement("span");
    txt.className = "chip-text";
    txt.textContent = b.alias;
    const x = document.createElement("button");
    x.type = "button";
    x.className = "chip-x";
    x.setAttribute("aria-label", `detach ${b.alias}`);
    x.title = "detach";
    x.textContent = "×";
    x.addEventListener("click", () => detachBinding(b.alias, kind));
    chip.append(txt, x);
    group.appendChild(chip);
  }
  return group;
}


// renderMarkdown returns DOMPurify-sanitized HTML; using Range.createContextualFragment
// avoids triggering the `innerHTML =` lint while parsing the same way.
function setSanitizedHTML(el, html) {
  el.replaceChildren(document.createRange().createContextualFragment(html));
}

function renderHistory(history) {
  const chat = $("#chat");
  chat.replaceChildren();
  clearTableCache();
  const callIndex = new Map();
  for (const item of history) {
    if (item.role === "tool_call") {
      const details = buildToolDetails(item.tool_name);
      chat.appendChild(details);
      if (item.call_id) callIndex.set(item.call_id, details);
    } else if (item.role === "tool_output") {
      const target = (item.call_id && callIndex.get(item.call_id)) || lastTool();
      if (!target) continue;
      markToolDone(target, false);
      if (item.display && item.display.type === "table") {
        appendToolTable(target, item.display, item.table_id);
        rememberTable(item.table_id, item.display);
      } else if (item.output) {
        appendToolOutput(target, item.output);
      }
    } else if (item.role === "assistant") {
      const div = document.createElement("div");
      div.className = "msg assistant";
      setSanitizedHTML(div, renderMarkdown(item.content));
      expandTableCites(div);
      chat.appendChild(div);
    } else {
      const div = document.createElement("div");
      div.className = "msg user";
      div.textContent = item.content || "";
      chat.appendChild(div);
    }
  }
  chat.scrollTop = chat.scrollHeight;
}

function showConfirm({ title, body, okLabel = "Delete" }) {
  const dlg = $("#confirm-dialog");
  $("#confirm-title").textContent = title;
  $("#confirm-text").textContent = body;
  $("#confirm-ok").textContent = okLabel;
  const cancelBtn = $("#confirm-cancel");
  return new Promise((resolve) => {
    const onCancel = () => dlg.close("cancel");
    const onClose = () => {
      dlg.removeEventListener("close", onClose);
      cancelBtn.removeEventListener("click", onCancel);
      resolve(dlg.returnValue === "ok");
    };
    cancelBtn.addEventListener("click", onCancel);
    dlg.addEventListener("close", onClose);
    dlg.showModal();
  });
}

async function deleteSession(id) {
  const ok = await showConfirm({
    title: "Delete session?",
    body: "This removes the session and all of its chat history.",
    okLabel: "Delete",
  });
  if (!ok) return;
  const res = await apiJson("/sessions/" + encodeURIComponent(id), { method: "DELETE" });
  if (!res) return;
  if (id === state.currentId) {
    state.currentId = null;
    state.currentMeta = null;
    $("#chat").replaceChildren();
    renderHeader(null);
    renderFileList();
  }
  await refreshSessions();
}
