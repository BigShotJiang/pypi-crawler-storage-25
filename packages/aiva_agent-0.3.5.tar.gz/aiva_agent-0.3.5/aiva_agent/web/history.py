"""SDK-shape → frontend-shape translation for session history items.

The Agents SDK stores raw OpenAI-style items in SQLiteSession; the web UI wants
a flatter set of `{role, content}` / `{role: "tool_call|tool_output", ...}`
records. Keeping this translation out of the route module so route code stays
focused on request handling.
"""

from __future__ import annotations

import json
import re
from contextlib import asynccontextmanager
from typing import Any

from ..tools._shared import extract_display, truncate_tool_output

_TEXT_KEYS = ("text", "input_text", "output_text")
_CTRL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def normalize_history_item(item: Any) -> dict[str, Any] | None:
    """Map raw SDK session items onto the shapes the frontend expects.

    Returns one of:
      - {role: "user"|"assistant", content: str}
      - {role: "tool_call", call_id, tool_name, arguments}
      - {role: "tool_output", call_id, output}
    or None if the item isn't user-visible.
    """
    if not isinstance(item, dict):
        return None
    item_type = item.get("type")
    if item_type == "function_call":
        return {
            "role": "tool_call",
            "call_id": item.get("call_id"),
            "tool_name": item.get("name") or "tool",
            "arguments": item.get("arguments", ""),
        }
    if item_type == "function_call_output":
        raw = _as_text(item.get("output"))
        envelope = extract_display(raw)
        if envelope is not None:
            return {
                "role": "tool_output",
                "call_id": item.get("call_id"),
                "table_id": envelope.get("table_id"),
                "display": envelope["display"],
                "message": envelope.get("message"),
            }
        text, _ = truncate_tool_output(raw)
        return {
            "role": "tool_output",
            "call_id": item.get("call_id"),
            "output": text,
        }
    role = item.get("role")
    if role in {"user", "assistant"}:
        return {"role": role, "content": _strip_control(_extract_text(item.get("content", "")))}
    return None


def _extract_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if not isinstance(content, list):
        return ""
    parts: list[str] = []
    for piece in content:
        if isinstance(piece, str):
            parts.append(piece)
            continue
        if isinstance(piece, dict):
            for key in _TEXT_KEYS:
                val = piece.get(key)
                if isinstance(val, str):
                    parts.append(val)
                    break
    return "".join(parts)


def _as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, default=str)
    except (TypeError, ValueError):
        return str(value)


def _strip_control(s: str) -> str:
    return _CTRL_RE.sub("", s)


@asynccontextmanager
async def open_sqlite_session(db_path: str, session_id: str):
    """Open a SQLiteSession, yield it, and reliably close it whether `close`
    is sync or async (the SDK has shipped both shapes)."""
    from agents import SQLiteSession

    session = SQLiteSession(session_id, db_path)
    try:
        yield session
    finally:
        close = getattr(session, "close", None)
        if close is not None:
            res = close()
            if hasattr(res, "__await__"):
                await res
