import re
from pathlib import Path
from typing import Callable

import duckdb
from agents import function_tool

from ._shared import (
    ALIAS_RE as _ALIAS_RE,
    DUCKHTS_ERROR_HINT as _DUCKHTS_ERROR_HINT,
    ROW_LIMIT,
    format_table_response as _format_table_response,
    safe_sql_path as _safe_path,
)

_FORMAT_MARKER_RE = re.compile(
    r"\b(?:Format|Functional annotations)\s*:\s*", re.IGNORECASE
)
_IDENT_SAFE_RE = re.compile(r"[^A-Za-z0-9_]+")
_MIN_PIPE_SUBFIELDS = 3
_MAX_PIPE_SUBFIELDS = 200

# Standard VCF columns surfaced by duckhts read_bcf, in display order.
STANDARD_COLS = ("CHROM", "POS", "ID", "REF", "ALT", "QUAL", "FILTER")
_INFO_PREFIX = "INFO_"
_FORMAT_PREFIX = "FORMAT_"
_SAMPLE_ID_COL = "SAMPLE_ID"
_LONG_SUFFIX = "_long"
_HEADER_RECORD_TYPES = ("INFO", "FORMAT")


def _pipe_format_subfields(description: str | None) -> list[str] | None:
    """Parse a VCF INFO/FORMAT header description for an embedded
    pipe-delimited Format spec, regardless of which annotator wrote it.

    Recognizes the two conventions in the wild:
      VEP CSQ / bcftools BCSQ: "... Format: A|B|C ..."
      snpEff ANN:              "Functional annotations: 'A | B | C'"

    Returns the ordered subfield names (with empty positions preserved as
    empty strings), or None if no spec is present. The caller sanitizes
    individual names before turning them into DuckDB identifiers.
    """
    if not description:
        return None
    s = description.strip()
    if len(s) >= 2 and s[0] == s[-1] and s[0] in ('"', "'"):
        s = s[1:-1]
    m = _FORMAT_MARKER_RE.search(s)
    if not m:
        return None
    body = s[m.end():].strip()
    if len(body) >= 2 and body[0] == body[-1] and body[0] in ('"', "'"):
        body = body[1:-1]
    body = body.rstrip(" \t.;")
    if "|" not in body:
        return None
    parts = [p.strip() for p in body.split("|")]
    if len(parts) < _MIN_PIPE_SUBFIELDS or len(parts) > _MAX_PIPE_SUBFIELDS:
        return None
    return parts


def _sanitize_subfield(name: str) -> str:
    """Coerce a raw subfield name into a safe DuckDB identifier suffix.
    Returns "" if nothing usable remains."""
    s = _IDENT_SAFE_RE.sub("_", name.lower()).strip("_")
    if not s:
        return ""
    if s[0].isdigit():
        s = "_" + s
    return s


def _open_connection(specs: list[tuple[str, Path]]) -> duckdb.DuckDBPyConnection:
    if not specs:
        raise ValueError("at least one (alias, path) spec is required")
    con = duckdb.connect(":memory:")
    try:
        con.execute("INSTALL duckhts FROM community;")
        con.execute("LOAD duckhts;")
    except Exception as e:
        if "GLIBC_" in str(e):
            raise RuntimeError(_DUCKHTS_ERROR_HINT.format(err=e)) from e
        raise
    for alias, path in specs:
        if not _ALIAS_RE.match(alias):
            raise ValueError(f"invalid view alias: {alias!r}")
        safe = _safe_path(path)
        con.execute(f"CREATE VIEW {alias} AS SELECT * FROM read_bcf('{safe}')")
        con.execute(
            f"CREATE VIEW {alias}{_LONG_SUFFIX} AS "
            f"SELECT * FROM read_bcf('{safe}', tidy_format:=true)"
        )
        _register_pipe_format_macros(con, alias, path)
    return con


def view_aliases(specs: list[tuple[str, Path]]) -> list[tuple[str, Path]]:
    """Expand each (alias, path) spec into the (view_alias, path) pairs that
    `_open_connection` actually registers — `{alias}` (wide) and
    `{alias}_long` (tidy)."""
    out: list[tuple[str, Path]] = []
    for alias, path in specs:
        out.append((alias, path))
        out.append((f"{alias}{_LONG_SUFFIX}", path))
    return out


def _iter_pipe_format_records(
    con: duckdb.DuckDBPyConnection, path: Path
) -> list[tuple[str, str, list[tuple[int, str]]]]:
    """One pass over the VCF header: yield (record_type, field_id, subfields)
    for every INFO/FORMAT record whose description carries a pipe-delimited
    Format spec. Each subfield is `(pipe_index_1based, sanitized_name)`,
    with empty / duplicate positions dropped — the index is preserved from
    the original spec so macro bodies can use it directly."""
    rows = con.execute(
        f"SELECT record_type, id, description FROM read_hts_header('{_safe_path(path)}') "
        f"WHERE record_type IN {_HEADER_RECORD_TYPES!r}"
    ).fetchall()
    out: list[tuple[str, str, list[tuple[int, str]]]] = []
    for record_type, fid, description in rows:
        subs = _pipe_format_subfields(description)
        if not subs or not _ALIAS_RE.match(fid or ""):
            continue
        seen: set[str] = set()
        sanitized: list[tuple[int, str]] = []
        for raw_idx, raw_name in enumerate(subs):
            name = _sanitize_subfield(raw_name)
            if not name or name in seen:
                continue
            seen.add(name)
            sanitized.append((raw_idx + 1, name))
        if sanitized:
            out.append((record_type, fid, sanitized))
    return out


def _register_pipe_format_macros(
    con: duckdb.DuckDBPyConnection, alias: str, path: Path
) -> None:
    """Register one DuckDB scalar macro per pipe-delimited subfield declared
    in the VCF header. Macros are named `{alias}_{lower(field_id)}_{subfield}`
    so multiple pipe-delimited fields per file (e.g. CSQ + AIVA_CSQ) and
    multi-VCF mode both stay collision-free. Each macro takes the raw blob
    column and returns LIST<VARCHAR> per record — the column reference is
    passed in as an argument, so region predicates on the base view still
    hit duckhts' tabix index when used.

    duckhts auto-splits Number=. String INFO fields to VARCHAR[]; some
    arrive as VARCHAR. The macro body is chosen per field from the view's
    column dtype.
    """
    col_types: dict[str, str] = {
        row[0]: row[1] for row in con.execute(f"DESCRIBE {alias}").fetchall()
    }
    for record_type, fid, sanitized in _iter_pipe_format_records(con, path):
        if record_type == "INFO":
            col_name = _INFO_PREFIX + fid
        else:
            sample_prefix = f"{_FORMAT_PREFIX}{fid}_"
            col_name = next(
                (c for c in col_types if c.startswith(sample_prefix)), None
            )
        if not col_name:
            continue
        is_list = col_types.get(col_name, "").endswith("[]")
        for pipe_idx, name in sanitized:
            macro = f"{alias}_{fid.lower()}_{name}"
            if not _ALIAS_RE.match(macro):
                continue
            con.execute(
                f"CREATE OR REPLACE MACRO {macro}(blob) AS "
                f"{_macro_body(is_list, pipe_idx)}"
            )


def _macro_body(is_list: bool, pipe_idx: int) -> str:
    if is_list:
        return f"list_transform(blob, t -> string_split(t, '|')[{pipe_idx}])"
    return (
        f"list_transform(string_split(blob, ','), "
        f"t -> string_split(t, '|')[{pipe_idx}])"
    )


def _format_field_ids(con: duckdb.DuckDBPyConnection, path: Path) -> list[str]:
    """Return the FORMAT field IDs declared in the BCF/VCF header."""
    rows = con.execute(
        f"SELECT id FROM read_hts_header('{_safe_path(path)}') WHERE record_type='FORMAT' ORDER BY idx"
    ).fetchall()
    return [r[0] for r in rows]


def _summarize_view(
    con: duckdb.DuckDBPyConnection, alias: str, path: Path
) -> str:
    """Compact, agent-friendly schema summary for one registered view.

    Detects shape from the column list: a `SAMPLE_ID` column means the
    tidy/long companion view (one row per (variant, sample), bare
    FORMAT_<FIELD> columns); otherwise the wide layout
    (FORMAT_<FIELD>_<SAMPLE> per sample). Macros are registered against
    the base alias regardless of which view emits the blob, so the long
    view's pipe-delimited block references the base macro family name.
    """
    cols = con.execute(f"DESCRIBE {alias}").fetchall()
    is_long = any(name == _SAMPLE_ID_COL for name, *_ in cols)
    if is_long:
        return _summarize_long_view(con, alias, path, cols)
    return _summarize_wide_view(con, alias, path, cols)


def _summarize_wide_view(
    con: duckdb.DuckDBPyConnection,
    alias: str,
    path: Path,
    cols: list[tuple],
) -> str:
    standard: list[str] = []
    info: list[str] = []
    format_cols: list[tuple[str, str]] = []
    for name, dtype, *_ in cols:
        if name in STANDARD_COLS:
            standard.append(f"{name} {dtype}")
        elif name.startswith(_INFO_PREFIX):
            info.append(f"{name} {dtype}")
        elif name.startswith(_FORMAT_PREFIX):
            format_cols.append((name, dtype))

    field_ids = _format_field_ids(con, path)
    samples: list[str] = []
    seen_samples: set[str] = set()
    field_types: dict[str, str] = {}
    unparsed: list[str] = []
    for name, dtype in format_cols:
        body = name[len(_FORMAT_PREFIX):]
        matched = False
        for fid in field_ids:
            prefix = fid + "_"
            if body.startswith(prefix):
                sample = body[len(prefix):]
                if sample and sample not in seen_samples:
                    seen_samples.add(sample)
                    samples.append(sample)
                field_types.setdefault(fid, dtype)
                matched = True
                break
        if not matched:
            unparsed.append(name)

    lines = [f"view: {alias}  (wide; one row per variant; path: {path})"]
    lines.append(
        "  standard:  " + ", ".join(standard) if standard else "  standard:  (none)"
    )
    if info:
        lines.append("  INFO:      " + ", ".join(info))
    if samples:
        lines.append(f"  samples ({len(samples)}): " + ", ".join(samples))
    if field_types:
        ordered = [f"{fid} {field_types[fid]}" for fid in field_ids if fid in field_types]
        lines.append(
            "  FORMAT/<sample> (column = FORMAT_<FIELD>_<SAMPLE>): "
            + ", ".join(ordered)
        )
    if unparsed:
        lines.append(f"  unparsed FORMAT columns: {', '.join(unparsed)}")

    _append_pipe_format_block(lines, con, path, alias)
    return "\n".join(lines)


def _summarize_long_view(
    con: duckdb.DuckDBPyConnection,
    alias: str,
    path: Path,
    cols: list[tuple],
) -> str:
    """Render the schema for a tidy/long view (`{alias}_long`). FORMAT data
    is bare `FORMAT_<FIELD>` (no per-sample suffix); a `SAMPLE_ID` column
    keys per-sample rows. Pipe-delimited annotation fields use the same
    `<base_alias>_<field>_<sub>(INFO_<FIELD>)` macros as the wide view."""
    standard: list[str] = []
    info: list[str] = []
    format_cols: list[str] = []
    for name, dtype, *_ in cols:
        if name in STANDARD_COLS or name == _SAMPLE_ID_COL:
            standard.append(f"{name} {dtype}")
        elif name.startswith(_INFO_PREFIX):
            info.append(f"{name} {dtype}")
        elif name.startswith(_FORMAT_PREFIX):
            format_cols.append(f"{name} {dtype}")

    lines = [
        f"view: {alias}  (tidy/long; one row per (variant, sample); path: {path})"
    ]
    lines.append(
        "  standard:  " + ", ".join(standard) if standard else "  standard:  (none)"
    )
    if info:
        lines.append("  INFO:      " + ", ".join(info))
    if format_cols:
        lines.append("  FORMAT (per row, no sample suffix): " + ", ".join(format_cols))

    _append_pipe_format_block(lines, con, path, alias)
    return "\n".join(lines)


def _append_pipe_format_block(
    lines: list[str],
    con: duckdb.DuckDBPyConnection,
    path: Path,
    view_alias: str,
) -> None:
    base_alias = (
        view_alias[: -len(_LONG_SUFFIX)]
        if view_alias.endswith(_LONG_SUFFIX) else view_alias
    )
    records = sorted(_iter_pipe_format_records(con, path), key=lambda r: (r[0], r[1]))
    for record_type, fid, sanitized in records:
        col = f"{record_type}_{fid}"
        macro_prefix = f"{base_alias}_{fid.lower()}_"
        names = [n for _, n in sanitized]
        lines.append(
            f"  {col} (pipe-delimited; {len(names)} subfields, "
            f"macro family: {macro_prefix}<sub>(blob) -> LIST<VARCHAR> per record):"
        )
        for chunk in _wrap_tokens(names, indent="    ", width=88):
            lines.append(chunk)


def _wrap_tokens(tokens: list[str], indent: str, width: int) -> list[str]:
    """Wrap a comma-joined token list into lines no wider than `width` chars."""
    out: list[str] = []
    line = indent
    for tok in tokens:
        sep = "" if line == indent else ", "
        candidate = line + sep + tok
        if len(candidate) > width and line != indent:
            out.append(line)
            line = indent + tok
        else:
            line = candidate
    if line != indent:
        out.append(line)
    return out


def build_vcf_tools(
    vcf_specs: list[tuple[str, Path]],
) -> tuple[list, Callable[[], None]]:
    """Build the duckdb-backed VCF tool palette.

    Each (alias, path) spec is registered as a named DuckDB view. A single
    bare-path invocation should pass `[("vcf", path)]` to keep the legacy
    view name. Returns (tools_list, cleanup_fn). Caller must invoke
    cleanup_fn when the agent run is done so the duckdb connection is closed.
    """
    if not vcf_specs:
        raise ValueError("vcf_specs is required (got empty list)")
    con = _open_connection(vcf_specs)
    view_specs = view_aliases(vcf_specs)

    @function_tool
    async def query_vcf(sql: str) -> str:
        """Run a read-only SQL query against the user's VCF view(s). Each VCF
        spec exposes two DuckDB views: `<alias>` (wide; one row per variant)
        and `<alias>_long` (tidy; one row per (variant, sample)). Returns up
        to 200 rows. Output shape depends on the active interface: on web,
        a structured envelope with a `table_id` for client-side rendering;
        on CLI, plain TSV the model renders in its reply. See the system
        prompt's table-rendering rule for which applies.

        Args:
            sql: A SELECT statement. The result is wrapped in `SELECT * FROM (...) LIMIT 200`.
        """
        try:
            res = con.execute(f"SELECT * FROM ({sql}) LIMIT {ROW_LIMIT}")
            rows = res.fetchall()
            cols = [d[0] for d in res.description]
            return _format_table_response(cols, rows)
        except Exception as e:
            return f"SQL error: {e}"

    @function_tool
    async def vcf_schema() -> str:
        """Return a compact summary of every registered VCF view. Each spec
        contributes two blocks: the wide view (per-variant) and the
        `_long` companion (per-(variant, sample)). Call this once at the
        top of a session before composing queries."""
        blocks = [_summarize_view(con, alias, path) for alias, path in view_specs]
        return "\n\n".join(blocks)

    def cleanup() -> None:
        try:
            con.close()
        except Exception:
            pass

    return [query_vcf, vcf_schema], cleanup
