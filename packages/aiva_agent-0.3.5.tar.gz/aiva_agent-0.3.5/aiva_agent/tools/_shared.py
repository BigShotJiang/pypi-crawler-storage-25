"""Minimal helpers shared across tool modules."""

import json
import re
import secrets
from contextvars import ContextVar
from pathlib import Path
from typing import Any, Literal

Interface = Literal["cli", "web"]

_INTERFACE: ContextVar[Interface] = ContextVar("_INTERFACE", default="cli")


def set_interface(value: Interface) -> None:
    """Record which front-end the current agent run is serving. Read by
    `format_table_response` to decide whether to emit a structured envelope
    (web; the frontend renders the table) or plain TSV (cli; the model
    prints the rows in its reply). Set once at the top of `_prepare_run`."""
    _INTERFACE.set(value)


def get_interface() -> Interface:
    return _INTERFACE.get()

ROW_LIMIT = 200

ALIAS_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

MAX_ALIAS_LEN = 32

RESERVED_ALIASES = frozenset(
    {
        "all", "alter", "and", "any", "as", "asc", "between", "by",
        "case", "cast", "check", "column", "constraint", "create",
        "cross", "current_date", "current_time", "current_timestamp",
        "default", "delete", "desc", "describe", "distinct", "drop",
        "else", "end", "except", "exists", "false", "fetch", "for",
        "foreign", "from", "full", "grant", "group", "having", "in",
        "inner", "insert", "intersect", "into", "is", "join", "left",
        "like", "limit", "natural", "not", "null", "offset", "on",
        "only", "or", "order", "outer", "pivot", "primary", "references",
        "right", "select", "show", "some", "summarize", "table", "then",
        "to", "true", "union", "unique", "unpivot", "update", "using",
        "values", "view", "when", "where", "window", "with",
    }
)

TOOL_OUTPUT_MAX_CHARS = 2000

TABLE_ID_PREFIX = "tbl_"


def truncate_tool_output(text: str, max_chars: int = TOOL_OUTPUT_MAX_CHARS) -> tuple[str, bool]:
    """Cap a tool-output string for display. Returns (text, truncated)."""
    if max_chars <= 0 or len(text) <= max_chars:
        return text, False
    extra = len(text) - max_chars
    return text[:max_chars] + f"…[+{extra} more chars]", True

DUCKHTS_ERROR_HINT = (
    "Failed to load the duckhts DuckDB extension on this host (likely glibc "
    "too old). Try the published container image: "
    "docker.io/mhspl/aiva-agent:latest\n"
    "Underlying error: {err}"
)


def safe_sql_path(p: Path) -> str:
    """Escape a filesystem path for embedding inside a single-quoted SQL literal."""
    return str(p).replace("'", "''")


def format_rows(cols: list[str], rows: list[tuple]) -> str:
    """Render query results as TSV with a trailing row count."""
    if not rows:
        return "(0 rows)"
    header = "\t".join(cols)
    body = "\n".join(
        "\t".join(repr(c) if not isinstance(c, str) else c for c in r) for r in rows
    )
    return f"{header}\n{body}\n({len(rows)} rows)"


def to_json(payload: Any) -> str:
    """Serialize a tool result to a string the agent will see verbatim."""
    if isinstance(payload, str):
        return payload
    return json.dumps(payload, default=str, indent=2)


def make_table_id() -> str:
    """Mint a short, citation-friendly table ID for the agent to reference
    in prose (e.g. `[TABLE:tbl_a1b2c3d4e5f6]`). Per-call uniqueness within
    a session is enough — collisions across sessions are harmless because
    the renderer scopes table_ids to the surrounding tool block."""
    return f"{TABLE_ID_PREFIX}{secrets.token_hex(6)}"


def _coerce_cell(value: Any) -> Any:
    """Make a row cell JSON-safe for the structured envelope.
    Mirrors the str/repr split that `format_rows` uses for TSV output."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (list, tuple)):
        return [_coerce_cell(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _coerce_cell(v) for k, v in value.items()}
    return repr(value)


def format_table_response(
    cols: list[str],
    rows: list[tuple],
    *,
    tool_name: str = "query_vcf",
) -> str:
    """Build the structured 'display envelope' for a tabular tool result
    and return it as a JSON string.

    Returning a string (not a dict) matters for persistence: the OpenAI
    Agents SDK coerces non-string tool returns via `str()` before storing
    them in the session transcript, which produces a Python `repr` (single
    quotes, `True/False`) that downstream `json.loads` cannot parse. By
    pre-serializing here, both the live SSE bridge and the history-replay
    path see the same valid-JSON string and can cleanly extract the
    `display` block.

    On CLI (`set_interface("cli")`) the envelope is bypassed entirely:
    plain TSV is returned so the model can read the rows and print them
    in its reply — the CLI has no parser for `[TABLE:tbl_…]` placeholders.
    """
    if _INTERFACE.get() == "cli":
        return format_rows(cols, rows)
    table_id = make_table_id()
    n = len(rows)
    row_dicts = [
        {col: _coerce_cell(val) for col, val in zip(cols, r)} for r in rows
    ]
    envelope = {
        "success": True,
        "tool_name": tool_name,
        "table_id": table_id,
        "message": (
            f"{n} row{'s' if n != 1 else ''} returned. "
            f"Reference as [TABLE:{table_id}] in your reply; "
            "do not restate rows — the user already sees the rendered table."
        ),
        "display": {
            "type": "table",
            "data": {"columns": list(cols), "rows": row_dicts},
        },
    }
    return json.dumps(envelope, default=str)


def extract_display(text: str) -> dict | None:
    """If `text` is the JSON-serialized form of a table envelope (as
    produced by `format_table_response`), return the parsed dict. Else
    return None. Both the SSE bridge and the history endpoint use this to
    decide whether to ship a structured table or fall back to plain text."""
    if not text or not text.lstrip().startswith("{"):
        return None
    try:
        obj = json.loads(text)
    except (TypeError, ValueError):
        return None
    if not isinstance(obj, dict):
        return None
    display = obj.get("display")
    if not isinstance(display, dict) or display.get("type") != "table":
        return None
    return obj


def extract_json(text: str) -> dict[str, Any] | None:
    """Find the first balanced `{...}` substring and parse it as JSON.

    A naive `\\{.*\\}` regex with `re.DOTALL` is greedy and spans from the
    first `{` to the last `}` in the text, which fuses two adjacent JSON
    objects into one unparsable blob. Brace-counting handles nesting and
    stops at the first balanced object. Quoted strings (which may contain
    unbalanced braces) are skipped over.
    """
    start = text.find("{")
    if start < 0:
        return None
    depth = 0
    i = start
    in_string = False
    while i < len(text):
        c = text[i]
        if in_string:
            if c == "\\":
                i += 2
                continue
            if c == '"':
                in_string = False
        elif c == '"':
            in_string = True
        elif c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(text[start : i + 1])
                except json.JSONDecodeError:
                    return None
        i += 1
    return None
