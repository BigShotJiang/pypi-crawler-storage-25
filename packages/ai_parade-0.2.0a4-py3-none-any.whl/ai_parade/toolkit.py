import ai_parade._compat  # type: ignore # noqa: F401
import ai_parade._toolkit.datasets.loadImageNet as datasets
from ai_parade._toolkit.convert.conversion_error import ConversionError
from ai_parade._toolkit.convert.convert import Convert
from ai_parade._toolkit.inference import inference

from ._toolkit.convert.converter import ConversionResult
from ._toolkit.data.ImageInput import ImageInput
from ._toolkit.data.output import ModelOutput, Output
from ._toolkit.datasets.Dataset import Dataset
from ._toolkit.enums import (
	COMMON_HW_ACCELERATIONS,
	AIRuntime,
	ExactModelFormat,
	HardwareAcceleration,
	ModelFormat,
	Platform,
	Quantization,
	format_suffixes,
	formats_preferred_runtime,
)
from ._toolkit.get_weights import get_weights_name
from ._toolkit.logging import get_ai_parade_logger
from ._toolkit.metadata.custom import Customizations
from ._toolkit.metadata.enums import ModelTasks
from ._toolkit.metadata.models.final import ModelMetadata, PyTorchOptions
from ._toolkit.metadata.parsing import (
	MetadataNotFoundError,
	get_local_metadata,
	parse_metadata,
)
from ._toolkit.run.ModelRunner import LoadedModelRunner
from ._toolkit.run.runner_selector import ModelRunner, get_runner
from ._toolkit.verify import compute_statistics

__all__ = [
	"ModelMetadata",
	"PyTorchOptions",
	"ModelTasks",
	"ModelFormat",
	"AIRuntime",
	"formats_preferred_runtime",
	"ModelOutput",
	"Output",
	"ImageInput",
	"Dataset",
	"datasets",
	"get_runner",
	"LoadedModelRunner",
	"get_local_metadata",
	"parse_metadata",
	"MetadataNotFoundError",
	"ModelRunner",
	"Customizations",
	"get_ai_parade_logger",
	"compute_statistics",
	"Quantization",
	"ExactModelFormat",
	"ConversionResult",
	"Convert",
	"ConversionError",
	"HardwareAcceleration",
	"COMMON_HW_ACCELERATIONS",
	"format_suffixes",
	"Platform",
	"get_weights_name",
	"inference",
]
