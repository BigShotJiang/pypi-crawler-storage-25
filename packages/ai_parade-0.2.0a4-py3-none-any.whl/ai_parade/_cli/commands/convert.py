import asyncio
from pathlib import Path
from typing import Annotated

import typer

from ai_parade._toolkit.datasets.Dataset import DatasetSplit
from ai_parade.toolkit import (
	Convert,
	ExactModelFormat,
	HardwareAcceleration,
	ModelFormat,
	Quantization,
	get_local_metadata,
)

from ._common import (
	NEED_CALIBRATION,
	ArtifactsDirType,
	ModelNameType,
	RepositoryPathType,
	VerboseType,
	WeightsPathType,
	app,
	get_dataset,
)


@app.command()
def convert(
	weights_path: WeightsPathType,
	model_name: ModelNameType,
	model_format: Annotated[
		ModelFormat, typer.Argument(case_sensitive=False, help="Target model format")
	],
	quantization: Annotated[
		Quantization,
		typer.Option(
			"--quantization",
			"--quantize",
			case_sensitive=False,
			help="Quantization of the target model",
		),
	] = Quantization.none,
	hw_acceleration: Annotated[
		HardwareAcceleration,
		typer.Option(
			case_sensitive=False,
			help="Hardware acceleration of the target model. It is used only by Executorch",
		),
	] = HardwareAcceleration.CPU,
	override: Annotated[
		bool,
		typer.Option(
			help="Overwrite already converted weights if they exist (including intermediate ones)."
		),
	] = False,
	# calibration for quantization
	calibration_dataset: Annotated[
		str | None,
		typer.Option(
			"--calibration-dataset",
			help="Dataset name used to calibrate INT4/INT8 conversions. Required for INT4/INT8 conversions.",
		),
	] = None,
	calibration_path: Annotated[
		Path | None,
		typer.Option(
			"--calibration-path",
			help="Path with assets for the calibration dataset (when required).",
		),
	] = None,
	calibration_split: Annotated[
		DatasetSplit,
		typer.Option(
			"--calibration-split",
			case_sensitive=False,
			help="Dataset split to use for calibration.",
		),
	] = DatasetSplit.val,
	calibration_take: Annotated[
		int,
		typer.Option(
			"--calibration-take", help="Number of samples to use for calibration."
		),
	] = 1000,
	calibration_seed: Annotated[
		int,
		typer.Option(
			"--calibration-seed", help="Shuffle seed for the calibration dataset."
		),
	] = 42,
	# verification
	verify: Annotated[
		bool,
		typer.Option(
			help="Run inference before/after conversion and compare.",
		),
	] = False,
	verify_dataset: Annotated[
		str | None,
		typer.Option(
			"--verify-dataset",
			help="Dataset name used for verification. Automatically sets `--verify` to True.",
			show_default="None; Random if `--verify` is set",
		),
	] = None,
	verify_dataset_path: Annotated[
		Path | None,
		typer.Option(
			"--verify-dataset-path",
			help="Path with assets for the verification dataset.",
		),
	] = None,
	verify_split: Annotated[
		DatasetSplit,
		typer.Option(
			"--verify-split",
			case_sensitive=False,
			help="Dataset split to use for verification.",
		),
	] = DatasetSplit.val,
	verify_take: Annotated[
		int,
		typer.Option(
			"--verify-take", help="Number of samples to use for verification."
		),
	] = 100,
	# common
	artifacts: ArtifactsDirType = Path("build"),
	repository_path: RepositoryPathType = Path("."),
	output: Annotated[
		Path,
		typer.Option("--output", "-o", help="Output directory for converted weights."),
	] = Path("."),
	verbose: VerboseType = [],
):
	"""
	Convert an existing model to a different format. Target format can be quantized.
	"""
	assert quantization not in NEED_CALIBRATION or calibration_dataset is not None

	artifacts.mkdir(parents=True, exist_ok=True)
	output.mkdir(parents=True, exist_ok=True)

	metadata_list = asyncio.run(get_local_metadata(repository_path))
	metadata = next(x for x in metadata_list if x.name == model_name)

	if calibration_dataset is not None:
		parsed_calibration_dataset = (
			get_dataset(calibration_dataset, calibration_path, split=calibration_split)
			.shuffle(calibration_seed)
			.take(calibration_take)
		)
	else:
		parsed_calibration_dataset = None

	if verify or verify_dataset is not None:
		parsed_verify_dataset = get_dataset(
			verify_dataset or "Random", verify_dataset_path, split=verify_split
		).take(verify_take)
	else:
		parsed_verify_dataset = None

	results = asyncio.run(
		Convert(
			metadata.format,
			ExactModelFormat(model_format, quantization, hw_acceleration),
			calibration_dataset=parsed_calibration_dataset,
			verify_dataset=parsed_verify_dataset,
			override=override,
			error_immediately=True,
			metadata=metadata,
			output=output,
			artifacts=artifacts,
			default_model=weights_path,
		)()
	)
	if results is not None:
		print(results)
