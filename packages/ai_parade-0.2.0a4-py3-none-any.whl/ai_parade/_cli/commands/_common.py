import logging
import sys
from pathlib import Path
from typing import Annotated

import typer

from ai_parade.datasets import DatasetSplit, ImageNet, ImageNet_VID, Random
from ai_parade.logging import TRACE_LVL
from ai_parade.toolkit import Dataset, Quantization
from ai_parade.toolkit import (
	get_ai_parade_logger as get_toolkit_logger,
)

app = typer.Typer()

RepositoryPathType = Annotated[
	Path,
	typer.Option(
		"--repository",
		"--repo",
		help="Path to repository with pyproject.toml",
		file_okay=False,
		exists=True,
		resolve_path=True,
	),
]

WeightsPathTypeArgDef = typer.Argument(
	help="Path to the model file (all in one file), or directory (if multiple files are needed), or json conversion result.",
	exists=True,
	resolve_path=True,
)
WeightsPathTypeOptional = Annotated[Path | None, WeightsPathTypeArgDef]
WeightsPathType = Annotated[Path, WeightsPathTypeArgDef]

ModelNameTypeArgDef = typer.Argument(
	help="Name of model (as in the [tool.ai-parade.name] property in pyproject.toml file)"
)
ModelNameType = Annotated[str, ModelNameTypeArgDef]
ModelNameTypeOptional = Annotated[str | None, ModelNameTypeArgDef]

ArtifactsDirType = Annotated[
	Path,
	typer.Option(
		help="Directory for artifacts (where logs, dumps etc. will be stored).",
		file_okay=False,
	),
]

NEED_CALIBRATION = [Quantization.int4, Quantization.int8]

verbosity_level = 0


def _set_verbosity(ctx: typer.Context, verbose: "VerboseType"):
	toolkit_logger = get_toolkit_logger()
	this_logger = logging.getLogger("ai_parade._cli")
	global verbosity_level
	verbosity_level = verbose.count(True)

	# Hide traceback frames at verbosity 0 (just `ExceptionType: message`).
	if verbosity_level == 0:
		sys.tracebacklimit = 0
		app.pretty_exceptions_enable = False

	if verbosity_level < 2:
		logging.basicConfig(
			format="[%(levelname)-9s%(asctime)s] %(message)s",
			datefmt="%H:%M:%S",
		)
	else:
		logging.basicConfig(
			format="[%(levelname)-9s%(asctime)s] %(filename)s#%(lineno)d - %(message)s",
			datefmt="%H:%M:%S",
		)
	try:
		match verbosity_level:
			case 0:
				this_logger.setLevel(logging.INFO)
			case 1:
				toolkit_logger.setLevel(logging.INFO)
				this_logger.setLevel(logging.DEBUG)
			case 2:
				toolkit_logger.setLevel(logging.DEBUG)
				this_logger.setLevel(TRACE_LVL)
			case 3:
				toolkit_logger.setLevel(TRACE_LVL)
				this_logger.setLevel(TRACE_LVL)
			case _:
				logging.getLogger().setLevel(TRACE_LVL)
	except Exception as e:
		logging.basicConfig(level=logging.INFO)
		this_logger.error(f"Failed to set verbosity level: {e}")


VerboseType = Annotated[
	list[bool],
	typer.Option(
		"--verbose",
		"-v",
		help="Enable verbose logging, repeat for more verbosity (current max: `-vvvv`)",
		callback=_set_verbosity,
	),
]

ScriptType = Annotated[
	bool,
	typer.Option(
		"--script",
		help="Enable script mode (hide progress bars, etc.)",
	),  # todo: save logs in file
]

FromEnvironmentType = Annotated[
	bool,
	typer.Option(
		"--from-environment",
		help="Lock from the active environment (uv pip freeze + compile, augmented "
		"with `ai-parade[<extras>]` for non-base feature sets).",
	),
]

FromDefinitionsType = Annotated[
	bool,
	typer.Option(
		"--from-definitions",
		help="Lock from definition files (uv.lock or pyproject.toml/requirements/setup).",
	),
]


def get_dataset(
	dataset_name: str, dataset_path: Path | None, split: DatasetSplit
) -> Dataset:
	match dataset_name:
		case "ImageNet":
			if dataset_path is None:
				raise ValueError("Dataset path is required for ImageNet dataset")
			dataset = ImageNet(dataset_path, split)
		case "ImageNet_VID":
			if dataset_path is None:
				raise ValueError("Dataset path is required for ImageNet_VID dataset")
			dataset = ImageNet_VID(dataset_path, split)
		case "Random":
			dataset = Random(seed=442)
		case _:
			raise NotImplementedError(f"Dataset {dataset_name} not implemented")
	return dataset
