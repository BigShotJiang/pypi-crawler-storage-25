import asyncio
import logging
from pathlib import Path

import typer

from ai_parade._toolkit.constants import (
	get_ai_parade_dir,
	get_custom_definitions_path,
)

from .._shared import ExitCode
from ..sync import sync_impl
from ._common import (
	FromDefinitionsType,
	FromEnvironmentType,
	RepositoryPathType,
	VerboseType,
	app,
)

logger = logging.getLogger(__name__)

_CUSTOM_DEFINITIONS_STUB = """\
\"\"\"Customizations for ai-parade.

See: https://docs.ai-parade.example/addModel/customize for the full reference.
\"\"\"
import ai_parade.custom_definitions as aip  # noqa: F401


def include() -> list[aip.ModelMetadataApi]:
	# Return ModelMetadataApi instances here to register models programmatically.
	return []
"""


@app.command()
def init(
	repository: RepositoryPathType = Path("."),
	from_environment: FromEnvironmentType = False,
	from_definitions: FromDefinitionsType = False,
	verbose: VerboseType = [],
):
	"""
	Initialize the ai-parade in a repository (interactive).
	"""

	ai_parade_dir = get_ai_parade_dir(repository)
	if ai_parade_dir.exists():
		if not typer.confirm(
			f"{ai_parade_dir} already exists. Continue and refresh contents?",
			default=True,
		):
			logger.info("Aborted.")
			raise typer.Exit(code=ExitCode.OK)

	asyncio.run(
		sync_impl(
			repository,
			from_environment=from_environment,
			from_definitions=from_definitions,
			allow_local_dependencies=False,
		)
	)

	custom_path = get_custom_definitions_path(repository)
	if not custom_path.exists():
		if typer.confirm(
			f"Scaffold a customization stub at {custom_path}?", default=False
		):
			custom_path.write_text(_CUSTOM_DEFINITIONS_STUB)
			logger.info(f"Wrote customization stub: {custom_path}")

	logger.info("Initialized.")
