import asyncio
import logging
from pathlib import Path
from typing import Annotated

import typer

from ai_parade._toolkit.datasets.Random import Random
from ai_parade._toolkit.metadata.parsing import get_local_metadata
from ai_parade._toolkit.run.runner_selector import get_runner

from .._shared import ExitCode
from ..check import (
	basic_checks,
	compare_lock_to_venv,
	has_local_dependencies,
)
from ._common import (
	ModelNameTypeOptional,
	RepositoryPathType,
	VerboseType,
	WeightsPathTypeOptional,
	app,
)

logger = logging.getLogger(__name__)


@app.command()
def check(
	model_name: ModelNameTypeOptional = None,
	weights_path: WeightsPathTypeOptional = None,
	feature_set: Annotated[
		str | None,
		typer.Option(
			"--feature-set",
			help="Verify this feature set's lock file against the active environment. "
			"Omit to skip lock verification.",
		),
	] = None,
	skip_dependencies: Annotated[
		bool,
		typer.Option(help="If set to True, don't check dependencies."),
	] = False,
	allow_local_dependencies: Annotated[
		bool,
		typer.Option(
			help="Allow packages installed from local paths (e.g. editable installs). "
			"By default any missing dependency referencing a local path is treated as an error."
		),
	] = False,
	repository: RepositoryPathType = Path("."),
	verbose: VerboseType = [],
):
	"""
	Check if model repository is correctly set up. Read-only.

	It runs the following steps:

	1. Check if required dependencies are properly defined.
		- Skip with `--skip-dependencies`

	2. Parse metadata and select model (`MODEL_NAME`)

	3. Run inference on random data.
		- Only run if model name and weights are provided (`MODEL_NAME` and `WEIGHTS_PATH`)
	"""
	exit_code = ExitCode.OK

	if not skip_dependencies:
		if asyncio.run(basic_checks(repository)):
			exit_code |= ExitCode.CHECK_FLAGS_BASIC
		if feature_set is not None and asyncio.run(
			compare_lock_to_venv(repository, feature_set)
		):
			exit_code |= ExitCode.CHECK_FLAGS_LOCK
		if not allow_local_dependencies:
			if asyncio.run(has_local_dependencies(repository)):
				exit_code |= ExitCode.CHECK_FLAGS_LOCAL_DEPS
		logger.info("Dependencies checked!")

	metadata_list = asyncio.run(get_local_metadata(repository))
	logger.info("Model metadata successfully parsed")

	if model_name is not None:
		assert weights_path is not None
		metadata = next(x for x in metadata_list if x.name == model_name)
		logger.info(f"Selected model: {metadata.name}")

		async def run_inference():
			async with get_runner(metadata, weights_path) as runner:
				await runner.inference(Random(metadata.image_input).take(2))

		asyncio.run(run_inference())
	raise typer.Exit(code=exit_code)
