import asyncio
from pathlib import Path
from typing import Annotated

import typer

from ai_parade._toolkit.datasets.Dataset import DatasetSplit
from ai_parade._toolkit.metadata.parsing import get_local_metadata
from ai_parade._toolkit.metrics import Metric, build_metrics
from ai_parade.toolkit import inference as run_inference

from ._common import (
	ArtifactsDirType,
	ModelNameTypeOptional,
	RepositoryPathType,
	VerboseType,
	WeightsPathType,
	app,
	get_dataset,
)


@app.command()
def inference(
	weights_path: WeightsPathType,
	model_name: ModelNameTypeOptional = None,
	dataset_name: Annotated[
		str,
		typer.Option("--dataset", help="Dataset used for inference."),
	] = "Random",
	dataset_path: Annotated[
		Path | None,
		typer.Option(
			help="Optional path to the dataset assets (required for non-random datasets)."
		),
	] = None,
	take: Annotated[
		int,
		typer.Option(
			help="Number of samples to run through the model during inference. If negative, runs on the whole dataset.",
		),
	] = -1,
	split: Annotated[
		DatasetSplit, typer.Option(help="Dataset split to use.")
	] = DatasetSplit.val,
	metric: Annotated[
		list[Metric],
		typer.Option(
			"--metric",
			case_sensitive=False,
			help="Metric to compute. Can be specified multiple times.",
		),
	] = [],
	# common
	artifacts: ArtifactsDirType = Path("build"),
	output: Annotated[
		Path | None,
		typer.Option("--output", "-o", help="path to store JSON results."),
	] = None,
	repository_path: RepositoryPathType = Path("."),
	verbose: VerboseType = [],
):
	"""
	Run inference on a model using a selected dataset and print results.
	"""
	metadata_list = asyncio.run(get_local_metadata(repository_path))
	if model_name:
		metadata = next(x for x in metadata_list if x.name == model_name)
	else:
		assert weights_path.suffix == ".json", (
			f"Model name is required unless using a conversion result (weights_path: {weights_path})."
		)
		metadata = metadata_list[0]

	dataset = get_dataset(dataset_name, dataset_path, split).take(take)

	asyncio.run(
		run_inference(
			weights_path,
			metadata,
			dataset,
			artifacts,
			output,
			build_metrics(metric),
		)
	)
