import asyncio
from pathlib import Path
from typing import Annotated

from ai_parade._toolkit.metadata.cache import load_metadata_cache, write_metadata_cache, write_metadata_to
import typer

from ai_parade._toolkit.constants import get_metadata_cache
from ai_parade._toolkit.metadata.parsing import get_local_metadata
from ai_parade._toolkit.run.runner_selector import get_runner

from ._common import RepositoryPathType, VerboseType, app


@app.command()
def ls(
	repository: RepositoryPathType = Path("."),
	print_metadata: Annotated[
		bool,
		typer.Option(
			"--print",
			help="If set to True, print full metadata for each model. "
			"Otherwise, only model names will be printed. "
		),
	] = False,
	skip_cache: Annotated[
		bool,
		typer.Option(
			help="If set to True, all models will be reloaded and size will be recalculated (if required)."
		),
	] = False,
	include_size: Annotated[
		bool,
		typer.Option(
			help="If set to True, size of each model will be included in the metadata."
		),
	] = False,
	output_file: Annotated[
		Path | None,
		typer.Option(
			"--output", "-o",
			help="Path to the output file where the list of models will be saved."
		),
	] = None,
	verbose: VerboseType = [],
):
	"""
	List all available models in the repository.
	"""
	cache_file = get_metadata_cache(repository)
	if skip_cache or not cache_file.exists():
		metadata_list = asyncio.run(get_local_metadata(repository))
		write_metadata_cache(repository, metadata_list)
	else:
		metadata_list = load_metadata_cache(repository)

	# compute sizes if needed, and update cache
	assert len(metadata_list) > 0
	if include_size and metadata_list[0].real_size is None:
		metadata_list = [
			model.model_copy(update={"real_size": asyncio.run(get_runner(model, None).get_model_size())})
			for model in metadata_list
		]
		write_metadata_cache(repository, metadata_list)

	if output_file:
		write_metadata_to(output_file, metadata_list)

	if print_metadata:
		print(cache_file.read_text())
	else:
		print(
			"Models metadata parsed:\n\t" + "\n\t".join(m.name for m in metadata_list),
			flush=True,
		)
