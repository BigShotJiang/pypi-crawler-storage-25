import json
from pathlib import Path

from ai_parade._toolkit.metadata.models.pyproject import (
	ModelMetadataPyproject,
)

from ._common import (
	VerboseType,
	app,
)


@app.command()
def interop(
	output: Path = Path(".ai-parade/schemas"),
	verbose: VerboseType = [],
):
	"""
	Generate json schemas.
	"""
	metadata_schema = ModelMetadataPyproject.model_json_schema(mode="serialization")
	output.mkdir(parents=True, exist_ok=True)
	with open(output / "model_metadata.json", "w") as f:
		f.write(json.dumps(metadata_schema, indent=4))
