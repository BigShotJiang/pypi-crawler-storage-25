import importlib
import pathlib
import pkgutil
from typing import Annotated

import typer

import ai_parade._compat  # type: ignore # noqa: F401

from ._common import app

for module_info in pkgutil.iter_modules([str(pathlib.Path(__file__).parent)]):
	if not module_info.name.startswith("_") and module_info.name != __name__:
		importlib.import_module(f"{__package__}.{module_info.name}")


@app.callback(invoke_without_command=True)
def main(
	ctx: typer.Context,
	version: Annotated[
		bool, typer.Option("--version", "-v", help="Print version")
	] = False,
):
	if version:
		import importlib.metadata

		version_string_of_foo = importlib.metadata.version("ai-parade")
		print(version_string_of_foo)
		raise typer.Exit()
	if ctx.invoked_subcommand is None:
		pass


if __name__ == "__main__":
	app()
