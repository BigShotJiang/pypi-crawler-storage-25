import asyncio
from pathlib import Path
from typing import Annotated

import typer

from .._shared import FEATURE_SETS
from ..sync import sync_impl
from ._common import (
	FromDefinitionsType,
	FromEnvironmentType,
	RepositoryPathType,
	VerboseType,
	app,
)


@app.command()
def sync(
	feature_set: Annotated[
		str | None,
		typer.Argument(
			help="Feature set to (re)generate the lock for. One of: "
			f"{', '.join(FEATURE_SETS)}. Required unless --all is given.",
		),
	] = None,
	all_feature_sets: Annotated[
		bool,
		typer.Option("--all", help="Regenerate every feature set's lock."),
	] = False,
	repository: RepositoryPathType = Path("."),
	from_environment: FromEnvironmentType = False,
	from_definitions: FromDefinitionsType = False,
	allow_local_dependencies: Annotated[
		bool,
		typer.Option(
			help="Allow packages installed from local paths (e.g. editable installs)."
		),
	] = False,
	current_platform: Annotated[
		bool,
		typer.Option(
			"--current-platform",
			help="Compile locks for the current host platform instead of Linux. "
			"Locks are written to .ai-parade/locks.local/ and git-ignored.",
		),
	] = False,
	skip_checks: Annotated[
		bool,
		typer.Option(
			"--skip-checks",
			help="Skip the post-sync verification (lock vs. environment, local deps, "
			"metadata parse). Useful when bootstrapping a venv from the lock you're "
			"about to (re)generate.",
		),
	] = False,
	verbose: VerboseType = [],
):
	"""
	Update ai-parade lock files. Safe to re-run.
	"""
	if all_feature_sets == (feature_set is not None):
		raise typer.BadParameter("Pass exactly one of FEATURE_SET or --all.")

	if all_feature_sets:
		selected = FEATURE_SETS
	else:
		assert feature_set is not None
		if feature_set not in FEATURE_SETS:
			raise typer.BadParameter(
				f"Unknown feature set {feature_set!r}. "
				f"Known: {', '.join(FEATURE_SETS)}."
			)
		selected = {feature_set: FEATURE_SETS[feature_set]}

	asyncio.run(
		sync_impl(
			repository,
			from_environment=from_environment,
			from_definitions=from_definitions,
			allow_local_dependencies=allow_local_dependencies,
			skip_checks=skip_checks,
			feature_sets=selected,
			current_platform=current_platform,
		)
	)
