import logging
import subprocess
from pathlib import Path

from ai_parade._cli._shared import FEATURE_SETS
from ai_parade._toolkit.constants import (
	get_lock_path,
	get_locks_dir,
)
from ai_parade._toolkit.logging import subprocess_run_log_async

logger = logging.getLogger(__name__)


async def basic_checks(repository: Path) -> bool:
	"""Run always-on checks: verify every lock file exists and none are git-ignored.

	Returns ``True`` if any lock is missing.
	"""
	any_missing = await check_locks_exist(repository)
	await is_locks_git_ignored(repository)
	return any_missing


async def is_locks_git_ignored(repository: Path) -> bool:
	"""Warn if any lock file is listed in .gitignore."""
	lock_paths = [str(get_lock_path(repository, name)) for name in FEATURE_SETS]
	returncode, ignored_stdout, _ = await subprocess_run_log_async(
		["git", "check-ignore", *lock_paths],
		logger=logger,
		cwd=repository,
		check=False,
		suppress_errors=True,
	)
	if returncode == 128:  # not a git repository
		logger.debug("Skipping git-ignore check: not a git repository")
		return False
	
	if returncode == 1: # none of the paths are ignored
		logger.debug("No locks are git-ignored.")
		return False
	else:
		for path in {
			Path(line) for line in ignored_stdout.splitlines() if line.strip()
		}:
			logger.warning(f"Lock is git-ignored: {path}")
		return True


async def check_locks_exist(repository: Path) -> bool:
	"""Verify the locks directory and every feature-set lock file are present.

	Returns ``True`` if anything is missing.
	"""
	locks_dir = get_locks_dir(repository)
	if not locks_dir.exists():
		logger.warning(f"Locks directory not found: {locks_dir}")
		return True

	any_missing = False
	for name in FEATURE_SETS:
		lock_path = get_lock_path(repository, name)
		if not lock_path.exists():
			logger.warning(f"Missing lock: {lock_path}")
			any_missing = True
	return any_missing


async def compare_lock_to_venv(repository: Path, feature_set: str) -> bool:
	"""Check one lock file against the active environment via ``uv pip sync --dry-run``.

	For the ``base`` feature set the env must contain everything in the lock and
	nothing extra. For other feature sets only version mismatches are flagged
	(packages the env doesn't have are expected — they belong to that feature set).

	Returns ``True`` if any discrepancy was found.
	"""
	lock_path = get_lock_path(repository, feature_set)
	if not lock_path.exists():
		logger.warning(f"Missing lock: {lock_path}")
		return True

	output = None
	try:
		_, _, output = await subprocess_run_log_async(
			["uv", "pip", "sync", "--dry-run", str(lock_path)],
			logger=logger,
		)
	except subprocess.CalledProcessError as e:
		logger.warning(f"uv pip sync failed for {lock_path.name}: {e}")

	if output is None:
		return True

	any_discrepancy = False
	for line in output.splitlines():
		stripped = line.strip()
		if stripped.startswith("+ "):
			if feature_set == "base":
				logger.warning(
					f"[{lock_path.name}] Dependency missing in environment "
					f"(present in lock): {stripped[2:]}"
				)
				any_discrepancy = True
		elif stripped.startswith("- "):
			logger.warning(
				f"[{lock_path.name}] Dependency missing in lock "
				f"(present in venv): {stripped[2:]}"
			)
			any_discrepancy = True

	return any_discrepancy


async def has_local_dependencies(root_path: Path) -> bool:
	"""Detect editable installs or local-path packages in the active environment."""
	try:
		_, frozen, _ = await subprocess_run_log_async(
			["uv", "pip", "freeze"], logger=logger, cwd=root_path
		)
	except subprocess.CalledProcessError as e:
		logger.warning(f"uv pip freeze failed: {e}")
		return False

	has_local = False
	for line in frozen.splitlines():
		stripped = line.strip()
		if stripped.startswith("-e "):
			logger.warning(f"Local editable dependency detected: {stripped[3:]}")
			has_local = True
		elif " @ file://" in stripped:
			logger.warning(f"Local path dependency detected: {stripped}")
			has_local = True
	return has_local
