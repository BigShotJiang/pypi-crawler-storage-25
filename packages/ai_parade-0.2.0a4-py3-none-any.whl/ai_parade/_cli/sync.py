import logging
import os
import subprocess
import sys
from pathlib import Path
from typing import Literal

from ai_parade._cli._shared import FEATURE_SETS
from ai_parade._cli.check import basic_checks, has_local_dependencies
from ai_parade._toolkit.constants import (
	get_ai_parade_dir,
	get_lock_path,
	get_locks_dir,
)
from ai_parade._toolkit.logging import subprocess_run_log_async
from ai_parade._toolkit.metadata.parsing import get_local_metadata

LockSource = Literal["environment", "definitions", "any"]
UvResolution = Literal["highest", "lowest", "lowest-direct"]
PythonVersionResolution = Literal["lowest-first", "highest-first"]

logger = logging.getLogger(__name__)

_PROBE_PYTHON_VERSIONS = ["3.10", "3.11", "3.12", "3.13", "3.14"]


def _is_python_abi_error(stderr: str) -> bool:
	return "No solution found" in stderr and "ABI tag" in stderr


_DEFINITION_FILES = [
	"requirements.in",
	"pyproject.toml",
	"requirements.txt",
	"setup.py",
	"setup.cfg",
]


async def _gen_base_requirements(
	root_path: Path, source: LockSource
) -> tuple[list[Path], str]:
	"""Produce a requirements.txt string representing the ``base`` lock from ``source``."""

	found_definitions = [
		root_path / f for f in _DEFINITION_FILES if (root_path / f).exists()
	]
	if found_definitions:
		logger.debug(
			f"Compiling base from definitions: {', '.join(str(f) for f in found_definitions)}"
		)
		return found_definitions, ""

	if not found_definitions and source in ("environment", "any"):
		logger.debug("Capturing base from current environment via uv pip freeze")
		_, frozen, _ = await subprocess_run_log_async(
			["uv", "pip", "freeze"], logger=logger
		)
		return [], frozen
	raise FileNotFoundError(f"No uv.lock or definition files found in {root_path}")


_TOOLKIT_ROOT = Path(__file__).resolve().parent.parent.parent.parent


async def _sync_feature_set(
	repository: Path,
	*,
	source: LockSource,
	feature_set: str,
	extras: list[str],
	resolution: UvResolution | None,
	local: bool,
	current_platform: bool,
	python_strategy: PythonVersionResolution,
) -> None:
	repository = repository.resolve()
	final_path = get_lock_path(
		repository, feature_set, resolution, local_platform=current_platform
	)

	logger.debug(f"Locking feature set {feature_set!r} to `{final_path}`")

	definitions, stdin = await _gen_base_requirements(repository, source)
	extras_str = f"[{','.join(extras)}]" if extras else ""
	if local:
		rel = Path(os.path.relpath(_TOOLKIT_ROOT, repository.resolve())).as_posix()
		stdin += f"\n-e ai-parade{extras_str} @ {rel}"
	else:
		stdin += f"\nai-parade{extras_str}"
	versions = (
		_PROBE_PYTHON_VERSIONS
		if python_strategy == "lowest-first"
		else list(reversed(_PROBE_PYTHON_VERSIONS))
	)
	for python_version in versions:
		returncode, stdout, stderr = await subprocess_run_log_async(
			[
				"uv",
				"pip",
				"compile",
				"--format",
				"pylock.toml",
				"--output-file",
				str(final_path),
				"--upgrade",
				*((["--python-platform", "linux"]) if not current_platform else []),
				"--python-version",
				python_version,
				*([f"--resolution={resolution}"] if resolution else []),
				*definitions,
				"-",
			],
			cwd=repository,
			logger=logger,
			stdin=stdin,
			check=False,
			suppress_errors=True,
		)
		if returncode == 0:
			logger.info(
				f"Locked: {feature_set} (Python {python_version}) → {final_path}"
			)
			return
		if _is_python_abi_error(stderr):
			logger.debug(
				f"Python {python_version} incompatible for {feature_set!r}, trying next"
			)
			continue
		logger.error(stdout)
		logger.error(stderr)
		raise subprocess.CalledProcessError(
			returncode, "uv pip compile", output=stdout, stderr=stderr
		)
	raise RuntimeError(
		f"No compatible Python version found for {feature_set!r} in {versions}"
	)


_LOCAL_GITIGNORE_PATTERN = "locks.local*/"


def _ensure_gitignore(repository: Path) -> None:
	gitignore = get_ai_parade_dir(repository) / ".gitignore"
	if not gitignore.exists() or _LOCAL_GITIGNORE_PATTERN not in gitignore.read_text():
		with gitignore.open("a") as f:
			f.write(f"{_LOCAL_GITIGNORE_PATTERN}\n")


def ensure_layout(
	repository: Path,
	resolution: str | None = None,
	local_platform: bool = False,
) -> None:
	"""Create the ``.ai-parade/`` and ``.ai-parade/locks/`` directories if missing."""
	get_locks_dir(repository, resolution, local_platform=local_platform).mkdir(
		parents=True, exist_ok=True
	)
	_ensure_gitignore(repository)


async def sync_impl(
	repository: Path,
	*,
	from_environment: bool,
	from_definitions: bool,
	allow_local_dependencies: bool,
	skip_checks: bool = False,
	feature_sets: dict[str, list[str]] = FEATURE_SETS,
	resolution: UvResolution | None = None,
	local: bool = False,
	current_platform: bool = False,
	python_strategy: PythonVersionResolution = "lowest-first",
) -> None:
	if not current_platform and sys.platform != "linux":
		logger.warning(
			f"Lock files are compiled for Linux but you are running on {sys.platform!r}; "
			"the generated locks may be incompatible with your host platform. "
			"Use --local-platform to generate platform-specific locks for local testing."
		)

	ensure_layout(repository, resolution, local_platform=current_platform)

	if from_environment and from_definitions:
		source: LockSource = "any"
	elif from_environment:
		source = "environment"
	elif from_definitions:
		source = "definitions"
	else:
		source = "any"

	successfully_created = True
	for name, extras in feature_sets.items():
		try:
			await _sync_feature_set(
				repository,
				feature_set=name,
				extras=extras,
				source=source,
				resolution=resolution,
				local=local,
				current_platform=current_platform,
				python_strategy=python_strategy,
			)
		except Exception:
			logger.error(f"Failed to lock feature set {name!r}")
			successfully_created = False

	if not successfully_created:
		raise RuntimeError("Failed to create one or more lock files")

	if not skip_checks:
		await basic_checks(repository)
		if not allow_local_dependencies and not local:
			await has_local_dependencies(repository)
		await get_local_metadata(repository)
	logger.info("Sync complete.")
