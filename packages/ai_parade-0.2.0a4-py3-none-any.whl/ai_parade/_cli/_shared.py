import enum


class ExitCode(enum.IntEnum):
    OK = 0
    NO_LOCK = 3
    CHECK_FLAGS_BASIC = 4
    CHECK_FLAGS_LOCK = 8
    CHECK_FLAGS_LOCAL_DEPS = 16


# Maps feature-set name → list of ai-parade extras to enable when locking.
# Mirrors the entries of ``[tool.uv.conflicts]`` in ai-parade's pyproject.toml,
# plus a baseline with no extras.
FEATURE_SETS: dict[str, list[str]] = {
	"base": [],
	"inference": ["inference"],
	"inference-gpu": ["inference-gpu"],
	"convert-torch-executorch": ["convert-torch-executorch"],
	"convert-torch-tflite": ["convert-torch-tflite"],
	"convert-torch-onnx": ["convert-torch-onnx"],
	"convert-torch-ncnn": ["convert-torch-ncnn"],
	"convert-onnx-tf": ["convert-onnx-tf"],
	"convert-onnx-ncnn": ["convert-onnx-ncnn"],
	"convert-onnx--gpu": ["convert-onnx--gpu"],
	"convert-tf-onnx": ["convert-tf-onnx"],
}
