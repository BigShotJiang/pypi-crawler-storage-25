import logging
from pathlib import Path

TRACE_LVL = 5
logging.addLevelName(TRACE_LVL, "TRACE")

VENV_DIR = ".venv"
AI_PARADE_DIR = ".ai-parade"
CACHED_METADATA_FILE_NAME = "metadata.json"
LOCKS_SUBDIR = "locks"
LOCAL_LOCKS_SUBDIR = "locks.local"
BASE_FEATURE_SET = "base"
CUSTOM_DEFINITIONS_FILE_NAME = "ai-parade.py"


def get_site_packages_path(repository_path: Path) -> Path:
	return (repository_path / VENV_DIR / "lib").glob( # todo: this is linux only (probably whole customization loading should be reworked...)
		"python*"
	).__next__() / "site-packages"


def get_ai_parade_dir(repository_path: Path) -> Path:
	return repository_path / AI_PARADE_DIR

def get_metadata_cache(repository_path: Path) -> Path:
	"""
	IMPORTANT!: Do not use for loading or writing data directly, use load_metadata_cache / write_metadata_cache instead. 
	It skips repository path so loading from it would end with different metadata
	"""
	return get_ai_parade_dir(repository_path) / CACHED_METADATA_FILE_NAME


def get_locks_dir(
	repository_path: Path,
	resolution: str | None = None,
	local_platform: bool = False,
) -> Path:
	base = LOCAL_LOCKS_SUBDIR if local_platform else LOCKS_SUBDIR
	subdir = f"{base}[{resolution}]" if resolution else base
	return get_ai_parade_dir(repository_path) / subdir


def get_lock_path(
	repository_path: Path,
	feature_set: str,
	resolution: str | None = None,
	local_platform: bool = False,
) -> Path:
	return get_locks_dir(repository_path, resolution, local_platform) / f"pylock.{feature_set}.toml"


def get_custom_definitions_path(repository_path: Path) -> Path:
	return get_ai_parade_dir(repository_path) / CUSTOM_DEFINITIONS_FILE_NAME
