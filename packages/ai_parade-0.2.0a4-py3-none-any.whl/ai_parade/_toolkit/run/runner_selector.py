from pathlib import Path

from ai_parade._toolkit.enums import AIRuntime, formats_preferred_runtime
from ai_parade._toolkit.metadata.models.api import RunnerGetter
from ai_parade._toolkit.metadata.models.final import ModelMetadata

from .ModelRunner import ModelRunner
from .NotARunner import NotARunner


def get_runner(
	model_metadata: ModelMetadata,
	weights: Path | None,
	runtime: AIRuntime | None = None,
) -> ModelRunner:
	"""Returns appropriate runner for the model based on the parameters

	Args:
		model_metadata: metadata
		weights: Model weights
		runtime: Desired AI runtime, only relevant if there are multiple runtimes for the same model format (from the metadata)

	Returns:
		Initialized ModelRunner
	"""
	runtime = runtime or formats_preferred_runtime[model_metadata.format.format]
	if model_metadata.get_custom_runner is not None:
		assert formats_preferred_runtime[model_metadata.format.format] == runtime
		runner = model_metadata.get_custom_runner(model_metadata, weights)
		return runner
	else:
		local_getter = _choose_default_runner(runtime)
		return local_getter(model_metadata, weights)


def _choose_default_runner(
	runtime: AIRuntime,
) -> RunnerGetter:
	"""Chooses default runner or runner from customizations

	Args:
		model_format: Desired model format
	Returns:
		ModelRunner in form of RunnerGetter
	"""
	match runtime:
		case AIRuntime.PyTorch:
			from .PyTorch import PyTorchRunner

			return PyTorchRunner
		case AIRuntime.ONNXRuntime:
			from .ONNX import ONNXRunner

			return ONNXRunner
		case AIRuntime.TensorFlow:
			from .TensorFlow import TensorFlowRunner

			return TensorFlowRunner
		case AIRuntime.ExecuTorch:
			return NotARunner
		case AIRuntime.LiteRT:
			return NotARunner
		case AIRuntime.ncnn:
			return NotARunner
		case _:
			raise RuntimeError(f"Unknown model format `{runtime}`")
		# New AI Runtime: register runner - ModelRunner derived class
