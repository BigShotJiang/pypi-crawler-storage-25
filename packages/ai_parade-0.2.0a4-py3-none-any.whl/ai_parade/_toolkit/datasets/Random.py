import typing
from typing import Any, Iterable, cast, get_type_hints, override

import numpy as np

from ai_parade._toolkit.data.ImageInput import ImageInput
from ai_parade._toolkit.data.output import ModelOutput

from .Dataset import Dataset, DatasetInfo, Output_unbatched


class Random(Dataset[None]):
	"""Dataset with random data of the ImageInput specifications"""

	def __init__(
		self,
		image_input: ImageInput | None = None,
		*,
		seed: int | None = None,
		size: int = 1000,
	):
		super().__init__()
		self._image_input = image_input
		if image_input is not None:
			self._batch_size = image_input.batchSize
		self._seed = seed
		self._size = size

	@override
	def walk(self) -> Iterable[None]:
		for _ in range(self._size):
			yield None

	@override
	def parse_data(
		self, iterable: Iterable[None], should_load: bool
	) -> Iterable[Output_unbatched]:
		assert self._image_input is not None, (
			"The Random dataset was constructed without an ImageInput or preprocess call"
		)

		class _RandomLabels(dict):  # type: ignore[type-arg]
			hints = get_type_hints(ModelOutput)
			
			def _random_value(self, hint: Any) -> Any:
				if hint is int:
					return int(rng.randint(0, 1000))
				if hint is float:
					return float(rng.rand())
				if hint is str:
					return f"random_{rng.randint(0, 1000)}"
				origin = typing.get_origin(hint)
				args = typing.get_args(hint)
				if origin is list and args:
					return [self._random_value(args[0]) for _ in range(10)]
				
				return None  # default for unsupported types
			
			def __missing__(self, key: str) -> Any:
				hint = self.hints.get(key)
				return self._random_value(hint)

		rng = np.random.RandomState(self._seed)
		shape = self._image_input.shape[1:]
		labels = cast(ModelOutput, _RandomLabels())
		for _ in iterable:
			match self._image_input.dataType:
				case ImageInput.DataType.float32:
					data = rng.rand(*shape).astype(np.float32)
				case ImageInput.DataType.float16:
					data = rng.rand(*shape).astype(np.float16)
				case ImageInput.DataType.uint8:
					data = rng.randint(
						0,
						255,
						size=shape,
						dtype=np.uint8,
					)
			yield (
				data,
				labels,
				DatasetInfo(
					source_data_shape=shape,
					data_source="Random",
					data_shape=shape,
				),
			)

	@override
	def preprocess(self, image_input: ImageInput):
		self._image_input = image_input
		self._batch_size = image_input.batchSize
		return self
