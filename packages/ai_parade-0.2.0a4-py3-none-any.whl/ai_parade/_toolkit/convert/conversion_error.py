from typing import override

from ai_parade._toolkit.enums import ExactModelFormat


class ConversionError(RuntimeError):
	def __init__(
		self,
		source: ExactModelFormat,
		target: ExactModelFormat,
		message: str = "",
	):
		self.source = source
		self.target = target
		self.message = message
		super().__init__(self.__str__())

	@override
	def __str__(self) -> str:
		return f"Conversion from {self.source} to {self.target} failed:\n{self.message}"
