from dataclasses import replace
from typing import TYPE_CHECKING, Literal, override

if TYPE_CHECKING:
	import torch  # type: ignore  # noqa: F401

from ai_parade._toolkit.data.ImageInput import ImageInput
from ai_parade._toolkit.enums import (
	ExactModelFormat,
	ModelFormat,
	Quantization,
)

from ..converter import Converter
from ._pytorch_base import PyTorchConvertBase


class LiteRTTorchConverterEntry(Converter):
	"""
	https://github.com/google-ai-edge/ai-edge-torch
	and
	https://github.com/google-ai-edge/ai-edge-torch/blob/main/docs/pytorch_converter/README.md#quantization
	"""

	def __init__(
		self,
		quantization_type: Literal[Quantization.none]
		| Literal[Quantization.float16]
		| Literal[Quantization.int8],
	):
		self.quantization_type = quantization_type

	@property
	@override
	def conversion(self):
		return (
			ExactModelFormat(ModelFormat.PyTorch),
			ExactModelFormat(ModelFormat.LiteRT, self.quantization_type),
		)

	@override
	def create(self, options: Converter.Options):
		super().create(options)
		return self.LiteRTTorchConverter(self.conversion, options)

	class LiteRTTorchConverter(PyTorchConvertBase):
		@override
		def _export_call(self, params: PyTorchConvertBase.Params):
			model, sample_inputs, output_weights_path, default_results, *_ = params
			try:
				import litert_torch  # type: ignore
			except ImportError:  # fallback for windows where litert_torch is not available, but ai_edge_torch is
				import ai_edge_torch  # pyright: ignore[reportMissingImports]

				litert_torch = ai_edge_torch
			import tensorflow as tf  # type: ignore

			# set it to channels last mode, so that the model does not contain transpose layers (the backend does work in NHWC)
			model = litert_torch.to_channel_last_io(model, args=[0])
			model.eval()  # apparently the mode is reset by the to_channel_last_io
			sample_inputs = (sample_inputs[0].permute(0, 2, 3, 1),)

			converter_flags = {}
			match self.conversion[1].quantization:
				case Quantization.float32:
					pass

				case Quantization.int8:
					assert self.options.calibration_data is not None
					# with fallback to other datatypes
					converter_flags["optimizations"] = [tf.lite.Optimize.DEFAULT]
					converter_flags["representative_dataset"] = list(
						map(
							lambda x: [x[0].transpose(0, 2, 3, 1)],
							self.options.calibration_data,
						)
					).__iter__
				case Quantization.float16:
					converter_flags = {
						"optimizations": [tf.lite.Optimize.DEFAULT],
						"target_spec": {"supported_types": [tf.float16]},
					}

				case _:
					raise NotImplementedError(
						f"Quantization {self.conversion[1].quantization} not supported"
					)

			edge_model = litert_torch.convert(
				model, sample_inputs, _ai_edge_converter_flags=converter_flags
			)
			edge_model.export(str(output_weights_path))

			default_results.image_input = replace(
				default_results.image_input, dataOrder=ImageInput.DataOrder.NHWC
			)
			return default_results


capabilities: list[Converter] = [
	LiteRTTorchConverterEntry(Quantization.none),
	LiteRTTorchConverterEntry(Quantization.int8),
	LiteRTTorchConverterEntry(Quantization.float16),
]
