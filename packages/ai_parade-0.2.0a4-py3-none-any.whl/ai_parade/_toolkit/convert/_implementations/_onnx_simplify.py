import logging
import shutil
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Literal

from ai_parade._toolkit.logging import subprocess_run_log

logger = logging.getLogger(__name__)


class ONNXSimplify:
	def __init__(
		self,
		simplifier: Literal["onnxslim"] | Literal["onnxsim"] = "onnxslim",
	):
		self.simplifier = simplifier

	def simplify(
		self,
		onnx_path: Path,
	):
		# delete=False + explicit close: on Windows, NamedTemporaryFile holds an exclusive
		# lock while open, which prevents onnxslim from writing to the same path.
		with NamedTemporaryFile(delete=False, suffix=".onnx") as tmp_file:
			tmp_path = Path(tmp_file.name)
		try:
			logger.info(f"Running {self.simplifier} on ONNX model")
			returncode, _, _ = subprocess_run_log(
				[self.simplifier, onnx_path, tmp_path],
				logger=logger,
			)
			if returncode == 0:
				shutil.move(
					onnx_path, onnx_path.with_stem(onnx_path.stem + "_unsimplified")
				)
				shutil.move(tmp_path, onnx_path)
		finally:
			tmp_path.unlink(missing_ok=True)

		return returncode == 0
