import sys
from pathlib import Path
from typing import Literal

from pydantic import BaseModel

from ai_parade._toolkit.data.ImageInput import ImageInput
from ai_parade._toolkit.data.output import Output
from ai_parade._toolkit.enums import ExactModelFormat


class ConversionResult(BaseModel):
	status: Literal["success", "failed"] = "success"

	format: ExactModelFormat
	"""
	Format of the converted model
	"""

	image_input: ImageInput
	"""
	Image input of the converted model
	"""

	path: Path
	"""
	Path to the converted model.
	"""
	output: Output
	"""
	Output of the converted model.
	"""

	@staticmethod
	def load(path: Path) -> "ConversionResult":
		if not path.exists():
			raise FileNotFoundError(f"Conversion result file {path} does not exist")
		if path.suffix != ".json":
			raise ValueError(f"Conversion result file {path} is not a JSON file")
		with open(path, "r", encoding="utf-8") as f:
			conversion_result = ConversionResult.model_validate_json(f.read())

		conversion_result.path = (path.parent / conversion_result.path).resolve()
		return conversion_result

	def save(self, result_json_path: Path) -> None:
		"""Save the conversion result JSON. The model path is stored relative to the JSON file."""
		assert self.path.is_absolute(), f"Model path must be absolute, got {self.path}"

		if sys.version_info >= (3, 12):
			relative_path = self.path.relative_to(result_json_path.parent, walk_up=True)
		else:
			import os

			relative_path = Path(os.path.relpath(self.path, result_json_path.parent))

		serializable = self.model_copy(update={"path": relative_path})
		with open(result_json_path, "w", encoding="utf-8") as f:
			f.write(serializable.model_dump_json(indent=2))
