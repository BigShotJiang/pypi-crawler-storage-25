import logging
import os
import re
from pathlib import Path

import aiohttp

logger = logging.getLogger(__name__)

_GDRIVE_SCOPES = ["https://www.googleapis.com/auth/drive.readonly"]


def create_gdrive_credentials(token_path: Path):
	"""
	Shows basic usage of the Drive v3 API.
	See: https://developers.google.com/drive/api/quickstart/python
	"""

	from google.auth.transport.requests import Request # pyright: ignore[reportMissingImports]
	from google.oauth2.credentials import Credentials # pyright: ignore[reportMissingImports]
	from google_auth_oauthlib.flow import InstalledAppFlow # pyright: ignore[reportMissingImports]

	creds = None
	# The file token.json stores the user's access and refresh tokens, and is
	# created automatically when the authorization flow completes for the first
	# time.
	if token_path.exists():
		creds = Credentials.from_authorized_user_file(token_path, _GDRIVE_SCOPES)
	# If there are no (valid) credentials available, let the user log in.
	if not creds or not creds.valid:
		if creds and creds.expired and creds.refresh_token:
			creds.refresh(Request())
		else:
			flow = InstalledAppFlow.from_client_secrets_file(
				token_path,
				_GDRIVE_SCOPES,
			)
			creds = flow.run_local_server(port=0)
		# Save the credentials for the next run
		with open(token_path, "w") as token:
			token.write(creds.to_json())


def _download_gdrive(file_id: str, download_location: Path, token_path: Path):
	"""
	```
	pip install --upgrade google-api-python-client google-auth-httplib2 google-auth-oauthlib
	```
	See: https://developers.google.com/drive/api/guides/manage-downloads#python
	"""

	from google.oauth2.credentials import Credentials # pyright: ignore[reportMissingImports]
	from googleapiclient.discovery import build # pyright: ignore[reportMissingImports]
	from googleapiclient.errors import HttpError # pyright: ignore[reportMissingImports]
	from googleapiclient.http import MediaIoBaseDownload # pyright: ignore[reportMissingImports]

	logger.debug(f"Downloading as file {file_id} via google api")
	# creds, project_id = google.auth.default()
	creds = Credentials.from_authorized_user_file(token_path, _GDRIVE_SCOPES)

	try:
		# create drive api client
		service = build("drive", "v3", credentials=creds)

		# pylint: disable=maybe-no-member
		request = service.files().get_media(fileId=file_id)
		with open(download_location, "wb") as file:
			downloader = MediaIoBaseDownload(file, request)
			done = False
			while done is False:
				status, done = downloader.next_chunk()
				print(f"Download {int(status.progress() * 100)}.")
	except HttpError as error:
		print(f"An error occurred: {error}")


async def async_urlretrieve(url: str, dest: Path):
	async with aiohttp.ClientSession() as session:
		async with session.get(url) as response:
			response.raise_for_status()

			with open(dest, "wb") as f:
				async for chunk in response.content.iter_chunked(8192):
					f.write(chunk)

			return dest, response.headers


async def download(source: str, target_location: Path, token_path: Path | None = None):
	"""
	Downloads files from given url
	The google disk downloads have special handling to escape quotas - they uses gdrive api with logged-in user

	Args:
		url: source of the data
		download_location: path of the file which will be downloaded
		config: configuration
	"""
	logger.info(f"Downloading {source}")
	gdrive_file = re.search(r"google\.com/file/d/([^/]+)/", source)
	if gdrive_file is not None:
		gdrive_id = gdrive_file.group(1)
		assert token_path is not None
		_download_gdrive(gdrive_id, target_location, token_path)
	else:
		logger.debug("Downloading via url retrieve")
		await async_urlretrieve(source, target_location)

	# TODO: the pytorch model data is getting unarchived, so skipping it for now
	return
	# unarchive if archive
	import patoolib

	if patoolib.is_archive(target_location):
		logger.info("Unpacking download.")
		target_location = Path(target_location)
		archive_path = target_location.parent / f"{target_location.name}.archive"
		os.rename(target_location, archive_path)
		patoolib.extract_archive(
			archive_path, outdir=target_location, interactive=False
		)
