import asyncio
import logging
import re
import subprocess
from asyncio.subprocess import Process
from pathlib import Path
from typing import Any

from ai_parade._toolkit.constants import TRACE_LVL

_Args = list[str] | list[str | Path] | list[Path]


def _log_command(logger: logging.Logger, args: _Args, **kwargs: Any):
	logger.debug(f"Running command: `{' '.join([str(x) for x in args])}`")
	if kwargs:
		logger.debug(f"\twith kwargs: {kwargs}")


# From https://stackoverflow.com/a/14693789/5739006
_ansi_escape = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")


def better_decode(b: bytes) -> str:
	text = b.decode()
	return _ansi_escape.sub("", text)


def _log_results(
	logger: logging.Logger,
	args: _Args,
	returncode: int,
	stdout: bytes,
	stderr: bytes,
	check: bool,
	suppress_errors: bool,
):
	msg = f"Command: `{' '.join([str(x) for x in args])}` exited with return code {returncode} and output:"
	if stdout is not None:  # type: ignore because it is simply not true
		msg += "\n" + better_decode(stdout)
	if stderr is not None:  # type: ignore because it is simply not true
		msg += "\n" + better_decode(stderr)

	logger.log(TRACE_LVL if returncode == 0 or suppress_errors else logging.ERROR, msg)

	if check and returncode != 0:
		raise subprocess.CalledProcessError(returncode, args, stdout, stderr)


def log_subprocess_result(
	result: subprocess.CompletedProcess[bytes],
	*,
	logger: logging.Logger,
	check: bool = True,
	suppress_errors: bool = False,
):
	_log_results(
		logger,
		result.args,
		result.returncode,
		result.stdout,
		result.stderr,
		check,
		suppress_errors,
	)
	return result.returncode, better_decode(result.stdout), better_decode(result.stderr)


async def log_subprocess_result_async(
	process: Process,
	args: _Args = [],
	*,
	logger: logging.Logger,
	check: bool = True,
	stdin: bytes | None = None,
	suppress_errors: bool = False,
):
	stdout, stderr = await process.communicate(input=stdin)
	assert process.returncode is not None
	_log_results(
		logger,
		args,
		process.returncode,
		stdout,
		stderr,
		check,
		suppress_errors,
	)
	return process.returncode, better_decode(stdout), better_decode(stderr)


async def subprocess_run_log_async(
	args: _Args,
	*,
	logger: logging.Logger,
	check: bool = True,
	stdin: str | None = None,
	suppress_errors: bool = False,
	**kwargs: Any,
):
	_log_command(logger, args, **kwargs)

	process = await asyncio.create_subprocess_exec(
		str(args[0]),
		*map(str, args[1:]),
		stdout=asyncio.subprocess.PIPE,
		stderr=asyncio.subprocess.PIPE,
		stdin=asyncio.subprocess.PIPE if stdin is not None else None,
		**kwargs,
	)
	return await log_subprocess_result_async(
		process,
		args,
		logger=logger,
		check=check,
		stdin=stdin.encode() if stdin is not None else None,
		suppress_errors=suppress_errors,
	)


def subprocess_run_log(
	args: _Args,
	*,
	logger: logging.Logger,
	check: bool = True,
	suppress_errors: bool = False,
	**kwargs: Any,
):
	_log_command(logger, args, **kwargs)
	result = subprocess.run(
		args,
		stdout=asyncio.subprocess.PIPE,
		stderr=asyncio.subprocess.PIPE,
		**kwargs,
	)
	return log_subprocess_result(
		result, logger=logger, check=check, suppress_errors=suppress_errors
	)


def get_ai_parade_logger() -> logging.Logger:
	"""Get the logger for ai_parade"""
	return logging.getLogger("ai_parade._toolkit")
