import json
from pathlib import Path

from ai_parade._toolkit.constants import get_metadata_cache
from ai_parade._toolkit.metadata.models.final import ModelMetadata


def load_metadata_cache(repository: Path, path: Path | None = None) -> list[ModelMetadata]:
	path = path or get_metadata_cache(repository)
	with open(path, "r") as f:
		return [ModelMetadata(**d, repository_path=repository.resolve()) for d in json.load(f)]


def write_metadata_cache(repository: Path, metadata_list: list[ModelMetadata]) -> None:
	path = get_metadata_cache(repository)
	path.parent.mkdir(parents=True, exist_ok=True)

	write_metadata_to(path, metadata_list)

def write_metadata_to(path: Path , metadata_list: list[ModelMetadata]) -> None:
	def _serialize_metadata(metadata: ModelMetadata) -> dict:
		return metadata.model_dump(mode="json", exclude_none=True, exclude={"repository_path"})
	
	with open(path, "w") as f:
		json.dump([_serialize_metadata(m) for m in metadata_list], f, indent=4)