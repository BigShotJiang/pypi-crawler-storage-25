from pathlib import Path
from typing import Optional

from pydantic import ConfigDict, DirectoryPath

from ai_parade._toolkit.convert.conversion_error import ConversionError
from ai_parade._toolkit.convert.ConversionResult import ConversionResult

from .api import ModelMetadataApi, PyTorchOptionsApi


class ModelMetadata(ModelMetadataApi):
	"""
	Model metadata -- everything needed to run the model and more
	"""
	schema_version: str = "0.1.0"

	model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

	repository_path: Optional[DirectoryPath] = None
	"""
	Path to the repository, or None if the model is not locally available
	"""

	pytorch: Optional["PyTorchOptions"] = None  # type: ignore

	def with_conversion_results(
		self,
		conversion_result_path: Path,
		conversion_result: ConversionResult | None = None,
	) -> tuple["ModelMetadata", Path]:
		conversion_result = conversion_result or ConversionResult.load(
			conversion_result_path
		)
		if conversion_result.status == "failed":
			raise ConversionError(
				self.format,
				conversion_result.format,
				"Using failed conversion result",
			)

		new_metadata = self.model_copy(
			update={
				"image_input": conversion_result.image_input,
				"format": conversion_result.format,
				"output": conversion_result.output,
				"get_custom_runner": None,
			}
		)
		return new_metadata, conversion_result.path


class PyTorchOptions(PyTorchOptionsApi):
	"""
	PyTorch options
	"""

	model_config = ConfigDict(frozen=True, protected_namespaces=())
	pass
