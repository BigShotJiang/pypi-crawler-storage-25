"""Document Processing Hub - File type identification and validation."""

from .scanNameFiles import identify_file_type, get_file_info
from .validators import (
    validate_zj_format,
    validate_manpower_budget,
    validate_manpower_documents,
    classify_manpower_type,
)
from .fileSelector import find_latest_file, FileSelector, _default_selector, FileResult, FileSearcher

# Mapeo de tipos de archivo a sus nombres de método
FILE_TYPE_MAPPING = {
    "ZJ": "zj",
    "MANPOWER_BUDGET": "manpower_budget",
    "MANPOWER_DOCUMENTS": "manpower_documents",
    "MANPOWER": "manpower",
    "REAL_TIME_PRODUCTION": "real_time_production",
}


class FileSearchNamespace:
    """Namespace dinámico para búsquedas de archivos con operaciones en cadena."""

    def __init__(self, selector: FileSelector):
        self.selector = selector

    def __getattr__(self, name: str):
        """Genera dinámicamente métodos de búsqueda basados en nombres."""
        # Buscar el tipo de archivo correspondiente al nombre
        for file_type, method_name in FILE_TYPE_MAPPING.items():
            if method_name == name:
                return FileSearcher(self.selector, file_type)
        raise AttributeError(f"No existe búsqueda para '{name}'")


class find_latest_file_ns:
    """Namespace para find_latest_file con múltiples métodos."""

    # Namespaces dinámicos para búsquedas
    exists = FileSearchNamespace(_default_selector)
    local_searcher = FileSearchNamespace(_default_selector)
    find_searcher = FileSearchNamespace(_default_selector)

    @staticmethod
    def local(folder_path: str, file_type: str):
        """Búsqueda en carpeta local específica."""
        result = _default_selector.local(folder_path, file_type)
        return FileResult(result)

    @staticmethod
    def find(file_type: str, *additional_paths):
        """Búsqueda en rutas predefinidas + adicionales."""
        result = _default_selector.find(file_type, *additional_paths)
        return FileResult(result)

    @staticmethod
    def add_path(file_type: str, path: str):
        """Agregar ruta predefinida."""
        return _default_selector.add_path(file_type, path)

    @staticmethod
    def set_paths(file_type: str, paths: list):
        """Reemplazar rutas predefinidas."""
        return _default_selector.set_paths(file_type, paths)


# Reemplazar find_latest_file con namespace
find_latest_file = find_latest_file_ns

__version__ = "0.3.0"
__all__ = [
    "identify_file_type",
    "get_file_info",
    "validate_zj_format",
    "validate_manpower_budget",
    "validate_manpower_documents",
    "classify_manpower_type",
    "find_latest_file",
    "FileSelector",
    "FileResult",
]
