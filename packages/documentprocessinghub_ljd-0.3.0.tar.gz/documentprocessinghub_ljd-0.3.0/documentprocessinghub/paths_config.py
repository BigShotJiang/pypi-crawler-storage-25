"""
Configuración de rutas predefinidas para búsqueda de archivos.

Modifica estas rutas según tus necesidades. Si en el futuro se requiere
un algoritmo para elegir carpeta dinámicamente, solo necesitas cambiar
esta sección.
"""

# Rutas predefinidas para búsqueda rápida por tipo de archivo
DEFAULT_PATHS = {
    "MANPOWER_BUDGET": [
        r"\\172.29.172.155\Industrial_Eng\PE QUALITY RECORDS\06) Manpower\Manpower budget 2026",
    ],
    "MANPOWER": [
        r"\\172.29.172.155\Industrial_Eng\PE QUALITY RECORDS\06) Manpower",
    ],
}
