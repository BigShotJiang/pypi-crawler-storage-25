from __future__ import annotations

from typing import Required, TypedDict

from .asset import Asset, AudioRef, FileRef, ImageRef, VideoRef


class SplitVideoInput(TypedDict, total=False):
    fileKey: str
    video: Asset
    videoKey: str
    video_base64: str
    video_bytes: str

class SplitVideoOutput(TypedDict, total=False):
    error: str
    success: Required[bool]
    text: str
    thinking: str
    video_parts: list[VideoRef]

