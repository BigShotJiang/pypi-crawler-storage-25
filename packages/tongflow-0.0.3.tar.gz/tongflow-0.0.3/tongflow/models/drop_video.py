from __future__ import annotations

from typing import Required, TypedDict

from .asset import Asset, AudioRef, FileRef, ImageRef, VideoRef


class DropVideoInput(TypedDict, total=False):
    fileKeys: list[str]
    query: str

class DropVideoOutput(TypedDict, total=False):
    audio_base64: AudioRef
    clips: list[VideoRef]
    error: str
    image_base64: ImageRef
    success: Required[bool]
    text: str
    texts: list[str]
    thinking: str
    video_base64: VideoRef

