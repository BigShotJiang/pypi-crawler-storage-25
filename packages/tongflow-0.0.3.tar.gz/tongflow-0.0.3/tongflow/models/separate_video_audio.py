from __future__ import annotations

from typing import Required, TypedDict

from .asset import Asset, AudioRef, FileRef, ImageRef, VideoRef


class SeparateVideoAudioInput(TypedDict, total=False):
    fileKey: str
    videoKey: str
    video_bytes: str
    video_filename: str

class SeparateVideoAudioOutput(TypedDict, total=False):
    audio_file_key: AudioRef
    error: str
    success: Required[bool]
    text: str
    thinking: str
    video_file_key: VideoRef

