from __future__ import annotations

from typing import Required, TypedDict

from .asset import Asset, AudioRef, FileRef, ImageRef, VideoRef


class ArrangeGroupInputRootInfosItem(TypedDict, total=False):
    pass

class ArrangeGroupInputRootItemsItem(TypedDict, total=False):
    id: str
    text: str

class ArrangeGroupInput(TypedDict, total=False):
    duplicatable: bool
    fileKeys: list[str]
    groupCount: int
    infos: list["ArrangeGroupInputRootInfosItem"]
    items: list["ArrangeGroupInputRootItemsItem"]
    query: str

class ArrangeGroupOutput(TypedDict, total=False):
    audio_base64: AudioRef
    error: str
    groups: list[list[VideoRef]]
    image_base64: ImageRef
    success: Required[bool]
    text: str
    texts: list[str]
    thinking: str
    video_base64: VideoRef

