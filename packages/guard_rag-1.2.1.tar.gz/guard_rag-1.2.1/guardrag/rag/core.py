"""
Core RAG pipeline for document processing and retrieval.
"""

import hashlib
import os
import time
from pathlib import Path
from typing import Any

from langchain_community.document_loaders import Docx2txtLoader, PyPDFLoader, TextLoader
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_ollama import ChatOllama
from langchain_text_splitters import RecursiveCharacterTextSplitter

try:
    from langchain.chains import create_history_aware_retriever, create_retrieval_chain
    from langchain.chains.combine_documents import create_stuff_documents_chain
except ImportError:
    # Handle future versions (1.0+) where chains moved to langchain_classic
    from langchain_classic.chains import (
        create_history_aware_retriever,
        create_retrieval_chain,
    )
    from langchain_classic.chains.combine_documents import create_stuff_documents_chain
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

# Fix OMP error for FAISS (must be before FAISS import)
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

# Proxy bypass
_NO_PROXY = "huggingface.co,*.huggingface.co,localhost,127.0.0.1"
os.environ.setdefault("NO_PROXY", _NO_PROXY)
os.environ.setdefault("no_proxy", _NO_PROXY)


_embeddings = None

def _get_embeddings():
    """Get HuggingFace embeddings model (cached)."""
    global _embeddings
    if _embeddings is None:
        try:
            _embeddings = HuggingFaceEmbeddings(
                model_name="sentence-transformers/all-MiniLM-L6-v2",
                model_kwargs={"device": "cpu"},
                encode_kwargs={"normalize_embeddings": True},
            )
        except Exception as e:
            raise RuntimeError(
                f"Failed to initialize HuggingFace embeddings. "
                f"Ensure 'sentence-transformers', 'torch', and 'transformers' are installed correctly. "
                f"Error: {str(e)}"
            ) from e
    return _embeddings


def build_rag_chain(
    file_paths: list[str],
    model: str = "gemma3:1b",
    chunk_size: int = 1000,
    chunk_overlap: int = 200,
    ollama_host: str = "http://localhost:11434",
    storage_dir: str = ".guardrag_storage"
) -> tuple[str, Any]:
    """
    Build a RAG chain from document files.
    
    Args:
        file_paths: List of paths to documents (PDF, TXT, DOCX)
        model: Ollama model name
        chunk_size: Text chunk size for splitting
        chunk_overlap: Overlap between chunks
        ollama_host: Ollama server URL
        storage_dir: Directory to store FAISS indices
        
    Returns:
        Tuple of (db_id, rag_chain)
    """
    embeddings = _get_embeddings()
    storage_path = Path(storage_dir)
    storage_path.mkdir(exist_ok=True)
    
    # Generate cache key based on file content and settings
    hasher = hashlib.md5()
    for fp in file_paths:
        with open(fp, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                hasher.update(chunk)
    db_id = f"{hasher.hexdigest()}_{chunk_size}_{chunk_overlap}_Offline"
    persist_dir = str(storage_path / db_id)
    
    # Load from cache if available
    if os.path.exists(persist_dir):
        print(f"Loading cached embeddings from {persist_dir}...")
        vectorstore = FAISS.load_local(
            persist_dir,
            embeddings,
            allow_dangerous_deserialization=True
        )
    else:
        print("Loading documents...")
        docs = []
        for fp in file_paths:
            ext = os.path.splitext(fp)[-1].lower()
            try:
                if ext == ".pdf":
                    try:
                        import pypdf
                    except ImportError as err:
                        raise ImportError("The 'pypdf' package is required for PDF files. Run 'pip install pypdf'.") from err
                    loader = PyPDFLoader(fp)
                elif ext == ".txt":
                    loader = TextLoader(fp, encoding="utf-8")
                elif ext in [".doc", ".docx"]:
                    try:
                        import docx2txt
                    except ImportError as err:
                        raise ImportError("The 'docx2txt' package is required for DOCX files. Run 'pip install docx2txt'.") from err
                    loader = Docx2txtLoader(fp)
                else:
                    print(f"Skipping unsupported file type: {ext}")
                    continue
                
                print(f"  {os.path.basename(fp)}")
                docs.extend(loader.load())
            except Exception as e:
                print(f"  Error loading {os.path.basename(fp)}: {e}")
                # Re-raise to be caught by the outer build_rag_chain caller if critical
                raise e
        
        if not docs:
            raise ValueError("No documents were successfully loaded.")
        
        print(f"Splitting {len(docs)} documents into chunks...")
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap
        )
        splits = splitter.split_documents(docs)
        
        if not splits:
            raise ValueError("No text could be extracted from the uploaded documents.")

        print(f"Creating embeddings for {len(splits)} chunks...")
        vectorstore = None
        for i in range(0, len(splits), 100):
            batch = splits[i : i + 100]
            if vectorstore is None:
                vectorstore = FAISS.from_documents(documents=batch, embedding=embeddings)
            else:
                vectorstore.add_documents(documents=batch)
        
        if vectorstore is None:
            raise ValueError("Failed to create FAISS vector store.")

        print(f"Saving FAISS index to {persist_dir}...")
        vectorstore.save_local(persist_dir)
    
    # Build RAG chain
    rag_chain = _build_chain_from_vectorstore(vectorstore, model, ollama_host)
    
    print("RAG chain ready!")
    return db_id, rag_chain


def _build_chain_from_vectorstore(vectorstore, model: str, ollama_host: str):
    """Build a LangChain RAG chain from a FAISS vectorstore."""
    retriever = vectorstore.as_retriever(search_kwargs={"k": 10})
    llm = ChatOllama(model=model, base_url=ollama_host.rstrip("/"), num_ctx=4096)
    
    # History-aware retriever
    ctx_q_prompt = ChatPromptTemplate.from_messages([
        ("system",
         "Given a chat history and the latest user question which might reference "
         "context in the chat history, formulate a standalone question which can be "
         "understood without the chat history. Do NOT answer the question, just "
         "reformulate it if needed and otherwise return it as is."),
        MessagesPlaceholder("chat_history"),
        ("human", "{input}"),
    ])
    history_retriever = create_history_aware_retriever(llm, retriever, ctx_q_prompt)
    
    # Q&A chain
    qa_prompt = ChatPromptTemplate.from_messages([
        ("system",
         "You are GuardRAG, a professional AI document assistant. "
         "Answer the user's question using ONLY the provided context. "
         "If the context doesn't contain the answer, politely state that the information is missing from the uploaded documents. "
         "Maintain a helpful, concise, and accurate tone.\n\n"
         "Context:\n{context}"),
        MessagesPlaceholder("chat_history"),
        ("human", "{input}"),
    ])
    qa_chain = create_stuff_documents_chain(llm, qa_prompt)
    
    return create_retrieval_chain(history_retriever, qa_chain)


def load_stored_rag_chain(
    db_id: str,
    model: str = "gemma3:1b",
    ollama_host: str = "http://localhost:11434",
    storage_dir: str = ".guardrag_storage"
):
    """
    Load a previously persisted FAISS index and build the RAG chain.
    
    Args:
        db_id: The database/index ID
        model: Ollama model name
        ollama_host: Ollama server URL
        storage_dir: Directory where FAISS indices are stored
        
    Returns:
        The RAG chain
    """
    persist_dir = Path(storage_dir) / db_id
    if not persist_dir.exists():
        raise FileNotFoundError(f"No stored index for db_id: {db_id}")
    
    embeddings = _get_embeddings()
    vectorstore = FAISS.load_local(
        str(persist_dir),
        embeddings,
        allow_dangerous_deserialization=True
    )
    
    return _build_chain_from_vectorstore(vectorstore, model, ollama_host)
