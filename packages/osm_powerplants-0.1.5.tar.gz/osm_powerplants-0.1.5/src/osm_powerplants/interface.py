# SPDX-FileCopyrightText: Contributors to osm-powerplants
#
# SPDX-License-Identifier: MIT

"""
OpenStreetMap power plant data interface.

This module provides the main interface for extracting and processing power plant
data from OpenStreetMap. It handles country validation, multi-level caching,
and data processing.

Main functions:
    process_units: Simplified entry point for most use cases
    process_countries: Lower-level function with more options
    validate_countries: Validate country names with fuzzy matching
"""

import logging
import os
from difflib import get_close_matches

import pandas as pd

from .models import Unit, Units
from .quality.rejection import RejectionTracker
from .retrieval.client import OverpassAPIClient
from .utils import get_country_code
from .workflow import Workflow

logger = logging.getLogger(__name__)

# Valid fuel types for power plant categorization
# These match powerplantmatching's standard fuel types
VALID_FUELTYPES = [
    "Nuclear",
    "Solid Biomass",
    "Biogas",
    "Wind",
    "Hydro",
    "Solar",
    "Oil",
    "Natural Gas",
    "Hard Coal",
    "Lignite",
    "Geothermal",
    "Waste",
    "Other",
]

# Valid technology types for power generation methods
# These match powerplantmatching's standard technologies
VALID_TECHNOLOGIES = [
    "Steam Turbine",
    "OCGT",
    "CCGT",
    "Run-Of-River",
    "Reservoir",
    "Pumped Storage",
    "Offshore",
    "Onshore",
    "PV",
    "CSP",
    "Combustion Engine",
    "Marine",
]

# Valid power plant set types
VALID_SETS = ["PP", "CHP", "Store"]


def get_client_params(osm_config, api_url, cache_dir):
    """Build parameters for OverpassAPIClient initialization."""
    return {
        "api_url": api_url,
        "cache_dir": cache_dir,
        "timeout": osm_config.get("overpass_api", {}).get("timeout", 300),
        "max_retries": osm_config.get("overpass_api", {}).get("max_retries", 3),
        "retry_delay": osm_config.get("overpass_api", {}).get("retry_delay", 5),
        "cache_size_gb": osm_config.get("overpass_api", {}).get("cache_size_gb", 12),
        "show_progress": osm_config.get("overpass_api", {}).get("show_progress", True),
    }


def validate_countries(
    countries: list[str], omitted_countries: list[str] = []
) -> tuple[list[str], dict[str, str]]:
    """Validate country names and provide helpful suggestions for invalid entries.

    Uses pycountry to validate country names, supporting full names, ISO codes,
    and common variations. Provides fuzzy matching suggestions for typos or
    incorrect names. Checks against omitted countries list from configuration.

    Parameters
    ----------
    countries : list of str
        Country names to validate. Accepts:
        - Full names: 'Germany', 'United States'
        - ISO 3166-1 alpha-2: 'DE', 'US'
        - ISO 3166-1 alpha-3: 'DEU', 'USA'
        - Common variations: 'USA', 'UK', 'South Korea'

    omitted_countries : list of str, optional
        List of countries to omit from processing

    Returns
    -------
    valid_countries : list of str
        List of validated country names as provided (minus omitted ones)
    country_code_map : dict
        Mapping of country names to ISO alpha-2 codes

    Raises
    ------
    ValueError
        If any country names are invalid. Error message includes
        suggestions for similar valid names and shows which entries
        were valid vs invalid.

    Examples
    --------
    >>> valid, codes = validate_countries(['Germany', 'France'])
    >>> print(codes)
    {'Germany': 'DE', 'France': 'FR'}

    >>> validate_countries(['Germny'])  # Typo
    ValueError: ❌ Invalid country names detected...
         ℹ️  Did you mean: 'Germany', 'Armenia'
    """
    import pycountry

    countries_to_be_omitted = []
    if omitted_countries:
        # Filter out omitted countries
        filtered_countries = []
        for country in countries:
            if country in omitted_countries:
                logger.info(
                    f"Omitting country '{country}' as specified in configuration (omitted_countries)"
                )
                countries_to_be_omitted.append(country)
            else:
                filtered_countries.append(country)
        countries = filtered_countries

    # If no countries left after omission, return empty results
    if not countries:
        logger.warning(
            "No countries left to process after applying omitted_countries filter"
        )
        return [], {}

    valid_countries = []
    invalid_countries = []
    country_code_map = {}

    for country in countries:
        country_code = get_country_code(country)
        if country_code is not None:
            valid_countries.append(country)
            country_code_map[country] = country_code
        else:
            invalid_countries.append(country)

    if invalid_countries:
        all_country_names = [c.name for c in pycountry.countries]  # type: ignore
        all_country_names.extend([c.alpha_2 for c in pycountry.countries])  # type: ignore
        all_country_names.extend([c.alpha_3 for c in pycountry.countries])  # type: ignore

        country_variations = {
            "USA": "United States",
            "UK": "United Kingdom",
            "South Korea": "Korea, Republic of",
            "North Korea": "Korea, Democratic People's Republic of",
            "Russia": "Russian Federation",
            "Iran": "Iran, Islamic Republic of",
            "Syria": "Syrian Arab Republic",
            "Venezuela": "Venezuela, Bolivarian Republic of",
            "Bolivia": "Bolivia, Plurinational State of",
            "Tanzania": "Tanzania, United Republic of",
            "Vietnam": "Viet Nam",
            "Czech Republic": "Czechia",
            "Macedonia": "North Macedonia",
            "Turkey": "Türkiye",
        }
        all_country_names.extend(country_variations.keys())

        error_parts = [
            f"❌ Invalid country names detected: {len(invalid_countries)} out of {len(countries + countries_to_be_omitted)} countries",
        ]

        if countries_to_be_omitted:
            error_parts.append(
                f"\n⏭️  Omitted countries (from countries_to_be_omitted config): {', '.join(countries_to_be_omitted)}"
            )

        error_parts.append("\nInvalid entries:")

        for invalid in invalid_countries:
            error_parts.append(f"  ❌ '{invalid}'")

            suggestions = get_close_matches(invalid, all_country_names, n=3, cutoff=0.6)
            if suggestions:
                strings = []
                for suggestion in suggestions:
                    strings.append(f"'{suggestion}'")
                error_parts.append(f"     ℹ️  Did you mean: {', '.join(strings)}")

            if invalid in country_variations:
                error_parts.append(
                    f"     ℹ️  Try using: '{country_variations[invalid]}'"
                )

        error_parts.extend(
            [
                "\n✅ Valid entries:",
                *[
                    f"  ✅ '{valid}' → {country_code_map[valid]}"
                    for valid in valid_countries[:5]
                ],
                f"  ... and {len(valid_countries) - 5} more"
                if len(valid_countries) > 5
                else "",
                "\n📝 Accepted formats:",
                "  - Full name: 'Germany', 'United States'",
                "  - ISO 3166-1 alpha-2: 'DE', 'US'",
                "  - ISO 3166-1 alpha-3: 'DEU', 'USA'",
                "  - Common names: 'USA', 'UK', 'South Korea'",
                "\n⚠️  All countries must be valid before processing can begin.",
                "Please correct the invalid entries and try again.",
            ]
        )

        error_msg = "\n".join(filter(None, error_parts))
        logger.error(error_msg)
        raise ValueError(error_msg)

    logger.info(f"✅ Successfully validated all {len(valid_countries)} countries")
    if countries_to_be_omitted:
        logger.info(
            f"ℹ️  Note: {len(countries_to_be_omitted)} countries were omitted per configuration"
        )
    logger.debug(
        f"Country codes: {', '.join(f'{c}={code}' for c, code in country_code_map.items())}"
    )

    return valid_countries, country_code_map


def process_countries(
    countries,
    csv_cache_path,
    cache_dir,
    update,
    osm_config,
    raw=False,
    rejection_tracker: RejectionTracker | None = None,
):
    """Process power plant data for specified countries.

    Parameters
    ----------
    countries : list of str
        Country names or ISO codes
    csv_cache_path : str
        Path to CSV cache file
    cache_dir : str
        Cache directory path
    update : bool
        Force cache update if True
    osm_config : dict
        Configuration dictionary
    raw : bool, default False
        If True, return all columns including metadata
    rejection_tracker : RejectionTracker, optional
        If supplied, receives every rejection observed during processing
        so callers can inspect *why* plants/generators were dropped.
        Only the API path populates the tracker — cache hits skip it
        because the rejection record was already discarded when the
        country was first fetched.

    Returns
    -------
    pd.DataFrame
        Power plant data
    """
    logger.info(f"Starting country validation for {len(countries)} countries...")

    api_url = osm_config.get("overpass_api", {}).get("api_url")
    current_config_hash = Unit._generate_config_hash(osm_config)
    force_refresh = osm_config.get("force_refresh", False)
    omitted_countries = osm_config.get("omitted_countries", [])
    try:
        valid_countries, country_code_map = validate_countries(
            countries, omitted_countries
        )
    except ValueError as e:
        raise ValueError(
            f"Country validation failed. Cannot proceed with OSM data processing.\n{str(e)}"
        ) from e

    logger.info(
        f"Country validation successful! Processing OSM data for {len(valid_countries)} countries: "
        f"{', '.join(valid_countries[:5])}"
        f"{f' and {len(valid_countries) - 5} more' if len(valid_countries) > 5 else ''}"
    )

    all_valid_data = pd.DataFrame()

    # Create single client for all countries
    client_params = get_client_params(osm_config, api_url, cache_dir)

    with OverpassAPIClient(**client_params) as client:
        for i, country in enumerate(valid_countries, 1):
            logger.info(
                f"Processing country {i}/{len(valid_countries)}: {country} ({country_code_map[country]})"
            )

            country_data = process_single_country(
                country,
                csv_cache_path,
                current_config_hash,
                update,
                force_refresh,
                osm_config,
                client,
                rejection_tracker=rejection_tracker,
            )

            if country_data is not None and not country_data.empty:
                if not raw:
                    country_data = validate_and_standardize_df(
                        country_data,
                        VALID_FUELTYPES,
                        VALID_TECHNOLOGIES,
                        VALID_SETS,
                    )
                all_valid_data = pd.concat(
                    [all_valid_data, country_data], ignore_index=True
                )

    logger.info(f"✅ Successfully processed all {len(valid_countries)} countries")
    return all_valid_data


def process_single_country(
    country,
    csv_cache_path,
    config_hash,
    update,
    force_refresh,
    osm_config,
    client,
    rejection_tracker: RejectionTracker | None = None,
):
    """Process a single country, checking cache first.

    Parameters
    ----------
    country : str
        Country name
    csv_cache_path : str
        Path to CSV cache
    config_hash : str
        Current config hash for cache validation
    update : bool
        Force update if True
    force_refresh : bool
        Skip cache if True
    osm_config : dict
        Configuration dictionary
    client : OverpassAPIClient
        API client instance
    rejection_tracker : RejectionTracker, optional
        Forwarded to the API path; cache hits do not populate it.

    Returns
    -------
    pd.DataFrame or None
        Country data or None if not found
    """
    force_refresh = osm_config.get("force_refresh", False)

    if force_refresh:
        return process_from_api(
            csv_cache_path, country, osm_config, client, rejection_tracker
        )

    # Check CSV cache first
    country_data = check_csv_cache(csv_cache_path, country, config_hash, update)
    if country_data is not None:
        return country_data

    country_data = check_units_cache(csv_cache_path, country, config_hash, client)
    if country_data is not None:
        return country_data

    # Process from API using existing client
    return process_from_api(
        csv_cache_path, country, osm_config, client, rejection_tracker
    )


def check_csv_cache(cache_path, country, config_hash, update):
    """Check CSV cache for valid country data.

    Returns cached data only if config_hash matches current configuration.
    """
    if update or not os.path.exists(cache_path):
        return None

    try:
        # More robust CSV reading with proper error handling
        csv_data = pd.read_csv(
            cache_path,
            quoting=1,  # QUOTE_ALL
            escapechar="\\",
            on_bad_lines="skip",
        )

        if csv_data.empty:
            logger.debug(f"CSV cache exists but is empty: {cache_path}")
            return None

        country_rows = csv_data[csv_data["Country"] == country]

        if country_rows.empty:
            logger.debug(f"No data for {country} in CSV cache")
            return None

        if "config_hash" not in country_rows.columns:
            logger.debug(f"CSV cache for {country} missing config_hash column")
            return None

        if country_rows["config_hash"].iloc[0] == config_hash:
            logger.info(f"Using CSV cache for {country} (matching config)")
            return country_rows.copy()
        else:
            logger.debug(f"CSV cache for {country} has outdated config_hash")
            return None

    except (pd.errors.EmptyDataError, pd.errors.ParserError) as e:
        logger.warning(f"CSV cache file corrupted: {str(e)}, removing file")
        try:
            os.remove(cache_path)
        except OSError:
            pass
        return None
    except Exception as e:
        logger.debug(f"Error reading CSV cache: {str(e)}")
        return None


def check_units_cache(csv_cache_path, country, config_hash, client):
    """Check units cache for valid country data.

    Returns cached units only if config_hash matches. Updates CSV cache on hit.
    """
    country_code = get_country_code(country)
    if country_code is None:
        logger.warning(f"Invalid country name: {country}, skipping units cache check")
        return None

    try:
        cached_units = client.cache.get_units(country_code)

        valid_units = []
        for unit in cached_units:
            if hasattr(unit, "config_hash") and unit.config_hash == config_hash:
                valid_units.append(unit)

        if valid_units:
            logger.info(f"Found {len(valid_units)} valid cached units for {country}")
            country_data = pd.DataFrame([unit.to_dict() for unit in valid_units])

            update_csv_cache(csv_cache_path, country, country_data)
            return country_data
    except Exception as e:
        logger.error(f"Error accessing units cache for {country}: {str(e)}")

    return None


def process_from_api(
    csv_cache_path,
    country,
    osm_config,
    client,
    rejection_tracker: RejectionTracker | None = None,
):
    """Download and process country data from Overpass API.

    Creates workflow, processes country, updates CSV cache with results.
    If ``rejection_tracker`` is supplied it is reused (so aggregated
    results reflect every processed country); otherwise a local tracker
    is created and discarded.
    """
    logger.info(f"No valid cache for {country}, processing from API")

    try:
        units_collection = Units()
        if rejection_tracker is None:
            rejection_tracker = RejectionTracker()

        workflow = Workflow(
            client=client,
            rejection_tracker=rejection_tracker,
            units=units_collection,
            config=osm_config,
        )

        updated_units_collection, _ = workflow.process_country_data(country)

        country_units = updated_units_collection.filter_by_country(country)

        if len(country_units) > 0:
            logger.info(f"Processed {len(country_units)} units for {country}")
            country_data = pd.DataFrame([unit.to_dict() for unit in country_units])

            update_csv_cache(csv_cache_path, country, country_data)

            return country_data
        else:
            logger.warning(f"No units found for {country}")
            return None
    except Exception as e:
        logger.error(f"Error processing {country} from API: {str(e)}")
        return None


def update_csv_cache(cache_path, country, country_data):
    """Update CSV cache with new country data.

    Replaces existing data for the country, preserving other countries.
    """
    if country_data.empty:
        return

    try:
        os.makedirs(os.path.dirname(cache_path), exist_ok=True)

        if os.path.exists(cache_path):
            try:
                # More robust CSV reading with proper quoting and error handling
                full_csv = pd.read_csv(
                    cache_path,
                    quoting=1,  # QUOTE_ALL
                    escapechar="\\",
                    on_bad_lines="skip",
                )
                full_csv = full_csv[full_csv["Country"] != country]
                updated_csv = pd.concat([full_csv, country_data], ignore_index=True)
                # Write with proper quoting to handle special characters
                updated_csv.to_csv(
                    cache_path,
                    index=False,
                    quoting=1,  # QUOTE_ALL
                    escapechar="\\",
                )
                logger.info(
                    f"Updated CSV cache with {len(country_data)} entries for {country}"
                )
            except (pd.errors.EmptyDataError, pd.errors.ParserError) as e:
                logger.warning(f"CSV cache corrupted, recreating: {str(e)}")
                # If cache is corrupted, start fresh
                country_data.to_csv(
                    cache_path,
                    index=False,
                    quoting=1,  # QUOTE_ALL
                    escapechar="\\",
                )
                logger.info(
                    f"Recreated CSV cache with {len(country_data)} entries for {country}"
                )
        else:
            country_data.to_csv(
                cache_path,
                index=False,
                quoting=1,  # QUOTE_ALL
                escapechar="\\",
            )
            logger.info(
                f"Created new CSV cache with {len(country_data)} entries for {country}"
            )
    except Exception as e:
        logger.warning(f"Error updating CSV cache: {str(e)}")


def validate_and_standardize_df(
    df, valid_fueltypes=None, valid_technologies=None, valid_sets=None
):
    """Remove metadata columns and validate data.

    Removes cache-related columns (config_hash, created_at, etc.) and
    logs warnings for invalid fuel types, technologies, or sets.

    Parameters
    ----------
    df : pd.DataFrame
        Power plant data
    valid_fueltypes : list of str, optional
        Allowed fuel types
    valid_technologies : list of str, optional
        Allowed technologies
    valid_sets : list of str, optional
        Allowed set types

    Returns
    -------
    pd.DataFrame
        DataFrame with metadata columns removed
    """
    if df.empty:
        return df

    if valid_fueltypes is None:
        valid_fueltypes = VALID_FUELTYPES
    if valid_technologies is None:
        valid_technologies = VALID_TECHNOLOGIES
    if valid_sets is None:
        valid_sets = VALID_SETS

    df = df.copy()

    # Remove only cache-related metadata columns
    metadata_columns = [
        "created_at",
        "config_hash",
        "config_version",
        "processing_parameters",
        "id",  # redundant with projectID
    ]
    df = df.drop(columns=[col for col in metadata_columns if col in df.columns])

    # Validate but don't remove data
    if "Fueltype" in df.columns:
        invalid_fuels = (
            df["Fueltype"].dropna().apply(lambda x: x not in valid_fueltypes)
        )
        if invalid_fuels.any():
            logger.warning(
                f"Found {invalid_fuels.sum()} rows with invalid Fueltype values"
            )

    if "Technology" in df.columns:
        invalid_techs = (
            df["Technology"].dropna().apply(lambda x: x not in valid_technologies)
        )
        if invalid_techs.any():
            logger.warning(
                f"Found {invalid_techs.sum()} rows with invalid Technology values"
            )

    if "Set" in df.columns:
        invalid_sets = df["Set"].dropna().apply(lambda x: x not in valid_sets)
        if invalid_sets.any():
            logger.warning(f"Found {invalid_sets.sum()} rows with invalid Set values")

    return df


# Main entry point
def process_units(
    countries: list[str],
    config: dict,
    cache_dir: str,
    output_path: str | None = None,
    raw: bool = True,
    rejected_output_path: str | None = None,
) -> pd.DataFrame:
    """Process power plant data for specified countries.

    Parameters
    ----------
    countries : list[str]
        Country names or ISO codes (e.g., ['Germany', 'FR', 'ESP'])
    config : dict
        Configuration from get_config()
    cache_dir : str
        Cache directory from get_cache_dir()
    output_path : str, optional
        Save CSV of accepted plants to this path if provided
    raw : bool, default True
        If True, return all columns. If False, remove metadata columns
        (config_hash, created_at, processing_parameters, id).
    rejected_output_path : str, optional
        If provided, write the rejection report (CSV) to this path and
        a sibling GeoJSON file with the same stem and ``.geojson``
        suffix. The report lists every OSM element that was dropped
        during processing and the reason (e.g. ``Missing output tag``,
        ``Capacity regex no match``) — useful for diagnosing why a
        country returned fewer plants than expected and for feeding
        triage targets back to OSM contributors.

        Only API-path processing populates the report: countries served
        from cache contribute nothing. Set ``config['force_refresh'] =
        True`` to force a fresh fetch when you need a complete report.

    Returns
    -------
    pd.DataFrame
        Power plant data with columns: projectID, Name, Country, lat, lon,
        Fueltype, Technology, Set, Capacity, DateIn, type, capacity_source.
        When raw=True, also includes metadata columns.

    Examples
    --------
    >>> from osm_powerplants import process_units, get_config, get_cache_dir
    >>> config = get_config()
    >>> df = process_units(
    ...     countries=['Malta', 'Luxembourg'],
    ...     config=config,
    ...     cache_dir=str(get_cache_dir(config)),
    ... )

    Capture the rejection report to understand why plants were dropped:

    >>> config['force_refresh'] = True
    >>> df = process_units(
    ...     countries=['Kenya'],
    ...     config=config,
    ...     cache_dir=str(get_cache_dir(config)),
    ...     output_path='kenya.csv',
    ...     rejected_output_path='kenya_rejected.csv',
    ... )
    """
    import os

    csv_cache_path = os.path.join(cache_dir, "osm_data.csv")
    update = config.get("force_refresh", False)

    tracker = RejectionTracker() if rejected_output_path else None

    df = process_countries(
        countries=countries,
        csv_cache_path=csv_cache_path,
        cache_dir=cache_dir,
        update=update,
        osm_config=config,
        raw=raw,
        rejection_tracker=tracker,
    )

    if output_path and not df.empty:
        df.to_csv(output_path, index=False)

    if tracker is not None and rejected_output_path:
        _write_rejection_report(tracker, rejected_output_path)

    return df


def _write_rejection_report(tracker: RejectionTracker, csv_path: str) -> None:
    """Persist a rejection tracker as CSV plus a sibling GeoJSON file.

    Always writes the CSV (even when empty) so downstream tooling can
    rely on the artefact's existence; skips the GeoJSON when there are
    no rejections with coordinates to surface.
    """
    csv_dir = os.path.dirname(csv_path)
    if csv_dir:
        os.makedirs(csv_dir, exist_ok=True)

    tracker.generate_report().to_csv(csv_path, index=False)

    root, _ = os.path.splitext(csv_path)
    geojson_path = f"{root}.geojson"
    if tracker.get_total_count() > 0:
        tracker.save_geojson(geojson_path)
    else:
        logger.info(f"No rejections recorded — skipping GeoJSON at {geojson_path}")
