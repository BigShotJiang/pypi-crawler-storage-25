"""AIVibe MCP server — read-only tools for querying platform data."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from aivibe_mcp.client import api_get, api_post

mcp = FastMCP("aivibe")

# ── IMPORTANT DATA MODEL NOTE ───────────────────────────────────────────────
# The platform has two independent data modules:
#
# 1. DIAGNOSE (surveys) — responses are ANONYMOUS. There is no link between
#    a survey response and a specific person or team member. You cannot
#    cross-reference survey answers with task map entries at the individual
#    or team level. This is by design for respondent privacy.
#
# 2. MAP (task maps) — task entries are ATTRIBUTED to named team members.
#    Each task entry has a member_id and member_name.
#
# Cross-referencing between modules is only possible at the ORGANIZATION
# level (e.g., "org X has 50 survey responses AND 7 mapped teams").
# Never attempt to correlate individual survey answers with specific
# team members — the data model does not support it.
# ─────────────────────────────────────────────────────────────────────────────


# ── Organizations ────────────────────────────────────────────────────────────

@mcp.tool()
def list_organizations() -> str:
    """List all accessible organizations. Names are anonymized (shown as org codes)."""
    return api_get("/api/platform/orgs")


@mcp.tool()
def get_organization(org_id: int) -> str:
    """Get organization details by ID."""
    return api_get(f"/api/platform/orgs/{org_id}")


# ── Surveys (Diagnose module) ───────────────────────────────────────────────

@mcp.tool()
def list_surveys(org_id: int | None = None) -> str:
    """List surveys, optionally filtered by organization ID."""
    params = {"organization_id": org_id} if org_id is not None else None
    return api_get("/api/diagnose/surveys", params=params)


@mcp.tool()
def get_survey(survey_id: str) -> str:
    """Get survey details by ID."""
    return api_get(f"/api/diagnose/surveys/{survey_id}")


@mcp.tool()
def get_survey_summary(survey_id: str, org_id: int | None = None, template_id: str | None = None) -> str:
    """Get a lightweight survey analytics summary (~5-10K instead of 300K). Returns: total responses, completed/in-progress counts, and per-question score distributions (option counts and percentages). Does NOT include raw responses or free-text answers. Use this first — only use get_survey_results_full if you need the complete payload. IMPORTANT: Survey responses are ANONYMOUS — there is no link between a survey response and a specific person or team member. You CANNOT cross-reference survey answers with task map entries at the individual or team level. Cross-module analysis is only possible at the organization level."""
    params: dict[str, str] = {}
    if org_id is not None:
        params["organization_ids"] = str(org_id)
    if template_id is not None:
        params["template_id"] = template_id
    return api_get(f"/api/diagnose/reporting/summary/{survey_id}", params=params or None)


@mcp.tool()
def get_survey_results_detail(survey_id: str, org_id: int | None = None) -> str:
    """Get detailed survey analytics with per-question breakdowns. Can be large — ALWAYS pass org_id to filter to a single organization (much smaller response). Without org_id, the response may exceed context limits (300K+). Prefer get_survey_summary first for counts and distributions; use this only when you need the full question-level detail for a specific org."""
    params: dict[str, str] = {}
    if org_id is not None:
        params["organization_ids"] = str(org_id)
    return api_get(f"/api/diagnose/reporting/analytics/{survey_id}", params=params or None)


# ── Teams (Map module) ──────────────────────────────────────────────────────

@mcp.tool()
def list_teams(org_id: int | None = None, page: int = 1, page_size: int = 50) -> str:
    """List teams, optionally filtered by organization ID. Returns a PAGINATED response: {items: [...], total, page, page_size}. Each item has: id (UUID), name, organization_id, organization_name, member_count, total_task_entries, fully_assessed_tasks, managers, region, division, team_type."""
    params: dict[str, str | int] = {"page": page, "page_size": page_size}
    if org_id is not None:
        params["organization_id"] = org_id
    return api_get("/api/map/teams", params=params)


@mcp.tool()
def get_team(team_id: str) -> str:
    """Get team details by ID. team_id is a UUID string."""
    return api_get(f"/api/map/teams/{team_id}")


@mcp.tool()
def get_team_members(team_id: str) -> str:
    """List members of a team. team_id is a UUID string."""
    return api_get(f"/api/map/teams/{team_id}/members")


@mcp.tool()
def get_team_roles(team_id: str) -> str:
    """List roles defined for a team. team_id is a UUID string."""
    return api_get(f"/api/map/teams/{team_id}/roles")


@mcp.tool()
def get_team_work_areas(team_id: str) -> str:
    """List work areas for a team. team_id is a UUID string."""
    return api_get(f"/api/map/teams/{team_id}/work-areas")


@mcp.tool()
def get_team_task_entries(team_id: str) -> str:
    """List all task entries (task map data) for a team. Each entry represents a task performed by a NAMED team member (unlike survey responses which are anonymous). Key fields: id (entry UUID), label (task name), frequency (time proportion — values: 'Nearly none of my time', 'Little of my time', 'Some of my time', 'A lot of my time', 'Most of my time', or null if not assessed), enjoyment (values: 'High', 'Medium', 'Low', or null if not assessed), automation_type (current automation level — values: '0', '25', '50', '75', '100', or null if not assessed — this is NOT automation potential, it is how automated the task IS TODAY), app_ids (UUIDs of tools used — resolve via resolve_catalog_app_ids), work_area_id, work_area_label, member_id, member_name. NOTE: Task map data is attributed to individuals. Survey (Diagnose) data is anonymous. Do NOT cross-reference individual survey answers with task map members. team_id is a UUID string."""
    return api_get(f"/api/map/teams/{team_id}/task-entries")


@mcp.tool()
def get_team_summary(team_id: str) -> str:
    """Get team reporting summary. Returns: team_id, team_name, organization_id, organization_name, total_task_entries, members_with_entries, total_members, active_days, fully_assessed_tasks. team_id is a UUID string."""
    return api_get(f"/api/map/reports/teams/{team_id}/summary")


@mcp.tool()
def get_org_map_summary(org_id: int) -> str:
    """Get organization-level map reporting summary. Returns: org_id, org_name, total_task_entries, members_with_entries, total_members, teams_count, active_days, fully_assessed_tasks."""
    return api_get(f"/api/map/reports/organizations/{org_id}/summary")


@mcp.tool()
def get_top_tasks(org_id: int | None = None) -> str:
    """Get the most common tasks ranked by how many people perform them. Returns: label (task name), frequency (time proportion — e.g. 'Most of my time', 'Some of my time'), count (number of people doing this task). Optionally filtered by org. NOTE: this is a popularity ranking, not an automation/AI opportunity ranking."""
    params = {"org_ids": str(org_id)} if org_id is not None else None
    return api_get("/api/map/reports/top-tasks", params=params)


# ── Catalog (tool/app name resolution) ───────────────────────────────────────

@mcp.tool()
def search_catalog_apps(query: str) -> str:
    """Search for tools/apps by name substring. Returns matching apps with id, name, is_custom. Use this when you know a tool NAME and want to find it. To resolve app UUIDs to names, use resolve_catalog_app_ids instead."""
    return api_get("/api/map/catalog-apps/search", params={"q": query})


@mcp.tool()
def resolve_catalog_app_ids(ids: list[str]) -> str:
    """Resolve app UUIDs to human-readable names. Pass a list of UUID strings from task entry app_ids. Returns: id, name, is_custom for each resolved app."""
    return api_post("/api/map/catalog-apps/by-ids", body={"ids": ids})


# ── Recos module ─────────────────────────────────────────────────────────────

@mcp.tool()
def check_recos_freshness() -> str:
    """Check data freshness for recommendations."""
    return api_get("/api/recos/freshness")


def main() -> None:
    """Entry point for the MCP server (stdio transport)."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
