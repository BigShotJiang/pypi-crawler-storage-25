"""Tests for the MCP server HTTP client."""

import json
from pathlib import Path
from unittest.mock import patch

from aivibe_mcp.client import _load_config, _version_lt, api_get


class TestVersionComparison:
    def test_equal(self) -> None:
        assert _version_lt("0.1.0", "0.1.0") is False

    def test_older(self) -> None:
        assert _version_lt("0.1.0", "0.2.0") is True

    def test_newer(self) -> None:
        assert _version_lt("0.2.0", "0.1.0") is False


class TestLoadConfig:
    def test_env_vars_take_precedence(self, tmp_path: Path) -> None:
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({"api_key": "ak_file", "api_url": "http://file"}))

        with patch("aivibe_mcp.client.CONFIG_FILE", config_file), \
             patch.dict("os.environ", {"AIVIBE_API_KEY": "ak_env", "AIVIBE_API_URL": "http://env"}):
            config = _load_config()
            assert config["api_key"] == "ak_env"
            assert config["api_url"] == "http://env"

    def test_falls_back_to_file(self, tmp_path: Path) -> None:
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({"api_key": "ak_file", "api_url": "http://file"}))

        with patch("aivibe_mcp.client.CONFIG_FILE", config_file), \
             patch.dict("os.environ", {}, clear=True):
            config = _load_config()
            assert config["api_key"] == "ak_file"

    def test_empty_when_nothing_configured(self, tmp_path: Path) -> None:
        config_file = tmp_path / "nonexistent" / "config.json"
        with patch("aivibe_mcp.client.CONFIG_FILE", config_file), \
             patch.dict("os.environ", {}, clear=True):
            config = _load_config()
            assert config == {}


class TestApiGet:
    def test_returns_error_without_config(self, tmp_path: Path) -> None:
        config_file = tmp_path / "nonexistent" / "config.json"
        with patch("aivibe_mcp.client.CONFIG_FILE", config_file), \
             patch.dict("os.environ", {}, clear=True):
            result = json.loads(api_get("/api/test"))
            assert "error" in result
            assert "No API key" in result["error"]
