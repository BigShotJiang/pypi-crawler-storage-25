"""Tests for the MCP server tool definitions."""

import json
from unittest.mock import patch

from aivibe_mcp.server import (
    check_recos_freshness,
    get_organization,
    get_org_map_summary,
    get_survey,
    get_survey_results_detail,
    get_survey_summary,
    get_team,
    get_team_members,
    get_team_roles,
    get_team_summary,
    get_team_task_entries,
    get_team_work_areas,
    get_top_tasks,
    list_organizations,
    resolve_catalog_app_ids,
    search_catalog_apps,
    list_surveys,
    list_teams,
)

MOCK_RESPONSE = json.dumps([{"id": 1, "name": "Test"}], indent=2)
TEAM_UUID = "a1b2c3d4-e5f6-7890-abcd-ef1234567890"


class TestTools:
    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_organizations(self, mock_get) -> None:
        result = list_organizations()
        mock_get.assert_called_once_with("/api/platform/orgs")
        assert "Test" in result

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_organization(self, mock_get) -> None:
        get_organization(1)
        mock_get.assert_called_once_with("/api/platform/orgs/1")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_surveys_no_filter(self, mock_get) -> None:
        list_surveys()
        mock_get.assert_called_once_with("/api/diagnose/surveys", params=None)

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_surveys_with_org(self, mock_get) -> None:
        list_surveys(org_id=5)
        mock_get.assert_called_once_with("/api/diagnose/surveys", params={"organization_id": 5})

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_survey(self, mock_get) -> None:
        get_survey("abc-123")
        mock_get.assert_called_once_with("/api/diagnose/surveys/abc-123")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_survey_summary(self, mock_get) -> None:
        get_survey_summary("abc-123")
        mock_get.assert_called_once_with("/api/diagnose/reporting/summary/abc-123", params=None)

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_survey_summary_with_org(self, mock_get) -> None:
        get_survey_summary("abc-123", org_id=5)
        mock_get.assert_called_once_with(
            "/api/diagnose/reporting/summary/abc-123", params={"organization_ids": "5"}
        )

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_survey_results_detail_no_org(self, mock_get) -> None:
        get_survey_results_detail("abc-123")
        mock_get.assert_called_once_with("/api/diagnose/reporting/analytics/abc-123", params=None)

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_survey_results_detail_with_org(self, mock_get) -> None:
        get_survey_results_detail("abc-123", org_id=5)
        mock_get.assert_called_once_with(
            "/api/diagnose/reporting/analytics/abc-123", params={"organization_ids": "5"}
        )

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_teams_no_filter(self, mock_get) -> None:
        list_teams()
        mock_get.assert_called_once_with("/api/map/teams", params={"page": 1, "page_size": 50})

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_teams_with_org(self, mock_get) -> None:
        list_teams(org_id=3)
        mock_get.assert_called_once_with(
            "/api/map/teams", params={"page": 1, "page_size": 50, "organization_id": 3}
        )

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_list_teams_with_pagination(self, mock_get) -> None:
        list_teams(page=2, page_size=10)
        mock_get.assert_called_once_with("/api/map/teams", params={"page": 2, "page_size": 10})

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_team(self, mock_get) -> None:
        get_team(TEAM_UUID)
        mock_get.assert_called_once_with(f"/api/map/teams/{TEAM_UUID}")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_team_members(self, mock_get) -> None:
        get_team_members(TEAM_UUID)
        mock_get.assert_called_once_with(f"/api/map/teams/{TEAM_UUID}/members")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_team_roles(self, mock_get) -> None:
        get_team_roles(TEAM_UUID)
        mock_get.assert_called_once_with(f"/api/map/teams/{TEAM_UUID}/roles")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_team_work_areas(self, mock_get) -> None:
        get_team_work_areas(TEAM_UUID)
        mock_get.assert_called_once_with(f"/api/map/teams/{TEAM_UUID}/work-areas")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_team_task_entries(self, mock_get) -> None:
        get_team_task_entries(TEAM_UUID)
        mock_get.assert_called_once_with(f"/api/map/teams/{TEAM_UUID}/task-entries")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_team_summary(self, mock_get) -> None:
        get_team_summary(TEAM_UUID)
        mock_get.assert_called_once_with(f"/api/map/reports/teams/{TEAM_UUID}/summary")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_org_map_summary(self, mock_get) -> None:
        get_org_map_summary(1)
        mock_get.assert_called_once_with("/api/map/reports/organizations/1/summary")

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_top_tasks(self, mock_get) -> None:
        get_top_tasks(org_id=1)
        mock_get.assert_called_once_with("/api/map/reports/top-tasks", params={"org_ids": "1"})

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_get_top_tasks_no_filter(self, mock_get) -> None:
        get_top_tasks()
        mock_get.assert_called_once_with("/api/map/reports/top-tasks", params=None)

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_search_catalog_apps(self, mock_get) -> None:
        search_catalog_apps("slack")
        mock_get.assert_called_once_with("/api/map/catalog-apps/search", params={"q": "slack"})

    @patch("aivibe_mcp.server.api_post", return_value=MOCK_RESPONSE)
    def test_resolve_catalog_app_ids(self, mock_post) -> None:
        resolve_catalog_app_ids(["uuid1", "uuid2"])
        mock_post.assert_called_once_with(
            "/api/map/catalog-apps/by-ids", body={"ids": ["uuid1", "uuid2"]}
        )

    @patch("aivibe_mcp.server.api_get", return_value=MOCK_RESPONSE)
    def test_check_recos_freshness(self, mock_get) -> None:
        check_recos_freshness()
        mock_get.assert_called_once_with("/api/recos/freshness")
