# aivibe-mcp

MCP server for read-only access to AIVibe platform data. Designed for Claude Desktop and Cowork.

## Installation

```bash
pipx install aivibe-mcp
```

## Setup

Run `aivibe setup` (from the `aivibe-cli` package) to configure your API key, or create `~/.aivibe/config.json` manually:

```json
{
  "api_key": "ak_...",
  "api_url": "https://api.aivibe.app"
}
```

Then add to your Claude Desktop config (`~/Library/Application Support/Claude/claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "aivibe": {
      "command": "/full/path/to/aivibe-mcp",
      "args": []
    }
  }
}
```

Restart Claude Desktop. The AIVibe tools will appear automatically.

Requires Python 3.10+.
