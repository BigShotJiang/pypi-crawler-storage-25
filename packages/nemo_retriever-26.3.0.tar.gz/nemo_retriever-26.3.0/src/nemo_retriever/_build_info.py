"""Build metadata written by CI before packaging."""

BUILD_GIT_SHA = "15b2bc05681599329276e46e83edfa0f15bb4318"
BUILD_DATE = "2026-03-16T18:28:10Z"
