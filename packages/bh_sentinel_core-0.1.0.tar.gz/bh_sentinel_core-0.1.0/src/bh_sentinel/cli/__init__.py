"""bh-sentinel CLI tools."""
