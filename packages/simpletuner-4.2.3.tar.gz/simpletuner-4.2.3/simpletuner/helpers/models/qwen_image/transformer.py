# Copyright 2025 Qwen-Image Team, The HuggingFace Team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import functools
import math
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from diffusers.configuration_utils import ConfigMixin, register_to_config
from diffusers.loaders import FromOriginalModelMixin, PeftAdapterMixin
from diffusers.models._modeling_parallel import ContextParallelInput, ContextParallelOutput
from diffusers.models.attention import AttentionMixin, FeedForward
from diffusers.models.attention_dispatch import dispatch_attention_fn
from diffusers.models.attention_processor import Attention
from diffusers.models.cache_utils import CacheMixin
from diffusers.models.embeddings import TimestepEmbedding, Timesteps
from diffusers.models.modeling_outputs import Transformer2DModelOutput
from diffusers.models.modeling_utils import ModelMixin
from diffusers.models.normalization import AdaLayerNormContinuous, RMSNorm
from diffusers.utils import USE_PEFT_BACKEND, deprecate, logging, scale_lora_layers, unscale_lora_layers
from diffusers.utils.torch_utils import maybe_allow_in_graph

from simpletuner.helpers.musubi_block_swap import MusubiBlockSwapManager
from simpletuner.helpers.training.qk_clip_logging import publish_attention_max_logits
from simpletuner.helpers.training.tread import TREADRouter
from simpletuner.helpers.utils.patching import MutableModuleList, PatchableModule

logger = logging.get_logger(__name__)  # pylint: disable=invalid-name

# Global flag to force tiled attention (set via config or after OOM).
# WARNING: If this is set due to OOM during forward, gradient checkpointing may fail
# because the recomputation will take a different code path than the original forward.
# For reliable training with checkpointing, set this explicitly before training starts.
_USE_TILED_ATTENTION = False


def _tiled_scaled_dot_product_attention(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    attn_mask: Optional[torch.Tensor] = None,
    dropout_p: float = 0.0,
    is_causal: bool = False,
    tile_size: int = 1024,
) -> torch.Tensor:
    """
    Tiled attention that processes queries in chunks to reduce peak memory.

    This is mathematically equivalent to standard scaled dot-product attention
    because each query position's attention is independent (softmax is per-row).

    Args:
        query: [B, seq_q, heads, head_dim] or [B, heads, seq_q, head_dim]
        key: [B, seq_kv, heads, head_dim] or [B, heads, seq_kv, head_dim]
        value: [B, seq_kv, heads, head_dim] or [B, heads, seq_kv, head_dim]
        attn_mask: Optional attention mask
        dropout_p: Dropout probability (only applied in training)
        is_causal: Whether to use causal masking
        tile_size: Number of query positions to process at once

    Returns:
        Attention output with same shape as query
    """
    # dispatch_attention_fn uses [B, seq, heads, head_dim] format
    # but F.scaled_dot_product_attention uses [B, heads, seq, head_dim]
    # We need to handle the format from dispatch_attention_fn
    batch_size, seq_q, num_heads, head_dim = query.shape
    seq_kv = key.shape[1]

    # Transpose to [B, heads, seq, head_dim] for F.sdpa
    query = query.transpose(1, 2)  # [B, heads, seq_q, head_dim]
    key = key.transpose(1, 2)  # [B, heads, seq_kv, head_dim]
    value = value.transpose(1, 2)  # [B, heads, seq_kv, head_dim]

    # Process in tiles along query dimension
    outputs = []
    for i in range(0, seq_q, tile_size):
        end_i = min(i + tile_size, seq_q)
        q_tile = query[:, :, i:end_i, :]  # [B, heads, tile, head_dim]

        # Handle attention mask tiling if present
        mask_tile = None
        if attn_mask is not None:
            # Mask shape could be [B, 1, seq_q, seq_kv] or [B, heads, seq_q, seq_kv]
            if attn_mask.dim() == 4:
                mask_tile = attn_mask[:, :, i:end_i, :]
            elif attn_mask.dim() == 3:
                mask_tile = attn_mask[:, i:end_i, :]
            elif attn_mask.dim() == 2:
                mask_tile = attn_mask[i:end_i, :]

        # Handle causal masking for tiles
        tile_is_causal = False
        if is_causal:
            # For causal attention, we need to apply causal mask manually for tiles
            # that don't start at position 0
            if i == 0:
                tile_is_causal = True
            else:
                # Create causal mask for this tile
                tile_len = end_i - i
                causal_mask = torch.ones(tile_len, seq_kv, dtype=torch.bool, device=query.device)
                # Each query at position j can attend to positions 0..i+j
                for j in range(tile_len):
                    causal_mask[j, i + j + 1 :] = False
                causal_mask = causal_mask.unsqueeze(0).unsqueeze(0)  # [1, 1, tile, seq_kv]
                if mask_tile is not None:
                    mask_tile = mask_tile & causal_mask
                else:
                    # Convert bool mask to float mask for SDPA
                    mask_tile = torch.zeros_like(causal_mask, dtype=query.dtype)
                    mask_tile.masked_fill_(~causal_mask, float("-inf"))

        # Compute attention for this tile
        out_tile = F.scaled_dot_product_attention(
            q_tile,
            key,
            value,
            attn_mask=mask_tile,
            dropout_p=dropout_p if query.requires_grad else 0.0,
            is_causal=tile_is_causal,
        )
        outputs.append(out_tile)

    # Concatenate tiles
    output = torch.cat(outputs, dim=2)  # [B, heads, seq_q, head_dim]

    # Transpose back to [B, seq_q, heads, head_dim]
    output = output.transpose(1, 2)

    return output


def attention_with_oom_fallback(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    attn_mask: Optional[torch.Tensor] = None,
    dropout_p: float = 0.0,
    is_causal: bool = False,
    backend: Optional[str] = None,
    tile_size: int = 1024,
) -> torch.Tensor:
    """
    Attention with automatic OOM fallback to tiled computation.

    First tries dispatch_attention_fn, and on OOM falls back to tiled attention
    which processes queries in chunks to reduce peak memory.

    The tiled version is mathematically equivalent because each query's attention
    is independent (softmax is computed per query position).

    WARNING: The OOM fallback changes global state mid-forward, which breaks
    gradient checkpointing (recomputation takes a different path). If you use
    checkpointing and hit this fallback, training will fail. In that case,
    set _USE_TILED_ATTENTION = True before training starts.
    """
    global _USE_TILED_ATTENTION

    if _USE_TILED_ATTENTION:
        return _tiled_scaled_dot_product_attention(
            query,
            key,
            value,
            attn_mask=attn_mask,
            dropout_p=dropout_p,
            is_causal=is_causal,
            tile_size=tile_size,
        )

    try:
        return dispatch_attention_fn(
            query,
            key,
            value,
            attn_mask=attn_mask,
            dropout_p=dropout_p,
            is_causal=is_causal,
            backend=backend,
        )
    except torch.cuda.OutOfMemoryError:
        seq_len = query.shape[1]
        logger.warning(
            "OOM during attention (seq_len=%d), falling back to tiled attention (tile_size=%d). "
            "This will be slower but use less memory. "
            "NOTE: If using gradient checkpointing, this may cause errors. "
            "Consider enabling tiled attention explicitly before training.",
            seq_len,
            tile_size,
        )
        _USE_TILED_ATTENTION = True
        torch.cuda.empty_cache()

        return _tiled_scaled_dot_product_attention(
            query,
            key,
            value,
            attn_mask=attn_mask,
            dropout_p=dropout_p,
            is_causal=is_causal,
            tile_size=tile_size,
        )


def _store_hidden_state(buffer, key: str, hidden_states: torch.Tensor, image_tokens_start: int | None = None):
    if buffer is None:
        return
    if image_tokens_start is not None and hidden_states.dim() >= 3:
        buffer[key] = hidden_states[:, image_tokens_start:, ...]
    else:
        buffer[key] = hidden_states


def get_timestep_embedding(
    timesteps: torch.Tensor,
    embedding_dim: int,
    flip_sin_to_cos: bool = False,
    downscale_freq_shift: float = 1,
    scale: float = 1,
    max_period: int = 10000,
) -> torch.Tensor:
    """
    This matches the implementation in Denoising Diffusion Probabilistic Models: Create sinusoidal timestep embeddings.

    Args
        timesteps (torch.Tensor):
            a 1-D floating point Tensor of N indices, one per batch element. These may be fractional.
        embedding_dim (int):
            the dimension of the output.
        flip_sin_to_cos (bool):
            Whether the embedding order should be `cos, sin` (if True) or `sin, cos` (if False)
        downscale_freq_shift (float):
            Controls the delta between frequencies between dimensions
        scale (float):
            Scaling factor applied to the embeddings.
        max_period (int):
            Controls the maximum frequency of the embeddings
    Returns
        torch.Tensor: an [N x dim] Tensor of positional embeddings.
    """
    assert len(timesteps.shape) == 1, "Timesteps should be a 1d-array"
    if not timesteps.is_floating_point():
        raise TypeError("`get_timestep_embedding` expects floating-point `timesteps`. Call `.float()` on the input.")

    half_dim = embedding_dim // 2
    exponent = -math.log(max_period) * torch.arange(start=0, end=half_dim, dtype=torch.float32, device=timesteps.device)
    exponent = exponent / (half_dim - downscale_freq_shift)

    emb = torch.exp(exponent)
    timesteps = timesteps.float()
    emb = timesteps[:, None] * emb[None, :]

    # scale embeddings
    emb = scale * emb

    # concat sine and cosine embeddings
    emb = torch.cat([torch.sin(emb), torch.cos(emb)], dim=-1)

    # flip sine and cosine embeddings
    if flip_sin_to_cos:
        emb = torch.cat([emb[:, half_dim:], emb[:, :half_dim]], dim=-1)

    # zero pad
    if embedding_dim % 2 == 1:
        emb = torch.nn.functional.pad(emb, (0, 1, 0, 0))
    return emb


def apply_rotary_emb_qwen(
    x: torch.Tensor,
    freqs_cis: Union[torch.Tensor, Tuple[torch.Tensor]],
    use_real: bool = True,
    use_real_unbind_dim: int = -1,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Apply rotary embeddings to input tensors using the given frequency tensor. This function applies rotary embeddings
    to the given query or key 'x' tensors using the provided frequency tensor 'freqs_cis'. The input tensors are
    reshaped as complex numbers, and the frequency tensor is reshaped for broadcasting compatibility. The resulting
    tensors contain rotary embeddings and are returned as real tensors.

    Args:
        x (`torch.Tensor`):
            Query or key tensor to apply rotary embeddings. [B, S, H, D] xk (torch.Tensor): Key tensor to apply
        freqs_cis (`Tuple[torch.Tensor]`): Precomputed frequency tensor for complex exponentials. ([S, D], [S, D],)

    Returns:
        Tuple[torch.Tensor, torch.Tensor]: Tuple of modified query tensor and key tensor with rotary embeddings.
    """
    if use_real:
        cos, sin = freqs_cis  # [S, D]
        cos = cos[None, None]
        sin = sin[None, None]
        cos, sin = cos.to(x.device), sin.to(x.device)

        if use_real_unbind_dim == -1:
            # Used for flux, cogvideox, hunyuan-dit
            x_real, x_imag = x.reshape(*x.shape[:-1], -1, 2).unbind(-1)  # [B, S, H, D//2]
            x_rotated = torch.stack([-x_imag, x_real], dim=-1).flatten(3)
        elif use_real_unbind_dim == -2:
            # Used for Stable Audio, OmniGen, CogView4 and Cosmos
            x_real, x_imag = x.reshape(*x.shape[:-1], 2, -1).unbind(-2)  # [B, S, H, D//2]
            x_rotated = torch.cat([-x_imag, x_real], dim=-1)
        else:
            raise ValueError(f"`use_real_unbind_dim={use_real_unbind_dim}` but should be -1 or -2.")

        out = (x.float() * cos + x_rotated.float() * sin).to(x.dtype)

        return out
    else:
        x_rotated = torch.view_as_complex(x.float().reshape(*x.shape[:-1], -1, 2))
        freqs_cis = freqs_cis.unsqueeze(1)
        x_out = torch.view_as_real(x_rotated * freqs_cis).flatten(3)

        return x_out.type_as(x)


def compute_text_seq_len_from_mask(
    encoder_hidden_states: torch.Tensor, encoder_hidden_states_mask: Optional[torch.Tensor]
) -> Tuple[int, Optional[torch.Tensor], Optional[torch.Tensor]]:
    """
    Compute text sequence length without assuming contiguous masks. Returns length for RoPE and a normalized bool mask.
    """
    batch_size, text_seq_len = encoder_hidden_states.shape[:2]
    if encoder_hidden_states_mask is None:
        return text_seq_len, None, None

    if encoder_hidden_states_mask.shape[:2] != (batch_size, text_seq_len):
        raise ValueError(
            f"`encoder_hidden_states_mask` shape {encoder_hidden_states_mask.shape} must match "
            f"(batch_size, text_seq_len)=({batch_size}, {text_seq_len})."
        )

    if encoder_hidden_states_mask.dtype != torch.bool:
        encoder_hidden_states_mask = encoder_hidden_states_mask.to(torch.bool)

    position_ids = torch.arange(text_seq_len, device=encoder_hidden_states.device, dtype=torch.long)
    active_positions = torch.where(encoder_hidden_states_mask, position_ids, position_ids.new_zeros(()))
    has_active = encoder_hidden_states_mask.any(dim=1)
    per_sample_len = torch.where(has_active, active_positions.max(dim=1).values + 1, torch.as_tensor(text_seq_len))
    return text_seq_len, per_sample_len, encoder_hidden_states_mask


class QwenTimestepProjEmbeddings(nn.Module):
    def __init__(self, embedding_dim: int, enable_time_sign_embed: bool = False):
        super().__init__()

        self.time_proj = Timesteps(num_channels=256, flip_sin_to_cos=True, downscale_freq_shift=0, scale=1000)
        self.timestep_embedder = TimestepEmbedding(in_channels=256, time_embed_dim=embedding_dim)
        self.timestep_embedder.time_embed_dim = embedding_dim
        # Signed-time embedding for TwinFlow-style negative time handling.
        self.time_sign_embed: Optional[nn.Embedding] = None
        if enable_time_sign_embed:
            self.time_sign_embed = nn.Embedding(2, embedding_dim)
            nn.init.zeros_(self.time_sign_embed.weight)

    def _apply_timestep_sign(
        self,
        conditioning: torch.Tensor,
        timestep_sign: torch.Tensor,
        *,
        target_device: torch.device,
    ) -> torch.Tensor:
        if self.time_sign_embed is None:
            raise ValueError(
                "timestep_sign was provided but the model was loaded without `enable_time_sign_embed=True`. "
                "Enable TwinFlow (or load a TwinFlow-compatible checkpoint) to use signed-timestep conditioning."
            )

        sign_tensor = timestep_sign.to(device=target_device)
        if conditioning.ndim == 3:
            if sign_tensor.ndim == 0:
                sign_tensor = sign_tensor.expand(conditioning.shape[0], conditioning.shape[1])
            elif sign_tensor.ndim == 1:
                if sign_tensor.shape[0] == 1:
                    sign_tensor = sign_tensor.expand(conditioning.shape[0])
                elif sign_tensor.shape[0] != conditioning.shape[0]:
                    raise ValueError(
                        f"Qwen tokenwise timestep_sign expected 1 or {conditioning.shape[0]} batch values, got {sign_tensor.shape[0]}."
                    )
                sign_tensor = sign_tensor[:, None].expand(-1, conditioning.shape[1])
            elif sign_tensor.ndim == 2:
                if sign_tensor.shape != conditioning.shape[:2]:
                    raise ValueError(
                        f"Qwen tokenwise timestep_sign expected shape {tuple(conditioning.shape[:2])}, got {tuple(sign_tensor.shape)}."
                    )
            else:
                raise ValueError(
                    f"Qwen timestep_sign expected scalar, 1D batch tensor, or 2D tokenwise tensor, got shape {tuple(sign_tensor.shape)}."
                )
            sign_idx = (sign_tensor.reshape(-1) < 0).long()
            sign_emb = self.time_sign_embed(sign_idx).to(dtype=conditioning.dtype, device=target_device)
            return conditioning + sign_emb.view(conditioning.shape[0], conditioning.shape[1], -1)

        sign_idx = (sign_tensor.view(-1) < 0).long().to(device=target_device)
        return conditioning + self.time_sign_embed(sign_idx).to(dtype=conditioning.dtype, device=target_device)

    def forward(self, timestep, hidden_states, timestep_sign: Optional[torch.Tensor] = None):
        target_device = hidden_states.device
        target_dtype = hidden_states.dtype

        if hasattr(self.time_proj, "to"):
            self.time_proj = self.time_proj.to(device=target_device)

        embedder_params = list(self.timestep_embedder.parameters())
        if embedder_params:
            if embedder_params[0].device != target_device:
                self.timestep_embedder = self.timestep_embedder.to(device=target_device)
            if embedder_params[0].dtype != target_dtype:
                self.timestep_embedder = self.timestep_embedder.to(dtype=target_dtype)

        timestep = timestep.to(device=target_device)
        if timestep.ndim == 2:
            timesteps_proj = self.time_proj(timestep.reshape(-1))
            timesteps_proj = timesteps_proj.to(device=target_device, dtype=target_dtype)
            conditioning = self.timestep_embedder(timesteps_proj).view(timestep.shape[0], timestep.shape[1], -1)
        else:
            timesteps_proj = self.time_proj(timestep)
            timesteps_proj = timesteps_proj.to(device=target_device, dtype=target_dtype)
            conditioning = self.timestep_embedder(timesteps_proj)

        if conditioning.dtype != target_dtype:
            conditioning = conditioning.to(dtype=target_dtype)

        if timestep_sign is not None:
            conditioning = self._apply_timestep_sign(
                conditioning,
                timestep_sign,
                target_device=target_device,
            )

        return conditioning


class QwenEmbedRope(nn.Module):
    def __init__(self, theta: int, axes_dim: List[int], scale_rope=False):
        super().__init__()
        self.theta = theta
        self.axes_dim = axes_dim
        pos_index = torch.arange(8192)
        neg_index = torch.arange(8192).flip(0) * -1 - 1
        self.pos_freqs = torch.cat(
            [
                self.rope_params(pos_index, self.axes_dim[0], self.theta),
                self.rope_params(pos_index, self.axes_dim[1], self.theta),
                self.rope_params(pos_index, self.axes_dim[2], self.theta),
            ],
            dim=1,
        )
        self.neg_freqs = torch.cat(
            [
                self.rope_params(neg_index, self.axes_dim[0], self.theta),
                self.rope_params(neg_index, self.axes_dim[1], self.theta),
                self.rope_params(neg_index, self.axes_dim[2], self.theta),
            ],
            dim=1,
        )
        self.rope_cache = {}

        # DO NOT USING REGISTER BUFFER HERE, IT WILL CAUSE COMPLEX NUMBERS LOSE ITS IMAGINARY PART
        self.scale_rope = scale_rope

    def rope_params(self, index, dim, theta=10000):
        """
        Args:
            index: [0, 1, 2, 3] 1D Tensor representing the position index of the token
        """
        assert dim % 2 == 0
        freqs = torch.outer(index, 1.0 / torch.pow(theta, torch.arange(0, dim, 2).to(torch.float32).div(dim)))
        freqs = torch.polar(torch.ones_like(freqs), freqs)
        return freqs

    def forward(
        self,
        video_fhw: Union[Tuple[int, int, int], List[Tuple[int, int, int]]],
        txt_seq_lens: Union[int, torch.Tensor, List[int]],
        device: torch.device = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            video_fhw (`Tuple[int, int, int]` or `List[Tuple[int, int, int]]`):
                A list of 3 integers [frame, height, width] representing the shape of the video.
            txt_seq_lens (`int`, `torch.Tensor`, or `List[int]`):
                The text sequence length(s) for RoPE computation. If a list is provided, the maximum
                value is used. Can be an int, list of ints, or scalar tensor (for torch.compile).
            device: (`torch.device`, *optional*):
                The device on which to perform the RoPE computation.
        """
        # Move to device unconditionally to avoid graph breaks in torch.compile
        self.pos_freqs = self.pos_freqs.to(device)
        self.neg_freqs = self.neg_freqs.to(device)

        # Compute max text sequence length
        if isinstance(txt_seq_lens, list):
            max_txt_seq_len = max(txt_seq_lens)
        else:
            max_txt_seq_len = txt_seq_lens

        if isinstance(video_fhw, list):
            video_fhw = video_fhw[0]
        if not isinstance(video_fhw, list):
            video_fhw = [video_fhw]

        vid_freqs = []
        max_vid_index = 0
        for idx, fhw in enumerate(video_fhw):
            frame, height, width = fhw
            rope_key = f"{idx}_{height}_{width}"

            if not torch.compiler.is_compiling():
                if rope_key not in self.rope_cache:
                    self.rope_cache[rope_key] = self._compute_video_freqs(frame, height, width, idx)
                video_freq = self.rope_cache[rope_key]
            else:
                video_freq = self._compute_video_freqs(frame, height, width, idx)
            video_freq = video_freq.to(device)
            vid_freqs.append(video_freq)

            if self.scale_rope:
                max_vid_index = max(height // 2, width // 2, max_vid_index)
            else:
                max_vid_index = max(height, width, max_vid_index)

        max_txt_seq_len_int = int(max_txt_seq_len)
        # Create device-specific copy for text freqs without modifying self.pos_freqs
        txt_freqs = self.pos_freqs.to(device)[max_vid_index : max_vid_index + max_txt_seq_len_int, ...]
        vid_freqs = torch.cat(vid_freqs, dim=0)

        return vid_freqs, txt_freqs

    @functools.lru_cache(maxsize=None)
    def _compute_video_freqs(self, frame, height, width, idx=0):
        seq_lens = frame * height * width
        freqs_pos = self.pos_freqs.split([x // 2 for x in self.axes_dim], dim=1)
        freqs_neg = self.neg_freqs.split([x // 2 for x in self.axes_dim], dim=1)

        freqs_frame = freqs_pos[0][idx : idx + frame].view(frame, 1, 1, -1).expand(frame, height, width, -1)
        if self.scale_rope:
            freqs_height = torch.cat([freqs_neg[1][-(height - height // 2) :], freqs_pos[1][: height // 2]], dim=0)
            freqs_height = freqs_height.view(1, height, 1, -1).expand(frame, height, width, -1)
            freqs_width = torch.cat([freqs_neg[2][-(width - width // 2) :], freqs_pos[2][: width // 2]], dim=0)
            freqs_width = freqs_width.view(1, 1, width, -1).expand(frame, height, width, -1)
        else:
            freqs_height = freqs_pos[1][:height].view(1, height, 1, -1).expand(frame, height, width, -1)
            freqs_width = freqs_pos[2][:width].view(1, 1, width, -1).expand(frame, height, width, -1)

        freqs = torch.cat([freqs_frame, freqs_height, freqs_width], dim=-1).reshape(seq_lens, -1)
        return freqs.clone().contiguous()


class QwenDoubleStreamAttnProcessor2_0:
    """
    Attention processor for Qwen double-stream architecture, matching DoubleStreamLayerMegatron logic. This processor
    implements joint attention computation where text and image streams are processed together.
    """

    _attention_backend = None

    def __init__(self):
        sdpa = getattr(F, "scaled_dot_product_attention", None)
        if sdpa is None or not callable(sdpa):
            raise ImportError(
                "QwenDoubleStreamAttnProcessor2_0 requires PyTorch 2.0, to use it, please upgrade PyTorch to 2.0."
            )

    def __call__(
        self,
        attn: Attention,
        hidden_states: torch.FloatTensor,  # Image stream
        encoder_hidden_states: torch.FloatTensor = None,  # Text stream
        encoder_hidden_states_mask: torch.FloatTensor = None,
        attention_mask: Optional[torch.FloatTensor] = None,
        image_rotary_emb: Optional[torch.Tensor] = None,
    ) -> torch.FloatTensor:
        if encoder_hidden_states is None:
            raise ValueError("QwenDoubleStreamAttnProcessor2_0 requires encoder_hidden_states (text stream)")

        seq_txt = encoder_hidden_states.shape[1]

        # Compute QKV for image stream (sample projections)
        img_query = attn.to_q(hidden_states)
        img_key = attn.to_k(hidden_states)
        img_value = attn.to_v(hidden_states)

        # Compute QKV for text stream (context projections)
        txt_query = attn.add_q_proj(encoder_hidden_states)
        txt_key = attn.add_k_proj(encoder_hidden_states)
        txt_value = attn.add_v_proj(encoder_hidden_states)

        # Reshape for multi-head attention
        img_query = img_query.unflatten(-1, (attn.heads, -1))
        img_key = img_key.unflatten(-1, (attn.heads, -1))
        img_value = img_value.unflatten(-1, (attn.heads, -1))

        txt_query = txt_query.unflatten(-1, (attn.heads, -1))
        txt_key = txt_key.unflatten(-1, (attn.heads, -1))
        txt_value = txt_value.unflatten(-1, (attn.heads, -1))

        # Apply QK normalization
        if attn.norm_q is not None:
            img_query = attn.norm_q(img_query)
        if attn.norm_k is not None:
            img_key = attn.norm_k(img_key)
        if attn.norm_added_q is not None:
            txt_query = attn.norm_added_q(txt_query)
        if attn.norm_added_k is not None:
            txt_key = attn.norm_added_k(txt_key)

        # Apply RoPE
        if image_rotary_emb is not None:
            img_freqs, txt_freqs = image_rotary_emb
            img_query = apply_rotary_emb_qwen(img_query, img_freqs, use_real=False)
            img_key = apply_rotary_emb_qwen(img_key, img_freqs, use_real=False)
            txt_query = apply_rotary_emb_qwen(txt_query, txt_freqs, use_real=False)
            txt_key = apply_rotary_emb_qwen(txt_key, txt_freqs, use_real=False)

        # Route between per-sample split attention (B>1, variable text length)
        # and joint attention (B==1 or no mask).
        batch_size_attn = img_query.shape[0]
        per_sample_mask = attention_mask if attention_mask is None else None  # unused sentinel
        # Retrieve the raw encoder_hidden_states_mask forwarded via attention_mask kwarg
        # (when batch>1, forward() sets block_attention_kwargs["encoder_hidden_states_mask"])
        raw_enc_mask = encoder_hidden_states_mask  # may be None

        if raw_enc_mask is not None and batch_size_attn > 1:
            # Per-sample split attention: each sample uses its own true text length.
            # This prevents padding tokens from being attended to across the batch.
            img_attn_outputs = []
            txt_attn_outputs = []

            for s in range(batch_size_attn):
                # Determine true text length for this sample
                true_txt_len = int(raw_enc_mask[s].sum().item())
                true_txt_len = max(true_txt_len, 1)  # at least 1 to avoid empty attn

                # Slice text QKV to actual length (no padding tokens)
                s_txt_q = txt_query[s : s + 1, :true_txt_len, :]
                s_txt_k = txt_key[s : s + 1, :true_txt_len, :]
                s_txt_v = txt_value[s : s + 1, :true_txt_len, :]
                s_img_q = img_query[s : s + 1]
                s_img_k = img_key[s : s + 1]
                s_img_v = img_value[s : s + 1]

                # Joint concat for this sample only
                s_joint_q = torch.cat([s_txt_q, s_img_q], dim=1)
                s_joint_k = torch.cat([s_txt_k, s_img_k], dim=1)
                s_joint_v = torch.cat([s_txt_v, s_img_v], dim=1)

                # Run attention without mask (text is already sliced to true length)
                s_joint_out = attention_with_oom_fallback(
                    s_joint_q,
                    s_joint_k,
                    s_joint_v,
                    attn_mask=None,
                    dropout_p=0.0,
                    is_causal=False,
                    backend=self._attention_backend,
                )
                s_joint_out = s_joint_out.flatten(2, 3).to(s_joint_q.dtype)

                # Split back into text and image parts
                s_txt_out = s_joint_out[:, :true_txt_len, :]
                s_img_out = s_joint_out[:, true_txt_len:, :]

                # Zero-pad text output back to seq_txt (the padded batch width)
                if true_txt_len < seq_txt:
                    pad = torch.zeros(
                        1, seq_txt - true_txt_len, s_txt_out.shape[-1], dtype=s_txt_out.dtype, device=s_txt_out.device
                    )
                    s_txt_out = torch.cat([s_txt_out, pad], dim=1)

                img_attn_outputs.append(s_img_out)
                txt_attn_outputs.append(s_txt_out)

            joint_img = torch.cat(img_attn_outputs, dim=0)
            txt_attn_output = torch.cat(txt_attn_outputs, dim=0)
            txt_attn_output = attn.to_add_out(txt_attn_output)

            # Apply output projection to image part (linear then dropout)
            # IMPORTANT: project first, then dropout. Reversing this causes loss=70.
            img_attn_output = attn.to_out[0](joint_img)
            if len(attn.to_out) > 1:
                img_attn_output = attn.to_out[1](img_attn_output)  # dropout

            return img_attn_output, txt_attn_output

        else:
            # Single sample or no mask: use efficient joint attention path
            joint_query = torch.cat([txt_query, img_query], dim=1)
            joint_key = torch.cat([txt_key, img_key], dim=1)
            joint_value = torch.cat([txt_value, img_value], dim=1)

            publish_attention_max_logits(
                joint_query.transpose(1, 2),
                joint_key.transpose(1, 2),
                attention_mask,
                getattr(attn, "to_q", None) and attn.to_q.weight,
                getattr(attn, "to_k", None) and attn.to_k.weight,
            )
            joint_hidden_states = attention_with_oom_fallback(
                joint_query,
                joint_key,
                joint_value,
                attn_mask=attention_mask,
                dropout_p=0.0,
                is_causal=False,
                backend=self._attention_backend,
            )

            # Reshape back
            joint_hidden_states = joint_hidden_states.flatten(2, 3)
            joint_hidden_states = joint_hidden_states.to(joint_query.dtype)

            # Split attention outputs back
            txt_attn_output = joint_hidden_states[:, :seq_txt, :]  # Text part
            img_attn_output = joint_hidden_states[:, seq_txt:, :]  # Image part

            # Apply output projections
            img_attn_output = attn.to_out[0](img_attn_output)
            if len(attn.to_out) > 1:
                img_attn_output = attn.to_out[1](img_attn_output)  # dropout

            txt_attn_output = attn.to_add_out(txt_attn_output)

            return img_attn_output, txt_attn_output


@maybe_allow_in_graph
class QwenImageTransformerBlock(PatchableModule):
    def __init__(
        self, dim: int, num_attention_heads: int, attention_head_dim: int, qk_norm: str = "rms_norm", eps: float = 1e-6
    ):
        super().__init__()

        self.dim = dim
        self.num_attention_heads = num_attention_heads
        self.attention_head_dim = attention_head_dim

        # Image processing modules
        self.img_mod = nn.Sequential(
            nn.SiLU(),
            nn.Linear(dim, 6 * dim, bias=True),  # For scale, shift, gate for norm1 and norm2
        )
        self.img_norm1 = nn.LayerNorm(dim, elementwise_affine=False, eps=eps)
        self.attn = Attention(
            query_dim=dim,
            cross_attention_dim=None,  # Enable cross attention for joint computation
            added_kv_proj_dim=dim,  # Enable added KV projections for text stream
            dim_head=attention_head_dim,
            heads=num_attention_heads,
            out_dim=dim,
            context_pre_only=False,
            bias=True,
            processor=QwenDoubleStreamAttnProcessor2_0(),
            qk_norm=qk_norm,
            eps=eps,
        )
        self.img_norm2 = nn.LayerNorm(dim, elementwise_affine=False, eps=eps)
        self.img_mlp = FeedForward(dim=dim, dim_out=dim, activation_fn="gelu-approximate")

        # Text processing modules
        self.txt_mod = nn.Sequential(
            nn.SiLU(),
            nn.Linear(dim, 6 * dim, bias=True),  # For scale, shift, gate for norm1 and norm2
        )
        self.txt_norm1 = nn.LayerNorm(dim, elementwise_affine=False, eps=eps)
        # Text doesn't need separate attention - it's handled by img_attn joint computation
        self.txt_norm2 = nn.LayerNorm(dim, elementwise_affine=False, eps=eps)
        self.txt_mlp = FeedForward(dim=dim, dim_out=dim, activation_fn="gelu-approximate")

    def _modulate(self, x, mod_params, modulate_index: Optional[torch.Tensor] = None):
        """Apply modulation to input tensor.

        Args:
            x: Input tensor of shape [B, L, D]
            mod_params: Modulation parameters of shape [B, 3*D] or [2*B, 3*D] when using zero_cond_t
            modulate_index: Optional tensor of shape [B, L] with values 0 or 1 indicating
                which modulation set to use per token. When provided, mod_params is expected
                to have doubled batch size [2*B, 3*D] where first half is for actual timestep
                and second half is for t=0.
        """
        shift, scale, gate = mod_params.chunk(3, dim=-1)

        if mod_params.ndim == 3:
            return x * (1 + scale) + shift, gate

        if modulate_index is not None:
            # mod_params has shape [2*actual_batch, dim] - split into two sets
            actual_batch = shift.size(0) // 2
            shift_0, shift_1 = shift[:actual_batch], shift[actual_batch:]
            scale_0, scale_1 = scale[:actual_batch], scale[actual_batch:]
            gate_0, gate_1 = gate[:actual_batch], gate[actual_batch:]

            # modulate_index: [B, L] -> [B, L, 1] for broadcasting
            index_expanded = modulate_index.unsqueeze(-1)

            # Expand params to [B, 1, D] for broadcasting to [B, L, D]
            shift_0_exp = shift_0.unsqueeze(1)
            shift_1_exp = shift_1.unsqueeze(1)
            scale_0_exp = scale_0.unsqueeze(1)
            scale_1_exp = scale_1.unsqueeze(1)
            gate_0_exp = gate_0.unsqueeze(1)
            gate_1_exp = gate_1.unsqueeze(1)

            # Select based on index: 0 = actual timestep, 1 = zero timestep
            shift_result = torch.where(index_expanded == 0, shift_0_exp, shift_1_exp)
            scale_result = torch.where(index_expanded == 0, scale_0_exp, scale_1_exp)
            gate_result = torch.where(index_expanded == 0, gate_0_exp, gate_1_exp)
        else:
            shift_result = shift.unsqueeze(1)
            scale_result = scale.unsqueeze(1)
            gate_result = gate.unsqueeze(1)

        return x * (1 + scale_result) + shift_result, gate_result

    def forward(
        self,
        hidden_states: torch.Tensor,
        encoder_hidden_states: torch.Tensor,
        encoder_hidden_states_mask: torch.Tensor,
        temb: torch.Tensor,
        image_rotary_emb: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        joint_attention_kwargs: Optional[Dict[str, Any]] = None,
        modulate_index: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        # Get modulation parameters for image stream
        # When using zero_cond_t, temb has doubled batch size [2*B, D]
        img_mod_params = self.img_mod(temb)  # [B, 6*dim] or [2*B, 6*dim]

        # For text stream, use only the actual timestep embedding (first half when zero_cond_t).
        # Tokenwise image timesteps are pooled down for the text stream.
        if temb.ndim == 3:
            if modulate_index is not None:
                target_mask = (modulate_index == 0).to(dtype=temb.dtype).unsqueeze(-1)
                target_count = target_mask.sum(dim=1).clamp_min(1.0)
                txt_temb = (temb * target_mask).sum(dim=1) / target_count
            else:
                txt_temb = temb.mean(dim=1)
        elif modulate_index is not None:
            txt_temb = torch.chunk(temb, 2, dim=0)[0]
        else:
            txt_temb = temb
        txt_mod_params = self.txt_mod(txt_temb)  # [B, 6*dim]

        # Split modulation parameters for norm1 and norm2
        img_mod1, img_mod2 = img_mod_params.chunk(2, dim=-1)  # Each [B, 3*dim] or [2*B, 3*dim]
        txt_mod1, txt_mod2 = txt_mod_params.chunk(2, dim=-1)  # Each [B, 3*dim]

        # Process image stream - norm1 + modulation (with optional per-token index selection)
        img_normed = self.img_norm1(hidden_states)
        img_modulated, img_gate1 = self._modulate(img_normed, img_mod1, modulate_index)

        # Process text stream - norm1 + modulation (always uses actual timestep)
        txt_normed = self.txt_norm1(encoder_hidden_states)
        txt_modulated, txt_gate1 = self._modulate(txt_normed, txt_mod1)

        # Use QwenAttnProcessor2_0 for joint attention computation
        # This directly implements the DoubleStreamLayerMegatron logic:
        # 1. Computes QKV for both streams
        # 2. Applies QK normalization and RoPE
        # 3. Concatenates and runs joint attention
        # 4. Splits results back to separate streams
        joint_attention_kwargs = dict(joint_attention_kwargs or {})
        if encoder_hidden_states_mask is None:
            encoder_hidden_states_mask = joint_attention_kwargs.pop("encoder_hidden_states_mask", None)
        else:
            joint_attention_kwargs.pop("encoder_hidden_states_mask", None)
        attn_output = self.attn(
            hidden_states=img_modulated,  # Image stream (will be processed as "sample")
            encoder_hidden_states=txt_modulated,  # Text stream (will be processed as "context")
            encoder_hidden_states_mask=encoder_hidden_states_mask,
            image_rotary_emb=image_rotary_emb,
            **joint_attention_kwargs,
        )

        # QwenAttnProcessor2_0 returns (img_output, txt_output) when encoder_hidden_states is provided
        img_attn_output, txt_attn_output = attn_output

        # Apply attention gates and add residual (like in Megatron)
        hidden_states = hidden_states + img_gate1 * img_attn_output
        encoder_hidden_states = encoder_hidden_states + txt_gate1 * txt_attn_output

        # Process image stream - norm2 + MLP (with optional per-token index selection)
        img_normed2 = self.img_norm2(hidden_states)
        img_modulated2, img_gate2 = self._modulate(img_normed2, img_mod2, modulate_index)
        img_mlp_output = self.img_mlp(img_modulated2)
        hidden_states = hidden_states + img_gate2 * img_mlp_output

        # Process text stream - norm2 + MLP
        txt_normed2 = self.txt_norm2(encoder_hidden_states)
        txt_modulated2, txt_gate2 = self._modulate(txt_normed2, txt_mod2)
        txt_mlp_output = self.txt_mlp(txt_modulated2)
        encoder_hidden_states = encoder_hidden_states + txt_gate2 * txt_mlp_output

        # Clip to prevent overflow for fp16
        if encoder_hidden_states.dtype == torch.float16:
            encoder_hidden_states = encoder_hidden_states.clip(-65504, 65504)
        if hidden_states.dtype == torch.float16:
            hidden_states = hidden_states.clip(-65504, 65504)

        return encoder_hidden_states, hidden_states


class QwenImageTransformer2DModel(
    PatchableModule, ModelMixin, ConfigMixin, PeftAdapterMixin, FromOriginalModelMixin, CacheMixin, AttentionMixin
):
    """
    The Transformer model introduced in Qwen.

    Args:
        patch_size (`int`, defaults to `2`):
            Patch size to turn the input data into small patches.
        in_channels (`int`, defaults to `64`):
            The number of channels in the input.
        out_channels (`int`, *optional*, defaults to `None`):
            The number of channels in the output. If not specified, it defaults to `in_channels`.
        num_layers (`int`, defaults to `60`):
            The number of layers of dual stream DiT blocks to use.
        attention_head_dim (`int`, defaults to `128`):
            The number of dimensions to use for each attention head.
        num_attention_heads (`int`, defaults to `24`):
            The number of attention heads to use.
        joint_attention_dim (`int`, defaults to `3584`):
            The number of dimensions to use for the joint attention (embedding/channel dimension of
            `encoder_hidden_states`).
        guidance_embeds (`bool`, defaults to `False`):
            Whether to use guidance embeddings for guidance-distilled variant of the model.
        axes_dims_rope (`Tuple[int]`, defaults to `(16, 56, 56)`):
            The dimensions to use for the rotary positional embeddings.
    """

    _supports_gradient_checkpointing = True
    _no_split_modules = ["QwenImageTransformerBlock"]
    _skip_layerwise_casting_patterns = ["pos_embed", "norm"]
    _repeated_blocks = ["QwenImageTransformerBlock"]
    _cp_plan = {
        "": {
            "hidden_states": ContextParallelInput(split_dim=1, expected_dims=3, split_output=False),
            "encoder_hidden_states": ContextParallelInput(split_dim=1, expected_dims=3, split_output=False),
            "encoder_hidden_states_mask": ContextParallelInput(split_dim=1, expected_dims=2, split_output=False),
        },
        "pos_embed": {
            0: ContextParallelInput(split_dim=0, expected_dims=2, split_output=True),
            1: ContextParallelInput(split_dim=0, expected_dims=2, split_output=True),
        },
        "proj_out": ContextParallelOutput(gather_dim=1, expected_dims=3),
    }

    @register_to_config
    def __init__(
        self,
        patch_size: int = 2,
        in_channels: int = 64,
        out_channels: Optional[int] = 16,
        num_layers: int = 60,
        attention_head_dim: int = 128,
        num_attention_heads: int = 24,
        joint_attention_dim: int = 3584,
        guidance_embeds: bool = False,  # TODO: this should probably be removed
        axes_dims_rope: Tuple[int, int, int] = (16, 56, 56),
        musubi_blocks_to_swap: int = 0,
        musubi_block_swap_device: str = "cpu",
        enable_time_sign_embed: bool = False,
    ):
        super().__init__()
        self.out_channels = out_channels or in_channels
        self.inner_dim = num_attention_heads * attention_head_dim

        self.pos_embed = QwenEmbedRope(theta=10000, axes_dim=list(axes_dims_rope), scale_rope=True)

        self.time_text_embed = QwenTimestepProjEmbeddings(
            embedding_dim=self.inner_dim,
            enable_time_sign_embed=enable_time_sign_embed,
        )
        self.time_sign_embed = self.time_text_embed.time_sign_embed

        self.txt_norm = RMSNorm(joint_attention_dim, eps=1e-6)

        self._patch_area = patch_size * patch_size
        self._img_in_features = in_channels
        self.img_in = nn.Linear(self._img_in_features, self.inner_dim)
        self.txt_in = nn.Linear(joint_attention_dim, self.inner_dim)

        self.transformer_blocks = MutableModuleList(
            [
                QwenImageTransformerBlock(
                    dim=self.inner_dim,
                    num_attention_heads=num_attention_heads,
                    attention_head_dim=attention_head_dim,
                )
                for _ in range(num_layers)
            ]
        )

        self.norm_out = AdaLayerNormContinuous(self.inner_dim, self.inner_dim, elementwise_affine=False, eps=1e-6)
        self.proj_out = nn.Linear(self.inner_dim, patch_size * patch_size * self.out_channels, bias=True)

        self.gradient_checkpointing = False
        self._musubi_block_swap = MusubiBlockSwapManager.build(
            depth=num_layers,
            blocks_to_swap=musubi_blocks_to_swap,
            swap_device=musubi_block_swap_device,
            logger=logger,
        )

        # TREAD support
        self._tread_router = None
        self._tread_routes = None

    def set_router(self, router: TREADRouter, routes: Optional[List[Dict]] = None):
        """Set TREAD router and routes for token reduction during training."""
        self._tread_router = router
        self._tread_routes = routes

    def _tokenize_hidden_states(self, hidden_states: torch.Tensor) -> Tuple[torch.Tensor, Optional[int], Optional[int]]:
        """
        Ensure hidden states are flattened into patch tokens.

        Returns the tokenized hidden states along with optional patch grid sizes.
        """
        if hidden_states.ndim == 3:
            # Already tokenized: (batch, tokens, features)
            return hidden_states, None, None

        if hidden_states.ndim != 4:
            raise ValueError(f"Expected hidden_states to be 3D tokens or 4D latent map, got shape {hidden_states.shape}.")

        batch_size, channels, height, width = hidden_states.shape
        patch_size = self.config.patch_size
        if height % patch_size != 0 or width % patch_size != 0:
            raise ValueError(f"Height ({height}) and width ({width}) must be divisible by patch_size ({patch_size}).")

        grid_h = height // patch_size
        grid_w = width // patch_size
        token_dim = channels * patch_size * patch_size
        if token_dim != self._img_in_features:
            raise ValueError(
                f"Token dimension mismatch: expected {self._img_in_features}, "
                f"but got {token_dim} from latents (channels={channels}, patch_size={patch_size})."
            )

        hidden_states = hidden_states.view(
            batch_size,
            channels,
            grid_h,
            patch_size,
            grid_w,
            patch_size,
        )
        hidden_states = hidden_states.permute(0, 2, 4, 1, 3, 5).reshape(
            batch_size,
            grid_h * grid_w,
            token_dim,
        )
        return hidden_states, grid_h, grid_w

    def _untokenize_hidden_states(
        self, hidden_states: torch.Tensor, grid_h: Optional[int], grid_w: Optional[int]
    ) -> torch.Tensor:
        if grid_h is None or grid_w is None:
            return hidden_states

        batch_size, num_tokens, channels = hidden_states.shape
        patch_size = self.config.patch_size
        expected_tokens = grid_h * grid_w
        if num_tokens != expected_tokens:
            raise ValueError(f"Unexpected token count during untokenize: got {num_tokens}, expected {expected_tokens}")

        expected_channels = patch_size * patch_size * self.out_channels
        if channels != expected_channels:
            raise ValueError(f"Unexpected channel count during untokenize: got {channels}, expected {expected_channels}")

        hidden_states = hidden_states.view(
            batch_size,
            grid_h,
            grid_w,
            patch_size,
            patch_size,
            self.out_channels,
        )
        hidden_states = hidden_states.permute(0, 5, 1, 3, 2, 4).reshape(
            batch_size,
            self.out_channels,
            grid_h * patch_size,
            grid_w * patch_size,
        )
        return hidden_states

    def forward(
        self,
        hidden_states: torch.Tensor,
        encoder_hidden_states: torch.Tensor = None,
        encoder_hidden_states_mask: torch.Tensor = None,
        timestep: torch.LongTensor = None,
        timestep_sign: Optional[torch.Tensor] = None,
        img_shapes: Optional[List[Tuple[int, int, int]]] = None,
        txt_seq_lens: Optional[List[int]] = None,
        guidance: torch.Tensor = None,  # TODO: this should probably be removed
        attention_kwargs: Optional[Dict[str, Any]] = None,
        controlnet_block_samples=None,
        force_keep_mask: Optional[torch.Tensor] = None,
        return_dict: bool = True,
        hidden_states_buffer: Optional[dict] = None,
        modulate_index: Optional[torch.Tensor] = None,
    ) -> Union[torch.Tensor, Transformer2DModelOutput]:
        """
        The [`QwenTransformer2DModel`] forward method.

        Args:
            hidden_states (`torch.Tensor` of shape `(batch_size, image_sequence_length, in_channels)`):
                Input `hidden_states`.
            encoder_hidden_states (`torch.Tensor` of shape `(batch_size, text_sequence_length, joint_attention_dim)`):
                Conditional embeddings (embeddings computed from the input conditions such as prompts) to use.
            encoder_hidden_states_mask (`torch.Tensor` of shape `(batch_size, text_sequence_length)`):
                Mask of the input conditions.
            timestep ( `torch.LongTensor`):
                Used to indicate denoising step.
            img_shapes (`List[Tuple[int, int, int]]`, *optional*):
                Image shapes for RoPE computation.
            txt_seq_lens (`List[int]`, *optional*, **Deprecated**):
                Deprecated parameter. Use `encoder_hidden_states_mask` instead. If provided, the maximum value will be
                used to compute RoPE sequence length.
            attention_kwargs (`dict`, *optional*):
                A kwargs dictionary that if specified is passed along to the `AttentionProcessor` as defined under
                `self.processor` in
                [diffusers.models.attention_processor](https://github.com/huggingface/diffusers/blob/main/src/diffusers/models/attention_processor.py).
            return_dict (`bool`, *optional*, defaults to `True`):
                Whether or not to return a [`~models.transformer_2d.Transformer2DModelOutput`] instead of a plain
                tuple.

        Returns:
            If `return_dict` is True, an [`~models.transformer_2d.Transformer2DModelOutput`] is returned, otherwise a
            `tuple` where the first element is the sample tensor.
        """
        if txt_seq_lens is not None:
            deprecate(
                "txt_seq_lens",
                "0.39.0",
                "Passing `txt_seq_lens` is deprecated and will be removed in version 0.39.0. "
                "Please use `txt_seq_len` instead (singular, not plural). "
                "The new parameter accepts a single int or tensor value instead of a list.",
                standard_warn=False,
            )

        if attention_kwargs is not None:
            attention_kwargs = attention_kwargs.copy()
            lora_scale = attention_kwargs.pop("scale", 1.0)
        else:
            lora_scale = 1.0

        if USE_PEFT_BACKEND:
            # weight the lora layers by setting `lora_scale` for each PEFT layer
            scale_lora_layers(self, lora_scale)
        else:
            if attention_kwargs is not None and attention_kwargs.get("scale", None) is not None:
                logger.warning(
                    "Passing `scale` via `joint_attention_kwargs` when not using the PEFT backend is ineffective."
                )

        inputs_are_tokens = hidden_states.ndim == 3
        hidden_states, patch_h, patch_w = self._tokenize_hidden_states(hidden_states)

        if (patch_h is None or patch_w is None) and img_shapes:
            # img_shapes entries have the form (frame, height, width) and may be wrapped per-sample.
            primary_shape = img_shapes[0]
            if isinstance(primary_shape, list):
                primary_shape = primary_shape[0] if primary_shape else None
            if primary_shape is not None:
                _, grid_h, grid_w = primary_shape
                patch_h = patch_h or grid_h
                patch_w = patch_w or grid_w

        if img_shapes is None:
            if patch_h is None or patch_w is None:
                raise ValueError("img_shapes must be provided when hidden_states are already tokenized.")
            img_shapes = [(1, patch_h, patch_w)] * hidden_states.shape[0]

        if timestep.ndim == 2 and timestep.shape != hidden_states.shape[:2]:
            raise ValueError(
                f"Qwen tokenwise timesteps expected shape {tuple(hidden_states.shape[:2])}, got {tuple(timestep.shape)}."
            )

        hidden_states = self.img_in(hidden_states)

        timestep = timestep.to(hidden_states.dtype)
        encoder_hidden_states = self.txt_norm(encoder_hidden_states)
        encoder_hidden_states = self.txt_in(encoder_hidden_states)

        # Use the encoder_hidden_states sequence length for RoPE computation and normalize mask
        text_seq_len, _, encoder_hidden_states_mask = compute_text_seq_len_from_mask(
            encoder_hidden_states, encoder_hidden_states_mask
        )

        if guidance is not None:
            guidance = guidance.to(hidden_states.dtype) * 1000

        temb = (
            self.time_text_embed(timestep, hidden_states, timestep_sign=timestep_sign)
            if guidance is None
            else self.time_text_embed(timestep, guidance, hidden_states, timestep_sign=timestep_sign)
        )

        image_rotary_emb = self.pos_embed(img_shapes, txt_seq_lens=text_seq_len, device=hidden_states.device)

        # TREAD initialization
        routes = self._tread_routes or []
        router = self._tread_router
        use_routing = self.training and len(routes) > 0 and torch.is_grad_enabled()

        # Pre-normalize route indices to handle negative values
        if use_routing:
            num_blocks = len(self.transformer_blocks)

            def _to_pos(idx: int) -> int:
                return idx if idx >= 0 else num_blocks + idx

            routes = [
                {
                    **r,
                    "start_layer_idx": _to_pos(r["start_layer_idx"]),
                    "end_layer_idx": _to_pos(r["end_layer_idx"]),
                }
                for r in routes
            ]

        # TREAD state tracking
        route_ptr = 0
        routing_now = False
        tread_mask_info = None
        saved_tokens = None

        grad_enabled = torch.is_grad_enabled()
        musubi_manager = self._musubi_block_swap
        musubi_offload_active = False
        if musubi_manager is not None:
            musubi_offload_active = musubi_manager.activate(self.transformer_blocks, hidden_states.device, grad_enabled)

        # Construct attention mask for blocks.
        # For batch_size==1: build a joint bool mask [text_mask, all_ones_for_image] once
        # to avoid reconstructing per-block (eliminates 60 GPU syncs, torch.compile safe).
        # For batch_size>1 with variable text lengths: the block forwards
        # encoder_hidden_states_mask explicitly to Attention.forward, so only
        # the single-sample joint attention_mask belongs in joint_attention_kwargs.
        block_attention_kwargs = attention_kwargs.copy() if attention_kwargs is not None else {}
        if encoder_hidden_states_mask is not None:
            batch_size, image_seq_len = hidden_states.shape[:2]
            if batch_size == 1:
                # Single sample: joint mask is safe and efficient
                image_mask = torch.ones((batch_size, image_seq_len), dtype=torch.bool, device=hidden_states.device)
                joint_attention_mask = torch.cat([encoder_hidden_states_mask, image_mask], dim=1)
                block_attention_kwargs["attention_mask"] = joint_attention_mask

        capture_idx = 0
        for index_block, block in enumerate(self.transformer_blocks):
            if musubi_offload_active and musubi_manager.is_managed_block(index_block):
                musubi_manager.stream_in(block, hidden_states.device)

            # TREAD: START a route?
            if use_routing and route_ptr < len(routes) and index_block == routes[route_ptr]["start_layer_idx"]:
                mask_ratio = routes[route_ptr]["selection_ratio"]
                tread_mask_info = router.get_mask(
                    hidden_states,
                    mask_ratio=mask_ratio,
                    force_keep=force_keep_mask,
                )
                saved_tokens = hidden_states.clone()
                hidden_states = router.start_route(hidden_states, tread_mask_info)
                routing_now = True

            if torch.is_grad_enabled() and self.gradient_checkpointing:

                def create_custom_forward(module, mod_idx):
                    def custom_forward(
                        *inputs,
                        hidden_states=None,
                        encoder_hidden_states=None,
                        encoder_hidden_states_mask=None,
                        temb=None,
                        image_rotary_emb=None,
                        **kwargs,
                    ):
                        # Handle both positional args (real checkpoint) and keyword args (test mock)
                        if inputs:
                            hs, ehs, ehsm, t, ire = inputs[:5]
                        else:
                            hs = hidden_states
                            ehs = encoder_hidden_states
                            ehsm = encoder_hidden_states_mask
                            t = temb
                            ire = image_rotary_emb

                        return module(
                            hidden_states=hs,
                            encoder_hidden_states=ehs,
                            encoder_hidden_states_mask=ehsm,
                            temb=t,
                            image_rotary_emb=ire,
                            joint_attention_kwargs=block_attention_kwargs,
                            modulate_index=mod_idx,
                        )

                    return custom_forward

                encoder_hidden_states, hidden_states = self._gradient_checkpointing_func(
                    create_custom_forward(block, modulate_index),
                    hidden_states,
                    encoder_hidden_states,
                    encoder_hidden_states_mask,  # Pass mask; processor routes joint vs split
                    temb,
                    image_rotary_emb,
                )

            else:
                encoder_hidden_states, hidden_states = block(
                    hidden_states=hidden_states,
                    encoder_hidden_states=encoder_hidden_states,
                    encoder_hidden_states_mask=encoder_hidden_states_mask,  # Pass mask; processor routes
                    temb=temb,
                    image_rotary_emb=image_rotary_emb,
                    joint_attention_kwargs=block_attention_kwargs,
                    modulate_index=modulate_index,
                )

            _store_hidden_state(hidden_states_buffer, f"layer_{capture_idx}", hidden_states)
            capture_idx += 1

            # TREAD: END the current route?
            if routing_now and index_block == routes[route_ptr]["end_layer_idx"]:
                hidden_states = router.end_route(
                    hidden_states,
                    tread_mask_info,
                    original_x=saved_tokens,
                )
                routing_now = False
                route_ptr += 1

            # controlnet residual
            if controlnet_block_samples is not None:
                interval_control = len(self.transformer_blocks) / len(controlnet_block_samples)
                interval_control = int(np.ceil(interval_control))
                hidden_states = hidden_states + controlnet_block_samples[index_block // interval_control]

            if musubi_offload_active and musubi_manager.is_managed_block(index_block):
                musubi_manager.stream_out(block)

        # Use only the image part (hidden_states) from the dual-stream blocks
        # When using zero_cond_t, use only the actual timestep embedding for final norm
        if modulate_index is not None and temb.ndim != 3:
            norm_temb = torch.chunk(temb, 2, dim=0)[0]
        else:
            norm_temb = temb
        if norm_temb.ndim == 3:
            emb = self.norm_out.linear(self.norm_out.silu(norm_temb).to(hidden_states.dtype))
            scale, shift = torch.chunk(emb, 2, dim=-1)
            hidden_states = self.norm_out.norm(hidden_states) * (1 + scale) + shift
        else:
            hidden_states = self.norm_out(hidden_states, norm_temb)
        output = self.proj_out(hidden_states)

        if USE_PEFT_BACKEND:
            # remove `lora_scale` from each PEFT layer
            unscale_lora_layers(self, lora_scale)

        # Check if output token count matches expected dimensions for untokenization
        # For edit models with concatenated inputs, the output will have more tokens than expected
        # In that case, return packed tokens and let the pipeline handle slicing and untokenization
        expected_tokens = patch_h * patch_w if (patch_h is not None and patch_w is not None) else None
        actual_tokens = output.shape[1]

        if inputs_are_tokens:
            # Keep packed token layout when caller supplies tokenized latents (scheduler expects packed tensors).
            output_image = output
        elif expected_tokens is not None and actual_tokens != expected_tokens:
            # Token count mismatch - likely concatenated inputs for edit model
            # Return packed tokens without untokenization
            output_image = output
        else:
            # Normal case - untokenize to image format
            output_image = self._untokenize_hidden_states(output, patch_h, patch_w)

        if not return_dict:
            return (output_image,)

        return Transformer2DModelOutput(sample=output_image)
