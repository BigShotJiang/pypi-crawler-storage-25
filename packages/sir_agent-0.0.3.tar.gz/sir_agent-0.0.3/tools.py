"""Example tools for testing the SIR UI."""

from sir import tool


@tool
def search_web(query: str) -> str:
    """Search the web for a query and return results."""
    return f"[Results for '{query}']: AI breakthroughs in 2025 include new reasoning models and open-source LLMs."


@tool
def summarize(text: str) -> str:
    """Summarize a long text into key points."""
    return f"Summary: {text[:100]}..."


@tool
def translate(text: str, lang: str) -> str:
    """Translate text to the target language."""
    return f"[{lang}] Traduzione: {text[:80]}..."
