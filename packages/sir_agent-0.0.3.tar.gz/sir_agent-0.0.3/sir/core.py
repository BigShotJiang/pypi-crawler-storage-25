"""SIR core engine — single-input-reasoning orchestrator."""

from __future__ import annotations

import asyncio
import logging
import time
from pathlib import Path
from typing import Any, AsyncIterator

from sir.compiler import CompiledDAG, compile_graph
from sir.executor import execute_graph, execute_graph_stream
from sir.graph import GraphValidationError, parse_graph, validate_graph
from sir.healing import compile_heal_prompt, merge_healed_results
from sir.memory.store import Memory
from sir.models import ActionGraph, GraphResult, StepResult, StepStatus
from sir.optimizer import optimize_graph
from sir.prompt import compile_prompt
from sir.providers.llm import LLMProvider, OllamaProvider
from sir.tool import ToolSpec

logger = logging.getLogger("sir")

DEFAULT_MAX_TOKENS = 4096
LLM_RETRIES = 2


class SIR:
    """Single-Input-Reasoning engine."""

    def __init__(
        self,
        provider: LLMProvider | None = None,
        *,
        model: str = "",
        embed_provider: LLMProvider | None = None,
        memory_path: str | Path | None = "dags.bin",
        enable_memory: bool = True,
        enable_optimizer: bool = True,
        enable_speculation: bool = True,
        enable_reasoning: bool = True,
        enable_healing: bool = True,
        tool_mode: str = "adaptive",
        deprecation_threshold: float = 3.0,
        similarity_threshold: float = 0.78,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        llm_retries: int = LLM_RETRIES,
    ):
        self.provider = provider or OllamaProvider(model=model or "qwen2.5:14b")
        if not isinstance(self.provider, LLMProvider):
            raise TypeError("provider must be an instance of LLMProvider")
        self.embed_provider = embed_provider
        self.enable_memory = enable_memory
        self.enable_optimizer = enable_optimizer
        self.enable_speculation = enable_speculation
        self.enable_reasoning = enable_reasoning
        self.enable_healing = enable_healing
        self.tool_mode = tool_mode
        self.max_tokens = max_tokens
        self.llm_retries = llm_retries
        self._last_graph: ActionGraph | None = None
        self._last_raw_output: str | None = None
        self._last_reasoning: str | None = None
        self._planning_messages: list[dict[str, str]] = []
        self.memory: Memory | None = None
        if enable_memory and memory_path:
            self.memory = Memory(
                path=memory_path,
                threshold=deprecation_threshold,
                similarity_threshold=similarity_threshold,
            )
            self.memory.set_embedder(embed_provider or self.provider)

    # ── Public API ──────────────────────────────────────────────────

    def run(self, prompt: str, tools: list[ToolSpec], **kwargs: Any) -> GraphResult:
        return asyncio.run(self.arun(prompt, tools, **kwargs))

    async def arun(self, prompt: str, tools: list[ToolSpec], **kwargs: Any) -> GraphResult:
        tool_map = {t.name: t for t in tools}
        tool_names = set(tool_map.keys())

        # 1. Memory lookup
        prior = await self.memory.find(prompt) if self.memory else None
        if prior:
            logger.info("Memory hit: %s (used %dx, avg=%.1f)",
                        prior.logic_id, prior.times_used, prior.avg_score)

        # 2. Compile prompt
        messages = compile_prompt(tools, prompt, prior_logic=prior, tool_mode=self.tool_mode)

        # 3. LLM call → parse → validate
        kwargs.setdefault("max_tokens", self.max_tokens)
        graph = await self._generate_graph(messages, tool_names, **kwargs)

        # 4. Optimize graph (post-LLM compiler passes)
        optimizations = []
        if self.enable_optimizer:
            graph, optimizations = optimize_graph(graph, tool_names)
            if optimizations:
                logger.info("Optimizations: %s", "; ".join(optimizations))

        logger.info("Graph: %d steps, final=%s", len(graph.steps), graph.final_step)

        self._last_graph = graph

        # 5. Execute with speculative execution
        result = await execute_graph(
            graph, tool_map, prompt,
            enable_speculation=self.enable_speculation,
        )
        result.from_memory = prior is not None
        result.optimizations_applied = optimizations

        # 6. Self-healing — repair failed branches
        if self.enable_healing:
            result = await self._heal(result, graph, tools, **kwargs)

        # 7. Reasoning pass — LLM decides via nr, with heuristic fallback
        should_reason = graph.needs_reasoning
        if not should_reason and self.enable_reasoning and result.steps:
            should_reason = self._heuristic_needs_reasoning(prompt)
        if should_reason and result.steps:
            reasoning = await self._reasoning_pass(messages, result)
            if reasoning:
                self._last_reasoning = reasoning
                result.reasoning = reasoning
                result.final_result = reasoning

        # 8. Memory
        if self.memory:
            if prior and graph.prior_scores:
                self.memory.update_scores(prior.logic_id, graph.prior_scores, result)
            elif prior:
                # Auto-score from execution results even without LLM scores
                self.memory.auto_score(prior.logic_id, result)
            if not prior:
                record = await self.memory.store(prompt, graph)
                # Auto-score the first run too
                self.memory.auto_score(record.logic_id, result)

        return result

    async def arun_stream(
        self, prompt: str, tools: list[ToolSpec], **kwargs: Any
    ) -> AsyncIterator[StepResult | GraphResult]:
        tool_map = {t.name: t for t in tools}
        tool_names = set(tool_map.keys())

        prior = await self.memory.find(prompt) if self.memory else None
        messages = compile_prompt(tools, prompt, prior_logic=prior, tool_mode=self.tool_mode)
        kwargs.setdefault("max_tokens", self.max_tokens)
        graph = await self._generate_graph(messages, tool_names, **kwargs)

        optimizations = []
        if self.enable_optimizer:
            graph, optimizations = optimize_graph(graph, tool_names)

        self._last_graph = graph
        all_steps: list[StepResult] = []
        t0 = time.perf_counter()

        async for step_result in execute_graph_stream(graph, tool_map, prompt):
            all_steps.append(step_result)
            yield step_result

        final = None
        if graph.final_step:
            for sr in all_steps:
                if sr.step_id == graph.final_step and sr.status == StepStatus.SUCCESS:
                    final = sr.result
                    break
        if final is None:
            for sr in reversed(all_steps):
                if sr.status == StepStatus.SUCCESS and sr.result is not None:
                    final = sr.result
                    break

        # Reasoning pass
        reasoning = None
        temp_result = GraphResult(
            prompt=prompt, steps=all_steps, final_result=final,
            total_duration_ms=(time.perf_counter() - t0) * 1000,
        )
        if self.enable_reasoning and all_steps and (graph.needs_reasoning or self._heuristic_needs_reasoning(prompt)):
            reasoning = await self._reasoning_pass(messages, temp_result)
            if reasoning:
                self._last_reasoning = reasoning
                final = reasoning

        result = GraphResult(
            prompt=prompt,
            steps=all_steps,
            final_result=final,
            reasoning=reasoning,
            total_duration_ms=(time.perf_counter() - t0) * 1000,
            from_memory=prior is not None,
            optimizations_applied=optimizations,
        )

        if self.memory:
            if prior and graph.prior_scores:
                self.memory.update_scores(prior.logic_id, graph.prior_scores, result)
            elif prior:
                self.memory.auto_score(prior.logic_id, result)
            if not prior:
                record = await self.memory.store(prompt, graph)
                self.memory.auto_score(record.logic_id, result)

        yield result

    # ── Reasoning pass ──────────────────────────────────────────

    @staticmethod
    def _heuristic_needs_reasoning(prompt: str) -> bool:
        """Lightweight fallback when the LLM doesn't set nr=true."""
        p = prompt.lower()
        signals = [
            "explain", "analyze", "analyse", "summarize", "summarise",
            "describe", "compare", "evaluate", "interpret", "conclude",
            "what do you think", "what does", "what is the", "why ",
            "in your own words", "your opinion", "insight", "recommend",
            "main idea", "core idea", "key takeaway", "overview",
            "sentiment", "implication", "significance", "meaning",
            "pros and cons", "relationship between", "difference between",
        ]
        return any(s in p for s in signals)

    async def _reasoning_pass(
        self,
        planning_messages: list[dict[str, str]],
        result: GraphResult,
    ) -> str | None:
        """Inject tool results into the conversation and ask the LLM to reason.

        This is the second (and final) LLM call in the SIR pipeline.
        It reuses the planning conversation context, appends compressed
        tool results, and asks the LLM to produce a final answer.

        Returns None if all steps failed or reasoning is unnecessary.
        """
        successful = [
            sr for sr in result.steps
            if sr.status == StepStatus.SUCCESS and sr.result is not None
        ]
        if not successful:
            return None

        # Compress results: step_id -> truncated result
        results_compact = {}
        for sr in successful:
            val = str(sr.result)
            # Truncate large results to save tokens
            if len(val) > 2000:
                val = val[:1800] + "\n...[truncated]"
            results_compact[sr.step_id] = val

        # Build the injection message
        results_text = "\n".join(
            f"[{sid}] {val}" for sid, val in results_compact.items()
        )

        # Continue the same conversation
        reasoning_messages = list(planning_messages)
        reasoning_messages.append({
            "role": "assistant",
            "content": self._last_raw_output or "",
        })
        reasoning_messages.append({
            "role": "user",
            "content": (
                f"Tool execution complete. Results:\n{results_text}\n\n"
                "Based on these results, provide the final answer to the original request. "
                "Be concise and direct. Output ONLY the answer, no JSON, no metadata."
            ),
        })

        try:
            logger.info("Reasoning pass: sending %d chars of tool results", len(results_text))
            reasoning = await self.provider.generate(
                reasoning_messages, max_tokens=self.max_tokens
            )
            logger.info("Reasoning pass result: %s", reasoning[:200] if reasoning else "None")
            return reasoning.strip() if reasoning and reasoning.strip() else None
        except Exception as exc:
            logger.warning("Reasoning pass failed: %s", exc)
            return None

    # ── Self-healing ────────────────────────────────────────────────

    async def _heal(
        self,
        result: GraphResult,
        graph: ActionGraph,
        tools: list[ToolSpec],
        **kwargs: Any,
    ) -> GraphResult:
        """Attempt to repair failed branches with a single targeted LLM call."""
        failed = [sr for sr in result.steps if sr.status == StepStatus.FAILED]
        if not failed:
            return result

        heal_messages = compile_heal_prompt(tools, result, graph)
        if not heal_messages:
            return result

        tool_map = {t.name: t for t in tools}
        tool_names = set(tool_map.keys())

        try:
            logger.info("Self-healing: repairing %d failed step(s)", len(failed))
            raw = await self.provider.generate(heal_messages, max_tokens=self.max_tokens)
            heal_graph = parse_graph(raw)
            validate_graph(heal_graph, tool_names)

            # Inject already-succeeded results so the micro-DAG can reference them
            heal_result = await execute_graph(
                heal_graph, tool_map, result.prompt,
                enable_speculation=False,
            )

            healed_ok = [sr for sr in heal_result.steps if sr.status == StepStatus.SUCCESS]
            if healed_ok:
                result.steps = merge_healed_results(result.steps, heal_result.steps)
                result.healed = True
                # Re-execute skipped downstream steps that now have their deps healed
                result = await self._replay_skipped(result, graph, tool_map)
                # Update final_result
                succeeded = {sr.step_id: sr.result for sr in result.steps if sr.status == StepStatus.SUCCESS}
                if graph.final_step and graph.final_step in succeeded:
                    result.final_result = succeeded[graph.final_step]
                logger.info("Self-healing: repaired %d step(s)", len(healed_ok))
        except Exception as exc:
            logger.warning("Self-healing failed: %s", exc)

        return result

    async def _replay_skipped(
        self,
        result: GraphResult,
        graph: ActionGraph,
        tool_map: dict[str, ToolSpec],
    ) -> GraphResult:
        """Re-execute steps that were skipped due to failed deps, now that deps are healed."""
        from sir.graph import resolve_refs

        succeeded = {sr.step_id: sr.result for sr in result.steps if sr.status == StepStatus.SUCCESS}
        skipped_ids = {sr.step_id for sr in result.steps if sr.status == StepStatus.SKIPPED}
        step_map = {s.id: s for s in graph.steps}

        changed = True
        while changed:
            changed = False
            for sid in list(skipped_ids):
                step = step_map.get(sid)
                if not step:
                    continue
                # Check if all deps are now satisfied
                if all(d in succeeded for d in step.depends_on):
                    tool_fn = tool_map.get(step.tool)
                    if not tool_fn:
                        continue
                    resolved = resolve_refs(step.args, succeeded)
                    try:
                        res = await tool_fn(**resolved)
                        new_sr = StepResult(
                            step_id=sid, tool=step.tool, args=resolved,
                            status=StepStatus.SUCCESS, result=res, healed=True,
                        )
                        # Replace the skipped entry
                        result.steps = [
                            new_sr if sr.step_id == sid else sr
                            for sr in result.steps
                        ]
                        succeeded[sid] = res
                        skipped_ids.discard(sid)
                        changed = True
                    except Exception as exc:
                        logger.warning("Replay of %s failed: %s", sid, exc)

        return result

    # ── Compile-Once, Run-Anywhere ────────────────────────────────

    async def compile(self, prompt: str, tools: list[ToolSpec], path: str | Path = "compiled.sirx", **kwargs: Any) -> CompiledDAG:
        """Plan + optimise a DAG, then compile it to a binary .sirx file.

        The resulting file can be executed with ``run_compiled`` without
        any LLM call — zero inference latency, zero token cost.
        """
        tool_map = {t.name: t for t in tools}
        tool_names = set(tool_map.keys())

        prior = await self.memory.find(prompt) if self.memory else None
        messages = compile_prompt(tools, prompt, prior_logic=prior, tool_mode=self.tool_mode)
        kwargs.setdefault("max_tokens", self.max_tokens)
        graph = await self._generate_graph(messages, tool_names, **kwargs)

        if self.enable_optimizer:
            graph, _ = optimize_graph(graph, tool_names)

        compiled = compile_graph(graph, prompt, sorted(tool_names))
        compiled.save(path)
        logger.info("Compiled DAG saved to %s (%d steps)", path, len(graph.steps))
        return compiled

    @staticmethod
    async def run_compiled(
        path: str | Path,
        tools: list[ToolSpec],
        *,
        enable_speculation: bool = True,
    ) -> GraphResult:
        """Execute a pre-compiled .sirx DAG — zero LLM calls."""
        compiled = CompiledDAG.load(path)
        tool_map = {t.name: t for t in tools}

        missing = set(compiled.tool_names) - set(tool_map.keys())
        if missing:
            raise ValueError(f"Compiled DAG requires tools not provided: {missing}")

        return await execute_graph(
            compiled.graph, tool_map, compiled.prompt,
            enable_speculation=enable_speculation,
        )

    async def _generate_graph(self, messages, tool_names, **kwargs):
        last_err = None
        for attempt in range(self.llm_retries + 1):
            try:
                raw = await self.provider.generate(messages, **kwargs)
                self._last_raw_output = raw
                graph = parse_graph(raw)
                validate_graph(graph, tool_names)
                return graph
            except (GraphValidationError, Exception) as exc:
                last_err = exc
                logger.warning("LLM attempt %d failed: %s", attempt + 1, exc)
                if attempt < self.llm_retries:
                    await asyncio.sleep(1.0 * (attempt + 1))
        raise last_err
