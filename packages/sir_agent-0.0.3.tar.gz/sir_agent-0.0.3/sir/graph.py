"""Graph parsing, validation, and condition evaluation."""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from sir.models import ActionGraph, Condition, Step

logger = logging.getLogger("sir")


class GraphValidationError(Exception):
    pass


# ── Alias expansion (compact LLM output → full model keys) ─────────

_STEP_ALIASES = {"t": "tool", "a": "args", "d": "depends_on", "c": "condition", "f": "foreach", "r": "retry", "alt": "alternatives", "sel": "select"}
_ALT_ALIASES = {"t": "tool", "a": "args"}
_COND_ALIASES = {"op": "operator", "val": "value"}
_ROOT_ALIASES = {"s": "steps", "fs": "final_step", "ps": "prior_scores", "nr": "needs_reasoning"}
_SCORE_ALIASES = {"sid": "step_id", "sc": "score", "n": "note"}


def _expand_condition(c: Any) -> Any:
    if not isinstance(c, dict):
        return c
    return {_COND_ALIASES.get(k, k): v for k, v in c.items()}


def _expand_alt(a: dict) -> dict:
    return {_ALT_ALIASES.get(k, k): v for k, v in a.items()}


def _expand_step(s: dict) -> dict:
    out = {}
    for k, v in s.items():
        key = _STEP_ALIASES.get(k, k)
        if key == "condition" and v is not None:
            v = _expand_condition(v)
        elif key == "alternatives" and isinstance(v, list):
            v = [_expand_alt(a) if isinstance(a, dict) else a for a in v]
        elif key == "depends_on" and isinstance(v, str):
            v = [x.strip() for x in v.split(",") if x.strip()]  # coerce "s1,s2" → ["s1", "s2"]
        out[key] = v
    return out


def _expand_score(s: dict) -> dict:
    return {_SCORE_ALIASES.get(k, k): v for k, v in s.items()}


def _expand_aliases(data: dict) -> dict:
    out = {}
    for k, v in data.items():
        key = _ROOT_ALIASES.get(k, k)
        if key == "steps" and isinstance(v, list):
            v = [_expand_step(s) for s in v]
        elif key == "prior_scores" and isinstance(v, list):
            v = [_expand_score(s) for s in v]
        out[key] = v
    return out


# ── Robust JSON extraction ──────────────────────────────────────────

def _extract_json_object(raw: str) -> dict:
    """Extract the first valid JSON object from raw text, tolerating noise."""
    text = raw.strip()
    # Strip markdown fences
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```\s*$", "", text)

    # Try direct parse first
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            return data
    except json.JSONDecodeError:
        pass

    # Find first balanced { ... } block
    depth = 0
    start = None
    for i, ch in enumerate(text):
        if ch == "{":
            if depth == 0:
                start = i
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0 and start is not None:
                try:
                    return json.loads(text[start:i + 1])
                except json.JSONDecodeError:
                    start = None

    raise GraphValidationError(f"No valid JSON object found in LLM output ({len(raw)} chars)")


# ── Parsing ─────────────────────────────────────────────────────────

def parse_graph(raw: str) -> ActionGraph:
    data = _extract_json_object(raw)
    data = _expand_aliases(data)

    # Auto-infer final_step if missing: last step with no dependents
    if not data.get("final_step"):
        steps = data.get("steps", [])
        if steps:
            all_ids = {s.get("id") or s.get("id") for s in steps}
            depended_on = set()
            for s in steps:
                for d in s.get("depends_on", []):
                    depended_on.add(d)
            leaf_ids = all_ids - depended_on
            # Pick the last leaf in order
            for s in reversed(steps):
                if s.get("id") in leaf_ids:
                    data["final_step"] = s["id"]
                    break

    return ActionGraph.model_validate(data)


# ── Validation (lenient mode: fix what we can, reject only fatal) ───

def validate_graph(graph: ActionGraph, tool_names: set[str]) -> None:
    ids = {s.id for s in graph.steps}

    # Remove steps with unknown tools instead of crashing
    valid_steps = []
    for step in graph.steps:
        if step.tool not in tool_names:
            logger.warning("Removing step %s: unknown tool '%s'", step.id, step.tool)
            continue
        # Remove unknown dependencies
        step.depends_on = [d for d in step.depends_on if d in ids]
        valid_steps.append(step)
    graph.steps = valid_steps
    ids = {s.id for s in graph.steps}

    if not graph.steps:
        raise GraphValidationError("No valid steps after filtering unknown tools")

    # Remove duplicate step IDs (keep first)
    seen_ids: set[str] = set()
    deduped: list[Step] = []
    for s in graph.steps:
        if s.id in seen_ids:
            logger.warning("Removing duplicate step ID: %s", s.id)
            continue
        seen_ids.add(s.id)
        deduped.append(s)
    graph.steps = deduped
    ids = {s.id for s in graph.steps}

    # Fix final_step
    if not graph.final_step or graph.final_step not in ids:
        # Pick the deepest leaf node (most dependencies upstream)
        depended_on = set()
        for s in graph.steps:
            depended_on.update(s.depends_on)
        leaves = [s for s in graph.steps if s.id not in depended_on]
        graph.final_step = leaves[-1].id if leaves else graph.steps[-1].id

    # Break cycles by removing the back-edge
    try:
        _detect_cycles(graph.steps)
    except GraphValidationError:
        logger.warning("Cycle detected, attempting repair")
        graph.steps = _break_cycles(graph.steps)
        _detect_cycles(graph.steps)  # re-validate


def _detect_cycles(steps: list[Step]) -> None:
    adj: dict[str, list[str]] = {s.id: list(s.depends_on) for s in steps}
    WHITE, GRAY, BLACK = 0, 1, 2
    color: dict[str, int] = {sid: WHITE for sid in adj}

    def dfs(node: str) -> None:
        color[node] = GRAY
        for nb in adj.get(node, []):
            if color[nb] == GRAY:
                raise GraphValidationError(f"Cycle detected involving '{nb}'")
            if color[nb] == WHITE:
                dfs(nb)
        color[node] = BLACK

    for sid in adj:
        if color[sid] == WHITE:
            dfs(sid)


def _break_cycles(steps: list[Step]) -> list[Step]:
    """Remove back-edges to break cycles. Preserves as many deps as possible."""
    adj: dict[str, list[str]] = {s.id: list(s.depends_on) for s in steps}
    WHITE, GRAY, BLACK = 0, 1, 2
    color: dict[str, int] = {sid: WHITE for sid in adj}
    back_edges: list[tuple[str, str]] = []

    def dfs(node: str) -> None:
        color[node] = GRAY
        for nb in adj.get(node, []):
            if color.get(nb) == GRAY:
                back_edges.append((node, nb))
            elif color.get(nb, WHITE) == WHITE:
                dfs(nb)
        color[node] = BLACK

    for sid in adj:
        if color[sid] == WHITE:
            dfs(sid)

    step_map = {s.id: s for s in steps}
    for src, dst in back_edges:
        if src in step_map:
            step_map[src].depends_on = [d for d in step_map[src].depends_on if d != dst]
            logger.warning("Broke cycle: removed %s -> %s", src, dst)

    return steps


def topological_sort(steps: list[Step]) -> list[list[Step]]:
    id_map = {s.id: s for s in steps}
    in_degree: dict[str, int] = {s.id: len(s.depends_on) for s in steps}
    layers: list[list[Step]] = []
    remaining = set(id_map.keys())

    while remaining:
        layer = [sid for sid in remaining if in_degree[sid] == 0]
        if not layer:
            raise GraphValidationError("Unresolvable dependencies (cycle?)")
        layers.append([id_map[sid] for sid in layer])
        for sid in layer:
            remaining.discard(sid)
            for s in steps:
                if sid in s.depends_on:
                    in_degree[s.id] -= 1

    return layers


# ── Variable resolution ─────────────────────────────────────────────

_REF_PATTERN = re.compile(r"\$s\d+(?:\.result)?")


def resolve_refs(value: Any, results: dict[str, Any]) -> Any:
    if isinstance(value, str):
        if value == "$item":
            return results.get("$item", value)
        match = _REF_PATTERN.fullmatch(value)
        if match:
            ref_id = value[1:].split(".")[0]
            resolved = results.get(ref_id)
            if resolved is not None:
                return resolved
            return value

        def _replace(m: re.Match) -> str:
            ref_id = m.group(0)[1:].split(".")[0]
            resolved = results.get(ref_id)
            if resolved is not None:
                return str(resolved)
            return m.group(0)

        return _REF_PATTERN.sub(_replace, value)
    if isinstance(value, dict):
        return {k: resolve_refs(v, results) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve_refs(v, results) for v in value]
    return value


# ── Condition evaluation ────────────────────────────────────────────

def evaluate_condition(cond: Condition, results: dict[str, Any]) -> bool:
    ref_id = cond.ref[1:].split(".")[0]
    actual = results.get(ref_id)
    op = cond.operator.lower()
    val = cond.value

    ops = {
        "contains": lambda: val in str(actual),
        "not_contains": lambda: val not in str(actual),
        "equals": lambda: actual == val,
        "not_equals": lambda: actual != val,
        "gt": lambda: float(actual) > float(val),
        "lt": lambda: float(actual) < float(val),
        "gte": lambda: float(actual) >= float(val),
        "lte": lambda: float(actual) <= float(val),
        "not_empty": lambda: bool(actual),
        "is_empty": lambda: not bool(actual),
    }
    evaluator = ops.get(op)
    if not evaluator:
        return False  # Unknown op → skip instead of crash
    try:
        return evaluator()
    except (TypeError, ValueError):
        return False
