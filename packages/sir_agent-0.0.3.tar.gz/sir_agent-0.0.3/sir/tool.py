"""@tool decorator — extracts JSON-schema from function signatures."""

from __future__ import annotations

import asyncio
import inspect
from typing import Any, Callable, get_type_hints

_TYPE_MAP: dict[type, str] = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
    list: "array",
    dict: "object",
}


class ToolSpec:
    __slots__ = ("fn", "name", "description", "schema", "is_async", "required")

    def __init__(self, fn: Callable, name: str | None = None, description: str | None = None,
                 required: bool = True):
        self.fn = fn
        self.name = name or fn.__name__
        self.description = description or (fn.__doc__ or "").strip() or f"Tool: {self.name}"
        self.is_async = asyncio.iscoroutinefunction(fn)
        self.schema = self._extract_schema(fn)
        self.required = required

    @staticmethod
    def _extract_schema(fn: Callable) -> dict[str, Any]:
        hints = get_type_hints(fn)
        sig = inspect.signature(fn)
        props: dict[str, Any] = {}
        required: list[str] = []
        for pname, param in sig.parameters.items():
            if pname in ("self", "cls"):
                continue
            ptype = hints.get(pname, str)
            origin = getattr(ptype, "__origin__", None)
            json_type = _TYPE_MAP.get(origin or ptype, "string")
            props[pname] = {"type": json_type}
            if param.default is inspect.Parameter.empty:
                required.append(pname)
        return {"properties": props, "required": required}

    async def __call__(self, **kwargs: Any) -> Any:
        if self.is_async:
            return await self.fn(**kwargs)
        return await asyncio.to_thread(self.fn, **kwargs)

    def to_prompt_dict(self) -> dict[str, Any]:
        return {"name": self.name, "description": self.description, "parameters": self.schema}


def tool(fn: Callable | None = None, *, name: str | None = None, description: str | None = None,
         required: bool = True):
    """Decorator to register a function as a SIR tool.

    Args:
        required: If True (default), this tool MUST be used in strict mode.
                  If False, the tool is optional (only used in strict mode).
    """
    def wrap(f: Callable) -> ToolSpec:
        return ToolSpec(f, name=name, description=description, required=required)

    if fn is not None:
        return wrap(fn)
    return wrap
