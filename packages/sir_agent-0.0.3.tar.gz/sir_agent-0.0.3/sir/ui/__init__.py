"""SIR UI — local web dashboard."""
