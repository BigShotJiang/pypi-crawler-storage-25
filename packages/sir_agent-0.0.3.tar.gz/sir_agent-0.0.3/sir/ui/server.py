"""SIR UI — FastAPI backend with WebSocket for real-time DAG execution."""

from __future__ import annotations

import asyncio
import json
import os
import time
from pathlib import Path
from typing import Any

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, FileResponse

from sir.memory.store import Memory
from sir.models import GraphResult, StepResult, StepStatus

app = FastAPI(title="SIR UI")

_memory_path = "dags.bin"


def _get_frontend() -> str:
    frontend_path = Path(__file__).parent / "frontend.html"
    return frontend_path.read_text()


@app.get("/static/{filepath:path}")
async def serve_static(filepath: str):
    """Serve static files (logo, icons) from docs/static."""
    # Try multiple locations
    candidates = [
        Path.cwd() / "docs" / "static" / filepath,
        Path.cwd() / "static" / filepath,
        Path(__file__).parent.parent.parent / "docs" / "static" / filepath,
        Path(__file__).parent.parent.parent / "static" / filepath,
    ]
    for p in candidates:
        if p.exists():
            return FileResponse(p)
    return HTMLResponse(status_code=404, content="Not found")


@app.get("/", response_class=HTMLResponse)
async def index():
    return _get_frontend()


@app.get("/api/memory")
async def get_memory():
    mem = Memory(path=_memory_path)
    records = []
    for rec in mem.records:
        steps = []
        for sr in rec.steps:
            steps.append({
                "id": sr.step.id,
                "tool": sr.step.tool,
                "args": sr.step.args,
                "depends_on": sr.step.depends_on,
                "score": round(sr.score, 1),
                "executions": sr.executions,
                "deprecated": sr.deprecated,
                "notes": sr.notes[-3:] if sr.notes else [],
            })
        records.append({
            "logic_id": rec.logic_id,
            "prompt": rec.prompt_text,
            "times_used": rec.times_used,
            "avg_score": round(rec.avg_score, 1),
            "created_at": rec.created_at,
            "last_used_at": rec.last_used_at,
            "steps": steps,
        })
    return {"records": records}


@app.get("/api/memory/{logic_id}")
async def get_memory_detail(logic_id: str):
    mem = Memory(path=_memory_path)
    rec = next((r for r in mem.records if r.logic_id == logic_id), None)
    if not rec:
        return {"error": "not found"}
    steps = []
    for sr in rec.steps:
        steps.append({
            "id": sr.step.id,
            "tool": sr.step.tool,
            "args": sr.step.args,
            "depends_on": sr.step.depends_on,
            "condition": sr.step.condition.model_dump() if sr.step.condition else None,
            "foreach": sr.step.foreach,
            "score": round(sr.score, 1),
            "executions": sr.executions,
            "deprecated": sr.deprecated,
            "notes": sr.notes,
        })
    return {
        "logic_id": rec.logic_id,
        "prompt": rec.prompt_text,
        "times_used": rec.times_used,
        "avg_score": round(rec.avg_score, 1),
        "created_at": rec.created_at,
        "last_used_at": rec.last_used_at,
        "steps": steps,
    }


@app.get("/api/memory/timeline/{logic_id}")
async def get_memory_timeline(logic_id: str):
    """Return score evolution data for a logic record."""
    mem = Memory(path=_memory_path)
    rec = next((r for r in mem.records if r.logic_id == logic_id), None)
    if not rec:
        return {"error": "not found"}
    timeline = []
    for sr in rec.steps:
        timeline.append({
            "id": sr.step.id,
            "tool": sr.step.tool,
            "score": round(sr.score, 1),
            "executions": sr.executions,
            "deprecated": sr.deprecated,
            "notes": sr.notes,
        })
    return {
        "logic_id": rec.logic_id,
        "prompt": rec.prompt_text,
        "times_used": rec.times_used,
        "avg_score": round(rec.avg_score, 1),
        "steps": timeline,
    }


@app.websocket("/ws/run")
async def ws_run(ws: WebSocket):
    """WebSocket endpoint for real-time DAG execution.

    Client sends: {"prompt": "...", "tools_module": "path/to/tools.py", "model": "...", "provider": "ollama"}
    Server streams: {"type": "planning"}, {"type": "step", ...}, {"type": "result", ...}, {"type": "error", ...}
    """
    await ws.accept()
    try:
        data = await ws.receive_json()
        prompt = data.get("prompt", "")
        tools_module = data.get("tools_module", "")
        model = data.get("model", "qwen2.5:14b")
        provider_name = data.get("provider", "ollama")
        api_key = data.get("api_key", "") or None
        embed_provider_name = data.get("embed_provider", "same")
        embed_model = data.get("embed_model", "") or None
        embed_api_key = data.get("embed_api_key", "") or None
        embed_host = data.get("embed_host", "") or None
        host = data.get("host", "") or None

        if not prompt or not tools_module:
            await ws.send_json({"type": "error", "message": "prompt and tools_module required"})
            return

        # Load .env from working directory
        env_path = Path.cwd() / ".env"
        if env_path.exists():
            for line in env_path.read_text().splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    k, v = line.split("=", 1)
                    os.environ.setdefault(k.strip(), v.strip())
                elif ":" in line:
                    k, v = line.split(":", 1)
                    os.environ.setdefault(k.strip(), v.strip())

        # Load tools
        import importlib.util
        path = Path(tools_module).resolve()
        if not path.exists():
            await ws.send_json({"type": "error", "message": f"File not found: {tools_module}"})
            return

        from sir.tool import ToolSpec
        spec = importlib.util.spec_from_file_location("_tools", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        tool_list = [v for v in vars(mod).values() if isinstance(v, ToolSpec)]

        if not tool_list:
            await ws.send_json({"type": "error", "message": "No @tool functions found"})
            return

        # Send tool info
        await ws.send_json({
            "type": "tools",
            "tools": [{"name": t.name, "description": t.description} for t in tool_list],
        })

        # Build provider
        provider = _make_provider(provider_name, model, api_key=api_key, host=host)

        # Build embed provider
        embed_prov = _make_embed_provider(
            embed_provider_name or "ollama",
            embed_model or "nomic-embed-text",
            embed_api_key,
            embed_host,
        )

        from sir.core import SIR
        sir = SIR(provider=provider, embed_provider=embed_prov,
                  memory_path=_memory_path, enable_memory=True)

        import logging
        logger = logging.getLogger("sir")
        logger.setLevel(logging.INFO)
        logging.basicConfig(level=logging.INFO, force=True)

        # Planning phase
        await ws.send_json({"type": "planning"})

        t0 = time.perf_counter()
        all_steps: list[dict] = []

        # Execute planning phase first to get the graph
        # We need to start the stream to trigger planning
        stream = sir.arun_stream(prompt, tool_list)
        first_item = None
        async for item in stream:
            if isinstance(item, StepResult):
                # Planning is done, graph is available
                if sir._last_graph:
                    g = sir._last_graph
                    await ws.send_json({
                        "type": "graph",
                        "steps": [
                            {"id": s.id, "tool": s.tool, "depends_on": s.depends_on}
                            for s in g.steps
                        ],
                        "final_step": g.final_step,
                    })
                    # Small delay to let frontend render the graph
                    await asyncio.sleep(0.05)
                first_item = item
                break
            elif isinstance(item, GraphResult):
                first_item = item
                break

        # Process first item
        if isinstance(first_item, StepResult):
            step_data = {
                "type": "step",
                "step_id": first_item.step_id,
                "tool": first_item.tool,
                "args": first_item.args,
                "status": first_item.status.value,
                "result": str(first_item.result)[:500] if first_item.result else None,
                "error": first_item.error,
                "duration_ms": round(first_item.duration_ms, 1),
                "speculative": first_item.speculative,
                "healed": first_item.healed,
            }
            all_steps.append(step_data)
            await ws.send_json(step_data)

        # Continue with remaining items
        if not isinstance(first_item, GraphResult):
            async for item in stream:
                if isinstance(item, StepResult):
                    step_data = {
                        "type": "step",
                        "step_id": item.step_id,
                        "tool": item.tool,
                        "args": item.args,
                        "status": item.status.value,
                        "result": str(item.result)[:500] if item.result else None,
                        "error": item.error,
                        "duration_ms": round(item.duration_ms, 1),
                        "speculative": item.speculative,
                        "healed": item.healed,
                    }
                    all_steps.append(step_data)
                    await ws.send_json(step_data)
                elif isinstance(item, GraphResult):
                    if item.reasoning:
                        await ws.send_json({"type": "reasoning", "text": item.reasoning})
                    n_steps = len(item.steps)
                    healed_ids = [sr.step_id for sr in item.steps if sr.healed]
                    await ws.send_json({
                        "type": "result",
                        "final_result": str(item.final_result) if item.final_result else None,
                        "reasoning": item.reasoning,
                        "raw_llm_output": sir._last_raw_output,
                        "total_duration_ms": round(item.total_duration_ms, 1),
                        "from_memory": item.from_memory,
                        "optimizations": item.optimizations_applied,
                        "steps_count": n_steps,
                        "total_input_tokens": provider.total_input_tokens,
                        "total_output_tokens": provider.total_output_tokens,
                        "healed": item.healed,
                        "healed_steps": healed_ids,
                    })
                    await ws.close(1000)

    except WebSocketDisconnect:
        pass
    except Exception as e:
        try:
            await ws.send_json({"type": "error", "message": str(e)})
        except Exception:
            pass


def _make_provider(name: str, model: str, api_key: str | None = None,
                   host: str | None = None):
    if name == "openai":
        from sir.providers import OpenAIProvider
        return OpenAIProvider(model=model, api_key=api_key)
    if name == "claude":
        from sir.providers import ClaudeProvider
        return ClaudeProvider(model=model, api_key=api_key)
    if name == "bedrock":
        from sir.providers import BedrockProvider
        return BedrockProvider(model=model)
    if name == "gemini":
        from sir.providers import GeminiProvider
        return GeminiProvider(model=model, api_key=api_key)
    if name == "openrouter":
        from sir.providers import OpenRouterProvider
        return OpenRouterProvider(model=model, api_key=api_key)
    if name == "perplexity":
        from sir.providers import PerplexityProvider
        return PerplexityProvider(model=model, api_key=api_key)
    if name == "mistral":
        from sir.providers import MistralProvider
        return MistralProvider(model=model, api_key=api_key)
    from sir.providers import OllamaProvider
    return OllamaProvider(model=model, host=host)


def _make_embed_provider(name: str, embed_model: str | None,
                         api_key: str | None = None, host: str | None = None):
    """Build a provider specifically for embeddings."""
    if name == "openai":
        from sir.providers import OpenAIProvider
        return OpenAIProvider(model="unused", api_key=api_key,
                              embed_model=embed_model or "text-embedding-3-small")
    if name == "ollama":
        from sir.providers import OllamaProvider
        return OllamaProvider(model="unused", host=host,
                              embed_model=embed_model or "nomic-embed-text")
    return None


def start(host: str = "127.0.0.1", port: int = 7437, memory: str = "dags.bin"):
    global _memory_path
    _memory_path = memory
    import uvicorn
    uvicorn.run(app, host=host, port=port, log_level="warning")
