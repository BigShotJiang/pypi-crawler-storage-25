"""Domain models for SIR."""

from __future__ import annotations

import time
from enum import Enum
from typing import Any
from pydantic import BaseModel, Field


# ── Graph models (LLM output) ──────────────────────────────────────

class Condition(BaseModel):
    ref: str
    operator: str
    value: Any = None


class StepScore(BaseModel):
    step_id: str
    score: float = Field(ge=0.0, le=10.0)
    note: str = ""


class Alternative(BaseModel):
    """An alternative tool+args for DAG branching."""
    tool: str
    args: dict[str, Any] = Field(default_factory=dict)


class Step(BaseModel):
    id: str
    tool: str
    args: dict[str, Any] = Field(default_factory=dict)
    depends_on: list[str] = Field(default_factory=list)
    condition: Condition | None = None
    foreach: str | list | None = None
    retry: int = Field(default=0, ge=0, le=5)
    alternatives: list[Alternative] = Field(default_factory=list)
    select: str | None = None  # "fastest" | "shortest" | "longest" | None


class ActionGraph(BaseModel):
    steps: list[Step]
    final_step: str | None = None
    needs_reasoning: bool = False
    prior_scores: list[StepScore] = Field(default_factory=list)


# ── Execution results ───────────────────────────────────────────────

class StepStatus(str, Enum):
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"
    SPECULATIVE = "speculative"  # executed speculatively, may be re-run


class StepResult(BaseModel):
    step_id: str
    tool: str
    args: dict[str, Any]
    status: StepStatus
    result: Any = None
    error: str | None = None
    duration_ms: float = 0.0
    speculative: bool = False  # True if this was a speculative execution
    healed: bool = False  # True if this step was repaired by self-healing


class GraphResult(BaseModel):
    prompt: str
    steps: list[StepResult]
    final_result: Any = None
    reasoning: str | None = None
    total_duration_ms: float = 0.0
    from_memory: bool = False
    optimizations_applied: list[str] = Field(default_factory=list)
    healed: bool = False  # True if self-healing was triggered


# ── Memory / evolutionary models ────────────────────────────────────

class StepRecord(BaseModel):
    step: Step
    score: float = Field(default=5.0, ge=0.0, le=10.0)
    notes: list[str] = Field(default_factory=list)
    executions: int = 0
    deprecated: bool = False


class LogicRecord(BaseModel):
    logic_id: str
    prompt_text: str
    embedding: list[float] = Field(default_factory=list)
    steps: list[StepRecord]
    created_at: float = Field(default_factory=time.time)
    last_used_at: float = Field(default_factory=time.time)
    times_used: int = 1
    avg_score: float = 5.0
