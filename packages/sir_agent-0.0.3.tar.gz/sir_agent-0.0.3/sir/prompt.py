"""Prompt compiler — compressed single-shot system prompt with tool modes."""

from __future__ import annotations

import json

from sir.tool import ToolSpec
from sir.models import LogicRecord

# ── Tool mode instructions ──────────────────────────────────────────

_MODE_STRICT = """\
STRICT MODE: You MUST use ALL tools listed above. Every tool must appear exactly once in the graph (unless foreach expands it). Do NOT skip any tool. Do NOT add tools not in the list. Your job is to decide the optimal ORDER, PARALLELISM, and DEPENDENCIES — not which tools to use."""

_MODE_ADAPTIVE = """\
ADAPTIVE MODE: Map the user request to the MINIMUM set of tools needed. Each word in the request should map to at most one tool. Do NOT add tools for validation, caching, logging, formatting, or any step the user did not explicitly request. Fewer steps = better."""

_MODE_REQUIRED = """\
REQUIRED+OPTIONAL MODE: Tools marked [REQUIRED] MUST appear in the graph. Tools marked [optional] MAY be used if they help, but are not mandatory. Do NOT add tools not in the list."""

SYSTEM_TEMPLATE = """\
You are SIR, a planning engine. Produce a SINGLE JSON action graph to solve the user request. You will NOT be called again — unless you set nr=true.

Tools: {tools_json}

Output ONLY valid JSON:
{{"s":[{{"id":"s1","t":"<tool>","a":{{}}}}],"fs":"s1","nr":false,"ps":[]}}

Keys: t=tool, a=args, d=depends_on, c=condition(ref/op/val), f=foreach, r=retry(0-5), fs=final_step, nr=needs_reasoning, ps=prior_scores, alt=alternatives, sel=select.
Refs: "$s1.result" in args refs step s1 output. "$item" for foreach iteration.
Condition ops: contains,not_contains,equals,not_equals,gt,lt,gte,lte,not_empty,is_empty
Alternatives: for critical steps, provide alt=[{{"t":"other_tool","a":{{}}}}] with sel="fastest"|"shortest"|"longest".

nr (needs_reasoning): set to true ONLY when the user request requires understanding, analysis, summarization, explanation, or synthesis of the tool results. When nr=true, after all tools execute, you will receive their outputs and produce a final reasoned answer. When nr=false (default), the last tool's output IS the final answer. Use nr=false for pure data pipelines (fetch, transform, translate, store).

Rules: maximise parallelism; use foreach for map-reduce; omit null/empty fields.
Output MUST be compact: no indentation, no spaces, no null fields. Omit d/c/f/r/alt/sel/nr if empty/null/0/false.
{mode_instruction}
{memory_section}\
"""

MEMORY_SECTION = """
Prior logic (scored 0-10, DEPRECATED=ineffective):
{prior_logic}
In "ps", score each prior step and add a note. Replace deprecated/low-scored steps.\
"""


def compile_prompt(
    tools: list[ToolSpec],
    user_prompt: str,
    prior_logic: LogicRecord | None = None,
    tool_mode: str = "adaptive",
) -> list[dict[str, str]]:
    tools_compact = []
    for t in tools:
        params = {k: v["type"] for k, v in t.schema.get("properties", {}).items()}
        entry: dict = {"n": t.name, "d": t.description, "p": params}
        if tool_mode == "required":
            entry["req"] = t.required
        tools_compact.append(entry)

    # Mode instruction
    if tool_mode == "strict":
        mode_instruction = _MODE_STRICT
    elif tool_mode == "required":
        mode_instruction = _MODE_REQUIRED
    else:
        mode_instruction = _MODE_ADAPTIVE

    memory_section = ""
    if prior_logic:
        prior_data = []
        for sr in prior_logic.steps:
            entry_m: dict = {
                "id": sr.step.id,
                "t": sr.step.tool,
                "sc": round(sr.score, 1),
            }
            if sr.deprecated:
                entry_m["DEP"] = True
            if sr.notes:
                entry_m["notes"] = sr.notes[-3:]
            prior_data.append(entry_m)
        memory_section = MEMORY_SECTION.format(
            prior_logic=json.dumps(prior_data, separators=(",", ":"))
        )

    system = SYSTEM_TEMPLATE.format(
        tools_json=json.dumps(tools_compact, separators=(",", ":")),
        mode_instruction=mode_instruction,
        memory_section=memory_section,
    )
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": user_prompt},
    ]
