"""Graph optimizer — post-LLM DAG optimization passes."""

from __future__ import annotations

import logging
from typing import Any

from sir.models import ActionGraph, Step

logger = logging.getLogger("sir")


def optimize_graph(graph: ActionGraph, tool_names: set[str]) -> tuple[ActionGraph, list[str]]:
    """Run all optimization passes on the graph. Returns (optimized_graph, list_of_applied_optimizations)."""
    steps = [s.model_copy(deep=True) for s in graph.steps]
    applied: list[str] = []

    steps, n = _infer_dependencies(steps)
    if n:
        applied.append(f"dependency_inference: added {n} implicit deps from args")

    steps, n = _eliminate_dead_steps(steps, graph.final_step)
    if n:
        applied.append(f"dead_step_elimination: removed {n} unreachable steps")

    steps, n = _merge_duplicate_steps(steps)
    if n:
        applied.append(f"duplicate_merge: merged {n} duplicate steps")

    optimized = ActionGraph(
        steps=steps,
        final_step=graph.final_step,
        prior_scores=graph.prior_scores,
    )
    return optimized, applied


def _infer_dependencies(steps: list[Step]) -> tuple[list[Step], int]:
    """Add missing dependencies inferred from $sN references in args."""
    ids = {s.id for s in steps}
    added = 0
    for step in steps:
        refs = set(_extract_refs(step.args))
        if step.foreach and isinstance(step.foreach, str) and step.foreach.startswith("$"):
            refs.add(step.foreach[1:].split(".")[0])
        if step.condition:
            refs.add(step.condition.ref[1:].split(".")[0])
        for ref in refs:
            if ref in ids and ref != step.id and ref not in step.depends_on:
                step.depends_on.append(ref)
                added += 1
    return steps, added


def _eliminate_dead_steps(steps: list[Step], final_step: str | None) -> tuple[list[Step], int]:
    """Remove steps whose output is never referenced by any other step and are not leaf nodes."""
    if not steps:
        return steps, 0

    id_map = {s.id: s for s in steps}

    # Find all step IDs that are depended on by at least one other step
    depended_on = set()
    for s in steps:
        for d in s.depends_on:
            depended_on.add(d)
        for ref in _extract_refs(s.args):
            depended_on.add(ref)
        if s.foreach:
            if isinstance(s.foreach, str) and s.foreach.startswith("$"):
                depended_on.add(s.foreach[1:].split(".")[0])
        if s.condition:
            depended_on.add(s.condition.ref[1:].split(".")[0])

    # Leaf nodes = steps that no other step depends on
    leaf_ids = {s.id for s in steps} - depended_on

    # Walk backwards from ALL leaves (not just final_step) to find reachable
    reachable: set[str] = set()
    queue = list(leaf_ids)
    if final_step and final_step not in leaf_ids:
        queue.append(final_step)

    while queue:
        sid = queue.pop()
        if sid in reachable or sid not in id_map:
            continue
        reachable.add(sid)
        step = id_map[sid]
        queue.extend(step.depends_on)
        for ref in _extract_refs(step.args):
            queue.append(ref)
        if step.foreach and isinstance(step.foreach, str) and step.foreach.startswith("$"):
            queue.append(step.foreach[1:].split(".")[0])
        if step.condition:
            queue.append(step.condition.ref[1:].split(".")[0])

    original_count = len(steps)
    steps = [s for s in steps if s.id in reachable]
    removed = original_count - len(steps)

    if removed:
        logger.info("Dead step elimination: removed %d steps", removed)

    return steps, removed


def _extract_refs(value: Any) -> list[str]:
    """Extract all $sN step references from args."""
    import re
    refs = []
    if isinstance(value, str):
        for m in re.finditer(r"\$s(\d+)(?:\.result)?", value):
            refs.append(f"s{m.group(1)}")
    elif isinstance(value, dict):
        for v in value.values():
            refs.extend(_extract_refs(v))
    elif isinstance(value, list):
        for v in value:
            refs.extend(_extract_refs(v))
    return refs


def _merge_duplicate_steps(steps: list[Step]) -> tuple[list[Step], int]:
    """Merge steps that call the same tool with identical args."""
    merged = 0
    seen: dict[str, str] = {}  # (tool, frozen_args) → step_id
    remap: dict[str, str] = {}  # old_id → canonical_id

    for step in steps:
        key = f"{step.tool}:{_freeze(step.args)}"
        if key in seen and not step.foreach and not step.condition and not step.alternatives:
            remap[step.id] = seen[key]
            merged += 1
        else:
            seen[key] = step.id

    if not remap:
        return steps, 0

    # Rewrite references
    kept = [s for s in steps if s.id not in remap]
    for step in kept:
        step.depends_on = [remap.get(d, d) for d in step.depends_on]
        step.args = _rewrite_refs(step.args, remap)
        if step.foreach:
            ref_id = step.foreach[1:].split(".")[0]
            if ref_id in remap:
                step.foreach = step.foreach.replace(ref_id, remap[ref_id])

    logger.info("Duplicate merge: merged %d steps", merged)
    return kept, merged


def _relax_dependencies(steps: list[Step]) -> tuple[list[Step], int]:
    """Remove dependencies that aren't actually needed (step doesn't reference the dep's output)."""
    removed = 0
    for step in steps:
        needed = set()
        # Refs in args
        for ref in _extract_refs(step.args):
            needed.add(ref)
        # Foreach ref
        if step.foreach and isinstance(step.foreach, str) and step.foreach.startswith("$"):
            needed.add(step.foreach[1:].split(".")[0])
        # Condition ref
        if step.condition:
            needed.add(step.condition.ref[1:].split(".")[0])

        original = len(step.depends_on)
        step.depends_on = [d for d in step.depends_on if d in needed]
        removed += original - len(step.depends_on)

    if removed:
        logger.info("Dependency relaxation: removed %d unnecessary deps", removed)

    return steps, removed


def _freeze(obj: Any) -> str:
    """Create a hashable string from args for dedup."""
    import json
    return json.dumps(obj, sort_keys=True, default=str)


def _rewrite_refs(value: Any, remap: dict[str, str]) -> Any:
    """Rewrite $sN.result references according to remap."""
    import re
    if isinstance(value, str):
        def _replace(m: re.Match) -> str:
            ref_id = m.group(0)[1:].split(".")[0]
            new_id = remap.get(ref_id, ref_id)
            return m.group(0).replace(ref_id, new_id)
        return re.sub(r"\$s\d+(?:\.result)?", _replace, value)
    if isinstance(value, dict):
        return {k: _rewrite_refs(v, remap) for k, v in value.items()}
    if isinstance(value, list):
        return [_rewrite_refs(v, remap) for v in value]
    return value
