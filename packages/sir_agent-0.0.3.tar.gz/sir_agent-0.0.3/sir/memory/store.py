"""Evolutionary memory — vectorised binary persistence with semantic matching."""

from __future__ import annotations

import math
import os
import time
import uuid
from pathlib import Path
from typing import Any

import msgpack

from sir.models import (
    ActionGraph,
    GraphResult,
    LogicRecord,
    StepRecord,
    StepScore,
    StepStatus,
)

DEFAULT_PATH = Path("dags.bin")
DEPRECATION_THRESHOLD = 3.0
SIMILARITY_THRESHOLD = 0.78


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    if len(a) != len(b) or not a:
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    return dot / (na * nb) if na and nb else 0.0


class Embedder:
    """Generates embeddings for semantic memory matching.

    Uses the LLM provider's embedding endpoint if available,
    otherwise falls back to a simple bag-of-characters hash
    (deterministic, zero-dependency, surprisingly effective for
    short prompts with overlapping tool names).
    """

    def __init__(self, provider: Any = None):
        self._provider = provider

    async def embed(self, text: str) -> list[float]:
        if self._provider and hasattr(self._provider, "embed"):
            try:
                return await self._provider.embed(text)
            except NotImplementedError:
                pass
        return self._fallback_embed(text)

    @staticmethod
    def _fallback_embed(text: str, dim: int = 128) -> list[float]:
        """Deterministic character-trigram embedding (no external deps)."""
        import hashlib
        vec = [0.0] * dim
        t = text.lower()
        for i in range(len(t) - 2):
            trigram = t[i:i + 3]
            h = int(hashlib.md5(trigram.encode()).hexdigest(), 16) % dim
            vec[h] += 1.0
        norm = math.sqrt(sum(x * x for x in vec)) or 1.0
        return [x / norm for x in vec]


class Memory:
    """Binary-persisted evolutionary memory with vector search."""

    def __init__(
        self,
        path: str | Path = DEFAULT_PATH,
        threshold: float = DEPRECATION_THRESHOLD,
        similarity_threshold: float = SIMILARITY_THRESHOLD,
    ):
        self.path = Path(path)
        self.threshold = threshold
        self.similarity_threshold = similarity_threshold
        self._records: list[LogicRecord] = []
        self._embedder: Embedder | None = None
        if self.path.exists():
            self._load()

    def set_embedder(self, provider: Any) -> None:
        self._embedder = Embedder(provider)

    # ── Persistence ─────────────────────────────────────────────────

    def _load(self) -> None:
        raw = self.path.read_bytes()
        entries = msgpack.unpackb(raw, raw=False)
        self._records = [LogicRecord.model_validate(e) for e in entries]

    def _save(self) -> None:
        data = [r.model_dump() for r in self._records]
        self.path.write_bytes(msgpack.packb(data, use_bin_type=True))

    # ── Vector lookup ───────────────────────────────────────────────

    async def find(self, prompt: str) -> LogicRecord | None:
        if not self._records:
            return None
        embedder = self._embedder or Embedder()
        query_vec = await embedder.embed(prompt)

        best: LogicRecord | None = None
        best_sim = -1.0
        for rec in self._records:
            if not rec.embedding:
                continue
            sim = _cosine_similarity(query_vec, rec.embedding)
            if sim > best_sim:
                best_sim = sim
                best = rec

        if best and best_sim >= self.similarity_threshold:
            return best
        return None

    # ── Store ───────────────────────────────────────────────────────

    async def store(self, prompt: str, graph: ActionGraph) -> LogicRecord:
        embedder = self._embedder or Embedder()
        vec = await embedder.embed(prompt)
        record = LogicRecord(
            logic_id=uuid.uuid4().hex[:12],
            prompt_text=prompt,
            embedding=vec,
            steps=[StepRecord(step=s) for s in graph.steps],
        )
        self._records.append(record)
        self._save()
        return record

    # ── Evolutionary scoring (from single-call prior_scores) ────────

    def auto_score(self, logic_id: str, graph_result: GraphResult) -> LogicRecord | None:
        """Auto-score steps based on execution results (no LLM scores needed)."""
        record = next((r for r in self._records if r.logic_id == logic_id), None)
        if not record:
            return None

        total = 0.0
        for sr in record.steps:
            sid = sr.step.id
            sr.executions += 1
            step_res = next((r for r in graph_result.steps if r.step_id == sid), None)
            if step_res:
                if step_res.status == StepStatus.SUCCESS:
                    auto = 8.0 + min(2.0, 2000.0 / max(step_res.duration_ms, 1))
                elif step_res.status == StepStatus.SKIPPED:
                    auto = 5.0
                else:
                    auto = 2.0
                sr.score = sr.score * 0.6 + auto * 0.4
                if step_res.status == StepStatus.FAILED and step_res.error:
                    sr.notes.append(f"auto: failed — {step_res.error[:100]}")
                    sr.notes = sr.notes[-10:]

            if sr.executions >= 3 and sr.score < self.threshold:
                sr.deprecated = True
                sr.notes.append(
                    f"auto: deprecated (score {sr.score:.1f} < {self.threshold})"
                )
            total += sr.score

        record.avg_score = total / len(record.steps) if record.steps else 0
        record.last_used_at = time.time()
        record.times_used += 1
        self._save()
        return record

    def update_scores(
        self,
        logic_id: str,
        prior_scores: list[StepScore],
        graph_result: GraphResult,
    ) -> LogicRecord | None:
        record = next((r for r in self._records if r.logic_id == logic_id), None)
        if not record:
            return None

        score_map = {s.step_id: s for s in prior_scores}
        total = 0.0

        for sr in record.steps:
            sid = sr.step.id
            sr.executions += 1

            if sid in score_map:
                s = score_map[sid]
                sr.score = sr.score * 0.6 + s.score * 0.4
                if s.note:
                    sr.notes.append(s.note)
                    sr.notes = sr.notes[-10:]
            else:
                # Auto-score from execution result
                step_res = next((r for r in graph_result.steps if r.step_id == sid), None)
                if step_res:
                    auto = 8.0 if step_res.status == StepStatus.SUCCESS else 2.0
                    sr.score = sr.score * 0.6 + auto * 0.4
                    if step_res.status == StepStatus.FAILED:
                        sr.notes.append(f"auto: failed — {step_res.error}")

            if sr.executions >= 3 and sr.score < self.threshold:
                sr.deprecated = True
                sr.notes.append(
                    f"auto: deprecated (score {sr.score:.1f} < {self.threshold})"
                )

            total += sr.score

        record.avg_score = total / len(record.steps) if record.steps else 0
        record.last_used_at = time.time()
        record.times_used += 1
        self._save()
        return record

    # ── Utils ───────────────────────────────────────────────────────

    @property
    def records(self) -> list[LogicRecord]:
        return list(self._records)

    def clear(self) -> None:
        self._records.clear()
        if self.path.exists():
            os.remove(self.path)
