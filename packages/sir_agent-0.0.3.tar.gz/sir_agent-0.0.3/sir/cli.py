"""SIR CLI — Rich terminal interface."""

from __future__ import annotations

import asyncio
import importlib
import sys
from pathlib import Path
from typing import Any

import click
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from sir.core import SIR
from sir.models import GraphResult, StepResult, StepStatus
from sir.tool import ToolSpec

console = Console()

STATUS_STYLE = {
    StepStatus.SUCCESS: ("✓", "green"),
    StepStatus.FAILED: ("✗", "red"),
    StepStatus.SKIPPED: ("⊘", "dim"),
}


def _build_table(steps: list[StepResult], title: str = "Execution") -> Table:
    table = Table(title=title, show_lines=True, expand=True)
    table.add_column("Step", style="cyan", width=6)
    table.add_column("Tool", style="magenta")
    table.add_column("Status", width=8)
    table.add_column("Duration", justify="right", width=10)
    table.add_column("Result / Error")

    for sr in steps:
        icon, style = STATUS_STYLE.get(sr.status, ("?", "yellow"))
        status = Text(f"{icon} {sr.status.value}", style=style)
        dur = f"{sr.duration_ms:.0f}ms" if sr.duration_ms else "—"
        output = str(sr.error or sr.result or "")
        if len(output) > 120:
            output = output[:117] + "..."
        table.add_row(sr.step_id, sr.tool, status, dur, output)

    return table


def _load_tools_from_module(module_path: str) -> list[ToolSpec]:
    """Import a Python file and collect all ToolSpec objects."""
    path = Path(module_path).resolve()
    spec = importlib.util.spec_from_file_location("_sir_tools", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return [v for v in vars(mod).values() if isinstance(v, ToolSpec)]


@click.group()
@click.version_option(package_name="sir-agent")
def cli():
    """SIR — Single-Input-Reasoning CLI"""


@cli.command()
@click.argument("prompt")
@click.option("--tools", "-t", required=True, help="Path to Python file with @tool functions")
@click.option("--model", "-m", default="qwen2.5:14b", help="LLM model name")
@click.option("--provider", "-p", default="ollama", type=click.Choice(["ollama", "openai"]))
@click.option("--memory", default="dags.bin", help="Memory file path")
@click.option("--no-memory", is_flag=True, help="Disable evolutionary memory")
@click.option("--stream", "-s", is_flag=True, help="Stream step results live")
@click.option("--api-key", envvar="OPENAI_API_KEY", default=None, help="API key (OpenAI)")
def run(prompt: str, tools: str, model: str, provider: str, memory: str,
        no_memory: bool, stream: bool, api_key: str | None):
    """Run a prompt through SIR."""
    # Load tools
    tool_list = _load_tools_from_module(tools)
    if not tool_list:
        console.print("[red]No @tool functions found in the module.[/red]")
        raise SystemExit(1)

    console.print(Panel(
        f"[bold]{prompt}[/bold]\n\n"
        f"[dim]Model: {model} | Provider: {provider} | "
        f"Tools: {', '.join(t.name for t in tool_list)} | "
        f"Memory: {'off' if no_memory else memory}[/dim]",
        title="[cyan]SIR[/cyan]",
        border_style="cyan",
    ))

    # Build provider
    llm_provider = _make_provider(provider, model, api_key)
    sir = SIR(
        provider=llm_provider,
        memory_path=None if no_memory else memory,
        enable_memory=not no_memory,
    )

    if stream:
        asyncio.run(_run_stream(sir, prompt, tool_list))
    else:
        asyncio.run(_run_batch(sir, prompt, tool_list))


async def _run_batch(sir: SIR, prompt: str, tools: list[ToolSpec]):
    with console.status("[cyan]LLM planning + executing...[/cyan]", spinner="dots"):
        result = await sir.arun(prompt, tools)
    _print_result(result)


async def _run_stream(sir: SIR, prompt: str, tools: list[ToolSpec]):
    steps: list[StepResult] = []
    final_result: GraphResult | None = None

    with Live(_build_table(steps, "Executing..."), console=console, refresh_per_second=8) as live:
        # First show planning phase
        live.update(Panel("[cyan]LLM planning...[/cyan]", border_style="dim"))

        async for item in sir.arun_stream(prompt, tools):
            if isinstance(item, StepResult):
                steps.append(item)
                live.update(_build_table(steps, "Executing..."))
            elif isinstance(item, GraphResult):
                final_result = item

    if final_result:
        _print_result(final_result)


def _print_result(result: GraphResult):
    console.print()
    console.print(_build_table(result.steps, "Results"))
    console.print()

    meta = (
        f"[dim]Duration: {result.total_duration_ms:.0f}ms | "
        f"Steps: {len(result.steps)} | "
        f"Memory: {'hit' if result.from_memory else 'miss'}[/dim]"
    )
    console.print(meta)

    if result.final_result:
        console.print(Panel(
            str(result.final_result),
            title="[green]Final Result[/green]",
            border_style="green",
        ))


@cli.command()
@click.option("--memory", default="dags.bin", help="Memory file path")
def inspect(memory: str):
    """Inspect the evolutionary memory file."""
    from sir.memory.store import Memory

    mem = Memory(path=memory)
    if not mem.records:
        console.print("[dim]No records in memory.[/dim]")
        return

    for rec in mem.records:
        console.print(Panel(
            f"[bold]Logic:[/bold] {rec.logic_id}\n"
            f"[bold]Prompt:[/bold] {rec.prompt_text[:100]}\n"
            f"[bold]Used:[/bold] {rec.times_used}x | "
            f"[bold]Avg score:[/bold] {rec.avg_score:.1f}",
            title=f"[cyan]{rec.logic_id}[/cyan]",
            border_style="cyan",
        ))

        table = Table(show_lines=True)
        table.add_column("Step", style="cyan")
        table.add_column("Tool", style="magenta")
        table.add_column("Score", justify="right")
        table.add_column("Execs", justify="right")
        table.add_column("Status")
        table.add_column("Notes")

        for sr in rec.steps:
            score_style = "red" if sr.score < 3 else "yellow" if sr.score < 6 else "green"
            status = "[red]DEPRECATED[/red]" if sr.deprecated else "[green]active[/green]"
            notes = "\n".join(sr.notes[-3:]) if sr.notes else "—"
            table.add_row(
                sr.step.id, sr.step.tool,
                Text(f"{sr.score:.1f}", style=score_style),
                str(sr.executions), status, notes,
            )

        console.print(table)
        console.print()


@cli.command()
@click.option("--memory", default="dags.bin", help="Memory file path")
@click.confirmation_option(prompt="Clear all memory?")
def clear(memory: str):
    """Clear the evolutionary memory."""
    from sir.memory.store import Memory
    Memory(path=memory).clear()
    console.print("[green]Memory cleared.[/green]")


@cli.command(name="compile")
@click.argument("prompt")
@click.option("--tools", "-t", required=True, help="Path to Python file with @tool functions")
@click.option("--output", "-o", default="compiled.sirx", help="Output .sirx file path")
@click.option("--model", "-m", default="qwen2.5:14b", help="LLM model name")
@click.option("--provider", "-p", default="ollama", type=click.Choice(["ollama", "openai"]))
@click.option("--api-key", envvar="OPENAI_API_KEY", default=None)
def compile_cmd(prompt: str, tools: str, output: str, model: str, provider: str, api_key: str | None):
    """Compile a prompt into a reusable .sirx DAG (one LLM call, then never again)."""
    tool_list = _load_tools_from_module(tools)
    if not tool_list:
        console.print("[red]No @tool functions found.[/red]")
        raise SystemExit(1)

    llm_provider = _make_provider(provider, model, api_key)
    sir = SIR(provider=llm_provider, enable_memory=False)

    with console.status("[cyan]Compiling DAG...[/cyan]", spinner="dots"):
        compiled = asyncio.run(sir.compile(prompt, tool_list, path=output))

    console.print(f"[green]Compiled[/green] → {output}  ({len(compiled.graph.steps)} steps, hash={compiled.source_hash})")


@cli.command(name="run-compiled")
@click.argument("sirx_path")
@click.option("--tools", "-t", required=True, help="Path to Python file with @tool functions")
def run_compiled_cmd(sirx_path: str, tools: str):
    """Execute a pre-compiled .sirx DAG — zero LLM calls."""
    tool_list = _load_tools_from_module(tools)
    if not tool_list:
        console.print("[red]No @tool functions found.[/red]")
        raise SystemExit(1)

    with console.status("[cyan]Executing compiled DAG...[/cyan]", spinner="dots"):
        result = asyncio.run(SIR.run_compiled(sirx_path, tool_list))

    _print_result(result)
    console.print("[dim]0 LLM calls — pure runtime execution[/dim]")


@cli.command()
@click.option("--host", default="127.0.0.1", help="Host to bind")
@click.option("--port", default=7437, help="Port to bind")
@click.option("--memory", default="dags.bin", help="Memory file path")
def ui(host: str, port: int, memory: str):
    """Launch the SIR web dashboard."""
    try:
        from sir.ui.server import start
    except ImportError as e:
        console.print(f"[red]UI dependencies not installed: {e}\nRun: pip install 'sir-agent[ui]'[/red]")
        raise SystemExit(1)
    console.print(f"[cyan]SIR Dashboard[/cyan] → http://{host}:{port}")
    start(host=host, port=port, memory=memory)


def _make_provider(name: str, model: str, api_key: str | None):
    if name == "openai":
        from sir.providers import OpenAIProvider
        return OpenAIProvider(model=model, api_key=api_key)
    from sir.providers import OllamaProvider
    return OllamaProvider(model=model)


def main():
    cli()


if __name__ == "__main__":
    main()
