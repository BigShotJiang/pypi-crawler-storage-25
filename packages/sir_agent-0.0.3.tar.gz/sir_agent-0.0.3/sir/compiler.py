"""Compile-Once, Run-Anywhere DAG caching.

Serialises an optimised ActionGraph into a binary `.sirx` file (msgpack).
At runtime the compiled DAG is loaded and executed directly — zero LLM calls.
"""

from __future__ import annotations

import hashlib
import time
from pathlib import Path
from typing import Any

import msgpack

from sir.models import ActionGraph, GraphResult

_MAGIC = b"SIRX"
_VERSION = 1


class CompiledDAG:
    """A frozen, LLM-free action graph ready for execution."""

    __slots__ = ("graph", "prompt", "tool_names", "compiled_at", "source_hash")

    def __init__(
        self,
        graph: ActionGraph,
        prompt: str,
        tool_names: list[str],
        compiled_at: float | None = None,
        source_hash: str = "",
    ):
        self.graph = graph
        self.prompt = prompt
        self.tool_names = tool_names
        self.compiled_at = compiled_at or time.time()
        self.source_hash = source_hash

    # ── Serialisation ───────────────────────────────────────────────

    def save(self, path: str | Path) -> Path:
        """Write compiled DAG to a `.sirx` binary file."""
        path = Path(path)
        payload = {
            "v": _VERSION,
            "prompt": self.prompt,
            "tool_names": self.tool_names,
            "compiled_at": self.compiled_at,
            "source_hash": self.source_hash,
            "graph": self.graph.model_dump(),
        }
        data = _MAGIC + msgpack.packb(payload, use_bin_type=True)
        path.write_bytes(data)
        return path

    @classmethod
    def load(cls, path: str | Path) -> CompiledDAG:
        """Load a compiled DAG from a `.sirx` file."""
        path = Path(path)
        raw = path.read_bytes()
        if not raw.startswith(_MAGIC):
            raise ValueError(f"Not a valid .sirx file: {path}")
        payload = msgpack.unpackb(raw[len(_MAGIC):], raw=False)
        if payload.get("v", 0) > _VERSION:
            raise ValueError(f"Unsupported .sirx version {payload['v']}")
        return cls(
            graph=ActionGraph.model_validate(payload["graph"]),
            prompt=payload["prompt"],
            tool_names=payload["tool_names"],
            compiled_at=payload.get("compiled_at", 0),
            source_hash=payload.get("source_hash", ""),
        )


def compile_graph(
    graph: ActionGraph,
    prompt: str,
    tool_names: list[str],
) -> CompiledDAG:
    """Compile an optimised ActionGraph into a frozen executable."""
    source = f"{prompt}:{'|'.join(sorted(tool_names))}"
    return CompiledDAG(
        graph=graph,
        prompt=prompt,
        tool_names=tool_names,
        source_hash=hashlib.sha256(source.encode()).hexdigest()[:16],
    )
