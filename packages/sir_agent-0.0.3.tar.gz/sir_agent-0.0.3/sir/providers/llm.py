"""LLM provider abstraction and implementations."""

from __future__ import annotations

import asyncio
import os
from abc import ABC, abstractmethod
from typing import Any


class LLMProvider(ABC):
    def __init__(self):
        self.last_input_tokens: int = 0
        self.last_output_tokens: int = 0
        self.total_input_tokens: int = 0
        self.total_output_tokens: int = 0

    @abstractmethod
    async def generate(self, messages: list[dict[str, str]], **kwargs: Any) -> str:
        """Send messages and return the raw text response."""

    async def embed(self, text: str) -> list[float]:
        """Generate embedding vector. Override for real embeddings."""
        raise NotImplementedError

    def _track_tokens(self, input_t: int, output_t: int) -> None:
        self.last_input_tokens = input_t
        self.last_output_tokens = output_t
        self.total_input_tokens += input_t
        self.total_output_tokens += output_t


# ── Ollama ──────────────────────────────────────────────────────────

class OllamaProvider(LLMProvider):
    def __init__(self, model: str = "qwen2.5:14b", host: str | None = None,
                 embed_model: str | None = None):
        super().__init__()
        self.model = model
        self.host = host or os.getenv("OLLAMA_HOST")
        self.embed_model = embed_model

    async def generate(self, messages: list[dict[str, str]], **kwargs: Any) -> str:
        from ollama import Client

        def _call() -> str:
            client = Client(host=self.host) if self.host else Client()
            resp = client.chat(model=self.model, messages=messages)
            if isinstance(resp, dict):
                text = resp.get("message", {}).get("content", "")
                self._track_tokens(
                    resp.get("prompt_eval_count", 0) or 0,
                    resp.get("eval_count", 0) or 0,
                )
            else:
                text = resp.message.content
                self._track_tokens(
                    getattr(resp, "prompt_eval_count", 0) or 0,
                    getattr(resp, "eval_count", 0) or 0,
                )
            return text

        return await asyncio.to_thread(_call)

    async def embed(self, text: str) -> list[float]:
        if not self.embed_model:
            raise NotImplementedError("Set embed_model to use Ollama embeddings")
        from ollama import Client

        def _call() -> list[float]:
            client = Client(host=self.host) if self.host else Client()
            resp = client.embed(model=self.embed_model, input=text)
            if isinstance(resp, dict):
                return resp.get("embeddings", [[]])[0]
            return resp.embeddings[0]

        return await asyncio.to_thread(_call)


# ── OpenAI ──────────────────────────────────────────────────────────

class OpenAIProvider(LLMProvider):
    """OpenAI provider. Also works as base for any OpenAI-compatible API."""

    def __init__(self, model: str = "gpt-4o", api_key: str | None = None,
                 base_url: str | None = None, embed_model: str = "text-embedding-3-small"):
        super().__init__()
        self.model = model
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        self.base_url = base_url
        self.embed_model = embed_model

    async def generate(self, messages: list[dict[str, str]], **kwargs: Any) -> str:
        from openai import AsyncOpenAI

        client = AsyncOpenAI(api_key=self.api_key, base_url=self.base_url)
        resp = await client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=kwargs.get("temperature", 0.2),
            response_format={"type": "json_object"},
        )
        if resp.usage:
            self._track_tokens(resp.usage.prompt_tokens or 0, resp.usage.completion_tokens or 0)
        return resp.choices[0].message.content

    async def embed(self, text: str) -> list[float]:
        from openai import AsyncOpenAI

        client = AsyncOpenAI(api_key=self.api_key, base_url=self.base_url)
        resp = await client.embeddings.create(model=self.embed_model, input=text)
        return resp.data[0].embedding


# ── Claude (Anthropic) ──────────────────────────────────────────────

class ClaudeProvider(LLMProvider):
    def __init__(self, model: str = "claude-sonnet-4-20250514",
                 api_key: str | None = None):
        super().__init__()
        self.model = model
        self.api_key = api_key or os.getenv("ANTHROPIC_API_KEY")

    async def generate(self, messages: list[dict[str, str]], **kwargs: Any) -> str:
        from anthropic import AsyncAnthropic

        client = AsyncAnthropic(api_key=self.api_key)
        system = [m["content"] for m in messages if m["role"] == "system"]
        chat = [m for m in messages if m["role"] != "system"]
        resp = await client.messages.create(
            model=self.model,
            max_tokens=kwargs.get("max_tokens", 4096),
            system=system[0] if system else "",
            messages=chat,
        )
        if hasattr(resp, "usage") and resp.usage:
            self._track_tokens(
                getattr(resp.usage, "input_tokens", 0) or 0,
                getattr(resp.usage, "output_tokens", 0) or 0,
            )
        return resp.content[0].text


# ── Gemini (Google) ─────────────────────────────────────────────────

class GeminiProvider(OpenAIProvider):
    """Google Gemini via OpenAI-compatible API."""

    def __init__(self, model: str = "gemini-2.5-flash", api_key: str | None = None):
        super().__init__(
            model=model,
            api_key=api_key or os.getenv("GEMINI_API_KEY"),
            base_url="https://generativelanguage.googleapis.com/v1beta/openai/",
        )


# ── AWS Bedrock ─────────────────────────────────────────────────────

class BedrockProvider(LLMProvider):
    def __init__(self, model: str = "anthropic.claude-sonnet-4-20250514-v1:0",
                 region: str | None = None, bearer_token: str | None = None):
        super().__init__()
        self.model = model
        self.region = region or os.getenv("AWS_REGION", "us-east-1")
        self.bearer_token = bearer_token or os.getenv("AWS_BEARER_TOKEN_BEDROCK")

    async def generate(self, messages: list[dict[str, str]], **kwargs: Any) -> str:
        import boto3
        from botocore.config import Config

        def _call() -> tuple[str, int, int]:
            config = Config(read_timeout=300, connect_timeout=10,
                            retries={"max_attempts": 3, "mode": "adaptive"})
            client_kwargs: dict[str, Any] = {
                "service_name": "bedrock-runtime",
                "region_name": self.region,
                "config": config,
            }
            if self.bearer_token:
                client_kwargs["aws_access_key_id"] = "BEDROCK_API_KEY"
                client_kwargs["aws_secret_access_key"] = self.bearer_token

            client = boto3.client(**client_kwargs)

            system = [{"text": m["content"]} for m in messages if m["role"] == "system"]
            chat = [{"role": m["role"], "content": [{"text": m["content"]}]}
                    for m in messages if m["role"] != "system"]

            req: dict[str, Any] = {
                "modelId": self.model,
                "messages": chat,
                "inferenceConfig": {"maxTokens": kwargs.get("max_tokens", 4096)},
            }
            if system:
                req["system"] = system

            resp = client.converse(**req)
            usage = resp.get("usage", {})
            in_t = usage.get("inputTokens", 0)
            out_t = usage.get("outputTokens", 0)
            for item in resp["output"]["message"]["content"]:
                if "text" in item:
                    return item["text"], in_t, out_t
            raise ValueError("No text in Bedrock response")

        text, in_t, out_t = await asyncio.to_thread(_call)
        self._track_tokens(in_t, out_t)
        return text


# ── OpenRouter ──────────────────────────────────────────────────────

class OpenRouterProvider(OpenAIProvider):
    """OpenRouter — access 200+ models via OpenAI-compatible API."""

    def __init__(self, model: str = "openai/gpt-4o", api_key: str | None = None):
        super().__init__(
            model=model,
            api_key=api_key or os.getenv("OPENROUTER_API_KEY"),
            base_url="https://openrouter.ai/api/v1",
        )


# ── Perplexity ──────────────────────────────────────────────────────

class PerplexityProvider(OpenAIProvider):
    """Perplexity Sonar — OpenAI-compatible API."""

    def __init__(self, model: str = "sonar-pro", api_key: str | None = None):
        super().__init__(
            model=model,
            api_key=api_key or os.getenv("PERPLEXITY_API_KEY"),
            base_url="https://api.perplexity.ai",
        )


# ── Mistral ─────────────────────────────────────────────────────────

class MistralProvider(OpenAIProvider):
    """Mistral AI — OpenAI-compatible API."""

    def __init__(self, model: str = "mistral-large-latest", api_key: str | None = None):
        super().__init__(
            model=model,
            api_key=api_key or os.getenv("MISTRAL_API_KEY"),
            base_url="https://api.mistral.ai/v1",
        )
