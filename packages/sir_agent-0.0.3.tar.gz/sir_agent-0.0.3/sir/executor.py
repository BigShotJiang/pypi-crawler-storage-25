"""Async graph executor — parallelism, fan-out, retry, speculative execution, alternative racing."""

from __future__ import annotations

import asyncio
import time
from typing import Any, AsyncIterator, Callable, Awaitable

from sir.graph import evaluate_condition, resolve_refs, topological_sort
from sir.models import ActionGraph, Alternative, GraphResult, Step, StepResult, StepStatus
from sir.tool import ToolSpec

StepCallback = Callable[[StepResult], Awaitable[None]] | None

# Placeholder for speculative execution — used when a dep hasn't finished yet
_SPECULATIVE_PLACEHOLDER = "<speculative:pending>"


async def execute_graph(
    graph: ActionGraph,
    tools: dict[str, ToolSpec],
    user_prompt: str,
    on_step: StepCallback = None,
    enable_speculation: bool = True,
) -> GraphResult:
    t0 = time.perf_counter()
    results: dict[str, Any] = {}
    failed_ids: set[str] = set()
    step_results: list[StepResult] = []
    speculative_results: dict[str, StepResult] = {}  # step_id → speculative result
    layers = topological_sort(graph.steps)

    for layer_idx, layer in enumerate(layers):
        # Launch speculative execution for the NEXT layer while current runs
        spec_tasks: dict[str, asyncio.Task] = {}
        if enable_speculation and layer_idx + 1 < len(layers):
            next_layer = layers[layer_idx + 1]
            for ns in next_layer:
                if not ns.condition and not ns.foreach and not ns.alternatives:
                    # Only speculate on simple steps with all deps in current+previous layers
                    spec_tasks[ns.id] = asyncio.create_task(
                        _speculative_execute(ns, tools, results)
                    )

        # Execute current layer
        coros = [_execute_step(step, tools, results, failed_ids, on_step) for step in layer]
        layer_results = await asyncio.gather(*coros, return_exceptions=True)

        for sr in layer_results:
            _collect_results(sr, results, failed_ids, step_results)

        # Resolve speculative tasks — check if they can be kept or must be re-run
        for sid, task in spec_tasks.items():
            task.cancel()
            if task.done() and not task.cancelled():
                try:
                    spec_sr = task.result()
                    if isinstance(spec_sr, StepResult) and spec_sr.status == StepStatus.SPECULATIVE:
                        speculative_results[sid] = spec_sr
                except Exception:
                    pass

    final = results.get(graph.final_step) if graph.final_step else None
    # Fallback chain: if designated final_step has no result, walk backwards
    if final is None:
        # Try leaf nodes (steps no one depends on)
        depended_on = set()
        for s in graph.steps:
            depended_on.update(s.depends_on)
        for s in reversed(graph.steps):
            if s.id not in depended_on and s.id in results:
                final = results[s.id]
                break
        # Last resort: last successful result in execution order
        if final is None:
            for sr in reversed(step_results):
                if sr.status == StepStatus.SUCCESS and sr.result is not None:
                    final = sr.result
                    break
    return GraphResult(
        prompt=user_prompt,
        steps=step_results,
        final_result=final,
        total_duration_ms=(time.perf_counter() - t0) * 1000,
    )


async def execute_graph_stream(
    graph: ActionGraph,
    tools: dict[str, ToolSpec],
    user_prompt: str,
) -> AsyncIterator[StepResult]:
    results: dict[str, Any] = {}
    failed_ids: set[str] = set()
    layers = topological_sort(graph.steps)

    for layer in layers:
        coros = [_execute_step(step, tools, results, failed_ids) for step in layer]
        layer_results = await asyncio.gather(*coros, return_exceptions=True)
        for sr in layer_results:
            if isinstance(sr, list):
                successes = [s.result for s in sr if s.status == StepStatus.SUCCESS]
                if successes and sr:
                    results[sr[0].step_id] = successes
                for s in sr:
                    if s.status in (StepStatus.FAILED, StepStatus.SKIPPED):
                        failed_ids.add(s.step_id)
                    yield s
            elif isinstance(sr, StepResult):
                _update_tracking(sr, results, failed_ids)
                yield sr


def _collect_results(sr, results, failed_ids, step_results):
    if isinstance(sr, list):
        step_results.extend(sr)
        # Foreach results: collect all successes into a list under the step_id
        successes = [s.result for s in sr if s.status == StepStatus.SUCCESS]
        if successes and sr:
            results[sr[0].step_id] = successes
        for s in sr:
            if s.status in (StepStatus.FAILED, StepStatus.SKIPPED):
                failed_ids.add(s.step_id)
    elif isinstance(sr, StepResult):
        step_results.append(sr)
        _update_tracking(sr, results, failed_ids)
    else:
        step_results.append(StepResult(
            step_id="?", tool="?", args={},
            status=StepStatus.FAILED, error=str(sr),
        ))


def _update_tracking(sr: StepResult, results: dict, failed_ids: set):
    if sr.status == StepStatus.SUCCESS:
        results[sr.step_id] = sr.result
    elif sr.status in (StepStatus.FAILED, StepStatus.SKIPPED):
        failed_ids.add(sr.step_id)
        failed_ids.add(sr.step_id)


# ── Speculative execution ───────────────────────────────────────────

async def _speculative_execute(
    step: Step,
    tools: dict[str, ToolSpec],
    results: dict[str, Any],
) -> StepResult:
    """Execute a step speculatively with placeholder values for missing deps."""
    tool_fn = tools.get(step.tool)
    if not tool_fn:
        return StepResult(
            step_id=step.id, tool=step.tool, args=step.args,
            status=StepStatus.FAILED, error="Unknown tool",
        )

    # Build speculative args — use real results where available, placeholders otherwise
    spec_results = {**results}
    for dep in step.depends_on:
        if dep not in spec_results:
            spec_results[dep] = _SPECULATIVE_PLACEHOLDER

    resolved = resolve_refs(step.args, spec_results)

    # Don't execute if any arg still has a placeholder
    if _has_placeholder(resolved):
        return StepResult(
            step_id=step.id, tool=step.tool, args=resolved,
            status=StepStatus.SPECULATIVE, speculative=True,
        )

    t0 = time.perf_counter()
    try:
        result = await tool_fn(**resolved)
        return StepResult(
            step_id=step.id, tool=step.tool, args=resolved,
            status=StepStatus.SPECULATIVE, result=result,
            duration_ms=(time.perf_counter() - t0) * 1000,
            speculative=True,
        )
    except Exception as exc:
        return StepResult(
            step_id=step.id, tool=step.tool, args=resolved,
            status=StepStatus.FAILED, error=str(exc), speculative=True,
        )


def _has_placeholder(value: Any) -> bool:
    if isinstance(value, str):
        return _SPECULATIVE_PLACEHOLDER in value
    if isinstance(value, dict):
        return any(_has_placeholder(v) for v in value.values())
    if isinstance(value, list):
        return any(_has_placeholder(v) for v in value)
    return False


# ── Alternative racing (DAG branching) ──────────────────────────────

async def _race_alternatives(
    step: Step,
    tools: dict[str, ToolSpec],
    results: dict[str, Any],
    on_step: StepCallback = None,
) -> StepResult:
    """Run the primary tool + all alternatives in parallel, pick winner by select strategy."""
    candidates: list[tuple[str, dict[str, Any], ToolSpec]] = []

    # Primary
    tool_fn = tools.get(step.tool)
    if tool_fn:
        candidates.append((step.tool, step.args, tool_fn))

    # Alternatives
    for alt in step.alternatives:
        alt_fn = tools.get(alt.tool)
        if alt_fn:
            candidates.append((alt.tool, alt.args, alt_fn))

    if not candidates:
        return StepResult(
            step_id=step.id, tool=step.tool, args=step.args,
            status=StepStatus.FAILED, error="No valid tools for racing",
        )

    async def _run_candidate(tool_name: str, args: dict, fn: ToolSpec) -> StepResult:
        resolved = resolve_refs(args, results)
        t0 = time.perf_counter()
        try:
            result = await fn(**resolved)
            return StepResult(
                step_id=step.id, tool=tool_name, args=resolved,
                status=StepStatus.SUCCESS, result=result,
                duration_ms=(time.perf_counter() - t0) * 1000,
            )
        except Exception as exc:
            return StepResult(
                step_id=step.id, tool=tool_name, args=resolved,
                status=StepStatus.FAILED, error=str(exc),
                duration_ms=(time.perf_counter() - t0) * 1000,
            )

    strategy = (step.select or "fastest").lower()

    if strategy == "fastest":
        # Return first successful result
        tasks = [asyncio.create_task(_run_candidate(*c)) for c in candidates]
        winner = None
        for coro in asyncio.as_completed(tasks):
            sr = await coro
            if sr.status == StepStatus.SUCCESS:
                winner = sr
                # Cancel remaining
                for t in tasks:
                    t.cancel()
                break
        if not winner:
            # All failed — return last
            winner = sr
    else:
        # Run all, pick by strategy
        all_results = await asyncio.gather(*[_run_candidate(*c) for c in candidates])
        successes = [r for r in all_results if r.status == StepStatus.SUCCESS]
        if not successes:
            winner = all_results[0]
        elif strategy == "shortest":
            winner = min(successes, key=lambda r: len(str(r.result or "")))
        elif strategy == "longest":
            winner = max(successes, key=lambda r: len(str(r.result or "")))
        else:
            winner = successes[0]

    if on_step and winner:
        await on_step(winner)
    return winner


# ── Main step execution ─────────────────────────────────────────────

async def _execute_step(
    step: Step,
    tools: dict[str, ToolSpec],
    results: dict[str, Any],
    failed_ids: set[str],
    on_step: StepCallback = None,
) -> StepResult | list[StepResult]:
    # Skip if any dependency failed
    failed_deps = [d for d in step.depends_on if d in failed_ids]
    if failed_deps:
        sr = StepResult(
            step_id=step.id, tool=step.tool, args=step.args,
            status=StepStatus.SKIPPED,
            error=f"Skipped: dependency {', '.join(failed_deps)} failed",
        )
        if on_step:
            await on_step(sr)
        return sr

    # Condition check
    if step.condition and not evaluate_condition(step.condition, results):
        sr = StepResult(
            step_id=step.id, tool=step.tool, args=step.args,
            status=StepStatus.SKIPPED,
        )
        if on_step:
            await on_step(sr)
        return sr

    # DAG branching — race alternatives
    if step.alternatives:
        return await _race_alternatives(step, tools, results, on_step)

    # Unknown tool
    tool_fn = tools.get(step.tool)
    if not tool_fn:
        sr = StepResult(
            step_id=step.id, tool=step.tool, args=step.args,
            status=StepStatus.FAILED, error=f"Unknown tool: {step.tool}",
        )
        if on_step:
            await on_step(sr)
        return sr

    # Fan-out (foreach)
    if step.foreach:
        if isinstance(step.foreach, list):
            # Inline array: foreach over literal values
            items = step.foreach
        elif isinstance(step.foreach, str) and step.foreach.startswith("$"):
            ref_id = step.foreach[1:].split(".")[0]
            items = results.get(ref_id, [])
            if not isinstance(items, list):
                items = [items]
        else:
            items = [step.foreach]
        if not items:
            sr = StepResult(
                step_id=step.id, tool=step.tool, args=step.args,
                status=StepStatus.SKIPPED, error="foreach: empty list",
            )
            if on_step:
                await on_step(sr)
            return [sr]
        coros = [
            _run_with_retry(step, tool_fn, {**results, "$item": item}, on_step)
            for item in items
        ]
        return await asyncio.gather(*coros)

    return await _run_with_retry(step, tool_fn, results, on_step)


async def _run_with_retry(
    step: Step,
    tool_fn: ToolSpec,
    results: dict[str, Any],
    on_step: StepCallback = None,
) -> StepResult:
    resolved = resolve_refs(step.args, results)
    last_err: str | None = None

    for attempt in range(step.retry + 1):
        t0 = time.perf_counter()
        try:
            result = await tool_fn(**resolved)
            sr = StepResult(
                step_id=step.id, tool=step.tool, args=resolved,
                status=StepStatus.SUCCESS, result=result,
                duration_ms=(time.perf_counter() - t0) * 1000,
            )
            if on_step:
                await on_step(sr)
            return sr
        except Exception as exc:
            last_err = f"[attempt {attempt + 1}] {exc}"
            if attempt < step.retry:
                await asyncio.sleep(0.5 * (attempt + 1))

    sr = StepResult(
        step_id=step.id, tool=step.tool, args=resolved,
        status=StepStatus.FAILED, error=last_err,
    )
    if on_step:
        await on_step(sr)
    return sr
