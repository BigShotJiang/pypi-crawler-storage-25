"""Self-Healing DAGs — targeted micro-DAG repair for failed branches.

When steps fail, SIR generates a minimal repair DAG in one additional LLM
call that replaces only the broken branch.  Successfully healed results are
injected back so downstream steps can proceed.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from sir.graph import parse_graph, validate_graph
from sir.models import ActionGraph, GraphResult, Step, StepResult, StepStatus
from sir.tool import ToolSpec

logger = logging.getLogger("sir")

_HEAL_SYSTEM = """\
You are SIR-Heal, a repair engine. A DAG execution had failures. \
Generate a MINIMAL micro-DAG that replaces ONLY the failed steps to produce their expected outputs.

Available tools: {tools_json}

Already succeeded (use these results via $sN.result):
{succeeded}

Failed steps to repair:
{failed}

Downstream steps that need the repaired outputs:
{downstream}

Output ONLY valid compact JSON — same format as SIR:
{{"s":[{{"id":"<same id as failed step>","t":"<tool>","a":{{}}}}],"fs":"<final>"}}

Rules:
- Reuse the SAME step IDs as the failed steps so downstream refs still work.
- You may add NEW intermediate steps (use ids like "h1","h2",...).
- Use $sN.result to reference already-succeeded steps.
- Minimise steps. Do NOT re-plan the entire graph.
- Output MUST be compact JSON, no markdown, no explanation.\
"""


def compile_heal_prompt(
    tools: list[ToolSpec],
    result: GraphResult,
    graph: ActionGraph,
) -> list[dict[str, str]] | None:
    """Build a healing prompt from execution results. Returns None if nothing to heal."""
    failed = [sr for sr in result.steps if sr.status == StepStatus.FAILED]
    if not failed:
        return None

    succeeded = {sr.step_id: sr.result for sr in result.steps if sr.status == StepStatus.SUCCESS}
    failed_ids = {sr.step_id for sr in failed}

    # Find downstream steps that were skipped because of the failures
    downstream = [
        s for s in graph.steps
        if s.id not in failed_ids
        and s.id not in succeeded
        and any(d in failed_ids for d in s.depends_on)
    ]

    if not failed:
        return None

    tools_compact = json.dumps(
        [{"n": t.name, "d": t.description,
          "p": {k: v["type"] for k, v in t.schema.get("properties", {}).items()}}
         for t in tools],
        separators=(",", ":"),
    )

    succeeded_text = "\n".join(
        f"  {sid}: {str(val)[:300]}" for sid, val in succeeded.items()
    ) or "  (none)"

    failed_text = "\n".join(
        f"  {sr.step_id} (tool={sr.tool}, args={json.dumps(sr.args, separators=(',',':'))}): {sr.error}"
        for sr in failed
    )

    downstream_text = "\n".join(
        f"  {s.id} (tool={s.tool}, depends_on={s.depends_on})"
        for s in downstream
    ) or "  (none)"

    system = _HEAL_SYSTEM.format(
        tools_json=tools_compact,
        succeeded=succeeded_text,
        failed=failed_text,
        downstream=downstream_text,
    )
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": "Repair the failed steps."},
    ]


def merge_healed_results(
    original_results: list[StepResult],
    healed_results: list[StepResult],
) -> list[StepResult]:
    """Replace failed steps with healed ones, keep everything else."""
    healed_map = {sr.step_id: sr for sr in healed_results if sr.status == StepStatus.SUCCESS}
    merged = []
    for sr in original_results:
        if sr.step_id in healed_map:
            healed_sr = healed_map.pop(sr.step_id)
            healed_sr.healed = True
            merged.append(healed_sr)
        else:
            merged.append(sr)
    # Append any new intermediate healing steps (h1, h2, ...)
    for sr in healed_results:
        if sr.step_id in healed_map:
            sr.healed = True
            merged.append(sr)
    return merged
