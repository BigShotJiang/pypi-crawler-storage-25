"""Real tools for testing SIR with actual HTTP requests and processing."""

import json
import urllib.request
import urllib.parse
from sir import tool


@tool
def fetch_url(url: str) -> str:
    """Fetch the content of a URL and return the text."""
    req = urllib.request.Request(url, headers={"User-Agent": "SIR-Agent/1.0"})
    with urllib.request.urlopen(req, timeout=15) as resp:
        raw = resp.read().decode("utf-8", errors="replace")[:5000]
        # Strip HTML tags for cleaner output
        import re
        text = re.sub(r'<script[^>]*>.*?</script>', '', raw, flags=re.DOTALL)
        text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL)
        text = re.sub(r'<[^>]+>', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text[:3000]


@tool
def search_wikipedia(query: str) -> str:
    """Search Wikipedia and return a summary of the top result."""
    q = urllib.parse.quote(query)
    url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{q}"
    req = urllib.request.Request(url, headers={"User-Agent": "SIR-Agent/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data.get("extract", "No summary found.")
    except Exception:
        url2 = f"https://en.wikipedia.org/w/api.php?action=opensearch&search={q}&limit=1&format=json"
        req2 = urllib.request.Request(url2, headers={"User-Agent": "SIR-Agent/1.0"})
        with urllib.request.urlopen(req2, timeout=10) as resp2:
            results = json.loads(resp2.read().decode("utf-8"))
            if results[1]:
                return f"Found: {results[1][0]} — {results[3][0] if results[3] else ''}"
            return "No results found."


@tool
def get_weather(city: str) -> str:
    """Get current weather for a city using wttr.in."""
    c = urllib.parse.quote(city)
    url = f"https://wttr.in/{c}?format=j1"
    req = urllib.request.Request(url, headers={"User-Agent": "SIR-Agent/1.0"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        data = json.loads(resp.read().decode("utf-8"))
        current = data.get("current_condition", [{}])[0]
        desc = current.get("weatherDesc", [{}])[0].get("value", "unknown")
        temp = current.get("temp_C", "?")
        humidity = current.get("humidity", "?")
        return f"{city}: {desc}, {temp}°C, humidity {humidity}%"


@tool
def count_words(text: str) -> str:
    """Count the number of words in a text."""
    words = len(text.split())
    chars = len(text)
    sentences = text.count(".") + text.count("!") + text.count("?")
    return f"Words: {words}, Characters: {chars}, Sentences: {sentences}"


@tool
def extract_keywords(text: str) -> str:
    """Extract the most frequent meaningful words from text."""
    stop = {"the","a","an","is","are","was","were","be","been","being","have","has",
            "had","do","does","did","will","would","could","should","may","might",
            "shall","can","to","of","in","for","on","with","at","by","from","as",
            "into","through","during","before","after","and","but","or","nor","not",
            "so","yet","both","either","neither","each","every","all","any","few",
            "more","most","other","some","such","no","only","own","same","than",
            "too","very","just","it","its","this","that","these","those","i","me",
            "my","we","our","you","your","he","him","his","she","her","they","them"}
    words = [w.lower().strip(".,!?;:\"'()[]") for w in text.split()]
    words = [w for w in words if w and len(w) > 2 and w not in stop]
    freq = {}
    for w in words:
        freq[w] = freq.get(w, 0) + 1
    top = sorted(freq.items(), key=lambda x: -x[1])[:10]
    return ", ".join(f"{w} ({c})" for w, c in top)


@tool
def combine_texts(text1: str, text2: str) -> str:
    """Combine two texts into a structured report."""
    return f"--- Section 1 ---\n{text1}\n\n--- Section 2 ---\n{text2}"
