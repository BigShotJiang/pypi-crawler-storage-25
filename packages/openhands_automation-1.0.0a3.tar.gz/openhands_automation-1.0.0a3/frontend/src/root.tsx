import { Links, Meta, Outlet, Scripts, ScrollRestoration } from "react-router";
import type { MetaFunction } from "react-router";
import "./tailwind.css";
import "./index.css";
import React from "react";
import { Toaster } from "react-hot-toast";
import { TOAST_OPTIONS } from "./utils/custom-toast-handlers";

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <Meta />
        <Links />
      </head>
      <body>
        {children}
        <ScrollRestoration />
        <Scripts />
        <Toaster toastOptions={TOAST_OPTIONS} />
      </body>
    </html>
  );
}

export const meta: MetaFunction = () => [
  { title: "OpenHands Automations" },
  { name: "description", content: "Manage your OpenHands automations" },
];

export default function App() {
  return <Outlet />;
}
