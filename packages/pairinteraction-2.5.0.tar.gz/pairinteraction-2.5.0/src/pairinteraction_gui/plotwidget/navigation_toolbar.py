# SPDX-FileCopyrightText: 2025 PairInteraction Developers
# SPDX-License-Identifier: LGPL-3.0-or-later
from __future__ import annotations

from typing import TYPE_CHECKING, Any

from matplotlib.backends.backend_qt import NavigationToolbar2QT as NavigationToolbar

if TYPE_CHECKING:
    from collections.abc import Callable

    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
    from PySide6.QtWidgets import QWidget


class CustomNavigationToolbar(NavigationToolbar):
    """Custom navigation toolbar for matplotlib figures.

    See Also:
    https://stackoverflow.com/questions/12695678/how-to-modify-the-navigation-toolbar-easily-in-a-matplotlib-figure-window/15549675#15549675

    """

    toolitems = (
        ("Zoom", "Zoom to rectangle\nx/y fixes axis", "zoom_to_rect", "zoom"),
        ("Pan", "Left button pans, Right button zooms\nx/y fixes axis, CTRL fixes aspect", "move", "pan"),
        ("Home", "Reset original view", "home", "home"),
    )  # type: ignore [assignment]

    def __init__(self, canvas: FigureCanvasQTAgg, parent: QWidget | None = None) -> None:
        """Initialize the custom navigation toolbar."""
        super().__init__(canvas, parent, coordinates=False)
        self._home_callbacks: list[Callable[[], None]] = []

    def home(self, *args: Any) -> None:
        """Reset view and notify registered callbacks."""
        super().home(*args)
        for cb in self._home_callbacks:
            cb()

    def reset_home_view(self) -> None:
        """Reset the home view to the current axes state.

        I.e. if a user afterwards clicks the home/reset button, the view will be reset to the current view.
        """
        self.update()
        self.push_current()
