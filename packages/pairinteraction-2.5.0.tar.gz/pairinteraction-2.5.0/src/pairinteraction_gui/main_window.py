# SPDX-FileCopyrightText: 2025 PairInteraction Developers
# SPDX-License-Identifier: LGPL-3.0-or-later
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, TypeVar

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QAction, QActionGroup, QIcon, QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QDockWidget,
    QMainWindow,
    QMessageBox,
    QSizePolicy,
    QStatusBar,
    QToolBar,
    QWidget,
)

import pairinteraction
from pairinteraction import Database
from pairinteraction.cli import download_databases
from pairinteraction_gui.app import Application
from pairinteraction_gui.config.base_config import BaseConfig
from pairinteraction_gui.page import (
    LifetimesPage,
    OneAtomPage,
    TwoAtomsPage,
)
from pairinteraction_gui.page.base_page import SimulationPage
from pairinteraction_gui.qobjects import NamedStackedWidget
from pairinteraction_gui.settings import SettingsManager
from pairinteraction_gui.theme import theme_manager
from pairinteraction_gui.worker import MultiThreadWorker

if TYPE_CHECKING:
    from pathlib import Path

    from PySide6.QtCore import QObject
    from PySide6.QtGui import QCloseEvent

    from pairinteraction_gui.page import BasePage

    ChildType = TypeVar("ChildType", bound=QObject)

logger = logging.getLogger(__name__)


class MainWindow(QMainWindow):
    """Main window for the PairInteraction GUI application."""

    def __init__(self, *, cache_dir: Path | None = None, enable_theme_hot_reload: bool = False) -> None:
        """Initialize the main window."""
        super().__init__()
        self._theme_hot_reload_enabled = enable_theme_hot_reload

        self.setWindowTitle(f"PairInteraction v{pairinteraction.__version__}")
        self.resize(1200, 800)

        self.statusbar = self.setup_statusbar()
        self.dockwidget = self.setup_dockwidget()

        self.stacked_pages = self.setup_stacked_pages()
        self.toolbar = self.setup_toolbar()

        self.settings_manager = SettingsManager(cache_dir)
        self.restore_settings()

        self.init_keyboard_shortcuts()
        self.connect_signals()

        self.apply_theme()
        if enable_theme_hot_reload:
            theme_manager.enable_hot_reload()
            theme_manager.signals.themes_reloaded.connect(self.apply_theme)

    def connect_signals(self) -> None:
        """Connect signals to slots."""
        self.signals = Application.instance().signals
        self.signals.ask_download_database.connect(self.ask_download_database)

    def apply_theme(self) -> None:
        """Apply the current main application theme."""
        app = Application.instance()
        app.setPalette(theme_manager.get_palette())
        self.setStyleSheet(theme_manager.get_theme())

    def findChild(  # type: ignore [override] # explicitly override type hints
        self, type_: type[ChildType], name: str, options: Qt.FindChildOption | None = None
    ) -> ChildType:
        if options is None:
            options = Qt.FindChildOption.FindChildrenRecursively
        return super().findChild(type_, name, options)  # type: ignore [return-value] # explicitly override type hints

    def setup_statusbar(self) -> QStatusBar:
        """Set up the status bar.

        The status bar message is set to "Ready" by default.
        It can be updated with a new message by either from the main window instance:
            `self.statusbar.showMessage("Ready", timeout=0)`
        or from outside the main window instance:
            `QApplication.sendEvent(self, QStatusTipEvent("Ready"))`
        """
        statusbar = QStatusBar(self)
        statusbar.setFixedHeight(25)
        self.setStatusBar(statusbar)
        statusbar.showMessage("Ready", timeout=0)
        return statusbar

    def setup_dockwidget(self) -> QDockWidget:
        """Create a configuration dock widget for the main window."""
        dockwidget = QDockWidget()
        dockwidget.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea)
        dockwidget.setTitleBarWidget(QWidget())  # This removes the title bar

        dockwidget.setMinimumWidth(375)
        dockwidget.setVisible(False)
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, dockwidget)
        return dockwidget

    def setup_stacked_pages(self) -> NamedStackedWidget[BasePage]:
        """Set up the different pages for each toolbar option."""
        stacked_pages = NamedStackedWidget["BasePage"]()
        self.setCentralWidget(stacked_pages)

        stacked_pages.addNamedWidget(OneAtomPage(), "OneAtomPage")
        stacked_pages.addNamedWidget(TwoAtomsPage(), "TwoAtomsPage")
        stacked_pages.addNamedWidget(LifetimesPage(), "LifetimesPage")
        # stacked_pages.addNamedWidget(C6Page(), "C6Page")

        # stacked_pages.addNamedWidget(SettingsPage(), "SettingsPage")
        # stacked_pages.addNamedWidget(AboutPage(), "AboutPage")
        return stacked_pages

    def setup_toolbar(self) -> QToolBar:
        """Set up the toolbar with icon buttons."""
        toolbar = QToolBar("Sidebar")
        toolbar.setObjectName("SidebarToolBar")
        toolbar.setMovable(False)
        toolbar.setOrientation(Qt.Orientation.Vertical)
        toolbar.setIconSize(QSize(32, 32))
        toolbar.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonIconOnly)

        toolbar_group = QActionGroup(self)
        toolbar_group.setExclusive(True)

        for name, page in self.stacked_pages.items():
            # add a spacer widget
            if name == "about":
                spacer_widget = QWidget()
                spacer_widget.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
                toolbar.addWidget(spacer_widget)

            action = QAction(self)
            action.setObjectName(name)
            action.setText(page.title)
            action.setToolTip(page.tooltip)
            action.setCheckable(True)
            if page.icon_path:
                action.setIcon(QIcon(str(page.icon_path)))

            toolbar.addAction(action)
            toolbar_group.addAction(action)

            action.triggered.connect(lambda checked, name=name: self.stacked_pages.setCurrentNamedWidget(name))

        default_page = "OneAtomPage"
        self.findChild(QAction, default_page).setChecked(True)
        self.stacked_pages.setCurrentNamedWidget(default_page)

        self.addToolBar(Qt.ToolBarArea.LeftToolBarArea, toolbar)

        return toolbar

    def init_keyboard_shortcuts(self) -> None:
        """Initialize keyboard shortcuts."""
        # Add Ctrl+W shortcut to close the window
        close_shortcut = QShortcut(QKeySequence("Ctrl+W"), self)
        close_shortcut.activated.connect(lambda: logger.info("Ctrl+W detected. Shutting down gracefully..."))
        close_shortcut.activated.connect(self.close)

    def save_settings(self) -> None:
        """Save all interactive widget state to disk."""
        for page_name, page in self.stacked_pages.items():
            if not isinstance(page, SimulationPage):
                continue
            attr_dict = {name: attr for name, attr in vars(page).items() if isinstance(attr, BaseConfig)}
            for name, widget in attr_dict.items():
                self.settings_manager.save_widget_state(widget, f"{page_name}/{name}")

    def restore_settings(self) -> None:
        """Restore all interactive widget state from disk."""
        for page_name, page in self.stacked_pages.items():
            if not isinstance(page, SimulationPage):
                continue
            attr_dict = {name: attr for name, attr in vars(page).items() if isinstance(attr, BaseConfig)}
            for name, widget in attr_dict.items():
                self.settings_manager.restore_widget_state(widget, f"{page_name}/{name}")

    def closeEvent(self, event: QCloseEvent) -> None:
        """Make sure to also call Application.quit() when closing the window."""
        logger.debug("Close event triggered.")
        self.save_settings()
        Application.quit()
        event.accept()

    def ask_download_database(self, species: str) -> bool:
        msg_box = QMessageBox()
        msg_box.setWindowTitle("Download missing database tables?")
        msg_box.setText(f"Database tables for {species} not found.")
        msg_box.setInformativeText("Would you like to download the missing database tables?")
        msg_box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)

        download = msg_box.exec() == QMessageBox.StandardButton.Yes
        if download:
            self.statusbar.showMessage("Downloading database table ...", timeout=0)

            worker = MultiThreadWorker(lambda: download_databases([species]))
            worker.enable_busy_indicator(self.stacked_pages.currentWidget())

            msg = "Successfully downloaded database table for " + species
            worker.signals.result.connect(lambda _result: self.statusbar.showMessage(msg, timeout=0))
            worker.signals.result.connect(lambda _result: setattr(Database, "_global_database", None))
            page = self.stacked_pages.currentWidget()
            if isinstance(page, SimulationPage):
                ket_config = page.ket_config
                for i in range(ket_config.n_atoms):
                    worker.signals.result.connect(
                        lambda _, atom=i: ket_config.signal_species_changed.emit(atom, ket_config.get_species(atom))
                    )
            worker.start()

        return download
