# SPDX-FileCopyrightText: 2024 PairInteraction Developers
# SPDX-License-Identifier: LGPL-3.0-or-later

# ruff: noqa: N802, N806

from __future__ import annotations

import math
from typing import TYPE_CHECKING, Literal, TypeVar

import numpy as np
import scipy.constants as const
from numba import njit
from scipy.integrate import quad

from pairinteraction.green_tensor.bessel_function import (
    cached_bessel_function_0,
    cached_bessel_function_1,
    cached_bessel_function_2,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from pairinteraction.units import NDArray

    Entries = Literal["xx", "xy", "xz", "yx", "yy", "yz", "zx", "zy", "zz"]

    from typing_extensions import ParamSpec

    P = ParamSpec("P")
    R = TypeVar("R")

    def njit(cache: bool) -> Callable[[Callable[P, R]], Callable[P, R]]: ...


__all__ = ["dynamic_green_tensor_homogeneous", "dynamic_green_tensor_scattered"]


def dynamic_green_tensor_homogeneous(
    pos1: NDArray, pos2: NDArray, omega: float, epsilon0: complex, *, only_real_part: bool = False
) -> NDArray:
    r"""Homogeneous Green Tensor for two atoms in cartesian coordinates in an infinite homogeneous medium.

    The function used is from equation 2 of the paper:
    "Dispersionless subradiant photon storage in one-dimensional emitter chains"
    https://doi.org/10.1103/PhysRevA.108.L051702

    We calculate the scaled Green Tensor, i.e.
    .. math::
        \frac{\omega^2}{\hbar \epsilon_0 c^2} G(r_\alpha, r_\beta, \omega)

    Args:
        pos1: Position vector of atom A in meters
        pos2: Position vector of atom B in meters
        omega: Angular frequency (i.e. 2*pi*f) in 1/s
        epsilon0: Electric permittivity of the medium (dimensionless, complex)
        only_real_part: If True, only the real part of the Green tensor is calculated (default: False)

    Returns: The 3x3 scaled homogeneous Green Tensor (general complex values) (m^(-3) [hbar]^(-1) [epsilon_0]^(-1))
        :math:`\omega^2 / (\hbar \epsilon_0 c^2) G(r_\alpha, r_\beta, \omega)`

    """
    k_vac = omega / const.c  # magnitude of wave vector in vacuum
    k0 = k_vac * np.sqrt(epsilon0)  # magnitude of wave vector in medium with permittivity epsilon0
    distance_vec = pos2 - pos1
    distance = np.linalg.norm(distance_vec)

    # this is missing a 1/k0**2 compared to the paper, we absorb this in the scaled prefactor, see line below
    prefactor = np.exp(1j * k0 * distance) / (4 * np.pi * distance**3)
    prefactor *= 1 / (epsilon0 * const.epsilon_0 * const.hbar)  # epsilon0 from missing k0^2 compared to omega^2/c^2
    prefactor *= -1  # minus sign from H = - \hbar \sum V_{\alpha\beta} ...

    result: NDArray = prefactor * (
        (k0**2 * distance**2 + 1j * k0 * distance - 1) * np.eye(3)
        + (-(k0**2) * distance**2 - 3j * k0 * distance + 3) * np.outer(distance_vec, distance_vec) / distance**2
    )

    if only_real_part:
        return np.real(result)
    return result


def dynamic_green_tensor_scattered(
    pos1: NDArray,
    pos2: NDArray,
    z1: float,
    z2: float,
    omega: float,
    epsilon0: complex,
    epsilon1: complex,
    epsilon2: complex,
    *,
    only_real_part: bool = False,
) -> NDArray:
    """Assemble the total scattering Green tensor.

    Args:
        pos1: Position vector of atom A (m)
        pos2: Position vector of atom B (m)
        z1: z-coordinate of the first surface (m)
        z2: z-coordinate of the second surface (m)
        omega: Angular frequency (i.e. 2*pi*f) in 1/s
        epsilon0: Electric permittivity of the medium between the two surfaces (dimensionless, complex)
        epsilon1: Electric permittivity of the upper medium (dimensionless, complex)
        epsilon2: Electric permittivity of the lower medium (dimensionless, complex)
        only_real_part: If True, only the real part of the Green tensor is calculated (default: False)

    Returns: The 3x3 Scattering Green Tensor (general complex values) (1/m)

    """
    if z1 > z2:
        # Ensure z1 is the lower surface and z2 is the upper surface
        z1, z2 = z2, z1
        epsilon1, epsilon2 = epsilon2, epsilon1
    if not (z1 < pos1[2] < z2 and z1 < pos2[2] < z2):
        raise ValueError("Both atoms must be located between the two surfaces (i.e. z1 < z_atom < z2).")

    distance = pos2 - pos1
    height = abs(z1 - z2)

    rho = np.sqrt(distance[0] ** 2 + distance[1] ** 2)
    phi = np.atan2(distance[1], distance[0]) if rho != 0 else 0

    z_ges = pos1[2] + pos2[2] - 2 * min(z1, z2)
    z_diff = pos1[2] - pos2[2]

    gt_scattered = np.zeros((3, 3), dtype=complex)
    for i, ix in enumerate(["x", "y", "z"]):
        for j, jx in enumerate(["x", "y", "z"]):
            entry: Entries = ix + jx  # type: ignore [assignment]
            g_ij_elliptic = elliptic_integral(
                omega,
                height,
                rho,
                phi,
                epsilon0,
                epsilon1,
                epsilon2,
                z_ges,
                z_diff,
                entry,
                only_real_part=only_real_part,
            )
            g_ij_real = real_axis_integral(
                omega,
                height,
                rho,
                phi,
                epsilon0,
                epsilon1,
                epsilon2,
                z_ges,
                z_diff,
                entry,
                only_real_part=only_real_part,
            )
            # prefactor see comment in dynamic_green_tensor_homogeneous
            prefactor = -1 / (epsilon0 * const.epsilon_0 * const.hbar)
            value = prefactor * (g_ij_elliptic + g_ij_real)
            gt_scattered[i][j] = value

    return gt_scattered


@njit(cache=True)
def branch(epsilon: complex, k: float, k_rho: complex) -> complex:
    """Calculate the perpendicular wave vector component with positive imaginary part.

    Args:
        epsilon: Electric permittivity of the medium (dimensionless, complex)
        k: Magnitude of wave number in vacuum (1/m)
        k_rho: In-plane wave vector component (1/m)

    Returns: The perpendicular wave vector component (1/m)

    """
    return np.sqrt(epsilon * k**2 - k_rho**2 + 0j)  # type: ignore [no-any-return]


"""The following functions are used from Appendix B of the paper:
"Modified dipole-dipole interaction and dissipation in an atomic ensemble near surfaces"
https://doi.org/10.1103/PhysRevA.97.053841
and are needed to calculate the scattering Green Tensor for two atoms between two planar surfaces.
We try to keep the same notation (in particular the same function names) as in the paper.
"""


@njit(cache=True)
def rs(kz: complex, k1z: complex) -> complex:
    """Calculate the Fresnel reflection coefficient for s-polarized light.

    Args:
        kz: Perpendicular wave vector component in the medium between the two surfaces (1/m)
        k1z: Perpendicular wave vector component in the upper or lower medium (1/m)

    Returns: The Fresnel reflection coefficient for s-polarized light (dimensionless, complex)

    """
    if kz == 0 and k1z == 0:
        return 0.0
    return (kz - k1z) / (kz + k1z)


@njit(cache=True)
def rp(kz: complex, k1z: complex, epsilon: complex) -> complex:
    """Calculate the Fresnel reflection coefficient for p-polarized light.

    Args:
        kz: Perpendicular wave vector component in the medium between the two surfaces (1/m)
        k1z: Perpendicular wave vector component in the upper or lower medium (1/m)
        epsilon: Electric permittivity of the upper or lower medium (dimensionless, complex)

    Returns: The Fresnel reflection coefficient for p-polarized light (dimensionless, complex)

    """
    if kz == 0 and k1z == 0:
        return 0.0
    return (epsilon * kz - k1z) / (epsilon * kz + k1z)


@njit(cache=True)
def D(r_plus: complex, r_minus: complex, kz: complex, h: float) -> complex:
    """Calculate the denominator term D used in the scattering Green Tensor matrix elements.

    Args:
        r_plus: Fresnel reflection coefficient for the upper surface (dimensionless, complex)
        r_minus: Fresnel reflection coefficient for the lower surface (dimensionless, complex)
        kz: Perpendicular wave vector component in the medium between the two surfaces (1/m)
        h: Distance between the two surfaces (m)

    Returns: The value of the denominator term D (dimensionless, complex)

    """
    return 1 - r_plus * r_minus * np.exp(2j * kz * h)  # type: ignore [no-any-return]


@njit(cache=True)
def A_plus(r_plus: complex, r_minus: complex, kz: complex, h: float, z_ges: float, z_diff: float) -> complex:
    """Calculate the numerator term A_plus used in the scattering Green Tensor matrix elements.

    Args:
        r_plus: Fresnel reflection coefficient for the upper surface (dimensionless, complex)
        r_minus: Fresnel reflection coefficient for the lower surface (dimensionless, complex)
        kz: Perpendicular wave vector component in the medium between the two surfaces (1/m)
        h: Distance between the two surfaces (m)
        z_ges: Total z-coordinate (m)
        z_diff: Difference in z-coordinates (m)

    Returns: The value of the numerator term A_plus (dimensionless, complex)

    """
    return (  # type: ignore [no-any-return]
        r_minus * np.exp(1j * kz * (z_ges - h))
        + r_plus * np.exp(-1j * kz * (z_ges - h))
        + 2 * r_plus * r_minus * np.cos(kz * z_diff) * np.exp(1j * kz * h)
    ) / D(r_plus, r_minus, kz, h)


@njit(cache=True)
def A_minus(r_plus: complex, r_minus: complex, kz: complex, h: float, z_ges: float, z_diff: float) -> complex:
    """Calculate the numerator term A_minus used in the scattering Green Tensor matrix elements.

    Args:
        r_plus: Fresnel reflection coefficient for the upper surface (dimensionless, complex)
        r_minus: Fresnel reflection coefficient for the lower surface (dimensionless, complex)
        kz: Perpendicular wave vector component in the medium between the two surfaces (1/m)
        h: Distance between the two surfaces (m)
        z_ges: Total z-coordinate (m)
        z_diff: Difference in z-coordinates (m)

    Returns: The value of the numerator term A_minus (dimensionless, complex)

    """
    return (  # type: ignore [no-any-return]
        r_minus * np.exp(1j * kz * (z_ges - h))
        + r_plus * np.exp(-1j * kz * (z_ges - h))
        - 2 * r_plus * r_minus * np.cos(kz * z_diff) * np.exp(1j * kz * h)
    ) / D(r_plus, r_minus, kz, h)


@njit(cache=True)
def B_plus(r_plus: complex, r_minus: complex, kz: complex, h: float, z_ges: float, z_diff: float) -> complex:
    """Calculate the numerator term B_plus used in the scattering Green Tensor matrix elements.

    Args:
        r_plus: Fresnel reflection coefficient for the upper surface (dimensionless, complex)
        r_minus: Fresnel reflection coefficient for the lower surface (dimensionless, complex)
        kz: Perpendicular wave vector component in the medium between the two surfaces (1/m)
        h: Distance between the two surfaces (m)
        z_ges: Total z-coordinate (m)
        z_diff: Difference in z-coordinates (m)

    Returns: The value of the numerator term B_plus (dimensionless, complex)

    """
    return (  # type: ignore [no-any-return]
        r_minus * np.exp(1j * kz * (z_ges - h))
        - r_plus * np.exp(-1j * kz * (z_ges - h))
        + 2j * r_plus * r_minus * np.sin(kz * z_diff) * np.exp(1j * kz * h)
    ) / D(r_plus, r_minus, kz, h)


@njit(cache=True)
def B_minus(r_plus: complex, r_minus: complex, kz: complex, h: float, z_ges: float, z_diff: float) -> complex:
    """Calculate the numerator term B_minus used in the scattering Green Tensor matrix elements.

    Args:
        r_plus: Fresnel reflection coefficient for the upper surface (dimensionless, complex)
        r_minus: Fresnel reflection coefficient for the lower surface (dimensionless, complex)
        kz: Perpendicular wave vector component in the medium between the two surfaces (1/m)
        h: Distance between the two surfaces (m)
        z_ges: Total z-coordinate (m)
        z_diff: Difference in z-coordinates (m)

    Returns: The value of the numerator term B_minus (dimensionless, complex)

    """
    return (  # type: ignore [no-any-return]
        r_minus * np.exp(1j * kz * (z_ges - h))
        + r_plus * np.exp(-1j * kz * (z_ges - h))
        - 2j * r_plus * r_minus * np.sin(kz * z_diff) * np.exp(1j * kz * h)
    ) / D(r_plus, r_minus, kz, h)


def Gs(
    kz: complex,
    h: float,
    k_rho: complex,
    rho: float,
    phi: float,
    rs_plus: complex,
    rs_minus: complex,
    z_ges: float,
    z_diff: float,
    entry: Entries,
) -> complex:
    """Calculate the Gs part of the scattering Green Tensor."""
    if entry in ["xz", "yz", "zx", "zy", "zz"]:
        return 0
    As_plus = A_plus(rs_plus, rs_minus, kz, h, z_ges, z_diff)
    J2 = cached_bessel_function_2(k_rho * rho)
    if entry in ["xy", "yx"]:
        return -As_plus / 2 * J2 * math.sin(2 * phi)
    J0 = cached_bessel_function_0(k_rho * rho)
    if entry == "xx":
        return As_plus / 2 * (J0 + J2 * math.cos(2 * phi))
    if entry == "yy":
        return As_plus / 2 * (J0 - J2 * math.cos(2 * phi))

    raise ValueError(f"Invalid entry '{entry}' for Gs function.")


def Gp(  # noqa: PLR0911
    kz: complex,
    h: float,
    k_rho: complex,
    rho: float,
    phi: float,
    rp_plus: complex,
    rp_minus: complex,
    z_ges: float,
    z_diff: float,
    entry: Entries,
) -> complex:
    """Calculate the Gp part of the scattering Green Tensor."""
    if entry in ["xz", "zx", "yz", "zy"]:
        J1 = cached_bessel_function_1(k_rho * rho)
        if entry == "zx":
            Bp_minus = B_minus(rp_plus, rp_minus, kz, h, z_ges, z_diff)
            return -1j * (k_rho / kz) * Bp_minus * J1 * math.cos(phi)
        if entry == "xz":
            Bp_plus = B_plus(rp_plus, rp_minus, kz, h, z_ges, z_diff)
            return 1j * (k_rho / kz) * Bp_plus * J1 * math.cos(phi)
        if entry == "yz":
            Bp_plus = B_plus(rp_plus, rp_minus, kz, h, z_ges, z_diff)
            return 1j * (k_rho / kz) * Bp_plus * J1 * math.sin(phi)
        if entry == "zy":
            Bp_minus = B_minus(rp_plus, rp_minus, kz, h, z_ges, z_diff)
            return -1j * (k_rho / kz) * Bp_minus * J1 * math.sin(phi)

    if entry == "zz":
        J0 = cached_bessel_function_0(k_rho * rho)
        Ap_plus = A_plus(rp_plus, rp_minus, kz, h, z_ges, z_diff)
        return -(k_rho**2 / kz**2) * Ap_plus * J0

    J2 = cached_bessel_function_2(k_rho * rho)
    Ap_minus = A_minus(rp_plus, rp_minus, kz, h, z_ges, z_diff)
    if entry in ["xy", "yx"]:
        return Ap_minus / 2 * J2 * math.sin(2 * phi)

    J0 = cached_bessel_function_0(k_rho * rho)
    if entry == "xx":
        return Ap_minus / 2 * (J0 - J2 * math.cos(2 * phi))
    if entry == "yy":
        return Ap_minus / 2 * (J0 + J2 * math.cos(2 * phi))

    raise ValueError(f"Invalid entry '{entry}' for Gp function.")


""" The integrals for the scattering Green Tensor are evaluated in two parts:
    The first part is along an elliptical path from 0 to 2*k_maj in the complex plane to avoid singularities,
    and the second part is along the real axis from 2*k_maj to an upper limit.

    The methods for evaluating these integrals are explained in the papers:
    - "Accurate and efficient computation of the Green's tensor for stratified media"
        section III.A (https://doi.org/10.1103/PhysRevE.62.5797)
    - "Challenges in Computational Electromagnetics: Analysis and Optimization of Planar Multilayered Structures"
        section 2.4.1 (https://doi.org/10.5075/epfl-thesis-5122)
    """


@njit(cache=True)
def integrand_ellipse_partial(
    t: complex,
    k_maj: float,
    k_min: float,
    k0: float,
    epsilon0: float,
    epsilon1: complex,
    epsilon2: complex,
    h: float,
) -> tuple[complex, complex, complex, complex, complex, complex, complex]:
    # elliptical path, substitution
    k_rho = k_maj * (1 + np.cos(t)) - 1j * k_min * np.sin(t)
    dk_rho = -k_maj * np.sin(t) - 1j * k_min * np.cos(t)

    # Wave vector components
    kz = branch(epsilon0, k0, k_rho)
    k1z = branch(epsilon1, k0, k_rho)
    k2z = branch(epsilon2, k0, k_rho)

    rs_plus = rs(kz, k1z)
    rs_minus = rs(kz, k2z)
    rp_plus = rp(kz, k1z, epsilon1)
    rp_minus = rp(kz, k2z, epsilon2)

    if k_rho == 0 and dk_rho == 0:  # noqa: SIM108
        prefactor = 0.0
    else:
        prefactor = 1j / (4 * np.pi) * (k_rho / kz) * np.exp(1j * kz * h) * dk_rho
    return k_rho, kz, rs_plus, rs_minus, rp_plus, rp_minus, prefactor


def integrand_ellipse(
    t: complex,
    k_maj: float,
    k_min: float,
    k0: float,
    epsilon0: float,
    epsilon1: complex,
    epsilon2: complex,
    h: float,
    rho: float,
    phi: float,
    z_ges: float,
    z_diff: float,
    entry: Entries,
    real_or_imag: str,
) -> complex:
    k_rho, kz, rs_plus, rs_minus, rp_plus, rp_minus, prefactor = integrand_ellipse_partial(
        t, k_maj, k_min, k0, epsilon0, epsilon1, epsilon2, h
    )
    if k0 == 0 and kz == 0:
        return 0.0

    gs = Gs(kz, h, k_rho, rho, phi, rs_plus, rs_minus, z_ges, z_diff, entry)
    gp = Gp(kz, h, k_rho, rho, phi, rp_plus, rp_minus, z_ges, z_diff, entry)

    integrand = prefactor * (k0**2 * gs - kz**2 * gp)
    if real_or_imag == "real":
        return np.real(integrand)
    if real_or_imag == "imag":
        return np.imag(integrand)
    raise ValueError("real_or_imag must be 'real' or 'imag'")


def elliptic_integral(
    omega: float,
    h: float,
    rho: float,
    phi: float,
    epsilon0: complex,
    epsilon1: complex,
    epsilon2: complex,
    z_ges: float,
    z_diff: float,
    entry: Entries,
    *,
    only_real_part: bool = False,
) -> complex:
    """Evaluate the elliptic part of the integral.

    Args:
        omega: Angular frequency (i.e. 2*pi*f) in 1/s
        h: Distance between the two surfaces in meters
        rho: In-plane distance between the two atoms in meters
        phi: Angle between the in-plane distance vector and the x-axis in radians
        epsilon0: Electric permittivity of the medium between the two surfaces (dimensionless, complex)
        epsilon1: Electric permittivity of the upper medium (dimensionless, complex)
        epsilon2: Electric permittivity of the lower medium (dimensionless, complex)
        z_ges: Sum of the z-positions of the two atoms in meters
        z_diff: Difference of the z-positions of the two atoms in meters
        entry: Entry of the Green tensor to calculate
        only_real_part: If True, only the real part of the integral is calculated (default: False)

    Returns: The value of the integral along the elliptical path as a complex number (1/m)

    """
    k_vac = omega / const.c  # magnitude of wave vector in vacuum
    k0 = k_vac * np.sqrt(epsilon0)

    # Elliptical path in complex plane to avoid singularities (Integral from 0 to 2k_maj)
    k1 = k_vac * np.sqrt(epsilon1)
    k2 = k_vac * np.sqrt(epsilon2)
    kl_max = max(np.real(k0), np.real(k1), np.real(k2))

    k_maj = (kl_max + k_vac) / 2  # major axis of ellipse
    k_min = min(k_vac, 1 / rho) if rho != 0 else k_vac

    args = (k_maj, k_min, k0, epsilon0, epsilon1, epsilon2, h, rho, phi, z_ges, z_diff, entry)

    real_ellipse, _ = quad(integrand_ellipse, np.pi, 0, args=(*args, "real"), epsrel=1e-9, limit=1000)  # type: ignore [arg-type]
    if only_real_part:
        return real_ellipse
    imag_ellipse, _ = quad(integrand_ellipse, np.pi, 0, args=(*args, "imag"), epsrel=1e-9, limit=1000)  # type: ignore [arg-type]
    return real_ellipse + 1j * imag_ellipse


def integrand_real(
    k_rho: complex,
    k0: float,
    epsilon0: float,
    epsilon1: complex,
    epsilon2: complex,
    h: float,
    rho: float,
    phi: float,
    z_ges: float,
    z_diff: float,
    entry: Entries,
    real_or_imag: str,
) -> complex:
    kz = branch(epsilon0, k0, k_rho)
    if kz == 0 and k0 == 0:
        return 0

    k1z = branch(epsilon1, k0, k_rho)
    k2z = branch(epsilon2, k0, k_rho)

    rs_plus = rs(kz, k1z)
    rs_minus = rs(kz, k2z)
    rp_plus = rp(kz, k1z, epsilon1)
    rp_minus = rp(kz, k2z, epsilon2)

    # Integrand
    integrand = (
        1j
        / (4 * np.pi)
        * (
            k0**2 * Gs(kz, h, k_rho, rho, phi, rs_plus, rs_minus, z_ges, z_diff, entry)
            - kz**2 * Gp(kz, h, k_rho, rho, phi, rp_plus, rp_minus, z_ges, z_diff, entry)
        )
        * (k_rho / kz)
        * np.exp(1j * kz * h)
    )
    if real_or_imag == "real":
        return np.real(integrand)  # type: ignore [no-any-return]
    if real_or_imag == "imag":
        return np.imag(integrand)  # type: ignore [no-any-return]
    raise ValueError("real_or_imag must be 'real' or 'imag'")


def real_axis_integral(
    omega: float,
    h: float,
    rho: float,
    phi: float,
    epsilon0: complex,
    epsilon1: complex,
    epsilon2: complex,
    z_ges: float,
    z_diff: float,
    entry: Entries,
    *,
    only_real_part: bool = False,
) -> complex:
    """Evaluate the real axis part of the integral.

    Args:
        omega: Angular frequency (i.e. 2*pi*f) in 1/s
        h: Distance between the two surfaces in meters
        rho: In-plane distance between the two atoms in meters
        phi: Angle between the in-plane distance vector and the x-axis in radians
        epsilon0: Electric permittivity of the medium between the two surfaces (dimensionless, complex)
        epsilon1: Electric permittivity of the upper medium (dimensionless, complex)
        epsilon2: Electric permittivity of the lower medium (dimensionless, complex)
        z_ges: Sum of the z-positions of the two atoms in meters
        z_diff: Difference of the z-positions of the two atoms in meters
        entry: Entry of the Green tensor to calculate
        upper_limit: Upper limit for the real axis integral (1/m)
        only_real_part: If True, only the real part of the integral is calculated (default: False)

    Returns: The value of the integral along the real axis as a complex number (1/m)

    """
    k_vac = omega / const.c  # magnitude of wave vector in vacuum
    k0 = k_vac * np.sqrt(epsilon0)
    k1 = k_vac * np.sqrt(epsilon1)
    k2 = k_vac * np.sqrt(epsilon2)

    kl_max = max(np.real(k0), np.real(k1), np.real(k2))
    k_maj = (kl_max + k_vac) / 2

    args = (k0, epsilon0, epsilon1, epsilon2, h, rho, phi, z_ges, z_diff, entry)

    # Estimate the upper limit for the real axis integral
    upper_limit = np.sqrt((745 / h) ** 2 + 1)

    real_real, _ = quad(
        integrand_real,  # type: ignore [arg-type]
        2 * k_maj,
        upper_limit,
        args=(*args, "real"),  # type: ignore [arg-type]
        limit=1000,
        epsrel=1e-9,
    )
    if only_real_part:
        return real_real
    imag_real, _ = quad(
        integrand_real,  # type: ignore [arg-type]
        2 * k_maj,
        upper_limit,
        args=(*args, "imag"),  # type: ignore [arg-type]
        limit=1000,
        epsrel=1e-9,
    )
    return real_real + 1j * imag_real
