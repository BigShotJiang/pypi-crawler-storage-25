// SPDX-FileCopyrightText: 2024 PairInteraction Developers
// SPDX-License-Identifier: LGPL-3.0-or-later

#include "./LoggerBridge.hpp"
#include "./basis/Basis.py.hpp"
#include "./database/Database.py.hpp"
#include "./diagonalize/Diagonalizer.py.hpp"
#include "./enums/FloatType.py.hpp"
#include "./enums/OperatorType.py.hpp"
#include "./enums/Parity.py.hpp"
#include "./enums/TransformationType.py.hpp"
#include "./interfaces/DiagonalizerInterface.py.hpp"
#include "./interfaces/TransformationBuilderInterface.py.hpp"
#include "./ket/Ket.py.hpp"
#include "./paths.py.hpp"
#include "./system/System.py.hpp"
#include "./tools/run_unit_tests.py.hpp"
#include "./version.py.hpp"
#include "pairinteraction/utils/TaskControl.hpp"

#include <nanobind/nanobind.h>
#include <nanobind/stl/string.h>
#include <nanobind/stl/vector.h>

namespace nb = nanobind;

NB_MODULE(_backend, m) // NOLINT
{
    // https://nanobind.readthedocs.io/en/latest/faq.html#why-am-i-getting-errors-about-leaked-functions-and-types
    nb::set_leak_warnings(false);

    // wrap the get_pending_logs method of the logger bridge instance
    static LoggerBridge bridge;
    nb::class_<LoggerBridge::LogEntry>(m, "LogEntry")
        .def_ro("level", &LoggerBridge::LogEntry::level)
        .def_prop_ro("message", [](const LoggerBridge::LogEntry &e) {
            return nb::bytes(e.message.data(), e.message.size());
        });
    m.def("get_pending_logs", []() { return bridge.get_pending_logs(); });

    // wrap task control functions
    static nb::exception<pairinteraction::TaskAbortedError> task_aborted_error(m,
                                                                               "TaskAbortedError");
    m.def("request_task_abort", &pairinteraction::request_task_abort);
    m.def("reset_task_status", &pairinteraction::reset_task_status);
    m.def("get_task_info", &pairinteraction::get_task_info);
    m.def("get_progress_count", &pairinteraction::get_progress_count);

    // enums
    bind_operator_type(m);
    bind_parity(m);
    bind_transformation_type(m);
    bind_float_type(m);

    // interfaces
    bind_diagonalizer_interface(m);
    bind_transformation_builder_interface(m);

    // database
    bind_database(m);

    // diagonalizer
    bind_diagonalizer(m);

    // ket
    bind_ket(m);

    // basis
    bind_basis(m);

    // system
    bind_system(m);

    // tools
    bind_run_unit_tests(m);

    // paths
    bind_paths(m);

    // version
    bind_version(m);
}
