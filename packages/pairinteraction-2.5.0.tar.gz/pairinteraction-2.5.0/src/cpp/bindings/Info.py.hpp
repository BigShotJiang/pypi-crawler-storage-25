// SPDX-FileCopyrightText: 2025 PairInteraction Developers
// SPDX-License-Identifier: LGPL-3.0-or-later

#pragma once

#include <nanobind/nanobind.h>

void bind_info(nanobind::module_ &m);
