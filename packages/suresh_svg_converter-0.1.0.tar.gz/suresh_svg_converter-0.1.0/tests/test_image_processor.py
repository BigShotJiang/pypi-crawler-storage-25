"""
Test suite for Image to SVG Converter
"""
import pytest
import tempfile
import os
from pathlib import Path
from PIL import Image
import numpy as np

from suresh_svg_converter.services.bg_remove import BackgroundRemover, BACKGROUND_REMOVAL_AVAILABLE, REMBG_AVAILABLE
from suresh_svg_converter.services.svg_convert import SVGConverter, SVG_CONVERSION_AVAILABLE, POTRACE_AVAILABLE, SVGWRITE_AVAILABLE
from suresh_svg_converter.services.image_utils import (
    load_image,
    resize_image,
    enhance_image,
    convert_to_binary,
    preprocess_for_svg
)


class TestImageUtils:
    """Test image utility functions"""
    
    @pytest.fixture
    def sample_image(self, tmp_path):
        """Create a sample test image"""
        img_path = tmp_path / "test.png"
        img = Image.new('RGB', (100, 100), color='red')
        img.save(img_path)
        return img_path
    
    @pytest.fixture
    def large_image(self, tmp_path):
        """Create a large test image"""
        img_path = tmp_path / "large.png"
        img = Image.new('RGB', (5000, 5000), color='blue')
        img.save(img_path)
        return img_path
    
    def test_load_image(self, sample_image):
        """Test image loading"""
        img = load_image(str(sample_image))
        assert img.size == (100, 100)
        assert img.mode == 'RGB'
    
    def test_load_invalid_image(self):
        """Test loading invalid image"""
        with pytest.raises(FileNotFoundError):
            load_image("nonexistent.png")
    
    def test_resize_image_small(self, sample_image):
        """Test resizing small image (should not resize)"""
        img = Image.open(sample_image)
        resized = resize_image(img, max_dimension=4096)
        assert resized.size == (100, 100)
    
    def test_resize_image_large(self, large_image):
        """Test resizing large image"""
        img = Image.open(large_image)
        resized = resize_image(img, max_dimension=4096)
        assert max(resized.size) <= 4096
        # Check aspect ratio maintained
        ratio = resized.width / resized.height
        assert abs(ratio - 1.0) < 0.01
    
    def test_enhance_image(self, sample_image):
        """Test image enhancement"""
        img = Image.open(sample_image)
        enhanced = enhance_image(img, contrast=1.5, sharpness=2.0)
        assert enhanced.size == img.size
    
    def test_convert_to_binary(self, sample_image):
        """Test binary conversion"""
        img = Image.open(sample_image).convert('L')
        binary = convert_to_binary(img, threshold=128)
        assert binary.shape == (100, 100)
        assert binary.dtype == np.uint8
        assert set(np.unique(binary)).issubset({0, 255})
    
    def test_preprocess_for_svg(self, large_image):
        """Test complete preprocessing pipeline"""
        img = Image.open(large_image)
        processed, metadata = preprocess_for_svg(img, max_dim=2048)
        
        assert max(processed.size) <= 2048
        assert metadata['resized'] is True
        assert 'original_size' in metadata
        assert 'final_size' in metadata

    def test_preprocess_crops_foreground_alpha(self, tmp_path):
        """Test cropping to the visible alpha foreground"""
        img = Image.new('RGBA', (200, 200), (0, 0, 0, 0))
        for x in range(50, 150):
            for y in range(50, 150):
                img.putpixel((x, y), (255, 0, 0, 255))
        processed, metadata = preprocess_for_svg(img, max_dim=2048)

        assert processed.size[0] <= 102
        assert processed.size[1] <= 102
        assert metadata['cropped'] is True
        assert 'crop_size' in metadata


class TestBackgroundRemoval:
    """Test background removal functionality"""
    
    @pytest.fixture
    def test_image_with_bg(self, tmp_path):
        """Create test image"""
        img_path = tmp_path / "test_bg.png"
        # Create image with solid background
        img = Image.new('RGBA', (200, 200), (255, 0, 0, 255))
        # Add a shape in the center
        for x in range(50, 150):
            for y in range(50, 150):
                img.putpixel((x, y), (0, 255, 0, 255))
        img.save(img_path)
        return img_path
    
    def test_singleton_pattern(self):
        """Test that BackgroundRemover is a singleton"""
        remover1 = BackgroundRemover()
        remover2 = BackgroundRemover()
        assert remover1 is remover2

    def test_background_removal_available(self):
        """Background removal should stay available via fallback logic."""
        assert BACKGROUND_REMOVAL_AVAILABLE is True
    
    def test_remove_background(self, test_image_with_bg):
        """Test background removal"""
        remover = BackgroundRemover()
        result = remover.remove_background(str(test_image_with_bg))
        
        assert result.mode == 'RGBA'
        assert result.size == (200, 200)
        
        # Check that some pixels are transparent
        pixels = list(result.getdata())
        transparent_count = sum(1 for p in pixels if p[3] < 255)
        assert transparent_count > 0
    
    def test_remove_background_bytes(self, test_image_with_bg):
        """Test background removal from bytes"""
        with open(test_image_with_bg, 'rb') as f:
            img_bytes = f.read()
        
        remover = BackgroundRemover()
        result = remover.remove_background(img_bytes)
        
        assert result.mode == 'RGBA'


class TestSVGConversion:
    """Test SVG conversion functionality"""
    
    @pytest.fixture
    def simple_image(self, tmp_path):
        """Create simple black and white image"""
        img_path = tmp_path / "simple.png"
        img = Image.new('L', (100, 100), 255)  # White background
        # Draw black rectangle
        for x in range(25, 75):
            for y in range(25, 75):
                img.putpixel((x, y), 0)
        img.save(img_path)
        return img_path
    
    def test_image_to_bitmap(self, simple_image):
        """Test bitmap conversion"""
        img = Image.open(simple_image)
        converter = SVGConverter()
        bitmap = converter.image_to_bitmap(img)
        
        assert bitmap.shape == (100, 100)
        assert bitmap.dtype == np.float64
        assert set(np.unique(bitmap)).issubset({0.0, 1.0})

    def test_image_to_bitmap_uses_alpha_mask(self, tmp_path):
        """Test alpha-channel bitmap conversion preserves the object mask"""
        img_path = tmp_path / "alpha.png"
        img = Image.new('RGBA', (80, 80), (0, 0, 0, 0))
        for x in range(20, 60):
            for y in range(20, 60):
                img.putpixel((x, y), (255, 0, 0, 128))
        img.save(img_path)

        converter = SVGConverter()
        bitmap = converter.image_to_bitmap(Image.open(img_path))

        assert bitmap.shape == (80, 80)
        assert bitmap.dtype == np.float64
        assert bitmap[40, 40] == 1.0
        assert bitmap[0, 0] == 0.0

    def test_svg_conversion_available(self):
        """SVG conversion should stay available via fallback tracing."""
        assert SVG_CONVERSION_AVAILABLE is True
    
    def test_trace_bitmap(self, simple_image):
        """Test bitmap tracing"""
        img = Image.open(simple_image)
        converter = SVGConverter()
        bitmap = converter.image_to_bitmap(img)
        traced = converter.trace_bitmap(bitmap)
        
        assert traced is not None
        assert len(traced.curves) > 0
    
    def test_save_to_svg(self, simple_image, tmp_path):
        """Test SVG saving"""
        img = Image.open(simple_image)
        converter = SVGConverter()
        bitmap = converter.image_to_bitmap(img)
        traced = converter.trace_bitmap(bitmap)
        
        svg_path = tmp_path / "output.svg"
        result_path = converter.save_to_svg(traced, svg_path)
        
        assert result_path.exists()
        assert result_path.suffix == '.svg'
        
        # Verify SVG is valid XML
        with open(result_path, 'r') as f:
            content = f.read()
            assert '<svg' in content
            assert '</svg>' in content
    
    def test_full_conversion(self, simple_image, tmp_path):
        """Test complete conversion pipeline"""
        converter = SVGConverter()
        svg_path = tmp_path / "converted.svg"
        
        result = converter.convert(simple_image, svg_path)
        
        assert result.exists()
        assert result.stat().st_size > 0


class TestEdgeCases:
    """Test edge cases and error handling"""
    
    def test_corrupted_image(self, tmp_path):
        """Test handling of corrupted image file"""
        corrupted_path = tmp_path / "corrupted.png"
        
        # Write invalid image data
        with open(corrupted_path, 'wb') as f:
            f.write(b"Not a valid image file")
        
        with pytest.raises(Exception):
            load_image(str(corrupted_path))
    
    def test_empty_image(self, tmp_path):
        """Test handling of very small image"""
        tiny_path = tmp_path / "tiny.png"
        img = Image.new('RGB', (1, 1), color='red')
        img.save(tiny_path)
        
        # Should not raise exception
        processed, metadata = preprocess_for_svg(img)
        assert processed.size == (1, 1)
    
    def test_alpha_channel_image(self, tmp_path):
        """Test image with alpha channel"""
        alpha_path = tmp_path / "alpha.png"
        img = Image.new('RGBA', (100, 100), (255, 0, 0, 128))
        img.save(alpha_path)
        
        img = load_image(str(alpha_path))
        assert img.mode in ('RGB', 'RGBA')


class TestIntegration:
    """Integration tests for complete workflow"""
    
    def test_full_workflow(self, tmp_path):
        """Test complete workflow: load → remove bg → convert to svg"""
        # Create test image
        img_path = tmp_path / "test.png"
        img = Image.new('RGBA', (200, 200), (255, 255, 255, 255))
        # Add colored rectangle
        for x in range(50, 150):
            for y in range(50, 150):
                img.putpixel((x, y), (0, 0, 255, 255))
        img.save(img_path)
        
        # Step 1: Remove background
        remover = BackgroundRemover()
        no_bg = remover.remove_background(str(img_path))
        
        # Step 2: Convert to SVG
        svg_path = tmp_path / "output.svg"
        converter = SVGConverter()
        converter.convert(no_bg, svg_path)
        
        # Verify outputs
        assert svg_path.exists()
        assert svg_path.stat().st_size > 0


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
