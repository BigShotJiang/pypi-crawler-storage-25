"""
Models for request/response handling
"""
from dataclasses import dataclass
from typing import Optional
from pathlib import Path

from pydantic import BaseModel

@dataclass
class ProcessedImage:
    """Represents a processed image with paths"""
    original_path: Path
    transparent_png_path: Optional[Path] = None
    svg_path: Optional[Path] = None
    success: bool = True
    error_message: Optional[str] = None


class ProcessingResult(BaseModel):
    """Result of image processing operation"""
    success: bool
    message: str
    transparent_png: Optional[str] = None
    svg_file: Optional[str] = None
    processing_time: float = 0.0
