"""
Models package initialization
"""
