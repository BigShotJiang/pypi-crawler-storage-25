"""
Command Line Interface for Image to SVG Converter
"""
import sys
import time
import logging
from pathlib import Path
from typing import List, Optional

import click
from tqdm import tqdm

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from suresh_svg_converter.config import settings
from suresh_svg_converter.services.bg_remove import BackgroundRemover, REMBG_AVAILABLE
from suresh_svg_converter.services.svg_convert import SVGConverter, POTRACE_AVAILABLE, SVGWRITE_AVAILABLE
from suresh_svg_converter.services.image_utils import preprocess_for_svg, load_image

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format=settings.LOG_FORMAT
)
logger = logging.getLogger(__name__)


@click.command()
@click.argument(
    'input_files',
    nargs=-1,
    type=click.Path(exists=True, path_type=Path),
    required=True
)
@click.option(
    '--output-dir', '-o',
    type=click.Path(path_type=Path),
    default=None,
    help='Output directory (default: ./outputs)'
)
@click.option(
    '--remove-bg', '-r',
    is_flag=True,
    default=True,
    help='Remove background from images'
)
@click.option(
    '--svg', '-s',
    is_flag=True,
    default=True,
    help='Convert to SVG format'
)
@click.option(
    '--no-svg',
    is_flag=True,
    default=False,
    help='Skip SVG conversion'
)
@click.option(
    '--max-dim',
    type=int,
    default=settings.MAX_IMAGE_DIMENSION,
    help=f'Maximum image dimension (default: {settings.MAX_IMAGE_DIMENSION})'
)
@click.option(
    '--verbose', '-v',
    is_flag=True,
    help='Enable verbose output'
)
def main(
    input_files: List[Path],
    output_dir: Optional[Path],
    remove_bg: bool,
    svg: bool,
    no_svg: bool,
    max_dim: int,
    verbose: bool
):
    """
    Process images: remove backgrounds and convert to SVG.
    
    INPUT_FILES: One or more image files (PNG, JPG, JPEG, WEBP)
    
    Examples:
    
    \b
        # Process single image
        python cli.py input.jpg
        
        # Process with SVG conversion
        python cli.py input.png --svg
        
        # Process without background removal
        python cli.py input.jpg --no-remove-bg
        
        # Process multiple files
        python cli.py *.jpg -o ./results
        
        # Custom max dimension
        python cli.py input.png --max-dim 2048
    """
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Determine output directory
    if output_dir is None:
        output_dir = settings.OUTPUT_DIR
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Check required libraries
    if remove_bg and not REMBG_AVAILABLE:
        logger.warning("Background removal requested but rembg is not installed")
        remove_bg = False
    
    if (svg or not no_svg) and not (POTRACE_AVAILABLE and SVGWRITE_AVAILABLE):
        logger.warning("SVG conversion requested but required libraries are not installed")
        svg = False
    
    convert_to_svg = svg and not no_svg
    
    # Filter valid image files
    valid_extensions = {'.png', '.jpg', '.jpeg', '.webp'}
    image_files = [
        f for f in input_files
        if f.suffix.lower() in valid_extensions
    ]
    
    if not image_files:
        logger.error("No valid image files found")
        sys.exit(1)
    
    logger.info(f"Processing {len(image_files)} image(s)...")
    logger.info(f"Output directory: {output_dir}")
    logger.info(f"Background removal: {'enabled' if remove_bg else 'disabled'}")
    logger.info(f"SVG conversion: {'enabled' if convert_to_svg else 'disabled'}")
    
    # Initialize services
    if remove_bg:
        logger.info("Initializing background removal...")
        remover = BackgroundRemover()
    
    if convert_to_svg:
        logger.info("Initializing SVG converter...")
        converter = SVGConverter()
    
    # Process each file
    success_count = 0
    error_count = 0
    
    for input_file in tqdm(image_files, desc="Processing images"):
        try:
            start_time = time.time()
            logger.info(f"\nProcessing: {input_file.name}")
            
            # Load image
            image = load_image(str(input_file))
            logger.debug(f"Loaded image: {image.size}, {image.mode}")
            
            # Remove background
            if remove_bg:
                logger.debug("Removing background...")
                image = remover.remove_background(image)
                logger.debug("Background removed")
            
            # Ensure RGBA
            if image.mode != 'RGBA':
                image = image.convert('RGBA')
            
            # Generate output filename
            base_name = input_file.stem
            unique_id = f"{int(time.time())}"
            
            # Save transparent PNG
            png_output = output_dir / f"{base_name}_{unique_id}.png"
            logger.debug(f"Saving PNG: {png_output}")
            image.save(png_output, "PNG")
            logger.info(f"✓ Saved: {png_output.name}")
            
            # Convert to SVG
            if convert_to_svg:
                logger.debug("Converting to SVG...")
                
                # Preprocess
                preprocessed_img, metadata = preprocess_for_svg(image, max_dim=max_dim)
                
                # Convert
                svg_output = output_dir / f"{base_name}_{unique_id}.svg"
                converter.convert(preprocessed_img, svg_output)
                logger.info(f"✓ Saved: {svg_output.name}")
            
            processing_time = time.time() - start_time
            logger.debug(f"Processing time: {processing_time:.2f}s")
            success_count += 1
            
        except Exception as e:
            logger.error(f"✗ Error processing {input_file.name}: {str(e)}")
            if verbose:
                logger.exception("Detailed error:")
            error_count += 1
    
    # Summary
    logger.info("\n" + "="*50)
    logger.info("Processing Complete!")
    logger.info(f"  Successful: {success_count}")
    logger.info(f"  Failed: {error_count}")
    logger.info(f"  Output: {output_dir}")
    logger.info("="*50)
    
    if error_count > 0:
        sys.exit(1)


if __name__ == '__main__':
    main()
