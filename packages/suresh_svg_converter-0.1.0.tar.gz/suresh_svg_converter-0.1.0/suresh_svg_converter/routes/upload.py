"""
API routes for image upload and processing
"""
import logging
import time
from pathlib import Path
from typing import Optional
import uuid

from fastapi import APIRouter, UploadFile, File, HTTPException, BackgroundTasks, Response
from fastapi.responses import FileResponse, JSONResponse

from suresh_svg_converter.config import settings
from suresh_svg_converter.models.image_models import ProcessingResult, ProcessedImage
from suresh_svg_converter.services.bg_remove import BackgroundRemover, REMBG_AVAILABLE
from suresh_svg_converter.services.svg_convert import SVGConverter, SVG_CONVERSION_AVAILABLE, POTRACE_AVAILABLE
from suresh_svg_converter.services.image_utils import preprocess_for_svg

logger = logging.getLogger(__name__)

router = APIRouter()


def generate_output_filename(original_name: str, suffix: str = "") -> str:
    """Generate unique output filename"""
    name = Path(original_name).stem
    unique_id = str(uuid.uuid4())[:8]
    return f"{name}_{unique_id}{suffix}"


@router.post("/upload", response_model=ProcessingResult)
async def upload_image(response: Response,
    file: UploadFile = File(..., description="Image file to process"),
    convert_to_svg: bool = True,
    remove_background: bool = True,
    num_colors: int = getattr(settings, 'SVG_DEFAULT_COLORS', 8)
):
    """
    Upload and process an image
    
    - Accepts: PNG, JPG, JPEG, WEBP
    - Returns: Transparent PNG and optionally SVG
    """
    start_time = time.time()
    
    # Validate file extension
    file_ext = Path(file.filename).suffix.lower()
    if file_ext not in settings.SUPPORTED_FORMATS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file format. Supported: {settings.SUPPORTED_FORMATS}"
        )
    
    # Validate file size
    contents = await file.read()
    if len(contents) > settings.MAX_FILE_SIZE:
        raise HTTPException(
            status_code=400,
            detail=f"File too large. Maximum size: {settings.MAX_FILE_SIZE // (1024*1024)}MB"
        )
    
    try:
        from PIL import Image
        import io
        
        # Load image
        image = Image.open(io.BytesIO(contents))
        logger.info(f"Received image: {file.filename}, size: {image.size}, mode: {image.mode}")
        
        # Validate image dimensions
        if max(image.size) > settings.MAX_IMAGE_DIMENSION:
            scale_factor = settings.MAX_IMAGE_DIMENSION / max(image.size)
            new_size = tuple(int(dim * scale_factor) for dim in image.size)
            image = image.resize(new_size, Image.LANCZOS)
            logger.info(f"Image resized from {image.size} to {new_size} for performance")
        
        # Generate output paths
        output_dir = settings.OUTPUT_DIR
        png_filename = generate_output_filename(file.filename, ".png")
        svg_filename = generate_output_filename(file.filename, ".svg")
        
        png_path = output_dir / png_filename
        svg_path = output_dir / svg_filename if convert_to_svg else None
        
        result = ProcessedImage(
            original_path=Path(file.filename),
            transparent_png_path=png_path,
            svg_path=svg_path
        )
        
        # Step 1: Remove background if requested
        if remove_background:
            if not REMBG_AVAILABLE:
                logger.warning("Background removal requested but rembg not available")
            else:
                logger.info("Removing background...")
                remover = BackgroundRemover()
                image = remover.remove_background(image)
                logger.info("Background removed")
        
        # Ensure RGBA for transparent PNG
        if image.mode != 'RGBA':
            image = image.convert('RGBA')
        
        # Step 2: Save transparent PNG
        logger.info(f"Saving transparent PNG to {png_path}")
        image.save(png_path, "PNG")
        
        # Step 3: Convert to SVG if requested
        if convert_to_svg:
            if not SVG_CONVERSION_AVAILABLE:
                logger.warning("SVG conversion requested but required libraries not available")
                result.svg_path = None
            else:
                logger.info("Converting to SVG...")
                
                # Preprocess for better SVG quality
                preprocessed_img, metadata = preprocess_for_svg(image)
                
                # Convert to SVG
                converter = SVGConverter()
                converter.convert(preprocessed_img, svg_path)
                logger.info(f"SVG saved to {svg_path}")
        

        

        
        processing_time = time.time() - start_time

        # Build paths for browser download via static /outputs mount
        transparent_png_url = f"/outputs/{png_filename}"
        svg_url = None
        if convert_to_svg and svg_path and svg_path.exists():
            svg_url = f"/outputs/{svg_filename}"

        if convert_to_svg:
            response.headers["X-Potrace-Fallback"] = "false" if POTRACE_AVAILABLE else "true"
            
        return ProcessingResult(
            success=True,
            message="Image processed successfully",
            transparent_png=transparent_png_url,
            svg_file=svg_url,
            processing_time=round(processing_time, 2)
        )
        
    except Exception as e:
        logger.error(f"Error processing image: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Processing failed: {str(e)}")


@router.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "services": {
            "background_removal": REMBG_AVAILABLE,
            "svg_conversion": SVG_CONVERSION_AVAILABLE
        }
    }


@router.get("/info")
async def service_info():
    """Get service information and capabilities"""
    return {
        "name": "Image to SVG Converter",
        "version": "1.0.0",
        "supported_formats": list(settings.SUPPORTED_FORMATS),
        "max_file_size_mb": settings.MAX_FILE_SIZE // (1024 * 1024),
        "capabilities": {
            "background_removal": REMBG_AVAILABLE,
            "svg_conversion": SVG_CONVERSION_AVAILABLE,
            "potrace_native": POTRACE_AVAILABLE
        },
        "settings": {
            "max_image_dimension": settings.MAX_IMAGE_DIMENSION,
            "output_directory": str(settings.OUTPUT_DIR)
        }
    }
