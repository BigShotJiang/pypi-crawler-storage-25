"""
Routes package initialization
"""
