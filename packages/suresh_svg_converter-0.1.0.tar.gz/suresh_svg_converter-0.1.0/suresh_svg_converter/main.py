"""
FastAPI application entry point.
"""
import logging
from contextlib import asynccontextmanager
from html import escape

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from suresh_svg_converter.config import settings
from suresh_svg_converter.routes import upload
from suresh_svg_converter.services.bg_remove import (
    BackgroundRemover,
    get_rembg_unavailable_reason,
    is_rembg_available,
)
from suresh_svg_converter.services.svg_convert import SVG_CONVERSION_AVAILABLE

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL),
    format=settings.LOG_FORMAT,
)

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Initialize resources on startup and clean them up on shutdown.
    """
    logger.info("Starting Image to SVG Converter API...")

    logger.info("Pre-initializing background removal model...")
    try:
        _ = BackgroundRemover.get_session()
        logger.info("Background removal model ready")
    except Exception as exc:
        logger.warning("Could not initialize background removal: %s", exc)

    yield

    logger.info("Shutting down API...")
    BackgroundRemover.reset_session()


app = FastAPI(
    title="Image to SVG Converter",
    description="API for removing backgrounds from images and converting to SVG format",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(upload.router, prefix="/api", tags=["Image Processing"])

if settings.OUTPUT_DIR.exists():
    app.mount("/outputs", StaticFiles(directory=str(settings.OUTPUT_DIR)), name="outputs")


@app.get("/", response_class=HTMLResponse)
async def root():
    """Render the simple upload UI."""
    background_removal_available = is_rembg_available()
    svg_conversion_available = SVG_CONVERSION_AVAILABLE
    remove_bg_attrs = "checked" if background_removal_available else "disabled"
    remove_bg_label = (
        "Remove Background"
        if background_removal_available
        else "Remove Background (Unavailable)"
    )
    convert_svg_attrs = "checked" if svg_conversion_available else "disabled"
    convert_svg_label = (
        "Convert to SVG"
        if svg_conversion_available
        else "Convert to SVG (Unavailable)"
    )

    access_note = """
            <div class="notice info">
                Open this app at <strong>http://localhost:8000</strong> in your browser.
                The server bind address <code>0.0.0.0</code> is not a browser URL.
            </div>
    """

    background_notice = ""
    if not background_removal_available:
        reason = escape(get_rembg_unavailable_reason() or "Background removal is currently unavailable.")
        background_notice = f"""
            <div class="notice warning">
                {reason} You can still upload images and convert them without background removal.
            </div>
        """

    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Image to SVG Converter</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 50px auto;
                padding: 20px;
                background: #f5f5f5;
            }
            .container {
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            h1 {
                color: #333;
                text-align: center;
            }
            .notice {
                margin: 15px 0;
                padding: 12px 16px;
                border-radius: 8px;
                font-size: 14px;
                line-height: 1.5;
            }
            .notice.info {
                background: #e3f2fd;
                color: #0d47a1;
            }
            .notice.warning {
                background: #fff3e0;
                color: #8a5300;
            }
            code {
                background: rgba(0, 0, 0, 0.08);
                border-radius: 4px;
                padding: 2px 6px;
            }
            .upload-area {
                border: 3px dashed #ccc;
                border-radius: 10px;
                padding: 40px;
                text-align: center;
                margin: 20px 0;
                cursor: pointer;
                transition: border-color 0.3s;
            }
            .upload-area:hover {
                border-color: #666;
                background: #f9f9f9;
            }
            .upload-area.dragover {
                border-color: #4CAF50;
                background: #e8f5e9;
            }
            input[type="file"] {
                display: none;
            }
            .btn {
                background: #4CAF50;
                color: white;
                padding: 12px 30px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                font-size: 16px;
                margin: 10px 5px;
            }
            .btn:hover {
                background: #45a049;
            }
            .btn:disabled {
                background: #ccc;
                cursor: not-allowed;
            }
            .options {
                margin: 20px 0;
                padding: 15px;
                background: #f9f9f9;
                border-radius: 5px;
            }
            .options label {
                display: inline-block;
                margin: 5px 15px;
                cursor: pointer;
            }
            #result {
                margin-top: 30px;
                padding: 20px;
                background: #e8f5e9;
                border-radius: 5px;
                display: none;
            }
            .preview-panel {
                margin-top: 20px;
                padding: 16px;
                background: #f9f9f9;
                border: 1px solid #ddd;
                border-radius: 8px;
            }
            .preview-panel h3 {
                margin-top: 0;
                font-size: 16px;
                color: #333;
            }
            .preview-content {
                display: flex;
                flex-wrap: wrap;
                gap: 12px;
                margin-top: 12px;
            }
            .preview-item {
                width: 180px;
                max-width: 100%;
                border: 1px solid #ccc;
                border-radius: 6px;
                padding: 8px;
                background: white;
                text-align: center;
            }
            .preview-item img {
                max-width: 100%;
                max-height: 140px;
                display: block;
                margin: 0 auto 6px auto;
            }
            .preview-item span {
                display: block;
                font-size: 12px;
                color: #555;
                word-break: break-word;
            }
            .progress {
                margin-top: 20px;
                display: none;
            }
            .progress-bar {
                width: 100%;
                height: 20px;
                background: #e0e0e0;
                border-radius: 10px;
                overflow: hidden;
            }
            .progress-fill {
                height: 100%;
                background: #4CAF50;
                width: 0%;
                transition: width 0.3s;
            }
            .error {
                background: #ffebee;
                color: #c62828;
                padding: 15px;
                border-radius: 5px;
                margin-top: 20px;
                display: none;
            }
            .download-links {
                margin-top: 20px;
            }
            .download-links a {
                display: inline-block;
                margin: 10px 10px 10px 0;
                padding: 10px 20px;
                background: #2196F3;
                color: white;
                text-decoration: none;
                border-radius: 5px;
            }
            .download-links a:hover {
                background: #1976D2;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Image to SVG Converter</h1>
            <p style="text-align: center; color: #666;">
                Remove backgrounds and convert images to SVG format
            </p>
            __ACCESS_NOTE__
            __BACKGROUND_NOTICE__

            <div class="upload-area" id="dropZone">
                <p>Drag and drop your image here</p>
                <p style="color: #999; font-size: 14px;">or click to browse</p>
                <p style="color: #999; font-size: 12px;">
                    Supported: PNG, JPG, JPEG, WEBP (Max 50MB)
                </p>
                <input type="file" id="fileInput" accept=".png,.jpg,.jpeg,.webp">
            </div>

            <div class="options">
                <label>
                    <input type="checkbox" id="removeBg" __REMOVE_BG_ATTRS__>
                    __REMOVE_BG_LABEL__
                </label>
                <label>
                    <input type="checkbox" id="convertSvg" __CONVERT_SVG_ATTRS__>
                    __CONVERT_SVG_LABEL__
                </label>
            </div>

            <div class="preview-panel" id="previewPanel" style="display:none;">
                <h3>Selected image preview</h3>
                <div class="preview-content" id="selectedPreview"></div>
            </div>

            <div style="text-align: center;">
                <button class="btn" id="uploadBtn" disabled>Convert Image</button>
            </div>

            <div class="progress" id="progress">
                <p>Processing... <span id="progressText">0%</span></p>
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill"></div>
                </div>
            </div>

            <div class="error" id="error"></div>

            <div id="result">
                <h3>Processing Complete</h3>
                <p>Processing time: <strong id="procTime"></strong> seconds</p>
                <div class="download-links" id="downloadLinks"></div>
            </div>
        </div>

        <script>
            const dropZone = document.getElementById('dropZone');
            const fileInput = document.getElementById('fileInput');
            const uploadBtn = document.getElementById('uploadBtn');
            const removeBg = document.getElementById('removeBg');
            const convertSvg = document.getElementById('convertSvg');
            const progress = document.getElementById('progress');
            const progressFill = document.getElementById('progressFill');
            const progressText = document.getElementById('progressText');
            const result = document.getElementById('result');
            const error = document.getElementById('error');
            const downloadLinks = document.getElementById('downloadLinks');
            const procTime = document.getElementById('procTime');
            const previewPanel = document.getElementById('previewPanel');
            const selectedPreview = document.getElementById('selectedPreview');

            let selectedFile = null;

            dropZone.addEventListener('click', () => fileInput.click());

            dropZone.addEventListener('dragover', (e) => {
                e.preventDefault();
                dropZone.classList.add('dragover');
            });

            dropZone.addEventListener('dragleave', () => {
                dropZone.classList.remove('dragover');
            });

            dropZone.addEventListener('drop', (e) => {
                e.preventDefault();
                dropZone.classList.remove('dragover');
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    handleFile(files[0]);
                }
            });

            fileInput.addEventListener('change', (e) => {
                if (e.target.files.length > 0) {
                    handleFile(e.target.files[0]);
                }
            });

            function handleFile(file) {
                selectedFile = file;
                uploadBtn.disabled = false;
                dropZone.querySelector('p').textContent = `File selected: ${file.name}`;
                result.style.display = 'none';
                error.style.display = 'none';

                previewPanel.style.display = 'block';
                selectedPreview.innerHTML = '';

                const reader = new FileReader();
                reader.onload = (event) => {
                    const wrapper = document.createElement('div');
                    wrapper.className = 'preview-item';

                    const img = document.createElement('img');
                    img.src = event.target.result;
                    img.alt = file.name;
                    wrapper.appendChild(img);

                    const label = document.createElement('span');
                    label.textContent = file.name;
                    wrapper.appendChild(label);

                    selectedPreview.appendChild(wrapper);
                };
                reader.readAsDataURL(file);
            }

            uploadBtn.addEventListener('click', async () => {
                if (!selectedFile) return;

                const formData = new FormData();
                formData.append('file', selectedFile);
                formData.append('convert_to_svg', convertSvg.checked);
                formData.append('remove_background', removeBg.checked);

                progress.style.display = 'block';
                progressFill.style.width = '30%';
                progressText.textContent = 'Uploading...';
                uploadBtn.disabled = true;

                try {
                    const response = await fetch('/api/upload', {
                        method: 'POST',
                        body: formData
                    });

                    progressFill.style.width = '70%';
                    progressText.textContent = 'Processing...';

                    if (!response.ok) {
                        const errData = await response.json();
                        throw new Error(errData.detail || 'Processing failed');
                    }

                    const data = await response.json();

                    progressFill.style.width = '100%';
                    progressText.textContent = 'Complete';

                    setTimeout(() => {
                        progress.style.display = 'none';
                        result.style.display = 'block';
                        procTime.textContent = data.processing_time;

                        downloadLinks.innerHTML = '';
                        selectedPreview.innerHTML = '';

                        if (data.transparent_png) {
                            const pngPreview = document.createElement('div');
                            pngPreview.className = 'preview-item';

                            const img = document.createElement('img');
                            img.src = data.transparent_png;
                            img.alt = 'Processed PNG';
                            pngPreview.appendChild(img);

                            const label = document.createElement('span');
                            label.textContent = 'Processed PNG';
                            pngPreview.appendChild(label);

                            selectedPreview.appendChild(pngPreview);

                            const pngLink = document.createElement('a');
                            pngLink.href = data.transparent_png;
                            pngLink.textContent = 'Download PNG';
                            pngLink.download = '';
                            downloadLinks.appendChild(pngLink);
                        }

                        if (data.svg_file) {
                            const svgPreview = document.createElement('div');
                            svgPreview.className = 'preview-item';

                            const img = document.createElement('img');
                            img.src = data.svg_file;
                            img.alt = 'Output SVG';
                            svgPreview.appendChild(img);

                            const label = document.createElement('span');
                            label.textContent = 'Output SVG';
                            svgPreview.appendChild(label);

                            selectedPreview.appendChild(svgPreview);

                            const svgLink = document.createElement('a');
                            svgLink.href = data.svg_file;
                            svgLink.textContent = 'Download SVG';
                            svgLink.download = '';
                            downloadLinks.appendChild(svgLink);
                        }

                        uploadBtn.disabled = false;
                    }, 500);
                } catch (err) {
                    progress.style.display = 'none';
                    error.style.display = 'block';
                    error.textContent = `Error: ${err.message}`;
                    uploadBtn.disabled = false;
                }
            });
        </script>
    </body>
    </html>
    """
    return (
        html
        .replace("__ACCESS_NOTE__", access_note)
        .replace("__BACKGROUND_NOTICE__", background_notice)
        .replace("__REMOVE_BG_ATTRS__", remove_bg_attrs)
        .replace("__REMOVE_BG_LABEL__", remove_bg_label)
        .replace("__CONVERT_SVG_ATTRS__", convert_svg_attrs)
        .replace("__CONVERT_SVG_LABEL__", convert_svg_label)
    )
