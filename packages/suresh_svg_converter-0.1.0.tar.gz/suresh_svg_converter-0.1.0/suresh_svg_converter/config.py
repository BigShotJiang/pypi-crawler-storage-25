"""
Configuration settings for the Image to SVG Converter
"""
import os
from pathlib import Path
from typing import Optional


class Settings:
    """Application settings with environment variable support"""
    
    # Base paths
    BASE_DIR = Path(__file__).parent.parent
    OUTPUT_DIR = BASE_DIR / "outputs"
    OUTPUT_DIR.mkdir(exist_ok=True)
    
    # Image processing
    SUPPORTED_FORMATS = {".png", ".jpg", ".jpeg", ".webp"}
    MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
    DEFAULT_OUTPUT_FORMAT = "png"
    
    # Performance settings
    MAX_IMAGE_DIMENSION = 4096  # Resize larger images
    THREAD_POOL_SIZE = 4
    PROCESSING_TIMEOUT = 120  # seconds
    
    # Background removal
    REMBG_MODEL = "u2net"  # Options: u2net, u2netp, u2net_human_seg
    REMBG_ALPHA_MATTING = True
    REMBG_ALPHA_MATTING_ERODE_SIZE = 10
    
    # SVG conversion
    SVG_TURD_SIZE = 2  # Ignore small specks
    SVG_OPTIMIZE = True
    SVG_PRECISION = 3  # Decimal precision
    SVG_DEFAULT_COLORS = 8  # Default layers to trace for color SVG
    
    # Server settings
    HOST = "0.0.0.0"
    PORT = 8000
    DEBUG = os.getenv("DEBUG", "False").lower() == "true"
    
    # Logging
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"


settings = Settings()
