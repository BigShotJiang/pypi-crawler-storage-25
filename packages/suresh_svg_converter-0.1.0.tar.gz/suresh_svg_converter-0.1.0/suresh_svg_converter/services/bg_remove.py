"""
Background removal service using rembg.
"""
import logging
import os
import sys
from importlib import import_module
from importlib.util import find_spec
from pathlib import Path
from typing import Optional, Union

from PIL import Image

from suresh_svg_converter.config import settings

logger = logging.getLogger(__name__)

_remove = None
_new_session = None
REMBG_UNAVAILABLE_REASON = None

if find_spec("rembg") is None:
    REMBG_AVAILABLE = False
    REMBG_UNAVAILABLE_REASON = "rembg is not installed."
else:
    REMBG_AVAILABLE = True
BACKGROUND_REMOVAL_AVAILABLE = REMBG_AVAILABLE


def _load_rembg():
    """Import rembg only when background removal is actually needed."""
    global _remove, _new_session, REMBG_AVAILABLE, REMBG_UNAVAILABLE_REASON

    if _remove is not None and _new_session is not None:
        return _remove, _new_session

    if not REMBG_AVAILABLE:
        raise RuntimeError(REMBG_UNAVAILABLE_REASON or "Background removal is not available.")

    try:
        rembg = import_module("rembg")
    except ImportError as exc:
        REMBG_AVAILABLE = False
        REMBG_UNAVAILABLE_REASON = "rembg is not installed."
        logger.warning("%s", REMBG_UNAVAILABLE_REASON)
        raise RuntimeError(REMBG_UNAVAILABLE_REASON) from exc

    _remove = rembg.remove
    _new_session = rembg.new_session
    return _remove, _new_session


def is_rembg_available() -> bool:
    """Expose background-removal availability for the UI and health endpoints."""
    return REMBG_AVAILABLE


def get_rembg_unavailable_reason() -> Optional[str]:
    """Return the reason background removal is unavailable, if known."""
    return REMBG_UNAVAILABLE_REASON


class BackgroundRemover:
    """
    Singleton class for background removal.

    Reuses the ONNX session for better performance.
    """

    _instance = None
    _session = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    @classmethod
    def get_session(cls):
        """Get or create the ONNX session."""
        if not REMBG_AVAILABLE:
            raise RuntimeError(REMBG_UNAVAILABLE_REASON or "Background removal is not available.")

        if cls._session is None:
            logger.info("Initializing rembg session...")
            _, new_session = _load_rembg()
            cls._session = new_session(
                model_name=settings.REMBG_MODEL,
                providers=["CPUExecutionProvider"],
            )
            logger.info("rembg session initialized with model: %s", settings.REMBG_MODEL)

        return cls._session

    @classmethod
    def reset_session(cls):
        """Reset the session (useful for testing or model changes)."""
        cls._session = None

    def remove_background(
        self,
        image: Union[Image.Image, str, Path, bytes],
        alpha_matting: Optional[bool] = None,
        alpha_matting_erode_size: Optional[int] = None,
    ) -> Image.Image:
        """
        Remove background from an image.

        Args:
            image: PIL Image, file path, or bytes
            alpha_matting: Enable alpha matting for better edges
            alpha_matting_erode_size: Erosion size for alpha matting

        Returns:
            PIL Image with transparent background (RGBA mode)
        """
        if not REMBG_AVAILABLE:
            raise RuntimeError(REMBG_UNAVAILABLE_REASON or "Background removal is not available.")

        if alpha_matting is None:
            alpha_matting = settings.REMBG_ALPHA_MATTING
        if alpha_matting_erode_size is None:
            alpha_matting_erode_size = settings.REMBG_ALPHA_MATTING_ERODE_SIZE

        try:
            if isinstance(image, (str, Path)):
                image = Image.open(image)
            elif isinstance(image, bytes):
                import io
                image = Image.open(io.BytesIO(image))

            logger.debug("Removing background from image: %s", image.size)

            remove, _ = _load_rembg()
            result = remove(
                image,
                session=self.get_session(),
                alpha_matting=alpha_matting,
                alpha_matting_erode_size=alpha_matting_erode_size,
            )

            if result.mode != "RGBA":
                result = result.convert("RGBA")

            logger.info("Background removed successfully")
            return result

        except Exception as exc:
            logger.error("Error removing background: %s", exc)
            raise


def remove_background(
    image: Union[Image.Image, str, Path, bytes],
    **kwargs,
) -> Image.Image:
    """
    Remove background from an image (convenience function).
    """
    remover = BackgroundRemover()
    return remover.remove_background(image, **kwargs)
