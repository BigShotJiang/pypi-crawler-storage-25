"""
Image preprocessing utilities
"""
import cv2
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
from typing import Tuple, Optional
import logging

logger = logging.getLogger(__name__)


def load_image(image_path: str) -> Image.Image:
    """
    Load an image from file path
    
    Args:
        image_path: Path to the image file
        
    Returns:
        PIL Image object
        
    Raises:
        FileNotFoundError: If image doesn't exist
        ValueError: If image format is unsupported
    """
    try:
        img = Image.open(image_path)
        img.verify()  # Verify it's a valid image
        
        # Reopen since verify() closes it
        img = Image.open(image_path)
        
        # Convert to RGB if necessary (handles RGBA, P, etc.)
        if img.mode not in ('RGB', 'RGBA'):
            img = img.convert('RGB')
            
        return img
    except Exception as e:
        logger.error(f"Error loading image {image_path}: {str(e)}")
        raise


def resize_image(
    img: Image.Image,
    max_dimension: int = 4096,
    maintain_aspect: bool = True
) -> Image.Image:
    """
    Resize image if it exceeds maximum dimension
    
    Args:
        img: PIL Image object
        max_dimension: Maximum width or height
        maintain_aspect: Whether to maintain aspect ratio
        
    Returns:
        Resized PIL Image object
    """
    width, height = img.size
    
    if width <= max_dimension and height <= max_dimension:
        return img
    
    if maintain_aspect:
        ratio = min(max_dimension / width, max_dimension / height)
        new_width = int(width * ratio)
        new_height = int(height * ratio)
    else:
        new_width = max_dimension
        new_height = max_dimension
    
    logger.info(f"Resizing image from {width}x{height} to {new_width}x{new_height}")
    return img.resize((new_width, new_height), Image.Resampling.LANCZOS)


def enhance_image(
    img: Image.Image,
    contrast: float = 1.2,
    sharpness: float = 1.5,
    brightness: float = 1.0
) -> Image.Image:
    """
    Apply image enhancements for better edge detection
    
    Args:
        img: PIL Image object
        contrast: Contrast enhancement factor (1.0 = no change)
        sharpness: Sharpening factor (1.0 = no change)
        brightness: Brightness factor (1.0 = no change)
        
    Returns:
        Enhanced PIL Image object
    """
    # Apply contrast
    if contrast != 1.0:
        enhancer = ImageEnhance.Contrast(img)
        img = enhancer.enhance(contrast)
    
    # Apply sharpness
    if sharpness != 1.0:
        enhancer = ImageEnhance.Sharpness(img)
        img = enhancer.enhance(sharpness)
    
    # Apply brightness
    if brightness != 1.0:
        enhancer = ImageEnhance.Brightness(img)
        img = enhancer.enhance(brightness)
    
    return img


def convert_to_binary(
    img: Image.Image,
    threshold: int = 128
) -> np.ndarray:
    """
    Convert image to binary (black and white)
    
    Args:
        img: PIL Image object (grayscale)
        threshold: Threshold value (0-255)
        
    Returns:
        Binary numpy array
    """
    # Convert to grayscale if needed
    if img.mode != 'L':
        img = img.convert('L')
    
    # Convert to numpy array
    img_array = np.array(img)
    
    # Apply threshold
    binary = (img_array > threshold).astype(np.uint8) * 255
    
    return binary


def auto_contrast(img: Image.Image) -> Image.Image:
    """
    Apply automatic contrast enhancement
    
    Args:
        img: PIL Image object
        
    Returns:
        Contrast-enhanced PIL Image object
    """
    return ImageEnhance.Contrast(img).enhance(1.3)


def denoise_image(img: Image.Image) -> Image.Image:
    """
    Apply light denoising to reduce artifacts
    
    Args:
        img: PIL Image object
    
    Returns:
        Denoised PIL Image object
    """
    # Convert to numpy for OpenCV processing
    img_array = np.array(img)
    
    # Apply non-local means denoising
    if len(img_array.shape) == 3:
        denoised = cv2.fastNlMeansDenoisingColored(img_array, None, 10, 10, 7, 21)
    else:
        denoised = cv2.fastNlMeansDenoising(img_array, None, 10, 7, 21)
    
    return Image.fromarray(denoised)


def crop_to_foreground(img: Image.Image, threshold: int = 10, padding: int = 10) -> Image.Image:
    """
    Crop the image to the visible foreground object.

    Args:
        img: PIL Image object
        threshold: Alpha threshold to determine visible pixels
        padding: Padding around the bounding box

    Returns:
        Cropped PIL Image object containing the foreground object
    """
    if img.mode == 'RGBA':
        alpha = np.array(img.split()[-1])
        mask = alpha >= threshold
    else:
        gray = np.array(img.convert('L'))
        mask = gray > threshold

    coords = np.column_stack(np.where(mask))
    if coords.size == 0:
        return img

    y0, x0 = coords.min(axis=0)
    y1, x1 = coords.max(axis=0)

    x0 = max(x0 - padding, 0)
    y0 = max(y0 - padding, 0)
    x1 = min(x1 + padding, img.width - 1)
    y1 = min(y1 + padding, img.height - 1)

    return img.crop((x0, y0, x1 + 1, y1 + 1))


def preprocess_for_svg(
    img: Image.Image,
    max_dim: int = 4096,
    enhance: bool = True
) -> Tuple[Image.Image, dict]:
    """
    Complete preprocessing pipeline for SVG conversion
    
    Args:
        img: PIL Image object
        max_dim: Maximum dimension for resizing
        enhance: Whether to apply enhancements
        
    Returns:
        Tuple of (preprocessed image, metadata dict)
    """
    metadata = {
        'original_size': img.size,
        'resized': False
    }
    
    # Step 1: Resize if needed
    img = resize_image(img, max_dim)
    if img.size != metadata['original_size']:
        metadata['resized'] = True
        metadata['new_size'] = img.size

    # Step 1.5: DO NOT crop to the object foreground so SVG matches PNG dimensions.
    metadata['cropped'] = False

    # Convert alpha images to RGB for preprocessing
    if img.mode == 'RGBA':
        background = Image.new('RGB', img.size, (255, 255, 255))
        background.paste(img, mask=img.split()[3])
        img = background
    elif img.mode != 'RGB':
        img = img.convert('RGB')

    # Step 2: Denoise
    img = denoise_image(img)
    
    # Step 3: Enhance
    if enhance:
        img = enhance_image(img, contrast=1.2, sharpness=1.5)
    
    metadata['final_size'] = img.size
    
    return img, metadata
