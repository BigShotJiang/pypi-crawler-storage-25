"""
SVG conversion service using potrace
"""
import logging
import tempfile
import os
from pathlib import Path
from typing import Union, Optional
from types import SimpleNamespace
from PIL import Image
import numpy as np
import cv2

try:
    import potrace
    POTRACE_AVAILABLE = True
    logging.info("Native potrace library loaded successfully")
except ImportError:
    POTRACE_AVAILABLE = False
    logging.warning("potrace not installed. SVG conversion will use OpenCV contour fallback.")

try:
    import svgwrite
    SVGWRITE_AVAILABLE = True
except ImportError:
    SVGWRITE_AVAILABLE = False
    logging.warning("svgwrite not installed. SVG conversion disabled.")

from suresh_svg_converter.config import settings

logger = logging.getLogger(__name__)
SVG_CONVERSION_AVAILABLE = SVGWRITE_AVAILABLE


class SVGConverter:
    """Convert raster images to SVG vector format"""
    
    @staticmethod
    def _quantize_image(img_array: np.ndarray, num_colors: int) -> tuple[np.ndarray, np.ndarray]:
        """Quantize an image to a specific number of colors using K-Means"""
        pixels = img_array.reshape((-1, 3))
        pixels = np.float32(pixels)

        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.2)
        _, labels, centers = cv2.kmeans(pixels, num_colors, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)

        centers = np.uint8(centers)
        labels = labels.flatten()
        return labels.reshape(img_array.shape[:2]), centers

    @staticmethod
    def image_to_color_layers(img: Image.Image, num_colors: int = 8) -> list:
        """
        Convert PIL Image to multiple binary bitmaps, one for each quantized color.
        """
        # Handle alpha
        alpha_mask = None
        if img.mode in ('RGBA', 'LA'):
            alpha_mask = np.array(img.split()[-1])
            alpha_mask = alpha_mask > 20  # Use lower threshold to not lose edges
            img = img.convert('RGB')
        else:
            img = img.convert('RGB')
            
        img_array = np.array(img)
        
        # Apply slight blur to reduce noise
        blurred = cv2.GaussianBlur(img_array, (3, 3), 0)
        
        # Quantize colors
        labels, centers = SVGConverter._quantize_image(blurred, num_colors)
        
        layers = []
        for i, center in enumerate(centers):
            # Create mask for this color
            mask = (labels == i)
            
            # Apply alpha mask if present
            if alpha_mask is not None:
                mask = mask & alpha_mask
                
            # Skip if layer is empty after alpha masking
            if not np.any(mask):
                continue
                
            hex_color = f"#{center[0]:02x}{center[1]:02x}{center[2]:02x}"
            bitmap = mask.astype(np.float64)
            
            layers.append({
                'color': hex_color,
                'bitmap': bitmap,
                'pixel_count': np.sum(mask)
            })
            
        # Sort layers to draw larger shapes first
        layers.sort(key=lambda x: x['pixel_count'], reverse=True)
        return layers

    @staticmethod
    def image_to_bitmap(img: Image.Image) -> np.ndarray:
        """
        Convert PIL Image to binary bitmap for potrace or contour tracing (Monochrome fallback).
        """
        if img.mode in ('RGBA', 'LA'):
            alpha = np.array(img.split()[-1])
            alpha = ((alpha / 255.0) > 0.5).astype(np.float64)
            return alpha

        if img.mode != 'L':
            img = img.convert('L')
        
        img_array = np.array(img)
        blurred = cv2.GaussianBlur(img_array, (5, 5), 0)
        _, binary = cv2.threshold(blurred, 128, 255, cv2.THRESH_BINARY_INV)
        
        bitmap = (binary / 255.0).astype(np.float64)
        return bitmap
    
    @staticmethod
    def trace_bitmap(bitmap: np.ndarray) -> Union["potrace.Bitmap", SimpleNamespace]:
        """
        Trace bitmap using potrace if available, otherwise fallback to OpenCV contours.
        """
        if POTRACE_AVAILABLE:
            pm = potrace.Bitmap(bitmap)
            pm.process()
            logger.debug(f"Native potrace tracing successful: {len(pm.curves)} curves")
            return pm

        logger.warning("Falling back to OpenCV contour tracing (reduced accuracy)")
        return SVGConverter._trace_bitmap_fallback(bitmap)

    @staticmethod
    def _trace_bitmap_fallback(bitmap: np.ndarray) -> SimpleNamespace:
        """Fallback tracing using OpenCV contours when potrace is unavailable."""
        binary = (bitmap * 255).astype(np.uint8)
        contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        return SimpleNamespace(size=bitmap.shape, curves=contours, is_potrace=False)
    
    @staticmethod
    def save_to_svg(
        pm: Union["potrace.Bitmap", SimpleNamespace],
        output_path: Union[str, Path],
        turdsize: Optional[int] = None,
        optimize: bool = True
    ) -> Path:
        """ Backward compatibility for single color save """
        return SVGConverter.save_to_svg_multicolor(
            traced_layers=[{'color': '#000000', 'traced': pm}],
            size=(pm.size[1], pm.size[0]),
            output_path=output_path,
            turdsize=turdsize,
            optimize=optimize
        )

    @staticmethod
    def save_to_svg_multicolor(
        traced_layers: list,
        size: tuple,
        output_path: Union[str, Path],
        turdsize: Optional[int] = None,
        optimize: bool = True
    ) -> Path:
        """ Save traced multiple layers to an SVG file """
        if not SVGWRITE_AVAILABLE:
            raise RuntimeError("svgwrite library is not installed")
        
        output_path = Path(output_path)
        turdsize = turdsize or settings.SVG_TURD_SIZE
        width, height = size
        
        dwg = svgwrite.Drawing(
            str(output_path),
            size=("100%", "100%"),
            profile='full'
        )
        dwg.viewbox(0, 0, width, height)
        
        for layer in traced_layers:
            color = layer['color']
            pm = layer['traced']
            
            all_path_data = []
            if getattr(pm, 'is_potrace', True):
                for curve in pm.curves:
                    if len(curve) < turdsize:
                        continue
                        
                    path_data = []
                    for segment in curve:
                        if segment.is_corner:
                            if not path_data:
                                path_data.append(f"M {segment.start_point[1]},{segment.start_point[0]}")
                            path_data.append(f"L {segment.end_point[1]},{segment.end_point[0]}")
                        else:
                            if not path_data:
                                path_data.append(f"M {segment.start_point[1]},{segment.start_point[0]}")
                            c1 = segment.c1
                            c2 = segment.c2
                            end = segment.end_point
                            path_data.append(f"C {c1[1]},{c1[0]} {c2[1]},{c2[0]} {end[1]},{end[0]}")
                    
                    if path_data:
                        path_data.append("Z")
                        all_path_data.append(" ".join(path_data))
            else:
                for contour in pm.curves:
                    pts = contour.reshape(-1, 2)
                    if len(pts) < turdsize:
                        continue
                    path_data = [f"M {pts[0][0]},{pts[0][1]}"]
                    path_data += [f"L {pt[0]},{pt[1]}" for pt in pts[1:]]
                    path_data.append("Z")
                    all_path_data.append(" ".join(path_data))
            
            if all_path_data:
                stroke_color = color if len(traced_layers) > 1 else "none"
                stroke_width = "0.5" if len(traced_layers) > 1 else "0"
                
                dwg.add(
                    dwg.path(
                        d=" ".join(all_path_data),
                        fill=color,
                        stroke=stroke_color,
                        stroke_width=stroke_width,
                        fill_rule="evenodd"
                    )
                )
        
        dwg.save()
        logger.info(f"SVG saved to {output_path}")
        return output_path
    
    def convert(
        self,
        image: Union[Image.Image, str, Path],
        output_path: Union[str, Path],
        preprocess: bool = True,
        num_colors: int = getattr(settings, 'SVG_DEFAULT_COLORS', 8)
    ) -> Path:
        """
        Complete conversion pipeline: image → bitmap(s) → trace → SVG
        """
        try:
            if isinstance(image, (str, Path)):
                image = Image.open(image)
            
            logger.info(f"Converting image to SVG: {image.size} with {num_colors} colors")
            
            if num_colors > 1:
                # Multi-color tracing
                layers = self.image_to_color_layers(image, num_colors=num_colors)
                traced_layers = []
                for layer in layers:
                    traced = self.trace_bitmap(layer['bitmap'])
                    traced_layers.append({
                        'color': layer['color'],
                        'traced': traced
                    })
                    logger.debug(f"Traced color layer {layer['color']}: {len(traced.curves)} curves")
                
                svg_path = self.save_to_svg_multicolor(
                    traced_layers=traced_layers,
                    size=image.size,
                    output_path=output_path
                )
            else:
                # Monochrome backward compatible tracing
                bitmap = self.image_to_bitmap(image)
                traced = self.trace_bitmap(bitmap)
                svg_path = self.save_to_svg(traced, output_path)
            
            return svg_path
            
        except Exception as e:
            logger.error(f"Error converting to SVG: {str(e)}")
            raise

# Convenience function
def convert_to_svg(
    image: Union[Image.Image, str, Path],
    output_path: Union[str, Path],
    **kwargs
) -> Path:
    converter = SVGConverter()
    return converter.convert(image, output_path, **kwargs)
