"""
Services package initialization
"""
