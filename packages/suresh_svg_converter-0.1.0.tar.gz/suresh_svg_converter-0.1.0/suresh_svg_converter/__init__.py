"""
Package initialization for app module
"""
from suresh_svg_converter.main import app  # noqa: F401

