# 🖼️ Suresh SVG Converter

A professional, production-ready Python package for removing backgrounds from images and converting them to high-quality multi-color SVG format.

[![PyPI version](https://badge.fury.io/py/suresh-svg-converter.svg)](https://pypi.org/project/suresh-svg-converter/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## ✨ Features

- **Background Removal**: AI-powered background removal using `rembg` with ONNX runtime.
- **Accurate SVG Conversion**: High-quality vector tracing using `potrace` with **multi-color support**.
- **Color Quantization**: Automatically detects dominant colors and creates stratified SVG layers.
- **Dual Interface**: Full-featured Command Line Interface (CLI) and a beautiful FastAPI web UI.
- **CPU Optimized**: Runs entirely on CPU with no GPU dependency.
- **Fast Performance**: Optimized for speed with lazy model loading and K-Means quantization.
- **Batch Processing**: Process multiple images at once via CLI.

## 📋 Requirements

- Python 3.9+
- 2GB+ RAM recommended for high-resolution processing.

## 🚀 Installation

Install the package directly from PyPI:

```bash
pip install suresh-svg-converter
```

## 🖥️ Usage

### Command Line Interface (CLI)

Once installed, use the `suresh-svg-converter` command anywhere:

**Basic usage**:
```bash
suresh-svg-converter input.jpg
```

**With options**:
```bash
# Convert with 16 colors and remove background
suresh-svg-converter input.png --remove-bg --colors 16

# Custom output directory
suresh-svg-converter *.png -o ./results

# Batch process multiple files
suresh-svg-converter img1.jpg img2.webp img3.png
```

**CLI Options**:
- `--remove-bg, -r`: Remove background (default: enabled)
- `--colors, -c`: Number of colors for SVG tracing (default: 8)
- `--output-dir, -o`: Custom output directory
- `--max-dim`: Maximum image dimension for processing (default: 4096)
- `--verbose, -v`: Enable verbose logging

### Web Interface

Launch the interactive web UI to drag and drop images:

```bash
python -m suresh_svg_converter.main
```
Or use uvicorn directly:
```bash
uvicorn suresh_svg_converter.main:app --host 0.0.0.0 --port 8000
```

Then open `http://localhost:8000` in your browser.

### Programmatic API

Use the converter in your own Python projects:

```python
from suresh_svg_converter.services.svg_convert import SVGConverter
from suresh_svg_converter.services.bg_remove import BackgroundRemover
from PIL import Image

# Load image
img = Image.open("photo.jpg")

# Remove background
remover = BackgroundRemover()
img_no_bg = remover.remove_background(img)

# Convert to SVG with 12 colors
converter = SVGConverter()
svg_path = converter.convert(img_no_bg, "output.svg", num_colors=12)

print(f"Vector saved to: {svg_path}")
```

## 📁 Project Structure

```
suresh_svg_converter/
├── cli.py                   # Main CLI entry point
├── main.py                  # FastAPI web application
├── config.py                # Configuration settings
├── services/
│   ├── bg_remove.py         # Background removal service
│   ├── svg_convert.py       # Multi-color SVG conversion
│   └── image_utils.py       # Image preprocessing
├── routes/
│   └── upload.py            # API routes
└── models/
    └── image_models.py      # Data schemas
```

## ⚙️ Configuration

You can customize the default behavior in `suresh_svg_converter/config.py`:

- `SVG_DEFAULT_COLORS`: Default number of color layers (default: 8)
- `MAX_IMAGE_DIMENSION`: Resize limit for performance
- `REMBG_MODEL`: Choose between `u2net`, `u2netp`, etc.

## 📝 License

MIT License - See [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [rembg](https://github.com/danielgatis/rembg) for background removal.
- [potrace](http://potrace.sourceforge.net/) for vector tracing.
- [FastAPI](https://fastapi.tiangolo.com/) for the web interface.

---
Built with ❤️ for the developer community.
