# -*- coding: utf-8 -*-
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# %                                                                   LogHandling Module - Classes and Functions                                                            %
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
"""
Classes and function to support logging
 
@note: PyXMake module                   
Created on 07.01.2026

@version:  1.0    
----------------------------------------------------------------------------------------------
@requires:
       - 

@change: 
       -    
   
@author: garb_ma                                                                          [DLR-SY,STM Braunschweig]
----------------------------------------------------------------------------------------------
"""

## @package PyXMake.Tools.LogHandling
# Logging handling module.
## @author 
# Marc Garbade
## @date
# 07.01.2026

import sys
import logging #@UnusedImport
import logging.config

class LoggingFilter(logging.Filter):
    """
    Base class to filter certain events during logging
    """    
    def __init__(self, *args, **kwargs):

        super(LoggingFilter, self).__init__(*args)
        self.__dict__.update(kwargs)
    
    def filter(self, record):
        """
        Only lets through log messages with log level below ERROR .
        """
        return eval(self.condition)

default_config = {
    'version': 1,
    'filters': {
        'exclude_info': {
            '()':  LoggingFilter,
            'condition' : "record.levelno != logging.INFO",
        },
        'only_info': {
            '()': LoggingFilter,
            'condition' : "record.levelno == logging.INFO",
        }
    },
    'handlers': {
        'console_stderr': {
            # Sends log messages with log level ERROR or higher to stderr
            'class': 'logging.StreamHandler',
            'level': 'DEBUG',
            'filters': ['exclude_info'],
            'stream': sys.stderr
        },
        'console_stdout': {
            # Sends log messages with log level lower than ERROR to stdout
            'class': 'logging.StreamHandler',
            'level': 'INFO',
            'filters': ['only_info'],
            'stream': sys.stdout
        }
    },
    'root': {
        # In general, this should be kept at 'NOTSET'.
        # Otherwise it would interfere with the log levels set for each handler.
        'level': 'INFO',
        'handlers': ['console_stderr', 'console_stdout']
    },
}

# Define a default logger
logging.config.dictConfig(default_config)
logger = logging.getLogger(__name__)

if __name__ == '__main__':
    pass        
