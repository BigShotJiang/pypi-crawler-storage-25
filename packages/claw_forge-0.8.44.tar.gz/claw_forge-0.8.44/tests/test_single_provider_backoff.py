"""Pin ``ProviderPoolManager.enabled_provider_count`` (v0.8.44).

Reports the number of providers currently enabled in config (ignoring
circuit-breaker state).  Defensive helper for callers that need to
branch on "single-provider config" vs "multi-provider pool" — e.g.
deciding whether rotation is even a meaningful response to a transient
error.  Kept narrow: doesn't factor in runtime health, just static
config — so it's safe to call from any context without a refresh.
"""

from __future__ import annotations

from claw_forge.pool.manager import ProviderPoolManager
from claw_forge.pool.providers.base import ProviderConfig, ProviderType


def _cfg(name: str, *, enabled: bool = True) -> ProviderConfig:
    return ProviderConfig(
        name=name, provider_type=ProviderType.ANTHROPIC, api_key="k",
        enabled=enabled,
    )


def test_enabled_provider_count_returns_zero_for_empty_pool() -> None:
    """A pool with no providers reports zero."""
    pool = ProviderPoolManager([])
    assert pool.enabled_provider_count() == 0


def test_enabled_provider_count_returns_one_for_single_enabled() -> None:
    """A pool with one enabled provider reports one — the trigger
    condition for the v0.8.44 in-place backoff path."""
    pool = ProviderPoolManager([_cfg("p1")])
    assert pool.enabled_provider_count() == 1


def test_enabled_provider_count_ignores_disabled_providers() -> None:
    """Disabled providers don't count toward the rotation pool — a
    single ENABLED + N DISABLED still counts as 1 for backoff
    decision purposes."""
    pool = ProviderPoolManager(
        [_cfg("p1"), _cfg("p2", enabled=False), _cfg("p3", enabled=False)],
    )
    assert pool.enabled_provider_count() == 1


def test_enabled_provider_count_returns_multiple_when_multiple_enabled(
) -> None:
    """N>1 enabled providers → normal rotation path stays active."""
    pool = ProviderPoolManager([_cfg("p1"), _cfg("p2"), _cfg("p3")])
    assert pool.enabled_provider_count() == 3


