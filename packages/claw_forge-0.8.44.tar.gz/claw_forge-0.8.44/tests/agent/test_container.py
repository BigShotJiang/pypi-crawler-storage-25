"""Tests for ``claw_forge.agent.container`` — Level 4 opt-in container
isolation (v0.8.19).  Covers runtime detection, image-existence
checks, wrapper-script generation, and the fail-fast behaviours that
prevent silent fallback when the operator opted in.

The wrapper-script tests don't actually run ``docker`` — they
inspect the generated script's contents to verify mounts, env
forwarding, and arg pass-through.  Tests requiring a real container
runtime are gated on docker/podman availability.
"""
from __future__ import annotations

import os
import shutil
import stat
from pathlib import Path
from unittest.mock import patch

import pytest

from claw_forge.agent.container import (
    _AUTH_ENV_VARS,
    _DEFAULT_AGENT_DOCKERFILE,
    _SAFETY_ENV_VARS,
    _hash_dockerfile_content,
    detect_runtime,
    image_exists,
    make_container_wrapper,
    resolve_auto_container_image,
    write_container_wrapper,
)


class TestDetectRuntime:
    def test_auto_returns_docker_when_available(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """``"auto"`` prefers docker (the more common default) over podman."""
        monkeypatch.setattr(
            "claw_forge.agent.container.shutil.which",
            lambda name: "/usr/local/bin/docker" if name == "docker" else None,
        )
        assert detect_runtime("auto") == "docker"

    def test_auto_falls_through_to_podman(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """When docker isn't available but podman is, auto picks podman."""
        monkeypatch.setattr(
            "claw_forge.agent.container.shutil.which",
            lambda name: "/usr/bin/podman" if name == "podman" else None,
        )
        assert detect_runtime("auto") == "podman"

    def test_auto_returns_none_when_neither_available(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """No runtime → ``None``; caller decides what to do."""
        monkeypatch.setattr(
            "claw_forge.agent.container.shutil.which", lambda name: None,
        )
        assert detect_runtime("auto") is None

    def test_explicit_docker_requires_docker(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """``"docker"`` returns docker if available, else ``None`` —
        does NOT fall through to podman."""
        monkeypatch.setattr(
            "claw_forge.agent.container.shutil.which",
            lambda name: "/usr/bin/podman" if name == "podman" else None,
        )
        assert detect_runtime("docker") is None

    def test_explicit_podman_requires_podman(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setattr(
            "claw_forge.agent.container.shutil.which",
            lambda name: "/usr/local/bin/docker" if name == "docker" else None,
        )
        assert detect_runtime("podman") is None


class TestImageExists:
    def test_returns_false_on_subprocess_error(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Image inspection failure (image not found, daemon not
        running, anything) → ``False``.  Best-effort check; caller
        decides whether to pull or fail."""
        import subprocess

        def fake_run(*args: object, **kwargs: object) -> object:
            raise subprocess.CalledProcessError(
                1, ["docker", "image", "inspect", "x"],
            )

        monkeypatch.setattr(
            "claw_forge.agent.container.subprocess.run", fake_run,
        )
        assert image_exists("docker", "nonexistent:latest") is False

    def test_returns_true_on_success(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        from subprocess import CompletedProcess

        def fake_run(*args: object, **kwargs: object) -> object:
            return CompletedProcess(args=[], returncode=0, stdout="", stderr="")

        monkeypatch.setattr(
            "claw_forge.agent.container.subprocess.run", fake_run,
        )
        assert image_exists("docker", "real-image:latest") is True


class TestWriteContainerWrapper:
    """Generated wrapper script contract — mounts, env vars,
    workdir, arg pass-through.  No docker invocation; we just
    inspect the script's contents."""

    @pytest.fixture
    def setup(self, tmp_path: Path) -> tuple[Path, Path]:
        """Return ``(worktree_path, output_dir)``."""
        worktree = tmp_path / "wt"
        worktree.mkdir()
        return worktree, tmp_path / "out"

    def test_wrapper_is_executable(
        self, setup: tuple[Path, Path],
    ) -> None:
        worktree, out = setup
        wrapper = write_container_wrapper(
            runtime="docker", image="my-img",
            worktree_path=worktree, output_dir=out,
        )
        assert wrapper.exists()
        assert os.access(wrapper, os.X_OK)
        assert wrapper.stat().st_mode & stat.S_IXUSR

    def test_wrapper_mounts_worktree_to_workspace(
        self, setup: tuple[Path, Path],
    ) -> None:
        """The single critical mount: worktree → /workspace.  The
        agent's cwd inside the container is /workspace; without this
        mount the agent has no way to read its own files."""
        worktree, out = setup
        wrapper = write_container_wrapper(
            runtime="docker", image="my-img",
            worktree_path=worktree, output_dir=out,
        )
        content = wrapper.read_text()
        # Use resolved path so symlinks (e.g. /tmp → /private/tmp on
        # macOS) match what's actually written into the wrapper.
        assert f'-v "{worktree.resolve()}":/workspace' in content
        assert "--workdir /workspace" in content

    def test_wrapper_passes_anthropic_auth_env_vars(
        self, setup: tuple[Path, Path],
    ) -> None:
        """Container needs Anthropic auth to reach the API.  All
        three auth env vars are forwarded by name (the container
        reads the host's current value at run-time)."""
        worktree, out = setup
        wrapper = write_container_wrapper(
            runtime="docker", image="my-img",
            worktree_path=worktree, output_dir=out,
        )
        content = wrapper.read_text()
        for var in _AUTH_ENV_VARS:
            assert f"-e {var}" in content

    def test_wrapper_does_not_mount_parent_project(
        self, setup: tuple[Path, Path],
    ) -> None:
        """The Level 4 promise: parent project absent from container's
        filesystem namespace.  Wrapper must not have a ``-v <parent>``
        mount that would re-introduce the leak surface."""
        worktree, out = setup
        wrapper = write_container_wrapper(
            runtime="docker", image="my-img",
            worktree_path=worktree, output_dir=out,
        )
        content = wrapper.read_text()
        # Parent project is the worktree's parent directory.
        parent = worktree.parent.resolve()
        assert f'-v "{parent}":' not in content

    def test_wrapper_passes_args_through(
        self, setup: tuple[Path, Path],
    ) -> None:
        """SDK invokes ``<wrapper> <claude_args>``; wrapper must pass
        ``"$@"`` to claude inside the container so the SDK's args
        reach the agent verbatim."""
        worktree, out = setup
        wrapper = write_container_wrapper(
            runtime="docker", image="my-img",
            worktree_path=worktree, output_dir=out,
        )
        content = wrapper.read_text()
        assert "claude" in content
        assert '"$@"' in content

    def test_extra_mounts_are_added(
        self, setup: tuple[Path, Path],
    ) -> None:
        """Operator-supplied extra mounts (test fixtures, language
        toolchains, etc.) appear as additional ``-v`` flags."""
        worktree, out = setup
        wrapper = write_container_wrapper(
            runtime="docker", image="my-img",
            worktree_path=worktree, output_dir=out,
            extra_mounts=["/host/cache:/cache:ro"],
        )
        assert '-v "/host/cache:/cache:ro"' in wrapper.read_text()

    def test_extra_env_vars_are_forwarded(
        self, setup: tuple[Path, Path],
    ) -> None:
        """Beyond the auth set, operator can add domain env vars."""
        worktree, out = setup
        wrapper = write_container_wrapper(
            runtime="docker", image="my-img",
            worktree_path=worktree, output_dir=out,
            extra_env=["MY_PROJECT_TOKEN", "TEST_ENV"],
        )
        content = wrapper.read_text()
        assert "-e MY_PROJECT_TOKEN" in content
        assert "-e TEST_ENV" in content

    def test_safety_env_vars_are_forwarded(
        self, setup: tuple[Path, Path],
    ) -> None:
        """v0.8.33: npm/pnpm/yarn safety env vars are forwarded by name
        so the dispatcher's ``npm_config_ignore_scripts=true`` policy
        reaches the in-container package managers.  Docker reads the
        wrapper's runtime env when the value isn't pinned, so the
        setting flows from sdk_env → wrapper subprocess → container."""
        worktree, out = setup
        wrapper = write_container_wrapper(
            runtime="docker", image="my-img",
            worktree_path=worktree, output_dir=out,
        )
        content = wrapper.read_text()
        for var in _SAFETY_ENV_VARS:
            assert f"-e {var}" in content

    def test_safety_env_vars_cover_npm_and_yarn(self) -> None:
        """Lock down the safety-env list — silent removal of either
        would weaken the npm-supply-chain defence to a half-measure."""
        assert "npm_config_ignore_scripts" in _SAFETY_ENV_VARS
        assert "YARN_ENABLE_SCRIPTS" in _SAFETY_ENV_VARS

    def test_runtime_is_used_in_wrapper(
        self, setup: tuple[Path, Path],
    ) -> None:
        """Podman wrapper uses ``podman run``, not ``docker run`` —
        the wrapper is portable across both runtimes."""
        worktree, out = setup
        wrapper = write_container_wrapper(
            runtime="podman", image="my-img",
            worktree_path=worktree, output_dir=out,
        )
        content = wrapper.read_text()
        assert "podman run" in content
        assert "docker run" not in content


class TestMakeContainerWrapper:
    """High-level entrypoint contract: fail-fast on missing runtime
    or image, no silent fallback when operator opted in."""

    def test_raises_when_runtime_missing(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Operator set ``isolation: container`` → silent fallback to
        weaker isolation would violate their explicit choice.  Raise
        with a clear message instead."""
        monkeypatch.setattr(
            "claw_forge.agent.container.shutil.which", lambda name: None,
        )
        with pytest.raises(RuntimeError, match="requires"):
            make_container_wrapper(
                worktree_path=tmp_path / "wt",
                output_dir=tmp_path / "out",
                image="my-img",
            )

    def test_raises_when_image_missing_and_pull_disabled(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Default ``pull_if_missing: false`` — operator controls image
        sourcing.  Quietly pulling from a registry the operator didn't
        approve would be a security surprise."""
        monkeypatch.setattr(
            "claw_forge.agent.container.detect_runtime",
            lambda pref: "docker",
        )
        monkeypatch.setattr(
            "claw_forge.agent.container.image_exists", lambda r, i: False,
        )
        (tmp_path / "wt").mkdir()
        with pytest.raises(RuntimeError, match="not found"):
            make_container_wrapper(
                worktree_path=tmp_path / "wt",
                output_dir=tmp_path / "out",
                image="missing:latest",
            )

    def test_attempts_pull_when_pull_if_missing_true(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Opt-in pull: ``pull_if_missing: true`` triggers a single
        ``docker pull`` attempt; success → wrapper, failure → raise."""
        from subprocess import CompletedProcess

        pull_calls: list[list[str]] = []

        def fake_run(args: list[str], **kw: object) -> object:
            pull_calls.append(args)
            return CompletedProcess(args=args, returncode=0, stdout="", stderr="")

        monkeypatch.setattr(
            "claw_forge.agent.container.detect_runtime",
            lambda pref: "docker",
        )
        monkeypatch.setattr(
            "claw_forge.agent.container.image_exists", lambda r, i: False,
        )
        monkeypatch.setattr(
            "claw_forge.agent.container.subprocess.run", fake_run,
        )
        (tmp_path / "wt").mkdir()
        wrapper = make_container_wrapper(
            worktree_path=tmp_path / "wt",
            output_dir=tmp_path / "out",
            image="will-pull:latest",
            pull_if_missing=True,
        )
        assert wrapper.exists()
        assert any(a[0:2] == ["docker", "pull"] for a in pull_calls)

    def test_returns_wrapper_when_image_present(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Happy path: runtime + image both available → wrapper
        written, no pull attempted."""
        monkeypatch.setattr(
            "claw_forge.agent.container.detect_runtime",
            lambda pref: "docker",
        )
        monkeypatch.setattr(
            "claw_forge.agent.container.image_exists", lambda r, i: True,
        )
        (tmp_path / "wt").mkdir()
        wrapper = make_container_wrapper(
            worktree_path=tmp_path / "wt",
            output_dir=tmp_path / "out",
            image="present:latest",
        )
        assert wrapper.exists()
        assert os.access(wrapper, os.X_OK)


@pytest.mark.skipif(
    shutil.which("docker") is None,
    reason="docker required for end-to-end container test",
)
class TestEndToEndDockerAvailable:
    """Integration tests that actually run docker — gated on
    docker availability so they skip cleanly on CI runners
    without a daemon."""

    def test_detect_runtime_finds_docker(self) -> None:
        """When docker is on PATH AND the daemon is running, detect
        succeeds.  This is the smoke test that ``v0.8.19`` is
        usable on this host."""
        with patch("claw_forge.agent.container.shutil.which", wraps=shutil.which):
            assert detect_runtime("docker") == "docker"


# ─────────────────────────────────────────────────────────────────────────
# v0.8.34 auto-build — claw-forge init --container scaffolds the
# Dockerfile, the dispatcher hashes it and builds lazily on first run.
# ─────────────────────────────────────────────────────────────────────────


class TestHashDockerfileContent:
    """Content-hash function — deterministic + sensitive to edits."""

    def test_stable_for_same_content(self) -> None:
        """Same content → same hash.  Required for cache lookups to be
        deterministic across machines + processes."""
        c = "FROM node:20\nRUN apt-get update\n"
        assert _hash_dockerfile_content(c) == _hash_dockerfile_content(c)

    def test_changes_when_content_changes(self) -> None:
        """Editing the Dockerfile produces a new tag so the dispatcher's
        next-run cache check misses and rebuilds.  No coordination with
        an external invalidation signal needed."""
        a = "FROM node:20-slim\n"
        b = "FROM node:22-slim\n"  # single char diff
        assert _hash_dockerfile_content(a) != _hash_dockerfile_content(b)

    def test_returns_12_hex_chars(self) -> None:
        """Pinned at 12 — changing the length invalidates every cached
        image on existing installations and forces a one-time rebuild
        on upgrade.  We don't want to break this contract accidentally."""
        result = _hash_dockerfile_content("FROM scratch\n")
        assert len(result) == 12
        assert all(c in "0123456789abcdef" for c in result)


class TestDefaultAgentDockerfile:
    """Pin the Dockerfile contract — the template that ``init
    --container`` materialises and the dispatcher hashes."""

    def test_uses_node_base_image(self) -> None:
        """Default base is node:20-slim because the claude CLI is a
        Node package.  Operators with non-Node stacks customise; this
        test pins the default that ships."""
        assert "FROM node:20-slim" in _DEFAULT_AGENT_DOCKERFILE

    def test_installs_claude_code_cli(self) -> None:
        """The container's whole job is to run the claude CLI; without
        this install line the wrapper's ``claude "$@"`` fails."""
        assert "@anthropic-ai/claude-code" in _DEFAULT_AGENT_DOCKERFILE

    def test_creates_unprivileged_user(self) -> None:
        """Run as ``agent`` not root — defence-in-depth against
        container-escape exploits and matches the Dockerfile docs."""
        assert "useradd -m agent" in _DEFAULT_AGENT_DOCKERFILE
        assert "USER agent" in _DEFAULT_AGENT_DOCKERFILE

    def test_workdir_is_workspace(self) -> None:
        """The wrapper mounts the worktree at ``/workspace``; the
        Dockerfile's WORKDIR must match so the agent's cwd inside the
        container is the worktree."""
        assert "WORKDIR /workspace" in _DEFAULT_AGENT_DOCKERFILE

    def test_no_entrypoint_directive(self) -> None:
        """No ``ENTRYPOINT`` Dockerfile directive — the wrapper appends
        ``claude "$@"`` so the SDK's args reach the agent verbatim.
        Setting an ENTRYPOINT would mangle the arg-passing chain.

        We check for the directive (line starting with ``ENTRYPOINT``)
        rather than the word, because the template's *comment* explains
        why there's no entrypoint and naturally mentions it."""
        directive_lines = [
            line for line in _DEFAULT_AGENT_DOCKERFILE.splitlines()
            if line.strip().startswith("ENTRYPOINT")
        ]
        assert not directive_lines


class TestResolveAutoContainerImage:
    """Auto-build resolver: hash → lookup → build (if missing) → return tag."""

    @pytest.fixture
    def project_with_dockerfile(self, tmp_path: Path) -> Path:
        """Project root with ``.claw-forge/agent.Dockerfile`` containing
        the default template — the state ``claw-forge init --container``
        produces."""
        (tmp_path / ".claw-forge").mkdir()
        dockerfile = tmp_path / ".claw-forge" / "agent.Dockerfile"
        dockerfile.write_text(_DEFAULT_AGENT_DOCKERFILE)
        return tmp_path

    def test_errors_without_dockerfile(self, tmp_path: Path) -> None:
        """Operator set ``isolation: container`` + left image empty but
        forgot to run ``init --container``.  Error must point at the
        fix, not just say "file not found"."""
        with patch(
            "claw_forge.agent.container.detect_runtime",
            return_value="docker",
        ), pytest.raises(RuntimeError, match="init --container"):
            resolve_auto_container_image(tmp_path)

    def test_errors_without_runtime(self, project_with_dockerfile: Path) -> None:
        """No docker / podman on PATH but operator asked for container
        mode.  Don't silently fall back to sandbox — the operator opted
        in, fail loudly with installation pointers."""
        with patch(
            "claw_forge.agent.container.detect_runtime", return_value=None,
        ), pytest.raises(RuntimeError, match="Docker or Podman"):
            resolve_auto_container_image(project_with_dockerfile)

    def test_returns_content_hashed_tag(
        self, project_with_dockerfile: Path,
    ) -> None:
        """Tag is ``claw-forge-agent:<sha256[:12]>`` — readable in
        ``docker images`` output and deterministic across machines."""
        expected_hash = _hash_dockerfile_content(_DEFAULT_AGENT_DOCKERFILE)
        with patch(
            "claw_forge.agent.container.detect_runtime", return_value="docker",
        ), patch(
            "claw_forge.agent.container.image_exists", return_value=True,
        ):
            tag = resolve_auto_container_image(project_with_dockerfile)
        assert tag == f"claw-forge-agent:{expected_hash}"

    def test_skips_build_when_image_exists(
        self, project_with_dockerfile: Path,
    ) -> None:
        """Cache hit: image already built locally.  Don't invoke ``docker
        build`` — the content hash hasn't changed, the cached layer is
        identical.  Skipping the subprocess saves the 50ms ``docker
        build`` no-op probe."""
        with patch(
            "claw_forge.agent.container.detect_runtime", return_value="docker",
        ), patch(
            "claw_forge.agent.container.image_exists", return_value=True,
        ), patch(
            "claw_forge.agent.container.subprocess.run",
        ) as mock_run:
            resolve_auto_container_image(project_with_dockerfile)
            mock_run.assert_not_called()

    def test_runs_build_when_image_missing(
        self, project_with_dockerfile: Path,
    ) -> None:
        """First run (or after Dockerfile edit) — image not in cache, so
        we invoke ``docker build``.  Build context is the project root
        so future Dockerfile templates can ``COPY`` from project tree."""
        with patch(
            "claw_forge.agent.container.detect_runtime", return_value="docker",
        ), patch(
            "claw_forge.agent.container.image_exists", return_value=False,
        ), patch(
            "claw_forge.agent.container.subprocess.run",
        ) as mock_run:
            tag = resolve_auto_container_image(project_with_dockerfile)
            mock_run.assert_called_once()
            call_args = mock_run.call_args[0][0]
            assert call_args[0] == "docker"
            assert call_args[1] == "build"
            assert "-t" in call_args
            assert tag in call_args
            assert "-f" in call_args
            assert str(
                project_with_dockerfile / ".claw-forge" / "agent.Dockerfile",
            ) in call_args
            assert str(project_with_dockerfile) in call_args

    def test_rebuild_flag_forces_build(
        self, project_with_dockerfile: Path,
    ) -> None:
        """``rebuild=True`` bypasses the image_exists cache check —
        useful when the operator edited the Dockerfile but the layer
        cache would otherwise still hit (rare, but possible if the
        edit is in a comment or whitespace that hashes differently
        but produces an identical resulting image)."""
        with patch(
            "claw_forge.agent.container.detect_runtime", return_value="docker",
        ), patch(
            "claw_forge.agent.container.image_exists", return_value=True,
        ), patch(
            "claw_forge.agent.container.subprocess.run",
        ) as mock_run:
            resolve_auto_container_image(
                project_with_dockerfile, rebuild=True,
            )
            mock_run.assert_called_once()

    def test_build_failure_raises_with_pointer(
        self, project_with_dockerfile: Path,
    ) -> None:
        """``docker build`` failed (bad base image, network error,
        Dockerfile syntax error).  Wrap the SubprocessError in a
        RuntimeError with a "fix and re-run" pointer so the operator
        knows what to do."""
        with patch(
            "claw_forge.agent.container.detect_runtime", return_value="docker",
        ), patch(
            "claw_forge.agent.container.image_exists", return_value=False,
        ), patch(
            "claw_forge.agent.container.subprocess.run",
            side_effect=__import__("subprocess").CalledProcessError(1, "build"),
        ), pytest.raises(RuntimeError, match="build.*failed"):
            resolve_auto_container_image(project_with_dockerfile)
