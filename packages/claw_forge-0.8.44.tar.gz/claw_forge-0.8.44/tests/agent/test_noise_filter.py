"""Pin macOS tool-result noise scrubber (v0.8.43).

When the dispatcher runs inside Cursor's integrated terminal, Cursor's
``ms-python.debugpy`` extension auto-attaches its debugger to every
Python subprocess via a shim in PATH (``noConfigScripts/debugpy``).
On macOS the debug attachment's teardown calls ``turn_off_stack_logging()``
defensively — but ``MallocStackLogging`` was never enabled in the
child, so ``libsystem_malloc.dylib`` prints the harmless noise line:

    python3(8267) MallocStackLogging: can't turn off malloc stack
    logging because it was not enabled.

This noise leaks into the subprocess's stderr → ``ToolResultBlock.content``
the agent receives → activity log (UI) + ``agent_log`` events (DB) +
exported training corpus.  Zero learning signal, pure pollution.

The scrubber strips these well-known macOS-libsystem chatter lines from
tool_result text before they enter any persistence layer.  Conservative
patterns — only matches what we've actually seen — so non-noise text
is never touched.

Also covered: scrubbing must be idempotent (apply twice = same result),
and must leave the surrounding signal intact (only the noise line goes;
the rest of tool_result output is preserved verbatim).
"""

from __future__ import annotations


class TestScrubMacosNoise:
    def test_scrubs_mallocstacklogging_line(self) -> None:
        from claw_forge.agent.noise_filter import scrub_macos_noise
        noisy = (
            "test output line 1\n"
            "python3(8267) MallocStackLogging: can't turn off malloc "
            "stack logging because it was not enabled.\n"
            "test output line 2"
        )
        out = scrub_macos_noise(noisy)
        assert "MallocStackLogging" not in out
        assert "line 1" in out
        assert "line 2" in out

    def test_scrubs_nw_protocol_line(self) -> None:
        from claw_forge.agent.noise_filter import scrub_macos_noise
        noisy = (
            "real test output\n"
            "nw_protocol_socket_set_no_wake_from_sleep [C42:1] Inet, "
            "definite, attribution: developer setsockopt SO_NOWAKEFROMSLEEP "
            "failed [22: Invalid argument]"
        )
        out = scrub_macos_noise(noisy)
        assert "nw_protocol_socket_set_no_wake_from_sleep" not in out
        assert "real test output" in out

    def test_does_not_touch_real_python_output(self) -> None:
        """A legitimate ``python3 ...`` test output line is preserved."""
        from claw_forge.agent.noise_filter import scrub_macos_noise
        real = (
            "================ test session starts ================\n"
            "platform darwin -- Python 3.12.12, pytest-9.0.3\n"
            "collected 47 items\n"
            "tests/test_thing.py ........................... [100%]\n"
            "================ 47 passed in 1.23s ================"
        )
        out = scrub_macos_noise(real)
        assert out == real, (
            "Scrubber must leave non-noise text byte-identical.  Any "
            "regex that matches normal test output is too aggressive."
        )

    def test_idempotent(self) -> None:
        """Scrubbing twice yields the same result as scrubbing once."""
        from claw_forge.agent.noise_filter import scrub_macos_noise
        noisy = (
            "x\npython3(123) MallocStackLogging: can't turn off malloc "
            "stack logging because it was not enabled.\ny"
        )
        once = scrub_macos_noise(noisy)
        twice = scrub_macos_noise(once)
        assert once == twice

    def test_empty_string_returns_empty(self) -> None:
        from claw_forge.agent.noise_filter import scrub_macos_noise
        assert scrub_macos_noise("") == ""

    def test_noise_only_input_returns_empty(self) -> None:
        from claw_forge.agent.noise_filter import scrub_macos_noise
        noisy = (
            "python3(8267) MallocStackLogging: can't turn off malloc "
            "stack logging because it was not enabled."
        )
        out = scrub_macos_noise(noisy)
        assert out == "" or out.strip() == "", (
            f"Pure-noise input must reduce to empty/whitespace, got "
            f"{out!r}"
        )

    def test_preserves_apostrophe_variants(self) -> None:
        """Both straight (``'``) and curly (``’``) apostrophes in 'can't'.

        macOS's libsystem_malloc has used both over the years — the
        regex must accept either to be future-proof against OS upgrades.
        """
        from claw_forge.agent.noise_filter import scrub_macos_noise
        for apos in ("'", "’"):
            line = (
                f"python3(8267) MallocStackLogging: can{apos}t turn off "
                "malloc stack logging because it was not enabled."
            )
            assert "MallocStackLogging" not in scrub_macos_noise(line), (
                f"Failed to scrub variant with apostrophe {apos!r}"
            )


class TestRecorderIntegration:
    """End-to-end: noise present in a fake tool_result block is stripped
    by the recorder's ``_block_to_jsonable`` before it would be persisted.
    """

    def test_tool_result_string_content_is_scrubbed(self) -> None:
        from claw_forge.training.recorder import _block_to_jsonable

        class FakeBlock:
            type = "tool_result"
            tool_use_id = "x"
            content = (
                "test passed\n"
                "python3(8267) MallocStackLogging: can't turn off malloc "
                "stack logging because it was not enabled."
            )

        out = _block_to_jsonable(FakeBlock())
        assert "MallocStackLogging" not in out["content"], (
            "Recorder must scrub macOS noise from tool_result content "
            "before the events table is written."
        )
        assert "test passed" in out["content"]

    def test_tool_result_list_content_is_scrubbed(self) -> None:
        """Some SDK versions wrap content as ``[{type, text}, ...]``."""
        from claw_forge.training.recorder import _block_to_jsonable

        class FakeBlock:
            type = "tool_result"
            tool_use_id = "x"
            content = [
                {
                    "type": "text",
                    "text": (
                        "real output\n"
                        "python3(8267) MallocStackLogging: can't turn off "
                        "malloc stack logging because it was not enabled."
                    ),
                },
            ]

        out = _block_to_jsonable(FakeBlock())
        text = out["content"][0]["text"]
        assert "MallocStackLogging" not in text
        assert "real output" in text

    def test_tool_use_blocks_untouched(self) -> None:
        """Filter is narrow: only tool_result blocks get scrubbed.
        Tool_use blocks pass through unchanged (their ``input`` could
        legitimately contain those strings if the agent is debugging
        macOS-libsystem itself)."""
        from claw_forge.training.recorder import _block_to_jsonable

        class FakeBlock:
            type = "tool_use"
            id = "x"
            name = "Bash"
            input = {"command": "grep MallocStackLogging /var/log/system.log"}

        out = _block_to_jsonable(FakeBlock())
        assert "MallocStackLogging" in out["input"]["command"]
