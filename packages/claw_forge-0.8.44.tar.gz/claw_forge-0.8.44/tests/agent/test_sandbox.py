"""Tests for ``claw_forge.agent.sandbox`` — Level 2 OS-level filesystem
jail (v0.8.18).  Most assertions exercise the macOS sandbox-exec path
since that's what v0.8.18 ships; Linux bwrap lands in a follow-up.

These tests skip on platforms where the sandbox isn't available so
the suite still passes on Linux CI runners (which can't validate
macOS sandbox semantics) and on Windows.
"""
from __future__ import annotations

import os
import platform
import shutil
import subprocess
from pathlib import Path

import pytest

from claw_forge.agent.sandbox import (
    _HOME_PROTECTED_FILES,
    _HOME_PROTECTED_SUBPATHS,
    _SYSTEM_PROTECTED_SUBPATHS,
    _linux_bwrap_args,
    _macos_sandbox_profile,
    _resolve_git_common_dir,
    is_sandbox_available,
    make_sandbox_wrapper,
    write_linux_bwrap_wrapper,
    write_macos_sandbox_wrapper,
)

_NEEDS_MACOS = pytest.mark.skipif(
    platform.system() != "Darwin",
    reason="macOS sandbox-exec required",
)
_NEEDS_SANDBOX_BIN = pytest.mark.skipif(
    shutil.which("sandbox-exec") is None,
    reason="sandbox-exec not on PATH",
)


class TestIsSandboxAvailable:
    def test_returns_tuple(self) -> None:
        """Always returns ``(bool, str_mechanism)`` regardless of OS so
        callers can branch on availability AND log the mechanism name."""
        available, mechanism = is_sandbox_available()
        assert isinstance(available, bool)
        assert mechanism in ("sandbox-exec", "bwrap", "none")

    @_NEEDS_MACOS
    def test_macos_reports_sandbox_exec(self) -> None:
        """On macOS, mechanism must be ``sandbox-exec``."""
        _, mechanism = is_sandbox_available()
        assert mechanism == "sandbox-exec"


class TestMacosSandboxProfile:
    """Profile-string contract — covers the canonical-path landmine
    that silently no-ops the deny rule (the bug we hit during impl)."""

    def test_profile_contains_default_allow(self, tmp_path: Path) -> None:
        """Default-allow + targeted deny model — needed to keep the
        agent's normal operations (stdout, network, /tmp scratch)
        working without enumerating every permission."""
        worktree = tmp_path / "wt"
        profile = _macos_sandbox_profile(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
        )
        assert "(allow default)" in profile

    def test_profile_denies_project_path(self, tmp_path: Path) -> None:
        """Resolved project path appears in the deny rule.  This is
        the canonical path; symlink paths silently don't match the
        kernel's canonicalised view."""
        worktree = tmp_path / "wt"
        profile = _macos_sandbox_profile(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
        )
        assert f'(deny file-write* (subpath "{tmp_path.resolve()}"))' in profile

    def test_profile_carves_out_worktree(self, tmp_path: Path) -> None:
        """Worktree allow rule comes after the project deny so writes
        under the worktree still work despite the deny.  Last rule wins
        in sandbox-exec; ordering is part of the contract."""
        worktree = tmp_path / "wt"
        profile = _macos_sandbox_profile(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
        )
        deny_idx = profile.find("(deny file-write*")
        allow_idx = profile.find("(allow file-write*")
        assert deny_idx > -1 and allow_idx > -1
        assert allow_idx > deny_idx, (
            "worktree allow must come AFTER project deny "
            "so it wins via last-rule-wins"
        )


@_NEEDS_MACOS
@_NEEDS_SANDBOX_BIN
class TestWriteMacosSandboxWrapper:
    """End-to-end: build a wrapper, exec a write command through it,
    verify the kernel actually denies the write outside the worktree
    and allows it inside.  These tests fail loudly if Apple ever
    changes sandbox-exec semantics in a way that breaks our profile."""

    @pytest.fixture
    def setup(self, tmp_path: Path) -> tuple[Path, Path, Path]:
        """Return ``(project, worktree, wrapper_path)``."""
        project = tmp_path / "proj"
        worktree = project / ".claw-forge" / "worktrees" / "feat"
        worktree.mkdir(parents=True)
        # Use /bin/sh as the "claude" stand-in — we just want to
        # exec a command and verify the sandbox kicks in.  The real
        # claude binary isn't needed for these assertions.
        wrapper = write_macos_sandbox_wrapper(
            project_path=project,
            worktree_path=worktree,
            output_dir=worktree / ".claw-forge" / "sandbox",
            claude_path=Path("/bin/sh"),
        )
        return project, worktree, wrapper

    def test_wrapper_is_executable(
        self, setup: tuple[Path, Path, Path],
    ) -> None:
        _, _, wrapper = setup
        assert wrapper.exists()
        assert os.access(wrapper, os.X_OK)

    def test_profile_written_alongside_wrapper(
        self, setup: tuple[Path, Path, Path],
    ) -> None:
        _, _, wrapper = setup
        profile = wrapper.parent / "sandbox.sb"
        assert profile.exists()
        content = profile.read_text()
        assert "(version 1)" in content

    def test_wrapper_denies_write_to_project_root(
        self, setup: tuple[Path, Path, Path],
    ) -> None:
        """The leak we're preventing: a write to the project root that
        bypasses every static check (Bash/exempt-command/tool sandbox).
        With Level 2 the kernel itself denies it."""
        project, _, wrapper = setup
        target = project / "leaked.txt"
        result = subprocess.run(
            [str(wrapper), "-c", f'touch "{target}" 2>&1; echo exit=$?'],
            capture_output=True, text=True, timeout=10,
        )
        # The touch's exit code should be non-zero AND the file must
        # not exist.  Note: ``echo`` after touch always succeeds, so
        # we check the captured ``exit=N`` line.
        assert "Operation not permitted" in result.stdout
        assert "exit=1" in result.stdout
        assert not target.exists()

    def test_wrapper_allows_write_inside_worktree(
        self, setup: tuple[Path, Path, Path],
    ) -> None:
        """Carve-out: writes under the worktree path go through
        normally — the agent's intended work lands where it should."""
        _, worktree, wrapper = setup
        target = worktree / "in_worktree.txt"
        result = subprocess.run(
            [str(wrapper), "-c", f'touch "{target}"; echo exit=$?'],
            capture_output=True, text=True, timeout=10,
        )
        assert "exit=0" in result.stdout
        assert target.exists()

    def test_wrapper_denies_via_python(
        self, setup: tuple[Path, Path, Path],
    ) -> None:
        """The escape pattern Layer 1–3 can't statically catch:
        ``python -c "open('/abs', 'w')…"``.  The sandbox sees the
        ``open(2)`` syscall regardless of how the Python literal was
        constructed and denies it."""
        project, _, wrapper = setup
        target = project / "via_python.txt"
        # Use shell to invoke python — same way Claude's Bash tool
        # would.  The agent could embed any literal here.
        cmd = (
            f'/usr/bin/python3 -c "'
            f"open(r'{target}', 'w').write('leak')"
            f'" 2>&1; echo exit=$?'
        )
        result = subprocess.run(
            [str(wrapper), "-c", cmd],
            capture_output=True, text=True, timeout=10,
        )
        assert "exit=1" in result.stdout
        assert not target.exists()


class TestResolveGitCommonDir:
    """v0.8.26 carve-out helper — returns the **shared** git common
    dir (``<project>/.git/``) for a linked worktree.  Linked worktrees
    share their object store, refs, hooks, and config with the parent
    project's ``.git/``; the per-worktree metadata at
    ``<git_common>/worktrees/<slug>/`` is a subset of this carve-out.
    Carving out only per-worktree metadata isn't enough — the
    object-store write fails and ``git commit`` aborts.
    """

    def test_reads_gitdir_pointer_and_walks_to_common_dir(
        self, tmp_path: Path,
    ) -> None:
        project = tmp_path / "proj"
        worktree = project / ".claw-forge" / "worktrees" / "feat"
        worktree.mkdir(parents=True)
        # git creates the per-worktree metadata dir AND a one-line
        # pointer at <worktree>/.git.  The COMMON dir is two levels up
        # from the metadata: <common>/worktrees/<slug>.
        metadata = project / ".git" / "worktrees" / "feat"
        metadata.mkdir(parents=True)
        (worktree / ".git").write_text(f"gitdir: {metadata}\n")

        result = _resolve_git_common_dir(
            worktree.resolve(), project.resolve(),
        )
        # parent.parent of metadata is <project>/.git
        assert result == (project / ".git").resolve()

    def test_falls_back_to_project_dot_git_when_pointer_missing(
        self, tmp_path: Path,
    ) -> None:
        """Newly-created worktree dir whose ``.git`` pointer isn't
        there yet — fall back to ``<project>/.git`` (the standard
        layout claw-forge always produces)."""
        project = tmp_path / "proj"
        worktree = project / ".claw-forge" / "worktrees" / "feat"
        worktree.mkdir(parents=True)
        (project / ".git").mkdir()  # bare common dir
        result = _resolve_git_common_dir(
            worktree.resolve(), project.resolve(),
        )
        assert result == (project / ".git").resolve()

    def test_returns_none_when_neither_path_exists(
        self, tmp_path: Path,
    ) -> None:
        """Caller treats None as 'no carve-out needed' — project not
        yet git-init'd; ``.git`` doesn't exist anywhere."""
        project = tmp_path / "proj"
        worktree = project / ".claw-forge" / "worktrees" / "feat"
        worktree.mkdir(parents=True)
        # No .git pointer, no project .git dir.
        result = _resolve_git_common_dir(
            worktree.resolve(), project.resolve(),
        )
        assert result is None


class TestMacosSandboxProfileGitMetadataCarveout:
    """v0.8.26 — git's per-worktree metadata at
    ``<project>/.git/worktrees/<slug>/`` MUST be carved out, otherwise
    ``git -C <worktree>`` operations fail with EPERM on ``index.lock``."""

    def test_carveout_appears_when_metadata_provided(
        self, tmp_path: Path,
    ) -> None:
        worktree = tmp_path / "wt"
        metadata = tmp_path / ".git" / "worktrees" / "wt"
        profile = _macos_sandbox_profile(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
            git_common_dir=metadata.resolve(),
        )
        assert (
            f'(allow file-write* (subpath "{metadata.resolve()}"))'
            in profile
        )

    def test_carveout_omitted_when_metadata_none(
        self, tmp_path: Path,
    ) -> None:
        """Default ``None`` keeps byte-for-byte compatibility with the
        pre-v0.8.26 profile shape (one allow rule for the worktree)."""
        worktree = tmp_path / "wt"
        profile = _macos_sandbox_profile(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
            git_common_dir=None,
        )
        # Exactly one allow file-write* line — no extra carve-out.
        assert profile.count("(allow file-write*") == 1

    def test_carveout_after_project_deny(self, tmp_path: Path) -> None:
        """Last-rule-wins applies to the metadata carve-out too — it
        must appear AFTER the project deny so the kernel actually
        permits the write through the metadata subpath."""
        worktree = tmp_path / "wt"
        metadata = tmp_path / ".git" / "worktrees" / "wt"
        profile = _macos_sandbox_profile(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
            git_common_dir=metadata.resolve(),
        )
        deny_idx = profile.find(f'(deny file-write* (subpath "{tmp_path.resolve()}'
                                f'"))')
        meta_idx = profile.find(
            f'(allow file-write* (subpath "{metadata.resolve()}"))'
        )
        assert deny_idx > -1 and meta_idx > -1
        assert meta_idx > deny_idx


class TestLinuxBwrapGitMetadataCarveout:
    """Symmetric to the macOS test — bwrap's ``--bind`` for git
    metadata must come after the project ``--ro-bind`` for the
    last-mount-wins override to take effect."""

    def test_metadata_bind_present_when_provided(
        self, tmp_path: Path,
    ) -> None:
        worktree = tmp_path / "wt"
        metadata = tmp_path / ".git" / "worktrees" / "wt"
        args = _linux_bwrap_args(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
            git_common_dir=metadata.resolve(),
        )
        # Find every --bind pair and check one of them targets metadata.
        bind_targets = [
            args[i + 1]
            for i, a in enumerate(args)
            if a == "--bind" and i + 1 < len(args)
        ]
        assert str(metadata.resolve()) in bind_targets

    def test_metadata_bind_omitted_when_none(self, tmp_path: Path) -> None:
        """Default ``None`` keeps the pre-v0.8.26 arg list shape — one
        --bind for the worktree, no extras."""
        worktree = tmp_path / "wt"
        args = _linux_bwrap_args(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
            git_common_dir=None,
        )
        # Exactly one --bind pair (the worktree carve-out).
        assert args.count("--bind") == 1

    def test_metadata_bind_after_project_ro_bind(
        self, tmp_path: Path,
    ) -> None:
        worktree = tmp_path / "wt"
        metadata = tmp_path / ".git" / "worktrees" / "wt"
        args = _linux_bwrap_args(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
            git_common_dir=metadata.resolve(),
        )
        ro_idx = args.index("--ro-bind")
        # Find the --bind pair targeting metadata specifically (there
        # may be multiple --bind pairs).
        meta_idx = None
        for i, a in enumerate(args):
            if (
                a == "--bind"
                and i + 1 < len(args)
                and args[i + 1] == str(metadata.resolve())
            ):
                meta_idx = i
                break
        assert meta_idx is not None and meta_idx > ro_idx


@_NEEDS_MACOS
@_NEEDS_SANDBOX_BIN
class TestMacosWrapperGitOpsEndToEnd:
    """End-to-end on a real git worktree: build the wrapper, then
    execute ``git status`` and ``git commit`` through it.  This is the
    integration test that would have caught the v0.8.26 regression
    earlier — without the carve-out, both fail with EPERM on
    ``.git/worktrees/<slug>/index.lock``.
    """

    @pytest.fixture
    def git_worktree(self, tmp_path: Path) -> tuple[Path, Path, Path]:
        """Real git project + linked worktree.  Returns
        ``(project, worktree, wrapper)``."""
        project = tmp_path / "proj"
        project.mkdir()
        # Initialise a real git repo on `main` branch.
        for cmd in (
            ["git", "init", "-q", "-b", "main"],
            ["git", "config", "user.email", "t@t.x"],
            ["git", "config", "user.name", "t"],
        ):
            subprocess.run(cmd, cwd=project, check=True)
        (project / "README.md").write_text("# init\n")
        subprocess.run(["git", "add", "."], cwd=project, check=True)
        subprocess.run(
            ["git", "commit", "-q", "-m", "init"], cwd=project, check=True,
        )
        # Add a linked worktree on a feature branch — git creates
        # both `<project>/.claw-forge/worktrees/feat/` and
        # `<project>/.git/worktrees/feat/` (the metadata).
        worktree_dir = project / ".claw-forge" / "worktrees" / "feat"
        subprocess.run(
            ["git", "worktree", "add", "-q", str(worktree_dir), "-b", "feat"],
            cwd=project, check=True,
        )
        wrapper = write_macos_sandbox_wrapper(
            project_path=project,
            worktree_path=worktree_dir,
            output_dir=worktree_dir / ".claw-forge" / "sandbox",
            claude_path=Path("/bin/sh"),
        )
        return project, worktree_dir, wrapper

    def test_git_status_inside_sandboxed_worktree_succeeds(
        self, git_worktree: tuple[Path, Path, Path],
    ) -> None:
        """``git status`` reads HEAD/index — small sanity probe that
        proves the basic git-inside-sandbox path works."""
        _, worktree, wrapper = git_worktree
        result = subprocess.run(
            [
                str(wrapper),
                "-c",
                f'cd "{worktree}" && git status --porcelain; echo exit=$?',
            ],
            capture_output=True, text=True, timeout=15,
        )
        assert "exit=0" in result.stdout, (
            f"git status exited non-zero under sandbox\nstdout: {result.stdout}"
            f"\nstderr: {result.stderr}"
        )

    def test_git_commit_inside_sandboxed_worktree_succeeds(
        self, git_worktree: tuple[Path, Path, Path],
    ) -> None:
        """The headline test: a full add → commit cycle inside the
        sandboxed worktree.  This exercises EVERY file write a commit
        does:

        - ``<git_common>/worktrees/<slug>/index.lock`` (per-worktree
          lock) — pre-v0.8.26 this was the EPERM the user reported.
        - ``<git_common>/worktrees/<slug>/index`` (per-worktree index).
        - ``<git_common>/objects/<hash[:2]>/<hash[2:]>`` (shared object
          store) — this is what defeated the first carve-out attempt
          that only allowed per-worktree metadata.
        - ``<git_common>/refs/heads/feat`` (shared ref update).

        With v0.8.26's full common-dir carve-out, all four succeed.
        """
        project, worktree, wrapper = git_worktree
        (worktree / "new.py").write_text("print('hi')\n")
        # ``git add`` writes the index; ``git commit`` writes objects
        # + refs.  Both must succeed for the contract to hold.
        result = subprocess.run(
            [
                str(wrapper),
                "-c",
                f'cd "{worktree}" && '
                'git add new.py && '
                'git -c user.email=t@t.x -c user.name=t '
                'commit --no-verify -q -m feat:add 2>&1; '
                'echo exit=$?',
            ],
            capture_output=True, text=True, timeout=15,
        )
        assert "exit=0" in result.stdout, (
            f"git add+commit failed under sandbox\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )
        # Defence-in-depth: the leak we explicitly are NOT regressing
        # on — writes to project root still get denied.
        assert not (project / "leaked.txt").exists()


@_NEEDS_MACOS
@_NEEDS_SANDBOX_BIN
class TestMacosWrapperSubagentInheritance:
    """Pin the contract: child processes spawned inside the sandbox
    inherit the deny-write rules.  This is what makes Task-tool
    subagents safe — they run in-process with the parent claude, and
    even if they shell out to bash/python/anything, the kernel-level
    sandbox follows the process tree.
    """

    @pytest.fixture
    def setup(self, tmp_path: Path) -> tuple[Path, Path, Path]:
        project = tmp_path / "proj"
        worktree = project / ".claw-forge" / "worktrees" / "feat"
        worktree.mkdir(parents=True)
        wrapper = write_macos_sandbox_wrapper(
            project_path=project,
            worktree_path=worktree,
            output_dir=worktree / ".claw-forge" / "sandbox",
            claude_path=Path("/bin/sh"),
        )
        return project, worktree, wrapper

    def test_grandchild_bash_inherits_deny(
        self, setup: tuple[Path, Path, Path],
    ) -> None:
        """A bash subprocess of bash (two levels deep) still sees the
        deny.  Mirrors the agent → bash → python chain a Task-tool
        subagent might produce when shelling out."""
        project, _, wrapper = setup
        target = project / "grandchild_leak.txt"
        # Outer wrapper runs bash -c that spawns bash -c that touches.
        result = subprocess.run(
            [
                str(wrapper),
                "-c",
                f'/bin/bash -c \'touch "{target}" 2>&1\'; echo exit=$?',
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert "Operation not permitted" in result.stdout
        assert "exit=1" in result.stdout
        assert not target.exists()

    def test_grandchild_python_inherits_deny(
        self, setup: tuple[Path, Path, Path],
    ) -> None:
        """A python subprocess invoked from bash inherits the sandbox
        — covers the FFI / subprocess-via-Python escape path that the
        OS sandbox closes regardless of subagent depth.

        We write the python script to a real file inside the worktree
        (the ONE place writes are allowed) and run it via
        ``bash -c "python3 leak.py"`` — sidesteps the shell-quoting
        gymnastics of ``python -c "literal"`` while still exercising
        the same sandbox semantics (script execution → ``open(2)`` of
        a path outside the worktree).
        """
        project, worktree, wrapper = setup
        target = project / "py_grandchild_leak.txt"
        script = worktree / "leak.py"
        script.write_text(
            f"import sys\n"
            f"try:\n"
            f"    open(r'{target}', 'w').write('x')\n"
            f"    print('LEAKED')\n"
            f"    sys.exit(0)\n"
            f"except PermissionError:\n"
            f"    print('DENIED')\n"
            f"    sys.exit(1)\n"
        )
        result = subprocess.run(
            [
                str(wrapper),
                "-c",
                f'/bin/bash -c "/usr/bin/python3 \\"{script}\\""; '
                f"echo exit=$?",
            ],
            capture_output=True, text=True, timeout=10,
        )
        assert "DENIED" in result.stdout, (
            f"sandbox did not deny grandchild python write\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )
        assert "exit=1" in result.stdout
        assert not target.exists()


class TestMakeSandboxWrapperFallback:
    """``make_sandbox_wrapper`` returns ``None`` when no sandbox is
    available so the dispatcher can degrade to the behavioural-only
    stack without raising."""

    def test_returns_none_when_claude_not_on_path(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """If ``claude`` isn't installed (API-only mode, fresh CI),
        we can't wrap it — fall back to bare cli_path."""
        # Make ``shutil.which`` return None for "claude".
        real_which = shutil.which

        def fake_which(name: str, *args: object, **kwargs: object) -> str | None:
            if name == "claude":
                return None
            return real_which(name)

        monkeypatch.setattr("claw_forge.agent.sandbox.shutil.which", fake_which)
        result = make_sandbox_wrapper(
            project_path=tmp_path,
            worktree_path=tmp_path / "wt",
            output_dir=tmp_path / "out",
        )
        assert result is None

    def test_returns_none_on_unsupported_os(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """On Windows / BSD / anything that isn't macOS or Linux,
        no sandbox available — fall back."""
        monkeypatch.setattr(
            "claw_forge.agent.sandbox.platform.system",
            lambda: "Windows",
        )
        result = make_sandbox_wrapper(
            project_path=tmp_path,
            worktree_path=tmp_path / "wt",
            output_dir=tmp_path / "out",
        )
        assert result is None


class TestLinuxBwrapArgs:
    """bwrap CLI-args contract — covers the same canonical-path
    landmine as macOS plus the layer-ordering invariant (later mounts
    override earlier ones at overlapping subpaths)."""

    def test_dev_bind_root_first(self, tmp_path: Path) -> None:
        """``--dev-bind / /`` MUST come first so the host's full
        filesystem is available before we layer ro-bind/bind on top.
        Without it, claude can't read /usr, /etc, ~/.claude, etc."""
        worktree = tmp_path / "wt"
        args = _linux_bwrap_args(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
        )
        assert args[:3] == ["--dev-bind", "/", "/"]

    def test_ro_bind_project_after_root(self, tmp_path: Path) -> None:
        """``--ro-bind <project> <project>`` overlays the parent
        project as read-only.  Must come AFTER ``--dev-bind / /`` so
        the later-rules-win semantics make this stick."""
        worktree = tmp_path / "wt"
        args = _linux_bwrap_args(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
        )
        ro_idx = args.index("--ro-bind")
        dev_bind_idx = args.index("--dev-bind")
        assert ro_idx > dev_bind_idx, (
            "ro-bind project must come after dev-bind / so it "
            "actually overrides the writable / mount at the project subpath"
        )
        assert args[ro_idx + 1] == str(tmp_path.resolve())
        assert args[ro_idx + 2] == str(tmp_path.resolve())

    def test_bind_worktree_after_ro_bind(self, tmp_path: Path) -> None:
        """``--bind <worktree> <worktree>`` carves out the worktree as
        writable.  MUST come after the project ro-bind for the
        last-rule-wins override to take effect."""
        worktree = tmp_path / "wt"
        args = _linux_bwrap_args(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
        )
        bind_idx = args.index("--bind")
        ro_idx = args.index("--ro-bind")
        assert bind_idx > ro_idx, (
            "worktree --bind must come after the project --ro-bind "
            "so it overrides the read-only mount at the worktree subpath"
        )

    def test_chdir_to_worktree(self, tmp_path: Path) -> None:
        """Agent's cwd inside the sandbox is the worktree (mirrors
        macOS where ``cwd=str(worktree_path)`` on the SDK options)."""
        worktree = tmp_path / "wt"
        args = _linux_bwrap_args(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
        )
        chdir_idx = args.index("--chdir")
        assert args[chdir_idx + 1] == str(worktree.resolve())


class TestWriteLinuxBwrapWrapper:
    """Wrapper script + args persistence (tests don't actually run
    bwrap — that's the integration test gated on Linux + bwrap)."""

    @pytest.fixture
    def setup(self, tmp_path: Path) -> tuple[Path, Path, Path]:
        """Return ``(project, worktree, wrapper_path)``."""
        project = tmp_path / "proj"
        worktree = project / ".claw-forge" / "worktrees" / "feat"
        worktree.mkdir(parents=True)
        wrapper = write_linux_bwrap_wrapper(
            project_path=project,
            worktree_path=worktree,
            output_dir=worktree / ".claw-forge" / "sandbox",
            claude_path=Path("/usr/bin/claude"),
        )
        return project, worktree, wrapper

    def test_wrapper_is_executable(
        self, setup: tuple[Path, Path, Path],
    ) -> None:
        _, _, wrapper = setup
        assert wrapper.exists()
        import os
        assert os.access(wrapper, os.X_OK)

    def test_wrapper_uses_bwrap(
        self, setup: tuple[Path, Path, Path],
    ) -> None:
        """Wrapper invokes ``/usr/bin/bwrap`` (NOT ``sandbox-exec``)
        — the script is OS-specific, this test pins the dispatch."""
        _, _, wrapper = setup
        content = wrapper.read_text()
        assert "/usr/bin/bwrap" in content
        assert "sandbox-exec" not in content

    def test_wrapper_preserves_args(
        self, setup: tuple[Path, Path, Path],
    ) -> None:
        """SDK invokes ``<wrapper> <claude_args>``; wrapper passes
        ``"$@"`` to claude inside the jail.  Same pass-through
        contract as the macOS wrapper."""
        _, _, wrapper = setup
        content = wrapper.read_text()
        assert '"$@"' in content

    def test_args_record_persisted(
        self, setup: tuple[Path, Path, Path],
    ) -> None:
        """``bwrap_args.txt`` written next to the wrapper for
        forensic inspection — operator can reproduce the exact
        bwrap invocation when triaging a sandbox-related failure."""
        _, _, wrapper = setup
        args_file = wrapper.parent / "bwrap_args.txt"
        assert args_file.exists()
        recorded = args_file.read_text().splitlines()
        assert "--dev-bind" in recorded
        assert "--ro-bind" in recorded
        assert "--bind" in recorded


# ─────────────────────────────────────────────────────────────────────────
# v0.8.33 HOME-protection — supply-chain defence layer.
#
# These tests pin the contract for the npm-supply-chain hardening that
# extends the v0.8.18 OS sandbox: the agent can no longer write to
# credential stores (~/.ssh, ~/.aws, …), shell rc files, package-
# manager caches, or persistence dirs.  Tests for both ``home_protection
# =True`` (default) and ``home_protection=False`` (legacy / opt-out)
# states; existing tests above default to True via the function's
# default arg, so the legacy shape is preserved only when explicitly
# requested.
# ─────────────────────────────────────────────────────────────────────────


class TestMacosSandboxProfileHomeProtection:
    """``home_protection=True`` (default) adds deny rules for credential
    stores, shell rc files, and persistence dirs.  ``=False`` keeps
    byte-for-byte compatibility with the pre-v0.8.33 profile."""

    def test_profile_denies_ssh_when_home_protection_on(
        self, tmp_path: Path,
    ) -> None:
        """The headline target: a postinstall script that drops a key
        into ``~/.ssh/authorized_keys`` for persistence.  Kernel-level
        deny shuts this down regardless of how the path is constructed."""
        worktree = tmp_path / "wt"
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        profile = _macos_sandbox_profile(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
            home_protection=True,
            home_dir=fake_home.resolve(),
        )
        assert (
            f'(deny file-write* (subpath "{fake_home.resolve()}/.ssh"))'
            in profile
        )

    def test_profile_denies_npm_cache_when_home_protection_on(
        self, tmp_path: Path,
    ) -> None:
        """``~/.npm`` is the cache-poisoning surface for npm supply-chain
        attacks — a malicious package can plant modified tarballs that
        future agents (or the user's normal shell) would pick up."""
        worktree = tmp_path / "wt"
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        profile = _macos_sandbox_profile(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
            home_protection=True,
            home_dir=fake_home.resolve(),
        )
        assert (
            f'(deny file-write* (subpath "{fake_home.resolve()}/.npm"))'
            in profile
        )

    def test_profile_denies_shell_rc_files_when_on(
        self, tmp_path: Path,
    ) -> None:
        """Shell init files (.bashrc/.zshrc/…) are the canonical persistence
        vector — writing a single line plants code that runs on every
        future shell.  Uses ``literal`` matching so sibling files at the
        same prefix aren't accidentally captured."""
        worktree = tmp_path / "wt"
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        profile = _macos_sandbox_profile(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
            home_protection=True,
            home_dir=fake_home.resolve(),
        )
        for rc in (".bashrc", ".zshrc", ".profile"):
            assert (
                f'(deny file-write* (literal "{fake_home.resolve()}/{rc}"))'
                in profile
            )

    def test_profile_denies_macos_launchagents_when_on(
        self, tmp_path: Path,
    ) -> None:
        """``~/Library/LaunchAgents`` is the macOS user-level launchd
        persistence dir — a plist there runs at every login.  System-wide
        ``/Library/LaunchAgents`` is also denied as defence-in-depth."""
        worktree = tmp_path / "wt"
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        profile = _macos_sandbox_profile(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
            home_protection=True,
            home_dir=fake_home.resolve(),
        )
        assert (
            '(deny file-write* (subpath '
            f'"{fake_home.resolve()}/Library/LaunchAgents"))'
            in profile
        )
        # System-wide persistence dir always in the profile regardless
        # of resolved home.
        assert (
            '(deny file-write* (subpath "/Library/LaunchAgents"))'
            in profile
        )

    def test_profile_omits_home_denies_when_protection_off(
        self, tmp_path: Path,
    ) -> None:
        """Opt-out path: byte-for-byte compatibility with the pre-v0.8.33
        profile shape.  Operators who set ``home_protection: false`` get
        the legacy default-allow + project-deny + worktree-allow profile."""
        worktree = tmp_path / "wt"
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        profile = _macos_sandbox_profile(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
            home_protection=False,
            home_dir=fake_home.resolve(),
        )
        assert ".ssh" not in profile
        assert ".npm" not in profile
        assert "LaunchAgents" not in profile
        # Still has the legacy structure — project deny + worktree allow.
        assert (
            f'(deny file-write* (subpath "{tmp_path.resolve()}"))'
            in profile
        )

    def test_profile_uses_resolved_path_for_home(
        self, tmp_path: Path,
    ) -> None:
        """Home dir is canonicalised the same way as project/worktree
        — symlinks (``/Users/foo`` → ``/private/Users/foo`` in odd
        macOS setups) would otherwise silently no-op the deny rule.
        Same kernel-comparison landmine as the project deny."""
        worktree = tmp_path / "wt"
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        profile = _macos_sandbox_profile(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
            home_protection=True,
            home_dir=fake_home,  # unresolved — should still be canonical
        )
        # Every HOME path in the profile must use the resolved form.
        assert str(fake_home.resolve()) in profile

    def test_protected_subpaths_cover_credential_dirs(self) -> None:
        """Lock down the protected-subpath list so a refactor that
        accidentally removes ``.ssh`` or ``.aws`` is flagged by a
        failing test rather than a silently-weakened default."""
        assert ".ssh" in _HOME_PROTECTED_SUBPATHS
        assert ".aws" in _HOME_PROTECTED_SUBPATHS
        assert ".gnupg" in _HOME_PROTECTED_SUBPATHS
        assert ".npm" in _HOME_PROTECTED_SUBPATHS

    def test_protected_files_cover_shell_rc(self) -> None:
        """Same lockdown as above for the shell-init list — the
        persistence vector is so high-value that silent removal must
        fail a test rather than ship."""
        assert ".bashrc" in _HOME_PROTECTED_FILES
        assert ".zshrc" in _HOME_PROTECTED_FILES
        assert ".profile" in _HOME_PROTECTED_FILES
        assert ".netrc" in _HOME_PROTECTED_FILES


class TestLinuxBwrapHomeProtection:
    """Symmetric to the macOS HOME-protection tests — Linux bwrap
    uses ``--ro-bind-try`` (silently no-ops on missing paths) so the
    sandbox setup doesn't fail when a user has no ``~/.aws`` etc."""

    def test_ro_bind_try_for_protected_subpaths_when_on(
        self, tmp_path: Path,
    ) -> None:
        worktree = tmp_path / "wt"
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        args = _linux_bwrap_args(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
            home_protection=True,
            home_dir=fake_home.resolve(),
        )
        # Each protected subpath shows up as a --ro-bind-try pair.
        for sub in (".ssh", ".aws", ".npm"):
            target = str((fake_home.resolve() / sub).resolve())
            assert "--ro-bind-try" in args
            assert target in args

    def test_ro_bind_try_for_protected_files_when_on(
        self, tmp_path: Path,
    ) -> None:
        worktree = tmp_path / "wt"
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        args = _linux_bwrap_args(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
            home_protection=True,
            home_dir=fake_home.resolve(),
        )
        for rc in (".bashrc", ".zshrc", ".npmrc"):
            target = str((fake_home.resolve() / rc).resolve())
            assert target in args

    def test_ro_bind_try_for_system_persistence_when_on(
        self, tmp_path: Path,
    ) -> None:
        """``/etc/cron.d`` / ``/Library/LaunchAgents`` / ``/etc/systemd/
        system`` are root-owned but defence-in-depth still binds them
        read-only — a sandbox bug + a sudo'd dev environment shouldn't
        combine to permit persistence."""
        worktree = tmp_path / "wt"
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        args = _linux_bwrap_args(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
            home_protection=True,
            home_dir=fake_home.resolve(),
        )
        for system_path in ("/etc/cron.d", "/etc/systemd/system"):
            assert system_path in args

    def test_no_extra_binds_when_protection_off(
        self, tmp_path: Path,
    ) -> None:
        """Opt-out path: legacy arg shape, no ``--ro-bind-try``."""
        worktree = tmp_path / "wt"
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        args = _linux_bwrap_args(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
            home_protection=False,
            home_dir=fake_home.resolve(),
        )
        assert "--ro-bind-try" not in args

    def test_protected_paths_lists_disjoint_with_project(
        self, tmp_path: Path,
    ) -> None:
        """Sanity check: protected HOME paths and the project path are
        disjoint — a developer who happens to put their project under
        ``~/.cache/`` would otherwise see the project rules silently
        overridden by the HOME rules.  Real-world projects don't live
        in cache dirs; this test pins the assumption."""
        # _SYSTEM_PROTECTED_SUBPATHS are absolute paths, not under HOME
        # or under any reasonable project path.
        for system_path in _SYSTEM_PROTECTED_SUBPATHS:
            assert system_path.startswith("/")
            assert not system_path.startswith(str(tmp_path))
