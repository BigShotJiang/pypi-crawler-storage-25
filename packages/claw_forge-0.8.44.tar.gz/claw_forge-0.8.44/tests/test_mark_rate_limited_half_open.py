"""Pin ``mark_provider_rate_limited`` to force OPEN regardless of state.

Pre-v0.8.44 the implementation was::

    cb = self._circuits[provider_name]
    for _ in range(cb.failure_threshold - cb._failure_count):
        cb.record_failure()

That's a no-op when ``cb._failure_count`` is already at or past the
threshold — which happens whenever the circuit was OPEN before and has
since transitioned to HALF_OPEN (recovery_timeout elapsed) without the
failure count being reset.  HALF_OPEN circuits are *available* per
``Router.select`` (one re-probe call allowed), so the pool re-picks the
provider that we just "tripped" → the dispatcher's exhaustion check
fires with N=1 → ``"All 1 configured provider(s) tripped by transient
errors; no fresh providers..."`` — even when there are multiple healthy
providers in the pool.

Real-world trigger: devShield project with two enabled OAuth providers
both in HALF_OPEN recovery after earlier transient failures.  v0.8.42's
more aggressive rotation triggers exposed this latent bug because the
re-trip in the same dispatcher session became common.

The fix forces ``_state = OPEN`` directly (rather than relying on
``record_failure``'s threshold-based transition), and resets
``_last_failure_time`` to the current monotonic clock so the
recovery_timeout window restarts from now.  Idempotent: calling it on
an already-OPEN circuit just refreshes the timestamp.
"""

from __future__ import annotations

import time

from claw_forge.pool.health import CircuitBreaker, CircuitState
from claw_forge.pool.manager import ProviderPoolManager
from claw_forge.pool.providers.base import ProviderConfig, ProviderType


def _cfg(name: str) -> ProviderConfig:
    return ProviderConfig(
        name=name, provider_type=ProviderType.ANTHROPIC, api_key="k",
    )


def test_marks_closed_circuit_open() -> None:
    """The baseline path: fresh CLOSED circuit → trip → OPEN."""
    pool = ProviderPoolManager([_cfg("p1")])
    cb = pool._circuits["p1"]
    assert cb.state == CircuitState.CLOSED
    assert pool.mark_provider_rate_limited("p1") is True
    assert cb.state == CircuitState.OPEN


def test_marks_half_open_circuit_open() -> None:
    """The bug case: HALF_OPEN circuit must flip back to OPEN.

    Pre-v0.8.44 mark_provider_rate_limited was a no-op here because
    ``range(threshold - count) = range(5-5) = range(0)``.  Circuit
    stayed HALF_OPEN → ``is_available`` returned True → pool re-picked
    the same provider → rotation hit exhaustion with N=1.
    """
    pool = ProviderPoolManager([_cfg("p1")])
    cb = pool._circuits["p1"]
    # Simulate: prior failures opened the circuit, then recovery_timeout
    # elapsed and it auto-transitioned to HALF_OPEN.
    cb._failure_count = cb.failure_threshold  # 5
    cb._state = CircuitState.OPEN
    cb._last_failure_time = time.monotonic() - cb.recovery_timeout - 1
    # Accessing .state property triggers the auto-transition.
    assert cb.state == CircuitState.HALF_OPEN
    assert cb.is_available is True  # The trap — looks available

    # Trip it.
    assert pool.mark_provider_rate_limited("p1") is True

    # Must be OPEN now (and is_available must report False).
    assert cb._state == CircuitState.OPEN, (
        "HALF_OPEN circuit must flip back to OPEN on trip; pre-v0.8.44 "
        "this was a no-op so the pool kept picking the same provider."
    )
    assert cb.is_available is False, (
        "After mark_rate_limited, is_available must be False so "
        "Router.select filters this provider out on the next pick."
    )


def test_marks_already_open_circuit_refreshes_timestamp() -> None:
    """Calling on an already-OPEN circuit refreshes the timestamp so
    recovery_timeout restarts.  Idempotent in state; refreshing in
    time."""
    pool = ProviderPoolManager([_cfg("p1")])
    cb = pool._circuits["p1"]
    cb._state = CircuitState.OPEN
    cb._failure_count = cb.failure_threshold
    cb._last_failure_time = time.monotonic() - 30  # 30s ago

    before = cb._last_failure_time
    pool.mark_provider_rate_limited("p1")
    after = cb._last_failure_time

    assert cb._state == CircuitState.OPEN
    assert after >= before, (
        "Re-tripping an already-OPEN circuit should refresh "
        "_last_failure_time so the recovery window restarts."
    )


def test_unknown_provider_returns_false() -> None:
    """Caller can detect "credential came from process env, not pool"
    via the False return — preserved from pre-v0.8.44 behaviour."""
    pool = ProviderPoolManager([_cfg("p1")])
    assert pool.mark_provider_rate_limited("env") is False
    assert pool.mark_provider_rate_limited("nonexistent") is False


def test_rotation_unblocked_by_half_open_trip() -> None:
    """End-to-end: 2 providers, p1 in HALF_OPEN recovery, mark p1 →
    next_provider_for_dispatch picks p2 (not p1 again).

    Pre-v0.8.44 this returned p1 because the HALF_OPEN circuit stayed
    HALF_OPEN.  Post-v0.8.44 it's forced to OPEN, Router.select filters
    it, and p2 is picked.
    """
    pool = ProviderPoolManager([_cfg("p1"), _cfg("p2")])

    # p1 in HALF_OPEN — looks available.
    cb1 = pool._circuits["p1"]
    cb1._failure_count = cb1.failure_threshold
    cb1._state = CircuitState.OPEN
    cb1._last_failure_time = time.monotonic() - cb1.recovery_timeout - 1
    assert cb1.is_available is True  # HALF_OPEN allows one re-probe

    # Trip p1.
    pool.mark_provider_rate_limited("p1")

    # Must pick p2, not p1.
    picked = pool.next_provider_for_dispatch()
    assert picked is not None
    assert picked.name == "p2", (
        f"After tripping HALF_OPEN p1, pool should pick p2 — but got "
        f"{picked.name!r}.  This is the meridian/devShield 'All 1' bug."
    )


def test_circuit_breaker_module_exports_unchanged() -> None:
    """Defensive: make sure the test file can still import what it expects."""
    assert CircuitBreaker is not None
    assert CircuitState.OPEN.value == "open"
