"""CLI flag tests for ``claw-forge run`` — push-after-merge plumbing.

The pattern: respx mocks the state-service ``POST /sessions/init`` endpoint
to return zero tasks (so ``run`` exits cleanly after init), and we patch
``claw_forge.cli.GitOps`` with a side_effect that captures construction
kwargs.  This lets us assert the CLI flag → ``GitOps(push_after_merge=...)``
plumbing without spinning up an agent dispatch.
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import respx
from httpx import Response
from typer.testing import CliRunner

from claw_forge.cli import app

_runner = CliRunner()


def _yaml(
    tmp_path: Path,
    *,
    push_after_merge: str | None = None,
    handle_uncommitted: str | None = None,
    isolation: str | None = None,
) -> Path:
    cfg = tmp_path / "claw-forge.yaml"
    body = (
        "providers: {}\n"
        "git:\n"
        "  enabled: true\n"
        "  merge_strategy: auto\n"
        "  branch_prefix: feat\n"
    )
    if push_after_merge is not None:
        body += f"  push_after_merge: {push_after_merge}\n"
    if handle_uncommitted is not None:
        body += f"  handle_uncommitted_at_startup: {handle_uncommitted}\n"
    body += (
        "agent:\n"
        "  default_model: claude-sonnet-4-6\n"
    )
    if isolation is not None:
        body += f"  isolation: {isolation}\n"
    cfg.write_text(body)
    return cfg


@pytest.fixture()
def project(tmp_path: Path) -> Path:
    subprocess.run(["git", "init", "-q", "-b", "main"], cwd=tmp_path, check=True)
    subprocess.run(["git", "config", "user.email", "t@x"], cwd=tmp_path, check=True)
    subprocess.run(["git", "config", "user.name", "t"], cwd=tmp_path, check=True)
    (tmp_path / "f.txt").write_text("seed")
    subprocess.run(["git", "add", "."], cwd=tmp_path, check=True)
    subprocess.run(["git", "commit", "-qm", "init"], cwd=tmp_path, check=True)
    return tmp_path


def _invoke_run(
    cfg_path: Path, project_path: Path, *extra_args: str,
) -> tuple[dict, str, int]:
    """Invoke ``claw-forge run`` with empty-task init and a captured GitOps.

    Returns (captured_kwargs, output, exit_code).
    """
    captured: dict = {}

    def _capture_git_ops(*args: object, **kwargs: object) -> MagicMock:
        captured.update(kwargs)
        # Return a real-looking mock so downstream code doesn't choke
        ops = MagicMock()
        ops.enabled = kwargs.get("enabled", True)
        ops.push_after_merge = kwargs.get("push_after_merge", False)
        return ops

    init_payload = {
        "session_id": "00000000-0000-0000-0000-000000000001",
        "orphans_reset": 0,
        "tasks_adopted": 0,
        "tasks": [],  # empty → run exits cleanly
    }

    base_url = "http://127.0.0.1:8420"
    with (
        respx.mock(base_url=base_url, assert_all_called=False) as mock,
        patch("claw_forge.orchestrator.run_cli._ensure_state_service", return_value=8420),
        patch("claw_forge.git.GitOps", side_effect=_capture_git_ops),
    ):
        mock.post("/sessions/init").mock(return_value=Response(200, json=init_payload))
        result = _runner.invoke(
            app,
            ["run", "--config", str(cfg_path), "--project", str(project_path),
             *extra_args],
        )

    return captured, result.output, result.exit_code


class TestPushAfterMergeFlags:
    def test_default_push_after_merge_off(self, project: Path) -> None:
        cfg = _yaml(project)
        captured, output, code = _invoke_run(cfg, project)
        assert code == 0, output
        assert captured.get("push_after_merge") is False

    def test_flag_enables_push_after_merge(self, project: Path) -> None:
        cfg = _yaml(project)
        captured, output, code = _invoke_run(
            cfg, project, "--push-after-merge",
        )
        assert code == 0, output
        assert captured.get("push_after_merge") is True

    def test_push_remote_overrides_default_origin(self, project: Path) -> None:
        cfg = _yaml(project)
        captured, output, code = _invoke_run(
            cfg, project, "--push-after-merge", "--push-remote", "upstream",
        )
        assert code == 0, output
        assert captured.get("push_after_merge") == "upstream"

    def test_config_bool_true_enables(self, project: Path) -> None:
        cfg = _yaml(project, push_after_merge="true")
        captured, output, code = _invoke_run(cfg, project)
        assert code == 0, output
        assert captured.get("push_after_merge") is True

    def test_config_string_remote_passes_through(self, project: Path) -> None:
        cfg = _yaml(project, push_after_merge='"upstream"')
        captured, output, code = _invoke_run(cfg, project)
        assert code == 0, output
        assert captured.get("push_after_merge") == "upstream"

    def test_cli_flag_overrides_config_false(self, project: Path) -> None:
        cfg = _yaml(project, push_after_merge="false")
        captured, output, code = _invoke_run(
            cfg, project, "--push-after-merge",
        )
        assert code == 0, output
        assert captured.get("push_after_merge") is True


class TestHandleUncommittedAtStartup:
    """Wiring: ``git.handle_uncommitted_at_startup`` config controls
    the startup handler — autonomous in smart mode, fail-fast in abort
    mode, no-op in ignore mode."""

    def test_ignore_mode_skips_handler(self, project: Path) -> None:
        from unittest.mock import patch

        cfg = _yaml(project)  # no key set → default ``ignore``
        (project / "wip.py").write_text("x")

        with patch(
            "claw_forge.git.cleanup.smart_handle_uncommitted_in_project_dir"
        ) as mock_handler:
            _, _, code = _invoke_run(cfg, project)

        assert mock_handler.call_count == 0
        assert code == 0
        assert (project / "wip.py").exists()

    def test_smart_mode_calls_handler(self, project: Path) -> None:
        from unittest.mock import patch

        from claw_forge.git.cleanup import UncommittedHandlingResult

        cfg = _yaml(project, handle_uncommitted="smart")

        with patch(
            "claw_forge.git.cleanup.smart_handle_uncommitted_in_project_dir",
            return_value=UncommittedHandlingResult(),
        ) as mock_handler:
            _, _, code = _invoke_run(cfg, project)

        assert mock_handler.call_count == 1
        assert code == 0

    def test_smart_mode_succeeds_with_real_untracked(
        self, project: Path,
    ) -> None:
        """End-to-end: smart mode autonomously archives untracked +
        proceeds; never aborts."""
        cfg = _yaml(project, handle_uncommitted="smart")
        (project / "wip.py").write_text("x")

        _, output, code = _invoke_run(cfg, project)

        assert code == 0
        # File got archived, console reports it
        assert "Archived" in output
        assert not (project / "wip.py").exists()
        # Archived to .claw-forge/orphans/<ts>/wip.py
        archives = list(
            (project / ".claw-forge" / "orphans").iterdir()
        )
        assert len(archives) == 1
        assert (archives[0] / "wip.py").exists()

    def test_smart_mode_succeeds_with_dirty_tracked(
        self, project: Path,
    ) -> None:
        """End-to-end: smart mode autonomously stashes dirty tracked
        files + proceeds."""
        cfg = _yaml(project, handle_uncommitted="smart")
        (project / "f.txt").write_text("modified seed")

        _, output, code = _invoke_run(cfg, project)

        assert code == 0
        assert "Stashed" in output
        # Working tree restored
        assert (project / "f.txt").read_text() == "seed"

    def test_abort_mode_fails_on_untracked(
        self, project: Path,
    ) -> None:
        cfg = _yaml(project, handle_uncommitted="abort")
        (project / "wip.py").write_text("x")

        _, output, code = _invoke_run(cfg, project)

        assert code != 0
        assert "wip.py" in output

    def test_abort_mode_fails_on_dirty_tracked(
        self, project: Path,
    ) -> None:
        cfg = _yaml(project, handle_uncommitted="abort")
        (project / "f.txt").write_text("modified")

        _, output, code = _invoke_run(cfg, project)

        assert code != 0
        assert "f.txt" in output


class TestYoloUpgradesUncommittedHandling:
    """``--yolo`` upgrades the default for ``handle_uncommitted_at_startup``
    from ``ignore`` to ``smart`` (autonomous archive + stash).  Explicit
    user-set config values still win — yolo only flips the default."""

    def test_yolo_upgrades_default_to_smart(
        self, project: Path,
    ) -> None:
        """No explicit config + ``--yolo`` → handler called in smart mode."""
        from unittest.mock import patch

        from claw_forge.git.cleanup import UncommittedHandlingResult

        cfg = _yaml(project)  # no handle_uncommitted_at_startup key

        with patch(
            "claw_forge.git.cleanup.smart_handle_uncommitted_in_project_dir",
            return_value=UncommittedHandlingResult(),
        ) as mock_handler:
            _, _, code = _invoke_run(cfg, project, "--yolo")

        assert mock_handler.call_count == 1
        assert code == 0

    def test_no_yolo_keeps_ignore_default(
        self, project: Path,
    ) -> None:
        """No explicit config + no ``--yolo`` → handler NOT called."""
        from unittest.mock import patch

        cfg = _yaml(project)

        with patch(
            "claw_forge.git.cleanup.smart_handle_uncommitted_in_project_dir"
        ) as mock_handler:
            _, _, code = _invoke_run(cfg, project)

        assert mock_handler.call_count == 0
        assert code == 0

    def test_yolo_does_not_override_explicit_ignore(
        self, project: Path,
    ) -> None:
        """User explicitly set ``ignore`` → yolo respects it.  Principle of
        least surprise: yolo flips the default, not explicit settings."""
        from unittest.mock import patch

        cfg = _yaml(project, handle_uncommitted="ignore")

        with patch(
            "claw_forge.git.cleanup.smart_handle_uncommitted_in_project_dir"
        ) as mock_handler:
            _, _, code = _invoke_run(cfg, project, "--yolo")

        assert mock_handler.call_count == 0

    def test_yolo_does_not_override_explicit_abort(
        self, project: Path,
    ) -> None:
        """User explicitly set ``abort`` → yolo respects it; the run still
        fail-fasts on uncommitted state."""
        cfg = _yaml(project, handle_uncommitted="abort")
        (project / "wip.py").write_text("x")

        _, output, code = _invoke_run(cfg, project, "--yolo")

        assert code != 0
        assert "wip.py" in output


class TestAgentIsolationConfig:
    """v0.8.21: ``agent.isolation`` config parsing.

    Three valid values: ``sandbox`` (canonical default), ``container``
    (opt-in), and ``process`` (legacy alias for ``sandbox``).  Invalid
    values fail dispatch with a clear error pointing at the valid
    options.
    """

    def test_default_is_sandbox(self, project: Path) -> None:
        """No ``agent.isolation`` key in config → defaults to
        ``sandbox`` (the v0.8.21 default).  Run completes without
        error since no tasks are dispatched (empty init payload)."""
        cfg = _yaml(project)  # no isolation key
        _, output, code = _invoke_run(cfg, project)
        assert code == 0, output

    def test_explicit_sandbox_accepted(self, project: Path) -> None:
        """``isolation: sandbox`` is the canonical name introduced
        in v0.8.21 — accepted with no warning."""
        cfg = _yaml(project, isolation="sandbox")
        _, output, code = _invoke_run(cfg, project)
        assert code == 0, output

    def test_legacy_process_alias_accepted(self, project: Path) -> None:
        """v0.8.18 → v0.8.20 used ``process`` as the value name; this
        contract test pins the alias resolution so existing configs
        keep working without modification."""
        cfg = _yaml(project, isolation="process")
        _, output, code = _invoke_run(cfg, project)
        assert code == 0, output

    def test_invalid_value_rejected(self, project: Path) -> None:
        """Unknown values fail with an actionable error — operators
        get told the valid options explicitly rather than discovering
        the failure mode through cryptic agent crashes."""
        cfg = _yaml(project, isolation="bogus")
        _, output, code = _invoke_run(cfg, project)
        assert code != 0
        assert "is not a valid value" in output
        assert "sandbox" in output
        assert "container" in output

    def test_container_without_image_rejected(
        self, project: Path,
    ) -> None:
        """``container`` mode requires ``agent.container.image`` —
        omitting it fails fast (operator opted in to container
        isolation; silent fallback to sandbox would violate the
        explicit choice)."""
        cfg = _yaml(project, isolation="container")
        _, output, code = _invoke_run(cfg, project)
        assert code != 0
        assert "agent.container.image" in output
