"""Pin rotation when the SDK reports an underspecified error (v0.8.42).

The dispatcher in ``task_handler.py`` raises ``RuntimeError`` in two places
where the rotation classifier ``is_retryable_provider_error`` historically
returned False — silently disabling provider rotation:

1. ``msg.error`` set with the SDK's unhelpful default ``"unknown"`` →
   wrapper text ``"Agent error: unknown — check claude login or verify
   API key in .env"``.  The actual transient signal (``"API Error: Stream
   idle timeout"``, etc.) lives in the assistant's *recent text output*
   immediately before the error message.  Pre-v0.8.42 that context never
   reached the classifier.

2. Agent produced no output at all → wrapper text ``"Agent produced no
   output — check claude login or verify API key in .env"``.  Zero patterns
   match, even though "produced no output" from the SDK is itself a strong
   rotation signal (provider returned nothing useful — try another).

Real-world trigger: meridian task ``8c400669`` failed on 2026-05-20 with
``msg.error = "unknown"`` preceded by an SDK ``"API Error: Stream idle
timeout - partial response"`` assistant turn.  The rotation classifier
saw only ``"Agent error: unknown — check claude login..."`` and skipped
rotation; task flipped to ``failed`` with no retry.

This file pins:

(a) The new patterns added to ``PROVIDER_TRANSIENT_PATTERNS`` so the
    no-output wrapper and stream-idle/stream-error variants classify
    as retryable.
(b) The new ``compose_agent_error`` helper that combines ``_err`` with
    recent assistant text so the classifier can see the underlying SDK
    error even when ``_err`` is ``"unknown"``.
"""

from __future__ import annotations


class TestPatternAdditions:
    def test_produced_no_output_classifies_as_retryable(self) -> None:
        from claw_forge.agent.rate_limit import is_retryable_provider_error
        assert is_retryable_provider_error(
            "Agent produced no output — check `claude login` or verify "
            "API key in .env"
        ) is True, (
            "Empty-output wrapper must trigger rotation: a silent SDK "
            "failure on one provider may succeed on another."
        )

    def test_stream_idle_timeout_classifies_as_retryable(self) -> None:
        from claw_forge.agent.rate_limit import is_retryable_provider_error
        # ``\\btimeout\\b`` already matches this, but a dedicated test
        # pins the contract so a future regex rewrite doesn't lose it.
        assert is_retryable_provider_error(
            "API Error: Stream idle timeout - partial response"
        ) is True

    def test_stream_error_classifies_as_retryable(self) -> None:
        from claw_forge.agent.rate_limit import is_retryable_provider_error
        assert is_retryable_provider_error(
            "API Error: stream error - connection lost"
        ) is True

    def test_bare_unknown_without_context_still_classifies_as_retryable(
        self,
    ) -> None:
        """``Agent error: unknown`` from the SDK is itself a rotation
        signal — the SDK admitting it doesn't know what failed strongly
        suggests something at the provider layer broke.  Conservative
        in isolation, retryable when the dispatcher wraps it.
        """
        from claw_forge.agent.rate_limit import is_retryable_provider_error
        assert is_retryable_provider_error(
            "Agent error: unknown — check `claude login` or verify API "
            "key in .env"
        ) is True, (
            "After the v0.8.42 pattern additions, the dispatcher's "
            "stock ``Agent error: unknown`` wrapper must trigger rotation."
        )


class TestComposeAgentErrorHelper:
    """``compose_agent_error`` combines the SDK's error attr with the
    assistant's recent text output so the rotation classifier sees the
    underlying signal even when ``_err`` is ``"unknown"``."""

    def test_compose_includes_recent_output_context(self) -> None:
        from claw_forge.orchestrator.task_handler import compose_agent_error
        out = compose_agent_error(
            err="unknown",
            recent_output=[
                "thinking about the problem",
                "API Error: Stream idle timeout - partial response",
            ],
        )
        assert "unknown" in out
        assert "Stream idle timeout" in out, (
            "Recent assistant output must be included so the rotation "
            "classifier can detect the underlying transient signal."
        )

    def test_compose_truncates_long_output(self) -> None:
        from claw_forge.orchestrator.task_handler import compose_agent_error
        # Pathological long output mustn't blow up the error string size
        out = compose_agent_error(
            err="unknown",
            recent_output=["x" * 5000, "y" * 5000],
        )
        # ≤1 KB cap leaves room for the wrapper boilerplate
        assert len(out) < 1500

    def test_compose_handles_empty_output(self) -> None:
        """No output yet — wrapper still produces a coherent message."""
        from claw_forge.orchestrator.task_handler import compose_agent_error
        out = compose_agent_error(err="unknown", recent_output=[])
        assert "unknown" in out

    def test_composed_string_triggers_rotation_when_context_is_transient(
        self,
    ) -> None:
        """End-to-end: the helper's output, passed to the classifier,
        flips to True when recent output carries a transient signal."""
        from claw_forge.agent.rate_limit import is_retryable_provider_error
        from claw_forge.orchestrator.task_handler import compose_agent_error
        composed = compose_agent_error(
            err="unknown",
            recent_output=[
                "API Error: Stream idle timeout - partial response",
            ],
        )
        assert is_retryable_provider_error(composed) is True, (
            "End-to-end contract: helper output + classifier must "
            "agree that a stream-idle-timeout warrants rotation."
        )
