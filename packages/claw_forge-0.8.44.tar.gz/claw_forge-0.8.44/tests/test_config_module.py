"""Sanity tests for the claw_forge.config module + cli.py shim back-compat."""
from __future__ import annotations


def test_config_module_exports_expected_symbols() -> None:
    """All public helpers exist on claw_forge.config."""
    from claw_forge import config

    assert callable(config._load_env_file)
    assert callable(config._expand_env_vars)
    assert callable(config._load_config)
    assert callable(config._scaffold_config)
    assert isinstance(config._DEFAULT_CONFIG_YAML, str)
    assert isinstance(config._DEFAULT_ENV_EXAMPLE, str)


def test_cli_shim_reexports_config_helpers() -> None:
    """Tests that import from claw_forge.cli keep working after the move."""
    from claw_forge.cli import (
        _DEFAULT_CONFIG_YAML,
        _load_config,
        _load_env_file,
    )

    assert callable(_load_env_file)
    assert callable(_load_config)
    assert isinstance(_DEFAULT_CONFIG_YAML, str)


def test_expand_env_vars_handles_bash_default() -> None:
    """${VAR:-default} substitutes the default when VAR is unset."""
    import os

    from claw_forge.config import _expand_env_vars

    os.environ.pop("CLAW_FORGE_TEST_UNSET", None)
    result = _expand_env_vars("${CLAW_FORGE_TEST_UNSET:-fallback}")
    assert result == "fallback"


def test_expand_env_vars_recurses_into_dicts_and_lists() -> None:
    """Recursion through dicts and lists preserves structure."""
    import os

    from claw_forge.config import _expand_env_vars

    os.environ["CLAW_FORGE_TEST_X"] = "expanded"
    result = _expand_env_vars({"a": "${CLAW_FORGE_TEST_X}", "b": ["${CLAW_FORGE_TEST_X}", 1]})
    assert result == {"a": "expanded", "b": ["expanded", 1]}
    del os.environ["CLAW_FORGE_TEST_X"]
