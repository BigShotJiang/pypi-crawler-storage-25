"""Smoke tests for the ``run`` command's post-extraction shape.

After PR 7 of the cli.py decomposition, the ``run`` command and its
~2400 lines of dispatcher / task-handler / agent-prep code live under
``claw_forge/orchestrator/``.  These tests pin the public shape that
existing tests rely on so future refactors don't accidentally break the
back-compat shim.
"""

from __future__ import annotations

import pytest
from typer.testing import CliRunner

# Eagerly import claw_forge.cli at collection time so its transitive chain
# (boundaries → agent.permissions → claude_agent_sdk.types) resolves BEFORE
# any other test file's collection-time ``sys.modules`` stubs can shadow
# ``claude_agent_sdk`` with an empty module — see test_release_coverage.py.
from claw_forge import cli as _cli  # noqa: F401


def test_run_command_appears_in_main_cli_help() -> None:
    """``claw-forge --help`` still lists ``run`` after the move."""
    from claw_forge.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "run" in result.stdout


def test_run_command_help_unchanged(monkeypatch: pytest.MonkeyPatch) -> None:
    """``run --help`` lists every flag it had before the extraction.

    Forces ``COLUMNS=240`` so Typer's Rich-backed renderer doesn't wrap
    long flag names across lines (which would defeat the substring
    assertion).
    """
    monkeypatch.setenv("COLUMNS", "240")
    from claw_forge.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["run", "--help"])
    assert result.exit_code == 0
    for flag in (
        "--config",
        "--project",
        "--task",
        "--model",
        "--plan-model",
        "--concurrency",
        "--yolo",
        "--dry-run",
        "--edit-mode",
        "--loop-detect-threshold",
        "--verify-on-exit",
        "--push-after-merge",
        "--github-mode",
        "--adversarial-review",
        "--reset-threshold",
    ):
        assert flag in result.stdout, f"missing flag {flag!r}"


def test_run_context_dataclass_importable() -> None:
    """``RunContext`` is exposed from ``orchestrator.task_handler``."""
    from claw_forge.orchestrator.task_handler import RunContext

    assert RunContext.__name__ == "RunContext"
    # Spot-check a few required fields so a future field-rename trips the gate.
    annotations = RunContext.__annotations__
    for field_name in (
        "state_base",
        "session_id",
        "git_ops",
        "git_enabled",
        "active_worktrees",
        "pending_merge_retries",
    ):
        assert field_name in annotations, f"missing RunContext field {field_name}"


def test_cli_shim_reexports_run_helpers() -> None:
    """The four run helpers stay importable from ``claw_forge.cli``.

    test_cli_merge_gating.py imports ``_set_merged_after_merge``,
    test_cli_file_claims.py imports ``_try_claim_files``,
    test_resolve_sdk_credentials.py imports ``_resolve_sdk_credentials``,
    tests/git/test_dispatcher_git.py imports ``_create_and_sync_worktree``.
    """
    from claw_forge.cli import (
        _create_and_sync_worktree,
        _resolve_sdk_credentials,
        _set_merged_after_merge,
        _try_claim_files,
    )

    assert callable(_create_and_sync_worktree)
    assert callable(_resolve_sdk_credentials)
    assert callable(_set_merged_after_merge)
    assert callable(_try_claim_files)


def test_run_command_registered_via_subapp_pattern() -> None:
    """``run`` is registered through ``app.command``-as-function (Pattern A)."""
    from claw_forge.cli import app
    from claw_forge.orchestrator.run_cli import run as run_cmd

    registered = {cmd.name for cmd in app.registered_commands}
    assert "run" in registered

    # The function lives in orchestrator.run_cli, not cli.
    assert run_cmd.__module__ == "claw_forge.orchestrator.run_cli"


def test_checkpointing_module_importable() -> None:
    """``periodic_checkpoint_loop`` is exposed from ``orchestrator.checkpointing``."""
    from claw_forge.orchestrator.checkpointing import periodic_checkpoint_loop

    assert callable(periodic_checkpoint_loop)


class TestApplyNpmSafetyEnv:
    """v0.8.33: ``_apply_npm_safety_env`` injects supply-chain-safety env
    vars into the agent's ``sdk_env``.  Tests pin the public contract —
    keys set, opt-out behavior, and operator-pinned value precedence."""

    def test_injects_npm_and_yarn_keys_when_enabled(self) -> None:
        """The headline contract: both npm-style (``npm_config_*``) and
        yarn-2-style (``YARN_*``) get the disable-postinstall setting.
        Covers npm, pnpm (inherits ``npm_config_*``), Yarn 1 (npm-style
        env var), and Yarn 2+ (``YARN_ENABLE_SCRIPTS``)."""
        from claw_forge.orchestrator.task_handler import _apply_npm_safety_env

        env: dict[str, str] = {}
        _apply_npm_safety_env(env, enabled=True)
        assert env["npm_config_ignore_scripts"] == "true"
        assert env["YARN_ENABLE_SCRIPTS"] == "false"

    def test_no_op_when_disabled(self) -> None:
        """Opt-out path: a project that legitimately needs install hooks
        sets ``agent.npm_ignore_scripts: false`` and the dispatcher
        passes ``enabled=False`` here — env stays untouched."""
        from claw_forge.orchestrator.task_handler import _apply_npm_safety_env

        env: dict[str, str] = {"FOO": "bar"}
        _apply_npm_safety_env(env, enabled=False)
        assert env == {"FOO": "bar"}

    def test_setdefault_respects_pre_existing_keys(self) -> None:
        """Operator pre-set values win.  Useful when a specific run
        needs a non-default policy without flipping the project-wide
        config.  Pin the precedence — pool/operator env > our default."""
        from claw_forge.orchestrator.task_handler import _apply_npm_safety_env

        env: dict[str, str] = {"npm_config_ignore_scripts": "false"}
        _apply_npm_safety_env(env, enabled=True)
        # Pre-existing operator value is preserved.
        assert env["npm_config_ignore_scripts"] == "false"
        # But the other key still gets the default.
        assert env["YARN_ENABLE_SCRIPTS"] == "false"


class TestRunContextSupplyChainFields:
    """v0.8.33: RunContext gained two defaults-on knobs for supply-chain
    hardening — pin the defaults so a future field rename / default flip
    is flagged by a test rather than a silent weakening."""

    def test_npm_ignore_scripts_defaults_true(self) -> None:
        """Default ``True`` so fresh installs / migrated configs get the
        protection without operator action.  Explicit opt-out via
        ``agent.npm_ignore_scripts: false`` in claw-forge.yaml."""
        from claw_forge.orchestrator.task_handler import RunContext

        annotations = RunContext.__annotations__
        assert "npm_ignore_scripts" in annotations

    def test_sandbox_home_protection_defaults_true(self) -> None:
        from claw_forge.orchestrator.task_handler import RunContext

        annotations = RunContext.__annotations__
        assert "sandbox_home_protection" in annotations
