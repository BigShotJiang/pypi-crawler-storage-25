"""Pin the end-of-run summary logic (v0.8.41).

Pre-v0.8.41 the dispatcher printed ``🎉 All tasks succeeded!`` whenever
the in-invocation ``total_failed`` set was empty — regardless of whether
the session had ``failed`` tasks from prior invocations that this run
never touched.

Real-world trigger: meridian project on 2026-05-22.  A prior
``claw-forge run`` completed 153 tasks, exited cleanly, printed
"All tasks succeeded!" — but the session still had task ``8c400669``
in ``failed`` state from a Stream-idle-timeout on 2026-05-20 that the
prior run never knew about (it joined the session AFTER the failure
was recorded; status=``failed`` tasks are excluded from
``total_failed`` because they weren't failed-during-this-invocation).

Fix: query session state at end-of-run.  Report accurately based on
all session tasks, not just in-invocation deltas.  Falls back to the
legacy message shape when the state service is unreachable so users
on broken setups still see something coherent.
"""

from __future__ import annotations

from typing import Any


def _summary(
    *,
    total_completed: dict[str, Any] | None = None,
    total_failed: dict[str, str] | None = None,
    session_tasks: list[dict[str, Any]] | None = None,
) -> str:
    """Helper: render the summary as a single string for substring checks."""
    from claw_forge.orchestrator.run_cli import format_run_summary

    lines = format_run_summary(
        total_completed=total_completed or {},
        total_failed=total_failed or {},
        session_tasks=session_tasks,
    )
    return "\n".join(lines)


class TestRunSummary:
    def test_session_fully_complete_prints_all_succeeded(self) -> None:
        """When every session task is completed+merged, print the celebration."""
        tasks = [
            {"status": "completed", "merged_to_target_branch": True}
            for _ in range(5)
        ]
        out = _summary(
            total_completed={f"t{i}": {} for i in range(5)},
            session_tasks=tasks,
        )
        assert "All session tasks succeeded" in out
        assert "5/5" in out

    def test_session_has_failed_tasks_does_not_print_all_succeeded(self) -> None:
        """Reproduces the meridian regression: a session with previously-failed
        tasks (not touched by this invocation) MUST NOT print 'All succeeded'.
        """
        tasks = [
            {"status": "completed", "merged_to_target_branch": True},
            {"status": "completed", "merged_to_target_branch": True},
            {"status": "failed", "merged_to_target_branch": False},  # prior fail
        ]
        out = _summary(
            total_completed={"t1": {}, "t2": {}},
            total_failed={},  # this-run failures empty — the regression case
            session_tasks=tasks,
        )
        assert "All session tasks succeeded" not in out, (
            "Bug regression: 'All succeeded' printed even though the "
            "session has a failed task from a prior invocation.  "
            "format_run_summary must consult session_tasks, not just "
            "total_failed."
        )
        assert "Failed" in out
        assert "1" in out  # the one failed task surfaces

    def test_session_with_pending_tasks_lists_pending_bucket(self) -> None:
        """Pending leftovers (e.g. blocked behind un-merged parents) listed."""
        tasks = [
            {"status": "completed", "merged_to_target_branch": True},
            {"status": "pending"},
            {"status": "pending"},
        ]
        out = _summary(session_tasks=tasks)
        assert "All session tasks succeeded" not in out
        assert "Pending" in out
        assert "2" in out

    def test_completed_unmerged_counts_as_not_done(self) -> None:
        """The v0.5.35 bug class: completed AND has commit but never merged
        to target.  Must surface so the operator knows manual salvage may
        be needed.
        """
        tasks = [
            {"status": "completed", "merged_to_target_branch": True},
            {"status": "completed", "merged_to_target_branch": False},  # zombie
        ]
        out = _summary(session_tasks=tasks)
        assert "All session tasks succeeded" not in out

    def test_session_tasks_none_falls_back_to_legacy_message(self) -> None:
        """When the state service is unreachable at end-of-run, the
        summary must still produce SOMETHING — fall back to the
        legacy in-invocation-only message rather than crash."""
        out = _summary(
            total_completed={"t1": {}, "t2": {}},
            total_failed={},
            session_tasks=None,
        )
        assert "All tasks succeeded" in out  # legacy message preserved

    def test_in_invocation_failures_still_surface_in_addition(self) -> None:
        """Both buckets are useful: in-invocation failures (often
        transient — provider rotations exhausted, etc.) and session-level
        failures (terminal, may need reset).  Show both."""
        tasks = [
            {"status": "completed", "merged_to_target_branch": True},
            {"status": "failed"},
        ]
        out = _summary(
            total_completed={"t1": {}},
            total_failed={"t-just-failed": "rate_limit retries exhausted"},
            session_tasks=tasks,
        )
        # The in-invocation failure list still shows so the user sees what
        # just happened, AND the session-level breakdown shows so they see
        # everything that needs attention.
        assert "Failed" in out
        # ``All session tasks succeeded`` MUST NOT appear because the
        # session has 1 failed task.
        assert "All session tasks succeeded" not in out
