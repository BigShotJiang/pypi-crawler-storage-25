"""Pin the dispatcher-side heartbeat task (v0.8.39).

The state service exposes ``POST /sessions/{id}/dispatcher/heartbeat`` —
the dispatcher must call it every ~30 s while alive so the corresponding
``GET .../dispatcher/status`` flips to ``alive: True``.  Without the
client-side task, the status endpoint is decorative.

Two layers of test here:

1. **Behavioral** — drive the heartbeat loop against a real ASGI state
   service and verify ``dispatcher/status`` reports alive.  Confirms the
   loop POSTs to the right URL with the right path shape.
2. **AST wiring** — assert that ``run_cli.py`` imports and starts the
   heartbeat loop alongside the dispatcher kickoff.  Catches the
   regression where the loop module exists but nothing calls it.
"""

from __future__ import annotations

import ast
import asyncio
import contextlib
from pathlib import Path
from typing import Any

import httpx
import pytest
from fastapi.testclient import TestClient
from httpx import ASGITransport


@pytest.fixture
def state_app(tmp_path: Path) -> Any:
    from claw_forge.state.service import AgentStateService

    db_url = f"sqlite+aiosqlite:///{tmp_path / 'state.db'}"
    svc = AgentStateService(database_url=db_url)
    return svc.create_app()


@pytest.mark.asyncio
async def test_heartbeat_loop_flips_status_to_alive(state_app: Any) -> None:
    """Drive the loop against a real ASGI app and confirm status flips."""
    from claw_forge.orchestrator.heartbeat import heartbeat_loop

    # Trigger lifespan synchronously so the tables exist before the
    # async ASGITransport block hits the API.
    with TestClient(state_app):
        pass

    transport = ASGITransport(app=state_app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test",
    ) as client:
        sresp = await client.post(
            "/sessions", json={"project_path": "/tmp/p"},
        )
        sid = sresp.json()["id"]

        # Run the loop with a short interval; cancel after one POST has
        # landed.  Pass the client through so we don't depend on real
        # networking from the loop's default httpx client.
        task = asyncio.create_task(
            heartbeat_loop(
                state_base="http://test",
                session_id=sid,
                interval_seconds=0.05,
                client=client,
            ),
        )
        # Wait long enough for at least one POST to land.
        await asyncio.sleep(0.15)
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task

        # Status should now report alive.
        resp = await client.get(f"/sessions/{sid}/dispatcher/status")
        body = resp.json()
        assert body["alive"] is True, (
            "Heartbeat loop ran but status reports offline.  Likely the "
            "loop POSTed to a different URL or the body was rejected."
        )
        assert body["last_heartbeat_iso"] is not None


@pytest.mark.asyncio
async def test_heartbeat_loop_survives_transient_post_failure(
    state_app: Any,
) -> None:
    """A 5xx/network error on one POST must NOT abort the loop.

    The dispatcher must keep heartbeating across transient state-service
    hiccups so a brief network blip doesn't make the UI declare the
    dispatcher dead.
    """
    from claw_forge.orchestrator.heartbeat import heartbeat_loop

    with TestClient(state_app):
        pass

    call_count = {"n": 0}

    transport = ASGITransport(app=state_app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test",
    ) as real_client:
        # Wrap the real client so the first POST raises, subsequent ones
        # succeed.  Mirrors a transient network hiccup.
        class FlakyClient:
            async def post(self, url: str, **kw: Any) -> Any:
                call_count["n"] += 1
                if call_count["n"] == 1:
                    raise httpx.ConnectError("transient")
                return await real_client.post(url, **kw)

        sresp = await real_client.post(
            "/sessions", json={"project_path": "/tmp/p"},
        )
        sid = sresp.json()["id"]

        task = asyncio.create_task(
            heartbeat_loop(
                state_base="http://test",
                session_id=sid,
                interval_seconds=0.05,
                client=FlakyClient(),  # type: ignore[arg-type]
            ),
        )
        await asyncio.sleep(0.2)
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task

        assert call_count["n"] >= 2, (
            "Loop stopped after the first failure — the recovery path "
            "is missing.  A transient network hiccup must not be fatal."
        )
        resp = await real_client.get(f"/sessions/{sid}/dispatcher/status")
        assert resp.json()["alive"] is True


# ── AST wiring test ─────────────────────────────────────────────────────────


def _run_cli_source() -> tuple[str, ast.AST]:
    p = Path(__file__).resolve().parents[2] / "claw_forge/orchestrator/run_cli.py"
    src = p.read_text()
    return src, ast.parse(src)


def test_run_cli_imports_heartbeat_loop() -> None:
    """``run_cli.py`` must import the heartbeat loop helper."""
    _src, tree = _run_cli_source()
    del _src
    found = False
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.ImportFrom)
            and node.module == "claw_forge.orchestrator.heartbeat"
            and any(a.name == "heartbeat_loop" for a in node.names)
        ):
            found = True
            break
    assert found, (
        "run_cli.py must import heartbeat_loop from "
        "claw_forge.orchestrator.heartbeat — otherwise the server-side "
        "/dispatcher/status endpoint stays permanently offline because "
        "no client is posting heartbeats."
    )


def test_run_cli_starts_heartbeat_task() -> None:
    """run_cli.py must spawn the heartbeat as an asyncio Task.

    Looks for a Call where the function name is ``create_task`` and the
    inner Call's function name is ``heartbeat_loop``.  Catches regressions
    where the import remains but the call site is deleted.
    """
    _src, tree = _run_cli_source()
    del _src
    found = False
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        f = node.func
        name = f.id if isinstance(f, ast.Name) else (
            f.attr if isinstance(f, ast.Attribute) else None
        )
        if name != "create_task":
            continue
        # Inspect first positional arg
        if not node.args:
            continue
        inner = node.args[0]
        if not isinstance(inner, ast.Call):
            continue
        inf = inner.func
        iname = inf.id if isinstance(inf, ast.Name) else (
            inf.attr if isinstance(inf, ast.Attribute) else None
        )
        if iname == "heartbeat_loop":
            found = True
            break
    assert found, (
        "run_cli.py must call asyncio.create_task(heartbeat_loop(...)) so "
        "the dispatcher actually pings the state service.  Import without "
        "use means /dispatcher/status stays permanently offline."
    )
