"""Pin training-trace recorder wiring on the dispatcher hot path.

The plugin layer (``plugins/coding.py`` etc.) is NOT on the dispatcher's
hot path — ``orchestrator/task_handler.py`` constructs ``ClaudeAgentOptions``
and consumes ``AgentSession.run(prompt)`` directly, never invoking
``plugin.execute(context)``.  This means anything wired only into a
plugin's ``execute()`` is silently inert for ``claw-forge run``.

The training-trace recorder MUST be wired here in task_handler.py
around the ``agent_session.run()`` async iterator, in addition to the
plugin-path wiring in ``agent/runner.py``.  Without this, the
defaults-on ``training_traces.{enabled,acknowledged_terms}`` config
captures zero ``agent_message`` events for every ``claw-forge run``
session — and ``claw-forge export training`` returns an empty corpus.

AST-inspection is the right tool here: spinning up ``AgentSession``
requires the real ``claude`` CLI binary, but the structural wiring
contract is exactly what we want to lock in.
"""

import ast
from pathlib import Path

TASK_HANDLER = Path(__file__).resolve().parents[2] / (
    "claw_forge/orchestrator/task_handler.py"
)


def _source_tree() -> tuple[str, ast.AST]:
    src = TASK_HANDLER.read_text()
    return src, ast.parse(src)


def test_task_handler_imports_record_messages() -> None:
    """task_handler.py must import ``record_messages`` (top-level or lazy)."""
    _src, tree = _source_tree()
    del _src
    found = False
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.ImportFrom)
            and node.module == "claw_forge.training.recorder"
            and any(a.name == "record_messages" for a in node.names)
        ):
            found = True
            break
    assert found, (
        "task_handler.py must import record_messages from "
        "claw_forge.training.recorder.  Without this import the "
        "dispatcher hot path cannot tee SDK messages to /events — "
        "see project_dispatcher_bypasses_plugin_layer.md for the "
        "v0.8.35 regression history."
    )


def test_task_handler_calls_record_messages() -> None:
    """task_handler.py must call ``record_messages(...)`` somewhere.

    The call wraps the raw ``agent_session.run(prompt)`` async iterator
    so each SDK message is POSTed to ``/tasks/<id>/agent-log`` as an
    ``agent_message`` event before being re-yielded to the consumer.
    """
    _src, tree = _source_tree()
    del _src
    found = False
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            func = node.func
            name = None
            if isinstance(func, ast.Name):
                name = func.id
            elif isinstance(func, ast.Attribute):
                name = func.attr
            if name == "record_messages":
                found = True
                break
    assert found, (
        "task_handler.py must call record_messages() to wrap the "
        "agent_session.run(prompt) async iterator.  Without this call "
        "the recorder is inert on `claw-forge run` (the dispatcher hot "
        "path) and training_traces captures zero events despite the "
        "defaults-on config.  See "
        "project_dispatcher_bypasses_plugin_layer.md."
    )


def test_task_handler_uses_destination_from_context() -> None:
    """The destination must be built via ``destination_from_context``
    so the existing ``training_traces.{enabled,acknowledged_terms}``
    config gate is honoured uniformly across runner.py and task_handler.py.
    """
    src, tree = _source_tree()
    # destination_from_context may be imported lazily or eagerly — both OK.
    has_call = any(
        isinstance(n, ast.Call)
        and (
            (isinstance(n.func, ast.Name) and n.func.id == "destination_from_context")
            or (
                isinstance(n.func, ast.Attribute)
                and n.func.attr == "destination_from_context"
            )
        )
        for n in ast.walk(tree)
    )
    # Constructing RecordingDestination directly is also acceptable when
    # the gating is already done via training_traces config plumbed onto
    # RunContext.  Accept either pattern.
    has_direct = "RecordingDestination(" in src
    assert has_call or has_direct, (
        "task_handler.py must build the RecordingDestination via "
        "destination_from_context() OR construct RecordingDestination "
        "directly (gating via RunContext fields).  Neither pattern was "
        "detected — recorder destination is not being built on the "
        "dispatcher path."
    )
