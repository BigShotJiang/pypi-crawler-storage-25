"""Smoke tests for the spec subapp."""
from __future__ import annotations

from typer.testing import CliRunner


def test_spec_commands_appear_in_main_cli_help() -> None:
    from claw_forge.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    for cmd in ("plan", "validate-spec", "import"):
        assert cmd in result.stdout


def test_cli_shim_reexports_write_plan_to_db() -> None:
    """test_three_phase_pipeline.py imports _write_plan_to_db from cli — must still work."""
    from claw_forge.cli import _write_plan_to_db
    assert callable(_write_plan_to_db)


def test_each_spec_command_help_works() -> None:
    """Each command's --help exits 0 (Typer wiring intact)."""
    from claw_forge.cli import app

    runner = CliRunner()
    for cmd in ("plan", "validate-spec", "import"):
        result = runner.invoke(app, [cmd, "--help"])
        assert result.exit_code == 0, f"{cmd} --help failed: {result.stdout}"
