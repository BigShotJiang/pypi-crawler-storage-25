"""Layer 4 (Shape) validator tests.

One class per check function; one entrypoint test class for run_shape_checks.
Boundary cases for the heuristic threshold are covered in
TestCheckCategoryLooksVertical.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from claw_forge.spec.parser import FeatureItem, ProjectSpec
from claw_forge.spec.validator import (
    CORE_CHAIN_DEPTH_THRESHOLD,
    CROSS_CUTTING_INDICATORS,
    DEFAULT_MIGRATION_TOUCHES_FILES,
    MIGRATION_INDICATORS,
    VERTICAL_INDICATORS,
    VERTICAL_MIN_BULLETS,
    VERTICAL_RATIO_THRESHOLD,
    IssueSeverity,
    _slugify_plugin_name,
)


class TestSlugifyPluginName:
    """Convert category names to plugin slugs — used by /fix-spec auto-fix
    recipes and the Gap 6 nudge message."""

    def test_simple_lowercase(self) -> None:
        assert _slugify_plugin_name("Authentication") == "authentication"

    def test_strips_non_alphanumerics(self) -> None:
        assert _slugify_plugin_name("User Management!") == "user-management"

    def test_collapses_whitespace_to_single_dash(self) -> None:
        assert _slugify_plugin_name("Order   Processing") == "order-processing"

    def test_strips_leading_trailing_dashes(self) -> None:
        assert _slugify_plugin_name("--Billing--") == "billing"

    def test_empty_string_returns_empty(self) -> None:
        assert _slugify_plugin_name("") == ""

    def test_only_specials_returns_empty(self) -> None:
        assert _slugify_plugin_name("!!!") == ""


class TestModuleConstants:
    """Module-level vocabulary and thresholds are public and importable."""

    def test_vertical_indicators_is_frozenset(self) -> None:
        assert isinstance(VERTICAL_INDICATORS, frozenset)
        assert "user can" in VERTICAL_INDICATORS

    def test_cross_cutting_indicators_is_frozenset(self) -> None:
        assert isinstance(CROSS_CUTTING_INDICATORS, frozenset)
        assert "middleware" in CROSS_CUTTING_INDICATORS

    def test_thresholds_are_numeric(self) -> None:
        assert 0.0 <= VERTICAL_RATIO_THRESHOLD <= 1.0
        assert VERTICAL_MIN_BULLETS >= 1
        assert CORE_CHAIN_DEPTH_THRESHOLD >= 2


class TestCheckPluginShapeComplete:
    """Gap 1 — shape='plugin' must have plugin= or non-empty touches_files.
    Always ERROR (invariant: silent disable of file-claim locking)."""

    def _feat(self, **overrides: Any) -> FeatureItem:
        defaults: dict[str, Any] = {
            "category": "Auth",
            "name": "register",
            "description": "User can register with email and password",
            "shape": "plugin",
            "plugin": None,
            "touches_files": [],
        }
        defaults.update(overrides)
        return FeatureItem(**defaults)

    def test_plugin_with_plugin_attr_passes(self) -> None:
        from claw_forge.spec.validator import check_plugin_shape_complete

        feat = self._feat(plugin="auth", touches_files=["src/plugins/auth/**"])
        assert check_plugin_shape_complete(feat, strict=False) is None

    def test_plugin_with_explicit_touches_passes(self) -> None:
        from claw_forge.spec.validator import check_plugin_shape_complete

        feat = self._feat(plugin=None, touches_files=["src/auth/auth.py"])
        assert check_plugin_shape_complete(feat, strict=False) is None

    def test_plugin_missing_both_fails(self) -> None:
        from claw_forge.spec.validator import check_plugin_shape_complete

        feat = self._feat(plugin=None, touches_files=[])
        issue = check_plugin_shape_complete(feat, strict=False)
        assert issue is not None
        assert issue.severity == IssueSeverity.ERROR
        assert issue.layer == 4
        assert "plugin=" in issue.message or "touches_files" in issue.message

    def test_plugin_missing_both_strict_still_error(self) -> None:
        """Strict flag does not affect Gap 1 — already always ERROR."""
        from claw_forge.spec.validator import check_plugin_shape_complete

        feat = self._feat(plugin=None, touches_files=[])
        issue = check_plugin_shape_complete(feat, strict=True)
        assert issue is not None
        assert issue.severity == IssueSeverity.ERROR

    def test_core_shape_skipped(self) -> None:
        """Gap 1 only applies to shape='plugin'; core/None untouched."""
        from claw_forge.spec.validator import check_plugin_shape_complete

        feat = self._feat(shape="core", touches_files=["src/middleware.py"])
        assert check_plugin_shape_complete(feat, strict=False) is None

    def test_unannotated_shape_skipped(self) -> None:
        from claw_forge.spec.validator import check_plugin_shape_complete

        feat = self._feat(shape=None, plugin=None, touches_files=[])
        assert check_plugin_shape_complete(feat, strict=False) is None

    def test_issue_includes_bullet_text(self) -> None:
        from claw_forge.spec.validator import check_plugin_shape_complete

        feat = self._feat(plugin=None, touches_files=[])
        issue = check_plugin_shape_complete(feat, strict=False)
        assert issue is not None
        assert issue.bullet == "User can register with email and password"

    def test_issue_suggestion_names_category_slug(self) -> None:
        from claw_forge.spec.validator import check_plugin_shape_complete

        feat = self._feat(category="User Management", plugin=None, touches_files=[])
        issue = check_plugin_shape_complete(feat, strict=False)
        assert issue is not None
        assert "user-management" in issue.suggestion


class TestCheckMigrationShapeCandidate:
    """Gap 8 — feature description suggests migration / DB-schema work but
    isn't shape='core'.  **ERROR by default** (v0.8.23+); WARNING when
    ``allow_soft=True`` (CLI: ``--allow-soft-migration-shape``).

    Migration-touching features mutate alembic's revision tree (a global
    shared resource).  Declaring them shape='core' causes the dispatcher
    to single-flight them, preventing parallel-revision collisions —
    the upstream cause of the floorplan failure documented in
    ``docs/superpowers/specs/2026-05-10-autonomous-merge-recovery.md``."""

    def _feat(self, **overrides: Any) -> FeatureItem:
        defaults: dict[str, Any] = {
            "category": "Schema",
            "name": "tickets-table",
            "description": "Add a migration creating the app.tickets table",
            "shape": None,
            "plugin": None,
            "touches_files": [],
        }
        defaults.update(overrides)
        return FeatureItem(**defaults)

    def test_migration_keyword_unannotated_errors_by_default(self) -> None:
        """v0.8.23+: Gap 8 defaults to ERROR.  Migration-shape misclassification
        is precise enough to gate planning at parse time, eliminating the
        alembic-collision failure class."""
        from claw_forge.spec.validator import check_migration_shape_candidate

        feat = self._feat(description="Add a migration creating app.tickets")
        issue = check_migration_shape_candidate(feat, strict=False)
        assert issue is not None
        assert issue.severity == IssueSeverity.ERROR
        assert issue.layer == 4

    def test_allow_soft_keeps_warning_severity(self) -> None:
        """``--allow-soft-migration-shape`` (config:
        ``validation.allow_soft_migration_shape: true``) preserves the
        pre-v0.8.23 WARNING behaviour for migration on-ramp on existing
        specs that haven't been shape-annotated yet."""
        from claw_forge.spec.validator import check_migration_shape_candidate

        feat = self._feat(description="Add a migration creating app.tickets")
        issue = check_migration_shape_candidate(
            feat, strict=False, allow_soft=True,
        )
        assert issue is not None
        assert issue.severity == IssueSeverity.WARNING

    def test_alembic_keyword_unannotated_warns(self) -> None:
        from claw_forge.spec.validator import check_migration_shape_candidate

        feat = self._feat(description="Wire up alembic for the new schema")
        issue = check_migration_shape_candidate(feat, strict=False)
        assert issue is not None

    def test_create_table_combo_warns(self) -> None:
        from claw_forge.spec.validator import check_migration_shape_candidate

        feat = self._feat(description="Create table for partner consultants")
        issue = check_migration_shape_candidate(feat, strict=False)
        assert issue is not None

    def test_alter_table_combo_warns(self) -> None:
        from claw_forge.spec.validator import check_migration_shape_candidate

        feat = self._feat(description="Alter table app.purchases to add sku check")
        issue = check_migration_shape_candidate(feat, strict=False)
        assert issue is not None

    def test_add_column_combo_warns(self) -> None:
        from claw_forge.spec.validator import check_migration_shape_candidate

        feat = self._feat(description="Add column status to app.tickets")
        issue = check_migration_shape_candidate(feat, strict=False)
        assert issue is not None

    def test_no_migration_vocabulary_passes(self) -> None:
        from claw_forge.spec.validator import check_migration_shape_candidate

        feat = self._feat(description="User can register with email and password")
        assert check_migration_shape_candidate(feat, strict=False) is None

    def test_table_alone_does_not_trigger(self) -> None:
        """``table`` alone is too broad (HTML tables, lookup tables).
        Must co-occur with create/alter/drop verb to count."""
        from claw_forge.spec.validator import check_migration_shape_candidate

        feat = self._feat(description="UI displays a table of recent purchases")
        assert check_migration_shape_candidate(feat, strict=False) is None

    def test_core_shape_passes(self) -> None:
        """Already correctly annotated — no warning."""
        from claw_forge.spec.validator import check_migration_shape_candidate

        feat = self._feat(
            description="Add a migration creating app.tickets",
            shape="core",
            touches_files=["migrations/versions/0011_tickets.py"],
        )
        assert check_migration_shape_candidate(feat, strict=False) is None

    def test_plugin_shape_with_migration_keyword_warns(self) -> None:
        """shape='plugin' on migration work is wrong — still flagged."""
        from claw_forge.spec.validator import check_migration_shape_candidate

        feat = self._feat(
            description="Add a migration creating app.tickets",
            shape="plugin",
            plugin="tickets",
            touches_files=["src/plugins/tickets/**"],
        )
        issue = check_migration_shape_candidate(feat, strict=False)
        assert issue is not None

    def test_strict_promotes_to_error(self) -> None:
        from claw_forge.spec.validator import check_migration_shape_candidate

        feat = self._feat(description="Add a migration creating app.tickets")
        issue = check_migration_shape_candidate(feat, strict=True)
        assert issue is not None
        assert issue.severity == IssueSeverity.ERROR

    def test_case_insensitive_match(self) -> None:
        from claw_forge.spec.validator import check_migration_shape_candidate

        feat = self._feat(description="Wire up ALEMBIC for the new SCHEMA")
        issue = check_migration_shape_candidate(feat, strict=False)
        assert issue is not None

    def test_suggestion_recommends_default_touches_files(self) -> None:
        from claw_forge.spec.validator import check_migration_shape_candidate

        feat = self._feat(description="Add a migration creating app.tickets")
        issue = check_migration_shape_candidate(feat, strict=False)
        assert issue is not None
        assert 'shape="core"' in issue.suggestion
        assert DEFAULT_MIGRATION_TOUCHES_FILES in issue.suggestion

    def test_indicators_module_constant_is_frozenset(self) -> None:
        assert isinstance(MIGRATION_INDICATORS, frozenset)
        # sanity: includes the high-signal terms
        assert "migration" in MIGRATION_INDICATORS
        assert "alembic" in MIGRATION_INDICATORS


class TestCheckTouchesOverlap:
    """Gap 3 — core feature touches_files glob overlaps a plugin's directory.
    Conservative algorithm: false-negatives over false-positives.
    WARNING by default; ERROR in strict mode."""

    def _spec(self, features: list[FeatureItem]) -> ProjectSpec:
        from claw_forge.spec.parser import TechStack

        return ProjectSpec(
            project_name="t",
            overview="o",
            tech_stack=TechStack(),
            features=features,
            implementation_phases=[],
            success_criteria=[],
            design_system={},
            api_endpoints={},
            database_tables={},
            raw_xml="",
        )

    def _plugin(self, name: str) -> FeatureItem:
        return FeatureItem(
            category="Cat",
            name=f"{name}-feat",
            description=f"User can do {name}",
            shape="plugin",
            plugin=name,
            touches_files=[f"src/plugins/{name}/**"],
        )

    def _core(self, *globs: str) -> FeatureItem:
        return FeatureItem(
            category="Core",
            name="core-feat",
            description="System enforces JWT on every endpoint",
            shape="core",
            touches_files=list(globs),
        )

    def test_no_overlap_passes(self) -> None:
        from claw_forge.spec.validator import check_touches_overlap

        spec = self._spec([
            self._plugin("auth"),
            self._core("src/core/middleware/jwt.py"),
        ])
        assert check_touches_overlap(spec, strict=False) == []

    def test_sloppy_core_glob_overlaps_plugin(self) -> None:
        """src/** matches every plugin directory — flagged."""
        from claw_forge.spec.validator import check_touches_overlap

        spec = self._spec([
            self._plugin("auth"),
            self._core("src/**"),
        ])
        issues = check_touches_overlap(spec, strict=False)
        assert len(issues) == 1
        assert issues[0].severity == IssueSeverity.WARNING
        assert issues[0].layer == 4
        assert "src/plugins/auth/" in issues[0].message

    def test_strict_promotes_to_error(self) -> None:
        from claw_forge.spec.validator import check_touches_overlap

        spec = self._spec([
            self._plugin("auth"),
            self._core("src/**"),
        ])
        issues = check_touches_overlap(spec, strict=True)
        assert len(issues) == 1
        assert issues[0].severity == IssueSeverity.ERROR

    def test_explicit_specific_path_in_plugin_dir_overlaps(self) -> None:
        """A core glob that explicitly names a path inside a plugin dir
        is still an overlap (the explicit-override escape hatch is a
        plugin-side concept; core specifying plugin paths is the smell)."""
        from claw_forge.spec.validator import check_touches_overlap

        spec = self._spec([
            self._plugin("billing"),
            self._core("src/plugins/billing/auth.py"),
        ])
        issues = check_touches_overlap(spec, strict=False)
        assert len(issues) == 1

    def test_multiple_overlaps_emit_one_per_pair(self) -> None:
        from claw_forge.spec.validator import check_touches_overlap

        spec = self._spec([
            self._plugin("auth"),
            self._plugin("billing"),
            self._core("src/**"),
        ])
        issues = check_touches_overlap(spec, strict=False)
        assert len(issues) == 2

    def test_plugin_with_no_plugin_attr_skipped(self) -> None:
        """Plugin features without plugin= can't have a derivable directory;
        skip — Gap 1 will have already flagged them."""
        from claw_forge.spec.validator import check_touches_overlap

        feat = FeatureItem(
            category="Auth", name="x", description="y",
            shape="plugin", plugin=None, touches_files=["src/somewhere/x.py"],
        )
        spec = self._spec([feat, self._core("src/**")])
        assert check_touches_overlap(spec, strict=False) == []

    def test_legacy_unshaped_features_ignored(self) -> None:
        """No shape annotations → no overlap analysis."""
        from claw_forge.spec.validator import check_touches_overlap

        feats = [
            FeatureItem(category="x", name="a", description="a", touches_files=["src/**"]),
            FeatureItem(
                category="x", name="b", description="b",
                touches_files=["src/plugins/auth/**"],
            ),
        ]
        assert check_touches_overlap(self._spec(feats), strict=False) == []


class TestCheckCoreChainDepth:
    """Gap 7 — long core-on-core depends_on chain (depth ≥
    CORE_CHAIN_DEPTH_THRESHOLD). Always WARNING — architectural smell,
    not invariant. Strict flag does not promote."""

    def _core(self, idx: int, deps: list[int] | None = None) -> FeatureItem:
        return FeatureItem(
            category="Core",
            name=f"core-{idx}",
            description=f"System enforces invariant {idx}",
            shape="core",
            touches_files=[f"src/core/inv_{idx}.py"],
            index=idx,
            depends_on_indices=deps or [],
        )

    def _plugin(self, idx: int, name: str, deps: list[int] | None = None) -> FeatureItem:
        return FeatureItem(
            category="Auth",
            name=f"plug-{idx}",
            description=f"User can do {name}",
            shape="plugin",
            plugin=name,
            touches_files=[f"src/plugins/{name}/**"],
            index=idx,
            depends_on_indices=deps or [],
        )

    def _spec(self, features: list[FeatureItem]) -> ProjectSpec:
        from claw_forge.spec.parser import TechStack

        return ProjectSpec(
            project_name="t", overview="o", tech_stack=TechStack(),
            features=features, implementation_phases=[], success_criteria=[],
            design_system={}, api_endpoints={}, database_tables={}, raw_xml="",
        )

    def test_short_core_chain_passes(self) -> None:
        from claw_forge.spec.validator import check_core_chain_depth

        # 1 → 2 → 3 (length 3, threshold 4)
        spec = self._spec([
            self._core(1),
            self._core(2, deps=[1]),
            self._core(3, deps=[2]),
        ])
        assert check_core_chain_depth(spec) == []

    def test_long_core_chain_flagged(self) -> None:
        from claw_forge.spec.validator import check_core_chain_depth

        # 1 → 2 → 3 → 4 → 5 (length 5)
        spec = self._spec([
            self._core(1),
            self._core(2, deps=[1]),
            self._core(3, deps=[2]),
            self._core(4, deps=[3]),
            self._core(5, deps=[4]),
        ])
        issues = check_core_chain_depth(spec)
        assert len(issues) == 1
        assert issues[0].severity == IssueSeverity.WARNING
        assert issues[0].layer == 4
        assert "5" in issues[0].message  # chain length

    def test_plugin_break_resets_chain(self) -> None:
        """A plugin in the dependency path breaks the all-core chain."""
        from claw_forge.spec.validator import check_core_chain_depth

        # core1 → plugin2 → core3 → core4 → core5 — longest core run is 3
        spec = self._spec([
            self._core(1),
            self._plugin(2, "auth", deps=[1]),
            self._core(3, deps=[2]),
            self._core(4, deps=[3]),
            self._core(5, deps=[4]),
        ])
        assert check_core_chain_depth(spec) == []

    def test_diamond_pattern_uses_longest_path(self) -> None:
        from claw_forge.spec.validator import check_core_chain_depth

        # 1 → 2 → 4 → 5
        # 1 → 3 → 4 → 5  (4 has deps [2, 3]; longest path 4)
        spec = self._spec([
            self._core(1),
            self._core(2, deps=[1]),
            self._core(3, deps=[1]),
            self._core(4, deps=[2, 3]),
            self._core(5, deps=[4]),  # length: 1→2→4→5 or 1→3→4→5 = 4
        ])
        issues = check_core_chain_depth(spec)
        assert len(issues) == 1

    def test_strict_does_not_promote(self) -> None:
        """Gap 7 is always WARNING — architectural smell."""
        from claw_forge.spec.validator import check_core_chain_depth

        spec = self._spec([
            self._core(1),
            self._core(2, deps=[1]),
            self._core(3, deps=[2]),
            self._core(4, deps=[3]),
            self._core(5, deps=[4]),
        ])
        issues = check_core_chain_depth(spec)
        assert all(i.severity == IssueSeverity.WARNING for i in issues)

    def test_no_index_features_ignored(self) -> None:
        """Legacy bullets without index= can't participate in chain analysis."""
        from claw_forge.spec.validator import check_core_chain_depth

        feats = [
            FeatureItem(
                category="Core", name=f"x{i}", description="y",
                shape="core", touches_files=["src/x.py"],
                index=None,
            )
            for i in range(5)
        ]
        assert check_core_chain_depth(self._spec(feats)) == []


class TestCheckCategoryLooksVertical:
    """Gap 6 — vertical-looking category with no shape declared.
    Operates on the unannotated subset only. WARNING / ERROR strict."""

    def _vert(self, n: int) -> list[FeatureItem]:
        """n unannotated bullets all matching VERTICAL_INDICATORS."""
        return [
            FeatureItem(
                category="Auth", name=f"v{i}",
                description=f"User can perform action {i}",
            )
            for i in range(n)
        ]

    def test_below_min_bullets_skipped(self) -> None:
        """|U| < VERTICAL_MIN_BULLETS → skip."""
        from claw_forge.spec.validator import check_category_looks_vertical

        feats = self._vert(VERTICAL_MIN_BULLETS - 1)
        assert check_category_looks_vertical("Auth", feats, strict=False) is None

    def test_min_bullets_all_vertical_flagged(self) -> None:
        from claw_forge.spec.validator import check_category_looks_vertical

        feats = self._vert(VERTICAL_MIN_BULLETS)
        issue = check_category_looks_vertical("Auth", feats, strict=False)
        assert issue is not None
        assert issue.severity == IssueSeverity.WARNING
        assert issue.layer == 4
        assert "auth" in issue.suggestion.lower()  # slug name appears

    def test_strict_promotes_to_error(self) -> None:
        from claw_forge.spec.validator import check_category_looks_vertical

        feats = self._vert(VERTICAL_MIN_BULLETS)
        issue = check_category_looks_vertical("Auth", feats, strict=True)
        assert issue is not None
        assert issue.severity == IssueSeverity.ERROR

    def test_at_threshold_flagged(self) -> None:
        """At exactly VERTICAL_RATIO_THRESHOLD → flag (≥ comparison)."""
        from claw_forge.spec.validator import check_category_looks_vertical

        # 5 unannotated: 3 vertical (+3), 2 neither (0) → score 3/5 = 0.6 → flag
        feats = [
            FeatureItem(category="Auth", name=f"v{i}",
                        description=f"User can do action {i}")
            for i in range(3)
        ] + [
            FeatureItem(category="Auth", name=f"n{i}",
                        description=f"Something happens {i}")
            for i in range(2)
        ]
        issue = check_category_looks_vertical("Auth", feats, strict=False)
        assert issue is not None

    def test_below_threshold_not_flagged(self) -> None:
        """Below VERTICAL_RATIO_THRESHOLD → skip."""
        from claw_forge.spec.validator import check_category_looks_vertical

        # 5 unannotated, 2 vertical, 3 neither → 2/5 = 0.4 (< 0.6)
        feats = [
            FeatureItem(category="Auth", name=f"v{i}",
                        description=f"User can do action {i}")
            for i in range(2)
        ] + [
            FeatureItem(category="Auth", name=f"n{i}",
                        description=f"Something happens {i}")
            for i in range(3)
        ]
        assert check_category_looks_vertical("Auth", feats, strict=False) is None

    def test_cross_cutting_negates_vertical(self) -> None:
        """Cross-cutting indicators score -1 and pull the ratio down."""
        from claw_forge.spec.validator import check_category_looks_vertical

        feats = [
            FeatureItem(category="Auth", name="v",
                        description="User can register"),                  # +1
            FeatureItem(category="Auth", name="x",
                        description="System enforces middleware globally"),  # -1
            FeatureItem(category="Auth", name="y",
                        description="System tracks metrics"),              # -1
        ]
        # score = 1 - 1 - 1 = -1; ratio = -1/3 ≈ -0.33 → not flagged
        assert check_category_looks_vertical("Auth", feats, strict=False) is None

    def test_already_annotated_features_excluded_from_score(self) -> None:
        """Score is computed only on the unannotated subset."""
        from claw_forge.spec.validator import check_category_looks_vertical

        feats = [
            # 2 already-annotated (excluded from analysis)
            FeatureItem(category="Auth", name="a1", description="x",
                        shape="plugin", plugin="auth"),
            FeatureItem(category="Auth", name="a2", description="x",
                        shape="plugin", plugin="auth"),
            # 3 unannotated, all vertical
            FeatureItem(category="Auth", name="u1",
                        description="User can do thing"),
            FeatureItem(category="Auth", name="u2",
                        description="User can do other thing"),
            FeatureItem(category="Auth", name="u3",
                        description="User can do third thing"),
        ]
        issue = check_category_looks_vertical("Auth", feats, strict=False)
        assert issue is not None  # flagged because U is 3 vertical / 3 = 1.0

    def test_all_annotated_skipped(self) -> None:
        """|U| == 0 → skip."""
        from claw_forge.spec.validator import check_category_looks_vertical

        feats = [
            FeatureItem(category="Auth", name=f"a{i}", description="x",
                        shape="plugin", plugin="auth")
            for i in range(VERTICAL_MIN_BULLETS)
        ]
        assert check_category_looks_vertical("Auth", feats, strict=False) is None


class TestCheckPluginDirExists:
    """Gap 5 — plugin='X' references nonexistent directory.
    Brownfield-only: skip if project_root has no src/plugins/.
    WARNING / ERROR strict."""

    def _feat(self, plugin: str) -> FeatureItem:
        return FeatureItem(
            category="Auth", name="x",
            description="User can register",
            shape="plugin", plugin=plugin,
            touches_files=[f"src/plugins/{plugin}/**"],
        )

    def test_greenfield_skipped(self, tmp_path: Path) -> None:
        """No src/plugins/ → skip silently."""
        from claw_forge.spec.validator import check_plugin_dir_exists

        feat = self._feat("auth")
        result = check_plugin_dir_exists(
            feat, project_root=tmp_path, strict=False, brownfield=False,
        )
        assert result is None

    def test_brownfield_present_dir_passes(self, tmp_path: Path) -> None:
        from claw_forge.spec.validator import check_plugin_dir_exists

        (tmp_path / "src" / "plugins" / "auth").mkdir(parents=True)
        feat = self._feat("auth")
        result = check_plugin_dir_exists(
            feat, project_root=tmp_path, strict=False, brownfield=True,
        )
        assert result is None

    def test_brownfield_missing_dir_warns(self, tmp_path: Path) -> None:
        from claw_forge.spec.validator import check_plugin_dir_exists

        (tmp_path / "src" / "plugins" / "auth").mkdir(parents=True)
        # Other plugins exist but not "profile"
        feat = self._feat("profile")
        issue = check_plugin_dir_exists(
            feat, project_root=tmp_path, strict=False, brownfield=True,
        )
        assert issue is not None
        assert issue.severity == IssueSeverity.WARNING
        assert issue.layer == 4
        assert "profile" in issue.message

    def test_brownfield_missing_dir_strict_errors(self, tmp_path: Path) -> None:
        from claw_forge.spec.validator import check_plugin_dir_exists

        (tmp_path / "src" / "plugins" / "auth").mkdir(parents=True)
        feat = self._feat("profile")
        issue = check_plugin_dir_exists(
            feat, project_root=tmp_path, strict=True, brownfield=True,
        )
        assert issue is not None
        assert issue.severity == IssueSeverity.ERROR

    def test_non_plugin_shape_skipped(self, tmp_path: Path) -> None:
        from claw_forge.spec.validator import check_plugin_dir_exists

        (tmp_path / "src" / "plugins" / "auth").mkdir(parents=True)
        feat = FeatureItem(
            category="Core", name="x", description="y",
            shape="core", touches_files=["src/middleware.py"],
        )
        assert check_plugin_dir_exists(
            feat, project_root=tmp_path, strict=False, brownfield=True,
        ) is None

    def test_plugin_without_plugin_attr_skipped(self, tmp_path: Path) -> None:
        """Gap 1 already flags this; Gap 5 skips."""
        from claw_forge.spec.validator import check_plugin_dir_exists

        (tmp_path / "src" / "plugins" / "auth").mkdir(parents=True)
        feat = FeatureItem(
            category="Auth", name="x", description="y",
            shape="plugin", plugin=None, touches_files=["src/some/path.py"],
        )
        assert check_plugin_dir_exists(
            feat, project_root=tmp_path, strict=False, brownfield=True,
        ) is None


class TestRunShapeChecks:
    """run_shape_checks composes the five check functions and returns
    a ValidationReport."""

    def _spec(self, features: list[FeatureItem]) -> ProjectSpec:
        from claw_forge.spec.parser import TechStack

        return ProjectSpec(
            project_name="t", overview="o", tech_stack=TechStack(),
            features=features, implementation_phases=[], success_criteria=[],
            design_system={}, api_endpoints={}, database_tables={}, raw_xml="",
        )

    def test_clean_spec_zero_issues(self) -> None:
        from claw_forge.spec.validator import run_shape_checks

        spec = self._spec([
            FeatureItem(
                category="Auth", name="register",
                description="User can register",
                shape="plugin", plugin="auth",
                touches_files=["src/plugins/auth/**"],
            ),
        ])
        report = run_shape_checks(spec, project_root=None, strict=False)
        assert report.issues == []

    def test_collects_gap_1_error(self) -> None:
        from claw_forge.spec.validator import run_shape_checks

        spec = self._spec([
            FeatureItem(
                category="Auth", name="register",
                description="User can register",
                shape="plugin",  # missing plugin= and touches_files=
            ),
        ])
        report = run_shape_checks(spec, project_root=None, strict=False)
        assert any(
            i.severity == IssueSeverity.ERROR and i.layer == 4
            for i in report.issues
        )

    def test_filesystem_check_skipped_without_project_root(
        self, tmp_path: Path
    ) -> None:
        """No project_root → check_plugin_dir_exists not run."""
        from claw_forge.spec.validator import run_shape_checks

        spec = self._spec([
            FeatureItem(
                category="Auth", name="x", description="User can do x",
                shape="plugin", plugin="ghost",
                touches_files=["src/plugins/ghost/**"],
            ),
        ])
        report = run_shape_checks(spec, project_root=None, strict=False)
        assert not any(
            "directory" in i.message.lower() for i in report.issues
        )

    def test_filesystem_check_runs_with_brownfield_root(
        self, tmp_path: Path
    ) -> None:
        from claw_forge.spec.validator import run_shape_checks

        # Brownfield: src/plugins/ exists with some plugin
        (tmp_path / "src" / "plugins" / "real").mkdir(parents=True)
        spec = self._spec([
            FeatureItem(
                category="Auth", name="x", description="User can do x",
                shape="plugin", plugin="ghost",
                touches_files=["src/plugins/ghost/**"],
            ),
        ])
        report = run_shape_checks(
            spec, project_root=tmp_path, strict=False,
        )
        assert any(
            "directory" in i.message.lower() and i.layer == 4
            for i in report.issues
        )

    def test_strict_promotes_warnings_to_errors(self, tmp_path: Path) -> None:
        from claw_forge.spec.validator import run_shape_checks

        (tmp_path / "src" / "plugins" / "real").mkdir(parents=True)
        spec = self._spec([
            FeatureItem(
                category="Auth", name="x", description="User can do x",
                shape="plugin", plugin="ghost",
                touches_files=["src/plugins/ghost/**"],
            ),
        ])
        report_default = run_shape_checks(
            spec, project_root=tmp_path, strict=False,
        )
        report_strict = run_shape_checks(
            spec, project_root=tmp_path, strict=True,
        )
        default_severities = {i.severity for i in report_default.issues}
        strict_severities = {i.severity for i in report_strict.issues}
        assert IssueSeverity.WARNING in default_severities
        assert IssueSeverity.ERROR in strict_severities
