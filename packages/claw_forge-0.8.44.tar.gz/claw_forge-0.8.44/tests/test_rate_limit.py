"""Tests for claw_forge.agent.rate_limit."""
from __future__ import annotations

from claw_forge.agent.rate_limit import (
    calculate_error_backoff,
    calculate_rate_limit_backoff,
    clamp_retry_delay,
    is_rate_limit_error,
    is_retryable_provider_error,
    parse_retry_after,
)


class TestIsRateLimitError:
    def test_detects_rate_limit_phrase(self):
        assert is_rate_limit_error("You have hit the rate limit") is True

    def test_detects_too_many_requests(self):
        assert is_rate_limit_error("Too many requests, please slow down") is True

    def test_detects_429_status(self):
        assert is_rate_limit_error("HTTP 429 error received") is True

    def test_detects_quota_exceeded(self):
        assert is_rate_limit_error("quota exceeded for your account") is True

    def test_detects_capacity_exceeded(self):
        assert is_rate_limit_error("capacity exceeded on this endpoint") is True

    def test_detects_overloaded(self):
        assert is_rate_limit_error("The service is overloaded") is True

    def test_detects_529_status(self):
        assert is_rate_limit_error("Error 529: service unavailable") is True

    def test_case_insensitive(self):
        assert is_rate_limit_error("RATE LIMIT EXCEEDED") is True

    def test_non_rate_limit_error_returns_false(self):
        assert is_rate_limit_error("Invalid API key provided") is False

    def test_empty_string_returns_false(self):
        assert is_rate_limit_error("") is False

    def test_generic_server_error_returns_false(self):
        assert is_rate_limit_error("Internal server error 500") is False

    def test_ratelimit_no_space(self):
        assert is_rate_limit_error("ratelimit reached") is True


class TestParseRetryAfter:
    def test_parses_retry_after_with_colon(self):
        result = parse_retry_after("Retry-After: 30")
        assert result == 30

    def test_parses_retry_after_with_space(self):
        result = parse_retry_after("retry after 60 seconds")
        assert result == 60

    def test_parses_seconds_standalone(self):
        result = parse_retry_after("Please wait 45 seconds before retrying")
        assert result == 45

    def test_returns_none_when_no_number(self):
        result = parse_retry_after("rate limit hit, try again later")
        assert result is None

    def test_returns_none_for_empty_string(self):
        result = parse_retry_after("")
        assert result is None

    def test_prefers_retry_after_over_seconds(self):
        # "Retry-After: 30" should win over any "30 seconds" mention
        result = parse_retry_after("Retry-After: 30 — wait 30 seconds")
        assert result == 30


class TestClampRetryDelay:
    def test_clamps_below_minimum(self):
        assert clamp_retry_delay(1) == 5

    def test_clamps_above_maximum(self):
        assert clamp_retry_delay(9999) == 3600

    def test_within_range_unchanged(self):
        assert clamp_retry_delay(60) == 60

    def test_custom_bounds(self):
        assert clamp_retry_delay(100, min_s=10, max_s=200) == 100
        assert clamp_retry_delay(5, min_s=10, max_s=200) == 10
        assert clamp_retry_delay(500, min_s=10, max_s=200) == 200


class TestCalculateRateLimitBackoff:
    def test_attempt_0_is_base_plus_jitter(self):
        result = calculate_rate_limit_backoff(0, base=60.0, max_s=900.0)
        # 60 * 2^0 = 60, plus up to 10 jitter → between 60 and 70
        assert 60 <= result <= 70

    def test_attempt_1_doubles(self):
        result = calculate_rate_limit_backoff(1, base=60.0, max_s=900.0)
        # 60 * 2^1 = 120 + jitter → between 120 and 130
        assert 120 <= result <= 130

    def test_capped_at_max(self):
        result = calculate_rate_limit_backoff(10, base=60.0, max_s=900.0)
        assert result == 900

    def test_returns_int(self):
        result = calculate_rate_limit_backoff(0)
        assert isinstance(result, int)


class TestCalculateErrorBackoff:
    def test_attempt_0_returns_zero(self):
        assert calculate_error_backoff(0) == 0

    def test_attempt_1_returns_base(self):
        assert calculate_error_backoff(1, base=5.0) == 5

    def test_attempt_3(self):
        assert calculate_error_backoff(3, base=5.0) == 15

    def test_capped_at_max(self):
        assert calculate_error_backoff(1000, base=5.0, max_s=300.0) == 300

    def test_returns_int(self):
        result = calculate_error_backoff(2)
        assert isinstance(result, int)


class TestIsRetryableProviderError:
    """v0.8.24: broader pattern set used by the dispatcher's provider-
    rotation logic.  Catches rate-limits + 5xx + network failures —
    anything where rotating to a different provider might succeed —
    while leaving client-side errors (4xx other than 429, malformed
    input, agent runtime errors) classified as non-retryable."""

    # ── Should retry: rate-limits (existing behaviour, preserved) ──

    def test_rate_limit_retryable(self):
        assert is_retryable_provider_error("rate limit exceeded") is True

    def test_429_retryable(self):
        assert is_retryable_provider_error("HTTP 429: too many requests") is True

    def test_overloaded_retryable(self):
        assert is_retryable_provider_error("Service overloaded") is True

    # ── Should retry: 5xx server errors (NEW in v0.8.24) ──

    def test_500_retryable(self):
        assert is_retryable_provider_error("HTTP 500 internal server error") is True

    def test_502_bad_gateway_retryable(self):
        assert is_retryable_provider_error("502 Bad Gateway") is True

    def test_503_service_unavailable_retryable(self):
        assert is_retryable_provider_error("503 Service Unavailable") is True

    def test_504_gateway_timeout_retryable(self):
        assert is_retryable_provider_error("504 Gateway Timeout") is True

    def test_internal_server_error_text_retryable(self):
        """SDK / HTTPX wrap server errors with the phrase, not just the code."""
        assert is_retryable_provider_error(
            "An internal server error occurred",
        ) is True

    # ── Should retry: network failures (NEW in v0.8.24) ──

    def test_connection_refused_retryable(self):
        assert is_retryable_provider_error(
            "Connection refused: api.example.com:443",
        ) is True

    def test_connection_reset_retryable(self):
        assert is_retryable_provider_error("Connection reset by peer") is True

    def test_timeout_retryable(self):
        assert is_retryable_provider_error("Request timeout after 60s") is True

    def test_timed_out_retryable(self):
        assert is_retryable_provider_error("Operation timed out") is True

    def test_dns_resolution_retryable(self):
        assert is_retryable_provider_error(
            "Name or service not known",
        ) is True

    def test_network_unreachable_retryable(self):
        assert is_retryable_provider_error("Network unreachable") is True

    # ── Should retry: generic upstream/provider wrappers ──

    def test_upstream_error_retryable(self):
        assert is_retryable_provider_error("Upstream error from provider") is True

    def test_provider_error_retryable(self):
        assert is_retryable_provider_error("Provider error: backend down") is True

    # ── Should NOT retry: client-side errors ──

    def test_400_bad_request_not_retryable(self):
        """4xx (other than 429) is a client-side problem; rotating won't
        help, all providers will reject the same malformed request."""
        assert is_retryable_provider_error(
            "HTTP 400 Bad Request: malformed input",
        ) is False

    def test_404_not_found_not_retryable(self):
        assert is_retryable_provider_error(
            "HTTP 404: model not found",
        ) is False

    def test_validation_error_not_retryable(self):
        assert is_retryable_provider_error(
            "ValidationError: tool input is malformed",
        ) is False

    def test_agent_internal_error_not_retryable(self):
        """Errors from the agent's own runtime (loop detection,
        max-turns reached) won't be fixed by rotating providers."""
        assert is_retryable_provider_error(
            "Agent loop detected after 5 identical turns",
        ) is False

    def test_sandbox_denial_not_retryable(self):
        """Layer 4 sandbox denials are correct behaviour, not provider
        problems.  Don't rotate."""
        assert is_retryable_provider_error(
            "[Sandbox] DENIED Bash — outside project dir",
        ) is False

    def test_empty_string_not_retryable(self):
        """Defensive: empty error text → no rotation (no signal to
        act on)."""
        assert is_retryable_provider_error("") is False

    # ── Compatibility: rate-limit case is a strict subset ──

    def test_rate_limit_subset_of_retryable(self):
        """Every error ``is_rate_limit_error`` matches MUST also match
        ``is_retryable_provider_error`` — the broader function is a
        superset, never narrower."""
        for sample in [
            "rate limit exceeded",
            "HTTP 429",
            "too many requests",
            "quota exceeded",
            "service overloaded",
            "529 capacity exceeded",
        ]:
            assert is_rate_limit_error(sample) is True
            assert is_retryable_provider_error(sample) is True, (
                f"is_retryable_provider_error must be a superset; "
                f"missed sample: {sample!r}"
            )


class TestAuthCredentialErrorsRotation:
    """v0.8.27: auth-credential errors are per-provider configuration
    problems where the request is fine but THIS provider can't honour
    it.  Another provider in the pool may have working creds, so the
    dispatcher should rotate.

    Pre-v0.8.27 the classifier explicitly excluded 401 / unauthorized
    on the rationale "rotating won't help, fail fast and let the
    operator fix the credential" — but with multi-provider pools
    that's exactly backwards: bad creds on one provider don't say
    anything about whether the OpenAI-compatible fallback works.
    Reversed in v0.8.27 after the fengshui ``oauth_org_not_allowed``
    incident.  See ``memory/project_provider_rotation_rules.md``.
    """

    def test_oauth_org_not_allowed_retryable(self):
        """The exact symptom from fengshui that motivated this fix —
        ``claude login`` works but the authenticated org isn't on the
        allow-list for that token."""
        assert is_retryable_provider_error("oauth_org_not_allowed") is True

    def test_oauth_token_invalid_retryable(self):
        """Expired or revoked OAuth token — re-running ``claude login``
        would fix it for that provider, but rotation gets the work done
        without operator intervention if another provider is healthy."""
        assert is_retryable_provider_error("oauth_token_invalid") is True

    def test_oauth_pattern_with_underscore_variant(self):
        """Match underscore vs space variants — providers emit either
        depending on the wrapper layer."""
        assert is_retryable_provider_error("oauth scope not allowed") is True

    def test_invalid_api_key_retryable(self):
        """Anthropic-style: ``invalid_api_key`` payload."""
        assert is_retryable_provider_error("invalid_api_key") is True

    def test_invalid_api_key_text_form_retryable(self):
        """Same error shaped as human-readable text instead of code."""
        assert is_retryable_provider_error("Invalid API Key") is True

    def test_authentication_error_retryable(self):
        assert is_retryable_provider_error("authentication_error") is True

    def test_authentication_failed_text_retryable(self):
        assert is_retryable_provider_error("Authentication failed") is True

    def test_401_now_retryable(self):
        """Reverses the v0.8.24 ``test_401_unauthorized_not_retryable``
        contract.  In API context 401 is almost always a credential
        issue, which is per-provider, so we rotate."""
        assert is_retryable_provider_error("HTTP 401 Unauthorized") is True

    def test_unauthorized_word_retryable(self):
        """The bare word ``unauthorized`` (no status code) — same
        underlying meaning, treated the same way."""
        assert is_retryable_provider_error("Request unauthorized") is True

    def test_dispatcher_wrapper_message_retryable(self):
        """Regression test for the exact RuntimeError text the
        dispatcher emits in ``cli.py`` when the agent returns an SDK
        error: ``f"Agent error: {_err} — check 'claude login' or
        verify API key in .env"``.  With ``_err='oauth_org_not_allowed'``
        the wrapped message must trigger rotation; pre-v0.8.27 it
        failed the task instead."""
        wrapped = (
            "Agent error: oauth_org_not_allowed — "
            "check `claude login` or verify API key in .env"
        )
        assert is_retryable_provider_error(wrapped) is True

    def test_403_forbidden_still_not_retryable(self):
        """403 stays excluded — it's commonly a content-moderation
        refusal (``"output blocked"`` / ``"prompt rejected"``), which
        IS request-level and would re-fail on every provider.  Don't
        promote it just because the pattern looks auth-adjacent."""
        assert is_retryable_provider_error("HTTP 403 Forbidden") is False

    def test_400_still_not_retryable(self):
        """Re-affirm the boundary: 400 / Bad Request stays fail-fast
        because the payload is broken."""
        assert is_retryable_provider_error(
            "HTTP 400 Bad Request: malformed input",
        ) is False
