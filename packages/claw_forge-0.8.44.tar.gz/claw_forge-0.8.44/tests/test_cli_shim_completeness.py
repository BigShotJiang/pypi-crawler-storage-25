"""Asserts cli.py back-compat shim covers every test-imported symbol.

If a future PR moves a helper but forgets to update cli.py's re-exports,
this test fails immediately rather than silently breaking downstream
test imports.

The 12 symbols listed below are imported from `claw_forge.cli` in test
files (originally 9 documented in the design; PR 7 added 3 more for
`_create_and_sync_worktree`, `_resolve_sdk_credentials`, `_try_claim_files`).
They MUST continue to resolve.
"""
from __future__ import annotations

_EXPECTED_SHIM_SYMBOLS = {
    "_DEFAULT_CONFIG_YAML",
    "_create_and_sync_worktree",
    "_load_config",
    "_load_env_file",
    "_resolve_latest_session",
    "_resolve_project_root",
    "_resolve_sdk_credentials",
    "_set_merged_after_merge",
    "_task_dict_to_node",
    "_try_claim_files",
    "_write_plan_to_db",
    "app",
}


def test_cli_exports_documented_back_compat_symbols() -> None:
    """All test-imported symbols must continue to resolve from claw_forge.cli."""
    from claw_forge import cli

    missing = {name for name in _EXPECTED_SHIM_SYMBOLS if not hasattr(cli, name)}
    assert not missing, f"missing shim symbols: {sorted(missing)}"


def test_app_is_typer_instance() -> None:
    """The main app object is a Typer instance."""
    import typer

    from claw_forge.cli import app

    assert isinstance(app, typer.Typer)


def test_shim_callables_are_actually_callable() -> None:
    """Every shimmed callable resolves to a callable, not None or a string."""
    from claw_forge import cli

    callables = _EXPECTED_SHIM_SYMBOLS - {"app", "_DEFAULT_CONFIG_YAML"}
    for name in callables:
        value = getattr(cli, name)
        assert callable(value), f"{name} is not callable: {type(value)}"


def test_default_config_yaml_is_string() -> None:
    """_DEFAULT_CONFIG_YAML resolves to a string constant with expected content."""
    from claw_forge.cli import _DEFAULT_CONFIG_YAML

    assert isinstance(_DEFAULT_CONFIG_YAML, str)
    assert "model_aliases" in _DEFAULT_CONFIG_YAML
