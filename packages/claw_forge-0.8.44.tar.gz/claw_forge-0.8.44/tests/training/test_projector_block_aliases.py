"""Pin: projector accepts both ``tool_use`` and ``tooluse`` block type strings.

The recorder serializes a block's ``type`` via two paths.  When the SDK
attaches an explicit ``type`` attribute (newer SDKs) we get the canonical
underscore form: ``tool_use`` / ``tool_result``.  When it doesn't, the
recorder falls back to ``cls.__name__.lower().replace("block", "")``,
which produces ``tooluse`` / ``toolresult`` (no underscore) for
``ToolUseBlock`` / ``ToolResultBlock``.

The OpenAI-tools / ShareGPT projectors only checked for ``tool_use`` and
``tool_result`` — every record exported from a session captured under
the no-``.type``-attribute SDK silently dropped its tool calls and
tool results.  An entire meridian session (8,539 ``agent_message``
events, 80 completed tasks) projected to **zero** ``tool_calls`` in
the JSONL output despite 150+ real tool invocations per task.

This file pins the contract: every projector that emits tool-use
semantics must accept BOTH variants of the type string.

Also pins the v0.8.38 ``--drop-error-turns`` filter (default-on) which
strips assistant turns that are just upstream rate-limit / API errors
— ``"API Error: Request rejected (429) ..."`` shaped messages that
the recorder faithfully captures but which should never reach the
training corpus.
"""

from __future__ import annotations

import json
from typing import Any


def _base_record() -> dict[str, Any]:
    """A minimal record skeleton — overridden ``raw_events`` per test."""
    return {
        "task_id": "t1",
        "session_id": "s1",
        "outcome": "success",
        "plugin": "coding",
        "category": "Test",
        "shape": None,
        "retry_count": 0,
        "metrics": {},
        "description": "demo task",
        "raw_events": [],
    }


def test_openai_tools_accepts_tooluse_no_underscore() -> None:
    """``type='tooluse'`` (from recorder fallback) must produce tool_calls."""
    from claw_forge.training.projectors import to_openai_tools

    rec = _base_record()
    rec["raw_events"] = [
        {
            "kind": "AssistantMessage",
            "content": [
                {"type": "text", "text": "I'll read the file."},
                {
                    "type": "tooluse",
                    "id": "call_1",
                    "name": "Read",
                    "input": {"file_path": "/tmp/x"},
                },
            ],
        },
    ]
    out = to_openai_tools(rec)
    asst = [m for m in out["messages"] if m["role"] == "assistant"]
    assert len(asst) == 1, "Expected exactly one assistant message"
    assert "tool_calls" in asst[0], (
        "Projector dropped the tool_use block because it had "
        "type='tooluse' instead of 'tool_use' — this is the bug "
        "that wiped tool calls from every projected record."
    )
    tc = asst[0]["tool_calls"]
    assert len(tc) == 1
    assert tc[0]["function"]["name"] == "Read"
    assert json.loads(tc[0]["function"]["arguments"]) == {"file_path": "/tmp/x"}


def test_openai_tools_accepts_tool_use_underscore() -> None:
    """The canonical underscore form must still work after the fix."""
    from claw_forge.training.projectors import to_openai_tools

    rec = _base_record()
    rec["raw_events"] = [
        {
            "kind": "AssistantMessage",
            "content": [
                {
                    "type": "tool_use",
                    "id": "call_1",
                    "name": "Read",
                    "input": {"file_path": "/tmp/x"},
                },
            ],
        },
    ]
    out = to_openai_tools(rec)
    asst = [m for m in out["messages"] if m["role"] == "assistant"]
    assert len(asst) == 1
    assert asst[0]["tool_calls"][0]["function"]["name"] == "Read"


def test_openai_tools_accepts_toolresult_no_underscore() -> None:
    """``type='toolresult'`` must produce tool-role messages."""
    from claw_forge.training.projectors import to_openai_tools

    rec = _base_record()
    rec["raw_events"] = [
        {
            "kind": "UserMessage",
            "content": [
                {
                    "type": "toolresult",
                    "tool_use_id": "call_1",
                    "content": "file contents",
                },
            ],
        },
    ]
    out = to_openai_tools(rec)
    tool_msgs = [m for m in out["messages"] if m["role"] == "tool"]
    assert len(tool_msgs) == 1, (
        "Projector dropped the tool_result block because it had "
        "type='toolresult' instead of 'tool_result'."
    )
    assert tool_msgs[0]["tool_call_id"] == "call_1"
    assert tool_msgs[0]["content"] == "file contents"


def test_sharegpt_accepts_toolresult_no_underscore() -> None:
    """ShareGPT projector has its own block-type check; verify it covers both."""
    from claw_forge.training.projectors import to_sharegpt

    rec = _base_record()
    rec["raw_events"] = [
        {
            "kind": "UserMessage",
            "content": [
                {"type": "toolresult", "tool_use_id": "x", "content": "ok"},
            ],
        },
    ]
    out = to_sharegpt(rec)
    tool_convos = [c for c in out["conversations"] if c["from"] == "tool"]
    assert len(tool_convos) == 1
    assert tool_convos[0]["value"] == "ok"


def test_sharegpt_flattens_tooluse_no_underscore() -> None:
    """The flatten helper must also accept the no-underscore alias."""
    from claw_forge.training.projectors import to_sharegpt

    rec = _base_record()
    rec["raw_events"] = [
        {
            "kind": "AssistantMessage",
            "content": [
                {"type": "tooluse", "id": "x", "name": "Read",
                 "input": {"file_path": "/tmp/y"}},
            ],
        },
    ]
    out = to_sharegpt(rec)
    gpt_convos = [c for c in out["conversations"] if c["from"] == "gpt"]
    assert len(gpt_convos) == 1
    # ShareGPT flattens tool calls into a <tool_call> tag — the bug would
    # have produced an empty string (no tool call rendered at all).
    assert "tool_call" in gpt_convos[0]["value"]
    assert "Read" in gpt_convos[0]["value"]


# ── API-error filter (v0.8.38) ──────────────────────────────────────────────


def test_openai_tools_drops_api_error_turns_by_default() -> None:
    """An assistant turn whose only text is an upstream rate-limit / API
    error is poison for training: the model would learn to emit fake
    rate-limit responses.  Default behaviour drops such turns.
    """
    from claw_forge.training.projectors import to_openai_tools

    rec = _base_record()
    rec["raw_events"] = [
        {
            "kind": "AssistantMessage",
            "content": [
                {
                    "type": "text",
                    "text": "API Error: Request rejected (429) · "
                            "This request would exceed your rate limit.",
                },
            ],
        },
        {
            "kind": "AssistantMessage",
            "content": [{"type": "text", "text": "Let me read the file."}],
        },
    ]
    out = to_openai_tools(rec)  # default: drop_error_turns=True
    asst = [m for m in out["messages"] if m["role"] == "assistant"]
    assert len(asst) == 1, (
        "Default drop_error_turns=True must drop the API-error message "
        "but keep the genuine assistant turn."
    )
    assert "API Error" not in asst[0]["content"]
    assert "read the file" in asst[0]["content"]


def test_openai_tools_keeps_api_error_turns_when_opt_out() -> None:
    """``drop_error_turns=False`` opts back in (e.g. for failure analysis)."""
    from claw_forge.training.projectors import to_openai_tools

    rec = _base_record()
    rec["raw_events"] = [
        {
            "kind": "AssistantMessage",
            "content": [{"type": "text", "text": "API Error: Request rejected (429)"}],
        },
    ]
    out = to_openai_tools(rec, drop_error_turns=False)
    asst = [m for m in out["messages"] if m["role"] == "assistant"]
    assert len(asst) == 1
    assert "API Error" in asst[0]["content"]


def test_openai_tools_keeps_normal_turns_with_filter_on() -> None:
    """Filter must be narrow: only error-shaped turns are dropped."""
    from claw_forge.training.projectors import to_openai_tools

    rec = _base_record()
    rec["raw_events"] = [
        {
            "kind": "AssistantMessage",
            "content": [{"type": "text", "text": "Looking at the API errors in the logs..."}],
        },
    ]
    # Filter mentions ``API Error: Request rejected`` specifically.  Casual
    # mentions of "API errors" in normal prose must NOT be dropped — the
    # filter must distinguish the upstream-error sentinel from the topic.
    out = to_openai_tools(rec)
    asst = [m for m in out["messages"] if m["role"] == "assistant"]
    assert len(asst) == 1
    assert "Looking at" in asst[0]["content"]
