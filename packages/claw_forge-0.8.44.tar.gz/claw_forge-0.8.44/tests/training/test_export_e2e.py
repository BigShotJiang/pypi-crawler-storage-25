"""End-to-end verification: recorder → state service → events → export.

This test pins the FULL training-trace export pipeline that v0.8.35
fixed.  It exercises every component the dispatcher hot path relies on:

1. ``RecordingDestination`` constructed with a real state-service URL.
2. ``record_messages`` POSTing each SDK message via httpx.
3. State service ``POST /sessions/<id>/events`` persisting the
   ``agent_message`` row with the JSON payload intact.
4. ``iter_training_records`` reading the SQLite DB and assembling
   per-task records from the persisted events.

The AST tests in ``tests/orchestrator/test_task_handler_recorder.py``
prove the WIRING exists.  This test proves the WIRING WORKS — every
component downstream of ``agent_session.run()`` actually carries SDK
messages through to non-empty export output.  Without it we could
silently break any link in the chain and the AST tests would still
pass.
"""

from __future__ import annotations

import json
import sqlite3
from collections.abc import AsyncIterator
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx
import pytest
from fastapi.testclient import TestClient
from httpx import ASGITransport


@dataclass
class _FakeTextBlock:
    """Mimics anthropic SDK ``TextBlock`` for the projector path."""

    text: str
    type: str = "text"


@dataclass
class _FakeAssistantMessage:
    """Mimics anthropic SDK ``AssistantMessage``."""

    content: list[Any]
    model: str = "claude-sonnet-4-6"


@dataclass
class _FakeResultMessage:
    """Mimics anthropic SDK ``ResultMessage`` (terminal turn)."""

    result: str
    stop_reason: str = "end_turn"


async def _yield_three_messages() -> AsyncIterator[Any]:
    """Async iterator yielding the same shapes the real SDK emits."""
    yield _FakeAssistantMessage(content=[_FakeTextBlock(text="first turn")])
    yield _FakeAssistantMessage(content=[_FakeTextBlock(text="second turn")])
    yield _FakeResultMessage(result="done")


@pytest.fixture
def state_db(tmp_path: Path) -> Path:
    """Return the on-disk path the state service writes to."""
    return tmp_path / "state.db"


@pytest.fixture
def state_app(state_db: Path) -> Any:
    """FastAPI app wired to a temp SQLite DB at the known path."""
    from claw_forge.state.service import AgentStateService

    db_url = f"sqlite+aiosqlite:///{state_db}"
    svc = AgentStateService(database_url=db_url)
    return svc.create_app()


@pytest.mark.asyncio
async def test_recorder_to_export_end_to_end_v0835(
    state_app: Any, state_db: Path,
) -> None:
    # Trigger the FastAPI lifespan synchronously via TestClient so the
    # SQLAlchemy ``create_all()`` runs against state_db before the async
    # ASGITransport block starts hitting the API.
    with TestClient(state_app):
        pass

    """Drive recorder → state service → SQLite → exporter and verify the
    captured messages survive every hop.

    Regresses the v0.8.29-v0.8.34 silent-empty-corpus bug fixed in
    v0.8.35.  If any link in the chain breaks (recorder POST URL drifts,
    state service stops persisting agent_message events, the export
    query filter drops them, the row schema changes), this test fails.
    """
    from claw_forge.training.exporter import iter_training_records
    from claw_forge.training.recorder import (
        RecordingDestination,
        record_messages,
    )

    transport = ASGITransport(app=state_app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test",
    ) as client:
        # ── 1. Create a session and a task ─────────────────────────────
        sresp = await client.post(
            "/sessions", json={"project_path": "/tmp/verify-035"},
        )
        assert sresp.status_code == 201, sresp.text
        session_id = sresp.json()["id"]

        tresp = await client.post(
            f"/sessions/{session_id}/tasks",
            json={"plugin_name": "coding", "description": "verify pipeline"},
        )
        assert tresp.status_code == 201, tresp.text
        task_id = tresp.json()["id"]

        # ── 2. Run record_messages against a fake SDK iterator ─────────
        # Real call site: ``task_handler.py`` wraps ``agent_session.run(prompt)``
        # with ``record_messages(..., dest=dest)`` (v0.8.35 fix).  We simulate
        # the same wrap pattern exactly.
        dest = RecordingDestination(
            session_id=session_id, task_id=task_id, state_url="http://test",
        )
        consumed: list[Any] = []
        async for msg in record_messages(
            _yield_three_messages(), dest=dest, client=client,
        ):
            consumed.append(msg)
        # The wrap must yield every message through to the caller (tee, not
        # filter) — exactly the contract the dispatcher loop relies on.
        assert len(consumed) == 3, (
            "record_messages dropped messages; the dispatcher loop would "
            "miss SDK output"
        )

        # ── 3. Mark task completed + merged so the exporter includes it ─
        patch = await client.patch(
            f"/tasks/{task_id}",
            json={
                "status": "completed",
                "merged_to_target_branch": True,
            },
        )
        assert patch.status_code == 200, patch.text

    # ── 4. Export reads back the persisted events ───────────────────────
    # Direct module call — same code path ``claw-forge export training``
    # invokes via ``export_cli.py``.
    records = list(
        iter_training_records(state_db, scope="session", session=session_id),
    )

    # The whole point of the v0.8.35 fix: the corpus is non-empty.
    assert len(records) == 1, (
        f"Expected exactly 1 record for the completed task, got {len(records)}. "
        "If 0: the export query filter dropped the task or the recorder didn't "
        "persist any events (the v0.8.34 bug class)."
    )
    rec = records[0]
    assert rec["task_id"] == task_id
    assert rec["outcome"] == "success"
    assert rec["session_id"] == session_id

    # ── 5. The raw events round-trip with the SDK message shapes intact ─
    events = rec["raw_events"]
    assert len(events) == 3, (
        f"Expected 3 raw_events (matching the 3 fake messages yielded), "
        f"got {len(events)}.  Recorder→state-service→export hop dropped "
        f"events."
    )
    # Turn numbering preserved (0, 1, 2 in dispatch order)
    assert [e["turn"] for e in events] == [0, 1, 2]
    # Message kinds preserved
    assert [e["kind"] for e in events] == [
        "_FakeAssistantMessage",
        "_FakeAssistantMessage",
        "_FakeResultMessage",
    ]
    # Text content preserved through the wire — this is what the projector
    # eventually renders for the training corpus.
    assert events[0]["content"][0]["text"] == "first turn"
    assert events[1]["content"][0]["text"] == "second turn"
    assert events[2]["result"] == "done"


def test_export_query_excludes_unmerged_tasks(tmp_path: Path) -> None:
    """Belt-and-braces: confirm the export filter requires
    ``merged_to_target_branch=1``.

    The v0.8.34 corpus was empty for two compounding reasons:
    (a) recorder wasn't firing (the primary bug, fixed in v0.8.35), and
    (b) even if it had been, the export filter requires the task to be
    merged.  This test pins (b) so a future filter relaxation doesn't
    silently widen the corpus to include unmerged work.
    """
    from claw_forge.training.exporter import iter_training_records

    db = tmp_path / "minimal.db"
    conn = sqlite3.connect(db)
    conn.executescript(
        """
        CREATE TABLE tasks (
            id TEXT PRIMARY KEY,
            session_id TEXT,
            plugin_name TEXT,
            description TEXT,
            category TEXT,
            shape TEXT,
            status TEXT,
            merged_to_target_branch INTEGER DEFAULT 0,
            bugfix_retry_count INTEGER DEFAULT 0,
            merge_commit_sha TEXT,
            input_tokens INTEGER DEFAULT 0,
            output_tokens INTEGER DEFAULT 0,
            cost_usd REAL DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id TEXT,
            event_type TEXT,
            payload TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        INSERT INTO tasks (id, session_id, plugin_name, description, status,
                           merged_to_target_branch)
        VALUES
            ('t-merged',   's1', 'coding', 'm', 'completed', 1),
            ('t-unmerged', 's1', 'coding', 'u', 'completed', 0);
        """
    )
    # Both tasks have an agent_message event
    for tid in ("t-merged", "t-unmerged"):
        conn.execute(
            "INSERT INTO events (task_id, event_type, payload) VALUES (?, ?, ?)",
            (tid, "agent_message", json.dumps({"turn": 0, "kind": "X"})),
        )
    conn.commit()
    conn.close()

    records = list(iter_training_records(db, scope="all"))
    ids = [r["task_id"] for r in records]
    assert ids == ["t-merged"], (
        "Export must filter on merged_to_target_branch=1; got "
        f"{ids} — an unmerged task leaked into the corpus."
    )
