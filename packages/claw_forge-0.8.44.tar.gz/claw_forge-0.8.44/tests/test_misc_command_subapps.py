"""Smoke tests for the PR 6 misc-command extraction (pool-status, fix, merge, ui, dev)."""
from __future__ import annotations

from typer.testing import CliRunner


def test_all_misc_commands_appear_in_main_cli_help() -> None:
    """All 5 commands moved in PR 6 should be top-level in `claw-forge --help`."""
    from claw_forge.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    for cmd in ("pool-status", "fix", "merge", "ui", "dev"):
        assert cmd in result.stdout, f"missing command: {cmd}"


def test_misc_commands_help_works() -> None:
    """Each command's --help exits 0 (Typer wiring intact after extraction)."""
    from claw_forge.cli import app

    runner = CliRunner()
    for cmd in ("pool-status", "fix", "merge", "ui", "dev"):
        result = runner.invoke(app, [cmd, "--help"])
        assert result.exit_code == 0, f"{cmd} --help failed: {result.stdout}"
