"""Pin staleness-aware salvage path in smart cleanup (v0.8.40).

A worktree whose branch is more than ``stale_salvage_threshold`` commits
behind ``target`` is unlikely to resume cleanly — pre-dispatch sync will
almost certainly conflict, the task will be marked failed, and the
*next* startup's smart cleanup salvages it.  That costs operators:

* disk space (the preserved worktree sticks around until next startup),
* one wasted dispatch cycle per stale worktree,
* confusion about why N worktrees exist when ``--concurrency 1``.

The fix promotes stale ``pending``/``running`` worktrees from
``preserve`` to ``salvage`` upfront — same code path as a failed-task
salvage, just triggered by staleness instead of failure status.

Real-world trigger: meridian project on 2026-05-20 had two preserved
worktrees ``feat/skill-forge-sel-...`` (83 commits behind) and
``feat/vaults-credenti-...`` (68 commits behind) sitting indefinitely
because ``_decorate_resumable`` skipped the resumable *preference* for
them; their tasks would still be dispatched, but the existing partial
work was effectively un-mergeable.

Back-compat: existing callers that don't pass the new params see
unchanged behaviour (``staleness=None`` / threshold ``None`` falls
through to the original ``preserve`` branch).
"""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from claw_forge.git.cleanup import decide_action, smart_cleanup_worktrees


@pytest.fixture()
def git_repo(tmp_path: Path) -> Path:
    """A bare init'd repo with one commit on ``main`` — enough to branch from."""
    subprocess.run(["git", "init", "-q", "-b", "main"], cwd=tmp_path, check=True)
    subprocess.run(
        ["git", "config", "user.email", "t@t.x"], cwd=tmp_path, check=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "t"], cwd=tmp_path, check=True,
    )
    (tmp_path / "README.md").write_text("# init\n")
    subprocess.run(["git", "add", "."], cwd=tmp_path, check=True)
    subprocess.run(
        ["git", "commit", "-q", "-m", "init"], cwd=tmp_path, check=True,
    )
    return tmp_path


class TestDecideActionStaleSalvage:
    """Pure-logic tests for the new staleness branch.

    The existing matrix (``test_cleanup.py::test_decide_action_matrix``)
    pins the legacy 2-arg behaviour; this class layers the new behaviour
    on top without touching it.
    """

    @pytest.mark.parametrize(
        "task_status,has_commits,staleness,threshold,expected",
        [
            # Old behaviour preserved when staleness signals are absent.
            ("pending", True, None, None, "preserve"),
            ("running", True, None, None, "preserve"),
            ("pending", True, 200, None, "preserve"),  # threshold None
            ("pending", True, None, 100, "preserve"),  # staleness None
            # Below threshold → still preserve.
            ("pending", True, 50, 100, "preserve"),
            ("running", True, 99, 100, "preserve"),
            # Exactly at threshold → still preserve (strict > comparison).
            ("pending", True, 100, 100, "preserve"),
            # Above threshold → promote to salvage.
            ("pending", True, 101, 100, "salvage"),
            ("running", True, 150, 100, "salvage"),
            # Terminal states aren't affected by the staleness gate —
            # they were already salvage; check the new params don't break.
            ("failed", True, 999, 100, "salvage"),
            ("completed", True, 999, 100, "salvage"),
            # Empty branches still ``remove`` regardless of staleness
            # (no commits → nothing to salvage).
            ("pending", False, 999, 100, "remove"),
        ],
    )
    def test_decide_action_staleness_branch(
        self,
        task_status: str | None,
        has_commits: bool,
        staleness: int | None,
        threshold: int | None,
        expected: str,
    ) -> None:
        assert (
            decide_action(
                task_status, has_commits,
                staleness=staleness,
                stale_salvage_threshold=threshold,
            )
            == expected
        )


class TestSmartCleanupStaleSalvageIntegration:
    """Drive ``smart_cleanup_worktrees`` against a real git repo to confirm
    the staleness signal reaches the decision and produces a salvage
    outcome (not preserve) for a sufficiently-behind branch."""

    def _make_stale_worktree(
        self,
        git_repo: Path,
        slug: str,
        *,
        main_advance: int,
    ) -> None:
        """Create a worktree with 1 commit ahead + N commits added to main.

        Lays out the exact shape ``smart_cleanup_worktrees`` will walk:
        ``.claw-forge/worktrees/<slug>/`` linked to ``feat/<slug>`` with
        partial work, then advances main beyond it.
        """
        branch = f"feat/{slug}"
        wt_dir = git_repo / ".claw-forge" / "worktrees" / slug
        wt_dir.parent.mkdir(parents=True, exist_ok=True)
        # Branch + worktree from current main HEAD
        subprocess.run(
            ["git", "worktree", "add", "-b", branch, str(wt_dir)],
            cwd=git_repo, check=True,
        )
        # One auto-save commit inside the worktree (the "partial work")
        (wt_dir / "partial.txt").write_text("wip\n")
        subprocess.run(["git", "add", "."], cwd=wt_dir, check=True)
        subprocess.run(
            ["git", "commit", "-q", "-m", "auto-save: coding in progress"],
            cwd=wt_dir, check=True,
        )
        # Advance main far past the worktree's branch point
        for i in range(main_advance):
            (git_repo / f"adv-{i}.txt").write_text(str(i))
            subprocess.run(["git", "add", "."], cwd=git_repo, check=True)
            subprocess.run(
                ["git", "commit", "-q", "-m", f"main commit {i}"],
                cwd=git_repo, check=True,
            )

    def test_stale_pending_worktree_is_salvaged_when_threshold_set(
        self, git_repo: Path,
    ) -> None:
        """Reproduces the meridian scenario: pending task with auto-save
        commits, main advanced 6 commits past the branch point, threshold
        set to 5 → expect salvage outcome (not preserve)."""
        # Slug must match what make_branch_name produces from the task's
        # description+category — otherwise _build_slug_to_task_map can't
        # match the worktree to the task and we'd hit the orphan path
        # (which already returns salvage, so the test would pass for the
        # wrong reason).
        self._make_stale_worktree(
            git_repo, "stale-stale-task-description", main_advance=6,
        )
        tasks = [{
            "id": "t1", "status": "pending",
            "description": "Stale task description",
            "category": "stale", "plugin_name": "coding",
        }]
        outcomes = smart_cleanup_worktrees(
            git_repo, tasks,
            prefix="feat",
            target="main",
            stale_salvage_threshold=5,
        )
        # Find the outcome for our worktree
        ours = [o for o in outcomes if o.slug == "stale-stale-task-description"]
        assert len(ours) == 1
        assert ours[0].action == "salvage", (
            f"Expected stale pending worktree to be salvaged (main is 6 "
            f"commits ahead, threshold=5), got action={ours[0].action!r}.  "
            f"The staleness signal isn't reaching decide_action — check "
            f"the smart_cleanup_worktrees wiring."
        )

    def test_non_stale_pending_worktree_is_preserved(
        self, git_repo: Path,
    ) -> None:
        """Negative: a branch only 2 commits behind main (under threshold
        of 5) must still preserve — the salvage gate must be narrow."""
        self._make_stale_worktree(
            git_repo, "fresh-fresh-task-description", main_advance=2,
        )
        tasks = [{
            "id": "t2", "status": "pending",
            "description": "Fresh task description",
            "category": "fresh", "plugin_name": "coding",
        }]
        outcomes = smart_cleanup_worktrees(
            git_repo, tasks,
            prefix="feat",
            target="main",
            stale_salvage_threshold=5,
        )
        ours = [o for o in outcomes if o.slug == "fresh-fresh-task-description"]
        assert len(ours) == 1
        assert ours[0].action == "preserve", (
            f"Fresh worktree (2 commits behind, threshold=5) must still "
            f"preserve.  Got action={ours[0].action!r}.  The staleness "
            f"gate fired too aggressively."
        )

    def test_threshold_None_keeps_legacy_preserve_behavior(
        self, git_repo: Path,
    ) -> None:
        """Back-compat: callers that omit ``stale_salvage_threshold`` see
        unchanged behaviour — even very stale pending worktrees preserve."""
        self._make_stale_worktree(
            git_repo, "very-very-stale-task", main_advance=50,
        )
        tasks = [{
            "id": "t3", "status": "pending",
            "description": "Very stale task",
            "category": "very", "plugin_name": "coding",
        }]
        outcomes = smart_cleanup_worktrees(
            git_repo, tasks,
            prefix="feat",
            target="main",
            # stale_salvage_threshold deliberately omitted
        )
        ours = [o for o in outcomes if o.slug == "very-very-stale-task"]
        assert len(ours) == 1
        assert ours[0].action == "preserve", (
            "Back-compat broken: omitting stale_salvage_threshold must "
            "behave exactly as before (preserve all pending+commits)."
        )
