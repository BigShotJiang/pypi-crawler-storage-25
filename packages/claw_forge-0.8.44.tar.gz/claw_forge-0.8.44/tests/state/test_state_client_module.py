"""Sanity tests for the claw_forge.state.client module + cli.py shim."""
from __future__ import annotations

import sqlite3
from pathlib import Path


def test_state_client_module_exports_expected_symbols() -> None:
    """All public helpers exist on claw_forge.state.client."""
    from claw_forge.state import client

    for name in (
        "_state_url",
        "_task_dict_to_node",
        "_decorate_resumable",
        "_http_get",
        "_http_post",
        "_resolve_project_root",
        "_resolve_latest_session",
        "_port_in_use_error",
        "_ensure_state_service",
    ):
        assert hasattr(client, name), f"missing symbol: {name}"


def test_cli_shim_reexports_state_client_helpers() -> None:
    """Tests that import from claw_forge.cli keep working after the move."""
    from claw_forge.cli import (
        _resolve_latest_session,
        _resolve_project_root,
        _task_dict_to_node,
    )

    assert callable(_resolve_latest_session)
    assert callable(_resolve_project_root)
    assert callable(_task_dict_to_node)


def test_state_url_default_port() -> None:
    """_state_url uses port 8420 by default and accepts an override."""
    from claw_forge.state.client import _state_url

    assert _state_url() == "http://localhost:8420"
    assert _state_url(9999) == "http://localhost:9999"


def test_resolve_latest_session_filters_by_project_path(tmp_path: Path) -> None:
    """_resolve_latest_session only returns sessions matching the project_path.

    NOTE: This test assumes the helper queries a `sessions` table with at least
    `(id, project_path, created_at)` columns and orders by `created_at` DESC.
    If the real schema differs, update the test to match — but verify by
    reading the helper body, not by guessing.
    """
    from claw_forge.state.client import _resolve_latest_session

    db = tmp_path / "state.db"
    conn = sqlite3.connect(db)
    conn.execute(
        "CREATE TABLE sessions (id TEXT PRIMARY KEY, project_path TEXT, created_at REAL)"
    )
    conn.execute(
        "INSERT INTO sessions VALUES ('a', '/proj-a', 1000), ('b', '/proj-b', 2000)"
    )
    conn.commit()
    conn.close()

    assert _resolve_latest_session(db, Path("/proj-a")) == "a"
    assert _resolve_latest_session(db, Path("/proj-b")) == "b"
