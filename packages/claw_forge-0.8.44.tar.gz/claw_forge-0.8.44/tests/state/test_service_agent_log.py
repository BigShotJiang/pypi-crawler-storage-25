"""Tests for v0.8.28 server-side agent_log persistence + hydration endpoint.

Pre-v0.8.28 the activity log lived only in browser ``sessionStorage``,
making refresh / new-tab / new-machine views inconsistent and leaving
disabled providers from prior sessions lingering in the cache.  v0.8.28
persists every ``POST /tasks/{id}/agent-log`` to the events table and
exposes ``GET /sessions/{id}/agent-log`` for hydration.
"""
from __future__ import annotations

from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient

from claw_forge.state.service import AgentStateService


async def _make_session_and_task(cl: AsyncClient, project_path: Path) -> tuple[str, str]:
    r = await cl.post("/sessions", json={"project_path": str(project_path)})
    session_id = r.json()["id"]
    r = await cl.post(
        f"/sessions/{session_id}/tasks",
        json={"plugin_name": "coding", "description": "demo"},
    )
    task_id = r.json()["id"]
    return session_id, task_id


@pytest.mark.asyncio
async def test_post_agent_log_persists_event(tmp_path: Path) -> None:
    """The headline contract: every agent-log POST writes to the events
    table so future hydration sees it.  Pre-v0.8.28 these were broadcast-
    only and a refresh lost them entirely."""
    svc = AgentStateService(
        database_url=f"sqlite+aiosqlite:///{tmp_path / 'state.db'}",
        project_path=tmp_path,
    )
    async with svc:
        app = svc.create_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test",
        ) as cl:
            session_id, task_id = await _make_session_and_task(cl, tmp_path)

            r = await cl.post(
                f"/tasks/{task_id}/agent-log",
                json={
                    "role": "assistant",
                    "content": "Hello, world.",
                    "model": "claude-sonnet-4-6",
                    "provider": "claude-oauth-1",
                    "task_name": "demo",
                },
            )
            assert r.status_code == 200
            assert r.json() == {"status": "ok"}

            # Hydrate from the events table — should see exactly the row
            # we just posted.
            r = await cl.get(f"/sessions/{session_id}/agent-log")
            rows = r.json()
            assert len(rows) == 1
            row = rows[0]
            assert row["task_id"] == task_id
            assert row["payload"]["role"] == "assistant"
            assert row["payload"]["content"] == "Hello, world."
            assert row["payload"]["provider"] == "claude-oauth-1"
            assert row["payload"]["task_name"] == "demo"


@pytest.mark.asyncio
async def test_agent_log_endpoint_filters_to_agent_log_event_type(
    tmp_path: Path,
) -> None:
    """The events table also holds task.updated and other event_types;
    the hydration endpoint must return ONLY agent_log entries so the UI
    doesn't get a polluted activity feed."""
    svc = AgentStateService(
        database_url=f"sqlite+aiosqlite:///{tmp_path / 'state.db'}",
        project_path=tmp_path,
    )
    async with svc:
        app = svc.create_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test",
        ) as cl:
            session_id, task_id = await _make_session_and_task(cl, tmp_path)

            # Mix: one PATCH (emits task.updated) + two agent-logs.
            await cl.patch(
                f"/tasks/{task_id}",
                json={"status": "running"},
            )
            for content in ("first turn", "second turn"):
                await cl.post(
                    f"/tasks/{task_id}/agent-log",
                    json={"role": "assistant", "content": content},
                )

            r = await cl.get(f"/sessions/{session_id}/agent-log")
            rows = r.json()
            assert len(rows) == 2
            assert [row["payload"]["content"] for row in rows] == [
                "first turn", "second turn",
            ]


@pytest.mark.asyncio
async def test_agent_log_since_cursor_returns_only_newer_rows(
    tmp_path: Path,
) -> None:
    """The reconnect path: UI sends ``?since=<lastSeenId>`` to fill the
    gap from a WebSocket disconnect.  Cursor must be strict-greater-than
    so the last-seen entry isn't duplicated."""
    svc = AgentStateService(
        database_url=f"sqlite+aiosqlite:///{tmp_path / 'state.db'}",
        project_path=tmp_path,
    )
    async with svc:
        app = svc.create_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test",
        ) as cl:
            session_id, task_id = await _make_session_and_task(cl, tmp_path)

            for i in range(5):
                await cl.post(
                    f"/tasks/{task_id}/agent-log",
                    json={"role": "assistant", "content": f"turn-{i}"},
                )

            # First fetch — get the lot.
            r = await cl.get(f"/sessions/{session_id}/agent-log")
            rows = r.json()
            assert len(rows) == 5
            third_id = rows[2]["id"]

            # Second fetch with cursor — should return only entries
            # strictly newer than third_id (so 2 rows: turn-3 and turn-4).
            r = await cl.get(
                f"/sessions/{session_id}/agent-log?since={third_id}",
            )
            rows = r.json()
            assert len(rows) == 2
            assert [row["payload"]["content"] for row in rows] == [
                "turn-3", "turn-4",
            ]


@pytest.mark.asyncio
async def test_agent_log_limit_caps_response(tmp_path: Path) -> None:
    """The limit parameter caps response size for long sessions; default
    500 keeps browser memory bounded.  Verify a low explicit limit
    actually caps."""
    svc = AgentStateService(
        database_url=f"sqlite+aiosqlite:///{tmp_path / 'state.db'}",
        project_path=tmp_path,
    )
    async with svc:
        app = svc.create_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test",
        ) as cl:
            session_id, task_id = await _make_session_and_task(cl, tmp_path)

            for i in range(10):
                await cl.post(
                    f"/tasks/{task_id}/agent-log",
                    json={"role": "assistant", "content": f"turn-{i}"},
                )
            r = await cl.get(f"/sessions/{session_id}/agent-log?limit=3")
            rows = r.json()
            assert len(rows) == 3
            # Ordered ASC by id — earliest first.
            assert rows[0]["payload"]["content"] == "turn-0"
            assert rows[2]["payload"]["content"] == "turn-2"


@pytest.mark.asyncio
async def test_agent_log_suppressed_for_paused_task_not_persisted(
    tmp_path: Path,
) -> None:
    """Stop-all paused tasks must not pollute the activity log — neither
    the WebSocket broadcast NOR the persisted events table.  Pre-v0.8.28
    only the broadcast was suppressed; persistence path needs the same
    guard so a hydrated client doesn't see paused-task spam."""
    svc = AgentStateService(
        database_url=f"sqlite+aiosqlite:///{tmp_path / 'state.db'}",
        project_path=tmp_path,
    )
    async with svc:
        app = svc.create_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test",
        ) as cl:
            session_id, task_id = await _make_session_and_task(cl, tmp_path)
            # Mark running so stop-all picks it up — only running tasks
            # get added to ``_paused_task_ids``.
            await cl.patch(f"/tasks/{task_id}", json={"status": "running"})
            await cl.post(f"/sessions/{session_id}/tasks/stop-all")

            r = await cl.post(
                f"/tasks/{task_id}/agent-log",
                json={"role": "assistant", "content": "should be suppressed"},
            )
            assert r.json() == {"status": "suppressed"}

            r = await cl.get(f"/sessions/{session_id}/agent-log")
            assert r.json() == []
