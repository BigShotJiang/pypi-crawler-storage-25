"""Pin dispatcher-liveness endpoints (v0.8.39).

When the dispatcher process dies (Ctrl+C, terminal close, OS reboot),
the state service keeps serving the Kanban UI as if nothing happened —
recent ``agent_log`` events look fresh, task counts are unchanged,
``stop-poll`` returns ``pause:false``.  Operators get no signal that
work has actually stopped.  Real-world meridian incident
(2026-05-19 02:13Z → 12:00Z): 153 pending tasks sitting idle for
~10 hours with zero indication anything was wrong.

Fix: explicit heartbeat protocol.

- Dispatcher POSTs ``/sessions/{id}/dispatcher/heartbeat`` every 30 s.
- UI/operator GETs ``/sessions/{id}/dispatcher/status`` for the answer.
- ``alive`` is True iff a heartbeat landed within 90 s (3 × ping
  interval — gives one wallclock retry before declaring death).

These tests pin the contract.  Wiring on the dispatcher side is
covered by ``tests/orchestrator/test_dispatcher_heartbeat_wiring.py``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def state_db(tmp_path: Path) -> Path:
    return tmp_path / "state.db"


@pytest.fixture
def app_pair(state_db: Path) -> Any:
    from claw_forge.state.service import AgentStateService

    db_url = f"sqlite+aiosqlite:///{state_db}"
    svc = AgentStateService(database_url=db_url)
    return svc.create_app(), svc


def _make_session(client: TestClient) -> str:
    sresp = client.post("/sessions", json={"project_path": "/tmp/p"})
    return sresp.json()["id"]


def test_dispatcher_status_before_any_heartbeat_is_not_alive(app_pair: Any) -> None:
    """Fresh service + no heartbeat → ``alive:false`` with null heartbeat."""
    app, _svc = app_pair
    del _svc
    with TestClient(app) as client:
        sid = _make_session(client)
        resp = client.get(f"/sessions/{sid}/dispatcher/status")
        assert resp.status_code == 200, resp.text
        body = resp.json()
        assert body["alive"] is False, (
            "No heartbeat has ever landed for this session; status MUST "
            "report alive=False so the UI/CLI can show 'dispatcher offline'."
        )
        assert body["last_heartbeat_iso"] is None
        assert body["seconds_since"] is None


def test_heartbeat_post_flips_status_to_alive(app_pair: Any) -> None:
    """POST /dispatcher/heartbeat → next GET status returns alive=True."""
    app, _svc = app_pair
    del _svc
    with TestClient(app) as client:
        sid = _make_session(client)
        post = client.post(f"/sessions/{sid}/dispatcher/heartbeat")
        assert post.status_code in (200, 201, 204), post.text

        resp = client.get(f"/sessions/{sid}/dispatcher/status")
        body = resp.json()
        assert body["alive"] is True, (
            "Heartbeat just landed; alive must be True until the grace "
            "window expires."
        )
        assert body["last_heartbeat_iso"] is not None
        # seconds_since should be a small positive float, well under the
        # 90 s grace window
        assert 0 <= body["seconds_since"] < 5


def test_status_flips_back_to_not_alive_after_grace_window(
    app_pair: Any, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A stale heartbeat (>90s old) must report alive=False.

    Time-skip by monkeypatching the service's internal ``now()`` helper
    rather than literally sleeping — keeps the test deterministic and
    fast.  The contract is purely about the age comparison, so injecting
    time is the right shape.
    """
    import claw_forge.state.service as svc_mod

    app, svc = app_pair
    with TestClient(app) as client:
        sid = _make_session(client)
        client.post(f"/sessions/{sid}/dispatcher/heartbeat")

        # Pretend it's now 2 minutes later — past the 90 s grace.
        original_now = svc_mod._dispatcher_now
        from datetime import timedelta
        future = original_now() + timedelta(seconds=120)
        monkeypatch.setattr(svc_mod, "_dispatcher_now", lambda: future)

        resp = client.get(f"/sessions/{sid}/dispatcher/status")
        body = resp.json()
        assert body["alive"] is False, (
            "Heartbeat is 120 s old > 90 s grace; dispatcher must be "
            "reported as offline."
        )
        assert body["last_heartbeat_iso"] is not None  # we still know when
        assert body["seconds_since"] > 90
    del svc


def test_heartbeats_are_per_session(app_pair: Any) -> None:
    """A heartbeat on session A must not lift session B's status.

    Without per-session keying, a heartbeat from one project's
    dispatcher would falsely indicate liveness for every other session
    in the DB.
    """
    app, _svc = app_pair
    del _svc
    with TestClient(app) as client:
        sid_a = _make_session(client)
        sid_b = _make_session(client)
        client.post(f"/sessions/{sid_a}/dispatcher/heartbeat")

        a = client.get(f"/sessions/{sid_a}/dispatcher/status").json()
        b = client.get(f"/sessions/{sid_b}/dispatcher/status").json()
        assert a["alive"] is True
        assert b["alive"] is False, (
            "Per-session keying broken: session B's status is True even "
            "though no heartbeat landed for it."
        )
