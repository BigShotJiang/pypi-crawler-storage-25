"""Pin: ``agent_message`` events are persisted but NOT broadcast to the Kanban WS.

The trace-recorder (``training/recorder.py``) POSTs each SDK message to
``/sessions/{id}/events`` with ``event_type='agent_message'`` so it lands
in the events table for ``claw-forge export training``.  The Kanban UI's
activity log was built around the structured ``agent_log`` event shape
(kind/text/model/provider/task_name) and has no renderer for the
recorder's raw SDK-message payload — ``useWebSocket.ts::eventToMessage``
has no ``case "agent_message"`` so broadcasting these events produces
empty rows in the activity panel (just timestamp + ``agent_message``
badge with no body).

The fix is to skip the Kanban broadcast for ``agent_message`` events
specifically — they're a backend persistence signal, not a UI feed.
Persistence (and SSE + legacy per-session WS broadcast) stays so the
export pipeline + any out-of-UI consumers are unaffected.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def state_db(tmp_path: Path) -> Path:
    return tmp_path / "state.db"


@pytest.fixture
def state_app(state_db: Path) -> Any:
    from claw_forge.state.service import AgentStateService

    db_url = f"sqlite+aiosqlite:///{state_db}"
    svc = AgentStateService(database_url=db_url)
    return svc.create_app(), svc


def test_agent_message_event_is_persisted(state_app: Any) -> None:
    """The POST endpoint still writes ``agent_message`` rows to events."""
    app, _svc = state_app
    del _svc
    with TestClient(app) as client:
        sresp = client.post("/sessions", json={"project_path": "/tmp/p"})
        sid = sresp.json()["id"]
        tresp = client.post(
            f"/sessions/{sid}/tasks",
            json={"plugin_name": "coding", "description": "x"},
        )
        tid = tresp.json()["id"]

        # POST via the same endpoint record_messages uses.
        eresp = client.post(
            f"/sessions/{sid}/events",
            json={
                "event_type": "agent_message",
                "task_id": tid,
                "payload": {"turn": 0, "kind": "AssistantMessage"},
            },
        )
        # FastAPI returns 201 by default for POST endpoints that
        # create resources; accept either to stay robust if the
        # endpoint's status_code is ever tightened.
        assert eresp.status_code in (200, 201), eresp.text

        # The event must be findable via GET /sessions/{id}/events/all
        # — that's what the exporter / out-of-band consumers rely on.
        listing = client.get(f"/sessions/{sid}/events/all").json()
        agent_msgs = [e for e in listing if e["event_type"] == "agent_message"]
        assert len(agent_msgs) == 1, (
            f"Expected 1 persisted agent_message event, got {len(agent_msgs)}. "
            "Persistence must survive — the export pipeline depends on it."
        )


def test_agent_message_event_is_not_broadcast_to_kanban_ws(
    state_app: Any, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Pin the UI fix: agent_message MUST be skipped by ws_manager.broadcast.

    Currently the Kanban UI shows empty ``agent_message`` rows because the
    recorder's events get broadcast but the UI has no renderer.  This test
    enforces the fix: ``_emit_event`` must skip the ``ws_manager.broadcast``
    call when ``event_type == 'agent_message'``.

    SSE listeners and legacy per-session ``/ws`` clients are intentionally
    NOT covered by this test — they still get the broadcast.  Only the
    Kanban ``ws_manager`` is filtered.
    """
    app, svc = state_app
    broadcast_calls: list[dict[str, Any]] = []

    async def _capturing_broadcast(payload: dict[str, Any]) -> None:
        broadcast_calls.append(payload)

    monkeypatch.setattr(svc.ws_manager, "broadcast", _capturing_broadcast)

    with TestClient(app) as client:
        sresp = client.post("/sessions", json={"project_path": "/tmp/p"})
        sid = sresp.json()["id"]
        tresp = client.post(
            f"/sessions/{sid}/tasks",
            json={"plugin_name": "coding", "description": "x"},
        )
        tid = tresp.json()["id"]

        # ── agent_message: should NOT trigger ws_manager.broadcast ─────
        client.post(
            f"/sessions/{sid}/events",
            json={
                "event_type": "agent_message",
                "task_id": tid,
                "payload": {"turn": 0, "kind": "AssistantMessage"},
            },
        )
        # ── a control event of a different type: SHOULD broadcast ──────
        # We use a fake event_type that isn't ``task.created/updated``
        # (those go through ``broadcast_feature_update`` instead) and
        # isn't ``agent_message``.  This proves the filter is narrow:
        # only ``agent_message`` is skipped, not "everything".
        client.post(
            f"/sessions/{sid}/events",
            json={
                "event_type": "custom_control_event",
                "task_id": tid,
                "payload": {"foo": "bar"},
            },
        )

    # Exactly one broadcast — for the control event, not for agent_message.
    broadcast_types = [p.get("type") for p in broadcast_calls]
    assert "agent_message" not in broadcast_types, (
        "ws_manager.broadcast was called with type='agent_message' — "
        "the Kanban UI will render empty rows for these. The fix is to "
        "skip the Kanban broadcast for agent_message events specifically."
    )
    assert "custom_control_event" in broadcast_types, (
        "The filter must be narrow: only agent_message is skipped, not "
        "all non-task events.  Got broadcast types: "
        f"{broadcast_types!r}"
    )
