"""Smoke tests asserting state_app commands are wired into the main CLI."""
from __future__ import annotations

from typer.testing import CliRunner


def test_state_app_commands_appear_in_main_cli_help() -> None:
    """All 6 state commands should appear in `claw-forge --help` output."""
    from claw_forge.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    for cmd in ("status", "state", "pause", "resume", "input", "add"):
        assert cmd in result.stdout, f"missing command: {cmd}"


def test_state_command_has_help() -> None:
    """Each state command's --help works after extraction."""
    from claw_forge.cli import app

    runner = CliRunner()
    for cmd in ("status", "state", "pause", "resume", "input", "add"):
        result = runner.invoke(app, [cmd, "--help"])
        assert result.exit_code == 0, f"{cmd} --help failed: {result.stdout}"
