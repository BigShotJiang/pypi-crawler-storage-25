"""Tests for v0.8.24 provider rotation on transient errors.

Two surfaces:

  * ``ProviderPoolManager.mark_provider_rate_limited(name)`` — the
    pool method the dispatcher calls when an agent run raises a
    transient provider error.  Trips the named provider's circuit
    so subsequent ``next_provider_for_dispatch()`` calls skip it.

  * The dispatcher's rotation loop (``cli.py`` ``_run_task``) — end-
    to-end behaviour: rate-limit raised → provider tripped → next
    provider returned → eventually exhausted.

The dispatcher loop itself is hard to unit-test without spinning
up a full agent session (it calls into ``AgentSession`` which
proxies to the real ``claude`` CLI).  The pool-level test below
covers the contract the dispatcher relies on; the dispatcher's
own loop is covered by ``test_cli_commands.py`` integration tests.
"""
from __future__ import annotations

import pytest

from claw_forge.pool.health import CircuitState
from claw_forge.pool.manager import ProviderPoolManager
from claw_forge.pool.providers.base import ProviderConfig, ProviderType


def _make_pool(provider_names: list[str]) -> ProviderPoolManager:
    """Build a real ``ProviderPoolManager`` with N anthropic providers.

    All providers are CLOSED at construction; the test trips them
    individually via ``mark_provider_rate_limited`` and verifies
    rotation behaves as the dispatcher expects.
    """
    configs = [
        ProviderConfig(
            name=name,
            provider_type=ProviderType.ANTHROPIC,
            api_key=f"sk-ant-fake-{name}",
            priority=1,
        )
        for name in provider_names
    ]
    return ProviderPoolManager(configs, failure_threshold=3)


class TestMarkProviderRateLimited:
    """Contract: tripping provider X via ``mark_provider_rate_limited``
    flips X's circuit to OPEN, and ``next_provider_for_dispatch``
    skips X afterwards.  Without this, the dispatcher's rotation
    loop would re-pick the same rate-limited provider on the
    immediate retry."""

    def test_returns_true_for_known_provider(self) -> None:
        """Tripping a configured provider returns True."""
        pool = _make_pool(["alpha", "beta"])
        assert pool.mark_provider_rate_limited("alpha") is True

    def test_returns_false_for_unknown_provider(self) -> None:
        """Tripping an unknown name (e.g. ``"env"`` for process-env
        creds) returns False — caller treats as "no rotation
        possible from here"."""
        pool = _make_pool(["alpha", "beta"])
        assert pool.mark_provider_rate_limited("env") is False
        assert pool.mark_provider_rate_limited("nonexistent") is False

    def test_circuit_opens_immediately(self) -> None:
        """After tripping, the provider's circuit is OPEN — the
        existing ``Router.select`` filter will skip it on the next
        dispatch call."""
        pool = _make_pool(["alpha"])
        assert pool._circuits["alpha"].state == CircuitState.CLOSED
        pool.mark_provider_rate_limited("alpha")
        assert pool._circuits["alpha"].state == CircuitState.OPEN

    def test_next_provider_skips_tripped_provider(self) -> None:
        """The end-to-end dispatcher contract: trip provider A,
        ``next_provider_for_dispatch`` returns provider B (not A)."""
        pool = _make_pool(["alpha", "beta", "gamma"])
        # Trip alpha — pool should skip it on subsequent dispatches.
        pool.mark_provider_rate_limited("alpha")
        for _ in range(5):  # any number of dispatches
            picked = pool.next_provider_for_dispatch()
            assert picked is not None
            assert picked.name != "alpha"

    def test_all_providers_tripped_returns_none(self) -> None:
        """When every provider is rate-limited, the next dispatch
        returns None — the dispatcher then surfaces a clear error
        instead of pinning the agent to a dead provider."""
        pool = _make_pool(["alpha", "beta"])
        pool.mark_provider_rate_limited("alpha")
        pool.mark_provider_rate_limited("beta")
        assert pool.next_provider_for_dispatch() is None

    def test_rotation_through_three_providers(self) -> None:
        """Simulates the dispatcher's worst case: each provider in
        turn rate-limits, dispatcher trips it, picks the next one.
        After all three are tripped, no providers remain."""
        pool = _make_pool(["alpha", "beta", "gamma"])
        seen = []
        for _ in range(3):
            picked = pool.next_provider_for_dispatch()
            assert picked is not None
            seen.append(picked.name)
            pool.mark_provider_rate_limited(picked.name)
        # All three tripped — no fourth provider to fall back to.
        assert pool.next_provider_for_dispatch() is None
        # Each provider was visited exactly once (round-robin).
        assert sorted(seen) == ["alpha", "beta", "gamma"]

    def test_idempotent_trip(self) -> None:
        """Tripping the same provider twice is a no-op — the
        circuit stays OPEN and the failure count doesn't run away
        beyond ``failure_threshold``.  Important because the
        dispatcher's retry loop might call ``mark_provider_rate_limited``
        again if the rotation hits transient races."""
        pool = _make_pool(["alpha", "beta"])
        pool.mark_provider_rate_limited("alpha")
        first_count = pool._circuits["alpha"]._failure_count
        # Trip again; failure count shouldn't exceed threshold.
        pool.mark_provider_rate_limited("alpha")
        second_count = pool._circuits["alpha"]._failure_count
        assert second_count == first_count, (
            "double-trip leaked failure count past the threshold"
        )
        assert pool._circuits["alpha"].state == CircuitState.OPEN


class TestRotationContractWithFakePool:
    """End-to-end-ish test of the dispatcher's contract using a
    minimal fake pool — verifies the SEQUENCE the dispatcher's
    rotation loop performs:

      1. _resolve_sdk_credentials → picks provider A
      2. agent run on A raises rate-limit
      3. dispatcher calls mark_provider_rate_limited("A")
      4. _resolve_sdk_credentials → picks provider B (NOT A)
      5. agent run on B succeeds → break

    Doesn't actually run an agent — just walks the
    ``next_provider_for_dispatch`` + ``mark_provider_rate_limited``
    interaction the dispatcher uses.
    """

    def test_dispatch_then_trip_then_dispatch(self) -> None:
        pool = _make_pool(["alpha", "beta", "gamma"])
        # First dispatch picks some provider (round-robin starts
        # with the first registered).
        first = pool.next_provider_for_dispatch()
        assert first is not None
        first_name = first.name
        # Simulate rate-limit on this provider.
        pool.mark_provider_rate_limited(first_name)
        # Second dispatch must NOT return the tripped one.
        second = pool.next_provider_for_dispatch()
        assert second is not None
        assert second.name != first_name


class TestNoRotationWhenSingleProvider:
    """When the pool has exactly one provider, rate-limiting that
    provider exhausts the pool — no rotation possible.  Dispatcher
    should fail the task with a clear "all providers tripped"
    error rather than retry indefinitely."""

    def test_single_provider_exhausts_immediately(self) -> None:
        pool = _make_pool(["solo"])
        first = pool.next_provider_for_dispatch()
        assert first is not None
        assert first.name == "solo"
        pool.mark_provider_rate_limited("solo")
        assert pool.next_provider_for_dispatch() is None


class TestRotationWithEnvCredentials:
    """When the SDK env path returned ``"env"`` as the provider name
    (process-env credentials, not pool), the dispatcher MUST NOT
    call ``mark_provider_rate_limited("env")`` — but if it does
    (defensive), the call returns False without affecting the pool.
    Locks in the no-op contract for the off-pool credential path."""

    def test_env_name_is_safe_to_trip(self) -> None:
        pool = _make_pool(["alpha", "beta"])
        # Defensively trip "env" — should be a no-op.
        result = pool.mark_provider_rate_limited("env")
        assert result is False
        # Pool still has both providers available.
        assert pool._circuits["alpha"].state == CircuitState.CLOSED
        assert pool._circuits["beta"].state == CircuitState.CLOSED


@pytest.mark.parametrize(
    "error_text,should_retry",
    [
        # Rate-limit cases (existing behaviour preserved)
        ("rate limit exceeded", True),
        ("HTTP 429", True),
        ("Too many requests", True),
        ("quota exceeded", True),
        ("Service overloaded", True),
        # Server errors (NEW in v0.8.24)
        ("HTTP 500 internal server error", True),
        ("502 Bad Gateway", True),
        ("503 Service Unavailable", True),
        ("504 Gateway Timeout", True),
        # Network failures (NEW in v0.8.24)
        ("Connection refused", True),
        ("Connection reset by peer", True),
        ("Operation timed out", True),
        ("Name or service not known", True),
        # Auth-credential errors (NEW in v0.8.27).  Per-provider
        # configuration; another provider may have working creds.
        ("oauth_org_not_allowed", True),
        ("oauth_token_invalid", True),
        ("invalid_api_key", True),
        ("Invalid API Key", True),
        ("authentication_error", True),
        ("Authentication failed", True),
        ("HTTP 401 Unauthorized", True),
        ("Request unauthorized", True),
        # Should NOT retry: request-level errors that re-fail
        # identically on every provider.
        ("HTTP 400 Bad Request", False),
        ("HTTP 403 Forbidden", False),  # often content-moderation
        ("HTTP 404 not found", False),
        ("ValidationError: malformed input", False),
        ("Agent loop detected", False),
        ("[Sandbox] DENIED Bash", False),
    ],
)
def test_dispatch_rotation_decision_matrix(
    error_text: str, should_retry: bool,
) -> None:
    """Parametrised: each error class produces the expected
    ``is_retryable_provider_error`` verdict, which is what the
    dispatcher's rotation loop branches on.  This locks the
    decision matrix as a single table — easy to extend when new
    error classes appear in production logs."""
    from claw_forge.agent.rate_limit import is_retryable_provider_error
    assert is_retryable_provider_error(error_text) is should_retry, (
        f"is_retryable_provider_error({error_text!r}) returned "
        f"{not should_retry}, expected {should_retry}"
    )
