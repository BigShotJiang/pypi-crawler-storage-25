# Cycle-Safe Dependency Inference + Gap 9 Detection

**Date:** 2026-05-16
**Status:** Design approved, ready for plan
**Author:** Bowen + Claude

## Problem

`claw-forge run` crashes with `CycleDetectedError` on user specs that mix
explicit `<feature depends_on>` edges with phase-inferred edges. The
crash is a planning bug, not a runtime bug — the scheduler's DAG validation
correctly refuses to execute a cyclic task graph.

### Reproducer

A 273-feature spec for the Meridian project (Python daemon + TS UI,
9 implementation phases E0..E8). When the user runs
`claw-forge run app_spec.txt`, the dispatcher's first wave-loop iteration
fails inside `Scheduler.validate_no_cycles()`:

```
CycleDetectedError: Cycle detected involving task 607fe2e5-...
```

Walking the dependency graph from the offending task reveals:

```
607fe2e5  Lifecycle Hooks (feature 193) ──explicit depends_on="76"──┐
   ↓                                                                │
3d29f35f  Harness & Run Loop (feature 76) ──explicit "74"──┐        │
   ↓                                                       │        │
666e98c8  Sessions & Event Log (feature 74) ──"63"──┐      │        │
   ↓                                                │      │        │
3edf719d  Sessions & Event Log (feature 63) ──"36"─┐│      │        │
   ↓                                               ││      │        │
166bc6f4  Storage NDJSON writer (feature 36, no explicit deps)      │
              └─ phase-inferred depends_on includes ────────────────┘
                 every feature in phase E3 (Hooks + Multi-Agent)
```

User-declared edges descend foundation-ward: `193 → 76 → 74 → 63 → 36`.
Phase inference adds `36 → 193` (because feature 36 has no explicit
deps). Cycle closes.

## Root Cause

`_assign_dependencies` in `claw_forge/spec/parser.py:618-651` assigns each
feature to a phase by **set-intersection of lowercase-split words** between
the feature's category name and the phase title. When no overlap is found,
the feature is dumped into the **middle phase**
(`phases[len(phases) // 2]`) as a fallback.

For the Meridian spec, three "foundation"-style categories — `Storage &
Repository Pattern`, `Harness & Run Loop`, `Sessions & Event Log` — share
no keywords with any of the nine phase titles (`E0 — Skeleton`, `E1 —
Sandbox + Capabilities`, …). They all fall through to phase E4 (middle).
E4's predecessor is E3 (`Multi-agent + Hooks + ACP`), which contains
Lifecycle Hooks (matches `"hooks"`) and Multi-Agent (matches
`"multi-agent"`, `"acp"`). So Storage feature 36 gets phase-inferred
deps to every Lifecycle Hooks and Multi-Agent feature.

The bug class became reachable when explicit `<feature depends_on>`
edges were added to the parser (commits `3cbf8ea`, `f17afbd`, `59d33eb`).
Before that, all edges came from phase inference and were uniform.
Now explicit and inferred edges can disagree across phase boundaries
and close cycles.

## Design Decisions

### Decision 1: Remove the middle-phase fallback

When a category's words don't intersect any phase title, **infer no deps**
for features in that category. Foundation features with no predecessor
phase don't get arbitrary edges to whatever happens to sit in the
predecessor of the middle phase.

**Trade-off considered:** A narrower fix (cycle filter alone, keep the
fallback) was rejected. It would preserve the heuristic that silently
surprised the user here and is likely to surprise others next time.
Removing the fallback makes the contract explicit: keyword match → inferred
deps; no match → declare explicitly.

**Backward compatibility:** specs whose unmatched-keyword features
currently get arbitrary middle-phase predecessor deps will get `[]` after
this change. In practice those inferred deps were already nonsense; we
expect this to remove bogus deps, not real ones. One existing test
(`test_unmatched_features_go_to_middle_phase`) pins the buggy behavior
and gets rewritten.

### Decision 2: Cycle filter as defense in depth

Even with Decision 1, cycles can still form via explicit cross-phase
backward edges (e.g., a feature in matched-phase P3 declares
`depends_on=` pointing to a feature in P5; inference for a P6 feature
then adds an edge to that P5 feature, closing a cycle if the P3 feature
was the original target).

After dep assignment, build the full graph (explicit ∪ inferred), DFS for
cycles, and drop any **inferred** edge that closes one. **Explicit edges
are sacred** — if the user authored an explicit cycle, the existing
`Scheduler.validate_no_cycles()` catches it downstream with a clear
error. We never silently drop user intent.

### Decision 3: Validator Gap 9 + `/fix-spec` rule

A feature whose category falls through to the new no-inference path may
have wanted predecessors — the user just didn't declare them. We can't
know what they meant, but we can surface the situation so they decide:

**Layer 4 Gap 9** (`check_unmatched_phase_inference`): fires per-feature
when (a) the spec has ≥ 2 `<implementation_steps>` phases, (b) the feature
has empty `depends_on_indices`, and (c) the feature's category words don't
intersect any phase title. Severity: WARNING default, ERROR under
`--strict-shape`.

**`/fix-spec` auto-fix**: for non-first features in such categories, add
`depends_on="<prev-index-in-same-category>"` (matches the dominant pattern
in user-authored specs). For first-in-category features, route to the
Manual Review block — that's a foundation feature and only the user
knows whether it should have cross-category predecessors.

## Implementation Components

### 1. Parser (`claw_forge/spec/parser.py`)

Modify `_assign_dependencies` (lines 618-651):

- **A**: delete the `if not assigned: mid = ...; phase_feature_indices[mid].append(i)` branch. Unmatched features simply don't enter `phase_feature_indices`.
- **B**: add cycle-safe filter at the end. Track which edges per feature are inferred vs explicit. Build adjacency list. For each inferred edge `(i, dep)` in stable order: if `dep` can reach `i` in the current graph (ignoring the edge under test), drop the inferred edge. Use simple DFS reachability — O(N·E), acceptable for ≤ ~1000 features.

Caller at `parser.py:382-388` is unchanged: explicit deps still short-circuit inference per-feature.

### 2. Validator (`claw_forge/spec/validator.py`)

Add `check_unmatched_phase_inference(feat, phases, *, strict)` alongside the
other Gap checks. Hooks into `run_shape_checks` via a new per-feature loop.
`run_shape_checks` already accepts a `project_root` parameter; add a
`phases: list[str] | None = None` parameter and thread it through from
`validate_spec()` (which already calls `ProjectSpec.from_file()` and has
access to the parsed phases — needs to be exposed on `ProjectSpec`).

Plumbing change: `ProjectSpec` likely needs an
`implementation_phases: list[str]` field (currently the phases list is
local to `from_xml`/`from_file`). Verify during plan-writing.

Add `Gap 9` constants (vocabulary not required — pure category-vs-phase
comparison).

### 3. `/fix-spec` (`.claude/commands/fix-spec.md`)

Append Gap 9 row to the Layer 4 fix table with the rule from Decision 3.
Add a worked example showing before/after with `depends_on=` populated
from the prior feature in the same category. Add the "first in category"
case to the Manual Review block with three candidate fixes:

- (a) Declare it a foundation feature (no deps; leave empty).
- (b) Rename a phase title to include a category keyword.
- (c) Add cross-category `depends_on=` pointing at an appropriate predecessor.

### 4. Tests

`tests/spec/test_parser.py`:
- **Rewrite** `test_unmatched_features_go_to_middle_phase` →
  `test_unmatched_features_get_no_inferred_deps`. Same fixture, assert
  `result[1] == []`.
- **Add** `test_cycle_filter_drops_inferred_edge_closing_cycle`: 3-feature
  graph where inference would close a cycle; assert the inferred edge is
  dropped and the explicit edge survives.
- **Add** `test_cycle_filter_preserves_explicit_cycles`: user-declared
  explicit cycle (intentional error) is preserved verbatim.
- **Add integration** `test_meridian_shape_does_not_produce_cycle`:
  minimal XML modeled on the Meridian shape (Storage feature with no
  deps + Lifecycle Hooks feature with explicit `depends_on=` pointing
  back through Sessions/Harness). Parse, build scheduler, assert
  `validate_no_cycles()` does not raise.

`tests/spec/test_validator.py`:
- **Add** `test_gap9_unmatched_phase_inference_warning`.
- **Add** `test_gap9_promoted_to_error_under_strict_shape`.
- **Add** `test_gap9_quiet_when_feature_has_explicit_depends_on`.
- **Add** `test_gap9_quiet_when_no_implementation_steps`.
- **Add** `test_gap9_first_in_category_emits_distinct_suggestion`.

### 5. Docs

- **CLAUDE.md** — `spec/parser.py` section: describe the new contract.
  Layer 4 validator gap list: add Gap 9.
- **`.claude/commands/fix-spec.md`** — updated as part of Component 3.

## Out of Scope

- Replacing the keyword-overlap matcher with a smarter category-to-phase
  classifier (e.g., LLM-driven). The keyword matcher works correctly when
  the user names phases with category keywords; the bug was the silent
  fallback, not the matcher itself.
- Auto-renaming phase titles to maximize keyword coverage.
- Surfacing the cycle filter's actions in `claw-forge plan` output
  (we drop inferred edges silently; explicit edges always survive).
  If a future user reports confusion, we can add a debug-level log.

## Migration Notes

Specs with unmatched-keyword categories that previously got middle-phase
fallback deps will now get `[]`. Most affected specs will benefit (those
bogus deps were a hidden source of scheduling slowdowns and the cycle
class). Specs that genuinely relied on the fallback chain can rename a
phase title to restore the old behavior, or declare `depends_on=`
explicitly — `claw-forge validate-spec` will tell them which features
are now uninferred via Gap 9.

## Success Criteria

1. `claw-forge run` against the user's Meridian spec no longer raises
   `CycleDetectedError`.
2. The rewritten `test_unmatched_features_get_no_inferred_deps` passes.
3. All new tests pass.
4. Coverage stays ≥ 90% (CI gate).
5. Running `claw-forge validate-spec --strict-shape` on the Meridian spec
   reports Gap 9 ERRORs for the three (or however many) currently-affected
   features.
6. `/fix-spec` run on the Meridian spec auto-fixes the non-first-in-category
   cases and leaves the first-in-category ones in the Manual Review block
   with the right candidate-fix wording.
