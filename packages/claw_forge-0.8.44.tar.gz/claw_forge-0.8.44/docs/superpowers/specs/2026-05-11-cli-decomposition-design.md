# cli.py Decomposition Design

**Date:** 2026-05-11
**Status:** Draft — awaiting user approval before plan
**Author:** Brainstormed with Claude (Opus 4.7)

## Problem

`claw_forge/cli.py` is 5236 lines, holding 17 top-level Typer commands plus ~25 module-private helpers. Two concrete consequences:

1. **LLM context cost:** No agent (including this one) can hold the whole file in working memory. Edits to one command require reasoning that spills into unrelated commands sharing the file.
2. **Mixed concerns:** State-service HTTP plumbing, config loading, session resolution, scaffolding, sandbox-settings selection, DB schema migration, plan serialisation, and the orchestrator wiring all live side-by-side in one module. The `run` command alone is ~2400 lines (lines 603–2998) and tangles dispatcher setup, task-handler closure, signal handlers, periodic-checkpoint loop, and finalisation.

5 subapps have already been peeled off into domain packages (`boundaries/cli.py`, `git/cli.py`, `git/stash_cli.py`, `training/cli.py`, top-level `export_cli.py`). The remaining 17 commands have not.

## Goal

Decompose `cli.py` such that:

- **Every resulting file is small enough to reason about in one LLM context** — soft target ≤800 lines, hard target ≤1200 for the absolute biggest module.
- **Commands live next to the code they exercise** — extending the existing pattern of the 5 already-extracted subapps, not introducing a parallel `cli/` package.
- **Test imports keep working without modification.** Tests import 9 symbols from `claw_forge.cli`; `cli.py` becomes a thin shim that re-exports them so test code is untouched.
- **Behaviour is unchanged.** No new features, no logic edits beyond what falls out of moving code. The 90 % branch-coverage gate must stay green throughout.

## Non-Goals

- No refactoring of `run`'s internal logic beyond extracting the `task_handler` closure into a top-level coroutine (which falls out naturally from cross-file moves — closures don't cross module boundaries cleanly).
- No reorganisation of the 5 already-extracted subapps.
- No changes to the Typer CLI surface — every `claw-forge <command>` invocation behaves identically.
- No test rewrites. Tests may be updated in a follow-up PR; this work keeps imports stable.
- No documentation changes beyond what's strictly necessary (CLAUDE.md architecture section update to reflect new file locations).

## Design

### Target file map — all 17 commands

| Command(s) | Target file | Rationale |
|---|---|---|
| `version` | `claw_forge/cli.py` (residue) | No domain, ~5 lines, stays as the residue. |
| `status` | `state/cli.py` (new) | Queries state-service `/sessions/.../tasks`; state-client. |
| `state` | `state/cli.py` | Manages the state service itself. |
| `pause`, `resume`, `input`, `add` | `state/cli.py` | All hit `/sessions/{id}/tasks/...` — state-service-client commands. |
| `init` | `claw_forge/cli.py` (residue) | Scaffolds `claw-forge.yaml`; calls `scaffold.py`. Small enough to stay in residue. |
| `plan`, `validate-spec`, `import` | `spec/cli.py` (new) | All consume/produce `app_spec.{txt,xml}` via `spec/parser.py` and `spec/validator.py`. |
| `merge` | `git/merge_cli.py` (new, sibling to existing `worktrees` and `stash` subapps in the `git/` package) | Manual squash-merge of feature branches; same domain as worktrees but a separate subapp file mirroring the `git/stash_cli.py` precedent. |
| `pool_status` | `pool/cli.py` (new) | Queries `pool/manager.py`; lives next to its data source. |
| `fix` | `bugfix/cli.py` (new) | The `bugfix/` package already owns the implementation; mirror pattern. |
| `ui`, `dev` | `ui_cli.py` (new top-level, mirrors `export_cli.py`) | No `ui/` package exists (only `ui_dist/` build artifact); single-file module is correct. |
| `run` | `orchestrator/run_cli.py` (new) + helpers (see below) | Biggest command, only one that fragments further. |

Result: residue `cli.py` shrinks to `version` + `init` + Typer app assembly + `add_typer` wiring + back-compat shim re-exports. Estimated ≤300 lines.

### The `run` command (special case)

`run` is the only command that decomposes across multiple files. Its current ~2400 lines split as:

| Concern | New location | Approx. size |
|---|---|---|
| `run()` Typer command — arg parsing, top-level coordination, dispatcher loop | `orchestrator/run_cli.py` | ~600–800 lines |
| The per-task lifecycle (currently the `task_handler` closure) — promoted to top-level `async def` taking explicit deps | `orchestrator/task_handler.py` | ~800–1000 lines |
| SIGTERM/SIGINT handler installation + `_active_worktrees` registry | `orchestrator/signals.py` | ~80 lines |
| Periodic auto-checkpoint asyncio loop | `orchestrator/checkpointing.py` | ~120 lines |
| `_create_and_sync_worktree`, `_try_claim_files`, `_resolve_sdk_credentials`, `_set_merged_after_merge`, `_migrate_schema` | `orchestrator/task_handler.py` (same file, called from there) | folded into above |

**Why promote `task_handler` from closure to top-level coroutine.** A closure captures the entire surrounding `run()` scope by reference. Crossing a module boundary requires either (a) moving the whole `run()` along with it — defeats decomposition — or (b) converting captured locals into explicit parameters. Option (b) is the standard fall-out and makes the dependencies inspectable, which is the long-term shape we want anyway. This counts as the "small refactor that falls out naturally" the user authorised in Question 1 / Option B.

### Helper-extraction map

| Current `cli.py` symbol | New home | Notes |
|---|---|---|
| `_load_env_file`, `_expand_env_vars`, `_DEFAULT_CONFIG_YAML`, `_load_config`, `_scaffold_config` | **`claw_forge/config.py` (new)** | Config + env-loading domain doesn't exist yet; create it. |
| `_state_url`, `_http_get`, `_http_post`, `_port_in_use_error`, `_ensure_state_service` | **`state/client.py` (new)** | HTTP-client side of the state service (state-service-side already lives in `state/service.py`). |
| `_task_dict_to_node`, `_decorate_resumable` | `state/client.py` | API-dict → `TaskNode` conversion; co-locates with HTTP client. |
| `_list_sessions_for_help`, `_session_exists`, `_count_sessions_and_tasks`, `_print_session_hints`, `_resolve_project_root`, `_resolve_latest_session` | `state/client.py` | Session-resolution reads `.claw-forge/state.db` — sibling to HTTP client. |
| `_make_sdk_sandbox_settings` | `agent/sandbox.py` (existing) | Already the sandbox domain; helper joins it. |
| `_build_session_redirect_js` | `ui_cli.py` (new, where `ui` command lives) | Only used by the `ui` command. |
| `_write_plan_to_db` | `spec/cli.py` (new, where `plan` command lives) | Only used by the `plan` command; test-imported. |
| `_set_merged_after_merge`, `_migrate_schema` | `orchestrator/task_handler.py` (`_set_merged_after_merge`), `state/service.py` (`_migrate_schema`) | Merge-gating is task-handler concern; schema migration is service-side. |
| `_create_and_sync_worktree`, `_try_claim_files`, `_resolve_sdk_credentials` | `orchestrator/task_handler.py` | All used only by the task handler. |

### Back-compat shim — what `cli.py` re-exports

Tests import 9 symbols from `claw_forge.cli` (verified via `grep -rn "from claw_forge.cli import"` across `tests/`):

```python
# claw_forge/cli.py (residue, after extraction)
from claw_forge.config import (
    _DEFAULT_CONFIG_YAML,
    _load_config,
    _load_env_file,
)
from claw_forge.orchestrator.task_handler import _set_merged_after_merge
from claw_forge.spec.cli import _write_plan_to_db
from claw_forge.state.client import (
    _resolve_latest_session,
    _resolve_project_root,
    _task_dict_to_node,
)

__all__ = [
    "_DEFAULT_CONFIG_YAML", "_load_config", "_load_env_file",
    "_resolve_latest_session", "_resolve_project_root",
    "_set_merged_after_merge", "_task_dict_to_node",
    "_write_plan_to_db", "app",
]
```

Plus the public `app` (Typer app) and the `version` / `init` command definitions themselves. Test-side import statements stay identical; the indirection is invisible.

### Typer subapp wiring

Two patterns, one per kind of module:

**(A) Multi-command modules** — module defines its own `typer.Typer()` and registers commands on it; `cli.py` mounts with `add_typer(subapp)` *without* a `name=` so the commands surface as top-level. This is **not** the same as the 5 existing subapps (which use `name=` because they really are subcommand groups like `boundaries audit / apply / status`). Multi-command modules in this refactor:

- `state/cli.py` (6 commands: `status`, `state`, `pause`, `resume`, `input`, `add`)
- `spec/cli.py` (3 commands: `plan`, `validate-spec`, `import`)
- `ui_cli.py` (2 commands: `ui`, `dev`)

**(B) Single-command modules** — module just exposes the command *function* (decorated with no Typer instance); `cli.py` registers it directly with `app.command()(fn)`. Avoids the `add_typer(x, name="run")` → `claw-forge run run` trap. Single-command modules in this refactor:

- `orchestrator/run_cli.py` → `run` function
- `git/merge_cli.py` → `merge` function
- `bugfix/cli.py` → `fix` function
- `pool/cli.py` → `pool_status` function (registered as `claw-forge pool-status`)

Final `cli.py` wiring block:

```python
# Existing subapps — true subcommand groups, mounted with name=
from claw_forge.boundaries.cli import boundaries_app
from claw_forge.export_cli import export_app
from claw_forge.git.cli import worktrees_app
from claw_forge.git.stash_cli import stash_app
from claw_forge.training.cli import traces_app

app.add_typer(boundaries_app, name="boundaries")
app.add_typer(export_app, name="export")
app.add_typer(worktrees_app, name="worktrees")
app.add_typer(stash_app, name="stash")
app.add_typer(traces_app, name="traces")

# New multi-command modules — top-level commands grouped by domain, mounted without name=
from claw_forge.spec.cli import spec_app
from claw_forge.state.cli import state_app
from claw_forge.ui_cli import ui_app

app.add_typer(spec_app)
app.add_typer(state_app)
app.add_typer(ui_app)

# New single-command modules — register the function directly
from claw_forge.bugfix.cli import fix as _fix_cmd
from claw_forge.git.merge_cli import merge as _merge_cmd
from claw_forge.orchestrator.run_cli import run as _run_cmd
from claw_forge.pool.cli import pool_status as _pool_status_cmd

app.command(name="run")(_run_cmd)
app.command(name="merge")(_merge_cmd)
app.command(name="fix")(_fix_cmd)
app.command(name="pool-status")(_pool_status_cmd)

# Residue commands — defined in cli.py itself
@app.command()
def version() -> None: ...

@app.command()
def init(...) -> None: ...
```

**Why two patterns instead of one.** Forcing single-command modules through a wrapper `Typer()` adds ceremony with no payoff — the wrapper exists solely to be `add_typer(x)`'d into the parent, which is exactly what `app.command()(fn)` does in one line. Conversely, multi-command modules (`state_app` with 6 commands) genuinely benefit from grouping their decorations together inside the module rather than scattering 6 `app.command()(_x_cmd)` calls in `cli.py`. Each pattern matches the shape of what it's wiring.

**Naming decision for `git/` package — why `git/merge_cli.py` rather than folding `merge` into `git/cli.py`:** today `git/cli.py` exposes `worktrees_app` mounted at name `"worktrees"` as a true subcommand group (`worktrees list`, `worktrees prune`). Folding `merge` into the same file would force one of:

- (i) Add `merge` as a subcommand of `worktrees` → breaks the public surface (`claw-forge worktrees merge` instead of `claw-forge merge`).
- (ii) Rename `worktrees_app` to a generic `git_app` mounted at name `"git"` → also breaks the public surface (`claw-forge git worktrees list`).
- (iii) Expose two separate Typer subapps from `git/cli.py` → works but conflates a subcommand group (worktrees) and a single command (merge) in one file.

`git/merge_cli.py` as a sibling file mirrors the existing `git/stash_cli.py` precedent exactly, keeps `claw-forge merge` as a top-level command (zero CLI breakage), and keeps each file's responsibility narrow.

### New modules introduced

```
claw_forge/
  config.py                      # NEW — _load_env_file, _expand_env_vars, _load_config, _DEFAULT_CONFIG_YAML, _scaffold_config
  ui_cli.py                      # NEW — ui_app: ui + dev commands, _build_session_redirect_js
  bugfix/
    cli.py                       # NEW — bugfix_app: fix command
  orchestrator/
    run_cli.py                   # NEW — run_app: run command (arg-prep + dispatcher loop)
    task_handler.py              # NEW — per-task coroutine + agent prep helpers
    signals.py                   # NEW — emergency-commit handlers + _active_worktrees registry
    checkpointing.py             # NEW — periodic auto-checkpoint asyncio task
  pool/
    cli.py                       # NEW — pool_app: pool-status command
  spec/
    cli.py                       # NEW — spec_app: plan + validate-spec + import commands, _write_plan_to_db
  state/
    cli.py                       # NEW — state_app: status + state + pause + resume + input + add commands
    client.py                    # NEW — _http_get, _http_post, _state_url, session-resolution helpers, _task_dict_to_node, _decorate_resumable
  git/
    merge_cli.py                 # NEW — merge_app: merge command
```

### Implementation order (light — full plan in next step)

The work slices into ~7 PRs, ordered low-risk-first. Each slice keeps tests + coverage green standalone.

1. **Helpers first** — `config.py` and `state/client.py` extraction; cli.py shims them. No command moves.
2. **Sandbox + small helpers** — `_make_sdk_sandbox_settings` → `agent/sandbox.py`; `_migrate_schema` → `state/service.py`.
3. **Tiny commands** — `state/cli.py` (status, state, pause, resume, input, add).
4. **Spec commands** — `spec/cli.py` (plan, validate-spec, import, `_write_plan_to_db`).
5. **Misc commands** — `pool/cli.py` (pool-status), `bugfix/cli.py` (fix), `git/merge_cli.py` (merge), `ui_cli.py` (ui, dev).
6. **`run` extraction** — `orchestrator/{run_cli,task_handler,signals,checkpointing}.py`. Highest blast radius; do last when everything else is stable.
7. **Final residue cleanup** — confirm `cli.py` is ≤300 lines and re-exports cleanly; update `CLAUDE.md` architecture section.

Each PR must:
- Run `uv run pytest tests/ -q --cov=claw_forge` with `fail_under=90` green.
- Run `uv run ruff check claw_forge/ tests/` clean.
- Run `uv run mypy claw_forge/ --ignore-missing-imports` with no new errors.
- Manually exercise the touched commands at least once (`claw-forge <cmd> --help` minimum; full invocation for non-trivial commands like `run`).

### Risks & mitigations

| Risk | Mitigation |
|---|---|
| Circular imports — e.g., `state/client.py` imports `state/scheduler.py` which imports `state/models.py`; the run-loop pulls in `orchestrator/`, which imports `state/client.py`. | Keep `state/client.py` dependency-light (stdlib + `httpx` + `state/scheduler.TaskNode`). Defer heavyweight imports (e.g., `agent/runner`) behind function-local imports as needed. The existing `if TYPE_CHECKING` guard in `cli.py` for `GitOps` and `TaskNode` is a precedent. |
| Coverage drop — moving lines without moving the tests that exercise them can land with coverage redistributed unevenly. | After each PR slice, run `--cov-report=term-missing` and verify each new module hits its own coverage. If a slice drops below 90 % overall, add unit tests for the extracted helper before merging. |
| `run` closure-to-top-level conversion introduces parameter bugs — the `task_handler` closure captures ~15+ locals (scheduler, session_id, console, config, git_ops, project_dir, etc.). | Promote in two steps inside the same PR: (a) gather all captured locals into a `RunContext` dataclass passed explicitly; (b) move `task_handler` to its own file taking `RunContext` as its single arg. Smaller diff per step, easier review. |
| Test-import shim drift — over time, contributors might add new tested helpers to extracted modules and forget to re-export from `cli.py`. | Add a one-line test that asserts `from claw_forge.cli import ...` succeeds for every symbol in `__all__`. Cheap, catches accidents. |
| Hidden coupling — a helper currently inside `cli.py` may be called from another module via internal import we haven't seen. | Pre-extraction sweep: `grep -rn "from claw_forge.cli import" claw_forge/` before each slice (not just `tests/`). |
| CLAUDE.md architecture section becomes stale — current section references "`claw_forge/cli.py` — 18+ commands". | Final PR updates that section to reflect the new package map. |

### Verification

The decomposition is successful when:

1. `wc -l claw_forge/cli.py` ≤ 300 lines.
2. No file under `claw_forge/` exceeds 1200 lines (target ≤800; `orchestrator/task_handler.py` may approach the cap).
3. `uv run pytest tests/ -q --cov=claw_forge` passes with `fail_under=90` unchanged.
4. `uv run ruff check claw_forge/ tests/` and `uv run mypy claw_forge/ --ignore-missing-imports` both clean.
5. `claw-forge --help` shows the same command list; every command's `--help` output is byte-identical to pre-refactor (modulo ordering — Typer sorts subapps by registration order, which we preserve).
6. A smoke-test `claw-forge run` against a small spec completes end-to-end without behaviour change.

## Out of Scope (Explicit)

- Refactoring `run`'s internal logic beyond closure→top-level conversion. The 2400 lines remain 2400 lines, just spread across 4 files in `orchestrator/`.
- Renaming any command or changing any CLI flag.
- Updating any test file imports — the shim handles compatibility.
- Adding new tests beyond the import-shim assertion.
- Moving the 5 already-extracted subapps.
- Bumping the version in `pyproject.toml` (per project convention — version is set by the publish workflow from the release tag).

## Open Questions

None — every architectural sub-decision has been made (the user authorised YOLO for sub-decisions after locking the high-level shape).
