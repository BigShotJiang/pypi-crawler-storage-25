# Autonomous merge-conflict recovery

**Status:** Draft → implementing
**Authors:** Bowen Li + Claude (claude-opus-4-7)
**Date:** 2026-05-10
**Target version:** v0.8.23
**Spec scope:** runtime behaviour only — no new modules, no resolver subsystem.

## Problem

Two failure modes today require human intervention even though every primitive needed to fix them autonomously is already in the harness.

### Failure mode A — squash-merge fails after agent completion

`apply_on_completion` calls `squash_merge`; on conflict (e.g. an alembic migration filename collision because another task landed `0006_*.py` while this task was running) the result is `{"merged": False}`. Today's handler (`_set_merged_after_merge` in `cli.py:2993`) records `error_message="merge_failed: ..."` and leaves the task in `status="completed"` with `merged_to_target_branch=0`. The branch + worktree are preserved, the operator is expected to resolve manually with `git -C <project> merge --squash <branch>`.

This is what produced the floorplan-confirm-north-arrow case in fengshui that motivated this spec — task `f4dff812` sat in `completed + merged=0` for 2 days, blocking dependents.

### Failure mode B — pre-dispatch sync hits a conflict

`_create_and_sync_worktree` calls `sync_worktree_with_target` to catch the resumed worktree up to `target` before the agent runs. On conflict, today's path (`cli.py:1620-1665`) PATCHes the task to `failed` with a `resume_conflict:` error message and skips agent dispatch entirely. The worktree is preserved for manual resolution.

### Common shape

In both cases, the agent never gets a chance to resolve the conflict — even though the agent already has Read/Edit/Bash tools and can run the project's test suite, which are exactly the primitives needed for resolution. The harness stops short of dispatching the agent into the conflict-bearing state.

## Non-goals

- A separate conflict-resolver subsystem (deterministic registry + LLM advisor + 3-layer fallback). Earlier exploration considered this; we rejected it because it duplicates capabilities the agent already has.
- Replacing the test gate. Resolutions still get judged by the project's existing test command via the agent's own normal post-edit verification.
- General-purpose AI conflict resolution outside the agent loop.

## Design

Three coordinated changes. All bounded by a per-task retry counter so a pathological case can't loop forever; the irreducible fallback is today's preserve-and-warn behaviour.

### Change 1 — squash failure re-pends the task

When `apply_on_completion` reports `{"merged": False}` for a task whose agent completed successfully, the harness re-pends the task instead of leaving it terminal.

**Schema:**
- New column on `Task`: `merge_retry_count: Mapped[int]` (default `0`, server_default `"0"`).
- New config key: `git.merge_retry_attempts` (default `3`).
- New error-message convention: `merge_retry_<N>: <reason>` (preserves the `merge_failed:` prefix at the cap so existing tooling that scans for that prefix keeps working).

**Behaviour in `_set_merged_after_merge`:**

```
if not merge_result["merged"]:
    if task.merge_retry_count + 1 < config.git.merge_retry_attempts:
        PATCH status="pending"
        PATCH merge_retry_count = current + 1
        PATCH error_message = f"merge_retry_{current + 1}: {reason}"
        return {"re_pended": True}     # signal outer loop
    else:
        # cap hit — fall through to today's behaviour
        PATCH error_message = f"merge_failed: {reason} (after {N} attempts)"
        return {"re_pended": False}
```

The squash failure path in `squash_merge` does NOT call `remove_worktree()`, so the worktree is already preserved on disk. `prefer_resumable: true` (default on) means the next dispatch picks the re-pended task up first within its priority tier.

**Outer-loop integration:**

The dispatcher's outer wave-loop (`cli.py:2486-2492`) computes `_new_pending` from DB by filtering `t["id"] not in total_completed`. A re-pended task IS in `total_completed` (the agent succeeded; the dispatcher recorded it). To allow re-entry without weakening the protection for genuinely-completed tasks:

```python
# Defined alongside _active_worktrees in the dispatcher closure
_pending_merge_retries: set[str] = set()

# task_handler captures the re-pend signal
result = await _set_merged_after_merge(...)
if result.get("re_pended"):
    _pending_merge_retries.add(task_node.id)

# Outer loop, after dispatcher.run() returns:
for tid in _pending_merge_retries:
    total_completed.pop(tid, None)
_pending_merge_retries.clear()
# Then existing _new_pending filter computes the next wave
```

Each re-entry consumes one slot from the merge-retry budget; at the cap, the task stays `completed + merged=0` per today's behaviour.

### Change 2 — sync-conflict dispatches the agent into the conflicted state

When `sync_worktree_with_target` returns `{"synced": False, "conflicts": [...]}`, the harness leaves the conflict markers in the worktree and dispatches the agent with a conflict-aware preamble — instead of failing the task and stopping.

**Primitive change:** `sync_worktree_with_target` gains a `leave_conflicts: bool = False` keyword argument:

```python
def sync_worktree_with_target(
    worktree_path: Path,
    target: str = "main",
    *,
    leave_conflicts: bool = False,
) -> dict[str, Any]:
    ...
    except subprocess.CalledProcessError:
        conflicts = sorted(
            _run_git(["diff", "--name-only", "--diff-filter=U"], worktree_path).stdout.splitlines()
        )
        if not leave_conflicts:
            with suppress(Exception):
                _run_git(["merge", "--abort"], worktree_path)
            with suppress(Exception):
                _run_git(["reset", "--hard", "HEAD"], worktree_path)
        return {"synced": False, "conflicts": conflicts, "left_in_place": leave_conflicts}
```

Default `False` preserves byte-for-byte behaviour for every existing caller. The dispatcher passes `True` so the conflict markers stay in the worktree for the agent to resolve.

**Dispatcher change:** When sync fails with conflicts AND merge_retry_count < cap, instead of PATCHing failed, set `merge_retry_count` and continue to agent dispatch with a conflict preamble. When at cap OR sync fails with `dirty_worktree`, fall through to today's behaviour (PATCH failed with `resume_conflict:` and skip agent).

```python
if not _sync.get("synced"):
    _conflict_files = _sync.get("conflicts", [])
    _dirty = _sync.get("dirty_worktree", False)
    _retry_eligible = (
        not _dirty
        and _conflict_files
        and task_data.get("merge_retry_count", 0) + 1 < merge_retry_attempts
    )
    if _retry_eligible:
        # Re-call sync with leave_conflicts=True so markers stay in place
        await git_ops.sync_worktree(_worktree_path, target=_default_branch, leave_conflicts=True)
        # Bump retry count on the task; agent dispatch proceeds with conflict-aware preamble
        new_count = task_data.get("merge_retry_count", 0) + 1
        await _patch_task(http, task_node.id, merge_retry_count=new_count)
        _conflict_recovery_files = _conflict_files  # picked up by preamble below
    else:
        # Today's path — PATCH failed, skip agent
        ...
```

### Change 3 — resume preamble surfaces merge conflict context

When `_conflict_recovery_files` is set OR `error_message` starts with `merge_retry_`, the resume preamble (`cli.py:1803-1851`) gets an extra section that explicitly tells the agent it's in a conflict-recovery scenario and what tools it has:

```markdown
## Merge Conflict Recovery (CRITICAL)

The catch-up merge of `main` into your branch produced conflicts in:
- migrations/versions/0006_floorplans.py
- app/models/__init__.py

Resolve them in this worktree:
1. For migration filename collisions: renumber to the next free slot under `migrations/versions/` and update `down_revision` to point at the current alembic head.
2. For ordinary code conflicts: edit the conflicted files, remove `<<<<<<<`, `=======`, `>>>>>>>` markers, choose the correct merge.
3. Stage and commit the resolution: `git add <files> && git commit -m "merge: resolve conflicts with main"`.
4. Run the project's test command and ensure it passes before finishing.
5. Continue with the original task as needed.

This is attempt N of M. If the squash-merge to `main` fails again after your work, the task will be retried up to the cap; after the cap, the task is preserved for human resolution.
```

The original task prompt is appended after the resume preamble so the agent knows what feature it was working on.

### Change 4 — Validator Gap 8 defaults to ERROR

`spec/validator.py:check_migration_shape_candidate` flips its default severity from WARNING to ERROR. A new flag `--allow-soft-migration-shape` (and config key `validation.allow_soft_migration_shape: false`) preserves the old WARNING behaviour for migration on-ramp.

```python
def check_migration_shape_candidate(
    feat: FeatureItem, *, strict: bool, allow_soft: bool = False,
) -> ValidationIssue | None:
    ...
    if feat.shape == "core":
        return None
    description_lower = feat.description.lower()
    if not any(token in description_lower for token in MIGRATION_INDICATORS):
        return None
    severity = IssueSeverity.WARNING if allow_soft else IssueSeverity.ERROR
    return ValidationIssue(...)
```

**Rationale:** Gap 8 catches the exact upstream cause of the floorplan failure — two parallel tasks with `migration` in their description, neither annotated `shape="core"`, both pick `0006_*.py`. Promoting to ERROR by default eliminates the failure class at parse time. The `--strict-shape` flag continues to govern Gaps 3, 5, 6 (shape-overlap warnings) — those remain default-WARNING because they're heuristic. Gap 8 is precise enough to be ERROR.

## Configuration

```yaml
git:
  merge_retry_attempts: 3              # cap for squash + sync auto-retry; 0 disables

validation:
  allow_soft_migration_shape: false    # true keeps Gap 8 at WARNING (migration on-ramp)
```

CLI flag mirror:
- `claw-forge validate-spec --allow-soft-migration-shape` (one-shot override).

## Backward compatibility

- Existing specs **without `shape="core"` on migration features** will fail validation. This is intentional — the spec calls this out as the migration trigger. Operators get a clear error message + auto-fix suggestion in the existing Gap 8 output. The escape hatch is `--allow-soft-migration-shape`.
- Existing tasks in DB without `merge_retry_count` get `0` from `_migrate_schema` ALTER TABLE — same pattern as `bugfix_retry_count`.
- All `sync_worktree_with_target` callers pass no `leave_conflicts` argument and continue to behave exactly as today.
- `_set_merged_after_merge`'s contract is extended (returns `{"re_pended": bool}`) but legacy code that ignores the return value (calls it and discards) keeps working.
- The dispatcher's existing `resume_conflict:` path is preserved — it fires at the merge-retry cap or on dirty worktree, exactly as today.

## Testing

For each change, one happy-path test + one edge-case test + the cap-enforcement test:

| Change | Tests |
|---|---|
| 1 (re-pend on squash fail) | re-pend happens with retry_count<cap; cap-hit leaves task at completed+merged=0; total_completed sidecar removal works in re-dispatch |
| 2 (sync leaves conflicts) | `leave_conflicts=True` keeps markers in worktree; `leave_conflicts=False` (default) still aborts; dispatcher dispatches agent on conflict when budget remains |
| 3 (preamble) | preamble inserted when `merge_retry_count > 0`; preamble includes file list when `_conflict_recovery_files` set |
| 4 (Gap 8 ERROR) | default-ERROR returned; `allow_soft=True` returns WARNING; CLI flag wires through; existing strict-shape tests pass unchanged |

Coverage gate (90%) must hold.

## Open questions resolved during writing

- **Q: Does the agent need explicit instruction on alembic renumber, or trust general capability?** A: Explicit instruction in the preamble. The harness already injects role-specific skills via `run_agent`'s auto-skill matcher; one more sentence of in-prompt guidance is cheap insurance.
- **Q: Should `merge_retry_count` reset on successful merge?** A: No — keep the historical record. A future `claw-forge export training` may want it as a feature for distillation.
- **Q: What if the agent resolves conflict but introduces regression?** A: Same risk class as any agent task. Squash will succeed if tests pass; if tests fail mid-resolution, that's the agent's normal failure handling.

## File-touch summary

| File | Change |
|---|---|
| `claw_forge/state/models.py` | + `merge_retry_count` column on `Task` |
| `claw_forge/cli.py` | extend `_migrate_schema` with new column; modify `_set_merged_after_merge` to re-pend; thread `_pending_merge_retries` set in dispatcher closure; modify sync-conflict path to dispatch with conflict preamble; add merge-conflict preamble |
| `claw_forge/git/merge.py` | + `leave_conflicts` kwarg on `sync_worktree_with_target` |
| `claw_forge/spec/validator.py` | flip Gap 8 default to ERROR; + `allow_soft` parameter |
| `claw_forge/cli.py` (validate-spec) | + `--allow-soft-migration-shape` flag |
| `claw_forge/state/service.py` | accept `merge_retry_count` in PATCH /tasks/{id} |
| `tests/git/test_merge.py` | sync_worktree leave_conflicts tests |
| `tests/test_cli_commands.py` | _set_merged_after_merge re-pend tests |
| `tests/spec/test_validator.py` | Gap 8 default-ERROR tests |
| `CLAUDE.md`, `README.md`, `docs/commands.md` | doc updates |

Estimated diff: <500 lines, no new modules.
