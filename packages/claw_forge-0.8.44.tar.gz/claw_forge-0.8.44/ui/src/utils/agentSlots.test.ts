/**
 * Regression tests for agent slot allocation in the activity log.
 *
 * Live-mode bug repro from a real fengshui session:
 *  - claw-forge.yaml ``max_concurrency: 2``
 *  - 14 distinct task_ids appeared in agent_log over the session
 *  - Several tasks went through ``running → failed → pending →
 *    running → completed`` retry cycles (autonomous merge-recovery)
 *  - UI showed ``agent #3`` and higher in the activity log even
 *    though no more than 2 tasks were ever concurrent
 *
 * Root cause: when a task is re-dispatched after a terminal state,
 * its slot map entry was deleted on the terminal transition.  If
 * both concurrent slots are held by other tasks at the moment of
 * re-dispatch, ``allocateSlot`` returns ``nextSlot++`` which
 * exceeds the configured concurrency.
 *
 * The ``regression_*`` tests use ``it.fails(...)`` — vitest's "expected
 * to fail" marker — so the CI suite stays green while the bug is
 * documented.  When the slot allocator is fixed to bound peak slots
 * by concurrency, ``it.fails`` itself will fail (the body no longer
 * throws), forcing the fixer to flip the assertion back to ``it(...)``
 * and pin the corrected behaviour.
 */
import { describe, expect, it } from "vitest";

import {
  allocateSlot,
  createSlotState,
  freeSlot,
  peakSlot,
} from "./agentSlots";

describe("agentSlots — clean scenarios (no retries)", () => {
  it("two concurrent tasks → max slot = 2", () => {
    const s = createSlotState();
    const a = allocateSlot(s, "A");
    const b = allocateSlot(s, "B");
    expect([a, b].sort()).toEqual([1, 2]);
    expect(peakSlot(s)).toBe(2);
  });

  it("sequential tasks with proper free → slot 1 is reused", () => {
    const s = createSlotState();
    allocateSlot(s, "A"); // slot 1
    freeSlot(s, "A");
    const b = allocateSlot(s, "B");
    expect(b).toBe(1); // reused from freeSlots
    expect(peakSlot(s)).toBe(1);
  });

  it("concurrency=2 with 4 staggered tasks → max slot stays at 2", () => {
    const s = createSlotState();
    allocateSlot(s, "A"); // 1
    allocateSlot(s, "B"); // 2
    freeSlot(s, "A"); // freeSlots=[1]
    allocateSlot(s, "C"); // 1 (reused)
    freeSlot(s, "B"); // freeSlots=[2]
    allocateSlot(s, "D"); // 2 (reused)
    expect(peakSlot(s)).toBe(2);
  });

  it("allocating same task_id twice returns the same slot", () => {
    const s = createSlotState();
    const first = allocateSlot(s, "A");
    const second = allocateSlot(s, "A");
    expect(first).toBe(second);
    expect(peakSlot(s)).toBe(1);
  });

  it("free on unknown task_id is a no-op", () => {
    const s = createSlotState();
    allocateSlot(s, "A");
    expect(() => freeSlot(s, "Z")).not.toThrow();
    expect(s.slotMap.get("A")).toBe(1);
  });

  it("freeSlots stays sorted ascending so allocation picks the lowest", () => {
    const s = createSlotState();
    allocateSlot(s, "A"); // 1
    allocateSlot(s, "B"); // 2
    allocateSlot(s, "C"); // 3
    freeSlot(s, "B"); // slotMap.size=2, freeSlots=[2]
    expect(s.slotMap.size).toBe(2);
    expect(s.freeSlots).toEqual([2]);
    freeSlot(s, "A"); // slotMap.size=1, freeSlots=[1,2]
    expect(s.freeSlots).toEqual([1, 2]);
    const d = allocateSlot(s, "D");
    expect(d).toBe(1); // lowest first
  });

  it("freeSlot resets nextSlot when slotMap empties (between-batch idle reset)", () => {
    // Pins the "agent #11 with concurrency=2" regression: after a
    // dispatch batch completes (all slots freed), the allocator
    // resets so the next batch starts at slot 1.  Without the reset,
    // nextSlot accumulates monotonically and a long-running session
    // displays lane numbers far above the configured concurrency.
    const s = createSlotState();
    allocateSlot(s, "A"); // 1
    allocateSlot(s, "B"); // 2
    allocateSlot(s, "C"); // 3 — simulates a brief race over the cap
    freeSlot(s, "A"); // slotMap.size=2
    freeSlot(s, "B"); // slotMap.size=1
    expect(s.nextSlot).toBe(4); // no reset while map non-empty
    freeSlot(s, "C"); // slotMap.size=0 → reset
    expect(s.slotMap.size).toBe(0);
    expect(s.freeSlots).toEqual([]);
    expect(s.nextSlot).toBe(1);
    // Next allocation starts fresh
    const d = allocateSlot(s, "D");
    expect(d).toBe(1);
  });
});

describe("agentSlots — between-batch reset (the 'agent #11 with concurrency=2' fix)", () => {
  it("after every active slot is freed, the next batch starts at slot 1", () => {
    // Reproduces the operator-observed pattern from a fengshui session
    // with max_concurrency=2: 14 distinct task_ids accumulated agent_log
    // entries over the session's lifetime.  The fix has two prongs:
    //   1. ``useWebSocket.rowToEntry`` (hydration) sets ``agentIndex:
    //      undefined`` — historical entries don't allocate lanes.
    //   2. ``freeSlot`` resets nextSlot when slotMap empties — so the
    //      next live batch starts fresh at slot 1.
    // This test pins (2) directly.  Prong (1) is enforced in the hook.
    const CONCURRENCY = 2;
    const s = createSlotState();

    // Batch 1: two tasks, completed normally.
    allocateSlot(s, "task-a"); // 1
    allocateSlot(s, "task-b"); // 2
    freeSlot(s, "task-a");
    freeSlot(s, "task-b");
    expect(s.nextSlot).toBe(1); // reset fired

    // Batch 2: should start at slot 1, not slot 3.
    const x = allocateSlot(s, "task-x");
    const y = allocateSlot(s, "task-y");
    expect(x).toBe(1);
    expect(y).toBe(2);
    expect(peakSlot(s)).toBeLessThanOrEqual(CONCURRENCY);
  });
});

describe("agentSlots — regression: retry after terminal state breaks concurrency bound", () => {
  it.fails("regression_concurrency_violated_on_retry_when_slots_busy", () => {
    // Concurrency=2.  Reproduces the live-mode pattern observed in the
    // fengshui session (status sequence "running → failed → pending →
    // running → completed", with other tasks consuming the freed slot
    // in the meantime).
    const CONCURRENCY = 2;
    const s = createSlotState();

    // 1. Initial fan-out: tasks A and B start concurrently.
    allocateSlot(s, "A"); // slot 1
    allocateSlot(s, "B"); // slot 2

    // 2. Task A hits a transient failure → autonomous merge-recovery
    //    flips A's status to "failed".  UI frees slot 1.
    freeSlot(s, "A"); // freeSlots=[1]

    // 3. Dispatcher's next wave-loop iteration picks task C (a fresh
    //    pending task, NOT a retry of A).  C grabs slot 1 from freeSlots.
    allocateSlot(s, "C"); // slot 1 — freeSlots now empty

    // 4. Merge-retry sidecar re-pends A.  Dispatcher re-claims A and
    //    its agent emits agent_log again.  At THIS moment, B and C
    //    are still running (slots 2 and 1 held).  Concurrency=2, so
    //    the dispatcher should never run 3 agents — but the UI's
    //    slot allocator has no link to the dispatcher's pool and is
    //    free to over-allocate.
    const retrySlot = allocateSlot(s, "A");

    // The contract: peak slot ever assigned must not exceed configured
    // concurrency.  Anything higher means the activity log shows
    // ``agent #3`` / ``#4`` / ... even though only 2 agents are
    // configured to run.
    //
    // CURRENT BEHAVIOUR: retrySlot === 3, peakSlot(s) === 3.
    // EXPECTED BEHAVIOUR: retrySlot ≤ 2 (queue or reuse).
    //
    // This assertion FAILS today.  A future fix to the slot allocator
    // (queue retries until a slot frees, or have the UI listen to
    // dispatcher concurrency state) flips it green and pins the fix.
    expect(retrySlot).toBeLessThanOrEqual(CONCURRENCY);
    expect(peakSlot(s)).toBeLessThanOrEqual(CONCURRENCY);
  });

  it.fails("regression_peak_slot_unbounded_across_many_retries", () => {
    // Stronger statement of the same bug: across N retry cycles where
    // the freed slot is always claimed by a fresh task before the
    // retry lands, peak slot grows unboundedly.  Mirrors what a long-
    // running session sees in the wild.
    const CONCURRENCY = 2;
    const s = createSlotState();

    allocateSlot(s, "A"); // 1
    allocateSlot(s, "B"); // 2

    // 5 retry cycles, each time a "fresh" task grabs the freed slot.
    for (let i = 0; i < 5; i++) {
      freeSlot(s, "A");
      allocateSlot(s, `fresh-${i}`); // takes the slot A just freed
      allocateSlot(s, "A"); // A retries; no free slot available → nextSlot++
      freeSlot(s, `fresh-${i}`); // fresh task completes
    }

    // Bug-current value of peakSlot is 3 (the slot allocated on the first
    // retry; later retries reuse the freed slots from completed `fresh-*`
    // tasks).  Even one violation breaks the contract — the correct upper
    // bound is concurrency.
    expect(peakSlot(s)).toBeLessThanOrEqual(CONCURRENCY);
  });
});
