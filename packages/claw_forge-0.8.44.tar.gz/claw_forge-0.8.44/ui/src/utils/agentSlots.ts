/**
 * Pure helpers for allocating per-task "agent slot" indices in the
 * activity log.
 *
 * Each running task gets a small 1-based integer (its slot number),
 * which the UI surfaces as ``agent #N`` in the activity log.  Slots
 * are reused: when a task reaches a terminal state, its slot is
 * pushed back into the free pool and the next new task picks the
 * lowest free slot before falling back to a fresh allocation.
 *
 * Extracted from `useWebSocket.ts` so the allocation contract can be
 * tested without a React harness.  The hook constructs a single
 * ``AgentSlotState`` at mount time and threads it through every
 * agent_log / feature_update event.
 *
 * **Known limitation pinned by ``agentSlots.test.ts``:** when a task
 * re-runs after a terminal state (e.g. ``running → failed → pending
 * → running`` from autonomous merge-recovery), its old slot has been
 * freed.  If both concurrent slots are now held by other tasks, the
 * re-running task gets ``nextSlot++``, breaking the invariant
 * "peak slot ≤ configured concurrency".  See the failing test
 * ``regression_concurrency_violated_on_retry_when_slots_busy`` for
 * a deterministic repro.
 */

export interface AgentSlotState {
  /** task_id → 1-based slot number for currently-allocated tasks. */
  slotMap: Map<string, number>;
  /** Slots that have been freed and are available for reuse,
   *  kept sorted ascending so allocation prefers the lowest. */
  freeSlots: number[];
  /** Next slot to assign when no freed slots are available. */
  nextSlot: number;
}

/** Construct a fresh slot state.  Call once per UI session. */
export function createSlotState(): AgentSlotState {
  return {
    slotMap: new Map(),
    freeSlots: [],
    nextSlot: 1,
  };
}

/**
 * Return the slot number for `taskId`, allocating one on first use.
 *
 * If `taskId` is already in the slot map, the existing slot is returned
 * unchanged.  Otherwise the lowest freed slot is reused, or a brand-new
 * slot is assigned via post-increment of ``nextSlot``.
 */
export function allocateSlot(state: AgentSlotState, taskId: string): number {
  const existing = state.slotMap.get(taskId);
  if (existing !== undefined) return existing;

  const slot =
    state.freeSlots.length > 0
      ? state.freeSlots.shift()!
      : state.nextSlot++;
  state.slotMap.set(taskId, slot);
  return slot;
}

/**
 * Free the slot currently held by `taskId`, if any.  No-op when the
 * task is not in the slot map.
 *
 * Call this from feature_update handlers when a task transitions to
 * a terminal status (``completed`` or ``failed``).  Do NOT call on
 * ``paused`` — late agent_log events can still arrive during the
 * cancellation window and would re-allocate a phantom slot.
 *
 * When the map empties (no active tasks), the allocator state is
 * reset to its initial form.  Without this, ``nextSlot`` grows
 * monotonically over the session's lifetime — and after a dispatch
 * batch completes plus the next one starts, fresh tasks are labelled
 * ``agent #N`` for whatever ``nextSlot`` reached during the prior
 * batch, even if only 2 tasks are concurrent.
 */
export function freeSlot(state: AgentSlotState, taskId: string): void {
  const slot = state.slotMap.get(taskId);
  if (slot === undefined) return;
  state.slotMap.delete(taskId);
  state.freeSlots.push(slot);
  state.freeSlots.sort((a, b) => a - b);

  if (state.slotMap.size === 0) {
    state.freeSlots.length = 0;
    state.nextSlot = 1;
  }
}

/** Peak slot number ever assigned by this state.  Useful for
 *  asserting "max agent_index ≤ configured concurrency" in tests. */
export function peakSlot(state: AgentSlotState): number {
  return state.nextSlot - 1;
}
