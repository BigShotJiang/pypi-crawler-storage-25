"""Rate limit detection and backoff utilities."""
from __future__ import annotations

import random
import re

RATE_LIMIT_PATTERNS = [
    r"rate.?limit",
    r"too many requests",
    r"429",
    r"quota exceeded",
    r"capacity exceeded",
    r"overloaded",
    r"529",
]

# Provider-side transient error patterns — broader set used by the
# dispatcher's rotation logic.  Decision boundary:
#
#   * Rotate when "this PROVIDER can't service this request" —
#     transient infrastructure (rate-limits, 5xx, network) AND
#     per-provider configuration problems (auth, expired tokens,
#     org-not-allowed).  Another provider in the pool may be fine.
#   * Fail fast when "this REQUEST is broken" — malformed input,
#     content-policy refusal, agent-internal logic bugs, sandbox
#     denials.  Rotating just wastes other providers' quota because
#     they would reject the same way.
#
# v0.8.25 shipped the rate-limit/5xx/network set; v0.8.27 adds the
# auth-credential set after seeing OAuth misconfiguration on one
# provider fail the whole task even with two healthy providers in the
# pool.  Auth errors are deliberately per-provider — bad credentials
# on Anthropic don't say anything about whether the OpenAI-compatible
# fallback works.  Conservative on ambiguous cases: 403 / "forbidden"
# is excluded because it's commonly a content-moderation refusal
# (not provider-rotatable), and 400 / "bad request" is excluded
# because it indicates a malformed payload.
PROVIDER_TRANSIENT_PATTERNS = [
    *RATE_LIMIT_PATTERNS,
    # HTTP 5xx — server is down/overloaded; another provider's
    # backend won't be (probably).
    r"\b50[0234]\b",  # 500, 502, 503, 504
    r"internal server error",
    r"bad gateway",
    r"service unavailable",
    r"gateway timeout",
    # Network-level failures — DNS, TCP, TLS — all suggest the
    # current provider's endpoint is unreachable from here.
    r"connection refused",
    r"connection reset",
    r"connection (?:error|aborted|closed)",
    r"name (?:or service not known|resolution)",
    r"network (?:is )?unreachable",
    r"\btimeout\b",
    r"timed out",
    r"read error",
    # Generic provider/upstream wrapper errors emitted by gateways,
    # proxies, and the SDK itself when it can't reach the backend.
    r"upstream",
    r"provider error",
    r"\bapi error\b",
    # Auth-credential errors (v0.8.27) — per-provider configuration
    # problems where the request is fine but THIS provider can't
    # honour it.  Another provider in the pool may have working
    # creds.  Includes both Anthropic-style API-key errors and the
    # OAuth-token errors emitted by ``claude login``.
    r"oauth_org_not_allowed",
    r"oauth_token_invalid",
    r"oauth.*not[_ ]allowed",
    r"invalid[_ ]?api[_ ]?key",
    r"authentication[_ ]?(?:error|failed)",
    r"\bauth[_ ]error\b",
    r"\b401\b",
    r"\bunauthorized\b",
    # v0.8.42 — SDK-internal transient failure markers.  When the SDK
    # itself reports the failure (rather than a backend HTTP error),
    # the error text often lacks the classic ``500`` / ``timeout`` /
    # ``rate limit`` keywords above — but the SDK markers below are
    # equally strong rotation signals: a stream that idled or partially
    # completed, or the agent producing literally zero output, both
    # indicate the current provider failed to service this request.
    # Real-world trigger: meridian task ``8c400669`` (2026-05-20) hit
    # ``Stream idle timeout`` followed by ``msg.error = "unknown"``;
    # without these patterns the wrapper ``"Agent error: unknown — ..."``
    # didn't classify as retryable and rotation never fired.
    r"stream idle",
    r"stream error",
    r"partial response",
    r"produced no output",
    # Bare ``Agent error: unknown`` from the dispatcher's wrapper is
    # also a rotation signal — the SDK admitting it doesn't know what
    # failed strongly suggests something at the provider layer broke
    # (network, auth re-handshake, model server reset).  Conservative
    # without the wrapper, retryable when the dispatcher produces it.
    r"agent error: unknown",
]


def is_rate_limit_error(text: str) -> bool:
    """Check if an error message indicates a rate limit."""
    t = text.lower()
    return any(re.search(p, t) for p in RATE_LIMIT_PATTERNS)


def is_retryable_provider_error(text: str) -> bool:
    """Check if an error is provider-side and worth a rotation retry.

    Broader than ``is_rate_limit_error`` — used by the dispatcher
    (``cli.py`` ``_run_task``) to decide whether an SDK exception
    warrants rotating to a fresh provider.  Returns True for:

      * Rate-limits / quota / overload (the original
        ``RATE_LIMIT_PATTERNS``).
      * HTTP 5xx server errors (``500``, ``502``, ``503``, ``504``,
        ``"internal server error"``, ``"bad gateway"``, etc.).
      * Network-level failures (timeouts, connection refused/reset,
        DNS resolution).
      * Generic provider / upstream / API-wrapper errors that
        suggest the request never reached the backend cleanly.
      * **Auth-credential errors** (v0.8.27): ``oauth_org_not_allowed``,
        ``invalid_api_key``, ``authentication_error``, ``401``,
        ``unauthorized``.  These are per-provider config problems —
        the request is fine but THIS provider can't honour it; the
        next provider in the pool may have working credentials.

    Returns False for errors that won't change with a different
    provider — malformed input, content-moderation refusals (403 /
    "forbidden"), agent runtime errors, sandbox denials.  Rotating
    in those cases wastes other providers' quota because they would
    reject the same way.

    Conservative when uncertain: an error text that doesn't match
    any pattern returns False (no rotation), so the task fails
    fast on truly unrecoverable errors instead of cycling through
    the pool pointlessly.
    """
    t = text.lower()
    return any(re.search(p, t) for p in PROVIDER_TRANSIENT_PATTERNS)


def parse_retry_after(text: str) -> int | None:
    """Extract retry-after seconds from error text."""
    m = re.search(r"retry.?after[:\s]+(\d+)", text, re.I)
    if m:
        return int(m.group(1))
    m = re.search(r"(\d+)\s*seconds?", text, re.I)
    if m:
        return int(m.group(1))
    return None


def clamp_retry_delay(seconds: int, min_s: int = 5, max_s: int = 3600) -> int:
    """Clamp a retry delay to reasonable bounds."""
    return max(min_s, min(max_s, seconds))


def calculate_rate_limit_backoff(
    attempt: int, base: float = 60.0, max_s: float = 900.0
) -> int:
    """Exponential backoff with jitter for rate limits."""
    delay = base * (2**attempt) + random.uniform(0, 10)
    return int(min(delay, max_s))


def calculate_error_backoff(
    attempt: int, base: float = 5.0, max_s: float = 300.0
) -> int:
    """Linear backoff for non-rate-limit errors."""
    return int(min(base * attempt, max_s))
