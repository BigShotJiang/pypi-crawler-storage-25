"""Scrub well-known macOS-libsystem chatter from tool_result text (v0.8.43).

When the dispatcher runs inside Cursor's integrated terminal, Cursor's
``ms-python.debugpy`` extension auto-attaches its debugger to every
Python subprocess spawned by the agent's Bash tool (via a shim in PATH:
``noConfigScripts/debugpy``).  On macOS the debug attachment's teardown
calls ``turn_off_stack_logging()`` defensively — but ``MallocStackLogging``
was never enabled in the child, so ``libsystem_malloc.dylib`` prints
the harmless noise::

    python3(8267) MallocStackLogging: can't turn off malloc stack
    logging because it was not enabled.

That line leaks into the child's stderr → the ``ToolResultBlock.content``
the agent receives → activity log (Kanban UI) + ``agent_log`` events
(state DB) + exported training corpus.  Zero learning signal, pure
pollution.

This module provides ``scrub_macos_noise(text)`` — a conservative regex
pass that strips only the patterns we've actually seen in the wild.
Used by:

* ``orchestrator/task_handler.py`` — before writing ``tool_result``
  content into the activity log (so the Kanban UI is clean).
* ``training/recorder.py`` — before serializing tool_result content
  into the ``agent_message`` event payload (so the training corpus
  is clean).

The scrubber is idempotent and preserves all non-matching text exactly.
"""

from __future__ import annotations

import re

# Patterns to strip.  All anchored to start-of-line (with ``^`` under
# ``re.MULTILINE``) so a stray fragment in normal text doesn't trigger
# accidental scrubbing.  Each pattern matches the WHOLE line including
# the trailing newline so we don't leave behind blank-line residue.
_MACOS_NOISE_PATTERNS: tuple[str, ...] = (
    # libsystem_malloc cleanup chatter from Cursor's debugpy shim.
    # ``can't`` may use straight (') or curly (’) apostrophe depending on
    # the macOS version's libsystem_malloc.dylib build.
    r"^.*MallocStackLogging:\s*can[\'’]t turn off.*$\n?",
    # Network-stack chatter from macOS Network framework — appears
    # when tests open sockets and the OS attempts wake-from-sleep
    # configuration on a TCP socket that doesn't support it.
    r"^.*nw_protocol_socket_set_no_wake_from_sleep.*$\n?",
)

_COMPILED_PATTERNS = tuple(
    re.compile(p, flags=re.MULTILINE) for p in _MACOS_NOISE_PATTERNS
)


def scrub_macos_noise(text: str) -> str:
    """Remove well-known macOS-libsystem noise lines from *text*.

    Idempotent: scrubbing twice yields the same result as scrubbing
    once.  Non-matching text is preserved byte-for-byte (modulo the
    final ``.strip()`` which trims leading/trailing whitespace).

    When the input is pure noise the output is the empty string.
    """
    if not text:
        return text
    for pattern in _COMPILED_PATTERNS:
        text = pattern.sub("", text)
    return text.strip()
