"""OS-level filesystem jail per agent process (v0.8.18 Level 2).

The architectural step beyond v0.8.17's snapshot-rollback.  v0.8.17
*detects and recovers* from leaks; this module makes leaks
*physically impossible* by wrapping the agent's ``claude`` CLI
subprocess in a kernel-enforced sandbox where writes outside the
worktree return ``EACCES``.

## HOME-protection (v0.8.33)

The v0.8.18 → v0.8.32 profile used ``(allow default)`` + a single
deny against the parent project — strong protection for the project
working tree, but the agent could still write anywhere outside it
(``~/.npm``, ``~/.ssh``, shell rc files, ``~/Library/LaunchAgents``).
This is the npm-supply-chain blast radius: a malicious package's
``postinstall`` script runs as the npm child process, not as a
Bash command our hook can intercept, so static command-arg checks
can't stop it.

v0.8.33 adds targeted deny rules for the highest-value persistence
and credential-theft targets in ``$HOME``.  Gated by the
``home_protection`` flag (default True) so operators can disable
it if a legitimate task needs to write to one of the protected
paths.  The block list is intentionally narrow — credential stores,
shell init files, macOS persistence dirs, package-manager caches.
``~/.claude`` is NOT protected (the SDK uses it).

Why this matters: the v0.8.16 layers (file-tool sandbox, exempt-
command jail check, system-prompt directive) each block one
escape pattern.  v0.8.17 captures the leftovers.  None of them stop
a determined or dynamically-built escape (``python -c "open('/abs',
'w')…"``, ``os.system('git -C /...')``, FFI through ctypes).  The
OS sandbox closes that gap at the syscall level — no user-space
guess-the-pattern logic is needed because the kernel itself denies
the write.

## OS support

  * **macOS**: ``sandbox-exec(1)`` with a generated profile that
    denies ``file-write*`` to the parent project's canonical path,
    with a carve-out allowing writes under the worktree.  The
    canonical-path resolution is critical — ``/tmp`` is a symlink to
    ``/private/tmp`` and the sandbox kernel hook compares against
    the resolved path; using the symlink path silently makes the
    deny rule non-matching.

  * **Linux** (v0.8.21): ``bwrap(1)`` (bubblewrap) with
    ``--dev-bind / /`` then ``--ro-bind`` on the parent project then
    ``--bind`` on the worktree.  Each later operation overlays the
    earlier one at the same subpath, so the project becomes read-only
    *except* under the worktree where the rebind makes it writable
    again.  Same end effect as macOS: writes outside the worktree
    fail at ``open(2)`` with ``EROFS`` (read-only filesystem).

  * **Other platforms** (Windows, BSD): no sandbox available.  The
    dispatcher logs at ``warning`` level and falls back to the
    behavioural-only stack (Layers 1–3 + snapshot-rollback).  The
    user-visible promise downgrades from "leaks impossible" to
    "leaks contained, work preserved in stash".

## Usage

The dispatcher generates a per-task wrapper script in the worktree's
``.claw-forge/`` dir, points ``ClaudeAgentOptions.cli_path`` at it,
and the SDK invokes the wrapper instead of the bare ``claude``
binary.  The wrapper sets up the sandbox and ``exec``s the real
``claude`` with the SDK's args intact.
"""
from __future__ import annotations

import logging
import os
import platform
import shutil
import stat
from pathlib import Path
from typing import Any

_log = logging.getLogger(__name__)


# ── HOME-protection target lists (v0.8.33) ───────────────────────────────────

# Directories under ``$HOME`` that an agent should never write to.  Each
# entry is interpreted as a subpath — the deny rule covers every file
# beneath it.  Reads are still allowed (the agent may legitimately need
# to read ``~/.aws/credentials`` for a deploy task, etc.); only writes
# are blocked.  Adding to this list is safe; removing items weakens the
# default and should be justified.
_HOME_PROTECTED_SUBPATHS: tuple[str, ...] = (
    ".ssh",                       # SSH keys + authorized_keys persistence
    ".aws",                       # AWS credentials + config
    ".gnupg",                     # PGP keys
    ".config/gh",                 # GitHub CLI auth
    ".docker",                    # Docker registry auth
    ".kube",                      # kubeconfig (cluster creds)
    ".npm",                       # npm cache (poisoning surface)
    ".cache",                     # generic cache root (persistence vector)
    ".pnpm-store",                # pnpm content-addressed package store
    ".yarn",                      # yarn cache + state
    "Library/LaunchAgents",       # macOS user-level launchd persistence
    "Library/LaunchDaemons",      # macOS system-loaded persistence
    "Library/Application Support/com.apple.backgroundtaskmanagementagent",
)

# Specific files (not directories) that should never be written to.
# Use ``literal`` matching on macOS for these so a sibling file at the
# same prefix isn't accidentally captured.
_HOME_PROTECTED_FILES: tuple[str, ...] = (
    ".bashrc", ".bash_profile", ".bash_login", ".profile",
    ".zshrc", ".zprofile", ".zlogin", ".zshenv",
    ".npmrc", ".yarnrc", ".yarnrc.yml", ".pnpmrc",
    ".gitconfig",                  # global git config — could redirect remotes
    ".netrc",                      # plaintext HTTP creds
)

# System-wide persistence locations outside ``$HOME``.  Already protected
# by Unix file permissions (need root to write), but defence-in-depth.
_SYSTEM_PROTECTED_SUBPATHS: tuple[str, ...] = (
    "/Library/LaunchAgents",      # macOS host-wide launchd
    "/Library/LaunchDaemons",     # macOS host-wide launchd (root)
    "/etc/cron.d",                # Linux cron drop-in
    "/etc/cron.daily", "/etc/cron.hourly", "/etc/cron.weekly",
    "/etc/systemd/system",        # Linux systemd unit drop-in
)


def _resolved_home() -> Path | None:
    """Return the canonical path to the user's home dir, or None.

    Wrapped so the sandbox builder can degrade gracefully when ``$HOME``
    is unset (e.g. nosuid /etc/passwd lookup failures in odd container
    runtimes) — we'd rather emit a profile without HOME rules than
    crash the agent dispatch.
    """
    home = os.environ.get("HOME", "")
    if not home:
        return None
    try:
        return Path(home).resolve()
    except OSError:
        return None


def is_sandbox_available() -> tuple[bool, str]:
    """Return ``(available, mechanism)``.

    ``mechanism`` is ``"sandbox-exec"`` on macOS when the binary is
    on PATH, ``"bwrap"`` on Linux when bubblewrap is installed, or
    ``"none"`` when no sandbox is available on this OS.  The
    dispatcher uses the mechanism string for log/warning output so
    operators know which OS path is in effect.
    """
    system = platform.system()
    if system == "Darwin":
        return (shutil.which("sandbox-exec") is not None, "sandbox-exec")
    if system == "Linux":
        return (shutil.which("bwrap") is not None, "bwrap")
    return (False, "none")


def _resolve_git_common_dir(
    worktree_path: Path, project_canonical: Path,
) -> Path | None:
    """Return the canonical path to the **shared** git common dir.

    A linked worktree at ``<project>/.claw-forge/worktrees/<slug>``
    shares its object store, refs, hooks, and config with the parent
    project's ``.git/`` directory.  A single ``git commit`` writes to
    THREE places in that shared dir:

    - ``<git_common>/worktrees/<slug>/`` — per-worktree state (``HEAD``,
      ``index``, ``index.lock``, ``logs/``).
    - ``<git_common>/objects/`` — new blob/tree/commit objects (the
      shared object database).
    - ``<git_common>/refs/`` and ``<git_common>/HEAD`` — branch tip
      updates land in the shared ref store.

    Carving out only the per-worktree metadata isn't enough — the
    object-store write fails with ``error: unable to create temporary
    file: Operation not permitted`` and the commit aborts.  The carve-
    out must cover the entire common dir.

    This is consistent with claw-forge's existing trust model: the
    agent already runs ``git`` via the sandbox-exempt Bash path
    (``permissions.py:SANDBOX_EXEMPT_COMMANDS``) and can therefore
    already mutate refs/objects via ``git update-ref``, ``git push
    --force``, etc.  The OS sandbox is preventing accidental
    file-level leaks to the parent project's *working tree*, not
    locking down git's *internal* state.

    Discovery, in order of preference:

    1. Read ``<worktree>/.git`` (a one-line text file
       ``gitdir: <abs path to metadata>`` for linked worktrees) and
       walk up two levels: ``metadata.parent.parent`` is the common
       dir.  Authoritative.
    2. Fall back to ``<project_canonical>/.git`` — the default for
       claw-forge-created worktrees in a standard repo layout.

    Returns ``None`` only when neither path exists on disk; the caller
    treats that as "no carve-out needed" (e.g. project not yet
    git-init'd; main worktree where ``.git`` is the common dir
    itself and the agent is sandboxed to its working subtree).
    """
    git_pointer = worktree_path / ".git"
    if git_pointer.is_file():
        try:
            content = git_pointer.read_text(encoding="utf-8").strip()
        except OSError:
            content = ""
        prefix = "gitdir:"
        if content.startswith(prefix):
            metadata = Path(content[len(prefix):].strip())
            # metadata = <common>/worktrees/<slug>; common = parent.parent
            common = metadata.parent.parent
            if common.exists():
                return common.resolve()

    # Fallback: the default location for claw-forge worktrees in a
    # standard non-bare repo.
    candidate = project_canonical / ".git"
    if candidate.exists():
        return candidate.resolve()
    return None


def _macos_sandbox_profile(
    *,
    project_canonical: Path,
    worktree_canonical: Path,
    git_common_dir: Path | None = None,
    home_protection: bool = True,
    home_dir: Path | None = None,
) -> str:
    """Generate a macOS sandbox-exec profile.

    The profile is **default-allow** (``(allow default)``) with a
    targeted ``deny file-write*`` against the parent project, then
    two carve-outs:

    1. ``allow file-write*`` for the worktree subtree (since the
       worktree is at ``<project>/.claw-forge/worktrees/<slug>``,
       the deny would otherwise also block legitimate worktree writes).
    2. ``allow file-write*`` for git's per-worktree metadata dir at
       ``<project>/.git/worktrees/<slug>/`` — without this carve-out,
       *any* ``git`` invocation inside the worktree fails because git
       can't write its own ``index.lock`` / ``HEAD`` / ``index``.
       v0.8.18 → v0.8.25 shipped without this carve-out and produced
       ``fatal: Unable to create '...index.lock': Operation not
       permitted`` errors as soon as the agent ran any git command.

    When ``home_protection`` is True (v0.8.33 default), additional
    deny rules cover credential stores, shell init files, and
    macOS persistence dirs inside ``$HOME``.  These rules go AFTER
    the worktree allow (which is at the project subpath and disjoint
    from HOME) but are themselves last-wins for HOME paths — nothing
    later re-allows them.

    All paths MUST be canonical (``Path.resolve()``).  macOS sandbox
    compares against canonicalised paths internally — a profile
    referencing ``/tmp/foo`` silently doesn't match writes to
    ``/private/tmp/foo`` (which the kernel sees), and the rule
    becomes a no-op without any error.

    Path values are interpolated as scheme strings; we don't escape
    embedded quotes because filesystem paths shouldn't contain ``"``.
    If they do, the profile is malformed and ``sandbox-exec`` fails
    fast at startup — the dispatcher catches the failure and falls
    back to non-sandboxed mode with a logged warning.
    """
    lines = [
        "(version 1)",
        "(allow default)",
        f'(deny file-write* (subpath "{project_canonical}"))',
        f'(allow file-write* (subpath "{worktree_canonical}"))',
    ]
    if git_common_dir is not None:
        lines.append(
            f'(allow file-write* (subpath "{git_common_dir}"))',
        )
    if home_protection:
        resolved_home = home_dir or _resolved_home()
        if resolved_home is not None:
            for sub in _HOME_PROTECTED_SUBPATHS:
                target = (resolved_home / sub).resolve()
                lines.append(
                    f'(deny file-write* (subpath "{target}"))',
                )
            for filename in _HOME_PROTECTED_FILES:
                target = (resolved_home / filename).resolve()
                lines.append(
                    f'(deny file-write* (literal "{target}"))',
                )
        for system_path in _SYSTEM_PROTECTED_SUBPATHS:
            lines.append(
                f'(deny file-write* (subpath "{system_path}"))',
            )
    return "\n".join(lines) + "\n"


def write_macos_sandbox_wrapper(
    *,
    project_path: Path,
    worktree_path: Path,
    output_dir: Path,
    claude_path: Path,
    home_protection: bool = True,
) -> Path:
    """Write a sandbox-exec wrapper script + profile to *output_dir*.

    Returns the absolute path to the wrapper script, suitable for
    ``ClaudeAgentOptions.cli_path``.  The SDK invokes the wrapper
    with claude's CLI args; the wrapper exec's the real ``claude``
    binary under the sandbox-exec'd profile so the agent's tool
    invocations (Bash, Write, subprocess via FFI) all inherit the
    jail.

    The profile + wrapper are written into ``output_dir`` (typically
    ``<worktree>/.claw-forge/sandbox/``) so they're scoped to the
    task's lifetime and cleaned up when the worktree is removed.

    ``home_protection`` (v0.8.33, default True): also deny writes to
    credential stores and persistence dirs in ``$HOME``.  See module
    docstring for the rationale.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    project_canonical = project_path.resolve()
    worktree_canonical = worktree_path.resolve()
    profile_path = output_dir / "sandbox.sb"
    profile_path.write_text(
        _macos_sandbox_profile(
            project_canonical=project_canonical,
            worktree_canonical=worktree_canonical,
            git_common_dir=_resolve_git_common_dir(
                worktree_canonical, project_canonical,
            ),
            home_protection=home_protection,
        ),
    )

    # ``exec`` so the wrapper doesn't sit as a parent process
    # consuming a PID slot — the SDK's process tree is shallower this
    # way and signals from the dispatcher reach the real claude
    # process directly.
    wrapper_path = output_dir / "claude_sandboxed"
    wrapper_path.write_text(
        '#!/bin/bash\n'
        f'exec /usr/bin/sandbox-exec -f "{profile_path}" '
        f'"{claude_path}" "$@"\n'
    )
    # Make executable for owner + group + others (the SDK might run
    # as a different effective user than the wrapper-writer in some
    # CI/container setups).
    wrapper_path.chmod(
        wrapper_path.stat().st_mode
        | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH,
    )
    return wrapper_path


def _linux_bwrap_args(
    *,
    project_canonical: Path,
    worktree_canonical: Path,
    git_common_dir: Path | None = None,
    home_protection: bool = True,
    home_dir: Path | None = None,
) -> list[str]:
    """Generate ``bwrap`` CLI args for the Linux Layer 4 jail (v0.8.21).

    Strategy mirrors the macOS sandbox-exec profile shape:

      1. ``--dev-bind / /`` mounts the host root with full device
         access — claude needs to read system tools (``/usr``,
         ``/etc``), write to ``/tmp`` and ``~/.claude/``, etc.
      2. ``--ro-bind <project> <project>`` overlays the parent
         project as read-only.  Later operations at this subpath
         override earlier ones, so the parent project becomes
         read-only despite the broader ``--dev-bind / /``.
      3. ``--bind <worktree> <worktree>`` overlays the worktree
         (a subpath of project) as writable, carving out the
         exception just like the macOS profile's allow-after-deny
         rule.
      4. ``--bind <project>/.git/worktrees/<slug> <…>`` (v0.8.26)
         carves out git's per-worktree metadata dir as writable
         — without this, *any* ``git`` invocation inside the
         worktree fails because git can't write ``index.lock`` /
         ``HEAD`` / ``index``.  See the matching macOS carve-out
         for the symptoms before this fix landed.
      5. ``--ro-bind-try <home>/<protected> <…>`` (v0.8.33) for
         each HOME-protection target.  ``-try`` silently no-ops
         when the source path doesn't exist (e.g. user has no
         ``~/.aws``), so missing optional paths don't break
         dispatch.  Bind ordering matters here too: these come
         AFTER the broad ``--dev-bind / /`` so they override
         the writable mount for the protected subpaths.
      6. ``--chdir <worktree>`` sets the agent's cwd inside the
         sandbox to the worktree.

    All paths must be canonical (``Path.resolve()``) — bwrap
    follows symlinks at mount time, so a path containing a symlink
    behaves unpredictably across mount layers.  Same canonicalisation
    discipline as the macOS path.
    """
    args = [
        "--dev-bind", "/", "/",
        "--ro-bind", str(project_canonical), str(project_canonical),
        "--bind", str(worktree_canonical), str(worktree_canonical),
    ]
    if git_common_dir is not None:
        args.extend([
            "--bind",
            str(git_common_dir),
            str(git_common_dir),
        ])
    if home_protection:
        resolved_home = home_dir or _resolved_home()
        if resolved_home is not None:
            for sub in _HOME_PROTECTED_SUBPATHS:
                target = str((resolved_home / sub).resolve())
                args.extend(["--ro-bind-try", target, target])
            for filename in _HOME_PROTECTED_FILES:
                target = str((resolved_home / filename).resolve())
                args.extend(["--ro-bind-try", target, target])
        for system_path in _SYSTEM_PROTECTED_SUBPATHS:
            args.extend(["--ro-bind-try", system_path, system_path])
    args.extend(["--chdir", str(worktree_canonical)])
    return args


def write_linux_bwrap_wrapper(
    *,
    project_path: Path,
    worktree_path: Path,
    output_dir: Path,
    claude_path: Path,
    home_protection: bool = True,
) -> Path:
    """Write a bwrap wrapper script + record args for Linux v0.8.21.

    Returns the absolute path to the wrapper, suitable for
    ``ClaudeAgentOptions.cli_path``.  Symmetric counterpart to
    ``write_macos_sandbox_wrapper`` — same per-task lifecycle
    (written into the worktree's ``.claw-forge/sandbox/`` dir,
    cleaned up when the worktree is removed) and same SDK plumbing
    (``cli_path`` → wrapper → ``exec`` real claude under the jail).

    ``home_protection`` (v0.8.33, default True): also bind credential
    stores and persistence dirs in ``$HOME`` read-only.  See module
    docstring for the rationale.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    project_canonical = project_path.resolve()
    worktree_canonical = worktree_path.resolve()
    args = _linux_bwrap_args(
        project_canonical=project_canonical,
        worktree_canonical=worktree_canonical,
        git_common_dir=_resolve_git_common_dir(
            worktree_canonical, project_canonical,
        ),
        home_protection=home_protection,
    )
    # Persist the args alongside the wrapper for forensic inspection
    # — useful when a sandbox-related bug surfaces and the operator
    # needs to reproduce the exact bwrap invocation.
    args_path = output_dir / "bwrap_args.txt"
    args_path.write_text("\n".join(args) + "\n")

    quoted_args = " ".join(f'"{a}"' for a in args)
    wrapper_path = output_dir / "claude_sandboxed"
    wrapper_path.write_text(
        '#!/bin/bash\n'
        f'exec /usr/bin/bwrap {quoted_args} '
        f'"{claude_path}" "$@"\n'
    )
    wrapper_path.chmod(
        wrapper_path.stat().st_mode
        | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH,
    )
    return wrapper_path


def make_sandbox_wrapper(
    *,
    project_path: Path,
    worktree_path: Path,
    output_dir: Path,
    home_protection: bool = True,
) -> Path | None:
    """High-level entrypoint: build a sandbox wrapper for the current
    OS, or return ``None`` when no sandbox is available.

    The dispatcher calls this once per task right before constructing
    ``ClaudeAgentOptions``.  When ``None`` is returned, the dispatcher
    sets ``cli_path`` to its default (the bare ``claude`` binary) and
    relies on the v0.8.16 + v0.8.17 behavioural layers — leak
    prevention degrades to "contained + recovered", not "impossible".

    ``home_protection`` (v0.8.33, default True): also deny writes to
    credential stores and persistence dirs in ``$HOME``.  Set to
    False via ``agent.sandbox.home_protection: false`` in
    ``claw-forge.yaml`` for tasks that legitimately need to write
    to one of the protected paths.
    """
    available, mechanism = is_sandbox_available()
    if not available:
        _log.debug(
            "sandbox: no OS-level sandbox available (mechanism=%s); "
            "falling back to behavioural layers", mechanism,
        )
        return None
    claude_path = shutil.which("claude")
    if claude_path is None:
        _log.warning(
            "sandbox: ``claude`` CLI not on PATH — cannot wrap; "
            "falling back to behavioural layers",
        )
        return None

    if mechanism == "sandbox-exec":
        return write_macos_sandbox_wrapper(
            project_path=project_path,
            worktree_path=worktree_path,
            output_dir=output_dir,
            claude_path=Path(claude_path),
            home_protection=home_protection,
        )
    if mechanism == "bwrap":
        return write_linux_bwrap_wrapper(
            project_path=project_path,
            worktree_path=worktree_path,
            output_dir=output_dir,
            claude_path=Path(claude_path),
            home_protection=home_protection,
        )
    # No remaining branches — kept as a safety net in case
    # ``is_sandbox_available`` ever returns a new mechanism string.
    _log.warning(
        "sandbox: %s not yet implemented — falling back to "
        "behavioural-only stack",
        mechanism,
    )
    return None


def _make_sdk_sandbox_settings(*, isolation_active: bool) -> Any:
    """Build the SDK's per-Bash ``SandboxSettings`` respecting nested-
    sandbox prevention (v0.8.20 fix).

    The SDK invokes ``sandbox-exec`` (macOS) for each Bash subprocess
    when ``enabled=True``.  When our v0.8.18 Layer 4 wrapper or v0.8.19
    Layer 5 container is active, the entire ``claude`` process is
    already isolated at a broader scope — and macOS forbids nested
    ``sandbox_apply`` calls (kernel returns ``Operation not permitted``,
    ``sandbox-exec`` exits 71, the agent's Bash tool fails).

    When *isolation_active* is True, disable the SDK sandbox to avoid
    the nested-sandbox collision (our wrapper already covers the same
    ground at a broader scope, so nothing is lost).  Otherwise keep the
    SDK sandbox on as the only remaining bash isolation — relevant for
    platforms without Layer 4 or 5 (Windows, Linux pre-bwrap, sandbox
    binary missing).
    """
    from claude_agent_sdk.types import SandboxNetworkConfig, SandboxSettings
    return SandboxSettings(
        enabled=not isolation_active,
        autoAllowBashIfSandboxed=True,
        excludedCommands=["git"],
        allowUnsandboxedCommands=False,
        network=SandboxNetworkConfig(allowLocalBinding=True),
    )
