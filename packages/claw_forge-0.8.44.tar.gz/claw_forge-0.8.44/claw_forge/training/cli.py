"""Typer subapp: ``claw-forge traces [status|prune]``.

Inspect and prune the agent_message events captured by training-trace
recording. Reads ``.claw-forge/state.db`` directly via sqlite3 — no
state-service dependency, safe to run while a session is active.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

import typer

from claw_forge._console import console

traces_app = typer.Typer(
    help="Inspect and prune training-trace agent_message events.",
    no_args_is_help=True,
)



def _db_path(project: str) -> Path:
    return Path(project).resolve() / ".claw-forge" / "state.db"


@traces_app.command("status")
def status_cmd(
    project: str = typer.Option(".", "--project", "-p"),
) -> None:
    """Report agent_message event counts and DB size."""
    db = _db_path(project)
    if not db.exists():
        console.print(f"[red]✖  State DB not found at {db}[/red]")
        raise typer.Exit(1)
    conn = sqlite3.connect(str(db))
    try:
        total = conn.execute(
            "SELECT COUNT(*) FROM events WHERE event_type='agent_message'"
        ).fetchone()[0]
        per_session = conn.execute(
            "SELECT session_id, COUNT(*) FROM events "
            "WHERE event_type='agent_message' GROUP BY session_id"
        ).fetchall()
    finally:
        conn.close()

    db_mb = db.stat().st_size / (1024 * 1024)
    console.print(f"[bold]agent_message events:[/bold] {total}")
    console.print(f"[bold]state.db size:[/bold] {db_mb:.1f} MB")
    if per_session:
        console.print("[bold]Per session:[/bold]")
        for sid, count in per_session:
            console.print(f"  {sid}: {count}")


@traces_app.command("prune")
def prune_cmd(
    project: str = typer.Option(".", "--project", "-p"),
    before: str = typer.Option(
        "", "--before",
        help="ISO date — delete agent_message events older than this.",
    ),
    keep_last: int = typer.Option(
        0, "--keep-last",
        help="Keep only the N newest agent_message events; delete the rest.",
    ),
    session: str = typer.Option("", "--session"),
    all_: bool = typer.Option(
        False, "--all", help="Delete every agent_message event.",
    ),
    dry_run: bool = typer.Option(False, "--dry-run"),
    keep_completed: bool = typer.Option(
        False, "--keep-completed",
        help="Spare events from tasks where status='completed' AND merged_to_target_branch=1.",
    ),
) -> None:
    """Delete agent_message events under the configured criteria."""
    db = _db_path(project)
    if not db.exists():
        console.print(f"[red]✖  State DB not found at {db}[/red]")
        raise typer.Exit(1)
    if not (before or keep_last or session or all_):
        console.print(
            "[red]✖  Must pass one of --before / --keep-last / --session / --all[/red]"
        )
        raise typer.Exit(1)

    conn = sqlite3.connect(str(db))
    try:
        ids = _select_prune_ids(
            conn, before=before, keep_last=keep_last,
            session=session, all_=all_, keep_completed=keep_completed,
        )
        n = len(ids)
        if dry_run:
            console.print(f"[yellow]would delete {n} agent_message events[/yellow]")
            return
        if not ids:
            console.print("nothing to delete")
            return
        for i in range(0, n, 500):
            chunk = ids[i:i + 500]
            conn.execute(
                f"DELETE FROM events WHERE id IN ({','.join('?' * len(chunk))})",
                chunk,
            )
        conn.commit()

        # VACUUM only when reclaimable space is meaningful (>100 MB)
        free_pages = conn.execute("PRAGMA freelist_count").fetchone()[0]
        page_size = conn.execute("PRAGMA page_size").fetchone()[0]
        reclaimable_mb = (free_pages * page_size) / (1024 * 1024)
        if reclaimable_mb > 100:
            conn.execute("VACUUM")
            console.print(f"[dim]VACUUMed (reclaimed ~{reclaimable_mb:.0f} MB)[/dim]")
    finally:
        conn.close()
    console.print(f"[green]✓ deleted {n} agent_message events[/green]")


def _select_prune_ids(
    conn: sqlite3.Connection,
    *,
    before: str,
    keep_last: int,
    session: str,
    all_: bool,
    keep_completed: bool,
) -> list[int]:
    where = ["event_type='agent_message'"]
    args: list[Any] = []
    if before:
        where.append("created_at < ?")
        args.append(before)
    if session:
        where.append("session_id = ?")
        args.append(session)
    if keep_completed:
        where.append(
            "task_id NOT IN (SELECT id FROM tasks "
            "WHERE status='completed' AND merged_to_target_branch=1)"
        )
    # ``all_`` adds no extra filter; it's just the explicit "no other filter" path
    _ = all_
    sql = f"SELECT id FROM events WHERE {' AND '.join(where)} ORDER BY created_at"
    ids = [row[0] for row in conn.execute(sql, args)]
    if keep_last:
        keep_sql = (
            f"SELECT id FROM events WHERE {' AND '.join(where)} "
            f"ORDER BY created_at DESC LIMIT {int(keep_last)}"
        )
        keep_ids = {row[0] for row in conn.execute(keep_sql, args)}
        ids = [i for i in ids if i not in keep_ids]
    return ids
