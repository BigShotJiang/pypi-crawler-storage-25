"""Tee recorder: persist each SDK Message to the state-service events table.

Caller-side tap. Wrap an async iterator from ``run_agent()`` (or one of its
``collect_result`` / ``collect_structured_result`` callers) before consuming::

    stream = run_agent(prompt, ...)
    if dest is not None:
        stream = record_messages(stream, dest=dest)
    async for message in stream:
        ...

Best-effort by design — recorder failures never abort the agent.
"""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import httpx

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class RecordingDestination:
    """Where to send agent_message events.

    All three fields are required; absence of a destination means
    "don't record" (the wrapper is skipped at the call site).
    """

    session_id: str
    task_id: str
    state_url: str


async def record_messages(
    messages: AsyncIterator[Any],
    *,
    dest: RecordingDestination,
    client: httpx.AsyncClient | None = None,
) -> AsyncIterator[Any]:
    """Tee: POST each message to /events, then re-yield to caller.

    A connection / timeout error is caught and logged so a transient
    state-service hiccup never aborts an in-flight task.

    When ``client`` is None the recorder owns its httpx client and closes
    it on exit. When provided (e.g. by tests using ``ASGITransport``), the
    caller owns the client lifecycle.
    """
    own_client = client is None
    active: httpx.AsyncClient = client if client is not None else httpx.AsyncClient(timeout=5.0)
    try:
        turn = 0
        async for message in messages:
            try:
                payload = _serialize_message(message, turn=turn)
                await active.post(
                    f"{dest.state_url}/sessions/{dest.session_id}/events",
                    json={
                        "event_type": "agent_message",
                        "task_id": dest.task_id,
                        "payload": payload,
                    },
                )
            except Exception:
                log.warning(
                    "trace recording failed for task %s turn %d; continuing",
                    dest.task_id, turn, exc_info=True,
                )
            turn += 1
            yield message
    finally:
        if own_client:
            await active.aclose()


def _serialize_message(message: Any, *, turn: int) -> dict[str, Any]:
    """Serialize an SDK Message to a JSON-safe dict.

    Faithful to whatever shape the SDK emits — the export-time projector
    re-interprets these blocks. Per-attribute extraction keeps us robust
    to SDK additions without needing to track every block type here.
    """
    out: dict[str, Any] = {
        "turn": turn,
        "kind": message.__class__.__name__,
    }
    for attr in ("model", "stop_reason", "usage"):
        val = getattr(message, attr, None)
        if val is not None:
            out[attr] = _to_jsonable(val)
    content = getattr(message, "content", None)
    if content is not None:
        out["content"] = [_block_to_jsonable(b) for b in content]
    result = getattr(message, "result", None)
    if result is not None:
        out["result"] = result
    return out


def _block_to_jsonable(block: Any) -> dict[str, Any]:
    """Convert one content block (TextBlock / ThinkingBlock / ToolUseBlock /
    ToolResultBlock) into a JSON dict that mirrors the SDK's wire format."""
    btype = getattr(block, "type", None) or block.__class__.__name__.lower().replace("block", "")
    out: dict[str, Any] = {"type": btype}
    for attr in ("text", "thinking", "id", "name", "input", "tool_use_id", "content", "is_error"):
        val = getattr(block, attr, None)
        if val is not None:
            out[attr] = _to_jsonable(val)
    # v0.8.43 — scrub macOS-libsystem chatter from tool_result content
    # before it lands in the events table.  Without this, Cursor's
    # debugpy-shim noise (``MallocStackLogging: can't turn off ...``)
    # poisons training corpora exported via ``claw-forge export training``.
    # Applied at recorder level so all downstream consumers (UI, export,
    # custom queries) inherit the clean text without re-implementing the
    # scrubber.
    if btype in ("tool_result", "toolresult") and "content" in out:
        from claw_forge.agent.noise_filter import scrub_macos_noise

        raw = out["content"]
        if isinstance(raw, str):
            out["content"] = scrub_macos_noise(raw)
        elif isinstance(raw, list):
            out["content"] = [
                {**item, "text": scrub_macos_noise(item["text"])}
                if isinstance(item, dict) and isinstance(item.get("text"), str)
                else item
                for item in raw
            ]
    return out


def _to_jsonable(val: Any) -> Any:
    """Recursive shallow JSON-ification: scalars and dicts/lists pass through;
    objects with ``__dict__`` are flattened; everything else falls back to str."""
    if isinstance(val, (str, int, float, bool, type(None))):
        return val
    if isinstance(val, dict):
        return {k: _to_jsonable(v) for k, v in val.items()}
    if isinstance(val, (list, tuple)):
        return [_to_jsonable(v) for v in val]
    if hasattr(val, "__dict__"):
        return {k: _to_jsonable(v) for k, v in val.__dict__.items() if not k.startswith("_")}
    return str(val)


def destination_from_context(
    *,
    session_id: str,
    task_id: str,
    config: dict[str, Any],
) -> RecordingDestination | None:
    """Build a RecordingDestination from a PluginContext.config dict.

    Returns None when traces are not active (the caller should pass
    record_to=None and skip the wrap entirely).  Looks up:

    - ``config["training_traces"]`` block — must have both
      ``enabled: true`` and ``acknowledged_terms: true`` set.
    - ``config["state_url"]`` — the http://localhost:<port> base URL.
    """
    from claw_forge.training.config import extract_training_traces_config

    tt = extract_training_traces_config(config)
    if not tt.recording_active:
        return None
    state_url = config.get("state_url")
    if not state_url:
        return None
    return RecordingDestination(
        session_id=session_id, task_id=task_id, state_url=state_url,
    )
