"""Per-format projectors: turn an assembled record into a JSONL-ready dict.

Each projector takes the dict that
:func:`claw_forge.training.exporter.iter_training_records` yields and returns
the OpenAI / ShareGPT / ChatML / raw shape.  Format-specific lossiness is
documented per-projector — see :mod:`claw_forge.training.exporter` for the
underlying schema.
"""

from __future__ import annotations

import json
from typing import Any

# v0.8.38 — block-type alias normaliser.  The recorder serializes a
# block's ``type`` via two paths:
# (1) ``getattr(block, "type", None)`` — when the SDK has an explicit
#     ``type`` attr we get the canonical underscore form
#     ``tool_use`` / ``tool_result``.
# (2) Fallback ``cls.__name__.lower().replace("block", "")`` — when no
#     ``type`` attr is present we get ``tooluse`` / ``toolresult``
#     (no underscore).
# The projectors used to only check the underscore form, silently
# dropping every tool call from sessions captured under path (2).
# Centralising the alias check here ensures every projector accepts
# both, including future formats added below.
_TOOL_USE_TYPES = frozenset({"tool_use", "tooluse"})
_TOOL_RESULT_TYPES = frozenset({"tool_result", "toolresult"})


def _is_tool_use(btype: str | None) -> bool:
    return btype in _TOOL_USE_TYPES


def _is_tool_result(btype: str | None) -> bool:
    return btype in _TOOL_RESULT_TYPES


# v0.8.38 — upstream-error sentinel detection.  The recorder is
# deliberately faithful to whatever the SDK yields, which means
# transient ``API Error: Request rejected (429) ...`` messages from
# the provider land in the trace as assistant turns.  Training on
# these would teach the model to emit fake rate-limit errors as a
# completion strategy.  The default-on filter strips assistant text
# blocks that start with this sentinel; opt out via
# ``drop_error_turns=False`` if you specifically need them (e.g. for
# failure-pattern analysis).
_API_ERROR_SENTINELS = (
    "API Error: Request rejected",
    "API Error: 429",
    "API Error: 5",
)


def _is_upstream_error_text(text: str) -> bool:
    """True if *text* starts with an upstream-error sentinel.

    Narrow by design: a turn casually MENTIONING ``API errors`` in
    normal prose is kept; only turns whose body STARTS with the
    sentinel are dropped (matches the shape of real SDK errors).
    """
    stripped = text.lstrip()
    return any(stripped.startswith(s) for s in _API_ERROR_SENTINELS)


def to_openai_tools(
    rec: dict[str, Any],
    *,
    include_thinking: bool = True,
    drop_error_turns: bool = True,
) -> dict[str, Any]:
    """OpenAI tool-use chat format. Default and most expressive.

    The ``thinking`` field on assistant messages is a non-standard extension
    most loaders silently drop. Set ``include_thinking=False`` to skip it
    entirely if you don't want the keys in your JSONL at all.

    When ``drop_error_turns`` is True (default), assistant turns whose only
    text content is an upstream rate-limit / API error are skipped.  See
    ``_is_upstream_error_text`` for the sentinel patterns.
    """
    messages: list[dict[str, Any]] = []
    messages.append({"role": "system", "content": _system_for(rec)})
    messages.append({"role": "user", "content": rec.get("description", "")})

    for ev in rec.get("raw_events", []):
        kind = ev.get("kind")
        if kind == "AssistantMessage":
            asst = _assistant_from_blocks(
                ev.get("content", []),
                include_thinking=include_thinking,
                drop_error_turns=drop_error_turns,
            )
            if asst:
                messages.append(asst)
        elif kind == "UserMessage":
            messages.extend(_tool_results_from_blocks(ev.get("content", [])))
        # SystemMessage / ResultMessage skipped — SDK plumbing

    out: dict[str, Any] = {
        "task_id": rec["task_id"],
        "session_id": rec["session_id"],
        "outcome": rec["outcome"],
        "plugin": rec["plugin"],
        "category": rec.get("category"),
        "shape": rec.get("shape"),
        "retry_count": rec.get("retry_count", 0),
        "metrics": rec.get("metrics", {}),
        "messages": messages,
    }
    if rec.get("merge_commit_sha"):
        out["merge_commit"] = rec["merge_commit_sha"]
    if rec.get("final_diff"):
        out["final_diff"] = rec["final_diff"]
    if rec.get("provenance"):
        out["provenance"] = rec["provenance"]
    return out


def to_sharegpt(
    rec: dict[str, Any],
    *,
    include_thinking: bool = False,
    drop_error_turns: bool = True,
) -> dict[str, Any]:
    """ShareGPT format. Tool calls flatten to text — lossy but maximally compatible."""
    convos: list[dict[str, str]] = []
    convos.append({"from": "system", "value": _system_for(rec)})
    convos.append({"from": "human", "value": rec.get("description", "")})
    for ev in rec.get("raw_events", []):
        kind = ev.get("kind")
        if kind == "AssistantMessage":
            text = _flatten_assistant(
                ev.get("content", []),
                include_thinking=include_thinking,
                drop_error_turns=drop_error_turns,
            )
            if text:
                convos.append({"from": "gpt", "value": text})
        elif kind == "UserMessage":
            for b in ev.get("content", []):
                if _is_tool_result(b.get("type")):
                    content = _coerce_result_content(b.get("content"))
                    convos.append({"from": "tool", "value": content})
    out: dict[str, Any] = {
        "task_id": rec["task_id"],
        "outcome": rec["outcome"],
        "conversations": convos,
    }
    if rec.get("merge_commit_sha"):
        out["merge_commit"] = rec["merge_commit_sha"]
    if rec.get("provenance"):
        out["provenance"] = rec["provenance"]
    return out


def to_chatml(
    rec: dict[str, Any],
    *,
    include_thinking: bool = False,
    drop_error_turns: bool = True,
) -> dict[str, Any]:
    """Generic ChatML format. Single ``text`` field; no tool-use semantics."""
    parts: list[str] = []
    parts.append(f"<|im_start|>system\n{_system_for(rec)}<|im_end|>")
    parts.append(f"<|im_start|>user\n{rec.get('description', '')}<|im_end|>")
    for ev in rec.get("raw_events", []):
        if ev.get("kind") != "AssistantMessage":
            continue
        text = _flatten_assistant(
            ev.get("content", []),
            include_thinking=include_thinking,
            drop_error_turns=drop_error_turns,
        )
        if text:
            parts.append(f"<|im_start|>assistant\n{text}<|im_end|>")
    out: dict[str, Any] = {
        "task_id": rec["task_id"],
        "outcome": rec["outcome"],
        "text": "\n".join(parts),
    }
    if rec.get("merge_commit_sha"):
        out["merge_commit"] = rec["merge_commit_sha"]
    return out


def to_raw_jsonl(
    rec: dict[str, Any],
    *,
    include_thinking: bool = True,
    drop_error_turns: bool = True,
) -> dict[str, Any]:
    """Direct dump: no projection, full SDK message stream preserved.

    ``include_thinking`` and ``drop_error_turns`` are accepted for API
    consistency with the other projectors but are no-ops here — raw
    events are dumped verbatim.  Filter at training time if needed.
    """
    del include_thinking, drop_error_turns  # silence unused-arg lint
    out: dict[str, Any] = {
        "task_id": rec["task_id"],
        "session_id": rec["session_id"],
        "outcome": rec["outcome"],
        "plugin": rec["plugin"],
        "category": rec.get("category"),
        "shape": rec.get("shape"),
        "retry_count": rec.get("retry_count", 0),
        "metrics": rec.get("metrics", {}),
        "description": rec.get("description", ""),
        "events": rec.get("raw_events", []),
    }
    if rec.get("merge_commit_sha"):
        out["merge_commit"] = rec["merge_commit_sha"]
    if rec.get("provenance"):
        out["provenance"] = rec["provenance"]
    return out


# ── Internal helpers ─────────────────────────────────────────────────────────


def _system_for(rec: dict[str, Any]) -> str:
    """Reconstruct a system-prompt approximation from task metadata.

    The actual system prompt sent to the agent isn't stored on Event rows;
    we synthesise a short string from plugin/category/shape so projected
    records are usable as-is for SFT without an empty system slot.
    """
    plugin = rec.get("plugin", "coding")
    cat = rec.get("category") or ""
    shape = rec.get("shape") or ""
    bits = [f"You are a claw-forge {plugin} agent."]
    if cat:
        bits.append(f"Category: {cat}.")
    if shape:
        bits.append(f"Shape: {shape}.")
    return " ".join(bits)


def _assistant_from_blocks(
    blocks: list[dict[str, Any]],
    *,
    include_thinking: bool,
    drop_error_turns: bool = True,
) -> dict[str, Any] | None:
    """Fold thinking + text + tool_use blocks into one OpenAI assistant msg.

    Accepts both ``tool_use`` (canonical underscore) and ``tooluse``
    (recorder fallback when SDK blocks lack a ``.type`` attribute).
    When ``drop_error_turns`` is True, text blocks starting with an
    upstream-error sentinel (``API Error: Request rejected ...``) are
    skipped — they're transient provider failures, not training signal.
    """
    text_parts: list[str] = []
    thinking_parts: list[str] = []
    tool_calls: list[dict[str, Any]] = []
    for b in blocks:
        btype = b.get("type")
        if btype == "text":
            text = b.get("text", "")
            if drop_error_turns and _is_upstream_error_text(text):
                continue
            text_parts.append(text)
        elif btype == "thinking":
            thinking_parts.append(b.get("thinking", ""))
        elif _is_tool_use(btype):
            tool_calls.append({
                "id": b.get("id", ""),
                "type": "function",
                "function": {
                    "name": b.get("name", ""),
                    "arguments": json.dumps(b.get("input") or {}),
                },
            })
    if not text_parts and not tool_calls:
        return None
    msg: dict[str, Any] = {"role": "assistant", "content": "".join(text_parts)}
    if include_thinking and thinking_parts:
        msg["thinking"] = "".join(thinking_parts)
    if tool_calls:
        msg["tool_calls"] = tool_calls
    return msg


def _tool_results_from_blocks(blocks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Each tool_result block becomes its own OpenAI tool-role message.

    Accepts both ``tool_result`` and ``toolresult`` — see file header
    for the recorder-side path that produces the no-underscore alias.
    """
    out: list[dict[str, Any]] = []
    for b in blocks:
        if not _is_tool_result(b.get("type")):
            continue
        out.append({
            "role": "tool",
            "tool_call_id": b.get("tool_use_id", ""),
            "content": _coerce_result_content(b.get("content")),
        })
    return out


def _flatten_assistant(
    blocks: list[dict[str, Any]],
    *,
    include_thinking: bool,
    drop_error_turns: bool = True,
) -> str:
    parts: list[str] = []
    for b in blocks:
        btype = b.get("type")
        if btype == "text":
            text = b.get("text", "")
            if drop_error_turns and _is_upstream_error_text(text):
                continue
            parts.append(text)
        elif btype == "thinking" and include_thinking:
            parts.append(f"<thinking>{b.get('thinking', '')}</thinking>")
        elif _is_tool_use(btype):
            args = json.dumps(b.get("input") or {})
            parts.append(f"<tool_call name=\"{b.get('name', '')}\">{args}</tool_call>")
    return "".join(parts)


def _coerce_result_content(content: Any) -> str:
    """tool_result content can be a string or a list of {type, text} blocks.
    Normalize to a single string."""
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(
            c.get("text", "") if isinstance(c, dict) else str(c) for c in content
        )
    return str(content)
