"""HTTP client and session-resolution helpers for the state service.

The state service itself lives in `claw_forge.state.service`. This module
is its consumer-side counterpart: HTTP GET/POST wrappers, port-binding
diagnostics, the auto-start orchestration (`_ensure_state_service`),
session-resolution from `.claw-forge/state.db`, and dict-to-TaskNode
conversion helpers.

Test-imported symbols (`_resolve_project_root`, `_resolve_latest_session`,
`_task_dict_to_node`) are re-exported by `claw_forge.cli` for backwards
compatibility.
"""
from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

import httpx
import typer

from claw_forge import __version__
from claw_forge._console import console

if TYPE_CHECKING:
    from claw_forge.state.scheduler import TaskNode



def _state_url(port: int = 8420) -> str:
    return f"http://localhost:{port}"


def _task_dict_to_node(payload: dict[str, Any]) -> TaskNode:
    """Build a scheduler TaskNode from a state-service task JSON payload."""
    from claw_forge.state.scheduler import TaskNode

    return TaskNode(
        id=payload["id"],
        plugin_name=payload.get("plugin_name", ""),
        priority=int(payload.get("priority", 0) or 0),
        depends_on=list(payload.get("depends_on", []) or []),
        status=payload.get("status", "pending"),
        category=payload.get("category", "") or "",
        steps=list(payload.get("steps", []) or []),
        description=payload.get("description", "") or "",
        merged_to_target_branch=bool(
            payload.get(
                "merged_to_target_branch",
                payload.get("merged_to_main", True),
            )
        ),
        touches_files=list(payload.get("touches_files", []) or []),
        shape=payload.get("shape"),
        plugin=payload.get("plugin"),
    )


def _decorate_resumable(
    nodes: list[TaskNode],
    project_dir: Path,
    target_branch: str,
    branch_prefix: str,
    *,
    enabled: bool = True,
    stale_threshold: int = 50,
) -> None:
    """Mark each pending node as resumable when its feature branch already
    has committed work that's not too stale to merge.

    A task is resumable iff:
      * ``status == "pending"`` (terminal-state tasks aren't dispatched again)
      * the feature branch ``{branch_prefix}/{slug}`` exists with at least
        one commit ahead of ``target_branch``
      * ``target_branch`` is no more than ``stale_threshold`` commits ahead
        of the feature branch (otherwise the catch-up merge will likely
        conflict and starting fresh is cleaner)

    When ``enabled`` is False the function is a no-op — useful for the
    ``git.prefer_resumable: false`` config.
    """
    if not enabled:
        return
    from claw_forge.git import (
        branch_age_in_commits,
        branch_exists,
        branch_has_commits_ahead,
    )
    from claw_forge.git.slug import make_branch_name

    for node in nodes:
        if node.status != "pending":
            continue
        branch = make_branch_name(
            node.description or None,
            node.category or None,
            node.plugin_name or branch_prefix,
            prefix=branch_prefix,
        )
        if not branch_exists(project_dir, branch):
            continue
        if not branch_has_commits_ahead(project_dir, branch, target_branch):
            continue
        if branch_age_in_commits(project_dir, branch, target_branch) > stale_threshold:
            continue
        node.resumable = True


def _http_get(url: str) -> dict[str, Any] | list[Any]:
    """Simple synchronous GET helper."""
    try:
        resp = httpx.get(url, timeout=5)
        resp.raise_for_status()
        return resp.json()  # type: ignore[no-any-return]
    except httpx.ConnectError:
        console.print(
            f"[red]State service not reachable at {url}[/red]\n"
            "[yellow]Tip: start it with `claw-forge state`[/yellow]"
        )
        raise typer.Exit(1) from None
    except httpx.HTTPStatusError as exc:
        console.print(f"[red]HTTP {exc.response.status_code}: {exc.response.text}[/red]")
        raise typer.Exit(1) from None


def _http_post(url: str, json: dict[str, Any] | None = None) -> dict[str, Any]:
    """Simple synchronous POST helper."""
    try:
        resp = httpx.post(url, json=json or {}, timeout=5)
        resp.raise_for_status()
        return resp.json()  # type: ignore[no-any-return]
    except httpx.ConnectError:
        console.print(
            f"[red]State service not reachable at {url}[/red]\n"
            "[yellow]Tip: start it with `claw-forge state`[/yellow]"
        )
        raise typer.Exit(1) from None
    except httpx.HTTPStatusError as exc:
        console.print(f"[red]HTTP {exc.response.status_code}: {exc.response.text}[/red]")
        raise typer.Exit(1) from None


def _list_sessions_for_help(
    db_path: Path, project_path: Path | None = None, limit: int = 10
) -> list[tuple[str, str, str]]:
    """Return [(id, project_path, created_at), ...] for error-message hints.

    Filters by *project_path* when given. Most recent first. Errors are
    swallowed and yield an empty list — this is purely for UX guidance.
    """
    try:
        import sqlite3 as _sq
        if not db_path.exists():
            return []
        with _sq.connect(str(db_path)) as conn:
            if project_path is not None:
                cursor = conn.execute(
                    "SELECT id, project_path, created_at FROM sessions "
                    "WHERE project_path = ? "
                    "ORDER BY created_at DESC LIMIT ?",
                    (str(project_path), limit),
                )
            else:
                cursor = conn.execute(
                    "SELECT id, project_path, created_at FROM sessions "
                    "ORDER BY created_at DESC LIMIT ?",
                    (limit,),
                )
            return [(str(r[0]), str(r[1]), str(r[2])) for r in cursor.fetchall()]
    except Exception:  # noqa: BLE001
        return []


def _session_exists(db_path: Path, session_id: str) -> bool:
    try:
        import sqlite3 as _sq
        with _sq.connect(str(db_path)) as conn:
            row = conn.execute(
                "SELECT 1 FROM sessions WHERE id = ? LIMIT 1", (session_id,)
            ).fetchone()
            return row is not None
    except Exception:  # noqa: BLE001
        return False


def _count_sessions_and_tasks(
    db_path: Path, session_id: str | None
) -> tuple[int, int]:
    """Return (session_count, task_count) for the export summary line."""
    try:
        import sqlite3 as _sq
        with _sq.connect(str(db_path)) as conn:
            if session_id is None:
                s_count = conn.execute(
                    "SELECT COUNT(*) FROM sessions"
                ).fetchone()[0]
                t_count = conn.execute(
                    "SELECT COUNT(*) FROM tasks"
                ).fetchone()[0]
            else:
                s_count = conn.execute(
                    "SELECT COUNT(*) FROM sessions WHERE id = ?",
                    (session_id,),
                ).fetchone()[0]
                t_count = conn.execute(
                    "SELECT COUNT(*) FROM tasks WHERE session_id = ?",
                    (session_id,),
                ).fetchone()[0]
            return int(s_count), int(t_count)
    except Exception:  # noqa: BLE001
        return 0, 0


def _print_session_hints(db_path: Path, project_path: Path) -> None:
    """Print a list of available sessions to help the operator pick one."""
    sessions = _list_sessions_for_help(db_path, project_path=project_path)
    if not sessions:
        # Fall back to all sessions across projects.
        sessions = _list_sessions_for_help(db_path)
    if sessions:
        console.print("\n  Available sessions:")
        for sid, ppath, created in sessions:
            console.print(
                f"    [cyan]{sid}[/cyan]  {created}  [dim]{ppath}[/dim]"
            )
    else:
        console.print(
            "\n  [dim]No sessions in DB. Run [bold]claw-forge run[/bold] first.[/dim]"
        )


def _resolve_project_root(
    spec_path: Path,
    *,
    override: Path | None = None,
) -> Path | None:
    """Resolve the project root for Layer 4 filesystem checks.

    Order:
      1. If override given, return it.
      2. Walk up from spec_path.parent looking for .claw-forge.yaml.
      3. If none found, walk up looking for .git.
      4. Otherwise return None — Layer 4 filesystem checks will be skipped.

    Returns the directory containing the marker, or None.
    """
    if override is not None:
        return override
    start = spec_path.resolve().parent
    # Pass 1: .claw-forge.yaml (more specific)
    for parent in [start, *start.parents]:
        if (parent / ".claw-forge.yaml").is_file():
            return parent
    # Pass 2: .git (looser — any git repo)
    for parent in [start, *start.parents]:
        if (parent / ".git").exists():
            return parent
    return None


def _resolve_latest_session(db_path: Path, project_path: Path | None = None) -> str:
    """Read the most-recent session id from state.db; return '' if none found.

    When *project_path* is given, only sessions whose ``project_path``
    column matches are considered — this prevents stale test sessions
    (or sessions from other projects sharing the same DB) from being
    selected over the real project session.
    """
    try:
        import sqlite3 as _sq
        if db_path.exists():
            with _sq.connect(str(db_path)) as conn:
                if project_path is not None:
                    row = conn.execute(
                        "SELECT id FROM sessions WHERE project_path = ? "
                        "ORDER BY created_at DESC LIMIT 1",
                        (str(project_path),),
                    ).fetchone()
                else:
                    row = conn.execute(
                        "SELECT id FROM sessions ORDER BY created_at DESC LIMIT 1"
                    ).fetchone()
                if row:
                    return str(row[0])
    except Exception:  # noqa: BLE001
        pass
    return ""


def _port_in_use_error(port: int, service: str = "state service") -> None:
    """Print a rich, actionable error when a port is already in use and exit."""
    import platform

    is_mac = platform.system() == "Darwin"
    lsof_cmd   = f"lsof -i :{port}"
    kill_cmd   = f"kill $(lsof -ti :{port})"
    ss_cmd     = f"ss -tlnp | grep {port}"         # Linux alternative

    console.print(f"\n[bold red]✖  Port {port} is already in use[/bold red]\n")
    console.print(
        f"  Another process is bound to [bold]{port}[/bold] and the {service} cannot start.\n"
    )

    console.print("[bold yellow]▶  How to find what is using the port:[/bold yellow]")
    console.print(f"     [cyan]{lsof_cmd}[/cyan]")
    if not is_mac:
        console.print(f"     [cyan]{ss_cmd}[/cyan]   [dim]# Linux alternative[/dim]")

    console.print("\n[bold yellow]▶  How to kill the conflicting process:[/bold yellow]")
    console.print(f"     [cyan]{kill_cmd}[/cyan]")

    console.print(
        "\n[bold yellow]▶  If a previous claw-forge session is still running:[/bold yellow]"
    )
    console.print("     [cyan]ps aux | grep 'claw-forge state'[/cyan]   [dim]# find PID[/dim]")
    shutdown_url = f"http://localhost:{port}/shutdown"
    console.print(f"     [cyan]curl -s -X POST {shutdown_url}[/cyan]   [dim]# graceful stop[/dim]")

    console.print("\n[bold yellow]▶  Use a different port instead:[/bold yellow]")
    console.print(f"     [cyan]claw-forge state --port {port + 1}[/cyan]")
    console.print(
        f"     [dim]Or set it permanently in[/dim] [bold]claw-forge.yaml[/bold][dim]:[/dim]\n"
        f"     [cyan]state:\n       port: {port + 1}[/cyan]"
    )
    raise typer.Exit(1)


def _ensure_state_service(
    project_path: Path, port: int, *, skip_version_restart: bool = False,
) -> int:
    """Start state service if not running or serving the wrong project.

    If the requested port is occupied, tries port+1 … port+4 and starts on
    the first free one.  The chosen port is always printed to the console.
    Returns the port the state service is listening on.

    When *skip_version_restart* is True (used by ``claw-forge ui``), the
    service is reused as-is when it serves the correct project, even if the
    version differs.  This prevents the UI from killing a state service that
    ``claw-forge run`` is actively using.
    """
    import json as _json
    import socket as _sock
    import subprocess as _sp
    import time as _st
    import urllib.request as _req

    want_project = str(project_path.resolve())
    log_path = project_path / ".claw-forge" / "state.log"

    def _listening(p: int) -> bool:
        try:
            with _sock.create_connection(("127.0.0.1", p), timeout=0.5):
                return True
        except OSError:
            return False

    def _wait_for_port(p: int, timeout: float = 10.0) -> bool:
        deadline = _st.monotonic() + timeout
        while _st.monotonic() < deadline:
            _st.sleep(0.25)
            try:
                with _sock.create_connection(("127.0.0.1", p), timeout=0.5):
                    return True
            except OSError:
                pass
        return False

    def _wait_for_port_free(p: int, timeout: float = 5.0) -> None:
        deadline = _st.monotonic() + timeout
        while _st.monotonic() < deadline:
            try:
                with _sock.create_connection(("127.0.0.1", p), timeout=0.5):
                    _st.sleep(0.25)
            except OSError:
                return

    def _get_info(p: int, timeout: float = 2.0) -> dict[str, object] | None:
        try:
            with _req.urlopen(  # noqa: S310
                f"http://127.0.0.1:{p}/info", timeout=timeout
            ) as resp:
                return _json.loads(resp.read())  # type: ignore[no-any-return]
        except Exception:  # noqa: BLE001
            return None

    def _start_on(p: int) -> bool:
        """Launch state service on *p*. Return True if /info responds correctly."""
        import shutil as _shutil
        import sys as _sys

        project_path.joinpath(".claw-forge").mkdir(parents=True, exist_ok=True)
        # Use the claw-forge binary from the same venv as the running process
        # to avoid picking up a stale system-wide installation.
        venv_bin = Path(_sys.executable).parent / "claw-forge"
        claw_forge_cmd = str(venv_bin) if venv_bin.exists() else (
            _shutil.which("claw-forge") or "claw-forge"
        )
        cmd = [
            claw_forge_cmd, "state",
            "--project", str(project_path),
            "--port", str(p),
        ]
        # Pass --config pointing to the project directory's config so the
        # subprocess finds claw-forge.yaml even when CWD != project dir.
        _cfg_path = project_path / "claw-forge.yaml"
        if _cfg_path.exists():
            cmd.extend(["--config", str(_cfg_path)])
        with open(log_path, "w") as log_f:  # noqa: WPS515
            _sp.Popen(  # noqa: S603
                cmd,
                stdout=log_f,
                stderr=_sp.STDOUT,
                start_new_session=True,
            )
        if not _wait_for_port(p, timeout=10.0):
            return False
        info = _get_info(p, timeout=3.0)
        if info is None:
            return False
        svc_project = info.get("project_path", "")
        return bool(svc_project) and str(Path(str(svc_project)).resolve()) == want_project

    # ── Is the configured port occupied by something? ─────────────────────────
    if _listening(port):
        info = _get_info(port)
        if info is not None:
            svc_project_raw = info.get("project_path", "")
            svc_version = info.get("claw_forge_version", "")
            if svc_project_raw:
                svc_project = str(Path(str(svc_project_raw)).resolve())
                if svc_project == want_project:
                    if svc_version == __version__ or skip_version_restart:
                        console.print(f"[dim]State service already running on port {port}[/dim]")
                        return port  # same project — reuse
                    # Same project but stale version → restart in place.
                    # POSTing /shutdown is safe here because we own the
                    # service (same project_path).
                    console.print(
                        f"[dim]State service outdated "
                        f"({svc_version} → {__version__}), restarting…[/dim]"
                    )
                    try:
                        with _req.urlopen(  # noqa: S310
                            _req.Request(f"http://127.0.0.1:{port}/shutdown", method="POST"),
                            timeout=2,
                        ):
                            pass
                    except Exception:  # noqa: BLE001
                        pass
                    _wait_for_port_free(port)
                    if _start_on(port):
                        console.print(f"[dim]State service restarted on port {port}[/dim]")
                        return port
                else:
                    # Different project — yield: NEVER shut down a state
                    # service that another project's run is actively using.
                    # Fall through to the port+1..port+4 fallback so concurrent
                    # ``claw-forge run`` invocations across projects don't
                    # terminate each other.
                    console.print(
                        f"[dim]Port {port} held by another project's state service; "
                        f"selecting alternate port[/dim]"
                    )
        # Port is blocked (non-claw-forge process, or claw-forge for another
        # project we yielded to) — find the next free port.
        for p in range(port + 1, port + 5):
            if _listening(p):
                # Check if it's already our service on this alternate port
                alt_info = _get_info(p)
                if alt_info is not None:
                    alt_raw = alt_info.get("project_path", "")
                    if alt_raw and str(Path(str(alt_raw)).resolve()) == want_project:
                        console.print(f"[dim]State service already running on port {p}[/dim]")
                        return p
                continue  # also blocked
            if _start_on(p):
                console.print(
                    f"[yellow]Port {port} is occupied — "
                    f"state service started on port [bold]{p}[/bold][/yellow]"
                )
                return p
        import contextlib as _ctx
        log_tail = ""
        with _ctx.suppress(OSError):
            log_tail = log_path.read_text()[-500:]
        raise RuntimeError(
            f"Port {port} and the next 4 alternatives are all occupied.\n"
            f"Fix: add 'state:\\n  port: <free_port>' to claw-forge.yaml.\n"
            f"Log: {log_path}\n{log_tail}"
        )

    # ── Port is free — start normally ─────────────────────────────────────────
    if _start_on(port):
        console.print(f"[dim]State service started on port {port}[/dim]")
        return port
    import contextlib as _ctx
    log_tail = ""
    with _ctx.suppress(OSError):
        log_tail = log_path.read_text()[-500:]
    raise RuntimeError(
        f"State service failed to start on port {port} within 10s.\n"
        f"Log: {log_path}\n{log_tail}"
    )


__all__ = [
    "_count_sessions_and_tasks",
    "_decorate_resumable",
    "_ensure_state_service",
    "_http_get",
    "_http_post",
    "_list_sessions_for_help",
    "_port_in_use_error",
    "_print_session_hints",
    "_resolve_latest_session",
    "_resolve_project_root",
    "_session_exists",
    "_state_url",
    "_task_dict_to_node",
    "console",
]
