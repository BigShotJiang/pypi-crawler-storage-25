"""Typer commands that interact with the state service.

This module owns six top-level claw-forge commands: ``status``, ``state``,
``pause``, ``resume``, ``input``, and ``add``. All hit the state-service REST
API (auto-started via ``_ensure_state_service``) or start the service itself
(``state``).

The Typer instance ``state_app`` is mounted on the main app in
``claw_forge.cli`` without a ``name=`` argument so its commands surface as
top-level (``claw-forge status`` etc., not ``claw-forge state status``).
"""
from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Any

import typer

from claw_forge._console import console
from claw_forge.config import _load_config, _load_env_file
from claw_forge.pool.model_resolver import resolve_model
from claw_forge.state.client import (
    _http_get,
    _http_post,
    _port_in_use_error,
    _state_url,
)

state_app = typer.Typer(help="State-service commands")


@state_app.command()
def status(
    config: str = typer.Option(
        "claw-forge.yaml", "--config", "-c",
        help="Path to claw-forge.yaml config file.",
    ),
    project: str = typer.Option(".", "--project", "-p", help="Project directory."),
) -> None:
    """Show project progress, agent status, and recommended next action.

    Zero-friction re-entry command — run this after returning to a project
    to see exactly where you left off and what to do next.

    Examples:

        # Show status for current directory
        claw-forge status

        # Show status for a specific project
        claw-forge status --project ~/projects/my-app
    """
    from claw_forge.commands.help_cmd import run_help

    project_path = Path(project).resolve()
    if config == "claw-forge.yaml":
        config = str(project_path / "claw-forge.yaml")
    run_help(config_path=config, project_path=str(project_path))


@state_app.command()
def state(
    port: int = typer.Option(8420, "--port", help="Port to bind the state service on."),
    host: str = typer.Option(
        "0.0.0.0", "--host",
        help="Host to bind (use 127.0.0.1 for local-only).",
    ),
    project: str = typer.Option(".", "--project", "-p", help="Project directory."),
    config: str = typer.Option(
        "claw-forge.yaml", "--config", "-c",
        help="Path to claw-forge.yaml (used for provider config and project metadata).",
    ),
    reload: bool = typer.Option(
        False, "--reload",
        help="Enable hot-reload — restart the server on Python file changes (dev only).",
    ),
    database_url: str | None = typer.Option(
        None, "--database-url",
        help="Database URL override "
        "(e.g. postgresql+asyncpg://user:pass@host/db). "
        "Default: SQLite in .claw-forge/state.db",
    ),
) -> None:
    """Start the AgentStateService REST + WebSocket API.

    The state service powers the Kanban UI and exposes REST endpoints for
    session, task, pool, regression, and command management.

    Examples:

        # Start on default port 8420
        claw-forge state

        # Start with hot-reload for development
        claw-forge state --reload

        # Start on a custom port, local-only
        claw-forge state --port 9000 --host 127.0.0.1

        # Start with PostgreSQL
        claw-forge state --database-url postgresql+asyncpg://u:p@host/db

        # Start the UI separately (connects to state service automatically)
        claw-forge ui --state-port 8420
    """
    import uvicorn

    from claw_forge.state.backend import mask_url_password, resolve_database_url

    project_path = Path(project).resolve()
    _load_env_file(project_path)
    cfg = _load_config(config)
    db_url = resolve_database_url(
        cli_override=database_url,
        config=cfg.get("state"),
        project_path=project_path,
    )
    console.print(f"[dim]Database: {mask_url_password(db_url)}[/dim]")

    try:
        if reload:
            console.print("[bold yellow]🔄 Hot-reload enabled[/bold yellow]")
            os.environ["CLAW_FORGE_DB_URL"] = db_url
            os.environ["CLAW_FORGE_PROJECT_PATH"] = str(project_path)
            uvicorn.run(
                "claw_forge.state.service:create_app_from_env",
                factory=True,
                host=host,
                port=port,
                reload=True,
                reload_dirs=[str(Path(__file__).parent.parent)],
            )
        else:
            from claw_forge.state.service import AgentStateService

            svc = AgentStateService(
                database_url=db_url, project_path=project_path,
            )
            uvicorn.run(svc.create_app(), host=host, port=port)
    except OSError as exc:
        if "Address already in use" in str(exc) or getattr(exc, "errno", None) in (48, 98):
            _port_in_use_error(port, "state service")
        raise


@state_app.command()
def pause(
    project: str = typer.Argument(..., help="Session ID or project name to pause"),
    port: int = typer.Option(8420, "--port", help="State service port"),
) -> None:
    """Pause a running project (drain mode: finish in-flight agents, start no new ones)."""
    url = f"{_state_url(port)}/project/pause?session_id={project}"
    result = _http_post(url)
    paused = result.get("paused", False)
    if paused:
        console.print(f"[yellow]⏸  Project {project!r} paused.[/yellow]")
        console.print("In-flight agents will complete. No new agents will start.")
        console.print(f"Resume with: [bold]claw-forge resume {project}[/bold]")
    else:
        console.print(f"[red]Unexpected response: {result}[/red]")
        raise typer.Exit(1) from None


@state_app.command()
def resume(
    project: str = typer.Argument(..., help="Session ID or project name to resume"),
    port: int = typer.Option(8420, "--port", help="State service port"),
) -> None:
    """Resume a paused project — dispatcher starts accepting new tasks again."""
    url = f"{_state_url(port)}/project/resume?session_id={project}"
    result = _http_post(url)
    paused = result.get("paused", True)
    if not paused:
        console.print(f"[green]▶  Project {project!r} resumed.[/green]")
        console.print("Dispatcher is now accepting new tasks.")
    else:
        console.print(f"[red]Unexpected response: {result}[/red]")
        raise typer.Exit(1) from None


@state_app.command(name="input")
def human_input(
    project: str = typer.Argument(..., help="Session ID or project name"),
    port: int = typer.Option(8420, "--port", help="State service port"),
) -> None:
    """List pending human-input questions and answer them interactively.

    Agents that are stuck POST a question to /features/{id}/human-input.
    This command shows those questions and submits your answers, moving
    the feature back to 'pending' for the dispatcher to retry.
    """
    url = f"{_state_url(port)}/features/needs-human?session_id={project}"
    pending: list[dict[str, Any]] = _http_get(url)  # type: ignore[assignment]

    if not pending:
        console.print(f"[green]✅ No pending human-input questions for {project!r}[/green]")
        return

    console.print(f"[bold yellow]🙋 {len(pending)} pending question(s) for {project!r}:[/bold yellow]\n")  # noqa: E501

    for item in pending:
        task_id = item["task_id"]
        question = item.get("question", "(no question text)")
        description = item.get("description", "")

        console.print(f"[bold]Task:[/bold] {description or task_id}")
        console.print(f"[bold yellow]Q:[/bold yellow] {question}")
        answer = typer.prompt("Your answer")

        answer_url = f"{_state_url(port)}/features/{task_id}/human-answer"
        _http_post(answer_url, json={"answer": answer})
        console.print(f"[green]✅ Answer submitted — task {task_id} moved to pending[/green]\n")

    console.print(f"[green]All questions answered. Project {project!r} can now continue.[/green]")


@state_app.command()
def add(
    feature: str = typer.Argument(
        ...,
        help="Feature description (plain text) or @path/to/additions_spec.xml.",
    ),
    spec: str | None = typer.Option(
        None, "--spec", "-s",
        help="Path to brownfield XML spec (additions_spec.xml). "
             "Use /create-spec in Claude Code to generate one.",
    ),
    project: str = typer.Option(".", "--project", "-p", help="Project directory."),
    model: str = typer.Option(
        "claude-sonnet-4-6", "--model", "-m",
        help=(
            "Model to use. Supported formats:\n"
            "  claude-sonnet-4-6             bare model (pool picks provider)\n"
            "  anthropic-proxy-1/claude-opus-4-6    pin to specific provider\n"
            "  sonnet                               alias from model_aliases in config"
        ),
    ),
    concurrency: int = typer.Option(
        3, "--concurrency", "-n",
        help="Max parallel agents for this addition (default 3, lower than greenfield).",
    ),
    branch: bool = typer.Option(
        True, "--branch/--no-branch",
        help="Create a feat/<slug> git branch for this addition.",
    ),
    config: str = typer.Option(
        "claw-forge.yaml", "--config", "-c",
        help="Path to claw-forge.yaml config file.",
    ),
) -> None:
    """Add a feature or brownfield spec to an existing project.

    Runs a brownfield agent that respects existing conventions, keeps all
    current tests green, and works on a dedicated git branch.

    Examples:

        # Add a single feature by description
        claw-forge add 'add Stripe payment webhook handler'

        # Add features from a brownfield spec
        claw-forge add --spec additions_spec.xml

        # Add without branching
        claw-forge add 'add rate limiting' --no-branch

        # Add with a specific model and concurrency
        claw-forge add --spec additions_spec.xml --model claude-opus-4-6 --concurrency 2
    """
    import json

    from claw_forge.plugins.base import PluginContext
    from claw_forge.plugins.initializer import InitializerPlugin

    cfg_data = _load_config(config)
    resolved = resolve_model(model, cfg_data)
    if resolved.alias_resolved:
        console.print(f"[dim]Model alias '{model}' → {resolved.model_id}[/dim]")
    if resolved.provider_hint:
        console.print(f"[dim]Provider pinned: {resolved.provider_hint}[/dim]")
    model = resolved.model_id

    if spec:
        # Brownfield spec path provided — parse and inject context
        from claw_forge.spec import ProjectSpec

        spec_path = Path(spec)
        try:
            parsed = ProjectSpec.from_file(spec_path)
        except Exception as exc:
            console.print(f"[red]Failed to parse spec: {exc}[/red]")
            raise typer.Exit(1) from exc

        # Load manifest if brownfield
        manifest: dict[str, Any] | None = None
        if parsed.is_brownfield:
            manifest_path = Path(project) / "brownfield_manifest.json"
            if manifest_path.exists():
                try:
                    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                    for key in ("stack", "test_baseline", "conventions"):
                        if key in manifest:
                            parsed.existing_context[key] = str(manifest[key])
                except Exception as exc:
                    console.print(f"[yellow]Warning: could not load manifest: {exc}[/yellow]")

        agent_ctx = parsed.to_agent_context(manifest)
        num_features = len(parsed.features)

        console.print(f"\n[bold green]✅ Brownfield spec: {parsed.project_name}[/bold green]")
        console.print(f"   Mode: {parsed.mode}")
        console.print(f"   Features to add: {num_features}")
        if parsed.constraints:
            console.print(f"   Constraints: {len(parsed.constraints)}")
        if parsed.integration_points:
            console.print(f"   Integration points: {len(parsed.integration_points)}")

        console.print("\n[bold]Agent context:[/bold]")
        console.print(agent_ctx)

        # Delegate to initializer for feature creation
        plugin = InitializerPlugin()
        ctx = PluginContext(project_path=project, session_id="add", task_id="add")
        ctx.metadata = {"spec_file": spec}
        result = asyncio.run(plugin.execute(ctx))
        if not result.success:
            console.print(f"[red]Failed: {result.output}[/red]")
            raise typer.Exit(1) from None

        if branch:
            branch_name = parsed.project_name.lower().replace(" ", "-").replace("—", "")
            branch_name = "".join(c for c in branch_name if c.isalnum() or c == "-")
            console.print(f"\n[dim]Suggested git branch: feature/{branch_name}[/dim]")

        console.print(
            f"\n   Next: [bold]claw-forge run --spec {spec} --project {project}[/bold]"
        )
    else:
        # Single feature description
        console.print(f"[bold]Adding feature:[/bold] {feature}")
        console.print(f"[bold]Project:[/bold] {project}")
        if branch:
            from claw_forge.git.slug import make_slug as _make_slug
            slug = _make_slug(feature)
            console.print(f"[dim]Suggested git branch: feat/{slug}[/dim]")
        console.print("[yellow]Feature addition not yet integrated — scaffold only[/yellow]")
