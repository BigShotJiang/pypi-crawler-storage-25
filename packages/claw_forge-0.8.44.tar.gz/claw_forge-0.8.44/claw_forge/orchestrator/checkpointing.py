"""Periodic auto-checkpoint asyncio task for the run dispatcher.

Wakes every ``interval`` seconds and best-effort commits dirty worktree
files via :meth:`GitOps.checkpoint` so a crash mid-task loses at most
``interval`` seconds of work.  Any commit failure is swallowed — the
checkpoint must NOT become a liveness gate.

Cancelled by the per-task ``task_handler`` in its ``finally`` block.
"""

from __future__ import annotations

import asyncio
from contextlib import suppress
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from claw_forge.git import GitOps


async def periodic_checkpoint_loop(
    git_ops: GitOps,
    wt_path: Path,
    t_id: str,
    t_plugin: str,
    sid: str,
    interval: int,
) -> None:
    """Best-effort auto-save of dirty worktree files."""
    while True:
        await asyncio.sleep(interval)
        with suppress(Exception):
            await git_ops.checkpoint(
                message=f"auto-save: {t_plugin} in progress",
                task_id=t_id,
                plugin=t_plugin,
                phase="auto-save",
                session_id=sid,
                cwd=wt_path,
            )
