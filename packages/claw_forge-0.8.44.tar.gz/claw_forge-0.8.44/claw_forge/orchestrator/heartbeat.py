"""Dispatcher → state-service heartbeat loop (v0.8.39).



The state service exposes ``POST /sessions/{id}/dispatcher/heartbeat`` and
the matching ``GET /sessions/{id}/dispatcher/status``.  This module
provides the dispatcher's client side: a background asyncio task that
pings the heartbeat endpoint every ``interval_seconds`` while the
dispatcher is alive.

Spawned from :mod:`claw_forge.orchestrator.run_cli` once the
``RunContext`` is constructed; cancelled in the ``finally`` block when
the dispatcher loop exits (normal completion, SIGINT, SIGTERM, or
unhandled exception).

Failure semantics: best-effort, never fatal.  A transient network or
HTTP error logs at DEBUG and the loop continues to the next interval —
a one-off hiccup must not cause the UI to declare the dispatcher dead.
The only way to stop the loop is ``asyncio.CancelledError``.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
from typing import Any

import httpx

log = logging.getLogger(__name__)


async def heartbeat_loop(
    *,
    state_base: str,
    session_id: str,
    interval_seconds: float = 30.0,
    client: httpx.AsyncClient | Any | None = None,
) -> None:
    """POST ``/sessions/{session_id}/dispatcher/heartbeat`` forever.

    Parameters
    ----------
    state_base
        Base URL of the state service (e.g. ``http://localhost:8420``).
    session_id
        UUID of the running session — the heartbeat key.
    interval_seconds
        Time between POSTs.  Default 30 s pairs with the server's 90 s
        grace window for one wallclock-retry tolerance.
    client
        Optional pre-built httpx client.  When None the loop owns its
        own client and closes it on cancellation.  Tests pass an
        ASGITransport-backed client so they don't need real networking.

    Cancellation
    ------------
    Raises ``asyncio.CancelledError`` to the caller — the dispatcher's
    ``finally`` block does ``task.cancel()`` + ``await task`` and
    swallows the cancellation.
    """
    own_client = client is None
    active = client if client is not None else httpx.AsyncClient(timeout=5.0)
    try:
        while True:
            try:
                await active.post(
                    f"{state_base}/sessions/{session_id}/dispatcher/heartbeat",
                )
            except Exception:  # noqa: BLE001
                # Best-effort: a transient network blip must not abort the
                # loop.  Log at DEBUG so we don't fill the state log with
                # noise during real outages.
                log.debug(
                    "dispatcher heartbeat POST failed for session %s",
                    session_id, exc_info=True,
                )
            await asyncio.sleep(interval_seconds)
    finally:
        if own_client and hasattr(active, "aclose"):
            with contextlib.suppress(Exception):
                await active.aclose()
