"""Singleton Rich Console instance shared across claw-forge CLI modules.

Pre-decomposition, cli.py had one Console. The 8-PR decomposition gave each
new module its own Console (intentional, kept extraction PRs minimal).
This module consolidates them into one shared instance.
"""
from __future__ import annotations

from rich.console import Console

console = Console()

__all__ = ["console"]
