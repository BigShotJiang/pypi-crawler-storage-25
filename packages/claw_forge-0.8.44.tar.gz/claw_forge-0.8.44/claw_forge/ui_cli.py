"""Typer commands for the UI server (`ui` and `dev`).

Mirrors the top-level `claw_forge/export_cli.py` pattern — single file,
no domain package, hosts multiple commands as a Typer subapp.

Also owns `_build_session_redirect_js`, an HTML/JS helper used only by `ui`.
"""
from __future__ import annotations

import os
from collections.abc import AsyncGenerator
from pathlib import Path

import httpx
import typer

from claw_forge._console import console
from claw_forge.config import _load_env_file
from claw_forge.state.client import (
    _ensure_state_service,
    _port_in_use_error,
    _resolve_latest_session,
)

ui_app = typer.Typer(help="UI server commands")


def _build_session_redirect_js(session_id: str) -> str:
    """Return inline JS that redirects the SPA to ?session=<id> if not already set."""
    if not session_id:
        return ""
    return (
        f"if(!new URLSearchParams(location.search).get('session')&&"
        f"!location.hash){{"
        f"history.replaceState(null,'',location.pathname+'?session={session_id}');}}"
    )


@ui_app.command()
def ui(
    port: int = typer.Option(
        int(os.environ.get("CLAW_FORGE_UI_PORT", "5173")),
        "--port",
        "-p",
        help="Port for the Kanban UI",
    ),
    state_port: int = typer.Option(
        int(os.environ.get("CLAW_FORGE_STATE_PORT", "8420")),
        "--state-port",
        help="Port the state service is running on [default: 8420 or $CLAW_FORGE_STATE_PORT]",
    ),
    open_browser: bool = typer.Option(True, "--open/--no-open", help="Open browser automatically"),
    session: str = typer.Option("", "--session", "-s", help="Session UUID to open on the board"),
    project: str = typer.Option(
        ".", "--project", "-P", help="Project directory (to find .claw-forge/state.db)."
    ),
    dev: bool = typer.Option(
        False, "--dev", help="Use Vite dev server from source (requires Node.js)"
    ),
) -> None:
    """Launch the Kanban UI.

    By default serves the pre-built static bundle (no Node.js required).
    Pass --dev to use the Vite hot-reload dev server from the source tree.

    Examples:

        # Serve pre-built UI (works from pip install)
        claw-forge ui

        # Use Vite dev server (source checkout only)
        claw-forge ui --dev
    """
    import shutil
    import subprocess
    import threading
    import time
    import webbrowser

    url = f"http://localhost:{port}"
    if session:
        url += f"/?session={session}"
    # Note: for production mode, we also auto-detect the session from DB
    # and inject it via JS redirect (see _session_redirect below)

    # ── Dev mode (source checkout) ──────────────────────────────────────────
    if dev:
        ui_dir = Path(__file__).parent.parent / "ui"
        if not ui_dir.exists():
            console.print(
                "[red]ui/ source directory not found.[/red]\n"
                "[dim]--dev requires a source checkout. "
                "For pip installs run without --dev.[/dim]"
            )
            raise typer.Exit(1) from None
        if not shutil.which("node"):
            console.print("[red]Node.js not found. Install from https://nodejs.org/[/red]")
            raise typer.Exit(1) from None
        node_modules = ui_dir / "node_modules"
        if not node_modules.exists():
            console.print("[yellow]Installing UI dependencies (npm install)…[/yellow]")
            subprocess.run(["npm", "install"], cwd=ui_dir, check=True)  # noqa: S603, S607

        _session_id_dev = "(none — run `claw-forge run` to create a session)"
        _project_path_dev = Path(project).resolve()
        _dev_session = _resolve_latest_session(
            _project_path_dev / ".claw-forge" / "state.db",
            project_path=_project_path_dev,
        )
        if _dev_session:
            _session_id_dev = _dev_session

        console.print("[bold green]🔥 claw-forge Kanban UI (dev)[/bold green]")
        console.print(f"   UI:        [cyan]{url}[/cyan]")
        console.print(f"   State API: [cyan]http://localhost:{state_port}[/cyan]")
        console.print(f"   Session:   [yellow]{_session_id_dev}[/yellow]")
        console.print("   Press [bold]Ctrl+C[/bold] to stop\n")

        env = os.environ.copy()
        env["VITE_API_PORT"] = str(state_port)
        env["VITE_WS_PORT"] = str(state_port)

        if open_browser:
            def _open_dev() -> None:
                time.sleep(2)
                webbrowser.open(url)
            threading.Thread(target=_open_dev, daemon=True).start()

        subprocess.run(  # noqa: S603, S607
            ["npm", "run", "dev", "--", "--port", str(port), "--host"],
            cwd=ui_dir, env=env, check=False,
        )
        return

    # ── Production mode (pre-built static bundle, works from pip install) ───
    ui_dist = Path(__file__).parent / "ui_dist"
    if not ui_dist.exists():
        console.print(
            "[red]Pre-built UI bundle not found.[/red]\n"
            "[dim]This should not happen with a normal pip install. "
            "Try reinstalling: pip install --force-reinstall claw-forge[/dim]"
        )
        raise typer.Exit(1) from None

    try:
        import uvicorn
        from starlette.applications import Starlette
        from starlette.responses import Response
        from starlette.routing import Mount, Route
        from starlette.staticfiles import StaticFiles
    except ImportError:
        console.print(
            "[red]uvicorn / starlette not found.[/red]\n"
            "[dim]Install them: pip install uvicorn starlette[/dim]"
        )
        raise typer.Exit(1) from None

    # Auto-start state service if not already running.
    # Must happen BEFORE session resolution, HTML patching, and proxy setup
    # so that state_port reflects the actual port the service is on.
    # skip_version_restart: the UI is a read-only consumer — never kill a
    # running state service just because the CLI version differs.
    state_port = _ensure_state_service(
        Path(project).resolve(), state_port, skip_version_restart=True,
    )

    # Resolve session: explicit arg → latest from DB (filtered by project) → empty
    _project_path = Path(project).resolve()
    _resolved_session = session or _resolve_latest_session(
        _project_path / ".claw-forge" / "state.db", project_path=_project_path,
    )

    # Inject runtime config so the SPA knows where the state API lives
    index_html = (ui_dist / "index.html").read_text()
    _session_redirect = _build_session_redirect_js(_resolved_session)
    runtime_cfg = (
        f"<script>window.__CLAW_FORGE_STATE_PORT__={state_port};"
        f"window.__CLAW_FORGE_SESSION__='{_resolved_session}';"
        f"{_session_redirect}</script>"
    )
    patched_html = index_html.replace("</head>", runtime_cfg + "</head>", 1)

    async def serve_index(request: object) -> Response:
        return Response(patched_html, media_type="text/html")

    # Reverse proxy: forward /api/* and /ws* to the state service
    import websockets
    from starlette.requests import Request as StarletteRequest
    from starlette.responses import StreamingResponse
    from starlette.websockets import WebSocket as StarletteWebSocket

    state_base = f"http://localhost:{state_port}"
    # Use no read timeout for SSE streams; connect/write timeouts still apply.
    _proxy_client = httpx.AsyncClient(
        base_url=state_base,
        timeout=httpx.Timeout(connect=10.0, write=10.0, read=None, pool=10.0),
    )

    async def proxy_api(request: StarletteRequest) -> StreamingResponse:
        from starlette.responses import JSONResponse

        path = request.url.path  # e.g. /api/sessions/...
        backend_path = path[4:] if path.startswith("/api") else path  # strip /api prefix
        url = httpx.URL(path=backend_path, query=request.url.query.encode())
        try:
            body = await request.body()
        except Exception:  # noqa: BLE001 — client disconnected before body arrived
            return JSONResponse({"error": "Client disconnected"}, status_code=499)  # type: ignore[return-value]
        rp_req = _proxy_client.build_request(
            request.method,
            url,
            headers={k: v for k, v in request.headers.items() if k.lower() != "host"},
            content=body,
        )
        try:
            rp_resp = await _proxy_client.send(rp_req, stream=True)
        except httpx.ConnectError:
            return JSONResponse(  # type: ignore[return-value]
                {"error": "State service unavailable — still starting. Retry in a moment."},
                status_code=503,
            )
        except (httpx.TimeoutException, httpx.RemoteProtocolError, httpx.ReadError) as exc:
            return JSONResponse(  # type: ignore[return-value]
                {"error": f"State service error: {exc.__class__.__name__}"},
                status_code=502,
            )

        async def _stream_with_close() -> AsyncGenerator[bytes, None]:
            try:
                async for chunk in rp_resp.aiter_raw():
                    yield chunk
            finally:
                await rp_resp.aclose()

        return StreamingResponse(
            _stream_with_close(),
            status_code=rp_resp.status_code,
            headers=dict(rp_resp.headers),
            background=None,
        )

    async def proxy_ws(websocket: StarletteWebSocket) -> None:
        """Proxy WebSocket /ws and /ws/{session_id} to the state service."""
        import asyncio
        import contextlib

        from starlette.websockets import WebSocketState

        path = websocket.url.path
        ws_url = f"ws://localhost:{state_port}{path}"
        await websocket.accept()
        try:
            async with websockets.connect(ws_url) as backend_ws:
                async def _fw() -> None:
                    async for msg in backend_ws:
                        if websocket.client_state == WebSocketState.CONNECTED:
                            await websocket.send_text(
                                msg if isinstance(msg, str) else msg.decode()
                            )
                fwd_task = asyncio.create_task(_fw())
                try:
                    async for msg in websocket.iter_text():
                        await backend_ws.send(msg)
                finally:
                    fwd_task.cancel()
                    with contextlib.suppress(asyncio.CancelledError):
                        await fwd_task
        except Exception:  # noqa: BLE001
            pass
        finally:
            if websocket.client_state == WebSocketState.CONNECTED:
                with contextlib.suppress(Exception):
                    await websocket.close()

    from starlette.routing import WebSocketRoute

    static_app = Starlette(
        routes=[
            Route("/", serve_index),
            Route("/index.html", serve_index),
            Mount("/assets", StaticFiles(directory=str(ui_dist / "assets")), name="assets"),
            # Proxy API and WebSocket to state service
            Route("/api/{path:path}", proxy_api, methods=["GET", "POST", "PUT", "PATCH", "DELETE"]),
            WebSocketRoute("/ws", proxy_ws),
            WebSocketRoute("/ws/{session_id}", proxy_ws),
            # SPA fallback: any unknown path → index.html
            Route("/{path:path}", serve_index),
        ]
    )

    # Prefer --session arg; otherwise read latest from DB
    if session:
        _session_id_display = session
    else:
        _session_id_display = _resolve_latest_session(
            _project_path / ".claw-forge" / "state.db",
            project_path=_project_path,
        ) or "(none — run `claw-forge run` to create a session)"

    console.print("[bold green]🔥 claw-forge Kanban UI[/bold green]")
    console.print(f"   UI:        [cyan]{url}[/cyan]")
    console.print(f"   State API: [cyan]http://localhost:{state_port}[/cyan]")
    console.print(f"   Session:   [yellow]{_session_id_display}[/yellow]")
    console.print("   Press [bold]Ctrl+C[/bold] to stop\n")

    if open_browser:
        def _open_static() -> None:
            time.sleep(1)
            webbrowser.open(url)
        threading.Thread(target=_open_static, daemon=True).start()

    try:
        uvicorn.run(static_app, host="0.0.0.0", port=port, log_level="warning")  # noqa: S104
    except OSError as exc:
        if "Address already in use" in str(exc) or getattr(exc, "errno", None) in (48, 98):
            _port_in_use_error(port, "UI server")
        raise


@ui_app.command()
def dev(
    ui_port: int = typer.Option(
        int(os.environ.get("CLAW_FORGE_UI_PORT", "5173")),
        "--ui-port",
        help="Port for the Vite dev server",
    ),
    state_port: int = typer.Option(
        int(os.environ.get("CLAW_FORGE_STATE_PORT", "8420")),
        "--state-port",
        help="Port for the state service API",
    ),
    project: str = typer.Option(".", "--project", "-p", help="Project directory."),
    open_browser: bool = typer.Option(True, "--open/--no-open", help="Open browser automatically"),
    session: str = typer.Option("", "--session", "-s", help="Session UUID to open on the board"),
    run_agents: bool = typer.Option(
        False, "--run/--no-run",
        help="Also launch the agent orchestrator (claw-forge run) alongside the dev servers.",
    ),
) -> None:
    """Start both the API (with hot-reload) and the Kanban UI (Vite dev server).

    This is the recommended way to develop locally — a single command that
    runs the FastAPI state service with uvicorn --reload and the Vite HMR
    dev server side by side.  Both restart automatically on file changes.

    Examples:

        # Start everything with defaults
        claw-forge dev

        # Custom ports
        claw-forge dev --state-port 9000 --ui-port 3000

        # Also run agents (orchestrator + UI + state service together)
        claw-forge dev --project /path/to/project --run
    """
    import shutil
    import signal
    import subprocess
    import threading
    import time
    import webbrowser

    project_path = Path(project).resolve()
    # Load .env from the project directory so API keys are available
    _load_env_file(project_path)

    # ── Validate prerequisites ──────────────────────────────────────────────
    ui_dir = Path(__file__).parent.parent / "ui"
    if not ui_dir.exists():
        console.print(
            "[red]ui/ source directory not found.[/red]\n"
            "[dim]`claw-forge dev` requires a source checkout.[/dim]"
        )
        raise typer.Exit(1) from None
    if not shutil.which("node"):
        console.print("[red]Node.js not found. Install from https://nodejs.org/[/red]")
        raise typer.Exit(1) from None

    node_modules = ui_dir / "node_modules"
    if not node_modules.exists():
        console.print("[yellow]Installing UI dependencies (npm install)…[/yellow]")
        subprocess.run(["npm", "install"], cwd=ui_dir, check=True)  # noqa: S603, S607

    # ── Prepare state service database ──────────────────────────────────────
    db_path = project_path / ".claw-forge" / "state.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    db_url = f"sqlite+aiosqlite:///{db_path}"

    # ── Resolve session for display ─────────────────────────────────────────
    _session_id_dev = _resolve_latest_session(
        db_path, project_path=project_path,
    ) or "(none — run `claw-forge run` to create a session)"

    url = f"http://localhost:{ui_port}"
    if session:
        url += f"/?session={session}"

    console.print("[bold green]🔥 claw-forge dev (API + UI hot-reload)[/bold green]")
    console.print(f"   UI:        [cyan]{url}[/cyan]  (Vite HMR)")
    console.print(f"   State API: [cyan]http://localhost:{state_port}[/cyan]  (uvicorn --reload)")
    console.print(f"   Database:  [dim]{db_path}[/dim]")
    console.print(f"   Session:   [yellow]{_session_id_dev}[/yellow]")
    if run_agents:
        console.print("   Agents:    [green]enabled (--run)[/green]")
    else:
        console.print("   Agents:    [dim]disabled — pass --run to launch orchestrator[/dim]")
    console.print("   Press [bold]Ctrl+C[/bold] to stop all servers\n")

    # ── Launch state service with --reload ──────────────────────────────────
    state_env = os.environ.copy()
    state_env["CLAW_FORGE_DB_URL"] = db_url
    # start_new_session=True puts each child in its own process group so the
    # terminal's Ctrl-C SIGINT doesn't reach them directly.  _shutdown() is
    # the sole signal path — it posts /shutdown for a graceful WAL checkpoint,
    # then terminates each process individually.
    state_proc = subprocess.Popen(  # noqa: S603, S607
        [
            "claw-forge", "state",
            "--project", str(project_path),
            "--port", str(state_port),
            "--reload",
        ],
        env=state_env,
        start_new_session=True,
    )

    # ── Launch Vite dev server ──────────────────────────────────────────────
    ui_env = os.environ.copy()
    ui_env["VITE_API_PORT"] = str(state_port)
    ui_env["VITE_WS_PORT"] = str(state_port)
    ui_proc = subprocess.Popen(  # noqa: S603, S607
        ["npm", "run", "dev", "--", "--port", str(ui_port), "--host"],
        cwd=ui_dir,
        env=ui_env,
        start_new_session=True,
    )

    # ── Optionally launch the agent orchestrator ─────────────────────────────
    run_proc: subprocess.Popen[bytes] | None = None
    if run_agents:
        # Give the state service a moment to start before the orchestrator connects
        time.sleep(2)
        run_env = os.environ.copy()
        run_env["CLAW_FORGE_STATE_PORT"] = str(state_port)
        run_proc = subprocess.Popen(  # noqa: S603, S607
            ["claw-forge", "run", "--project", str(project_path)],
            env=run_env,
            start_new_session=True,
        )

    # ── Open browser after a short delay ────────────────────────────────────
    if open_browser:
        def _open_browser() -> None:
            time.sleep(3)
            webbrowser.open(url)
        threading.Thread(target=_open_browser, daemon=True).start()

    # ── Wait for either process to exit or Ctrl+C ──────────────────────────
    def _shutdown(*_args: object) -> None:
        # Ask the state service to shut down gracefully first so it can
        # run the PASSIVE WAL checkpoint in lifespan teardown.
        try:
            import urllib.request as _req
            _req.urlopen(  # noqa: S310
                _req.Request(
                    f"http://127.0.0.1:{state_port}/shutdown", method="POST"
                ),
                timeout=3,
            )
            # Give the lifespan teardown time to complete the WAL checkpoint
            # and dispose the engine before we kill the process group.
            time.sleep(2)
        except Exception:  # noqa: BLE001
            pass
        procs = [p for p in (run_proc, ui_proc, state_proc) if p is not None]
        for proc in procs:
            if proc.poll() is None:
                # Children run in their own session (start_new_session=True).
                # Kill the whole process group to reach both supervisor and
                # worker subprocesses.
                try:
                    os.killpg(proc.pid, signal.SIGTERM)
                except OSError:
                    proc.terminate()

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    try:
        # Wait for any watched process to finish
        watched = [p for p in (run_proc, ui_proc, state_proc) if p is not None]
        while all(p.poll() is None for p in watched):
            time.sleep(0.5)
    except KeyboardInterrupt:
        pass
    finally:
        _shutdown()
        for p in [p for p in (run_proc, ui_proc, state_proc) if p is not None]:
            p.wait()
        console.print("\n[dim]All servers stopped.[/dim]")
