"""Typer command for inspecting the provider pool.

Single command (`pool-status`). cli.py registers it via:
    app.command(name="pool-status")(pool_status)

so the function here is NOT decorated with @app.command().
Importing it from cli.py is the wiring step.
"""
from __future__ import annotations

import typer
from rich.table import Table

from claw_forge._console import console
from claw_forge.config import _load_config
from claw_forge.pool.providers.registry import load_configs_from_yaml


def pool_status(
    config: str = typer.Option("claw-forge.yaml", "--config", "-c"),
) -> None:
    """Show provider pool status."""
    cfg = _load_config(config)
    configs = load_configs_from_yaml(cfg)

    table = Table(title="Provider Pool")
    table.add_column("Name")
    table.add_column("Type")
    table.add_column("Priority")
    table.add_column("Enabled")
    table.add_column("Cost (in/out $/Mtok)")

    for c in configs:
        table.add_row(
            c.name,
            c.provider_type.value,
            str(c.priority),
            "✅" if c.enabled else "❌",
            f"${c.cost_per_mtok_input}/{c.cost_per_mtok_output}",
        )
    console.print(table)
