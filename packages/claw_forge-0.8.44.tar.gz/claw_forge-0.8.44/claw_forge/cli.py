"""Typer entrypoint for claw-forge.

Top-level commands live in their domain packages (post 8-PR decomposition):

- run, pool-status        → orchestrator/, pool/
- plan, validate-spec,    → spec/
  import
- status, state, pause,   → state/
  resume, input, add
- merge                   → git/
- ui, dev                 → ui_cli.py
- fix                     → bugfix/
- boundaries, worktrees,  → boundaries/, git/, training/, export_cli.py
  stash, traces, export

This module owns:
- The Typer `app` instance + subapp/command registration.
- Two residue commands: `version` and `init`.
- Back-compat re-exports of test-imported helpers from their new homes
  (pinned by tests/test_cli_shim_completeness.py).
"""

from __future__ import annotations

from pathlib import Path

import typer

from claw_forge import __version__
from claw_forge._console import console

# Back-compat shim — these helpers moved to claw_forge.config; tests import them from here.
from claw_forge.config import (
    _DEFAULT_CONFIG_YAML,  # noqa: F401
    _DEFAULT_ENV_EXAMPLE,
    _expand_env_vars,  # noqa: F401
    _load_config,
    _load_env_file,  # noqa: F401
    _scaffold_config,  # noqa: F401
)

# Back-compat shim — run-command helpers moved to claw_forge.orchestrator.task_handler;
# tests import them from here (test_cli_merge_gating, test_cli_file_claims,
# test_resolve_sdk_credentials, tests/git/test_dispatcher_git).
from claw_forge.orchestrator.task_handler import (
    _create_and_sync_worktree,  # noqa: F401
    _resolve_sdk_credentials,  # noqa: F401
    _set_merged_after_merge,  # noqa: F401
    _try_claim_files,  # noqa: F401
)

# Back-compat shim — _write_plan_to_db moved to claw_forge.spec.cli; tests import from here.
from claw_forge.spec.cli import _write_plan_to_db  # noqa: F401

# Back-compat shim — these helpers moved to claw_forge.state.client; tests import them from here.
from claw_forge.state.client import (
    _count_sessions_and_tasks,  # noqa: F401
    _decorate_resumable,  # noqa: F401
    _ensure_state_service,  # noqa: F401
    _http_get,  # noqa: F401
    _http_post,  # noqa: F401
    _list_sessions_for_help,  # noqa: F401
    _port_in_use_error,  # noqa: F401
    _print_session_hints,  # noqa: F401
    _resolve_latest_session,  # noqa: F401
    _resolve_project_root,  # noqa: F401
    _session_exists,  # noqa: F401
    _state_url,  # noqa: F401
    _task_dict_to_node,  # noqa: F401
)

app = typer.Typer(name="claw-forge", help="Multi-provider autonomous coding agent harness")

# Register subapps
from claw_forge.boundaries.cli import boundaries_app  # noqa: E402
from claw_forge.bugfix.cli import fix as _fix_cmd  # noqa: E402
from claw_forge.export_cli import export_app  # noqa: E402
from claw_forge.git.cli import worktrees_app  # noqa: E402
from claw_forge.git.merge_cli import merge as _merge_cmd  # noqa: E402
from claw_forge.git.stash_cli import stash_app  # noqa: E402
from claw_forge.orchestrator.run_cli import run as _run_cmd  # noqa: E402
from claw_forge.pool.cli import pool_status as _pool_status_cmd  # noqa: E402
from claw_forge.spec.cli import spec_app  # noqa: E402
from claw_forge.state.cli import state_app  # noqa: E402
from claw_forge.training.cli import traces_app  # noqa: E402
from claw_forge.ui_cli import ui_app  # noqa: E402

app.add_typer(boundaries_app, name="boundaries")
app.add_typer(export_app, name="export")
app.add_typer(spec_app)  # no name= — commands surface as top-level
app.add_typer(state_app)  # no name= — commands surface as top-level
app.add_typer(stash_app, name="stash")
app.add_typer(traces_app, name="traces")
app.add_typer(worktrees_app, name="worktrees")
app.add_typer(ui_app)  # no name= — ui + dev surface as top-level
app.command(name="pool-status")(_pool_status_cmd)
app.command(name="fix")(_fix_cmd)
app.command(name="merge")(_merge_cmd)
app.command(name="run")(_run_cmd)


# ── Commands ──────────────────────────────────────────────────────────────────


def _scaffold_container_isolation(project_path: Path, config_path: Path) -> None:
    """Write ``.claw-forge/agent.Dockerfile`` + flip ``agent.isolation`` to
    ``container`` in *config_path*.

    Called when the user passes ``claw-forge init --container``.  Idempotent —
    safe to re-run; existing Dockerfile is left alone, and the yaml flip is a
    no-op if already set.  Operators who want a custom stack edit the
    Dockerfile in place; the dispatcher's content-hash auto-build picks up
    changes on the next ``claw-forge run``.

    The yaml edit is line-based (substring replace) rather than yaml-roundtrip
    because (a) we want to preserve the rich comments in the scaffolded yaml
    and (b) yaml.safe_dump would discard them.  The literal we replace is
    pinned in ``config.py:_DEFAULT_CONFIG_YAML`` so this stays a one-line
    contract — if the default ever changes shape, both lines move together.
    """
    from claw_forge.agent.container import _DEFAULT_AGENT_DOCKERFILE

    # 1. Write the Dockerfile (only if absent — preserve operator customisations).
    dockerfile_dir = project_path / ".claw-forge"
    dockerfile_dir.mkdir(parents=True, exist_ok=True)
    dockerfile_path = dockerfile_dir / "agent.Dockerfile"
    if not dockerfile_path.exists():
        dockerfile_path.write_text(_DEFAULT_AGENT_DOCKERFILE)
        console.print(
            f"[green]✓ Wrote {dockerfile_path.relative_to(project_path)}"
            f"[/green]  (edit to customise; rebuild auto-triggers)",
        )
    else:
        console.print(
            f"[dim]✓ {dockerfile_path.relative_to(project_path)} "
            f"already exists — preserved[/dim]",
        )

    # 2. Flip ``isolation: sandbox`` → ``isolation: container`` in the yaml.
    #    The scaffolded yaml's line is ``  isolation: sandbox     # sandbox |
    #    container | process (alias)``; replacing just ``isolation: sandbox``
    #    is sufficient and survives operator-edited inline comments.
    if config_path.exists():
        content = config_path.read_text()
        if "isolation: sandbox" in content:
            content = content.replace(
                "isolation: sandbox", "isolation: container", 1,
            )
            config_path.write_text(content)
            console.print(
                f"[green]✓ Set agent.isolation: container in "
                f"{config_path.name}[/green]",
            )
        elif "isolation: container" in content:
            console.print(
                f"[dim]✓ agent.isolation: container already set in "
                f"{config_path.name}[/dim]",
            )
        else:
            console.print(
                f"[yellow]⚠ Couldn't find agent.isolation: in "
                f"{config_path.name} — set it manually to 'container'.[/yellow]",
            )

    console.print(
        "\n[bold cyan]Next step:[/bold cyan] run [bold]claw-forge run[/bold]\n"
        "  The dispatcher will auto-build the agent image on first dispatch\n"
        "  (Docker or Podman must be installed).  Subsequent runs use the\n"
        "  cached image; editing the Dockerfile triggers a rebuild.\n"
    )


@app.command()
def version() -> None:
    """Print version."""
    console.print(f"claw-forge {__version__}")


@app.command()
def init(
    project: str = typer.Option(".", "--project", "-p", help="Project directory to bootstrap"),
    config: str = typer.Option(
        "claw-forge.yaml", "--config", "-c",
        help="Path to claw-forge.yaml (created if absent).",
    ),
    container: bool = typer.Option(
        False, "--container",
        help=(
            "Scaffold per-agent container isolation: write "
            ".claw-forge/agent.Dockerfile and flip agent.isolation: container "
            "in the generated claw-forge.yaml.  The dispatcher auto-builds "
            "the image on first `claw-forge run` and re-uses it via content-"
            "hash tags.  Customise the Dockerfile in place; edits trigger "
            "a transparent rebuild."
        ),
    ),
) -> None:
    """Bootstrap a project — scaffold .claude/, CLAUDE.md, and claw-forge.yaml.

    Run this once in a new project directory before writing your spec.
    It installs the /create-spec and other Claude slash commands, then guides
    you to the next step.

    Examples:

        # Bootstrap current directory
        claw-forge init

        # Bootstrap a specific directory
        claw-forge init --project ~/projects/my-app

        # Bootstrap with container isolation (Docker/Podman required)
        claw-forge init --container
    """
    from claw_forge.scaffold import scaffold_project

    project_path = Path(project).resolve()
    project_path.mkdir(parents=True, exist_ok=True)
    if config == "claw-forge.yaml":
        config = str(project_path / "claw-forge.yaml")

    _load_config(config, auto_scaffold=True)

    if container:
        _scaffold_container_isolation(project_path, Path(config))

    # Always ensure .env.example exists alongside the config — even when
    # claw-forge.yaml was already present (so _scaffold_config was skipped).
    env_example = Path(config).parent / ".env.example"
    if not env_example.exists():
        env_example.write_text(_DEFAULT_ENV_EXAMPLE)
        console.print(
            f"[green]✓ Created {env_example}[/green]  (copy to .env and fill keys)"
        )

    scaffold = scaffold_project(project_path)
    console.print(
        f"✓ Stack detected: {scaffold['stack'].get('language', 'unknown')} / "
        f"{scaffold['stack'].get('framework', 'unknown')}"
    )
    if scaffold["claude_md_written"]:
        console.print("✓ Generated CLAUDE.md (tailored to your stack)")
    if scaffold["dot_claude_created"]:
        console.print("✓ Created .claude/ with settings.json")
    else:
        console.print("[dim]✓ .claude/ already exists — skipped[/dim]")
    if scaffold["commands_copied"]:
        console.print(
            f"✓ Scaffolded {len(scaffold['commands_copied'])} slash commands → .claude/commands/"
        )
        for cmd in scaffold["commands_copied"]:
            console.print(f"  • /{Path(cmd).stem}")

    if scaffold["spec_example_written"]:
        console.print("✓ Created app_spec.example.xml  (reference format for your spec)")

    if scaffold["git_initialized"]:
        console.print("✓ Initialized git repository")
    else:
        console.print("[dim]✓ Git repository already exists — skipped[/dim]")

    # Guide user to next step
    spec_file = project_path / "app_spec.txt"
    xml_spec_file = project_path / "additions_spec.xml"
    if not spec_file.exists() and not xml_spec_file.exists():
        console.print(
            "\n[bold cyan]Next step:[/bold cyan] create your project spec.\n"
            "  Option A — use the Claude slash command:\n"
            "    Open Claude Code here and run [bold]/create-spec[/bold]\n\n"
            "  Option B — paste your PRD into Claude with this prompt:\n"
            '    "Convert this PRD to claw-forge XML spec format.\n'
            "     Use app_spec.example.xml in this directory as the template.\n"
            '     Write the result to app_spec.txt."\n\n'
            "  Then run: [bold]claw-forge validate-spec --strict-shape app_spec.txt[/bold]\n"
            "  Then run: [bold]claw-forge plan app_spec.txt[/bold]"
        )
    else:
        found = spec_file if spec_file.exists() else xml_spec_file
        console.print(
            f"\n[bold cyan]Spec found:[/bold cyan] {found.name}\n"
            f"  Run: [bold]claw-forge validate-spec --strict-shape {found.name}[/bold]\n"
            f"  Run: [bold]claw-forge plan {found.name}[/bold]"
        )


if __name__ == "__main__":
    app()
