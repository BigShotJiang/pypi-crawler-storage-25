"""Typer commands for spec processing.

Owns three top-level claw-forge commands: `plan` (seeds the task DAG
from app_spec.{txt,xml}), `validate-spec` (Layer 4 shape validator),
and `import` (imports a spec from a remote URL or path).

Also owns `_write_plan_to_db` — the helper that writes a parsed
ProjectSpec into the state-service DB. `_write_plan_to_db` is
re-exported by `claw_forge.cli` for test back-compat.
"""
from __future__ import annotations

import asyncio
import os
import pathlib
from pathlib import Path
from typing import Any

import typer
from rich.table import Table

from claw_forge._console import console
from claw_forge.config import _load_config
from claw_forge.pool.model_resolver import resolve_model
from claw_forge.pool.providers.registry import load_configs_from_yaml
from claw_forge.state.client import _resolve_project_root

spec_app = typer.Typer(help="Spec processing commands")


async def _write_plan_to_db(
    project_path: Path,
    project_name: str,  # noqa: ARG001
    features: list[dict[str, Any]],
    *,
    fresh: bool = False,
) -> dict[str, int]:
    """Persist parsed features as pending tasks, reconciling with existing state.

    By default, finds the existing session for *project_path* and only inserts
    features that don't already have a matching task (by description).  Existing
    completed/failed/pending tasks are left untouched.

    Pass ``fresh=True`` to force a brand-new session with all tasks from scratch.

    Returns a summary dict: ``{existing_completed, existing_pending, …, new}``.
    """
    import uuid

    from sqlalchemy import select
    from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

    from claw_forge.state.models import Base, Task
    from claw_forge.state.models import Session as DbSession

    claw_forge_dir = project_path / ".claw-forge"
    claw_forge_dir.mkdir(parents=True, exist_ok=True)
    db_path = claw_forge_dir / "state.db"
    db_url = f"sqlite+aiosqlite:///{db_path}"

    engine = create_async_engine(db_url, echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async_session = async_sessionmaker(engine, expire_on_commit=False)
    async with async_session() as db:
        # ── Find or create session ────────────────────────────────────────
        session_id: str | None = None
        existing_by_desc: dict[str, Task] = {}

        if not fresh:
            result = await db.execute(
                select(DbSession)
                .where(DbSession.project_path == str(project_path))
                .where(DbSession.status.in_(["running", "pending"]))
                .order_by(DbSession.created_at.desc())
                .limit(1)
            )
            existing_session = result.scalar_one_or_none()
            if existing_session is not None:
                session_id = existing_session.id
                # Load existing tasks keyed by description for matching
                task_result = await db.execute(
                    select(Task).where(Task.session_id == session_id)
                )
                for t in task_result.scalars():
                    if t.description:
                        existing_by_desc[t.description] = t

        if session_id is None:
            session_id = str(uuid.uuid4())
            db_sess = DbSession(
                id=session_id,
                project_path=str(project_path),
                status="pending",
            )
            db.add(db_sess)
            await db.flush()

        # ── Build index→UUID map (existing tasks reuse their UUID) ────────
        index_to_uuid: dict[int, str] = {}
        new_indices: set[int] = set()

        for feat in features:
            desc = f"{feat['name']}: {feat['description']}"
            existing = existing_by_desc.get(desc)
            if existing is not None:
                index_to_uuid[feat["index"]] = existing.id
            else:
                index_to_uuid[feat["index"]] = str(uuid.uuid4())
                new_indices.add(feat["index"])

        # ── Create only the NEW tasks ─────────────────────────────────────
        for feat in features:
            if feat["index"] not in new_indices:
                continue
            task_id = index_to_uuid[feat["index"]]
            cross_deps = [
                index_to_uuid[i]
                for i in feat.get("depends_on_indices", [])
                if i in index_to_uuid
            ]
            db.add(Task(
                id=task_id,
                session_id=session_id,
                plugin_name="coding",
                description=f"{feat['name']}: {feat['description']}",
                category=feat.get("category"),
                steps=feat.get("steps", []),
                status="pending",
                priority=feat.get("index", 0),
                depends_on=cross_deps,
                shape=feat.get("shape"),
                plugin=feat.get("plugin"),
                touches_files=feat.get("touches_files", []) or [],
            ))

        await db.commit()

    await engine.dispose()

    # ── Build summary ─────────────────────────────────────────────────────
    from collections import Counter
    status_counts = Counter(t.status for t in existing_by_desc.values())
    return {
        "existing_completed": status_counts.get("completed", 0),
        "existing_pending": status_counts.get("pending", 0),
        "existing_failed": status_counts.get("failed", 0),
        "existing_other": sum(
            v for k, v in status_counts.items()
            if k not in ("completed", "pending", "failed")
        ),
        "new": len(new_indices),
    }


@spec_app.command()
def plan(
    spec: str = typer.Argument(..., help="Path to app_spec.txt or additions_spec.xml."),
    project: str = typer.Option(".", "--project", "-p", help="Project directory."),
    model: str = typer.Option(
        "claude-opus-4-6", "--model", "-m",
        help=(
            "Model to use. Supported formats:\n"
            "  claude-opus-4-6                      bare model (pool picks provider)\n"
            "  anthropic-proxy-1/claude-opus-4-6    pin to specific provider\n"
            "  opus                                 alias from model_aliases in config\n"
            "Defaults to Opus — planning is the most critical step."
        ),
    ),
    concurrency: int = typer.Option(
        5, "--concurrency", "-n",
        help="Max parallel agents when running (saved as hint in output).",
    ),
    config: str = typer.Option(
        "claw-forge.yaml", "--config", "-c",
        help="Path to claw-forge.yaml config file.",
    ),
    fresh: bool = typer.Option(
        False, "--fresh",
        help=(
            "Force a fresh session — ignore existing tasks and create all from scratch. "
            "Without this flag, plan reconciles with the existing session: completed tasks "
            "are kept, and only new/missing features are added."
        ),
    ),
) -> None:
    """Parse a spec file and generate the feature DAG in the state database.

    Reads app_spec.txt (or additions_spec.xml for brownfield), decomposes it into
    atomic features, assigns dependencies, and writes the task graph to the DB.
    Uses Opus by default — errors in planning cascade through every agent run.

    By default, reconciles with the existing session: completed tasks are preserved,
    and only features missing from the DB are added as new pending tasks.  Use
    ``--fresh`` to start a brand-new session with all tasks from scratch.

    Examples:

        # Parse spec and build feature DAG (reconciles with existing)
        claw-forge plan app_spec.txt

        # Force a clean slate
        claw-forge plan app_spec.txt --fresh

        # Use Sonnet if cost matters more than planning quality
        claw-forge plan app_spec.txt --model claude-sonnet-4-5

        # Brownfield additions
        claw-forge plan additions_spec.xml --concurrency 3
    """
    from claw_forge.plugins.base import PluginContext
    from claw_forge.plugins.initializer import InitializerPlugin

    project_path = Path(project).resolve()
    if config == "claw-forge.yaml":
        config = str(project_path / "claw-forge.yaml")

    cfg = _load_config(config)
    resolved = resolve_model(model, cfg)
    if resolved.alias_resolved:
        console.print(f"[dim]Model alias '{model}' → {resolved.model_id}[/dim]")
    if resolved.provider_hint:
        console.print(f"[dim]Provider pinned: {resolved.provider_hint}[/dim]")
    model = resolved.model_id  # noqa: F841

    spec_path = Path(spec)
    if not spec_path.is_absolute():
        spec_path = project_path / spec
    if not spec_path.exists():
        console.print(f"[red]Spec file not found: {spec_path}[/red]")
        raise typer.Exit(1) from None

    console.print(f"[dim]Project: {project_path}[/dim]")
    console.print(f"[dim]DB: {project_path / '.claw-forge' / 'state.db'}[/dim]")

    plugin = InitializerPlugin()
    ctx = PluginContext(project_path=str(project_path), session_id="plan", task_id="plan")
    ctx.metadata = {"spec_file": str(spec_path)}
    result = asyncio.run(plugin.execute(ctx))

    if result.success:
        meta = result.metadata

        # ── Write tasks to DB so `claw-forge run` can find them ──────────────
        features = meta.get("features", [])
        if features:
            summary = asyncio.run(_write_plan_to_db(
                project_path, meta["project_name"], features, fresh=fresh,
            ))
            _existing_keys = (
                "existing_completed", "existing_pending",
                "existing_failed", "existing_other",
            )
            _has_existing = any(summary.get(k, 0) for k in _existing_keys)
            if summary.get("new", 0) > 0 and not fresh and _has_existing:
                n_done = summary["existing_completed"]
                n_pend = summary["existing_pending"]
                n_fail = summary["existing_failed"]
                n_other = summary.get("existing_other", 0)
                n_new = summary["new"]
                console.print("\n[bold]Reconciled with existing session:[/bold]")
                if n_done:
                    console.print(f"  [green]{n_done} completed[/green]  (kept)")
                if n_pend:
                    console.print(f"  [yellow]{n_pend} pending[/yellow]    (kept)")
                if n_fail:
                    console.print(f"  [red]{n_fail} failed[/red]     (kept)")
                if n_other:
                    console.print(f"  [dim]{n_other} other[/dim]      (kept)")
                console.print(f"  [bold cyan]{n_new} new[/bold cyan]        (added)")

        if "feature_count" in meta:
            console.print(f"\n[bold green]✅ Spec parsed: {meta['project_name']}[/bold green]")
            console.print(f"   {result.output}\n")

            category_counts = meta.get("category_counts", {})
            if category_counts:
                cat_table = Table(title="Features by Category")
                cat_table.add_column("Category", style="cyan")
                cat_table.add_column("Count", justify="right", style="bold")
                for cat, count in sorted(category_counts.items(), key=lambda x: -x[1]):
                    cat_table.add_row(cat, str(count))
                cat_table.add_row("[bold]Total[/bold]", f"[bold]{meta['feature_count']}[/bold]")
                console.print(cat_table)

            wave_count = meta.get("wave_count", 0)
            console.print(f"\n   [bold]Dependency waves:[/bold] {wave_count}")

            feature_count = meta.get("feature_count", 0)
            if feature_count > 0 and concurrency > 0:
                est_minutes = (feature_count * 2) / concurrency
                est_str = (
                    f"{est_minutes:.0f} minutes"
                    if est_minutes < 60
                    else f"{est_minutes / 60:.1f} hours"
                )
                console.print(
                    f"   [bold]Estimated run time:[/bold] ~{est_str} "
                    f"(at concurrency={concurrency})"
                )

            phases = meta.get("phases", [])
            if phases:
                console.print(f"\n   [bold]Implementation phases ({len(phases)}):[/bold]")
                for i, phase in enumerate(phases, 1):
                    console.print(f"     {i}. {phase}")

            console.print(
                f"\n   Next steps:"
                f"\n     1. [bold]claw-forge run --project {project_path}"
                f" --concurrency {concurrency}[/bold]"
                f"\n     2. [bold]claw-forge ui  --project {project_path}[/bold]"
                f"  ← open Kanban board"
            )
        else:
            console.print("[green]Plan complete[/green]")
            for k, v in meta.items():
                if k != "features":
                    console.print(f"  {k}: {v}")
    else:
        console.print(f"[red]Planning failed: {result.output}[/red]")
        raise typer.Exit(1) from None


@spec_app.command("validate-spec")
def validate_spec_cmd(
    spec: str = typer.Argument(..., help="Path to app_spec.txt or additions_spec.xml."),
    no_llm: bool = typer.Option(
        False, "--no-llm",
        help="Skip Layer 2 adversarial LLM evaluation (Layer 1 + Layer 3 only).",
    ),
    threshold: float = typer.Option(
        7.0, "--threshold", "-t",
        help="Layer 2 LLM approval threshold (0-10). Default: 7.0.",
    ),
    model: str = typer.Option(
        "claude-haiku-4-5-20251001", "--model", "-m",
        help="Model for Layer 2 LLM evaluation.",
    ),
    strict_shape: bool = typer.Option(
        False, "--strict-shape",
        help="Promote shape WARNINGs (gaps 3, 5, 6) to ERRORs.",
    ),
    allow_soft_migration_shape: bool = typer.Option(
        False, "--allow-soft-migration-shape",
        help=(
            "Keep Gap 8 (migration-shape candidate) at WARNING severity "
            "instead of the v0.8.23+ default of ERROR.  Use during "
            "migration on-ramp."
        ),
    ),
    project_root: pathlib.Path | None = typer.Option(  # noqa: B008,UP007
        None, "--project-root",
        help="Override auto-detected project root for filesystem-aware shape checks.",
    ),
) -> None:
    """Validate a spec file before planning.

    Runs 4 validation layers and exits non-zero if errors are found:

      Layer 1 — Structural: action verbs, measurable outcomes, atomicity, vagueness
      Layer 2 — LLM:        adversarial per-category scoring (requires ANTHROPIC_API_KEY)
      Layer 3 — Coverage:   cross-references endpoints and tables against bullets
      Layer 4 — Shape:      architectural-shape coherence (typos, plugin completeness,
                            core/plugin overlap, brownfield directory existence,
                            vertical-category nudges, long core chains)

    Examples:

        claw-forge validate-spec app_spec.txt
        claw-forge validate-spec app_spec.txt --no-llm
        claw-forge validate-spec app_spec.txt --threshold 8.0
        claw-forge validate-spec app_spec.txt --strict-shape
    """
    from claw_forge.spec.parser import ProjectSpec
    from claw_forge.spec.validator import IssueSeverity, validate_spec

    spec_path = Path(spec)
    if not spec_path.exists():
        console.print(f"[red]Spec file not found: {spec_path}[/red]")
        raise typer.Exit(1)

    try:
        parsed = ProjectSpec.from_file(spec_path)
    except Exception as exc:
        console.print(f"[red]Failed to parse spec: {exc}[/red]")
        raise typer.Exit(1) from exc

    resolved_project_root = _resolve_project_root(spec_path, override=project_root)

    shape_annotated = sum(1 for f in parsed.features if f.shape)
    shape_unannotated = len(parsed.features) - shape_annotated

    console.print(f"\n[bold]Validating:[/bold] {spec_path.name}")
    console.print(f"  Features:   {len(parsed.features)}")
    console.print(f"  Categories: {len({f.category for f in parsed.features})}")
    console.print(f"  Endpoints:  {sum(len(v) for v in parsed.api_endpoints.values())}")
    console.print(f"  Tables:     {len(parsed.database_tables)}")
    console.print(f"  Shape:      {shape_annotated} annotated, {shape_unannotated} unannotated")
    console.print()

    run_llm = not no_llm
    report = validate_spec(
        parsed,
        run_llm=run_llm,
        approve_threshold=threshold,
        llm_model=model,
        strict_shape=strict_shape,
        project_root=resolved_project_root,
        allow_soft_migration_shape=allow_soft_migration_shape,
    )

    # ── Layer 1 ──────────────────────────────────────────────────────────────
    l1 = report.layer_issues(1)
    l1_errors = [i for i in l1 if i.severity == IssueSeverity.ERROR]
    l1_warnings = [i for i in l1 if i.severity == IssueSeverity.WARNING]
    status_l1 = "[red]FAIL[/red]" if l1_errors else "[green]PASS[/green]"
    console.print(
        f"Layer 1 (Structural)  {status_l1}  "
        f"{len(l1_errors)} errors, {len(l1_warnings)} warnings"
    )
    for issue in l1_errors:
        console.print(f"  [red]✗[/red] [{issue.category}] {issue.message}")
        if issue.suggestion:
            console.print(f"    → {issue.suggestion}")
        console.print(f'    Bullet: "{issue.bullet[:80]}"')
    for issue in l1_warnings[:5]:
        console.print(f"  [yellow]⚠[/yellow] [{issue.category}] {issue.message}")
    if len(l1_warnings) > 5:
        console.print(f"  [dim]... and {len(l1_warnings) - 5} more warnings[/dim]")

    # ── Layer 2 ──────────────────────────────────────────────────────────────
    l2 = report.layer_issues(2)
    if not run_llm:
        console.print("\nLayer 2 (LLM eval)    [dim]skipped (--no-llm)[/dim]")
    elif any("skipped" in i.message.lower() or "ANTHROPIC_API_KEY" in i.message for i in l2):
        for issue in l2:
            console.print(f"\n  [dim]{issue.message}[/dim]")
    else:
        l2_fails = [i for i in l2 if i.category]
        status_l2 = "[red]FAIL[/red]" if l2_fails else "[green]PASS[/green]"
        console.print(f"\nLayer 2 (LLM eval)    {status_l2}")
        for cat, score in report.category_scores.items():
            mark = "[green]✓[/green]" if score >= threshold else "[yellow]⚠[/yellow]"
            console.print(f"  {mark} {cat}: {score:.1f}/10")
        for issue in l2_fails:
            console.print(f"  [yellow]⚠[/yellow] {issue.message}")

    # ── Layer 3 ──────────────────────────────────────────────────────────────
    l3 = report.layer_issues(3)
    status_l3 = "[yellow]GAPS[/yellow]" if l3 else "[green]PASS[/green]"
    console.print(f"\nLayer 3 (Coverage)    {status_l3}  {len(l3)} gaps")
    for issue in l3:
        console.print(f"  [yellow]⚠[/yellow] {issue.message}")
        if issue.suggestion:
            console.print(f"    → {issue.suggestion}")

    # ── Layer 4 ──────────────────────────────────────────────────────────────
    l4 = report.layer_issues(4)
    l4_errors = [i for i in l4 if i.severity == IssueSeverity.ERROR]
    l4_warnings = [i for i in l4 if i.severity == IssueSeverity.WARNING]
    if l4_errors:
        status_l4 = "[red]FAIL[/red]"
    elif l4_warnings:
        status_l4 = "[yellow]WARN[/yellow]"
    else:
        status_l4 = "[green]PASS[/green]"
    console.print(
        f"\nLayer 4 (Shape)       {status_l4}  "
        f"{len(l4_errors)} errors, {len(l4_warnings)} warnings"
    )
    if resolved_project_root is None:
        console.print(
            "  [dim]filesystem checks skipped "
            "(no project root detected — pass --project-root to enable)[/dim]"
        )
    for issue in l4_errors:
        console.print(f"  [red]✗[/red] [{issue.category}] {issue.message}")
        if issue.suggestion:
            console.print(f"    → {issue.suggestion}")
        if issue.bullet:
            console.print(f'    Bullet: "{issue.bullet[:80]}"')
    for issue in l4_warnings:
        console.print(f"  [yellow]⚠[/yellow] [{issue.category}] {issue.message}")
        if issue.suggestion:
            console.print(f"    → {issue.suggestion}")

    # ── Verdict ───────────────────────────────────────────────────────────────
    # Preserve --strict-shape on the re-run hints so users tightening shape
    # coverage don't have to remember to re-add the flag every iteration.
    rerun_flags = " --strict-shape" if strict_shape else ""
    console.print()
    if report.passed:
        if report.warning_count:
            w = report.warning_count
            console.print(
                f"[bold yellow]⚠ Spec passed validation with {w} warning(s)[/bold yellow]"
            )
            console.print(
                f"\n  To clean up warnings: open Claude Code and run [bold]/fix-spec[/bold]\n"
                f"  Then re-run: [bold]claw-forge validate-spec{rerun_flags} {spec}[/bold]\n"
                f"\n  Or skip straight to: [bold]claw-forge plan {spec}[/bold]"
            )
        else:
            console.print("[bold green]✅ Spec passed validation — no issues[/bold green]")
            console.print(f"\n  Next: [bold]claw-forge plan {spec}[/bold]")
    else:
        console.print(
            f"[bold red]✗ Spec has {report.error_count} error(s) "
            f"— fix before running claw-forge plan[/bold red]"
        )
        console.print(
            f"\n  To fix: open Claude Code and run [bold]/fix-spec[/bold]\n"
            f"  Then re-run: [bold]claw-forge validate-spec{rerun_flags} {spec}[/bold]"
        )
        raise typer.Exit(1)


@spec_app.command("import")
def import_spec_cmd(
    path: str = typer.Argument(..., help="Path to harness output folder or file."),
    project: str = typer.Option(".", "--project", "-p", help="Project directory."),
    model: str = typer.Option("claude-opus-4-6", "--model", "-m", help="Model for conversion."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
    config: str = typer.Option("claw-forge.yaml", "--config", "-c", help="Config file."),
    out: str = typer.Option("", "--out", "-o", help="Output filename (default: auto)."),
) -> None:
    """Import a 3rd-party harness export and convert it to app_spec.txt.

    Supports BMAD, Linear, Jira, and generic markdown exports.

    Examples:

        claw-forge import ./bmad-output --project .
        claw-forge import issues.json --project . --yes
        claw-forge import ./bmad-output --out my_spec.xml
    """
    from claw_forge.importer import extract
    from claw_forge.importer.converter import convert
    from claw_forge.importer.detector import detect
    from claw_forge.importer.writer import write_spec

    input_path = Path(path)
    project_dir = Path(project).resolve()

    if not input_path.exists():
        console.print(f"[red]Path not found: {input_path}[/red]")
        raise typer.Exit(1) from None

    # ── Detect ───────────────────────────────────────────────────────────────
    console.print(f"\n[dim]Scanning {path}...[/dim]")
    result = detect(input_path)
    fmt_label = result.format.upper()
    console.print(f"[bold green]✓ Detected:[/bold green] {fmt_label} — {result.summary}")
    console.print(f"  Confidence: {result.confidence}")

    # ── Confirm ──────────────────────────────────────────────────────────────
    if not yes:
        answer = typer.prompt("\nProceed with import? [Y/n]", default="Y")
        if answer.strip().lower() == "n":
            console.print("[dim]Aborted.[/dim]")
            raise typer.Exit(0) from None

    # ── Extract ──────────────────────────────────────────────────────────────
    console.print("\n[dim]Extracting structure...[/dim]  ", end="")
    spec = extract(result)
    console.print(
        f"[bold green]✓[/bold green]  {spec.epic_count} epic(s), {spec.story_count} story/stories"
    )

    if spec.story_count == 0:
        console.print("[red]No features extracted — check export contains stories/issues[/red]")
        raise typer.Exit(1) from None

    # ── Get api_key from config ───────────────────────────────────────────────
    _config_path = Path(config)
    if not _config_path.is_absolute() and not _config_path.exists():
        _project_config = project_dir / config
        if _project_config.exists():
            config = str(_project_config)

    cfg = _load_config(config)
    configs = load_configs_from_yaml(cfg)

    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key and configs:
        first = configs[0]
        api_key = getattr(first, "api_key", "") or ""

    if not api_key:
        console.print("[red]No API key found — set ANTHROPIC_API_KEY or configure a provider[/red]")
        raise typer.Exit(1) from None

    # ── Resolve model alias ───────────────────────────────────────────────────
    resolved = resolve_model(model, cfg)
    if resolved.alias_resolved:
        console.print(f"[dim]Model alias '{model}' → {resolved.model_id}[/dim]")
    model = resolved.model_id

    # ── Convert ──────────────────────────────────────────────────────────────
    console.print("[dim]Converting to spec via Claude...[/dim]  ", end="")
    sections = convert(spec, api_key=api_key, model=model)
    console.print("[bold green]✓[/bold green]")

    is_brownfield = (project_dir / "brownfield_manifest.json").exists()
    mode = "brownfield" if is_brownfield else "greenfield"
    if not is_brownfield:
        console.print("[dim]Auto-detected: greenfield (no brownfield_manifest.json found)[/dim]")
    else:
        console.print("[dim]Auto-detected: brownfield (brownfield_manifest.json found)[/dim]")

    # ── Write ────────────────────────────────────────────────────────────────
    out_path = write_spec(sections, spec, project_dir, out=out)
    rel_path = (
        out_path.relative_to(project_dir) if out_path.is_relative_to(project_dir) else out_path
    )

    console.print(f"\n[bold green]✓ Written:[/bold green] {rel_path}")
    # Count feature bullets in core_features
    bullet_count = sections.core_features.count("<item>") or sections.core_features.count("\n-")
    console.print(f"  Features: {bullet_count} bullets across {spec.epic_count} categories")
    console.print(f"  Epics:    {spec.epic_count} implementation phases")

    # ── Next steps ───────────────────────────────────────────────────────────
    # The importer emits shape-annotated <feature> elements, so the spec is
    # expected to validate cleanly under --strict-shape on the first try.
    console.print("\n[bold]Next steps:[/bold]")
    console.print(f"  1. Review {rel_path}")
    console.print(f"  2. claw-forge validate-spec --strict-shape {rel_path}")
    console.print(f"  3. claw-forge plan {rel_path}")

    _ = mode  # suppress unused variable warning
