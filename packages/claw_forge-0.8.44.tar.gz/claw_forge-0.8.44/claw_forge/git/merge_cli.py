"""Typer command for manual squash-merge of feature branches.

Sibling to git/cli.py (worktrees_app) and git/stash_cli.py (stash_app).
Single command (`merge`); registered via app.command(name="merge")(merge).

The function here is NOT decorated with @app.command().
"""
from __future__ import annotations

from pathlib import Path

import typer

from claw_forge._console import console


def merge(
    branch: str = typer.Argument(None, help="Branch to squash-merge (e.g. feat/user-auth)"),
    project: str = typer.Option(".", "--project", "-p", help="Project directory."),
    target: str = typer.Option("main", "--target", "-t", help="Target branch to merge into."),
) -> None:
    """Squash-merge a feature branch to the target branch.

    Used with merge_strategy: manual to control when features land on main.
    If no branch is specified, lists branches with the configured prefix.

    Examples:

        # Merge a specific branch
        claw-forge merge feat/user-auth

        # List ready feature branches
        claw-forge merge

        # Merge into a custom target
        claw-forge merge feat/user-auth --target develop
    """
    import subprocess as sp

    project_path = Path(project).resolve()

    if branch is None:
        # List feature branches
        try:
            result = sp.run(
                ["git", "branch", "--list", "feat/*"],
                cwd=project_path, capture_output=True, text=True, check=True,
            )
            branches = [
                b.strip().lstrip("* ")
                for b in result.stdout.strip().splitlines()
                if b.strip()
            ]
            if not branches:
                console.print("[dim]No feature branches found.[/dim]")
                return
            console.print("[bold]Feature branches:[/bold]")
            for b in branches:
                console.print(f"  • {b}")
            console.print("\n[dim]Run: claw-forge merge <branch>[/dim]")
        except sp.CalledProcessError:
            console.print("[red]Not a git repository or git not available.[/red]")
        return

    from claw_forge.git.merge import squash_merge

    result = squash_merge(project_path, branch, target)
    if result["merged"]:
        _hash = result['commit_hash']
        console.print(f"[green]✓ Merged {branch} → {target} ({_hash})[/green]")
    else:
        console.print(f"[red]✗ Merge failed: {result.get('error', 'unknown')}[/red]")
