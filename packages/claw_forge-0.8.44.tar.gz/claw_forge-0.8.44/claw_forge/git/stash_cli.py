"""Typer subapp for ``claw-forge stash [list|drop]``.

Operator surface for the ``claw-forge-*`` stash entries the harness
creates automatically:

  * ``claw-forge-auto-<ts>`` — startup smart-cleanup of dirty-tracked
    files in main.
  * ``claw-forge-manual-<ts>`` — produced by direct ``git stash push``
    invocations the operator runs (no enforcement; cosmetic prefix).
  * ``claw-forge-leak-<task_id>-<ts>`` — mid-run leak detector (v0.8.16)
    captured dirt that appeared in main during a task's window.
  * ``claw-forge-boot-<ts>`` — v0.8.17 snapshot-rollback boot baseline:
    pre-existing operator dirt that smart-cleanup couldn't archive,
    captured at dispatcher startup so the run can enforce
    HEAD-clean-main as an invariant.

Without this subapp the only way to inspect/drop stashes was raw
``git stash list/drop`` — workable but not discoverable, and mixed
in with the operator's own pre-existing stashes.  This filters for
the harness-managed prefix so operators can audit and clean up
without sifting through unrelated entries.
"""
from __future__ import annotations

import re
import subprocess
from contextlib import suppress
from pathlib import Path
from typing import Any

import typer

from claw_forge._console import console

stash_app = typer.Typer(
    help=(
        "Manage claw-forge-managed git stash entries (auto-cleanup, "
        "manual cleanup, mid-run leak captures)."
    ),
    no_args_is_help=True,
)


# Match the three marker prefixes the harness emits.  Operator-created
# stashes without this prefix are intentionally excluded — this CLI is
# scoped to harness state, not the operator's personal stash drawer.
_CF_STASH_RE = re.compile(r"claw-forge-(auto|manual|leak|boot)")
_STASH_LINE_RE = re.compile(r"^(stash@\{(\d+)\}):\s*(.*)$")


def _list_cf_stashes(project_dir: Path) -> list[dict[str, Any]]:
    """Return harness-managed stash entries in *project_dir*.

    Each entry: ``{"ref": "stash@{N}", "index": int, "message": str,
    "kind": "auto"|"manual"|"leak"}``.  Returns ``[]`` on git error
    (no stashes / not a git repo / git unreachable).
    """
    try:
        result = subprocess.run(
            ["git", "stash", "list"],
            cwd=str(project_dir),
            capture_output=True,
            text=True,
            check=True,
            timeout=15,
        )
    except (subprocess.SubprocessError, OSError):
        return []

    rows: list[dict[str, Any]] = []
    for line in result.stdout.splitlines():
        m = _STASH_LINE_RE.match(line)
        if not m:
            continue
        ref, idx_str, msg = m.group(1), m.group(2), m.group(3)
        kind_match = _CF_STASH_RE.search(msg)
        if not kind_match:
            continue
        rows.append({
            "ref": ref,
            "index": int(idx_str),
            "message": msg,
            "kind": kind_match.group(1),
        })
    return rows


@stash_app.command("list")
def list_cmd(
    project: str = typer.Option(
        ".", "--project", "-p", help="Project root directory.",
    ),
) -> None:
    """List claw-forge-managed git stash entries.

    Shows three kinds: auto (startup cleanup), manual (operator-run
    cleanup), leak (mid-run leak detector).  Use ``git stash list``
    directly to see operator-personal stashes alongside.
    """
    project_dir = Path(project).resolve()
    rows = _list_cf_stashes(project_dir)
    if not rows:
        console.print(
            "[dim]No claw-forge-managed stash entries in "
            f"{project_dir}[/dim]"
        )
        return

    console.print(
        f"[bold]claw-forge stash entries in {project_dir}[/bold]\n"
    )
    by_kind = {"auto": 0, "manual": 0, "leak": 0, "boot": 0}
    for row in rows:
        by_kind[row["kind"]] = by_kind.get(row["kind"], 0) + 1
        kind_color = {
            "auto": "cyan", "manual": "green",
            "leak": "red", "boot": "yellow",
        }.get(row["kind"], "white")
        console.print(
            f"  [{kind_color}]{row['ref']}[/{kind_color}] "
            f"[{kind_color}]({row['kind']})[/{kind_color}] {row['message']}"
        )
    console.print(
        f"\n[dim]{len(rows)} entr{'ies' if len(rows) != 1 else 'y'} — "
        f"{by_kind['auto']} auto, {by_kind['manual']} manual, "
        f"{by_kind['leak']} leak, {by_kind['boot']} boot.  Inspect with "
        "`git stash show -p <ref>`, recover with `git stash apply "
        "<ref>`, drop with `claw-forge stash drop <ref|index>`.[/dim]"
    )


@stash_app.command("drop")
def drop_cmd(
    ref: str = typer.Argument(
        ...,
        help=(
            "Stash ref to drop — either ``stash@{N}`` or just ``N``.  "
            "Must be a claw-forge-managed entry; operator-personal "
            "stashes are refused."
        ),
    ),
    project: str = typer.Option(
        ".", "--project", "-p", help="Project root directory.",
    ),
    yes: bool = typer.Option(
        False, "--yes", "-y", help="Skip the confirmation prompt.",
    ),
) -> None:
    """Drop a specific claw-forge-managed stash entry.

    Refuses to drop operator-personal stashes (those without the
    ``claw-forge-*`` marker prefix) — use ``git stash drop <ref>``
    directly for those, since they're not the harness's to manage.
    """
    project_dir = Path(project).resolve()
    # Accept bare integer index as a convenience.
    if ref.isdigit():
        ref = f"stash@{{{ref}}}"

    rows = _list_cf_stashes(project_dir)
    matched = next((r for r in rows if r["ref"] == ref), None)
    if matched is None:
        console.print(
            f"[red]No claw-forge-managed stash at {ref}.[/red]  "
            "Run `claw-forge stash list` to see available refs, or "
            "use `git stash drop` for operator-personal stashes."
        )
        raise typer.Exit(1)

    if not yes:
        console.print(
            f"About to drop [bold]{ref}[/bold] ({matched['kind']}): "
            f"{matched['message']}"
        )
        proceed = typer.confirm("Drop this stash?")
        if not proceed:
            console.print("[dim]Cancelled.[/dim]")
            return

    with suppress(subprocess.SubprocessError, OSError):
        result = subprocess.run(
            ["git", "stash", "drop", ref],
            cwd=str(project_dir),
            capture_output=True,
            text=True,
            check=True,
            timeout=15,
        )
        console.print(f"[green]{result.stdout.strip()}[/green]")
        return
    console.print(f"[red]Failed to drop {ref}.[/red]")
    raise typer.Exit(1)


__all__ = ["stash_app", "list_cmd", "drop_cmd"]
