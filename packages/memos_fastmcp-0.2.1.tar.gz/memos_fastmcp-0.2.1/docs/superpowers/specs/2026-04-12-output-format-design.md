---
title: 输出格式选择功能设计
date: 2026-04-12
type: design-spec
---

# 输出格式选择功能设计

## 概述

查询类 MCP 工具返回 Markdown 格式，支持两种展示形式：**列表形式**（默认）和**表格形式**，通过环境变量控制。memo_id 以超链接形式链接到浏览器可访问的详情页。

## 需求摘要

| 项目 | 选择 |
|------|------|
| 输出格式 | Markdown（固定） |
| 展示形式 | 列表形式（默认）或 表格形式 |
| 控制方式 | 环境变量 `MEMOS_DISPLAY_STYLE` |
| 超链接目标 | 浏览器 URL：`{MEMOS_URL}/memos/{memo_id}` |
| 内容截断 | 200 字符 |

---

## 第一部分：涉及的工具

### 查询类工具（返回 Markdown）

| 工具 | 说明 |
|------|------|
| `list_memos` | 列出 memos |
| `search_memos` | 搜索 memos |
| `get_memo` | 获取单条 memo（仅列表形式） |
| `list_public_memos` | 列出公开 memos |
| `list_private_memos` | 列出私密 memos |
| `list_tags` | 列出标签统计 |

### 修改类工具（保持 JSON，不改动）

| 工具 | 说明 |
|------|------|
| `create_memo` | 创建 memo |
| `update_memo` | 更新 memo |
| `delete_memo` | 删除 memo |
| `set_visibility` | 设置可见性 |

---

## 第二部分：环境变量配置

| 变量名 | 说明 | 默认值 |
|--------|------|--------|
| `MEMOS_DISPLAY_STYLE` | 展示形式 (`list` / `table`) | `list` |

---

## 第三部分：Markdown 输出格式

### 列表形式（默认，`MEMOS_DISPLAY_STYLE=list`）

```markdown
## Memo 列表 (共 5 条)

### 1. [V2xmw6RkAEDo4TimKhCGNL](http://192.168.1.5:5230/memos/V2xmw6RkAEDo4TimKhCGNL)
- **内容**: 测试测试 #TEST...
- **标签**: TEST
- **时间**: 2026-04-11 17:27:49
- **状态**: 普通 | 私密

### 2. [jejv4FWU5GR9i2cj8oG45H](http://192.168.1.5:5230/memos/jejv4FWU5GR9i2cj8oG45H)
- **内容**: 另一条 memo 的内容...
- **标签**: 工作, 重要
- **时间**: 2026-04-10 10:00:00
- **状态**: 置顶 | 公开
```

**优点**：内容字段不受宽度限制，阅读体验更好

### 表格形式（`MEMOS_DISPLAY_STYLE=table`）

```markdown
## Memo 列表 (共 5 条)

| ID | 内容 | 标签 | 时间 | 状态 |
|---|---|---|---|---|
| [V2xmw6RkAEDo4TimKhCGNL](http://192.168.1.5:5230/memos/V2xmw6RkAEDo4TimKhCGNL) | 测试测试 #TEST... | TEST | 2026-04-11 | 普通 |
| [jejv4FWU5GR9i2cj8oG45H](http://192.168.1.5:5230/memos/jejv4FWU5GR9i2cj8oG45H) | 另一条内容... | 工作 | 2026-04-10 | 置顶 |
```

**优点**：信息紧凑，适合快速浏览多条 memo

**注意**：
- ID 列显示完整 ID（不截断，便于复制）
- 内容列截断到 50 字符（表格宽度限制）
- 时间列只显示日期（`YYYY-MM-DD`）

### 单条详情（get_memo，固定列表形式）

```markdown
## Memo 详情

### [V2xmw6RkAEDo4TimKhCGNL](http://192.168.1.5:5230/memos/V2xmw6RkAEDo4TimKhCGNL)

**完整内容**:
测试测试 #TEST

**元信息**:
- 标签: TEST
- 可见性: PRIVATE
- 创建时间: 2026-04-11 17:27:49
- 更新时间: 2026-04-11 17:30:00
- 状态: NORMAL
- 置顶: 否
```

### 标签统计（固定列表形式）

```markdown
## 标签统计 (共 N 个)

- **TEST**: 5 条
- **工作**: 3 条
- **重要**: 2 条
```

---

## 第四部分：实现要点

### Settings 类扩展

```python
class Settings(BaseSettings):
    memos_url: str
    memos_token: str
    api_version: str = "v1"
    request_timeout: float = 30.0
    display_style: str = Field(default="list", description="Display style: list or table")
    
    def get_memo_url(self, memo_id: str) -> str:
        """构建 memo 详情页 URL（浏览器可访问）"""
        pure_id = memo_id.split("/")[-1] if "/" in memo_id else memo_id
        base = self.memos_url.rstrip("/")
        return f"{base}/memos/{pure_id}"
```

### 格式化工具函数

在 `utils/formatting.py` 添加：

```python
def format_memo_list(memos: list[Memo], base_url: str, style: str = "list") -> str:
    """格式化 memo 列表为 Markdown（列表或表格形式）"""
    if style == "table":
        return format_memo_table(memos, base_url)
    return format_memo_list_items(memos, base_url)

def format_memo_list_items(memos: list[Memo], base_url: str) -> str:
    """列表形式"""
    ...

def format_memo_table(memos: list[Memo], base_url: str) -> str:
    """表格形式（ID 显示完整）"""
    ...

def format_memo_detail(memo: Memo, base_url: str) -> str:
    """单条 memo 详情"""
    ...

def truncate_content(content: str, max_length: int) -> str:
    """截断内容"""
    ...
```

### 工具返回类型变化

查询工具返回类型从 `dict | list[dict]` 改为 `str`（Markdown 文本）。

---

## 第五部分：修改文件清单

| 文件 | 修改内容 |
|------|----------|
| `src/memos_mcp/config.py` | 添加 `display_style` 字段和 `get_memo_url()` 方法 |
| `src/memos_mcp/utils/formatting.py` | 添加 Markdown 格式化函数（列表/表格） |
| `src/memos_mcp/tools/memo_tools.py` | 查询工具返回 Markdown 字符串 |
| `src/memos_mcp/tools/visibility_tools.py` | `list_public_memos`、`list_private_memos` 返回 Markdown |
| `src/memos_mcp/tools/tag_tools.py` | `list_tags` 返回 Markdown |
| `README.md` | 更新文档，说明展示形式配置 |

---

## 测试要点

1. 默认列表形式：不设置环境变量，验证返回列表格式 Markdown
2. 表格形式：设置 `MEMOS_DISPLAY_STYLE=table`，验证返回表格格式
3. 超链接正确：URL 格式为 `{MEMOS_URL}/memos/{memo_id}`
4. 内容截断：列表形式截断 200 字符，表格形式截断 50 字符
5. ID 显示完整：表格形式 ID 显示完整 ID（便于复制）