# 输出格式选择功能实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 查询类 MCP 工具返回 Markdown 格式，支持列表/表格两种展示形式，memo_id 以超链接形式链接到浏览器详情页。

**Architecture:** 通过环境变量 MEMOS_DISPLAY_STYLE 控制展示形式。Settings 类添加 display_style 字段和 get_memo_url 方法。formatting.py 重写以支持列表/表格格式和超链接。

**Tech Stack:** Python, FastMCP, Pydantic, pydantic-settings

---

## 文件结构

| 文件 | 职责 | 操作 |
|------|------|------|
| `src/memos_mcp/config.py` | 配置管理，添加 display_style 和 get_memo_url | 修改 |
| `src/memos_mcp/utils/formatting.py` | Markdown 格式化（列表/表格，超链接） | 重写 |
| `src/memos_mcp/tools/memo_tools.py` | 查询工具返回 Markdown | 修改 |
| `src/memos_mcp/tools/visibility_tools.py` | list_public/private_memos 返回 Markdown | 修改 |
| `src/memos_mcp/tools/tag_tools.py` | list_tags 返回 Markdown | 修改 |
| `tests/test_formatting.py` | 格式化函数测试 | 创建 |
| `README.md` | 文档更新 | 修改 |

---

### Task 1: 扩展 Settings 类

**Files:**
- Modify: `src/memos_mcp/config.py`

- [ ] **Step 1: 添加 display_style 字段和 get_memo_url 方法**

```python
"""Configuration management using pydantic-settings."""

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from memos_mcp.exceptions import ConfigurationError


class Settings(BaseSettings):
    """Application settings from environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_prefix="",
    )

    memos_url: str = Field(
        ...,
        description="Memos server URL"
    )
    memos_token: str = Field(
        ...,
        description="Memos API access token"
    )
    api_version: str = Field(
        default="v1",
        description="API version path"
    )
    request_timeout: float = Field(
        default=30.0,
        description="Request timeout in seconds"
    )
    display_style: str = Field(
        default="list",
        description="Display style for memo lists: list or table"
    )

    @property
    def api_base_url(self) -> str:
        """Full API base URL."""
        base = self.memos_url.rstrip("/")
        return f"{base}/api/{self.api_version}"

    def get_memo_url(self, memo_id: str) -> str:
        """Build memo detail page URL for browser access.
        
        Args:
            memo_id: Memo ID (pure ID or full name like memos/xxx)
            
        Returns:
            Browser-accessible URL: {memos_url}/memos/{pure_id}
        """
        # Extract pure ID from full name if needed
        pure_id = memo_id.split("/")[-1] if "/" in memo_id else memo_id
        base = self.memos_url.rstrip("/")
        return f"{base}/memos/{pure_id}"


@lru_cache
def get_settings() -> Settings:
    """Get settings instance (cached singleton)."""
    try:
        return Settings()
    except Exception as e:
        missing = []
        error_str = str(e)
        if "memos_url" in error_str.lower():
            missing.append("MEMOS_URL")
        if "memos_token" in error_str.lower():
            missing.append("MEMOS_TOKEN")
        raise ConfigurationError(missing)
```

- [ ] **Step 2: 验证配置正确加载**

Run: `cd "C:\Users\admin\StudioProjects\memos-mcp" && MEMOS_URL=http://test.com MEMOS_TOKEN=test python -c "import sys; sys.path.insert(0,'src'); from memos_mcp.config import Settings; s=Settings(); print(f'display_style={s.display_style}'); print(f'memo_url={s.get_memo_url(\"abc123\")}')"`

Expected: `display_style=list` and `memo_url=http://test.com/memos/abc123`

- [ ] **Step 3: Commit**

```bash
git add src/memos_mcp/config.py
git commit -m "feat: add display_style and get_memo_url to Settings"
```

---

### Task 2: 重写 formatting.py 支持列表/表格格式

**Files:**
- Rewrite: `src/memos_mcp/utils/formatting.py`
- Create: `tests/test_formatting.py`

- [ ] **Step 1: 编写 formatting.py 新实现**

```python
"""Formatting utilities for Markdown output with list/table styles."""

from datetime import datetime

from memos_mcp.models import Memo, MemoVisibility


def truncate_content(content: str, max_length: int = 200) -> str:
    """Truncate content to specified length.
    
    Args:
        content: Original content string.
        max_length: Maximum length (default 200 for list, 50 for table).
        
    Returns:
        Truncated string with '...' suffix if needed.
    """
    if not content:
        return "(empty)"
    
    # Remove newlines for display
    display = content.strip().replace("\n", " ")
    
    if len(display) <= max_length:
        return display
    
    return display[:max_length] + "..."


def format_datetime_short(dt: datetime | str | None) -> str:
    """Format datetime as short date (YYYY-MM-DD) for table."""
    if dt is None:
        return "-"
    
    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt.replace("Z", "+00:00"))
        except ValueError:
            return dt
    
    return dt.strftime("%Y-%m-%d")


def format_datetime_full(dt: datetime | str | None) -> str:
    """Format datetime as full (YYYY-MM-DD HH:MM:SS) for list."""
    if dt is None:
        return "-"
    
    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt.replace("Z", "+00:00"))
        except ValueError:
            return dt
    
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def format_status_text(memo: Memo) -> str:
    """Format status text (pinned/normal + visibility).
    
    Args:
        memo: Memo object.
        
    Returns:
        Status text like '置顶 | 公开' or '普通 | 私密'.
    """
    pinned_text = "置顶" if memo.pinned else "普通"
    
    vis_map = {
        MemoVisibility.PRIVATE: "私密",
        MemoVisibility.PROTECTED: "保护",
        MemoVisibility.PUBLIC: "公开",
    }
    vis_text = vis_map.get(memo.visibility, "未知")
    
    return f"{pinned_text} | {vis_text}"


def extract_memo_id(memo: Memo) -> str:
    """Extract pure memo ID from name field.
    
    Args:
        memo: Memo object.
        
    Returns:
        Pure ID (e.g., 'V2xmw6RkAEDo4TimKhCGNL').
    """
    name = memo.name
    return name.split("/")[-1] if "/" in name else name


def format_memo_list(memos: list[Memo], base_url: str, style: str = "list") -> str:
    """Format memo list as Markdown (list or table style).
    
    Args:
        memos: List of Memo objects.
        base_url: Base URL for constructing memo links.
        style: Display style - 'list' or 'table'.
        
    Returns:
        Markdown formatted string.
    """
    if not memos:
        return "## Memo 列表\n\n暂无 memo。"
    
    if style == "table":
        return _format_memo_table(memos, base_url)
    return _format_memo_list_items(memos, base_url)


def _format_memo_list_items(memos: list[Memo], base_url: str) -> str:
    """Format memos as list items (default style).
    
    Content truncated to 200 chars. Full datetime shown.
    """
    lines = [f"## Memo 列表 (共 {len(memos)} 条)", ""]
    
    for i, memo in enumerate(memos, 1):
        memo_id = extract_memo_id(memo)
        memo_url = f"{base_url}/memos/{memo_id}"
        
        lines.append(f"### {i}. [{memo_id}]({memo_url})")
        lines.append(f"- **内容**: {truncate_content(memo.content, 200)}")
        lines.append(f"- **标签**: {', '.join(memo.tags) if memo.tags else '无'}")
        lines.append(f"- **时间**: {format_datetime_full(memo.create_time)}")
        lines.append(f"- **状态**: {format_status_text(memo)}")
        lines.append("")
    
    return "\n".join(lines)


def _format_memo_table(memos: list[Memo], base_url: str) -> str:
    """Format memos as table (compact style).
    
    Content truncated to 50 chars. Date only shown.
    ID not truncated (full ID for copying).
    """
    lines = [
        f"## Memo 列表 (共 {len(memos)} 条)",
        "",
        "| ID | 内容 | 标签 | 时间 | 状态 |",
        "|---|---|---|---|---|",
    ]
    
    for memo in memos:
        memo_id = extract_memo_id(memo)
        memo_url = f"{base_url}/memos/{memo_id}"
        
        # ID with full link (not truncated)
        id_cell = f"[{memo_id}]({memo_url})"
        content_cell = truncate_content(memo.content, 50)
        tags_cell = ", ".join(memo.tags) if memo.tags else "-"
        time_cell = format_datetime_short(memo.create_time)
        status_cell = format_status_text(memo)
        
        lines.append(f"| {id_cell} | {content_cell} | {tags_cell} | {time_cell} | {status_cell} |")
    
    return "\n".join(lines)


def format_memo_detail(memo: Memo, base_url: str) -> str:
    """Format single memo detail as Markdown.
    
    Args:
        memo: Memo object.
        base_url: Base URL for constructing memo link.
        
    Returns:
        Markdown formatted detail (always list style).
    """
    memo_id = extract_memo_id(memo)
    memo_url = f"{base_url}/memos/{memo_id}"
    
    lines = [
        "## Memo 详情",
        "",
        f"### [{memo_id}]({memo_url})",
        "",
        "**完整内容**:",
        memo.content or "(empty)",
        "",
        "**元信息**:",
        f"- 标签: {', '.join(memo.tags) if memo.tags else '无'}",
        f"- 可见性: {memo.visibility.value if memo.visibility else '-'}",
        f"- 创建时间: {format_datetime_full(memo.create_time)}",
        f"- 更新时间: {format_datetime_full(memo.update_time)}",
        f"- 状态: {memo.state.value if memo.state else '-'}",
        f"- 置顶: {'是' if memo.pinned else '否'}",
    ]
    
    return "\n".join(lines)


def format_tags_list(tags: dict[str, int]) -> str:
    """Format tags statistics as Markdown list.
    
    Args:
        tags: Dictionary mapping tag names to usage counts.
        
    Returns:
        Markdown formatted list (always list style).
    """
    if not tags:
        return "## 标签统计\n\n暂无标签。"
    
    # Sort by count descending
    sorted_tags = sorted(tags.items(), key=lambda x: (-x[1], x[0]))
    
    lines = [f"## 标签统计 (共 {len(sorted_tags)} 个)", ""]
    
    for tag, count in sorted_tags:
        lines.append(f"- **{tag}**: {count} 条")
    
    return "\n".join(lines)


def format_stats(stats: dict) -> str:
    """Format statistics as Markdown.
    
    Args:
        stats: Dictionary with statistics data.
        
    Returns:
        Markdown formatted statistics.
    """
    lines = ["## 统计信息", ""]
    
    if "total" in stats:
        lines.append(f"- **总 Memo 数**: {stats['total']}")
    
    if "by_visibility" in stats:
        lines.append("")
        lines.append("### 按可见性")
        for vis, count in stats["by_visibility"].items():
            lines.append(f"- **{vis}**: {count}")
    
    if "by_state" in stats:
        lines.append("")
        lines.append("### 按状态")
        for state, count in stats["by_state"].items():
            lines.append(f"- **{state}**: {count}")
    
    if "total_tags" in stats:
        lines.append("")
        lines.append(f"- **唯一标签数**: {stats['total_tags']}")
    
    if "pinned" in stats:
        lines.append(f"- **置顶数**: {stats['pinned']}")
    
    return "\n".join(lines)
```

- [ ] **Step 2: 编写测试文件**

```python
"""Tests for formatting utilities."""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from datetime import datetime

from memos_mcp.models import Memo, MemoState, MemoVisibility
from memos_mcp.utils.formatting import (
    truncate_content,
    format_datetime_short,
    format_datetime_full,
    format_status_text,
    extract_memo_id,
    format_memo_list,
    format_memo_detail,
    format_tags_list,
)


def create_test_memo(
    name: str = "memos/V2xmw6RkAEDo4TimKhCGNL",
    content: str = "测试内容 #TEST",
    tags: list[str] = ["TEST"],
    pinned: bool = False,
    visibility: MemoVisibility = MemoVisibility.PRIVATE,
) -> Memo:
    """Create a test memo object."""
    return Memo(
        name=name,
        state=MemoState.NORMAL,
        creator="users/1",
        content=content,
        visibility=visibility,
        pinned=pinned,
        tags=tags,
        create_time=datetime(2026, 4, 11, 17, 27, 49),
        update_time=datetime(2026, 4, 11, 17, 30, 0),
        display_time=datetime(2026, 4, 11, 17, 27, 49),
    )


def test_truncate_content_short():
    """Test truncate with short content."""
    result = truncate_content("短内容", 200)
    assert result == "短内容"


def test_truncate_content_long():
    """Test truncate with long content."""
    long_content = "这是一段很长的内容" * 20
    result = truncate_content(long_content, 200)
    assert len(result) == 203  # 200 + "..."
    assert result.endswith("...")


def test_truncate_content_table():
    """Test truncate for table (50 chars)."""
    content = "这是一段测试内容用于表格显示截断测试"
    result = truncate_content(content, 50)
    assert len(result) <= 53


def test_extract_memo_id():
    """Test extracting memo ID from name."""
    memo = create_test_memo(name="memos/abc123")
    assert extract_memo_id(memo) == "abc123"
    
    memo = create_test_memo(name="xyz789")
    assert extract_memo_id(memo) == "xyz789"


def test_format_status_text():
    """Test status text formatting."""
    memo = create_test_memo(pinned=True, visibility=MemoVisibility.PUBLIC)
    assert format_status_text(memo) == "置顶 | 公开"
    
    memo = create_test_memo(pinned=False, visibility=MemoVisibility.PRIVATE)
    assert format_status_text(memo) == "普通 | 私密"


def test_format_memo_list_list_style():
    """Test list format style."""
    memos = [create_test_memo()]
    result = format_memo_list(memos, "http://test.com", "list")
    
    assert "## Memo 列表 (共 1 条)" in result
    assert "[V2xmw6RkAEDo4TimKhCGNL](http://test.com/memos/V2xmw6RkAEDo4TimKhCGNL)" in result
    assert "- **内容**:" in result
    assert "- **标签**: TEST" in result


def test_format_memo_list_table_style():
    """Test table format style."""
    memos = [create_test_memo()]
    result = format_memo_list(memos, "http://test.com", "table")
    
    assert "## Memo 列表 (共 1 条)" in result
    assert "| ID | 内容 | 标签 | 时间 | 状态 |" in result
    # ID should be full (not truncated) with link
    assert "[V2xmw6RkAEDo4TimKhCGNL](http://test.com/memos/V2xmw6RkAEDo4TimKhCGNL)" in result


def test_format_memo_list_empty():
    """Test empty memo list."""
    result = format_memo_list([], "http://test.com", "list")
    assert "暂无 memo" in result


def test_format_memo_detail():
    """Test memo detail format."""
    memo = create_test_memo()
    result = format_memo_detail(memo, "http://test.com")
    
    assert "## Memo 详情" in result
    assert "[V2xmw6RkAEDo4TimKhCGNL](http://test.com/memos/V2xmw6RkAEDo4TimKhCGNL)" in result
    assert "**完整内容**:" in result
    assert "测试内容 #TEST" in result


def test_format_tags_list():
    """Test tags list format."""
    tags = {"TEST": 5, "工作": 3}
    result = format_tags_list(tags)
    
    assert "## 标签统计 (共 2 个)" in result
    assert "- **TEST**: 5 条" in result
    assert "- **工作**: 3 条" in result


if __name__ == "__main__":
    test_truncate_content_short()
    test_truncate_content_long()
    test_truncate_content_table()
    test_extract_memo_id()
    test_format_status_text()
    test_format_memo_list_list_style()
    test_format_memo_list_table_style()
    test_format_memo_list_empty()
    test_format_memo_detail()
    test_format_tags_list()
    print("All tests passed!")
```

- [ ] **Step 3: 运行测试验证**

Run: `cd "C:\Users\admin\StudioProjects\memos-mcp" && python tests/test_formatting.py`

Expected: `All tests passed!`

- [ ] **Step 4: Commit**

```bash
git add src/memos_mcp/utils/formatting.py tests/test_formatting.py
git commit -m "feat: rewrite formatting.py with list/table styles and hyperlinks"
```

---

### Task 3: 修改 memo_tools.py 查询工具返回 Markdown

**Files:**
- Modify: `src/memos_mcp/tools/memo_tools.py`

- [ ] **Step 1: 修改查询工具返回 Markdown**

需要修改的工具：`list_memos`、`search_memos`、`get_memo`

保持 JSON 的工具：`create_memo`、`update_memo`、`delete_memo`

```python
"""Memo CRUD tools."""

from typing import Literal

from fastmcp import FastMCP

from memos_mcp.client import MemosClient
from memos_mcp.config import get_settings
from memos_mcp.models import MemoState, MemoVisibility
from memos_mcp.utils.formatting import format_memo_list, format_memo_detail, extract_memo_id

_client: MemosClient | None = None


def get_client() -> MemosClient:
    """Get or create the singleton MemosClient instance."""
    global _client
    if _client is None:
        _client = MemosClient(get_settings())
    return _client


def _format_memo_response(memo) -> dict:
    """Format memo response with memo_id field for clarity."""
    data = memo.model_dump()
    data["memo_id"] = extract_memo_id(memo)
    return data


# ============================================
# CREATE / UPDATE / DELETE - Return JSON (unchanged)
# ============================================


async def create_memo(
    content: str,
    visibility: Literal["PRIVATE", "PROTECTED", "PUBLIC"] = "PRIVATE",
    tags: list[str] | None = None,
) -> dict:
    """Create a new memo.

    Args:
        content: The memo content (markdown supported).
        visibility: Memo visibility level (PRIVATE, PROTECTED, PUBLIC).
        tags: List of tags to apply to the memo.

    Returns:
        The created memo with memo_id field for future reference.
    """
    client = get_client()
    visibility_enum = MemoVisibility(visibility)
    memo = await client.create_memo(
        content=content,
        visibility=visibility_enum,
        tags=tags or [],
    )
    return _format_memo_response(memo)


async def update_memo(
    memo_id: str,
    content: str | None = None,
    visibility: Literal["PRIVATE", "PROTECTED", "PUBLIC"] | None = None,
    pinned: bool | None = None,
) -> dict:
    """Update an existing memo.

    Args:
        memo_id: The memo ID to update. Can be either:
            - Pure ID (e.g., "V2xmw6RkAEDo4TimKhCGNL")
            - Full name format (e.g., "memos/V2xmw6RkAEDo4TimKhCGNL")
            Both formats are accepted. Use the memo_id from list/get responses.
        content: New content for the memo (optional).
        visibility: New visibility level (optional).
        pinned: New pinned status (optional).

    Returns:
        The updated memo with memo_id field for future reference.
    """
    client = get_client()
    visibility_enum = None
    if visibility is not None:
        visibility_enum = MemoVisibility(visibility)
    memo = await client.update_memo(
        memo_id=memo_id,
        content=content,
        visibility=visibility_enum,
        pinned=pinned,
    )
    return _format_memo_response(memo)


async def delete_memo(
    memo_id: str,
) -> bool:
    """Delete a memo.

    Args:
        memo_id: The memo ID to delete. Can be either:
            - Pure ID (e.g., "V2xmw6RkAEDo4TimKhCGNL")
            - Full name format (e.g., "memos/V2xmw6RkAEDo4TimKhCGNL")
            Both formats are accepted.

    Returns:
        True if deletion was successful.
    """
    client = get_client()
    return await client.delete_memo(memo_id)


# ============================================
# QUERY - Return Markdown
# ============================================


async def list_memos(
    limit: int = 20,
    state: Literal["NORMAL", "ARCHIVED"] = "NORMAL",
    filter: str | None = None,
) -> str:
    """List memos with optional filters.

    Args:
        limit: Maximum number of memos to return.
        state: Filter by memo state (NORMAL or ARCHIVED).
        filter: Custom filter expression.

    Returns:
        Markdown formatted memo list with hyperlinks to browser.
        Display style controlled by MEMOS_DISPLAY_STYLE env var.
    """
    client = get_client()
    settings = get_settings()
    state_enum = MemoState(state)
    memos = await client.list_memos(
        limit=limit,
        state=state_enum,
        filter=filter,
    )
    return format_memo_list(memos, settings.memos_url, settings.display_style)


async def search_memos(
    query: str | None = None,
    tags: list[str] | None = None,
    limit: int = 20,
) -> str:
    """Search memos by content or tags.

    Args:
        query: Search query for memo content.
        tags: List of tags to filter by.
        limit: Maximum number of results.

    Returns:
        Markdown formatted memo list with hyperlinks to browser.
        Display style controlled by MEMOS_DISPLAY_STYLE env var.
    """
    client = get_client()
    settings = get_settings()

    # Build filter expression
    filter_parts = []

    if query:
        escaped_query = query.replace("'", "\\'")
        filter_parts.append(f"content.contains('{escaped_query}')")

    if tags:
        for tag in tags:
            escaped_tag = tag.replace("'", "\\'")
            filter_parts.append(f"tags.contains('{escaped_tag}')")

    filter_expr = None
    if filter_parts:
        filter_expr = " && ".join(filter_parts)

    memos = await client.list_memos(
        limit=limit,
        state=MemoState.NORMAL,
        filter=filter_expr,
    )
    return format_memo_list(memos, settings.memos_url, settings.display_style)


async def get_memo(
    memo_id: str,
) -> str:
    """Get a memo by ID.

    Args:
        memo_id: The memo ID. Can be either:
            - Pure ID (e.g., "V2xmw6RkAEDo4TimKhCGNL")
            - Full name format (e.g., "memos/V2xmw6RkAEDo4TimKhCGNL")
            Both formats are accepted.

    Returns:
        Markdown formatted memo detail with hyperlink to browser.
    """
    client = get_client()
    settings = get_settings()
    memo = await client.get_memo(memo_id)
    return format_memo_detail(memo, settings.memos_url)


def register_tools(mcp: FastMCP) -> None:
    """Register all memo tools with the FastMCP instance."""
    mcp.tool(create_memo)
    mcp.tool(get_memo)
    mcp.tool(update_memo)
    mcp.tool(delete_memo)
    mcp.tool(list_memos)
    mcp.tool(search_memos)
```

- [ ] **Step 2: Commit**

```bash
git add src/memos_mcp/tools/memo_tools.py
git commit -m "feat: query tools return Markdown with hyperlinks"
```

---

### Task 4: 修改 visibility_tools.py

**Files:**
- Modify: `src/memos_mcp/tools/visibility_tools.py`

- [ ] **Step 1: 修改 list_public_memos 和 list_private_memos 返回 Markdown**

```python
"""Visibility control tools."""

from typing import Literal

from fastmcp import FastMCP

from memos_mcp.client import MemosClient
from memos_mcp.config import get_settings
from memos_mcp.models import MemoVisibility
from memos_mcp.utils.formatting import format_memo_list, extract_memo_id

_client: MemosClient | None = None


def get_client() -> MemosClient:
    """Get or create the singleton MemosClient instance."""
    global _client
    if _client is None:
        _client = MemosClient(get_settings())
    return _client


async def set_visibility(
    memo_id: str,
    visibility: Literal["PRIVATE", "PROTECTED", "PUBLIC"],
) -> str:
    """Set the visibility of a memo.

    Args:
        memo_id: The memo ID to update. Can be either:
            - Pure ID (e.g., "V2xmw6RkAEDo4TimKhCGNL")
            - Full name format (e.g., "memos/V2xmw6RkAEDo4TimKhCGNL")
            Both formats are accepted. Use the memo_id from list/get responses.
        visibility: New visibility level (PRIVATE, PROTECTED, PUBLIC).

    Returns:
        Summary of the visibility change with memo_id for reference.
    """
    client = get_client()
    visibility_enum = MemoVisibility(visibility)
    memo = await client.update_memo(memo_id, visibility=visibility_enum)

    extracted_id = extract_memo_id(memo)
    return f"Successfully set memo {extracted_id} visibility to {visibility}. Use memo_id '{extracted_id}' for future operations."


async def list_public_memos(limit: int = 20) -> str:
    """List all public memos.

    Args:
        limit: Maximum number of memos to return.

    Returns:
        Markdown formatted public memo list with hyperlinks to browser.
        Display style controlled by MEMOS_DISPLAY_STYLE env var.
    """
    client = get_client()
    settings = get_settings()
    memos = await client.list_memos(limit=limit, state=None)
    public_memos = [m for m in memos if m.visibility == MemoVisibility.PUBLIC]
    return format_memo_list(public_memos, settings.memos_url, settings.display_style)


async def list_private_memos(limit: int = 20) -> str:
    """List all private memos.

    Args:
        limit: Maximum number of memos to return.

    Returns:
        Markdown formatted private memo list with hyperlinks to browser.
        Display style controlled by MEMOS_DISPLAY_STYLE env var.
    """
    client = get_client()
    settings = get_settings()
    memos = await client.list_memos(limit=limit, state=None)
    private_memos = [m for m in memos if m.visibility == MemoVisibility.PRIVATE]
    return format_memo_list(private_memos, settings.memos_url, settings.display_style)


def register_tools(mcp: FastMCP) -> None:
    """Register all visibility tools with the FastMCP instance."""
    mcp.tool(set_visibility)
    mcp.tool(list_public_memos)
    mcp.tool(list_private_memos)
```

- [ ] **Step 2: Commit**

```bash
git add src/memos_mcp/tools/visibility_tools.py
git commit -m "feat: list_public/private_memos return Markdown"
```

---

### Task 5: 修改 tag_tools.py

**Files:**
- Modify: `src/memos_mcp/tools/tag_tools.py`

- [ ] **Step 1: 修改 list_tags 返回 Markdown 列表**

```python
"""Tag management tools."""

from fastmcp import FastMCP

from memos_mcp.client import MemosClient
from memos_mcp.config import get_settings
from memos_mcp.utils.formatting import format_tags_list

_client: MemosClient | None = None


def get_client() -> MemosClient:
    """Get or create the singleton MemosClient instance."""
    global _client
    if _client is None:
        _client = MemosClient(get_settings())
    return _client


async def list_tags(limit: int = 100) -> str:
    """List all tags with their usage counts.

    Args:
        limit: Maximum number of tags to return.

    Returns:
        Markdown formatted tag statistics list.
    """
    client = get_client()
    tags = await client.list_tags(limit=limit)
    return format_tags_list(tags)


async def rename_tag(old_name: str, new_name: str) -> str:
    """Rename a tag across all memos.

    Args:
        old_name: Current tag name to rename.
        new_name: New tag name.

    Returns:
        Summary of the rename operation.
    """
    client = get_client()
    updated_memos = await client.rename_tag(old_name, new_name)

    count = len(updated_memos)
    return f"Successfully renamed tag '{old_name}' to '{new_name}' in {count} memo(s)."


async def delete_tag(tag_name: str) -> str:
    """Delete a tag from all memos.

    Args:
        tag_name: Tag name to delete.

    Returns:
        Summary of the delete operation.
    """
    client = get_client()
    updated_memos = await client.delete_tag(tag_name)

    count = len(updated_memos)
    return f"Successfully deleted tag '{tag_name}' from {count} memo(s)."


def register_tools(mcp: FastMCP) -> None:
    """Register all tag tools with the FastMCP instance."""
    mcp.tool(list_tags)
    mcp.tool(rename_tag)
    mcp.tool(delete_tag)
```

- [ ] **Step 2: Commit**

```bash
git add src/memos_mcp/tools/tag_tools.py
git commit -m "feat: list_tags returns Markdown list format"
```

---

### Task 6: 更新 utils/__init__.py 导出

**Files:**
- Modify: `src/memos_mcp/utils/__init__.py`

- [ ] **Step 1: 更新导出列表**

```python
"""Utility modules."""

from memos_mcp.utils.formatting import (
    format_memo_list,
    format_memo_detail,
    format_tags_list,
    format_stats,
    truncate_content,
    extract_memo_id,
)

__all__ = [
    "format_memo_list",
    "format_memo_detail",
    "format_tags_list",
    "format_stats",
    "truncate_content",
    "extract_memo_id",
]
```

- [ ] **Step 2: Commit**

```bash
git add src/memos_mcp/utils/__init__.py
git commit -m "feat: update utils exports"
```

---

### Task 7: 运行完整测试并发布

**Files:**
- Test all functionality with real API

- [ ] **Step 1: 运行单元测试**

Run: `cd "C:\Users\admin\StudioProjects\memos-mcp" && python tests/test_formatting.py`

Expected: `All tests passed!`

- [ ] **Step 2: 运行集成测试验证 Markdown 输出**

Run: `cd "C:\Users\admin\StudioProjects\memos-mcp" && MEMOS_URL=http://192.168.1.5:5230 MEMOS_TOKEN=memos_pat_AebiaozWwn5LMl3csd68otEcn5hn2C4C python -c "
import asyncio
import sys
sys.path.insert(0, 'src')

from memos_mcp.tools import memo_tools, visibility_tools, tag_tools
memo_tools._client = None
visibility_tools._client = None
tag_tools._client = None

from memos_mcp.tools.memo_tools import list_memos, get_memo
from memos_mcp.tools.visibility_tools import list_public_memos
from memos_mcp.tools.tag_tools import list_tags

async def test():
    print('=== list_memos (default list style) ===')
    result = await list_memos(limit=2)
    print(result[:500])
    print()
    
    print('=== Test hyperlink format ===')
    assert 'http://192.168.1.5:5230/memos/' in result
    print('Hyperlink present: OK')
    
asyncio.run(test())
"`

Expected: Markdown output with hyperlinks like `[V2xmw6RkAEDo4TimKhCGNL](http://192.168.1.5:5230/memos/V2xmw6RkAEDo4TimKhCGNL)`

- [ ] **Step 3: 测试表格形式**

Run: `cd "C:\Users\admin\StudioProjects\memos-mcp" && MEMOS_URL=http://192.168.1.5:5230 MEMOS_TOKEN=memos_pat_AebiaozWwn5LMl3csd68otEcn5hn2C4C MEMOS_DISPLAY_STYLE=table python -c "
import asyncio
import sys
sys.path.insert(0, 'src')

from memos_mcp.tools import memo_tools
memo_tools._client = None

from memos_mcp.tools.memo_tools import list_memos

async def test():
    result = await list_memos(limit=2)
    print(result)
    print()
    assert '| ID | 内容 |' in result
    print('Table format: OK')

asyncio.run(test())
"`

Expected: Markdown table format

- [ ] **Step 4: 更新版本号**

修改 `src/memos_mcp/__init__.py`:
```python
__version__ = "0.2.0"
```

修改 `pyproject.toml`:
```toml
version = "0.2.0"
```

- [ ] **Step 5: 发布到 PyPI**

```bash
cd "C:\Users\admin\StudioProjects\memos-mcp"
rm -rf dist/*
python -m build
set PYTHONUTF8=1 && twine upload dist/* --disable-progress-bar
```

- [ ] **Step 6: Commit 并推送到 GitHub**

```bash
git add -A
git commit -m "release: v0.2.0 with Markdown output format"
git push origin master
```

---

### Task 8: 更新 README 文档

**Files:**
- Modify: `README.md`

- [ ] **Step 1: 添加输出格式说明**

在 README.md 的 Configuration 部分添加：

```markdown
### Output Format

Query tools (list_memos, search_memos, get_memo, etc.) return Markdown format with two display styles:

| Style | Description |
|-------|-------------|
| `list` | Detailed list items (default) |
| `table` | Compact table format |

Control via environment variable:

```bash
MEMOS_DISPLAY_STYLE=table  # Default: list
```

**Example output (list style)**:
```markdown
### 1. [V2xmw6RkAEDo4TimKhCGNL](http://your-memos/memos/V2xmw6RkAEDo4TimKhCGNL)
- **内容**: Test content...
- **标签**: test
- **时间**: 2026-04-11 17:27:49
- **状态**: 普通 | 私密
```

**Example output (table style)**:
```markdown
| ID | 内容 | 标签 | 时间 | 状态 |
|---|---|---|---|---|
| [V2xmw6Rk...](http://url) | Test... | test | 2026-04-11 | 普通 |
```

Note: Memo IDs are displayed with hyperlinks to the browser-accessible detail page.
```

- [ ] **Step 2: Commit**

```bash
git add README.md
git commit -m "docs: add output format documentation"
git push origin master
```

---

## 自检清单

1. **Spec coverage**: 所有设计文档要求都已覆盖
   - ✅ display_style 环境变量
   - ✅ get_memo_url 方法
   - ✅ 列表/表格两种格式
   - ✅ 超链接格式正确
   - ✅ 内容截断（列表200，表格50）
   - ✅ ID 不截断

2. **Placeholder scan**: 无 TBD/TODO

3. **Type consistency**: 函数签名一致
   - format_memo_list 接收 `list[Memo]`, `base_url`, `style`
   - 所有查询工具返回 `str`
   - 修改工具返回 `dict` 或 `bool`