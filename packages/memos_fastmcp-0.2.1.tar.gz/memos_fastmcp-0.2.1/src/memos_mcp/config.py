"""Configuration management using pydantic-settings."""

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from memos_mcp.exceptions import ConfigurationError


class Settings(BaseSettings):
    """Application settings from environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_prefix="",
    )

    memos_url: str = Field(
        ...,
        description="Memos server URL"
    )
    memos_token: str = Field(
        ...,
        description="Memos API access token"
    )
    api_version: str = Field(
        default="v1",
        description="API version path"
    )
    request_timeout: float = Field(
        default=30.0,
        description="Request timeout in seconds"
    )
    display_style: str = Field(
        default="list",
        description="Display style for memo lists: list or table"
    )

    @property
    def api_base_url(self) -> str:
        """Full API base URL."""
        base = self.memos_url.rstrip("/")
        return f"{base}/api/{self.api_version}"

    def get_memo_url(self, memo_id: str) -> str:
        """Build memo detail page URL for browser access.

        Args:
            memo_id: Memo ID (pure ID or full name like memos/xxx)

        Returns:
            Browser-accessible URL: {memos_url}/memos/{pure_id}
        """
        # Extract pure ID from full name if needed
        pure_id = memo_id.split("/")[-1] if "/" in memo_id else memo_id
        base = self.memos_url.rstrip("/")
        return f"{base}/memos/{pure_id}"


@lru_cache
def get_settings() -> Settings:
    """Get settings instance (cached singleton)."""
    try:
        return Settings()
    except Exception as e:
        missing = []
        error_str = str(e)
        if "memos_url" in error_str.lower():
            missing.append("MEMOS_URL")
        if "memos_token" in error_str.lower():
            missing.append("MEMOS_TOKEN")
        raise ConfigurationError(missing)