"""Memo CRUD tools."""

from typing import Literal

from fastmcp import FastMCP

from memos_mcp.client import MemosClient
from memos_mcp.config import get_settings
from memos_mcp.models import MemoState, MemoVisibility
from memos_mcp.utils.formatting import format_memo_list, format_memo_detail, extract_memo_id

_client: MemosClient | None = None


def get_client() -> MemosClient:
    """Get or create the singleton MemosClient instance."""
    global _client
    if _client is None:
        _client = MemosClient(get_settings())
    return _client


def _format_memo_response(memo) -> dict:
    """Format memo response with memo_id field for clarity."""
    data = memo.model_dump()
    data["memo_id"] = extract_memo_id(memo)
    return data


# ============================================
# CREATE / UPDATE / DELETE - Return JSON (unchanged)
# ============================================


async def create_memo(
    content: str,
    visibility: Literal["PRIVATE", "PROTECTED", "PUBLIC"] = "PRIVATE",
    tags: list[str] | None = None,
) -> dict:
    """Create a new memo.

    Args:
        content: The memo content (markdown supported).
        visibility: Memo visibility level (PRIVATE, PROTECTED, PUBLIC).
        tags: List of tags to apply to the memo.

    Returns:
        The created memo with memo_id field for future reference.
    """
    client = get_client()
    visibility_enum = MemoVisibility(visibility)
    memo = await client.create_memo(
        content=content,
        visibility=visibility_enum,
        tags=tags or [],
    )
    return _format_memo_response(memo)


async def update_memo(
    memo_id: str,
    content: str | None = None,
    visibility: Literal["PRIVATE", "PROTECTED", "PUBLIC"] | None = None,
    pinned: bool | None = None,
) -> dict:
    """Update an existing memo.

    Args:
        memo_id: The memo ID to update. Can be either:
            - Pure ID (e.g., "V2xmw6RkAEDo4TimKhCGNL")
            - Full name format (e.g., "memos/V2xmw6RkAEDo4TimKhCGNL")
            Both formats are accepted. Use the memo_id from list/get responses.
        content: New content for the memo (optional).
        visibility: New visibility level (optional).
        pinned: New pinned status (optional).

    Returns:
        The updated memo with memo_id field for future reference.
    """
    client = get_client()
    visibility_enum = None
    if visibility is not None:
        visibility_enum = MemoVisibility(visibility)
    memo = await client.update_memo(
        memo_id=memo_id,
        content=content,
        visibility=visibility_enum,
        pinned=pinned,
    )
    return _format_memo_response(memo)


async def delete_memo(
    memo_id: str,
) -> bool:
    """Delete a memo.

    Args:
        memo_id: The memo ID to delete. Can be either:
            - Pure ID (e.g., "V2xmw6RkAEDo4TimKhCGNL")
            - Full name format (e.g., "memos/V2xmw6RkAEDo4TimKhCGNL")
            Both formats are accepted.

    Returns:
        True if deletion was successful.
    """
    client = get_client()
    return await client.delete_memo(memo_id)


# ============================================
# QUERY - Return Markdown
# ============================================


async def list_memos(
    limit: int = 20,
    state: Literal["NORMAL", "ARCHIVED"] = "NORMAL",
    filter: str | None = None,
) -> str:
    """List memos with optional filters.

    Args:
        limit: Maximum number of memos to return.
        state: Filter by memo state (NORMAL or ARCHIVED).
        filter: Custom filter expression.

    Returns:
        Markdown formatted memo list with hyperlinks to browser.
        Display style controlled by MEMOS_DISPLAY_STYLE env var.
    """
    client = get_client()
    settings = get_settings()
    state_enum = MemoState(state)
    memos = await client.list_memos(
        limit=limit,
        state=state_enum,
        filter=filter,
    )
    return format_memo_list(memos, settings.memos_url, settings.display_style)


async def search_memos(
    query: str | None = None,
    tags: list[str] | None = None,
    limit: int = 20,
) -> str:
    """Search memos by content or tags.

    Args:
        query: Search query for memo content.
        tags: List of tags to filter by.
        limit: Maximum number of results.

    Returns:
        Markdown formatted memo list with hyperlinks to browser.
        Display style controlled by MEMOS_DISPLAY_STYLE env var.
    """
    client = get_client()
    settings = get_settings()

    # Build filter expression
    filter_parts = []

    if query:
        escaped_query = query.replace("'", "\\'")
        filter_parts.append(f"content.contains('{escaped_query}')")

    if tags:
        for tag in tags:
            escaped_tag = tag.replace("'", "\\'")
            filter_parts.append(f"tags.contains('{escaped_tag}')")

    filter_expr = None
    if filter_parts:
        filter_expr = " && ".join(filter_parts)

    memos = await client.list_memos(
        limit=limit,
        state=MemoState.NORMAL,
        filter=filter_expr,
    )
    return format_memo_list(memos, settings.memos_url, settings.display_style)


async def get_memo(
    memo_id: str,
) -> str:
    """Get a memo by ID.

    Args:
        memo_id: The memo ID. Can be either:
            - Pure ID (e.g., "V2xmw6RkAEDo4TimKhCGNL")
            - Full name format (e.g., "memos/V2xmw6RkAEDo4TimKhCGNL")
            Both formats are accepted.

    Returns:
        Markdown formatted memo detail with hyperlink to browser.
    """
    client = get_client()
    settings = get_settings()
    memo = await client.get_memo(memo_id)
    return format_memo_detail(memo, settings.memos_url)


def register_tools(mcp: FastMCP) -> None:
    """Register all memo tools with the FastMCP instance."""
    mcp.tool(create_memo)
    mcp.tool(get_memo)
    mcp.tool(update_memo)
    mcp.tool(delete_memo)
    mcp.tool(list_memos)
    mcp.tool(search_memos)