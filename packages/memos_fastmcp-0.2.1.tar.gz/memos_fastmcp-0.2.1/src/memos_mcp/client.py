"""Async HTTP client for Memos API."""

import httpx

from memos_mcp.config import Settings, get_settings
from memos_mcp.models import Memo, MemoState, MemoVisibility
from memos_mcp.exceptions import AuthenticationError, MemosNotFoundError, MemosAPIError


class MemosClient:
    """Async client for Memos API."""

    def __init__(self, settings: Settings | None = None):
        self.settings = settings or get_settings()
        self._client: httpx.AsyncClient | None = None

    def _get_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.settings.api_base_url,
                headers={
                    "Authorization": f"Bearer {self.settings.memos_token}",
                    "Content-Type": "application/json",
                },
                timeout=self.settings.request_timeout,
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None

    def _handle_error(self, response: httpx.Response, memo_id: str | None = None) -> None:
        """Handle error responses from the API."""
        if response.status_code == 401:
            raise AuthenticationError()
        if response.status_code == 404:
            raise MemosNotFoundError("Memo", memo_id or "unknown")
        if response.status_code >= 400:
            try:
                data = response.json()
                message = data.get("message", "Unknown error")
            except Exception:
                message = response.text or "Unknown error"
            raise MemosAPIError(response.status_code, message)

    async def list_memos(
        self,
        limit: int | None = None,
        state: MemoState | None = None,
        filter: str | None = None,
        order_by: str | None = None,
    ) -> list[Memo]:
        """List memos with optional filters.

        Args:
            limit: Maximum number of memos to return.
            state: Filter by memo state.
            filter: Custom filter expression.
            order_by: Order by expression.

        Returns:
            List of Memo objects.
        """
        client = self._get_client()
        params = {}

        if limit is not None:
            params["pageSize"] = limit
        if state is not None:
            params["state"] = state.value
        if filter is not None:
            params["filter"] = filter
        if order_by is not None:
            params["orderBy"] = order_by

        response = await client.get("/memos", params=params)
        self._handle_error(response)

        data = response.json()
        memos = data.get("memos", [])
        return [Memo(**memo) for memo in memos]

    async def get_memo(self, memo_id: str) -> Memo:
        """Get a single memo by ID.

        Args:
            memo_id: The memo ID (e.g., "1" or "memos/1").

        Returns:
            Memo object.
        """
        client = self._get_client()
        # Handle both raw ID and full name format
        if "/" in memo_id:
            path = f"/{memo_id}"
        else:
            path = f"/memos/{memo_id}"

        response = await client.get(path)
        self._handle_error(response, memo_id)

        data = response.json()
        return Memo(**data)

    async def create_memo(
        self,
        content: str,
        visibility: str | MemoVisibility = "PRIVATE",
        tags: list[str] | None = None,
    ) -> Memo:
        """Create a new memo.

        Args:
            content: Memo content.
            visibility: Memo visibility (PRIVATE, PROTECTED, PUBLIC).
            tags: List of tags - these are embedded in content as #tag format.

        Returns:
            Created Memo object.
        """
        client = self._get_client()

        # Convert visibility to string value
        if isinstance(visibility, MemoVisibility):
            vis_value = visibility.value
        else:
            vis_value = visibility

        # Embed tags in content if provided (Memos extracts tags from #tag format)
        # Only add tags that are not already present in content
        final_content = content
        if tags:
            # Extract existing tags from content (find all #tag patterns)
            import re
            existing_tags = set(re.findall(r'#(\w+)', content))
            # Only append tags that don't already exist in content
            new_tags = [tag for tag in tags if tag not in existing_tags]
            if new_tags:
                tag_str = " ".join(f"#{tag}" for tag in new_tags)
                final_content = f"{content} {tag_str}"

        body = {
            "content": final_content,
            "visibility": vis_value,
        }

        response = await client.post("/memos", json=body)
        self._handle_error(response)

        data = response.json()
        return Memo(**data)

    async def update_memo(
        self,
        memo_id: str,
        content: str | None = None,
        visibility: str | MemoVisibility | None = None,
        pinned: bool | None = None,
    ) -> Memo:
        """Update an existing memo.

        Args:
            memo_id: The memo ID.
            content: New content.
            visibility: New visibility (PRIVATE, PROTECTED, PUBLIC).
            pinned: New pinned status.

        Returns:
            Updated Memo object.
        """
        client = self._get_client()

        # Handle both raw ID and full name format
        if "/" in memo_id:
            path = f"/{memo_id}"
        else:
            path = f"/memos/{memo_id}"

        body = {}
        if content is not None:
            body["content"] = content
        if visibility is not None:
            # Convert visibility to string value
            if isinstance(visibility, MemoVisibility):
                body["visibility"] = visibility.value
            else:
                body["visibility"] = visibility
        if pinned is not None:
            body["pinned"] = pinned

        response = await client.patch(path, json=body)
        self._handle_error(response, memo_id)

        data = response.json()
        return Memo(**data)

    async def delete_memo(self, memo_id: str) -> bool:
        """Delete a memo.

        Args:
            memo_id: The memo ID.

        Returns:
            True if deletion was successful.
        """
        client = self._get_client()

        # Handle both raw ID and full name format
        if "/" in memo_id:
            path = f"/{memo_id}"
        else:
            path = f"/memos/{memo_id}"

        response = await client.delete(path)
        self._handle_error(response, memo_id)

        return True

    async def list_tags(self, limit: int | None = None) -> dict[str, int]:
        """List all tags with usage counts.

        Args:
            limit: Maximum number of tags to return.

        Returns:
            Dictionary mapping tag names to usage counts.
        """
        # Get all memos to extract tags
        memos = await self.list_memos(limit=limit or 1000)

        # Count tag usage
        tag_counts: dict[str, int] = {}
        for memo in memos:
            for tag in memo.tags:
                tag_counts[tag] = tag_counts.get(tag, 0) + 1

        # Sort by count descending
        sorted_tags = dict(
            sorted(tag_counts.items(), key=lambda x: (-x[1], x[0]))
        )

        if limit:
            # Apply limit after sorting
            sorted_tags = dict(list(sorted_tags.items())[:limit])

        return sorted_tags

    async def rename_tag(self, old_name: str, new_name: str) -> list[Memo]:
        """Rename a tag across all memos.

        Args:
            old_name: Current tag name.
            new_name: New tag name.

        Returns:
            List of updated memos.
        """
        # Find all memos with the old tag
        memos = await self.list_memos(filter=f"tags.contains('{old_name}')")
        updated_memos = []

        for memo in memos:
            if old_name in memo.tags:
                # Update the memo content to replace the tag reference
                new_content = memo.content.replace(f"#{old_name}", f"#{new_name}")
                updated = await self.update_memo(
                    memo.name,
                    content=new_content,
                )
                updated_memos.append(updated)

        return updated_memos

    async def delete_tag(self, tag_name: str) -> list[Memo]:
        """Delete a tag from all memos.

        Args:
            tag_name: Tag name to delete.

        Returns:
            List of updated memos.
        """
        # Find all memos with the tag
        memos = await self.list_memos(filter=f"tags.contains('{tag_name}')")
        updated_memos = []

        for memo in memos:
            if tag_name in memo.tags:
                # Remove the tag from the memo content
                new_content = memo.content.replace(f"#{tag_name}", "")
                # Clean up content (remove extra spaces)
                new_content = new_content.strip()
                updated = await self.update_memo(
                    memo.name,
                    content=new_content,
                )
                updated_memos.append(updated)

        return updated_memos