"""MCP Resources for Memos."""

from fastmcp import FastMCP

from memos_mcp.client import MemosClient
from memos_mcp.config import get_settings
from memos_mcp.models import MemoState
from memos_mcp.utils import (
    format_memo_detail,
    format_memo_list,
    format_stats,
    format_tags_list,
)

_client: MemosClient | None = None


def get_client() -> MemosClient:
    """Get or create the singleton MemosClient instance."""
    global _client
    if _client is None:
        _client = MemosClient(get_settings())
    return _client


async def get_memo_list() -> str:
    """Get a summary list of recent memos.

    Returns the last 20 memos with summary information including:
    - Memo ID
    - Title (extracted from content)
    - Tags
    - Created time
    - Visibility

    URI: memos://list
    """
    client = get_client()
    settings = get_settings()
    memos = await client.list_memos(limit=20, state=MemoState.NORMAL)
    return format_memo_list(memos, settings.memos_url, settings.display_style)


async def get_memo_detail(memo_id: str) -> str:
    """Get full details of a single memo.

    Args:
        memo_id: The memo ID (e.g., "1" or "memos/1").

    Returns the complete memo content and metadata including:
    - Full markdown content
    - Creation and update timestamps
    - Visibility and state
    - Tags
    - Attachments

    URI: memos://{memo_id}
    """
    client = get_client()
    settings = get_settings()
    memo = await client.get_memo(memo_id)
    return format_memo_detail(memo, settings.memos_url)


async def get_tags() -> str:
    """Get all tags with their usage counts.

    Returns a table showing each tag and how many memos use it,
    sorted by usage count (most used first).

    URI: memos://tags
    """
    client = get_client()
    tags = await client.list_tags()
    return format_tags_list(tags)


async def get_stats() -> str:
    """Get statistics about the Memos instance.

    Returns statistics including:
    - Total number of memos
    - Memos by visibility (PRIVATE, PROTECTED, PUBLIC)
    - Memos by state (NORMAL, ARCHIVED)
    - Number of unique tags
    - Number of pinned memos

    URI: memos://stats
    """
    client = get_client()

    # Get all memos for stats calculation
    all_memos = await client.list_memos(limit=1000)

    # Calculate statistics
    total = len(all_memos)

    by_visibility: dict[str, int] = {}
    by_state: dict[str, int] = {}
    all_tags: set[str] = set()
    pinned_count = 0

    for memo in all_memos:
        # Visibility stats
        vis_key = memo.visibility.value if memo.visibility else "UNKNOWN"
        by_visibility[vis_key] = by_visibility.get(vis_key, 0) + 1

        # State stats
        state_key = memo.state.value if memo.state else "UNKNOWN"
        by_state[state_key] = by_state.get(state_key, 0) + 1

        # Collect tags
        for tag in memo.tags:
            all_tags.add(tag)

        # Pinned count
        if memo.pinned:
            pinned_count += 1

    stats = {
        "total": total,
        "by_visibility": by_visibility,
        "by_state": by_state,
        "total_tags": len(all_tags),
        "pinned": pinned_count,
    }

    return format_stats(stats)


def register_resources(mcp: FastMCP) -> None:
    """Register all resources with the FastMCP instance."""
    mcp.resource("memos://list")(get_memo_list)
    mcp.resource("memos://{memo_id}")(get_memo_detail)
    mcp.resource("memos://tags")(get_tags)
    mcp.resource("memos://stats")(get_stats)