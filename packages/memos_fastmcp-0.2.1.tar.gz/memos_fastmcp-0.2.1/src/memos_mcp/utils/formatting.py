"""Formatting utilities for Markdown output with list/table styles."""

from datetime import datetime

from memos_mcp.models import Memo, MemoVisibility


def truncate_content(content: str, max_length: int = 200) -> str:
    """Truncate content to specified length.

    Args:
        content: Original content string.
        max_length: Maximum length (default 200 for list, 50 for table).

    Returns:
        Truncated string with '...' suffix if needed.
    """
    if not content:
        return "(empty)"

    # Remove newlines for display
    display = content.strip().replace("\n", " ")

    if len(display) <= max_length:
        return display

    return display[:max_length] + "..."


def format_datetime_short(dt: datetime | str | None) -> str:
    """Format datetime as short date (YYYY-MM-DD) for table."""
    if dt is None:
        return "-"

    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt.replace("Z", "+00:00"))
        except ValueError:
            return dt

    return dt.strftime("%Y-%m-%d")


def format_datetime_full(dt: datetime | str | None) -> str:
    """Format datetime as full (YYYY-MM-DD HH:MM:SS) for list."""
    if dt is None:
        return "-"

    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt.replace("Z", "+00:00"))
        except ValueError:
            return dt

    return dt.strftime("%Y-%m-%d %H:%M:%S")


def format_status_text(memo: Memo) -> str:
    """Format status text (pinned/normal + visibility).

    Args:
        memo: Memo object.

    Returns:
        Status text like '置顶 | 公开' or '普通 | 私密'.
    """
    pinned_text = "置顶" if memo.pinned else "普通"

    vis_map = {
        MemoVisibility.PRIVATE: "私密",
        MemoVisibility.PROTECTED: "保护",
        MemoVisibility.PUBLIC: "公开",
    }
    vis_text = vis_map.get(memo.visibility, "未知")

    return f"{pinned_text} | {vis_text}"


def extract_memo_id(memo: Memo) -> str:
    """Extract pure memo ID from name field.

    Args:
        memo: Memo object.

    Returns:
        Pure ID (e.g., 'V2xmw6RkAEDo4TimKhCGNL').
    """
    name = memo.name
    return name.split("/")[-1] if "/" in name else name


def format_memo_list(memos: list[Memo], base_url: str, style: str = "list") -> str:
    """Format memo list as Markdown (list or table style).

    Args:
        memos: List of Memo objects.
        base_url: Base URL for constructing memo links.
        style: Display style - 'list' or 'table'.

    Returns:
        Markdown formatted string.
    """
    if not memos:
        return "## Memo 列表\n\n暂无 memo。"

    if style == "table":
        return _format_memo_table(memos, base_url)
    return _format_memo_list_items(memos, base_url)


def _format_memo_list_items(memos: list[Memo], base_url: str) -> str:
    """Format memos as list items (default style).

    Content truncated to 200 chars. Full datetime shown.
    """
    lines = [f"## Memo 列表 (共 {len(memos)} 条)", ""]

    for i, memo in enumerate(memos, 1):
        memo_id = extract_memo_id(memo)
        memo_url = f"{base_url}/memos/{memo_id}"

        lines.append(f"### {i}. [{memo_id}]({memo_url})")
        lines.append(f"- **内容**: {truncate_content(memo.content, 200)}")
        lines.append(f"- **标签**: {', '.join(memo.tags) if memo.tags else '无'}")
        lines.append(f"- **时间**: {format_datetime_full(memo.create_time)}")
        lines.append(f"- **状态**: {format_status_text(memo)}")
        lines.append("")

    return "\n".join(lines)


def _format_memo_table(memos: list[Memo], base_url: str) -> str:
    """Format memos as table (compact style).

    Content truncated to 50 chars. Date only shown.
    ID not truncated (full ID for copying).
    """
    lines = [
        f"## Memo 列表 (共 {len(memos)} 条)",
        "",
        "| ID | 内容 | 标签 | 时间 | 状态 |",
        "|---|---|---|---|---|",
    ]

    for memo in memos:
        memo_id = extract_memo_id(memo)
        memo_url = f"{base_url}/memos/{memo_id}"

        # ID with full link (not truncated)
        id_cell = f"[{memo_id}]({memo_url})"
        content_cell = truncate_content(memo.content, 50)
        tags_cell = ", ".join(memo.tags) if memo.tags else "-"
        time_cell = format_datetime_short(memo.create_time)
        status_cell = format_status_text(memo)

        lines.append(f"| {id_cell} | {content_cell} | {tags_cell} | {time_cell} | {status_cell} |")

    return "\n".join(lines)


def format_memo_detail(memo: Memo, base_url: str) -> str:
    """Format single memo detail as Markdown.

    Args:
        memo: Memo object.
        base_url: Base URL for constructing memo link.

    Returns:
        Markdown formatted detail (always list style).
    """
    memo_id = extract_memo_id(memo)
    memo_url = f"{base_url}/memos/{memo_id}"

    lines = [
        "## Memo 详情",
        "",
        f"### [{memo_id}]({memo_url})",
        "",
        "**完整内容**:",
        memo.content or "(empty)",
        "",
        "**元信息**:",
        f"- 标签: {', '.join(memo.tags) if memo.tags else '无'}",
        f"- 可见性: {memo.visibility.value if memo.visibility else '-'}",
        f"- 创建时间: {format_datetime_full(memo.create_time)}",
        f"- 更新时间: {format_datetime_full(memo.update_time)}",
        f"- 状态: {memo.state.value if memo.state else '-'}",
        f"- 置顶: {'是' if memo.pinned else '否'}",
    ]

    return "\n".join(lines)


def format_tags_list(tags: dict[str, int]) -> str:
    """Format tags statistics as Markdown list.

    Args:
        tags: Dictionary mapping tag names to usage counts.

    Returns:
        Markdown formatted list (always list style).
    """
    if not tags:
        return "## 标签统计\n\n暂无标签。"

    # Sort by count descending
    sorted_tags = sorted(tags.items(), key=lambda x: (-x[1], x[0]))

    lines = [f"## 标签统计 (共 {len(sorted_tags)} 个)", ""]

    for tag, count in sorted_tags:
        lines.append(f"- **{tag}**: {count} 条")

    return "\n".join(lines)


def format_stats(stats: dict) -> str:
    """Format statistics as Markdown.

    Args:
        stats: Dictionary with statistics data.

    Returns:
        Markdown formatted statistics.
    """
    lines = ["## 统计信息", ""]

    if "total" in stats:
        lines.append(f"- **总 Memo 数**: {stats['total']}")

    if "by_visibility" in stats:
        lines.append("")
        lines.append("### 按可见性")
        for vis, count in stats["by_visibility"].items():
            lines.append(f"- **{vis}**: {count}")

    if "by_state" in stats:
        lines.append("")
        lines.append("### 按状态")
        for state, count in stats["by_state"].items():
            lines.append(f"- **{state}**: {count}")

    if "total_tags" in stats:
        lines.append("")
        lines.append(f"- **唯一标签数**: {stats['total_tags']}")

    if "pinned" in stats:
        lines.append(f"- **置顶数**: {stats['pinned']}")

    return "\n".join(lines)