"""Tests for MCP Memo tools."""

import pytest
import respx
import httpx

from memos_mcp.tools.memo_tools import (
    create_memo,
    get_memo,
    update_memo,
    delete_memo,
    list_memos,
    search_memos,
    get_client,
    register_tools,
)
from memos_mcp.config import Settings


@pytest.fixture
def settings(monkeypatch):
    """Test settings fixture."""
    test_settings = Settings(
        memos_url="https://memos.example.com",
        memos_token="test-token",
        api_version="v1",
        request_timeout=30.0,
        display_style="list",
    )
    # Clear the cached client
    import memos_mcp.tools.memo_tools as tools_module
    tools_module._client = None
    monkeypatch.setattr("memos_mcp.tools.memo_tools.get_settings", lambda: test_settings)
    return test_settings


@pytest.fixture
def sample_memo_response():
    """Sample memo response from API."""
    return {
        "name": "memos/1",
        "state": "NORMAL",
        "creator": "users/1",
        "content": "Test memo content",
        "visibility": "PRIVATE",
        "pinned": False,
        "tags": ["tag1", "tag2"],
        "createTime": "2024-01-01T12:00:00Z",
        "updateTime": "2024-01-01T12:30:00Z",
        "displayTime": "2024-01-01T12:00:00Z",
        "attachments": [],
    }


class TestGetClient:
    """Tests for get_client function."""

    def test_get_client_creates_client(self, settings):
        """Test get_client creates a client."""
        client = get_client()
        assert client is not None
        assert client.settings == settings

    def test_get_client_returns_same_instance(self, settings):
        """Test get_client returns singleton client."""
        client1 = get_client()
        client2 = get_client()
        assert client1 is client2


class TestCreateMemo:
    """Tests for create_memo tool - returns dict."""

    @pytest.mark.asyncio
    async def test_create_memo_success(self, settings, sample_memo_response):
        """Test successful create_memo tool call."""
        sample_memo_response["content"] = "New memo content"
        sample_memo_response["tags"] = ["work", "important"]

        with respx.mock:
            respx.post("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            result = await create_memo(
                content="New memo content",
                visibility="PRIVATE",
                tags=["work", "important"],
            )

        assert result["name"] == "memos/1"
        assert result["content"] == "New memo content"
        assert result["tags"] == ["work", "important"]

    @pytest.mark.asyncio
    async def test_create_memo_default_visibility(self, settings, sample_memo_response):
        """Test create_memo with default visibility."""
        sample_memo_response["content"] = "Test"

        with respx.mock:
            route = respx.post("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            result = await create_memo(content="Test")

        assert result["visibility"] == "PRIVATE"
        request = route.calls[0].request
        body = request.content.decode()
        assert '"visibility":"PRIVATE"' in body

    @pytest.mark.asyncio
    async def test_create_memo_public_visibility(self, settings, sample_memo_response):
        """Test create_memo with PUBLIC visibility."""
        sample_memo_response["visibility"] = "PUBLIC"

        with respx.mock:
            respx.post("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            result = await create_memo(content="Public memo", visibility="PUBLIC")

        assert result["visibility"] == "PUBLIC"

    @pytest.mark.asyncio
    async def test_create_memo_with_tags(self, settings, sample_memo_response):
        """Test create_memo with tags."""
        sample_memo_response["tags"] = ["tag1", "tag2"]

        with respx.mock:
            respx.post("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            result = await create_memo(content="Tagged memo", tags=["tag1", "tag2"])

        assert result["tags"] == ["tag1", "tag2"]

    @pytest.mark.asyncio
    async def test_create_memo_no_tags(self, settings, sample_memo_response):
        """Test create_memo without tags."""
        sample_memo_response["tags"] = []

        with respx.mock:
            respx.post("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            result = await create_memo(content="No tags memo", tags=None)

        assert result["tags"] == []


class TestGetMemo:
    """Tests for get_memo tool - returns markdown string."""

    @pytest.mark.asyncio
    async def test_get_memo_success(self, settings, sample_memo_response):
        """Test successful get_memo tool call returns markdown."""
        with respx.mock:
            respx.get("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            result = await get_memo("1")

        # Now returns markdown string, not dict
        assert isinstance(result, str)
        assert "1" in result  # memo_id should be in markdown
        assert "https://memos.example.com/memos/1" in result  # hyperlink

    @pytest.mark.asyncio
    async def test_get_memo_with_full_name(self, settings, sample_memo_response):
        """Test get_memo with full memo name format."""
        with respx.mock:
            respx.get("https://memos.example.com/api/v1/memos/123").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            result = await get_memo("memos/123")

        assert isinstance(result, str)

    @pytest.mark.asyncio
    async def test_get_memo_not_found(self, settings):
        """Test get_memo with non-existent memo."""
        from memos_mcp.exceptions import MemosNotFoundError

        with respx.mock:
            respx.get("https://memos.example.com/api/v1/memos/999").mock(
                return_value=httpx.Response(404, json={"message": "Memo not found"})
            )
            with pytest.raises(MemosNotFoundError):
                await get_memo("999")


class TestUpdateMemo:
    """Tests for update_memo tool - returns dict."""

    @pytest.mark.asyncio
    async def test_update_memo_content(self, settings, sample_memo_response):
        """Test update_memo with content update."""
        sample_memo_response["content"] = "Updated content"

        with respx.mock:
            respx.patch("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            result = await update_memo("1", content="Updated content")

        assert result["content"] == "Updated content"

    @pytest.mark.asyncio
    async def test_update_memo_visibility(self, settings, sample_memo_response):
        """Test update_memo with visibility update."""
        sample_memo_response["visibility"] = "PUBLIC"

        with respx.mock:
            respx.patch("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            result = await update_memo("1", visibility="PUBLIC")

        assert result["visibility"] == "PUBLIC"

    @pytest.mark.asyncio
    async def test_update_memo_pinned(self, settings, sample_memo_response):
        """Test update_memo with pinned update."""
        sample_memo_response["pinned"] = True

        with respx.mock:
            respx.patch("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            result = await update_memo("1", pinned=True)

        assert result["pinned"] is True

    @pytest.mark.asyncio
    async def test_update_memo_multiple_fields(self, settings, sample_memo_response):
        """Test update_memo with multiple field updates."""
        sample_memo_response["content"] = "Updated"
        sample_memo_response["visibility"] = "PUBLIC"
        sample_memo_response["pinned"] = True

        with respx.mock:
            respx.patch("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            result = await update_memo(
                "1",
                content="Updated",
                visibility="PUBLIC",
                pinned=True,
            )

        assert result["content"] == "Updated"
        assert result["visibility"] == "PUBLIC"
        assert result["pinned"] is True

    @pytest.mark.asyncio
    async def test_update_memo_no_changes(self, settings, sample_memo_response):
        """Test update_memo with no field updates."""
        with respx.mock:
            respx.patch("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            result = await update_memo("1")

        assert result["name"] == "memos/1"


class TestDeleteMemo:
    """Tests for delete_memo tool - returns bool."""

    @pytest.mark.asyncio
    async def test_delete_memo_success(self, settings):
        """Test successful delete_memo tool call."""
        with respx.mock:
            respx.delete("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(200, json={})
            )
            result = await delete_memo("1")

        assert result is True

    @pytest.mark.asyncio
    async def test_delete_memo_not_found(self, settings):
        """Test delete_memo with non-existent memo."""
        from memos_mcp.exceptions import MemosNotFoundError

        with respx.mock:
            respx.delete("https://memos.example.com/api/v1/memos/999").mock(
                return_value=httpx.Response(404, json={"message": "Memo not found"})
            )
            with pytest.raises(MemosNotFoundError):
                await delete_memo("999")


class TestListMemos:
    """Tests for list_memos tool - returns markdown string."""

    @pytest.mark.asyncio
    async def test_list_memos_success(self, settings, sample_memo_response):
        """Test successful list_memos tool call returns markdown."""
        with respx.mock:
            respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": [sample_memo_response]})
            )
            results = await list_memos()

        # Now returns markdown string, not list
        assert isinstance(results, str)
        assert "1" in results  # memo_id in markdown
        assert "https://memos.example.com/memos/1" in results  # hyperlink

    @pytest.mark.asyncio
    async def test_list_memos_with_limit(self, settings, sample_memo_response):
        """Test list_memos with limit parameter."""
        with respx.mock:
            route = respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": [sample_memo_response]})
            )
            await list_memos(limit=10)

        request = route.calls[0].request
        assert "pageSize=10" in str(request.url)

    @pytest.mark.asyncio
    async def test_list_memos_with_state(self, settings, sample_memo_response):
        """Test list_memos with state parameter."""
        with respx.mock:
            route = respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": [sample_memo_response]})
            )
            await list_memos(state="NORMAL")

        request = route.calls[0].request
        assert "state=NORMAL" in str(request.url)

    @pytest.mark.asyncio
    async def test_list_memos_with_filter(self, settings, sample_memo_response):
        """Test list_memos with filter parameter."""
        with respx.mock:
            route = respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": [sample_memo_response]})
            )
            await list_memos(filter="creator == 'users/1'")

        request = route.calls[0].request
        assert "filter" in str(request.url)

    @pytest.mark.asyncio
    async def test_list_memos_default_state(self, settings, sample_memo_response):
        """Test list_memos uses NORMAL as default state."""
        with respx.mock:
            route = respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": [sample_memo_response]})
            )
            await list_memos()

        request = route.calls[0].request
        assert "state=NORMAL" in str(request.url)

    @pytest.mark.asyncio
    async def test_list_memos_empty(self, settings):
        """Test list_memos with empty result."""
        with respx.mock:
            respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": []})
            )
            results = await list_memos()

        # Now returns markdown string with "no memos" message
        assert isinstance(results, str)
        assert "暂无 memo" in results


class TestSearchMemos:
    """Tests for search_memos tool - returns markdown string."""

    @pytest.mark.asyncio
    async def test_search_memos_by_query(self, settings, sample_memo_response):
        """Test search_memos with query parameter."""
        with respx.mock:
            route = respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": [sample_memo_response]})
            )
            results = await search_memos(query="test")

        assert isinstance(results, str)
        request = route.calls[0].request
        assert "filter" in str(request.url)

    @pytest.mark.asyncio
    async def test_search_memos_by_tags(self, settings, sample_memo_response):
        """Test search_memos with tags parameter."""
        sample_memo_response["tags"] = ["work", "important"]

        with respx.mock:
            route = respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": [sample_memo_response]})
            )
            results = await search_memos(tags=["work", "important"])

        assert isinstance(results, str)
        request = route.calls[0].request
        url = str(request.url)
        assert "filter" in url

    @pytest.mark.asyncio
    async def test_search_memos_by_query_and_tags(self, settings, sample_memo_response):
        """Test search_memos with both query and tags."""
        with respx.mock:
            route = respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": [sample_memo_response]})
            )
            results = await search_memos(query="test", tags=["work"])

        assert isinstance(results, str)
        request = route.calls[0].request
        url = str(request.url)
        assert "filter" in url

    @pytest.mark.asyncio
    async def test_search_memos_with_limit(self, settings, sample_memo_response):
        """Test search_memos with limit parameter."""
        with respx.mock:
            route = respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": [sample_memo_response]})
            )
            await search_memos(query="test", limit=5)

        request = route.calls[0].request
        assert "pageSize=5" in str(request.url)

    @pytest.mark.asyncio
    async def test_search_memos_no_params(self, settings, sample_memo_response):
        """Test search_memos without query or tags returns all memos."""
        with respx.mock:
            route = respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": [sample_memo_response]})
            )
            results = await search_memos()

        assert isinstance(results, str)
        request = route.calls[0].request
        # Should still apply default state filter
        assert "state=NORMAL" in str(request.url)

    @pytest.mark.asyncio
    async def test_search_memos_empty(self, settings):
        """Test search_memos with no results."""
        with respx.mock:
            respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": []})
            )
            results = await search_memos(query="nonexistent")

        assert isinstance(results, str)
        assert "暂无 memo" in results


class TestRegisterTools:
    """Tests for register_tools function."""

    @pytest.mark.asyncio
    async def test_register_tools(self, settings):
        """Test that register_tools adds tools to FastMCP."""
        from fastmcp import FastMCP

        mcp = FastMCP("test-server")
        register_tools(mcp)

        # Verify tools are registered by listing them
        tools = await mcp.list_tools()
        tool_names = [tool.name for tool in tools]

        assert "create_memo" in tool_names
        assert "get_memo" in tool_names
        assert "update_memo" in tool_names
        assert "delete_memo" in tool_names
        assert "list_memos" in tool_names
        assert "search_memos" in tool_names