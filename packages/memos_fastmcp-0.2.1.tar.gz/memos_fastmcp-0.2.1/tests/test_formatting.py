"""Tests for formatting utilities."""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from datetime import datetime

from memos_mcp.models import Memo, MemoState, MemoVisibility
from memos_mcp.utils.formatting import (
    truncate_content,
    format_datetime_short,
    format_datetime_full,
    format_status_text,
    extract_memo_id,
    format_memo_list,
    format_memo_detail,
    format_tags_list,
)


def create_test_memo(
    name: str = "memos/V2xmw6RkAEDo4TimKhCGNL",
    content: str = "测试内容 #TEST",
    tags: list[str] = ["TEST"],
    pinned: bool = False,
    visibility: MemoVisibility = MemoVisibility.PRIVATE,
) -> Memo:
    """Create a test memo object."""
    return Memo(
        name=name,
        state=MemoState.NORMAL,
        creator="users/1",
        content=content,
        visibility=visibility,
        pinned=pinned,
        tags=tags,
        create_time=datetime(2026, 4, 11, 17, 27, 49),
        update_time=datetime(2026, 4, 11, 17, 30, 0),
        display_time=datetime(2026, 4, 11, 17, 27, 49),
    )


def test_truncate_content_short():
    """Test truncate with short content."""
    result = truncate_content("短内容", 200)
    assert result == "短内容"


def test_truncate_content_long():
    """Test truncate with long content."""
    long_content = "这是一段很长的内容用于测试截断功能" * 10
    result = truncate_content(long_content, 200)
    # Content should be truncated if longer than 200
    if len(long_content) > 200:
        assert result.endswith("...")
    else:
        # If content is shorter, no truncation
        assert result == long_content.strip().replace("\n", " ")


def test_truncate_content_table():
    """Test truncate for table (50 chars)."""
    content = "这是一段测试内容用于表格显示截断测试"
    result = truncate_content(content, 50)
    assert len(result) <= 53


def test_extract_memo_id():
    """Test extracting memo ID from name."""
    memo = create_test_memo(name="memos/abc123")
    assert extract_memo_id(memo) == "abc123"

    memo = create_test_memo(name="xyz789")
    assert extract_memo_id(memo) == "xyz789"


def test_format_status_text():
    """Test status text formatting."""
    memo = create_test_memo(pinned=True, visibility=MemoVisibility.PUBLIC)
    assert format_status_text(memo) == "置顶 | 公开"

    memo = create_test_memo(pinned=False, visibility=MemoVisibility.PRIVATE)
    assert format_status_text(memo) == "普通 | 私密"


def test_format_memo_list_list_style():
    """Test list format style."""
    memos = [create_test_memo()]
    result = format_memo_list(memos, "http://test.com", "list")

    assert "## Memo 列表 (共 1 条)" in result
    assert "[V2xmw6RkAEDo4TimKhCGNL](http://test.com/memos/V2xmw6RkAEDo4TimKhCGNL)" in result
    assert "- **内容**:" in result
    assert "- **标签**: TEST" in result


def test_format_memo_list_table_style():
    """Test table format style."""
    memos = [create_test_memo()]
    result = format_memo_list(memos, "http://test.com", "table")

    assert "## Memo 列表 (共 1 条)" in result
    assert "| ID | 内容 | 标签 | 时间 | 状态 |" in result
    # ID should be full (not truncated) with link
    assert "[V2xmw6RkAEDo4TimKhCGNL](http://test.com/memos/V2xmw6RkAEDo4TimKhCGNL)" in result


def test_format_memo_list_empty():
    """Test empty memo list."""
    result = format_memo_list([], "http://test.com", "list")
    assert "暂无 memo" in result


def test_format_memo_detail():
    """Test memo detail format."""
    memo = create_test_memo()
    result = format_memo_detail(memo, "http://test.com")

    assert "## Memo 详情" in result
    assert "[V2xmw6RkAEDo4TimKhCGNL](http://test.com/memos/V2xmw6RkAEDo4TimKhCGNL)" in result
    assert "**完整内容**:" in result
    assert "测试内容 #TEST" in result


def test_format_tags_list():
    """Test tags list format."""
    tags = {"TEST": 5, "工作": 3}
    result = format_tags_list(tags)

    assert "## 标签统计 (共 2 个)" in result
    assert "- **TEST**: 5 条" in result
    assert "- **工作**: 3 条" in result


if __name__ == "__main__":
    test_truncate_content_short()
    test_truncate_content_long()
    test_truncate_content_table()
    test_extract_memo_id()
    test_format_status_text()
    test_format_memo_list_list_style()
    test_format_memo_list_table_style()
    test_format_memo_list_empty()
    test_format_memo_detail()
    test_format_tags_list()
    print("All tests passed!")