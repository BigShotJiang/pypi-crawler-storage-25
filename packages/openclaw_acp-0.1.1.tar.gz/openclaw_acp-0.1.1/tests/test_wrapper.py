"""Tests for the OpenClaw ACP wrapper core logic."""

import io
import json
import os
import socket
import sys
import threading
import time
from unittest.mock import MagicMock, patch

import pytest

# Add parent directory to path so we can import the module
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from wrapper import OpenClawAcpWrapper


class TestMessageTransforms:
    """Tests for protocol translation methods."""

    def test_transform_client_to_acp_initialize(self):
        """initialize protocolVersion should be rewritten to 1."""
        wrapper = OpenClawAcpWrapper()
        msg = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {"protocolVersion": "2025-03-26"},
        }
        result = wrapper._transform_client_to_acp(json.dumps(msg))
        parsed = json.loads(result)
        assert parsed["params"]["protocolVersion"] == 1
        assert wrapper.client_protocol_version == "2025-03-26"

    def test_transform_client_to_acp_non_initialize(self):
        """Non-initialize messages should pass through unchanged."""
        wrapper = OpenClawAcpWrapper()
        msg = {"jsonrpc": "2.0", "id": 2, "method": "tools/list"}
        result = wrapper._transform_client_to_acp(json.dumps(msg))
        assert json.loads(result) == msg

    def test_transform_client_to_acp_invalid_json(self):
        """Invalid JSON should be returned as-is."""
        wrapper = OpenClawAcpWrapper()
        text = "not-json{"
        assert wrapper._transform_client_to_acp(text) == text

    def test_transform_acp_to_client_protocol_version(self):
        """ACP response protocolVersion should be restored to client version."""
        wrapper = OpenClawAcpWrapper()
        wrapper.client_protocol_version = "2025-03-26"
        msg = {"jsonrpc": "2.0", "id": 1, "result": {"protocolVersion": 1}}
        result = wrapper._transform_acp_to_client(json.dumps(msg))
        parsed = json.loads(result)
        assert parsed["result"]["protocolVersion"] == "2025-03-26"

    def test_transform_acp_to_client_no_version(self):
        """If no client version stored, ACP response should pass through."""
        wrapper = OpenClawAcpWrapper()
        wrapper.client_protocol_version = None
        msg = {"jsonrpc": "2.0", "id": 1, "result": {"protocolVersion": 1}}
        result = wrapper._transform_acp_to_client(json.dumps(msg))
        assert json.loads(result) == msg

    def test_transform_acp_to_client_invalid_json(self):
        """Invalid JSON should be returned as-is."""
        wrapper = OpenClawAcpWrapper()
        text = "not-json{"
        assert wrapper._transform_acp_to_client(text) == text


class TestWriteMessage:
    """Tests for _write_message static method."""

    def test_write_message_text_stream(self):
        """Write to a text stream (StringIO)."""
        stream = io.StringIO()
        obj = {"jsonrpc": "2.0", "id": 1, "result": "ok"}
        OpenClawAcpWrapper._write_message(stream, obj)
        stream.seek(0)
        content = stream.read()
        assert content.startswith("Content-Length:")
        # Extract body
        _, body = content.split("\r\n\r\n", 1)
        assert json.loads(body) == obj

    def test_write_message_binary_stream(self):
        """Write to a binary stream (BytesIO with 'wb' mode)."""
        stream = io.BytesIO()
        # Monkey-patch mode so the method treats it as binary
        stream.mode = "wb"
        obj = {"jsonrpc": "2.0", "id": 1, "result": "ok"}
        OpenClawAcpWrapper._write_message(stream, obj)
        stream.seek(0)
        content = stream.read()
        assert content.startswith(b"Content-Length:")
        _, body = content.split(b"\r\n\r\n", 1)
        assert json.loads(body.decode("utf-8")) == obj


class TestReadMessages:
    """Tests for _read_messages static method."""

    def test_read_content_length_framed(self):
        """Read Content-Length framed messages."""
        callback = MagicMock()
        payload = json.dumps({"jsonrpc": "2.0", "id": 1})
        body = payload.encode("utf-8")
        header = f"Content-Length: {len(body)}\r\n\r\n".encode("utf-8")
        stream = io.BytesIO(header + body)

        OpenClawAcpWrapper._read_messages(stream, callback)
        callback.assert_called_once_with(payload)

    def test_read_newline_delimited(self):
        """Read newline-delimited JSON messages."""
        callback = MagicMock()
        payload = json.dumps({"jsonrpc": "2.0", "id": 2})
        stream = io.BytesIO((payload + "\n").encode("utf-8"))

        OpenClawAcpWrapper._read_messages(stream, callback)
        callback.assert_called_once_with(payload)

    def test_read_multiple_messages(self):
        """Read multiple mixed messages."""
        callback = MagicMock()
        p1 = json.dumps({"id": 1})
        p2 = json.dumps({"id": 2})
        data = (
            f"Content-Length: {len(p1.encode('utf-8'))}\r\n\r\n{p1}"
            f"{p2}\n"
        ).encode("utf-8")
        stream = io.BytesIO(data)

        OpenClawAcpWrapper._read_messages(stream, callback)
        assert callback.call_count == 2
        assert callback.call_args_list[0][0][0] == p1
        assert callback.call_args_list[1][0][0] == p2


class TestUtilityMethods:
    """Tests for helper / utility methods."""

    def test_get_openclaw_bin_found_in_path(self):
        """If openclaw is in PATH, return it directly."""
        with patch("wrapper.shutil.which", return_value="/usr/bin/openclaw"):
            wrapper = OpenClawAcpWrapper()
            assert wrapper._get_openclaw_bin() == "openclaw"

    def test_get_openclaw_bin_fallback(self):
        """If not in PATH but exists at fallback location, return fallback."""
        with patch("wrapper.shutil.which", return_value=None):
            with patch("wrapper.os.path.isfile", return_value=True):
                wrapper = OpenClawAcpWrapper(openclaw_bin="openclaw")
                assert wrapper._get_openclaw_bin() == "/opt/homebrew/bin/openclaw"

    def test_get_openclaw_bin_not_found(self):
        """If nowhere to be found, return the original name."""
        with patch("wrapper.shutil.which", return_value=None):
            with patch("wrapper.os.path.isfile", return_value=False):
                wrapper = OpenClawAcpWrapper(openclaw_bin="openclaw")
                assert wrapper._get_openclaw_bin() == "openclaw"

    def test_get_env_prepends_paths(self):
        """Extra paths should be prepended to PATH."""
        with patch.dict(os.environ, {"PATH": "/usr/bin"}, clear=True):
            with patch("wrapper.os.path.isdir", return_value=True):
                wrapper = OpenClawAcpWrapper()
                env = wrapper._get_env()
                assert env["PATH"].startswith("/opt/homebrew/bin:/usr/local/bin:/usr/bin")

    def test_is_gateway_ready_when_open(self):
        """_is_gateway_ready should return True when port is open."""
        mock_sock = MagicMock()
        with patch("wrapper.socket.socket", return_value=mock_sock):
            wrapper = OpenClawAcpWrapper()
            assert wrapper._is_gateway_ready() is True
            mock_sock.connect.assert_called_once_with(("127.0.0.1", 18789))
            mock_sock.close.assert_called_once()

    def test_is_gateway_ready_when_closed(self):
        """_is_gateway_ready should return False when connection refused."""
        mock_sock = MagicMock()
        mock_sock.connect.side_effect = OSError("Connection refused")
        with patch("wrapper.socket.socket", return_value=mock_sock):
            wrapper = OpenClawAcpWrapper()
            assert wrapper._is_gateway_ready() is False


class TestHandleClientMessage:
    """Tests for _handle_client_message."""

    def test_initialize_responds_immediately(self):
        """An initialize request should get an immediate response."""
        wrapper = OpenClawAcpWrapper()
        wrapper.acp_process = MagicMock()
        wrapper.acp_process.stdin = MagicMock()

        with patch.object(wrapper, "_write_json_line") as mock_write:
            msg = {
                "jsonrpc": "2.0",
                "id": 42,
                "method": "initialize",
                "params": {"protocolVersion": "2025-03-26"},
            }
            wrapper._handle_client_message(json.dumps(msg))

            assert wrapper.initialized is True
            mock_write.assert_called_once()
            written = mock_write.call_args[0][1]
            assert written["id"] == 42
            assert written["result"]["protocolVersion"] == "2025-03-26"
            assert written["result"]["serverInfo"]["name"] == "openclaw-acp-wrapper"

    def test_non_initialize_forwarded_to_acp(self):
        """Non-initialize messages should be forwarded to acp_process."""
        wrapper = OpenClawAcpWrapper()
        wrapper.acp_process = MagicMock()
        wrapper.acp_process.stdin = MagicMock()

        msg = {"jsonrpc": "2.0", "id": 3, "method": "tools/list"}
        wrapper._handle_client_message(json.dumps(msg))

        wrapper.acp_process.stdin.write.assert_called_once()
        written = wrapper.acp_process.stdin.write.call_args[0][0]
        assert json.loads(written.strip()) == msg

    def test_invalid_json_passed_through(self):
        """Invalid JSON should be written straight to acp_process."""
        wrapper = OpenClawAcpWrapper()
        wrapper.acp_process = MagicMock()
        wrapper.acp_process.stdin = MagicMock()

        wrapper._handle_client_message("bad-json")
        wrapper.acp_process.stdin.write.assert_called_once_with("bad-json\n")


class TestHandleAcpMessage:
    """Tests for _handle_acp_message."""

    def test_handle_acp_message_writes_to_stdout(self):
        """ACP messages should be transformed and written to stdout."""
        wrapper = OpenClawAcpWrapper()
        wrapper.client_protocol_version = "2025-03-26"

        with patch.object(wrapper, "_write_json_line") as mock_write:
            msg = {"jsonrpc": "2.0", "id": 1, "result": {"protocolVersion": 1}}
            wrapper._handle_acp_message(json.dumps(msg))

            mock_write.assert_called_once()
            written = mock_write.call_args[0][1]
            assert written["result"]["protocolVersion"] == "2025-03-26"


class TestShutdown:
    """Tests for shutdown behavior."""

    def test_shutdown_sets_event_and_stops_processes(self):
        """shutdown should set the event and terminate subprocesses."""
        wrapper = OpenClawAcpWrapper()
        wrapper.gateway_process = MagicMock()
        wrapper.gateway_process.poll.return_value = None
        wrapper.acp_process = MagicMock()
        wrapper.acp_process.poll.return_value = None

        wrapper.shutdown()

        assert wrapper._shutdown_event.is_set()
        wrapper.acp_process.terminate.assert_called_once()
        wrapper.gateway_process.terminate.assert_called_once()

    def test_stop_gateway_already_exited(self):
        """stop_gateway should do nothing if process already finished."""
        wrapper = OpenClawAcpWrapper()
        wrapper.gateway_process = MagicMock()
        wrapper.gateway_process.poll.return_value = 0

        wrapper.stop_gateway()
        wrapper.gateway_process.terminate.assert_not_called()

    def test_stop_acp_already_exited(self):
        """stop_acp should do nothing if process already finished."""
        wrapper = OpenClawAcpWrapper()
        wrapper.acp_process = MagicMock()
        wrapper.acp_process.poll.return_value = 0

        wrapper.stop_acp()
        wrapper.acp_process.terminate.assert_not_called()
