"""Tests for the CLI entry point."""

import importlib.util
import sys
import os
from unittest.mock import MagicMock, patch

_project_root = os.path.dirname(os.path.dirname(__file__))

# Pre-load wrapper.py into sys.modules so cli.py's relative import resolves
_wrapper_spec = importlib.util.spec_from_file_location(
    "openclaw_acp.wrapper",
    os.path.join(_project_root, "wrapper.py"),
)
_wrapper_mod = importlib.util.module_from_spec(_wrapper_spec)
sys.modules["openclaw_acp"] = type(sys)("openclaw_acp")
sys.modules["openclaw_acp"].__path__ = [_project_root]
sys.modules["openclaw_acp.wrapper"] = _wrapper_mod
_wrapper_spec.loader.exec_module(_wrapper_mod)

# Now load cli.py
_cli_spec = importlib.util.spec_from_file_location(
    "openclaw_acp.cli",
    os.path.join(_project_root, "cli.py"),
)
cli_module = importlib.util.module_from_spec(_cli_spec)
_cli_spec.loader.exec_module(cli_module)
main = cli_module.main


class TestCli:
    """Tests for cli.main"""

    def test_main_runs_wrapper(self):
        """main should instantiate OpenClawAcpWrapper and call run."""
        with patch.object(cli_module, "OpenClawAcpWrapper") as MockWrapper:
            mock_instance = MagicMock()
            MockWrapper.return_value = mock_instance

            with patch.object(sys, "argv", ["openclaw-acp"]):
                main()

            MockWrapper.assert_called_once_with(openclaw_bin="openclaw")
            mock_instance.run.assert_called_once()

    def test_main_custom_bin(self):
        """main should pass --openclaw-bin to the wrapper."""
        with patch.object(cli_module, "OpenClawAcpWrapper") as MockWrapper:
            mock_instance = MagicMock()
            MockWrapper.return_value = mock_instance

            with patch.object(sys, "argv", ["openclaw-acp", "--openclaw-bin", "/usr/local/bin/openclaw"]):
                main()

            MockWrapper.assert_called_once_with(openclaw_bin="/usr/local/bin/openclaw")

    def test_main_fatal_error_exits_nonzero(self):
        """If run() raises an exception, main should exit with code 1."""
        with patch.object(cli_module, "OpenClawAcpWrapper") as MockWrapper:
            mock_instance = MagicMock()
            mock_instance.run.side_effect = RuntimeError("boom")
            MockWrapper.return_value = mock_instance

            with patch.object(sys, "argv", ["openclaw-acp"]):
                with patch.object(cli_module.sys, "exit") as mock_exit:
                    main()
                    mock_exit.assert_called_once_with(1)
