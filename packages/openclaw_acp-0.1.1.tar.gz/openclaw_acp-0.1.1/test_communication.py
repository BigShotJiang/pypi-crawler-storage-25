#!/usr/bin/env python3
"""Test that openclaw-acp can communicate via stdio."""

import json
import subprocess
import sys
import threading
import time


def send_message(proc, obj: dict):
    payload = json.dumps(obj, separators=(",", ":"), ensure_ascii=False)
    data = f"Content-Length: {len(payload.encode('utf-8'))}\r\n\r\n{payload}"
    proc.stdin.write(data.encode("utf-8"))
    proc.stdin.flush()
    print(f"[SEND] {payload}", file=sys.stderr)


def read_json_lines(proc, timeout: float = 10.0):
    """Read newline-delimited JSON from stdout (wrapper currently uses this format)."""
    start_time = time.time()
    buf = b""
    while time.time() - start_time < timeout:
        if b"\n" in buf:
            line, buf = buf.split(b"\n", 1)
            line_str = line.decode("utf-8", errors="replace").strip()
            if line_str:
                print(f"[RECV] {line_str}", file=sys.stderr)
                try:
                    return json.loads(line_str)
                except json.JSONDecodeError:
                    continue
        try:
            chunk = proc.stdout.read(1)
            if not chunk:
                time.sleep(0.05)
                continue
            buf += chunk
        except Exception:
            time.sleep(0.05)
    raise TimeoutError("Timeout waiting for JSON line")


def main():
    cmd = ["/private/tmp/testwk/.venv/bin/openclaw-acp"]
    print(f"Starting: {' '.join(cmd)}", file=sys.stderr)

    proc = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=False,
        bufsize=0,
    )

    # Drain stderr in background
    def drain_stderr():
        for line in iter(proc.stderr.readline, b""):
            if line:
                print(f"[STDERR] {line.decode('utf-8', errors='replace').rstrip()}", file=sys.stderr)

    stderr_thread = threading.Thread(target=drain_stderr, daemon=True)
    stderr_thread.start()

    try:
        # Send initialize request
        init_request = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2025-03-26",
                "capabilities": {},
                "clientInfo": {"name": "test-client", "version": "0.1.0"},
            },
        }
        send_message(proc, init_request)

        # Wait for initialize response (wrapper sends immediate response)
        response = read_json_lines(proc, timeout=5.0)
        assert response.get("id") == 1, f"Unexpected id: {response}"
        assert "result" in response, f"No result in response: {response}"
        assert response["result"]["serverInfo"]["name"] == "openclaw-acp-wrapper"
        print("✅ Initialize immediate response OK", file=sys.stderr)

        # openclaw acp will also send a response; wait for it
        time.sleep(0.5)
        # Drain any extra acp response
        extra = []
        while True:
            try:
                proc.stdout.read(0)  # check readable
                # Try non-blocking peek
                import select
                ready, _, _ = select.select([proc.stdout.fileno()], [], [], 0.2)
                if not ready:
                    break
                resp = read_json_lines(proc, timeout=1.0)
                extra.append(resp)
            except (TimeoutError, EOFError):
                break

        if extra:
            print(f"✅ Got {len(extra)} additional response(s) from openclaw acp", file=sys.stderr)
            for r in extra:
                print(f"   -> id={r.get('id')}, has_result={'result' in r}, has_error={'error' in r}", file=sys.stderr)

        # Give openclaw acp some time to fully initialize
        time.sleep(2.0)

        # Send tools/list request
        tools_request = {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/list",
            "params": {},
        }
        send_message(proc, tools_request)

        # Wait for response (may need to skip stale initialize responses)
        response2 = None
        start = time.time()
        while time.time() - start < 10.0:
            resp = read_json_lines(proc, timeout=2.0)
            if resp.get("id") == 2:
                response2 = resp
                break
            else:
                print(f"   (skipping stale response id={resp.get('id')})", file=sys.stderr)
        assert response2 is not None, "Did not receive tools/list response within timeout"
        print(f"✅ tools/list response received", file=sys.stderr)
        print(f"   -> result preview: {json.dumps(response2.get('result', response2.get('error')), indent=2)[:500]}", file=sys.stderr)

        print("\n✅ All communication tests passed!", file=sys.stderr)

    except Exception as e:
        print(f"\n❌ Test failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()
        sys.exit(1)
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()


if __name__ == "__main__":
    main()
