#!/usr/bin/env python3
"""Send a test message '1+1' to openclaw-acp and print responses."""

import json
import subprocess
import sys
import threading
import time


def send_json_line(proc, obj: dict):
    """Send newline-delimited JSON (matching wrapper's output format)."""
    payload = json.dumps(obj, separators=(",", ":"), ensure_ascii=False)
    proc.stdin.write((payload + "\n").encode("utf-8"))
    proc.stdin.flush()
    print(f"[SEND] {payload}", file=sys.stderr)


def send_framed(proc, obj: dict):
    """Send Content-Length framed JSON."""
    payload = json.dumps(obj, separators=(",", ":"), ensure_ascii=False)
    data = f"Content-Length: {len(payload.encode('utf-8'))}\r\n\r\n{payload}"
    proc.stdin.write(data.encode("utf-8"))
    proc.stdin.flush()
    print(f"[SEND] {payload}", file=sys.stderr)


def read_responses(proc, duration: float = 15.0):
    """Read newline-delimited JSON responses for a given duration."""
    start = time.time()
    buf = b""
    while time.time() - start < duration:
        try:
            import select
            ready, _, _ = select.select([proc.stdout.fileno()], [], [], 0.5)
            if not ready:
                continue
            chunk = proc.stdout.read(4096)
            if not chunk:
                time.sleep(0.1)
                continue
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                line_str = line.decode("utf-8", errors="replace").strip()
                if line_str:
                    print(f"[RECV] {line_str}", file=sys.stderr)
                    try:
                        yield json.loads(line_str)
                    except json.JSONDecodeError:
                        pass
        except Exception as e:
            print(f"[READ ERR] {e}", file=sys.stderr)
            break


def main():
    cmd = ["/private/tmp/testwk/.venv/bin/openclaw-acp"]
    print(f"Starting: {' '.join(cmd)}", file=sys.stderr)

    proc = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=False,
        bufsize=0,
    )

    # Drain stderr
    def drain_stderr():
        for line in iter(proc.stderr.readline, b""):
            if line:
                print(f"[STDERR] {line.decode('utf-8', errors='replace').rstrip()}", file=sys.stderr)

    threading.Thread(target=drain_stderr, daemon=True).start()

    try:
        # 1. Initialize
        init_request = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2025-03-26",
                "capabilities": {},
                "clientInfo": {"name": "test-client", "version": "0.1.0"},
            },
        }
        send_framed(proc, init_request)

        # Collect initialize responses
        for resp in read_responses(proc, duration=3.0):
            if resp.get("id") == 1:
                print(f"\n✅ Initialize response:\n{json.dumps(resp, indent=2, ensure_ascii=False)}\n")
                break

        # 2. Send "1+1" as a prompt/get request
        print("=" * 50)
        print("Sending prompt/get with message '1+1'...")
        print("=" * 50)
        prompt_request = {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "prompts/get",
            "params": {
                "name": "default",
                "arguments": {"message": "1+1"},
            },
        }
        send_framed(proc, prompt_request)

        for resp in read_responses(proc, duration=5.0):
            print(f"\n📨 Response for id={resp.get('id')}:\n{json.dumps(resp, indent=2, ensure_ascii=False)}\n")

        # 3. Try agents/run or message if prompts/get failed
        print("=" * 50)
        print("Trying agents/run with input '1+1'...")
        print("=" * 50)
        agent_request = {
            "jsonrpc": "2.0",
            "id": 3,
            "method": "agents/run",
            "params": {
                "input": "1+1",
            },
        }
        send_framed(proc, agent_request)

        for resp in read_responses(proc, duration=5.0):
            print(f"\n📨 Response for id={resp.get('id')}:\n{json.dumps(resp, indent=2, ensure_ascii=False)}\n")

        # 4. Try tools/call with evaluate/calculate
        print("=" * 50)
        print("Trying tools/call with '1+1'...")
        print("=" * 50)
        tool_request = {
            "jsonrpc": "2.0",
            "id": 4,
            "method": "tools/call",
            "params": {
                "name": "evaluate",
                "arguments": {"expression": "1+1"},
            },
        }
        send_framed(proc, tool_request)

        for resp in read_responses(proc, duration=5.0):
            print(f"\n📨 Response for id={resp.get('id')}:\n{json.dumps(resp, indent=2, ensure_ascii=False)}\n")

    except Exception as e:
        print(f"\n❌ Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()


if __name__ == "__main__":
    main()
