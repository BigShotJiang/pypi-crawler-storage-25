"""CLI entry point for the OpenClaw ACP stdio wrapper."""

import argparse
import sys

from .wrapper import OpenClawAcpWrapper


def main():
    parser = argparse.ArgumentParser(
        description="Wrap openclaw acp into a standard stdio ACP server."
    )
    parser.add_argument(
        "--openclaw-bin",
        default="openclaw",
        help="Path to the openclaw executable (default: openclaw)",
    )
    parser.add_argument(
        "command",
        nargs="?",
        default=None,
        help="Optional command (e.g. 'acp') - ignored",
    )
    args = parser.parse_args()

    wrapper = OpenClawAcpWrapper(openclaw_bin=args.openclaw_bin)
    try:
        wrapper.run()
    except Exception as exc:
        wrapper.log("Fatal error:", exc)
        sys.exit(1)


if __name__ == "__main__":
    main()
