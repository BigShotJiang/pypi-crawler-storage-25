#!/usr/bin/env python3
import json, subprocess, sys, threading, time

proc = subprocess.Popen(
    ["/private/tmp/testwk/.venv/bin/openclaw-acp"],
    stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    text=False, bufsize=0,
)

def drain_stderr():
    for line in iter(proc.stderr.readline, b""):
        if line:
            print(f"[STDERR] {line.decode('utf-8',errors='replace').rstrip()}", file=sys.stderr)
threading.Thread(target=drain_stderr, daemon=True).start()

# Try sending raw text lines after initialize to see if acp accepts plain text
init = {"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{"tools":{},"prompts":{},"resources":{}},"clientInfo":{"name":"test","version":"0.1"}}}
proc.stdin.write(f"Content-Length: {len(json.dumps(init).encode())}\r\n\r\n{json.dumps(init)}".encode())
proc.stdin.flush()

# Read init response
t0 = time.time()
buf = b""
while time.time() - t0 < 5:
    import select
    r, _, _ = select.select([proc.stdout.fileno()], [], [], 0.5)
    if r:
        chunk = proc.stdout.read(4096)
        if chunk:
            buf += chunk
            if b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                print(f"[INIT] {line.decode('utf-8',errors='replace')}")
                break

# Now try various raw message formats
print("\n--- Sending raw text '1+1' ---", file=sys.stderr)
proc.stdin.write(b"1+1\n")
proc.stdin.flush()

# Wait for any response
t0 = time.time()
while time.time() - t0 < 5:
    import select
    r, _, _ = select.select([proc.stdout.fileno()], [], [], 0.5)
    if r:
        chunk = proc.stdout.read(4096)
        if chunk:
            print(f"[RAW RESP] {chunk.decode('utf-8',errors='replace')}")
    else:
        break

# Try JSON-RPC prompt
print("\n--- Sending prompts/get ---", file=sys.stderr)
p = {"jsonrpc":"2.0","id":2,"method":"prompts/get","params":{"name":"default","arguments":{"message":"1+1"}}}
proc.stdin.write(f"Content-Length: {len(json.dumps(p).encode())}\r\n\r\n{json.dumps(p)}".encode())
proc.stdin.flush()

t0 = time.time()
while time.time() - t0 < 5:
    import select
    r, _, _ = select.select([proc.stdout.fileno()], [], [], 0.5)
    if r:
        chunk = proc.stdout.read(4096)
        if chunk:
            print(f"[PROMPT RESP] {chunk.decode('utf-8',errors='replace')}")
    else:
        break

proc.terminate()
try:
    proc.wait(timeout=3)
except:
    proc.kill()
