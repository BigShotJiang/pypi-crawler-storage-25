#!/usr/bin/env python3
"""Talk directly to openclaw acp without wrapper."""
import json, subprocess, sys, threading, time, select

proc = subprocess.Popen(
    ["openclaw", "acp"],
    stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    text=False, bufsize=0,
)

def drain_stderr():
    for line in iter(proc.stderr.readline, b""):
        if line:
            print(f"[ACP STDERR] {line.decode('utf-8',errors='replace').rstrip()}", file=sys.stderr)
threading.Thread(target=drain_stderr, daemon=True).start()

# Send initialize
init = {"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"test","version":"0.1"}}}
proc.stdin.write(f"Content-Length: {len(json.dumps(init).encode())}\r\n\r\n{json.dumps(init)}".encode())
proc.stdin.flush()

# Read responses for 5s
buf = b""
t0 = time.time()
while time.time() - t0 < 5:
    r, _, _ = select.select([proc.stdout.fileno()], [], [], 0.3)
    if r:
        chunk = proc.stdout.read(4096)
        if chunk:
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                print(f"[ACP RESP] {line.decode('utf-8',errors='replace')}")
    else:
        break

# Try prompts/list
print("\n--- prompts/list ---", file=sys.stderr)
p = {"jsonrpc":"2.0","id":2,"method":"prompts/list","params":{}}
proc.stdin.write(f"Content-Length: {len(json.dumps(p).encode())}\r\n\r\n{json.dumps(p)}".encode())
proc.stdin.flush()

t0 = time.time()
while time.time() - t0 < 5:
    r, _, _ = select.select([proc.stdout.fileno()], [], [], 0.3)
    if r:
        chunk = proc.stdout.read(4096)
        if chunk:
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                print(f"[ACP RESP] {line.decode('utf-8',errors='replace')}")
    else:
        break

# Try sending raw prompt message
print("\n--- agent/message ---", file=sys.stderr)
p = {"jsonrpc":"2.0","id":3,"method":"agent/message","params":{"content":"1+1"}}
proc.stdin.write(f"Content-Length: {len(json.dumps(p).encode())}\r\n\r\n{json.dumps(p)}".encode())
proc.stdin.flush()

t0 = time.time()
while time.time() - t0 < 5:
    r, _, _ = select.select([proc.stdout.fileno()], [], [], 0.3)
    if r:
        chunk = proc.stdout.read(4096)
        if chunk:
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                print(f"[ACP RESP] {line.decode('utf-8',errors='replace')}")
    else:
        break

proc.terminate()
try:
    proc.wait(timeout=3)
except:
    proc.kill()
