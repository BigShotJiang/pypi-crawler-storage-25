"""OpenClaw ACP Stdio Wrapper."""

__version__ = "0.1.1"
