#!/usr/bin/env python3
"""Test that openclaw-acp can reply to messages via agent fallback."""

import json
import subprocess
import sys
import threading
import time
import select


def send_framed(proc, obj: dict):
    payload = json.dumps(obj, separators=(",", ":"), ensure_ascii=False)
    data = f"Content-Length: {len(payload.encode('utf-8'))}\r\n\r\n{payload}"
    proc.stdin.write(data.encode("utf-8"))
    proc.stdin.flush()
    print(f"[SEND] {payload}", file=sys.stderr)


def read_json_lines(proc, duration: float = 15.0):
    start = time.time()
    buf = b""
    while time.time() - start < duration:
        try:
            ready, _, _ = select.select([proc.stdout.fileno()], [], [], 0.5)
            if not ready:
                continue
            chunk = proc.stdout.read(4096)
            if not chunk:
                time.sleep(0.1)
                continue
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                line_str = line.decode("utf-8", errors="replace").strip()
                if line_str:
                    print(f"[RECV] {line_str}", file=sys.stderr)
                    try:
                        yield json.loads(line_str)
                    except json.JSONDecodeError:
                        pass
        except Exception as e:
            print(f"[READ ERR] {e}", file=sys.stderr)
            break


def wait_for_id(proc, target_id, duration=15.0):
    for resp in read_json_lines(proc, duration=duration):
        if resp.get("id") == target_id:
            return resp
    return None


def main():
    cmd = ["/private/tmp/testwk/.venv/bin/openclaw-acp"]
    print(f"Starting: {' '.join(cmd)}", file=sys.stderr)

    proc = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=False,
        bufsize=0,
    )

    def drain_stderr():
        for line in iter(proc.stderr.readline, b""):
            if line:
                print(f"[STDERR] {line.decode('utf-8',errors='replace').rstrip()}", file=sys.stderr)

    threading.Thread(target=drain_stderr, daemon=True).start()

    try:
        # 1. Initialize
        init_request = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2025-03-26",
                "capabilities": {},
                "clientInfo": {"name": "test-client", "version": "0.1.0"},
            },
        }
        send_framed(proc, init_request)
        resp = wait_for_id(proc, 1, duration=5.0)
        assert resp and "result" in resp
        print(f"\n✅ Initialize OK: {resp['result']['serverInfo']['name']}\n")

        # 2. Send "1+1" via tools/call
        print("=" * 50)
        print("Sending tools/call with expression '1+1'...")
        print("=" * 50)
        tool_request = {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/call",
            "params": {
                "name": "evaluate",
                "arguments": {"expression": "1+1"},
            },
        }
        send_framed(proc, tool_request)
        resp2 = wait_for_id(proc, 2, duration=60.0)
        assert resp2 is not None, "Timeout waiting for tools/call response"
        print(f"\n📨 tools/call response:\n{json.dumps(resp2, indent=2, ensure_ascii=False)}\n")

        # 3. Send "hello" via prompts/get
        print("=" * 50)
        print("Sending prompts/get with message 'hello'...")
        print("=" * 50)
        prompt_request = {
            "jsonrpc": "2.0",
            "id": 3,
            "method": "prompts/get",
            "params": {
                "name": "default",
                "arguments": {"message": "hello"},
            },
        }
        send_framed(proc, prompt_request)
        resp3 = wait_for_id(proc, 3, duration=60.0)
        assert resp3 is not None, "Timeout waiting for prompts/get response"
        print(f"\n📨 prompts/get response:\n{json.dumps(resp3, indent=2, ensure_ascii=False)}\n")

        print("\n✅ All communication tests passed!", file=sys.stderr)

    except Exception as e:
        print(f"\n❌ Test failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()
        sys.exit(1)
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()


if __name__ == "__main__":
    main()
