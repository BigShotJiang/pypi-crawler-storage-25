#!/usr/bin/env python3
import json, subprocess, sys, threading, time

def send(proc, obj):
    payload = json.dumps(obj, separators=(",", ":"), ensure_ascii=False)
    data = f"Content-Length: {len(payload.encode('utf-8'))}\r\n\r\n{payload}"
    proc.stdin.write(data.encode("utf-8"))
    proc.stdin.flush()
    print(f"[SEND] {payload}", file=sys.stderr)

def read_all(proc, duration=8.0):
    start = time.time()
    buf = b""
    while time.time() - start < duration:
        try:
            import select
            ready, _, _ = select.select([proc.stdout.fileno()], [], [], 0.3)
            if not ready:
                continue
            chunk = proc.stdout.read(4096)
            if not chunk:
                continue
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                line_str = line.decode("utf-8", errors="replace").strip()
                if line_str:
                    print(f"[RECV] {line_str}", file=sys.stderr)
                    try:
                        yield json.loads(line_str)
                    except json.JSONDecodeError:
                        pass
        except Exception:
            break

proc = subprocess.Popen(
    ["/private/tmp/testwk/.venv/bin/openclaw-acp"],
    stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    text=False, bufsize=0,
)
threading.Thread(target=lambda: [
    print(f"[STDERR] {l.decode('utf-8',errors='replace').rstrip()}", file=sys.stderr)
    for l in iter(proc.stderr.readline, b"") if l
], daemon=True).start()

# Initialize
send(proc, {"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"test","version":"0.1"}}})
for r in read_all(proc, 3.0):
    if r.get("id") == 1 and "result" in r:
        print(f"\n✅ Initialized: {r['result']['serverInfo']['name']}\n")
        break

# Try various methods to send "1+1"
methods_to_try = [
    ("sessions/list", {}),
    ("sessions/create", {"input": "1+1"}),
    ("messages/send", {"content": "1+1"}),
    ("chat", {"message": "1+1"}),
    ("completion", {"prompt": "1+1"}),
    ("agent/run", {"input": "1+1"}),
    ("agent/message", {"message": "1+1"}),
]

for i, (method, params) in enumerate(methods_to_try, start=10):
    print(f"\n--- Trying {method} ---", file=sys.stderr)
    send(proc, {"jsonrpc":"2.0","id":i,"method":method,"params":params})
    found = False
    for r in read_all(proc, 2.0):
        if r.get("id") == i:
            found = True
            if "error" in r:
                print(f"❌ {method}: {r['error']['message']}")
            else:
                print(f"✅ {method} response:\n{json.dumps(r, indent=2, ensure_ascii=False)}")
            break
    if not found:
        print(f"⏱️ {method}: no response")

proc.terminate()
try:
    proc.wait(timeout=3)
except subprocess.TimeoutExpired:
    proc.kill()
