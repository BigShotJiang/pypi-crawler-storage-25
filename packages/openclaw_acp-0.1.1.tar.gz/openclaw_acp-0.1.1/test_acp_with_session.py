#!/usr/bin/env python3
import json, subprocess, sys, threading, time, select

proc = subprocess.Popen(
    ["openclaw", "acp", "--session", "agent:main:main"],
    stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    text=False, bufsize=0,
)

def drain_stderr():
    for line in iter(proc.stderr.readline, b""):
        if line:
            print(f"[ACP STDERR] {line.decode('utf-8',errors='replace').rstrip()}", file=sys.stderr)
threading.Thread(target=drain_stderr, daemon=True).start()

methods = [
    ("initialize", {"protocolVersion":1,"capabilities":{},"clientInfo":{"name":"test","version":"0.1"}}),
    ("tools/list", {}),
    ("prompts/list", {}),
    ("prompts/get", {"name":"default","arguments":{"message":"1+1"}}),
    ("agent/message", {"content":"1+1"}),
]

for i, (method, params) in enumerate(methods, start=1):
    msg = {"jsonrpc":"2.0","id":i,"method":method,"params":params}
    line = json.dumps(msg, separators=(",",":"), ensure_ascii=False) + "\n"
    proc.stdin.write(line.encode("utf-8"))
    proc.stdin.flush()
    print(f"[SEND] {line.strip()}", file=sys.stderr)
    
    buf = b""
    t0 = time.time()
    while time.time() - t0 < 3:
        r, _, _ = select.select([proc.stdout.fileno()], [], [], 0.3)
        if r:
            chunk = proc.stdout.read(4096)
            if chunk:
                buf += chunk
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    line_str = line.decode('utf-8',errors='replace')
                    if line_str.strip():
                        print(f"[RECV] {line_str}")
        else:
            break

proc.terminate()
try:
    proc.wait(timeout=3)
except:
    proc.kill()
