#!/usr/bin/env python3
"""Simulate clawdboz sending session/prompt to openclaw-acp."""

import json
import subprocess
import sys
import threading
import time
import select


def read_json_lines(proc, duration: float = 120.0):
    start = time.time()
    buf = b""
    while time.time() - start < duration:
        try:
            ready, _, _ = select.select([proc.stdout.fileno()], [], [], 0.5)
            if not ready:
                continue
            chunk = proc.stdout.read(4096)
            if not chunk:
                time.sleep(0.1)
                continue
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                line_str = line.decode("utf-8", errors="replace").strip()
                if line_str:
                    print(f"[RECV] {line_str[:200]}")
                    try:
                        yield json.loads(line_str)
                    except json.JSONDecodeError:
                        pass
        except Exception as e:
            print(f"[READ ERR] {e}")
            break


def main():
    cmd = ["/private/tmp/testwk/.venv/bin/openclaw-acp"]
    print(f"Starting: {' '.join(cmd)}")

    proc = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=False,
        bufsize=0,
    )

    def drain_stderr():
        for line in iter(proc.stderr.readline, b""):
            if line:
                print(f"[STDERR] {line.decode('utf-8',errors='replace').rstrip()}")

    threading.Thread(target=drain_stderr, daemon=True).start()

    # Send initialize
    init = {
        "jsonrpc": "2.0",
        "id": "init-1",
        "method": "initialize",
        "params": {
            "protocolVersion": 1,
            "capabilities": {},
            "clientInfo": {"name": "clawdboz", "version": "2.2.0"},
        },
    }
    proc.stdin.write((json.dumps(init) + "\n").encode("utf-8"))
    proc.stdin.flush()
    print(f"[SEND] initialize")

    for resp in read_json_lines(proc, duration=5.0):
        if resp.get("id") == "init-1":
            print(f"\n✅ Initialize OK\n")
            break

    # Directly send session/prompt with a fake sessionId (like clawdboz does)
    session_id = "test-session-1234"
    prompt = {
        "jsonrpc": "2.0",
        "id": "prompt-1",
        "method": "session/prompt",
        "params": {
            "sessionId": session_id,
            "prompt": [{"type": "text", "text": "1+1"}],
        },
    }
    proc.stdin.write((json.dumps(prompt) + "\n").encode("utf-8"))
    proc.stdin.flush()
    print(f"[SEND] session/prompt: 1+1")

    chunks = []
    result_resp = None
    for resp in read_json_lines(proc, duration=60.0):
        method = resp.get("method")
        if method == "session/update":
            update = resp.get("params", {}).get("update", {})
            update_type = update.get("sessionUpdate")
            if update_type == "agent_message_chunk":
                text = update.get("content", {}).get("text", "")
                chunks.append(text)
                print(f"  [CHUNK] {text[:100]}")
            elif update_type == "thinking":
                text = update.get("content", {}).get("text", "")
                print(f"  [THINKING] {text[:100]}")
            else:
                print(f"  [UPDATE] {update_type}")
        elif resp.get("id") == "prompt-1":
            result_resp = resp
            print(f"\n✅ Got response for prompt-1: {json.dumps(resp, indent=2)[:300]}")
            break

    print(f"\n{'='*50}")
    print(f"Total chunks: {len(chunks)}")
    print(f"Full text: {''.join(chunks)}")
    print(f"Result: {result_resp}")
    print(f"{'='*50}")

    proc.terminate()
    try:
        proc.wait(timeout=3)
    except subprocess.TimeoutExpired:
        proc.kill()


if __name__ == "__main__":
    main()
