"""OpenClaw ACP stdio wrapper core logic."""

import json
import os
import select
import shutil
import socket
import subprocess
import sys
import threading
import time

# Force line buffering on stdout/stderr so parent readline() sees output immediately
for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, "reconfigure"):
        try:
            _stream.reconfigure(line_buffering=True)
        except Exception:
            pass


class OpenClawAcpWrapper:
    """Wraps `openclaw acp` into a standard stdio ACP server."""

    GATEWAY_PORT = 18789
    GATEWAY_HOST = "127.0.0.1"

    def __init__(self, openclaw_bin: str = "openclaw"):
        self.openclaw_bin = openclaw_bin
        self.gateway_process: subprocess.Popen | None = None
        self.acp_process: subprocess.Popen | None = None
        self.client_protocol_version = None
        self.initialized = False
        self._shutdown_event = threading.Event()
        self._default_session_id = None

    def log(self, *args):
        msg = " ".join(str(a) for a in args)
        sys.stderr.write(f"[openclaw-acp-wrapper] {msg}\n")
        sys.stderr.flush()
        # Also log to file for debugging
        try:
            with open("/tmp/openclaw_acp_debug.log", "a") as f:
                f.write(f"{msg}\n")
        except Exception:
            pass

    def _is_gateway_ready(self) -> bool:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.5)
            sock.connect((self.GATEWAY_HOST, self.GATEWAY_PORT))
            sock.close()
            return True
        except OSError:
            return False

    def _get_openclaw_bin(self) -> str:
        """Resolve openclaw binary path, ensuring it can find node."""
        if shutil.which(self.openclaw_bin):
            return self.openclaw_bin
        # Common fallback paths
        for path in ["/opt/homebrew/bin/openclaw", "/usr/local/bin/openclaw"]:
            if os.path.isfile(path):
                return path
        return self.openclaw_bin

    def _get_env(self) -> dict:
        """Return environment with common bin directories in PATH."""
        env = os.environ.copy()
        extra_paths = ["/opt/homebrew/bin", "/usr/local/bin"]
        existing = env.get("PATH", "").split(os.pathsep)
        new_paths = [p for p in extra_paths if p not in existing and os.path.isdir(p)]
        if new_paths:
            env["PATH"] = os.pathsep.join(new_paths + existing)
        return env

    def start_gateway(self):
        if self._is_gateway_ready():
            self.log("Gateway already running on", f"{self.GATEWAY_HOST}:{self.GATEWAY_PORT}")
            return

        self.log("Starting openclaw gateway...")
        env = self._get_env()
        openclaw_bin = self._get_openclaw_bin()
        self.gateway_process = subprocess.Popen(
            [openclaw_bin, "gateway", "run", "--bind", "loopback", "--auth", "none", "--force"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
        )

        # Wait for port to open (max 30s)
        for i in range(60):
            if self._is_gateway_ready():
                self.log("Gateway ready")
                return
            if self.gateway_process.poll() is not None:
                raise RuntimeError(
                    f"Gateway exited with code {self.gateway_process.returncode}"
                )
            time.sleep(0.5)
        raise RuntimeError("Gateway failed to start within 30s")

    def stop_gateway(self):
        if self.gateway_process and self.gateway_process.poll() is None:
            self.gateway_process.terminate()
            try:
                self.gateway_process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.gateway_process.kill()
                self.gateway_process.wait(timeout=1)

    def start_acp(self):
        self.log("Starting openclaw acp bridge...")
        env = self._get_env()
        openclaw_bin = self._get_openclaw_bin()
        self.acp_process = subprocess.Popen(
            [openclaw_bin, "acp"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            text=True,
            bufsize=1,
        )

        def _watch_acp():
            self.acp_process.wait()
            self.log("openclaw acp exited with code", self.acp_process.returncode)
            self.shutdown()

        threading.Thread(target=_watch_acp, daemon=True).start()

        # Drain stderr to prevent pipe deadlock
        def _drain_acp_stderr():
            for _line in iter(self.acp_process.stderr.readline, ""):
                pass
            self.acp_process.stderr.close()

        threading.Thread(target=_drain_acp_stderr, daemon=True).start()

    def stop_acp(self):
        if self.acp_process and self.acp_process.poll() is None:
            self.acp_process.terminate()
            try:
                self.acp_process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.acp_process.kill()
                self.acp_process.wait(timeout=1)

    def shutdown(self):
        self._shutdown_event.set()
        self.stop_acp()
        self.stop_gateway()

    # ------------------------------------------------------------------
    # Agent fallback for messages openclaw acp does not handle
    # ------------------------------------------------------------------

    def _get_default_session_id(self):
        """Allocate a fresh openclaw session id on every wrapper start."""
        if self._default_session_id:
            return self._default_session_id
        # Allow explicit override via environment
        env_session = os.environ.get("OPENCLAW_SESSION_ID")
        if env_session:
            self._default_session_id = env_session
            self.log("Using session from OPENCLAW_SESSION_ID:", env_session)
            return env_session
        import uuid
        self._default_session_id = str(uuid.uuid4())
        self.log("Allocated new session:", self._default_session_id)
        return self._default_session_id

    @staticmethod
    def _extract_user_message(msg: dict):
        """Try to extract a user-facing message string from an ACP request."""
        params = msg.get("params", {})
        # Direct params keys
        for key in ("message", "input", "prompt", "content", "text", "query"):
            val = params.get(key)
            if isinstance(val, str) and val.strip():
                return val.strip()
        # Nested arguments (tools/call style)
        args = params.get("arguments", {})
        for key in ("message", "input", "prompt", "content", "text", "query", "expression"):
            val = args.get(key)
            if isinstance(val, str) and val.strip():
                return val.strip()
        # prompts/get style
        if isinstance(args, dict):
            for val in args.values():
                if isinstance(val, str) and val.strip():
                    return val.strip()
        # session/prompt style: prompt is a list of content blocks
        prompt_blocks = params.get("prompt", [])
        if isinstance(prompt_blocks, list):
            for block in prompt_blocks:
                if isinstance(block, dict) and block.get("type") == "text":
                    text = block.get("text", "")
                    if isinstance(text, str) and text.strip():
                        return text.strip()
        return None

    def _run_agent(self, message: str) -> dict:
        """Run openclaw agent CLI and return an ACP-compatible result dict."""
        session_id = self._get_default_session_id()
        if not session_id:
            return {"error": "No openclaw session available."}
        self.log("[AGENT] Running openclaw agent for message:", message[:60])
        try:
            result = subprocess.run(
                [self._get_openclaw_bin(), "agent", "--session-id", session_id, "-m", message, "--json"],
                capture_output=True, text=True, timeout=120,
                env=self._get_env(),
            )
            if result.returncode != 0:
                err = result.stderr.strip() or "openclaw agent failed"
                return {"error": err}
            data = json.loads(result.stdout)
            # openclaw may resolve the temp id to its own session id — cache it
            actual_session = data.get("result", {}).get("meta", {}).get("agentMeta", {}).get("sessionId")
            if actual_session and actual_session != session_id:
                self._default_session_id = actual_session
                self.log("Session resolved to:", actual_session)
            payloads = data.get("result", {}).get("payloads", [])
            texts = [p["text"] for p in payloads if p.get("text")]
            return {
                "content": [{"type": "text", "text": "\n".join(texts)}],
                "isError": False,
            }
        except Exception as exc:
            return {"error": str(exc)}

    # ------------------------------------------------------------------
    # Message framing helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _write_message(stream, obj: dict):
        payload = json.dumps(obj, separators=(",", ":"), ensure_ascii=False)
        if hasattr(stream, "mode") and "b" in stream.mode:
            body = payload.encode("utf-8")
            header = f"Content-Length: {len(body)}\r\n\r\n".encode("utf-8")
            stream.write(header + body)
        else:
            # text stream (e.g. sys.stdout with text=True)
            header = f"Content-Length: {len(payload.encode('utf-8'))}\r\n\r\n"
            stream.write(header + payload)
        stream.flush()

    def _write_json_line(self, stream, obj: dict):
        """Write a newline-delimited JSON object (for clawdboz compatibility)."""
        payload = json.dumps(obj, separators=(",", ":"), ensure_ascii=False)
        self.log("[WRITE_JSON_LINE]", payload[:200])
        stream.write(payload + "\n")
        stream.flush()

    @staticmethod
    def _read_messages(stream, callback):
        """Read Content-Length framed JSON-RPC messages from a stream."""
        # Detect whether stream is text or binary
        sample = stream.read(0)
        is_text = isinstance(sample, str)
        if is_text:
            buf = ""
            crlf = "\r\n\r\n"
            lf = "\n"
        else:
            buf = b""
            crlf = b"\r\n\r\n"
            lf = b"\n"
        expected_len = None
        def _process_buf(eof=False):
            nonlocal buf, expected_len
            while True:
                if expected_len is None:
                    header_end = buf.find(crlf)
                    if header_end != -1:
                        header = buf[:header_end]
                        if not is_text:
                            header = header.decode("utf-8", errors="replace")
                        match = __import__("re").search(r"Content-Length:\s*(\d+)", header, __import__("re").IGNORECASE)
                        if not match:
                            # fallback: newline-delimited JSON
                            nl = buf.find(lf)
                            if nl == -1:
                                break
                            line = buf[:nl]
                            if not is_text:
                                line = line.decode("utf-8", errors="replace")
                            line = line.strip()
                            buf = buf[nl + 1 :]
                            if line:
                                callback(line)
                            continue
                        expected_len = int(match.group(1))
                        buf = buf[header_end + 4 :]
                    else:
                        # No Content-Length header found; try newline-delimited JSON
                        nl = buf.find(lf)
                        if nl == -1:
                            if eof and buf.strip():
                                line = buf.strip()
                                if not is_text:
                                    line = line.decode("utf-8", errors="replace")
                                callback(line)
                                buf = type(buf)()
                            break
                        line = buf[:nl]
                        if not is_text:
                            line = line.decode("utf-8", errors="replace")
                        line = line.strip()
                        buf = buf[nl + 1 :]
                        if line:
                            callback(line)
                        continue

                if len(buf) < expected_len:
                    break
                body = buf[:expected_len]
                if not is_text:
                    body = body.decode("utf-8", errors="replace")
                buf = buf[expected_len:]
                expected_len = None
                callback(body)

        while True:
            try:
                chunk = stream.read(4096)
                if not chunk:
                    _process_buf(eof=True)
                    break
            except (OSError, ValueError):
                _process_buf(eof=True)
                break
            buf += chunk
            _process_buf()

    # ------------------------------------------------------------------
    # Protocol translation
    # ------------------------------------------------------------------

    def _transform_client_to_acp(self, text: str) -> str:
        try:
            msg = json.loads(text)
        except json.JSONDecodeError:
            return text

        if msg.get("method") == "initialize" and msg.get("params"):
            self.client_protocol_version = msg["params"].get("protocolVersion")
            msg["params"] = {**msg["params"], "protocolVersion": 1}
        return json.dumps(msg, separators=(",", ":"), ensure_ascii=False)

    def _transform_acp_to_client(self, text: str) -> str:
        try:
            msg = json.loads(text)
        except json.JSONDecodeError:
            return text

        if (
            msg.get("result")
            and "protocolVersion" in msg["result"]
            and self.client_protocol_version is not None
        ):
            msg["result"] = {
                **msg["result"],
                "protocolVersion": self.client_protocol_version,
            }
        return json.dumps(msg, separators=(",", ":"), ensure_ascii=False)

    # ------------------------------------------------------------------
    # Main bridge
    # ------------------------------------------------------------------

    def run(self):
        self.start_gateway()
        self.start_acp()

        # Thread: client stdin -> acp stdin (newline-delimited JSON from clawdboz)
        # We use os.read on the raw fd because TextIOWrapper.readline/read in a
        # daemon thread can deadlock/stall on macOS until EOF.
        def _client_reader():
            fd = sys.stdin.buffer.raw.fileno()
            buf = b""
            expected_len = None
            crlf = b"\r\n\r\n"
            lf = b"\n"

            def _process_buf(eof=False):
                nonlocal buf, expected_len
                while True:
                    if expected_len is None:
                        header_end = buf.find(crlf)
                        if header_end != -1:
                            header = buf[:header_end].decode("utf-8", errors="replace")
                            match = __import__("re").search(r"Content-Length:\s*(\d+)", header, __import__("re").IGNORECASE)
                            if not match:
                                nl = buf.find(lf)
                                if nl == -1:
                                    break
                                line = buf[:nl].decode("utf-8", errors="replace").strip()
                                buf = buf[nl + 1 :]
                                if line:
                                    self._handle_client_message(line)
                                continue
                            expected_len = int(match.group(1))
                            buf = buf[header_end + 4 :]
                        else:
                            nl = buf.find(lf)
                            if nl == -1:
                                if eof and buf.strip():
                                    line = buf.strip().decode("utf-8", errors="replace")
                                    self._handle_client_message(line)
                                    buf = b""
                                break
                            line = buf[:nl].decode("utf-8", errors="replace").strip()
                            buf = buf[nl + 1 :]
                            if line:
                                self._handle_client_message(line)
                            continue

                    if len(buf) < expected_len:
                        break
                    body = buf[:expected_len].decode("utf-8", errors="replace")
                    buf = buf[expected_len:]
                    expected_len = None
                    self._handle_client_message(body)

            while True:
                try:
                    chunk = os.read(fd, 4096)
                    if not chunk:
                        _process_buf(eof=True)
                        break
                except OSError:
                    _process_buf(eof=True)
                    break
                buf += chunk
                _process_buf()
            self.shutdown()

        # Thread: acp stdout -> client stdout (newline-delimited JSON to clawdboz)
        def _acp_reader():
            for line in iter(self.acp_process.stdout.readline, ""):
                line = line.strip()
                if line:
                    self._handle_acp_message(line)
            self.shutdown()

        threading.Thread(target=_client_reader, daemon=True).start()
        threading.Thread(target=_acp_reader, daemon=True).start()

        # Block until shutdown
        try:
            while not self._shutdown_event.is_set():
                time.sleep(0.1)
        except KeyboardInterrupt:
            pass
        finally:
            self.shutdown()

    def _handle_client_message(self, text: str):
        try:
            msg = json.loads(text)
        except json.JSONDecodeError:
            # Pass through invalid JSON as newline-delimited
            self.acp_process.stdin.write(text + "\n")
            self.acp_process.stdin.flush()
            return

        self.log("[HANDLE_CLIENT] method=", msg.get("method"), "id=", msg.get("id"))
        if msg.get("method") == "initialize" and not self.initialized:
            # Immediately respond so the IDE doesn't timeout
            response = {
                "jsonrpc": "2.0",
                "id": msg.get("id"),
                "result": {
                    "protocolVersion": msg.get("params", {}).get("protocolVersion", "2025-03-26"),
                    "capabilities": {
                        "tools": {},
                        "prompts": {},
                        "resources": {},
                    },
                    "serverInfo": {
                        "name": "openclaw-acp-wrapper",
                        "version": "0.1.1",
                    },
                },
            }
            self._write_json_line(sys.stdout, response)
            self.initialized = True

            # Also forward modified initialize to openclaw acp as newline-delimited JSON
            forward = self._transform_client_to_acp(text)
            self.acp_process.stdin.write(forward + "\n")
            self.acp_process.stdin.flush()
            return

        # Fallback: if the request carries a user message, run openclaw agent directly
        user_msg = self._extract_user_message(msg)
        if user_msg and msg.get("id") is not None:
            # For session/prompt, send a thinking notification first to keep the client watchdog alive
            session_id = msg.get("params", {}).get("sessionId", "")
            if msg.get("method") == "session/prompt" and session_id:
                self._write_json_line(sys.stdout, {
                    "jsonrpc": "2.0",
                    "method": "session/update",
                    "params": {
                        "sessionId": session_id,
                        "update": {
                            "sessionUpdate": "thinking",
                            "content": {"type": "text", "text": "Processing..."}
                        }
                    }
                })

            agent_result = self._run_agent(user_msg)
            if "error" not in agent_result:
                text = agent_result["content"][0]["text"] if agent_result.get("content") else ""

                # For session/prompt, emit message chunks and a completion notification
                if msg.get("method") == "session/prompt" and session_id:
                    self._write_json_line(sys.stdout, {
                        "jsonrpc": "2.0",
                        "method": "session/update",
                        "params": {
                            "sessionId": session_id,
                            "update": {
                                "sessionUpdate": "agent_message_chunk",
                                "content": {"type": "text", "text": text}
                            }
                        }
                    })
                    response = {
                        "jsonrpc": "2.0",
                        "id": msg["id"],
                        "result": {"stopReason": "completed"},
                    }
                else:
                    response = {
                        "jsonrpc": "2.0",
                        "id": msg["id"],
                        "result": agent_result,
                    }
                self._write_json_line(sys.stdout, response)
                return
            else:
                self.log("[AGENT FALLBACK FAILED]", agent_result["error"])

        transformed = self._transform_client_to_acp(text)
        self.acp_process.stdin.write(transformed + "\n")
        self.acp_process.stdin.flush()

    def _handle_acp_message(self, text: str):
        self.log("[HANDLE_ACP]", text[:200])
        transformed = self._transform_acp_to_client(text)
        self._write_json_line(sys.stdout, json.loads(transformed))
