#!/usr/bin/env python3
"""Karon Web Unblocker — MCP server."""
from mcp.server.fastmcp import FastMCP
import httpx
import os
import json
import asyncio
import logging
import ipaddress
import math
import socket
import unicodedata
from urllib.parse import urlparse, urldefrag
from karon_mcp import __version__

logger = logging.getLogger("karon-unblocker")

mcp = FastMCP("karon-unblocker")
mcp._mcp_server.version = __version__

_API_BASE = "https://api.karonlabs.net"
_ALLOWED_EXTRACTS = {"markdown", "text", "html"}
_MAX_URL_LEN = 8192
_MAX_CONTENT_LEN = 200_000
_MAX_CONCURRENCY = 5
_MAX_URLS = 20
_TIMEOUT_LOCAL = 70.0
_MAX_RESPONSE_BYTES = 10 * 1024 * 1024
_MAX_META_LEN = 2048
_MAX_REJECTED = 100


def _env_flag(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in {"1", "true", "yes", "on"}


def _runtime_env() -> str:
    for name in ("KARON_ENV", "APP_ENV", "ENV"):
        value = os.environ.get(name, "").strip().lower()
        if value:
            return value
    return ""


_DEBUG_ERRORS = _env_flag("KARON_MCP_DEBUG_ERRORS")
_INCLUDE_RESPONSE_META = _env_flag("KARON_MCP_INCLUDE_RESPONSE_META")
_ALLOW_RESPONSE_META = _env_flag("KARON_MCP_ALLOW_RESPONSE_META")
_RUNTIME_ENV = _runtime_env()
_PRODUCTION_ENVS = {"prod", "production"}


def _enforce_runtime_policy() -> None:
    if _RUNTIME_ENV in _PRODUCTION_ENVS and _DEBUG_ERRORS:
        raise RuntimeError("KARON_MCP_DEBUG_ERRORS is forbidden in production")
    if _RUNTIME_ENV in _PRODUCTION_ENVS and _INCLUDE_RESPONSE_META:
        raise RuntimeError("KARON_MCP_INCLUDE_RESPONSE_META is forbidden in production")
    if _INCLUDE_RESPONSE_META and not _ALLOW_RESPONSE_META:
        raise RuntimeError(
            "KARON_MCP_INCLUDE_RESPONSE_META requires KARON_MCP_ALLOW_RESPONSE_META=1"
        )


_enforce_runtime_policy()

_global_sem = asyncio.Semaphore(_MAX_CONCURRENCY)
_client: httpx.AsyncClient | None = None

# --- Blocked networks (SSRF defense) ---
_BLOCKED_NETS = [
    # IPv4
    ipaddress.ip_network("0.0.0.0/8"),
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("100.64.0.0/10"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.0.0.0/24"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("224.0.0.0/4"),       # #20 multicast
    ipaddress.ip_network("240.0.0.0/4"),       # #20 reserved
    ipaddress.ip_network("255.255.255.255/32"),  # broadcast
    # IPv6
    ipaddress.ip_network("::/128"),
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
    ipaddress.ip_network("fe80::/10"),
    ipaddress.ip_network("fec0::/10"),          # #55 site-local
    ipaddress.ip_network("2001:db8::/32"),      # documentation
    ipaddress.ip_network("::ffff:0:0/96"),      # IPv4-mapped
    ipaddress.ip_network("64:ff9b::/96"),       # NAT64
]

# --- Control character translation table (built once) ---
_CONTROL_TRANSLATION: dict[int, str] = {}
for _i in range(32):
    if _i not in (9, 10, 13):  # #6: preserve TAB, LF, CR
        _CONTROL_TRANSLATION[_i] = f"\\x{_i:02x}"
_CONTROL_TRANSLATION[0x7F] = "\\x7f"  # #32: DEL
for _i in range(0x80, 0xA0):           # #48: C1 control codes
    _CONTROL_TRANSLATION[_i] = f"\\x{_i:02x}"
for _cp in (0x200E, 0x200F, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
            0x2066, 0x2067, 0x2068, 0x2069):  # #32: bidi overrides
    _CONTROL_TRANSLATION[_cp] = ""

# ── helpers ──────────────────────────────────────────────────────────────────

def _get_api_key() -> str:
    return os.environ.get("KARON_API_KEY", "")


async def _get_client() -> httpx.AsyncClient:
    global _client
    if _client is None or _client.is_closed:
        _client = httpx.AsyncClient(
            timeout=_TIMEOUT_LOCAL,
            follow_redirects=False,          # #29: SSRF chain prevention
            trust_env=False,                 # #51: env proxy poison prevention
            limits=httpx.Limits(max_connections=_MAX_CONCURRENCY),
            cookies=httpx.Cookies(),         # #24: isolated empty jar
        )
    return _client


def _is_blocked_ip(addr: ipaddress.IPv4Address | ipaddress.IPv6Address) -> bool:
    """Check address (and any embedded IPv4) against blocked networks."""
    check_addrs: list[ipaddress.IPv4Address | ipaddress.IPv6Address] = [addr]
    if isinstance(addr, ipaddress.IPv6Address):
        if addr.ipv4_mapped:                 # ::ffff:x.x.x.x
            check_addrs.append(addr.ipv4_mapped)
        packed = addr.packed
        # #53: IPv4-compatible ::x.x.x.x (not :: or ::1)
        if packed[:12] == b"\x00" * 12 and packed[12:] not in (b"\x00\x00\x00\x00", b"\x00\x00\x00\x01"):
            check_addrs.append(ipaddress.IPv4Address(packed[12:]))
        # #52: 6to4 — 2002:AABB:CCDD::/48 embeds IPv4 A.B.C.D
        if packed[:2] == b"\x20\x02":
            check_addrs.append(ipaddress.IPv4Address(packed[2:6]))
        # #52: Teredo — 2001:0000:...: client IP is packed[12:16] XOR 0xFFFFFFFF
        if packed[:4] == b"\x20\x01\x00\x00":
            client_bits = int.from_bytes(packed[12:16], "big") ^ 0xFFFFFFFF
            check_addrs.append(ipaddress.IPv4Address(client_bits))
    for a in check_addrs:
        for net in _BLOCKED_NETS:
            if isinstance(a, type(net.network_address)) and a in net:
                return True
    return False


async def _validate_url(url: str) -> str | None:
    """Returns validation code if invalid, None if OK."""
    if not isinstance(url, str) or not url.strip():
        return "invalid_url"

    url = url.strip()  # #9

    if "\x00" in url:  # #54: null byte rejection
        return "invalid_url"

    if len(url) > _MAX_URL_LEN:
        return "url_too_long"

    try:  # #8: urlparse can raise ValueError
        parsed = urlparse(url)
    except ValueError:
        return "invalid_url"

    if parsed.scheme not in ("http", "https"):
        return "unsupported_scheme"

    hostname = parsed.hostname
    if not hostname:
        return "invalid_url"

    # #21: port validation
    try:
        port = parsed.port
        if port is not None and not (1 <= port <= 65535):
            return "invalid_port"
    except ValueError:
        return "invalid_port"

    # #41: reject credentials in URL
    if parsed.username or parsed.password:
        return "url_not_allowed"

    # #25: NFKC normalization (fullwidth chars → ASCII)
    try:
        hostname_lower = unicodedata.normalize("NFKC", hostname.lower())
    except (UnicodeError, ValueError):  # #13: oversized hostname → UnicodeError
        return "invalid_hostname"

    if hostname_lower in ("localhost", "localhost.localdomain", "ip6-localhost", "ip6-loopback"):
        return "url_not_allowed"

    # #46: strip IPv6 scope ID (%eth0)
    addr_str = hostname_lower
    if "%" in addr_str:
        addr_str = addr_str.split("%")[0]

    try:
        addr = ipaddress.ip_address(addr_str)
        if _is_blocked_ip(addr):
            return "url_not_allowed"
    except ValueError:
        pass  # Not an IP literal — proceed to DNS check

    # #5: non-blocking DNS resolution via executor
    # #1: FAIL-CLOSED on DNS failure (was fail-open!)
    loop = asyncio.get_running_loop()
    try:
        infos = await loop.run_in_executor(
            None, lambda: socket.getaddrinfo(hostname, None, proto=socket.IPPROTO_TCP),
        )
        for info in infos:
            resolved_ip = info[4][0]
            try:
                addr = ipaddress.ip_address(resolved_ip)
                if _is_blocked_ip(addr):
                    return "url_not_allowed"
            except ValueError:
                continue
    except socket.gaierror:
        return "hostname_unresolved"  # #1 P0: fail-closed

    return None


def _safe_str(val: object, *, max_len: int = 0) -> str:
    """Sanitize value for safe output. max_len=0 means no limit."""
    if isinstance(val, (dict, list)):       # #10: JSON, not Python repr
        try:
            s = json.dumps(val, ensure_ascii=False, allow_nan=False)
        except (ValueError, TypeError):
            s = repr(val)
    elif isinstance(val, str):
        s = val
    elif val is None:                        # #36: None → ""
        return ""
    else:
        s = str(val)
    s = s.translate(_CONTROL_TRANSLATION)
    if max_len and len(s) > max_len:         # #28: truncation support
        s = s[:max_len] + "\n[truncated]"
    return s


def _public_error(code: str) -> str:
    if code == "api_key_missing":
        return "API key not configured"
    if code == "url_not_allowed":
        return "url is not allowed"
    if code == "invalid_request":
        return "request is invalid"
    if code == "request_failed":
        return "request failed"
    if code == "response_unavailable":
        return "response unavailable"
    if code == "timeout":
        return "request timed out"
    return "request failed"


def _error_message(public_code: str, debug_message: str | None = None) -> str:
    if _DEBUG_ERRORS and debug_message:
        return debug_message
    return _public_error(public_code)


def _parse_response(data: object) -> dict | None:
    """Validate upstream response is a dict. Returns None if not."""
    if not isinstance(data, dict):
        return None
    return data


def _build_error(msg: str, status_code: int | None = None, cost: object = None) -> str:
    parts = [f"Error: {msg}"]
    if _DEBUG_ERRORS and status_code is not None:
        parts.append(f"(HTTP {status_code})")
    if _INCLUDE_RESPONSE_META and cost is not None:
        parts.append(f"[credits_used: {cost}]")
    return " ".join(parts)


def _sanitize_cost(cost: object) -> object:
    """Replace NaN/Inf floats with None."""
    if isinstance(cost, float) and not math.isfinite(cost):
        return None
    return cost


def _sanitize_meta(val: object, fallback: str = "") -> str:
    """Sanitize a metadata field: safe_str + CRLF strip + size limit."""
    s = _safe_str(val, max_len=_MAX_META_LEN) if val is not None else fallback
    return s.replace("\n", " ").replace("\r", " ")[:_MAX_META_LEN]


def _validate_resolved_url(raw: object, original: str) -> str:
    """#42: Validate upstream resolved_url — reject non-http(s) schemes."""
    if raw and isinstance(raw, str):
        try:
            rp = urlparse(raw)
            if rp.scheme in ("http", "https"):
                return _sanitize_meta(raw, fallback=original)
        except ValueError:
            pass
    return _sanitize_meta(original)


async def _stream_body(client: httpx.AsyncClient, method: str, url: str,
                       *, headers: dict, json_body: dict) -> tuple[bytes, int]:
    """#4: Stream response body with size guard. Returns (body, status_code)."""
    async with client.stream(method, url, headers=headers, json=json_body) as r:
        status_code = r.status_code
        chunks: list[bytes] = []
        total = 0
        async for chunk in r.aiter_bytes(chunk_size=65536):
            total += len(chunk)
            if total > _MAX_RESPONSE_BYTES:
                raise ValueError("response too large")
            chunks.append(chunk)
    return b"".join(chunks), status_code


async def _parse_json(raw: bytes) -> object:
    """#47: Offload JSON parsing for large payloads."""
    if len(raw) > 1_000_000:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, json.loads, raw)
    return json.loads(raw)


def _validate_request_options(extract: object, readability: object) -> str | None:
    if not isinstance(extract, str):
        return _error_message("invalid_request", "extract must be a string")
    if extract not in _ALLOWED_EXTRACTS:
        return _error_message("invalid_request", f"extract must be one of {sorted(_ALLOWED_EXTRACTS)}")
    if not isinstance(readability, bool):
        return _error_message("invalid_request", "readability must be a boolean")
    return None


def _public_status_block(*, source: str, content: str, cost: object = None, cache_hit: object = None) -> str:
    lines = [f"[source]: {source}"]
    if _INCLUDE_RESPONSE_META:
        lines.append(f"[credits_used]: {cost if cost is not None else '?'}")
        lines.append(f"[cache_hit]: {cache_hit if cache_hit is not None else '?'}")
    lines.extend(["---", content])
    return "\n".join(lines)


def _public_html_payload(*, source: str, content: str, cost: object = None, cache_hit: object = None) -> str:
    payload = {"source": source, "content": content}
    if _INCLUDE_RESPONSE_META:
        payload["credits_used"] = cost
        payload["cache_hit"] = cache_hit
    return json.dumps(payload, ensure_ascii=False, allow_nan=False)


# ── MCP tools ────────────────────────────────────────────────────────────────

@mcp.tool()
async def browse(
    url: str,
    extract: str = "markdown",
    readability: bool = True,
) -> str:
    """
    Fetch any URL protected by WAFs and anti-bot systems.
    Returns clean text or markdown. Costs 1 credit (cache) or 10 credits (browser).

    Args:
        url: Target URL (must start with http/https)
        extract: Output format — "markdown" | "text" | "html"
        readability: True = main content only (default). False = full page.
    """
    api_key = _get_api_key()
    if not api_key:
        logger.error("browse request rejected: missing API key")
        return _build_error(_error_message("api_key_missing", "api_key_missing"))

    url_err = await _validate_url(url)  # async
    if url_err:
        logger.error("browse request rejected: %s", url_err)
        return _build_error(_error_message("url_not_allowed", url_err))

    option_err = _validate_request_options(extract, readability)
    if option_err:
        return _build_error(option_err)

    status_code: int | None = None
    async with _global_sem:
        try:
            client = await _get_client()
            raw, status_code = await _stream_body(
                client, "POST", f"{_API_BASE}/v1/agent/browse",
                headers={"Authorization": f"Bearer {api_key}"},
                json_body={"url": url, "extract": extract, "readability": readability},
            )
            client.cookies.clear()  # #24
        except httpx.HTTPError as e:  # #12: network vs other
            logger.error("browse network request failed", exc_info=True)
            return _build_error(_error_message("request_failed", "network_error"))
        except ValueError as e:
            # "response too large" from _stream_body
            debug_message = str(e)
            code = "response_unavailable" if debug_message == "response too large" else "request_failed"
            debug_code = "response_too_large" if debug_message == "response too large" else "request_error"
            return _build_error(_error_message(code, debug_code), status_code=status_code)
        except Exception as e:
            logger.error("browse request failed", exc_info=True)
            return _build_error(_error_message("request_failed", "request_exception"))  # #22

    try:
        data = await _parse_json(raw)
    except Exception:
        logger.error("browse JSON parse failed (HTTP %s)", status_code)  # #12
        return _build_error(_error_message("response_unavailable", "invalid_upstream_json"), status_code=status_code)

    data = _parse_response(data)
    if data is None:
        return _build_error(_error_message("response_unavailable", "invalid_upstream_response"), status_code=status_code)

    success = data.get("success")
    cost = _sanitize_cost(data.get("cost_credits"))  # #15

    if success is not True:
        logger.error("browse upstream returned failure")
        return _build_error(
            _error_message("request_failed", "upstream_error"),
            status_code=status_code,
            cost=cost,
        )

    if status_code is not None and status_code >= 400:  # #17: keep strict check
        logger.error("browse upstream returned inconsistent success with HTTP %s", status_code)
        return _build_error(_error_message("request_failed", "inconsistent_upstream_status"), status_code=status_code, cost=cost)

    raw_content = data.get("content")
    content = _safe_str(raw_content, max_len=_MAX_CONTENT_LEN) if raw_content is not None else ""  # #36

    resolved_url = _validate_resolved_url(data.get("url"), url)  # #42, #16
    timing = data.get("timing")
    cache_hit = timing.get("cache_hit", "?") if isinstance(timing, dict) else "?"

    if extract == "html":
        return _public_html_payload(source=resolved_url, content=content, cost=cost, cache_hit=cache_hit)

    return _public_status_block(source=resolved_url, content=content, cost=cost, cache_hit=cache_hit)


@mcp.tool()
async def crawl(
    urls: list[str],
    extract: str = "markdown",
    readability: bool = True,
    concurrency: int = 3,
) -> str:
    """
    Fetch multiple URLs concurrently bypassing WAFs. Returns JSON array of results.

    Args:
        urls: List of URLs (max 20)
        extract: Output format — "markdown" | "text"
        readability: True = main content only (default). False = full page.
        concurrency: Parallel requests (1-5, default 3)
    """
    api_key = _get_api_key()
    if not api_key:
        logger.error("crawl request rejected: missing API key")
        return json.dumps([{"url": "N/A", "success": False, "error": _error_message("api_key_missing", "api_key_missing")}])

    if not isinstance(urls, list):
        return json.dumps([{"url": "N/A", "success": False, "error": _error_message("invalid_request", "urls must be a list of strings")}])

    # #38: bool is subclass of int — reject explicitly
    if not isinstance(concurrency, int) or isinstance(concurrency, bool):
        return json.dumps([{"url": "N/A", "success": False, "error": _error_message("invalid_request", "concurrency must be an integer")}])

    option_err = _validate_request_options(extract, readability)
    if option_err:
        return json.dumps([{"url": "N/A", "success": False, "error": option_err}])

    # #18: check count limit BEFORE validation (avoid wasted DNS)
    if len(urls) > _MAX_URLS:
        return json.dumps([{
            "url": "N/A", "success": False,
            "error": _error_message("invalid_request", f"too many URLs: {len(urls)} (max {_MAX_URLS})"),
        }])

    concurrency = max(1, min(_MAX_CONCURRENCY, concurrency))

    # --- URL validation + dedup (#35 before DNS, #23 case-insensitive, #26 defrag) ---
    validated: list[str] = []
    rejected: list[dict] = []
    seen: set[str] = set()

    for u in urls:
        if not isinstance(u, str) or not u.strip():  # #39: safe repr for non-str
            if len(rejected) < _MAX_REJECTED:  # #34: bound growth
                rejected.append({"url": _safe_str(u, max_len=256), "error": _error_message("invalid_request", "invalid url type or empty")})
            continue

        u = u.strip()

        # #26: strip fragment before dedup
        u_defrag, _ = urldefrag(u)

        # #23: case-insensitive dedup key (scheme+host lowercase, path preserved)
        try:
            p = urlparse(u_defrag)
            dedup_key = f"{p.scheme}://{(p.hostname or '').lower()}{p.path}{'?' + p.query if p.query else ''}"
        except ValueError:
            dedup_key = u_defrag.lower()

        # #35: dedup BEFORE DNS validation
        if dedup_key in seen:
            if len(rejected) < _MAX_REJECTED:  # #11: inform caller
                rejected.append({"url": u, "success": False, "content": "", "error": _error_message("invalid_request", "duplicate URL (skipped)")})
            continue
        seen.add(dedup_key)

        url_err = await _validate_url(u_defrag)  # async
        if url_err:
            if len(rejected) < _MAX_REJECTED:  # #34
                rejected.append({"url": u, "error": _error_message("url_not_allowed", url_err)})
            continue

        validated.append(u_defrag)

    # --- fetch logic ---
    local_sem = asyncio.Semaphore(concurrency)

    async def fetch_one(target_url: str) -> dict:
        try:
            async with asyncio.timeout(_TIMEOUT_LOCAL + 5):  # #27: per-URL timeout
                async with local_sem:       # #3: local first
                    async with _global_sem:  # #3: then global
                        try:
                            client = await _get_client()
                            raw, status_code = await _stream_body(
                                client, "POST", f"{_API_BASE}/v1/agent/browse",
                                headers={"Authorization": f"Bearer {api_key}"},
                                json_body={"url": target_url, "extract": extract, "readability": readability},
                            )
                            client.cookies.clear()  # #24
                        except httpx.HTTPError as e:  # #12
                            logger.error("crawl network failed for %s", target_url, exc_info=True)
                            return {"url": target_url, "success": False, "content": "", "error": _error_message("request_failed", "network_error")}
                        except ValueError as e:
                            debug_message = str(e)
                            code = "response_unavailable" if debug_message == "response too large" else "request_failed"
                            debug_code = "response_too_large" if debug_message == "response too large" else "request_error"
                            return {"url": target_url, "success": False, "content": "", "error": _error_message(code, debug_code)}
                        except Exception as e:
                            logger.error("crawl fetch failed for %s", target_url, exc_info=True)
                            return {"url": target_url, "success": False, "content": "", "error": _error_message("request_failed", "request_exception")}

                        status_code_val = status_code
                        try:
                            data = await _parse_json(raw)
                        except Exception:
                            logger.error("crawl JSON parse failed for %s (HTTP %d)", target_url, status_code_val)
                            return {"url": target_url, "success": False, "content": "", "error": _error_message("response_unavailable", "invalid_upstream_json"), "status_code": status_code_val}

                        if not isinstance(data, dict):
                            return {"url": target_url, "success": False, "content": "", "error": _error_message("response_unavailable", "invalid_upstream_response"), "status_code": status_code_val}

                        success = data.get("success") is True

                        # #17: align HTTP status check with browse()
                        if success and status_code_val >= 400:
                            success = False

                        cost = _sanitize_cost(data.get("cost_credits"))  # #14, #58

                        if success:
                            raw_content = data.get("content")
                            content = _safe_str(raw_content, max_len=_MAX_CONTENT_LEN) if raw_content is not None else ""  # #36
                        else:
                            content = ""  # #43: no content leak on failure

                        return {
                            "url": target_url,                                      # #30: always original URL
                            "resolved_url": _validate_resolved_url(data.get("url"), target_url),  # #31, #42
                            "success": success,
                            "content": content,
                            "error": _error_message("request_failed", "upstream_error") if data.get("error") is not None else None,  # #58
                            **({"cost_credits": cost} if _INCLUDE_RESPONSE_META else {}),
                            **({"status_code": status_code_val} if _DEBUG_ERRORS else {}),
                        }
        except TimeoutError:
            return {"url": target_url, "success": False, "content": "", "error": _error_message("timeout", "per-URL timeout exceeded")}

    # --- task execution (#7: asyncio.wait preserves completed on timeout, #40: order) ---
    task_pairs: list[tuple[str, asyncio.Task]] = []
    for u in validated:
        t = asyncio.create_task(fetch_one(u))
        task_pairs.append((u, t))

    all_tasks = [t for _, t in task_pairs]
    batch_timeout = _TIMEOUT_LOCAL * len(validated) / max(concurrency, 1) + 30

    if all_tasks:
        done, pending = await asyncio.wait(all_tasks, timeout=batch_timeout)
        for t in pending:
            t.cancel()
    else:
        done, pending = set(), set()

    # #40: collect in input order
    final: list[dict] = []
    for url_str, t in task_pairs:
        if t in done:
            exc = t.exception()
            if exc:
                logger.error("crawl batch task failed for %s", url_str, exc_info=exc)
                final.append({"url": url_str, "success": False, "content": "", "error": _error_message("request_failed", "request_exception")})
            else:
                final.append(t.result())
        else:
            final.append({"url": url_str, "success": False, "content": "", "error": _error_message("timeout", "batch timeout exceeded")})

    if rejected:
        for rej in rejected:
            rej.setdefault("success", False)
            rej.setdefault("content", "")
            final.append(rej)

    return json.dumps(final, ensure_ascii=False, indent=2, allow_nan=False)


if __name__ == "__main__":
    mcp.run()
