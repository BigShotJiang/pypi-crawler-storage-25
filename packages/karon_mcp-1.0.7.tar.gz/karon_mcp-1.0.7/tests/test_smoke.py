#!/usr/bin/env python3
"""Public smoke tests for karon-mcp."""
import json
import importlib
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

from karon_mcp import __version__


def find_karon_mcp_bin() -> Path:
    interpreter_local = Path(sys.executable).resolve().parent / "karon-mcp"
    if interpreter_local.exists():
        return interpreter_local

    bin_path = shutil.which("karon-mcp")
    if bin_path:
        return Path(bin_path)

    local = Path(".venv/bin/karon-mcp")
    if local.exists():
        return local

    raise FileNotFoundError("karon-mcp binary not found in PATH or .venv/bin")


class SmokeRunner:
    def __init__(self) -> None:
        self.passed = 0
        self.failed = 0
        self.proc: subprocess.Popen[str] | None = None
        self.bin_path = find_karon_mcp_bin()

    def start_server(self, with_api_key: bool = False, extra_env: dict[str, str] | None = None) -> None:
        env = os.environ.copy()
        if not with_api_key:
            env.pop("KARON_API_KEY", None)
        if extra_env:
            env.update(extra_env)
        self.proc = subprocess.Popen(
            [str(self.bin_path)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            env=env,
        )

    def stop_server(self) -> None:
        if not self.proc:
            return
        self.proc.terminate()
        try:
            self.proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            self.proc.kill()
        self.proc = None

    def send(self, req: dict) -> dict:
        assert self.proc and self.proc.stdin and self.proc.stdout
        self.proc.stdin.write(json.dumps(req) + "\n")
        self.proc.stdin.flush()
        deadline = time.time() + 15
        while time.time() < deadline:
            line = self.proc.stdout.readline()
            if line:
                return json.loads(line)
            time.sleep(0.05)
        raise TimeoutError("No MCP response received")

    def wait_for_exit(self) -> tuple[int | None, str]:
        assert self.proc and self.proc.stderr
        try:
            code = self.proc.wait(timeout=3)
        except subprocess.TimeoutExpired as exc:
            raise TimeoutError("Process did not exit in time") from exc
        stderr = self.proc.stderr.read()
        return code, stderr

    def check(self, condition: bool, msg: str) -> None:
        if condition:
            print(f"PASS: {msg}")
            self.passed += 1
        else:
            print(f"FAIL: {msg}")
            self.failed += 1

    def initialize(self) -> dict:
        return self.send(
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "smoke", "version": "1.0"},
                },
            }
        )

    def test_initialize(self) -> None:
        self.start_server()
        resp = self.initialize()
        self.check(resp.get("result", {}).get("serverInfo", {}).get("name") == "karon-unblocker", "initialize returns server name")
        self.check(resp.get("result", {}).get("serverInfo", {}).get("version") == __version__, "initialize returns package version")
        self.stop_server()

    def test_tools(self) -> None:
        self.start_server()
        self.initialize()
        resp = self.send({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
        tool_names = [t.get("name") for t in resp.get("result", {}).get("tools", [])]
        self.check(tool_names == ["browse", "crawl"], "tools/list exposes public tools")
        self.stop_server()

    def test_missing_key(self) -> None:
        self.start_server(with_api_key=False)
        self.initialize()
        resp = self.send(
            {
                "jsonrpc": "2.0",
                "id": 3,
                "method": "tools/call",
                "params": {
                    "name": "browse",
                    "arguments": {"url": "https://example.com", "extract": "text"},
                },
            }
        )
        content = resp.get("result", {}).get("content", [{}])[0].get("text", "")
        self.check("API key not configured" in content, "browse returns a clean missing-key error")
        self.stop_server()

    def test_public_response_hides_meta(self) -> None:
        self.start_server(with_api_key=False)
        self.initialize()
        resp = self.send(
            {
                "jsonrpc": "2.0",
                "id": 4,
                "method": "tools/call",
                "params": {
                    "name": "browse",
                    "arguments": {"url": "https://example.com", "extract": "text"},
                },
            }
        )
        content = resp.get("result", {}).get("content", [{}])[0].get("text", "")
        self.check("[credits_used]" not in content and "[cache_hit]" not in content, "public mode hides response metadata")
        self.stop_server()

    def test_response_meta_requires_explicit_allow(self) -> None:
        self.start_server(extra_env={"KARON_MCP_INCLUDE_RESPONSE_META": "1"})
        code, stderr = self.wait_for_exit()
        self.check(code != 0 and "KARON_MCP_ALLOW_RESPONSE_META=1" in stderr, "response meta requires explicit allow")
        self.stop_server()

    def test_helper_meta_policy(self) -> None:
        env_names = ("KARON_MCP_INCLUDE_RESPONSE_META", "KARON_MCP_ALLOW_RESPONSE_META", "KARON_ENV", "APP_ENV", "ENV")
        original = {name: os.environ.get(name) for name in env_names}
        try:
            for name in env_names:
                os.environ.pop(name, None)
            import karon_mcp.server as server_module
            server_module = importlib.reload(server_module)
            payload = server_module._public_status_block(source="https://example.com", content="ok", cost=1, cache_hit=True)
            self.check("[credits_used]" not in payload and "[cache_hit]" not in payload, "helper keeps metadata hidden by default")

            os.environ["KARON_MCP_INCLUDE_RESPONSE_META"] = "1"
            os.environ["KARON_MCP_ALLOW_RESPONSE_META"] = "1"
            server_module = importlib.reload(server_module)
            payload = server_module._public_status_block(source="https://example.com", content="ok", cost=1, cache_hit=True)
            self.check("[credits_used]: 1" in payload and "[cache_hit]: True" in payload, "helper exposes metadata only with explicit allow")
        finally:
            for name, value in original.items():
                if value is None:
                    os.environ.pop(name, None)
                else:
                    os.environ[name] = value
            import karon_mcp.server as server_module
            importlib.reload(server_module)

    def test_production_blocks_response_meta(self) -> None:
        self.start_server(
            extra_env={
                "KARON_ENV": "production",
                "KARON_MCP_INCLUDE_RESPONSE_META": "1",
                "KARON_MCP_ALLOW_RESPONSE_META": "1",
            }
        )
        code, stderr = self.wait_for_exit()
        self.check(code != 0 and "forbidden in production" in stderr, "production blocks response metadata")
        self.stop_server()

    def test_production_blocks_debug_errors(self) -> None:
        self.start_server(extra_env={"KARON_ENV": "production", "KARON_MCP_DEBUG_ERRORS": "1"})
        code, stderr = self.wait_for_exit()
        self.check(code != 0 and "KARON_MCP_DEBUG_ERRORS is forbidden in production" in stderr, "production blocks debug errors")
        self.stop_server()

    def run(self) -> int:
        self.test_initialize()
        self.test_tools()
        self.test_missing_key()
        self.test_public_response_hides_meta()
        self.test_response_meta_requires_explicit_allow()
        self.test_helper_meta_policy()
        self.test_production_blocks_response_meta()
        self.test_production_blocks_debug_errors()
        print(f"Results: {self.passed} passed, {self.failed} failed")
        return 0 if self.failed == 0 else 1


if __name__ == "__main__":
    runner = SmokeRunner()
    sys.exit(runner.run())
