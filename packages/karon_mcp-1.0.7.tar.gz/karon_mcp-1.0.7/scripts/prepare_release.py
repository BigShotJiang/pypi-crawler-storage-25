#!/usr/bin/env python3
"""Prepare a public release tree from the current SSOT repository."""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BUILD_ROOT = ROOT / "build"
DEFAULT_OUT = BUILD_ROOT / "release"
EXCLUDE_NAMES = {
    ".git",
    ".venv",
    "build",
    "dist",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
}


def _copy_repo(out_dir: Path) -> None:
    if out_dir.exists():
        shutil.rmtree(out_dir)
    shutil.copytree(
        ROOT,
        out_dir,
        ignore=shutil.ignore_patterns(*EXCLUDE_NAMES),
    )
    integration_workflow = out_dir / ".github" / "workflows" / "integration.yml"
    if integration_workflow.exists():
        integration_workflow.unlink()


def _run(cmd: list[str], cwd: Path) -> None:
    subprocess.run(cmd, cwd=cwd, check=True)


def _release_scan(out_dir: Path) -> None:
    scans = [
        (
            [
                "CHANGELOG.md",
                "Cloudflare",
                "DataDome",
                "Akamai",
                "Kasada",
                "PerimeterX",
                "hCaptcha",
                "AWS WAF",
                "waf-bypass",
                "TOCTOU",
                "billing bypass",
                "KARON_API_KEY environment variable not set",
                "[credits_used]",
                "[cache_hit]",
            ],
            ["README.md", "pyproject.toml", ".github", "src"],
        ),
        (
            ["/mnt/nvme-hot"],
            ["tests", ".github", "README.md"],
        ),
    ]
    for patterns, files in scans:
        cmd = ["rg", "-n", "-F"]
        for pattern in patterns:
            cmd.extend(["-e", pattern])
        cmd.extend(files)
        result = subprocess.run(cmd, cwd=out_dir, text=True, capture_output=True)
        if result.returncode == 0:
            raise SystemExit(f"release scan failed:\n{result.stdout}")
        if result.returncode > 1:
            raise SystemExit(result.stderr or "release scan error")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=str(DEFAULT_OUT))
    parser.add_argument("--build", action="store_true")
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()

    out_dir = Path(args.out).resolve()
    _copy_repo(out_dir)
    _release_scan(out_dir)

    if args.build:
        _run([sys.executable, "-m", "build"], cwd=out_dir)

    if args.smoke:
        venv_dir = out_dir / ".release-venv"
        _run([sys.executable, "-m", "venv", str(venv_dir)], cwd=out_dir)
        pip_bin = venv_dir / "bin" / "pip"
        wheel = next((out_dir / "dist").glob("karon_mcp-*.whl"))
        _run([str(pip_bin), "install", str(wheel)], cwd=out_dir)
        _run(
            [
                "bash",
                "-lc",
                ". .release-venv/bin/activate && python tests/test_smoke.py",
            ],
            cwd=out_dir,
        )

    print(out_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
