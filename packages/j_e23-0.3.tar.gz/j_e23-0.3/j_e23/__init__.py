# This code runs the moment someone types "import omkar_cheat_notes_12345"

CHEAT_CODE_NOTE = """
1. Vowels and Consonants
import re
text = "Compiler Construction"
vowels = len(re.findall(r'[aeiouAEIOU]', text))
consonants = sum(1 for c in text if c.isalpha()) - vowels
print(f"String: {text}\nVowels: {vowels}, Consonants: {consonants}")

2. Lexical Analyzer
import re
code = "int a = 10 + b;"
# Regex matches identifiers, numbers, and symbols
tokens = re.findall(r'[a-zA-Z_]\w*|\d+|[=+\-*/;]', code)
for token in tokens:
    print(f"Token: {token}")

3. First and Follow (Simplified)
grammar = {'S': ['aB', 'c'], 'B': ['b', 'd']}
first = {}
for nt, rules in grammar.items():
    # Grabs the first terminal of each rule
    first[nt] = {rule[0] for rule in rules if rule[0].islower()}
print(f"FIRST sets: {first}")
print("FOLLOW sets: {'S': {'$'}, 'B': {'$'}}") # Hardcoded for brevity

4. Single Pass Macro Processor
lines = ["START", "MACRO_1", "END"]
macros = {"MACRO_1": "MOV A, B\nADD C"}
expanded = []
for line in lines:
    expanded.extend(macros.get(line, line).split('\n'))
print("Expanded Source:\n" + '\n'.join(expanded))

5. Recognize Keywords, Numbers, Words
stmt = "if x == 10 then y"
keywords = {'if', 'then', 'else'}
for word in stmt.split():
    if word in keywords: print(f"{word} -> Keyword")
    elif word.isdigit(): print(f"{word} -> Number")
    elif word.isalpha(): print(f"{word} -> Word")

6. Two Pass Assembler (Simulated)
code = ["START 100", "L1 ADD B", "JMP L1"]
symtab = {} # Pass 1: Build Symbol Table
for i, line in enumerate(code):
    if len(parts := line.split()) > 1 and parts[0] not in ["START", "JMP"]:
        symtab[parts[0]] = 100 + i
for line in code[1:]: # Pass 2: Substitute addresses
    print(f"Instruction: {line} | Target Address: {symtab.get(line.split()[-1], 'None')}")

7. Calculator & Evaluate Expression (YACC alternative)
def evaluate_expr(expression):
    try:
        return eval(expression) # eval() handles the parsing logic 
    except Exception as e:
        return f"Error: {e}"
expr = "5 + 3 * (8 - 2)"
print(f"Result of '{expr}' = {evaluate_expr(expr)}")
"""
print(CHEAT_CODE_NOTE)