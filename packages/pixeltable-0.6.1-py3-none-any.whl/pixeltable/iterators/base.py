from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Iterator

from deprecated import deprecated

from pixeltable import exceptions as excs
from pixeltable.func import GeneratingFunction, GeneratingFunctionCall
from pixeltable.func.iterator import ITERATOR_GUIDE_URL
from pixeltable.type_system import ColumnType


class ComponentIterator(ABC):
    """Base class for Pixeltable iterators."""

    @classmethod
    @abstractmethod
    def input_schema(cls) -> dict[str, ColumnType]:
        """Provide the Pixeltable types of the init() parameters

        The keys need to match the names of the init() parameters. This is equivalent to the parameters_types
        parameter of the @function decorator.
        """
        raise NotImplementedError

    @classmethod
    @abstractmethod
    def output_schema(cls, *args: Any, **kwargs: Any) -> tuple[dict[str, ColumnType], list[str]]:
        """Specify the dictionary returned by next() and a list of unstored column names

        Returns:
            a dictionary which is turned into a list of columns in the output table
            a list of unstored column names
        """
        raise NotImplementedError

    def __iter__(self) -> Iterator[dict[str, Any]]:
        return self

    @abstractmethod
    def __next__(self) -> dict[str, Any]:
        """Return the next element of the iterator as a dictionary or raise StopIteration"""
        raise NotImplementedError

    @abstractmethod
    def close(self) -> None:
        """Close the iterator and release all resources"""
        raise NotImplementedError

    def set_pos(self, pos: int, **kwargs: Any) -> None:
        """Set the iterator position to pos"""
        pass

    @classmethod
    @deprecated(
        'The `ComponentIterator` class is deprecated; please use the `@pxt.iterator` decorator instead.\n'
        f'For details see: {ITERATOR_GUIDE_URL}',
        version='0.5.19',
        category=excs.PixeltableDeprecationWarning,
    )
    def create(cls, **kwargs: Any) -> GeneratingFunctionCall:
        # Use GeneratingFunction._retrofit() for backward compatibility with legacy iterator pattern
        it = GeneratingFunction._retrofit(cls)
        return it(**kwargs)
