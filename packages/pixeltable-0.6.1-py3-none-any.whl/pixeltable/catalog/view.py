from __future__ import annotations

import dataclasses
import logging
from typing import TYPE_CHECKING, Any, List, Literal, Mapping
from uuid import UUID

import pixeltable.exceptions as excs
import pixeltable.metadata.schema as md_schema
import pixeltable.type_system as ts
from pixeltable import exprs, func
from pixeltable.catalog.globals import _POS_COLUMN_NAME
from pixeltable.func.iterator import IteratorOutput
from pixeltable.runtime import get_runtime
from pixeltable.types import ColumnSpec

from .column import Column
from .globals import MediaValidation
from .table import Table
from .table_version import TableVersion, TableVersionKey, TableVersionMd
from .table_version_handle import TableVersionHandle
from .table_version_path import TableVersionPath
from .tbl_ops import CreateStoreTableOp, CreateTableMdOp, LoadViewOp, OpStatus, TableOp
from .update_status import UpdateStatus

if TYPE_CHECKING:
    from pixeltable.catalog.table import TableMetadata
    from pixeltable.globals import TableDataSource
    from pixeltable.plan import SampleClause

_logger = logging.getLogger('pixeltable')


class View(Table):
    """A `Table` that presents a virtual view of another table (or view).

    A view is typically backed by a store table, which records the view's columns and is joined back to the bases
    at query execution time.
    The exception is a snapshot view without a predicate and without additional columns: in that case, the view
    is simply a reference to a specific set of base versions.
    """

    def __init__(self, id: UUID, dir_id: UUID, name: str, tbl_version_path: TableVersionPath, snapshot_only: bool):
        super().__init__(id, dir_id, name, tbl_version_path)
        self._snapshot_only = snapshot_only
        if not snapshot_only:
            self._tbl_version = tbl_version_path.tbl_version

    def _display_name(self) -> str:
        if self._tbl_version_path.is_replica():
            return 'replica'
        if self._tbl_version_path.is_snapshot():
            return 'snapshot'
        if self._tbl_version_path.is_view():
            return 'view'
        return 'table'

    @classmethod
    def select_list_to_additional_columns(
        cls, select_list: list[tuple[exprs.Expr, str | None]]
    ) -> dict[str, ColumnSpec]:
        """Returns a list of columns in the same format as the additional_columns parameter of View.create.
        The source is the list of expressions from a select() statement on a Query.
        If the column is a ColumnRef, to a base table column, it is marked to not be stored.sy
        """
        from pixeltable._query import Query

        r: dict[str, ColumnSpec] = {}
        exps, names = Query._normalize_select_list([], select_list)
        for expr, name in zip(exps, names):
            stored = not isinstance(expr, exprs.ColumnRef)
            r[name] = {'value': expr, 'stored': stored}
        return r

    @classmethod
    def _create(
        cls,
        name: str,
        base: TableVersionPath,
        select_list: list[tuple[exprs.Expr, str | None]] | None,
        additional_columns: Mapping[str, type | ColumnSpec | exprs.Expr],
        predicate: 'exprs.Expr' | None,
        sample_clause: 'SampleClause' | None,
        is_snapshot: bool,
        create_default_idxs: bool,
        comment: str | None,
        custom_metadata: Any,
        media_validation: MediaValidation,
        iterator_call: func.GeneratingFunctionCall | None,
    ) -> tuple[TableVersionMd, list[TableOp] | None]:
        from pixeltable.exprs import InlineDict
        from pixeltable.plan import SampleClause

        # Convert select_list to more additional_columns if present
        include_base_columns: bool = select_list is None
        select_list_columns: List[Column] = []
        if not include_base_columns:
            r = cls.select_list_to_additional_columns(select_list)
            select_list_columns = [Column.create(name, spec) for name, spec in r.items()]

        columns = select_list_columns + [Column.create(name, spec) for name, spec in additional_columns.items()]
        cls._verify_schema(columns)

        # verify that filters can be evaluated in the context of the base
        if predicate is not None:
            if not predicate.is_bound_by([base]):
                raise excs.RequestError(
                    excs.ErrorCode.UNSUPPORTED_OPERATION,
                    f'View filter cannot be computed in the context of the base table {base.tbl_name()!r}',
                )
            # create a copy that we can modify and store
            predicate = predicate.copy()
        if sample_clause is not None:
            # make sure that the sample clause can be computed in the context of the base
            if sample_clause.stratify_exprs is not None and not all(
                stratify_expr.is_bound_by([base]) for stratify_expr in sample_clause.stratify_exprs
            ):
                raise excs.RequestError(
                    excs.ErrorCode.UNSUPPORTED_OPERATION,
                    f'View sample clause cannot be computed in the context of the base table {base.tbl_name()!r}',
                )
            # create a copy that we can modify and store
            sc = sample_clause
            sample_clause = SampleClause(
                sc.version, sc.n, sc.n_per_stratum, sc.fraction, sc.seed, sc.stratify_exprs.copy()
            )

        # same for value exprs
        for col in columns:
            if not col.is_computed:
                continue
            # make sure that the value can be computed in the context of the base
            if col.value_expr is not None and not col.value_expr.is_bound_by([base]):
                raise excs.RequestError(
                    excs.ErrorCode.UNSUPPORTED_OPERATION,
                    f'Column {col.name!r}: Value expression cannot be computed in the context of the '
                    f'base table {base.tbl_name()!r}',
                )

        if iterator_call is not None:
            assert _POS_COLUMN_NAME in iterator_call.outputs
            known_col_names = {col.name for col in columns}
            if include_base_columns:
                known_col_names.update(col.name for col in base.columns())
            if any(name in known_col_names for name in iterator_call.outputs):
                # One or more output column names from the iterator call conflict with existing column names.
                # Rename the output column names as necessary to avoid conflicts.
                updated_outputs: dict[str, IteratorOutput] = {}
                for col_name, output_info in iterator_call.outputs.items():
                    unique_name = cls.__get_unique_column_name(col_name, known_col_names)
                    if unique_name != col_name:
                        known_col_names.add(unique_name)
                    updated_outputs[unique_name] = output_info
                iterator_call = dataclasses.replace(iterator_call, outputs=updated_outputs)

            iterator_cols = []
            for col_name, output_info in iterator_call.outputs.items():
                stores_cellmd = Column.should_store_cellmd(
                    col_type=output_info.col_type, is_stored=output_info.is_stored, is_computed=False
                )
                iterator_cols.append(
                    Column(
                        col_name,
                        col_type=output_info.col_type,
                        is_iterator_col=True,
                        stored=output_info.is_stored,
                        stores_cellmd=stores_cellmd,
                    )
                )

            columns = iterator_cols + columns

        iterator_args_expr: exprs.Expr = InlineDict(iterator_call.bound_args) if iterator_call is not None else None
        base_version_path = cls._get_snapshot_path(base) if is_snapshot else base

        # if this is a snapshot, we need to retarget all exprs to the snapshot tbl versions
        if is_snapshot:
            predicate = predicate.retarget(base_version_path) if predicate is not None else None
            if sample_clause is not None:
                exprs.Expr.retarget_list(sample_clause.stratify_exprs, base_version_path)
            iterator_args_expr = (
                iterator_args_expr.retarget(base_version_path) if iterator_args_expr is not None else None
            )
            for col in columns:
                if col.value_expr is not None:
                    col.set_value_expr(col.value_expr.retarget(base_version_path))

        view_md = md_schema.ViewMd(
            is_snapshot=is_snapshot,
            include_base_columns=include_base_columns,
            predicate=predicate.as_dict() if predicate is not None else None,
            sample_clause=sample_clause.as_dict() if sample_clause is not None else None,
            base_versions=base_version_path.as_md(),
            iterator_call=iterator_call.as_dict() if iterator_call is not None else None,
        )

        md = TableVersion.create_initial_md(
            name,
            columns,
            comment,
            custom_metadata,
            media_validation=media_validation,
            view_md=view_md,
            create_default_idxs=create_default_idxs,
            is_versioned=base.is_versioned(),
        )
        if md.tbl_md.is_pure_snapshot:
            # this is purely a snapshot: no store table to create or load
            return md, None
        else:
            tbl_id = md.tbl_md.tbl_id
            key = TableVersionKey(UUID(tbl_id), 0 if is_snapshot else None, None)
            view_path = TableVersionPath(TableVersionHandle(key), base=base_version_path)
            ops = [
                CreateTableMdOp(tbl_id=tbl_id, op_sn=0, num_ops=3, status=OpStatus.PENDING),
                CreateStoreTableOp(tbl_id=tbl_id, op_sn=1, num_ops=3, status=OpStatus.PENDING),
                LoadViewOp(tbl_id=tbl_id, op_sn=2, num_ops=3, status=OpStatus.PENDING, view_path=view_path.as_dict()),
            ]
            return md, ops

    @classmethod
    def __get_unique_column_name(cls, base_name: str, existing_names: set[str]) -> str:
        """Returns a unique column name based on the given base name and the set of existing names."""
        if base_name not in existing_names:
            return base_name

        i = 1
        new_name = f'{base_name}_{i}'
        while new_name in existing_names:
            i += 1
            new_name = f'{base_name}_{i}'

        return new_name

    @classmethod
    def _verify_column(cls, col: Column) -> None:
        # make sure that columns are nullable or have a default
        if not col.col_type.nullable and not col.is_computed:
            raise excs.RequestError(
                excs.ErrorCode.INVALID_ARGUMENT, f'Column {col.name!r}: Non-computed columns in views must be nullable'
            )
        super()._verify_column(col)

    @classmethod
    def _get_snapshot_path(cls, tbl_version_path: TableVersionPath) -> TableVersionPath:
        """Returns snapshot of the given table version path.
        All TableVersions of that path will be snapshot versions. Creates new versions from mutable versions,
        if necessary.
        """
        if tbl_version_path.is_snapshot():
            return tbl_version_path
        tbl_version = tbl_version_path.tbl_version.get()
        assert not tbl_version.is_snapshot

        return TableVersionPath(
            TableVersionHandle(TableVersionKey(tbl_version.id, tbl_version.version, None)),
            base=cls._get_snapshot_path(tbl_version_path.base) if tbl_version_path.base is not None else None,
        )

    def _is_named_pure_snapshot(self) -> bool:
        """
        Returns True if this is a named pure snapshot (i.e., a pure snapshot that is a separate schema object).
        """
        return self._id != self._tbl_version_path.tbl_id

    def _is_anonymous_snapshot(self) -> bool:
        """
        Returns True if this is an unnamed snapshot (i.e., a snapshot that is not a separate schema object).
        """
        return self._snapshot_only and self._id == self._tbl_version_path.tbl_id

    def _get_metadata(self) -> 'TableMetadata':
        md = super()._get_metadata()
        md['is_view'] = True
        md['is_snapshot'] = self._tbl_version_path.is_snapshot()
        if self._is_anonymous_snapshot():
            # Update name and path with version qualifiers.
            md['name'] = f'{self._name}:{self._tbl_version_path.version()}'
            md['path'] = f'{self._path()}:{self._tbl_version_path.version()}'
        base_tbl_id = self._base_tbl_id
        if base_tbl_id is not None:
            base_tbl = self._get_base_table()
            base_path = '<anonymous base table>' if base_tbl is None else base_tbl._path()
            base_version = self._effective_base_versions[0]
            md['base'] = base_path if base_version is None else f'{base_path}:{base_version}'

        tv = self._tbl_version_path.tbl_version.get()
        if tv.iterator_call is not None:
            # Mark iterator-produced columns
            columns = self._tbl_version_path.columns()
            for col in columns:
                if col.name in md['columns'] and tv.is_iterator_column(col):
                    md['columns'][col.name]['is_iterator_col'] = True
            # Build the iterator expression string: "iterator_name(arg1, arg2=expr2, ...)"
            arg_strs: list[str] = []
            for arg_expr in tv.iterator_call.args:
                arg_strs.append(arg_expr.display_str(inline=True))
            for arg_name, arg_expr in tv.iterator_call.kwargs.items():
                arg_strs.append(f'{arg_name}={arg_expr.display_str(inline=True)}')
            md['iterator_call'] = f'{tv.iterator_call.it.name}({", ".join(arg_strs)})'

        return md

    def insert(
        self,
        source: TableDataSource | None = None,
        /,
        *,
        source_format: Literal['csv', 'excel', 'parquet', 'json'] | None = None,
        schema_overrides: dict[str, ts.ColumnType] | None = None,
        on_error: Literal['abort', 'ignore'] = 'abort',
        print_stats: bool = False,
        **kwargs: Any,
    ) -> UpdateStatus:
        raise excs.RequestError(
            excs.ErrorCode.UNSUPPORTED_OPERATION, f'{self._display_str()}: Cannot insert into a {self._display_name()}.'
        )

    def delete(self, where: exprs.Expr | None = None) -> UpdateStatus:
        raise excs.RequestError(
            excs.ErrorCode.UNSUPPORTED_OPERATION, f'{self._display_str()}: Cannot delete from a {self._display_name()}.'
        )

    @property
    def _base_tbl_id(self) -> UUID | None:
        if self._tbl_version_path.tbl_id != self._id:
            # _tbl_version_path represents a different schema object from this one. This can only happen if this is a
            # named pure snapshot.
            return self._tbl_version_path.tbl_id
        if self._tbl_version_path.base is None:
            return None
        return self._tbl_version_path.base.tbl_id

    def _get_base_table(self) -> 'Table' | None:
        """Returns None if there is no base table, or if the base table is hidden."""
        base_tbl_id = self._base_tbl_id
        if base_tbl_id is None:
            return None
        with get_runtime().catalog.begin_xact(read_tbl_ids=[base_tbl_id]):
            return get_runtime().catalog.get_table_by_id(base_tbl_id)

    @property
    def _effective_base_versions(self) -> list[int | None]:
        effective_versions = [tv.effective_version for tv in self._tbl_version_path.get_tbl_versions()]
        if self._snapshot_only and not self._is_anonymous_snapshot():
            return effective_versions  # Named pure snapshot
        else:
            return effective_versions[1:]

    def _table_descriptor(self) -> str:
        result = [self._display_str()]
        bases_descrs: list[str] = []
        for base, effective_version in zip(self._get_base_tables(), self._effective_base_versions):
            if effective_version is None:
                bases_descrs.append(f'{base._path()!r}')
            else:
                base_descr = f'{base._path()}:{effective_version}'
                bases_descrs.append(f'{base_descr!r}')
        if len(bases_descrs) > 0:
            # bases_descrs can be empty in the case of a table-replica
            result.append(f' (of {", ".join(bases_descrs)})')

        if self._tbl_version_path.tbl_version.get().predicate is not None:
            result.append(f'\nWhere: {self._tbl_version_path.tbl_version.get().predicate!s}')
        if self._tbl_version_path.tbl_version.get().sample_clause is not None:
            result.append(f'\nSample: {self._tbl_version.get().sample_clause!s}')
        return ''.join(result)
