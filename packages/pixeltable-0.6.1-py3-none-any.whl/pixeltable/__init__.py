"""
Core Pixeltable API for table operations, data processing, and UDF management.
"""

# ruff: noqa: F401

from ._query import Query, ResultCursor, ResultSet, Row
from ._version import __version__
from .catalog import (
    Column,
    ColumnMetadata,
    IndexMetadata,
    InsertableTable,
    Table,
    TableMetadata,
    UpdateStatus,
    VersionMetadata,
    View,
)
from .exceptions import (
    AlreadyExistsError,
    AuthorizationError,
    ConcurrencyError,
    Error,
    ErrorCode,
    ExternalServiceError,
    NotFoundError,
    PixeltableWarning,
    RequestError,
    ServiceUnavailableError,
)
from .func import (
    Aggregator,
    Function,
    PxtIterator,
    Tool,
    ToolChoice,
    Tools,
    expr_udf,
    iterator,
    mcp_udfs,
    query,
    retrieval_udf,
    uda,
    udf,
)
from .globals import (
    DirContents,
    DirectoryNode,
    TableKind,
    TableNode,
    TreeNode,
    array,
    configure_logging,
    create_dir,
    create_snapshot,
    create_table,
    create_view,
    drop_dir,
    drop_table,
    get_dir_contents,
    get_dir_tree,
    get_table,
    home,
    init,
    list_dirs,
    list_functions,
    list_tables,
    ls,
    move,
    publish,
    replicate,
    tool,
    tools,
)
from .type_system import (
    UUID,
    Array,
    Audio,
    Binary,
    Bool,
    Date,
    Document,
    Float,
    Image,
    Int,
    Json,
    Required,
    String,
    Timestamp,
    Video,
)

# This import must go last to avoid circular imports.
from . import dashboard, functions, io, iterators  # isort: skip

# This is the safest / most maintainable way to construct __all__: start with the default and "blacklist"
# stuff that we don't want in there. (Using a "whitelist" is considerably harder to maintain.)

__default_dir = {symbol for symbol in dir() if not symbol.startswith('_')}
__removed_symbols = {
    '_query',
    'catalog',
    'env',
    'exceptions',
    'exec',
    'exprs',
    'func',
    'globals',
    'index',
    'metadata',
    'plan',
    'type_system',
    'utils',
}
__all__ = sorted(__default_dir - __removed_symbols)


def __dir__() -> list[str]:
    return __all__
