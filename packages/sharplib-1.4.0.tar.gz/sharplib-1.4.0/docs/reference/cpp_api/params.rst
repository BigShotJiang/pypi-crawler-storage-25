params
======

Convective
----------

.. doxygenfunction:: sharp::effective_inflow_layer(Lifter&, const float[], const float[], const float[], const float[], const float[], float[], float[], const std::ptrdiff_t, const float, const float, Parcel*)
.. doxygenfunction:: sharp::storm_motion_bunkers(const float[], const float[], const float[], const float[], const std::ptrdiff_t, HeightLayer, HeightLayer, const bool, const bool)
.. doxygenfunction:: sharp::storm_motion_bunkers(const float[], const float[], const float[], const float[], const std::ptrdiff_t, PressureLayer, const Parcel&, const bool)
.. doxygenfunction:: sharp::mcs_motion_corfidi
.. doxygenfunction:: sharp::effective_bulk_wind_difference
.. doxygenfunction:: sharp::energy_helicity_index
.. doxygenfunction:: sharp::supercell_composite_parameter
.. doxygenfunction:: sharp::significant_tornado_parameter
.. doxygenfunction:: sharp::significant_hail_parameter
.. doxygenfunction:: sharp::derecho_composite_parameter
.. doxygenfunction:: sharp::large_hail_parameter
.. doxygenfunction:: sharp::hail_growth_layer
.. doxygenfunction:: sharp::convective_temperature(Lifter&, const float[], const float[], const float[], const float[], const float[], float[], float[], const std::ptrdiff_t, float)
.. doxygenfunction:: sharp::precipitable_water

Fire
----

.. doxygenfunction:: sharp::equilibrium_moisture_content
.. doxygenfunction:: sharp::fosberg_fire_index
.. doxygenfunction:: sharp::pft_plume_potential_temperature
.. doxygenfunction:: sharp::pft_plume_mixratio
.. doxygenfunction:: sharp::pyrocumulonimbus_firepower_threshold

Winter
------

.. doxygenfunction:: sharp::dendritic_layer
.. doxygenfunction:: sharp::snow_squall_parameter

