# Perforated

**Perforated Backpropagation** by [Perforated AI](https://perforated.ai)

A parameter-efficient neural network training algorithm that adds dendritic computation layers to standard neurons, enabling models to achieve greater capability density.

## Status

This package is a placeholder. Full SDK coming soon.

## Links

- [GitHub](https://github.com/PerforatedAI/PerforatedBackpropagation)
- [ArXiv Paper](https://arxiv.org/abs/2501.18018)
- [Patent US11580403B2](https://patents.google.com/patent/US11580403B2)
