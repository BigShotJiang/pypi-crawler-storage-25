"""
Perforated AI - Perforated Backpropagation

Official package for Perforated AI's neural network training algorithm.
Visit https://perforated.ai for more information.
"""

__version__ = "0.1.0"
__author__ = "Perforated AI"
