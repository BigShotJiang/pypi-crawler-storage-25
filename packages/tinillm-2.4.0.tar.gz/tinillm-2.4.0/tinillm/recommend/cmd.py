"""Entry point for `tinillm recommend`."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor

from tinillm.models.database import MODELS, RealModel
from tinillm.analyzer.fit import _memory_budget, best_quant_for_budget, score_fit_level
from tinillm.analyzer.types import FitLevel, ModelFit, LlmModel
from tinillm.analyzer.throughput import estimate_tokens_per_sec
from tinillm.hardware.detect import detect
from tinillm.hardware.bandwidth import gpu_bandwidth_gbps
from tinillm.recommend.logic import rank_models


def _to_llm_model(m: RealModel) -> LlmModel:
    return LlmModel(
        name=m.display_name,
        params_b=m.params_b,
        num_layers=m.num_layers,
        num_kv_heads=m.num_kv_heads,
        head_dim=m.head_dim,
        context_length=m.context_length,
    )


def _fit_model(
    model: RealModel,
    budget_gb: float,
    bandwidth_gbps: float,
    runs_on_gpu: bool,
) -> ModelFit:
    lm = _to_llm_model(model)
    result = best_quant_for_budget(lm, budget_gb)
    if result is None:
        return ModelFit(
            model=lm,
            fit_level=FitLevel.TOO_TIGHT,
            best_quant=None,
            mem_required_gb=None,
            tokens_per_sec=None,
            runs_on_gpu=runs_on_gpu,
        )
    best_quant, mem_required, ctx = result
    fit_level = score_fit_level(mem_required, budget_gb, runs_on_gpu, best_quant, lm, ctx)
    tps = estimate_tokens_per_sec(lm, best_quant, bandwidth_gbps, runs_on_gpu)
    return ModelFit(
        model=lm,
        fit_level=fit_level,
        best_quant=best_quant,
        mem_required_gb=round(mem_required, 1),
        tokens_per_sec=round(tps, 1),
        runs_on_gpu=runs_on_gpu,
    )


def run_recommend(use_case: str | None, json_output: bool) -> None:
    """Detect hardware, score all models in parallel, and render top picks."""
    from tinillm.recommend.render import render_recommend_table, render_recommend_json
    from rich.console import Console
    from tinillm.render.styles import TINILLM_THEME
    import os

    console = Console(theme=TINILLM_THEME, no_color="NO_COLOR" in os.environ, highlight=False)

    with console.status("[dim]Finding best models for your hardware...[/dim]"):
        specs = detect()
        budget_gb, runs_on_gpu = _memory_budget(specs)
        bw = gpu_bandwidth_gbps(specs.gpus[0].name) if specs.gpus else 0.0

        def _fit(model: RealModel) -> tuple[RealModel, ModelFit]:
            return model, _fit_model(model, budget_gb, bw, runs_on_gpu)

        with ThreadPoolExecutor(max_workers=8) as pool:
            candidates = list(pool.map(_fit, MODELS))

    ranked = rank_models(candidates, use_case)

    # Memory hook: record the top recommendation as a project-scoped fact so
    # future sessions know what was suggested for this use-case. Best-effort.
    try:
        from tinillm.memory.writer import ingest_suggest_choice
        top = ranked[0] if ranked else None
        if top is not None:
            tag = getattr(top.model, "name", None) or getattr(top.model, "ollama_tag", None)
            if tag:
                ingest_suggest_choice(use_case, str(tag))
    except Exception:
        pass

    if json_output:
        import click
        click.echo(render_recommend_json(ranked, specs, budget_gb, runs_on_gpu, use_case))
        return

    render_recommend_table(ranked, specs, budget_gb, runs_on_gpu, use_case)
