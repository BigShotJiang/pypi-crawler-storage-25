"""Hardware summary card renderer — violet brand-bar style."""

from __future__ import annotations

from rich.console import Console
from rich.table import Table

from tinillm.hardware.types import SystemSpecs
from tinillm.render.styles import backend_style, render_header


def render_hardware_summary(console: Console, specs: SystemSpecs) -> None:
    """Print hardware info beneath a violet brand-bar header."""
    render_header(console, "tinillm scan", "Hardware Report")

    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="label", min_width=6)
    grid.add_column(style="value")

    cpu = specs.cpu
    freq_str = f"  {cpu.freq_mhz / 1000:.1f} GHz" if cpu.freq_mhz else ""
    grid.add_row(
        "CPU",
        f"{cpu.model_name}   {cpu.physical_cores}c / {cpu.logical_cores}t{freq_str}",
    )
    grid.add_row(
        "RAM",
        f"{specs.total_ram_gb:.1f} GB total  ·  {specs.free_ram_gb:.1f} GB free",
    )

    if specs.gpus:
        for i, gpu in enumerate(specs.gpus):
            count_str = f" × {gpu.count}" if gpu.count > 1 else ""
            unified_str = "  (unified)" if gpu.unified_memory else ""
            backend_markup = f"[{backend_style(gpu.backend)}]{gpu.backend}[/]"
            label = f"GPU {i}" if len(specs.gpus) > 1 else "GPU"
            grid.add_row(
                label,
                f"{gpu.name}{count_str}  {gpu.vram_gb:.1f} GB  {backend_markup}{unified_str}",
            )
    else:
        grid.add_row("GPU", "[dim]None detected — CPU-only mode[/dim]")

    grid.add_row("OS", specs.os)
    console.print(grid)
    console.print()
