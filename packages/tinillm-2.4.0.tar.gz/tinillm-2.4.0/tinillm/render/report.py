"""Top-level report renderer — wires hardware summary + capability matrix."""

from __future__ import annotations

import json
import sys

from rich.console import Console

from tinillm.hardware.types import SystemSpecs
from tinillm.analyzer.types import ModelFit
from tinillm.render.styles import TINILLM_THEME
from tinillm.render.hardware_summary import render_hardware_summary
from tinillm.render.capability_matrix import render_capability_matrix


def _make_console(force_plain: bool = False) -> Console:
    no_color = force_plain or "NO_COLOR" in __import__("os").environ
    return Console(theme=TINILLM_THEME, no_color=no_color, highlight=False)


def render_report(
    specs: SystemSpecs,
    fits: list[ModelFit],
    verbose: bool = False,
) -> None:
    """Print the full hardware + LLM capability report to stdout."""
    console = _make_console()
    console.print()
    render_hardware_summary(console, specs)
    render_capability_matrix(console, fits, verbose=verbose)


def render_json(specs: SystemSpecs, fits: list[ModelFit]) -> str:
    """Return a JSON string representation of the scan results."""

    def gpu_dict(g):
        return {
            "name": g.name,
            "vram_gb": g.vram_gb,
            "backend": g.backend,
            "count": g.count,
            "unified_memory": g.unified_memory,
        }

    def fit_dict(f):
        return {
            "model": f.model.name,
            "params_b": f.model.params_b,
            "fit_level": f.fit_level.value,
            "best_quant": f.best_quant.value if f.best_quant else None,
            "mem_required_gb": f.mem_required_gb,
            "tokens_per_sec": f.tokens_per_sec,
            "runs_on_gpu": f.runs_on_gpu,
        }

    payload = {
        "hardware": {
            "os": specs.os,
            "cpu": {
                "model": specs.cpu.model_name,
                "physical_cores": specs.cpu.physical_cores,
                "logical_cores": specs.cpu.logical_cores,
                "freq_mhz": specs.cpu.freq_mhz,
            },
            "ram": {
                "total_gb": specs.total_ram_gb,
                "free_gb": specs.free_ram_gb,
            },
            "gpus": [gpu_dict(g) for g in specs.gpus],
        },
        "fits": [fit_dict(f) for f in fits],
    }
    return json.dumps(payload, indent=2)
