"""Rich style constants and shared rendering utilities for tinillm."""

from __future__ import annotations

from rich.console import Console
from rich.style import Style
from rich.text import Text
from rich.theme import Theme

# ── Brand ─────────────────────────────────────────────────────────────────────
BRAND       = "#7c3aed"   # violet
BRAND_LIGHT = "#a78bfa"   # light violet

# ── Fit level colours ─────────────────────────────────────────────────────────
FIT_COLORS = {
    "Perfect":  "#00e5b0",  # bright cyan-green
    "Good":     "#86efac",  # soft green
    "Marginal": "#fbbf24",  # warm amber
    "TooTight": "#f87171",  # soft red
}

# ── Status colours (doctor command) ──────────────────────────────────────────
STATUS_OK   = "#10b981"   # emerald
STATUS_WARN = "#f59e0b"   # amber
STATUS_MISS = "#f87171"   # soft red
STATUS_ERR  = "#ef4444"   # red

TINILLM_THEME = Theme(
    {
        "header":          f"bold {BRAND_LIGHT}",
        "label":           "bold #06b6d4",
        "value":           "white",
        "dim":             "dim white",
        "brand":           f"bold {BRAND}",
        "fit.perfect":     f"bold {FIT_COLORS['Perfect']}",
        "fit.good":        f"bold {FIT_COLORS['Good']}",
        "fit.marginal":    f"bold {FIT_COLORS['Marginal']}",
        "fit.tootight":    f"bold {FIT_COLORS['TooTight']}",
        "status.ok":       f"bold {STATUS_OK}",
        "status.warn":     f"bold {STATUS_WARN}",
        "status.miss":     f"bold {STATUS_MISS}",
        "status.err":      f"bold {STATUS_ERR}",
        "backend.cuda":    "bold green",
        "backend.rocm":    "bold yellow",
        "backend.metal":   "bold cyan",
        "backend.vulkan":  "bold blue",
        "backend.directx": "bold magenta",
    }
)

# ── ASCII banner ───────────────────────────────────────────────────────────────
_BANNER = r"""
  ████████╗██╗███╗   ██╗██╗██╗     ██╗     ███╗   ███╗
     ██╔══╝██║████╗  ██║██║██║     ██║     ████╗ ████║
     ██║   ██║██╔██╗ ██║██║██║     ██║     ██╔████╔██║
     ██║   ██║██║╚██╗██║██║██║     ██║     ██║╚██╔╝██║
     ██║   ██║██║ ╚████║██║███████╗███████╗██║ ╚═╝ ██║
     ╚═╝   ╚═╝╚═╝  ╚═══╝╚═╝╚══════╝╚══════╝╚═╝     ╚═╝"""


def render_banner(console: Console) -> None:
    """Print the tinillm ASCII art banner with tagline and version."""
    from tinillm import __version__
    t = Text(_BANNER, style=f"bold {BRAND}")
    console.print(t)
    console.print(
        f"\n  [dim]Know what LLMs your hardware can run — locally, instantly.[/]"
        f"  [dim]v{__version__}[/]\n"
    )


def render_header(console: Console, title: str, subtitle: str = "") -> None:
    """Print a distinctive violet brand-bar header.

    Example output:
        ▌ tinillm scan       Hardware Report
    """
    bar = Text()
    bar.append("  ", style=f"on {BRAND}")       # violet left bar
    bar.append(f" {title}", style="bold white")
    if subtitle:
        bar.append(f"   {subtitle}", style="dim white")
    console.print()
    console.print(bar)
    console.print()


def fit_style(fit_value: str) -> str:
    """Return a Rich markup style tag for the given FitLevel string."""
    mapping = {
        "Perfect":  "fit.perfect",
        "Good":     "fit.good",
        "Marginal": "fit.marginal",
        "TooTight": "fit.tootight",
    }
    return mapping.get(fit_value, "white")


def backend_style(backend: str) -> str:
    mapping = {
        "CUDA":    "backend.cuda",
        "ROCm":    "backend.rocm",
        "Metal":   "backend.metal",
        "Vulkan":  "backend.vulkan",
        "DirectX": "backend.directx",
    }
    return mapping.get(backend, "white")
