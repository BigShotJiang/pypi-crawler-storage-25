"""tinillm — local LLM hardware capability tool.

`tinillm` launches an interactive REPL. All features (scan, models, run,
recommend, doctor, memory, remember, forget) are invoked as slash commands
from inside the REPL — there are no shell-level subcommands.
"""

from __future__ import annotations

import click

from tinillm import __version__


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(__version__, "-V", "--version", prog_name="tinillm")
def app() -> None:
    """Know what LLMs your hardware can run — locally, instantly.

    Run `tinillm` with no arguments to launch the interactive tool.
    Inside it, use /scan, /models, /run, /recommend, /ask, /help, /exit, and more.
    """
    from tinillm.repl import run_repl
    run_repl()


if __name__ == "__main__":
    app()
