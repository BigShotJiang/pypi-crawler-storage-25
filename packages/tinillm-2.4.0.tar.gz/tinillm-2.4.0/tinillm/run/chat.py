"""Interactive chat REPL with web_search tool support."""
from __future__ import annotations

import sys
from pathlib import Path

import click
from rich.markdown import Markdown
from rich.markup import escape
from rich.progress import BarColumn, Progress, TimeRemainingColumn

from tinillm.memory import recall as _recall
from tinillm.memory import writer as _mem_writer
from tinillm.memory.paths import memory_disabled
from tinillm.run.tools import TOOLS, execute_tool
from tinillm.run.agent_chat import run_agent_chat  # re-export for /chat slash command

__all__ = ["run_chat", "run_agent_chat"]


_MEMORY_MARKER = "# tinillm memory"


def _upsert_system(messages: list[dict], block_text: str) -> None:
    """Ensure ``messages[0]`` holds the memory block as a system message.

    If the block is empty, any existing tinillm-memory system message is
    stripped. Other system messages (from the model or user config) are
    left alone — we only touch ones we previously inserted.
    """
    has_mem_system = (
        messages
        and messages[0].get("role") == "system"
        and isinstance(messages[0].get("content"), str)
        and messages[0]["content"].lstrip().startswith(_MEMORY_MARKER)
    )
    stripped = block_text.strip()
    if not stripped:
        if has_mem_system:
            messages.pop(0)
        return
    system_msg = {"role": "system", "content": stripped}
    if has_mem_system:
        messages[0] = system_msg
    else:
        messages.insert(0, system_msg)


def _ensure_model_ready(tag: str, console) -> bool:
    """Check if the model is installed; offer to pull it if not.

    Returns True when the model is ready, False if the user declined or pull failed.
    """
    import ollama

    # Check what's already installed
    try:
        installed = {m.model for m in ollama.list().models}
        base = tag.split(":")[0]
        if tag in installed or any(
            m == tag or m.startswith(base + ":") for m in installed
        ):
            return True
    except Exception:
        # Can't verify — proceed and let the chat handle any error
        return True

    # Model not found locally — ask before downloading
    console.print(
        f"\n[yellow]Model [cyan]{escape(tag)}[/cyan] is not downloaded yet.[/yellow]"
    )
    try:
        if not click.confirm("  Download it now?", default=True):
            return False
    except click.exceptions.Abort:
        return False

    # Pull with a live progress bar
    try:
        last_status = ""
        with Progress(
            "[progress.description]{task.description}",
            BarColumn(),
            "[progress.percentage]{task.percentage:>3.0f}%",
            TimeRemainingColumn(),
            console=console,
            transient=True,
        ) as bar:
            task_id = bar.add_task(f"[dim]Pulling {tag}…[/dim]", total=100)

            for chunk in ollama.pull(tag, stream=True):
                status = getattr(chunk, "status", "") or ""
                total = getattr(chunk, "total", None)
                completed = getattr(chunk, "completed", None)

                if status and status != last_status:
                    last_status = status
                    bar.update(task_id, description=f"[dim]{escape(status)}[/dim]")

                if total and completed:
                    bar.update(task_id, completed=int(completed / total * 100))

        console.print(f"[green]✓[/green]  {escape(tag)} downloaded successfully.\n")
        return True

    except Exception as e:
        console.print(f"[bold red]Pull failed:[/] {escape(str(e))}")
        return False


def run_chat(tag: str, console) -> None:
    """Start an interactive chat session with the given model tag.

    Ensures the model is downloaded first; registers web_search as a tool
    and falls back gracefully for models that don't support tool calling.
    """
    try:
        import ollama
    except ImportError:
        console.print("[bold red]ollama package not found.[/] Run: pip install tinillm")
        sys.exit(1)

    if not _ensure_model_ready(tag, console):
        return

    messages: list[dict] = []
    tools_enabled = True  # set to False if model doesn't support tools
    cwd = Path.cwd()
    mem_on = not memory_disabled()

    mem_note = "" if not mem_on else "  [dim]· memory on[/dim]"
    console.print(
        f"\n[bold]Chat with [cyan]{escape(tag)}[/cyan][/bold]  "
        f"[dim](web_search enabled · type 'exit' to quit){mem_note}[/dim]\n"
    )

    try:
        while True:
            try:
                user_input = click.prompt(
                    "You", prompt_suffix=" > ", default="", show_default=False
                ).strip()
            except click.exceptions.Abort:
                break

            if not user_input:
                continue
            if user_input.lower() in ("exit", "quit", "/bye"):
                break

            messages.append({"role": "user", "content": user_input})

            # Rebuild the memory system message from recall every turn —
            # keyword tier depends on the latest user message. Must happen
            # before checkpoint is captured so rollback indices stay valid.
            if mem_on:
                block_text = _recall.assemble_memory_block(
                    cwd=cwd, recent_turns=messages
                )
                _upsert_system(messages, block_text)

            # Snapshot length so we can cleanly roll back the whole turn on error.
            checkpoint = len(messages)

            # Agentic inner loop: keep going while model requests tool calls
            turn_assistant_text = ""
            while True:
                kwargs: dict = {"model": tag, "messages": messages}
                if tools_enabled:
                    kwargs["tools"] = TOOLS

                try:
                    with console.status("[dim]Thinking...[/dim]"):
                        response = ollama.chat(**kwargs)
                except ollama.ResponseError as e:
                    err = str(e).lower()
                    if ("does not support tools" in err or "tool" in err) and tools_enabled:
                        tools_enabled = False
                        console.print("[dim]ℹ  web_search not available for this model[/dim]")
                        continue  # retry the same turn without tools
                    console.print(f"[bold red]Error:[/] {escape(str(e))}")
                    del messages[checkpoint:]
                    break
                except Exception as e:
                    console.print(f"[bold red]Error:[/] {escape(str(e))}")
                    del messages[checkpoint:]
                    break

                msg = response.message
                messages.append({
                    "role": msg.role,
                    "content": msg.content or "",
                    "tool_calls": msg.tool_calls,
                })

                if msg.tool_calls:
                    for tc in msg.tool_calls:
                        fn = tc.function
                        args = fn.arguments if isinstance(fn.arguments, dict) else {}
                        query = args.get("query", "")
                        console.print(f"[dim]🔍  Searching: {escape(query)}[/dim]")
                        result = execute_tool(fn.name, args)
                        messages.append({"role": "tool", "content": result})
                    # loop again — model incorporates results and produces final text
                else:
                    content = msg.content or ""
                    console.print("\n[bold]Assistant:[/]")
                    console.print(Markdown(content))
                    console.print()
                    turn_assistant_text = content
                    break

            # Post-turn: enqueue heuristic extraction on the background thread.
            if mem_on and user_input:
                _mem_writer.ingest(user_input, turn_assistant_text, cwd=cwd)

    except KeyboardInterrupt:
        console.print("\n[dim]Session ended.[/dim]")
