"""Rich rendering for `tinillm run` — interactive picker and fit warnings."""

from __future__ import annotations

from rich.console import Console
from rich.table import Table
from rich.text import Text
from rich import box

from tinillm.hardware.types import SystemSpecs
from tinillm.models.database import RealModel
from tinillm.analyzer.types import ModelFit, FitLevel
from tinillm.render.styles import fit_style, BRAND


def _hardware_line(specs: SystemSpecs) -> str:
    """One-line hardware summary for the picker header."""
    if specs.gpus:
        best_gpu = max(specs.gpus, key=lambda g: g.vram_gb)
        gpu_str = f"{best_gpu.name} ({best_gpu.vram_gb:.0f} GB VRAM)"
    else:
        gpu_str = "CPU-only"
    return f"{gpu_str} · {specs.total_ram_gb:.0f} GB RAM"


def render_picker_table(
    console: Console,
    specs: SystemSpecs,
    entries: list[tuple[int, RealModel, ModelFit]],
) -> None:
    """Print a numbered table of compatible models for interactive selection."""
    hw_line = _hardware_line(specs)
    console.print(f"\n[bold white]Hardware:[/] {hw_line}\n")

    table = Table(
        box=box.SIMPLE_HEAD,
        show_header=True,
        header_style="bold white",
        padding=(0, 1),
    )
    table.add_column("#", style="dim", width=4)
    table.add_column("Model", min_width=22)
    table.add_column("Provider", min_width=14)
    table.add_column("Fit", min_width=9)
    table.add_column("Quant", min_width=9)
    table.add_column("Speed", min_width=9)

    for idx, model, fit in entries:
        fit_val = fit.fit_level.value
        style = fit_style(fit_val)
        quant_str = fit.best_quant.value if fit.best_quant else "—"
        speed_str = f"{fit.tokens_per_sec:.0f} t/s" if fit.tokens_per_sec else "—"
        table.add_row(
            str(idx),
            f"[bold white]{model.display_name}[/]",
            model.provider,
            f"[{style}]{fit_val}[/]",
            Text(quant_str, style=f"bold {BRAND}"),
            speed_str,
        )

    console.print(table)


def render_fit_warning(
    console: Console,
    model: RealModel,
    fit: ModelFit,
    budget_gb: float,
) -> None:
    """Print a Marginal or TooTight fit warning."""
    fit_val = fit.fit_level.value
    style = fit_style(fit_val)
    mem_str = f"{fit.mem_required_gb:.1f} GB" if fit.mem_required_gb else "unknown"

    if fit.fit_level == FitLevel.MARGINAL:
        console.print(
            f"[{style}]Warning:[/] {model.display_name} is a marginal fit "
            f"({mem_str} needed, {budget_gb:.1f} GB available). "
            "Performance may be degraded."
        )
    elif fit.fit_level == FitLevel.TOO_TIGHT:
        console.print(
            f"[{style}]Error:[/] {model.display_name} requires {mem_str} "
            f"but only {budget_gb:.1f} GB is available. "
            "Use --force to run anyway."
        )
