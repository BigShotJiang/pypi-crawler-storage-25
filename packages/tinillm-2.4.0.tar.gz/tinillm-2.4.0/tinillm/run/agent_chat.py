"""Agent chat shim — kept for backwards-compat with `/chat`, tests, and direct
callers. The real implementation now lives in ``tinillm.run.chat_session`` so
the top-level REPL can own a ``ChatSession`` across free-text and slash input.

Do not add new logic here. Extend ``ChatSession`` instead.
"""
from __future__ import annotations

import click
from rich.console import Console

from tinillm.run.chat_session import ChatSession, ChatSessionError, IN_CHAT_COMMANDS


# Re-exports so existing tests that patch ``tinillm.run.agent_chat.<name>``
# keep working even though the definitions live in chat_session now.
from tinillm.run.chat_session import (  # noqa: F401
    _run_model_loop,
    _handle_in_chat,
    _brief_args,
    _mem_writer_ingest,
    _memory_disabled as memory_disabled_cached,
)


def run_agent_chat(
    model_tag: str | None = None,
    *,
    resume_id: str | None = None,
    mode: str | None = None,
    auto_confirm: bool = False,
) -> None:
    """Start the tool-using agent chat session.

    Thin wrapper: builds a ``ChatSession`` and drives its own input loop.
    Preserved as a standalone entry point so ``/chat`` and existing tests keep
    working without a tinillm-repl harness.
    """
    console = Console(highlight=False)
    try:
        session = ChatSession.create(
            model_tag=model_tag,
            resume_id=resume_id,
            mode=mode,
            auto_confirm=auto_confirm,
            console=console,
        )
    except ChatSessionError as e:
        console.print(f"[bold red]{e}[/]")
        if "ollama package" in str(e):
            import sys
            sys.exit(1)
        return

    session.print_banner()

    try:
        while True:
            try:
                user_input = click.prompt(
                    "│", prompt_suffix=" ", default="", show_default=False
                ).strip()
            except click.exceptions.Abort:
                break
            if not user_input:
                continue
            if user_input.lower() in ("exit", "quit", "/exit", "/bye"):
                break

            if ChatSession.is_in_chat_slash(user_input):
                session.handle_slash(user_input)
                continue

            session.handle_user_turn(user_input)
    except KeyboardInterrupt:
        console.print("\n[dim]Session ended.[/dim]")
