"""Web search tool definition and execution for tinillm run chat sessions."""
from __future__ import annotations

_DDG_TIMEOUT = 10        # seconds before DuckDuckGo request gives up
_MAX_SEARCH_RESULTS = 5  # number of results to fetch and return to the model

WEB_SEARCH_TOOL = {
    "type": "function",
    "function": {
        "name": "web_search",
        "description": (
            "Search the web for current information, GitHub repos, documentation, "
            "news, or any online content. Use whenever asked to find something online."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "The search query"}
            },
            "required": ["query"],
        },
    },
}

TOOLS = [WEB_SEARCH_TOOL]


def execute_tool(name: str, args: dict) -> str:
    """Dispatch a tool call by name and return its string result."""
    if name == "web_search":
        return _web_search(args.get("query", ""))
    return f"Unknown tool: {name}"


def _web_search(query: str, max_results: int = _MAX_SEARCH_RESULTS) -> str:
    try:
        from ddgs import DDGS
        with DDGS(timeout=_DDG_TIMEOUT) as ddgs:
            hits = list(ddgs.text(query, max_results=max_results))
        if not hits:
            return "No results found."
        return "\n\n".join(
            f"{i}. {r['title']}\n   {r['href']}\n   {r['body']}"
            for i, r in enumerate(hits, 1)
        )
    except Exception as e:
        return f"Search error: {e}"
