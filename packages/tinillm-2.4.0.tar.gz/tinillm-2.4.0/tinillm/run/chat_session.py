"""Agent chat session — state holder so one session can span multiple prompts.

Extracted from ``agent_chat.py`` so the top-level REPL (``tinillm.repl``) can
own a single ``ChatSession`` and feed it one user turn at a time, interleaving
with slash-command dispatch. ``run_agent_chat`` in ``agent_chat.py`` is now a
thin shim that builds a ``ChatSession`` and drives its own input loop.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path

from rich.console import Console
from rich.markdown import Markdown
from rich.markup import escape

from tinillm.agent import (
    PermissionDenied,
    PermissionEnforcer,
    TOOL_SPECS,
    ToolContext,
    UsageTracker,
    Workspace,
    dispatch,
    rewind_messages,
)
from tinillm.agent import hooks as _hooks
from tinillm.agent import recovery as _recovery
from tinillm.agent.config import load as _load_config
from tinillm.agent.sandbox import detect as _detect_sandbox
from tinillm.agent.plan_mode import (
    PlanState,
    enter as _plan_enter,
    exit_ as _plan_exit,
    looks_like_final_plan as _looks_like_final_plan,
    system_addendum as _plan_addendum,
)
from tinillm.agent.prompts import assemble_system_prompt
from tinillm.agent.session import load_session, new_session
from tinillm.agent.session.compact import apply_summary, build_compact_request
from tinillm.agent.session.store import SessionStore


IN_CHAT_COMMANDS = {
    "/plan", "/plan-off", "/compact", "/summary", "/rewind",
    "/diff", "/cost", "/permissions", "/tasks", "/load", "/help",
}


class ChatSessionError(RuntimeError):
    """Raised by ChatSession.create() when setup cannot proceed.

    Callers get a single type to catch regardless of whether the failure was a
    missing model tag, bad permission mode, or a missing resume_id — the
    message is already user-facing.
    """


@dataclass
class ChatSession:
    """Stateful agent chat. One instance per user session."""

    ollama: object                       # the ``ollama`` module (duck-typed for tests)
    model_tag: str
    ctx: ToolContext
    messages: list[dict]
    store: SessionStore
    session_id: str
    plan: PlanState
    usage: UsageTracker
    mem_on: bool
    console: Console

    # ── Construction ────────────────────────────────────────────────────────

    @classmethod
    def create(
        cls,
        model_tag: str | None = None,
        *,
        resume_id: str | None = None,
        mode: str | None = None,
        auto_confirm: bool = False,
        console: Console | None = None,
    ) -> "ChatSession":
        """Build a ready-to-run ChatSession. Raises ChatSessionError on setup
        failure so the REPL can render the message and stay alive."""
        try:
            import ollama
        except ImportError:
            raise ChatSessionError("ollama package not found — run: pip install tinillm")

        console = console or Console(highlight=False)
        cfg = _load_config()
        chosen_mode = mode or cfg.permission_mode
        tag = model_tag or cfg.model
        if not tag:
            raise ChatSessionError(
                "No model specified — pass MODEL_TAG or set model in .tinillmrc."
            )

        workspace = Workspace(Path.cwd())
        enforcer = PermissionEnforcer()
        try:
            enforcer.set_mode(chosen_mode)
        except ValueError as e:
            raise ChatSessionError(str(e)) from e
        if cfg.allowed_tools:
            enforcer.allowed_tools = set(cfg.allowed_tools)
        enforcer.denied_tools = set(cfg.denied_tools)
        enforcer.allow_patterns = list(cfg.allow_patterns)
        enforcer.deny_patterns = list(cfg.deny_patterns)

        # Sandbox detection — warn once on Linux if bash will run unsandboxed.
        sandbox = _detect_sandbox() if cfg.sandbox_enabled else None
        if cfg.sandbox_enabled and sandbox is not None and not sandbox.available:
            import platform as _pf
            if _pf.system() == "Linux":
                console.print(
                    "[yellow]⚠  sandbox disabled: install bubblewrap "
                    "(`apt install bubblewrap`) to confine bash to the workspace.[/]"
                )

        ctx = ToolContext(
            workspace=workspace,
            enforcer=enforcer,
            console=console,
            auto_confirm=auto_confirm,
            sandbox=sandbox,
            sandbox_allow_network=cfg.sandbox_allow_network,
        )

        # Session: resume or start fresh.
        if resume_id:
            try:
                sess = load_session(resume_id)
                messages = list(sess.messages)
            except FileNotFoundError as e:
                raise ChatSessionError(str(e)) from e
        else:
            sess = new_session(tag, cwd=Path.cwd())
            messages = []
        store = SessionStore(sess)

        # System prompt: defaults + TINILLM.md (if present).
        if not messages or messages[0].get("role") != "system":
            sys_prompt = assemble_system_prompt(Path.cwd())
            messages.insert(0, {"role": "system", "content": sys_prompt})
            # Resumed sessions need the prompt at the *start* of the JSONL.
            if resume_id:
                store.replace_all(messages)
            else:
                store.append(messages[0])

        return cls(
            ollama=ollama,
            model_tag=tag,
            ctx=ctx,
            messages=messages,
            store=store,
            session_id=sess.id,
            plan=PlanState(auto_accept=cfg.auto_accept_plan),
            usage=UsageTracker(),
            mem_on=not _memory_disabled(),
            console=console,
        )

    # ── Input routing ───────────────────────────────────────────────────────

    def print_banner(self) -> None:
        self.console.print(
            f"\n[bold]Agent chat · [cyan]{escape(self.model_tag)}[/cyan][/bold]  "
            f"[dim]mode={self.ctx.enforcer.mode.value} · session={self.session_id}[/dim]"
        )
        self.console.print(
            "  [dim]in-chat: /plan /compact /rewind /diff /cost /tasks /help[/dim]\n"
        )

    @staticmethod
    def is_in_chat_slash(line: str) -> bool:
        """True if ``line`` starts with an in-chat slash command we handle."""
        if not line.startswith("/"):
            return False
        head = line.split(maxsplit=1)[0]
        return head in IN_CHAT_COMMANDS

    def handle_slash(self, line: str) -> None:
        """Dispatch an in-chat slash command (``/plan``, ``/cost``, etc.)."""
        new_tag = _handle_in_chat(
            line, self.ctx, self.messages, self.store,
            self.plan, self.usage, self.model_tag, self.ollama,
        )
        if new_tag:
            self.model_tag = new_tag

    def handle_user_turn(self, user_input: str) -> str:
        """Process one natural-language user turn. Returns the assistant text
        (empty string if the pre_prompt hook cancelled)."""
        # pre_prompt hook — may rewrite or cancel the user's input.
        hook = _hooks.run_hook("pre_prompt", {"prompt": user_input})
        if not hook.ok:
            self.console.print(f"[yellow]pre_prompt hook blocked: {hook.reason}[/]")
            return ""
        user_input = hook.payload.get("prompt", user_input)

        user_msg = {"role": "user", "content": user_input}
        self.messages.append(user_msg)
        self.store.append(user_msg)
        checkpoint = len(self.messages)

        assistant_text = _run_model_loop(
            self.ollama, self.model_tag, self.messages, self.store,
            self.ctx, self.plan, self.usage, self.console, checkpoint,
        )

        if self.mem_on and user_input:
            _mem_writer_ingest(user_input, assistant_text)
        return assistant_text


# ── Model loop ───────────────────────────────────────────────────────────────

def _run_model_loop(ollama, model_tag, messages, store, ctx, plan, usage, console, checkpoint):
    """Inner agentic loop: call model, run any requested tools, repeat.

    Plan-approval autonomy: when the auto-accept branch fires, ``ctx.auto_confirm``
    is flipped to True so the model can execute the approved plan without
    per-command confirmation prompts (including destructive-bash patterns).
    The original value is restored before returning control to the user, so
    autonomy is scoped to a single approved plan.
    """
    original_auto_confirm = ctx.auto_confirm
    turn_text = ""
    tools_enabled = True
    try:
        while True:
            kwargs = {"model": model_tag, "messages": messages}
            if tools_enabled:
                kwargs["tools"] = TOOL_SPECS
            try:
                with console.status("[dim]Thinking...[/dim]"):
                    response = ollama.chat(**kwargs)
            except Exception as e:
                recipe = _recovery.match(str(e))
                if recipe:
                    console.print(f"[yellow]{recipe.hint}[/]")
                    if recipe.label == "model-no-tools" and tools_enabled:
                        tools_enabled = False
                        continue
                console.print(f"[bold red]Error:[/] {escape(str(e))}")
                # Roll back so /resume can't replay a half-finished turn.
                del messages[checkpoint:]
                store.replace_all(messages)
                return turn_text

            usage.record(response)
            msg = response.message
            entry = {
                "role": msg.role,
                "content": msg.content or "",
                "tool_calls": getattr(msg, "tool_calls", None),
            }
            messages.append(entry)
            store.append(entry)

            tool_calls = getattr(msg, "tool_calls", None)
            if tool_calls:
                for tc in tool_calls:
                    name = tc.function.name
                    args = tc.function.arguments if isinstance(tc.function.arguments, dict) else {}
                    pre = _hooks.run_hook("pre_tool", {"name": name, "args": args})
                    if not pre.ok:
                        result = f"pre_tool hook blocked: {pre.reason}"
                    else:
                        try:
                            console.print(f"[dim]⚙  {name}({_brief_args(args)})[/dim]")
                            result = dispatch(ctx, name, pre.payload.get("args", args))
                        except PermissionDenied as e:
                            result = f"permission denied: {e}"
                    _hooks.run_hook("post_tool", {"name": name, "result": result})
                    tool_msg = {"role": "tool", "content": result}
                    messages.append(tool_msg)
                    store.append(tool_msg)
                continue

            turn_text = msg.content or ""
            console.print("\n[bold]Assistant:[/]")
            console.print(Markdown(turn_text))
            console.print()

            # Auto-accept plan: exit plan mode, grant blanket autonomy for the
            # execution phase, and re-prompt with a synthetic approval message.
            if (
                plan.active
                and plan.auto_accept
                and _looks_like_final_plan(turn_text)
            ):
                _plan_exit(ctx.enforcer, plan)
                addendum = _plan_addendum()
                messages[:] = [
                    m for m in messages
                    if not (m.get("role") == "system" and m.get("content") == addendum)
                ]
                approval = {
                    "role": "user",
                    "content": "The plan is approved. Execute the actions in order.",
                }
                messages.append(approval)
                store.replace_all(messages)
                ctx.auto_confirm = True
                console.print(
                    f"[green]plan auto-accepted[/] — executing in "
                    f"{ctx.enforcer.mode.value} mode "
                    f"[dim](auto-confirming tool calls until control returns)[/].\n"
                )
                continue

            return turn_text
    finally:
        ctx.auto_confirm = original_auto_confirm


# ── In-chat slash commands ───────────────────────────────────────────────────

def _handle_in_chat(line, ctx, messages, store, plan, usage, model_tag, ollama):
    """Run one in-chat slash command. Returns a new model tag if /load was
    used, else None."""
    console = ctx.console
    tokens = line.split()
    cmd = tokens[0]
    if cmd == "/plan":
        if plan.active:
            console.print("[dim]already in plan mode.[/]")
            return None
        _plan_enter(ctx.enforcer, plan)
        messages.append({"role": "system", "content": _plan_addendum()})
        store.replace_all(messages)
        console.print(
            "[yellow]plan mode ON[/] — read-only. "
            "Describe your goal; the model will produce a numbered plan."
        )
    elif cmd == "/plan-off":
        if not plan.active:
            console.print("[dim]not in plan mode.[/]")
            return None
        _plan_exit(ctx.enforcer, plan)
        addendum = _plan_addendum()
        before = len(messages)
        messages[:] = [
            m for m in messages
            if not (m.get("role") == "system" and m.get("content") == addendum)
        ]
        if len(messages) != before:
            store.replace_all(messages)
        console.print(f"[green]plan mode OFF[/] — mode restored to {ctx.enforcer.mode.value}.")
    elif cmd == "/cost":
        console.print(usage.render())
    elif cmd == "/permissions":
        if len(tokens) >= 2:
            try:
                ctx.enforcer.set_mode(tokens[1])
                console.print(f"[green]mode → {ctx.enforcer.mode.value}[/]")
            except ValueError as e:
                console.print(f"[bold red]{e}[/]")
        else:
            console.print(f"current mode: [bold]{ctx.enforcer.mode.value}[/bold]")
    elif cmd == "/tasks":
        console.print(ctx.todos.render())
    elif cmd == "/diff":
        console.print(ctx.snapshots.diff())
    elif cmd == "/rewind":
        try:
            turns = int(tokens[1]) if len(tokens) >= 2 else 1
        except ValueError:
            console.print("[bold red]Usage:[/] /rewind [N]  (N must be an integer)")
            return None
        new_msgs = rewind_messages(messages, turns=turns)
        messages[:] = new_msgs
        store.replace_all(new_msgs)
        console.print(f"[green]rewound {turns} turn(s). {len(messages)} messages remaining.[/]")
    elif cmd in ("/compact", "/summary"):
        request = build_compact_request(messages)
        try:
            with console.status("[dim]Compacting...[/dim]"):
                resp = ollama.chat(model=model_tag, messages=request)
        except Exception as e:
            console.print(f"[bold red]compact failed:[/] {e}")
            return None
        summary = resp.message.content or ""
        if cmd == "/summary":
            console.print(Markdown(summary))
            return None
        new_msgs, result = apply_summary(messages, summary)
        messages[:] = new_msgs
        store.replace_all(new_msgs)
        console.print(
            f"[green]compacted: dropped {result.dropped}, kept {result.kept} tail messages.[/]"
        )
    elif cmd == "/load":
        if len(tokens) < 2:
            console.print("[bold red]Usage:[/] /load <model-tag>")
            return None
        new_tag = tokens[1]
        from tinillm.agent import settings as _s
        _s.save(model=new_tag)
        console.print(
            f"[green]✓[/] model → [bold]{new_tag}[/bold]  "
            f"[dim](saved to {_s.path()})[/dim]"
        )
        return new_tag
    elif cmd == "/help":
        console.print("  [bold]/plan[/] · [bold]/plan-off[/] · [bold]/compact[/] · [bold]/summary[/]")
        console.print("  [bold]/rewind [n][/] · [bold]/diff[/] · [bold]/cost[/] · [bold]/tasks[/]")
        console.print("  [bold]/load <model>[/] · [bold]/permissions [mode][/]")
    return None


# ── Helpers ──────────────────────────────────────────────────────────────────

def _brief_args(args: dict) -> str:
    pieces = []
    for k, v in args.items():
        s = repr(v)
        if len(s) > 50:
            s = s[:47] + "…"
        pieces.append(f"{k}={s}")
    return ", ".join(pieces)


def _memory_disabled() -> bool:
    from tinillm.memory.paths import memory_disabled
    return memory_disabled()


def _mem_writer_ingest(user_input: str, assistant_text: str) -> None:
    from tinillm.memory import writer
    writer.ingest(user_input, assistant_text, cwd=Path.cwd())
