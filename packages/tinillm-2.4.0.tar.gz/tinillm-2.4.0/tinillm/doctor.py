"""tinillm doctor — parallel system health check."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass


@dataclass
class CheckResult:
    status: str       # OK | WARN | MISS | ERR
    label: str
    detail: str
    hint: str = ""


def _check_hardware() -> CheckResult:
    try:
        from tinillm.hardware.detect import detect
        specs = detect()
        ram = f"{specs.total_ram_gb:.0f} GB RAM"
        gpu = f"· {specs.gpus[0].name}" if specs.gpus else "· CPU only"
        return CheckResult("OK", "Hardware", f"{ram}  {gpu}")
    except Exception as e:
        return CheckResult("ERR", "Hardware", f"Detection failed: {e}")


def _check_ollama() -> CheckResult:
    try:
        import ollama
        response = ollama.list()
        count = len(response.models)
        try:
            import subprocess
            v = subprocess.run(["ollama", "--version"], capture_output=True, text=True, timeout=3)
            version = v.stdout.strip().split()[-1] if v.returncode == 0 else "unknown"
        except Exception:
            version = "running"
        return CheckResult("OK", "Ollama", f"{version}  ·  {count} model(s) installed")
    except Exception:
        return CheckResult(
            "ERR", "Ollama", "Not running",
            hint="Start with: ollama serve"
        )


def _check_models_installed() -> CheckResult:
    try:
        import ollama
        models = ollama.list().models
        if not models:
            return CheckResult(
                "WARN", "LLM models", "No models installed",
                hint="Pull one: ollama pull qwen2.5:7b"
            )
        names = ", ".join(m.model for m in models[:3])
        extra = f" +{len(models)-3} more" if len(models) > 3 else ""
        return CheckResult("OK", "LLM models", f"{names}{extra}")
    except Exception:
        return CheckResult("MISS", "LLM models", "Ollama unavailable")


def _check_memory() -> CheckResult:
    try:
        from tinillm.memory.paths import (
            FEEDBACK_MD,
            GLOBAL_MEMORY_MD,
            MEMORY_ROOT,
            USER_MD,
            memory_disabled,
        )

        if memory_disabled():
            return CheckResult(
                "WARN", "Memory", "Disabled",
                hint="Unset TINILLM_MEMORY or remove DISABLED sentinel"
            )
        if not MEMORY_ROOT.exists():
            return CheckResult(
                "WARN", "Memory", "Not initialised",
                hint="Start `tinillm` once to auto-create"
            )

        total_bytes = 0
        total_entries = 0
        for path in [GLOBAL_MEMORY_MD, USER_MD, FEEDBACK_MD]:
            if path.exists():
                try:
                    total_bytes += path.stat().st_size
                    text = path.read_text(encoding="utf-8")
                    total_entries += sum(
                        1 for ln in text.splitlines() if ln.lstrip().startswith("-")
                    )
                except OSError:
                    pass
        for sub in ("rules", "lore"):
            d = MEMORY_ROOT / sub
            if d.exists():
                for p in d.glob("*.md"):
                    total_entries += 1
                    try:
                        total_bytes += p.stat().st_size
                    except OSError:
                        pass

        kb = total_bytes / 1024
        detail = f"{total_entries} entries  ·  {kb:.1f} KB"
        return CheckResult("OK", "Memory", detail)
    except Exception as e:
        return CheckResult("ERR", "Memory", str(e))


def _check_sandbox() -> CheckResult:
    try:
        import platform
        from tinillm.agent.sandbox import detect
        backend = detect()
        system = platform.system()
        if backend.available and backend.name == "bwrap":
            return CheckResult(
                "OK", "Sandbox", "bwrap — bash confined to workspace, network off"
            )
        if system == "Linux":
            return CheckResult(
                "WARN", "Sandbox", "Unavailable — bash runs on the host filesystem",
                hint="Install: apt install bubblewrap"
            )
        return CheckResult(
            "WARN", "Sandbox", f"N/A on {system} — workspace boundary enforced in-process only"
        )
    except Exception as e:
        return CheckResult("ERR", "Sandbox", str(e))


def _check_disk() -> CheckResult:
    try:
        from pathlib import Path
        import shutil

        total, used, free = shutil.disk_usage(Path.home())
        free_gb = free / 1_073_741_824
        if free_gb < 2:
            return CheckResult(
                "WARN", "Disk space",
                f"{free_gb:.1f} GB free — low, may affect model downloads"
            )
        return CheckResult("OK", "Disk space", f"{free_gb:.1f} GB free")
    except Exception:
        return CheckResult("WARN", "Disk space", "Could not check")


_CHECKS = [
    _check_hardware,
    _check_ollama,
    _check_models_installed,
    _check_memory,
    _check_sandbox,
    _check_disk,
]


def run_doctor() -> None:
    from rich.console import Console
    from rich.table import Table
    from rich import box
    from tinillm.render.styles import (
        STATUS_OK, STATUS_WARN, STATUS_MISS, STATUS_ERR,
        TINILLM_THEME, render_header,
    )

    console = Console(theme=TINILLM_THEME, highlight=False)
    render_header(console, "tinillm doctor", "System Health Check")

    results: dict[int, CheckResult] = {}
    with ThreadPoolExecutor(max_workers=len(_CHECKS)) as pool:
        futures = {pool.submit(fn): i for i, fn in enumerate(_CHECKS)}
        with console.status("[dim]Running checks...[/dim]"):
            for future in as_completed(futures):
                idx = futures[future]
                try:
                    results[idx] = future.result()
                except Exception as e:
                    results[idx] = CheckResult("ERR", "Unknown", str(e))

    ordered = [results[i] for i in range(len(_CHECKS))]

    table = Table(box=box.SIMPLE_HEAD, show_header=False, padding=(0, 1))
    table.add_column("Icon", width=4)
    table.add_column("Label", style="bold white", min_width=16)
    table.add_column("Detail")
    table.add_column("Hint", style="dim")

    status_styles = {
        "OK":   (f"bold {STATUS_OK}",   "✓"),
        "WARN": (f"bold {STATUS_WARN}", "⚠"),
        "MISS": (f"bold {STATUS_MISS}", "✗"),
        "ERR":  (f"bold {STATUS_ERR}",  "✗"),
    }

    counts = {"OK": 0, "WARN": 0, "MISS": 0, "ERR": 0}
    for r in ordered:
        style, icon = status_styles.get(r.status, ("dim", "?"))
        counts[r.status] = counts.get(r.status, 0) + 1
        table.add_row(
            f"[{style}]{icon}[/]",
            r.label,
            r.detail,
            r.hint,
        )

    console.print(table)

    parts = []
    if counts["OK"]:
        parts.append(f"[bold {STATUS_OK}]{counts['OK']} OK[/]")
    if counts["WARN"]:
        parts.append(f"[bold {STATUS_WARN}]{counts['WARN']} WARN[/]")
    if counts["MISS"]:
        parts.append(f"[bold {STATUS_MISS}]{counts['MISS']} MISS[/]")
    if counts["ERR"]:
        parts.append(f"[bold {STATUS_ERR}]{counts['ERR']} ERR[/]")

    console.print("  " + "  ·  ".join(parts) + "\n")
