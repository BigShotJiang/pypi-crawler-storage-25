"""Memory file I/O — frontmatter parser, atomic writes, file locking.

Custom minimal frontmatter parser (no YAML dep). Handles the subset we need:

    ---
    name: my-rule
    description: one line
    type: feedback
    globs: ["**/*.py", "**/pyproject.toml"]
    keys: ["pytest", "test"]
    ---
    body text here, may contain --- and other delimiters safely
    since we only split on the FIRST two --- lines.

Values parse as strings; bracketed lists parse as list[str] (comma-separated,
quote-stripped). Anything else stays a string.
"""
from __future__ import annotations

import os
import re
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

_FM_DELIM = "---"
_LIST_RE = re.compile(r"^\s*\[(.*)\]\s*$")


@dataclass
class MemoryEntry:
    """A parsed memory file (rule, lore, or typed memory)."""

    path: Path
    fields: dict[str, Any] = field(default_factory=dict)
    body: str = ""

    @property
    def name(self) -> str:
        return str(self.fields.get("name") or self.path.stem)

    @property
    def description(self) -> str:
        return str(self.fields.get("description") or "")

    @property
    def mem_type(self) -> str:
        return str(self.fields.get("type") or "")

    @property
    def globs(self) -> list[str]:
        return _as_list(self.fields.get("globs"))

    @property
    def keys(self) -> list[str]:
        return _as_list(self.fields.get("keys"))


def _as_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(v) for v in value]
    # Fallback: split on comma.
    s = str(value).strip()
    if not s:
        return []
    return [p.strip() for p in s.split(",") if p.strip()]


# ── Parsing ────────────────────────────────────────────────────────────────────

def _parse_scalar(raw: str) -> Any:
    """Parse a frontmatter value. Lists return list[str], else a stripped string."""
    raw = raw.strip()
    m = _LIST_RE.match(raw)
    if m:
        inner = m.group(1).strip()
        if not inner:
            return []
        items: list[str] = []
        for part in inner.split(","):
            p = part.strip()
            if (p.startswith('"') and p.endswith('"')) or (p.startswith("'") and p.endswith("'")):
                p = p[1:-1]
            if p:
                items.append(p)
        return items
    if (raw.startswith('"') and raw.endswith('"')) or (raw.startswith("'") and raw.endswith("'")):
        return raw[1:-1]
    return raw


def parse_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    """Split ``text`` into (fields, body). If no frontmatter, fields is {}."""
    lines = text.splitlines()
    if not lines or lines[0].strip() != _FM_DELIM:
        return {}, text
    end = -1
    for i in range(1, len(lines)):
        if lines[i].strip() == _FM_DELIM:
            end = i
            break
    if end == -1:
        return {}, text  # unterminated frontmatter — treat as body
    fields: dict[str, Any] = {}
    for ln in lines[1:end]:
        if not ln.strip() or ln.lstrip().startswith("#"):
            continue
        if ":" not in ln:
            continue
        key, _, val = ln.partition(":")
        fields[key.strip()] = _parse_scalar(val)
    body = "\n".join(lines[end + 1 :]).lstrip("\n")
    return fields, body


def emit_frontmatter(fields: dict[str, Any], body: str) -> str:
    """Serialise fields + body back to a markdown file with frontmatter."""
    if not fields:
        return body if body.endswith("\n") else body + "\n"
    out = [_FM_DELIM]
    for k, v in fields.items():
        out.append(f"{k}: {_emit_scalar(v)}")
    out.append(_FM_DELIM)
    out.append("")
    out.append(body.rstrip("\n"))
    out.append("")
    return "\n".join(out)


def _emit_scalar(value: Any) -> str:
    if isinstance(value, list):
        parts = ", ".join(f'"{v}"' for v in value)
        return f"[{parts}]"
    s = str(value)
    # Quote if the string contains characters that would confuse the parser.
    if any(c in s for c in "[]:,") or s != s.strip():
        return f'"{s}"'
    return s


# ── I/O ────────────────────────────────────────────────────────────────────────

def read_entry(path: Path) -> MemoryEntry | None:
    """Read + parse a memory file. Returns None if the file is missing/unreadable."""
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None
    fields, body = parse_frontmatter(text)
    return MemoryEntry(path=path, fields=fields, body=body)


def read_entries(directory: Path) -> list[MemoryEntry]:
    """Read every ``*.md`` under ``directory`` (non-recursive). Skips unreadable files."""
    if not directory.exists():
        return []
    entries: list[MemoryEntry] = []
    try:
        for p in sorted(directory.glob("*.md")):
            e = read_entry(p)
            if e is not None:
                entries.append(e)
    except OSError:
        pass
    return entries


def atomic_write(path: Path, text: str) -> None:
    """Write ``text`` to ``path`` atomically via ``tmp + os.replace``.

    Creates parent directories as needed. Raises OSError on failure — callers
    that run on the background thread must catch it.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(
        prefix=path.name + ".",
        suffix=".tmp",
        dir=str(path.parent),
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except OSError:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def append_body(path: Path, line: str) -> None:
    """Append a line to a memory file's body, creating frontmatter-free files.

    Used for the flat ``user.md`` / ``feedback.md`` accumulators — those files
    have no frontmatter and just grow a bulleted list over time.
    """
    existing = ""
    if path.exists():
        try:
            existing = path.read_text(encoding="utf-8")
        except OSError:
            existing = ""
    if existing and not existing.endswith("\n"):
        existing += "\n"
    if not line.endswith("\n"):
        line += "\n"
    atomic_write(path, existing + line)
