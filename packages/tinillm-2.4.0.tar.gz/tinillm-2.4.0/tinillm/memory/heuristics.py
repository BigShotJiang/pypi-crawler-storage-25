"""Regex heuristics that extract user/feedback/project signals from chat turns.

These run on the background writer thread post-turn. They are intentionally
conservative: false negatives are fine (the user can always /remember), but
false positives pollute the memory store. Each pattern returns None on miss
or a structured ``Extraction`` on hit.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Callable


@dataclass
class Extraction:
    """One thing worth remembering — routed to user.md / feedback.md / project.md."""

    category: str   # "user" | "feedback" | "project"
    content: str    # one-line or small multi-line bullet body


# ── User-profile patterns ─────────────────────────────────────────────────────

_USER_ROLE_RE = re.compile(
    r"\bi(?:'m| am)\s+(?:a|an)\s+([a-z][a-z ]{2,40}?(?: engineer| developer| scientist| designer| student| analyst| researcher| manager))\b",
    re.I,
)

_USER_NAME_RE = re.compile(
    # Trigger is case-insensitive via inline flag; the captured name stays
    # case-sensitive so "call me alice" (no proper noun) doesn't trigger.
    r"\b(?i:my name is|i'm called|call me)\s+([A-Z][a-zA-Z]{1,30})\b"
)

_USER_STACK_RE = re.compile(
    r"\bi(?:'m| am)?\s+(?:mainly |mostly |primarily )?(?:use|using|writing|coding in|working in|working with)\s+([a-z0-9+#./ ]{2,60}?)(?:\.|,|$| not| instead| rather)",
    re.I,
)

_USER_PREF_RE = re.compile(
    r"\bi\s+prefer\s+([a-z0-9_ .+#/-]{2,80}?)(?:\.|,|$| over| to | instead)",
    re.I,
)


def _user_role(text: str) -> Extraction | None:
    m = _USER_ROLE_RE.search(text)
    if m:
        return Extraction("user", f"- role: {m.group(1).strip().lower()}")
    return None


def _user_name(text: str) -> Extraction | None:
    m = _USER_NAME_RE.search(text)
    if m:
        return Extraction("user", f"- name: {m.group(1).strip()}")
    return None


def _user_stack(text: str) -> Extraction | None:
    m = _USER_STACK_RE.search(text)
    if m:
        stack = m.group(1).strip().rstrip(".,")
        if 2 <= len(stack) <= 60:
            return Extraction("user", f"- uses: {stack}")
    return None


def _user_pref(text: str) -> Extraction | None:
    m = _USER_PREF_RE.search(text)
    if m:
        pref = m.group(1).strip().rstrip(".,")
        if 2 <= len(pref) <= 80:
            return Extraction("user", f"- prefers: {pref}")
    return None


# ── Feedback patterns (do/don't rules) ────────────────────────────────────────

# Lookahead (not consuming) so ``_extract_why`` can still match the trailing
# ``because ...`` clause starting where the lazy match stopped.
_FEEDBACK_DONT_RE = re.compile(
    r"\b(?:don'?t|never|stop|avoid|do not)\s+([a-z0-9 ._,/'+#:=?()\[\]-]{4,120}?)(?=\.|$|\s+\b(?:because|since)\b)",
    re.I,
)

_FEEDBACK_DO_RE = re.compile(
    r"\balways\s+([a-z0-9 ._,/'+#:=?()\[\]-]{4,120}?)(?=\.|$|\s+\b(?:because|since)\b)",
    re.I,
)


def _feedback_dont(text: str) -> Extraction | None:
    m = _FEEDBACK_DONT_RE.search(text)
    if m:
        rule = m.group(1).strip().rstrip(".,")
        if 4 <= len(rule) <= 120:
            why = _extract_why(text, m.end())
            body = f"- avoid: {rule}"
            if why:
                body += f"\n  **Why:** {why}"
            return Extraction("feedback", body)
    return None


def _feedback_do(text: str) -> Extraction | None:
    m = _FEEDBACK_DO_RE.search(text)
    if m:
        rule = m.group(1).strip().rstrip(".,")
        if 4 <= len(rule) <= 120:
            why = _extract_why(text, m.end())
            body = f"- always: {rule}"
            if why:
                body += f"\n  **Why:** {why}"
            return Extraction("feedback", body)
    return None


_WHY_RE = re.compile(r"\b(?:because|since)\s+([^.]{4,200})", re.I)


def _extract_why(text: str, from_pos: int) -> str | None:
    m = _WHY_RE.search(text, pos=from_pos)
    if m:
        return m.group(1).strip().rstrip(".,")
    return None


# ── Registry ──────────────────────────────────────────────────────────────────

_EXTRACTORS: list[Callable[[str], Extraction | None]] = [
    _user_role,
    _user_name,
    _user_stack,
    _user_pref,
    _feedback_dont,
    _feedback_do,
]


def extract(text: str) -> list[Extraction]:
    """Run all heuristics against ``text`` and return unique extractions.

    Dedupes by (category, content) so the same regex firing on slightly
    different phrasings within one turn only produces one entry.
    """
    if not text or not text.strip():
        return []
    seen: set[tuple[str, str]] = set()
    out: list[Extraction] = []
    for fn in _EXTRACTORS:
        try:
            e = fn(text)
        except re.error:
            continue
        if e is None:
            continue
        key = (e.category, e.content)
        if key in seen:
            continue
        seen.add(key)
        out.append(e)
    return out
