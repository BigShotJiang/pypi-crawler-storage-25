"""tinillm memory — zero-setup background context persistence.

v1.9.0. Layered, local-first memory for the REPL. No embeddings, no daemon,
no new runtime deps. Three recall tiers (always-on, glob-scoped, keyword-
triggered) are assembled into a memory block prepended to the system prompt;
heuristic writes happen on a background thread post-turn.

See /home/harish/.claude/plans/zazzy-booping-scroll.md for the full design.
"""
from __future__ import annotations

from tinillm.memory.paths import (
    MEMORY_ROOT,
    memory_disabled,
    project_dir,
    ensure_dirs,
)

__all__ = ["MEMORY_ROOT", "memory_disabled", "project_dir", "ensure_dirs"]
