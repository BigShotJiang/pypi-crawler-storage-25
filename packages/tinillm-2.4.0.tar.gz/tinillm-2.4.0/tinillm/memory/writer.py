"""Background writer thread — runs heuristic extraction post-turn.

Never blocks the hot path: ingestion is fire-and-forget via a bounded queue.
One daemon thread consumes the queue and appends extractions to the flat
user.md / feedback.md / project.md files, deduping against what's already
written so the store doesn't grow linearly with turns.

Thread safety: a process-wide lock serialises the appends, so two background
threads in the same process can't race. Inter-process races (two REPL
instances) are guarded by atomic tmp-then-replace writes in ``store.py``;
the worst-case is a lost line, not a corrupt file.
"""
from __future__ import annotations

import queue
import threading
from dataclasses import dataclass
from pathlib import Path

from tinillm.memory.heuristics import Extraction, extract
from tinillm.memory.paths import (
    FEEDBACK_MD,
    USER_MD,
    memory_disabled,
    project_dir,
)
from tinillm.memory.store import append_body


@dataclass
class _Job:
    user_text: str
    assistant_text: str
    cwd_str: str | None


_queue: queue.Queue[_Job | None] = queue.Queue(maxsize=64)
_lock = threading.Lock()
_worker: threading.Thread | None = None
_started = threading.Event()


def _ensure_worker() -> None:
    global _worker
    with _lock:
        if _worker is not None and _worker.is_alive():
            return
        t = threading.Thread(target=_run_worker, name="tinillm-memory", daemon=True)
        t.start()
        _worker = t
        _started.set()


def _run_worker() -> None:
    while True:
        try:
            job = _queue.get()
        except Exception:
            return
        try:
            if job is None:
                return
            try:
                _process_job(job)
            except Exception:
                # Never raise from the worker — memory writes are best-effort.
                pass
        finally:
            # Always mark done so queue.join() in flush() can unblock once
            # processing (not just dequeue) completes.
            try:
                _queue.task_done()
            except ValueError:
                pass


def _process_job(job: _Job) -> None:
    text = (job.user_text or "") + "\n" + (job.assistant_text or "")
    extractions = extract(text)
    if not extractions:
        return
    cwd = Path(job.cwd_str) if job.cwd_str else None
    existing = _load_existing(cwd)
    for e in extractions:
        target = _target_for(e, cwd)
        if target is None:
            continue
        # Dedupe on the first line of the content.
        fingerprint = e.content.splitlines()[0].strip()
        if fingerprint and fingerprint in existing.get(target, set()):
            continue
        try:
            append_body(target, e.content)
        except OSError:
            continue
        existing.setdefault(target, set()).add(fingerprint)


def _target_for(e: Extraction, cwd: Path | None) -> Path | None:
    if e.category == "user":
        return USER_MD
    if e.category == "feedback":
        return FEEDBACK_MD
    if e.category == "project":
        pdir = project_dir(cwd)
        try:
            pdir.mkdir(parents=True, exist_ok=True)
        except OSError:
            return None
        return pdir / "project.md"
    return None


def _load_existing(cwd: Path | None) -> dict[Path, set[str]]:
    """Return a map of path → set of first-lines already present, for dedupe."""
    paths: list[Path] = [USER_MD, FEEDBACK_MD]
    pdir = project_dir(cwd)
    paths.append(pdir / "project.md")
    out: dict[Path, set[str]] = {}
    for p in paths:
        if not p.exists():
            out[p] = set()
            continue
        try:
            text = p.read_text(encoding="utf-8")
        except OSError:
            out[p] = set()
            continue
        out[p] = {line.strip() for line in text.splitlines() if line.strip()}
    return out


# ── Public API ────────────────────────────────────────────────────────────────

def ingest(user_text: str, assistant_text: str, cwd: Path | None = None) -> None:
    """Enqueue a turn for background heuristic extraction. Never blocks."""
    if memory_disabled():
        return
    if not (user_text or assistant_text):
        return
    _ensure_worker()
    job = _Job(
        user_text=user_text or "",
        assistant_text=assistant_text or "",
        cwd_str=str(cwd) if cwd else None,
    )
    try:
        _queue.put_nowait(job)
    except queue.Full:
        # Drop on overflow rather than blocking the chat loop.
        pass


def ingest_suggest_choice(
    use_case: str | None, model_tag: str, cwd: Path | None = None
) -> None:
    """Record a /recommend top pick as a project-scoped preference line.

    Writes directly to ``<project>/project.md`` (bypassing heuristics, which
    wouldn't match a structured one-liner like this).
    """
    if memory_disabled() or not model_tag:
        return
    uc = (use_case or "general").strip()
    line = f"- /recommend: top pick `{model_tag}` for {uc}"
    pdir = project_dir(cwd)
    try:
        pdir.mkdir(parents=True, exist_ok=True)
        target = pdir / "project.md"
    except OSError:
        return
    # Dedupe — don't re-add the same pick.
    if target.exists():
        try:
            existing = target.read_text(encoding="utf-8")
            if line in existing:
                return
        except OSError:
            pass
    try:
        append_body(target, line)
    except OSError:
        pass


def flush(timeout: float = 2.0) -> None:
    """Block until every enqueued job has finished processing. Used by tests.

    Uses ``queue.join()`` (paired with ``task_done`` in the worker) so this
    waits on completed writes, not just dequeue.
    """
    if not _started.is_set():
        return
    import threading as _th

    done = _th.Event()

    def _wait_for_join() -> None:
        _queue.join()
        done.set()

    t = _th.Thread(target=_wait_for_join, daemon=True)
    t.start()
    done.wait(timeout=timeout)
