"""Assemble the memory block injected into the system prompt.

Three deterministic tiers, resolved in a single pass:

    1. Always-on    — global MEMORY.md + user.md + feedback.md
                      + active project MEMORY.md + project.md
    2. Glob-scoped  — memory/rules/*.md with frontmatter globs matching cwd
    3. Keyword      — memory/lore/*.md + projects/<id>/lore/*.md whose keys
                      appear in the last N user turns

The result is capped at ~2k tokens (~8KB). If over budget, oldest tier-3
entries drop first, then tier-2, never tier-1 body text (a truncation footer
appears instead).
"""
from __future__ import annotations

import fnmatch
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from tinillm.memory.paths import (
    FEEDBACK_MD,
    GLOBAL_MEMORY_MD,
    LORE_DIR,
    MEMORY_ROOT,
    PROJECTS_DIR,
    RULES_DIR,
    USER_MD,
    memory_disabled,
    project_dir,
    project_root_for,
)
from tinillm.memory.store import MemoryEntry, read_entries, read_entry

# ── Budget constants ──────────────────────────────────────────────────────────

MAX_BLOCK_BYTES = 8192         # ~2k tokens at ~4 chars/token
MAX_TIER2_RULES = 20
MAX_TIER3_ENTRIES = 5
KEYWORD_SCAN_TURNS = 2          # scan last N user messages for lorebook keys


@dataclass
class RecallBlock:
    """Structured result of a recall pass — renderable + introspectable."""

    tier1_sections: list[tuple[str, str]]  # (title, body) for rendering
    tier2_rules: list[MemoryEntry]
    tier3_entries: list[MemoryEntry]
    truncated: bool = False

    def is_empty(self) -> bool:
        return (
            not any(body.strip() for _, body in self.tier1_sections)
            and not self.tier2_rules
            and not self.tier3_entries
        )

    def to_text(self) -> str:
        """Render as a plain-text memory block for the system prompt."""
        if self.is_empty():
            return ""
        parts: list[str] = ["# tinillm memory"]
        for title, body in self.tier1_sections:
            stripped = body.strip()
            if not stripped:
                continue
            parts.append(f"\n## {title}\n{stripped}")
        if self.tier2_rules:
            parts.append("\n## Rules for this project")
            for r in self.tier2_rules:
                parts.append(_format_entry(r))
        if self.tier3_entries:
            parts.append("\n## Relevant context")
            for e in self.tier3_entries:
                parts.append(_format_entry(e))
        if self.truncated:
            parts.append("\n_⚠ memory truncated — raise budget with `/memory show` to inspect_")
        return "\n".join(parts).rstrip() + "\n"


def _format_entry(e: MemoryEntry) -> str:
    header = f"- **{e.name}**"
    if e.description:
        header += f" — {e.description}"
    body = e.body.strip()
    if body:
        indented = "\n".join("  " + line if line else "" for line in body.splitlines())
        return f"{header}\n{indented}"
    return header


# ── Tier 1 — always-on ────────────────────────────────────────────────────────

def _load_tier1(cwd: Path | None) -> list[tuple[str, str]]:
    sections: list[tuple[str, str]] = []
    for label, path in [
        ("Index", GLOBAL_MEMORY_MD),
        ("User", USER_MD),
        ("Feedback rules", FEEDBACK_MD),
    ]:
        entry = read_entry(path)
        if entry is not None and _has_substance(entry.body):
            sections.append((label, entry.body))

    pdir = project_dir(cwd)
    root = project_root_for(cwd)
    project_label = root.name or "project"
    for label, path in [
        (f"Project index ({project_label})", pdir / "MEMORY.md"),
        (f"Project facts ({project_label})", pdir / "project.md"),
    ]:
        entry = read_entry(path)
        if entry is not None and _has_substance(entry.body):
            sections.append((label, entry.body))
    return sections


def _has_substance(body: str) -> bool:
    """True if the body has real user content beyond stubs / comments / headings.

    Stubs from ``bootstrap.py`` contain only markdown headings, HTML comments,
    and an italic placeholder line. None of those count as substance — only
    a bullet list item or a real paragraph does.
    """
    for line in body.splitlines():
        s = line.strip()
        if not s:
            continue
        if s.startswith("<!--") and s.endswith("-->"):
            continue
        if s.startswith("_") and s.endswith("_"):
            continue
        if s.startswith("#"):
            # Markdown heading (any level) — part of the stub.
            continue
        # A bullet list entry, numbered list, or plain paragraph counts.
        return True
    return False


# ── Tier 2 — glob-scoped rules ────────────────────────────────────────────────

def _load_tier2(cwd: Path | None) -> list[MemoryEntry]:
    entries = read_entries(RULES_DIR)
    if not entries:
        return []
    root = project_root_for(cwd)
    # Match relative to project root and to absolute path — either works.
    matched: list[MemoryEntry] = []
    for e in entries:
        globs = e.globs
        if not globs:
            matched.append(e)  # rules without globs are project-wide
            continue
        if _any_glob_matches(globs, root):
            matched.append(e)
    return matched[:MAX_TIER2_RULES]


def _glob_to_regex(pattern: str) -> re.Pattern[str]:
    """Translate a glob to a regex that honours ``**`` as multi-segment.

    ``fnmatch`` treats ``**`` like ``*`` (one path segment), so it fails on
    common rule patterns like ``**/pyproject.toml`` or ``src/**``. This
    translator distinguishes:

    * ``**/``        — zero or more path segments followed by a ``/``
    * ``/**`` (end)  — zero or more path segments preceded by a ``/``
    * ``/**/``       — at least one ``/`` bridging any number of segments
    * bare ``**``    — any run of chars including ``/``
    * ``*``          — any chars except ``/``
    * ``?``          — any single char except ``/``
    """
    n = len(pattern)
    i = 0
    out: list[str] = ["(?s:"]
    while i < n:
        c = pattern[i]
        # '/**/' → optional segments bridge.
        if (
            c == "/"
            and i + 3 < n
            and pattern[i + 1 : i + 4] == "**/"
        ):
            out.append(r"(?:/.*/|/)")
            i += 4
            continue
        # '/**' at end of pattern → optional segments suffix.
        if (
            c == "/"
            and i + 2 < n
            and pattern[i + 1 : i + 3] == "**"
            and i + 3 == n
        ):
            out.append(r"(?:/.*)?")
            i += 3
            continue
        # '**/' at start or after a non-/ char → optional segments prefix.
        if c == "*" and pattern[i : i + 3] == "**/":
            out.append(r"(?:.*/)?")
            i += 3
            continue
        # Bare '**'.
        if c == "*" and i + 1 < n and pattern[i + 1] == "*":
            out.append(r".*")
            i += 2
            continue
        if c == "*":
            out.append(r"[^/]*")
            i += 1
            continue
        if c == "?":
            out.append(r"[^/]")
            i += 1
            continue
        if c == "[":
            j = pattern.find("]", i)
            if j == -1:
                out.append(re.escape(c))
                i += 1
            else:
                out.append(pattern[i : j + 1])
                i = j + 1
            continue
        out.append(re.escape(c))
        i += 1
    out.append(r")\Z")
    return re.compile("".join(out))


_GLOB_RE_CACHE: dict[str, re.Pattern[str]] = {}


def _compile_glob(pattern: str) -> re.Pattern[str]:
    cached = _GLOB_RE_CACHE.get(pattern)
    if cached is not None:
        return cached
    compiled = _glob_to_regex(pattern)
    _GLOB_RE_CACHE[pattern] = compiled
    return compiled


def _any_glob_matches(globs: Iterable[str], root: Path) -> bool:
    """Return True if any file under ``root`` matches any of the globs.

    We don't walk the whole tree — too slow. Instead we match each glob
    against a small sample: root itself, and up to 50 entries of its top
    two levels. That's sufficient for typical repo signals like
    ``**/pyproject.toml`` or ``src/**``.
    """
    try:
        samples = [root]
        if root.is_dir():
            for child in list(root.iterdir())[:50]:
                samples.append(child)
                if child.is_dir():
                    for grand in list(child.iterdir())[:20]:
                        samples.append(grand)
    except OSError:
        samples = [root]

    for g in globs:
        pattern = g.strip()
        if pattern.startswith("./"):
            pattern = pattern[2:]
        rx = _compile_glob(pattern)
        for s in samples:
            try:
                rel = s.relative_to(root)
            except ValueError:
                continue
            candidate = str(rel).replace("\\", "/")
            if rx.match(candidate):
                return True
            # Also try the basename for patterns like ``*.py`` where the
            # user didn't bother with the ``**/`` prefix.
            if fnmatch.fnmatch(s.name, g):
                return True
    return False


# ── Tier 3 — keyword triggers ─────────────────────────────────────────────────

def _load_tier3(
    cwd: Path | None, recent_user_text: str
) -> list[MemoryEntry]:
    entries = list(read_entries(LORE_DIR))
    pdir = project_dir(cwd)
    entries.extend(read_entries(pdir / "lore"))
    if not entries or not recent_user_text.strip():
        return []
    needle = recent_user_text.lower()
    matched: list[tuple[int, MemoryEntry]] = []
    for e in entries:
        for k in e.keys:
            if k.lower() in needle:
                matched.append((_mtime(e.path), e))
                break
    matched.sort(key=lambda pair: -pair[0])
    return [e for _, e in matched[:MAX_TIER3_ENTRIES]]


def _mtime(path: Path) -> int:
    try:
        return int(path.stat().st_mtime)
    except OSError:
        return 0


# ── Public API ────────────────────────────────────────────────────────────────

def _recent_user_text(recent_turns: list[dict] | None) -> str:
    if not recent_turns:
        return ""
    chunks: list[str] = []
    count = 0
    for msg in reversed(recent_turns):
        if msg.get("role") != "user":
            continue
        content = msg.get("content") or ""
        if isinstance(content, str):
            chunks.append(content)
            count += 1
            if count >= KEYWORD_SCAN_TURNS:
                break
    return "\n".join(reversed(chunks))


def build_recall(cwd: Path | None = None, recent_turns: list[dict] | None = None) -> RecallBlock:
    """Assemble the three-tier recall block for injection into the prompt."""
    if memory_disabled() or not MEMORY_ROOT.exists():
        return RecallBlock([], [], [])
    tier1 = _load_tier1(cwd)
    tier2 = _load_tier2(cwd)
    tier3 = _load_tier3(cwd, _recent_user_text(recent_turns))
    block = RecallBlock(tier1, tier2, tier3)
    # Apply byte budget.
    if len(block.to_text().encode("utf-8")) > MAX_BLOCK_BYTES:
        while block.tier3_entries and len(block.to_text().encode("utf-8")) > MAX_BLOCK_BYTES:
            block.tier3_entries.pop()
            block.truncated = True
        while block.tier2_rules and len(block.to_text().encode("utf-8")) > MAX_BLOCK_BYTES:
            block.tier2_rules.pop()
            block.truncated = True
    return block


def assemble_memory_block(
    cwd: Path | None = None, recent_turns: list[dict] | None = None
) -> str:
    """Convenience: return the block text directly (empty string if nothing)."""
    return build_recall(cwd, recent_turns).to_text()
