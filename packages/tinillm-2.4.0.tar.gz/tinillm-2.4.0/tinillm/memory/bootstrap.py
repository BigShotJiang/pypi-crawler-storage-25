"""First-run bootstrap for tinillm memory.

Idempotent: safe to call on every REPL start. Never clobbers existing files.
Silent on any OS error — memory is opt-out by design, not critical path.
"""
from __future__ import annotations

from tinillm.memory.paths import (
    FEEDBACK_MD,
    GLOBAL_MEMORY_MD,
    USER_MD,
    ensure_dirs,
    project_dir,
    project_root_for,
)
from tinillm.memory.store import atomic_write

_GLOBAL_STUB = """# Memory Index

_Empty — tinillm will populate this as you chat._

## Pointers

<!-- Each line: - [Title](file.md) — one-line hook. Auto-managed. -->
"""

_USER_STUB = """# User profile

<!-- tinillm notes role, stack, and preferences here as the conversation reveals them. -->
"""

_FEEDBACK_STUB = """# Feedback rules

<!-- "Do X / avoid Y" rules learned from corrections. Each entry ends with **Why:** and **How to apply:** -->
"""


def _write_if_missing(path, content: str) -> bool:
    if path.exists():
        return False
    try:
        atomic_write(path, content)
        return True
    except OSError:
        return False


def init_if_missing(cwd=None) -> bool:
    """Create the memory skeleton if absent. Returns True if anything was created."""
    ensure_dirs(cwd)
    created = False
    created |= _write_if_missing(GLOBAL_MEMORY_MD, _GLOBAL_STUB)
    created |= _write_if_missing(USER_MD, _USER_STUB)
    created |= _write_if_missing(FEEDBACK_MD, _FEEDBACK_STUB)

    # Per-project stub.
    pdir = project_dir(cwd)
    proj_memory = pdir / "MEMORY.md"
    proj_facts = pdir / "project.md"
    root = project_root_for(cwd)
    proj_stub = f"""# Project memory — {root.name}

<!-- Scoped to {root}. -->

## Pointers
"""
    facts_stub = f"""# Project facts — {root.name}

<!-- Conventions, deadlines, stakeholders. Auto-populated as tinillm learns. -->
"""
    created |= _write_if_missing(proj_memory, proj_stub)
    created |= _write_if_missing(proj_facts, facts_stub)
    return created
