"""Filesystem layout for tinillm memory.

Single root at ``~/.tinillm/memory/``. Global files sit at the root; per-
project files live under ``projects/<hash>/`` where the hash is derived from
the absolute project path (git root if available, else cwd).

This module never raises; path helpers are pure and safe to call before the
directory exists. ``ensure_dirs`` creates the skeleton when needed.
"""
from __future__ import annotations

import hashlib
import os
import subprocess
from pathlib import Path

# ── Root locations ────────────────────────────────────────────────────────────

MEMORY_ROOT: Path = Path.home() / ".tinillm" / "memory"

GLOBAL_MEMORY_MD = MEMORY_ROOT / "MEMORY.md"
USER_MD = MEMORY_ROOT / "user.md"
FEEDBACK_MD = MEMORY_ROOT / "feedback.md"
RULES_DIR = MEMORY_ROOT / "rules"
LORE_DIR = MEMORY_ROOT / "lore"
PROJECTS_DIR = MEMORY_ROOT / "projects"
SESSIONS_DB = MEMORY_ROOT / "sessions.sqlite"
DISABLED_SENTINEL = MEMORY_ROOT / "DISABLED"


# ── Opt-out ───────────────────────────────────────────────────────────────────

def memory_disabled() -> bool:
    """True if memory should be bypassed entirely this session.

    Controlled by the ``TINILLM_MEMORY`` env var (0/false/off) or a sentinel
    file at ``~/.tinillm/memory/DISABLED``.
    """
    env = os.environ.get("TINILLM_MEMORY", "").strip().lower()
    if env in ("0", "false", "off", "no"):
        return True
    return DISABLED_SENTINEL.exists()


# ── Project scoping ───────────────────────────────────────────────────────────

def _git_root(start: Path) -> Path | None:
    """Return the git top-level for ``start`` if inside a git repo, else None."""
    try:
        result = subprocess.run(
            ["git", "-C", str(start), "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            timeout=2,
        )
        if result.returncode == 0:
            out = result.stdout.strip()
            if out:
                return Path(out)
    except (OSError, subprocess.SubprocessError):
        pass
    return None


def project_key(cwd: Path | None = None) -> str:
    """Stable 12-char hex hash of the project root for path scoping."""
    start = Path(cwd) if cwd else Path.cwd()
    try:
        root = _git_root(start) or start.resolve()
    except OSError:
        root = start
    return hashlib.sha1(str(root).encode("utf-8")).hexdigest()[:12]


def project_dir(cwd: Path | None = None) -> Path:
    """Absolute path to the active project's memory dir (not guaranteed to exist)."""
    return PROJECTS_DIR / project_key(cwd)


def project_root_for(cwd: Path | None = None) -> Path:
    """Return the resolved project root path that ``project_key`` hashed."""
    start = Path(cwd) if cwd else Path.cwd()
    try:
        return _git_root(start) or start.resolve()
    except OSError:
        return start


# ── Skeleton creation ─────────────────────────────────────────────────────────

def ensure_dirs(cwd: Path | None = None) -> None:
    """Create the memory root + subdirs if missing. Idempotent, silent on error."""
    try:
        MEMORY_ROOT.mkdir(parents=True, exist_ok=True)
        RULES_DIR.mkdir(parents=True, exist_ok=True)
        LORE_DIR.mkdir(parents=True, exist_ok=True)
        PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
        pdir = project_dir(cwd)
        pdir.mkdir(parents=True, exist_ok=True)
        (pdir / "lore").mkdir(parents=True, exist_ok=True)
    except OSError:
        # Permission/disk issue — downstream writes will handle their own errors.
        pass
