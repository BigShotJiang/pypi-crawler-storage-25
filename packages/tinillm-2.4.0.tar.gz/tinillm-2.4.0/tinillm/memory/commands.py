"""Click commands exposed in the REPL: /memory, /remember, /forget."""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path
from typing import Optional

import click

from tinillm.memory.bootstrap import init_if_missing
from tinillm.memory.paths import (
    FEEDBACK_MD,
    GLOBAL_MEMORY_MD,
    MEMORY_ROOT,
    USER_MD,
    memory_disabled,
    project_dir,
    project_root_for,
)
from tinillm.memory.recall import build_recall
from tinillm.memory.store import append_body


# ── /memory ────────────────────────────────────────────────────────────────────

@click.command("memory")
@click.argument(
    "subcommand",
    required=False,
    default="show",
    type=click.Choice(["show", "edit", "path", "clear"], case_sensitive=False),
)
@click.option("--project", is_flag=True, default=False,
              help="Scope `clear` to the active project only.")
@click.option("--all", "clear_all", is_flag=True, default=False,
              help="With `clear`: wipe the entire memory root.")
@click.option("--yes", "-y", is_flag=True, default=False,
              help="Skip the confirmation prompt.")
@click.option("--no-color", "-C", is_flag=True, default=False,
              help="Suppress colors.")
def memory_cmd(
    subcommand: str,
    project: bool,
    clear_all: bool,
    yes: bool,
    no_color: bool,
) -> None:
    """Inspect and manage tinillm's memory store.

    \b
    Subcommands:
      show   Render the currently recalled memory block (default)
      edit   Open global MEMORY.md in $EDITOR
      path   Print the memory root path
      clear  Remove memory files (use --project or --all)
    """
    if no_color:
        os.environ["NO_COLOR"] = "1"

    from rich.console import Console
    from tinillm.render.styles import TINILLM_THEME

    console = Console(theme=TINILLM_THEME, highlight=False)

    if memory_disabled():
        console.print("[yellow]Memory is disabled[/] (TINILLM_MEMORY=0 or DISABLED sentinel).")
        return

    init_if_missing()
    sub = subcommand.lower()

    if sub == "path":
        click.echo(str(MEMORY_ROOT))
        return
    if sub == "show":
        _cmd_show(console)
        return
    if sub == "edit":
        _cmd_edit(console)
        return
    if sub == "clear":
        _cmd_clear(console, project=project, clear_all=clear_all, yes=yes)
        return


def _cmd_show(console) -> None:
    from rich.panel import Panel

    block = build_recall(cwd=Path.cwd(), recent_turns=None)
    text = block.to_text().strip()
    tier1_count = sum(1 for _, body in block.tier1_sections if body.strip())
    header = (
        f"[dim]tier 1: {tier1_count} section(s)  ·  "
        f"tier 2: {len(block.tier2_rules)} rule(s)  ·  "
        f"tier 3: {len(block.tier3_entries)} lore entry(s)[/dim]"
    )
    if not text:
        console.print(
            Panel(
                "[dim]_empty — tinillm will populate this as you chat._[/dim]",
                title="[bold]tinillm memory[/]",
                subtitle=header,
                border_style="#7c3aed",
                padding=(1, 2),
            )
        )
        return
    console.print(
        Panel(
            text,
            title="[bold]tinillm memory[/]",
            subtitle=header,
            border_style="#7c3aed",
            padding=(1, 2),
        )
    )
    if block.truncated:
        console.print("[yellow]⚠  Memory block truncated to fit the 2k-token budget.[/]")


def _cmd_edit(console) -> None:
    editor = os.environ.get("EDITOR") or os.environ.get("VISUAL") or "nano"
    try:
        subprocess.call([editor, str(GLOBAL_MEMORY_MD)])
    except (OSError, subprocess.SubprocessError) as e:
        console.print(f"[bold red]Editor failed:[/] {e}")
        console.print(f"[dim]Edit directly: {GLOBAL_MEMORY_MD}[/dim]")


def _cmd_clear(console, *, project: bool, clear_all: bool, yes: bool) -> None:
    if clear_all and project:
        console.print("[bold red]Pick one:[/] --project or --all (not both).")
        return
    if not (project or clear_all):
        console.print("[bold red]Specify what to clear:[/] --project or --all.")
        return
    if clear_all:
        target = MEMORY_ROOT
        scope = "the entire memory root"
    else:
        target = project_dir()
        scope = f"project memory for {project_root_for().name}"
    if not target.exists():
        console.print(f"[dim]Nothing to clear — {target} does not exist.[/dim]")
        return
    if not yes:
        if not click.confirm(f"Delete {scope} at {target}?", default=False):
            console.print("[dim]Cancelled.[/dim]")
            return
    try:
        shutil.rmtree(target)
    except OSError as e:
        console.print(f"[bold red]Failed:[/] {e}")
        return
    console.print(f"[green]✓[/] Cleared {scope}.")
    init_if_missing()


# ── /remember ──────────────────────────────────────────────────────────────────

@click.command("remember")
@click.argument("text", nargs=-1, required=True)
@click.option(
    "--as", "category",
    type=click.Choice(["user", "feedback", "project"], case_sensitive=False),
    default=None,
    help="Category to save under (skips LLM classification).",
)
@click.option("--no-color", "-C", is_flag=True, default=False,
              help="Suppress colors.")
def remember_cmd(text: tuple[str, ...], category: Optional[str], no_color: bool) -> None:
    """Save a one-off fact to memory.

    Example: /remember I use polars instead of pandas --as user
    """
    if no_color:
        os.environ["NO_COLOR"] = "1"
    from rich.console import Console
    from tinillm.render.styles import TINILLM_THEME

    console = Console(theme=TINILLM_THEME, highlight=False)
    if memory_disabled():
        console.print("[yellow]Memory is disabled — refusing to save.[/]")
        return

    init_if_missing()
    body = " ".join(text).strip()
    if not body:
        console.print("[bold red]Nothing to remember.[/]")
        return

    cat = (category or _classify(body)).lower()
    target = {
        "user":     USER_MD,
        "feedback": FEEDBACK_MD,
    }.get(cat)
    if target is None:
        target = project_dir() / "project.md"

    try:
        append_body(target, f"- {body}")
    except OSError as e:
        console.print(f"[bold red]Save failed:[/] {e}")
        return
    console.print(
        f"[green]✓[/] Remembered under [bold]{cat}[/] → [dim]{target}[/dim]"
    )


def _classify(text: str) -> str:
    """Quick keyword-based classification when no --as flag is given.

    We don't call an LLM here because the REPL is synchronous and we want
    zero latency. The --as flag is available for precise control.
    """
    low = text.lower()
    if any(k in low for k in ("don't", "never", "always", "stop", "avoid", "prefer")):
        return "feedback"
    if low.startswith(("i ", "i'm", "my ", "im ")):
        return "user"
    return "project"


# ── /forget ────────────────────────────────────────────────────────────────────

@click.command("forget")
@click.argument("query", nargs=-1, required=True)
@click.option("--yes", "-y", is_flag=True, default=False,
              help="Skip confirmation.")
@click.option("--no-color", "-C", is_flag=True, default=False,
              help="Suppress colors.")
def forget_cmd(query: tuple[str, ...], yes: bool, no_color: bool) -> None:
    """Remove memory lines matching QUERY (substring, case-insensitive)."""
    if no_color:
        os.environ["NO_COLOR"] = "1"
    from rich.console import Console
    from tinillm.render.styles import TINILLM_THEME

    console = Console(theme=TINILLM_THEME, highlight=False)
    if memory_disabled():
        console.print("[yellow]Memory is disabled.[/]")
        return

    init_if_missing()
    needle = " ".join(query).strip().lower()
    if not needle:
        console.print("[bold red]No query given.[/]")
        return

    candidates = [USER_MD, FEEDBACK_MD, project_dir() / "project.md"]
    hits: list[tuple[Path, int, str]] = []  # (file, line_index, line)
    for path in candidates:
        if not path.exists():
            continue
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except OSError:
            continue
        for i, ln in enumerate(lines):
            if needle in ln.lower() and ln.strip().startswith("-"):
                hits.append((path, i, ln))

    if not hits:
        console.print(f"[dim]No matches for[/] [bold]{needle}[/].")
        return

    console.print(f"Found [bold]{len(hits)}[/] line(s):")
    for path, _, ln in hits:
        console.print(f"  [dim]{path.name}:[/] {ln.strip()}")
    if not yes:
        if not click.confirm("Delete these lines?", default=False):
            console.print("[dim]Cancelled.[/dim]")
            return

    # Group by path and rewrite each file with matching lines removed.
    by_path: dict[Path, set[int]] = {}
    for path, idx, _ in hits:
        by_path.setdefault(path, set()).add(idx)
    for path, kill in by_path.items():
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
            kept = [ln for i, ln in enumerate(lines) if i not in kill]
            from tinillm.memory.store import atomic_write
            atomic_write(path, "\n".join(kept) + ("\n" if kept else ""))
        except OSError as e:
            console.print(f"[bold red]Failed to rewrite {path.name}:[/] {e}")
    console.print(f"[green]✓[/] Removed {len(hits)} line(s).")
