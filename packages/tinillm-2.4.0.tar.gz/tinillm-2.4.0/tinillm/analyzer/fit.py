"""LLM fitting logic — FitLevel scoring and quantisation selection.

Ported from llmfit fit.rs and models.rs best_quant_for_budget().
"""

from __future__ import annotations

from tinillm.analyzer.types import FitLevel, LlmModel, ModelFit, Quant
from tinillm.analyzer.memory import QUANT_BPP, estimate_memory_gb
from tinillm.analyzer.models import MODEL_ARCHETYPES
from tinillm.analyzer.throughput import estimate_tokens_per_sec
from tinillm.hardware.types import SystemSpecs

# Quality-ordered hierarchy: best → most compressed
QUANT_HIERARCHY: list[Quant] = [
    Quant.Q8_0,
    Quant.Q6_K,
    Quant.Q5_K_M,
    Quant.Q4_K_M,
    Quant.Q3_K_M,
    Quant.Q2_K,
]

# "Comfortable" baseline quant for FitPerfect threshold
_BASELINE_QUANT = Quant.Q4_K_M
_MIN_CONTEXT = 1024
_CPU_RAM_FRACTION = 0.75  # fraction of free RAM to use as budget on CPU-only systems


def best_quant_for_budget(
    model: LlmModel, budget_gb: float
) -> tuple[Quant, float, int] | None:
    """Find the highest-quality quant + context that fits within budget_gb.

    Returns (quant, mem_required_gb, context_len) or None if nothing fits.
    Halves context length on each pass (down to _MIN_CONTEXT) before giving up.
    """
    ctx = model.context_length
    while ctx >= _MIN_CONTEXT:
        for quant in QUANT_HIERARCHY:
            needed = estimate_memory_gb(model, quant, ctx)
            if needed <= budget_gb:
                return quant, needed, ctx
        ctx //= 2
    return None


def score_fit_level(
    mem_required: float,
    budget_gb: float,
    runs_on_gpu: bool,
    best_quant: Quant,
    model: LlmModel,
    context_len: int,
) -> FitLevel:
    """Classify how well the model fits the available memory budget."""
    if mem_required > budget_gb:
        return FitLevel.TOO_TIGHT

    if not runs_on_gpu:
        return FitLevel.MARGINAL  # CPU-only is always Marginal

    # Check if the comfortable baseline fits at full context
    baseline_mem = estimate_memory_gb(model, _BASELINE_QUANT, model.context_length)
    if baseline_mem <= budget_gb:
        # Fits the baseline with ≥20% headroom → Perfect
        if budget_gb >= baseline_mem * 1.2:
            return FitLevel.PERFECT
        return FitLevel.GOOD

    # Fits only at reduced quant or reduced context
    if context_len < model.context_length:
        return FitLevel.MARGINAL

    return FitLevel.GOOD


def _memory_budget(specs: SystemSpecs) -> tuple[float, bool]:
    """Determine available memory budget and whether GPU is available.

    Returns (budget_gb, runs_on_gpu).
    """
    if not specs.gpus:
        # CPU-only: use a fraction of free RAM to leave headroom for the OS
        return specs.free_ram_gb * _CPU_RAM_FRACTION, False

    # Find the largest single GPU (don't sum across cards for accuracy)
    best = max(specs.gpus, key=lambda g: g.vram_gb)

    if best.unified_memory:
        # Apple Silicon: use total RAM as the GPU memory pool
        return specs.total_ram_gb, True

    return best.vram_gb, True


def _primary_gpu_bandwidth(specs: SystemSpecs) -> float:
    """Return bandwidth (GB/s) of the largest GPU, or 0 for CPU-only."""
    from tinillm.hardware.bandwidth import gpu_bandwidth_gbps

    if not specs.gpus:
        return 0.0
    best = max(specs.gpus, key=lambda g: g.vram_gb)
    return gpu_bandwidth_gbps(best.name)


def analyze(specs: SystemSpecs) -> list[ModelFit]:
    """Run the full LLM fit analysis for all model archetypes."""
    budget_gb, runs_on_gpu = _memory_budget(specs)
    bandwidth_gbps = _primary_gpu_bandwidth(specs)

    results: list[ModelFit] = []
    for model in MODEL_ARCHETYPES:
        fit_result = best_quant_for_budget(model, budget_gb)

        if fit_result is None:
            results.append(
                ModelFit(
                    model=model,
                    fit_level=FitLevel.TOO_TIGHT,
                    best_quant=None,
                    mem_required_gb=None,
                    tokens_per_sec=None,
                    runs_on_gpu=runs_on_gpu,
                )
            )
            continue

        best_quant, mem_required, ctx = fit_result
        fit_level = score_fit_level(
            mem_required, budget_gb, runs_on_gpu, best_quant, model, ctx
        )
        tps = estimate_tokens_per_sec(
            model=model,
            quant=best_quant,
            bandwidth_gbps=bandwidth_gbps,
            runs_on_gpu=runs_on_gpu,
        )
        results.append(
            ModelFit(
                model=model,
                fit_level=fit_level,
                best_quant=best_quant,
                mem_required_gb=round(mem_required, 1),
                tokens_per_sec=round(tps, 1),
                runs_on_gpu=runs_on_gpu,
            )
        )

    return results
