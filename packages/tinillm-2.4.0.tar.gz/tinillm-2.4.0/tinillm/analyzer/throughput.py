"""Tokens-per-second estimation using the physics-based model from llmfit.

Formula (from llmfit fit.rs):
  tps = bandwidth_GB_s * EFFICIENCY / model_size_GB
  model_size_GB = params_B * bytes_per_param[quant]

CPU-only path applies a 0.3x multiplier (llmfit run mode constant).
"""

from __future__ import annotations

from tinillm.analyzer.types import LlmModel, Quant
from tinillm.analyzer.memory import QUANT_BPP

_EFFICIENCY = 0.55        # empirical memory bandwidth utilisation
_CPU_MULTIPLIER = 0.30    # CPU is ~3x slower than theoretical memory BW

# Conservative fallback constants when GPU bandwidth is unknown (t/s)
_FALLBACK_GPU_TPS: dict[Quant, float] = {
    Quant.F16:    10.0,
    Quant.Q8_0:   15.0,
    Quant.Q6_K:   18.0,
    Quant.Q5_K_M: 20.0,
    Quant.Q4_K_M: 22.0,
    Quant.Q3_K_M: 24.0,
    Quant.Q2_K:   28.0,
}
_FALLBACK_CPU_TPS: dict[Quant, float] = {
    Quant.F16:     2.0,
    Quant.Q8_0:    4.0,
    Quant.Q6_K:    5.0,
    Quant.Q5_K_M:  6.0,
    Quant.Q4_K_M:  8.0,
    Quant.Q3_K_M: 10.0,
    Quant.Q2_K:   14.0,
}


def estimate_tokens_per_sec(
    model: LlmModel,
    quant: Quant,
    bandwidth_gbps: float,
    runs_on_gpu: bool,
) -> float:
    """Estimate decode tokens/sec for the given model + quantisation."""
    bpp = QUANT_BPP[quant]
    model_size_gb = model.params_b * bpp

    if bandwidth_gbps > 0:
        effective_bw = bandwidth_gbps if runs_on_gpu else bandwidth_gbps * _CPU_MULTIPLIER
        tps = (effective_bw * _EFFICIENCY) / model_size_gb
        return max(0.1, tps)

    # Unknown bandwidth — use fallback constants
    fallback = _FALLBACK_GPU_TPS if runs_on_gpu else _FALLBACK_CPU_TPS
    return fallback.get(quant, 10.0)
