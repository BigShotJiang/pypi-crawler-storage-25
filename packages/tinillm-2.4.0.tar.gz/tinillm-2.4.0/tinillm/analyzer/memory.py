"""Memory estimation formulas, ported from llmfit fit.rs / models.rs.

KV cache formula:
  kv_cache_bytes = 2 * n_layers * n_kv_heads * head_dim * context * dtype_bytes
  dtype_bytes = 2  (fp16 default KV cache)

Total memory:
  total_gb = weight_gb + kv_cache_gb + OVERHEAD_GB
"""

from __future__ import annotations

from tinillm.analyzer.types import LlmModel, Quant

# bytes per parameter at each quantisation level
QUANT_BPP: dict[Quant, float] = {
    Quant.F16:    2.00,
    Quant.Q8_0:   1.05,
    Quant.Q6_K:   0.80,
    Quant.Q5_K_M: 0.68,
    Quant.Q4_K_M: 0.58,
    Quant.Q3_K_M: 0.48,
    Quant.Q2_K:   0.37,
}

_OVERHEAD_GB = 0.5   # fixed per-model overhead (loader, OS, etc.)
_KV_DTYPE_BYTES = 2  # fp16 KV cache


def kv_cache_gb(model: LlmModel, context_len: int) -> float:
    """Compute KV cache memory in GB for the given context length."""
    bytes_ = (
        2
        * model.num_layers
        * model.num_kv_heads
        * model.head_dim
        * context_len
        * _KV_DTYPE_BYTES
    )
    return bytes_ / (1024 ** 3)


def estimate_memory_gb(model: LlmModel, quant: Quant, context_len: int) -> float:
    """Total GPU/RAM memory required (weights + KV cache + overhead)."""
    bpp = QUANT_BPP[quant]
    weight_gb = model.params_b * bpp
    kv_gb = kv_cache_gb(model, context_len)
    return weight_gb + kv_gb + _OVERHEAD_GB
