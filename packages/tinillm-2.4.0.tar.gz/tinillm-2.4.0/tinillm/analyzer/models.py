"""LLM model archetype database.

Six size classes that answer "can my hardware run a ~7B model?"
Architecture parameters are representative of the Llama/Mistral family.
Embedded as a Python list — no external file needed.
"""

from __future__ import annotations

from tinillm.analyzer.types import LlmModel

MODEL_ARCHETYPES: list[LlmModel] = [
    LlmModel(name="~1B",  params_b=1.0,  num_layers=22, num_kv_heads=8, head_dim=64,  context_length=8192),
    LlmModel(name="~3B",  params_b=3.0,  num_layers=28, num_kv_heads=8, head_dim=128, context_length=8192),
    LlmModel(name="~7B",  params_b=7.0,  num_layers=32, num_kv_heads=8, head_dim=128, context_length=8192),
    LlmModel(name="~13B", params_b=13.0, num_layers=40, num_kv_heads=8, head_dim=128, context_length=4096),
    LlmModel(name="~34B", params_b=34.0, num_layers=48, num_kv_heads=8, head_dim=128, context_length=4096),
    LlmModel(name="~70B", params_b=70.0, num_layers=80, num_kv_heads=8, head_dim=128, context_length=4096),
]
