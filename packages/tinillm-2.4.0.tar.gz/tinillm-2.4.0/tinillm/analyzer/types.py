"""LLM analysis data structures."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class Quant(str, Enum):
    F16     = "F16"
    Q8_0    = "Q8_0"
    Q6_K    = "Q6_K"
    Q5_K_M  = "Q5_K_M"
    Q4_K_M  = "Q4_K_M"
    Q3_K_M  = "Q3_K_M"
    Q2_K    = "Q2_K"


class FitLevel(str, Enum):
    PERFECT   = "Perfect"
    GOOD      = "Good"
    MARGINAL  = "Marginal"
    TOO_TIGHT = "TooTight"


@dataclass
class LlmModel:
    name: str            # display name e.g. "~7B"
    params_b: float      # total parameters in billions
    num_layers: int
    num_kv_heads: int
    head_dim: int
    context_length: int


@dataclass
class ModelFit:
    model: LlmModel
    fit_level: FitLevel
    best_quant: Optional[Quant]      # None if TooTight
    mem_required_gb: Optional[float] # None if TooTight
    tokens_per_sec: Optional[float]  # None if TooTight
    runs_on_gpu: bool
