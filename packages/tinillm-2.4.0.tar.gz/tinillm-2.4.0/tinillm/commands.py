"""Click command objects for tinillm.

These commands are not exposed as shell-level subcommands. They are invoked
only through the interactive REPL (tinillm/repl.py) via the slash-command
dispatcher, and imported directly by tests.

Keeping them as Click commands (rather than plain functions) lets us reuse
Click's argument parsing, help-text rendering, and option validation inside
the REPL, and lets tests exercise them with Click's CliRunner unchanged.
"""
from __future__ import annotations

import os
from typing import Optional

import click


# ── scan ───────────────────────────────────────────────────────────────────────

@click.command("scan")
@click.option("--json", "-j", "json_output", is_flag=True, default=False,
              help="Output machine-readable JSON.")
@click.option("--no-color", "-C", is_flag=True, default=False,
              help="Suppress colors.")
@click.option("--verbose", "-v", is_flag=True, default=False,
              help="Show all model sizes including TooTight.")
def scan_cmd(json_output: bool, no_color: bool, verbose: bool) -> None:
    """Scan hardware and show which LLM sizes can run on this machine."""
    from tinillm.hardware.detect import detect
    from tinillm.analyzer.fit import analyze
    from tinillm.render.report import render_report, render_json
    from rich.console import Console
    from tinillm.render.styles import TINILLM_THEME

    if no_color:
        os.environ["NO_COLOR"] = "1"

    console = Console(theme=TINILLM_THEME, no_color=no_color, highlight=False)

    if json_output:
        specs = detect()
        fits = analyze(specs)
        click.echo(render_json(specs, fits))
        return

    with console.status("[dim]Scanning hardware...[/dim]"):
        specs = detect()
        fits = analyze(specs)

    render_report(specs, fits, verbose=verbose)


# ── models ─────────────────────────────────────────────────────────────────────

@click.command("models")
@click.option("--filter", "name_filter", default=None, metavar="TEXT",
              help="Filter models by name (case-insensitive substring).")
@click.option("--size", default=None,
              type=click.Choice(["1b", "3b", "7b", "13b", "34b", "70b"], case_sensitive=False),
              help="Filter by approximate model size.")
@click.option("--fits-only", "-F", is_flag=True, default=False,
              help="Hide models that don't fit on this hardware.")
@click.option("--ollama", "check_ollama", is_flag=True, default=False,
              help="Show which models are installed in local Ollama.")
@click.option("--json", "-j", "json_output", is_flag=True, default=False,
              help="Output machine-readable JSON.")
@click.option("--no-color", "-C", is_flag=True, default=False,
              help="Suppress colors.")
def models_cmd(
    name_filter: Optional[str],
    size: Optional[str],
    fits_only: bool,
    check_ollama: bool,
    json_output: bool,
    no_color: bool,
) -> None:
    """Browse real LLM models and see which ones fit on this machine."""
    if no_color:
        os.environ["NO_COLOR"] = "1"
    from tinillm.models.cmd import run_models
    run_models(
        name_filter=name_filter,
        size_filter=size,
        fits_only=fits_only,
        check_ollama=check_ollama,
        json_output=json_output,
    )


# ── run ────────────────────────────────────────────────────────────────────────

@click.command("run")
@click.argument("model_tag", required=False, default=None, metavar="[MODEL_TAG]")
@click.option("--use-case", "use_case",
              type=click.Choice(["chat", "coding", "reasoning", "writing", "fast"]),
              default=None,
              help="Sort the interactive picker by use-case affinity.")
@click.option("--force", is_flag=True, default=False,
              help="Run even if the model is TooTight for this hardware.")
@click.option("--dry-run", "dry_run", is_flag=True, default=False,
              help="Print the ollama command without executing it.")
@click.option("--no-color", "-C", is_flag=True, default=False,
              help="Suppress colors.")
def run_cmd(
    model_tag: Optional[str],
    use_case: Optional[str],
    force: bool,
    dry_run: bool,
    no_color: bool,
) -> None:
    """Pick a compatible model and run it via Ollama.

    Optionally pass MODEL_TAG directly (e.g. llama3.1:8b) to skip the picker.
    """
    if no_color:
        os.environ["NO_COLOR"] = "1"
    from tinillm.run.cmd import run_run
    run_run(model_tag=model_tag, use_case=use_case, force=force, dry_run=dry_run)


# ── recommend ──────────────────────────────────────────────────────────────────

@click.command("recommend")
@click.option("--use-case", "use_case",
              type=click.Choice(["chat", "coding", "reasoning", "writing", "fast"]),
              default=None,
              help="Your intended use case.")
@click.option("--json", "-j", "json_output", is_flag=True, default=False,
              help="Output machine-readable JSON.")
@click.option("--no-color", "-C", is_flag=True, default=False,
              help="Suppress colors.")
def recommend_cmd(use_case: Optional[str], json_output: bool, no_color: bool) -> None:
    """Get a personalised model recommendation for your hardware and use case."""
    if no_color:
        os.environ["NO_COLOR"] = "1"
    from tinillm.recommend.cmd import run_recommend
    run_recommend(use_case, json_output)


# Backwards-compat alias — preserves any external imports of ``suggest_cmd``.
suggest_cmd = recommend_cmd


# ── doctor ─────────────────────────────────────────────────────────────────────

@click.command("doctor")
def doctor_cmd() -> None:
    """Run a system health check — hardware, Ollama, models, memory."""
    from tinillm.doctor import run_doctor
    run_doctor()


# ── memory / remember / forget ─────────────────────────────────────────────────

from tinillm.memory.commands import forget_cmd, memory_cmd, remember_cmd


# ── init ───────────────────────────────────────────────────────────────────────

@click.command("init")
@click.option("--force", is_flag=True, default=False,
              help="Overwrite an existing TINILLM.md.")
def init_cmd(force: bool) -> None:
    """Create a starter TINILLM.md in the current directory."""
    from rich.console import Console
    from tinillm.agent.prompts import init_project

    console = Console()
    try:
        path = init_project(Path.cwd(), force=force)
        console.print(f"[green]✓[/] wrote {path}")
    except FileExistsError as e:
        console.print(f"[yellow]{e}[/yellow]")


# ── permissions ────────────────────────────────────────────────────────────────

@click.command("permissions")
@click.argument("mode", required=False,
                type=click.Choice(["read-only", "workspace-write", "danger-full-access"],
                                  case_sensitive=False))
def permissions_cmd(mode: Optional[str]) -> None:
    """Show or set the default permission mode used by the chat agent."""
    from rich.console import Console
    from tinillm.agent.config import load as load_config

    console = Console()
    cfg = load_config()
    if mode is None:
        console.print(f"current mode: [bold]{cfg.permission_mode}[/bold]")
        console.print("  [dim]read-only  · workspace-write  · danger-full-access[/dim]")
        console.print("  [dim]set in ~/.tinillmrc or .tinillmrc — e.g. permission_mode = \"read-only\"[/dim]")
        return
    console.print(f"mode would be set to [bold]{mode}[/bold] — persist via ~/.tinillmrc.")


# ── skills ─────────────────────────────────────────────────────────────────────

@click.command("skills")
def skills_cmd() -> None:
    """List available skill briefs (~/.tinillm/skills/*.md)."""
    from rich.console import Console
    from tinillm.agent.skills import discover

    console = Console()
    found = discover(Path.cwd())
    if not found:
        console.print("[dim]No skills found. Drop markdown files into ~/.tinillm/skills/[/dim]")
        return
    for s in found:
        console.print(f"  [bold]{s.name}[/bold]  [dim]— {s.description}[/dim]")


# ── sessions ───────────────────────────────────────────────────────────────────

@click.command("sessions")
def sessions_cmd() -> None:
    """List recent chat sessions."""
    from rich.console import Console
    from tinillm.agent.session import list_sessions

    console = Console()
    rows = list_sessions()
    if not rows:
        console.print("[dim]No saved sessions.[/dim]")
        return
    for r in rows[:20]:
        console.print(
            f"  [bold]{r.get('id', '?')}[/bold]  "
            f"[dim]{r.get('model', '?')} · {r.get('message_count', 0)} msgs · "
            f"{r.get('updated_at', '')}[/dim]"
        )


# ── load ───────────────────────────────────────────────────────────────────────

@click.command("load")
@click.argument("model_tag")
def load_cmd(model_tag: str) -> None:
    """Save ``MODEL_TAG`` as the default model in ~/.tinillm/settings.json."""
    from rich.console import Console
    from tinillm.agent import settings as _s

    console = Console()
    _s.save(model=model_tag)
    console.print(f"[green]✓[/] model → [bold]{model_tag}[/bold]")
    console.print(f"  [dim]saved to {_s.path()}[/dim]")


# ── chat ───────────────────────────────────────────────────────────────────────

@click.command("chat")
@click.argument("model_tag", required=False, default=None, metavar="[MODEL_TAG]")
@click.option("--resume", "resume_id", default=None, metavar="SESSION_ID",
              help="Resume a saved session by id (see /sessions).")
@click.option("--mode", "mode",
              type=click.Choice(["read-only", "workspace-write", "danger-full-access"],
                                case_sensitive=False),
              default=None, help="Permission mode for this session.")
@click.option("--yes", is_flag=True, default=False,
              help="Auto-confirm destructive bash + ask_user prompts.")
def chat_cmd(model_tag: Optional[str], resume_id: Optional[str],
             mode: Optional[str], yes: bool) -> None:
    """Start the agent chat loop with tool access (read/write/edit/bash/search)."""
    from tinillm.run.chat import run_agent_chat
    run_agent_chat(model_tag=model_tag, resume_id=resume_id, mode=mode, auto_confirm=yes)


# ── public registry (used by REPL dispatcher) ──────────────────────────────────

from pathlib import Path  # re-used by /init above; imported late to avoid ordering churn

COMMAND_REGISTRY: dict[str, click.Command] = {
    "scan":        scan_cmd,
    "models":      models_cmd,
    "run":         run_cmd,
    "recommend":   recommend_cmd,
    "suggest":     recommend_cmd,   # alias for backwards compatibility
    "doctor":      doctor_cmd,
    "memory":      memory_cmd,
    "remember":    remember_cmd,
    "forget":      forget_cmd,
    "init":        init_cmd,
    "permissions": permissions_cmd,
    "skills":      skills_cmd,
    "sessions":    sessions_cmd,
    "load":        load_cmd,
    "chat":        chat_cmd,
}
