"""Curated database of real, popular LLM models.

Architecture parameters sourced from HuggingFace model cards and llmfit's
hf_models.json (MIT licensed). Embedded as a Python list — fully offline,
no JSON file, no HTTP calls needed.

Each model maps 1-to-1 to an Ollama tag for easy `ollama pull`.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class RealModel:
    name: str           # short identifier, e.g. "llama3.2:3b"
    display_name: str   # human display, e.g. "Llama 3.2 3B"
    provider: str       # org, e.g. "Meta"
    params_b: float     # total parameters in billions
    num_layers: int
    num_kv_heads: int
    head_dim: int
    context_length: int
    ollama_tag: str     # exact tag for `ollama pull`
    description: str    # one-line description


# ---------------------------------------------------------------------------
# The database
# ---------------------------------------------------------------------------

MODELS: list[RealModel] = [

    # ── SmolLM2 (HuggingFace) ────────────────────────────────────────────
    RealModel("smollm2:135m",  "SmolLM2 135M",  "HuggingFace",  0.135,  30,  8,  64,   8192,  "smollm2:135m",  "Tiny model for edge / embedded devices"),
    RealModel("smollm2:360m",  "SmolLM2 360M",  "HuggingFace",  0.360,  32,  8,  64,   8192,  "smollm2:360m",  "Compact model with solid text quality"),
    RealModel("smollm2:1.7b",  "SmolLM2 1.7B",  "HuggingFace",  1.7,    24,  8,  64,   8192,  "smollm2:1.7b",  "Best-in-class sub-2B model"),

    # ── Llama 3.2 (Meta) ─────────────────────────────────────────────────
    RealModel("llama3.2:1b",   "Llama 3.2 1B",  "Meta",   1.0,   16,  8,  64,  131072, "llama3.2:1b",   "Ultra-fast, fits any hardware"),
    RealModel("llama3.2:3b",   "Llama 3.2 3B",  "Meta",   3.0,   28,  8,  128, 131072, "llama3.2:3b",   "Efficient everyday model"),

    # ── Llama 3.1 (Meta) ─────────────────────────────────────────────────
    RealModel("llama3.1:8b",   "Llama 3.1 8B",  "Meta",   8.0,   32,  8,  128, 131072, "llama3.1:8b",   "Flagship small model, strong reasoning"),
    RealModel("llama3.1:70b",  "Llama 3.1 70B", "Meta",  70.0,   80,  8,  128, 131072, "llama3.1:70b",  "Near-GPT-4 quality, requires high VRAM"),

    # ── Llama 3.3 (Meta) ─────────────────────────────────────────────────
    RealModel("llama3.3:70b",  "Llama 3.3 70B", "Meta",  70.0,   80,  8,  128, 131072, "llama3.3:70b",  "Latest Llama 70B — improved instruction following"),

    # ── Mistral ──────────────────────────────────────────────────────────
    RealModel("mistral:7b",       "Mistral 7B",      "Mistral AI",  7.0,  32, 8,  128, 32768, "mistral:7b",       "Classic high-quality 7B model"),
    RealModel("mistral-nemo:12b", "Mistral Nemo 12B","Mistral AI", 12.0,  40, 8,  128, 128000, "mistral-nemo:12b", "Strong 12B with 128k context"),

    # ── Mixtral (Mistral MoE) ─────────────────────────────────────────────
    RealModel("mixtral:8x7b",  "Mixtral 8×7B",  "Mistral AI", 46.7, 32, 8, 128, 32768, "mixtral:8x7b",  "Mixture-of-experts, ~13B active params"),

    # ── Qwen 2.5 (Alibaba) ────────────────────────────────────────────────
    RealModel("qwen2.5:0.5b",  "Qwen 2.5 0.5B", "Alibaba",  0.5,  24,  2,  64,  32768,  "qwen2.5:0.5b",  "Ultra-compact multilingual model"),
    RealModel("qwen2.5:1.5b",  "Qwen 2.5 1.5B", "Alibaba",  1.5,  28,  2,  128, 32768,  "qwen2.5:1.5b",  "Strong multilingual sub-2B"),
    RealModel("qwen2.5:3b",    "Qwen 2.5 3B",   "Alibaba",  3.0,  36,  2,  128, 32768,  "qwen2.5:3b",    "Competitive small multilingual model"),
    RealModel("qwen2.5:7b",    "Qwen 2.5 7B",   "Alibaba",  7.0,  28,  4,  128, 131072, "qwen2.5:7b",    "Excellent reasoning, 128k context"),
    RealModel("qwen2.5:14b",   "Qwen 2.5 14B",  "Alibaba", 14.0,  48,  8,  128, 131072, "qwen2.5:14b",   "Top mid-range model for complex tasks"),
    RealModel("qwen2.5:32b",   "Qwen 2.5 32B",  "Alibaba", 32.0,  64,  8,  128, 131072, "qwen2.5:32b",   "Near-70B quality at lower cost"),
    RealModel("qwen2.5:72b",   "Qwen 2.5 72B",  "Alibaba", 72.0,  80,  8,  128, 131072, "qwen2.5:72b",   "State-of-the-art open model"),

    # ── Gemma 3 (Google) ─────────────────────────────────────────────────
    RealModel("gemma3:1b",   "Gemma 3 1B",   "Google",  1.0,  18,  4,  256, 32768,  "gemma3:1b",   "Tiny Google model for on-device tasks"),
    RealModel("gemma3:4b",   "Gemma 3 4B",   "Google",  4.0,  34,  4,  256, 131072, "gemma3:4b",   "Efficient vision-capable model"),
    RealModel("gemma3:12b",  "Gemma 3 12B",  "Google", 12.0,  48,  8,  256, 131072, "gemma3:12b",  "Best Gemma for reasoning tasks"),
    RealModel("gemma3:27b",  "Gemma 3 27B",  "Google", 27.0,  62,  8,  256, 131072, "gemma3:27b",  "Top-tier open model from Google"),

    # ── Phi (Microsoft) ──────────────────────────────────────────────────
    RealModel("phi4-mini:3.8b", "Phi-4 Mini 3.8B", "Microsoft",  3.8, 32, 8,  96,  131072, "phi4-mini:3.8b", "Compact reasoning model from Microsoft"),
    RealModel("phi4:14b",       "Phi-4 14B",       "Microsoft", 14.0, 40, 8,  128, 16384,  "phi4:14b",       "Strong STEM reasoning, concise outputs"),

    # ── DeepSeek R1 ───────────────────────────────────────────────────────
    RealModel("deepseek-r1:1.5b", "DeepSeek-R1 1.5B", "DeepSeek",  1.5, 28,  8, 128, 131072, "deepseek-r1:1.5b", "Distilled reasoning model, tiny footprint"),
    RealModel("deepseek-r1:7b",   "DeepSeek-R1 7B",   "DeepSeek",  7.0, 28,  8, 128, 131072, "deepseek-r1:7b",   "Reasoning-focused, chain-of-thought"),
    RealModel("deepseek-r1:8b",   "DeepSeek-R1 8B",   "DeepSeek",  8.0, 32,  8, 128, 131072, "deepseek-r1:8b",   "Llama-3 based distilled reasoner"),
    RealModel("deepseek-r1:14b",  "DeepSeek-R1 14B",  "DeepSeek", 14.0, 48,  8, 128, 131072, "deepseek-r1:14b",  "Mid-range deep reasoning model"),
    RealModel("deepseek-r1:32b",  "DeepSeek-R1 32B",  "DeepSeek", 32.0, 64,  8, 128, 131072, "deepseek-r1:32b",  "Near-70B reasoning quality"),
    RealModel("deepseek-r1:70b",  "DeepSeek-R1 70B",  "DeepSeek", 70.0, 80,  8, 128, 131072, "deepseek-r1:70b",  "Top open reasoning model"),

    # ── Command R (Cohere) ────────────────────────────────────────────────
    RealModel("command-r:35b",      "Command R 35B",      "Cohere", 35.0, 40, 8, 128, 131072, "command-r:35b",      "Cohere enterprise-grade chat model"),
    RealModel("command-r-plus:104b","Command R+ 104B",    "Cohere",104.0, 56, 8, 128, 131072, "command-r-plus:104b","Cohere's most capable open model"),

    # ── CodeLlama (Meta) ─────────────────────────────────────────────────
    RealModel("codellama:7b",  "CodeLlama 7B",  "Meta",  7.0, 32, 8, 128, 16384, "codellama:7b",  "Code generation and completion"),
    RealModel("codellama:13b", "CodeLlama 13B", "Meta", 13.0, 40, 8, 128, 16384, "codellama:13b", "Stronger code model for complex tasks"),
    RealModel("codellama:34b", "CodeLlama 34B", "Meta", 34.0, 48, 8, 128, 16384, "codellama:34b", "Best open-source code model"),
]


# ---------------------------------------------------------------------------
# Size-bracket helper
# ---------------------------------------------------------------------------

def size_bracket(params_b: float) -> str:
    """Return a coarse size bracket string matching --size filter values."""
    if params_b < 1.0:
        return "1b"   # sub-1B shown in the 1b bucket
    elif params_b < 4.0:
        return "3b"
    elif params_b < 10.0:
        return "7b"
    elif params_b < 20.0:
        return "13b"
    elif params_b < 50.0:
        return "34b"
    else:
        return "70b"
