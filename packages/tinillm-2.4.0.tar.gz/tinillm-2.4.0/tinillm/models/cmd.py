"""Core logic for `tinillm models` — filtering, fitting, Ollama check."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor

from tinillm.models.database import MODELS, RealModel, size_bracket
from tinillm.analyzer.types import LlmModel, FitLevel, ModelFit
from tinillm.analyzer.fit import best_quant_for_budget, score_fit_level, _memory_budget, _primary_gpu_bandwidth
from tinillm.analyzer.throughput import estimate_tokens_per_sec
from tinillm.hardware.detect import detect


def _to_llm_model(m: RealModel) -> LlmModel:
    return LlmModel(
        name=m.display_name,
        params_b=m.params_b,
        num_layers=m.num_layers,
        num_kv_heads=m.num_kv_heads,
        head_dim=m.head_dim,
        context_length=m.context_length,
    )


def _fit_model(model: RealModel, budget_gb: float, bandwidth_gbps: float, runs_on_gpu: bool) -> ModelFit:
    lm = _to_llm_model(model)
    result = best_quant_for_budget(lm, budget_gb)
    if result is None:
        return ModelFit(
            model=lm,
            fit_level=FitLevel.TOO_TIGHT,
            best_quant=None,
            mem_required_gb=None,
            tokens_per_sec=None,
            runs_on_gpu=runs_on_gpu,
        )
    best_quant, mem_required, ctx = result
    fit_level = score_fit_level(mem_required, budget_gb, runs_on_gpu, best_quant, lm, ctx)
    tps = estimate_tokens_per_sec(lm, best_quant, bandwidth_gbps, runs_on_gpu)
    return ModelFit(
        model=lm,
        fit_level=fit_level,
        best_quant=best_quant,
        mem_required_gb=round(mem_required, 1),
        tokens_per_sec=round(tps, 1),
        runs_on_gpu=runs_on_gpu,
    )


def _fetch_ollama_installed() -> set[str]:
    try:
        import ollama
        return {m.model for m in ollama.list().models}
    except Exception:
        return set()


def run_models(
    name_filter: str | None,
    size_filter: str | None,
    fits_only: bool,
    check_ollama: bool,
    json_output: bool,
) -> None:
    from tinillm.models.render import render_models_table, render_models_json
    from rich.console import Console
    from tinillm.render.styles import TINILLM_THEME
    import os, sys

    console = Console(
        theme=TINILLM_THEME,
        no_color="NO_COLOR" in os.environ,
        highlight=False,
    )

    with console.status("[dim]Analysing hardware...[/dim]"):
        specs = detect()
        budget_gb, runs_on_gpu = _memory_budget(specs)
        bw = _primary_gpu_bandwidth(specs)
        installed: set[str] = _fetch_ollama_installed() if check_ollama else set()

    # Pre-filter candidates before parallel fitting
    candidates = []
    for model in MODELS:
        if name_filter and name_filter.lower() not in model.display_name.lower() \
                and name_filter.lower() not in model.provider.lower():
            continue
        if size_filter and size_bracket(model.params_b) != size_filter.lower():
            continue
        candidates.append(model)

    # Parallel model fitting
    def _fit(model: RealModel) -> tuple[RealModel, ModelFit]:
        return model, _fit_model(model, budget_gb, bw, runs_on_gpu)

    with ThreadPoolExecutor(max_workers=8) as pool:
        fitted = list(pool.map(_fit, candidates))

    results: list[tuple[RealModel, ModelFit, bool]] = []
    for model, fit in fitted:
        if fits_only and fit.fit_level == FitLevel.TOO_TIGHT:
            continue
        is_installed = any(
            tag in installed or tag.split(":")[0] in installed
            for tag in [model.ollama_tag, model.name]
        )
        results.append((model, fit, is_installed))

    if json_output:
        import click
        click.echo(render_models_json(results, specs, check_ollama))
        return

    render_models_table(results, specs, budget_gb, runs_on_gpu, show_installed=check_ollama)
