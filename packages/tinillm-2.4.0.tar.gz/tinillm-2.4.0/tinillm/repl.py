"""Interactive REPL for tinillm — prompt_toolkit-powered slash-command shell.

`tinillm` launches this REPL. All features are slash commands here; there are
no shell-level subcommands.
"""
from __future__ import annotations

import getpass
import os
import shlex
from pathlib import Path
from typing import Iterable

from prompt_toolkit import PromptSession
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.document import Document
from prompt_toolkit.history import FileHistory
from prompt_toolkit.styles import Style

from tinillm.commands import COMMAND_REGISTRY

HISTORY_FILE = Path.home() / ".tinillm_history"
STATE_DIR = Path.home() / ".tinillm"
FIRST_LAUNCH_MARKER = STATE_DIR / "first_launch_done"

# ── Command metadata (drives tab completion + /help) ──────────────────────────
SLASH_COMMANDS: dict[str, dict] = {
    "scan": {
        "desc": "Scan hardware and show which LLM sizes fit",
        "flags": ["--json", "--no-color", "--verbose"],
    },
    "models": {
        "desc": "Browse real LLM models and see which fit",
        "flags": ["--filter", "--size", "--fits-only", "--ollama", "--json", "--no-color"],
    },
    "run": {
        "desc": "Pick a compatible model and run it via Ollama",
        "flags": ["--use-case", "--force", "--dry-run", "--no-color"],
    },
    "recommend": {
        "desc": "Get a personalised model recommendation",
        "flags": ["--use-case", "--json", "--no-color"],
    },
    "doctor": {
        "desc": "Run a system health check",
        "flags": [],
    },
    "memory": {
        "desc": "Inspect and manage persistent memory (show | edit | path | clear)",
        "flags": ["--project", "--all", "--yes", "--no-color"],
        "subcommands": {
            "show":  ["--no-color"],
            "edit":  ["--no-color"],
            "path":  [],
            "clear": ["--project", "--all", "--yes", "--no-color"],
        },
    },
    "remember": {
        "desc": "Save a one-off fact to memory",
        "flags": ["--as", "--no-color"],
    },
    "forget": {
        "desc": "Remove memory lines matching a query",
        "flags": ["--yes", "--no-color"],
    },
    "init": {
        "desc": "Write a starter TINILLM.md (project brief for the agent)",
        "flags": ["--force"],
    },
    "permissions": {
        "desc": "Show or set the agent's permission mode",
        "flags": [],
    },
    "skills": {
        "desc": "List skill briefs under ~/.tinillm/skills/",
        "flags": [],
    },
    "sessions": {
        "desc": "List recent agent chat sessions",
        "flags": [],
    },
    "chat": {
        "desc": "(Re)initialise the agent — free text now routes directly",
        "flags": ["--resume", "--mode", "--yes"],
    },
    "load": {
        "desc": "Set the default model in ~/.tinillm/settings.json",
        "flags": [],
    },
    # ── Agent in-chat commands (only meaningful once a chat session exists) ──
    "plan":        {"desc": "Agent: enter read-only plan mode", "flags": []},
    "plan-off":    {"desc": "Agent: leave plan mode", "flags": []},
    "compact":     {"desc": "Agent: summarise and shrink the session", "flags": []},
    "summary":     {"desc": "Agent: print a summary without shrinking", "flags": []},
    "rewind":      {"desc": "Agent: undo N turns (default 1)", "flags": []},
    "diff":        {"desc": "Agent: show filesystem diff since session start", "flags": []},
    "cost":        {"desc": "Agent: show token usage", "flags": []},
    "tasks":       {"desc": "Agent: show the in-memory task list", "flags": []},
    "help":  {"desc": "Show this help", "flags": []},
    "clear": {"desc": "Clear the terminal screen", "flags": []},
    "exit":  {"desc": "Exit the REPL", "flags": []},
}


# ── Tab completer ──────────────────────────────────────────────────────────────

class SlashCompleter(Completer):
    """Tab-complete slash commands, their subcommands, and their flags."""

    def get_completions(
        self, document: Document, complete_event
    ) -> Iterable[Completion]:
        text = document.text_before_cursor.lstrip()
        if not text.startswith("/"):
            return

        stripped = text[1:]
        tokens = stripped.split()
        ends_with_space = text.endswith(" ")

        if not tokens or (len(tokens) == 1 and not ends_with_space):
            partial = tokens[0] if tokens else ""
            for name in SLASH_COMMANDS:
                if name.startswith(partial):
                    yield Completion(
                        "/" + name,
                        start_position=-len(text),
                        display=f"/{name}",
                        display_meta=SLASH_COMMANDS[name]["desc"],
                    )
            return

        cmd = tokens[0]
        if cmd not in SLASH_COMMANDS:
            return

        spec = SLASH_COMMANDS[cmd]

        if spec.get("subcommands"):
            subcommands = spec.get("subcommands", {})
            if len(tokens) == 1 and ends_with_space:
                for sub in subcommands:
                    yield Completion(sub, start_position=0, display=sub)
            elif len(tokens) == 2 and not ends_with_space:
                partial_sub = tokens[1]
                for sub in subcommands:
                    if sub.startswith(partial_sub):
                        yield Completion(
                            sub,
                            start_position=-len(partial_sub),
                            display=sub,
                        )
            elif len(tokens) >= 2 and ends_with_space:
                sub = tokens[1]
                for f in subcommands.get(sub, []):
                    yield Completion(f, start_position=0, display=f)
            elif len(tokens) >= 3:
                sub = tokens[1]
                partial_flag = tokens[-1]
                for f in subcommands.get(sub, []):
                    if f.startswith(partial_flag):
                        yield Completion(
                            f,
                            start_position=-len(partial_flag),
                            display=f,
                        )
            return

        flags = spec.get("flags", [])
        if ends_with_space:
            for f in flags:
                yield Completion(f, start_position=0, display=f)
        elif tokens[-1].startswith("-"):
            partial_flag = tokens[-1]
            for f in flags:
                if f.startswith(partial_flag):
                    yield Completion(
                        f,
                        start_position=-len(partial_flag),
                        display=f,
                    )


# ── PromptSession factory ──────────────────────────────────────────────────────

def _make_session() -> PromptSession:
    style = Style.from_dict({
        "prompt": "bold #7c3aed",
    })
    return PromptSession(
        history=FileHistory(str(HISTORY_FILE)),
        completer=SlashCompleter(),
        style=style,
        complete_while_typing=True,
    )


# ── Click invocation ───────────────────────────────────────────────────────────

def _invoke_click(cmd_obj, args: list[str], console) -> None:
    """Invoke a Click command with args, keeping the REPL alive on any error."""
    import click

    try:
        cmd_obj.main(args, standalone_mode=False)
    except click.UsageError as exc:
        console.print(f"[bold red]Usage error:[/] {exc.format_message()}")
        console.print(f"[dim]Try: /{cmd_obj.name} --help[/dim]")
    except click.exceptions.Exit:
        pass
    except SystemExit:
        pass
    except Exception as exc:
        console.print(f"[bold red]Error:[/] {exc}")


# ── Dispatcher ─────────────────────────────────────────────────────────────────

def _dispatch_click_slash(line: str, console) -> None:
    """Route a /slash command to its Click implementation.

    Only handles commands in ``COMMAND_REGISTRY``. Terminal commands (/exit,
    /clear, /help) and agent in-chat commands (/plan, /cost…) are handled
    upstream in ``run_repl`` so the session object is in scope.
    """
    try:
        parts = shlex.split(line[1:])
    except ValueError as exc:
        console.print(f"[bold red]Parse error:[/] {exc}")
        return

    if not parts:
        return

    cmd_name = parts[0]
    args = parts[1:]

    cmd_obj = COMMAND_REGISTRY.get(cmd_name)
    if cmd_obj is None:
        console.print(
            f"[bold red]Unknown command:[/] /{cmd_name}  "
            "— type [bold]/help[/] for a list."
        )
        return

    _invoke_click(cmd_obj, args, console)


def _ensure_chat(existing, console):
    """Return a live ChatSession, creating one lazily on first free-text or
    in-chat slash input. Prints the setup error and returns ``None`` if
    creation fails so the REPL stays alive."""
    if existing is not None:
        return existing
    try:
        from tinillm.run.chat_session import ChatSession, ChatSessionError
    except ImportError as e:
        console.print(f"[bold red]Agent unavailable:[/] {e}")
        return None
    try:
        chat = ChatSession.create(console=console)
    except ChatSessionError as e:
        console.print(f"[bold red]{e}[/]")
        return None
    chat.print_banner()
    return chat


# ── /help renderer ─────────────────────────────────────────────────────────────

def _render_help(console) -> None:
    from rich import box
    from rich.table import Table

    console.print()
    console.print(
        "  [bold]Type anything[/] to talk to the agent · "
        "[bold]/command[/] for tools\n"
    )
    table = Table(
        box=box.SIMPLE_HEAD,
        show_header=True,
        header_style="bold #a78bfa",
        padding=(0, 2),
    )
    table.add_column("Command", style="bold #a78bfa", min_width=24)
    table.add_column("Description")

    core_cmds = ["scan", "models", "run", "recommend", "doctor"]
    for name in core_cmds:
        spec = SLASH_COMMANDS[name]
        flags_hint = "  [dim]" + "  ".join(spec["flags"][:3]) + "[/dim]" if spec["flags"] else ""
        table.add_row(f"/{name}", spec["desc"] + flags_hint)

    table.add_row("", "")
    for name in ("memory", "remember", "forget"):
        spec = SLASH_COMMANDS[name]
        flags_hint = "  [dim]" + "  ".join(spec["flags"][:3]) + "[/dim]" if spec["flags"] else ""
        table.add_row(f"/{name}", spec["desc"] + flags_hint)

    table.add_row("", "")
    for name in ("plan", "plan-off", "compact", "rewind", "diff", "cost", "tasks"):
        table.add_row(f"/{name}", SLASH_COMMANDS[name]["desc"])

    table.add_row("", "")
    table.add_row("/help",  SLASH_COMMANDS["help"]["desc"])
    table.add_row("/clear", SLASH_COMMANDS["clear"]["desc"])
    table.add_row("/exit",  SLASH_COMMANDS["exit"]["desc"])

    console.print(table)
    console.print(
        "  [dim]Flags work as in the CLI — e.g. "
        "/models --fits-only  ·  /scan --json  ·  /run llama3.2:3b[/dim]\n"
    )


# ── Status probes (used by welcome panel) ──────────────────────────────────────

def _probe_ollama() -> bool:
    """Quick check — is Ollama reachable? Returns False on any failure."""
    try:
        import ollama
        ollama.list()
        return True
    except Exception:
        return False


def _sandbox_status_line() -> str:
    """Render a welcome-panel row for the bash sandbox."""
    try:
        import platform
        from tinillm.agent.sandbox import detect
        backend = detect()
        if backend.available and backend.name == "bwrap":
            return "  [dim]sandbox  [/][bold #22c55e]●[/] [dim]bwrap[/]"
        if platform.system() == "Linux":
            return "  [dim]sandbox  ○ off  ([bold]apt install bubblewrap[/])[/dim]"
        return f"  [dim]sandbox  ○ n/a on {platform.system()}[/]"
    except Exception:
        return "  [dim]sandbox  ? unknown[/]"


# ── Welcome screen ────────────────────────────────────────────────────────────

def _get_recent_commands(n: int = 5) -> list[str]:
    """Read last n commands from ~/.tinillm_history."""
    if not HISTORY_FILE.exists():
        return []
    try:
        raw = HISTORY_FILE.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    commands = [
        line[1:].strip()
        for line in raw.splitlines()
        if line.startswith("+") and line[1:].strip()
    ]
    return commands[-n:][::-1]


_TINILLM_BANNER = (
    "[bold #7c3aed]"
    "████████╗██╗███╗   ██╗██╗██╗     ██╗     ███╗   ███╗\n"
    "╚══██╔══╝██║████╗  ██║██║██║     ██║     ████╗ ████║\n"
    "   ██║   ██║██╔██╗ ██║██║██║     ██║     ██╔████╔██║\n"
    "   ██║   ██║██║╚██╗██║██║██║     ██║     ██║╚██╔╝██║\n"
    "   ██║   ██║██║ ╚████║██║███████╗███████╗██║ ╚═╝ ██║\n"
    "   ╚═╝   ╚═╝╚═╝  ╚═══╝╚═╝╚══════╝╚══════╝╚═╝     ╚═╝"
    "[/]"
)


def render_welcome(console) -> None:
    """Render the welcome panel — full TINILLM banner over a 2-col info grid."""
    from rich.console import Group
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from tinillm import __version__

    username = getpass.getuser().capitalize()
    cwd = str(Path.cwd()).replace(str(Path.home()), "~")

    ollama_up = _probe_ollama()
    status_line = (
        "  [dim]ollama   [/][bold #22c55e]●[/] [dim]running[/]"
        if ollama_up
        else "  [dim]ollama   ○ not running[/]"
    )
    sandbox_line = _sandbox_status_line()

    left_text = (
        f"  [bold]Welcome back, {username}![/]\n\n"
        f"  [dim]v{__version__} · tinillm[/]\n"
        f"  [dim]{cwd}[/]\n"
        f"{status_line}\n"
        f"{sandbox_line}"
    )

    tips = (
        "[bold #a78bfa]Tips for getting started[/]\n"
        f"[dim]{'─' * 40}[/]\n"
        "  Run [bold #a78bfa]/scan[/]       to detect your hardware\n"
        "  Run [bold #a78bfa]/models[/]     to browse compatible LLMs\n"
        "  Run [bold #a78bfa]/run[/]        to launch a model in Ollama\n"
        "  Run [bold #a78bfa]/recommend[/]  for a personalised pick\n"
        "  Run [bold #a78bfa]/doctor[/]     for a system health check\n"
        "  Run [bold #a78bfa]/help[/]       to list all commands\n"
    )

    recent_cmds = _get_recent_commands()
    recent = (
        "\n[bold #a78bfa]Recent activity[/]\n"
        f"[dim]{'─' * 40}[/]\n"
    )
    if recent_cmds:
        for cmd in recent_cmds:
            recent += f"  [dim]{cmd}[/]\n"
    else:
        recent += "  [dim]No recent activity[/]\n"

    right_text = tips + recent

    grid = Table.grid(expand=True, padding=(0, 1))
    grid.add_column(ratio=2, min_width=30)
    grid.add_column(ratio=3)
    grid.add_row(left_text, right_text)

    banner = Text.from_markup(_TINILLM_BANNER, justify="center")

    panel = Panel(
        Group(banner, Text(""), grid),
        title=f"[dim]─── tinillm v{__version__} ───[/dim]",
        title_align="left",
        border_style="#7c3aed",
        padding=(1, 2),
    )
    console.print(panel)
    console.print(
        "  [dim]Type [bold]/help[/] for commands · "
        "[bold]/exit[/] or Ctrl+D to quit[/dim]\n"
    )


# ── First-run detection ────────────────────────────────────────────────────────

def _is_first_launch() -> bool:
    """Return True on the very first REPL launch on this machine."""
    return not FIRST_LAUNCH_MARKER.exists()


def _mark_first_launch_done() -> None:
    """Create the first-launch marker file. Silent on failure."""
    try:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        FIRST_LAUNCH_MARKER.touch()
    except OSError:
        # Permission / disk issue — skip quietly; worst case auto-scan
        # runs again next launch, which is harmless.
        pass


def _run_first_launch_scan(console) -> None:
    """Auto-invoke /scan on the first launch to show immediate value."""
    console.print("[dim]─── First run — here's your hardware ───[/dim]\n")
    _invoke_click(COMMAND_REGISTRY["scan"], [], console)
    console.print()
    _mark_first_launch_done()


def _run_startup_checks(console) -> None:
    """Auto-invoke /scan followed by /doctor on every launch.

    Keeps the user oriented: hardware snapshot + health of Ollama / models /
    memory, surfaced before the prompt appears.
    """
    console.print("[dim]─── Startup checks ───[/dim]\n")
    _invoke_click(COMMAND_REGISTRY["scan"], [], console)
    console.print()
    _invoke_click(COMMAND_REGISTRY["doctor"], [], console)
    console.print()


# ── Main REPL loop ─────────────────────────────────────────────────────────────

def run_repl() -> None:
    """Enter the interactive REPL.

    Called from `tinillm/main.py` when the user runs bare `tinillm`.
    """
    from rich.console import Console
    from tinillm.render.styles import TINILLM_THEME

    console = Console(theme=TINILLM_THEME, highlight=False)
    render_welcome(console)

    # Silent, idempotent: creates ~/.tinillm/memory/ skeleton on first ever
    # run, and the per-project subdir on first visit to a new repo. Safe to
    # call every launch; noop if memory is disabled.
    try:
        from tinillm.memory.paths import memory_disabled
        from tinillm.memory.bootstrap import init_if_missing
        if not memory_disabled():
            init_if_missing()
    except Exception:
        pass

    # Auto /scan + /doctor on every launch so users always see hardware +
    # health before the prompt. First-launch marker is retained so future
    # onboarding tweaks (welcome wizard, etc.) can still opt into "once only"
    # behaviour without flipping it back on here.
    _run_startup_checks(console)
    if _is_first_launch():
        _mark_first_launch_done()

    session = _make_session()
    chat = None  # lazy — only created when the user first talks to the agent

    prompt_fragments = [
        ("class:prompt", "│ "),
    ]

    # Deferred import: ChatSession is the recognizer for in-chat slash verbs.
    # Imported lazily so slash-only users don't pay the ollama import cost.
    from tinillm.run.chat_session import ChatSession

    while True:
        try:
            line = session.prompt(prompt_fragments).strip()
        except KeyboardInterrupt:
            console.print("[dim](Ctrl+C — type /exit or Ctrl+D to quit)[/dim]")
            continue
        except EOFError:
            console.print("\n[dim]Goodbye.[/dim]")
            break

        if not line:
            continue

        # Terminal commands — handled here so Ctrl+D parity works.
        if line in ("/exit", "/quit", "/bye"):
            break
        if line == "/clear":
            os.system("cls" if os.name == "nt" else "clear")
            continue
        if line == "/help":
            _render_help(console)
            continue

        # In-chat agent commands (/plan, /cost, /compact, …): need a session.
        if ChatSession.is_in_chat_slash(line):
            chat = _ensure_chat(chat, console)
            if chat is not None:
                chat.handle_slash(line)
            continue

        # Regular slash commands — /scan, /models, /run, /chat, etc.
        if line.startswith("/"):
            # /chat (re)initialises or resumes the agent explicitly. Shelling
            # out to the Click command would spawn a second prompt loop; route
            # it through the session here instead so free text keeps working.
            head = line.split(maxsplit=1)[0]
            if head == "/chat":
                chat = _ensure_chat(chat, console)
                continue
            _dispatch_click_slash(line, console)
            continue

        # Natural language → agent. Lazily create the session on first use.
        chat = _ensure_chat(chat, console)
        if chat is not None:
            chat.handle_user_turn(line)
