"""Windows GPU detection via PowerShell WMI."""

from __future__ import annotations

import json
import subprocess
import sys
from typing import List

from tinillm.hardware.types import GpuInfo

# WMI AdapterRAM is 32-bit, capped at ~4 GB for high-VRAM cards.
# Name-based VRAM override table for common discrete GPUs (GB).
_VRAM_OVERRIDE: dict[str, float] = {
    # NVIDIA RTX 50
    "RTX 5090": 32.0,
    "RTX 5080": 16.0,
    # NVIDIA RTX 40
    "RTX 4090": 24.0,
    "RTX 4080 SUPER": 16.0,
    "RTX 4080": 16.0,
    "RTX 4070 TI SUPER": 16.0,
    "RTX 4070 TI": 12.0,
    "RTX 4070 SUPER": 12.0,
    "RTX 4070": 12.0,
    "RTX 4060 TI": 16.0,
    "RTX 4060": 8.0,
    # NVIDIA RTX 30
    "RTX 3090 TI": 24.0,
    "RTX 3090": 24.0,
    "RTX 3080 TI": 12.0,
    "RTX 3080": 10.0,
    "RTX 3070 TI": 8.0,
    "RTX 3070": 8.0,
    "RTX 3060 TI": 8.0,
    "RTX 3060": 12.0,
    # NVIDIA RTX 20
    "RTX 2080 TI": 11.0,
    "RTX 2080 SUPER": 8.0,
    "RTX 2080": 8.0,
    "RTX 2070 SUPER": 8.0,
    "RTX 2070": 8.0,
    "RTX 2060 SUPER": 8.0,
    "RTX 2060": 6.0,
    # AMD RX 7000
    "RX 7900 XTX": 24.0,
    "RX 7900 XT": 20.0,
    "RX 7800 XT": 16.0,
    "RX 7700 XT": 12.0,
    "RX 7600": 8.0,
    # AMD RX 6000
    "RX 6900 XT": 16.0,
    "RX 6800 XT": 16.0,
    "RX 6800": 16.0,
    "RX 6700 XT": 12.0,
    "RX 6700": 10.0,
    "RX 6600 XT": 8.0,
    "RX 6600": 8.0,
    # AMD RX 9000
    "RX 9070 XT": 16.0,
    "RX 9070": 16.0,
}

_SKIP_NAMES = {"Microsoft Basic Display", "Basic Display", "VMware", "VirtualBox"}


def detect_windows_gpus() -> List[GpuInfo]:
    if sys.platform != "win32":
        return []

    ps_script = (
        "Get-WmiObject Win32_VideoController "
        "| Select-Object Name,AdapterRAM "
        "| ConvertTo-Json"
    )
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps_script],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode != 0 or not result.stdout.strip():
            return []

        raw = json.loads(result.stdout)
        # PowerShell returns a dict when there's one GPU, list for multiple
        if isinstance(raw, dict):
            raw = [raw]

        gpus = []
        for item in raw:
            name: str = (item.get("Name") or "").strip()
            if not name:
                continue
            if any(skip in name for skip in _SKIP_NAMES):
                continue

            adapter_ram = item.get("AdapterRAM") or 0
            vram_gb = round(adapter_ram / (1024 ** 3), 1)

            # Fix 32-bit WMI cap: look up real VRAM from override table
            vram_gb = _override_vram(name, vram_gb)

            backend = _detect_backend(name)
            gpus.append(GpuInfo(name=name, vram_gb=vram_gb, backend=backend))

        return gpus
    except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError):
        return []


def _override_vram(name: str, detected_gb: float) -> float:
    """If WMI reported ≤4.3 GB for a known high-VRAM card, use override."""
    if detected_gb > 4.3:
        return detected_gb
    upper = name.upper()
    best_len = 0
    best_val = detected_gb
    for key, val in _VRAM_OVERRIDE.items():
        if key in upper and len(key) > best_len:
            best_len = len(key)
            best_val = val
    return best_val


def _detect_backend(name: str) -> str:
    upper = name.upper()
    if "NVIDIA" in upper or "RTX" in upper or "GTX" in upper or "QUADRO" in upper:
        return "CUDA"
    if "AMD" in upper or "RADEON" in upper or "RX " in upper:
        return "ROCm"
    if "INTEL" in upper and "ARC" in upper:
        return "Vulkan"
    return "DirectX"
