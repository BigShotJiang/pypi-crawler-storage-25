"""RAM detection via psutil — cross-platform."""

from __future__ import annotations


def detect_ram() -> tuple[float, float]:
    """Return (total_gb, free_gb)."""
    try:
        import psutil
        mem = psutil.virtual_memory()
        total_gb = mem.total / (1024 ** 3)
        free_gb = mem.available / (1024 ** 3)
        return round(total_gb, 1), round(free_gb, 1)
    except Exception:
        return 0.0, 0.0
