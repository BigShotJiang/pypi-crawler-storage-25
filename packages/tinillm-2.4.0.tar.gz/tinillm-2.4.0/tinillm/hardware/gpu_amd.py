"""AMD GPU detection via rocm-smi, with sysfs fallback."""

from __future__ import annotations

import json
import subprocess
import sys
from typing import List

from tinillm.hardware.types import GpuInfo

_SYSFS_AMD_VENDOR = "0x1002"
_MIN_DISCRETE_VRAM_GB = 2.0  # filter out APU/iGPU entries


def detect_amd_gpus() -> List[GpuInfo]:
    if sys.platform not in ("linux",):
        return []

    gpus = _from_rocm_smi_json()
    if not gpus:
        gpus = _from_rocm_smi_text()
    if not gpus:
        gpus = _from_sysfs()

    return [g for g in gpus if g.vram_gb >= _MIN_DISCRETE_VRAM_GB]


def _from_rocm_smi_json() -> List[GpuInfo]:
    try:
        result = subprocess.run(
            ["rocm-smi", "--showmeminfo", "vram", "--json"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0:
            return []
        data = json.loads(result.stdout)
        gpus = []
        for card_key, card_data in data.items():
            if not isinstance(card_data, dict):
                continue
            vram_bytes_str = (
                card_data.get("VRAM Total Memory (B)")
                or card_data.get("vram_total_memory_b")
                or "0"
            )
            name = card_data.get("Card Series") or card_data.get("card_series") or card_key
            try:
                vram_gb = round(int(vram_bytes_str) / (1024 ** 3), 1)
            except (ValueError, TypeError):
                vram_gb = 0.0
            gpus.append(GpuInfo(name=name, vram_gb=vram_gb, backend="ROCm"))
        return gpus
    except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError, ValueError):
        return []


def _from_rocm_smi_text() -> List[GpuInfo]:
    """Parse rocm-smi text output as a fallback."""
    try:
        result = subprocess.run(
            ["rocm-smi", "--showmeminfo", "vram"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0:
            return []
        gpus = []
        vram_gb = 0.0
        name = "AMD GPU"
        for line in result.stdout.splitlines():
            line = line.strip()
            if "GPU" in line and ":" in line:
                # Flush previous
                if vram_gb > 0:
                    gpus.append(GpuInfo(name=name, vram_gb=vram_gb, backend="ROCm"))
                    vram_gb = 0.0
                name = line.split(":", 1)[0].strip()
            if "vram total memory" in line.lower():
                try:
                    val = int(line.split()[-2])
                    vram_gb = round(val / (1024 ** 3), 1)
                except (ValueError, IndexError):
                    pass
        if vram_gb > 0:
            gpus.append(GpuInfo(name=name, vram_gb=vram_gb, backend="ROCm"))
        return gpus
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []


def _from_sysfs() -> List[GpuInfo]:
    import os
    gpus: list[GpuInfo] = []
    drm = "/sys/class/drm"
    if not os.path.isdir(drm):
        return []

    seen: set[str] = set()
    for card in sorted(os.listdir(drm)):
        if not card.startswith("card") or "-" in card:
            continue
        device_path = os.path.join(drm, card, "device")
        vendor_path = os.path.join(device_path, "vendor")
        if not os.path.isfile(vendor_path):
            continue
        try:
            vendor = open(vendor_path).read().strip().lower()
        except OSError:
            continue
        if vendor != _SYSFS_AMD_VENDOR:
            continue

        dev_id = os.path.realpath(device_path)
        if dev_id in seen:
            continue
        seen.add(dev_id)

        mem_path = os.path.join(device_path, "mem_info_vram_total")
        vram_gb = 0.0
        if os.path.isfile(mem_path):
            try:
                vram_gb = round(int(open(mem_path).read().strip()) / (1024 ** 3), 1)
            except (ValueError, OSError):
                pass

        # Read card name from product_name or uevent
        name = _amd_card_name(device_path) or "AMD GPU"
        gpus.append(GpuInfo(name=name, vram_gb=vram_gb, backend="ROCm"))

    return gpus


def _amd_card_name(device_path: str) -> str | None:
    import os
    for fname in ("product_name", "label"):
        p = os.path.join(device_path, fname)
        if os.path.isfile(p):
            try:
                return open(p).read().strip()
            except OSError:
                pass
    return None
