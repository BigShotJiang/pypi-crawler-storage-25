"""NVIDIA GPU detection via nvidia-smi, with sysfs fallback."""

from __future__ import annotations

import subprocess
import sys
from collections import Counter
from typing import List

from tinillm.hardware.types import GpuInfo

_SYSFS_NVIDIA_VENDOR = "0x10de"


def detect_nvidia_gpus() -> List[GpuInfo]:
    if sys.platform == "darwin":
        return []

    gpus = _from_nvidia_smi()
    if gpus:
        return gpus
    return _from_sysfs()


def _from_nvidia_smi() -> List[GpuInfo]:
    try:
        result = subprocess.run(
            ["nvidia-smi",
             "--query-gpu=name,memory.total",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0 or not result.stdout.strip():
            return []

        raw: list[tuple[str, float]] = []
        for line in result.stdout.strip().splitlines():
            parts = line.split(",", 1)
            if len(parts) != 2:
                continue
            name = parts[0].strip()
            try:
                vram_gb = round(int(parts[1].strip()) / 1024, 1)
            except ValueError:
                continue
            raw.append((name, vram_gb))

        # Group identical cards
        counts: Counter = Counter()
        vrams: dict[str, float] = {}
        for name, vram in raw:
            counts[name] += 1
            vrams[name] = vram

        return [
            GpuInfo(name=name, vram_gb=vrams[name], backend="CUDA", count=counts[name])
            for name in counts
        ]
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []


def _from_sysfs() -> List[GpuInfo]:
    """Read NVIDIA GPUs from /sys/class/drm without nvidia-smi."""
    if sys.platform != "linux":
        return []

    import os
    gpus: list[GpuInfo] = []
    drm = "/sys/class/drm"
    if not os.path.isdir(drm):
        return []

    seen: set[str] = set()
    for card in sorted(os.listdir(drm)):
        if not card.startswith("card") or card.count("-") > 0:
            continue
        device_path = os.path.join(drm, card, "device")
        vendor_path = os.path.join(device_path, "vendor")
        if not os.path.isfile(vendor_path):
            continue
        try:
            vendor = open(vendor_path).read().strip().lower()
        except OSError:
            continue
        if vendor != _SYSFS_NVIDIA_VENDOR:
            continue

        mem_path = os.path.join(device_path, "mem_info_vram_total")
        vram_gb = 0.0
        if os.path.isfile(mem_path):
            try:
                vram_gb = round(int(open(mem_path).read().strip()) / (1024 ** 3), 1)
            except (ValueError, OSError):
                pass

        # Use device path as identity key to avoid counting render nodes
        dev_id = os.path.realpath(device_path)
        if dev_id in seen:
            continue
        seen.add(dev_id)

        # Try to read GPU name from uevent
        name = _read_gpu_name_from_uevent(device_path) or "NVIDIA GPU"
        gpus.append(GpuInfo(name=name, vram_gb=vram_gb, backend="CUDA"))

    return gpus


def _read_gpu_name_from_uevent(device_path: str) -> str | None:
    import os
    uevent = os.path.join(device_path, "uevent")
    if not os.path.isfile(uevent):
        return None
    try:
        for line in open(uevent):
            if line.startswith("PCI_ID="):
                return f"NVIDIA {line.split('=')[1].strip()}"
    except OSError:
        pass
    return None
