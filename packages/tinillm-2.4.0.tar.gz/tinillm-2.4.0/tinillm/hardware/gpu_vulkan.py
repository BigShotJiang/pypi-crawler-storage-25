"""Vulkan fallback GPU detection via vulkaninfo."""

from __future__ import annotations

import subprocess
from typing import List

from tinillm.hardware.types import GpuInfo

_SOFTWARE_RENDERERS = {"llvmpipe", "lavapipe", "swiftshader", "softpipe", "virgl"}


def detect_vulkan_gpus() -> List[GpuInfo]:
    """Last-resort GPU detection using vulkaninfo --summary."""
    try:
        result = subprocess.run(
            ["vulkaninfo", "--summary"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0:
            return []

        gpus = []
        for line in result.stdout.splitlines():
            line = line.strip()
            if line.lower().startswith("devicename"):
                name_part = line.split("=", 1)
                if len(name_part) < 2:
                    continue
                name = name_part[1].strip()
                if any(sw in name.lower() for sw in _SOFTWARE_RENDERERS):
                    continue
                backend = _infer_backend(name)
                # VRAM is not reported by vulkaninfo summary; use 0 as unknown
                gpus.append(GpuInfo(name=name, vram_gb=0.0, backend=backend))
        return gpus
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []


def _infer_backend(name: str) -> str:
    upper = name.upper()
    if "NVIDIA" in upper or "RTX" in upper or "GTX" in upper:
        return "CUDA"
    if "AMD" in upper or "RADEON" in upper:
        return "ROCm"
    if "INTEL" in upper:
        return "Vulkan"
    return "Vulkan"
