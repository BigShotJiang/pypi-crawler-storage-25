"""GPU memory bandwidth lookup table (GB/s).

Ported from llmfit hardware.rs bandwidth lookup tables.
Used for physics-based tokens/sec estimation:
  tps = bandwidth_GB_s * 0.55 / model_size_GB
"""

from __future__ import annotations

# Key: uppercase substring of GPU name (longer keys take priority)
# Value: memory bandwidth in GB/s
_BANDWIDTH_TABLE: dict[str, float] = {
    # ── NVIDIA RTX 50 ─────────────────────────────────────────────
    "RTX 5090":           1792.0,
    "RTX 5080":            960.0,
    "RTX 5070 TI":         896.0,
    "RTX 5070":            672.0,
    # ── NVIDIA RTX 40 ─────────────────────────────────────────────
    "RTX 4090":           1008.0,
    "RTX 4080 SUPER":      736.0,
    "RTX 4080":            716.8,
    "RTX 4070 TI SUPER":   672.0,
    "RTX 4070 TI":         504.2,
    "RTX 4070 SUPER":      504.2,
    "RTX 4070":            504.2,
    "RTX 4060 TI":         288.0,
    "RTX 4060":            272.0,
    # ── NVIDIA RTX 30 ─────────────────────────────────────────────
    "RTX 3090 TI":        1008.0,
    "RTX 3090":            936.2,
    "RTX 3080 TI":         912.4,
    "RTX 3080":            760.3,
    "RTX 3070 TI":         608.0,
    "RTX 3070":            448.0,
    "RTX 3060 TI":         448.0,
    "RTX 3060":            360.0,
    # ── NVIDIA RTX 20 ─────────────────────────────────────────────
    "RTX 2080 TI":         616.0,
    "RTX 2080 SUPER":      496.1,
    "RTX 2080":            448.0,
    "RTX 2070 SUPER":      448.0,
    "RTX 2070":            448.0,
    "RTX 2060 SUPER":      448.0,
    "RTX 2060":            336.0,
    # ── NVIDIA Data Centre ────────────────────────────────────────
    "H200 SXM":           4800.0,
    "H200":               4800.0,
    "H100 SXM":           3350.0,
    "H100":               3350.0,
    "A100 SXM":           2000.0,
    "A100":               2000.0,
    "L40S":                864.0,
    "L40":                 864.0,
    "A40":                 696.0,
    "A30":                 933.0,
    "T4":                  300.0,
    "V100 SXM":            900.0,
    "V100":                900.0,
    # ── NVIDIA GTX 10 / older ─────────────────────────────────────
    "GTX 1080 TI":         484.4,
    "GTX 1080":            320.3,
    "GTX 1070 TI":         256.3,
    "GTX 1070":            256.3,
    "GTX 1060":            192.2,
    # ── AMD RDNA 4 ────────────────────────────────────────────────
    "RX 9070 XT":          717.0,
    "RX 9070":             644.0,
    # ── AMD RDNA 3 ────────────────────────────────────────────────
    "RX 7900 XTX":         960.0,
    "RX 7900 XT":          800.0,
    "RX 7800 XT":          624.0,
    "RX 7700 XT":          432.0,
    "RX 7600":             288.0,
    # ── AMD RDNA 2 ────────────────────────────────────────────────
    "RX 6900 XT":          512.0,
    "RX 6800 XT":          512.0,
    "RX 6800":             512.0,
    "RX 6700 XT":          384.0,
    "RX 6700":             320.0,
    "RX 6600 XT":          256.0,
    "RX 6600":             224.0,
    # ── AMD CDNA ──────────────────────────────────────────────────
    "MI300X":             5300.0,
    "MI300A":             5300.0,
    "MI250X":             3276.8,
    "MI210":              1638.4,
    # ── Apple Silicon ─────────────────────────────────────────────
    "M4 ULTRA":            819.2,
    "M4 MAX":              546.0,
    "M4 PRO":              273.0,
    "M4":                  120.0,
    "M3 ULTRA":            819.2,
    "M3 MAX":              400.0,
    "M3 PRO":              153.6,
    "M3":                  100.0,
    "M2 ULTRA":            800.0,
    "M2 MAX":              400.0,
    "M2 PRO":              200.0,
    "M2":                  100.0,
    "M1 ULTRA":            800.0,
    "M1 MAX":              400.0,
    "M1 PRO":              200.0,
    "M1":                   68.25,
    # ── Intel Arc ─────────────────────────────────────────────────
    "ARC A770":            560.0,
    "ARC A750":            512.0,
    "ARC A580":            512.0,
    "ARC A380":            186.0,
    "ARC A310":            128.0,
    # ── Intel Battlemage ──────────────────────────────────────────
    "ARC B580":            456.0,
    "ARC B570":            380.0,
}


def gpu_bandwidth_gbps(gpu_name: str) -> float:
    """Return memory bandwidth in GB/s for a GPU name, or 0.0 if unknown.

    Uses longest-match substring so 'RTX 4080 SUPER' matches before 'RTX 4080'.
    """
    upper = gpu_name.upper()
    best_len = 0
    best_val = 0.0
    for key, val in _BANDWIDTH_TABLE.items():
        if key in upper and len(key) > best_len:
            best_len = len(key)
            best_val = val
    return best_val
