"""Top-level hardware detection orchestrator."""

from __future__ import annotations

import sys

from tinillm.hardware.types import SystemSpecs, GpuInfo
from tinillm.hardware.cpu import detect_cpu
from tinillm.hardware.ram import detect_ram
from tinillm.hardware.gpu_nvidia import detect_nvidia_gpus
from tinillm.hardware.gpu_amd import detect_amd_gpus
from tinillm.hardware.gpu_apple import detect_apple_gpus
from tinillm.hardware.gpu_intel import detect_intel_gpus
from tinillm.hardware.gpu_windows import detect_windows_gpus
from tinillm.hardware.gpu_vulkan import detect_vulkan_gpus


def detect() -> SystemSpecs:
    """Detect all hardware and return a populated SystemSpecs."""
    cpu = detect_cpu()
    total_ram_gb, free_ram_gb = detect_ram()
    gpus = _detect_all_gpus(total_ram_gb)

    return SystemSpecs(
        cpu=cpu,
        total_ram_gb=total_ram_gb,
        free_ram_gb=free_ram_gb,
        gpus=gpus,
        os=_os_name(),
    )


def _detect_all_gpus(total_ram_gb: float) -> list[GpuInfo]:
    """Run all GPU detectors in priority order, merge results.

    Priority:
      Windows → use WMI only (covers all vendors).
      Linux/macOS → try platform-specific detectors in parallel order.
    """
    gpus: list[GpuInfo] = []

    if sys.platform == "win32":
        gpus.extend(detect_windows_gpus())
    elif sys.platform == "darwin":
        gpus.extend(detect_apple_gpus(total_ram_gb))
    else:
        # Linux: try each vendor detector independently
        gpus.extend(detect_nvidia_gpus())
        gpus.extend(detect_amd_gpus())
        gpus.extend(detect_intel_gpus())

    # Vulkan fallback — only if nothing found yet
    if not gpus:
        gpus.extend(detect_vulkan_gpus())

    return gpus


def _os_name() -> str:
    if sys.platform == "darwin":
        return "macOS"
    if sys.platform == "win32":
        return "Windows"
    return "Linux"
