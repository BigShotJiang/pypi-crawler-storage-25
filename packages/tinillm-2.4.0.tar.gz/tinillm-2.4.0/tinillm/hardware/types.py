"""Hardware detection data structures."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class CpuInfo:
    model_name: str = "Unknown CPU"
    physical_cores: int = 1
    logical_cores: int = 1
    freq_mhz: float = 0.0


@dataclass
class GpuInfo:
    name: str
    vram_gb: float
    backend: str          # "CUDA" | "ROCm" | "Metal" | "Vulkan" | "DirectX"
    count: int = 1
    unified_memory: bool = False  # Apple Silicon, Grace Blackwell


@dataclass
class SystemSpecs:
    cpu: CpuInfo = field(default_factory=CpuInfo)
    total_ram_gb: float = 0.0
    free_ram_gb: float = 0.0
    gpus: List[GpuInfo] = field(default_factory=list)
    os: str = ""          # "linux" | "darwin" | "windows"
