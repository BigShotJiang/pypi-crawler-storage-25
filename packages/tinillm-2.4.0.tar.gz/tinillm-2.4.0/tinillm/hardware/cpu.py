"""CPU detection via psutil — cross-platform."""

from __future__ import annotations

from tinillm.hardware.types import CpuInfo


def detect_cpu() -> CpuInfo:
    try:
        import psutil

        freq = psutil.cpu_freq()
        freq_mhz = freq.max if freq else 0.0

        physical = psutil.cpu_count(logical=False) or 1
        logical = psutil.cpu_count(logical=True) or physical

        model_name = _read_cpu_model_name()
        return CpuInfo(
            model_name=model_name,
            physical_cores=physical,
            logical_cores=logical,
            freq_mhz=freq_mhz,
        )
    except Exception:
        return CpuInfo()


def _read_cpu_model_name() -> str:
    """Read human-readable CPU name from OS-specific sources."""
    import sys
    import platform

    if sys.platform == "linux":
        try:
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if line.startswith("model name"):
                        return line.split(":", 1)[1].strip()
        except OSError:
            pass

    if sys.platform == "darwin":
        import subprocess
        try:
            result = subprocess.run(
                ["sysctl", "-n", "machdep.cpu.brand_string"],
                capture_output=True, text=True, timeout=5,
            )
            name = result.stdout.strip()
            if name:
                return name
        except Exception:
            pass

    if sys.platform == "win32":
        import subprocess
        try:
            result = subprocess.run(
                ["powershell", "-Command",
                 "(Get-WmiObject Win32_Processor).Name"],
                capture_output=True, text=True, timeout=10,
            )
            name = result.stdout.strip().splitlines()[0].strip()
            if name:
                return name
        except Exception:
            pass

    return platform.processor() or "Unknown CPU"
