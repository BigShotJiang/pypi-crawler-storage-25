"""Intel Arc GPU detection via sysfs and lspci (Linux only)."""

from __future__ import annotations

import subprocess
import sys
from typing import List

from tinillm.hardware.types import GpuInfo

_SYSFS_INTEL_VENDOR = "0x8086"
_MIN_VRAM_GB = 2.0  # filter iGPU entries


def detect_intel_gpus() -> List[GpuInfo]:
    if sys.platform != "linux":
        return []

    gpus = _from_sysfs()
    # Confirm "Arc" discrete GPUs via lspci if any found
    if gpus:
        arc_names = _lspci_arc_names()
        if arc_names:
            # Replace sysfs generic names with lspci names where available
            for i, gpu in enumerate(gpus):
                if arc_names:
                    gpus[i] = GpuInfo(
                        name=arc_names.pop(0),
                        vram_gb=gpu.vram_gb,
                        backend="Vulkan",
                    )
    return [g for g in gpus if g.vram_gb >= _MIN_VRAM_GB]


def _from_sysfs() -> List[GpuInfo]:
    import os
    gpus: list[GpuInfo] = []
    drm = "/sys/class/drm"
    if not os.path.isdir(drm):
        return []

    seen: set[str] = set()
    for card in sorted(os.listdir(drm)):
        if not card.startswith("card") or "-" in card:
            continue
        device_path = os.path.join(drm, card, "device")
        vendor_path = os.path.join(device_path, "vendor")
        if not os.path.isfile(vendor_path):
            continue
        try:
            vendor = open(vendor_path).read().strip().lower()
        except OSError:
            continue
        if vendor != _SYSFS_INTEL_VENDOR:
            continue

        dev_id = os.path.realpath(device_path)
        if dev_id in seen:
            continue
        seen.add(dev_id)

        mem_path = os.path.join(device_path, "mem_info_vram_total")
        if not os.path.isfile(mem_path):
            continue  # iGPU typically has no vram sysfs node
        try:
            vram_gb = round(int(open(mem_path).read().strip()) / (1024 ** 3), 1)
        except (ValueError, OSError):
            continue

        gpus.append(GpuInfo(name="Intel Arc GPU", vram_gb=vram_gb, backend="Vulkan"))

    return gpus


def _lspci_arc_names() -> list[str]:
    """Extract Intel Arc GPU names from lspci output."""
    try:
        result = subprocess.run(
            ["lspci", "-mm"],
            capture_output=True, text=True, timeout=10,
        )
        names = []
        for line in result.stdout.splitlines():
            if "Intel" in line and ("Arc" in line or "Xe" in line):
                # Format: 'BB:DD.F "Class" "Vendor" "Device" ...'
                parts = line.split('"')
                if len(parts) >= 6:
                    names.append(f"Intel {parts[5]}")
        return names
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []
