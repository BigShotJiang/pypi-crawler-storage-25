"""Apple Silicon GPU detection via system_profiler."""

from __future__ import annotations

import json
import subprocess
import sys
from typing import List

from tinillm.hardware.types import GpuInfo


def detect_apple_gpus(total_ram_gb: float) -> List[GpuInfo]:
    """On Apple Silicon, GPU VRAM == total system RAM (unified memory)."""
    if sys.platform != "darwin":
        return []

    chip_name = _detect_chip_name()
    if not chip_name:
        return []

    return [
        GpuInfo(
            name=chip_name,
            vram_gb=total_ram_gb,
            backend="Metal",
            unified_memory=True,
        )
    ]


def _detect_chip_name() -> str | None:
    """Extract chip name, e.g. 'Apple M3 Max'."""
    # Try sysctl first (fast)
    try:
        result = subprocess.run(
            ["sysctl", "-n", "machdep.cpu.brand_string"],
            capture_output=True, text=True, timeout=5,
        )
        name = result.stdout.strip()
        if name and "Apple" in name:
            return name
    except Exception:
        pass

    # Fallback: system_profiler (slower but more reliable)
    try:
        result = subprocess.run(
            ["system_profiler", "SPHardwareDataType", "-json"],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode != 0:
            return None
        data = json.loads(result.stdout)
        hw_items = data.get("SPHardwareDataType", [])
        if hw_items:
            chip = hw_items[0].get("chip_type") or hw_items[0].get("cpu_type", "")
            if chip:
                return chip
    except Exception:
        pass

    # Last resort: check processor name from platform
    import platform
    proc = platform.processor()
    if proc and "Apple" in proc:
        return proc

    return None
