"""User-defined hooks.

Three trigger points, matching claw-code's hook lifecycle:

    pre_tool     before a tool is dispatched
    post_tool    after a tool returns
    pre_prompt   before the user's message is sent to the model

Hook scripts live at ``~/.tinillm/hooks/<name>[.d/*]``. Each script receives a
JSON payload on stdin and may:
  - write a replacement payload to stdout (JSON) — merged back in
  - exit non-zero — cancels the underlying action

Silent on any OS error — hooks should never crash the REPL.
"""
from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from pathlib import Path


HOOKS_ROOT: Path = Path.home() / ".tinillm" / "hooks"
_TIMEOUT = 10


@dataclass
class HookResult:
    ok: bool                     # False if a hook asked to cancel
    payload: dict                # possibly modified payload
    reason: str = ""


def run_hook(trigger: str, payload: dict) -> HookResult:
    """Run every script under ``hooks/<trigger>`` (and ``<trigger>.d/``).

    Scripts run in order; the output of one feeds the next.
    """
    current = dict(payload)
    for script in _scripts_for(trigger):
        try:
            proc = subprocess.run(
                [str(script)],
                input=json.dumps(current),
                capture_output=True,
                text=True,
                timeout=_TIMEOUT,
                env=None,
            )
        except (OSError, subprocess.TimeoutExpired) as e:
            # Hook failure is non-fatal — log would go here in a REPL with logging.
            return HookResult(ok=True, payload=current, reason=f"hook skipped: {e}")
        if proc.returncode != 0:
            return HookResult(
                ok=False,
                payload=current,
                reason=proc.stderr.strip() or f"{script.name} exited {proc.returncode}",
            )
        out = proc.stdout.strip()
        if out:
            try:
                current = json.loads(out)
            except json.JSONDecodeError:
                # Non-JSON stdout is tolerated but ignored.
                pass
    return HookResult(ok=True, payload=current)


def _scripts_for(trigger: str) -> list[Path]:
    scripts: list[Path] = []
    single = HOOKS_ROOT / trigger
    if single.is_file() and _is_executable(single):
        scripts.append(single)
    dir_ = HOOKS_ROOT / f"{trigger}.d"
    if dir_.is_dir():
        scripts.extend(
            sorted(p for p in dir_.iterdir() if p.is_file() and _is_executable(p))
        )
    return scripts


def _is_executable(p: Path) -> bool:
    try:
        return p.stat().st_mode & 0o111 != 0
    except OSError:
        return False
