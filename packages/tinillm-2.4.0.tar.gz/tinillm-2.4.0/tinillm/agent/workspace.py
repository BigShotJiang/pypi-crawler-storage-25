"""Workspace root + boundary guard.

Ported from claw-code runtime/src/file_ops.rs::validate_workspace_boundary
and is_symlink_escape. Prevents tools from reading/writing outside the
project root and from following symlinks that escape it.
"""
from __future__ import annotations

import os
from pathlib import Path


class WorkspaceError(Exception):
    pass


class Workspace:
    """The current working project root.

    A path is "inside" the workspace if its resolved (symlink-followed)
    form is a descendant of the workspace root. Absolute paths outside
    that tree are rejected.
    """

    def __init__(self, root: Path | str | None = None) -> None:
        if root is None:
            root = Path.cwd()
        self.root: Path = Path(root).expanduser().resolve()

    # ── Path resolution ────────────────────────────────────────────────────

    def resolve(self, relative_or_absolute: str, *, allow_missing: bool = False) -> Path:
        """Normalise ``path`` and ensure it stays inside the workspace.

        - Relative paths resolve against the workspace root.
        - Absolute paths must already be inside the workspace root.
        - Symlinks that escape the root raise WorkspaceError.
        """
        p = Path(relative_or_absolute).expanduser()
        if not p.is_absolute():
            p = self.root / p
        resolved = self._safe_resolve(p, allow_missing=allow_missing)
        self._check_boundary(resolved)
        return resolved

    def is_inside(self, path: Path) -> bool:
        try:
            resolved = path.resolve(strict=False)
        except OSError:
            return False
        try:
            resolved.relative_to(self.root)
            return True
        except ValueError:
            return False

    # ── Internals ──────────────────────────────────────────────────────────

    def _safe_resolve(self, path: Path, *, allow_missing: bool) -> Path:
        if not allow_missing:
            try:
                return path.resolve(strict=True)
            except FileNotFoundError as e:
                raise WorkspaceError(f"Path does not exist: {path}") from e
        try:
            return path.resolve(strict=False)
        except OSError:
            pass
        # Missing leaf is OK when allow_missing — synthesize through parent
        # so we can still boundary-check where the file *would* be written.
        parent = path.parent
        try:
            parent_resolved = parent.resolve(strict=True)
        except FileNotFoundError:
            # Walk up until we find an existing ancestor, then re-attach the tail.
            tail: list[str] = [path.name]
            cur = parent
            while True:
                if cur.exists():
                    parent_resolved = cur.resolve(strict=True)
                    break
                tail.append(cur.name)
                if cur.parent == cur:  # root
                    parent_resolved = cur
                    break
                cur = cur.parent
            for segment in reversed(tail):
                parent_resolved = parent_resolved / segment
            return parent_resolved
        return parent_resolved / path.name

    def _check_boundary(self, resolved: Path) -> None:
        try:
            resolved.relative_to(self.root)
        except ValueError as e:
            raise WorkspaceError(
                f"Path escapes workspace root: {resolved} (root: {self.root})"
            ) from e

    # ── Symlink escape ─────────────────────────────────────────────────────

    def is_symlink_escape(self, path: Path) -> bool:
        """True if ``path`` is a symlink whose target escapes the workspace."""
        if not path.is_symlink():
            return False
        try:
            target = os.readlink(path)
        except OSError:
            return False
        target_path = Path(target)
        if not target_path.is_absolute():
            target_path = (path.parent / target_path).resolve(strict=False)
        else:
            target_path = target_path.resolve(strict=False)
        try:
            target_path.relative_to(self.root)
            return False
        except ValueError:
            return True
