"""Trimmed MCP stdio client.

Model Context Protocol servers speak JSON-RPC over stdio. Claw's client is
2.9 kLOC; tinillm's subset covers:

    initialize                handshake + capability negotiation
    tools/list                enumerate tools the server exposes
    tools/call                invoke one
    resources/list + read     optional read-only resources
    notifications/initialized shutdown-safe close

Servers are configured in ``~/.tinillm/mcp.json``:

    {
      "servers": {
        "my-server": {"command": ["npx", "-y", "@some/mcp-server"]}
      }
    }
"""
from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


_CONFIG_PATH: Path = Path.home() / ".tinillm" / "mcp.json"
_RPC_TIMEOUT = 30


class McpError(Exception):
    pass


@dataclass
class McpServerSpec:
    name: str
    command: list[str]
    env: dict[str, str] | None = None


@dataclass
class McpTool:
    server: str
    name: str
    description: str
    input_schema: dict


@dataclass
class McpClient:
    spec: McpServerSpec
    proc: subprocess.Popen | None = None
    _next_id: int = 1
    _initialized: bool = False
    tools: list[McpTool] = field(default_factory=list)

    def start(self) -> None:
        if not shutil.which(self.spec.command[0]):
            raise McpError(f"MCP command not found: {self.spec.command[0]}")
        self.proc = subprocess.Popen(
            self.spec.command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            env=self.spec.env,
        )
        self._rpc(
            "initialize",
            {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "tinillm", "version": "1.9.0"},
            },
        )
        self._notify("notifications/initialized", {})
        self._initialized = True
        self._refresh_tools()

    def stop(self) -> None:
        if not self.proc:
            return
        try:
            self.proc.stdin.close()  # type: ignore[union-attr]
        except OSError:
            pass
        try:
            self.proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.proc.kill()
        self.proc = None
        self._initialized = False

    def call_tool(self, name: str, arguments: dict) -> str:
        result = self._rpc("tools/call", {"name": name, "arguments": arguments})
        # Per MCP spec the result has a ``content`` array of text/image parts.
        parts = result.get("content", []) if isinstance(result, dict) else []
        text_chunks = [p.get("text", "") for p in parts if p.get("type") == "text"]
        return "\n".join(text_chunks) or json.dumps(result)

    # ── RPC plumbing ───────────────────────────────────────────────────────

    def _rpc(self, method: str, params: dict) -> Any:
        if not self.proc:
            raise McpError(f"{self.spec.name} not started")
        rid = self._next_id
        self._next_id += 1
        payload = {"jsonrpc": "2.0", "id": rid, "method": method, "params": params}
        self._send(payload)
        resp = self._recv()
        if "error" in resp:
            err = resp["error"]
            raise McpError(f"{self.spec.name}: {err.get('message', err)}")
        return resp.get("result")

    def _notify(self, method: str, params: dict) -> None:
        self._send({"jsonrpc": "2.0", "method": method, "params": params})

    def _send(self, message: dict) -> None:
        assert self.proc and self.proc.stdin
        self.proc.stdin.write(json.dumps(message) + "\n")
        self.proc.stdin.flush()

    def _recv(self) -> dict:
        assert self.proc and self.proc.stdout
        line = self.proc.stdout.readline()
        if not line:
            raise McpError(f"{self.spec.name} closed stdout unexpectedly")
        try:
            return json.loads(line)
        except json.JSONDecodeError as e:
            raise McpError(f"{self.spec.name} sent invalid JSON: {e}") from e

    def _refresh_tools(self) -> None:
        result = self._rpc("tools/list", {})
        self.tools = []
        for t in result.get("tools", []) if isinstance(result, dict) else []:
            self.tools.append(
                McpTool(
                    server=self.spec.name,
                    name=t.get("name", ""),
                    description=t.get("description", ""),
                    input_schema=t.get("inputSchema", {}),
                )
            )


def load_config() -> list[McpServerSpec]:
    """Parse ``~/.tinillm/mcp.json`` into server specs. Returns [] if missing."""
    if not _CONFIG_PATH.exists():
        return []
    try:
        raw = json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    servers_raw = raw.get("servers", {}) if isinstance(raw, dict) else {}
    out: list[McpServerSpec] = []
    for name, conf in servers_raw.items():
        if not isinstance(conf, dict):
            continue
        cmd = conf.get("command")
        if not cmd:
            continue
        if isinstance(cmd, str):
            cmd = [cmd]
        out.append(McpServerSpec(name=name, command=list(cmd), env=conf.get("env")))
    return out
