"""Permission modes + enforcer.

Three modes mirrored from claw-code:

    read-only            Only read_file / glob_search / grep_search allowed.
                         All writes, bash, MCP calls denied.
    workspace-write      Reads + writes inside the workspace root.
                         Bash runs, but destructive patterns ask first.
    danger-full-access   No gating. User explicitly opts in.

The enforcer holds the current mode and is consulted by every tool before
execution. Tools raise PermissionDenied on a deny.
"""
from __future__ import annotations

import fnmatch
import re
from dataclasses import dataclass, field
from enum import Enum


class PermissionMode(str, Enum):
    READ_ONLY = "read-only"
    WORKSPACE_WRITE = "workspace-write"
    DANGER_FULL_ACCESS = "danger-full-access"

    @classmethod
    def parse(cls, text: str) -> "PermissionMode":
        norm = text.strip().lower().replace("_", "-")
        for m in cls:
            if m.value == norm:
                return m
        raise ValueError(f"Unknown permission mode: {text}")


class PermissionDenied(Exception):
    """Raised when a tool call is blocked by the current permission mode."""


# Tools grouped by what they do — used by the enforcer to decide allow/deny.
_READ_TOOLS = frozenset({
    "read_file",
    "glob_search",
    "grep_search",
    "TodoWrite",        # in-memory list, not persistent
    "AskUserQuestion",
    "ListMcpResources",
    "ReadMcpResource",
})

_WRITE_TOOLS = frozenset({
    "write_file",
    "edit_file",
    "NotebookEdit",
})

_EXEC_TOOLS = frozenset({
    "bash",
    "McpInvoke",
    "Skill",
})

# Bash patterns that look destructive enough to always warn, even in
# workspace-write mode. List extracted from claw-code bash_validation.rs.
_DESTRUCTIVE_BASH_PATTERNS = [
    re.compile(r"\brm\s+-[a-z]*r[a-z]*f\b", re.I),
    re.compile(r"\brm\s+-[a-z]*f[a-z]*r\b", re.I),
    re.compile(r"\bmkfs\.\w+\b", re.I),
    re.compile(r"\bdd\s+if=.*of=/dev/", re.I),
    re.compile(r">\s*/dev/sd", re.I),
    re.compile(r"\bshutdown\b", re.I),
    re.compile(r"\breboot\b", re.I),
    re.compile(r"\bkill\s+-9\s+1\b"),
    re.compile(r":\(\)\s*\{.*\};:"),  # fork bomb
    re.compile(r"\bsudo\s+rm\b", re.I),
    re.compile(r"\bgit\s+push\s+.*--force", re.I),
    re.compile(r"\bgit\s+reset\s+--hard", re.I),
]


@dataclass
class Decision:
    """Result of a permission check."""
    allowed: bool
    reason: str = ""
    ask_user: bool = False


@dataclass(frozen=True)
class _Pattern:
    """A parsed ``tool(arg-glob)`` rule."""
    tool: str
    arg_glob: str | None  # None = bare tool name, match any args


def _parse_pattern(raw: str) -> _Pattern:
    """``bash(rm *)`` → Pattern(tool="bash", arg_glob="rm *"). ``bash`` → Pattern("bash", None)."""
    s = raw.strip()
    if s.endswith(")") and "(" in s:
        tool, _, tail = s.partition("(")
        return _Pattern(tool=tool.strip(), arg_glob=tail[:-1])
    return _Pattern(tool=s, arg_glob=None)


def _pattern_matches(pat: _Pattern, tool_name: str, args: dict) -> bool:
    if pat.tool != "*" and pat.tool != tool_name:
        return False
    if pat.arg_glob is None or pat.arg_glob == "*":
        return True
    # Arg matching: pick the most relevant arg for the tool.
    subject = _arg_subject(tool_name, args)
    return fnmatch.fnmatchcase(subject, pat.arg_glob)


def _arg_subject(tool_name: str, args: dict) -> str:
    """Return the string to glob-match against for a given tool."""
    if tool_name == "bash":
        return str(args.get("command", ""))
    if tool_name in {"read_file", "write_file", "edit_file"}:
        return str(args.get("path", ""))
    if tool_name in {"glob_search", "grep_search"}:
        return str(args.get("pattern", ""))
    # Fallback: join all string args.
    return " ".join(str(v) for v in args.values())


def _any_match(patterns, tool_name: str, args: dict) -> bool:
    for raw in patterns:
        if _pattern_matches(_parse_pattern(raw), tool_name, args):
            return True
    return False


@dataclass
class PermissionEnforcer:
    """Mutable mode holder consulted by every tool."""
    mode: PermissionMode = PermissionMode.WORKSPACE_WRITE
    # Legacy set-based surface (bare tool names). Kept for backwards compat.
    allowed_tools: set[str] | None = None
    denied_tools: set[str] = field(default_factory=set)
    # Pattern-based rules from settings.json. Deny beats allow beats mode.
    allow_patterns: list[str] = field(default_factory=list)
    deny_patterns: list[str] = field(default_factory=list)

    def set_mode(self, mode: PermissionMode | str) -> None:
        self.mode = mode if isinstance(mode, PermissionMode) else PermissionMode.parse(mode)

    # ── Core check ─────────────────────────────────────────────────────────
    def check(self, tool_name: str, args: dict | None = None) -> Decision:
        args = args or {}

        # Deny patterns first — highest priority.
        if self.deny_patterns and _any_match(self.deny_patterns, tool_name, args):
            return Decision(False, f"{tool_name} matches a deny rule.")

        if tool_name in self.denied_tools:
            return Decision(False, f"{tool_name} is explicitly denied.")

        # Allow patterns short-circuit the mode check.
        if self.allow_patterns and _any_match(self.allow_patterns, tool_name, args):
            return Decision(True)

        if self.allowed_tools is not None and tool_name not in self.allowed_tools:
            return Decision(False, f"{tool_name} is not in --allowedTools list.")

        if self.mode == PermissionMode.DANGER_FULL_ACCESS:
            return Decision(True)

        if self.mode == PermissionMode.READ_ONLY:
            if tool_name in _READ_TOOLS:
                return Decision(True)
            return Decision(False, f"{tool_name} denied in read-only mode.")

        # workspace-write
        if tool_name in _READ_TOOLS or tool_name in _WRITE_TOOLS:
            return Decision(True)
        if tool_name == "bash":
            cmd = args.get("command", "") if isinstance(args, dict) else ""
            if _looks_destructive(cmd):
                return Decision(
                    True,
                    f"bash command looks destructive — confirm before running.",
                    ask_user=True,
                )
            return Decision(True)
        if tool_name in _EXEC_TOOLS:
            return Decision(True, ask_user=True)
        return Decision(True)  # unknown tools default-allowed in workspace-write


def _looks_destructive(command: str) -> bool:
    return any(p.search(command) for p in _DESTRUCTIVE_BASH_PATTERNS)
