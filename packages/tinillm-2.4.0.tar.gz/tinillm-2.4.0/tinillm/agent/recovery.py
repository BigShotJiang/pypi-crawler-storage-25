"""Recovery recipes — canned playbooks for common error shapes.

Claw ships a large catalog of recipes keyed off error strings (tool-not-found,
permission-denied, etc.). tinillm's subset is small on purpose: we only match
the handful that actually occur in the local-Ollama loop.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Recipe:
    label: str
    hint: str                 # what to tell the user
    retry: bool               # whether the loop should retry automatically


_RECIPES: list[tuple[str, Recipe]] = [
    (
        "does not support tools",
        Recipe(
            label="model-no-tools",
            hint="This model doesn't support tool calling. Falling back to plain chat.",
            retry=True,
        ),
    ),
    (
        "Connection refused",
        Recipe(
            label="ollama-not-running",
            hint="Ollama isn't running. Start it with `ollama serve` in another terminal.",
            retry=False,
        ),
    ),
    (
        "model not found",
        Recipe(
            label="model-missing",
            hint="Pull the model first: `ollama pull <tag>`.",
            retry=False,
        ),
    ),
    (
        "Path escapes workspace",
        Recipe(
            label="escape-workspace",
            hint="The tool tried to touch a file outside the project root. Denied.",
            retry=False,
        ),
    ),
    (
        "old_string not found",
        Recipe(
            label="edit-not-found",
            hint="The snippet to replace wasn't found. Read the file first and copy bytes exactly.",
            retry=True,
        ),
    ),
]


def match(error: str) -> Recipe | None:
    low = error.lower()
    for needle, recipe in _RECIPES:
        if needle.lower() in low:
            return recipe
    return None
