"""Skill loader — pull user-defined ``*.md`` skills into the session prompt.

Directory layout mirrors Claude Code:

    ~/.tinillm/skills/<name>.md          user-wide
    <project>/.tinillm/skills/<name>.md  per-project

Each file is a short markdown brief. The ``/skills`` command lists them;
``/skill <name>`` appends one to the system prompt.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


GLOBAL_SKILLS_DIR: Path = Path.home() / ".tinillm" / "skills"


@dataclass
class Skill:
    name: str
    path: Path
    description: str          # first non-empty line of the file
    content: str


def discover(cwd: Path | str | None = None) -> list[Skill]:
    """Return every skill from the global + project dirs, de-duped by name."""
    seen: dict[str, Skill] = {}
    for d in (_project_dir(cwd), GLOBAL_SKILLS_DIR):
        if not d.exists():
            continue
        for p in sorted(d.glob("*.md")):
            s = _read_skill(p)
            if s and s.name not in seen:
                seen[s.name] = s
    return list(seen.values())


def load(name: str, cwd: Path | str | None = None) -> Skill | None:
    for s in discover(cwd):
        if s.name == name:
            return s
    return None


def _project_dir(cwd: Path | str | None) -> Path:
    root = Path(cwd) if cwd else Path.cwd()
    return root / ".tinillm" / "skills"


def _read_skill(path: Path) -> Skill | None:
    try:
        content = path.read_text(encoding="utf-8")
    except OSError:
        return None
    description = ""
    for line in content.splitlines():
        line = line.strip().lstrip("# ").strip()
        if line:
            description = line
            break
    return Skill(
        name=path.stem,
        path=path,
        description=description,
        content=content,
    )
