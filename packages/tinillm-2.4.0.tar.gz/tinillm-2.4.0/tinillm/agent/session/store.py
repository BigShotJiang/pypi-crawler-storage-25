"""Per-session JSONL history.

Each chat session gets a fresh file under ``~/.tinillm/sessions/<id>.jsonl``.
Every message (user, assistant, tool) is appended as one JSON line so that
a crashed REPL can be resumed with ``/resume``. Matches claw-code's session
format trimmed to the fields we actually replay.
"""
from __future__ import annotations

import json
import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path


SESSIONS_ROOT: Path = Path.home() / ".tinillm" / "sessions"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class Session:
    id: str
    path: Path
    model: str
    cwd: str
    created_at: str
    messages: list[dict] = field(default_factory=list)

    # The meta file (``<id>.meta.json``) mirrors the frontmatter claw stores
    # at the top of its session files. We keep it separate so the JSONL stays
    # append-only.
    @property
    def meta_path(self) -> Path:
        return self.path.with_suffix(".meta.json")

    def to_meta(self) -> dict:
        return {
            "id": self.id,
            "model": self.model,
            "cwd": self.cwd,
            "created_at": self.created_at,
            "message_count": len(self.messages),
            "updated_at": _now(),
        }


def _to_jsonable(value):
    """Convert Ollama pydantic objects (ToolCall etc.) into plain dicts."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if hasattr(value, "model_dump"):
        return value.model_dump()
    if isinstance(value, dict):
        return {k: _to_jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_jsonable(v) for v in value]
    return str(value)


@dataclass
class SessionStore:
    """Append-only writer that keeps ``session.messages`` in sync with disk."""
    session: Session

    def append(self, message: dict) -> None:
        jsonable = {k: _to_jsonable(v) for k, v in message.items()}
        self.session.messages.append(message)
        line = json.dumps(jsonable, ensure_ascii=False)
        with self.session.path.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
        self._write_meta()

    def replace_all(self, messages: list[dict]) -> None:
        """Rewrite the session file — used after /compact or /rewind."""
        self.session.messages = list(messages)
        tmp = self.session.path.with_suffix(".jsonl.tmp")
        with tmp.open("w", encoding="utf-8") as f:
            for m in messages:
                jsonable = {k: _to_jsonable(v) for k, v in m.items()}
                f.write(json.dumps(jsonable, ensure_ascii=False) + "\n")
        os.replace(tmp, self.session.path)
        self._write_meta()

    def _write_meta(self) -> None:
        meta = self.session.to_meta()
        self.session.meta_path.write_text(
            json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8"
        )


def new_session(model: str, cwd: Path | str | None = None) -> Session:
    SESSIONS_ROOT.mkdir(parents=True, exist_ok=True)
    sid = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
    path = SESSIONS_ROOT / f"{sid}.jsonl"
    path.touch()
    session = Session(
        id=sid,
        path=path,
        model=model,
        cwd=str(Path(cwd) if cwd else Path.cwd()),
        created_at=_now(),
    )
    SessionStore(session)._write_meta()
    return session


def load_session(session_id: str) -> Session:
    path = SESSIONS_ROOT / f"{session_id}.jsonl"
    if not path.exists():
        raise FileNotFoundError(f"No such session: {session_id}")
    meta_path = path.with_suffix(".meta.json")
    meta = {}
    if meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            meta = {}
    messages: list[dict] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                messages.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return Session(
        id=session_id,
        path=path,
        model=meta.get("model", ""),
        cwd=meta.get("cwd", ""),
        created_at=meta.get("created_at", _now()),
        messages=messages,
    )


def list_sessions() -> list[dict]:
    """Return recent sessions newest first (from meta files)."""
    if not SESSIONS_ROOT.exists():
        return []
    metas = sorted(
        SESSIONS_ROOT.glob("*.meta.json"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    out: list[dict] = []
    for mp in metas:
        try:
            out.append(json.loads(mp.read_text(encoding="utf-8")))
        except (json.JSONDecodeError, OSError):
            continue
    return out
