"""/compact + /summary — shrink the conversation without losing continuity.

Claw uses Anthropic's native ``messages.create`` with a compaction prompt. For
Ollama we send the same style of meta-prompt to the local model and swap the
returned summary in for the old turns, keeping the most recent exchanges intact
so the model still has fresh context.
"""
from __future__ import annotations

from dataclasses import dataclass


_COMPACT_PROMPT = """\
Summarize this conversation into a tight briefing a future assistant can resume
from. Keep: user's goals, decisions made, files touched, open questions,
last-known state. Drop: polite filler, exploratory dead-ends, raw tool output
that's no longer relevant. Output plain prose, no headings.
"""

_KEEP_TAIL = 4  # messages at the end of history to keep verbatim


@dataclass
class CompactResult:
    summary: str
    kept: int           # count of verbatim tail messages kept
    dropped: int        # count of older messages folded into the summary


def build_compact_request(messages: list[dict]) -> list[dict]:
    """Construct the messages list for the ollama.chat compaction call."""
    older = messages[:-_KEEP_TAIL] if len(messages) > _KEEP_TAIL else messages
    transcript_lines = []
    for m in older:
        role = m.get("role", "")
        content = m.get("content", "") or ""
        if not content:
            continue
        transcript_lines.append(f"{role.upper()}: {content}")
    transcript = "\n\n".join(transcript_lines)
    return [
        {"role": "system", "content": _COMPACT_PROMPT},
        {"role": "user", "content": transcript or "(empty)"},
    ]


def apply_summary(messages: list[dict], summary: str) -> tuple[list[dict], CompactResult]:
    """Replace older history with a single summary system message."""
    total = len(messages)
    if total <= _KEEP_TAIL:
        # Nothing to compact — return unchanged.
        return messages, CompactResult(summary=summary, kept=total, dropped=0)
    tail = messages[-_KEEP_TAIL:]
    dropped = total - len(tail)
    compacted = [
        {"role": "system", "content": f"[summary of prior conversation]\n{summary}"},
        *tail,
    ]
    return compacted, CompactResult(summary=summary, kept=len(tail), dropped=dropped)
