"""tinillm agent subsystem — tools, permissions, session, MCP, hooks.

Ported from claw-code (https://github.com/ultraworkers/claw-code) and adapted
for the local-Ollama tool-calling loop in tinillm.run.chat.
"""
from __future__ import annotations

from tinillm.agent.permissions import (
    PermissionDenied,
    PermissionEnforcer,
    PermissionMode,
)
from tinillm.agent.rewind import FileSnapshots, rewind_messages
from tinillm.agent.tools.registry import TOOL_SPECS, ToolContext, dispatch
from tinillm.agent.tools.todo import TodoList
from tinillm.agent.usage import UsageTracker
from tinillm.agent.workspace import Workspace, WorkspaceError

__all__ = [
    "FileSnapshots",
    "PermissionDenied",
    "PermissionEnforcer",
    "PermissionMode",
    "TOOL_SPECS",
    "TodoList",
    "ToolContext",
    "UsageTracker",
    "Workspace",
    "WorkspaceError",
    "dispatch",
    "rewind_messages",
]
