"""Sandbox for the agent's ``bash`` tool.

Linux: ``bubblewrap`` (``bwrap``). Read-only rootfs, read-write workspace,
no network unless ``allow_network`` is set. Falls through to unsandboxed
execution on macOS/Windows with a one-time warning.

Not a security boundary against a determined attacker with kernel bugs —
but enough to stop a prompt-injected model from reading ``~/.ssh``,
``~/.aws``, or running an unexpected ``curl | sh`` over the network.
"""
from __future__ import annotations

import platform
import shutil
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class SandboxBackend:
    name: str           # "bwrap" | "sandbox-exec" | "none"
    available: bool     # whether the binary is on PATH and the OS supports it

    def wrap_bash(
        self,
        command: str,
        workspace: Path,
        *,
        allow_network: bool = False,
    ) -> list[str]:
        """Return argv for running ``command`` through ``/bin/bash -lc``.

        When ``name == "none"``, returns the plain ``/bin/bash -lc`` argv so the
        caller can exec it uniformly.
        """
        if self.name == "bwrap" and self.available:
            return _bwrap_argv(command, workspace, allow_network=allow_network)
        return ["/bin/bash", "-lc", command]


def detect() -> SandboxBackend:
    """Pick the best available backend for this OS."""
    system = platform.system()
    if system == "Linux":
        if shutil.which("bwrap"):
            return SandboxBackend(name="bwrap", available=True)
        return SandboxBackend(name="none", available=False)
    # macOS / Windows: no backend in v2.3.0 — falls through unsandboxed.
    return SandboxBackend(name="none", available=False)


def _bwrap_argv(command: str, workspace: Path, *, allow_network: bool) -> list[str]:
    ws = str(workspace.resolve())
    argv: list[str] = [
        "bwrap",
        # Read-only view of the host rootfs (so bash, coreutils, etc. work).
        "--ro-bind", "/", "/",
        # Minimal /dev, /proc, /tmp — order before the workspace bind so a
        # workspace under /tmp isn't clobbered by the tmpfs overlay.
        "--dev", "/dev",
        "--proc", "/proc",
        "--tmpfs", "/tmp",
        # Writable bind of the workspace at the same path. Placed last so it
        # wins over any earlier overlay (e.g. --tmpfs /tmp).
        "--bind", ws, ws,
        # New namespaces; no shared PID/IPC/UTS with the host.
        "--unshare-pid",
        "--unshare-ipc",
        "--unshare-uts",
        "--unshare-cgroup-try",
        # Die when the parent dies so zombies can't outlive the agent.
        "--die-with-parent",
        # Run inside the workspace dir.
        "--chdir", ws,
    ]
    if not allow_network:
        argv.append("--unshare-net")
    argv += ["/bin/bash", "-lc", command]
    return argv
