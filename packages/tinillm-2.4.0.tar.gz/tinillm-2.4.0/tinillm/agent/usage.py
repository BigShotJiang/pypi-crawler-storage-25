"""Usage tracker — tokens in/out across a session.

Ollama returns ``prompt_eval_count`` and ``eval_count`` on every chat response.
We sum those per session and render them through ``/cost``. Pricing is N/A for
local models (free), so we just report counts + wall-clock runtime.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass
class UsageTracker:
    prompt_tokens: int = 0
    completion_tokens: int = 0
    started_at: float = field(default_factory=time.time)
    turns: int = 0

    def record(self, response) -> None:
        """Absorb counts from an ollama.chat response object."""
        self.turns += 1
        self.prompt_tokens += int(getattr(response, "prompt_eval_count", 0) or 0)
        self.completion_tokens += int(getattr(response, "eval_count", 0) or 0)

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens

    def render(self) -> str:
        elapsed = max(0.0, time.time() - self.started_at)
        mins, secs = divmod(int(elapsed), 60)
        return (
            f"turns:       {self.turns}\n"
            f"prompt:      {self.prompt_tokens} tokens\n"
            f"completion:  {self.completion_tokens} tokens\n"
            f"total:       {self.total_tokens} tokens\n"
            f"elapsed:     {mins}m{secs:02d}s\n"
            f"cost:        $0.00 (local model)"
        )
