"""Config loader — ``~/.tinillm/settings.json`` (preferred) with legacy
TOML ``.tinillmrc`` fallback.

The ``Config`` dataclass is kept as the surface-level API used elsewhere in
the codebase. v2.3.0 prefers ``settings.json``; if it is missing, we fall
back to the old TOML file and print a one-time deprecation hint so existing
users aren't surprised.

v2.4.0 will drop the TOML fallback.
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

try:
    import tomllib  # py311+
except ImportError:  # pragma: no cover
    import tomli as tomllib  # type: ignore[no-redef]

from tinillm.agent import settings as _settings


_FILE_NAME = ".tinillmrc"
_DEPRECATION_PRINTED = False


@dataclass
class Config:
    model: str | None = None
    permission_mode: str = "workspace-write"
    # Legacy TOML whitelist: if set, only listed tools are allowed. None = all.
    allowed_tools: list[str] | None = None
    denied_tools: list[str] = field(default_factory=list)
    # JSON settings patterns — "bash(*)", "bash(rm *)"; semantics = override.
    allow_patterns: list[str] = field(default_factory=list)
    deny_patterns: list[str] = field(default_factory=list)
    auto_accept_plan: bool = True
    sandbox_enabled: bool = True
    sandbox_backend: str | None = None
    sandbox_allow_network: bool = False
    system_prompt_path: str | None = None
    extras: dict = field(default_factory=dict)


def load(cwd: Path | str | None = None) -> Config:
    """Prefer ``~/.tinillm/settings.json``; fall back to legacy TOML."""
    s_path = _settings.path()
    if s_path.exists():
        return _from_settings(_settings.load())
    # Legacy TOML path
    toml_cfg = _load_legacy_toml(cwd)
    if toml_cfg is not None:
        _warn_legacy_once()
        return toml_cfg
    return _from_settings(_settings.Settings())


def _from_settings(s: "_settings.Settings") -> Config:
    return Config(
        model=s.model,
        permission_mode=s.permission_mode,
        allowed_tools=None,              # JSON uses allow_patterns instead
        denied_tools=[],
        allow_patterns=list(s.permissions.allow),
        deny_patterns=list(s.permissions.deny),
        auto_accept_plan=s.auto_accept_plan,
        sandbox_enabled=s.sandbox.enabled,
        sandbox_backend=s.sandbox.backend,
        sandbox_allow_network=s.sandbox.allow_network,
        system_prompt_path=s.system_prompt_path,
        extras=dict(s.extras),
    )


def _load_legacy_toml(cwd: Path | str | None) -> Config | None:
    merged: dict = {}
    found = False
    for path in (_home_rc(), _project_rc(Path(cwd) if cwd else Path.cwd())):
        if path and path.exists():
            found = True
            try:
                with path.open("rb") as f:
                    data = tomllib.load(f)
            except (OSError, tomllib.TOMLDecodeError):
                continue
            _deep_merge(merged, data)
    if not found:
        return None
    known = {"model", "permission_mode", "allowed_tools", "denied_tools", "system_prompt_path"}
    extras = {k: v for k, v in merged.items() if k not in known}
    return Config(
        model=merged.get("model"),
        permission_mode=merged.get("permission_mode", "workspace-write"),
        allowed_tools=merged.get("allowed_tools"),
        denied_tools=list(merged.get("denied_tools", [])),
        system_prompt_path=merged.get("system_prompt_path"),
        extras=extras,
    )


def _warn_legacy_once() -> None:
    global _DEPRECATION_PRINTED
    if _DEPRECATION_PRINTED or os.environ.get("TINILLM_NO_DEPRECATION"):
        return
    _DEPRECATION_PRINTED = True
    try:
        print(
            "[tinillm] .tinillmrc (TOML) is deprecated; move settings to "
            "~/.tinillm/settings.json. The TOML loader will be removed in v2.4.",
            file=sys.stderr,
        )
    except OSError:
        pass


def _home_rc() -> Path | None:
    try:
        return Path.home() / _FILE_NAME
    except (OSError, RuntimeError):
        return None


def _project_rc(cwd: Path) -> Path:
    return cwd / _FILE_NAME


def _deep_merge(dst: dict, src: dict) -> None:
    for k, v in src.items():
        if isinstance(v, dict) and isinstance(dst.get(k), dict):
            _deep_merge(dst[k], v)
        else:
            dst[k] = v
