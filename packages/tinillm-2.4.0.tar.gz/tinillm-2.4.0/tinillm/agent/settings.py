"""Global JSON settings at ``~/.tinillm/settings.json``.

Replaces the legacy TOML ``~/.tinillmrc`` as the primary config source. The
schema deliberately mirrors Claude Code's ``settings.json`` so users who
already maintain one can copy the shape over.

Schema::

    {
      "permissions": {
        "allow": ["bash(*)", "read_file(*)", "write_file(src/**)"],
        "deny":  ["bash(rm -rf *)"]
      },
      "model": "qwen2.5-coder:14b",
      "auto_accept_plan": true,
      "sandbox": {
        "enabled": true,
        "backend": null,
        "allow_network": false
      }
    }
"""
from __future__ import annotations

import json
import os
import tempfile
from dataclasses import asdict, dataclass, field
from pathlib import Path


_DIR_NAME = ".tinillm"
_FILE_NAME = "settings.json"


@dataclass
class Permissions:
    allow: list[str] = field(default_factory=list)
    deny: list[str] = field(default_factory=list)


@dataclass
class SandboxConfig:
    enabled: bool = True
    backend: str | None = None  # auto-detect when None
    allow_network: bool = False


@dataclass
class Settings:
    model: str | None = None
    permission_mode: str = "workspace-write"
    permissions: Permissions = field(default_factory=Permissions)
    auto_accept_plan: bool = True
    sandbox: SandboxConfig = field(default_factory=SandboxConfig)
    system_prompt_path: str | None = None
    extras: dict = field(default_factory=dict)


def path() -> Path:
    """Absolute path to ``~/.tinillm/settings.json``."""
    return Path.home() / _DIR_NAME / _FILE_NAME


def load() -> Settings:
    """Read settings.json. Missing or malformed → defaults."""
    p = path()
    if not p.exists():
        return Settings()
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return Settings()
    if not isinstance(data, dict):
        return Settings()
    return _from_dict(data)


def save(**fields) -> Settings:
    """Merge ``fields`` into the current settings and persist atomically.

    Returns the updated ``Settings`` object. Unknown keys are stored under
    ``extras`` so a future field never loses data on round-trip.
    """
    current = load()
    for k, v in fields.items():
        if k == "permissions" and isinstance(v, dict):
            current.permissions = _perms_from_dict(v)
        elif k == "sandbox" and isinstance(v, dict):
            current.sandbox = _sandbox_from_dict(v)
        elif hasattr(current, k):
            setattr(current, k, v)
        else:
            current.extras[k] = v
    _write_atomic(path(), current)
    return current


# ── Internals ────────────────────────────────────────────────────────────────

def _from_dict(data: dict) -> Settings:
    known = {
        "model", "permission_mode", "permissions", "auto_accept_plan",
        "sandbox", "system_prompt_path",
    }
    extras = {k: v for k, v in data.items() if k not in known}
    return Settings(
        model=data.get("model"),
        permission_mode=data.get("permission_mode", "workspace-write"),
        permissions=_perms_from_dict(data.get("permissions") or {}),
        auto_accept_plan=bool(data.get("auto_accept_plan", True)),
        sandbox=_sandbox_from_dict(data.get("sandbox") or {}),
        system_prompt_path=data.get("system_prompt_path"),
        extras=extras,
    )


def _perms_from_dict(d: dict) -> Permissions:
    return Permissions(
        allow=list(d.get("allow", [])),
        deny=list(d.get("deny", [])),
    )


def _sandbox_from_dict(d: dict) -> SandboxConfig:
    return SandboxConfig(
        enabled=bool(d.get("enabled", True)),
        backend=d.get("backend"),
        allow_network=bool(d.get("allow_network", False)),
    )


def _to_jsonable(settings: Settings) -> dict:
    out = {
        "model": settings.model,
        "permission_mode": settings.permission_mode,
        "permissions": asdict(settings.permissions),
        "auto_accept_plan": settings.auto_accept_plan,
        "sandbox": asdict(settings.sandbox),
        "system_prompt_path": settings.system_prompt_path,
    }
    out.update(settings.extras)
    return out


def _write_atomic(target: Path, settings: Settings) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    data = json.dumps(_to_jsonable(settings), indent=2, sort_keys=True).encode("utf-8")
    tmp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            dir=target.parent,
            prefix=f".{target.name}.",
            suffix=".tmp",
            delete=False,
        ) as tmp:
            tmp_path = Path(tmp.name)
            tmp.write(data)
            tmp.flush()
            os.fsync(tmp.fileno())
        os.replace(tmp_path, target)
        tmp_path = None
    finally:
        if tmp_path is not None and tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass
