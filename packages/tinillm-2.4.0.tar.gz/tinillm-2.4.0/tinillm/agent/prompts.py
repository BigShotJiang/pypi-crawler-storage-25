"""System prompt templates + /init project bootstrap.

``/init`` drops a starter ``TINILLM.md`` into the project root — the local
equivalent of ``CLAUDE.md``. Claude Code loads CLAUDE.md automatically; we
mirror that here via ``load_project_prompt``.
"""
from __future__ import annotations

from pathlib import Path


_DEFAULT_PROMPT_FILE = "TINILLM.md"

_DEFAULT_SYSTEM_PROMPT = """\
You are the tinillm agent — a local-LLM coding assistant running inside the
user's terminal. You have file-system tools (read_file, write_file, edit_file),
search tools (glob_search, grep_search), a bash tool, a TodoWrite list, and an
AskUserQuestion pause.

Ground rules:
- Prefer the dedicated tool over bash when one fits.
- Read before you edit. edit_file requires byte-exact snippets.
- Keep answers short. Show code, not narration.
- When a task has multiple steps, use TodoWrite and mark each step done.
"""

_INIT_TEMPLATE = """\
# {project}

> Project brief for tinillm. Edit freely — this file is loaded as system
> context at the start of every chat session.

## What this project is


## How to build / test


## Conventions


## Anything tinillm should always do (or never do)

"""


def default_system_prompt() -> str:
    return _DEFAULT_SYSTEM_PROMPT


def load_project_prompt(cwd: Path | str | None = None) -> str | None:
    """Return the contents of ``TINILLM.md`` in the project root, if present."""
    root = Path(cwd) if cwd else Path.cwd()
    p = root / _DEFAULT_PROMPT_FILE
    if not p.exists() or not p.is_file():
        return None
    try:
        return p.read_text(encoding="utf-8").strip() or None
    except OSError:
        return None


def assemble_system_prompt(cwd: Path | str | None = None, extra: str | None = None) -> str:
    """Build the full system prompt: defaults + TINILLM.md + any extra."""
    parts = [default_system_prompt()]
    project = load_project_prompt(cwd)
    if project:
        parts.append(f"# Project context\n{project}")
    if extra:
        parts.append(extra.strip())
    return "\n\n".join(parts)


def init_project(cwd: Path | str | None = None, *, force: bool = False) -> Path:
    """Create ``TINILLM.md`` in the project root. Returns the path written."""
    root = Path(cwd) if cwd else Path.cwd()
    path = root / _DEFAULT_PROMPT_FILE
    if path.exists() and not force:
        raise FileExistsError(f"{path} already exists — pass force=True to overwrite.")
    content = _INIT_TEMPLATE.format(project=root.name)
    path.write_text(content, encoding="utf-8")
    return path
