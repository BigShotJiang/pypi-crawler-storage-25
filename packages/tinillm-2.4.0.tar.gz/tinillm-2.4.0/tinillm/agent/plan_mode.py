"""Plan mode — read-only scratch space for drafting a plan before touching code.

When the user runs ``/plan``, the enforcer switches to READ_ONLY and the REPL
tells the model to produce a plan rather than execute. ``/plan off`` restores
the previous mode.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from tinillm.agent.permissions import PermissionEnforcer, PermissionMode


_PLAN_READY_SENTINEL = "<!-- plan:ready -->"


_PLAN_SYSTEM_ADDITION = f"""\
You are in PLAN MODE. Produce a concrete plan only — do not write or edit
files, do not run bash. Use read_file/grep_search/glob_search to gather
facts. End with a numbered list of actions the user can approve, followed
by the sentinel marker {_PLAN_READY_SENTINEL} on its own line so the shell
knows the plan is final.
"""


@dataclass
class PlanState:
    active: bool = False
    previous_mode: PermissionMode | None = None
    auto_accept: bool = True


_NUMBERED_LINE = re.compile(r"^\s*\d+\.\s", re.MULTILINE)


def looks_like_final_plan(text: str) -> bool:
    """True when ``text`` looks like a final, user-approvable plan.

    Two signals, either sufficient:
      1. An explicit sentinel (``<!-- plan:ready -->``) the system prompt
         asks the model to emit — most reliable when the model follows
         instructions.
      2. A numbered list of ≥3 items — fallback for models that ignore the
         sentinel. Threshold avoids false positives on casual numbering
         ("1. first try…") in ordinary replies.
    """
    if not text:
        return False
    if _PLAN_READY_SENTINEL in text:
        return True
    return len(_NUMBERED_LINE.findall(text)) >= 3


def enter(enforcer: PermissionEnforcer, state: PlanState) -> None:
    if state.active:
        return
    state.previous_mode = enforcer.mode
    enforcer.set_mode(PermissionMode.READ_ONLY)
    state.active = True


def exit_(enforcer: PermissionEnforcer, state: PlanState) -> None:
    if not state.active:
        return
    if state.previous_mode is not None:
        enforcer.set_mode(state.previous_mode)
    state.active = False
    state.previous_mode = None


def system_addendum() -> str:
    return _PLAN_SYSTEM_ADDITION
