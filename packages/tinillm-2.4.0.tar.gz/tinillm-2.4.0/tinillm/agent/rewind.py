"""/diff + /rewind — turn-level undo.

``rewind`` drops the most recent user+assistant exchange (and any tool
messages between them) from the session so the user can retry with a
different question. Paired with ``SessionStore.replace_all``.

``diff`` shows a unified diff of every file touched this session. The tool
dispatcher records pre-edit snapshots in a FileSnapshots store; diff walks
those against the current on-disk contents.
"""
from __future__ import annotations

import difflib
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class FileSnapshots:
    """Remembers the first pre-write content we saw for each file this session."""
    snapshots: dict[str, str] = field(default_factory=dict)
    created: set[str] = field(default_factory=set)

    def capture(self, path: Path) -> None:
        """Record ``path``'s current content if we haven't seen it this session."""
        key = str(path)
        if key in self.snapshots or key in self.created:
            return
        if not path.exists():
            self.created.add(key)
            return
        try:
            self.snapshots[key] = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            pass

    def diff(self) -> str:
        """Return a unified diff of every tracked file vs. its current state."""
        chunks: list[str] = []
        for key, original in self.snapshots.items():
            p = Path(key)
            try:
                current = p.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            if current == original:
                continue
            chunks.append("\n".join(difflib.unified_diff(
                original.splitlines(),
                current.splitlines(),
                fromfile=f"a/{key}",
                tofile=f"b/{key}",
                lineterm="",
            )))
        for key in self.created:
            p = Path(key)
            if p.exists():
                try:
                    current = p.read_text(encoding="utf-8", errors="replace")
                except OSError:
                    continue
                chunks.append("\n".join(difflib.unified_diff(
                    [],
                    current.splitlines(),
                    fromfile="/dev/null",
                    tofile=f"b/{key}",
                    lineterm="",
                )))
        return "\n\n".join(c for c in chunks if c) or "(no file changes this session)"


def rewind_messages(messages: list[dict], turns: int = 1) -> list[dict]:
    """Drop the last ``turns`` user-led exchanges. Returns a new list."""
    if turns < 1:
        return list(messages)
    result = list(messages)
    removed = 0
    while removed < turns and result:
        # Walk back to the previous user message and cut from there on.
        for i in range(len(result) - 1, -1, -1):
            if result[i].get("role") == "user":
                result = result[:i]
                removed += 1
                break
        else:
            break
    return result
