"""Tool registry + dispatcher.

Every tool goes through ``dispatch``:

    permission check → [user confirm if ask_user] → invoke → render string

The string return type matches what ``ollama.chat`` expects for a
``{"role": "tool"}`` message. Callers that want structured results call the
underlying functions directly.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

import click
from rich.console import Console

from tinillm.agent.permissions import PermissionDenied, PermissionEnforcer
from tinillm.agent.rewind import FileSnapshots
from tinillm.agent.sandbox import SandboxBackend
from tinillm.agent.tools import ask_user as _ask
from tinillm.agent.tools import bash as _bash
from tinillm.agent.tools import file_ops as _fs
from tinillm.agent.tools import search as _search
from tinillm.agent.tools import todo as _todo
from tinillm.agent.workspace import Workspace


# Spec list handed to ollama.chat as the ``tools=`` argument.
TOOL_SPECS = [
    _fs.READ_FILE_SPEC,
    _fs.WRITE_FILE_SPEC,
    _fs.EDIT_FILE_SPEC,
    _search.GLOB_SEARCH_SPEC,
    _search.GREP_SEARCH_SPEC,
    _bash.BASH_SPEC,
    _todo.TODO_WRITE_SPEC,
    _ask.ASK_USER_SPEC,
]


@dataclass
class ToolContext:
    """Everything a tool needs from the session. Passed to ``dispatch``."""
    workspace: Workspace
    enforcer: PermissionEnforcer
    console: Console
    todos: _todo.TodoList = field(default_factory=_todo.TodoList)
    snapshots: FileSnapshots = field(default_factory=FileSnapshots)
    # When True, ask_user confirms are suppressed (useful for --yes / scripts).
    auto_confirm: bool = False
    # Sandbox for the bash tool. None = run unsandboxed.
    sandbox: SandboxBackend | None = None
    sandbox_allow_network: bool = False


def dispatch(ctx: ToolContext, name: str, args: dict[str, Any]) -> str:
    """Run one tool call. Returns a string for the model."""
    decision = ctx.enforcer.check(name, args)
    if not decision.allowed:
        raise PermissionDenied(decision.reason)
    if decision.ask_user and not ctx.auto_confirm:
        ctx.console.print(
            f"[yellow]⚠  {decision.reason or name + ' requires confirmation'}[/yellow]"
        )
        ctx.console.print(f"  [dim]{name}({_short_args(args)})[/dim]")
        if not click.confirm("  Proceed?", default=False):
            return f"User declined to run {name}."

    handler = _HANDLERS.get(name)
    if handler is None:
        return f"Unknown tool: {name}"
    try:
        return handler(ctx, args)
    except PermissionDenied:
        raise
    except Exception as e:
        return f"{name} error: {e}"


# ── Individual handlers ──────────────────────────────────────────────────────

def _h_read_file(ctx: ToolContext, args: dict) -> str:
    r = _fs.read_file(
        ctx.workspace,
        args["path"],
        offset=int(args.get("offset", 0)),
        limit=args.get("limit"),
    )
    header = f"{r.path}  ({r.total_lines} lines"
    if r.truncated:
        header += f", showing {r.offset + 1}–{r.offset + r.limit}"
    header += ")"
    return f"{header}\n{r.content}"


def _h_write_file(ctx: ToolContext, args: dict) -> str:
    target = ctx.workspace.resolve(args["path"], allow_missing=True)
    ctx.snapshots.capture(target)
    r = _fs.write_file(ctx.workspace, args["path"], args["content"])
    verb = "created" if r.created else "updated"
    return f"{verb} {r.path} ({r.bytes_written} bytes)"


def _h_edit_file(ctx: ToolContext, args: dict) -> str:
    target = ctx.workspace.resolve(args["path"])
    ctx.snapshots.capture(target)
    r = _fs.edit_file(
        ctx.workspace,
        args["path"],
        args["old_string"],
        args["new_string"],
        replace_all=bool(args.get("replace_all", False)),
    )
    return f"edited {r.path} ({r.replacements} replacement(s), {len(r.hunks)} hunk(s))"


def _h_glob(ctx: ToolContext, args: dict) -> str:
    r = _search.glob_search(
        ctx.workspace,
        args["pattern"],
        limit=int(args.get("limit", 100)),
    )
    if not r.matches:
        return f"No files match {r.pattern}."
    out = "\n".join(r.matches)
    if r.truncated:
        out += "\n[…results truncated]"
    return out


def _h_grep(ctx: ToolContext, args: dict) -> str:
    r = _search.grep_search(
        ctx.workspace,
        args["pattern"],
        path=args.get("path"),
        glob=args.get("glob"),
        case_insensitive=bool(args.get("case_insensitive", False)),
        limit=int(args.get("limit", 100)),
    )
    if not r.matches:
        return f"No matches for {r.pattern}."
    lines = [f"{m.path}:{m.line}:{m.text}" for m in r.matches]
    if r.truncated:
        lines.append("[…results truncated]")
    return "\n".join(lines)


def _h_bash(ctx: ToolContext, args: dict) -> str:
    r = _bash.run_bash(
        args["command"],
        cwd=ctx.workspace.root,
        timeout=int(args.get("timeout", 30)),
        sandbox=ctx.sandbox,
        allow_network=ctx.sandbox_allow_network,
    )
    parts = [f"$ {r.command}", f"exit: {r.exit_code}"]
    if r.stdout:
        parts.append(f"stdout:\n{r.stdout}")
    if r.stderr:
        parts.append(f"stderr:\n{r.stderr}")
    return "\n".join(parts)


def _h_todo_write(ctx: ToolContext, args: dict) -> str:
    ctx.todos.write(args.get("todos", []))
    return ctx.todos.render()


def _h_ask_user(ctx: ToolContext, args: dict) -> str:
    r = _ask.ask_user(
        args["question"],
        options=args.get("options"),
        console=ctx.console,
    )
    return r.answer or "(no answer)"


_HANDLERS: dict[str, Callable[[ToolContext, dict], str]] = {
    "read_file": _h_read_file,
    "write_file": _h_write_file,
    "edit_file": _h_edit_file,
    "glob_search": _h_glob,
    "grep_search": _h_grep,
    "bash": _h_bash,
    "TodoWrite": _h_todo_write,
    "AskUserQuestion": _h_ask_user,
}


def _short_args(args: dict) -> str:
    parts = []
    for k, v in args.items():
        s = repr(v)
        if len(s) > 60:
            s = s[:57] + "…"
        parts.append(f"{k}={s}")
    return ", ".join(parts)
