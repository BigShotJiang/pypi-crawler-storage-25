"""bash tool — run a shell command with timeout and output truncation.

Ported from claw-code ``runtime/src/bash.rs``. The destructive-pattern check
lives in ``tinillm.agent.permissions`` so the enforcer can flag the command
before we ever spawn a subprocess.
"""
from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path

from tinillm.agent.sandbox import SandboxBackend


_DEFAULT_TIMEOUT = 30          # seconds — matches claw's default
_MAX_OUTPUT_BYTES = 32 * 1024  # 32 KiB — enough for most tool output


@dataclass
class BashResult:
    command: str
    exit_code: int
    stdout: str
    stderr: str
    timed_out: bool
    truncated: bool


def run_bash(
    command: str,
    *,
    cwd: Path | str | None = None,
    timeout: int = _DEFAULT_TIMEOUT,
    env: dict[str, str] | None = None,
    sandbox: SandboxBackend | None = None,
    allow_network: bool = False,
) -> BashResult:
    """Run ``command`` through ``/bin/bash -lc`` and capture output.

    - Output over 32 KiB is truncated (head/tail) with a marker in between.
    - Timeouts return ``timed_out=True`` and a non-zero exit code.
    - When ``sandbox`` is provided and its backend is available, the command
      runs inside that sandbox (e.g. ``bwrap``). Otherwise runs directly.
    """
    ws = Path(cwd).resolve() if cwd else Path.cwd().resolve()
    if sandbox is not None and sandbox.available:
        argv = sandbox.wrap_bash(command, ws, allow_network=allow_network)
    else:
        argv = ["/bin/bash", "-lc", command]
    try:
        proc = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(cwd) if cwd else None,
            env=env,
        )
        return BashResult(
            command=command,
            exit_code=proc.returncode,
            stdout=_truncate(proc.stdout),
            stderr=_truncate(proc.stderr),
            timed_out=False,
            truncated=_was_truncated(proc.stdout) or _was_truncated(proc.stderr),
        )
    except subprocess.TimeoutExpired as e:
        return BashResult(
            command=command,
            exit_code=124,  # conventional timeout code
            stdout=_truncate(e.stdout or ""),
            stderr=_truncate(e.stderr or "") + f"\n[timed out after {timeout}s]",
            timed_out=True,
            truncated=True,
        )


def _truncate(text: str) -> str:
    data = text.encode("utf-8", errors="replace")
    if len(data) <= _MAX_OUTPUT_BYTES:
        return text
    half = _MAX_OUTPUT_BYTES // 2
    head = data[:half].decode("utf-8", errors="replace")
    tail = data[-half:].decode("utf-8", errors="replace")
    omitted = len(data) - _MAX_OUTPUT_BYTES
    return f"{head}\n\n[... {omitted} bytes truncated ...]\n\n{tail}"


def _was_truncated(text: str) -> bool:
    return len(text.encode("utf-8", errors="replace")) > _MAX_OUTPUT_BYTES


BASH_SPEC = {
    "type": "function",
    "function": {
        "name": "bash",
        "description": (
            "Run a shell command via /bin/bash -lc. Subject to permission mode: "
            "destructive patterns (rm -rf, mkfs, sudo rm, git push --force, …) "
            "are flagged for confirmation. Output is truncated at 32 KiB."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "command": {"type": "string"},
                "timeout": {"type": "integer", "default": _DEFAULT_TIMEOUT},
            },
            "required": ["command"],
        },
    },
}
