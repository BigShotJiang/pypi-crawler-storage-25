"""glob_search + grep_search.

Ported from claw-code ``runtime/src/search.rs``. glob_search walks the
workspace with ``pathlib``; grep_search shells out to ``rg`` when available
and falls back to a pure-Python scanner otherwise (so the tool works on
machines without ripgrep).
"""
from __future__ import annotations

import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from tinillm.agent.workspace import Workspace


_GLOB_DEFAULT_LIMIT = 100
_GREP_DEFAULT_LIMIT = 100


@dataclass
class GlobResult:
    pattern: str
    matches: list[str] = field(default_factory=list)
    truncated: bool = False


@dataclass
class GrepMatch:
    path: str
    line: int
    text: str


@dataclass
class GrepResult:
    pattern: str
    matches: list[GrepMatch] = field(default_factory=list)
    truncated: bool = False


# ── glob_search ──────────────────────────────────────────────────────────────

def glob_search(
    workspace: Workspace,
    pattern: str,
    *,
    limit: int = _GLOB_DEFAULT_LIMIT,
) -> GlobResult:
    """Return files matching ``pattern`` inside the workspace, newest first."""
    root = workspace.root
    matches = [p for p in root.glob(pattern) if p.is_file()]
    matches.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    truncated = len(matches) > limit
    matches = matches[:limit]
    return GlobResult(
        pattern=pattern,
        matches=[str(p) for p in matches],
        truncated=truncated,
    )


# ── grep_search ──────────────────────────────────────────────────────────────

def grep_search(
    workspace: Workspace,
    pattern: str,
    *,
    path: str | None = None,
    glob: str | None = None,
    case_insensitive: bool = False,
    limit: int = _GREP_DEFAULT_LIMIT,
) -> GrepResult:
    """Search file contents for ``pattern`` (regex)."""
    search_root = workspace.resolve(path) if path else workspace.root

    if shutil.which("rg"):
        return _grep_rg(pattern, search_root, glob, case_insensitive, limit)
    return _grep_python(pattern, search_root, glob, case_insensitive, limit)


def _grep_rg(
    pattern: str,
    root: Path,
    glob: str | None,
    case_insensitive: bool,
    limit: int,
) -> GrepResult:
    cmd = ["rg", "--line-number", "--no-heading", "--color=never"]
    if case_insensitive:
        cmd.append("-i")
    if glob:
        cmd.extend(["--glob", glob])
    cmd.extend(["-e", pattern, str(root)])

    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    except subprocess.TimeoutExpired:
        return GrepResult(pattern=pattern, truncated=True)

    matches: list[GrepMatch] = []
    for raw in proc.stdout.splitlines():
        # rg line format: path:lineno:text
        parts = raw.split(":", 2)
        if len(parts) < 3:
            continue
        try:
            line = int(parts[1])
        except ValueError:
            continue
        matches.append(GrepMatch(path=parts[0], line=line, text=parts[2]))
        if len(matches) >= limit:
            return GrepResult(pattern=pattern, matches=matches, truncated=True)
    return GrepResult(pattern=pattern, matches=matches)


def _grep_python(
    pattern: str,
    root: Path,
    glob: str | None,
    case_insensitive: bool,
    limit: int,
) -> GrepResult:
    flags = re.IGNORECASE if case_insensitive else 0
    regex = re.compile(pattern, flags)
    iterator = root.rglob(glob) if glob else root.rglob("*")
    matches: list[GrepMatch] = []
    for p in iterator:
        if not p.is_file():
            continue
        try:
            with p.open("r", encoding="utf-8", errors="replace") as f:
                for i, line in enumerate(f, start=1):
                    if regex.search(line):
                        matches.append(
                            GrepMatch(path=str(p), line=i, text=line.rstrip("\n"))
                        )
                        if len(matches) >= limit:
                            return GrepResult(
                                pattern=pattern, matches=matches, truncated=True
                            )
        except OSError:
            continue
    return GrepResult(pattern=pattern, matches=matches)


# ── Ollama tool specs ────────────────────────────────────────────────────────

GLOB_SEARCH_SPEC = {
    "type": "function",
    "function": {
        "name": "glob_search",
        "description": (
            "Find files by glob pattern, relative to the workspace root. "
            "Results are sorted newest-first. Example: '**/*.py'."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string"},
                "limit": {"type": "integer", "default": _GLOB_DEFAULT_LIMIT},
            },
            "required": ["pattern"],
        },
    },
}

GREP_SEARCH_SPEC = {
    "type": "function",
    "function": {
        "name": "grep_search",
        "description": (
            "Search file contents for a regex. Uses ripgrep when available, "
            "falls back to pure Python. Scope with path= and/or glob=."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string"},
                "path": {"type": "string"},
                "glob": {"type": "string"},
                "case_insensitive": {"type": "boolean", "default": False},
                "limit": {"type": "integer", "default": _GREP_DEFAULT_LIMIT},
            },
            "required": ["pattern"],
        },
    },
}
