"""read_file / write_file / edit_file.

Ported from claw-code ``runtime/src/file_ops.rs``. Each function runs paths
through the ``Workspace`` boundary guard before touching disk, detects
binary files up front, and returns a dataclass the registry can render for
the model or show to the user.
"""
from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from tinillm.agent.workspace import Workspace


# Files larger than this are rejected outright unless the caller passes an
# explicit ``limit`` — matches claw's 2 MiB default read cap.
_MAX_READ_BYTES = 2 * 1024 * 1024
_BINARY_SNIFF_BYTES = 8192
_DEFAULT_READ_LINES = 2000


class FileOpError(Exception):
    pass


@dataclass
class ReadFileResult:
    path: str
    content: str          # with 1-indexed line numbers prepended
    total_lines: int
    offset: int
    limit: int
    truncated: bool


@dataclass
class WriteFileResult:
    path: str
    bytes_written: int
    created: bool         # True if file didn't exist before


@dataclass
class EditHunk:
    line: int             # 1-indexed line where the edit starts
    before: str
    after: str


@dataclass
class EditFileResult:
    path: str
    replacements: int
    hunks: list[EditHunk] = field(default_factory=list)


# ── read_file ────────────────────────────────────────────────────────────────

def read_file(
    workspace: Workspace,
    path: str,
    *,
    offset: int = 0,
    limit: int | None = None,
) -> ReadFileResult:
    """Read a text file, numbered ``cat -n``–style.

    - ``offset`` is 0-indexed line offset.
    - ``limit`` defaults to 2000 lines so the model can't blow its context.
    - Binary files raise FileOpError; so do files larger than the read cap.
    """
    resolved = workspace.resolve(path, allow_missing=True)
    if not resolved.exists():
        raise FileOpError(f"File not found: {resolved}")
    if resolved.is_dir():
        raise FileOpError(f"Is a directory, not a file: {resolved}")

    size = resolved.stat().st_size
    if size > _MAX_READ_BYTES and limit is None:
        raise FileOpError(
            f"File too large ({size} bytes). Pass an explicit limit to read a slice."
        )

    if _looks_binary(resolved):
        raise FileOpError(f"Refusing to read binary file: {resolved}")

    text = resolved.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    total = len(lines)

    if offset < 0:
        offset = 0
    effective_limit = limit if limit is not None else _DEFAULT_READ_LINES
    end = min(total, offset + effective_limit)
    slice_ = lines[offset:end]
    truncated = end < total

    width = len(str(end)) if end else 1
    numbered = "\n".join(
        f"{i + 1:>{width}}\t{line}" for i, line in enumerate(slice_, start=offset)
    )
    return ReadFileResult(
        path=str(resolved),
        content=numbered,
        total_lines=total,
        offset=offset,
        limit=effective_limit,
        truncated=truncated,
    )


# ── write_file ───────────────────────────────────────────────────────────────

def write_file(workspace: Workspace, path: str, content: str) -> WriteFileResult:
    """Atomically write ``content`` to ``path`` (create or overwrite)."""
    resolved = workspace.resolve(path, allow_missing=True)
    if resolved.is_dir():
        raise FileOpError(f"Cannot write — path is a directory: {resolved}")

    created = not resolved.exists()
    resolved.parent.mkdir(parents=True, exist_ok=True)

    # Atomic replace so a crash mid-write never leaves a truncated file.
    data = content.encode("utf-8")
    tmp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            dir=resolved.parent,
            prefix=f".{resolved.name}.",
            suffix=".tmp",
            delete=False,
        ) as tmp:
            tmp_path = Path(tmp.name)
            tmp.write(data)
            tmp.flush()
            os.fsync(tmp.fileno())
        os.replace(tmp_path, resolved)
        tmp_path = None  # ownership handed over
    finally:
        if tmp_path is not None and tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass

    return WriteFileResult(
        path=str(resolved),
        bytes_written=len(data),
        created=created,
    )


# ── edit_file ────────────────────────────────────────────────────────────────

def edit_file(
    workspace: Workspace,
    path: str,
    old_string: str,
    new_string: str,
    *,
    replace_all: bool = False,
) -> EditFileResult:
    """Replace ``old_string`` with ``new_string`` in ``path``.

    Must match exactly. When ``replace_all`` is False (default), ``old_string``
    must be unique in the file — caller should widen the snippet otherwise.
    """
    if old_string == new_string:
        raise FileOpError("old_string and new_string are identical — no edit to make.")

    resolved = workspace.resolve(path, allow_missing=True)
    if not resolved.exists():
        raise FileOpError(f"File not found: {resolved}")
    if _looks_binary(resolved):
        raise FileOpError(f"Refusing to edit binary file: {resolved}")

    text = resolved.read_text(encoding="utf-8", errors="replace")
    occurrences = text.count(old_string)
    if occurrences == 0:
        raise FileOpError(
            "old_string not found in file. Read the file and copy the exact bytes."
        )
    if occurrences > 1 and not replace_all:
        raise FileOpError(
            f"old_string matches {occurrences} times — widen the snippet or "
            f"pass replace_all=True."
        )

    if replace_all:
        new_text = text.replace(old_string, new_string)
        replaced = occurrences
    else:
        new_text = text.replace(old_string, new_string, 1)
        replaced = 1

    hunks = _hunks_for_edit(text, new_text)
    write_file(workspace, path, new_text)
    return EditFileResult(
        path=str(resolved),
        replacements=replaced,
        hunks=hunks,
    )


# ── Helpers ──────────────────────────────────────────────────────────────────

def _looks_binary(path: Path) -> bool:
    try:
        with path.open("rb") as f:
            chunk = f.read(_BINARY_SNIFF_BYTES)
    except OSError:
        return False
    if b"\x00" in chunk:
        return True
    # Heuristic: if >30% of bytes are non-printable, treat as binary.
    if not chunk:
        return False
    printable = sum(
        1 for b in chunk if b in (9, 10, 13) or 32 <= b < 127
    )
    return printable / len(chunk) < 0.7


def _hunks_for_edit(before: str, after: str) -> list[EditHunk]:
    """Return line-level hunks between ``before`` and ``after``.

    Uses difflib to find contiguous changed regions; one hunk per region.
    """
    import difflib

    b_lines = before.splitlines()
    a_lines = after.splitlines()
    matcher = difflib.SequenceMatcher(a=b_lines, b=a_lines, autojunk=False)
    hunks: list[EditHunk] = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            continue
        hunks.append(
            EditHunk(
                line=i1 + 1,
                before="\n".join(b_lines[i1:i2]),
                after="\n".join(a_lines[j1:j2]),
            )
        )
    return hunks


# ── Ollama tool specs ────────────────────────────────────────────────────────

READ_FILE_SPEC = {
    "type": "function",
    "function": {
        "name": "read_file",
        "description": (
            "Read a text file from the workspace. Returns numbered lines. "
            "Use offset/limit for large files; default limit is 2000 lines."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path (absolute or workspace-relative)."},
                "offset": {"type": "integer", "description": "0-indexed line to start at.", "default": 0},
                "limit": {"type": "integer", "description": "Max lines to read."},
            },
            "required": ["path"],
        },
    },
}

WRITE_FILE_SPEC = {
    "type": "function",
    "function": {
        "name": "write_file",
        "description": "Create or overwrite a text file with the given content.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "content": {"type": "string"},
            },
            "required": ["path", "content"],
        },
    },
}

EDIT_FILE_SPEC = {
    "type": "function",
    "function": {
        "name": "edit_file",
        "description": (
            "Replace an exact snippet in a file. old_string must match the file "
            "byte-for-byte. If it appears more than once, set replace_all=true or "
            "widen the snippet to be unique."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "old_string": {"type": "string"},
                "new_string": {"type": "string"},
                "replace_all": {"type": "boolean", "default": False},
            },
            "required": ["path", "old_string", "new_string"],
        },
    },
}
