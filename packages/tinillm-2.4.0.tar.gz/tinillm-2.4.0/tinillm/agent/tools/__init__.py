"""Tool implementations for the tinillm agent loop.

Each tool module exposes:
- a pure-Python function that returns a structured dataclass
- a ``SPEC`` dict in Ollama tool-call JSON shape

The ``registry`` module assembles these into the list handed to ``ollama.chat``
and dispatches model-requested calls through the permission enforcer.
"""
from __future__ import annotations
