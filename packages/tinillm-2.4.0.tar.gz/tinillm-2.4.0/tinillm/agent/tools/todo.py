"""TodoWrite tool — session-local task list.

Mirrors claw-code's in-memory TodoWrite: the model owns the list, tinillm
just persists it for the duration of the chat session and renders it on
``/tasks``. Not saved to disk.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class TodoStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"


@dataclass
class Todo:
    id: int
    content: str
    status: TodoStatus = TodoStatus.PENDING
    active_form: str = ""  # present-tense phrasing used while in-progress


@dataclass
class TodoList:
    """Append-only list with id-based update. Lives on the session object."""
    items: list[Todo] = field(default_factory=list)
    _next_id: int = 1

    def write(self, todos: list[dict]) -> list[Todo]:
        """Replace the list wholesale (matches claw's TodoWrite semantics)."""
        self.items = []
        self._next_id = 1
        for t in todos:
            self.items.append(
                Todo(
                    id=self._next_id,
                    content=t.get("content", "").strip(),
                    status=TodoStatus(t.get("status", "pending")),
                    active_form=t.get("active_form", ""),
                )
            )
            self._next_id += 1
        return list(self.items)

    def render(self) -> str:
        if not self.items:
            return "(no tasks)"
        marks = {
            TodoStatus.PENDING: "[ ]",
            TodoStatus.IN_PROGRESS: "[~]",
            TodoStatus.COMPLETED: "[x]",
        }
        return "\n".join(
            f"{marks[t.status]} {t.active_form or t.content}" for t in self.items
        )


TODO_WRITE_SPEC = {
    "type": "function",
    "function": {
        "name": "TodoWrite",
        "description": (
            "Overwrite the session task list. Use one in_progress task at a time. "
            "Each item: {content, status: pending|in_progress|completed, active_form}."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "todos": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "content": {"type": "string"},
                            "status": {
                                "type": "string",
                                "enum": ["pending", "in_progress", "completed"],
                            },
                            "active_form": {"type": "string"},
                        },
                        "required": ["content", "status"],
                    },
                },
            },
            "required": ["todos"],
        },
    },
}
