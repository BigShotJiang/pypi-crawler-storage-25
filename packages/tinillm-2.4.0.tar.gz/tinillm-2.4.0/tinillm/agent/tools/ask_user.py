"""AskUserQuestion — surface a multiple-choice question to the user.

Claw's version lets the model pause the loop and request input. For the
local-Ollama REPL we implement this as a blocking ``click.prompt`` that
renders the options through Rich, then returns the user's answer back to
the model as the tool result.
"""
from __future__ import annotations

from dataclasses import dataclass

import click
from rich.console import Console


@dataclass
class AskUserResult:
    question: str
    answer: str


def ask_user(
    question: str,
    options: list[str] | None = None,
    *,
    console: Console | None = None,
) -> AskUserResult:
    console = console or Console()
    console.print(f"\n[bold yellow]?[/] {question}")
    if options:
        for i, opt in enumerate(options, start=1):
            console.print(f"  [cyan]{i}[/cyan]. {opt}")
        raw = click.prompt("Choose (number or free text)", default="", show_default=False)
        try:
            idx = int(raw)
            if 1 <= idx <= len(options):
                return AskUserResult(question=question, answer=options[idx - 1])
        except ValueError:
            pass
        return AskUserResult(question=question, answer=raw)
    answer = click.prompt("> ", default="", show_default=False)
    return AskUserResult(question=question, answer=answer)


ASK_USER_SPEC = {
    "type": "function",
    "function": {
        "name": "AskUserQuestion",
        "description": (
            "Pause and ask the user a question before continuing. Use when a "
            "decision can't be made from context alone. Optional multiple-choice options."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "question": {"type": "string"},
                "options": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["question"],
        },
    },
}
