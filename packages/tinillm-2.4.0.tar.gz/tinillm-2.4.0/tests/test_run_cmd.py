"""Tests for `tinillm run` command."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from tinillm.commands import run_cmd
from tinillm.analyzer.types import FitLevel, ModelFit, LlmModel, Quant
from tinillm.hardware.types import CpuInfo, GpuInfo, SystemSpecs
from tinillm.models.database import MODELS


# ── Shared fixtures ────────────────────────────────────────────────────────

@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def specs_high_end():
    return SystemSpecs(
        cpu=CpuInfo("Intel Core i9-13900K", 24, 32, 5800.0),
        total_ram_gb=32.0,
        free_ram_gb=24.0,
        gpus=[GpuInfo(name="NVIDIA GeForce RTX 4090", vram_gb=24.0, backend="CUDA")],
        os="Linux",
    )


def _perfect_fit(name: str = "Test Model") -> ModelFit:
    return ModelFit(
        model=LlmModel(name, 7.0, 32, 8, 128, 8192),
        fit_level=FitLevel.PERFECT,
        best_quant=Quant.Q4_K_M,
        mem_required_gb=4.5,
        tokens_per_sec=87.0,
        runs_on_gpu=True,
    )


def _marginal_fit(name: str = "Test Model") -> ModelFit:
    return ModelFit(
        model=LlmModel(name, 7.0, 32, 8, 128, 8192),
        fit_level=FitLevel.MARGINAL,
        best_quant=Quant.Q2_K,
        mem_required_gb=3.8,
        tokens_per_sec=40.0,
        runs_on_gpu=False,
    )


def _too_tight_fit(name: str = "Test Model") -> ModelFit:
    return ModelFit(
        model=LlmModel(name, 70.0, 80, 8, 128, 4096),
        fit_level=FitLevel.TOO_TIGHT,
        best_quant=None,
        mem_required_gb=None,
        tokens_per_sec=None,
        runs_on_gpu=False,
    )


# ── Help text ──────────────────────────────────────────────────────────────

class TestRunHelp:
    def test_run_help_shows_flags(self, runner):
        result = runner.invoke(run_cmd, ["--help"])
        assert result.exit_code == 0
        for flag in ["--use-case", "--force", "--dry-run", "--no-color"]:
            assert flag in result.output

    def test_run_help_shows_model_tag_arg(self, runner):
        result = runner.invoke(run_cmd, ["--help"])
        assert "MODEL_TAG" in result.output


# ── Dry-run: no subprocess called ─────────────────────────────────────────

class TestDryRun:
    def test_dry_run_explicit_tag_prints_command(self, runner, specs_high_end):
        # Find a real model tag from the database
        model = next(m for m in MODELS if "llama3.1:8b" == m.ollama_tag)
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.cmd.subprocess.run") as mock_sub,
        ):
            result = runner.invoke(run_cmd, [model.ollama_tag, "--dry-run"])

        assert result.exit_code == 0
        mock_sub.assert_not_called()
        assert "ollama run" in result.output
        assert model.ollama_tag in result.output

    def test_dry_run_does_not_call_subprocess(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.cmd.subprocess.run") as mock_sub,
        ):
            runner.invoke(run_cmd, ["llama3.1:8b", "--dry-run"])

        mock_sub.assert_not_called()


# ── Explicit tag: Perfect fit ──────────────────────────────────────────────

class TestExplicitTagPerfectFit:
    def test_calls_ollama_run_with_correct_tag(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.cmd.subprocess.run") as mock_sub,
        ):
            result = runner.invoke(run_cmd, ["llama3.1:8b"])

        mock_sub.assert_called_once_with(["ollama", "run", "llama3.1:8b"])
        assert result.exit_code == 0

    def test_no_warning_for_perfect_fit(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.cmd.subprocess.run"),
        ):
            result = runner.invoke(run_cmd, ["llama3.1:8b"])

        assert "Warning" not in result.output
        assert "Error" not in result.output


# ── Explicit tag: TooTight ─────────────────────────────────────────────────

class TestExplicitTagTooTight:
    def test_exits_nonzero_when_too_tight(self, runner, specs_high_end):
        specs_tiny = SystemSpecs(
            cpu=CpuInfo("Intel Core i3", 2, 4, 2000.0),
            total_ram_gb=4.0,
            free_ram_gb=2.0,
            gpus=[],
            os="Linux",
        )
        # command-r-plus:104b is almost certainly TooTight on 2 GB free RAM
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_tiny),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.cmd.subprocess.run") as mock_sub,
        ):
            result = runner.invoke(run_cmd, ["command-r-plus:104b"])

        assert result.exit_code != 0
        mock_sub.assert_not_called()

    def test_force_proceeds_despite_too_tight(self, runner):
        specs_tiny = SystemSpecs(
            cpu=CpuInfo("Intel Core i3", 2, 4, 2000.0),
            total_ram_gb=4.0,
            free_ram_gb=2.0,
            gpus=[],
            os="Linux",
        )
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_tiny),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.cmd.subprocess.run") as mock_sub,
        ):
            result = runner.invoke(run_cmd, ["command-r-plus:104b", "--force"])

        mock_sub.assert_called_once_with(["ollama", "run", "command-r-plus:104b"])


# ── Ollama not running ─────────────────────────────────────────────────────

class TestOllamaNotRunning:
    def test_exits_nonzero_when_ollama_down(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd.subprocess.run"),
            patch(
                "tinillm.run.cmd._check_ollama",
                side_effect=SystemExit(1),
            ),
        ):
            result = runner.invoke(run_cmd, ["llama3.1:8b"])

        assert result.exit_code != 0

    def test_error_message_suggests_ollama_serve(self, runner, specs_high_end):
        """_check_ollama prints a hint; test that the real impl does so."""
        httpx = pytest.importorskip("httpx")

        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd.subprocess.run"),
            patch("httpx.get", side_effect=httpx.ConnectError("refused")),
        ):
            result = runner.invoke(run_cmd, ["llama3.1:8b"])

        assert result.exit_code != 0
        assert "ollama serve" in result.output


# ── Unknown tag (not in database) ─────────────────────────────────────────

class TestUnknownTag:
    def test_unknown_tag_passes_through_to_ollama(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.cmd.subprocess.run") as mock_sub,
        ):
            result = runner.invoke(run_cmd, ["some-custom-model:latest"])

        mock_sub.assert_called_once_with(["ollama", "run", "some-custom-model:latest"])
        assert result.exit_code == 0

    def test_unknown_tag_prints_database_note(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.cmd.subprocess.run"),
        ):
            result = runner.invoke(run_cmd, ["some-custom-model:latest"])

        assert "not in tinillm" in result.output.lower() or "database" in result.output.lower()


# ── Interactive picker ─────────────────────────────────────────────────────

class TestInteractivePicker:
    def test_no_arg_shows_model_table(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.cmd.subprocess.run"),
        ):
            result = runner.invoke(run_cmd, [], input="q\n")

        # Table headers should appear
        assert "Model" in result.output
        assert "Fit" in result.output

    def test_quit_exits_zero(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.cmd.subprocess.run"),
        ):
            result = runner.invoke(run_cmd, [], input="q\n")

        assert result.exit_code == 0

    def test_valid_selection_launches_model(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.cmd.subprocess.run") as mock_sub,
        ):
            result = runner.invoke(run_cmd, [], input="1\n")

        mock_sub.assert_called_once()
        called_cmd = mock_sub.call_args[0][0]
        assert called_cmd[0] == "ollama"
        assert called_cmd[1] == "run"
        assert result.exit_code == 0

    def test_invalid_input_reprompts(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.cmd.subprocess.run"),
        ):
            # "abc" is invalid, then "q" to quit
            result = runner.invoke(run_cmd, [], input="abc\nq\n")

        assert "number" in result.output.lower()


# ── --use-case sorting ─────────────────────────────────────────────────────

class TestUseCaseSorting:
    def test_coding_use_case_shows_coding_models_first(self, runner, specs_high_end):
        from tinillm.recommend.logic import USE_CASE_AFFINITY

        coding_primaries = {
            name for name, score in USE_CASE_AFFINITY["coding"].items() if score == 2
        }
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.cmd.subprocess.run"),
        ):
            result = runner.invoke(run_cmd, ["--use-case", "coding"], input="q\n")

        assert result.exit_code == 0
        lines = result.output.splitlines()
        # Find the index of the first row labelled "1" — it should be a coding-affinity model
        first_row = next((l for l in lines if l.strip().startswith("1 ")), None)
        if first_row:
            # At least one primary coding model display name appears in top rows
            top_rows = "\n".join(lines[:20])
            assert any(
                m.display_name in top_rows
                for m in MODELS
                if m.name in coding_primaries
            )
