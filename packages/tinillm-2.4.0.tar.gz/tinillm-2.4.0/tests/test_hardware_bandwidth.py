"""Unit tests for the GPU memory bandwidth lookup table.

Verifies correct values for known GPUs and the longest-match
substring resolution logic.
"""

import pytest

from tinillm.hardware.bandwidth import gpu_bandwidth_gbps


class TestGpuBandwidthLookup:
    # ── Exact known values ─────────────────────────────────────────────────

    def test_rtx4090_bandwidth(self):
        assert gpu_bandwidth_gbps("NVIDIA GeForce RTX 4090") == 1008.0

    def test_rtx3090_bandwidth(self):
        assert gpu_bandwidth_gbps("NVIDIA GeForce RTX 3090") == 936.2

    def test_rtx3060_bandwidth(self):
        assert gpu_bandwidth_gbps("NVIDIA GeForce RTX 3060") == 360.0

    def test_rx7900xtx_bandwidth(self):
        assert gpu_bandwidth_gbps("AMD Radeon RX 7900 XTX") == 960.0

    def test_apple_m3_max_bandwidth(self):
        assert gpu_bandwidth_gbps("Apple M3 Max") == 400.0

    def test_apple_m1_bandwidth(self):
        assert gpu_bandwidth_gbps("Apple M1") == 68.25

    def test_h100_bandwidth(self):
        assert gpu_bandwidth_gbps("NVIDIA H100") == 3350.0

    def test_intel_arc_a770(self):
        assert gpu_bandwidth_gbps("Intel Arc A770") == 560.0

    # ── Unknown GPU returns 0 ──────────────────────────────────────────────

    def test_unknown_gpu_returns_zero(self):
        assert gpu_bandwidth_gbps("SomeBrand XYZ 9999") == 0.0

    def test_empty_string_returns_zero(self):
        assert gpu_bandwidth_gbps("") == 0.0

    # ── Longest-match resolution ───────────────────────────────────────────

    def test_rtx4080_super_preferred_over_rtx4080(self):
        """'RTX 4080 SUPER' is more specific and should return 736.0, not 716.8."""
        assert gpu_bandwidth_gbps("NVIDIA GeForce RTX 4080 SUPER") == 736.0

    def test_rtx3090_ti_preferred_over_rtx3090(self):
        assert gpu_bandwidth_gbps("NVIDIA GeForce RTX 3090 Ti") == 1008.0

    def test_m4_max_preferred_over_m4(self):
        assert gpu_bandwidth_gbps("Apple M4 Max") == 546.0

    def test_m2_ultra_preferred_over_m2(self):
        assert gpu_bandwidth_gbps("Apple M2 Ultra") == 800.0

    # ── Case insensitivity ─────────────────────────────────────────────────

    def test_lowercase_name_matches(self):
        result_upper = gpu_bandwidth_gbps("NVIDIA GeForce RTX 4090")
        result_lower = gpu_bandwidth_gbps("nvidia geforce rtx 4090")
        assert result_upper == result_lower

    def test_mixed_case_matches(self):
        assert gpu_bandwidth_gbps("Nvidia Geforce Rtx 4090") == 1008.0

    # ── Value sanity ───────────────────────────────────────────────────────

    def test_all_known_gpus_return_positive_bandwidth(self):
        known_gpus = [
            "RTX 4090", "RTX 3090", "RX 7900 XTX",
            "Apple M1", "Apple M2", "Apple M3",
            "H100", "A100", "T4",
        ]
        for name in known_gpus:
            bw = gpu_bandwidth_gbps(name)
            assert bw > 0, f"Zero bandwidth for known GPU: {name}"

    def test_bandwidth_increases_with_gpu_tier(self):
        """Higher-tier GPUs should have higher bandwidth within the same generation."""
        assert gpu_bandwidth_gbps("RTX 4090") > gpu_bandwidth_gbps("RTX 4060")
        assert gpu_bandwidth_gbps("H100") > gpu_bandwidth_gbps("T4")
        assert gpu_bandwidth_gbps("Apple M3 Max") > gpu_bandwidth_gbps("Apple M3")
