"""Unit tests for the LLM fitting engine.

Tests best_quant_for_budget, score_fit_level, and the full analyze() pipeline
across different hardware profiles (high-end GPU, mid-range, CPU-only, Apple Silicon).
"""

import pytest

from tinillm.analyzer.fit import (
    QUANT_HIERARCHY,
    best_quant_for_budget,
    score_fit_level,
    analyze,
    _memory_budget,
)
from tinillm.analyzer.types import FitLevel, LlmModel, Quant
from tinillm.analyzer.models import MODEL_ARCHETYPES
from tinillm.hardware.types import CpuInfo, GpuInfo, SystemSpecs


# ── QUANT_HIERARCHY ordering ───────────────────────────────────────────────

class TestQuantHierarchy:
    def test_q8_is_first(self):
        assert QUANT_HIERARCHY[0] == Quant.Q8_0

    def test_q2k_is_last(self):
        assert QUANT_HIERARCHY[-1] == Quant.Q2_K

    def test_all_quants_covered_except_f16(self):
        """F16 is excluded from the hierarchy (too large for most local runs)."""
        covered = set(QUANT_HIERARCHY)
        assert Quant.Q4_K_M in covered
        assert Quant.Q8_0 in covered


# ── best_quant_for_budget ──────────────────────────────────────────────────

class TestBestQuantForBudget:
    def test_large_budget_returns_q8(self, model_7b):
        """24 GB budget should fit 7B at Q8_0."""
        result = best_quant_for_budget(model_7b, 24.0)
        assert result is not None
        quant, _, _ = result
        assert quant == Quant.Q8_0

    def test_tight_budget_returns_more_compressed_quant(self, model_7b):
        """6 GB budget should force a smaller quant."""
        result = best_quant_for_budget(model_7b, 6.0)
        assert result is not None
        quant, _, _ = result
        # Q8_0 won't fit; must be Q5 or smaller
        assert quant in (Quant.Q5_K_M, Quant.Q4_K_M, Quant.Q3_K_M, Quant.Q2_K)

    def test_impossible_budget_returns_none(self, model_7b):
        """Budget of 0.5 GB cannot fit any 7B quantisation."""
        result = best_quant_for_budget(model_7b, 0.5)
        assert result is None

    def test_returned_mem_fits_within_budget(self, model_7b):
        budget = 8.0
        result = best_quant_for_budget(model_7b, budget)
        assert result is not None
        _, mem_required, _ = result
        assert mem_required <= budget

    def test_context_halved_when_needed(self, model_7b):
        """Verify context_len can be halved to fit a tighter budget."""
        result_full = best_quant_for_budget(model_7b, 24.0)
        result_tight = best_quant_for_budget(model_7b, 4.0)
        assert result_tight is not None
        _, _, ctx_tight = result_tight
        _, _, ctx_full = result_full
        assert ctx_tight <= ctx_full

    def test_1b_model_fits_tiny_budget(self):
        """1B model should fit in even 2 GB."""
        model = LlmModel("~1B", 1.0, 22, 8, 64, 8192)
        result = best_quant_for_budget(model, 2.0)
        assert result is not None

    def test_70b_does_not_fit_in_8gb(self):
        """70B model cannot fit in 8 GB under any quant."""
        model = LlmModel("~70B", 70.0, 80, 8, 128, 4096)
        result = best_quant_for_budget(model, 8.0)
        assert result is None


# ── score_fit_level ────────────────────────────────────────────────────────

class TestScoreFitLevel:
    def _model_7b(self):
        return LlmModel("~7B", 7.0, 32, 8, 128, 8192)

    def test_too_tight_when_mem_exceeds_budget(self):
        model = self._model_7b()
        level = score_fit_level(
            mem_required=10.0, budget_gb=8.0,
            runs_on_gpu=True, best_quant=Quant.Q4_K_M,
            model=model, context_len=8192,
        )
        assert level == FitLevel.TOO_TIGHT

    def test_cpu_only_is_always_marginal(self):
        model = self._model_7b()
        level = score_fit_level(
            mem_required=5.0, budget_gb=12.0,
            runs_on_gpu=False, best_quant=Quant.Q4_K_M,
            model=model, context_len=8192,
        )
        assert level == FitLevel.MARGINAL

    def test_perfect_when_plenty_of_vram(self):
        """24 GB VRAM for a 7B model should be Perfect."""
        model = self._model_7b()
        level = score_fit_level(
            mem_required=5.5, budget_gb=24.0,
            runs_on_gpu=True, best_quant=Quant.Q4_K_M,
            model=model, context_len=8192,
        )
        assert level == FitLevel.PERFECT

    def test_marginal_when_context_reduced(self):
        """Marginal triggers when baseline does NOT fit full context, but a
        reduced context+quant does (context_len < model.context_length).

        7B Q4_K_M@8192 = 5.56 GB > budget 5.0 → baseline doesn't fit.
        But mem_required=4.0 GB fits, at context_len=1024 < 8192 → Marginal.
        """
        model = self._model_7b()
        level = score_fit_level(
            mem_required=4.0, budget_gb=5.0,   # baseline (5.56 GB) > budget
            runs_on_gpu=True, best_quant=Quant.Q2_K,
            model=model, context_len=1024,      # reduced from 8192
        )
        assert level == FitLevel.MARGINAL

    def test_good_when_fits_baseline_tightly(self):
        """Fits baseline but less than 20% headroom → Good."""
        model = self._model_7b()
        # Force a scenario where baseline fits but barely (no 20% headroom)
        from tinillm.analyzer.memory import estimate_memory_gb
        baseline_mem = estimate_memory_gb(model, Quant.Q4_K_M, 8192)
        budget = baseline_mem * 1.1  # only 10% headroom → Good, not Perfect
        level = score_fit_level(
            mem_required=baseline_mem - 0.1, budget_gb=budget,
            runs_on_gpu=True, best_quant=Quant.Q4_K_M,
            model=model, context_len=8192,
        )
        assert level == FitLevel.GOOD


# ── _memory_budget ─────────────────────────────────────────────────────────

class TestMemoryBudget:
    def test_cpu_only_uses_75_pct_free_ram(self, specs_cpu_only):
        budget, runs_on_gpu = _memory_budget(specs_cpu_only)
        assert not runs_on_gpu
        assert abs(budget - specs_cpu_only.free_ram_gb * 0.75) < 0.01

    def test_gpu_uses_vram(self, specs_high_end):
        budget, runs_on_gpu = _memory_budget(specs_high_end)
        assert runs_on_gpu
        assert budget == 24.0  # RTX 4090

    def test_apple_silicon_uses_total_ram(self, specs_apple_silicon):
        budget, runs_on_gpu = _memory_budget(specs_apple_silicon)
        assert runs_on_gpu
        assert budget == specs_apple_silicon.total_ram_gb

    def test_multi_gpu_uses_single_card_vram(self, specs_multi_gpu):
        """Multi-GPU: budget = single card's VRAM, not total sum."""
        budget, runs_on_gpu = _memory_budget(specs_multi_gpu)
        assert runs_on_gpu
        assert budget == 24.0  # one RTX 3090


# ── Full analyze() pipeline ────────────────────────────────────────────────

class TestAnalyzePipeline:
    def test_returns_all_six_archetypes(self, specs_high_end):
        fits = analyze(specs_high_end)
        assert len(fits) == len(MODEL_ARCHETYPES)

    def test_ordered_smallest_to_largest(self, specs_high_end):
        fits = analyze(specs_high_end)
        sizes = [f.model.params_b for f in fits]
        assert sizes == sorted(sizes)

    def test_high_end_gpu_all_perfect_or_good(self, specs_high_end):
        """RTX 4090 (24 GB) runs models up to ~34B.
        70B at Q2_K requires ~26 GB weights alone → genuinely TooTight on 24 GB VRAM.
        """
        fits = analyze(specs_high_end)
        small_models = [f for f in fits if f.model.params_b <= 34.0]
        for fit in small_models:
            assert fit.fit_level != FitLevel.TOO_TIGHT, (
                f"{fit.model.name} marked TooTight on RTX 4090"
            )

    def test_mid_range_gpu_some_toottight(self, specs_mid_range):
        """RTX 3060 (12 GB) cannot run 34B or 70B at any quant."""
        fits = analyze(specs_mid_range)
        tight = [f for f in fits if f.fit_level == FitLevel.TOO_TIGHT]
        # At least 70B should be TooTight
        tight_names = [f.model.name for f in tight]
        assert "~70B" in tight_names

    def test_cpu_only_all_marginal(self, specs_cpu_only):
        """CPU-only runs are always Marginal (or TooTight)."""
        fits = analyze(specs_cpu_only)
        for fit in fits:
            if fit.fit_level != FitLevel.TOO_TIGHT:
                assert fit.fit_level == FitLevel.MARGINAL, (
                    f"{fit.model.name} is {fit.fit_level} on CPU-only (expected Marginal)"
                )

    def test_cpu_only_runs_on_gpu_false(self, specs_cpu_only):
        fits = analyze(specs_cpu_only)
        for fit in fits:
            assert not fit.runs_on_gpu

    def test_gpu_runs_on_gpu_true(self, specs_high_end):
        fits = analyze(specs_high_end)
        for fit in fits:
            assert fit.runs_on_gpu

    def test_apple_silicon_96gb_all_fit(self, specs_apple_silicon):
        """96 GB unified memory should run even 70B."""
        fits = analyze(specs_apple_silicon)
        tight = [f for f in fits if f.fit_level == FitLevel.TOO_TIGHT]
        assert len(tight) == 0, f"Expected no TooTight on M3 Max 96GB, got: {[f.model.name for f in tight]}"

    def test_runnable_fits_have_positive_tps(self, specs_high_end):
        fits = analyze(specs_high_end)
        for fit in fits:
            if fit.fit_level != FitLevel.TOO_TIGHT:
                assert fit.tokens_per_sec is not None
                assert fit.tokens_per_sec > 0

    def test_toottight_fits_have_null_fields(self, specs_low_ram):
        fits = analyze(specs_low_ram)
        for fit in fits:
            if fit.fit_level == FitLevel.TOO_TIGHT:
                assert fit.best_quant is None
                assert fit.mem_required_gb is None
                assert fit.tokens_per_sec is None

    def test_low_ram_machine_smallest_model_still_runs(self, specs_low_ram):
        """Even 4 GB RAM should fit at least ~1B."""
        fits = analyze(specs_low_ram)
        one_b = next(f for f in fits if f.model.name == "~1B")
        assert one_b.fit_level != FitLevel.TOO_TIGHT
