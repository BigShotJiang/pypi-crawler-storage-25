"""Unit tests for memory estimation formulas.

Tests the KV cache formula and total memory estimation
against known expected values derived from the llmfit spec.
"""

import pytest

from tinillm.analyzer.memory import kv_cache_gb, estimate_memory_gb, QUANT_BPP
from tinillm.analyzer.types import LlmModel, Quant


@pytest.fixture
def model_7b() -> LlmModel:
    return LlmModel(
        name="~7B", params_b=7.0, num_layers=32,
        num_kv_heads=8, head_dim=128, context_length=8192,
    )


@pytest.fixture
def model_1b() -> LlmModel:
    return LlmModel(
        name="~1B", params_b=1.0, num_layers=22,
        num_kv_heads=8, head_dim=64, context_length=8192,
    )


# ── QUANT_BPP table ────────────────────────────────────────────────────────

class TestQuantBPP:
    def test_all_quant_levels_present(self):
        for q in Quant:
            assert q in QUANT_BPP, f"Missing BPP for {q}"

    def test_f16_is_2_bytes(self):
        assert QUANT_BPP[Quant.F16] == 2.0

    def test_ordering_f16_largest_q2k_smallest(self):
        """Higher quality quant must use more bytes."""
        assert QUANT_BPP[Quant.F16] > QUANT_BPP[Quant.Q8_0]
        assert QUANT_BPP[Quant.Q8_0] > QUANT_BPP[Quant.Q6_K]
        assert QUANT_BPP[Quant.Q6_K] > QUANT_BPP[Quant.Q5_K_M]
        assert QUANT_BPP[Quant.Q5_K_M] > QUANT_BPP[Quant.Q4_K_M]
        assert QUANT_BPP[Quant.Q4_K_M] > QUANT_BPP[Quant.Q3_K_M]
        assert QUANT_BPP[Quant.Q3_K_M] > QUANT_BPP[Quant.Q2_K]

    def test_all_bpp_positive(self):
        for q, bpp in QUANT_BPP.items():
            assert bpp > 0, f"BPP for {q} must be positive"


# ── KV cache formula ───────────────────────────────────────────────────────

class TestKvCacheGb:
    def test_7b_kv_cache_at_8k_context(self, model_7b):
        """
        kv = 2 * 32 * 8 * 128 * 8192 * 2 / (1024^3)
           = 1,073,741,824 / 1,073,741,824 = 1.0 GB exactly
        """
        result = kv_cache_gb(model_7b, 8192)
        assert abs(result - 1.0) < 0.01, f"Expected 1.0 GB, got {result:.3f}"

    def test_kv_cache_scales_linearly_with_context(self, model_7b):
        kv_8k = kv_cache_gb(model_7b, 8192)
        kv_4k = kv_cache_gb(model_7b, 4096)
        assert abs(kv_8k / kv_4k - 2.0) < 0.01

    def test_kv_cache_zero_context_is_zero(self, model_7b):
        assert kv_cache_gb(model_7b, 0) == 0.0

    def test_kv_cache_always_non_negative(self, model_7b):
        for ctx in [512, 1024, 2048, 4096, 8192, 16384]:
            assert kv_cache_gb(model_7b, ctx) >= 0


# ── Total memory estimation ────────────────────────────────────────────────

class TestEstimateMemoryGb:
    def test_7b_q4km_approximate_value(self, model_7b):
        """
        7B Q4_K_M: weights = 7 * 0.58 = 4.06 GB
        KV@8192   ≈ 0.80 GB
        overhead  = 0.50 GB
        total     ≈ 5.36 GB
        """
        result = estimate_memory_gb(model_7b, Quant.Q4_K_M, 8192)
        assert 5.0 < result < 6.0, f"Expected 5–6 GB for 7B Q4_K_M, got {result:.2f}"

    def test_7b_f16_larger_than_q4km(self, model_7b):
        f16 = estimate_memory_gb(model_7b, Quant.F16, 8192)
        q4 = estimate_memory_gb(model_7b, Quant.Q4_K_M, 8192)
        assert f16 > q4

    def test_higher_quant_requires_more_memory(self, model_7b):
        """Q8_0 should require more memory than Q4_K_M for the same model+context."""
        q8 = estimate_memory_gb(model_7b, Quant.Q8_0, 8192)
        q4 = estimate_memory_gb(model_7b, Quant.Q4_K_M, 8192)
        assert q8 > q4

    def test_longer_context_requires_more_memory(self, model_7b):
        mem_8k = estimate_memory_gb(model_7b, Quant.Q4_K_M, 8192)
        mem_4k = estimate_memory_gb(model_7b, Quant.Q4_K_M, 4096)
        assert mem_8k > mem_4k

    def test_overhead_is_included(self, model_1b):
        """Even a tiny model must report > 0.5 GB (overhead alone)."""
        result = estimate_memory_gb(model_1b, Quant.Q2_K, 512)
        assert result > 0.5

    def test_all_quants_return_positive(self, model_7b):
        for q in Quant:
            result = estimate_memory_gb(model_7b, q, 4096)
            assert result > 0, f"Memory for {q} must be positive"

    def test_1b_q4km_fits_in_2gb(self, model_1b):
        """~1B model at Q4_K_M should fit comfortably under 2 GB."""
        result = estimate_memory_gb(model_1b, Quant.Q4_K_M, 8192)
        assert result < 2.0, f"1B Q4_K_M unexpectedly large: {result:.2f} GB"
