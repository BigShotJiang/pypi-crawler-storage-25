"""Tests for the JSON render output — structure and content validation."""

import json

import pytest

from tinillm.analyzer.types import FitLevel, LlmModel, ModelFit, Quant
from tinillm.hardware.types import CpuInfo, GpuInfo, SystemSpecs
from tinillm.render.report import render_json


@pytest.fixture
def specs_with_gpu():
    return SystemSpecs(
        cpu=CpuInfo("Intel Core i9-13900K", 24, 32, 5800.0),
        total_ram_gb=32.0,
        free_ram_gb=24.0,
        gpus=[GpuInfo("NVIDIA GeForce RTX 4090", 24.0, "CUDA")],
        os="Linux",
    )


@pytest.fixture
def specs_no_gpu():
    return SystemSpecs(
        cpu=CpuInfo("AMD Ryzen 7 5800X", 8, 16, 3800.0),
        total_ram_gb=16.0,
        free_ram_gb=10.0,
        gpus=[],
        os="Linux",
    )


@pytest.fixture
def sample_fits():
    model_7b = LlmModel("~7B", 7.0, 32, 8, 128, 8192)
    model_70b = LlmModel("~70B", 70.0, 80, 8, 128, 4096)
    return [
        ModelFit(
            model=model_7b,
            fit_level=FitLevel.PERFECT,
            best_quant=Quant.Q6_K,
            mem_required_gb=6.2,
            tokens_per_sec=88.0,
            runs_on_gpu=True,
        ),
        ModelFit(
            model=model_70b,
            fit_level=FitLevel.TOO_TIGHT,
            best_quant=None,
            mem_required_gb=None,
            tokens_per_sec=None,
            runs_on_gpu=True,
        ),
    ]


class TestRenderJson:
    def test_output_is_valid_json(self, specs_with_gpu, sample_fits):
        output = render_json(specs_with_gpu, sample_fits)
        json.loads(output)  # must not raise

    def test_hardware_section_present(self, specs_with_gpu, sample_fits):
        payload = json.loads(render_json(specs_with_gpu, sample_fits))
        assert "hardware" in payload

    def test_fits_section_present(self, specs_with_gpu, sample_fits):
        payload = json.loads(render_json(specs_with_gpu, sample_fits))
        assert "fits" in payload
        assert len(payload["fits"]) == 2

    def test_cpu_fields_correct(self, specs_with_gpu, sample_fits):
        payload = json.loads(render_json(specs_with_gpu, sample_fits))
        cpu = payload["hardware"]["cpu"]
        assert cpu["model"] == "Intel Core i9-13900K"
        assert cpu["physical_cores"] == 24
        assert cpu["logical_cores"] == 32
        assert cpu["freq_mhz"] == 5800.0

    def test_ram_fields_correct(self, specs_with_gpu, sample_fits):
        payload = json.loads(render_json(specs_with_gpu, sample_fits))
        ram = payload["hardware"]["ram"]
        assert ram["total_gb"] == 32.0
        assert ram["free_gb"] == 24.0

    def test_gpu_fields_correct(self, specs_with_gpu, sample_fits):
        payload = json.loads(render_json(specs_with_gpu, sample_fits))
        gpus = payload["hardware"]["gpus"]
        assert len(gpus) == 1
        gpu = gpus[0]
        assert gpu["name"] == "NVIDIA GeForce RTX 4090"
        assert gpu["vram_gb"] == 24.0
        assert gpu["backend"] == "CUDA"
        assert gpu["unified_memory"] is False

    def test_no_gpu_returns_empty_list(self, specs_no_gpu, sample_fits):
        payload = json.loads(render_json(specs_no_gpu, sample_fits))
        assert payload["hardware"]["gpus"] == []

    def test_perfect_fit_has_all_fields(self, specs_with_gpu, sample_fits):
        payload = json.loads(render_json(specs_with_gpu, sample_fits))
        fit = next(f for f in payload["fits"] if f["fit_level"] == "Perfect")
        assert fit["best_quant"] == "Q6_K"
        assert fit["mem_required_gb"] == 6.2
        assert fit["tokens_per_sec"] == 88.0
        assert fit["runs_on_gpu"] is True

    def test_toottight_has_null_fields(self, specs_with_gpu, sample_fits):
        payload = json.loads(render_json(specs_with_gpu, sample_fits))
        fit = next(f for f in payload["fits"] if f["fit_level"] == "TooTight")
        assert fit["best_quant"] is None
        assert fit["mem_required_gb"] is None
        assert fit["tokens_per_sec"] is None

    def test_os_field_correct(self, specs_with_gpu, sample_fits):
        payload = json.loads(render_json(specs_with_gpu, sample_fits))
        assert payload["hardware"]["os"] == "Linux"

    def test_unified_memory_gpu(self, sample_fits):
        specs = SystemSpecs(
            cpu=CpuInfo("Apple M3 Max", 12, 12, 4050.0),
            total_ram_gb=96.0,
            free_ram_gb=70.0,
            gpus=[GpuInfo("Apple M3 Max", 96.0, "Metal", unified_memory=True)],
            os="macOS",
        )
        payload = json.loads(render_json(specs, sample_fits))
        gpu = payload["hardware"]["gpus"][0]
        assert gpu["unified_memory"] is True
        assert gpu["backend"] == "Metal"
