"""Integration tests for the hardware detection orchestrator.

Uses mocking to simulate different hardware configurations
without needing real GPU tools installed.
"""

from __future__ import annotations

import sys
from unittest.mock import MagicMock, patch

import pytest

from tinillm.hardware.detect import detect, _detect_all_gpus, _os_name
from tinillm.hardware.types import CpuInfo, GpuInfo, SystemSpecs


class TestDetectOrchestrator:
    def test_detect_returns_system_specs(self):
        specs = detect()
        assert isinstance(specs, SystemSpecs)

    def test_cpu_has_model_name(self):
        specs = detect()
        assert isinstance(specs.cpu.model_name, str)
        assert len(specs.cpu.model_name) > 0

    def test_cpu_cores_are_positive(self):
        specs = detect()
        assert specs.cpu.physical_cores >= 1
        assert specs.cpu.logical_cores >= specs.cpu.physical_cores

    def test_ram_is_positive(self):
        specs = detect()
        assert specs.total_ram_gb > 0
        assert specs.free_ram_gb >= 0
        assert specs.free_ram_gb <= specs.total_ram_gb

    def test_os_is_known_value(self):
        specs = detect()
        assert specs.os in ("Linux", "macOS", "Windows")

    def test_gpus_is_a_list(self):
        specs = detect()
        assert isinstance(specs.gpus, list)

    def test_gpus_have_positive_vram_if_present(self):
        specs = detect()
        for gpu in specs.gpus:
            assert isinstance(gpu, GpuInfo)
            assert gpu.vram_gb >= 0
            assert gpu.backend in ("CUDA", "ROCm", "Metal", "Vulkan", "DirectX")


class TestOsName:
    def test_linux(self):
        with patch("sys.platform", "linux"):
            assert _os_name() == "Linux"

    def test_darwin(self):
        with patch("sys.platform", "darwin"):
            assert _os_name() == "macOS"

    def test_windows(self):
        with patch("sys.platform", "win32"):
            assert _os_name() == "Windows"


class TestDetectAllGpus:
    def test_no_gpu_tools_returns_empty_or_list(self):
        """When no GPU tools are available, detect should not crash."""
        with patch("tinillm.hardware.detect.detect_nvidia_gpus", return_value=[]), \
             patch("tinillm.hardware.detect.detect_amd_gpus", return_value=[]), \
             patch("tinillm.hardware.detect.detect_intel_gpus", return_value=[]), \
             patch("tinillm.hardware.detect.detect_vulkan_gpus", return_value=[]), \
             patch("sys.platform", "linux"):
            gpus = _detect_all_gpus(16.0)
        assert isinstance(gpus, list)

    def test_nvidia_gpu_found_is_returned(self):
        fake_gpu = GpuInfo(name="NVIDIA GeForce RTX 4090", vram_gb=24.0, backend="CUDA")
        with patch("tinillm.hardware.detect.detect_nvidia_gpus", return_value=[fake_gpu]), \
             patch("tinillm.hardware.detect.detect_amd_gpus", return_value=[]), \
             patch("tinillm.hardware.detect.detect_intel_gpus", return_value=[]), \
             patch("sys.platform", "linux"):
            gpus = _detect_all_gpus(16.0)
        assert len(gpus) == 1
        assert gpus[0].name == "NVIDIA GeForce RTX 4090"

    def test_vulkan_fallback_only_when_no_gpus_found(self):
        fake_vulkan = GpuInfo(name="NVIDIA GeForce RTX 4090", vram_gb=0.0, backend="Vulkan")
        with patch("tinillm.hardware.detect.detect_nvidia_gpus", return_value=[]), \
             patch("tinillm.hardware.detect.detect_amd_gpus", return_value=[]), \
             patch("tinillm.hardware.detect.detect_intel_gpus", return_value=[]), \
             patch("tinillm.hardware.detect.detect_vulkan_gpus", return_value=[fake_vulkan]), \
             patch("sys.platform", "linux"):
            gpus = _detect_all_gpus(16.0)
        assert len(gpus) == 1
        assert gpus[0].backend == "Vulkan"

    def test_vulkan_not_called_when_gpu_already_found(self):
        fake_gpu = GpuInfo(name="NVIDIA GeForce RTX 3060", vram_gb=12.0, backend="CUDA")
        mock_vulkan = MagicMock(return_value=[])
        with patch("tinillm.hardware.detect.detect_nvidia_gpus", return_value=[fake_gpu]), \
             patch("tinillm.hardware.detect.detect_amd_gpus", return_value=[]), \
             patch("tinillm.hardware.detect.detect_intel_gpus", return_value=[]), \
             patch("tinillm.hardware.detect.detect_vulkan_gpus", mock_vulkan), \
             patch("sys.platform", "linux"):
            _detect_all_gpus(16.0)
        mock_vulkan.assert_not_called()

    def test_apple_silicon_uses_apple_detector_only(self):
        fake_gpu = GpuInfo(name="Apple M3 Max", vram_gb=96.0, backend="Metal", unified_memory=True)
        mock_nvidia = MagicMock(return_value=[])
        with patch("tinillm.hardware.detect.detect_apple_gpus", return_value=[fake_gpu]), \
             patch("tinillm.hardware.detect.detect_nvidia_gpus", mock_nvidia), \
             patch("sys.platform", "darwin"):
            gpus = _detect_all_gpus(96.0)
        mock_nvidia.assert_not_called()
        assert len(gpus) == 1
        assert gpus[0].unified_memory is True
