"""Shared test fixtures for tinillm tests."""

import pytest

from tinillm.hardware.types import CpuInfo, GpuInfo, SystemSpecs
from tinillm.analyzer.types import FitLevel, LlmModel, ModelFit, Quant


# ── Hardware fixture helpers ──────────────────────────────────────────────────

@pytest.fixture
def cpu_i9() -> CpuInfo:
    return CpuInfo(
        model_name="Intel Core i9-13900K",
        physical_cores=24,
        logical_cores=32,
        freq_mhz=5800.0,
    )


@pytest.fixture
def gpu_rtx4090() -> GpuInfo:
    return GpuInfo(name="NVIDIA GeForce RTX 4090", vram_gb=24.0, backend="CUDA")


@pytest.fixture
def gpu_rtx3060() -> GpuInfo:
    return GpuInfo(name="NVIDIA GeForce RTX 3060", vram_gb=12.0, backend="CUDA")


@pytest.fixture
def gpu_apple_m3_max() -> GpuInfo:
    return GpuInfo(
        name="Apple M3 Max",
        vram_gb=96.0,
        backend="Metal",
        unified_memory=True,
    )


@pytest.fixture
def gpu_rx7900xtx() -> GpuInfo:
    return GpuInfo(name="AMD Radeon RX 7900 XTX", vram_gb=24.0, backend="ROCm")


# ── SystemSpecs fixtures ──────────────────────────────────────────────────────

@pytest.fixture
def specs_high_end(cpu_i9, gpu_rtx4090) -> SystemSpecs:
    """High-end desktop: RTX 4090 + 32 GB RAM."""
    return SystemSpecs(
        cpu=cpu_i9,
        total_ram_gb=32.0,
        free_ram_gb=24.0,
        gpus=[gpu_rtx4090],
        os="Linux",
    )


@pytest.fixture
def specs_mid_range(cpu_i9, gpu_rtx3060) -> SystemSpecs:
    """Mid-range: RTX 3060 (12 GB) + 16 GB RAM."""
    return SystemSpecs(
        cpu=cpu_i9,
        total_ram_gb=16.0,
        free_ram_gb=12.0,
        gpus=[gpu_rtx3060],
        os="Linux",
    )


@pytest.fixture
def specs_cpu_only() -> SystemSpecs:
    """CPU-only machine: 16 GB RAM, no GPU."""
    return SystemSpecs(
        cpu=CpuInfo("AMD Ryzen 7 5800X", 8, 16, 3800.0),
        total_ram_gb=16.0,
        free_ram_gb=10.0,
        gpus=[],
        os="Linux",
    )


@pytest.fixture
def specs_low_ram() -> SystemSpecs:
    """Low-RAM machine: 4 GB total, no GPU."""
    return SystemSpecs(
        cpu=CpuInfo("Intel Core i5-6300U", 2, 4, 2400.0),
        total_ram_gb=4.0,
        free_ram_gb=2.5,
        gpus=[],
        os="Linux",
    )


@pytest.fixture
def specs_apple_silicon(gpu_apple_m3_max) -> SystemSpecs:
    """Apple M3 Max with 96 GB unified memory."""
    return SystemSpecs(
        cpu=CpuInfo("Apple M3 Max", 12, 12, 4050.0),
        total_ram_gb=96.0,
        free_ram_gb=70.0,
        gpus=[gpu_apple_m3_max],
        os="macOS",
    )


@pytest.fixture
def specs_multi_gpu(cpu_i9) -> SystemSpecs:
    """Dual RTX 3090 — should use single-card budget (24 GB)."""
    cards = [
        GpuInfo(name="NVIDIA GeForce RTX 3090", vram_gb=24.0, backend="CUDA", count=2),
    ]
    return SystemSpecs(
        cpu=cpu_i9, total_ram_gb=128.0, free_ram_gb=100.0,
        gpus=cards, os="Linux",
    )


# ── LlmModel fixture ─────────────────────────────────────────────────────────

@pytest.fixture
def model_7b() -> LlmModel:
    return LlmModel(
        name="~7B", params_b=7.0, num_layers=32,
        num_kv_heads=8, head_dim=128, context_length=8192,
    )


@pytest.fixture
def model_70b() -> LlmModel:
    return LlmModel(
        name="~70B", params_b=70.0, num_layers=80,
        num_kv_heads=8, head_dim=128, context_length=4096,
    )
