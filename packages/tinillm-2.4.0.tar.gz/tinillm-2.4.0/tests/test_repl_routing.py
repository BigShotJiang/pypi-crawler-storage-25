"""REPL routing: bare prompt → slash command vs. agent chat.

Pins down the unified-prompt behaviour: natural language flows into
``ChatSession.handle_user_turn``; slash commands stay in their own channels.
The startup side-effects (welcome banner, scan+doctor, first-launch scan) are
mocked out so the test runs in under a second.
"""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import tinillm.repl  # noqa: F401  — required so patch targets resolve


def _mute_startup():
    """Patch the noisy run_repl side-effects so tests only exercise the loop."""
    return [
        patch("tinillm.repl.render_welcome"),
        patch("tinillm.repl._run_startup_checks"),
        patch("tinillm.repl._is_first_launch", return_value=False),
    ]


def _drive_repl(lines):
    """Run ``run_repl`` with ``lines`` scripted as prompt_toolkit input.

    After the list is exhausted an EOFError breaks the loop (matches Ctrl+D).
    Returns the ChatSession mock so callers can inspect call history.
    """
    chat_mock = MagicMock()

    class ScriptedPrompt:
        def __init__(self):
            self._it = iter(lines)

        def prompt(self, *args, **kwargs):
            try:
                return next(self._it)
            except StopIteration:
                raise EOFError

    with patch("tinillm.repl._make_session", return_value=ScriptedPrompt()):
        with patch("tinillm.run.chat_session.ChatSession.create", return_value=chat_mock):
            muted = _mute_startup()
            for m in muted:
                m.start()
            try:
                from tinillm.repl import run_repl
                run_repl()
            finally:
                for m in muted:
                    m.stop()
    return chat_mock


class TestFreetextRoutesToAgent:
    def test_natural_language_calls_handle_user_turn(self):
        chat = _drive_repl(["list the files"])
        chat.handle_user_turn.assert_called_once_with("list the files")
        chat.handle_slash.assert_not_called()

    def test_multiple_turns_each_dispatched(self):
        chat = _drive_repl(["first prompt", "second prompt"])
        calls = [c.args[0] for c in chat.handle_user_turn.call_args_list]
        assert calls == ["first prompt", "second prompt"]

    def test_in_chat_slash_routes_to_handle_slash(self):
        chat = _drive_repl(["/plan"])
        chat.handle_slash.assert_called_once_with("/plan")
        chat.handle_user_turn.assert_not_called()

    def test_click_slash_does_not_touch_chat_session(self):
        """/scan is a Click command — must not trigger ChatSession.create."""
        with patch("tinillm.run.chat_session.ChatSession.create") as create_mock:
            with patch("tinillm.repl._dispatch_click_slash") as click_mock:
                class ScriptedPrompt:
                    def __init__(self):
                        self._it = iter(["/scan --help"])

                    def prompt(self, *args, **kwargs):
                        try:
                            return next(self._it)
                        except StopIteration:
                            raise EOFError

                with patch("tinillm.repl._make_session", return_value=ScriptedPrompt()):
                    muted = _mute_startup()
                    for m in muted:
                        m.start()
                    try:
                        from tinillm.repl import run_repl
                        run_repl()
                    finally:
                        for m in muted:
                            m.stop()
                click_mock.assert_called_once()
                create_mock.assert_not_called()

    def test_exit_breaks_without_creating_session(self):
        with patch("tinillm.run.chat_session.ChatSession.create") as create_mock:
            class ScriptedPrompt:
                def __init__(self):
                    self._it = iter(["/exit"])

                def prompt(self, *args, **kwargs):
                    try:
                        return next(self._it)
                    except StopIteration:
                        raise EOFError

            with patch("tinillm.repl._make_session", return_value=ScriptedPrompt()):
                muted = _mute_startup()
                for m in muted:
                    m.start()
                try:
                    from tinillm.repl import run_repl
                    run_repl()
                finally:
                    for m in muted:
                        m.stop()
            create_mock.assert_not_called()
