"""CLI tests for `tinillm models` — user-facing behaviour and all flags."""

import json
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tinillm.commands import models_cmd


@pytest.fixture
def runner():
    return CliRunner()


# ── Help text ──────────────────────────────────────────────────────────────

class TestModelsHelp:
    def test_models_help_shows_all_flags(self, runner):
        result = runner.invoke(models_cmd, ["--help"])
        assert result.exit_code == 0
        for flag in ["--filter", "--size", "--fits-only", "--ollama", "--json", "--no-color"]:
            assert flag in result.output

    def test_models_help_shows_description(self, runner):
        result = runner.invoke(models_cmd, ["--help"])
        assert "llm" in result.output.lower() or "model" in result.output.lower()


# ── Default models output ─────────────────────────────────────────────────

class TestDefaultModels:
    def test_exits_zero(self, runner):
        result = runner.invoke(models_cmd, [])
        assert result.exit_code == 0, result.output

    def test_shows_header_panel(self, runner):
        result = runner.invoke(models_cmd, [])
        assert "tinillm models" in result.output

    def test_shows_hardware_budget(self, runner):
        result = runner.invoke(models_cmd, [])
        assert "budget" in result.output.lower()
        assert "GB" in result.output

    def test_shows_model_names(self, runner):
        result = runner.invoke(models_cmd, [])
        assert any(name in result.output for name in ["Llama", "Mistral", "Qwen", "SmolLM", "Gemma"])

    def test_shows_fit_levels(self, runner):
        result = runner.invoke(models_cmd, [])
        assert any(level in result.output for level in ["Perfect", "Good", "Marginal", "TooTight"])

    def test_shows_legend(self, runner):
        result = runner.invoke(models_cmd, [])
        assert "Perfect" in result.output
        assert "TooTight" in result.output

    def test_shows_ollama_tip(self, runner):
        result = runner.invoke(models_cmd, [])
        assert "ollama" in result.output.lower()


# ── --filter flag ─────────────────────────────────────────────────────────

class TestFilterFlag:
    def test_filter_llama_returns_only_llama_models(self, runner):
        result = runner.invoke(models_cmd, ["--filter", "llama"])
        assert result.exit_code == 0
        lines = [l for l in result.output.splitlines() if "Qwen" in l or "Mistral" in l or "Gemma" in l]
        assert len(lines) == 0, "Non-Llama models appeared with --filter llama"

    def test_filter_is_case_insensitive(self, runner):
        lower = runner.invoke(models_cmd, ["--filter", "llama"])
        upper = runner.invoke(models_cmd, ["--filter", "LLAMA"])
        assert lower.exit_code == 0
        assert upper.exit_code == 0
        # Both should show same number of results
        def count_rows(output):
            return sum(1 for l in output.splitlines() if "Llama" in l or "llama" in l.lower())
        assert count_rows(lower.output) == count_rows(upper.output)

    def test_filter_no_match_shows_no_models_message(self, runner):
        result = runner.invoke(models_cmd, ["--filter", "xyznonexistentmodel999"])
        assert result.exit_code == 0
        assert "No models" in result.output or "0 models" in result.output

    def test_filter_by_provider(self, runner):
        result = runner.invoke(models_cmd, ["--filter", "google"])
        assert result.exit_code == 0
        assert "Gemma" in result.output


# ── --size flag ───────────────────────────────────────────────────────────

class TestSizeFlag:
    def test_size_7b_shows_7b_bracket_models(self, runner):
        result = runner.invoke(models_cmd, ["--size", "7b"])
        assert result.exit_code == 0
        # All shown models should be in 4–10B range
        assert "7B" in result.output or "8B" in result.output or "TooTight" in result.output

    def test_size_1b_shows_small_models(self, runner):
        result = runner.invoke(models_cmd, ["--size", "1b"])
        assert result.exit_code == 0
        assert "M" in result.output or "1B" in result.output  # sub-1B or 1B models

    def test_invalid_size_exits_nonzero(self, runner):
        result = runner.invoke(models_cmd, ["--size", "999b"])
        assert result.exit_code != 0

    def test_valid_sizes_all_work(self, runner):
        for size in ["1b", "3b", "7b", "13b", "34b", "70b"]:
            result = runner.invoke(models_cmd, ["--size", size])
            assert result.exit_code == 0, f"--size {size} failed"


# ── --fits-only flag ──────────────────────────────────────────────────────

class TestFitsOnlyFlag:
    def test_fits_only_hides_toottight(self, runner):
        default = runner.invoke(models_cmd, [])
        fits_only = runner.invoke(models_cmd, ["--fits-only"])
        assert fits_only.exit_code == 0

        def count_rows(output):
            return sum(1 for l in output.splitlines()
                       if any(s in l for s in ["Perfect", "Good", "Marginal", "TooTight"])
                       and any(c.isalpha() for c in l[:30]))

        # fits-only must show ≤ default
        assert count_rows(fits_only.output) <= count_rows(default.output)

    def test_fits_only_no_toottight_rows(self, runner):
        result = runner.invoke(models_cmd, ["--fits-only"])
        # TooTight rows should not appear (only in legend footer is OK)
        data_lines = [l for l in result.output.splitlines()
                      if "TooTight" in l and "·" not in l]
        assert len(data_lines) == 0, "TooTight rows shown with --fits-only"


# ── --json flag ───────────────────────────────────────────────────────────

class TestModelsJsonFlag:
    def test_json_is_valid(self, runner):
        result = runner.invoke(models_cmd, ["--json"])
        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert isinstance(payload, dict)

    def test_json_has_models_key(self, runner):
        result = runner.invoke(models_cmd, ["--json"])
        payload = json.loads(result.output)
        assert "models" in payload
        assert isinstance(payload["models"], list)

    def test_json_models_have_required_fields(self, runner):
        result = runner.invoke(models_cmd, ["--json"])
        models = json.loads(result.output)["models"]
        assert len(models) > 0
        for m in models:
            assert "name" in m
            assert "display_name" in m
            assert "provider" in m
            assert "fit_level" in m
            assert "ollama_tag" in m
            assert m["fit_level"] in ("Perfect", "Good", "Marginal", "TooTight")

    def test_json_toottight_has_null_fields(self, runner):
        result = runner.invoke(models_cmd, ["--json"])
        models = json.loads(result.output)["models"]
        for m in models:
            if m["fit_level"] == "TooTight":
                assert m["best_quant"] is None
                assert m["mem_required_gb"] is None
                assert m["tokens_per_sec"] is None

    def test_json_runnable_has_numeric_fields(self, runner):
        result = runner.invoke(models_cmd, ["--json"])
        models = json.loads(result.output)["models"]
        for m in models:
            if m["fit_level"] != "TooTight":
                assert m["best_quant"] is not None
                assert isinstance(m["mem_required_gb"], (int, float))
                assert isinstance(m["tokens_per_sec"], (int, float))
                assert m["mem_required_gb"] > 0
                assert m["tokens_per_sec"] > 0

    def test_json_filter_works_with_json(self, runner):
        result = runner.invoke(models_cmd, ["--filter", "llama", "--json"])
        models = json.loads(result.output)["models"]
        for m in models:
            assert "llama" in m["display_name"].lower() or "llama" in m["provider"].lower()

    def test_json_fits_only_with_json(self, runner):
        result = runner.invoke(models_cmd, ["--fits-only", "--json"])
        models = json.loads(result.output)["models"]
        for m in models:
            assert m["fit_level"] != "TooTight"

    def test_json_ollama_flag_adds_installed_field(self, runner):
        with patch("tinillm.models.cmd._fetch_ollama_installed", return_value=set()):
            result = runner.invoke(models_cmd, ["--ollama", "--json"])
        models = json.loads(result.output)["models"]
        for m in models:
            assert "installed" in m


# ── --no-color flag ───────────────────────────────────────────────────────

class TestNoColorFlag:
    def test_no_color_exits_zero(self, runner):
        result = runner.invoke(models_cmd, ["--no-color"])
        assert result.exit_code == 0

    def test_no_color_still_shows_content(self, runner):
        result = runner.invoke(models_cmd, ["--no-color"])
        assert "tinillm models" in result.output

    def test_no_color_has_no_ansi_codes(self, runner):
        result = runner.invoke(models_cmd, ["--no-color"])
        assert "\x1b[" not in result.output


# ── --ollama flag (mocked) ────────────────────────────────────────────────

class TestOllamaFlag:
    def test_ollama_flag_shows_installed_column(self, runner):
        with patch("tinillm.models.cmd._fetch_ollama_installed", return_value={"llama3.2:3b"}):
            result = runner.invoke(models_cmd, ["--ollama", "--filter", "llama"])
        assert result.exit_code == 0
        assert "Installed" in result.output

    def test_ollama_unavailable_does_not_crash(self, runner):
        with patch("tinillm.models.cmd._fetch_ollama_installed", return_value=set()):
            result = runner.invoke(models_cmd, ["--ollama"])
        assert result.exit_code == 0

    def test_ollama_marks_installed_model(self, runner):
        with patch("tinillm.models.cmd._fetch_ollama_installed", return_value={"llama3.2:3b"}):
            result = runner.invoke(models_cmd, ["--ollama", "--filter", "llama", "--json"])
        models = json.loads(result.output)["models"]
        llama32_3b = next((m for m in models if m["name"] == "llama3.2:3b"), None)
        if llama32_3b:
            assert llama32_3b["installed"] is True

    def test_non_installed_model_marked_false(self, runner):
        with patch("tinillm.models.cmd._fetch_ollama_installed", return_value=set()):
            result = runner.invoke(models_cmd, ["--ollama", "--json"])
        models = json.loads(result.output)["models"]
        for m in models:
            assert m["installed"] is False


# ── Combined flags ────────────────────────────────────────────────────────

class TestCombinedFlags:
    def test_filter_and_size_together(self, runner):
        result = runner.invoke(models_cmd, ["--filter", "qwen", "--size", "7b"])
        assert result.exit_code == 0

    def test_fits_only_and_json(self, runner):
        result = runner.invoke(models_cmd, ["--fits-only", "--json"])
        assert result.exit_code == 0
        models = json.loads(result.output)["models"]
        for m in models:
            assert m["fit_level"] != "TooTight"

    def test_filter_fits_only_json(self, runner):
        result = runner.invoke(models_cmd, ["--filter", "llama", "--fits-only", "--json"])
        assert result.exit_code == 0
        models = json.loads(result.output)["models"]
        for m in models:
            assert "llama" in m["display_name"].lower() or "llama" in m["provider"].lower()
            assert m["fit_level"] != "TooTight"
