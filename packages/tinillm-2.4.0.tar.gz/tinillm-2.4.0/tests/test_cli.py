"""CLI integration tests for the /scan slash command.

After the REPL-only refactor, `scan` is no longer a shell subcommand — it's a
slash command inside the REPL. These tests exercise the underlying Click
Command object (`scan_cmd`) directly, which is the same object the REPL
dispatches to. Coverage is identical to the pre-refactor shell-level tests.
"""

import json

import pytest
from click.testing import CliRunner

from tinillm.commands import scan_cmd
from tinillm.main import app


@pytest.fixture
def runner():
    return CliRunner()


# ── Top-level `tinillm` CLI ────────────────────────────────────────────────────

class TestTopLevelCLI:
    def test_help_describes_repl(self, runner):
        """`tinillm --help` should explain that `tinillm` launches the REPL."""
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        # Must mention the interactive tool, not list subcommands
        assert "interactive" in result.output.lower() or "repl" in result.output.lower() \
            or "/scan" in result.output

    def test_version_flag_works(self, runner):
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert "tinillm" in result.output

    def test_unknown_shell_subcommand_fails(self, runner):
        """`tinillm scan` must no longer work from the shell."""
        result = runner.invoke(app, ["scan"])
        assert result.exit_code != 0


# ── /scan help text ────────────────────────────────────────────────────────────

class TestHelpText:
    def test_scan_help_shows_all_flags(self, runner):
        result = runner.invoke(scan_cmd, ["--help"])
        assert result.exit_code == 0
        for flag in ["--json", "--no-color", "--verbose"]:
            assert flag in result.output

    def test_scan_help_shows_description(self, runner):
        result = runner.invoke(scan_cmd, ["--help"])
        assert result.exit_code == 0
        assert "hardware" in result.output.lower() or "llm" in result.output.lower()


# ── Default scan output ────────────────────────────────────────────────────

class TestDefaultScan:
    def test_scan_exits_zero(self, runner):
        result = runner.invoke(scan_cmd, [])
        assert result.exit_code == 0, f"Unexpected exit: {result.output}"

    def test_scan_shows_hardware_panel(self, runner):
        result = runner.invoke(scan_cmd, [])
        assert result.exit_code == 0
        assert "Hardware Report" in result.output

    def test_scan_shows_cpu_info(self, runner):
        result = runner.invoke(scan_cmd, [])
        assert "CPU" in result.output

    def test_scan_shows_ram_info(self, runner):
        result = runner.invoke(scan_cmd, [])
        assert "RAM" in result.output
        assert "GB" in result.output

    def test_scan_shows_capability_matrix(self, runner):
        result = runner.invoke(scan_cmd, [])
        assert "LLM Capability Matrix" in result.output

    def test_scan_matrix_has_model_column(self, runner):
        result = runner.invoke(scan_cmd, [])
        assert any(size in result.output for size in ["~1B", "~3B", "~7B", "~13B", "~34B", "~70B"])

    def test_scan_shows_fit_legend(self, runner):
        result = runner.invoke(scan_cmd, [])
        assert "Perfect" in result.output or "Marginal" in result.output or "TooTight" in result.output

    def test_scan_hides_toottight_by_default(self, runner):
        result = runner.invoke(scan_cmd, [])
        assert result.exit_code == 0
        lines = result.output.splitlines()
        if any("TooTight" in l for l in lines):
            assert any("verbose" in l.lower() for l in lines), (
                "TooTight rows shown without --verbose and no hint to user"
            )


# ── --verbose flag ─────────────────────────────────────────────────────────

class TestVerboseFlag:
    def test_verbose_shows_more_rows_than_default(self, runner):
        default = runner.invoke(scan_cmd, [])
        verbose = runner.invoke(scan_cmd, ["--verbose"])
        assert verbose.exit_code == 0

        def count_model_rows(output):
            return sum(
                1 for line in output.splitlines()
                if any(s in line for s in ["~1B", "~3B", "~7B", "~13B", "~34B", "~70B"])
            )

        default_rows = count_model_rows(default.output)
        verbose_rows = count_model_rows(verbose.output)
        assert verbose_rows >= default_rows

    def test_verbose_short_flag_works(self, runner):
        result = runner.invoke(scan_cmd, ["-v"])
        assert result.exit_code == 0

    def test_verbose_shows_toottight_label(self, runner):
        result = runner.invoke(scan_cmd, ["--verbose"])
        assert result.exit_code == 0
        assert "TooTight" in result.output


# ── --json flag ────────────────────────────────────────────────────────────

class TestJsonFlag:
    def test_json_output_is_valid_json(self, runner):
        result = runner.invoke(scan_cmd, ["--json"])
        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert isinstance(payload, dict)

    def test_json_has_hardware_key(self, runner):
        result = runner.invoke(scan_cmd, ["--json"])
        payload = json.loads(result.output)
        assert "hardware" in payload

    def test_json_has_fits_key(self, runner):
        result = runner.invoke(scan_cmd, ["--json"])
        payload = json.loads(result.output)
        assert "fits" in payload
        assert isinstance(payload["fits"], list)

    def test_json_hardware_has_cpu_ram_gpus(self, runner):
        result = runner.invoke(scan_cmd, ["--json"])
        payload = json.loads(result.output)
        hw = payload["hardware"]
        assert "cpu" in hw
        assert "ram" in hw
        assert "gpus" in hw

    def test_json_cpu_has_required_fields(self, runner):
        result = runner.invoke(scan_cmd, ["--json"])
        hw = json.loads(result.output)["hardware"]
        cpu = hw["cpu"]
        assert "model" in cpu
        assert "physical_cores" in cpu
        assert "logical_cores" in cpu
        assert cpu["physical_cores"] >= 1
        assert cpu["logical_cores"] >= cpu["physical_cores"]

    def test_json_ram_is_positive(self, runner):
        result = runner.invoke(scan_cmd, ["--json"])
        hw = json.loads(result.output)["hardware"]
        assert hw["ram"]["total_gb"] > 0
        assert hw["ram"]["free_gb"] >= 0

    def test_json_fits_have_required_fields(self, runner):
        result = runner.invoke(scan_cmd, ["--json"])
        fits = json.loads(result.output)["fits"]
        assert len(fits) > 0
        for fit in fits:
            assert "model" in fit
            assert "fit_level" in fit
            assert "params_b" in fit
            assert fit["fit_level"] in ("Perfect", "Good", "Marginal", "TooTight")

    def test_json_fit_toottight_has_null_fields(self, runner):
        result = runner.invoke(scan_cmd, ["--json"])
        fits = json.loads(result.output)["fits"]
        for fit in fits:
            if fit["fit_level"] == "TooTight":
                assert fit["best_quant"] is None
                assert fit["mem_required_gb"] is None
                assert fit["tokens_per_sec"] is None

    def test_json_fit_runnable_has_numeric_fields(self, runner):
        result = runner.invoke(scan_cmd, ["--json"])
        fits = json.loads(result.output)["fits"]
        for fit in fits:
            if fit["fit_level"] != "TooTight":
                assert fit["best_quant"] is not None
                assert isinstance(fit["mem_required_gb"], (int, float))
                assert isinstance(fit["tokens_per_sec"], (int, float))
                assert fit["mem_required_gb"] > 0
                assert fit["tokens_per_sec"] > 0

    def test_json_models_are_ordered_by_size(self, runner):
        result = runner.invoke(scan_cmd, ["--json"])
        fits = json.loads(result.output)["fits"]
        sizes = [f["params_b"] for f in fits]
        assert sizes == sorted(sizes), "Model fits must be ordered smallest → largest"

    def test_json_os_field_is_present(self, runner):
        result = runner.invoke(scan_cmd, ["--json"])
        hw = json.loads(result.output)["hardware"]
        assert hw["os"] in ("Linux", "macOS", "Windows")


# ── --no-color flag ────────────────────────────────────────────────────────

class TestNoColorFlag:
    def test_no_color_exits_zero(self, runner):
        result = runner.invoke(scan_cmd, ["--no-color"])
        assert result.exit_code == 0

    def test_no_color_still_shows_content(self, runner):
        result = runner.invoke(scan_cmd, ["--no-color"])
        assert "Hardware Report" in result.output
        assert "LLM Capability Matrix" in result.output

    def test_no_color_output_has_no_ansi_codes(self, runner):
        result = runner.invoke(scan_cmd, ["--no-color"])
        assert "\x1b[" not in result.output, "ANSI codes found in --no-color output"


# ── Error handling ─────────────────────────────────────────────────────────

class TestErrorHandling:
    def test_unknown_flag_exits_nonzero(self, runner):
        result = runner.invoke(scan_cmd, ["--bogus-flag"])
        assert result.exit_code != 0

    def test_unknown_flag_shows_error_message(self, runner):
        result = runner.invoke(scan_cmd, ["--bogus-flag"])
        assert "error" in result.output.lower() or "no such option" in result.output.lower()


# ── Pipe / scripting usage (JSON still parseable when driven programmatically) ─

class TestPipeAndScripting:
    def test_json_is_machine_parseable(self, runner):
        result = runner.invoke(scan_cmd, ["--json"])
        payload = json.loads(result.output)
        total_gb = payload["hardware"]["ram"]["total_gb"]
        assert isinstance(total_gb, float)
        assert total_gb > 0

    def test_json_fit_filter(self, runner):
        result = runner.invoke(scan_cmd, ["--json"])
        fits = json.loads(result.output)["fits"]
        runnable = [f for f in fits if f["fit_level"] in ("Perfect", "Good", "Marginal")]
        assert len(runnable) >= 0
        for fit in runnable:
            assert fit["tokens_per_sec"] is not None
            assert fit["mem_required_gb"] is not None

    def test_no_color_piped_output_is_clean_text(self, runner):
        result = runner.invoke(scan_cmd, ["--no-color"])
        for line in result.output.splitlines():
            assert "\x1b" not in line, f"ANSI code in line: {repr(line)}"
