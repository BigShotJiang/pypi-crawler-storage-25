"""Session JSONL — round-trip, ToolCall serialization, replace_all."""
from __future__ import annotations

import json

import pytest


@pytest.fixture
def store_mod(isolated_home):
    import tinillm.agent.session.store as m
    return m


class TestNewSession:
    def test_creates_files(self, store_mod):
        sess = store_mod.new_session("llama3:8b")
        assert sess.path.exists()
        assert sess.meta_path.exists()
        meta = json.loads(sess.meta_path.read_text())
        assert meta["model"] == "llama3:8b"
        assert meta["message_count"] == 0


class TestAppendAndLoad:
    def test_roundtrip_plain_message(self, store_mod):
        sess = store_mod.new_session("m")
        s = store_mod.SessionStore(sess)
        s.append({"role": "user", "content": "hi"})
        s.append({"role": "assistant", "content": "hello"})

        loaded = store_mod.load_session(sess.id)
        assert len(loaded.messages) == 2
        assert loaded.messages[0]["content"] == "hi"

    def test_toolcall_pydantic_serializable(self, store_mod):
        """Regression: ollama ToolCall pydantic objects must not crash append."""
        from ollama._types import Message as M
        tc = M.ToolCall(
            function=M.ToolCall.Function(name="read_file",
                                         arguments={"path": "x.py"})
        )
        sess = store_mod.new_session("m")
        s = store_mod.SessionStore(sess)
        s.append({"role": "assistant", "content": "",
                  "tool_calls": [tc]})
        loaded = store_mod.load_session(sess.id)
        assert loaded.messages[0]["tool_calls"][0]["function"]["name"] == "read_file"


class TestReplaceAll:
    def test_rewrites_file(self, store_mod):
        sess = store_mod.new_session("m")
        s = store_mod.SessionStore(sess)
        for i in range(5):
            s.append({"role": "user", "content": f"m{i}"})

        s.replace_all([{"role": "user", "content": "only"}])
        loaded = store_mod.load_session(sess.id)
        assert len(loaded.messages) == 1
        assert loaded.messages[0]["content"] == "only"

    def test_atomic_via_tmp(self, store_mod):
        sess = store_mod.new_session("m")
        s = store_mod.SessionStore(sess)
        s.replace_all([{"role": "user", "content": "x"}])
        # No stray .tmp after completion
        assert not sess.path.with_suffix(".jsonl.tmp").exists()


class TestListSessions:
    def test_newest_first(self, store_mod):
        import time
        s1 = store_mod.new_session("a")
        time.sleep(0.01)
        s2 = store_mod.new_session("b")
        rows = store_mod.list_sessions()
        ids = [r["id"] for r in rows]
        assert ids.index(s2.id) < ids.index(s1.id)

    def test_empty_when_no_sessions(self, store_mod):
        assert store_mod.list_sessions() == []


class TestLoadErrors:
    def test_missing_session(self, store_mod):
        with pytest.raises(FileNotFoundError):
            store_mod.load_session("does-not-exist")

    def test_skips_malformed_lines(self, store_mod):
        sess = store_mod.new_session("m")
        with sess.path.open("a") as f:
            f.write('{"role":"user","content":"ok"}\n')
            f.write("this is not json\n")
            f.write('{"role":"assistant","content":"ok2"}\n')
        loaded = store_mod.load_session(sess.id)
        assert len(loaded.messages) == 2
