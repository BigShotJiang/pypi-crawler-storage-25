"""read_file / write_file / edit_file — including the bugs we fixed."""
from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from tinillm.agent.tools.file_ops import (
    FileOpError,
    edit_file,
    read_file,
    write_file,
)


class TestReadFile:
    def test_happy_path(self, workspace, write_file_in_ws):
        write_file_in_ws("a.txt", "one\ntwo\nthree")
        r = read_file(workspace, "a.txt")
        assert r.total_lines == 3
        assert "1\tone" in r.content
        assert "3\tthree" in r.content
        assert r.truncated is False

    def test_line_numbering_right_aligned(self, workspace, write_file_in_ws):
        write_file_in_ws("a.txt", "\n".join(f"l{i}" for i in range(15)))
        r = read_file(workspace, "a.txt")
        # 15 lines → width 2
        assert " 1\tl0" in r.content
        assert "10\tl9" in r.content

    def test_offset_and_limit(self, workspace, write_file_in_ws):
        write_file_in_ws("a.txt", "\n".join(f"l{i}" for i in range(10)))
        r = read_file(workspace, "a.txt", offset=5, limit=3)
        assert r.offset == 5
        assert r.limit == 3
        assert r.truncated is True
        assert "6\tl5" in r.content
        assert "8\tl7" in r.content
        assert "9\tl8" not in r.content

    def test_negative_offset_clamped(self, workspace, write_file_in_ws):
        write_file_in_ws("a.txt", "x\ny")
        r = read_file(workspace, "a.txt", offset=-50)
        assert r.offset == 0

    def test_missing_file(self, workspace):
        with pytest.raises(FileOpError, match="not found"):
            read_file(workspace, "nope.txt")

    def test_dir_rejected(self, workspace):
        (workspace.root / "sub").mkdir()
        with pytest.raises(FileOpError, match="directory"):
            read_file(workspace, "sub")

    def test_binary_rejected(self, workspace):
        (workspace.root / "bin").write_bytes(b"\x00\x01\x02text")
        with pytest.raises(FileOpError, match="binary"):
            read_file(workspace, "bin")

    def test_boundary_escape(self, workspace, tmp_path):
        outside = tmp_path / "out.txt"
        outside.write_text("x")
        from tinillm.agent.workspace import WorkspaceError
        with pytest.raises(WorkspaceError):
            read_file(workspace, str(outside))


class TestWriteFile:
    def test_create(self, workspace):
        r = write_file(workspace, "new.txt", "hello")
        assert r.created is True
        assert r.bytes_written == 5
        assert (workspace.root / "new.txt").read_text() == "hello"

    def test_overwrite(self, workspace, write_file_in_ws):
        write_file_in_ws("a.txt", "old")
        r = write_file(workspace, "a.txt", "new")
        assert r.created is False
        assert (workspace.root / "a.txt").read_text() == "new"

    def test_nested_parents_created(self, workspace):
        r = write_file(workspace, "deep/deeper/file.txt", "hi")
        assert r.created is True
        assert (workspace.root / "deep/deeper/file.txt").read_text() == "hi"

    def test_reject_directory(self, workspace):
        (workspace.root / "sub").mkdir()
        with pytest.raises(FileOpError, match="directory"):
            write_file(workspace, "sub", "x")

    def test_atomic_temp_cleanup_on_failure(self, workspace):
        """If os.replace fails, the hidden .tmp file must not leak."""
        with patch("tinillm.agent.tools.file_ops.os.replace",
                   side_effect=OSError("simulated disk error")):
            with pytest.raises(OSError):
                write_file(workspace, "x.txt", "data")
        # No stray .tmp files left behind
        leftovers = [p.name for p in workspace.root.iterdir()]
        assert leftovers == [], f"temp leak: {leftovers}"

    def test_utf8_bytes_accurate(self, workspace):
        r = write_file(workspace, "u.txt", "héllo 🌍")
        assert r.bytes_written == len("héllo 🌍".encode("utf-8"))


class TestEditFile:
    def test_single_replacement(self, workspace, write_file_in_ws):
        write_file_in_ws("a.txt", "foo bar baz")
        r = edit_file(workspace, "a.txt", "bar", "QUX")
        assert r.replacements == 1
        assert (workspace.root / "a.txt").read_text() == "foo QUX baz"
        assert len(r.hunks) >= 1

    def test_snippet_not_found(self, workspace, write_file_in_ws):
        write_file_in_ws("a.txt", "foo")
        with pytest.raises(FileOpError, match="not found"):
            edit_file(workspace, "a.txt", "nonexistent", "x")

    def test_non_unique_without_replace_all(self, workspace, write_file_in_ws):
        write_file_in_ws("a.txt", "x\nx\nx")
        with pytest.raises(FileOpError, match="matches 3 times"):
            edit_file(workspace, "a.txt", "x", "y")

    def test_replace_all(self, workspace, write_file_in_ws):
        write_file_in_ws("a.txt", "x\nx\nx")
        r = edit_file(workspace, "a.txt", "x", "y", replace_all=True)
        assert r.replacements == 3
        assert (workspace.root / "a.txt").read_text() == "y\ny\ny"

    def test_identical_strings_rejected(self, workspace, write_file_in_ws):
        write_file_in_ws("a.txt", "x")
        with pytest.raises(FileOpError, match="identical"):
            edit_file(workspace, "a.txt", "x", "x")

    def test_binary_file_rejected(self, workspace):
        (workspace.root / "b").write_bytes(b"\x00abc")
        with pytest.raises(FileOpError, match="binary"):
            edit_file(workspace, "b", "abc", "xyz")

    def test_hunks_report_changed_lines(self, workspace, write_file_in_ws):
        write_file_in_ws("a.txt", "line1\nline2\nline3\n")
        r = edit_file(workspace, "a.txt", "line2", "LINE2")
        assert any(h.before == "line2" and h.after == "LINE2" for h in r.hunks)
