"""Unified dispatcher — permissions, user confirms, snapshots, unknown tools."""
from __future__ import annotations

from unittest.mock import patch

import pytest

from tinillm.agent.permissions import PermissionDenied, PermissionMode
from tinillm.agent.tools.registry import dispatch


class TestDispatchGating:
    def test_read_tool_in_read_only(self, ctx, write_file_in_ws):
        write_file_in_ws("a.txt", "hi")
        ctx.enforcer.set_mode(PermissionMode.READ_ONLY)
        out = dispatch(ctx, "read_file", {"path": "a.txt"})
        assert "hi" in out

    def test_write_denied_in_read_only(self, ctx):
        ctx.enforcer.set_mode(PermissionMode.READ_ONLY)
        with pytest.raises(PermissionDenied):
            dispatch(ctx, "write_file", {"path": "x.txt", "content": "x"})

    def test_unknown_tool(self, ctx):
        out = dispatch(ctx, "frobnicate", {})
        assert "Unknown tool" in out

    def test_destructive_bash_without_auto_confirm_asks(self, ctx):
        ctx.auto_confirm = False
        with patch("tinillm.agent.tools.registry.click.confirm",
                   return_value=False) as m:
            out = dispatch(ctx, "bash", {"command": "rm -rf /tmp/never"})
        m.assert_called_once()
        assert "declined" in out

    def test_destructive_bash_with_auto_confirm_runs(self, ctx, tmp_path):
        """auto_confirm=True should bypass the Proceed? prompt."""
        with patch("tinillm.agent.tools.registry.click.confirm") as m:
            # Use a benign bash that *looks* destructive per regex but isn't.
            dispatch(ctx, "bash", {"command": "echo 'rm -rf x'"})
        # Confirm should NOT be called because ctx.auto_confirm=True
        # (even though the pattern matches, it runs straight through).
        m.assert_not_called()


class TestSnapshots:
    def test_write_captures_snapshot(self, ctx, write_file_in_ws):
        write_file_in_ws("a.txt", "original")
        dispatch(ctx, "write_file", {"path": "a.txt", "content": "modified"})
        diff = ctx.snapshots.diff()
        assert "-original" in diff
        assert "+modified" in diff

    def test_edit_captures_snapshot(self, ctx, write_file_in_ws):
        write_file_in_ws("a.txt", "foo bar")
        dispatch(ctx, "edit_file",
                 {"path": "a.txt", "old_string": "bar", "new_string": "BAZ"})
        diff = ctx.snapshots.diff()
        assert "+foo BAZ" in diff

    def test_created_file_shown_in_diff(self, ctx):
        dispatch(ctx, "write_file", {"path": "new.txt", "content": "hi"})
        diff = ctx.snapshots.diff()
        assert "/dev/null" in diff
        assert "+hi" in diff

    def test_no_changes_diff(self, ctx, write_file_in_ws):
        write_file_in_ws("a.txt", "x")
        # Read only — no snapshot captured
        dispatch(ctx, "read_file", {"path": "a.txt"})
        assert "no file changes" in ctx.snapshots.diff()


class TestToolErrorHandling:
    def test_tool_exception_becomes_string(self, ctx):
        out = dispatch(ctx, "read_file", {"path": "nonexistent.txt"})
        assert "read_file error" in out
        assert "not found" in out

    def test_permission_denied_propagates(self, ctx):
        ctx.enforcer.set_mode(PermissionMode.READ_ONLY)
        with pytest.raises(PermissionDenied):
            dispatch(ctx, "bash", {"command": "ls"})
