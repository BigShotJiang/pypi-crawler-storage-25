"""bash tool — timeout, truncation, exit codes."""
from __future__ import annotations

import pytest

from tinillm.agent.tools.bash import run_bash, _MAX_OUTPUT_BYTES


class TestRunBash:
    def test_happy_path(self):
        r = run_bash("echo hello")
        assert r.exit_code == 0
        assert "hello" in r.stdout
        assert r.timed_out is False
        assert r.truncated is False

    def test_nonzero_exit(self):
        r = run_bash("exit 7")
        assert r.exit_code == 7

    def test_stderr_captured(self):
        r = run_bash("echo err 1>&2")
        assert "err" in r.stderr

    def test_timeout(self):
        r = run_bash("sleep 5", timeout=1)
        assert r.timed_out is True
        assert r.exit_code == 124
        assert "timed out" in r.stderr.lower()

    def test_output_truncation(self):
        # Emit more than _MAX_OUTPUT_BYTES bytes.
        r = run_bash(f"yes x | head -c {_MAX_OUTPUT_BYTES + 1000}")
        assert r.truncated is True
        assert "truncated" in r.stdout

    def test_cwd_honoured(self, tmp_path):
        r = run_bash("pwd", cwd=tmp_path)
        assert str(tmp_path) in r.stdout

    def test_env_override(self):
        r = run_bash("echo $FOO", env={"FOO": "bar", "PATH": "/usr/bin:/bin"})
        assert "bar" in r.stdout
