"""Boundary guard + symlink escape detection."""
from __future__ import annotations

import os
from pathlib import Path

import pytest

from tinillm.agent.workspace import Workspace, WorkspaceError


class TestResolve:
    def test_relative_path_inside_ws(self, workspace, write_file_in_ws):
        write_file_in_ws("a.txt", "hi")
        resolved = workspace.resolve("a.txt")
        assert resolved == workspace.root / "a.txt"

    def test_absolute_path_inside_ws(self, workspace, write_file_in_ws):
        p = write_file_in_ws("b.txt", "hi")
        assert workspace.resolve(str(p)) == p

    def test_absolute_path_outside_ws_rejected(self, workspace, tmp_path):
        outside = tmp_path / "outside.txt"
        outside.write_text("x")
        with pytest.raises(WorkspaceError):
            workspace.resolve(str(outside))

    def test_parent_traversal_outside_rejected(self, workspace):
        with pytest.raises(WorkspaceError):
            workspace.resolve("../escape.txt")

    def test_allow_missing_for_new_file(self, workspace):
        p = workspace.resolve("new.txt", allow_missing=True)
        assert p == workspace.root / "new.txt"

    def test_allow_missing_nested_parent(self, workspace):
        # Resolve succeeds even through non-existent intermediate dirs on Linux.
        p = workspace.resolve("a/b/c/new.txt", allow_missing=True)
        assert p == workspace.root / "a" / "b" / "c" / "new.txt"

    def test_missing_without_allow_raises(self, workspace):
        with pytest.raises(WorkspaceError):
            workspace.resolve("nope.txt")

    def test_expanduser(self, workspace, monkeypatch):
        # Users pass ``~/foo`` — must be expanded to HOME and then boundary-checked.
        monkeypatch.setenv("HOME", str(workspace.root))
        p = workspace.resolve("~/x.txt", allow_missing=True)
        assert str(p).startswith(str(workspace.root))


class TestIsInside:
    def test_file_inside(self, workspace, write_file_in_ws):
        p = write_file_in_ws("x.txt", "")
        assert workspace.is_inside(p) is True

    def test_file_outside(self, workspace, tmp_path):
        assert workspace.is_inside(tmp_path / "elsewhere") is False


class TestSymlinkEscape:
    def test_symlink_inside_workspace(self, workspace, write_file_in_ws):
        target = write_file_in_ws("target.txt", "hi")
        link = workspace.root / "link"
        link.symlink_to(target)
        assert workspace.is_symlink_escape(link) is False

    def test_symlink_escaping_workspace(self, workspace, tmp_path):
        outside = tmp_path / "outside.txt"
        outside.write_text("x")
        link = workspace.root / "evil"
        link.symlink_to(outside)
        assert workspace.is_symlink_escape(link) is True

    def test_non_symlink(self, workspace, write_file_in_ws):
        p = write_file_in_ws("plain.txt", "hi")
        assert workspace.is_symlink_escape(p) is False
