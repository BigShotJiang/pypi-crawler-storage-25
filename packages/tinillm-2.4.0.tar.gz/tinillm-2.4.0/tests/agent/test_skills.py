"""Skill loader — global + project discovery, de-duplication."""
from __future__ import annotations

import pytest


@pytest.fixture
def skills_mod(isolated_home):
    import tinillm.agent.skills as s
    return s


class TestSkills:
    def test_empty(self, skills_mod, tmp_path):
        assert skills_mod.discover(tmp_path) == []

    def test_global_skill(self, skills_mod, tmp_path):
        skills_mod.GLOBAL_SKILLS_DIR.mkdir(parents=True, exist_ok=True)
        (skills_mod.GLOBAL_SKILLS_DIR / "refactor.md").write_text(
            "# Refactor skill\nUse small steps.\n"
        )
        found = skills_mod.discover(tmp_path)
        assert len(found) == 1
        assert found[0].name == "refactor"
        assert "Refactor skill" in found[0].description

    def test_project_overrides_global(self, skills_mod, tmp_path):
        skills_mod.GLOBAL_SKILLS_DIR.mkdir(parents=True, exist_ok=True)
        (skills_mod.GLOBAL_SKILLS_DIR / "review.md").write_text("# Global review\n")

        proj_dir = tmp_path / ".tinillm" / "skills"
        proj_dir.mkdir(parents=True)
        (proj_dir / "review.md").write_text("# Project review\n")

        found = skills_mod.discover(tmp_path)
        assert len(found) == 1
        assert "Project review" in found[0].description

    def test_load_specific(self, skills_mod, tmp_path):
        skills_mod.GLOBAL_SKILLS_DIR.mkdir(parents=True, exist_ok=True)
        (skills_mod.GLOBAL_SKILLS_DIR / "foo.md").write_text("# foo\nbody\n")
        s = skills_mod.load("foo", tmp_path)
        assert s is not None
        assert s.name == "foo"

    def test_load_missing(self, skills_mod, tmp_path):
        assert skills_mod.load("nonexistent", tmp_path) is None
