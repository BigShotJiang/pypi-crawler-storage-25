"""Shared fixtures for agent tests.

Every fixture isolates filesystem effects: HOME is redirected to a tmp dir so
sessions, hooks, skills, and config can't pollute the developer's real
``~/.tinillm``; the Workspace is rooted in another tmp dir so file-op tests
can't escape into the real tree.
"""
from __future__ import annotations

import importlib
from pathlib import Path

import pytest
from rich.console import Console

from tinillm.agent.permissions import PermissionEnforcer
from tinillm.agent.tools.registry import ToolContext
from tinillm.agent.workspace import Workspace


@pytest.fixture
def isolated_home(tmp_path, monkeypatch):
    """Redirect HOME so session/hooks/skills live in a throwaway dir."""
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: home))
    # Modules cache path constants at import time. Reload the ones we touch so
    # their module-level paths pick up the new HOME.
    for modname in (
        "tinillm.agent.session.store",
        "tinillm.agent.hooks",
        "tinillm.agent.skills",
        "tinillm.agent.mcp",
    ):
        importlib.reload(importlib.import_module(modname))
    yield home


@pytest.fixture
def workspace(tmp_path) -> Workspace:
    root = tmp_path / "ws"
    root.mkdir()
    return Workspace(root)


@pytest.fixture
def enforcer() -> PermissionEnforcer:
    return PermissionEnforcer()


@pytest.fixture
def ctx(workspace, enforcer) -> ToolContext:
    """Tool context with auto_confirm on (no interactive prompts in tests)."""
    return ToolContext(
        workspace=workspace,
        enforcer=enforcer,
        console=Console(quiet=True, file=open("/dev/null", "w")),
        auto_confirm=True,
    )


@pytest.fixture
def write_file_in_ws(workspace):
    """Factory: drop a real file in the workspace at a relative path."""
    def _write(rel: str, body: str) -> Path:
        p = workspace.root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(body, encoding="utf-8")
        return p
    return _write
