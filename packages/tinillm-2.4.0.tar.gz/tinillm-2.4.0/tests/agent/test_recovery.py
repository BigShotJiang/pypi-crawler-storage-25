"""Recovery recipe matcher."""
from __future__ import annotations

import pytest

from tinillm.agent.recovery import match


@pytest.mark.parametrize("error,label", [
    ("this model does not support tools", "model-no-tools"),
    ("Connection refused when calling Ollama", "ollama-not-running"),
    ("model not found: llama3:8b", "model-missing"),
    ("Path escapes workspace root: /etc/passwd", "escape-workspace"),
    ("old_string not found in file.", "edit-not-found"),
])
def test_known_recipes(error, label):
    recipe = match(error)
    assert recipe is not None
    assert recipe.label == label


def test_unknown_returns_none():
    assert match("something totally unrelated") is None


def test_case_insensitive():
    assert match("MODEL NOT FOUND: x").label == "model-missing"
