"""Plan mode — toggles enforcer between read-only and prior mode."""
from __future__ import annotations

from tinillm.agent.permissions import PermissionEnforcer, PermissionMode
from tinillm.agent.plan_mode import PlanState, enter, exit_, system_addendum


class TestPlanMode:
    def test_enter_switches_to_read_only(self):
        e = PermissionEnforcer(mode=PermissionMode.WORKSPACE_WRITE)
        st = PlanState()
        enter(e, st)
        assert e.mode == PermissionMode.READ_ONLY
        assert st.active is True
        assert st.previous_mode == PermissionMode.WORKSPACE_WRITE

    def test_exit_restores(self):
        e = PermissionEnforcer(mode=PermissionMode.WORKSPACE_WRITE)
        st = PlanState()
        enter(e, st)
        exit_(e, st)
        assert e.mode == PermissionMode.WORKSPACE_WRITE
        assert st.active is False

    def test_double_enter_is_noop(self):
        e = PermissionEnforcer(mode=PermissionMode.DANGER_FULL_ACCESS)
        st = PlanState()
        enter(e, st)
        # Save original previous mode
        prev = st.previous_mode
        enter(e, st)  # should not overwrite previous
        assert st.previous_mode == prev

    def test_exit_when_inactive_is_noop(self):
        e = PermissionEnforcer(mode=PermissionMode.WORKSPACE_WRITE)
        st = PlanState()
        exit_(e, st)  # not active — must not crash
        assert e.mode == PermissionMode.WORKSPACE_WRITE

    def test_system_addendum_mentions_plan(self):
        assert "PLAN MODE" in system_addendum()
