"""Auto-accept plan flow.

When ``/plan`` is active and ``auto_accept_plan`` is on (the v2.3 default),
a model message shaped like a numbered plan should:

1. Exit plan mode (restore the prior permission mode)
2. Strip the PLAN-MODE system addendum from the message list
3. Append a synthetic "plan approved" user message
4. Re-invoke the model to actually execute the plan

These tests pin down ``looks_like_final_plan`` and drive the full chat loop
with a fake Ollama to verify the wire-up in ``agent_chat._run_model_loop``.
"""
from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import patch

import pytest

from tinillm.agent.plan_mode import looks_like_final_plan, system_addendum


# ── Pure function ───────────────────────────────────────────────────────────

class TestLooksLikeFinalPlan:
    def test_three_numbered_lines_matches(self):
        text = "Here is the plan:\n1. Read config\n2. Edit file\n3. Run tests"
        assert looks_like_final_plan(text) is True

    def test_two_numbered_lines_does_not_match(self):
        # Keep false positives down — bare "1. try this, 2. try that" shouldn't fire.
        text = "Maybe try 1. this and 2. that"
        assert looks_like_final_plan(text) is False

    def test_empty_string_does_not_match(self):
        assert looks_like_final_plan("") is False

    def test_indented_numbered_lines_count(self):
        text = "   1. a\n   2. b\n   3. c"
        assert looks_like_final_plan(text) is True

    def test_prose_without_numbered_list_does_not_match(self):
        text = "I think we should read the code, edit it, then test it."
        assert looks_like_final_plan(text) is False


# ── Integration with the chat loop ──────────────────────────────────────────

class _FakeMessage:
    def __init__(self, content="", tool_calls=None, role="assistant"):
        self.role = role
        self.content = content
        self.tool_calls = tool_calls


class _FakeResponse:
    def __init__(self, message, prompt_tokens=10, eval_tokens=20):
        self.message = message
        self.prompt_eval_count = prompt_tokens
        self.eval_count = eval_tokens


class _FakeOllama:
    def __init__(self, scripted):
        self._responses = list(scripted)
        self.calls = []
        self.ResponseError = Exception

    def chat(self, **kwargs):
        self.calls.append(kwargs)
        if not self._responses:
            raise AssertionError("no scripted response left")
        return self._responses.pop(0)


@pytest.fixture
def in_workspace(tmp_path, monkeypatch, isolated_home):
    ws = tmp_path / "work"
    ws.mkdir()
    monkeypatch.chdir(ws)
    return ws


def _run_chat(fake_ollama, inputs, **kwargs):
    with patch.dict("sys.modules", {"ollama": fake_ollama}):
        with patch(
            "tinillm.run.agent_chat.click.prompt",
            side_effect=list(inputs) + ["/exit"],
        ):
            with patch("tinillm.run.chat_session._mem_writer_ingest"):
                from tinillm.run.agent_chat import run_agent_chat
                run_agent_chat(model_tag="fake-model", **kwargs)


class TestAutoAcceptIntegration:
    def test_plan_then_auto_execute(self, in_workspace):
        """After /plan + user goal, the plan turn should auto-approve and re-call
        the model with a synthetic approval user message appended."""
        plan_turn = _FakeResponse(_FakeMessage(
            content="Here's what I'll do:\n1. Read the file\n"
                    "2. Make the edit\n3. Save it\n"
        ))
        post_approval = _FakeResponse(_FakeMessage(content="done."))
        ollama = _FakeOllama([plan_turn, post_approval])

        _run_chat(ollama, ["/plan", "refactor the thing"])

        # Two chat calls: the plan turn, then the approval-execute turn.
        assert len(ollama.calls) == 2

        # Second call must include the synthetic "approved" user message.
        second_msgs = ollama.calls[1]["messages"]
        approvals = [
            m for m in second_msgs
            if m.get("role") == "user"
            and "approved" in (m.get("content") or "").lower()
        ]
        assert len(approvals) == 1

        # Second call must NOT still carry the PLAN MODE addendum system msg.
        addendum = system_addendum()
        addendum_msgs = [
            m for m in second_msgs
            if m.get("role") == "system" and m.get("content") == addendum
        ]
        assert addendum_msgs == []

    def test_auto_accept_disabled_keeps_plan_mode(self, in_workspace, monkeypatch):
        """With auto_accept_plan=false, plan turn must not auto-execute."""
        # Force config to return auto_accept_plan=False.
        from tinillm.agent import config as _cfg
        real_load = _cfg.load

        def fake_load(*a, **kw):
            c = real_load(*a, **kw)
            c.auto_accept_plan = False
            return c

        monkeypatch.setattr(_cfg, "load", fake_load)
        monkeypatch.setattr("tinillm.run.chat_session._load_config", fake_load)

        plan_turn = _FakeResponse(_FakeMessage(
            content="Plan:\n1. one\n2. two\n3. three\n"
        ))
        ollama = _FakeOllama([plan_turn])
        _run_chat(ollama, ["/plan", "do the thing"])

        # Only one call — no auto re-prompt.
        assert len(ollama.calls) == 1
