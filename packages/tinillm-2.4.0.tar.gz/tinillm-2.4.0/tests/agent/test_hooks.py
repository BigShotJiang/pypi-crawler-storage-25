"""User shell hooks — pre_tool / post_tool / pre_prompt."""
from __future__ import annotations

import os
import stat

import pytest


@pytest.fixture
def hooks_mod(isolated_home):
    import tinillm.agent.hooks as h
    return h


def _write_hook(hooks_root, trigger, body):
    hooks_root.mkdir(parents=True, exist_ok=True)
    path = hooks_root / trigger
    path.write_text(f"#!/bin/sh\n{body}\n")
    path.chmod(path.stat().st_mode | stat.S_IXUSR)
    return path


class TestHookRunner:
    def test_no_hooks_returns_ok(self, hooks_mod):
        r = hooks_mod.run_hook("pre_tool", {"name": "x"})
        assert r.ok is True
        assert r.payload == {"name": "x"}

    def test_hook_modifies_payload(self, hooks_mod):
        _write_hook(
            hooks_mod.HOOKS_ROOT,
            "pre_prompt",
            'cat - | sed s/hello/world/',
        )
        r = hooks_mod.run_hook("pre_prompt", {"prompt": "hello"})
        assert r.ok is True
        assert r.payload["prompt"] == "world"

    def test_nonzero_exit_cancels(self, hooks_mod):
        _write_hook(
            hooks_mod.HOOKS_ROOT,
            "pre_tool",
            "echo 'nope' 1>&2\nexit 1",
        )
        r = hooks_mod.run_hook("pre_tool", {"name": "bash"})
        assert r.ok is False
        assert "nope" in r.reason

    def test_d_subdir_runs_multiple(self, hooks_mod):
        d = hooks_mod.HOOKS_ROOT / "pre_tool.d"
        d.mkdir(parents=True, exist_ok=True)
        h1 = d / "01-first.sh"
        h1.write_text('#!/bin/sh\ncat - | sed s/x/y/\n')
        h1.chmod(h1.stat().st_mode | stat.S_IXUSR)
        h2 = d / "02-second.sh"
        h2.write_text('#!/bin/sh\ncat - | sed s/y/Z/\n')
        h2.chmod(h2.stat().st_mode | stat.S_IXUSR)

        r = hooks_mod.run_hook("pre_tool", {"val": "x"})
        assert r.payload["val"] == "Z"

    def test_non_executable_skipped(self, hooks_mod):
        hooks_mod.HOOKS_ROOT.mkdir(parents=True, exist_ok=True)
        p = hooks_mod.HOOKS_ROOT / "pre_prompt"
        p.write_text("#!/bin/sh\nexit 1")
        # no chmod +x
        r = hooks_mod.run_hook("pre_prompt", {"prompt": "hi"})
        assert r.ok is True  # not run → not blocked
