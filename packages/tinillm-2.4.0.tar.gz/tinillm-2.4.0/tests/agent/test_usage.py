"""UsageTracker — accumulates prompt/completion tokens over a session."""
from __future__ import annotations

from types import SimpleNamespace

from tinillm.agent.usage import UsageTracker


def _resp(prompt, eval_):
    return SimpleNamespace(prompt_eval_count=prompt, eval_count=eval_)


class TestUsageTracker:
    def test_starts_zero(self):
        u = UsageTracker()
        assert u.total_tokens == 0
        assert u.turns == 0

    def test_accumulates(self):
        u = UsageTracker()
        u.record(_resp(100, 50))
        u.record(_resp(200, 75))
        assert u.prompt_tokens == 300
        assert u.completion_tokens == 125
        assert u.total_tokens == 425
        assert u.turns == 2

    def test_none_counts_treated_as_zero(self):
        u = UsageTracker()
        u.record(SimpleNamespace())  # no attributes at all
        assert u.total_tokens == 0
        assert u.turns == 1

    def test_render_has_all_fields(self):
        u = UsageTracker()
        u.record(_resp(10, 20))
        out = u.render()
        assert "turns:" in out
        assert "prompt:" in out
        assert "$0.00" in out  # local model → free
