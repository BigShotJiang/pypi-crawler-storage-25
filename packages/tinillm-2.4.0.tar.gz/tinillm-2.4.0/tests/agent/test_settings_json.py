"""JSON settings at ``~/.tinillm/settings.json``.

Covers:
- Missing file → defaults
- Malformed JSON → defaults (no crash)
- Round-trip ``save()`` / ``load()`` for every field
- Merge semantics: ``save(**)`` only touches the passed keys
- Unknown keys preserved via ``extras``
- Dual-read compat: legacy ``.tinillmrc`` still works until v2.4
"""
from __future__ import annotations

import json

import pytest

from tinillm.agent import config as _config
from tinillm.agent import settings as _settings


@pytest.fixture
def isolated_home(tmp_path, monkeypatch):
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setattr("pathlib.Path.home", classmethod(lambda cls: home))
    # Reset the one-time deprecation flag so each test starts clean.
    monkeypatch.setattr(_config, "_DEPRECATION_PRINTED", False)
    return home


def test_missing_file_returns_defaults(isolated_home):
    s = _settings.load()
    assert s.model is None
    assert s.permission_mode == "workspace-write"
    assert s.auto_accept_plan is True
    assert s.permissions.allow == []
    assert s.permissions.deny == []
    assert s.sandbox.enabled is True
    assert s.sandbox.allow_network is False


def test_malformed_json_falls_back_to_defaults(isolated_home):
    p = _settings.path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("{ this is : not json", encoding="utf-8")
    s = _settings.load()
    assert s.model is None
    assert s.auto_accept_plan is True


def test_non_object_json_falls_back_to_defaults(isolated_home):
    p = _settings.path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text('["a", "b"]', encoding="utf-8")
    s = _settings.load()
    assert s.model is None


def test_save_writes_atomic_file(isolated_home):
    _settings.save(model="qwen2.5-coder:14b")
    p = _settings.path()
    assert p.exists()
    data = json.loads(p.read_text(encoding="utf-8"))
    assert data["model"] == "qwen2.5-coder:14b"


def test_roundtrip_all_fields(isolated_home):
    _settings.save(
        model="llama3.1:8b",
        permission_mode="read-only",
        auto_accept_plan=False,
        permissions={"allow": ["bash(*)"], "deny": ["bash(rm -rf *)"]},
        sandbox={"enabled": True, "backend": "bwrap", "allow_network": True},
        system_prompt_path="/tmp/prompt.md",
    )
    s = _settings.load()
    assert s.model == "llama3.1:8b"
    assert s.permission_mode == "read-only"
    assert s.auto_accept_plan is False
    assert s.permissions.allow == ["bash(*)"]
    assert s.permissions.deny == ["bash(rm -rf *)"]
    assert s.sandbox.enabled is True
    assert s.sandbox.backend == "bwrap"
    assert s.sandbox.allow_network is True
    assert s.system_prompt_path == "/tmp/prompt.md"


def test_save_merges_fields_instead_of_replacing(isolated_home):
    _settings.save(model="m1", auto_accept_plan=False)
    _settings.save(model="m2")  # should keep auto_accept_plan=False
    s = _settings.load()
    assert s.model == "m2"
    assert s.auto_accept_plan is False


def test_unknown_keys_stored_in_extras(isolated_home):
    _settings.save(**{"some_future_key": {"nested": 1}})
    s = _settings.load()
    assert s.extras.get("some_future_key") == {"nested": 1}


def test_extras_round_trip_through_file(isolated_home):
    p = _settings.path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({"model": "m", "mystery": 42}), encoding="utf-8")
    s = _settings.load()
    assert s.extras.get("mystery") == 42
    # Now save something else — mystery should survive.
    _settings.save(model="n")
    s2 = _settings.load()
    assert s2.extras.get("mystery") == 42
    assert s2.model == "n"


def test_config_prefers_settings_json_over_legacy_toml(isolated_home):
    # Write both. settings.json wins.
    _settings.save(model="from-json", auto_accept_plan=False)
    (isolated_home / ".tinillmrc").write_text('model = "from-toml"\n')
    cfg = _config.load(isolated_home)
    assert cfg.model == "from-json"
    assert cfg.auto_accept_plan is False


def test_config_falls_back_to_legacy_toml(isolated_home, monkeypatch):
    (isolated_home / ".tinillmrc").write_text(
        'model = "toml-model"\npermission_mode = "read-only"\n'
    )
    monkeypatch.setenv("TINILLM_NO_DEPRECATION", "1")
    cfg = _config.load(isolated_home)
    assert cfg.model == "toml-model"
    assert cfg.permission_mode == "read-only"


def test_json_allow_deny_mapped_to_pattern_fields(isolated_home):
    _settings.save(
        permissions={"allow": ["bash(*)", "read_file(*)"], "deny": ["bash(sudo *)"]},
    )
    cfg = _config.load(isolated_home)
    assert cfg.allow_patterns == ["bash(*)", "read_file(*)"]
    assert cfg.deny_patterns == ["bash(sudo *)"]
