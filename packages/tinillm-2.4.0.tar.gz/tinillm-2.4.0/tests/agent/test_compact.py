"""/compact + /summary — conversation compression semantics."""
from __future__ import annotations

from tinillm.agent.session.compact import apply_summary, build_compact_request


class TestBuildRequest:
    def test_has_system_and_user(self):
        msgs = [{"role": "user", "content": "hi"},
                {"role": "assistant", "content": "there"}]
        req = build_compact_request(msgs)
        assert req[0]["role"] == "system"
        assert "Summarize" in req[0]["content"]
        assert req[1]["role"] == "user"

    def test_empty_history(self):
        req = build_compact_request([])
        assert req[1]["content"] == "(empty)"


class TestApplySummary:
    def test_short_history_unchanged(self):
        msgs = [{"role": "user", "content": "hi"}]
        new, result = apply_summary(msgs, "SUMMARY")
        assert new == msgs
        assert result.dropped == 0

    def test_long_history_compacted(self):
        msgs = [{"role": "user", "content": f"m{i}"} for i in range(10)]
        new, result = apply_summary(msgs, "SUMMARY")
        assert new[0]["role"] == "system"
        assert "SUMMARY" in new[0]["content"]
        # Last 4 tail messages kept verbatim
        assert result.kept == 4
        assert result.dropped == 6
        # Tail preserved in order
        assert new[-1]["content"] == "m9"
        assert new[-4]["content"] == "m6"
