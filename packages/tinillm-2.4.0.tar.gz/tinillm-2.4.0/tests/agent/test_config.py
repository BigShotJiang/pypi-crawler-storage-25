"""TOML config loader — ~/.tinillmrc + project-local .tinillmrc."""
from __future__ import annotations


from tinillm.agent.config import load


def test_returns_defaults_when_no_files(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    (tmp_path / "home").mkdir()
    cfg = load(tmp_path)
    assert cfg.permission_mode == "workspace-write"
    assert cfg.model is None
    assert cfg.allowed_tools is None


def test_project_overrides_global(tmp_path, monkeypatch):
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setattr("pathlib.Path.home", classmethod(lambda cls: home))

    (home / ".tinillmrc").write_text('model = "llama3:8b"\npermission_mode = "read-only"\n')

    proj = tmp_path / "proj"
    proj.mkdir()
    (proj / ".tinillmrc").write_text('permission_mode = "workspace-write"\n')

    cfg = load(proj)
    assert cfg.model == "llama3:8b"           # inherited from global
    assert cfg.permission_mode == "workspace-write"  # project wins


def test_allowed_denied_tools(tmp_path, monkeypatch):
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setattr("pathlib.Path.home", classmethod(lambda cls: home))

    (tmp_path / ".tinillmrc").write_text(
        'allowed_tools = ["read_file", "grep_search"]\n'
        'denied_tools = ["bash"]\n'
    )
    cfg = load(tmp_path)
    assert cfg.allowed_tools == ["read_file", "grep_search"]
    assert cfg.denied_tools == ["bash"]


def test_malformed_toml_ignored(tmp_path, monkeypatch):
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setattr("pathlib.Path.home", classmethod(lambda cls: home))
    (tmp_path / ".tinillmrc").write_text("this = is [[[ not toml")
    cfg = load(tmp_path)
    assert cfg.permission_mode == "workspace-write"


def test_unknown_keys_preserved_as_extras(tmp_path, monkeypatch):
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setattr("pathlib.Path.home", classmethod(lambda cls: home))
    (tmp_path / ".tinillmrc").write_text('custom_key = "x"\n')
    cfg = load(tmp_path)
    assert cfg.extras.get("custom_key") == "x"
