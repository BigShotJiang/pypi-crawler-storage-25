"""Pattern-based permission rules: ``tool(arg-glob)``.

Covers:
- Positive + negative matches for bash/read/write/glob/grep
- Deny beats allow (deny is evaluated first)
- Allow patterns short-circuit the mode check (e.g. bash allowed in read-only)
- Empty allow/deny lists fall through to the legacy mode behavior
- Bare tool name (no parens) matches any args for that tool
"""
from __future__ import annotations

from tinillm.agent.permissions import (
    PermissionEnforcer,
    PermissionMode,
    _any_match,
    _parse_pattern,
)


# ── Parse ───────────────────────────────────────────────────────────────────

def test_parse_bare_tool():
    p = _parse_pattern("bash")
    assert p.tool == "bash"
    assert p.arg_glob is None


def test_parse_tool_with_star_glob():
    p = _parse_pattern("bash(*)")
    assert p.tool == "bash"
    assert p.arg_glob == "*"


def test_parse_tool_with_specific_glob():
    p = _parse_pattern("bash(rm -rf *)")
    assert p.tool == "bash"
    assert p.arg_glob == "rm -rf *"


def test_parse_handles_whitespace():
    p = _parse_pattern("  write_file(src/**)  ")
    assert p.tool == "write_file"
    assert p.arg_glob == "src/**"


# ── _any_match ──────────────────────────────────────────────────────────────

def test_any_match_bash_wildcard():
    assert _any_match(["bash(*)"], "bash", {"command": "anything"})
    assert _any_match(["bash"], "bash", {"command": "anything"})


def test_any_match_bash_specific_prefix():
    assert _any_match(["bash(rm *)"], "bash", {"command": "rm -rf foo"})
    assert not _any_match(["bash(rm *)"], "bash", {"command": "ls"})


def test_any_match_write_file_path_glob():
    assert _any_match(["write_file(src/*)"], "write_file", {"path": "src/a.py"})
    # fnmatch's `*` does NOT cross `/` — but src/** does, in fnmatchcase semantics
    # it's the same as *, so we assert on the documented intent: src/* matches one level.
    assert _any_match(["write_file(src/*.py)"], "write_file", {"path": "src/a.py"})
    assert not _any_match(["write_file(src/*.py)"], "write_file", {"path": "tests/a.py"})


def test_any_match_tool_mismatch_skipped():
    assert not _any_match(["bash(*)"], "read_file", {"path": "a"})


def test_any_match_universal_tool_wildcard():
    assert _any_match(["*(*)"], "anything", {"k": "v"})


# ── Enforcer: deny beats allow ──────────────────────────────────────────────

def test_deny_pattern_blocks_even_when_allowed():
    e = PermissionEnforcer(
        mode=PermissionMode.WORKSPACE_WRITE,
        allow_patterns=["bash(*)"],
        deny_patterns=["bash(sudo *)"],
    )
    d = e.check("bash", {"command": "sudo rm foo"})
    assert d.allowed is False
    assert "deny" in d.reason.lower()


def test_allow_pattern_short_circuits_mode():
    # Bash is normally denied in read-only, but an explicit allow pattern wins.
    e = PermissionEnforcer(
        mode=PermissionMode.READ_ONLY,
        allow_patterns=["bash(echo *)"],
    )
    d = e.check("bash", {"command": "echo hi"})
    assert d.allowed is True


def test_allow_pattern_doesnt_affect_unrelated_tool():
    # An allow pattern for bash must not change read_file behavior.
    e = PermissionEnforcer(
        mode=PermissionMode.READ_ONLY,
        allow_patterns=["bash(*)"],
    )
    # read_file is still allowed under read-only (built-in).
    assert e.check("read_file", {"path": "a"}).allowed is True
    # write_file is still blocked under read-only; no allow pattern for it.
    assert e.check("write_file", {"path": "a"}).allowed is False


def test_empty_patterns_fall_through_to_mode():
    e = PermissionEnforcer(mode=PermissionMode.READ_ONLY)
    assert e.check("write_file", {"path": "a"}).allowed is False
    e.set_mode(PermissionMode.DANGER_FULL_ACCESS)
    assert e.check("write_file", {"path": "a"}).allowed is True


def test_deny_pattern_with_empty_allow_still_blocks():
    e = PermissionEnforcer(
        mode=PermissionMode.DANGER_FULL_ACCESS,
        deny_patterns=["bash(rm *)"],
    )
    d = e.check("bash", {"command": "rm -rf /"})
    assert d.allowed is False


def test_deny_pattern_nonmatching_allows_flow_through():
    e = PermissionEnforcer(
        mode=PermissionMode.WORKSPACE_WRITE,
        deny_patterns=["bash(sudo *)"],
    )
    d = e.check("bash", {"command": "ls"})
    assert d.allowed is True


def test_grep_search_pattern_arg_subject():
    e = PermissionEnforcer(
        mode=PermissionMode.READ_ONLY,
        allow_patterns=["grep_search(TODO*)"],
    )
    # grep_search is already read-safe, so this is really about exercising the
    # arg-subject wiring for non-path/non-command tools.
    assert e.check("grep_search", {"pattern": "TODO fix"}).allowed is True
