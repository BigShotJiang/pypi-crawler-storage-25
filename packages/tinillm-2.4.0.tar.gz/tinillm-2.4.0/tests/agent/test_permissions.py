"""Permission modes, allow/deny lists, and destructive-bash detection."""
from __future__ import annotations

import pytest

from tinillm.agent.permissions import (
    PermissionEnforcer,
    PermissionMode,
    _looks_destructive,
)


class TestMode:
    def test_parse_variants(self):
        assert PermissionMode.parse("read-only") == PermissionMode.READ_ONLY
        assert PermissionMode.parse("READ_ONLY") == PermissionMode.READ_ONLY
        assert PermissionMode.parse("workspace-write") == PermissionMode.WORKSPACE_WRITE

    def test_parse_unknown(self):
        with pytest.raises(ValueError):
            PermissionMode.parse("banana")


class TestReadOnly:
    def test_read_tool_allowed(self):
        e = PermissionEnforcer(mode=PermissionMode.READ_ONLY)
        assert e.check("read_file", {}).allowed is True

    def test_write_denied(self):
        e = PermissionEnforcer(mode=PermissionMode.READ_ONLY)
        d = e.check("write_file", {"path": "x", "content": ""})
        assert d.allowed is False
        assert "read-only" in d.reason

    def test_bash_denied(self):
        e = PermissionEnforcer(mode=PermissionMode.READ_ONLY)
        assert e.check("bash", {"command": "ls"}).allowed is False


class TestWorkspaceWrite:
    def test_write_allowed(self):
        e = PermissionEnforcer(mode=PermissionMode.WORKSPACE_WRITE)
        assert e.check("write_file", {}).allowed is True

    def test_benign_bash_allowed_no_confirm(self):
        e = PermissionEnforcer(mode=PermissionMode.WORKSPACE_WRITE)
        d = e.check("bash", {"command": "ls -la"})
        assert d.allowed is True
        assert d.ask_user is False

    @pytest.mark.parametrize("cmd", [
        "rm -rf /tmp/x",
        "rm -fr some/dir",
        "sudo rm something",
        "mkfs.ext4 /dev/sda1",
        "dd if=/dev/zero of=/dev/sda",
        "shutdown -h now",
        "reboot",
        ":(){ :|:& };:",
        "git push origin main --force",
        "git reset --hard HEAD~5",
    ])
    def test_destructive_bash_asks_user(self, cmd):
        e = PermissionEnforcer(mode=PermissionMode.WORKSPACE_WRITE)
        d = e.check("bash", {"command": cmd})
        assert d.allowed is True
        assert d.ask_user is True


class TestDangerFullAccess:
    def test_anything_goes(self):
        e = PermissionEnforcer(mode=PermissionMode.DANGER_FULL_ACCESS)
        assert e.check("bash", {"command": "rm -rf /"}).allowed is True
        assert e.check("write_file", {}).allowed is True


class TestAllowDenyLists:
    def test_denied_tool(self):
        e = PermissionEnforcer(denied_tools={"bash"})
        assert e.check("bash", {"command": "ls"}).allowed is False

    def test_allowlist_blocks_others(self):
        e = PermissionEnforcer(allowed_tools={"read_file"})
        assert e.check("read_file", {}).allowed is True
        assert e.check("write_file", {}).allowed is False


class TestDestructiveDetector:
    def test_positive_hits(self):
        assert _looks_destructive("rm -rf /")
        assert _looks_destructive("sudo rm -rf x")

    def test_negative(self):
        assert not _looks_destructive("ls")
        assert not _looks_destructive("git status")

    def test_known_false_positive(self):
        # Regex is intentionally substring-based — an echo that quotes a
        # destructive command still trips the detector. Documented trade-off:
        # we'd rather ask one extra confirm than miss a real rm -rf.
        assert _looks_destructive("echo 'rm -rf not a real command'")
