"""rewind_messages + FileSnapshots.diff."""
from __future__ import annotations

from tinillm.agent.rewind import FileSnapshots, rewind_messages


def _conv(turns: int) -> list[dict]:
    msgs = [{"role": "system", "content": "sys"}]
    for i in range(turns):
        msgs.append({"role": "user", "content": f"q{i}"})
        msgs.append({"role": "assistant", "content": f"a{i}"})
    return msgs


class TestRewindMessages:
    def test_no_op_on_zero(self):
        msgs = _conv(3)
        assert rewind_messages(msgs, turns=0) == msgs

    def test_drop_one_turn(self):
        msgs = _conv(3)
        new = rewind_messages(msgs, turns=1)
        # Last user message was 'q2' — cut from there on
        assert {m.get("content") for m in new if m.get("role") == "user"} == {"q0", "q1"}
        assert "a2" not in [m.get("content") for m in new]

    def test_drop_all(self):
        msgs = _conv(2)
        new = rewind_messages(msgs, turns=5)
        # Nothing but system left
        assert [m["role"] for m in new] == ["system"]

    def test_returns_copy(self):
        msgs = _conv(2)
        new = rewind_messages(msgs, turns=1)
        new.clear()
        # Original untouched
        assert len(msgs) == 5


class TestFileSnapshots:
    def test_captures_original(self, tmp_path):
        p = tmp_path / "x.txt"
        p.write_text("orig")
        snaps = FileSnapshots()
        snaps.capture(p)
        p.write_text("new")
        diff = snaps.diff()
        assert "-orig" in diff
        assert "+new" in diff

    def test_double_capture_no_op(self, tmp_path):
        p = tmp_path / "x.txt"
        p.write_text("one")
        snaps = FileSnapshots()
        snaps.capture(p)
        p.write_text("two")
        snaps.capture(p)  # Should NOT overwrite the first snapshot
        p.write_text("three")
        diff = snaps.diff()
        assert "-one" in diff
        assert "+three" in diff

    def test_created_file(self, tmp_path):
        p = tmp_path / "new.txt"
        snaps = FileSnapshots()
        snaps.capture(p)  # doesn't exist yet
        p.write_text("hi")
        diff = snaps.diff()
        assert "/dev/null" in diff
        assert "+hi" in diff

    def test_no_changes(self, tmp_path):
        p = tmp_path / "x.txt"
        p.write_text("stable")
        snaps = FileSnapshots()
        snaps.capture(p)
        assert "no file changes" in snaps.diff()
