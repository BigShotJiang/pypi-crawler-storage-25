"""Sandbox backend detection + argv composition.

Unit-level tests that don't require ``bwrap`` to be installed. Exec-level
tests that actually run a sandboxed command are skipped when the binary is
missing on $PATH.
"""
from __future__ import annotations

import platform
import shutil

import pytest

from tinillm.agent.sandbox import SandboxBackend, detect


# ── detect() ────────────────────────────────────────────────────────────────

def test_detect_returns_backend_instance():
    b = detect()
    assert isinstance(b, SandboxBackend)
    assert b.name in {"bwrap", "sandbox-exec", "none"}


def test_detect_on_linux_with_bwrap(monkeypatch):
    monkeypatch.setattr(platform, "system", lambda: "Linux")
    monkeypatch.setattr(shutil, "which", lambda name: "/usr/bin/bwrap")
    b = detect()
    assert b.name == "bwrap"
    assert b.available is True


def test_detect_on_linux_without_bwrap(monkeypatch):
    monkeypatch.setattr(platform, "system", lambda: "Linux")
    monkeypatch.setattr(shutil, "which", lambda name: None)
    b = detect()
    assert b.name == "none"
    assert b.available is False


def test_detect_on_macos_falls_back(monkeypatch):
    monkeypatch.setattr(platform, "system", lambda: "Darwin")
    b = detect()
    assert b.name == "none"
    assert b.available is False


def test_detect_on_windows_falls_back(monkeypatch):
    monkeypatch.setattr(platform, "system", lambda: "Windows")
    b = detect()
    assert b.name == "none"
    assert b.available is False


# ── wrap_bash() argv composition ────────────────────────────────────────────

class TestBwrapArgv:
    def test_none_backend_returns_plain_bash(self, tmp_path):
        b = SandboxBackend(name="none", available=False)
        argv = b.wrap_bash("echo hi", tmp_path)
        assert argv == ["/bin/bash", "-lc", "echo hi"]

    def test_bwrap_backend_wraps_command(self, tmp_path):
        b = SandboxBackend(name="bwrap", available=True)
        argv = b.wrap_bash("echo hi", tmp_path)
        assert argv[0] == "bwrap"
        assert "/bin/bash" in argv
        assert "-lc" in argv
        assert "echo hi" in argv

    def test_bwrap_binds_workspace_writable(self, tmp_path):
        b = SandboxBackend(name="bwrap", available=True)
        argv = b.wrap_bash("true", tmp_path)
        ws = str(tmp_path.resolve())
        # --bind <ws> <ws> should appear — workspace is read-write.
        assert "--bind" in argv
        bind_index = argv.index("--bind")
        assert argv[bind_index + 1] == ws
        assert argv[bind_index + 2] == ws

    def test_bwrap_ro_binds_root(self, tmp_path):
        b = SandboxBackend(name="bwrap", available=True)
        argv = b.wrap_bash("true", tmp_path)
        # --ro-bind / / so coreutils/bash are reachable read-only.
        assert "--ro-bind" in argv
        idx = argv.index("--ro-bind")
        assert argv[idx + 1] == "/"
        assert argv[idx + 2] == "/"

    def test_bwrap_default_has_no_network(self, tmp_path):
        b = SandboxBackend(name="bwrap", available=True)
        argv = b.wrap_bash("true", tmp_path)
        assert "--unshare-net" in argv

    def test_bwrap_allow_network_drops_unshare_net(self, tmp_path):
        b = SandboxBackend(name="bwrap", available=True)
        argv = b.wrap_bash("true", tmp_path, allow_network=True)
        assert "--unshare-net" not in argv

    def test_bwrap_die_with_parent(self, tmp_path):
        b = SandboxBackend(name="bwrap", available=True)
        argv = b.wrap_bash("true", tmp_path)
        assert "--die-with-parent" in argv

    def test_bwrap_chdir_is_workspace(self, tmp_path):
        b = SandboxBackend(name="bwrap", available=True)
        argv = b.wrap_bash("true", tmp_path)
        idx = argv.index("--chdir")
        assert argv[idx + 1] == str(tmp_path.resolve())

    def test_bwrap_not_available_falls_back(self, tmp_path):
        # name=bwrap but available=False should still fall through unwrapped.
        b = SandboxBackend(name="bwrap", available=False)
        argv = b.wrap_bash("echo hi", tmp_path)
        assert argv == ["/bin/bash", "-lc", "echo hi"]


# ── Exec-level (requires bwrap) ─────────────────────────────────────────────

_BWRAP = shutil.which("bwrap")


@pytest.mark.skipif(_BWRAP is None, reason="bubblewrap not installed")
class TestBwrapExec:
    def test_sandboxed_command_runs(self, tmp_path):
        from tinillm.agent.tools.bash import run_bash
        b = SandboxBackend(name="bwrap", available=True)
        r = run_bash("echo sandbox-ok", cwd=tmp_path, sandbox=b)
        assert r.exit_code == 0
        assert "sandbox-ok" in r.stdout

    def test_sandboxed_workspace_is_writable(self, tmp_path):
        from tinillm.agent.tools.bash import run_bash
        b = SandboxBackend(name="bwrap", available=True)
        r = run_bash(f"echo hello > {tmp_path}/out.txt", cwd=tmp_path, sandbox=b)
        assert r.exit_code == 0
        assert (tmp_path / "out.txt").read_text().strip() == "hello"

    def test_sandboxed_network_blocked_by_default(self, tmp_path):
        """Without allow_network, DNS/socket access should fail."""
        from tinillm.agent.tools.bash import run_bash
        b = SandboxBackend(name="bwrap", available=True)
        # `getent hosts` fails fast when the net namespace is unshared.
        r = run_bash(
            "getent hosts example.com >/dev/null 2>&1; echo exit=$?",
            cwd=tmp_path,
            sandbox=b,
            allow_network=False,
        )
        # Either the command fails (exit!=0 in echo) or getent returns non-zero.
        assert "exit=0" not in r.stdout
