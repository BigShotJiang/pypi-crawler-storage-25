"""Post-plan-approval autonomy: ``ctx.auto_confirm`` during execution.

When ``/plan`` auto-accepts, the execution phase must run without per-tool
confirmation prompts (that's what the user is signing off by producing the
plan). Scope: one model loop. After the loop returns control to the user,
``ctx.auto_confirm`` is restored to the session's original value so the next
turn's destructive bash gets a fresh confirm.
"""
from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import patch

import pytest


# ── Fake ollama ──────────────────────────────────────────────────────────────

class _FakeMessage:
    def __init__(self, content="", tool_calls=None, role="assistant"):
        self.role = role
        self.content = content
        self.tool_calls = tool_calls


class _FakeResponse:
    def __init__(self, message, prompt_tokens=10, eval_tokens=20):
        self.message = message
        self.prompt_eval_count = prompt_tokens
        self.eval_count = eval_tokens


def _tool_call(name: str, args: dict):
    return SimpleNamespace(function=SimpleNamespace(name=name, arguments=args))


class _FakeOllama:
    def __init__(self, scripted):
        self._responses = list(scripted)
        self.calls = []
        self.ResponseError = Exception

    def chat(self, **kwargs):
        self.calls.append(kwargs)
        if not self._responses:
            raise AssertionError("no scripted response left")
        return self._responses.pop(0)


# ── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
def in_workspace(tmp_path, monkeypatch, isolated_home):
    ws = tmp_path / "work"
    ws.mkdir()
    monkeypatch.chdir(ws)
    return ws


def _run_chat(fake_ollama, inputs, **kwargs):
    with patch.dict("sys.modules", {"ollama": fake_ollama}):
        with patch(
            "tinillm.run.agent_chat.click.prompt",
            side_effect=list(inputs) + ["/exit"],
        ):
            with patch("tinillm.run.chat_session._mem_writer_ingest"):
                from tinillm.run.agent_chat import run_agent_chat
                run_agent_chat(model_tag="fake-model", **kwargs)


# ── Test ─────────────────────────────────────────────────────────────────────

class TestPlanApprovalAutonomy:
    def test_plan_approval_grants_auto_confirm(self, in_workspace):
        """During post-plan tool execution ``ctx.auto_confirm`` must be True,
        and must be restored to its original value after the loop returns."""
        # Scripted model turns:
        #   1. First user input → model emits a 3-item plan (triggers auto-accept).
        #   2. After approval → model emits a tool_call (this is where we
        #      spy on ctx.auto_confirm).
        #   3. After tool result → model emits final text (returns control).
        plan_turn = _FakeResponse(_FakeMessage(
            content="Plan:\n1. inspect\n2. edit\n3. verify\n",
        ))
        exec_turn = _FakeResponse(_FakeMessage(
            content="",
            tool_calls=[_tool_call("write_file", {"path": "out.txt", "content": "x"})],
        ))
        done_turn = _FakeResponse(_FakeMessage(content="done."))
        ollama = _FakeOllama([plan_turn, exec_turn, done_turn])

        # Spy on dispatch to capture ctx.auto_confirm *at tool execution time*.
        seen_auto_confirm: list[bool] = []
        from tinillm.run import chat_session as _cs
        real_dispatch = _cs.dispatch

        def spying_dispatch(ctx, name, args):
            seen_auto_confirm.append(ctx.auto_confirm)
            return real_dispatch(ctx, name, args)

        with patch.object(_cs, "dispatch", side_effect=spying_dispatch):
            _run_chat(ollama, ["/plan", "refactor the thing"])

        # 3 model calls: plan, exec (tool), done.
        assert len(ollama.calls) == 3

        # During tool execution (post-approval) auto_confirm was True.
        assert seen_auto_confirm == [True], (
            f"expected auto_confirm=True during post-plan tool exec, "
            f"got {seen_auto_confirm}"
        )

        # After the loop returns, the next user-initiated turn sees the
        # *original* auto_confirm value. We can verify by driving a second
        # user turn: spy again and assert False.
        seen_after: list[bool] = []

        def spying_dispatch_after(ctx, name, args):
            seen_after.append(ctx.auto_confirm)
            return real_dispatch(ctx, name, args)

        ollama2 = _FakeOllama([
            _FakeResponse(_FakeMessage(
                content="",
                tool_calls=[_tool_call("write_file",
                                        {"path": "q.txt", "content": "y"})],
            )),
            _FakeResponse(_FakeMessage(content="ok")),
        ])

        with patch.object(_cs, "dispatch", side_effect=spying_dispatch_after):
            _run_chat(ollama2, ["do another thing"])

        # Fresh session → auto_confirm defaults to False, and tool exec in
        # the new turn should observe that (autonomy did NOT leak).
        assert seen_after == [False], (
            f"auto_confirm leaked across sessions: {seen_after}"
        )
