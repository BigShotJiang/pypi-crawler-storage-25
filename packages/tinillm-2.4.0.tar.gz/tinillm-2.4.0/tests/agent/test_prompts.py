"""System prompt assembly + /init project bootstrap."""
from __future__ import annotations

import pytest

from tinillm.agent.prompts import (
    assemble_system_prompt,
    default_system_prompt,
    init_project,
    load_project_prompt,
)


class TestDefaultPrompt:
    def test_mentions_tools(self):
        p = default_system_prompt()
        assert "read_file" in p
        assert "bash" in p
        assert "TodoWrite" in p


class TestProjectPrompt:
    def test_missing_returns_none(self, tmp_path):
        assert load_project_prompt(tmp_path) is None

    def test_loads_file(self, tmp_path):
        (tmp_path / "TINILLM.md").write_text("# Project X\nuse pep8\n")
        p = load_project_prompt(tmp_path)
        assert "Project X" in p

    def test_empty_file_is_none(self, tmp_path):
        (tmp_path / "TINILLM.md").write_text("   \n")
        assert load_project_prompt(tmp_path) is None


class TestAssemble:
    def test_includes_project_when_present(self, tmp_path):
        (tmp_path / "TINILLM.md").write_text("use tabs\n")
        full = assemble_system_prompt(tmp_path)
        assert "use tabs" in full
        assert "read_file" in full  # defaults still there

    def test_extra_appended(self, tmp_path):
        full = assemble_system_prompt(tmp_path, extra="extra rule")
        assert "extra rule" in full


class TestInitProject:
    def test_writes_starter(self, tmp_path):
        path = init_project(tmp_path)
        assert path.exists()
        body = path.read_text()
        assert tmp_path.name in body
        assert "# " in body

    def test_refuses_overwrite(self, tmp_path):
        (tmp_path / "TINILLM.md").write_text("existing")
        with pytest.raises(FileExistsError):
            init_project(tmp_path)

    def test_force_overwrites(self, tmp_path):
        (tmp_path / "TINILLM.md").write_text("old")
        init_project(tmp_path, force=True)
        body = (tmp_path / "TINILLM.md").read_text()
        assert "old" not in body
