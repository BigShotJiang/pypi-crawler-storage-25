"""New slash commands: /init, /permissions, /skills, /sessions."""
from __future__ import annotations

import pytest
from click.testing import CliRunner


@pytest.fixture
def runner():
    return CliRunner()


class TestInitCommand:
    def test_writes_tinillm_md(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from tinillm.commands import init_cmd
        result = runner.invoke(init_cmd, [])
        assert result.exit_code == 0
        assert (tmp_path / "TINILLM.md").exists()

    def test_refuses_overwrite(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "TINILLM.md").write_text("old")
        from tinillm.commands import init_cmd
        result = runner.invoke(init_cmd, [])
        assert "exists" in result.output
        assert (tmp_path / "TINILLM.md").read_text() == "old"

    def test_force(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "TINILLM.md").write_text("old")
        from tinillm.commands import init_cmd
        result = runner.invoke(init_cmd, ["--force"])
        assert result.exit_code == 0
        assert (tmp_path / "TINILLM.md").read_text() != "old"


class TestPermissionsCommand:
    def test_shows_current(self, runner):
        from tinillm.commands import permissions_cmd
        result = runner.invoke(permissions_cmd, [])
        assert result.exit_code == 0
        assert "current mode" in result.output


class TestSkillsCommand:
    def test_empty(self, runner, isolated_home, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        from tinillm.commands import skills_cmd
        result = runner.invoke(skills_cmd, [])
        assert "No skills" in result.output


class TestSessionsCommand:
    def test_empty(self, runner, isolated_home):
        from tinillm.commands import sessions_cmd
        result = runner.invoke(sessions_cmd, [])
        assert "No saved sessions" in result.output
