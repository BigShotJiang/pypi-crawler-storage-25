"""End-to-end agent chat loop — mocked ollama, real tools, real session store.

The loop is the single integration point that ties permissions, tools, hooks,
sessions, usage, recovery, and in-chat slash commands together. These tests
drive it through a fake Ollama that replays scripted responses.
"""
from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import patch

import pytest


# ── Fake ollama module ───────────────────────────────────────────────────────

class _FakeMessage:
    def __init__(self, content="", tool_calls=None, role="assistant"):
        self.role = role
        self.content = content
        self.tool_calls = tool_calls


class _FakeResponse:
    def __init__(self, message, prompt_tokens=10, eval_tokens=20):
        self.message = message
        self.prompt_eval_count = prompt_tokens
        self.eval_count = eval_tokens


def _tool_call(name: str, args: dict):
    """Build a fake Ollama tool-call matching the attribute shape we use."""
    return SimpleNamespace(
        function=SimpleNamespace(name=name, arguments=args)
    )


class _FakeOllama:
    """Minimal stand-in for the ``ollama`` module."""
    def __init__(self, scripted_responses):
        self._responses = list(scripted_responses)
        self.calls = []
        self.ResponseError = Exception  # type used by run_agent_chat

    def chat(self, **kwargs):
        self.calls.append(kwargs)
        if not self._responses:
            raise AssertionError("no scripted response left")
        return self._responses.pop(0)


# ── Fixtures ────────────────────────────────────────────────────────────────

@pytest.fixture
def in_workspace(tmp_path, monkeypatch, isolated_home):
    """Run the chat loop with cwd pointed at a clean workspace."""
    ws = tmp_path / "work"
    ws.mkdir()
    monkeypatch.chdir(ws)
    return ws


def _run_chat(fake_ollama, inputs, **kwargs):
    """Drive run_agent_chat with a scripted user-input iterator."""
    # Patch the ollama import AND the click.prompt used by the loop.
    with patch.dict("sys.modules", {"ollama": fake_ollama}):
        with patch("tinillm.run.agent_chat.click.prompt",
                   side_effect=list(inputs) + ["/exit"]):
            # Also disable memory writer to keep the test hermetic.
            with patch("tinillm.run.chat_session._mem_writer_ingest"):
                from tinillm.run.agent_chat import run_agent_chat
                run_agent_chat(model_tag="fake-model", **kwargs)


# ── Tests ────────────────────────────────────────────────────────────────────

class TestPlainChat:
    def test_single_turn(self, in_workspace):
        ollama = _FakeOllama([
            _FakeResponse(_FakeMessage(content="hi there")),
        ])
        _run_chat(ollama, ["hello"])
        # 1 user turn → 1 chat call
        assert len(ollama.calls) == 1
        # Messages sent include system + user
        sent = ollama.calls[0]["messages"]
        roles = [m["role"] for m in sent]
        assert "system" in roles
        assert "user" in roles


class TestToolCalling:
    def test_read_file_roundtrip(self, in_workspace):
        (in_workspace / "a.txt").write_text("file-contents")
        ollama = _FakeOllama([
            _FakeResponse(_FakeMessage(
                content="",
                tool_calls=[_tool_call("read_file", {"path": "a.txt"})],
            )),
            _FakeResponse(_FakeMessage(content="done reading")),
        ])
        _run_chat(ollama, ["what's in a.txt"])
        # Second call must include tool message with file contents
        second = ollama.calls[1]["messages"]
        tool_msgs = [m for m in second if m.get("role") == "tool"]
        assert tool_msgs
        assert "file-contents" in tool_msgs[0]["content"]

    def test_write_captures_snapshot(self, in_workspace):
        ollama = _FakeOllama([
            _FakeResponse(_FakeMessage(
                content="",
                tool_calls=[_tool_call("write_file",
                                        {"path": "new.txt", "content": "hi"})],
            )),
            _FakeResponse(_FakeMessage(content="wrote it")),
        ])
        _run_chat(ollama, ["make a file"])
        assert (in_workspace / "new.txt").read_text() == "hi"


class TestPermissionMode:
    def test_read_only_blocks_writes(self, in_workspace):
        ollama = _FakeOllama([
            _FakeResponse(_FakeMessage(
                content="",
                tool_calls=[_tool_call("write_file",
                                        {"path": "x.txt", "content": "x"})],
            )),
            _FakeResponse(_FakeMessage(content="sorry")),
        ])
        _run_chat(ollama, ["write x.txt"], mode="read-only")
        # File must NOT have been created
        assert not (in_workspace / "x.txt").exists()
        # Tool result in the next call should mention permission denied
        second = ollama.calls[1]["messages"]
        tool_msgs = [m for m in second if m.get("role") == "tool"]
        assert any("permission denied" in m["content"].lower() for m in tool_msgs)


class TestSessionPersistence:
    def test_messages_written_to_jsonl(self, in_workspace, isolated_home):
        ollama = _FakeOllama([
            _FakeResponse(_FakeMessage(content="ok")),
        ])
        _run_chat(ollama, ["ping"])

        # Find the session file under isolated HOME
        sessions = list((isolated_home / ".tinillm" / "sessions").glob("*.jsonl"))
        assert len(sessions) == 1
        content = sessions[0].read_text()
        assert '"role": "user"' in content
        assert '"role": "assistant"' in content

    def test_resume_loads_prior_history(self, in_workspace, isolated_home):
        # First session
        ollama1 = _FakeOllama([_FakeResponse(_FakeMessage(content="first"))])
        _run_chat(ollama1, ["one"])

        # Find the session id
        metas = list((isolated_home / ".tinillm" / "sessions").glob("*.meta.json"))
        assert len(metas) == 1
        import json
        sid = json.loads(metas[0].read_text())["id"]

        # Resume — history should be passed to ollama.chat
        ollama2 = _FakeOllama([_FakeResponse(_FakeMessage(content="second"))])
        _run_chat(ollama2, ["two"], resume_id=sid)

        second_call_msgs = ollama2.calls[0]["messages"]
        # Should contain both turns: one user "one" and one user "two"
        user_contents = [m["content"] for m in second_call_msgs if m.get("role") == "user"]
        assert "one" in user_contents
        assert "two" in user_contents


class TestInChatCommands:
    def test_rewind_removes_turn(self, in_workspace):
        # One real model turn, then /rewind should NOT re-call the model
        ollama = _FakeOllama([_FakeResponse(_FakeMessage(content="first"))])
        _run_chat(ollama, ["hello", "/rewind"])
        # Only the initial "hello" turn made an ollama call
        assert len(ollama.calls) == 1

    def test_rewind_non_integer_does_not_crash(self, in_workspace):
        """Regression: /rewind abc used to raise ValueError and kill the loop."""
        ollama = _FakeOllama([
            _FakeResponse(_FakeMessage(content="first")),
            _FakeResponse(_FakeMessage(content="second")),
        ])
        _run_chat(ollama, ["hi", "/rewind abc", "second"])
        # Loop survived → second prompt reached the model
        assert len(ollama.calls) == 2


class TestErrorRollback:
    def test_rollback_keeps_store_in_sync(self, in_workspace, isolated_home):
        """Regression: on model error the JSONL used to keep phantom messages."""

        class _Boom(_FakeOllama):
            def chat(self, **kwargs):
                self.calls.append(kwargs)
                raise RuntimeError("ollama blew up")

        ollama = _Boom([])
        _run_chat(ollama, ["will error"])

        # The JSONL must not contain the failed user turn in a way that breaks resume
        sessions = list((isolated_home / ".tinillm" / "sessions").glob("*.jsonl"))
        raw = sessions[0].read_text().splitlines()
        # System message only remains — error rolled back the user msg too
        import json
        roles = [json.loads(l)["role"] for l in raw if l.strip()]
        assert roles.count("assistant") == 0


class TestNoModelConfigured:
    def test_errors_out_cleanly(self, in_workspace, capsys):
        """No model_tag and no config → friendly error, no crash."""
        from tinillm.run.agent_chat import run_agent_chat
        with patch.dict("sys.modules", {"ollama": _FakeOllama([])}):
            run_agent_chat(model_tag=None)
        out = capsys.readouterr().out
        assert "No model" in out
