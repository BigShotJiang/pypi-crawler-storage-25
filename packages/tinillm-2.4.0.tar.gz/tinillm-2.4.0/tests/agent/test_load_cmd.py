"""``/load <model>`` command.

Two surfaces:

- Top-level Click command (registered in ``COMMAND_REGISTRY["load"]``) that
  persists ``model`` to ``~/.tinillm/settings.json``.
- In-chat slash handler that additionally swaps the live model mid-session.
"""
from __future__ import annotations

import json
from types import SimpleNamespace
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tinillm.agent import settings as _settings
from tinillm.commands import COMMAND_REGISTRY, load_cmd


@pytest.fixture
def isolated_home_simple(tmp_path, monkeypatch):
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setattr("pathlib.Path.home", classmethod(lambda cls: home))
    return home


# ── Click command surface ───────────────────────────────────────────────────

class TestLoadCommand:
    def test_registered_in_command_registry(self):
        assert "load" in COMMAND_REGISTRY
        assert COMMAND_REGISTRY["load"] is load_cmd

    def test_writes_settings_json(self, isolated_home_simple):
        runner = CliRunner()
        result = runner.invoke(load_cmd, ["qwen2.5-coder:14b"])
        assert result.exit_code == 0
        p = _settings.path()
        assert p.exists()
        data = json.loads(p.read_text())
        assert data["model"] == "qwen2.5-coder:14b"

    def test_updates_existing_settings(self, isolated_home_simple):
        # Pre-seed settings.json with other values.
        _settings.save(model="old:1b", auto_accept_plan=False)
        runner = CliRunner()
        result = runner.invoke(load_cmd, ["new:7b"])
        assert result.exit_code == 0
        s = _settings.load()
        assert s.model == "new:7b"
        # Unrelated fields must survive.
        assert s.auto_accept_plan is False

    def test_requires_model_tag_argument(self):
        runner = CliRunner()
        result = runner.invoke(load_cmd, [])
        assert result.exit_code != 0  # missing required argument

    def test_prints_confirmation(self, isolated_home_simple):
        runner = CliRunner()
        result = runner.invoke(load_cmd, ["llama3.1:8b"])
        assert "llama3.1:8b" in result.output


# ── In-chat slash handler ───────────────────────────────────────────────────

class _FakeMessage:
    def __init__(self, content="", tool_calls=None, role="assistant"):
        self.role = role
        self.content = content
        self.tool_calls = tool_calls


class _FakeResponse:
    def __init__(self, message):
        self.message = message
        self.prompt_eval_count = 1
        self.eval_count = 1


class _FakeOllama:
    def __init__(self, scripted):
        self._responses = list(scripted)
        self.calls = []
        self.ResponseError = Exception

    def chat(self, **kwargs):
        self.calls.append(kwargs)
        if not self._responses:
            raise AssertionError("no scripted response left")
        return self._responses.pop(0)


@pytest.fixture
def in_workspace(tmp_path, monkeypatch, isolated_home):
    ws = tmp_path / "work"
    ws.mkdir()
    monkeypatch.chdir(ws)
    return ws


def _run_chat(fake_ollama, inputs, **kwargs):
    with patch.dict("sys.modules", {"ollama": fake_ollama}):
        with patch(
            "tinillm.run.agent_chat.click.prompt",
            side_effect=list(inputs) + ["/exit"],
        ):
            with patch("tinillm.run.chat_session._mem_writer_ingest"):
                from tinillm.run.agent_chat import run_agent_chat
                run_agent_chat(model_tag="start-model", **kwargs)


class TestLoadInChat:
    def test_load_swaps_active_model(self, in_workspace):
        """After /load <tag>, the next model call must target the new tag."""
        ollama = _FakeOllama([
            _FakeResponse(_FakeMessage(content="first")),   # "hello"
            _FakeResponse(_FakeMessage(content="second")),  # "after-load"
        ])
        _run_chat(ollama, ["hello", "/load qwen1:7b", "after-load"])

        assert len(ollama.calls) == 2
        assert ollama.calls[0]["model"] == "start-model"
        assert ollama.calls[1]["model"] == "qwen1:7b"

    def test_load_persists_to_settings_json(self, in_workspace, isolated_home):
        ollama = _FakeOllama([_FakeResponse(_FakeMessage(content="ok"))])
        _run_chat(ollama, ["hi", "/load llama3.1:70b"])
        s = _settings.load()
        assert s.model == "llama3.1:70b"

    def test_load_without_arg_is_noop(self, in_workspace):
        """/load with no argument should complain but not crash the loop."""
        ollama = _FakeOllama([
            _FakeResponse(_FakeMessage(content="first")),
            _FakeResponse(_FakeMessage(content="second")),
        ])
        _run_chat(ollama, ["hello", "/load", "still-working"])
        # Loop must have survived to the third prompt.
        assert len(ollama.calls) == 2
        # Model should not have changed.
        assert ollama.calls[1]["model"] == "start-model"
