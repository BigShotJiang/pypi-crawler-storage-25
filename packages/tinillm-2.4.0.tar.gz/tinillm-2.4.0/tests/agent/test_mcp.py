"""MCP stdio client — config parser only (no live server)."""
from __future__ import annotations

import json

import pytest


@pytest.fixture
def mcp_mod(isolated_home):
    import tinillm.agent.mcp as m
    return m


class TestLoadConfig:
    def test_missing_file_returns_empty(self, mcp_mod):
        assert mcp_mod.load_config() == []

    def test_parses_commands(self, mcp_mod):
        mcp_mod._CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        mcp_mod._CONFIG_PATH.write_text(json.dumps({
            "servers": {
                "filesystem": {"command": ["npx", "-y", "@server/fs"]},
                "git": {"command": "gitmcp"},
            }
        }))
        specs = mcp_mod.load_config()
        by_name = {s.name: s for s in specs}
        assert by_name["filesystem"].command == ["npx", "-y", "@server/fs"]
        assert by_name["git"].command == ["gitmcp"]

    def test_env_passed_through(self, mcp_mod):
        mcp_mod._CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        mcp_mod._CONFIG_PATH.write_text(json.dumps({
            "servers": {"x": {"command": ["x"], "env": {"TOKEN": "abc"}}}
        }))
        specs = mcp_mod.load_config()
        assert specs[0].env == {"TOKEN": "abc"}

    def test_malformed_json(self, mcp_mod):
        mcp_mod._CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        mcp_mod._CONFIG_PATH.write_text("{{{")
        assert mcp_mod.load_config() == []

    def test_missing_command_skipped(self, mcp_mod):
        mcp_mod._CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        mcp_mod._CONFIG_PATH.write_text(json.dumps({
            "servers": {"broken": {}}
        }))
        assert mcp_mod.load_config() == []


class TestErrorType:
    def test_start_without_executable(self, mcp_mod):
        spec = mcp_mod.McpServerSpec(
            name="fake", command=["this-binary-does-not-exist-anywhere"]
        )
        client = mcp_mod.McpClient(spec=spec)
        with pytest.raises(mcp_mod.McpError, match="not found"):
            client.start()
