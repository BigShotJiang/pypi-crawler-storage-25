"""TodoWrite list semantics + AskUserQuestion answer parsing."""
from __future__ import annotations

from unittest.mock import patch

from tinillm.agent.tools.ask_user import ask_user
from tinillm.agent.tools.todo import TodoList, TodoStatus


class TestTodoList:
    def test_write_replaces_wholesale(self):
        lst = TodoList()
        lst.write([{"content": "a", "status": "pending", "active_form": "Doing a"}])
        assert len(lst.items) == 1
        assert lst.items[0].status == TodoStatus.PENDING

        lst.write([{"content": "b", "status": "in_progress", "active_form": "Doing b"}])
        assert len(lst.items) == 1
        assert lst.items[0].content == "b"

    def test_ids_reset(self):
        lst = TodoList()
        lst.write([{"content": "a", "status": "pending"},
                   {"content": "b", "status": "pending"}])
        ids = [t.id for t in lst.items]
        assert ids == [1, 2]

    def test_render_empty(self):
        assert TodoList().render() == "(no tasks)"

    def test_render_markers(self):
        lst = TodoList()
        lst.write([
            {"content": "done", "status": "completed", "active_form": ""},
            {"content": "now", "status": "in_progress", "active_form": "Doing now"},
            {"content": "later", "status": "pending", "active_form": ""},
        ])
        out = lst.render()
        assert "[x] done" in out
        assert "[~] Doing now" in out
        assert "[ ] later" in out


class TestAskUser:
    def test_free_text_answer(self):
        with patch("click.prompt", return_value="my answer"):
            r = ask_user("why?")
        assert r.answer == "my answer"

    def test_numeric_choice_maps_to_option(self):
        with patch("click.prompt", return_value="2"):
            r = ask_user("pick", options=["alpha", "beta", "gamma"])
        assert r.answer == "beta"

    def test_out_of_range_number_returns_raw(self):
        with patch("click.prompt", return_value="99"):
            r = ask_user("pick", options=["alpha"])
        assert r.answer == "99"

    def test_non_numeric_with_options_returns_raw(self):
        with patch("click.prompt", return_value="custom"):
            r = ask_user("pick", options=["alpha"])
        assert r.answer == "custom"
