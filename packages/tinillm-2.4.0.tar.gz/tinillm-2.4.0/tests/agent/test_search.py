"""glob_search + grep_search (pure-Python path — rg not required)."""
from __future__ import annotations

from unittest.mock import patch

import pytest

from tinillm.agent.tools.search import glob_search, grep_search


@pytest.fixture
def tree(workspace, write_file_in_ws):
    write_file_in_ws("a.py", "print('hello')\n")
    write_file_in_ws("src/b.py", "x = 1\nprint('world')\n")
    write_file_in_ws("src/sub/c.py", "y = 2\n")
    write_file_in_ws("notes.md", "# Notes\n")
    return workspace


class TestGlobSearch:
    def test_single_pattern(self, tree):
        r = glob_search(tree, "*.py")
        names = [p.rsplit("/", 1)[-1] for p in r.matches]
        assert "a.py" in names

    def test_recursive_pattern(self, tree):
        r = glob_search(tree, "**/*.py")
        assert len(r.matches) == 3

    def test_limit_truncates(self, tree):
        r = glob_search(tree, "**/*.py", limit=2)
        assert len(r.matches) == 2
        assert r.truncated is True

    def test_no_match(self, tree):
        r = glob_search(tree, "*.rs")
        assert r.matches == []
        assert r.truncated is False

    def test_sorted_newest_first(self, tree, write_file_in_ws):
        # Touch notes.md to make it newer than a.py.
        import os, time
        now = time.time()
        os.utime(tree.root / "notes.md", (now, now))
        os.utime(tree.root / "a.py", (now - 100, now - 100))
        r = glob_search(tree, "*")
        # First result should be the newest (notes.md)
        assert r.matches[0].endswith("notes.md")


class TestGrepSearch:
    @pytest.fixture(autouse=True)
    def force_python_fallback(self):
        """Disable the rg path so tests exercise the pure-Python scanner."""
        with patch("tinillm.agent.tools.search.shutil.which", return_value=None):
            yield

    def test_literal_match(self, tree):
        r = grep_search(tree, "hello")
        assert len(r.matches) == 1
        assert r.matches[0].text == "print('hello')"
        assert r.matches[0].line == 1

    def test_regex(self, tree):
        r = grep_search(tree, r"print\('(hello|world)'\)")
        assert len(r.matches) == 2

    def test_case_insensitive(self, tree):
        r = grep_search(tree, "HELLO", case_insensitive=True)
        assert len(r.matches) == 1

    def test_glob_scope(self, tree):
        r = grep_search(tree, "x = 1", glob="**/*.py")
        assert len(r.matches) == 1

    def test_limit_truncates(self, tree):
        r = grep_search(tree, "print", limit=1)
        assert len(r.matches) == 1
        assert r.truncated is True

    def test_path_scope(self, tree, write_file_in_ws):
        write_file_in_ws("src/only.py", "hello\n")
        r = grep_search(tree, "hello", path="src")
        paths = [m.path for m in r.matches]
        assert all("/src/" in p for p in paths)
