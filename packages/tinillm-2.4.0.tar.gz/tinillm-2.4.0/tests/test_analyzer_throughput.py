"""Unit tests for tokens/sec throughput estimation.

Validates the physics-based formula:
  tps = bandwidth_GB_s * 0.55 / model_size_GB
"""

import pytest

from tinillm.analyzer.throughput import estimate_tokens_per_sec
from tinillm.analyzer.types import LlmModel, Quant


@pytest.fixture
def model_7b() -> LlmModel:
    return LlmModel("~7B", 7.0, 32, 8, 128, 8192)


@pytest.fixture
def model_70b() -> LlmModel:
    return LlmModel("~70B", 70.0, 80, 8, 128, 4096)


class TestEstimateTokensPerSec:
    def test_rtx4090_7b_q4km_approximate(self, model_7b):
        """
        RTX 4090 bandwidth = 1008 GB/s
        7B Q4_K_M model_size = 7 * 0.58 = 4.06 GB
        tps = 1008 * 0.55 / 4.06 ≈ 136 t/s
        """
        tps = estimate_tokens_per_sec(model_7b, Quant.Q4_K_M, 1008.0, runs_on_gpu=True)
        assert 100 < tps < 200, f"RTX 4090 7B Q4_K_M expected 100–200 t/s, got {tps:.1f}"

    def test_gpu_faster_than_cpu(self, model_7b):
        tps_gpu = estimate_tokens_per_sec(model_7b, Quant.Q4_K_M, 500.0, runs_on_gpu=True)
        tps_cpu = estimate_tokens_per_sec(model_7b, Quant.Q4_K_M, 500.0, runs_on_gpu=False)
        assert tps_gpu > tps_cpu

    def test_lower_quant_faster_tps(self, model_7b):
        """Q2_K weighs less per token → higher throughput."""
        tps_q8 = estimate_tokens_per_sec(model_7b, Quant.Q8_0, 500.0, runs_on_gpu=True)
        tps_q4 = estimate_tokens_per_sec(model_7b, Quant.Q4_K_M, 500.0, runs_on_gpu=True)
        tps_q2 = estimate_tokens_per_sec(model_7b, Quant.Q2_K, 500.0, runs_on_gpu=True)
        assert tps_q8 < tps_q4 < tps_q2

    def test_larger_model_slower(self, model_7b, model_70b):
        """70B model is ~10x larger → ~10x slower at same quant + bandwidth."""
        tps_7b = estimate_tokens_per_sec(model_7b, Quant.Q4_K_M, 500.0, runs_on_gpu=True)
        tps_70b = estimate_tokens_per_sec(model_70b, Quant.Q4_K_M, 500.0, runs_on_gpu=True)
        assert tps_7b > tps_70b

    def test_zero_bandwidth_uses_fallback(self, model_7b):
        """When bandwidth is unknown (0), fallback constants are used — must be > 0."""
        tps = estimate_tokens_per_sec(model_7b, Quant.Q4_K_M, 0.0, runs_on_gpu=True)
        assert tps > 0

    def test_cpu_fallback_positive(self, model_7b):
        tps = estimate_tokens_per_sec(model_7b, Quant.Q4_K_M, 0.0, runs_on_gpu=False)
        assert tps > 0

    def test_all_quants_return_positive_with_known_bandwidth(self, model_7b):
        for q in Quant:
            tps = estimate_tokens_per_sec(model_7b, q, 500.0, runs_on_gpu=True)
            assert tps > 0, f"TPS for {q} must be positive"

    def test_higher_bandwidth_means_more_tps(self, model_7b):
        tps_low = estimate_tokens_per_sec(model_7b, Quant.Q4_K_M, 300.0, runs_on_gpu=True)
        tps_high = estimate_tokens_per_sec(model_7b, Quant.Q4_K_M, 1008.0, runs_on_gpu=True)
        assert tps_high > tps_low
