"""Unit tests for GPU output parsers.

Uses monkeypatching to inject fake subprocess output so tests run
on any machine regardless of which GPU tools are installed.
"""

from __future__ import annotations

import subprocess
from unittest.mock import MagicMock, patch

import pytest

from tinillm.hardware.gpu_nvidia import _from_nvidia_smi
from tinillm.hardware.gpu_amd import _from_rocm_smi_json, _from_rocm_smi_text
from tinillm.hardware.gpu_windows import _override_vram, detect_windows_gpus
from tinillm.hardware.bandwidth import gpu_bandwidth_gbps


# ── NVIDIA nvidia-smi parser ───────────────────────────────────────────────

class TestNvidiaSmiParser:
    def _run_mock(self, stdout: str, returncode: int = 0):
        mock = MagicMock()
        mock.returncode = returncode
        mock.stdout = stdout
        return mock

    def test_single_rtx4090(self):
        stdout = "NVIDIA GeForce RTX 4090, 24576\n"
        with patch("subprocess.run", return_value=self._run_mock(stdout)):
            gpus = _from_nvidia_smi()
        assert len(gpus) == 1
        assert gpus[0].name == "NVIDIA GeForce RTX 4090"
        assert gpus[0].vram_gb == 24.0
        assert gpus[0].backend == "CUDA"

    def test_multiple_identical_cards_are_grouped(self):
        """Four identical RTX 3090s should produce count=4, not 4 entries."""
        stdout = "\n".join(["NVIDIA GeForce RTX 3090, 24576"] * 4) + "\n"
        with patch("subprocess.run", return_value=self._run_mock(stdout)):
            gpus = _from_nvidia_smi()
        assert len(gpus) == 1
        assert gpus[0].count == 4
        assert gpus[0].vram_gb == 24.0

    def test_two_different_cards(self):
        stdout = "NVIDIA GeForce RTX 4090, 24576\nNVIDIA GeForce RTX 3060, 12288\n"
        with patch("subprocess.run", return_value=self._run_mock(stdout)):
            gpus = _from_nvidia_smi()
        assert len(gpus) == 2
        names = {g.name for g in gpus}
        assert "NVIDIA GeForce RTX 4090" in names

    def test_empty_output_returns_empty_list(self):
        with patch("subprocess.run", return_value=self._run_mock("")):
            gpus = _from_nvidia_smi()
        assert gpus == []

    def test_nonzero_exit_returns_empty_list(self):
        with patch("subprocess.run", return_value=self._run_mock("", returncode=6)):
            gpus = _from_nvidia_smi()
        assert gpus == []

    def test_file_not_found_returns_empty_list(self):
        with patch("subprocess.run", side_effect=FileNotFoundError):
            gpus = _from_nvidia_smi()
        assert gpus == []

    def test_timeout_returns_empty_list(self):
        with patch("subprocess.run", side_effect=subprocess.TimeoutExpired("nvidia-smi", 10)):
            gpus = _from_nvidia_smi()
        assert gpus == []

    def test_malformed_line_is_skipped(self):
        """A line without a comma should be silently ignored."""
        stdout = "NVIDIA GeForce RTX 4090 24576\nNVIDIA GeForce RTX 3060, 12288\n"
        with patch("subprocess.run", return_value=self._run_mock(stdout)):
            gpus = _from_nvidia_smi()
        assert len(gpus) == 1
        assert gpus[0].name == "NVIDIA GeForce RTX 3060"

    def test_vram_converted_from_mib_to_gb(self):
        """nvidia-smi reports MiB; we divide by 1024 → GB."""
        stdout = "NVIDIA GeForce RTX 4090, 24576\n"  # 24576 MiB = 24 GB
        with patch("subprocess.run", return_value=self._run_mock(stdout)):
            gpus = _from_nvidia_smi()
        assert gpus[0].vram_gb == 24.0


# ── AMD rocm-smi JSON parser ───────────────────────────────────────────────

class TestRocmSmiParser:
    def _run_mock(self, stdout: str, returncode: int = 0):
        mock = MagicMock()
        mock.returncode = returncode
        mock.stdout = stdout
        return mock

    def test_parse_rocm_json_output(self):
        stdout = """{
            "card0": {
                "Card Series": "AMD Radeon RX 7900 XTX",
                "VRAM Total Memory (B)": "25769803776"
            }
        }"""
        with patch("subprocess.run", return_value=self._run_mock(stdout)):
            gpus = _from_rocm_smi_json()
        assert len(gpus) == 1
        assert gpus[0].name == "AMD Radeon RX 7900 XTX"
        assert abs(gpus[0].vram_gb - 24.0) < 0.2
        assert gpus[0].backend == "ROCm"

    def test_invalid_json_returns_empty(self):
        with patch("subprocess.run", return_value=self._run_mock("not json")):
            gpus = _from_rocm_smi_json()
        assert gpus == []

    def test_file_not_found_returns_empty(self):
        with patch("subprocess.run", side_effect=FileNotFoundError):
            gpus = _from_rocm_smi_json()
        assert gpus == []


# ── Windows VRAM override table ────────────────────────────────────────────

class TestWindowsVramOverride:
    def test_rtx4090_override_when_wmi_capped(self):
        """WMI reports 4.0 GB for RTX 4090 (32-bit cap). Override must return 24."""
        result = _override_vram("NVIDIA GeForce RTX 4090", 4.0)
        assert result == 24.0

    def test_no_override_when_vram_correct(self):
        """If WMI reports > 4.3 GB, trust it directly."""
        result = _override_vram("NVIDIA GeForce RTX 4060", 8.0)
        assert result == 8.0

    def test_unknown_gpu_keeps_detected_value(self):
        result = _override_vram("SomeBrand GPU XYZ", 2.0)
        assert result == 2.0

    def test_rtx3090_override(self):
        result = _override_vram("NVIDIA GeForce RTX 3090", 3.9)
        assert result == 24.0

    def test_rx6900xt_override(self):
        result = _override_vram("AMD Radeon RX 6900 XT", 2.0)
        assert result == 16.0


# ── detect_windows_gpus — full integration with mocked PowerShell ──────────

class TestWindowsGpusIntegration:
    def _run_mock(self, stdout: str, returncode: int = 0):
        mock = MagicMock()
        mock.returncode = returncode
        mock.stdout = stdout
        return mock

    def test_single_gpu(self):
        import sys
        if sys.platform != "win32":
            pytest.skip("Windows-only test")
        stdout = '[{"Name": "NVIDIA GeForce RTX 4090", "AdapterRAM": 4294967295}]'
        with patch("subprocess.run", return_value=self._run_mock(stdout)):
            with patch("sys.platform", "win32"):
                gpus = detect_windows_gpus()
        assert len(gpus) == 1
        assert gpus[0].backend == "CUDA"

    def test_skips_basic_display_adapter(self):
        import sys
        if sys.platform != "win32":
            pytest.skip("Windows-only test")
        stdout = '[{"Name": "Microsoft Basic Display Adapter", "AdapterRAM": 0}]'
        with patch("subprocess.run", return_value=self._run_mock(stdout)):
            gpus = detect_windows_gpus()
        assert gpus == []
