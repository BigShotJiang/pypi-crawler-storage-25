"""QA tests for `tinillm run` — full coverage of all flags and edge cases.

The existing test_run_cmd.py mocks `tinillm.run.cmd.subprocess.run` which
never existed. The correct mock target is `tinillm.run.chat.run_chat`.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from tinillm.commands import run_cmd
from tinillm.hardware.types import CpuInfo, GpuInfo, SystemSpecs
from tinillm.models.database import MODELS


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def specs_high_end():
    return SystemSpecs(
        cpu=CpuInfo("Intel Core i9-13900K", 24, 32, 5800.0),
        total_ram_gb=32.0,
        free_ram_gb=24.0,
        gpus=[GpuInfo(name="NVIDIA GeForce RTX 4090", vram_gb=24.0, backend="CUDA")],
        os="Linux",
    )


@pytest.fixture
def specs_cpu_only():
    return SystemSpecs(
        cpu=CpuInfo("AMD Ryzen 7 5800X", 8, 16, 3800.0),
        total_ram_gb=16.0,
        free_ram_gb=10.0,
        gpus=[],
        os="Linux",
    )


@pytest.fixture
def specs_tiny():
    return SystemSpecs(
        cpu=CpuInfo("Intel Core i3", 2, 4, 2000.0),
        total_ram_gb=4.0,
        free_ram_gb=2.0,
        gpus=[],
        os="Linux",
    )


# ── Help ──────────────────────────────────────────────────────────────────────

class TestRunHelp:
    def test_run_help_exits_zero(self, runner):
        result = runner.invoke(run_cmd, ["--help"])
        assert result.exit_code == 0

    def test_run_help_shows_all_flags(self, runner):
        result = runner.invoke(run_cmd, ["--help"])
        for flag in ["--use-case", "--force", "--dry-run", "--no-color"]:
            assert flag in result.output, f"Missing flag: {flag}"

    def test_run_help_shows_model_tag_argument(self, runner):
        result = runner.invoke(run_cmd, ["--help"])
        assert "MODEL_TAG" in result.output

    def test_run_help_shows_use_case_choices(self, runner):
        result = runner.invoke(run_cmd, ["--help"])
        for choice in ["chat", "coding", "reasoning", "writing", "fast"]:
            assert choice in result.output


# ── Dry-run ───────────────────────────────────────────────────────────────────

class TestDryRun:
    def test_dry_run_exits_zero(self, runner, specs_high_end):
        with patch("tinillm.run.cmd.detect", return_value=specs_high_end):
            result = runner.invoke(run_cmd, ["llama3.1:8b", "--dry-run"])
        assert result.exit_code == 0

    def test_dry_run_does_not_launch_chat(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.chat.run_chat") as mock_chat,
        ):
            runner.invoke(run_cmd, ["llama3.1:8b", "--dry-run"])
        mock_chat.assert_not_called()

    def test_dry_run_prints_description(self, runner, specs_high_end):
        with patch("tinillm.run.cmd.detect", return_value=specs_high_end):
            result = runner.invoke(run_cmd, ["llama3.1:8b", "--dry-run"])
        assert "llama3.1:8b" in result.output or "dry" in result.output.lower()

    def test_dry_run_unknown_model_does_not_crash(self, runner, specs_high_end):
        with patch("tinillm.run.cmd.detect", return_value=specs_high_end):
            result = runner.invoke(run_cmd, ["my-custom-model:latest", "--dry-run"])
        assert result.exit_code == 0

    def test_dry_run_skips_ollama_check(self, runner, specs_high_end):
        """--dry-run must not contact Ollama at all."""
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama") as mock_check,
        ):
            runner.invoke(run_cmd, ["llama3.1:8b", "--dry-run"])
        mock_check.assert_not_called()


# ── Explicit model tag ────────────────────────────────────────────────────────

class TestExplicitTag:
    def test_known_tag_launches_chat(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat") as mock_chat,
        ):
            result = runner.invoke(run_cmd, ["llama3.1:8b"])
        mock_chat.assert_called_once()
        assert result.exit_code == 0

    def test_known_tag_passes_correct_tag_to_chat(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat") as mock_chat,
        ):
            runner.invoke(run_cmd, ["llama3.1:8b"])
        called_tag = mock_chat.call_args[0][0]
        assert called_tag == "llama3.1:8b"

    def test_unknown_tag_prints_note(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat"),
        ):
            result = runner.invoke(run_cmd, ["unknown-model:v99"])
        assert "not in tinillm" in result.output.lower() or "database" in result.output.lower()

    def test_unknown_tag_still_launches(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat") as mock_chat,
        ):
            result = runner.invoke(run_cmd, ["unknown-model:v99"])
        mock_chat.assert_called_once()
        assert result.exit_code == 0

    def test_no_warning_for_good_fit(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat"),
        ):
            result = runner.invoke(run_cmd, ["llama3.2:3b"])
        assert "Warning" not in result.output
        assert "Error" not in result.output


# ── TooTight model ────────────────────────────────────────────────────────────

class TestTooTight:
    def test_too_tight_exits_nonzero(self, runner, specs_tiny):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_tiny),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat") as mock_chat,
        ):
            result = runner.invoke(run_cmd, ["llama3.1:70b"])
        assert result.exit_code != 0
        mock_chat.assert_not_called()

    def test_too_tight_prints_error(self, runner, specs_tiny):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_tiny),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat"),
        ):
            result = runner.invoke(run_cmd, ["llama3.1:70b"])
        assert "Error" in result.output or "requires" in result.output.lower()

    def test_force_bypasses_too_tight(self, runner, specs_tiny):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_tiny),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat") as mock_chat,
        ):
            result = runner.invoke(run_cmd, ["llama3.1:70b", "--force"])
        mock_chat.assert_called_once()

    def test_marginal_shows_warning_but_proceeds(self, runner, specs_cpu_only):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_cpu_only),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat") as mock_chat,
        ):
            # Pick a model known to be Marginal on 10 GB free RAM CPU
            result = runner.invoke(run_cmd, ["llama3.1:8b"])
        # Should proceed (exit 0) with a warning or proceed without one
        # (fit level depends on actual hardware analysis — just verify no crash)
        assert result.exit_code in (0, 1)


# ── Ollama not running ────────────────────────────────────────────────────────

class TestOllamaNotRunning:
    def test_ollama_down_exits_nonzero(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama", side_effect=SystemExit(1)),
        ):
            result = runner.invoke(run_cmd, ["llama3.1:8b"])
        assert result.exit_code != 0

    def test_ollama_down_message_mentions_serve(self, runner, specs_high_end):
        """Real _check_ollama prints hint — test using the real function."""
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("ollama.list", side_effect=Exception("connection refused")),
        ):
            result = runner.invoke(run_cmd, ["llama3.1:8b"])
        assert "ollama serve" in result.output or result.exit_code != 0


# ── Interactive picker ────────────────────────────────────────────────────────

class TestInteractivePicker:
    def test_no_arg_shows_picker_table(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat"),
        ):
            result = runner.invoke(run_cmd, [], input="q\n")
        assert "Model" in result.output
        assert "Fit" in result.output

    def test_quit_exits_zero(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat"),
        ):
            result = runner.invoke(run_cmd, [], input="q\n")
        assert result.exit_code == 0

    def test_valid_selection_launches_model(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat") as mock_chat,
        ):
            result = runner.invoke(run_cmd, [], input="1\n")
        mock_chat.assert_called_once()
        assert result.exit_code == 0

    def test_invalid_input_reprompts(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat"),
        ):
            result = runner.invoke(run_cmd, [], input="abc\nq\n")
        assert "number" in result.output.lower() or "enter" in result.output.lower()

    def test_out_of_range_input_reprompts(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat"),
        ):
            result = runner.invoke(run_cmd, [], input="9999\nq\n")
        assert result.exit_code == 0

    def test_picker_hardware_line_shown(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat"),
        ):
            result = runner.invoke(run_cmd, [], input="q\n")
        assert "Hardware" in result.output or "GB" in result.output


# ── --use-case flag ───────────────────────────────────────────────────────────

class TestUseCaseFlag:
    @pytest.mark.parametrize("use_case", ["chat", "coding", "reasoning", "writing", "fast"])
    def test_valid_use_case_exits_zero(self, runner, specs_high_end, use_case):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat"),
        ):
            result = runner.invoke(run_cmd, ["--use-case", use_case], input="q\n")
        assert result.exit_code == 0, f"Failed for --use-case {use_case}: {result.output}"

    def test_invalid_use_case_exits_nonzero(self, runner):
        result = runner.invoke(run_cmd, ["--use-case", "gaming"])
        assert result.exit_code != 0

    def test_coding_use_case_shows_table(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat"),
        ):
            result = runner.invoke(run_cmd, ["--use-case", "coding"], input="q\n")
        assert "Model" in result.output


# ── --no-color flag ───────────────────────────────────────────────────────────

class TestNoColorFlag:
    def test_no_color_dry_run_no_ansi(self, runner, specs_high_end):
        with patch("tinillm.run.cmd.detect", return_value=specs_high_end):
            result = runner.invoke(run_cmd, ["llama3.1:8b", "--dry-run", "--no-color"])
        assert "\x1b[" not in result.output

    def test_no_color_picker_no_ansi(self, runner, specs_high_end):
        with (
            patch("tinillm.run.cmd.detect", return_value=specs_high_end),
            patch("tinillm.run.cmd._check_ollama"),
            patch("tinillm.run.chat.run_chat"),
        ):
            result = runner.invoke(run_cmd, ["--no-color"], input="q\n")
        assert "\x1b[" not in result.output


# ── No runnable models ────────────────────────────────────────────────────────

class TestNoRunnableModels:
    def test_all_toottight_exits_nonzero(self, runner):
        specs_minimal = SystemSpecs(
            cpu=CpuInfo("Tiny CPU", 1, 2, 800.0),
            total_ram_gb=1.0,
            free_ram_gb=0.3,
            gpus=[],
            os="Linux",
        )
        with patch("tinillm.run.cmd.detect", return_value=specs_minimal):
            result = runner.invoke(run_cmd, [])
        assert result.exit_code != 0

    def test_all_toottight_shows_message(self, runner):
        specs_minimal = SystemSpecs(
            cpu=CpuInfo("Tiny CPU", 1, 2, 800.0),
            total_ram_gb=1.0,
            free_ram_gb=0.3,
            gpus=[],
            os="Linux",
        )
        with patch("tinillm.run.cmd.detect", return_value=specs_minimal):
            result = runner.invoke(run_cmd, [])
        assert "no models" in result.output.lower() or "upgrade" in result.output.lower()
