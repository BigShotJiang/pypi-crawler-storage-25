"""Unit tests for the glob-to-regex translator that powers tier-2 matching."""
from __future__ import annotations

import pytest

from tinillm.memory.recall import _glob_to_regex


@pytest.mark.parametrize(
    "pattern,path,expected",
    [
        ("**/pyproject.toml", "pyproject.toml", True),
        ("**/pyproject.toml", "src/pyproject.toml", True),
        ("**/pyproject.toml", "a/b/c/pyproject.toml", True),
        ("**/pyproject.toml", "pyproject.toml.bak", False),
        ("src/**", "src/foo.py", True),
        ("src/**", "src/a/b/c.py", True),
        ("src/**", "lib/foo.py", False),
        ("*.py", "foo.py", True),
        ("*.py", "src/foo.py", False),   # single * does not span /
        ("?.py", "a.py", True),
        ("?.py", "ab.py", False),
        ("a.b", "a.b", True),
        ("a.b", "axb", False),           # . is literal
        ("[ab].py", "a.py", True),
        ("[ab].py", "c.py", False),
    ],
)
def test_glob_to_regex(pattern, path, expected):
    rx = _glob_to_regex(pattern)
    assert bool(rx.match(path)) is expected, (
        f"pattern={pattern!r} path={path!r} expected {expected}"
    )
