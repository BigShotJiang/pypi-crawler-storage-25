"""Tests for the background writer — ingest, flush, dedupe."""
from __future__ import annotations

from pathlib import Path

from tinillm.memory import paths as mp
from tinillm.memory.bootstrap import init_if_missing
from tinillm.memory.writer import flush, ingest, ingest_suggest_choice


def test_ingest_extracts_user_role(tmp_memory):
    init_if_missing()
    ingest("Hi — I'm a data scientist.", "Noted.", cwd=Path.cwd())
    flush(timeout=3.0)
    content = mp.USER_MD.read_text(encoding="utf-8")
    assert "data scientist" in content.lower()


def test_ingest_extracts_feedback_with_why(tmp_memory):
    init_if_missing()
    ingest(
        "don't use subprocess shell=True because it's injection-prone",
        "ok",
        cwd=Path.cwd(),
    )
    flush(timeout=3.0)
    content = mp.FEEDBACK_MD.read_text(encoding="utf-8")
    assert "subprocess" in content.lower()
    assert "why" in content.lower()


def test_ingest_dedupes_repeat(tmp_memory):
    init_if_missing()
    ingest("I am a data scientist.", "", cwd=Path.cwd())
    flush(timeout=3.0)
    ingest("I am a data scientist.", "", cwd=Path.cwd())
    flush(timeout=3.0)
    content = mp.USER_MD.read_text(encoding="utf-8")
    # Only one line matching "role: data scientist"
    occurrences = content.lower().count("role: data scientist")
    assert occurrences == 1


def test_ingest_disabled(monkeypatch, tmp_memory):
    monkeypatch.setenv("TINILLM_MEMORY", "0")
    init_if_missing()
    ingest("I am a data scientist.", "", cwd=Path.cwd())
    flush(timeout=1.0)
    # user.md is just the stub — nothing appended.
    assert "data scientist" not in mp.USER_MD.read_text(encoding="utf-8").lower()


def test_ingest_suggest_choice_writes_project_file(tmp_memory):
    init_if_missing()
    ingest_suggest_choice("coding", "qwen2.5-coder:7b")
    target = mp.project_dir() / "project.md"
    text = target.read_text(encoding="utf-8")
    assert "qwen2.5-coder:7b" in text
    assert "coding" in text
    # Dedupe — don't rewrite on a repeat call.
    ingest_suggest_choice("coding", "qwen2.5-coder:7b")
    text2 = target.read_text(encoding="utf-8")
    assert text == text2


def test_ingest_empty_is_noop(tmp_memory):
    init_if_missing()
    original = mp.USER_MD.read_text(encoding="utf-8")
    ingest("", "", cwd=Path.cwd())
    flush(timeout=0.5)
    assert mp.USER_MD.read_text(encoding="utf-8") == original
