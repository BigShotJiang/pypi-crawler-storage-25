"""Tests for tinillm.memory.paths — project keying, opt-out, ensure_dirs."""
from __future__ import annotations

from pathlib import Path

import pytest

from tinillm.memory import paths as mp


def test_project_key_is_stable(tmp_path):
    key1 = mp.project_key(tmp_path)
    key2 = mp.project_key(tmp_path)
    assert key1 == key2
    assert len(key1) == 12


def test_project_key_differs_across_dirs(tmp_path):
    a = tmp_path / "a"
    b = tmp_path / "b"
    a.mkdir()
    b.mkdir()
    assert mp.project_key(a) != mp.project_key(b)


def test_ensure_dirs_creates_skeleton(tmp_memory):
    mp.ensure_dirs()
    assert mp.MEMORY_ROOT.exists()
    assert (mp.MEMORY_ROOT / "rules").is_dir()
    assert (mp.MEMORY_ROOT / "lore").is_dir()
    assert (mp.MEMORY_ROOT / "projects").is_dir()


def test_ensure_dirs_is_idempotent(tmp_memory):
    mp.ensure_dirs()
    mp.ensure_dirs()
    assert tmp_memory.exists()


def test_memory_disabled_env(monkeypatch, tmp_memory):
    monkeypatch.setenv("TINILLM_MEMORY", "0")
    assert mp.memory_disabled() is True
    monkeypatch.setenv("TINILLM_MEMORY", "off")
    assert mp.memory_disabled() is True
    monkeypatch.setenv("TINILLM_MEMORY", "1")
    assert mp.memory_disabled() is False


def test_memory_disabled_sentinel(tmp_memory):
    tmp_memory.mkdir(parents=True, exist_ok=True)
    (tmp_memory / "DISABLED").touch()
    assert mp.memory_disabled() is True


def test_project_dir_under_projects_root(tmp_memory, tmp_path):
    pdir = mp.project_dir(tmp_path)
    assert pdir.parent == tmp_memory / "projects"
