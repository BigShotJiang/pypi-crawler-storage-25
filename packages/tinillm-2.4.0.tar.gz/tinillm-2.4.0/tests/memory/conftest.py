"""Shared fixtures for memory tests — redirects the store to a tmp dir."""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

_PATH_ATTRS = (
    "MEMORY_ROOT",
    "GLOBAL_MEMORY_MD",
    "USER_MD",
    "FEEDBACK_MD",
    "RULES_DIR",
    "LORE_DIR",
    "PROJECTS_DIR",
    "SESSIONS_DB",
    "DISABLED_SENTINEL",
)

_CONSUMER_MODULES = (
    "tinillm.memory",
    "tinillm.memory.bootstrap",
    "tinillm.memory.recall",
    "tinillm.memory.writer",
    "tinillm.memory.commands",
)


@pytest.fixture
def tmp_memory(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect every memory path constant to a disposable tmp dir.

    Every module that imported the constants at module load time is also
    patched so they see the new values. Also removes any ``TINILLM_MEMORY``
    env override so tests run as if memory were enabled.
    """
    root = tmp_path / "tinillm_mem"
    monkeypatch.delenv("TINILLM_MEMORY", raising=False)

    from tinillm.memory import paths as _paths

    new_vals = {
        "MEMORY_ROOT":       root,
        "GLOBAL_MEMORY_MD":  root / "MEMORY.md",
        "USER_MD":           root / "user.md",
        "FEEDBACK_MD":       root / "feedback.md",
        "RULES_DIR":         root / "rules",
        "LORE_DIR":          root / "lore",
        "PROJECTS_DIR":      root / "projects",
        "SESSIONS_DB":       root / "sessions.sqlite",
        "DISABLED_SENTINEL": root / "DISABLED",
    }

    for attr, value in new_vals.items():
        monkeypatch.setattr(_paths, attr, value, raising=False)

    for mod_name in _CONSUMER_MODULES:
        mod = sys.modules.get(mod_name)
        if mod is None:
            continue
        for attr, value in new_vals.items():
            if hasattr(mod, attr):
                monkeypatch.setattr(mod, attr, value, raising=False)

    return root
