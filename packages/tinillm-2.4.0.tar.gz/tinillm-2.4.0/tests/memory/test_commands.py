"""Tests for /memory, /remember, /forget via Click's CliRunner."""
from __future__ import annotations

from click.testing import CliRunner

from tinillm.commands import forget_cmd, memory_cmd, remember_cmd
from tinillm.memory import paths as mp


def test_memory_show_empty(tmp_memory):
    runner = CliRunner()
    result = runner.invoke(memory_cmd, ["show"])
    assert result.exit_code == 0
    assert "tinillm memory" in result.output


def test_memory_path_prints_root(tmp_memory):
    runner = CliRunner()
    result = runner.invoke(memory_cmd, ["path"])
    assert result.exit_code == 0
    assert str(tmp_memory) in result.output


def test_remember_explicit_user(tmp_memory):
    runner = CliRunner()
    result = runner.invoke(
        remember_cmd, ["I use fish shell", "--as", "user"]
    )
    assert result.exit_code == 0
    assert "Remembered" in result.output
    assert "fish shell" in mp.USER_MD.read_text(encoding="utf-8")


def test_remember_auto_classifies_feedback(tmp_memory):
    runner = CliRunner()
    result = runner.invoke(remember_cmd, ["never commit .env files"])
    assert result.exit_code == 0
    assert ".env" in mp.FEEDBACK_MD.read_text(encoding="utf-8")


def test_forget_removes_line(tmp_memory):
    mp.USER_MD.parent.mkdir(parents=True, exist_ok=True)
    mp.USER_MD.write_text(
        "# user\n- role: engineer\n- uses: fish shell\n",
        encoding="utf-8",
    )
    runner = CliRunner()
    result = runner.invoke(forget_cmd, ["fish", "--yes"])
    assert result.exit_code == 0
    content = mp.USER_MD.read_text(encoding="utf-8")
    assert "fish" not in content
    assert "role: engineer" in content


def test_forget_no_match(tmp_memory):
    runner = CliRunner()
    result = runner.invoke(forget_cmd, ["nonexistent-thing", "--yes"])
    assert result.exit_code == 0
    assert "No matches" in result.output


def test_memory_clear_project_requires_confirm(tmp_memory):
    runner = CliRunner()
    # Without --yes, the confirm prompt gets 'n' and nothing is deleted.
    result = runner.invoke(
        memory_cmd, ["clear", "--project"], input="n\n"
    )
    assert result.exit_code == 0
    assert "Cancelled" in result.output or "does not exist" in result.output


def test_memory_disabled_via_env(monkeypatch, tmp_memory):
    monkeypatch.setenv("TINILLM_MEMORY", "0")
    runner = CliRunner()
    result = runner.invoke(memory_cmd, ["show"])
    assert result.exit_code == 0
    assert "disabled" in result.output.lower()
