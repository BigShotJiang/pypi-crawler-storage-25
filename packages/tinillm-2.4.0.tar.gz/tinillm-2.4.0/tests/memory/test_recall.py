"""Tests for assemble_memory_block — tier resolution + budget enforcement."""
from __future__ import annotations

from pathlib import Path

from tinillm.memory import paths as mp
from tinillm.memory.bootstrap import init_if_missing
from tinillm.memory.recall import (
    MAX_BLOCK_BYTES,
    assemble_memory_block,
    build_recall,
)


def test_empty_when_root_missing(tmp_memory):
    # tmp_memory exists as a Path reference but dir not created yet.
    block = build_recall(cwd=Path.cwd(), recent_turns=None)
    assert block.is_empty()


def test_tier1_picks_up_user_md(tmp_memory):
    init_if_missing()
    mp.USER_MD.write_text(
        "# User profile\n\n- role: engineer\n- uses: polars\n",
        encoding="utf-8",
    )
    text = assemble_memory_block(cwd=Path.cwd(), recent_turns=[])
    assert "User" in text
    assert "polars" in text


def test_tier1_ignores_stub_placeholder(tmp_memory):
    """A file with only the italic placeholder should count as empty."""
    init_if_missing()
    text = assemble_memory_block(cwd=Path.cwd(), recent_turns=[])
    # The bootstrap stubs contain only comments + italic placeholder, so
    # the block should be empty at this stage.
    assert text == ""


def test_tier3_keyword_triggers(tmp_memory):
    init_if_missing()
    mp.LORE_DIR.mkdir(parents=True, exist_ok=True)
    (mp.LORE_DIR / "docker.md").write_text(
        '---\nname: docker-note\nkeys: ["docker", "compose"]\n---\n'
        "User avoids Docker on this project.\n",
        encoding="utf-8",
    )

    recent = [{"role": "user", "content": "how do I deploy with docker?"}]
    text = assemble_memory_block(cwd=Path.cwd(), recent_turns=recent)
    assert "docker-note" in text

    # Without keyword match, the lore entry must not be injected.
    text2 = assemble_memory_block(
        cwd=Path.cwd(),
        recent_turns=[{"role": "user", "content": "unrelated question"}],
    )
    assert "docker-note" not in text2


def test_tier2_rule_without_glob_is_project_wide(tmp_memory):
    init_if_missing()
    mp.RULES_DIR.mkdir(parents=True, exist_ok=True)
    (mp.RULES_DIR / "style.md").write_text(
        "---\nname: code-style\ndescription: follow PEP 8\n---\n"
        "Prefer explicit imports.\n",
        encoding="utf-8",
    )
    text = assemble_memory_block(cwd=Path.cwd(), recent_turns=[])
    assert "code-style" in text


def test_tier2_globstar_matches_nested_file(tmp_memory, tmp_path):
    """`**/pyproject.toml` must fire for a nested file — fnmatch alone fails this."""
    init_if_missing()
    mp.RULES_DIR.mkdir(parents=True, exist_ok=True)
    (mp.RULES_DIR / "py.md").write_text(
        '---\nname: py-rule\nglobs: ["**/pyproject.toml"]\n---\n'
        "Use hatchling.\n",
        encoding="utf-8",
    )
    repo = tmp_path / "fake_repo"
    (repo / "src").mkdir(parents=True)
    (repo / "pyproject.toml").write_text("[project]\n")
    text = assemble_memory_block(cwd=repo, recent_turns=[])
    assert "py-rule" in text


def test_tier2_globstar_matches_deep_path(tmp_memory, tmp_path):
    init_if_missing()
    mp.RULES_DIR.mkdir(parents=True, exist_ok=True)
    (mp.RULES_DIR / "src.md").write_text(
        '---\nname: src-rule\nglobs: ["src/**"]\n---\n'
        "Keep src layout.\n",
        encoding="utf-8",
    )
    repo = tmp_path / "deep_repo"
    (repo / "src" / "pkg").mkdir(parents=True)
    (repo / "src" / "pkg" / "mod.py").write_text("x = 1\n")
    text = assemble_memory_block(cwd=repo, recent_turns=[])
    assert "src-rule" in text


def test_tier2_glob_does_not_match_other_dir(tmp_memory, tmp_path):
    init_if_missing()
    mp.RULES_DIR.mkdir(parents=True, exist_ok=True)
    (mp.RULES_DIR / "py.md").write_text(
        '---\nname: py-rule\nglobs: ["**/pyproject.toml"]\n---\nfoo\n',
        encoding="utf-8",
    )
    empty = tmp_path / "no_pyproj"
    empty.mkdir()
    (empty / "README.md").write_text("# hi\n")
    text = assemble_memory_block(cwd=empty, recent_turns=[])
    assert "py-rule" not in text


def test_budget_truncation(tmp_memory):
    init_if_missing()
    mp.LORE_DIR.mkdir(parents=True, exist_ok=True)
    # Build lots of matching lore entries with large bodies to overflow budget.
    big_body = "x " * 4000  # ~8 KB of content alone
    for i in range(5):
        (mp.LORE_DIR / f"lore{i}.md").write_text(
            f'---\nname: lore-{i}\nkeys: ["foo"]\n---\n{big_body}\n',
            encoding="utf-8",
        )
    recent = [{"role": "user", "content": "foo " * 5}]
    block = build_recall(cwd=Path.cwd(), recent_turns=recent)
    # Tier-3 list must drop entries until under budget.
    assert len(block.to_text().encode("utf-8")) <= MAX_BLOCK_BYTES
    # We should still have at least the truncation marker or some tier-3.
    # In practice truncated flag fires.
    assert block.truncated or not block.tier3_entries


def test_disabled_returns_empty(monkeypatch, tmp_memory):
    monkeypatch.setenv("TINILLM_MEMORY", "0")
    init_if_missing()
    mp.USER_MD.write_text("# user\n- role: engineer\n", encoding="utf-8")
    assert assemble_memory_block(cwd=Path.cwd(), recent_turns=[]) == ""
