"""Tests for the minimal frontmatter parser in tinillm.memory.store."""
from __future__ import annotations

from tinillm.memory.store import (
    MemoryEntry,
    atomic_write,
    emit_frontmatter,
    parse_frontmatter,
    read_entry,
)


def test_parse_basic_fields():
    text = """---
name: my-rule
description: one line
type: feedback
---
body text
"""
    fields, body = parse_frontmatter(text)
    assert fields["name"] == "my-rule"
    assert fields["description"] == "one line"
    assert fields["type"] == "feedback"
    assert body.strip() == "body text"


def test_parse_list_field():
    text = """---
name: r
globs: ["**/*.py", "src/**"]
keys: ["pytest", "test"]
---
ok
"""
    fields, _ = parse_frontmatter(text)
    assert fields["globs"] == ["**/*.py", "src/**"]
    assert fields["keys"] == ["pytest", "test"]


def test_parse_no_frontmatter():
    text = "no delimiter here\nsecond line"
    fields, body = parse_frontmatter(text)
    assert fields == {}
    assert body == text


def test_parse_unterminated_frontmatter():
    text = "---\nname: r\n\nbody without closing delim"
    fields, body = parse_frontmatter(text)
    assert fields == {}
    assert body == text


def test_parse_quoted_scalar():
    text = '---\nname: "has: colon"\n---\nok\n'
    fields, _ = parse_frontmatter(text)
    assert fields["name"] == "has: colon"


def test_emit_roundtrip():
    fields = {"name": "r", "description": "d", "globs": ["**/*.py"]}
    body = "rule body"
    out = emit_frontmatter(fields, body)
    fields2, body2 = parse_frontmatter(out)
    assert fields2 == fields
    assert body2.strip() == body


def test_emit_without_fields():
    out = emit_frontmatter({}, "just body")
    assert out == "just body\n"


def test_read_entry_missing_file(tmp_path):
    assert read_entry(tmp_path / "nope.md") is None


def test_read_entry_via_atomic_write(tmp_path):
    path = tmp_path / "rule.md"
    atomic_write(path, '---\nname: r\nkeys: ["a", "b"]\n---\nbody\n')
    e = read_entry(path)
    assert isinstance(e, MemoryEntry)
    assert e.name == "r"
    assert e.keys == ["a", "b"]
    assert "body" in e.body
