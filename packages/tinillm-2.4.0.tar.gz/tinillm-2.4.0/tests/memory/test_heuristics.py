"""Tests for the regex extraction heuristics."""
from __future__ import annotations

from tinillm.memory.heuristics import extract


def test_extracts_user_role():
    out = extract("I'm a data scientist working on an internal tool.")
    kinds = [e.category for e in out]
    assert "user" in kinds
    assert any("data scientist" in e.content.lower() for e in out)


def test_extracts_user_stack():
    out = extract("i am mostly writing Rust these days.")
    assert any(
        e.category == "user" and "rust" in e.content.lower() for e in out
    )


def test_extracts_user_preference():
    out = extract("I prefer polars over pandas for everything.")
    assert any(
        e.category == "user" and "polars" in e.content.lower() for e in out
    )


def test_extracts_dont_rule_with_why():
    out = extract(
        "please don't use subprocess shell=True because it opens injection holes."
    )
    feedback = [e for e in out if e.category == "feedback"]
    assert feedback, f"expected feedback extraction, got {out}"
    body = feedback[0].content
    assert "subprocess" in body.lower()
    assert "Why:" in body


def test_extracts_always_rule():
    out = extract("always run pytest before pushing.")
    feedback = [e for e in out if e.category == "feedback"]
    assert feedback
    assert "pytest" in feedback[0].content.lower()


def test_empty_text_returns_no_extractions():
    assert extract("") == []
    assert extract("   \n\n") == []


def test_benign_text_returns_no_extractions():
    # Pure question/answer with none of the trigger patterns.
    out = extract("What time is it in Tokyo?")
    assert out == []


def test_dedupe_same_signal_twice():
    text = "I'm a data scientist. Also, I am a data scientist on the ML team."
    out = extract(text)
    roles = [e for e in out if "role:" in e.content.lower()]
    # Both sentences match but only one extraction survives dedupe.
    assert len(roles) == 1
