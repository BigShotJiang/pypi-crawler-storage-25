"""Tests for init_if_missing — first-run skeleton creation."""
from __future__ import annotations

from tinillm.memory import paths as mp
from tinillm.memory.bootstrap import init_if_missing


def test_creates_skeleton_on_first_run(tmp_memory):
    created = init_if_missing()
    assert created is True
    assert mp.GLOBAL_MEMORY_MD.exists()
    assert mp.USER_MD.exists()
    assert mp.FEEDBACK_MD.exists()
    assert (mp.project_dir() / "MEMORY.md").exists()
    assert (mp.project_dir() / "project.md").exists()


def test_idempotent_second_run(tmp_memory):
    init_if_missing()
    mp.USER_MD.write_text("# User\n\n- custom line\n", encoding="utf-8")
    created = init_if_missing()
    assert created is False
    assert "custom line" in mp.USER_MD.read_text(encoding="utf-8")


def test_global_memory_md_has_header(tmp_memory):
    init_if_missing()
    assert "Memory Index" in mp.GLOBAL_MEMORY_MD.read_text(encoding="utf-8")
