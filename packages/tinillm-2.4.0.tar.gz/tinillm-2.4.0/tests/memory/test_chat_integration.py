"""Integration test — verify /run chat injects the memory block into ollama.chat().

Stubs the ollama module so the test runs without a live server.
"""
from __future__ import annotations

import sys
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from tinillm.memory import paths as mp
from tinillm.memory.bootstrap import init_if_missing


def _fake_response(content: str):
    msg = SimpleNamespace(role="assistant", content=content, tool_calls=None)
    return SimpleNamespace(message=msg)


def test_recall_block_injected_as_system_message(tmp_memory, monkeypatch):
    """When user.md has content, run_chat should prepend a memory system msg."""
    init_if_missing()
    mp.USER_MD.write_text(
        "# User profile\n\n- role: data scientist\n- uses: polars\n",
        encoding="utf-8",
    )

    captured: dict = {}

    def fake_chat(**kwargs):
        captured.setdefault("calls", []).append(kwargs)
        return _fake_response("ok")

    # Fake ollama module — used both in chat.py and in _ensure_model_ready.
    fake_ollama = MagicMock()
    fake_ollama.chat = fake_chat
    fake_ollama.list.return_value = SimpleNamespace(
        models=[SimpleNamespace(model="llama3:8b")]
    )
    # ResponseError class needed for except clause.
    fake_ollama.ResponseError = type("ResponseError", (Exception,), {})
    monkeypatch.setitem(sys.modules, "ollama", fake_ollama)

    # Inputs: one user turn, then EOF.
    inputs = iter(["hello", ""])

    def fake_prompt(*args, **kwargs):
        try:
            return next(inputs)
        except StopIteration:
            import click
            raise click.exceptions.Abort()

    from rich.console import Console
    console = Console(file=open("/dev/null", "w"))

    with patch("click.prompt", side_effect=fake_prompt):
        from tinillm.run.chat import run_chat
        run_chat("llama3:8b", console)

    # First ollama.chat call must include our memory system message.
    assert captured.get("calls"), "ollama.chat was not invoked"
    first = captured["calls"][0]
    msgs = first["messages"]
    assert msgs[0]["role"] == "system"
    assert "tinillm memory" in msgs[0]["content"]
    assert "polars" in msgs[0]["content"]
    # User message follows the system one.
    assert msgs[1]["role"] == "user"
    assert msgs[1]["content"] == "hello"
