"""Tests for the model database — integrity, completeness, and helpers."""

import pytest
from tinillm.models.database import MODELS, RealModel, size_bracket


class TestDatabaseIntegrity:
    def test_database_is_not_empty(self):
        assert len(MODELS) > 0

    def test_all_entries_are_real_model_instances(self):
        for m in MODELS:
            assert isinstance(m, RealModel), f"{m} is not a RealModel"

    def test_all_names_are_unique(self):
        names = [m.name for m in MODELS]
        assert len(names) == len(set(names)), "Duplicate model names in database"

    def test_all_ollama_tags_are_unique(self):
        tags = [m.ollama_tag for m in MODELS]
        assert len(tags) == len(set(tags)), "Duplicate ollama_tag entries"

    def test_no_empty_display_names(self):
        for m in MODELS:
            assert m.display_name.strip(), f"Empty display_name for {m.name}"

    def test_no_empty_providers(self):
        for m in MODELS:
            assert m.provider.strip(), f"Empty provider for {m.name}"

    def test_no_empty_descriptions(self):
        for m in MODELS:
            assert m.description.strip(), f"Empty description for {m.name}"

    def test_all_params_b_positive(self):
        for m in MODELS:
            assert m.params_b > 0, f"{m.name} has non-positive params_b"

    def test_all_layers_positive(self):
        for m in MODELS:
            assert m.num_layers > 0, f"{m.name} has zero num_layers"

    def test_all_context_lengths_positive(self):
        for m in MODELS:
            assert m.context_length > 0, f"{m.name} has zero context_length"

    def test_all_kv_heads_positive(self):
        for m in MODELS:
            assert m.num_kv_heads > 0

    def test_all_head_dims_positive(self):
        for m in MODELS:
            assert m.head_dim > 0


class TestDatabaseCoverage:
    def _names(self):
        return [m.display_name.lower() for m in MODELS]

    def _tags(self):
        return [m.ollama_tag.lower() for m in MODELS]

    def test_includes_llama_models(self):
        assert any("llama" in n for n in self._names())

    def test_includes_mistral(self):
        assert any("mistral" in n for n in self._names())

    def test_includes_qwen(self):
        assert any("qwen" in n for n in self._names())

    def test_includes_gemma(self):
        assert any("gemma" in n for n in self._names())

    def test_includes_phi(self):
        assert any("phi" in n for n in self._names())

    def test_includes_deepseek(self):
        assert any("deepseek" in n for n in self._names())

    def test_includes_codellama(self):
        assert any("codellama" in t for t in self._tags())

    def test_has_at_least_30_models(self):
        assert len(MODELS) >= 30, f"Only {len(MODELS)} models — expected ≥30"

    def test_has_sub_1b_model(self):
        assert any(m.params_b < 1.0 for m in MODELS), "No sub-1B model in database"

    def test_has_large_model_over_70b(self):
        assert any(m.params_b >= 70.0 for m in MODELS)


class TestSizeBracket:
    def test_sub_1b_returns_1b_bucket(self):
        assert size_bracket(0.135) == "1b"
        assert size_bracket(0.5) == "1b"
        assert size_bracket(0.9) == "1b"

    def test_1b_to_4b_returns_3b(self):
        assert size_bracket(1.0) == "3b"
        assert size_bracket(1.7) == "3b"
        assert size_bracket(3.0) == "3b"
        assert size_bracket(3.8) == "3b"

    def test_4b_to_10b_returns_7b(self):
        assert size_bracket(4.0) == "7b"
        assert size_bracket(7.0) == "7b"
        assert size_bracket(8.0) == "7b"

    def test_10b_to_20b_returns_13b(self):
        assert size_bracket(12.0) == "13b"
        assert size_bracket(14.0) == "13b"

    def test_20b_to_50b_returns_34b(self):
        assert size_bracket(32.0) == "34b"
        assert size_bracket(35.0) == "34b"

    def test_50b_and_above_returns_70b(self):
        assert size_bracket(70.0) == "70b"
        assert size_bracket(104.0) == "70b"
