"""CLI tests for `tinillm recommend` — user-facing behaviour and all flags."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tinillm.commands import suggest_cmd
from tinillm.hardware.types import CpuInfo, GpuInfo, SystemSpecs


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def specs_mid_range():
    """RTX 3060 12 GB — fits many 7B models at Perfect/Good."""
    return SystemSpecs(
        cpu=CpuInfo("Intel Core i9", 16, 32, 5000.0),
        total_ram_gb=16.0,
        free_ram_gb=12.0,
        gpus=[GpuInfo("NVIDIA GeForce RTX 3060", 12.0, "CUDA")],
        os="Linux",
    )


@pytest.fixture
def specs_cpu_only():
    return SystemSpecs(
        cpu=CpuInfo("AMD Ryzen 7", 8, 16, 3800.0),
        total_ram_gb=16.0,
        free_ram_gb=10.0,
        gpus=[],
        os="Linux",
    )


# ── Help text ──────────────────────────────────────────────────────────────

class TestRecommendHelp:
    def test_recommend_help_shows_all_flags(self, runner):
        result = runner.invoke(suggest_cmd, ["--help"])
        assert result.exit_code == 0
        for flag in ["--use-case", "--json", "--no-color"]:
            assert flag in result.output

    def test_recommend_help_shows_use_case_choices(self, runner):
        result = runner.invoke(suggest_cmd, ["--help"])
        for choice in ["chat", "coding", "reasoning", "writing", "fast"]:
            assert choice in result.output

    def test_recommend_help_shows_description(self, runner):
        result = runner.invoke(suggest_cmd, ["--help"])
        assert "recommend" in result.output.lower() or "model" in result.output.lower()


# ── Default output ─────────────────────────────────────────────────────────

class TestDefaultRecommend:
    def test_exits_zero(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, [])
        assert result.exit_code == 0, result.output

    def test_shows_header_panel(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, [])
        assert "tinillm recommend" in result.output

    def test_shows_use_case_general(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, [])
        assert "general" in result.output.lower()

    def test_shows_hardware_budget_gb(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, [])
        assert "GB" in result.output

    def test_shows_star_for_top_pick(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, [])
        assert "★" in result.output

    def test_shows_ollama_pull_command(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, [])
        assert "ollama pull" in result.output

    def test_shows_run_it_now_footer(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, [])
        assert "Run it now" in result.output


# ── --use-case flag ────────────────────────────────────────────────────────

class TestUseCaseFlag:
    @pytest.mark.parametrize("use_case", ["chat", "coding", "reasoning", "writing", "fast"])
    def test_valid_use_case_exits_zero(self, runner, use_case, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--use-case", use_case])
        assert result.exit_code == 0, f"--use-case {use_case} failed: {result.output}"

    @pytest.mark.parametrize("use_case", ["chat", "coding", "reasoning", "writing", "fast"])
    def test_use_case_label_appears_in_output(self, runner, use_case, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--use-case", use_case])
        assert use_case in result.output

    def test_invalid_use_case_exits_nonzero(self, runner):
        result = runner.invoke(suggest_cmd, ["--use-case", "gaming"])
        assert result.exit_code != 0

    def test_coding_recommends_a_coding_model(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--use-case", "coding"])
        assert result.exit_code == 0
        assert any(kw in result.output for kw in [
            "CodeLlama", "DeepSeek", "Qwen", "codellama", "deepseek", "qwen"
        ])

    def test_fast_recommends_small_model(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--use-case", "fast"])
        assert result.exit_code == 0
        assert any(kw in result.output for kw in [
            "SmolLM", "Gemma 3 1B", "Qwen 2.5 0", "smollm", "gemma3:1b", "qwen2.5:0"
        ])


# ── --json flag ────────────────────────────────────────────────────────────

class TestRecommendJsonFlag:
    def test_json_is_valid(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--json"])
        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert isinstance(payload, dict)

    def test_json_has_required_top_level_keys(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--json"])
        payload = json.loads(result.output)
        for key in ["use_case", "hardware", "top_pick", "recommendations"]:
            assert key in payload

    def test_json_use_case_is_none_without_flag(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--json"])
        assert json.loads(result.output)["use_case"] is None

    def test_json_use_case_set_with_flag(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--use-case", "coding", "--json"])
        assert json.loads(result.output)["use_case"] == "coding"

    def test_json_hardware_has_required_fields(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--json"])
        hw = json.loads(result.output)["hardware"]
        assert "budget_gb" in hw
        assert "runs_on_gpu" in hw
        assert isinstance(hw["budget_gb"], float)
        assert isinstance(hw["runs_on_gpu"], bool)

    def test_json_top_pick_has_model_fields(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--json"])
        top = json.loads(result.output)["top_pick"]
        assert top is not None
        for field in ["name", "display_name", "provider", "ollama_tag",
                      "fit_level", "best_quant", "mem_required_gb", "tokens_per_sec"]:
            assert field in top

    def test_json_recommendations_is_list(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--json"])
        recs = json.loads(result.output)["recommendations"]
        assert isinstance(recs, list)
        assert len(recs) >= 1

    def test_json_recommendations_at_most_3(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--json"])
        assert len(json.loads(result.output)["recommendations"]) <= 3

    def test_json_top_pick_matches_first_recommendation(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--json"])
        payload = json.loads(result.output)
        assert payload["top_pick"]["name"] == payload["recommendations"][0]["name"]

    def test_json_no_toottight_in_recommendations(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--json"])
        for r in json.loads(result.output)["recommendations"]:
            assert r["fit_level"] != "TooTight"

    def test_json_has_scoring_fields(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--use-case", "coding", "--json"])
        for r in json.loads(result.output)["recommendations"]:
            assert "fit_score" in r
            assert "affinity" in r
            assert "total_score" in r


# ── --no-color flag ────────────────────────────────────────────────────────

class TestNoColorFlag:
    def test_no_color_exits_zero(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--no-color"])
        assert result.exit_code == 0

    def test_no_color_still_shows_content(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--no-color"])
        assert "tinillm recommend" in result.output

    def test_no_color_has_no_ansi_codes(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--no-color"])
        assert "\x1b[" not in result.output


# ── CPU-only hardware ──────────────────────────────────────────────────────

class TestCpuOnlyHardware:
    def test_cpu_only_exits_zero(self, runner, specs_cpu_only):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_cpu_only):
            result = runner.invoke(suggest_cmd, [])
        assert result.exit_code == 0

    def test_cpu_only_shows_cpu_label(self, runner, specs_cpu_only):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_cpu_only):
            result = runner.invoke(suggest_cmd, [])
        assert "CPU" in result.output

    def test_cpu_only_json_runs_on_gpu_false(self, runner, specs_cpu_only):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_cpu_only):
            result = runner.invoke(suggest_cmd, ["--json"])
        assert json.loads(result.output)["hardware"]["runs_on_gpu"] is False


# ── No-fit edge case ───────────────────────────────────────────────────────

class TestNoFitHardware:
    @pytest.fixture
    def specs_tiny(self):
        return SystemSpecs(
            cpu=CpuInfo("Tiny CPU", 1, 2, 1000.0),
            total_ram_gb=1.0,
            free_ram_gb=0.5,
            gpus=[],
            os="Linux",
        )

    def test_extremely_low_ram_does_not_crash(self, runner, specs_tiny):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_tiny):
            result = runner.invoke(suggest_cmd, [])
        assert result.exit_code == 0

    def test_no_models_json_top_pick_is_none(self, runner, specs_tiny):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_tiny):
            result = runner.invoke(suggest_cmd, ["--json"])
        payload = json.loads(result.output)
        assert payload["top_pick"] is None
        assert payload["recommendations"] == []


# ── Combined flags ─────────────────────────────────────────────────────────

class TestCombinedFlags:
    def test_use_case_and_json(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--use-case", "reasoning", "--json"])
        assert result.exit_code == 0
        assert json.loads(result.output)["use_case"] == "reasoning"

    def test_use_case_and_no_color(self, runner, specs_mid_range):
        with patch("tinillm.recommend.cmd.detect", return_value=specs_mid_range):
            result = runner.invoke(suggest_cmd, ["--use-case", "writing", "--no-color"])
        assert result.exit_code == 0
        assert "\x1b[" not in result.output
