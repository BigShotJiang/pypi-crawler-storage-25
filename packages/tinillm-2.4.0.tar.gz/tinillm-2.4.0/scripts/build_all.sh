#!/usr/bin/env bash
# Build standalone executables for all platforms using PyInstaller.
# Run from the project root: bash scripts/build_all.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
DIST_DIR="$PROJECT_ROOT/dist"

echo "==> Installing PyInstaller..."
uv pip install pyinstaller --quiet

mkdir -p "$DIST_DIR"

echo "==> Building tinillm (current platform)..."
cd "$PROJECT_ROOT"
uv run pyinstaller \
    --onefile \
    --name tinillm \
    --distpath "$DIST_DIR" \
    --clean \
    --noconfirm \
    tinillm/main.py

echo ""
echo "==> Built: $DIST_DIR/tinillm"
echo ""
echo "    Cross-platform note:"
echo "    Run this script on each target OS to build the native binary."
echo "    Linux → Linux binary, macOS → macOS binary, Windows → .exe"
echo ""
echo "    For CI/CD matrix builds, add this script to your GitHub Actions"
echo "    workflow matrix with runs-on: [ubuntu-latest, macos-latest, windows-latest]"
