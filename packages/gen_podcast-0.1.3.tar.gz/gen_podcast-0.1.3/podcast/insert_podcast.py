from datetime import datetime
import os
import logging
import time
import uuid

from deep_translator import GoogleTranslator
from deep_translator.exceptions import TranslationNotFound

from pydub import AudioSegment
from pydantic import BaseModel
import typer
from dotenv import load_dotenv

from .aws.upload import r2_upload
from .cloudflare.rest_api import d1_table_query
from .image_compression import compress_img
from .siliconflow_api import save_gen_image
from .audio_length import get_audio_length


# Load environment variables from .env file
load_dotenv(override=True)

app = typer.Typer()


r"""
python -m podcast.insert_podcast insert_podcast_to_d1 \
    ./audios/podcast/LLM.mp3 \
    "large language model" \
    "weedge" \
    "zh-CN-YunjianNeural,zh-CN-XiaoxiaoNeural" \
    "https://example.com/cover.png" \
    "https://example.com/subtitle.json" \
    "https://example.com/subtitle.vtt" \
    "https://example.com/subtitle.lrc" \
    "https://example.com/subtitle.srt"
"""


class Podcast(BaseModel):
    pid: str
    title: str = ""
    author: str = ""
    speakers: str = ""
    audio_url: str = ""
    source: str = ""
    audio_content: str = ""
    cover_img_url: str = ""
    duration: int = 0
    description: str = ""
    tags: str = ""
    status: int = 0
    category: int = 0
    is_published: bool = False
    audio_size: int = 0
    subtitle_json_url: str = ""
    subtitle_vtt_url: str = ""
    subtitle_lrc_url: str = ""
    subtitle_srt_url: str = ""


@app.command("get_audio_duration")
def get_audio_duration(file_path, format="mp3"):
    audio = None
    match format:
        case "flv":
            audio = AudioSegment.from_flv(file_path)
        case "ogg":
            audio = AudioSegment.from_ogg(file_path)
        case "wav":
            audio = AudioSegment.from_wav(file_path)
        case _:
            audio = AudioSegment.from_mp3(file_path)
    duration = len(audio) // 1000  # s
    logging.info(f"{file_path} duration: {duration}s")
    return duration


@app.command("get_podcast")
def get_podcast(
    audio_file: str,
    title: str,
    author: str,
    speakers: str,
    audio_content: str = "",
    pid: str = "",
    language: str = "en",
    quality: int = 60,
) -> Podcast:
    cover_img_url = ""
    if title:
        en_title = title
        if language != "en":
            language = "zh-CN" if language == "zh" else language
            max_retries = 10
            retries = 0
            while retries < max_retries:
                try:
                    en_title = GoogleTranslator(
                        source=language,
                        target="en",
                    ).translate(title)
                    break  # 翻译成功，退出循环
                except TranslationNotFound as e:
                    retries += 1
                    logging.warning(f"Translation failed, retrying ({retries}/{max_retries}): {e}")
                    time.sleep(1)  # Add a 1-second delay
                    if retries == max_retries:
                        logging.error("Max retries reached, translation failed.")
                        raise  # 如果达到最大重试次数，抛出异常

        gen_img_prompt = f"podcast cover image which content is about {en_title}"
        print(f"{gen_img_prompt}")
        img_file = save_gen_image(gen_img_prompt, uuid.uuid4().hex)
        cover_img_url = r2_upload("podcast", img_file)

        compress_img_path = compress_img(img_path=img_file, quality=quality)
        compress_img_url = r2_upload("podcast", compress_img_path)
        logging.info(f"compress {img_file} to {compress_img_path} upload to r2: {compress_img_url}")

    audio_url = ""
    duration = 0
    if audio_file:
        audio_url = r2_upload("podcast", audio_file)
        duration = get_audio_duration(audio_file, format=audio_file.split(".")[-1])

    podcast = Podcast(
        pid=uuid.uuid4().hex if not pid else pid,
        title=title,
        author=author,
        speakers=speakers,
        audio_content=audio_content,
        audio_url=audio_url,
        cover_img_url=cover_img_url,
        duration=duration,
        audio_size=os.path.getsize(audio_file),
    )
    logging.info(f"podcast:{podcast}")
    return podcast


@app.command("insert_podcast_to_d1")
def insert_podcast_to_d1(
    audio_file: str,
    title: str,
    author: str,
    speakers: str,
    description: str = "",
    audio_content: str = "",
    is_published: bool = False,
    status: int = 0,
    category: int = 0,
    source: str = "",
    pid: str = "",
    language: str = "en",
    subtitle_json_url: str = "",
    subtitle_vtt_url: str = "",
    subtitle_lrc_url: str = "",
    subtitle_srt_url: str = "",
) -> Podcast:
    podcast = get_podcast(
        audio_file=audio_file,
        title=title,
        author=author,
        speakers=speakers,
        audio_content=audio_content,
        pid=pid,
        language=language,
    )

    now = datetime.now()
    formatted_time = now.strftime("%Y-%m-%d %H:%M:%S")
    db_id = os.getenv("PODCAST_D1_DB_ID")
    sql = (
        "replace into podcast("
        "pid,title,description,author,speakers,source,audio_url,audio_content,cover_img_url,"
        "duration,is_published,status,category,create_time,update_time,audio_size,"
        "subtitle_json_url,subtitle_vtt_url,subtitle_lrc_url,subtitle_srt_url"
        ") values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);"
    )
    sql_params = [
        podcast.pid,
        podcast.title,
        description,
        podcast.author,
        podcast.speakers,
        source,
        podcast.audio_url,
        podcast.audio_content,
        podcast.cover_img_url,
        podcast.duration,
        1 if is_published else 0,
        status,
        category,
        formatted_time,
        formatted_time,
        podcast.audio_size,
        subtitle_json_url,
        subtitle_vtt_url,
        subtitle_lrc_url,
        subtitle_srt_url,
    ]

    res = d1_table_query(db_id, sql, sql_params)
    if res["success"] is True:
        if is_published:
            print(
                f"insert podcast success, url: https://podcast-997.pages.dev/podcast/{podcast.pid}"
            )
        else:
            print("insert podcast success")
    else:
        logging.error(f"insert podcast failed, res: {res}")
    return res["success"]


@app.command("update_podcast_subtitles_to_d1")
def update_podcast_subtitles_to_d1(
    pid: str,
    subtitle_json_url: str = "",
    subtitle_vtt_url: str = "",
    subtitle_lrc_url: str = "",
    subtitle_srt_url: str = "",
) -> bool:
    """Backfill subtitle R2 URLs onto an existing podcast row."""
    now = datetime.now()
    formatted_time = now.strftime("%Y-%m-%d %H:%M:%S")
    db_id = os.getenv("PODCAST_D1_DB_ID")
    sql = (
        "update podcast set "
        "subtitle_json_url=?, subtitle_vtt_url=?, subtitle_lrc_url=?, subtitle_srt_url=?, "
        "update_time=? where pid=?;"
    )
    sql_params = [
        subtitle_json_url,
        subtitle_vtt_url,
        subtitle_lrc_url,
        subtitle_srt_url,
        formatted_time,
        pid,
    ]
    res = d1_table_query(db_id, sql, sql_params)
    print(res)
    return res["success"]


@app.command("update_podcast_cover_to_d1")
def update_podcast_cover_to_d1(
    pid: str,
    cover_img_url: str,
) -> Podcast:
    now = datetime.now()
    formatted_time = now.strftime("%Y-%m-%d %H:%M:%S")
    db_id = os.getenv("PODCAST_D1_DB_ID")
    sql = "update podcast set cover_img_url=?, update_time=? where pid=?;"
    sql_params = [
        cover_img_url,
        formatted_time,
        pid,
    ]
    res = d1_table_query(db_id, sql, sql_params)
    print(res)
    return res["success"]


@app.command("update_podcast_audio_size_to_d1")
def update_podcast_audio_size_to_d1():
    now = datetime.now()
    db_id = os.getenv("PODCAST_D1_DB_ID")
    select_sql = "select pid,audio_url,audio_size from podcast where audio_size=0;"
    select_res = d1_table_query(db_id, select_sql)
    for item in select_res["result"][0]["results"]:
        file_name = item["audio_url"].split("/")[-1]
        file_path = f"./audios/podcast/{file_name}"
        if os.path.exists(file_path):
            audio_size = os.path.getsize(file_path)
        else:
            audio_size = get_audio_length(item["audio_url"])
        sql = "update podcast set audio_size=?, update_time=? where pid=?;"
        formatted_time = now.strftime("%Y-%m-%d %H:%M:%S")
        sql_params = [
            audio_size,
            formatted_time,
            item["pid"],
        ]
        res = d1_table_query(db_id, sql, sql_params)
        if res["success"] is True:
            logging.info(
                f"update podcast success, url: https://podcast-997.pages.dev/podcast/{item['pid']}"
            )


r"""
python -m podcast.insert_podcast get_podcast \
    ./audios/podcast/LLM.mp3 \
    "large language model" \
    "weedge" \
    "zh-CN-YunjianNeural,zh-CN-XiaoxiaoNeural"

python -m podcast.insert_podcast insert_podcast_to_d1 \
    ./audios/podcast/LLM.mp3 \
    "large language model" \
    "weedge" \
    "zh-CN-YunjianNeural,zh-CN-XiaoxiaoNeural"

python -m podcast.insert_podcast update_podcast_cover_to_d1 \
    195b08f114a94819bbb90ea2deac3220 \
    "https://example.com/cover.png"
"""
if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(pathname)s:%(lineno)d - %(funcName)s - %(message)s",
        handlers=[
            logging.StreamHandler()],
    )
    app()
