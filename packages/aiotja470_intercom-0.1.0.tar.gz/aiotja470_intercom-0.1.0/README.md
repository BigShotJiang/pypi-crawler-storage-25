# aiotja470_intercom

Asynchronous Python client for the Hager TJA470 Intercom API. This package is designed to be integrated into Home Assistant.

## Installation

```bash
pip install aiotja470_intercom
```

## Usage

```python
import asyncio
from aiotja470_intercom import TJA470IntercomClient, AiohttpRunner

async def main():
    runner = AiohttpRunner()
    client = TJA470IntercomClient(
        host="192.168.1.100",
        username="user",
        password="password",
        runner=runner
    )

    try:
        # Check manifest
        await client.get_manifest()

        # Get free devices for pairing
        devices = await client.get_free_devices()
        print(devices)

        # Retrieve provisioning config
        config = await client.get_provisioning("your-uuid")
        print(config)

    finally:
        await runner.close()

if __name__ == "__main__":
    asyncio.run(main())
```