"""
Widget system: base class + all built-in widgets.
Widgets draw themselves onto a Canvas region.
"""
from __future__ import annotations
import math
import time
import unicodedata
from typing import Optional, List, Callable, Any, Tuple
from neoterm.canvas import Canvas, Cell, char_width, ATTR_BOLD, ATTR_ITALIC, ATTR_UNDERLINE, ATTR_REVERSE
from neoterm.events import MouseEvent, KeyEvent, MouseButton
from neoterm.layout import LayoutNode, FlexStyle, Rect
from neoterm.animation import Animation, SHADERS


# ── Theme ─────────────────────────────────────────────────────────────────────

class Theme:
    BG        = (18,  18,  24)
    BG2       = (28,  28,  38)
    BG3       = (38,  38,  52)
    FG        = (204, 204, 220)
    FG2       = (140, 140, 160)
    ACCENT    = (120, 90,  220)
    ACCENT2   = (80,  160, 240)
    SUCCESS   = (80,  200, 120)
    WARN      = (240, 180,  60)
    ERROR     = (220,  70,  70)
    BORDER    = (60,   60,  90)
    BORDER_HI = (120, 100, 200)
    SELECT_BG = (50,  50,  90)
    SELECT_FG = (230, 230, 255)

T = Theme


# ── Base Widget ───────────────────────────────────────────────────────────────

class Widget:
    def __init__(self, style: Optional[FlexStyle] = None):
        self.node    = LayoutNode(style or FlexStyle())
        self.node._widget = self
        self.focused    = False
        self.visible    = True
        self._anim:     Optional[Animation] = None
        self._shader:   Optional[str] = None
        self._on_focus: Optional[Callable] = None

    @property
    def rect(self) -> Rect:
        return self.node.rect

    def animate(self, prop: str, from_: float, to: float,
                duration: float = 0.3, easing: str = "ease_out_cubic",
                loop: bool = False, delay: float = 0.0):
        if self._anim is None:
            self._anim = Animation()
        self._anim.add(prop, [(delay, from_), (delay + duration, to)],
                       easing=easing, loop=loop)
        self._anim.start()
        return self

    def set_shader(self, name: str):
        self._shader = name
        return self

    def _apply_shader(self, canvas: Canvas):
        if not self._shader or self._shader == "none":
            return
        fn = SHADERS.get(self._shader)
        if fn is None:
            return
        t = time.monotonic()
        r = self.rect
        for y in range(r.y, min(r.y + r.h, canvas.height)):
            for x in range(r.x, min(r.x + r.w, canvas.width)):
                idx = y * canvas.width + x
                old = canvas.front[idx]
                new = fn(x - r.x, y - r.y, t, old)
                canvas.front[idx] = new

    def render(self, canvas: Canvas):
        pass

    def handle_mouse(self, ev: MouseEvent) -> bool:
        return False

    def handle_key(self, ev: KeyEvent) -> bool:
        return False

    def hit_test(self, x: int, y: int) -> bool:
        r = self.rect
        return r.x <= x < r.x + r.w and r.y <= y < r.y + r.h


# ── Label ─────────────────────────────────────────────────────────────────────

class Label(Widget):
    def __init__(self, text: str = "", fg=None, bg=None,
                 bold=False, italic=False, underline=False,
                 align: str = "left", wrap: bool = False,
                 style: Optional[FlexStyle] = None):
        super().__init__(style)
        self.text      = text
        self.fg        = fg or T.FG
        self.bg        = bg or T.BG
        self.bold      = bold
        self.italic    = italic
        self.underline = underline
        self.align     = align
        self.wrap      = wrap

    def render(self, canvas: Canvas):
        r = self.rect
        if not self.visible or r.w <= 0 or r.h <= 0:
            return
        canvas.fill(r.x, r.y, r.w, r.h, bg=self.bg)

        attrs = 0
        if self.bold:      attrs |= ATTR_BOLD
        if self.italic:    attrs |= ATTR_ITALIC
        if self.underline: attrs |= ATTR_UNDERLINE

        opacity = 1.0
        if self._anim:
            opacity = self._anim.get("opacity", 1.0)

        fg = self.fg
        if opacity < 1.0:
            fg = tuple(int(c * opacity) for c in fg)  # type: ignore

        lines = self.text.split("\n") if self.wrap else [self.text]
        for row, line in enumerate(lines):
            if row >= r.h:
                break
            # measure display width
            disp_w = sum(char_width(c) for c in line)
            if self.align == "center":
                xoff = max(0, (r.w - disp_w) // 2)
            elif self.align == "right":
                xoff = max(0, r.w - disp_w)
            else:
                xoff = 0

            cx = r.x + xoff
            for ch in line:
                if cx - r.x >= r.w:
                    break
                w = char_width(ch)
                canvas.put(cx, r.y + row, Cell(ch, fg, self.bg, attrs, w))
                cx += w

        self._apply_shader(canvas)


# ── Divider ───────────────────────────────────────────────────────────────────

class Divider(Widget):
    def __init__(self, direction="horizontal", fg=None, bg=None,
                 style: Optional[FlexStyle] = None):
        s = style or FlexStyle()
        if direction == "horizontal":
            s.height = 1
        else:
            s.width = 1
        super().__init__(s)
        self.direction = direction
        self.fg = fg or T.BORDER
        self.bg = bg or T.BG

    def render(self, canvas: Canvas):
        r = self.rect
        if self.direction == "horizontal":
            canvas.hline(r.x, r.y, r.w, "─", self.fg, self.bg)
        else:
            canvas.vline(r.x, r.y, r.h, "│", self.fg, self.bg)


# ── Button ────────────────────────────────────────────────────────────────────

class Button(Widget):
    def __init__(self, label: str = "OK",
                 on_click: Optional[Callable] = None,
                 fg=None, bg=None, fg_hover=None, bg_hover=None,
                 style: Optional[FlexStyle] = None):
        s = style or FlexStyle()
        if s.height is None: s.height = 3
        super().__init__(s)
        self.label    = label
        self.on_click = on_click
        self.fg       = fg       or T.FG
        self.bg       = bg       or T.BG2
        self.fg_hover = fg_hover or T.SELECT_FG
        self.bg_hover = bg_hover or T.ACCENT
        self._hover   = False
        self._pressed = False
        self._press_t = 0.0

    def render(self, canvas: Canvas):
        r = self.rect
        if not self.visible or r.w <= 0 or r.h <= 0:
            return

        # flash on press
        flash = (time.monotonic() - self._press_t < 0.12)
        if flash:
            fg, bg = T.BG, T.ACCENT2
        elif self._hover or self.focused:
            fg, bg = self.fg_hover, self.bg_hover
        else:
            fg, bg = self.fg, self.bg

        canvas.fill(r.x, r.y, r.w, r.h, bg=bg)
        canvas.box(r.x, r.y, r.w, r.h, fg=T.BORDER_HI if (self._hover or self.focused) else T.BORDER, bg=bg)

        # center label
        label_w = sum(char_width(c) for c in self.label)
        lx = r.x + max(0, (r.w - label_w) // 2)
        ly = r.y + r.h // 2
        canvas.text(lx, ly, self.label, fg, bg, ATTR_BOLD)
        self._apply_shader(canvas)

    def handle_mouse(self, ev: MouseEvent) -> bool:
        was_hover = self._hover
        self._hover = self.hit_test(ev.x, ev.y)
        if self._hover and ev.button == MouseButton.LEFT and ev.pressed:
            self._pressed = True
            self._press_t = time.monotonic()
            if self.on_click:
                self.on_click()
            return True
        if not ev.pressed:
            self._pressed = False
        return self._hover != was_hover

    def handle_key(self, ev: KeyEvent) -> bool:
        if self.focused and ev.key in ("Enter", " "):
            self._press_t = time.monotonic()
            if self.on_click:
                self.on_click()
            return True
        return False


# ── TextInput ─────────────────────────────────────────────────────────────────

class TextInput(Widget):
    def __init__(self, placeholder: str = "",
                 value: str = "",
                 on_change: Optional[Callable[[str], None]] = None,
                 on_submit: Optional[Callable[[str], None]] = None,
                 password: bool = False,
                 max_len: int = 0,
                 style: Optional[FlexStyle] = None):
        s = style or FlexStyle()
        if s.height is None: s.height = 3
        super().__init__(s)
        self.placeholder = placeholder
        self.value       = value
        self.on_change   = on_change
        self.on_submit   = on_submit
        self.password    = password
        self.max_len     = max_len
        self._cursor     = len(value)
        self._scroll     = 0          # horizontal scroll offset
        self._blink      = 0.0

    def render(self, canvas: Canvas):
        r = self.rect
        if not self.visible or r.w <= 0 or r.h <= 0:
            return

        bg = T.BG2 if self.focused else T.BG
        border_fg = T.ACCENT if self.focused else T.BORDER
        canvas.fill(r.x, r.y, r.w, r.h, bg=bg)
        canvas.box(r.x, r.y, r.w, r.h, fg=border_fg, bg=bg)

        inner_w = r.w - 4
        ly = r.y + r.h // 2

        display = ("•" * len(self.value)) if self.password else self.value
        if not display:
            canvas.text(r.x + 2, ly, self.placeholder[:inner_w], T.FG2, bg)
        else:
            # horizontal scroll
            visible = display[self._scroll: self._scroll + inner_w]
            canvas.text(r.x + 2, ly, visible, T.FG, bg)

        # cursor blink
        if self.focused:
            blink_on = int(time.monotonic() * 2) % 2 == 0
            if blink_on:
                cur_pos = self._cursor - self._scroll
                if 0 <= cur_pos <= inner_w:
                    cx = r.x + 2 + cur_pos
                    ch = display[self._cursor] if self._cursor < len(display) else " "
                    canvas.put(cx, ly, Cell(ch, T.BG, T.ACCENT, 0, 1))

    def handle_key(self, ev: KeyEvent) -> bool:
        if not self.focused:
            return False
        if ev.key == "Backspace":
            if self._cursor > 0:
                self.value = self.value[:self._cursor-1] + self.value[self._cursor:]
                self._cursor -= 1
                self._ensure_scroll()
                if self.on_change: self.on_change(self.value)
            return True
        if ev.key == "Delete":
            if self._cursor < len(self.value):
                self.value = self.value[:self._cursor] + self.value[self._cursor+1:]
                if self.on_change: self.on_change(self.value)
            return True
        if ev.key == "Left":
            self._cursor = max(0, self._cursor - 1)
            self._ensure_scroll(); return True
        if ev.key == "Right":
            self._cursor = min(len(self.value), self._cursor + 1)
            self._ensure_scroll(); return True
        if ev.key == "Home" or ev.key == "Ctrl+A":
            self._cursor = 0; self._scroll = 0; return True
        if ev.key == "End" or ev.key == "Ctrl+E":
            self._cursor = len(self.value); self._ensure_scroll(); return True
        if ev.key == "Enter":
            if self.on_submit: self.on_submit(self.value)
            return True
        if ev.key == "Ctrl+U":
            self.value = ""; self._cursor = 0; self._scroll = 0
            if self.on_change: self.on_change(self.value); return True
        if ev.char and not ev.ctrl and not ev.alt:
            if self.max_len == 0 or len(self.value) < self.max_len:
                self.value = self.value[:self._cursor] + ev.char + self.value[self._cursor:]
                self._cursor += 1
                self._ensure_scroll()
                if self.on_change: self.on_change(self.value)
            return True
        return False

    def _ensure_scroll(self):
        inner_w = max(1, self.rect.w - 4)
        if self._cursor - self._scroll >= inner_w:
            self._scroll = self._cursor - inner_w + 1
        if self._cursor < self._scroll:
            self._scroll = self._cursor


# ── ProgressBar ───────────────────────────────────────────────────────────────

class ProgressBar(Widget):
    def __init__(self, value: float = 0.0, max_val: float = 100.0,
                 show_label: bool = True, animated: bool = True,
                 fg=None, bg=None, style: Optional[FlexStyle] = None):
        s = style or FlexStyle()
        if s.height is None: s.height = 3
        super().__init__(s)
        self.value     = value
        self.max_val   = max_val
        self.show_label= show_label
        self.fg        = fg or T.ACCENT
        self.bg        = bg or T.BG2
        self._animated = animated
        self._render_v = value   # animated render value

    def render(self, canvas: Canvas):
        r = self.rect
        if not self.visible or r.w <= 0 or r.h <= 0:
            return

        # smooth animation
        if self._animated:
            diff = self.value - self._render_v
            self._render_v += diff * 0.2
        else:
            self._render_v = self.value

        canvas.fill(r.x, r.y, r.w, r.h, bg=self.bg)
        canvas.box(r.x, r.y, r.w, r.h, fg=T.BORDER, bg=self.bg)

        inner_w = r.w - 2
        pct = max(0.0, min(1.0, self._render_v / max(1, self.max_val)))
        fill_w = int(inner_w * pct)

        # sub-character precision using block chars
        partial = (inner_w * pct) - fill_w
        blocks  = " ▏▎▍▌▋▊▉█"
        sub_idx = int(partial * 8)

        ly = r.y + r.h // 2
        for i in range(fill_w):
            canvas.put_char(r.x + 1 + i, ly, "█", self.fg, self.bg)
        if fill_w < inner_w and sub_idx > 0:
            canvas.put_char(r.x + 1 + fill_w, ly, blocks[sub_idx], self.fg, self.bg)

        if self.show_label:
            label = f"{int(self._render_v)}/{int(self.max_val)}"
            lx = r.x + max(1, (r.w - len(label)) // 2)
            # draw over bar with proper contrast
            for i, ch in enumerate(label):
                fx = lx + i
                if 0 <= fx < r.x + r.w - 1:
                    bar_here = (fx - r.x - 1) < fill_w
                    fg2 = T.BG if bar_here else self.fg
                    bg2 = self.fg if bar_here else self.bg
                    canvas.put_char(fx, ly, ch, fg2, bg2)

        self._apply_shader(canvas)


# ── Spinner ───────────────────────────────────────────────────────────────────

class Spinner(Widget):
    FRAMES = ["⠋","⠙","⠹","⠸","⠼","⠴","⠦","⠧","⠇","⠏"]

    def __init__(self, label: str = "Loading...", fg=None,
                 style: Optional[FlexStyle] = None):
        s = style or FlexStyle()
        if s.height is None: s.height = 1
        super().__init__(s)
        self.label = label
        self.fg    = fg or T.ACCENT

    def render(self, canvas: Canvas):
        r = self.rect
        if not self.visible: return
        frame = self.FRAMES[int(time.monotonic() * 10) % len(self.FRAMES)]
        canvas.fill(r.x, r.y, r.w, 1, bg=T.BG)
        canvas.put_char(r.x, r.y, frame, self.fg, T.BG, ATTR_BOLD)
        canvas.text(r.x + 2, r.y, self.label, T.FG2, T.BG)


# ── Table ─────────────────────────────────────────────────────────────────────

class Table(Widget):
    def __init__(self, columns: List[str],
                 rows: Optional[List[List[Any]]] = None,
                 on_select: Optional[Callable[[int, List], None]] = None,
                 sortable: bool = True,
                 style: Optional[FlexStyle] = None):
        super().__init__(style or FlexStyle())
        self.columns   = columns
        self.rows: List[List[Any]] = rows or []
        self.on_select = on_select
        self.sortable  = sortable
        self._selected = 0
        self._scroll   = 0
        self._sort_col: Optional[int] = None
        self._sort_asc  = True
        self._hover_row = -1

    @property
    def col_widths(self) -> List[int]:
        if not self.rect.w:
            return [10] * len(self.columns)
        inner = self.rect.w - 2 - (len(self.columns) - 1)
        base  = max(4, inner // max(1, len(self.columns)))
        return [base] * len(self.columns)

    def render(self, canvas: Canvas):
        r = self.rect
        if not self.visible or r.w < 4 or r.h < 3:
            return

        canvas.fill(r.x, r.y, r.w, r.h, bg=T.BG)
        canvas.box(r.x, r.y, r.w, r.h, fg=T.BORDER, bg=T.BG)

        cws = self.col_widths
        header_y = r.y + 1
        cx = r.x + 1

        # Header
        for i, (col, cw) in enumerate(zip(self.columns, cws)):
            arrow = ""
            if self.sortable and self._sort_col == i:
                arrow = " ▲" if self._sort_asc else " ▼"
            h_text = (col + arrow)[:cw]
            pad = cw - len(h_text)
            canvas.text(cx, header_y, h_text + " "*pad, T.ACCENT2, T.BG, ATTR_BOLD)
            cx += cw + 1
            if i < len(self.columns) - 1:
                canvas.put_char(cx - 1, header_y, "│", T.BORDER, T.BG)

        canvas.hline(r.x + 1, header_y + 1, r.w - 2, "─", T.BORDER, T.BG)

        # Rows
        max_rows = r.h - 4
        visible_rows = self.rows[self._scroll: self._scroll + max_rows]

        for row_i, row in enumerate(visible_rows):
            abs_i = row_i + self._scroll
            ry = header_y + 2 + row_i
            if ry >= r.y + r.h - 1:
                break

            is_sel   = abs_i == self._selected
            is_hover = abs_i == self._hover_row
            if is_sel:
                row_fg, row_bg = T.SELECT_FG, T.SELECT_BG
            elif is_hover:
                row_fg, row_bg = T.FG, T.BG3
            else:
                row_fg, row_bg = T.FG, T.BG

            canvas.fill(r.x + 1, ry, r.w - 2, 1, bg=row_bg)
            cx = r.x + 1
            for i, (cell_val, cw) in enumerate(zip(row, cws)):
                text = str(cell_val)[:cw].ljust(cw)
                canvas.text(cx, ry, text, row_fg, row_bg)
                cx += cw + 1
                if i < len(self.columns) - 1:
                    canvas.put_char(cx - 1, ry, "│", T.BORDER, row_bg)

        # scrollbar
        if len(self.rows) > max_rows and max_rows > 0:
            bar_h = max(1, max_rows * max_rows // len(self.rows))
            bar_y = header_y + 2 + (self._scroll * (max_rows - bar_h) // max(1, len(self.rows) - max_rows))
            canvas.vline(r.x + r.w - 1, header_y + 2, max_rows, "▒", T.BORDER, T.BG)
            for i in range(bar_h):
                if bar_y + i < r.y + r.h - 1:
                    canvas.put_char(r.x + r.w - 1, bar_y + i, "█", T.ACCENT, T.BG)

    def handle_mouse(self, ev: MouseEvent) -> bool:
        r = self.rect
        header_y = r.y + 1
        if not self.hit_test(ev.x, ev.y):
            self._hover_row = -1
            return False

        # header click → sort
        if ev.y == header_y and ev.button == MouseButton.LEFT and ev.pressed and self.sortable:
            cws = self.col_widths
            cx = r.x + 1
            for i, cw in enumerate(cws):
                if cx <= ev.x < cx + cw:
                    if self._sort_col == i:
                        self._sort_asc = not self._sort_asc
                    else:
                        self._sort_col = i
                        self._sort_asc = True
                    self.rows.sort(key=lambda row: str(row[i]) if i < len(row) else "",
                                   reverse=not self._sort_asc)
                    return True
                cx += cw + 1

        # row click
        row_y = ev.y - header_y - 2
        if 0 <= row_y < len(self.rows):
            abs_i = row_y + self._scroll
            self._hover_row = abs_i
            if ev.button == MouseButton.LEFT and ev.pressed:
                self._selected = abs_i
                if self.on_select and abs_i < len(self.rows):
                    self.on_select(abs_i, self.rows[abs_i])
                return True

        # scroll wheel
        if ev.button == MouseButton.SCROLL_UP:
            self._scroll = max(0, self._scroll - 1); return True
        if ev.button == MouseButton.SCROLL_DOWN:
            self._scroll = min(max(0, len(self.rows) - 1), self._scroll + 1); return True
        return True

    def handle_key(self, ev: KeyEvent) -> bool:
        if not self.focused: return False
        if ev.key == "Up":
            self._selected = max(0, self._selected - 1)
            self._ensure_visible(); return True
        if ev.key == "Down":
            self._selected = min(len(self.rows) - 1, self._selected + 1)
            self._ensure_visible(); return True
        if ev.key == "Enter":
            if self.on_select and self._selected < len(self.rows):
                self.on_select(self._selected, self.rows[self._selected])
            return True
        return False

    def _ensure_visible(self):
        max_rows = max(1, self.rect.h - 4)
        if self._selected < self._scroll:
            self._scroll = self._selected
        elif self._selected >= self._scroll + max_rows:
            self._scroll = self._selected - max_rows + 1


# ── ScrollView ────────────────────────────────────────────────────────────────

class ScrollView(Widget):
    def __init__(self, content: Optional[Widget] = None,
                 style: Optional[FlexStyle] = None):
        super().__init__(style or FlexStyle())
        self.content  = content
        self._scroll_y = 0
        self._scroll_x = 0

    def render(self, canvas: Canvas):
        r = self.rect
        if not self.visible or r.w < 2 or r.h < 2:
            return
        canvas.fill(r.x, r.y, r.w, r.h, bg=T.BG)
        if self.content:
            # give content its own virtual area inside
            self.content.node.layout(r.x, r.y - self._scroll_y, r.w - 1, r.h * 4)
            self.content.render(canvas)
        # draw scrollbar
        canvas.vline(r.x + r.w - 1, r.y, r.h, "│", T.BORDER, T.BG)

    def handle_mouse(self, ev: MouseEvent) -> bool:
        if not self.hit_test(ev.x, ev.y): return False
        if ev.button == MouseButton.SCROLL_UP:
            self._scroll_y = max(0, self._scroll_y - 2); return True
        if ev.button == MouseButton.SCROLL_DOWN:
            self._scroll_y += 2; return True
        if self.content:
            return self.content.handle_mouse(ev)
        return False


# ── Image widget (Sixel / iTerm2 inline / block art fallback) ──────────────────

class ImageWidget(Widget):
    """
    Display an image in the terminal.
    Tries (in order):
      1. Kitty terminal graphics protocol
      2. Sixel (if supported)
      3. Half-block Unicode art (always works)
    """
    def __init__(self, path: Optional[str] = None,
                 data: Optional[bytes] = None,
                 width_cells: int = 20,
                 height_cells: int = 10,
                 protocol: str = "auto",
                 style: Optional[FlexStyle] = None):
        s = style or FlexStyle()
        s.width  = s.width  or width_cells
        s.height = s.height or height_cells
        super().__init__(s)
        self.path          = path
        self.data          = data
        self.width_cells   = width_cells
        self.height_cells  = height_cells
        self.protocol      = protocol     # "kitty", "sixel", "block", "auto"
        self._pixels:       Optional[list] = None
        self._loaded        = False

    def load(self):
        if self._loaded:
            return
        try:
            from PIL import Image as PILImage
            if self.path:
                img = PILImage.open(self.path)
            elif self.data:
                import io
                img = PILImage.open(io.BytesIO(self.data))
            else:
                self._loaded = True; return
            img = img.convert("RGB")
            # resize to 2× height (half-block = 2 rows per cell row)
            tw = self.width_cells
            th = self.height_cells * 2
            img = img.resize((tw, th), PILImage.LANCZOS)
            self._pixels = list(img.getdata())
            self._img_w  = tw
            self._img_h  = th
        except ImportError:
            self._pixels = None
        self._loaded = True

    def render(self, canvas: Canvas):
        self.load()
        r = self.rect
        if not self.visible: return

        if self._pixels is None:
            # Pillow not available - draw placeholder
            canvas.box(r.x, r.y, r.w, r.h, fg=T.BORDER, bg=T.BG)
            canvas.text(r.x + 2, r.y + r.h//2, "📷 (pip install pillow)", T.FG2, T.BG)
            return

        # Half-block render: ▀ uses top pixel as fg, bg cell as bg
        for row in range(min(self.height_cells, r.h)):
            for col in range(min(self.width_cells, r.w)):
                top_i  = (row * 2)     * self._img_w + col
                bot_i  = (row * 2 + 1) * self._img_w + col
                if top_i >= len(self._pixels): break
                top_rgb = self._pixels[top_i]
                bot_rgb = self._pixels[bot_i] if bot_i < len(self._pixels) else (0,0,0)
                canvas.put(r.x + col, r.y + row,
                           Cell("▀", top_rgb, bot_rgb, 0, 1))

        self._apply_shader(canvas)


# ── Container (Flex) ──────────────────────────────────────────────────────────

class Container(Widget):
    """
    A widget that holds children and lays them out with flexbox.
    The most important building block for layouts.
    """
    def __init__(self, direction="column", gap=0,
                 padding=(1,2,1,2),
                 fg_border=None, bg=None,
                 border: bool = False,
                 border_style: str = "rounded",
                 title: str = "",
                 shader: Optional[str] = None,
                 style: Optional[FlexStyle] = None):
        s = style or FlexStyle()
        s.direction = direction
        s.gap       = gap
        s.padding   = padding
        super().__init__(s)
        self.children:    List[Widget] = []
        self.fg_border    = fg_border or T.BORDER
        self.bg           = bg or T.BG
        self.border       = border
        self.border_style = border_style
        self.title        = title
        self._shader      = shader

    def add(self, widget: Widget) -> Widget:
        self.children.append(widget)
        self.node.add(widget.node)
        return widget

    def layout(self, x: int, y: int, w: int, h: int):
        self.node.layout(x, y, w, h)

    def render(self, canvas: Canvas):
        r = self.rect
        if not self.visible: return

        canvas.fill(r.x, r.y, r.w, r.h, bg=self.bg)

        if self.border:
            canvas.box(r.x, r.y, r.w, r.h,
                       fg=self.fg_border, bg=self.bg, style=self.border_style)
            if self.title:
                tx = r.x + 2
                canvas.text(tx, r.y, f" {self.title} ", T.ACCENT2, self.bg, ATTR_BOLD)

        for child in self.children:
            if child.visible:
                child.render(canvas)

        self._apply_shader(canvas)

    def handle_mouse(self, ev: MouseEvent) -> bool:
        for child in reversed(self.children):
            if child.hit_test(ev.x, ev.y):
                if child.handle_mouse(ev):
                    return True
        return False

    def handle_key(self, ev: KeyEvent) -> bool:
        for child in self.children:
            if child.focused and child.handle_key(ev):
                return True
        return False

    def find_focusable(self) -> List[Widget]:
        result = []
        for child in self.children:
            if isinstance(child, Container):
                result.extend(child.find_focusable())
            elif isinstance(child, (Button, TextInput, Table)):
                result.append(child)
        return result
