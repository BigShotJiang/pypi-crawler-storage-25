"""
CLI entry points — kurulumdan sonra terminalde doğrudan çalışır:
  neoterm-help
  neoterm-demo
  neoterm-shaders
"""
import sys
import os
import runpy


def _run_example(name):
    """Önce kurulu paketteki examples'a bak, sonra kaynak klasöre."""
    # 1) pip install ile kurulmuş — paket dizininin yanında examples var mı?
    pkg_dir  = os.path.dirname(os.path.abspath(__file__))          # neoterm/
    root_dir = os.path.dirname(pkg_dir)                             # proje kökü
    script   = os.path.join(root_dir, "examples", name)

    if os.path.exists(script):
        sys.path.insert(0, root_dir)
        runpy.run_path(script, run_name="__main__")
        return

    # 2) Doğrudan inline çalıştır (pip install sonrası examples yoksa)
    sys.path.insert(0, root_dir)
    if name == "demo.py":
        _run_demo_inline()
    elif name == "help.py":
        _run_help_inline()
    elif name == "shader_gallery.py":
        _run_shaders_inline()


def help():
    _run_example("help.py")


def demo():
    _run_example("demo.py")


def shaders():
    _run_example("shader_gallery.py")


# ── Inline fallback'ler ───────────────────────────────────────────────────────

def _run_demo_inline():
    import neoterm as nt
    from neoterm.layout import FlexStyle

    app = nt.App(fps=30)
    root = nt.Container(direction="column", gap=1, padding=(1,2,1,2),
                         border=True, title="NeoTerm Demo")

    root.add(nt.Label("🚀 NeoTerm kuruldu!", bold=True,
                       fg=nt.T.ACCENT2, align="center"))
    root.add(nt.Label("Tam demo için kaynak kodunu indir:", fg=nt.T.FG2, align="center"))
    root.add(nt.Label("github.com veya zip'ten examples/demo.py", fg=nt.T.FG2, align="center"))
    root.add(nt.Divider())

    pbar = nt.ProgressBar(value=0, style=FlexStyle(height=3))
    root.add(pbar)
    root.add(nt.Divider())

    shader_names = ["none","rainbow","wave","matrix","fire"]
    shader_idx   = [0]
    def next_shader():
        shader_idx[0] = (shader_idx[0] + 1) % len(shader_names)
        n = shader_names[shader_idx[0]]
        shader_btn.label = f"🎨 Shader: {n}"
        root.set_shader(n if n != "none" else None)

    shader_btn = nt.Button("🎨 Shader: none", on_click=next_shader,
                            style=FlexStyle(height=3))
    quit_btn   = nt.Button("❌ Çık", on_click=app.quit,
                            fg=nt.T.ERROR, style=FlexStyle(height=3))

    row = nt.Container(direction="row", gap=1, padding=(0,0,0,0))
    row.add(shader_btn)
    row.add(quit_btn)
    root.add(row)

    import time
    start = time.monotonic()
    orig  = app._render
    def patched():
        pbar.value = (time.monotonic() - start) * 20 % 100
        orig()
    app._render = patched

    app.mount(root)
    app.run()


def _run_help_inline():
    import neoterm as nt
    from neoterm.layout import FlexStyle

    app = nt.App(fps=30)
    root = nt.Container(direction="column", gap=1, padding=(2,4,2,4),
                         border=True, title="NeoTerm Help")

    root.add(nt.Label("📖 NeoTerm Hızlı Başlangıç", bold=True,
                       fg=nt.T.ACCENT2, align="center"))
    root.add(nt.Divider())

    lines = [
        "import neoterm as nt",
        "from neoterm.layout import FlexStyle",
        "",
        "app = nt.App(fps=30)",
        "root = nt.Container(direction='column',",
        "                    border=True, title='App')",
        "root.add(nt.Label('Merhaba! 👋', bold=True))",
        "root.add(nt.Button('Çık', on_click=app.quit))",
        "app.mount(root)",
        "app.run()",
    ]
    for line in lines:
        root.add(nt.Label(line, fg=nt.T.FG, style=FlexStyle(height=1)))

    root.add(nt.Divider())
    root.add(nt.Label("Tam dokümantasyon için: neoterm-help (kaynak zip gerekli)",
                       fg=nt.T.FG2, align="center"))
    root.add(nt.Button("Çık", on_click=app.quit, style=FlexStyle(height=3)))

    app.mount(root)
    app.run()


def _run_shaders_inline():
    import neoterm as nt
    from neoterm.layout import FlexStyle

    app = nt.App(fps=60)
    root = nt.Container(direction="column", gap=1, padding=(1,2,1,2),
                         border=True, title="Shader Gallery")

    preview = nt.Container(direction="column", gap=0, padding=(1,1,1,1),
                            border=True, style=FlexStyle(flex_grow=1))
    lines = [
        "  ███╗   ██╗███████╗ ██████╗ ████████╗███████╗██████╗ ███╗   ███╗",
        "  ████╗  ██║██╔════╝██╔═══██╗╚══██╔══╝██╔════╝██╔══██╗████╗ ████║",
        "  ██╔██╗ ██║█████╗  ██║   ██║   ██║   █████╗  ██████╔╝██╔████╔██║",
        "  ██║╚██╗██║██╔══╝  ██║   ██║   ██║   ██╔══╝  ██╔══██╗██║╚██╔╝██║",
        "  ██║ ╚████║███████╗╚██████╔╝   ██║   ███████╗██║  ██║██║ ╚═╝ ██║",
        "  ╚═╝  ╚═══╝╚══════╝ ╚═════╝    ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝",
        "",
        "  🌍 Unicode  🚀 Mouse  🎨 Shaders  ⚡ Animasyon",
    ]
    for line in lines:
        preview.add(nt.Label(line, style=FlexStyle(height=1)))
    root.add(preview)

    SHADERS = ["none","rainbow","wave","matrix","fire","scanline"]
    cur = [0]
    lbl = nt.Label("Aktif: none", fg=nt.T.FG2, align="center", style=FlexStyle(height=1))
    root.add(lbl)

    def set_shader(i):
        cur[0] = i
        n = SHADERS[i]
        lbl.text = f"Aktif: {n}  (← → ile değiştir)"
        preview.set_shader(n if n != "none" else None)

    row = nt.Container(direction="row", gap=1, padding=(0,0,0,0), style=FlexStyle(height=3))
    for i, name in enumerate(SHADERS):
        row.add(nt.Button(name, on_click=lambda i=i: set_shader(i),
                           style=FlexStyle(flex_grow=1)))
    root.add(row)

    def on_key(ev):
        if ev.key == "Right": set_shader((cur[0]+1) % len(SHADERS))
        if ev.key == "Left":  set_shader((cur[0]-1) % len(SHADERS))

    app.on_key(on_key)
    app.mount(root)
    app.run()


if __name__ == "__main__":
    help()