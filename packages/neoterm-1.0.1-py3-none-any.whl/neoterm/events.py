"""
Event parsing: keyboard (full Unicode + special keys), mouse (SGR), resize.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import Optional
from enum import Enum, auto


class EventType(Enum):
    KEY        = auto()
    MOUSE      = auto()
    RESIZE     = auto()
    TIMER      = auto()


class MouseButton(Enum):
    LEFT    = 0
    MIDDLE  = 1
    RIGHT   = 2
    SCROLL_UP   = 64
    SCROLL_DOWN = 65
    NONE    = -1


@dataclass
class MouseEvent:
    x: int
    y: int
    button: MouseButton
    pressed: bool         # True = press / scroll, False = release
    drag: bool = False
    shift: bool = False
    ctrl:  bool = False
    alt:   bool = False
    type: EventType = EventType.MOUSE


@dataclass
class KeyEvent:
    key: str              # printable char OR special name e.g. "Up", "F1", "Ctrl+C"
    char: Optional[str]   # actual unicode char if printable, else None
    ctrl:  bool = False
    alt:   bool = False
    shift: bool = False
    type: EventType = EventType.KEY


@dataclass
class ResizeEvent:
    width: int
    height: int
    type: EventType = EventType.RESIZE


# ── special key map ───────────────────────────────────────────────────────────

_ESC_MAP = {
    "\x1b[A":  "Up",    "\x1b[B":  "Down",
    "\x1b[C":  "Right", "\x1b[D":  "Left",
    "\x1b[H":  "Home",  "\x1b[F":  "End",
    "\x1b[2~": "Insert","\x1b[3~": "Delete",
    "\x1b[5~": "PageUp","\x1b[6~": "PageDown",
    "\x1bOP":  "F1",    "\x1bOQ":  "F2",
    "\x1bOR":  "F3",    "\x1bOS":  "F4",
    "\x1b[15~":"F5",    "\x1b[17~":"F6",
    "\x1b[18~":"F7",    "\x1b[19~":"F8",
    "\x1b[20~":"F9",    "\x1b[21~":"F10",
    "\x1b[23~":"F11",   "\x1b[24~":"F12",
    # shift arrows
    "\x1b[1;2A":"Shift+Up",   "\x1b[1;2B":"Shift+Down",
    "\x1b[1;2C":"Shift+Right","\x1b[1;2D":"Shift+Left",
    # ctrl arrows
    "\x1b[1;5A":"Ctrl+Up",    "\x1b[1;5B":"Ctrl+Down",
    "\x1b[1;5C":"Ctrl+Right", "\x1b[1;5D":"Ctrl+Left",
    # alt arrows
    "\x1b[1;3A":"Alt+Up",     "\x1b[1;3B":"Alt+Down",
    "\x1b[1;3C":"Alt+Right",  "\x1b[1;3D":"Alt+Left",
}

_CTRL_MAP = {
    "\x01":"Ctrl+A", "\x02":"Ctrl+B", "\x03":"Ctrl+C", "\x04":"Ctrl+D",
    "\x05":"Ctrl+E", "\x06":"Ctrl+F", "\x07":"Ctrl+G", "\x08":"Backspace",
    "\x09":"Tab",    "\x0a":"Enter",  "\x0b":"Ctrl+K", "\x0c":"Ctrl+L",
    "\x0d":"Enter",  "\x0e":"Ctrl+N", "\x0f":"Ctrl+O", "\x10":"Ctrl+P",
    "\x11":"Ctrl+Q", "\x12":"Ctrl+R", "\x13":"Ctrl+S", "\x14":"Ctrl+T",
    "\x15":"Ctrl+U", "\x16":"Ctrl+V", "\x17":"Ctrl+W", "\x18":"Ctrl+X",
    "\x19":"Ctrl+Y", "\x1a":"Ctrl+Z", "\x1b":"Escape", "\x7f":"Backspace",
}

_SGR_MOUSE_RE = re.compile(r"\x1b\[<(\d+);(\d+);(\d+)([Mm])")


def parse_events(raw: bytes) -> list:
    """Parse raw bytes into a list of KeyEvent / MouseEvent."""
    events = []
    s = raw.decode("utf-8", errors="replace")
    i = 0
    while i < len(s):
        # SGR mouse: ESC [ < btn ; x ; y M/m
        m = _SGR_MOUSE_RE.match(s, i)
        if m:
            btn_raw = int(m.group(1))
            x = int(m.group(2)) - 1
            y = int(m.group(3)) - 1
            pressed = m.group(4) == "M"
            # strip modifier bits (shift=4, alt=8, ctrl=16) and drag bit (32)
            btn_code = btn_raw & 0x03   # base button: 0=left,1=mid,2=right
            is_scroll = bool(btn_raw & 0x40)  # scroll wheel flag
            drag  = bool(btn_raw & 0x20)
            shift = bool(btn_raw & 0x04)
            alt   = bool(btn_raw & 0x08)
            ctrl  = bool(btn_raw & 0x10)
            if is_scroll:
                button = MouseButton.SCROLL_UP if btn_code == 0 else MouseButton.SCROLL_DOWN
            elif btn_code == 0:
                button = MouseButton.LEFT
            elif btn_code == 1:
                button = MouseButton.MIDDLE
            elif btn_code == 2:
                button = MouseButton.RIGHT
            else:
                button = MouseButton.NONE
            events.append(MouseEvent(x=x, y=y, button=button, pressed=pressed,
                                     drag=drag, shift=shift, ctrl=ctrl, alt=alt))
            i = m.end()
            continue

        ch = s[i]

        # ESC sequences
        if ch == "\x1b" and i + 1 < len(s):
            rest = s[i:]
            matched = None
            for seq, name in sorted(_ESC_MAP.items(), key=lambda x: -len(x[0])):
                if rest.startswith(seq):
                    matched = (seq, name)
                    break
            if matched:
                seq, name = matched
                events.append(KeyEvent(key=name, char=None))
                i += len(seq)
                continue
            # Alt+char: ESC + printable
            if i + 1 < len(s) and s[i+1] != "\x1b":
                next_ch = s[i+1]
                events.append(KeyEvent(key=f"Alt+{next_ch}", char=next_ch, alt=True))
                i += 2
                continue

        # control chars
        if ch in _CTRL_MAP:
            name = _CTRL_MAP[ch]
            ctrl = name.startswith("Ctrl+")
            events.append(KeyEvent(key=name, char=None, ctrl=ctrl))
            i += 1
            continue

        # printable unicode (including emoji, CJK, etc.)
        events.append(KeyEvent(key=ch, char=ch))
        i += 1

    return events
