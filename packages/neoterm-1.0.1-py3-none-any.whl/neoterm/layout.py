"""
Flexbox-inspired layout engine.
Supports: direction row/column, flex-grow, align, justify, gap, padding, min/max size.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, List, Literal


@dataclass
class Rect:
    x: int = 0
    y: int = 0
    w: int = 0
    h: int = 0


@dataclass
class FlexStyle:
    direction:    Literal["row", "column"]  = "column"
    align:        Literal["start","center","end","stretch"] = "stretch"
    justify:      Literal["start","center","end","space-between","space-around","space-evenly"] = "start"
    flex_grow:    float  = 0.0
    flex_shrink:  float  = 1.0
    flex_basis:   Optional[int] = None     # explicit size on main axis
    gap:          int    = 0
    padding:      tuple  = (0, 0, 0, 0)   # top right bottom left
    min_w:        int    = 0
    min_h:        int    = 0
    max_w:        int    = 99999
    max_h:        int    = 99999
    width:        Optional[int] = None     # fixed width override
    height:       Optional[int] = None     # fixed height override


class LayoutNode:
    """
    A node in the layout tree.
    Each widget attaches one LayoutNode.
    After layout(), `rect` holds the computed position.
    """
    def __init__(self, style: Optional[FlexStyle] = None):
        self.style:    FlexStyle        = style or FlexStyle()
        self.children: List[LayoutNode] = []
        self.rect:     Rect             = Rect()
        self._widget   = None           # back-reference to widget

    def add(self, child: "LayoutNode"):
        self.children.append(child)
        return child

    def layout(self, x: int, y: int, avail_w: int, avail_h: int):
        s = self.style
        # apply fixed overrides
        if s.width  is not None: avail_w = s.width
        if s.height is not None: avail_h = s.height
        avail_w = max(s.min_w, min(s.max_w, avail_w))
        avail_h = max(s.min_h, min(s.max_h, avail_h))

        pt, pr, pb, pl = s.padding
        inner_w = max(0, avail_w - pl - pr)
        inner_h = max(0, avail_h - pt - pb)

        self.rect = Rect(x, y, avail_w, avail_h)

        if not self.children:
            return

        is_row = s.direction == "row"

        # ── measure children ──────────────────────────────────────────────
        # First pass: give each child its natural (basis) size on main axis
        total_gap    = s.gap * max(0, len(self.children) - 1)
        total_grow   = sum(c.style.flex_grow for c in self.children)
        base_sizes   = []   # main-axis size per child before flex

        for child in self.children:
            cs = child.style
            if cs.flex_basis is not None:
                base = cs.flex_basis
            elif is_row and cs.width is not None:
                base = cs.width
            elif not is_row and cs.height is not None:
                base = cs.height
            else:
                base = 0   # will be determined by flex grow or content
            base_sizes.append(base)

        fixed_total = sum(base_sizes) + total_gap
        free        = (inner_w if is_row else inner_h) - fixed_total

        # ── distribute free space to flex-grow children ───────────────────
        final_sizes = list(base_sizes)
        if free > 0 and total_grow > 0:
            for i, child in enumerate(self.children):
                if child.style.flex_grow > 0:
                    final_sizes[i] += int(free * child.style.flex_grow / total_grow)

        # ── cross-axis sizes ──────────────────────────────────────────────
        cross_total = inner_h if is_row else inner_w

        # ── justify: position along main axis ────────────────────────────
        total_main = sum(final_sizes) + total_gap
        leftover   = (inner_w if is_row else inner_h) - total_main

        justify_offsets = self._justify_offsets(
            leftover, len(self.children), s.justify, s.gap, final_sizes)

        # ── second pass: recurse into children ───────────────────────────
        for i, child in enumerate(self.children):
            cs = child.style
            main_size  = final_sizes[i]
            off        = justify_offsets[i]

            if is_row:
                cx = x + pl + off
                cy = y + pt
                cw = main_size
                ch = self._cross_size(cross_total, cs, is_row)
                cy += self._cross_offset(ch, cross_total, cs.align, s.align)
            else:
                cx = x + pl
                cy = y + pt + off
                cw = self._cross_size(cross_total, cs, is_row)
                ch = main_size
                cx += self._cross_offset(cw, cross_total, cs.align, s.align)

            child.layout(cx, cy, cw, ch)

    def _cross_size(self, cross_total, cs: FlexStyle, is_row: bool) -> int:
        if is_row:
            if cs.height is not None: return min(cs.height, cross_total)
            if cs.align in ("stretch", None): return cross_total
            return min(cross_total, max(cs.min_h, cs.max_h if cs.max_h < 99999 else cross_total))
        else:
            if cs.width is not None: return min(cs.width, cross_total)
            if cs.align in ("stretch", None): return cross_total
            return min(cross_total, max(cs.min_w, cs.max_w if cs.max_w < 99999 else cross_total))

    def _cross_offset(self, child_size, total, child_align, parent_align) -> int:
        align = child_align if child_align != "stretch" else parent_align
        if align == "center":
            return (total - child_size) // 2
        if align == "end":
            return total - child_size
        return 0

    def _justify_offsets(self, leftover, n, justify, gap, sizes) -> List[int]:
        offsets = []
        if justify == "start" or n == 0:
            pos = 0
            for s in sizes:
                offsets.append(pos)
                pos += s + gap
        elif justify == "end":
            pos = leftover
            for s in sizes:
                offsets.append(pos)
                pos += s + gap
        elif justify == "center":
            pos = leftover // 2
            for s in sizes:
                offsets.append(pos)
                pos += s + gap
        elif justify == "space-between":
            if n == 1:
                return [0]
            space = leftover // (n - 1)
            pos = 0
            for s in sizes:
                offsets.append(pos)
                pos += s + gap + space
        elif justify == "space-around":
            space = leftover // n
            pos = space // 2
            for s in sizes:
                offsets.append(pos)
                pos += s + gap + space
        elif justify == "space-evenly":
            space = leftover // (n + 1)
            pos = space
            for s in sizes:
                offsets.append(pos)
                pos += s + gap + space
        else:
            pos = 0
            for s in sizes:
                offsets.append(pos)
                pos += s + gap
        return offsets
