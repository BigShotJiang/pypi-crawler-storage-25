"""
Platform abstraction layer — Windows (WinAPI ReadConsoleInput) and Unix (termios/ANSI)

Windows mouse strategy:
  We use ReadConsoleInput() directly instead of msvcrt, which lets us receive
  MOUSE_EVENT records from the Win32 console API and convert them to the same
  SGR escape-sequence format that the event parser already understands.
  This works on Windows Terminal, PowerShell, CMD, and VS Code terminal.
"""
import sys
import os

IS_WINDOWS = sys.platform == "win32"

if IS_WINDOWS:
    import ctypes
    import ctypes.wintypes as wt
    import msvcrt

    # ── Win32 structs ────────────────────────────────────────────────────
    kernel32 = ctypes.windll.kernel32

    class _COORD(ctypes.Structure):
        _fields_ = [("X", ctypes.c_short), ("Y", ctypes.c_short)]

    class _KEY_EVENT_RECORD(ctypes.Structure):
        _fields_ = [
            ("bKeyDown",         wt.BOOL),
            ("wRepeatCount",     wt.WORD),
            ("wVirtualKeyCode",  wt.WORD),
            ("wVirtualScanCode", wt.WORD),
            ("uChar",            wt.WCHAR),
            ("dwControlKeyState",wt.DWORD),
        ]

    class _MOUSE_EVENT_RECORD(ctypes.Structure):
        _fields_ = [
            ("dwMousePosition",   _COORD),
            ("dwButtonState",     wt.DWORD),
            ("dwControlKeyState", wt.DWORD),
            ("dwEventFlags",      wt.DWORD),
        ]

    class _WINDOW_BUFFER_SIZE_RECORD(ctypes.Structure):
        _fields_ = [("dwSize", _COORD)]

    class _INPUT_UNION(ctypes.Union):
        _fields_ = [
            ("KeyEvent",              _KEY_EVENT_RECORD),
            ("MouseEvent",            _MOUSE_EVENT_RECORD),
            ("WindowBufferSizeEvent", _WINDOW_BUFFER_SIZE_RECORD),
            ("pad",                   ctypes.c_byte * 16),
        ]

    class INPUT_RECORD(ctypes.Structure):
        _fields_ = [("EventType", wt.WORD), ("Event", _INPUT_UNION)]

    KEY_EVENT                = 0x0001
    MOUSE_EVENT              = 0x0002
    WINDOW_BUFFER_SIZE_EVENT = 0x0004

    # mouse button state bits
    FROM_LEFT_1ST_BUTTON_PRESSED = 0x0001
    RIGHTMOST_BUTTON_PRESSED     = 0x0002
    FROM_LEFT_2ND_BUTTON_PRESSED = 0x0004

    # mouse event flags
    MOUSE_MOVED   = 0x0001
    DOUBLE_CLICK  = 0x0002
    MOUSE_WHEELED = 0x0004
    MOUSE_HWHEELED = 0x0008

    # control key state
    SHIFT_PRESSED     = 0x0010
    LEFT_CTRL_PRESSED = 0x0008
    LEFT_ALT_PRESSED  = 0x0002

    # VK codes → escape sequence mapping
    _VK_MAP = {
        0x25: "\x1b[D",   # Left
        0x26: "\x1b[A",   # Up
        0x27: "\x1b[C",   # Right
        0x28: "\x1b[B",   # Down
        0x24: "\x1b[H",   # Home
        0x23: "\x1b[F",   # End
        0x21: "\x1b[5~",  # PageUp
        0x22: "\x1b[6~",  # PageDown
        0x2D: "\x1b[2~",  # Insert
        0x2E: "\x1b[3~",  # Delete
        0x70: "\x1bOP",   # F1
        0x71: "\x1bOQ",   # F2
        0x72: "\x1bOR",   # F3
        0x73: "\x1bOS",   # F4
        0x74: "\x1b[15~", # F5
        0x75: "\x1b[17~", # F6
        0x76: "\x1b[18~", # F7
        0x77: "\x1b[19~", # F8
        0x78: "\x1b[20~", # F9
        0x79: "\x1b[21~", # F10
        0x7A: "\x1b[23~", # F11
        0x7B: "\x1b[24~", # F12
        0x09: "\x09",     # Tab
        0x0D: "\x0d",     # Enter  (VK_RETURN)
        0x08: "\x7f",     # Backspace
        0x1B: "\x1b",     # Escape
    }

else:
    import termios
    import tty
    import select
    import fcntl


# ── Previous mouse state (Windows) ───────────────────────────────────────────
if IS_WINDOWS:
    _prev_btn_state = 0


class Terminal:
    def __init__(self):
        self._old_settings     = None
        self._win_old_mode_in  = None
        self._win_old_mode_out = None
        self._h_in             = None
        self._prev_btn_state   = 0    # tracks last Windows mouse button state

    # ── public ───────────────────────────────────────────────────────────

    def enter_raw_mode(self):
        if IS_WINDOWS:
            self._enter_raw_windows()
        else:
            self._enter_raw_unix()

    def exit_raw_mode(self):
        if IS_WINDOWS:
            self._exit_raw_windows()
        else:
            self._exit_raw_unix()

    def get_size(self):
        if IS_WINDOWS:
            return self._get_size_windows()
        else:
            return self._get_size_unix()

    def read_input(self, timeout=0.02):
        """
        Non-blocking read.  Returns bytes (keyboard) or a special
        _MouseRecord namedtuple, or None.
        """
        if IS_WINDOWS:
            return self._read_windows(timeout)
        else:
            return self._read_unix(timeout)

    def write(self, data: str):
        sys.stdout.write(data)

    def flush(self):
        sys.stdout.flush()

    # ── Unix ──────────────────────────────────────────────────────────────

    def _enter_raw_unix(self):
        fd = sys.stdin.fileno()
        self._old_settings = termios.tcgetattr(fd)
        tty.setraw(fd)
        sys.stdout.write("\x1b[?1003h\x1b[?1006h")   # mouse: any-event + SGR
        sys.stdout.write("\x1b[?25l")                  # hide cursor
        sys.stdout.write("\x1b[?1049h")                # alternate screen
        sys.stdout.flush()

    def _exit_raw_unix(self):
        sys.stdout.write("\x1b[?1003l\x1b[?1006l\x1b[?25h\x1b[?1049l")
        sys.stdout.flush()
        if self._old_settings:
            termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, self._old_settings)

    def _get_size_unix(self):
        try:
            data = fcntl.ioctl(sys.stdout.fileno(), termios.TIOCGWINSZ, b'\x00' * 8)
            h, w = __import__('struct').unpack('HH', data[:4])
            return (w or 80), (h or 24)
        except Exception:
            return 80, 24

    def _read_unix(self, timeout):
        r, _, _ = select.select([sys.stdin], [], [], timeout)
        if r:
            return os.read(sys.stdin.fileno(), 256)
        return None

    # ── Windows ───────────────────────────────────────────────────────────

    def _enter_raw_windows(self):
        ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
        ENABLE_MOUSE_INPUT    = 0x0010
        ENABLE_EXTENDED_FLAGS = 0x0080
        ENABLE_WINDOW_INPUT   = 0x0008

        self._h_in  = kernel32.GetStdHandle(-10)
        h_out       = kernel32.GetStdHandle(-11)

        old_in  = wt.DWORD()
        old_out = wt.DWORD()
        kernel32.GetConsoleMode(self._h_in, ctypes.byref(old_in))
        kernel32.GetConsoleMode(h_out,      ctypes.byref(old_out))
        self._win_old_mode_in  = old_in.value
        self._win_old_mode_out = old_out.value

        # Output: enable VT sequences
        kernel32.SetConsoleMode(h_out,
            old_out.value | ENABLE_VIRTUAL_TERMINAL_PROCESSING)

        # Input: mouse + window resize (NO ENABLE_VIRTUAL_TERMINAL_INPUT —
        # that flag routes input as VT sequences bypassing ReadConsoleInput)
        kernel32.SetConsoleMode(self._h_in,
            ENABLE_MOUSE_INPUT | ENABLE_EXTENDED_FLAGS | ENABLE_WINDOW_INPUT)

        kernel32.SetConsoleOutputCP(65001)
        kernel32.SetConsoleCP(65001)

        # switch to alternate screen, hide cursor
        sys.stdout.write("\x1b[?25l\x1b[?1049h")
        sys.stdout.flush()

    def _exit_raw_windows(self):
        sys.stdout.write("\x1b[?25h\x1b[?1049l")
        sys.stdout.flush()
        if self._win_old_mode_in is not None:
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-10), self._win_old_mode_in)
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), self._win_old_mode_out)

    def _get_size_windows(self):
        class CONSOLE_SCREEN_BUFFER_INFO(ctypes.Structure):
            _fields_ = [
                ("dwSize",              _COORD),
                ("dwCursorPosition",    _COORD),
                ("wAttributes",         ctypes.c_ushort),
                ("srWindow",            ctypes.wintypes.SMALL_RECT),
                ("dwMaximumWindowSize", _COORD),
            ]
        csbi = CONSOLE_SCREEN_BUFFER_INFO()
        if kernel32.GetConsoleScreenBufferInfo(kernel32.GetStdHandle(-11), ctypes.byref(csbi)):
            w = csbi.srWindow.Right  - csbi.srWindow.Left + 1
            h = csbi.srWindow.Bottom - csbi.srWindow.Top  + 1
            return w, h
        return 80, 24

    def _read_windows(self, timeout):
        """
        Poll ReadConsoleInput.  Convert:
          KEY_EVENT   → bytes (same format event parser expects)
          MOUSE_EVENT → SGR escape bytes  ESC[<btn;x;yM/m
          RESIZE      → b'\x1b[RESIZE]' sentinel (handled in app)
        Returns None if nothing available within timeout.
        """
        global _prev_btn_state

        # Check if there are pending events (WaitForSingleObject)
        WAIT_OBJECT_0  = 0x00000000
        WAIT_TIMEOUT   = 0x00000102
        ms = max(0, int(timeout * 1000))
        result = kernel32.WaitForSingleObject(self._h_in, ms)
        if result != WAIT_OBJECT_0:
            return None

        records = (INPUT_RECORD * 32)()
        num_read = wt.DWORD(0)
        kernel32.ReadConsoleInputW(
            self._h_in, records, 32, ctypes.byref(num_read))

        output = bytearray()

        for i in range(num_read.value):
            rec = records[i]

            # ── Keyboard ─────────────────────────────────────────────────
            if rec.EventType == KEY_EVENT:
                ke = rec.Event.KeyEvent
                if not ke.bKeyDown:
                    continue

                vk   = ke.wVirtualKeyCode
                ch   = ke.uChar
                ctrl = ke.dwControlKeyState & LEFT_CTRL_PRESSED

                # Special keys → escape sequences
                if vk in _VK_MAP:
                    output += _VK_MAP[vk].encode()
                    continue

                # Ctrl+letter
                if ctrl and 0x41 <= vk <= 0x5A:
                    output += bytes([vk - 0x40])
                    continue

                # Printable unicode char
                if ch and ord(ch) >= 0x20:
                    output += ch.encode("utf-8", errors="replace")

            # ── Mouse ─────────────────────────────────────────────────────
            elif rec.EventType == MOUSE_EVENT:
                me = rec.Event.MouseEvent
                x  = me.dwMousePosition.X
                y  = me.dwMousePosition.Y
                bs = me.dwButtonState
                fl = me.dwEventFlags
                cs = me.dwControlKeyState

                shift = bool(cs & SHIFT_PRESSED)
                ctrl  = bool(cs & LEFT_CTRL_PRESSED)
                alt   = bool(cs & LEFT_ALT_PRESSED)
                mods  = (4 if shift else 0) | (8 if alt else 0) | (16 if ctrl else 0)

                if fl & MOUSE_WHEELED:
                    # High word of dwButtonState: positive = up, negative = down
                    delta = ctypes.c_int(bs).value
                    btn   = 64 if delta > 0 else 65
                    seq   = f"\x1b[<{btn | mods};{x+1};{y+1}M"
                    output += seq.encode()
                    continue

                if fl & MOUSE_MOVED:
                    # Drag if button held, else move
                    if bs & (FROM_LEFT_1ST_BUTTON_PRESSED | RIGHTMOST_BUTTON_PRESSED | FROM_LEFT_2ND_BUTTON_PRESSED):
                        btn = 32  # drag
                        if bs & RIGHTMOST_BUTTON_PRESSED:     btn = 34
                        elif bs & FROM_LEFT_2ND_BUTTON_PRESSED: btn = 33
                        seq = f"\x1b[<{btn | mods};{x+1};{y+1}M"
                        output += seq.encode()
                    else:
                        # plain move — send as button 35 (no button)
                        seq = f"\x1b[<{35 | mods};{x+1};{y+1}M"
                        output += seq.encode()
                    _prev_btn_state = bs
                    continue

                # Button press/release — detect by comparing with previous state
                changed = bs ^ _prev_btn_state
                _prev_btn_state = bs

                def _emit(btn_code, pressed):
                    final = "M" if pressed else "m"
                    return f"\x1b[<{btn_code | mods};{x+1};{y+1}{final}".encode()

                if changed & FROM_LEFT_1ST_BUTTON_PRESSED:
                    output += _emit(0, bool(bs & FROM_LEFT_1ST_BUTTON_PRESSED))
                if changed & FROM_LEFT_2ND_BUTTON_PRESSED:
                    output += _emit(1, bool(bs & FROM_LEFT_2ND_BUTTON_PRESSED))
                if changed & RIGHTMOST_BUTTON_PRESSED:
                    output += _emit(2, bool(bs & RIGHTMOST_BUTTON_PRESSED))

            # ── Resize ────────────────────────────────────────────────────
            elif rec.EventType == WINDOW_BUFFER_SIZE_EVENT:
                output += b'\x1b[RESIZE]'

        return bytes(output) if output else None


_terminal = Terminal()


def get_terminal():
    return _terminal
