"""
NeoTerm App — main event loop, window management, focus cycling, FPS limiter.
"""
from __future__ import annotations
import sys
import os
import time
import signal
import threading
from typing import Optional, List, Callable

from neoterm.terminal_platform import get_terminal
from neoterm.canvas   import Canvas
from neoterm.events   import parse_events, EventType, KeyEvent, MouseEvent, ResizeEvent
from neoterm.widgets  import Container, Widget
from neoterm.layout   import FlexStyle


def _check_terminal():
    """VS Code integrated terminal'ı blokla — diğer her terminal çalışır."""
    if os.environ.get("TERM_PROGRAM", "").lower() == "vscode":
        print("╔══════════════════════════════════════════════╗")
        print("║   NeoTerm — VS Code terminali desteklenmiyor ║")
        print("╠══════════════════════════════════════════════╣")
        print("║                                              ║")
        print("║  VS Code terminali mouse ve VT desteğini    ║")
        print("║  kısıtlıyor. Lütfen şunu kullan:            ║")
        print("║                                              ║")
        print("║   ✓  Windows Terminal   (Win+R → wt)        ║")
        print("║   ✓  PowerShell / CMD penceresi             ║")
        print("║   ✓  Alacritty / WezTerm / Kitty            ║")
        print("║                                              ║")
        print("╚══════════════════════════════════════════════╝")
        sys.exit(1)


class App:
    def __init__(self, fps: int = 30, bg=None):
        self.fps       = fps
        self.bg        = bg or (18, 18, 24)
        self._term     = get_terminal()
        self._running  = False
        self._root:    Optional[Container] = None
        self._canvas:  Optional[Canvas]    = None
        self._focus_list: List[Widget]     = []
        self._focus_idx:  int              = -1
        self._on_key:  Optional[Callable]  = None
        self._on_mouse:Optional[Callable]  = None
        self._overlays: List[Container]    = []
        self._dirty    = True

    # ── setup ─────────────────────────────────────────────────────────────

    def mount(self, root: Container):
        self._root = root

    def on_key(self, fn: Callable):
        self._on_key = fn

    def on_mouse(self, fn: Callable):
        self._on_mouse = fn

    def push_overlay(self, overlay: Container):
        self._overlays.append(overlay)

    def pop_overlay(self):
        if self._overlays:
            self._overlays.pop()

    # ── run ───────────────────────────────────────────────────────────────

    def run(self):
        _check_terminal()
        term = self._term
        term.enter_raw_mode()

        w, h = term.get_size()
        self._canvas = Canvas(w, h)

        # SIGWINCH (resize) — Unix only
        try:
            signal.signal(signal.SIGWINCH, self._on_sigwinch)
        except (AttributeError, OSError):
            pass

        self._running = True
        frame_time = 1.0 / self.fps
        last_frame = 0.0

        try:
            while self._running:
                now = time.monotonic()
                # process input
                raw = term.read_input(timeout=max(0, frame_time - (now - last_frame)))
                if raw:
                    if raw == b'\x1b[RESIZE]':
                        w2, h2 = term.get_size()
                        if self._canvas:
                            self._canvas.resize(w2, h2)
                    else:
                        for ev in parse_events(raw):
                            self._dispatch(ev)

                # render at target FPS
                now = time.monotonic()
                if now - last_frame >= frame_time:
                    self._render()
                    last_frame = now
        finally:
            term.exit_raw_mode()
            term.flush()

    def quit(self):
        self._running = False

    # ── internal ──────────────────────────────────────────────────────────

    def _on_sigwinch(self, *_):
        w, h = self._term.get_size()
        if self._canvas:
            self._canvas.resize(w, h)
        self._dirty = True

    def _render(self):
        canvas = self._canvas
        if canvas is None: return
        w, h = self._term.get_size()
        if canvas.width != w or canvas.height != h:
            canvas.resize(w, h)

        canvas.clear(self.bg)

        # layout and render root
        if self._root:
            self._root.node.layout(0, 0, w, h)
            self._root.render(canvas)

        # overlays on top
        for overlay in self._overlays:
            overlay.node.layout(0, 0, w, h)
            overlay.render(canvas)

        canvas.flush(self._term.write)
        self._term.flush()

    def _dispatch(self, ev):
        if isinstance(ev, KeyEvent):
            if ev.key in ("Ctrl+C", "Ctrl+Q"):
                self.quit(); return
            if ev.key == "Tab":
                self._cycle_focus(1); return
            if ev.key == "Shift+Tab":
                self._cycle_focus(-1); return
            if self._on_key:
                self._on_key(ev)
            # Send to whichever widget is focused (search whole focus list)
            self._build_focus_list()
            for w in self._focus_list:
                if w.focused:
                    w.handle_key(ev)
                    return
            # fallback: send to root/overlay
            top = self._overlays[-1] if self._overlays else self._root
            if top:
                top.handle_key(ev)

        elif isinstance(ev, MouseEvent):
            if self._on_mouse:
                self._on_mouse(ev)
            top = self._overlays[-1] if self._overlays else self._root
            if top:
                top.handle_mouse(ev)
                # focus clicked widget on left press
                if ev.button.value == 0 and ev.pressed:
                    self._focus_at(ev.x, ev.y, top)

        elif isinstance(ev, ResizeEvent):
            if self._canvas:
                self._canvas.resize(ev.width, ev.height)

    def _build_focus_list(self, container=None):
        root = container or (self._overlays[-1] if self._overlays else self._root)
        if root:
            self._focus_list = root.find_focusable()

    def _cycle_focus(self, direction: int):
        self._build_focus_list()
        if not self._focus_list: return
        if 0 <= self._focus_idx < len(self._focus_list):
            self._focus_list[self._focus_idx].focused = False
        self._focus_idx = (self._focus_idx + direction) % len(self._focus_list)
        self._focus_list[self._focus_idx].focused = True

    def _focus_at(self, x: int, y: int, container: Container):
        self._build_focus_list(container)
        for i, w in enumerate(self._focus_list):
            hit = w.hit_test(x, y)
            if hit and not w.focused:
                # unfocus all others first
                for other in self._focus_list:
                    other.focused = False
                w.focused = True
                self._focus_idx = i
                return
