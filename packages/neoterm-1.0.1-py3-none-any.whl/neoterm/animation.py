"""
Animation engine: keyframe timelines + easing functions.
Usage:
    anim = Animation()
    anim.add("opacity", [(0, 0.0), (0.5, 1.0)], easing="ease_out_cubic")
    val = anim.sample("opacity", t)
"""
from __future__ import annotations
import math
import time
from typing import Callable, Dict, List, Tuple, Optional


# ── easing functions ─────────────────────────────────────────────────────────

def _linear(t): return t
def _ease_in_quad(t): return t * t
def _ease_out_quad(t): return t * (2 - t)
def _ease_in_out_quad(t): return 2*t*t if t < 0.5 else -1+(4-2*t)*t
def _ease_in_cubic(t): return t**3
def _ease_out_cubic(t): return (t-1)**3 + 1
def _ease_in_out_cubic(t): return 4*t**3 if t < 0.5 else (t-1)*(2*t-2)**2+1
def _ease_in_back(t): c = 1.70158; return c*t*t*t - c*t*t  # type: ignore
def _ease_out_back(t): c = 1.70158; t-=1; return t*t*((c+1)*t+c)+1  # type: ignore
def _ease_out_bounce(t):
    if t < 1/2.75:   return 7.5625*t*t
    elif t < 2/2.75: t-=1.5/2.75;   return 7.5625*t*t+0.75
    elif t < 2.5/2.75: t-=2.25/2.75; return 7.5625*t*t+0.9375
    else:             t-=2.625/2.75; return 7.5625*t*t+0.984375
def _ease_in_elastic(t):
    if t==0 or t==1: return t
    return -(2**(10*(t-1))) * math.sin((t-1.1)*2*math.pi/0.4)
def _ease_out_elastic(t):
    if t==0 or t==1: return t
    return 2**(-10*t) * math.sin((t-0.1)*2*math.pi/0.4)+1

EASINGS: Dict[str, Callable] = {
    "linear":           _linear,
    "ease_in":          _ease_in_quad,
    "ease_out":         _ease_out_quad,
    "ease_in_out":      _ease_in_out_quad,
    "ease_in_cubic":    _ease_in_cubic,
    "ease_out_cubic":   _ease_out_cubic,
    "ease_in_out_cubic":_ease_in_out_cubic,
    "ease_in_back":     _ease_in_back,
    "ease_out_back":    _ease_out_back,
    "bounce":           _ease_out_bounce,
    "elastic_in":       _ease_in_elastic,
    "elastic_out":      _ease_out_elastic,
}


# ── Keyframe track ────────────────────────────────────────────────────────────

class Track:
    """A single animated property."""
    def __init__(self, keyframes: List[Tuple[float, float]],
                 easing: str = "ease_out_cubic",
                 loop: bool = False,
                 duration: Optional[float] = None):
        # keyframes = [(time_seconds, value), ...]
        self.keyframes = sorted(keyframes, key=lambda k: k[0])
        self.ease_fn   = EASINGS.get(easing, _ease_out_cubic)
        self.loop      = loop
        self.total     = duration if duration is not None else (
            self.keyframes[-1][0] if self.keyframes else 1.0)

    def sample(self, t: float) -> float:
        if not self.keyframes:
            return 0.0
        if self.loop and self.total > 0:
            t = t % self.total
        t = max(0.0, t)

        kf = self.keyframes
        if t <= kf[0][0]:
            return kf[0][1]
        if t >= kf[-1][0]:
            if self.loop:
                return kf[0][1]
            return kf[-1][1]

        for i in range(len(kf) - 1):
            t0, v0 = kf[i]
            t1, v1 = kf[i + 1]
            if t0 <= t <= t1:
                if t1 == t0:
                    return v1
                p = (t - t0) / (t1 - t0)
                p = max(0.0, min(1.0, self.ease_fn(p)))
                return v0 + (v1 - v0) * p
        return kf[-1][1]

    def finished(self, t: float) -> bool:
        if self.loop:
            return False
        return t >= (self.keyframes[-1][0] if self.keyframes else 0)


# ── Animation ─────────────────────────────────────────────────────────────────

class Animation:
    """
    Manages multiple tracks for one widget.
    start() resets the start time.
    """
    def __init__(self):
        self._tracks: Dict[str, Track] = {}
        self._start:  float = time.monotonic()
        self.running: bool  = True

    def start(self):
        self._start  = time.monotonic()
        self.running = True

    def add(self, prop: str,
            keyframes: List[Tuple[float, float]],
            easing: str = "ease_out_cubic",
            loop: bool = False,
            duration: Optional[float] = None):
        self._tracks[prop] = Track(keyframes, easing, loop, duration)

    def get(self, prop: str, default: float = 0.0) -> float:
        t = time.monotonic() - self._start
        track = self._tracks.get(prop)
        if track is None:
            return default
        return track.sample(t)

    def finished(self) -> bool:
        t = time.monotonic() - self._start
        return all(tr.finished(t) for tr in self._tracks.values())

    def elapsed(self) -> float:
        return time.monotonic() - self._start


# ── Shader system ─────────────────────────────────────────────────────────────
# Shaders take (x, y, t, cell) and return a modified Cell.

import colorsys
from neoterm.canvas import Cell

def hsv(h, s, v) -> Tuple[int, int, int]:
    r, g, b = colorsys.hsv_to_rgb(h % 1.0, s, v)
    return int(r*255), int(g*255), int(b*255)


def shader_rainbow(x, y, t, cell: Cell) -> Cell:
    """Cycling rainbow foreground, synced to x/y/t."""
    hue = (x * 0.05 + y * 0.03 + t * 0.4) % 1.0
    c = cell.copy()
    c.fg = hsv(hue, 0.9, 1.0)
    return c


def shader_wave_bg(x, y, t, cell: Cell) -> Cell:
    """Sinusoidal background colour wave."""
    import math
    v = (math.sin(x * 0.3 + t * 2.0) + math.sin(y * 0.5 + t * 1.5)) * 0.5 + 0.5
    c = cell.copy()
    r = int(10 + v * 30)
    g = int(10 + v * 20)
    b = int(30 + v * 60)
    c.bg = (r, g, b)
    return c


def shader_matrix(x, y, t, cell: Cell) -> Cell:
    """Classic green matrix rain effect."""
    import math, random
    c = cell.copy()
    seed = (x * 31 + y * 17) & 0xFFFF
    phase = (seed / 0xFFFF + t * 0.5) % 1.0
    brightness = max(0.0, math.sin(phase * math.pi * 2) ** 8)
    g = int(50 + brightness * 205)
    c.fg = (0, g, int(g * 0.3))
    return c


def shader_fire(x, y, t, cell: Cell) -> Cell:
    """Fire gradient rising from bottom."""
    import math
    c = cell.copy()
    h = (math.sin(x * 0.4 + t * 3.0) * 0.2 + y * 0.05 + t * 0.1) % 1.0
    hue = 0.05 * (1 - h)           # yellow → red
    sat = 0.9
    val = max(0.0, 1.0 - h * 1.5)
    c.fg = hsv(hue, sat, val)
    return c


def shader_scanline(x, y, t, cell: Cell) -> Cell:
    """CRT scanline overlay."""
    c = cell.copy()
    if int(y + t * 8) % 4 == 0:
        c.bg = (
            max(0, c.bg[0] - 30),
            max(0, c.bg[1] - 30),
            max(0, c.bg[2] - 30),
        )
    return c


def shader_neon_border(x, y, t, cell: Cell, width=1, height=1) -> Cell:
    """Glowing animated border. Pass canvas width/height as extra kwargs."""
    import math
    c = cell.copy()
    edge = (x < 2 or x >= width - 2 or y < 1 or y >= height - 1)
    if edge:
        hue = (t * 0.3 + x * 0.02 + y * 0.02) % 1.0
        c.fg = hsv(hue, 1.0, 1.0)
    return c


SHADERS = {
    "rainbow":     shader_rainbow,
    "wave":        shader_wave_bg,
    "matrix":      shader_matrix,
    "fire":        shader_fire,
    "scanline":    shader_scanline,
    "neon_border": shader_neon_border,
    "none":        lambda x, y, t, cell: cell,
}
