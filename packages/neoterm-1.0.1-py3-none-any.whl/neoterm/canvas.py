"""
Double-buffered terminal renderer.
Each character position is a Cell with full RGB colour, attributes, and Unicode.
Only changed cells are written to the terminal (diff rendering).
"""
from __future__ import annotations
import unicodedata
from dataclasses import dataclass, field
from typing import Tuple, Optional

# ── ANSI helpers ─────────────────────────────────────────────────────────────

def _rgb_fg(r, g, b):  return f"\x1b[38;2;{r};{g};{b}m"
def _rgb_bg(r, g, b):  return f"\x1b[48;2;{r};{g};{b}m"
_RESET = "\x1b[0m"

ATTR_BOLD      = 1 << 0
ATTR_ITALIC    = 1 << 1
ATTR_UNDERLINE = 1 << 2
ATTR_BLINK     = 1 << 3
ATTR_STRIKE    = 1 << 4
ATTR_DIM       = 1 << 5
ATTR_REVERSE   = 1 << 6

def _attr_seq(attrs: int) -> str:
    parts = []
    if attrs & ATTR_BOLD:      parts.append("1")
    if attrs & ATTR_DIM:       parts.append("2")
    if attrs & ATTR_ITALIC:    parts.append("3")
    if attrs & ATTR_UNDERLINE: parts.append("4")
    if attrs & ATTR_BLINK:     parts.append("5")
    if attrs & ATTR_REVERSE:   parts.append("7")
    if attrs & ATTR_STRIKE:    parts.append("9")
    return "\x1b[" + ";".join(parts) + "m" if parts else ""

def char_width(ch: str) -> int:
    """East-asian width: wide chars occupy 2 columns."""
    if not ch:
        return 1
    cp = ord(ch[0])
    if cp == 0:
        return 1
    eaw = unicodedata.east_asian_width(ch[0])
    return 2 if eaw in ("W", "F") else 1


# ── Cell ─────────────────────────────────────────────────────────────────────

@dataclass
class Cell:
    char:  str   = " "
    fg:    Tuple[int,int,int] = (204, 204, 204)
    bg:    Tuple[int,int,int] = (18,  18,  24)
    attrs: int   = 0
    width: int   = 1        # 1 or 2 (wide chars)

    def copy(self) -> "Cell":
        return Cell(self.char, self.fg, self.bg, self.attrs, self.width)

    def __eq__(self, other):
        if not isinstance(other, Cell):
            return False
        return (self.char == other.char and self.fg == other.fg
                and self.bg == other.bg and self.attrs == other.attrs)

_DEFAULT_CELL = Cell()


# ── Canvas ────────────────────────────────────────────────────────────────────

class Canvas:
    """
    Double-buffered screen.
    front  = what we WANT to display
    back   = what is CURRENTLY on screen
    flush() writes only the diff.
    """

    def __init__(self, width: int, height: int):
        self.width  = width
        self.height = height
        n = width * height
        self.front: list[Cell] = [Cell() for _ in range(n)]
        self.back:  list[Cell] = [Cell(char="\x00") for _ in range(n)]  # force full first paint
        self._clip_stack: list[tuple] = []
        self._needs_cls: bool = False

    def resize(self, width: int, height: int):
        self.width, self.height = width, height
        n = width * height
        self.front = [Cell() for _ in range(n)]
        # Force full repaint: sentinel char never matches any real cell
        self.back  = [Cell(char="\x00") for _ in range(n)]
        self._needs_cls = True  # erase stale terminal content on next flush

    # ── drawing primitives ──────────────────────────────────────────────

    def put(self, x: int, y: int, cell: Cell):
        if 0 <= x < self.width and 0 <= y < self.height:
            self.front[y * self.width + x] = cell
            if cell.width == 2 and x + 1 < self.width:
                # right half of wide char is a blank placeholder
                self.front[y * self.width + x + 1] = Cell(
                    char=" ", fg=cell.fg, bg=cell.bg, attrs=cell.attrs, width=0
                )

    def put_char(self, x: int, y: int, ch: str,
                 fg=(204,204,204), bg=(18,18,24), attrs=0):
        w = char_width(ch)
        self.put(x, y, Cell(ch, fg, bg, attrs, w))

    def fill(self, x: int, y: int, w: int, h: int,
             fg=(204,204,204), bg=(18,18,24), ch=" "):
        for row in range(y, min(y + h, self.height)):
            for col in range(x, min(x + w, self.width)):
                self.front[row * self.width + col] = Cell(ch, fg, bg)

    def text(self, x: int, y: int, s: str,
             fg=(204,204,204), bg=(18,18,24), attrs=0):
        cx = x
        for ch in s:
            if cx >= self.width:
                break
            w = char_width(ch)
            self.put(cx, y, Cell(ch, fg, bg, attrs, w))
            cx += w

    def hline(self, x: int, y: int, length: int,
              ch="─", fg=(100,100,120), bg=(18,18,24)):
        for i in range(length):
            self.put_char(x + i, y, ch, fg, bg)

    def vline(self, x: int, y: int, length: int,
              ch="│", fg=(100,100,120), bg=(18,18,24)):
        for i in range(length):
            self.put_char(x, y + i, ch, fg, bg)

    def box(self, x: int, y: int, w: int, h: int,
            fg=(100,100,120), bg=(18,18,24), style="rounded"):
        if style == "rounded":
            tl,tr,bl,br,hz,vt = "╭","╮","╰","╯","─","│"
        elif style == "double":
            tl,tr,bl,br,hz,vt = "╔","╗","╚","╝","═","║"
        elif style == "thick":
            tl,tr,bl,br,hz,vt = "┏","┓","┗","┛","━","┃"
        else:
            tl,tr,bl,br,hz,vt = "┌","┐","└","┘","─","│"
        # corners
        self.put_char(x,       y,       tl, fg, bg)
        self.put_char(x+w-1,   y,       tr, fg, bg)
        self.put_char(x,       y+h-1,   bl, fg, bg)
        self.put_char(x+w-1,   y+h-1,   br, fg, bg)
        # edges
        self.hline(x+1, y,     w-2, hz, fg, bg)
        self.hline(x+1, y+h-1, w-2, hz, fg, bg)
        self.vline(x,   y+1,   h-2, vt, fg, bg)
        self.vline(x+w-1, y+1, h-2, vt, fg, bg)

    def clear(self, bg=(18,18,24)):
        for i in range(len(self.front)):
            self.front[i] = Cell(bg=bg)

    # ── flush (diff render) ─────────────────────────────────────────────

    def flush(self, writer) -> int:
        """Write only changed cells. Returns number of cells written."""
        if self._needs_cls:
            writer("\x1b[2J")   # erase display — kills stale chars from old terminal size
            self._needs_cls = False
        out = []
        last_x = last_y = -99
        last_fg = last_bg = last_attrs = None
        written = 0

        for y in range(self.height):
            for x in range(self.width):
                idx = y * self.width + x
                f = self.front[idx]
                b = self.back[idx]

                if f == b:
                    continue
                if f.width == 0:   # right half of wide char, already written
                    self.back[idx] = f.copy()
                    continue

                # move cursor only if not consecutive
                if not (y == last_y and x == last_x):
                    out.append(f"\x1b[{y+1};{x+1}H")
                    last_fg = last_bg = last_attrs = None  # force colour reset after move

                # colour / attr
                needs_reset = (last_attrs is not None and last_attrs != 0 and f.attrs == 0)
                if needs_reset:
                    out.append(_RESET)
                    last_fg = last_bg = None
                    last_attrs = 0

                if f.attrs != last_attrs and f.attrs != 0:
                    out.append(_RESET)
                    out.append(_attr_seq(f.attrs))
                    last_fg = last_bg = None
                    last_attrs = f.attrs

                if f.fg != last_fg:
                    out.append(_rgb_fg(*f.fg))
                    last_fg = f.fg
                if f.bg != last_bg:
                    out.append(_rgb_bg(*f.bg))
                    last_bg = f.bg

                out.append(f.char if f.char else " ")
                last_x = x + (f.width if f.width >= 1 else 1)
                last_y = y

                self.back[idx] = f.copy()
                written += 1

        if out:
            out.append(_RESET)
            writer("".join(out))
        return written
