"""
NeoTerm — Rich terminal UI framework
Cross-platform (Windows/macOS/Linux)
Features: double-buffered renderer, flexbox layout, full Unicode + emoji,
          mouse support, GPU-style cell shaders, animation engine, image display.

Quick start:
    import neoterm as nt

    app = nt.App(fps=30)
    root = nt.Container(direction="column", border=True, title="My App")
    root.add(nt.Label("Hello, 🌍!", bold=True, align="center"))
    root.add(nt.Button("Quit", on_click=app.quit))
    app.mount(root)
    app.run()
"""

from neoterm.app      import App
from neoterm.widgets  import (
    Widget, Container, Label, Divider,
    Button, TextInput, ProgressBar, Spinner,
    Table, ScrollView, ImageWidget, Theme,
)
from neoterm.canvas   import Canvas, Cell, ATTR_BOLD, ATTR_ITALIC, ATTR_UNDERLINE, ATTR_REVERSE
from neoterm.layout   import FlexStyle, LayoutNode
from neoterm.animation import Animation, SHADERS, EASINGS
from neoterm.events   import KeyEvent, MouseEvent, MouseButton

T = Theme

__all__ = [
    "App", "Container", "Label", "Divider",
    "Button", "TextInput", "ProgressBar", "Spinner",
    "Table", "ScrollView", "ImageWidget",
    "Canvas", "Cell", "FlexStyle",
    "Animation", "SHADERS", "EASINGS",
    "KeyEvent", "MouseEvent", "MouseButton",
    "Theme", "T",
    "ATTR_BOLD", "ATTR_ITALIC", "ATTR_UNDERLINE", "ATTR_REVERSE",
]
