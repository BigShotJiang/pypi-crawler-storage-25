# Idempotency

Idempotency means that processing the same message more than once does not
create incorrect duplicate effects. For example, writing the same event twice
should not create two business records when the event represents one real
business action.

JetStream redelivery is normal in an at-least-once system. Redelivery may
happen after a process crash, NATS reconnect, ACK failure, destination timeout,
or successful destination commit followed by process failure before ACK.

The package prefers safe duplication over silent loss.

## Why Idempotency Is Required

`nats-sinks` ACKs after the destination commit. That avoids silent loss, but it
also means there is a small window where the destination has committed and the
ACK has not yet reached JetStream. If the process stops in that window, the
message can be redelivered. A correctly designed sink treats that duplicate as
safe.

```mermaid
sequenceDiagram
    participant JS as JetStream
    participant R as Runner
    participant D as Destination

    JS->>R: Deliver message #42
    R->>D: Commit message #42
    D-->>R: Commit succeeded
    R--xJS: Process exits before ACK
    JS->>R: Redeliver message #42
    R->>D: Duplicate-safe write
```

The duplicate must not corrupt state or create unwanted business effects.

## Common Strategy Names

The framework uses shared strategy names so future sinks can document familiar
behavior even when their destination-specific implementation differs.

### `stream_sequence`

Recommended for JetStream sinks. It uses:

- stream name,
- stream sequence.

This pair is stable for a message in a stream and maps naturally to a primary key.

### `message_id`

Uses a stable NATS message ID header. This is useful when producers already enforce message IDs.

### `payload_field`

Extracts a field from the normalized JSON payload value. This is useful for
business keys such as `order_id`, but it requires every message to carry the
expected field.

When a message body is non-JSON text or bytes, JSON-capable sinks may wrap it
in the nats-sinks JSON payload envelope. In that case, `payload_field` paths
refer to the envelope. For example, `payload` would refer to the wrapped text
value. For encrypted text and opaque payloads, prefer `stream_sequence` or
`message_id` idempotency because those strategies do not depend on decrypting
or interpreting the payload body.

## Duplicate Handling Modes

Duplicate handling is destination-specific. A relational database might use an
upsert or an insert-that-ignores-conflicts. An object store might use
deterministic object keys. An HTTP sink might use an idempotency-key header and
require the target service to honor it.

The important rule is destination-neutral: a sink must either make duplicate
redelivery safe or clearly document that a mode is not suitable for normal
production use.

## Production Recommendation

Use `stream_sequence` unless you have a strong reason to use producer-supplied
IDs. For each destination, choose a write mode that treats duplicate delivery
as success rather than creating duplicate business effects.

## Current Scope

The current production implementation is Oracle. Oracle duplicate handling is
documented in [Oracle Sink](https://github.com/ProjectCuillin/nats-sinks/blob/main/docs/oracle-sink.md), including `merge`,
`insert_ignore`, `insert`, and `append` behavior. Oracle-specific key-column
mapping and payload-field extraction are intentionally kept on that page so
future sinks can document their own backend-native approach without changing
this generic guide.

The generic core also protects idempotency by owning all acknowledgement
decisions. Sinks never receive raw NATS messages and cannot ACK early. If a sink
raises before durable success, the core leaves the message eligible for
redelivery. If a permanent failure is sent to a DLQ, the original message is
ACKed only after DLQ publication succeeds.

## Roadmap

Future idempotency work should focus on certifying every new sink, not only on
adding more strategy names. Planned areas include:

- per-route or per-table Oracle idempotency overrides,
- duplicate counters and metrics for Oracle duplicate handling,
- configurable Oracle `merge` update columns,
- Postgres `ON CONFLICT`-based duplicate handling,
- HTTP idempotency-key support and explicit warnings for unsafe endpoints,
- file and S3 sinks with deterministic keys and atomic overwrite-or-skip
  behavior,
- a reusable sink certification test suite that proves duplicate redelivery is
  safe before a sink is called production-ready.
