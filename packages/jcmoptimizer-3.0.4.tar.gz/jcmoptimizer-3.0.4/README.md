# JCMoptimizer Python Client #

This package implements a python client for interacting with the JCMoptimizer server. It provides a convenient interface to set up, run, and analyze numerical studies of expensive black box functions.

## Getting Started

### Cloud Service
The easiest way to get started is to use the free tier of the JCMwave's cloud service for JCMoptimizer:
* Install the `jcmoptimizer` package into your python environment, e.g. by running `pip install jcmoptimizer`.
* Signup to [optimizer.jcmwave.com](https://optimizer.jcmwave.com).
* Create an [API access token](https://optimizer.jcmwave.com/cloud/tokens/list/)

### Run JCMoptimizer Locally
For a self-hosted version, you need install JCMsuite and the JCMoptimizer extension for JCMsuite:
* Browse to the [JCMsuite download](https://installation.jcmwave.com/fb13885794fc64c42531c9656f8f6f73.php) page to install JCMsuite and to retrieve a demo or commercial license.
* Browse to the [JCMoptimizer download](https://optimizer.jcmwave.com/download) page to install JCMoptimizer.

### First Example
A basic usage example of the python package is given in the tutorial on a [Bayesian Optimization](https://optimizer.jcmwave.com/documentation/python/latest/tutorials/vanilla_bayesian_optimization.html).

## Documentation

For a comprehensive overview of all available classes, methods, and their parameters, please refer to the official JCMoptimizer Python documentation:

*   [JCMoptimizer Python Interface Documentation](https://optimizer.jcmwave.com/documentation/python/latest/interface/index.html)
*   [JCMoptimizer Python Tutorials](https://optimizer.jcmwave.com/documentation/python/latest/tutorials/index.html)

These resources provide detailed explanations and examples for advanced usage, including different drivers.
