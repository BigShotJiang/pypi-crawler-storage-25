from fasr_vad_marblenet.models.vad import MarbleNetForVAD

__all__ = ["MarbleNetForVAD"]
