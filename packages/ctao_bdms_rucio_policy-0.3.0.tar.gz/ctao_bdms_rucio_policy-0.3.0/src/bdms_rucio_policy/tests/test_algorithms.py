import pytest

long_lfn = "/ctao/test/telescope/TEL001/events/2024/06/17/TEL001_SDH001_20240617T030105_SBID2000012345_OBSID2000006789_TEL_SHOWER_CHUNK000.fits.fz"
lfns = {
    "/ctao.org/foo/foo.dat": "foo",
    "/ctao.org/bar/test.dat": "bar",
    long_lfn: "test",
    # special handling
    "/ctao.dpps.test/": "root",
    "/ctao.dpps.test": "root",
    "/": "root",
    # scope given explicitly
    "foo:/ctao.org/foo/foo.dat": "foo",
    "bar:/ctao.org/bar/foo.dat": "bar",
    # user scopes
    "/ctao.org/user": "root",
    "/ctao.org/user/a": "root",
    "/ctao.org/user/e": "root",
    "/ctao.org/user/a/aeinstein": "user.aeinstein",
    "/ctao.org/user/e/efermi": "user.efermi",
    "/ctao.org/user/a/aeinstein/example_file.fits": "user.aeinstein",
    "/ctao.org/user/e/efermi/some/deep/example/file.h5": "user.efermi",
}


@pytest.mark.parametrize(("did", "expected_scope"), lfns.items())
def test_extract_scope_ctao(did, expected_scope):
    from bdms_rucio_policy.scope import scope as extract_scope

    _, _, expected_lfn = did.rpartition(":")
    scope, name = extract_scope(did, scopes=None)
    assert scope == expected_scope
    assert name == expected_lfn


def test_extract_scope_ctao_invalid():
    from bdms_rucio_policy.scope import scope as extract_scope

    with pytest.raises(ValueError, match="DID 'test:foo.dat' does not match"):
        extract_scope("test:foo.dat", scopes=None)

    with pytest.raises(ValueError, match="DID 'test/bar/baz' does not match"):
        extract_scope("test/bar/baz", scopes=None)

    with pytest.raises(
        ValueError, match="Given scope 'foo' does not match extracted scope 'bar'"
    ):
        extract_scope("foo:/ctao.org/bar/test.dat", scopes=None)

    with pytest.raises(
        ValueError, match="Given scope 'foo' does not match extracted scope 'root'"
    ):
        extract_scope("foo:/ctao.org/", scopes=None)


@pytest.mark.parametrize(("did", "expected_scope"), lfns.items())
def test_extract_scope_via_rucio(did, expected_scope):
    from rucio.common.utils import extract_scope

    _, _, expected_lfn = did.rpartition(":")
    scope, name = extract_scope(did, scopes=None)
    assert scope == expected_scope
    assert name == expected_lfn
