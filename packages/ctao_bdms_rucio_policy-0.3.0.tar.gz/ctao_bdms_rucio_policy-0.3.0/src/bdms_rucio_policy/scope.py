"""Default extract_scope."""

from collections.abc import Sequence
from typing import Optional

__all__ = [
    "scope",
]


def _extract_scope_from_lfn(lfn: str) -> str:
    """Extract scope from LFN."""
    components = [comp for comp in lfn.split("/") if comp != ""]

    # if no "scope" is in the did, e.g. it's just the vo or another path
    # we return the special "root" scope. Needed as the DIRAC integration
    # needs a container to exist with DID /<VO> and that should belong to
    # the scope "root" owned by the admin user.
    if len(components) < 2:
        return "root"

    # /<vo>/user/... case
    if components[1] == "user":
        # only a base path, /<vo/user or /<vo>/user/<first letter>/
        if len(components) < 4:
            return "root"

        # full user path, /<vo>/user/<username[0]>/<username>/...
        username = components[3]
        return f"user.{username}"

    return components[1]


def scope(did: str, scopes: Optional[Sequence[str]]) -> tuple[str, str]:
    """Scope extraction algorithm for CTAO.

    Assumes LFNs of the form ``/<VO Name>/<scope>/<path>``.

    User's personal data is assumed to be in ``/<VO name>/user/<username[0]>/<username>/``,
    as assumed by DIRAC. This will return a scope ``user.<username>``

    Input can either be an LFN or of form ``'<scope>:<lfn>'``.
    """
    given_scope, _, lfn = did.rpartition(":")

    if not lfn.startswith("/"):
        msg = f"DID {did!r} does not match expected schema: /<VO Name>/<scope>/<path>."
        raise ValueError(msg)

    scope = _extract_scope_from_lfn(lfn)

    if given_scope != "" and scope != given_scope:
        msg = f"Given scope '{given_scope}' does not match extracted scope '{scope}'"
        raise ValueError(msg)

    return scope, lfn
