"""Transcendence Memory Server — self-hosted multimodal RAG memory service."""
__version__ = "0.12.0"
