from wilfie_cli.main import cli


if __name__ == "__main__":
    raise SystemExit(cli())
