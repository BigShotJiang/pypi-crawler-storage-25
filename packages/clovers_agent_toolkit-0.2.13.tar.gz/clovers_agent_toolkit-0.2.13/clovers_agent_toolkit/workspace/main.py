from pathlib import Path
from clovers_agent import CloversAgent, Event
from clovers_agent.config import CONFIG as AGENT_CONFIG
from clovers.logger import logger
from .docker import Shell
from ..toolkit import TOOLS, CONFIG

WORKSPACE = Path(AGENT_CONFIG.path) / "workspace"
README = WORKSPACE / "README.md"


def format_path(path: str):
    return f".{path[10:]}" if path.startswith("/workspace") else path.lstrip("/\\")


@TOOLS.create_category("workspace", "包含文件读写与发送、命令执行等工具，用于进行相关工作。")
async def _(agent: CloversAgent, event: Event):
    if not WORKSPACE.exists():
        WORKSPACE.mkdir(parents=True, exist_ok=True)
    if not README.exists():
        README.write_text("Clovers Agent Workspace")
    if CONFIG.use_shell:
        session_id = agent.session_id(event)
        session = agent.current_session(event)
        if "shell" not in session.extra:
            try:
                shell = Shell(session_id, WORKSPACE)
            except Exception as e:
                logger.error(e)
                return f"workspace 已初始化, shell 初始化失败，此工作区无法执行命令。\n当前工作目录: /workspace"
            session.extra["shell"] = shell
        session.extra["shell"].workdir = "/workspace"
        return f"workspace 已初始化，当前系统：Debian\n当前工作目录: /workspace"
    else:
        return f"workspace 已初始化\n当前工作目录: /workspace"


if CONFIG.use_shell:

    @TOOLS.register(
        "shell",
        "在工作区环境下执行命令",
        {"command": {"type": "string", "description": "需要执行的命令，如需要执行多条命令，请使用 `&&` 或 `;`隔开"}},
        "workspace",
    )
    async def _(agent: CloversAgent, event: Event, command: str):
        extra = agent.current_session(event).extra
        if "shell" not in extra or not isinstance(shell := extra["shell"], Shell):
            return f"Error: shell 初始化失败，请返回故障原因。在故障排除前不要重复调用此方法。"
        output = await shell.execute(command)
        return f"{output}\n当前工作目录: {shell.workdir}"

else:

    @TOOLS.register(
        "ls",
        "查看工作区文件",
        {"path": {"type": "string", "description": "需要查看的目录路径"}},
        "workspace",
    )
    async def _(agent: CloversAgent, event: Event, path: str):
        folder = WORKSPACE / agent.session_id(event) / format_path(path)
        if not folder.exists():
            return f"路径 '{path}' 不存在。"
        files = []
        for file in folder.rglob("*"):
            if file.is_file():
                files.append(str(file.relative_to(folder)))
        return f"路径 '{path}' 下的文件列表：\n{"\n".join(files)}"


def read_text(file: Path):
    for encoding in ["utf-8", None, "ansi"]:
        try:
            return file.read_text(encoding=encoding)
        except UnicodeDecodeError:
            continue
        except Exception as e:
            logger.error(f"文件读取失败: {e}")
            return ""


@TOOLS.register(
    "read_files",
    "读取并查看指定文件的内容。支持同时传入多个路径以一次性查看多个文件。",
    {"filepaths": {"type": "array", "description": "包含一个或多个文件路径的数组", "items": {"type": "string"}}},
    "workspace",
)
async def _(agent: CloversAgent, event: Event, filepaths: list[str]):
    workspace = WORKSPACE / agent.session_id(event)
    md = []
    for file_path in filepaths:
        file = workspace / format_path(file_path)
        if not file.is_relative_to(workspace):
            md.append(f"{file_path} 非工作区文件")
        if not file.exists():
            md.append(f"{file_path} 文件不存在")
            continue
        md.append(f"```{file_path}\n{read_text(file)}\n```")
    return "\n\n".join(md)


@TOOLS.register(
    "write_file",
    "写入文件",
    {
        "file_path": {"type": "string", "description": "需要写入的文件路径"},
        "file_content": {"type": "string", "description": "需要写入到文件的内容"},
    },
    "workspace",
)
async def _(agent: CloversAgent, event: Event, file_path: str, file_content: str):
    file = WORKSPACE / agent.session_id(event) / format_path(file_path)
    file.parent.mkdir(parents=True, exist_ok=True)
    try:
        file.write_text(file_content, encoding="utf-8")
        return f"文件写入成功。"
    except Exception as e:
        logger.error(e)
        return f"文件写入失败：{e}"


@TOOLS.register(
    "upload_file",
    "把文件上传给用户。注意助手工作区对用户不可见，如用户要求助手发送文件则必须使用此工具。",
    {"file_path": {"type": "string", "description": "需要上传的的文件路径"}},
    "workspace",
)
async def _(agent: CloversAgent, event: Event, file_path: str):
    workspace = WORKSPACE / agent.session_id(event)
    file = workspace / format_path(file_path)
    if not file.is_relative_to(workspace):
        return f"{file_path} 非工作区文件"
    if not file.exists():
        return f"{file_path} 文件不存在"
    if (coro := event.send("file", file)) is None:
        return "未实现上传文件接口"
    try:
        await coro
    except Exception as e:
        return f"上传失败：{e}"
    return "上传成功！"
