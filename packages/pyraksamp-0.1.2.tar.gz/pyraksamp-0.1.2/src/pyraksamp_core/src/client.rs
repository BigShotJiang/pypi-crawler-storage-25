//! SA:MP 0.3.7 pure-Rust client — port of client.cpp.

use std::net::{IpAddr, Ipv4Addr, SocketAddr, TcpStream, ToSocketAddrs, UdpSocket};
use std::sync::atomic::{AtomicBool, AtomicU16, AtomicU32, AtomicU8, Ordering};
use std::sync::{Arc, Mutex, OnceLock};
use std::time::{Duration, Instant};
use std::{fmt, io};

// RakNet::GetTime() returns ms elapsed since the first call (process-relative),
// not since the UNIX epoch. We replicate that by anchoring to the first use.
static RAKNET_EPOCH: OnceLock<Instant> = OnceLock::new();

fn raknet_time_ms() -> u32 {
    RAKNET_EPOCH.get_or_init(Instant::now).elapsed().as_millis() as u32
}

use crate::socks5;

use crate::bitstream::BitStream;
use crate::encrypt::{auth_response as samp_auth_response, encrypt as samp_encrypt};
use crate::reliability::{make_ack, make_packet, parse as rel_parse, SplitBuffer};

// ── Packet IDs ────────────────────────────────────────────────────────────────
const ID_INTERNAL_PING: u8 = 6;
const ID_CONNECTED_PONG: u8 = 9;
const ID_CONNECTION_REQUEST: u8 = 11;
const ID_AUTH_KEY: u8 = 12;
const ID_RPC: u8 = 20;
const ID_OPEN_CONNECTION_REQUEST: u8 = 24;
const ID_OPEN_CONNECTION_REPLY: u8 = 25;
const ID_OPEN_CONNECTION_COOKIE: u8 = 26;
const ID_CONNECTION_ATTEMPT_FAILED: u8 = 29;
const ID_NEW_INCOMING_CONNECTION: u8 = 30;
const ID_NO_FREE_INCOMING_CONNECTIONS: u8 = 31;
const ID_DISCONNECTION_NOTIFICATION: u8 = 32;
const ID_CONNECTION_LOST: u8 = 33;
const ID_CONNECTION_REQUEST_ACCEPTED: u8 = 34;
const ID_CONNECTION_BANNED: u8 = 36;
const ID_INVALID_PASSWORD: u8 = 37;
const ID_TIMESTAMP: u8 = 40;
const ID_VEHICLE_SYNC: u8 = 200;
const ID_PLAYER_SYNC: u8 = 207;
const ID_PASSENGER_SYNC: u8 = 211;
const ID_SPECTATOR_SYNC: u8 = 212;

// ── RPC IDs ──────────────────────────────────────────────────────────────────
const RPC_SERVER_JOIN: u8 = 137;
const RPC_SERVER_QUIT: u8 = 138;
const RPC_INIT_GAME: u8 = 139;
const RPC_CONNECTION_REJ: u8 = 130;
const RPC_CHAT: u8 = 101;
const RPC_CLIENT_MESSAGE: u8 = 93;
const RPC_DIALOG_BOX: u8 = 61;
const RPC_GAME_TEXT: u8 = 73;
const RPC_SET_HEALTH: u8 = 14;
const RPC_SET_ARMOUR: u8 = 66;
const RPC_SET_POSITION: u8 = 12;
const RPC_SET_CHECKPOINT: u8 = 107;
const RPC_DISABLE_CHECKPOINT: u8 = 37;
const RPC_WORLD_PLAYER_ADD: u8 = 32;
const RPC_WORLD_PLAYER_REMOVE: u8 = 163;
const RPC_SET_PLAYER_NAME: u8 = 11;
const RPC_TOGGLE_CONTROLLABLE: u8 = 15;
const RPC_SET_PLAYER_TIME: u8 = 29;
const RPC_SEND_DEATH_MESSAGE: u8 = 55;
const RPC_SET_ARMED_WEAPON: u8 = 67;
const RPC_SET_SPAWN_INFO: u8 = 68;
const RPC_SET_PLAYER_TEAM: u8 = 69;
const RPC_PUT_IN_VEHICLE: u8 = 70;
const RPC_REMOVE_FROM_VEHICLE: u8 = 71;
const RPC_SET_PLAYER_COLOR: u8 = 72;
const RPC_SET_VIRTUAL_WORLD: u8 = 48;
const RPC_SET_WORLD_TIME: u8 = 94;
const RPC_TOGGLE_SPECTATING: u8 = 124;
const RPC_SET_WANTED_LEVEL: u8 = 133;
const RPC_SET_WEAPON_AMMO: u8 = 145;
const RPC_SET_GRAVITY: u8 = 146;
const RPC_SET_WEATHER: u8 = 152;
const RPC_SET_PLAYER_SKIN: u8 = 153;
const RPC_SET_INTERIOR: u8 = 156;
const RPC_WORLD_VEHICLE_ADD: u8 = 164;
const RPC_WORLD_VEHICLE_REMOVE: u8 = 165;
const RPC_DEATH_BROADCAST: u8 = 166;

// Client→server: acknowledge interior change (SAMPRPC.cpp: RPC_SetInteriorId = 118)
const RPC_INTERIOR_CHANGE_NOTIFY: u8 = 118;
const RPC_SET_PLAYER_FACING_ANGLE: u8 = 19;
const ID_AIM_SYNC: u8 = 203;

const RPC_CLIENT_JOIN: u8 = 25;
const RPC_REQUEST_CLASS: u8 = 128;
const RPC_REQUEST_SPAWN: u8 = 129;
const RPC_SPAWN: u8 = 52;
const RPC_DIALOG_RESPONSE: u8 = 62;
const RPC_DEATH: u8 = 53;
const RPC_ENTER_VEHICLE: u8 = 26;
const RPC_EXIT_VEHICLE: u8 = 154;
const RPC_SERVER_COMMAND: u8 = 50;
const RPC_UPDATE_SCORES: u8 = 155;

// TextDraw RPCs
const RPC_CLIENT_CHECK: u8 = 103;
const RPC_FORCE_CLASS_SELECTION: u8 = 74;
const RPC_GAME_MODE_RESTART: u8 = 40;

const ID_WEAPONS_UPDATE: u8 = 204;
const ID_STATS_UPDATE: u8 = 205;

// TextDraw RPCs
const RPC_TEXTDRAW_SHOW: u8 = 134;
const RPC_TEXTDRAW_HIDE: u8 = 135;
const RPC_TEXTDRAW_EDIT: u8 = 105;
const RPC_TEXTDRAW_TOGGLE_SELECT: u8 = 83;
const RPC_TEXTDRAW_SELECT: u8 = 83;

const NETGAME_VERSION: u32 = 4057;
const NETCODE_CONNCOOKIELULZ: u16 = 0x6969;
const DEFAULT_GPCI: &str = "3E9B8D0C4A7F2E6B1D5A3C9E8F2B4D6A0C7E9B3";

// Reliability constants (SAMP legacy offset)
const REL_UNRELIABLE: u8 = 6;
const REL_UNRELIABLE_SEQUENCED: u8 = 7;
const REL_RELIABLE: u8 = 8;
const REL_RELIABLE_ORDERED: u8 = 9;
const REL_RELIABLE_SEQUENCED: u8 = 10;

// ── Callbacks ─────────────────────────────────────────────────────────────────

#[allow(clippy::type_complexity)]
pub struct Callbacks {
    pub on_connect: Option<Arc<dyn Fn() + Send + Sync>>,
    pub on_disconnect: Option<Arc<dyn Fn() + Send + Sync>>,
    pub on_rpc: Option<Arc<dyn Fn(u8, Vec<u8>) + Send + Sync>>,
    pub on_player_join: Option<Arc<dyn Fn(u16, String) + Send + Sync>>,
    pub on_player_quit: Option<Arc<dyn Fn(u16, u8) + Send + Sync>>,
    pub on_chat: Option<Arc<dyn Fn(u16, Vec<u8>) + Send + Sync>>,
    pub on_client_message: Option<Arc<dyn Fn(u32, Vec<u8>) + Send + Sync>>,
    pub on_dialog: Option<Arc<dyn Fn(u16, u8, Vec<u8>, Vec<u8>, Vec<u8>, Vec<u8>) + Send + Sync>>,
    pub on_game_text: Option<Arc<dyn Fn(i32, i32, String) + Send + Sync>>,
    pub on_set_health: Option<Arc<dyn Fn(f32) + Send + Sync>>,
    pub on_set_armour: Option<Arc<dyn Fn(f32) + Send + Sync>>,
    pub on_set_position: Option<Arc<dyn Fn(f32, f32, f32) + Send + Sync>>,
    pub on_checkpoint: Option<Arc<dyn Fn(f32, f32, f32, f32) + Send + Sync>>,
    pub on_checkpoint_disabled: Option<Arc<dyn Fn() + Send + Sync>>,
    pub on_player_streamed_in:
        Option<Arc<dyn Fn(u16, u8, i32, f32, f32, f32, f32, u32, u8) + Send + Sync>>,
    pub on_player_streamed_out: Option<Arc<dyn Fn(u16) + Send + Sync>>,
    pub on_player_name: Option<Arc<dyn Fn(u16, String, u8) + Send + Sync>>,
    pub on_toggle_controllable: Option<Arc<dyn Fn(u8) + Send + Sync>>,
    pub on_player_time: Option<Arc<dyn Fn(u8, u8) + Send + Sync>>,
    pub on_death_message: Option<Arc<dyn Fn(u16, u16, u8) + Send + Sync>>,
    pub on_set_armed_weapon: Option<Arc<dyn Fn(u32) + Send + Sync>>,
    pub on_spawn_info: Option<
        Arc<dyn Fn(u8, u32, f32, f32, f32, f32, u32, u32, u32, u32, u32, u32) + Send + Sync>,
    >,
    pub on_player_team: Option<Arc<dyn Fn(u16, u8) + Send + Sync>>,
    pub on_put_in_vehicle: Option<Arc<dyn Fn(u16, u8) + Send + Sync>>,
    pub on_remove_from_vehicle: Option<Arc<dyn Fn() + Send + Sync>>,
    pub on_player_color: Option<Arc<dyn Fn(u16, u32) + Send + Sync>>,
    pub on_world_time: Option<Arc<dyn Fn(u8) + Send + Sync>>,
    pub on_toggle_spectating: Option<Arc<dyn Fn(bool) + Send + Sync>>,
    pub on_wanted_level: Option<Arc<dyn Fn(u8) + Send + Sync>>,
    pub on_weapon_ammo: Option<Arc<dyn Fn(u8, u16) + Send + Sync>>,
    pub on_gravity: Option<Arc<dyn Fn(f32) + Send + Sync>>,
    pub on_weather: Option<Arc<dyn Fn(u8) + Send + Sync>>,
    pub on_player_skin: Option<Arc<dyn Fn(i32, u32) + Send + Sync>>,
    pub on_set_interior: Option<Arc<dyn Fn(u8) + Send + Sync>>,
    pub on_set_virtual_world: Option<Arc<dyn Fn(i32) + Send + Sync>>,
    pub on_vehicle_streamed_in: Option<
        Arc<
            dyn Fn(
                    u16,
                    i32,
                    f32,
                    f32,
                    f32,
                    f32,
                    u8,
                    u8,
                    f32,
                    u8,
                    u32,
                    u32,
                    u8,
                    u8,
                    u8,
                    u8,
                    u32,
                    u32,
                ) + Send
                + Sync,
        >,
    >,
    pub on_vehicle_streamed_out: Option<Arc<dyn Fn(u16) + Send + Sync>>,
    pub on_player_death: Option<Arc<dyn Fn(u16) + Send + Sync>>,
    pub on_textdraw_show: Option<
        Arc<
            dyn Fn(
                    u16,
                    u8,
                    f32,
                    f32,
                    u32,
                    f32,
                    f32,
                    u32,
                    u8,
                    u8,
                    u32,
                    u8,
                    u8,
                    f32,
                    f32,
                    u16,
                    f32,
                    f32,
                    f32,
                    f32,
                    i16,
                    i16,
                    String,
                ) + Send
                + Sync,
        >,
    >,
    pub on_textdraw_hide: Option<Arc<dyn Fn(u16) + Send + Sync>>,
    pub on_textdraw_edit: Option<Arc<dyn Fn(u16, String) + Send + Sync>>,
    pub on_textdraw_toggle_select: Option<Arc<dyn Fn(bool, u32) + Send + Sync>>,
}

impl Default for Callbacks {
    fn default() -> Self {
        Self::new()
    }
}

impl Callbacks {
    pub fn new() -> Self {
        Callbacks {
            on_connect: None,
            on_disconnect: None,
            on_rpc: None,
            on_player_join: None,
            on_player_quit: None,
            on_chat: None,
            on_client_message: None,
            on_dialog: None,
            on_game_text: None,
            on_set_health: None,
            on_set_armour: None,
            on_set_position: None,
            on_checkpoint: None,
            on_checkpoint_disabled: None,
            on_player_streamed_in: None,
            on_player_streamed_out: None,
            on_player_name: None,
            on_toggle_controllable: None,
            on_player_time: None,
            on_death_message: None,
            on_set_armed_weapon: None,
            on_spawn_info: None,
            on_player_team: None,
            on_put_in_vehicle: None,
            on_remove_from_vehicle: None,
            on_player_color: None,
            on_world_time: None,
            on_toggle_spectating: None,
            on_wanted_level: None,
            on_weapon_ammo: None,
            on_gravity: None,
            on_weather: None,
            on_player_skin: None,
            on_set_interior: None,
            on_set_virtual_world: None,
            on_vehicle_streamed_in: None,
            on_vehicle_streamed_out: None,
            on_player_death: None,
            on_textdraw_show: None,
            on_textdraw_hide: None,
            on_textdraw_edit: None,
            on_textdraw_toggle_select: None,
        }
    }
}

// Helper: clone a callback from the mutex without holding the lock when calling.
macro_rules! fire {
    ($cbs:expr, $field:ident) => {{
        let cb = $cbs.lock().unwrap().$field.clone();
        if let Some(cb) = cb { cb(); }
    }};
    ($cbs:expr, $field:ident, $($arg:expr),+) => {{
        let cb = $cbs.lock().unwrap().$field.clone();
        if let Some(cb) = cb { cb($($arg),+); }
    }};
}

// ── Connect errors ────────────────────────────────────────────────────────────

#[derive(Debug)]
pub enum ConnectError {
    /// Server hostname could not be resolved (or is not IPv4).
    HostResolution,
    /// Could not bind the local UDP socket.
    SocketBind(io::Error),
    /// SOCKS5 proxy handshake failed.
    Proxy(io::Error),
    /// Server did not complete the open-connection handshake in time.
    HandshakeTimeout,
    /// Server did not accept the connection request in time.
    ConnectionTimeout,
    /// Server actively refused the connection attempt.
    Rejected,
    /// Client is banned from the server.
    Banned,
    /// Wrong server password.
    InvalidPassword,
    /// Server has no free player slots.
    NoFreeSlots,
}

impl fmt::Display for ConnectError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ConnectError::HostResolution => write!(f, "could not resolve server host"),
            ConnectError::SocketBind(e) => write!(f, "failed to bind UDP socket: {e}"),
            ConnectError::Proxy(e) => write!(f, "SOCKS5 proxy error: {e}"),
            ConnectError::HandshakeTimeout => write!(f, "connection handshake timed out"),
            ConnectError::ConnectionTimeout => write!(f, "connection request timed out"),
            ConnectError::Rejected => write!(f, "connection attempt failed"),
            ConnectError::Banned => write!(f, "banned from server"),
            ConnectError::InvalidPassword => write!(f, "invalid server password"),
            ConnectError::NoFreeSlots => write!(f, "server is full"),
        }
    }
}

impl std::error::Error for ConnectError {}

// ── Network helpers ───────────────────────────────────────────────────────────

struct NetState {
    sock: Arc<UdpSocket>,
    server_addr: SocketAddr,
    /// SOCKS5: relay address to send UDP datagrams to.
    relay_addr: Option<SocketAddr>,
    /// SOCKS5: TCP control connection.  Must stay alive for the relay to work.
    _tcp_ctrl: Option<TcpStream>,
}

// ── SampClient ────────────────────────────────────────────────────────────────

pub struct SampClient {
    // Config (immutable after construction)
    port: u16,
    nickname: String,
    password: String,
    gpci: String,
    host: String,
    proxy: Option<socks5::ProxyConfig>,

    // Network (set once in connect())
    net: Mutex<Option<NetState>>,

    // Atomic state
    pub connected: AtomicBool,
    pub running: AtomicBool,
    spawned: AtomicBool,
    spectating: AtomicBool,
    send_msg_num: AtomicU16,
    ordering_idx: AtomicU16,  // for RELIABLE_ORDERED
    sequenced_idx: AtomicU16, // for UNRELIABLE_SEQUENCED / RELIABLE_SEQUENCED
    keys: AtomicU16,
    lr_analog: AtomicU16,
    ud_analog: AtomicU16,
    health: AtomicU8,
    armour: AtomicU8,
    weapon: AtomicU8,
    // facing angle in degrees, stored as f32 bits (fQuaternion[3] in ONFOOT_SYNC_DATA)
    rotation_raw: AtomicU32,
    onfoot_rate_ms: AtomicU32, // server-specified send interval for on-foot sync

    // Protected state
    player_id: Mutex<i32>,
    challenge: Mutex<u32>,
    pending_acks: Mutex<Vec<u16>>,
    position: Mutex<[f32; 3]>,
    // (vehicle_id, seat_id); None = on foot
    current_vehicle: Mutex<Option<(u16, u8)>>,

    pub callbacks: Mutex<Callbacks>,
}

impl SampClient {
    pub fn new(
        host: &str,
        port: u16,
        nickname: &str,
        password: &str,
        gpci: &str,
        proxy: Option<socks5::ProxyConfig>,
    ) -> Arc<Self> {
        let gpci = if gpci.is_empty() {
            DEFAULT_GPCI.to_string()
        } else {
            gpci.to_string()
        };
        Arc::new(SampClient {
            host: host.to_string(),
            port,
            nickname: nickname.to_string(),
            password: password.to_string(),
            gpci,
            proxy,
            net: Mutex::new(None),
            connected: AtomicBool::new(false),
            running: AtomicBool::new(false),
            spawned: AtomicBool::new(false),
            spectating: AtomicBool::new(false),
            send_msg_num: AtomicU16::new(0),
            ordering_idx: AtomicU16::new(0),
            sequenced_idx: AtomicU16::new(0),
            keys: AtomicU16::new(0),
            lr_analog: AtomicU16::new(0),
            ud_analog: AtomicU16::new(0),
            health: AtomicU8::new(100),
            armour: AtomicU8::new(0),
            weapon: AtomicU8::new(0),
            rotation_raw: AtomicU32::new(0),
            onfoot_rate_ms: AtomicU32::new(40),
            player_id: Mutex::new(-1),
            challenge: Mutex::new(0),
            pending_acks: Mutex::new(Vec::new()),
            position: Mutex::new([0.0, 0.0, 3.0]),
            current_vehicle: Mutex::new(None),
            callbacks: Mutex::new(Callbacks::new()),
        })
    }

    pub fn is_connected(&self) -> bool {
        self.connected.load(Ordering::Relaxed)
    }
    pub fn player_id(&self) -> i32 {
        *self.player_id.lock().unwrap()
    }

    /// Extract `(socket, server_ipv4, relay_ipv4)` from the active `NetState`.
    ///
    /// Returns `None` when no connection is active or the server address is not IPv4.
    /// All three callers — `do_handshake`, `do_connection_request`, and `run` — use
    /// this single helper so the extraction logic lives in exactly one place.
    fn net_recv_params(&self) -> Option<(Arc<UdpSocket>, Ipv4Addr, Option<Ipv4Addr>)> {
        let guard = self.net.lock().unwrap();
        let ns = guard.as_ref()?;
        let server_v4 = match ns.server_addr.ip() {
            IpAddr::V4(v) => v,
            _ => return None,
        };
        let relay_v4 = ns.relay_addr.and_then(|a| match a.ip() {
            IpAddr::V4(v) => Some(v),
            _ => None,
        });
        Some((Arc::clone(&ns.sock), server_v4, relay_v4))
    }

    // ─── Internal send primitives ─────────────────────────────────────────────

    fn send_encrypted(&self, data: &[u8]) {
        let (sock, addr, relay_addr) = {
            let guard = self.net.lock().unwrap();
            match guard.as_ref() {
                Some(ns) => (Arc::clone(&ns.sock), ns.server_addr, ns.relay_addr),
                None => return,
            }
        };
        let enc = samp_encrypt(data, self.port);
        if let Some(relay) = relay_addr {
            let wrapped = socks5::wrap_packet(&enc, addr);
            let _ = sock.send_to(&wrapped, relay);
        } else {
            let _ = sock.send_to(&enc, addr);
        }
    }

    fn send_reliability_pkt(&self, data: &[u8], rel: u8, oc: u8, mut oi: u16) {
        let num = self.send_msg_num.fetch_add(1, Ordering::Relaxed);
        if rel == REL_RELIABLE_ORDERED {
            oi = self.ordering_idx.fetch_add(1, Ordering::Relaxed);
        } else if rel == REL_UNRELIABLE_SEQUENCED || rel == REL_RELIABLE_SEQUENCED {
            oi = self.sequenced_idx.fetch_add(1, Ordering::Relaxed);
        }
        let pkt = make_packet(data, num, rel, oc, oi);
        self.send_encrypted(&pkt);
    }

    fn send_acks(&self, nums: &[u16]) {
        if nums.is_empty() {
            return;
        }
        let pkt = make_ack(nums);
        self.send_encrypted(&pkt);
    }

    fn flush_acks(&self) {
        let acks: Vec<u16> = {
            let mut guard = self.pending_acks.lock().unwrap();
            std::mem::take(&mut *guard)
        };
        self.send_acks(&acks);
    }

    // ─── RPC send ─────────────────────────────────────────────────────────────

    pub fn send_rpc(&self, rpc_id: u8, payload: &[u8], rel: u8) {
        let mut bs = BitStream::new();
        bs.write_uint8(ID_RPC);
        bs.write_uint8(rpc_id);
        bs.write_compressed_uint32((payload.len() * 8) as u32);
        if !payload.is_empty() {
            bs.write_bits(payload, (payload.len() * 8) as i32, false);
        }
        self.send_reliability_pkt(bs.as_bytes(), rel, 0, 0);
    }

    // ─── Handshake phase ──────────────────────────────────────────────────────

    fn do_handshake(&self, timeout: Duration) -> Result<(), ConnectError> {
        let (sock, server_v4, relay_v4) =
            self.net_recv_params().ok_or(ConnectError::HostResolution)?;

        let req = [ID_OPEN_CONNECTION_REQUEST, 0, 0];
        self.send_encrypted(&req);

        let deadline = Instant::now() + timeout;
        let mut buf = [0u8; 256];
        loop {
            match recv_deadline(&sock, &mut buf, server_v4, deadline, relay_v4) {
                None => return Err(ConnectError::HandshakeTimeout),
                Some(n) => {
                    if n >= 3 && buf[0] == ID_OPEN_CONNECTION_COOKIE {
                        let lo = buf[1];
                        let hi = buf[2];
                        let reply = [
                            ID_OPEN_CONNECTION_REQUEST,
                            lo ^ (NETCODE_CONNCOOKIELULZ & 0xFF) as u8,
                            hi ^ ((NETCODE_CONNCOOKIELULZ >> 8) & 0xFF) as u8,
                        ];
                        self.send_encrypted(&reply);
                        continue;
                    }
                    if n >= 1 && buf[0] == ID_OPEN_CONNECTION_REPLY {
                        return Ok(());
                    }
                }
            }
        }
    }

    fn handle_auth_key_raw(&self, data: &[u8]) {
        if data.len() < 2 {
            return;
        }
        let key_len = data[1] as usize;
        if data.len() < 2 + key_len {
            return;
        }

        // Challenge: strip trailing null bytes
        let raw = &data[2..2 + key_len];
        let challenge = std::str::from_utf8(raw)
            .unwrap_or("")
            .trim_end_matches('\0');

        let resp = samp_auth_response(challenge).unwrap_or("");
        let resp_bytes = resp.as_bytes();

        let mut pkt = vec![0u8; 2 + resp_bytes.len()];
        pkt[0] = ID_AUTH_KEY;
        pkt[1] = resp_bytes.len() as u8;
        pkt[2..].copy_from_slice(resp_bytes);
        self.send_reliability_pkt(&pkt, REL_RELIABLE, 0, 0);
    }

    fn handle_connection_accepted_raw(&self, data: &[u8]) {
        if data.len() < 9 {
            return;
        }
        let mut bs = BitStream::from_bytes(data);
        // Skip: ID_CONNECTION_REQUEST_ACCEPTED(8b) + binaryAddress(32b) + port(16b)
        bs.skip_bits(56);
        let pid: u16 = match bs.read_uint16_le() {
            Ok(v) => v,
            Err(_) => return,
        };
        let chal: u32 = match bs.read_uint32_le() {
            Ok(v) => v,
            Err(_) => return,
        };

        *self.player_id.lock().unwrap() = pid as i32;
        *self.challenge.lock().unwrap() = chal;

        // ID_NEW_INCOMING_CONNECTION
        let server_ip_be: u32 = {
            let guard = self.net.lock().unwrap();
            match guard.as_ref() {
                Some(ns) => match ns.server_addr.ip() {
                    IpAddr::V4(v4) => u32::from(v4).to_be(),
                    _ => 0,
                },
                None => 0,
            }
        };
        let mut nic = vec![0u8; 7];
        nic[0] = ID_NEW_INCOMING_CONNECTION;
        nic[1..5].copy_from_slice(&server_ip_be.to_be_bytes());
        let port_le = self.port.to_le_bytes();
        nic[5..7].copy_from_slice(&port_le);
        self.send_reliability_pkt(&nic, REL_RELIABLE, 0, 0);

        self.send_client_join();
    }

    fn send_client_join(&self) {
        let nick = {
            let n = &self.nickname;
            if n.len() > 20 {
                n[..20].to_string()
            } else {
                n.clone()
            }
        };
        let gpci = {
            let g = &self.gpci;
            if g.len() > 63 {
                g[..63].to_string()
            } else {
                g.clone()
            }
        };
        let ver = "0.3.7";
        let challenge = *self.challenge.lock().unwrap();
        let challenge_resp = challenge ^ NETGAME_VERSION;

        let mut bs = BitStream::new();
        let version = NETGAME_VERSION as i32;
        bs.write_int32_le(version);
        bs.write_uint8(1); // mod = 1
        bs.write_uint8(nick.len() as u8);
        bs.write_aligned_bytes(nick.as_bytes());
        bs.write_uint32_le(challenge_resp);
        bs.write_uint8(gpci.len() as u8);
        bs.write_aligned_bytes(gpci.as_bytes());
        bs.write_uint8(ver.len() as u8);
        bs.write_aligned_bytes(ver.as_bytes());
        // Official SA:MP 0.3.7 client sends challenge_resp a second time at the end.
        // Servers can detect bots by checking this duplicate is non-zero.
        bs.write_uint32_le(challenge_resp);

        let payload = bs.as_bytes().to_vec();
        let mut rpc_bs = BitStream::new();
        rpc_bs.write_uint8(ID_RPC);
        rpc_bs.write_uint8(RPC_CLIENT_JOIN);
        rpc_bs.write_compressed_uint32((payload.len() * 8) as u32);
        rpc_bs.write_bits(&payload, (payload.len() * 8) as i32, false);
        self.send_reliability_pkt(rpc_bs.as_bytes(), REL_RELIABLE, 0, 0);
    }

    fn do_connection_request(&self, timeout: Duration) -> Result<(), ConnectError> {
        let (sock, server_v4, relay_v4) =
            self.net_recv_params().ok_or(ConnectError::HostResolution)?;

        let mut cr = vec![ID_CONNECTION_REQUEST];
        if !self.password.is_empty() {
            cr.extend_from_slice(self.password.as_bytes());
        }
        self.send_reliability_pkt(&cr, REL_RELIABLE, 0, 0);

        let deadline = Instant::now() + timeout;
        let mut buf = [0u8; 2048];
        let mut split_buf = SplitBuffer::new();

        loop {
            let n = match recv_deadline_cap(
                &sock,
                &mut buf,
                server_v4,
                deadline,
                Duration::from_millis(500),
                relay_v4,
            ) {
                None => return Err(ConnectError::ConnectionTimeout),
                Some(n) => n,
            };

            // Raw auth key (before reliability layer)
            if n >= 2 && buf[0] == ID_AUTH_KEY {
                self.handle_auth_key_raw(&buf[..n]);
                continue;
            }

            let result = match rel_parse(&buf[..n], &mut split_buf) {
                Some(r) => r,
                None => continue,
            };
            if result.is_ack {
                continue;
            }

            for pkt in &result.packets {
                // ACK all three reliable types — mirrors ReliabilityLayer.cpp:455:
                // "if RELIABLE_SEQUENCED || RELIABLE_ORDERED || RELIABLE"
                if pkt.reliability == crate::reliability::Reliability::Reliable
                    || pkt.reliability == crate::reliability::Reliability::ReliableOrdered
                    || pkt.reliability == crate::reliability::Reliability::ReliableSequenced
                {
                    self.pending_acks.lock().unwrap().push(pkt.msg_num);
                }
                self.flush_acks();

                if pkt.data.is_empty() {
                    continue;
                }
                match pkt.data[0] {
                    id if id == ID_AUTH_KEY => {
                        self.handle_auth_key_raw(&pkt.data);
                    }
                    id if id == ID_CONNECTION_REQUEST_ACCEPTED => {
                        self.handle_connection_accepted_raw(&pkt.data);
                        self.connected.store(true, Ordering::Relaxed);
                        return Ok(());
                    }
                    id if id == ID_CONNECTION_BANNED => return Err(ConnectError::Banned),
                    id if id == ID_INVALID_PASSWORD => return Err(ConnectError::InvalidPassword),
                    id if id == ID_NO_FREE_INCOMING_CONNECTIONS => {
                        return Err(ConnectError::NoFreeSlots)
                    }
                    id if id == ID_CONNECTION_ATTEMPT_FAILED => return Err(ConnectError::Rejected),
                    _ => {}
                }
            }
        }
    }

    // ─── RPC handlers ─────────────────────────────────────────────────────────

    fn handle_rpc(&self, rpc_id: u8, payload: &[u8]) {
        let mut bs = BitStream::from_bytes(payload);
        let len = payload.len() as i32;

        let _ = (|| -> Option<()> {
            match rpc_id {
                RPC_INIT_GAME => {
                    // Parse INIT_GAME payload (netrpc.cpp: InitGame, RPCs.cpp: InitGameForPlayer).
                    // RakSAMP BitStream.ReadBits does NOT byte-align before reading —
                    // all fields are packed bit-consecutively (confirmed from BitStream.cpp).
                    // Bit positions:
                    //   bits   0-3:   4 booleans (zoneNames, useCJWalk, allowWeapons, limitGlobalChatRadius)
                    //   bits   4-35:  f32 globalChatRadius
                    //   bit    36:    bool stuntBonus
                    //   bits   37-68: f32 nameTagDrawDistance
                    //   bits   69-71: 3 booleans (disableEnterExits, nameTagLOS, manualVehicleEngineAndLight)
                    //   bits   72-103: i32 iSpawnsAvailable
                    //   bits  104-119: u16 MyPlayerID
                    //   bit   120:    bool showPlayerTags
                    //   bits  121-152: i32 showPlayerMarkers
                    //   bits  153-160: u8 worldTime
                    //   bits  161-168: u8 weather
                    //   bits  169-200: f32 gravity
                    //   bit   201:    bool lanMode
                    //   bits  202-233: i32 deathDropMoney
                    //   bit   234:    bool instagib
                    //   bits  235-266: i32 onFootRate  ← send rate
                    //   bits  267-298: i32 inCarRate
                    bs.skip_bits(104);
                    if let Ok(pid) = bs.read_uint16_le() {
                        *self.player_id.lock().unwrap() = pid as i32;
                    }
                    // skip from bit 120 to bit 235 (115 bits)
                    bs.skip_bits(115);
                    if let (Ok(onfoot_ms), Ok(_incar_ms)) = (bs.read_int32_le(), bs.read_int32_le())
                    {
                        let rate = onfoot_ms.clamp(30, 2000) as u32;
                        self.onfoot_rate_ms.store(rate, Ordering::Relaxed);
                    }

                    fire!(self.callbacks, on_connect);
                    // Request class 0; spawn is deferred until server replies (RPC_REQUEST_CLASS).
                    let class_id: i32 = 0;
                    self.send_rpc(RPC_REQUEST_CLASS, &class_id.to_le_bytes(), REL_RELIABLE);
                }

                RPC_REQUEST_CLASS => {
                    // Server approved class selection (u8 outcome + PLAYER_SPAWN_INFO).
                    // PLAYER_SPAWN_INFO (#pragma pack(1)):
                    //   byteTeam(1) + iSkin(4) + unk(1) + vecPos(12) + fRotation(4) + ...
                    let outcome = bs.read_uint8().ok()?;
                    if outcome != 0 {
                        // Skip byteTeam(1)+iSkin(4)+unk(1) = 6 bytes, then read vecPos + fRotation.
                        bs.skip_bits(6 * 8);
                        let x = bs.read_float_le().ok()?;
                        let y = bs.read_float_le().ok()?;
                        let z = bs.read_float_le().ok()?;
                        *self.position.lock().unwrap() = [x, y, z];
                        if let Ok(rot) = bs.read_float_le() {
                            self.rotation_raw.store(rot.to_bits(), Ordering::Relaxed);
                        }
                    }
                    // Skip spawn if the server put us in spectating mode — it will
                    // call TogglePlayerSpectating(false) when ready for us to spawn.
                    if !self.spectating.load(Ordering::Relaxed) {
                        self.send_rpc(RPC_REQUEST_SPAWN, &[], REL_RELIABLE);
                        self.send_rpc(RPC_SPAWN, &[], REL_RELIABLE);
                        self.spawned.store(true, Ordering::Relaxed);
                    }
                }

                RPC_CONNECTION_REJ => {
                    self.running.store(false, Ordering::Relaxed);
                }

                RPC_SERVER_JOIN => {
                    let pid = bs.read_uint16_le().ok()?;
                    bs.skip_bits(32); // unk
                    bs.read_uint8().ok()?; // isNPC
                    let nlen = bs.read_uint8().ok()? as usize;
                    let mut name_buf = vec![0u8; nlen];
                    if nlen > 0 {
                        bs.read_aligned_bytes(&mut name_buf).ok()?;
                    }
                    let name = String::from_utf8_lossy(&name_buf).into_owned();
                    fire!(self.callbacks, on_player_join, pid, name);
                }

                RPC_SERVER_QUIT => {
                    let pid = bs.read_uint16_le().ok()?;
                    let reason = bs.read_uint8().ok()?;
                    fire!(self.callbacks, on_player_quit, pid, reason);
                }

                RPC_CHAT => {
                    let pid = bs.read_uint16_le().ok()?;
                    let tlen = bs.read_uint8().ok()? as usize;
                    let mut tbuf = vec![0u8; tlen];
                    if tlen > 0 {
                        bs.read_aligned_bytes(&mut tbuf).ok()?;
                    }
                    fire!(self.callbacks, on_chat, pid, tbuf);
                }

                RPC_CLIENT_MESSAGE => {
                    let color = bs.read_uint32_le().ok()?;
                    let mlen = bs.read_uint32_le().ok()? as usize;
                    if mlen > 256 {
                        return None;
                    }
                    let mut mbuf = vec![0u8; mlen];
                    if mlen > 0 {
                        bs.read_aligned_bytes(&mut mbuf).ok()?;
                    }
                    fire!(self.callbacks, on_client_message, color, mbuf);
                }

                RPC_DIALOG_BOX => {
                    let did = bs.read_uint16_le().ok()?;
                    let style = bs.read_uint8().ok()?;

                    let tlen = bs.read_uint8().ok()? as usize;
                    let mut tbuf = vec![0u8; tlen];
                    if tlen > 0 {
                        bs.read_aligned_bytes(&mut tbuf).ok()?;
                    }
                    let b1len = bs.read_uint8().ok()? as usize;
                    let mut b1buf = vec![0u8; b1len];
                    if b1len > 0 {
                        bs.read_aligned_bytes(&mut b1buf).ok()?;
                    }

                    let b2len = bs.read_uint8().ok()? as usize;
                    let mut b2buf = vec![0u8; b2len];
                    if b2len > 0 {
                        bs.read_aligned_bytes(&mut b2buf).ok()?;
                    }

                    let body = bs.read_compressed_bytes(4095).ok().unwrap_or_default();
                    fire!(
                        self.callbacks,
                        on_dialog,
                        did,
                        style,
                        tbuf,
                        b1buf,
                        b2buf,
                        body
                    );
                }

                RPC_GAME_TEXT => {
                    let gtype = bs.read_int32_le().ok()?;
                    let time = bs.read_int32_le().ok()?;
                    let mlen = bs.read_int32_le().ok()?;
                    if !(0..=400).contains(&mlen) {
                        return None;
                    }
                    let mut mbuf = vec![0u8; mlen as usize];
                    if mlen > 0 {
                        bs.read_aligned_bytes(&mut mbuf).ok()?;
                    }
                    let text = String::from_utf8_lossy(&mbuf).into_owned();
                    fire!(self.callbacks, on_game_text, gtype, time, text);
                }

                RPC_SET_HEALTH => {
                    let hp = bs.read_float_le().ok()?;
                    self.health
                        .store(hp.clamp(0.0, 255.0) as u8, Ordering::Relaxed);
                    fire!(self.callbacks, on_set_health, hp);
                }

                RPC_SET_ARMOUR => {
                    let arm = bs.read_float_le().ok()?;
                    self.armour
                        .store(arm.clamp(0.0, 255.0) as u8, Ordering::Relaxed);
                    fire!(self.callbacks, on_set_armour, arm);
                }

                RPC_SET_POSITION => {
                    let x = bs.read_float_le().ok()?;
                    let y = bs.read_float_le().ok()?;
                    let z = bs.read_float_le().ok()?;
                    *self.position.lock().unwrap() = [x, y, z];
                    fire!(self.callbacks, on_set_position, x, y, z);
                }

                RPC_SET_CHECKPOINT => {
                    let x = bs.read_float_le().ok()?;
                    let y = bs.read_float_le().ok()?;
                    let z = bs.read_float_le().ok()?;
                    let sz = bs.read_float_le().ok()?;
                    fire!(self.callbacks, on_checkpoint, x, y, z, sz);
                }

                RPC_DISABLE_CHECKPOINT => {
                    fire!(self.callbacks, on_checkpoint_disabled);
                }

                RPC_WORLD_PLAYER_ADD => {
                    let pid = bs.read_uint16_le().ok()?;
                    let team = bs.read_uint8().ok()?;
                    let skin = bs.read_int32_le().ok()?;
                    let x = bs.read_float_le().ok()?;
                    let y = bs.read_float_le().ok()?;
                    let z = bs.read_float_le().ok()?;
                    let rot = bs.read_float_le().ok()?;
                    let color = bs.read_uint32_le().ok()?;
                    let fs = bs.read_uint8().ok()?;
                    // Server broadcasts our own spawn position — update sync state.
                    if pid == *self.player_id.lock().unwrap() as u16 {
                        *self.position.lock().unwrap() = [x, y, z];
                        self.rotation_raw.store(rot.to_bits(), Ordering::Relaxed);
                    }
                    fire!(
                        self.callbacks,
                        on_player_streamed_in,
                        pid,
                        team,
                        skin,
                        x,
                        y,
                        z,
                        rot,
                        color,
                        fs
                    );
                }

                RPC_WORLD_PLAYER_REMOVE => {
                    let pid = bs.read_uint16_le().ok()?;
                    fire!(self.callbacks, on_player_streamed_out, pid);
                }

                RPC_SET_PLAYER_NAME => {
                    let pid = bs.read_uint16_le().ok()?;
                    let nlen = bs.read_uint8().ok()? as usize;
                    let mut nbuf = vec![0u8; nlen];
                    if nlen > 0 {
                        bs.read_aligned_bytes(&mut nbuf).ok()?;
                    }
                    let name = String::from_utf8_lossy(&nbuf).into_owned();
                    let success = bs.read_uint8().ok()?;
                    fire!(self.callbacks, on_player_name, pid, name, success);
                }

                RPC_TOGGLE_CONTROLLABLE => {
                    let moveable = bs.read_uint8().ok()?;
                    fire!(self.callbacks, on_toggle_controllable, moveable);
                }

                RPC_SET_PLAYER_FACING_ANGLE => {
                    // fRotation stored in fQuaternion[3] of on-foot sync (misc_funcs.cpp:40)
                    let rot = bs.read_float_le().ok()?;
                    self.rotation_raw.store(rot.to_bits(), Ordering::Relaxed);
                }

                RPC_SET_PLAYER_TIME => {
                    let hour = bs.read_uint8().ok()?;
                    let minute = bs.read_uint8().ok()?;
                    fire!(self.callbacks, on_player_time, hour, minute);
                }

                RPC_SEND_DEATH_MESSAGE => {
                    let killer = bs.read_uint16_le().ok()?;
                    let player = bs.read_uint16_le().ok()?;
                    let weapon = bs.read_uint8().ok()?;
                    fire!(self.callbacks, on_death_message, killer, player, weapon);
                }

                RPC_SET_ARMED_WEAPON => {
                    let wid = bs.read_uint32_le().ok()?;
                    self.weapon.store(wid as u8, Ordering::Relaxed);
                    fire!(self.callbacks, on_set_armed_weapon, wid);
                }

                RPC_SET_SPAWN_INFO => {
                    let team = bs.read_uint8().ok()?;
                    let skin = bs.read_uint32_le().ok()?;
                    bs.read_uint8().ok()?; // unused
                    let x = bs.read_float_le().ok()?;
                    let y = bs.read_float_le().ok()?;
                    let z = bs.read_float_le().ok()?;
                    let rot = bs.read_float_le().ok()?;
                    let w1 = bs.read_uint32_le().ok()?;
                    let w2 = bs.read_uint32_le().ok()?;
                    let w3 = bs.read_uint32_le().ok()?;
                    let a1 = bs.read_uint32_le().ok()?;
                    let a2 = bs.read_uint32_le().ok()?;
                    let a3 = bs.read_uint32_le().ok()?;
                    fire!(
                        self.callbacks,
                        on_spawn_info,
                        team,
                        skin,
                        x,
                        y,
                        z,
                        rot,
                        w1,
                        w2,
                        w3,
                        a1,
                        a2,
                        a3
                    );
                }

                RPC_SET_PLAYER_TEAM => {
                    let pid = bs.read_uint16_le().ok()?;
                    let team = bs.read_uint8().ok()?;
                    fire!(self.callbacks, on_player_team, pid, team);
                }

                RPC_PUT_IN_VEHICLE => {
                    let vid = bs.read_uint16_le().ok()?;
                    let seat = bs.read_uint8().ok()?;
                    *self.current_vehicle.lock().unwrap() = Some((vid, seat));
                    fire!(self.callbacks, on_put_in_vehicle, vid, seat);
                }

                RPC_REMOVE_FROM_VEHICLE => {
                    *self.current_vehicle.lock().unwrap() = None;
                    fire!(self.callbacks, on_remove_from_vehicle);
                }

                RPC_SET_PLAYER_COLOR => {
                    let pid = bs.read_uint16_le().ok()?;
                    let color = bs.read_uint32_le().ok()?;
                    fire!(self.callbacks, on_player_color, pid, color);
                }

                RPC_SET_WORLD_TIME => {
                    let hour = bs.read_uint8().ok()?;
                    fire!(self.callbacks, on_world_time, hour);
                }

                RPC_TOGGLE_SPECTATING => {
                    let spec = bs.read_uint32_le().ok()?;
                    let was_spectating = self.spectating.swap(spec != 0, Ordering::Relaxed);
                    // Mirror reference: if transitioning OUT of spectating and not yet spawned → spawn.
                    if was_spectating && spec == 0 && !self.spawned.load(Ordering::Relaxed) {
                        self.send_rpc(RPC_REQUEST_SPAWN, &[], REL_RELIABLE);
                        self.send_rpc(RPC_SPAWN, &[], REL_RELIABLE);
                        self.spawned.store(true, Ordering::Relaxed);
                    }
                    fire!(self.callbacks, on_toggle_spectating, spec != 0);
                }

                RPC_SET_WANTED_LEVEL => {
                    let level = bs.read_uint8().ok()?;
                    fire!(self.callbacks, on_wanted_level, level);
                }

                RPC_SET_WEAPON_AMMO => {
                    let wid = bs.read_uint8().ok()?;
                    let ammo = bs.read_uint16_le().ok()?;
                    fire!(self.callbacks, on_weapon_ammo, wid, ammo);
                }

                RPC_SET_GRAVITY => {
                    let g = bs.read_float_le().ok()?;
                    fire!(self.callbacks, on_gravity, g);
                }

                RPC_SET_WEATHER => {
                    let w = bs.read_uint8().ok()?;
                    fire!(self.callbacks, on_weather, w);
                }

                RPC_SET_PLAYER_SKIN => {
                    let pid = bs.read_int32_le().ok()?;
                    let skin = bs.read_uint32_le().ok()?;
                    fire!(self.callbacks, on_player_skin, pid, skin);
                }

                RPC_SET_INTERIOR => {
                    let id = bs.read_uint8().ok()?;
                    // Server tracks interior via client response RPC 118 (RPC_SetInteriorId,
                    // SAMPRPC.cpp). Without this echo the server's GetPlayerInterior() stays
                    // stale and anti-cheat scripts may kick us.
                    self.send_rpc(RPC_INTERIOR_CHANGE_NOTIFY, &[id], REL_RELIABLE_ORDERED);
                    fire!(self.callbacks, on_set_interior, id);
                }

                RPC_SET_VIRTUAL_WORLD => {
                    // SetPlayerVirtualWorld (RPC 48) — server→client only, no response needed.
                    let vw = bs.read_int32_le().ok()?;
                    fire!(self.callbacks, on_set_virtual_world, vw);
                }

                RPC_WORLD_VEHICLE_ADD => {
                    let vid = bs.read_uint16_le().ok()?;
                    let model = bs.read_int32_le().ok()?;
                    let x = bs.read_float_le().ok()?;
                    let y = bs.read_float_le().ok()?;
                    let z = bs.read_float_le().ok()?;
                    let angle = bs.read_float_le().ok()?;
                    let color1 = bs.read_uint8().ok()?;
                    let color2 = bs.read_uint8().ok()?;
                    let health = bs.read_float_le().ok()?;
                    let interior = bs.read_uint8().ok()?;
                    let door_dmg = bs.read_uint32_le().ok()?;
                    let panel_dmg = bs.read_uint32_le().ok()?;
                    let light_dmg = bs.read_uint8().ok()?;
                    let tire_dmg = bs.read_uint8().ok()?;
                    let add_siren = bs.read_uint8().ok()?;
                    let mut mods = [0u8; 14];
                    bs.read_aligned_bytes(&mut mods).ok()?;
                    let paintjob = bs.read_uint8().ok()?;
                    let body_color1 = bs.read_uint32_le().ok()?;
                    let body_color2 = bs.read_uint32_le().ok()?;
                    // u8 unk ignored
                    fire!(
                        self.callbacks,
                        on_vehicle_streamed_in,
                        vid,
                        model,
                        x,
                        y,
                        z,
                        angle,
                        color1,
                        color2,
                        health,
                        interior,
                        door_dmg,
                        panel_dmg,
                        light_dmg,
                        tire_dmg,
                        add_siren,
                        paintjob,
                        body_color1,
                        body_color2
                    );
                }

                RPC_WORLD_VEHICLE_REMOVE => {
                    let vid = bs.read_uint16_le().ok()?;
                    fire!(self.callbacks, on_vehicle_streamed_out, vid);
                }

                RPC_DEATH_BROADCAST => {
                    let pid = bs.read_uint16_le().ok()?;
                    fire!(self.callbacks, on_player_death, pid);
                }

                RPC_TEXTDRAW_SHOW => {
                    let tid = bs.read_uint16_le().ok()?;
                    let flags = bs.read_uint8().ok()?;
                    let lw = bs.read_float_le().ok()?;
                    let lh = bs.read_float_le().ok()?;
                    let lcol = bs.read_uint32_le().ok()?;
                    let linew = bs.read_float_le().ok()?;
                    let lineh = bs.read_float_le().ok()?;
                    let bcol = bs.read_uint32_le().ok()?;
                    let shadow = bs.read_uint8().ok()?;
                    let outline = bs.read_uint8().ok()?;
                    let bgcol = bs.read_uint32_le().ok()?;
                    let style = bs.read_uint8().ok()?;
                    let sel = bs.read_uint8().ok()?;
                    let x = bs.read_float_le().ok()?;
                    let y = bs.read_float_le().ok()?;
                    let model = bs.read_uint16_le().ok()?;
                    let rx = bs.read_float_le().ok()?;
                    let ry = bs.read_float_le().ok()?;
                    let rz = bs.read_float_le().ok()?;
                    let zoom = bs.read_float_le().ok()?;
                    let col1 = bs.read_int16_le().ok()?;
                    let col2 = bs.read_int16_le().ok()?;
                    let tlen = bs.read_uint16_le().ok()? as usize;
                    let mut tbuf = vec![0u8; tlen];
                    if tlen > 0 {
                        bs.read_aligned_bytes(&mut tbuf).ok()?;
                    }
                    let text = String::from_utf8_lossy(&tbuf).into_owned();
                    fire!(
                        self.callbacks,
                        on_textdraw_show,
                        tid,
                        flags,
                        lw,
                        lh,
                        lcol,
                        linew,
                        lineh,
                        bcol,
                        shadow,
                        outline,
                        bgcol,
                        style,
                        sel,
                        x,
                        y,
                        model,
                        rx,
                        ry,
                        rz,
                        zoom,
                        col1,
                        col2,
                        text
                    );
                }

                RPC_TEXTDRAW_HIDE => {
                    let tid = bs.read_uint16_le().ok()?;
                    fire!(self.callbacks, on_textdraw_hide, tid);
                }

                RPC_TEXTDRAW_EDIT => {
                    let tid = bs.read_uint16_le().ok()?;
                    let tlen = bs.read_uint16_le().ok()? as usize;
                    let mut tbuf = vec![0u8; tlen];
                    if tlen > 0 {
                        bs.read_aligned_bytes(&mut tbuf).ok()?;
                    }
                    let text = String::from_utf8_lossy(&tbuf).into_owned();
                    fire!(self.callbacks, on_textdraw_edit, tid, text);
                }

                RPC_TEXTDRAW_TOGGLE_SELECT => {
                    let enable = bs.read_uint8().ok()? != 0;
                    let color = bs.read_uint32_le().ok()?;
                    fire!(self.callbacks, on_textdraw_toggle_select, enable, color);
                }

                RPC_CLIENT_CHECK => {
                    // Anti-cheat memory check. Server sends type+address+offset+count;
                    // client must respond with same RPC: type+address+response(0).
                    let check_type = bs.read_uint8().ok()?;
                    let address = bs.read_uint32_le().ok()?;
                    // offset and count are informational — we always respond with 0
                    let mut resp = [0u8; 6];
                    resp[0] = check_type;
                    resp[1..5].copy_from_slice(&address.to_le_bytes());
                    resp[5] = 0; // response byte
                    self.send_rpc(RPC_CLIENT_CHECK, &resp, REL_RELIABLE);
                }

                RPC_FORCE_CLASS_SELECTION => {
                    // Server wants us back at class selection — reset spawn state and re-request.
                    self.spawned.store(false, Ordering::Relaxed);
                    let class_id: i32 = 0;
                    self.send_rpc(RPC_REQUEST_CLASS, &class_id.to_le_bytes(), REL_RELIABLE);
                }

                RPC_GAME_MODE_RESTART => {
                    // Server is restarting — treat as disconnect so Python layer can reconnect.
                    self.connected.store(false, Ordering::Relaxed);
                    self.running.store(false, Ordering::Relaxed);
                    fire!(self.callbacks, on_disconnect);
                }

                _ => {}
            }
            Some(())
        })();

        // Always fire raw escape hatch
        fire!(self.callbacks, on_rpc, rpc_id, payload.to_vec());
        let _ = len; // suppress unused warning
    }

    fn process_packet_data(&self, data: &[u8]) {
        if data.is_empty() {
            return;
        }
        match data[0] {
            id if id == ID_TIMESTAMP => {
                if data.len() < 6 {
                    return;
                }
                self.process_packet_data(&data[5..]);
            }
            id if id == ID_RPC => {
                if data.len() < 2 {
                    return;
                }
                let mut bs = BitStream::from_bytes(data);
                bs.skip_bits(8); // ID_RPC
                let rpc_id = match bs.read_uint8() {
                    Ok(v) => v,
                    Err(_) => return,
                };
                let bit_len = match bs.read_compressed_uint32() {
                    Ok(v) => v,
                    Err(_) => return,
                };
                let byte_len = (bit_len as usize).div_ceil(8);
                let mut payload = vec![0u8; byte_len];
                if byte_len > 0 && bs.read_bits(&mut payload, bit_len as i32, false).is_err() {
                    return;
                }
                self.handle_rpc(rpc_id, &payload);
            }
            id if id == ID_INTERNAL_PING => {
                if data.len() < 5 {
                    return;
                }
                let ts = u32::from_le_bytes(data[1..5].try_into().unwrap());
                // RakNet validates pong size as 1 + 2*sizeof(RakNetTime) = 9 bytes.
                // Without the second timestamp the server silently rejects every pong,
                // keeps ping=500ms, and uses a 1500ms retransmit timeout instead of
                // the actual RTT*3 -- causing delayed delivery of reliable chat packets.
                // The second field must use the same epoch as RakNet::GetTime()
                // (ms since first call, not UNIX epoch) so clockDifferential is valid.
                let now_ms = raknet_time_ms();
                let mut resp = BitStream::new();
                resp.write_uint8(ID_CONNECTED_PONG);
                resp.write_uint32_le(ts);
                resp.write_uint32_le(now_ms);
                self.send_reliability_pkt(resp.as_bytes(), REL_UNRELIABLE, 0, 0);
            }
            id if id == ID_DISCONNECTION_NOTIFICATION || id == ID_CONNECTION_LOST => {
                self.connected.store(false, Ordering::Relaxed);
                self.running.store(false, Ordering::Relaxed);
                fire!(self.callbacks, on_disconnect);
            }
            id if id == ID_AUTH_KEY => {
                self.handle_auth_key_raw(data);
            }
            id if id == ID_CONNECTION_REQUEST_ACCEPTED
                && !self.connected.load(Ordering::Relaxed) =>
            {
                self.handle_connection_accepted_raw(data);
            }
            _ => {}
        }
    }

    /// Build the raw on-foot sync packet bytes (without sending).
    /// Extracted so that unit tests can inspect the packet without a live socket.
    fn build_keepalive_pkt(&self) -> Vec<u8> {
        // OnFootData struct (68 bytes), packed:
        // lrAnalog(u16) udAnalog(u16) wKeys(u16)
        // vecPos(3xf32) fQuaternion(4xf32)
        // byteHealth(u8) byteArmour(u8) weapon(u8) specialAction(u8)
        // moveSpeed(3xf32) surfOffsets(3xf32)
        // wSurfInfo(u16) animID(i32)
        let mut pkt = vec![0u8; 1 + 68];
        pkt[0] = ID_PLAYER_SYNC;
        // lrAnalog at offset 0, udAnalog at offset 2, wKeys at offset 4
        pkt[1..3].copy_from_slice(&self.lr_analog.load(Ordering::Relaxed).to_le_bytes());
        pkt[3..5].copy_from_slice(&self.ud_analog.load(Ordering::Relaxed).to_le_bytes());
        pkt[5..7].copy_from_slice(&self.keys.load(Ordering::Relaxed).to_le_bytes());
        // vecPos at offset 6 — updated on RPC_SET_POSITION
        let [px, py, pz] = *self.position.lock().unwrap();
        pkt[1 + 6..1 + 10].copy_from_slice(&px.to_le_bytes());
        pkt[1 + 10..1 + 14].copy_from_slice(&py.to_le_bytes());
        pkt[1 + 14..1 + 18].copy_from_slice(&pz.to_le_bytes());
        // fQuaternion[3] at struct offset 30: SA:MP stores facing angle here (misc_funcs.cpp:40)
        let rot = f32::from_bits(self.rotation_raw.load(Ordering::Relaxed));
        pkt[1 + 30..1 + 34].copy_from_slice(&rot.to_le_bytes());
        // byteHealth at offset 34, byteArmour at 35, byteCurrentWeapon at 36
        pkt[1 + 34] = self.health.load(Ordering::Relaxed);
        pkt[1 + 35] = self.armour.load(Ordering::Relaxed);
        pkt[1 + 36] = self.weapon.load(Ordering::Relaxed);
        // wSurfInfo at offset 62: 0 = not surfing on any vehicle
        pkt
    }

    // SPECTATOR_SYNC_DATA (common.h): lrAnalog(u16) udAnalog(u16) wKeys(u16) vecPos(3xf32) = 18 bytes
    // Reference: localplayer.cpp SendSpectatorData — UNRELIABLE_SEQUENCED
    fn build_spectator_pkt(&self) -> Vec<u8> {
        let mut pkt = vec![0u8; 1 + 18];
        pkt[0] = ID_SPECTATOR_SYNC;
        pkt[1..3].copy_from_slice(&self.lr_analog.load(Ordering::Relaxed).to_le_bytes());
        pkt[3..5].copy_from_slice(&self.ud_analog.load(Ordering::Relaxed).to_le_bytes());
        pkt[5..7].copy_from_slice(&self.keys.load(Ordering::Relaxed).to_le_bytes());
        let [px, py, pz] = *self.position.lock().unwrap();
        pkt[7..11].copy_from_slice(&px.to_le_bytes());
        pkt[11..15].copy_from_slice(&py.to_le_bytes());
        pkt[15..19].copy_from_slice(&pz.to_le_bytes());
        pkt
    }

    // INCAR_SYNC_DATA (common.h): VehicleID(u16) lrAnalog(u16) udAnalog(u16) wKeys(u16)
    //   fQuaternion(4xf32) vecPos(3xf32) vecMoveSpeed(3xf32) fCarHealth(f32)
    //   bytePlayerHealth(u8) bytePlayerArmour(u8) byteCurrentWeapon(u8)
    //   byteSirenOn(u8) byteLandingGearState(u8) TrailerID_or_ThrustAngle(u16) fTrainSpeed(f32)
    //   = 63 bytes total
    // Reference: localplayer.cpp SendInCarFullSyncData — UNRELIABLE_SEQUENCED
    fn build_vehicle_pkt(&self, vehicle_id: u16) -> Vec<u8> {
        let mut pkt = vec![0u8; 1 + 63];
        pkt[0] = ID_VEHICLE_SYNC;
        pkt[1..3].copy_from_slice(&vehicle_id.to_le_bytes());
        pkt[3..5].copy_from_slice(&self.lr_analog.load(Ordering::Relaxed).to_le_bytes());
        pkt[5..7].copy_from_slice(&self.ud_analog.load(Ordering::Relaxed).to_le_bytes());
        pkt[7..9].copy_from_slice(&self.keys.load(Ordering::Relaxed).to_le_bytes());
        // fQuaternion[4] at struct offset 8 → pkt[9..25]: zeroed (bot doesn't track vehicle angle)
        // vecPos at struct offset 24 → pkt[25..37]
        let [px, py, pz] = *self.position.lock().unwrap();
        pkt[25..29].copy_from_slice(&px.to_le_bytes());
        pkt[29..33].copy_from_slice(&py.to_le_bytes());
        pkt[33..37].copy_from_slice(&pz.to_le_bytes());
        // vecMoveSpeed at offset 36 → zeroed (stationary)
        // fCarHealth at struct offset 48 → pkt[49..53]
        pkt[49..53].copy_from_slice(&1000.0f32.to_le_bytes());
        // bytePlayerHealth at struct offset 52 → pkt[53]
        pkt[53] = self.health.load(Ordering::Relaxed);
        // bytePlayerArmour at struct offset 53 → pkt[54]
        pkt[54] = self.armour.load(Ordering::Relaxed);
        // byteCurrentWeapon at struct offset 54 → pkt[55]
        pkt[55] = self.weapon.load(Ordering::Relaxed);
        // TrailerID_or_ThrustAngle at struct offset 57 → pkt[58..60] — 0xFFFF = no trailer
        pkt[58..60].copy_from_slice(&0xFFFFu16.to_le_bytes());
        pkt
    }

    // PASSENGER_SYNC_DATA (common.h): VehicleID(u16) byteSeatFlags/byteDriveBy(u8)
    //   byteCurrentWeapon(u8) bytePlayerHealth(u8) bytePlayerArmour(u8)
    //   lrAnalog(u16) udAnalog(u16) wKeys(u16) vecPos(3xf32) = 24 bytes
    // Reference: localplayer.cpp SendPassengerFullSyncData — UNRELIABLE_SEQUENCED
    fn build_passenger_pkt(&self, vehicle_id: u16, seat: u8) -> Vec<u8> {
        let mut pkt = vec![0u8; 1 + 24];
        pkt[0] = ID_PASSENGER_SYNC;
        pkt[1..3].copy_from_slice(&vehicle_id.to_le_bytes());
        // byteSeatFlags (lower 7 bits) | byteDriveBy (bit 7)
        pkt[3] = seat & 0x7F;
        // byteCurrentWeapon at struct offset 3 → pkt[4]
        pkt[4] = self.weapon.load(Ordering::Relaxed);
        // bytePlayerHealth at struct offset 4 → pkt[5]
        pkt[5] = self.health.load(Ordering::Relaxed);
        // bytePlayerArmour at struct offset 5 → pkt[6]
        pkt[6] = self.armour.load(Ordering::Relaxed);
        // lrAnalog at offset 7, udAnalog at offset 9, wKeys at offset 11
        pkt[7..9].copy_from_slice(&self.lr_analog.load(Ordering::Relaxed).to_le_bytes());
        pkt[9..11].copy_from_slice(&self.ud_analog.load(Ordering::Relaxed).to_le_bytes());
        pkt[11..13].copy_from_slice(&self.keys.load(Ordering::Relaxed).to_le_bytes());
        // vecPos at offset 13
        let [px, py, pz] = *self.position.lock().unwrap();
        pkt[13..17].copy_from_slice(&px.to_le_bytes());
        pkt[17..21].copy_from_slice(&py.to_le_bytes());
        pkt[21..25].copy_from_slice(&pz.to_le_bytes());
        pkt
    }

    // ID_STATS_UPDATE (205): Packet_ID + INT32 money + INT32 drunk_level = 9 bytes
    fn build_stats_update_pkt(&self) -> Vec<u8> {
        let mut pkt = vec![0u8; 9];
        pkt[0] = ID_STATS_UPDATE;
        // money and drunk_level both 0
        pkt
    }

    // ID_WEAPONS_UPDATE (204): Packet_ID + UINT16 target_player + UINT16 target_actor
    //   + 12 × (UINT8 slot, UINT8 weapon, UINT16 ammo) = 1+2+2+48 = 53 bytes
    fn build_weapons_update_pkt(&self) -> Vec<u8> {
        let mut pkt = vec![0u8; 53];
        pkt[0] = ID_WEAPONS_UPDATE;
        // target_player = 0xFFFF (no target), target_actor = 0xFFFF
        pkt[1..3].copy_from_slice(&0xFFFFu16.to_le_bytes());
        pkt[3..5].copy_from_slice(&0xFFFFu16.to_le_bytes());
        // 12 slots: slot_id increments, weapon=0, ammo=0
        for i in 0u8..12 {
            let off = 5 + (i as usize) * 4;
            pkt[off] = i; // slot index
                          // weapon and ammo stay 0
        }
        pkt
    }

    // AIM_SYNC_DATA (common.h) = 31 bytes:
    //   byteCamMode(u8) vecAimf1(3xf32) vecAimPos(3xf32) fAimZ(f32)
    //   [byteCamExtZoom:6 | byteWeaponState:2](u8) bUnk(u8)
    // Reference: localplayer.cpp SendAimSyncData, misc_funcs.cpp onFootUpdateAtNormalPos
    //   byteCamMode=4, vecAimf1=[0.1,0.1,0.1], vecAimPos=player_pos, bUnk=0x55
    fn build_aim_sync_pkt(&self) -> Vec<u8> {
        let mut pkt = vec![0u8; 1 + 31];
        pkt[0] = ID_AIM_SYNC;
        // byteCamMode at offset 0
        pkt[1] = 4;
        // vecAimf1[3] at offset 1
        let aim_dir = 0.1f32.to_le_bytes();
        pkt[2..6].copy_from_slice(&aim_dir);
        pkt[6..10].copy_from_slice(&aim_dir);
        pkt[10..14].copy_from_slice(&aim_dir);
        // vecAimPos[3] at offset 13
        let [px, py, pz] = *self.position.lock().unwrap();
        pkt[14..18].copy_from_slice(&px.to_le_bytes());
        pkt[18..22].copy_from_slice(&py.to_le_bytes());
        pkt[22..26].copy_from_slice(&pz.to_le_bytes());
        // fAimZ at offset 25 — zeroed
        // byteCamExtZoom:6|byteWeaponState:2 at offset 29 — zeroed
        // bUnk at offset 30 = 0x55
        pkt[31] = 0x55;
        pkt
    }

    // ─── Public API ───────────────────────────────────────────────────────────

    pub fn connect(&self, timeout_sec: f64) -> Result<(), ConnectError> {
        let server_v4 = resolve_host(&self.host, self.port).ok_or(ConnectError::HostResolution)?;

        let sock = UdpSocket::bind("0.0.0.0:0").map_err(ConnectError::SocketBind)?;

        // If a SOCKS5 proxy is configured, negotiate UDP ASSOCIATE now.
        let (relay_addr, tcp_ctrl) = match self.proxy.as_ref() {
            Some(proxy) => {
                let (relay, ctrl) = socks5::udp_associate(proxy).map_err(ConnectError::Proxy)?;
                (Some(relay), Some(ctrl))
            }
            None => (None, None),
        };

        {
            let mut guard = self.net.lock().unwrap();
            *guard = Some(NetState {
                sock: Arc::new(sock),
                server_addr: SocketAddr::from((server_v4, self.port)),
                relay_addr,
                _tcp_ctrl: tcp_ctrl,
            });
        }

        let half = Duration::from_secs_f64(timeout_sec / 2.0);
        self.do_handshake(half)?;
        self.do_connection_request(half)?;
        Ok(())
    }

    pub fn run(&self) {
        self.running.store(true, Ordering::Relaxed);

        let (sock, server_v4, relay_v4) = match self.net_recv_params() {
            Some(p) => p,
            None => return,
        };

        let mut split_buf = SplitBuffer::new();
        let mut last_keepalive = Instant::now();
        let mut last_ack_flush = Instant::now();
        let mut last_scores = Instant::now();
        let mut last_stats = Instant::now();
        let mut recv_buf = [0u8; 2048];

        while self.running.load(Ordering::Relaxed) {
            let now = Instant::now();

            if now.duration_since(last_ack_flush) > Duration::from_millis(50) {
                self.flush_acks();
                last_ack_flush = now;
            }
            let keepalive_interval =
                Duration::from_millis(self.onfoot_rate_ms.load(Ordering::Relaxed) as u64);
            if now.duration_since(last_keepalive) > keepalive_interval {
                // Only send sync after spawning — the reference (misc_funcs.cpp)
                // calls onFootUpdateAtNormalPos() only inside the iSpawned == 1 branch.
                // Sending it pre-spawn confuses the server's player state machine.
                if self.spawned.load(Ordering::Relaxed) {
                    let is_spectating = self.spectating.load(Ordering::Relaxed);
                    let pkt = if is_spectating {
                        self.build_spectator_pkt()
                    } else {
                        match *self.current_vehicle.lock().unwrap() {
                            Some((vid, 0)) => self.build_vehicle_pkt(vid),
                            Some((vid, seat)) => self.build_passenger_pkt(vid, seat),
                            None => self.build_keepalive_pkt(),
                        }
                    };
                    self.send_reliability_pkt(&pkt, REL_UNRELIABLE_SEQUENCED, 0, 0);
                    // AIM_SYNC sent alongside every sync update (misc_funcs.cpp SendAimSyncData)
                    if !is_spectating {
                        let aim = self.build_aim_sync_pkt();
                        self.send_reliability_pkt(&aim, REL_UNRELIABLE_SEQUENCED, 0, 0);
                    }
                }
                last_keepalive = now;
            }
            if now.duration_since(last_scores) > Duration::from_secs(3) {
                self.send_rpc(RPC_UPDATE_SCORES, &[], REL_RELIABLE);
                last_scores = now;
            }
            if self.spawned.load(Ordering::Relaxed)
                && now.duration_since(last_stats) > Duration::from_secs(1)
            {
                let stats = self.build_stats_update_pkt();
                self.send_reliability_pkt(&stats, REL_UNRELIABLE_SEQUENCED, 0, 0);
                let weapons = self.build_weapons_update_pkt();
                self.send_reliability_pkt(&weapons, REL_UNRELIABLE_SEQUENCED, 0, 0);
                last_stats = now;
            }

            let _ = sock.set_read_timeout(Some(Duration::from_millis(30)));
            let n = match recv_one(&sock, &mut recv_buf, server_v4, relay_v4) {
                Some(n) => n,
                None => continue,
            };

            let data = &recv_buf[..n];

            // Raw auth key
            if n >= 2 && data[0] == ID_AUTH_KEY {
                self.handle_auth_key_raw(data);
                continue;
            }

            let result = match rel_parse(data, &mut split_buf) {
                Some(r) => r,
                None => continue,
            };
            if result.is_ack {
                continue;
            }

            for pkt in &result.packets {
                // ACK all three reliable types — mirrors ReliabilityLayer.cpp:455:
                // "if RELIABLE_SEQUENCED || RELIABLE_ORDERED || RELIABLE"
                if pkt.reliability == crate::reliability::Reliability::Reliable
                    || pkt.reliability == crate::reliability::Reliability::ReliableOrdered
                    || pkt.reliability == crate::reliability::Reliability::ReliableSequenced
                {
                    self.pending_acks.lock().unwrap().push(pkt.msg_num);
                }
                self.process_packet_data(&pkt.data);
            }
        }
    }

    pub fn stop(&self) {
        self.running.store(false, Ordering::Relaxed);
    }

    pub fn disconnect(&self) {
        self.running.store(false, Ordering::Relaxed);
        self.spawned.store(false, Ordering::Relaxed);
        self.spectating.store(false, Ordering::Relaxed);
        let disc = vec![ID_DISCONNECTION_NOTIFICATION, 0];
        self.send_reliability_pkt(&disc, REL_RELIABLE, 0, 0);
        std::thread::sleep(Duration::from_millis(100));
        if let Ok(mut guard) = self.net.lock() {
            *guard = None;
        }
    }

    // ─── Send helpers ─────────────────────────────────────────────────────────

    pub fn send_dialog_response(&self, dialog_id: u16, button: u8, list_item: u16, text: &[u8]) {
        let mut bs = BitStream::new();
        bs.write_uint16_le(dialog_id);
        bs.write_uint8(button);
        bs.write_uint16_le(list_item);
        let rlen = text.len().min(255) as u8;
        bs.write_uint8(rlen);
        if rlen > 0 {
            bs.write_aligned_bytes(&text[..rlen as usize]);
        }
        self.send_rpc(RPC_DIALOG_RESPONSE, bs.as_bytes(), REL_RELIABLE_ORDERED);
    }

    pub fn send_death(&self, weapon_id: u8, killer_id: u16) {
        let mut bs = BitStream::new();
        bs.write_uint8(weapon_id);
        bs.write_uint16_le(killer_id);
        self.send_rpc(RPC_DEATH, bs.as_bytes(), REL_RELIABLE_ORDERED);
    }

    pub fn send_enter_vehicle(&self, vehicle_id: u16, is_passenger: bool) {
        let mut bs = BitStream::new();
        bs.write_uint16_le(vehicle_id);
        bs.write_uint8(is_passenger as u8);
        self.send_rpc(RPC_ENTER_VEHICLE, bs.as_bytes(), REL_RELIABLE_SEQUENCED);
    }

    pub fn send_exit_vehicle(&self, vehicle_id: u16) {
        let mut bs = BitStream::new();
        bs.write_uint16_le(vehicle_id);
        self.send_rpc(RPC_EXIT_VEHICLE, bs.as_bytes(), REL_RELIABLE_SEQUENCED);
    }

    pub fn send_command(&self, text: &[u8]) {
        let mut bs = BitStream::new();
        bs.write_uint32_le(text.len() as u32);
        if !text.is_empty() {
            bs.write_aligned_bytes(text);
        }
        self.send_rpc(RPC_SERVER_COMMAND, bs.as_bytes(), REL_RELIABLE);
    }

    pub fn click_textdraw(&self, textdraw_id: u16) {
        let mut bs = BitStream::new();
        bs.write_uint16_le(textdraw_id);
        self.send_rpc(RPC_TEXTDRAW_SELECT, bs.as_bytes(), REL_RELIABLE_ORDERED);
    }

    /// Set the key state reported in on-foot sync packets.
    /// Values persist across keepalive sends until changed again.
    pub fn set_keys(&self, keys: u16, lr_analog: u16, ud_analog: u16) {
        self.keys.store(keys, Ordering::Relaxed);
        self.lr_analog.store(lr_analog, Ordering::Relaxed);
        self.ud_analog.store(ud_analog, Ordering::Relaxed);
    }
}

// ── Network helpers ───────────────────────────────────────────────────────────

fn resolve_host(host: &str, port: u16) -> Option<Ipv4Addr> {
    let s = format!("{}:{}", host, port);
    for addr in s.to_socket_addrs().ok()? {
        if let IpAddr::V4(v4) = addr.ip() {
            return Some(v4);
        }
    }
    None
}

// ── Low-level receive helpers ─────────────────────────────────────────────────

/// Receive one UDP datagram and strip the SOCKS5 header when a relay is active.
///
/// - Direct mode  (`relay_v4 = None`):  accept only datagrams whose source IP
///   matches `server_v4`.
/// - SOCKS5 mode  (`relay_v4 = Some`):  accept only datagrams from the relay,
///   strip the SOCKS5 UDP header, and verify the embedded source IP matches
///   `server_v4`.  The stripped payload is written back to the start of `buf`.
///
/// Returns the payload length, or `None` if the datagram should be discarded
/// (wrong source, malformed header, or a transient recv error).
fn recv_one(
    sock: &UdpSocket,
    buf: &mut [u8],
    server_v4: Ipv4Addr,
    relay_v4: Option<Ipv4Addr>,
) -> Option<usize> {
    let (n, src) = sock.recv_from(buf).ok()?;
    let src_v4 = match src.ip() {
        IpAddr::V4(v) => v,
        _ => return None,
    };

    match relay_v4 {
        Some(_relay) => {
            // Accept from any source: some proxies relay UDP from a different IP
            // than the one advertised in the UDP ASSOCIATE reply.  The embedded
            // SOCKS5 header is the authoritative source-address check.
            let (origin, hdr_len) = socks5::unwrap_packet(&buf[..n])?;
            if origin != server_v4 {
                return None;
            }
            buf.copy_within(hdr_len..n, 0);
            Some(n - hdr_len)
        }
        None => {
            if src_v4 == server_v4 {
                Some(n)
            } else {
                None
            }
        }
    }
}

/// Receive a datagram from `server_v4` before `deadline`.
/// Returns None only if deadline is reached without a matching packet.
fn recv_deadline(
    sock: &UdpSocket,
    buf: &mut [u8],
    server_v4: Ipv4Addr,
    deadline: Instant,
    relay_v4: Option<Ipv4Addr>,
) -> Option<usize> {
    recv_deadline_cap(
        sock,
        buf,
        server_v4,
        deadline,
        Duration::from_secs(1),
        relay_v4,
    )
}

/// Like recv_deadline but caps each poll to `cap`.
fn recv_deadline_cap(
    sock: &UdpSocket,
    buf: &mut [u8],
    server_v4: Ipv4Addr,
    deadline: Instant,
    cap: Duration,
    relay_v4: Option<Ipv4Addr>,
) -> Option<usize> {
    loop {
        let now = Instant::now();
        if now >= deadline {
            return None;
        }
        let remaining = deadline - now;
        let poll = remaining.min(cap).max(Duration::from_millis(1));
        let _ = sock.set_read_timeout(Some(poll));
        if let Some(n) = recv_one(sock, buf, server_v4, relay_v4) {
            return Some(n);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_client() -> Arc<SampClient> {
        SampClient::new("127.0.0.1", 7777, "TestBot", "", "", None)
    }

    // ── set_keys / build_keepalive_pkt ────────────────────────────────────────

    #[test]
    fn test_keepalive_pkt_default_keys_are_zero() {
        let c = make_client();
        let pkt = c.build_keepalive_pkt();
        // lrAnalog at bytes 1-2, udAnalog at 3-4, wKeys at 5-6
        assert_eq!(
            &pkt[1..7],
            &[0, 0, 0, 0, 0, 0],
            "keys/analog should default to zero"
        );
    }

    #[test]
    fn test_set_keys_reflected_in_packet() {
        let c = make_client();
        // Keys::FIRE | Keys::SPRINT = 4 | 8 = 12
        c.set_keys(12, 100, 200);
        let pkt = c.build_keepalive_pkt();
        assert_eq!(
            u16::from_le_bytes(pkt[1..3].try_into().unwrap()),
            100,
            "lr_analog"
        );
        assert_eq!(
            u16::from_le_bytes(pkt[3..5].try_into().unwrap()),
            200,
            "ud_analog"
        );
        assert_eq!(
            u16::from_le_bytes(pkt[5..7].try_into().unwrap()),
            12,
            "wKeys"
        );
    }

    #[test]
    fn test_set_keys_last_write_wins() {
        let c = make_client();
        c.set_keys(0xFFFF, 0xFFFF, 0xFFFF);
        c.set_keys(1, 2, 3);
        let pkt = c.build_keepalive_pkt();
        assert_eq!(u16::from_le_bytes(pkt[1..3].try_into().unwrap()), 2);
        assert_eq!(u16::from_le_bytes(pkt[3..5].try_into().unwrap()), 3);
        assert_eq!(u16::from_le_bytes(pkt[5..7].try_into().unwrap()), 1);
    }

    #[test]
    fn test_set_keys_max_values_dont_bleed_into_vecpos() {
        let c = make_client();
        c.set_keys(0xFFFF, 0xFFFF, 0xFFFF);
        let pkt = c.build_keepalive_pkt();
        // vecPos starts at pkt[7]; x and y are zero (default position is 0,0,3)
        assert_eq!(
            &pkt[7..15],
            &[0u8; 8],
            "0xFFFF keys must not bleed into vecPos"
        );
    }

    #[test]
    fn test_keepalive_pkt_constants() {
        let c = make_client();
        let pkt = c.build_keepalive_pkt();
        assert_eq!(pkt[0], ID_PLAYER_SYNC, "packet ID");
        assert_eq!(
            &pkt[15..19],
            &3.0f32.to_le_bytes(),
            "vecPos.z = 3.0 (default)"
        );
        assert_eq!(
            &pkt[31..35],
            &0.0f32.to_le_bytes(),
            "fQuaternion[3] = 0.0 (default facing)"
        );
        assert_eq!(pkt[35], 100, "byteHealth = 100");
        assert_eq!(
            [pkt[63], pkt[64]],
            [0x00, 0x00],
            "wSurfInfo = 0 (not surfing)"
        );
    }

    #[test]
    fn test_keepalive_pkt_length() {
        let c = make_client();
        assert_eq!(c.build_keepalive_pkt().len(), 1 + 68);
    }
}
