# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['bleak_esphome', 'bleak_esphome.backend']

package_data = \
{'': ['*']}

install_requires = \
['aioesphomeapi>=45.0.3',
 'bleak-retry-connector>=3.8.0',
 'bleak>=1',
 'bluetooth-data-tools>=1.18.0',
 'habluetooth>=6.1.0',
 'lru-dict>=1.2.0']

setup_kwargs = {
    'name': 'bleak-esphome',
    'version': '3.7.6',
    'description': 'Bleak backend of ESPHome',
    'long_description': '# bleak-esphome\n\n<p align="center">\n  <a href="https://github.com/bluetooth-devices/bleak-esphome/actions/workflows/ci.yml?query=branch%3Amain">\n    <img src="https://img.shields.io/github/actions/workflow/status/bluetooth-devices/bleak-esphome/ci.yml?branch=main&label=CI&logo=github&style=flat-square" alt="CI Status" >\n  </a>\n  <a href="https://bleak-esphome.readthedocs.io">\n    <img src="https://img.shields.io/readthedocs/bleak-esphome.svg?logo=read-the-docs&logoColor=fff&style=flat-square" alt="Documentation Status">\n  </a>\n  <a href="https://codecov.io/gh/bluetooth-devices/bleak-esphome">\n    <img src="https://img.shields.io/codecov/c/github/bluetooth-devices/bleak-esphome.svg?logo=codecov&logoColor=fff&style=flat-square" alt="Test coverage percentage">\n  </a>\n  <a href="https://codspeed.io/Bluetooth-Devices/bleak-esphome"><img src="https://img.shields.io/endpoint?url=https://codspeed.io/badge.json" alt="CodSpeed Badge"/></a>\n</p>\n<p align="center">\n  <a href="https://python-poetry.org/">\n    <img src="https://img.shields.io/badge/packaging-poetry-299bd7?style=flat-square&logo=data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAASCAYAAABrXO8xAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAJJSURBVHgBfZLPa1NBEMe/s7tNXoxW1KJQKaUHkXhQvHgW6UHQQ09CBS/6V3hKc/AP8CqCrUcpmop3Cx48eDB4yEECjVQrlZb80CRN8t6OM/teagVxYZi38+Yz853dJbzoMV3MM8cJUcLMSUKIE8AzQ2PieZzFxEJOHMOgMQQ+dUgSAckNXhapU/NMhDSWLs1B24A8sO1xrN4NECkcAC9ASkiIJc6k5TRiUDPhnyMMdhKc+Zx19l6SgyeW76BEONY9exVQMzKExGKwwPsCzza7KGSSWRWEQhyEaDXp6ZHEr416ygbiKYOd7TEWvvcQIeusHYMJGhTwF9y7sGnSwaWyFAiyoxzqW0PM/RjghPxF2pWReAowTEXnDh0xgcLs8l2YQmOrj3N7ByiqEoH0cARs4u78WgAVkoEDIDoOi3AkcLOHU60RIg5wC4ZuTC7FaHKQm8Hq1fQuSOBvX/sodmNJSB5geaF5CPIkUeecdMxieoRO5jz9bheL6/tXjrwCyX/UYBUcjCaWHljx1xiX6z9xEjkYAzbGVnB8pvLmyXm9ep+W8CmsSHQQY77Zx1zboxAV0w7ybMhQmfqdmmw3nEp1I0Z+FGO6M8LZdoyZnuzzBdjISicKRnpxzI9fPb+0oYXsNdyi+d3h9bm9MWYHFtPeIZfLwzmFDKy1ai3p+PDls1Llz4yyFpferxjnyjJDSEy9CaCx5m2cJPerq6Xm34eTrZt3PqxYO1XOwDYZrFlH1fWnpU38Y9HRze3lj0vOujZcXKuuXm3jP+s3KbZVra7y2EAAAAAASUVORK5CYII=" alt="Poetry">\n  </a>\n  <a href="https://github.com/ambv/black">\n    <img src="https://img.shields.io/badge/code%20style-black-000000.svg?style=flat-square" alt="black">\n  </a>\n  <a href="https://github.com/pre-commit/pre-commit">\n    <img src="https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white&style=flat-square" alt="pre-commit">\n  </a>\n</p>\n<p align="center">\n  <a href="https://pypi.org/project/bleak-esphome/">\n    <img src="https://img.shields.io/pypi/v/bleak-esphome.svg?logo=python&logoColor=fff&style=flat-square" alt="PyPI Version">\n  </a>\n  <img src="https://img.shields.io/pypi/pyversions/bleak-esphome.svg?style=flat-square&logo=python&amp;logoColor=fff" alt="Supported Python versions">\n  <img src="https://img.shields.io/pypi/l/bleak-esphome.svg?style=flat-square" alt="License">\n</p>\n\n---\n\n**Documentation**: <a href="https://bleak-esphome.readthedocs.io" target="_blank">https://bleak-esphome.readthedocs.io </a>\n\n**Source Code**: <a href="https://github.com/bluetooth-devices/bleak-esphome" target="_blank">https://github.com/bluetooth-devices/bleak-esphome </a>\n\n---\n\nA [Bleak](https://github.com/hbldh/bleak) backend that proxies Bluetooth Low Energy\nthrough an ESP32 running [ESPHome](https://github.com/esphome/esphome) with the\n[Bluetooth Proxy](https://esphome.io/components/bluetooth_proxy.html) component.\nIt lets any Python application — Home Assistant, an add-on, or a stand-alone\nscript — discover and connect to BLE peripherals using a remote ESP32 as the\nadapter. The Bluetooth Proxy firmware itself lives in the ESPHome project; this\nlibrary is the host-side client. See the [architecture\ndocs](https://bleak-esphome.readthedocs.io/en/latest/architecture.html) for how\nthe pieces fit together.\n\n## Installation\n\nInstall this via pip (or your favourite package manager):\n\n`pip install bleak-esphome`\n\n## Contributors ✨\n\nThanks goes to these wonderful people ([emoji key](https://allcontributors.org/docs/en/emoji-key)):\n\n<!-- prettier-ignore-start -->\n<!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->\n<!-- markdownlint-disable -->\n<!-- markdownlint-enable -->\n<!-- ALL-CONTRIBUTORS-LIST:END -->\n<!-- prettier-ignore-end -->\n\nThis project follows the [all-contributors](https://github.com/all-contributors/all-contributors) specification. Contributions of any kind welcome!\n\n## Credits\n\nThis package was created with\n[Copier](https://copier.readthedocs.io/) and the\n[browniebroke/pypackage-template](https://github.com/browniebroke/pypackage-template)\nproject template.\n',
    'author': 'J. Nick Koston',
    'author_email': 'bluetooth@koston.org',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/bluetooth-devices/bleak-esphome',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11',
}
from build_ext import *
build(setup_kwargs)

setup(**setup_kwargs)
