# emt-brain

EMT Brain — populate skills, workflows, and agents from the EMT repository into Claude Code (or GitHub Copilot).

## Install

```bash
# From wheel (recommended)
pip install dist/emt_brain-0.6.0-py3-none-any.whl

# From source
pip install -e tools/emt-brain

# With uv
uv pip install dist/emt_brain-0.6.0-py3-none-any.whl
```

## Quick start

```bash
# One-shot full setup (MCP servers + 3rd-party plugins + EMT skills/agents)
emt-brain init

# Or step by step:
# 1. Install standard MCP servers (Sequential Thinking + Memory)
emt-brain 3rd-mcp-setup

# 2. Install 3rd-party plugins (e.g. graphify)
emt-brain 3rd-plugins-setup

# 3. Sync default bundle (master + utilities + anthropics + context-engineering)
#    + all workflows + all agents
emt-brain framework-sync

# 4. See available workflows
emt-brain workflow-list

# 5. Scope to a specific workflow and its dep closure
emt-brain framework-sync --workflow emt-wf-ip-planning

# Preview without writing
emt-brain framework-sync --dry-run

# Show onboarding guide
emt-brain help
```

## Commands

### `emt-brain init`

Full one-shot setup that runs three steps in order:

1. **3rd-mcp-setup** — install Sequential Thinking + Memory (npx) + Context Mode (local) MCP servers
2. **3rd-plugins-setup** — install 3rd-party skill/agent plugins (e.g. graphify)
3. **framework-sync** — sync EMT default bundle + all workflows + agents

```bash
emt-brain init                        # interactive full setup
emt-brain init --yes                  # non-interactive (CI)
emt-brain init --dry-run              # preview without writing
emt-brain init --scope project        # install into project .claude/
emt-brain init --skip-mcp            # skip MCP servers step
emt-brain init --skip-plugins        # skip 3rd-party plugins step
emt-brain init --skip-sync           # skip framework-sync step
```

### `emt-brain 3rd-mcp-setup`

Install and activate MCP servers into Claude Code's `settings.json`. Checks if each server is already configured — skips if present, adds if missing. Restart Claude Code after running to activate.

```bash
emt-brain 3rd-mcp-setup                          # write to ~/.claude/settings.json (global)
emt-brain 3rd-mcp-setup --scope project          # write to .claude/settings.json (project)
emt-brain 3rd-mcp-setup --force                  # reinstall local servers (re-clone + npm install)
emt-brain 3rd-mcp-setup --dry-run                # preview without writing
```

**Servers installed:**

| Server | Mode | Package / Source |
| --- | --- | --- |
| `sequential-thinking` | npx | `@modelcontextprotocol/server-sequential-thinking` |
| `memory` | npx | `@modelcontextprotocol/server-memory` |
| `context-mode` | local | [github.com/mksglu/context-mode](https://github.com/mksglu/context-mode) |

**npx servers** require [Node.js](https://nodejs.org). Registered as `npx -y <package>` — no local storage.

**local servers** (e.g. `context-mode`) are cloned and installed at runtime:

1. `git clone --depth=1 <source>` → `~/Library/Application Support/emt-brain/mcp-servers/<name>/`
2. `npm install --prefer-offline`
3. `npm run build` if `package.json` has a build script
4. Entrypoint auto-detected: `bin` → `main` → `index.js` from `package.json`
5. Registered in `settings.json` as `{ "command": "node", "args": ["/path/to/entry.js"] }`

> local mode requires `git` + `npm` on PATH in addition to Node.js.

### `emt-brain 3rd-plugins-setup`

Install 3rd-party **skill/agent** plugins from public GitHub repos. Plugins are cloned with `git clone --depth=1` and copied into `.claude/skills/` or `.claude/agents/`. No authentication required.

> **MCP servers** (like `context-mode`) are managed by `3rd-mcp-setup`, not here.

```bash
emt-brain 3rd-plugins-setup                     # install all missing plugins
emt-brain 3rd-plugins-setup --list              # show status, do not install
emt-brain 3rd-plugins-setup --plugin graphify   # install one plugin
emt-brain 3rd-plugins-setup --force             # reinstall even if present
emt-brain 3rd-plugins-setup --dry-run           # preview without writing
emt-brain 3rd-plugins-setup --scope project     # install into .claude/ (project)
```

**Available plugins:**

| Plugin | Type | Source | Install path |
| --- | --- | --- | --- |
| `graphify` | skill | [github.com/safishamsi/graphify](https://github.com/safishamsi/graphify) | `~/.claude/skills/graphify/` |

> Requires `git` on PATH.

### `emt-brain framework-sync`

Populate skills, workflows, and agents in one shot.

```bash
emt-brain framework-sync                                 # default bundle + all
emt-brain framework-sync --workflow emt-wf-ip-planning  # scope to workflow deps
emt-brain framework-sync --dry-run                      # preview only
emt-brain framework-sync --force                        # overwrite local modifications
emt-brain framework-sync --scope project                # project-local (.claude/skills/)
emt-brain framework-sync --scope global                 # global (~/.claude/skills/)
```

**Default bundle** (`flezi-emt/bundles/default.bundle.yaml`) includes:

- Master skills (10) — EMT meta-tooling
- Utility skills (5) — docs, translations, branding
- Community: Anthropics (7 curated)
- Context-engineering skills (7 — context engineering foundation per IDEA-001)

**Workflow sync** (`--workflow <id>`) resolves the dep closure:

- Target workflow + transitively consumed workflows
- All agents referenced by those workflows
- All skills used by those agents
- Plus the default bundle (always included)

### `emt-brain workflow-list`

List all available EMT workflows.

```bash
emt-brain workflow-list           # summary table
emt-brain workflow-list --full    # include per-workflow agent list
emt-brain workflow-list --json    # raw JSON
```

### `emt-brain help`

Show categorised command overview and getting-started guide.

### `emt-brain status`

Show current configuration (repo, branch, provider, scope) and drift count.

### `emt-brain doctor`

Run environment diagnostics: Python version, git, Azure auth, repo reachability, destination writable, state file.

### `emt-brain reset`

Delete CLI config and state. Already-synced files are **not** removed.

## Authentication

`emt-brain` uses [azure-identity](https://pypi.org/project/azure-identity/). On first run it prompts for device-code login if the Azure CLI credential is not cached. Subsequent runs reuse the cached credential.

## Project config

Place a `.flezi-emt/config.yaml` at your project root to configure `emt-brain` per project:

```yaml
profile: default            # bundle to sync
provider: claude            # claude | copilot
scope: project              # global | project
```

CLI flags override project config; project config overrides global config.

| Location | Purpose |
| --- | --- |
| Global config | `~/.config/emt-brain/config.json` — repo URL, branch, provider, scope |
| Project config | `.flezi-emt/config.yaml` — profile, filter_tags, provider, scope |
| State | `~/.local/share/emt-brain/state.json` — managed files, last sync |
| Cache | `~/.cache/emt-brain/repo-cache/` — cloned remote repo |

Run `emt-brain doctor` to see active paths.

## Post-sync: Claude Code setup

After syncing, in your project run `/emt-brain-help setup-project` in Claude Code to:

1. Initialize `CLAUDE.md` (if absent)
2. Add horizontal-protocol guidelines (IDEA-001 four-pillar session protocol)
3. Add workflow-usage guidelines for each installed workflow
