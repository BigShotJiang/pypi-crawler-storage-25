"""
hook_setup.py — Install HARNESS hook pipeline to ~/.claude/hooks/ (user scope).

Mirrors the pattern of mcp_setup.py. Hook scripts are bundled as package data
under emt_brain/hooks/ and installed to ~/.claude/hooks/ for user-level access.

Why user scope:
  HARNESS Protocol is cross-cutting — applies to all projects, not one repo.
  MCP servers are already at user scope; hooks should be consistent.
  Projects do not need to copy hooks — one install works everywhere.
"""

import importlib.resources
import json
import shutil
from pathlib import Path

HOOK_SCRIPTS = [
    "context-pct.mjs",
    "signal-density-gate.mjs",
    "distraction-filter.mjs",
    "observation-masking.mjs",
    "compaction-trigger.mjs",
    "poisoning-detector.mjs",
    "session-cleanup.mjs",
]

LIB_SCRIPTS = ["context-usage.mjs"]

# Full hooks block for ~/.claude/settings.json using absolute $HOME paths.
# Project-level .claude/settings.json should only contain project-specific
# permissions (deny/allow) — hooks come from user-level settings.
HARNESS_HOOKS_BLOCK: dict = {
    "PreToolUse": [
        {
            "matcher": "Bash|WebFetch|Read|Grep",
            "hooks": [
                {"type": "command", "command": "context-mode hook claude-code pretooluse"}
            ],
        },
        {
            "matcher": "Read",
            "hooks": [
                {"type": "command", "command": "node $HOME/.claude/hooks/signal-density-gate.mjs"},
                {"type": "command", "command": "node $HOME/.claude/hooks/distraction-filter.mjs"},
            ],
        },
        {
            "matcher": "WebFetch",
            "hooks": [
                {"type": "command", "command": "node $HOME/.claude/hooks/distraction-filter.mjs"},
            ],
        },
    ],
    "PostToolUse": [
        {
            "matcher": "",
            "hooks": [
                {"type": "command", "command": "context-mode hook claude-code posttooluse"},
                {"type": "command", "command": "node $HOME/.claude/hooks/observation-masking.mjs"},
                {"type": "command", "command": "node $HOME/.claude/hooks/compaction-trigger.mjs"},
                {"type": "command", "command": "node $HOME/.claude/hooks/poisoning-detector.mjs"},
            ],
        }
    ],
    "PreCompact": [
        {
            "matcher": "",
            "hooks": [
                {"type": "command", "command": "context-mode hook claude-code precompact"}
            ],
        }
    ],
    "SessionStart": [
        {
            "matcher": "",
            "hooks": [
                {"type": "command", "command": "echo '[HARNESS/start] New session — run /emt-sk-session-open before anything non-trivial'"},
                {"type": "command", "command": "context-mode hook claude-code sessionstart"},
                {"type": "command", "command": "node $HOME/.claude/hooks/session-cleanup.mjs"},
            ],
        }
    ],
    "UserPromptSubmit": [
        {
            "matcher": "",
            "hooks": [
                {"type": "command", "command": "node $HOME/.claude/hooks/context-pct.mjs"},
                {"type": "command", "command": "echo '[HARNESS] Session: did /emt-sk-session-open run? (non-trivial = >1 file / architecture decision / >1 turn)'"},
                {"type": "command", "command": "context-mode hook claude-code userpromptsubmit"},
            ],
        }
    ],
    "Stop": [
        {
            "matcher": "",
            "hooks": [
                {"type": "command", "command": "echo '[HARNESS/stop] End of turn: ①≥70%→session-close required ②65-70%+task continues→session-close ③>3 turns+constrained?→≤65%:/context-degradation|>65%:session-close first'"},
            ],
        }
    ],
}


def get_hooks_source() -> Path:
    """Return the bundled hooks directory inside the installed package."""
    pkg = importlib.resources.files("emt_brain")
    return Path(str(pkg)) / "hooks"


def install_hook_scripts(dry_run: bool = False) -> tuple[Path, list[str], list[str]]:
    """
    Copy hook scripts from package data to ~/.claude/hooks/.
    Returns (hooks_dir, installed, skipped).
    """
    hooks_dir = Path.home() / ".claude" / "hooks"
    lib_dir = hooks_dir / "lib"

    if not dry_run:
        hooks_dir.mkdir(parents=True, exist_ok=True)
        lib_dir.mkdir(parents=True, exist_ok=True)

    source = get_hooks_source()
    installed: list[str] = []
    skipped: list[str] = []

    for script in HOOK_SCRIPTS:
        src = source / script
        dst = hooks_dir / script
        if dst.exists() and not dry_run:
            skipped.append(script)
            continue
        if not dry_run:
            shutil.copy2(src, dst)
        installed.append(script)

    for script in LIB_SCRIPTS:
        src = source / "lib" / script
        dst = lib_dir / script
        if dst.exists() and not dry_run:
            skipped.append(f"lib/{script}")
            continue
        if not dry_run:
            shutil.copy2(src, dst)
        installed.append(f"lib/{script}")

    return hooks_dir, installed, skipped


def update_user_settings(dry_run: bool = False, force: bool = False) -> tuple[Path, bool]:
    """
    Merge HARNESS_HOOKS_BLOCK into ~/.claude/settings.json.
    Returns (settings_path, already_had_hooks).
    """
    settings_path = Path.home() / ".claude" / "settings.json"

    existing: dict = {}
    if settings_path.exists():
        try:
            existing = json.loads(settings_path.read_text())
        except (json.JSONDecodeError, OSError):
            existing = {}

    already_had = "hooks" in existing and not force

    if not already_had or force:
        existing["hooks"] = HARNESS_HOOKS_BLOCK
        if not dry_run:
            settings_path.parent.mkdir(parents=True, exist_ok=True)
            settings_path.write_text(json.dumps(existing, indent=2) + "\n")

    return settings_path, already_had
