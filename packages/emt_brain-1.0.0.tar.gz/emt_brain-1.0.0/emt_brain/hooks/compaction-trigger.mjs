/**
 * compaction-trigger.mjs — PostToolUse
 * Gates to 85%-only (last-resort compaction warning).
 * The 60/65/70% HARNESS thresholds are owned by context-pct.mjs (UserPromptSubmit).
 * This hook fires 5-20× per turn — do NOT re-echo lower thresholds to avoid noise.
 */

import { readUsage } from "./lib/context-usage.mjs";

const COMPACT_AT = 85; // % — last-resort, inject compaction warning

try {
  const raw = await new Promise((resolve) => {
    let data = "";
    process.stdin.on("data", (c) => (data += c));
    process.stdin.on("end", () => resolve(data));
    process.stdin.on("error", () => resolve(""));
  });
  if (!raw.trim()) process.exit(0);

  const input = JSON.parse(raw);
  const transcriptPath = input.transcript_path;
  if (!transcriptPath) process.exit(0);

  const usage = readUsage(transcriptPath);
  if (!usage) process.exit(0);

  const { percent, tokens, totalK, windowK } = usage;

  if (percent >= COMPACT_AT) {
    process.stdout.write(JSON.stringify({
      type: "inject_context",
      context: [
        `🔴 [compaction-trigger] CONTEXT CRITICAL: ${percent}% (${totalK}K/${windowK}K).`,
        `Quality degradation imminent. Run /emt-sk-session-close or /compact now.`,
      ].join("\n")
    }) + "\n");
  }
} catch {
  // Never block — silent exit
}
process.exit(0);
