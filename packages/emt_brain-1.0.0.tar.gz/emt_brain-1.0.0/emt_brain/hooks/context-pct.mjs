#!/usr/bin/env node
/**
 * context-pct.mjs — HARNESS context window meter hook (UserPromptSubmit)
 *
 * ① /clear sentinel gate (any context %): requires session-close first
 * ② ≥65% warn  ③ ≥70% suggest /compact  ④ ≥80% block (only /compact allowed)
 *
 * Off-by-1-turn: reports previous turn's usage (~3-5% below actual).
 * Fallback: silent exit 0 — never blocks the session.
 */

import { readUsage } from "./lib/context-usage.mjs";
import { existsSync, rmSync, readFileSync } from "node:fs";
import { join } from "node:path";

async function readStdin() {
  return new Promise((resolve) => {
    let data = "";
    process.stdin.on("data", (chunk) => (data += chunk));
    process.stdin.on("end", () => resolve(data));
    process.stdin.on("error", () => resolve(""));
  });
}

try {
  const raw = await readStdin();
  if (!raw.trim()) process.exit(0);

  const input = JSON.parse(raw);
  const transcriptPath = input.transcript_path;
  if (!transcriptPath) process.exit(0);

  const cwd = input.cwd || process.cwd();
  const usage = readUsage(transcriptPath, cwd);
  if (!usage) process.exit(0);

  const { percent: pct, totalK, windowK } = usage;
  const prompt = input.prompt !== undefined ? String(input.prompt).trim() : undefined;

  // Read session intent (written by emt-sk-session-open Step 3b) — re-inject each turn
  let intentLine = "";
  try {
    const intentPath = join(cwd, ".flezi-emt", ".session-intent");
    if (existsSync(intentPath)) {
      const intent = readFileSync(intentPath, "utf-8").trim().slice(0, 200);
      if (intent) intentLine = `[Session intent] ${intent}\n`;
    }
  } catch {}

  // ① /clear sentinel gate — runs at any context %
  // session-close writes .flezi-emt/.clear-approved; hook consumes it on /clear
  if (prompt !== undefined && /^\/clear\b/i.test(prompt)) {
    const flagPath = join(cwd, ".flezi-emt", ".clear-approved");
    if (existsSync(flagPath)) {
      try { rmSync(flagPath); } catch {}
      process.exit(0); // session-close was done — allow /clear through
    } else {
      const msg = "[HARNESS] Run /emt-sk-session-close before /clear — type /clear again after session-close completes.";
      process.stdout.write(JSON.stringify({ decision: "block", reason: msg, stopReason: msg }) + "\n");
      process.exit(0);
    }
  }

  // ② Enforce /compact at ≥80%: block all prompts except /compact
  if (pct >= 80 && prompt !== undefined) {
    const isAllowed = /^\/compact\b/i.test(prompt);
    if (!isAllowed) {
      const msg = `[HARNESS/context] ${pct}% (${totalK}K/${windowK}K) ⛔ COMPACT REQUIRED — run /compact before continuing.`;
      process.stdout.write(JSON.stringify({ decision: "block", reason: msg, stopReason: msg }) + "\n");
      process.exit(0);
    }
  }

  // ③ Advisory messages
  let msg;
  if (pct >= 80) {
    msg = `[HARNESS/context] ${pct}% (${totalK}K/${windowK}K) ⛔ — running /compact`;
  } else if (pct >= 70) {
    msg = `[HARNESS/context] ${pct}% (${totalK}K/${windowK}K) ⚠ — run /compact before next turn`;
  } else if (pct >= 65) {
    msg = `[HARNESS/context] ${pct}% (${totalK}K/${windowK}K) ⚡ — context filling`;
  } else {
    msg = `[HARNESS/context] ${pct}% (${totalK}K/${windowK}K) ✓`;
  }

  process.stdout.write(intentLine + msg + "\n");
} catch {
  process.exit(0);
}
