#!/usr/bin/env node
/**
 * precompact-instruction.mjs — PreCompact hook (HARNESS Layer C — Quality assurance)
 *
 * Injects structured summarization schema into every /compact run.
 * Covers: A1 (structured output), A3 (observation aging), B5 (under-pressure), B6 (early turns).
 *
 * Output: hookSpecificOutput.additionalContext → Claude Code injects into /compact prompt.
 */

import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";

try {
  const raw = await new Promise((resolve) => {
    let data = "";
    process.stdin.on("data", (c) => (data += c));
    process.stdin.on("end", () => resolve(data));
    process.stdin.on("error", () => resolve(""));
  });

  const input = raw.trim() ? JSON.parse(raw) : {};
  const cwd = input.cwd || process.cwd();

  // Try to read session intent for context
  let intentHint = "";
  const intentPath = join(cwd, ".flezi-emt", ".session-intent");
  if (existsSync(intentPath)) {
    try {
      const intent = readFileSync(intentPath, "utf-8").trim().slice(0, 150);
      if (intent) intentHint = `\nSession intent: ${intent}`;
    } catch {}
  }

  const instruction = `[HARNESS/precompact] Structured compaction required.${intentHint}

MUST preserve in summary:
1. Session Intent (1 line)
2. Files Modified — full paths + function/method names changed (no paraphrase)
3. Decisions — reasoning + outcome; include decisions from first 2-3 turns (early constraints)
4. Open Questions — unresolved blockers with "open: " prefix
5. Current State — what is in progress + immediate next step

NEVER compress: tool definitions, function signatures, file paths, error codes, error messages.
Replace tool outputs older than 3 turns: [Obs:N elided. Key: <1-line summary>]
Target: 50-70% token reduction. If >70% → preserve more — do not lose critical state.`;

  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: "PreCompact",
      additionalContext: instruction
    }
  }) + "\n");
} catch {
  // Never block compaction — silent exit
  process.exit(0);
}
