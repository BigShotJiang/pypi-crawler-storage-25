"""cli.py — emt-brain: populate EMT framework into Claude Code workspaces."""
from __future__ import annotations

import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table

from . import auth, filter as skill_filter, repo, state, sync, sync_agents as _sa
from . import sync_contracts as _sc
from . import mcp_setup as _mcp
from . import hook_setup as _hooks
from . import plugins_setup as _plugins
from .manifest import load_manifest
from .paths import detect_providers, resolve_root
from .project_config import find_project_config, load_project_config, merge_configs
from .workflow_resolver import resolve_workflow_deps

app = typer.Typer(
    no_args_is_help=True,
    help="EMT Brain — populate skills, workflows, and agents into your Claude Code workspace.",
)
console = Console()

VALID_PROVIDERS = ["claude", "copilot"]
VALID_SCOPES = ["global", "project"]

DEFAULT_REPO_URL = "https://dev.azure.com/azurefsoft139/emt/_git/flezi-emt-skills"
DEFAULT_BRANCH = "main"
DEFAULT_PROFILE = "default"


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _setup_wizard(cfg: dict, yes: bool = False) -> dict:
    if not cfg.get("repo_url"):
        if yes:
            cfg["repo_url"] = DEFAULT_REPO_URL
        else:
            cfg["repo_url"] = Prompt.ask(
                "[bold]Azure DevOps repository URL[/bold]",
                default=DEFAULT_REPO_URL,
                console=console,
            )
    if not cfg.get("branch"):
        if yes:
            cfg["branch"] = DEFAULT_BRANCH
        else:
            cfg["branch"] = Prompt.ask("Branch", default=DEFAULT_BRANCH, console=console)
    if not cfg.get("provider"):
        detected = detect_providers()
        if len(detected) == 1:
            console.print(f"[dim]Auto-detected provider:[/dim] {detected[0]}")
            cfg["provider"] = detected[0]
        elif yes:
            cfg["provider"] = detected[0] if detected else "claude"
        else:
            default = detected[0] if detected else "claude"
            cfg["provider"] = Prompt.ask(
                "Provider", choices=VALID_PROVIDERS, default=default, console=console,
            )
    if not cfg.get("scope"):
        if yes:
            cfg["scope"] = "global"
        else:
            cfg["scope"] = Prompt.ask(
                "Scope", choices=VALID_SCOPES, default="global", console=console,
            )
    return cfg


def _build_and_show_plan(
    entries: list,
    repo_root: Path,
    provider: str,
    scope: str,
    project_path: Path,
    managed_files: dict,
    label: str = "Skills + Workflows",
) -> tuple[list, dict]:
    """Build sync plan, display table, return (plan, counts)."""
    plan = sync.build_plan(
        entries,
        repo_root,
        provider,
        scope,
        project_path if scope == "project" else None,
        managed_files,
    )
    adds      = sum(1 for a in plan if a.action == "add")
    updates   = sum(1 for a in plan if a.action == "update")
    skips     = sum(1 for a in plan if a.action == "skip")
    conflicts = sum(1 for a in plan if a.action == "conflict")

    table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
    table.add_column(label)
    table.add_column("Category", style="dim")
    table.add_column("Owner", style="dim")
    table.add_column("Action")
    table.add_column("Destination", style="dim")

    _COLOR = {"add": "green", "update": "cyan", "skip": "dim", "conflict": "red"}
    for action in plan:
        color = _COLOR[action.action]
        extra = f"  ({len(action.conflict_files)} file(s))" if action.conflict_files else ""
        table.add_row(
            action.entry.id,
            action.entry.category or "—",
            action.entry.owner or "—",
            f"[{color}]{action.action.upper()}{extra}[/{color}]",
            str(action.local_dest),
        )

    console.print(table)
    console.print(
        f"\n[dim]{adds} add · {updates} update · {skips} skip · {conflicts} conflict[/dim]"
    )
    counts = {"adds": adds, "updates": updates, "skips": skips, "conflicts": conflicts}
    return plan, counts


# ---------------------------------------------------------------------------
# framework-sync
# ---------------------------------------------------------------------------

@app.command(name="framework-sync")
def framework_sync_cmd(
    provider: Optional[str] = typer.Option(None, "--provider", help="claude or copilot"),
    scope: Optional[str] = typer.Option(None, "--scope", help="global or project"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview changes without writing files"),
    force: bool = typer.Option(False, "--force", help="Overwrite locally modified managed files"),
    project_path: Optional[str] = typer.Option(None, "--project-path", help="Project root (defaults to cwd)"),
    workflow: Optional[str] = typer.Option(None, "--workflow", help="Scope to a workflow and its dep closure, e.g. emt-wf-ip-planning"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Non-interactive mode: accept all defaults (for CI)"),
) -> None:
    """Populate skills, workflows, and agents into Claude Code.

    Default (no --workflow): syncs the 'default' bundle (master + utilities +
    anthropics + context-engineering) plus ALL workflows and ALL agents.

    With --workflow <id>: syncs the default bundle + the target workflow's dep
    closure (transitively linked workflows, their agents, and those agents' skills).
    """
    # ── 1. Config ────────────────────────────────────────────────────────
    global_cfg = state.load_config()
    _start_path = Path(project_path or Path.cwd())
    _project_config_path = find_project_config(_start_path)
    project_cfg: dict = {}
    if _project_config_path:
        try:
            project_cfg = load_project_config(_project_config_path)
            console.print(f"[dim]Using .flezi-emt/config.yaml from {_project_config_path}[/dim]")
        except ValueError as exc:
            console.print(f"[yellow]⚠ {exc} — project config ignored[/yellow]")

    cli_overrides: dict = {}
    if provider:
        cli_overrides["provider"] = provider
    if scope:
        cli_overrides["scope"] = scope
    if project_path:
        cli_overrides["project_path"] = project_path

    cfg = merge_configs(global_cfg, project_cfg, cli_overrides)
    cfg = _setup_wizard(cfg, yes=yes)

    if provider and provider not in VALID_PROVIDERS:
        console.print(f"[red]Unknown provider '{provider}'. Valid: {VALID_PROVIDERS}[/red]")
        raise typer.Exit(1)
    if scope and scope not in VALID_SCOPES:
        console.print(f"[red]Unknown scope '{scope}'. Valid: {VALID_SCOPES}[/red]")
        raise typer.Exit(1)

    _GLOBAL_KEYS = {"repo_url", "branch", "provider", "scope", "project_path"}
    state.save_config({k: v for k, v in cfg.items() if k in _GLOBAL_KEYS and v})

    _provider: str = cfg["provider"]
    _scope: str = cfg["scope"]
    _project_path = Path(cfg.get("project_path") or project_path or Path.cwd())
    _repo_url: str = cfg["repo_url"]
    _branch: str = cfg.get("branch", "main")

    # ── 2. Auth ──────────────────────────────────────────────────────────
    console.rule("[bold]Authenticating[/bold]")
    try:
        token = auth.get_token()
        console.print("[green]✓[/green] Authenticated")
    except Exception as exc:
        console.print(f"[red]✗ Authentication failed:[/red] {exc}")
        raise typer.Exit(1)

    # ── 3. Fetch remote ──────────────────────────────────────────────────
    console.rule("[bold]Fetching repository[/bold]")
    try:
        git_repo = repo.ensure_repo(_repo_url, _branch, token)
        commit = repo.current_commit(git_repo)
        repo_root = repo.repo_root(git_repo)
        console.print(f"[green]✓[/green] HEAD [dim]{commit[:12]}[/dim]  branch [dim]{_branch}[/dim]")
    except Exception as exc:
        console.print(f"[red]✗ Repository error:[/red] {exc}")
        raise typer.Exit(1)

    # ── 4. Parse manifest ────────────────────────────────────────────────
    try:
        manifest = load_manifest(repo_root)
        console.print(
            f"[green]✓[/green] Manifest  "
            f"[dim]{len(manifest.skills)} skills · "
            f"{len(manifest.workflows)} workflows · "
            f"{len(manifest.agents)} agents · "
            f"{len(manifest.bundles)} bundles[/dim]"
        )
    except Exception as exc:
        console.print(f"[red]✗ Manifest error:[/red] {exc}")
        raise typer.Exit(1)

    # ── 4b. Resolve what to sync ─────────────────────────────────────────
    if workflow:
        console.rule(f"[bold]Resolving deps for --workflow {workflow}[/bold]")
        try:
            deps = resolve_workflow_deps(workflow, manifest)
        except ValueError as exc:
            console.print(f"[red]✗ {exc}[/red]")
            raise typer.Exit(1)
        console.print(
            f"[green]✓[/green] Resolved: "
            f"[dim]{len(deps.workflows)} workflow(s) · "
            f"{len(deps.agents)} agent(s) · "
            f"{len(deps.skills)} skill(s)[/dim]"
        )
        # Skill entries: default bundle + workflow-specific skills
        try:
            default_entries = skill_filter.apply_filters(manifest, profile=DEFAULT_PROFILE)
        except ValueError:
            default_entries = []
        extra_skill_ids = set(deps.skills) - {e.id for e in default_entries}
        extra_entries = [s for s in manifest.skills if s.id in extra_skill_ids]
        skill_entries = default_entries + extra_entries
        # Workflow entries scoped to resolved dep closure
        wf_entries = [
            wf.as_skill_entry()
            for wf in manifest.workflows
            if wf.id in deps.workflows
        ]
        agent_ids: set[str] = set(deps.agents)
    else:
        # Default: entire default bundle + all workflows + all agents
        try:
            skill_entries = skill_filter.apply_filters(manifest, profile=DEFAULT_PROFILE)
        except ValueError:
            # default bundle not yet defined — fall back to all skills
            skill_entries = manifest.skills
        wf_entries = [wf.as_skill_entry() for wf in manifest.workflows]
        agent_ids = {a.id for a in manifest.agents}

    all_entries = skill_entries + wf_entries

    # ── 5. Populate contracts in cloned repo before copying workflow dirs ─
    console.rule("[bold]Syncing contracts[/bold]")
    contract_results = _sc.populate_envelope_to_workflows(repo_root, dry_run=dry_run)
    synced = sum(1 for r in contract_results if r.action in ("copied", "refreshed"))
    skipped_v1 = sum(1 for r in contract_results if r.action == "skipped-v1")
    up_to_date = sum(1 for r in contract_results if r.action == "up-to-date")
    console.print(
        f"[dim]Contracts: {synced} synced · {up_to_date} up-to-date · {skipped_v1} skipped (v1)[/dim]"
    )

    # ── 6. Build skill + workflow sync plan ──────────────────────────────
    console.rule("[bold]Analyzing skills & workflows[/bold]")
    st = state.load_state()
    managed_files: dict = st.get("managed_files", {})

    plan, counts = _build_and_show_plan(
        all_entries, repo_root, _provider, _scope, _project_path, managed_files,
    )

    # ── 7. Build agent sync plan ─────────────────────────────────────────
    console.rule("[bold]Analyzing agents[/bold]")
    index_data = json.loads((repo_root / "index.json").read_text(encoding="utf-8"))
    index_agents = [a for a in (index_data.get("agents") or []) if a.get("id") in agent_ids]
    _agents_dest = _project_path / ".claude" / "agents"
    agent_plan = _sa.plan_sync(index_agents, repo_root, _agents_dest)

    _AGENT_COLOR = {"add": "green", "update": "cyan", "skip": "dim", "blocked": "red"}
    agent_table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
    agent_table.add_column("Agent")
    agent_table.add_column("Action")
    agent_table.add_column("Detail", style="dim")
    for action in agent_plan:
        color = _AGENT_COLOR.get(action.action, "white")
        agent_table.add_row(
            action.name,
            f"[{color}]{action.action.upper()}[/{color}]",
            action.reason or str(action.dest),
        )
    console.print(agent_table)
    agent_adds    = sum(1 for a in agent_plan if a.action == "add")
    agent_updates = sum(1 for a in agent_plan if a.action == "update")
    agent_skips   = sum(1 for a in agent_plan if a.action == "skip")
    agent_blocked = sum(1 for a in agent_plan if a.action == "blocked")
    console.print(
        f"\n[dim]{agent_adds} add · {agent_updates} update · {agent_skips} skip · {agent_blocked} blocked[/dim]"
    )

    if dry_run:
        console.print("\n[yellow]Dry run — no files written.[/yellow]")
        return

    if counts["conflicts"] and not force:
        console.print(
            f"\n[red]{counts['conflicts']} conflict(s) detected.[/red] "
            "Re-run with [bold]--force[/bold] to overwrite."
        )
        raise typer.Exit(1)

    # ── 8. Cache index.json into project .claude/ for offline commands ───
    _index_cache = _project_path / ".claude" / "emt-brain-index.json"
    _index_cache.parent.mkdir(parents=True, exist_ok=True)
    _index_cache.write_text(
        (repo_root / "index.json").read_text(encoding="utf-8"),
        encoding="utf-8",
    )

    if counts["adds"] + counts["updates"] == 0 and agent_adds + agent_updates == 0:
        console.print("\n[green]Everything is up to date.[/green]")
        return

    # ── 9. Apply skills + workflows ──────────────────────────────────────
    console.rule("[bold]Applying skills & workflows[/bold]")
    backup_dir = (state.cache_dir().parent / "backups") if force else None
    new_managed, stats = sync.apply_plan(plan, repo_root, force=force, backup_dir=backup_dir)

    # ── 9. Apply agents ──────────────────────────────────────────────────
    console.rule("[bold]Applying agents[/bold]")
    agent_stats = _sa.apply_sync(agent_plan, dry_run=False)

    # ── 10. Persist state ────────────────────────────────────────────────
    now = datetime.now(timezone.utc).isoformat()
    st["last_commit"] = commit
    st["last_sync_time"] = now
    st["managed_files"] = new_managed
    st.setdefault("history", []).append({
        "time": now,
        "commit": commit,
        "provider": _provider,
        "scope": _scope,
        "workflow_filter": workflow or "all",
        "skills_added": stats["added"],
        "skills_updated": stats["updated"],
        "agents_added": agent_stats["added"],
    })
    state.save_state(st)

    # ── 11. Summary ──────────────────────────────────────────────────────
    console.rule()
    console.print(
        f"[bold green]✓ framework-sync complete.[/bold green]\n"
        f"  Skills/Workflows — Added [green]{stats['added']}[/green]  "
        f"Updated [cyan]{stats['updated']}[/cyan]  "
        f"Skipped [dim]{stats['skipped']}[/dim]\n"
        f"  Agents          — Added [green]{agent_stats['added']}[/green]  "
        f"Updated [cyan]{agent_stats['updated']}[/cyan]  "
        f"Skipped [dim]{agent_stats['skipped']}[/dim]"
    )


# ---------------------------------------------------------------------------
# workflow-list
# ---------------------------------------------------------------------------

@app.command(name="workflow-list")
def workflow_list_cmd(
    json_output: bool = typer.Option(False, "--json", help="Print raw JSON instead of table"),
    full: bool = typer.Option(False, "--full", help="Show agent list per workflow"),
) -> None:
    """List all available EMT workflows with their summaries."""
    index_file: Path | None = None
    current = Path.cwd().resolve()
    while True:
        candidate = current / ".claude" / "emt-brain-index.json"
        if candidate.exists():
            index_file = candidate
            break
        parent = current.parent
        if parent == current:
            break
        current = parent

    if index_file is None:
        console.print(
            "[red]✗ emt-brain-index.json not found.[/red] "
            "Run [bold]emt-brain framework-sync[/bold] first to cache the index."
        )
        raise typer.Exit(1)

    data = json.loads(index_file.read_text(encoding="utf-8"))
    if data.get("version", 1) < 4:
        console.print("[yellow]⚠ index.json version < 4 — workflow entries may be missing.[/yellow]")

    workflows = data.get("workflows", [])
    if not workflows:
        console.print("[yellow]No workflows found in index.json.[/yellow]")
        return

    if json_output:
        console.print_json(json.dumps(workflows, indent=2))
        return

    table = Table(
        show_header=True,
        header_style="bold",
        box=None,
        padding=(0, 2),
        show_lines=True,
    )
    table.add_column("Workflow ID", style="bold cyan", no_wrap=True)
    table.add_column("Entry agent", style="dim", no_wrap=True)
    table.add_column("Agents", justify="right", style="dim")
    table.add_column("Consumes")
    table.add_column("v2", justify="center")
    table.add_column("Tags", style="dim")

    for wf in sorted(workflows, key=lambda w: w.get("id", "")):
        wf_id = wf.get("id", "—")
        entry = wf.get("entry_agent", "—")
        agents = wf.get("agents") or []
        n_agents = str(len(agents))
        cwh = wf.get("consumes_workflow_handoff")
        consumes = cwh.get("workflow", "—") if isinstance(cwh, dict) else "—"
        is_v2 = "[green]✓[/green]" if wf.get("is_v2") else "[dim]—[/dim]"
        tags = ", ".join((wf.get("tags") or [])[:3])

        table.add_row(wf_id, entry, n_agents, consumes, is_v2, tags)

        if full and agents:
            for slot in agents:
                ref = slot.get("agent_ref") or slot.get("id", "?")
                gate = slot.get("gate", "")
                table.add_row(
                    f"  [dim]→ {ref}[/dim]",
                    f"[dim]gate: {gate}[/dim]" if gate else "",
                    "", "", "", "",
                )

    console.print(table)
    console.print(
        f"\n[dim]{len(workflows)} workflow(s) — "
        "run [bold]emt-brain framework-sync --workflow <id>[/bold] to scope sync[/dim]"
    )


# ---------------------------------------------------------------------------
# help
# ---------------------------------------------------------------------------

@app.command(name="help")
def help_cmd() -> None:
    """Show getting-started guide and command overview."""
    console.print(Panel.fit(
        "[bold cyan]emt-brain[/bold cyan] — populate EMT framework into your Claude Code workspace\n"
        "[dim]Version 0.8.0  ·  EMT @ FPT Software[/dim]",
        border_style="cyan",
    ))

    console.print("\n[bold]Quick start[/bold]")
    qs = Table(show_header=False, box=None, padding=(0, 2))
    qs.add_column(style="bold magenta", no_wrap=True)
    qs.add_column()
    qs.add_row(
        "init",
        "Full one-shot setup: MCP servers + 3rd-party plugins + EMT skills/agents\n"
        "[dim]  --yes             Non-interactive (accept all defaults)[/dim]\n"
        "[dim]  --dry-run         Preview without writing[/dim]",
    )
    console.print(qs)

    console.print("\n[bold]Core commands[/bold]")
    core = Table(show_header=False, box=None, padding=(0, 2))
    core.add_column(style="bold green", no_wrap=True)
    core.add_column()
    core.add_row(
        "framework-sync",
        "Sync default skills + all workflows + all agents into Claude Code\n"
        "[dim]  --workflow <id>   Scope to a workflow's dep closure[/dim]\n"
        "[dim]  --dry-run         Preview without writing[/dim]\n"
        "[dim]  --force           Overwrite locally modified files[/dim]",
    )
    core.add_row(
        "workflow-list",
        "List all available EMT workflows with summary\n"
        "[dim]  --full            Show per-workflow agent list[/dim]\n"
        "[dim]  --json            Raw JSON output[/dim]",
    )
    console.print(core)

    console.print("\n[bold]MCP & Plugins[/bold]")
    mcp = Table(show_header=False, box=None, padding=(0, 2))
    mcp.add_column(style="bold green", no_wrap=True)
    mcp.add_column()
    mcp.add_row(
        "3rd-mcp-setup",
        "Install MCP servers into Claude Code settings.json\n"
        "[dim]  npx   sequential-thinking, memory[/dim]\n"
        "[dim]  local context-mode (clone + npm install + node)[/dim]\n"
        "[dim]  --scope project   Write to project .claude/settings.json[/dim]\n"
        "[dim]  --force           Reinstall local servers[/dim]\n"
        "[dim]  --dry-run         Preview without writing[/dim]",
    )
    mcp.add_row(
        "3rd-plugins-setup",
        "Install 3rd-party skill/agent plugins (e.g. graphify)\n"
        "[dim]  Plugins: graphify (skill)[/dim]\n"
        "[dim]  --list            Show available plugins and install status[/dim]\n"
        "[dim]  --plugin <name>   Install one specific plugin[/dim]\n"
        "[dim]  --force           Reinstall even if already present[/dim]\n"
        "[dim]  --dry-run         Preview without writing[/dim]",
    )
    console.print(mcp)

    console.print("\n[bold]Utilities[/bold]")
    util = Table(show_header=False, box=None, padding=(0, 2))
    util.add_column(style="bold", no_wrap=True)
    util.add_column(style="dim")
    util.add_row("status",  "Show current sync configuration and drift")
    util.add_row("doctor",  "Run environment diagnostics (Python, git, auth, dest)")
    util.add_row("reset",   "Wipe CLI config and state (synced files are NOT deleted)")
    console.print(util)

    console.print("\n[bold]Getting started[/bold]")
    steps = Table(show_header=False, box=None, padding=(0, 2))
    steps.add_column(style="bold cyan", no_wrap=True)
    steps.add_column()
    steps.add_row("1.", "Run [bold]emt-brain init[/bold] to do everything in one go")
    steps.add_row("  or", "")
    steps.add_row("1a.", "Run [bold]emt-brain 3rd-mcp-setup[/bold] to install standard MCP servers")
    steps.add_row("1b.", "Run [bold]emt-brain 3rd-plugins-setup[/bold] to install 3rd-party plugins")
    steps.add_row("1c.", "Run [bold]emt-brain framework-sync[/bold] to install the default bundle")
    steps.add_row("2.", "Run [bold]emt-brain workflow-list[/bold] to see available workflows")
    steps.add_row("3.", "Run [bold]emt-brain framework-sync --workflow emt-wf-ip-planning[/bold] to scope to a workflow")
    steps.add_row("4.", "In Claude Code: [bold]/emt-brain-help setup-project[/bold] → init CLAUDE.md with guidelines")
    console.print(steps)

    console.print(
        "\n[dim]Tip: Each command supports [bold]--help[/bold] for full flag details.[/dim]\n"
    )


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------

@app.command()
def status() -> None:
    """Show current sync configuration and state."""
    global_cfg = state.load_config()
    st = state.load_state()

    if not global_cfg:
        console.print(
            "[yellow]Not configured.[/yellow] "
            "Run [bold]emt-brain framework-sync[/bold] to set up."
        )
        return

    _project = Path(global_cfg.get("project_path") or Path.cwd())
    _proj_cfg_path = find_project_config(_project)
    project_cfg: dict = {}
    if _proj_cfg_path:
        try:
            project_cfg = load_project_config(_proj_cfg_path)
        except ValueError:
            pass

    cfg = merge_configs(global_cfg, project_cfg, {})
    _provider = cfg.get("provider", "")
    _scope = cfg.get("scope", "")

    try:
        local_root = resolve_root(_provider, _scope, _project) if _provider and _scope else "—"
    except Exception:
        local_root = "—"

    managed: dict = st.get("managed_files", {})
    drift_count = 0
    for abs_path, meta in managed.items():
        p = Path(abs_path)
        if p.exists() and sync._hash_file(p) != meta.get("hash", ""):
            drift_count += 1

    tbl = Table(show_header=False, box=None, padding=(0, 2))
    tbl.add_column(style="bold")
    tbl.add_column()
    tbl.add_row("Repo URL",      cfg.get("repo_url", "—"))
    tbl.add_row("Branch",        cfg.get("branch", "main"))
    tbl.add_row("Provider",      _provider or "—")
    tbl.add_row("Scope",         _scope or "—")
    tbl.add_row("Local root",    str(local_root))
    if _proj_cfg_path:
        tbl.add_row("Project config", str(_proj_cfg_path))
        if project_cfg.get("profile"):
            tbl.add_row("  profile",     project_cfg["profile"])
        if project_cfg.get("filter_tags"):
            tbl.add_row("  filter_tags", project_cfg["filter_tags"])
    tbl.add_row("Last commit",   st.get("last_commit", "—"))
    tbl.add_row("Last sync",     st.get("last_sync_time", "—"))
    tbl.add_row("Managed files", str(len(managed)))
    tbl.add_row(
        "Local drift",
        f"[red]{drift_count} modified[/red]" if drift_count else "[green]clean[/green]",
    )
    console.print(tbl)


# ---------------------------------------------------------------------------
# doctor
# ---------------------------------------------------------------------------

@app.command()
def doctor() -> None:
    """Run environment diagnostics."""
    all_ok = True

    def chk(label: str, ok: bool, detail: str = "") -> None:
        nonlocal all_ok
        icon = "[green]✓[/green]" if ok else "[red]✗[/red]"
        note = f"  [dim]{detail}[/dim]" if detail else ""
        console.print(f"  {icon}  {label}{note}")
        if not ok:
            all_ok = False

    console.rule("[bold]Diagnostics[/bold]")
    chk("Python ≥ 3.10", sys.version_info >= (3, 10), sys.version.split()[0])
    git_bin = shutil.which("git")
    chk("Git installed", git_bin is not None, git_bin or "not found")

    cfg = state.load_config()
    chk("Config file exists", bool(cfg), str(state.config_path()))
    chk("repo_url configured", bool(cfg.get("repo_url")))
    chk("provider configured", bool(cfg.get("provider")))
    chk("scope configured",    bool(cfg.get("scope")))

    try:
        auth.get_token()
        chk("Azure authentication", True)
    except Exception as exc:
        chk("Azure authentication", False, str(exc)[:100])

    if cfg.get("repo_url"):
        try:
            token    = auth.get_token()
            git_repo = repo.ensure_repo(cfg["repo_url"], cfg.get("branch", "main"), token)
            chk("Repository accessible", True, repo.current_commit(git_repo)[:12])
        except Exception as exc:
            chk("Repository accessible", False, str(exc)[:100])

    if cfg.get("provider") and cfg.get("scope"):
        try:
            root = resolve_root(cfg["provider"], cfg["scope"])
            root.mkdir(parents=True, exist_ok=True)
            chk("Destination path writable", True, str(root))
        except Exception as exc:
            chk("Destination path writable", False, str(exc)[:100])

    sp = state.state_path()
    if sp.exists():
        try:
            import json as _json
            _json.loads(sp.read_text(encoding="utf-8"))
            chk("State file valid", True, str(sp))
        except Exception as exc:
            chk("State file valid", False, str(exc))
    else:
        chk("State file", True, "not yet created — OK")

    _start = Path(cfg.get("project_path") or Path.cwd()) if cfg else Path.cwd()
    proj_cfg_path = find_project_config(_start)
    if proj_cfg_path:
        try:
            load_project_config(proj_cfg_path)
            chk(".flezi-emt/config.yaml valid", True, str(proj_cfg_path))
        except ValueError as exc:
            chk(".flezi-emt/config.yaml valid", False, str(exc))
    else:
        chk(".flezi-emt/config.yaml", True, "not found — using global config only")

    console.rule()
    if all_ok:
        console.print("[bold green]All checks passed.[/bold green]")
    else:
        console.print("[bold red]Some checks failed — see above.[/bold red]")


# ---------------------------------------------------------------------------
# 3rd-mcp-setup
# ---------------------------------------------------------------------------

@app.command(name="3rd-mcp-setup")
def mcp_setup_cmd(
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without writing"),
    force: bool = typer.Option(False, "--force", help="Re-install even if already configured"),
) -> None:
    """Install and activate MCP servers at USER scope (available in all projects).

    Servers installed:
      sequential-thinking   npx        @modelcontextprotocol/server-sequential-thinking
      context-mode          npm-global  context-mode (server.bundle.mjs — NOT the CLI)
      memory                npx        @modelcontextprotocol/server-memory  [optional — deferred]

    Installation: uses `claude mcp add -s user` when claude CLI is available,
    otherwise writes to ~/.claude/settings.json. Always user scope — never project/local.

    Restart Claude Code after running to activate new servers.
    """
    console.rule("[bold]MCP Server Setup[/bold]")

    if not _mcp.check_npx_available():
        console.print(
            "[yellow]⚠  npx not found — npx-mode servers need Node.js.[/yellow]\n"
            "[dim]   Install Node.js (https://nodejs.org) to enable them.[/dim]"
        )
    if not _mcp.check_npm_available():
        console.print(
            "[yellow]⚠  npm not found — context-mode needs npm for global install.[/yellow]"
        )

    use_cli = _mcp.check_claude_cli_available()
    if use_cli:
        console.print("[dim]Using `claude mcp add -s user` (guaranteed user scope)[/dim]")
    else:
        console.print("[dim]claude CLI not found — writing to ~/.claude/settings.json[/dim]")

    settings_path, statuses = _mcp.setup_mcp_servers(
        dry_run=dry_run,
        force=force,
    )

    console.print(f"\n[dim]Settings file: {settings_path}[/dim]\n")

    table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
    table.add_column("MCP Server", style="bold", no_wrap=True)
    table.add_column("Mode", style="dim")
    table.add_column("Status")
    table.add_column("Package / Source", style="dim")

    for s in statuses:
        if s.error:
            status_str = f"[red]FAILED — {s.error}[/red]"
        elif s.already_configured:
            status_str = "[dim]already configured[/dim]"
        elif s.added:
            status_str = "[green]ADDED[/green]"
        else:
            status_str = "[yellow]would add (dry-run)[/yellow]"
        table.add_row(s.display_name, s.mode, status_str, s.package)

    console.print(table)

    if dry_run:
        console.print("\n[yellow]Dry run — no files written.[/yellow]")
        return

    added_count = sum(1 for s in statuses if s.added)
    already_count = sum(1 for s in statuses if s.already_configured)
    failed_count = sum(1 for s in statuses if s.error)

    console.print()
    if added_count:
        console.print(
            f"[bold green]✓ {added_count} server(s) added to {settings_path}[/bold green]\n"
            "[dim]Restart Claude Code to activate the new MCP servers.[/dim]"
        )
    if already_count and not added_count:
        console.print(
            f"[green]✓ All MCP servers already configured ({already_count} server(s)).[/green]"
        )
    if failed_count:
        console.print(f"[bold red]✗ {failed_count} server(s) failed — see above.[/bold red]")
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# hook-setup
# ---------------------------------------------------------------------------

@app.command(name="hook-setup")
def hook_setup_cmd(
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without writing"),
    force: bool = typer.Option(False, "--force", help="Overwrite existing scripts and hooks block"),
) -> None:
    """Install HARNESS hook pipeline to ~/.claude/hooks/ (user scope).

    Scripts installed to ~/.claude/hooks/:
      context-pct.mjs          UserPromptSubmit  60/65/70% HARNESS meter
      signal-density-gate.mjs  PreToolUse/Read   Block re-reading same file
      distraction-filter.mjs   PreToolUse/Read+WebFetch  Block noise files
      observation-masking.mjs  PostToolUse       Mask outputs >2KB
      compaction-trigger.mjs   PostToolUse       85% last-resort warning
      poisoning-detector.mjs   PostToolUse       Detect error loops ≥3×
      session-cleanup.mjs      SessionStart      Reset per-session state files
      lib/context-usage.mjs    (shared)          Usage math: tokens → percent

    Also merges HARNESS hooks block into ~/.claude/settings.json (user scope).
    Projects do not need their own hooks — one install applies to all sessions.

    Prerequisite: context-mode must be installed globally:
      npm install -g context-mode
    Verify with: context-mode doctor
    """
    console.rule("[bold]HARNESS Hook Setup[/bold]")

    if dry_run:
        console.print("[dim]Dry-run mode — no files will be written.[/dim]\n")

    # 1. Install scripts
    hooks_dir, installed, skipped = _hooks.install_hook_scripts(dry_run=dry_run)
    console.print(f"[dim]Hooks directory: {hooks_dir}[/dim]")

    if installed:
        for s in installed:
            label = "[dim](dry-run)[/dim] " if dry_run else ""
            console.print(f"  {label}[green]✓[/green] {s}")
    if skipped:
        for s in skipped:
            console.print(f"  [yellow]~[/yellow] {s} [dim](already exists — use --force to overwrite)[/dim]")

    # 2. Update ~/.claude/settings.json
    settings_path, already_had = _hooks.update_user_settings(dry_run=dry_run, force=force)
    console.print(f"\n[dim]Settings: {settings_path}[/dim]")
    if already_had and not force:
        console.print("  [yellow]~[/yellow] hooks block [dim](already present — use --force to overwrite)[/dim]")
    else:
        label = "[dim](dry-run)[/dim] " if dry_run else ""
        console.print(f"  {label}[green]✓[/green] hooks block written")

    console.print(
        "\n[bold green]Done.[/bold green] Restart Claude Code to activate hooks.\n"
        "[dim]Verify: run `context-mode doctor` in a new session — [HARNESS/context] should appear.[/dim]"
    )


# ---------------------------------------------------------------------------
# reset
# ---------------------------------------------------------------------------

@app.command()
def reset(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt (for CI)"),
) -> None:
    """Delete CLI config and state. Already-synced files are NOT removed."""
    if not yes:
        console.print(
            "[yellow]This will remove config and state files.[/yellow]\n"
            "[dim]Files already synced into provider directories are NOT deleted.[/dim]\n"
        )
        if not Confirm.ask("Proceed?", console=console):
            console.print("Aborted.")
            return

    removed: list[str] = []
    for path in (state.config_path(), state.state_path()):
        if path.exists():
            path.unlink()
            removed.append(str(path))

    if removed:
        for r in removed:
            console.print(f"[dim]Removed: {r}[/dim]")
        console.print("[green]✓ Reset complete.[/green]")
    else:
        console.print("[dim]Nothing to remove.[/dim]")


# ---------------------------------------------------------------------------
# 3rd-plugins-setup
# ---------------------------------------------------------------------------

@app.command(name="3rd-plugins-setup")
def plugins_setup_cmd(
    list_only: bool = typer.Option(False, "--list", help="Show available plugins and their install status, then exit"),
    plugin: Optional[str] = typer.Option(None, "--plugin", help="Install only this plugin by name"),
    scope: str = typer.Option("global", "--scope", help="global or project — where .claude/ lives"),
    project_path: Optional[str] = typer.Option(None, "--project-path", help="Project root (used when --scope=project)"),
    force: bool = typer.Option(False, "--force", help="Reinstall even if the plugin is already present"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without writing files"),
) -> None:
    """Install 3rd-party skill/agent/MCP plugins from public GitHub repos.

    Available plugins:
      graphify   skill  Convert any input to a knowledge graph

    MCP servers (e.g. context-mode) are managed by 3rd-mcp-setup, not here.

    Examples:
      emt-brain 3rd-plugins-setup                       # install all missing
      emt-brain 3rd-plugins-setup --list                # status only
      emt-brain 3rd-plugins-setup --plugin graphify
      emt-brain 3rd-plugins-setup --force               # reinstall
    """
    console.rule("[bold]3rd-Party Plugins Setup[/bold]")

    if scope not in VALID_SCOPES:
        console.print(f"[red]Unknown scope '{scope}'. Valid: {VALID_SCOPES}[/red]")
        raise typer.Exit(1)

    _project_path = Path(project_path) if project_path else None

    # Validate --plugin if supplied
    if plugin and plugin not in _plugins.PLUGINS:
        available = ", ".join(_plugins.PLUGINS)
        console.print(f"[red]Unknown plugin '{plugin}'. Available: {available}[/red]")
        raise typer.Exit(1)

    target_names = [plugin] if plugin else list(_plugins.PLUGINS)

    # Build status table
    all_statuses = _plugins.list_plugins(scope=scope, project_path=_project_path)
    shown = [s for s in all_statuses if s["name"] in target_names]

    tbl = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
    tbl.add_column("Plugin", style="bold", no_wrap=True)
    tbl.add_column("Type", style="dim")
    tbl.add_column("Status")
    tbl.add_column("Source", style="dim")

    for s in shown:
        if s["installed"]:
            status_str = "[green]installed[/green]"
        else:
            status_str = "[yellow]not installed[/yellow]"
        tbl.add_row(
            s["display_name"],
            s["type"],
            status_str,
            s["source"],
        )

    console.print(tbl)

    if list_only:
        console.print(f"\n[dim]{len(shown)} plugin(s). Re-run without --list to install.[/dim]")
        return

    # Install phase
    needs_install = [s["name"] for s in shown if not s["installed"] or force]
    if not needs_install:
        console.print("\n[green]✓ All plugins already installed.[/green]")
        return

    if dry_run:
        console.print(f"\n[yellow]Dry run — would install: {', '.join(needs_install)}[/yellow]")
        return

    git_bin = shutil.which("git")
    if not git_bin:
        console.print("[red]✗ git not found on PATH. Install git to continue.[/red]")
        raise typer.Exit(1)

    console.print()
    results: list[_plugins.PluginStatus] = []
    for name in needs_install:
        console.print(f"[dim]Installing {name}…[/dim]")
        result = _plugins.install_plugin(
            name,
            scope=scope,
            project_path=_project_path,
            dry_run=dry_run,
            force=force,
        )
        results.append(result)

    console.print()
    result_tbl = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
    result_tbl.add_column("Plugin", style="bold", no_wrap=True)
    result_tbl.add_column("Result")
    result_tbl.add_column("Path", style="dim")

    for r in results:
        if r.error:
            result_str = f"[red]FAILED — {r.error}[/red]"
        elif r.installed:
            result_str = "[green]INSTALLED[/green]"
        else:
            result_str = "[dim]already present[/dim]"
        result_tbl.add_row(r.display_name, result_str, str(r.install_path))

    console.print(result_tbl)

    installed_count = sum(1 for r in results if r.installed)
    failed_count = sum(1 for r in results if r.error)

    console.print()
    if installed_count:
        mcp_count = sum(
            1 for r in results
            if r.installed and _plugins.PLUGINS.get(r.name, {}).get("type") == "mcp"
        )
        console.print(f"[bold green]✓ {installed_count} plugin(s) installed.[/bold green]")
        if mcp_count:
            console.print(
                f"[dim]  {mcp_count} MCP plugin(s) registered in settings.json — "
                "restart Claude Code to activate.[/dim]"
            )
    if failed_count:
        console.print(f"[bold red]✗ {failed_count} plugin(s) failed — see above.[/bold red]")
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------

@app.command(name="init")
def init_cmd(
    scope: str = typer.Option("global", "--scope", help="global or project — where .claude/ lives"),
    project_path: Optional[str] = typer.Option(None, "--project-path", help="Project root (defaults to cwd)"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without writing files"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Non-interactive mode: accept all defaults (for CI)"),
    skip_plugins: bool = typer.Option(False, "--skip-plugins", help="Skip 3rd-party plugins setup"),
    skip_mcp: bool = typer.Option(False, "--skip-mcp", help="Skip MCP servers setup"),
    skip_sync: bool = typer.Option(False, "--skip-sync", help="Skip framework-sync"),
    skip_hooks: bool = typer.Option(False, "--skip-hooks", help="Skip HARNESS hook pipeline setup"),
) -> None:
    """Full one-shot workspace setup.

    Runs five steps in order:
      1. 3rd-mcp-setup   — install MCP servers at user scope (sequential-thinking, context-mode)
      2. mcp-verify      — verify context-mode CLI is in PATH
      3. framework-sync  — sync EMT default bundle + all workflows + agents
      4. 3rd-plugins-setup — install 3rd-party plugins (e.g. graphify)
      5. hook-setup      — install HARNESS hook pipeline to ~/.claude/hooks/

    Use --skip-* flags to skip individual steps if already done.
    """
    console.print(Panel.fit(
        "[bold cyan]emt-brain init[/bold cyan] — full workspace setup\n"
        "[dim]Steps: mcp-setup → mcp-verify → framework-sync → plugins → hook-setup[/dim]",
        border_style="cyan",
    ))

    if scope not in VALID_SCOPES:
        console.print(f"[red]Unknown scope '{scope}'. Valid: {VALID_SCOPES}[/red]")
        raise typer.Exit(1)

    _project_path = Path(project_path) if project_path else Path.cwd()
    any_error = False

    # ── Step 1: MCP setup ───────────────────────────────────────────────────
    if not skip_mcp:
        console.rule("[bold]Step 1 of 5 — MCP Servers[/bold]")

        if not _mcp.check_npx_available():
            console.print(
                "[yellow]⚠  npx not found — MCP servers run via npx.[/yellow]\n"
                "[dim]   Install Node.js (https://nodejs.org) to enable them.[/dim]"
            )

        settings_path, mcp_statuses = _mcp.setup_mcp_servers(
            dry_run=dry_run,
        )

        mcp_tbl = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
        mcp_tbl.add_column("MCP Server", style="bold", no_wrap=True)
        mcp_tbl.add_column("Status")
        mcp_tbl.add_column("Package", style="dim")

        for s in mcp_statuses:
            if s.already_configured:
                st_str = "[dim]already configured[/dim]"
            elif s.added:
                st_str = "[green]ADDED[/green]"
            else:
                st_str = "[yellow]would add (dry-run)[/yellow]"
            mcp_tbl.add_row(s.display_name, st_str, s.package)

        console.print(mcp_tbl)
        mcp_added = sum(1 for s in mcp_statuses if s.added)
        if mcp_added and not dry_run:
            console.print(
                f"[dim]→ {mcp_added} server(s) written to {settings_path}[/dim]\n"
                "[dim]  Restart Claude Code to activate.[/dim]"
            )
    else:
        console.print("[dim]Step 1 skipped (--skip-mcp)[/dim]")

    # ── Step 2: MCP verify ──────────────────────────────────────────────────
    console.rule("[bold]Step 2 of 5 — MCP Verify[/bold]")
    checks = [
        ("npx", _mcp.check_npx_available(), "sequential-thinking runtime"),
        ("context-mode", bool(shutil.which("context-mode")), "hook CLI + MCP server (npm install -g context-mode)"),
    ]
    all_ok = True
    for name, ok, note in checks:
        if ok:
            console.print(f"  [green]✓[/green] {name} [dim]({note})[/dim]")
        else:
            console.print(f"  [yellow]⚠[/yellow]  {name} not found — {note}")
            all_ok = False
    if not all_ok:
        console.print("[dim]Install missing tools, then restart Claude Code.[/dim]")

    # ── Step 3: framework-sync ──────────────────────────────────────────────
    if not skip_sync:
        console.rule("[bold]Step 3 of 5 — Framework Sync[/bold]")
        console.print("[dim]Delegating to framework-sync…[/dim]\n")
        try:
            framework_sync_cmd(
                provider=None,
                scope=scope,
                dry_run=dry_run,
                force=False,
                project_path=project_path,
                workflow=None,
                yes=yes,
            )
        except SystemExit as exc:
            if exc.code != 0:
                any_error = True
    else:
        console.print("[dim]Step 3 skipped (--skip-sync)[/dim]")

    # ── Step 4: 3rd-party plugins ───────────────────────────────────────────
    if not skip_plugins:
        console.rule("[bold]Step 4 of 5 — 3rd-Party Plugins[/bold]")

        git_bin = shutil.which("git")
        if not git_bin:
            console.print("[yellow]⚠  git not found — skipping plugin installation.[/yellow]")
        else:
            plugin_list = _plugins.list_plugins(scope=scope, project_path=_project_path)
            needs_install = [p["name"] for p in plugin_list if not p["installed"]]

            if not needs_install:
                console.print("[green]✓ All plugins already installed.[/green]")
            elif dry_run:
                console.print(f"[yellow]Would install: {', '.join(needs_install)}[/yellow]")
            else:
                plugin_results: list[_plugins.PluginStatus] = []
                for name in needs_install:
                    console.print(f"[dim]Installing {name}…[/dim]")
                    res = _plugins.install_plugin(name, scope=scope, project_path=_project_path)
                    plugin_results.append(res)
                    if res.error:
                        console.print(f"  [red]✗ {res.display_name}: {res.error}[/red]")
                        any_error = True
                    else:
                        pip_note = " [dim](+ pip)[/dim]" if res.pip_installed else ""
                        console.print(f"  [green]✓ {res.display_name} installed → {res.install_path}{pip_note}[/green]")
    else:
        console.print("[dim]Step 4 skipped (--skip-plugins)[/dim]")

    # ── Step 5: HARNESS hook pipeline ───────────────────────────────────────
    if not skip_hooks:
        console.rule("[bold]Step 5 of 5 — HARNESS Hook Pipeline[/bold]")
        hooks_dir, installed, skipped = _hooks.install_hook_scripts(dry_run=dry_run)
        settings_path_h, already_had = _hooks.update_user_settings(dry_run=dry_run)
        if installed:
            console.print(f"  [green]✓[/green] {len(installed)} script(s) → {hooks_dir}")
        if skipped:
            console.print(f"  [dim]~ {len(skipped)} already present (--force to overwrite)[/dim]")
        if already_had:
            console.print("  [dim]~ hooks block already in ~/.claude/settings.json[/dim]")
        else:
            label = "(dry-run) " if dry_run else ""
            console.print(f"  [green]✓[/green] {label}hooks block → {settings_path_h}")
    else:
        console.print("[dim]Step 5 skipped (--skip-hooks)[/dim]")

    # ── Summary ─────────────────────────────────────────────────────────────
    console.rule()
    if any_error:
        console.print("[bold red]init completed with errors — see above.[/bold red]")
        raise typer.Exit(1)
    elif dry_run:
        console.print("[yellow]Dry run complete — no files written.[/yellow]")
    else:
        console.print(
            "[bold green]✓ init complete.[/bold green]\n"
            "[dim]Next: restart Claude Code, then run [bold]emt-brain workflow-list[/bold] to see available workflows.[/dim]"
        )
