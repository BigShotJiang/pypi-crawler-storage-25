"""Tests for core authentication functionality."""
