# Changelog

## [0.2.0] - 2025-04-02

### Added
- `TokenExpiredError` and `TokenInvalidError` exceptions for proper error handling
- `VerifyResult` dataclass with `needs_rehash` support for automatic hash upgrades
- `TokenPair` dataclass for access/refresh token workflows
- `create_token_pair()` for generating access + refresh tokens
- `refresh_tokens()` for token refresh flow
- `hash_async()` and `verify_async()` for non-blocking password operations
- `jti` claim for token revocation support
- `iat` claim for post-password-change invalidation
- `nbf` (not before) claim support
- `old_secret_keys` parameter for secret key rotation
- `password_validator` callback for custom password strength rules
- `generate_secret_key()` and `generate_csrf_token()` helpers
- Constant-time comparison for token type validation

### Changed
- Minimum secret key length now enforced (32 bytes)
- `verify()` now returns `VerifyResult` instead of `bool`
- All JWT errors now raise specific exceptions instead of returning `None`
- Internal attributes now use underscore prefix

### Security
- Fixed timing attack vector in token type comparison
- Added algorithm restriction to prevent `alg: none` attacks
- Generic error messages to prevent information leakage

## [0.1.0] - 2025-03-XX

### Added
- Initial release
- Basic password hashing with Argon2id
- JWT creation and decoding