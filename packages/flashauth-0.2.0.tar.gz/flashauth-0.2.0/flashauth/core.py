"""Core authentication functionality."""
"""
FlashAuth - Secure authentication for FastAPI and Python 3.13+

No 72-byte password limits. No deprecated dependencies. Just works.
"""

import secrets
import hmac
import asyncio
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from typing import Optional, Dict, Any, List, Callable
from dataclasses import dataclass

from jose import jwt, JWTError, ExpiredSignatureError
from pwdlib import PasswordHash


__version__ = "0.2.0"
__all__ = [
    "FlashAuth",
    "TokenError",
    "TokenExpiredError", 
    "TokenInvalidError",
    "VerifyResult",
    "TokenPair",
]


# =============================================================================
# Exceptions
# =============================================================================

class TokenError(Exception):
    """Base exception for token-related errors."""
    pass


class TokenExpiredError(TokenError):
    """Raised when a token has expired."""
    pass


class TokenInvalidError(TokenError):
    """Raised when a token is invalid (bad signature, malformed, etc.)."""
    pass


# =============================================================================
# Data Classes
# =============================================================================

@dataclass(frozen=True)
class VerifyResult:
    """Result of password verification."""
    valid: bool
    needs_rehash: bool = False
    new_hash: Optional[str] = None


@dataclass(frozen=True)
class TokenPair:
    """Access and refresh token pair."""
    access_token: str
    refresh_token: str
    access_expires_at: datetime
    refresh_expires_at: datetime


# =============================================================================
# Main Class
# =============================================================================

class FlashAuth:
    """
    Secure authentication helper for FastAPI and Python 3.13+.
    
    Features:
        - Argon2id password hashing (no 72-byte limit)
        - JWT creation and validation with proper security claims
        - Access/refresh token pairs
        - Async support for non-blocking password operations
        - Secret key rotation support
        - Python 3.13 ready (no crypt module dependency)
    
    Thread-safe: All methods can be called from multiple threads.
    
    Example:
        auth = FlashAuth(secret_key=FlashAuth.generate_secret_key())
        
        # Hash and verify passwords
        hashed = auth.hash("my-secure-password")
        result = auth.verify("my-secure-password", hashed)
        
        # Create and validate tokens
        token = auth.create_token({"user_id": 123})
        payload = auth.decode_token(token)
    """
    
    MIN_SECRET_KEY_BYTES = 32
    
    def __init__(
        self,
        secret_key: str,
        algorithm: str = "HS256",
        access_token_expire_minutes: int = 30,
        refresh_token_expire_minutes: int = 60 * 24 * 7,
        issuer: Optional[str] = None,
        audience: Optional[str] = None,
        old_secret_keys: Optional[List[str]] = None,
        password_validator: Optional[Callable[[str], None]] = None,
    ):
        """
        Initialize FlashAuth.
        
        Args:
            secret_key: Primary signing key (min 32 bytes).
            algorithm: JWT algorithm (HS256, HS384, or HS512).
            access_token_expire_minutes: Access token lifetime. Default: 30.
            refresh_token_expire_minutes: Refresh token lifetime. Default: 7 days.
            issuer: Optional JWT issuer claim.
            audience: Optional JWT audience claim.
            old_secret_keys: Previous keys to accept during rotation.
            password_validator: Optional callback to validate password strength.
                                Should raise ValueError if password is weak.
        
        Raises:
            ValueError: If secret_key is too short or algorithm is invalid.
        """
        self._validate_secret_key(secret_key)
        for old_key in (old_secret_keys or []):
            self._validate_secret_key(old_key, param_name="old_secret_keys")
        
        allowed_algorithms = {"HS256", "HS384", "HS512"}
        if algorithm not in allowed_algorithms:
            raise ValueError(f"algorithm must be one of {allowed_algorithms}")
        
        if access_token_expire_minutes <= 0:
            raise ValueError("access_token_expire_minutes must be positive")
        if refresh_token_expire_minutes <= 0:
            raise ValueError("refresh_token_expire_minutes must be positive")
        
        self._secret_key = secret_key
        self._algorithm = algorithm
        self._access_token_expire_minutes = access_token_expire_minutes
        self._refresh_token_expire_minutes = refresh_token_expire_minutes
        self._issuer = issuer
        self._audience = audience
        self._old_secret_keys = old_secret_keys or []
        self._password_validator = password_validator
        self._password_helper = PasswordHash.recommended()
        self._executor = ThreadPoolExecutor(max_workers=4)
    
    @classmethod
    def _validate_secret_key(cls, key: str, param_name: str = "secret_key") -> None:
        if not key:
            raise ValueError(f"{param_name} cannot be empty")
        if len(key.encode("utf-8")) < cls.MIN_SECRET_KEY_BYTES:
            raise ValueError(
                f"{param_name} must be at least {cls.MIN_SECRET_KEY_BYTES} bytes. "
                f"Generate one with: FlashAuth.generate_secret_key()"
            )

    # =========================================================================
    # Password Hashing
    # =========================================================================

    def hash(self, password: str) -> str:
        """
        Hash a password using Argon2id.
        
        Args:
            password: Plaintext password (any length).
            
        Returns:
            Hashed password string.
            
        Raises:
            ValueError: If password is empty or fails validation.
        """
        if not password:
            raise ValueError("password cannot be empty")
        
        if self._password_validator:
            self._password_validator(password)
        
        return self._password_helper.hash(password)

    async def hash_async(self, password: str) -> str:
        """Hash a password without blocking the event loop."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(self._executor, self.hash, password)

    def verify(self, plain: str, hashed: str) -> VerifyResult:
        """
        Verify a password against a hash.
        
        Args:
            plain: Plaintext password to verify.
            hashed: Stored hash to verify against.
            
        Returns:
            VerifyResult with valid, needs_rehash, and new_hash fields.
            
        Example:
            result = auth.verify(password, stored_hash)
            if result.valid:
                if result.needs_rehash:
                    user.password_hash = result.new_hash
                    await user.save()
        """
        if not plain or not hashed:
            return VerifyResult(valid=False)
        
        try:
            valid, new_hash = self._password_helper.verify_and_update(plain, hashed)
            return VerifyResult(
                valid=valid,
                needs_rehash=new_hash is not None,
                new_hash=new_hash,
            )
        except Exception:
            return VerifyResult(valid=False)

    async def verify_async(self, plain: str, hashed: str) -> VerifyResult:
        """Verify a password without blocking the event loop."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(self._executor, self.verify, plain, hashed)

    # =========================================================================
    # JWT Creation
    # =========================================================================

    def create_token(
        self,
        data: Dict[str, Any],
        expires_delta: Optional[int] = None,
        token_type: str = "access",
        include_jti: bool = True,
        not_before: Optional[datetime] = None,
    ) -> str:
        """
        Create a signed JWT.
        
        Args:
            data: Custom claims (e.g., {"user_id": 123}).
            expires_delta: Override expiration in minutes.
            token_type: Token purpose ("access" or "refresh").
            include_jti: Include unique token ID for revocation support.
            not_before: Optional datetime before which token is invalid.
            
        Returns:
            Encoded JWT string.
            
        Raises:
            ValueError: If data contains reserved claims.
        """
        to_encode = data.copy()
        
        reserved_claims = {"exp", "iat", "iss", "aud", "typ", "jti", "nbf"}
        conflicts = reserved_claims & to_encode.keys()
        if conflicts:
            raise ValueError(f"data cannot contain reserved claims: {conflicts}")
        
        now = datetime.now(timezone.utc)
        
        if expires_delta is not None:
            if expires_delta <= 0:
                raise ValueError("expires_delta must be positive")
            minutes = expires_delta
        elif token_type == "refresh":
            minutes = self._refresh_token_expire_minutes
        else:
            minutes = self._access_token_expire_minutes
        
        expire = now + timedelta(minutes=minutes)
        
        to_encode.update({
            "exp": expire,
            "iat": now,
            "typ": token_type,
        })
        
        if include_jti:
            to_encode["jti"] = secrets.token_urlsafe(16)
        
        if not_before:
            to_encode["nbf"] = not_before
        
        if self._issuer:
            to_encode["iss"] = self._issuer
        if self._audience:
            to_encode["aud"] = self._audience
        
        return jwt.encode(to_encode, self._secret_key, algorithm=self._algorithm)

    def create_token_pair(self, data: Dict[str, Any]) -> TokenPair:
        """
        Create an access/refresh token pair.
        
        Args:
            data: Custom claims (e.g., {"user_id": 123}).
            
        Returns:
            TokenPair with access_token, refresh_token, and expiry times.
        """
        now = datetime.now(timezone.utc)
        
        return TokenPair(
            access_token=self.create_token(data, token_type="access"),
            refresh_token=self.create_token(data, token_type="refresh"),
            access_expires_at=now + timedelta(minutes=self._access_token_expire_minutes),
            refresh_expires_at=now + timedelta(minutes=self._refresh_token_expire_minutes),
        )

    def refresh_tokens(self, refresh_token: str) -> TokenPair:
        """
        Exchange a refresh token for a new token pair.
        
        Important: Invalidate the old refresh token's jti after calling this.
        
        Args:
            refresh_token: Valid refresh token.
            
        Returns:
            New TokenPair.
            
        Raises:
            TokenExpiredError: If refresh token has expired.
            TokenInvalidError: If refresh token is invalid.
        """
        payload = self.decode_token(refresh_token, expected_type="refresh")
        
        standard_claims = {"exp", "iat", "iss", "aud", "typ", "jti", "nbf"}
        user_data = {k: v for k, v in payload.items() if k not in standard_claims}
        
        return self.create_token_pair(user_data)

    # =========================================================================
    # JWT Decoding
    # =========================================================================

    def decode_token(
        self,
        token: str,
        expected_type: Optional[str] = "access",
    ) -> Dict[str, Any]:
        """
        Decode and validate a JWT.
        
        Args:
            token: JWT string to decode.
            expected_type: Expected token type (None to skip check).
            
        Returns:
            Decoded token payload.
            
        Raises:
            TokenExpiredError: If token has expired.
            TokenInvalidError: If token is invalid.
        """
        if not token or not isinstance(token, str):
            raise TokenInvalidError("token must be a non-empty string")
        
        keys_to_try = [self._secret_key] + self._old_secret_keys
        last_error = None
        
        for key in keys_to_try:
            try:
                payload = self._decode_with_key(token, key)
                
                if expected_type is not None:
                    token_type = payload.get("typ", "")
                    if not self._constant_time_compare(token_type, expected_type):
                        raise TokenInvalidError("token type mismatch")
                
                return payload
                
            except TokenExpiredError:
                raise
            except TokenInvalidError as e:
                last_error = e
                continue
        
        raise last_error or TokenInvalidError("invalid token")

    def _decode_with_key(self, token: str, key: str) -> Dict[str, Any]:
        try:
            return jwt.decode(
                token,
                key,
                algorithms=[self._algorithm],
                audience=self._audience,
                issuer=self._issuer,
                options={"require_exp": True, "require_iat": True},
            )
        except ExpiredSignatureError:
            raise TokenExpiredError("token has expired")
        except JWTError:
            raise TokenInvalidError("invalid token")

    @staticmethod
    def _constant_time_compare(a: str, b: str) -> bool:
        return hmac.compare_digest(a.encode("utf-8"), b.encode("utf-8"))

    def get_token_id(self, token: str) -> Optional[str]:
        """
        Extract jti from token without full validation.
        
        Useful for blocklist checks before expensive validation.
        WARNING: Does NOT verify signature.
        """
        try:
            return jwt.get_unverified_claims(token).get("jti")
        except Exception:
            return None

    # =========================================================================
    # Utilities
    # =========================================================================

    @staticmethod
    def generate_secret_key() -> str:
        """Generate a cryptographically secure secret key (256 bits)."""
        return secrets.token_urlsafe(32)

    @staticmethod
    def generate_csrf_token() -> str:
        """Generate a CSRF token for web forms."""
        return secrets.token_urlsafe(32)

    def verify_csrf_token(self, token: str, expected: str) -> bool:
        """Constant-time CSRF token verification."""
        if not token or not expected:
            return False
        return self._constant_time_compare(token, expected)

    def __del__(self):
        self._executor.shutdown(wait=False)

