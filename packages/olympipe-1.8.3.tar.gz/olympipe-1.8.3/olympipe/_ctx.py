import os
from multiprocessing import get_context
from multiprocessing.context import BaseContext


def _resolve_mp_context() -> BaseContext:
    """Use 'spawn' when torch is detected (avoids PyTorch DataLoader/CUDA deadlocks with fork).
    Set OLYMPIPE_FORCE_FORK=1 to disable this auto-detection."""
    if os.environ.get("OLYMPIPE_FORCE_FORK", "0") == "1":
        return get_context("fork")
    try:
        import torch  # type: ignore[import-untyped, import-not-found]  # noqa: F401

        return get_context("spawn")
    except ImportError:
        return get_context("fork")


mp_ctx: BaseContext = _resolve_mp_context()
