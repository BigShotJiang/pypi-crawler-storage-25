import hashlib
import os
import pickle
from dataclasses import dataclass
from multiprocessing.managers import DictProxy
from typing import Any, Generic, List, TypeVar

from olympipe.shuttable_queue import ShuttableQueue

from .generic import GenericPipe, _PicklableCallable

T = TypeVar("T")


@dataclass
class CacheEnvelope(Generic[T]):
    """Wraps a packet with its cumulative lineage hash for cache chain tracking."""

    data: T
    lineage_hash: str


def _compute_packet_hash(data: Any) -> str:
    try:
        import cloudpickle  # type: ignore[import-untyped]

        packet_bytes = cloudpickle.dumps(data)
    except Exception:
        packet_bytes = pickle.dumps(data)
    return hashlib.sha256(packet_bytes).hexdigest()


class CachedTaskPipe(GenericPipe[Any, Any]):
    def __init__(
        self,
        father_process_dag: "DictProxy[str, List[str]]",
        source: "ShuttableQueue[Any]",
        target: "ShuttableQueue[Any]",
        task: Any,
        cache_dir: str,
        auto_start: bool = True,
    ):
        self._task = _PicklableCallable(task)
        self._step_hash = hashlib.sha256(self._task._bytes).hexdigest()
        self._cache_dir = cache_dir
        super().__init__(father_process_dag, source, target, auto_start)

    @property
    def shortname(self) -> str:
        return f"cached:{self._task.__name__}"

    def _perform_task(self, data: Any) -> Any:
        if isinstance(data, CacheEnvelope):
            lineage_hash = data.lineage_hash
            actual_data = data.data
        else:
            lineage_hash = _compute_packet_hash(data)
            actual_data = data

        cache_key = hashlib.sha256(
            (lineage_hash + self._step_hash).encode()
        ).hexdigest()

        # step directory keyed by first 16 chars of fn hash for uniqueness
        step_dir = os.path.join(self._cache_dir, self._step_hash[:16])
        cache_path = os.path.join(step_dir, cache_key + ".pkl")

        if os.path.exists(cache_path):
            with open(cache_path, "rb") as f:
                result = pickle.load(f)
        else:
            result = self._task(actual_data)
            os.makedirs(step_dir, exist_ok=True)
            with open(cache_path, "wb") as f:
                pickle.dump(result, f)

        return CacheEnvelope(data=result, lineage_hash=cache_key)


class UncachePipe(GenericPipe[Any, Any]):
    """Strips CacheEnvelope wrappers back to raw packets."""

    @property
    def shortname(self) -> str:
        return "uncache"

    def _perform_task(self, data: Any) -> Any:
        if isinstance(data, CacheEnvelope):
            return data.data
        return data
