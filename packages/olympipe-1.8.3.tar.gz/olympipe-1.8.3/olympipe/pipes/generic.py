import copy
from multiprocessing import Process
from multiprocessing.managers import DictProxy
from queue import Empty, Full
from typing import Any, Callable, Dict, Generic, List, Optional, Tuple, cast

import psutil
import setproctitle

from olympipe._ctx import mp_ctx as _fork_ctx
from olympipe.shuttable_queue import ShuttableQueue
from olympipe.types import InPacket, OutPacket


class _PicklableCallable:
    """Wrapper that uses cloudpickle to serialize callables (including lambdas and local functions)."""

    def __init__(self, fn: Callable[..., Any]) -> None:
        import cloudpickle  # type: ignore[import-untyped]

        self._bytes = cloudpickle.dumps(fn)
        self._fn = fn

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        return self._fn(*args, **kwargs)

    @property
    def __name__(self) -> str:
        return getattr(self._fn, "__name__", repr(self._fn))

    def __getstate__(self) -> Dict[str, Any]:
        return {"_bytes": self._bytes}

    def __setstate__(self, state: Dict[str, Any]) -> None:
        import cloudpickle  # type: ignore[import-untyped]

        self._bytes = state["_bytes"]
        self._fn = cloudpickle.loads(self._bytes)


class GenericPipe(_fork_ctx.Process, Generic[InPacket, OutPacket]):  # type: ignore[misc, name-defined]
    DEBUG = False

    def __init__(
        self,
        father_process_dag: "DictProxy[str, List[str]]",
        source: "ShuttableQueue[InPacket]",
        target: "ShuttableQueue[OutPacket]",
        auto_start: bool = True,
    ):
        self._father_process_dag = father_process_dag
        self._timeout: Optional[float] = 0.1
        self._source_queue = source
        self._target_queue = target
        setproctitle.setproctitle(self.__repr__())
        super().__init__(daemon=True)

        # Le DAG est la seule source de vérité - pas de logique alternative

        if auto_start:
            self.start()

    def set_error_mode(self) -> None:
        pid = str(self.pid)
        try:
            with self._father_process_dag._mutex:
                frozen_dag = copy.deepcopy(self._father_process_dag._getvalue())

                # set all parents to errored keys
                parents: List[str] = []
                explored: List[str] = [pid]
                while len(explored) > 0:
                    current_node = explored.pop(0)
                    if current_node in frozen_dag:
                        for v in frozen_dag[current_node]:
                            if v not in parents:
                                parents.append(v)
                                explored.append(v)

                for p in parents:
                    self._father_process_dag[p] = ["error"]
        except (KeyError, OSError, ConnectionError, EOFError, BrokenPipeError) as e:
            # En cas d'erreur d'accès au DAG, ignorer silencieusement
            print(f"Warning: Could not set error mode in DAG: {e}")
            pass

    def should_quit(self) -> bool:
        try:
            with self._father_process_dag._mutex:
                frozen_dag: Dict[str, List[str]] = copy.deepcopy(
                    self._father_process_dag._getvalue()
                )
                for vals in frozen_dag.values():
                    if "error" in vals:
                        return True
            return False
        except (EOFError, BrokenPipeError):
            # Le manager est mort -> le processus parent est terminé, on doit s'arrêter
            return True
        except (KeyError, OSError, ConnectionError):
            # Erreur transitoire - ne pas déclarer d'erreur sans confirmation
            return False

    def can_quit(self) -> bool:
        if self.should_quit():
            return True
        # Chemin rapide : la queue source a été fermée (signal mémoire partagée, pas de proxy)
        if self._source_queue.is_closed:
            return self._source_queue.empty()
        # Fallback DAG pour les cas où close() n'a pas encore été appelé
        pid = str(self.pid)
        has_living_father = False
        try:
            with self._father_process_dag._mutex:
                frozen_dag: Dict[str, List[str]] = copy.deepcopy(
                    self._father_process_dag._getvalue()
                )

                if pid not in frozen_dag:
                    return False

                for f_queue in frozen_dag[pid]:
                    if f_queue in frozen_dag:
                        for p_children in frozen_dag[f_queue]:
                            try:
                                has_living_father = (
                                    psutil.pid_exists(int(p_children))
                                    or has_living_father
                                )
                            except Exception as e:
                                print("Could not eval can_quit", pid, f_queue, e)

                is_queue_empty = self._source_queue.empty()
            return (not has_living_father) and is_queue_empty
        except (KeyError, OSError, ConnectionError, EOFError, BrokenPipeError):
            return False

    def get_ends(
        self,
    ) -> "Tuple[ShuttableQueue[InPacket], Process, ShuttableQueue[OutPacket]]":
        return (self._source_queue, self, self._target_queue)

    def unregister_from_dag(self):
        pid = str(self.pid)
        try:
            frozen_dag: Dict[str, List[str]] = copy.deepcopy(
                self._father_process_dag._getvalue()
            )
            keys_to_delete: List[str] = []
            for key, pids in frozen_dag.items():
                if pid in pids:
                    filtered_pids = [p for p in pids if p != pid]
                    if len(filtered_pids) > 0:
                        self._father_process_dag[key] = filtered_pids

                    else:
                        keys_to_delete.append(key)
                        self._source_queue.close()
            for key in keys_to_delete:
                _ = self._father_process_dag.pop(key)

            if pid in frozen_dag:
                _ = self._father_process_dag.pop(pid)
        except (KeyError, OSError, ConnectionError, EOFError, BrokenPipeError) as e:
            # En cas d'erreur d'accès au DAG, ignorer silencieusement
            print(f"Warning: Could not unregister from DAG: {e}")
            pass

    @property
    def shortname(self) -> str:
        return "Generic"

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}[{self.shortname}]"

    def _kill(self):
        try:
            with self._father_process_dag._mutex:
                self.unregister_from_dag()
        except (KeyError, OSError, ConnectionError, EOFError, BrokenPipeError) as e:
            # En cas d'erreur d'accès au DAG, ignorer silencieusement
            print(f"Warning: Could not access DAG mutex in _kill: {e}")
            pass

    def _perform_task(self, data: InPacket) -> OutPacket:
        return cast(OutPacket, data)

    def _send_to_next(self, processed: OutPacket):
        while True:
            try:
                self._target_queue.put(processed, timeout=self._timeout)
                break
            except (Full, TimeoutError):
                if self.should_quit():
                    break
            except Exception as e:
                print("next", e)
                raise e

    def get_next(self) -> InPacket:
        return cast(InPacket, self._source_queue.get(timeout=self._timeout))

    def run(self):
        while True:
            try:
                data = self.get_next()
                processed = self._perform_task(data)
                self._send_to_next(processed)
            except (TimeoutError, Empty, Full):
                pass
            except (OSError, EOFError, BrokenPipeError):
                # Queue fermée normalement (close() appelé) → terminer proprement
                if self._source_queue.is_closed and self._source_queue.empty():
                    self._kill()
                    return
            except Exception as e:
                import traceback as _tb

                msg = f"{self.__repr__()}: {type(e).__name__}: {e}\n{_tb.format_exc()}"
                print(msg)
                try:
                    self._target_queue.add_error(msg)
                except Exception:
                    pass
                self.set_error_mode()

            try:
                if self.can_quit():
                    self._kill()
                    break
            except (KeyError, OSError, ConnectionError, EOFError, BrokenPipeError) as e:
                # DAG inaccessible, forcer la fermeture proprement
                print(f"Warning: DAG access error in run loop, forcing quit: {e}")
                try:
                    self._kill()
                except Exception:
                    pass  # Ignorer les erreurs de kill
                break
