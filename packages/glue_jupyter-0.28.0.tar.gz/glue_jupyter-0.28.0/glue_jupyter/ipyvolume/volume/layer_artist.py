import ipyvolume as ipv
import numpy as np
import matplotlib.colors
import uuid

from glue.viewers.common.layer_artist import LayerArtist
from glue.viewers.volume3d.data_proxy import DataProxy

from .layer_state import VolumeLayerState
from ...link import link, dlink, on_change

__all__ = ['IpyvolumeVolumeLayerArtist']


def _transfer_func_rgba(color, N=256, max_opacity=1, stretch=None):
    r, g, b = matplotlib.colors.to_rgb(color)
    data = np.zeros((N, 4), dtype=np.float32)
    ramp = np.linspace(0, 1, N)
    if stretch is not None:
        ramp = stretch(ramp)
    data[..., 0] = r
    data[..., 1] = g
    data[..., 2] = b
    data[..., 3] = ramp*max_opacity
    return data


def _transfer_func_cmap(cmap, N=256, max_opacity=1, stretch=None):
    data = np.zeros((N, 4), dtype=np.float32)
    ramp = np.linspace(0, 1, N)
    if stretch is not None:
        ramp = stretch(ramp)
    colors = cmap(ramp)
    for i in range(3):
        data[..., i] = [c[i] for c in colors]
    data[..., 3] = ramp*max_opacity
    return data

def operation(op, x, empty_value=0):
    try:
        return op(x)
    except ValueError:
        return empty_value


def nanmin(x, empty_value=0):
    return operation(np.nanmin, x, empty_value=empty_value)


def nanmax(x, empty_value=1):
    return operation(np.nanmax, x, empty_value=empty_value)


data0 = [[[1, 2]] * 2] * 2


class IpyvolumeVolumeLayerArtist(LayerArtist):

    _layer_state_cls = VolumeLayerState

    def __init__(self, view, viewer_state, layer=None, layer_state=None):

        super(IpyvolumeVolumeLayerArtist, self).__init__(viewer_state,
                                                         layer_state=layer_state,
                                                         layer=layer)

        self.view = view
        self.figure = view.figure

        self.transfer_function = ipv.TransferFunction(rgba=_transfer_func_rgba(self.state.color))
        self.volume = ipv.Volume(extent_original=[[0, 1]] * 3, data_original=data0,
                                 tf=self.transfer_function, data_max_shape=128)
        self.figure.volumes = self.figure.volumes + [self.volume]

        self.id = str(uuid.uuid4())

        self.last_shape = None
        self._data_proxy = None

        dlink((self.state, 'lighting'), (self.volume, 'lighting'))
        dlink((self.state, 'render_method'), (self.volume, 'rendering_method'))
        dlink((self._viewer_state, 'resolution'), (self.volume, 'data_max_shape'))

        dlink((self.state, 'vmin'), (self.volume, 'show_min'))
        dlink((self.state, 'vmax'), (self.volume, 'show_max'))

        dlink((self.state, 'data_min'), (self.volume, 'data_min'))
        dlink((self.state, 'data_max'), (self.volume, 'data_max'))

        dlink((self.state, 'clamp_min'), (self.volume, 'clamp_min'))
        dlink((self.state, 'clamp_max'), (self.volume, 'clamp_max'))

        link((self.state, 'opacity_scale'), (self.volume, 'opacity_scale'))

        on_change([(self.state, 'color', 'alpha', 'color_mode',
                    'cmap', 'stretch', 'stretch_parameters'
                    )])(self._update_transfer_function)

        self._viewer_state.add_global_callback(self.update)
        self.state.add_global_callback(self.update)

    def clear(self):
        pass

    def redraw(self):
        pass

    def update(self, **kwargs):

        if self._data_proxy is None:
            self._data_proxy = DataProxy(self._viewer_state, self)

        bounds = [(self._viewer_state.z_min, self._viewer_state.z_max, self._viewer_state.resolution),
                  (self._viewer_state.y_min, self._viewer_state.y_max, self._viewer_state.resolution),
                  (self._viewer_state.x_min, self._viewer_state.x_max, self._viewer_state.resolution)]

        data = self._data_proxy.compute_fixed_resolution_buffer(bounds)

        data = np.transpose(data, (2, 0, 1))
        data_min, data_max = nanmin(data), nanmax(data)

        extent = [[bounds[i][0], bounds[i][1]] for i in (1, 0, 2)]

        self.last_shape = data.shape
        if self.volume is None:
            with self.figure:
                self.volume = ipv.volshow(data, data_min=data_min, data_max=data_max,
                                          extent=extent,
                                          controls=False, tf=self.transfer_function)
        else:
            self.volume.extent_original = extent
            self.volume.data_original = data
            self.volume.data_min = data_min
            self.volume.data_max = data_max
        self.state.data_min = self.state.vmin
        self.state.data_max = self.state.vmax

        # might be a bug in glue-core, it seems that for subsets vmin/vmax are
        # not calculated
        if self.state.vmin == self.state.vmax == 0:
            self.state.lim_helper.log = False
            self.state.percentile = 100

    def _update_transfer_function(self):
        def stretch(x):
            return self.state.stretch_object(x, **self.state.stretch_parameters)
        if self.state.color_mode == "Fixed":
            self.transfer_function.rgba = _transfer_func_rgba(self.state.color,
                                                              max_opacity=self.state.alpha,
                                                              stretch=stretch)
        else:
            self.transfer_function.rgba = _transfer_func_cmap(self.state.cmap,
                                                              max_opacity=self.state.alpha,
                                                              stretch=stretch)
