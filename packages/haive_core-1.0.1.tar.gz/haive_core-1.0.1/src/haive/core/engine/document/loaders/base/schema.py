from typing import TypeVar

from langchain_core.documents import Document
from pydantic import BaseModel, Field

# Try to import GraphDocument, fallback gracefully if not available
try:
    from langchain_community.graphs import GraphDocument

    DocumentLike = TypeVar("DocumentLike", bound=Document | GraphDocument)
except ImportError:
    # GraphDocument not available, use Document only
    GraphDocument = None
    DocumentLike = TypeVar("DocumentLike", bound=Document)


class LoaderInputSchema(BaseModel):
    """Schema for the input of a loader."""

    source: str | list[str] = Field(description="The source of the data to load.")


class LoaderOutputSchema(BaseModel):
    """Schema for the output of a loader."""

    documents: list[DocumentLike] = Field(description="The loaded documents.")
