# llm-router — Monetization Strategy (PRIVATE — gitignored)

Last updated: 2026-03-30

---

## TL;DR

Open-core SaaS. Free forever for individuals. Team tier at ~$49/month. Enterprise at $15K–$50K/year.
The structural moat is Claude Code-native MCP integration + zero-infrastructure deployment + transparent benchmark-driven routing.
Nobody in the LLM routing space has this combination.

---

## Competitive Landscape

| Tool | Routing Intelligence | Claude Code Native | Local Models | Self-Hosted | Entry Price |
|------|---------------------|-------------------|--------------|-------------|-------------|
| **llm-router** | Benchmark + complexity | ✅ Only one | ✅ Ollama | ✅ pip install | Free |
| Martian | Opaque ML model | ❌ | ❌ | ❌ Cloud only | $0.004/req |
| NotDiamond | Route recommendations | ❌ | ❌ | ❌ Cloud only | $10/10K routes |
| LiteLLM | None (gateway only) | ❌ | ✅ | ✅ Docker | Free / $30K/yr enterprise |
| PortKey | Rule-based | ❌ | ❌ | ❌ Cloud only | $49–99/mo |
| OpenRouter | None (marketplace) | ❌ | ❌ | ❌ | 5% fee |

**Key insight**: LiteLLM charges $30K/year for enterprise. We can undercut on price while offering what they can't: zero infra overhead + Claude Code integration.

---

## Target Segments

### Tier 0 — Individual Developers (free forever)
- Pain: paying $20–$100/month on APIs with no visibility
- Value delivered: savings tracking, routing intelligence, Ollama integration
- Strategy: make them evangelists. Every `llm check_usage` showing "$340 saved" is a tweet waiting to happen.
- Monetization: $0. This is distribution.

### Tier 1 — Small Dev Teams (5–50 engineers)
- Pain: uncontrolled LLM spend, no team-wide policy, each dev using different models
- Conversion trigger: team LLM spend exceeds $500/month
- Willingness to pay: $50–$200/month
- Features they need:
  - Centralized usage dashboard (shared across team)
  - Per-user budget caps
  - Team-wide routing policies (e.g. "no GPT-4o for queries under 50 tokens")
  - Slack/email spend alerts
  - Cost attribution per project/feature

### Tier 2 — AI-Native Startups (building LLM products)
- Pain: LLM cost is core COGS, routing decisions directly impact margin
- Willingness to pay: $500–$5K/month if routing demonstrably cuts costs 40–60%
- Features they need:
  - A/B testing of routing strategies
  - Custom routing profiles per product endpoint
  - Cost attribution per feature/customer
  - Outcome feedback loop (route based on quality scores, not just complexity)
- **Key sales argument**: If they spend $20K/month on LLM APIs and we cut it 60% = $144K/year saved. Charging $2K/month = 6x ROI.

### Tier 3 — Enterprise (100+ devs using AI tools)
- Pain: compliance, audit, data governance, cost attribution across BUs
- Willingness to pay: $15K–$150K/year
- Features they need:
  - SSO/SAML
  - RBAC (team policies, per-role model access)
  - Audit logs (who routed what, when, to which model)
  - VPC deployment option (no data egress)
  - SOC2 / HIPAA readiness
  - Executive cost dashboard
  - SLA + dedicated support
- **Strongest differentiator for enterprise**: local Ollama routing = full data residency. Healthcare/finance/legal can't use cloud proxies. Nobody else solves this at the routing layer.

---

## Pricing Model — Recommended: Open-Core SaaS

### Free (Individual)
- Everything currently open source
- Unlimited local usage
- SQLite cost tracking
- Ollama integration
- Benchmark-driven routing

### Team — $49/month (or $490/year)
- Everything in Free +
- `llm-router --server` team mode (shared config + usage DB)
- Centralized web dashboard (usage, costs, savings by user/project)
- Per-user budget caps
- Slack/email alerts on spend thresholds
- Up to 25 seats

### Business — $199/month (or $1,990/year)
- Everything in Team +
- Up to 100 seats
- Custom routing profiles per project
- A/B testing of routing strategies
- Cost attribution API (export to billing systems)
- Priority support (24h response)

### Enterprise — $15,000–$50,000/year
- Everything in Business +
- Unlimited seats
- SSO/SAML + RBAC
- Audit logs (compliance export)
- VPC / air-gapped deployment option
- Custom benchmark integration (route on your own eval data)
- SLA (99.9% uptime, 1h Sev0 response)
- Dedicated customer success

---

## Phased Rollout

### Phase 1 — Now (distribution building)
- Pure OSS. Ship fast. Get GitHub stars.
- Add `llm check_usage` savings display to every session end (makes savings visible)
- Add one-click "share savings" (generates a tweet-sized summary)
- Goal: 500 GitHub stars, 200 active daily users

### Phase 2 — Team Server MVP ($49/month)
- Build `llm-router-server` mode: lightweight FastAPI server that multiple Claude Code instances connect to
- Shared SQLite → PostgreSQL backend
- Simple web dashboard (React, hosted on Vercel or Railway)
- Stripe integration for billing
- Goal: 50 paying teams, $2,500 MRR

### Phase 3 — Enterprise Inbound
- When 3+ teams ask for SSO/RBAC/audit logs → that's the signal to build it
- Use savings ledger data as primary sales instrument: "Here's exactly how much you'd save"
- Partner with Anthropic / Claude Code ecosystem as a recommended tool
- Goal: 3 enterprise customers at $20K/year = $60K ARR

---

## Unique Leverage Points

1. **Claude Code native** — nobody else has MCP integration. As Claude Code grows in enterprise, we grow with it. First-mover advantage is real here.

2. **Savings quantification** — the SQLite ledger makes every user's ROI visible. This converts individual users into internal champions at their companies. "I saved $340 last month" → "let me show my manager".

3. **Zero infrastructure overhead** — LiteLLM and PortKey require running a server. We install with `pip install`. In enterprise, that difference matters enormously (no security review for a cloud proxy, no devops involvement).

4. **Transparent routing logic** — all decisions traceable to public benchmarks. This is a compliance advantage vs. Martian's opaque ML model. Regulated industries can audit WHY a task went to model X.

5. **Local model integration** — data residency story. Healthcare, finance, legal segments that can't use cloud proxies. Nobody is solving this at the routing layer.

6. **PyPI + open source flywheel** — organic growth, no paid acquisition needed in Phase 1. PostHog model: OSS community is the top of funnel, enterprise monetizes it.

---

## Key Risks

- **Anthropic changes MCP spec** → mitigation: contribute to MCP standard, maintain compatibility layer
- **LiteLLM adds complexity routing** → mitigation: Claude Code native integration is still a moat they can't copy
- **OpenRouter adds free routing** → mitigation: local model + zero infra story is theirs to lose
- **Benchmark data goes stale** → mitigation: already have weekly CI update pipeline

---

## Numbers to Track

- GitHub stars (distribution signal)
- `pip install` downloads / week (adoption signal)
- Average savings per user / month (value signal, primary conversion metric)
- % of users with > $100/month savings (enterprise candidate signal)
- Conversion rate: free → team tier

---

## First Revenue Action

The single highest-leverage thing to build next: **team server mode** with a shared usage dashboard.
Cost to build: ~2 weeks of dev. Revenue potential: $49 × 50 teams = $2,450 MRR from day one.
The individual users are already using it. They just need a way to share it with their team.
