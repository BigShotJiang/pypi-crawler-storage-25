"""Konfig core utilities package."""
