"""
Entry point for packaged executable.

When double-clicked (no arguments), automatically starts the gateway.
When called with arguments, falls through to the normal CLI.
"""

import sys


def main():
    # No subcommand given → default to "gateway"
    if len(sys.argv) == 1:
        sys.argv.append("gateway")

    from asedclaw.cli.commands import app

    app()


if __name__ == "__main__":
    main()
