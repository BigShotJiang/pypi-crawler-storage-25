"""Observability sinks: consume DiagnosticEvents and output them.

Sinks are registered as listeners via on_event(). Each sink formats and
delivers events to a specific destination.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Callable

from asedclaw.observability.events import DiagnosticEvent, on_event


class ConsoleSink:
    """Write events as JSON to stderr."""

    def __init__(self, *, pretty: bool = False):
        self._pretty = pretty
        self._unsub: Callable[[], None] | None = None

    def start(self) -> None:
        self._unsub = on_event(self._handle)

    def stop(self) -> None:
        if self._unsub:
            self._unsub()
            self._unsub = None

    def _handle(self, event: DiagnosticEvent) -> None:
        line = json.dumps(event.to_dict(), ensure_ascii=False, default=str)
        if self._pretty:
            line = json.dumps(event.to_dict(), ensure_ascii=False, default=str, indent=2)
        sys.stderr.write(line + "\n")
        sys.stderr.flush()


class FileSink:
    """Append events as JSONL to a file."""

    def __init__(self, path: str | Path):
        self._path = Path(path)
        self._unsub: Callable[[], None] | None = None

    def start(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._unsub = on_event(self._handle)

    def stop(self) -> None:
        if self._unsub:
            self._unsub()
            self._unsub = None

    def _handle(self, event: DiagnosticEvent) -> None:
        line = json.dumps(event.to_dict(), ensure_ascii=False, default=str)
        with open(self._path, "a", encoding="utf-8") as f:
            f.write(line + "\n")
