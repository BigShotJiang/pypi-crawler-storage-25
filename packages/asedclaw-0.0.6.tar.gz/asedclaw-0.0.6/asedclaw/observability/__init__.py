"""Structured observability: diagnostic events, emitter, and sinks."""

from asedclaw.observability.events import DiagnosticEvent, emit, on_event

__all__ = ["DiagnosticEvent", "emit", "on_event"]
