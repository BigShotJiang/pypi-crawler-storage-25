"""Diagnostic event definitions and global emitter.

Usage:
    from asedclaw.observability.events import emit, on_event

    # Emit an event
    emit("model.usage", {"model": "gpt-4o", "input_tokens": 500, "output_tokens": 200})

    # Subscribe to events
    unsub = on_event(lambda e: print(e))
    unsub()  # unsubscribe
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from loguru import logger


@dataclass(frozen=True)
class DiagnosticEvent:
    """A single diagnostic event emitted during agent operation."""

    type: str          # e.g. "model.usage", "guardrail.triggered", "compaction.done"
    ts: float          # time.time() when emitted
    seq: int           # monotonically increasing sequence number
    data: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"type": self.type, "ts": self.ts, "seq": self.seq, **self.data}


# ── Global state (thread-safe) ─────────────────────────────────────

_lock = threading.Lock()
_listeners: set[Callable[[DiagnosticEvent], None]] = set()
_seq: int = 0
_emitting: bool = False  # recursion guard


def emit(event_type: str, data: dict[str, Any] | None = None) -> DiagnosticEvent | None:
    """Emit a diagnostic event to all registered listeners.

    Safe to call from any context. Listener exceptions are logged but never
    propagate. Re-entrant calls (listener emitting another event) are silently
    dropped to prevent infinite recursion.
    """
    global _seq, _emitting

    with _lock:
        if _emitting:
            return None
        _seq += 1
        seq = _seq

    event = DiagnosticEvent(type=event_type, ts=time.time(), seq=seq, data=data or {})

    with _lock:
        if _emitting:
            return event
        _emitting = True
        listeners = set(_listeners)

    try:
        for listener in listeners:
            try:
                listener(event)
            except Exception:
                logger.debug("Diagnostic event listener error", exc_info=True)
    finally:
        with _lock:
            _emitting = False

    return event


def on_event(listener: Callable[[DiagnosticEvent], None]) -> Callable[[], None]:
    """Register a listener for all diagnostic events.

    Returns an unsubscribe function.
    """
    with _lock:
        _listeners.add(listener)

    def unsubscribe():
        with _lock:
            _listeners.discard(listener)

    return unsubscribe


def clear_listeners() -> None:
    """Remove all listeners (useful for testing)."""
    with _lock:
        _listeners.clear()
