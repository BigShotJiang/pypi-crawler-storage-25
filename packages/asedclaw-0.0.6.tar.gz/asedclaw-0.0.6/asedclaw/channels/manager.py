"""Channel manager for coordinating chat channels."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from typing import Any

from loguru import logger

from asedclaw.bus.events import OutboundMessage
from asedclaw.bus.queue import MessageBus
from asedclaw.channels.base import BaseChannel
from asedclaw.config.schema import Config


class ChannelManager:
    """
    Manages chat channels and coordinates message routing.

    Responsibilities:
    - Initialize enabled channels (Telegram, WhatsApp, etc.)
    - Start/stop channels
    - Route outbound messages
    """

    def __init__(self, config: Config, bus: MessageBus):
        self.config = config
        self.bus = bus
        self.channels: dict[str, BaseChannel] = {}
        self._dispatch_task: asyncio.Task | None = None

        self._init_channels()

    def _groq_api_key(self) -> str:
        """Groq API key for optional voice transcription (may be unset)."""
        p = getattr(self.config.providers, "groq", None)
        if p is None:
            return ""
        return getattr(p, "api_key", "") or ""

    def _register_channel(
        self,
        name: str,
        enabled: bool,
        factory: Callable[[], BaseChannel],
    ) -> None:
        """Instantiate one channel; log and skip on failure so other channels still start."""
        if not enabled:
            return
        try:
            self.channels[name] = factory()
            logger.info("{} channel registered", name)
        except ImportError as e:
            logger.warning("{} channel not available: {}", name, e)
        except Exception as e:
            logger.error("Failed to initialize {} channel: {}", name, e)

    def _init_channels(self) -> None:
        """Initialize channels based on config."""

        self._register_channel(
            "telegram",
            self.config.channels.telegram.enabled,
            lambda: self._make_telegram(),
        )
        self._register_channel(
            "whatsapp",
            self.config.channels.whatsapp.enabled,
            lambda: self._make_whatsapp(),
        )
        self._register_channel(
            "discord",
            self.config.channels.discord.enabled,
            lambda: self._make_discord(),
        )
        self._register_channel(
            "feishu",
            self.config.channels.feishu.enabled,
            lambda: self._make_feishu(),
        )
        self._register_channel(
            "mochat",
            self.config.channels.mochat.enabled,
            lambda: self._make_mochat(),
        )
        self._register_channel(
            "dingtalk",
            self.config.channels.dingtalk.enabled,
            lambda: self._make_dingtalk(),
        )
        self._register_channel(
            "email",
            self.config.channels.email.enabled,
            lambda: self._make_email(),
        )
        self._register_channel(
            "slack",
            self.config.channels.slack.enabled,
            lambda: self._make_slack(),
        )
        self._register_channel(
            "qq",
            self.config.channels.qq.enabled,
            lambda: self._make_qq(),
        )
        self._register_channel(
            "matrix",
            self.config.channels.matrix.enabled,
            lambda: self._make_matrix(),
        )
        self._register_channel(
            "ased",
            self.config.channels.im.enabled,
            lambda: self._make_ased(),
        )

        self._apply_allow_from_policy()

    def _make_telegram(self) -> BaseChannel:
        from asedclaw.channels.telegram import TelegramChannel

        return TelegramChannel(
            self.config.channels.telegram,
            self.bus,
            groq_api_key=self._groq_api_key(),
        )

    def _make_whatsapp(self) -> BaseChannel:
        from asedclaw.channels.whatsapp import WhatsAppChannel

        return WhatsAppChannel(self.config.channels.whatsapp, self.bus)

    def _make_discord(self) -> BaseChannel:
        from asedclaw.channels.discord import DiscordChannel

        return DiscordChannel(self.config.channels.discord, self.bus)

    def _make_feishu(self) -> BaseChannel:
        from asedclaw.channels.feishu import FeishuChannel

        return FeishuChannel(
            self.config.channels.feishu,
            self.bus,
            groq_api_key=self._groq_api_key(),
        )

    def _make_mochat(self) -> BaseChannel:
        from asedclaw.channels.mochat import MochatChannel

        return MochatChannel(self.config.channels.mochat, self.bus)

    def _make_dingtalk(self) -> BaseChannel:
        from asedclaw.channels.dingtalk import DingTalkChannel

        return DingTalkChannel(self.config.channels.dingtalk, self.bus)

    def _make_email(self) -> BaseChannel:
        from asedclaw.channels.email import EmailChannel

        return EmailChannel(self.config.channels.email, self.bus)

    def _make_slack(self) -> BaseChannel:
        from asedclaw.channels.slack import SlackChannel

        return SlackChannel(self.config.channels.slack, self.bus)

    def _make_qq(self) -> BaseChannel:
        from asedclaw.channels.qq import QQChannel

        return QQChannel(self.config.channels.qq, self.bus)

    def _make_matrix(self) -> BaseChannel:
        from asedclaw.channels.matrix import MatrixChannel

        return MatrixChannel(self.config.channels.matrix, self.bus)

    def _make_ased(self) -> BaseChannel:
        from asedclaw.channels.ased import IMChannel

        return IMChannel(self.config.channels.im, self.bus)

    def _apply_allow_from_policy(self) -> None:
        """Enforce allow_from rules; lenient mode drops invalid channels instead of exiting."""
        strict = self.config.channels.startup_policy == "strict"
        to_remove: list[str] = []

        for name, ch in list(self.channels.items()):
            if name == "ased":
                continue
            if getattr(ch.config, "allow_from", None) != []:
                continue
            if strict:
                raise SystemExit(
                    f'Error: "{name}" has empty allowFrom (denies all). '
                    f'Set ["*"] to allow everyone, or add specific user IDs.'
                )
            to_remove.append(name)

        for name in to_remove:
            del self.channels[name]
            logger.warning(
                'Skipping channel "{}" - allowFrom is empty (denies all). '
                'Set ["*"] or specific IDs, or set enabled=false. '
                "(channels.startupPolicy=lenient skips this channel.)",
                name,
            )

    async def _start_channel(self, name: str, channel: BaseChannel) -> None:
        """Start a channel and log any exceptions."""
        try:
            await channel.start()
        except Exception as e:
            logger.error("Failed to start channel {}: {}", name, e)

    async def start_all(self) -> None:
        """Start all channels and the outbound dispatcher."""
        if not self.channels:
            logger.warning("No channels enabled")
            return

        # Start outbound dispatcher
        self._dispatch_task = asyncio.create_task(self._dispatch_outbound())

        # Start channels
        tasks = []
        for name, channel in self.channels.items():
            logger.info("Starting {} channel...", name)
            tasks.append(asyncio.create_task(self._start_channel(name, channel)))

        # Wait for all to complete (they should run forever)
        await asyncio.gather(*tasks, return_exceptions=True)

    async def stop_all(self) -> None:
        """Stop all channels and the dispatcher."""
        logger.info("Stopping all channels...")

        # Stop dispatcher
        if self._dispatch_task:
            self._dispatch_task.cancel()
            try:
                await self._dispatch_task
            except asyncio.CancelledError:
                pass

        # Stop all channels
        for name, channel in self.channels.items():
            try:
                await channel.stop()
                logger.info("Stopped {} channel", name)
            except Exception as e:
                logger.error("Error stopping {}: {}", name, e)

    _PROGRESS_BATCH_DELAY = 0.3  # seconds to wait before flushing batched progress

    async def _dispatch_outbound(self) -> None:
        """Dispatch outbound messages, batching consecutive progress chunks."""
        logger.info("Outbound dispatcher started")

        pending_progress: dict[str, OutboundMessage] = {}
        flush_task: asyncio.Task | None = None

        async def _flush_progress() -> None:
            await asyncio.sleep(self._PROGRESS_BATCH_DELAY)
            for key in list(pending_progress):
                merged = pending_progress.pop(key, None)
                if merged and merged.content:
                    channel = self.channels.get(merged.channel)
                    if channel:
                        try:
                            await channel.send(merged)
                        except Exception as e:
                            logger.error("Error sending batched progress to {}: {}", merged.channel, e)

        while True:
            try:
                msg = await asyncio.wait_for(
                    self.bus.consume_outbound(),
                    timeout=0.1,
                )

                is_progress = msg.metadata.get("_progress", False)
                is_tool_hint = msg.metadata.get("_tool_hint", False)

                if is_progress:
                    if is_tool_hint and not self.config.channels.send_tool_hints:
                        continue
                    if not is_tool_hint and not self.config.channels.send_progress:
                        continue

                    # ased channel handles streaming internally—dispatch each chunk
                    # immediately so the frontend gets real-time character-by-character output.
                    if msg.channel == "ased":
                        channel = self.channels.get("ased")
                        if channel:
                            try:
                                await channel.send(msg)
                            except Exception as e:
                                logger.error("Error sending stream chunk to ased: {}", e)
                        continue

                    batch_key = f"{msg.channel}:{msg.chat_id}"
                    existing = pending_progress.get(batch_key)
                    if existing and not is_tool_hint:
                        existing.content += msg.content
                    else:
                        pending_progress[batch_key] = OutboundMessage(
                            channel=msg.channel,
                            chat_id=msg.chat_id,
                            content=msg.content,
                            metadata=dict(msg.metadata),
                        )

                    if flush_task is None or flush_task.done():
                        flush_task = asyncio.create_task(_flush_progress())
                    continue

                if pending_progress:
                    if flush_task and not flush_task.done():
                        flush_task.cancel()
                        try:
                            await flush_task
                        except asyncio.CancelledError:
                            pass
                    for key in list(pending_progress):
                        merged = pending_progress.pop(key, None)
                        if merged and merged.content:
                            channel = self.channels.get(merged.channel)
                            if channel:
                                try:
                                    await channel.send(merged)
                                except Exception as e:
                                    logger.error("Error sending batched progress to {}: {}", merged.channel, e)

                channel = self.channels.get(msg.channel)
                if channel:
                    try:
                        await channel.send(msg)
                    except Exception as e:
                        logger.error("Error sending to {}: {}", msg.channel, e)
                else:
                    logger.warning("Unknown channel: {}", msg.channel)

            except asyncio.TimeoutError:
                if pending_progress and (flush_task is None or flush_task.done()):
                    flush_task = asyncio.create_task(_flush_progress())
                continue
            except asyncio.CancelledError:
                for merged in pending_progress.values():
                    if merged and merged.content:
                        channel = self.channels.get(merged.channel)
                        if channel:
                            try:
                                await channel.send(merged)
                            except Exception:
                                pass
                break

    def get_channel(self, name: str) -> BaseChannel | None:
        """Get a channel by name."""
        return self.channels.get(name)

    def get_status(self) -> dict[str, Any]:
        """Get status of all channels."""
        return {
            name: {
                "enabled": True,
                "running": channel.is_running
            }
            for name, channel in self.channels.items()
        }

    @property
    def enabled_channels(self) -> list[str]:
        """Get list of enabled channel names."""
        return list(self.channels.keys())
