"""Filesystem toolkit with read/write/edit/list operations."""

import difflib
from pathlib import Path
from typing import Any, Awaitable, Callable

from agno.tools import Toolkit


def _resolve_path(
    path: str, workspace: Path | None = None, allowed_dir: Path | None = None
) -> Path:
    """Resolve path against workspace (if relative) and enforce directory restriction."""
    p = Path(path).expanduser()
    if not p.is_absolute() and workspace:
        p = workspace / p
    resolved = p.resolve()
    if allowed_dir:
        try:
            resolved.relative_to(allowed_dir.resolve())
        except ValueError:
            raise PermissionError(f"Path {path} is outside allowed directory {allowed_dir}")
    return resolved


class FilesystemToolkit(Toolkit):
    """Toolkit for file operations: read, write, edit, list."""

    _MAX_CHARS = 128_000  # ~128 KB — prevents OOM from reading huge files into LLM context

    def __init__(
        self,
        workspace: Path | None = None,
        allowed_dir: Path | None = None,
        file_approval_requester: Callable[..., Awaitable[str]] | None = None,
    ):
        self._workspace = workspace
        self._allowed_dir = allowed_dir
        self._file_approval_requester = file_approval_requester
        self._context_channel = ""
        self._context_chat_id = ""
        self._context_sender_id = ""
        self._context_session_key = ""
        self._context_metadata: dict[str, Any] = {}
        super().__init__(
            name="filesystem_tools",
            tools=[self.read_file, self.write_file, self.edit_file, self.list_dir],
        )

    def set_context(
        self,
        channel: str,
        chat_id: str,
        sender_id: str = "",
        session_key: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self._context_channel = channel
        self._context_chat_id = chat_id
        self._context_sender_id = sender_id
        self._context_session_key = session_key
        self._context_metadata = dict(metadata or {})

    async def read_file(self, path: str) -> str:
        try:
            file_path = _resolve_path(path, self._workspace, self._allowed_dir)
            if not file_path.exists():
                return f"Error: File not found: {path}"
            if not file_path.is_file():
                return f"Error: Not a file: {path}"

            size = file_path.stat().st_size
            if size > self._MAX_CHARS * 4:  # rough upper bound (UTF-8 chars ≤ 4 bytes)
                return (
                    f"Error: File too large ({size:,} bytes). "
                    f"Use exec tool with head/tail/grep to read portions."
                )

            content = file_path.read_text(encoding="utf-8")
            if len(content) > self._MAX_CHARS:
                return content[: self._MAX_CHARS] + f"\n\n... (truncated — file is {len(content):,} chars, limit {self._MAX_CHARS:,})"
            return content
        except PermissionError as e:
            return f"Error: {e}"
        except Exception as e:
            return f"Error reading file: {str(e)}"

    async def _maybe_request_file_approval(self, file_path: Path, action: str) -> str | None:
        if not self._file_approval_requester:
            return None
        path_str = str(file_path)
        lower = path_str.lower()
        risky = (
            ".env" in lower
            or lower.endswith(".pem")
            or lower.endswith(".key")
            or "windows" in lower
            or (self._workspace is not None and not str(file_path).startswith(str(self._workspace.resolve())))
        )
        if not risky:
            return None
        decision = await self._file_approval_requester(
            path=path_str,
            action=action,
            channel=self._context_channel,
            chat_id=self._context_chat_id,
            sender_id=self._context_sender_id,
            session_key=self._context_session_key,
            metadata=dict(self._context_metadata),
            summary=f"高风险文件写入需要审批: {path_str}",
        )
        if decision in {"allow-once", "allow-rule"}:
            return None
        if decision == "timeout":
            return "Error: File write approval timed out"
        if decision == "cancelled":
            return "Error: File write approval was cancelled"
        return "Error: File write denied by approval policy"

    async def write_file(self, path: str, content: str) -> str:
        """Write content to a file. Creates parent directories if needed."""
        try:
            file_path = _resolve_path(path, self._workspace, self._allowed_dir)
            approval_error = await self._maybe_request_file_approval(file_path, "write")
            if approval_error:
                return approval_error
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(content, encoding="utf-8")
            return f"Successfully wrote {len(content)} bytes to {file_path}\nMEDIA:{file_path}"
        except PermissionError as e:
            return f"Error: {e}"
        except Exception as e:
            return f"Error writing file: {str(e)}"

    async def edit_file(self, path: str, old_text: str, new_text: str) -> str:
        """Edit a file by replacing old_text with new_text (must be unique match)."""
        try:
            file_path = _resolve_path(path, self._workspace, self._allowed_dir)
            if not file_path.exists():
                return f"Error: File not found: {path}"

            approval_error = await self._maybe_request_file_approval(file_path, "edit")
            if approval_error:
                return approval_error

            content = file_path.read_text(encoding="utf-8")

            if old_text not in content:
                return self._not_found_message(old_text, content, path)

            count = content.count(old_text)
            if count > 1:
                return f"Warning: old_text appears {count} times. Please provide more context to make it unique."

            new_content = content.replace(old_text, new_text, 1)
            file_path.write_text(new_content, encoding="utf-8")

            return f"Successfully edited {file_path}\nMEDIA:{file_path}"
        except PermissionError as e:
            return f"Error: {e}"
        except Exception as e:
            return f"Error editing file: {str(e)}"

    @staticmethod
    def _not_found_message(old_text: str, content: str, path: str) -> str:
        """Build a helpful error when old_text is not found."""
        lines = content.splitlines(keepends=True)
        old_lines = old_text.splitlines(keepends=True)
        window = len(old_lines)

        best_ratio, best_start = 0.0, 0
        for i in range(max(1, len(lines) - window + 1)):
            ratio = difflib.SequenceMatcher(None, old_lines, lines[i : i + window]).ratio()
            if ratio > best_ratio:
                best_ratio, best_start = ratio, i

        if best_ratio > 0.5:
            diff = "\n".join(
                difflib.unified_diff(
                    old_lines,
                    lines[best_start : best_start + window],
                    fromfile="old_text (provided)",
                    tofile=f"{path} (actual, line {best_start + 1})",
                    lineterm="",
                )
            )
            return f"Error: old_text not found in {path}.\nBest match ({best_ratio:.0%} similar) at line {best_start + 1}:\n{diff}"
        return f"Error: old_text not found in {path}. No similar text found. Verify the file content."

    async def list_dir(self, path: str) -> str:
        try:
            dir_path = _resolve_path(path, self._workspace, self._allowed_dir)
            if not dir_path.exists():
                return f"Error: Directory not found: {path}"
            if not dir_path.is_dir():
                return f"Error: Not a directory: {path}"

            items = []
            for item in sorted(dir_path.iterdir()):
                prefix = "📁 " if item.is_dir() else "📄 "
                items.append(f"{prefix}{item.name}")

            if not items:
                return f"Directory {path} is empty"

            return "\n".join(items)
        except PermissionError as e:
            return f"Error: {e}"
        except Exception as e:
            return f"Error listing directory: {str(e)}"
