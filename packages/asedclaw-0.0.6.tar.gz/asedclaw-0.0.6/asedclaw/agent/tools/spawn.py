"""Spawn tool for creating background subagents."""

from typing import TYPE_CHECKING, Any

from agno.tools import Toolkit

if TYPE_CHECKING:
    from asedclaw.agent.subagent import SubagentManager


class SpawnTool(Toolkit):
    """Toolkit to spawn a subagent for background task execution."""

    def __init__(self, manager: "SubagentManager"):
        self._manager = manager
        self._origin_channel = "cli"
        self._origin_chat_id = "direct"
        self._session_key = "cli:direct"
        super().__init__(name="spawn", tools=[self.spawn])

    def set_context(self, channel: str, chat_id: str) -> None:
        """Set the origin context for subagent announcements."""
        self._origin_channel = channel
        self._origin_chat_id = chat_id
        self._session_key = f"{channel}:{chat_id}"

    async def spawn(self, task: str, label: str | None = None) -> str:
        """Spawn a subagent to execute the given task."""
        return await self._manager.spawn(
            task=task,
            label=label,
            origin_channel=self._origin_channel,
            origin_chat_id=self._origin_chat_id,
            session_key=self._session_key,
        )

    async def execute(self, task: str, label: str | None = None, **kwargs: Any) -> str:
        return await self.spawn(task, label)
