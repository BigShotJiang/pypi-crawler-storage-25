from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any


class ApprovalDecision(str, Enum):
    ALLOW_ONCE = "allow-once"
    ALLOW_RULE = "allow-rule"
    DENY = "deny"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


class ApprovalStatus(str, Enum):
    PENDING = "pending"
    DECIDED = "decided"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


@dataclass
class PendingApproval:
    approval_id: str
    session_key: str
    channel: str
    chat_id: str
    user_id: str
    app_id: str | None
    resource_type: str
    summary: str
    command: str
    created_at: datetime
    expires_at: datetime
    allowed_decisions: list[str] = field(default_factory=lambda: [
        ApprovalDecision.ALLOW_ONCE.value,
        ApprovalDecision.ALLOW_RULE.value,
        ApprovalDecision.DENY.value,
    ])
    metadata: dict[str, Any] = field(default_factory=dict)
    approver_ids: list[str] = field(default_factory=list)
    status: ApprovalStatus = ApprovalStatus.PENDING
    decision: ApprovalDecision | None = None
    decided_at: datetime | None = None
    decided_by: str | None = None


class ApprovalManager:
    def __init__(self, timeout_seconds: int = 300):
        self.timeout_seconds = timeout_seconds
        self._pending: dict[str, PendingApproval] = {}
        self._events: dict[str, asyncio.Event] = {}
        self._lock = asyncio.Lock()

    async def create(
        self,
        *,
        session_key: str,
        channel: str,
        chat_id: str,
        user_id: str,
        app_id: str | None,
        resource_type: str,
        summary: str,
        command: str,
        metadata: dict[str, Any] | None = None,
        approver_ids: list[str] | None = None,
        timeout_seconds: int | None = None,
    ) -> PendingApproval:
        now = datetime.utcnow()
        ttl = timeout_seconds or self.timeout_seconds
        approval = PendingApproval(
            approval_id=uuid.uuid4().hex,
            session_key=session_key,
            channel=channel,
            chat_id=chat_id,
            user_id=user_id,
            app_id=app_id,
            resource_type=resource_type,
            summary=summary,
            command=command,
            created_at=now,
            expires_at=now + timedelta(seconds=max(ttl, 1)),
            metadata=dict(metadata or {}),
            approver_ids=list(approver_ids or ([user_id] if user_id else [])),
        )
        async with self._lock:
            self._pending[approval.approval_id] = approval
            self._events[approval.approval_id] = asyncio.Event()
        return approval

    async def wait_for_decision(self, approval_id: str) -> ApprovalDecision:
        async with self._lock:
            approval = self._pending.get(approval_id)
            event = self._events.get(approval_id)
        if approval is None or event is None:
            return ApprovalDecision.CANCELLED

        timeout = max((approval.expires_at - datetime.utcnow()).total_seconds(), 0)
        try:
            await asyncio.wait_for(event.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            await self.resolve(
                approval_id,
                ApprovalDecision.TIMEOUT.value,
                actor_id=None,
                force=True,
            )

        async with self._lock:
            current = self._pending.get(approval_id)
            if current is None or current.decision is None:
                return ApprovalDecision.CANCELLED
            return current.decision

    async def resolve(
        self,
        approval_id: str,
        decision: str,
        *,
        actor_id: str | None,
        force: bool = False,
    ) -> PendingApproval | None:
        async with self._lock:
            approval = self._pending.get(approval_id)
            if approval is None:
                return None
            if approval.status is not ApprovalStatus.PENDING:
                return approval

            normalized = ApprovalDecision(decision)
            if not force and approval.approver_ids and actor_id and str(actor_id) not in approval.approver_ids:
                raise PermissionError("actor is not allowed to decide this approval")

            if normalized is ApprovalDecision.TIMEOUT:
                approval.status = ApprovalStatus.TIMEOUT
            elif normalized is ApprovalDecision.CANCELLED:
                approval.status = ApprovalStatus.CANCELLED
            else:
                approval.status = ApprovalStatus.DECIDED
            approval.decision = normalized
            approval.decided_at = datetime.utcnow()
            approval.decided_by = str(actor_id) if actor_id is not None else None
            event = self._events.get(approval_id)
            if event is not None:
                event.set()
            return approval

    async def cancel_session(self, session_key: str) -> list[PendingApproval]:
        async with self._lock:
            approvals = [a for a in self._pending.values() if a.session_key == session_key and a.status is ApprovalStatus.PENDING]
        results: list[PendingApproval] = []
        for approval in approvals:
            resolved = await self.resolve(
                approval.approval_id,
                ApprovalDecision.CANCELLED.value,
                actor_id=None,
                force=True,
            )
            if resolved is not None:
                results.append(resolved)
        return results

    async def get(self, approval_id: str) -> PendingApproval | None:
        async with self._lock:
            return self._pending.get(approval_id)

    async def list_for_session(self, session_key: str) -> list[PendingApproval]:
        async with self._lock:
            return [a for a in self._pending.values() if a.session_key == session_key]
