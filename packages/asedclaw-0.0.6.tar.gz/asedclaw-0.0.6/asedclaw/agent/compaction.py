"""LLM-based session compaction: summarize old messages to reclaim context space.

Follows OpenClaw's approach: instead of mechanically truncating tool results,
use the LLM to produce a semantic summary that preserves key decisions, identifiers,
and task state while dramatically reducing token count.

Flow:
  1. Split messages into (to_summarize, to_keep) based on recent-turns threshold
  2. Chunk to_summarize by token budget
  3. Summarize each chunk via LLM, passing previous summary for continuity
  4. Replace original messages with [compaction summary] + kept messages
  5. Inject post-compaction context refresh from AGENTS.md
"""

from __future__ import annotations

import re
from datetime import datetime
from typing import TYPE_CHECKING, Any

from loguru import logger

from asedclaw.agent.token_utils import estimate_messages_tokens, estimate_tokens
from asedclaw.observability.events import emit as _emit

if TYPE_CHECKING:
    from pathlib import Path

    from asedclaw.config.schema import CompactionConfig
    from asedclaw.providers.base import LLMProvider


# ── Compaction prompt templates ─────────────────────────────────────

_SUMMARIZE_SYSTEM = """\
你是一个对话压缩代理。你的任务是为下面的对话生成一份简洁、准确的摘要。\
该摘要将替换代理上下文窗口中的原始消息。

使用对话中的主要语言撰写摘要。

## 必需结构
你的摘要必须包含以下章节：
- ## 摘要 — 讨论了什么、做出了哪些决定、当前状态
- ## 进行中的任务 — 正在进行的任务、状态、阻塞项
- ## 决策 — 关键决策及其理由
- ## 待办事项 — 未完成的任务或待处理项
- ## 精确标识符 — 所有 UUID、提交哈希、PR/Issue 编号、URL、文件路径、版本号

## 保留规则
必须保留：
- 进行中的任务及其当前状态（进行中、阻塞、待处理）
- 批量操作进度（例如"已完成 5/17 项"）
- 用户最后请求的内容以及正在进行的处理
- 做出的决策及其理由
- 待办事项、未解决的问题和约束条件
- 任何承诺或后续跟进事项
- 所有影响状态的工具调用结果（文件写入、命令执行等）

优先保留近期上下文，而非较早的历史记录。
{identifier_policy}"""

_IDENTIFIER_STRICT = """
## 标识符策略（严格）
完整保留所有不透明标识符，不得缩短或重新构造。\
包括：UUID、哈希值、提交 SHA、ID、令牌、API 密钥、主机名、IP、\
端口、URL、文件路径和版本号。"""

_MERGE_PROMPT = """\
以下是同一对话不同片段的部分摘要，按时间顺序排列。\
请将它们合并为一份连贯的完整摘要。

保留所有章节（## 摘要、## 进行中的任务、## 决策、## 待办事项、\
## 精确标识符）。当片段之间的信息冲突时，以较晚的片段为准，\
因为它反映了更新的状态。

## 部分摘要

{partials}"""

_REQUIRED_SECTIONS = ["## 摘要", "## 进行中的任务", "## 决策", "## 待办事项", "## 精确标识符"]


# ── Core compaction logic ───────────────────────────────────────────

async def compact_session(
    messages: list[dict[str, Any]],
    *,
    provider: LLMProvider,
    model: str,
    config: CompactionConfig,
    workspace: Path | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Run LLM-based compaction on a message list.

    Returns (compacted_messages, metrics).
    The compacted list is: [system] + [compaction_entry] + [kept_messages]
    optionally followed by a post-compaction refresh message.
    """
    compaction_model = config.model or model

    # Separate system messages from conversation
    system_msgs = [m for m in messages if m.get("role") == "system"]
    conv_msgs = [m for m in messages if m.get("role") != "system"]

    if not conv_msgs:
        return messages, {"compacted": False, "reason": "no_messages"}

    # Decide what to keep vs summarize
    to_summarize, to_keep = _split_messages(conv_msgs, config)

    if not to_summarize:
        return messages, {"compacted": False, "reason": "nothing_to_summarize"}

    tokens_before = estimate_messages_tokens(messages)
    summarize_tokens = estimate_messages_tokens(to_summarize)

    logger.info(
        "Compaction: {} messages to summarize (~{} tokens), {} to keep",
        len(to_summarize), summarize_tokens, len(to_keep),
    )

    # Chunk and summarize
    summary = await _summarize_messages(
        to_summarize,
        provider=provider,
        model=compaction_model,
        config=config,
    )

    if summary is None:
        logger.warning("LLM compaction failed, no summary produced")
        return messages, {"compacted": False, "reason": "llm_failed"}

    # Truncate summary if needed
    if len(summary) > config.max_summary_chars:
        summary = summary[: config.max_summary_chars] + "\n\n...(truncated)"

    # Build compaction entry
    compaction_entry = {
        "role": "assistant",
        "content": f"[Session Compaction Summary — {datetime.now():%Y-%m-%d %H:%M}]\n\n{summary}",
        "timestamp": datetime.now().isoformat(),
        "_compaction": True,
    }

    # Build result: system + compaction_entry + kept messages
    result = system_msgs + [compaction_entry] + to_keep

    # Post-compaction context refresh
    if workspace and config.post_compaction_sections:
        refresh = _build_post_compaction_refresh(workspace, config)
        if refresh:
            result.append({
                "role": "user",
                "content": refresh,
                "timestamp": datetime.now().isoformat(),
                "_post_compaction_refresh": True,
            })

    tokens_after = estimate_messages_tokens(result)
    metrics = {
        "compacted": True,
        "messages_summarized": len(to_summarize),
        "messages_kept": len(to_keep),
        "tokens_before": tokens_before,
        "tokens_after": tokens_after,
        "tokens_saved": tokens_before - tokens_after,
        "summary_chars": len(summary),
    }
    logger.info(
        "Compaction done: {} → {} tokens (saved {}), {} messages summarized",
        tokens_before, tokens_after, tokens_before - tokens_after, len(to_summarize),
    )
    _emit("compaction.done", {
        "tokens_before": tokens_before,
        "tokens_after": tokens_after,
        "messages_summarized": len(to_summarize),
    })
    return result, metrics


# ── Message splitting ───────────────────────────────────────────────

def _split_messages(
    conv_msgs: list[dict[str, Any]],
    config: CompactionConfig,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Split conversation into (to_summarize, to_keep).

    Keeps the most recent N complete turns (user+assistant pairs) plus
    any trailing messages.
    """
    preserve = config.recent_turns_preserve

    # Find turn boundaries (each user message starts a new turn)
    turn_starts: list[int] = []
    for i, m in enumerate(conv_msgs):
        if m.get("role") == "user":
            turn_starts.append(i)

    if len(turn_starts) <= preserve:
        # Not enough turns to compact
        return [], conv_msgs

    # Keep from the Nth-to-last user message onward
    split_idx = turn_starts[-preserve]
    return conv_msgs[:split_idx], conv_msgs[split_idx:]


# ── LLM summarization ──────────────────────────────────────────────

async def _summarize_messages(
    messages: list[dict[str, Any]],
    *,
    provider: LLMProvider,
    model: str,
    config: CompactionConfig,
) -> str | None:
    """Summarize messages via LLM, chunking if necessary."""
    chunk_budget = int(config.context_window * config.chunk_ratio / config.safety_margin)
    chunk_budget -= config.summarization_overhead_tokens

    chunks = _chunk_messages(messages, chunk_budget)

    if not chunks:
        return None

    id_policy = _IDENTIFIER_STRICT if config.identifier_policy == "strict" else ""
    system_prompt = _SUMMARIZE_SYSTEM.format(identifier_policy=id_policy)

    # Single chunk — simple summarization
    if len(chunks) == 1:
        transcript = _format_transcript(chunks[0], max_content_chars=config.summarize_input_max_chars)
        summary = await _call_llm_summarize(
            system_prompt=system_prompt,
            user_prompt=f"## Conversation to Summarize\n\n{transcript}",
            provider=provider,
            model=model,
        )
        return await _validate_and_retry(summary, system_prompt, transcript, provider, model, config)

    # Multi-chunk — progressive summarization
    partial_summaries: list[str] = []
    previous_summary = ""

    for i, chunk in enumerate(chunks):
        transcript = _format_transcript(chunk, max_content_chars=config.summarize_input_max_chars)
        context = ""
        if previous_summary:
            context = f"## Summary of Earlier Conversation\n\n{previous_summary}\n\n"

        summary = await _call_llm_summarize(
            system_prompt=system_prompt,
            user_prompt=f"{context}## Conversation Segment {i + 1}/{len(chunks)}\n\n{transcript}",
            provider=provider,
            model=model,
        )
        if summary:
            partial_summaries.append(summary)
            previous_summary = summary

    if not partial_summaries:
        return None

    if len(partial_summaries) == 1:
        return await _validate_and_retry(
            partial_summaries[0], system_prompt, _format_transcript(messages, max_content_chars=config.summarize_input_max_chars), provider, model, config,
        )

    # Merge partial summaries
    partials_text = "\n\n---\n\n".join(
        f"### Segment {i + 1}\n\n{s}" for i, s in enumerate(partial_summaries)
    )
    merged = await _call_llm_summarize(
        system_prompt=system_prompt,
        user_prompt=_MERGE_PROMPT.format(partials=partials_text),
        provider=provider,
        model=model,
    )
    return await _validate_and_retry(merged, system_prompt, partials_text, provider, model, config)


async def _validate_and_retry(
    summary: str | None,
    system_prompt: str,
    transcript: str,
    provider: LLMProvider,
    model: str,
    config: CompactionConfig,
) -> str | None:
    """Validate summary for required sections, retry if missing."""
    if not summary:
        return None

    for attempt in range(1 + config.quality_retries):
        missing = _check_required_sections(summary)
        if not missing:
            return summary

        if attempt < config.quality_retries:
            logger.warning(
                "Compaction quality check failed (attempt {}/{}): missing {}",
                attempt + 1, 1 + config.quality_retries, missing,
            )
            retry_prompt = (
                f"## 待总结的对话\n\n{transcript}\n\n"
                f"## 重试：你上一次的摘要缺少必需章节：{', '.join(missing)}。\n"
                f"请重新生成包含所有必需章节的摘要。"
            )
            summary = await _call_llm_summarize(
                system_prompt=system_prompt,
                user_prompt=retry_prompt,
                provider=provider,
                model=model,
            )
            if not summary:
                return None
        else:
            logger.warning(
                "Compaction quality check failed after {} attempts: missing {}. Accepting anyway.",
                1 + config.quality_retries, missing,
            )

    return summary


def _check_required_sections(summary: str) -> list[str]:
    """Return list of missing required section headers."""
    lower = summary.lower()
    return [s for s in _REQUIRED_SECTIONS if s.lower() not in lower]


# ── Message chunking ────────────────────────────────────────────────

def _chunk_messages(
    messages: list[dict[str, Any]],
    max_tokens_per_chunk: int,
) -> list[list[dict[str, Any]]]:
    """Split messages into chunks that fit within token budget."""
    if max_tokens_per_chunk <= 0:
        return [messages]

    chunks: list[list[dict[str, Any]]] = []
    current_chunk: list[dict[str, Any]] = []
    current_tokens = 0

    for m in messages:
        msg_tokens = estimate_messages_tokens([m])
        if current_chunk and current_tokens + msg_tokens > max_tokens_per_chunk:
            chunks.append(current_chunk)
            current_chunk = []
            current_tokens = 0
        current_chunk.append(m)
        current_tokens += msg_tokens

    if current_chunk:
        chunks.append(current_chunk)

    return chunks


# ── Transcript formatting ───────────────────────────────────────────

def _format_transcript(messages: list[dict[str, Any]], *, max_content_chars: int = 2000) -> str:
    """Format messages into a readable transcript for the summarization LLM."""
    _summarize_input_max_chars = max_content_chars
    lines: list[str] = []
    for m in messages:
        role = m.get("role", "?").upper()
        ts = m.get("timestamp", "")
        if ts:
            ts = ts[:16]

        content = m.get("content", "")
        if not content:
            # Tool calls without content
            tool_calls = m.get("tool_calls", [])
            if tool_calls:
                names = [tc.get("function", {}).get("name", "?") for tc in tool_calls]
                content = f"[tool calls: {', '.join(names)}]"
            else:
                continue

        if isinstance(content, list):
            # Multimodal content — extract text blocks
            text_parts = [b.get("text", "") for b in content if isinstance(b, dict) and b.get("type") == "text"]
            content = "\n".join(text_parts)

        # Truncate very long content (tool results) for the summarization prompt
        if len(content) > _summarize_input_max_chars:
            content = content[:_summarize_input_max_chars] + "\n... (truncated for summarization)"

        tools_used = ""
        if m.get("tool_calls"):
            names = [tc.get("function", {}).get("name", "?") for tc in m["tool_calls"]]
            tools_used = f" [tools: {', '.join(names)}]"

        tool_name = ""
        if m.get("role") == "tool" and m.get("name"):
            tool_name = f" ({m['name']})"

        lines.append(f"[{ts}] {role}{tool_name}{tools_used}: {content}")

    return "\n".join(lines)


# ── LLM call ────────────────────────────────────────────────────────

async def _call_llm_summarize(
    *,
    system_prompt: str,
    user_prompt: str,
    provider: LLMProvider,
    model: str,
) -> str | None:
    """Call the LLM to produce a summary."""
    try:
        from agno.agent.agent import Agent

        agent = Agent(
            model=provider.build_model(model=model),
            instructions=system_prompt,
            stream=False,
        )
        response = await agent.arun(user_prompt, stream=False)

        if response and response.content:
            return response.content
        return None
    except Exception:
        logger.exception("LLM summarization call failed")
        return None


# ── Post-compaction context refresh ─────────────────────────────────

def _build_post_compaction_refresh(
    workspace: Path,
    config: CompactionConfig,
) -> str | None:
    """Extract critical sections from AGENTS.md and build a refresh message.

    Following OpenClaw's post-compaction-context.ts pattern: after compaction,
    re-inject Session Startup and Red Lines sections so the agent doesn't
    lose critical constraints.
    """
    agents_file = workspace / "AGENTS.md"
    if not agents_file.exists():
        return None

    content = agents_file.read_text(encoding="utf-8")
    if not content.strip():
        return None

    extracted: list[str] = []
    for section_name in config.post_compaction_sections:
        section_text = _extract_md_section(content, section_name)
        if section_text:
            extracted.append(section_text)

    if not extracted:
        return None

    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    sections_text = "\n\n".join(extracted)

    if len(sections_text) > config.post_compaction_refresh_max_chars:
        sections_text = sections_text[:config.post_compaction_refresh_max_chars] + "\n\n...[truncated]..."

    return (
        f"[压缩后上下文刷新]\n\n"
        f"会话刚刚被压缩。上面的对话摘要是精简表示——不能替代你的启动流程。"
        f"如有需要，请在回复用户前重新读取必要的文件。\n\n"
        f"来自 AGENTS.md 的关键规则：\n\n"
        f"{sections_text}\n\n"
        f"当前时间：{now}"
    )


def _extract_md_section(content: str, heading: str) -> str | None:
    """Extract a markdown section by heading (H2 or H3), stopping at the next same-level heading.

    Respects fenced code blocks (won't match headings inside ```)."""
    # Find the heading
    escaped = re.escape(heading)
    pattern = re.compile(rf"^(#{{2,3}})\s+{escaped}\s*$", re.IGNORECASE | re.MULTILINE)
    match = pattern.search(content)
    if not match:
        return None

    level = len(match.group(1))  # 2 or 3
    start = match.start()

    # Find the next heading at same or higher level, respecting code fences
    rest = content[match.end():]
    in_fence = False
    end_offset = len(rest)

    for line_match in re.finditer(r"^(.*)$", rest, re.MULTILINE):
        line = line_match.group(1)
        stripped = line.strip()

        if stripped.startswith("```"):
            in_fence = not in_fence
            continue

        if in_fence:
            continue

        # Check for heading at same or higher level
        hm = re.match(r"^(#{1," + str(level) + r"})(?!#)\s+", line)
        if hm:
            end_offset = line_match.start()
            break

    section = content[start: match.end() + end_offset].strip()
    return section if section else None
