"""Pre-compaction memory flush: silently ask the model to persist important info before context overflow."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

from loguru import logger

from asedclaw.agent.token_utils import estimate_messages_tokens
from asedclaw.observability.events import emit as _emit

if TYPE_CHECKING:
    from asedclaw.config.schema import MemoryFlushConfig
    from asedclaw.providers.base import LLMProvider
    from asedclaw.session.manager import Session

# Safety constraints shared with consolidation prompt.
MEMORY_FLUSH_SAFETY_HINTS = [
    "持久记忆只能存储在 memory/YYYY-MM-DD.md 中（如需要请创建 memory/ 目录）。",
    "如果 memory/YYYY-MM-DD.md 已存在，追加新内容——不要覆盖已有条目。",
    "在此次刷写期间，将 MEMORY.md、SOUL.md、TOOLS.md 和 AGENTS.md 视为只读。",
]


def build_flush_system_prompt() -> str:
    safety = "\n".join(f"- {h}" for h in MEMORY_FLUSH_SAFETY_HINTS)
    return (
        "压缩前记忆刷写轮次。"
        "由于即将进行上下文压缩，较早的上下文将会丢失。"
        "请立即将重要信息保存到每日记忆文件中。\n\n"
        f"## 安全规则\n{safety}"
    )


def build_flush_user_prompt(date_str: str) -> str:
    return (
        f"将值得记住的持久笔记、决策或事实写入 memory/{date_str}.md。"
        "使用 write_file 工具追加内容。"
        "如果没有重要信息需要保存，请回复 NO_REPLY。"
    )


def should_flush(
    total_tokens: int,
    config: MemoryFlushConfig,
    flush_done: bool,
) -> bool:
    """Return True if a memory flush should be triggered."""
    if not config.enabled or flush_done:
        return False
    threshold = config.context_window - config.reserve_tokens_floor - config.soft_threshold_tokens
    return total_tokens >= threshold


def should_force_flush_by_size(
    transcript_bytes: int,
    config: MemoryFlushConfig,
    flush_done: bool,
) -> bool:
    """Return True if transcript size exceeds force-flush threshold."""
    if not config.enabled or flush_done:
        return False
    return transcript_bytes >= config.force_flush_transcript_bytes


async def run_memory_flush(
    session: Session,
    provider: LLMProvider,
    model: str,
    workspace: Path,
    config: MemoryFlushConfig,
) -> bool:
    """Execute a silent memory flush turn.

    Injects a flush prompt and runs an agno agent that can only write to the
    daily memory file.  Returns True on success.
    """
    try:
        from agno.agent.agent import Agent
        from agno.tools import tool
    except Exception:
        logger.exception("Agno runtime unavailable for memory flush")
        return False

    memory_dir = workspace / "memory"
    memory_dir.mkdir(parents=True, exist_ok=True)
    date_str = datetime.now().strftime("%Y-%m-%d")
    daily_file = memory_dir / f"{date_str}.md"

    @tool(name="write_file", description="Append content to the daily memory file.")
    async def write_file(content: str) -> str:
        """Append *content* to today's daily memory log."""
        with open(daily_file, "a", encoding="utf-8") as f:
            f.write(content.rstrip() + "\n\n")
        return f"Appended to {daily_file.name}"

    # Build a concise conversation summary for the flush agent
    recent = session.messages[-40:] if len(session.messages) > 40 else session.messages
    summary_lines: list[str] = []
    for m in recent:
        content = m.get("content")
        if not content or not isinstance(content, str):
            continue
        role = m.get("role", "?").upper()
        ts = m.get("timestamp", "")[:16]
        preview = content[:200]
        summary_lines.append(f"[{ts}] {role}: {preview}")

    flush_prompt = build_flush_user_prompt(date_str)
    if summary_lines:
        flush_prompt += "\n\n## Recent conversation context\n" + "\n".join(summary_lines)

    try:
        agent = Agent(
            model=provider.build_model(model=model),
            tools=[write_file],
            instructions=build_flush_system_prompt(),
            stream=False,
        )
        response = await agent.arun(flush_prompt, stream=False)
        content = getattr(response, "content", str(response)) if response else ""
        if "NO_REPLY" in str(content):
            logger.debug("Memory flush: model had nothing to save")
        else:
            logger.info("Memory flush completed, wrote to {}", daily_file.name)
        _emit("memory.flush", {"success": True, "trigger_reason": "token_threshold"})
        return True
    except Exception:
        logger.exception("Memory flush failed")
        _emit("memory.flush", {"success": False, "trigger_reason": "token_threshold"})
        return False
