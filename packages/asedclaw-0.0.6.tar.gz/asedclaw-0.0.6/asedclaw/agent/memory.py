"""Memory system for persistent agent memory."""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING

from loguru import logger

from asedclaw.utils.helpers import ensure_dir

if TYPE_CHECKING:
    from asedclaw.providers.base import LLMProvider
    from asedclaw.session.manager import Session


class MemoryStore:
    """Two-layer memory: MEMORY.md + append-only daily logs (memory/YYYY-MM-DD.md)."""

    def __init__(self, workspace: Path):
        self.memory_dir = ensure_dir(workspace / "memory")
        self.memory_file = self.memory_dir / "MEMORY.md"
        # Legacy file kept only for migration reads.
        self.legacy_history_file = self.memory_dir / "HISTORY.md"

    def read_long_term(self) -> str:
        if self.memory_file.exists():
            return self.memory_file.read_text(encoding="utf-8")
        return ""

    def write_long_term(self, content: str) -> None:
        self.memory_file.write_text(content, encoding="utf-8")

    def get_daily_file(self, when: datetime | None = None) -> Path:
        ts = when or datetime.now()
        return self.memory_dir / f"{ts:%Y-%m-%d}.md"

    def append_daily(self, entry: str, when: datetime | None = None) -> None:
        daily_file = self.get_daily_file(when)
        with open(daily_file, "a", encoding="utf-8") as f:
            f.write(entry.rstrip() + "\n\n")

    def read_recent_daily(self, days: int = 2, max_chars: int = 6000) -> str:
        """Read recent daily logs (today backwards). Includes legacy HISTORY.md as fallback."""
        chunks: list[str] = []
        now = datetime.now()
        for offset in range(max(1, days)):
            fp = self.get_daily_file(now - timedelta(days=offset))
            if fp.exists():
                content = fp.read_text(encoding="utf-8").strip()
                if content:
                    chunks.append(f"### {fp.name}\n{content}")

        if not chunks and self.legacy_history_file.exists():
            legacy = self.legacy_history_file.read_text(encoding="utf-8").strip()
            if legacy:
                chunks.append(f"### HISTORY.md (legacy)\n{legacy}")

        merged = "\n\n".join(chunks)
        if len(merged) > max_chars:
            return merged[:max_chars] + "\n\n...(truncated)"
        return merged

    def get_memory_context(self) -> str:
        parts: list[str] = []
        long_term = self.read_long_term()
        if long_term:
            parts.append(f"## 长期记忆\n{long_term}")

        recent = self.read_recent_daily(days=2)
        if recent:
            parts.append(f"## 近期每日记忆\n{recent}")

        return "\n\n".join(parts)

    async def consolidate(
        self,
        session: Session,
        provider: LLMProvider,
        model: str,
        *,
        archive_all: bool = False,
        memory_window: int = 50,
    ) -> bool:
        """Consolidate old messages into MEMORY.md + daily logs via LLM tool call.

        Returns True on success (including no-op), False on failure.
        """
        if archive_all:
            old_messages = session.messages
            keep_count = 0
            logger.info("Memory consolidation (archive_all): {} messages", len(session.messages))
        else:
            keep_count = memory_window // 2
            if len(session.messages) <= keep_count:
                return True
            if len(session.messages) - session.last_consolidated <= 0:
                return True
            old_messages = session.messages[session.last_consolidated:-keep_count]
            if not old_messages:
                return True
            logger.info("Memory consolidation: {} to consolidate, {} keep", len(old_messages), keep_count)

        lines = []
        for m in old_messages:
            if not m.get("content"):
                continue
            tools = f" [tools: {', '.join(m['tools_used'])}]" if m.get("tools_used") else ""
            lines.append(f"[{m.get('timestamp', '?')[:16]}] {m['role'].upper()}{tools}: {m['content']}")

        current_memory = self.read_long_term()
        prompt = f"""处理以下对话并调用 save_memory 工具提交你的整合结果。
daily_entry 应为今日文件（memory/YYYY-MM-DD.md）的仅追加笔记。
memory_update 应为 MEMORY.md 的完整更新内容。

## 安全规则
1. daily_entry 仅追加——如果当日文件已存在，你的内容将被追加，不会覆盖。
2. MEMORY.md 的内容必须且只能通过 memory_update 返回值写入——不要通过其他工具修改。
3. 不要修改 SOUL.md、TOOLS.md 或 AGENTS.md。

## memory_update 必需章节
memory_update 必须包含以下章节（如不存在请创建）：
- ## 决策 — 已做出的关键决策及其理由
- ## 待办事项 — 未完成的任务或待处理项
- ## 精确标识符 — 所有 UUID、提交哈希、PR/Issue 编号、API 密钥、URL、文件路径、版本号

## 标识符保留策略
原样保留所有精确标识符——UUID、提交哈希、PR/Issue 编号、API 密钥、URL、
文件路径、版本号。不要缩写、改写或重构它们。

## 当前长期记忆
{current_memory or "（空）"}

## 待处理的对话
{chr(10).join(lines)}"""

        try:
            args = await self._consolidate_with_retry(
                prompt=prompt, model=model, provider=provider,
            )
            if args is None:
                logger.warning("Memory consolidation: agno did not produce save_memory payload")
                return False

            if not isinstance(args, dict):
                logger.warning("Memory consolidation: unexpected arguments type {}", type(args).__name__)
                return False

            if entry := args.get("daily_entry"):
                if not isinstance(entry, str):
                    entry = json.dumps(entry, ensure_ascii=False)
                self.append_daily(entry)
            elif entry := args.get("history_entry"):
                # Compatibility with old payload name.
                if not isinstance(entry, str):
                    entry = json.dumps(entry, ensure_ascii=False)
                self.append_daily(entry)
            if update := args.get("memory_update"):
                if not isinstance(update, str):
                    update = json.dumps(update, ensure_ascii=False)
                if update != current_memory:
                    self.write_long_term(update)

            session.last_consolidated = 0 if archive_all else len(session.messages) - keep_count
            logger.info("Memory consolidation done: {} messages, last_consolidated={}", len(session.messages), session.last_consolidated)
            return True
        except Exception:
            logger.exception("Memory consolidation failed")
            return False

    # ── Compaction quality validation ─────────────────────────────────

    _REQUIRED_SECTIONS = ["## 决策", "## 待办事项", "## 精确标识符"]
    _MAX_COMPACTION_CHARS = 16_000
    _MAX_RETRIES = 2

    def _validate_compaction(self, memory_update: str) -> list[str]:
        """Check memory_update for required sections. Returns list of missing section names."""
        if not memory_update:
            return list(self._REQUIRED_SECTIONS)
        missing = []
        lower = memory_update.lower()
        for section in self._REQUIRED_SECTIONS:
            if section.lower() not in lower:
                missing.append(section)
        return missing

    async def _consolidate_with_retry(
        self,
        prompt: str,
        model: str,
        provider: "LLMProvider",
    ) -> dict | None:
        """Run consolidation with quality validation and retry on missing sections."""
        for attempt in range(1 + self._MAX_RETRIES):
            args = await self._consolidate_with_agno(
                prompt=prompt, model=model, provider=provider,
            )
            if args is None:
                return None

            update = args.get("memory_update", "")
            if isinstance(update, str) and len(update) > self._MAX_COMPACTION_CHARS:
                args["memory_update"] = update[:self._MAX_COMPACTION_CHARS] + "\n\n...(truncated)"
                logger.info("Compaction output truncated to {} chars", self._MAX_COMPACTION_CHARS)

            missing = self._validate_compaction(args.get("memory_update", ""))
            if not missing:
                return args

            if attempt < self._MAX_RETRIES:
                logger.warning(
                    "Compaction quality check failed (attempt {}/{}): missing {}",
                    attempt + 1, 1 + self._MAX_RETRIES, missing,
                )
                # Append retry instruction to prompt
                prompt = prompt + (
                    f"\n\n## 重试：缺少必需章节\n"
                    f"你上次的输出缺少以下章节：{', '.join(missing)}。\n"
                    f"请在 memory_update 中包含所有必需章节。"
                )
            else:
                logger.warning(
                    "Compaction quality check failed after {} attempts: missing {}. Accepting anyway.",
                    1 + self._MAX_RETRIES, missing,
                )

        return args

    async def _consolidate_with_agno(
        self,
        prompt: str,
        model: str,
        provider: "LLMProvider",
    ) -> dict | None:
        """Run memory consolidation via agno agent tool call."""
        try:
            from agno.agent.agent import Agent
            from agno.tools import tool
        except Exception:
            logger.exception("Agno memory runtime unavailable")
            return None

        payload: dict[str, str] = {}

        @tool(name="save_memory", description="Save consolidated memory output.")
        async def save_memory(daily_entry: str, memory_update: str) -> str:
            payload["daily_entry"] = daily_entry
            payload["memory_update"] = memory_update
            return "ok"

        agent = Agent(
            model=provider.build_model(model=model),
            tools=[save_memory],
            instructions=(
                "你是一个记忆整合代理。"
                "请恰好调用一次 save_memory(daily_entry, memory_update)。"
                "daily_entry 必须是今日每日日志文件的仅追加笔记。"
                "不要修改 SOUL.md、TOOLS.md 或 AGENTS.md。"
                "MEMORY.md 的内容只能通过 memory_update 写入。"
                "memory_update 必须包含以下章节：## 决策、## 待办事项、## 精确标识符。"
                "原样保留所有 UUID、提交哈希、PR 编号、URL、文件路径、版本号。"
            ),
            stream=False,
        )
        await agent.arun(prompt, stream=False)
        return payload or None
