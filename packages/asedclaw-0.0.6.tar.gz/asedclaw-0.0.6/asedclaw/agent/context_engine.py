"""Context Engine: three-stage lifecycle for context window management.

Stages:
  assemble(messages, budget) → trim history to fit token budget
  maintain(messages)         → post-turn cleanup (compress old tool results, remove stale metadata)
  compact(messages, ...)     → LLM-based summarization of old messages (replaces mechanical truncation)
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from loguru import logger

from asedclaw.agent.token_utils import estimate_messages_tokens, estimate_tokens

if TYPE_CHECKING:
    from pathlib import Path

    from asedclaw.config.schema import CompactionConfig, ContextBudgetConfig, ToolResultBudgetConfig
    from asedclaw.providers.base import LLMProvider

# Placeholder text when tool output is compacted away
_COMPACTED_MARKER = "[compacted: tool output removed]"


class ContextEngine:
    """Manages context window budget across the agent lifecycle."""

    def __init__(
        self,
        budget_config: ContextBudgetConfig | None = None,
        result_budget_config: ToolResultBudgetConfig | None = None,
        compaction_config: CompactionConfig | None = None,
    ):
        from asedclaw.config.schema import CompactionConfig, ContextBudgetConfig, ToolResultBudgetConfig

        self._cfg = budget_config or ContextBudgetConfig()
        self._result_cfg = result_budget_config or ToolResultBudgetConfig()
        self._compaction_cfg = compaction_config or CompactionConfig()
        # Track whether compaction happened this turn (for post-compaction refresh)
        self._compacted_this_turn = False

    # ── Stage 1: Assemble ────────────────────────────────────────────

    def assemble(
        self,
        messages: list[dict[str, Any]],
        budget_tokens: int | None = None,
    ) -> tuple[list[dict[str, Any]], int]:
        """Trim message history to fit within token budget.

        Keeps system prompt + most recent messages that fit.
        Returns (trimmed_messages, estimated_tokens).
        """
        if budget_tokens is None:
            budget_tokens = int(self._cfg.context_window * self._cfg.input_budget_ratio)

        if not messages:
            return messages, 0

        # System prompt always kept
        system_msgs = [m for m in messages if m.get("role") == "system"]
        non_system = [m for m in messages if m.get("role") != "system"]

        system_tokens = estimate_messages_tokens(system_msgs)
        remaining_budget = budget_tokens - system_tokens

        if remaining_budget <= 0:
            logger.warning("System prompt ({} tokens) exceeds budget ({})", system_tokens, budget_tokens)
            return system_msgs + non_system[-2:], estimate_messages_tokens(system_msgs + non_system[-2:])

        # Walk backwards from most recent, accumulating messages
        kept: list[dict[str, Any]] = []
        running_tokens = 0

        for m in reversed(non_system):
            msg_tokens = estimate_messages_tokens([m])
            if running_tokens + msg_tokens > remaining_budget:
                break
            kept.append(m)
            running_tokens += msg_tokens

        kept.reverse()

        # Ensure we always keep at least the last user message
        if not kept and non_system:
            kept = non_system[-1:]
            running_tokens = estimate_messages_tokens(kept)

        result = system_msgs + kept
        total_tokens = system_tokens + running_tokens

        trimmed_count = len(non_system) - len(kept)
        if trimmed_count > 0:
            logger.info(
                "Context assemble: trimmed {} messages, kept {}, ~{} tokens (budget {})",
                trimmed_count, len(kept), total_tokens, budget_tokens,
            )

        return result, total_tokens

    # ── Stage 2: Maintain ────────────────────────────────────────────

    def maintain(self, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Post-turn maintenance: compress old tool results to save context space.

        Only compresses tool results older than the most recent user message.
        """
        # Find index of the most recent user message
        last_user_idx = -1
        for i in range(len(messages) - 1, -1, -1):
            if messages[i].get("role") == "user":
                last_user_idx = i
                break

        if last_user_idx <= 0:
            return messages

        result = list(messages)
        max_old_tool_chars = int(self._result_cfg.hard_max_tool_result_chars * self._result_cfg.maintain_old_tool_ratio)

        for i in range(last_user_idx):
            m = result[i]
            if m.get("role") != "tool":
                continue
            content = m.get("content", "")
            if not isinstance(content, str):
                continue
            if content == _COMPACTED_MARKER:
                continue
            if len(content) > max_old_tool_chars:
                result[i] = {**m, "content": content[:max_old_tool_chars] + "\n... (compacted)"}

        return result

    # ── Stage 3: Preemptive overflow compression ─────────────────────

    def compress_tool_results_if_needed(
        self,
        messages: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """L3: If total tokens exceed preemptive ratio, compress old tool results."""
        total_tokens = estimate_messages_tokens(messages)
        threshold = int(self._cfg.context_window * self._result_cfg.preemptive_ratio)

        if total_tokens <= threshold:
            return messages

        logger.info(
            "Preemptive compression triggered: {} tokens > {} threshold",
            total_tokens, threshold,
        )

        result = list(messages)
        # Compress tool results from oldest to newest until under threshold
        for i, m in enumerate(result):
            if m.get("role") != "tool":
                continue
            content = m.get("content", "")
            if not isinstance(content, str) or content == _COMPACTED_MARKER:
                continue
            result[i] = {**m, "content": _COMPACTED_MARKER}
            total_tokens = estimate_messages_tokens(result)
            if total_tokens <= threshold:
                break

        logger.info("After preemptive compression: ~{} tokens", total_tokens)
        return result

    # ── Tool result budget enforcement (L1 + L2) ─────────────────────

    def enforce_tool_result_budget(
        self,
        result_text: str,
        round_result_tokens: int,
    ) -> tuple[str, int]:
        """Enforce L1 (single result) and L2 (total round) budgets.

        Returns (possibly truncated result, updated round total).
        """
        cfg = self._result_cfg

        # Hard max chars
        if len(result_text) > cfg.hard_max_tool_result_chars:
            result_text = result_text[:cfg.hard_max_tool_result_chars] + "\n... (truncated)"

        # L1: single result token budget
        l1_budget = int(self._cfg.context_window * cfg.single_result_share)
        result_tokens = estimate_tokens(result_text)

        if result_tokens > l1_budget:
            # Estimate chars to keep based on ratio
            keep_ratio = l1_budget / max(result_tokens, 1)
            keep_chars = int(len(result_text) * keep_ratio)
            result_text = result_text[:keep_chars] + "\n... (truncated: exceeded single result budget)"
            result_tokens = estimate_tokens(result_text)
            logger.debug("L1 truncation: {} tokens → {} tokens", result_tokens, l1_budget)

        # L2: total round budget
        l2_budget = int(self._cfg.context_window * cfg.total_result_share)
        if round_result_tokens + result_tokens > l2_budget:
            available = max(100, l2_budget - round_result_tokens)
            keep_ratio = available / max(result_tokens, 1)
            if keep_ratio < 1.0:
                keep_chars = int(len(result_text) * keep_ratio)
                result_text = result_text[:keep_chars] + "\n... (truncated: total result budget exceeded)"
                result_tokens = estimate_tokens(result_text)
                logger.debug("L2 truncation: round total would exceed {} tokens", l2_budget)

        return result_text, round_result_tokens + result_tokens

    # ── LLM-based compaction ─────────────────────────────────────────

    def should_compact(self, messages: list[dict[str, Any]]) -> bool:
        """Check whether LLM compaction should be triggered."""
        if not self._compaction_cfg.enabled:
            return False
        total_tokens = estimate_messages_tokens(messages)
        threshold = int(self._cfg.context_window * self._compaction_cfg.trigger_ratio)
        return total_tokens > threshold

    async def compact(
        self,
        messages: list[dict[str, Any]],
        *,
        provider: LLMProvider,
        model: str,
        workspace: Path | None = None,
    ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        """Run LLM-based compaction to summarize old messages.

        Falls back to mechanical truncation (compress_tool_results_if_needed)
        if LLM compaction is disabled or fails.

        Returns (compacted_messages, metrics_dict).
        """
        from asedclaw.agent.compaction import compact_session

        self._compacted_this_turn = False

        if not self._compaction_cfg.enabled:
            return messages, {"compacted": False, "reason": "disabled"}

        result, metrics = await compact_session(
            messages,
            provider=provider,
            model=model,
            config=self._compaction_cfg,
            workspace=workspace,
        )

        if metrics.get("compacted"):
            self._compacted_this_turn = True
            return result, metrics

        # Fallback to mechanical truncation
        if self._compaction_cfg.fallback_to_truncation:
            logger.info("Falling back to mechanical truncation after LLM compaction failure")
            result = self.compress_tool_results_if_needed(messages)
            return result, {**metrics, "fallback": "mechanical_truncation"}

        return messages, metrics

    @property
    def compacted_this_turn(self) -> bool:
        """Whether LLM compaction was performed during the current turn."""
        return self._compacted_this_turn
