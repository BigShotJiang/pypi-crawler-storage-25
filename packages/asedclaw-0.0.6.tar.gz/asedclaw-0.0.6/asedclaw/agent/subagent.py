"""Subagent manager for background task execution."""

import asyncio
import uuid
from pathlib import Path

from loguru import logger

from asedclaw.agent.rule_engine import RuleEngine
from asedclaw.agent.tools.filesystem import FilesystemToolkit
from asedclaw.agent.tools.memory import MemoryToolkit
from asedclaw.agent.tools.registry import ToolRegistry
from asedclaw.agent.tools.shell import ExecTool
from asedclaw.agent.tools.web import WebToolkit
from asedclaw.bus.events import InboundMessage
from asedclaw.bus.queue import MessageBus
from asedclaw.config.schema import ExecToolConfig
from asedclaw.providers.base import LLMProvider


class SubagentManager:
    """Manages background subagent execution."""

    def __init__(
        self,
        provider: LLMProvider,
        workspace: Path,
        bus: MessageBus,
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        reasoning_effort: str | None = None,
        brave_api_key: str | None = None,
        web_proxy: str | None = None,
        exec_config: "ExecToolConfig | None" = None,
        restrict_to_workspace: bool = False,
    ):
        from asedclaw.config.schema import ExecToolConfig
        self.provider = provider
        self.workspace = workspace
        self.bus = bus
        self.model = model or provider.get_default_model()
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.reasoning_effort = reasoning_effort
        self.brave_api_key = brave_api_key
        self.web_proxy = web_proxy
        self.exec_config = exec_config or ExecToolConfig()
        self.restrict_to_workspace = restrict_to_workspace
        self._running_tasks: dict[str, asyncio.Task[None]] = {}
        self._session_tasks: dict[str, set[str]] = {}  # session_key -> {task_id, ...}

    async def spawn(
        self,
        task: str,
        label: str | None = None,
        origin_channel: str = "cli",
        origin_chat_id: str = "direct",
        session_key: str | None = None,
    ) -> str:
        """Spawn a subagent to execute a task in the background."""
        task_id = str(uuid.uuid4())[:8]
        display_label = label or task[:30] + ("..." if len(task) > 30 else "")
        origin = {"channel": origin_channel, "chat_id": origin_chat_id}

        bg_task = asyncio.create_task(
            self._run_subagent(task_id, task, display_label, origin)
        )
        self._running_tasks[task_id] = bg_task
        if session_key:
            self._session_tasks.setdefault(session_key, set()).add(task_id)

        def _cleanup(_: asyncio.Task) -> None:
            self._running_tasks.pop(task_id, None)
            if session_key and (ids := self._session_tasks.get(session_key)):
                ids.discard(task_id)
                if not ids:
                    del self._session_tasks[session_key]

        bg_task.add_done_callback(_cleanup)

        logger.info("Spawned subagent [{}]: {}", task_id, display_label)
        return f"子代理 [{display_label}] 已启动（id: {task_id}）。完成后会通知你。"

    async def _run_subagent(
        self,
        task_id: str,
        task: str,
        label: str,
        origin: dict[str, str],
    ) -> None:
        """Execute the subagent task and announce the result."""
        logger.info("Subagent [{}] starting task: {}", task_id, label)

        try:
            # Build subagent tools (no message tool, no spawn tool)
            tools = ToolRegistry()
            allowed_dir = self.workspace if self.restrict_to_workspace else None
            rule_engine = RuleEngine()
            tools.register_many(
                FilesystemToolkit(workspace=self.workspace, allowed_dir=allowed_dir),
                MemoryToolkit(workspace=self.workspace),
                ExecTool(
                    working_dir=str(self.workspace),
                    timeout=self.exec_config.timeout,
                    restrict_to_workspace=self.restrict_to_workspace,
                    path_append=self.exec_config.path_append,
                    approval_required_patterns=self.exec_config.approval_required_patterns,
                    rule_engine=rule_engine,
                ),
                WebToolkit(api_key=self.brave_api_key, proxy=self.web_proxy),
            )
            system_prompt = self._build_subagent_prompt()
            final_result = await self._run_with_agno(task, system_prompt, tools)

            if final_result is None:
                final_result = "任务已完成，但未生成最终回复。"

            logger.info("Subagent [{}] completed successfully", task_id)
            await self._announce_result(task_id, label, task, final_result, origin, "ok")

        except Exception as e:
            error_msg = f"Error: {str(e)}"
            logger.error("Subagent [{}] failed: {}", task_id, e)
            await self._announce_result(task_id, label, task, error_msg, origin, "error")

    async def _run_with_agno(
        self,
        task: str,
        system_prompt: str,
        registry: ToolRegistry,
    ) -> str | None:
        """Run a subagent task via agno Agent."""
        try:
            from agno.agent import RunEvent
            from agno.agent.agent import Agent
        except Exception:
            logger.exception("Subagent agno runtime unavailable")
            return None

        agent = Agent(
            model=self.provider.build_model(
                model=self.model,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                reasoning_effort=self.reasoning_effort,
            ),
            tools=registry.get_agno_tool_instances(),
            instructions=system_prompt,
            markdown=True,
            stream=True,
        )

        final_content = ""
        async for event in agent.arun(task, stream=True, stream_events=True):
            if getattr(event, "event", None) == RunEvent.run_content:
                delta = getattr(event, "content", None)
                if isinstance(delta, str) and delta:
                    final_content += delta
            elif getattr(event, "event", None) == RunEvent.run_completed:
                content = getattr(event, "content", None)
                if isinstance(content, str) and content.strip():
                    final_content = content

        return final_content or None

    async def _announce_result(
        self,
        task_id: str,
        label: str,
        task: str,
        result: str,
        origin: dict[str, str],
        status: str,
    ) -> None:
        """Announce the subagent result to the main agent via the message bus."""
        status_text = "已成功完成" if status == "ok" else "执行失败"

        announce_content = f"""[子代理 '{label}' {status_text}]

任务：{task}

结果：
{result}

请自然地为用户总结此结果。保持简洁（1-2 句话）。不要提及"子代理"或任务 ID 等技术细节。"""

        # Inject as system message to trigger main agent
        msg = InboundMessage(
            channel="system",
            sender_id="subagent",
            chat_id=f"{origin['channel']}:{origin['chat_id']}",
            content=announce_content,
        )

        await self.bus.publish_inbound(msg)
        logger.debug("Subagent [{}] announced result to {}:{}", task_id, origin['channel'], origin['chat_id'])
    
    def _build_subagent_prompt(self) -> str:
        """Build a focused system prompt for the subagent."""
        from asedclaw.agent.context import ContextBuilder
        from asedclaw.agent.skills import SkillsLoader

        time_ctx = ContextBuilder._build_runtime_context(None, None)
        parts = [f"""# 子代理

{time_ctx}

你是由主代理派生的子代理，用于完成特定任务。
请专注于分配的任务。你的最终回复将被报告给主代理。

## 工作区
{self.workspace}"""]

        skills_summary = SkillsLoader(self.workspace).build_skills_summary()
        if skills_summary:
            parts.append(f"## 技能\n\n使用 read_file 读取 SKILL.md 以使用技能。\n\n{skills_summary}")

        return "\n\n".join(parts)
    
    async def cancel_by_session(self, session_key: str) -> int:
        """Cancel all subagents for the given session. Returns count cancelled."""
        tasks = [self._running_tasks[tid] for tid in self._session_tasks.get(session_key, [])
                 if tid in self._running_tasks and not self._running_tasks[tid].done()]
        for t in tasks:
            t.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        return len(tasks)

    def get_running_count(self) -> int:
        """Return the number of currently running subagents."""
        return len(self._running_tasks)
