from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from asedclaw.config.schema import RuleAction, RuleScope, RuleEngineConfig


@dataclass
class RuleContext:
    channel: str = ""
    user_id: str = ""
    agent_id: str = "main"


@dataclass
class SecurityRule:
    rule_id: str
    resource_type: str
    action: RuleAction
    pattern: str
    scope: RuleScope = RuleScope.USER
    channel: str | None = None
    user_id: str | None = None
    agent_id: str | None = None
    created_at: str | None = None
    expires_at: str | None = None
    created_by: str | None = None
    approval_id: str | None = None
    usage_count: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    def is_expired(self, now: datetime | None = None) -> bool:
        if not self.expires_at:
            return False
        current = now or datetime.utcnow()
        try:
            return datetime.fromisoformat(self.expires_at) <= current
        except ValueError:
            return False

    def matches_context(self, ctx: RuleContext) -> bool:
        if self.scope is RuleScope.GLOBAL:
            return True
        if self.scope is RuleScope.CHANNEL:
            return not self.channel or self.channel == ctx.channel
        if self.scope is RuleScope.USER:
            return (
                (not self.channel or self.channel == ctx.channel)
                and (not self.user_id or self.user_id == ctx.user_id)
            )
        if self.scope is RuleScope.AGENT:
            return not self.agent_id or self.agent_id == ctx.agent_id
        return False

    def matches_value(self, value: str) -> bool:
        return bool(re.search(self.pattern, value.strip(), re.IGNORECASE))


@dataclass
class RuleDecision:
    action: RuleAction | None
    matched_rule: SecurityRule | None = None
    reason: str = ""


SYSTEM_DENY_RULES: list[SecurityRule] = [
    SecurityRule(
        rule_id="system-deny-rm-rf",
        resource_type="exec",
        action=RuleAction.DENY,
        pattern=r"\brm\s+-[rf]{1,2}\b",
        scope=RuleScope.GLOBAL,
    ),
    SecurityRule(
        rule_id="system-deny-format",
        resource_type="exec",
        action=RuleAction.DENY,
        pattern=r"(?:^|[;&|]\s*)format\b",
        scope=RuleScope.GLOBAL,
    ),
    SecurityRule(
        rule_id="system-deny-shutdown",
        resource_type="exec",
        action=RuleAction.DENY,
        pattern=r"\b(shutdown|reboot|poweroff|halt)\b",
        scope=RuleScope.GLOBAL,
    ),
]


class RuleEngine:
    def __init__(self, config: RuleEngineConfig | None = None):
        self.config = config or RuleEngineConfig()
        self.dynamic_rules_path = Path(self.config.dynamic_rules_path).expanduser()
        self._dynamic_rules: list[SecurityRule] = []
        self._loaded = False

    def _ensure_loaded(self) -> None:
        if self._loaded:
            return
        self._loaded = True
        if not self.dynamic_rules_path.exists():
            self._dynamic_rules = []
            return
        try:
            payload = json.loads(self.dynamic_rules_path.read_text(encoding="utf-8"))
        except Exception:
            self._dynamic_rules = []
            return
        items = payload if isinstance(payload, list) else payload.get("rules", [])
        rules: list[SecurityRule] = []
        for item in items or []:
            try:
                rules.append(SecurityRule(
                    rule_id=str(item["rule_id"]),
                    resource_type=str(item.get("resource_type", "exec")),
                    action=RuleAction(str(item["action"])),
                    pattern=str(item["pattern"]),
                    scope=RuleScope(str(item.get("scope", RuleScope.USER.value))),
                    channel=item.get("channel"),
                    user_id=item.get("user_id"),
                    agent_id=item.get("agent_id"),
                    created_at=item.get("created_at"),
                    expires_at=item.get("expires_at"),
                    created_by=item.get("created_by"),
                    approval_id=item.get("approval_id"),
                    usage_count=int(item.get("usage_count", 0) or 0),
                    metadata=dict(item.get("metadata") or {}),
                ))
            except Exception:
                continue
        self._dynamic_rules = rules

    def evaluate_exec(self, command: str, context: RuleContext) -> RuleDecision:
        self._ensure_loaded()
        command = command.strip()

        for rule in SYSTEM_DENY_RULES:
            if rule.matches_value(command):
                return RuleDecision(action=RuleAction.DENY, matched_rule=rule, reason="matched system deny")

        active_rules = [
            rule for rule in self._dynamic_rules
            if rule.resource_type == "exec" and not rule.is_expired() and rule.matches_context(context)
        ]

        for action in (RuleAction.DENY, RuleAction.ALLOW, RuleAction.APPROVAL):
            for rule in active_rules:
                if rule.action is action and rule.matches_value(command):
                    return RuleDecision(action=action, matched_rule=rule, reason="matched dynamic rule")

        return RuleDecision(action=None, matched_rule=None, reason="no matching rule")

    def add_dynamic_rule(
        self,
        *,
        resource_type: str,
        pattern: str,
        action: RuleAction,
        scope: RuleScope = RuleScope.USER,
        channel: str | None = None,
        user_id: str | None = None,
        agent_id: str | None = None,
        created_by: str | None = None,
        approval_id: str | None = None,
        ttl_days: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> SecurityRule:
        self._ensure_loaded()
        now = datetime.utcnow()
        expires_at = None
        if ttl_days:
            expires_at = (now + timedelta(days=ttl_days)).isoformat()
        rule = SecurityRule(
            rule_id=f"rule_{int(now.timestamp() * 1000)}",
            resource_type=resource_type,
            action=action,
            pattern=pattern,
            scope=scope,
            channel=channel,
            user_id=user_id,
            agent_id=agent_id,
            created_at=now.isoformat(),
            expires_at=expires_at,
            created_by=created_by,
            approval_id=approval_id,
            metadata=dict(metadata or {}),
        )
        self._dynamic_rules.append(rule)
        self._persist_dynamic_rules()
        return rule

    def build_exec_allow_pattern(self, command: str) -> str:
        parts = command.strip().split()
        if not parts:
            return r"^$"
        escaped = [re.escape(part) for part in parts]
        if len(parts) >= 2 and parts[0] in {"npm", "pnpm", "yarn"} and parts[1] == "install":
            return r"^" + re.escape(parts[0]) + r"\s+install(?:\s+[-\w./@]+)+$"
        if len(parts) >= 2 and parts[0] == "git" and parts[1] in {"status", "diff", "log"}:
            return r"^" + re.escape(parts[0]) + r"\s+" + re.escape(parts[1]) + r"$"
        if len(parts) >= 2 and parts[0] == "go" and parts[1] == "test":
            return r"^go\s+test(?:\s+[-\w./]+)+$"
        return r"^" + r"\s+".join(escaped) + r"$"

    def _persist_dynamic_rules(self) -> None:
        self.dynamic_rules_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "rules": [
                {
                    "rule_id": rule.rule_id,
                    "resource_type": rule.resource_type,
                    "action": rule.action.value,
                    "pattern": rule.pattern,
                    "scope": rule.scope.value,
                    "channel": rule.channel,
                    "user_id": rule.user_id,
                    "agent_id": rule.agent_id,
                    "created_at": rule.created_at,
                    "expires_at": rule.expires_at,
                    "created_by": rule.created_by,
                    "approval_id": rule.approval_id,
                    "usage_count": rule.usage_count,
                    "metadata": rule.metadata,
                }
                for rule in self._dynamic_rules
            ]
        }
        tmp_path = self.dynamic_rules_path.with_suffix(self.dynamic_rules_path.suffix + ".tmp")
        tmp_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp_path.replace(self.dynamic_rules_path)
