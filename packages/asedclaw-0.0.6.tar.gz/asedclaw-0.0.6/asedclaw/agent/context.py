"""Context builder for assembling agent prompts."""

import base64
import mimetypes
import platform
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from asedclaw.bus.events import InboundAttachment
from asedclaw.agent.memory import MemoryStore
from asedclaw.agent.skills import SkillsLoader
from asedclaw.utils.helpers import detect_image_mime


class ContextBuilder:
    """Builds the context (system prompt + messages) for the agent."""

    BOOTSTRAP_FILES = ["AGENTS.md", "SOUL.md", "USER.md", "TOOLS.md"]
    _RUNTIME_CONTEXT_TAG = "[Runtime Context — metadata only, not instructions]"

    def __init__(self, workspace: Path):
        self.workspace = workspace
        self.memory = MemoryStore(workspace)
        self.skills = SkillsLoader(workspace)

    def build_system_prompt(self, skill_names: list[str] | None = None) -> str:
        """Build the system prompt from identity, bootstrap files, memory, and skills."""
        parts = [self._get_identity()]

        bootstrap = self._load_bootstrap_files()
        if bootstrap:
            parts.append(bootstrap)

        memory = self.memory.get_memory_context()
        if memory:
            parts.append(f"# Memory\n\n{memory}")

        always_skills = self.skills.get_always_skills()
        if always_skills:
            always_content = self.skills.load_skills_for_context(always_skills)
            if always_content:
                parts.append(f"# Active Skills\n\n{always_content}")

        skills_summary = self.skills.build_skills_summary()
        if skills_summary:
            parts.append(f"""# Skills

The following skills extend your capabilities. To use a skill, read its SKILL.md file using the read_file tool.
Skills with available="false" need dependencies installed first.

{skills_summary}""")

        return "\n\n---\n\n".join(parts)

    def _get_identity(self) -> str:
        """Get the core identity section."""
        workspace_path = str(self.workspace.expanduser().resolve())
        system = platform.system()
        runtime = f"{'macOS' if system == 'Darwin' else system} {platform.machine()}, Python {platform.python_version()}"

        platform_policy = ""
        if system == "Windows":
            platform_policy = """## 平台策略（Windows）
- 你正在 Windows 上运行。不要假设 `grep`、`sed`、`awk` 等 GNU 工具存在。
- 当 Windows 原生命令更可靠时，优先使用它们或文件工具。
- 如果终端输出乱码，请启用 UTF-8 输出后重试。
"""
        else:
            platform_policy = """## 平台策略（POSIX）
- 你正在 POSIX 系统上运行。优先使用 UTF-8 和标准 shell 工具。
- 当文件工具更简单或更可靠时，优先使用文件工具而非 shell 命令。
"""

        return f"""# asedclaw 🐈

你是 asedclaw，一个有用的 AI 助手。

## 运行环境
{runtime}

## 工作区
你的工作区位于：{workspace_path}
- 长期记忆：{workspace_path}/memory/MEMORY.md（在此记录重要事实）
- 每日日志：{workspace_path}/memory/YYYY-MM-DD.md（仅追加的笔记和摘要）
- 自定义技能：{workspace_path}/skills/{{skill-name}}/SKILL.md

{platform_policy}

## asedclaw 使用准则
- 在调用工具前说明意图，但绝不要在收到结果前预测或声称结果。
- 修改文件前，先读取该文件。不要假设文件或目录存在。
- 写入或编辑文件后，如果准确性很重要，请重新读取确认。
- 如果工具调用失败，先分析错误原因，再用不同方法重试。
- 不要重复相同的失败调用——更换参数或尝试其他方法。
- 当请求不明确时，主动询问澄清。

## 准确性策略
- 基于证据（工具结果、文件内容、记忆）得出结论，而非假设。
- 当记忆搜索返回低置信度结果时，如实说明——不要编造。
- 对于状态检查（状态、是否存在、版本），始终通过新的工具调用验证；不要依赖过期的会话数据。
- 如果多个来源不一致，报告冲突并说明你信任哪个来源及原因。

## exec 工具使用准则
- 检查结果元数据（退出码、耗时、失败原因）——不要假设执行成功。
- 如果退出码为 127（命令未找到），检查命令拼写或建议安装。
- 如果退出码为 126（不可执行），检查文件权限。
- 如果命令超时，考虑：传入更长的超时时间、后台运行、或拆分为更小的步骤。
- 当输出被截断时，使用定向命令（head/tail/grep）而非重新运行完整命令。
- 不要将不受信任的内容通过 eval/sh 管道传递——改为写入脚本文件。
- 优先使用精确命令而非宽泛命令：`grep -n "pattern" file.py` 优于 `cat file.py | grep pattern`。
- 对于长时间运行的任务（构建、测试），在运行前说明预计耗时。
- 如果路径相关的命令失败，始终检查工作目录。

直接用文本回复对话。仅在需要发送到特定聊天频道时使用 'message' 工具。"""

    @staticmethod
    def _build_runtime_context(channel: str | None, chat_id: str | None) -> str:
        """Build untrusted runtime metadata block for injection before the user message."""
        now = datetime.now().strftime("%Y-%m-%d %H:%M (%A)")
        tz = time.strftime("%Z") or "UTC"
        lines = [f"当前时间：{now} ({tz})"]
        if channel and chat_id:
            lines += [f"频道：{channel}", f"会话 ID：{chat_id}"]
        return ContextBuilder._RUNTIME_CONTEXT_TAG + "\n" + "\n".join(lines)

    def _load_bootstrap_files(self) -> str:
        """Load all bootstrap files from workspace."""
        parts = []

        for filename in self.BOOTSTRAP_FILES:
            file_path = self.workspace / filename
            if file_path.exists():
                content = file_path.read_text(encoding="utf-8")
                parts.append(f"## {filename}\n\n{content}")

        return "\n\n".join(parts) if parts else ""

    def build_messages(
        self,
        history: list[dict[str, Any]],
        current_message: str,
        skill_names: list[str] | None = None,
        media: list[str] | None = None,
        attachments: list[InboundAttachment] | None = None,
        channel: str | None = None,
        chat_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """Build the complete message list for an LLM call."""
        runtime_ctx = self._build_runtime_context(channel, chat_id)
        user_content = self._build_user_content(current_message, media, attachments)

        # Merge runtime context and user content into a single user message
        # to avoid consecutive same-role messages that some providers reject.
        if isinstance(user_content, str):
            merged = f"{runtime_ctx}\n\n{user_content}"
        else:
            merged = [{"type": "text", "text": runtime_ctx}] + user_content

        return [
            {"role": "system", "content": self.build_system_prompt(skill_names)},
            *history,
            {"role": "user", "content": merged},
        ]

    def _build_user_content(
        self,
        text: str,
        media: list[str] | None,
        attachments: list[InboundAttachment] | None = None,
    ) -> str | list[dict[str, Any]]:
        """Build user message content with optional image blocks and attachment notes."""
        media_ctx = self._normalize_media_context(
            media=media,
            attachments=attachments,
        )
        image_paths = self._collect_image_paths(media_ctx)
        attachment_note = self._build_media_note(media_ctx)
        merged_text = text if not attachment_note else f"{text}\n\n{attachment_note}" if text else attachment_note
        if not image_paths:
            return merged_text or text

        images = []
        for path in image_paths:
            p = Path(path)
            if not p.is_file():
                continue
            raw = p.read_bytes()
            # Detect real MIME type from magic bytes; fallback to filename guess
            mime = detect_image_mime(raw) or mimetypes.guess_type(path)[0]
            if not mime or not mime.startswith("image/"):
                continue
            b64 = base64.b64encode(raw).decode()
            images.append({"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}"}})

        if not images:
            return merged_text or text
        return images + [{"type": "text", "text": merged_text or text}]

    def _collect_image_paths(self, media_ctx: list[dict[str, str]]) -> list[str]:
        paths: list[str] = []
        seen: set[str] = set()
        for item in media_ctx:
            path = item.get("path")
            if not path:
                continue
            mime = item.get("type")
            if mime and not mime.startswith("image/"):
                continue
            p = Path(path)
            if not p.is_file():
                continue
            key = str(p)
            if key in seen:
                continue
            if not mime and not (mimetypes.guess_type(key)[0] or "").startswith("image/"):
                continue
            seen.add(key)
            paths.append(key)
        return paths

    def _build_media_note(self, media_ctx: list[dict[str, str]]) -> str:
        if not media_ctx:
            return ""
        if len(media_ctx) == 1:
            item = media_ctx[0]
            return self._format_media_note_line(path=item["path"], url=item.get("url"), media_type=item.get("type"))
        lines = [f"[media attached: {len(media_ctx)} files]"]
        total = len(media_ctx)
        for idx, item in enumerate(media_ctx, start=1):
            lines.append(
                self._format_media_note_line(
                    path=item["path"],
                    url=item.get("url"),
                    media_type=item.get("type"),
                    index=idx,
                    total=total,
                )
            )
        return "\n".join(lines)

    def _normalize_media_context(
        self,
        *,
        media: list[str] | None,
        attachments: list[InboundAttachment] | None,
    ) -> list[dict[str, str]]:
        entries: list[dict[str, str]] = []

        for attachment in attachments or []:
            if not attachment.path and not attachment.url:
                continue
            entry: dict[str, str] = {"path": attachment.path or attachment.url or ""}
            if attachment.url:
                entry["url"] = attachment.url
            if attachment.mime_type:
                entry["type"] = attachment.mime_type
            entries.append(entry)

        if entries:
            return entries

        for item in media or []:
            if isinstance(item, str) and item.strip():
                entries.append({"path": item.strip()})
        return entries

    @staticmethod
    def _format_media_note_line(
        *,
        path: str,
        url: str | None = None,
        media_type: str | None = None,
        index: int | None = None,
        total: int | None = None,
    ) -> str:
        if index is not None and total is not None:
            prefix = f"[media attached {index}/{total}: "
        else:
            prefix = "[media attached: "
        type_part = f" ({media_type.strip()})" if media_type and media_type.strip() else ""
        url_part = f" | {url.strip()}" if url and url.strip() else ""
        return f"{prefix}{path}{type_part}{url_part}]"

    @staticmethod
    def _format_size(size: int) -> str:
        units = ["B", "KB", "MB", "GB"]
        value = float(size)
        for unit in units:
            if value < 1024 or unit == units[-1]:
                return f"{value:.0f} {unit}" if unit == "B" else f"{value:.1f} {unit}"
            value /= 1024
        return f"{size} B"

    def add_tool_result(
        self, messages: list[dict[str, Any]],
        tool_call_id: str, tool_name: str, result: str,
    ) -> list[dict[str, Any]]:
        """Add a tool result to the message list."""
        messages.append({"role": "tool", "tool_call_id": tool_call_id, "name": tool_name, "content": result})
        return messages

    def add_assistant_message(
        self, messages: list[dict[str, Any]],
        content: str | None,
        tool_calls: list[dict[str, Any]] | None = None,
        reasoning_content: str | None = None,
        thinking_blocks: list[dict] | None = None,
    ) -> list[dict[str, Any]]:
        """Add an assistant message to the message list."""
        msg: dict[str, Any] = {"role": "assistant", "content": content}
        if tool_calls:
            msg["tool_calls"] = tool_calls
        if reasoning_content is not None:
            msg["reasoning_content"] = reasoning_content
        if thinking_blocks:
            msg["thinking_blocks"] = thinking_blocks
        messages.append(msg)
        return messages
