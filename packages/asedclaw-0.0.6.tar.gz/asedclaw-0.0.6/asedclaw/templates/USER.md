# 用户画像

用于记录用户信息，以帮助个性化交互。

## 基本信息

- **姓名**：（你的名字）
- **时区**：（你的时区，例如 UTC+8）
- **语言**：（偏好语言）

## 偏好

### 沟通风格

- [ ] 随意
- [ ] 专业
- [ ] 技术向

### 回复长度

- [ ] 简短精炼
- [ ] 详细解释
- [ ] 根据问题自适应

### 技术水平

- [ ] 初学者
- [ ] 中级
- [ ] 专家

## 工作背景

- **主要角色**：（你的角色，例如开发者、研究员）
- **当前项目**：（你正在做的事情）
- **常用工具**：（IDE、语言、框架等）

## 感兴趣的话题

- 
- 
- 

## 特别说明

（关于助手行为的任何特殊要求）

---

# 核心环境契约 (Environment Contract)

- **操作系统**: Windows 11
- **默认 Shell**: PowerShell 7
- **执行规范**: 
    - 严禁直接使用 `bash`, `sh`, `grep`, `head`, `curl` 等 Linux 命令。
    - 所有系统操作必须通过 `powershell -Command` 进行包装。
    - 路径处理：必须使用双引号包裹含空格的路径，或使用单引号定义字符串。

# 软件管理规范 (SailWind 3.0)

- **根目录**: `C:\Paizi\SailWind 3.0\Programs`
- **启动规范**:
    - 命令格式: `powershell -Command "Start-Process 'C:\Paizi\SailWind 3.0\Programs\文件名.exe'"`
- **关闭规范**:
    - 命令格式: `powershell -Command "Stop-Process -Name '进程名' -Force"`
    - *注：进程名通常不含 .exe 后缀。*
- **已知组件清单**:
    - **逻辑模块**: 文件名 `SailWindLogic.exe` / 进程名 `SailWindLogic`
    - **PCB模块**: 文件名 `SailWindPCB.exe` / 进程名 `SailWindPCB`
    - **布线模块**: 文件名 `SailWindRouter.exe` / 进程名 `SailWindRouter`

*编辑此文件以按你的需要自定义 asedclaw 的行为。*
