"""Message bus module for decoupled channel-agent communication."""

from asedclaw.bus.events import InboundMessage, OutboundMessage
from asedclaw.bus.queue import MessageBus

__all__ = ["MessageBus", "InboundMessage", "OutboundMessage"]
