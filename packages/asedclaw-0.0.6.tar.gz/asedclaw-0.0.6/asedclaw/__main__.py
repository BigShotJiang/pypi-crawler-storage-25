"""
Entry point for running asedclaw as a module: python -m asedclaw
"""

from asedclaw.cli.commands import app

if __name__ == "__main__":
    app()
