"""
asedclaw - A lightweight AI agent framework
"""

__version__ = "0.0.6"
__logo__ = "🦞"