"""Custom provider backed by agno OpenAILike."""

from asedclaw.providers.agno_provider import AgnoOpenAILikeProvider


class CustomProvider(AgnoOpenAILikeProvider):
    """OpenAI-compatible custom endpoint via agno model wrapper."""

