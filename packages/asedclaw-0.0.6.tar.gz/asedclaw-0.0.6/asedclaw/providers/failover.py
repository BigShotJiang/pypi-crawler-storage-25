"""Provider failover chain: automatic retry and fallback across LLM providers.

When the primary provider fails, the chain tries fallback providers in order,
classifying errors as transient (retry after cooldown) or persistent (skip provider).
"""

from __future__ import annotations

import asyncio
import re
import time
from typing import Any, Literal

from loguru import logger

from asedclaw.observability.events import emit as _emit
from asedclaw.providers.base import LLMProvider, LLMResponse


class FailoverConfig:
    """Failover chain configuration (constructed from schema.FailoverConfig)."""

    __slots__ = (
        "enabled", "max_attempts", "cooldown_seconds",
        "probe_interval_seconds", "fallback_models",
    )

    def __init__(
        self,
        *,
        enabled: bool = True,
        max_attempts: int = 3,
        cooldown_seconds: int = 60,
        probe_interval_seconds: int = 30,
        fallback_models: list[str] | None = None,
    ):
        self.enabled = enabled
        self.max_attempts = max_attempts
        self.cooldown_seconds = cooldown_seconds
        self.probe_interval_seconds = probe_interval_seconds
        self.fallback_models = fallback_models or []


class FailoverChain:
    """Try primary provider, fall back to alternatives on failure.

    Each provider entry is a (LLMProvider, model_name) tuple.
    The chain tracks cooldowns per provider key and classifies errors
    to decide between retry, fallback, and abort.
    """

    def __init__(
        self,
        primary: LLMProvider,
        primary_model: str,
        fallbacks: list[tuple[LLMProvider, str]],
        config: FailoverConfig,
    ):
        self._providers: list[tuple[LLMProvider, str]] = [(primary, primary_model)] + list(fallbacks)
        self._config = config
        # provider_key → timestamp when cooldown expires
        self._cooldowns: dict[str, float] = {}
        # provider_key → timestamp of last probe attempt
        self._last_probe: dict[str, float] = {}
        # provider_key → persistent error flag (auth/billing failures)
        self._persistent_failures: dict[str, str] = {}

    # ── Public API ──────────────────────────────────────────────────

    async def call(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        *,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        reasoning_effort: str | None = None,
    ) -> tuple[LLMResponse, str]:
        """Try providers in order until one succeeds.

        Returns (response, actual_model_used).
        Raises the last error if all providers fail.
        """
        last_error: Exception | None = None
        attempts = 0

        for provider, model in self._providers:
            key = self._provider_key(provider, model)

            # Skip providers with persistent failures
            if key in self._persistent_failures:
                logger.debug(
                    "Skipping {} (persistent failure: {})",
                    key, self._persistent_failures[key],
                )
                continue

            # Skip providers in cooldown (unless probe interval elapsed)
            if self._is_in_cooldown(key):
                if not self._should_probe(key):
                    logger.debug("Skipping {} (in cooldown)", key)
                    continue
                logger.info("Probing {} after cooldown", key)
                self._last_probe[key] = time.monotonic()

            if attempts >= self._config.max_attempts:
                break

            attempts += 1
            try:
                logger.debug(
                    "Failover attempt {}/{}: provider={} model={}",
                    attempts, self._config.max_attempts, key, model,
                )
                response = await provider.chat(
                    messages, tools,
                    model=model,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    reasoning_effort=reasoning_effort,
                )
                # Success — clear any cooldown
                self._cooldowns.pop(key, None)
                self._last_probe.pop(key, None)
                if attempts > 1:
                    logger.info("Failover succeeded on attempt {} with {}", attempts, key)
                return response, model

            except Exception as exc:
                classification = self._classify_error(exc)
                logger.warning(
                    "Failover: {} failed (attempt {}, class={}): {}",
                    key, attempts, classification, exc,
                )
                _emit("failover.attempt", {
                    "provider": key, "model": model,
                    "error_type": classification, "attempt_number": attempts,
                })
                last_error = exc

                if classification == "persistent":
                    self._persistent_failures[key] = str(exc)[:200]
                elif classification == "transient":
                    self._enter_cooldown(key, self._config.cooldown_seconds)
                # "fatal" errors (context overflow) are re-raised immediately
                elif classification == "fatal":
                    raise

        if last_error is not None:
            raise last_error
        raise RuntimeError("No providers available for failover")

    # ── Error classification ────────────────────────────────────────

    @staticmethod
    def _classify_error(error: Exception) -> Literal["transient", "persistent", "fatal"]:
        """Classify an error to determine failover behavior.

        transient: rate limit, overload, timeout → cooldown then retry or try next
        persistent: auth, billing, model not found → skip provider entirely
        fatal: context overflow → don't retry, propagate immediately
        """
        msg = str(error).lower()
        error_type = type(error).__name__.lower()

        # Fatal: context overflow — cannot be solved by switching providers
        if any(kw in msg for kw in (
            "context_length_exceeded", "context length", "maximum context",
            "token limit", "too many tokens",
        )):
            return "fatal"

        # Persistent: auth, billing, model doesn't exist
        if any(kw in msg for kw in (
            "401", "403", "authentication", "unauthorized", "forbidden",
            "billing", "quota exceeded", "insufficient_quota",
            "model_not_found", "model not found", "does not exist",
            "invalid_api_key", "invalid api key",
        )):
            return "persistent"

        # Transient: rate limit
        if any(kw in msg for kw in (
            "429", "rate limit", "rate_limit", "too many requests",
            "tokens per min", "requests per min",
        )):
            return "transient"

        # Transient: server overload
        if any(kw in msg for kw in (
            "503", "502", "500", "overloaded", "server error",
            "internal error", "service unavailable", "bad gateway",
        )):
            return "transient"

        # Transient: network errors
        if any(kw in error_type for kw in (
            "timeout", "connection", "network",
        )) or any(kw in msg for kw in (
            "timeout", "timed out", "connection refused", "connection reset",
            "connect error", "network",
        )):
            return "transient"

        # Default: treat unknown errors as transient (try next provider)
        return "transient"

    # ── Cooldown management ─────────────────────────────────────────

    def _enter_cooldown(self, provider_key: str, duration: int) -> None:
        self._cooldowns[provider_key] = time.monotonic() + duration
        logger.info("Provider {} entering {}s cooldown", provider_key, duration)

    def _is_in_cooldown(self, provider_key: str) -> bool:
        expires = self._cooldowns.get(provider_key)
        if expires is None:
            return False
        if time.monotonic() >= expires:
            self._cooldowns.pop(provider_key)
            return False
        return True

    def _should_probe(self, provider_key: str) -> bool:
        last = self._last_probe.get(provider_key, 0.0)
        return (time.monotonic() - last) >= self._config.probe_interval_seconds

    # ── Helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _provider_key(provider: LLMProvider, model: str) -> str:
        return f"{type(provider).__name__}:{model}"

    @property
    def available_providers(self) -> list[str]:
        """List provider keys that are not persistently failed."""
        return [
            self._provider_key(p, m)
            for p, m in self._providers
            if self._provider_key(p, m) not in self._persistent_failures
        ]
