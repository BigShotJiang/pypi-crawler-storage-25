"""Agno-backed provider (keeps legacy class name for compatibility)."""

from asedclaw.providers.agno_provider import AgnoOpenAILikeProvider


class LiteLLMProvider(AgnoOpenAILikeProvider):
    """Compatibility alias for the generic agno-backed provider."""
