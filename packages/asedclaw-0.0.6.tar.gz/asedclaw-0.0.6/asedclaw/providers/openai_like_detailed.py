"""OpenAILike subclass: preserve full provider HTTP error bodies on ModelProviderError."""

from __future__ import annotations

import json
from collections.abc import AsyncIterator, Iterator
from dataclasses import dataclass
from typing import Any

from agno.exceptions import ModelProviderError
from agno.models.openai.like import OpenAILike

_DETAILS_MARK = "\n\n(details)\n"


def enrich_model_provider_error(exc: ModelProviderError) -> ModelProviderError:
    """If exc was caused by an HTTP API error, append JSON body to the message."""
    if _DETAILS_MARK in (exc.message or ""):
        return exc
    cause = exc.__cause__
    if cause is None:
        return exc
    response = getattr(cause, "response", None)
    if response is None:
        return exc
    try:
        body: Any = response.json()
    except Exception:
        body = getattr(response, "text", None) or str(cause)
    short = str(exc.message) if exc.message is not None else str(exc)
    detail: dict[str, Any] = {
        "message": short,
        "http_status": getattr(response, "status_code", None),
        "provider_error": body,
    }
    full_message = f"{short}{_DETAILS_MARK}{json.dumps(detail, ensure_ascii=False, indent=2)}"
    return ModelProviderError(
        message=full_message,
        status_code=getattr(exc, "status_code", 500),
        model_name=exc.model_name,
        model_id=exc.model_id,
    )


@dataclass
class OpenAILikeDetailed(OpenAILike):
    """Same as OpenAILike; re-raises ModelProviderError with raw provider JSON when available."""

    def invoke(self, *args: Any, **kwargs: Any):  # type: ignore[no-untyped-def]
        try:
            return super().invoke(*args, **kwargs)
        except ModelProviderError as e:
            enriched = enrich_model_provider_error(e)
            if enriched.message != e.message:
                raise enriched from e.__cause__
            raise

    async def ainvoke(self, *args: Any, **kwargs: Any):  # type: ignore[no-untyped-def]
        try:
            return await super().ainvoke(*args, **kwargs)
        except ModelProviderError as e:
            enriched = enrich_model_provider_error(e)
            if enriched.message != e.message:
                raise enriched from e.__cause__
            raise

    def invoke_stream(self, *args: Any, **kwargs: Any) -> Iterator[Any]:
        """Agno Agent uses streaming by default; errors must be enriched here too."""
        try:
            yield from super().invoke_stream(*args, **kwargs)
        except ModelProviderError as e:
            enriched = enrich_model_provider_error(e)
            if enriched.message != e.message:
                raise enriched from e.__cause__
            raise

    async def ainvoke_stream(self, *args: Any, **kwargs: Any) -> AsyncIterator[Any]:
        """Async streaming path used by Agent.arun(stream=True) — required for full error bodies."""
        try:
            async for chunk in super().ainvoke_stream(*args, **kwargs):
                yield chunk
        except ModelProviderError as e:
            enriched = enrich_model_provider_error(e)
            if enriched.message != e.message:
                raise enriched from e.__cause__
            raise
