"""OpenAI Codex provider backed by agno OpenAILike."""

from asedclaw.providers.agno_provider import AgnoOpenAILikeProvider


class OpenAICodexProvider(AgnoOpenAILikeProvider):
    """Codex model route via agno OpenAILike wrapper."""
