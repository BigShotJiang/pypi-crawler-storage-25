"""Azure OpenAI provider backed by agno OpenAILike."""

from asedclaw.providers.agno_provider import AgnoOpenAILikeProvider


class AzureOpenAIProvider(AgnoOpenAILikeProvider):
    """Azure endpoint via agno OpenAILike model wrapper."""