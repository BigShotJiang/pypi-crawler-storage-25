﻿"""Configuration schema using Pydantic."""

from enum import Enum
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel
from pydantic_settings import BaseSettings


class Base(BaseModel):
    """Base model that accepts both camelCase and snake_case keys."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)


class WhatsAppConfig(Base):
    """WhatsApp channel configuration."""

    enabled: bool = False
    bridge_url: str = "ws://localhost:3001"
    bridge_token: str = ""  # Shared token for bridge auth (optional, recommended)
    allow_from: list[str] = Field(default_factory=list)  # Allowed phone numbers


class TelegramConfig(Base):
    """Telegram channel configuration."""

    enabled: bool = False
    token: str = ""  # Bot token from @BotFather
    allow_from: list[str] = Field(default_factory=list)  # Allowed user IDs or usernames
    proxy: str | None = (
        None  # HTTP/SOCKS5 proxy URL, e.g. "http://127.0.0.1:7890" or "socks5://127.0.0.1:1080"
    )
    reply_to_message: bool = False  # If true, bot replies quote the original message


class FeishuConfig(Base):
    """Feishu/Lark channel configuration using WebSocket long connection."""

    enabled: bool = False
    app_id: str = ""  # App ID from Feishu Open Platform
    app_secret: str = ""  # App Secret from Feishu Open Platform
    encrypt_key: str = ""  # Encrypt Key for event subscription (optional)
    verification_token: str = ""  # Verification Token for event subscription (optional)
    allow_from: list[str] = Field(default_factory=list)  # Allowed user open_ids
    react_emoji: str = (
        "THUMBSUP"  # Emoji type for message reactions (e.g. THUMBSUP, OK, DONE, SMILE)
    )


class DingTalkConfig(Base):
    """DingTalk channel configuration using Stream mode."""

    enabled: bool = False
    client_id: str = ""  # AppKey
    client_secret: str = ""  # AppSecret
    allow_from: list[str] = Field(default_factory=list)  # Allowed staff_ids


class DiscordConfig(Base):
    """Discord channel configuration."""

    enabled: bool = False
    token: str = ""  # Bot token from Discord Developer Portal
    allow_from: list[str] = Field(default_factory=list)  # Allowed user IDs
    gateway_url: str = "wss://gateway.discord.gg/?v=10&encoding=json"
    intents: int = 37377  # GUILDS + GUILD_MESSAGES + DIRECT_MESSAGES + MESSAGE_CONTENT
    group_policy: Literal["mention", "open"] = "mention"


class MatrixConfig(Base):
    """Matrix (Element) channel configuration."""

    enabled: bool = False
    homeserver: str = "https://matrix.org"
    access_token: str = ""
    user_id: str = ""  # @bot:matrix.org
    device_id: str = ""
    e2ee_enabled: bool = True  # Enable Matrix E2EE support (encryption + encrypted room handling).
    sync_stop_grace_seconds: int = (
        2  # Max seconds to wait for sync_forever to stop gracefully before cancellation fallback.
    )
    max_media_bytes: int = (
        20 * 1024 * 1024
    )  # Max attachment size accepted for Matrix media handling (inbound + outbound).
    allow_from: list[str] = Field(default_factory=list)
    group_policy: Literal["open", "mention", "allowlist"] = "open"
    group_allow_from: list[str] = Field(default_factory=list)
    allow_room_mentions: bool = False


class EmailConfig(Base):
    """Email channel configuration (IMAP inbound + SMTP outbound)."""

    enabled: bool = False
    consent_granted: bool = False  # Explicit owner permission to access mailbox data

    # IMAP (receive)
    imap_host: str = ""
    imap_port: int = 993
    imap_username: str = ""
    imap_password: str = ""
    imap_mailbox: str = "INBOX"
    imap_use_ssl: bool = True

    # SMTP (send)
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_username: str = ""
    smtp_password: str = ""
    smtp_use_tls: bool = True
    smtp_use_ssl: bool = False
    from_address: str = ""

    # Behavior
    auto_reply_enabled: bool = (
        True  # If false, inbound email is read but no automatic reply is sent
    )
    poll_interval_seconds: int = 30
    mark_seen: bool = True
    max_body_chars: int = 12000
    subject_prefix: str = "Re: "
    allow_from: list[str] = Field(default_factory=list)  # Allowed sender email addresses


class MochatMentionConfig(Base):
    """Mochat mention behavior configuration."""

    require_in_groups: bool = False


class MochatGroupRule(Base):
    """Mochat per-group mention requirement."""

    require_mention: bool = False


class MochatConfig(Base):
    """Mochat channel configuration."""

    enabled: bool = False
    base_url: str = "https://mochat.io"
    socket_url: str = ""
    socket_path: str = "/socket.io"
    socket_disable_msgpack: bool = False
    socket_reconnect_delay_ms: int = 1000
    socket_max_reconnect_delay_ms: int = 10000
    socket_connect_timeout_ms: int = 10000
    refresh_interval_ms: int = 30000
    watch_timeout_ms: int = 25000
    watch_limit: int = 100
    retry_delay_ms: int = 500
    max_retry_attempts: int = 0  # 0 means unlimited retries
    claw_token: str = ""
    agent_user_id: str = ""
    sessions: list[str] = Field(default_factory=list)
    panels: list[str] = Field(default_factory=list)
    allow_from: list[str] = Field(default_factory=list)
    mention: MochatMentionConfig = Field(default_factory=MochatMentionConfig)
    groups: dict[str, MochatGroupRule] = Field(default_factory=dict)
    reply_delay_mode: str = "non-mention"  # off | non-mention
    reply_delay_ms: int = 120000


class SlackDMConfig(Base):
    """Slack DM policy configuration."""

    enabled: bool = True
    policy: str = "open"  # "open" or "allowlist"
    allow_from: list[str] = Field(default_factory=list)  # Allowed Slack user IDs


class SlackConfig(Base):
    """Slack channel configuration."""

    enabled: bool = False
    mode: str = "socket"  # "socket" supported
    webhook_path: str = "/slack/events"
    bot_token: str = ""  # xoxb-...
    app_token: str = ""  # xapp-...
    user_token_read_only: bool = True
    reply_in_thread: bool = True
    react_emoji: str = "eyes"
    allow_from: list[str] = Field(default_factory=list)  # Allowed Slack user IDs (sender-level)
    group_policy: str = "mention"  # "mention", "open", "allowlist"
    group_allow_from: list[str] = Field(default_factory=list)  # Allowed channel IDs if allowlist
    dm: SlackDMConfig = Field(default_factory=SlackDMConfig)


class QQConfig(Base):
    """QQ channel configuration using botpy SDK."""

    enabled: bool = False
    app_id: str = ""  # 鏈哄櫒浜?ID (AppID) from q.qq.com
    secret: str = ""  # 鏈哄櫒浜哄瘑閽?(AppSecret) from q.qq.com
    allow_from: list[str] = Field(
        default_factory=list
    )  # Allowed user openids (empty = public access)



class MatrixConfig(Base):
    """Matrix (Element) channel configuration."""
    enabled: bool = False
    homeserver: str = "https://matrix.org"
    access_token: str = ""
    user_id: str = ""                       # e.g. @bot:matrix.org
    device_id: str = ""
    e2ee_enabled: bool = True               # end-to-end encryption support
    sync_stop_grace_seconds: int = 2        # graceful sync_forever shutdown timeout
    max_media_bytes: int = 20 * 1024 * 1024 # inbound + outbound attachment limit
    allow_from: list[str] = Field(default_factory=list)
    group_policy: Literal["open", "mention", "allowlist"] = "open"
    group_allow_from: list[str] = Field(default_factory=list)
    allow_room_mentions: bool = False

    
class ImConfig(Base):
    """IM channel configuration - connects to SuperAgent IM via WebSocket long connection."""

    enabled: bool = False
    app_id: str = ""  # SuperAgent im_apps app_id
    app_secret: str = ""  # SuperAgent im_apps app_secret
    im_base_url: str = "https://superagent.example.com"  # SuperAgent base URL
    allow_from: list[str] = Field(default_factory=list)  # Empty = allow all user_ids; ["*"] = allow all
    # Application-level WebSocket keepalive (seconds). 0 = disable. Recommended: 15鈥?0s.
    ws_keepalive_interval_s: int = 20
    inbound_file_max_bytes: int = 10 * 1024 * 1024
    inbound_file_timeout_s: float = 20.0
    inbound_file_retention_hours: int = 72


class MessageQueueConfig(Base):
    """Busy-session message queue settings.

    Controls how incoming messages are handled when the agent is already
    processing a message for the same session.

    Modes:
        followup — queue and process one-by-one after current turn (default)
        collect  — batch queued messages into one combined prompt
        interrupt — cancel current task and process new message immediately
        queue    — simple FIFO (like followup, no debounce)
    """

    mode: str = "followup"
    debounce_ms: int = 1000  # debounce window for collect mode
    cap: int = 20  # max queued messages before drop policy kicks in
    drop_policy: str = "summarize"  # old | new | summarize


class ChannelsConfig(Base):
    """Configuration for chat channels."""

    # lenient: skip channels that fail init or have empty allowFrom; strict: exit on those errors
    startup_policy: Literal["lenient", "strict"] = "lenient"
    send_progress: bool = True  # stream agent's text progress to the channel
    send_tool_hints: bool = True  # stream tool-call hints (e.g. read_file("鈥?))
    message_queue: MessageQueueConfig = Field(default_factory=MessageQueueConfig)
    message_queue_by_channel: dict[str, MessageQueueConfig] = Field(default_factory=dict)
    whatsapp: WhatsAppConfig = Field(default_factory=WhatsAppConfig)
    telegram: TelegramConfig = Field(default_factory=TelegramConfig)
    discord: DiscordConfig = Field(default_factory=DiscordConfig)
    feishu: FeishuConfig = Field(default_factory=FeishuConfig)
    mochat: MochatConfig = Field(default_factory=MochatConfig)
    dingtalk: DingTalkConfig = Field(default_factory=DingTalkConfig)
    email: EmailConfig = Field(default_factory=EmailConfig)
    slack: SlackConfig = Field(default_factory=SlackConfig)
    qq: QQConfig = Field(default_factory=QQConfig)
    matrix: MatrixConfig = Field(default_factory=MatrixConfig)
    im: ImConfig = Field(default_factory=ImConfig)


class ContextBudgetConfig(Base):
    """Context window budget settings for the Context Engine."""

    context_window: int = 256_000  # model context window in tokens
    input_budget_ratio: float = 0.75  # max fraction of context window for input
    compact_chunk_ratio: float = 0.4  # fraction of messages per summary chunk
    compact_safety_margin: float = 0.2  # extra headroom after compaction
    summarization_overhead_tokens: int = 4096  # reserved tokens for summarization prompt
    max_compaction_summary_chars: int = 16_000  # hard limit on compaction summary size


class ToolResultBudgetConfig(Base):
    """Multi-layer tool result overflow protection settings."""

    single_result_share: float = 0.5  # L1: single result max share of context window
    total_result_share: float = 0.75  # L2: total results max share per round
    preemptive_ratio: float = 0.9  # L3: trigger preemptive compression at this ratio
    hard_max_tool_result_chars: int = 50_000  # absolute max chars per tool result
    maintain_old_tool_ratio: float = 0.2  # maintain stage: old tool result size = hard_max * this


class GuardrailsConfig(Base):
    """Round guardrails configuration."""

    max_same_error_retries: int = 3  # stop after N consecutive identical failures
    max_total_tool_calls: int = 40  # global tool call limit per round
    tool_budget: dict[str, int] = Field(default_factory=lambda: {
        "exec_command": 15,
        "write_file": 10,
        "read_file": 20,
        "memory_search": 5,
        "memory_get": 10,
        "web_search": 5,
        "web_fetch": 5,
        "message": 4,
        "send_file": 4,
        "spawn": 3,
        "cron": 5,
    })


class EmbeddingConfig(Base):
    """Embedding model configuration for memory vector search."""

    api_base: str = "http://10.0.18.252:19999"
    api_key: str = "no-key"  # placeholder for self-hosted services
    model: str = "jina-embeddings-v4"
    dimensions: int = 1024
    task: str = "retrieval"


class MemoryFlushConfig(Base):
    """Pre-compaction memory flush settings."""

    enabled: bool = True
    context_window: int = 256_000  # model context window in tokens
    reserve_tokens_floor: int = 8192  # tokens reserved for output
    soft_threshold_tokens: int = 4000  # flush when within this margin
    force_flush_transcript_bytes: int = 2 * 1024 * 1024  # 2 MB transcript force flush


class CompactionConfig(Base):
    """LLM-based session compaction settings."""

    enabled: bool = True
    # Context window size in tokens (should match ContextBudgetConfig.context_window)
    context_window: int = 256_000
    # Trigger when total tokens exceed this ratio of context window
    trigger_ratio: float = 0.85
    # How many recent turns to preserve verbatim (not summarized)
    recent_turns_preserve: int = 3
    # Max share of context window for history (post-compaction)
    max_history_share: float = 0.5
    # Chunk ratio: fraction of context window per summarization chunk
    chunk_ratio: float = 0.4
    # Safety margin multiplier for token estimation
    safety_margin: float = 1.2
    # Reserved tokens for the summarization prompt itself
    summarization_overhead_tokens: int = 4096
    # Max chars for the final summary output
    max_summary_chars: int = 16_000
    # Max chars per message content in summarization input
    summarize_input_max_chars: int = 2000
    # Max chars for post-compaction refresh sections
    post_compaction_refresh_max_chars: int = 3000
    # Identifier preservation policy: "strict" or "off"
    identifier_policy: str = "strict"
    # Quality guard: retry on missing required sections
    quality_retries: int = 2
    # Model override for compaction (None = use same model as agent)
    model: str | None = None
    # Post-compaction: AGENTS.md sections to re-inject
    post_compaction_sections: list[str] = Field(
        default_factory=lambda: ["Session Startup", "Red Lines"],
    )
    # Fallback to mechanical truncation if LLM compaction fails
    fallback_to_truncation: bool = True


class FailoverConfig(Base):
    """Provider failover chain configuration."""

    enabled: bool = True
    max_attempts: int = 3  # max total attempts across all providers
    cooldown_seconds: int = 60  # cooldown period after transient failure
    probe_interval_seconds: int = 30  # min interval between probes for cooled-down providers
    fallback_models: list[str] = Field(default_factory=list)  # fallback model names, e.g. ["gpt-4o", "claude-3-sonnet"]


class AgentDefaults(Base):
    """Default agent configuration."""

    workspace: str = "~/.asedclaw/workspace"
    model: str = "MiniMax-M2.5"
    provider: str = "custom"  # Provider name (e.g. "anthropic", "openrouter") or "auto" for auto-detection
    max_tokens: int = 8192
    temperature: float = 0.1
    max_tool_iterations: int = 40
    memory_window: int = 100
    reasoning_effort: str | None = "low"  # low / medium / high 鈥?enables LLM thinking mode
    memory_flush: MemoryFlushConfig = Field(default_factory=MemoryFlushConfig)
    compaction: CompactionConfig = Field(default_factory=CompactionConfig)
    embedding: EmbeddingConfig = Field(default_factory=EmbeddingConfig)
    guardrails: GuardrailsConfig = Field(default_factory=GuardrailsConfig)
    context_budget: ContextBudgetConfig = Field(default_factory=ContextBudgetConfig)
    tool_result_budget: ToolResultBudgetConfig = Field(default_factory=ToolResultBudgetConfig)
    failover: FailoverConfig = Field(default_factory=FailoverConfig)


class AgentsConfig(Base):
    """Agent configuration."""

    defaults: AgentDefaults = Field(default_factory=AgentDefaults)


class ProviderConfig(Base):
    """LLM provider configuration."""

    api_key: str = ""
    api_base: str | None = None
    extra_headers: dict[str, str] | None = None  # Custom headers (e.g. APP-Code for AiHubMix)


class ProvidersConfig(Base):
    """Configuration for LLM providers."""

    custom: ProviderConfig = Field(default_factory=ProviderConfig)  # Any OpenAI-compatible endpoint
    azure_openai: ProviderConfig = Field(default_factory=ProviderConfig)  # Azure OpenAI (model = deployment name)
    anthropic: ProviderConfig = Field(default_factory=ProviderConfig)
    openai: ProviderConfig = Field(default_factory=ProviderConfig)
    openrouter: ProviderConfig = Field(default_factory=ProviderConfig)
    deepseek: ProviderConfig = Field(default_factory=ProviderConfig)
    zhipu: ProviderConfig = Field(default_factory=ProviderConfig)
    dashscope: ProviderConfig = Field(default_factory=ProviderConfig)  # 闃块噷浜戦€氫箟鍗冮棶
    vllm: ProviderConfig = Field(default_factory=ProviderConfig)
    gemini: ProviderConfig = Field(default_factory=ProviderConfig)
    moonshot: ProviderConfig = Field(default_factory=ProviderConfig)
    minimax: ProviderConfig = Field(default_factory=ProviderConfig)
    siliconflow: ProviderConfig = Field(default_factory=ProviderConfig)
    volcengine: ProviderConfig = Field(default_factory=ProviderConfig)
    groq: ProviderConfig = Field(default_factory=ProviderConfig)  # Groq API (e.g. voice transcription)


class HeartbeatConfig(Base):
    """Heartbeat service configuration."""

    enabled: bool = True
    interval_s: int = 30 * 60  # 30 minutes


class GatewayConfig(Base):
    """Gateway/server configuration."""

    host: str = "0.0.0.0"
    port: int = 18790
    heartbeat: HeartbeatConfig = Field(default_factory=HeartbeatConfig)


class WebSearchConfig(Base):
    """Web search tool configuration."""

    api_key: str = ""  # Brave Search API key
    max_results: int = 5


class WebToolsConfig(Base):
    """Web tools configuration."""

    proxy: str | None = (
        None  # HTTP/SOCKS5 proxy URL, e.g. "http://127.0.0.1:7890" or "socks5://127.0.0.1:1080"
    )
    search: WebSearchConfig = Field(default_factory=WebSearchConfig)


class ExecSecurityLevel(str, Enum):
    DENY = "deny"
    ALLOWLIST = "allowlist"
    FULL = "full"


class FileSecurityLevel(str, Enum):
    OFF = "off"
    WARN = "warn"
    BLOCK = "block"
    APPROVAL = "approval"


class RuleAction(str, Enum):
    ALLOW = "allow"
    DENY = "deny"
    APPROVAL = "approval"


class RuleScope(str, Enum):
    GLOBAL = "global"
    CHANNEL = "channel"
    USER = "user"
    AGENT = "agent"


class ApprovalConfig(Base):
    """Approval flow configuration."""

    enabled: bool = True
    timeout_seconds: int = 180
    allow_requester_only: bool = True
    admin_approvers: list[str] = Field(default_factory=list)
    max_pending_per_session: int = 1
    expose_to_superagent_im: bool = True
    require_authenticated_im_user: bool = True
    superagent_decision_audit: bool = True
    superagent_bridge_base_url: str = ""
    superagent_push_timeout_seconds: int = 10


class ExecPolicyConfig(Base):
    """Shell execution policy configuration."""

    default_level: ExecSecurityLevel = ExecSecurityLevel.ALLOWLIST
    channel_overrides: dict[str, ExecSecurityLevel] = Field(default_factory=dict)
    user_overrides: dict[str, ExecSecurityLevel] = Field(default_factory=dict)
    agent_overrides: dict[str, ExecSecurityLevel] = Field(default_factory=dict)


class FilePolicyConfig(Base):
    """File write policy configuration."""

    default_level: FileSecurityLevel = FileSecurityLevel.APPROVAL
    channel_overrides: dict[str, FileSecurityLevel] = Field(default_factory=dict)
    user_overrides: dict[str, FileSecurityLevel] = Field(default_factory=dict)
    agent_overrides: dict[str, FileSecurityLevel] = Field(default_factory=dict)


class RuleEngineConfig(Base):
    """Rule engine persistence configuration."""

    static_rules_path: str = "~/.asedclaw/security_rules.yaml"
    dynamic_rules_path: str = "~/.asedclaw/dynamic_rules.json"
    audit_log_path: str = "~/.asedclaw/security_audit.jsonl"


class ExecToolConfig(Base):
    """Shell exec tool configuration."""

    timeout: int = 120
    path_append: str = ""
    approval_timeout: int = 300
    approval_required_patterns: list[str] = Field(
        default_factory=lambda: [
            r"\brm\b(?:\s+-(?:[^\n]*[rf]|[^\n]*f[^\n]*r)[a-z]*)?",
            r'\bdel\b(?:\s+/[a-z]+)*\s+(?:"[^"]+"|\'[^\']+\'|\S+)',
            r'\berase\b(?:\s+/[a-z]+)*\s+(?:"[^"]+"|\'[^\']+\'|\S+)',
            r"\brmdir\b(?:\s+/[a-z]+)*\b",
            r"(?:^|[;&|]\s*)format\b",
            r"\b(mkfs|diskpart|fdisk|parted)\b",
            r"\bdd\s+(?:if|of)=",
            r">\s*/dev/sd[a-z]\d*",
            r"\b(chmod|chown)\s+(?:-[^\s]+\s+)?(?:777|000)\b",
            r"\b(takeown|icacls)\b",
            r"\b(reg\s+(?:add|delete)|sc\s+(?:config|delete)|netsh\b)\b",
            r"\b(shutdown|reboot|poweroff|halt|init\s+0|init\s+6)\b",
            r"\b(kill|pkill|taskkill)\b(?:\s+[^\n]*)?(?:\s+-9\b|\s+/f\b)",
        ]
    )


class MCPServerConfig(Base):
    """MCP server connection configuration (stdio or HTTP)."""

    type: Literal["stdio", "sse", "streamableHttp"] | None = None  # auto-detected if omitted
    command: str = ""  # Stdio: command to run (e.g. "npx")
    args: list[str] = Field(default_factory=list)  # Stdio: command arguments
    env: dict[str, str] = Field(default_factory=dict)  # Stdio: extra env vars
    url: str = ""  # HTTP/SSE: endpoint URL
    headers: dict[str, str] = Field(default_factory=dict)  # HTTP/SSE: custom headers
    tool_timeout: int = 30  # seconds before a tool call is cancelled


class MediaConfig(Base):
    """Media file delivery configuration."""

    staged_ttl_seconds: int = Field(default=300, ge=60)
    auto_media: bool = True
    extra_allowed_dirs: list[str] = Field(default_factory=list)
    trusted_tools: list[str] = Field(
        default_factory=lambda: ["exec", "write_file", "edit_file", "web_fetch", "message"]
    )


class ToolsConfig(Base):
    """Tools configuration."""

    web: WebToolsConfig = Field(default_factory=WebToolsConfig)
    exec: ExecToolConfig = Field(default_factory=ExecToolConfig)
    approval: ApprovalConfig = Field(default_factory=ApprovalConfig)
    exec_policy: ExecPolicyConfig = Field(default_factory=ExecPolicyConfig)
    file_policy: FilePolicyConfig = Field(default_factory=FilePolicyConfig)
    rule_engine: RuleEngineConfig = Field(default_factory=RuleEngineConfig)
    media: MediaConfig = Field(default_factory=MediaConfig)
    restrict_to_workspace: bool = False  # If true, restrict all tool access to workspace directory
    mcp_servers: dict[str, MCPServerConfig] = Field(default_factory=dict)


class Config(BaseSettings):
    """Root configuration for asedclaw."""

    agents: AgentsConfig = Field(default_factory=AgentsConfig)
    channels: ChannelsConfig = Field(default_factory=ChannelsConfig)
    providers: ProvidersConfig = Field(default_factory=ProvidersConfig)
    gateway: GatewayConfig = Field(default_factory=GatewayConfig)
    tools: ToolsConfig = Field(default_factory=ToolsConfig)

    @property
    def workspace_path(self) -> Path:
        """Get expanded workspace path."""
        return Path(self.agents.defaults.workspace).expanduser()

    def _match_provider(
        self, model: str | None = None
    ) -> tuple["ProviderConfig | None", str | None]:
        """Match provider config and its registry name. Returns (config, spec_name)."""
        from asedclaw.providers.registry import PROVIDERS

        forced = self.agents.defaults.provider
        if forced != "auto":
            p = getattr(self.providers, forced, None)
            return (p, forced) if p else (None, None)

        model_lower = (model or self.agents.defaults.model).lower()
        model_normalized = model_lower.replace("-", "_")
        model_prefix = model_lower.split("/", 1)[0] if "/" in model_lower else ""
        normalized_prefix = model_prefix.replace("-", "_")

        def _kw_matches(kw: str) -> bool:
            kw = kw.lower()
            return kw in model_lower or kw.replace("-", "_") in model_normalized

        for spec in PROVIDERS:
            p = getattr(self.providers, spec.name, None)
            if p and model_prefix and normalized_prefix == spec.name:
                if spec.is_oauth or p.api_key:
                    return p, spec.name

        # Match by keyword (order follows PROVIDERS registry)
        for spec in PROVIDERS:
            p = getattr(self.providers, spec.name, None)
            if p and any(_kw_matches(kw) for kw in spec.keywords):
                if spec.is_oauth or p.api_key:
                    return p, spec.name

        # Fallback: gateways first, then others (follows registry order)
        # OAuth providers are NOT valid fallbacks 鈥?they require explicit model selection
        for spec in PROVIDERS:
            if spec.is_oauth:
                continue
            p = getattr(self.providers, spec.name, None)
            if p and p.api_key:
                return p, spec.name
        return None, None

    def get_provider(self, model: str | None = None) -> ProviderConfig | None:
        """Get matched provider config (api_key, api_base, extra_headers). Falls back to first available."""
        p, _ = self._match_provider(model)
        return p

    def get_provider_name(self, model: str | None = None) -> str | None:
        """Get the registry name of the matched provider (e.g. "deepseek", "openrouter")."""
        _, name = self._match_provider(model)
        return name

    def get_api_key(self, model: str | None = None) -> str | None:
        """Get API key for the given model. Falls back to first available key."""
        p = self.get_provider(model)
        return p.api_key if p else None

    def get_api_base(self, model: str | None = None) -> str | None:
        """Get API base URL for the given model. Applies default URLs for known gateways."""
        from asedclaw.providers.registry import find_by_name

        p, name = self._match_provider(model)
        if p and p.api_base:
            return p.api_base
        # Only gateways get a default api_base here. Standard providers
        # (like Moonshot) set their base URL via env vars in _setup_env
        # to avoid polluting the global litellm.api_base.
        if name:
            spec = find_by_name(name)
            if spec and spec.is_gateway and spec.default_api_base:
                return spec.default_api_base
        return None

    model_config = ConfigDict(env_prefix="ASEDCLAW_", env_nested_delimiter="__")
