"""Media handling: parsing, validation, dedup, MIME detection, and staging."""
