use super::check_column_exists;
use super::check_table_exists;
use crate::db::clickhouse::ClickHouseConnectionInfo;
use crate::db::clickhouse::migration_manager::migration_trait::Migration;
use crate::error::{Error, ErrorDetails};
use async_trait::async_trait;

use super::ViewOffsetDeadline;
use super::migration_0037::quantiles_sql_args;

/// Adds a dedicated `count_with_cost` column to `ModelProviderStatistics` so that
/// cost-presence is tracked per-inference rather than per-(model, provider, minute)
/// bucket. Previously, if *any* inference in a bucket had a non-null cost, *all*
/// inferences in that bucket were counted in `count_with_cost`. With the new column
/// (`countState(cost)`), only inferences with a non-null cost value are counted.
///
/// See #6574.
pub struct Migration0052<'a> {
    pub clickhouse: &'a ClickHouseConnectionInfo,
}

const MIGRATION_ID: &str = "0052";

#[async_trait]
impl Migration for Migration0052<'_> {
    async fn can_apply(&self) -> Result<(), Error> {
        if !check_table_exists(self.clickhouse, "ModelProviderStatistics", MIGRATION_ID).await? {
            return Err(Error::new(ErrorDetails::ClickHouseMigration {
                id: MIGRATION_ID.to_string(),
                message: "ModelProviderStatistics table does not exist".to_string(),
            }));
        }
        Ok(())
    }

    async fn should_apply(&self) -> Result<bool, Error> {
        Ok(!check_column_exists(
            self.clickhouse,
            "ModelProviderStatistics",
            "count_with_cost",
            MIGRATION_ID,
        )
        .await?)
    }

    async fn apply(&self, clean_start: bool) -> Result<(), Error> {
        let qs = quantiles_sql_args();
        let on_cluster_name = self.clickhouse.get_on_cluster_name();

        // 1. Add the count_with_cost column
        self.clickhouse
            .run_query_synchronous_no_params(format!(
                "ALTER TABLE ModelProviderStatistics{on_cluster_name} ADD COLUMN IF NOT EXISTS count_with_cost AggregateFunction(count, Nullable(Decimal(18, 9)))"
            ))
            .await?;

        // 2. Record timestamp T (now + offset)
        let view_deadline = ViewOffsetDeadline::new();
        let view_timestamp_nanos = (std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_err(|e| {
                Error::new(ErrorDetails::ClickHouseMigration {
                    id: MIGRATION_ID.to_string(),
                    message: e.to_string(),
                })
            })?
            + ViewOffsetDeadline::offset())
        .as_nanos();

        // 3. Drop the existing MV
        self.clickhouse
            .run_query_synchronous_no_params(format!(
                "DROP TABLE IF EXISTS ModelProviderStatisticsView{on_cluster_name} SYNC"
            ))
            .await?;

        // 4. Recreate the MV with the new count_with_cost column
        let view_where_clause = if clean_start {
            String::new()
        } else {
            format!("WHERE UUIDv7ToDateTime(id) >= fromUnixTimestamp64Nano({view_timestamp_nanos})")
        };

        let query = format!(
            r"
            CREATE MATERIALIZED VIEW IF NOT EXISTS ModelProviderStatisticsView{on_cluster_name}
            TO ModelProviderStatistics
            AS
            SELECT
                model_name,
                model_provider_name,
                toStartOfMinute(timestamp) as minute,
                quantilesTDigestState({qs})(response_time_ms) as response_time_ms_quantiles,
                quantilesTDigestState({qs})(ttft_ms) as ttft_ms_quantiles,
                sumState(input_tokens) as total_input_tokens,
                sumState(output_tokens) as total_output_tokens,
                countState() as count,
                sumState(cost) as total_cost,
                sumState(provider_cache_read_input_tokens) as total_provider_cache_read_input_tokens,
                sumState(provider_cache_write_input_tokens) as total_provider_cache_write_input_tokens,
                countState(cost) as count_with_cost
            FROM ModelInference
            {view_where_clause}
            GROUP BY model_name, model_provider_name, minute
            "
        );
        self.clickhouse
            .run_query_synchronous_no_params(query)
            .await?;

        // 5. Backfill if needed
        if !clean_start {
            view_deadline.wait().await;

            let create_table = self
                .clickhouse
                .run_query_synchronous_no_params(
                    "SHOW CREATE TABLE ModelProviderStatisticsView".to_string(),
                )
                .await?
                .response;

            let view_timestamp_nanos_string = view_timestamp_nanos.to_string();
            if !create_table.contains(&view_timestamp_nanos_string) {
                tracing::warn!(
                    "Materialized view `ModelProviderStatisticsView` was not written because it was recently created. This is likely due to a concurrent migration. Unless the other migration failed, no action is required."
                );
                return Ok(());
            }

            // Only backfill the new `count_with_cost` column. The other columns were
            // already aggregated by previous migrations. Inserting only `count_with_cost`
            // lets AggregatingMergeTree merge the new partial row with the existing one.
            tracing::info!("Running backfill of `ModelProviderStatistics` for `count_with_cost`");
            let query = format!(
                r"
                INSERT INTO ModelProviderStatistics
                    (model_name, model_provider_name, minute, count_with_cost)
                SELECT
                    model_name,
                    model_provider_name,
                    toStartOfMinute(timestamp) as minute,
                    countState(cost) as count_with_cost
                FROM ModelInference
                WHERE UUIDv7ToDateTime(id) < fromUnixTimestamp64Nano({view_timestamp_nanos})
                GROUP BY model_name, model_provider_name, minute
                "
            );
            self.clickhouse
                .run_query_synchronous_no_params(query)
                .await?;
        }

        Ok(())
    }

    fn rollback_instructions(&self) -> String {
        let qs = quantiles_sql_args();
        let on_cluster_name = self.clickhouse.get_on_cluster_name();
        format!(
            r"
            DROP TABLE IF EXISTS ModelProviderStatisticsView{on_cluster_name} SYNC;
            ALTER TABLE ModelProviderStatistics{on_cluster_name} DROP COLUMN count_with_cost;
            CREATE MATERIALIZED VIEW IF NOT EXISTS ModelProviderStatisticsView{on_cluster_name} TO ModelProviderStatistics AS SELECT model_name, model_provider_name, toStartOfMinute(timestamp) as minute, quantilesTDigestState({qs})(response_time_ms) as response_time_ms_quantiles, quantilesTDigestState({qs})(ttft_ms) as ttft_ms_quantiles, sumState(input_tokens) as total_input_tokens, sumState(output_tokens) as total_output_tokens, countState() as count, sumState(cost) as total_cost, sumState(provider_cache_read_input_tokens) as total_provider_cache_read_input_tokens, sumState(provider_cache_write_input_tokens) as total_provider_cache_write_input_tokens FROM ModelInference GROUP BY model_name, model_provider_name, minute;"
        )
    }

    async fn has_succeeded(&self) -> Result<bool, Error> {
        Ok(check_column_exists(
            self.clickhouse,
            "ModelProviderStatistics",
            "count_with_cost",
            MIGRATION_ID,
        )
        .await?)
    }
}
