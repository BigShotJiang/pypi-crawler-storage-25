use futures::StreamExt;
use futures::future::try_join_all;
use lazy_static::lazy_static;
use mime::MediaType;
use reqwest::StatusCode;
use reqwest_sse_stream::Event;
use secrecy::{ExposeSecret, SecretString};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::borrow::Cow;
use std::collections::HashMap;
use std::time::Duration;
use tensorzero_derive::TensorZeroDeserialize;
use tokio::time::Instant;
use url::Url;

use crate::cache::ModelProviderRequest;
use crate::endpoints::inference::InferenceCredentials;
use crate::error::{
    DelayedError, DisplayOrDebugGateway, Error, ErrorDetails, warn_discarded_unknown_chunk,
};
use crate::http::{TensorZeroEventSource, TensorzeroHttpClient};
use crate::inference::InferenceProvider;
use crate::inference::types::ProviderInferenceResponseArgs;
use crate::inference::types::batch::BatchRequestRow;
use crate::inference::types::batch::PollBatchInferenceResponse;
use crate::inference::types::chat_completion_inference_params::{
    ChatCompletionInferenceParamsV2, ServiceTier, warn_inference_parameter_not_supported,
};
use crate::inference::types::resolved_input::{FileUrl, LazyFile, LazyFileExt};
use crate::inference::types::usage::raw_usage_entries_from_value;
use crate::inference::types::{
    ApiType, ContentBlockOutput, FlattenUnknown, ModelInferenceRequest,
    PeekableProviderInferenceResponseStream, ProviderInferenceResponse,
    ProviderInferenceResponseChunk, ProviderInferenceResponseStreamInner, RequestMessage,
    TextChunk, Thought, ThoughtChunk, UnknownChunk, Usage,
};
use crate::inference::types::{
    ContentBlock, ContentBlockChunk, FinishReason, FunctionType, Latency,
    ModelInferenceRequestJsonMode, ObjectStorageFile, Role, Text, Unknown,
    batch::StartBatchProviderInferenceResponse,
};
use crate::model::{Credential, ModelProvider};
use crate::providers::helpers::{
    inject_extra_request_data_and_send, inject_extra_request_data_and_send_eventsource,
};
use crate::tool::{FunctionToolConfig, ToolCall, ToolCallChunk, ToolCallConfig, ToolChoice};
use crate::utils::deprecation_warning;
use uuid::Uuid;

use super::helpers::convert_stream_error;
use super::helpers::{peek_first_chunk, warn_cannot_forward_url_if_missing_mime_type};

lazy_static! {
    static ref ANTHROPIC_DEFAULT_BASE_URL: Url = {
        #[expect(clippy::expect_used)]
        Url::parse("https://api.anthropic.com/v1/")
            .expect("Failed to parse ANTHROPIC_DEFAULT_BASE_URL")
    };
}
const ANTHROPIC_API_VERSION: &str = "2023-06-01";
const PROVIDER_NAME: &str = "Anthropic";
pub const PROVIDER_TYPE: &str = "anthropic";

/// Checks if the api_base ends with `/messages` and warns if it does.
/// This mirrors the OpenAI pattern in `check_api_base_suffix`.
fn check_api_base_suffix(api_base: &Url) {
    let path = api_base.path();
    if path.ends_with("/messages") || path.ends_with("/messages/") {
        // IMPORTANT: After the deprecation period, we should still keep `check_api_base_suffix` but change the warning message.
        // See OpenAI's `check_api_base_suffix` for more details.
        // Deprecation #5668: https://github.com/tensorzero/tensorzero/issues/5668
        deprecation_warning(&format!(
            "The gateway automatically appends `/messages` to the `api_base`. \
            You provided `{api_base}` which includes the `/messages` suffix. \
            Please remove the `/messages` suffix from `api_base`. \
            The suffix will be stripped automatically for now, but this behavior \
            may be removed in a future release."
        ));
    }
}

/// Normalizes an api_base by stripping the `/messages` suffix if present.
/// Returns the normalized URL.
fn normalize_api_base(mut api_base: Url) -> Url {
    let path = api_base.path().to_string();
    if path.ends_with("/messages") {
        let new_path = &path[..path.len() - "/messages".len()];
        // Ensure trailing slash
        let new_path = if new_path.ends_with('/') {
            new_path.to_string()
        } else {
            format!("{new_path}/")
        };
        api_base.set_path(&new_path);
        api_base
    } else if path.ends_with("/messages/") {
        let new_path = &path[..path.len() - "/messages/".len()];
        // Ensure trailing slash
        let new_path = if new_path.ends_with('/') {
            new_path.to_string()
        } else {
            format!("{new_path}/")
        };
        api_base.set_path(&new_path);
        api_base
    } else {
        api_base
    }
}

/// Constructs the messages URL by appending `/messages` to the base URL.
/// This mirrors the OpenAI pattern in `get_chat_url`.
fn get_messages_url(base_url: &Url) -> Result<Url, Error> {
    let mut url = base_url.clone();
    if !url.path().ends_with('/') {
        url.set_path(&format!("{}/", url.path()));
    }
    url.join("messages").map_err(|e| {
        Error::new(ErrorDetails::InvalidBaseUrl {
            message: e.to_string(),
        })
    })
}

#[cfg_attr(feature = "ts-bindings", derive(ts_rs::TS))]
#[derive(Debug, Serialize)]
#[cfg_attr(feature = "ts-bindings", ts(export))]
pub struct AnthropicProvider {
    model_name: String,
    api_base: Option<Url>,
    #[serde(skip)]
    credentials: AnthropicCredentials,
    provider_tools: Vec<Value>,
}

impl AnthropicProvider {
    pub fn new(
        model_name: String,
        api_base: Option<Url>,
        credentials: AnthropicCredentials,
        provider_tools: Vec<Value>,
    ) -> Self {
        // Check and normalize api_base if provided
        let normalized_api_base = api_base.map(|url| {
            check_api_base_suffix(&url);
            normalize_api_base(url)
        });

        AnthropicProvider {
            model_name,
            api_base: normalized_api_base,
            credentials,
            provider_tools,
        }
    }

    pub fn model_name(&self) -> &str {
        &self.model_name
    }

    pub fn provider_tools(&self) -> &[Value] {
        &self.provider_tools
    }

    fn base_url(&self) -> &Url {
        self.api_base
            .as_ref()
            .unwrap_or(&ANTHROPIC_DEFAULT_BASE_URL)
    }

    fn messages_url(&self) -> Result<Url, Error> {
        get_messages_url(self.base_url())
    }
}

#[derive(Clone, Debug, Deserialize)]
pub enum AnthropicCredentials {
    Static(SecretString),
    Dynamic(String),
    None,
    WithFallback {
        default: Box<AnthropicCredentials>,
        fallback: Box<AnthropicCredentials>,
    },
}

impl TryFrom<Credential> for AnthropicCredentials {
    type Error = Error;

    fn try_from(credentials: Credential) -> Result<Self, Error> {
        match credentials {
            Credential::Static(key) => Ok(AnthropicCredentials::Static(key)),
            Credential::Dynamic(key_name) => Ok(AnthropicCredentials::Dynamic(key_name)),
            Credential::Missing => Ok(AnthropicCredentials::None),
            Credential::WithFallback { default, fallback } => {
                Ok(AnthropicCredentials::WithFallback {
                    default: Box::new((*default).try_into()?),
                    fallback: Box::new((*fallback).try_into()?),
                })
            }
            _ => Err(Error::new(ErrorDetails::Config {
                message: "Invalid api_key_location for Anthropic provider".to_string(),
            })),
        }
    }
}

impl AnthropicCredentials {
    fn get_api_key<'a>(
        &'a self,
        dynamic_api_keys: &'a InferenceCredentials,
    ) -> Result<&'a SecretString, DelayedError> {
        match self {
            AnthropicCredentials::Static(api_key) => Ok(api_key),
            AnthropicCredentials::Dynamic(key_name) => {
                dynamic_api_keys.get(key_name).ok_or_else(|| {
                    DelayedError::new(ErrorDetails::ApiKeyMissing {
                        provider_name: PROVIDER_NAME.to_string(),
                        message: format!("Dynamic api key `{key_name}` is missing"),
                    })
                })
            }
            AnthropicCredentials::WithFallback { default, fallback } => {
                // Try default first, fall back to fallback if it fails
                match default.get_api_key(dynamic_api_keys) {
                    Ok(key) => Ok(key),
                    Err(e) => {
                        e.log_at_level(
                            "Using fallback credential, as default credential is unavailable: ",
                            tracing::Level::WARN,
                        );
                        fallback.get_api_key(dynamic_api_keys)
                    }
                }
            }
            AnthropicCredentials::None => Err(DelayedError::new(ErrorDetails::ApiKeyMissing {
                provider_name: PROVIDER_NAME.to_string(),
                message: "No credentials are set".to_string(),
            })),
        }
    }
}

/// Collects all provider tools (static from config + dynamic scoped from request).
pub(super) fn collect_all_provider_tools(
    static_tools: &[Value],
    request: &ModelInferenceRequest<'_>,
    model_name: &str,
    provider_name: &str,
) -> Vec<Value> {
    let mut all_tools: Vec<Value> = static_tools.to_vec();
    if let Some(tc) = request.tool_config.as_deref() {
        all_tools.extend(
            tc.get_scoped_provider_tools(model_name, provider_name)
                .into_iter()
                .map(|pt| pt.tool.clone()),
        );
    }
    all_tools
}

impl InferenceProvider for AnthropicProvider {
    /// Anthropic non-streaming API request
    async fn infer<'a>(
        &'a self,
        ModelProviderRequest {
            request,
            provider_name,
            model_name,
            otlp_config: _,
            model_inference_id,
        }: ModelProviderRequest<'a>,
        http_client: &'a TensorzeroHttpClient,
        dynamic_api_keys: &'a InferenceCredentials,
        model_provider: &'a ModelProvider,
    ) -> Result<ProviderInferenceResponse, Error> {
        let all_provider_tools =
            collect_all_provider_tools(&self.provider_tools, request, model_name, provider_name);
        let request_body = serde_json::to_value(
            AnthropicRequestBody::new(&self.model_name, request, &all_provider_tools).await?,
        )
        .map_err(|e| {
            Error::new(ErrorDetails::Serialization {
                message: format!(
                    "Error serializing Anthropic request: {}",
                    DisplayOrDebugGateway::new(e)
                ),
            })
        })?;
        let api_key = self
            .credentials
            .get_api_key(dynamic_api_keys)
            .map_err(|e| e.log())?;
        let start_time = Instant::now();
        let request_url = self.messages_url()?;
        let builder = http_client
            .post(request_url.as_ref())
            .header("anthropic-version", ANTHROPIC_API_VERSION)
            .header("x-api-key", api_key.expose_secret());

        let (res, raw_request) = inject_extra_request_data_and_send(
            PROVIDER_TYPE,
            ApiType::ChatCompletions,
            &request.extra_body,
            &request.extra_headers,
            model_provider,
            model_name,
            request_body,
            builder,
        )
        .await?;
        let latency = Latency::NonStreaming {
            response_time: start_time.elapsed(),
        };
        if res.status().is_success() {
            let raw_response = res.text().await.map_err(|e| {
                Error::new(ErrorDetails::InferenceServer {
                    message: format!(
                        "Error parsing text response: {}",
                        DisplayOrDebugGateway::new(e)
                    ),
                    provider_type: PROVIDER_TYPE.to_string(),
                    api_type: ApiType::ChatCompletions,
                    raw_request: Some(raw_request.clone()),
                    raw_response: None,
                })
            })?;

            let response = serde_json::from_str(&raw_response).map_err(|e| {
                Error::new(ErrorDetails::InferenceServer {
                    message: format!(
                        "Error parsing JSON response: {}: {raw_response}",
                        DisplayOrDebugGateway::new(e)
                    ),
                    provider_type: PROVIDER_TYPE.to_string(),
                    api_type: ApiType::ChatCompletions,
                    raw_request: Some(raw_request.clone()),
                    raw_response: Some(raw_response.clone()),
                })
            })?;

            let response_with_latency = AnthropicResponseWithMetadata {
                response,
                latency,
                raw_request,
                generic_request: request,
                input_messages: request.messages.clone(),
                raw_response,
                model_name,
                provider_name: &model_provider.name,
                model_inference_id,
            };
            Ok(response_with_latency.try_into()?)
        } else {
            let response_code = res.status();
            let response_text = res.text().await.map_err(|e| {
                Error::new(ErrorDetails::InferenceServer {
                    message: format!("Error fetching response: {}", DisplayOrDebugGateway::new(e)),
                    provider_type: PROVIDER_TYPE.to_string(),
                    api_type: ApiType::ChatCompletions,
                    raw_request: Some(raw_request.clone()),
                    raw_response: None,
                })
            })?;
            handle_anthropic_error(
                response_code,
                raw_request,
                response_text,
                ApiType::ChatCompletions,
            )
        }
    }

    /// Anthropic streaming API request
    async fn infer_stream<'a>(
        &'a self,
        ModelProviderRequest {
            request,
            provider_name,
            model_name,
            otlp_config: _,
            model_inference_id,
        }: ModelProviderRequest<'a>,
        http_client: &'a TensorzeroHttpClient,
        api_key: &'a InferenceCredentials,
        model_provider: &'a ModelProvider,
    ) -> Result<(PeekableProviderInferenceResponseStream, String), Error> {
        let all_provider_tools =
            collect_all_provider_tools(&self.provider_tools, request, model_name, provider_name);
        let request_body = serde_json::to_value(
            AnthropicRequestBody::new(&self.model_name, request, &all_provider_tools).await?,
        )
        .map_err(|e| {
            Error::new(ErrorDetails::Serialization {
                message: format!(
                    "Error serializing Anthropic request: {}",
                    DisplayOrDebugGateway::new(e)
                ),
            })
        })?;
        let start_time = Instant::now();
        let api_key = self.credentials.get_api_key(api_key).map_err(|e| e.log())?;
        let request_url = self.messages_url()?;
        let builder = http_client
            .post(request_url.as_ref())
            .header("anthropic-version", ANTHROPIC_API_VERSION)
            .header("x-api-key", api_key.expose_secret());

        let (event_source, raw_request) = inject_extra_request_data_and_send_eventsource(
            PROVIDER_TYPE,
            ApiType::ChatCompletions,
            &request.extra_body,
            &request.extra_headers,
            model_provider,
            model_name,
            request_body,
            builder,
        )
        .await?;
        let mut stream = stream_anthropic(
            event_source,
            start_time,
            model_provider,
            model_name,
            provider_name,
            &raw_request,
            model_inference_id,
        )
        .peekable();
        let chunk = peek_first_chunk(
            &mut stream,
            &raw_request,
            PROVIDER_TYPE,
            ApiType::ChatCompletions,
        )
        .await?;
        if needs_json_prefill(request) {
            prefill_json_chunk_response(chunk);
        }
        Ok((stream, raw_request))
    }

    async fn start_batch_inference<'a>(
        &'a self,
        _requests: &'a [ModelInferenceRequest<'_>],
        _client: &'a TensorzeroHttpClient,
        _dynamic_api_keys: &'a InferenceCredentials,
    ) -> Result<StartBatchProviderInferenceResponse, Error> {
        Err(ErrorDetails::UnsupportedModelProviderForBatchInference {
            provider_type: "Anthropic".to_string(),
        }
        .into())
    }

    async fn poll_batch_inference<'a>(
        &'a self,
        _batch_request: &'a BatchRequestRow<'a>,
        _http_client: &'a TensorzeroHttpClient,
        _dynamic_api_keys: &'a InferenceCredentials,
    ) -> Result<PollBatchInferenceResponse, Error> {
        Err(ErrorDetails::UnsupportedModelProviderForBatchInference {
            provider_type: PROVIDER_TYPE.to_string(),
        }
        .into())
    }
}

/// Maps events from Anthropic into the TensorZero format
/// Modified from the example [here](https://github.com/64bit/async-openai/blob/5c9c817b095e3bacb2b6c9804864cdf8b15c795e/async-openai/src/client.rs#L433)
/// At a high level, this function is handling low-level EventSource details and mapping the objects returned by Anthropic into our `InferenceResultChunk` type
fn stream_anthropic(
    mut event_source: TensorZeroEventSource,
    start_time: Instant,
    model_provider: &ModelProvider,
    model_name: &str,
    provider_name: &str,
    raw_request: &str,
    model_inference_id: Uuid,
) -> ProviderInferenceResponseStreamInner {
    let raw_request = raw_request.to_string();
    let discard_unknown_chunks = model_provider.discard_unknown_chunks;
    let model_name = model_name.to_string();
    let provider_name = provider_name.to_string();
    Box::pin(async_stream::stream! {
        // Track tool state per content block index for robust handling of interleaved blocks
        let mut tool_state: HashMap<u32, (String, String)> = HashMap::new();

        while let Some(ev) = event_source.next().await {
            match ev {
                Err(e) => {
                    yield Err(convert_stream_error(raw_request.clone(), PROVIDER_TYPE.to_string(), ApiType::ChatCompletions, *e, None).await);
                }
                Ok(event) => match event {
                    Event::Open => continue,
                    Event::Message(message) => {
                        let data: Result<AnthropicStreamMessage, Error> =
                            serde_json::from_str(&message.data).map_err(|e| Error::new(ErrorDetails::InferenceServer {
                                message: format!(
                                    "Error parsing message: {}, Data: {}",
                                    e, message.data
                                ),
                                provider_type: PROVIDER_TYPE.to_string(),
                                api_type: ApiType::ChatCompletions,
                                raw_request: Some(raw_request.to_string()),
                                raw_response: Some(message.data.clone()),
                            }));
                        // Anthropic streaming API docs specify that this is the last message
                        if let Ok(AnthropicStreamMessage::MessageStop) = data {
                            break;
                        }

                        let response = data.and_then(|data| {
                            anthropic_to_tensorzero_stream_message(
                                message.data,
                                data,
                                start_time.elapsed(),
                                &mut tool_state,
                                discard_unknown_chunks,
                                &model_name,
                                &provider_name,
                                PROVIDER_TYPE,
                                model_inference_id,
                            )
                        });

                        match response {
                            Ok(None) => {},
                            Ok(Some(stream_message)) => yield Ok(stream_message),
                            Err(e) => yield Err(e),
                        }
                    }
                },
            }
        }
    })
}

#[derive(Clone, Debug, PartialEq, Serialize)]
#[serde(rename_all = "lowercase")]
/// Anthropic doesn't handle the system message in this way
/// It's a field of the POST body instead
pub(super) enum AnthropicRole {
    User,
    Assistant,
}

impl From<Role> for AnthropicRole {
    fn from(role: Role) -> Self {
        match role {
            Role::User => AnthropicRole::User,
            Role::Assistant => AnthropicRole::Assistant,
        }
    }
}

/// We can instruct Anthropic to use a particular tool,
/// any tool (but to use one), or to use a tool if needed.
#[derive(Clone, Debug, PartialEq, Serialize)]
#[serde(tag = "type")]
#[serde(rename_all = "snake_case")]
pub enum AnthropicToolChoice<'a> {
    Auto {
        disable_parallel_tool_use: Option<bool>,
    },
    Any {
        disable_parallel_tool_use: Option<bool>,
    },
    Tool {
        name: &'a str,
        disable_parallel_tool_use: Option<bool>,
    },
}

// We map our ToolCallConfig struct to the AnthropicToolChoice that serializes properly
impl<'a> TryFrom<&'a ToolCallConfig> for AnthropicToolChoice<'a> {
    type Error = Error;

    fn try_from(tool_call_config: &'a ToolCallConfig) -> Result<Self, Error> {
        let disable_parallel_tool_use = Some(tool_call_config.parallel_tool_calls == Some(false));
        let tool_choice = &tool_call_config.tool_choice;

        match tool_choice {
            ToolChoice::Auto => Ok(AnthropicToolChoice::Auto {
                disable_parallel_tool_use,
            }),
            ToolChoice::Required => Ok(AnthropicToolChoice::Any {
                disable_parallel_tool_use,
            }),
            ToolChoice::Specific(name) => Ok(AnthropicToolChoice::Tool {
                name,
                disable_parallel_tool_use,
            }),
            ToolChoice::None => Ok(AnthropicToolChoice::Auto {
                disable_parallel_tool_use,
            }),
        }
    }
}

#[derive(Clone, Debug, PartialEq, Serialize)]
pub(super) struct AnthropicFunctionTool<'a> {
    pub(super) name: &'a str,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(super) description: Option<&'a str>,
    pub(super) input_schema: &'a Value,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(super) strict: Option<bool>,
}

impl<'a> AnthropicFunctionTool<'a> {
    pub fn new(tool: &'a FunctionToolConfig, supports_strict_mode: bool) -> Self {
        // In case we add more tool types in the future, the compiler will complain here.
        Self {
            name: tool.name(),
            description: Some(tool.description()),
            input_schema: tool.parameters(),
            strict: supports_strict_mode.then_some(tool.strict()),
        }
    }
}

/// Wrapper enum for tools sent to Anthropic API.
/// Can be either a function tool (with name, description, input_schema) or a provider tool (raw JSON like web_search, bash).
#[derive(Clone, Debug, PartialEq, Serialize)]
#[serde(untagged)]
pub(super) enum AnthropicTool<'a> {
    Function(AnthropicFunctionTool<'a>),
    Provider(&'a Value),
}

/// Builds the tools list for Anthropic requests, combining function tools and provider tools.
/// Returns None if no tools should be sent (ToolChoice::None or empty lists).
///
/// This is shared between Anthropic and GCP Vertex Anthropic providers.
pub(super) fn build_anthropic_tools<'a>(
    tool_config: Option<&'a Cow<'a, ToolCallConfig>>,
    provider_tools: &'a [Value],
    supports_strict_mode: bool,
) -> Result<Option<Vec<AnthropicTool<'a>>>, Error> {
    // Workaround for Anthropic API limitation: they don't support explicitly specifying "none"
    // for tool choice. When ToolChoice::None is specified, we don't send any tools in the
    // request payload to achieve the same effect.
    match tool_config {
        // ToolChoice::None - don't send any tools (function or provider)
        Some(c) if matches!(c.tool_choice, ToolChoice::None) => Ok(None),
        // Other tool choices - send both function and provider tools
        Some(c) => {
            let mut all_tools: Vec<AnthropicTool<'a>> = c
                .strict_tools_available()?
                .map(|tool| {
                    AnthropicTool::Function(AnthropicFunctionTool::new(tool, supports_strict_mode))
                })
                .collect();
            all_tools.extend(provider_tools.iter().map(AnthropicTool::Provider));
            Ok(Some(all_tools))
        }
        // No tool_config - only send provider tools if any exist
        None => {
            if provider_tools.is_empty() {
                Ok(None)
            } else {
                Ok(Some(
                    provider_tools.iter().map(AnthropicTool::Provider).collect(),
                ))
            }
        }
    }
}

#[derive(Clone, Debug, PartialEq, Serialize)]
#[serde(tag = "type")]
#[serde(rename_all = "snake_case")]
pub(super) enum AnthropicMessageContent<'a> {
    Text {
        text: &'a str,
    },
    Image {
        source: AnthropicDocumentSource,
    },
    Document {
        source: AnthropicDocumentSource,
    },
    ToolResult {
        tool_use_id: &'a str,
        content: Vec<AnthropicMessageContent<'a>>,
    },
    Thinking {
        thinking: Option<&'a str>,
        signature: Option<&'a str>,
    },
    RedactedThinking {
        data: &'a str,
    },
    ToolUse {
        id: &'a str,
        name: &'a str,
        input: Value,
    },
}

/// This is used by Anthropic for both images and documents -
/// the only different is the outer `AnthropicMessageContent`
#[derive(Clone, Debug, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
#[serde(tag = "type")]
pub enum AnthropicDocumentSource {
    Base64 { media_type: MediaType, data: String },
    Url { url: String },
}

impl<'a> AnthropicMessageContent<'a> {
    pub(super) async fn from_content_block(
        block: &'a ContentBlock,
        messages_config: AnthropicMessagesConfig,
        provider_type: &str,
    ) -> Result<Option<FlattenUnknown<'a, AnthropicMessageContent<'a>>>, Error> {
        match block {
            ContentBlock::Text(Text { text }) => Ok(Some(FlattenUnknown::Normal(
                AnthropicMessageContent::Text { text },
            ))),
            ContentBlock::ToolCall(tool_call) => {
                // Convert the tool call arguments from String to JSON Value (Anthropic expects an object)
                let input: Value = serde_json::from_str(&tool_call.arguments).map_err(|e| {
                    Error::new(ErrorDetails::InferenceClient {
                        status_code: Some(StatusCode::BAD_REQUEST),
                        message: format!(
                            "Error parsing tool call arguments as JSON Value: {}",
                            DisplayOrDebugGateway::new(e)
                        ),
                        provider_type: provider_type.to_string(),
                        api_type: ApiType::ChatCompletions,
                        raw_request: None,
                        raw_response: Some(tool_call.arguments.clone()),
                    })
                })?;

                if !input.is_object() {
                    return Err(Error::new(ErrorDetails::InferenceClient {
                        status_code: Some(StatusCode::BAD_REQUEST),
                        message: "Tool call arguments must be a JSON object".to_string(),
                        provider_type: provider_type.to_string(),
                        api_type: ApiType::ChatCompletions,
                        raw_request: None,
                        raw_response: Some(tool_call.arguments.clone()),
                    }));
                }

                Ok(Some(FlattenUnknown::Normal(
                    AnthropicMessageContent::ToolUse {
                        id: &tool_call.id,
                        name: &tool_call.name,
                        input,
                    },
                )))
            }
            ContentBlock::ToolResult(tool_result) => Ok(Some(FlattenUnknown::Normal(
                AnthropicMessageContent::ToolResult {
                    tool_use_id: &tool_result.id,
                    content: vec![AnthropicMessageContent::Text {
                        text: &tool_result.result,
                    }],
                },
            ))),
            ContentBlock::File(file) => match &**file {
                LazyFile::Url {
                    file_url:
                        FileUrl {
                            mime_type: Some(mime_type),
                            url,
                            detail,
                            filename: _,
                        },
                    future: _,
                } if !messages_config.fetch_and_encode_input_files_before_inference => {
                    // If the user provided a url, and we're not configured to fetch the file beforehand,
                    // then forward the url directly to Anthropic.
                    if detail.is_some() {
                        tracing::warn!(
                            "The image detail parameter is not supported by Anthropic. The `detail` field will be ignored."
                        );
                    }
                    if mime_type.type_() == mime::IMAGE {
                        Ok(Some(FlattenUnknown::Normal(
                            AnthropicMessageContent::Image {
                                source: AnthropicDocumentSource::Url {
                                    url: url.to_string(),
                                },
                            },
                        )))
                    } else {
                        Ok(Some(FlattenUnknown::Normal(
                            AnthropicMessageContent::Document {
                                source: AnthropicDocumentSource::Url {
                                    url: url.to_string(),
                                },
                            },
                        )))
                    }
                }
                _ => {
                    warn_cannot_forward_url_if_missing_mime_type(
                        file,
                        messages_config.fetch_and_encode_input_files_before_inference,
                        provider_type,
                    );
                    // Otherwise, fetch the file, encode it as base64, and send it to Anthropic
                    let resolved_file = file.resolve().await?;
                    let ObjectStorageFile { file, data } = &*resolved_file;
                    if file.detail.is_some() {
                        tracing::warn!(
                            "The image detail parameter is not supported by Anthropic. The `detail` field will be ignored."
                        );
                    }
                    let document = AnthropicDocumentSource::Base64 {
                        media_type: file.mime_type.clone(),
                        data: data.clone(),
                    };
                    if file.mime_type.type_() == mime::IMAGE {
                        Ok(Some(FlattenUnknown::Normal(
                            AnthropicMessageContent::Image { source: document },
                        )))
                    } else {
                        Ok(Some(FlattenUnknown::Normal(
                            AnthropicMessageContent::Document { source: document },
                        )))
                    }
                }
            },
            ContentBlock::Thought(thought) => {
                if let Some(text) = thought.text.as_deref() {
                    Ok(Some(FlattenUnknown::Normal(
                        AnthropicMessageContent::Thinking {
                            thinking: Some(text),
                            signature: thought.signature.as_deref(),
                        },
                    )))
                } else if let Some(signature) = thought.signature.as_deref() {
                    Ok(Some(FlattenUnknown::Normal(
                        AnthropicMessageContent::RedactedThinking { data: signature },
                    )))
                } else {
                    Ok(None)
                }
            }
            ContentBlock::Unknown(Unknown { data, .. }) => {
                Ok(Some(FlattenUnknown::Unknown(Cow::Borrowed(data))))
            }
        }
    }
}

#[derive(Clone, Debug, PartialEq, Serialize)]
pub(super) struct AnthropicMessage<'a> {
    pub(super) role: AnthropicRole,
    pub(super) content: Vec<FlattenUnknown<'a, AnthropicMessageContent<'a>>>,
}

impl<'a> AnthropicMessage<'a> {
    pub(super) async fn from_request_message(
        message: &'a RequestMessage,
        messages_config: AnthropicMessagesConfig,
        provider_type: &str,
    ) -> Result<Self, Error> {
        let content: Vec<FlattenUnknown<AnthropicMessageContent>> =
            try_join_all(message.content.iter().map(|c| {
                AnthropicMessageContent::from_content_block(c, messages_config, provider_type)
            }))
            .await?
            .into_iter()
            .flatten()
            .collect();

        Ok(AnthropicMessage {
            role: message.role.into(),
            content,
        })
    }
}

#[derive(Debug, PartialEq, Serialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub(super) enum AnthropicSystemBlock<'a> {
    Text {
        text: &'a str,
        // This also contains cache control and citations but we will ignore these for now.
    },
}

#[derive(Debug, PartialEq, Serialize)]
#[serde(untagged)]
enum AnthropicThinkingConfig {
    Enabled {
        r#type: &'static str,
        budget_tokens: i32,
    },
    Adaptive {
        r#type: &'static str,
    },
}

#[derive(Debug, PartialEq, Serialize)]
#[serde(tag = "type")]
#[serde(rename_all = "snake_case")]
pub enum AnthropicOutputFormat {
    JsonSchema { schema: Value },
}

#[derive(Debug, PartialEq, Serialize)]
pub struct AnthropicOutputConfig {
    #[serde(skip_serializing_if = "Option::is_none")]
    format: Option<AnthropicOutputFormat>,
    #[serde(skip_serializing_if = "Option::is_none")]
    effort: Option<String>,
}

#[derive(Debug, Default, PartialEq, Serialize)]
struct AnthropicRequestBody<'a> {
    model: &'a str,
    messages: Vec<AnthropicMessage<'a>>,
    max_tokens: u32,
    #[serde(skip_serializing_if = "Option::is_none")]
    stream: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    output_config: Option<AnthropicOutputConfig>,
    #[serde(skip_serializing_if = "Option::is_none")]
    // This is the system message
    system: Option<Vec<AnthropicSystemBlock<'a>>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    temperature: Option<f32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    thinking: Option<AnthropicThinkingConfig>,
    #[serde(skip_serializing_if = "Option::is_none")]
    top_p: Option<f32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    service_tier: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    stop_sequences: Option<Cow<'a, [String]>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    tool_choice: Option<AnthropicToolChoice<'a>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    tools: Option<Vec<AnthropicTool<'a>>>,
}

#[derive(Copy, Clone, Debug)]
pub(super) struct AnthropicMessagesConfig {
    pub(super) fetch_and_encode_input_files_before_inference: bool,
}

/// Returns true if we should use JSON prefill for this request.
/// Prefill is only used for json_mode=on. For json_mode=strict, we use
/// the beta structured outputs feature with output_format instead.
fn needs_json_prefill(request: &ModelInferenceRequest<'_>) -> bool {
    matches!(request.json_mode, ModelInferenceRequestJsonMode::On)
        && matches!(request.function_type, FunctionType::Json)
}

impl<'a> AnthropicRequestBody<'a> {
    async fn new(
        model_name: &'a str,
        request: &'a ModelInferenceRequest<'_>,
        provider_tools: &'a [Value],
    ) -> Result<AnthropicRequestBody<'a>, Error> {
        if request.messages.is_empty() {
            return Err(ErrorDetails::InvalidRequest {
                message: "Anthropic requires at least one message".to_string(),
            }
            .into());
        }
        let messages_config = AnthropicMessagesConfig {
            fetch_and_encode_input_files_before_inference: request
                .fetch_and_encode_input_files_before_inference,
        };
        // We use the content block form rather than string so people can use
        // extra_body for cache control.
        let system = request
            .system
            .as_deref()
            .map(|text| vec![AnthropicSystemBlock::Text { text }]);
        let messages: Vec<AnthropicMessage> =
            try_join_all(request.messages.iter().map(|m| {
                AnthropicMessage::from_request_message(m, messages_config, PROVIDER_TYPE)
            }))
            .await?;
        let messages = if needs_json_prefill(request) {
            prefill_json_message(messages)
        } else {
            messages
        };

        let tools = build_anthropic_tools(request.tool_config.as_ref(), provider_tools, true)?;

        // `tool_choice` should only be set if tools are set and non-empty
        let tool_choice: Option<AnthropicToolChoice> = tools
            .as_ref()
            .filter(|t| !t.is_empty())
            .and(request.tool_config.as_ref())
            .and_then(|c| c.as_ref().try_into().ok());

        let max_tokens = match request.max_tokens {
            Some(max_tokens) => Ok(max_tokens),
            None => get_default_max_tokens(model_name),
        }?;

        // NOTE: Anthropic does not support seed
        let mut anthropic_request = AnthropicRequestBody {
            model: model_name,
            messages,
            max_tokens,
            stream: Some(request.stream),
            system,
            temperature: request.temperature,
            thinking: None,
            top_p: request.top_p,
            service_tier: None, // handled below
            tool_choice,
            tools,
            output_config: match request.json_mode {
                ModelInferenceRequestJsonMode::Strict => {
                    request.output_schema.map(|schema| AnthropicOutputConfig {
                        format: Some(AnthropicOutputFormat::JsonSchema {
                            schema: schema.clone(),
                        }),
                        effort: None,
                    })
                }
                ModelInferenceRequestJsonMode::On | ModelInferenceRequestJsonMode::Off => None,
            },
            stop_sequences: request.borrow_stop_sequences(),
        };

        apply_inference_params(&mut anthropic_request, &request.inference_params_v2)?;

        Ok(anthropic_request)
    }
}

fn apply_inference_params(
    request: &mut AnthropicRequestBody,
    inference_params: &ChatCompletionInferenceParamsV2,
) -> Result<(), Error> {
    let ChatCompletionInferenceParamsV2 {
        reasoning_effort,
        service_tier,
        thinking_budget_tokens,
        verbosity,
    } = inference_params;

    if reasoning_effort.is_some() && thinking_budget_tokens.is_some() {
        return Err(ErrorDetails::InvalidRequest {
            message: "Cannot specify both `reasoning_effort` and `thinking_budget_tokens` for Anthropic. Use `reasoning_effort` for adaptive thinking or `thinking_budget_tokens` for manual thinking.".to_string(),
        }
        .into());
    }

    if let Some(effort) = reasoning_effort {
        request.thinking = Some(AnthropicThinkingConfig::Adaptive { r#type: "adaptive" });
        match &mut request.output_config {
            Some(config) => {
                config.effort = Some(effort.clone());
            }
            None => {
                request.output_config = Some(AnthropicOutputConfig {
                    format: None,
                    effort: Some(effort.clone()),
                });
            }
        }
    }

    // Map service_tier values to Anthropic-compatible values
    if let Some(tier) = service_tier {
        match tier {
            ServiceTier::Auto | ServiceTier::Priority => {
                request.service_tier = Some("auto".to_string());
            }
            ServiceTier::Default => {
                request.service_tier = Some("standard_only".to_string());
            }
            ServiceTier::Flex => {
                warn_inference_parameter_not_supported(PROVIDER_NAME, "service_tier (flex)", None);
            }
        }
    }

    if let Some(budget_tokens) = thinking_budget_tokens {
        request.thinking = Some(AnthropicThinkingConfig::Enabled {
            r#type: "enabled",
            budget_tokens: *budget_tokens,
        });
    }

    if verbosity.is_some() {
        warn_inference_parameter_not_supported(PROVIDER_NAME, "verbosity", None);
    }

    Ok(())
}

/// Returns the default max_tokens for a given Anthropic model name, or an error if unknown.
///
/// Anthropic requires that the user provides `max_tokens`, but the value depends on the model.
/// We maintain a library of known maximum values, and ask the user to hardcode it if it's unknown.
fn get_default_max_tokens(model_name: &str) -> Result<u32, Error> {
    if model_name.starts_with("claude-3-haiku") || model_name.starts_with("claude-3-opus") {
        Ok(4_096)
    } else if model_name.starts_with("claude-3-5-haiku")
        || model_name.starts_with("claude-3-5-sonnet")
    {
        Ok(8_192)
    } else if model_name.starts_with("claude-3-7-sonnet")
        || model_name.starts_with("claude-sonnet-4-202")
        || model_name == "claude-sonnet-4-0"
        || model_name.starts_with("claude-haiku-4-5")
        || model_name.starts_with("claude-sonnet-4-5")
        || model_name.starts_with("claude-sonnet-4-6")
        || model_name.starts_with("claude-opus-4-5")
    {
        Ok(64_000)
    } else if model_name.starts_with("claude-opus-4-202")
        || model_name == "claude-opus-4-0"
        || model_name.starts_with("claude-opus-4-1-202")
        || model_name == "claude-opus-4-1"
    {
        Ok(32_000)
    } else if model_name.starts_with("claude-opus-4-6") {
        Ok(128_000)
    } else {
        Err(Error::new(ErrorDetails::InferenceClient {
            message: format!(
                "The TensorZero Gateway doesn't know the output token limit for `{model_name}` and Anthropic requires you to provide a `max_tokens` value. Please set `max_tokens` in your configuration or inference request."
            ),
            status_code: None,
            provider_type: PROVIDER_TYPE.into(),
            api_type: ApiType::ChatCompletions,
            raw_request: None,
            raw_response: None,
        }))
    }
}

fn prefill_json_message(messages: Vec<AnthropicMessage>) -> Vec<AnthropicMessage> {
    let mut messages = messages;
    // Add a JSON-prefill message for Anthropic's JSON mode
    messages.push(AnthropicMessage {
        role: AnthropicRole::Assistant,
        content: vec![FlattenUnknown::Normal(AnthropicMessageContent::Text {
            text: "Here is the JSON requested:\n{",
        })],
    });
    messages
}

pub(crate) fn prefill_json_response(
    content: Vec<ContentBlockOutput>,
) -> Result<Vec<ContentBlockOutput>, Error> {
    // Check if the content is a single text block
    if content.len() == 1
        && let ContentBlockOutput::Text(text) = &content[0]
    {
        // If it's a single text block, add a "{" to the beginning
        return Ok(vec![ContentBlockOutput::Text(Text {
            text: format!("{{{}", text.text.trim()),
        })]);
    }
    // If it's not a single text block, return content as-is but log an error
    Error::new(ErrorDetails::OutputParsing {
        message: "Expected a single text block in the response from Anthropic".to_string(),
        raw_output: serde_json::to_string(&content).map_err(|e| Error::new(ErrorDetails::Inference {
            message: format!("Error serializing content as JSON: {}. This should never happen. Please file a bug report: https://github.com/tensorzero/tensorzero/issues/new", DisplayOrDebugGateway::new(e)),
        }))?,
    });
    Ok(content)
}

pub(crate) fn prefill_json_chunk_response(chunk: &mut ProviderInferenceResponseChunk) {
    if chunk.content.is_empty() {
        chunk.content = vec![ContentBlockChunk::Text(TextChunk {
            text: "{".to_string(),
            id: "0".to_string(),
        })];
    } else if chunk.content.len() == 1 {
        if let ContentBlockChunk::Text(TextChunk { text, .. }) = &chunk.content[0] {
            // Add a "{" to the beginning of the text
            chunk.content = vec![ContentBlockChunk::Text(TextChunk {
                text: format!("{{{}", text.trim_start()),
                id: "0".to_string(),
            })];
        }
    } else {
        Error::new(ErrorDetails::OutputParsing {
            message: "Expected a single text block in the response from Anthropic".to_string(),
            raw_output: serde_json::to_string(&chunk.content).map_err(|e| Error::new(ErrorDetails::Inference {
                message: format!("Error serializing content as JSON: {}. This should never happen. Please file a bug report: https://github.com/tensorzero/tensorzero/issues/new", DisplayOrDebugGateway::new(e)),
            })).unwrap_or_default()
        });
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, TensorZeroDeserialize)]
#[serde(tag = "type")]
#[serde(rename_all = "snake_case")]
pub enum AnthropicContentBlock {
    Text {
        text: String,
    },
    Thinking {
        thinking: String,
        signature: String,
    },
    RedactedThinking {
        data: String,
    },
    ToolUse {
        id: String,
        name: String,
        input: serde_json::Value,
    },
}

fn convert_to_output(
    model_name: &str,
    provider_name: &str,
    block: FlattenUnknown<'static, AnthropicContentBlock>,
) -> Result<ContentBlockOutput, Error> {
    match block {
        FlattenUnknown::Normal(AnthropicContentBlock::Text { text }) => Ok(text.into()),
        FlattenUnknown::Normal(AnthropicContentBlock::ToolUse { id, name, input }) => {
            Ok(ContentBlockOutput::ToolCall(ToolCall {
                id,
                name,
                arguments: serde_json::to_string(&input).map_err(|e| {
                    Error::new(ErrorDetails::InferenceServer {
                        message: format!(
                            "Error parsing input for tool call: {}",
                            DisplayOrDebugGateway::new(e)
                        ),
                        provider_type: PROVIDER_TYPE.to_string(),
                        api_type: ApiType::ChatCompletions,
                        raw_request: None,
                        raw_response: Some(serde_json::to_string(&input).unwrap_or_default()),
                    })
                })?,
            }))
        }
        FlattenUnknown::Normal(AnthropicContentBlock::Thinking {
            thinking,
            signature,
        }) => Ok(ContentBlockOutput::Thought(Thought {
            text: Some(thinking),
            signature: Some(signature),
            summary: None,
            provider_type: Some(PROVIDER_TYPE.to_string()),
            extra_data: None,
        })),
        FlattenUnknown::Normal(AnthropicContentBlock::RedactedThinking { data }) => {
            Ok(ContentBlockOutput::Thought(Thought {
                text: None,
                signature: Some(data),
                summary: None,
                provider_type: Some(PROVIDER_TYPE.to_string()),
                extra_data: None,
            }))
        }
        FlattenUnknown::Unknown(data) => Ok(ContentBlockOutput::Unknown(Unknown {
            data: data.into_owned(),
            model_name: Some(model_name.to_string()),
            provider_name: Some(provider_name.to_string()),
        })),
    }
}

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
pub struct AnthropicUsage {
    #[serde(default)]
    input_tokens: Option<u32>,
    #[serde(default)]
    output_tokens: Option<u32>,
    /// Number of input tokens used to create a new cache entry
    #[serde(default)]
    cache_creation_input_tokens: Option<u32>,
    /// Number of input tokens read from cache
    #[serde(default)]
    cache_read_input_tokens: Option<u32>,
}

impl AnthropicUsage {
    pub fn into_usage(self) -> Usage {
        // Anthropic reports cache tokens separately from input_tokens.
        // We need to add them back to get the total input token count.
        let total_input_tokens = match (
            self.input_tokens,
            self.cache_creation_input_tokens,
            self.cache_read_input_tokens,
        ) {
            (None, None, None) => None,
            _ => Some(
                self.input_tokens.unwrap_or(0)
                    + self.cache_creation_input_tokens.unwrap_or(0)
                    + self.cache_read_input_tokens.unwrap_or(0),
            ),
        };

        Usage {
            input_tokens: total_input_tokens,
            output_tokens: self.output_tokens,
            provider_cache_read_input_tokens: self.cache_read_input_tokens,
            provider_cache_write_input_tokens: self.cache_creation_input_tokens,
            cost: None,
        }
    }
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
struct AnthropicResponse {
    id: String,
    r#type: String, // this is always "message"
    role: String,   // this is always "assistant"
    content: Vec<FlattenUnknown<'static, AnthropicContentBlock>>,
    model: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    stop_reason: Option<AnthropicStopReason>,
    #[serde(skip_serializing_if = "Option::is_none")]
    stop_sequence: Option<String>,
    usage: AnthropicUsage,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum AnthropicStopReason {
    EndTurn,
    MaxTokens,
    StopSequence,
    ToolUse,
    #[serde(other)]
    Unknown,
}

impl AnthropicStopReason {
    pub fn into_finish_reason(self) -> FinishReason {
        match self {
            AnthropicStopReason::EndTurn => FinishReason::Stop,
            AnthropicStopReason::MaxTokens => FinishReason::Length,
            AnthropicStopReason::StopSequence => FinishReason::StopSequence,
            AnthropicStopReason::ToolUse => FinishReason::ToolCall,
            AnthropicStopReason::Unknown => FinishReason::Unknown,
        }
    }
}

#[derive(Debug)]
#[cfg_attr(any(feature = "e2e_tests", test), derive(PartialEq))]
struct AnthropicResponseWithMetadata<'a> {
    response: AnthropicResponse,
    raw_response: String,
    latency: Latency,
    raw_request: String,
    generic_request: &'a ModelInferenceRequest<'a>,
    input_messages: Vec<RequestMessage>,
    model_name: &'a str,
    provider_name: &'a str,
    model_inference_id: Uuid,
}

impl<'a> TryFrom<AnthropicResponseWithMetadata<'a>> for ProviderInferenceResponse {
    type Error = Error;
    fn try_from(value: AnthropicResponseWithMetadata<'a>) -> Result<Self, Self::Error> {
        let AnthropicResponseWithMetadata {
            response,
            raw_response,
            latency,
            raw_request,
            generic_request,
            input_messages,
            model_name,
            provider_name,
            model_inference_id,
        } = value;
        let output: Vec<ContentBlockOutput> = response
            .content
            .into_iter()
            .map(|block| convert_to_output(model_name, provider_name, block))
            .collect::<Result<Vec<_>, _>>()?;
        let content = if needs_json_prefill(generic_request) {
            prefill_json_response(output)?
        } else {
            output
        };

        let raw_usage = anthropic_usage_from_raw_response(&raw_response).map(|usage| {
            raw_usage_entries_from_value(
                model_inference_id,
                PROVIDER_TYPE,
                ApiType::ChatCompletions,
                usage,
            )
        });
        let usage = response.usage.into_usage();
        Ok(ProviderInferenceResponse::new(
            ProviderInferenceResponseArgs {
                id: model_inference_id,
                output: content,
                system: generic_request.system.clone(),
                input_messages,
                raw_request,
                raw_response,
                raw_usage,
                relay_raw_response: None,
                usage,
                provider_latency: latency,
                finish_reason: response
                    .stop_reason
                    .map(AnthropicStopReason::into_finish_reason),
            },
        ))
    }
}

fn anthropic_usage_from_raw_response(raw_response: &str) -> Option<Value> {
    serde_json::from_str::<Value>(raw_response)
        .ok()
        .and_then(|value| value.get("usage").filter(|v| !v.is_null()).cloned())
}

pub(super) fn handle_anthropic_error(
    response_code: StatusCode,
    raw_request: String,
    raw_response: String,
    api_type: ApiType,
) -> Result<ProviderInferenceResponse, Error> {
    match response_code {
        StatusCode::UNAUTHORIZED
        | StatusCode::BAD_REQUEST
        | StatusCode::PAYLOAD_TOO_LARGE
        | StatusCode::TOO_MANY_REQUESTS => Err(ErrorDetails::InferenceClient {
            status_code: Some(response_code),
            provider_type: PROVIDER_TYPE.to_string(),
            api_type,
            raw_request: Some(raw_request),
            raw_response: Some(raw_response.clone()),
            message: raw_response,
        }
        .into()),
        // StatusCode::NOT_FOUND | StatusCode::FORBIDDEN | StatusCode::INTERNAL_SERVER_ERROR | 529: Overloaded
        // These are all captured in _ since they have the same error behavior
        _ => Err(ErrorDetails::InferenceServer {
            raw_response: Some(raw_response.clone()),
            message: raw_response,
            provider_type: PROVIDER_TYPE.to_string(),
            api_type,
            raw_request: Some(raw_request),
        }
        .into()),
    }
}

#[derive(Debug, Serialize, TensorZeroDeserialize)]
#[serde(tag = "type")]
#[serde(rename_all = "snake_case")]
pub enum AnthropicContentBlockDelta {
    TextDelta { text: String },
    InputJsonDelta { partial_json: String },
    SignatureDelta { signature: String },
    ThinkingDelta { thinking: String },
}

#[derive(Deserialize, Debug, Serialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub struct AnthropicMessageDelta {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub stop_reason: Option<AnthropicStopReason>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub stop_sequence: Option<String>,
}

#[derive(Deserialize, Debug, Serialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum AnthropicStreamMessage {
    ContentBlockDelta {
        delta: FlattenUnknown<'static, AnthropicContentBlockDelta>,
        index: u32,
    },
    ContentBlockStart {
        content_block: FlattenUnknown<'static, AnthropicContentBlock>,
        index: u32,
    },
    ContentBlockStop {
        index: u32,
    },
    Error {
        error: Value,
    },
    MessageDelta {
        delta: FlattenUnknown<'static, AnthropicMessageDelta>,
        usage: Value,
    },
    MessageStart {
        message: Value,
    },
    MessageStop,
    Ping,
}

/// This function converts an Anthropic stream message to a TensorZero stream message.
/// It must keep track of tool IDs and names per content block index in order to correctly handle ToolCallChunks
/// (which we force to always contain the tool name and ID).
/// Anthropic only sends the tool ID and name in the ToolUse/server_tool_use ContentBlockStart events,
/// so we track them per index so that subsequent InputJsonDelta chunks can be initialized with this information.
/// Using per-index tracking (rather than a single global state) ensures correct behavior even if content blocks
/// are interleaved in the stream.
/// See the Anthropic [docs](https://docs.anthropic.com/en/api/messages-streaming) on streaming messages for details.
#[expect(clippy::too_many_arguments)]
pub(super) fn anthropic_to_tensorzero_stream_message(
    raw_message: String,
    message: AnthropicStreamMessage,
    message_latency: Duration,
    tool_state: &mut HashMap<u32, (String, String)>, // index -> (tool_id, tool_name)
    discard_unknown_chunks: bool,
    model_name: &str,
    provider_name: &str,
    provider_type: &str,
    model_inference_id: Uuid,
) -> Result<Option<ProviderInferenceResponseChunk>, Error> {
    match message {
        AnthropicStreamMessage::ContentBlockDelta {
            delta: FlattenUnknown::Normal(delta),
            index,
        } => match delta {
            AnthropicContentBlockDelta::TextDelta { text } => {
                Ok(Some(ProviderInferenceResponseChunk::new(
                    vec![ContentBlockChunk::Text(TextChunk {
                        text,
                        id: index.to_string(),
                    })],
                    None,
                    raw_message,
                    message_latency,
                    None,
                )))
            }
            AnthropicContentBlockDelta::InputJsonDelta { partial_json } => {
                // Look up tool info by index for robust handling of interleaved content blocks
                let (tool_id, _tool_name) = tool_state.get(&index).ok_or_else(|| Error::new(ErrorDetails::InferenceServer {
                    message: format!(
                        "Got InputJsonDelta chunk from Anthropic for index {index} without a preceding ToolUse ContentBlockStart"
                    ),
                    provider_type: provider_type.to_string(),
                    api_type: ApiType::ChatCompletions,
                    raw_request: None,
                    raw_response: None,
                }))?;
                Ok(Some(ProviderInferenceResponseChunk::new(
                    vec![ContentBlockChunk::ToolCall(ToolCallChunk {
                        raw_name: None,
                        id: tool_id.clone(),
                        raw_arguments: partial_json,
                    })],
                    None,
                    raw_message,
                    message_latency,
                    None,
                )))
            }
            AnthropicContentBlockDelta::ThinkingDelta { thinking } => {
                Ok(Some(ProviderInferenceResponseChunk::new(
                    vec![ContentBlockChunk::Thought(ThoughtChunk {
                        text: Some(thinking),
                        signature: None,
                        id: index.to_string(),
                        summary_id: None,
                        summary_text: None,
                        provider_type: Some(provider_type.to_string()),
                        extra_data: None,
                    })],
                    None,
                    raw_message,
                    message_latency,
                    None,
                )))
            }
            AnthropicContentBlockDelta::SignatureDelta { signature } => {
                Ok(Some(ProviderInferenceResponseChunk::new(
                    vec![ContentBlockChunk::Thought(ThoughtChunk {
                        text: None,
                        signature: Some(signature),
                        id: index.to_string(),
                        summary_id: None,
                        summary_text: None,
                        provider_type: Some(provider_type.to_string()),
                        extra_data: None,
                    })],
                    None,
                    raw_message,
                    message_latency,
                    None,
                )))
            }
        },
        AnthropicStreamMessage::ContentBlockStart {
            content_block: FlattenUnknown::Normal(content_block),
            index,
        } => match content_block {
            AnthropicContentBlock::Text { text } => {
                let text_chunk = ContentBlockChunk::Text(TextChunk {
                    text,
                    id: index.to_string(),
                });
                Ok(Some(ProviderInferenceResponseChunk::new(
                    vec![text_chunk],
                    None,
                    raw_message,
                    message_latency,
                    None,
                )))
            }
            AnthropicContentBlock::ToolUse { id, name, .. } => {
                // Store tool info by index for subsequent InputJsonDelta events
                tool_state.insert(index, (id.clone(), name.clone()));
                Ok(Some(ProviderInferenceResponseChunk::new(
                    vec![ContentBlockChunk::ToolCall(ToolCallChunk {
                        id,
                        raw_name: Some(name),
                        // As far as I can tell this is always {} so we ignore
                        raw_arguments: String::new(),
                    })],
                    None,
                    raw_message,
                    message_latency,
                    None,
                )))
            }
            AnthropicContentBlock::Thinking {
                thinking,
                signature,
            } => Ok(Some(ProviderInferenceResponseChunk::new(
                vec![ContentBlockChunk::Thought(ThoughtChunk {
                    text: Some(thinking),
                    signature: Some(signature),
                    id: index.to_string(),
                    summary_id: None,
                    summary_text: None,
                    provider_type: Some(provider_type.to_string()),
                    extra_data: None,
                })],
                None,
                raw_message,
                message_latency,
                None,
            ))),
            AnthropicContentBlock::RedactedThinking { data } => {
                Ok(Some(ProviderInferenceResponseChunk::new(
                    vec![ContentBlockChunk::Thought(ThoughtChunk {
                        text: None,
                        signature: Some(data),
                        id: index.to_string(),
                        summary_id: None,
                        summary_text: None,
                        provider_type: Some(provider_type.to_string()),
                        extra_data: None,
                    })],
                    None,
                    raw_message,
                    message_latency,
                    None,
                )))
            }
        },
        AnthropicStreamMessage::ContentBlockStop { .. } => Ok(None),
        AnthropicStreamMessage::Error { error } => Err(ErrorDetails::InferenceServer {
            message: error.to_string(),
            provider_type: provider_type.to_string(),
            api_type: ApiType::ChatCompletions,
            raw_request: None,
            raw_response: None,
        }
        .into()),
        AnthropicStreamMessage::MessageDelta {
            usage,
            delta: FlattenUnknown::Normal(delta),
        } => {
            let usage_value = usage;
            let usage = parse_usage_info(&usage_value);
            let raw_usage = Some(raw_usage_entries_from_value(
                model_inference_id,
                provider_type,
                ApiType::ChatCompletions,
                usage_value,
            ));
            Ok(Some(match raw_usage {
                Some(entries) => ProviderInferenceResponseChunk::new_with_raw_usage(
                    vec![],
                    Some(usage.into_usage()),
                    raw_message,
                    message_latency,
                    delta
                        .stop_reason
                        .map(AnthropicStopReason::into_finish_reason),
                    Some(entries),
                ),
                None => ProviderInferenceResponseChunk::new(
                    vec![],
                    Some(usage.into_usage()),
                    raw_message,
                    message_latency,
                    delta
                        .stop_reason
                        .map(AnthropicStopReason::into_finish_reason),
                ),
            }))
        }
        AnthropicStreamMessage::MessageStart { message } => {
            if let Some(usage_info) = message.get("usage") {
                let usage = parse_usage_info(usage_info);
                let raw_usage = Some(raw_usage_entries_from_value(
                    model_inference_id,
                    provider_type,
                    ApiType::ChatCompletions,
                    usage_info.clone(),
                ));
                Ok(Some(match raw_usage {
                    Some(entries) => ProviderInferenceResponseChunk::new_with_raw_usage(
                        vec![],
                        Some(usage.into_usage()),
                        raw_message,
                        message_latency,
                        None,
                        Some(entries),
                    ),
                    None => ProviderInferenceResponseChunk::new(
                        vec![],
                        Some(usage.into_usage()),
                        raw_message,
                        message_latency,
                        None,
                    ),
                }))
            } else {
                Ok(None)
            }
        }
        AnthropicStreamMessage::MessageStop | AnthropicStreamMessage::Ping => Ok(None),
        AnthropicStreamMessage::ContentBlockDelta {
            delta: FlattenUnknown::Unknown(delta),
            index,
        } => {
            if discard_unknown_chunks {
                warn_discarded_unknown_chunk(provider_type, &delta.to_string());
                return Ok(None);
            }
            Ok(Some(ProviderInferenceResponseChunk::new(
                vec![ContentBlockChunk::Unknown(UnknownChunk {
                    id: index.to_string(),
                    data: delta.into_owned(),
                    model_name: Some(model_name.to_string()),
                    provider_name: Some(provider_name.to_string()),
                })],
                None,
                raw_message,
                message_latency,
                None,
            )))
        }
        AnthropicStreamMessage::ContentBlockStart {
            content_block: FlattenUnknown::Unknown(content_block),
            index,
        } => {
            // For server_tool_use blocks (e.g., web_search), extract the tool ID and name
            // and store them by index (same as regular ToolUse blocks)
            if let Some(obj) = content_block.as_object()
                && obj.get("type").and_then(|v| v.as_str()) == Some("server_tool_use")
                && let (Some(id), Some(name)) = (
                    obj.get("id").and_then(|v| v.as_str()),
                    obj.get("name").and_then(|v| v.as_str()),
                )
            {
                tool_state.insert(index, (id.to_string(), name.to_string()));
            }

            if discard_unknown_chunks {
                warn_discarded_unknown_chunk(provider_type, &content_block.to_string());
                return Ok(None);
            }
            Ok(Some(ProviderInferenceResponseChunk::new(
                vec![ContentBlockChunk::Unknown(UnknownChunk {
                    id: index.to_string(),
                    data: content_block.into_owned(),
                    model_name: Some(model_name.to_string()),
                    provider_name: Some(provider_name.to_string()),
                })],
                None,
                raw_message,
                message_latency,
                None,
            )))
        }
        AnthropicStreamMessage::MessageDelta {
            usage: _,
            delta: FlattenUnknown::Unknown(delta),
        } => {
            if discard_unknown_chunks {
                warn_discarded_unknown_chunk(provider_type, &delta.to_string());
                return Ok(None);
            }
            Ok(Some(ProviderInferenceResponseChunk::new(
                vec![ContentBlockChunk::Unknown(UnknownChunk {
                    id: "message_delta".to_string(),
                    data: delta.into_owned(),
                    model_name: Some(model_name.to_string()),
                    provider_name: Some(provider_name.to_string()),
                })],
                None,
                raw_message,
                message_latency,
                None,
            )))
        }
    }
}

fn parse_usage_info(usage_info: &Value) -> AnthropicUsage {
    serde_json::from_value(usage_info.clone()).unwrap_or_default()
}

#[cfg(test)]
mod tests {
    use std::borrow::Cow;
    use std::collections::HashMap;

    use futures::FutureExt;
    use serde_json::json;
    use url::Url;
    use uuid::Uuid;

    use super::*;
    use crate::inference::types::file::Detail;
    use crate::inference::types::resolved_input::{FileUrl, LazyFile};
    use crate::inference::types::{ContentBlock, FunctionType, ModelInferenceRequestJsonMode};
    use crate::jsonschema_util::JSONSchema;
    use crate::providers::test_helpers::WEATHER_TOOL_CONFIG;
    use crate::tool::{DynamicToolConfig, ToolResult};
    use crate::utils::testing::capture_logs;

    #[test]
    fn test_try_from_tool_call_config() {
        // Need to cover all 4 cases
        let tool_call_config = ToolCallConfig {
            parallel_tool_calls: Some(false),
            ..Default::default()
        };
        let anthropic_tool_choice = AnthropicToolChoice::try_from(&tool_call_config);
        assert!(matches!(
            anthropic_tool_choice.unwrap(),
            AnthropicToolChoice::Auto {
                disable_parallel_tool_use: Some(true)
            }
        ));

        let tool_call_config = ToolCallConfig {
            parallel_tool_calls: Some(true),
            ..Default::default()
        };
        let anthropic_tool_choice = AnthropicToolChoice::try_from(&tool_call_config);
        assert!(anthropic_tool_choice.is_ok());
        assert_eq!(
            anthropic_tool_choice.unwrap(),
            AnthropicToolChoice::Auto {
                disable_parallel_tool_use: Some(false)
            }
        );

        let tool_call_config = ToolCallConfig {
            tool_choice: ToolChoice::Required,
            parallel_tool_calls: Some(true),
            ..Default::default()
        };
        let anthropic_tool_choice = AnthropicToolChoice::try_from(&tool_call_config);
        assert!(anthropic_tool_choice.is_ok());
        assert_eq!(
            anthropic_tool_choice.unwrap(),
            AnthropicToolChoice::Any {
                disable_parallel_tool_use: Some(false)
            }
        );

        let tool_call_config = ToolCallConfig {
            tool_choice: ToolChoice::Specific("test".to_string()),
            parallel_tool_calls: Some(false),
            ..Default::default()
        };
        let anthropic_tool_choice = AnthropicToolChoice::try_from(&tool_call_config);
        assert!(anthropic_tool_choice.is_ok());
        assert_eq!(
            anthropic_tool_choice.unwrap(),
            AnthropicToolChoice::Tool {
                name: "test",
                disable_parallel_tool_use: Some(true)
            }
        );
    }

    #[tokio::test]
    async fn test_from_tool() {
        let parameters = json!({
            "type": "object",
            "properties": {
                "location": {"type": "string"},
                "unit": {"type": "string"}
            },
            "required": ["location", "unit"]
        });
        let tool = FunctionToolConfig::Dynamic(DynamicToolConfig {
            name: "test".to_string(),
            description: "test".to_string(),
            parameters: JSONSchema::compile_background(parameters.clone()),
            strict: false,
        });
        let anthropic_tool: AnthropicFunctionTool = AnthropicFunctionTool::new(&tool, true);
        assert_eq!(
            anthropic_tool,
            AnthropicFunctionTool {
                name: "test",
                description: Some("test"),
                input_schema: &parameters,
                strict: Some(false),
            }
        );
    }

    #[tokio::test]
    async fn test_try_from_content_block() {
        let text_content_block: ContentBlock = "test".to_string().into();
        let anthropic_content_block = AnthropicMessageContent::from_content_block(
            &text_content_block,
            AnthropicMessagesConfig {
                fetch_and_encode_input_files_before_inference: false,
            },
            PROVIDER_TYPE,
        )
        .await
        .unwrap()
        .unwrap();
        assert_eq!(
            anthropic_content_block,
            FlattenUnknown::Normal(AnthropicMessageContent::Text { text: "test" })
        );

        let tool_call_content_block = ContentBlock::ToolCall(ToolCall {
            id: "test_id".to_string(),
            name: "test_name".to_string(),
            arguments: serde_json::to_string(&json!({"type": "string"})).unwrap(),
        });
        let anthropic_content_block = AnthropicMessageContent::from_content_block(
            &tool_call_content_block,
            AnthropicMessagesConfig {
                fetch_and_encode_input_files_before_inference: false,
            },
            PROVIDER_TYPE,
        )
        .await
        .unwrap()
        .unwrap();
        assert_eq!(
            anthropic_content_block,
            FlattenUnknown::Normal(AnthropicMessageContent::ToolUse {
                id: "test_id",
                name: "test_name",
                input: json!({"type": "string"})
            })
        );
    }

    #[tokio::test]
    async fn test_try_from_request_message() {
        // Test a User message
        let inference_request_message = RequestMessage {
            role: Role::User,
            content: vec!["test".to_string().into()],
        };
        let anthropic_message = AnthropicMessage::from_request_message(
            &inference_request_message,
            AnthropicMessagesConfig {
                fetch_and_encode_input_files_before_inference: false,
            },
            PROVIDER_TYPE,
        )
        .await
        .unwrap();
        assert_eq!(
            anthropic_message,
            AnthropicMessage {
                role: AnthropicRole::User,
                content: vec![FlattenUnknown::Normal(AnthropicMessageContent::Text {
                    text: "test"
                })],
            }
        );

        // Test an Assistant message
        let inference_request_message = RequestMessage {
            role: Role::Assistant,
            content: vec!["test_assistant".to_string().into()],
        };
        let anthropic_message = AnthropicMessage::from_request_message(
            &inference_request_message,
            AnthropicMessagesConfig {
                fetch_and_encode_input_files_before_inference: false,
            },
            PROVIDER_TYPE,
        )
        .await
        .unwrap();
        assert_eq!(
            anthropic_message,
            AnthropicMessage {
                role: AnthropicRole::Assistant,
                content: vec![FlattenUnknown::Normal(AnthropicMessageContent::Text {
                    text: "test_assistant",
                })],
            }
        );

        // Test a Tool message
        let inference_request_message = RequestMessage {
            role: Role::User,
            content: vec![ContentBlock::ToolResult(ToolResult {
                id: "test_tool_call_id".to_string(),
                name: "test_tool_name".to_string(),
                result: "test_tool_response".to_string(),
            })],
        };
        let anthropic_message = AnthropicMessage::from_request_message(
            &inference_request_message,
            AnthropicMessagesConfig {
                fetch_and_encode_input_files_before_inference: false,
            },
            PROVIDER_TYPE,
        )
        .await
        .unwrap();
        assert_eq!(
            anthropic_message,
            AnthropicMessage {
                role: AnthropicRole::User,
                content: vec![FlattenUnknown::Normal(
                    AnthropicMessageContent::ToolResult {
                        tool_use_id: "test_tool_call_id",
                        content: vec![AnthropicMessageContent::Text {
                            text: "test_tool_response"
                        }],
                    }
                )],
            }
        );
    }

    #[tokio::test]
    async fn test_initialize_anthropic_request_body() {
        let model = "claude-3-7-sonnet-latest".to_string();
        // Test Case 1: Empty message list
        let inference_request = ModelInferenceRequest {
            inference_id: Uuid::now_v7(),
            messages: vec![],
            system: None,
            tool_config: None,
            temperature: None,
            top_p: None,
            presence_penalty: None,
            frequency_penalty: None,
            max_tokens: None,
            seed: None,
            stream: false,
            json_mode: ModelInferenceRequestJsonMode::Off,
            function_type: FunctionType::Chat,
            output_schema: None,
            extra_body: Default::default(),
            ..Default::default()
        };
        let anthropic_request_body =
            AnthropicRequestBody::new(&model, &inference_request, &[]).await;
        let error = anthropic_request_body.unwrap_err();
        let details = error.get_details();
        assert_eq!(
            *details,
            ErrorDetails::InvalidRequest {
                message: "Anthropic requires at least one message".to_string(),
            }
        );

        // Test Case 2: Messages starting with Assistant - should prepend and append listening message
        let messages = vec![RequestMessage {
            role: Role::Assistant,
            content: vec!["test_assistant".to_string().into()],
        }];
        let inference_request = ModelInferenceRequest {
            inference_id: Uuid::now_v7(),
            messages,
            system: Some("test_system".to_string()),
            tool_config: None,
            temperature: None,
            top_p: None,
            presence_penalty: None,
            frequency_penalty: None,
            max_tokens: None,
            seed: None,
            stream: false,
            json_mode: ModelInferenceRequestJsonMode::Off,
            function_type: FunctionType::Chat,
            output_schema: None,
            extra_body: Default::default(),
            ..Default::default()
        };
        let anthropic_request_body =
            AnthropicRequestBody::new(&model, &inference_request, &[]).await;
        assert!(anthropic_request_body.is_ok());
        assert_eq!(
            anthropic_request_body.unwrap(),
            AnthropicRequestBody {
                model: &model,
                messages: vec![
                    AnthropicMessage::from_request_message(
                        &inference_request.messages[0],
                        AnthropicMessagesConfig {
                            fetch_and_encode_input_files_before_inference: false,
                        },
                        PROVIDER_TYPE,
                    )
                    .await
                    .unwrap(),
                ],
                max_tokens: 64_000,
                stream: Some(false),
                system: Some(vec![AnthropicSystemBlock::Text {
                    text: "test_system"
                }]),
                ..Default::default()
            }
        );

        // Test Case 3: Messages ending with Assistant - should append listening message
        let messages = vec![
            RequestMessage {
                role: Role::User,
                content: vec!["test_user".to_string().into()],
            },
            RequestMessage {
                role: Role::Assistant,
                content: vec!["test_assistant".to_string().into()],
            },
        ];
        let inference_request = ModelInferenceRequest {
            inference_id: Uuid::now_v7(),
            messages,
            system: Some("test_system".to_string()),
            tool_config: None,
            temperature: Some(0.5),
            top_p: None,
            presence_penalty: None,
            frequency_penalty: None,
            max_tokens: Some(100),
            seed: None,
            stream: true,
            json_mode: ModelInferenceRequestJsonMode::Off,
            function_type: FunctionType::Chat,
            output_schema: None,
            extra_body: Default::default(),
            ..Default::default()
        };
        let anthropic_request_body =
            AnthropicRequestBody::new(&model, &inference_request, &[]).await;
        assert!(anthropic_request_body.is_ok());
        assert_eq!(
            anthropic_request_body.unwrap(),
            AnthropicRequestBody {
                model: &model,
                messages: vec![
                    AnthropicMessage::from_request_message(
                        &inference_request.messages[0],
                        AnthropicMessagesConfig {
                            fetch_and_encode_input_files_before_inference: false,
                        },
                        PROVIDER_TYPE,
                    )
                    .await
                    .unwrap(),
                    AnthropicMessage::from_request_message(
                        &inference_request.messages[1],
                        AnthropicMessagesConfig {
                            fetch_and_encode_input_files_before_inference: false,
                        },
                        PROVIDER_TYPE,
                    )
                    .await
                    .unwrap(),
                ],
                max_tokens: 100,
                stream: Some(true),
                system: Some(vec![AnthropicSystemBlock::Text {
                    text: "test_system"
                }]),
                temperature: Some(0.5),
                ..Default::default()
            }
        );

        // Test Case 4: Valid message sequence - no changes needed
        let messages = vec![
            RequestMessage {
                role: Role::User,
                content: vec!["test_user".to_string().into()],
            },
            RequestMessage {
                role: Role::Assistant,
                content: vec!["test_assistant".to_string().into()],
            },
            RequestMessage {
                role: Role::User,
                content: vec!["test_user2".to_string().into()],
            },
        ];
        let inference_request = ModelInferenceRequest {
            inference_id: Uuid::now_v7(),
            messages,
            system: None,
            tool_config: None,
            temperature: None,
            top_p: None,
            presence_penalty: None,
            frequency_penalty: None,
            max_tokens: None,
            seed: None,
            stream: false,
            json_mode: ModelInferenceRequestJsonMode::Off,
            function_type: FunctionType::Chat,
            output_schema: None,
            extra_body: Default::default(),
            ..Default::default()
        };
        let anthropic_request_body =
            AnthropicRequestBody::new(&model, &inference_request, &[]).await;
        assert!(anthropic_request_body.is_ok());
        // Convert messages asynchronously
        let expected_messages = try_join_all(inference_request.messages.iter().map(|m| {
            AnthropicMessage::from_request_message(
                m,
                AnthropicMessagesConfig {
                    fetch_and_encode_input_files_before_inference: false,
                },
                PROVIDER_TYPE,
            )
        }))
        .await
        .unwrap();

        assert_eq!(
            anthropic_request_body.unwrap(),
            AnthropicRequestBody {
                model: &model,
                messages: expected_messages,
                max_tokens: 64_000,
                stream: Some(false),
                ..Default::default()
            }
        );

        // Test Case 5: Tool use with JSON mode
        let messages = vec![
            RequestMessage {
                role: Role::User,
                content: vec!["test_user".to_string().into()],
            },
            RequestMessage {
                role: Role::Assistant,
                content: vec![ContentBlock::ToolCall(ToolCall {
                    id: "test_id".to_string(),
                    name: "get_temperature".to_string(),
                    arguments: r#"{"location":"London"}"#.to_string(),
                })],
            },
        ];
        let inference_request = ModelInferenceRequest {
            inference_id: Uuid::now_v7(),
            messages,
            system: None,
            tool_config: Some(Cow::Borrowed(&WEATHER_TOOL_CONFIG)),
            temperature: None,
            top_p: None,
            presence_penalty: None,
            frequency_penalty: None,
            max_tokens: None,
            seed: None,
            stream: false,
            json_mode: ModelInferenceRequestJsonMode::On,
            function_type: FunctionType::Json,
            output_schema: None,
            extra_body: Default::default(),
            ..Default::default()
        };
        let anthropic_request_body =
            AnthropicRequestBody::new(&model, &inference_request, &[]).await;
        assert!(anthropic_request_body.is_ok());
        let result = anthropic_request_body.unwrap();
        assert_eq!(result.messages.len(), 3); // Original 2 messages + JSON prefill
        assert_eq!(
            result.messages[0],
            AnthropicMessage::from_request_message(
                &inference_request.messages[0],
                AnthropicMessagesConfig {
                    fetch_and_encode_input_files_before_inference: false,
                },
                PROVIDER_TYPE,
            )
            .await
            .unwrap()
        );
        assert_eq!(
            result.messages[1],
            AnthropicMessage::from_request_message(
                &inference_request.messages[1],
                AnthropicMessagesConfig {
                    fetch_and_encode_input_files_before_inference: false,
                },
                PROVIDER_TYPE,
            )
            .await
            .unwrap()
        );
        assert_eq!(
            result.messages[2],
            AnthropicMessage {
                role: AnthropicRole::Assistant,
                content: vec![FlattenUnknown::Normal(AnthropicMessageContent::Text {
                    text: "Here is the JSON requested:\n{",
                })],
            }
        );
    }

    #[tokio::test]
    async fn test_get_default_max_tokens_in_new_anthropic_request_body() {
        let messages = vec![RequestMessage {
            role: Role::User,
            content: vec!["Hello".to_string().into()],
        }];

        let request = ModelInferenceRequest {
            messages: messages.clone(),
            ..Default::default()
        };

        let request_with_max_tokens = ModelInferenceRequest {
            messages,
            max_tokens: Some(100),
            ..Default::default()
        };

        let model = "claude-opus-4-1-20250805".to_string();
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 32_000);
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-opus-4-20250514".to_string();
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 32_000);
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-sonnet-4-20250514".to_string();
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 64_000);
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-3-7-sonnet-20250219".to_string();
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 64_000);
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-3-5-sonnet-20241022".to_string();
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 8_192);
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-3-5-haiku-20241022".to_string();
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 8_192);
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-opus-4-1".to_string();
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 32_000);
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-opus-4-0".to_string();
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 32_000);
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-sonnet-4-0".to_string();
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 64_000);
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-3-7-sonnet-latest".to_string();
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 64_000);
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-3-5-sonnet-latest".to_string();
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 8_192);
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-3-5-haiku-latest".to_string();
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 8_192);
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-3-haiku-20240307".to_string();
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 4_096);
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-haiku-4-5-20251001".to_string();
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 64_000);
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-sonnet-4-5-20250929".to_string();
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 64_000);
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-opus-4-6".to_string();
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert_eq!(
            body.unwrap().max_tokens,
            128_000,
            "expected unversioned claude-opus-4-6 to default to 128k max tokens"
        );
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-opus-4-6-20260601".to_string();
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert_eq!(
            body.unwrap().max_tokens,
            128_000,
            "expected versioned claude-opus-4-6 model ids to default to 128k max tokens"
        );
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-3-5-ballad-latest".to_string(); // fake model
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert!(body.is_err());
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);

        let model = "claude-4-5-haiku-20260101".to_string(); // fake model
        let body = AnthropicRequestBody::new(&model, &request, &[]).await;
        assert!(body.is_err());
        let body = AnthropicRequestBody::new(&model, &request_with_max_tokens, &[]).await;
        assert_eq!(body.unwrap().max_tokens, 100);
    }

    #[test]
    fn test_handle_anthropic_error() {
        let response_code = StatusCode::BAD_REQUEST;
        let result = handle_anthropic_error(
            response_code,
            "raw request".to_string(),
            "raw response".to_string(),
            ApiType::ChatCompletions,
        );
        let error = result.unwrap_err();
        let details = error.get_details();
        assert_eq!(
            *details,
            ErrorDetails::InferenceClient {
                message: "raw response".to_string(),
                status_code: Some(response_code),
                provider_type: PROVIDER_TYPE.to_string(),
                api_type: ApiType::ChatCompletions,
                raw_request: Some("raw request".to_string()),
                raw_response: Some("raw response".to_string()),
            }
        );
        let response_code = StatusCode::UNAUTHORIZED;
        let result = handle_anthropic_error(
            response_code,
            "raw request".to_string(),
            "raw response".to_string(),
            ApiType::ChatCompletions,
        );
        let error = result.unwrap_err();
        let details = error.get_details();
        assert_eq!(
            *details,
            ErrorDetails::InferenceClient {
                message: "raw response".to_string(),
                status_code: Some(response_code),
                provider_type: PROVIDER_TYPE.to_string(),
                api_type: ApiType::ChatCompletions,
                raw_request: Some("raw request".to_string()),
                raw_response: Some("raw response".to_string()),
            }
        );
        let response_code = StatusCode::TOO_MANY_REQUESTS;
        let result = handle_anthropic_error(
            response_code,
            "raw request".to_string(),
            "raw response".to_string(),
            ApiType::ChatCompletions,
        );
        let error = result.unwrap_err();
        let details = error.get_details();
        assert_eq!(
            *details,
            ErrorDetails::InferenceClient {
                message: "raw response".to_string(),
                status_code: Some(response_code),
                provider_type: PROVIDER_TYPE.to_string(),
                api_type: ApiType::ChatCompletions,
                raw_request: Some("raw request".to_string()),
                raw_response: Some("raw response".to_string()),
            }
        );
        let response_code = StatusCode::NOT_FOUND;
        let result = handle_anthropic_error(
            response_code,
            "raw request".to_string(),
            "raw response".to_string(),
            ApiType::ChatCompletions,
        );
        let error = result.unwrap_err();
        let details = error.get_details();
        assert_eq!(
            *details,
            ErrorDetails::InferenceServer {
                message: "raw response".to_string(),
                raw_request: Some("raw request".to_string()),
                raw_response: Some("raw response".to_string()),
                provider_type: PROVIDER_TYPE.to_string(),
                api_type: ApiType::ChatCompletions,
            }
        );
        let response_code = StatusCode::INTERNAL_SERVER_ERROR;
        let result = handle_anthropic_error(
            response_code,
            "raw request".to_string(),
            "raw response".to_string(),
            ApiType::ChatCompletions,
        );
        let error = result.unwrap_err();
        let details = error.get_details();
        assert_eq!(
            *details,
            ErrorDetails::InferenceServer {
                message: "raw response".to_string(),
                raw_request: Some("raw request".to_string()),
                raw_response: Some("raw response".to_string()),
                provider_type: PROVIDER_TYPE.to_string(),
                api_type: ApiType::ChatCompletions,
            }
        );
    }

    #[test]
    fn test_anthropic_usage_to_usage() {
        let anthropic_usage = AnthropicUsage {
            input_tokens: Some(100),
            output_tokens: Some(50),
            ..Default::default()
        };

        let usage: Usage = anthropic_usage.into_usage();

        assert_eq!(usage.input_tokens, Some(100), "input_tokens should match");
        assert_eq!(usage.output_tokens, Some(50), "output_tokens should match");

        // Test with None values
        let anthropic_usage = AnthropicUsage {
            input_tokens: None,
            output_tokens: Some(100),
            ..Default::default()
        };

        let usage: Usage = anthropic_usage.into_usage();

        assert_eq!(
            usage.input_tokens, None,
            "input_tokens should be None when not provided"
        );
        assert_eq!(usage.output_tokens, Some(100), "output_tokens should match");

        // Test with cache tokens
        let anthropic_usage = AnthropicUsage {
            input_tokens: Some(10),
            output_tokens: Some(50),
            cache_creation_input_tokens: Some(100),
            cache_read_input_tokens: Some(200),
        };

        let usage: Usage = anthropic_usage.into_usage();

        assert_eq!(
            usage.input_tokens,
            Some(310),
            "input_tokens should include cache tokens (10 + 100 + 200)"
        );
        assert_eq!(usage.output_tokens, Some(50), "output_tokens should match");
        assert_eq!(
            usage.provider_cache_read_input_tokens,
            Some(200),
            "provider_cache_read_input_tokens should be forwarded from Anthropic"
        );
        assert_eq!(
            usage.provider_cache_write_input_tokens,
            Some(100),
            "provider_cache_write_input_tokens should map from cache_creation_input_tokens"
        );

        // Test cache write only (first request to a new prompt)
        let anthropic_usage = AnthropicUsage {
            input_tokens: Some(10),
            output_tokens: Some(50),
            cache_creation_input_tokens: Some(4000),
            cache_read_input_tokens: None,
        };

        let usage: Usage = anthropic_usage.into_usage();

        assert_eq!(
            usage.input_tokens,
            Some(4010),
            "input_tokens should include cache_creation tokens"
        );
        assert_eq!(
            usage.provider_cache_write_input_tokens,
            Some(4000),
            "cache_write should be set on first request"
        );
        assert_eq!(
            usage.provider_cache_read_input_tokens, None,
            "cache_read should be None on first request"
        );

        // Test cache read only (subsequent request with same prompt)
        let anthropic_usage = AnthropicUsage {
            input_tokens: Some(10),
            output_tokens: Some(50),
            cache_creation_input_tokens: None,
            cache_read_input_tokens: Some(4000),
        };

        let usage: Usage = anthropic_usage.into_usage();

        assert_eq!(
            usage.input_tokens,
            Some(4010),
            "input_tokens should include cache_read tokens"
        );
        assert_eq!(
            usage.provider_cache_write_input_tokens, None,
            "cache_write should be None on cache hit"
        );
        assert_eq!(
            usage.provider_cache_read_input_tokens,
            Some(4000),
            "cache_read should be set on cache hit"
        );

        // Test no cache tokens (provider doesn't support caching)
        let anthropic_usage = AnthropicUsage {
            input_tokens: Some(100),
            output_tokens: Some(50),
            cache_creation_input_tokens: None,
            cache_read_input_tokens: None,
        };

        let usage: Usage = anthropic_usage.into_usage();

        assert_eq!(usage.provider_cache_read_input_tokens, None);
        assert_eq!(usage.provider_cache_write_input_tokens, None);
    }

    #[test]
    fn test_anthropic_usage_deserialization_with_cache_tokens() {
        // Simulate a real Anthropic API response usage block with cache write
        let json = r#"{
            "input_tokens": 15,
            "output_tokens": 30,
            "cache_creation_input_tokens": 4200,
            "cache_read_input_tokens": 0
        }"#;
        let anthropic_usage: AnthropicUsage = serde_json::from_str(json)
            .expect("should deserialize Anthropic usage with cache tokens");
        let usage: Usage = anthropic_usage.into_usage();
        assert_eq!(usage.input_tokens, Some(4215));
        assert_eq!(usage.provider_cache_write_input_tokens, Some(4200));
        assert_eq!(usage.provider_cache_read_input_tokens, Some(0));

        // Simulate cache read response
        let json = r#"{
            "input_tokens": 15,
            "output_tokens": 42,
            "cache_creation_input_tokens": 0,
            "cache_read_input_tokens": 4200
        }"#;
        let anthropic_usage: AnthropicUsage =
            serde_json::from_str(json).expect("should deserialize Anthropic usage with cache read");
        let usage: Usage = anthropic_usage.into_usage();
        assert_eq!(usage.input_tokens, Some(4215));
        assert_eq!(usage.provider_cache_write_input_tokens, Some(0));
        assert_eq!(usage.provider_cache_read_input_tokens, Some(4200));

        // Simulate response with no cache fields at all
        let json = r#"{
            "input_tokens": 100,
            "output_tokens": 50
        }"#;
        let anthropic_usage: AnthropicUsage =
            serde_json::from_str(json).expect("should deserialize without cache fields");
        let usage: Usage = anthropic_usage.into_usage();
        assert_eq!(usage.input_tokens, Some(100));
        assert_eq!(usage.provider_cache_write_input_tokens, None);
        assert_eq!(usage.provider_cache_read_input_tokens, None);
    }

    #[test]
    fn test_anthropic_response_conversion() {
        // Test case 1: Text response
        let anthropic_response_body = AnthropicResponse {
            id: "1".to_string(),
            r#type: "message".to_string(),
            role: "assistant".to_string(),
            content: vec![FlattenUnknown::Normal(AnthropicContentBlock::Text {
                text: "Response text".to_string(),
            })],
            model: "model-name".into(),
            stop_reason: Some(AnthropicStopReason::EndTurn),
            stop_sequence: Some("stop sequence".to_string()),
            usage: AnthropicUsage {
                input_tokens: Some(100),
                output_tokens: Some(50),
                ..Default::default()
            },
        };
        let generic_request = ModelInferenceRequest {
            inference_id: Uuid::now_v7(),
            messages: vec![RequestMessage {
                role: Role::User,
                content: vec!["test_user".to_string().into()],
            }],
            system: None,
            temperature: Some(0.5),
            max_tokens: Some(100),
            seed: Some(69),
            top_p: Some(0.9),
            presence_penalty: Some(0.1),
            frequency_penalty: Some(0.2),
            stream: false,
            json_mode: ModelInferenceRequestJsonMode::On,
            tool_config: None,
            function_type: FunctionType::Chat,
            output_schema: None,
            extra_body: Default::default(),
            ..Default::default()
        };
        let latency = Latency::NonStreaming {
            response_time: Duration::from_millis(100),
        };
        let request_body = AnthropicRequestBody {
            model: "model-name",
            messages: vec![],
            max_tokens: 100,
            stream: Some(false),
            system: None,
            top_p: Some(0.5),
            ..Default::default()
        };
        let raw_response = "{\"foo\": \"bar\"}".to_string();
        let input_messages = vec![RequestMessage {
            role: Role::User,
            content: vec!["Hello".to_string().into()],
        }];
        let raw_request = serde_json::to_string(&request_body).unwrap();
        let body_with_latency = AnthropicResponseWithMetadata {
            response: anthropic_response_body.clone(),
            raw_response: raw_response.clone(),
            latency: latency.clone(),
            raw_request: raw_request.clone(),
            generic_request: &generic_request,
            input_messages: input_messages.clone(),
            model_name: "model-name",
            provider_name: "dummy",
            model_inference_id: Uuid::now_v7(),
        };

        let inference_response = ProviderInferenceResponse::try_from(body_with_latency).unwrap();
        assert_eq!(
            inference_response.output,
            vec!["Response text".to_string().into()]
        );

        assert_eq!(raw_response, inference_response.raw_response);
        assert_eq!(inference_response.usage.input_tokens, Some(100));
        assert_eq!(inference_response.usage.output_tokens, Some(50));
        assert_eq!(inference_response.finish_reason, Some(FinishReason::Stop));
        assert_eq!(inference_response.provider_latency, latency);
        assert_eq!(inference_response.raw_request, raw_request);
        assert_eq!(inference_response.input_messages, input_messages);

        // Test case 2: Tool call response
        let anthropic_response_body = AnthropicResponse {
            id: "2".to_string(),
            r#type: "message".to_string(),
            role: "assistant".to_string(),
            content: vec![FlattenUnknown::Normal(AnthropicContentBlock::ToolUse {
                id: "tool_call_1".to_string(),
                name: "get_temperature".to_string(),
                input: json!({"location": "New York"}),
            })],
            model: "model-name".into(),
            stop_reason: Some(AnthropicStopReason::ToolUse),
            stop_sequence: None,
            usage: AnthropicUsage {
                input_tokens: Some(100),
                output_tokens: Some(50),
                ..Default::default()
            },
        };
        let request_body = AnthropicRequestBody {
            model: "model-name",
            messages: vec![],
            max_tokens: 100,
            stream: Some(false),
            top_p: Some(0.5),
            ..Default::default()
        };
        let input_messages = vec![RequestMessage {
            role: Role::Assistant,
            content: vec!["Hello".to_string().into()],
        }];
        let raw_request = serde_json::to_string(&request_body).unwrap();
        let body_with_latency = AnthropicResponseWithMetadata {
            response: anthropic_response_body.clone(),
            raw_response: raw_response.clone(),
            latency: latency.clone(),
            raw_request: raw_request.clone(),
            generic_request: &generic_request,
            input_messages: input_messages.clone(),
            model_name: "model-name",
            provider_name: "dummy",
            model_inference_id: Uuid::now_v7(),
        };

        let inference_response: ProviderInferenceResponse = body_with_latency.try_into().unwrap();
        assert!(inference_response.output.len() == 1);
        assert_eq!(
            inference_response.output[0],
            ContentBlockOutput::ToolCall(ToolCall {
                id: "tool_call_1".to_string(),
                name: "get_temperature".to_string(),
                arguments: r#"{"location":"New York"}"#.to_string(),
            })
        );

        assert_eq!(raw_response, inference_response.raw_response);
        assert_eq!(inference_response.usage.input_tokens, Some(100));
        assert_eq!(inference_response.usage.output_tokens, Some(50));
        assert_eq!(inference_response.provider_latency, latency);
        assert_eq!(inference_response.raw_request, raw_request);
        assert_eq!(
            inference_response.finish_reason,
            Some(FinishReason::ToolCall)
        );
        assert_eq!(inference_response.input_messages, input_messages);

        // Test case 3: Mixed response (text and tool call)
        let anthropic_response_body = AnthropicResponse {
            id: "3".to_string(),
            r#type: "message".to_string(),
            role: "assistant".to_string(),
            content: vec![
                FlattenUnknown::Normal(AnthropicContentBlock::Text {
                    text: "Here's the weather:".to_string(),
                }),
                FlattenUnknown::Normal(AnthropicContentBlock::ToolUse {
                    id: "tool_call_2".to_string(),
                    name: "get_temperature".to_string(),
                    input: json!({"location": "London"}),
                }),
            ],
            model: "model-name".into(),
            stop_reason: None,
            stop_sequence: None,
            usage: AnthropicUsage {
                input_tokens: Some(100),
                output_tokens: Some(50),
                ..Default::default()
            },
        };
        let request_body = AnthropicRequestBody {
            model: "model-name",
            messages: vec![],
            max_tokens: 100,
            stream: Some(false),
            top_p: Some(0.5),
            ..Default::default()
        };
        let input_messages = vec![RequestMessage {
            role: Role::User,
            content: vec!["Helloooo".to_string().into()],
        }];
        let raw_request = serde_json::to_string(&request_body).unwrap();
        let body_with_latency = AnthropicResponseWithMetadata {
            response: anthropic_response_body.clone(),
            raw_response: raw_response.clone(),
            latency: latency.clone(),
            raw_request: raw_request.clone(),
            generic_request: &generic_request,
            input_messages: input_messages.clone(),
            model_name: "model-name",
            provider_name: "dummy",
            model_inference_id: Uuid::now_v7(),
        };
        let inference_response = ProviderInferenceResponse::try_from(body_with_latency).unwrap();
        assert_eq!(
            inference_response.output[0],
            "Here's the weather:".to_string().into()
        );
        assert!(inference_response.output.len() == 2);
        assert_eq!(
            inference_response.output[1],
            ContentBlockOutput::ToolCall(ToolCall {
                id: "tool_call_2".to_string(),
                name: "get_temperature".to_string(),
                arguments: r#"{"location":"London"}"#.to_string(),
            })
        );

        assert_eq!(raw_response, inference_response.raw_response);

        assert_eq!(inference_response.usage.input_tokens, Some(100));
        assert_eq!(inference_response.usage.output_tokens, Some(50));
        assert_eq!(inference_response.finish_reason, None);
        assert_eq!(inference_response.provider_latency, latency);
        assert_eq!(inference_response.raw_request, raw_request);
        assert_eq!(inference_response.input_messages, input_messages);
    }

    #[test]
    fn test_anthropic_to_tensorzero_stream_message() {
        use serde_json::json;

        // Test ContentBlockDelta with TextDelta
        let mut tool_state: HashMap<u32, (String, String)> = HashMap::new();
        let content_block_delta = AnthropicStreamMessage::ContentBlockDelta {
            delta: FlattenUnknown::Normal(AnthropicContentBlockDelta::TextDelta {
                text: "Hello".to_string(),
            }),
            index: 0,
        };
        let latency = Duration::from_millis(100);
        let result = anthropic_to_tensorzero_stream_message(
            "my_raw_chunk".to_string(),
            content_block_delta,
            latency,
            &mut tool_state,
            false,
            "test_model",
            "test_provider",
            PROVIDER_TYPE,
            Uuid::now_v7(),
        );
        assert!(result.is_ok());
        let chunk = result.unwrap().unwrap();
        assert_eq!(chunk.content.len(), 1);
        match &chunk.content[0] {
            ContentBlockChunk::Text(text) => {
                assert_eq!(text.text, "Hello".to_string());
                assert_eq!(text.id, "0".to_string());
            }
            _ => panic!("Expected a text content block"),
        }
        assert_eq!(chunk.provider_latency, latency);

        // Test ContentBlockDelta with InputJsonDelta but no previous tool info
        let mut tool_state: HashMap<u32, (String, String)> = HashMap::new();
        let content_block_delta = AnthropicStreamMessage::ContentBlockDelta {
            delta: FlattenUnknown::Normal(AnthropicContentBlockDelta::InputJsonDelta {
                partial_json: "aaaa: bbbbb".to_string(),
            }),
            index: 0,
        };
        let latency = Duration::from_millis(100);
        let result = anthropic_to_tensorzero_stream_message(
            "my_raw_chunk".to_string(),
            content_block_delta,
            latency,
            &mut tool_state,
            false,
            "test_model",
            "test_provider",
            PROVIDER_TYPE,
            Uuid::now_v7(),
        );
        let error = result.unwrap_err();
        let details = error.get_details();
        assert_eq!(
            *details,
            ErrorDetails::InferenceServer {
                message: "Got InputJsonDelta chunk from Anthropic for index 0 without a preceding ToolUse ContentBlockStart".to_string(),
                raw_request: None,
                raw_response: None,
                provider_type: PROVIDER_TYPE.to_string(),
                api_type: ApiType::ChatCompletions,
            }
        );

        // Test ContentBlockDelta with InputJsonDelta and previous tool info
        let mut tool_state: HashMap<u32, (String, String)> = HashMap::new();
        tool_state.insert(0, ("tool_id".to_string(), "tool_name".to_string()));
        let content_block_delta = AnthropicStreamMessage::ContentBlockDelta {
            delta: FlattenUnknown::Normal(AnthropicContentBlockDelta::InputJsonDelta {
                partial_json: "aaaa: bbbbb".to_string(),
            }),
            index: 0,
        };
        let latency = Duration::from_millis(100);
        let result = anthropic_to_tensorzero_stream_message(
            "my_raw_chunk".to_string(),
            content_block_delta,
            latency,
            &mut tool_state,
            false,
            "test_model",
            "test_provider",
            PROVIDER_TYPE,
            Uuid::now_v7(),
        );
        let chunk = result.unwrap().unwrap();
        assert_eq!(chunk.content.len(), 1);
        match &chunk.content[0] {
            ContentBlockChunk::ToolCall(tool_call) => {
                assert_eq!(tool_call.id, "tool_id".to_string());
                assert_eq!(tool_call.raw_name, None); // We don't add the tool name if it isn't in the contentBlockDelta
                assert_eq!(tool_call.raw_arguments, "aaaa: bbbbb".to_string());
            }
            _ => panic!("Expected a tool call content block"),
        }
        assert_eq!(chunk.provider_latency, latency);

        // Test ContentBlockStart with ToolUse
        let mut tool_state: HashMap<u32, (String, String)> = HashMap::new();
        let content_block_start = AnthropicStreamMessage::ContentBlockStart {
            content_block: FlattenUnknown::Normal(AnthropicContentBlock::ToolUse {
                id: "tool1".to_string(),
                name: "calculator".to_string(),
                input: json!({}),
            }),
            index: 1,
        };
        let latency = Duration::from_millis(110);
        let result = anthropic_to_tensorzero_stream_message(
            "my_raw_chunk".to_string(),
            content_block_start,
            latency,
            &mut tool_state,
            false,
            "test_model",
            "test_provider",
            PROVIDER_TYPE,
            Uuid::now_v7(),
        )
        .unwrap();
        let chunk = result.unwrap();
        assert_eq!(chunk.content.len(), 1);
        match &chunk.content[0] {
            ContentBlockChunk::ToolCall(tool_call) => {
                assert_eq!(tool_call.id, "tool1".to_string());
                assert_eq!(tool_call.raw_name, Some("calculator".to_string()));
                assert_eq!(tool_call.raw_arguments, String::new());
            }
            _ => panic!("Expected a tool call content block"),
        }
        assert_eq!(chunk.provider_latency, latency);
        assert_eq!(
            tool_state.get(&1),
            Some(&("tool1".to_string(), "calculator".to_string())),
            "Tool state should be stored by index"
        );

        // Test ContentBlockStart with Text
        let mut tool_state: HashMap<u32, (String, String)> = HashMap::new();
        let content_block_start = AnthropicStreamMessage::ContentBlockStart {
            content_block: FlattenUnknown::Normal(AnthropicContentBlock::Text {
                text: "Hello".to_string(),
            }),
            index: 2,
        };
        let latency = Duration::from_millis(120);
        let result = anthropic_to_tensorzero_stream_message(
            "my_raw_chunk".to_string(),
            content_block_start,
            latency,
            &mut tool_state,
            false,
            "test_model",
            "test_provider",
            PROVIDER_TYPE,
            Uuid::now_v7(),
        );
        let chunk = result.unwrap().unwrap();
        assert_eq!(chunk.content.len(), 1);
        match &chunk.content[0] {
            ContentBlockChunk::Text(text) => {
                assert_eq!(text.text, "Hello".to_string());
                assert_eq!(text.id, "2".to_string());
            }
            _ => panic!("Expected a text content block"),
        }
        assert_eq!(chunk.provider_latency, latency);

        // Test ContentBlockStop
        let content_block_stop = AnthropicStreamMessage::ContentBlockStop { index: 2 };
        let latency = Duration::from_millis(120);
        let result = anthropic_to_tensorzero_stream_message(
            "my_raw_chunk".to_string(),
            content_block_stop,
            latency,
            &mut tool_state,
            false,
            "test_model",
            "test_provider",
            PROVIDER_TYPE,
            Uuid::now_v7(),
        );
        assert!(result.is_ok());
        assert!(result.unwrap().is_none());

        // Test Error
        let error_message = AnthropicStreamMessage::Error {
            error: json!({"message": "Test error"}),
        };
        let latency = Duration::from_millis(130);
        let result = anthropic_to_tensorzero_stream_message(
            "my_raw_chunk".to_string(),
            error_message,
            latency,
            &mut tool_state,
            false,
            "test_model",
            "test_provider",
            PROVIDER_TYPE,
            Uuid::now_v7(),
        );
        let error = result.unwrap_err();
        let details = error.get_details();
        assert_eq!(
            *details,
            ErrorDetails::InferenceServer {
                message: r#"{"message":"Test error"}"#.to_string(),
                raw_request: None,
                raw_response: None,
                provider_type: PROVIDER_TYPE.to_string(),
                api_type: ApiType::ChatCompletions,
            }
        );

        // Test MessageDelta with usage
        let message_delta = AnthropicStreamMessage::MessageDelta {
            delta: FlattenUnknown::Normal(AnthropicMessageDelta {
                stop_reason: Some(AnthropicStopReason::EndTurn),
                stop_sequence: None,
            }),
            usage: json!({"input_tokens": 10, "output_tokens": 20}),
        };
        let latency = Duration::from_millis(140);
        let result = anthropic_to_tensorzero_stream_message(
            "my_raw_chunk".to_string(),
            message_delta,
            latency,
            &mut tool_state,
            false,
            "test_model",
            "test_provider",
            PROVIDER_TYPE,
            Uuid::now_v7(),
        );
        assert!(result.is_ok());
        let chunk = result.unwrap().unwrap();
        assert_eq!(chunk.content.len(), 0);
        assert!(chunk.usage.is_some());
        let usage = chunk.usage.unwrap();
        assert_eq!(usage.input_tokens, Some(10));
        assert_eq!(usage.output_tokens, Some(20));
        assert_eq!(chunk.provider_latency, latency);
        assert_eq!(chunk.finish_reason, Some(FinishReason::Stop));

        // Test MessageStart with usage
        let message_start = AnthropicStreamMessage::MessageStart {
            message: json!({"usage": {"input_tokens": 5, "output_tokens": 15}}),
        };
        let latency = Duration::from_millis(150);
        let result = anthropic_to_tensorzero_stream_message(
            "my_raw_chunk".to_string(),
            message_start,
            latency,
            &mut tool_state,
            false,
            "test_model",
            "test_provider",
            PROVIDER_TYPE,
            Uuid::now_v7(),
        );
        assert!(result.is_ok());
        let chunk = result.unwrap().unwrap();
        assert_eq!(chunk.content.len(), 0);
        assert!(chunk.usage.is_some());
        let usage = chunk.usage.unwrap();
        assert_eq!(usage.input_tokens, Some(5));
        assert_eq!(usage.output_tokens, Some(15));
        assert_eq!(chunk.provider_latency, latency);

        // Test MessageStop
        let message_stop = AnthropicStreamMessage::MessageStop;
        let latency = Duration::from_millis(160);
        let result = anthropic_to_tensorzero_stream_message(
            "my_raw_chunk".to_string(),
            message_stop,
            latency,
            &mut tool_state,
            false,
            "test_model",
            "test_provider",
            PROVIDER_TYPE,
            Uuid::now_v7(),
        );
        assert!(result.is_ok());
        assert!(result.unwrap().is_none());

        // Test Ping
        let ping = AnthropicStreamMessage::Ping {};
        let latency = Duration::from_millis(170);
        let result = anthropic_to_tensorzero_stream_message(
            "my_raw_chunk".to_string(),
            ping,
            latency,
            &mut tool_state,
            false,
            "test_model",
            "test_provider",
            PROVIDER_TYPE,
            Uuid::now_v7(),
        );
        assert!(result.is_ok());
        assert!(result.unwrap().is_none());
    }

    #[test]
    fn test_parse_usage_info() {
        // Test with valid input
        let usage_info = json!({
            "input_tokens": 100,
            "output_tokens": 200
        });
        let result = parse_usage_info(&usage_info);
        assert_eq!(
            result,
            AnthropicUsage {
                input_tokens: Some(100),
                output_tokens: Some(200),
                ..Default::default()
            },
            "both fields should be Some when present"
        );

        // Test with missing output_tokens
        let usage_info = json!({
            "input_tokens": 50
        });
        let result = parse_usage_info(&usage_info);
        assert_eq!(
            result,
            AnthropicUsage {
                input_tokens: Some(50),
                output_tokens: None,
                ..Default::default()
            },
            "output_tokens should be None when missing"
        );

        // Test with missing input_tokens (like Anthropic's message_delta)
        let usage_info = json!({
            "output_tokens": 100
        });
        let result = parse_usage_info(&usage_info);
        assert_eq!(
            result,
            AnthropicUsage {
                input_tokens: None,
                output_tokens: Some(100),
                ..Default::default()
            },
            "input_tokens should be None when missing"
        );

        // Test with empty object
        let usage_info = json!({});
        let result = parse_usage_info(&usage_info);
        assert_eq!(
            result,
            AnthropicUsage {
                input_tokens: None,
                output_tokens: None,
                ..Default::default()
            },
            "both fields should be None for empty object"
        );

        // Test with non-numeric values (falls back to default)
        let usage_info = json!({
            "input_tokens": "not a number",
            "output_tokens": true
        });
        let result = parse_usage_info(&usage_info);
        assert_eq!(
            result,
            AnthropicUsage::default(),
            "non-numeric values should fall back to default"
        );
    }

    #[test]
    fn test_anthropic_base_url() {
        assert_eq!(
            ANTHROPIC_DEFAULT_BASE_URL.as_str(),
            "https://api.anthropic.com/v1/",
            "Default base URL should be the API root without /messages"
        );
    }

    #[test]
    fn test_anthropic_provider_custom_api_base() {
        let custom_url = Url::parse("https://example.com/custom/").unwrap();
        let provider = AnthropicProvider::new(
            "claude".to_string(),
            Some(custom_url.clone()),
            AnthropicCredentials::None,
            vec![],
        );

        assert_eq!(
            provider.base_url(),
            &custom_url,
            "Custom api_base should be stored as-is"
        );
        assert_eq!(
            provider.messages_url().unwrap().as_str(),
            "https://example.com/custom/messages",
            "messages_url() should append /messages to custom base URL"
        );
    }

    #[test]
    fn test_anthropic_provider_default_api_base() {
        let provider = AnthropicProvider::new(
            "claude".to_string(),
            None,
            AnthropicCredentials::None,
            vec![],
        );

        assert_eq!(
            provider.base_url().as_str(),
            "https://api.anthropic.com/v1/",
            "Default base URL should be the API root"
        );
        assert_eq!(
            provider.messages_url().unwrap().as_str(),
            "https://api.anthropic.com/v1/messages",
            "messages_url() should return URL with /messages appended"
        );
    }

    #[test]
    fn test_get_messages_url() {
        // Test with URL with trailing slash
        let base_url = Url::parse("https://api.anthropic.com/v1/").unwrap();
        let messages_url = get_messages_url(&base_url).unwrap();
        assert_eq!(
            messages_url.as_str(),
            "https://api.anthropic.com/v1/messages",
            "Should append /messages to base URL with trailing slash"
        );

        // Test with URL without trailing slash
        let base_url = Url::parse("https://api.anthropic.com/v1").unwrap();
        let messages_url = get_messages_url(&base_url).unwrap();
        assert_eq!(
            messages_url.as_str(),
            "https://api.anthropic.com/v1/messages",
            "Should append /messages to base URL without trailing slash"
        );

        // Test with custom base URL
        let base_url = Url::parse("https://example.com/anthropic/v1/").unwrap();
        let messages_url = get_messages_url(&base_url).unwrap();
        assert_eq!(
            messages_url.as_str(),
            "https://example.com/anthropic/v1/messages",
            "Should work with custom base URLs"
        );
    }

    #[test]
    fn test_check_api_base_suffix() {
        let logs_contain = capture_logs();

        // Valid cases (should not warn)
        check_api_base_suffix(&Url::parse("https://api.anthropic.com/v1/").unwrap());
        check_api_base_suffix(&Url::parse("https://api.anthropic.com/v1").unwrap());
        check_api_base_suffix(&Url::parse("https://example.com/anthropic/").unwrap());

        // Invalid cases (should warn with deprecation)
        let url1 = Url::parse("https://api.anthropic.com/v1/messages").unwrap();
        check_api_base_suffix(&url1);
        assert!(
            logs_contain("Deprecation Warning"),
            "Should emit deprecation warning for URL ending with /messages"
        );
        assert!(
            logs_contain("automatically appends `/messages`"),
            "Warning should mention automatic appending"
        );

        let url2 = Url::parse("https://api.anthropic.com/v1/messages/").unwrap();
        check_api_base_suffix(&url2);
        assert!(
            logs_contain(url2.as_ref()),
            "Warning should include the problematic URL"
        );
    }

    #[test]
    fn test_normalize_api_base() {
        // Test URL ending with /messages
        let url = Url::parse("https://api.anthropic.com/v1/messages").unwrap();
        let normalized = normalize_api_base(url);
        assert_eq!(
            normalized.as_str(),
            "https://api.anthropic.com/v1/",
            "Should strip /messages and add trailing slash"
        );

        // Test URL ending with /messages/
        let url = Url::parse("https://api.anthropic.com/v1/messages/").unwrap();
        let normalized = normalize_api_base(url);
        assert_eq!(
            normalized.as_str(),
            "https://api.anthropic.com/v1/",
            "Should strip /messages/ and preserve trailing slash"
        );

        // Test URL without /messages suffix (should remain unchanged)
        let url = Url::parse("https://api.anthropic.com/v1/").unwrap();
        let normalized = normalize_api_base(url);
        assert_eq!(
            normalized.as_str(),
            "https://api.anthropic.com/v1/",
            "Should not modify URL without /messages suffix"
        );

        // Test custom URL with /messages
        let url = Url::parse("https://example.com/anthropic/v1/messages").unwrap();
        let normalized = normalize_api_base(url);
        assert_eq!(
            normalized.as_str(),
            "https://example.com/anthropic/v1/",
            "Should work with custom URLs"
        );
    }

    #[test]
    fn test_anthropic_provider_normalizes_api_base_with_messages() {
        let logs_contain = capture_logs();

        // Create provider with api_base that includes /messages
        let url_with_messages = Url::parse("https://example.com/v1/messages").unwrap();
        let provider = AnthropicProvider::new(
            "claude".to_string(),
            Some(url_with_messages),
            AnthropicCredentials::None,
            vec![],
        );

        // Verify the stored api_base is normalized
        assert_eq!(
            provider.base_url().as_str(),
            "https://example.com/v1/",
            "Provider should store normalized base URL without /messages"
        );

        // Verify messages_url() returns the correct full URL
        assert_eq!(
            provider.messages_url().unwrap().as_str(),
            "https://example.com/v1/messages",
            "messages_url() should return URL with /messages appended"
        );

        // Verify deprecation warning was emitted
        assert!(
            logs_contain("Deprecation Warning"),
            "Should emit deprecation warning when api_base includes /messages"
        );
    }

    #[test]
    fn test_prefill_json_message() {
        // Create a sample input message
        let input_messages = vec![AnthropicMessage {
            role: AnthropicRole::User,
            content: vec![FlattenUnknown::Normal(AnthropicMessageContent::Text {
                text: "Generate some JSON",
            })],
        }];

        // Call the function
        let result = prefill_json_message(input_messages);

        // Assert that the result has one more message than the input
        assert_eq!(result.len(), 2);

        // Check the original message is unchanged
        assert_eq!(result[0].role, AnthropicRole::User);
        assert_eq!(
            result[0].content,
            vec![FlattenUnknown::Normal(AnthropicMessageContent::Text {
                text: "Generate some JSON",
            })]
        );

        // Check the new message is correct
        assert_eq!(result[1].role, AnthropicRole::Assistant);
        assert_eq!(
            result[1].content,
            vec![FlattenUnknown::Normal(AnthropicMessageContent::Text {
                text: "Here is the JSON requested:\n{",
            })]
        );
    }

    #[test]
    fn test_prefill_json_response() {
        // Test case 1: Single text block
        let input = vec![ContentBlockOutput::Text(Text {
            text: "  \"key\": \"value\"}".to_string(),
        })];
        let result = prefill_json_response(input).unwrap();
        assert_eq!(result.len(), 1);
        assert_eq!(
            result[0],
            ContentBlockOutput::Text(Text {
                text: "{\"key\": \"value\"}".to_string(),
            })
        );

        // Test case 2: Multiple blocks
        let input = vec![
            ContentBlockOutput::Text(Text {
                text: "Block 1".to_string(),
            }),
            ContentBlockOutput::Text(Text {
                text: "Block 2".to_string(),
            }),
        ];
        let result = prefill_json_response(input.clone()).unwrap();
        assert_eq!(result, input);

        // Test case 3: Empty input
        let input = vec![];
        let result = prefill_json_response(input.clone()).unwrap();
        assert_eq!(result, input);

        // Test case 4: Non-text block
        let input = vec![ContentBlockOutput::ToolCall(ToolCall {
            id: "1".to_string(),
            name: "test_tool".to_string(),
            arguments: "{}".to_string(),
        })];
        let result = prefill_json_response(input.clone()).unwrap();
        assert_eq!(result, input);
    }

    #[test]
    fn test_prefill_json_chunk_response() {
        // Test case 1: Empty content
        let chunk = ProviderInferenceResponseChunk {
            content: vec![],
            usage: None,
            raw_usage: None,
            raw_response: String::new(),
            provider_latency: Duration::from_millis(0),
            finish_reason: None,
        };
        let mut result = chunk.clone();
        prefill_json_chunk_response(&mut result);
        assert_eq!(
            result.content,
            vec![ContentBlockChunk::Text(TextChunk {
                text: "{".to_string(),
                id: "0".to_string()
            })]
        );
        // Test case 2: Single text block
        let chunk = ProviderInferenceResponseChunk {
            usage: None,
            raw_usage: None,
            raw_response: String::new(),
            provider_latency: Duration::from_millis(0),
            finish_reason: None,
            content: vec![ContentBlockChunk::Text(TextChunk {
                text: "\"key\": \"value ".to_string(),
                id: "0".to_string(),
            })],
        };
        let mut result = chunk.clone();
        prefill_json_chunk_response(&mut result);
        assert_eq!(
            result.content,
            vec![ContentBlockChunk::Text(TextChunk {
                text: "{\"key\": \"value ".to_string(),
                id: "0".to_string()
            })]
        );

        // Test case 3: Multiple blocks (should remain unchanged)
        let chunk = ProviderInferenceResponseChunk {
            usage: None,
            raw_usage: None,
            raw_response: String::new(),
            provider_latency: Duration::from_millis(0),
            finish_reason: None,
            content: vec![
                ContentBlockChunk::Text(TextChunk {
                    text: "Block 1".to_string(),
                    id: "test_id".to_string(),
                }),
                ContentBlockChunk::Text(TextChunk {
                    text: "Block 2".to_string(),
                    id: "test_id".to_string(),
                }),
            ],
        };
        let mut result = chunk.clone();
        prefill_json_chunk_response(&mut result);
        assert_eq!(result, chunk);

        // Test case 4: Non-text block (should remain unchanged)
        let chunk = ProviderInferenceResponseChunk {
            usage: None,
            raw_usage: None,
            raw_response: String::new(),
            provider_latency: Duration::from_millis(0),
            finish_reason: None,
            content: vec![ContentBlockChunk::ToolCall(ToolCallChunk {
                id: "1".to_string(),
                raw_name: Some("test_tool".to_string()),
                raw_arguments: "{}".to_string(),
            })],
        };
        let mut result = chunk.clone();
        prefill_json_chunk_response(&mut result);
        assert_eq!(result, chunk);
    }

    #[test]
    fn test_credential_to_anthropic_credentials() {
        // Test Static credential
        let generic = Credential::Static(SecretString::from("test_key"));
        let creds = AnthropicCredentials::try_from(generic).unwrap();
        assert!(matches!(creds, AnthropicCredentials::Static(_)));

        // Test Dynamic credential
        let generic = Credential::Dynamic("key_name".to_string());
        let creds = AnthropicCredentials::try_from(generic).unwrap();
        assert!(matches!(creds, AnthropicCredentials::Dynamic(_)));

        // Test Missing credential
        let generic = Credential::Missing;
        let creds = AnthropicCredentials::try_from(generic).unwrap();
        assert!(matches!(creds, AnthropicCredentials::None));

        // Test invalid type
        let generic = Credential::FileContents(SecretString::from("test"));
        let result = AnthropicCredentials::try_from(generic);
        assert!(result.is_err());
        assert!(matches!(
            result.unwrap_err().get_details(),
            ErrorDetails::Config { message } if message.contains("Invalid api_key_location")
        ));
    }

    #[test]
    fn test_convert_unknown_chunk_returns_chunk() {
        let mut tool_state: HashMap<u32, (String, String)> = HashMap::new();
        let result = anthropic_to_tensorzero_stream_message(
            "my_raw_chunk".to_string(),
            AnthropicStreamMessage::ContentBlockStart {
                content_block: FlattenUnknown::Unknown(Cow::Owned(
                    serde_json::json!({"my_unknown": "content_block"}),
                )),
                index: 0,
            },
            Duration::from_secs(0),
            &mut tool_state,
            false,
            "test_model",
            "test_provider",
            PROVIDER_TYPE,
            Uuid::now_v7(),
        )
        .unwrap()
        .unwrap();

        assert_eq!(result.content.len(), 1);
        match &result.content[0] {
            ContentBlockChunk::Unknown(UnknownChunk { id, data, .. }) => {
                assert_eq!(id, "0");
                assert_eq!(
                    data.get("my_unknown").and_then(|v| v.as_str()),
                    Some("content_block")
                );
            }
            _ => panic!("Expected Unknown chunk"),
        }
    }

    #[test]
    fn test_convert_unknown_chunk_warn() {
        let logs_contain = crate::utils::testing::capture_logs();
        let mut tool_state: HashMap<u32, (String, String)> = HashMap::new();
        let res = anthropic_to_tensorzero_stream_message(
            "my_raw_chunk".to_string(),
            AnthropicStreamMessage::ContentBlockStart {
                content_block: FlattenUnknown::Unknown(Cow::Owned(
                    serde_json::json!({"my_unknown": "content_block"}),
                )),
                index: 0,
            },
            Duration::from_secs(0),
            &mut tool_state,
            true,
            "test_model",
            "test_provider",
            PROVIDER_TYPE,
            Uuid::now_v7(),
        )
        .unwrap();
        assert_eq!(res, None);
        assert!(logs_contain("Discarding unknown chunk"));
    }

    #[test]
    fn test_anthropic_apply_inference_params_thinking_budget_tokens() {
        let logs_contain = crate::utils::testing::capture_logs();
        let inference_params = ChatCompletionInferenceParamsV2 {
            reasoning_effort: None,
            service_tier: None,
            thinking_budget_tokens: Some(1024),
            verbosity: Some("low".to_string()),
        };
        let mut request = AnthropicRequestBody {
            model: "claude-3-5-sonnet-20241022",
            messages: vec![],
            max_tokens: 1024,
            ..Default::default()
        };

        apply_inference_params(&mut request, &inference_params).unwrap();

        // Test that thinking_budget_tokens is applied correctly
        assert_eq!(
            request.thinking,
            Some(AnthropicThinkingConfig::Enabled {
                r#type: "enabled",
                budget_tokens: 1024,
            }),
            "thinking_budget_tokens should set enabled thinking mode"
        );

        // Test that verbosity warns
        assert!(
            logs_contain("Anthropic does not support the inference parameter `verbosity`"),
            "verbosity should produce a warning"
        );
    }

    #[test]
    fn test_anthropic_apply_inference_params_reasoning_effort() {
        let inference_params = ChatCompletionInferenceParamsV2 {
            reasoning_effort: Some("low".to_string()),
            service_tier: None,
            thinking_budget_tokens: None,
            verbosity: None,
        };
        let mut request = AnthropicRequestBody {
            model: "claude-sonnet-4-6",
            messages: vec![],
            max_tokens: 2048,
            ..Default::default()
        };

        apply_inference_params(&mut request, &inference_params).unwrap();

        // Test that reasoning_effort sets adaptive thinking
        assert_eq!(
            request.thinking,
            Some(AnthropicThinkingConfig::Adaptive { r#type: "adaptive" }),
            "reasoning_effort should set adaptive thinking mode"
        );

        // Test that output_config has the effort value
        assert_eq!(
            request.output_config,
            Some(AnthropicOutputConfig {
                format: None,
                effort: Some("low".to_string()),
            }),
            "reasoning_effort should set effort in output_config"
        );
    }

    #[test]
    fn test_anthropic_apply_inference_params_reasoning_effort_with_json_strict() {
        let inference_params = ChatCompletionInferenceParamsV2 {
            reasoning_effort: Some("medium".to_string()),
            service_tier: None,
            thinking_budget_tokens: None,
            verbosity: None,
        };
        // Simulate a request that already has output_config set from JSON strict mode
        let mut request = AnthropicRequestBody {
            model: "claude-sonnet-4-6",
            messages: vec![],
            max_tokens: 2048,
            output_config: Some(AnthropicOutputConfig {
                format: Some(AnthropicOutputFormat::JsonSchema {
                    schema: serde_json::json!({"type": "object"}),
                }),
                effort: None,
            }),
            ..Default::default()
        };

        apply_inference_params(&mut request, &inference_params).unwrap();

        // Test that both format and effort are set
        assert_eq!(
            request.output_config,
            Some(AnthropicOutputConfig {
                format: Some(AnthropicOutputFormat::JsonSchema {
                    schema: serde_json::json!({"type": "object"}),
                }),
                effort: Some("medium".to_string()),
            }),
            "reasoning_effort should merge effort into existing output_config with format"
        );
    }

    #[test]
    fn test_anthropic_apply_inference_params_mutual_exclusivity() {
        let inference_params = ChatCompletionInferenceParamsV2 {
            reasoning_effort: Some("high".to_string()),
            service_tier: None,
            thinking_budget_tokens: Some(1024),
            verbosity: None,
        };
        let mut request = AnthropicRequestBody {
            model: "claude-sonnet-4-6",
            messages: vec![],
            max_tokens: 2048,
            ..Default::default()
        };

        let result = apply_inference_params(&mut request, &inference_params);
        assert!(
            result.is_err(),
            "should error when both reasoning_effort and thinking_budget_tokens are provided"
        );
        let err = result.unwrap_err();
        assert!(
            err.to_string()
                .contains("Cannot specify both `reasoning_effort` and `thinking_budget_tokens`"),
            "error message should mention mutual exclusivity"
        );
    }

    #[tokio::test]
    async fn test_anthropic_warns_on_detail() {
        let logs_contain = capture_logs();

        // Test URL forwarding path with detail
        let url = Url::parse("https://example.com/image.png").unwrap();
        let content_block = ContentBlock::File(Box::new(LazyFile::Url {
            file_url: FileUrl {
                url: url.clone(),
                mime_type: Some(mime::IMAGE_PNG),
                detail: Some(Detail::Low),
                filename: None,
            },
            future: async { panic!("Should not resolve") }.boxed().shared(),
        }));

        let config = AnthropicMessagesConfig {
            fetch_and_encode_input_files_before_inference: false,
        };

        let _result =
            AnthropicMessageContent::from_content_block(&content_block, config, PROVIDER_TYPE)
                .await;

        // Should log a warning about detail not being supported
        assert!(logs_contain(
            "The image detail parameter is not supported by Anthropic"
        ));
    }

    #[test]
    fn test_anthropic_respects_allowed_tools() {
        use crate::providers::test_helpers::{QUERY_TOOL, WEATHER_TOOL};
        use crate::tool::{AllowedTools, AllowedToolsChoice};

        // Create a ToolCallConfig with two tools but only allow one
        let tool_config = ToolCallConfig {
            static_tools_available: vec![WEATHER_TOOL.clone(), QUERY_TOOL.clone()],
            dynamic_tools_available: vec![],
            provider_tools: vec![],
            openai_custom_tools: vec![],
            tool_choice: ToolChoice::Auto,
            parallel_tool_calls: None,
            allowed_tools: AllowedTools {
                tools: vec!["get_temperature".to_string()].into_iter().collect(),
                choice: AllowedToolsChoice::Explicit,
            },
        };

        // Convert to Anthropic tools
        let tools: Vec<AnthropicFunctionTool> = tool_config
            .strict_tools_available()
            .unwrap()
            .map(|tool| AnthropicFunctionTool::new(tool, true))
            .collect();

        // Verify only the allowed tool is included
        assert_eq!(tools.len(), 1);
        assert_eq!(tools[0].name, "get_temperature");
    }
}
