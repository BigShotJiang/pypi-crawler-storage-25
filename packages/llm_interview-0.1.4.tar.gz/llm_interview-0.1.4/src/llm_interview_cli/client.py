import json
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin
from urllib.request import Request, urlopen


class ApiError(RuntimeError):
    def __init__(self, status: int, message: str):
        self.status = status
        super().__init__(message)


class ApiClient:
    def __init__(self, server_url: str, token: str = ""):
        self.server_url = server_url.rstrip("/") + "/"
        self.token = token

    def post_json(self, path: str, payload: dict) -> dict:
        return self._request("POST", path, payload)

    def get_json(self, path: str) -> dict:
        return self._request("GET", path, None)

    def _request(self, method: str, path: str, payload: dict | None) -> dict:
        data = None
        headers = {
            "Accept": "application/json",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        if payload is not None:
            data = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"

        request = Request(urljoin(self.server_url, path.lstrip("/")), data=data, headers=headers, method=method)
        try:
            with urlopen(request, timeout=20) as response:
                body = response.read().decode("utf-8")
        except HTTPError as exc:
            body = exc.read().decode("utf-8")
            try:
                message = json.loads(body).get("error", body)
            except json.JSONDecodeError:
                message = body or exc.reason
            raise ApiError(exc.code, message) from exc
        except URLError as exc:
            raise ApiError(0, f"Could not reach server: {exc.reason}") from exc

        return json.loads(body) if body else {}
