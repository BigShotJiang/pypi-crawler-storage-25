# Copyright 2025 Timandes White
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Fnos - A Python client for Fnos WebSocket communication
"""

from .client import FnosClient
from .exceptions import NotConnectedError
from .store import Store
from .resource_monitor import ResourceMonitor
from .sac import SAC
from .system_info import SystemInfo
from .user import User
from .network import Network
from .file import File
from .docker_manager import DockerManager
from .event_logger import EventLogger
from .share import Share
from .notify import Notify
from .iscsi_manager import IscsiManager

__version__ = "0.12.0"

__all__ = ["FnosClient", "Store", "ResourceMonitor", "SAC", "SystemInfo", "User", "Network", "File", "DockerManager", "EventLogger", "Share", "Notify", "IscsiManager"]