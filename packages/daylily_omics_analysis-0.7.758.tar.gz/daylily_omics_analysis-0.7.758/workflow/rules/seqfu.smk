import os

# #### seqfu
# -----------
#   Super efficent fasta/q manipulations
#
# github:  https://github.com/telatin/seqfu2
# paper: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8148589/


rule seqfu:
    input:
        #DR=MDIR + "{sample}/{sample}.dirsetup.ready",
        #fqs=get_raw_fastqs,
        #f1=getR1sS,  # method defined in fastp.smk
        #f2=getR2sS,  # method defined in fastp.smk
        f1=get_raw_R1s,
        f2=get_raw_R2s,
    output:
        mqc_r1=f"{MDIR}" + "{sample}/seqqc/seqfu/{sample}.seqfuR1.mqc.tsv",
        mqc_r2=f"{MDIR}" + "{sample}/seqqc/seqfu/{sample}.seqfuR2.mqc.tsv",
        sent=MDIR + "{sample}/seqqc/seqfu/{sample}.seqfu.done",
    benchmark:
        f"{MDIR}" + "{sample}/benchmarks/{sample}.seqfu.bench.tsv"
    threads: config["seqfu"]["threads"]
    params:
        cluster_sample=ret_sample,
        ld_preload=" "
        if "ld_preload" not in config["malloc_alt"]
        else config["malloc_alt"]["ld_preload"],
        ld_pre=" "
        if "ld_preload" not in config["seqfu"]
        else config["seqfu"]["ld_preload"],
    log:
        f"{MDIR}" + "{sample}/seqqc/seqfu/{sample}.seqfu.log",
    conda:
        config["seqfu"]["env_yaml"]
    shell:
        """
        mkdir -p $(dirname {output.mqc_r1});
        ( cat  <(gzip -dc -- {input.f1} ) | env {params.ld_preload} seqfu stats --nice -b  --verbose --multiqc ./{output.mqc_r1} - &
        cat <(gzip -dc -- {input.f2} ) | env {params.ld_preload} seqfu stats --nice -b  --verbose --multiqc ./{output.mqc_r2} - &
        wait;
        touch {output.sent};) > {log}
        ls {output};
        """


localrules:
    compile_seqfu,


rule compile_seqfu:
    input:
        expand(MDIR + "{sample}/seqqc/seqfu/{sample}.seqfu.done", sample=SAMPS),
    container:
        None
    output:
        mqc1=MDIR + "other_reports/seqfu1.mqc.tsv",
        mqc2=MDIR + "other_reports/seqfu2.mqc.tsv",
        mqc=MDIR + "other_reports/seqfu_mqc.tsv",
        d=MDIR + "logs/seqfu.done",
    params:
        mdir=MDIR,
    shell:
        """mkdir -p {MDIR}other_reports $(dirname {output.d});
        single_file=$( find {params.mdir} -name '*seqfuR1.mqc.tsv' | head -n 1);
        if [[ "$single_file" == "" ]]; then
            echo "NO DATA FOUND" > {output.mqc1};
        else
            head -n 35 $single_file > {output.mqc1};
            find {params.mdir} -name '*seqfuR1.mqc.tsv' -exec sh -c 'tail -n 1 "$1" >> "$2"' sh {{}} {output.mqc1} \\;;
        fi;

        single_file2=$( find {params.mdir} -name '*seqfuR2.mqc.tsv'  | head -n 1);
        if [[ "$single_file2" == "" ]]; then
            echo "NO DATA FOUND" > {output.mqc2};
        else
            head -n 35 $single_file2 > {output.mqc2};
            find {params.mdir} -name '*seqfuR2.mqc.tsv' -exec sh -c 'tail -n 1 "$1" >> "$2"' sh {{}} {output.mqc2} \\;;
        fi;
        printf "Sample\\tbase_sample\\tread\\tsource_path\\n" > {output.mqc};
        find {params.mdir} -name '*seqfuR1.mqc.tsv' | sort | while IFS= read -r source_path; do
            base_sample=$(basename "$source_path" .seqfuR1.mqc.tsv);
            printf "%s.R1\\t%s\\tR1\\t%s\\n" "$base_sample" "$base_sample" "$source_path" >> {output.mqc};
        done;
        find {params.mdir} -name '*seqfuR2.mqc.tsv' | sort | while IFS= read -r source_path; do
            base_sample=$(basename "$source_path" .seqfuR2.mqc.tsv);
            printf "%s.R2\\t%s\\tR2\\t%s\\n" "$base_sample" "$base_sample" "$source_path" >> {output.mqc};
        done;
        touch {output.d};

        """


localrules:
    produce_seqfu,


rule produce_seqfu:  # TARGET: seqfu output
    input:
        MDIR + "logs/seqfu.done",
    container:
        None
