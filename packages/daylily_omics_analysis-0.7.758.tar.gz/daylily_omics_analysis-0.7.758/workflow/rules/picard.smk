import os
###### Piocard QC Tools
# ----------------------------------



rule picard_cram:
    input:
        cram=MDIR + "{sample}/align/{alnr}/{ddup}/{sample}.{alnr}.{ddup}.cram",
    output:
        sent=touch(MDIR + "{sample}/align/{alnr}/{ddup}/alignqc/picard/picard/{sample}.{alnr}.{ddup}.done"),
    threads: config["picard"]["threads"]
    resources:
        vcpu=config["picard"]["threads"],
        partition=config["picard"]["partition"],
    benchmark:
        MDIR + "{sample}/benchmarks/{sample}.{alnr}.{ddup}.picard.bench.tsv"
    log:
        MDIR + "{sample}/align/{alnr}/{ddup}/alignqc/picard/logs/{sample}.{alnr}.{ddup}.stats.log"
    conda:
        "../envs/picard_v0.1.yaml"
    params:
        cluster_sample=ret_sample,
        huref=config["supporting_files"]["files"]["huref"]["fasta"]["name"],
        prefix=MDIR + "{sample}/align/{alnr}/{ddup}/alignqc/picard/{sample}.{alnr}.{ddup}",
        metric_accumulation_level="SAMPLE" if 'metric_accumulation_level' not in config['picard'] else config['picard']['metric_accumulation_level'],
        alnr=get_alnr,
        stop_after="2000000" if 'stop_after' not in config['picard'] else config['picard']['stop_after'],
        validation_stringency="LENIENT" if 'validation_stringency' not in config['picard'] else config['picard']['validation_stringency']
    shell:
        """
        set +euo pipefail;
        (
        rm -f {params.prefix:q}.* || echo rmPicardPrefixFailed;
        mkdir -p $(dirname {log:q} ) $(dirname {params.prefix:q}) $(dirname {output.sent:q});
        picard CollectMultipleMetrics VALIDATION_STRINGENCY={params.validation_stringency} METRIC_ACCUMULATION_LEVEL={params.metric_accumulation_level} LEVEL={params.metric_accumulation_level} STOP_AFTER={params.stop_after} I={input.cram:q} O={params.prefix:q} R={params.huref:q} EXT=.txt PROGRAM=CollectAlignmentSummaryMetrics PROGRAM=CollectInsertSizeMetrics PROGRAM=QualityScoreDistribution PROGRAM=CollectGcBiasMetrics PROGRAM=CollectSequencingArtifactMetrics PROGRAM=CollectQualityYieldMetrics INCLUDE_UNPAIRED=true ;
        touch {output.sent}; echo empySentFilesNotBeingSeen >> {output.sent};
        ls {output.sent}; cat {output.sent} ; ) > {log} 2>&1;
        exit 0;
        """

localrules: produce_picard_cram,

rule produce_picard_cram:  # TARGET: produce picard QC data
    input:
        expand(MDIR + "{sample}/align/{alnr}/{ddup}/alignqc/picard/picard/{sample}.{alnr}.{ddup}.done", sample=SSAMPS,alnr=ALL_ALIGNERS, ddup=DDUP)
    output:
        touch(MDIR + "other_reports/picard_summary_gather.done"),
