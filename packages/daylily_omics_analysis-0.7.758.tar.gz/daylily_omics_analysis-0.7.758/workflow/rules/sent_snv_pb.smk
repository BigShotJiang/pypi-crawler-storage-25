import sys
import os


ALIGNERS_PB = ["sentmm2"]


# ---------------------------------------------------------------------------
# sent_snv_pacbio: Sentieon DNAscope LongRead pipeline (PacBio HiFi)
# Uses sentieon-cli dnascope-longread which implements the full two-pass
# phased variant calling pipeline (DNAscope → VariantPhaser → RepeatModel →
# DNAscopeHP per-haplotype → merge).  Outputs SNV/indel VCF + SV VCF.
# ---------------------------------------------------------------------------

rule sent_snv_pacbio:
    input:
        cram=MDIR + "{sample}/align/{alnr}/{ddup}/{sample}.{alnr}.{ddup}.cram",
        crai=MDIR + "{sample}/align/{alnr}/{ddup}/{sample}.{alnr}.{ddup}.cram.crai",
    output:
        vcfgz=MDIR
        + "{sample}/align/{alnr}/{ddup}/snv/sentdpb/{sample}.{alnr}.{ddup}.sentdpb.snv.sort.vcf.gz",
        vcfgztbi=MDIR
        + "{sample}/align/{alnr}/{ddup}/snv/sentdpb/{sample}.{alnr}.{ddup}.sentdpb.snv.sort.vcf.gz.tbi",
        svvcfgz=MDIR
        + "{sample}/align/{alnr}/{ddup}/snv/sentdpb/{sample}.{alnr}.{ddup}.sentdpb.sv.vcf.gz",
        svvcfgztbi=MDIR
        + "{sample}/align/{alnr}/{ddup}/snv/sentdpb/{sample}.{alnr}.{ddup}.sentdpb.sv.vcf.gz.tbi",
    log:
        MDIR
        + "{sample}/align/{alnr}/{ddup}/snv/sentdpb/log/{sample}.{alnr}.{ddup}.sentdpb.snv.log",
    threads: config['sentdpb']['threads']
    conda:
        config["sentdpb"]["env_yaml"]
    priority: 45
    benchmark:
        repeat(
            MDIR + "{sample}/benchmarks/{sample}.{alnr}.{ddup}.sentdpb.bench.tsv",
            0
            if "bench_repeat" not in config["sentdpb"]
            else config["sentdpb"]["bench_repeat"],
        )
    resources:
        attempt_n=lambda wildcards, attempt:  (attempt + 0),
        partition=config['sentdpb']['partition'],
        threads=config['sentdpb']['threads'],
        vcpu=config['sentdpb']['threads'],
        mem_mb=config['sentdpb']['mem_mb'],
    params:
        huref=config["supporting_files"]["files"]["huref"]["fasta"]["name"],
        model=config["sentdpb"]["dna_scope_snv_model"],
        pop_vcf=config["supporting_files"]["files"]["popvcf"]["name"],
        cluster_sample=ret_sample,
        haploid_bed=get_haploid_bed_arg,
        diploid_bed=get_diploid_bed_arg,
    shell:
        """
        export PATH=$PATH:/fsx/data/cached_envs/sentieon-genomics-202503.02/bin/
        timestamp=$(date +%Y%m%d%H%M%S)_$$;
        export TMPDIR=/dev/shm/sentdpb_tmp_$timestamp;
        export SENTIEON_TMPDIR=$TMPDIR;
        mkdir -p $TMPDIR;
        export APPTAINER_HOME=$TMPDIR;
        trap 'rm -rf "$TMPDIR" 2>/dev/null || true' EXIT;

        if [ -z "$SENTIEON_LICENSE" ]; then
            echo "SENTIEON_LICENSE not set." >> {log} 2>&1;
            exit 3;
        fi

        if [ ! -f "$SENTIEON_LICENSE" ]; then
            echo "SENTIEON_LICENSE file not found: '$SENTIEON_LICENSE'" >> {log} 2>&1;
            exit 4;
        fi

        TOKEN=$(curl -s -X PUT 'http://169.254.169.254/latest/api/token' -H 'X-aws-ec2-metadata-token-ttl-seconds: 21600');
        itype=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/instance-type);
        echo "INSTANCE TYPE: $itype" > {log};
        start_time=$(date +%s);

        ulimit -n 65536 || echo "ulimit mod failed" >> {log} 2>&1;

        # Find jemalloc in the active conda environment
        jemalloc_path="";
        for _dir in "$CONDA_PREFIX/lib" "$CONDA_PREFIX/lib64" "$CONDA_PREFIX/lib/x86_64-linux-gnu"; do
            if [[ -d "$_dir" ]]; then
                for _ext in so dylib; do
                    _candidate=$(find "$_dir" -maxdepth 1 -name "libjemalloc*.$_ext*" 2>/dev/null | head -n 1);
                    if [[ -n "$_candidate" && -r "$_candidate" ]]; then
                        jemalloc_path="$_candidate";
                        break 2;
                    fi
                done
            fi
        done

        if [[ -n "$jemalloc_path" ]]; then
            export LD_PRELOAD="$jemalloc_path";
            export MALLOC_CONF=background_thread:true,metadata_thp:auto,dirty_decay_ms:5000,muzzy_decay_ms:5000;
            echo "LD_PRELOAD set to: $LD_PRELOAD" >> {log};
            echo "MALLOC_CONF set to: $MALLOC_CONF" >> {log};
        else
            echo "WARNING: libjemalloc not found in CONDA_PREFIX=$CONDA_PREFIX" >> {log};
        fi

        # --- sentieon-cli dnascope-longread (PacBio HiFi) ---
        # The CLI runs the full two-pass phased pipeline internally.
        # Outputs: <basename>.vcf.gz (SNV/indel) and <basename>.sv.vcf.gz (SV)
        cli_out="$TMPDIR/{wildcards.sample}.{wildcards.alnr}.sentdpb";

        echo "sentieon-cli dnascope-longread starting: model={params.model} tech=HiFi" >> {log} 2>&1;
        set +e;
        sentieon-cli dnascope-longread \
            -r {params.huref} \
            -i {input.cram} \
            -m "{params.model}" \
            -d "{params.pop_vcf}" \
            -t {threads} \
            --tech HiFi \
            {params.diploid_bed} {params.haploid_bed} \
            "${{cli_out}}.vcf.gz" >> {log} 2>&1;
        cli_rc=$?;
        set -e;
        echo "sentieon-cli exit code: $cli_rc" >> {log} 2>&1;
        if [ $cli_rc -ne 0 ]; then
            echo "ERROR: sentieon-cli dnascope-longread failed with exit code $cli_rc" >> {log} 2>&1;
            exit $cli_rc;
        fi

        # --- Reheader SNV VCF: rename sample to cluster_sample ---
        if [ -f "${{cli_out}}.vcf.gz" ]; then
            oldname=$(bcftools query -l "${{cli_out}}.vcf.gz" | head -n1);
            echo -e "${{oldname}}\t{params.cluster_sample}" > "$TMPDIR/rename.txt";
            bcftools reheader -s "$TMPDIR/rename.txt" -o {output.vcfgz} "${{cli_out}}.vcf.gz" >> {log} 2>&1;
            bcftools index -f -t --threads {threads} -o {output.vcfgztbi} {output.vcfgz} >> {log} 2>&1;
        else
            echo "ERROR: SNV VCF not produced by sentieon-cli" >> {log} 2>&1;
            exit 20;
        fi

        # --- Reheader SV VCF ---
        if [ -f "${{cli_out}}.sv.vcf.gz" ]; then
            bcftools reheader -s "$TMPDIR/rename.txt" -o {output.svvcfgz} "${{cli_out}}.sv.vcf.gz" >> {log} 2>&1;
            bcftools index -f -t --threads {threads} -o {output.svvcfgztbi} {output.svvcfgz} >> {log} 2>&1;
        else
            echo "WARNING: SV VCF not produced; creating empty placeholder" >> {log} 2>&1;
            touch {output.svvcfgz} {output.svvcfgztbi};
        fi

        end_time=$(date +%s);
        elapsed_time=$((($end_time - $start_time) / 60));
        echo "Elapsed-Time-min:\t$itype\t$elapsed_time" >> {log} 2>&1;

        """


localrules:
    clear_combined_sentdpb_vcf,


rule clear_combined_sentdpb_vcf:  # TARGET:  clear combined sentdpb vcf so the chunks can be re-evaluated if needed.
    input:
        expand(
            MDIR + "{sample}/align/{alnr}/{ddup}/snv/sentdpb/{sample}.{alnr}.{ddup}.sentdpb.snv.sort.vcf.gz",
            sample=SSAMPS,
            alnr=ALIGNERS_PB,
            ddup=DDUP,
        ),
    threads: 2
    priority: 42
    shell:
        """
        rm {input}*  1> /dev/null  2> /dev/null || echo 'file not found for deletion: {input}';
        """


localrules:
    produce_sentdpb_vcf,


rule produce_sentdpb_vcf:  # DEPRECATED TARGET: use produce_sentdpb_snv_vcf
    input:
        expand(
            MDIR
            + "{sample}/align/{alnr}/{ddup}/snv/sentdpb/{sample}.{alnr}.{ddup}.sentdpb.snv.sort.vcf.gz.tbi",
            sample=SSAMPS,
            alnr=ALIGNERS_PB,
            ddup=DDUP,
        ),
    output:
        "gatheredall.sentdpb",
    priority: 48
    threads: 1
    log:
        "gatheredall.sentdpb.log",
    shell:
        """( touch {output} ;

        ls {output} ) >> {log} 2>&1;
        """
