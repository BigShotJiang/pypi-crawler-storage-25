use base64::engine::general_purpose::STANDARD as BASE64_STANDARD;
use base64::Engine as _;
use image::codecs::jpeg::JpegEncoder;
use image::imageops::FilterType;
use image::{DynamicImage, ImageFormat};
use lopdf::content::Content as LopdfContent;
use lopdf::{Document as LopdfDocument, Object as LopdfObject, ObjectId as LopdfObjectId};
use printpdf::image_crate::{self, codecs::jpeg::JpegDecoder, ImageDecoder};
use printpdf::{
    ColorBits, ColorSpace, Image as PdfImage, ImageFilter, ImageTransform, ImageXObject, Mm,
    PdfDocument, Px,
};
use pyo3::exceptions::{PyRuntimeError, PyValueError};
use pyo3::prelude::*;
use pyo3::types::PyBytes;
use std::collections::{HashMap, HashSet};
use std::env;
use std::ffi::OsString;
use std::fs;
use std::io::{BufReader, BufWriter, Cursor, Read, Seek, SeekFrom, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Output};
use std::sync::mpsc::{self, Receiver, RecvTimeoutError, Sender, TryRecvError};
use std::sync::{Arc, Condvar, Mutex, OnceLock};
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant};
use tempfile::{tempdir, TempDir};
use zip::ZipArchive;

const MAX_IMAGE_AREA: u64 = 36_000_000;
const BYTES_PER_MB: f64 = 1024.0 * 1024.0;
const DEFAULT_PAGE_DPI: f32 = 300.0;
const MAX_ENFORCE_WORKERS: usize = 4;
const SIMPLE_SCAN_JPEG_QUALITY: u8 = 90;
const DEFAULT_MAX_SOFFICE_PROCESSES: usize = 1;

fn debug_logging_enabled() -> bool {
    static DEBUG_ENABLED: OnceLock<bool> = OnceLock::new();
    *DEBUG_ENABLED.get_or_init(|| {
        matches!(
            env::var("DOCS_TOOLS_DEBUG").ok().as_deref(),
            Some("1")
                | Some("true")
                | Some("TRUE")
                | Some("yes")
                | Some("YES")
                | Some("on")
                | Some("ON")
        )
    })
}

fn debug_log(message: impl AsRef<str>) {
    if debug_logging_enabled() {
        eprintln!("[dy_docs_tools] {}", message.as_ref());
    }
}

fn parse_image_limits(max_area: u64, max_size_mb: f64) -> Result<(u64, u64), String> {
    if max_area == 0 {
        return Err("max_area must be > 0".to_string());
    }
    if !max_size_mb.is_finite() || max_size_mb <= 0.0 {
        return Err("max_size_mb must be a finite number > 0".to_string());
    }
    let max_size_bytes = (max_size_mb * BYTES_PER_MB).floor() as u64;
    if max_size_bytes == 0 {
        return Err("max_size_mb is too small; resulting max bytes is 0".to_string());
    }
    Ok((max_area, max_size_bytes))
}

fn path_has_separator(program: &str) -> bool {
    program.contains('/') || program.contains('\\')
}

fn pdftoppm_output_format(fmt: &str) -> &str {
    if fmt.eq_ignore_ascii_case("jpg") {
        "jpeg"
    } else {
        fmt
    }
}

fn generated_image_extension(fmt: &str) -> &str {
    if fmt.eq_ignore_ascii_case("jpeg") {
        "jpg"
    } else {
        fmt
    }
}

fn normalized_image_extension(ext: &str) -> &str {
    if ext.eq_ignore_ascii_case("jpeg") {
        "jpg"
    } else if ext.eq_ignore_ascii_case("tiff") {
        "tif"
    } else {
        ext
    }
}

fn poppler_tool_requested(program: &str) -> bool {
    program.eq_ignore_ascii_case("pdftoppm")
        || program.eq_ignore_ascii_case("pdfimages")
        || program.eq_ignore_ascii_case("pdfinfo")
}

fn parse_output_image_format(fmt: &str) -> Result<ImageFormat, String> {
    match fmt.to_ascii_lowercase().as_str() {
        "jpg" | "jpeg" => Ok(ImageFormat::Jpeg),
        "png" => Ok(ImageFormat::Png),
        "tif" | "tiff" => Ok(ImageFormat::Tiff),
        _ => Err(format!("fmt must be one of: png, jpg, jpeg, tif, tiff")),
    }
}

fn singlefile_output_candidates(output_dir: &Path, prefix: &str, ext: &str) -> Vec<PathBuf> {
    let mut candidates = vec![output_dir.join(format!("{}.{}", prefix, ext))];
    if ext.eq_ignore_ascii_case("jpg") {
        candidates.push(output_dir.join(format!("{}.jpeg", prefix)));
    } else if ext.eq_ignore_ascii_case("jpeg") {
        candidates.push(output_dir.join(format!("{}.jpg", prefix)));
    }
    candidates
}

fn resolve_singlefile_output_path(
    output_dir: &Path,
    prefix: &str,
    ext: &str,
) -> Result<String, String> {
    for candidate in singlefile_output_candidates(output_dir, prefix, ext) {
        if candidate.is_file() {
            return Ok(candidate.to_string_lossy().to_string());
        }
    }

    Err(format!(
        "Expected rendered image for prefix `{}` with extension `{}` under `{}`",
        prefix,
        ext,
        output_dir.display()
    ))
}

fn resolved_command_cache() -> &'static Mutex<HashMap<String, PathBuf>> {
    static COMMAND_CACHE: OnceLock<Mutex<HashMap<String, PathBuf>>> = OnceLock::new();
    COMMAND_CACHE.get_or_init(|| Mutex::new(HashMap::new()))
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum CommandFamily {
    Poppler,
    Soffice,
    Other,
}

struct CommandLimiter {
    state: Mutex<CommandLimiterState>,
    condvar: Condvar,
}

#[derive(Default)]
struct CommandLimiterState {
    poppler_in_flight: usize,
    soffice_in_flight: usize,
}

struct CommandPermit {
    family: CommandFamily,
}

fn command_family(program: &str) -> CommandFamily {
    if poppler_tool_requested(program) {
        CommandFamily::Poppler
    } else if program.eq_ignore_ascii_case("soffice") {
        CommandFamily::Soffice
    } else {
        CommandFamily::Other
    }
}

fn parse_command_limit(var_name: &str, default: usize) -> usize {
    env::var(var_name)
        .ok()
        .and_then(|value| value.parse::<usize>().ok())
        .filter(|value| *value > 0)
        .unwrap_or(default.max(1))
}

fn default_worker_count() -> usize {
    thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1)
        .max(1)
}

fn max_poppler_processes() -> usize {
    static LIMIT: OnceLock<usize> = OnceLock::new();
    *LIMIT.get_or_init(|| {
        parse_command_limit("DOCS_TOOLS_MAX_POPPLER_PROCESSES", default_worker_count())
    })
}

fn max_soffice_processes() -> usize {
    static LIMIT: OnceLock<usize> = OnceLock::new();
    *LIMIT.get_or_init(|| {
        parse_command_limit(
            "DOCS_TOOLS_MAX_SOFFICE_PROCESSES",
            DEFAULT_MAX_SOFFICE_PROCESSES,
        )
    })
}

fn command_limiter() -> &'static CommandLimiter {
    static LIMITER: OnceLock<CommandLimiter> = OnceLock::new();
    LIMITER.get_or_init(|| CommandLimiter {
        state: Mutex::new(CommandLimiterState::default()),
        condvar: Condvar::new(),
    })
}

fn acquire_command_permit(program: &str) -> Result<CommandPermit, String> {
    let family = command_family(program);
    if matches!(family, CommandFamily::Other) {
        return Ok(CommandPermit { family });
    }

    let limiter = command_limiter();
    let mut state = limiter
        .state
        .lock()
        .map_err(|_| "command limiter lock poisoned".to_string())?;

    loop {
        let available = match family {
            CommandFamily::Poppler => state.poppler_in_flight < max_poppler_processes(),
            CommandFamily::Soffice => state.soffice_in_flight < max_soffice_processes(),
            CommandFamily::Other => true,
        };
        if available {
            match family {
                CommandFamily::Poppler => state.poppler_in_flight += 1,
                CommandFamily::Soffice => state.soffice_in_flight += 1,
                CommandFamily::Other => {}
            }
            return Ok(CommandPermit { family });
        }
        state = limiter
            .condvar
            .wait(state)
            .map_err(|_| "command limiter lock poisoned".to_string())?;
    }
}

impl Drop for CommandPermit {
    fn drop(&mut self) {
        if matches!(self.family, CommandFamily::Other) {
            return;
        }

        let limiter = command_limiter();
        if let Ok(mut state) = limiter.state.lock() {
            match self.family {
                CommandFamily::Poppler => {
                    state.poppler_in_flight = state.poppler_in_flight.saturating_sub(1)
                }
                CommandFamily::Soffice => {
                    state.soffice_in_flight = state.soffice_in_flight.saturating_sub(1)
                }
                CommandFamily::Other => {}
            }
            limiter.condvar.notify_one();
        }
    }
}

#[cfg(windows)]
fn command_candidates(program: &str) -> Vec<OsString> {
    let mut out = Vec::new();
    out.push(OsString::from(program));
    if !program.to_ascii_lowercase().ends_with(".exe") {
        out.push(OsString::from(format!("{}.exe", program)));
    }
    out
}

#[cfg(not(windows))]
fn command_candidates(program: &str) -> Vec<OsString> {
    vec![OsString::from(program)]
}

fn find_in_path(program: &str) -> Option<PathBuf> {
    if path_has_separator(program) {
        let p = PathBuf::from(program);
        if p.exists() && p.is_file() {
            return Some(p);
        }
    }

    let path_var = env::var_os("PATH")?;
    let dirs = env::split_paths(&path_var);
    let candidates = command_candidates(program);

    for dir in dirs {
        for name in &candidates {
            let full = dir.join(name);
            if full.exists() && full.is_file() {
                return Some(full);
            }
        }
    }
    None
}

fn extra_command_search_paths(program: &str) -> Vec<PathBuf> {
    let mut paths = Vec::new();
    if poppler_tool_requested(program) {
        #[cfg(windows)]
        {
            if let Some(p) = env::var_os("ProgramFiles") {
                let base = PathBuf::from(p);
                paths.push(base.join("poppler").join("Library").join("bin"));
                paths.push(base.join("poppler").join("bin"));
                push_poppler_children(&mut paths, &base);
            }
            if let Some(p) = env::var_os("ProgramFiles(x86)") {
                let base = PathBuf::from(p);
                paths.push(base.join("poppler").join("Library").join("bin"));
                paths.push(base.join("poppler").join("bin"));
                push_poppler_children(&mut paths, &base);
            }
            if let Some(p) = env::var_os("LOCALAPPDATA") {
                let base = PathBuf::from(p);
                paths.push(
                    base.join("Programs")
                        .join("poppler")
                        .join("Library")
                        .join("bin"),
                );
                paths.push(base.join("Programs").join("poppler").join("bin"));
                push_poppler_children(&mut paths, &base.join("Programs"));
            }
            if let Some(p) = env::var_os("ChocolateyInstall") {
                paths.push(
                    PathBuf::from(p)
                        .join("lib")
                        .join("poppler")
                        .join("tools")
                        .join("bin"),
                );
            }
            if let Some(home) = env::var_os("USERPROFILE") {
                let base = PathBuf::from(home);
                paths.push(
                    base.join("scoop")
                        .join("apps")
                        .join("poppler")
                        .join("current")
                        .join("Library")
                        .join("bin"),
                );
                paths.push(
                    base.join("scoop")
                        .join("apps")
                        .join("poppler")
                        .join("current")
                        .join("bin"),
                );
            }
            if let Some(local_app_data) = env::var_os("LOCALAPPDATA") {
                push_winget_poppler_paths(
                    &mut paths,
                    &PathBuf::from(local_app_data)
                        .join("Microsoft")
                        .join("WinGet")
                        .join("Packages"),
                );
            }
        }
        #[cfg(not(windows))]
        {
            paths.push(PathBuf::from("/usr/bin"));
            paths.push(PathBuf::from("/usr/local/bin"));
            paths.push(PathBuf::from("/opt/homebrew/bin"));
            paths.push(PathBuf::from("/snap/bin"));
        }
    }
    paths
}

#[cfg(windows)]
fn push_poppler_children(paths: &mut Vec<PathBuf>, root: &Path) {
    if let Ok(entries) = fs::read_dir(root) {
        for entry in entries.flatten() {
            let path = entry.path();
            if !path.is_dir() {
                continue;
            }
            let Some(name) = path.file_name().and_then(|s| s.to_str()) else {
                continue;
            };
            if name.to_ascii_lowercase().starts_with("poppler") {
                paths.push(path.join("Library").join("bin"));
                paths.push(path.join("bin"));
            }
        }
    }
}

#[cfg(windows)]
fn push_winget_poppler_paths(paths: &mut Vec<PathBuf>, winget_packages_root: &Path) {
    let Ok(packages) = fs::read_dir(winget_packages_root) else {
        return;
    };

    for pkg_entry in packages.flatten() {
        let pkg_path = pkg_entry.path();
        if !pkg_path.is_dir() {
            continue;
        }
        let Some(pkg_name) = pkg_path.file_name().and_then(|s| s.to_str()) else {
            continue;
        };
        if !pkg_name
            .to_ascii_lowercase()
            .starts_with("oschwartz10612.poppler")
        {
            continue;
        }

        paths.push(pkg_path.join("Library").join("bin"));
        paths.push(pkg_path.join("bin"));

        let Ok(children) = fs::read_dir(&pkg_path) else {
            continue;
        };
        for child in children.flatten() {
            let child_path = child.path();
            if !child_path.is_dir() {
                continue;
            }
            let Some(child_name) = child_path.file_name().and_then(|s| s.to_str()) else {
                continue;
            };
            if child_name.to_ascii_lowercase().starts_with("poppler") {
                paths.push(child_path.join("Library").join("bin"));
                paths.push(child_path.join("bin"));
            }
        }
    }
}

fn resolve_command(program: &str) -> Result<PathBuf, String> {
    if let Ok(cache) = resolved_command_cache().lock() {
        if let Some(path) = cache.get(program) {
            return Ok(path.clone());
        }
    }

    if let Some(p) = find_in_path(program) {
        if let Ok(mut cache) = resolved_command_cache().lock() {
            cache.insert(program.to_string(), p.clone());
        }
        return Ok(p);
    }

    let candidates = command_candidates(program);
    for dir in extra_command_search_paths(program) {
        for name in &candidates {
            let full = dir.join(name);
            if full.exists() && full.is_file() {
                if let Ok(mut cache) = resolved_command_cache().lock() {
                    cache.insert(program.to_string(), full.clone());
                }
                return Ok(full);
            }
        }
    }

    Err(format!(
        "Failed to locate command `{}`. Checked PATH and platform-specific common install directories.",
        program
    ))
}

fn run_command(program: &str, args: &[OsString]) -> Result<(), String> {
    let output = run_command_capture(program, args)?;
    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr);
        let stdout = String::from_utf8_lossy(&output.stdout);
        return Err(format!(
            "`{}` failed with status {}.\nstdout:\n{}\nstderr:\n{}",
            program, output.status, stdout, stderr
        ));
    }
    Ok(())
}

fn run_command_capture(program: &str, args: &[OsString]) -> Result<Output, String> {
    let command_path = resolve_command(program)?;
    let _permit = acquire_command_permit(program)?;
    Command::new(&command_path)
        .args(args)
        .output()
        .map_err(|e| {
            format!(
                "Failed to execute `{}` at `{}`. Error: {}",
                program,
                command_path.display(),
                e
            )
        })
}

fn ensure_file(path: &Path, label: &str) -> Result<(), String> {
    if !path.exists() {
        return Err(format!("{} does not exist: {}", label, path.display()));
    }
    if !path.is_file() {
        return Err(format!("{} is not a file: {}", label, path.display()));
    }
    Ok(())
}

fn ensure_dir(path: &Path, label: &str) -> Result<(), String> {
    if !path.exists() {
        fs::create_dir_all(path)
            .map_err(|e| format!("Failed to create {} `{}`: {}", label, path.display(), e))?;
    }
    if !path.is_dir() {
        return Err(format!("{} is not a directory: {}", label, path.display()));
    }
    Ok(())
}

fn list_generated_images(
    output_dir: &Path,
    fmt: &str,
    prefix: &str,
) -> Result<Vec<String>, String> {
    let mut files: Vec<PathBuf> = fs::read_dir(output_dir)
        .map_err(|e| {
            format!(
                "Failed to read output directory `{}`: {}",
                output_dir.display(),
                e
            )
        })?
        .filter_map(Result::ok)
        .map(|entry| entry.path())
        .filter(|path| {
            path.is_file()
                && path
                    .extension()
                    .map(|ext| ext.eq_ignore_ascii_case(fmt))
                    .unwrap_or(false)
                && path
                    .file_stem()
                    .map(|stem| stem.to_string_lossy().starts_with(prefix))
                    .unwrap_or(false)
        })
        .collect();

    files.sort();

    Ok(files
        .iter()
        .map(|p| p.to_string_lossy().to_string())
        .collect::<Vec<_>>())
}

fn list_prefixed_files(
    output_dir: &Path,
    prefix: &str,
    allowed_exts: &[&str],
) -> Result<Vec<String>, String> {
    let mut files: Vec<PathBuf> = fs::read_dir(output_dir)
        .map_err(|e| {
            format!(
                "Failed to read output directory `{}`: {}",
                output_dir.display(),
                e
            )
        })?
        .filter_map(Result::ok)
        .map(|entry| entry.path())
        .filter(|path| {
            path.is_file()
                && path
                    .extension()
                    .and_then(|ext| ext.to_str())
                    .map(|ext| {
                        allowed_exts
                            .iter()
                            .any(|item| ext.eq_ignore_ascii_case(item))
                    })
                    .unwrap_or(false)
                && path
                    .file_stem()
                    .map(|stem| stem.to_string_lossy().starts_with(prefix))
                    .unwrap_or(false)
        })
        .collect();

    files.sort();
    Ok(files
        .into_iter()
        .map(|path| path.to_string_lossy().to_string())
        .collect())
}

fn generated_paginated_output_path(
    output_dir: &Path,
    prefix: &str,
    page_number: usize,
    ext: &str,
) -> PathBuf {
    output_dir.join(format!("{}-{}.{}", prefix, page_number, ext))
}

fn extracted_image_matches_requested_format(path: &Path, requested_ext: &str) -> bool {
    path.extension()
        .and_then(|ext| ext.to_str())
        .map(normalized_image_extension)
        .map(|ext| ext.eq_ignore_ascii_case(normalized_image_extension(requested_ext)))
        .unwrap_or(false)
}

fn place_extracted_image(src: &Path, dst: &Path) -> Result<(), String> {
    if src == dst {
        return Ok(());
    }
    if let Some(parent) = dst.parent() {
        if !parent.as_os_str().is_empty() {
            ensure_dir(parent, "output directory")?;
        }
    }
    if dst.exists() {
        fs::remove_file(dst).map_err(|e| {
            format!(
                "Failed to replace extracted image `{}` before writing: {}",
                dst.display(),
                e
            )
        })?;
    }
    match fs::rename(src, dst) {
        Ok(()) => Ok(()),
        Err(rename_err) => {
            fs::copy(src, dst).map_err(|copy_err| {
                format!(
                    "Failed to place extracted image `{}` -> `{}`: rename error: {}; copy error: {}",
                    src.display(),
                    dst.display(),
                    rename_err,
                    copy_err
                )
            })?;
            Ok(())
        }
    }
}

fn detect_image_format(fmt: &str, path: &Path) -> Result<ImageFormat, String> {
    let normalized = fmt.to_ascii_lowercase();
    match normalized.as_str() {
        "jpg" | "jpeg" => Ok(ImageFormat::Jpeg),
        "png" => Ok(ImageFormat::Png),
        "tif" | "tiff" => Ok(ImageFormat::Tiff),
        _ => {
            let bytes = read_file_bytes(path)?;
            if let Ok(guessed) = guess_output_image_format(path, &bytes) {
                return Ok(guessed);
            }

            match path
                .extension()
                .and_then(|v| v.to_str())
                .map(|v| v.to_ascii_lowercase())
            {
                Some(ext) if ext == "jpg" || ext == "jpeg" => Ok(ImageFormat::Jpeg),
                Some(ext) if ext == "png" => Ok(ImageFormat::Png),
                Some(ext) if ext == "tif" || ext == "tiff" => Ok(ImageFormat::Tiff),
                _ => Err(format!(
                    "Unsupported image format for limit enforcement: `{}`",
                    path.display()
                )),
            }
        }
    }
}

fn guess_image_format(path: &Path, bytes: &[u8]) -> Result<ImageFormat, String> {
    image::guess_format(bytes)
        .map_err(|_| format!("Unsupported image format for `{}`", path.display()))
}

fn guess_output_image_format(path: &Path, bytes: &[u8]) -> Result<ImageFormat, String> {
    match guess_image_format(path, bytes)? {
        ImageFormat::Jpeg => Ok(ImageFormat::Jpeg),
        ImageFormat::Png => Ok(ImageFormat::Png),
        ImageFormat::Tiff => Ok(ImageFormat::Tiff),
        _ => Err(format!(
            "Unsupported image format for limit enforcement: `{}`",
            path.display()
        )),
    }
}

fn load_dynamic_image(path: &Path) -> Result<DynamicImage, String> {
    let bytes = read_file_bytes(path)?;
    image::load_from_memory(&bytes)
        .map_err(|e| format!("Failed to read image `{}`: {}", path.display(), e))
}

fn quick_png_dimensions(path: &Path) -> Option<(u32, u32)> {
    let mut buf = [0_u8; 24];
    let mut file = fs::File::open(path).ok()?;
    let read_n = file.read(&mut buf).ok()?;
    if read_n < 24 {
        return None;
    }
    if &buf[0..8] != b"\x89PNG\r\n\x1a\n" {
        return None;
    }
    if &buf[12..16] != b"IHDR" {
        return None;
    }
    let width = u32::from_be_bytes([buf[16], buf[17], buf[18], buf[19]]);
    let height = u32::from_be_bytes([buf[20], buf[21], buf[22], buf[23]]);
    if width == 0 || height == 0 {
        return None;
    }
    Some((width, height))
}

fn quick_jpeg_dimensions(path: &Path) -> Option<(u32, u32)> {
    let file = fs::File::open(path).ok()?;
    let mut reader = BufReader::new(file);
    let mut marker_bytes = [0_u8; 2];
    reader.read_exact(&mut marker_bytes).ok()?;
    if marker_bytes != [0xFF, 0xD8] {
        return None;
    }

    loop {
        let mut marker = [0_u8; 1];
        reader.read_exact(&mut marker).ok()?;
        while marker[0] != 0xFF {
            reader.read_exact(&mut marker).ok()?;
        }

        reader.read_exact(&mut marker).ok()?;
        while marker[0] == 0xFF {
            reader.read_exact(&mut marker).ok()?;
        }
        let marker = marker[0];
        if marker == 0xD9 || marker == 0xDA {
            return None;
        }
        if marker == 0x01 || (marker >= 0xD0 && marker <= 0xD7) {
            continue;
        }

        let mut len_buf = [0_u8; 2];
        reader.read_exact(&mut len_buf).ok()?;
        let seg_len = i64::from(u16::from_be_bytes(len_buf));
        if seg_len < 2 {
            return None;
        }

        let is_sof = matches!(
            marker,
            0xC0 | 0xC1
                | 0xC2
                | 0xC3
                | 0xC5
                | 0xC6
                | 0xC7
                | 0xC9
                | 0xCA
                | 0xCB
                | 0xCD
                | 0xCE
                | 0xCF
        );
        if is_sof {
            if seg_len < 7 {
                return None;
            }
            let mut sof_buf = [0_u8; 5];
            reader.read_exact(&mut sof_buf).ok()?;
            let height = u16::from_be_bytes([sof_buf[1], sof_buf[2]]) as u32;
            let width = u16::from_be_bytes([sof_buf[3], sof_buf[4]]) as u32;
            if width == 0 || height == 0 {
                return None;
            }
            return Some((width, height));
        }

        reader.seek(SeekFrom::Current(seg_len - 2)).ok()?;
    }
}

fn quick_image_dimensions(path: &Path) -> Option<(u32, u32)> {
    let ext = path
        .extension()
        .and_then(|v| v.to_str())
        .map(|v| v.to_ascii_lowercase())?;
    match ext.as_str() {
        "png" => quick_png_dimensions(path),
        "jpg" | "jpeg" => quick_jpeg_dimensions(path),
        _ => None,
    }
}

fn save_dynamic_image(
    img: &DynamicImage,
    output_path: &Path,
    format: ImageFormat,
    jpeg_quality: u8,
) -> Result<(), String> {
    let file = fs::File::create(output_path).map_err(|e| {
        format!(
            "Failed to create image file `{}`: {}",
            output_path.display(),
            e
        )
    })?;
    let mut writer = BufWriter::new(file);

    if matches!(format, ImageFormat::Jpeg) {
        let mut encoder = JpegEncoder::new_with_quality(&mut writer, jpeg_quality);
        encoder
            .encode_image(img)
            .map_err(|e| format!("Failed to encode JPEG `{}`: {}", output_path.display(), e))?;
    } else {
        img.write_to(&mut writer, format)
            .map_err(|e| format!("Failed to encode image `{}`: {}", output_path.display(), e))?;
    }

    writer
        .flush()
        .map_err(|e| format!("Failed to flush image `{}`: {}", output_path.display(), e))?;
    Ok(())
}

fn enforce_image_limits(
    path: &Path,
    fmt: &str,
    max_area: u64,
    max_bytes: u64,
) -> Result<(), String> {
    ensure_file(path, "image output")?;

    let format = detect_image_format(fmt, path)?;
    let initial_bytes = fs::metadata(path)
        .map_err(|e| format!("Failed to stat image `{}`: {}", path.display(), e))?
        .len();
    if let Some((width, height)) = quick_image_dimensions(path) {
        let initial_area = u64::from(width) * u64::from(height);
        if initial_area <= max_area && initial_bytes <= max_bytes {
            debug_log(format!(
                "enforce skip path=`{}` width={} height={} area={} bytes={}",
                path.display(),
                width,
                height,
                initial_area,
                initial_bytes
            ));
            return Ok(());
        }
    }

    let mut image = load_dynamic_image(path)?;
    let mut jpeg_quality: u8 = 85;
    let initial_area = u64::from(image.width()) * u64::from(image.height());
    if matches!(format, ImageFormat::Jpeg) && initial_bytes > max_bytes {
        let oversize_ratio = initial_bytes as f64 / max_bytes as f64;
        jpeg_quality = if oversize_ratio >= 2.5 {
            60
        } else if oversize_ratio >= 1.5 {
            70
        } else if oversize_ratio >= 1.15 {
            78
        } else {
            85
        };
    }
    debug_log(format!(
        "enforce start path=`{}` format={:?} width={} height={} area={} bytes={} max_area={} max_bytes={}",
        path.display(),
        format,
        image.width(),
        image.height(),
        initial_area,
        initial_bytes,
        max_area,
        max_bytes
    ));

    let mut initial_ratio = 1.0_f64;
    if initial_area > max_area {
        initial_ratio = initial_ratio.min((max_area as f64 / initial_area as f64).sqrt() * 0.995);
    }
    if initial_bytes > max_bytes && !matches!(format, ImageFormat::Jpeg) {
        initial_ratio = initial_ratio.min((max_bytes as f64 / initial_bytes as f64).sqrt() * 0.9);
    }

    if initial_ratio < 1.0 {
        let new_w = ((image.width() as f64 * initial_ratio).floor() as u32).max(1);
        let new_h = ((image.height() as f64 * initial_ratio).floor() as u32).max(1);
        debug_log(format!(
            "enforce initial_resize path=`{}` ratio={:.4} width={} height={} -> {}x{}",
            path.display(),
            initial_ratio,
            image.width(),
            image.height(),
            new_w,
            new_h
        ));
        image = image.resize(new_w, new_h, FilterType::Triangle);
    }

    for attempt in 0..6 {
        save_dynamic_image(&image, path, format, jpeg_quality)?;

        let bytes = fs::metadata(path)
            .map_err(|e| format!("Failed to stat image `{}`: {}", path.display(), e))?
            .len();
        let area = u64::from(image.width()) * u64::from(image.height());
        debug_log(format!(
            "enforce attempt={} path=`{}` quality={} area={} bytes={}",
            attempt + 1,
            path.display(),
            jpeg_quality,
            area,
            bytes
        ));
        if area <= max_area && bytes <= max_bytes {
            debug_log(format!(
                "enforce done path=`{}` width={} height={} area={} bytes={} quality={}",
                path.display(),
                image.width(),
                image.height(),
                area,
                bytes,
                jpeg_quality
            ));
            return Ok(());
        }

        if matches!(format, ImageFormat::Jpeg)
            && area <= max_area
            && bytes > max_bytes
            && jpeg_quality > 40
        {
            let next_quality = if bytes > max_bytes.saturating_mul(2) {
                jpeg_quality.saturating_sub(15)
            } else if bytes > ((max_bytes as f64) * 1.25) as u64 {
                jpeg_quality.saturating_sub(12)
            } else {
                jpeg_quality.saturating_sub(8)
            };
            if next_quality < jpeg_quality {
                debug_log(format!(
                    "enforce quality_drop path=`{}` quality={} -> {} bytes={} max_bytes={}",
                    path.display(),
                    jpeg_quality,
                    next_quality,
                    bytes,
                    max_bytes
                ));
                jpeg_quality = next_quality.max(40);
                continue;
            }
        }

        if matches!(format, ImageFormat::Jpeg) && bytes > max_bytes && jpeg_quality > 50 {
            let next_quality = jpeg_quality.saturating_sub(10).max(50);
            if next_quality < jpeg_quality {
                debug_log(format!(
                    "enforce quality_drop path=`{}` quality={} -> {} bytes={} max_bytes={}",
                    path.display(),
                    jpeg_quality,
                    next_quality,
                    bytes,
                    max_bytes
                ));
                jpeg_quality = next_quality;
                continue;
            }
        }

        let mut ratio = 1.0_f64;
        if area > max_area {
            ratio = ratio.min((max_area as f64 / area as f64).sqrt() * 0.985);
        }
        if bytes > max_bytes {
            let byte_factor = if area <= max_area { 0.94 } else { 0.88 };
            ratio = ratio.min((max_bytes as f64 / bytes as f64).sqrt() * byte_factor);
        }
        if ratio >= 0.995 {
            ratio = if bytes > max_bytes || area > max_area {
                0.92
            } else {
                1.0
            };
        }
        if ratio >= 1.0 {
            break;
        }

        let new_w = ((image.width() as f64 * ratio).floor() as u32).max(1);
        let new_h = ((image.height() as f64 * ratio).floor() as u32).max(1);
        debug_log(format!(
            "enforce resize path=`{}` ratio={:.4} width={} height={} -> {}x{}",
            path.display(),
            ratio,
            image.width(),
            image.height(),
            new_w,
            new_h
        ));
        image = image.resize(new_w, new_h, FilterType::Triangle);
    }

    let final_bytes = fs::metadata(path)
        .map_err(|e| format!("Failed to stat image `{}`: {}", path.display(), e))?
        .len();
    let final_area = u64::from(image.width()) * u64::from(image.height());
    Err(format!(
        "Failed to enforce limits for `{}` after retries: area={} bytes={}",
        path.display(),
        final_area,
        final_bytes
    ))
}

fn image_is_within_limits_fast(path: &Path, max_area: u64, max_bytes: u64) -> Result<bool, String> {
    let bytes = fs::metadata(path)
        .map_err(|e| format!("Failed to stat image `{}`: {}", path.display(), e))?
        .len();
    if bytes > max_bytes {
        return Ok(false);
    }

    let Some((width, height)) = quick_image_dimensions(path) else {
        return Ok(false);
    };
    let area = u64::from(width) * u64::from(height);
    Ok(area <= max_area)
}

fn prepare_constrained_images(
    image_paths: &[String],
    max_area: u64,
    max_size_mb: f64,
) -> Result<(Vec<String>, TempDir), String> {
    if image_paths.is_empty() {
        return Err("image_paths cannot be empty".to_string());
    }
    let (max_area, max_bytes) = parse_image_limits(max_area, max_size_mb)?;
    let tmp = tempdir().map_err(|e| format!("Failed to create temp dir: {}", e))?;
    let mut constrained = Vec::with_capacity(image_paths.len());

    for (idx, path) in image_paths.iter().enumerate() {
        let src = Path::new(path);
        ensure_file(src, "image file")?;
        if image_is_within_limits_fast(src, max_area, max_bytes)? {
            debug_log(format!(
                "image_to_pdf reuse source image=`{}` without temp copy",
                src.display()
            ));
            constrained.push(path.clone());
            continue;
        }

        let ext = src
            .extension()
            .and_then(|v| v.to_str())
            .unwrap_or("png")
            .to_ascii_lowercase();
        let dst = tmp.path().join(format!("img_{:06}.{}", idx + 1, ext));
        fs::copy(src, &dst).map_err(|e| {
            format!(
                "Failed to copy image `{}` to `{}`: {}",
                src.display(),
                dst.display(),
                e
            )
        })?;
        enforce_image_limits(&dst, "", max_area, max_bytes)?;
        constrained.push(dst.to_string_lossy().to_string());
    }
    Ok((constrained, tmp))
}

#[derive(Clone)]
struct EnforceJob {
    index: usize,
    path: String,
}

fn enforce_rendered_images(
    files: &[String],
    fmt: &str,
    max_area: u64,
    max_bytes: u64,
) -> Result<(), String> {
    let mut jobs = Vec::new();

    for (index, file) in files.iter().enumerate() {
        let path = Path::new(file);
        let bytes = fs::metadata(path)
            .map_err(|e| format!("Failed to stat image `{}`: {}", path.display(), e))?
            .len();
        let mut within_limits = false;
        if let Some((w, h)) = quick_image_dimensions(path) {
            let area = u64::from(w) * u64::from(h);
            if area <= max_area && bytes <= max_bytes {
                within_limits = true;
                debug_log(format!(
                    "pdf_to_image keep file=`{}` area={} bytes={}",
                    path.display(),
                    area,
                    bytes
                ));
            }
        }
        if !within_limits {
            debug_log(format!(
                "pdf_to_image enqueue enforce page={} file=`{}` bytes={}",
                index + 1,
                path.display(),
                bytes
            ));
            jobs.push(EnforceJob {
                index,
                path: file.clone(),
            });
        }
    }

    if jobs.is_empty() {
        debug_log("pdf_to_image enforce skipped: all pages already within limits");
        return Ok(());
    }

    if jobs.len() == 1 {
        let job = &jobs[0];
        debug_log(format!(
            "pdf_to_image enforce serial page={} file=`{}`",
            job.index + 1,
            job.path
        ));
        return enforce_image_limits(Path::new(&job.path), fmt, max_area, max_bytes);
    }

    let worker_count = thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1)
        .min(MAX_ENFORCE_WORKERS)
        .min(jobs.len())
        .max(1);
    debug_log(format!(
        "pdf_to_image enforce parallel jobs={} workers={} cap={}",
        jobs.len(),
        worker_count,
        MAX_ENFORCE_WORKERS
    ));

    let mut buckets = vec![Vec::<EnforceJob>::new(); worker_count];
    for (i, job) in jobs.into_iter().enumerate() {
        buckets[i % worker_count].push(job);
    }

    thread::scope(|scope| -> Result<(), String> {
        let mut handles = Vec::with_capacity(worker_count);
        for (worker_id, bucket) in buckets.into_iter().enumerate() {
            let fmt = fmt.to_string();
            handles.push(scope.spawn(move || -> Result<(), String> {
                debug_log(format!(
                    "pdf_to_image worker={} start jobs={}",
                    worker_id + 1,
                    bucket.len()
                ));
                for job in bucket {
                    debug_log(format!(
                        "pdf_to_image enforce worker={} page={} file=`{}`",
                        worker_id + 1,
                        job.index + 1,
                        job.path
                    ));
                    enforce_image_limits(Path::new(&job.path), &fmt, max_area, max_bytes).map_err(
                        |e| {
                            format!(
                                "Failed to enforce limits page={} file=`{}`: {}",
                                job.index + 1,
                                job.path,
                                e
                            )
                        },
                    )?;
                }
                Ok(())
            }));
        }

        for handle in handles {
            match handle.join() {
                Ok(result) => result?,
                Err(_) => return Err("pdf_to_image enforce worker panicked".to_string()),
            }
        }
        Ok(())
    })
}

fn image_paths_to_pdf(
    image_paths: &[String],
    output_pdf: String,
    page_dpi: f32,
) -> Result<String, String> {
    if image_paths.is_empty() {
        return Err("image_paths cannot be empty".to_string());
    }

    let output_pdf_path = PathBuf::from(&output_pdf);
    if let Some(parent) = output_pdf_path.parent() {
        if !parent.as_os_str().is_empty() {
            ensure_dir(parent, "output directory")?;
        }
    }

    let (first_w, first_h, first_pdf_img) = pdf_image_with_dimensions_from_path(&image_paths[0])?;

    let (doc, page1, layer1) = PdfDocument::new(
        "dy_docs_tools image_to_pdf",
        px_to_mm(first_w, page_dpi),
        px_to_mm(first_h, page_dpi),
        "Layer 1",
    );

    let layer = doc.get_page(page1).get_layer(layer1);
    first_pdf_img.add_to_layer(
        layer,
        ImageTransform {
            translate_x: Some(Mm(0.0)),
            translate_y: Some(Mm(0.0)),
            rotate: None,
            scale_x: Some(1.0),
            scale_y: Some(1.0),
            dpi: Some(page_dpi),
        },
    );

    for img_path in image_paths.iter().skip(1) {
        let (w, h, pdf_img) = pdf_image_with_dimensions_from_path(img_path)?;
        let (page, layer) = doc.add_page(px_to_mm(w, page_dpi), px_to_mm(h, page_dpi), "Layer 1");
        let layer_ref = doc.get_page(page).get_layer(layer);
        pdf_img.add_to_layer(
            layer_ref,
            ImageTransform {
                translate_x: Some(Mm(0.0)),
                translate_y: Some(Mm(0.0)),
                rotate: None,
                scale_x: Some(1.0),
                scale_y: Some(1.0),
                dpi: Some(page_dpi),
            },
        );
    }

    let mut out = BufWriter::new(fs::File::create(&output_pdf_path).map_err(|e| {
        format!(
            "Failed to create output pdf `{}`: {}",
            output_pdf_path.display(),
            e
        )
    })?);
    doc.save(&mut out)
        .map_err(|e| format!("Failed to write pdf `{}`: {}", output_pdf_path.display(), e))?;
    Ok(output_pdf)
}

fn pdf_image_with_dimensions_from_path(image_path: &str) -> Result<(u32, u32, PdfImage), String> {
    let path = Path::new(image_path);
    let image_data = read_file_bytes(path)?;
    let format = guess_image_format(path, &image_data)?;
    if matches!(format, ImageFormat::Jpeg) {
        return jpeg_pdf_image_from_bytes(path, image_data);
    }

    let dyn_img = image_crate::load_from_memory(&image_data)
        .map_err(|e| format!("Failed to open image `{}`: {}", path.display(), e))?;
    let width = dyn_img.width();
    let height = dyn_img.height();
    Ok((width, height, PdfImage::from_dynamic_image(&dyn_img)))
}

fn jpeg_pdf_image_from_bytes(
    path: &Path,
    image_data: Vec<u8>,
) -> Result<(u32, u32, PdfImage), String> {
    let mut reader = Cursor::new(image_data.as_slice());
    let decoder = JpegDecoder::new(&mut reader)
        .map_err(|e| format!("Failed to parse jpeg header `{}`: {}", path.display(), e))?;
    let (width, height) = decoder.dimensions();
    let color_type = decoder.color_type();

    debug_log(format!(
        "image_to_pdf fast_jpeg path=`{}` width={} height={} bytes={}",
        path.display(),
        width,
        height,
        image_data.len()
    ));

    Ok((
        width,
        height,
        PdfImage::from(ImageXObject {
            width: Px(width as usize),
            height: Px(height as usize),
            color_space: ColorSpace::from(color_type),
            bits_per_component: ColorBits::from(color_type),
            interpolate: true,
            image_data,
            image_filter: Some(ImageFilter::DCT),
            smask: None,
            clipping_bbox: None,
        }),
    ))
}

fn px_to_mm(px: u32, page_dpi: f32) -> Mm {
    // Convert pixel size to physical page size with target page DPI.
    Mm((px as f64 * 25.4 / page_dpi as f64) as f32)
}

fn bytes_to_pdf_data_url(bytes: &[u8]) -> String {
    let payload = BASE64_STANDARD.encode(bytes);
    format!("data:application/pdf;base64,{}", payload)
}

fn bytes_to_data_url(bytes: &[u8], mime: &str) -> String {
    let payload = BASE64_STANDARD.encode(bytes);
    format!("data:{};base64,{}", mime, payload)
}

fn read_file_bytes(path: &Path) -> Result<Vec<u8>, String> {
    fs::read(path).map_err(|e| format!("Failed to read file `{}`: {}", path.display(), e))
}

fn guess_mime_type(path: &Path) -> &'static str {
    match to_lower_ext(path).as_deref() {
        Some("pdf") => "application/pdf",
        Some("docx") => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        Some("jpg" | "jpeg") => "image/jpeg",
        Some("png") => "image/png",
        Some("tif" | "tiff") => "image/tiff",
        _ => "application/octet-stream",
    }
}

fn passthrough_file_path(input_path: String) -> Result<String, String> {
    let path = PathBuf::from(&input_path);
    ensure_file(&path, "input_path")?;
    Ok(input_path)
}

fn passthrough_file_bytes(input_path: String) -> Result<Vec<u8>, String> {
    let path = PathBuf::from(&input_path);
    ensure_file(&path, "input_path")?;
    read_file_bytes(&path)
}

fn passthrough_file_data_url(input_path: String) -> Result<String, String> {
    let path = PathBuf::from(&input_path);
    ensure_file(&path, "input_path")?;
    let bytes = read_file_bytes(&path)?;
    Ok(bytes_to_data_url(&bytes, guess_mime_type(&path)))
}

fn py_value_err(msg: String) -> PyErr {
    PyValueError::new_err(msg)
}

fn py_runtime_err(msg: String) -> PyErr {
    PyRuntimeError::new_err(msg)
}

fn lopdf_to_f64(obj: &LopdfObject) -> Option<f64> {
    match obj {
        LopdfObject::Integer(v) => Some(*v as f64),
        LopdfObject::Real(v) => Some((*v).into()),
        _ => None,
    }
}

fn lopdf_resolve_object(doc: &LopdfDocument, obj: &LopdfObject) -> Result<LopdfObject, String> {
    match obj {
        LopdfObject::Reference(id) => doc
            .get_object(*id)
            .map(|o| o.clone())
            .map_err(|e| format!("Failed to resolve PDF object {:?}: {}", id, e)),
        _ => Ok(obj.clone()),
    }
}

fn lopdf_inherited_page_value(
    doc: &LopdfDocument,
    page_id: LopdfObjectId,
    key: &[u8],
) -> Result<Option<LopdfObject>, String> {
    let mut current = LopdfObject::Reference(page_id);
    let mut visited = HashSet::new();

    for _ in 0..64 {
        if let LopdfObject::Reference(id) = current {
            if !visited.insert(id) {
                return Err(format!(
                    "Detected cycle while resolving page tree key `{}` from {:?}",
                    String::from_utf8_lossy(key),
                    page_id
                ));
            }
            current = doc
                .get_object(id)
                .map_err(|e| format!("Failed to read page tree object {:?}: {}", id, e))?
                .clone();
        }

        let current_dict = match current {
            LopdfObject::Dictionary(dict) => dict,
            _ => {
                return Err(format!(
                    "Page tree object for {:?} is not a dictionary while resolving `{}`",
                    page_id,
                    String::from_utf8_lossy(key)
                ))
            }
        };

        if let Ok(value) = current_dict.get(key) {
            return Ok(Some(lopdf_resolve_object(doc, value)?));
        }

        current = match current_dict.get(b"Parent") {
            Ok(parent) => parent.clone(),
            Err(_) => return Ok(None),
        };
    }

    Err(format!(
        "Exceeded page tree depth while resolving `{}` from {:?}",
        String::from_utf8_lossy(key),
        page_id
    ))
}

fn lopdf_page_dimensions_points(
    doc: &LopdfDocument,
    page_id: LopdfObjectId,
) -> Result<(f64, f64), String> {
    let media_box = lopdf_inherited_page_value(doc, page_id, b"MediaBox")?
        .ok_or_else(|| format!("Page {:?} missing MediaBox", page_id))?;
    let arr = match media_box {
        LopdfObject::Array(arr) => arr,
        _ => return Err(format!("Page {:?} MediaBox is not an array", page_id)),
    };
    if arr.len() != 4 {
        return Err(format!(
            "Page {:?} MediaBox length is {}",
            page_id,
            arr.len()
        ));
    }
    let x0 =
        lopdf_to_f64(&arr[0]).ok_or_else(|| format!("Invalid MediaBox x0 for {:?}", page_id))?;
    let y0 =
        lopdf_to_f64(&arr[1]).ok_or_else(|| format!("Invalid MediaBox y0 for {:?}", page_id))?;
    let x1 =
        lopdf_to_f64(&arr[2]).ok_or_else(|| format!("Invalid MediaBox x1 for {:?}", page_id))?;
    let y1 =
        lopdf_to_f64(&arr[3]).ok_or_else(|| format!("Invalid MediaBox y1 for {:?}", page_id))?;
    let width = (x1 - x0).abs();
    let height = (y1 - y0).abs();
    if width <= 0.0 || height <= 0.0 {
        return Err(format!("Page {:?} has non-positive MediaBox", page_id));
    }
    Ok((width, height))
}

fn page_area_pixels_at_dpi(width_pt: f64, height_pt: f64, dpi: f32) -> u64 {
    let width_px = width_pt * dpi as f64 / 72.0;
    let height_px = height_pt * dpi as f64 / 72.0;
    (width_px * height_px).round().max(0.0) as u64
}

fn compute_page_safe_render_dpi(
    width_pt: f64,
    height_pt: f64,
    requested_dpi: u32,
    max_area: u64,
) -> u32 {
    if requested_dpi == 0 {
        return 1;
    }
    let area_points = width_pt * height_pt;
    if area_points <= 0.0 {
        return requested_dpi.max(1);
    }
    let requested_area = page_area_pixels_at_dpi(width_pt, height_pt, requested_dpi as f32);
    if requested_area <= max_area {
        return requested_dpi.max(1);
    }
    let safe_dpi = ((max_area as f64) * 72.0_f64 * 72.0_f64 / area_points).sqrt();
    safe_dpi.floor().max(1.0).min(requested_dpi as f64) as u32
}

fn parse_pdfinfo_pages(output: &str) -> Result<u32, String> {
    let line = output
        .lines()
        .find(|line| line.trim_start().starts_with("Pages:"))
        .ok_or_else(|| "pdfinfo output missing `Pages:` line".to_string())?;
    let value = line
        .split_once(':')
        .map(|(_, value)| value.trim())
        .ok_or_else(|| format!("Invalid pdfinfo `Pages:` line: {}", line))?;
    value
        .parse::<u32>()
        .map_err(|e| format!("Failed to parse pdfinfo pages from `{}`: {}", line, e))
}

fn parse_pdfinfo_size_line(line: &str) -> Option<(f64, f64)> {
    let (_, value) = line.split_once(':')?;
    let mut tokens = value.split_whitespace();
    let width = tokens.next()?.parse::<f64>().ok()?;
    let x_token = tokens.next()?;
    if x_token != "x" {
        return None;
    }
    let height = tokens.next()?.parse::<f64>().ok()?;
    Some((width, height))
}

fn parse_pdfinfo_page_size(output: &str, page_number: Option<u32>) -> Result<(f64, f64), String> {
    if let Some(page_number) = page_number {
        let prefix = format!("Page    {} size:", page_number);
        if let Some(line) = output
            .lines()
            .find(|line| line.trim_start().starts_with(&prefix))
        {
            return parse_pdfinfo_size_line(line)
                .ok_or_else(|| format!("Failed to parse pdfinfo page size from line `{}`", line));
        }

        let prefix = format!("Page {} size:", page_number);
        if let Some(line) = output
            .lines()
            .find(|line| line.trim_start().starts_with(&prefix))
        {
            return parse_pdfinfo_size_line(line)
                .ok_or_else(|| format!("Failed to parse pdfinfo page size from line `{}`", line));
        }
    }

    let line = output
        .lines()
        .find(|line| line.trim_start().starts_with("Page size:"))
        .ok_or_else(|| "pdfinfo output missing page size line".to_string())?;
    parse_pdfinfo_size_line(line)
        .ok_or_else(|| format!("Failed to parse pdfinfo page size from line `{}`", line))
}

fn pdfinfo_output(pdf_path: &Path, page_number: Option<u32>) -> Result<String, String> {
    let mut args = Vec::new();
    if let Some(page_number) = page_number {
        args.push(OsString::from("-f"));
        args.push(OsString::from(page_number.to_string()));
        args.push(OsString::from("-l"));
        args.push(OsString::from(page_number.to_string()));
    }
    args.push(pdf_path.as_os_str().to_os_string());

    let output = run_command_capture("pdfinfo", &args)?;
    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr);
        let stdout = String::from_utf8_lossy(&output.stdout);
        return Err(format!(
            "`pdfinfo` failed with status {}.\nstdout:\n{}\nstderr:\n{}",
            output.status, stdout, stderr
        ));
    }
    Ok(String::from_utf8_lossy(&output.stdout).into_owned())
}

fn pdfinfo_pages_with_dimensions(input_pdf: &Path) -> Result<Vec<(u32, f64, f64)>, String> {
    let output = pdfinfo_output(input_pdf, None)?;
    let page_count = parse_pdfinfo_pages(&output)?;
    if page_count == 0 {
        return Err(format!(
            "pdfinfo reported zero pages for `{}`",
            input_pdf.display()
        ));
    }

    let mut pages = Vec::with_capacity(page_count as usize);
    if page_count == 1 {
        let (width_pt, height_pt) = parse_pdfinfo_page_size(&output, None)?;
        pages.push((1, width_pt, height_pt));
        return Ok(pages);
    }

    for page_number in 1..=page_count {
        let page_output = pdfinfo_output(input_pdf, Some(page_number))?;
        let (width_pt, height_pt) = parse_pdfinfo_page_size(&page_output, Some(page_number))?;
        pages.push((page_number, width_pt, height_pt));
    }
    Ok(pages)
}

#[derive(Clone)]
struct RenderJob {
    page_number: u32,
    render_dpi: u32,
    page_prefix: String,
}

fn render_pdf_pages_with_dynamic_dpi(
    input_pdf: &Path,
    output_dir: &Path,
    requested_dpi: u32,
    fmt: &str,
    prefix: &str,
    max_area: u64,
    max_size_mb: f64,
    render_workers: usize,
) -> Result<Vec<String>, String> {
    if requested_dpi == 0 {
        return Err("dpi must be > 0".to_string());
    }
    if !matches!(fmt, "png" | "jpg" | "jpeg" | "tif" | "tiff") {
        return Err("fmt must be one of: png, jpg, jpeg, tif, tiff".to_string());
    }
    let (max_area, _max_bytes) = parse_image_limits(max_area, max_size_mb)?;
    let pdf = input_pdf.to_path_buf();
    let doc = LopdfDocument::load(input_pdf)
        .map_err(|e| format!("Failed to parse PDF `{}`: {}", input_pdf.display(), e))?;
    let pages = doc.get_pages();
    let ppm_fmt = pdftoppm_output_format(fmt);
    let result_ext = generated_image_extension(fmt);
    let mut jobs = Vec::with_capacity(pages.len());
    let page_metrics = if pages.is_empty() {
        debug_log(format!(
            "pdf_to_pdf render fallback=pdfinfo reason=lopdf_get_pages_empty pdf=`{}`",
            input_pdf.display()
        ));
        pdfinfo_pages_with_dimensions(input_pdf)?
    } else {
        let mut metrics = Vec::with_capacity(pages.len());
        for (page_number, page_id) in pages {
            let (width_pt, height_pt) = match lopdf_page_dimensions_points(&doc, page_id) {
                Ok(dimensions) => dimensions,
                Err(err) => {
                    debug_log(format!(
                        "pdf_to_pdf render fallback=pdfinfo reason=page_dimensions page={} pdf=`{}` error={}",
                        page_number,
                        input_pdf.display(),
                        err
                    ));
                    let mut fallback = pdfinfo_pages_with_dimensions(input_pdf)?;
                    let (_, width_pt, height_pt) = fallback
                        .drain(..)
                        .find(|(candidate_page, _, _)| *candidate_page == page_number)
                        .ok_or_else(|| {
                            format!(
                                "pdfinfo did not return dimensions for page {} in `{}`",
                                page_number,
                                input_pdf.display()
                            )
                        })?;
                    (width_pt, height_pt)
                }
            };
            metrics.push((page_number, width_pt, height_pt));
        }
        metrics
    };

    for (page_number, width_pt, height_pt) in page_metrics {
        let render_dpi = compute_page_safe_render_dpi(width_pt, height_pt, requested_dpi, max_area);
        let page_area_at_requested =
            page_area_pixels_at_dpi(width_pt, height_pt, requested_dpi as f32);
        let page_area_at_render = page_area_pixels_at_dpi(width_pt, height_pt, render_dpi as f32);
        let page_prefix = format!("{}_{:06}", prefix, page_number);
        debug_log(format!(
            "render-dpi page={} size_pt={:.2}x{:.2} requested_dpi={} render_dpi={} area_at_requested={} area_at_render={}",
            page_number,
            width_pt,
            height_pt,
            requested_dpi,
            render_dpi,
            page_area_at_requested,
            page_area_at_render
        ));
        jobs.push(RenderJob {
            page_number,
            render_dpi,
            page_prefix,
        });
    }

    let worker_cap = render_workers.max(1);
    let worker_count = thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1)
        .min(worker_cap)
        .min(jobs.len())
        .max(1);
    debug_log(format!(
        "pdf_to_pdf render parallel pages={} workers={} cap={}",
        jobs.len(),
        worker_count,
        worker_cap
    ));

    let mut buckets = vec![Vec::<RenderJob>::new(); worker_count];
    for (i, job) in jobs.iter().cloned().enumerate() {
        buckets[i % worker_count].push(job);
    }

    let rendered = thread::scope(|scope| -> Result<Vec<(u32, String)>, String> {
        let mut handles = Vec::with_capacity(worker_count);
        for (worker_id, bucket) in buckets.into_iter().enumerate() {
            let pdf = pdf.clone();
            let output_dir = output_dir.to_path_buf();
            let ppm_fmt = ppm_fmt.to_string();
            let result_ext = result_ext.to_string();
            handles.push(scope.spawn(move || -> Result<Vec<(u32, String)>, String> {
                debug_log(format!(
                    "pdf_to_pdf render worker={} start jobs={}",
                    worker_id + 1,
                    bucket.len()
                ));
                let mut rendered = Vec::with_capacity(bucket.len());
                for job in bucket {
                    let out_prefix = output_dir.join(&job.page_prefix);
                    let args = vec![
                        OsString::from(format!("-{}", ppm_fmt)),
                        OsString::from("-singlefile"),
                        OsString::from("-f"),
                        OsString::from(job.page_number.to_string()),
                        OsString::from("-l"),
                        OsString::from(job.page_number.to_string()),
                        OsString::from("-r"),
                        OsString::from(job.render_dpi.to_string()),
                        pdf.as_os_str().to_os_string(),
                        out_prefix.as_os_str().to_os_string(),
                    ];
                    debug_log(format!(
                        "pdf_to_pdf render worker={} page={} command=pdftoppm format={} dpi={} pdf=`{}` prefix=`{}`",
                        worker_id + 1,
                        job.page_number,
                        ppm_fmt,
                        job.render_dpi,
                        pdf.display(),
                        out_prefix.display()
                    ));
                    run_command("pdftoppm", &args)?;
                    let rendered_path =
                        resolve_singlefile_output_path(&output_dir, &job.page_prefix, &result_ext)?;
                    rendered.push((job.page_number, rendered_path));
                }
                Ok(rendered)
            }));
        }

        let mut rendered = Vec::with_capacity(jobs.len());
        for handle in handles {
            match handle.join() {
                Ok(result) => rendered.extend(result?),
                Err(_) => return Err("pdf_to_pdf render worker panicked".to_string()),
            }
        }
        Ok(rendered)
    })?;
    let mut rendered = rendered;
    rendered.sort_by_key(|(page_number, _)| *page_number);
    let rendered = rendered
        .into_iter()
        .map(|(_, path)| path)
        .collect::<Vec<_>>();
    Ok(rendered)
}

#[derive(Clone)]
struct SimpleScanPageInfo {
    page_number: u32,
    width_pt: f64,
    height_pt: f64,
    image_bytes: u64,
}

fn is_simple_scan_safe_operator(operator: &str) -> bool {
    matches!(
        operator,
        "q" | "Q"
            | "cm"
            | "ri"
            | "i"
            | "J"
            | "j"
            | "w"
            | "M"
            | "d"
            | "gs"
            | "G"
            | "g"
            | "RG"
            | "rg"
            | "K"
            | "k"
            | "CS"
            | "cs"
            | "SC"
            | "SCN"
            | "sc"
            | "scn"
            | "BX"
            | "EX"
    )
}

fn analyze_simple_scan_page(
    doc: &LopdfDocument,
    page_number: u32,
    page_id: LopdfObjectId,
) -> Result<Option<SimpleScanPageInfo>, String> {
    let (width_pt, height_pt) = lopdf_page_dimensions_points(doc, page_id)?;
    debug_log(format!(
        "scan-check page={} size_pt={:.2}x{:.2}",
        page_number, width_pt, height_pt
    ));

    let content_data = doc
        .get_page_content(page_id)
        .map_err(|e| format!("Failed to read page {} content: {}", page_number, e))?;
    let content = LopdfContent::decode(&content_data)
        .map_err(|e| format!("Failed to decode page {} content: {}", page_number, e))?;

    let page_obj = doc
        .get_object(page_id)
        .map_err(|e| format!("Failed to read page {} object: {}", page_number, e))?;
    let page_dict = page_obj
        .as_dict()
        .map_err(|e| format!("Page {} object is not a dictionary: {}", page_number, e))?;
    let resources_obj = match page_dict.get(b"Resources") {
        Ok(obj) => obj,
        Err(_) => return Ok(None),
    };
    let resources = lopdf_resolve_object(doc, resources_obj)?;
    let resources_dict = match resources {
        LopdfObject::Dictionary(dict) => dict,
        _ => return Ok(None),
    };
    let xobject_obj = match resources_dict.get(b"XObject") {
        Ok(obj) => obj,
        Err(_) => return Ok(None),
    };
    let xobject_dict = match lopdf_resolve_object(doc, xobject_obj)? {
        LopdfObject::Dictionary(dict) => dict,
        _ => return Ok(None),
    };

    let mut used_image_stream_sizes = Vec::new();
    for operation in &content.operations {
        match operation.operator.as_str() {
            operator if is_simple_scan_safe_operator(operator) => {}
            "Do" => {
                let Some(name_obj) = operation.operands.first() else {
                    return Ok(None);
                };
                let name = match name_obj {
                    LopdfObject::Name(name) => name,
                    _ => return Ok(None),
                };
                let xobj_ref = match xobject_dict.get(name.as_slice()) {
                    Ok(obj) => obj,
                    Err(_) => return Ok(None),
                };
                let xobj = lopdf_resolve_object(doc, xobj_ref)?;
                let stream = match xobj {
                    LopdfObject::Stream(stream) => stream,
                    _ => return Ok(None),
                };
                let subtype = match stream.dict.get(b"Subtype") {
                    Ok(LopdfObject::Name(name)) => name,
                    _ => return Ok(None),
                };
                if subtype.as_slice() != b"Image" {
                    debug_log(format!(
                        "scan-check page={} rejected: non-image XObject",
                        page_number
                    ));
                    return Ok(None);
                }
                if stream.dict.has(b"SMask") || stream.dict.has(b"Mask") {
                    debug_log(format!(
                        "scan-check page={} rejected: image uses mask/smask",
                        page_number
                    ));
                    return Ok(None);
                }
                used_image_stream_sizes.push(stream.content.len() as u64);
            }
            other => {
                debug_log(format!(
                    "scan-check page={} rejected: operator `{}` indicates non-simple content",
                    page_number, other
                ));
                return Ok(None);
            }
        }
    }

    if used_image_stream_sizes.len() != 1 {
        debug_log(format!(
            "scan-check page={} rejected: image_xobjects_used={}",
            page_number,
            used_image_stream_sizes.len()
        ));
        return Ok(None);
    }
    let image_bytes = used_image_stream_sizes[0];
    debug_log(format!(
        "scan-check page={} simple_scan=true image_bytes={}",
        page_number, image_bytes
    ));
    Ok(Some(SimpleScanPageInfo {
        page_number,
        width_pt,
        height_pt,
        image_bytes,
    }))
}

fn analyze_simple_scan_pdf(input_pdf: &Path) -> Result<Option<Vec<SimpleScanPageInfo>>, String> {
    debug_log(format!("simple-scan analyze pdf=`{}`", input_pdf.display()));
    let doc = LopdfDocument::load(input_pdf)
        .map_err(|e| format!("Failed to parse PDF `{}`: {}", input_pdf.display(), e))?;
    let pages = doc.get_pages();
    if pages.is_empty() {
        debug_log("simple-scan analyze rejected: no pages");
        return Ok(None);
    }

    let mut infos = Vec::with_capacity(pages.len());
    for (page_number, page_id) in pages {
        let Some(info) = analyze_simple_scan_page(&doc, page_number, page_id)? else {
            debug_log(format!(
                "simple-scan analyze rejected at page={}",
                page_number
            ));
            return Ok(None);
        };
        infos.push(info);
    }
    debug_log(format!(
        "simple-scan analyze accepted pages={}",
        infos.len()
    ));
    Ok(Some(infos))
}

fn can_short_circuit_scanned_pdf(
    pages: &[SimpleScanPageInfo],
    page_dpi: f32,
    max_area: u64,
    max_bytes: u64,
) -> Result<bool, String> {
    if pages.is_empty() {
        debug_log("short-circuit analyze rejected: no pages");
        return Ok(false);
    }

    for page in pages {
        let page_area = page_area_pixels_at_dpi(page.width_pt, page.height_pt, page_dpi);
        debug_log(format!(
            "short-circuit page={} area_at_{}dpi={} image_bytes={}",
            page.page_number, page_dpi, page_area, page.image_bytes
        ));
        if page_area > max_area {
            debug_log(format!(
                "short-circuit rejected at page={} area {} > max_area {}",
                page.page_number, page_area, max_area
            ));
            return Ok(false);
        }
        if page.image_bytes > max_bytes {
            debug_log(format!(
                "short-circuit rejected at page={} image_bytes {} > max_bytes {}",
                page.page_number, page.image_bytes, max_bytes
            ));
            return Ok(false);
        }
    }
    debug_log("short-circuit analyze accepted");
    Ok(true)
}

#[derive(Clone)]
struct ScanTranscodeJob {
    index: usize,
    input_path: String,
    output_path: Option<PathBuf>,
}

fn extract_simple_scan_pdf_images(
    input_pdf: &Path,
    raw_dir: &Path,
    output_dir: &Path,
    fmt: &str,
    prefix: &str,
    max_area: u64,
    max_bytes: u64,
    worker_cap: usize,
    expected_pages: usize,
) -> Result<Vec<String>, String> {
    let output_format = parse_output_image_format(fmt)?;
    let result_ext = generated_image_extension(fmt).to_string();
    let raw_prefix = format!("{}-raw", prefix);
    let raw_output_prefix = raw_dir.join(&raw_prefix);
    let args = vec![
        input_pdf.as_os_str().to_os_string(),
        raw_output_prefix.as_os_str().to_os_string(),
    ];
    debug_log(format!(
        "simple-scan extract command=pdfimages pdf=`{}` prefix=`{}` fmt={}",
        input_pdf.display(),
        raw_output_prefix.display(),
        fmt
    ));
    run_command("pdfimages", &args)?;

    let extracted = list_prefixed_files(
        raw_dir,
        &raw_prefix,
        &["pbm", "pgm", "ppm", "jpg", "jpeg", "png", "tif", "tiff"],
    )?;
    if extracted.len() != expected_pages {
        return Err(format!(
            "Expected {} extracted images from `{}`, found {}",
            expected_pages,
            input_pdf.display(),
            extracted.len()
        ));
    }

    let mut jobs = Vec::with_capacity(extracted.len());
    for (index, input_path) in extracted.into_iter().enumerate() {
        jobs.push(ScanTranscodeJob {
            index,
            input_path,
            output_path: Some(generated_paginated_output_path(
                output_dir,
                prefix,
                index + 1,
                &result_ext,
            )),
        });
    }

    let worker_count = thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1)
        .min(worker_cap.max(1))
        .min(jobs.len())
        .max(1);
    debug_log(format!(
        "simple-scan transcode parallel images={} workers={} cap={}",
        jobs.len(),
        worker_count,
        worker_cap
    ));

    let mut buckets = vec![Vec::<ScanTranscodeJob>::new(); worker_count];
    for (i, job) in jobs.into_iter().enumerate() {
        buckets[i % worker_count].push(job);
    }

    let transcoded = thread::scope(|scope| -> Result<Vec<(usize, String)>, String> {
        let mut handles = Vec::with_capacity(worker_count);
        for (worker_id, bucket) in buckets.into_iter().enumerate() {
            let result_ext = result_ext.clone();
            handles.push(
                scope.spawn(move || -> Result<Vec<(usize, String)>, String> {
                    debug_log(format!(
                        "simple-scan worker={} start jobs={}",
                        worker_id + 1,
                        bucket.len()
                    ));
                    let mut completed = Vec::with_capacity(bucket.len());
                    for job in bucket {
                        let input_path = PathBuf::from(&job.input_path);
                        let final_path = job
                            .output_path
                            .clone()
                            .unwrap_or_else(|| input_path.clone());
                        if job.output_path.is_some() {
                            let same_format =
                                extracted_image_matches_requested_format(&input_path, &result_ext);
                            if same_format {
                                place_extracted_image(&input_path, &final_path)?;
                            } else {
                                let image = load_dynamic_image(&input_path).map_err(|e| {
                                    format!(
                                        "Failed to decode extracted image `{}`: {}",
                                        input_path.display(),
                                        e
                                    )
                                })?;
                                save_dynamic_image(
                                    &image,
                                    &final_path,
                                    output_format,
                                    SIMPLE_SCAN_JPEG_QUALITY,
                                )?;
                            }
                        } else {
                            let image = load_dynamic_image(&input_path).map_err(|e| {
                                format!(
                                    "Failed to decode extracted image `{}`: {}",
                                    input_path.display(),
                                    e
                                )
                            })?;
                            save_dynamic_image(
                                &image,
                                &final_path,
                                output_format,
                                SIMPLE_SCAN_JPEG_QUALITY,
                            )?;
                        }
                        enforce_image_limits(&final_path, &result_ext, max_area, max_bytes)
                            .map_err(|e| {
                                format!(
                                    "Failed to constrain extracted page={} file=`{}`: {}",
                                    job.index + 1,
                                    final_path.display(),
                                    e
                                )
                            })?;
                        debug_log(format!(
                            "simple-scan worker={} page={} output=`{}`",
                            worker_id + 1,
                            job.index + 1,
                            final_path.display()
                        ));
                        completed.push((job.index, final_path.to_string_lossy().to_string()));
                    }
                    Ok(completed)
                }),
            );
        }

        let mut completed = Vec::with_capacity(expected_pages);
        for handle in handles {
            match handle.join() {
                Ok(result) => completed.extend(result?),
                Err(_) => return Err("simple-scan transcode worker panicked".to_string()),
            }
        }
        Ok(completed)
    })?;

    let mut transcoded = transcoded;
    transcoded.sort_by_key(|(index, _)| *index);
    Ok(transcoded.into_iter().map(|(_, path)| path).collect())
}

fn pdf_to_image_impl(
    pdf_path: String,
    output_dir: String,
    dpi: u32,
    fmt: &str,
    prefix: &str,
    max_area: u64,
    max_size_mb: f64,
) -> Result<Vec<String>, String> {
    debug_log(format!(
        "pdf_to_image start pdf=`{}` output_dir=`{}` dpi={} fmt={} prefix={} max_area={} max_size_mb={}",
        pdf_path, output_dir, dpi, fmt, prefix, max_area, max_size_mb
    ));
    if dpi == 0 {
        return Err("dpi must be > 0".to_string());
    }
    if !matches!(fmt, "png" | "jpg" | "jpeg" | "tif" | "tiff") {
        return Err("fmt must be one of: png, jpg, jpeg, tif, tiff".to_string());
    }
    let (max_area, max_bytes) = parse_image_limits(max_area, max_size_mb)?;

    let pdf = PathBuf::from(pdf_path);
    let out_dir = PathBuf::from(output_dir);
    ensure_file(&pdf, "pdf_path")?;
    ensure_dir(&out_dir, "output_dir")?;

    let analyze_start = Instant::now();
    let simple_scan_pages = analyze_simple_scan_pdf(&pdf)?;
    debug_log(format!(
        "pdf_to_image stage=analyze_parse elapsed_ms={}",
        analyze_start.elapsed().as_millis()
    ));
    if let Some(pages) = simple_scan_pages {
        let extract_start = Instant::now();
        let tmp = tempdir().map_err(|e| format!("Failed to create temp dir: {}", e))?;
        let files = extract_simple_scan_pdf_images(
            &pdf,
            tmp.path(),
            &out_dir,
            fmt,
            prefix,
            max_area,
            max_bytes,
            default_worker_count(),
            pages.len(),
        )?;
        debug_log(format!(
            "pdf_to_image stage=extract_simple_scan elapsed_ms={} extracted_images={}",
            extract_start.elapsed().as_millis(),
            files.len()
        ));
        debug_log("pdf_to_image done simple_scan_extract=true");
        return Ok(files);
    }
    debug_log("pdf_to_image simple_scan unavailable: not a simple scan pdf");

    let ppm_fmt = pdftoppm_output_format(fmt);
    let result_ext = generated_image_extension(fmt);
    let out_prefix = out_dir.join(prefix);
    let args = vec![
        OsString::from(format!("-{}", ppm_fmt)),
        OsString::from("-r"),
        OsString::from(dpi.to_string()),
        pdf.as_os_str().to_os_string(),
        out_prefix.as_os_str().to_os_string(),
    ];
    debug_log(format!(
        "pdf_to_image render command=pdftoppm format={} dpi={} pdf=`{}` prefix=`{}`",
        ppm_fmt,
        dpi,
        pdf.display(),
        out_prefix.display()
    ));
    run_command("pdftoppm", &args)?;

    let files = list_generated_images(&out_dir, result_ext, prefix)?;
    if files.is_empty() {
        return Err(format!(
            "No output images found in `{}` after conversion",
            out_dir.display()
        ));
    }
    debug_log(format!(
        "pdf_to_image rendered pages={} output_dir=`{}`",
        files.len(),
        out_dir.display()
    ));
    enforce_rendered_images(&files, fmt, max_area, max_bytes)?;
    debug_log("pdf_to_image done");
    Ok(files)
}

fn image_to_pdf_impl(
    image_paths: Vec<String>,
    output_pdf: String,
    max_area: u64,
    max_size_mb: f64,
    page_dpi: f32,
) -> Result<String, String> {
    debug_log(format!(
        "image_to_pdf start output_pdf=`{}` images={} page_dpi={} max_area={} max_size_mb={}",
        output_pdf,
        image_paths.len(),
        page_dpi,
        max_area,
        max_size_mb
    ));
    let (constrained_images, _tmp_guard) =
        prepare_constrained_images(&image_paths, max_area, max_size_mb)?;
    let result = image_paths_to_pdf(&constrained_images, output_pdf, page_dpi)?;
    debug_log(format!("image_to_pdf done output_pdf=`{}`", result));
    Ok(result)
}

fn image_to_pdf_bytes_from_paths(
    image_paths: &[String],
    max_area: u64,
    max_size_mb: f64,
    page_dpi: f32,
) -> Result<Vec<u8>, String> {
    let (constrained_images, _tmp_guard) =
        prepare_constrained_images(image_paths, max_area, max_size_mb)?;
    let mut out = BufWriter::new(Vec::<u8>::new());

    if constrained_images.is_empty() {
        return Err("image_paths cannot be empty".to_string());
    }

    let (first_w, first_h, first_pdf_img) =
        pdf_image_with_dimensions_from_path(&constrained_images[0])?;

    let (doc, page1, layer1) = PdfDocument::new(
        "dy_docs_tools image_to_pdf",
        px_to_mm(first_w, page_dpi),
        px_to_mm(first_h, page_dpi),
        "Layer 1",
    );

    let layer = doc.get_page(page1).get_layer(layer1);
    first_pdf_img.add_to_layer(
        layer,
        ImageTransform {
            translate_x: Some(Mm(0.0)),
            translate_y: Some(Mm(0.0)),
            rotate: None,
            scale_x: Some(1.0),
            scale_y: Some(1.0),
            dpi: Some(page_dpi),
        },
    );

    for img_path in constrained_images.iter().skip(1) {
        let (w, h, pdf_img) = pdf_image_with_dimensions_from_path(img_path)?;
        let (page, layer) = doc.add_page(px_to_mm(w, page_dpi), px_to_mm(h, page_dpi), "Layer 1");
        let layer_ref = doc.get_page(page).get_layer(layer);
        pdf_img.add_to_layer(
            layer_ref,
            ImageTransform {
                translate_x: Some(Mm(0.0)),
                translate_y: Some(Mm(0.0)),
                rotate: None,
                scale_x: Some(1.0),
                scale_y: Some(1.0),
                dpi: Some(page_dpi),
            },
        );
    }

    doc.save(&mut out)
        .map_err(|e| format!("Failed to build pdf bytes: {}", e))?;
    out.flush()
        .map_err(|e| format!("Failed to flush pdf bytes buffer: {}", e))?;
    out.into_inner()
        .map_err(|e| format!("Failed to finalize pdf bytes buffer: {}", e))
}

fn docx_to_pdf_raw_impl(docx_path: String, output_pdf: String) -> Result<String, String> {
    let docx = PathBuf::from(&docx_path);
    ensure_file(&docx, "docx_path")?;

    let output_pdf_path = PathBuf::from(&output_pdf);
    let out_dir = output_pdf_path
        .parent()
        .map(PathBuf::from)
        .ok_or_else(|| "Cannot infer output directory from output_pdf".to_string())?;
    if !out_dir.as_os_str().is_empty() {
        ensure_dir(&out_dir, "output_dir")?;
    }

    let args = vec![
        OsString::from("--headless"),
        OsString::from("--convert-to"),
        OsString::from("pdf"),
        docx.as_os_str().to_os_string(),
        OsString::from("--outdir"),
        out_dir.as_os_str().to_os_string(),
    ];
    run_command("soffice", &args)?;

    let stem = docx
        .file_stem()
        .ok_or_else(|| "Failed to parse DOCX file name".to_string())?;
    let converted_pdf = out_dir.join(format!("{}.pdf", stem.to_string_lossy()));

    if !converted_pdf.exists() {
        return Err(format!(
            "DOCX conversion completed but output file not found: {}",
            converted_pdf.display()
        ));
    }

    if converted_pdf != output_pdf_path {
        fs::copy(&converted_pdf, &output_pdf_path).map_err(|e| {
            format!(
                "Failed to place converted pdf `{}` -> `{}`: {}",
                converted_pdf.display(),
                output_pdf_path.display(),
                e
            )
        })?;
        let _ = fs::remove_file(&converted_pdf);
    }

    Ok(output_pdf)
}

fn docx_to_pdf_impl(
    docx_path: String,
    output_pdf: String,
    apply_constraints: bool,
    dpi: u32,
    fmt: &str,
    prefix: &str,
    max_area: u64,
    max_size_mb: f64,
    page_dpi: f32,
    render_workers: usize,
) -> Result<String, String> {
    if !apply_constraints {
        return docx_to_pdf_raw_impl(docx_path, output_pdf);
    }

    let tmp = tempdir().map_err(|e| format!("Failed to create temp dir: {}", e))?;
    let raw_pdf = tmp.path().join("raw.pdf");
    let raw_pdf = docx_to_pdf_raw_impl(docx_path, raw_pdf.to_string_lossy().to_string())?;
    pdf_to_pdf_impl(
        raw_pdf,
        output_pdf.clone(),
        dpi,
        fmt,
        prefix,
        max_area,
        max_size_mb,
        page_dpi,
        render_workers,
    )?;
    Ok(output_pdf)
}

fn docx_to_image_impl(
    docx_path: String,
    output_dir: String,
    dpi: u32,
    fmt: &str,
    max_area: u64,
    max_size_mb: f64,
) -> Result<Vec<String>, String> {
    let tmp = tempdir().map_err(|e| format!("Failed to create temp dir: {}", e))?;
    let pdf_path = tmp.path().join("input.pdf");
    let pdf_path = docx_to_pdf_raw_impl(docx_path, pdf_path.to_string_lossy().to_string())?;
    pdf_to_image_impl(
        pdf_path,
        output_dir,
        dpi,
        fmt,
        "page",
        max_area,
        max_size_mb,
    )
}

fn pdf_to_pdf_impl(
    input_pdf: String,
    output_pdf: String,
    dpi: u32,
    fmt: &str,
    prefix: &str,
    max_area: u64,
    max_size_mb: f64,
    page_dpi: f32,
    render_workers: usize,
) -> Result<String, String> {
    let total_start = Instant::now();
    let input_pdf_path = PathBuf::from(&input_pdf);
    let output_pdf_path = PathBuf::from(&output_pdf);
    let analyze_start = Instant::now();
    let (_checked_max_area, max_bytes) = parse_image_limits(max_area, max_size_mb)?;
    let simple_scan_pages = analyze_simple_scan_pdf(&input_pdf_path)?;
    let analyze_elapsed = analyze_start.elapsed();
    debug_log(format!(
        "pdf_to_pdf start input=`{}` output=`{}` dpi={} fmt={} page_dpi={} max_area={} max_size_mb={} render_workers={}",
        input_pdf_path.display(),
        output_pdf_path.display(),
        dpi,
        fmt,
        page_dpi,
        max_area,
        max_size_mb,
        render_workers
    ));
    debug_log(format!(
        "pdf_to_pdf stage=analyze_parse elapsed_ms={}",
        analyze_elapsed.as_millis()
    ));

    let short_circuit_start = Instant::now();
    if let Some(pages) = simple_scan_pages.as_ref() {
        if can_short_circuit_scanned_pdf(pages, page_dpi, max_area, max_bytes)? {
            if let Some(parent) = output_pdf_path.parent() {
                if !parent.as_os_str().is_empty() {
                    ensure_dir(parent, "output directory")?;
                }
            }
            fs::copy(&input_pdf_path, &output_pdf_path).map_err(|e| {
                format!(
                    "Failed to short-circuit copy `{}` -> `{}`: {}",
                    input_pdf_path.display(),
                    output_pdf_path.display(),
                    e
                )
            })?;
            debug_log(format!(
                "pdf_to_pdf short-circuit copy input=`{}` output=`{}`",
                input_pdf_path.display(),
                output_pdf_path.display()
            ));
            debug_log(format!(
                "pdf_to_pdf stage=short_circuit elapsed_ms={}",
                short_circuit_start.elapsed().as_millis()
            ));
            debug_log(format!(
                "pdf_to_pdf stage=total elapsed_ms={} short_circuit=true",
                total_start.elapsed().as_millis()
            ));
            return Ok(output_pdf);
        }
    } else {
        debug_log("pdf_to_pdf short-circuit unavailable: not a simple scan pdf");
    }
    debug_log(format!(
        "pdf_to_pdf stage=short_circuit elapsed_ms={} result=miss",
        short_circuit_start.elapsed().as_millis()
    ));

    let tmp = tempdir().map_err(|e| format!("Failed to create temp dir: {}", e))?;
    let tmp_dir = tmp.path().to_string_lossy().to_string();
    debug_log(format!("pdf_to_pdf rebuild temp_dir=`{}`", tmp_dir));

    if let Some(pages) = simple_scan_pages {
        let extract_start = Instant::now();
        let images = extract_simple_scan_pdf_images(
            &input_pdf_path,
            tmp.path(),
            tmp.path(),
            fmt,
            prefix,
            max_area,
            max_bytes,
            render_workers,
            pages.len(),
        )?;
        debug_log(format!(
            "pdf_to_pdf stage=extract_simple_scan elapsed_ms={} extracted_images={}",
            extract_start.elapsed().as_millis(),
            images.len()
        ));
        let rebuild_start = Instant::now();
        let result = image_paths_to_pdf(&images, output_pdf, page_dpi)?;
        debug_log(format!(
            "pdf_to_pdf stage=rebuild elapsed_ms={}",
            rebuild_start.elapsed().as_millis()
        ));
        debug_log(format!(
            "pdf_to_pdf stage=total elapsed_ms={} simple_scan_extract=true",
            total_start.elapsed().as_millis()
        ));
        return Ok(result);
    }

    let render_start = Instant::now();
    let images = render_pdf_pages_with_dynamic_dpi(
        &input_pdf_path,
        tmp.path(),
        dpi,
        fmt,
        prefix,
        max_area,
        max_size_mb,
        render_workers,
    )?;
    let render_elapsed = render_start.elapsed();
    debug_log(format!(
        "pdf_to_pdf stage=render elapsed_ms={} rendered_images={}",
        render_elapsed.as_millis(),
        images.len()
    ));
    debug_log(format!(
        "pdf_to_pdf rebuild rendered_images={}",
        images.len()
    ));

    let enforce_start = Instant::now();
    enforce_rendered_images(&images, fmt, max_area, max_bytes)?;
    debug_log(format!(
        "pdf_to_pdf stage=enforce elapsed_ms={} rendered_images={}",
        enforce_start.elapsed().as_millis(),
        images.len()
    ));

    let rebuild_start = Instant::now();
    let result = image_paths_to_pdf(&images, output_pdf, page_dpi)?;
    let rebuild_elapsed = rebuild_start.elapsed();
    debug_log(format!(
        "pdf_to_pdf stage=rebuild elapsed_ms={}",
        rebuild_elapsed.as_millis()
    ));
    debug_log(format!("pdf_to_pdf done output=`{}`", result));
    debug_log(format!(
        "pdf_to_pdf stage=total elapsed_ms={} short_circuit=false",
        total_start.elapsed().as_millis()
    ));
    Ok(result)
}

fn image_to_pdf_bytes_impl(
    image_paths: Vec<String>,
    max_area: u64,
    max_size_mb: f64,
    page_dpi: f32,
) -> Result<Vec<u8>, String> {
    image_to_pdf_bytes_from_paths(&image_paths, max_area, max_size_mb, page_dpi)
}

fn docx_to_pdf_bytes_impl(
    docx_path: String,
    apply_constraints: bool,
    dpi: u32,
    fmt: &str,
    prefix: &str,
    max_area: u64,
    max_size_mb: f64,
    page_dpi: f32,
    render_workers: usize,
) -> Result<Vec<u8>, String> {
    let tmp = tempdir().map_err(|e| format!("Failed to create temp dir: {}", e))?;
    let output_pdf = tmp.path().join("out.pdf");
    docx_to_pdf_impl(
        docx_path,
        output_pdf.to_string_lossy().to_string(),
        apply_constraints,
        dpi,
        fmt,
        prefix,
        max_area,
        max_size_mb,
        page_dpi,
        render_workers,
    )?;
    read_file_bytes(&output_pdf)
}

fn pdf_to_pdf_bytes_impl(
    input_pdf: String,
    dpi: u32,
    fmt: &str,
    prefix: &str,
    max_area: u64,
    max_size_mb: f64,
    page_dpi: f32,
    render_workers: usize,
) -> Result<Vec<u8>, String> {
    let tmp = tempdir().map_err(|e| format!("Failed to create temp dir: {}", e))?;
    let output_pdf = tmp.path().join("out.pdf");
    pdf_to_pdf_impl(
        input_pdf,
        output_pdf.to_string_lossy().to_string(),
        dpi,
        fmt,
        prefix,
        max_area,
        max_size_mb,
        page_dpi,
        render_workers,
    )?;
    read_file_bytes(&output_pdf)
}

#[pyfunction]
#[pyo3(signature = (pdf_path, output_dir, dpi=300, fmt="png", prefix="page", max_area=MAX_IMAGE_AREA, max_size_mb=10.0))]
fn pdf_to_image(
    pdf_path: String,
    output_dir: String,
    dpi: u32,
    fmt: &str,
    prefix: &str,
    max_area: u64,
    max_size_mb: f64,
) -> PyResult<Vec<String>> {
    pdf_to_image_impl(
        pdf_path,
        output_dir,
        dpi,
        fmt,
        prefix,
        max_area,
        max_size_mb,
    )
    .map_err(py_runtime_err)
}

#[pyfunction]
#[pyo3(signature = (image_paths, output_pdf, max_area=MAX_IMAGE_AREA, max_size_mb=10.0, page_dpi=DEFAULT_PAGE_DPI))]
fn image_to_pdf(
    image_paths: Vec<String>,
    output_pdf: String,
    max_area: u64,
    max_size_mb: f64,
    page_dpi: f32,
) -> PyResult<String> {
    image_to_pdf_impl(image_paths, output_pdf, max_area, max_size_mb, page_dpi)
        .map_err(py_runtime_err)
}

#[pyfunction]
#[pyo3(signature = (docx_path, output_pdf, apply_constraints=false, dpi=300, fmt="jpg", prefix="page", max_area=MAX_IMAGE_AREA, max_size_mb=10.0, page_dpi=DEFAULT_PAGE_DPI, render_workers=None))]
fn docx_to_pdf(
    docx_path: String,
    output_pdf: String,
    apply_constraints: bool,
    dpi: u32,
    fmt: &str,
    prefix: &str,
    max_area: u64,
    max_size_mb: f64,
    page_dpi: f32,
    render_workers: Option<usize>,
) -> PyResult<String> {
    let render_workers = render_workers.unwrap_or_else(default_worker_count);
    docx_to_pdf_impl(
        docx_path,
        output_pdf,
        apply_constraints,
        dpi,
        fmt,
        prefix,
        max_area,
        max_size_mb,
        page_dpi,
        render_workers,
    )
    .map_err(py_runtime_err)
}

#[pyfunction]
#[pyo3(signature = (docx_path, output_dir, dpi=300, fmt="png", max_area=MAX_IMAGE_AREA, max_size_mb=10.0))]
fn docx_to_image(
    docx_path: String,
    output_dir: String,
    dpi: u32,
    fmt: &str,
    max_area: u64,
    max_size_mb: f64,
) -> PyResult<Vec<String>> {
    docx_to_image_impl(docx_path, output_dir, dpi, fmt, max_area, max_size_mb)
        .map_err(py_runtime_err)
}

#[pyfunction]
#[pyo3(signature = (input_pdf, output_pdf, dpi=300, fmt="jpg", prefix="page", max_area=MAX_IMAGE_AREA, max_size_mb=10.0, page_dpi=DEFAULT_PAGE_DPI, render_workers=None))]
fn pdf_to_pdf(
    input_pdf: String,
    output_pdf: String,
    dpi: u32,
    fmt: &str,
    prefix: &str,
    max_area: u64,
    max_size_mb: f64,
    page_dpi: f32,
    render_workers: Option<usize>,
) -> PyResult<String> {
    let render_workers = render_workers.unwrap_or_else(default_worker_count);
    pdf_to_pdf_impl(
        input_pdf,
        output_pdf,
        dpi,
        fmt,
        prefix,
        max_area,
        max_size_mb,
        page_dpi,
        render_workers,
    )
    .map_err(py_runtime_err)
}

#[pyfunction]
#[pyo3(signature = (image_paths, max_area=MAX_IMAGE_AREA, max_size_mb=10.0, page_dpi=DEFAULT_PAGE_DPI))]
fn image_to_pdf_bytes(
    py: Python<'_>,
    image_paths: Vec<String>,
    max_area: u64,
    max_size_mb: f64,
    page_dpi: f32,
) -> PyResult<Py<PyBytes>> {
    let bytes = image_to_pdf_bytes_impl(image_paths, max_area, max_size_mb, page_dpi)
        .map_err(py_runtime_err)?;
    Ok(PyBytes::new_bound(py, &bytes).into())
}

#[pyfunction]
#[pyo3(signature = (image_paths, max_area=MAX_IMAGE_AREA, max_size_mb=10.0, page_dpi=DEFAULT_PAGE_DPI))]
fn image_to_pdf_data_url(
    image_paths: Vec<String>,
    max_area: u64,
    max_size_mb: f64,
    page_dpi: f32,
) -> PyResult<String> {
    let bytes = image_to_pdf_bytes_impl(image_paths, max_area, max_size_mb, page_dpi)
        .map_err(py_runtime_err)?;
    Ok(bytes_to_pdf_data_url(&bytes))
}

#[pyfunction]
#[pyo3(signature = (docx_path, apply_constraints=false, dpi=300, fmt="jpg", prefix="page", max_area=MAX_IMAGE_AREA, max_size_mb=10.0, page_dpi=DEFAULT_PAGE_DPI, render_workers=None))]
fn docx_to_pdf_bytes(
    py: Python<'_>,
    docx_path: String,
    apply_constraints: bool,
    dpi: u32,
    fmt: &str,
    prefix: &str,
    max_area: u64,
    max_size_mb: f64,
    page_dpi: f32,
    render_workers: Option<usize>,
) -> PyResult<Py<PyBytes>> {
    let render_workers = render_workers.unwrap_or_else(default_worker_count);
    let bytes = docx_to_pdf_bytes_impl(
        docx_path,
        apply_constraints,
        dpi,
        fmt,
        prefix,
        max_area,
        max_size_mb,
        page_dpi,
        render_workers,
    )
    .map_err(py_runtime_err)?;
    Ok(PyBytes::new_bound(py, &bytes).into())
}

#[pyfunction]
#[pyo3(signature = (docx_path, apply_constraints=false, dpi=300, fmt="jpg", prefix="page", max_area=MAX_IMAGE_AREA, max_size_mb=10.0, page_dpi=DEFAULT_PAGE_DPI, render_workers=None))]
fn docx_to_pdf_data_url(
    docx_path: String,
    apply_constraints: bool,
    dpi: u32,
    fmt: &str,
    prefix: &str,
    max_area: u64,
    max_size_mb: f64,
    page_dpi: f32,
    render_workers: Option<usize>,
) -> PyResult<String> {
    let render_workers = render_workers.unwrap_or_else(default_worker_count);
    let bytes = docx_to_pdf_bytes_impl(
        docx_path,
        apply_constraints,
        dpi,
        fmt,
        prefix,
        max_area,
        max_size_mb,
        page_dpi,
        render_workers,
    )
    .map_err(py_runtime_err)?;
    Ok(bytes_to_pdf_data_url(&bytes))
}

#[pyfunction]
#[pyo3(signature = (input_pdf, dpi=300, fmt="jpg", prefix="page", max_area=MAX_IMAGE_AREA, max_size_mb=10.0, page_dpi=DEFAULT_PAGE_DPI, render_workers=None))]
fn pdf_to_pdf_bytes(
    py: Python<'_>,
    input_pdf: String,
    dpi: u32,
    fmt: &str,
    prefix: &str,
    max_area: u64,
    max_size_mb: f64,
    page_dpi: f32,
    render_workers: Option<usize>,
) -> PyResult<Py<PyBytes>> {
    let render_workers = render_workers.unwrap_or_else(default_worker_count);
    let bytes = pdf_to_pdf_bytes_impl(
        input_pdf,
        dpi,
        fmt,
        prefix,
        max_area,
        max_size_mb,
        page_dpi,
        render_workers,
    )
    .map_err(py_runtime_err)?;
    Ok(PyBytes::new_bound(py, &bytes).into())
}

#[pyfunction]
#[pyo3(signature = (input_pdf, dpi=300, fmt="jpg", prefix="page", max_area=MAX_IMAGE_AREA, max_size_mb=10.0, page_dpi=DEFAULT_PAGE_DPI, render_workers=None))]
fn pdf_to_pdf_data_url(
    input_pdf: String,
    dpi: u32,
    fmt: &str,
    prefix: &str,
    max_area: u64,
    max_size_mb: f64,
    page_dpi: f32,
    render_workers: Option<usize>,
) -> PyResult<String> {
    let render_workers = render_workers.unwrap_or_else(default_worker_count);
    let bytes = pdf_to_pdf_bytes_impl(
        input_pdf,
        dpi,
        fmt,
        prefix,
        max_area,
        max_size_mb,
        page_dpi,
        render_workers,
    )
    .map_err(py_runtime_err)?;
    Ok(bytes_to_pdf_data_url(&bytes))
}

enum Task {
    ToPdf {
        input_path: String,
        output_pdf: Option<String>,
        apply_constraints: bool,
        dpi: u32,
        fmt: String,
        prefix: String,
        max_area: u64,
        max_size_mb: f64,
        page_dpi: f32,
        render_workers: usize,
        return_mode: PdfReturnMode,
    },
    ToImages {
        input_path: String,
        output_dir: String,
        dpi: u32,
        fmt: String,
        prefix: String,
        max_area: u64,
        max_size_mb: f64,
    },
    PdfToImage {
        pdf_path: String,
        output_dir: String,
        dpi: u32,
        fmt: String,
        prefix: String,
        max_area: u64,
        max_size_mb: f64,
    },
    ImageToPdf {
        image_paths: Vec<String>,
        output_pdf: Option<String>,
        max_area: u64,
        max_size_mb: f64,
        page_dpi: f32,
        return_mode: PdfReturnMode,
    },
    DocxToPdf {
        docx_path: String,
        output_pdf: Option<String>,
        apply_constraints: bool,
        dpi: u32,
        fmt: String,
        prefix: String,
        max_area: u64,
        max_size_mb: f64,
        page_dpi: f32,
        render_workers: usize,
        return_mode: PdfReturnMode,
    },
    DocxToImage {
        docx_path: String,
        output_dir: String,
        dpi: u32,
        fmt: String,
        max_area: u64,
        max_size_mb: f64,
    },
    PassthroughImage {
        image_path: String,
    },
    PdfToPdf {
        input_pdf: String,
        output_pdf: Option<String>,
        dpi: u32,
        fmt: String,
        prefix: String,
        max_area: u64,
        max_size_mb: f64,
        page_dpi: f32,
        render_workers: usize,
        return_mode: PdfReturnMode,
    },
    PassthroughFile {
        input_path: String,
        return_mode: PdfReturnMode,
    },
    Shutdown,
}

#[derive(Clone)]
enum TaskResult {
    Images(Result<Vec<String>, String>),
    PdfText(Result<String, String>),
    PdfBytes(Result<Vec<u8>, String>),
    Ack,
}

struct Job {
    task: Task,
    response_tx: Sender<TaskResult>,
}

fn run_task(task: Task) -> TaskResult {
    match task {
        Task::ToPdf {
            input_path,
            output_pdf,
            apply_constraints,
            dpi,
            fmt,
            prefix,
            max_area,
            max_size_mb,
            page_dpi,
            render_workers,
            return_mode,
        } => match build_to_pdf_task(
            input_path,
            output_pdf,
            apply_constraints,
            dpi,
            &fmt,
            &prefix,
            max_area,
            max_size_mb,
            page_dpi,
            render_workers,
            return_mode,
        ) {
            Ok(task) => run_task(task),
            Err(err) => match return_mode {
                PdfReturnMode::Path | PdfReturnMode::DataUrl => TaskResult::PdfText(Err(err)),
                PdfReturnMode::Bytes => TaskResult::PdfBytes(Err(err)),
            },
        },
        Task::ToImages {
            input_path,
            output_dir,
            dpi,
            fmt,
            prefix,
            max_area,
            max_size_mb,
        } => match build_to_images_task(
            input_path,
            output_dir,
            dpi,
            &fmt,
            &prefix,
            max_area,
            max_size_mb,
        ) {
            Ok(task) => run_task(task),
            Err(err) => TaskResult::Images(Err(err)),
        },
        Task::PdfToImage {
            pdf_path,
            output_dir,
            dpi,
            fmt,
            prefix,
            max_area,
            max_size_mb,
        } => TaskResult::Images(pdf_to_image_impl(
            pdf_path,
            output_dir,
            dpi,
            &fmt,
            &prefix,
            max_area,
            max_size_mb,
        )),
        Task::ImageToPdf {
            image_paths,
            output_pdf,
            max_area,
            max_size_mb,
            page_dpi,
            return_mode,
        } => match return_mode {
            PdfReturnMode::Path => match output_pdf {
                Some(output_pdf) => TaskResult::PdfText(image_to_pdf_impl(
                    image_paths,
                    output_pdf,
                    max_area,
                    max_size_mb,
                    page_dpi,
                )),
                None => TaskResult::PdfText(Err(
                    "output_pdf is required for return_mode=path".to_string()
                )),
            },
            PdfReturnMode::Bytes => TaskResult::PdfBytes(image_to_pdf_bytes_impl(
                image_paths,
                max_area,
                max_size_mb,
                page_dpi,
            )),
            PdfReturnMode::DataUrl => TaskResult::PdfText(
                image_to_pdf_bytes_impl(image_paths, max_area, max_size_mb, page_dpi)
                    .map(|b| bytes_to_pdf_data_url(&b)),
            ),
        },
        Task::DocxToPdf {
            docx_path,
            output_pdf,
            apply_constraints,
            dpi,
            fmt,
            prefix,
            max_area,
            max_size_mb,
            page_dpi,
            render_workers,
            return_mode,
        } => match return_mode {
            PdfReturnMode::Path => match output_pdf {
                Some(output_pdf) => TaskResult::PdfText(docx_to_pdf_impl(
                    docx_path,
                    output_pdf,
                    apply_constraints,
                    dpi,
                    &fmt,
                    &prefix,
                    max_area,
                    max_size_mb,
                    page_dpi,
                    render_workers,
                )),
                None => TaskResult::PdfText(Err(
                    "output_pdf is required for return_mode=path".to_string()
                )),
            },
            PdfReturnMode::Bytes => TaskResult::PdfBytes(docx_to_pdf_bytes_impl(
                docx_path,
                apply_constraints,
                dpi,
                &fmt,
                &prefix,
                max_area,
                max_size_mb,
                page_dpi,
                render_workers,
            )),
            PdfReturnMode::DataUrl => TaskResult::PdfText(
                docx_to_pdf_bytes_impl(
                    docx_path,
                    apply_constraints,
                    dpi,
                    &fmt,
                    &prefix,
                    max_area,
                    max_size_mb,
                    page_dpi,
                    render_workers,
                )
                .map(|b| bytes_to_pdf_data_url(&b)),
            ),
        },
        Task::DocxToImage {
            docx_path,
            output_dir,
            dpi,
            fmt,
            max_area,
            max_size_mb,
        } => TaskResult::Images(docx_to_image_impl(
            docx_path,
            output_dir,
            dpi,
            &fmt,
            max_area,
            max_size_mb,
        )),
        Task::PassthroughImage { image_path } => TaskResult::Images(Ok(vec![image_path])),
        Task::PdfToPdf {
            input_pdf,
            output_pdf,
            dpi,
            fmt,
            prefix,
            max_area,
            max_size_mb,
            page_dpi,
            render_workers,
            return_mode,
        } => match return_mode {
            PdfReturnMode::Path => match output_pdf {
                Some(output_pdf) => TaskResult::PdfText(pdf_to_pdf_impl(
                    input_pdf,
                    output_pdf,
                    dpi,
                    &fmt,
                    &prefix,
                    max_area,
                    max_size_mb,
                    page_dpi,
                    render_workers,
                )),
                None => TaskResult::PdfText(Err(
                    "output_pdf is required for return_mode=path".to_string()
                )),
            },
            PdfReturnMode::Bytes => TaskResult::PdfBytes(pdf_to_pdf_bytes_impl(
                input_pdf,
                dpi,
                &fmt,
                &prefix,
                max_area,
                max_size_mb,
                page_dpi,
                render_workers,
            )),
            PdfReturnMode::DataUrl => TaskResult::PdfText(
                pdf_to_pdf_bytes_impl(
                    input_pdf,
                    dpi,
                    &fmt,
                    &prefix,
                    max_area,
                    max_size_mb,
                    page_dpi,
                    render_workers,
                )
                .map(|b| bytes_to_pdf_data_url(&b)),
            ),
        },
        Task::PassthroughFile {
            input_path,
            return_mode,
        } => match return_mode {
            PdfReturnMode::Path => TaskResult::PdfText(passthrough_file_path(input_path)),
            PdfReturnMode::Bytes => TaskResult::PdfBytes(passthrough_file_bytes(input_path)),
            PdfReturnMode::DataUrl => TaskResult::PdfText(passthrough_file_data_url(input_path)),
        },
        Task::Shutdown => TaskResult::Ack,
    }
}

#[pyclass]
struct ConverterPool {
    worker_count: usize,
    job_tx: Sender<Job>,
    workers: Vec<JoinHandle<()>>,
    closed: bool,
}

enum HandleState {
    Pending(Receiver<TaskResult>),
    Ready(TaskResult),
}

#[pyclass]
struct TaskHandle {
    state: Mutex<HandleState>,
}

fn recv_job(rx: &Arc<Mutex<Receiver<Job>>>) -> Option<Job> {
    let lock = rx.lock().ok()?;
    lock.recv().ok()
}

#[pymethods]
impl TaskHandle {
    fn done(&self) -> PyResult<bool> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| py_runtime_err("task handle lock poisoned".to_string()))?;

        match &mut *state {
            HandleState::Ready(_) => Ok(true),
            HandleState::Pending(rx) => match rx.try_recv() {
                Ok(result) => {
                    *state = HandleState::Ready(result);
                    Ok(true)
                }
                Err(TryRecvError::Empty) => Ok(false),
                Err(TryRecvError::Disconnected) => Err(py_runtime_err(
                    "worker disconnected before sending task result".to_string(),
                )),
            },
        }
    }

    #[pyo3(signature = (timeout_ms=None))]
    fn result(&self, py: Python<'_>, timeout_ms: Option<u64>) -> PyResult<PyObject> {
        let result = self.wait_result(timeout_ms)?;
        task_result_to_py(py, result)
    }
}

#[pymethods]
impl ConverterPool {
    #[new]
    #[pyo3(signature = (workers=None))]
    fn new(workers: Option<usize>) -> PyResult<Self> {
        let worker_count = workers.unwrap_or_else(default_worker_count);
        if worker_count == 0 {
            return Err(py_value_err("workers must be > 0".to_string()));
        }

        let (job_tx, job_rx) = mpsc::channel::<Job>();
        let shared_rx = Arc::new(Mutex::new(job_rx));
        let mut worker_handles = Vec::with_capacity(worker_count);

        for _ in 0..worker_count {
            let rx = Arc::clone(&shared_rx);
            worker_handles.push(thread::spawn(move || loop {
                let Some(job) = recv_job(&rx) else {
                    break;
                };
                if matches!(job.task, Task::Shutdown) {
                    let _ = job.response_tx.send(TaskResult::Ack);
                    break;
                }
                let result = run_task(job.task);
                let _ = job.response_tx.send(result);
            }));
        }

        Ok(Self {
            worker_count,
            job_tx,
            workers: worker_handles,
            closed: false,
        })
    }

    #[getter]
    fn workers(&self) -> usize {
        self.worker_count
    }

    fn __enter__(slf: PyRef<'_, Self>) -> PyRef<'_, Self> {
        slf
    }

    #[pyo3(signature = (_exc_type=None, _exc=None, _traceback=None))]
    fn __exit__(
        &mut self,
        _exc_type: Option<&Bound<'_, PyAny>>,
        _exc: Option<&Bound<'_, PyAny>>,
        _traceback: Option<&Bound<'_, PyAny>>,
    ) {
        self.close();
    }

    #[pyo3(signature = (input_path, output_pdf=None, apply_constraints=false, dpi=300, fmt="jpg", prefix="page", max_area=MAX_IMAGE_AREA, max_size_mb=10.0, page_dpi=DEFAULT_PAGE_DPI, render_workers=None, return_mode="path"))]
    fn submit_to_pdf(
        &self,
        input_path: String,
        output_pdf: Option<String>,
        apply_constraints: bool,
        dpi: u32,
        fmt: &str,
        prefix: &str,
        max_area: u64,
        max_size_mb: f64,
        page_dpi: f32,
        render_workers: Option<usize>,
        return_mode: &str,
    ) -> PyResult<TaskHandle> {
        let render_workers = render_workers.unwrap_or_else(default_worker_count);
        let return_mode = parse_pdf_return_mode(return_mode).map_err(py_runtime_err)?;
        self.submit_task(Task::ToPdf {
            input_path,
            output_pdf,
            apply_constraints,
            dpi,
            fmt: fmt.to_string(),
            prefix: prefix.to_string(),
            max_area,
            max_size_mb,
            page_dpi,
            render_workers,
            return_mode,
        })
    }

    #[pyo3(signature = (input_path, output_dir, dpi=300, fmt="png", prefix="page", max_area=MAX_IMAGE_AREA, max_size_mb=10.0))]
    fn submit_to_images(
        &self,
        input_path: String,
        output_dir: String,
        dpi: u32,
        fmt: &str,
        prefix: &str,
        max_area: u64,
        max_size_mb: f64,
    ) -> PyResult<TaskHandle> {
        self.submit_task(Task::ToImages {
            input_path,
            output_dir,
            dpi,
            fmt: fmt.to_string(),
            prefix: prefix.to_string(),
            max_area,
            max_size_mb,
        })
    }

    fn close(&mut self) {
        if self.closed {
            return;
        }
        for _ in 0..self.worker_count {
            let (response_tx, _response_rx) = mpsc::channel::<TaskResult>();
            let _ = self.job_tx.send(Job {
                task: Task::Shutdown,
                response_tx,
            });
        }
        for handle in self.workers.drain(..) {
            let _ = handle.join();
        }
        self.closed = true;
    }
}

impl ConverterPool {
    fn submit_task(&self, task: Task) -> PyResult<TaskHandle> {
        let (response_tx, response_rx) = mpsc::channel::<TaskResult>();
        self.job_tx
            .send(Job { task, response_tx })
            .map_err(|e| py_runtime_err(e.to_string()))?;
        Ok(TaskHandle {
            state: Mutex::new(HandleState::Pending(response_rx)),
        })
    }
}

impl TaskHandle {
    fn wait_result(&self, timeout_ms: Option<u64>) -> PyResult<TaskResult> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| py_runtime_err("task handle lock poisoned".to_string()))?;

        match &mut *state {
            HandleState::Ready(result) => Ok(result.clone()),
            HandleState::Pending(rx) => {
                let received = if let Some(ms) = timeout_ms {
                    match rx.recv_timeout(Duration::from_millis(ms)) {
                        Ok(result) => result,
                        Err(RecvTimeoutError::Timeout) => {
                            return Err(py_runtime_err(format!(
                                "task result timeout after {} ms",
                                ms
                            )))
                        }
                        Err(RecvTimeoutError::Disconnected) => {
                            return Err(py_runtime_err(
                                "worker disconnected before sending task result".to_string(),
                            ))
                        }
                    }
                } else {
                    rx.recv().map_err(|_| {
                        py_runtime_err("worker disconnected before sending task result".to_string())
                    })?
                };
                *state = HandleState::Ready(received.clone());
                Ok(received)
            }
        }
    }
}

fn task_result_to_py(py: Python<'_>, result: TaskResult) -> PyResult<PyObject> {
    match result {
        TaskResult::Images(Ok(items)) => Ok(items.into_py(py)),
        TaskResult::PdfText(Ok(pdf)) => Ok(pdf.into_py(py)),
        TaskResult::PdfBytes(Ok(bytes)) => Ok(PyBytes::new_bound(py, &bytes).into()),
        TaskResult::Images(Err(err))
        | TaskResult::PdfText(Err(err))
        | TaskResult::PdfBytes(Err(err)) => Err(py_runtime_err(err)),
        TaskResult::Ack => Ok(py.None()),
    }
}

fn to_lower_ext(path: &Path) -> Option<String> {
    path.extension()
        .and_then(|v| v.to_str())
        .map(|v| v.to_ascii_lowercase())
}

#[derive(Clone, Copy)]
enum InputKind {
    Pdf,
    Docx,
    Image,
}

#[derive(Clone, Copy)]
enum PdfReturnMode {
    Path,
    Bytes,
    DataUrl,
}

fn parse_pdf_return_mode(mode: &str) -> Result<PdfReturnMode, String> {
    match mode.to_ascii_lowercase().as_str() {
        "path" => Ok(PdfReturnMode::Path),
        "bytes" => Ok(PdfReturnMode::Bytes),
        "data_url" => Ok(PdfReturnMode::DataUrl),
        _ => Err(format!(
            "Unsupported return_mode `{}`. Supported: path, bytes, data_url",
            mode
        )),
    }
}

fn detect_kind_by_extension(path: &Path) -> Option<InputKind> {
    match to_lower_ext(path).as_deref() {
        Some("pdf") => Some(InputKind::Pdf),
        Some("docx") => Some(InputKind::Docx),
        Some("jpg" | "jpeg" | "png" | "tif" | "tiff") => Some(InputKind::Image),
        _ => None,
    }
}

fn detect_kind_by_content(path: &Path) -> Result<Option<InputKind>, String> {
    let mut f = fs::File::open(path)
        .map_err(|e| format!("Failed to open input file `{}`: {}", path.display(), e))?;
    let mut buf = vec![0_u8; 8192];
    let read_n = f
        .read(&mut buf)
        .map_err(|e| format!("Failed to read input file `{}`: {}", path.display(), e))?;
    buf.truncate(read_n);

    if buf.starts_with(b"%PDF-") {
        return Ok(Some(InputKind::Pdf));
    }

    if let Ok(fmt) = image::guess_format(&buf) {
        if matches!(
            fmt,
            ImageFormat::Jpeg | ImageFormat::Png | ImageFormat::Tiff
        ) {
            return Ok(Some(InputKind::Image));
        }
    }

    // DOCX is a zip containing both of these entries.
    if buf.starts_with(b"PK") {
        let file = fs::File::open(path)
            .map_err(|e| format!("Failed to open zip candidate `{}`: {}", path.display(), e))?;
        if let Ok(mut zip) = ZipArchive::new(file) {
            let has_content_types = zip.by_name("[Content_Types].xml").is_ok();
            let has_document_xml = zip.by_name("word/document.xml").is_ok();
            if has_content_types && has_document_xml {
                return Ok(Some(InputKind::Docx));
            }
        }
    }

    Ok(None)
}

fn detect_input_kind(path: &Path) -> Result<Option<InputKind>, String> {
    if let Some(kind) = detect_kind_by_content(path)? {
        return Ok(Some(kind));
    }
    Ok(detect_kind_by_extension(path))
}

fn build_to_pdf_task(
    input_path: String,
    output_pdf: Option<String>,
    apply_constraints: bool,
    dpi: u32,
    fmt: &str,
    prefix: &str,
    max_area: u64,
    max_size_mb: f64,
    page_dpi: f32,
    render_workers: usize,
    return_mode: PdfReturnMode,
) -> Result<Task, String> {
    let path = PathBuf::from(&input_path);
    ensure_file(&path, "input_path")?;
    let kind = detect_input_kind(&path)?;

    if matches!(kind, Some(InputKind::Pdf)) {
        return Ok(Task::PdfToPdf {
            input_pdf: input_path,
            output_pdf,
            dpi,
            fmt: fmt.to_string(),
            prefix: prefix.to_string(),
            max_area,
            max_size_mb,
            page_dpi,
            render_workers,
            return_mode,
        });
    }
    if matches!(kind, Some(InputKind::Docx)) {
        return Ok(Task::DocxToPdf {
            docx_path: input_path,
            output_pdf,
            apply_constraints,
            dpi,
            fmt: fmt.to_string(),
            prefix: prefix.to_string(),
            max_area,
            max_size_mb,
            page_dpi,
            render_workers,
            return_mode,
        });
    }
    if matches!(kind, Some(InputKind::Image)) {
        return Ok(Task::ImageToPdf {
            image_paths: vec![input_path],
            output_pdf,
            max_area,
            max_size_mb,
            page_dpi,
            return_mode,
        });
    }

    Ok(Task::PassthroughFile {
        input_path,
        return_mode,
    })
}

fn build_to_images_task(
    input_path: String,
    output_dir: String,
    dpi: u32,
    fmt: &str,
    prefix: &str,
    max_area: u64,
    max_size_mb: f64,
) -> Result<Task, String> {
    let path = PathBuf::from(&input_path);
    ensure_file(&path, "input_path")?;
    let kind = detect_input_kind(&path)?;

    if matches!(kind, Some(InputKind::Pdf)) {
        return Ok(Task::PdfToImage {
            pdf_path: input_path,
            output_dir,
            dpi,
            fmt: fmt.to_string(),
            prefix: prefix.to_string(),
            max_area,
            max_size_mb,
        });
    }
    if matches!(kind, Some(InputKind::Docx)) {
        return Ok(Task::DocxToImage {
            docx_path: input_path,
            output_dir,
            dpi,
            fmt: fmt.to_string(),
            max_area,
            max_size_mb,
        });
    }
    if matches!(kind, Some(InputKind::Image)) {
        return Ok(Task::PassthroughImage {
            image_path: input_path,
        });
    }

    Err(format!(
        "Unsupported input `{}` for submit_to_images; supported types: PDF, DOCX, JPEG, PNG, TIFF",
        path.display()
    ))
}

impl Drop for ConverterPool {
    fn drop(&mut self) {
        self.close();
    }
}

#[pymodule]
fn dy_docs_tools(_py: Python<'_>, m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(pdf_to_image, m)?)?;
    m.add_function(wrap_pyfunction!(image_to_pdf, m)?)?;
    m.add_function(wrap_pyfunction!(image_to_pdf_bytes, m)?)?;
    m.add_function(wrap_pyfunction!(image_to_pdf_data_url, m)?)?;
    m.add_function(wrap_pyfunction!(docx_to_pdf, m)?)?;
    m.add_function(wrap_pyfunction!(docx_to_pdf_bytes, m)?)?;
    m.add_function(wrap_pyfunction!(docx_to_pdf_data_url, m)?)?;
    m.add_function(wrap_pyfunction!(docx_to_image, m)?)?;
    m.add_function(wrap_pyfunction!(pdf_to_pdf, m)?)?;
    m.add_function(wrap_pyfunction!(pdf_to_pdf_bytes, m)?)?;
    m.add_function(wrap_pyfunction!(pdf_to_pdf_data_url, m)?)?;
    m.add_class::<ConverterPool>()?;
    m.add_class::<TaskHandle>()?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use image::{DynamicImage, Rgb, RgbImage};
    use lopdf::dictionary;
    use pyo3::Py;
    use zip::write::FileOptions;
    use zip::ZipWriter;

    fn write_test_image(path: &Path, format: ImageFormat, width: u32, height: u32) {
        let img = DynamicImage::ImageRgb8(RgbImage::from_pixel(width, height, Rgb([12, 34, 56])));
        img.save_with_format(path, format).unwrap();
    }

    fn write_test_pdf(path: &Path) {
        fs::write(
            path,
            b"%PDF-1.4\n1 0 obj\n<<>>\nendobj\ntrailer\n<<>>\n%%EOF\n",
        )
        .unwrap();
    }

    fn write_simple_scan_pdf(path: &Path, image_format: ImageFormat, width: u32, height: u32) {
        write_simple_scan_pdf_with_contents(
            path,
            image_format,
            width,
            height,
            b"q\n595 0 0 842 0 0 cm\n/Im1 Do\nQ\n",
        );
    }

    fn write_simple_scan_pdf_with_contents(
        path: &Path,
        image_format: ImageFormat,
        width: u32,
        height: u32,
        contents: &[u8],
    ) {
        let image = DynamicImage::ImageRgb8(RgbImage::from_pixel(width, height, Rgb([12, 34, 56])));
        let mut image_bytes = Cursor::new(Vec::new());
        image.write_to(&mut image_bytes, image_format).unwrap();

        let filter = match image_format {
            ImageFormat::Jpeg => "DCTDecode",
            other => panic!("unsupported simple scan test format: {:?}", other),
        };

        let mut doc = LopdfDocument::with_version("1.5");
        let pages_id = doc.new_object_id();
        let image_id = doc.add_object(lopdf::Stream::new(
            dictionary! {
                "Type" => "XObject",
                "Subtype" => "Image",
                "Width" => i64::from(width),
                "Height" => i64::from(height),
                "ColorSpace" => "DeviceRGB",
                "BitsPerComponent" => 8,
                "Filter" => filter,
            },
            image_bytes.into_inner(),
        ));
        let contents_id = doc.add_object(lopdf::Stream::new(dictionary! {}, contents.to_vec()));
        let page_id = doc.add_object(dictionary! {
            "Type" => "Page",
            "Parent" => pages_id,
            "MediaBox" => vec![0.into(), 0.into(), 595.into(), 842.into()],
            "Resources" => dictionary! {
                "XObject" => dictionary! {
                    "Im1" => image_id,
                }
            },
            "Contents" => contents_id,
        });
        doc.objects.insert(
            pages_id,
            LopdfObject::Dictionary(dictionary! {
                "Type" => "Pages",
                "Kids" => vec![page_id.into()],
                "Count" => 1,
            }),
        );
        let catalog_id = doc.add_object(dictionary! {
            "Type" => "Catalog",
            "Pages" => pages_id,
        });
        doc.trailer.set("Root", catalog_id);
        doc.save(path).unwrap();
    }

    fn write_test_docx(path: &Path) {
        let file = fs::File::create(path).unwrap();
        let mut zip = ZipWriter::new(file);
        let options = FileOptions::default();
        zip.start_file("[Content_Types].xml", options).unwrap();
        zip.write_all(br#"<?xml version="1.0" encoding="UTF-8"?>"#)
            .unwrap();
        zip.start_file("word/document.xml", options).unwrap();
        zip.write_all(br#"<?xml version="1.0" encoding="UTF-8"?><w:document/>"#)
            .unwrap();
        zip.finish().unwrap();
    }

    fn assert_send<T: Send>() {}

    #[test]
    fn pool_and_task_handle_are_send() {
        assert_send::<ConverterPool>();
        assert_send::<TaskHandle>();
    }

    #[test]
    fn converter_pool_pyclass_can_be_used_across_threads() {
        pyo3::prepare_freethreaded_python();
        let tmp = tempdir().unwrap();
        let input = tmp.path().join("sample.png");
        let output = tmp.path().join("out.pdf");
        write_test_image(&input, ImageFormat::Png, 17, 9);
        let input_path = input.to_string_lossy().to_string();
        let output_path = output.to_string_lossy().to_string();
        let pool =
            Python::with_gil(|py| Py::new(py, ConverterPool::new(Some(2)).unwrap()).unwrap());

        let join = thread::spawn(move || {
            Python::with_gil(|py| {
                let pool_ref = pool.bind(py).borrow();
                let handle = pool_ref
                    .submit_to_pdf(
                        input_path,
                        Some(output_path.clone()),
                        false,
                        300,
                        "jpg",
                        "page",
                        MAX_IMAGE_AREA,
                        10.0,
                        DEFAULT_PAGE_DPI,
                        None,
                        "path",
                    )
                    .unwrap();

                match handle.wait_result(Some(5_000)).unwrap() {
                    TaskResult::PdfText(Ok(path)) => {
                        assert_eq!(path, output_path);
                        assert!(Path::new(&path).exists());
                    }
                    other => panic!(
                        "unexpected task result: {:?}",
                        std::mem::discriminant(&other)
                    ),
                }
            });
        });

        join.join().unwrap();
    }

    #[test]
    fn converter_pool_defaults_worker_count_from_cpu() {
        let pool = ConverterPool::new(None).unwrap();
        assert_eq!(pool.workers(), default_worker_count());
    }

    #[test]
    fn converter_pool_python_api_only_exposes_generic_submit_methods() {
        pyo3::prepare_freethreaded_python();
        Python::with_gil(|py| {
            let pool = Py::new(py, ConverterPool::new(Some(2)).unwrap()).unwrap();
            let pool_ref = pool.bind(py);

            assert!(pool_ref.getattr("submit_to_pdf").is_ok());
            assert!(pool_ref.getattr("submit_to_images").is_ok());
            assert!(pool_ref.getattr("submit_pdf_to_image").is_err());
            assert!(pool_ref.getattr("submit_image_to_pdf").is_err());
            assert!(pool_ref.getattr("submit_docx_to_pdf").is_err());
            assert!(pool_ref.getattr("submit_docx_to_image").is_err());
            assert!(pool_ref.getattr("submit_pdf_to_pdf").is_err());
        });
    }

    #[test]
    fn submit_to_pdf_defers_missing_input_validation_to_worker() {
        let pool = ConverterPool::new(Some(1)).unwrap();
        let handle = pool
            .submit_to_pdf(
                "not_exists.docx".to_string(),
                Some("out.pdf".to_string()),
                false,
                300,
                "jpg",
                "page",
                MAX_IMAGE_AREA,
                10.0,
                DEFAULT_PAGE_DPI,
                None,
                "path",
            )
            .unwrap();

        match handle.wait_result(Some(5_000)).unwrap() {
            TaskResult::PdfText(Err(err)) => assert!(err.contains("not_exists.docx")),
            other => panic!(
                "unexpected task result: {:?}",
                std::mem::discriminant(&other)
            ),
        }
    }

    #[test]
    fn submit_to_images_defers_missing_input_validation_to_worker() {
        let pool = ConverterPool::new(Some(1)).unwrap();
        let handle = pool
            .submit_to_images(
                "not_exists.docx".to_string(),
                "out".to_string(),
                300,
                "png",
                "page",
                MAX_IMAGE_AREA,
                10.0,
            )
            .unwrap();

        match handle.wait_result(Some(5_000)).unwrap() {
            TaskResult::Images(Err(err)) => assert!(err.contains("not_exists.docx")),
            other => panic!(
                "unexpected task result: {:?}",
                std::mem::discriminant(&other)
            ),
        }
    }

    #[test]
    fn quick_jpeg_dimensions_reads_dimensions_from_header() {
        let tmp = tempdir().unwrap();
        let path = tmp.path().join("sample.jpg");
        write_test_image(&path, ImageFormat::Jpeg, 17, 9);

        assert_eq!(quick_jpeg_dimensions(&path), Some((17, 9)));
    }

    #[test]
    fn prepare_constrained_images_reuses_images_already_within_limits() {
        let tmp = tempdir().unwrap();
        let path = tmp.path().join("small.png");
        write_test_image(&path, ImageFormat::Png, 12, 8);
        let input = vec![path.to_string_lossy().to_string()];

        let (prepared, _guard) = prepare_constrained_images(&input, 1_000, 1.0).unwrap();

        assert_eq!(prepared, input);
    }

    #[test]
    fn prepare_constrained_images_accepts_misnamed_jpeg_input() {
        let tmp = tempdir().unwrap();
        let path = tmp.path().join("misnamed.png");
        write_test_image(&path, ImageFormat::Jpeg, 17, 9);
        let input = vec![path.to_string_lossy().to_string()];

        let (prepared, _guard) = prepare_constrained_images(&input, 1_000, 1.0).unwrap();
        let (width, height, _) = pdf_image_with_dimensions_from_path(&prepared[0]).unwrap();

        assert_eq!((width, height), (17, 9));
    }

    #[test]
    fn detect_input_kind_prefers_pdf_content_over_extension() {
        let tmp = tempdir().unwrap();
        let path = tmp.path().join("misnamed.jpg");
        write_test_pdf(&path);

        assert!(matches!(
            detect_input_kind(&path).unwrap(),
            Some(InputKind::Pdf)
        ));
    }

    #[test]
    fn detect_input_kind_prefers_image_content_over_extension() {
        let tmp = tempdir().unwrap();
        let path = tmp.path().join("misnamed.pdf");
        write_test_image(&path, ImageFormat::Jpeg, 17, 9);

        assert!(matches!(
            detect_input_kind(&path).unwrap(),
            Some(InputKind::Image)
        ));
    }

    #[test]
    fn detect_input_kind_detects_docx_without_extension() {
        let tmp = tempdir().unwrap();
        let path = tmp.path().join("sample");
        write_test_docx(&path);

        assert!(matches!(
            detect_input_kind(&path).unwrap(),
            Some(InputKind::Docx)
        ));
    }

    #[test]
    fn build_to_images_task_routes_pdf_inputs_to_pdf_to_image() {
        let tmp = tempdir().unwrap();
        let input = tmp.path().join("sample.pdf");
        write_test_pdf(&input);
        let output_dir = tmp.path().join("out");

        let task = build_to_images_task(
            input.to_string_lossy().to_string(),
            output_dir.to_string_lossy().to_string(),
            200,
            "png",
            "page",
            MAX_IMAGE_AREA,
            10.0,
        )
        .unwrap();

        assert!(matches!(task, Task::PdfToImage { .. }));
    }

    #[test]
    fn build_to_images_task_routes_docx_inputs_to_docx_to_image() {
        let tmp = tempdir().unwrap();
        let input = tmp.path().join("sample.docx");
        write_test_docx(&input);
        let output_dir = tmp.path().join("out");

        let task = build_to_images_task(
            input.to_string_lossy().to_string(),
            output_dir.to_string_lossy().to_string(),
            200,
            "png",
            "page",
            MAX_IMAGE_AREA,
            10.0,
        )
        .unwrap();

        assert!(matches!(task, Task::DocxToImage { .. }));
    }

    #[test]
    fn build_to_images_task_passthroughs_image_inputs() {
        let tmp = tempdir().unwrap();
        let input = tmp.path().join("sample.png");
        write_test_image(&input, ImageFormat::Png, 17, 9);
        let output_dir = tmp.path().join("out");

        let task = build_to_images_task(
            input.to_string_lossy().to_string(),
            output_dir.to_string_lossy().to_string(),
            200,
            "png",
            "page",
            MAX_IMAGE_AREA,
            10.0,
        )
        .unwrap();

        match task {
            Task::PassthroughImage { image_path } => {
                assert_eq!(image_path, input.to_string_lossy());
            }
            other => panic!(
                "unexpected task result: {:?}",
                std::mem::discriminant(&other)
            ),
        }
    }

    #[test]
    fn build_to_images_task_rejects_unknown_inputs() {
        let tmp = tempdir().unwrap();
        let input = tmp.path().join("sample.txt");
        fs::write(&input, b"plain text").unwrap();
        let output_dir = tmp.path().join("out");

        let err = match build_to_images_task(
            input.to_string_lossy().to_string(),
            output_dir.to_string_lossy().to_string(),
            200,
            "png",
            "page",
            MAX_IMAGE_AREA,
            10.0,
        ) {
            Ok(_) => panic!("expected unsupported input to return an error"),
            Err(err) => err,
        };

        assert!(err.contains("Unsupported input"));
    }

    #[test]
    fn extracted_image_matches_requested_format_normalizes_aliases() {
        assert!(extracted_image_matches_requested_format(
            Path::new("scan.jpeg"),
            "jpg"
        ));
        assert!(extracted_image_matches_requested_format(
            Path::new("scan.tiff"),
            "tif"
        ));
        assert!(!extracted_image_matches_requested_format(
            Path::new("scan.png"),
            "jpg"
        ));
    }

    #[test]
    fn analyze_simple_scan_pdf_accepts_single_embedded_image_page() {
        let tmp = tempdir().unwrap();
        let path = tmp.path().join("scan.pdf");
        write_simple_scan_pdf(&path, ImageFormat::Jpeg, 32, 24);

        let pages = analyze_simple_scan_pdf(&path).unwrap().unwrap();

        assert_eq!(pages.len(), 1);
        assert!(pages[0].image_bytes > 0);
    }

    #[test]
    fn analyze_simple_scan_pdf_allows_safe_graphics_state_ops() {
        let tmp = tempdir().unwrap();
        let path = tmp.path().join("scan_rg.pdf");
        write_simple_scan_pdf_with_contents(
            &path,
            ImageFormat::Jpeg,
            32,
            24,
            b"q\n1 0 0 RG\n595 0 0 842 0 0 cm\n/Im1 Do\nQ\n",
        );

        let pages = analyze_simple_scan_pdf(&path).unwrap().unwrap();

        assert_eq!(pages.len(), 1);
        assert!(pages[0].image_bytes > 0);
    }

    #[test]
    fn resolve_singlefile_output_path_accepts_jpeg_fallback() {
        let tmp = tempdir().unwrap();
        let path = tmp.path().join("page_000001.jpeg");
        fs::write(&path, b"ok").unwrap();

        let resolved = resolve_singlefile_output_path(tmp.path(), "page_000001", "jpg").unwrap();

        assert_eq!(resolved, path.to_string_lossy());
    }

    #[test]
    fn lopdf_page_dimensions_points_reads_inherited_media_box() {
        let mut doc = LopdfDocument::with_version("1.5");
        let pages_id = doc.new_object_id();
        let page_id = doc.add_object(dictionary! {
            "Type" => "Page",
            "Parent" => pages_id,
        });
        doc.objects.insert(
            pages_id,
            LopdfObject::Dictionary(dictionary! {
                "Type" => "Pages",
                "Kids" => vec![page_id.into()],
                "Count" => 1,
                "MediaBox" => vec![0.into(), 0.into(), 595.into(), 842.into()],
            }),
        );
        let catalog_id = doc.add_object(dictionary! {
            "Type" => "Catalog",
            "Pages" => pages_id,
        });
        doc.trailer.set("Root", catalog_id);

        let (width_pt, height_pt) = lopdf_page_dimensions_points(&doc, page_id).unwrap();

        assert_eq!((width_pt, height_pt), (595.0, 842.0));
    }

    #[test]
    fn parse_pdfinfo_pages_and_single_page_size() {
        let output = "\
Title: demo\n\
Pages:           1\n\
Page size:       841.92 x 595.32 pts (A4)\n";

        assert_eq!(parse_pdfinfo_pages(output).unwrap(), 1);
        assert_eq!(
            parse_pdfinfo_page_size(output, None).unwrap(),
            (841.92, 595.32)
        );
    }

    #[test]
    fn parse_pdfinfo_page_specific_size() {
        let output = "\
Pages:           2\n\
Page    2 size:  595 x 842 pts (A4)\n";

        assert_eq!(
            parse_pdfinfo_page_size(output, Some(2)).unwrap(),
            (595.0, 842.0)
        );
    }
}
