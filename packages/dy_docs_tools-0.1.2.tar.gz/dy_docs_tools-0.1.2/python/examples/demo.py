from pathlib import Path
import sys

_THIS_DIR = Path(__file__).resolve().parent
_PYTHON_ROOT = _THIS_DIR.parent
if str(_PYTHON_ROOT) not in sys.path:
    sys.path.insert(0, str(_PYTHON_ROOT))

from dy_docs_tools import submit_to_images, submit_to_pdf


def main() -> None:
    root = _THIS_DIR
    samples = root / "samples"
    out = root / "out"
    out.mkdir(parents=True, exist_ok=True)

    pdf_file = samples / "input.pdf"
    docx_file = samples / "input.docx"
    img1 = samples / "img1.png"

    if pdf_file.exists():
        handle = submit_to_images(
            str(pdf_file),
            str(out / "pdf_pages"),
            dpi=200,
            fmt="png",
            max_area=36_000_000,
            max_size_mb=10,
        )
        print("pdf -> images:", handle.result())

    if docx_file.exists():
        handle = submit_to_pdf(
            str(docx_file),
            str(out / "docx.pdf"),
            apply_constraints=True,
            dpi=200,
            fmt="jpg",
            max_area=36_000_000,
            max_size_mb=10,
        )
        print("docx -> pdf:", handle.result())

    if img1.exists():
        handle = submit_to_pdf(
            str(img1),
            str(out / "image.pdf"),
            page_dpi=300,
        )
        print("image -> pdf:", handle.result())


if __name__ == "__main__":
    main()
