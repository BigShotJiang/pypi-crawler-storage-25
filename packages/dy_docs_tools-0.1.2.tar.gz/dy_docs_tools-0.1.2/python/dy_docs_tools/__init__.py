from __future__ import annotations

import atexit as _atexit
from threading import RLock as _RLock

from .dy_docs_tools import ConverterPool as _ConverterPool


class _ConverterService:
    def __init__(self):
        self._lock = _RLock()
        self._pool = None

    def _get_pool(self):
        with self._lock:
            if self._pool is None:
                self._pool = _ConverterPool()
            return self._pool

    def submit_to_pdf(
        self,
        input_path,
        output_pdf=None,
        apply_constraints=False,
        dpi=300,
        fmt="jpg",
        prefix="page",
        max_area=36_000_000,
        max_size_mb=10.0,
        page_dpi=300,
        render_workers=None,
        return_mode="path",
    ):
        return self._get_pool().submit_to_pdf(
            str(input_path),
            None if output_pdf is None else str(output_pdf),
            apply_constraints=apply_constraints,
            dpi=dpi,
            fmt=fmt,
            prefix=prefix,
            max_area=max_area,
            max_size_mb=max_size_mb,
            page_dpi=page_dpi,
            render_workers=render_workers,
            return_mode=return_mode,
        )

    def submit_to_images(
        self,
        input_path,
        output_dir,
        dpi=300,
        fmt="png",
        prefix="page",
        max_area=36_000_000,
        max_size_mb=10.0,
    ):
        return self._get_pool().submit_to_images(
            str(input_path),
            str(output_dir),
            dpi=dpi,
            fmt=fmt,
            prefix=prefix,
            max_area=max_area,
            max_size_mb=max_size_mb,
        )

    def close(self):
        with self._lock:
            if self._pool is None:
                return
            self._pool.close()
            self._pool = None


_converter_service = None
_converter_service_lock = _RLock()


def _get_converter_service():
    global _converter_service
    with _converter_service_lock:
        if _converter_service is None:
            _converter_service = _ConverterService()
        return _converter_service


def _close_converter_service():
    global _converter_service
    with _converter_service_lock:
        if _converter_service is None:
            return
        _converter_service.close()
        _converter_service = None


def submit_to_pdf(
    input_path,
    output_pdf=None,
    apply_constraints=False,
    dpi=300,
    fmt="jpg",
    prefix="page",
    max_area=36_000_000,
    max_size_mb=10.0,
    page_dpi=300,
    render_workers=None,
    return_mode="path",
):
    return _get_converter_service().submit_to_pdf(
        input_path,
        output_pdf=output_pdf,
        apply_constraints=apply_constraints,
        dpi=dpi,
        fmt=fmt,
        prefix=prefix,
        max_area=max_area,
        max_size_mb=max_size_mb,
        page_dpi=page_dpi,
        render_workers=render_workers,
        return_mode=return_mode,
    )


def submit_to_images(
    input_path,
    output_dir,
    dpi=300,
    fmt="png",
    prefix="page",
    max_area=36_000_000,
    max_size_mb=10.0,
):
    return _get_converter_service().submit_to_images(
        input_path,
        output_dir,
        dpi=dpi,
        fmt=fmt,
        prefix=prefix,
        max_area=max_area,
        max_size_mb=max_size_mb,
    )


_atexit.register(_close_converter_service)

globals().pop("dy_docs_tools", None)
try:
    del annotations
except NameError:
    pass


__all__ = [
    "submit_to_pdf",
    "submit_to_images",
]
