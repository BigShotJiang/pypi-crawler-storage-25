#!/usr/bin/env python
from __future__ import annotations

import argparse
import os
import statistics
import sys
import time
import zipfile
from pathlib import Path


def default_worker_count() -> int:
    return max(1, os.cpu_count() or 1)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Benchmark submit_to_pdf for each file in a directory."
    )
    parser.add_argument(
        "--input-dir",
        type=Path,
        default=Path(r"C:\Users\PC\pros\python\tests"),
        help="Directory containing input files.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(r"C:\Users\PC\pros\python\tools\target\benchmark_submit_to_pdf"),
        help="Directory to write converted PDFs.",
    )
    parser.add_argument("--dpi", type=int, default=150)
    parser.add_argument("--page-dpi", type=float, default=300)
    parser.add_argument(
        "--fmt",
        default="jpg",
        choices=["png", "jpg", "jpeg", "tif", "tiff"],
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=default_worker_count(),
        help="ConverterPool worker count. Defaults to the current CPU count.",
    )
    parser.add_argument(
        "--in-flight",
        type=int,
        default=None,
        help="Maximum number of submitted jobs kept in flight at once. Defaults to workers.",
    )
    parser.add_argument("--timeout-ms", type=int, default=300_000)
    parser.add_argument("--max-area", type=int, default=36_000_000)
    parser.add_argument("--max-size-mb", type=float, default=10.0)
    parser.add_argument(
        "--return-mode",
        default="path",
        choices=["path", "data_url"],
        help="submit_to_pdf return mode to benchmark.",
    )
    parser.add_argument(
        "--csv",
        type=Path,
        default=None,
        help="Optional CSV output path.",
    )
    return parser.parse_args()


def load_docs_tools(repo_root: Path):
    wheel_dir = repo_root / "target" / "wheels"
    wheels = sorted(wheel_dir.glob("docs_tools-*.whl"), key=lambda p: p.stat().st_mtime)
    if not wheels:
        raise FileNotFoundError(f"no wheel found under {wheel_dir}")

    wheel = wheels[-1]
    unpack = repo_root / "target" / f"benchmark_unpack_{int(time.time())}"
    unpack.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(wheel) as zf:
        zf.extractall(unpack)

    sys.path.insert(0, str(unpack.resolve()))
    import docs_tools

    return docs_tools, wheel


def csv_escape(value: str) -> str:
    return '"' + value.replace('"', '""') + '"'


def estimate_data_url_pdf_bytes(result: object) -> tuple[int, str]:
    text = str(result)
    prefix, sep, payload = text.partition(",")
    if not sep or ";base64" not in prefix:
        return -1, f"data_url(chars={len(text)})"

    padding = len(payload) - len(payload.rstrip("="))
    pdf_bytes = (len(payload) * 3) // 4 - padding
    return pdf_bytes, f"data_url(chars={len(text)},pdf_bytes={pdf_bytes})"


def summarize_result(
    result: object,
    return_mode: str,
    out_pdf: Path,
) -> tuple[int, str]:
    if return_mode == "path":
        size = out_pdf.stat().st_size if out_pdf.exists() else -1
        return size, str(result)

    if return_mode == "data_url":
        return estimate_data_url_pdf_bytes(result)

    return -1, str(result)


def finalize_job(
    job: dict[str, object],
    rows: list[dict[str, object] | None],
    timeout_ms: int,
) -> None:
    start = float(job["start"])
    out_pdf = Path(job["out_pdf"])
    return_mode = str(job["return_mode"])
    try:
        result = job["handle"].result(timeout_ms)
        elapsed = time.perf_counter() - start
        size, output_summary = summarize_result(result, return_mode, out_pdf)
        rows[int(job["index"])] = {
            "file": str(job["src"]),
            "return_mode": return_mode,
            "status": "OK",
            "seconds": elapsed,
            "bytes": size,
            "output": output_summary,
            "error": "",
        }
        print(f"[OK] {elapsed:8.3f}s {job['src']}")
    except Exception as exc:
        elapsed = time.perf_counter() - start
        rows[int(job["index"])] = {
            "file": str(job["src"]),
            "return_mode": return_mode,
            "status": "FAIL",
            "seconds": elapsed,
            "bytes": -1,
            "output": "",
            "error": str(exc),
        }
        print(f"[FAIL] {elapsed:8.3f}s {job['src']}")
        print(str(exc))


def collect_completed_jobs(
    pending: list[dict[str, object]],
    rows: list[dict[str, object] | None],
    timeout_ms: int,
) -> bool:
    completed_indices: list[int] = []
    for idx, job in enumerate(pending):
        if job["handle"].done():
            completed_indices.append(idx)

    if not completed_indices:
        return False

    for idx in reversed(completed_indices):
        finalize_job(pending.pop(idx), rows, timeout_ms)
    return True


def main() -> int:
    args = parse_args()
    repo_root = Path(__file__).resolve().parents[1]

    if not args.input_dir.exists():
        print(f"FAIL: input dir not found: {args.input_dir}")
        return 2

    args.output_dir.mkdir(parents=True, exist_ok=True)
    docs_tools, wheel = load_docs_tools(repo_root)

    files = sorted(p for p in args.input_dir.rglob("*") if p.is_file())
    print(f"INFO: wheel={wheel}")
    print(f"INFO: files={len(files)}")
    print(
        f"INFO: dpi={args.dpi} page_dpi={args.page_dpi} fmt={args.fmt} "
        f"workers={args.workers} in_flight={args.in_flight or args.workers} "
        f"max_area={args.max_area} max_size_mb={args.max_size_mb} "
        f"return_mode={args.return_mode}"
    )

    rows: list[dict[str, object] | None] = [None] * len(files)
    in_flight = max(1, args.in_flight or args.workers)
    benchmark_start = time.perf_counter()
    pool = docs_tools.ConverterPool(workers=args.workers)
    try:
        pending: list[dict[str, object]] = []
        next_index = 0
        while next_index < len(files) or pending:
            while next_index < len(files) and len(pending) < in_flight:
                src = files[next_index]
                out_pdf = args.output_dir / f"{src.stem}.bench.pdf"
                output_pdf = str(out_pdf) if args.return_mode == "path" else None
                handle = pool.submit_to_pdf(
                    str(src),
                    output_pdf,
                    apply_constraints=False,
                    dpi=args.dpi,
                    fmt=args.fmt,
                    prefix="page",
                    max_area=args.max_area,
                    max_size_mb=args.max_size_mb,
                    page_dpi=args.page_dpi,
                    return_mode=args.return_mode,
                )
                pending.append(
                    {
                        "index": next_index,
                        "src": src,
                        "out_pdf": out_pdf,
                        "return_mode": args.return_mode,
                        "handle": handle,
                        "start": time.perf_counter(),
                    }
                )
                next_index += 1

            if not collect_completed_jobs(pending, rows, args.timeout_ms):
                time.sleep(0.01)

        while pending:
            finalize_job(pending.pop(0), rows, args.timeout_ms)
    finally:
        pool.close()

    rows = [row for row in rows if row is not None]
    ok_rows = [r for r in rows if r["status"] == "OK"]
    fail_rows = [r for r in rows if r["status"] == "FAIL"]
    ok_times = [float(r["seconds"]) for r in ok_rows]
    wall_elapsed = time.perf_counter() - benchmark_start

    print()
    print(f"SUMMARY: total={len(rows)} ok={len(ok_rows)} fail={len(fail_rows)}")
    print(
        f"WALL: total={wall_elapsed:.3f}s throughput={len(rows) / wall_elapsed:.3f} files/s"
    )
    if ok_times:
        print(
            "TIMING: "
            f"min={min(ok_times):.3f}s "
            f"avg={statistics.mean(ok_times):.3f}s "
            f"median={statistics.median(ok_times):.3f}s "
            f"max={max(ok_times):.3f}s"
        )

    if args.csv is not None:
        args.csv.parent.mkdir(parents=True, exist_ok=True)
        with args.csv.open("w", encoding="utf-8", newline="") as f:
            f.write("file,return_mode,status,seconds,bytes,output,error\n")
            for row in rows:
                f.write(
                    ",".join(
                        [
                            csv_escape(str(row["file"])),
                            csv_escape(str(row["return_mode"])),
                            csv_escape(str(row["status"])),
                            csv_escape(f"{float(row['seconds']):.6f}"),
                            csv_escape(str(row["bytes"])),
                            csv_escape(str(row["output"])),
                            csv_escape(str(row["error"])),
                        ]
                    )
                    + "\n"
                )
        print(f"CSV: {args.csv}")

    return 0 if not fail_rows else 1


if __name__ == "__main__":
    raise SystemExit(main())
