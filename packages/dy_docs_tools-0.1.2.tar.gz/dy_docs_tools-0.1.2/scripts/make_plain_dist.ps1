param(
    [string]$WheelPath = ""
)

$ErrorActionPreference = "Stop"

$repoRoot = Split-Path -Parent $PSScriptRoot
Set-Location $repoRoot

if ([string]::IsNullOrWhiteSpace($WheelPath)) {
    $wheel = Get-ChildItem "target/wheels/docs_tools-*.whl" |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1
    if (-not $wheel) {
        throw "No wheel found. Run: python -m maturin build --release"
    }
}
else {
    if (-not (Test-Path $WheelPath)) {
        throw "Wheel not found: $WheelPath"
    }
    $wheel = Get-Item $WheelPath
}

$plainDir = Join-Path $repoRoot "dist_plain/docs_tools"
$unpackDir = Join-Path $repoRoot "target/plain_unpack"

Remove-Item -Recurse -Force $plainDir, $unpackDir -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force $plainDir, $unpackDir | Out-Null

$zipPath = Join-Path $wheel.DirectoryName ($wheel.BaseName + ".zip")
Copy-Item $wheel.FullName $zipPath -Force
Expand-Archive -Path $zipPath -DestinationPath $unpackDir -Force
Remove-Item $zipPath -Force

Copy-Item (Join-Path $unpackDir "docs_tools/__init__.py") (Join-Path $plainDir "__init__.py") -Force
Copy-Item (Join-Path $unpackDir "docs_tools/docs_tools.pyd") (Join-Path $plainDir "docs_tools.pyd") -Force

@'
import sys
from pathlib import Path
sys.path.insert(0, str(Path("dist_plain").resolve()))
import docs_tools
print("OK: import docs_tools succeeded")
print("Exports:", ", ".join(sorted(docs_tools.__all__)))
'@ | python -

Write-Host "Done."
Write-Host "Wheel: $($wheel.FullName)"
Write-Host "Output: $plainDir"
