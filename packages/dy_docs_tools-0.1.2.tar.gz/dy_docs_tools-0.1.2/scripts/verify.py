#!/usr/bin/env python
from __future__ import annotations

import argparse
import importlib
import statistics
import shutil
import sys
import threading
import time
import traceback
import zipfile
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Smoke verify docs_tools build and async APIs."
    )
    parser.add_argument(
        "--wheel",
        type=Path,
        default=None,
        help="Optional wheel path. If omitted, auto-detect from target/wheels.",
    )
    parser.add_argument(
        "--pool-iterations",
        type=int,
        default=1000,
        help="Number of pool create/assign iterations for the benchmark.",
    )
    parser.add_argument(
        "--real-input",
        type=Path,
        default=Path(r"C:\Users\PC\pros\python\tests\20260323-220347.jpg"),
        help="Real input file used for end-to-end benchmark.",
    )
    return parser.parse_args()


def prepare_import_path(wheel_path: Path) -> Path:
    started = time.perf_counter()
    unpack_dir = Path("target") / "verify_unpack"
    if unpack_dir.exists():
        shutil.rmtree(unpack_dir)
    unpack_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(wheel_path) as zf:
        zf.extractall(unpack_dir)
    sys.path.insert(0, str(unpack_dir.resolve()))
    elapsed_ms = (time.perf_counter() - started) * 1000
    print(f"TIMING: unpack wheel = {elapsed_ms:.3f} ms")
    return unpack_dir


def resolve_wheel(cli_wheel: Path | None) -> Path | None:
    if cli_wheel is not None:
        if not cli_wheel.exists():
            raise FileNotFoundError(f"wheel not found: {cli_wheel}")
        return cli_wheel

    wheels = list((Path("target") / "wheels").glob("docs_tools-*.whl"))
    if not wheels:
        return None
    return max(wheels, key=lambda p: p.stat().st_mtime)


def import_package() -> tuple[object, str]:
    started = time.perf_counter()
    module = importlib.import_module("docs_tools")
    elapsed_ms = (time.perf_counter() - started) * 1000
    print(f"TIMING: import docs_tools = {elapsed_ms:.3f} ms")
    return module, "installed"


def run_smoke_test(module: object) -> None:
    required = {
        "pdf_to_image",
        "pdf_to_pdf",
        "image_to_pdf",
        "docx_to_pdf",
        "docx_to_image",
        "ConverterPool",
        "TaskHandle",
    }
    exports = set(getattr(module, "__all__", []))
    missing = required - exports
    if missing:
        raise RuntimeError(f"missing exports: {sorted(missing)}")

    assign_started = time.perf_counter()
    pool = module.ConverterPool(workers=2)
    assign_elapsed_ms = (time.perf_counter() - assign_started) * 1000
    print(f"TIMING: pool = ConverterPool(workers=2) = {assign_elapsed_ms:.3f} ms")
    try:
        submit_started = time.perf_counter()
        handle = pool.submit_to_pdf("not_exists.docx", "out.pdf")
        submit_elapsed_ms = (time.perf_counter() - submit_started) * 1000
        print(f"TIMING: submit_to_pdf(main thread) = {submit_elapsed_ms:.3f} ms")

        done_started = time.perf_counter()
        # done() should be callable and return bool; state can race so we don't assert value.
        done_flag = handle.done()
        done_elapsed_ms = (time.perf_counter() - done_started) * 1000
        print(f"TIMING: handle.done()(main thread) = {done_elapsed_ms:.3f} ms")
        if not isinstance(done_flag, bool):
            raise RuntimeError("TaskHandle.done() did not return bool")

        result_started = time.perf_counter()
        try:
            handle.result(5000)
            raise RuntimeError("expected RuntimeError for missing input docx, but got success")
        except RuntimeError as exc:
            result_elapsed_ms = (time.perf_counter() - result_started) * 1000
            print(f"TIMING: handle.result(5000)(main thread) = {result_elapsed_ms:.3f} ms")
            msg = str(exc)
            if "does not exist" not in msg and "not_exists.docx" not in msg:
                raise RuntimeError(f"unexpected RuntimeError message: {msg}") from exc

        final_done_started = time.perf_counter()
        final_done_flag = handle.done()
        final_done_elapsed_ms = (time.perf_counter() - final_done_started) * 1000
        print(f"TIMING: handle.done()(main thread, final) = {final_done_elapsed_ms:.3f} ms")
        if not final_done_flag:
            raise RuntimeError("task should be done after result() returned")
    finally:
        pool.close()


def run_cross_thread_smoke_test(module: object) -> None:
    assign_started = time.perf_counter()
    pool = module.ConverterPool(workers=2)
    assign_elapsed_ms = (time.perf_counter() - assign_started) * 1000
    print(
        f"TIMING: cross-thread pool = ConverterPool(workers=2) = {assign_elapsed_ms:.3f} ms"
    )
    errors: list[str] = []

    def worker() -> None:
        try:
            submit_started = time.perf_counter()
            handle = pool.submit_to_pdf("not_exists_thread.docx", "out.pdf")
            submit_elapsed_ms = (time.perf_counter() - submit_started) * 1000
            print(f"TIMING: submit_to_pdf(worker thread) = {submit_elapsed_ms:.3f} ms")

            done_started = time.perf_counter()
            done_flag = handle.done()
            done_elapsed_ms = (time.perf_counter() - done_started) * 1000
            print(f"TIMING: handle.done()(worker thread) = {done_elapsed_ms:.3f} ms")
            if not isinstance(done_flag, bool):
                raise RuntimeError("TaskHandle.done() did not return bool in worker thread")

            result_started = time.perf_counter()
            try:
                handle.result(5000)
                raise RuntimeError(
                    "expected RuntimeError for missing input docx in worker thread, but got success"
                )
            except RuntimeError as exc:
                result_elapsed_ms = (time.perf_counter() - result_started) * 1000
                print(
                    f"TIMING: handle.result(5000)(worker thread) = {result_elapsed_ms:.3f} ms"
                )
                msg = str(exc)
                if "does not exist" not in msg and "not_exists_thread.docx" not in msg:
                    raise RuntimeError(
                        f"unexpected RuntimeError message in worker thread: {msg}"
                    ) from exc

            final_done_started = time.perf_counter()
            final_done_flag = handle.done()
            final_done_elapsed_ms = (time.perf_counter() - final_done_started) * 1000
            print(
                f"TIMING: handle.done()(worker thread, final) = {final_done_elapsed_ms:.3f} ms"
            )
            if not final_done_flag:
                raise RuntimeError("task should be done after result() returned in worker thread")
        except Exception as exc:
            errors.append(str(exc))

    thread = threading.Thread(target=worker, name="verify-cross-thread")
    thread.start()
    thread.join()

    try:
        if errors:
            raise RuntimeError(errors[0])
    finally:
        pool.close()


def summarize_timings(label: str, values_ms: list[float]) -> None:
    if not values_ms:
        print(f"TIMING: {label} = no samples")
        return

    ordered = sorted(values_ms)
    count = len(ordered)
    p50 = statistics.median(ordered)
    p95_index = min(count - 1, max(0, int((count - 1) * 0.95)))
    p95 = ordered[p95_index]
    avg = sum(ordered) / count
    print(
        "TIMING: "
        f"{label} count={count} min={ordered[0]:.3f} ms avg={avg:.3f} ms "
        f"p50={p50:.3f} ms p95={p95:.3f} ms max={ordered[-1]:.3f} ms"
    )


def run_pool_creation_benchmark(module: object, iterations: int) -> None:
    values_ms: list[float] = []
    for _ in range(iterations):
        started = time.perf_counter()
        pool = module.ConverterPool(workers=2)
        elapsed_ms = (time.perf_counter() - started) * 1000
        values_ms.append(elapsed_ms)
        pool.close()
    summarize_timings("pool create/assign benchmark", values_ms)


def run_real_file_benchmark(module: object, real_input: Path) -> None:
    if not real_input.exists():
        raise FileNotFoundError(f"real input not found: {real_input}")

    output_dir = Path("target") / "verify_real_outputs"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_pdf = output_dir / f"{real_input.stem}.verify.pdf"

    pool_started = time.perf_counter()
    pool = module.ConverterPool(workers=2)
    pool_elapsed_ms = (time.perf_counter() - pool_started) * 1000
    print(f"TIMING: real-file pool = ConverterPool(workers=2) = {pool_elapsed_ms:.3f} ms")

    try:
        submit_started = time.perf_counter()
        handle = pool.submit_to_pdf(
            str(real_input),
            str(output_pdf),
            apply_constraints=False,
            dpi=150,
            fmt="jpg",
            prefix="page",
            max_area=36_000_000,
            max_size_mb=10.0,
            page_dpi=300,
            render_workers=4,
            return_mode="path",
        )
        submit_elapsed_ms = (time.perf_counter() - submit_started) * 1000
        print(f"TIMING: submit_to_pdf(real file) = {submit_elapsed_ms:.3f} ms")

        result_started = time.perf_counter()
        result = handle.result(30000)
        result_elapsed_ms = (time.perf_counter() - result_started) * 1000
        print(f"TIMING: handle.result(30000)(real file) = {result_elapsed_ms:.3f} ms")

        total_path = Path(result)
        if not total_path.exists():
            raise RuntimeError(f"real-file output was not created: {total_path}")
        print(f"INFO: real-file output={total_path}")
    finally:
        pool.close()


def main() -> int:
    args = parse_args()
    source = "installed"

    try:
        if args.wheel is not None:
            wheel_path = resolve_wheel(args.wheel)
            if wheel_path is None:
                print("FAIL: wheel path was provided but could not be resolved")
                return 2
            unpack_dir = prepare_import_path(wheel_path)
            module, source = import_package()
            source = "wheel"
            print(f"INFO: imported from unpacked wheel: {wheel_path}")
            print(f"INFO: unpack dir: {unpack_dir}")
        else:
            try:
                module, source = import_package()
            except ModuleNotFoundError:
                wheel_path = resolve_wheel(args.wheel)
                if wheel_path is None:
                    print("FAIL: package not installed and no wheel found under target/wheels")
                    return 2
                unpack_dir = prepare_import_path(wheel_path)
                module, source = import_package()
                source = "wheel"
                print(f"INFO: imported from unpacked wheel: {wheel_path}")
                print(f"INFO: unpack dir: {unpack_dir}")

        run_smoke_test(module)
        run_cross_thread_smoke_test(module)
        run_pool_creation_benchmark(module, args.pool_iterations)
        run_real_file_benchmark(module, args.real_input)
        print(f"PASS: smoke test ok (source={source})")
        return 0
    except Exception as exc:
        print(f"FAIL: {exc}")
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
