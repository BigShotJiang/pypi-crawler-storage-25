#!/usr/bin/env python
from __future__ import annotations

import csv
import json
import re
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = ROOT / "docs" / "charts"

SEQ_LOG = ROOT / "target" / "chart_inputs" / "benchmark_seq_page300_bc.log"
CONC_LOG = ROOT / "target" / "chart_inputs" / "benchmark_conc_page300_bc.log"
STRESS_BEFORE = ROOT / "target" / "stress_loop_monitor_page300" / "summary.json"
STRESS_AFTER = ROOT / "target" / "stress_loop_monitor_page300_bc" / "summary.json"
IMAGE_COMPARE = ROOT / "target" / "image_compare_505344" / "summary.json"
SEQ_BEFORE_CSV = ROOT / "target" / "benchmark_seq_page300" / "results.csv"
SEQ_AFTER_CSV = ROOT / "target" / "benchmark_seq_page300_bc" / "results.csv"
CONC_BEFORE_CSV = ROOT / "target" / "benchmark_conc_page300" / "results.csv"
CONC_AFTER_CSV = ROOT / "target" / "benchmark_conc_page300_bc" / "results.csv"

# Measured from pdfinfo/pdfimages for 505344.pdf and the rebuilt output.
SOURCE_PDF_505344 = Path(r"C:\Users\PC\pros\python\tests\505344.pdf")
SOURCE_PDF_PAGES = 6
SOURCE_PAGE_WIDTH_PT = 2355.91
SOURCE_PAGE_HEIGHT_PT = 1604.24
OUTPUT_PAGE_WIDTH_PT = 564.96
SOURCE_IMAGE_WIDTH_PX = 2354
OUTPUT_IMAGE_WIDTH_PX = 2354


@dataclass
class BenchmarkSummary:
    wall_seconds: float
    throughput: float


@dataclass
class TargetPdfSummary:
    before_seq_seconds: float
    after_seq_seconds: float
    before_conc_seconds: float
    after_conc_seconds: float
    output_bytes: int
    source_bytes: int


def read_text(path: Path) -> str:
    data = path.read_bytes()
    if data.startswith(b"\xff\xfe") or data.startswith(b"\xfe\xff"):
        return data.decode("utf-16", errors="replace")
    if data.startswith(b"\xef\xbb\xbf"):
        return data.decode("utf-8-sig", errors="replace")
    return data.decode("utf-8", errors="replace")


def parse_benchmark_log(path: Path) -> BenchmarkSummary:
    text = read_text(path)
    match = re.search(
        r"WALL:\s+total=(?P<seconds>\d+(?:\.\d+)?)s\s+throughput=(?P<throughput>\d+(?:\.\d+)?)\s+files/s",
        text,
    )
    if not match:
        raise ValueError(f"failed to parse WALL line in {path}")
    return BenchmarkSummary(
        wall_seconds=float(match.group("seconds")),
        throughput=float(match.group("throughput")),
    )


def find_csv_row(path: Path, target_name: str) -> dict[str, str]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            if row["file"].endswith(target_name):
                return row
    raise ValueError(f"failed to find {target_name} in {path}")


def load_target_pdf_summary() -> TargetPdfSummary:
    seq_before = find_csv_row(SEQ_BEFORE_CSV, "505344.pdf")
    seq_after = find_csv_row(SEQ_AFTER_CSV, "505344.pdf")
    conc_before = find_csv_row(CONC_BEFORE_CSV, "505344.pdf")
    conc_after = find_csv_row(CONC_AFTER_CSV, "505344.pdf")
    return TargetPdfSummary(
        before_seq_seconds=float(seq_before["seconds"]),
        after_seq_seconds=float(seq_after["seconds"]),
        before_conc_seconds=float(conc_before["seconds"]),
        after_conc_seconds=float(conc_after["seconds"]),
        output_bytes=int(seq_after["bytes"]),
        source_bytes=SOURCE_PDF_505344.stat().st_size,
    )


def load_json(path: Path) -> dict:
    return json.loads(read_text(path))


def fmt_num(value: float, digits: int = 2) -> str:
    return f"{value:.{digits}f}"


def fmt_mb_decimal(value_bytes: int) -> str:
    return f"{value_bytes / 1_000_000:.2f} MB"


def svg_header(width: int, height: int) -> list[str]:
    return [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<style>',
        ".title { font: 700 28px 'Segoe UI', Arial, sans-serif; fill: #13293d; }",
        ".subtitle { font: 400 14px 'Segoe UI', Arial, sans-serif; fill: #3e5c76; }",
        ".label { font: 600 14px 'Segoe UI', Arial, sans-serif; fill: #13293d; }",
        ".small { font: 400 12px 'Segoe UI', Arial, sans-serif; fill: #3e5c76; }",
        ".value { font: 700 16px 'Segoe UI', Arial, sans-serif; fill: #13293d; }",
        ".note { font: 400 13px 'Segoe UI', Arial, sans-serif; fill: #486581; }",
        ".axis { font: 400 12px 'Segoe UI', Arial, sans-serif; fill: #486581; }",
        "</style>",
    ]


def svg_footer() -> list[str]:
    return ["</svg>"]


def save_svg(path: Path, lines: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def chart_bg(lines: list[str], width: int, height: int) -> None:
    lines.append(f'<rect x="0" y="0" width="{width}" height="{height}" fill="#f7fafc" />')
    lines.append(
        f'<rect x="18" y="18" width="{width - 36}" height="{height - 36}" rx="22" fill="#ffffff" stroke="#d9e2ec" />'
    )


def add_title(lines: list[str], title: str, subtitle: str) -> None:
    lines.append(f'<text class="title" x="40" y="58">{title}</text>')
    lines.append(f'<text class="subtitle" x="40" y="84">{subtitle}</text>')


def draw_kpi_card(
    lines: list[str],
    x: int,
    y: int,
    w: int,
    h: int,
    title: str,
    value: str,
    note: str,
    accent: str,
) -> None:
    lines.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="18" fill="#ffffff" stroke="#d9e2ec" />')
    lines.append(f'<rect x="{x}" y="{y}" width="{w}" height="8" rx="18" fill="{accent}" />')
    lines.append(f'<text class="small" x="{x + 18}" y="{y + 34}">{title}</text>')
    lines.append(
        f'<text x="{x + 18}" y="{y + 76}" style="font: 700 30px \'Segoe UI\', Arial, sans-serif; fill: #13293d;">{value}</text>'
    )
    lines.append(f'<text class="note" x="{x + 18}" y="{y + h - 18}">{note}</text>')


def draw_bar_panel(
    lines: list[str],
    title: str,
    x: int,
    y: int,
    w: int,
    h: int,
    labels: list[str],
    values: list[float],
    colors: list[str],
    unit: str,
    lower_is_better: bool,
) -> None:
    lines.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="18" fill="#f8fbff" stroke="#d9e2ec" />')
    lines.append(f'<text class="label" x="{x + 18}" y="{y + 28}">{title}</text>')
    max_value = max(values) if values else 1.0
    plot_x = x + 18
    plot_y = y + 44
    plot_w = w - 36
    plot_h = h - 78
    bar_w = 74
    gap = 34
    total_w = len(values) * bar_w + (len(values) - 1) * gap
    start_x = plot_x + max(0, (plot_w - total_w) // 2)
    baseline = plot_y + plot_h
    lines.append(f'<line x1="{plot_x}" y1="{baseline}" x2="{plot_x + plot_w}" y2="{baseline}" stroke="#bcccdc" />')
    for idx, (label, value, color) in enumerate(zip(labels, values, colors)):
        bar_h = 0 if max_value == 0 else int((value / max_value) * (plot_h - 12))
        bx = start_x + idx * (bar_w + gap)
        by = baseline - bar_h
        lines.append(f'<rect x="{bx}" y="{by}" width="{bar_w}" height="{bar_h}" rx="10" fill="{color}" />')
        lines.append(f'<text class="value" x="{bx + bar_w / 2:.1f}" y="{by - 10}" text-anchor="middle">{fmt_num(value)}</text>')
        lines.append(f'<text class="small" x="{bx + bar_w / 2:.1f}" y="{baseline + 18}" text-anchor="middle">{label}</text>')
    direction = "lower is better" if lower_is_better else "higher is better"
    lines.append(f'<text class="small" x="{x + 18}" y="{y + h - 16}">unit: {unit} | {direction}</text>')


def polyline_points(values: list[float], x: int, y: int, w: int, h: int) -> list[tuple[float, float]]:
    if not values:
        return []
    max_value = max(values)
    min_value = min(values)
    span = max(max_value - min_value, 1e-9)
    if len(values) == 1:
        return [(x + w / 2, y + h / 2)]
    result: list[tuple[float, float]] = []
    for idx, value in enumerate(values):
        px = x + (w * idx / (len(values) - 1))
        normalized = (value - min_value) / span
        py = y + h - normalized * h
        result.append((px, py))
    return result


def draw_line_panel(
    lines: list[str],
    title: str,
    x: int,
    y: int,
    w: int,
    h: int,
    series: list[tuple[str, list[float], str]],
) -> None:
    lines.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="18" fill="#f8fbff" stroke="#d9e2ec" />')
    lines.append(f'<text class="label" x="{x + 18}" y="{y + 28}">{title}</text>')
    plot_x = x + 20
    plot_y = y + 46
    plot_w = w - 40
    plot_h = h - 72
    all_values = [value for _, values, _ in series for value in values]
    max_value = max(all_values)
    min_value = min(all_values)
    span = max(max_value - min_value, 1e-9)
    for tick in range(4):
        ty = plot_y + plot_h * tick / 3
        tick_value = max_value - span * tick / 3
        lines.append(f'<line x1="{plot_x}" y1="{ty:.1f}" x2="{plot_x + plot_w}" y2="{ty:.1f}" stroke="#e9eff5" />')
        lines.append(f'<text class="axis" x="{plot_x + plot_w + 6}" y="{ty + 4:.1f}">{fmt_num(tick_value)}</text>')
    for idx in range(10):
        tx = plot_x + plot_w * idx / 9
        lines.append(f'<text class="axis" x="{tx:.1f}" y="{plot_y + plot_h + 18}" text-anchor="middle">R{idx + 1}</text>')
    legend_x = x + 18
    for name, values, color in series:
        points = []
        for idx, value in enumerate(values):
            px = plot_x + plot_w * idx / max(len(values) - 1, 1)
            normalized = (value - min_value) / span
            py = plot_y + plot_h - normalized * plot_h
            points.append((px, py))
        point_attr = " ".join(f"{px:.1f},{py:.1f}" for px, py in points)
        lines.append(f'<polyline fill="none" stroke="{color}" stroke-width="3" points="{point_attr}" />')
        for px, py in points:
            lines.append(f'<circle cx="{px:.1f}" cy="{py:.1f}" r="3.5" fill="{color}" />')
        lines.append(f'<rect x="{legend_x}" y="{y + h - 22}" width="18" height="6" rx="3" fill="{color}" />')
        lines.append(f'<text class="small" x="{legend_x + 24}" y="{y + h - 16}">{name}</text>')
        legend_x += 132


def draw_bar_panel_cn(
    lines: list[str],
    title: str,
    x: int,
    y: int,
    w: int,
    h: int,
    labels: list[str],
    values: list[float],
    colors: list[str],
    footer: str,
) -> None:
    lines.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="22" fill="#ffffff" stroke="#d9e2ec" />')
    lines.append(f'<text x="{x + 20}" y="{y + 34}" style="font: 700 18px \'Microsoft YaHei\', \'Segoe UI\', Arial, sans-serif; fill: #102a43;">{title}</text>')
    plot_x = x + 26
    plot_y = y + 62
    plot_w = w - 52
    plot_h = h - 112
    baseline = plot_y + plot_h
    max_value = max(values) if values else 1.0
    lines.append(f'<line x1="{plot_x}" y1="{baseline}" x2="{plot_x + plot_w}" y2="{baseline}" stroke="#bcccdc" />')
    bar_w = max(48, int((plot_w - 24 * (len(values) - 1)) / max(len(values), 1)))
    gap = 24
    total_w = len(values) * bar_w + (len(values) - 1) * gap
    start_x = plot_x + max(0, (plot_w - total_w) // 2)
    for idx, (label, value, color) in enumerate(zip(labels, values, colors)):
        bar_h = 0 if max_value == 0 else int((value / max_value) * (plot_h - 18))
        bx = start_x + idx * (bar_w + gap)
        by = baseline - bar_h
        lines.append(f'<rect x="{bx}" y="{by}" width="{bar_w}" height="{bar_h}" rx="12" fill="{color}" />')
        lines.append(
            f'<text x="{bx + bar_w / 2:.1f}" y="{by - 10}" text-anchor="middle" style="font: 700 16px \'Segoe UI\', Arial, sans-serif; fill: #102a43;">{fmt_num(value)}</text>'
        )
        lines.append(
            f'<text x="{bx + bar_w / 2:.1f}" y="{baseline + 22}" text-anchor="middle" style="font: 400 13px \'Microsoft YaHei\', \'Segoe UI\', Arial, sans-serif; fill: #486581;">{label}</text>'
        )
    lines.append(
        f'<text x="{x + 20}" y="{y + h - 20}" style="font: 400 13px \'Microsoft YaHei\', \'Segoe UI\', Arial, sans-serif; fill: #486581;">{footer}</text>'
    )


def draw_line_panel_cn(
    lines: list[str],
    title: str,
    x: int,
    y: int,
    w: int,
    h: int,
    series: list[tuple[str, list[float], str]],
    footer: str,
) -> None:
    lines.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="22" fill="#ffffff" stroke="#d9e2ec" />')
    lines.append(f'<text x="{x + 20}" y="{y + 34}" style="font: 700 18px \'Microsoft YaHei\', \'Segoe UI\', Arial, sans-serif; fill: #102a43;">{title}</text>')
    plot_x = x + 24
    plot_y = y + 56
    plot_w = w - 72
    plot_h = h - 112
    all_values = [value for _, values, _ in series for value in values]
    max_value = max(all_values)
    min_value = min(all_values)
    span = max(max_value - min_value, 1e-9)
    for tick in range(4):
        ty = plot_y + plot_h * tick / 3
        tick_value = max_value - span * tick / 3
        lines.append(f'<line x1="{plot_x}" y1="{ty:.1f}" x2="{plot_x + plot_w}" y2="{ty:.1f}" stroke="#e9eff5" />')
        lines.append(
            f'<text x="{plot_x + plot_w + 8}" y="{ty + 4:.1f}" style="font: 400 12px \'Segoe UI\', Arial, sans-serif; fill: #486581;">{fmt_num(tick_value)}</text>'
        )
    count = max(len(series[0][1]), 1)
    for idx in range(count):
        tx = plot_x + plot_w * idx / max(count - 1, 1)
        lines.append(
            f'<text x="{tx:.1f}" y="{plot_y + plot_h + 20}" text-anchor="middle" style="font: 400 12px \'Microsoft YaHei\', \'Segoe UI\', Arial, sans-serif; fill: #486581;">{idx + 1}</text>'
        )
    legend_x = x + 20
    legend_y = y + h - 48
    for name, values, color in series:
        points = []
        for idx, value in enumerate(values):
            px = plot_x + plot_w * idx / max(len(values) - 1, 1)
            normalized = (value - min_value) / span
            py = plot_y + plot_h - normalized * plot_h
            points.append((px, py))
        point_attr = " ".join(f"{px:.1f},{py:.1f}" for px, py in points)
        lines.append(f'<polyline fill="none" stroke="{color}" stroke-width="3.5" points="{point_attr}" />')
        for px, py in points:
            lines.append(f'<circle cx="{px:.1f}" cy="{py:.1f}" r="4" fill="{color}" />')
        lines.append(f'<rect x="{legend_x}" y="{legend_y - 7}" width="22" height="7" rx="3" fill="{color}" />')
        lines.append(
            f'<text x="{legend_x + 30}" y="{legend_y}" style="font: 400 13px \'Microsoft YaHei\', \'Segoe UI\', Arial, sans-serif; fill: #486581;">{name}</text>'
        )
        legend_x += 110
    lines.append(
        f'<text x="{x + 20}" y="{y + h - 20}" style="font: 400 13px \'Microsoft YaHei\', \'Segoe UI\', Arial, sans-serif; fill: #486581;">{footer}</text>'
    )


def write_benchmark_chart(seq: BenchmarkSummary, conc: BenchmarkSummary) -> None:
    width, height = 1080, 520
    lines = svg_header(width, height)
    chart_bg(lines, width, height)
    add_title(lines, "Benchmark Comparison", "submit_to_pdf | tests directory | dpi=300 page_dpi=300 fmt=jpg")
    draw_bar_panel(
        lines,
        "Wall Time",
        40,
        118,
        470,
        330,
        ["Sequential", "Concurrent"],
        [seq.wall_seconds, conc.wall_seconds],
        ["#d64550", "#2f855a"],
        "seconds",
        True,
    )
    draw_bar_panel(
        lines,
        "Throughput",
        570,
        118,
        470,
        330,
        ["Sequential", "Concurrent"],
        [seq.throughput, conc.throughput],
        ["#805ad5", "#1f77b4"],
        "files/s",
        False,
    )
    speedup = conc.throughput / seq.throughput
    reduction = (1.0 - conc.wall_seconds / seq.wall_seconds) * 100.0
    lines.append(
        f'<text class="note" x="40" y="480">speedup: {fmt_num(speedup)}x | wall-time reduction: {fmt_num(reduction)}%</text>'
    )
    save_svg(OUTPUT_DIR / "benchmark_seq_vs_concurrent.svg", lines + svg_footer())


def write_stress_time_chart(before: dict, after: dict) -> None:
    width, height = 1080, 520
    lines = svg_header(width, height)
    chart_bg(lines, width, height)
    add_title(lines, "Stress Test Round Times", "10 rounds | 100 tasks total | before vs after optimization")
    draw_line_panel(
        lines,
        "Round Wall Time",
        40,
        118,
        1000,
        330,
        [
            ("Before", before["round_seconds"], "#d64550"),
            ("After", after["round_seconds"], "#2f855a"),
        ],
    )
    before_total = float(before["total_seconds"])
    after_total = float(after["total_seconds"])
    speedup = before_total / after_total
    lines.append(
        f'<text class="note" x="40" y="480">before: {fmt_num(before_total)}s | after: {fmt_num(after_total)}s | speedup: {fmt_num(speedup)}x</text>'
    )
    save_svg(OUTPUT_DIR / "stress_round_times_before_after.svg", lines + svg_footer())


def write_stress_memory_chart(before: dict, after: dict) -> None:
    before_rounds = before["rounds_data"]
    after_rounds = after["rounds_data"]
    before_steady = float(before_rounds[-1]["rss_after_mb"])
    after_steady = float(after_rounds[-1]["rss_after_mb"])
    before_peak = float(before.get("max_self_rss_mb", before_steady))
    after_peak = float(after.get("max_self_rss_mb", after_steady))
    width, height = 1080, 520
    lines = svg_header(width, height)
    chart_bg(lines, width, height)
    add_title(lines, "Memory Comparison", "Python process RSS | baseline stress vs optimized stress")
    draw_bar_panel(
        lines,
        "Steady RSS",
        40,
        118,
        470,
        330,
        ["Before", "After"],
        [before_steady, after_steady],
        ["#d64550", "#2f855a"],
        "MB",
        True,
    )
    draw_bar_panel(
        lines,
        "Peak RSS",
        570,
        118,
        470,
        330,
        ["Before", "After"],
        [before_peak, after_peak],
        ["#805ad5", "#1f77b4"],
        "MB",
        True,
    )
    peak_tree = after.get("peak_tree_rss_mb")
    note = f"after peak process-tree RSS: {fmt_num(float(peak_tree))} MB" if peak_tree else "after peak process-tree RSS: n/a"
    lines.append(f'<text class="note" x="40" y="480">{note}</text>')
    save_svg(OUTPUT_DIR / "stress_memory_before_after.svg", lines + svg_footer())


def write_resolution_quality_chart(image_summary: dict) -> None:
    source_width_in = SOURCE_PAGE_WIDTH_PT / 72.0
    output_width_in = OUTPUT_PAGE_WIDTH_PT / 72.0
    source_dpi = SOURCE_IMAGE_WIDTH_PX / source_width_in
    output_dpi = OUTPUT_IMAGE_WIDTH_PX / output_width_in
    rows = image_summary["rows"]
    total_src_bytes = sum(float(row["src_bytes"]) for row in rows)
    total_out_bytes = sum(float(row["out_bytes"]) for row in rows)
    width, height = 1080, 520
    lines = svg_header(width, height)
    chart_bg(lines, width, height)
    add_title(lines, "505344.pdf Resolution and Quality", "source scanned PDF vs rebuilt output PDF")
    draw_bar_panel(
        lines,
        "Effective DPI",
        40,
        118,
        300,
        330,
        ["Source", "Output"],
        [source_dpi, output_dpi],
        ["#d97706", "#2563eb"],
        "dpi",
        False,
    )
    draw_bar_panel(
        lines,
        "Page Width",
        390,
        118,
        300,
        330,
        ["Source", "Output"],
        [source_width_in, output_width_in],
        ["#7c3aed", "#0f766e"],
        "inch",
        True,
    )
    draw_bar_panel(
        lines,
        "Page Image Bytes",
        740,
        118,
        300,
        330,
        ["Source", "Output"],
        [total_src_bytes / (1024 * 1024), total_out_bytes / (1024 * 1024)],
        ["#be123c", "#047857"],
        "MB",
        True,
    )
    lines.append(
        f'<text class="note" x="40" y="470">avg PSNR: {fmt_num(float(image_summary["avg_psnr_db"]))} dB | avg abs pixel diff: {fmt_num(float(image_summary["avg_mean_abs_diff"]))} / 255</text>'
    )
    lines.append(
        f'<text class="note" x="40" y="492">same page-image pixels were preserved; output reached 300 dpi by shrinking physical page size, not by upscaling pixels</text>'
    )
    save_svg(OUTPUT_DIR / "505344_resolution_quality.svg", lines + svg_footer())


def write_overview_chart(seq: BenchmarkSummary, conc: BenchmarkSummary, before: dict, after: dict, image_summary: dict) -> None:
    width, height = 1600, 1220
    lines = svg_header(width, height)
    chart_bg(lines, width, height)
    add_title(
        lines,
        "Optimization Overview",
        "submit_to_pdf | tests directory | one-shot benchmark + monitored stress + 505344.pdf quality summary",
    )

    throughput_speedup = conc.throughput / seq.throughput
    wall_reduction = (1.0 - conc.wall_seconds / seq.wall_seconds) * 100.0
    stress_before = float(before["total_seconds"])
    stress_after = float(after["total_seconds"])
    stress_speedup = stress_before / stress_after
    peak_tree = float(after.get("peak_tree_rss_mb", after.get("max_self_rss_mb", 0.0)))
    avg_psnr = float(image_summary["avg_psnr_db"])
    source_width_in = SOURCE_PAGE_WIDTH_PT / 72.0
    output_width_in = OUTPUT_PAGE_WIDTH_PT / 72.0
    source_dpi = SOURCE_IMAGE_WIDTH_PX / source_width_in
    output_dpi = OUTPUT_IMAGE_WIDTH_PX / output_width_in
    rows = image_summary["rows"]
    total_src_mb = sum(float(row["src_bytes"]) for row in rows) / (1024 * 1024)
    total_out_mb = sum(float(row["out_bytes"]) for row in rows) / (1024 * 1024)

    margin = 40
    gap = 18
    card_y = 116
    card_h = 118
    available = width - margin * 2 - gap * 4
    card_w = available // 5
    cards = [
        ("One-shot speedup", f"{fmt_num(throughput_speedup)}x", "throughput: concurrent / sequential", "#2563eb"),
        ("Wall reduction", f"{fmt_num(wall_reduction)}%", "one-shot benchmark wall time drop", "#2f855a"),
        ("Stress speedup", f"{fmt_num(stress_speedup)}x", "total seconds before / after", "#7c3aed"),
        ("Peak tree RSS", f"{fmt_num(peak_tree)} MB", "latest monitored optimized run", "#d97706"),
        ("Avg PSNR", f"{fmt_num(avg_psnr)} dB", "505344 extracted page-image diff", "#be123c"),
    ]
    for idx, (title, value, note, accent) in enumerate(cards):
        x = margin + idx * (card_w + gap)
        draw_kpi_card(lines, x, card_y, card_w, card_h, title, value, note, accent)

    panel_gap = 30
    panel_y1 = 270
    panel_h = 400
    panel_w = (width - margin * 2 - panel_gap) // 2
    left_x = margin
    right_x = margin + panel_w + panel_gap
    panel_y2 = 710

    draw_bar_panel(
        lines,
        "One-shot Benchmark",
        left_x,
        panel_y1,
        panel_w,
        panel_h,
        ["Seq s", "Conc s", "Seq t", "Conc t"],
        [seq.wall_seconds, conc.wall_seconds, seq.throughput, conc.throughput],
        ["#d64550", "#2f855a", "#805ad5", "#1f77b4"],
        "mixed",
        False,
    )
    lines.append(
        f'<text class="note" x="{left_x + 18}" y="{panel_y1 + panel_h - 34}">wall: {fmt_num(seq.wall_seconds)}s -> {fmt_num(conc.wall_seconds)}s</text>'
    )
    lines.append(
        f'<text class="note" x="{left_x + 18}" y="{panel_y1 + panel_h - 16}">throughput: {fmt_num(seq.throughput)} -> {fmt_num(conc.throughput)} files/s</text>'
    )

    draw_line_panel(
        lines,
        "Stress Round Wall Time",
        right_x,
        panel_y1,
        panel_w,
        panel_h,
        [
            ("Before", before["round_seconds"], "#d64550"),
            ("After", after["round_seconds"], "#2f855a"),
        ],
    )

    draw_bar_panel(
        lines,
        "Memory",
        left_x,
        panel_y2,
        panel_w,
        panel_h,
        ["Steady B", "Steady A", "Peak B", "Peak A"],
        [
            float(before["rounds_data"][-1]["rss_after_mb"]),
            float(after["rounds_data"][-1]["rss_after_mb"]),
            float(before.get("max_self_rss_mb", 0.0)),
            float(after.get("max_self_rss_mb", 0.0)),
        ],
        ["#d64550", "#2f855a", "#805ad5", "#1f77b4"],
        "MB",
        True,
    )
    lines.append(
        f'<text class="note" x="{left_x + 18}" y="{panel_y2 + panel_h - 16}">after peak process tree: {fmt_num(peak_tree)} MB</text>'
    )

    lines.append(
        f'<rect x="{right_x}" y="{panel_y2}" width="{panel_w}" height="{panel_h}" rx="18" fill="#f8fbff" stroke="#d9e2ec" />'
    )
    lines.append(f'<text class="label" x="{right_x + 18}" y="{panel_y2 + 28}">505344.pdf Resolution and Quality</text>')
    inner_gap = 18
    inner_w = (panel_w - 36 - inner_gap * 2) // 3
    inner_x = right_x + 18
    inner_y = panel_y2 + 46
    inner_h = 250
    draw_bar_panel(
        lines,
        "Effective DPI",
        inner_x,
        inner_y,
        inner_w,
        inner_h,
        ["Source", "Output"],
        [source_dpi, output_dpi],
        ["#d97706", "#2563eb"],
        "dpi",
        False,
    )
    draw_bar_panel(
        lines,
        "Page Width",
        inner_x + inner_w + inner_gap,
        inner_y,
        inner_w,
        inner_h,
        ["Source", "Output"],
        [source_width_in, output_width_in],
        ["#7c3aed", "#0f766e"],
        "inch",
        True,
    )
    draw_bar_panel(
        lines,
        "Page Image Bytes",
        inner_x + (inner_w + inner_gap) * 2,
        inner_y,
        inner_w,
        inner_h,
        ["Source", "Output"],
        [total_src_mb, total_out_mb],
        ["#be123c", "#047857"],
        "MB",
        True,
    )
    lines.append(
        f'<text class="note" x="{right_x + 18}" y="{panel_y2 + panel_h - 42}">page image pixels unchanged: {SOURCE_IMAGE_WIDTH_PX}px -> {OUTPUT_IMAGE_WIDTH_PX}px</text>'
    )
    lines.append(
        f'<text class="note" x="{right_x + 18}" y="{panel_y2 + panel_h - 24}">300 dpi came from shrinking physical page size, not from pixel upscaling</text>'
    )

    save_svg(OUTPUT_DIR / "optimization_overview.svg", lines + svg_footer())


def write_report_landscape_chart(
    seq: BenchmarkSummary,
    conc: BenchmarkSummary,
    before: dict,
    after: dict,
    image_summary: dict,
) -> None:
    width, height = 1920, 1080
    lines = svg_header(width, height)
    chart_bg(lines, width, height)
    add_title(
        lines,
        "submit_to_pdf Optimization Report",
        "tests directory | dpi=300 | page_dpi=300 | fmt=jpg | benchmark + stress + 505344.pdf quality",
    )

    throughput_speedup = conc.throughput / seq.throughput
    wall_reduction = (1.0 - conc.wall_seconds / seq.wall_seconds) * 100.0
    stress_before = float(before["total_seconds"])
    stress_after = float(after["total_seconds"])
    stress_speedup = stress_before / stress_after
    before_steady = float(before["rounds_data"][-1]["rss_after_mb"])
    after_steady = float(after["rounds_data"][-1]["rss_after_mb"])
    before_peak = float(before.get("max_self_rss_mb", before_steady))
    after_peak = float(after.get("max_self_rss_mb", after_steady))
    peak_tree = float(after.get("peak_tree_rss_mb", after_peak))

    source_width_in = SOURCE_PAGE_WIDTH_PT / 72.0
    output_width_in = OUTPUT_PAGE_WIDTH_PT / 72.0
    source_dpi = SOURCE_IMAGE_WIDTH_PX / source_width_in
    output_dpi = OUTPUT_IMAGE_WIDTH_PX / output_width_in
    rows = image_summary["rows"]
    total_src_mb = sum(float(row["src_bytes"]) for row in rows) / (1024 * 1024)
    total_out_mb = sum(float(row["out_bytes"]) for row in rows) / (1024 * 1024)
    avg_psnr = float(image_summary["avg_psnr_db"])
    avg_abs_diff = float(image_summary["avg_mean_abs_diff"])

    margin = 40
    gap = 18
    card_y = 116
    card_h = 112
    card_w = (width - margin * 2 - gap * 5) // 6
    cards = [
        ("One-shot speedup", f"{fmt_num(throughput_speedup)}x", "throughput: concurrent / sequential", "#2563eb"),
        ("Wall reduction", f"{fmt_num(wall_reduction)}%", "one-shot benchmark wall-time drop", "#2f855a"),
        ("Stress speedup", f"{fmt_num(stress_speedup)}x", "100 tasks before / after", "#7c3aed"),
        ("Steady RSS", f"{fmt_num(after_steady)} MB", f"before {fmt_num(before_steady)} MB", "#0f766e"),
        ("Peak tree RSS", f"{fmt_num(peak_tree)} MB", f"python peak {fmt_num(after_peak)} MB", "#d97706"),
        ("505344 PSNR", f"{fmt_num(avg_psnr)} dB", f"avg abs diff {fmt_num(avg_abs_diff)} / 255", "#be123c"),
    ]
    for idx, (title, value, note, accent) in enumerate(cards):
        x = margin + idx * (card_w + gap)
        draw_kpi_card(lines, x, card_y, card_w, card_h, title, value, note, accent)

    top_y = 258
    top_h = 368
    benchmark_w = 520
    stress_w = 860
    quality_w = width - margin * 2 - benchmark_w - stress_w - gap * 2

    draw_bar_panel(
        lines,
        "One-shot Benchmark",
        margin,
        top_y,
        benchmark_w,
        top_h,
        ["Seq s", "Conc s", "Seq t", "Conc t"],
        [seq.wall_seconds, conc.wall_seconds, seq.throughput, conc.throughput],
        ["#d64550", "#2f855a", "#805ad5", "#1f77b4"],
        "mixed",
        False,
    )
    lines.append(
        f'<text class="note" x="{margin + 18}" y="{top_y + top_h - 34}">wall: {fmt_num(seq.wall_seconds)}s -> {fmt_num(conc.wall_seconds)}s</text>'
    )
    lines.append(
        f'<text class="note" x="{margin + 18}" y="{top_y + top_h - 16}">throughput: {fmt_num(seq.throughput)} -> {fmt_num(conc.throughput)} files/s</text>'
    )

    stress_x = margin + benchmark_w + gap
    draw_line_panel(
        lines,
        "Stress Round Wall Time",
        stress_x,
        top_y,
        stress_w,
        top_h,
        [
            ("Before", before["round_seconds"], "#d64550"),
            ("After", after["round_seconds"], "#2f855a"),
        ],
    )

    quality_x = stress_x + stress_w + gap
    lines.append(
        f'<rect x="{quality_x}" y="{top_y}" width="{quality_w}" height="{top_h}" rx="18" fill="#f8fbff" stroke="#d9e2ec" />'
    )
    lines.append(f'<text class="label" x="{quality_x + 18}" y="{top_y + 28}">505344.pdf Snapshot</text>')
    qx = quality_x + 18
    qy = top_y + 56
    step = 38
    quality_lines = [
        ("Source page width", f"{fmt_num(source_width_in, 3)} inch"),
        ("Output page width", f"{fmt_num(output_width_in, 3)} inch"),
        ("Source effective DPI", f"{fmt_num(source_dpi)}"),
        ("Output effective DPI", f"{fmt_num(output_dpi)}"),
        ("Source page images", f"{fmt_num(total_src_mb)} MB"),
        ("Output page images", f"{fmt_num(total_out_mb)} MB"),
        ("Embedded image pixels", f"{SOURCE_IMAGE_WIDTH_PX}px -> {OUTPUT_IMAGE_WIDTH_PX}px"),
        ("Conclusion", "physical page shrank; pixels were not upscaled"),
    ]
    for idx, (label, value) in enumerate(quality_lines):
        cy = qy + idx * step
        lines.append(f'<text class="small" x="{qx}" y="{cy}">{label}</text>')
        lines.append(f'<text class="value" x="{qx}" y="{cy + 20}">{value}</text>')

    bottom_y = 654
    bottom_h = 348
    left_w = 620
    center_w = 620
    right_w = width - margin * 2 - left_w - center_w - gap * 2

    draw_bar_panel(
        lines,
        "Memory",
        margin,
        bottom_y,
        left_w,
        bottom_h,
        ["Steady B", "Steady A", "Peak B", "Peak A"],
        [before_steady, after_steady, before_peak, after_peak],
        ["#d64550", "#2f855a", "#805ad5", "#1f77b4"],
        "MB",
        True,
    )
    lines.append(
        f'<text class="note" x="{margin + 18}" y="{bottom_y + bottom_h - 16}">optimized run process-tree peak: {fmt_num(peak_tree)} MB</text>'
    )

    center_x = margin + left_w + gap
    draw_bar_panel(
        lines,
        "Resolution Shift",
        center_x,
        bottom_y,
        center_w,
        bottom_h,
        ["Src DPI", "Out DPI", "Src in", "Out in"],
        [source_dpi, output_dpi, source_width_in, output_width_in],
        ["#d97706", "#2563eb", "#7c3aed", "#0f766e"],
        "mixed",
        False,
    )
    lines.append(
        f'<text class="note" x="{center_x + 18}" y="{bottom_y + bottom_h - 34}">same image width in PDF: {SOURCE_IMAGE_WIDTH_PX}px</text>'
    )
    lines.append(
        f'<text class="note" x="{center_x + 18}" y="{bottom_y + bottom_h - 16}">300 dpi came from page-size shrink, not resampling up</text>'
    )

    right_x = center_x + center_w + gap
    lines.append(
        f'<rect x="{right_x}" y="{bottom_y}" width="{right_w}" height="{bottom_h}" rx="18" fill="#f8fbff" stroke="#d9e2ec" />'
    )
    lines.append(f'<text class="label" x="{right_x + 18}" y="{bottom_y + 28}">Key Takeaways</text>')
    takeaway_y = bottom_y + 64
    takeaways = [
        f"Batch throughput improved from {fmt_num(seq.throughput)} to {fmt_num(conc.throughput)} files/s.",
        f"10-round stress runtime dropped from {fmt_num(stress_before)}s to {fmt_num(stress_after)}s.",
        f"Python steady RSS stayed low: {fmt_num(before_steady)} MB -> {fmt_num(after_steady)} MB.",
        f"JPEG path kept acceptable quality: avg PSNR {fmt_num(avg_psnr)} dB.",
        "505344.pdf kept the same page-image pixels and changed physical page size to reach 300 dpi.",
        "Current bottleneck is still external renderer process cost and its transient memory footprint.",
    ]
    for idx, text in enumerate(takeaways):
        cy = takeaway_y + idx * 42
        lines.append(f'<circle cx="{right_x + 24}" cy="{cy - 5}" r="5" fill="#2563eb" />')
        lines.append(f'<text class="note" x="{right_x + 40}" y="{cy}">{text}</text>')

    save_svg(OUTPUT_DIR / "optimization_overview_landscape.svg", lines + svg_footer())


def write_ppt_cn_chart(
    seq: BenchmarkSummary,
    conc: BenchmarkSummary,
    before: dict,
    after: dict,
    image_summary: dict,
) -> None:
    width, height = 1920, 1080
    lines = svg_header(width, height)
    lines.append("<defs>")
    lines.append('<linearGradient id="pptBg" x1="0" y1="0" x2="1" y2="1">')
    lines.append('<stop offset="0%" stop-color="#0b1f33" />')
    lines.append('<stop offset="55%" stop-color="#102a43" />')
    lines.append('<stop offset="100%" stop-color="#16324f" />')
    lines.append("</linearGradient>")
    lines.append('<linearGradient id="accentBlue" x1="0" y1="0" x2="1" y2="0">')
    lines.append('<stop offset="0%" stop-color="#38bdf8" />')
    lines.append('<stop offset="100%" stop-color="#2563eb" />')
    lines.append("</linearGradient>")
    lines.append('<linearGradient id="accentGreen" x1="0" y1="0" x2="1" y2="0">')
    lines.append('<stop offset="0%" stop-color="#34d399" />')
    lines.append('<stop offset="100%" stop-color="#059669" />')
    lines.append("</linearGradient>")
    lines.append('<linearGradient id="accentPurple" x1="0" y1="0" x2="1" y2="0">')
    lines.append('<stop offset="0%" stop-color="#a78bfa" />')
    lines.append('<stop offset="100%" stop-color="#7c3aed" />')
    lines.append("</linearGradient>")
    lines.append("</defs>")
    lines.append(f'<rect x="0" y="0" width="{width}" height="{height}" fill="url(#pptBg)" />')
    lines.append(f'<circle cx="{width - 180}" cy="140" r="220" fill="#1d4ed8" opacity="0.10" />')
    lines.append(f'<circle cx="160" cy="{height - 120}" r="240" fill="#0ea5e9" opacity="0.08" />')
    lines.append(
        '<text x="52" y="68" style="font: 700 34px \'Microsoft YaHei\', \'Segoe UI\', Arial, sans-serif; fill: #f8fafc;">submit_to_pdf 性能优化汇报</text>'
    )
    lines.append(
        '<text x="52" y="100" style="font: 400 15px \'Microsoft YaHei\', \'Segoe UI\', Arial, sans-serif; fill: #cbd5e1;">测试目录：C:\\Users\\PC\\pros\\python\\tests | 参数：dpi=300 / page_dpi=300 / fmt=jpg</text>'
    )

    throughput_speedup = conc.throughput / seq.throughput
    wall_reduction = (1.0 - conc.wall_seconds / seq.wall_seconds) * 100.0
    stress_before = float(before["total_seconds"])
    stress_after = float(after["total_seconds"])
    stress_speedup = stress_before / stress_after
    before_steady = float(before["rounds_data"][-1]["rss_after_mb"])
    after_steady = float(after["rounds_data"][-1]["rss_after_mb"])
    before_peak = float(before.get("max_self_rss_mb", before_steady))
    after_peak = float(after.get("max_self_rss_mb", after_steady))
    peak_tree = float(after.get("peak_tree_rss_mb", after_peak))
    avg_psnr = float(image_summary["avg_psnr_db"])
    avg_abs_diff = float(image_summary["avg_mean_abs_diff"])
    source_width_in = SOURCE_PAGE_WIDTH_PT / 72.0
    output_width_in = OUTPUT_PAGE_WIDTH_PT / 72.0
    source_dpi = SOURCE_IMAGE_WIDTH_PX / source_width_in
    output_dpi = OUTPUT_IMAGE_WIDTH_PX / output_width_in

    margin = 52
    gap = 18
    card_y = 128
    card_h = 118
    card_w = (width - margin * 2 - gap * 4) // 5
    cards = [
        ("单次吞吐提升", f"{fmt_num(throughput_speedup)}x", f"{fmt_num(seq.throughput)} -> {fmt_num(conc.throughput)} 文件/s", "url(#accentBlue)"),
        ("单次耗时下降", f"{fmt_num(wall_reduction)}%", f"{fmt_num(seq.wall_seconds)}s -> {fmt_num(conc.wall_seconds)}s", "url(#accentGreen)"),
        ("连续压测提速", f"{fmt_num(stress_speedup)}x", f"{fmt_num(stress_before)}s -> {fmt_num(stress_after)}s", "url(#accentPurple)"),
        ("稳态 RSS", f"{fmt_num(after_steady)} MB", f"基线 {fmt_num(before_steady)} MB", "#f59e0b"),
        ("峰值内存", f"{fmt_num(peak_tree)} MB", f"Python 峰值 {fmt_num(after_peak)} MB", "#ef4444"),
    ]
    for idx, (title, value, note, accent) in enumerate(cards):
        x = margin + idx * (card_w + gap)
        lines.append(f'<rect x="{x}" y="{card_y}" width="{card_w}" height="{card_h}" rx="24" fill="#ffffff" opacity="0.98" />')
        lines.append(f'<rect x="{x}" y="{card_y}" width="{card_w}" height="8" rx="24" fill="{accent}" />')
        lines.append(
            f'<text x="{x + 20}" y="{card_y + 34}" style="font: 400 14px \'Microsoft YaHei\', \'Segoe UI\', Arial, sans-serif; fill: #486581;">{title}</text>'
        )
        lines.append(
            f'<text x="{x + 20}" y="{card_y + 78}" style="font: 700 34px \'Segoe UI\', Arial, sans-serif; fill: #0f172a;">{value}</text>'
        )
        lines.append(
            f'<text x="{x + 20}" y="{card_y + 102}" style="font: 400 13px \'Microsoft YaHei\', \'Segoe UI\', Arial, sans-serif; fill: #64748b;">{note}</text>'
        )

    top_y = 274
    panel_h = 392
    left_w = 560
    middle_w = 760
    right_w = width - margin * 2 - left_w - middle_w - gap * 2
    left_x = margin
    middle_x = left_x + left_w + gap
    right_x = middle_x + middle_w + gap

    draw_bar_panel_cn(
        lines,
        "单次性能对比",
        left_x,
        top_y,
        left_w,
        panel_h,
        ["顺序耗时", "并发耗时", "顺序吞吐", "并发吞吐"],
        [seq.wall_seconds, conc.wall_seconds, seq.throughput, conc.throughput],
        ["#ef4444", "#10b981", "#8b5cf6", "#2563eb"],
        "说明：顺序为 --in-flight 1，并发为 --in-flight 4",
    )

    draw_line_panel_cn(
        lines,
        "10 轮连续压测耗时",
        middle_x,
        top_y,
        middle_w,
        panel_h,
        [
            ("优化前", before["round_seconds"], "#ef4444"),
            ("优化后", after["round_seconds"], "#10b981"),
        ],
        "结果：100/100 成功，优化后每轮耗时整体下移",
    )

    lines.append(f'<rect x="{right_x}" y="{top_y}" width="{right_w}" height="{panel_h}" rx="22" fill="#ffffff" opacity="0.98" />')
    lines.append(
        f'<text x="{right_x + 20}" y="{top_y + 34}" style="font: 700 18px \'Microsoft YaHei\', \'Segoe UI\', Arial, sans-serif; fill: #102a43;">核心结论</text>'
    )
    bullets = [
        f"批量吞吐从 {fmt_num(seq.throughput)} 提升到 {fmt_num(conc.throughput)} 文件/s。",
        f"单次任务总耗时从 {fmt_num(seq.wall_seconds)}s 降到 {fmt_num(conc.wall_seconds)}s。",
        f"连续 100 个任务总耗时从 {fmt_num(stress_before)}s 降到 {fmt_num(stress_after)}s。",
        f"Python 稳态 RSS 维持在 {fmt_num(after_steady)} MB，未见明显泄漏。",
        f"当前主要压力仍在外部渲染进程，优化后进程树峰值约 {fmt_num(peak_tree)} MB。",
    ]
    bullet_y = top_y + 88
    for idx, text in enumerate(bullets):
        cy = bullet_y + idx * 60
        lines.append(f'<circle cx="{right_x + 26}" cy="{cy - 7}" r="6" fill="#2563eb" />')
        lines.append(
            f'<text x="{right_x + 44}" y="{cy}" style="font: 400 18px \'Microsoft YaHei\', \'Segoe UI\', Arial, sans-serif; fill: #334155;">{text}</text>'
        )

    bottom_y = 692
    bottom_h = 336
    bottom_left_w = 760
    bottom_mid_w = 520
    bottom_right_w = width - margin * 2 - bottom_left_w - bottom_mid_w - gap * 2

    draw_bar_panel_cn(
        lines,
        "内存对比",
        left_x,
        bottom_y,
        bottom_left_w,
        bottom_h,
        ["稳态前", "稳态后", "峰值前", "峰值后"],
        [before_steady, after_steady, before_peak, after_peak],
        ["#ef4444", "#10b981", "#8b5cf6", "#2563eb"],
        "说明：峰值为 Python 进程 RSS；进程树峰值单独统计为 734.52 MB",
    )

    draw_bar_panel_cn(
        lines,
        "505344 分辨率变化",
        middle_x,
        bottom_y,
        bottom_mid_w,
        bottom_h,
        ["源 PDF DPI", "输出 DPI", "源页面宽", "输出页面宽"],
        [source_dpi, output_dpi, source_width_in, output_width_in],
        ["#f59e0b", "#2563eb", "#a855f7", "#0f766e"],
        "结论：300 dpi 来自物理页尺寸缩小，不是像素放大",
    )

    lines.append(f'<rect x="{right_x}" y="{bottom_y}" width="{bottom_right_w}" height="{bottom_h}" rx="22" fill="#ffffff" opacity="0.98" />')
    lines.append(
        f'<text x="{right_x + 20}" y="{bottom_y + 34}" style="font: 700 18px \'Microsoft YaHei\', \'Segoe UI\', Arial, sans-serif; fill: #102a43;">画质补充</text>'
    )
    quality_notes = [
        f"simple-scan JPEG 默认质量：90",
        f"505344 平均 PSNR：{fmt_num(avg_psnr)} dB",
        f"平均绝对像素差：{fmt_num(avg_abs_diff)} / 255",
        f"页图总字节：18.09 MB -> 3.27 MB",
        "结论：体积显著下降，清晰度只有轻微有损变化",
    ]
    qy = bottom_y + 88
    for idx, text in enumerate(quality_notes):
        cy = qy + idx * 42
        lines.append(f'<rect x="{right_x + 20}" y="{cy - 14}" width="8" height="8" rx="2" fill="#10b981" />')
        lines.append(
            f'<text x="{right_x + 38}" y="{cy}" style="font: 400 16px \'Microsoft YaHei\', \'Segoe UI\', Arial, sans-serif; fill: #334155;">{text}</text>'
        )

    lines.append(
        '<text x="52" y="1052" style="font: 400 13px \'Microsoft YaHei\', \'Segoe UI\', Arial, sans-serif; fill: #cbd5e1;">结论：本轮优化显著提升批量吞吐与连续压测效率，主瓶颈已收敛到外部渲染进程的瞬时资源消耗。</text>'
    )
    save_svg(OUTPUT_DIR / "optimization_ppt_cn.svg", lines + svg_footer())


def main() -> None:
    seq = parse_benchmark_log(SEQ_LOG)
    conc = parse_benchmark_log(CONC_LOG)
    before = load_json(STRESS_BEFORE)
    after = load_json(STRESS_AFTER)
    image_summary = load_json(IMAGE_COMPARE)
    write_ppt_cn_chart(seq, conc, before, after, image_summary)
    write_report_landscape_chart(seq, conc, before, after, image_summary)
    write_overview_chart(seq, conc, before, after, image_summary)
    write_benchmark_chart(seq, conc)
    write_stress_time_chart(before, after)
    write_stress_memory_chart(before, after)
    write_resolution_quality_chart(image_summary)
    print(f"generated SVG charts under {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
