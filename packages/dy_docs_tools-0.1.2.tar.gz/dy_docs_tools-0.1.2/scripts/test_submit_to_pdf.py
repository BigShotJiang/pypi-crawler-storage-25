#!/usr/bin/env python
from __future__ import annotations

import argparse
import os
import sys
import time
import zipfile
from pathlib import Path


def default_worker_count() -> int:
    return max(1, os.cpu_count() or 1)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Test submit_to_pdf against all files in a directory."
    )
    parser.add_argument(
        "--input-dir",
        type=Path,
        default=Path(r"C:\Users\PC\pros\python\tests"),
        help="Directory containing input files.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(r"C:\Users\PC\pros\python\tools\target\submit_to_pdf_test_page_dpi"),
        help="Directory to write converted PDFs.",
    )
    parser.add_argument(
        "--dpi",
        type=int,
        default=150,
        help="Rasterization DPI for PDF/DOCX inputs.",
    )
    parser.add_argument(
        "--page-dpi",
        type=float,
        default=300,
        help="Target page DPI used when writing output PDF page size.",
    )
    parser.add_argument(
        "--fmt",
        default="jpg",
        choices=["png", "jpg", "jpeg", "tif", "tiff"],
        help="Intermediate image format.",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=default_worker_count(),
        help="ConverterPool worker count. Defaults to the current CPU count.",
    )
    parser.add_argument(
        "--in-flight",
        type=int,
        default=None,
        help="Maximum number of submitted jobs kept in flight at once. Defaults to workers.",
    )
    parser.add_argument(
        "--timeout-ms",
        type=int,
        default=300_000,
        help="Per-file timeout in milliseconds.",
    )
    parser.add_argument(
        "--max-area",
        type=int,
        default=36_000_000,
        help="Maximum image area in pixels.",
    )
    parser.add_argument(
        "--max-size-mb",
        type=float,
        default=10.0,
        help="Maximum image size in MB.",
    )
    return parser.parse_args()


def load_docs_tools(repo_root: Path):
    wheel_dir = repo_root / "target" / "wheels"
    wheels = sorted(wheel_dir.glob("docs_tools-*.whl"), key=lambda p: p.stat().st_mtime)
    if not wheels:
        raise FileNotFoundError(f"no wheel found under {wheel_dir}")

    wheel = wheels[-1]
    unpack = repo_root / "target" / f"manual_unpack_{int(time.time())}"
    unpack.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(wheel) as zf:
        zf.extractall(unpack)

    sys.path.insert(0, str(unpack.resolve()))
    import docs_tools

    return docs_tools, wheel


def finalize_job(
    job: dict[str, object],
    results: list[tuple[str, str, str] | None],
    timeout_ms: int,
) -> None:
    try:
        result = job["handle"].result(timeout_ms)
        results[int(job["index"])] = (str(job["src"]), "OK", str(result))
    except Exception as exc:
        results[int(job["index"])] = (str(job["src"]), "FAIL", str(exc))


def collect_completed_jobs(
    pending: list[dict[str, object]],
    results: list[tuple[str, str, str] | None],
    timeout_ms: int,
) -> bool:
    completed_indices: list[int] = []
    for idx, job in enumerate(pending):
        if job["handle"].done():
            completed_indices.append(idx)

    if not completed_indices:
        return False

    for idx in reversed(completed_indices):
        finalize_job(pending.pop(idx), results, timeout_ms)
    return True


def main() -> int:
    args = parse_args()
    repo_root = Path(__file__).resolve().parents[1]

    if not args.input_dir.exists():
        print(f"FAIL: input dir not found: {args.input_dir}")
        return 2

    args.output_dir.mkdir(parents=True, exist_ok=True)

    docs_tools, wheel = load_docs_tools(repo_root)
    print(f"INFO: wheel={wheel}")
    print(f"INFO: input_dir={args.input_dir}")
    print(f"INFO: output_dir={args.output_dir}")
    print(f"INFO: workers={args.workers} in_flight={args.in_flight or args.workers}")

    files = sorted(p for p in args.input_dir.rglob("*") if p.is_file())
    print(f"INFO: files={len(files)}")

    pool = docs_tools.ConverterPool(workers=args.workers)
    results: list[tuple[str, str, str] | None] = [None] * len(files)
    in_flight = max(1, args.in_flight or args.workers)
    try:
        pending: list[dict[str, object]] = []
        next_index = 0
        while next_index < len(files) or pending:
            while next_index < len(files) and len(pending) < in_flight:
                src = files[next_index]
                out_pdf = args.output_dir / f"{src.stem}.submit.page{int(args.page_dpi)}.pdf"
                handle = pool.submit_to_pdf(
                    str(src),
                    str(out_pdf),
                    apply_constraints=False,
                    dpi=args.dpi,
                    fmt=args.fmt,
                    prefix="page",
                    max_area=args.max_area,
                    max_size_mb=args.max_size_mb,
                    page_dpi=args.page_dpi,
                    return_mode="data_url",
                )
                pending.append(
                    {
                        "index": next_index,
                        "src": src,
                        "handle": handle,
                    }
                )
                next_index += 1

            if not collect_completed_jobs(pending, results, args.timeout_ms):
                time.sleep(0.01)

        while pending:
            finalize_job(pending.pop(0), results, args.timeout_ms)
    finally:
        pool.close()

    results = [item for item in results if item is not None]
    ok = sum(1 for _, status, _ in results if status == "OK")
    fail = len(results) - ok
    print(f"SUMMARY: TOTAL={len(results)} OK={ok} FAIL={fail}")

    for src, status, detail in results:
        print(f"[{status}] {src}")
        print(detail)

    return 0 if fail == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
