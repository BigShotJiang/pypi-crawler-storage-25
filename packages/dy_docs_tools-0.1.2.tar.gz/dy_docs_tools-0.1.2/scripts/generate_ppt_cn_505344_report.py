#!/usr/bin/env python
from __future__ import annotations

import csv
import json
import re
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "docs" / "charts" / "optimization_ppt_cn_505344.svg"

SEQ_LOG = ROOT / "target" / "chart_inputs" / "benchmark_seq_page300_bc.log"
CONC_LOG = ROOT / "target" / "chart_inputs" / "benchmark_conc_page300_bc.log"
SEQ_BEFORE_CSV = ROOT / "target" / "benchmark_seq_page300" / "results.csv"
SEQ_AFTER_CSV = ROOT / "target" / "benchmark_seq_page300_bc" / "results.csv"
CONC_BEFORE_CSV = ROOT / "target" / "benchmark_conc_page300" / "results.csv"
CONC_AFTER_CSV = ROOT / "target" / "benchmark_conc_page300_bc" / "results.csv"
STRESS_BEFORE = ROOT / "target" / "stress_loop_monitor_page300" / "summary.json"
STRESS_AFTER = ROOT / "target" / "stress_loop_monitor_page300_bc" / "summary.json"
IMAGE_COMPARE = ROOT / "target" / "image_compare_505344" / "summary.json"

SOURCE_PDF = Path(r"C:\Users\PC\pros\python\tests\505344.pdf")
SOURCE_PDF_PAGES = 6
SOURCE_PAGE_WIDTH_PT = 2355.91
SOURCE_PAGE_HEIGHT_PT = 1604.24
OUTPUT_PAGE_WIDTH_PT = 564.96
SOURCE_IMAGE_WIDTH_PX = 2354
OUTPUT_IMAGE_WIDTH_PX = 2354


@dataclass
class BenchmarkSummary:
    wall_seconds: float
    throughput: float


@dataclass
class TargetPdfSummary:
    before_seq_seconds: float
    after_seq_seconds: float
    before_conc_seconds: float
    after_conc_seconds: float
    output_bytes: int
    source_bytes: int


def read_text(path: Path) -> str:
    data = path.read_bytes()
    if data.startswith(b"\xff\xfe") or data.startswith(b"\xfe\xff"):
        return data.decode("utf-16", errors="replace")
    if data.startswith(b"\xef\xbb\xbf"):
        return data.decode("utf-8-sig", errors="replace")
    return data.decode("utf-8", errors="replace")


def load_json(path: Path) -> dict:
    return json.loads(read_text(path))


def parse_benchmark_log(path: Path) -> BenchmarkSummary:
    text = read_text(path)
    match = re.search(
        r"WALL:\s+total=(?P<seconds>\d+(?:\.\d+)?)s\s+throughput=(?P<throughput>\d+(?:\.\d+)?)\s+files/s",
        text,
    )
    if not match:
        raise ValueError(f"failed to parse WALL line in {path}")
    return BenchmarkSummary(
        wall_seconds=float(match.group("seconds")),
        throughput=float(match.group("throughput")),
    )


def find_csv_row(path: Path, target_name: str) -> dict[str, str]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            if row["file"].endswith(target_name):
                return row
    raise ValueError(f"failed to find {target_name} in {path}")


def load_target_pdf_summary() -> TargetPdfSummary:
    seq_before = find_csv_row(SEQ_BEFORE_CSV, "505344.pdf")
    seq_after = find_csv_row(SEQ_AFTER_CSV, "505344.pdf")
    conc_before = find_csv_row(CONC_BEFORE_CSV, "505344.pdf")
    conc_after = find_csv_row(CONC_AFTER_CSV, "505344.pdf")
    return TargetPdfSummary(
        before_seq_seconds=float(seq_before["seconds"]),
        after_seq_seconds=float(seq_after["seconds"]),
        before_conc_seconds=float(conc_before["seconds"]),
        after_conc_seconds=float(conc_after["seconds"]),
        output_bytes=int(seq_after["bytes"]),
        source_bytes=SOURCE_PDF.stat().st_size,
    )


def fmt_num(value: float, digits: int = 2) -> str:
    return f"{value:.{digits}f}"


def fmt_mb(value_bytes: int) -> str:
    return f"{value_bytes / 1_000_000:.2f} MB"


def svg_text(x: float, y: float, text: str, size: int, weight: int, color: str, family: str = "Microsoft YaHei, Segoe UI, Arial, sans-serif") -> str:
    return f'<text x="{x}" y="{y}" style="font: {weight} {size}px {family}; fill: {color};">{text}</text>'


def add_card(lines: list[str], x: int, y: int, w: int, h: int, title: str, value: str, note: str, accent: str) -> None:
    lines.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="24" fill="#ffffff" opacity="0.98" />')
    lines.append(f'<rect x="{x}" y="{y}" width="{w}" height="8" rx="24" fill="{accent}" />')
    lines.append(svg_text(x + 20, y + 34, title, 14, 400, "#486581"))
    lines.append(svg_text(x + 20, y + 78, value, 34, 700, "#0f172a", "Segoe UI, Arial, sans-serif"))
    lines.append(svg_text(x + 20, y + 102, note, 13, 400, "#64748b"))


def add_bar_panel(lines: list[str], x: int, y: int, w: int, h: int, title: str, labels: list[str], values: list[float], colors: list[str], footer: str) -> None:
    lines.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="22" fill="#ffffff" opacity="0.98" />')
    lines.append(svg_text(x + 20, y + 34, title, 18, 700, "#102a43"))
    plot_x = x + 26
    plot_y = y + 62
    plot_w = w - 52
    plot_h = h - 112
    baseline = plot_y + plot_h
    max_value = max(values) if values else 1.0
    lines.append(f'<line x1="{plot_x}" y1="{baseline}" x2="{plot_x + plot_w}" y2="{baseline}" stroke="#bcccdc" />')
    gap = 24
    bar_w = max(48, int((plot_w - gap * (len(values) - 1)) / max(len(values), 1)))
    total_w = len(values) * bar_w + (len(values) - 1) * gap
    start_x = plot_x + max(0, (plot_w - total_w) // 2)
    for idx, (label, value, color) in enumerate(zip(labels, values, colors)):
        bar_h = 0 if max_value == 0 else int((value / max_value) * (plot_h - 18))
        bx = start_x + idx * (bar_w + gap)
        by = baseline - bar_h
        lines.append(f'<rect x="{bx}" y="{by}" width="{bar_w}" height="{bar_h}" rx="12" fill="{color}" />')
        lines.append(svg_text(bx + bar_w / 2, by - 10, fmt_num(value), 16, 700, "#102a43", "Segoe UI, Arial, sans-serif").replace('><', ' text-anchor="middle"><'))
        lines.append(svg_text(bx + bar_w / 2, baseline + 22, label, 13, 400, "#486581").replace('><', ' text-anchor="middle"><'))
    lines.append(svg_text(x + 20, y + h - 20, footer, 13, 400, "#486581"))


def add_line_panel(lines: list[str], x: int, y: int, w: int, h: int, title: str, series: list[tuple[str, list[float], str]], footer: str) -> None:
    lines.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="22" fill="#ffffff" opacity="0.98" />')
    lines.append(svg_text(x + 20, y + 34, title, 18, 700, "#102a43"))
    plot_x = x + 24
    plot_y = y + 56
    plot_w = w - 72
    plot_h = h - 112
    all_values = [value for _, values, _ in series for value in values]
    max_value = max(all_values)
    min_value = min(all_values)
    span = max(max_value - min_value, 1e-9)
    for tick in range(4):
        ty = plot_y + plot_h * tick / 3
        tick_value = max_value - span * tick / 3
        lines.append(f'<line x1="{plot_x}" y1="{ty:.1f}" x2="{plot_x + plot_w}" y2="{ty:.1f}" stroke="#e9eff5" />')
        lines.append(svg_text(plot_x + plot_w + 8, ty + 4, fmt_num(tick_value), 12, 400, "#486581", "Segoe UI, Arial, sans-serif"))
    count = max(len(series[0][1]), 1)
    for idx in range(count):
        tx = plot_x + plot_w * idx / max(count - 1, 1)
        lines.append(svg_text(tx, plot_y + plot_h + 20, str(idx + 1), 12, 400, "#486581").replace('><', ' text-anchor="middle"><'))
    legend_x = x + 20
    legend_y = y + h - 48
    for name, values, color in series:
        points = []
        for idx, value in enumerate(values):
            px = plot_x + plot_w * idx / max(len(values) - 1, 1)
            normalized = (value - min_value) / span
            py = plot_y + plot_h - normalized * plot_h
            points.append((px, py))
        point_attr = " ".join(f"{px:.1f},{py:.1f}" for px, py in points)
        lines.append(f'<polyline fill="none" stroke="{color}" stroke-width="3.5" points="{point_attr}" />')
        for px, py in points:
            lines.append(f'<circle cx="{px:.1f}" cy="{py:.1f}" r="4" fill="{color}" />')
        lines.append(f'<rect x="{legend_x}" y="{legend_y - 7}" width="22" height="7" rx="3" fill="{color}" />')
        lines.append(svg_text(legend_x + 30, legend_y, name, 13, 400, "#486581"))
        legend_x += 110
    lines.append(svg_text(x + 20, y + h - 20, footer, 13, 400, "#486581"))


def main() -> None:
    seq = parse_benchmark_log(SEQ_LOG)
    conc = parse_benchmark_log(CONC_LOG)
    before = load_json(STRESS_BEFORE)
    after = load_json(STRESS_AFTER)
    image_summary = load_json(IMAGE_COMPARE)
    target_pdf = load_target_pdf_summary()

    throughput_speedup = conc.throughput / seq.throughput
    wall_reduction = (1.0 - conc.wall_seconds / seq.wall_seconds) * 100.0
    stress_before = float(before["total_seconds"])
    stress_after = float(after["total_seconds"])
    stress_speedup = stress_before / stress_after
    before_steady = float(before["rounds_data"][-1]["rss_after_mb"])
    after_steady = float(after["rounds_data"][-1]["rss_after_mb"])
    before_peak = float(before.get("max_self_rss_mb", before_steady))
    after_peak = float(after.get("max_self_rss_mb", after_steady))
    peak_tree = float(after.get("peak_tree_rss_mb", after_peak))
    avg_psnr = float(image_summary["avg_psnr_db"])
    avg_abs_diff = float(image_summary["avg_mean_abs_diff"])
    source_width_in = SOURCE_PAGE_WIDTH_PT / 72.0
    output_width_in = OUTPUT_PAGE_WIDTH_PT / 72.0
    source_dpi = SOURCE_IMAGE_WIDTH_PX / source_width_in
    output_dpi = OUTPUT_IMAGE_WIDTH_PX / output_width_in
    target_seq_delta_pct = (1.0 - target_pdf.after_seq_seconds / target_pdf.before_seq_seconds) * 100.0
    target_conc_delta_pct = (1.0 - target_pdf.after_conc_seconds / target_pdf.before_conc_seconds) * 100.0

    width, height = 1920, 1080
    lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        "<defs>",
        '<linearGradient id="pptBg" x1="0" y1="0" x2="1" y2="1">',
        '<stop offset="0%" stop-color="#0b1f33" />',
        '<stop offset="55%" stop-color="#102a43" />',
        '<stop offset="100%" stop-color="#16324f" />',
        "</linearGradient>",
        '<linearGradient id="accentBlue" x1="0" y1="0" x2="1" y2="0">',
        '<stop offset="0%" stop-color="#38bdf8" />',
        '<stop offset="100%" stop-color="#2563eb" />',
        "</linearGradient>",
        '<linearGradient id="accentGreen" x1="0" y1="0" x2="1" y2="0">',
        '<stop offset="0%" stop-color="#34d399" />',
        '<stop offset="100%" stop-color="#059669" />',
        "</linearGradient>",
        '<linearGradient id="accentPurple" x1="0" y1="0" x2="1" y2="0">',
        '<stop offset="0%" stop-color="#a78bfa" />',
        '<stop offset="100%" stop-color="#7c3aed" />',
        "</linearGradient>",
        "</defs>",
        f'<rect x="0" y="0" width="{width}" height="{height}" fill="url(#pptBg)" />',
        f'<circle cx="{width - 180}" cy="140" r="220" fill="#1d4ed8" opacity="0.10" />',
        f'<circle cx="160" cy="{height - 120}" r="240" fill="#0ea5e9" opacity="0.08" />',
        svg_text(52, 68, "submit_to_pdf 性能优化汇报", 34, 700, "#f8fafc"),
        svg_text(52, 100, "测试目录：C:\\Users\\PC\\pros\\python\\tests | 参数：dpi=300 / page_dpi=300 / fmt=jpg", 15, 400, "#cbd5e1"),
    ]

    margin = 52
    gap = 18
    card_y = 128
    card_h = 118
    card_w = (width - margin * 2 - gap * 4) // 5
    cards = [
        ("单次吞吐提升", f"{fmt_num(throughput_speedup)}x", f"{fmt_num(seq.throughput)} -> {fmt_num(conc.throughput)} 文件/s", "url(#accentBlue)"),
        ("单次耗时下降", f"{fmt_num(wall_reduction)}%", f"{fmt_num(seq.wall_seconds)}s -> {fmt_num(conc.wall_seconds)}s", "url(#accentGreen)"),
        ("连续压测提速", f"{fmt_num(stress_speedup)}x", f"{fmt_num(stress_before)}s -> {fmt_num(stress_after)}s", "url(#accentPurple)"),
        ("稳态 RSS", f"{fmt_num(after_steady)} MB", f"基线 {fmt_num(before_steady)} MB", "#f59e0b"),
        ("峰值内存", f"{fmt_num(peak_tree)} MB", f"Python 峰值 {fmt_num(after_peak)} MB", "#ef4444"),
    ]
    for idx, card in enumerate(cards):
        add_card(lines, margin + idx * (card_w + gap), card_y, card_w, card_h, *card)

    top_y = 274
    panel_h = 392
    left_w = 560
    middle_w = 760
    right_w = width - margin * 2 - left_w - middle_w - gap * 2
    left_x = margin
    middle_x = left_x + left_w + gap
    right_x = middle_x + middle_w + gap

    add_bar_panel(
        lines,
        left_x,
        top_y,
        left_w,
        panel_h,
        "批量性能对比",
        ["顺序耗时", "并发耗时", "顺序吞吐", "并发吞吐"],
        [seq.wall_seconds, conc.wall_seconds, seq.throughput, conc.throughput],
        ["#ef4444", "#10b981", "#8b5cf6", "#2563eb"],
        "说明：顺序为 --in-flight 1，并发为 --in-flight 4",
    )
    add_line_panel(
        lines,
        middle_x,
        top_y,
        middle_w,
        panel_h,
        "10 轮连续压测耗时",
        [("优化前", before["round_seconds"], "#ef4444"), ("优化后", after["round_seconds"], "#10b981")],
        "结果：100/100 成功，优化后每轮耗时整体下移",
    )

    lines.append(f'<rect x="{right_x}" y="{top_y}" width="{right_w}" height="{panel_h}" rx="22" fill="#ffffff" opacity="0.98" />')
    lines.append(svg_text(right_x + 20, top_y + 34, "505344.pdf 单文件表现", 18, 700, "#102a43"))
    single_file_lines = [
        f"顺序模式：{fmt_num(target_pdf.before_seq_seconds, 3)}s -> {fmt_num(target_pdf.after_seq_seconds, 3)}s。",
        f"并发批量中该文件：{fmt_num(target_pdf.before_conc_seconds, 3)}s -> {fmt_num(target_pdf.after_conc_seconds, 3)}s。",
        f"顺序变化：{fmt_num(target_seq_delta_pct)}% | 并发变化：{fmt_num(target_conc_delta_pct)}%。",
        "结论：单个大文件耗时基本持平，本轮优化收益主要体现在批量调度与整体吞吐。",
        f"输出 PDF 体积稳定：{fmt_mb(target_pdf.output_bytes)}。",
    ]
    bullet_y = top_y + 88
    for idx, text in enumerate(single_file_lines):
        cy = bullet_y + idx * 54
        lines.append(f'<circle cx="{right_x + 26}" cy="{cy - 7}" r="6" fill="#2563eb" />')
        lines.append(svg_text(right_x + 44, cy, text, 17, 400, "#334155"))

    bottom_y = 692
    bottom_h = 336
    bottom_left_w = 700
    bottom_mid_w = 540
    bottom_right_w = width - margin * 2 - bottom_left_w - bottom_mid_w - gap * 2

    add_bar_panel(
        lines,
        left_x,
        bottom_y,
        bottom_left_w,
        bottom_h,
        "内存对比",
        ["稳态前", "稳态后", "峰值前", "峰值后"],
        [before_steady, after_steady, before_peak, after_peak],
        ["#ef4444", "#10b981", "#8b5cf6", "#2563eb"],
        "说明：峰值为 Python 进程 RSS；进程树峰值单独统计为 734.52 MB",
    )
    add_bar_panel(
        lines,
        middle_x,
        bottom_y,
        bottom_mid_w,
        bottom_h,
        "505344 单文件耗时对比",
        ["前-顺序", "后-顺序", "前-并发", "后-并发"],
        [
            target_pdf.before_seq_seconds,
            target_pdf.after_seq_seconds,
            target_pdf.before_conc_seconds,
            target_pdf.after_conc_seconds,
        ],
        ["#ef4444", "#10b981", "#f59e0b", "#2563eb"],
        "结论：该文件单独处理路径变化很小，优化收益不在单文件耗时本身",
    )

    lines.append(f'<rect x="{right_x}" y="{bottom_y}" width="{bottom_right_w}" height="{bottom_h}" rx="22" fill="#ffffff" opacity="0.98" />')
    lines.append(svg_text(right_x + 20, bottom_y + 34, "505344.pdf 基本信息", 18, 700, "#102a43"))
    info_lines = [
        f"源文件大小：{fmt_mb(target_pdf.source_bytes)} | 页数：{SOURCE_PDF_PAGES} 页",
        f"源页面尺寸：{fmt_num(SOURCE_PAGE_WIDTH_PT, 2)} x {fmt_num(SOURCE_PAGE_HEIGHT_PT, 2)} pt",
        f"源页图宽度：{SOURCE_IMAGE_WIDTH_PX}px | 源有效 DPI：{fmt_num(source_dpi)}",
        f"输出页宽：{fmt_num(output_width_in, 2)} inch | 输出有效 DPI：{fmt_num(output_dpi)}",
        f"JPEG 默认质量：90 | PSNR：{fmt_num(avg_psnr)} dB | 像素差：{fmt_num(avg_abs_diff)} / 255",
        "总结：像素未放大，300 dpi 来自物理页尺寸缩小，画质为轻微有损。",
    ]
    qy = bottom_y + 88
    for idx, text in enumerate(info_lines):
        cy = qy + idx * 38
        lines.append(f'<rect x="{right_x + 20}" y="{cy - 14}" width="8" height="8" rx="2" fill="#10b981" />')
        lines.append(svg_text(right_x + 38, cy, text, 15, 400, "#334155"))

    lines.append(
        svg_text(
            52,
            1052,
            "总结：对 505344.pdf 这类单个大文件，单文件耗时基本持平；本轮优化的主要收益体现在批量吞吐、连续压测总耗时和调度效率。",
            13,
            400,
            "#cbd5e1",
        )
    )
    lines.append("</svg>")

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"generated {OUTPUT}")


if __name__ == "__main__":
    main()
