#!/usr/bin/env python
from __future__ import annotations

import argparse
import ctypes
import json
import os
import sys
import time
import zipfile
from ctypes import wintypes
from pathlib import Path


class ProcessMemoryCountersEx(ctypes.Structure):
    _fields_ = [
        ("cb", wintypes.DWORD),
        ("PageFaultCount", wintypes.DWORD),
        ("PeakWorkingSetSize", ctypes.c_size_t),
        ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t),
        ("PeakPagefileUsage", ctypes.c_size_t),
        ("PrivateUsage", ctypes.c_size_t),
    ]


GetCurrentProcess = ctypes.windll.kernel32.GetCurrentProcess
GetProcessMemoryInfo = ctypes.windll.psapi.GetProcessMemoryInfo
GetProcessMemoryInfo.argtypes = [
    wintypes.HANDLE,
    ctypes.POINTER(ProcessMemoryCountersEx),
    wintypes.DWORD,
]
GetProcessMemoryInfo.restype = wintypes.BOOL


def current_rss_mb() -> float:
    counters = ProcessMemoryCountersEx()
    counters.cb = ctypes.sizeof(ProcessMemoryCountersEx)
    ok = GetProcessMemoryInfo(GetCurrentProcess(), ctypes.byref(counters), counters.cb)
    if not ok:
        raise OSError("GetProcessMemoryInfo failed")
    return counters.WorkingSetSize / (1024 * 1024)


def default_worker_count() -> int:
    return max(1, os.cpu_count() or 1)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Stress submit_to_pdf in a single long-lived process and record RSS."
    )
    parser.add_argument(
        "--input-dir",
        type=Path,
        default=Path(r"C:\Users\PC\pros\python\tests"),
        help="Directory containing input files.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(r"C:\Users\PC\pros\python\tools\target\stress_loop_monitor_page300_bc"),
        help="Directory to write outputs and summary.",
    )
    parser.add_argument("--rounds", type=int, default=10)
    parser.add_argument("--dpi", type=int, default=300)
    parser.add_argument("--page-dpi", type=float, default=300)
    parser.add_argument(
        "--fmt",
        default="jpg",
        choices=["png", "jpg", "jpeg", "tif", "tiff"],
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=default_worker_count(),
        help="ConverterPool worker count. Defaults to the current CPU count.",
    )
    parser.add_argument(
        "--in-flight",
        type=int,
        default=None,
        help="Maximum number of submitted jobs kept in flight at once. Defaults to workers.",
    )
    parser.add_argument("--timeout-ms", type=int, default=300_000)
    parser.add_argument("--max-area", type=int, default=36_000_000)
    parser.add_argument("--max-size-mb", type=float, default=10.0)
    parser.add_argument(
        "--return-mode",
        default="path",
        choices=["path", "data_url"],
        help="submit_to_pdf return mode to stress.",
    )
    parser.add_argument(
        "--summary",
        type=Path,
        default=None,
        help="Optional summary path. Defaults to <output-dir>/summary.json.",
    )
    parser.add_argument(
        "--details",
        type=Path,
        default=None,
        help="Optional per-file detail path. Defaults to <output-dir>/details.json.",
    )
    return parser.parse_args()


def load_docs_tools(repo_root: Path):
    wheel_dir = repo_root / "target" / "wheels"
    wheels = sorted(wheel_dir.glob("docs_tools-*.whl"), key=lambda p: p.stat().st_mtime)
    if not wheels:
        raise FileNotFoundError(f"no wheel found under {wheel_dir}")

    wheel = wheels[-1]
    unpack = repo_root / "target" / f"stress_unpack_{int(time.time())}"
    unpack.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(wheel) as zf:
        zf.extractall(unpack)

    sys.path.insert(0, str(unpack.resolve()))
    import docs_tools

    return docs_tools, wheel


def estimate_data_url_pdf_bytes(result: object) -> tuple[int, str]:
    text = str(result)
    prefix, sep, payload = text.partition(",")
    if not sep or ";base64" not in prefix:
        return -1, f"data_url(chars={len(text)})"

    padding = len(payload) - len(payload.rstrip("="))
    pdf_bytes = (len(payload) * 3) // 4 - padding
    return pdf_bytes, f"data_url(chars={len(text)},pdf_bytes={pdf_bytes})"


def summarize_result(
    result: object,
    return_mode: str,
    out_pdf: Path,
) -> tuple[int, str]:
    if return_mode == "path":
        size = out_pdf.stat().st_size if out_pdf.exists() else -1
        return size, str(result)

    if return_mode == "data_url":
        return estimate_data_url_pdf_bytes(result)

    return -1, str(result)


def finalize_job(
    job: dict[str, object],
    results: list[dict[str, object] | None],
    timeout_ms: int,
) -> None:
    start = float(job["start"])
    out_pdf = Path(job["out_pdf"])
    return_mode = str(job["return_mode"])
    try:
        result = job["handle"].result(timeout_ms)
        elapsed = time.perf_counter() - start
        size, output_summary = summarize_result(result, return_mode, out_pdf)
        results[int(job["index"])] = {
            "file": str(job["src"]),
            "return_mode": return_mode,
            "status": "OK",
            "seconds": elapsed,
            "bytes": size,
            "output": output_summary,
            "error": "",
        }
    except Exception as exc:
        elapsed = time.perf_counter() - start
        results[int(job["index"])] = {
            "file": str(job["src"]),
            "return_mode": return_mode,
            "status": "FAIL",
            "seconds": elapsed,
            "bytes": -1,
            "output": "",
            "error": str(exc),
        }


def collect_completed_jobs(
    pending: list[dict[str, object]],
    results: list[dict[str, object] | None],
    timeout_ms: int,
) -> bool:
    completed_indices: list[int] = []
    for idx, job in enumerate(pending):
        if job["handle"].done():
            completed_indices.append(idx)

    if not completed_indices:
        return False

    for idx in reversed(completed_indices):
        finalize_job(pending.pop(idx), results, timeout_ms)
    return True


def main() -> int:
    args = parse_args()
    repo_root = Path(__file__).resolve().parents[1]

    if not args.input_dir.exists():
        print(f"FAIL: input dir not found: {args.input_dir}")
        return 2

    args.output_dir.mkdir(parents=True, exist_ok=True)
    outputs_dir = args.output_dir / "outputs"
    outputs_dir.mkdir(parents=True, exist_ok=True)

    docs_tools, wheel = load_docs_tools(repo_root)
    files = sorted(p for p in args.input_dir.rglob("*") if p.is_file())
    in_flight = max(1, args.in_flight or args.workers)

    print(f"INFO: wheel={wheel}")
    print(f"INFO: input_dir={args.input_dir}")
    print(f"INFO: output_dir={args.output_dir}")
    print(
        f"INFO: rounds={args.rounds} files={len(files)} workers={args.workers} "
        f"in_flight={in_flight} dpi={args.dpi} page_dpi={args.page_dpi} fmt={args.fmt} "
        f"return_mode={args.return_mode}"
    )

    total_ok = 0
    total_fail = 0
    round_seconds: list[float] = []
    rounds_data: list[dict[str, object]] = []
    details_data: list[dict[str, object]] = []
    max_self_rss_mb = current_rss_mb()
    stress_start = time.perf_counter()

    pool = docs_tools.ConverterPool(workers=args.workers)
    try:
        for round_index in range(1, args.rounds + 1):
            round_start = time.perf_counter()
            rss_before_mb = current_rss_mb()
            rss_peak_mb = rss_before_mb
            max_self_rss_mb = max(max_self_rss_mb, rss_before_mb)
            results: list[dict[str, object] | None] = [None] * len(files)

            pending: list[dict[str, object]] = []
            next_index = 0
            while next_index < len(files) or pending:
                while next_index < len(files) and len(pending) < in_flight:
                    src = files[next_index]
                    out_pdf = outputs_dir / f"{src.stem}.round{round_index:02d}.pdf"
                    output_pdf = str(out_pdf) if args.return_mode == "path" else None
                    handle = pool.submit_to_pdf(
                        str(src),
                        output_pdf,
                        apply_constraints=False,
                        dpi=args.dpi,
                        fmt=args.fmt,
                        prefix="page",
                        max_area=args.max_area,
                        max_size_mb=args.max_size_mb,
                        page_dpi=args.page_dpi,
                        return_mode=args.return_mode,
                    )
                    pending.append(
                        {
                            "index": next_index,
                            "src": src,
                            "out_pdf": out_pdf,
                            "return_mode": args.return_mode,
                            "handle": handle,
                            "start": time.perf_counter(),
                        }
                    )
                    next_index += 1

                if not collect_completed_jobs(pending, results, args.timeout_ms):
                    time.sleep(0.01)

                rss_now_mb = current_rss_mb()
                rss_peak_mb = max(rss_peak_mb, rss_now_mb)
                max_self_rss_mb = max(max_self_rss_mb, rss_now_mb)

            rows = [row for row in results if row is not None]
            ok_rows = [row for row in rows if row["status"] == "OK"]
            fail_rows = [row for row in rows if row["status"] == "FAIL"]
            round_elapsed = time.perf_counter() - round_start
            rss_after_mb = current_rss_mb()
            rss_peak_mb = max(rss_peak_mb, rss_after_mb)
            max_self_rss_mb = max(max_self_rss_mb, rss_after_mb)
            file_times = [float(row["seconds"]) for row in rows]

            round_record = {
                "round": round_index,
                "seconds": round_elapsed,
                "ok": len(ok_rows),
                "fail": len(fail_rows),
                "rss_before_mb": rss_before_mb,
                "rss_after_mb": rss_after_mb,
                "rss_peak_mb": rss_peak_mb,
                "avg_file_seconds": (sum(file_times) / len(file_times)) if file_times else 0.0,
                "max_file_seconds": max(file_times) if file_times else 0.0,
            }
            rounds_data.append(round_record)
            round_seconds.append(round_elapsed)
            total_ok += len(ok_rows)
            total_fail += len(fail_rows)
            details_data.append(
                {
                    "round": round_index,
                    "rows": rows,
                }
            )

            print(
                f"ROUND {round_index:02d}/{args.rounds}: seconds={round_elapsed:.3f} "
                f"ok={len(ok_rows)} fail={len(fail_rows)} "
                f"rss_before_mb={rss_before_mb:.3f} rss_after_mb={rss_after_mb:.3f} "
                f"rss_peak_mb={rss_peak_mb:.3f}"
            )
    finally:
        pool.close()

    summary_path = args.summary or (args.output_dir / "summary.json")
    details_path = args.details or (args.output_dir / "details.json")
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    details_path.parent.mkdir(parents=True, exist_ok=True)
    summary = {
        "wheel": str(wheel),
        "rounds": args.rounds,
        "files_per_round": len(files),
        "total_tasks": len(files) * args.rounds,
        "return_mode": args.return_mode,
        "ok": total_ok,
        "fail": total_fail,
        "total_seconds": time.perf_counter() - stress_start,
        "round_seconds": round_seconds,
        "rounds_data": rounds_data,
        "max_self_rss_mb": max_self_rss_mb,
    }
    summary_path.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    details = {
        "wheel": str(wheel),
        "input_dir": str(args.input_dir),
        "output_dir": str(args.output_dir),
        "rounds": args.rounds,
        "return_mode": args.return_mode,
        "files": [str(path) for path in files],
        "details": details_data,
    }
    details_path.write_text(
        json.dumps(details, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"SUMMARY_JSON: {summary_path}")
    print(f"DETAILS_JSON: {details_path}")
    return 0 if total_fail == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
