class SkatyError(Exception):
    """Base exception for all Skaty-related errors."""

    pass


class InvalidGameStateError(SkatyError):
    """Raised if an operation is performed in an invalid game state (e.g. playing a card before a trick starts)."""


class InvalidGameTypeError(SkatyError):
    """Raised when an invalid game type is passed as an argument (e.g. passing GameType.PASS for is_valid_game_declaration)."""


class NoHigherBidPossible(SkatyError):
    """Raised when no higher bid is possible according to the rules."""


class InvalidActionError(SkatyError):
    """Raised when an illegal action is tried (e.g. acting when not being the active player)."""


class NoCardsError(SkatyError):
    """Raised when no cards are passed where there should be some."""


class TrickNotFinishedError(InvalidGameStateError):
    """Raised when a trick with less than 3 cards is probed for a winner."""


class TrickFinishedError(InvalidGameStateError):
    """Raised when a card is added to a trick if it is finished."""
