# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project

TokenFlow — new project, Apache 2.0 licensed. No source code, build system, or tests have been added yet.
