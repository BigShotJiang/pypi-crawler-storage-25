# Verlex

**Run your code in the cloud for the price of a coffee.**

Verlex is a Python SDK that lets you execute code on the cheapest available cloud infrastructure across AWS, GCP, and Azure — all with a single function call.

## Installation

```bash
pip install verlex
```

With ML dependencies:

```bash
pip install verlex[ml]
```

## Quick Start

```python
import verlex

def train_model():
    import torch
    model = torch.nn.Linear(100, 10)
    # Your training code here...
    return {"accuracy": 0.95}

# Run it in the cloud — one line!
result = verlex.cloud(train_model, api_key="gw_your_key")
print(result)
```

## Basic Usage

### One-Liner (Simplest)

Every function works as a standalone call — just pass your `api_key`:

```python
import verlex

# Run in the cloud
result = verlex.cloud(train_model, api_key="gw_your_key")

# Analyze resources
rec = verlex.analyze(train_model, api_key="gw_your_key")

# Estimate cost
costs = verlex.estimate_cost(train_model, api_key="gw_your_key")
```

### Specifying Resources

```python
result = verlex.cloud(
    train_model,
    api_key="gw_your_key",
    gpu="A100",       # Specific GPU type
    gpu_count=2,      # Multiple GPUs
    memory="64GB",    # Memory requirement
    timeout=7200,     # 2 hour timeout
)
```

### Context Manager (Multi-step Sessions)

```python
with verlex.GateWay(api_key="gw_your_key") as gw:
    rec = gw.analyze(train_model)
    costs = gw.estimate_cost(train_model)
    result = gw.run(train_model)
```

### Async Execution

```python
with verlex.GateWay(api_key="gw_your_key") as gw:
    # Submit jobs (non-blocking)
    job1 = gw.run_async(train_model_1)
    job2 = gw.run_async(train_model_2)

    # Wait for results when needed
    result1 = job1.result()
    result2 = job2.result()
```

## Pricing Modes

Choose your price-speed tradeoff with a single `fast` flag:

| Mode | Wait Time | Best For |
|------|-----------|----------|
| **Performance** (`fast=True`) | Immediate | Time-sensitive workloads |
| **Standard** (`fast=False`) | Up to 10 min | Batch jobs, cost-sensitive |

```python
# Performance mode - immediate execution
result = verlex.cloud(my_function, api_key="gw_your_key", fast=True)

# Standard mode (default) - wait for lower prices
result = verlex.cloud(my_function, api_key="gw_your_key")
```

## Authentication

### Option 1: Direct API Key (Inline)

```python
result = verlex.cloud(my_function, api_key="gw_your_key")
```

### Option 2: Environment Variable

```bash
export VERLEX_API_KEY="gw_your_key"
```

```python
result = verlex.cloud(my_function)  # picks up VERLEX_API_KEY
```

## Automatic Cloud Offloading

Don't know which functions are heavy? Let Verlex figure it out:

```python
import verlex
verlex.overflow(fast=True)

# Your code runs normally. When CPU or memory exceeds 85%,
# functions are automatically offloaded to the cheapest cloud.
data = load_data()
result = train_model(data)   # system overloaded? → cloud
evaluate(result)             # resources free → runs locally
```

Install with: `pip install 'verlex[overflow]'`

## Agent Daemon

Monitor your system and offload heavy Python processes:

```bash
# Watch for heavy processes and offer to offload
verlex agent watch

# Auto-offload without prompting
verlex agent watch --auto

# Submit a script directly via source-code pipeline
verlex agent run train.py --gpu A100
```

Install with: `pip install 'verlex[agent]'`

## CLI

```bash
# Login
verlex login

# Run a script
verlex run train.py

# Run with specific GPU
verlex run train.py --gpu A100

# Check job status
verlex jobs

# View account info
verlex whoami
```

## Supported Cloud Providers

- **AWS** - EC2, with Spot instances (up to 90% off)
- **GCP** - Compute Engine, with Preemptible VMs (up to 91% off)
- **Azure** - VMs, with Spot instances (up to 81% off)

## Links

- **Website**: [verlex.dev](https://verlex.dev)
- **Documentation**: [verlex.dev/docs](https://verlex.dev/docs)

## Contact

- **Support**: support@verlex.dev
- **Sales**: sales@verlex.dev
- **General**: contact@verlex.dev

## License

Apache 2.0
