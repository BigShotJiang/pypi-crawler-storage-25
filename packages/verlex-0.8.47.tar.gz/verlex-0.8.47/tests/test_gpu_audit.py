"""
Tests for the GPU catalog coverage audit and admin cache-reset.

Covers the three production safeguards added on top of the
canonicalization layer:

  1. audit_catalog_coverage detects unknown SKUs, missing aliases,
     and ambiguous A100 entries.
  2. The bare-A100 fallback warns once per process when memory is missing.
  3. reset_cache() forces gpu_specs_db to re-read from Supabase.
"""

from datetime import datetime, timedelta
from unittest.mock import patch

import pytest

from verlex_server.gateway.backend import gpu_specs_db
from verlex_server.gateway.backend.gpu_specs_db import (
    audit_catalog_coverage,
    log_audit_findings,
    reset_cache,
)
from verlex_server.gateway.core import gpu_canonicalization
from verlex_server.gateway.core.gpu_canonicalization import canonicalize
from verlex_server.gateway.core.pricing import CloudProvider, PriceInfo


def _make(provider, gpu, gpu_count=1, gpu_memory_gb=None, instance_type="x"):
    return PriceInfo(
        provider=provider,
        instance_type=instance_type,
        region="us-east-1",
        cpu=8,
        memory_gb=32,
        gpu_type=gpu,
        gpu_count=gpu_count,
        gpu_memory_gb=gpu_memory_gb,
        on_demand_price=1.0,
        available=True,
    )


# ----------------------------------------------------------------------------
# audit_catalog_coverage
# ----------------------------------------------------------------------------


class TestAuditCoverage:
    def test_clean_catalog_has_no_findings(self):
        catalog = [
            _make(CloudProvider.AWS, "H100", gpu_memory_gb=80, instance_type="p5.48xlarge"),
            _make(CloudProvider.AWS, "A10G", gpu_memory_gb=24, instance_type="g5.xlarge"),
        ]
        # DB returns the seeded specs.
        with patch.object(
            gpu_specs_db, "get_specs",
            return_value={"H100": {"fp16_tflops": 989}, "A10": {"fp16_tflops": 125}},
        ), patch.object(gpu_specs_db, "get_aliases", return_value={}):
            findings = audit_catalog_coverage(catalog)
        assert findings["unknown_skus"] == []
        assert findings["ambiguous_a100"] == []
        # AWS A10G is in HARDCODED_ALIASES — should not flag.
        assert findings["missing_alias"] == []

    def test_detects_unknown_canonical_sku(self):
        # A canonical that isn't in gpu_specs at all (simulates a new GPU
        # that we forgot to seed).
        catalog = [_make(CloudProvider.AWS, "FUTURE-GPU-X", instance_type="future.xlarge")]
        with patch.object(gpu_specs_db, "get_specs", return_value={"H100": {}}), \
             patch.object(gpu_specs_db, "get_aliases", return_value={}):
            findings = audit_catalog_coverage(catalog)
        assert any(
            e["canonical"] == "FUTURE-GPU-X"
            for e in findings["unknown_skus"]
        )

    def test_detects_ambiguous_a100(self):
        catalog = [
            # No gpu_memory_gb -> ambiguous.
            _make(CloudProvider.AWS, "A100", gpu_memory_gb=None, instance_type="p4d.24xlarge"),
            # With memory -> NOT ambiguous.
            _make(CloudProvider.AWS, "A100", gpu_memory_gb=40, instance_type="p4d.24xlarge"),
        ]
        with patch.object(gpu_specs_db, "get_specs", return_value={"A100-40": {}}), \
             patch.object(gpu_specs_db, "get_aliases", return_value={}):
            findings = audit_catalog_coverage(catalog)
        ambiguous = findings["ambiguous_a100"]
        assert len(ambiguous) == 1
        assert ambiguous[0]["instance_type"] == "p4d.24xlarge"

    def test_detects_missing_alias_for_new_provider(self):
        catalog = [
            _make(CloudProvider.AWS, "WEIRD_NEW_NAME_NOT_IN_SEED", instance_type="x"),
        ]
        with patch.object(gpu_specs_db, "get_specs", return_value={}), \
             patch.object(gpu_specs_db, "get_aliases", return_value={}):
            findings = audit_catalog_coverage(catalog)
        assert any(
            e["raw_name"] == "WEIRD_NEW_NAME_NOT_IN_SEED"
            for e in findings["missing_alias"]
        )

    def test_log_audit_findings_returns_total_count(self):
        # Empty findings -> 0 issues.
        clean = {"unknown_skus": [], "ambiguous_a100": [], "missing_alias": []}
        assert log_audit_findings(clean) == 0

        dirty = {
            "unknown_skus": [{"provider": "x", "raw_name": "y", "canonical": "z", "instance_type": "i"}],
            "ambiguous_a100": [{"provider": "x", "instance_type": "i", "region": "r", "gpu_type": "A100"}],
            "missing_alias": [{"provider": "x", "raw_name": "y", "instance_type": "i"}],
        }
        # Should report 3 issues without raising.
        assert log_audit_findings(dirty) == 3

    def test_audit_dedupes_repeated_unknown(self):
        catalog = [
            _make(CloudProvider.AWS, "BOGUS", instance_type="a"),
            _make(CloudProvider.AWS, "BOGUS", instance_type="b"),
            _make(CloudProvider.AWS, "BOGUS", instance_type="c"),
        ]
        with patch.object(gpu_specs_db, "get_specs", return_value={}), \
             patch.object(gpu_specs_db, "get_aliases", return_value={}):
            findings = audit_catalog_coverage(catalog)
        # Same (provider, canonical) appears once even though raw appears 3x.
        assert len([e for e in findings["unknown_skus"] if e["canonical"] == "BOGUS"]) == 1


# ----------------------------------------------------------------------------
# Bare A100 fallback warning
# ----------------------------------------------------------------------------


class TestA100FallbackWarning:
    def _reset_throttle(self):
        gpu_canonicalization._warned_ambiguous_a100 = False

    def test_unknown_provider_a100_fallback_logs_warning_once(self, caplog):
        # A new provider with no alias seed for "A100" + no memory hint
        # is the genuine ambiguous case. We warn once per process so the
        # operator sees the silent default and can fix the alias seed.
        self._reset_throttle()
        with patch.object(
            gpu_canonicalization, "_try_db_aliases", return_value={}
        ), caplog.at_level("WARNING", logger="verlex_server.gateway.core.gpu_canonicalization"):
            r1 = canonicalize("brand-new-cloud", "A100")  # no memory, no alias -> warn
            r2 = canonicalize("brand-new-cloud", "A100")  # second call -> throttled
        assert r1 == "A100-40"
        assert r2 == "A100-40"
        warnings = [r for r in caplog.records if "bare 'A100'" in r.getMessage()]
        assert len(warnings) == 1, f"expected exactly 1 warning, got {len(warnings)}"

    def test_a100_with_memory_hint_disambiguates_silently(self, caplog):
        self._reset_throttle()
        with patch.object(
            gpu_canonicalization, "_try_db_aliases", return_value={}
        ), caplog.at_level("WARNING", logger="verlex_server.gateway.core.gpu_canonicalization"):
            r = canonicalize("brand-new-cloud", "A100", gpu_memory_gb=80)
        assert r == "A100-80"
        warnings = [r for r in caplog.records if "bare 'A100'" in r.getMessage()]
        assert len(warnings) == 0

    def test_aws_a100_uses_alias_no_warning(self, caplog):
        # Known provider with seeded alias short-circuits to the alias value;
        # this is documented, deterministic behavior — no warning expected.
        self._reset_throttle()
        with caplog.at_level("WARNING", logger="verlex_server.gateway.core.gpu_canonicalization"):
            r = canonicalize("aws", "A100")
        assert r == "A100-40"
        warnings = [r for r in caplog.records if "bare 'A100'" in r.getMessage()]
        assert len(warnings) == 0

    def test_throttle_is_a_single_bool_not_unbounded_set(self):
        # Memory-leak guard: the throttle must be a bool, not a growing
        # collection, so a noisy catalog can't bloat memory.
        assert isinstance(gpu_canonicalization._warned_ambiguous_a100, bool)


# ----------------------------------------------------------------------------
# compute_score input validation (#5)
# ----------------------------------------------------------------------------


class TestComputeScoreSafety:
    def test_handles_none_inputs(self):
        from verlex_server.gateway.core.gpu_performance import compute_score
        # Should not raise even with None / NaN / negatives.
        assert compute_score(None, None, None, None) >= 0
        assert compute_score("H100", None, None, None) > 0  # GPU still scores

    def test_negative_gpu_count_treated_as_one(self):
        from verlex_server.gateway.core.gpu_performance import (
            GPU_TFLOPS_FALLBACK,
            compute_score,
        )
        with patch(
            "verlex_server.gateway.core.gpu_performance._try_db_specs",
            return_value={},
        ):
            score = compute_score("H100", -3, 8, 32)
        # Negative count clamps to 1, not -3 (which would flip the sort).
        assert score == GPU_TFLOPS_FALLBACK["H100"]

    def test_nan_does_not_break_sort(self):
        from verlex_server.gateway.core.gpu_performance import compute_score
        # NaN coerced to 0; result is finite so list.sort doesn't raise.
        scores = [
            compute_score(None, 1, float("nan"), float("nan")),
            compute_score(None, 1, 4, 8),
            compute_score(None, 1, float("inf"), 0),
        ]
        assert all(s >= 0 for s in scores)
        sorted(scores)  # must not raise

    def test_string_gpu_count_handled(self):
        from verlex_server.gateway.core.gpu_performance import compute_score
        # Coerces "8" -> 8.
        assert compute_score("H100", "8", 16, 64) > 0

    def test_garbage_gpu_count_falls_back(self):
        from verlex_server.gateway.core.gpu_performance import compute_score
        # Unparseable -> defaults to 1, not a crash.
        assert compute_score("H100", "not-a-number", 16, 64) > 0


# ----------------------------------------------------------------------------
# Cross-pod cache propagation (#4)
# ----------------------------------------------------------------------------


class TestCrossPodCachePropagation:
    def test_remote_epoch_newer_invalidates_cache(self):
        from datetime import timedelta
        gpu_specs_db.reset_cache()

        # First load: cache populated, remote epoch matches load time.
        with patch.object(
            gpu_specs_db, "_load_specs_from_db",
            return_value={"H100": {"fp16_tflops": 989}},
        ) as load_mock, patch.object(
            gpu_specs_db, "_poll_remote_epoch",
            return_value=datetime.utcnow() - timedelta(minutes=5),
        ):
            specs1 = gpu_specs_db.get_specs()
            assert "H100" in specs1
            assert load_mock.call_count == 1

        # Second call with REMOTE epoch newer than load time -> reload.
        # We have to re-stub the load with the bumped value.
        future = datetime.utcnow() + timedelta(seconds=1)
        with patch.object(
            gpu_specs_db, "_load_specs_from_db",
            return_value={"H100": {"fp16_tflops": 1100}},
        ) as load_mock, patch.object(
            gpu_specs_db, "_poll_remote_epoch", return_value=future,
        ):
            specs2 = gpu_specs_db.get_specs()
            assert load_mock.call_count == 1, (
                "expected reload because remote epoch advanced"
            )
            assert specs2["H100"]["fp16_tflops"] == 1100

        gpu_specs_db.reset_cache()

    def test_remote_epoch_unchanged_uses_cache(self):
        from datetime import timedelta
        gpu_specs_db.reset_cache()
        old_epoch = datetime.utcnow() - timedelta(hours=2)

        with patch.object(
            gpu_specs_db, "_load_specs_from_db",
            return_value={"H100": {"fp16_tflops": 989}},
        ) as load_mock, patch.object(
            gpu_specs_db, "_poll_remote_epoch", return_value=old_epoch,
        ):
            gpu_specs_db.get_specs()
            gpu_specs_db.get_specs()
            gpu_specs_db.get_specs()
            # Stale remote -> all subsequent reads are cache hits.
            assert load_mock.call_count == 1

        gpu_specs_db.reset_cache()

    def test_epoch_poll_failure_does_not_invalidate(self):
        gpu_specs_db.reset_cache()
        with patch.object(
            gpu_specs_db, "_load_specs_from_db",
            return_value={"H100": {"fp16_tflops": 989}},
        ) as load_mock, patch.object(
            gpu_specs_db, "_poll_remote_epoch", return_value=None,
        ):
            gpu_specs_db.get_specs()
            gpu_specs_db.get_specs()
            # Poll returning None means "can't tell" -> trust TTL,
            # don't burn an extra DB load.
            assert load_mock.call_count == 1

        gpu_specs_db.reset_cache()


# ----------------------------------------------------------------------------
# reset_cache
# ----------------------------------------------------------------------------


class TestCacheReset:
    def test_reset_forces_db_reload(self):
        gpu_specs_db.reset_cache()

        # First load returns some specs.
        with patch.object(
            gpu_specs_db, "_load_specs_from_db",
            return_value={"H100": {"fp16_tflops": 989}},
        ) as m:
            specs1 = gpu_specs_db.get_specs()
            assert "H100" in specs1
            assert m.call_count == 1
            # Second call uses cache.
            gpu_specs_db.get_specs()
            assert m.call_count == 1

        # After reset, the next read hits the DB again.
        gpu_specs_db.reset_cache()
        with patch.object(
            gpu_specs_db, "_load_specs_from_db",
            return_value={"H100": {"fp16_tflops": 1100}},  # pretend value bumped
        ) as m:
            specs2 = gpu_specs_db.get_specs()
            assert m.call_count == 1
            assert specs2["H100"]["fp16_tflops"] == 1100

        gpu_specs_db.reset_cache()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
