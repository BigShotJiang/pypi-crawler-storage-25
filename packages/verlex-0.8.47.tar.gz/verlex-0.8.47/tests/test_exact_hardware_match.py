"""
Tests for the exact-hardware-match feature.

When a user names a specific GPU SKU (e.g. "H100"), it must be a hard
requirement. If no provider has it available, the system must surface the
closest matches:
  - Standard tier  -> top 5 by cheapest effective price (no price shown)
  - Performance tier -> top 5 by pure compute strength (TFLOPs * count)
"""

from unittest.mock import patch

import pytest

from verlex_server.gateway.core.gpu_performance import (
    GPU_TFLOPS_FALLBACK,
    compute_score,
    get_gpu_tflops,
)
from verlex_server.gateway.core.pricing import (
    CloudProvider,
    PriceComparison,
    PriceInfo,
)
from verlex_server.gateway.core.selection import (
    ExactHardwareUnavailableError,
    HardwareAlternative,
    PerformanceSelector,
    SelectionMode,
    StandardSelector,
    _exact_match_available,
    find_closest_matches,
)


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------


def make_price(
    provider: CloudProvider,
    instance_type: str,
    region: str,
    cpu: int,
    memory_gb: float,
    gpu_type: str | None,
    gpu_count: int,
    on_demand: float,
    spot: float | None = None,
    available: bool = True,
) -> PriceInfo:
    return PriceInfo(
        provider=provider,
        instance_type=instance_type,
        region=region,
        cpu=cpu,
        memory_gb=memory_gb,
        gpu_type=gpu_type,
        gpu_count=gpu_count,
        on_demand_price=on_demand,
        spot_price=spot,
        available=available,
        spot_available=spot is not None,
    )


CATALOG_NO_H100 = [
    make_price(CloudProvider.AWS, "g4dn.xlarge", "us-east-1", 4, 16, "T4", 1, 0.526, 0.158),
    make_price(CloudProvider.GCP, "n1-standard-4-t4", "us-central1", 4, 15, "T4", 1, 0.595, 0.179),
    make_price(CloudProvider.AWS, "g5.xlarge", "us-east-1", 4, 16, "A10G", 1, 1.006, 0.302),
    make_price(CloudProvider.AWS, "p3.2xlarge", "us-east-1", 8, 61, "V100", 1, 3.06, 0.918),
    make_price(CloudProvider.AWS, "p4d.24xlarge", "us-east-1", 96, 1152, "A100", 8, 32.77, 9.83),
    make_price(CloudProvider.GCP, "a2-ultragpu-8g", "us-central1", 96, 1360, "A100", 8, 28.50, 8.55),
    make_price(CloudProvider.AZURE, "Standard_NC24ads_A100_v4", "eastus", 24, 220, "A100", 1, 3.67, 1.10),
    make_price(CloudProvider.AWS, "g6e.xlarge", "us-east-1", 4, 32, "L40S", 1, 1.86, 0.56),
]

CATALOG_WITH_H100 = CATALOG_NO_H100 + [
    make_price(CloudProvider.AWS, "p5.48xlarge", "us-east-1", 192, 2048, "H100", 8, 98.32, None),
    make_price(CloudProvider.GCP, "a3-highgpu-8g", "us-central1", 208, 1872, "H100", 8, 88.49, None),
]


def fake_compare_prices(catalog):
    """Build a fake compare_prices() that returns the given catalog filtered."""

    def _impl(
        cpu=2,
        memory_gb=4,
        gpu_type=None,
        gpu_count=1,
        prefer_spot=True,
        excluded_providers=None,
        preferred_regions=None,
    ):
        excluded = set(excluded_providers or [])
        opts = [
            p for p in catalog
            if p.provider.value not in excluded
            and p.cpu >= cpu
            and p.memory_gb >= memory_gb
            and (gpu_type is None or (p.gpu_type and p.gpu_type.upper() == gpu_type.upper()))
            and (gpu_count <= 1 or p.gpu_count >= gpu_count)
        ]
        opts.sort(key=lambda p: p.effective_price(prefer_spot))
        return PriceComparison(
            options=opts,
            cheapest=min(opts, key=lambda p: p.on_demand_price, default=None),
            cheapest_spot=min(
                [p for p in opts if p.spot_price],
                key=lambda p: p.spot_price,
                default=None,
            ),
            cheapest_available_now=min(
                [p for p in opts if p.available],
                key=lambda p: p.effective_price(prefer_spot),
                default=None,
            ),
        )

    return _impl


# ----------------------------------------------------------------------------
# gpu_performance
# ----------------------------------------------------------------------------


class TestGpuPerformance:
    def test_known_skus_have_tflops(self):
        assert get_gpu_tflops("H100") == GPU_TFLOPS_FALLBACK["H100"]
        # Bare "A100" canonicalizes to "A100-40" by default.
        assert get_gpu_tflops("A100") == GPU_TFLOPS_FALLBACK["A100-40"]
        assert get_gpu_tflops("T4") == GPU_TFLOPS_FALLBACK["T4"]

    def test_lookup_is_case_insensitive(self):
        assert get_gpu_tflops("h100") == get_gpu_tflops("H100")
        assert get_gpu_tflops("  a100 ") == get_gpu_tflops("A100")

    def test_variant_collapses_to_base(self):
        # "A100-80GB" canonicalizes to "A100-80".
        assert get_gpu_tflops("A100-80GB") == GPU_TFLOPS_FALLBACK["A100-80"]

    def test_unknown_returns_zero(self):
        assert get_gpu_tflops("BOGUS_GPU") == 0.0
        assert get_gpu_tflops(None) == 0.0
        assert get_gpu_tflops("") == 0.0

    def test_compute_score_orders_gpus_correctly(self):
        h100 = compute_score("H100", 1, 8, 32)
        a100 = compute_score("A100", 1, 8, 32)
        t4 = compute_score("T4", 1, 8, 32)
        assert h100 > a100 > t4

    def test_compute_score_scales_with_count(self):
        single = compute_score("A100", 1, 8, 32)
        eight = compute_score("A100", 8, 8, 32)
        assert eight == pytest.approx(single * 8)

    def test_cpu_only_skus_get_nonzero_score(self):
        assert compute_score(None, 0, 16, 64) > 0


# ----------------------------------------------------------------------------
# _exact_match_available
# ----------------------------------------------------------------------------


class TestExactMatchAvailable:
    def test_returns_only_exact_gpu(self):
        result = _exact_match_available(CATALOG_WITH_H100, "H100", 8)
        assert len(result) == 2
        assert all(p.gpu_type == "H100" for p in result)

    def test_empty_when_gpu_missing(self):
        assert _exact_match_available(CATALOG_NO_H100, "H100", 1) == []

    def test_filters_by_count(self):
        # Only single-A100 SKU is the Azure NC24ads, all others are 8x.
        result = _exact_match_available(CATALOG_NO_H100, "A100", 8)
        assert len(result) == 2
        assert all(p.gpu_count >= 8 for p in result)

    def test_no_gpu_request_returns_all_available(self):
        result = _exact_match_available(CATALOG_NO_H100, None, 0)
        assert len(result) == len(CATALOG_NO_H100)

    def test_unavailable_skus_excluded(self):
        catalog = CATALOG_WITH_H100[:]
        catalog[-1] = make_price(
            CloudProvider.GCP, "a3-highgpu-8g", "us-central1",
            208, 1872, "H100", 8, 88.49, None, available=False,
        )
        result = _exact_match_available(catalog, "H100", 8)
        assert len(result) == 1
        assert result[0].provider == CloudProvider.AWS

    def test_case_insensitive_gpu_match(self):
        result = _exact_match_available(CATALOG_WITH_H100, "h100", 8)
        assert len(result) == 2


# ----------------------------------------------------------------------------
# find_closest_matches
# ----------------------------------------------------------------------------


class TestFindClosestMatches:
    def test_standard_tier_ranks_by_cheapest(self):
        with patch(
            "verlex_server.gateway.core.selection.compare_prices",
            fake_compare_prices(CATALOG_NO_H100),
        ):
            alts = find_closest_matches(
                cpu=1, memory_gb=1,
                requested_gpu="H100", requested_gpu_count=8,
                tier=SelectionMode.STANDARD, limit=5,
            )

        # Standard tier filters out tier-weaker GPUs (per-GPU TFLOPs
        # below 0.3x H100), then ranks the survivors by cheapest spot
        # price. T4 / A10G / V100 are tier-weaker than H100 and must
        # NOT appear; A100 / L40S do qualify.
        assert all(a.gpu_type not in ("T4", "A10G", "V100") for a in alts)
        assert all(a.gpu_type in ("A100", "L40S") for a in alts)
        # Cheapest qualifying spot price in the test catalog is L40S
        # 1x at $0.56 (A100 1x Azure is $1.10, A100 8x is $8.55+).
        assert alts[0].gpu_type == "L40S"
        assert all(a.gpu_type != "H100" for a in alts)

    def test_performance_tier_ranks_by_compute(self):
        with patch(
            "verlex_server.gateway.core.selection.compare_prices",
            fake_compare_prices(CATALOG_NO_H100),
        ):
            alts = find_closest_matches(
                cpu=1, memory_gb=1,
                requested_gpu="H100", requested_gpu_count=8,
                tier=SelectionMode.PERFORMANCE, limit=5,
            )

        assert len(alts) >= 1
        # Top of the list must be the strongest available: 8x A100
        assert alts[0].gpu_type == "A100"
        assert alts[0].gpu_count == 8

    def test_performance_strictly_orders_by_compute_score(self):
        with patch(
            "verlex_server.gateway.core.selection.compare_prices",
            fake_compare_prices(CATALOG_NO_H100),
        ):
            alts = find_closest_matches(
                cpu=1, memory_gb=1,
                requested_gpu="H100", requested_gpu_count=8,
                tier=SelectionMode.PERFORMANCE, limit=10,
            )

        scores = [
            compute_score(a.gpu_type, a.gpu_count, a.cpu, a.memory_gb) for a in alts
        ]
        assert scores == sorted(scores, reverse=True), (
            f"alternatives not sorted by descending compute score: {scores}"
        )

    def test_excludes_requested_gpu_from_alternatives(self):
        with patch(
            "verlex_server.gateway.core.selection.compare_prices",
            fake_compare_prices(CATALOG_WITH_H100),
        ):
            alts = find_closest_matches(
                cpu=1, memory_gb=1,
                requested_gpu="H100", requested_gpu_count=8,
                tier=SelectionMode.PERFORMANCE, limit=10,
            )
        # Even though catalog contains H100, it shouldn't appear as an "alternative"
        assert all(a.gpu_type != "H100" for a in alts)

    def test_limit_respected(self):
        with patch(
            "verlex_server.gateway.core.selection.compare_prices",
            fake_compare_prices(CATALOG_NO_H100),
        ):
            alts = find_closest_matches(
                cpu=1, memory_gb=1,
                requested_gpu="H100", requested_gpu_count=8,
                tier=SelectionMode.STANDARD, limit=3,
            )
        assert len(alts) == 3

    def test_dedupes_by_provider_region_gpu(self):
        # Two SKUs with same (provider, region, gpu, count) — should appear once.
        catalog = [
            make_price(CloudProvider.AWS, "p4d.24xlarge", "us-east-1", 96, 1152, "A100", 8, 32.77, 9.83),
            make_price(CloudProvider.AWS, "p4de.24xlarge", "us-east-1", 96, 1152, "A100", 8, 40.96, 12.29),
        ]
        with patch(
            "verlex_server.gateway.core.selection.compare_prices",
            fake_compare_prices(catalog),
        ):
            alts = find_closest_matches(
                cpu=1, memory_gb=1,
                requested_gpu="H100", requested_gpu_count=8,
                tier=SelectionMode.STANDARD, limit=5,
            )
        assert len(alts) == 1


# ----------------------------------------------------------------------------
# Selectors raise ExactHardwareUnavailableError
# ----------------------------------------------------------------------------


class TestSelectorRaises:
    def test_performance_selector_raises_when_h100_missing(self):
        with patch(
            "verlex_server.gateway.core.selection.compare_prices",
            fake_compare_prices(CATALOG_NO_H100),
        ):
            with pytest.raises(ExactHardwareUnavailableError) as excinfo:
                PerformanceSelector().select(
                    cpu=8, memory_gb=32,
                    gpu_type="H100", gpu_count=8,
                    estimated_duration_minutes=60,
                    config={},
                )

        err = excinfo.value
        assert err.requested_gpu == "H100"
        assert err.requested_gpu_count == 8
        assert err.tier == SelectionMode.PERFORMANCE
        assert len(err.alternatives) >= 1
        # Performance tier => strongest GPU first => 8x A100
        assert err.alternatives[0].gpu_type == "A100"
        assert err.alternatives[0].gpu_count == 8

    def test_standard_selector_raises_when_h100_missing(self):
        with patch(
            "verlex_server.gateway.core.selection.compare_prices",
            fake_compare_prices(CATALOG_NO_H100),
        ):
            with pytest.raises(ExactHardwareUnavailableError) as excinfo:
                StandardSelector().select(
                    cpu=1, memory_gb=4,
                    gpu_type="H100", gpu_count=8,
                    estimated_duration_minutes=60,
                    config={},
                )

        err = excinfo.value
        assert err.tier == SelectionMode.STANDARD
        # Standard tier => cheapest among tier-similar substitutes only.
        # T4 (per-GPU 65 TFLOPs vs H100's 989) is tier-weaker and is
        # excluded; cheapest qualifying spot price is L40S at $0.56/hr.
        assert err.alternatives[0].gpu_type == "L40S"
        assert all(
            a.gpu_type not in ("T4", "A10G", "V100")
            for a in err.alternatives
        )

    def test_performance_selector_succeeds_when_h100_available(self):
        with patch(
            "verlex_server.gateway.core.selection.compare_prices",
            fake_compare_prices(CATALOG_WITH_H100),
        ):
            selection = PerformanceSelector().select(
                cpu=8, memory_gb=32,
                gpu_type="H100", gpu_count=8,
                estimated_duration_minutes=60,
                config={"prefer_spot": False},
            )

        assert selection.price_info.gpu_type == "H100"
        assert selection.price_info.gpu_count == 8
        assert selection.mode == SelectionMode.PERFORMANCE

    def test_no_gpu_request_does_not_trigger_strict_check(self):
        # User didn't name a GPU — selectors should pick a CPU instance fine.
        cpu_only_catalog = [
            make_price(CloudProvider.AWS, "m5.large", "us-east-1", 2, 8, None, 0, 0.096, 0.029),
        ]
        with patch(
            "verlex_server.gateway.core.selection.compare_prices",
            fake_compare_prices(cpu_only_catalog),
        ):
            selection = PerformanceSelector().select(
                cpu=2, memory_gb=4,
                gpu_type=None, gpu_count=0,
                estimated_duration_minutes=60,
                config={},
            )
        assert selection.price_info.gpu_type is None


# ----------------------------------------------------------------------------
# Error message formatting
# ----------------------------------------------------------------------------


class TestErrorMessage:
    def test_message_contains_requested_hardware(self):
        err = ExactHardwareUnavailableError(
            requested_gpu="H100",
            requested_gpu_count=8,
            requested_cpu=32,
            requested_memory_gb=256.0,
            alternatives=[],
            tier=SelectionMode.PERFORMANCE,
        )
        msg = err.format_message()
        assert "8x H100" in msg
        assert "not available" in msg.lower()
        assert "closest matches" in msg.lower()

    def test_message_lists_provider_and_region_no_price(self):
        alts = [
            HardwareAlternative("aws", "us-east-1", "p4d.24xlarge", "A100", 8, 96, 1152.0),
            HardwareAlternative("gcp", "us-central1", "a2-ultragpu-8g", "A100", 8, 96, 1360.0),
        ]
        err = ExactHardwareUnavailableError(
            requested_gpu="H100",
            requested_gpu_count=8,
            requested_cpu=8,
            requested_memory_gb=32.0,
            alternatives=alts,
            tier=SelectionMode.PERFORMANCE,
        )
        msg = err.format_message()
        assert "AWS / us-east-1" in msg
        assert "GCP / us-central1" in msg
        # No prices ANYWHERE
        assert "$" not in msg
        assert "/hr" not in msg
        assert "price" not in msg.lower()

    def test_to_dict_payload_shape(self):
        alts = [
            HardwareAlternative("aws", "us-east-1", "p4d.24xlarge", "A100", 8, 96, 1152.0),
        ]
        err = ExactHardwareUnavailableError(
            requested_gpu="H100",
            requested_gpu_count=8,
            requested_cpu=8,
            requested_memory_gb=32.0,
            alternatives=alts,
            tier=SelectionMode.STANDARD,
        )
        d = err.to_dict()
        assert d["error"] == "exact_hardware_unavailable"
        assert d["requested"]["gpu_type"] == "H100"
        assert d["requested"]["gpu_count"] == 8
        assert d["tier"] == "S"
        assert len(d["alternatives"]) == 1
        assert d["alternatives"][0]["provider"] == "aws"

    def test_no_alternatives_message(self):
        err = ExactHardwareUnavailableError(
            requested_gpu="H100",
            requested_gpu_count=8,
            requested_cpu=8,
            requested_memory_gb=32.0,
            alternatives=[],
            tier=SelectionMode.PERFORMANCE,
        )
        msg = err.format_message()
        assert "no alternatives" in msg.lower()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
