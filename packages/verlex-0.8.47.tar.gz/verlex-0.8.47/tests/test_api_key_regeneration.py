"""
Tests for API key regeneration feature.

Verifies that:
1. regenerate_api_key revokes all existing keys
2. regenerate_api_key creates a new key
3. The operation is atomic (old keys stop working, new key works)
"""


import pytest


class TestAPIKeyRegenerationMethod:
    """Test that the regeneration methods exist and have correct signatures."""

    def test_regenerate_api_key_method_exists(self):
        """Verify the regenerate_api_key method exists on APIKeyManager."""
        from verlex_server.gateway.backend.clerk_auth import APIKeyManager
        assert hasattr(APIKeyManager, 'regenerate_api_key')

    def test_revoke_all_user_keys_method_exists(self):
        """Verify the revoke_all_user_keys method exists on APIKeyManager."""
        from verlex_server.gateway.backend.clerk_auth import APIKeyManager
        assert hasattr(APIKeyManager, 'revoke_all_user_keys')

    def test_regenerate_api_key_is_async(self):
        """Verify regenerate_api_key is an async method."""
        import asyncio

        from verlex_server.gateway.backend.clerk_auth import APIKeyManager
        method = APIKeyManager.regenerate_api_key
        assert asyncio.iscoroutinefunction(method)

    def test_revoke_all_user_keys_is_async(self):
        """Verify revoke_all_user_keys is an async method."""
        import asyncio

        from verlex_server.gateway.backend.clerk_auth import APIKeyManager
        method = APIKeyManager.revoke_all_user_keys
        assert asyncio.iscoroutinefunction(method)


class TestRegenerateAPIEndpoint:
    """Test the /v1/auth/keys/regenerate endpoint."""

    @pytest.mark.asyncio
    async def test_regenerate_endpoint_exists(self):
        """Verify the regenerate endpoint is registered."""
        from verlex_server.gateway.backend.api import create_app
        app = create_app()

        routes = [r.path for r in app.routes if hasattr(r, 'path')]
        assert "/v1/auth/keys/regenerate" in routes

    @pytest.mark.asyncio
    async def test_regenerate_endpoint_is_post(self):
        """Verify the regenerate endpoint uses POST method."""
        from verlex_server.gateway.backend.api import create_app
        app = create_app()

        for route in app.routes:
            if hasattr(route, 'path') and route.path == "/v1/auth/keys/regenerate":
                assert "POST" in route.methods
                break


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
