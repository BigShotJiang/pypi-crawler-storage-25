"""
Tests for the GPU canonicalization + Supabase-backed specs layer.

Verifies that:
  - Provider raw names (AWS "A10G", GCP "nvidia-h100-80gb", Azure "H100_v5",
    Lambda/RunPod/CoreWeave/Vast forms) all resolve to the same canonical name.
  - User-typed names (no provider) resolve correctly.
  - A100-40 vs A100-80 disambiguation by gpu_memory_gb works.
  - get_gpu_tflops prefers Supabase data when available, falls back to the
    hardcoded table when Supabase returns nothing.
  - The strict-match check in selection.py works across naming variants.
"""

from unittest.mock import patch

import pytest

from verlex_server.gateway.core.gpu_canonicalization import (
    CANONICAL_NAMES,
    HARDCODED_ALIASES,
    canonicalize,
    is_canonical,
)
from verlex_server.gateway.core.gpu_performance import (
    GPU_TFLOPS_FALLBACK,
    compute_score,
    get_gpu_tflops,
)
from verlex_server.gateway.core.pricing import CloudProvider, PriceInfo
from verlex_server.gateway.core.selection import _exact_match_available


# ----------------------------------------------------------------------------
# canonicalize()
# ----------------------------------------------------------------------------


class TestCanonicalize:
    def test_h100_resolves_across_providers(self):
        assert canonicalize("aws", "H100") == "H100"
        assert canonicalize("gcp", "nvidia-h100-80gb") == "H100"
        assert canonicalize("gcp", "NVIDIA_H100_80GB") == "H100"
        assert canonicalize("azure", "H100_v5") == "H100"
        assert canonicalize("lambda", "gpu_8x_h100_80gb_sxm5") == "H100"
        assert canonicalize("runpod", "NVIDIA H100 80GB HBM3") == "H100"
        assert canonicalize("coreweave", "h100_80gb_sxm5") == "H100"
        assert canonicalize("vast", "H100 SXM") == "H100"

    def test_a10_aws_variant_resolves_correctly(self):
        # AWS calls A10 "A10G" — must NOT be confused with "A10".
        assert canonicalize("aws", "A10G") == "A10"
        assert canonicalize("azure", "A10") == "A10"

    def test_a100_memory_variants(self):
        # AWS: p4d (40GB) and p4de (80GB) both report "A100" raw.
        # Without memory hint, default to 40GB (the older base SKU).
        assert canonicalize("aws", "A100") == "A100-40"
        # Explicit 80GB string -> A100-80.
        assert canonicalize("aws", "A100-80GB") == "A100-80"
        # GCP names are explicit.
        assert canonicalize("gcp", "nvidia-tesla-a100") == "A100-40"
        assert canonicalize("gcp", "nvidia-a100-80gb") == "A100-80"

    def test_a100_disambiguation_by_memory(self):
        # When user types just "A100" and memory hint is provided.
        assert canonicalize(None, "A100", gpu_memory_gb=40) == "A100-40"
        assert canonicalize(None, "A100", gpu_memory_gb=80) == "A100-80"
        # 60GB threshold — anything >=60 is treated as 80GB variant.
        assert canonicalize(None, "A100", gpu_memory_gb=60) == "A100-80"
        assert canonicalize(None, "A100", gpu_memory_gb=39) == "A100-40"

    def test_user_input_no_provider_searches_all(self):
        # User types provider-specific names without specifying a provider.
        assert canonicalize(None, "A10G") == "A10"
        assert canonicalize(None, "nvidia-h100-80gb") == "H100"
        assert canonicalize(None, "h100_80gb_sxm5") == "H100"

    def test_user_typed_canonical_passes_through(self):
        for name in CANONICAL_NAMES:
            assert canonicalize(None, name) == name
            assert canonicalize(None, name.lower()) == name

    def test_case_and_whitespace_insensitive(self):
        assert canonicalize("aws", "h100") == "H100"
        assert canonicalize("AWS", "H100") == "H100"
        assert canonicalize("gcp", "  nvidia-h100-80gb  ") == "H100"

    def test_compact_form_a100_80gb(self):
        # Common user-typed forms.
        assert canonicalize(None, "A100-80GB") == "A100-80"
        assert canonicalize(None, "a100 80gb") == "A100-80"

    def test_unknown_returns_uppercase_raw(self):
        # Don't crash — return the upper form so callers can still display it.
        assert canonicalize("aws", "FUTURE_GPU_X") == "FUTURE_GPU_X"

    def test_empty_returns_none(self):
        assert canonicalize("aws", "") is None
        assert canonicalize("aws", None) is None

    def test_is_canonical(self):
        assert is_canonical("H100")
        assert is_canonical("h100")
        assert is_canonical("A100-80")
        assert not is_canonical("A10G")  # provider raw form, not canonical
        assert not is_canonical("nvidia-h100-80gb")
        assert not is_canonical(None)
        assert not is_canonical("")

    def test_db_aliases_override_hardcoded(self):
        # If a future migration changes a mapping, the DB takes precedence.
        fake_db_aliases = {
            ("aws", "A10G"): "A10-CUSTOM",  # pretend DB renames A10
        }
        with patch(
            "verlex_server.gateway.core.gpu_canonicalization._try_db_aliases",
            return_value=fake_db_aliases,
        ):
            assert canonicalize("aws", "A10G") == "A10-CUSTOM"

    def test_hardcoded_used_when_db_empty(self):
        with patch(
            "verlex_server.gateway.core.gpu_canonicalization._try_db_aliases",
            return_value={},
        ):
            assert canonicalize("aws", "A10G") == "A10"
            assert canonicalize("gcp", "nvidia-h100-80gb") == "H100"


# ----------------------------------------------------------------------------
# get_gpu_tflops with Supabase fallback
# ----------------------------------------------------------------------------


class TestGpuTflopsSupabase:
    def test_returns_db_value_when_present(self):
        fake_specs = {
            "H100": {"fp16_tflops": 1100.0},  # pretend DB has a refreshed number
        }
        with patch(
            "verlex_server.gateway.core.gpu_performance._try_db_specs",
            return_value=fake_specs,
        ):
            assert get_gpu_tflops("H100") == 1100.0

    def test_falls_back_to_hardcoded_when_db_empty(self):
        with patch(
            "verlex_server.gateway.core.gpu_performance._try_db_specs",
            return_value={},
        ):
            assert get_gpu_tflops("H100") == GPU_TFLOPS_FALLBACK["H100"]

    def test_falls_back_when_db_missing_specific_sku(self):
        # DB has some specs but not the one we want.
        fake_specs = {"OTHER_SKU": {"fp16_tflops": 50.0}}
        with patch(
            "verlex_server.gateway.core.gpu_performance._try_db_specs",
            return_value=fake_specs,
        ):
            assert get_gpu_tflops("A100-80") == GPU_TFLOPS_FALLBACK["A100-80"]

    def test_provider_raw_name_resolves_to_correct_tflops(self):
        # AWS calls A10 "A10G" — TFLOPs lookup must canonicalize first.
        with patch(
            "verlex_server.gateway.core.gpu_performance._try_db_specs",
            return_value={},
        ):
            assert get_gpu_tflops("A10G", provider="aws") == GPU_TFLOPS_FALLBACK["A10"]

    def test_gcp_long_name_resolves(self):
        with patch(
            "verlex_server.gateway.core.gpu_performance._try_db_specs",
            return_value={},
        ):
            assert get_gpu_tflops("nvidia-h100-80gb", provider="gcp") == GPU_TFLOPS_FALLBACK["H100"]

    def test_unknown_returns_zero(self):
        with patch(
            "verlex_server.gateway.core.gpu_performance._try_db_specs",
            return_value={},
        ):
            assert get_gpu_tflops("BOGUS_GPU_3000") == 0.0

    def test_compute_score_uses_canonicalized_lookup(self):
        with patch(
            "verlex_server.gateway.core.gpu_performance._try_db_specs",
            return_value={},
        ):
            # 8x H100 named per provider — all should produce identical scores.
            aws = compute_score("H100", 8, 96, 1024, provider="aws")
            gcp = compute_score("nvidia-h100-80gb", 8, 96, 1024, provider="gcp")
            azure = compute_score("H100_v5", 8, 96, 1024, provider="azure")
        assert aws == gcp == azure
        assert aws == GPU_TFLOPS_FALLBACK["H100"] * 8


# ----------------------------------------------------------------------------
# Strict-match across provider naming variants
# ----------------------------------------------------------------------------


def _make(provider, gpu, gpu_count, gpu_memory_gb=80):
    """Helper — builds a PriceInfo with the provider's raw GPU name."""
    return PriceInfo(
        provider=provider,
        instance_type=f"{gpu}-instance",
        region="us-east-1",
        cpu=8,
        memory_gb=32,
        gpu_type=gpu,  # NOT canonicalized at construction (simulates legacy data)
        gpu_count=gpu_count,
        gpu_memory_gb=gpu_memory_gb,
        on_demand_price=1.0,
        available=True,
    )


class TestStrictMatchCrossProvider:
    def test_h100_request_matches_all_provider_naming(self):
        # User asks for "H100" — must match every provider naming variant.
        catalog = [
            _make(CloudProvider.AWS, "H100", 8),
            _make(CloudProvider.GCP, "nvidia-h100-80gb", 8),
            _make(CloudProvider.AZURE, "H100_v5", 8),
        ]
        with patch(
            "verlex_server.gateway.core.gpu_canonicalization._try_db_aliases",
            return_value={},
        ):
            matches = _exact_match_available(catalog, "H100", 8)
        assert len(matches) == 3, (
            f"Expected all 3 provider variants of H100 to match, got {len(matches)}"
        )

    def test_a10g_user_request_matches_a10_catalog(self):
        # User types "A10G" (AWS-style); should still match an "A10" canonical.
        catalog = [_make(CloudProvider.AWS, "A10G", 1)]
        with patch(
            "verlex_server.gateway.core.gpu_canonicalization._try_db_aliases",
            return_value={},
        ):
            matches = _exact_match_available(catalog, "A10", 1)
        assert len(matches) == 1

    def test_user_h100_does_not_match_a100(self):
        catalog = [
            _make(CloudProvider.AWS, "A100", 8, gpu_memory_gb=40),
            _make(CloudProvider.GCP, "nvidia-tesla-a100", 8),
        ]
        with patch(
            "verlex_server.gateway.core.gpu_canonicalization._try_db_aliases",
            return_value={},
        ):
            matches = _exact_match_available(catalog, "H100", 8)
        assert matches == []

    def test_a100_80_does_not_match_a100_40_request(self):
        # A100-40 and A100-80 must remain distinct.
        catalog = [
            _make(CloudProvider.AWS, "A100", 8, gpu_memory_gb=40),       # A100-40
            _make(CloudProvider.AWS, "A100-80GB", 8, gpu_memory_gb=80),  # A100-80
        ]
        with patch(
            "verlex_server.gateway.core.gpu_canonicalization._try_db_aliases",
            return_value={},
        ):
            matches_40 = _exact_match_available(catalog, "A100-40", 8)
            matches_80 = _exact_match_available(catalog, "A100-80", 8)
        assert len(matches_40) == 1
        assert len(matches_80) == 1
        assert matches_40[0].gpu_memory_gb == 40
        assert matches_80[0].gpu_memory_gb == 80


# ----------------------------------------------------------------------------
# Hardcoded alias sanity
# ----------------------------------------------------------------------------


class TestHardcodedAliasIntegrity:
    def test_every_alias_maps_to_canonical(self):
        # Every value in HARDCODED_ALIASES must be a known canonical name
        # OR an SKU we have a TFLOPs entry for (so ranking works).
        known = CANONICAL_NAMES | set(GPU_TFLOPS_FALLBACK.keys())
        for (provider, raw), canonical in HARDCODED_ALIASES.items():
            assert canonical in known, (
                f"({provider}, {raw}) -> {canonical!r} not in canonical set"
            )

    def test_no_duplicate_provider_raw_keys(self):
        # The dict can't have duplicates by definition, but the SQL seed
        # file has the same set — keep both in sync.
        assert len(HARDCODED_ALIASES) > 50  # sanity: meaningful coverage


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
