"""Package metadata constants shared across runtime surfaces."""

VERSION = "2.6.1"
CONSTITUTIONAL_HASH = "608508a9bd224290"
