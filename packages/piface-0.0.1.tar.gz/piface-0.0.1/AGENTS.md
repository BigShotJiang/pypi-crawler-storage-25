# AGENTS.md

## Project

**Piface** — a Python web server + Svelte frontend that wraps `pi --mode rpc` subprocesses, exposing them via FastAPI + WebSocket so you can use pi from any browser over VPN/Tailscale.

## Stack

- **Backend**: Python 3.12+, FastAPI, uvicorn, Pydantic, typer, platformdirs
- **Frontend**: Svelte/SvelteKit, Vite, pnpm
- **Transport**: WebSocket (browser ↔ piface), asyncio subprocess pipes (piface ↔ pi)

## Architecture

```
Browser (Svelte) ↔ WebSocket ↔ FastAPI (piface) ↔ stdin/stdout ↔ pi --mode rpc (N processes)
```

- `piface/` — Python package (server, session manager, RPC types, routes)
- `frontend/` — Svelte app; built output served by FastAPI from `piface/static/`
- State persisted as JSON in `~/.local/share/piface/` (Linux) or `~/Library/Application Support/piface/` (macOS)

## Workflow Rules

1. **Always use `uv`** for all Python operations — dependency management, running scripts, virtual environments, adding packages. Never use pip, poetry, or conda.
2. **Test-Driven Development (TDD)** — write tests first, then implement. Run tests with `uv run pytest`. Every new module/feature needs corresponding tests before the implementation is considered complete.
3. **Keep docs up-to-date** — when changing behavior, APIs, CLI flags, architecture, or dependencies, update README.md and any other relevant docs in the same commit. Docs must never drift from code.
4. Commit messages: concise, imperative mood.
5. Type-hint all Python code. Use Pydantic models for RPC types and state.
6. Use `ruff` for linting/formatting.

## Key Files

| Path | Purpose |
|---|---|
| `pyproject.toml` | uv project config, deps, entry points |
| `piface/cli.py` | CLI: `piface serve [--port] [--host] [--dev]` |
| `piface/server.py` | FastAPI app factory, lifecycle |
| `piface/session_manager.py` | Manages all pi subprocess sessions |
| `piface/pi_session.py` | Single pi subprocess wrapper (asyncio) |
| `piface/rpc_types.py` | Pydantic models for pi RPC commands/events |
| `piface/state.py` | Persistent JSON state |
| `piface/build.py` | Auto-build Svelte frontend if stale |
| `piface/routes/sessions.py` | REST API for sessions + dir browsing |
| `piface/routes/ws.py` | WebSocket relay per session |
| `frontend/` | Svelte app (pnpm, adapter-static → `frontend/dist/`) |
| `Makefile` | Dev shortcuts: `serve`, `dev`, `background-dev`, `stop-dev`, `test`, `lint`, `format` |

## Running

```bash
uv run piface serve                    # default port 7832
uv run piface serve --port 8000 --dev  # dev mode, proxies to Svelte dev server
make background-dev                    # run dev server in background (idempotent, kills existing)
make stop-dev                          # stop background dev server
uv run pytest                          # run tests
```

Use `make background-dev` when developing inside a pi/claude-code session — it runs in the background, logs to `/tmp/piface-dev.log`, and is idempotent (re-running kills the old process first).

## Session Persistence

Pi session files live in pi's **standard location** (`~/.pi/agent/sessions/`), not in a piface-specific directory. This means piface sessions are visible to `pi --resume`.

- After the first prompt, piface captures the session file path by sending `get_state` to pi and extracting the `sessionFile` field.
- The path is persisted in piface's state (`~/.local/share/piface/state.json`).
- On server restart, sessions are restored with `--session <path>` so pi reloads the full conversation history.
