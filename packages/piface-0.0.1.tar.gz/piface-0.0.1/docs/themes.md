# Piface UI Themes (not pi themes)

This document describes **Piface’s frontend skin system only**.

> Important: It does **not** affect `pi` CLI themes. `pi` themes are JSON files loaded by the terminal app and are unrelated to Piface’s `data-*` UI skin system.

Piface has two independent visual layers in the browser:

1. **Theme mode**: light/dark preference (`auto`, `light`, `dark`).
2. **Skin**: visual style presets (`default`, `beos`, `facebook2007`, `nintendo`, `nintendo-nes`, `windows98`, `macos8`, `winamp`, `protoss`, `terran`, `zerg`, `synthwave`).

Both are applied as attributes on `<html>` at runtime.

---

## 1) Runtime architecture (Piface UI)

### Where initialization happens

`frontend/src/routes/+layout.svelte` runs both initializers:

```svelte
onMount(() => {
	initTheme();
	initSkin();
	return () => cleanupThemeSync();
});
```

- `initTheme()` in `frontend/src/lib/theme.ts` loads from `localStorage`, applies the resolved `data-theme`, and wires the OS `prefers-color-scheme` listener if mode is `auto`.
- `initSkin()` in `frontend/src/lib/skin.ts` loads skin name from `localStorage` and applies `data-skin`.
- Base mode/skin selection is persisted client-side; session pages can additionally apply temporary workspace-driven theme/skin overrides from backend session metadata.

### Storage keys

- Theme mode: `piface.theme.mode` (`auto` | `light` | `dark`)
- Skin: `piface.theme.skin` (`default` | `beos` | `facebook2007` | `nintendo` | `nintendo-nes` | `windows98` | `macos8` | `winamp` | `protoss` | `terran` | `zerg` | `synthwave`)

### Theme mode behavior (`theme.ts`)

- `ThemeMode = 'auto' | 'light' | 'dark'`
- `auto` resolves using `(prefers-color-scheme: dark)`.
- `applyTheme()` writes:
  - `html.dataset.theme = 'light' | 'dark'`
  - `html.style.colorScheme = 'light' | 'dark'`
- `cleanupThemeSync()` removes the `matchMedia` listener when layout unmounts.
- `setThemeOverride('light' | 'dark' | null)` can temporarily force a session-specific theme mode without changing stored user preference.
- `setSkinOverride('<skin>' | null)` can temporarily force a session-specific skin without changing stored user preference.

### Skin behavior (`skin.ts`)

- `SkinName = 'default' | 'beos' | 'facebook2007' | 'nintendo' | 'nintendo-nes' | 'windows98' | 'macos8' | 'winamp' | 'protoss' | 'terran' | 'zerg' | 'synthwave'`
- `applySkin()` writes:
  - `html.dataset.skin = <skin>`
- No media-query logic for skins; the selected value is directly used.

---

## 2) How CSS is structured

All visual variables are defined in `frontend/src/app.css`.

- `:root { ... }` = base palette and token defaults (this is effectively default dark mode + default skin behavior).
- `html[data-theme='light'] { ... }` = global light-mode overrides.
- For skins:
  - `html[data-skin='<name>'] { ... }`
  - `html[data-theme='light'][data-skin='<name>'] { ... }` (optional light override)

This layering means:

1. Base/default
2. Theme (`light` or `dark`)
3. Skin override

So a skin can be tuned differently in light mode when needed.

### Core token groups used in skins

- **Window/content**: `--color-bg`, `--color-text`, `--color-muted`, `--color-muted-2`, `--color-subtle`, `--color-dim`, `--color-faint`
- **Surfaces**: `--surface-1`, `--surface-2`, `--surface-3`, `--surface-hover`
- **Borders/chips**: `--border`, `--border-soft`, `--border-strong`, `--border-streaming`
- **Accents**: `--primary-*`, `--danger-*`, `--success-*`
- **Piface skin polish**: `--skin-page-glow-*`, `--skin-panel-shadow`, `--skin-button-shadow`, `--skin-input-shadow`, `--skin-link-glow`, `--skin-texture-*`, `--skin-button-idle-*`, `--skin-button-sheen-*`

---

## 3) Where these values are used in components

Because tokens are CSS variables, all components automatically pick them up:

- Dashboard and session views use `--color-*` and `--surface-*` for cards, panels, and panels.
- Background and page glow uses:
  - `--skin-page-glow-*`
  - `--skin-texture-page`
- Buttons, icon buttons, tab chips use:
  - `--skin-button-shadow`
  - `--skin-button-sheen-*`
- Inputs and bordered containers use:
  - `--skin-input-shadow`
- Mermaid theme selection is coupled to `data-theme`, not skin:
  - `resolveMermaidTheme()` returns `default` when `html.dataset.theme === 'light'`, otherwise `dark`.

---

## 4) UI controls

The dashboard header has two controls in `frontend/src/routes/+page.svelte`:

- **Theme** select → calls `setThemeMode(mode)`
- **Skin** select → calls `setSkin(skin)`

Both change appearance immediately and persist into `localStorage`.

Default startup behavior:

- Theme mode defaults to `auto`
- Skin defaults to `default`

### Workspace-level session theme/skin override

Workspace Config (dashboard gear menu) supports:

- **Session theme mode override** (`none`/`light`/`dark`)
- **Session skin override** (`none`/`default`/`beos`/`facebook2007`/`nintendo`/`nintendo-nes`/`windows98`/`macos8`/`winamp`/`protoss`/`terran`/`zerg`/`synthwave`)

Storage in `.piface/workspace.toml`:

- `[ui].theme_override`
- `[ui].skin_override`

Backend session metadata fields:

- `workspace_theme_override`
- `workspace_skin_override`

`frontend/src/routes/session/[id]/+page.svelte` applies these via `setThemeOverride(...)` + `setSkinOverride(...)` while that session view is active, then clears both on page destroy.

User-selected defaults (`piface.theme.mode`, `piface.theme.skin`) remain unchanged underneath.

---

## 5) Adding a new Piface UI skin

To add a new skin preset, update:

1. `frontend/src/lib/skin.ts`
   - extend `SkinName`
   - extend `isSkinName()` guard
2. `frontend/src/lib/skin.test.ts`
   - add valid/invalid storage cases
3. `frontend/src/routes/+page.svelte`
   - add a `<option value="...">` entry
4. `frontend/src/app.css`
   - add `html[data-skin='...']`
   - optionally add `html[data-theme='light'][data-skin='...']`
5. Optional textures in `frontend/static/skins/`
   - wire via `--skin-texture-page`, `--skin-texture-panel`, `--skin-texture-button`

Recommended test set:

- `cd frontend && pnpm test -- src/lib/skin.test.ts`
- `cd frontend && pnpm test` (or relevant theme/skin test subset)
- manual browser smoke test across mode/skin combinations

---

## 6) BeOS 10-style skin (current implementation)

The `beos` skin is now tuned to be much closer to classic BeOS/10 UI: cool brushed-metal panels, high-contrast blue control bars, and soft specular highlights over smooth glass-like card surfaces.

### Current `beos` palette mapping

- `html[data-skin='beos']`
  - `--color-bg: #d0e1f2`
  - `--color-text: #10263a`
  - `--color-muted: #38526d`
  - `--color-muted-2: #4c6380`
  - `--color-subtle: #617a98`
  - `--color-dim: #6f85a2`
  - `--color-faint: #8ca4bf`
  - `--surface-1: #eaf0f8`, `--surface-2: #dee8f5`, `--surface-3: #d4e2f0`, `--surface-hover: #c8d8ea`
  - `--border: #93a8bf`, `--border-soft: #d9e4f2`, `--border-strong: #6889a7`, `--border-streaming: #8ca6c3`
  - `--primary-bg: #2a85d3`, `--primary-bg-hover: #3292e1`, `--primary-border: #1f6ca7`, `--primary-text: #f2f9ff`
  - `--danger-bg: #ffd0d0`, `--danger-bg-hover: #ffbbbb`, `--danger-border: #ff8d8d`, `--danger-text: #942b2b`
  - `--success-bg: #d8f0d8`, `--success-text: #2b7e40`
  - `--skin-page-glow-1: color-mix(in srgb, var(--primary-bg) 18%, transparent)`
  - `--skin-page-glow-2: color-mix(in srgb, var(--primary-text) 10%, transparent)`
  - `--skin-panel-shadow`: layered inset white rims + deeper shadow lift
  - `--skin-button-shadow`: high-gloss inset/outer highlights for button-like controls
  - `--skin-input-shadow`: brighter inset edge and thin white rim
  - `--skin-link-glow: 0 0 6px rgba(42, 141, 207, 0.28)`
  - `--skin-button-idle-animation: skin-button-breathe`
  - `--skin-button-idle-duration: 4.2s`
  - `--skin-button-sheen-opacity: 0.14`
  - `--skin-button-sheen-duration: 5.8s`

- `html[data-theme='light'][data-skin='beos']`
  - `--color-bg: #edf4fc`
  - `--color-text: #173654`
  - `--color-muted: #3f5d7c`
  - `--color-muted-2: #536f89`
  - `--color-subtle: #607d9c`
  - `--color-dim: #718bab`
  - `--color-faint: #98afca`
  - `--surface-1: #f7fafe`, `--surface-2: #edf5fc`, `--surface-3: #e2ecf8`, `--surface-hover: #d8e5f4`
  - `--border: #9fb9d2`, `--border-soft: #e8f1f8`, `--border-strong: #7390ad`, `--border-streaming: #8ea9c6`
  - `--primary-bg: #1f82ce`, `--primary-bg-hover: #2a92de`, `--primary-border: #2168a5`, `--primary-text: #08213e`
  - `--danger-bg: #ffd7d7`, `--danger-bg-hover: #ffcaca`, `--danger-border: #fc9898`, `--danger-text: #a13434`
  - `--success-bg: #e0f2e1`, `--success-text: #1f7b37`
  - `--skin-page-glow-1: color-mix(in srgb, var(--primary-bg) 14%, transparent)`
  - `--skin-page-glow-2: color-mix(in srgb, var(--border-streaming) 16%, transparent)`
  - `--skin-button-idle-animation: skin-button-breathe`
  - `--skin-button-idle-duration: 4.4s`
  - `--skin-button-sheen-opacity: 0.16`
  - `--skin-button-sheen-duration: 5.2s`

### BeOS-10 texture stack currently used

`beos` uses layered CSS gradients for polish (no bitmap asset required):

- `--skin-texture-page`
- `--skin-texture-panel`
- `--skin-texture-button`

The stack includes:

- radial highlight bloom,
- a short diagonal glaze,
- brushed horizontal ridges,
- and a fine vertical texture noise simulation.

### Practical tuning knobs (if you want to push it further)

If you want to push closer to a 10-era look:

- Raise `--skin-page-glow-*` to increase the glassy edge glow.
- Increase `--skin-button-sheen-opacity` a little for stronger button shininess.
- Keep `--primary-text` bright against `--primary-bg`.
- Keep `--color-bg`/surface colors high and desaturated (avoid deep greys/dark contrast).
- Add a thin, crisp focus glow to active controls by reusing existing `--skin-link-glow` family.

## 7) Nintendo Happy skin (playful, original Nintendo-inspired)

`nintendo` is a cheerful theme tuned around the original Nintendo-inspired "happy" style: bright blue surfaces, saturated red accents, and optimistic contrast.

### Current `nintendo` palette mapping

- `html[data-skin='nintendo']`
  - `--color-bg: #edf6ff`
  - `--color-text: #183252`
  - `--color-muted: #3f648f`
  - `--color-muted-2: #4e6d90`
  - `--color-subtle: #6a86a8`
  - `--color-dim: #88a2c0`
  - `--color-faint: #acc0d8`
  - `--surface-1: #f7fbff`, `--surface-2: #ecf4ff`, `--surface-3: #deedf9`, `--surface-hover: #cde1f4`
  - `--border: #9abddf`, `--border-soft: #dce9f8`, `--border-strong: #6e95ba`, `--border-streaming: #7ea9cd`
  - `--primary-bg: #ff4f4f`, `--primary-bg-hover: #ff6767`, `--primary-border: #cf2f2f`, `--primary-text: #fffdf8`
  - `--danger-bg: #ffd4c0`, `--danger-bg-hover: #ffc1a4`, `--danger-border: #ff8f6a`, `--danger-text: #9d3a1e`
  - `--success-bg: #d4f2dd`, `--success-text: #1a7f47`
  - `--skin-page-glow-1: color-mix(in srgb, var(--primary-bg) 24%, transparent)`
  - `--skin-page-glow-2: color-mix(in srgb, var(--success-bg) 36%, transparent)`
  - `--skin-button-idle-animation: skin-button-breathe`
  - `--skin-button-idle-duration: 3.6s`
  - `--skin-button-sheen-opacity: 0.2`
  - `--skin-button-sheen-duration: 4.6s`

- `html[data-theme='light'][data-skin='nintendo']`
  - `--color-bg: #fff9ec`
  - `--color-text: #213a5a`
  - `--color-muted: #4c6787`
  - `--color-muted-2: #5e7da0`
  - `--color-subtle: #7694b8`
  - `--color-dim: #92add0`
  - `--color-faint: #bccde4`
  - `--surface-1: #fffcf4`, `--surface-2: #fffaf0`, `--surface-3: #f2f3f9`, `--surface-hover: #e3ecf7`
  - `--border: #b4cfec`, `--border-soft: #f0f6ff`, `--border-strong: #8cb0d5`, `--border-streaming: #95c1eb`
  - `--primary-bg: #ff5555`, `--primary-bg-hover: #ff6a6a`, `--primary-border: #d33f3f`, `--primary-text: #fff7ee`
  - `--danger-bg: #ffdaca`, `--danger-bg-hover: #ffc0a4`, `--danger-border: #ffb08f`, `--danger-text: #a1422a`
  - `--success-bg: #dff8e5`, `--success-text: #1b7c45`
  - `--skin-page-glow-1: color-mix(in srgb, var(--primary-bg) 20%, transparent)`
  - `--skin-page-glow-2: color-mix(in srgb, var(--primary-border) 24%, transparent)`
  - `--skin-button-idle-animation: skin-button-breathe`
  - `--skin-button-idle-duration: 3.8s`
  - `--skin-button-sheen-opacity: 0.22`
  - `--skin-button-sheen-duration: 4.8s`

### Notes on Nintendo Happy look

- `--primary-bg` is intentionally saturated red (`#ff4f4f`) to evoke Nintendo’s bright accent style, while textures and blue accents keep the palette light and cheerful.
- Soft warm gradient sheens keep the interface playful without reducing contrast.
- The textured layers add a subtle “toy-like” visual feel while remaining flat and readable.

---

## 8) Nintendo NES skin (retro console-inspired)

`nintendo-nes` is a higher-contrast, more retro interpretation with strong yellow action accents and cooler blue surfaces.

### Current `nintendo-nes` palette mapping

- `html[data-skin='nintendo-nes']`
  - `--color-bg: #eef5ff`
  - `--color-text: #152a4a`
  - `--color-muted: #355d90`
  - `--color-muted-2: #4e75a9`
  - `--color-subtle: #6e8caf`
  - `--color-dim: #87a7c9`
  - `--color-faint: #afc6dd`
  - `--surface-1: #f8fbff`, `--surface-2: #edf4ff`, `--surface-3: #dfeaff`, `--surface-hover: #c8dbf2`
  - `--border: #85aed5`, `--border-soft: #deedff`, `--border-strong: #6590be`, `--border-streaming: #7ba9d7`
  - `--primary-bg: #f2bd00`, `--primary-bg-hover: #ffcf3c`, `--primary-border: #a96f00`, `--primary-text: #2d1b00`
  - `--danger-bg: #ffd3ba`, `--danger-bg-hover: #ffbe98`, `--danger-border: #ff8c5f`, `--danger-text: #8e2f17`
  - `--success-bg: #d8f2de`, `--success-text: #197840`
  - `--skin-page-glow-1: color-mix(in srgb, var(--primary-bg) 24%, transparent)`
  - `--skin-page-glow-2: color-mix(in srgb, var(--success-text) 20%, transparent)`
  - `--skin-button-idle-animation: skin-button-breathe`
  - `--skin-button-idle-duration: 4s`
  - `--skin-button-sheen-opacity: 0.16`
  - `--skin-button-sheen-duration: 5s`

- `html[data-theme='light'][data-skin='nintendo-nes']`
  - `--color-bg: #fffef8`
  - `--color-text: #1e3559`
  - `--color-muted: #4b6484`
  - `--color-muted-2: #617a9f`
  - `--color-subtle: #7a94b8`
  - `--color-dim: #94acd2`
  - `--color-faint: #bdcde3`
  - `--surface-1: #fffaf2`, `--surface-2: #fff4e9`, `--surface-3: #f0ebf4`, `--surface-hover: #dce8f7`
  - `--border: #b8cae6`, `--border-soft: #fff8ef`, `--border-strong: #95afe8`, `--border-streaming: #8cb8e2`
  - `--primary-bg: #f2b800`, `--primary-bg-hover: #f9c941`, `--primary-border: #a86400`, `--primary-text: #221300`
  - `--danger-bg: #ffd8bf`, `--danger-bg-hover: #ffc4a5`, `--danger-border: #ff996f`, `--danger-text: #92331a`
  - `--success-bg: #ddf5e7`, `--success-text: #1a8144`
  - `--skin-page-glow-1: color-mix(in srgb, var(--primary-bg) 22%, transparent)`
  - `--skin-page-glow-2: color-mix(in srgb, var(--primary-text) 12%, transparent)`
  - `--skin-button-idle-animation: skin-button-breathe`
  - `--skin-button-idle-duration: 4.2s`
  - `--skin-button-sheen-opacity: 0.18`
  - `--skin-button-sheen-duration: 5.1s`

### Notes on Nintendo NES look

- This variant swaps the softer rounded friendliness of `nintendo` for a tighter pixel-era contrast.
- `--primary-bg` uses a vivid yellow (`#f2bd00`) with a complementary warm glow and darker border to mimic late-80s game UI controls.
- Textures use finer linear ridges and subtle noise to mimic low-resolution display artifacting without losing clarity.

---

## 9) Windows 98 skin (classic desktop-inspired)

`windows98` recreates the classic late-90s desktop look with:

- teal desktop background (`--color-bg: #008080`),
- gray window surfaces (`--surface-1: #c0c0c0`, `--surface-2: #d4d0c8`),
- beveled controls via directional border colors,
- square corners and no glow/sheen animation,
- deep navy action accent (`--primary-bg: #000080`) for title/primary affordances,
- classic dotted keyboard focus rings, inset text fields, and blue active tab/primary states.

Implementation details in `frontend/src/app.css`:

- `html[data-skin='windows98']` token palette
- `html[data-theme='light'][data-skin='windows98']` light override
- Windows-98-specific component polish block (button bevels, pressed state, classic input inset, square panel chrome)

---

## 10) Mac OS 8 skin (classic Aqua-inspired)

`macos8` brings a faithful 1990s classic Mac look: bright aqua surfaces, high-gloss buttons, soft beveled controls, and a subtle brushed-metal base texture.

Implementation details in `frontend/src/app.css`:

- `html[data-skin='macos8']` token palette
- `html[data-theme='light'][data-skin='macos8']` light override
- Mac-specific component polish block (Chicago-style font stack, rounded bevel controls, subdued active press, and gradient accents)

### Current `macos8` palette mapping

- `html[data-skin='macos8']`
  - `--color-bg: #9dc1e9`
  - `--color-text: #142744`
  - `--color-muted: #325a80`
  - `--color-muted-2: #3f6990`
  - `--color-subtle: #56739b`
  - `--color-dim: #6787b1`
  - `--color-faint: #8fa7cb`
  - `--surface-1: #d8eaf9`, `--surface-2: #c0d9f3`, `--surface-3: #a9cee6`, `--surface-hover: #bdd7ef`
  - `--border: #95aec8`, `--border-soft: #ecf5ff`, `--border-strong: #6690b5`, `--border-streaming: #82a4cf`
  - `--primary-bg: #2f84d8`, `--primary-bg-hover: #3a93e8`, `--primary-border: #1d64ae`, `--primary-text: #f7fbff`
  - `--danger-bg: #ffc4aa`, `--danger-bg-hover: #ffb190`, `--danger-border: #dd6d4b`, `--danger-text: #7c2812`
  - `--success-bg: #d7efca`, `--success-text: #1e6f42`
  - `--skin-page-glow-1: color-mix(in srgb, var(--primary-bg) 20%, transparent)`
  - `--skin-page-glow-2: color-mix(in srgb, var(--primary-text) 8%, transparent)`
  - `--skin-button-idle-animation: skin-button-breathe`
  - `--skin-button-idle-duration: 4.8s`
  - `--skin-button-sheen-opacity: 0.18`
  - `--skin-button-sheen-duration: 5.4s`

- `html[data-theme='light'][data-skin='macos8']`
  - `--color-bg: #d6ebff`
  - `--color-text: #102a4e`
  - `--color-muted: #3a6289`
  - `--color-muted-2: #467098`
  - `--color-subtle: #5d79a0`
  - `--color-dim: #6f8fb8`
  - `--color-faint: #96afcf`
  - `--surface-1: #f0f7ff`, `--surface-2: #dcecff`, `--surface-3: #cce3f9`, `--surface-hover: #d5e8ff`
  - `--border: #9ab3cb`, `--border-soft: #eff7ff`, `--border-strong: #78a0cb`, `--border-streaming: #90b2d9`
  - `--primary-bg: #3386de`, `--primary-bg-hover: #4895e6`, `--primary-border: #1b65a4`, `--primary-text: #f6fbff`
  - `--skin-page-glow-1: color-mix(in srgb, var(--primary-bg) 18%, transparent)`
  - `--skin-page-glow-2: color-mix(in srgb, var(--primary-bg-hover) 16%, transparent)`
  - `--skin-button-idle-duration: 4.4s`
  - `--skin-button-sheen-opacity: 0.2`
  - `--skin-button-sheen-duration: 5.2s`

### Mac OS 8 polish notes

- Added dedicated macOS-specific polish selectors in `frontend/src/app.css` for:
  - classic rounded window control shapes,
  - button beveling and press behavior,
  - input rounding/shadows,
  - subtle focus dotted outlines,
  - optional custom font stack.
- No texture assets are required; all surface texture is CSS gradient layers.

## 11) Notes for maintainers

- `ThemeMode` validation is strict (`light`, `dark`, `auto`).
- `SkinName` validation is strict and invalid stored values fall back to defaults.
- No backend state changes are required for UI theme/skin changes.
- Do not confuse this system with `pi` CLI themes (JSON files in `~/.pi/agent/themes`):
  they are separate systems.
