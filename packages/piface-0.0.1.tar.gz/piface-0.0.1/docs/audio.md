# Piface Audio & Speech Notes

This document captures the non-obvious audio/speech behavior and compatibility workarounds we added, so future CUDA/mobile issues are easier to diagnose.

## 1) End-to-end flows

### 1.1 Speech-to-text (microphone → composer)

1. Browser records microphone audio with `MediaRecorder`.
2. Frontend base64-encodes recorded bytes and calls:
   - `POST /api/sessions/{id}/transcribe`
3. Backend decodes payload and converts audio to 16 kHz mono WAV via `ffmpeg`.
4. `ParakeetTranscriber` (`piface/speech.py`) runs NeMo Parakeet v3 transcription.
5. Optional cleanup pass (`Mic → Clean`) rewrites transcript via a short-lived pi call.

### 1.2 Text-to-speech (assistant message → browser playback)

1. User clicks `Listen` on an assistant message in the session chat.
2. Frontend calls:
   - `POST /api/sessions/{id}/tts`
3. Backend normalizes the visible assistant text, hashes `(model_name, text, output_format)` into a cache key, and asks `CoquiTtsSynthesizer` (`piface/tts.py`) to ensure `<cache_key>.mp3` exists.
4. On a cache miss, Coqui TTS synthesizes a temporary WAV, then `ffmpeg` transcodes it to MP3 and stores that under Piface's data directory cache.
5. Backend returns a stable content-addressed URL:
   - `GET /api/audio/tts/{cache_key}.mp3`
6. Browser plays that MP3 with `HTMLAudioElement` controls exposed in the UI:
   - `Listen` / `Play` / `Pause`
   - inline progress + elapsed / duration
   - `↺ Restart`
   - adaptive rewind (`-10s` or `-15s` depending on clip length)
7. Because the URL is immutable and content-addressed, browser HTTP cache reuses it after the first fetch.

## 2) Key files

- Backend
  - `piface/speech.py`
  - `piface/tts.py`
  - `piface/routes/sessions.py`
  - `piface/server.py`
  - `piface/cli.py`
- Frontend
  - `frontend/src/lib/voice-input.ts`
  - `frontend/src/lib/tts-playback.ts`
  - `frontend/src/routes/session/[id]/+page.svelte`

## 3) CUDA / GPU compatibility notes

### 3.1 Torch build matters for older GPUs (e.g. GTX 1080 Ti)

`torch 2.10 + cu128` may not include `sm_61` kernels, which causes runtime failures like:

- `CUDA error: no kernel image is available for execution on the device`

We use `torch==2.10.0+cu126` and `torchaudio==2.10.0+cu126` for GTX 1080 Ti compatibility.

```bash
make install-torch-cu126
```

### 3.2 Pin audio workloads to GTX 1080 Ti (leave other GPUs free)

Both Parakeet STT and Coqui TTS run inside the same piface server process, so `CUDA_VISIBLE_DEVICES` pinning applies to both features.

Preferred Makefile targets:

```bash
make serve-audio-1080
make dev-audio-1080
make background-dev-audio-1080
```

Back-compat aliases still exist:

```bash
make serve-speech-1080
make dev-speech-1080
make background-dev-speech-1080
```

### 3.3 NeMo CUDA-graphs failure on older stack

Observed error:

- `ValueError: not enough values to unpack (expected 6, got 5)`

This occurred inside NeMo RNNT CUDA graph setup on first decode. Workaround is implemented in `piface/speech.py`:

- `_disable_cuda_graphs_if_supported(model)`
- called after `model.to("cuda")`

This keeps GPU inference enabled while avoiding the failing CUDA-graphs path.

## 4) TTS caching behavior

### 4.1 Server cache

Coqui outputs are cached on disk under the Piface data directory:

- Linux: `~/.local/share/piface/tts-cache/`
- macOS: `~/Library/Application Support/piface/tts-cache/`

Details:

- file names are SHA-256 content hashes of `(model_name, normalized_text, output_format)`
- format is currently MP3 (`audio/mpeg`)
- cache is trimmed opportunistically after new writes, keeping the most recently used files up to ~1 GiB by default

### 4.2 Browser cache

`GET /api/audio/tts/{cache_key}.mp3` is served with long-lived cache headers:

- `Cache-Control: public, max-age=31536000, immutable`
- `ETag: "<cache_key>"`

That means once a synthesized MP3 has been fetched by the browser, replaying the same assistant output can reuse the cached response without re-downloading the audio bytes.

## 5) iOS / iPadOS recording hardening

We saw intermittent empty recordings on Safari/Chrome iOS (`Audio payload is empty`).

Mitigations implemented:

1. iOS environment detection (`isLikelyIOSRecordingEnvironment`)
2. MIME preference on iOS:
   - prefer `audio/mp4` over webm
3. chunked recording on iOS:
   - `MediaRecorder.start(250)` to force periodic `dataavailable`
4. stop flush behavior:
   - request final data
   - short delayed stop (`~140ms`) on iOS
5. defensive frontend checks before upload:
   - if no chunks / zero-size blob, show friendly retry message

## 6) Basic troubleshooting checklist

### 6.1 Dependency checks

Install whichever stack(s) you need:

```bash
uv sync --extra speech          # Parakeet STT only
uv sync --extra tts             # Coqui TTS only
uv sync --extra audio           # both
ffmpeg -version
```

Notes:

- Piface uses the maintained `coqui-tts` package for TTS support
- the legacy `TTS` package only supports Python `<3.12`, so the project is pinned to Python 3.12.x
- Coqui's current import path also needs `torchcodec`, and the compatible line for our pinned Torch stack is `torchcodec 0.10.x`
- if you want CUDA on the GTX 1080 Ti, run `make install-torch-cu126` after sync so both `torch` and `torchaudio` match the cu126 build

Quick import smoke tests:

```bash
uv run python -c "import nemo.collections.asr, torch; print('stt deps OK')"
uv run python -c "from TTS.api import TTS; import torch, torchaudio, torchcodec; print('tts deps OK')"
```

### 6.2 CUDA checks

```bash
nvidia-smi --query-gpu=index,name,uuid --format=csv,noheader
uv run python -c "import torch; print(torch.__version__, torch.cuda.get_arch_list(), torch.cuda.is_available())"
```

### 6.3 Runtime mode checks

- Force CPU if GPU stack is unstable:

```bash
uv run piface serve --speech-cpu --tts-cpu
```

- Disable STT entirely:

```bash
uv run piface serve --no-speech
```

- Disable TTS entirely:

```bash
uv run piface serve --no-tts
```

### 6.4 Logs

When using background dev mode:

```bash
tail -n 200 /tmp/piface-dev.log
```

## 7) Symptoms → likely cause quick map

- `Speech transcription dependencies are missing`:
  - speech extra not installed in active env
- `Text-to-speech dependencies are missing`:
  - `coqui-tts`, `torchaudio`, and/or `torchcodec` not installed in the active env
- `module 'ml_dtypes' has no attribute 'float4_e2m1fn'` during NeMo import:
  - old `ml-dtypes` selected by the environment; re-run `uv sync --extra speech` or `uv sync --extra audio`
- `ffmpeg ... not found on PATH`:
  - ffmpeg missing (needed for microphone normalization and TTS MP3 transcoding)
- `no kernel image is available for execution`:
  - Torch CUDA build does not include your GPU arch
- `expected 6, got 5` in NeMo transducer decode:
  - CUDA-graphs issue on that stack (handled by disabling CUDA graphs)
- `Audio payload is empty` on iOS:
  - recorder not flushing final chunk reliably (mitigated by iOS-specific capture logic)
- `TTS audio not found` on `GET /api/audio/tts/...`:
  - cache file was trimmed/removed; re-request `POST /api/sessions/{id}/tts` to regenerate
