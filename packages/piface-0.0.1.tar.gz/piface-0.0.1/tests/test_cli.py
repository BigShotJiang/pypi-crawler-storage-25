"""Tests for the CLI module."""

from typer.testing import CliRunner

from piface.cli import app

runner = CliRunner()


class TestCli:
    def test_help(self) -> None:
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "piface" in result.output.lower() or "serve" in result.output.lower()

    def test_serve_help(self) -> None:
        result = runner.invoke(app, ["serve", "--help"])
        assert result.exit_code == 0
        assert "--port" in result.output
        assert "--host" in result.output
        assert "--dev" in result.output
        assert "--direnv" in result.output
        assert "--no-direnv" in result.output
        assert "--speech" in result.output
        assert "--no-speech" in result.output
        assert "--speech-model" in result.output
        assert "--tts" in result.output
        assert "--no-tts" in result.output
        assert "--tts-model" in result.output
        assert "--tts-gpu" in result.output
        assert "--tts-cpu" in result.output
