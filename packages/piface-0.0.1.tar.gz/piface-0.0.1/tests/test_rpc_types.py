"""Tests for RPC type models."""

import json

from piface.rpc_types import (
    AbortBashCommand,
    AbortCommand,
    AbortRetryCommand,
    BashCommand,
    CompactCommand,
    CycleModelCommand,
    CycleThinkingLevelCommand,
    ExportHtmlCommand,
    ExtensionUIResponse,
    FollowUpCommand,
    ForkCommand,
    GetAvailableModelsCommand,
    GetCommandsCommand,
    GetForkMessagesCommand,
    GetLastAssistantTextCommand,
    GetMessagesCommand,
    GetSessionStatsCommand,
    GetStateCommand,
    NewSessionCommand,
    PromptCommand,
    RpcEvent,
    RpcResponse,
    SetModelCommand,
    SetSessionNameCommand,
    SetThinkingLevelCommand,
    SteerCommand,
    SwitchSessionCommand,
    parse_command,
    parse_event,
)


class TestCommandSerialization:
    def test_prompt_command_basic(self) -> None:
        cmd = PromptCommand(message="Hello!")
        data = json.loads(cmd.model_dump_json(exclude_none=True))
        assert data == {"type": "prompt", "message": "Hello!"}

    def test_prompt_command_with_id(self) -> None:
        cmd = PromptCommand(id="req-1", message="Hello!")
        data = json.loads(cmd.model_dump_json(exclude_none=True))
        assert data["id"] == "req-1"
        assert data["type"] == "prompt"

    def test_prompt_command_with_streaming_behavior(self) -> None:
        cmd = PromptCommand(message="New", streamingBehavior="steer")
        data = json.loads(cmd.model_dump_json(exclude_none=True))
        assert data["streamingBehavior"] == "steer"

    def test_steer_command(self) -> None:
        cmd = SteerCommand(message="Stop that")
        data = json.loads(cmd.model_dump_json(exclude_none=True))
        assert data == {"type": "steer", "message": "Stop that"}

    def test_follow_up_command(self) -> None:
        cmd = FollowUpCommand(message="Also do this")
        data = json.loads(cmd.model_dump_json(exclude_none=True))
        assert data == {"type": "follow_up", "message": "Also do this"}

    def test_abort_command(self) -> None:
        cmd = AbortCommand()
        data = json.loads(cmd.model_dump_json(exclude_none=True))
        assert data == {"type": "abort"}

    def test_set_model_command(self) -> None:
        cmd = SetModelCommand(provider="anthropic", modelId="claude-sonnet-4-20250514")
        data = json.loads(cmd.model_dump_json(exclude_none=True))
        assert data["type"] == "set_model"
        assert data["provider"] == "anthropic"
        assert data["modelId"] == "claude-sonnet-4-20250514"

    def test_set_thinking_level_command(self) -> None:
        cmd = SetThinkingLevelCommand(level="high")
        data = json.loads(cmd.model_dump_json(exclude_none=True))
        assert data == {"type": "set_thinking_level", "level": "high"}

    def test_get_state_command(self) -> None:
        cmd = GetStateCommand()
        data = json.loads(cmd.model_dump_json(exclude_none=True))
        assert data == {"type": "get_state"}

    def test_get_messages_command(self) -> None:
        cmd = GetMessagesCommand()
        data = json.loads(cmd.model_dump_json(exclude_none=True))
        assert data == {"type": "get_messages"}

    def test_new_session_command(self) -> None:
        cmd = NewSessionCommand()
        data = json.loads(cmd.model_dump_json(exclude_none=True))
        assert data == {"type": "new_session"}

    def test_compact_command(self) -> None:
        cmd = CompactCommand(customInstructions="Focus on code")
        data = json.loads(cmd.model_dump_json(exclude_none=True))
        assert data == {"type": "compact", "customInstructions": "Focus on code"}

    def test_bash_command(self) -> None:
        cmd = BashCommand(command="ls -la")
        data = json.loads(cmd.model_dump_json(exclude_none=True))
        assert data == {"type": "bash", "command": "ls -la"}

    def test_switch_session_command(self) -> None:
        cmd = SwitchSessionCommand(sessionPath="/path/to/session.jsonl")
        data = json.loads(cmd.model_dump_json(exclude_none=True))
        assert data == {"type": "switch_session", "sessionPath": "/path/to/session.jsonl"}

    def test_fork_command(self) -> None:
        cmd = ForkCommand(entryId="abc123")
        data = json.loads(cmd.model_dump_json(exclude_none=True))
        assert data == {"type": "fork", "entryId": "abc123"}

    def test_set_session_name_command(self) -> None:
        cmd = SetSessionNameCommand(name="my-feature")
        data = json.loads(cmd.model_dump_json(exclude_none=True))
        assert data == {"type": "set_session_name", "name": "my-feature"}

    def test_export_html_command(self) -> None:
        cmd = ExportHtmlCommand(outputPath="/tmp/session.html")
        data = json.loads(cmd.model_dump_json(exclude_none=True))
        assert data == {"type": "export_html", "outputPath": "/tmp/session.html"}

    def test_extension_ui_response(self) -> None:
        resp = ExtensionUIResponse(id="uuid-1", value="Allow")
        data = json.loads(resp.model_dump_json(exclude_none=True))
        assert data == {"type": "extension_ui_response", "id": "uuid-1", "value": "Allow"}

    def test_extension_ui_response_confirmed(self) -> None:
        resp = ExtensionUIResponse(id="uuid-2", confirmed=True)
        data = json.loads(resp.model_dump_json(exclude_none=True))
        assert data == {"type": "extension_ui_response", "id": "uuid-2", "confirmed": True}

    def test_extension_ui_response_cancelled(self) -> None:
        resp = ExtensionUIResponse(id="uuid-3", cancelled=True)
        data = json.loads(resp.model_dump_json(exclude_none=True))
        assert data == {"type": "extension_ui_response", "id": "uuid-3", "cancelled": True}


class TestParseCommand:
    def test_parse_prompt(self) -> None:
        raw = {"type": "prompt", "message": "Hello"}
        cmd = parse_command(raw)
        assert isinstance(cmd, PromptCommand)
        assert cmd.message == "Hello"

    def test_parse_abort(self) -> None:
        raw = {"type": "abort"}
        cmd = parse_command(raw)
        assert isinstance(cmd, AbortCommand)

    def test_parse_set_model(self) -> None:
        raw = {"type": "set_model", "provider": "anthropic", "modelId": "claude-sonnet-4-20250514"}
        cmd = parse_command(raw)
        assert isinstance(cmd, SetModelCommand)

    def test_parse_unknown_returns_none(self) -> None:
        raw = {"type": "totally_unknown_command"}
        cmd = parse_command(raw)
        assert cmd is None

    def test_parse_all_simple_commands(self) -> None:
        simple_commands: list[tuple[str, type]] = [
            ("abort", AbortCommand),
            ("get_state", GetStateCommand),
            ("get_messages", GetMessagesCommand),
            ("get_available_models", GetAvailableModelsCommand),
            ("cycle_model", CycleModelCommand),
            ("cycle_thinking_level", CycleThinkingLevelCommand),
            ("abort_bash", AbortBashCommand),
            ("abort_retry", AbortRetryCommand),
            ("get_session_stats", GetSessionStatsCommand),
            ("get_fork_messages", GetForkMessagesCommand),
            ("get_last_assistant_text", GetLastAssistantTextCommand),
            ("get_commands", GetCommandsCommand),
            ("new_session", NewSessionCommand),
        ]
        for cmd_type, expected_cls in simple_commands:
            raw = {"type": cmd_type}
            cmd = parse_command(raw)
            assert isinstance(cmd, expected_cls), f"Failed for {cmd_type}"


class TestParseEvent:
    def test_parse_response_event(self) -> None:
        raw = {"type": "response", "command": "prompt", "success": True}
        event = parse_event(raw)
        assert isinstance(event, RpcResponse)
        assert event.command == "prompt"
        assert event.success is True

    def test_parse_response_with_data(self) -> None:
        raw = {
            "type": "response",
            "command": "get_state",
            "success": True,
            "data": {"isStreaming": False},
        }
        event = parse_event(raw)
        assert isinstance(event, RpcResponse)
        assert event.data == {"isStreaming": False}

    def test_parse_response_error(self) -> None:
        raw = {"type": "response", "command": "set_model", "success": False, "error": "Not found"}
        event = parse_event(raw)
        assert isinstance(event, RpcResponse)
        assert event.success is False
        assert event.error == "Not found"

    def test_parse_generic_event(self) -> None:
        raw = {"type": "agent_start"}
        event = parse_event(raw)
        assert isinstance(event, RpcEvent)
        assert event.type == "agent_start"

    def test_parse_message_update_event(self) -> None:
        raw = {
            "type": "message_update",
            "message": {"role": "assistant"},
            "assistantMessageEvent": {"type": "text_delta", "delta": "Hello"},
        }
        event = parse_event(raw)
        assert isinstance(event, RpcEvent)
        assert event.type == "message_update"
        assert event.raw["assistantMessageEvent"]["delta"] == "Hello"

    def test_parse_extension_ui_request(self) -> None:
        raw = {
            "type": "extension_ui_request",
            "id": "uuid-1",
            "method": "select",
            "title": "Choose",
            "options": ["A", "B"],
        }
        event = parse_event(raw)
        assert isinstance(event, RpcEvent)
        assert event.type == "extension_ui_request"
        assert event.raw["method"] == "select"

    def test_parse_agent_end_event(self) -> None:
        raw = {"type": "agent_end", "messages": [{"role": "assistant"}]}
        event = parse_event(raw)
        assert isinstance(event, RpcEvent)
        assert event.raw["messages"] == [{"role": "assistant"}]
