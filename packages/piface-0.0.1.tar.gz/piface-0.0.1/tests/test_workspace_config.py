"""Tests for workspace configuration loading and validation."""

from pathlib import Path

import pytest

from piface.workspace_config import (
    BootstrapSection,
    LaunchSection,
    WorkspaceConfig,
    default_workspace_config,
    load_workspace_config,
    render_template,
    save_workspace_config,
    validate_file_paths,
    validate_workspace_root,
)


@pytest.fixture
def config_dir(tmp_path: Path) -> Path:
    """A directory that simulates a project root."""
    return tmp_path / "project"


@pytest.fixture
def project_with_config(config_dir: Path) -> Path:
    config_dir.mkdir()
    piface_dir = config_dir / ".piface"
    piface_dir.mkdir()
    return config_dir


class TestWorkspaceConfigLoading:
    def test_load_valid_full_config(self, project_with_config: Path) -> None:
        (project_with_config / ".piface" / "workspace.toml").write_text("""\
version = 1

[workspace]
mode = "git_worktree"
root = "~/.local/share/piface/worktrees/{project_slug}"
name_template = "{session_slug}-{short_id}"
default_base = "current_branch"
branch_prefix = "piface"
auto_cleanup = false

[env]
use_direnv = true

[files]
copy = [".env", ".env.local"]
symlink = ["data"]

[bootstrap]
shell = "bash"
use_direnv = true
cwd = "workspace_root"
script = "uv sync"
timeout_seconds = 900

[launch]
shell = "bash"
apply_to = ["pi", "pty"]
script = "useaion"
timeout_seconds = 30

[git]
create_branch = true
branch_template = "{branch_prefix}/{workspace_name}"
detach = false

[ui]
label_template = "{session_name} [{workspace_name}]"
theme_override = "dark"
skin_override = "beos"
""")
        config = load_workspace_config(project_with_config)
        assert config.version == 1
        assert config.workspace.mode == "git_worktree"
        assert config.workspace.branch_prefix == "piface"
        assert config.workspace.auto_cleanup is False
        assert config.env.use_direnv is True
        assert config.files.copy_paths == [".env", ".env.local"]
        assert config.files.symlink == ["data"]
        assert config.bootstrap is not None
        assert config.bootstrap.script == "uv sync"
        assert config.bootstrap.timeout_seconds == 900
        assert config.launch is not None
        assert config.launch.apply_to == ["pi", "pty"]
        assert config.launch.script == "useaion"
        assert config.git.create_branch is True
        assert config.git.branch_template == "{branch_prefix}/{workspace_name}"
        assert config.ui.theme_override == "dark"
        assert config.ui.skin_override == "beos"

    def test_load_minimal_config(self, project_with_config: Path) -> None:
        (project_with_config / ".piface" / "workspace.toml").write_text("""\
version = 1

[workspace]
mode = "git_worktree"
""")
        config = load_workspace_config(project_with_config)
        assert config.workspace.mode == "git_worktree"
        assert config.workspace.name_template == "{session_slug}-{short_id}"
        assert config.workspace.default_base == "current_branch"
        assert config.files.copy_paths == []
        assert config.files.symlink == []
        assert config.bootstrap is None
        assert config.launch is None
        assert config.ui.theme_override is None
        assert config.ui.skin_override is None

    def test_missing_config_returns_defaults(self, config_dir: Path) -> None:
        config_dir.mkdir()
        config = load_workspace_config(config_dir)
        defaults = default_workspace_config()
        assert config.workspace.mode == defaults.workspace.mode
        assert config.workspace.root == defaults.workspace.root
        assert config.files.copy_paths == []
        assert config.bootstrap is None
        assert config.launch is None
        assert config.ui.theme_override is None
        assert config.ui.skin_override is None

    def test_invalid_toml_syntax_raises(self, project_with_config: Path) -> None:
        (project_with_config / ".piface" / "workspace.toml").write_text("not valid toml {{{")
        with pytest.raises(ValueError, match="workspace.toml"):
            load_workspace_config(project_with_config)

    def test_unsupported_version_raises(self, project_with_config: Path) -> None:
        (project_with_config / ".piface" / "workspace.toml").write_text("""\
version = 99

[workspace]
mode = "git_worktree"
""")
        with pytest.raises(ValueError, match="version"):
            load_workspace_config(project_with_config)

    def test_invalid_mode_raises(self, project_with_config: Path) -> None:
        (project_with_config / ".piface" / "workspace.toml").write_text("""\
version = 1

[workspace]
mode = "docker"
""")
        with pytest.raises(ValueError):
            load_workspace_config(project_with_config)


class TestWorkspaceConfigValidation:
    def test_root_inside_repo_rejected(self, tmp_path: Path) -> None:
        project = tmp_path / "repo"
        project.mkdir()
        root = project / ".piface" / "worktrees"
        root.mkdir(parents=True)
        with pytest.raises(ValueError, match="outside"):
            validate_workspace_root(root, project)

    def test_root_outside_repo_accepted(self, tmp_path: Path) -> None:
        project = tmp_path / "repo"
        project.mkdir()
        root = tmp_path / "worktrees"
        root.mkdir()
        # Should not raise
        validate_workspace_root(root, project)

    def test_root_equal_to_repo_rejected(self, tmp_path: Path) -> None:
        project = tmp_path / "repo"
        project.mkdir()
        with pytest.raises(ValueError, match="outside"):
            validate_workspace_root(project, project)

    def test_files_copy_path_traversal_rejected(self) -> None:
        with pytest.raises(ValueError, match="traversal"):
            validate_file_paths(["../../../etc/passwd"])

    def test_files_copy_absolute_path_rejected(self) -> None:
        with pytest.raises(ValueError, match="absolute"):
            validate_file_paths(["/etc/hosts"])

    def test_files_copy_relative_accepted(self) -> None:
        # Should not raise
        validate_file_paths([".env", "config/local.yaml"])

    def test_create_branch_and_detach_both_true_rejected(self, project_with_config: Path) -> None:
        (project_with_config / ".piface" / "workspace.toml").write_text("""\
version = 1

[workspace]
mode = "git_worktree"

[git]
create_branch = true
detach = true
""")
        with pytest.raises(ValueError):
            load_workspace_config(project_with_config)


class TestTemplateSubstitution:
    def test_basic_substitution(self) -> None:
        result = render_template(
            "{branch_prefix}/{workspace_name}",
            {"branch_prefix": "piface", "workspace_name": "my-session-abc"},
        )
        assert result == "piface/my-session-abc"

    def test_root_template_expansion(self) -> None:
        result = render_template(
            "~/.local/share/piface/worktrees/{project_slug}",
            {"project_slug": "myrepo-a1b2c3"},
        )
        assert result == "~/.local/share/piface/worktrees/myrepo-a1b2c3"

    def test_missing_variable_raises(self) -> None:
        with pytest.raises(KeyError):
            render_template("{unknown_var}", {})

    def test_multiple_variables(self) -> None:
        result = render_template(
            "{session_slug}-{short_id}",
            {"session_slug": "my-feature", "short_id": "abc123"},
        )
        assert result == "my-feature-abc123"


class TestSerializeAndSave:
    def test_default_config_roundtrips(self, tmp_path: Path) -> None:
        original = default_workspace_config()
        # Write and reload
        project = tmp_path / "project"
        project.mkdir()
        save_workspace_config(project, original)
        reloaded = load_workspace_config(project)
        assert reloaded.workspace.mode == original.workspace.mode
        assert reloaded.workspace.root == original.workspace.root
        assert reloaded.workspace.name_template == original.workspace.name_template
        assert reloaded.files.copy_paths == []
        assert reloaded.files.symlink == []
        assert reloaded.bootstrap is None
        assert reloaded.launch is None

    def test_config_with_bootstrap_roundtrips(self, tmp_path: Path) -> None:
        config = WorkspaceConfig(
            bootstrap=BootstrapSection(script="uv sync\nnpm install"),
        )
        project = tmp_path / "project"
        project.mkdir()
        save_workspace_config(project, config)
        reloaded = load_workspace_config(project)
        assert reloaded.bootstrap is not None
        assert reloaded.bootstrap.script is not None
        assert "uv sync" in reloaded.bootstrap.script
        assert "npm install" in reloaded.bootstrap.script

    def test_config_with_launch_roundtrips(self, tmp_path: Path) -> None:
        config = WorkspaceConfig(
            launch=LaunchSection(script="useaion", apply_to=["pi"]),
        )
        project = tmp_path / "project"
        project.mkdir()
        save_workspace_config(project, config)
        reloaded = load_workspace_config(project)
        assert reloaded.launch is not None
        assert reloaded.launch.script is not None
        assert reloaded.launch.script.strip() == "useaion"
        assert reloaded.launch.apply_to == ["pi"]

    def test_config_with_files_roundtrips(self, tmp_path: Path) -> None:
        config = default_workspace_config()
        config.files.copy_paths = [".env", ".env.local"]
        config.files.symlink = ["data"]
        project = tmp_path / "project"
        project.mkdir()
        save_workspace_config(project, config)
        reloaded = load_workspace_config(project)
        assert reloaded.files.copy_paths == [".env", ".env.local"]
        assert reloaded.files.symlink == ["data"]

    def test_config_with_ui_theme_override_roundtrips(self, tmp_path: Path) -> None:
        config = default_workspace_config()
        config.ui.theme_override = "light"
        config.ui.skin_override = "nintendo"
        project = tmp_path / "project"
        project.mkdir()
        save_workspace_config(project, config)
        reloaded = load_workspace_config(project)
        assert reloaded.ui.theme_override == "light"
        assert reloaded.ui.skin_override == "nintendo"

    def test_save_creates_piface_directory(self, tmp_path: Path) -> None:
        project = tmp_path / "project"
        project.mkdir()
        save_workspace_config(project, default_workspace_config())
        assert (project / ".piface" / "workspace.toml").is_file()
