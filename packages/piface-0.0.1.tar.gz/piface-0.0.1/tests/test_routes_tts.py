"""Tests for assistant text-to-speech routes."""

import sys
from pathlib import Path

import httpx
import pytest
from fastapi import FastAPI

from piface.routes.sessions import create_sessions_router
from piface.session_manager import SessionManager
from piface.tts import PreparedTtsAudio, SpeechSynthesisError

FAKE_PI_SCRIPT = """\
import json, sys

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    try:
        cmd = json.loads(line)
    except Exception:
        continue

    resp = {"type": "response", "command": cmd.get("type", ""), "success": True}
    if cmd.get("id"):
        resp["id"] = cmd["id"]

    sys.stdout.write(json.dumps(resp) + "\\n")
    sys.stdout.flush()
"""


class FakeTtsSynthesizer:
    def __init__(
        self,
        audio_path: Path,
        *,
        cache_key: str = "a" * 64,
        cached: bool = False,
        media_type: str = "audio/mpeg",
        error: SpeechSynthesisError | None = None,
    ) -> None:
        self.audio_path = audio_path
        self.cache_key = cache_key
        self.cached = cached
        self.media_type = media_type
        self.error = error
        self.calls: list[str] = []
        self.cache_lookups: list[str] = []

    async def prepare(self, text: str) -> PreparedTtsAudio:
        self.calls.append(text)
        if self.error is not None:
            raise self.error
        return PreparedTtsAudio(
            cache_key=self.cache_key,
            file_path=self.audio_path,
            media_type=self.media_type,
            cached=self.cached,
        )

    def get_cached_audio(self, cache_key: str) -> PreparedTtsAudio | None:
        self.cache_lookups.append(cache_key)
        if cache_key != self.cache_key:
            return None
        return PreparedTtsAudio(
            cache_key=self.cache_key,
            file_path=self.audio_path,
            media_type=self.media_type,
            cached=True,
        )


@pytest.fixture
def fake_pi_script(tmp_path: Path) -> Path:
    script = tmp_path / "fake_pi.py"
    script.write_text(FAKE_PI_SCRIPT)
    return script


@pytest.fixture
def manager(tmp_path: Path, fake_pi_script: Path) -> SessionManager:
    mgr = SessionManager(state_path=tmp_path / "state.json")
    mgr._pi_command_override = [sys.executable, str(fake_pi_script)]
    return mgr


@pytest.fixture
def app(manager: SessionManager) -> FastAPI:
    app = FastAPI()
    app.state.session_manager = manager
    app.include_router(create_sessions_router(), prefix="/api")
    return app


@pytest.fixture
async def client(app: FastAPI) -> httpx.AsyncClient:
    transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        yield c  # type: ignore[misc]


@pytest.mark.asyncio
async def test_prepare_tts_audio_success(
    client: httpx.AsyncClient,
    app: FastAPI,
    tmp_path: Path,
) -> None:
    audio_path = tmp_path / "reply.mp3"
    audio_path.write_bytes(b"ID3")

    create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
    sid = create_resp.json()["piface_id"]

    synthesizer = FakeTtsSynthesizer(audio_path, cache_key="b" * 64, cached=False)
    app.state.tts_synthesizer = synthesizer

    resp = await client.post(
        f"/api/sessions/{sid}/tts",
        json={"text": "Read the latest answer."},
    )

    assert resp.status_code == 200
    data = resp.json()
    assert data["cache_key"] == "b" * 64
    assert data["audio_url"] == f"/api/audio/tts/{'b' * 64}.mp3"
    assert data["media_type"] == "audio/mpeg"
    assert data["cached"] is False
    assert synthesizer.calls == ["Read the latest answer."]


@pytest.mark.asyncio
async def test_prepare_tts_audio_allows_closed_sessions(
    client: httpx.AsyncClient,
    app: FastAPI,
    tmp_path: Path,
) -> None:
    audio_path = tmp_path / "reply.mp3"
    audio_path.write_bytes(b"ID3")

    create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
    sid = create_resp.json()["piface_id"]
    await client.post(f"/api/sessions/{sid}/kill")

    app.state.tts_synthesizer = FakeTtsSynthesizer(audio_path, cache_key="c" * 64)

    resp = await client.post(
        f"/api/sessions/{sid}/tts",
        json={"text": "Archived assistant reply"},
    )

    assert resp.status_code == 200
    assert resp.json()["cache_key"] == "c" * 64


@pytest.mark.asyncio
async def test_prepare_tts_audio_requires_synthesizer(
    client: httpx.AsyncClient,
    tmp_path: Path,
) -> None:
    create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
    sid = create_resp.json()["piface_id"]

    resp = await client.post(
        f"/api/sessions/{sid}/tts",
        json={"text": "Read me"},
    )

    assert resp.status_code == 503
    assert "not configured" in resp.json()["detail"].lower()


@pytest.mark.asyncio
async def test_prepare_tts_audio_rejects_empty_text(
    client: httpx.AsyncClient,
    app: FastAPI,
    tmp_path: Path,
) -> None:
    audio_path = tmp_path / "reply.mp3"
    audio_path.write_bytes(b"ID3")

    create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
    sid = create_resp.json()["piface_id"]
    app.state.tts_synthesizer = FakeTtsSynthesizer(audio_path)

    resp = await client.post(
        f"/api/sessions/{sid}/tts",
        json={"text": "   \n\t  "},
    )

    assert resp.status_code == 400
    assert "empty" in resp.json()["detail"].lower()


@pytest.mark.asyncio
async def test_prepare_tts_audio_surfaces_synthesis_errors(
    client: httpx.AsyncClient,
    app: FastAPI,
    tmp_path: Path,
) -> None:
    audio_path = tmp_path / "reply.mp3"
    audio_path.write_bytes(b"ID3")

    create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
    sid = create_resp.json()["piface_id"]
    app.state.tts_synthesizer = FakeTtsSynthesizer(
        audio_path,
        error=SpeechSynthesisError(
            "Coqui TTS dependencies are missing.",
            code="missing_dependencies",
            status_code=503,
        ),
    )

    resp = await client.post(
        f"/api/sessions/{sid}/tts",
        json={"text": "Read me"},
    )

    assert resp.status_code == 503
    assert "dependencies" in resp.json()["detail"].lower()


@pytest.mark.asyncio
async def test_get_tts_audio_success(
    client: httpx.AsyncClient,
    app: FastAPI,
    tmp_path: Path,
) -> None:
    audio_path = tmp_path / "reply.mp3"
    audio_path.write_bytes(b"ID3")

    synthesizer = FakeTtsSynthesizer(audio_path, cache_key="d" * 64, cached=True)
    app.state.tts_synthesizer = synthesizer

    resp = await client.get(f"/api/audio/tts/{'d' * 64}.mp3")

    assert resp.status_code == 200
    assert resp.content == b"ID3"
    assert "audio/mpeg" in resp.headers["content-type"]
    assert "immutable" in resp.headers["cache-control"]
    assert resp.headers["etag"] == '"' + ('d' * 64) + '"'
    assert synthesizer.cache_lookups == ["d" * 64]


@pytest.mark.asyncio
async def test_get_tts_audio_returns_404_for_unknown_cache_key(
    client: httpx.AsyncClient,
    app: FastAPI,
    tmp_path: Path,
) -> None:
    audio_path = tmp_path / "reply.mp3"
    audio_path.write_bytes(b"ID3")

    app.state.tts_synthesizer = FakeTtsSynthesizer(audio_path, cache_key="e" * 64, cached=True)

    resp = await client.get(f"/api/audio/tts/{'f' * 64}.mp3")

    assert resp.status_code == 404
