"""Tests for speech transcription helpers."""

from types import SimpleNamespace

from piface.speech import (
    _disable_cuda_graphs_if_supported,
    extract_transcription_text,
    infer_audio_suffix,
)


def test_infer_audio_suffix_uses_mime_type_defaults() -> None:
    assert infer_audio_suffix("audio/webm") == ".webm"
    assert infer_audio_suffix("audio/mp4") == ".mp4"
    assert infer_audio_suffix("audio/wav") == ".wav"
    assert infer_audio_suffix("application/octet-stream") == ".bin"


def test_extract_transcription_text_supports_string_and_structured_outputs() -> None:
    assert extract_transcription_text("hello") == "hello"

    class Result:
        def __init__(self, text: str) -> None:
            self.text = text

    assert extract_transcription_text([Result("from result")]) == "from result"
    assert extract_transcription_text([{"text": "from dict"}]) == "from dict"


def test_disable_cuda_graphs_if_supported_calls_decoder_toggle() -> None:
    class FakeDecoder:
        def __init__(self) -> None:
            self.called = False

        def disable_cuda_graphs(self) -> None:
            self.called = True

    decoder = FakeDecoder()
    model = SimpleNamespace(decoding=SimpleNamespace(decoding=decoder))

    _disable_cuda_graphs_if_supported(model)

    assert decoder.called is True


def test_disable_cuda_graphs_if_supported_is_noop_when_not_available() -> None:
    model = SimpleNamespace(decoding=SimpleNamespace(decoding=object()))

    _disable_cuda_graphs_if_supported(model)
