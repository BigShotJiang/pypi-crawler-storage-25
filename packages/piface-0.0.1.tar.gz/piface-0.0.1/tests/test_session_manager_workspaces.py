"""Tests for SessionManager with workspace isolation (git worktree mode)."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

from piface.session_manager import SessionManager
from piface.state import SessionStatus
from piface.workspace_manager import WorkspaceManager

# Reuse the same fake pi script pattern from test_session_manager.py
FAKE_PI_SCRIPT = """\
import json, os, sys, uuid

current_session_file = os.environ.get("PIFACE_FAKE_SESSION_FILE", "/tmp/fake.jsonl")

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    try:
        cmd = json.loads(line)
    except Exception:
        continue

    cmd_type = cmd.get("type", "")
    cmd_id = cmd.get("id")

    if cmd_type == "prompt":
        resp = {"type": "response", "command": "prompt", "success": True}
        if cmd_id:
            resp["id"] = cmd_id
        sys.stdout.write(json.dumps(resp) + "\\n")
        sys.stdout.write(json.dumps({"type": "agent_start"}) + "\\n")
        sys.stdout.write(json.dumps({"type": "agent_end", "messages": []}) + "\\n")
        sys.stdout.flush()
        continue

    if cmd_type == "get_state":
        data_resp = {
            "type": "response",
            "command": "get_state",
            "success": True,
            "data": {"sessionFile": current_session_file, "isStreaming": False},
        }
        if cmd_id:
            data_resp["id"] = cmd_id
        sys.stdout.write(json.dumps(data_resp) + "\\n")
        sys.stdout.flush()
        continue

    if cmd_type == "fork":
        current_session_file = f"/tmp/forked-{uuid.uuid4().hex}.jsonl"
        fork_resp = {
            "type": "response",
            "command": "fork",
            "success": True,
            "data": {"text": "Forked prompt text", "cancelled": False},
        }
        if cmd_id:
            fork_resp["id"] = cmd_id
        sys.stdout.write(json.dumps(fork_resp) + "\\n")
        sys.stdout.flush()
        continue

    resp = {"type": "response", "command": cmd_type, "success": True}
    if cmd_id:
        resp["id"] = cmd_id
    sys.stdout.write(json.dumps(resp) + "\\n")
    sys.stdout.flush()
"""


@pytest.fixture
def fake_pi_script(tmp_path: Path) -> Path:
    script = tmp_path / "fake_pi.py"
    script.write_text(FAKE_PI_SCRIPT)
    return script


@pytest.fixture
def state_file(tmp_path: Path) -> Path:
    return tmp_path / "state.json"


@pytest.fixture
def workspace_manager(tmp_path: Path) -> WorkspaceManager:
    return WorkspaceManager(data_dir=tmp_path / "piface-data")


@pytest.fixture
def manager(
    state_file: Path,
    fake_pi_script: Path,
    workspace_manager: WorkspaceManager,
) -> SessionManager:
    mgr = SessionManager(
        state_path=state_file,
        workspace_manager=workspace_manager,
    )
    mgr._pi_command_override = [sys.executable, str(fake_pi_script)]
    return mgr


class TestCreateSessionWithWorkspace:
    async def test_create_stores_workspace_metadata(
        self,
        manager: SessionManager,
        git_repo: Path,
        worktree_root: Path,
    ) -> None:
        sid = await manager.create_session(
            working_dir=str(git_repo),
            worktree_root_override=worktree_root,
        )
        state = manager._load_state()
        rec = state.sessions[sid]
        assert rec.project_dir == str(git_repo)
        assert rec.workspace_mode == "git_worktree"
        assert rec.workspace_name is not None
        assert rec.workspace_root is not None
        assert rec.workspace_branch is not None
        assert rec.execution_dir is not None
        assert rec.workspace_status == "ready"
        assert rec.workspace_theme_override is None
        assert rec.workspace_skin_override is None
        assert rec.workspace_created_by_piface is True
        await manager.shutdown()

    async def test_create_stores_workspace_theme_override_from_config(
        self,
        manager: SessionManager,
        git_repo: Path,
        worktree_root: Path,
    ) -> None:
        config_dir = git_repo / ".piface"
        config_dir.mkdir(exist_ok=True)
        (config_dir / "workspace.toml").write_text(
            """\
version = 1

[workspace]
mode = "git_worktree"

[ui]
theme_override = "dark"
skin_override = "beos"
"""
        )

        sid = await manager.create_session(
            working_dir=str(git_repo),
            worktree_root_override=worktree_root,
        )
        state = manager._load_state()
        rec = state.sessions[sid]
        assert rec.workspace_theme_override == "dark"
        assert rec.workspace_skin_override == "beos"
        await manager.shutdown()

    async def test_existing_workspace_sessions_follow_updated_theme_override(
        self,
        manager: SessionManager,
        git_repo: Path,
        worktree_root: Path,
    ) -> None:
        config_dir = git_repo / ".piface"
        config_dir.mkdir(exist_ok=True)
        config_path = config_dir / "workspace.toml"
        config_path.write_text(
            """\
version = 1

[workspace]
mode = "git_worktree"

[ui]
theme_override = "dark"
skin_override = "beos"
"""
        )

        sid = await manager.create_session(
            working_dir=str(git_repo),
            worktree_root_override=worktree_root,
        )
        first = manager.get_record(sid)
        assert first is not None
        assert first.workspace_theme_override == "dark"
        assert first.workspace_skin_override == "beos"

        config_path.write_text(
            """\
version = 1

[workspace]
mode = "git_worktree"

[ui]
theme_override = "light"
skin_override = "nintendo"
"""
        )

        refreshed = manager.get_record(sid)
        assert refreshed is not None
        assert refreshed.workspace_theme_override == "light"
        assert refreshed.workspace_skin_override == "nintendo"
        await manager.shutdown()

    async def test_create_execution_dir_differs_from_working_dir(
        self,
        manager: SessionManager,
        git_repo: Path,
        worktree_root: Path,
    ) -> None:
        sid = await manager.create_session(
            working_dir=str(git_repo),
            worktree_root_override=worktree_root,
        )
        state = manager._load_state()
        rec = state.sessions[sid]
        assert rec.execution_dir != str(git_repo)
        assert Path(rec.execution_dir).is_dir()
        await manager.shutdown()

    async def test_create_from_subdir(
        self,
        manager: SessionManager,
        git_repo_with_subdir: Path,
        worktree_root: Path,
    ) -> None:
        subdir = git_repo_with_subdir / "apps" / "api"
        sid = await manager.create_session(
            working_dir=str(subdir),
            worktree_root_override=worktree_root,
        )
        state = manager._load_state()
        rec = state.sessions[sid]
        assert rec.project_dir == str(git_repo_with_subdir)
        assert rec.project_subdir == "apps/api"
        assert rec.execution_dir.endswith("apps/api")
        await manager.shutdown()

    async def test_create_shared_flag_skips_worktree(
        self,
        manager: SessionManager,
        git_repo: Path,
    ) -> None:
        sid = await manager.create_session(
            working_dir=str(git_repo),
            shared=True,
        )
        state = manager._load_state()
        rec = state.sessions[sid]
        assert rec.workspace_mode == "shared"
        assert rec.execution_dir == str(git_repo)
        assert rec.project_dir == str(git_repo)
        assert rec.workspace_theme_override is None
        assert rec.workspace_skin_override is None
        await manager.shutdown()

    async def test_create_non_git_falls_back_to_shared(
        self,
        manager: SessionManager,
        tmp_path: Path,
    ) -> None:
        plain_dir = tmp_path / "not-a-repo"
        plain_dir.mkdir()
        sid = await manager.create_session(working_dir=str(plain_dir))
        state = manager._load_state()
        rec = state.sessions[sid]
        assert rec.workspace_mode == "shared"
        assert rec.execution_dir == str(plain_dir)
        assert rec.project_dir == str(plain_dir)
        await manager.shutdown()

    async def test_working_dir_preserved_in_record(
        self,
        manager: SessionManager,
        git_repo: Path,
        worktree_root: Path,
    ) -> None:
        sid = await manager.create_session(
            working_dir=str(git_repo),
            worktree_root_override=worktree_root,
        )
        state = manager._load_state()
        rec = state.sessions[sid]
        # working_dir keeps the original user-entered path
        assert rec.working_dir == str(git_repo)
        await manager.shutdown()

    async def test_session_is_live(
        self,
        manager: SessionManager,
        git_repo: Path,
        worktree_root: Path,
    ) -> None:
        sid = await manager.create_session(
            working_dir=str(git_repo),
            worktree_root_override=worktree_root,
        )
        assert sid in manager.sessions
        assert manager.sessions[sid].is_alive
        state = manager._load_state()
        assert state.sessions[sid].status == SessionStatus.LIVE
        await manager.shutdown()


class TestResumeWithWorkspace:
    async def test_resume_reuses_existing_workspace(
        self,
        manager: SessionManager,
        git_repo: Path,
        worktree_root: Path,
    ) -> None:
        sid = await manager.create_session(
            working_dir=str(git_repo),
            worktree_root_override=worktree_root,
        )
        state = manager._load_state()
        original_root = state.sessions[sid].workspace_root
        original_exec = state.sessions[sid].execution_dir

        await manager.kill_session(sid)
        await manager.resume_session(sid)

        state = manager._load_state()
        rec = state.sessions[sid]
        assert rec.workspace_root == original_root
        assert rec.execution_dir == original_exec
        assert rec.status == SessionStatus.LIVE
        await manager.shutdown()

    async def test_resume_missing_workspace_raises(
        self,
        manager: SessionManager,
        git_repo: Path,
        worktree_root: Path,
    ) -> None:
        sid = await manager.create_session(
            working_dir=str(git_repo),
            worktree_root_override=worktree_root,
        )
        state = manager._load_state()
        ws_root = state.sessions[sid].workspace_root

        await manager.kill_session(sid)

        # Delete the worktree directory
        import shutil

        shutil.rmtree(ws_root)

        with pytest.raises(ValueError, match="[Ww]orkspace"):
            await manager.resume_session(sid)


class TestLegacySessionCompatibility:
    async def test_legacy_session_resumes_in_shared_mode(
        self,
        manager: SessionManager,
        tmp_path: Path,
    ) -> None:
        plain_dir = tmp_path / "legacy-project"
        plain_dir.mkdir()
        sid = await manager.create_session(working_dir=str(plain_dir))
        await manager.kill_session(sid)
        rec = await manager.resume_session(sid)
        assert rec.workspace_mode == "shared"
        assert rec.status == SessionStatus.LIVE
        await manager.shutdown()
