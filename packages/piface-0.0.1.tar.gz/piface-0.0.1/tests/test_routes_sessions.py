"""Tests for session REST routes."""

import base64
import subprocess
import sys
from pathlib import Path

import httpx
import pytest
from fastapi import FastAPI

from piface.routes.sessions import create_sessions_router
from piface.session_manager import SessionManager
from piface.state import SessionStatus

FAKE_PI_SCRIPT = """\
import json, sys, uuid

current_session_file = "/tmp/fake.jsonl"

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    try:
        cmd = json.loads(line)
    except Exception:
        continue

    cmd_type = cmd.get("type", "")
    cmd_id = cmd.get("id")

    if cmd_type == "fork":
        current_session_file = f"/tmp/forked-{uuid.uuid4().hex}.jsonl"
        resp = {
            "type": "response",
            "command": "fork",
            "success": True,
            "data": {"text": "Forked prompt text", "cancelled": False},
        }
    elif cmd_type == "get_state":
        resp = {
            "type": "response",
            "command": "get_state",
            "success": True,
            "data": {"sessionFile": current_session_file, "isStreaming": False},
        }
    elif cmd_type == "get_fork_messages":
        resp = {
            "type": "response",
            "command": "get_fork_messages",
            "success": True,
            "data": {
                "messages": [
                    {"entryId": "entry-1", "text": "First prompt"},
                    {"entryId": "entry-2", "text": "Second prompt"},
                ]
            },
        }
    else:
        resp = {"type": "response", "command": cmd_type, "success": True}

    if cmd_id:
        resp["id"] = cmd_id

    sys.stdout.write(json.dumps(resp) + "\\n")
    sys.stdout.flush()
"""

FAILING_PI_SCRIPT = """\
import sys

sys.stderr.write("direnv: error /tmp/project/.envrc is blocked\\n")
sys.stderr.flush()
raise SystemExit(1)
"""


def _init_git_repo(path: Path) -> None:
    subprocess.run(["git", "init"], cwd=path, check=True, capture_output=True, text=True)
    (path / "tracked.txt").write_text("line1\n")
    subprocess.run(
        ["git", "add", "tracked.txt"],
        cwd=path,
        check=True,
        capture_output=True,
        text=True,
    )
    subprocess.run(
        [
            "git",
            "-c",
            "user.name=Piface Tests",
            "-c",
            "user.email=piface-tests@example.com",
            "commit",
            "-m",
            "initial",
        ],
        cwd=path,
        check=True,
        capture_output=True,
        text=True,
    )


@pytest.fixture
def fake_pi_script(tmp_path: Path) -> Path:
    script = tmp_path / "fake_pi.py"
    script.write_text(FAKE_PI_SCRIPT)
    return script


@pytest.fixture
def failing_pi_script(tmp_path: Path) -> Path:
    script = tmp_path / "failing_pi.py"
    script.write_text(FAILING_PI_SCRIPT)
    return script


@pytest.fixture
def manager(tmp_path: Path, fake_pi_script: Path) -> SessionManager:
    mgr = SessionManager(state_path=tmp_path / "state.json")
    mgr._pi_command_override = [sys.executable, str(fake_pi_script)]
    return mgr


@pytest.fixture
def app(manager: SessionManager) -> FastAPI:
    app = FastAPI()
    app.state.session_manager = manager
    app.include_router(create_sessions_router(), prefix="/api")
    return app


@pytest.fixture
async def client(app: FastAPI) -> httpx.AsyncClient:
    transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        yield c  # type: ignore[misc]


class TestListSessions:
    @pytest.mark.asyncio
    async def test_empty_list(self, client: httpx.AsyncClient) -> None:
        resp = await client.get("/api/sessions")
        assert resp.status_code == 200
        assert resp.json() == {"sessions": []}


class TestCreateSession:
    @pytest.mark.asyncio
    async def test_create_session(
        self, client: httpx.AsyncClient, tmp_path: Path, manager: SessionManager
    ) -> None:
        resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        assert resp.status_code == 201
        data = resp.json()
        assert "piface_id" in data
        assert data["status"] == "live"
        assert data["model_provider"] == "openai-codex"
        assert data["model_id"] == "gpt-5.5-codex"
        assert data["thinking_level"] == "medium"
        assert data["render_markdown"] is True
        assert data["use_direnv"] is True
        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_create_session_with_options(
        self, client: httpx.AsyncClient, tmp_path: Path, manager: SessionManager
    ) -> None:
        resp = await client.post(
            "/api/sessions",
            json={
                "working_dir": str(tmp_path),
                "provider": "anthropic",
                "model": "claude-sonnet-4-20250514",
                "thinking_level": "high",
                "session_name": "test",
                "render_markdown": False,
                "use_direnv": False,
            },
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["model_provider"] == "anthropic"
        assert data["session_name"] == "test"
        assert data["render_markdown"] is False
        assert data["use_direnv"] is False
        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_create_then_list(
        self, client: httpx.AsyncClient, tmp_path: Path, manager: SessionManager
    ) -> None:
        await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        await client.post("/api/sessions", json={"working_dir": str(tmp_path)})

        resp = await client.get("/api/sessions")
        assert resp.status_code == 200
        assert len(resp.json()["sessions"]) == 2
        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_create_session_bad_dir(self, client: httpx.AsyncClient) -> None:
        resp = await client.post(
            "/api/sessions",
            json={"working_dir": "/nonexistent/path/that/should/not/exist"},
        )
        assert resp.status_code == 400

    @pytest.mark.asyncio
    async def test_create_session_start_failure_returns_conflict(
        self,
        client: httpx.AsyncClient,
        tmp_path: Path,
        manager: SessionManager,
        failing_pi_script: Path,
    ) -> None:
        manager._pi_command_override = [sys.executable, str(failing_pi_script)]

        resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        assert resp.status_code == 409
        assert "exited immediately" in resp.json()["detail"].lower()


class TestKillSession:
    @pytest.mark.asyncio
    async def test_kill_session(
        self, client: httpx.AsyncClient, tmp_path: Path, manager: SessionManager
    ) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        resp = await client.post(f"/api/sessions/{sid}/kill")
        assert resp.status_code == 200
        assert resp.json()["status"] == "closed"

    @pytest.mark.asyncio
    async def test_kill_nonexistent(self, client: httpx.AsyncClient) -> None:
        resp = await client.post("/api/sessions/nonexistent/kill")
        assert resp.status_code == 404


class TestResumeSession:
    @pytest.mark.asyncio
    async def test_resume_closed_session(self, client: httpx.AsyncClient, tmp_path: Path) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        kill_resp = await client.post(f"/api/sessions/{sid}/kill")
        assert kill_resp.status_code == 200
        assert kill_resp.json()["status"] == "closed"

        resp = await client.post(f"/api/sessions/{sid}/resume")
        assert resp.status_code == 200
        assert resp.json()["status"] == "live"

    @pytest.mark.asyncio
    async def test_resume_nonexistent(self, client: httpx.AsyncClient) -> None:
        resp = await client.post("/api/sessions/nonexistent/resume")
        assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_resume_ephemeral_rejected(
        self, client: httpx.AsyncClient, tmp_path: Path
    ) -> None:
        create_resp = await client.post(
            "/api/sessions",
            json={"working_dir": str(tmp_path), "no_session": True},
        )
        sid = create_resp.json()["piface_id"]

        kill_resp = await client.post(f"/api/sessions/{sid}/kill")
        assert kill_resp.status_code == 200

        resp = await client.post(f"/api/sessions/{sid}/resume")
        assert resp.status_code == 409
        assert "ephemeral" in resp.json()["detail"].lower()

    @pytest.mark.asyncio
    async def test_resume_live_session_rejected(
        self, client: httpx.AsyncClient, tmp_path: Path
    ) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        resp = await client.post(f"/api/sessions/{sid}/resume")
        assert resp.status_code == 409
        assert "already live" in resp.json()["detail"].lower()

    @pytest.mark.asyncio
    async def test_resume_start_failure_returns_conflict(
        self,
        client: httpx.AsyncClient,
        tmp_path: Path,
        manager: SessionManager,
        failing_pi_script: Path,
    ) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        kill_resp = await client.post(f"/api/sessions/{sid}/kill")
        assert kill_resp.status_code == 200

        manager._pi_command_override = [sys.executable, str(failing_pi_script)]

        resp = await client.post(f"/api/sessions/{sid}/resume")
        assert resp.status_code == 409
        assert "exited immediately" in resp.json()["detail"].lower()


class TestDirenvAllow:
    @pytest.mark.asyncio
    async def test_allow_direnv_success(
        self,
        client: httpx.AsyncClient,
        manager: SessionManager,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        called: dict[str, str] = {}

        async def fake_allow(working_dir: str) -> None:
            called["working_dir"] = working_dir

        monkeypatch.setattr(manager, "allow_direnv", fake_allow)

        resp = await client.post("/api/direnv/allow", json={"working_dir": str(tmp_path)})
        assert resp.status_code == 200
        assert resp.json() == {"success": True, "working_dir": str(tmp_path)}
        assert called["working_dir"] == str(tmp_path)

    @pytest.mark.asyncio
    async def test_allow_direnv_bad_dir(self, client: httpx.AsyncClient) -> None:
        resp = await client.post(
            "/api/direnv/allow",
            json={"working_dir": "/nonexistent/path/that/should/not/exist"},
        )
        assert resp.status_code == 400

    @pytest.mark.asyncio
    async def test_allow_direnv_failure_returns_conflict(
        self,
        client: httpx.AsyncClient,
        manager: SessionManager,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        async def fake_allow(_: str) -> None:
            raise RuntimeError("direnv failed")

        monkeypatch.setattr(manager, "allow_direnv", fake_allow)

        resp = await client.post("/api/direnv/allow", json={"working_dir": str(tmp_path)})
        assert resp.status_code == 409
        assert "direnv failed" in resp.json()["detail"]


class TestUpdateSession:
    @pytest.mark.asyncio
    async def test_patch_render_markdown(self, client: httpx.AsyncClient, tmp_path: Path) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        resp = await client.patch(
            f"/api/sessions/{sid}",
            json={"render_markdown": False},
        )
        assert resp.status_code == 200
        assert resp.json()["render_markdown"] is False

    @pytest.mark.asyncio
    async def test_patch_session_nonexistent(self, client: httpx.AsyncClient) -> None:
        resp = await client.patch("/api/sessions/nonexistent", json={"render_markdown": False})
        assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_patch_session_requires_payload(
        self, client: httpx.AsyncClient, tmp_path: Path
    ) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        resp = await client.patch(f"/api/sessions/{sid}", json={})
        assert resp.status_code == 400


class TestSessionLookupAndHistory:
    @pytest.mark.asyncio
    async def test_get_session_by_id(self, client: httpx.AsyncClient, tmp_path: Path) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        resp = await client.get(f"/api/sessions/{sid}")
        assert resp.status_code == 200
        assert resp.json()["piface_id"] == sid

    @pytest.mark.asyncio
    async def test_get_session_by_id_nonexistent(self, client: httpx.AsyncClient) -> None:
        resp = await client.get("/api/sessions/nonexistent")
        assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_get_closed_session_history_from_session_file(
        self, client: httpx.AsyncClient, manager: SessionManager, tmp_path: Path
    ) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        session_file = tmp_path / "session.jsonl"
        session_file.write_text(
            "\n".join(
                [
                    '{"type":"session","version":3,"id":"abc","cwd":"/tmp"}',
                    '{"type":"message","message":{"role":"user","content":[{"type":"text","text":"hi"}],"timestamp":1}}',
                    '{"type":"message","message":{"role":"assistant","content":[{"type":"text","text":"hello"}],"timestamp":2}}',
                    '{"type":"message","message":{"role":"toolResult","toolName":"bash","content":[{"type":"text","text":"ok"}],"isError":false,"timestamp":3}}',
                ]
            )
            + "\n"
        )

        # Mark session closed and attach its persisted pi session file.
        state = manager._load_state()
        state.sessions[sid].status = SessionStatus.CLOSED
        state.sessions[sid].session_file = str(session_file)
        manager._save_state(state)

        resp = await client.get(f"/api/sessions/{sid}/history")
        assert resp.status_code == 200
        data = resp.json()
        assert data["source"] == "session_file"
        assert data["error"] is None
        assert [m["role"] for m in data["messages"]] == ["user", "assistant", "toolResult"]

    @pytest.mark.asyncio
    async def test_get_closed_session_history_missing_session_file(
        self, client: httpx.AsyncClient, manager: SessionManager, tmp_path: Path
    ) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        state = manager._load_state()
        state.sessions[sid].status = SessionStatus.CLOSED
        state.sessions[sid].session_file = str(tmp_path / "missing.jsonl")
        manager._save_state(state)

        resp = await client.get(f"/api/sessions/{sid}/history")
        assert resp.status_code == 200
        data = resp.json()
        assert data["messages"] == []
        assert data["source"] == "session_file"
        assert data["error"] == "file_not_found"


class TestForkMessagesAndBranching:
    @pytest.mark.asyncio
    async def test_get_fork_messages_live_session(
        self, client: httpx.AsyncClient, tmp_path: Path
    ) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        resp = await client.get(f"/api/sessions/{sid}/fork-messages")
        assert resp.status_code == 200
        data = resp.json()
        assert data["messages"][0]["entryId"] == "entry-1"
        assert data["messages"][0]["text"] == "First prompt"

    @pytest.mark.asyncio
    async def test_get_fork_messages_from_archived_session_file(
        self, client: httpx.AsyncClient, manager: SessionManager, tmp_path: Path
    ) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        session_file = tmp_path / "session.jsonl"
        session_file.write_text(
            "\n".join(
                [
                    '{"type":"session","version":3,"id":"abc","cwd":"/tmp"}',
                    '{"type":"message","id":"u1","message":{"role":"user","content":[{"type":"text","text":"hello"}],"timestamp":1}}',
                    '{"type":"message","id":"a1","message":{"role":"assistant","content":[{"type":"text","text":"hi"}],"timestamp":2}}',
                    '{"type":"message","id":"u2","message":{"role":"user","content":"redo","timestamp":3}}',
                ]
            )
            + "\n"
        )

        state = manager._load_state()
        state.sessions[sid].status = SessionStatus.CLOSED
        state.sessions[sid].session_file = str(session_file)
        manager._save_state(state)

        resp = await client.get(f"/api/sessions/{sid}/fork-messages")
        assert resp.status_code == 200
        data = resp.json()
        assert data["messages"] == [
            {"entryId": "u1", "text": "hello"},
            {"entryId": "u2", "text": "redo"},
        ]

    @pytest.mark.asyncio
    async def test_branch_session_creates_new_session_record(
        self, client: httpx.AsyncClient, manager: SessionManager, tmp_path: Path
    ) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        source_session_file = tmp_path / "source-session.jsonl"
        source_session_file.write_text('{"type":"session"}\n')

        state = manager._load_state()
        state.sessions[sid].session_file = str(source_session_file)
        manager._save_state(state)

        resp = await client.post(
            f"/api/sessions/{sid}/branch",
            json={"entry_id": "entry-1", "session_name": "branch-a"},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["cancelled"] is False
        assert data["selected_text"] == "Forked prompt text"
        assert data["session"]["piface_id"] != sid
        assert data["session"]["session_name"] == "branch-a"
        assert data["session"]["parent_piface_id"] == sid
        assert data["session"]["branch_entry_id"] == "entry-1"

    @pytest.mark.asyncio
    async def test_branch_clones_upload_refs_and_shared_blob_survives_parent_delete(
        self, client: httpx.AsyncClient, manager: SessionManager, tmp_path: Path
    ) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        source_session_file = tmp_path / "source-session.jsonl"
        source_session_file.write_text('{"type":"session"}\n')
        state = manager._load_state()
        state.sessions[sid].session_file = str(source_session_file)
        manager._save_state(state)

        upload_resp = await client.post(
            f"/api/sessions/{sid}/uploads",
            json={
                "files": [
                    {
                        "file_name": "photo.png",
                        "mime_type": "image/png",
                        "data": base64.b64encode(b"png-bytes").decode("ascii"),
                    }
                ]
            },
        )
        assert upload_resp.status_code == 200
        upload_path = Path(upload_resp.json()["uploads"][0]["path"])
        assert upload_path.exists()

        branch_resp = await client.post(
            f"/api/sessions/{sid}/branch",
            json={"entry_id": "entry-1"},
        )
        assert branch_resp.status_code == 201
        branched_id = branch_resp.json()["session"]["piface_id"]

        manager.remove_record(sid)
        assert upload_path.exists()

        manager.remove_record(branched_id)
        assert not upload_path.exists()


class TestFileUploads:
    @pytest.mark.asyncio
    async def test_upload_image_to_session(
        self, client: httpx.AsyncClient, manager: SessionManager, tmp_path: Path
    ) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        session_file = tmp_path / "session.jsonl"
        session_file.write_text('{"type":"session"}\n')

        state = manager._load_state()
        state.sessions[sid].session_file = str(session_file)
        manager._save_state(state)

        image_bytes = b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR"
        payload = {
            "files": [
                {
                    "file_name": "photo.png",
                    "mime_type": "image/png",
                    "data": base64.b64encode(image_bytes).decode("ascii"),
                }
            ]
        }

        resp = await client.post(f"/api/sessions/{sid}/uploads", json=payload)
        assert resp.status_code == 200

        data = resp.json()
        assert len(data["uploads"]) == 1
        upload = data["uploads"][0]
        assert upload["mime_type"] == "image/png"
        assert upload["size"] == len(image_bytes)
        upload_path = Path(upload["path"])
        assert upload_path.is_file()
        assert upload_path.read_bytes() == image_bytes
        assert "/uploads/_shared/" in upload["path"]

    @pytest.mark.asyncio
    async def test_upload_requires_persisted_session_file(
        self, client: httpx.AsyncClient, tmp_path: Path
    ) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        payload = {
            "files": [
                {
                    "file_name": "photo.png",
                    "mime_type": "image/png",
                    "data": base64.b64encode(b"png").decode("ascii"),
                }
            ]
        }
        resp = await client.post(f"/api/sessions/{sid}/uploads", json=payload)

        assert resp.status_code == 409
        assert "session file" in resp.json()["detail"].lower()

    @pytest.mark.asyncio
    async def test_upload_accepts_non_image_mime(
        self, client: httpx.AsyncClient, manager: SessionManager, tmp_path: Path
    ) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        session_file = tmp_path / "session.jsonl"
        session_file.write_text('{"type":"session"}\n')
        state = manager._load_state()
        state.sessions[sid].session_file = str(session_file)
        manager._save_state(state)

        text_bytes = b"hello world"
        payload = {
            "files": [
                {
                    "file_name": "note.txt",
                    "mime_type": "text/plain",
                    "data": base64.b64encode(text_bytes).decode("ascii"),
                }
            ]
        }
        resp = await client.post(f"/api/sessions/{sid}/uploads", json=payload)

        assert resp.status_code == 200
        data = resp.json()
        assert len(data["uploads"]) == 1
        upload = data["uploads"][0]
        assert upload["mime_type"] == "text/plain"
        assert upload["size"] == len(text_bytes)
        assert Path(upload["path"]).read_bytes() == text_bytes

    @pytest.mark.asyncio
    async def test_remove_directory_cleans_session_uploads(
        self, client: httpx.AsyncClient, manager: SessionManager, tmp_path: Path
    ) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        session_file = tmp_path / "session.jsonl"
        session_file.write_text('{"type":"session"}\n')
        state = manager._load_state()
        state.sessions[sid].session_file = str(session_file)
        manager._save_state(state)

        upload_resp = await client.post(
            f"/api/sessions/{sid}/uploads",
            json={
                "files": [
                    {
                        "file_name": "photo.png",
                        "mime_type": "image/png",
                        "data": base64.b64encode(b"png-bytes").decode("ascii"),
                    }
                ]
            },
        )
        assert upload_resp.status_code == 200
        upload_path = Path(upload_resp.json()["uploads"][0]["path"])
        assert upload_path.exists()

        remove_resp = await client.post("/api/directories/remove", json={"path": str(tmp_path)})
        assert remove_resp.status_code == 200

        assert not upload_path.exists()


class TestGitDiffRoutes:
    @pytest.mark.asyncio
    async def test_git_status_non_repo(self, client: httpx.AsyncClient, tmp_path: Path) -> None:
        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        resp = await client.get(f"/api/sessions/{sid}/git/status")
        assert resp.status_code == 200
        data = resp.json()
        assert data["is_repo"] is False
        assert data["files"] == []

    @pytest.mark.asyncio
    async def test_git_status_lists_changed_files(
        self, client: httpx.AsyncClient, tmp_path: Path
    ) -> None:
        _init_git_repo(tmp_path)

        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        session_data = create_resp.json()
        sid = session_data["piface_id"]
        exec_dir = Path(session_data["execution_dir"])

        # Modify files in the execution dir (worktree), not the original repo
        (exec_dir / "tracked.txt").write_text("line1\nline2\n")
        (exec_dir / "new.txt").write_text("new file\n")

        resp = await client.get(f"/api/sessions/{sid}/git/status")
        assert resp.status_code == 200

        files = {entry["path"]: entry for entry in resp.json()["files"]}
        assert files["tracked.txt"]["unstaged"] is True
        assert files["tracked.txt"]["status"] == " M"
        assert files["new.txt"]["untracked"] is True
        assert files["new.txt"]["status"] == "??"

    @pytest.mark.asyncio
    async def test_git_diff_for_modified_file(
        self, client: httpx.AsyncClient, tmp_path: Path
    ) -> None:
        _init_git_repo(tmp_path)

        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        session_data = create_resp.json()
        sid = session_data["piface_id"]
        exec_dir = Path(session_data["execution_dir"])

        (exec_dir / "tracked.txt").write_text("line1\nline2\n")

        resp = await client.get(
            f"/api/sessions/{sid}/git/diff",
            params={"path": "tracked.txt", "staged": "false"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["is_repo"] is True
        assert data["diff"]
        assert "+line2" in data["diff"]

    @pytest.mark.asyncio
    async def test_git_diff_for_untracked_file(
        self, client: httpx.AsyncClient, tmp_path: Path
    ) -> None:
        _init_git_repo(tmp_path)

        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        session_data = create_resp.json()
        sid = session_data["piface_id"]
        exec_dir = Path(session_data["execution_dir"])

        (exec_dir / "new.txt").write_text("hello\n")

        resp = await client.get(
            f"/api/sessions/{sid}/git/diff",
            params={"path": "new.txt", "staged": "false"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["is_repo"] is True
        assert "--- /dev/null" in data["diff"]
        assert "+++ b/new.txt" in data["diff"]

    @pytest.mark.asyncio
    async def test_git_diff_rejects_path_outside_repo(
        self, client: httpx.AsyncClient, tmp_path: Path
    ) -> None:
        _init_git_repo(tmp_path)

        create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
        sid = create_resp.json()["piface_id"]

        resp = await client.get(
            f"/api/sessions/{sid}/git/diff",
            params={"path": "../outside.txt", "staged": "false"},
        )
        assert resp.status_code == 400


class TestDirectoryBrowsing:
    @pytest.mark.asyncio
    async def test_list_dir(self, client: httpx.AsyncClient, tmp_path: Path) -> None:
        (tmp_path / "subdir").mkdir()
        (tmp_path / "file.txt").write_text("hello")

        resp = await client.get("/api/fs/list", params={"path": str(tmp_path)})
        assert resp.status_code == 200
        entries = resp.json()["entries"]
        names = {e["name"] for e in entries}
        assert "subdir" in names
        assert "file.txt" in names

        subdir_entry = next(e for e in entries if e["name"] == "subdir")
        file_entry = next(e for e in entries if e["name"] == "file.txt")
        assert subdir_entry["is_dir"] is True
        assert file_entry["is_dir"] is False

    @pytest.mark.asyncio
    async def test_list_nonexistent_dir(self, client: httpx.AsyncClient) -> None:
        resp = await client.get("/api/fs/list", params={"path": "/nonexistent/path"})
        assert resp.status_code == 400

    @pytest.mark.asyncio
    async def test_complete_dir(self, client: httpx.AsyncClient, tmp_path: Path) -> None:
        (tmp_path / "projects").mkdir()
        (tmp_path / "photos").mkdir()

        resp = await client.get("/api/fs/complete", params={"prefix": str(tmp_path / "pro")})
        assert resp.status_code == 200
        matches = resp.json()["matches"]
        assert any("projects" in m for m in matches)

    @pytest.mark.asyncio
    async def test_complete_no_matches(self, client: httpx.AsyncClient, tmp_path: Path) -> None:
        resp = await client.get("/api/fs/complete", params={"prefix": str(tmp_path / "zzz")})
        assert resp.status_code == 200
        assert resp.json()["matches"] == []

    @pytest.mark.asyncio
    async def test_preview_text_file(self, client: httpx.AsyncClient, tmp_path: Path) -> None:
        p = tmp_path / "notes.md"
        p.write_text("# Hello\n\nworld")

        resp = await client.get("/api/fs/file", params={"path": str(p)})
        assert resp.status_code == 200
        data = resp.json()
        assert data["kind"] == "markdown"
        assert data["content"] == "# Hello\n\nworld"
        assert data["size"] == len("# Hello\n\nworld")

    @pytest.mark.asyncio
    async def test_preview_rejects_large_text_file(
        self, client: httpx.AsyncClient, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from piface.routes import sessions as sessions_routes

        monkeypatch.setattr(sessions_routes, "_MAX_TEXT_PREVIEW_BYTES", 8)
        p = tmp_path / "big.txt"
        p.write_text("0123456789")

        resp = await client.get("/api/fs/file", params={"path": str(p)})
        assert resp.status_code == 413

    @pytest.mark.asyncio
    async def test_preview_binary_file(self, client: httpx.AsyncClient, tmp_path: Path) -> None:
        p = tmp_path / "archive.bin"
        p.write_bytes(b"\x00\x01\x02")

        resp = await client.get("/api/fs/file", params={"path": str(p)})
        assert resp.status_code == 200
        data = resp.json()
        assert data["kind"] == "binary"
        assert data["content"] is None

    @pytest.mark.asyncio
    async def test_raw_file(self, client: httpx.AsyncClient, tmp_path: Path) -> None:
        p = tmp_path / "index.html"
        p.write_text("<h1>hi</h1>")

        resp = await client.get("/api/fs/raw", params={"path": str(p)})
        assert resp.status_code == 200
        assert "text/html" in resp.headers.get("content-type", "")
        assert "<h1>hi</h1>" in resp.text

    @pytest.mark.asyncio
    async def test_raw_rejects_large_file(
        self, client: httpx.AsyncClient, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from piface.routes import sessions as sessions_routes

        monkeypatch.setattr(sessions_routes, "_MAX_RAW_PREVIEW_BYTES", 4)
        p = tmp_path / "photo.png"
        p.write_bytes(b"123456")

        resp = await client.get("/api/fs/raw", params={"path": str(p)})
        assert resp.status_code == 413
