"""Tests for workspace manager: project resolution, naming, and worktree lifecycle."""

from __future__ import annotations

import asyncio
import re
import subprocess
from pathlib import Path

import pytest

from piface.workspace_config import (
    WorkspaceConfig,
    WorkspaceSection,
)
from piface.workspace_manager import WorkspaceManager


@pytest.fixture
def manager(tmp_path: Path) -> WorkspaceManager:
    return WorkspaceManager(data_dir=tmp_path / "piface-data")


class TestProjectResolution:
    async def test_resolve_from_repo_root(
        self, manager: WorkspaceManager, git_repo: Path
    ) -> None:
        info = await manager.resolve_project(str(git_repo))
        assert info.project_dir == str(git_repo)
        assert info.project_subdir == "."
        assert info.is_git is True

    async def test_resolve_from_subdirectory(
        self, manager: WorkspaceManager, git_repo_with_subdir: Path
    ) -> None:
        subdir = git_repo_with_subdir / "apps" / "api"
        info = await manager.resolve_project(str(subdir))
        assert info.project_dir == str(git_repo_with_subdir)
        assert info.project_subdir == "apps/api"
        assert info.is_git is True

    async def test_resolve_non_git_directory(
        self, manager: WorkspaceManager, tmp_path: Path
    ) -> None:
        plain_dir = tmp_path / "not-a-repo"
        plain_dir.mkdir()
        info = await manager.resolve_project(str(plain_dir))
        assert info.is_git is False
        assert info.project_dir == str(plain_dir)
        assert info.project_subdir == "."

    async def test_resolve_nonexistent_raises(
        self, manager: WorkspaceManager, tmp_path: Path
    ) -> None:
        with pytest.raises(ValueError, match="does not exist"):
            await manager.resolve_project(str(tmp_path / "nope"))


class TestNameGeneration:
    def test_slugify_basic(self, manager: WorkspaceManager) -> None:
        assert manager._slugify("My Feature!") == "my-feature"

    def test_slugify_special_chars(self, manager: WorkspaceManager) -> None:
        slug = manager._slugify("héllo wörld @#$")
        assert re.match(r"^[a-z0-9-]+$", slug)

    def test_slugify_leading_trailing(self, manager: WorkspaceManager) -> None:
        slug = manager._slugify("---test---")
        assert not slug.startswith("-")
        assert not slug.endswith("-")

    def test_short_id_format(self, manager: WorkspaceManager) -> None:
        sid = manager._short_id()
        assert re.match(r"^[a-f0-9]{6}$", sid)

    def test_short_id_unique(self, manager: WorkspaceManager) -> None:
        ids = {manager._short_id() for _ in range(100)}
        assert len(ids) > 90  # very unlikely to have many collisions

    def test_project_slug_deterministic(self, manager: WorkspaceManager) -> None:
        slug1 = manager._project_slug("/home/user/project")
        slug2 = manager._project_slug("/home/user/project")
        assert slug1 == slug2

    def test_project_slug_includes_name_and_hash(
        self, manager: WorkspaceManager
    ) -> None:
        slug = manager._project_slug("/home/user/my-project")
        assert "my-project" in slug
        # Should have a hash suffix separated by dash
        parts = slug.rsplit("-", 1)
        assert len(parts) == 2
        assert re.match(r"^[a-f0-9]+$", parts[1])

    def test_generate_workspace_name_filesystem_safe(
        self, manager: WorkspaceManager
    ) -> None:
        from piface.workspace_config import default_workspace_config

        config = default_workspace_config()
        name = manager.generate_workspace_name(
            config,
            session_name="My Feature / test",
            project_dir="/home/user/project",
            project_subdir=".",
        )
        assert re.match(r"^[a-z0-9-]+$", name)
        assert len(name) > 6  # at least slug + short_id

    def test_generate_workspace_name_uses_session_name(
        self, manager: WorkspaceManager
    ) -> None:
        from piface.workspace_config import default_workspace_config

        config = default_workspace_config()
        name = manager.generate_workspace_name(
            config,
            session_name="agent-ui",
            project_dir="/home/user/project",
            project_subdir=".",
        )
        assert "agent-ui" in name

    def test_generate_workspace_name_unique(
        self, manager: WorkspaceManager
    ) -> None:
        from piface.workspace_config import default_workspace_config

        config = default_workspace_config()
        names = {
            manager.generate_workspace_name(
                config,
                session_name="same",
                project_dir="/home/user/project",
                project_subdir=".",
            )
            for _ in range(50)
        }
        assert len(names) == 50


class TestBaseRefResolution:
    async def test_current_branch(
        self, manager: WorkspaceManager, git_repo: Path
    ) -> None:
        from piface.workspace_config import default_workspace_config

        config = default_workspace_config()
        ref = await manager.resolve_base_ref(str(git_repo), config)
        assert ref == "main"

    async def test_explicit_ref(
        self, manager: WorkspaceManager, git_repo: Path
    ) -> None:

        config = WorkspaceConfig(
            workspace=WorkspaceSection(default_base="main"),
        )
        ref = await manager.resolve_base_ref(str(git_repo), config)
        assert ref == "main"

    async def test_source_branch_overrides_config(
        self, manager: WorkspaceManager, git_repo: Path
    ) -> None:
        from piface.workspace_config import default_workspace_config

        # Create a side branch
        subprocess.run(
            ["git", "branch", "feature-x"],
            cwd=git_repo,
            check=True,
            capture_output=True,
        )
        config = default_workspace_config()
        ref = await manager.resolve_base_ref(
            str(git_repo), config, source_branch="feature-x"
        )
        assert ref == "feature-x"


class TestWorktreeCreation:
    async def test_create_worktree_from_current_branch(
        self, manager: WorkspaceManager, git_repo: Path, worktree_root: Path
    ) -> None:
        info = await manager.resolve_project(str(git_repo))
        ws = await manager.create_workspace(
            info, session_name="test", worktree_root_override=worktree_root
        )
        assert Path(ws.workspace_root).is_dir()
        assert Path(ws.execution_dir).is_dir()
        # Worktree HEAD should match repo HEAD
        proc = subprocess.run(
            ["git", "-C", ws.workspace_root, "rev-parse", "HEAD"],
            capture_output=True, text=True, check=True,
        )
        repo_proc = subprocess.run(
            ["git", "-C", str(git_repo), "rev-parse", "HEAD"],
            capture_output=True, text=True, check=True,
        )
        assert proc.stdout.strip() == repo_proc.stdout.strip()

    async def test_worktree_name_is_unique(
        self, manager: WorkspaceManager, git_repo: Path, worktree_root: Path
    ) -> None:
        info = await manager.resolve_project(str(git_repo))
        ws1 = await manager.create_workspace(
            info, session_name="test", worktree_root_override=worktree_root
        )
        ws2 = await manager.create_workspace(
            info, session_name="test", worktree_root_override=worktree_root
        )
        assert ws1.workspace_name != ws2.workspace_name
        assert ws1.workspace_root != ws2.workspace_root
        assert ws1.workspace_branch != ws2.workspace_branch

    async def test_worktree_contains_repo_files(
        self, manager: WorkspaceManager, git_repo: Path, worktree_root: Path
    ) -> None:
        info = await manager.resolve_project(str(git_repo))
        ws = await manager.create_workspace(
            info, session_name="test", worktree_root_override=worktree_root
        )
        assert (Path(ws.workspace_root) / "tracked.txt").exists()

    async def test_create_worktree_with_subdir_sets_execution_dir(
        self, manager: WorkspaceManager, git_repo_with_subdir: Path, worktree_root: Path
    ) -> None:
        subdir = git_repo_with_subdir / "apps" / "api"
        info = await manager.resolve_project(str(subdir))
        ws = await manager.create_workspace(
            info, session_name="test", worktree_root_override=worktree_root
        )
        assert ws.execution_dir == str(Path(ws.workspace_root) / "apps" / "api")
        assert Path(ws.execution_dir).is_dir()

    async def test_worktree_root_outside_project(
        self, manager: WorkspaceManager, git_repo: Path, worktree_root: Path
    ) -> None:
        info = await manager.resolve_project(str(git_repo))
        ws = await manager.create_workspace(
            info, session_name="test", worktree_root_override=worktree_root
        )
        assert not Path(ws.workspace_root).is_relative_to(git_repo)

    async def test_branch_name_is_valid_git_ref(
        self, manager: WorkspaceManager, git_repo: Path, worktree_root: Path
    ) -> None:
        info = await manager.resolve_project(str(git_repo))
        ws = await manager.create_workspace(
            info, session_name="test", worktree_root_override=worktree_root
        )
        result = subprocess.run(
            ["git", "check-ref-format", "--branch", ws.workspace_branch],
            capture_output=True,
        )
        assert result.returncode == 0


class TestFileMaterialization:
    async def test_copy_env_files(
        self, manager: WorkspaceManager, git_repo_with_env_file: Path, worktree_root: Path
    ) -> None:
        # Write config with copy = [".env"]
        config_dir = git_repo_with_env_file / ".piface"
        config_dir.mkdir(exist_ok=True)
        (config_dir / "workspace.toml").write_text(f"""\
version = 1
[workspace]
root = "{worktree_root}"
[files]
copy = [".env"]
""")
        info = await manager.resolve_project(str(git_repo_with_env_file))
        ws = await manager.create_workspace(
            info, session_name="test", worktree_root_override=worktree_root
        )
        copied = Path(ws.workspace_root) / ".env"
        assert copied.exists()
        assert copied.read_text() == "SECRET=abc\n"

    async def test_copy_missing_source_logs_warning(
        self,
        manager: WorkspaceManager,
        git_repo: Path,
        worktree_root: Path,
        caplog: pytest.LogCaptureFixture,
    ) -> None:
        config_dir = git_repo / ".piface"
        config_dir.mkdir(exist_ok=True)
        (config_dir / "workspace.toml").write_text(f"""\
version = 1
[workspace]
root = "{worktree_root}"
[files]
copy = [".env.nonexistent"]
""")
        info = await manager.resolve_project(str(git_repo))
        # Should not raise
        ws = await manager.create_workspace(
            info, session_name="test", worktree_root_override=worktree_root
        )
        assert not (Path(ws.workspace_root) / ".env.nonexistent").exists()
        log_text = caplog.text.lower()
        assert "not found" in log_text or "missing" in log_text or "skip" in log_text

    async def test_direnv_allowed_in_worktree_with_envrc(
        self, manager: WorkspaceManager, git_repo: Path, worktree_root: Path
    ) -> None:
        """When .envrc is tracked in the repo, direnv allow runs in worktree."""
        (git_repo / ".envrc").write_text("export FOO=bar\n")
        subprocess.run(
            ["git", "-c", "user.name=Test", "-c", "user.email=test@test.com",
             "add", ".envrc"],
            cwd=git_repo, check=True, capture_output=True,
        )
        subprocess.run(
            ["git", "-c", "user.name=Test", "-c", "user.email=test@test.com",
             "commit", "-m", "add envrc"],
            cwd=git_repo, check=True, capture_output=True,
        )
        info = await manager.resolve_project(str(git_repo))
        ws = await manager.create_workspace(
            info, session_name="test", worktree_root_override=worktree_root
        )
        # .envrc should exist in worktree (checked out from git)
        assert (Path(ws.workspace_root) / ".envrc").exists()
        # direnv allow should have been run, so direnv exec should work
        proc = subprocess.run(
            ["direnv", "exec", ws.workspace_root, "bash", "-c", "echo ok"],
            capture_output=True, text=True,
        )
        assert proc.returncode == 0
        assert "ok" in proc.stdout

    async def test_symlink_file(
        self, manager: WorkspaceManager, git_repo_with_env_file: Path, worktree_root: Path
    ) -> None:
        config_dir = git_repo_with_env_file / ".piface"
        config_dir.mkdir(exist_ok=True)
        (config_dir / "workspace.toml").write_text(f"""\
version = 1
[workspace]
root = "{worktree_root}"
[files]
symlink = [".env"]
""")
        info = await manager.resolve_project(str(git_repo_with_env_file))
        ws = await manager.create_workspace(
            info, session_name="test", worktree_root_override=worktree_root
        )
        link = Path(ws.workspace_root) / ".env"
        assert link.is_symlink()
        assert link.read_text() == "SECRET=abc\n"


class TestBootstrapExecution:
    async def test_bootstrap_script_runs_in_workspace_root(
        self, manager: WorkspaceManager, git_repo: Path, worktree_root: Path
    ) -> None:
        config_dir = git_repo / ".piface"
        config_dir.mkdir(exist_ok=True)
        (config_dir / "workspace.toml").write_text(f"""\
version = 1
[workspace]
root = "{worktree_root}"
[bootstrap]
shell = "bash"
script = "touch marker.txt"
""")
        info = await manager.resolve_project(str(git_repo))
        ws = await manager.create_workspace(
            info, session_name="test", worktree_root_override=worktree_root
        )
        assert (Path(ws.workspace_root) / "marker.txt").exists()

    async def test_bootstrap_shares_shell_env(
        self, manager: WorkspaceManager, git_repo: Path, worktree_root: Path
    ) -> None:
        config_dir = git_repo / ".piface"
        config_dir.mkdir(exist_ok=True)
        (config_dir / "workspace.toml").write_text(f"""\
version = 1
[workspace]
root = "{worktree_root}"
[bootstrap]
shell = "bash"
script = \"\"\"
export FOO=bar
echo $FOO > marker.txt
\"\"\"
""")
        info = await manager.resolve_project(str(git_repo))
        ws = await manager.create_workspace(
            info, session_name="test", worktree_root_override=worktree_root
        )
        marker = Path(ws.workspace_root) / "marker.txt"
        assert marker.exists()
        assert marker.read_text().strip() == "bar"

    async def test_bootstrap_failure_raises(
        self, manager: WorkspaceManager, git_repo: Path, worktree_root: Path
    ) -> None:
        config_dir = git_repo / ".piface"
        config_dir.mkdir(exist_ok=True)
        (config_dir / "workspace.toml").write_text(f"""\
version = 1
[workspace]
root = "{worktree_root}"
[bootstrap]
shell = "bash"
script = "exit 1"
""")
        info = await manager.resolve_project(str(git_repo))
        with pytest.raises(RuntimeError, match="[Bb]ootstrap"):
            await manager.create_workspace(
                info, session_name="test", worktree_root_override=worktree_root
            )

    async def test_bootstrap_timeout(
        self, manager: WorkspaceManager, git_repo: Path, worktree_root: Path
    ) -> None:
        config_dir = git_repo / ".piface"
        config_dir.mkdir(exist_ok=True)
        (config_dir / "workspace.toml").write_text(f"""\
version = 1
[workspace]
root = "{worktree_root}"
[bootstrap]
shell = "bash"
script = "sleep 60"
timeout_seconds = 1
""")
        info = await manager.resolve_project(str(git_repo))
        with pytest.raises(RuntimeError, match="[Tt]imeout|[Tt]imed out"):
            await manager.create_workspace(
                info, session_name="test", worktree_root_override=worktree_root
            )

    async def test_bootstrap_log_captured(
        self, manager: WorkspaceManager, git_repo: Path, worktree_root: Path
    ) -> None:
        config_dir = git_repo / ".piface"
        config_dir.mkdir(exist_ok=True)
        (config_dir / "workspace.toml").write_text(f"""\
version = 1
[workspace]
root = "{worktree_root}"
[bootstrap]
shell = "bash"
script = "echo hello-bootstrap"
""")
        info = await manager.resolve_project(str(git_repo))
        ws = await manager.create_workspace(
            info, session_name="test", worktree_root_override=worktree_root
        )
        assert ws.bootstrap_log_path is not None
        assert Path(ws.bootstrap_log_path).exists()
        assert "hello-bootstrap" in Path(ws.bootstrap_log_path).read_text()

    async def test_no_bootstrap_is_noop(
        self, manager: WorkspaceManager, git_repo: Path, worktree_root: Path
    ) -> None:
        info = await manager.resolve_project(str(git_repo))
        ws = await manager.create_workspace(
            info, session_name="test", worktree_root_override=worktree_root
        )
        assert ws.bootstrap_log_path is None


class TestWorktreeValidation:
    async def test_validate_existing_worktree(
        self, manager: WorkspaceManager, git_repo: Path, worktree_root: Path
    ) -> None:
        info = await manager.resolve_project(str(git_repo))
        ws = await manager.create_workspace(
            info, session_name="test", worktree_root_override=worktree_root
        )
        valid, error = await manager.validate_workspace(ws.workspace_root, str(git_repo))
        assert valid is True
        assert error is None

    async def test_validate_deleted_worktree(
        self, manager: WorkspaceManager, git_repo: Path, worktree_root: Path
    ) -> None:
        info = await manager.resolve_project(str(git_repo))
        ws = await manager.create_workspace(
            info, session_name="test", worktree_root_override=worktree_root
        )
        # Force-remove the worktree directory
        import shutil
        shutil.rmtree(ws.workspace_root)
        valid, error = await manager.validate_workspace(ws.workspace_root, str(git_repo))
        assert valid is False
        assert error is not None


class TestConcurrency:
    async def test_concurrent_create_produces_unique_workspaces(
        self, manager: WorkspaceManager, git_repo: Path, worktree_root: Path
    ) -> None:
        info = await manager.resolve_project(str(git_repo))
        coro = lambda: manager.create_workspace(  # noqa: E731
            info, session_name="concurrent", worktree_root_override=worktree_root
        )
        results = await asyncio.gather(coro(), coro(), coro())
        names = {r.workspace_name for r in results}
        roots = {r.workspace_root for r in results}
        assert len(names) == 3
        assert len(roots) == 3


class TestLaunchWrapperGeneration:
    def test_no_launch_config_no_direnv(self, manager: WorkspaceManager) -> None:
        from piface.workspace_config import default_workspace_config

        config = default_workspace_config()
        cmd = manager.build_launch_command(
            ["pi", "--mode", "rpc"],
            execution_dir="/tmp/ws",
            config=config,
            use_direnv=False,
            target_type="pi",
        )
        assert cmd == ["pi", "--mode", "rpc"]

    def test_no_launch_config_returns_target(self, manager: WorkspaceManager) -> None:
        from piface.workspace_config import default_workspace_config

        config = default_workspace_config()
        cmd = manager.build_launch_command(
            ["pi", "--mode", "rpc"],
            execution_dir="/tmp/ws",
            config=config,
            use_direnv=False,
            target_type="pi",
        )
        assert cmd == ["pi", "--mode", "rpc"]

    def test_launch_with_script_wraps_command(self, manager: WorkspaceManager) -> None:
        from piface.workspace_config import LaunchSection

        config = WorkspaceConfig(
            launch=LaunchSection(
                shell="bash",
                apply_to=["pi", "pty"],
                script="useaion",
            ),
        )
        cmd = manager.build_launch_command(
            ["pi", "--mode", "rpc"],
            execution_dir="/tmp/ws",
            config=config,
            use_direnv=False,
            target_type="pi",
        )
        assert cmd[0] == "bash"
        assert cmd[1] == "-lc"
        assert "useaion" in cmd[2]
        assert 'exec "$@"' in cmd[2]
        assert cmd[3] == "bash"  # $0
        assert cmd[4:] == ["pi", "--mode", "rpc"]

    def test_launch_with_direnv_wraps_everything(
        self, manager: WorkspaceManager
    ) -> None:
        from piface.workspace_config import LaunchSection

        config = WorkspaceConfig(
            launch=LaunchSection(
                shell="bash",
                apply_to=["pi"],
                script="useaion",
            ),
        )
        cmd = manager.build_launch_command(
            ["pi", "--mode", "rpc"],
            execution_dir="/tmp/ws",
            config=config,
            use_direnv=True,
            target_type="pi",
        )
        assert cmd[0] == "direnv"
        assert cmd[1] == "exec"
        assert cmd[2] == "/tmp/ws"
        # cmd[3] = "bash", cmd[4] = "-lc", cmd[5] = script
        assert cmd[3] == "bash"
        assert "useaion" in cmd[5]

    def test_launch_apply_to_pi_only_skips_pty(
        self, manager: WorkspaceManager
    ) -> None:
        from piface.workspace_config import LaunchSection

        config = WorkspaceConfig(
            launch=LaunchSection(
                shell="bash",
                apply_to=["pi"],
                script="useaion",
            ),
        )
        cmd = manager.build_launch_command(
            ["bash", "-l"],
            execution_dir="/tmp/ws",
            config=config,
            use_direnv=False,
            target_type="pty",
        )
        # No launch wrapper for pty
        assert cmd == ["bash", "-l"]

    def test_launch_apply_to_pty(self, manager: WorkspaceManager) -> None:
        from piface.workspace_config import LaunchSection

        config = WorkspaceConfig(
            launch=LaunchSection(
                shell="bash",
                apply_to=["pty"],
                script="useaion",
            ),
        )
        cmd = manager.build_launch_command(
            ["bash", "-l"],
            execution_dir="/tmp/ws",
            config=config,
            use_direnv=False,
            target_type="pty",
        )
        assert cmd[0] == "bash"
        assert cmd[1] == "-lc"
        assert "useaion" in cmd[2]
        assert cmd[-2:] == ["bash", "-l"]
