"""Tests for WebSocket relay route."""

import sys
from pathlib import Path

import pytest
from fastapi import FastAPI
from starlette.testclient import TestClient

from piface.routes.ws import _event_queues, _ws_clients, create_ws_router
from piface.session_manager import SessionManager

FAKE_PI_SCRIPT = """\
import json, sys
for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    try:
        cmd = json.loads(line)
    except Exception:
        continue
    cmd_type = cmd.get("type", "")
    if cmd_type == "bash":
        resp = {
            "type": "response",
            "command": "bash",
            "success": True,
            "data": {
                "output": f"fake bash: {cmd.get('command', '')}\\n",
                "exitCode": 0,
                "cancelled": False,
                "truncated": False,
                "command": cmd.get("command", ""),
            },
        }
    else:
        resp = {
            "type": "response",
            "command": cmd_type,
            "success": True,
            "data": {
                "echoMessage": cmd.get("message"),
                "hasPifaceUploadIds": "piface_upload_ids" in cmd,
            },
        }
    if cmd.get("id"):
        resp["id"] = cmd["id"]
    sys.stdout.write(json.dumps(resp) + "\\n")
    sys.stdout.flush()

    if cmd_type == "prompt":
        # Simulate a realistic pi event sequence for a prompt with a tool call
        assistant_msg = {
            "role": "assistant",
            "content": [
                {"type": "text", "text": "Let me check."},
                {"type": "toolCall", "id": "call_1", "name": "bash", "arguments": {"command": "ls"}}
            ]
        }
        tool_result = {
            "role": "toolResult",
            "toolCallId": "call_1",
            "toolName": "bash",
            "content": [{"type": "text", "text": "file1.txt"}],
            "isError": False
        }
        final_msg = {
            "role": "assistant",
            "content": [{"type": "text", "text": "Done!"}]
        }

        sys.stdout.write(json.dumps({"type": "agent_start"}) + "\\n")

        # Turn 1: assistant message with tool call
        sys.stdout.write(json.dumps({"type": "turn_start"}) + "\\n")
        sys.stdout.write(json.dumps({"type": "message_start", "message": assistant_msg}) + "\\n")
        sys.stdout.write(json.dumps({
            "type": "message_update",
            "message": assistant_msg,
            "assistantMessageEvent": {
                "type": "text_delta", "contentIndex": 0, "delta": "Let me check."
            }
        }) + "\\n")
        sys.stdout.write(json.dumps({"type": "message_end", "message": assistant_msg}) + "\\n")
        sys.stdout.write(json.dumps({
            "type": "tool_execution_start",
            "toolCallId": "call_1", "toolName": "bash", "args": {"command": "ls"}
        }) + "\\n")
        sys.stdout.write(json.dumps({
            "type": "tool_execution_end",
            "toolCallId": "call_1", "toolName": "bash",
            "result": {"content": [{"type": "text", "text": "file1.txt"}]}, "isError": False
        }) + "\\n")
        sys.stdout.write(json.dumps({
            "type": "turn_end", "message": assistant_msg, "toolResults": [tool_result]
        }) + "\\n")

        # Turn 2: final assistant response
        sys.stdout.write(json.dumps({"type": "turn_start"}) + "\\n")
        sys.stdout.write(json.dumps({"type": "message_start", "message": final_msg}) + "\\n")
        sys.stdout.write(json.dumps({
            "type": "message_update",
            "message": final_msg,
            "assistantMessageEvent": {"type": "text_delta", "contentIndex": 0, "delta": "Done!"}
        }) + "\\n")
        sys.stdout.write(json.dumps({"type": "message_end", "message": final_msg}) + "\\n")
        sys.stdout.write(json.dumps({
            "type": "turn_end", "message": final_msg, "toolResults": []
        }) + "\\n")

        # agent_end includes ALL messages (this is what caused duplication)
        sys.stdout.write(json.dumps({
            "type": "agent_end",
            "messages": [assistant_msg, tool_result, final_msg]
        }) + "\\n")
        sys.stdout.flush()
"""


@pytest.fixture(autouse=True)
def _clean_ws_state() -> None:
    """Clean global WS state between tests."""
    _ws_clients.clear()
    _event_queues.clear()


@pytest.fixture
def fake_pi_script(tmp_path: Path) -> Path:
    script = tmp_path / "fake_pi.py"
    script.write_text(FAKE_PI_SCRIPT)
    return script


@pytest.fixture
def manager(tmp_path: Path, fake_pi_script: Path) -> SessionManager:
    mgr = SessionManager(state_path=tmp_path / "state.json")
    mgr._pi_command_override = [sys.executable, str(fake_pi_script)]
    return mgr


@pytest.fixture
def app(manager: SessionManager) -> FastAPI:
    app = FastAPI()
    app.state.session_manager = manager
    app.include_router(create_ws_router())
    return app


class TestWebSocketRelay:
    def test_connect_to_nonexistent_session(self, app: FastAPI) -> None:
        client = TestClient(app)
        with pytest.raises(Exception):
            with client.websocket_connect("/ws/sessions/nonexistent"):
                pass

    def test_connect_and_receive_session_state(
        self, app: FastAPI, manager: SessionManager, tmp_path: Path
    ) -> None:
        """Test that connecting to a session WS returns initial state.

        We create the session inside the TestClient's event loop by using
        a lifespan-like approach: the TestClient manages its own loop, and
        we create the session within that context via a startup event.
        """
        created_sid: dict[str, str] = {}

        @app.on_event("startup")
        async def _create() -> None:
            created_sid["sid"] = await manager.create_session(working_dir=str(tmp_path))

        @app.on_event("shutdown")
        async def _shutdown() -> None:
            await manager.shutdown()

        client = TestClient(app)
        with client:
            sid = created_sid["sid"]
            with client.websocket_connect(f"/ws/sessions/{sid}") as ws:
                msg = ws.receive_json()
                assert msg["type"] == "piface_session_state"
                assert msg["session"]["piface_id"] == sid

    def test_send_command_and_receive_events(
        self, app: FastAPI, manager: SessionManager, tmp_path: Path
    ) -> None:
        """Test sending a prompt over WS and receiving pi events back."""
        created_sid: dict[str, str] = {}

        @app.on_event("startup")
        async def _create() -> None:
            created_sid["sid"] = await manager.create_session(working_dir=str(tmp_path))

        @app.on_event("shutdown")
        async def _shutdown() -> None:
            await manager.shutdown()

        client = TestClient(app)
        with client:
            sid = created_sid["sid"]
            with client.websocket_connect(f"/ws/sessions/{sid}") as ws:
                # Consume initial state
                init = ws.receive_json()
                assert init["type"] == "piface_session_state"

                # Send prompt
                ws.send_json({"type": "prompt", "message": "hello"})

                # Collect events with a timeout
                events = []
                import time

                deadline = time.monotonic() + 5.0
                while time.monotonic() < deadline:
                    try:
                        msg = ws.receive_json()
                        events.append(msg)
                        if msg.get("type") == "agent_end":
                            break
                    except Exception:
                        break

                types = [e["type"] for e in events]
                assert "response" in types
                assert "agent_start" in types
                assert "agent_end" in types

    def test_no_duplicate_events_per_prompt(
        self, app: FastAPI, manager: SessionManager, tmp_path: Path
    ) -> None:
        """Verify that a single prompt produces exactly one of each event.

        The fake pi script emits a realistic event sequence including
        agent_end with a messages array. The WebSocket relay must forward
        each event exactly once (the client is responsible for not double-
        counting from agent_end.messages vs message_end).
        """
        created_sid: dict[str, str] = {}

        @app.on_event("startup")
        async def _create() -> None:
            created_sid["sid"] = await manager.create_session(working_dir=str(tmp_path))

        @app.on_event("shutdown")
        async def _shutdown() -> None:
            await manager.shutdown()

        client = TestClient(app)
        with client:
            sid = created_sid["sid"]
            with client.websocket_connect(f"/ws/sessions/{sid}") as ws:
                ws.receive_json()  # initial session state

                ws.send_json({"type": "prompt", "message": "hello"})

                events = []
                import time

                deadline = time.monotonic() + 5.0
                while time.monotonic() < deadline:
                    try:
                        msg = ws.receive_json()
                        events.append(msg)
                        if msg.get("type") == "agent_end":
                            break
                    except Exception:
                        break

                types = [e["type"] for e in events]

                # Each event type should appear exactly as many times as
                # pi emitted it — no extra duplicates from the relay layer.
                assert types.count("response") == 1
                assert types.count("agent_start") == 1
                assert types.count("agent_end") == 1
                assert types.count("message_end") == 2  # two assistant messages
                assert types.count("turn_end") == 2  # two turns
                assert types.count("message_update") == 2  # two text_delta updates
                assert types.count("tool_execution_start") == 1
                assert types.count("tool_execution_end") == 1

                # Verify the agent_end message contains the full messages
                # array (the CLIENT must choose not to double-add these)
                agent_end = next(e for e in events if e["type"] == "agent_end")
                assert len(agent_end["messages"]) == 3  # asst + tool_result + asst

    def test_prompt_with_upload_ids_is_rewritten_to_paths(
        self, app: FastAPI, manager: SessionManager, tmp_path: Path
    ) -> None:
        created_sid: dict[str, str] = {}

        @app.on_event("startup")
        async def _create() -> None:
            sid = await manager.create_session(working_dir=str(tmp_path))
            created_sid["sid"] = sid

            session_file = tmp_path / "session.jsonl"
            session_file.write_text('{"type":"session"}\n')
            state = manager._load_state()
            state.sessions[sid].session_file = str(session_file)
            manager._save_state(state)

            manager.create_upload(
                sid,
                file_name="photo.png",
                mime_type="image/png",
                data=b"png-data",
            )

        @app.on_event("shutdown")
        async def _shutdown() -> None:
            await manager.shutdown()

        client = TestClient(app)
        with client:
            sid = created_sid["sid"]
            upload_id = next(iter(manager._uploads[sid].keys()))

            with client.websocket_connect(f"/ws/sessions/{sid}") as ws:
                ws.receive_json()  # session state
                ws.send_json(
                    {
                        "type": "prompt",
                        "message": "what is in this image?",
                        "piface_upload_ids": [upload_id],
                    }
                )

                response = None
                import time

                deadline = time.monotonic() + 5.0
                while time.monotonic() < deadline:
                    msg = ws.receive_json()
                    if msg.get("type") == "response" and msg.get("command") == "prompt":
                        response = msg
                        break

                assert response is not None
                echoed = response["data"]["echoMessage"]
                assert "Attached files (session-local file paths):" in echoed
                assert "/uploads/" in echoed
                assert response["data"]["hasPifaceUploadIds"] is False

    def test_prompt_bang_is_rewritten_to_pi_bash(
        self, app: FastAPI, manager: SessionManager, tmp_path: Path
    ) -> None:
        created_sid: dict[str, str] = {}

        @app.on_event("startup")
        async def _create() -> None:
            created_sid["sid"] = await manager.create_session(working_dir=str(tmp_path))

        @app.on_event("shutdown")
        async def _shutdown() -> None:
            await manager.shutdown()

        client = TestClient(app)
        with client:
            sid = created_sid["sid"]
            with client.websocket_connect(f"/ws/sessions/{sid}") as ws:
                ws.receive_json()  # initial session state
                ws.send_json({"type": "prompt", "message": "!echo hello"})

                response = ws.receive_json()
                assert response["type"] == "response"
                assert response["command"] == "bash"
                assert response["success"] is True
                assert response["data"]["command"] == "echo hello"

    def test_prompt_double_bang_runs_local_bash(
        self, app: FastAPI, manager: SessionManager, tmp_path: Path
    ) -> None:
        created_sid: dict[str, str] = {}

        @app.on_event("startup")
        async def _create() -> None:
            created_sid["sid"] = await manager.create_session(working_dir=str(tmp_path))

        @app.on_event("shutdown")
        async def _shutdown() -> None:
            await manager.shutdown()

        client = TestClient(app)
        with client:
            sid = created_sid["sid"]
            with client.websocket_connect(f"/ws/sessions/{sid}") as ws:
                ws.receive_json()  # initial session state
                ws.send_json({"type": "prompt", "message": "!!echo hidden"})

                response = ws.receive_json()
                assert response["type"] == "response"
                assert response["command"] == "bash"
                assert response["success"] is True
                assert response["data"]["output"] == "hidden\n"
                assert response["data"]["command"] == "echo hidden"
                assert response["data"]["excludeFromContext"] is True
