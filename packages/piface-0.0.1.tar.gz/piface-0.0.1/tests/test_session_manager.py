"""Tests for SessionManager."""

import asyncio
import sys
from pathlib import Path

import pytest

import piface.session_manager as session_manager_module
from piface.session_manager import SessionManager
from piface.state import PifaceState, SessionRecord, SessionStatus, load_state, save_state

# Minimal fake pi that responds to commands and exits cleanly on stdin close.
# Important: responds to get_state/fork/get_fork_messages.
FAKE_PI_SCRIPT = """\
import json, os, sys, uuid

current_session_file = os.environ.get("PIFACE_FAKE_SESSION_FILE", "/tmp/fake.jsonl")
user_messages = [
    {"entryId": "entry-1", "text": "First prompt"},
    {"entryId": "entry-2", "text": "Second prompt"},
]

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    try:
        cmd = json.loads(line)
    except Exception:
        continue

    cmd_type = cmd.get("type", "")
    cmd_id = cmd.get("id")

    if cmd_type == "prompt":
        resp = {"type": "response", "command": "prompt", "success": True}
        if cmd_id:
            resp["id"] = cmd_id
        sys.stdout.write(json.dumps(resp) + "\\n")
        sys.stdout.write(json.dumps({"type": "agent_start"}) + "\\n")
        sys.stdout.write(json.dumps({"type": "agent_end", "messages": []}) + "\\n")
        sys.stdout.flush()
        continue

    if cmd_type == "get_state":
        data_resp = {
            "type": "response",
            "command": "get_state",
            "success": True,
            "data": {"sessionFile": current_session_file, "isStreaming": False},
        }
        if cmd_id:
            data_resp["id"] = cmd_id
        sys.stdout.write(json.dumps(data_resp) + "\\n")
        sys.stdout.flush()
        continue

    if cmd_type == "fork":
        current_session_file = f"/tmp/forked-{uuid.uuid4().hex}.jsonl"
        fork_resp = {
            "type": "response",
            "command": "fork",
            "success": True,
            "data": {"text": "Forked prompt text", "cancelled": False},
        }
        if cmd_id:
            fork_resp["id"] = cmd_id
        sys.stdout.write(json.dumps(fork_resp) + "\\n")
        sys.stdout.flush()
        continue

    if cmd_type == "get_fork_messages":
        fork_messages_resp = {
            "type": "response",
            "command": "get_fork_messages",
            "success": True,
            "data": {"messages": user_messages},
        }
        if cmd_id:
            fork_messages_resp["id"] = cmd_id
        sys.stdout.write(json.dumps(fork_messages_resp) + "\\n")
        sys.stdout.flush()
        continue

    resp = {"type": "response", "command": cmd_type, "success": True}
    if cmd_id:
        resp["id"] = cmd_id
    sys.stdout.write(json.dumps(resp) + "\\n")
    sys.stdout.flush()
"""


@pytest.fixture
def fake_pi_script(tmp_path: Path) -> Path:
    script = tmp_path / "fake_pi.py"
    script.write_text(FAKE_PI_SCRIPT)
    return script


@pytest.fixture
def state_file(tmp_path: Path) -> Path:
    return tmp_path / "state.json"


@pytest.fixture
def manager(state_file: Path, fake_pi_script: Path) -> SessionManager:
    mgr = SessionManager(state_path=state_file)
    # Monkey-patch to use fake pi
    mgr._pi_command_override = [sys.executable, str(fake_pi_script)]
    return mgr


class TestSessionManager:
    @pytest.mark.asyncio
    async def test_create_session(self, manager: SessionManager, tmp_path: Path) -> None:
        sid = await manager.create_session(working_dir=str(tmp_path))
        assert sid in manager.sessions
        assert manager.sessions[sid].is_alive

        # State should be persisted
        state = manager._load_state()
        assert sid in state.sessions
        assert state.sessions[sid].status == SessionStatus.LIVE
        assert state.sessions[sid].model_provider == "openai-codex"
        assert state.sessions[sid].model_id == "gpt-5.5-codex"
        assert state.sessions[sid].thinking_level == "medium"
        assert state.sessions[sid].render_markdown is True
        assert state.sessions[sid].use_direnv is True

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_create_session_with_options(
        self, manager: SessionManager, tmp_path: Path
    ) -> None:
        sid = await manager.create_session(
            working_dir=str(tmp_path),
            provider="anthropic",
            model="claude-sonnet-4-20250514",
            thinking_level="high",
            session_name="test-session",
            render_markdown=False,
            use_direnv=False,
        )
        state = manager._load_state()
        rec = state.sessions[sid]
        assert rec.model_provider == "anthropic"
        assert rec.model_id == "claude-sonnet-4-20250514"
        assert rec.thinking_level == "high"
        assert rec.session_name == "test-session"
        assert rec.render_markdown is False
        assert rec.use_direnv is False
        assert manager.sessions[sid].config.use_direnv is False

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_kill_session(self, manager: SessionManager, tmp_path: Path) -> None:
        sid = await manager.create_session(working_dir=str(tmp_path))
        assert manager.sessions[sid].is_alive

        await manager.kill_session(sid)
        assert not manager.sessions[sid].is_alive

        state = manager._load_state()
        assert state.sessions[sid].status == SessionStatus.CLOSED

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_kill_nonexistent_session(self, manager: SessionManager) -> None:
        # Should not raise
        await manager.kill_session("nonexistent-id")

    @pytest.mark.asyncio
    async def test_allow_direnv_runs_allow_command(
        self,
        manager: SessionManager,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        class FakeProcess:
            returncode = 0

            async def communicate(self) -> tuple[bytes, bytes]:
                return b"", b""

        called: dict[str, object] = {}

        async def fake_exec(
            *cmd: str,
            cwd: str,
            stdout: object,
            stderr: object,
        ) -> FakeProcess:
            called["cmd"] = cmd
            called["cwd"] = cwd
            called["stdout"] = stdout
            called["stderr"] = stderr
            return FakeProcess()

        monkeypatch.setattr(session_manager_module.shutil, "which", lambda _: "/usr/bin/direnv")
        monkeypatch.setattr(session_manager_module.asyncio, "create_subprocess_exec", fake_exec)

        await manager.allow_direnv(str(tmp_path))

        assert called["cmd"] == ("direnv", "allow", str(tmp_path))
        assert called["cwd"] == str(tmp_path)

    @pytest.mark.asyncio
    async def test_allow_direnv_missing_binary_rejected(
        self,
        manager: SessionManager,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setattr(session_manager_module.shutil, "which", lambda _: None)

        with pytest.raises(ValueError, match="direnv is not installed"):
            await manager.allow_direnv(str(tmp_path))

    @pytest.mark.asyncio
    async def test_allow_direnv_failure_raises_runtime_error(
        self,
        manager: SessionManager,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        class FakeProcess:
            returncode = 1

            async def communicate(self) -> tuple[bytes, bytes]:
                return b"", b"direnv: error blocked"

        async def fake_exec(
            *cmd: str,
            cwd: str,
            stdout: object,
            stderr: object,
        ) -> FakeProcess:
            del cmd, cwd, stdout, stderr
            return FakeProcess()

        monkeypatch.setattr(session_manager_module.shutil, "which", lambda _: "/usr/bin/direnv")
        monkeypatch.setattr(session_manager_module.asyncio, "create_subprocess_exec", fake_exec)

        with pytest.raises(RuntimeError, match="blocked"):
            await manager.allow_direnv(str(tmp_path))

    @pytest.mark.asyncio
    async def test_resume_closed_session(self, manager: SessionManager, tmp_path: Path) -> None:
        sid = await manager.create_session(working_dir=str(tmp_path))
        await manager.kill_session(sid)

        rec = await manager.resume_session(sid)
        assert rec.status == SessionStatus.LIVE
        assert sid in manager.sessions
        assert manager.sessions[sid].is_alive

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_resume_ephemeral_session_rejected(
        self, manager: SessionManager, tmp_path: Path
    ) -> None:
        sid = await manager.create_session(working_dir=str(tmp_path), no_session=True)
        await manager.kill_session(sid)

        with pytest.raises(ValueError, match="Ephemeral sessions cannot be resumed"):
            await manager.resume_session(sid)

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_resume_live_session_rejected(
        self, manager: SessionManager, tmp_path: Path
    ) -> None:
        sid = await manager.create_session(working_dir=str(tmp_path))

        with pytest.raises(ValueError, match="Session is already live"):
            await manager.resume_session(sid)

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_list_sessions(self, manager: SessionManager, tmp_path: Path) -> None:
        sid1 = await manager.create_session(working_dir=str(tmp_path))
        sid2 = await manager.create_session(working_dir=str(tmp_path))

        sessions = manager.list_sessions()
        assert len(sessions) == 2
        ids = {s.piface_id for s in sessions}
        assert sid1 in ids
        assert sid2 in ids

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_get_session(self, manager: SessionManager, tmp_path: Path) -> None:
        sid = await manager.create_session(working_dir=str(tmp_path))
        pi_session = manager.get_session(sid)
        assert pi_session is not None
        assert pi_session.is_alive

        assert manager.get_session("nonexistent") is None

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_shutdown_stops_all(self, manager: SessionManager, tmp_path: Path) -> None:
        sid1 = await manager.create_session(working_dir=str(tmp_path))
        sid2 = await manager.create_session(working_dir=str(tmp_path))

        await manager.shutdown()

        assert not manager.sessions[sid1].is_alive
        assert not manager.sessions[sid2].is_alive

    @pytest.mark.asyncio
    async def test_send_to_session(self, manager: SessionManager, tmp_path: Path) -> None:
        events: list[dict] = []
        sid = await manager.create_session(working_dir=str(tmp_path))
        manager.sessions[sid].on_event = lambda e: events.append(e)

        await manager.send_to_session(sid, {"type": "prompt", "message": "hello"})
        await asyncio.sleep(0.3)

        types = [e["type"] for e in events]
        assert "response" in types
        assert "agent_start" in types

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_restore_sessions_on_startup(
        self, state_file: Path, tmp_path: Path, fake_pi_script: Path
    ) -> None:
        # Pre-populate state with a live session
        state = PifaceState()
        state.sessions["old-id"] = SessionRecord(
            piface_id="old-id",
            working_dir=str(tmp_path),
            status=SessionStatus.LIVE,
            session_file="/tmp/fake.jsonl",
        )
        # And a closed one
        state.sessions["closed-id"] = SessionRecord(
            piface_id="closed-id",
            working_dir=str(tmp_path),
            status=SessionStatus.CLOSED,
        )
        # And an ephemeral one
        state.sessions["ephemeral-id"] = SessionRecord(
            piface_id="ephemeral-id",
            working_dir=str(tmp_path),
            status=SessionStatus.LIVE,
            no_session=True,
        )
        save_state(state, state_file)

        mgr = SessionManager(state_path=state_file)
        mgr._pi_command_override = [sys.executable, str(fake_pi_script)]

        await mgr.restore_sessions()

        # Live session should be restored
        assert "old-id" in mgr.sessions
        assert mgr.sessions["old-id"].is_alive

        # Closed session should NOT be restored
        assert "closed-id" not in mgr.sessions

        # Ephemeral session should be dropped (marked closed, not restored)
        loaded = mgr._load_state()
        assert loaded.sessions["ephemeral-id"].status == SessionStatus.CLOSED

        await mgr.shutdown()

    @pytest.mark.asyncio
    async def test_restore_with_session_file_uses_session_flag(
        self, state_file: Path, tmp_path: Path, fake_pi_script: Path
    ) -> None:
        """Restoring a session that has a session_file should use --session <path>."""
        # Create a real file so the restore doesn't skip it
        session_file = tmp_path / "session.jsonl"
        session_file.write_text('{"fake": true}\n')

        state = PifaceState()
        state.sessions["test-id"] = SessionRecord(
            piface_id="test-id",
            working_dir=str(tmp_path),
            status=SessionStatus.LIVE,
            session_file=str(session_file),
        )
        save_state(state, state_file)

        mgr = SessionManager(state_path=state_file)
        mgr._pi_command_override = [sys.executable, str(fake_pi_script)]

        await mgr.restore_sessions()

        assert "test-id" in mgr.sessions
        assert mgr.sessions["test-id"].is_alive
        # The config should have the session_file set
        assert mgr.sessions["test-id"].config.session_file == str(session_file)

        await mgr.shutdown()

    @pytest.mark.asyncio
    async def test_restore_uses_persisted_direnv_preference(
        self, state_file: Path, tmp_path: Path, fake_pi_script: Path
    ) -> None:
        state = PifaceState()
        state.sessions["direnv-off-id"] = SessionRecord(
            piface_id="direnv-off-id",
            working_dir=str(tmp_path),
            status=SessionStatus.LIVE,
            use_direnv=False,
        )
        save_state(state, state_file)

        mgr = SessionManager(state_path=state_file)
        mgr._pi_command_override = [sys.executable, str(fake_pi_script)]

        await mgr.restore_sessions()

        assert "direnv-off-id" in mgr.sessions
        assert mgr.sessions["direnv-off-id"].config.use_direnv is False

        await mgr.shutdown()

    @pytest.mark.asyncio
    async def test_restore_missing_session_file_starts_fresh(
        self, state_file: Path, tmp_path: Path, fake_pi_script: Path
    ) -> None:
        """If the session file no longer exists, start fresh."""
        state = PifaceState()
        state.sessions["gone-id"] = SessionRecord(
            piface_id="gone-id",
            working_dir=str(tmp_path),
            status=SessionStatus.LIVE,
            session_file="/tmp/does_not_exist.jsonl",
        )
        save_state(state, state_file)

        mgr = SessionManager(state_path=state_file)
        mgr._pi_command_override = [sys.executable, str(fake_pi_script)]

        await mgr.restore_sessions()

        assert "gone-id" in mgr.sessions
        assert mgr.sessions["gone-id"].is_alive
        # Should NOT pass the missing file to pi
        assert mgr.sessions["gone-id"].config.session_file is None

        await mgr.shutdown()

    @pytest.mark.asyncio
    async def test_restore_without_session_file_starts_fresh(
        self, state_file: Path, tmp_path: Path, fake_pi_script: Path
    ) -> None:
        """Sessions without a session_file should start fresh (with capture listener)."""
        state = PifaceState()
        state.sessions["no-file-id"] = SessionRecord(
            piface_id="no-file-id",
            working_dir=str(tmp_path),
            status=SessionStatus.LIVE,
            session_file=None,
        )
        save_state(state, state_file)

        mgr = SessionManager(state_path=state_file)
        mgr._pi_command_override = [sys.executable, str(fake_pi_script)]

        await mgr.restore_sessions()

        assert "no-file-id" in mgr.sessions
        assert mgr.sessions["no-file-id"].is_alive
        assert mgr.sessions["no-file-id"].config.session_file is None

        await mgr.shutdown()

    @pytest.mark.asyncio
    async def test_session_file_captured_after_prompt(
        self, manager: SessionManager, tmp_path: Path
    ) -> None:
        """After first prompt, session_file should be captured via get_state."""
        sid = await manager.create_session(working_dir=str(tmp_path))

        # Initially no session_file
        state = manager._load_state()
        assert state.sessions[sid].session_file is None

        # Send a prompt which triggers agent_end → get_state → capture
        await manager.send_to_session(sid, {"type": "prompt", "message": "hi"})
        await asyncio.sleep(0.5)

        # Now session_file should be captured
        state = manager._load_state()
        assert state.sessions[sid].session_file == "/tmp/fake.jsonl"

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_session_file_capture_expands_user_home(
        self,
        manager: SessionManager,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        home_dir = tmp_path / "home"
        home_dir.mkdir(parents=True)
        expected = home_dir / "captured.jsonl"
        expected.write_text('{"type":"session"}\n')

        monkeypatch.setenv("HOME", str(home_dir))
        monkeypatch.setenv("PIFACE_FAKE_SESSION_FILE", "~/captured.jsonl")

        sid = await manager.create_session(working_dir=str(tmp_path))
        await manager.send_to_session(sid, {"type": "prompt", "message": "hi"})
        await asyncio.sleep(0.5)

        state = manager._load_state()
        assert state.sessions[sid].session_file == str(expected)

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_resume_expands_tilde_session_file_from_state(
        self,
        manager: SessionManager,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        home_dir = tmp_path / "home"
        home_dir.mkdir(parents=True)
        expected = home_dir / "resume.jsonl"
        expected.write_text('{"type":"session"}\n')

        monkeypatch.setenv("HOME", str(home_dir))

        sid = await manager.create_session(working_dir=str(tmp_path))
        await manager.kill_session(sid)

        state = manager._load_state()
        state.sessions[sid].session_file = "~/resume.jsonl"
        manager._save_state(state)

        resumed = await manager.resume_session(sid)
        assert resumed.session_file == str(expected)
        assert manager.sessions[sid].config.session_file == str(expected)

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_ephemeral_session_no_capture(
        self, manager: SessionManager, tmp_path: Path
    ) -> None:
        """Ephemeral sessions should not try to capture session file."""
        sid = await manager.create_session(working_dir=str(tmp_path), no_session=True)

        # Send a prompt
        await manager.send_to_session(sid, {"type": "prompt", "message": "hi"})
        await asyncio.sleep(0.5)

        # session_file should remain None
        state = manager._load_state()
        assert state.sessions[sid].session_file is None

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_get_fork_messages_from_live_session(
        self, manager: SessionManager, tmp_path: Path
    ) -> None:
        sid = await manager.create_session(working_dir=str(tmp_path))
        messages = await manager.get_fork_messages(sid)
        assert messages
        assert messages[0]["entryId"] == "entry-1"
        assert messages[0]["text"] == "First prompt"

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_branch_session_creates_new_live_session(
        self, manager: SessionManager, tmp_path: Path
    ) -> None:
        source_id = await manager.create_session(working_dir=str(tmp_path), session_name="source")

        source_session_file = tmp_path / "source-session.jsonl"
        source_session_file.write_text('{"type":"session"}\n')

        state = manager._load_state()
        state.sessions[source_id].session_file = str(source_session_file)
        manager._save_state(state)

        upload = manager.create_upload(
            source_id,
            file_name="photo.png",
            mime_type="image/png",
            data=b"image-bytes",
        )

        branched, selected_text, cancelled = await manager.branch_session(
            source_id,
            entry_id="entry-1",
            session_name="branch-a",
        )

        assert cancelled is False
        assert selected_text == "Forked prompt text"
        assert branched.piface_id != source_id
        assert branched.status == SessionStatus.LIVE
        assert branched.session_name == "branch-a"
        assert branched.session_file
        assert manager.get_session(branched.piface_id) is not None

        inherited_paths = manager.resolve_upload_paths(branched.piface_id, [upload["upload_id"]])
        assert inherited_paths
        assert Path(inherited_paths[0]).is_file()

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_branch_session_requires_persisted_source(
        self, manager: SessionManager, tmp_path: Path
    ) -> None:
        source_id = await manager.create_session(working_dir=str(tmp_path), no_session=True)

        with pytest.raises(ValueError, match="cannot be branched"):
            await manager.branch_session(source_id, entry_id="entry-1")

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_cleanup_transcript_with_pi_falls_back_to_original_text(
        self,
        manager: SessionManager,
        tmp_path: Path,
    ) -> None:
        sid = await manager.create_session(working_dir=str(tmp_path))
        cleaned = await manager.cleanup_transcript_with_pi(sid, "raw transcript")
        assert cleaned == "raw transcript"

        await manager.shutdown()

    def test_list_sessions_reconciles_stale_live_record_to_closed(
        self,
        state_file: Path,
        tmp_path: Path,
    ) -> None:
        state = PifaceState()
        state.sessions["stale-live-id"] = SessionRecord(
            piface_id="stale-live-id",
            working_dir=str(tmp_path),
            status=SessionStatus.LIVE,
        )
        save_state(state, state_file)

        mgr = SessionManager(state_path=state_file)

        records = mgr.list_sessions()
        assert len(records) == 1
        assert records[0].piface_id == "stale-live-id"
        assert records[0].status == SessionStatus.CLOSED

        persisted = mgr._load_state()
        assert persisted.sessions["stale-live-id"].status == SessionStatus.CLOSED

    def test_get_record_reconciles_stale_live_record_to_closed(
        self,
        state_file: Path,
        tmp_path: Path,
    ) -> None:
        state = PifaceState()
        state.sessions["stale-live-id"] = SessionRecord(
            piface_id="stale-live-id",
            working_dir=str(tmp_path),
            status=SessionStatus.LIVE,
        )
        save_state(state, state_file)

        mgr = SessionManager(state_path=state_file)

        record = mgr.get_record("stale-live-id")
        assert record is not None
        assert record.status == SessionStatus.CLOSED

        persisted = mgr._load_state()
        assert persisted.sessions["stale-live-id"].status == SessionStatus.CLOSED


class TestStateLocationMerging:
    def test_default_manager_loads_merged_legacy_state(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("HOME", str(tmp_path))
        monkeypatch.delenv("XDG_DATA_HOME", raising=False)
        monkeypatch.setattr("piface.state.sys.platform", "linux")

        canonical = tmp_path / ".local" / "share" / "piface" / "state.json"
        legacy = tmp_path / "snap" / "code" / "226" / ".local" / "share" / "piface" / "state.json"

        canonical_state = PifaceState(
            sessions={
                "canonical-id": SessionRecord(
                    piface_id="canonical-id",
                    working_dir="/tmp/canonical",
                    status=SessionStatus.CLOSED,
                )
            }
        )
        legacy_state = PifaceState(
            sessions={
                "legacy-id": SessionRecord(
                    piface_id="legacy-id",
                    working_dir="/tmp/legacy",
                    status=SessionStatus.LIVE,
                )
            }
        )

        save_state(canonical_state, canonical)
        save_state(legacy_state, legacy)

        mgr = SessionManager()

        records = mgr.list_sessions()
        ids = {record.piface_id for record in records}
        assert ids == {"canonical-id", "legacy-id"}

        persisted = load_state(canonical)
        assert "legacy-id" in persisted.sessions
