"""Tests for the frontend auto-build module."""

import time
from pathlib import Path
from unittest.mock import patch

from piface.build import _newest_mtime, is_build_stale


class TestNewestMtime:
    def test_empty_dir(self, tmp_path: Path) -> None:
        assert _newest_mtime(tmp_path) == 0.0

    def test_nonexistent_dir(self, tmp_path: Path) -> None:
        assert _newest_mtime(tmp_path / "nope") == 0.0

    def test_finds_newest(self, tmp_path: Path) -> None:
        (tmp_path / "old.txt").write_text("old")
        time.sleep(0.05)
        (tmp_path / "new.txt").write_text("new")
        newest = _newest_mtime(tmp_path)
        assert newest == (tmp_path / "new.txt").stat().st_mtime

    def test_filter_by_extension(self, tmp_path: Path) -> None:
        (tmp_path / "file.ts").write_text("ts")
        (tmp_path / "file.css").write_text("css")
        newest = _newest_mtime(tmp_path, extensions={".ts"})
        assert newest == (tmp_path / "file.ts").stat().st_mtime


class TestIsBuildStale:
    def test_stale_when_no_frontend_dir(self, tmp_path: Path) -> None:
        # Patch FRONTEND_DIR to a non-existent directory
        with patch("piface.build.FRONTEND_DIR", tmp_path / "nope"):
            assert is_build_stale() is False  # no frontend = nothing to build

    def test_stale_when_no_dist(self, tmp_path: Path) -> None:
        frontend = tmp_path / "frontend"
        (frontend / "src").mkdir(parents=True)
        (frontend / "src" / "app.ts").write_text("code")
        with (
            patch("piface.build.FRONTEND_DIR", frontend),
            patch("piface.build.DIST_DIR", frontend / "dist"),
        ):
            assert is_build_stale() is True

    def test_not_stale_when_dist_newer(self, tmp_path: Path) -> None:
        frontend = tmp_path / "frontend"
        (frontend / "src").mkdir(parents=True)
        (frontend / "src" / "app.ts").write_text("code")
        time.sleep(0.05)
        (frontend / "dist").mkdir()
        (frontend / "dist" / "index.html").write_text("<html>")
        with (
            patch("piface.build.FRONTEND_DIR", frontend),
            patch("piface.build.DIST_DIR", frontend / "dist"),
        ):
            assert is_build_stale() is False

    def test_stale_when_src_newer(self, tmp_path: Path) -> None:
        frontend = tmp_path / "frontend"
        (frontend / "dist").mkdir(parents=True)
        (frontend / "dist" / "index.html").write_text("<html>")
        time.sleep(0.05)
        (frontend / "src").mkdir(parents=True)
        (frontend / "src" / "app.ts").write_text("updated code")
        with (
            patch("piface.build.FRONTEND_DIR", frontend),
            patch("piface.build.DIST_DIR", frontend / "dist"),
        ):
            assert is_build_stale() is True
