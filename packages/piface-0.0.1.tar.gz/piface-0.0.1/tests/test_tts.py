"""Tests for text-to-speech helpers and cache lookup."""

from pathlib import Path

from piface.tts import CoquiTtsSynthesizer, build_tts_cache_key, normalize_tts_text


def test_build_tts_cache_key_is_stable_and_model_scoped() -> None:
    key_a = build_tts_cache_key(model_name="model-a", text="Hello world")
    key_b = build_tts_cache_key(model_name="model-a", text="Hello world")
    key_c = build_tts_cache_key(model_name="model-b", text="Hello world")
    key_d = build_tts_cache_key(model_name="model-a", text="Hello again")

    assert key_a == key_b
    assert key_a != key_c
    assert key_a != key_d
    assert len(key_a) == 64


def test_build_tts_cache_key_normalizes_whitespace_before_hashing() -> None:
    key_a = build_tts_cache_key(model_name="model-a", text="Hello\r\nworld\n")
    key_b = build_tts_cache_key(
        model_name="model-a",
        text=normalize_tts_text("Hello\nworld"),
    )

    assert key_a == key_b


def test_get_cached_audio_returns_cached_file(tmp_path: Path) -> None:
    text = "Read this out loud"
    key = build_tts_cache_key(model_name="model-a", text=text)
    audio_path = tmp_path / f"{key}.mp3"
    audio_path.write_bytes(b"ID3")

    synthesizer = CoquiTtsSynthesizer(
        model_name="model-a",
        cache_dir=tmp_path,
        prefer_gpu=False,
    )

    cached = synthesizer.get_cached_audio(key)

    assert cached is not None
    assert cached.cache_key == key
    assert cached.file_path == audio_path
    assert cached.media_type == "audio/mpeg"
    assert cached.cached is True


def test_get_cached_audio_rejects_invalid_cache_keys(tmp_path: Path) -> None:
    synthesizer = CoquiTtsSynthesizer(
        model_name="model-a",
        cache_dir=tmp_path,
        prefer_gpu=False,
    )

    assert synthesizer.get_cached_audio("../escape") is None
    assert synthesizer.get_cached_audio("not-a-real-key") is None
