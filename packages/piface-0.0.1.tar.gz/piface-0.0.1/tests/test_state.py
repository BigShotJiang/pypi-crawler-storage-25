"""Tests for persistent state management."""

from pathlib import Path

import pytest

from piface.state import (
    PifaceState,
    SessionRecord,
    SessionStatus,
    UploadBlobRecord,
    default_state_path,
    load_state,
    save_state,
)


@pytest.fixture
def state_file(tmp_path: Path) -> Path:
    return tmp_path / "state.json"


class TestSessionRecord:
    def test_create_live_session(self) -> None:
        rec = SessionRecord(
            piface_id="abc-123",
            working_dir="/home/user/project",
            status=SessionStatus.LIVE,
        )
        assert rec.piface_id == "abc-123"
        assert rec.status == SessionStatus.LIVE
        assert rec.no_session is False
        assert rec.render_markdown is True
        assert rec.created_at is not None
        assert rec.last_active is not None

    def test_create_with_all_fields(self) -> None:
        rec = SessionRecord(
            piface_id="abc-123",
            working_dir="/home/user/project",
            status=SessionStatus.LIVE,
            session_file="/home/user/.pi/sessions/abc.jsonl",
            no_session=False,
            model_provider="anthropic",
            model_id="claude-sonnet-4-20250514",
            thinking_level="medium",
            session_name="my-feature",
            render_markdown=False,
        )
        assert rec.session_file == "/home/user/.pi/sessions/abc.jsonl"
        assert rec.model_provider == "anthropic"
        assert rec.model_id == "claude-sonnet-4-20250514"
        assert rec.thinking_level == "medium"
        assert rec.session_name == "my-feature"
        assert rec.render_markdown is False

    def test_branch_lineage_fields(self) -> None:
        rec = SessionRecord(
            piface_id="branch-1",
            working_dir="/tmp/project",
            status=SessionStatus.LIVE,
            parent_piface_id="source-1",
            branch_entry_id="entry-123",
        )
        assert rec.parent_piface_id == "source-1"
        assert rec.branch_entry_id == "entry-123"

    def test_status_enum(self) -> None:
        assert SessionStatus.LIVE == "live"
        assert SessionStatus.CLOSED == "closed"

    def test_workspace_fields_default(self) -> None:
        rec = SessionRecord(
            piface_id="ws-1",
            working_dir="/home/user/project",
            status=SessionStatus.LIVE,
        )
        assert rec.project_dir is None
        assert rec.project_subdir == "."
        assert rec.execution_dir is None
        assert rec.workspace_mode == "shared"
        assert rec.workspace_id is None
        assert rec.workspace_name is None
        assert rec.workspace_root is None
        assert rec.workspace_branch is None
        assert rec.workspace_base_ref is None
        assert rec.workspace_theme_override is None
        assert rec.workspace_skin_override is None
        assert rec.workspace_created_by_piface is False
        assert rec.workspace_status == "ready"
        assert rec.workspace_error is None
        assert rec.bootstrap_log_path is None
        assert rec.launch_log_path is None

    def test_workspace_fields_roundtrip(self) -> None:
        rec = SessionRecord(
            piface_id="ws-2",
            working_dir="/home/user/project",
            status=SessionStatus.LIVE,
            project_dir="/home/user/project",
            project_subdir="apps/api",
            execution_dir="/home/user/.local/share/piface/worktrees/proj-abc/ws-2",
            workspace_mode="git_worktree",
            workspace_id="ws-2-id",
            workspace_name="my-session-abc123",
            workspace_root="/home/user/.local/share/piface/worktrees/proj-abc/ws-2",
            workspace_branch="piface/my-session-abc123",
            workspace_base_ref="main",
            workspace_theme_override="dark",
            workspace_skin_override="beos",
            workspace_created_by_piface=True,
            workspace_status="ready",
        )
        json_str = rec.model_dump_json()
        restored = SessionRecord.model_validate_json(json_str)
        assert restored.project_dir == "/home/user/project"
        assert restored.project_subdir == "apps/api"
        assert restored.execution_dir == rec.execution_dir
        assert restored.workspace_mode == "git_worktree"
        assert restored.workspace_id == "ws-2-id"
        assert restored.workspace_name == "my-session-abc123"
        assert restored.workspace_root == rec.workspace_root
        assert restored.workspace_branch == "piface/my-session-abc123"
        assert restored.workspace_base_ref == "main"
        assert restored.workspace_theme_override == "dark"
        assert restored.workspace_skin_override == "beos"
        assert restored.workspace_created_by_piface is True
        assert restored.workspace_status == "ready"

    def test_effective_execution_dir_falls_back(self) -> None:
        rec = SessionRecord(
            piface_id="ws-3",
            working_dir="/home/user/project",
            status=SessionStatus.LIVE,
        )
        assert rec.effective_execution_dir == "/home/user/project"

    def test_effective_execution_dir_uses_execution_dir(self) -> None:
        rec = SessionRecord(
            piface_id="ws-4",
            working_dir="/home/user/project",
            status=SessionStatus.LIVE,
            execution_dir="/home/user/.local/share/piface/worktrees/proj/ws",
        )
        assert rec.effective_execution_dir == "/home/user/.local/share/piface/worktrees/proj/ws"

    def test_effective_project_dir_falls_back(self) -> None:
        rec = SessionRecord(
            piface_id="ws-5",
            working_dir="/home/user/project",
            status=SessionStatus.LIVE,
        )
        assert rec.effective_project_dir == "/home/user/project"

    def test_effective_project_dir_uses_project_dir(self) -> None:
        rec = SessionRecord(
            piface_id="ws-6",
            working_dir="/home/user/project/apps/api",
            status=SessionStatus.LIVE,
            project_dir="/home/user/project",
        )
        assert rec.effective_project_dir == "/home/user/project"

    def test_legacy_state_loads_without_workspace_fields(self, state_file: Path) -> None:
        """Old state.json files without workspace fields still load."""
        legacy_json = """{
          "sessions": {
            "old-1": {
              "piface_id": "old-1",
              "working_dir": "/tmp/old",
              "status": "live",
              "created_at": "2025-01-01T00:00:00Z",
              "last_active": "2025-01-01T00:00:00Z"
            }
          }
        }"""
        state_file.write_text(legacy_json)
        state = load_state(state_file)
        rec = state.sessions["old-1"]
        assert rec.working_dir == "/tmp/old"
        assert rec.project_dir is None
        assert rec.workspace_mode == "shared"
        assert rec.effective_execution_dir == "/tmp/old"
        assert rec.effective_project_dir == "/tmp/old"


class TestPifaceState:
    def test_empty_state(self) -> None:
        state = PifaceState()
        assert state.sessions == {}

    def test_add_session(self) -> None:
        state = PifaceState()
        rec = SessionRecord(
            piface_id="id-1",
            working_dir="/tmp",
            status=SessionStatus.LIVE,
        )
        state.sessions["id-1"] = rec
        assert "id-1" in state.sessions

    def test_serialization_roundtrip(self) -> None:
        state = PifaceState()
        state.sessions["id-1"] = SessionRecord(
            piface_id="id-1",
            working_dir="/tmp/project",
            status=SessionStatus.LIVE,
            session_name="test",
        )
        json_str = state.model_dump_json()
        restored = PifaceState.model_validate_json(json_str)
        assert restored.sessions["id-1"].working_dir == "/tmp/project"
        assert restored.sessions["id-1"].session_name == "test"

    def test_upload_registry_roundtrip(self) -> None:
        state = PifaceState()
        state.uploads["u1"] = UploadBlobRecord(
            upload_id="u1",
            path="/tmp/uploads/_shared/u1_photo.png",
            file_name="photo.png",
            mime_type="image/png",
            size=12,
            ref_sessions=["session-a"],
        )
        state.session_upload_ids["session-a"] = ["u1"]

        restored = PifaceState.model_validate_json(state.model_dump_json())
        assert restored.uploads["u1"].path.endswith("u1_photo.png")
        assert restored.session_upload_ids["session-a"] == ["u1"]


class TestLoadSaveState:
    def test_load_nonexistent_returns_empty(self, state_file: Path) -> None:
        state = load_state(state_file)
        assert state.sessions == {}

    def test_save_and_load(self, state_file: Path) -> None:
        state = PifaceState()
        state.sessions["id-1"] = SessionRecord(
            piface_id="id-1",
            working_dir="/tmp",
            status=SessionStatus.LIVE,
        )
        save_state(state, state_file)
        assert state_file.exists()

        loaded = load_state(state_file)
        assert "id-1" in loaded.sessions
        assert loaded.sessions["id-1"].status == SessionStatus.LIVE

    def test_save_creates_parent_dirs(self, tmp_path: Path) -> None:
        nested = tmp_path / "a" / "b" / "state.json"
        state = PifaceState()
        save_state(state, nested)
        assert nested.exists()

    def test_load_corrupt_file_returns_empty(self, state_file: Path) -> None:
        state_file.write_text("not valid json{{{")
        state = load_state(state_file)
        assert state.sessions == {}

    def test_overwrite_existing(self, state_file: Path) -> None:
        state1 = PifaceState()
        state1.sessions["id-1"] = SessionRecord(
            piface_id="id-1", working_dir="/tmp", status=SessionStatus.LIVE
        )
        save_state(state1, state_file)

        state2 = PifaceState()
        state2.sessions["id-2"] = SessionRecord(
            piface_id="id-2", working_dir="/other", status=SessionStatus.CLOSED
        )
        save_state(state2, state_file)

        loaded = load_state(state_file)
        assert "id-1" not in loaded.sessions
        assert "id-2" in loaded.sessions


class TestDefaultStatePath:
    def test_linux_path_is_stable_under_home(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("HOME", str(tmp_path))
        monkeypatch.setattr("piface.state.sys.platform", "linux")

        assert default_state_path() == tmp_path / ".local" / "share" / "piface" / "state.json"


class TestStateMigration:
    def test_load_state_merges_legacy_snap_state(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("HOME", str(tmp_path))
        monkeypatch.delenv("XDG_DATA_HOME", raising=False)
        monkeypatch.setattr("piface.state.sys.platform", "linux")

        canonical = tmp_path / ".local" / "share" / "piface" / "state.json"
        legacy = tmp_path / "snap" / "code" / "226" / ".local" / "share" / "piface" / "state.json"

        canonical_state = PifaceState(
            sessions={
                "old-id": SessionRecord(
                    piface_id="old-id",
                    working_dir="/tmp/old",
                    status=SessionStatus.CLOSED,
                )
            }
        )
        legacy_state = PifaceState(
            sessions={
                "new-id": SessionRecord(
                    piface_id="new-id",
                    working_dir="/tmp/new",
                    status=SessionStatus.LIVE,
                )
            }
        )

        save_state(canonical_state, canonical)
        save_state(legacy_state, legacy)

        merged = load_state()
        assert "old-id" in merged.sessions
        assert "new-id" in merged.sessions

        persisted = load_state(canonical)
        assert "old-id" in persisted.sessions
        assert "new-id" in persisted.sessions
