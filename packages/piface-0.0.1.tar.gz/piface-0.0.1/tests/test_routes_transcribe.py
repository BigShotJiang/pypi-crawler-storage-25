"""Tests for session audio transcription routes."""

import base64
import sys
from pathlib import Path

import httpx
import pytest
from fastapi import FastAPI

from piface.routes.sessions import create_sessions_router
from piface.session_manager import SessionManager

FAKE_PI_SCRIPT = """\
import json, sys

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    try:
        cmd = json.loads(line)
    except Exception:
        continue

    resp = {"type": "response", "command": cmd.get("type", ""), "success": True}
    if cmd.get("id"):
        resp["id"] = cmd["id"]

    if cmd.get("type") == "prompt":
        message = cmd.get("message", "")
        cleaned = message.replace("INPUT:", "").strip().upper()
        assistant = {
            "role": "assistant",
            "content": [{"type": "text", "text": cleaned}],
        }
        sys.stdout.write(json.dumps(resp) + "\\n")
        sys.stdout.write(json.dumps({"type": "agent_start"}) + "\\n")
        sys.stdout.write(json.dumps({"type": "message_end", "message": assistant}) + "\\n")
        sys.stdout.write(json.dumps({"type": "agent_end"}) + "\\n")
        sys.stdout.flush()
        continue

    sys.stdout.write(json.dumps(resp) + "\\n")
    sys.stdout.flush()
"""


class FakeSpeechTranscriber:
    def __init__(self, text: str = "hello from audio") -> None:
        self.text = text
        self.calls: list[tuple[bytes, str]] = []

    async def transcribe(self, audio_bytes: bytes, mime_type: str) -> str:
        self.calls.append((audio_bytes, mime_type))
        return self.text


@pytest.fixture
def fake_pi_script(tmp_path: Path) -> Path:
    script = tmp_path / "fake_pi.py"
    script.write_text(FAKE_PI_SCRIPT)
    return script


@pytest.fixture
def manager(tmp_path: Path, fake_pi_script: Path) -> SessionManager:
    mgr = SessionManager(state_path=tmp_path / "state.json")
    mgr._pi_command_override = [sys.executable, str(fake_pi_script)]
    return mgr


@pytest.fixture
def app(manager: SessionManager) -> FastAPI:
    app = FastAPI()
    app.state.session_manager = manager
    app.include_router(create_sessions_router(), prefix="/api")
    return app


@pytest.fixture
async def client(app: FastAPI) -> httpx.AsyncClient:
    transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        yield c  # type: ignore[misc]


@pytest.mark.asyncio
async def test_transcribe_audio_success(
    client: httpx.AsyncClient,
    app: FastAPI,
    tmp_path: Path,
) -> None:
    create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
    sid = create_resp.json()["piface_id"]

    transcriber = FakeSpeechTranscriber("plain transcript")
    app.state.speech_transcriber = transcriber

    payload = {
        "audio_base64": base64.b64encode(b"audio-bytes").decode(),
        "mime_type": "audio/webm",
        "clean_with_pi": False,
    }
    resp = await client.post(f"/api/sessions/{sid}/transcribe", json=payload)

    assert resp.status_code == 200
    data = resp.json()
    assert data["text"] == "plain transcript"
    assert data["raw_text"] == "plain transcript"
    assert data["cleaned"] is False
    assert transcriber.calls == [(b"audio-bytes", "audio/webm")]


@pytest.mark.asyncio
async def test_transcribe_audio_with_cleanup_uses_pi(
    client: httpx.AsyncClient,
    app: FastAPI,
    manager: SessionManager,
    tmp_path: Path,
) -> None:
    create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
    sid = create_resp.json()["piface_id"]

    transcriber = FakeSpeechTranscriber("needs cleanup")
    app.state.speech_transcriber = transcriber

    called: dict[str, str] = {}

    async def fake_cleanup(session_id: str, transcript: str) -> str:
        called["session_id"] = session_id
        called["transcript"] = transcript
        return "cleaned transcript"

    manager.cleanup_transcript_with_pi = fake_cleanup  # type: ignore[assignment]

    payload = {
        "audio_base64": base64.b64encode(b"audio-bytes").decode(),
        "mime_type": "audio/webm",
        "clean_with_pi": True,
    }
    resp = await client.post(f"/api/sessions/{sid}/transcribe", json=payload)

    assert resp.status_code == 200
    data = resp.json()
    assert data["text"] == "cleaned transcript"
    assert data["raw_text"] == "needs cleanup"
    assert data["cleaned"] is True
    assert called == {"session_id": sid, "transcript": "needs cleanup"}


@pytest.mark.asyncio
async def test_transcribe_audio_requires_transcriber(
    client: httpx.AsyncClient,
    tmp_path: Path,
) -> None:
    create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
    sid = create_resp.json()["piface_id"]

    payload = {
        "audio_base64": base64.b64encode(b"audio-bytes").decode(),
        "mime_type": "audio/webm",
    }
    resp = await client.post(f"/api/sessions/{sid}/transcribe", json=payload)

    assert resp.status_code == 503
    assert "not configured" in resp.json()["detail"].lower()


@pytest.mark.asyncio
async def test_transcribe_audio_rejects_closed_sessions(
    client: httpx.AsyncClient,
    app: FastAPI,
    manager: SessionManager,
    tmp_path: Path,
) -> None:
    create_resp = await client.post("/api/sessions", json={"working_dir": str(tmp_path)})
    sid = create_resp.json()["piface_id"]
    await client.post(f"/api/sessions/{sid}/kill")

    app.state.speech_transcriber = FakeSpeechTranscriber()

    payload = {
        "audio_base64": base64.b64encode(b"audio-bytes").decode(),
        "mime_type": "audio/webm",
    }
    resp = await client.post(f"/api/sessions/{sid}/transcribe", json=payload)

    assert resp.status_code == 409
