"""Tests for audio-related packaging metadata in pyproject.toml."""

from __future__ import annotations

import tomllib
from pathlib import Path


def _load_pyproject() -> dict:
    return tomllib.loads(Path("pyproject.toml").read_text())


def test_project_is_pinned_to_python_312_for_audio_stack_compatibility() -> None:
    data = _load_pyproject()

    assert data["project"]["requires-python"] == ">=3.12,<3.13"


def test_audio_extras_pin_runtime_compatibility_dependencies() -> None:
    data = _load_pyproject()
    extras = data["project"]["optional-dependencies"]

    speech = extras["speech"]
    tts = extras["tts"]
    audio = extras["audio"]

    assert any(dep.startswith("ml-dtypes>=0.5.0") for dep in speech)
    assert any(dep.startswith("ml-dtypes>=0.5.0") for dep in audio)
    assert any(dep.startswith("torchcodec>=0.10") for dep in tts)
    assert any(dep.startswith("torchcodec>=0.10") for dep in audio)
