"""Shared test fixtures for workspace-related tests."""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest


def _git(cwd: Path, *args: str) -> None:
    subprocess.run(
        ["git", "-c", "user.name=Test", "-c", "user.email=test@test.com", *args],
        cwd=cwd,
        check=True,
        capture_output=True,
    )


@pytest.fixture
def git_repo(tmp_path: Path) -> Path:
    """Create a minimal Git repo with one committed file."""
    repo = tmp_path / "project"
    repo.mkdir()
    _git(repo, "init", "-b", "main")
    (repo / "tracked.txt").write_text("hello\n")
    _git(repo, "add", "tracked.txt")
    _git(repo, "commit", "-m", "initial commit")
    return repo


@pytest.fixture
def git_repo_with_subdir(git_repo: Path) -> Path:
    """Git repo that also has an apps/api subdirectory."""
    subdir = git_repo / "apps" / "api"
    subdir.mkdir(parents=True)
    (subdir / "main.py").write_text("print('hello')\n")
    _git(git_repo, "add", ".")
    _git(git_repo, "commit", "-m", "add subdir")
    return git_repo


@pytest.fixture
def worktree_root(tmp_path: Path) -> Path:
    """Separate directory outside the repo for worktree storage."""
    wt = tmp_path / "worktrees"
    wt.mkdir()
    return wt


@pytest.fixture
def git_repo_with_config(git_repo: Path, worktree_root: Path) -> Path:
    """Git repo with a .piface/workspace.toml that points worktrees outside the repo."""
    config_dir = git_repo / ".piface"
    config_dir.mkdir()
    (config_dir / "workspace.toml").write_text(f"""\
version = 1

[workspace]
mode = "git_worktree"
root = "{worktree_root}"
name_template = "{{session_slug}}-{{short_id}}"

[files]
copy = []
""")
    _git(git_repo, "add", ".piface/")
    _git(git_repo, "commit", "-m", "add workspace config")
    return git_repo


@pytest.fixture
def git_repo_with_env_file(git_repo: Path) -> Path:
    """Git repo with an untracked .env file."""
    (git_repo / ".env").write_text("SECRET=abc\n")
    (git_repo / ".gitignore").write_text(".env\n")
    _git(git_repo, "add", ".gitignore")
    _git(git_repo, "commit", "-m", "add gitignore")
    return git_repo
