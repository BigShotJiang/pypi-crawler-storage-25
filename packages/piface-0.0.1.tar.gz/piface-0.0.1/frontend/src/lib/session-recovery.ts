import { normalizeFilesViewState, type FilesViewState } from './files-view-state';

export type SessionTab = 'chat' | 'files' | 'diff' | 'terminal' | 'scratch';

export type { FilesViewState };

export type SessionSnapshot = {
	sessionId: string;
	session: any;
	messages: any[];
	activeTab: SessionTab;
	filesView?: FilesViewState;
	timestamp: number;
};

const SNAPSHOT_TTL_MS = 30 * 60_000;
const KEY_PREFIX = 'piface.session.snapshot:';

type SnapshotReadStorage = Pick<Storage, 'getItem'> | null | undefined;
type SnapshotWriteStorage = Pick<Storage, 'setItem'> | null | undefined;

export function computeReconnectDelay(attempt: number): number {
	const exp = Math.max(0, attempt);
	return Math.min(15_000, 1000 * 2 ** exp);
}

function keyFor(sessionId: string): string {
	return `${KEY_PREFIX}${sessionId}`;
}

export function saveSessionSnapshot(
	storage: Pick<Storage, 'setItem'>,
	snapshot: SessionSnapshot
): void {
	storage.setItem(keyFor(snapshot.sessionId), JSON.stringify(snapshot));
}

export function loadSessionSnapshot(
	storage: Pick<Storage, 'getItem'>,
	sessionId: string
): SessionSnapshot | null {
	const raw = storage.getItem(keyFor(sessionId));
	if (!raw) return null;

	try {
		const parsed = JSON.parse(raw) as SessionSnapshot;
		if (!parsed || parsed.sessionId !== sessionId) return null;
		if (Date.now() - parsed.timestamp > SNAPSHOT_TTL_MS) return null;
		if (!Array.isArray(parsed.messages)) return null;
		if (!['chat', 'files', 'diff', 'terminal', 'scratch'].includes(parsed.activeTab)) return null;
		if (parsed.filesView !== undefined) {
			const normalizedFilesView = normalizeFilesViewState(parsed.filesView);
			if (!normalizedFilesView) return null;
			parsed.filesView = normalizedFilesView;
		}
		return parsed;
	} catch {
		return null;
	}
}

function loadSnapshotSafe(storage: SnapshotReadStorage, sessionId: string): SessionSnapshot | null {
	if (!storage) return null;
	try {
		return loadSessionSnapshot(storage, sessionId);
	} catch {
		return null;
	}
}

export function loadSessionSnapshotWithFallback(
	primaryStorage: SnapshotReadStorage,
	fallbackStorage: SnapshotReadStorage,
	sessionId: string
): SessionSnapshot | null {
	const primary = loadSnapshotSafe(primaryStorage, sessionId);
	if (primary) return primary;
	return loadSnapshotSafe(fallbackStorage, sessionId);
}

function saveSnapshotSafe(storage: SnapshotWriteStorage, snapshot: SessionSnapshot): void {
	if (!storage) return;
	try {
		saveSessionSnapshot(storage, snapshot);
	} catch {
		// no-op when browser storage is unavailable
	}
}

export function saveSessionSnapshotWithFallback(
	primaryStorage: SnapshotWriteStorage,
	fallbackStorage: SnapshotWriteStorage,
	snapshot: SessionSnapshot
): void {
	saveSnapshotSafe(primaryStorage, snapshot);
	if (fallbackStorage && fallbackStorage !== primaryStorage) {
		saveSnapshotSafe(fallbackStorage, snapshot);
	}
}
