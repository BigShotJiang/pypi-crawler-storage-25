export interface SessionPathLike {
	working_dir?: string | null;
	execution_dir?: string | null;
	workspace_mode?: string | null;
}

export function getSessionFilesRoot(session: SessionPathLike | null | undefined): string {
	if (!session) return '';
	if (session.workspace_mode === 'git_worktree' && session.execution_dir?.trim()) {
		return session.execution_dir.trim();
	}
	return session.working_dir?.trim() ?? '';
}
