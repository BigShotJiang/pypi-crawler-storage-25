import { describe, expect, it } from 'vitest';

import {
	applyWorkingEvent,
	createWorkingIndicatorState,
	type WorkingIndicatorState
} from './working-indicator';

function applyMany(events: any[]): WorkingIndicatorState {
	let state = createWorkingIndicatorState();
	for (const event of events) {
		state = applyWorkingEvent(state, event);
	}
	return state;
}

describe('working indicator reducer', () => {
	it('starts idle', () => {
		const state = createWorkingIndicatorState();
		expect(state.phase).toBe('idle');
		expect(state.label).toBe('');
		expect(state.activeTools).toEqual([]);
	});

	it('shows thinking after agent_start', () => {
		const state = applyMany([{ type: 'agent_start' }]);
		expect(state.phase).toBe('thinking');
		expect(state.label).toBe('Thinking…');
	});

	it('shows running tool status while tools are active', () => {
		const state = applyMany([
			{ type: 'agent_start' },
			{ type: 'tool_execution_start', toolCallId: 'call_1', toolName: 'bash' }
		]);
		expect(state.phase).toBe('tool');
		expect(state.label).toBe('Running bash…');
		expect(state.activeTools).toEqual([{ id: 'call_1', toolName: 'bash', status: 'running' }]);
	});

	it('shows pluralized running label for multiple tools', () => {
		const state = applyMany([
			{ type: 'agent_start' },
			{ type: 'tool_execution_start', toolCallId: 'call_1', toolName: 'bash' },
			{ type: 'tool_execution_start', toolCallId: 'call_2', toolName: 'read' }
		]);
		expect(state.label).toBe('Running 2 tools…');
		expect(state.activeTools).toHaveLength(2);
	});

	it('shows responding once text deltas arrive and no tools are active', () => {
		const state = applyMany([
			{ type: 'agent_start' },
			{
				type: 'message_update',
				assistantMessageEvent: { type: 'text_delta', delta: 'hello' }
			}
		]);
		expect(state.phase).toBe('responding');
		expect(state.label).toBe('Responding…');
	});

	it('returns to responding after a tool ends when text deltas were seen', () => {
		const state = applyMany([
			{ type: 'agent_start' },
			{
				type: 'message_update',
				assistantMessageEvent: { type: 'text_delta', delta: 'Thinking...' }
			},
			{ type: 'tool_execution_start', toolCallId: 'call_1', toolName: 'bash' },
			{ type: 'tool_execution_end', toolCallId: 'call_1', toolName: 'bash', isError: false }
		]);
		expect(state.phase).toBe('responding');
		expect(state.recentTools[0]).toEqual({ id: 'call_1', toolName: 'bash', status: 'done' });
	});

	it('returns to thinking after a tool ends when no text delta was seen', () => {
		const state = applyMany([
			{ type: 'agent_start' },
			{ type: 'tool_execution_start', toolCallId: 'call_1', toolName: 'bash' },
			{ type: 'tool_execution_end', toolCallId: 'call_1', toolName: 'bash', isError: false }
		]);
		expect(state.phase).toBe('thinking');
		expect(state.label).toBe('Thinking…');
	});

	it('tracks recent tool outcomes and caps list', () => {
		const state = applyMany([
			{ type: 'agent_start' },
			{ type: 'tool_execution_start', toolCallId: '1', toolName: 'bash' },
			{ type: 'tool_execution_end', toolCallId: '1', toolName: 'bash', isError: false },
			{ type: 'tool_execution_start', toolCallId: '2', toolName: 'read' },
			{ type: 'tool_execution_end', toolCallId: '2', toolName: 'read', isError: true },
			{ type: 'tool_execution_start', toolCallId: '3', toolName: 'write' },
			{ type: 'tool_execution_end', toolCallId: '3', toolName: 'write', isError: false },
			{ type: 'tool_execution_start', toolCallId: '4', toolName: 'edit' },
			{ type: 'tool_execution_end', toolCallId: '4', toolName: 'edit', isError: false }
		]);

		expect(state.recentTools).toEqual([
			{ id: '4', toolName: 'edit', status: 'done' },
			{ id: '3', toolName: 'write', status: 'done' },
			{ id: '2', toolName: 'read', status: 'error' }
		]);
	});

	it('clears state on agent_end', () => {
		const state = applyMany([
			{ type: 'agent_start' },
			{ type: 'tool_execution_start', toolCallId: 'call_1', toolName: 'bash' },
			{ type: 'agent_end' }
		]);
		expect(state.phase).toBe('idle');
		expect(state.label).toBe('');
		expect(state.activeTools).toEqual([]);
		expect(state.recentTools).toEqual([]);
	});
});
