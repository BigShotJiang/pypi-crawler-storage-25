export type WorkingPhase = 'idle' | 'thinking' | 'tool' | 'responding';

export type ToolProgressItem = {
	id: string;
	toolName: string;
	status: 'running' | 'done' | 'error';
};

export type WorkingIndicatorState = {
	isAgentActive: boolean;
	hasTextDelta: boolean;
	phase: WorkingPhase;
	label: string;
	activeTools: ToolProgressItem[];
	recentTools: ToolProgressItem[];
};

const MAX_RECENT_TOOLS = 3;

export function createWorkingIndicatorState(): WorkingIndicatorState {
	return {
		isAgentActive: false,
		hasTextDelta: false,
		phase: 'idle',
		label: '',
		activeTools: [],
		recentTools: []
	};
}

function toolNameOrDefault(name: unknown): string {
	if (typeof name === 'string' && name.trim()) return name;
	return 'tool';
}

function toolIdOrDefault(event: any): string {
	if (typeof event?.toolCallId === 'string' && event.toolCallId.trim()) return event.toolCallId;
	if (typeof event?.toolName === 'string' && event.toolName.trim()) return `tool:${event.toolName}`;
	return 'tool:unknown';
}

function derivePhase(state: WorkingIndicatorState): WorkingPhase {
	if (!state.isAgentActive) return 'idle';
	if (state.activeTools.length > 0) return 'tool';
	if (state.hasTextDelta) return 'responding';
	return 'thinking';
}

function deriveLabel(state: WorkingIndicatorState): string {
	switch (state.phase) {
		case 'thinking':
			return 'Thinking…';
		case 'responding':
			return 'Responding…';
		case 'tool': {
			if (state.activeTools.length === 1) {
				return `Running ${state.activeTools[0].toolName}…`;
			}
			return `Running ${state.activeTools.length} tools…`;
		}
		default:
			return '';
	}
}

function withDerived(state: WorkingIndicatorState): WorkingIndicatorState {
	const phase = derivePhase(state);
	return {
		...state,
		phase,
		label: deriveLabel({ ...state, phase })
	};
}

export function applyWorkingEvent(
	state: WorkingIndicatorState,
	event: { type?: string; [key: string]: any }
): WorkingIndicatorState {
	switch (event?.type) {
		case 'agent_start':
			return withDerived({
				isAgentActive: true,
				hasTextDelta: false,
				phase: 'thinking',
				label: '',
				activeTools: [],
				recentTools: []
			});

		case 'agent_end':
		case 'piface_replay':
			return createWorkingIndicatorState();

		case 'message_update': {
			if (event?.assistantMessageEvent?.type !== 'text_delta') return state;
			return withDerived({
				...state,
				hasTextDelta: true
			});
		}

		case 'tool_execution_start':
		case 'tool_execution_update': {
			if (!state.isAgentActive) return state;
			const id = toolIdOrDefault(event);
			const toolName = toolNameOrDefault(event?.toolName);
			const nextActive = state.activeTools.filter((tool) => tool.id !== id);
			nextActive.push({ id, toolName, status: 'running' });
			return withDerived({
				...state,
				activeTools: nextActive
			});
		}

		case 'tool_execution_end': {
			if (!state.isAgentActive) return state;
			const id = toolIdOrDefault(event);
			const finishedTool =
				state.activeTools.find((tool) => tool.id === id) ??
				({ id, toolName: toolNameOrDefault(event?.toolName), status: 'running' } as const);
			const status: ToolProgressItem['status'] = event?.isError ? 'error' : 'done';
			const nextRecent = [{ ...finishedTool, status }, ...state.recentTools.filter((tool) => tool.id !== id)].slice(
				0,
				MAX_RECENT_TOOLS
			);
			const nextActive = state.activeTools.filter((tool) => tool.id !== id);
			return withDerived({
				...state,
				activeTools: nextActive,
				recentTools: nextRecent
			});
		}

		default:
			return state;
	}
}
