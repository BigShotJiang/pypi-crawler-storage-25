export type TransferItemLike<TFile extends { type?: string }> = {
	kind?: string;
	type?: string;
	getAsFile?: () => TFile | null;
};

export type TransferLike<TFile extends { type?: string }> = {
	items?: ArrayLike<TransferItemLike<TFile>> | null;
	files?: ArrayLike<TFile> | null;
};

function dedupeFiles<TFile>(files: TFile[]): TFile[] {
	const seen = new Set<TFile>();
	const unique: TFile[] = [];
	for (const file of files) {
		if (seen.has(file)) continue;
		seen.add(file);
		unique.push(file);
	}
	return unique;
}

export function collectFilesFromTransfer<TFile extends { type?: string }>(
	transfer: TransferLike<TFile> | null | undefined
): TFile[] {
	if (!transfer) return [];

	const itemFiles: TFile[] = [];
	for (const item of Array.from(transfer.items ?? [])) {
		if (item.kind && item.kind !== 'file') continue;
		const file = item.getAsFile?.();
		if (!file) continue;
		itemFiles.push(file);
	}

	if (itemFiles.length > 0) {
		return dedupeFiles(itemFiles);
	}

	return dedupeFiles(Array.from(transfer.files ?? []));
}
