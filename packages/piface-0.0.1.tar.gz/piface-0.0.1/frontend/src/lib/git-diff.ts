export type GitChangedFile = {
	path: string;
	status: string;
	staged: boolean;
	unstaged: boolean;
	untracked: boolean;
	old_path?: string | null;
};

export function defaultDiffModeIsStaged(file: GitChangedFile | null | undefined): boolean {
	if (!file) return false;
	if (file.untracked) return false;
	return file.staged && !file.unstaged;
}

export function formatStatusCode(code: string): string {
	return code.replace(/\s/g, '·');
}
