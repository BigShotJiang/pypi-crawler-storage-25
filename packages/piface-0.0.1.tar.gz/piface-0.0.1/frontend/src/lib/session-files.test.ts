import { describe, expect, it } from 'vitest';

import {
	loadRecentFiles,
	loadSessionFilesView,
	recordRecentFile,
	saveSessionFilesView
} from './session-files';

function createStorage(): Pick<Storage, 'getItem' | 'setItem'> {
	const store = new Map<string, string>();
	return {
		getItem: (key) => store.get(key) ?? null,
		setItem: (key, value) => {
			store.set(key, value);
		}
	};
}

describe('session file view storage', () => {
	it('round-trips per-session files view state', () => {
		const storage = createStorage();
		const state = {
			currentPath: '/tmp/project/src',
			selectedPath: '/tmp/project/src/main.ts',
			previewFullscreen: true
		};

		saveSessionFilesView(storage, 'session-1', state);

		expect(loadSessionFilesView(storage, 'session-1')).toEqual(state);
	});

	it('rejects malformed stored file view state', () => {
		const storage = createStorage();
		storage.setItem(
			'piface.session.files-view:session-1',
			JSON.stringify({ currentPath: 123, selectedPath: '/tmp/project/src/main.ts' })
		);

		expect(loadSessionFilesView(storage, 'session-1')).toBeNull();
	});

	it('salvages malformed optional fullscreen state', () => {
		const storage = createStorage();
		storage.setItem(
			'piface.session.files-view:session-1',
			JSON.stringify({
				currentPath: '/tmp/project/src',
				selectedPath: '/tmp/project/src/main.ts',
				previewFullscreen: 'yes'
			})
		);

		expect(loadSessionFilesView(storage, 'session-1')).toEqual({
			currentPath: '/tmp/project/src',
			selectedPath: '/tmp/project/src/main.ts'
		});
	});
});

describe('recent files storage', () => {
	it('records recent files most-recent-first and deduplicates entries', () => {
		const storage = createStorage();

		recordRecentFile(storage, '/tmp/project', '/tmp/project/src/main.ts');
		recordRecentFile(storage, '/tmp/project', '/tmp/project/README.md');
		recordRecentFile(storage, '/tmp/project', '/tmp/project/src/main.ts');

		expect(loadRecentFiles(storage, '/tmp/project')).toEqual([
			'/tmp/project/src/main.ts',
			'/tmp/project/README.md'
		]);
	});

	it('stores recent files separately for each directory', () => {
		const storage = createStorage();

		recordRecentFile(storage, '/tmp/project-a', '/tmp/project-a/src/a.ts');
		recordRecentFile(storage, '/tmp/project-b', '/tmp/project-b/src/b.ts');

		expect(loadRecentFiles(storage, '/tmp/project-a')).toEqual(['/tmp/project-a/src/a.ts']);
		expect(loadRecentFiles(storage, '/tmp/project-b')).toEqual(['/tmp/project-b/src/b.ts']);
	});

	it('ignores files outside the root directory', () => {
		const storage = createStorage();

		recordRecentFile(storage, '/tmp/project', '/tmp/other/file.ts');

		expect(loadRecentFiles(storage, '/tmp/project')).toEqual([]);
	});

	it('drops malformed recent file payloads', () => {
		const storage = createStorage();
		storage.setItem(
			'piface.directory.recent-files:%2Ftmp%2Fproject',
			JSON.stringify(['/tmp/project/src/main.ts', 123, null])
		);

		expect(loadRecentFiles(storage, '/tmp/project')).toEqual(['/tmp/project/src/main.ts']);
	});
});
