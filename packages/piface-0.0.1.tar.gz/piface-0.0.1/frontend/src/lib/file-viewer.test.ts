import { describe, expect, it } from 'vitest';

import {
	buildPathCopyVariants,
	buildPreviewCopyVariants,
	inferLanguageFromPath,
	inferPreviewKind,
	relativePathFromRoot
} from './file-viewer';

describe('inferPreviewKind', () => {
	it('detects markdown files', () => {
		expect(inferPreviewKind('/tmp/readme.md', 'text/markdown')).toBe('markdown');
	});

	it('detects html files', () => {
		expect(inferPreviewKind('/tmp/index.html', 'text/html')).toBe('html');
	});

	it('detects images via mime type', () => {
		expect(inferPreviewKind('/tmp/photo.dat', 'image/png')).toBe('image');
	});

	it('falls back to code for text-like files', () => {
		expect(inferPreviewKind('/tmp/config.yaml', 'application/octet-stream')).toBe('code');
		expect(inferPreviewKind('/tmp/file.txt', 'text/plain')).toBe('code');
	});

	it('returns binary for unknown binaries', () => {
		expect(inferPreviewKind('/tmp/archive.bin', 'application/octet-stream')).toBe('binary');
	});
});

describe('inferLanguageFromPath', () => {
	it('maps common extensions to highlight.js language ids', () => {
		expect(inferLanguageFromPath('main.py')).toBe('python');
		expect(inferLanguageFromPath('component.svelte')).toBe('svelte');
		expect(inferLanguageFromPath('settings.json')).toBe('json');
	});

	it('returns undefined for unknown extensions', () => {
		expect(inferLanguageFromPath('data.unknownext')).toBeUndefined();
	});
});

describe('relativePathFromRoot', () => {
	it('returns a clean child relative path inside the root directory', () => {
		expect(relativePathFromRoot('/tmp/project', '/tmp/project/src/main.ts')).toBe('src/main.ts');
		expect(relativePathFromRoot('/tmp/project/', '/tmp/project/README.md')).toBe('README.md');
	});

	it('returns dot when root and target are the same path', () => {
		expect(relativePathFromRoot('/tmp/project', '/tmp/project')).toBe('.');
	});

	it('walks up with .. when target is outside root', () => {
		expect(relativePathFromRoot('/tmp/project/src', '/tmp/project/README.md')).toBe('../README.md');
	});
});

describe('buildPathCopyVariants', () => {
	it('prefers relative path and falls back to absolute path', () => {
		expect(buildPathCopyVariants('/tmp/project', '/tmp/project/src/main.ts')).toEqual([
			{ kind: 'relative', value: 'src/main.ts' },
			{ kind: 'absolute', value: '/tmp/project/src/main.ts' }
		]);
	});

	it('returns only absolute path when relative path is not meaningful', () => {
		expect(buildPathCopyVariants('', '/tmp/project/src/main.ts')).toEqual([
			{ kind: 'absolute', value: '/tmp/project/src/main.ts' }
		]);
		expect(buildPathCopyVariants('project', '/tmp/project/src/main.ts')).toEqual([
			{ kind: 'absolute', value: '/tmp/project/src/main.ts' }
		]);
	});
});

describe('buildPreviewCopyVariants', () => {
	it('copies source content first for code and markdown files', () => {
		expect(
			buildPreviewCopyVariants('/tmp/project', {
				kind: 'code',
				path: '/tmp/project/src/main.ts',
				content: 'console.log(1);'
			})
		).toEqual([
			{ kind: 'content', value: 'console.log(1);' },
			{ kind: 'relative-path', value: 'src/main.ts' },
			{ kind: 'absolute-path', value: '/tmp/project/src/main.ts' }
		]);
	});

	it('falls back to path variants when source content is unavailable', () => {
		expect(
			buildPreviewCopyVariants('/tmp/project', {
				kind: 'image',
				path: '/tmp/project/assets/logo.png',
				content: null
			})
		).toEqual([
			{ kind: 'relative-path', value: 'assets/logo.png' },
			{ kind: 'absolute-path', value: '/tmp/project/assets/logo.png' }
		]);
	});

	it('preserves empty-file source content as a valid copy target', () => {
		expect(
			buildPreviewCopyVariants('/tmp/project', {
				kind: 'code',
				path: '/tmp/project/empty.txt',
				content: ''
			})
		).toEqual([
			{ kind: 'content', value: '' },
			{ kind: 'relative-path', value: 'empty.txt' },
			{ kind: 'absolute-path', value: '/tmp/project/empty.txt' }
		]);
	});
});
