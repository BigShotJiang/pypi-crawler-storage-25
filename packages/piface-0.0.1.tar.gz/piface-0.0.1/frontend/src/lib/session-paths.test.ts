import { describe, expect, it } from 'vitest';

import { getSessionFilesRoot, type SessionPathLike } from './session-paths';

describe('getSessionFilesRoot', () => {
	it('uses execution_dir for git worktree sessions', () => {
		const session: SessionPathLike = {
			working_dir: '/home/user/project',
			execution_dir: '/home/user/.local/share/piface/worktrees/project/ws-123',
			workspace_mode: 'git_worktree'
		};

		expect(getSessionFilesRoot(session)).toBe(
			'/home/user/.local/share/piface/worktrees/project/ws-123'
		);
	});

	it('falls back to working_dir when execution_dir is absent', () => {
		const session: SessionPathLike = {
			working_dir: '/home/user/project',
			workspace_mode: 'git_worktree'
		};

		expect(getSessionFilesRoot(session)).toBe('/home/user/project');
	});

	it('uses working_dir for shared sessions', () => {
		const session: SessionPathLike = {
			working_dir: '/home/user/project',
			execution_dir: '/tmp/ignored',
			workspace_mode: 'shared'
		};

		expect(getSessionFilesRoot(session)).toBe('/home/user/project');
	});
});
