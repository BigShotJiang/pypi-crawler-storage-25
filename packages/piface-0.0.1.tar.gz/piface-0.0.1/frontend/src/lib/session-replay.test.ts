import { describe, expect, it } from 'vitest';

import { applyReplayMessages } from './session-replay';

describe('applyReplayMessages', () => {
	it('keeps existing array reference when replay payload is unchanged', () => {
		const current = [
			{ role: 'user', content: [{ type: 'text', text: 'hi' }] },
			{ role: 'assistant', content: [{ type: 'text', text: 'hello' }] }
		];
		const incoming = [
			{ role: 'user', content: [{ type: 'text', text: 'hi' }] },
			{ role: 'assistant', content: [{ type: 'text', text: 'hello' }] }
		];

		const result = applyReplayMessages(current, incoming);

		expect(result.changed).toBe(false);
		expect(result.messages).toBe(current);
	});

	it('replaces messages when replay content changes', () => {
		const current = [{ role: 'user', content: [{ type: 'text', text: 'hi' }] }];
		const incoming = [
			{ role: 'user', content: [{ type: 'text', text: 'hi' }] },
			{ role: 'assistant', content: [{ type: 'text', text: 'new response' }] }
		];

		const result = applyReplayMessages(current, incoming);

		expect(result.changed).toBe(true);
		expect(result.messages).toEqual(incoming);
		expect(result.messages).not.toBe(current);
	});

	it('normalizes malformed replay payloads to an empty list', () => {
		const current = [{ role: 'assistant', content: [{ type: 'text', text: 'keep?' }] }];

		const result = applyReplayMessages(current, null);

		expect(result.changed).toBe(true);
		expect(result.messages).toEqual([]);
	});

	it('does not trigger updates when both current and replay are empty', () => {
		const current: any[] = [];

		const result = applyReplayMessages(current, undefined);

		expect(result.changed).toBe(false);
		expect(result.messages).toBe(current);
	});
});
