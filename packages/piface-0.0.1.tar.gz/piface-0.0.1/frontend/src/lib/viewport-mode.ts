export const SESSION_VIEWPORT_CLASS = 'piface-session-viewport';

interface ClassListLike {
	add: (...tokens: string[]) => void;
	remove: (...tokens: string[]) => void;
}

interface ViewportDocumentLike {
	documentElement: { classList: ClassListLike };
	body?: { classList: ClassListLike } | null;
}

function getBrowserDocument(): ViewportDocumentLike | null {
	if (typeof document === 'undefined') {
		return null;
	}
	return document as unknown as ViewportDocumentLike;
}

export function enableSessionViewportMode(doc: ViewportDocumentLike | null = getBrowserDocument()): void {
	if (!doc) return;
	doc.documentElement.classList.add(SESSION_VIEWPORT_CLASS);
	doc.body?.classList.add(SESSION_VIEWPORT_CLASS);
}

export function disableSessionViewportMode(doc: ViewportDocumentLike | null = getBrowserDocument()): void {
	if (!doc) return;
	doc.documentElement.classList.remove(SESSION_VIEWPORT_CLASS);
	doc.body?.classList.remove(SESSION_VIEWPORT_CLASS);
}
