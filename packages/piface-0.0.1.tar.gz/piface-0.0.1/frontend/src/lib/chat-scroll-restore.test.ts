import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

import { createChatScrollRestoreController } from './chat-scroll-restore';

describe('createChatScrollRestoreController', () => {
	beforeEach(() => {
		vi.useFakeTimers();
	});

	afterEach(() => {
		vi.useRealTimers();
	});

	function createScheduler() {
		return {
			requestAnimationFrame: (callback: FrameRequestCallback) =>
				setTimeout(() => callback(performance.now()), 16) as unknown as number,
			cancelAnimationFrame: (handle: number) => clearTimeout(handle),
			setInterval: (callback: () => void, ms: number) => setInterval(callback, ms),
			clearInterval: (handle: ReturnType<typeof setInterval>) => clearInterval(handle),
			setTimeout: (callback: () => void, ms: number) => setTimeout(callback, ms),
			clearTimeout: (handle: ReturnType<typeof setTimeout>) => clearTimeout(handle)
		};
	}

	it('reapplies scroll until settling and then stops', () => {
		const apply = vi.fn();
		const onSettled = vi.fn();
		const controller = createChatScrollRestoreController(createScheduler(), {
			intervalMs: 120,
			settleMs: 700
		});

		controller.start({ apply, onSettled });
		expect(controller.isActive()).toBe(true);
		expect(apply).toHaveBeenCalledTimes(1);

		vi.advanceTimersByTime(32);
		expect(apply).toHaveBeenCalledTimes(3);
		expect(onSettled).not.toHaveBeenCalled();

		vi.advanceTimersByTime(668);
		expect(apply).toHaveBeenCalledTimes(9);
		expect(onSettled).toHaveBeenCalledTimes(1);
		expect(controller.isActive()).toBe(false);

		vi.advanceTimersByTime(500);
		expect(apply).toHaveBeenCalledTimes(9);
	});

	it('cancels an active restore without firing the settle callback', () => {
		const apply = vi.fn();
		const onSettled = vi.fn();
		const controller = createChatScrollRestoreController(createScheduler());

		controller.start({ apply, onSettled });
		vi.advanceTimersByTime(16);
		expect(apply).toHaveBeenCalledTimes(2);

		controller.cancel();
		expect(controller.isActive()).toBe(false);

		vi.advanceTimersByTime(1000);
		expect(apply).toHaveBeenCalledTimes(2);
		expect(onSettled).not.toHaveBeenCalled();
	});

	it('restarting cancels the previous restore before starting a new one', () => {
		const firstApply = vi.fn();
		const firstSettled = vi.fn();
		const secondApply = vi.fn();
		const secondSettled = vi.fn();
		const controller = createChatScrollRestoreController(createScheduler());

		controller.start({ apply: firstApply, onSettled: firstSettled });
		vi.advanceTimersByTime(100);

		controller.start({ apply: secondApply, onSettled: secondSettled });
		vi.advanceTimersByTime(700);

		expect(firstSettled).not.toHaveBeenCalled();
		expect(secondApply).toHaveBeenCalled();
		expect(secondSettled).toHaveBeenCalledTimes(1);
	});
});
