<script lang="ts">
	let {
		value = $bindable(''),
		placeholder = 'Working directory…'
	}: {
		value: string;
		placeholder?: string;
	} = $props();

	let suggestions: string[] = $state([]);
	let showSuggestions = $state(false);
	let debounceTimer: ReturnType<typeof setTimeout> | undefined;

	async function complete(prefix: string) {
		if (!prefix || prefix.length < 2) {
			suggestions = [];
			return;
		}
		try {
			const res = await fetch(`/api/fs/complete?prefix=${encodeURIComponent(prefix)}`);
			const data = await res.json();
			suggestions = data.matches ?? [];
			showSuggestions = suggestions.length > 0;
		} catch {
			suggestions = [];
		}
	}

	function onInput() {
		clearTimeout(debounceTimer);
		debounceTimer = setTimeout(() => complete(value), 150);
	}

	function pick(s: string) {
		value = s;
		showSuggestions = false;
		// Trigger another completion for subdirectories
		clearTimeout(debounceTimer);
		debounceTimer = setTimeout(() => complete(value + '/'), 150);
	}

	function onBlur() {
		// Delay so click on suggestion registers
		setTimeout(() => (showSuggestions = false), 200);
	}
</script>

<div class="dir-browser">
	<input
		type="text"
		bind:value
		oninput={onInput}
		onfocus={() => { if (suggestions.length) showSuggestions = true; }}
		onblur={onBlur}
		{placeholder}
		autocomplete="off"
	/>
	{#if showSuggestions && suggestions.length > 0}
		<ul class="suggestions">
			{#each suggestions as s}
				<li>
					<button type="button" onmousedown={() => pick(s)}>{s}</button>
				</li>
			{/each}
		</ul>
	{/if}
</div>

<style>
	.dir-browser {
		position: relative;
	}
	input {
		width: 100%;
		padding: 0.5rem 0.6rem;
		background: var(--surface-2);
		border: 1px solid var(--border-strong);
		border-radius: 6px;
		color: var(--color-text);
		/* 16px prevents iOS auto-zoom on focus */
		font-size: 1rem;
		font-family: ui-monospace, 'SF Mono', monospace;
		box-sizing: border-box;
	}
	input:focus {
		outline: none;
		border-color: var(--primary-text);
	}
	.suggestions {
		position: absolute;
		top: 100%;
		left: 0;
		right: 0;
		background: var(--surface-2);
		border: 1px solid var(--border-strong);
		border-top: none;
		border-radius: 0 0 6px 6px;
		list-style: none;
		padding: 0;
		margin: 0;
		max-height: 200px;
		overflow-y: auto;
		z-index: 10;
	}
	.suggestions li button {
		width: 100%;
		text-align: left;
		padding: 0.6rem 0.75rem;
		background: none;
		border: none;
		color: var(--color-muted-2);
		font-family: ui-monospace, 'SF Mono', monospace;
		font-size: 0.9rem;
		cursor: pointer;
		-webkit-tap-highlight-color: transparent;
	}
	.suggestions li button:hover {
		background: var(--surface-hover);
		color: var(--color-text);
	}
</style>
