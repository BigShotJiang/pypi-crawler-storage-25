<script lang="ts">
	import { onMount, onDestroy } from 'svelte';
	import { computeReconnectDelay } from '$lib/session-recovery';

	let { sessionId, visible }: { sessionId: string; visible: boolean } = $props();

	let containerEl: HTMLDivElement;
	let term: any = null;
	let fitAddon: any = null;
	let ws: WebSocket | null = null;
	let initialized = $state(false);
	let ctrlActive = $state(false);
	let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
	let reconnectAttempt = 0;
	let sessionDead = false;
	const encoder = new TextEncoder();

	function buildTheme(): Record<string, string> {
		const s = getComputedStyle(document.documentElement);
		const v = (name: string) => s.getPropertyValue(name).trim();
		return {
			background: v('--color-bg') || '#0a0a0a',
			foreground: v('--color-text') || '#e0e0e0',
			cursor: v('--primary-text') || '#7cacf8',
			selectionBackground: v('--surface-2') || '#1e1e1e'
		};
	}

	function connectWebSocket() {
		if (sessionDead) return;
		if (reconnectTimer) {
			clearTimeout(reconnectTimer);
			reconnectTimer = null;
		}

		const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
		ws = new WebSocket(`${proto}//${location.host}/ws/sessions/${sessionId}/terminal`);
		ws.binaryType = 'arraybuffer';

		ws.onopen = () => {
			reconnectAttempt = 0;
			// Send initial resize so the PTY knows our dimensions
			if (term) {
				const cols = term.cols ?? 80;
				const rows = term.rows ?? 24;
				ws?.send(JSON.stringify({ type: 'resize', cols, rows }));
			}
		};

		ws.onmessage = (e) => {
			if (e.data instanceof ArrayBuffer) {
				term?.write(new Uint8Array(e.data));
			}
		};

		ws.onclose = (e) => {
			if (e.code === 4004) {
				// Session is gone, stop retrying
				sessionDead = true;
				return;
			}
			reconnectTimer = setTimeout(
				() => connectWebSocket(),
				computeReconnectDelay(reconnectAttempt++)
			);
		};

		ws.onerror = () => {
			// onclose will fire after onerror
		};
	}

	function sendInput(data: string) {
		if (ctrlActive) {
			ctrlActive = false;
			const code = data.toUpperCase().charCodeAt(0) - 64;
			if (code >= 0 && code <= 31) {
				data = String.fromCharCode(code);
			}
		}
		if (ws?.readyState === WebSocket.OPEN) {
			ws.send(encoder.encode(data));
		}
	}

	function preventFocusSteal(e: MouseEvent | TouchEvent) {
		e.preventDefault();
	}

	onMount(async () => {
		const ghostty = await import('ghostty-web');
		await ghostty.init();

		term = new ghostty.Terminal({
			cols: 80,
			rows: 24,
			fontSize: 14,
			fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace",
			theme: buildTheme()
		});

		term.open(containerEl);

		if (ghostty.FitAddon) {
			fitAddon = new ghostty.FitAddon();
			term.loadAddon(fitAddon);
			fitAddon.observeResize();
		}

		// All input (keyboard + iOS buttons) flows through sendInput
		term.onData((data: string) => {
			sendInput(data);
		});

		// Terminal resize → WebSocket
		term.onResize(({ cols, rows }: { cols: number; rows: number }) => {
			if (ws?.readyState === WebSocket.OPEN) {
				ws.send(JSON.stringify({ type: 'resize', cols, rows }));
			}
		});

		connectWebSocket();
		initialized = true;
	});

	onDestroy(() => {
		if (reconnectTimer) clearTimeout(reconnectTimer);
		ws?.close();
		term?.dispose();
	});

	// Re-fit when becoming visible (container has dimensions again)
	$effect(() => {
		if (visible && initialized) {
			requestAnimationFrame(() => {
				fitAddon?.fit?.();
			});
		}
	});
</script>

<div class="terminal-wrapper" class:hidden={!visible}>
	<div class="terminal-container" bind:this={containerEl}></div>
	<div class="ios-keys">
		<button type="button" class="key-btn" onmousedown={preventFocusSteal} onclick={() => sendInput('\x1b')}>Esc</button>
		<button type="button" class="key-btn" onmousedown={preventFocusSteal} onclick={() => sendInput('\t')}>Tab</button>
		<button
			type="button"
			class="key-btn"
			class:active={ctrlActive}
			onmousedown={preventFocusSteal}
			onclick={() => (ctrlActive = !ctrlActive)}>Ctrl</button
		>
		<button type="button" class="key-btn" onmousedown={preventFocusSteal} onclick={() => sendInput('\x1b[A')}>↑</button>
		<button type="button" class="key-btn" onmousedown={preventFocusSteal} onclick={() => sendInput('\x1b[B')}>↓</button>
		<button type="button" class="key-btn" onmousedown={preventFocusSteal} onclick={() => sendInput('\x1b[D')}>←</button>
		<button type="button" class="key-btn" onmousedown={preventFocusSteal} onclick={() => sendInput('\x1b[C')}>→</button>
		<button type="button" class="key-btn" onmousedown={preventFocusSteal} onclick={() => sendInput('|')}>|</button>
		<button type="button" class="key-btn" onmousedown={preventFocusSteal} onclick={() => sendInput('~')}>~</button>
		<button type="button" class="key-btn" onmousedown={preventFocusSteal} onclick={() => sendInput('-')}>-</button>
		<button type="button" class="key-btn" onmousedown={preventFocusSteal} onclick={() => sendInput('/')}>⁄</button>
	</div>
</div>

<style>
	.terminal-wrapper {
		display: flex;
		flex-direction: column;
		flex: 1;
		min-height: 0;
		overflow: hidden;
	}
	.terminal-wrapper.hidden {
		display: none;
	}
	.terminal-container {
		flex: 1;
		min-height: 0;
		padding: 4px;
	}
	.ios-keys {
		display: flex;
		gap: 4px;
		padding: 6px 8px;
		padding-bottom: max(6px, env(safe-area-inset-bottom));
		background: var(--surface-1);
		border-top: 1px solid var(--border);
		flex-wrap: wrap;
	}
	.key-btn {
		padding: 6px 12px;
		font-size: 13px;
		font-family: monospace;
		background: var(--surface-2);
		color: var(--color-text);
		border: 1px solid var(--border);
		border-radius: 4px;
		cursor: pointer;
		user-select: none;
		-webkit-tap-highlight-color: transparent;
		touch-action: manipulation;
	}
	.key-btn:active {
		background: var(--border-strong);
	}
	.key-btn.active {
		background: var(--primary-text);
		color: var(--color-bg);
		border-color: var(--primary-text);
	}

	@media (max-width: 480px) {
		.key-btn {
			padding: 8px 10px;
			font-size: 14px;
		}
		.ios-keys {
			gap: 3px;
			padding: 4px 6px;
			padding-bottom: max(4px, env(safe-area-inset-bottom));
		}
	}
</style>
