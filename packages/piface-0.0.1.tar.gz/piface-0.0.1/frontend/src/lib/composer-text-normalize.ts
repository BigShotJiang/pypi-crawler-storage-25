const CHAR_REPLACEMENTS: Record<string, string> = {
	'\u2018': "'", // left single quote
	'\u2019': "'", // right single quote / apostrophe
	'\u201A': "'", // single low-9 quote
	'\u201B': "'", // single high-reversed-9 quote
	'\u201C': '"', // left double quote
	'\u201D': '"', // right double quote
	'\u201E': '"', // double low-9 quote
	'\u201F': '"', // double high-reversed-9 quote
	'\u2010': '-', // hyphen
	'\u2011': '-', // non-breaking hyphen
	'\u2012': '-', // figure dash
	'\u2013': '-', // en dash
	'\u2014': '--', // em dash
	'\u2015': '--', // horizontal bar
	'\u2212': '-', // minus sign
	'\u2026': '...', // ellipsis
	'\u00A0': ' ' // non-breaking space
};

const SMART_TEXT_PATTERN = /[\u2018\u2019\u201A\u201B\u201C\u201D\u201E\u201F\u2010\u2011\u2012\u2013\u2014\u2015\u2212\u2026\u00A0]/g;

export function normalizeComposerText(input: string): string {
	if (!input) return '';
	return input.replaceAll(SMART_TEXT_PATTERN, (match) => CHAR_REPLACEMENTS[match] ?? match);
}
