import { tryCopyTextToClipboard } from './clipboard';
import { typesetMathInNode } from './mathjax';
import { renderMermaidInNode } from './mermaid';

export function enhanceRenderedMarkdown(node: HTMLElement, _version?: string) {
	function attachCopyButtons() {
		const pres = node.querySelectorAll<HTMLElement>('pre:not(.code-copy-attached)');
		for (const pre of pres) {
			pre.classList.add('code-copy-attached');

			const wrapper = document.createElement('div');
			wrapper.className = 'code-block-wrapper';
			pre.parentNode?.insertBefore(wrapper, pre);
			wrapper.appendChild(pre);

			const btn = document.createElement('button');
			btn.className = 'code-copy-btn';
			btn.setAttribute('aria-label', 'Copy code');
			btn.title = 'Copy code';
			btn.textContent = 'Copy';

			btn.addEventListener('click', async () => {
				const code = pre.querySelector('code')?.textContent ?? pre.textContent ?? '';
				const copied = await tryCopyTextToClipboard(code);
				if (copied) {
					btn.textContent = 'Copied!';
					btn.classList.add('copied');
				} else {
					btn.textContent = 'Error';
				}
				setTimeout(() => {
					btn.textContent = 'Copy';
					btn.classList.remove('copied');
				}, 2000);
			});

			wrapper.appendChild(btn);
		}
	}

	async function applyEnhancements(): Promise<void> {
		attachCopyButtons();
		await renderMermaidInNode(node);
		attachCopyButtons();
		await typesetMathInNode(node);
	}

	void applyEnhancements();
	return {
		update(_nextVersion?: string) {
			void applyEnhancements();
		},
		destroy() {}
	};
}
