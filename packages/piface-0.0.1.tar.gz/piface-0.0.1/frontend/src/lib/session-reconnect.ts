export const LIFECYCLE_RECONNECT_COOLDOWN_MS = 1200;

export type LifecycleReconnectInput = {
	sessionStatus: string | null | undefined;
	connected: boolean;
	hasSocket: boolean;
	isVisible: boolean;
	isOnline: boolean;
	nowMs: number;
	lastAttemptAtMs: number;
	cooldownMs?: number;
};

export function shouldAttemptLifecycleReconnect(input: LifecycleReconnectInput): boolean {
	if (input.sessionStatus !== 'live') return false;
	if (!input.isVisible) return false;
	if (!input.isOnline) return false;
	if (input.connected || input.hasSocket) return false;

	const cooldownMs =
		typeof input.cooldownMs === 'number' && input.cooldownMs >= 0
			? input.cooldownMs
			: LIFECYCLE_RECONNECT_COOLDOWN_MS;

	if (input.lastAttemptAtMs <= 0) return true;
	return input.nowMs - input.lastAttemptAtMs >= cooldownMs;
}
