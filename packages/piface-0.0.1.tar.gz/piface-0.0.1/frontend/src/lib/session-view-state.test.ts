import { describe, expect, it } from 'vitest';

import {
	captureChatScrollState,
	loadSessionViewState,
	loadSessionViewStateWithFallback,
	readSessionTabFromUrl,
	resolveChatScrollTop,
	saveSessionViewState,
	saveSessionViewStateWithFallback,
	toSessionTabHref,
	type SessionViewState
} from './session-view-state';

function createStorageMap(): Pick<Storage, 'getItem' | 'setItem'> & { store: Map<string, string> } {
	const store = new Map<string, string>();
	return {
		store,
		getItem: (key) => store.get(key) ?? null,
		setItem: (key, value) => {
			store.set(key, value);
		}
	};
}

describe('captureChatScrollState', () => {
	it('stores bottom mode when the viewport is already near the bottom', () => {
		expect(
			captureChatScrollState({
				scrollTop: 930,
				scrollHeight: 1000,
				clientHeight: 40,
				bottomThresholdPx: 32
			})
		).toEqual({ mode: 'bottom' });
	});

	it('stores offset-from-bottom when the viewport is away from the bottom', () => {
		expect(
			captureChatScrollState({
				scrollTop: 520,
				scrollHeight: 1200,
				clientHeight: 300,
				bottomThresholdPx: 32
			})
		).toEqual({ mode: 'offset', offsetFromBottom: 380 });
	});
});

describe('resolveChatScrollTop', () => {
	it('restores to the current bottom for bottom-mode snapshots', () => {
		expect(
			resolveChatScrollTop(
				{ mode: 'bottom' },
				{ scrollHeight: 1400, clientHeight: 320 }
			)
		).toBe(1080);
	});

	it('restores using the saved offset from the bottom', () => {
		expect(
			resolveChatScrollTop(
				{ mode: 'offset', offsetFromBottom: 180 },
				{ scrollHeight: 1400, clientHeight: 320 }
			)
		).toBe(900);
	});

	it('clamps offset restores inside the current scrollable range', () => {
		expect(
			resolveChatScrollTop(
				{ mode: 'offset', offsetFromBottom: 900 },
				{ scrollHeight: 500, clientHeight: 200 }
			)
		).toBe(0);
	});
});

describe('session view state storage', () => {
	it('round-trips persisted tab, files view, chat scroll state, and composer draft', () => {
		const storage = createStorageMap();
		const state: SessionViewState = {
			activeTab: 'files',
			filesView: {
				currentPath: '/tmp/project/src',
				selectedPath: '/tmp/project/src/main.ts',
				previewFullscreen: true
			},
			chatScroll: { mode: 'offset', offsetFromBottom: 240 },
			composerDraft: 'unfinished thought',
			timestamp: Date.now()
		};

		saveSessionViewState(storage, 'session-1', state);

		expect(loadSessionViewState(storage, 'session-1')).toEqual(state);
	});

	it('salvages malformed optional fields when the active tab is still valid', () => {
		const storage = createStorageMap();
		storage.setItem(
			'piface.session.view:session-1',
			JSON.stringify({
				activeTab: 'terminal',
				filesView: {
					currentPath: '/tmp/project/src',
					selectedPath: '/tmp/project/src/main.ts',
					previewFullscreen: 'oops'
				},
				chatScroll: { mode: 'offset', offsetFromBottom: 'oops' },
				composerDraft: 123,
				timestamp: Date.now()
			})
		);

		expect(loadSessionViewState(storage, 'session-1')).toEqual({
			activeTab: 'terminal',
			filesView: {
				currentPath: '/tmp/project/src',
				selectedPath: '/tmp/project/src/main.ts'
			},
			timestamp: expect.any(Number)
		});
	});

	it('rejects malformed or unsupported active tabs', () => {
		const storage = createStorageMap();
		storage.setItem(
			'piface.session.view:session-1',
			JSON.stringify({
				activeTab: 'invalid',
				timestamp: Date.now()
			})
		);

		expect(loadSessionViewState(storage, 'session-1')).toBeNull();
	});
});

describe('session view state fallback storage', () => {
	it('loads from fallback storage when session storage is empty', () => {
		const primary = createStorageMap();
		const fallback = createStorageMap();
		const state: SessionViewState = {
			activeTab: 'scratch',
			chatScroll: { mode: 'bottom' },
			composerDraft: 'keep this unsent',
			timestamp: Date.now()
		};
		saveSessionViewState(fallback, 'session-1', state);

		expect(loadSessionViewStateWithFallback(primary, fallback, 'session-1')).toEqual(state);
	});

	it('writes to fallback storage when primary storage throws', () => {
		const fallback = createStorageMap();
		const state: SessionViewState = {
			activeTab: 'chat',
			filesView: { currentPath: '', selectedPath: '' },
			timestamp: Date.now()
		};
		const primary: Pick<Storage, 'setItem'> = {
			setItem: () => {
				throw new Error('blocked');
			}
		};

		expect(() => saveSessionViewStateWithFallback(primary, fallback, 'session-1', state)).not.toThrow();
		expect(loadSessionViewState(fallback, 'session-1')).toEqual(state);
	});
});

describe('session tab url helpers', () => {
	it('reads supported tabs from the current URL', () => {
		expect(readSessionTabFromUrl('https://example.com/session/abc?tab=files')).toBe('files');
		expect(readSessionTabFromUrl('https://example.com/session/abc')).toBeNull();
		expect(readSessionTabFromUrl('https://example.com/session/abc?tab=nope')).toBeNull();
	});

	it('adds or removes the tab query parameter while preserving other URL parts', () => {
		expect(
			toSessionTabHref('https://example.com/session/abc?foo=1#chat', 'files')
		).toBe('/session/abc?foo=1&tab=files#chat');
		expect(
			toSessionTabHref('https://example.com/session/abc?foo=1&tab=files#chat', 'chat')
		).toBe('/session/abc?foo=1#chat');
	});
});
