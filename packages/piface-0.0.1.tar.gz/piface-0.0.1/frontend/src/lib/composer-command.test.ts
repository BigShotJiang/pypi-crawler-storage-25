import { describe, expect, it } from 'vitest';

import { isFollowUpShortcut, resolveComposerCommandType } from './composer-command';

describe('resolveComposerCommandType', () => {
	it('uses prompt when not streaming', () => {
		expect(resolveComposerCommandType({ isStreaming: false, followUpRequested: false })).toBe('prompt');
		expect(resolveComposerCommandType({ isStreaming: false, followUpRequested: true })).toBe('prompt');
	});

	it('uses steer by default while streaming', () => {
		expect(resolveComposerCommandType({ isStreaming: true, followUpRequested: false })).toBe('steer');
	});

	it('uses follow_up when explicitly requested while streaming', () => {
		expect(resolveComposerCommandType({ isStreaming: true, followUpRequested: true })).toBe('follow_up');
	});
});

describe('isFollowUpShortcut', () => {
	it('returns true for alt/ctrl/meta + enter shortcuts', () => {
		expect(isFollowUpShortcut({ altKey: true, ctrlKey: false, metaKey: false })).toBe(true);
		expect(isFollowUpShortcut({ altKey: false, ctrlKey: true, metaKey: false })).toBe(true);
		expect(isFollowUpShortcut({ altKey: false, ctrlKey: false, metaKey: true })).toBe(true);
	});

	it('returns false when no modifier is pressed', () => {
		expect(isFollowUpShortcut({ altKey: false, ctrlKey: false, metaKey: false })).toBe(false);
	});
});
