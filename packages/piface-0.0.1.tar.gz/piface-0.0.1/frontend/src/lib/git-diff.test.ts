import { describe, expect, it } from 'vitest';

import { defaultDiffModeIsStaged, formatStatusCode, type GitChangedFile } from './git-diff';

describe('defaultDiffModeIsStaged', () => {
	it('defaults to unstaged for mixed or unstaged-only files', () => {
		const file: GitChangedFile = {
			path: 'tracked.txt',
			status: ' M',
			staged: false,
			unstaged: true,
			untracked: false
		};
		expect(defaultDiffModeIsStaged(file)).toBe(false);
	});

	it('defaults to staged when file only has staged changes', () => {
		const file: GitChangedFile = {
			path: 'tracked.txt',
			status: 'M ',
			staged: true,
			unstaged: false,
			untracked: false
		};
		expect(defaultDiffModeIsStaged(file)).toBe(true);
	});

	it('defaults to unstaged for untracked files', () => {
		const file: GitChangedFile = {
			path: 'new.txt',
			status: '??',
			staged: false,
			unstaged: false,
			untracked: true
		};
		expect(defaultDiffModeIsStaged(file)).toBe(false);
	});
});

describe('formatStatusCode', () => {
	it('renders spaces as visible separators', () => {
		expect(formatStatusCode(' M')).toBe('·M');
		expect(formatStatusCode('M ')).toBe('M·');
		expect(formatStatusCode('??')).toBe('??');
	});
});
