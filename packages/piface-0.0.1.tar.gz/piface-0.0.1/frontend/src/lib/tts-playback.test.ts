import { describe, expect, it } from 'vitest';

import {
	formatPlaybackTime,
	getTtsPlaybackState,
	getTtsPrimaryActionLabel,
	getTtsProgressPercent,
	getTtsSeekBackLabel,
	getTtsSeekBackSeconds,
	isTtsPrimaryActionDisabled,
	seekPlaybackTime,
	shouldRenderTtsInlinePlayer
} from './tts-playback';

describe('formatPlaybackTime', () => {
	it('formats whole seconds as minutes and seconds', () => {
		expect(formatPlaybackTime(0)).toBe('0:00');
		expect(formatPlaybackTime(9)).toBe('0:09');
		expect(formatPlaybackTime(65)).toBe('1:05');
	});

	it('falls back to zero for invalid values', () => {
		expect(formatPlaybackTime(Number.NaN)).toBe('0:00');
		expect(formatPlaybackTime(Number.POSITIVE_INFINITY)).toBe('0:00');
	});
});

describe('seekPlaybackTime', () => {
	it('clamps seeks at zero', () => {
		expect(seekPlaybackTime(4, -15, 120)).toBe(0);
	});

	it('clamps seeks at the duration when known', () => {
		expect(seekPlaybackTime(50, 20, 60)).toBe(60);
	});

	it('allows forward seeks when duration is unknown', () => {
		expect(seekPlaybackTime(10, 15)).toBe(25);
	});
});

describe('getTtsPlaybackState', () => {
	it('returns loading for the message currently being synthesized', () => {
		expect(
			getTtsPlaybackState({
				messageKey: 'assistant-1',
				loadingMessageKey: 'assistant-1',
				activeMessageKey: '',
				isPlaying: false,
				hasPreparedAudio: false
			})
		).toBe('loading');
	});

	it('returns playing for the active playing message', () => {
		expect(
			getTtsPlaybackState({
				messageKey: 'assistant-1',
				loadingMessageKey: '',
				activeMessageKey: 'assistant-1',
				isPlaying: true,
				hasPreparedAudio: true
			})
		).toBe('playing');
	});

	it('returns paused for the active prepared message when not currently playing', () => {
		expect(
			getTtsPlaybackState({
				messageKey: 'assistant-1',
				loadingMessageKey: '',
				activeMessageKey: 'assistant-1',
				isPlaying: false,
				hasPreparedAudio: true
			})
		).toBe('paused');
	});

	it('returns idle for non-active messages', () => {
		expect(
			getTtsPlaybackState({
				messageKey: 'assistant-2',
				loadingMessageKey: '',
				activeMessageKey: 'assistant-1',
				isPlaying: false,
				hasPreparedAudio: false
			})
		).toBe('idle');
	});
});

describe('getTtsPrimaryActionLabel', () => {
	it('shows a loading label while the selected message is being synthesized', () => {
		expect(
			getTtsPrimaryActionLabel({
				messageKey: 'assistant-1',
				loadingMessageKey: 'assistant-1',
				activeMessageKey: '',
				isPlaying: false,
				hasPreparedAudio: false
			})
		).toBe('Generating audio…');
	});

	it('shows pause for the active playing message', () => {
		expect(
			getTtsPrimaryActionLabel({
				messageKey: 'assistant-1',
				loadingMessageKey: '',
				activeMessageKey: 'assistant-1',
				isPlaying: true,
				hasPreparedAudio: true
			})
		).toBe('Pause');
	});

	it('shows play for a prepared but paused active message', () => {
		expect(
			getTtsPrimaryActionLabel({
				messageKey: 'assistant-1',
				loadingMessageKey: '',
				activeMessageKey: 'assistant-1',
				isPlaying: false,
				hasPreparedAudio: true
			})
		).toBe('Play');
	});

	it('shows listen for messages that have not been prepared yet', () => {
		expect(
			getTtsPrimaryActionLabel({
				messageKey: 'assistant-2',
				loadingMessageKey: '',
				activeMessageKey: 'assistant-1',
				isPlaying: false,
				hasPreparedAudio: false
			})
		).toBe('Listen');
	});
});

describe('isTtsPrimaryActionDisabled', () => {
	it('disables all message triggers while any TTS request is loading', () => {
		expect(
			isTtsPrimaryActionDisabled({
				messageKey: 'assistant-1',
				loadingMessageKey: 'assistant-2'
			})
		).toBe(true);
		expect(
			isTtsPrimaryActionDisabled({
				messageKey: 'assistant-2',
				loadingMessageKey: 'assistant-2'
			})
		).toBe(true);
	});

	it('keeps triggers enabled when nothing is loading', () => {
		expect(
			isTtsPrimaryActionDisabled({
				messageKey: 'assistant-1',
				loadingMessageKey: ''
			})
		).toBe(false);
	});
});

describe('shouldRenderTtsInlinePlayer', () => {
	it('renders the inline player while a message is loading', () => {
		expect(
			shouldRenderTtsInlinePlayer({
				messageKey: 'assistant-1',
				loadingMessageKey: 'assistant-1',
				activeMessageKey: '',
				hasPreparedAudio: false,
				errorMessageKey: ''
			})
		).toBe(true);
	});

	it('renders the inline player for the active prepared message', () => {
		expect(
			shouldRenderTtsInlinePlayer({
				messageKey: 'assistant-1',
				loadingMessageKey: '',
				activeMessageKey: 'assistant-1',
				hasPreparedAudio: true,
				errorMessageKey: ''
			})
		).toBe(true);
	});

	it('renders the inline player for an error state so retry feedback stays in the footer', () => {
		expect(
			shouldRenderTtsInlinePlayer({
				messageKey: 'assistant-1',
				loadingMessageKey: '',
				activeMessageKey: '',
				hasPreparedAudio: false,
				errorMessageKey: 'assistant-1'
			})
		).toBe(true);
	});

	it('hides the inline player for idle messages', () => {
		expect(
			shouldRenderTtsInlinePlayer({
				messageKey: 'assistant-1',
				loadingMessageKey: '',
				activeMessageKey: '',
				hasPreparedAudio: false,
				errorMessageKey: ''
			})
		).toBe(false);
	});
});

describe('getTtsProgressPercent', () => {
	it('returns a clamped playback percentage', () => {
		expect(getTtsProgressPercent(15, 60)).toBe(25);
		expect(getTtsProgressPercent(-5, 60)).toBe(0);
		expect(getTtsProgressPercent(75, 60)).toBe(100);
	});

	it('returns zero when the duration is missing or invalid', () => {
		expect(getTtsProgressPercent(10, 0)).toBe(0);
		expect(getTtsProgressPercent(10, Number.NaN)).toBe(0);
	});
});

describe('getTtsSeekBackSeconds', () => {
	it('hides rewind for short clips', () => {
		expect(getTtsSeekBackSeconds(19)).toBeNull();
	});

	it('uses 10 seconds for medium clips', () => {
		expect(getTtsSeekBackSeconds(20)).toBe(10);
		expect(getTtsSeekBackLabel(20)).toBe('-10s');
	});

	it('uses 15 seconds for longer clips', () => {
		expect(getTtsSeekBackSeconds(90)).toBe(15);
		expect(getTtsSeekBackLabel(90)).toBe('-15s');
	});
});
