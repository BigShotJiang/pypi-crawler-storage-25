<script lang="ts">
	import DOMPurify from 'dompurify';
	import hljs from 'highlight.js/lib/common';

	import {
		buildPreviewCopyVariants,
		inferLanguageFromPath,
		relativePathFromRoot,
		type PreviewKind
	} from '$lib/file-viewer';
	import { type FilesViewState } from '$lib/files-view-state';
	import { loadRecentFiles, recordRecentFile } from '$lib/session-files';
	import { renderMarkdownForFile } from '$lib/markdown-file-render';
	import { enhanceRenderedMarkdown } from '$lib/rendered-markdown';
	import { tryCopyTextToClipboard } from '$lib/clipboard';

	type DirEntry = {
		name: string;
		path: string;
		is_dir: boolean;
	};

	type FilePreview = {
		path: string;
		name: string;
		size: number;
		mime_type: string;
		kind: PreviewKind;
		content: string | null;
		raw_url: string | null;
	};

	let {
		rootPath,
		initialCurrentPath = '',
		initialSelectedPath = '',
		initialPreviewFullscreen = false,
		onStateChange = (_state: FilesViewState) => {}
	}: {
		rootPath: string;
		initialCurrentPath?: string;
		initialSelectedPath?: string;
		initialPreviewFullscreen?: boolean;
		onStateChange?: (state: FilesViewState) => void;
	} = $props();

	let currentPath = $state('');
	let entries: DirEntry[] = $state([]);
	let loadingDirectory = $state(false);
	let directoryError = $state('');

	let selectedPath = $state('');
	let previewFullscreen = $state(false);
	let preview = $state<FilePreview | null>(null);
	let loadingPreview = $state(false);
	let previewError = $state('');
	let renderedMarkdown = $state('');
	let highlightedCode = $state('');

	let initializedRoot = $state('');
	const DEFAULT_COPY_BUTTON_LABEL = 'Copy source';

	let contextMenuVisible = $state(false);
	let contextMenuX = $state(0);
	let contextMenuY = $state(0);
	let contextMenuEntry = $state<DirEntry | null>(null);
	let copyButtonLabel = $state(DEFAULT_COPY_BUTTON_LABEL);
	let copyMessage = $state('');
	let recentFiles = $state<string[]>([]);
	let canEmitState = $state(false);
	let copyButtonResetTimer: ReturnType<typeof setTimeout> | null = null;

	function normalizePath(path: string): string {
		if (!path) return '';
		if (path === '/') return '/';
		return path.endsWith('/') ? path.replace(/\/+$/, '') : path;
	}

	function pathIsInsideRoot(path: string, root: string): boolean {
		if (!path || !root) return false;
		const normalizedRoot = normalizePath(root);
		const normalizedPath = normalizePath(path);
		if (normalizedRoot === '/') return normalizedPath.startsWith('/');
		if (normalizedPath === normalizedRoot) return true;
		return normalizedPath.startsWith(`${normalizedRoot}/`);
	}

	function directoryForFile(path: string): string {
		if (!path || path === '/') return '/';
		const trimmed = path.endsWith('/') && path.length > 1 ? path.slice(0, -1) : path;
		const slash = trimmed.lastIndexOf('/');
		if (slash <= 0) return '/';
		return trimmed.slice(0, slash);
	}

	function resolveInitialPaths(): {
		startPath: string;
		selectedFile: string;
		previewFullscreen: boolean;
	} {
		const selectedFile = pathIsInsideRoot(initialSelectedPath, rootPath) ? initialSelectedPath : '';
		const nextPreviewFullscreen = initialPreviewFullscreen && !!selectedFile;
		if (pathIsInsideRoot(initialCurrentPath, rootPath)) {
			return {
				startPath: initialCurrentPath,
				selectedFile,
				previewFullscreen: nextPreviewFullscreen
			};
		}
		if (selectedFile) {
			return {
				startPath: directoryForFile(selectedFile),
				selectedFile,
				previewFullscreen: nextPreviewFullscreen
			};
		}
		return { startPath: rootPath, selectedFile: '', previewFullscreen: false };
	}

	$effect(() => {
		if (!canEmitState) return;
		onStateChange({ currentPath, selectedPath, previewFullscreen });
	});

	$effect(() => {
		if (!rootPath || rootPath === initializedRoot) return;
		initializedRoot = rootPath;
		canEmitState = false;
		entries = [];
		preview = null;
		previewError = '';
		copyMessage = '';
		copyButtonLabel = DEFAULT_COPY_BUTTON_LABEL;
		recentFiles =
			typeof window === 'undefined'
				? []
				: (() => {
					try {
						return loadRecentFiles(window.localStorage, rootPath);
					} catch {
						return [];
					}
				})();
		closeContextMenu();

		const { startPath, selectedFile, previewFullscreen: nextPreviewFullscreen } = resolveInitialPaths();
		currentPath = startPath;
		selectedPath = selectedFile;
		previewFullscreen = nextPreviewFullscreen;
		const pendingRoot = rootPath;
		void restoreInitialView(startPath, selectedFile).finally(() => {
			if (rootPath === pendingRoot) {
				canEmitState = true;
			}
		});
	});

	$effect(() => {
		if (typeof window === 'undefined') return;

		const onKeyDown = (event: KeyboardEvent) => {
			if (event.key === 'Escape') {
				if (contextMenuVisible) {
					closeContextMenu();
					return;
				}
				if (previewFullscreen) {
					previewFullscreen = false;
				}
			}
		};

		window.addEventListener('keydown', onKeyDown);
		return () => window.removeEventListener('keydown', onKeyDown);
	});

	$effect(() => {
		if (!selectedPath && previewFullscreen) {
			previewFullscreen = false;
		}
	});

	$effect(() => {
		return () => {
			if (copyButtonResetTimer) {
				clearTimeout(copyButtonResetTimer);
			}
		};
	});

	async function loadDirectory(path: string): Promise<void> {
		closeContextMenu();
		loadingDirectory = true;
		directoryError = '';
		try {
			const res = await fetch(`/api/fs/list?path=${encodeURIComponent(path)}`);
			if (!res.ok) {
				const body = await res.json().catch(() => ({}));
				directoryError = body.detail ?? `Failed to list directory (${res.status})`;
				entries = [];
				return;
			}
			const data = await res.json();
			const loaded = (data.entries ?? []) as DirEntry[];
			entries = [...loaded].sort((a, b) => {
				if (a.is_dir && !b.is_dir) return -1;
				if (!a.is_dir && b.is_dir) return 1;
				return a.name.localeCompare(b.name);
			});
			currentPath = path;
		} catch {
			directoryError = 'Failed to list directory.';
			entries = [];
		} finally {
			loadingDirectory = false;
		}
	}

	async function restoreInitialView(startPath: string, selectedFile: string): Promise<void> {
		await loadDirectory(startPath || rootPath);
		if (!selectedFile) {
			preview = null;
			previewError = '';
			return;
		}
		await openFile(selectedFile);
	}

	function canGoUp(): boolean {
		return !!rootPath && !!currentPath && currentPath !== rootPath;
	}

	function parentPath(path: string): string {
		if (!path || path === '/') return '/';
		const trimmed = path.endsWith('/') && path.length > 1 ? path.slice(0, -1) : path;
		const slash = trimmed.lastIndexOf('/');
		if (slash <= 0) return '/';
		return trimmed.slice(0, slash);
	}

	async function goUp(): Promise<void> {
		if (!canGoUp()) return;
		const parent = parentPath(currentPath);
		const next = parent.length < rootPath.length ? rootPath : parent;
		await loadDirectory(next);
	}

	function togglePreviewFullscreen(): void {
		if (!selectedPath) return;
		previewFullscreen = !previewFullscreen;
	}

	async function openEntry(entry: DirEntry): Promise<void> {
		if (entry.is_dir) {
			previewFullscreen = false;
			await loadDirectory(entry.path);
			return;
		}
		await openFile(entry.path);
	}

	function closeContextMenu(): void {
		contextMenuVisible = false;
		contextMenuEntry = null;
	}

	function openContextMenu(event: MouseEvent, entry: DirEntry): void {
		event.preventDefault();
		contextMenuX = event.clientX;
		contextMenuY = event.clientY;
		contextMenuEntry = entry;
		contextMenuVisible = true;
	}

	function setCopyButtonState(text: string): void {
		copyButtonLabel = text;
		if (copyButtonResetTimer) {
			clearTimeout(copyButtonResetTimer);
			copyButtonResetTimer = null;
		}
		if (text !== DEFAULT_COPY_BUTTON_LABEL) {
			copyButtonResetTimer = setTimeout(() => {
				copyButtonLabel = DEFAULT_COPY_BUTTON_LABEL;
				copyButtonResetTimer = null;
			}, 1800);
		}
	}

	async function copyCurrentPreviewWithFallback(): Promise<'content' | 'relative-path' | 'absolute-path' | null> {
		if (!preview) return null;
		for (const candidate of buildPreviewCopyVariants(rootPath, {
			kind: preview.kind,
			path: preview.path,
			content: preview.content
		})) {
			if (await tryCopyTextToClipboard(candidate.value)) {
				return candidate.kind;
			}
		}
		return null;
	}

	async function copyTextToClipboard(text: string): Promise<boolean> {
		const copied = await tryCopyTextToClipboard(text);
		if (!copied) {
			copyMessage = 'Clipboard is unavailable. Try opening Piface over HTTPS or localhost.';
		}
		return copied;
	}

	async function copyCurrentPreviewPath(): Promise<void> {
		if (!preview) return;
		copyMessage = '';
		const copiedKind = await copyCurrentPreviewWithFallback();
		if (copiedKind === 'content') {
			setCopyButtonState('Copied source');
			return;
		}
		if (copiedKind === 'relative-path') {
			setCopyButtonState('Copied rel path');
			return;
		}
		if (copiedKind === 'absolute-path') {
			setCopyButtonState('Copied path');
			return;
		}
		copyMessage = 'Failed to copy to clipboard.';
		setCopyButtonState('Copy failed');
	}

	async function copyCurrentPreviewAbsolutePath(): Promise<void> {
		if (!preview) return;
		copyMessage = '';
		await copyTextToClipboard(preview.path);
	}

	async function copyAbsolutePath(): Promise<void> {
		if (!contextMenuEntry) return;
		copyMessage = '';
		await copyTextToClipboard(contextMenuEntry.path);
		closeContextMenu();
	}

	async function copyRelativePath(): Promise<void> {
		if (!contextMenuEntry) return;
		copyMessage = '';
		await copyTextToClipboard(relativePathFromRoot(rootPath, contextMenuEntry.path));
		closeContextMenu();
	}

	function rawUrlFor(previewData: FilePreview): string {
		return previewData.raw_url ?? `/api/fs/raw?path=${encodeURIComponent(previewData.path)}`;
	}

	function bindMarkdownLinkClicks(node: HTMLElement) {
		const onClick = (event: MouseEvent) => onMarkdownClick(event);
		node.addEventListener('click', onClick);
		return {
			destroy() {
				node.removeEventListener('click', onClick);
			}
		};
	}

	function resolveMarkdownLinkPath(href: string): string | null {
		if (!href) return null;
		try {
			const absolute = new URL(href, window.location.origin);
			if (absolute.pathname !== '/api/fs/raw') return null;
			return absolute.searchParams.get('path');
		} catch {
			return null;
		}
	}

	async function openPathFromMarkdownLink(rawPath: string): Promise<void> {
		const trimmedPath = rawPath;
		if (!trimmedPath) return;

		try {
			const directoryResponse = await fetch(`/api/fs/list?path=${encodeURIComponent(trimmedPath)}`);
			if (directoryResponse.ok) {
				selectedPath = '';
				previewFullscreen = false;
				preview = null;
				renderedMarkdown = '';
				highlightedCode = '';
				copyMessage = '';
				setCopyButtonState(DEFAULT_COPY_BUTTON_LABEL);
				await loadDirectory(trimmedPath);
				return;
			}
		} catch {
			// Fall through to file preview.
		}

		await openFile(trimmedPath);
	}

	function onMarkdownClick(event: MouseEvent): void {
		if (event.button !== 0) return;
		if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
		if (event.defaultPrevented) return;
		if (!(event.target instanceof Element)) return;
		const link = event.target.closest('a');
		if (!link) return;
		const href = link.getAttribute('href');
		const relativePath = href ? resolveMarkdownLinkPath(href) : null;
		if (!relativePath) return;

		event.preventDefault();
		void openPathFromMarkdownLink(relativePath);
	}

	function recentFileLabel(path: string): string {
		return relativePathFromRoot(rootPath, path);
	}

	async function openRecentFile(path: string): Promise<void> {
		if (!pathIsInsideRoot(path, rootPath)) return;
		const directory = directoryForFile(path);
		if (directory !== currentPath) {
			await loadDirectory(directory);
		}
		await openFile(path);
	}

	function updateRecentFiles(path: string): void {
		if (typeof window === 'undefined' || !rootPath) return;
		try {
			recentFiles = recordRecentFile(window.localStorage, rootPath, path);
		} catch {
			// Ignore transient browser storage failures.
		}
	}

	async function openFile(path: string): Promise<void> {
		selectedPath = path;
		loadingPreview = true;
		previewError = '';
		copyMessage = '';
		setCopyButtonState(DEFAULT_COPY_BUTTON_LABEL);
		renderedMarkdown = '';
		highlightedCode = '';
		try {
			const res = await fetch(`/api/fs/file?path=${encodeURIComponent(path)}`);
			if (!res.ok) {
				const body = await res.json().catch(() => ({}));
				previewError = body.detail ?? `Failed to preview file (${res.status})`;
				preview = null;
				return;
			}
			const data = (await res.json()) as FilePreview;
			preview = data;

			if (data.kind === 'markdown' && data.content) {
				renderedMarkdown = DOMPurify.sanitize(renderMarkdownForFile(data.content, data.path));
			}
			if (data.kind === 'code' && data.content) {
				const language = inferLanguageFromPath(data.path);
				if (language && hljs.getLanguage(language)) {
					highlightedCode = hljs.highlight(data.content, {
						language,
						ignoreIllegals: true
					}).value;
				} else {
					highlightedCode = hljs.highlightAuto(data.content).value;
				}
			}
			updateRecentFiles(data.path);
		} catch {
			previewError = 'Failed to preview file.';
			preview = null;
		} finally {
			loadingPreview = false;
		}
	}
</script>

<div class="file-viewer" class:preview-fullscreen={previewFullscreen}>
	<aside class="browser">
		<div class="browser-toolbar">
			<button class="btn" type="button" onclick={goUp} disabled={!canGoUp()}>Up</button>
			<div class="cwd" title={currentPath}>{currentPath || '—'}</div>
		</div>

		<div class="browser-body">
			{#if loadingDirectory}
				<p class="state">Loading files…</p>
			{:else if directoryError}
				<p class="state error">{directoryError}</p>
			{:else if entries.length === 0}
				<p class="state">This folder is empty.</p>
			{:else}
				<ul class="entry-list">
					{#each entries as entry}
						<li>
							<button
								type="button"
								class="entry"
								class:selected={selectedPath === entry.path}
								onclick={() => openEntry(entry)}
								oncontextmenu={(event) => openContextMenu(event, entry)}
								title={entry.path}
							>
								<span class="icon">{entry.is_dir ? '📁' : '📄'}</span>
								<span class="name">{entry.name}</span>
							</button>
						</li>
					{/each}
				</ul>
			{/if}

			<section class="recent-files">
				<h3>Recent files</h3>
				{#if recentFiles.length === 0}
					<p class="recent-empty">No recent files yet.</p>
				{:else}
					<ul class="recent-list">
						{#each recentFiles as path}
							<li>
								<button
									type="button"
									class="entry recent-entry"
									class:selected={selectedPath === path}
									onclick={() => openRecentFile(path)}
									title={path}
								>
									<span class="icon">🕘</span>
									<span class="name">{recentFileLabel(path)}</span>
								</button>
							</li>
						{/each}
					</ul>
				{/if}
			</section>
		</div>
	</aside>

	<section class="preview">
		<div class="preview-toolbar">
			<button
				class="preview-path"
				type="button"
				disabled={!preview}
				onclick={copyCurrentPreviewAbsolutePath}
				title={preview?.path ? `Copy absolute path: ${preview.path}` : 'No file selected'}
			>
				{preview?.path ?? 'No file selected'}
			</button>
			<div class="preview-toolbar-actions">
				{#if copyMessage}
					<span class="copy-message">{copyMessage}</span>
				{/if}
				<button
					class="btn"
					type="button"
					onclick={togglePreviewFullscreen}
					disabled={!selectedPath}
					aria-pressed={previewFullscreen}
					title={previewFullscreen ? 'Exit fullscreen file preview' : 'Expand file preview'}
				>
					{previewFullscreen ? 'Exit fullscreen' : 'Fullscreen'}
				</button>
				<button class="btn" type="button" onclick={copyCurrentPreviewPath} disabled={!preview}>
					{copyButtonLabel}
				</button>
			</div>
		</div>

		<div class="preview-content">
			{#if loadingPreview}
				<div class="state">Loading preview…</div>
			{:else if previewError}
				<div class="state error">{previewError}</div>
			{:else if !preview}
				<div class="state">Select a file to preview it.</div>
			{:else if preview.kind === 'image'}
				<div class="image-wrap">
					<img src={rawUrlFor(preview)} alt={preview.name} loading="lazy" />
				</div>
			{:else if preview.kind === 'html'}
				<iframe class="html-frame" title={preview.name} src={rawUrlFor(preview)}></iframe>
			{:else if preview.kind === 'markdown'}
				<article class="markdown" use:enhanceRenderedMarkdown={renderedMarkdown} use:bindMarkdownLinkClicks>{@html renderedMarkdown}</article>
			{:else if preview.kind === 'code'}
				<pre class="code-view"><code class="hljs">{@html highlightedCode}</code></pre>
			{:else}
				<div class="state">This file type is not previewable.</div>
			{/if}
		</div>
	</section>

	{#if contextMenuVisible && contextMenuEntry}
		<button class="context-backdrop" type="button" aria-label="Close context menu" onclick={closeContextMenu}></button>
		<div class="context-menu" style={`left: ${contextMenuX}px; top: ${contextMenuY}px;`} role="menu">
			<button type="button" role="menuitem" onclick={copyAbsolutePath}>Copy absolute path</button>
			<button type="button" role="menuitem" onclick={copyRelativePath}>Copy relative path</button>
		</div>
	{/if}
</div>

<style>
	.file-viewer {
		display: grid;
		grid-template-columns: minmax(220px, 320px) minmax(0, 1fr);
		gap: 0.75rem;
		height: 100%;
		min-height: 0;
	}

	.file-viewer.preview-fullscreen {
		grid-template-columns: minmax(0, 1fr);
	}

	.file-viewer.preview-fullscreen .browser {
		display: none;
	}

	.browser,
	.preview {
		background: var(--surface-1);
		border: 1px solid var(--border-soft);
		border-radius: 8px;
		min-height: 0;
	}

	.browser {
		display: flex;
		flex-direction: column;
		overflow: hidden;
	}

	.browser-body {
		flex: 1;
		min-height: 0;
		overflow-y: auto;
	}

	.browser-toolbar {
		display: flex;
		gap: 0.45rem;
		align-items: center;
		padding: 0.6rem;
		border-bottom: 1px solid var(--border-soft);
	}

	.cwd {
		font-family: ui-monospace, 'SF Mono', monospace;
		font-size: 0.75rem;
		color: var(--color-subtle);
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}

	.entry-list,
	.recent-list {
		list-style: none;
		padding: 0.35rem;
		margin: 0;
	}

	.recent-files {
		border-top: 1px solid var(--border-soft);
		padding: 0.55rem 0.35rem 0.35rem;
	}

	.recent-files h3 {
		margin: 0 0 0.35rem;
		padding: 0 0.35rem;
		font-size: 0.76rem;
		font-weight: 600;
		letter-spacing: 0.02em;
		text-transform: uppercase;
		color: var(--color-subtle);
	}

	.recent-empty {
		margin: 0;
		padding: 0 0.35rem 0.35rem;
		font-size: 0.8rem;
		color: var(--color-subtle);
	}

	.entry {
		display: flex;
		align-items: center;
		gap: 0.45rem;
		width: 100%;
		text-align: left;
		border: none;
		border-radius: 6px;
		padding: 0.35rem 0.45rem;
		background: transparent;
		color: var(--color-text);
		cursor: pointer;
	}

	.entry:hover {
		background: var(--surface-hover);
	}

	.entry.selected {
		background: var(--primary-bg);
		outline: 1px solid var(--primary-border);
	}

	.icon {
		flex-shrink: 0;
	}

	.name {
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		font-size: 0.85rem;
	}

	.preview {
		display: flex;
		flex-direction: column;
		min-height: 0;
		overflow: hidden;
	}

	.preview-toolbar {
		display: flex;
		align-items: center;
		gap: 0.5rem;
		justify-content: space-between;
		padding: 0.6rem;
		border-bottom: 1px solid var(--border-soft);
	}

	.preview-toolbar-actions {
		display: flex;
		align-items: center;
		justify-content: flex-end;
		gap: 0.5rem;
		flex-wrap: wrap;
		flex-shrink: 0;
	}

	.copy-message {
		font-size: 0.73rem;
		color: var(--danger-text);
	}

	.preview-path {
		flex: 1;
		font-family: ui-monospace, 'SF Mono', monospace;
		font-size: 0.75rem;
		color: var(--color-subtle);
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		min-width: 0;
		text-align: left;
		border: none;
		padding: 0;
		background: transparent;
		cursor: pointer;
	}

	.preview-path:not(:disabled):hover {
		color: var(--color-text);
	}

	.preview-path:disabled {
		cursor: not-allowed;
	}

	.preview-content {
		flex: 1;
		min-height: 0;
		overflow: auto;
	}

	.state {
		margin: 0;
		padding: 1rem;
		color: var(--color-subtle);
	}

	.state.error {
		color: var(--danger-text);
	}

	.image-wrap {
		display: flex;
		justify-content: center;
		padding: 1rem;
	}

	.image-wrap img {
		max-width: 100%;
		height: auto;
		border-radius: 8px;
		border: 1px solid var(--border-soft);
	}

	.html-frame {
		width: 100%;
		height: 100%;
		min-height: 55vh;
		border: none;
		background: white;
	}

	.markdown {
		padding: 1rem;
		line-height: 1.55;
	}

	.markdown :global(pre) {
		overflow: auto;
		padding: 0.75rem;
		border-radius: 6px;
		background: var(--surface-3);
	}

	.markdown :global(code) {
		font-family: ui-monospace, 'SF Mono', monospace;
	}

	.markdown :global(img) {
		max-width: 100%;
	}

	.markdown :global(.math-inline) {
		white-space: nowrap;
	}

	.markdown :global(.math-display) {
		overflow-x: auto;
		margin: 0.8rem 0;
	}

	.markdown :global(.code-block-wrapper) {
		position: relative;
	}

	.markdown :global(.code-copy-btn) {
		position: absolute;
		top: 0.35rem;
		right: 0.35rem;
		padding: 0.15rem 0.5rem;
		font-size: 0.7rem;
		line-height: 1.4;
		font-family: system-ui, -apple-system, sans-serif;
		border: 1px solid var(--border-strong);
		border-radius: 4px;
		background: var(--surface-2);
		color: var(--color-muted-2);
		cursor: pointer;
		opacity: 0;
		transition: opacity 0.15s ease, background 0.15s ease, color 0.15s ease;
		z-index: 1;
	}

	.markdown :global(.code-block-wrapper:hover .code-copy-btn) {
		opacity: 1;
	}

	.markdown :global(.code-copy-btn:hover) {
		background: var(--surface-hover);
		color: var(--color-text);
	}

	.markdown :global(.code-copy-btn.copied) {
		background: color-mix(in srgb, var(--success-text) 15%, var(--surface-2));
		border-color: var(--success-text);
		color: var(--success-text);
		opacity: 1;
	}

	.markdown :global(.mermaid-block) {
		margin: 1rem 0;
	}

	.markdown :global(.mermaid-render-surface) {
		display: flex;
		justify-content: center;
		align-items: center;
		min-height: 5rem;
		padding: 0.75rem;
		border-radius: 8px;
		border: 1px solid var(--border-soft);
		background: var(--surface-2);
		overflow-x: auto;
	}

	.markdown :global(.mermaid-render-placeholder) {
		color: var(--color-muted);
		font-size: 0.85rem;
	}

	.markdown :global(.mermaid-render-surface svg) {
		max-width: 100%;
		height: auto;
	}

	.markdown :global(.mermaid-render-error) {
		color: var(--danger-text);
		font-size: 0.85rem;
	}

	.markdown :global(.mermaid-source-details) {
		margin-top: 0.55rem;
	}

	.markdown :global(.mermaid-source-details summary) {
		cursor: pointer;
		color: var(--color-muted-2);
		font-size: 0.8rem;
	}

	.code-view {
		margin: 0;
		padding: 1rem;
		min-height: 100%;
		overflow: auto;
		font-size: 0.84rem;
		line-height: 1.45;
		font-family: ui-monospace, 'SF Mono', monospace;
	}

	.code-view :global(.hljs) {
		background: transparent;
		color: var(--color-text);
	}

	.code-view :global(.hljs-keyword),
	.code-view :global(.hljs-selector-tag),
	.code-view :global(.hljs-literal),
	.code-view :global(.hljs-section),
	.code-view :global(.hljs-link) {
		color: #c792ea;
	}

	.code-view :global(.hljs-string),
	.code-view :global(.hljs-title),
	.code-view :global(.hljs-name),
	.code-view :global(.hljs-type),
	.code-view :global(.hljs-attribute),
	.code-view :global(.hljs-symbol),
	.code-view :global(.hljs-bullet),
	.code-view :global(.hljs-addition),
	.code-view :global(.hljs-variable),
	.code-view :global(.hljs-template-tag),
	.code-view :global(.hljs-template-variable) {
		color: #8bd5ca;
	}

	.code-view :global(.hljs-comment),
	.code-view :global(.hljs-quote),
	.code-view :global(.hljs-deletion),
	.code-view :global(.hljs-meta) {
		color: #7f8c98;
	}

	.code-view :global(.hljs-number),
	.code-view :global(.hljs-regexp),
	.code-view :global(.hljs-selector-class),
	.code-view :global(.hljs-selector-attr),
	.code-view :global(.hljs-selector-pseudo) {
		color: #f6c177;
	}

	.btn {
		padding: 0.3rem 0.6rem;
		border: 1px solid var(--border-strong);
		border-radius: 6px;
		background: var(--surface-2);
		color: var(--color-text);
		cursor: pointer;
		font-size: 0.75rem;
	}

	.btn:disabled {
		opacity: 0.4;
		cursor: not-allowed;
	}

	.context-backdrop {
		position: fixed;
		inset: 0;
		border: none;
		background: transparent;
		padding: 0;
		margin: 0;
		z-index: 40;
	}

	.context-menu {
		position: fixed;
		z-index: 45;
		min-width: 12rem;
		display: flex;
		flex-direction: column;
		background: var(--surface-2);
		border: 1px solid var(--border-strong);
		border-radius: 8px;
		box-shadow: 0 12px 28px rgba(0, 0, 0, 0.35);
		overflow: hidden;
	}

	.context-menu button {
		background: transparent;
		color: var(--color-text);
		border: none;
		text-align: left;
		padding: 0.5rem 0.75rem;
		font-size: 0.82rem;
		cursor: pointer;
	}

	.context-menu button:hover {
		background: var(--surface-hover);
	}

	@media (max-width: 900px) {
		.file-viewer {
			display: flex;
			flex-direction: column;
		}

		.browser {
			min-height: 10rem;
			max-height: 42vh;
		}

		.preview {
			min-height: 35vh;
		}

		.html-frame {
			min-height: 40vh;
		}
	}
</style>
