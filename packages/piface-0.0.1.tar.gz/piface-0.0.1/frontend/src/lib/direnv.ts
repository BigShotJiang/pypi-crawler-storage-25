type FetchLike = (input: string, init?: { method?: string; headers?: Record<string, string>; body?: string }) => Promise<{
	ok: boolean;
	status?: number;
	json?: () => Promise<any>;
}>;

export function isDirenvBlockedError(detail: string | null | undefined): boolean {
	if (!detail) return false;
	const text = detail.toLowerCase();
	return text.includes('direnv') && text.includes('.envrc') && text.includes('blocked');
}

export async function allowDirenvForDirectory(input: {
	workingDir: string;
	fetchImpl?: FetchLike;
}): Promise<{ ok: true } | { ok: false; error: string }> {
	const { workingDir } = input;
	const fetchImpl: FetchLike =
		input.fetchImpl ?? ((url, init) => fetch(url, init as RequestInit) as any);

	const response = await fetchImpl('/api/direnv/allow', {
		method: 'POST',
		headers: { 'Content-Type': 'application/json' },
		body: JSON.stringify({ working_dir: workingDir })
	});

	if (response.ok) {
		return { ok: true };
	}

	const body = await response.json?.().catch(() => ({}));
	return {
		ok: false,
		error: body?.detail ?? `Failed to allow direnv (${response.status ?? 0}).`
	};
}
