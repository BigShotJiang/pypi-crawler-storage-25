import { describe, expect, it } from 'vitest';

import { collectFilesFromTransfer } from './image-input';

type FakeFile = {
	type: string;
	name: string;
};

function listLike<T>(values: T[]): ArrayLike<T> {
	return Object.assign([...values], { length: values.length });
}

describe('collectFilesFromTransfer', () => {
	it('returns empty list when transfer is missing', () => {
		expect(collectFilesFromTransfer<FakeFile>(null)).toEqual([]);
		expect(collectFilesFromTransfer<FakeFile>(undefined)).toEqual([]);
	});

	it('collects files from transfer.files', () => {
		const photo: FakeFile = { type: 'image/png', name: 'photo.png' };
		const txt: FakeFile = { type: 'text/plain', name: 'notes.txt' };

		const files = collectFilesFromTransfer<FakeFile>({
			files: listLike([photo, txt])
		});

		expect(files).toEqual([photo, txt]);
	});

	it('prefers transfer.items when files are present', () => {
		const jpg: FakeFile = { type: 'image/jpeg', name: 'camera.jpg' };
		const txt: FakeFile = { type: 'text/plain', name: 'notes.txt' };

		const files = collectFilesFromTransfer<FakeFile>({
			items: listLike([
				{ kind: 'file', type: 'image/jpeg', getAsFile: () => jpg },
				{ kind: 'file', type: 'text/plain', getAsFile: () => txt }
			]),
			files: listLike([])
		});

		expect(files).toEqual([jpg, txt]);
	});

	it('falls back to transfer.files when items have no files', () => {
		const gif: FakeFile = { type: 'image/gif', name: 'fun.gif' };

		const files = collectFilesFromTransfer<FakeFile>({
			items: listLike([{ kind: 'string', type: 'text/plain', getAsFile: () => null }]),
			files: listLike([gif])
		});

		expect(files).toEqual([gif]);
	});

	it('deduplicates repeated file references', () => {
		const webp: FakeFile = { type: 'image/webp', name: 'same.webp' };

		const files = collectFilesFromTransfer<FakeFile>({
			items: listLike([
				{ kind: 'file', type: 'image/webp', getAsFile: () => webp },
				{ kind: 'file', type: 'image/webp', getAsFile: () => webp }
			]),
			files: listLike([webp])
		});

		expect(files).toEqual([webp]);
	});
});
