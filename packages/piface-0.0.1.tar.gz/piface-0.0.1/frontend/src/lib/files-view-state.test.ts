import { describe, expect, it } from 'vitest';

import {
	createDefaultFilesViewState,
	normalizeFilesViewState,
	withDefaultFilesViewState
} from './files-view-state';

describe('normalizeFilesViewState', () => {
	it('accepts valid files view state with preview fullscreen enabled', () => {
		expect(
			normalizeFilesViewState({
				currentPath: '/tmp/project/docs',
				selectedPath: '/tmp/project/docs/README.md',
				previewFullscreen: true
			})
		).toEqual({
			currentPath: '/tmp/project/docs',
			selectedPath: '/tmp/project/docs/README.md',
			previewFullscreen: true
		});
	});

	it('drops malformed preview fullscreen values while preserving required paths', () => {
		expect(
			normalizeFilesViewState({
				currentPath: '/tmp/project/docs',
				selectedPath: '/tmp/project/docs/README.md',
				previewFullscreen: 'yes'
			})
		).toEqual({
			currentPath: '/tmp/project/docs',
			selectedPath: '/tmp/project/docs/README.md'
		});
	});

	it('rejects malformed required path fields', () => {
		expect(
			normalizeFilesViewState({
				currentPath: 123,
				selectedPath: '/tmp/project/docs/README.md',
				previewFullscreen: true
			})
		).toBeNull();
	});
});

describe('withDefaultFilesViewState', () => {
	it('fills in preview fullscreen as false when omitted', () => {
		expect(
			withDefaultFilesViewState({
				currentPath: '/tmp/project/docs',
				selectedPath: '/tmp/project/docs/README.md'
			})
		).toEqual({
			currentPath: '/tmp/project/docs',
			selectedPath: '/tmp/project/docs/README.md',
			previewFullscreen: false
		});
	});

	it('returns the default empty view state when no persisted value exists', () => {
		expect(withDefaultFilesViewState(null)).toEqual(createDefaultFilesViewState());
		expect(withDefaultFilesViewState(undefined)).toEqual(createDefaultFilesViewState());
	});
});
