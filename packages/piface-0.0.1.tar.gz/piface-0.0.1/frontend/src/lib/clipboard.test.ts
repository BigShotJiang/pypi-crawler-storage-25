import { describe, expect, it, vi } from 'vitest';

import { tryCopyTextToClipboard } from './clipboard';

describe('tryCopyTextToClipboard', () => {
	it('uses navigator.clipboard when available', async () => {
		const writeText = vi.fn(async () => {});
		const legacyCopy = vi.fn(() => false);

		const copied = await tryCopyTextToClipboard('hello', {
			navigator: { clipboard: { writeText } },
			legacyCopy
		});

		expect(copied).toBe(true);
		expect(writeText).toHaveBeenCalledWith('hello');
		expect(legacyCopy).not.toHaveBeenCalled();
	});

	it('falls back to legacy copy when clipboard API throws', async () => {
		const writeText = vi.fn(async () => {
			throw new Error('denied');
		});
		const legacyCopy = vi.fn(() => true);

		const copied = await tryCopyTextToClipboard('hello', {
			navigator: { clipboard: { writeText } },
			legacyCopy
		});

		expect(copied).toBe(true);
		expect(legacyCopy).toHaveBeenCalledWith('hello');
	});

	it('falls back to legacy copy when clipboard API is unavailable', async () => {
		const legacyCopy = vi.fn(() => true);

		const copied = await tryCopyTextToClipboard('hello', {
			navigator: {},
			legacyCopy
		});

		expect(copied).toBe(true);
		expect(legacyCopy).toHaveBeenCalledWith('hello');
	});
});
