export const MOBILE_COMPOSER_BREAKPOINT_PX = 480;
export const COMPOSER_MAX_VIEWPORT_RATIO = 0.4;

export interface ComposerHeightInput {
	scrollHeight: number;
	minHeight: number;
	viewportHeight: number;
	maxViewportRatio?: number;
}

export interface ComposerHeightResult {
	height: number;
	maxHeight: number;
	isClamped: boolean;
}

export interface MobileComposerFullscreenState {
	isFullscreen: boolean;
	autoEnterOnFocus: boolean;
}

export function computeComposerHeight({
	scrollHeight,
	minHeight,
	viewportHeight,
	maxViewportRatio = COMPOSER_MAX_VIEWPORT_RATIO
}: ComposerHeightInput): ComposerHeightResult {
	const maxHeight = Math.max(minHeight, Math.floor(viewportHeight * maxViewportRatio));
	const height = Math.max(minHeight, Math.min(scrollHeight, maxHeight));
	return {
		height,
		maxHeight,
		isClamped: scrollHeight > maxHeight
	};
}

export function isMobileComposerViewport(
	width: number,
	breakpoint = MOBILE_COMPOSER_BREAKPOINT_PX
): boolean {
	return width <= breakpoint;
}

export function createMobileComposerFullscreenState(): MobileComposerFullscreenState {
	return {
		isFullscreen: false,
		autoEnterOnFocus: false
	};
}

export function enterMobileComposerFullscreenOnFocus(
	state: MobileComposerFullscreenState,
	isMobileViewport: boolean
): MobileComposerFullscreenState {
	if (!isMobileViewport || !state.autoEnterOnFocus) {
		return state;
	}
	return {
		...state,
		isFullscreen: true
	};
}

export function exitMobileComposerFullscreen(
	state: MobileComposerFullscreenState
): MobileComposerFullscreenState {
	return {
		...state,
		isFullscreen: false,
		autoEnterOnFocus: false
	};
}

export function resetMobileComposerAutoEnter(
	state: MobileComposerFullscreenState
): MobileComposerFullscreenState {
	return {
		...state,
		autoEnterOnFocus: false
	};
}
