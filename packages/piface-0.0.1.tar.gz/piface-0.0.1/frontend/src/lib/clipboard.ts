type ClipboardNavigator = {
	clipboard?: {
		writeText: (text: string) => Promise<void>;
	};
};

export type ClipboardCopyOptions = {
	navigator?: ClipboardNavigator | null;
	document?: Document | null;
	legacyCopy?: (text: string) => boolean;
};

export function legacyCopyViaExecCommand(text: string, doc?: Document | null): boolean {
	const resolvedDocument = doc ?? (typeof document !== 'undefined' ? document : null);
	if (!resolvedDocument) return false;

	const textarea = resolvedDocument.createElement('textarea');
	textarea.value = text;
	textarea.setAttribute('readonly', '');
	textarea.style.position = 'fixed';
	textarea.style.left = '-9999px';
	resolvedDocument.body.appendChild(textarea);
	textarea.select();
	textarea.setSelectionRange(0, textarea.value.length);

	let copied = false;
	try {
		copied = resolvedDocument.execCommand('copy');
	} catch {
		copied = false;
	}

	resolvedDocument.body.removeChild(textarea);
	return copied;
}

export async function tryCopyTextToClipboard(
	text: string,
	options: ClipboardCopyOptions = {}
): Promise<boolean> {
	const resolvedNavigator = options.navigator ?? (typeof navigator !== 'undefined' ? navigator : null);
	try {
		if (resolvedNavigator?.clipboard?.writeText) {
			await resolvedNavigator.clipboard.writeText(text);
			return true;
		}
	} catch {
		// Fall through to legacy fallback.
	}

	if (options.legacyCopy) {
		return options.legacyCopy(text);
	}
	return legacyCopyViaExecCommand(text, options.document);
}
