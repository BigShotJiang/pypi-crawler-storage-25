export type ReplayApplyResult = {
	messages: any[];
	changed: boolean;
};

function normalizeReplayPayload(value: unknown): any[] {
	return Array.isArray(value) ? value : [];
}

function trySerializeMessages(messages: any[]): string | null {
	try {
		return JSON.stringify(messages);
	} catch {
		return null;
	}
}

export function applyReplayMessages(currentMessages: any[], replayPayload: unknown): ReplayApplyResult {
	const incomingMessages = normalizeReplayPayload(replayPayload);
	const currentSerialized = trySerializeMessages(currentMessages);
	const incomingSerialized = trySerializeMessages(incomingMessages);

	if (currentSerialized !== null && incomingSerialized !== null && currentSerialized === incomingSerialized) {
		return {
			messages: currentMessages,
			changed: false
		};
	}

	return {
		messages: incomingMessages,
		changed: true
	};
}
