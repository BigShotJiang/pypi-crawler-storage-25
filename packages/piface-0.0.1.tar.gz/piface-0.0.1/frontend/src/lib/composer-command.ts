export type ComposerCommandType = 'prompt' | 'steer' | 'follow_up';

export function resolveComposerCommandType(options: {
	isStreaming: boolean;
	followUpRequested: boolean;
}): ComposerCommandType {
	if (!options.isStreaming) {
		return 'prompt';
	}
	return options.followUpRequested ? 'follow_up' : 'steer';
}

export function isFollowUpShortcut(event: Pick<KeyboardEvent, 'altKey' | 'ctrlKey' | 'metaKey'>): boolean {
	return !!(event.altKey || event.ctrlKey || event.metaKey);
}
