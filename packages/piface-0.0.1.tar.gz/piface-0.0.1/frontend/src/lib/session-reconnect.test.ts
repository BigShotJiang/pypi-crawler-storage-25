import { describe, expect, it } from 'vitest';

import {
	LIFECYCLE_RECONNECT_COOLDOWN_MS,
	shouldAttemptLifecycleReconnect
} from './session-reconnect';

describe('shouldAttemptLifecycleReconnect', () => {
	it('returns true when session is live, disconnected, visible, online, and cooldown elapsed', () => {
		expect(
			shouldAttemptLifecycleReconnect({
				sessionStatus: 'live',
				connected: false,
				hasSocket: false,
				isVisible: true,
				isOnline: true,
				nowMs: 10_000,
				lastAttemptAtMs: 0
			})
		).toBe(true);
	});

	it('returns false when the session is not live', () => {
		expect(
			shouldAttemptLifecycleReconnect({
				sessionStatus: 'closed',
				connected: false,
				hasSocket: false,
				isVisible: true,
				isOnline: true,
				nowMs: 10_000,
				lastAttemptAtMs: 0
			})
		).toBe(false);
	});

	it('returns false when the document is hidden', () => {
		expect(
			shouldAttemptLifecycleReconnect({
				sessionStatus: 'live',
				connected: false,
				hasSocket: false,
				isVisible: false,
				isOnline: true,
				nowMs: 10_000,
				lastAttemptAtMs: 0
			})
		).toBe(false);
	});

	it('returns false when the browser is offline', () => {
		expect(
			shouldAttemptLifecycleReconnect({
				sessionStatus: 'live',
				connected: false,
				hasSocket: false,
				isVisible: true,
				isOnline: false,
				nowMs: 10_000,
				lastAttemptAtMs: 0
			})
		).toBe(false);
	});

	it('returns false when already connected or socket is open', () => {
		expect(
			shouldAttemptLifecycleReconnect({
				sessionStatus: 'live',
				connected: true,
				hasSocket: false,
				isVisible: true,
				isOnline: true,
				nowMs: 10_000,
				lastAttemptAtMs: 0
			})
		).toBe(false);

		expect(
			shouldAttemptLifecycleReconnect({
				sessionStatus: 'live',
				connected: false,
				hasSocket: true,
				isVisible: true,
				isOnline: true,
				nowMs: 10_000,
				lastAttemptAtMs: 0
			})
		).toBe(false);
	});

	it('enforces a cooldown between lifecycle reconnect attempts', () => {
		expect(
			shouldAttemptLifecycleReconnect({
				sessionStatus: 'live',
				connected: false,
				hasSocket: false,
				isVisible: true,
				isOnline: true,
				nowMs: 10_000,
				lastAttemptAtMs: 10_000 - (LIFECYCLE_RECONNECT_COOLDOWN_MS - 1)
			})
		).toBe(false);
	});
});
