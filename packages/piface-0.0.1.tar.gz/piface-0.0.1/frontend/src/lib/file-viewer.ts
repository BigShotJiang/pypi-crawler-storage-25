export type PreviewKind = 'code' | 'markdown' | 'html' | 'image' | 'binary';

const MARKDOWN_EXTENSIONS = new Set(['.md', '.markdown', '.mdx']);
const HTML_EXTENSIONS = new Set(['.html', '.htm']);
const CODELIKE_EXTENSIONS = new Set([
	'.txt',
	'.py',
	'.js',
	'.ts',
	'.tsx',
	'.jsx',
	'.json',
	'.yaml',
	'.yml',
	'.toml',
	'.ini',
	'.cfg',
	'.xml',
	'.css',
	'.scss',
	'.sql',
	'.sh',
	'.bash',
	'.zsh',
	'.go',
	'.rs',
	'.java',
	'.kt',
	'.c',
	'.h',
	'.cc',
	'.cpp',
	'.hpp',
	'.swift',
	'.rb',
	'.php',
	'.svelte',
	'.vue',
	'.lock',
	'.gitignore',
	'.dockerignore',
	'.env'
]);

const HIGHLIGHT_LANGUAGE_BY_EXTENSION: Record<string, string> = {
	py: 'python',
	js: 'javascript',
	ts: 'typescript',
	tsx: 'typescript',
	jsx: 'javascript',
	json: 'json',
	yaml: 'yaml',
	yml: 'yaml',
	toml: 'toml',
	md: 'markdown',
	markdown: 'markdown',
	css: 'css',
	scss: 'scss',
	html: 'xml',
	htm: 'xml',
	xml: 'xml',
	sh: 'bash',
	bash: 'bash',
	zsh: 'bash',
	sql: 'sql',
	go: 'go',
	rs: 'rust',
	java: 'java',
	kt: 'kotlin',
	c: 'c',
	h: 'c',
	cc: 'cpp',
	cpp: 'cpp',
	hpp: 'cpp',
	swift: 'swift',
	rb: 'ruby',
	php: 'php',
	svelte: 'svelte',
	vue: 'vue',
	ini: 'ini'
};

function fileSuffix(path: string): string {
	const lower = path.toLowerCase();
	const slash = lower.lastIndexOf('/');
	const filename = slash >= 0 ? lower.slice(slash + 1) : lower;
	const dot = filename.lastIndexOf('.');
	if (dot < 0) return '';
	return filename.slice(dot);
}

export function inferPreviewKind(path: string, mimeType: string | null | undefined): PreviewKind {
	const lowerPath = path.toLowerCase();
	const suffix = fileSuffix(path);

	if (mimeType?.startsWith('image/')) return 'image';
	if (MARKDOWN_EXTENSIONS.has(suffix)) return 'markdown';
	if (HTML_EXTENSIONS.has(suffix) || mimeType === 'text/html') return 'html';
	if (
		mimeType?.startsWith('text/') ||
		CODELIKE_EXTENSIONS.has(suffix) ||
		CODELIKE_EXTENSIONS.has(lowerPath.slice(lowerPath.lastIndexOf('/') + 1))
	) {
		return 'code';
	}
	return 'binary';
}

export function inferLanguageFromPath(path: string): string | undefined {
	const suffix = fileSuffix(path);
	if (!suffix) return undefined;
	return HIGHLIGHT_LANGUAGE_BY_EXTENSION[suffix.slice(1)];
}

function normalizePath(path: string): string {
	if (!path) return '';
	if (path === '/') return '/';
	const trimmed = path.replace(/\/+$/, '');
	return trimmed || '/';
}

function splitPathSegments(path: string): string[] {
	return normalizePath(path)
		.split('/')
		.filter((segment) => segment.length > 0);
}

export function relativePathFromRoot(rootPath: string, targetPath: string): string {
	const normalizedRoot = normalizePath(rootPath);
	const normalizedTarget = normalizePath(targetPath);
	if (!normalizedRoot || !normalizedTarget) return normalizedTarget;
	if (normalizedRoot === normalizedTarget) return '.';

	const rootIsAbsolute = normalizedRoot.startsWith('/');
	const targetIsAbsolute = normalizedTarget.startsWith('/');
	if (rootIsAbsolute !== targetIsAbsolute) return normalizedTarget;

	const rootSegments = splitPathSegments(normalizedRoot);
	const targetSegments = splitPathSegments(normalizedTarget);

	let commonLength = 0;
	while (
		commonLength < rootSegments.length &&
		commonLength < targetSegments.length &&
		rootSegments[commonLength] === targetSegments[commonLength]
	) {
		commonLength += 1;
	}

	const upSegments = new Array(rootSegments.length - commonLength).fill('..');
	const downSegments = targetSegments.slice(commonLength);
	const relativeSegments = [...upSegments, ...downSegments];

	return relativeSegments.length > 0 ? relativeSegments.join('/') : '.';
}

export type PathCopyVariant = {
	kind: 'relative' | 'absolute';
	value: string;
};

export function buildPathCopyVariants(rootPath: string, targetPath: string): PathCopyVariant[] {
	const normalizedTarget = normalizePath(targetPath);
	if (!normalizedTarget) return [];

	const variants: PathCopyVariant[] = [];
	const relative = rootPath ? relativePathFromRoot(rootPath, normalizedTarget) : '';
	if (relative && relative !== normalizedTarget) {
		variants.push({ kind: 'relative', value: relative });
	}
	variants.push({ kind: 'absolute', value: normalizedTarget });
	return variants;
}

export type PreviewCopyVariant =
	| {
			kind: 'content';
			value: string;
	  }
	| {
			kind: 'relative-path' | 'absolute-path';
			value: string;
	  };

export type PreviewCopySource = {
	path: string;
	kind: PreviewKind;
	content: string | null;
};

export function buildPreviewCopyVariants(rootPath: string, source: PreviewCopySource): PreviewCopyVariant[] {
	const variants: PreviewCopyVariant[] = [];

	if (source.content !== null && (source.kind === 'code' || source.kind === 'markdown')) {
		variants.push({ kind: 'content', value: source.content });
	}

	for (const pathVariant of buildPathCopyVariants(rootPath, source.path)) {
		variants.push({
			kind: pathVariant.kind === 'relative' ? 'relative-path' : 'absolute-path',
			value: pathVariant.value
		});
	}

	return variants;
}
