import { describe, expect, it } from 'vitest';

import {
	getDirectoryPage,
	groupSessionsByDirectory,
	SESSIONS_PER_DIRECTORY_PAGE
} from './session-pagination';

type FakeSession = {
	piface_id: string;
	working_dir: string;
	last_active: string;
};

function makeSession(id: number, dir: string, iso: string): FakeSession {
	return {
		piface_id: `s-${id}`,
		working_dir: dir,
		last_active: iso
	};
}

describe('session pagination helpers', () => {
	it('groups by directory and keeps reverse chronological order within each directory', () => {
		const sessions = [
			makeSession(1, '/a', '2026-01-01T10:00:00Z'),
			makeSession(2, '/b', '2026-01-01T10:05:00Z'),
			makeSession(3, '/a', '2026-01-01T10:10:00Z'),
			makeSession(4, '/a', '2026-01-01T09:00:00Z')
		];

		const grouped = groupSessionsByDirectory(sessions);
		expect(grouped.get('/a')?.map((s) => s.piface_id)).toEqual(['s-3', 's-1', 's-4']);
		expect(grouped.get('/b')?.map((s) => s.piface_id)).toEqual(['s-2']);
	});

	it('returns only 10 sessions per directory page by default', () => {
		const group = Array.from({ length: 25 }, (_, i) =>
			makeSession(i, '/a', `2026-01-01T10:${String(59 - i).padStart(2, '0')}:00Z`)
		);

		const first = getDirectoryPage(group, 0);
		expect(first.items).toHaveLength(SESSIONS_PER_DIRECTORY_PAGE);
		expect(first.hasPrev).toBe(false);
		expect(first.hasNext).toBe(true);
		expect(first.totalPages).toBe(3);

		const second = getDirectoryPage(group, 1);
		expect(second.items).toHaveLength(SESSIONS_PER_DIRECTORY_PAGE);
		expect(second.hasPrev).toBe(true);
		expect(second.hasNext).toBe(true);

		const third = getDirectoryPage(group, 2);
		expect(third.items).toHaveLength(5);
		expect(third.hasPrev).toBe(true);
		expect(third.hasNext).toBe(false);
	});

	it('clamps out-of-range pages to valid bounds', () => {
		const group = Array.from({ length: 3 }, (_, i) =>
			makeSession(i, '/a', `2026-01-01T10:0${i}:00Z`)
		);

		expect(getDirectoryPage(group, -10).page).toBe(0);
		expect(getDirectoryPage(group, 99).page).toBe(0);
	});

	it('groups by project_dir when available, falling back to working_dir', () => {
		const sessions = [
			{
				piface_id: 's-1',
				working_dir: '/worktrees/proj-abc/ws1',
				project_dir: '/home/user/project',
				last_active: '2026-01-01T10:00:00Z'
			},
			{
				piface_id: 's-2',
				working_dir: '/worktrees/proj-abc/ws2',
				project_dir: '/home/user/project',
				last_active: '2026-01-01T10:05:00Z'
			},
			{
				piface_id: 's-3',
				working_dir: '/legacy/path',
				last_active: '2026-01-01T10:10:00Z'
			}
		];
		const grouped = groupSessionsByDirectory(sessions);
		expect([...grouped.keys()]).toEqual(['/legacy/path', '/home/user/project']);
		expect(grouped.get('/home/user/project')?.map((s) => s.piface_id)).toEqual([
			's-2',
			's-1'
		]);
		expect(grouped.get('/legacy/path')?.map((s) => s.piface_id)).toEqual(['s-3']);
	});

	it('groups legacy sessions without project_dir by working_dir', () => {
		const sessions = [
			makeSession(1, '/a', '2026-01-01T10:00:00Z'),
			makeSession(2, '/a', '2026-01-01T10:05:00Z')
		];
		const grouped = groupSessionsByDirectory(sessions);
		expect(grouped.get('/a')?.length).toBe(2);
	});
});
