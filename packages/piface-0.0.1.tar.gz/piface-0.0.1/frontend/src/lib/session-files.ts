import { normalizeFilesViewState, type FilesViewState } from './files-view-state';

const FILES_VIEW_KEY_PREFIX = 'piface.session.files-view:';
const RECENT_FILES_KEY_PREFIX = 'piface.directory.recent-files:';
const DEFAULT_RECENT_FILES_LIMIT = 8;

function normalizePath(path: string): string {
	if (!path) return '';
	if (path === '/') return '/';
	return path.endsWith('/') ? path.replace(/\/+$/, '') : path;
}

function pathIsInsideRoot(path: string, root: string): boolean {
	if (!path || !root) return false;
	const normalizedRoot = normalizePath(root);
	const normalizedPath = normalizePath(path);
	if (!normalizedRoot || !normalizedPath) return false;
	if (normalizedRoot === '/') return normalizedPath.startsWith('/');
	if (normalizedPath === normalizedRoot) return true;
	return normalizedPath.startsWith(`${normalizedRoot}/`);
}

function filesViewKey(sessionId: string): string {
	return `${FILES_VIEW_KEY_PREFIX}${sessionId}`;
}

function recentFilesKey(rootPath: string): string {
	return `${RECENT_FILES_KEY_PREFIX}${encodeURIComponent(normalizePath(rootPath))}`;
}

export function saveSessionFilesView(
	storage: Pick<Storage, 'setItem'>,
	sessionId: string,
	state: FilesViewState
): void {
	storage.setItem(filesViewKey(sessionId), JSON.stringify(state));
}

export function loadSessionFilesView(
	storage: Pick<Storage, 'getItem'>,
	sessionId: string
): FilesViewState | null {
	const raw = storage.getItem(filesViewKey(sessionId));
	if (!raw) return null;

	try {
		const parsed = JSON.parse(raw) as unknown;
		return normalizeFilesViewState(parsed);
	} catch {
		return null;
	}
}

export function loadRecentFiles(storage: Pick<Storage, 'getItem'>, rootPath: string): string[] {
	if (!rootPath) return [];
	const raw = storage.getItem(recentFilesKey(rootPath));
	if (!raw) return [];

	try {
		const parsed = JSON.parse(raw) as unknown;
		if (!Array.isArray(parsed)) return [];
		return parsed.filter(
			(path): path is string => typeof path === 'string' && pathIsInsideRoot(path, rootPath)
		);
	} catch {
		return [];
	}
}

export function recordRecentFile(
	storage: Pick<Storage, 'getItem' | 'setItem'>,
	rootPath: string,
	path: string,
	limit = DEFAULT_RECENT_FILES_LIMIT
): string[] {
	if (!pathIsInsideRoot(path, rootPath)) {
		return loadRecentFiles(storage, rootPath);
	}

	const normalizedPath = normalizePath(path);
	const next = [normalizedPath, ...loadRecentFiles(storage, rootPath).filter((entry) => entry !== normalizedPath)]
		.slice(0, Math.max(1, limit));
	storage.setItem(recentFilesKey(rootPath), JSON.stringify(next));
	return next;
}
