type FetchLike = (input: string, init?: { method?: string }) => Promise<{
	ok: boolean;
	status?: number;
	json?: () => Promise<any>;
}>;

type GotoLike = (href: string) => Promise<void> | void;

export type CloseSessionResult =
	| { ok: true }
	| { ok: false; skipped: 'invalid' | 'cancelled' }
	| { ok: false; error: string };

export async function closeSessionAndReturnHome(input: {
	sessionId: string | null | undefined;
	sessionStatus: string | null | undefined;
	confirmClose: () => boolean;
	fetchImpl?: FetchLike;
	gotoImpl: GotoLike;
	onBeforeClose?: () => void;
}): Promise<CloseSessionResult> {
	const { sessionId, sessionStatus, confirmClose, gotoImpl, onBeforeClose } = input;
	const fetchImpl: FetchLike = input.fetchImpl ?? ((url, init) => fetch(url, init as RequestInit) as any);

	if (!sessionId || sessionStatus === 'closed') {
		return { ok: false, skipped: 'invalid' };
	}

	if (!confirmClose()) {
		return { ok: false, skipped: 'cancelled' };
	}

	const resp = await fetchImpl(`/api/sessions/${encodeURIComponent(sessionId)}/kill`, {
		method: 'POST'
	});

	if (!resp.ok) {
		const body = await resp.json?.().catch(() => ({}));
		return { ok: false, error: body?.detail ?? `Failed to close session (${resp.status ?? 0}).` };
	}

	onBeforeClose?.();
	await gotoImpl('/');
	return { ok: true };
}
