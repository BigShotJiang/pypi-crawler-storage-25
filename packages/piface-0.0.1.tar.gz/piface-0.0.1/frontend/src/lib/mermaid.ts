export type MermaidRenderResult = {
	svg: string;
	bindFunctions?: (element: Element) => void;
};

export type MermaidApi = {
	initialize: (config: Record<string, unknown>) => void;
	render: (id: string, text: string) => Promise<MermaidRenderResult> | MermaidRenderResult;
};

let mermaidApiPromise: Promise<MermaidApi | null> | null = null;
let mermaidRenderSequence = 0;

export function decodeMermaidSource(encoded: string | null | undefined): string {
	if (!encoded) return '';
	try {
		return decodeURIComponent(encoded);
	} catch {
		return '';
	}
}

export function resolveMermaidTheme(doc?: Document | null): 'default' | 'dark' {
	return doc?.documentElement?.dataset.theme === 'light' ? 'default' : 'dark';
}

function nextMermaidRenderId(): string {
	mermaidRenderSequence += 1;
	return `piface-mermaid-${mermaidRenderSequence}`;
}

function resolveDocument(node: ParentNode, fallback?: Document | null): Document | null {
	if (fallback) return fallback;
	if ((node as Document).documentElement) {
		return node as Document;
	}
	return (node as Node).ownerDocument ?? (typeof document !== 'undefined' ? document : null);
}

function getMermaidSurfaces(node: ParentNode): HTMLElement[] {
	return Array.from(node.querySelectorAll<HTMLElement>('.mermaid-render-surface[data-mermaid-source]'));
}

function openMermaidSourceDetails(surface: HTMLElement): void {
	const details = surface.closest('.mermaid-block')?.querySelector<HTMLDetailsElement>('.mermaid-source-details');
	if (details) {
		details.open = true;
	}
}

export async function renderMermaidBlocksInNode(
	node: ParentNode,
	api: MermaidApi,
	fallbackDocument?: Document | null
): Promise<void> {
	const surfaces = getMermaidSurfaces(node);
	if (surfaces.length === 0) return;

	const doc = resolveDocument(node, fallbackDocument);
	api.initialize({
		startOnLoad: false,
		securityLevel: 'strict',
		theme: resolveMermaidTheme(doc)
	});

	for (const surface of surfaces) {
		const source = decodeMermaidSource(surface.dataset.mermaidSource);
		if (!source.trim()) continue;

		try {
			const rendered = await api.render(nextMermaidRenderId(), source);
			surface.innerHTML = rendered.svg;
			surface.dataset.mermaidState = 'rendered';
			rendered.bindFunctions?.(surface);
		} catch {
			surface.innerHTML = '<div class="mermaid-render-error">Failed to render Mermaid diagram.</div>';
			surface.dataset.mermaidState = 'error';
			openMermaidSourceDetails(surface);
		}
	}
}

async function loadMermaidApi(): Promise<MermaidApi | null> {
	mermaidApiPromise ??= import('mermaid')
		.then((mod) => mod.default as unknown as MermaidApi)
		.catch(() => null);
	return mermaidApiPromise;
}

export async function renderMermaidInNode(node: ParentNode): Promise<void> {
	if (typeof window === 'undefined') return;
	if (getMermaidSurfaces(node).length === 0) return;

	const api = await loadMermaidApi();
	if (!api) return;
	await renderMermaidBlocksInNode(node, api, resolveDocument(node));
}
