import { describe, expect, it } from 'vitest';

import {
	isMermaidFence,
	renderMarkdown,
	renderMarkdownForFile,
	rewriteMarkdownAssetHref
} from './markdown-file-render';

describe('rewriteMarkdownAssetHref', () => {
	it('rewrites relative paths to fs raw endpoint urls', () => {
		expect(rewriteMarkdownAssetHref('/tmp/project/docs/readme.md', './images/arch.png')).toBe(
			'/api/fs/raw?path=%2Ftmp%2Fproject%2Fdocs%2Fimages%2Farch.png'
		);
		expect(rewriteMarkdownAssetHref('/tmp/project/docs/readme.md', '../shared/logo.png')).toBe(
			'/api/fs/raw?path=%2Ftmp%2Fproject%2Fshared%2Flogo.png'
		);
	});

	it('leaves non-relative urls unchanged', () => {
		expect(rewriteMarkdownAssetHref('/tmp/project/docs/readme.md', 'https://example.com/image.png')).toBe(
			'https://example.com/image.png'
		);
		expect(rewriteMarkdownAssetHref('/tmp/project/docs/readme.md', '/var/tmp/image.png')).toBe('/var/tmp/image.png');
		expect(rewriteMarkdownAssetHref('/tmp/project/docs/readme.md', '#section')).toBe('#section');
	});
});

describe('isMermaidFence', () => {
	it('detects mermaid code fences across common info-string variants', () => {
		expect(isMermaidFence('mermaid')).toBe(true);
		expect(isMermaidFence('Mermaid')).toBe(true);
		expect(isMermaidFence('{mermaid}')).toBe(true);
		expect(isMermaidFence('mermaid title="Architecture"')).toBe(true);
		expect(isMermaidFence('typescript')).toBe(false);
		expect(isMermaidFence(undefined)).toBe(false);
	});
});

describe('renderMarkdown', () => {
	it('renders mermaid fences as diagram containers with collapsible source', () => {
		const html = renderMarkdown('```mermaid\nflowchart TD\nA-->B\n```');

		expect(html).toContain('class="mermaid-block"');
		expect(html).toContain('class="mermaid-render-surface"');
		expect(html).toContain('data-mermaid-source="flowchart%20TD%0AA--%3EB"');
		expect(html).toContain('<summary>Show source</summary>');
		expect(html).toContain('<code class="language-mermaid">flowchart TD\nA--&gt;B</code>');
	});

	it('keeps non-mermaid fences as regular code blocks', () => {
		const html = renderMarkdown('```python\nprint(1)\n```');

		expect(html).not.toContain('class="mermaid-block"');
		expect(html).toContain('<pre><code class="language-python">print(1)\n</code></pre>');
	});
});

describe('renderMarkdownForFile', () => {
	it('renders markdown links and images with rewritten relative urls', () => {
		const html = renderMarkdownForFile(
			'[See details](./details.md)\n\n![diagram](./assets/diagram.png)',
			'/tmp/project/docs/experiment/index.md'
		);

		expect(html).toContain(
			'/api/fs/raw?path=%2Ftmp%2Fproject%2Fdocs%2Fexperiment%2Fdetails.md'
		);
		expect(html).toContain('<a href="/api/fs/raw?path=%2Ftmp%2Fproject%2Fdocs%2Fexperiment%2Fdetails.md"');
		expect(html).toContain('<img');
	});

	it('preserves tex expressions inside bracket math syntax for MathJax rendering', () => {
		const markdown = String.raw`Momentum 21d [ \text{mom21}_{i,t} = \frac{P_{i,t}}{P_{i,t-21}} - 1 ]`;
		const html = renderMarkdownForFile(markdown, '/tmp/project/docs/README.md');

		expect(html).toContain(String.raw`\(\text{mom21}_{i,t} = \frac{P_{i,t}}{P_{i,t-21}} - 1\)`);
		expect(html).not.toContain('<em>');
	});

	it('preserves $$...$$ display math for MathJax rendering', () => {
		const markdown = String.raw`$$\frac{P_{i,t}}{P_{i,t-21}} - 1$$`;
		const html = renderMarkdownForFile(markdown, '/tmp/project/docs/README.md');

		expect(html).toContain(String.raw`\[\frac{P_{i,t}}{P_{i,t-21}} - 1\]`);
		expect(html).not.toContain('<em>');
	});
});
