type TimerHandle = ReturnType<typeof setTimeout>;

export type ChatScrollRestoreScheduler = {
	requestAnimationFrame(callback: FrameRequestCallback): number;
	cancelAnimationFrame(handle: number): void;
	setInterval(callback: () => void, ms: number): TimerHandle;
	clearInterval(handle: TimerHandle): void;
	setTimeout(callback: () => void, ms: number): TimerHandle;
	clearTimeout(handle: TimerHandle): void;
};

export type ChatScrollRestoreCallbacks = {
	apply(): void;
	onSettled?(): void;
};

export type ChatScrollRestoreController = {
	start(callbacks: ChatScrollRestoreCallbacks): void;
	cancel(): void;
	isActive(): boolean;
};

export function createChatScrollRestoreController(
	scheduler: ChatScrollRestoreScheduler,
	options: { intervalMs?: number; settleMs?: number } = {}
): ChatScrollRestoreController {
	const intervalMs = options.intervalMs ?? 120;
	const settleMs = options.settleMs ?? 700;

	let animationFrameHandle: number | null = null;
	let intervalHandle: TimerHandle | null = null;
	let timeoutHandle: TimerHandle | null = null;
	let active = false;

	function clearScheduledWork() {
		if (animationFrameHandle !== null) {
			scheduler.cancelAnimationFrame(animationFrameHandle);
			animationFrameHandle = null;
		}
		if (intervalHandle !== null) {
			scheduler.clearInterval(intervalHandle);
			intervalHandle = null;
		}
		if (timeoutHandle !== null) {
			scheduler.clearTimeout(timeoutHandle);
			timeoutHandle = null;
		}
	}

	function cancel() {
		active = false;
		clearScheduledWork();
	}

	return {
		start({ apply, onSettled }: ChatScrollRestoreCallbacks) {
			cancel();
			active = true;

			const applyIfActive = () => {
				if (!active) return;
				apply();
			};

			applyIfActive();
			animationFrameHandle = scheduler.requestAnimationFrame(() => {
				applyIfActive();
				animationFrameHandle = scheduler.requestAnimationFrame(() => {
					applyIfActive();
					animationFrameHandle = null;
				});
			});
			intervalHandle = scheduler.setInterval(applyIfActive, intervalMs);
			timeoutHandle = scheduler.setTimeout(() => {
				applyIfActive();
				active = false;
				clearScheduledWork();
				onSettled?.();
			}, settleMs);
		},
		cancel,
		isActive() {
			return active;
		}
	};
}
