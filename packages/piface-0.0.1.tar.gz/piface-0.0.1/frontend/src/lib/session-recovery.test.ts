import { describe, expect, it } from 'vitest';

import {
	computeReconnectDelay,
	loadSessionSnapshot,
	loadSessionSnapshotWithFallback,
	saveSessionSnapshot,
	saveSessionSnapshotWithFallback,
	type SessionSnapshot
} from './session-recovery';

describe('computeReconnectDelay', () => {
	it('starts at 1s and caps at 15s', () => {
		expect(computeReconnectDelay(0)).toBe(1000);
		expect(computeReconnectDelay(1)).toBe(2000);
		expect(computeReconnectDelay(2)).toBe(4000);
		expect(computeReconnectDelay(10)).toBe(15000);
	});
});

describe('session snapshot storage', () => {
	it('round-trips snapshot state', () => {
		const store = new Map<string, string>();
		const storage: Pick<Storage, 'getItem' | 'setItem'> = {
			getItem: (key) => store.get(key) ?? null,
			setItem: (key, value) => {
				store.set(key, value);
			}
		};

		const snapshot: SessionSnapshot = {
			sessionId: 'abc',
			session: { status: 'live' },
			messages: [{ role: 'user', content: 'hi' }],
			activeTab: 'chat',
			filesView: {
				currentPath: '/tmp/project/src',
				selectedPath: '/tmp/project/src/main.ts',
				previewFullscreen: true
			},
			timestamp: Date.now()
		};

		saveSessionSnapshot(storage, snapshot);
		expect(loadSessionSnapshot(storage, 'abc')).toEqual(snapshot);
	});

	it('accepts diff tab snapshots', () => {
		const store = new Map<string, string>();
		const storage: Pick<Storage, 'getItem' | 'setItem'> = {
			getItem: (key) => store.get(key) ?? null,
			setItem: (key, value) => {
				store.set(key, value);
			}
		};

		const snapshot: SessionSnapshot = {
			sessionId: 'abc',
			session: { status: 'live' },
			messages: [],
			activeTab: 'diff',
			filesView: {
				currentPath: '',
				selectedPath: ''
			},
			timestamp: Date.now()
		};
		saveSessionSnapshot(storage, snapshot);

		expect(loadSessionSnapshot(storage, 'abc')).toEqual(snapshot);
	});

	it('accepts scratch tab snapshots', () => {
		const store = new Map<string, string>();
		const storage: Pick<Storage, 'getItem' | 'setItem'> = {
			getItem: (key) => store.get(key) ?? null,
			setItem: (key, value) => {
				store.set(key, value);
			}
		};

		const snapshot: SessionSnapshot = {
			sessionId: 'abc',
			session: { status: 'live' },
			messages: [],
			activeTab: 'scratch',
			filesView: {
				currentPath: '',
				selectedPath: ''
			},
			timestamp: Date.now()
		};
		saveSessionSnapshot(storage, snapshot);

		expect(loadSessionSnapshot(storage, 'abc')).toEqual(snapshot);
	});

	it('keeps supporting legacy snapshots without file view state', () => {
		const store = new Map<string, string>();
		const storage: Pick<Storage, 'getItem' | 'setItem'> = {
			getItem: (key) => store.get(key) ?? null,
			setItem: (key, value) => {
				store.set(key, value);
			}
		};

		const legacySnapshot = {
			sessionId: 'abc',
			session: { status: 'live' },
			messages: [],
			activeTab: 'chat',
			timestamp: Date.now()
		};
		storage.setItem('piface.session.snapshot:abc', JSON.stringify(legacySnapshot));

		expect(loadSessionSnapshot(storage, 'abc')).toEqual(legacySnapshot);
	});

	it('rejects snapshots with malformed file view state', () => {
		const store = new Map<string, string>();
		const storage: Pick<Storage, 'getItem' | 'setItem'> = {
			getItem: (key) => store.get(key) ?? null,
			setItem: (key, value) => {
				store.set(key, value);
			}
		};

		storage.setItem(
			'piface.session.snapshot:abc',
			JSON.stringify({
				sessionId: 'abc',
				session: { status: 'live' },
				messages: [],
				activeTab: 'files',
				filesView: { currentPath: 123, selectedPath: '/tmp/project/file.ts' },
				timestamp: Date.now()
			})
		);

		expect(loadSessionSnapshot(storage, 'abc')).toBeNull();
	});

	it('salvages malformed optional fullscreen state in snapshots', () => {
		const store = new Map<string, string>();
		const storage: Pick<Storage, 'getItem' | 'setItem'> = {
			getItem: (key) => store.get(key) ?? null,
			setItem: (key, value) => {
				store.set(key, value);
			}
		};

		storage.setItem(
			'piface.session.snapshot:abc',
			JSON.stringify({
				sessionId: 'abc',
				session: { status: 'live' },
				messages: [],
				activeTab: 'files',
				filesView: {
					currentPath: '/tmp/project',
					selectedPath: '/tmp/project/file.ts',
					previewFullscreen: 'yes'
				},
				timestamp: Date.now()
			})
		);

		expect(loadSessionSnapshot(storage, 'abc')).toEqual({
			sessionId: 'abc',
			session: { status: 'live' },
			messages: [],
			activeTab: 'files',
			filesView: {
				currentPath: '/tmp/project',
				selectedPath: '/tmp/project/file.ts'
			},
			timestamp: expect.any(Number)
		});
	});

	it('drops snapshots older than ttl', () => {
		const store = new Map<string, string>();
		const storage: Pick<Storage, 'getItem' | 'setItem'> = {
			getItem: (key) => store.get(key) ?? null,
			setItem: (key, value) => {
				store.set(key, value);
			}
		};

		const stale: SessionSnapshot = {
			sessionId: 'abc',
			session: { status: 'live' },
			messages: [],
			activeTab: 'chat',
			timestamp: Date.now() - 31 * 60_000
		};
		saveSessionSnapshot(storage, stale);

		expect(loadSessionSnapshot(storage, 'abc')).toBeNull();
	});
});

describe('session snapshot fallback storage', () => {
	function createStorageMap(): Pick<Storage, 'getItem' | 'setItem'> & { store: Map<string, string> } {
		const store = new Map<string, string>();
		return {
			store,
			getItem: (key) => store.get(key) ?? null,
			setItem: (key, value) => {
				store.set(key, value);
			}
		};
	}

	it('loads from fallback storage when session storage is empty', () => {
		const primary = createStorageMap();
		const fallback = createStorageMap();
		const snapshot: SessionSnapshot = {
			sessionId: 'abc',
			session: { status: 'live' },
			messages: [{ role: 'user', content: 'hi' }],
			activeTab: 'chat',
			timestamp: Date.now()
		};
		saveSessionSnapshot(fallback, snapshot);

		expect(loadSessionSnapshotWithFallback(primary, fallback, 'abc')).toEqual(snapshot);
	});

	it('writes snapshots to both primary and fallback storage', () => {
		const primary = createStorageMap();
		const fallback = createStorageMap();
		const snapshot: SessionSnapshot = {
			sessionId: 'abc',
			session: { status: 'live' },
			messages: [],
			activeTab: 'files',
			timestamp: Date.now(),
			filesView: { currentPath: '/tmp/project', selectedPath: '/tmp/project/a.ts' }
		};

		saveSessionSnapshotWithFallback(primary, fallback, snapshot);

		expect(loadSessionSnapshot(primary, 'abc')).toEqual(snapshot);
		expect(loadSessionSnapshot(fallback, 'abc')).toEqual(snapshot);
	});

	it('continues writing to fallback when primary storage throws', () => {
		const fallback = createStorageMap();
		const snapshot: SessionSnapshot = {
			sessionId: 'abc',
			session: { status: 'live' },
			messages: [],
			activeTab: 'chat',
			timestamp: Date.now()
		};

		const primary: Pick<Storage, 'setItem'> = {
			setItem: () => {
				throw new Error('blocked');
			}
		};

		expect(() => saveSessionSnapshotWithFallback(primary, fallback, snapshot)).not.toThrow();
		expect(loadSessionSnapshot(fallback, 'abc')).toEqual(snapshot);
	});
});
