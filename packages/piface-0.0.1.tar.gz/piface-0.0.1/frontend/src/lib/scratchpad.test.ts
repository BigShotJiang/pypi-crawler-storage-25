import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

import {
	createDebouncedScratchSaver,
	loadSessionScratch,
	saveSessionScratch,
	scratchStorageKey
} from './scratchpad';

describe('scratch storage', () => {
	it('builds a per-session storage key', () => {
		expect(scratchStorageKey('abc')).toBe('piface.session.scratch:abc');
	});

	it('loads empty text when scratch is missing', () => {
		const store = new Map<string, string>();
		const storage: Pick<Storage, 'getItem'> = {
			getItem: (key) => store.get(key) ?? null
		};

		expect(loadSessionScratch(storage, 'abc')).toBe('');
	});

	it('saves and loads text per session id', () => {
		const store = new Map<string, string>();
		const storage: Pick<Storage, 'getItem' | 'setItem'> = {
			getItem: (key) => store.get(key) ?? null,
			setItem: (key, value) => {
				store.set(key, value);
			}
		};

		saveSessionScratch(storage, 'abc', 'todo a');
		saveSessionScratch(storage, 'def', 'todo b');

		expect(loadSessionScratch(storage, 'abc')).toBe('todo a');
		expect(loadSessionScratch(storage, 'def')).toBe('todo b');
	});
});

describe('createDebouncedScratchSaver', () => {
	beforeEach(() => {
		vi.useFakeTimers();
	});

	afterEach(() => {
		vi.useRealTimers();
	});

	it('saves only once after typing pauses', () => {
		const onSave = vi.fn();
		const saver = createDebouncedScratchSaver({ delayMs: 2000, onSave });

		saver.schedule('a');
		vi.advanceTimersByTime(1500);
		saver.schedule('ab');
		vi.advanceTimersByTime(1999);
		expect(onSave).not.toHaveBeenCalled();

		vi.advanceTimersByTime(1);
		expect(onSave).toHaveBeenCalledTimes(1);
		expect(onSave).toHaveBeenCalledWith('ab');
	});

	it('flushes pending text immediately', () => {
		const onSave = vi.fn();
		const saver = createDebouncedScratchSaver({ delayMs: 2000, onSave });

		saver.schedule('draft');
		saver.flush();
		expect(onSave).toHaveBeenCalledTimes(1);
		expect(onSave).toHaveBeenCalledWith('draft');

		vi.advanceTimersByTime(3000);
		expect(onSave).toHaveBeenCalledTimes(1);
	});

	it('cancels pending saves', () => {
		const onSave = vi.fn();
		const saver = createDebouncedScratchSaver({ delayMs: 2000, onSave });

		saver.schedule('draft');
		saver.cancel();
		vi.advanceTimersByTime(3000);

		expect(onSave).not.toHaveBeenCalled();
	});
});
