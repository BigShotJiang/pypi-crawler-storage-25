// @vitest-environment jsdom

import { describe, expect, it, vi } from 'vitest';

import { decodeMermaidSource, renderMermaidBlocksInNode, resolveMermaidTheme, type MermaidApi } from './mermaid';

describe('decodeMermaidSource', () => {
	it('decodes encoded mermaid source safely', () => {
		expect(decodeMermaidSource('flowchart%20TD%0AA--%3EB')).toBe('flowchart TD\nA-->B');
		expect(decodeMermaidSource('%E0%A4%A')).toBe('');
		expect(decodeMermaidSource(undefined)).toBe('');
	});
});

describe('resolveMermaidTheme', () => {
	it('uses the light mermaid theme only when the document theme is light', () => {
		document.documentElement.dataset.theme = 'light';
		expect(resolveMermaidTheme(document)).toBe('default');

		document.documentElement.dataset.theme = 'dark';
		expect(resolveMermaidTheme(document)).toBe('dark');

		delete document.documentElement.dataset.theme;
		expect(resolveMermaidTheme(document)).toBe('dark');
	});
});

describe('renderMermaidBlocksInNode', () => {
	it('renders encoded mermaid blocks into svg output', async () => {
		const root = document.createElement('div');
		root.innerHTML = `
			<div class="mermaid-block">
				<div class="mermaid-render-surface" data-mermaid-source="flowchart%20TD%0AA--%3EB"></div>
				<details class="mermaid-source-details"><summary>Show source</summary></details>
			</div>
		`;

		const api: MermaidApi = {
			initialize: vi.fn(),
			render: vi.fn().mockResolvedValue({
				svg: '<svg><text>diagram</text></svg>'
			})
		};

		await renderMermaidBlocksInNode(root, api, document);

		expect(api.initialize).toHaveBeenCalledWith(
			expect.objectContaining({
				startOnLoad: false,
				securityLevel: 'strict',
				theme: 'dark'
			})
		);
		expect(api.render).toHaveBeenCalledWith(expect.stringMatching(/^piface-mermaid-/), 'flowchart TD\nA-->B');
		expect(root.querySelector('.mermaid-render-surface')?.innerHTML).toContain('<svg><text>diagram</text></svg>');
	});

	it('falls back to an inline error and opens the source details when rendering fails', async () => {
		const root = document.createElement('div');
		root.innerHTML = `
			<div class="mermaid-block">
				<div class="mermaid-render-surface" data-mermaid-source="flowchart%20TD%0AA--%3EB"></div>
				<details class="mermaid-source-details"><summary>Show source</summary></details>
			</div>
		`;

		const api: MermaidApi = {
			initialize: vi.fn(),
			render: vi.fn().mockRejectedValue(new Error('boom'))
		};

		await renderMermaidBlocksInNode(root, api, document);

		expect(root.querySelector('.mermaid-render-error')?.textContent).toContain('Failed to render Mermaid diagram.');
		expect(root.querySelector('details')?.open).toBe(true);
	});
});
