import { describe, expect, it, vi } from 'vitest';

import { closeSessionAndReturnHome } from './close-session';

describe('closeSessionAndReturnHome', () => {
	it('kills a live session and redirects home', async () => {
		const fetchImpl = vi.fn().mockResolvedValue({ ok: true });
		const gotoImpl = vi.fn().mockResolvedValue(undefined);
		const onBeforeClose = vi.fn();

		const result = await closeSessionAndReturnHome({
			sessionId: 'abc123',
			sessionStatus: 'live',
			confirmClose: () => true,
			fetchImpl: fetchImpl as any,
			gotoImpl,
			onBeforeClose
		});

		expect(result).toEqual({ ok: true });
		expect(fetchImpl).toHaveBeenCalledWith('/api/sessions/abc123/kill', { method: 'POST' });
		expect(onBeforeClose).toHaveBeenCalledTimes(1);
		expect(gotoImpl).toHaveBeenCalledWith('/');
	});

	it('does nothing when user cancels confirmation', async () => {
		const fetchImpl = vi.fn();
		const gotoImpl = vi.fn();

		const result = await closeSessionAndReturnHome({
			sessionId: 'abc123',
			sessionStatus: 'live',
			confirmClose: () => false,
			fetchImpl: fetchImpl as any,
			gotoImpl
		});

		expect(result).toEqual({ ok: false, skipped: 'cancelled' });
		expect(fetchImpl).not.toHaveBeenCalled();
		expect(gotoImpl).not.toHaveBeenCalled();
	});

	it('returns an error if the kill request fails', async () => {
		const fetchImpl = vi.fn().mockResolvedValue({
			ok: false,
			status: 500,
			json: vi.fn().mockResolvedValue({ detail: 'boom' })
		});
		const gotoImpl = vi.fn();

		const result = await closeSessionAndReturnHome({
			sessionId: 'abc123',
			sessionStatus: 'live',
			confirmClose: () => true,
			fetchImpl: fetchImpl as any,
			gotoImpl
		});

		expect(result).toEqual({ ok: false, error: 'boom' });
		expect(gotoImpl).not.toHaveBeenCalled();
	});
});
