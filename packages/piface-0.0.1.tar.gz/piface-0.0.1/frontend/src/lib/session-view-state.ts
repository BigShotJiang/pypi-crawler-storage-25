import { normalizeFilesViewState, type FilesViewState } from './files-view-state';
import type { SessionTab } from './session-recovery';

export type ChatScrollState = { mode: 'bottom' } | { mode: 'offset'; offsetFromBottom: number };

export type SessionViewState = {
	activeTab: SessionTab;
	filesView?: FilesViewState;
	chatScroll?: ChatScrollState;
	composerDraft?: string;
	timestamp: number;
};

const VIEW_STATE_KEY_PREFIX = 'piface.session.view:';
const VALID_TABS: SessionTab[] = ['chat', 'files', 'diff', 'terminal', 'scratch'];

export type ChatScrollMetrics = {
	scrollTop: number;
	scrollHeight: number;
	clientHeight: number;
	bottomThresholdPx?: number;
};

export type ChatScrollRestoreMetrics = Pick<ChatScrollMetrics, 'scrollHeight' | 'clientHeight'>;

type ViewStateReadStorage = Pick<Storage, 'getItem'> | null | undefined;
type ViewStateWriteStorage = Pick<Storage, 'setItem'> | null | undefined;

function keyFor(sessionId: string): string {
	return `${VIEW_STATE_KEY_PREFIX}${sessionId}`;
}

function isValidSessionTab(value: unknown): value is SessionTab {
	return typeof value === 'string' && VALID_TABS.includes(value as SessionTab);
}

function isValidChatScrollState(value: unknown): value is ChatScrollState {
	if (!value || typeof value !== 'object') return false;
	const record = value as Record<string, unknown>;
	if (record.mode === 'bottom') return true;
	return record.mode === 'offset' && typeof record.offsetFromBottom === 'number';
}

function normalizeViewState(value: unknown): SessionViewState | null {
	if (!value || typeof value !== 'object') return null;
	const record = value as Record<string, unknown>;
	if (!isValidSessionTab(record.activeTab)) return null;
	if (typeof record.timestamp !== 'number' || !Number.isFinite(record.timestamp)) return null;

	const normalized: SessionViewState = {
		activeTab: record.activeTab,
		timestamp: record.timestamp
	};
	const normalizedFilesView = normalizeFilesViewState(record.filesView);
	if (normalizedFilesView) {
		normalized.filesView = normalizedFilesView;
	}
	if (isValidChatScrollState(record.chatScroll)) {
		normalized.chatScroll = record.chatScroll;
	}
	if (typeof record.composerDraft === 'string') {
		normalized.composerDraft = record.composerDraft;
	}
	return normalized;
}

export function captureChatScrollState(metrics: ChatScrollMetrics): ChatScrollState {
	const maxScrollTop = Math.max(0, metrics.scrollHeight - metrics.clientHeight);
	const clampedScrollTop = Math.min(Math.max(0, metrics.scrollTop), maxScrollTop);
	const bottomThresholdPx = metrics.bottomThresholdPx ?? 48;
	const offsetFromBottom = Math.max(0, maxScrollTop - clampedScrollTop);
	if (offsetFromBottom <= bottomThresholdPx) {
		return { mode: 'bottom' };
	}
	return { mode: 'offset', offsetFromBottom };
}

export function resolveChatScrollTop(
	state: ChatScrollState,
	metrics: ChatScrollRestoreMetrics
): number {
	const maxScrollTop = Math.max(0, metrics.scrollHeight - metrics.clientHeight);
	if (state.mode === 'bottom') {
		return maxScrollTop;
	}
	return Math.min(maxScrollTop, Math.max(0, maxScrollTop - state.offsetFromBottom));
}

export function saveSessionViewState(
	storage: Pick<Storage, 'setItem'>,
	sessionId: string,
	state: SessionViewState
): void {
	storage.setItem(keyFor(sessionId), JSON.stringify(state));
}

export function loadSessionViewState(
	storage: Pick<Storage, 'getItem'>,
	sessionId: string
): SessionViewState | null {
	const raw = storage.getItem(keyFor(sessionId));
	if (!raw) return null;
	try {
		return normalizeViewState(JSON.parse(raw));
	} catch {
		return null;
	}
}

function loadViewStateSafe(storage: ViewStateReadStorage, sessionId: string): SessionViewState | null {
	if (!storage) return null;
	try {
		return loadSessionViewState(storage, sessionId);
	} catch {
		return null;
	}
}

function saveViewStateSafe(storage: ViewStateWriteStorage, sessionId: string, state: SessionViewState): void {
	if (!storage) return;
	try {
		saveSessionViewState(storage, sessionId, state);
	} catch {
		// no-op when browser storage is unavailable
	}
}

export function loadSessionViewStateWithFallback(
	primaryStorage: ViewStateReadStorage,
	fallbackStorage: ViewStateReadStorage,
	sessionId: string
): SessionViewState | null {
	const primary = loadViewStateSafe(primaryStorage, sessionId);
	if (primary) return primary;
	return loadViewStateSafe(fallbackStorage, sessionId);
}

export function saveSessionViewStateWithFallback(
	primaryStorage: ViewStateWriteStorage,
	fallbackStorage: ViewStateWriteStorage,
	sessionId: string,
	state: SessionViewState
): void {
	saveViewStateSafe(primaryStorage, sessionId, state);
	if (fallbackStorage && fallbackStorage !== primaryStorage) {
		saveViewStateSafe(fallbackStorage, sessionId, state);
	}
}

export function readSessionTabFromUrl(input: string | URL): SessionTab | null {
	const url = input instanceof URL ? input : new URL(input);
	const tab = url.searchParams.get('tab');
	return isValidSessionTab(tab) ? tab : null;
}

export function toSessionTabHref(input: string | URL, tab: SessionTab): string {
	const url = input instanceof URL ? new URL(input.toString()) : new URL(input);
	if (tab === 'chat') {
		url.searchParams.delete('tab');
	} else {
		url.searchParams.set('tab', tab);
	}
	return `${url.pathname}${url.search}${url.hash}`;
}
