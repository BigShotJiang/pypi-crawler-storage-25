import { describe, expect, it } from 'vitest';

import {
	disableSessionViewportMode,
	enableSessionViewportMode,
	SESSION_VIEWPORT_CLASS
} from './viewport-mode';

function createClassListStub() {
	const set = new Set<string>();
	return {
		add: (...tokens: string[]) => {
			for (const token of tokens) set.add(token);
		},
		remove: (...tokens: string[]) => {
			for (const token of tokens) set.delete(token);
		},
		has: (token: string) => set.has(token)
	};
}

function createDocumentStub() {
	const htmlClasses = createClassListStub();
	const bodyClasses = createClassListStub();
	return {
		documentElement: { classList: htmlClasses },
		body: { classList: bodyClasses },
		htmlClasses,
		bodyClasses
	};
}

describe('session viewport mode', () => {
	it('adds the session viewport class to html and body', () => {
		const doc = createDocumentStub();

		enableSessionViewportMode(doc);

		expect(doc.htmlClasses.has(SESSION_VIEWPORT_CLASS)).toBe(true);
		expect(doc.bodyClasses.has(SESSION_VIEWPORT_CLASS)).toBe(true);
	});

	it('removes the session viewport class from html and body', () => {
		const doc = createDocumentStub();
		enableSessionViewportMode(doc);

		disableSessionViewportMode(doc);

		expect(doc.htmlClasses.has(SESSION_VIEWPORT_CLASS)).toBe(false);
		expect(doc.bodyClasses.has(SESSION_VIEWPORT_CLASS)).toBe(false);
	});
});
