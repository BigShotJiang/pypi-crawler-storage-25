const PREFERRED_RECORDING_MIME_TYPES = [
	'audio/webm;codecs=opus',
	'audio/webm',
	'audio/mp4',
	'audio/ogg;codecs=opus'
];

const IOS_PREFERRED_RECORDING_MIME_TYPES = [
	'audio/mp4',
	'audio/webm;codecs=opus',
	'audio/webm',
	'audio/ogg;codecs=opus'
];

export type VoiceRecordingEnvironment = {
	userAgent?: string;
	maxTouchPoints?: number;
};

export function isLikelyIOSRecordingEnvironment(
	environment: VoiceRecordingEnvironment = {}
): boolean {
	const userAgent = environment.userAgent?.toLowerCase() ?? '';
	if (userAgent.includes('iphone') || userAgent.includes('ipad') || userAgent.includes('ipod')) {
		return true;
	}
	return userAgent.includes('macintosh') && (environment.maxTouchPoints ?? 0) > 1;
}

export type VoiceCaptureMode = 'idle' | 'transcribe' | 'clean';

export function isVoiceButtonDisabled(options: {
	connected: boolean;
	sessionClosed: boolean;
	voiceBusy: boolean;
	voiceMode: VoiceCaptureMode;
	buttonMode: Exclude<VoiceCaptureMode, 'idle'>;
}): boolean {
	const { connected, sessionClosed, voiceBusy, voiceMode, buttonMode } = options;
	if (!connected || sessionClosed) {
		return true;
	}

	if (voiceMode !== 'idle') {
		return voiceMode !== buttonMode;
	}

	return voiceBusy;
}

export type VoiceRecorderLike = {
	state: string;
	requestData?: () => void;
	stop: () => void;
};

export function requestFinalChunkAndStop(
	recorder: VoiceRecorderLike,
	options: {
		stopDelayMs?: number;
		scheduleStop?: (callback: () => void, delayMs: number) => void;
	} = {}
): void {
	if (recorder.state === 'inactive') {
		return;
	}
	if (typeof recorder.requestData === 'function') {
		try {
			recorder.requestData();
		} catch {
			// Ignore requestData errors and continue stopping the recorder.
		}
	}

	const stop = () => {
		if (recorder.state !== 'inactive') {
			recorder.stop();
		}
	};
	const stopDelayMs = Math.max(0, options.stopDelayMs ?? 0);
	if (stopDelayMs > 0) {
		const scheduleStop =
			options.scheduleStop ?? ((callback: () => void, delayMs: number) => setTimeout(callback, delayMs));
		scheduleStop(stop, stopDelayMs);
		return;
	}
	stop();
}

export function choosePreferredRecordingMimeType(
	isTypeSupported: (mimeType: string) => boolean,
	environment: VoiceRecordingEnvironment = {}
): string | undefined {
	const preferredMimeTypes = isLikelyIOSRecordingEnvironment(environment)
		? IOS_PREFERRED_RECORDING_MIME_TYPES
		: PREFERRED_RECORDING_MIME_TYPES;
	for (const mimeType of preferredMimeTypes) {
		if (isTypeSupported(mimeType)) {
			return mimeType;
		}
	}
	return undefined;
}

export function appendTranscriptToComposerInput(currentInput: string, transcript: string): string {
	const trimmedTranscript = transcript.trim();
	if (!trimmedTranscript) {
		return currentInput;
	}

	if (!currentInput.trim()) {
		return trimmedTranscript;
	}

	return `${currentInput.trimEnd()}\n${trimmedTranscript}`;
}

export function arrayBufferToBase64(buffer: ArrayBuffer): string {
	const bytes = new Uint8Array(buffer);
	let binary = '';
	for (let i = 0; i < bytes.length; i += 1) {
		binary += String.fromCharCode(bytes[i]);
	}
	if (typeof btoa !== 'function') {
		throw new Error('Base64 encoding is not available in this browser.');
	}
	return btoa(binary);
}
