export type FilesViewState = {
	currentPath: string;
	selectedPath: string;
	previewFullscreen?: boolean;
};

export function normalizeFilesViewState(value: unknown): FilesViewState | null {
	if (!value || typeof value !== 'object') return null;
	const record = value as Record<string, unknown>;
	if (typeof record.currentPath !== 'string' || typeof record.selectedPath !== 'string') {
		return null;
	}

	const normalized: FilesViewState = {
		currentPath: record.currentPath,
		selectedPath: record.selectedPath
	};
	if (typeof record.previewFullscreen === 'boolean') {
		normalized.previewFullscreen = record.previewFullscreen;
	}
	return normalized;
}

export function createDefaultFilesViewState(): FilesViewState {
	return {
		currentPath: '',
		selectedPath: '',
		previewFullscreen: false
	};
}

export function withDefaultFilesViewState(state: FilesViewState | null | undefined): FilesViewState {
	return {
		...createDefaultFilesViewState(),
		...(state ?? {})
	};
}
