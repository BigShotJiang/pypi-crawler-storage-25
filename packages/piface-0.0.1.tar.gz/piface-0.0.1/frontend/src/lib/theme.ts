export type ThemeMode = 'auto' | 'light' | 'dark';
export type ResolvedTheme = 'light' | 'dark';
export type ThemeOverride = ResolvedTheme | null;

export const THEME_STORAGE_KEY = 'piface.theme.mode';

const PREFERS_DARK_MEDIA_QUERY = '(prefers-color-scheme: dark)';

export interface ThemeStorage {
	getItem(key: string): string | null;
	setItem(key: string, value: string): void;
}

export interface ThemeDocument {
	documentElement: {
		dataset: Record<string, string | undefined>;
		style: { colorScheme?: string };
	};
}

export interface ThemeMediaQuery {
	matches: boolean;
	addEventListener?: (type: 'change', listener: (event: { matches: boolean }) => void) => void;
	removeEventListener?: (type: 'change', listener: (event: { matches: boolean }) => void) => void;
	addListener?: (listener: (event: { matches: boolean }) => void) => void;
	removeListener?: (listener: (event: { matches: boolean }) => void) => void;
}

interface ThemeOptions {
	document?: ThemeDocument | null;
	storage?: ThemeStorage | null;
	mediaQuery?: ThemeMediaQuery | null;
	prefersDark?: boolean;
}

let currentMode: ThemeMode = 'auto';
let currentOverride: ThemeOverride = null;
let removeMediaListener: (() => void) | null = null;

function getBrowserDocument(): ThemeDocument | null {
	if (typeof document === 'undefined') {
		return null;
	}
	return document as unknown as ThemeDocument;
}

function getBrowserStorage(): ThemeStorage | null {
	if (typeof window === 'undefined') {
		return null;
	}
	try {
		return window.localStorage;
	} catch {
		return null;
	}
}

function getBrowserMediaQuery(): ThemeMediaQuery | null {
	if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') {
		return null;
	}
	return window.matchMedia(PREFERS_DARK_MEDIA_QUERY);
}

function isThemeMode(value: string | null): value is ThemeMode {
	return value === 'auto' || value === 'light' || value === 'dark';
}

function getPrefersDark(options: Pick<ThemeOptions, 'prefersDark' | 'mediaQuery'>): boolean {
	if (typeof options.prefersDark === 'boolean') {
		return options.prefersDark;
	}
	const mediaQuery = options.mediaQuery ?? getBrowserMediaQuery();
	return mediaQuery?.matches ?? false;
}

export function getThemeMode(): ThemeMode {
	return currentMode;
}

export function resolveTheme(mode: ThemeMode, prefersDark: boolean): ResolvedTheme {
	if (mode === 'auto') {
		return prefersDark ? 'dark' : 'light';
	}
	return mode;
}

export function getStoredThemeMode(storage: ThemeStorage | null = getBrowserStorage()): ThemeMode {
	if (!storage) {
		return 'auto';
	}
	const raw = storage.getItem(THEME_STORAGE_KEY);
	return isThemeMode(raw) ? raw : 'auto';
}

function applyResolvedTheme(
	resolvedTheme: ResolvedTheme,
	options: Pick<ThemeOptions, 'document'> = {}
): ResolvedTheme {
	const doc = options.document ?? getBrowserDocument();
	if (doc) {
		doc.documentElement.dataset.theme = resolvedTheme;
		doc.documentElement.style.colorScheme = resolvedTheme;
	}
	return resolvedTheme;
}

function applyCurrentTheme(
	options: Pick<ThemeOptions, 'document' | 'mediaQuery' | 'prefersDark'> = {}
): ResolvedTheme {
	if (currentOverride) {
		return applyResolvedTheme(currentOverride, options);
	}
	const resolvedTheme = resolveTheme(currentMode, getPrefersDark(options));
	return applyResolvedTheme(resolvedTheme, options);
}

export function applyTheme(
	mode: ThemeMode,
	options: Pick<ThemeOptions, 'document' | 'mediaQuery' | 'prefersDark'> = {}
): ResolvedTheme {
	const resolvedTheme = resolveTheme(mode, getPrefersDark(options));
	return applyResolvedTheme(resolvedTheme, options);
}

export function setThemeMode(mode: ThemeMode, options: ThemeOptions = {}): ResolvedTheme {
	currentMode = mode;
	const storage = options.storage ?? getBrowserStorage();
	storage?.setItem(THEME_STORAGE_KEY, mode);
	return applyCurrentTheme(options);
}

export function setThemeOverride(
	override: ThemeOverride,
	options: Pick<ThemeOptions, 'document' | 'mediaQuery' | 'prefersDark'> = {}
): ResolvedTheme {
	currentOverride = override;
	return applyCurrentTheme(options);
}

export function cleanupThemeSync(): void {
	if (removeMediaListener) {
		removeMediaListener();
		removeMediaListener = null;
	}
}

export function initTheme(options: Omit<ThemeOptions, 'prefersDark'> = {}): ThemeMode {
	cleanupThemeSync();

	const storage = options.storage ?? getBrowserStorage();
	const mediaQuery = options.mediaQuery ?? getBrowserMediaQuery();
	currentMode = getStoredThemeMode(storage);

	applyCurrentTheme({
		document: options.document,
		mediaQuery
	});

	if (!mediaQuery) {
		return currentMode;
	}

	const onMediaChange = (event: { matches: boolean }) => {
		if (currentMode === 'auto' && currentOverride === null) {
			applyCurrentTheme({
				document: options.document,
				prefersDark: event.matches,
				mediaQuery
			});
		}
	};

	if (typeof mediaQuery.addEventListener === 'function' && typeof mediaQuery.removeEventListener === 'function') {
		mediaQuery.addEventListener('change', onMediaChange);
		removeMediaListener = () => mediaQuery.removeEventListener?.('change', onMediaChange);
	} else if (typeof mediaQuery.addListener === 'function' && typeof mediaQuery.removeListener === 'function') {
		mediaQuery.addListener(onMediaChange);
		removeMediaListener = () => mediaQuery.removeListener?.(onMediaChange);
	}

	return currentMode;
}
