import { Marked, Renderer } from 'marked';

const ABSOLUTE_URL_SCHEME_RE = /^[a-zA-Z][a-zA-Z\d+.-]*:/;
const BLOCK_MATH_DOLLAR_RE = /^\$\$([\s\S]+?)\$\$(?:\n|$)/;
const BLOCK_MATH_BRACKET_RE = /^\\\[([\s\S]+?)\\\](?:\n|$)/;
const INLINE_MATH_PAREN_RE = /^\\\(([\s\S]+?)\\\)/;
const INLINE_MATH_DOLLAR_RE = /^\$(?!\$)([^\s$](?:[\s\S]*?[^\s$])?)\$(?!\$)/;
const INLINE_MATH_BRACKET_RE = /^\[\s*([^\]\n]*\\[A-Za-z][^\]\n]*)\s*\](?!\()/;
const MERMAID_FENCE_LANGUAGES = new Set(['mermaid', 'mmd']);

function escapeHtml(text: string): string {
	return text
		.replaceAll('&', '&amp;')
		.replaceAll('<', '&lt;')
		.replaceAll('>', '&gt;')
		.replaceAll('"', '&quot;')
		.replaceAll("'", '&#39;');
}

function renderMathExpression(tex: string, display: boolean): string {
	const normalized = tex.trim();
	if (!normalized) return '';
	const escaped = escapeHtml(normalized);
	if (display) {
		return `<div class="math-display">\\[${escaped}\\]</div>`;
	}
	return `<span class="math-inline">\\(${escaped}\\)</span>`;
}

const MATH_EXTENSIONS: any[] = [
	{
		name: 'mathBlockDollar',
		level: 'block',
		start(src: string) {
			return src.indexOf('$$');
		},
		tokenizer(src: string) {
			const match = BLOCK_MATH_DOLLAR_RE.exec(src);
			if (!match) return undefined;
			return {
				type: 'mathBlockDollar',
				raw: match[0],
				text: match[1]
			};
		},
		renderer(token: any) {
			return renderMathExpression(token.text, true);
		}
	},
	{
		name: 'mathBlockBracket',
		level: 'block',
		start(src: string) {
			return src.indexOf('\\[');
		},
		tokenizer(src: string) {
			const match = BLOCK_MATH_BRACKET_RE.exec(src);
			if (!match) return undefined;
			return {
				type: 'mathBlockBracket',
				raw: match[0],
				text: match[1]
			};
		},
		renderer(token: any) {
			return renderMathExpression(token.text, true);
		}
	},
	{
		name: 'mathInlineParen',
		level: 'inline',
		start(src: string) {
			return src.indexOf('\\(');
		},
		tokenizer(src: string) {
			const match = INLINE_MATH_PAREN_RE.exec(src);
			if (!match) return undefined;
			return {
				type: 'mathInlineParen',
				raw: match[0],
				text: match[1]
			};
		},
		renderer(token: any) {
			return renderMathExpression(token.text, false);
		}
	},
	{
		name: 'mathInlineDollar',
		level: 'inline',
		start(src: string) {
			return src.indexOf('$');
		},
		tokenizer(src: string) {
			const match = INLINE_MATH_DOLLAR_RE.exec(src);
			if (!match) return undefined;
			return {
				type: 'mathInlineDollar',
				raw: match[0],
				text: match[1]
			};
		},
		renderer(token: any) {
			return renderMathExpression(token.text, false);
		}
	},
	{
		name: 'mathInlineBracket',
		level: 'inline',
		start(src: string) {
			return src.indexOf('[');
		},
		tokenizer(src: string) {
			const match = INLINE_MATH_BRACKET_RE.exec(src);
			if (!match) return undefined;
			return {
				type: 'mathInlineBracket',
				raw: match[0],
				text: match[1]
			};
		},
		renderer(token: any) {
			return renderMathExpression(token.text, false);
		}
	}
];

type RenderMarkdownOptions = {
	rewriteImageHref?: ((href: string) => string) | null;
	rewriteLinkHref?: ((href: string) => string) | null;
};

function normalizeFenceLanguage(lang: string | null | undefined): string {
	const info = (lang ?? '').trim();
	if (!info) return '';
	const firstToken = info.split(/\s+/, 1)[0] ?? '';
	const braceMatch = /^\{(.+)\}$/.exec(firstToken);
	return (braceMatch?.[1] ?? firstToken).trim().toLowerCase();
}

export function isMermaidFence(lang: string | null | undefined): boolean {
	return MERMAID_FENCE_LANGUAGES.has(normalizeFenceLanguage(lang));
}

function renderMermaidFence(source: string): string {
	const encodedSource = escapeHtml(encodeURIComponent(source));
	const escapedSource = escapeHtml(source);
	return [
		'<div class="mermaid-block">',
		`<div class="mermaid-render-surface" data-mermaid-source="${encodedSource}">`,
		'<div class="mermaid-render-placeholder">Rendering Mermaid diagram…</div>',
		'</div>',
		'<details class="mermaid-source-details">',
		'<summary>Show source</summary>',
		`<pre><code class="language-mermaid">${escapedSource}</code></pre>`,
		'</details>',
		'</div>'
	].join('');
}

function createMarkedRenderer(options: RenderMarkdownOptions): Marked {
	const renderer = new Renderer();
	const defaultCodeRenderer = renderer.code.bind(renderer);
	const rewriteImageHref = options.rewriteImageHref ?? null;
	const rewriteLinkHref = options.rewriteLinkHref ?? null;

	renderer.code = (token: any) => {
		const source = token.text ?? '';
		if (isMermaidFence(token.lang)) {
			return renderMermaidFence(source);
		}
		return defaultCodeRenderer(token);
	};

	if (rewriteImageHref) {
		renderer.image = (token) => {
			const rewrittenHref = rewriteImageHref(token.href);
			const title = token.title ? ` title="${escapeHtml(token.title)}"` : '';
			return `<img src="${escapeHtml(rewrittenHref)}" alt="${escapeHtml(token.text ?? '')}"${title}>`;
		};
	}

	if (rewriteLinkHref) {
		renderer.link = (token) => {
			const rewrittenHref = rewriteLinkHref(token.href);
			const title = token.title ? ` title="${escapeHtml(token.title)}"` : '';
			return `<a href="${escapeHtml(rewrittenHref)}"${title}>${escapeHtml(token.text ?? '')}</a>`;
		};
	}

	const parser = new Marked({ renderer });
	parser.use({ extensions: MATH_EXTENSIONS });
	return parser;
}

function normalizePath(path: string): string {
	const normalized = path.replace(/\\/g, '/');
	const isAbsolute = normalized.startsWith('/');
	const segments: string[] = [];

	for (const segment of normalized.split('/')) {
		if (!segment || segment === '.') continue;
		if (segment === '..') {
			if (segments.length > 0 && segments[segments.length - 1] !== '..') {
				segments.pop();
			} else if (!isAbsolute) {
				segments.push('..');
			}
			continue;
		}
		segments.push(segment);
	}

	if (segments.length === 0) return isAbsolute ? '/' : '';
	return `${isAbsolute ? '/' : ''}${segments.join('/')}`;
}

function dirname(path: string): string {
	const normalized = normalizePath(path);
	const slash = normalized.lastIndexOf('/');
	if (slash < 0) return '';
	if (slash === 0) return '/';
	return normalized.slice(0, slash);
}

function isRelativeAssetHref(href: string): boolean {
	if (!href) return false;
	if (href.startsWith('#')) return false;
	if (href.startsWith('?')) return false;
	if (href.startsWith('/')) return false;
	if (href.startsWith('//')) return false;
	if (ABSOLUTE_URL_SCHEME_RE.test(href)) return false;
	return true;
}

function resolveFilePath(markdownFilePath: string, relativeHref: string): string {
	const [relativePath] = relativeHref.split(/[?#]/, 1);
	const baseDir = dirname(markdownFilePath);
	const combined = baseDir ? `${baseDir}/${relativePath}` : relativePath;
	return normalizePath(combined);
}

export function rewriteMarkdownAssetHref(markdownFilePath: string, href: string): string {
	if (!isRelativeAssetHref(href)) return href;
	const resolvedPath = resolveFilePath(markdownFilePath, href);
	return `/api/fs/raw?path=${encodeURIComponent(resolvedPath)}`;
}

export function renderMarkdown(markdown: string): string {
	const parser = createMarkedRenderer({});
	return parser.parse(markdown) as string;
}

export function renderMarkdownForFile(markdown: string, markdownFilePath: string): string {
	const parser = createMarkedRenderer({
		rewriteImageHref: (href) => rewriteMarkdownAssetHref(markdownFilePath, href),
		rewriteLinkHref: (href) => rewriteMarkdownAssetHref(markdownFilePath, href)
	});
	return parser.parse(markdown) as string;
}
