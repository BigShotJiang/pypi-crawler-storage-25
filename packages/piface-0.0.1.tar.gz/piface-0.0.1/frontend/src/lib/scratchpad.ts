export const SCRATCH_STORAGE_KEY_PREFIX = 'piface.session.scratch:';
export const SCRATCH_AUTOSAVE_DELAY_MS = 2000;

export function scratchStorageKey(sessionId: string): string {
	return `${SCRATCH_STORAGE_KEY_PREFIX}${sessionId}`;
}

export function loadSessionScratch(
	storage: Pick<Storage, 'getItem'>,
	sessionId: string
): string {
	return storage.getItem(scratchStorageKey(sessionId)) ?? '';
}

export function saveSessionScratch(
	storage: Pick<Storage, 'setItem'>,
	sessionId: string,
	text: string
): void {
	storage.setItem(scratchStorageKey(sessionId), text);
}

export type DebouncedScratchSaver = {
	schedule: (text: string) => void;
	flush: () => void;
	cancel: () => void;
};

export function createDebouncedScratchSaver(args: {
	delayMs: number;
	onSave: (text: string) => void;
}): DebouncedScratchSaver {
	let timer: ReturnType<typeof setTimeout> | null = null;
	let pendingText: string | null = null;

	function clearTimer() {
		if (timer) {
			clearTimeout(timer);
			timer = null;
		}
	}

	function flush() {
		if (pendingText === null) return;
		const text = pendingText;
		pendingText = null;
		clearTimer();
		args.onSave(text);
	}

	return {
		schedule(text: string) {
			pendingText = text;
			clearTimer();
			timer = setTimeout(() => {
				timer = null;
				flush();
			}, args.delayMs);
		},
		flush,
		cancel() {
			pendingText = null;
			clearTimer();
		}
	};
}
