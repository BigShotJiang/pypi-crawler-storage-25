<script lang="ts">
	import DOMPurify from 'dompurify';
	import { html as renderDiffHtml } from 'diff2html';
	import 'diff2html/bundles/css/diff2html.min.css';

	import {
		defaultDiffModeIsStaged,
		formatStatusCode,
		type GitChangedFile
	} from '$lib/git-diff';

	type GitStatusResponse = {
		is_repo: boolean;
		repo_root: string | null;
		branch: string | null;
		head: string | null;
		files: GitChangedFile[];
	};

	type GitDiffResponse = {
		is_repo: boolean;
		repo_root: string | null;
		path: string | null;
		staged: boolean;
		diff: string;
		truncated: boolean;
	};

	let { sessionId, rootPath }: { sessionId: string; rootPath: string } = $props();

	let loadingStatus = $state(false);
	let statusError = $state('');
	let status = $state<GitStatusResponse | null>(null);

	let selectedPath = $state('');
	let showStaged = $state(false);
	let loadingDiff = $state(false);
	let diffError = $state('');
	let renderedDiff = $state('');
	let diffTruncated = $state(false);

	let initialized = $state('');

	$effect(() => {
		const key = `${sessionId}:${rootPath}`;
		if (!sessionId || !rootPath || key === initialized) return;
		initialized = key;
		status = null;
		selectedPath = '';
		renderedDiff = '';
		diffError = '';
		void refreshStatus(true);
	});

	async function refreshStatus(selectFirst: boolean): Promise<void> {
		loadingStatus = true;
		statusError = '';
		try {
			const res = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/git/status`);
			if (!res.ok) {
				const body = await res.json().catch(() => ({}));
				statusError = body.detail ?? `Failed to load git status (${res.status})`;
				status = null;
				return;
			}
			const next = (await res.json()) as GitStatusResponse;
			status = next;
			if (!next.is_repo) {
				selectedPath = '';
				renderedDiff = '';
				return;
			}

			const selectedStillExists = next.files.some((file) => file.path === selectedPath);
			if (selectFirst || !selectedStillExists) {
				const first = next.files[0];
				if (first) {
					void selectFile(first);
				} else {
					selectedPath = '';
					renderedDiff = '';
					diffError = '';
				}
			} else if (selectedPath) {
				void loadDiff(selectedPath, showStaged);
			}
		} catch {
			statusError = 'Failed to load git status.';
			status = null;
		} finally {
			loadingStatus = false;
		}
	}

	function selectedFile(): GitChangedFile | null {
		if (!status?.files?.length) return null;
		return status.files.find((file) => file.path === selectedPath) ?? null;
	}

	async function selectFile(file: GitChangedFile): Promise<void> {
		selectedPath = file.path;
		showStaged = defaultDiffModeIsStaged(file);
		await loadDiff(file.path, showStaged);
	}

	async function onToggleStaged(next: boolean): Promise<void> {
		showStaged = next;
		if (!selectedPath) return;
		await loadDiff(selectedPath, next);
	}

	async function loadDiff(path: string, staged: boolean): Promise<void> {
		loadingDiff = true;
		diffError = '';
		renderedDiff = '';
		diffTruncated = false;
		try {
			const params = new URLSearchParams({ path, staged: String(staged) });
			const res = await fetch(
				`/api/sessions/${encodeURIComponent(sessionId)}/git/diff?${params.toString()}`
			);
			if (!res.ok) {
				const body = await res.json().catch(() => ({}));
				diffError = body.detail ?? `Failed to load diff (${res.status})`;
				return;
			}

			const data = (await res.json()) as GitDiffResponse;
			if (!data.is_repo) {
				renderedDiff = '';
				return;
			}
			diffTruncated = !!data.truncated;
			if (!data.diff) {
				renderedDiff = '';
				return;
			}

			const rendered = renderDiffHtml(data.diff, {
				drawFileList: false,
				matching: 'lines',
				outputFormat: 'side-by-side'
			});
			renderedDiff = DOMPurify.sanitize(rendered);
		} catch {
			diffError = 'Failed to load diff.';
		} finally {
			loadingDiff = false;
		}
	}
</script>

<div class="git-diff-viewer">
	<aside class="changes">
		<div class="toolbar">
			<button class="btn" type="button" onclick={() => refreshStatus(true)} disabled={loadingStatus}>
				{loadingStatus ? 'Refreshing…' : 'Refresh'}
			</button>
			{#if status?.is_repo}
				<div class="repo-meta" title={status.repo_root ?? ''}>
					{status.branch || 'detached'}{status.head ? ` @ ${status.head}` : ''}
				</div>
			{/if}
		</div>

		{#if statusError}
			<p class="state error">{statusError}</p>
		{:else if !status || loadingStatus}
			<p class="state">Loading git status…</p>
		{:else if !status.is_repo}
			<p class="state">This session folder is not a Git repository.</p>
		{:else if status.files.length === 0}
			<p class="state">Working tree is clean.</p>
		{:else}
			<ul>
				{#each status.files as file}
					<li>
						<button
							type="button"
							class="change"
							class:selected={file.path === selectedPath}
							onclick={() => selectFile(file)}
							title={file.path}
						>
							<span class="code">{formatStatusCode(file.status)}</span>
							<span class="name">{file.path}</span>
						</button>
					</li>
				{/each}
			</ul>
		{/if}
	</aside>

	<section class="diff-pane">
		{#if selectedFile()}
			<div class="diff-toolbar">
				<label>
					<input
						type="checkbox"
						checked={showStaged}
						disabled={!selectedFile()?.staged}
						onchange={(e) => onToggleStaged((e.currentTarget as HTMLInputElement).checked)}
					/>
					<span>Show staged diff</span>
				</label>
			</div>
		{/if}

		{#if diffError}
			<p class="state error">{diffError}</p>
		{:else if loadingDiff}
			<p class="state">Loading diff…</p>
		{:else if !selectedPath}
			<p class="state">Select a changed file to view its diff.</p>
		{:else if !renderedDiff}
			<p class="state">No diff for this file in the selected mode.</p>
		{:else}
			{#if diffTruncated}
				<p class="state warning">Diff output truncated for performance.</p>
			{/if}
			<div class="diff-html">{@html renderedDiff}</div>
		{/if}
	</section>
</div>

<style>
	.git-diff-viewer {
		display: grid;
		grid-template-columns: minmax(220px, 320px) minmax(0, 1fr);
		gap: 0.75rem;
		height: 100%;
		min-height: 0;
	}

	.changes,
	.diff-pane {
		background: var(--surface-1);
		border: 1px solid var(--border-soft);
		border-radius: 8px;
		min-height: 0;
	}

	.changes {
		display: flex;
		flex-direction: column;
		overflow: hidden;
	}

	.toolbar,
	.diff-toolbar {
		display: flex;
		align-items: center;
		gap: 0.5rem;
		padding: 0.6rem;
		border-bottom: 1px solid var(--border-soft);
	}

	.repo-meta {
		font-family: ui-monospace, 'SF Mono', monospace;
		font-size: 0.75rem;
		color: var(--color-subtle);
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}

	ul {
		list-style: none;
		padding: 0.35rem;
		margin: 0;
		overflow-y: auto;
		flex: 1;
	}

	.change {
		display: grid;
		grid-template-columns: auto minmax(0, 1fr);
		gap: 0.5rem;
		align-items: center;
		width: 100%;
		border: none;
		border-radius: 6px;
		padding: 0.35rem 0.45rem;
		background: transparent;
		color: var(--color-text);
		text-align: left;
		cursor: pointer;
	}

	.change:hover {
		background: var(--surface-hover);
	}

	.change.selected {
		background: var(--primary-bg);
		outline: 1px solid var(--primary-border);
	}

	.code {
		font-family: ui-monospace, 'SF Mono', monospace;
		font-size: 0.75rem;
		color: var(--color-subtle);
	}

	.name {
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		font-size: 0.85rem;
	}

	.diff-pane {
		overflow: auto;
	}

	.diff-html {
		padding: 0.75rem;
	}

	.state {
		margin: 0;
		padding: 1rem;
		color: var(--color-subtle);
	}

	.state.error {
		color: var(--danger-text);
	}

	.state.warning {
		color: #f6c177;
	}

	.btn {
		padding: 0.3rem 0.6rem;
		border: 1px solid var(--border-strong);
		border-radius: 6px;
		background: var(--surface-2);
		color: var(--color-text);
		cursor: pointer;
		font-size: 0.75rem;
	}

	.btn:disabled {
		opacity: 0.4;
		cursor: not-allowed;
	}

	@media (max-width: 900px) {
		.git-diff-viewer {
			display: flex;
			flex-direction: column;
		}

		.changes {
			min-height: 10rem;
			max-height: 42vh;
		}

		.diff-pane {
			min-height: 35vh;
		}
	}
</style>
