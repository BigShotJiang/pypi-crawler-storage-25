type MathJaxGlobal = {
	startup?: {
		promise?: Promise<unknown>;
	};
	typesetClear?: (elements?: HTMLElement[]) => void;
	typesetPromise?: (elements?: HTMLElement[]) => Promise<unknown>;
};

declare global {
	interface Window {
		MathJax?: MathJaxGlobal;
	}
}

export async function typesetMathInNode(node: HTMLElement): Promise<void> {
	if (typeof window === 'undefined') return;
	const mathjax = window.MathJax;
	if (!mathjax?.typesetPromise) return;

	try {
		if (mathjax.startup?.promise) {
			await mathjax.startup.promise;
		}
		mathjax.typesetClear?.([node]);
		await mathjax.typesetPromise([node]);
	} catch {
		// Keep markdown rendering resilient when MathJax is unavailable.
	}
}
