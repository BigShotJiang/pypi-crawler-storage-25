import { describe, expect, it } from 'vitest';

import {
	applySkin,
	getStoredSkin,
	setSkin,
	setSkinOverride,
	type SkinName
} from './skin';

function createDocumentStub() {
	return {
		documentElement: {
			dataset: {} as Record<string, string>
		}
	};
}

function createStorageStub(initial: Record<string, string> = {}) {
	const state = new Map(Object.entries(initial));
	return {
		getItem(key: string): string | null {
			return state.get(key) ?? null;
		},
		setItem(key: string, value: string) {
			state.set(key, value);
		}
	};
}

describe('skin utilities', () => {
	it('uses default when stored skin is missing or invalid', () => {
		expect(getStoredSkin(createStorageStub())).toBe('default');
		expect(getStoredSkin(createStorageStub({ 'piface.theme.skin': 'hybrid' }))).toBe('default');
	});

	it('returns stored skin when valid', () => {
		expect(getStoredSkin(createStorageStub({ 'piface.theme.skin': 'default' }))).toBe('default');
		expect(getStoredSkin(createStorageStub({ 'piface.theme.skin': 'beos' }))).toBe('beos');
		expect(getStoredSkin(createStorageStub({ 'piface.theme.skin': 'facebook2007' }))).toBe('facebook2007');
		expect(getStoredSkin(createStorageStub({ 'piface.theme.skin': 'nintendo' }))).toBe('nintendo');
		expect(getStoredSkin(createStorageStub({ 'piface.theme.skin': 'nintendo-nes' }))).toBe('nintendo-nes');
		expect(getStoredSkin(createStorageStub({ 'piface.theme.skin': 'winamp' }))).toBe('winamp');
		expect(getStoredSkin(createStorageStub({ 'piface.theme.skin': 'protoss' }))).toBe('protoss');
		expect(getStoredSkin(createStorageStub({ 'piface.theme.skin': 'terran' }))).toBe('terran');
		expect(getStoredSkin(createStorageStub({ 'piface.theme.skin': 'zerg' }))).toBe('zerg');
		expect(getStoredSkin(createStorageStub({ 'piface.theme.skin': 'synthwave' }))).toBe('synthwave');
		expect(getStoredSkin(createStorageStub({ 'piface.theme.skin': 'macos8' }))).toBe('macos8');
		expect(getStoredSkin(createStorageStub({ 'piface.theme.skin': 'windows98' }))).toBe('windows98');
	});

	it('applies the selected skin to the document dataset', () => {
		const doc = createDocumentStub();
		applySkin('nintendo-nes', { document: doc });
		expect(doc.documentElement.dataset.skin).toBe('nintendo-nes');
	});

	it('persists selected skin and applies it immediately', () => {
		const doc = createDocumentStub();
		const storage = createStorageStub();

		setSkin('nintendo-nes' satisfies SkinName, {
			document: doc,
			storage
		});

		expect(storage.getItem('piface.theme.skin')).toBe('nintendo-nes');
		expect(doc.documentElement.dataset.skin).toBe('nintendo-nes');
	});

	it('applies temporary skin override and restores base skin when cleared', () => {
		const doc = createDocumentStub();
		const storage = createStorageStub();

		setSkin('default', {
			document: doc,
			storage
		});
		expect(doc.documentElement.dataset.skin).toBe('default');

		setSkinOverride('beos', { document: doc });
		expect(doc.documentElement.dataset.skin).toBe('beos');
		expect(storage.getItem('piface.theme.skin')).toBe('default');

		setSkinOverride(null, { document: doc });
		expect(doc.documentElement.dataset.skin).toBe('default');
	});

	it('keeps override active even when base skin changes', () => {
		const doc = createDocumentStub();
		const storage = createStorageStub();

		setSkin('default', {
			document: doc,
			storage
		});
		setSkinOverride('beos', { document: doc });

		setSkin('nintendo', {
			document: doc,
			storage
		});
		expect(storage.getItem('piface.theme.skin')).toBe('nintendo');
		expect(doc.documentElement.dataset.skin).toBe('beos');

		setSkinOverride(null, { document: doc });
		expect(doc.documentElement.dataset.skin).toBe('nintendo');
	});
});
