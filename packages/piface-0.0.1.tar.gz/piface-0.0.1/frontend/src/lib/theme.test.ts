import { describe, expect, it } from 'vitest';

import {
	applyTheme,
	getStoredThemeMode,
	resolveTheme,
	setThemeMode,
	setThemeOverride,
	type ThemeMode
} from './theme';

function createDocumentStub() {
	return {
		documentElement: {
			dataset: {} as Record<string, string>,
			style: {} as { colorScheme?: string }
		}
	};
}

function createStorageStub(initial: Record<string, string> = {}) {
	const state = new Map(Object.entries(initial));
	return {
		getItem(key: string): string | null {
			return state.get(key) ?? null;
		},
		setItem(key: string, value: string) {
			state.set(key, value);
		}
	};
}

describe('theme utilities', () => {
	it('uses auto when stored mode is missing or invalid', () => {
		expect(getStoredThemeMode(createStorageStub())).toBe('auto');
		expect(getStoredThemeMode(createStorageStub({ 'piface.theme.mode': 'neon' }))).toBe('auto');
	});

	it('returns stored theme mode when valid', () => {
		expect(getStoredThemeMode(createStorageStub({ 'piface.theme.mode': 'light' }))).toBe('light');
		expect(getStoredThemeMode(createStorageStub({ 'piface.theme.mode': 'dark' }))).toBe('dark');
		expect(getStoredThemeMode(createStorageStub({ 'piface.theme.mode': 'auto' }))).toBe('auto');
	});

	it('resolves auto theme from system preference', () => {
		expect(resolveTheme('auto', true)).toBe('dark');
		expect(resolveTheme('auto', false)).toBe('light');
	});

	it('applies dark/light classes and color scheme', () => {
		const doc = createDocumentStub();

		expect(applyTheme('light', { document: doc, prefersDark: true })).toBe('light');
		expect(doc.documentElement.dataset.theme).toBe('light');
		expect(doc.documentElement.style.colorScheme).toBe('light');

		expect(applyTheme('dark', { document: doc, prefersDark: false })).toBe('dark');
		expect(doc.documentElement.dataset.theme).toBe('dark');
		expect(doc.documentElement.style.colorScheme).toBe('dark');
	});

	it('persists selected mode and applies it immediately', () => {
		const doc = createDocumentStub();
		const storage = createStorageStub();

		setThemeMode('dark' satisfies ThemeMode, {
			document: doc,
			storage,
			prefersDark: false
		});

		expect(storage.getItem('piface.theme.mode')).toBe('dark');
		expect(doc.documentElement.dataset.theme).toBe('dark');
	});

	it('applies a temporary theme override and restores base mode when cleared', () => {
		const doc = createDocumentStub();
		const storage = createStorageStub();

		setThemeMode('light', {
			document: doc,
			storage,
			prefersDark: true
		});
		expect(doc.documentElement.dataset.theme).toBe('light');

		setThemeOverride('dark', {
			document: doc,
			prefersDark: false
		});
		expect(doc.documentElement.dataset.theme).toBe('dark');
		expect(storage.getItem('piface.theme.mode')).toBe('light');

		setThemeOverride(null, {
			document: doc,
			prefersDark: false
		});
		expect(doc.documentElement.dataset.theme).toBe('light');
	});

	it('keeps override active even when base mode changes', () => {
		const doc = createDocumentStub();
		const storage = createStorageStub();

		setThemeMode('light', {
			document: doc,
			storage,
			prefersDark: false
		});
		setThemeOverride('dark', {
			document: doc,
			prefersDark: false
		});

		setThemeMode('auto', {
			document: doc,
			storage,
			prefersDark: false
		});
		expect(storage.getItem('piface.theme.mode')).toBe('auto');
		expect(doc.documentElement.dataset.theme).toBe('dark');

		setThemeOverride(null, {
			document: doc,
			prefersDark: false
		});
		expect(doc.documentElement.dataset.theme).toBe('light');
	});
});
