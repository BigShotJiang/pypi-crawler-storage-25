import { describe, expect, it } from 'vitest';

import {
	CREATE_SESSION_THINKING_LEVELS,
	SESSION_THINKING_LEVELS
} from './thinking-levels';

describe('thinking level options', () => {
	it('includes xhigh in the new-session form options', () => {
		expect(CREATE_SESSION_THINKING_LEVELS).toContain('xhigh');
		expect(CREATE_SESSION_THINKING_LEVELS).toEqual([
			'',
			'off',
			'minimal',
			'low',
			'medium',
			'high',
			'xhigh'
		]);
	});

	it('includes xhigh in the live session thinking control options', () => {
		expect(SESSION_THINKING_LEVELS).toContain('xhigh');
		expect(SESSION_THINKING_LEVELS).toEqual([
			'',
			'off',
			'minimal',
			'low',
			'medium',
			'high',
			'xhigh'
		]);
	});
});
