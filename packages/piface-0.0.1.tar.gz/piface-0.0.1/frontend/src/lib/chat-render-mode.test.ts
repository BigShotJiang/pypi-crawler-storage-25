import { describe, expect, it } from 'vitest';

import { isMarkdownEnabled } from './chat-render-mode';

describe('isMarkdownEnabled', () => {
	it('defaults to true when unset', () => {
		expect(isMarkdownEnabled(undefined)).toBe(true);
		expect(isMarkdownEnabled(null)).toBe(true);
		expect(isMarkdownEnabled({})).toBe(true);
		expect(isMarkdownEnabled({ render_markdown: null })).toBe(true);
	});

	it('returns explicit boolean value when present', () => {
		expect(isMarkdownEnabled({ render_markdown: true })).toBe(true);
		expect(isMarkdownEnabled({ render_markdown: false })).toBe(false);
	});
});
