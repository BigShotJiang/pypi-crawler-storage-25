import { describe, expect, it, vi } from 'vitest';

import { RELOAD_SEMANTIC_WARNING, restartSessionViaSlashReload } from './session-reload';

describe('RELOAD_SEMANTIC_WARNING', () => {
	it('mentions semantic differences from native pi /reload', () => {
		expect(RELOAD_SEMANTIC_WARNING.toLowerCase()).toContain('does not run pi');
		expect(RELOAD_SEMANTIC_WARNING.toLowerCase()).toContain('kill and resume');
	});
});

describe('restartSessionViaSlashReload', () => {
	it('returns invalid when no session id is provided', async () => {
		const result = await restartSessionViaSlashReload({
			sessionId: '',
			sessionStatus: 'live',
			noSession: false,
			confirmReload: () => true,
			onAfterRestart: vi.fn()
		});

		expect(result).toEqual({ ok: false, skipped: 'invalid' });
	});

	it('returns invalid when session is closed', async () => {
		const result = await restartSessionViaSlashReload({
			sessionId: 'abc',
			sessionStatus: 'closed',
			noSession: false,
			confirmReload: () => true,
			onAfterRestart: vi.fn()
		});

		expect(result).toEqual({ ok: false, skipped: 'invalid' });
	});

	it('returns an error for ephemeral sessions', async () => {
		const result = await restartSessionViaSlashReload({
			sessionId: 'abc',
			sessionStatus: 'live',
			noSession: true,
			confirmReload: () => true,
			onAfterRestart: vi.fn()
		});

		expect(result).toEqual({ ok: false, error: 'Ephemeral sessions cannot be reloaded.' });
	});

	it('returns cancelled when user rejects warning dialog', async () => {
		const fetchImpl = vi.fn();
		const result = await restartSessionViaSlashReload({
			sessionId: 'abc',
			sessionStatus: 'live',
			noSession: false,
			confirmReload: () => false,
			fetchImpl: fetchImpl as any,
			onAfterRestart: vi.fn()
		});

		expect(result).toEqual({ ok: false, skipped: 'cancelled' });
		expect(fetchImpl).not.toHaveBeenCalled();
	});

	it('returns an error when kill fails', async () => {
		const fetchImpl = vi.fn().mockResolvedValue({
			ok: false,
			status: 500,
			json: vi.fn().mockResolvedValue({ detail: 'kill failed' })
		});

		const result = await restartSessionViaSlashReload({
			sessionId: 'abc',
			sessionStatus: 'live',
			noSession: false,
			confirmReload: () => true,
			fetchImpl: fetchImpl as any,
			onAfterRestart: vi.fn()
		});

		expect(result).toEqual({ ok: false, error: 'kill failed' });
		expect(fetchImpl).toHaveBeenCalledWith('/api/sessions/abc/kill', { method: 'POST' });
	});

	it('returns an error when resume fails after kill', async () => {
		const fetchImpl = vi
			.fn()
			.mockResolvedValueOnce({ ok: true })
			.mockResolvedValueOnce({
				ok: false,
				status: 409,
				json: vi.fn().mockResolvedValue({ detail: 'cannot resume' })
			});
		const onBeforeRestart = vi.fn();

		const result = await restartSessionViaSlashReload({
			sessionId: 'abc',
			sessionStatus: 'live',
			noSession: false,
			confirmReload: () => true,
			fetchImpl: fetchImpl as any,
			onBeforeRestart,
			onAfterRestart: vi.fn()
		});

		expect(result).toEqual({ ok: false, error: 'cannot resume' });
		expect(onBeforeRestart).toHaveBeenCalledTimes(1);
	});

	it('kills then resumes and runs callback on success', async () => {
		const fetchImpl = vi
			.fn()
			.mockResolvedValueOnce({ ok: true })
			.mockResolvedValueOnce({ ok: true });
		const onBeforeRestart = vi.fn();
		const onAfterRestart = vi.fn().mockResolvedValue(undefined);

		const result = await restartSessionViaSlashReload({
			sessionId: 'abc',
			sessionStatus: 'live',
			noSession: false,
			confirmReload: () => true,
			fetchImpl: fetchImpl as any,
			onBeforeRestart,
			onAfterRestart
		});

		expect(result).toEqual({ ok: true });
		expect(fetchImpl).toHaveBeenNthCalledWith(1, '/api/sessions/abc/kill', { method: 'POST' });
		expect(fetchImpl).toHaveBeenNthCalledWith(2, '/api/sessions/abc/resume', { method: 'POST' });
		expect(onBeforeRestart).toHaveBeenCalledTimes(1);
		expect(onAfterRestart).toHaveBeenCalledTimes(1);
	});
});
