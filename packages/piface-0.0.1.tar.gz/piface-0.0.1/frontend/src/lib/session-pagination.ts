export const SESSIONS_PER_DIRECTORY_PAGE = 10;

export interface SessionListItemLike {
	working_dir: string;
	project_dir?: string | null;
	last_active: string;
	[key: string]: unknown;
}

export interface DirectoryPage<T> {
	page: number;
	totalPages: number;
	items: T[];
	hasPrev: boolean;
	hasNext: boolean;
}

export function groupSessionsByDirectory<T extends SessionListItemLike>(
	sessions: T[]
): Map<string, T[]> {
	const map = new Map<string, T[]>();
	const sorted = [...sessions].sort(
		(a, b) => new Date(b.last_active).getTime() - new Date(a.last_active).getTime()
	);

	for (const session of sorted) {
		const dir = session.project_dir ?? session.working_dir;
		if (!map.has(dir)) map.set(dir, []);
		map.get(dir)!.push(session);
	}

	return map;
}

export function getDirectoryPage<T>(
	group: T[],
	page: number,
	pageSize: number = SESSIONS_PER_DIRECTORY_PAGE
): DirectoryPage<T> {
	const totalPages = Math.max(1, Math.ceil(group.length / pageSize));
	const safePage = Math.min(Math.max(0, page), totalPages - 1);
	const start = safePage * pageSize;
	const end = start + pageSize;
	const items = group.slice(start, end);

	return {
		page: safePage,
		totalPages,
		items,
		hasPrev: safePage > 0,
		hasNext: safePage < totalPages - 1
	};
}
