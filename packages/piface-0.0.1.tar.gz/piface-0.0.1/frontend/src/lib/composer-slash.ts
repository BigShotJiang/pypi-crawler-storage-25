export type ComposerSlashCommand =
	| { kind: 'copy' }
	| { kind: 'compact'; customInstructions?: string }
	| { kind: 'reload' };

export function parseComposerSlashCommand(input: string): ComposerSlashCommand | null {
	const text = input.trim();

	if (/^\/copy\s*$/i.test(text)) {
		return { kind: 'copy' };
	}

	const compactMatch = text.match(/^\/compact(?:\s+(.*))?$/i);
	if (compactMatch) {
		const customInstructions = compactMatch[1]?.trim();
		if (customInstructions) {
			return { kind: 'compact', customInstructions };
		}
		return { kind: 'compact' };
	}

	if (/^\/reload\s*$/i.test(text)) {
		return { kind: 'reload' };
	}

	return null;
}

function getMessageText(content: unknown): string {
	if (typeof content === 'string') return content;
	if (!Array.isArray(content)) return '';
	return content
		.filter((chunk) => {
			return (
				typeof chunk === 'object' &&
				chunk !== null &&
				'type' in chunk &&
				(chunk as { type?: unknown }).type === 'text' &&
				'text' in chunk &&
				typeof (chunk as { text?: unknown }).text === 'string'
			);
		})
		.map((chunk) => (chunk as { text: string }).text)
		.join('');
}

export function getLastAssistantMessageText(messages: unknown[]): string {
	for (let i = messages.length - 1; i >= 0; i -= 1) {
		const message = messages[i];
		if (typeof message !== 'object' || message === null) continue;

		const role = (message as { role?: unknown }).role;
		if (role !== 'assistant') continue;

		const text = getMessageText((message as { content?: unknown }).content).trim();
		if (text) return text;
	}

	return '';
}
