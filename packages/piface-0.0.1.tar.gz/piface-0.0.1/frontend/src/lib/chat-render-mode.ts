type SessionLike = {
	render_markdown?: boolean | null;
};

export function isMarkdownEnabled(session: SessionLike | null | undefined): boolean {
	return session?.render_markdown !== false;
}
