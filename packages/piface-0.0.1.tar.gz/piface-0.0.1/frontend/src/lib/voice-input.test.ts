import { describe, expect, it } from 'vitest';

import {
	appendTranscriptToComposerInput,
	choosePreferredRecordingMimeType,
	isLikelyIOSRecordingEnvironment,
	isVoiceButtonDisabled,
	requestFinalChunkAndStop
} from './voice-input';

describe('choosePreferredRecordingMimeType', () => {
	it('chooses the best supported recording mime type', () => {
		const supported = new Set(['audio/webm']);
		const selected = choosePreferredRecordingMimeType((value) => supported.has(value));
		expect(selected).toBe('audio/webm');
	});

	it('prefers mp4 on iOS when both mp4 and webm are supported', () => {
		const supported = new Set(['audio/webm', 'audio/mp4']);
		const selected = choosePreferredRecordingMimeType((value) => supported.has(value), {
			userAgent:
				'Mozilla/5.0 (iPhone; CPU iPhone OS 18_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/135.0 Mobile/15E148 Safari/604.1',
			maxTouchPoints: 5
		});
		expect(selected).toBe('audio/mp4');
	});

	it('falls back to undefined when no preferred type is supported', () => {
		const selected = choosePreferredRecordingMimeType(() => false);
		expect(selected).toBeUndefined();
	});
});

describe('isLikelyIOSRecordingEnvironment', () => {
	it('detects iPadOS reported as Macintosh when touch points are present', () => {
		expect(
			isLikelyIOSRecordingEnvironment({
				userAgent:
					'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.3 Safari/605.1.15',
				maxTouchPoints: 5
			})
		).toBe(true);
	});

	it('does not mark desktop macOS as iOS recording environment', () => {
		expect(
			isLikelyIOSRecordingEnvironment({
				userAgent:
					'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Safari/605.1.15',
				maxTouchPoints: 0
			})
		).toBe(false);
	});
});

describe('appendTranscriptToComposerInput', () => {
	it('uses transcript directly when composer is empty', () => {
		expect(appendTranscriptToComposerInput('', 'hello world')).toBe('hello world');
	});

	it('appends transcript on a new line when composer already has text', () => {
		expect(appendTranscriptToComposerInput('first line', 'second line')).toBe('first line\nsecond line');
	});
});

describe('isVoiceButtonDisabled', () => {
	it('keeps the active recording button enabled so users can stop recording', () => {
		expect(
			isVoiceButtonDisabled({
				connected: true,
				sessionClosed: false,
				voiceBusy: true,
				voiceMode: 'transcribe',
				buttonMode: 'transcribe'
			})
		).toBe(false);
	});

	it('disables the inactive recording button while another mode is recording', () => {
		expect(
			isVoiceButtonDisabled({
				connected: true,
				sessionClosed: false,
				voiceBusy: true,
				voiceMode: 'clean',
				buttonMode: 'transcribe'
			})
		).toBe(true);
	});

	it('disables both buttons while transcription is running', () => {
		expect(
			isVoiceButtonDisabled({
				connected: true,
				sessionClosed: false,
				voiceBusy: true,
				voiceMode: 'idle',
				buttonMode: 'clean'
			})
		).toBe(true);
	});
});

describe('requestFinalChunkAndStop', () => {
	it('requests a final data chunk before stopping', () => {
		const calls: string[] = [];
		requestFinalChunkAndStop({
			state: 'recording',
			requestData: () => calls.push('requestData'),
			stop: () => calls.push('stop')
		});
		expect(calls).toEqual(['requestData', 'stop']);
	});

	it('still stops when requestData throws', () => {
		const calls: string[] = [];
		requestFinalChunkAndStop({
			state: 'recording',
			requestData: () => {
				calls.push('requestData');
				throw new Error('no buffered data yet');
			},
			stop: () => calls.push('stop')
		});
		expect(calls).toEqual(['requestData', 'stop']);
	});

	it('supports delayed stop scheduling for mobile recorder flushes', () => {
		const calls: string[] = [];
		let scheduledDelayMs = -1;
		let callCountWhenScheduled = -1;
		requestFinalChunkAndStop(
			{
				state: 'recording',
				requestData: () => calls.push('requestData'),
				stop: () => calls.push('stop')
			},
			{
				stopDelayMs: 120,
				scheduleStop: (callback, delayMs) => {
					callCountWhenScheduled = calls.length;
					scheduledDelayMs = delayMs;
					callback();
				}
			}
		);
		expect(callCountWhenScheduled).toBe(1);
		expect(scheduledDelayMs).toBe(120);
		expect(calls).toEqual(['requestData', 'stop']);
	});

	it('does not call stop for an inactive recorder', () => {
		const calls: string[] = [];
		requestFinalChunkAndStop({
			state: 'inactive',
			requestData: () => calls.push('requestData'),
			stop: () => calls.push('stop')
		});
		expect(calls).toEqual([]);
	});
});
