import { describe, expect, it } from 'vitest';

import { normalizeComposerText } from './composer-text-normalize';

describe('normalizeComposerText', () => {
	it('leaves plain ascii text unchanged', () => {
		expect(normalizeComposerText('pi --model gpt-5 --thinking medium')).toBe(
			'pi --model gpt-5 --thinking medium'
		);
	});

	it('normalizes smart quotes and apostrophes', () => {
		expect(normalizeComposerText('“hello”, it’s me')).toBe('"hello", it\'s me');
	});

	it('normalizes smart dashes for cli-style arguments', () => {
		expect(normalizeComposerText('pi —model gpt-5 and -–dry-run')).toBe(
			'pi --model gpt-5 and --dry-run'
		);
	});

	it('normalizes ellipsis and non-breaking spaces', () => {
		expect(normalizeComposerText('wait… now\u00A0go')).toBe('wait... now go');
	});
});
