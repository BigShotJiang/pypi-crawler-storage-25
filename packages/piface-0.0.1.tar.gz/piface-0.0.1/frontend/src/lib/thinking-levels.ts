export const CREATE_SESSION_THINKING_LEVELS = [
	'',
	'off',
	'minimal',
	'low',
	'medium',
	'high',
	'xhigh'
] as const;

export const SESSION_THINKING_LEVELS = [...CREATE_SESSION_THINKING_LEVELS] as const;

export type ThinkingLevelOption = (typeof CREATE_SESSION_THINKING_LEVELS)[number];
