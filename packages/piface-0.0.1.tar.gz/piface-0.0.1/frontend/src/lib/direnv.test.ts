import { describe, expect, it, vi } from 'vitest';

import { allowDirenvForDirectory, isDirenvBlockedError } from './direnv';

describe('isDirenvBlockedError', () => {
	it('detects blocked .envrc errors', () => {
		expect(
			isDirenvBlockedError('direnv: error /tmp/project/.envrc is blocked. Run `direnv allow`.')
		).toBe(true);
	});

	it('returns false for unrelated errors', () => {
		expect(isDirenvBlockedError('Session not found')).toBe(false);
		expect(isDirenvBlockedError('')).toBe(false);
	});
});

describe('allowDirenvForDirectory', () => {
	it('posts working directory and returns success', async () => {
		const fetchImpl = vi.fn().mockResolvedValue({ ok: true, json: vi.fn() });

		const result = await allowDirenvForDirectory({
			workingDir: '/tmp/project',
			fetchImpl: fetchImpl as any
		});

		expect(result).toEqual({ ok: true });
		expect(fetchImpl).toHaveBeenCalledWith('/api/direnv/allow', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ working_dir: '/tmp/project' })
		});
	});

	it('surfaces API errors', async () => {
		const fetchImpl = vi.fn().mockResolvedValue({
			ok: false,
			status: 409,
			json: vi.fn().mockResolvedValue({ detail: 'direnv blocked' })
		});

		const result = await allowDirenvForDirectory({
			workingDir: '/tmp/project',
			fetchImpl: fetchImpl as any
		});

		expect(result).toEqual({ ok: false, error: 'direnv blocked' });
	});
});
