export type TtsPlaybackState = 'idle' | 'loading' | 'playing' | 'paused';

export function formatPlaybackTime(seconds: number): string {
	if (!Number.isFinite(seconds) || seconds < 0) {
		return '0:00';
	}
	const wholeSeconds = Math.floor(seconds);
	const minutes = Math.floor(wholeSeconds / 60);
	const remainingSeconds = wholeSeconds % 60;
	return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

export function seekPlaybackTime(
	currentTime: number,
	deltaSeconds: number,
	durationSeconds?: number
): number {
	const next = Math.max(0, currentTime + deltaSeconds);
	if (!Number.isFinite(durationSeconds ?? Number.NaN) || (durationSeconds ?? 0) < 0) {
		return next;
	}
	return Math.min(next, durationSeconds ?? next);
}

export function getTtsPlaybackState(options: {
	messageKey: string;
	loadingMessageKey: string;
	activeMessageKey: string;
	isPlaying: boolean;
	hasPreparedAudio: boolean;
}): TtsPlaybackState {
	const { messageKey, loadingMessageKey, activeMessageKey, isPlaying, hasPreparedAudio } = options;
	if (loadingMessageKey === messageKey) {
		return 'loading';
	}
	if (activeMessageKey === messageKey && hasPreparedAudio) {
		return isPlaying ? 'playing' : 'paused';
	}
	return 'idle';
}

export function getTtsPrimaryActionLabel(options: {
	messageKey: string;
	loadingMessageKey: string;
	activeMessageKey: string;
	isPlaying: boolean;
	hasPreparedAudio: boolean;
}): string {
	switch (getTtsPlaybackState(options)) {
		case 'loading':
			return 'Generating audio…';
		case 'playing':
			return 'Pause';
		case 'paused':
			return 'Play';
		default:
			return 'Listen';
	}
}

export function isTtsPrimaryActionDisabled(options: {
	messageKey: string;
	loadingMessageKey: string;
}): boolean {
	return !!options.loadingMessageKey;
}

export function shouldRenderTtsInlinePlayer(options: {
	messageKey: string;
	loadingMessageKey: string;
	activeMessageKey: string;
	hasPreparedAudio: boolean;
	errorMessageKey: string;
}): boolean {
	const { messageKey, loadingMessageKey, activeMessageKey, hasPreparedAudio, errorMessageKey } =
		options;
	return (
		loadingMessageKey === messageKey ||
		(activeMessageKey === messageKey && hasPreparedAudio) ||
		errorMessageKey === messageKey
	);
}

export function getTtsProgressPercent(currentTimeSeconds: number, durationSeconds: number): number {
	if (!Number.isFinite(durationSeconds) || durationSeconds <= 0) {
		return 0;
	}
	if (!Number.isFinite(currentTimeSeconds)) {
		return 0;
	}
	const clampedCurrent = Math.min(Math.max(currentTimeSeconds, 0), durationSeconds);
	return Math.round((clampedCurrent / durationSeconds) * 100);
}

export function getTtsSeekBackSeconds(durationSeconds: number): number | null {
	if (!Number.isFinite(durationSeconds) || durationSeconds < 20) {
		return null;
	}
	if (durationSeconds < 90) {
		return 10;
	}
	return 15;
}

export function getTtsSeekBackLabel(durationSeconds: number): string {
	const seconds = getTtsSeekBackSeconds(durationSeconds);
	return seconds ? `-${seconds}s` : '';
}
