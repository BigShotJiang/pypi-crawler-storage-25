import { describe, expect, it } from 'vitest';

import {
	COMPOSER_MAX_VIEWPORT_RATIO,
	MOBILE_COMPOSER_BREAKPOINT_PX,
	computeComposerHeight,
	createMobileComposerFullscreenState,
	enterMobileComposerFullscreenOnFocus,
	exitMobileComposerFullscreen,
	isMobileComposerViewport,
	resetMobileComposerAutoEnter
} from './composer-layout';

describe('computeComposerHeight', () => {
	it('grows with content until the viewport-based cap', () => {
		const result = computeComposerHeight({
			scrollHeight: 360,
			minHeight: 56,
			viewportHeight: 1000
		});

		expect(result.height).toBe(360);
		expect(result.maxHeight).toBe(400);
		expect(result.isClamped).toBe(false);
	});

	it('clamps to 40% of viewport height when content exceeds the cap', () => {
		const result = computeComposerHeight({
			scrollHeight: 700,
			minHeight: 56,
			viewportHeight: 1000
		});

		expect(result.height).toBe(400);
		expect(result.maxHeight).toBe(400);
		expect(result.isClamped).toBe(true);
	});

	it('never shrinks below minHeight', () => {
		const result = computeComposerHeight({
			scrollHeight: 28,
			minHeight: 56,
			viewportHeight: 1000
		});

		expect(result.height).toBe(56);
		expect(result.maxHeight).toBe(400);
		expect(result.isClamped).toBe(false);
	});

	it('uses a 40% viewport cap by default', () => {
		expect(COMPOSER_MAX_VIEWPORT_RATIO).toBe(0.4);
	});
});

describe('isMobileComposerViewport', () => {
	it('matches widths at or below the mobile breakpoint', () => {
		expect(isMobileComposerViewport(MOBILE_COMPOSER_BREAKPOINT_PX)).toBe(true);
		expect(isMobileComposerViewport(360)).toBe(true);
	});

	it('does not match widths above the mobile breakpoint', () => {
		expect(isMobileComposerViewport(MOBILE_COMPOSER_BREAKPOINT_PX + 1)).toBe(false);
	});
});

describe('mobile fullscreen composer state', () => {
	it('does not auto-enter fullscreen on focus by default', () => {
		const initial = createMobileComposerFullscreenState();
		const next = enterMobileComposerFullscreenOnFocus(initial, true);

		expect(next.isFullscreen).toBe(false);
		expect(next.autoEnterOnFocus).toBe(false);
	});

	it('exit keeps auto-enter disabled', () => {
		const entered = {
			...createMobileComposerFullscreenState(),
			isFullscreen: true
		};
		const exited = exitMobileComposerFullscreen(entered);
		const focusedAgain = enterMobileComposerFullscreenOnFocus(exited, true);

		expect(exited.isFullscreen).toBe(false);
		expect(exited.autoEnterOnFocus).toBe(false);
		expect(focusedAgain.isFullscreen).toBe(false);
	});

	it('reset preserves no-auto-enter behavior', () => {
		const exited = exitMobileComposerFullscreen(createMobileComposerFullscreenState());
		const reset = resetMobileComposerAutoEnter(exited);
		const focused = enterMobileComposerFullscreenOnFocus(reset, true);

		expect(reset.autoEnterOnFocus).toBe(false);
		expect(focused.isFullscreen).toBe(false);
	});
});
