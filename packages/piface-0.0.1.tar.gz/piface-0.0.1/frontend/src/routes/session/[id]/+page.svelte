<script lang="ts">
	import { goto } from '$app/navigation';
	import { page } from '$app/state';
	import { onDestroy, onMount, tick } from 'svelte';
	import DOMPurify from 'dompurify';

	import { resolveComposerCommandType, isFollowUpShortcut } from '$lib/composer-command';
	import { getLastAssistantMessageText, parseComposerSlashCommand } from '$lib/composer-slash';
	import { collectFilesFromTransfer } from '$lib/image-input';
	import SessionFileViewer from '$lib/SessionFileViewer.svelte';
	import SessionGitDiffViewer from '$lib/SessionGitDiffViewer.svelte';
	import SessionTerminal from '$lib/SessionTerminal.svelte';
	import { isMarkdownEnabled } from '$lib/chat-render-mode';
	import { loadSessionFilesView, saveSessionFilesView } from '$lib/session-files';
	import {
		captureChatScrollState,
		loadSessionViewStateWithFallback,
		readSessionTabFromUrl,
		resolveChatScrollTop,
		saveSessionViewStateWithFallback,
		toSessionTabHref,
		type ChatScrollState,
		type SessionViewState
	} from '$lib/session-view-state';
	import { createChatScrollRestoreController } from '$lib/chat-scroll-restore';
	import { renderMarkdown } from '$lib/markdown-file-render';
	import { enhanceRenderedMarkdown } from '$lib/rendered-markdown';
	import {
		createDefaultFilesViewState,
		withDefaultFilesViewState,
		type FilesViewState
	} from '$lib/files-view-state';
	import {
		computeReconnectDelay,
		loadSessionSnapshotWithFallback,
		saveSessionSnapshotWithFallback,
		type SessionSnapshot,
		type SessionTab
	} from '$lib/session-recovery';
	import {
		SCRATCH_AUTOSAVE_DELAY_MS,
		createDebouncedScratchSaver,
		loadSessionScratch,
		saveSessionScratch,
		type DebouncedScratchSaver
	} from '$lib/scratchpad';
	import {
		applyWorkingEvent,
		createWorkingIndicatorState
	} from '$lib/working-indicator';
	import { disableSessionViewportMode, enableSessionViewportMode } from '$lib/viewport-mode';
	import { buildSessionDocumentTitle, playCompletionDing } from '$lib/session-attention';
	import { setThemeOverride } from '$lib/theme';
	import { setSkinOverride, type SkinName } from '$lib/skin';
	import { applyReplayMessages } from '$lib/session-replay';
	import { shouldAttemptLifecycleReconnect } from '$lib/session-reconnect';
	import { closeSessionAndReturnHome } from '$lib/close-session';
	import {
		RELOAD_SEMANTIC_WARNING,
		restartSessionViaSlashReload
	} from '$lib/session-reload';
	import { buildCloneSessionPayload } from '$lib/new-session';
	import { getSessionFilesRoot } from '$lib/session-paths';
	import { SESSION_THINKING_LEVELS } from '$lib/thinking-levels';
	import { allowDirenvForDirectory, isDirenvBlockedError } from '$lib/direnv';
	import {
		appendTranscriptToComposerInput,
		arrayBufferToBase64,
		choosePreferredRecordingMimeType,
		isLikelyIOSRecordingEnvironment,
		isVoiceButtonDisabled,
		requestFinalChunkAndStop,
		type VoiceCaptureMode
	} from '$lib/voice-input';
	import {
		formatPlaybackTime,
		getTtsPlaybackState,
		getTtsPrimaryActionLabel,
		getTtsProgressPercent,
		getTtsSeekBackLabel,
		getTtsSeekBackSeconds,
		isTtsPrimaryActionDisabled,
		seekPlaybackTime,
		shouldRenderTtsInlinePlayer
	} from '$lib/tts-playback';
	import {
		computeComposerHeight,
		createMobileComposerFullscreenState,
		enterMobileComposerFullscreenOnFocus,
		exitMobileComposerFullscreen,
		isMobileComposerViewport as matchesMobileComposerViewport,
		resetMobileComposerAutoEnter
	} from '$lib/composer-layout';
	import { normalizeComposerText } from '$lib/composer-text-normalize';
	import { tryCopyTextToClipboard } from '$lib/clipboard';

	const sessionId = $derived(page.params.id);

	// Session metadata
	let session: any = $state(null);

	// Messages
	let messages: any[] = $state([]);

	// Streaming assistant message (in progress)
	let streamingContent = $state('');
	let isStreaming = $state(false);

	// Input
	let inputText = $state('');
	let inputEl: HTMLTextAreaElement | undefined = $state();
	let fileInputEl: HTMLInputElement | undefined = $state();

	type PendingUpload = {
		upload_id: string;
		file_name: string;
		mime_type: string;
		size: number;
		path: string;
	};
	let pendingUploads: PendingUpload[] = $state([]);
	let uploadError = $state('');
	let isDragActive = $state(false);
	let composerMinHeightPx = $state(0);
	let isMobileComposerViewport = $state(false);
	let mobileComposerState = $state(createMobileComposerFullscreenState());

	let voiceMode: VoiceCaptureMode = $state('idle');
	let voiceBusy = $state(false);
	let voiceRecorder: MediaRecorder | null = null;
	let voiceStream: MediaStream | null = null;

	let ttsAudioEl: HTMLAudioElement | null = null;
	let ttsLoadingMessageKey = $state('');
	let ttsActiveMessageKey = $state('');
	let ttsActiveAudioUrl = $state('');
	let ttsPreparedAudioUrls: Record<string, string> = $state({});
	let ttsErrorMessageKey = $state('');
	let ttsErrorText = $state('');
	let ttsIsPlaying = $state(false);
	let ttsCurrentTimeSeconds = $state(0);
	let ttsDurationSeconds = $state(0);

	type BranchCandidate = { entryId: string; text: string };
	let showMessageBranchActions = $state(false);
	let showBranchModal = $state(false);
	let branchLoading = $state(false);
	let branchSubmitting = $state(false);
	let branchError = $state('');
	let branchCandidates: BranchCandidate[] = $state([]);
	let selectedBranchEntryId = $state('');
	let branchName = $state('');
	let showCloneModal = $state(false);
	let cloneSubmitting = $state(false);
	let cloneError = $state('');
	let cloneName = $state('');
	let showCloseModal = $state(false);

	// WebSocket
	let ws: WebSocket | null = $state(null);
	let connected = $state(false);
	let replayed = $state(false);
	let awaitingReplay = $state(false);
	let loading = $state(true);
	let loadError = $state('');
	let reconnectAttempt = $state(0);
	let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
	let intentionalDisconnect = false;
	let resuming = $state(false);
	let closing = $state(false);
	let reloading = $state(false);
	let lastLifecycleReconnectAt = 0;

	// Runtime controls
	const thinkingLevels = SESSION_THINKING_LEVELS;
	let selectedThinking = $state('');
	let working = $state(createWorkingIndicatorState());

	const SESSION_VIEW_STATE_DEBOUNCE_MS = 150;
	const CHAT_SCROLL_RESTORE_SETTLE_MS = 700;

	let activeTab = $state<SessionTab>('chat');
	let filesViewState = $state<FilesViewState>(createDefaultFilesViewState());
	let chatScrollState = $state<ChatScrollState | null>(null);
	let pendingChatScrollRestore = $state<ChatScrollState | null>(null);
	let terminalEverOpened = $state(false);
	let scratchText = $state('');
	let scratchSessionStorageId = $state('');
	let scratchSaveError = $state('');
	let scratchSaver: DebouncedScratchSaver | null = null;
	let suppressChatScrollCapture = false;
	let releaseChatScrollCaptureFrame: number | null = null;
	let persistSessionViewStateTimer: ReturnType<typeof setTimeout> | null = null;
	let chatScrollRestoreController: ReturnType<typeof createChatScrollRestoreController> | null =
		null;
	let chatScrollRestoreRequestId = 0;
	let sessionViewStateReadyForId = $state('');

	$effect(() => {
		if (activeTab === 'terminal') terminalEverOpened = true;
	});
	let awaitingInstructions = $state(false);

	// Scroll ref
	let messagesEl: HTMLDivElement | undefined = $state();

	function ensureChatScrollRestoreController() {
		if (typeof window === 'undefined') return null;
		if (chatScrollRestoreController) return chatScrollRestoreController;
		chatScrollRestoreController = createChatScrollRestoreController(
			{
				requestAnimationFrame: window.requestAnimationFrame.bind(window),
				cancelAnimationFrame: window.cancelAnimationFrame.bind(window),
				setInterval: window.setInterval.bind(window),
				clearInterval: window.clearInterval.bind(window),
				setTimeout: window.setTimeout.bind(window),
				clearTimeout: window.clearTimeout.bind(window)
			},
			{ intervalMs: 120, settleMs: CHAT_SCROLL_RESTORE_SETTLE_MS }
		);
		return chatScrollRestoreController;
	}

	function withSuppressedChatScrollCapture(action: () => void) {
		suppressChatScrollCapture = true;
		if (typeof window === 'undefined') {
			action();
			suppressChatScrollCapture = false;
			return;
		}
		if (releaseChatScrollCaptureFrame !== null) {
			window.cancelAnimationFrame(releaseChatScrollCaptureFrame);
			releaseChatScrollCaptureFrame = null;
		}
		action();
		releaseChatScrollCaptureFrame = window.requestAnimationFrame(() => {
			suppressChatScrollCapture = false;
			releaseChatScrollCaptureFrame = null;
		});
	}

	function applyChatScrollStateToDom(state: ChatScrollState) {
		if (!messagesEl) return;
		withSuppressedChatScrollCapture(() => {
			if (!messagesEl) return;
			messagesEl.scrollTop = resolveChatScrollTop(state, {
				scrollHeight: messagesEl.scrollHeight,
				clientHeight: messagesEl.clientHeight
			});
		});
	}

	function captureCurrentChatScrollState(): ChatScrollState | null {
		if (!messagesEl) return chatScrollState;
		return captureChatScrollState({
			scrollTop: messagesEl.scrollTop,
			scrollHeight: messagesEl.scrollHeight,
			clientHeight: messagesEl.clientHeight
		});
	}

	function captureAndStoreCurrentChatScrollState(): ChatScrollState | null {
		const nextState = captureCurrentChatScrollState();
		if (nextState) {
			chatScrollState = nextState;
		}
		return nextState;
	}

	function clearPersistSessionViewStateTimer() {
		if (persistSessionViewStateTimer) {
			clearTimeout(persistSessionViewStateTimer);
			persistSessionViewStateTimer = null;
		}
	}

	function canPersistSessionViewState(pifaceId: string): boolean {
		return !!pifaceId && sessionViewStateReadyForId === pifaceId;
	}

	function cancelPendingChatScrollRestore() {
		chatScrollRestoreRequestId += 1;
		chatScrollRestoreController?.cancel();
	}

	function persistSessionViewStateNow(options: { captureChatScroll?: boolean } = {}) {
		if (typeof window === 'undefined') return;
		const pifaceId = resolveSessionId();
		if (!canPersistSessionViewState(pifaceId)) return;
		if (options.captureChatScroll && activeTab === 'chat') {
			captureAndStoreCurrentChatScrollState();
		}
		const nextState: SessionViewState = {
			activeTab,
			filesView: filesViewState,
			timestamp: Date.now()
		};
		if (chatScrollState) {
			nextState.chatScroll = chatScrollState;
		}
		if (inputText !== '') {
			nextState.composerDraft = inputText;
		}
		saveSessionViewStateWithFallback(
			window.sessionStorage,
			window.localStorage,
			pifaceId,
			nextState
		);
	}

	function schedulePersistSessionViewState(options: { captureChatScroll?: boolean } = {}) {
		if (typeof window === 'undefined') return;
		const pifaceId = resolveSessionId();
		if (!canPersistSessionViewState(pifaceId)) return;
		if (options.captureChatScroll && activeTab === 'chat') {
			captureAndStoreCurrentChatScrollState();
		}
		if (persistSessionViewStateTimer) return;
		persistSessionViewStateTimer = window.setTimeout(() => {
			persistSessionViewStateTimer = null;
			persistSessionViewStateNow();
		}, SESSION_VIEW_STATE_DEBOUNCE_MS);
	}

	function flushPersistSessionViewState(options: { captureChatScroll?: boolean } = {}) {
		clearPersistSessionViewStateTimer();
		persistSessionViewStateNow(options);
	}

	function restorePendingChatScrollState() {
		if (typeof window === 'undefined') return;
		if (activeTab !== 'chat' || !messagesEl || !pendingChatScrollRestore) return;

		cancelPendingChatScrollRestore();
		const requestId = chatScrollRestoreRequestId;
		const stateToRestore = pendingChatScrollRestore;
		void tick().then(() => {
			if (requestId !== chatScrollRestoreRequestId || !pendingChatScrollRestore) return;
			const controller = ensureChatScrollRestoreController();
			if (!controller) return;
			controller.start({
				apply: () => {
					if (activeTab !== 'chat' || !messagesEl) {
						controller.cancel();
						return;
					}
					applyChatScrollStateToDom(stateToRestore);
				},
				onSettled: () => {
					captureAndStoreCurrentChatScrollState();
					pendingChatScrollRestore = null;
					flushPersistSessionViewState();
				}
			});
		});
	}

	function syncActiveTabUrl(tab: SessionTab) {
		if (typeof window === 'undefined') return;
		const nextHref = toSessionTabHref(window.location.href, tab);
		const currentHref = `${window.location.pathname}${window.location.search}${window.location.hash}`;
		if (nextHref === currentHref) return;
		window.history.replaceState(window.history.state, '', nextHref);
	}

	function selectTab(nextTab: SessionTab) {
		if (activeTab === nextTab) return;
		if (activeTab === 'chat') {
			captureAndStoreCurrentChatScrollState();
		}
		if (nextTab !== 'chat') {
			cancelPendingChatScrollRestore();
		} else if (chatScrollState) {
			pendingChatScrollRestore = chatScrollState;
		}
		activeTab = nextTab;
	}

	function onMessagesScroll() {
		if (suppressChatScrollCapture) return;
		cancelPendingChatScrollRestore();
		pendingChatScrollRestore = null;
		captureAndStoreCurrentChatScrollState();
		schedulePersistSessionViewState();
	}

	function scrollToBottom(options: { preservePendingRestore?: boolean } = {}) {
		if (options.preservePendingRestore && pendingChatScrollRestore) {
			tick().then(() => {
				restorePendingChatScrollState();
			});
			return;
		}
		const nextState: ChatScrollState = { mode: 'bottom' };
		chatScrollState = nextState;
		tick().then(() => {
			if (activeTab === 'chat') {
				applyChatScrollStateToDom(nextState);
			}
		});
	}

	function resolveComposerMinHeight(textarea: HTMLTextAreaElement): number {
		if (typeof window === 'undefined') {
			return 56;
		}
		const styles = window.getComputedStyle(textarea);
		const rows = Number.parseInt(textarea.getAttribute('rows') || '2', 10);
		const lineHeight = Number.parseFloat(styles.lineHeight) || 22;
		const paddingTop = Number.parseFloat(styles.paddingTop) || 0;
		const paddingBottom = Number.parseFloat(styles.paddingBottom) || 0;
		const borderTop = Number.parseFloat(styles.borderTopWidth) || 0;
		const borderBottom = Number.parseFloat(styles.borderBottomWidth) || 0;
		return Math.ceil(lineHeight * rows + paddingTop + paddingBottom + borderTop + borderBottom);
	}

	function updateComposerHeight() {
		if (!inputEl || typeof window === 'undefined') return;
		if (composerMinHeightPx <= 0) {
			composerMinHeightPx = resolveComposerMinHeight(inputEl);
		}

		inputEl.style.height = 'auto';
		const { height, isClamped } = computeComposerHeight({
			scrollHeight: inputEl.scrollHeight,
			minHeight: composerMinHeightPx,
			viewportHeight: window.innerHeight
		});
		inputEl.style.height = `${height}px`;
		inputEl.style.overflowY = isClamped ? 'auto' : 'hidden';
	}

	function collapseMobileComposer(): void {
		mobileComposerState = exitMobileComposerFullscreen(mobileComposerState);
	}

	function enterMobileComposerFullscreenMode() {
		if (!isMobileComposerViewport) return;
		mobileComposerState = {
			...mobileComposerState,
			isFullscreen: true
		};
		tick().then(() => {
			inputEl?.focus();
			updateComposerHeight();
		});
	}

	function exitMobileComposerFullscreenMode() {
		mobileComposerState = exitMobileComposerFullscreen(mobileComposerState);
		tick().then(() => {
			inputEl?.focus();
			updateComposerHeight();
		});
	}

	function onComposerFocus() {
		mobileComposerState = enterMobileComposerFullscreenOnFocus(
			mobileComposerState,
			isMobileComposerViewport
		);
		updateComposerHeight();
	}

	function onComposerBlur() {
		mobileComposerState = resetMobileComposerAutoEnter(mobileComposerState);
	}

	function syncComposerViewportMode() {
		if (typeof window === 'undefined') return;
		const nextIsMobile = matchesMobileComposerViewport(window.innerWidth);
		isMobileComposerViewport = nextIsMobile;
		if (!nextIsMobile && mobileComposerState.isFullscreen) {
			collapseMobileComposer();
		}
	}

	function wait(ms: number): Promise<void> {
		return new Promise((resolve) => setTimeout(resolve, ms));
	}

	function resolveWorkspaceThemeOverride(value: unknown): 'light' | 'dark' | null {
		return value === 'light' || value === 'dark' ? value : null;
	}

	function resolveWorkspaceSkinOverride(value: unknown): SkinName | null {
		return (
			value === 'default' ||
			value === 'beos' ||
			value === 'facebook2007' ||
			value === 'nintendo' ||
			value === 'nintendo-nes' ||
			value === 'windows98' ||
			value === 'winamp' ||
			value === 'protoss' ||
			value === 'terran' ||
			value === 'zerg' ||
			value === 'synthwave' ||
			value === 'macos8'
		)
			? value
			: null;
	}

	async function loadSessionState(pifaceId: string): Promise<boolean> {
		for (let attempt = 0; attempt < 5; attempt += 1) {
			try {
				const resp = await fetch(`/api/sessions/${encodeURIComponent(pifaceId)}`);
				if (resp.ok) {
					session = await resp.json();
					selectedThinking = session?.thinking_level ?? '';
					return true;
				}

				if (resp.status === 404 && attempt < 4) {
					await wait(120);
					continue;
				}

				loadError = resp.status === 404 ? 'Session not found.' : `Failed to load session (${resp.status}).`;
				return false;
			} catch {
				if (attempt < 4) {
					await wait(120);
					continue;
				}
				loadError = 'Failed to load session metadata.';
				return false;
			}
		}

		loadError = 'Session not found.';
		return false;
	}

	async function loadArchivedHistory(pifaceId: string): Promise<void> {
		try {
			const resp = await fetch(`/api/sessions/${encodeURIComponent(pifaceId)}/history`);
			if (!resp.ok) {
				loadError = `Failed to load archived history (${resp.status}).`;
				return;
			}
			const data = await resp.json();
			messages = data.messages ?? [];
			replayed = true;
			isStreaming = false;
			streamingContent = '';
			if (data.error && data.error !== 'missing_session_file') {
				loadError = `Could not fully load history: ${data.error}`;
			}
			scrollToBottom({ preservePendingRestore: true });
		} catch {
			loadError = 'Failed to load archived history.';
		}
	}

	function clearReconnectTimer() {
		if (reconnectTimer) {
			clearTimeout(reconnectTimer);
			reconnectTimer = null;
		}
	}

	function disconnect() {
		intentionalDisconnect = true;
		clearReconnectTimer();
		if (voiceMode !== 'idle') {
			stopVoiceCapture();
		}
		cleanupVoiceCapture();
		voiceBusy = false;
		if (ws) {
			ws.close();
			ws = null;
		}
		connected = false;
		awaitingReplay = false;
		working = createWorkingIndicatorState();
	}

	function isDocumentVisible(): boolean {
		if (typeof document === 'undefined') return true;
		return document.visibilityState === 'visible';
	}

	function scheduleReconnect(pifaceId: string, immediate = false) {
		if (intentionalDisconnect || session?.status !== 'live') return;
		if (ws || reconnectTimer) return;
		if (!immediate && !isDocumentVisible()) return;
		const delay = immediate ? 0 : computeReconnectDelay(reconnectAttempt);
		reconnectTimer = setTimeout(() => {
			reconnectTimer = null;
			connect(pifaceId, true);
		}, delay);
	}

	function connect(pifaceId: string, isReconnect = false) {
		if (ws) {
			intentionalDisconnect = true;
			ws.close();
			ws = null;
		}
		clearReconnectTimer();
		intentionalDisconnect = false;

		const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
		const url = `${proto}//${location.host}/ws/sessions/${encodeURIComponent(pifaceId)}`;
		const socket = new WebSocket(url);

		socket.onopen = () => {
			connected = true;
			reconnectAttempt = 0;
			awaitingReplay = true;
			socket.send(JSON.stringify({ type: 'piface_get_history' }));
		};

		socket.onclose = () => {
			const wasIntentional = intentionalDisconnect;
			connected = false;
			ws = null;
			if (!wasIntentional) {
				reconnectAttempt += 1;
				scheduleReconnect(pifaceId, false);
			}
		};

		socket.onerror = () => {
			connected = false;
		};

		socket.onmessage = (event) => {
			const data = JSON.parse(event.data);
			handleEvent(data);
		};

		ws = socket;
		if (isReconnect) {
			awaitingReplay = true;
		}
	}

	function toBase64(file: File): Promise<string> {
		return new Promise((resolve, reject) => {
			const reader = new FileReader();
			reader.onload = () => {
				const value = typeof reader.result === 'string' ? reader.result : '';
				const comma = value.indexOf(',');
				resolve(comma >= 0 ? value.slice(comma + 1) : value);
			};
			reader.onerror = () => reject(new Error('Failed to read file'));
			reader.readAsDataURL(file);
		});
	}

	async function uploadSelectedFiles(files: File[]) {
		if (!session || session.status === 'closed' || !sessionId) return;
		uploadError = '';
		try {
			const payloadFiles = await Promise.all(
				files.map(async (file) => ({
					file_name: file.name,
					mime_type: file.type || 'application/octet-stream',
					data: await toBase64(file)
				}))
			);

			const resp = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/uploads`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ files: payloadFiles })
			});

			if (!resp.ok) {
				const body = await resp.json().catch(() => ({}));
				uploadError = body.detail ?? `Upload failed (${resp.status})`;
				return;
			}

			const data = await resp.json();
			pendingUploads = [...pendingUploads, ...(data.uploads ?? [])];
		} catch {
			uploadError = 'Upload failed.';
		} finally {
			if (fileInputEl) fileInputEl.value = '';
		}
	}

	function removePendingUpload(uploadId: string) {
		pendingUploads = pendingUploads.filter((u) => u.upload_id !== uploadId);
	}

	async function onSelectFiles(e: Event) {
		const input = e.currentTarget as HTMLInputElement;
		const files = collectFilesFromTransfer<File>({ files: input.files });
		if (!files.length) return;
		await uploadSelectedFiles(files);
	}

	function canAcceptFileTransfer(transfer: DataTransfer | null): boolean {
		if (!transfer) return false;
		if (!session || session.status === 'closed') return false;
		return collectFilesFromTransfer<File>(transfer).length > 0;
	}

	function onDragEnter(e: DragEvent) {
		if (canAcceptFileTransfer(e.dataTransfer)) {
			isDragActive = true;
		}
	}

	function onDragOver(e: DragEvent) {
		if (!canAcceptFileTransfer(e.dataTransfer)) return;
		e.preventDefault();
		if (e.dataTransfer) {
			e.dataTransfer.dropEffect = 'copy';
		}
		isDragActive = true;
	}

	function onDragLeave(e: DragEvent) {
		const current = e.currentTarget as HTMLElement;
		const next = e.relatedTarget as Node | null;
		if (next && current.contains(next)) {
			return;
		}
		isDragActive = false;
	}

	async function onDropFiles(e: DragEvent) {
		if (!canAcceptFileTransfer(e.dataTransfer)) {
			isDragActive = false;
			return;
		}
		e.preventDefault();
		isDragActive = false;
		const files = collectFilesFromTransfer<File>(e.dataTransfer);
		if (!files.length) return;
		await uploadSelectedFiles(files);
	}

	async function onPasteFiles(e: ClipboardEvent) {
		if (!session || session.status === 'closed') return;
		const files = collectFilesFromTransfer<File>(e.clipboardData);
		if (!files.length) return;
		e.preventDefault();
		await uploadSelectedFiles(files);
	}

	function cleanupVoiceCapture() {
		if (voiceRecorder) {
			voiceRecorder.ondataavailable = null;
			voiceRecorder.onstop = null;
			voiceRecorder.onerror = null;
			voiceRecorder = null;
		}
		if (voiceStream) {
			for (const track of voiceStream.getTracks()) {
				track.stop();
			}
			voiceStream = null;
		}
		voiceMode = 'idle';
	}

	function resolveAssistantTtsMessageKey(msg: any, index: number): string {
		const candidate = msg?.id ?? msg?.entryId;
		if (typeof candidate === 'string' && candidate.trim()) {
			return `assistant-${candidate}`;
		}
		return `assistant-${index}`;
	}

	function hasSpeakableAssistantText(msg: any): boolean {
		return !!getMessageText(msg).trim();
	}

	function clearActiveTtsSelection() {
		ttsActiveMessageKey = '';
		ttsActiveAudioUrl = '';
		ttsIsPlaying = false;
		ttsCurrentTimeSeconds = 0;
		ttsDurationSeconds = 0;
	}

	function cleanupTtsPlayback() {
		if (ttsAudioEl) {
			ttsAudioEl.pause();
			ttsAudioEl.onplay = null;
			ttsAudioEl.onpause = null;
			ttsAudioEl.onended = null;
			ttsAudioEl.onerror = null;
			ttsAudioEl.ontimeupdate = null;
			ttsAudioEl.onloadedmetadata = null;
			ttsAudioEl.removeAttribute('src');
			ttsAudioEl.load();
			ttsAudioEl = null;
		}
		ttsLoadingMessageKey = '';
		ttsErrorMessageKey = '';
		ttsErrorText = '';
		clearActiveTtsSelection();
	}

	function ensureTtsAudioElement(): HTMLAudioElement | null {
		if (typeof Audio === 'undefined') {
			return null;
		}
		if (ttsAudioEl) {
			return ttsAudioEl;
		}

		const audio = new Audio();
		audio.preload = 'auto';
		audio.onplay = () => {
			ttsIsPlaying = true;
		};
		audio.onpause = () => {
			ttsIsPlaying = false;
			ttsCurrentTimeSeconds = Number.isFinite(audio.currentTime) ? audio.currentTime : 0;
		};
		audio.onended = () => {
			ttsIsPlaying = false;
			if (Number.isFinite(audio.duration)) {
				ttsDurationSeconds = audio.duration;
			}
			try {
				audio.currentTime = 0;
			} catch {
				// ignore reset failures from the browser media element
			}
			ttsCurrentTimeSeconds = 0;
		};
		audio.onerror = () => {
			ttsIsPlaying = false;
			if (ttsActiveMessageKey) {
				ttsErrorMessageKey = ttsActiveMessageKey;
				ttsErrorText = 'Speech playback failed in this browser.';
			}
		};
		audio.ontimeupdate = () => {
			ttsCurrentTimeSeconds = Number.isFinite(audio.currentTime) ? audio.currentTime : 0;
		};
		audio.onloadedmetadata = () => {
			ttsDurationSeconds = Number.isFinite(audio.duration) ? audio.duration : 0;
		};
		ttsAudioEl = audio;
		return audio;
	}

	async function prepareTtsAudioUrl(text: string): Promise<string> {
		const id = resolveSessionId();
		if (!id || !session) {
			throw new Error('Session is not available for speech playback.');
		}

		const resp = await fetch(`/api/sessions/${encodeURIComponent(id)}/tts`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ text })
		});
		if (!resp.ok) {
			const body = await resp.json().catch(() => ({}));
			throw new Error(body.detail ?? `Text-to-speech failed (${resp.status})`);
		}

		const data = await resp.json();
		if (typeof data.audio_url !== 'string' || !data.audio_url) {
			throw new Error('Text-to-speech returned an invalid audio URL.');
		}
		return data.audio_url;
	}

	async function toggleAssistantSpeech(messageKey: string, text: string) {
		const audio = ensureTtsAudioElement();
		if (!audio) {
			ttsErrorMessageKey = messageKey;
			ttsErrorText = 'Speech playback is not supported in this browser.';
			return;
		}

		const normalizedText = text.trim();
		if (!normalizedText) {
			return;
		}
		if (ttsLoadingMessageKey) {
			return;
		}

		ttsErrorMessageKey = '';
		ttsErrorText = '';

		if (ttsActiveMessageKey === messageKey && ttsActiveAudioUrl) {
			if (audio.paused) {
				try {
					await audio.play();
				} catch (error: any) {
					ttsErrorMessageKey = messageKey;
					ttsErrorText = error?.message || 'Speech playback failed.';
				}
			} else {
				audio.pause();
			}
			return;
		}

		if (ttsActiveMessageKey && ttsActiveMessageKey !== messageKey) {
			audio.pause();
			clearActiveTtsSelection();
		}

		let audioUrl = ttsPreparedAudioUrls[messageKey];
		if (!audioUrl) {
			ttsLoadingMessageKey = messageKey;
			try {
				audioUrl = await prepareTtsAudioUrl(normalizedText);
				ttsPreparedAudioUrls = {
					...ttsPreparedAudioUrls,
					[messageKey]: audioUrl
				};
			} catch (error: any) {
				ttsErrorMessageKey = messageKey;
				ttsErrorText = error?.message || 'Text-to-speech failed.';
				return;
			} finally {
				ttsLoadingMessageKey = '';
			}
		}

		try {
			audio.pause();
			ttsActiveMessageKey = messageKey;
			ttsActiveAudioUrl = audioUrl;
			ttsCurrentTimeSeconds = 0;
			ttsDurationSeconds = 0;
			audio.src = audioUrl;
			audio.currentTime = 0;
			await audio.play();
		} catch (error: any) {
			ttsErrorMessageKey = messageKey;
			ttsErrorText = error?.message || 'Speech playback failed.';
		}
	}

	async function restartAssistantSpeech() {
		if (!ttsAudioEl || !ttsActiveAudioUrl) return;
		ttsErrorMessageKey = '';
		ttsErrorText = '';
		try {
			ttsAudioEl.currentTime = 0;
			await ttsAudioEl.play();
		} catch (error: any) {
			ttsErrorMessageKey = ttsActiveMessageKey;
			ttsErrorText = error?.message || 'Speech playback failed.';
		}
	}

	function seekAssistantSpeech(deltaSeconds: number) {
		if (!ttsAudioEl || !ttsActiveAudioUrl) return;
		ttsAudioEl.currentTime = seekPlaybackTime(
			ttsAudioEl.currentTime,
			deltaSeconds,
			Number.isFinite(ttsAudioEl.duration) ? ttsAudioEl.duration : undefined
		);
		ttsCurrentTimeSeconds = Number.isFinite(ttsAudioEl.currentTime) ? ttsAudioEl.currentTime : 0;
	}

	async function transcribeAudioBlob(blob: Blob, cleanWithPi: boolean) {
		const id = resolveSessionId();
		if (!id || !session || session.status === 'closed') {
			return;
		}

		const buffer = await blob.arrayBuffer();
		const payload = {
			audio_base64: arrayBufferToBase64(buffer),
			mime_type: blob.type || 'audio/webm',
			clean_with_pi: cleanWithPi
		};

		const resp = await fetch(`/api/sessions/${encodeURIComponent(id)}/transcribe`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(payload)
		});
		if (!resp.ok) {
			const body = await resp.json().catch(() => ({}));
			throw new Error(body.detail ?? `Transcription failed (${resp.status})`);
		}

		const data = await resp.json();
		const transcript = typeof data.text === 'string' ? data.text : '';
		inputText = appendTranscriptToComposerInput(inputText, transcript);
		tick().then(() => inputEl?.focus());
	}

	function resolveVoiceRecordingEnvironment() {
		if (typeof navigator === 'undefined') {
			return {};
		}
		return {
			userAgent: navigator.userAgent,
			maxTouchPoints: navigator.maxTouchPoints ?? 0
		};
	}

	async function startVoiceCapture(mode: Exclude<VoiceCaptureMode, 'idle'>) {
		if (voiceBusy || voiceMode !== 'idle') return;
		if (!session || session.status === 'closed' || !connected) return;
		if (typeof window === 'undefined' || typeof navigator === 'undefined') return;
		if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
			uploadError = 'Voice recording is not supported in this browser.';
			return;
		}

		uploadError = '';
		voiceBusy = true;
		const cleanWithPi = mode === 'clean';

		try {
			const recordingEnvironment = resolveVoiceRecordingEnvironment();
			const isIOSRecordingEnvironment = isLikelyIOSRecordingEnvironment(recordingEnvironment);
			voiceStream = await navigator.mediaDevices.getUserMedia({ audio: true });
			const mimeType = choosePreferredRecordingMimeType(
				(value) =>
					typeof MediaRecorder.isTypeSupported === 'function'
						? MediaRecorder.isTypeSupported(value)
						: false,
				recordingEnvironment
			);
			voiceRecorder = mimeType
				? new MediaRecorder(voiceStream, { mimeType })
				: new MediaRecorder(voiceStream);

			const chunks: Blob[] = [];
			voiceRecorder.ondataavailable = (event) => {
				if (event.data.size > 0) {
					chunks.push(event.data);
				}
			};
			voiceRecorder.onerror = () => {
				uploadError = 'Voice recording failed.';
				voiceBusy = false;
				cleanupVoiceCapture();
			};
			voiceRecorder.onstop = async () => {
				try {
					if (isIOSRecordingEnvironment && chunks.length === 0) {
						await new Promise((resolve) => setTimeout(resolve, 180));
					}
					if (chunks.length === 0) {
						throw new Error(
							isIOSRecordingEnvironment
								? 'No audio was captured. On iOS, speak for a moment before stopping and try again.'
								: 'No audio was captured. Please try recording again.'
						);
					}

					const blob = new Blob(chunks, {
						type: voiceRecorder?.mimeType || mimeType || 'audio/webm'
					});
					if (blob.size === 0) {
						throw new Error('No audio was captured. Please try recording again.');
					}
					await transcribeAudioBlob(blob, cleanWithPi);
				} catch (e: any) {
					uploadError = e?.message || 'Voice transcription failed.';
				} finally {
					voiceBusy = false;
					cleanupVoiceCapture();
				}
			};

			if (isIOSRecordingEnvironment) {
				voiceRecorder.start(250);
			} else {
				voiceRecorder.start();
			}
			voiceMode = mode;
		} catch (e: any) {
			uploadError = e?.message || 'Unable to access microphone.';
			voiceBusy = false;
			cleanupVoiceCapture();
		}
	}

	function stopVoiceCapture() {
		if (!voiceRecorder || voiceMode === 'idle') return;
		if (voiceRecorder.state !== 'inactive') {
			const isIOSRecordingEnvironment = isLikelyIOSRecordingEnvironment(
				resolveVoiceRecordingEnvironment()
			);
			voiceMode = 'idle';
			voiceBusy = true;
			try {
				requestFinalChunkAndStop(voiceRecorder, {
					stopDelayMs: isIOSRecordingEnvironment ? 140 : 0
				});
			} catch {
				uploadError = 'Voice recording failed.';
				voiceBusy = false;
				cleanupVoiceCapture();
			}
		}
	}

	function toggleVoiceCapture(mode: Exclude<VoiceCaptureMode, 'idle'>) {
		if (voiceMode === mode) {
			stopVoiceCapture();
			return;
		}
		if (voiceMode !== 'idle') return;
		void startVoiceCapture(mode);
	}

	function handleEvent(data: any) {
		working = applyWorkingEvent(working, data);
		switch (data.type) {
			case 'piface_session_state':
				session = data.session;
				selectedThinking = data.session?.thinking_level ?? '';
				break;

			case 'piface_replay': {
				const shouldHandleReplay = awaitingReplay || !replayed;
				if (shouldHandleReplay) {
					const replayResult = applyReplayMessages(messages, data.messages);
					if (replayResult.changed) {
						messages = replayResult.messages;
						scrollToBottom({ preservePendingRestore: true });
					}
					replayed = true;
					awaitingReplay = false;
				}
				streamingContent = '';
				isStreaming = false;
				break;
			}

			case 'agent_start':
				isStreaming = true;
				streamingContent = '';
				break;

			case 'agent_end':
				// Don't push data.messages here — they've already been added
				// individually via message_end and turn_end events.
				isStreaming = false;
				streamingContent = '';
				playCompletionDing();
				if (typeof document !== 'undefined' && document.visibilityState !== 'visible') {
					awaitingInstructions = true;
				}
				scrollToBottom();
				break;

			case 'message_update': {
				const evt = data.assistantMessageEvent;
				if (evt?.type === 'text_delta') {
					streamingContent += evt.delta;
					scrollToBottom();
				}
				break;
			}

			case 'message_start':
				// A new message is starting
				break;

			case 'message_end':
				// Only add assistant messages — user messages are added locally on send.
				// Pi should only emit message_end for assistant messages, but guard anyway.
				if (data.message && data.message.role !== 'user') {
					messages.push(data.message);
					messages = messages;
					streamingContent = '';
					scrollToBottom();
				}
				break;

			case 'turn_end':
				// Add tool results from this turn (assistant msg already added via message_end)
				if (data.toolResults) {
					for (const tr of data.toolResults) {
						if (tr.role !== 'user') {
							messages.push(tr);
						}
					}
					messages = messages;
					scrollToBottom();
				}
				break;

			case 'tool_execution_start':
			case 'tool_execution_update':
			case 'tool_execution_end':
				// handled by working indicator reducer
				break;

			case 'response': {
				if (data.command === 'bash' && data.success && data.data) {
					const command = typeof data.data.command === 'string' ? data.data.command : '';
					const output = typeof data.data.output === 'string' ? data.data.output : '';
					const exitCode = typeof data.data.exitCode === 'number' ? data.data.exitCode : 0;
					const excluded = data.data.excludeFromContext === true;
					const commandPrefix = command ? `$ ${command}\n` : '';
					const contextNote = excluded ? '\n\n(excluded from model context)' : '';
					const text = `${commandPrefix}${output}${contextNote}`.trimEnd();

					messages.push({
						role: 'toolResult',
						toolName: 'bash',
						isError: exitCode !== 0,
						content: [{ type: 'text', text }]
					});
					messages = messages;
					scrollToBottom();
					break;
				}

				if (!data.success && data.error) {
					console.error('RPC error:', data.error);
				}
				break;
			}

			case 'extension_ui_request':
				// TODO: show extension UI modal
				break;

			case 'piface_error':
				uploadError = data.message ?? 'Request failed.';
				break;

			default:
				break;
		}
	}

	async function copyLastAssistantMessageToClipboard(): Promise<boolean> {
		const text = getLastAssistantMessageText(messages);
		if (!text) {
			uploadError = 'No assistant message available to copy.';
			return false;
		}

		const copied = await tryCopyTextToClipboard(text);
		if (!copied) {
			uploadError = 'Failed to copy to clipboard.';
			return false;
		}
		return true;
	}

	async function runSlashReload(): Promise<void> {
		if (reloading) {
			uploadError = 'Reload already in progress.';
			return;
		}

		const id = resolveSessionId();
		reloading = true;
		try {
			const result = await restartSessionViaSlashReload({
				sessionId: id,
				sessionStatus: session?.status,
				noSession: session?.no_session === true,
				confirmReload: () =>
					typeof window === 'undefined'
						? true
						: window.confirm(RELOAD_SEMANTIC_WARNING),
				onBeforeRestart: disconnect,
				onAfterRestart: async () => {
					await initializeSessionView(id);
				}
			});

			if (!result.ok) {
				if ('error' in result) {
					uploadError = result.error;
				} else if (result.skipped === 'invalid') {
					uploadError = 'Reload is only available for live sessions.';
				}
			}
		} finally {
			reloading = false;
		}
	}

	async function sendPrompt(options: { followUpRequested?: boolean } = {}) {
		const normalizedInput = normalizeComposerText(inputText);
		const text = normalizedInput.trim();
		const uploadIds = pendingUploads.map((u) => u.upload_id);
		const canSend = !!text || uploadIds.length > 0;
		const slashCommand = parseComposerSlashCommand(text);

		uploadError = '';
		if (!canSend) {
			inputText = '';
			return;
		}

		if (slashCommand?.kind === 'copy') {
			inputText = '';
			if (uploadIds.length > 0) {
				uploadError = 'Slash command /copy does not support file attachments.';
				return;
			}
			await copyLastAssistantMessageToClipboard();
			pendingUploads = [];
			collapseMobileComposer();
			tick().then(() => inputEl?.focus());
			return;
		}

		if (slashCommand?.kind === 'compact') {
			inputText = '';
			if (uploadIds.length > 0) {
				uploadError = 'Slash command /compact does not support file attachments.';
				return;
			}
			if (!ws || !connected) {
				uploadError = 'Cannot run /compact while disconnected.';
				return;
			}

			pendingUploads = [];
			awaitingInstructions = false;
			const cmd: any = {
				type: 'compact'
			};
			if (slashCommand.customInstructions) {
				cmd.customInstructions = slashCommand.customInstructions;
			}
			ws.send(JSON.stringify(cmd));
			collapseMobileComposer();
			tick().then(() => inputEl?.focus());
			return;
		}

		if (slashCommand?.kind === 'reload') {
			inputText = '';
			if (uploadIds.length > 0) {
				uploadError = 'Slash command /reload does not support file attachments.';
				return;
			}
			pendingUploads = [];
			awaitingInstructions = false;
			await runSlashReload();
			collapseMobileComposer();
			tick().then(() => inputEl?.focus());
			return;
		}

		inputText = '';
		if (!ws || !connected) return;

		// Mark as replayed so a late-arriving piface_replay doesn't clobber
		replayed = true;

		// Add user message to local display immediately
		const localText =
			text || (uploadIds.length > 0 ? `[attached ${uploadIds.length} file(s)]` : '');
		messages.push({
			role: 'user',
			content: localText,
			timestamp: Date.now()
		});
		messages = messages;
		scrollToBottom();

		const commandType = resolveComposerCommandType({
			isStreaming,
			followUpRequested: !!options.followUpRequested
		});
		const cmd: any = {
			type: commandType,
			message: text,
			piface_upload_ids: uploadIds
		};

		pendingUploads = [];
		awaitingInstructions = false;
		ws.send(JSON.stringify(cmd));
		collapseMobileComposer();
		tick().then(() => inputEl?.focus());
	}

	function sendAbort() {
		if (ws && connected) {
			ws.send(JSON.stringify({ type: 'abort' }));
		}
	}

	async function resumeArchivedSession() {
		const id = resolveSessionId();
		if (!id || session?.status !== 'closed' || resuming) return;
		if (typeof window !== 'undefined') {
			const confirmed = window.confirm('Resume this archived session?');
			if (!confirmed) return;
		}

		resuming = true;
		loadError = '';
		try {
			const submitResume = async () =>
				fetch(`/api/sessions/${encodeURIComponent(id)}/resume`, {
					method: 'POST'
				});
			let resp = await submitResume();

			if (!resp.ok) {
				const body = await resp.json().catch(() => ({}));
				const detail = body.detail ?? `Failed to resume session (${resp.status}).`;
				const detailLower = typeof detail === 'string' ? detail.toLowerCase() : '';

				if (resp.status === 409 && detailLower.includes('already live')) {
					await initializeSessionView(id);
					return;
				}

				if (resp.status === 409 && isDirenvBlockedError(detail) && session?.working_dir) {
					if (typeof window !== 'undefined') {
						const confirmed = window.confirm(
							'This directory has a blocked .envrc. Allow it in this Piface environment and retry resume?'
						);
						if (!confirmed) {
							loadError = detail;
							return;
						}
					}

					const allow = await allowDirenvForDirectory({ workingDir: session.working_dir });
					if (!allow.ok) {
						loadError = allow.error;
						return;
					}

					resp = await submitResume();
				}
			}

			if (!resp.ok) {
				const body = await resp.json().catch(() => ({}));
				const detail = body.detail ?? `Failed to resume session (${resp.status}).`;
				const detailLower = typeof detail === 'string' ? detail.toLowerCase() : '';
				loadError =
					resp.status === 409 && detailLower.includes('ephemeral')
						? 'This session is ephemeral and cannot be resumed.'
						: detail;
				return;
			}
			await initializeSessionView(id);
		} catch {
			loadError = 'Failed to resume session.';
		} finally {
			resuming = false;
		}
	}

	function openCloseModal() {
		if (!session || session.status === 'closed' || loading || closing) return;
		showCloseModal = true;
	}

	function closeCloseModal() {
		if (closing) return;
		showCloseModal = false;
	}

	async function confirmCloseLiveSession() {
		if (closing) return;
		showCloseModal = false;
		await closeLiveSession();
	}

	async function closeLiveSession() {
		const id = resolveSessionId();
		if (!id || !session || session.status === 'closed' || closing) return;

		closing = true;
		loadError = '';
		try {
			const result = await closeSessionAndReturnHome({
				sessionId: id,
				sessionStatus: session.status,
				confirmClose: () => true,
				gotoImpl: goto,
				onBeforeClose: disconnect
			});
			if (!result.ok && 'error' in result) {
				loadError = result.error;
			}
		} catch {
			loadError = 'Failed to close session.';
		} finally {
			closing = false;
		}
	}

	function defaultCloneName(): string {
		const base =
			session?.session_name ||
			(session?.project_dir ?? session?.working_dir)?.split('/').pop() ||
			'session';
		return `${base} copy`;
	}

	function openCloneModal() {
		if (!session || loading) return;
		showCloneModal = true;
		cloneSubmitting = false;
		cloneError = '';
		cloneName = defaultCloneName();
	}

	function closeCloneModal() {
		showCloneModal = false;
		cloneSubmitting = false;
		cloneError = '';
		cloneName = '';
	}

	async function createClonedSession() {
		if (!session || cloneSubmitting) return;
		const workingDir = typeof session.working_dir === 'string' ? session.working_dir.trim() : '';
		if (!workingDir) {
			cloneError = 'Working directory is required.';
			return;
		}

		cloneSubmitting = true;
		cloneError = '';
		try {
			const body = buildCloneSessionPayload(session, cloneName);
			const resp = await fetch('/api/sessions', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify(body)
			});
			const data = await resp.json().catch(() => ({}));
			if (!resp.ok || !data?.piface_id) {
				cloneError = data.detail ?? `Failed to create session (${resp.status}).`;
				return;
			}

			closeCloneModal();
			await goto(`/session/${encodeURIComponent(data.piface_id)}`);
		} catch {
			cloneError = 'Failed to create session.';
		} finally {
			cloneSubmitting = false;
		}
	}

	function defaultBranchName(): string {
		const base =
			session?.session_name ||
			(session?.project_dir ?? session?.working_dir)?.split('/').pop() ||
			'session';
		return `${base} branch`;
	}

	function closeBranchModal() {
		showBranchModal = false;
		branchLoading = false;
		branchSubmitting = false;
		branchError = '';
		branchCandidates = [];
		selectedBranchEntryId = '';
	}

	async function openBranchModal(preferredText = '') {
		const id = resolveSessionId();
		if (!id || !session || session.no_session) return;

		showBranchModal = true;
		branchLoading = true;
		branchSubmitting = false;
		branchError = '';
		branchCandidates = [];
		selectedBranchEntryId = '';
		branchName = defaultBranchName();

		try {
			const resp = await fetch(`/api/sessions/${encodeURIComponent(id)}/fork-messages`);
			if (!resp.ok) {
				const body = await resp.json().catch(() => ({}));
				branchError = body.detail ?? `Failed to load branch points (${resp.status}).`;
				return;
			}

			const data = await resp.json();
			const rows = Array.isArray(data.messages) ? data.messages : [];
			branchCandidates = rows.filter(
				(row: any) => typeof row?.entryId === 'string' && typeof row?.text === 'string'
			);

			if (branchCandidates.length === 0) {
				branchError = 'No user messages are available for branching yet.';
				return;
			}

			if (preferredText) {
				const match = [...branchCandidates].reverse().find((m) => m.text === preferredText);
				if (match) {
					selectedBranchEntryId = match.entryId;
				}
			}
			if (!selectedBranchEntryId) {
				selectedBranchEntryId = branchCandidates[branchCandidates.length - 1].entryId;
			}
		} catch {
			branchError = 'Failed to load branch points.';
		} finally {
			branchLoading = false;
		}
	}

	async function createBranchFromSelection() {
		const id = resolveSessionId();
		if (!id || !selectedBranchEntryId || branchSubmitting) return;

		branchSubmitting = true;
		branchError = '';
		try {
			const resp = await fetch(`/api/sessions/${encodeURIComponent(id)}/branch`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({
					entry_id: selectedBranchEntryId,
					session_name: branchName.trim() || undefined
				})
			});

			const data = await resp.json().catch(() => ({}));
			if (!resp.ok) {
				branchError = data.detail ?? `Failed to branch session (${resp.status}).`;
				return;
			}

			if (data.cancelled || !data.session?.piface_id) {
				branchError = 'Branch creation was cancelled.';
				return;
			}

			const branchedId = data.session.piface_id;
			const prefill = typeof data.selected_text === 'string' ? data.selected_text : '';
			if (typeof window !== 'undefined' && prefill) {
				window.sessionStorage.setItem(`piface_branch_prefill:${branchedId}`, prefill);
			}

			closeBranchModal();
			await goto(`/session/${encodeURIComponent(branchedId)}`);
		} catch {
			branchError = 'Failed to branch session.';
		} finally {
			branchSubmitting = false;
		}
	}

	function consumeBranchPrefill(pifaceId: string) {
		if (typeof window === 'undefined') return;
		const key = `piface_branch_prefill:${pifaceId}`;
		const text = window.sessionStorage.getItem(key);
		if (!text) return;
		window.sessionStorage.removeItem(key);
		if (!inputText.trim()) {
			inputText = text;
		}
	}

	function setThinkingLevel(level: string) {
		if (!ws || !connected) return;
		selectedThinking = level;
		session = { ...(session ?? {}), thinking_level: level || null };
		ws.send(JSON.stringify({ type: 'set_thinking_level', level }));
	}

	async function setRenderMarkdown(enabled: boolean) {
		if (!sessionId || !session) return;
		const previous = isMarkdownEnabled(session);
		session = { ...(session ?? {}), render_markdown: enabled };
		try {
			const res = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}`, {
				method: 'PATCH',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ render_markdown: enabled })
			});
			if (!res.ok) {
				session = { ...(session ?? {}), render_markdown: previous };
				return;
			}
			session = await res.json();
		} catch {
			session = { ...(session ?? {}), render_markdown: previous };
		}
	}

	function renderAssistantHtml(msg: any): string {
		const text = getMessageText(msg);
		if (!text) return '';
		return DOMPurify.sanitize(renderMarkdown(text));
	}

	function onKeydown(e: KeyboardEvent) {
		if (e.key === 'Enter' && !e.shiftKey) {
			e.preventDefault();
			sendPrompt({ followUpRequested: isFollowUpShortcut(e) });
		}
	}

	function isEditableTarget(target: EventTarget | null): boolean {
		if (!(target instanceof HTMLElement)) return false;
		if (target.isContentEditable) return true;
		const tag = target.tagName;
		return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT';
	}

	function onGlobalHotkey(e: KeyboardEvent) {
		if (showBranchModal || showCloneModal) return;
		if (isEditableTarget(e.target)) return;
		if (e.metaKey || e.ctrlKey || e.altKey) return;

		const key = e.key.toLowerCase();
		if (key === 'b') {
			e.preventDefault();
			showMessageBranchActions = !showMessageBranchActions;
			return;
		}

		if (e.key === 'Escape' && showMessageBranchActions) {
			e.preventDefault();
			showMessageBranchActions = false;
		}
	}

	// Extract text from message content
	function getMessageText(msg: any): string {
		if (typeof msg.content === 'string') return msg.content;
		if (Array.isArray(msg.content)) {
			return msg.content
				.filter((c: any) => c.type === 'text')
				.map((c: any) => c.text)
				.join('');
		}
		return '';
	}

	// Extract thinking from assistant message
	function getThinking(msg: any): string {
		if (!Array.isArray(msg.content)) return '';
		return msg.content
			.filter((c: any) => c.type === 'thinking')
			.map((c: any) => c.thinking)
			.join('');
	}

	// Extract tool calls from assistant message
	function getToolCalls(msg: any): any[] {
		if (!Array.isArray(msg.content)) return [];
		return msg.content.filter((c: any) => c.type === 'toolCall');
	}

	function handleFilesViewStateChange(nextState: FilesViewState) {
		filesViewState = nextState;
		if (typeof window === 'undefined') return;
		const pifaceId = resolveSessionId();
		if (!pifaceId) return;
		try {
			saveSessionFilesView(window.sessionStorage, pifaceId, nextState);
		} catch {
			// Ignore transient browser storage failures.
		}
	}

	function flushAndDisposeScratchSaver() {
		if (!scratchSaver) return;
		scratchSaver.flush();
		scratchSaver.cancel();
		scratchSaver = null;
	}

	function loadScratchForSession(pifaceId: string) {
		scratchSessionStorageId = pifaceId;
		scratchSaveError = '';
		if (typeof window === 'undefined') {
			scratchText = '';
			return;
		}
		try {
			scratchText = loadSessionScratch(window.localStorage, pifaceId);
		} catch {
			scratchText = '';
			scratchSaveError = 'Scratch storage is unavailable in this browser.';
		}
	}

	function setupScratchAutosave(pifaceId: string) {
		flushAndDisposeScratchSaver();
		if (typeof window === 'undefined') return;

		scratchSaver = createDebouncedScratchSaver({
			delayMs: SCRATCH_AUTOSAVE_DELAY_MS,
			onSave: (text: string) => {
				try {
					saveSessionScratch(window.localStorage, pifaceId, text);
					scratchSaveError = '';
				} catch {
					scratchSaveError = 'Failed to save scratch text in browser storage.';
				}
			}
		});
	}

	function tryRestoreSnapshot(pifaceId: string): boolean {
		if (typeof window === 'undefined') return false;
		let snapshot: SessionSnapshot | null = null;
		try {
			snapshot = loadSessionSnapshotWithFallback(
				window.sessionStorage,
				window.localStorage,
				pifaceId
			);
		} catch {
			snapshot = null;
		}
		if (!snapshot) return false;
		session = snapshot.session;
		messages = snapshot.messages;
		activeTab = snapshot.activeTab;
		filesViewState = withDefaultFilesViewState(snapshot.filesView);
		replayed = true;
		return true;
	}

	async function initializeSessionView(pifaceId: string) {
		sessionViewStateReadyForId = '';
		activeTab = 'chat';
		filesViewState = createDefaultFilesViewState();
		chatScrollState = null;
		pendingChatScrollRestore = null;
		inputText = '';
		clearPersistSessionViewStateTimer();
		cancelPendingChatScrollRestore();

		const hadSnapshot = tryRestoreSnapshot(pifaceId);
		const persistedViewState =
			typeof window === 'undefined'
				? null
				: (() => {
					try {
						return loadSessionViewStateWithFallback(
							window.sessionStorage,
							window.localStorage,
							pifaceId
						);
					} catch {
						return null;
					}
				})();
		const persistedFilesView =
			typeof window === 'undefined'
				? null
				: (() => {
					try {
						return loadSessionFilesView(window.sessionStorage, pifaceId);
					} catch {
						return null;
					}
				})();
		const requestedTab =
			typeof window === 'undefined' ? null : readSessionTabFromUrl(window.location.href);

		activeTab = requestedTab ?? persistedViewState?.activeTab ?? activeTab;
		filesViewState = withDefaultFilesViewState(
			persistedViewState?.filesView ?? persistedFilesView ?? filesViewState
		);
		chatScrollState = persistedViewState?.chatScroll ?? chatScrollState;
		pendingChatScrollRestore = persistedViewState?.chatScroll ?? null;
		inputText = persistedViewState?.composerDraft ?? '';

		setupScratchAutosave(pifaceId);
		loadScratchForSession(pifaceId);
		loading = !hadSnapshot;
		loadError = '';
		if (!hadSnapshot) {
			session = null;
			messages = [];
			replayed = false;
			activeTab = requestedTab ?? persistedViewState?.activeTab ?? 'chat';
			filesViewState = withDefaultFilesViewState(
				persistedViewState?.filesView ?? persistedFilesView
			);
		}
		streamingContent = '';
		isStreaming = false;
		awaitingReplay = false;
		pendingUploads = [];
		uploadError = '';
		isDragActive = false;
		showMessageBranchActions = false;
		showCloseModal = false;
		awaitingInstructions = false;
		composerMinHeightPx = 0;
		mobileComposerState = createMobileComposerFullscreenState();
		disconnect();
		reconnectAttempt = 0;
		lastLifecycleReconnectAt = 0;
		intentionalDisconnect = false;

		const ok = await loadSessionState(pifaceId);
		if (!ok) {
			loading = false;
			return;
		}

		if (session?.status === 'live') {
			connect(pifaceId);
		} else {
			await loadArchivedHistory(pifaceId);
		}
		loading = false;
		consumeBranchPrefill(pifaceId);
		sessionViewStateReadyForId = pifaceId;
		flushPersistSessionViewState();
	}

	function resolveSessionId(): string {
		if (sessionId) {
			return sessionId;
		}
		if (typeof window === 'undefined') {
			return '';
		}
		const tail = window.location.pathname.split('/').filter(Boolean).pop() ?? '';
		return decodeURIComponent(tail);
	}

	let initializedForId = $state('');

	$effect(() => {
		const currentId = resolveSessionId();
		if (!currentId || currentId === initializedForId) {
			return;
		}
		initializedForId = currentId;
		void initializeSessionView(currentId);
	});

	$effect(() => {
		if (typeof window === 'undefined') return;
		syncActiveTabUrl(activeTab);
	});

	$effect(() => {
		if (typeof window === 'undefined') return;
		const currentId = resolveSessionId();
		if (!currentId) return;
		activeTab;
		filesViewState;
		chatScrollState;
		schedulePersistSessionViewState();
	});

	$effect(() => {
		pendingChatScrollRestore;
		activeTab;
		messagesEl;
		loading;
		if (loading) return;
		if (activeTab !== 'chat' || !messagesEl || !pendingChatScrollRestore) return;
		restorePendingChatScrollState();
	});

	$effect(() => {
		if (typeof window === 'undefined' || !sessionId) return;
		if (loading || !session) return;
		const snapshot: SessionSnapshot = {
			sessionId,
			session,
			messages,
			activeTab,
			filesView: filesViewState,
			timestamp: Date.now()
		};
		try {
			saveSessionSnapshotWithFallback(window.sessionStorage, window.localStorage, snapshot);
		} catch {
			// ignore storage write failures (private mode/quota/blocked)
		}
	});

	$effect(() => {
		setThemeOverride(resolveWorkspaceThemeOverride(session?.workspace_theme_override));
		setSkinOverride(resolveWorkspaceSkinOverride(session?.workspace_skin_override));
	});

	$effect(() => {
		scratchText;
		scratchSessionStorageId;
		if (!scratchSaver || !scratchSessionStorageId) return;
		scratchSaver.schedule(scratchText);
	});

	$effect(() => {
		inputText;
		if (typeof window !== 'undefined') {
			if (inputText === '') {
				flushPersistSessionViewState();
			} else {
				schedulePersistSessionViewState();
			}
		}
		tick().then(updateComposerHeight);
	});

	$effect(() => {
		if (activeTab !== 'chat' && mobileComposerState.isFullscreen) {
			collapseMobileComposer();
		}
	});

	onMount(() => {
		enableSessionViewportMode();

		const refreshLiveConnection = () => {
			const id = resolveSessionId();
			if (!id) return;
			const nowMs = Date.now();
			const isOnline = typeof navigator === 'undefined' ? true : navigator.onLine;
			if (
				!shouldAttemptLifecycleReconnect({
					sessionStatus: session?.status,
					connected,
					hasSocket: Boolean(ws),
					isVisible: isDocumentVisible(),
					isOnline,
					nowMs,
					lastAttemptAtMs: lastLifecycleReconnectAt
				})
			) {
				return;
			}
			lastLifecycleReconnectAt = nowMs;
			scheduleReconnect(id, false);
		};

		const onVisibility = () => {
			if (document.visibilityState !== 'visible') {
				flushPersistSessionViewState({ captureChatScroll: true });
				scratchSaver?.flush();
				return;
			}
			awaitingInstructions = false;
			refreshLiveConnection();
		};
		const onPageShow = () => {
			if (!isDocumentVisible()) return;
			awaitingInstructions = false;
			refreshLiveConnection();
		};
		const onPageHide = () => {
			flushPersistSessionViewState({ captureChatScroll: true });
			scratchSaver?.flush();
		};
		const onOnline = () => {
			if (!isDocumentVisible()) return;
			refreshLiveConnection();
		};
		const onResize = () => {
			syncComposerViewportMode();
			updateComposerHeight();
		};

		syncComposerViewportMode();
		tick().then(updateComposerHeight);

		document.addEventListener('visibilitychange', onVisibility);
		window.addEventListener('pageshow', onPageShow);
		window.addEventListener('pagehide', onPageHide);
		window.addEventListener('online', onOnline);
		window.addEventListener('keydown', onGlobalHotkey);
		window.addEventListener('resize', onResize);
		window.visualViewport?.addEventListener('resize', onResize);

		return () => {
			document.removeEventListener('visibilitychange', onVisibility);
			window.removeEventListener('pageshow', onPageShow);
			window.removeEventListener('pagehide', onPageHide);
			window.removeEventListener('online', onOnline);
			window.removeEventListener('keydown', onGlobalHotkey);
			window.removeEventListener('resize', onResize);
			window.visualViewport?.removeEventListener('resize', onResize);
			disableSessionViewportMode();
		};
	});

	onDestroy(() => {
		flushPersistSessionViewState({ captureChatScroll: true });
		clearPersistSessionViewStateTimer();
		cancelPendingChatScrollRestore();
		if (typeof window !== 'undefined' && releaseChatScrollCaptureFrame !== null) {
			window.cancelAnimationFrame(releaseChatScrollCaptureFrame);
			releaseChatScrollCaptureFrame = null;
		}
		disconnect();
		cleanupTtsPlayback();
		flushAndDisposeScratchSaver();
		setThemeOverride(null);
		setSkinOverride(null);
	});
</script>

<svelte:head>
	<title>{buildSessionDocumentTitle(session, awaitingInstructions)}</title>
</svelte:head>

<div
	class="session-view"
	class:mobile-compose-fullscreen={
		isMobileComposerViewport && mobileComposerState.isFullscreen && activeTab === 'chat'
	}
>
	<!-- Header -->
	<header>
		<div class="header-top">
			<a href="/" class="back">←</a>
			<h1>{session?.session_name || session?.working_dir?.split('/').pop() || 'Session'}</h1>
			<span class="status-dot" class:live={connected} class:dead={!connected} class:archived={session?.status === 'closed'}></span>
			<button
				type="button"
				class="btn clone-btn"
				onclick={openCloneModal}
				disabled={!session || loading}
				title="Create a new session with this session's defaults"
			>
				New from defaults
			</button>
			<button
				type="button"
				class="btn branch-btn"
				onclick={() => openBranchModal()}
				disabled={!session || session.no_session || loading}
				title={session?.no_session ? 'Ephemeral sessions cannot be branched' : 'Branch from a prior user message'}
			>
				Branch
			</button>
			{#if session?.status !== 'closed'}
				<button
					type="button"
					class="btn close-btn danger"
					onclick={openCloseModal}
					disabled={!session || loading || closing}
					title="Kill this session and return to the homepage"
				>
					{closing ? 'Closing…' : 'Close'}
				</button>
			{/if}
			{#if session?.status === 'closed'}
				<span class="mode-badge archived">Archived</span>
				{#if !session?.no_session}
					<button class="btn resume-btn" onclick={resumeArchivedSession} disabled={resuming}>
						{resuming ? 'Resuming…' : 'Resume'}
					</button>
				{/if}
			{/if}
		</div>
		{#if session}
			<div class="header-meta">
				<span class="meta path">{session.project_dir ?? session.working_dir}</span>
				{#if session.workspace_mode === 'git_worktree' && session.workspace_name}
					<span class="meta model workspace">{session.workspace_name}</span>
				{/if}
				{#if session.workspace_branch}
					<span class="meta model">{session.workspace_branch}</span>
				{/if}
				{#if session.model_id}
					<span class="meta model">{session.model_id}</span>
				{/if}
				<label class="markdown-toggle">
					<input
						type="checkbox"
						checked={isMarkdownEnabled(session)}
						onchange={(e) => setRenderMarkdown((e.currentTarget as HTMLInputElement).checked)}
					/>
					<span>Render Markdown</span>
				</label>
				<label class="thinking-control">
					<span>Thinking</span>
					<select
						value={selectedThinking}
						onchange={(e) => setThinkingLevel((e.currentTarget as HTMLSelectElement).value)}
						disabled={!connected || session?.status === 'closed'}
					>
						{#each thinkingLevels as level}
							<option value={level}>
								{level === '' ? 'Default' : level === 'xhigh' ? 'XHigh' : level[0].toUpperCase() + level.slice(1)}
							</option>
						{/each}
					</select>
				</label>
				{#if !session?.no_session}
					<span class="meta branch-hotkey-hint">Press <kbd>B</kbd> to toggle “Branch from here” actions</span>
				{/if}
			</div>
		{/if}
	</header>

	<nav class="tab-bar" aria-label="Session views">
		<button
			type="button"
			class="tab-button"
			class:active={activeTab === 'chat'}
			onclick={() => selectTab('chat')}
		>
			Chat
		</button>
		<button
			type="button"
			class="tab-button"
			class:active={activeTab === 'files'}
			onclick={() => selectTab('files')}
		>
			Files
		</button>
		<button
			type="button"
			class="tab-button"
			class:active={activeTab === 'diff'}
			onclick={() => selectTab('diff')}
		>
			Diff
		</button>
		<button
			type="button"
			class="tab-button"
			class:active={activeTab === 'terminal'}
			onclick={() => selectTab('terminal')}
		>
			Terminal
		</button>
		<button
			type="button"
			class="tab-button"
			class:active={activeTab === 'scratch'}
			onclick={() => selectTab('scratch')}
		>
			Scratch
		</button>
	</nav>

	{#if activeTab === 'chat'}
		<div class="chat-pane">
			<!-- Messages -->
			<div class="messages" bind:this={messagesEl} onscroll={onMessagesScroll}>
				{#if loading}
					<div class="empty-chat">
						<p>Loading session…</p>
					</div>
				{:else if loadError}
					<div class="empty-chat error-state">
						<p>{loadError}</p>
					</div>
				{:else if messages.length === 0 && !isStreaming}
					<div class="empty-chat">
						<p>{session?.status === 'closed' ? 'No archived messages found for this session.' : 'Send a message to start the conversation.'}</p>
					</div>
				{/if}

				{#each messages as msg, index}
					{#if msg.role === 'user'}
						<div class="msg user">
							<div class="msg-bubble user-bubble">
								<pre class="msg-text">{getMessageText(msg)}</pre>
								{#if !session?.no_session && showMessageBranchActions}
									<div class="msg-actions-row">
										<button
											type="button"
											class="msg-branch-btn"
											onclick={() => openBranchModal(getMessageText(msg))}
										>
											Branch from here
										</button>
									</div>
								{/if}
							</div>
						</div>
					{:else if msg.role === 'assistant'}
						<div class="msg assistant">
							<div class="msg-bubble assistant-bubble">
								{#if getThinking(msg)}
									<details class="thinking">
										<summary>Thinking…</summary>
										<pre class="thinking-text">{getThinking(msg)}</pre>
									</details>
								{/if}
								{#if isMarkdownEnabled(session)}
									<div class="assistant-markdown" use:enhanceRenderedMarkdown={getMessageText(msg)}>{@html renderAssistantHtml(msg)}</div>
								{:else}
									<pre class="msg-text">{getMessageText(msg)}</pre>
								{/if}
								{#if hasSpeakableAssistantText(msg)}
									{@const messageKey = resolveAssistantTtsMessageKey(msg, index)}
									{@const hasPreparedAudio = !!ttsPreparedAudioUrls[messageKey] || (ttsActiveMessageKey === messageKey && !!ttsActiveAudioUrl)}
									{@const playbackState = getTtsPlaybackState({
										messageKey,
										loadingMessageKey: ttsLoadingMessageKey,
										activeMessageKey: ttsActiveMessageKey,
										isPlaying: ttsIsPlaying,
										hasPreparedAudio
									})}
									{@const showInlinePlayer = shouldRenderTtsInlinePlayer({
										messageKey,
										loadingMessageKey: ttsLoadingMessageKey,
										activeMessageKey: ttsActiveMessageKey,
										hasPreparedAudio,
										errorMessageKey: ttsErrorMessageKey
									})}
									{@const isLoadingTts = playbackState === 'loading'}
									{@const progressPercent = getTtsProgressPercent(ttsCurrentTimeSeconds, ttsDurationSeconds)}
									{@const rewindSeconds = getTtsSeekBackSeconds(ttsDurationSeconds)}
									{@const showErrorPanel = ttsErrorMessageKey === messageKey && !hasPreparedAudio && !isLoadingTts}
									<div class="msg-audio-footer" data-state={playbackState}>
										{#if showInlinePlayer}
											<div class="msg-audio-player" data-state={showErrorPanel ? 'error' : playbackState}>
												{#if showErrorPanel}
													<div class="msg-audio-player-row">
														<div class="msg-audio-status">
															<span aria-hidden="true">⚠</span>
															<span>{ttsErrorText}</span>
														</div>
														<button
															type="button"
															class="msg-audio-btn secondary"
															onclick={() => toggleAssistantSpeech(messageKey, getMessageText(msg))}
														>
															Retry
														</button>
													</div>
												{:else}
													<div class="msg-audio-player-row">
														<button
															type="button"
															class="msg-audio-icon-btn"
															onclick={() => toggleAssistantSpeech(messageKey, getMessageText(msg))}
															disabled={isLoadingTts}
															aria-label={playbackState === 'playing' ? 'Pause audio playback' : 'Play audio playback'}
														>
															{#if isLoadingTts}
																<span class="msg-audio-spinner"></span>
															{:else if playbackState === 'playing'}
																⏸
															{:else}
																▶
															{/if}
														</button>
														<div class="msg-audio-track">
															<div class="msg-audio-track-meta">
																<span class="msg-audio-status">
																	{#if isLoadingTts}
																		Generating audio…
																	{:else if playbackState === 'playing'}
																		Now playing
																	{:else}
																		Ready to play
																	{/if}
																</span>
																<span class="msg-audio-time">
																	{#if isLoadingTts}
																		0:00 / --:--
																	{:else}
																		{formatPlaybackTime(ttsCurrentTimeSeconds)} / {formatPlaybackTime(ttsDurationSeconds)}
																	{/if}
																</span>
															</div>
															<div
																class="msg-audio-progress"
																class:is-loading={isLoadingTts}
																role="progressbar"
																aria-label="Audio playback progress"
																aria-valuemin="0"
																aria-valuemax="100"
																aria-valuenow={isLoadingTts ? 0 : progressPercent}
																style={`--tts-progress:${isLoadingTts ? 0 : progressPercent}%`}
															>
																<span class="msg-audio-progress-fill"></span>
															</div>
														</div>
														{#if !isLoadingTts}
															<div class="msg-audio-secondary-actions">
																<button type="button" class="msg-audio-btn secondary" onclick={restartAssistantSpeech}>
																	↺ Restart
																</button>
																{#if rewindSeconds}
																	<button
																		type="button"
																		class="msg-audio-btn secondary"
																		onclick={() => seekAssistantSpeech(-rewindSeconds)}
																	>
																		{getTtsSeekBackLabel(ttsDurationSeconds)}
																	</button>
																{/if}
															</div>
														{/if}
													</div>
													{#if ttsErrorMessageKey === messageKey && ttsErrorText}
														<div class="msg-inline-error msg-inline-error-audio">{ttsErrorText}</div>
													{/if}
												{/if}
											</div>
										{:else}
											<button
												type="button"
												class="msg-audio-trigger"
												data-state={playbackState}
												onclick={() => toggleAssistantSpeech(messageKey, getMessageText(msg))}
												disabled={isTtsPrimaryActionDisabled({
													messageKey,
													loadingMessageKey: ttsLoadingMessageKey
												})}
											>
												<span class="msg-audio-trigger-icon" aria-hidden="true">▶</span>
												<span>{getTtsPrimaryActionLabel({
													messageKey,
													loadingMessageKey: ttsLoadingMessageKey,
													activeMessageKey: ttsActiveMessageKey,
													isPlaying: ttsIsPlaying,
													hasPreparedAudio
												})}</span>
											</button>
										{/if}
									</div>
								{/if}
								{#each getToolCalls(msg) as tool}
									<details class="tool-call">
										<summary>🔧 {tool.name}({Object.keys(tool.arguments || {}).join(', ')})</summary>
										<pre class="tool-args">{JSON.stringify(tool.arguments, null, 2)}</pre>
									</details>
								{/each}
							</div>
						</div>
					{:else if msg.role === 'toolResult'}
						<div class="msg tool-result">
							<details class="tool-result-details">
								<summary>
									{#if msg.isError}❌{:else}✅{/if}
									{msg.toolName}
								</summary>
								<pre class="tool-output">{getMessageText(msg)}</pre>
							</details>
						</div>
					{/if}
				{/each}

				{#if isStreaming && streamingContent}
					<div class="msg assistant">
						<div class="msg-bubble assistant-bubble streaming">
							<pre class="msg-text">{streamingContent}<span class="cursor">▊</span></pre>
						</div>
					</div>
				{/if}
			</div>

			<!-- Input -->
			<div class="input-area">
				{#if isMobileComposerViewport && mobileComposerState.isFullscreen}
					<div class="composer-fullscreen-header">
						<span>Compose</span>
						<button
							type="button"
							class="btn composer-reference-btn"
							onclick={exitMobileComposerFullscreenMode}
						>
							Reference chat
						</button>
					</div>
				{/if}
				{#if working.phase !== 'idle'}
					<div class="working-indicator" aria-live="polite">
						<span class="working-dot" aria-hidden="true"></span>
						<span class="working-label">{working.label}</span>
					</div>
				{/if}

				{#if working.activeTools.length > 0 || working.recentTools.length > 0}
					<div class="tool-progress-list" aria-live="polite">
						{#each working.activeTools as tool (tool.id)}
							<div class="tool-progress-row running">
								<span class="tool-name">🔧 {tool.toolName}</span>
								<span class="tool-status">running…</span>
							</div>
						{/each}
						{#each working.recentTools as tool (tool.id)}
							<div class="tool-progress-row" class:error={tool.status === 'error'}>
								<span class="tool-name">{tool.status === 'error' ? '❌' : '✅'} {tool.toolName}</span>
								<span class="tool-status">{tool.status === 'error' ? 'failed' : 'done'}</span>
							</div>
						{/each}
					</div>
				{/if}

				<div
					class="composer"
					role="group"
					aria-label="Message composer"
					class:drag-active={isDragActive}
					ondragenter={onDragEnter}
					ondragover={onDragOver}
					ondragleave={onDragLeave}
					ondrop={onDropFiles}
				>
					<textarea
						bind:this={inputEl}
						bind:value={inputText}
						oninput={updateComposerHeight}
						onfocus={onComposerFocus}
						onblur={onComposerBlur}
						onkeydown={onKeydown}
						onpaste={onPasteFiles}
						autocapitalize="off"
						autocomplete="off"
						spellcheck="false"
						placeholder={session?.status === 'closed' ? 'Archived session (read-only)' : 'Message… (Enter sends; Shift+Enter newline; Opt/Ctrl/Cmd+Enter follow-up while streaming)'}
						rows="2"
						disabled={!connected || session?.status === 'closed'}
					></textarea>

					{#if isDragActive}
						<div class="drop-hint">Drop files to attach</div>
					{/if}

					{#if pendingUploads.length > 0}
						<div class="upload-chips">
							{#each pendingUploads as upload}
								<button
									type="button"
									class="upload-chip"
									title={upload.path}
									onclick={() => removePendingUpload(upload.upload_id)}
								>
									📎 {upload.file_name} ×
								</button>
							{/each}
						</div>
					{/if}
					{#if uploadError}
						<div class="upload-error">{uploadError}</div>
					{/if}
					{#if voiceMode !== 'idle' || voiceBusy}
						<div class="voice-status">
							{#if voiceMode !== 'idle'}
								Recording… press the same mic button to stop.
							{:else}
								Transcribing audio…
							{/if}
						</div>
					{/if}
				</div>

				<div class="input-actions">
					<input
						bind:this={fileInputEl}
						type="file"
						multiple
						onchange={onSelectFiles}
						hidden
						disabled={!connected || session?.status === 'closed'}
					/>
					{#if isMobileComposerViewport && !mobileComposerState.isFullscreen}
						<button
							type="button"
							class="btn"
							onclick={enterMobileComposerFullscreenMode}
							disabled={!connected || session?.status === 'closed'}
						>
							Fullscreen
						</button>
					{/if}
					<button
						type="button"
						class="btn"
						onclick={() => fileInputEl?.click()}
						disabled={!connected || session?.status === 'closed' || voiceBusy}
					>
						Add files
					</button>
					<button
						type="button"
						class="btn"
						onclick={() => toggleVoiceCapture('transcribe')}
						disabled={isVoiceButtonDisabled({
							connected,
							sessionClosed: session?.status === 'closed',
							voiceBusy,
							voiceMode,
							buttonMode: 'transcribe'
						})}
					>
						{voiceMode === 'transcribe' ? 'Stop Mic → Text' : 'Mic → Text'}
					</button>
					<button
						type="button"
						class="btn"
						onclick={() => toggleVoiceCapture('clean')}
						disabled={isVoiceButtonDisabled({
							connected,
							sessionClosed: session?.status === 'closed',
							voiceBusy,
							voiceMode,
							buttonMode: 'clean'
						})}
					>
						{voiceMode === 'clean' ? 'Stop Mic → Clean' : 'Mic → Clean'}
					</button>
					{#if isStreaming}
						<button class="btn danger" onclick={sendAbort}>Abort</button>
					{/if}
					<button
						class="btn primary"
						onclick={() => sendPrompt()}
						disabled={!connected || session?.status === 'closed' || (!inputText.trim() && pendingUploads.length === 0) || voiceBusy}
					>
						Send
					</button>
				</div>
			</div>
		</div>
	{:else if activeTab === 'files'}
		<div class="files-pane">
			{#if getSessionFilesRoot(session)}
				<SessionFileViewer
					rootPath={getSessionFilesRoot(session)}
					initialCurrentPath={filesViewState.currentPath}
					initialSelectedPath={filesViewState.selectedPath}
					initialPreviewFullscreen={filesViewState.previewFullscreen ?? false}
					onStateChange={handleFilesViewStateChange}
				/>
			{:else}
				<div class="empty-chat"><p>Loading files…</p></div>
			{/if}
		</div>
	{:else if activeTab === 'diff'}
		<div class="files-pane">
			{#if session?.working_dir && sessionId}
				<SessionGitDiffViewer sessionId={sessionId} rootPath={session.working_dir} />
			{:else}
				<div class="empty-chat"><p>Loading diff view…</p></div>
			{/if}
		</div>
	{:else if activeTab === 'scratch'}
		<div class="scratch-pane">
			<div class="scratch-hint">Per-session scratchpad. Autosaves in your browser after a short pause.</div>
			<textarea
				class="scratch-editor"
				bind:value={scratchText}
				placeholder="Write notes for this session…"
				spellcheck="false"
			></textarea>
			{#if scratchSaveError}
				<div class="scratch-error">{scratchSaveError}</div>
			{/if}
		</div>
	{/if}

	{#if terminalEverOpened && sessionId}
		<SessionTerminal {sessionId} visible={activeTab === 'terminal'} />
	{/if}

	{#if showCloseModal}
		<div
			class="modal-backdrop"
			onclick={closeCloseModal}
			onkeydown={(e) => {
				if (e.key === 'Escape' || e.key === 'Enter' || e.key === ' ') closeCloseModal();
			}}
			role="button"
			aria-label="Close session confirmation dialog"
			tabindex="0"
		>
			<div
				class="modal-card"
				onclick={(e) => e.stopPropagation()}
				onkeydown={(e) => e.stopPropagation()}
				role="dialog"
				aria-modal="true"
				aria-label="Confirm close session"
				tabindex="-1"
			>
				<h2>Close Session?</h2>
				<p class="modal-copy">This kills the active pi process and returns you to the dashboard.</p>
				<div class="modal-actions">
					<button type="button" class="btn" onclick={closeCloseModal} disabled={closing}>Cancel</button>
					<button type="button" class="btn danger" onclick={confirmCloseLiveSession} disabled={closing}>
						{closing ? 'Closing…' : 'Close session'}
					</button>
				</div>
			</div>
		</div>
	{/if}

	{#if showCloneModal}
		<div
			class="modal-backdrop"
			onclick={closeCloneModal}
			onkeydown={(e) => {
				if (e.key === 'Escape' || e.key === 'Enter' || e.key === ' ') closeCloneModal();
			}}
			role="button"
			aria-label="Close new session dialog"
			tabindex="0"
		>
			<div
				class="modal-card"
				onclick={(e) => e.stopPropagation()}
				onkeydown={(e) => e.stopPropagation()}
				role="dialog"
				aria-modal="true"
				aria-label="New session from defaults"
				tabindex="-1"
			>
				<h2>New Session from Defaults</h2>
				<p class="modal-copy">Create a new session using this session's current defaults and working directory.</p>
				{#if session?.project_dir || session?.working_dir}
					<p class="modal-copy"><strong>Directory:</strong> {session.project_dir ?? session.working_dir}</p>
				{/if}
				{#if session?.workspace_mode === 'git_worktree'}
					<p class="modal-copy modal-info">A new isolated worktree will be created from the current committed state.</p>
				{/if}
				<label class="modal-field">
					<span>New session name (optional)</span>
					<input
						type="text"
						bind:value={cloneName}
						placeholder="my-session-copy"
						disabled={cloneSubmitting}
					/>
				</label>

				{#if cloneError}
					<p class="modal-error">{cloneError}</p>
				{/if}

				<div class="modal-actions">
					<button type="button" class="btn" onclick={closeCloneModal} disabled={cloneSubmitting}>Cancel</button>
					<button type="button" class="btn primary" onclick={createClonedSession} disabled={cloneSubmitting}>
						{cloneSubmitting ? 'Creating…' : 'Create session'}
					</button>
				</div>
			</div>
		</div>
	{/if}

	{#if showBranchModal}
		<div
			class="modal-backdrop"
			onclick={closeBranchModal}
			onkeydown={(e) => {
				if (e.key === 'Escape' || e.key === 'Enter' || e.key === ' ') closeBranchModal();
			}}
			role="button"
			aria-label="Close branch dialog"
			tabindex="0"
		>
			<div
				class="modal-card"
				onclick={(e) => e.stopPropagation()}
				onkeydown={(e) => e.stopPropagation()}
				role="dialog"
				aria-modal="true"
				aria-label="Branch session"
				tabindex="-1"
			>
				<h2>Branch Session</h2>
				<p class="modal-copy">Select the user message to branch from and optionally rename the new session.</p>

				{#if branchLoading}
					<p class="modal-copy">Loading branch points…</p>
				{:else}
					<label class="modal-field">
						<span>Branch from message</span>
						<select bind:value={selectedBranchEntryId} disabled={branchCandidates.length === 0 || branchSubmitting}>
							{#each branchCandidates as candidate}
								<option value={candidate.entryId}>{candidate.text}</option>
							{/each}
						</select>
					</label>
					<label class="modal-field">
						<span>New session name</span>
						<input
							type="text"
							bind:value={branchName}
							placeholder="my-branch"
							disabled={branchSubmitting}
						/>
					</label>
				{/if}

				{#if branchError}
					<p class="modal-error">{branchError}</p>
				{/if}

				<div class="modal-actions">
					<button type="button" class="btn" onclick={closeBranchModal} disabled={branchSubmitting}>Cancel</button>
					<button
						type="button"
						class="btn primary"
						onclick={createBranchFromSelection}
						disabled={branchLoading || branchSubmitting || !selectedBranchEntryId}
					>
						{branchSubmitting ? 'Branching…' : 'Create branch'}
					</button>
				</div>
			</div>
		</div>
	{/if}
</div>

<style>
	:global(*),
	:global(*::before),
	:global(*::after) {
		box-sizing: border-box;
	}
	:global(html.piface-session-viewport),
	:global(body.piface-session-viewport) {
		font-family: system-ui, -apple-system, sans-serif;
		background-color: var(--color-bg);
		background-image:
			radial-gradient(1000px 600px at 10% -10%, var(--skin-page-glow-1), transparent 60%),
			radial-gradient(900px 580px at 100% 0%, var(--skin-page-glow-2), transparent 62%),
			linear-gradient(
				180deg,
				color-mix(in srgb, var(--color-bg) 88%, transparent),
				color-mix(in srgb, var(--color-bg) 92%, transparent)
			),
			var(--skin-texture-page);
		background-size: auto, auto, auto, 1200px auto;
		background-repeat: no-repeat, no-repeat, no-repeat, repeat;
		background-attachment: fixed, fixed, fixed, fixed;
		color: var(--color-text);
		margin: 0;
		padding: 0;
		height: 100%;
		overflow: hidden;
	}

	.session-view {
		display: flex;
		flex-direction: column;
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		max-width: 1280px;
		width: 100%;
		margin: 0 auto;
	}

	.chat-pane,
	.files-pane,
	.scratch-pane {
		flex: 1;
		min-height: 0;
		display: flex;
		flex-direction: column;
	}

	.files-pane,
	.scratch-pane {
		padding: 0.75rem 1rem;
		padding-left: max(1rem, env(safe-area-inset-left));
		padding-right: max(1rem, env(safe-area-inset-right));
		padding-bottom: max(0.75rem, env(safe-area-inset-bottom));
	}

	/* Header */
	header {
		display: flex;
		flex-direction: column;
		padding: 0.6rem 1rem;
		padding-top: max(0.6rem, env(safe-area-inset-top));
		padding-left: max(1rem, env(safe-area-inset-left));
		padding-right: max(1rem, env(safe-area-inset-right));
		border-bottom: 1px solid var(--border-soft);
		flex-shrink: 0;
		gap: 0.2rem;
	}
	.header-top {
		display: flex;
		align-items: center;
		gap: 0.6rem;
		min-width: 0;
	}
	.back {
		color: var(--primary-text);
		text-decoration: none;
		font-size: 1rem;
		flex-shrink: 0;
		-webkit-tap-highlight-color: transparent;
		padding: 0.25rem 0.25rem 0.25rem 0;
	}
	.back:hover {
		text-decoration: underline;
	}
	h1 {
		font-size: 1.1rem;
		margin: 0;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		min-width: 0;
		flex: 1;
	}
	.header-meta {
		display: flex;
		align-items: center;
		gap: 0.75rem;
		min-width: 0;
	}
	.meta {
		font-size: 0.75rem;
		color: var(--color-muted);
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		min-width: 0;
	}
	.meta.path {
		flex-shrink: 1;
	}
	.meta.model {
		font-family: ui-monospace, 'SF Mono', monospace;
		color: var(--color-muted);
		flex-shrink: 0;
	}
	.branch-hotkey-hint {
		font-size: 0.68rem;
		color: var(--color-faint);
		margin-left: 0.25rem;
		flex-shrink: 0;
	}
	.branch-hotkey-hint kbd {
		font-family: ui-monospace, 'SF Mono', monospace;
		font-size: 0.68rem;
		border: 1px solid var(--border-strong);
		border-radius: 4px;
		padding: 0 0.25rem;
		background: var(--surface-2);
	}
	.markdown-toggle {
		display: inline-flex;
		align-items: center;
		gap: 0.35rem;
		font-size: 0.72rem;
		color: var(--color-dim);
		flex-shrink: 0;
	}
	.markdown-toggle input {
		accent-color: var(--primary-text);
	}
	.thinking-control {
		display: inline-flex;
		align-items: center;
		gap: 0.35rem;
		margin-left: auto;
		font-size: 0.72rem;
		color: var(--color-dim);
		flex-shrink: 0;
	}
	.thinking-control select {
		background: var(--surface-2);
		border: 1px solid var(--border-strong);
		border-radius: 6px;
		color: var(--color-text);
		font-size: 0.75rem;
		padding: 0.25rem 0.4rem;
	}
	.thinking-control select:disabled {
		opacity: 0.5;
	}
	.status-dot {
		width: 8px;
		height: 8px;
		border-radius: 50%;
		flex-shrink: 0;
	}
	.status-dot.live {
		background: var(--success-text);
	}
	.status-dot.dead {
		background: var(--danger-text);
	}
	.status-dot.archived {
		background: var(--color-muted);
	}
	.mode-badge {
		font-size: 0.72rem;
		padding: 0.1rem 0.45rem;
		border-radius: 4px;
		background: var(--surface-2);
		color: var(--color-muted);
		border: 1px solid var(--border-soft);
	}
	.mode-badge.archived {
		background: var(--surface-3);
		color: var(--color-muted-2);
	}
	.resume-btn {
		padding: 0.2rem 0.55rem;
		font-size: 0.75rem;
		min-height: 0;
	}
	.clone-btn,
	.branch-btn {
		padding: 0.2rem 0.55rem;
		font-size: 0.75rem;
		min-height: 0;
	}
	.close-btn {
		padding: 0.2rem 0.55rem;
		font-size: 0.75rem;
		min-height: 0;
	}

	.tab-bar {
		display: inline-flex;
		gap: 0.35rem;
		padding: 0.55rem 1rem;
		padding-left: max(1rem, env(safe-area-inset-left));
		padding-right: max(1rem, env(safe-area-inset-right));
		border-bottom: 1px solid var(--border-soft);
		flex-shrink: 0;
	}

	.tab-button {
		padding: 0.35rem 0.8rem;
		border: 1px solid var(--border-strong);
		border-radius: 999px;
		background: var(--surface-2);
		color: var(--color-muted-2);
		cursor: pointer;
		font-size: 0.8rem;
	}

	.tab-button.active {
		background: var(--primary-bg);
		border-color: var(--primary-border);
		color: var(--primary-text);
	}

	.scratch-hint {
		font-size: 0.76rem;
		color: var(--color-muted);
		margin-bottom: 0.55rem;
	}
	.scratch-editor {
		flex: 1;
		min-height: 0;
		width: 100%;
		padding: 0.75rem 0.85rem;
		border-radius: 8px;
		border: 1px solid var(--border-strong);
		background: var(--surface-2);
		color: var(--color-text);
		font-family: ui-monospace, 'SF Mono', SFMono-Regular, Menlo, monospace;
		font-size: 0.9rem;
		line-height: 1.45;
		resize: none;
	}
	.scratch-editor:focus {
		outline: none;
		border-color: var(--primary-text);
	}
	.scratch-error {
		margin-top: 0.5rem;
		font-size: 0.74rem;
		color: var(--danger-text);
	}

	/* Messages */
	.messages {
		flex: 1;
		overflow-y: auto;
		-webkit-overflow-scrolling: touch;
		padding: 1rem;
		padding-left: max(1rem, env(safe-area-inset-left));
		padding-right: max(1rem, env(safe-area-inset-right));
		display: flex;
		flex-direction: column;
		gap: 0.75rem;
	}
	.empty-chat {
		flex: 1;
		display: flex;
		align-items: center;
		justify-content: center;
		color: var(--color-faint);
		text-align: center;
	}
	.empty-chat.error-state {
		color: var(--danger-text);
	}
	.msg {
		display: flex;
	}
	.msg.user {
		justify-content: flex-end;
	}
	.msg.assistant,
	.msg.tool-result {
		justify-content: flex-start;
	}
	.msg-bubble {
		max-width: 90%;
		padding: 0.6rem 0.9rem;
		border-radius: 12px;
		overflow-x: auto;
	}
	.user-bubble {
		background: var(--primary-bg);
		border: 1px solid var(--primary-border);
	}
	.assistant-bubble {
		background: var(--surface-2);
		border: 1px solid var(--border-strong);
	}
	.assistant-bubble.streaming {
		border-color: var(--border-streaming);
	}
	.msg-text {
		margin: 0;
		white-space: pre-wrap;
		word-wrap: break-word;
		overflow-wrap: break-word;
		font-family: system-ui, -apple-system, sans-serif;
		font-size: 0.9rem;
		line-height: 1.5;
	}
	.assistant-markdown {
		font-size: 0.9rem;
		line-height: 1.5;
	}
	.assistant-markdown :global(pre) {
		overflow: auto;
		padding: 0.65rem;
		border-radius: 6px;
		background: var(--surface-3);
	}
	.assistant-markdown :global(code) {
		font-family: ui-monospace, 'SF Mono', monospace;
	}
	.assistant-markdown :global(.math-inline) {
		white-space: nowrap;
	}
	.assistant-markdown :global(.math-display) {
		overflow-x: auto;
		margin: 0.8rem 0;
	}
	.assistant-markdown :global(p:first-child) {
		margin-top: 0;
	}
	.assistant-markdown :global(p:last-child) {
		margin-bottom: 0;
	}
	.assistant-markdown :global(.code-block-wrapper) {
		position: relative;
	}
	.assistant-markdown :global(.code-copy-btn) {
		position: absolute;
		top: 0.35rem;
		right: 0.35rem;
		padding: 0.15rem 0.5rem;
		font-size: 0.7rem;
		line-height: 1.4;
		font-family: system-ui, -apple-system, sans-serif;
		border: 1px solid var(--border-strong);
		border-radius: 4px;
		background: var(--surface-2);
		color: var(--color-muted-2);
		cursor: pointer;
		opacity: 0;
		transition: opacity 0.15s ease, background 0.15s ease, color 0.15s ease;
		z-index: 1;
	}
	.assistant-markdown :global(.code-block-wrapper:hover .code-copy-btn) {
		opacity: 1;
	}
	.assistant-markdown :global(.code-copy-btn:hover) {
		background: var(--surface-hover);
		color: var(--color-text);
	}
	.assistant-markdown :global(.code-copy-btn.copied) {
		background: color-mix(in srgb, var(--success-text) 15%, var(--surface-2));
		border-color: var(--success-text);
		color: var(--success-text);
		opacity: 1;
	}
	.assistant-markdown :global(.mermaid-block) {
		margin: 1rem 0;
	}
	.assistant-markdown :global(.mermaid-render-surface) {
		display: flex;
		justify-content: center;
		align-items: center;
		min-height: 5rem;
		padding: 0.75rem;
		border-radius: 8px;
		border: 1px solid var(--border-soft);
		background: var(--surface-2);
		overflow-x: auto;
	}
	.assistant-markdown :global(.mermaid-render-placeholder) {
		color: var(--color-muted);
		font-size: 0.85rem;
	}
	.assistant-markdown :global(.mermaid-render-surface svg) {
		max-width: 100%;
		height: auto;
	}
	.assistant-markdown :global(.mermaid-render-error) {
		color: var(--danger-text);
		font-size: 0.85rem;
	}
	.assistant-markdown :global(.mermaid-source-details) {
		margin-top: 0.55rem;
	}
	.assistant-markdown :global(.mermaid-source-details summary) {
		cursor: pointer;
		color: var(--color-muted-2);
		font-size: 0.8rem;
	}
	.msg-actions-row {
		display: flex;
		justify-content: flex-end;
		margin-top: 0.4rem;
	}
	.msg-audio-footer {
		display: flex;
		flex-direction: column;
		align-items: flex-start;
		gap: 0.45rem;
		margin-top: 0.55rem;
	}
	.msg-audio-trigger {
		display: inline-flex;
		align-items: center;
		gap: 0.45rem;
		border: 1px solid var(--border-strong);
		background: var(--surface-3);
		color: var(--color-muted-2);
		font-size: 0.78rem;
		font-weight: 500;
		line-height: 1;
		border-radius: 999px;
		padding: 0.38rem 0.78rem;
		cursor: pointer;
		transition: background 0.15s ease, color 0.15s ease, border-color 0.15s ease, transform 0.15s ease;
	}
	.msg-audio-trigger:hover {
		background: var(--surface-hover);
		color: var(--color-text);
	}
	.msg-audio-trigger:focus-visible,
	.msg-audio-icon-btn:focus-visible,
	.msg-audio-btn:focus-visible {
		outline: 2px solid var(--primary-text);
		outline-offset: 2px;
	}
	.msg-audio-trigger:disabled {
		opacity: 0.7;
		cursor: wait;
		transform: none;
	}
	.msg-audio-trigger[data-state='playing'] {
		background: color-mix(in srgb, var(--primary-text) 12%, var(--surface-3));
		color: var(--color-text);
		border-color: color-mix(in srgb, var(--primary-text) 45%, var(--border-strong));
	}
	.msg-audio-trigger-icon {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		width: 0.95rem;
		min-width: 0.95rem;
		font-size: 0.85rem;
	}
	.msg-audio-spinner {
		width: 0.8rem;
		height: 0.8rem;
		border-radius: 999px;
		border: 2px solid color-mix(in srgb, var(--color-muted) 45%, transparent);
		border-top-color: var(--primary-text);
		animation: spin 0.85s linear infinite;
	}
	.msg-audio-player {
		width: min(100%, 34rem);
		border: 1px solid var(--border-soft);
		border-radius: 12px;
		background: var(--surface-2);
		padding: 0.6rem 0.75rem;
	}
	.msg-audio-player[data-state='playing'] {
		border-color: color-mix(in srgb, var(--primary-text) 30%, var(--border-soft));
		background: color-mix(in srgb, var(--primary-text) 6%, var(--surface-2));
	}
	.msg-audio-player[data-state='error'] {
		border-color: color-mix(in srgb, var(--danger-text) 30%, var(--border-soft));
	}
	.msg-audio-player-row {
		display: flex;
		align-items: center;
		gap: 0.7rem;
		flex-wrap: wrap;
	}
	.msg-audio-icon-btn {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		width: 2rem;
		height: 2rem;
		border-radius: 999px;
		border: 1px solid var(--border-strong);
		background: var(--surface-3);
		color: var(--color-text);
		cursor: pointer;
		font-size: 0.9rem;
		flex: 0 0 auto;
	}
	.msg-audio-icon-btn:hover {
		background: var(--surface-hover);
	}
	.msg-audio-icon-btn:disabled {
		opacity: 0.7;
		cursor: wait;
	}
	.msg-audio-track {
		display: flex;
		flex-direction: column;
		gap: 0.35rem;
		flex: 1 1 12rem;
		min-width: 12rem;
	}
	.msg-audio-track-meta {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 0.75rem;
		font-size: 0.72rem;
	}
	.msg-audio-status {
		display: inline-flex;
		align-items: center;
		gap: 0.35rem;
		color: var(--color-muted-2);
		min-width: 0;
	}
	.msg-audio-time {
		font-size: 0.72rem;
		color: var(--color-muted);
		white-space: nowrap;
	}
	.msg-audio-progress {
		position: relative;
		height: 0.44rem;
		border-radius: 999px;
		background: var(--surface-3);
		overflow: hidden;
	}
	.msg-audio-progress-fill {
		display: block;
		height: 100%;
		width: var(--tts-progress);
		background: linear-gradient(90deg, var(--primary-text), color-mix(in srgb, var(--primary-text) 60%, white));
		border-radius: 999px;
		transition: width 0.12s linear;
	}
	.msg-audio-progress.is-loading .msg-audio-progress-fill {
		width: 38%;
		background: linear-gradient(
			90deg,
			color-mix(in srgb, var(--primary-text) 18%, var(--surface-3)),
			color-mix(in srgb, var(--primary-text) 48%, white),
			color-mix(in srgb, var(--primary-text) 18%, var(--surface-3))
		);
		animation: shimmer 1.15s linear infinite;
	}
	.msg-audio-secondary-actions {
		display: flex;
		align-items: center;
		gap: 0.4rem;
		flex-wrap: wrap;
	}
	.msg-audio-btn {
		border: 1px solid var(--border-strong);
		background: var(--surface-3);
		color: var(--color-muted-2);
		font-size: 0.72rem;
		border-radius: 999px;
		padding: 0.24rem 0.6rem;
		cursor: pointer;
	}
	.msg-audio-btn:hover {
		background: var(--surface-hover);
		color: var(--color-text);
	}
	.msg-audio-btn:disabled {
		opacity: 0.6;
		cursor: wait;
	}
	.msg-audio-btn.secondary {
		background: transparent;
	}
	.msg-inline-error {
		margin-top: 0.3rem;
		font-size: 0.74rem;
		color: var(--danger-text);
	}
	.msg-inline-error-audio {
		margin-top: 0.55rem;
	}
	@keyframes spin {
		to { transform: rotate(360deg); }
	}
	@keyframes shimmer {
		from { transform: translateX(-35%); }
		to { transform: translateX(170%); }
	}
	.msg-branch-btn {
		border: 1px solid var(--border-strong);
		background: var(--surface-3);
		color: var(--color-muted-2);
		font-size: 0.72rem;
		border-radius: 999px;
		padding: 0.12rem 0.5rem;
		cursor: pointer;
	}
	.msg-branch-btn:hover {
		background: var(--surface-hover);
		color: var(--color-text);
	}
	.cursor {
		animation: blink 1s step-end infinite;
		color: var(--primary-text);
	}
	@keyframes blink {
		50% { opacity: 0; }
	}

	/* Thinking */
	.thinking {
		margin-bottom: 0.5rem;
	}
	.thinking summary {
		font-size: 0.8rem;
		color: var(--color-muted);
		cursor: pointer;
	}
	.thinking-text {
		margin: 0.4rem 0 0;
		font-size: 0.8rem;
		color: var(--color-dim);
		white-space: pre-wrap;
		word-wrap: break-word;
		font-family: system-ui, sans-serif;
		border-left: 2px solid var(--border-strong);
		padding-left: 0.6rem;
	}

	/* Tool calls */
	.tool-call,
	.tool-result-details {
		margin-top: 0.5rem;
		font-size: 0.8rem;
	}
	.tool-call summary,
	.tool-result-details summary {
		cursor: pointer;
		color: var(--color-muted-2);
	}
	.tool-args,
	.tool-output {
		margin: 0.4rem 0 0;
		font-size: 0.8rem;
		color: var(--color-muted-2);
		white-space: pre-wrap;
		word-wrap: break-word;
		overflow-wrap: break-word;
		font-family: ui-monospace, 'SF Mono', monospace;
		background: var(--surface-3);
		padding: 0.5rem;
		border-radius: 6px;
		max-height: 300px;
		overflow-y: auto;
	}

	/* Tool result message */
	.tool-result {
		padding-left: 1rem;
	}

	/* Input area */
	.input-area {
		flex-shrink: 0;
		padding: 0.75rem 1rem;
		padding-bottom: max(0.75rem, env(safe-area-inset-bottom));
		padding-left: max(1rem, env(safe-area-inset-left));
		padding-right: max(1rem, env(safe-area-inset-right));
		border-top: 1px solid var(--border-soft);
		display: flex;
		flex-wrap: wrap;
		gap: 0.5rem;
		align-items: flex-end;
	}
	.composer-fullscreen-header {
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 0.5rem;
		font-size: 0.78rem;
		color: var(--color-muted-2);
	}
	.composer-reference-btn {
		padding: 0.3rem 0.65rem;
		font-size: 0.75rem;
		min-height: 0;
	}
	.working-indicator {
		width: 100%;
		display: inline-flex;
		align-items: center;
		gap: 0.45rem;
		font-size: 0.78rem;
		color: var(--color-muted-2);
	}
	.working-dot {
		width: 0.55rem;
		height: 0.55rem;
		border-radius: 999px;
		background: var(--primary-text);
		animation: pulse 1.1s ease-in-out infinite;
	}
	@keyframes pulse {
		0%,
		100% {
			opacity: 0.35;
			transform: scale(0.8);
		}
		50% {
			opacity: 1;
			transform: scale(1);
		}
	}
	.tool-progress-list {
		width: 100%;
		display: flex;
		flex-direction: column;
		gap: 0.25rem;
	}
	.tool-progress-row {
		display: flex;
		justify-content: space-between;
		align-items: center;
		gap: 0.5rem;
		font-size: 0.74rem;
		color: var(--color-muted);
	}
	.tool-progress-row.running {
		color: var(--primary-text);
	}
	.tool-progress-row.error {
		color: var(--danger-text);
	}
	.tool-name {
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
	.tool-status {
		text-transform: lowercase;
		flex-shrink: 0;
	}
	.composer {
		flex: 1;
		display: flex;
		flex-direction: column;
		gap: 0.35rem;
		padding: 0.2rem;
		border-radius: 10px;
		transition: background 0.15s ease, box-shadow 0.15s ease;
	}
	.composer.drag-active {
		background: color-mix(in srgb, var(--primary-bg) 35%, transparent);
		box-shadow: inset 0 0 0 1px var(--primary-border);
	}
	.drop-hint {
		font-size: 0.75rem;
		color: var(--primary-text);
		padding: 0 0.25rem;
	}
	textarea {
		width: 100%;
		padding: 0.6rem 0.8rem;
		background: var(--surface-2);
		border: 1px solid var(--border-strong);
		border-radius: 8px;
		color: var(--color-text);
		/* 16px prevents iOS auto-zoom on focus */
		font-size: 1rem;
		font-family: system-ui, sans-serif;
		resize: none;
		line-height: 1.4;
		overflow-y: hidden;
	}
	textarea:focus {
		outline: none;
		border-color: var(--primary-text);
	}
	textarea::placeholder {
		color: var(--color-muted);
		opacity: 1;
	}
	textarea:disabled {
		opacity: 0.5;
	}
	.upload-chips {
		display: flex;
		gap: 0.35rem;
		flex-wrap: wrap;
	}
	.upload-chip {
		border: 1px solid var(--border-strong);
		background: var(--surface-3);
		color: var(--color-text);
		font-size: 0.75rem;
		border-radius: 999px;
		padding: 0.15rem 0.5rem;
		cursor: pointer;
	}
	.upload-chip:hover {
		background: var(--surface-hover);
	}
	.upload-error {
		font-size: 0.75rem;
		color: var(--danger-text);
	}
	.voice-status {
		font-size: 0.75rem;
		color: var(--color-muted-2);
	}
	.input-actions {
		display: flex;
		gap: 0.35rem;
		flex-wrap: wrap;
		justify-content: flex-end;
	}
	.input-actions .btn {
		padding: 0.35rem 0.7rem;
		font-size: 0.78rem;
		line-height: 1.2;
		min-height: 2rem;
	}

	/* Buttons */
	.btn {
		padding: 0.5rem 1rem;
		border: 1px solid var(--border-strong);
		border-radius: 6px;
		background: var(--surface-2);
		color: var(--color-text);
		cursor: pointer;
		font-size: 0.85rem;
		-webkit-tap-highlight-color: transparent;
		touch-action: manipulation;
		min-height: 2.5rem;
	}
	.btn:hover {
		background: var(--surface-hover);
	}
	.btn.primary {
		background: var(--primary-bg);
		border-color: var(--primary-border);
		color: var(--primary-text);
	}
	.btn.primary:hover {
		background: var(--primary-bg-hover);
	}
	.btn.primary:disabled {
		opacity: 0.4;
		cursor: not-allowed;
	}
	.btn.danger {
		background: var(--danger-bg);
		border-color: var(--danger-border);
		color: var(--danger-text);
	}
	.btn.danger:hover {
		background: var(--danger-bg-hover);
	}

	.modal-backdrop {
		position: fixed;
		inset: 0;
		background: color-mix(in srgb, var(--color-bg) 70%, transparent);
		display: flex;
		align-items: center;
		justify-content: center;
		padding: 1rem;
		z-index: 30;
	}
	.modal-card {
		width: min(32rem, 100%);
		background: var(--surface-1);
		border: 1px solid var(--border-strong);
		border-radius: 10px;
		padding: 1rem;
		display: flex;
		flex-direction: column;
		gap: 0.7rem;
	}
	.modal-card h2 {
		margin: 0;
		font-size: 1rem;
	}
	.modal-copy {
		margin: 0;
		font-size: 0.82rem;
		color: var(--color-muted);
	}
	.modal-field {
		display: flex;
		flex-direction: column;
		gap: 0.3rem;
	}
	.modal-field span {
		font-size: 0.78rem;
		color: var(--color-muted-2);
	}
	.modal-field input,
	.modal-field select {
		padding: 0.5rem 0.6rem;
		background: var(--surface-2);
		border: 1px solid var(--border-strong);
		border-radius: 6px;
		color: var(--color-text);
		font-size: 0.9rem;
	}
	.modal-error {
		margin: 0;
		font-size: 0.82rem;
		color: var(--danger-text);
	}
	.modal-actions {
		display: flex;
		justify-content: flex-end;
		gap: 0.45rem;
	}

	/* ---- Mobile breakpoint ---- */
	@media (max-width: 480px) {
		header {
			padding: 0.4rem 0.75rem;
			padding-top: max(0.4rem, env(safe-area-inset-top));
		}
		h1 {
			font-size: 0.95rem;
		}
		.header-meta {
			gap: 0.5rem;
			flex-wrap: wrap;
		}
		.thinking-control {
			margin-left: 0;
		}
		.tab-bar {
			padding: 0.45rem 0.75rem;
		}
		.messages {
			padding: 0.75rem;
		}
		.msg-bubble {
			max-width: 92%;
		}
		.tool-result {
			padding-left: 0.5rem;
		}
		.msg-audio-player {
			width: 100%;
		}
		.msg-audio-player-row {
			align-items: flex-start;
		}
		.msg-audio-track {
			min-width: 0;
			width: 100%;
			flex-basis: 100%;
		}
		.msg-audio-secondary-actions {
			padding-left: 2.7rem;
		}
		.input-area {
			padding: 0.5rem 0.75rem;
			padding-bottom: max(0.5rem, env(safe-area-inset-bottom));
			flex-direction: column;
			flex-wrap: nowrap;
			align-items: stretch;
			gap: 0.45rem;
		}
		.composer {
			width: 100%;
		}
		.input-actions {
			width: 100%;
			display: flex;
			flex-wrap: nowrap;
			overflow-x: auto;
			gap: 0.3rem;
			justify-content: flex-start;
			padding-bottom: 0.1rem;
			-webkit-overflow-scrolling: touch;
			scrollbar-width: none;
		}
		.input-actions::-webkit-scrollbar {
			display: none;
		}
		.input-actions .btn {
			width: auto;
			flex: 0 0 auto;
			min-width: max-content;
			padding: 0.32rem 0.5rem;
			font-size: 0.75rem;
			min-height: 1.9rem;
			white-space: nowrap;
		}
		.files-pane,
		.scratch-pane {
			padding: 0.5rem 0.75rem;
			padding-bottom: max(0.5rem, env(safe-area-inset-bottom));
		}

		.session-view.mobile-compose-fullscreen header,
		.session-view.mobile-compose-fullscreen .tab-bar,
		.session-view.mobile-compose-fullscreen .messages,
		.session-view.mobile-compose-fullscreen .working-indicator,
		.session-view.mobile-compose-fullscreen .tool-progress-list {
			display: none;
		}
		.session-view.mobile-compose-fullscreen .input-area {
			flex: 1;
			border-top: none;
			padding-top: max(0.6rem, env(safe-area-inset-top));
		}
		.session-view.mobile-compose-fullscreen .composer {
			flex: 1;
		}
		.session-view.mobile-compose-fullscreen .input-actions {
			margin-top: auto;
		}
	}
</style>
