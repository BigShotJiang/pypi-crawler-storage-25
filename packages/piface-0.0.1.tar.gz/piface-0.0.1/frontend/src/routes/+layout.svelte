<script lang="ts">
	import { onMount } from 'svelte';
	import favicon from '$lib/assets/favicon.png';
	import '../app.css';
	import { cleanupThemeSync, initTheme } from '$lib/theme';
	import { initSkin } from '$lib/skin';

	let { children } = $props();

	onMount(() => {
		initTheme();
		initSkin();
		return () => cleanupThemeSync();
	});
</script>

<svelte:head>
	<link rel="icon" type="image/png" href={favicon} />
</svelte:head>

{@render children()}
