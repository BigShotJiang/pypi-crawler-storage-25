// SPA mode — disable SSR, enable prerender for static adapter
export const prerender = true;
export const ssr = false;
