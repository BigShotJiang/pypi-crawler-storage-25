"""Piface — web-based remote interface for pi."""

__version__ = "0.1.0"
