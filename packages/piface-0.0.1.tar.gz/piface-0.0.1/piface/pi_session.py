"""Wraps a single pi --mode rpc subprocess with asyncio streams."""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
from collections.abc import Callable
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class PiSessionConfig:
    """Configuration for spawning a pi subprocess."""

    working_dir: str
    provider: str | None = "openai-codex"
    model: str | None = "gpt-5.5-codex"
    thinking_level: str | None = "medium"
    no_session: bool = False
    session_file: str | None = None
    use_direnv: bool = True
    launch_command_prefix: list[str] | None = None

    def build_args(self) -> list[str]:
        args = ["pi", "--mode", "rpc"]
        if self.provider:
            args += ["--provider", self.provider]
        if self.model:
            args += ["--model", self.model]
        if self.thinking_level:
            args += ["--thinking", self.thinking_level]
        if self.no_session:
            args.append("--no-session")
        if self.session_file:
            args += ["--session", self.session_file]
        return args


class PiSession:
    """Manages a single pi RPC subprocess.

    Usage:
        session = PiSession(config)
        session.on_event = my_callback  # called for each JSON line from stdout
        await session.start()
        await session.send({"type": "prompt", "message": "hello"})
        await session.stop()
    """

    def __init__(self, config: PiSessionConfig) -> None:
        self.config = config
        self.on_event: Callable[[dict], None] | None = None
        self._internal_listeners: list[Callable[[dict], None]] = []
        self._process: asyncio.subprocess.Process | None = None
        self._reader_task: asyncio.Task | None = None

    def add_listener(self, callback: Callable[[dict], None]) -> None:
        """Add an internal event listener (always called, separate from on_event)."""
        self._internal_listeners.append(callback)

    def remove_listener(self, callback: Callable[[dict], None]) -> None:
        """Remove an internal event listener."""
        try:
            self._internal_listeners.remove(callback)
        except ValueError:
            pass

    def _build_command(self) -> list[str]:
        """Build the subprocess command. Overridable for testing."""
        args = self.config.build_args()

        if self.config.launch_command_prefix is not None:
            return self.config.launch_command_prefix + args

        if not self.config.use_direnv:
            return args

        if shutil.which("direnv") is None:
            return args

        return ["direnv", "exec", self.config.working_dir, *args]

    @property
    def is_alive(self) -> bool:
        return self._process is not None and self._process.returncode is None

    # pi RPC can emit very large JSON lines (e.g. file contents, long
    # responses, full session replays). The default asyncio stream buffer
    # is 64 KiB which is easily exceeded, causing a LimitOverrunError that
    # kills the read loop. 64 MiB safely covers large replay payloads.
    _STREAM_LIMIT = 64 * 1024 * 1024  # 64 MiB

    _STARTUP_GRACE_SECONDS = 0.35

    async def start(self) -> None:
        """Spawn the pi subprocess and start reading stdout."""
        cmd = self._build_command()
        logger.info("Starting pi session: %s (cwd=%s)", " ".join(cmd), self.config.working_dir)
        self._process = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=self.config.working_dir,
            limit=self._STREAM_LIMIT,
        )

        # Start reading stdout immediately so short-lived subprocesses can
        # still emit events before exit.
        self._reader_task = asyncio.create_task(self._read_loop())

        try:
            await asyncio.wait_for(
                self._process.wait(),
                timeout=self._STARTUP_GRACE_SECONDS,
            )
        except TimeoutError:
            # Process is still running after startup grace window.
            return

        # Process exited immediately. Treat non-zero exit as startup failure so
        # callers can surface a useful error instead of creating a dead session.
        returncode = self._process.returncode
        if returncode and returncode != 0:
            stderr_text = ""
            if self._process.stderr is not None:
                stderr_text = (await self._process.stderr.read()).decode(errors="replace").strip()

            # Let the stdout reader drain any final events before surfacing the
            # startup error.
            if self._reader_task is not None and not self._reader_task.done():
                try:
                    await asyncio.wait_for(asyncio.shield(self._reader_task), timeout=0.2)
                except TimeoutError:
                    pass

            if stderr_text:
                raise RuntimeError(
                    f"pi process exited immediately with code {returncode}: {stderr_text}"
                )
            raise RuntimeError(f"pi process exited immediately with code {returncode}")

    async def send(self, data: dict) -> None:
        """Write a JSON command to pi's stdin."""
        if not self.is_alive or self._process is None or self._process.stdin is None:
            logger.warning("Cannot send to dead pi session")
            return
        line = json.dumps(data) + "\n"
        self._process.stdin.write(line.encode())
        await self._process.stdin.drain()

    async def stop(self) -> None:
        """Terminate the pi subprocess and clean up."""
        if self._process is None:
            return

        if self.is_alive:
            try:
                self._process.terminate()
                try:
                    await asyncio.wait_for(self._process.wait(), timeout=5.0)
                except TimeoutError:
                    self._process.kill()
                    await self._process.wait()
            except ProcessLookupError:
                pass

        if self._reader_task is not None:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass
            self._reader_task = None

    async def _read_loop(self) -> None:
        """Read JSON lines from pi's stdout and dispatch events."""
        assert self._process is not None and self._process.stdout is not None
        try:
            while True:
                line = await self._process.stdout.readline()
                if not line:
                    # EOF — process exited
                    break
                text = line.decode().strip()
                if not text:
                    continue
                try:
                    data = json.loads(text)
                except json.JSONDecodeError:
                    logger.warning("Non-JSON line from pi: %s", text[:200])
                    continue
                # Dispatch to internal listeners first
                for listener in self._internal_listeners:
                    try:
                        listener(data)
                    except Exception:
                        logger.exception("Error in internal event listener")
                # Then dispatch to the external handler
                if self.on_event:
                    self.on_event(data)
        except asyncio.CancelledError:
            return
        except Exception:
            logger.exception("Error in pi session read loop")
