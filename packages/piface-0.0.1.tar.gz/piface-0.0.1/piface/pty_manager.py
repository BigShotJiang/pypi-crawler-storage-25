"""Per-session PTY management: spawn, resize, read/write, and cleanup."""

from __future__ import annotations

import asyncio
import fcntl
import logging
import os
import pty
import signal
import struct
import termios
from collections.abc import Callable

logger = logging.getLogger(__name__)


class PtySession:
    """Wraps a single PTY subprocess (bash shell) with async I/O.

    The PTY lifetime is tied to the piface session, not to any individual
    WebSocket connection.  When a browser disconnects and reconnects the
    same PTY is reused.
    """

    def __init__(self, fd: int, pid: int, cols: int, rows: int) -> None:
        self.fd = fd
        self.pid = pid
        self.cols = cols
        self.rows = rows
        self.on_output: Callable[[bytes], None] | None = None
        self._read_task: asyncio.Task[None] | None = None
        self._closed = False

    # -- Factory -------------------------------------------------------------

    @classmethod
    def spawn(
        cls,
        working_dir: str,
        cols: int = 80,
        rows: int = 24,
        *,
        launch_command: list[str] | None = None,
    ) -> PtySession:
        """Fork a child bash process attached to a new PTY."""
        pid, fd = pty.fork()

        if pid == 0:
            # Child process
            os.chdir(working_dir)
            env = os.environ.copy()
            env["TERM"] = "xterm-256color"
            env["COLORTERM"] = "truecolor"
            if launch_command is not None:
                os.execvpe(launch_command[0], launch_command, env)
            else:
                os.execvpe("bash", ["bash", "-l"], env)
            # execvpe never returns

        # Parent — set initial window size
        _set_winsize(fd, rows, cols)

        session = cls(fd, pid, cols, rows)
        return session

    # -- Public API ----------------------------------------------------------

    @property
    def alive(self) -> bool:
        if self._closed:
            return False
        try:
            pid, status = os.waitpid(self.pid, os.WNOHANG)
            if pid == 0:
                return True
            # Child exited — clean up fd
            self._closed = True
            try:
                os.close(self.fd)
            except OSError:
                pass
            return False
        except ChildProcessError:
            self._closed = True
            return False

    def resize(self, cols: int, rows: int) -> None:
        if self._closed:
            return
        self.cols = cols
        self.rows = rows
        try:
            _set_winsize(self.fd, rows, cols)
        except OSError:
            pass

    def write(self, data: bytes) -> None:
        if self._closed:
            return
        try:
            os.write(self.fd, data)
        except OSError:
            logger.debug("PTY write failed (pid=%s)", self.pid)

    def start_reading(self) -> None:
        """Start the async read loop (call once after setting on_output)."""
        if self._read_task is None or self._read_task.done():
            self._read_task = asyncio.create_task(self._read_loop())

    def stop_reading(self) -> None:
        """Cancel the read loop without closing the PTY."""
        if self._read_task is not None and not self._read_task.done():
            self._read_task.cancel()

    def close(self) -> None:
        """Terminate the child and close the PTY fd."""
        if self._closed:
            return
        self._closed = True
        self.stop_reading()
        try:
            os.kill(self.pid, signal.SIGHUP)
        except ProcessLookupError:
            pass
        try:
            os.close(self.fd)
        except OSError:
            pass
        try:
            pid, _ = os.waitpid(self.pid, os.WNOHANG)
            if pid == 0:
                # Still alive after SIGHUP — force kill
                os.kill(self.pid, signal.SIGKILL)
                os.waitpid(self.pid, 0)
        except (ChildProcessError, ProcessLookupError):
            pass

    # -- Internal ------------------------------------------------------------

    async def _read_loop(self) -> None:
        """Read PTY output in a thread and dispatch to on_output."""
        loop = asyncio.get_running_loop()
        try:
            while not self._closed:
                try:
                    data = await loop.run_in_executor(None, os.read, self.fd, 4096)
                except OSError:
                    break
                if not data:
                    break
                if self.on_output:
                    self.on_output(data)
        except asyncio.CancelledError:
            return


def _set_winsize(fd: int, rows: int, cols: int) -> None:
    """Set the terminal window size on a PTY fd."""
    winsize = struct.pack("HHHH", rows, cols, 0, 0)
    fcntl.ioctl(fd, termios.TIOCSWINSZ, winsize)
