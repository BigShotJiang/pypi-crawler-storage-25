"""Allow running as `python -m piface`."""

from piface.cli import app

app()
