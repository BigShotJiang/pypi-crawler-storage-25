"""Text-to-speech utilities powered by Coqui TTS."""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import subprocess
import tempfile
import threading
from dataclasses import dataclass
from pathlib import Path
from re import Pattern, compile
from typing import Any

_CACHE_KEY_PATTERN: Pattern[str] = compile(r"^[0-9a-f]{64}$")
_DEFAULT_CACHE_BYTES = 1024 * 1024 * 1024  # 1 GiB
_TTS_OUTPUT_FORMAT_VERSION = "mp3-v1"
_TTS_OUTPUT_SUFFIX = ".mp3"
_TTS_MEDIA_TYPE = "audio/mpeg"
_TTS_BITRATE = "64k"


class SpeechSynthesisError(RuntimeError):
    """Typed speech-synthesis error with an associated HTTP status code."""

    def __init__(self, message: str, *, code: str, status_code: int) -> None:
        super().__init__(message)
        self.code = code
        self.status_code = status_code


@dataclass(frozen=True)
class PreparedTtsAudio:
    """Resolved synthesized-audio artifact."""

    cache_key: str
    file_path: Path
    media_type: str = _TTS_MEDIA_TYPE
    cached: bool = False


def normalize_tts_text(text: str) -> str:
    """Normalize input text before hashing or synthesis."""
    return text.replace("\r\n", "\n").strip()


def build_tts_cache_key(*, model_name: str, text: str) -> str:
    """Build a stable content-addressed cache key for TTS output."""
    payload = json.dumps(
        {
            "model_name": model_name,
            "text": normalize_tts_text(text),
            "output_format": _TTS_OUTPUT_FORMAT_VERSION,
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def is_valid_tts_cache_key(cache_key: str) -> bool:
    """Return True when the cache key matches the expected digest shape."""
    return bool(_CACHE_KEY_PATTERN.fullmatch(cache_key))


class CoquiTtsSynthesizer:
    """Lazy-loading Coqui TTS service with a disk-backed audio cache."""

    def __init__(
        self,
        *,
        cache_dir: Path,
        model_name: str = "tts_models/en/ljspeech/vits",
        prefer_gpu: bool = True,
        max_cache_bytes: int = _DEFAULT_CACHE_BYTES,
    ) -> None:
        self.cache_dir = cache_dir
        self.model_name = model_name
        self.prefer_gpu = prefer_gpu
        self.max_cache_bytes = max_cache_bytes
        self._engine: Any | None = None
        self._engine_lock = threading.Lock()
        self._synthesis_lock = threading.Lock()

    async def prepare(self, text: str) -> PreparedTtsAudio:
        """Ensure a synthesized MP3 file exists for the given text."""
        normalized_text = normalize_tts_text(text)
        if not normalized_text:
            raise SpeechSynthesisError(
                "Text-to-speech input is empty.",
                code="empty_text",
                status_code=400,
            )

        cache_key = build_tts_cache_key(model_name=self.model_name, text=normalized_text)
        cached = self.get_cached_audio(cache_key)
        if cached is not None:
            return cached

        return await asyncio.to_thread(self._prepare_sync, normalized_text, cache_key)

    def get_cached_audio(self, cache_key: str) -> PreparedTtsAudio | None:
        """Return cached synthesized audio if the cache key exists on disk."""
        if not is_valid_tts_cache_key(cache_key):
            return None

        path = self.cache_dir / f"{cache_key}{_TTS_OUTPUT_SUFFIX}"
        try:
            if not path.is_file() or path.stat().st_size <= 0:
                return None
        except FileNotFoundError:
            return None

        self._touch_cache_file(path)
        return PreparedTtsAudio(
            cache_key=cache_key,
            file_path=path,
            media_type=_TTS_MEDIA_TYPE,
            cached=True,
        )

    def _prepare_sync(self, text: str, cache_key: str) -> PreparedTtsAudio:
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        with self._synthesis_lock:
            cached = self.get_cached_audio(cache_key)
            if cached is not None:
                return cached

            engine = self._get_or_load_engine()
            final_path = self.cache_dir / f"{cache_key}{_TTS_OUTPUT_SUFFIX}"
            temp_wav_path: Path | None = None
            temp_mp3_path: Path | None = None

            try:
                with tempfile.NamedTemporaryFile(
                    prefix="piface-tts-",
                    suffix=".wav",
                    dir=self.cache_dir,
                    delete=False,
                ) as temp_wav_file:
                    temp_wav_path = Path(temp_wav_file.name)
                with tempfile.NamedTemporaryFile(
                    prefix="piface-tts-",
                    suffix=_TTS_OUTPUT_SUFFIX,
                    dir=self.cache_dir,
                    delete=False,
                ) as temp_mp3_file:
                    temp_mp3_path = Path(temp_mp3_file.name)

                self._synthesize_to_file(engine, text=text, output_path=temp_wav_path)
                if not temp_wav_path.is_file() or temp_wav_path.stat().st_size <= 0:
                    raise SpeechSynthesisError(
                        "Coqui TTS produced an empty audio file.",
                        code="empty_audio",
                        status_code=502,
                    )

                self._convert_wav_to_mp3(source_path=temp_wav_path, mp3_path=temp_mp3_path)
                if not temp_mp3_path.is_file() or temp_mp3_path.stat().st_size <= 0:
                    raise SpeechSynthesisError(
                        "Coqui TTS produced an empty MP3 file.",
                        code="empty_audio",
                        status_code=502,
                    )

                temp_mp3_path.replace(final_path)
                self._touch_cache_file(final_path)
                self._trim_cache_if_needed()
                return PreparedTtsAudio(
                    cache_key=cache_key,
                    file_path=final_path,
                    media_type=_TTS_MEDIA_TYPE,
                    cached=False,
                )
            except SpeechSynthesisError:
                raise
            except Exception as exc:  # pragma: no cover - exercised by integration
                raise SpeechSynthesisError(
                    f"Coqui TTS synthesis failed: {exc}",
                    code="synthesis_failed",
                    status_code=502,
                ) from exc
            finally:
                if temp_wav_path is not None and temp_wav_path.exists():
                    temp_wav_path.unlink(missing_ok=True)
                if temp_mp3_path is not None and temp_mp3_path.exists():
                    temp_mp3_path.unlink(missing_ok=True)

    def _get_or_load_engine(self) -> Any:
        if self._engine is not None:
            return self._engine

        with self._engine_lock:
            if self._engine is not None:
                return self._engine

            try:
                import torch
                from TTS.api import TTS  # type: ignore[import-not-found]
            except ModuleNotFoundError as exc:
                raise SpeechSynthesisError(
                    (
                        "Text-to-speech dependencies are missing. Install the tts or "
                        "audio extra, then ensure torch, torchaudio, and torchcodec "
                        "are available."
                    ),
                    code="missing_dependencies",
                    status_code=503,
                ) from exc

            use_gpu = self.prefer_gpu and torch.cuda.is_available()
            try:
                try:
                    engine = TTS(model_name=self.model_name, progress_bar=False, gpu=use_gpu)
                except TypeError:
                    engine = TTS(model_name=self.model_name, progress_bar=False)
                    if use_gpu and hasattr(engine, "to"):
                        maybe_engine = engine.to("cuda")
                        if maybe_engine is not None:
                            engine = maybe_engine
            except Exception as exc:  # pragma: no cover - exercised by integration
                raise SpeechSynthesisError(
                    f"Failed to load Coqui TTS model: {exc}",
                    code="model_load_failed",
                    status_code=503,
                ) from exc

            self._engine = engine
            return engine

    @staticmethod
    def _synthesize_to_file(engine: Any, *, text: str, output_path: Path) -> None:
        try:
            engine.tts_to_file(text=text, file_path=str(output_path))
        except TypeError:
            engine.tts_to_file(text, str(output_path))

    @staticmethod
    def _convert_wav_to_mp3(*, source_path: Path, mp3_path: Path) -> None:
        command = [
            "ffmpeg",
            "-y",
            "-i",
            str(source_path),
            "-ac",
            "1",
            "-codec:a",
            "libmp3lame",
            "-b:a",
            _TTS_BITRATE,
            str(mp3_path),
        ]

        try:
            result = subprocess.run(command, capture_output=True, text=True, check=False)
        except FileNotFoundError as exc:
            raise SpeechSynthesisError(
                "ffmpeg is required for TTS MP3 encoding but was not found on PATH.",
                code="ffmpeg_missing",
                status_code=503,
            ) from exc

        if result.returncode != 0:
            detail = result.stderr.strip() or "TTS MP3 encoding failed"
            raise SpeechSynthesisError(
                detail,
                code="audio_encode_failed",
                status_code=502,
            )

    @staticmethod
    def _touch_cache_file(path: Path) -> None:
        try:
            os.utime(path, None)
        except FileNotFoundError:
            pass

    def _trim_cache_if_needed(self) -> None:
        if self.max_cache_bytes <= 0 or not self.cache_dir.is_dir():
            return

        files: list[Path] = []
        for candidate in self.cache_dir.glob(f"*{_TTS_OUTPUT_SUFFIX}"):
            try:
                candidate.stat()
            except FileNotFoundError:
                continue
            files.append(candidate)

        files.sort(key=lambda path: path.stat().st_mtime, reverse=True)

        total_bytes = 0
        for path in files:
            try:
                size = path.stat().st_size
            except FileNotFoundError:
                continue

            should_keep = total_bytes == 0 or total_bytes + size <= self.max_cache_bytes
            if should_keep:
                total_bytes += size
                continue

            path.unlink(missing_ok=True)
