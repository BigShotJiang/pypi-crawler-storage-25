import{_ as e,b as n}from"../chunks/B-FSkDvK.js";export{e as component,n as universal};
