import{l as o,a as r}from"../chunks/B_rE-CAi.js";export{o as load_css,r as start};
