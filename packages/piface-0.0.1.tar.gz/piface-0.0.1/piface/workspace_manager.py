"""Manages Git worktree-backed workspaces for piface sessions."""

from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import re
import secrets
import shutil
import uuid
from dataclasses import dataclass
from pathlib import Path

from platformdirs import user_data_dir

from piface.workspace_config import (
    WorkspaceConfig,
    load_workspace_config,
    render_template,
    validate_file_paths,
    validate_workspace_root,
)

logger = logging.getLogger(__name__)


@dataclass
class ProjectInfo:
    """Resolved project metadata from a user-entered path."""

    project_dir: str
    project_subdir: str
    is_git: bool
    config: WorkspaceConfig


@dataclass
class WorkspaceInfo:
    """Metadata for a provisioned workspace."""

    workspace_id: str
    workspace_name: str
    workspace_root: str
    workspace_branch: str | None
    workspace_base_ref: str
    execution_dir: str
    bootstrap_log_path: str | None


class WorkspaceManager:
    """Manages Git worktree-backed workspaces for piface sessions."""

    def __init__(self, data_dir: Path | None = None) -> None:
        self._data_dir = data_dir or _default_data_dir()
        self._project_locks: dict[str, asyncio.Lock] = {}

    def _get_project_lock(self, project_dir: str) -> asyncio.Lock:
        canonical = str(Path(project_dir).resolve())
        if canonical not in self._project_locks:
            self._project_locks[canonical] = asyncio.Lock()
        return self._project_locks[canonical]

    # -- Project resolution --------------------------------------------------

    async def resolve_project(self, user_path: str) -> ProjectInfo:
        """Determine project_dir, project_subdir, is_git from a user path."""
        path = Path(user_path).resolve()
        if not path.is_dir():
            raise ValueError(f"Path does not exist or is not a directory: {user_path}")

        try:
            proc = await asyncio.create_subprocess_exec(
                "git", "-C", str(path), "rev-parse", "--show-toplevel",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await proc.communicate()
            if proc.returncode == 0:
                repo_root = stdout.decode().strip()
                repo_root_path = Path(repo_root).resolve()
                try:
                    subdir = str(path.relative_to(repo_root_path))
                except ValueError:
                    subdir = "."
                if subdir == ".":
                    subdir = "."

                config = load_workspace_config(repo_root)
                return ProjectInfo(
                    project_dir=str(repo_root_path),
                    project_subdir=subdir,
                    is_git=True,
                    config=config,
                )
        except FileNotFoundError:
            # git not installed
            pass

        return ProjectInfo(
            project_dir=str(path),
            project_subdir=".",
            is_git=False,
            config=load_workspace_config(path),
        )

    # -- Name generation -----------------------------------------------------

    def _slugify(self, name: str) -> str:
        """Convert a name to a filesystem-safe, branch-safe slug."""
        slug = name.lower()
        # Replace non-alphanumeric with dashes
        slug = re.sub(r"[^a-z0-9]+", "-", slug)
        # Strip leading/trailing dashes
        slug = slug.strip("-")
        return slug or "workspace"

    def _short_id(self) -> str:
        """Generate a short random hex suffix."""
        return secrets.token_hex(3)

    def _project_slug(self, project_dir: str) -> str:
        """Generate a sanitized project slug with a short path hash."""
        basename = Path(project_dir).name
        slug = self._slugify(basename)
        path_hash = hashlib.sha256(project_dir.encode()).hexdigest()[:7]
        return f"{slug}-{path_hash}"

    def generate_workspace_name(
        self,
        config: WorkspaceConfig,
        *,
        session_name: str | None,
        project_dir: str,
        project_subdir: str,
    ) -> str:
        """Build a unique, filesystem-safe, branch-safe workspace name."""
        if session_name:
            base = self._slugify(session_name)
        else:
            base = self._slugify(Path(project_dir).name)

        short_id = self._short_id()
        variables = {
            "project_name": Path(project_dir).name,
            "project_slug": self._project_slug(project_dir),
            "session_name": session_name or Path(project_dir).name,
            "session_slug": base,
            "short_id": short_id,
        }

        name = render_template(config.workspace.name_template, variables)
        return self._slugify(name)

    # -- Base ref resolution -------------------------------------------------

    async def resolve_base_ref(
        self,
        project_dir: str,
        config: WorkspaceConfig,
        *,
        source_branch: str | None = None,
    ) -> str:
        """Determine the Git ref to base the new worktree on."""
        if source_branch is not None:
            return source_branch

        default_base = config.workspace.default_base

        if default_base == "current_branch":
            proc = await asyncio.create_subprocess_exec(
                "git", "-C", project_dir, "rev-parse", "--abbrev-ref", "HEAD",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await proc.communicate()
            if proc.returncode == 0:
                branch = stdout.decode().strip()
                if branch and branch != "HEAD":
                    return branch

            # Detached HEAD fallback
            proc = await asyncio.create_subprocess_exec(
                "git", "-C", project_dir, "rev-parse", "HEAD",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await proc.communicate()
            return stdout.decode().strip()

        if default_base == "repo_default_branch":
            proc = await asyncio.create_subprocess_exec(
                "git", "-C", project_dir,
                "symbolic-ref", "refs/remotes/origin/HEAD",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await proc.communicate()
            if proc.returncode == 0:
                ref = stdout.decode().strip()
                return ref.removeprefix("refs/remotes/origin/")
            return "main"

        # Explicit ref
        return default_base

    # -- Launch wrapper ------------------------------------------------------

    def build_launch_command(
        self,
        target_command: list[str],
        *,
        execution_dir: str,
        config: WorkspaceConfig,
        use_direnv: bool,
        target_type: str,
    ) -> list[str]:
        """Build the full command with launch wrapper + optional direnv.

        Returns the command list ready for subprocess execution.
        For pi, target_command is the pi args. For pty, it's ["bash", "-l"].
        """
        launch = config.launch
        has_launch = (
            launch is not None
            and launch.script is not None
            and target_type in launch.apply_to
        )

        if has_launch:
            assert launch is not None and launch.script is not None
            shell = launch.shell or "bash"
            script_body = launch.script.strip()
            wrapper_script = f"{script_body}\nexec \"$@\""
            inner = [shell, "-lc", wrapper_script, shell] + target_command
        else:
            inner = target_command

        if use_direnv and shutil.which("direnv") is not None:
            return ["direnv", "exec", execution_dir] + inner

        return inner

    # -- Workspace creation --------------------------------------------------

    async def create_workspace(
        self,
        project_info: ProjectInfo,
        *,
        session_name: str | None = None,
        source_branch: str | None = None,
        use_direnv: bool = True,
        worktree_root_override: Path | None = None,
    ) -> WorkspaceInfo:
        """Create a new Git worktree, copy files, run bootstrap."""
        config = project_info.config
        lock = self._get_project_lock(project_info.project_dir)

        async with lock:
            workspace_id = uuid.uuid4().hex[:12]
            workspace_name = self.generate_workspace_name(
                config,
                session_name=session_name,
                project_dir=project_info.project_dir,
                project_subdir=project_info.project_subdir,
            )

            # Resolve workspace root
            if worktree_root_override is not None:
                ws_root = worktree_root_override / workspace_name
            else:
                variables = {
                    "project_slug": self._project_slug(project_info.project_dir),
                }
                raw_root = render_template(config.workspace.root, variables)
                expanded = Path(os.path.expanduser(raw_root))
                validate_workspace_root(
                    expanded.resolve(), Path(project_info.project_dir).resolve()
                )
                ws_root = expanded / workspace_name

            # Resolve base ref and branch name
            base_ref = await self.resolve_base_ref(
                project_info.project_dir, config, source_branch=source_branch
            )

            workspace_branch: str | None = None
            if config.git.create_branch:
                branch_variables = {
                    "branch_prefix": config.workspace.branch_prefix,
                    "workspace_name": workspace_name,
                }
                workspace_branch = render_template(
                    config.git.branch_template, branch_variables
                )

            # Create the worktree
            await self._create_worktree(
                project_info.project_dir,
                str(ws_root),
                workspace_branch,
                base_ref,
                detach=config.git.detach,
            )

            # Compute execution dir
            if project_info.project_subdir != ".":
                execution_dir = str(ws_root / project_info.project_subdir)
            else:
                execution_dir = str(ws_root)

            # Materialize files
            await self._materialize_files(
                project_info.project_dir, str(ws_root), config
            )

            # Allow direnv in the new worktree if .envrc exists
            if use_direnv and (ws_root / ".envrc").exists():
                await self._allow_direnv(str(ws_root))

            # Run bootstrap
            bootstrap_log_path: str | None = None
            if config.bootstrap and config.bootstrap.script:
                bootstrap_log_path = await self._run_bootstrap(
                    str(ws_root), config, workspace_id=workspace_id, use_direnv=use_direnv
                )

            return WorkspaceInfo(
                workspace_id=workspace_id,
                workspace_name=workspace_name,
                workspace_root=str(ws_root),
                workspace_branch=workspace_branch,
                workspace_base_ref=base_ref,
                execution_dir=execution_dir,
                bootstrap_log_path=bootstrap_log_path,
            )

    async def _create_worktree(
        self,
        project_dir: str,
        workspace_root: str,
        branch_name: str | None,
        base_ref: str,
        *,
        detach: bool = False,
    ) -> None:
        """Execute git worktree add."""
        cmd = ["git", "-C", project_dir, "worktree", "add"]
        if detach:
            cmd += ["--detach", workspace_root, base_ref]
        elif branch_name:
            cmd += [workspace_root, "-b", branch_name, base_ref]
        else:
            cmd += [workspace_root, base_ref]

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            error_text = stderr.decode(errors="replace").strip()
            raise RuntimeError(
                f"git worktree add failed (exit {proc.returncode}): {error_text}"
            )

    # -- File materialization ------------------------------------------------

    async def _materialize_files(
        self,
        project_dir: str,
        workspace_root: str,
        config: WorkspaceConfig,
    ) -> None:
        """Copy and symlink configured files from project to workspace."""
        project = Path(project_dir)
        workspace = Path(workspace_root)

        # Copy files
        copy_paths = config.files.copy_paths
        if copy_paths:
            validate_file_paths(copy_paths)
            for rel in copy_paths:
                src = project / rel
                dst = workspace / rel
                if not src.exists():
                    logger.warning("File to copy not found, skipping: %s", src)
                    continue
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(src), str(dst))

        # Symlink files
        if config.files.symlink:
            validate_file_paths(config.files.symlink)
            for rel in config.files.symlink:
                src = project / rel
                dst = workspace / rel
                if not src.exists():
                    logger.warning("File to symlink not found, skipping: %s", src)
                    continue
                dst.parent.mkdir(parents=True, exist_ok=True)
                if dst.exists() or dst.is_symlink():
                    dst.unlink()
                dst.symlink_to(src.resolve())

    # -- Bootstrap -----------------------------------------------------------

    async def _run_bootstrap(
        self,
        workspace_root: str,
        config: WorkspaceConfig,
        *,
        workspace_id: str,
        use_direnv: bool,
    ) -> str:
        """Run bootstrap script. Returns log path."""
        assert config.bootstrap is not None and config.bootstrap.script is not None

        log_dir = self._data_dir / "workspace-logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / f"{workspace_id}-bootstrap.log"

        shell = config.bootstrap.shell or "bash"
        timeout = config.bootstrap.timeout_seconds

        with open(log_path, "w") as log_file:
            proc = await asyncio.create_subprocess_exec(
                shell, "-lc", config.bootstrap.script,
                cwd=workspace_root,
                stdout=log_file,
                stderr=asyncio.subprocess.STDOUT,
            )
            try:
                await asyncio.wait_for(proc.wait(), timeout=timeout)
            except TimeoutError:
                proc.kill()
                await proc.wait()
                raise RuntimeError(
                    f"Bootstrap timed out after {timeout}s. Log: {log_path}"
                )

        if proc.returncode != 0:
            raise RuntimeError(
                f"Bootstrap failed (exit {proc.returncode}). Log: {log_path}"
            )

        return str(log_path)

    # -- Direnv --------------------------------------------------------------

    async def _allow_direnv(self, workspace_root: str) -> None:
        """Run direnv allow in a workspace so .envrc is trusted."""
        if shutil.which("direnv") is None:
            return
        proc = await asyncio.create_subprocess_exec(
            "direnv", "allow", workspace_root,
            cwd=workspace_root,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        if proc.returncode != 0:
            logger.warning(
                "direnv allow failed in %s: %s",
                workspace_root,
                stderr.decode(errors="replace").strip(),
            )
        else:
            logger.info("Approved direnv for worktree %s", workspace_root)

    # -- Workspace validation ------------------------------------------------

    async def validate_workspace(
        self,
        workspace_root: str,
        project_dir: str,
    ) -> tuple[bool, str | None]:
        """Validate that an existing workspace is still usable."""
        ws = Path(workspace_root)
        if not ws.is_dir():
            return False, f"Workspace directory does not exist: {workspace_root}"

        # Check that it's a valid git worktree
        git_file = ws / ".git"
        if not git_file.exists():
            return False, f"Workspace is not a valid git worktree: {workspace_root}"

        return True, None

    # -- Workspace removal ---------------------------------------------------

    async def remove_workspace(
        self,
        workspace_root: str,
        project_dir: str,
        *,
        force: bool = False,
    ) -> None:
        """Remove a Git worktree and clean up."""
        cmd = ["git", "-C", project_dir, "worktree", "remove"]
        if force:
            cmd.append("--force")
        cmd.append(workspace_root)

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        if proc.returncode != 0:
            error_text = stderr.decode(errors="replace").strip()
            raise RuntimeError(
                f"git worktree remove failed: {error_text}"
            )


def _default_data_dir() -> Path:
    """Return the canonical piface data directory."""
    import sys

    if sys.platform.startswith("linux"):
        return Path.home() / ".local" / "share" / "piface"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "piface"
    return Path(user_data_dir("piface", appauthor=False))
