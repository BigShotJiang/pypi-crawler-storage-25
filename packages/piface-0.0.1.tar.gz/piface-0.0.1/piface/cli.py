"""CLI entry point: piface serve [--port] [--host] [--dev]."""

from __future__ import annotations

import logging

import typer
import uvicorn

app = typer.Typer(name="piface", help="Web-based remote interface for pi.")


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context) -> None:
    """Piface — web-based remote interface for pi."""
    if ctx.invoked_subcommand is None:
        # Default to serve if no subcommand given
        ctx.invoke(serve)


@app.command("serve")
def serve(
    port: int = typer.Option(7832, help="Server port"),
    host: str = typer.Option("0.0.0.0", help="Bind address"),
    dev: bool = typer.Option(False, help="Dev mode: proxy frontend to Svelte dev server"),
    direnv: bool = typer.Option(
        True,
        "--direnv/--no-direnv",
        help="Use direnv for spawned pi sessions when available",
    ),
    speech: bool = typer.Option(
        True,
        "--speech/--no-speech",
        help="Enable voice transcription endpoints",
    ),
    speech_model: str = typer.Option(
        "nvidia/parakeet-tdt-0.6b-v3",
        help="Parakeet model name for speech transcription",
    ),
    speech_gpu: bool = typer.Option(
        True,
        "--speech-gpu/--speech-cpu",
        help="Prefer GPU for speech transcription when CUDA is available",
    ),
    tts: bool = typer.Option(
        True,
        "--tts/--no-tts",
        help="Enable assistant text-to-speech endpoints",
    ),
    tts_model: str = typer.Option(
        "tts_models/en/ljspeech/vits",
        help="Coqui TTS model name for assistant speech playback",
    ),
    tts_gpu: bool = typer.Option(
        True,
        "--tts-gpu/--tts-cpu",
        help="Prefer GPU for assistant text-to-speech when CUDA is available",
    ),
) -> None:
    """Start the piface server."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    from piface.server import create_app

    app_instance = create_app(
        dev=dev,
        use_direnv_default=direnv,
        speech_enabled=speech,
        speech_model=speech_model,
        speech_prefer_gpu=speech_gpu,
        tts_enabled=tts,
        tts_model=tts_model,
        tts_prefer_gpu=tts_gpu,
    )
    uvicorn.run(app_instance, host=host, port=port, log_level="info")
