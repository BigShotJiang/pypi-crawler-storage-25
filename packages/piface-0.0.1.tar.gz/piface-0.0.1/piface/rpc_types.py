"""Pydantic models for the pi RPC protocol (commands, events, responses)."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Commands (browser/piface → pi stdin)
# ---------------------------------------------------------------------------


class _BaseCommand(BaseModel):
    """Base for all RPC commands sent to pi."""

    id: str | None = None

    def to_line(self) -> str:
        """Serialize to a JSON line (no trailing newline)."""
        return self.model_dump_json(exclude_none=True)


# --- Prompting ---


class PromptCommand(_BaseCommand):
    type: Literal["prompt"] = "prompt"
    message: str
    images: list[dict[str, Any]] | None = None
    streamingBehavior: Literal["steer", "followUp"] | None = None


class SteerCommand(_BaseCommand):
    type: Literal["steer"] = "steer"
    message: str
    images: list[dict[str, Any]] | None = None


class FollowUpCommand(_BaseCommand):
    type: Literal["follow_up"] = "follow_up"
    message: str
    images: list[dict[str, Any]] | None = None


class AbortCommand(_BaseCommand):
    type: Literal["abort"] = "abort"


# --- State ---


class GetStateCommand(_BaseCommand):
    type: Literal["get_state"] = "get_state"


class GetMessagesCommand(_BaseCommand):
    type: Literal["get_messages"] = "get_messages"


# --- Model ---


class SetModelCommand(_BaseCommand):
    type: Literal["set_model"] = "set_model"
    provider: str
    modelId: str


class CycleModelCommand(_BaseCommand):
    type: Literal["cycle_model"] = "cycle_model"


class GetAvailableModelsCommand(_BaseCommand):
    type: Literal["get_available_models"] = "get_available_models"


# --- Thinking ---


class SetThinkingLevelCommand(_BaseCommand):
    type: Literal["set_thinking_level"] = "set_thinking_level"
    level: Literal["off", "minimal", "low", "medium", "high", "xhigh"]


class CycleThinkingLevelCommand(_BaseCommand):
    type: Literal["cycle_thinking_level"] = "cycle_thinking_level"


# --- Queue Modes ---


class SetSteeringModeCommand(_BaseCommand):
    type: Literal["set_steering_mode"] = "set_steering_mode"
    mode: Literal["all", "one-at-a-time"]


class SetFollowUpModeCommand(_BaseCommand):
    type: Literal["set_follow_up_mode"] = "set_follow_up_mode"
    mode: Literal["all", "one-at-a-time"]


# --- Session ---


class NewSessionCommand(_BaseCommand):
    type: Literal["new_session"] = "new_session"
    parentSession: str | None = None


class SwitchSessionCommand(_BaseCommand):
    type: Literal["switch_session"] = "switch_session"
    sessionPath: str


class ForkCommand(_BaseCommand):
    type: Literal["fork"] = "fork"
    entryId: str


class GetForkMessagesCommand(_BaseCommand):
    type: Literal["get_fork_messages"] = "get_fork_messages"


class GetSessionStatsCommand(_BaseCommand):
    type: Literal["get_session_stats"] = "get_session_stats"


class ExportHtmlCommand(_BaseCommand):
    type: Literal["export_html"] = "export_html"
    outputPath: str | None = None


class GetLastAssistantTextCommand(_BaseCommand):
    type: Literal["get_last_assistant_text"] = "get_last_assistant_text"


class SetSessionNameCommand(_BaseCommand):
    type: Literal["set_session_name"] = "set_session_name"
    name: str


# --- Compaction ---


class CompactCommand(_BaseCommand):
    type: Literal["compact"] = "compact"
    customInstructions: str | None = None


class SetAutoCompactionCommand(_BaseCommand):
    type: Literal["set_auto_compaction"] = "set_auto_compaction"
    enabled: bool


# --- Retry ---


class SetAutoRetryCommand(_BaseCommand):
    type: Literal["set_auto_retry"] = "set_auto_retry"
    enabled: bool


class AbortRetryCommand(_BaseCommand):
    type: Literal["abort_retry"] = "abort_retry"


# --- Bash ---


class BashCommand(_BaseCommand):
    type: Literal["bash"] = "bash"
    command: str


class AbortBashCommand(_BaseCommand):
    type: Literal["abort_bash"] = "abort_bash"


# --- Commands ---


class GetCommandsCommand(_BaseCommand):
    type: Literal["get_commands"] = "get_commands"


# --- Extension UI Response (browser → piface → pi stdin) ---


class ExtensionUIResponse(BaseModel):
    type: Literal["extension_ui_response"] = "extension_ui_response"
    id: str
    value: str | None = None
    confirmed: bool | None = None
    cancelled: bool | None = None

    def to_line(self) -> str:
        return self.model_dump_json(exclude_none=True)


# Union of all command types for convenience
RpcCommand = (
    PromptCommand
    | SteerCommand
    | FollowUpCommand
    | AbortCommand
    | GetStateCommand
    | GetMessagesCommand
    | SetModelCommand
    | CycleModelCommand
    | GetAvailableModelsCommand
    | SetThinkingLevelCommand
    | CycleThinkingLevelCommand
    | SetSteeringModeCommand
    | SetFollowUpModeCommand
    | NewSessionCommand
    | SwitchSessionCommand
    | ForkCommand
    | GetForkMessagesCommand
    | GetSessionStatsCommand
    | ExportHtmlCommand
    | GetLastAssistantTextCommand
    | SetSessionNameCommand
    | CompactCommand
    | SetAutoCompactionCommand
    | SetAutoRetryCommand
    | AbortRetryCommand
    | BashCommand
    | AbortBashCommand
    | GetCommandsCommand
    | ExtensionUIResponse
)

# Mapping from type string → model class
_COMMAND_MAP: dict[str, type[BaseModel]] = {
    "prompt": PromptCommand,
    "steer": SteerCommand,
    "follow_up": FollowUpCommand,
    "abort": AbortCommand,
    "get_state": GetStateCommand,
    "get_messages": GetMessagesCommand,
    "set_model": SetModelCommand,
    "cycle_model": CycleModelCommand,
    "get_available_models": GetAvailableModelsCommand,
    "set_thinking_level": SetThinkingLevelCommand,
    "cycle_thinking_level": CycleThinkingLevelCommand,
    "set_steering_mode": SetSteeringModeCommand,
    "set_follow_up_mode": SetFollowUpModeCommand,
    "new_session": NewSessionCommand,
    "switch_session": SwitchSessionCommand,
    "fork": ForkCommand,
    "get_fork_messages": GetForkMessagesCommand,
    "get_session_stats": GetSessionStatsCommand,
    "export_html": ExportHtmlCommand,
    "get_last_assistant_text": GetLastAssistantTextCommand,
    "set_session_name": SetSessionNameCommand,
    "compact": CompactCommand,
    "set_auto_compaction": SetAutoCompactionCommand,
    "set_auto_retry": SetAutoRetryCommand,
    "abort_retry": AbortRetryCommand,
    "bash": BashCommand,
    "abort_bash": AbortBashCommand,
    "get_commands": GetCommandsCommand,
    "extension_ui_response": ExtensionUIResponse,
}


def parse_command(raw: dict[str, Any]) -> RpcCommand | None:
    """Parse a raw dict into a typed command model. Returns None if unknown."""
    cmd_type = raw.get("type")
    cls = _COMMAND_MAP.get(cmd_type)  # type: ignore[arg-type]
    if cls is None:
        return None
    return cls.model_validate(raw)  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# Events / Responses (pi stdout → piface → browser)
# ---------------------------------------------------------------------------


class RpcResponse(BaseModel):
    """A response to a command (type='response')."""

    type: Literal["response"] = "response"
    id: str | None = None
    command: str
    success: bool
    data: Any | None = None
    error: str | None = None


class RpcEvent(BaseModel):
    """Any event from pi stdout. We keep the raw dict for full fidelity."""

    type: str
    raw: dict[str, Any] = Field(default_factory=dict)


def parse_event(raw: dict[str, Any]) -> RpcResponse | RpcEvent:
    """Parse a raw event dict from pi stdout."""
    if raw.get("type") == "response":
        return RpcResponse.model_validate(raw)
    return RpcEvent(type=raw.get("type", "unknown"), raw=raw)
