"""Auto-build the Svelte frontend if stale or missing."""

from __future__ import annotations

import logging
import shutil
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

FRONTEND_DIR = Path(__file__).parent.parent / "frontend"
DIST_DIR = FRONTEND_DIR / "dist"
STATIC_DIR = Path(__file__).parent / "static"


def _newest_mtime(directory: Path, extensions: set[str] | None = None) -> float:
    """Return the newest mtime of any file under directory."""
    newest = 0.0
    if not directory.is_dir():
        return newest
    for p in directory.rglob("*"):
        if p.is_file():
            if extensions and p.suffix not in extensions:
                continue
            newest = max(newest, p.stat().st_mtime)
    return newest


def is_build_stale() -> bool:
    """Check if frontend/dist is missing or older than frontend/src."""
    if not FRONTEND_DIR.is_dir():
        logger.info("No frontend/ directory found — skipping build")
        return False

    index = DIST_DIR / "index.html"
    if not index.exists():
        return True

    src_mtime = _newest_mtime(FRONTEND_DIR / "src")
    dist_mtime = index.stat().st_mtime
    return src_mtime > dist_mtime


def build_frontend() -> bool:
    """Run pnpm install + build in frontend/. Returns True on success."""
    if not FRONTEND_DIR.is_dir():
        logger.warning("No frontend/ directory — cannot build")
        return False

    pnpm = shutil.which("pnpm")
    if pnpm is None:
        logger.error("pnpm not found on PATH. Install it: npm install -g pnpm")
        return False

    logger.info("Installing frontend dependencies…")
    result = subprocess.run(
        [pnpm, "install"],
        cwd=FRONTEND_DIR,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        logger.error("pnpm install failed:\n%s", result.stderr)
        return False

    logger.info("Building frontend…")
    result = subprocess.run(
        [pnpm, "build"],
        cwd=FRONTEND_DIR,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        logger.error("pnpm build failed:\n%s", result.stderr)
        return False

    logger.info("Frontend built successfully")
    return True


def sync_static() -> bool:
    """Copy frontend/dist → piface/static/ so FastAPI can serve it."""
    if not DIST_DIR.is_dir():
        return False

    if STATIC_DIR.exists():
        shutil.rmtree(STATIC_DIR)
    shutil.copytree(DIST_DIR, STATIC_DIR)
    logger.info("Synced frontend/dist → piface/static/")
    return True


def ensure_frontend(*, force: bool = False) -> None:
    """Build frontend if stale and sync to static dir. Called on server startup."""
    if force or is_build_stale():
        logger.info("Frontend build is stale or missing — rebuilding…")
        if build_frontend():
            sync_static()
        else:
            logger.warning("Frontend build failed — serving without frontend")
    elif DIST_DIR.is_dir() and not STATIC_DIR.is_dir():
        # dist exists but static doesn't — just sync
        sync_static()
    elif STATIC_DIR.is_dir():
        logger.info("Frontend is up to date")
    else:
        logger.info("No frontend to serve")
