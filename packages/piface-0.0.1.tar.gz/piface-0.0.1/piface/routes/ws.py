"""WebSocket relay: browser ↔ piface ↔ pi subprocess."""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from collections.abc import MutableSet

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from piface.session_manager import (
    _INTERNAL_QUERY_PREFIX,
    _SESSION_FILE_QUERY_PREFIX,
    SessionManager,
)

logger = logging.getLogger(__name__)

# Per-session set of connected WebSocket clients
_ws_clients: dict[str, MutableSet[WebSocket]] = {}

# Per-session asyncio.Queue for events from pi → WebSocket clients
_event_queues: dict[str, asyncio.Queue[dict]] = {}

# Per-session map of pending bash request id -> command text.
# Used to enrich bash responses with the command string (pi omits it).
_pending_bash_commands: dict[str, dict[str, str]] = {}


def get_clients(session_id: str) -> MutableSet[WebSocket]:
    """Get the set of WebSocket clients for a session."""
    if session_id not in _ws_clients:
        _ws_clients[session_id] = set()
    return _ws_clients[session_id]


def create_ws_router() -> APIRouter:
    router = APIRouter()

    @router.websocket("/ws/sessions/{session_id}")
    async def session_ws(websocket: WebSocket, session_id: str) -> None:
        mgr: SessionManager = websocket.app.state.session_manager

        # Validate session exists and is alive
        pi_session = mgr.get_session(session_id)
        if pi_session is None or not pi_session.is_alive:
            await websocket.close(code=4004, reason="Session not found or not alive")
            return

        await websocket.accept()
        clients = get_clients(session_id)
        clients.add(websocket)

        # Send initial session state
        record = mgr.get_record(session_id)
        if record:
            await websocket.send_json(
                {
                    "type": "piface_session_state",
                    "session": record.model_dump(mode="json"),
                }
            )

        # Set up event queue + forwarding from pi → WebSocket clients
        queue = _ensure_event_queue(session_id)
        _install_broadcast(session_id, mgr, queue)

        # Start a task to drain the event queue and broadcast
        drain_task = asyncio.create_task(_drain_queue(session_id, queue))

        try:
            while True:
                data = await websocket.receive_text()
                try:
                    msg = json.loads(data)
                except json.JSONDecodeError:
                    await websocket.send_json(
                        {
                            "type": "piface_error",
                            "message": "Invalid JSON",
                        }
                    )
                    continue

                msg_type = msg.get("type")

                if msg_type == "piface_get_history":
                    await mgr.send_to_session(
                        session_id,
                        {
                            "type": "get_messages",
                            "id": "__piface_replay__",
                        },
                    )
                    continue

                if msg_type in {"prompt", "steer", "follow_up"}:
                    maybe_bash = _parse_bang_bash_shortcut(msg)
                    if maybe_bash is not None:
                        command, exclude_from_context = maybe_bash
                        if msg.get("piface_upload_ids"):
                            await websocket.send_json(
                                {
                                    "type": "piface_error",
                                    "message": (
                                        "Bash shortcuts (! / !!) do not support file attachments."
                                    ),
                                }
                            )
                            continue

                        cmd_id = _ensure_command_id(msg)
                        if exclude_from_context:
                            local_response = await _run_local_bash(
                                mgr,
                                session_id,
                                command=command,
                                command_id=cmd_id,
                            )
                            await queue.put(local_response)
                            continue

                        bash_msg = {
                            "type": "bash",
                            "id": cmd_id,
                            "command": command,
                        }
                        _remember_pending_bash_command(session_id, cmd_id, command)
                        await mgr.send_to_session(session_id, bash_msg)
                        continue

                    try:
                        _rewrite_message_with_uploads(mgr, session_id, msg)
                    except ValueError as exc:
                        await websocket.send_json(
                            {
                                "type": "piface_error",
                                "message": str(exc),
                            }
                        )
                        continue

                if msg_type == "bash":
                    command = msg.get("command")
                    if isinstance(command, str):
                        cmd_id = _ensure_command_id(msg)
                        _remember_pending_bash_command(session_id, cmd_id, command)

                await mgr.send_to_session(session_id, msg)

        except WebSocketDisconnect:
            pass
        except Exception:
            logger.exception("WebSocket error for session %s", session_id)
        finally:
            clients.discard(websocket)
            drain_task.cancel()
            if not clients:
                _ws_clients.pop(session_id, None)
                _event_queues.pop(session_id, None)
                _pending_bash_commands.pop(session_id, None)

    @router.websocket("/ws/sessions/{session_id}/terminal")
    async def terminal_ws(websocket: WebSocket, session_id: str) -> None:
        mgr: SessionManager = websocket.app.state.session_manager

        # Validate session exists and is alive
        pi_session = mgr.get_session(session_id)
        if pi_session is None or not pi_session.is_alive:
            await websocket.close(code=4004, reason="Session not found or not alive")
            return

        await websocket.accept()

        # Get or create a persistent PTY for this session
        try:
            pty_session = mgr.get_or_create_pty(session_id)
        except Exception:
            logger.exception("Failed to create PTY for session %s", session_id)
            await websocket.close(code=1011, reason="Failed to create terminal")
            return

        # Wire PTY output → WebSocket (thread-safe via call_soon_threadsafe)
        loop = asyncio.get_running_loop()
        output_queue: asyncio.Queue[bytes] = asyncio.Queue()

        def on_pty_output(data: bytes) -> None:
            try:
                loop.call_soon_threadsafe(output_queue.put_nowait, data)
            except RuntimeError:
                pass

        pty_session.on_output = on_pty_output
        pty_session.start_reading()

        async def drain_pty_output() -> None:
            try:
                while True:
                    data = await output_queue.get()
                    await websocket.send_bytes(data)
            except asyncio.CancelledError:
                return
            except Exception:
                return

        drain_task = asyncio.create_task(drain_pty_output())

        try:
            while True:
                msg = await websocket.receive()
                msg_type = msg.get("type")

                if msg_type == "websocket.disconnect":
                    break

                # Binary data → terminal input
                raw = msg.get("bytes")
                if raw is not None:
                    pty_session.write(raw)
                    continue

                # Text data → JSON control message (resize)
                text = msg.get("text")
                if text is not None:
                    try:
                        ctrl = json.loads(text)
                    except json.JSONDecodeError:
                        continue
                    if ctrl.get("type") == "resize":
                        try:
                            cols = max(1, min(500, int(ctrl.get("cols", 80))))
                            rows = max(1, min(200, int(ctrl.get("rows", 24))))
                        except (TypeError, ValueError):
                            continue
                        pty_session.resize(cols, rows)
                    continue

        except WebSocketDisconnect:
            pass
        except Exception:
            logger.exception("Terminal WebSocket error for session %s", session_id)
        finally:
            drain_task.cancel()
            # Do NOT close pty_session — it persists across reconnections

    return router


def _parse_bang_bash_shortcut(msg: dict) -> tuple[str, bool] | None:
    """Parse ! / !! prompt shortcuts.

    Returns:
        (command, exclude_from_context)
        - exclude_from_context=True for !!
    """
    message = msg.get("message")
    if not isinstance(message, str) or not message.startswith("!"):
        return None

    if message.startswith("!!"):
        command = message[2:].lstrip()
        exclude = True
    else:
        command = message[1:].lstrip()
        exclude = False

    if not command:
        return None

    return command, exclude


def _ensure_command_id(msg: dict) -> str:
    existing_id = msg.get("id")
    if isinstance(existing_id, str) and existing_id.strip():
        return existing_id

    generated_id = f"__piface_cmd_{uuid.uuid4().hex}"
    msg["id"] = generated_id
    return generated_id


def _remember_pending_bash_command(session_id: str, command_id: str, command: str) -> None:
    by_id = _pending_bash_commands.setdefault(session_id, {})
    by_id[command_id] = command


async def _run_local_bash(
    mgr: SessionManager,
    session_id: str,
    *,
    command: str,
    command_id: str,
) -> dict:
    """Execute a !! command locally and return a pi-like bash response event."""
    record = mgr.get_record(session_id)
    cwd = record.effective_execution_dir if record is not None else None

    if not cwd:
        return {
            "type": "response",
            "id": command_id,
            "command": "bash",
            "success": False,
            "error": "Session working directory is not available",
        }

    try:
        process = await asyncio.create_subprocess_exec(
            "bash",
            "-lc",
            command,
            cwd=cwd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await process.communicate()
        output = (stdout + stderr).decode(errors="replace")

        return {
            "type": "response",
            "id": command_id,
            "command": "bash",
            "success": True,
            "data": {
                "output": output,
                "exitCode": process.returncode,
                "cancelled": False,
                "truncated": False,
                "command": command,
                "excludeFromContext": True,
            },
        }
    except Exception as exc:
        logger.exception("Local !! bash command failed for session %s", session_id)
        return {
            "type": "response",
            "id": command_id,
            "command": "bash",
            "success": False,
            "error": str(exc),
        }


def _rewrite_message_with_uploads(mgr: SessionManager, session_id: str, msg: dict) -> None:
    """Rewrite prompt-like messages that reference uploaded file IDs."""
    upload_ids = msg.pop("piface_upload_ids", None)
    if upload_ids is None:
        return

    if not isinstance(upload_ids, list):
        raise ValueError("piface_upload_ids must be a list")

    if not upload_ids:
        return

    upload_paths = mgr.resolve_upload_paths(session_id, upload_ids)
    message = msg.get("message", "")
    if not isinstance(message, str):
        raise ValueError("message must be a string")

    msg["message"] = mgr.inject_upload_paths_into_message(message, upload_paths)


def _ensure_event_queue(session_id: str) -> asyncio.Queue[dict]:
    """Get or create the event queue for a session."""
    if session_id not in _event_queues:
        _event_queues[session_id] = asyncio.Queue()
    return _event_queues[session_id]


def _install_broadcast(session_id: str, mgr: SessionManager, queue: asyncio.Queue[dict]) -> None:
    """Install an on_event callback that puts events into the queue (thread-safe)."""
    pi_session = mgr.get_session(session_id)
    if pi_session is None:
        return

    loop = asyncio.get_running_loop()

    def on_event(event: dict) -> None:
        # This callback fires from the reader task — always use call_soon_threadsafe
        # to put into the queue, in case we're on a different thread.
        try:
            loop.call_soon_threadsafe(queue.put_nowait, event)
        except RuntimeError:
            pass

    pi_session.on_event = on_event


async def _drain_queue(session_id: str, queue: asyncio.Queue[dict]) -> None:
    """Drain events from the queue and send to all connected WebSocket clients."""
    try:
        while True:
            event = await queue.get()
            clients = get_clients(session_id)
            if not clients:
                continue

            # Filter out internal piface events (session file capture, etc.)
            event_id = event.get("id", "")
            if isinstance(event_id, str) and (
                event_id.startswith(_SESSION_FILE_QUERY_PREFIX)
                or event_id.startswith(_INTERNAL_QUERY_PREFIX)
            ):
                continue

            # Special handling for replay response
            if (
                event.get("type") == "response"
                and event_id == "__piface_replay__"
                and event.get("success")
            ):
                event = {
                    "type": "piface_replay",
                    "messages": event.get("data", {}).get("messages", []),
                }

            # Enrich bash responses with command text.
            if (
                event.get("type") == "response"
                and event.get("command") == "bash"
                and event.get("success")
            ):
                by_id = _pending_bash_commands.get(session_id, {})
                command_id = event.get("id")
                command = by_id.pop(command_id, None) if isinstance(command_id, str) else None
                if command:
                    data = event.get("data")
                    if isinstance(data, dict) and "command" not in data:
                        event = {
                            **event,
                            "data": {
                                **data,
                                "command": command,
                            },
                        }

            for ws in list(clients):
                try:
                    await ws.send_json(event)
                except Exception:
                    clients.discard(ws)
    except asyncio.CancelledError:
        return
