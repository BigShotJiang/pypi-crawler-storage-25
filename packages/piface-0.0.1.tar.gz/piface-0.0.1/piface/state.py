"""Persistent JSON state for piface sessions."""

from __future__ import annotations

import enum
import logging
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Literal

from platformdirs import user_data_dir
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class SessionStatus(enum.StrEnum):
    LIVE = "live"
    CLOSED = "closed"


class SessionRecord(BaseModel):
    """Metadata for a single piface-managed pi session."""

    piface_id: str
    working_dir: str
    status: SessionStatus

    session_file: str | None = None
    no_session: bool = False
    use_direnv: bool = True

    model_provider: str | None = None
    model_id: str | None = None
    thinking_level: str | None = None
    session_name: str | None = None
    render_markdown: bool = True

    parent_piface_id: str | None = None
    branch_entry_id: str | None = None

    # Workspace fields (all optional with defaults for backward compatibility)
    project_dir: str | None = None
    project_subdir: str = "."
    execution_dir: str | None = None
    workspace_mode: Literal["shared", "git_worktree"] = "shared"
    workspace_id: str | None = None
    workspace_name: str | None = None
    workspace_root: str | None = None
    workspace_branch: str | None = None
    workspace_base_ref: str | None = None
    workspace_theme_override: Literal["light", "dark"] | None = None
    workspace_skin_override: (
        Literal[
            "default",
            "beos",
            "facebook2007",
            "nintendo",
            "nintendo-nes",
            "windows98",
            "winamp",
            "protoss",
            "terran",
            "zerg",
            "synthwave",
            "macos8",
        ]
        | None
    ) = None
    workspace_created_by_piface: bool = False
    workspace_status: Literal["ready", "error", "deleted"] = "ready"
    workspace_error: str | None = None
    bootstrap_log_path: str | None = None
    launch_log_path: str | None = None

    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    last_active: datetime = Field(default_factory=lambda: datetime.now(UTC))

    @property
    def effective_execution_dir(self) -> str:
        """Return execution_dir if set, otherwise fall back to working_dir."""
        return self.execution_dir or self.working_dir

    @property
    def effective_project_dir(self) -> str:
        """Return project_dir if set, otherwise fall back to working_dir."""
        return self.project_dir or self.working_dir


class UploadBlobRecord(BaseModel):
    """Shared upload blob metadata with per-session references."""

    upload_id: str
    path: str
    file_name: str
    mime_type: str
    size: int
    ref_sessions: list[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class PifaceState(BaseModel):
    """Top-level persistent state."""

    sessions: dict[str, SessionRecord] = Field(default_factory=dict)
    uploads: dict[str, UploadBlobRecord] = Field(default_factory=dict)
    session_upload_ids: dict[str, list[str]] = Field(default_factory=dict)


def _canonical_data_dir() -> Path:
    """Return the canonical app data directory (stable across launch environments)."""
    if sys.platform.startswith("linux"):
        # Keep Linux state under ~/.local/share even when XDG_DATA_HOME is
        # overridden by sandboxed launchers (e.g. snap code revisions).
        return Path.home() / ".local" / "share" / "piface"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "piface"
    return Path(user_data_dir("piface", appauthor=False))


def default_state_path() -> Path:
    """Return the canonical state file path."""
    return _canonical_data_dir() / "state.json"


def _load_state_file(path: Path) -> PifaceState | None:
    if not path.exists():
        return None
    try:
        return PifaceState.model_validate_json(path.read_text())
    except Exception:
        logger.warning("Failed to parse state file %s; skipping", path)
        return None


def _legacy_state_paths(primary: Path) -> list[Path]:
    """Find legacy state locations used by environment-dependent paths."""
    candidates: set[Path] = set()

    env_path = Path(user_data_dir("piface", appauthor=False)) / "state.json"
    if env_path != primary:
        candidates.add(env_path)

    if sys.platform.startswith("linux"):
        snap_root = Path.home() / "snap"
        if snap_root.is_dir():
            for app_dir in snap_root.iterdir():
                if not app_dir.is_dir():
                    continue
                for rev_dir in app_dir.iterdir():
                    if not rev_dir.is_dir():
                        continue
                    if rev_dir.name != "current" and not rev_dir.name.isdigit():
                        continue
                    candidate = rev_dir / ".local" / "share" / "piface" / "state.json"
                    if candidate != primary:
                        candidates.add(candidate)

    return sorted(candidates)


def _merge_states(states: list[PifaceState]) -> PifaceState:
    merged = PifaceState()

    for state in states:
        for session_id, session in state.sessions.items():
            existing = merged.sessions.get(session_id)
            if existing is None or session.last_active >= existing.last_active:
                merged.sessions[session_id] = session

        for upload_id, upload in state.uploads.items():
            existing_upload = merged.uploads.get(upload_id)
            if existing_upload is None:
                merged.uploads[upload_id] = upload
                continue

            newest = (
                upload.model_copy(deep=True)
                if upload.created_at >= existing_upload.created_at
                else existing_upload.model_copy(deep=True)
            )
            newest.ref_sessions = list(
                dict.fromkeys([*existing_upload.ref_sessions, *upload.ref_sessions])
            )
            merged.uploads[upload_id] = newest

        for session_id, upload_ids in state.session_upload_ids.items():
            merged_ids = merged.session_upload_ids.setdefault(session_id, [])
            for upload_id in upload_ids:
                if upload_id not in merged_ids:
                    merged_ids.append(upload_id)

    return merged


def load_state(path: Path | None = None) -> PifaceState:
    """Load state from disk. Returns empty state if file missing or corrupt."""
    if path is not None:
        loaded = _load_state_file(path)
        return loaded if loaded is not None else PifaceState()

    primary = default_state_path()
    states: list[PifaceState] = []

    primary_state = _load_state_file(primary)
    if primary_state is not None:
        states.append(primary_state)

    for legacy_path in _legacy_state_paths(primary):
        legacy_state = _load_state_file(legacy_path)
        if legacy_state is not None:
            states.append(legacy_state)

    if not states:
        return PifaceState()

    merged = _merge_states(states)

    primary_json = primary_state.model_dump(mode="json") if primary_state is not None else None
    merged_json = merged.model_dump(mode="json")
    if primary_json != merged_json:
        save_state(merged, primary)

    return merged


def save_state(state: PifaceState, path: Path | None = None) -> None:
    """Write state to disk, creating parent dirs as needed."""
    path = path or default_state_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(state.model_dump_json(indent=2))
