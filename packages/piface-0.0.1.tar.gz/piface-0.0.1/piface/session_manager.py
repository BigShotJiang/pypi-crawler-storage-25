"""Manages all pi subprocess sessions for piface."""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from piface.pi_session import PiSession, PiSessionConfig
from piface.pty_manager import PtySession
from piface.state import (
    PifaceState,
    SessionRecord,
    SessionStatus,
    UploadBlobRecord,
    load_state,
    save_state,
)
from piface.workspace_config import load_workspace_config
from piface.workspace_manager import WorkspaceManager

logger = logging.getLogger(__name__)

# Sentinel ID used for internal get_state queries
_SESSION_FILE_QUERY_PREFIX = "__piface_session_file_"
# Sentinel prefix for all other internal RPC queries
_INTERNAL_QUERY_PREFIX = "__piface_internal_"

_TRANSCRIPT_CLEANUP_PROMPT_TEMPLATE = """
Rewrite the following speech-to-text transcript for a coding assistant chat.
Return only the cleaned transcript.

Rules:
- Preserve meaning and intent.
- Fix punctuation, capitalization, and obvious transcription mistakes.
- Preserve commands, file paths, code snippets, and technical names exactly when possible.
- Do not add facts that are not present in the input.

INPUT:
{transcript}
"""


class SessionManager:
    """Owns all PiSession instances; handles spawn, kill, restore, and persistence."""

    def __init__(
        self,
        state_path: Path | None = None,
        use_direnv_default: bool = True,
        workspace_manager: WorkspaceManager | None = None,
    ) -> None:
        # None means: use canonical state path plus legacy merge behavior in
        # piface.state.load_state().
        self.state_path = state_path
        self.use_direnv_default = use_direnv_default
        self.sessions: dict[str, PiSession] = {}
        self.pty_sessions: dict[str, PtySession] = {}
        self._cached_models: list[dict[str, Any]] | None = None
        # Session upload registry: piface_id -> upload_id -> file path
        self._uploads: dict[str, dict[str, Path]] = {}
        # For testing: override the pi command
        self._pi_command_override: list[str] | None = None
        self._workspace_manager = workspace_manager or WorkspaceManager()

    # -- State helpers -------------------------------------------------------

    def _load_state(self) -> PifaceState:
        return load_state(self.state_path)

    def _save_state(self, state: PifaceState) -> None:
        save_state(state, self.state_path)

    def _update_record(self, piface_id: str, **kwargs: object) -> None:
        """Update fields on a session record and persist."""
        state = self._load_state()
        rec = state.sessions.get(piface_id)
        if rec is None:
            return
        for k, v in kwargs.items():
            setattr(rec, k, v)
        self._save_state(state)

    def _reconcile_stale_live_records(self, state: PifaceState) -> bool:
        """Mark persisted live records closed when no live runtime session exists."""
        changed = False
        now = datetime.now(UTC)

        for rec in state.sessions.values():
            if rec.status != SessionStatus.LIVE:
                continue

            pi_session = self.sessions.get(rec.piface_id)
            if pi_session is not None and pi_session.is_alive:
                continue

            if pi_session is not None and not pi_session.is_alive:
                self.sessions.pop(rec.piface_id, None)

            rec.status = SessionStatus.CLOSED
            rec.last_active = now
            changed = True

        return changed

    def _load_state_with_reconciled_liveness(self) -> PifaceState:
        state = self._load_state()
        if self._reconcile_stale_live_records(state):
            self._save_state(state)
        return state

    def _resolve_workspace_visual_overrides(
        self,
        record: SessionRecord,
        cache: dict[str, tuple[str | None, str | None]] | None = None,
    ) -> SessionRecord:
        if record.workspace_mode != "git_worktree":
            return record

        project_dir = record.effective_project_dir
        if cache is not None and project_dir in cache:
            theme_override, skin_override = cache[project_dir]
        else:
            try:
                ui = load_workspace_config(project_dir).ui
                theme_override = ui.theme_override
                skin_override = ui.skin_override
            except ValueError:
                theme_override = record.workspace_theme_override
                skin_override = record.workspace_skin_override
            if cache is not None:
                cache[project_dir] = (theme_override, skin_override)

        if (
            theme_override == record.workspace_theme_override
            and skin_override == record.workspace_skin_override
        ):
            return record

        return record.model_copy(
            update={
                "workspace_theme_override": theme_override,
                "workspace_skin_override": skin_override,
            }
        )

    @staticmethod
    def _normalize_session_file_path(session_file: str | None) -> str | None:
        if not isinstance(session_file, str):
            return None
        trimmed = session_file.strip()
        if not trimmed:
            return None
        return str(Path(trimmed).expanduser())

    async def allow_direnv(self, working_dir: str) -> None:
        """Run ``direnv allow`` for a directory in this server environment."""
        path = Path(working_dir)
        if not path.is_dir():
            raise ValueError(f"Directory does not exist: {working_dir}")

        if shutil.which("direnv") is None:
            raise ValueError("direnv is not installed")

        process = await asyncio.create_subprocess_exec(
            "direnv",
            "allow",
            str(path),
            cwd=str(path),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await process.communicate()

        if process.returncode != 0:
            out = stdout.decode(errors="replace").strip()
            err = stderr.decode(errors="replace").strip()
            detail = err or out or f"direnv allow failed with code {process.returncode}"
            raise RuntimeError(detail)

        logger.info("Approved direnv for %s", path)

    # -- Session-scoped file uploads ----------------------------------------

    def _shared_upload_root_from_record(self, rec: SessionRecord) -> Path | None:
        """Return the shared upload root for a record, or None if unavailable.

        Upload blobs are shared across all branched sessions in the same pi
        session directory:
            <session_dir>/uploads/_shared/...
        """
        session_file = self._normalize_session_file_path(rec.session_file)
        if not session_file:
            return None
        return Path(session_file).parent / "uploads" / "_shared"

    def get_session_upload_root(self, piface_id: str) -> Path | None:
        """Return the shared upload directory for a piface session."""
        rec = self.get_record(piface_id)
        if rec is None:
            return None
        return self._shared_upload_root_from_record(rec)

    def _add_upload_reference(self, state: PifaceState, piface_id: str, upload_id: str) -> None:
        upload = state.uploads.get(upload_id)
        if upload is None:
            return

        if piface_id not in upload.ref_sessions:
            upload.ref_sessions.append(piface_id)

        session_uploads = state.session_upload_ids.setdefault(piface_id, [])
        if upload_id not in session_uploads:
            session_uploads.append(upload_id)

    def clone_session_upload_references(self, source_piface_id: str, target_piface_id: str) -> None:
        """Copy shared upload references from one session to another."""
        state = self._load_state()
        source_upload_ids = state.session_upload_ids.get(source_piface_id, [])

        for upload_id in source_upload_ids:
            self._add_upload_reference(state, target_piface_id, upload_id)
            upload = state.uploads.get(upload_id)
            if upload is not None:
                self._uploads.setdefault(target_piface_id, {})[upload_id] = Path(upload.path)

        self._save_state(state)

    def create_upload(
        self,
        piface_id: str,
        *,
        file_name: str,
        mime_type: str,
        data: bytes,
    ) -> dict[str, Any]:
        """Persist a file upload and register it for later prompt rewriting."""
        rec = self.get_record(piface_id)
        if rec is None:
            raise ValueError("Session not found")

        upload_root = self._shared_upload_root_from_record(rec)
        if upload_root is None:
            raise ValueError("Session file not available")

        safe_name = Path(file_name).name or "file"
        upload_id = uuid.uuid4().hex
        upload_root.mkdir(parents=True, exist_ok=True)
        upload_path = upload_root / f"{upload_id}_{safe_name}"
        upload_path.write_bytes(data)

        state = self._load_state()
        state.uploads[upload_id] = UploadBlobRecord(
            upload_id=upload_id,
            path=str(upload_path),
            file_name=safe_name,
            mime_type=mime_type,
            size=len(data),
            ref_sessions=[piface_id],
        )
        state.session_upload_ids.setdefault(piface_id, []).append(upload_id)
        self._save_state(state)

        self._uploads.setdefault(piface_id, {})[upload_id] = upload_path

        return {
            "upload_id": upload_id,
            "file_name": safe_name,
            "mime_type": mime_type,
            "size": len(data),
            "path": str(upload_path),
        }

    def resolve_upload_paths(self, piface_id: str, upload_ids: list[str]) -> list[str]:
        """Resolve upload IDs to file paths, validating session ownership."""
        paths: list[str] = []
        by_id = self._uploads.setdefault(piface_id, {})
        state = self._load_state()

        for upload_id in upload_ids:
            if not isinstance(upload_id, str) or not upload_id.strip():
                raise ValueError("Invalid upload id")

            path = by_id.get(upload_id)
            if path is None:
                upload = state.uploads.get(upload_id)
                if upload is None or piface_id not in upload.ref_sessions:
                    raise ValueError(f"Unknown upload id: {upload_id}")
                path = Path(upload.path)
                by_id[upload_id] = path

            if not path.is_file():
                raise ValueError(f"Unknown upload id: {upload_id}")

            paths.append(str(path))

        return paths

    def inject_upload_paths_into_message(self, message: str, upload_paths: list[str]) -> str:
        """Append a session-local upload-path manifest to a prompt message."""
        if not upload_paths:
            return message

        manifest_lines = [
            "Attached files (session-local file paths):",
            *[f"- {path}" for path in upload_paths],
        ]
        manifest = "\n".join(manifest_lines)

        base = message.strip()
        if base:
            return f"{base}\n\n{manifest}"
        return f"{manifest}\n\nPlease inspect these files."

    def clear_session_uploads(self, piface_id: str) -> None:
        """Drop upload references for a session and GC unreferenced blobs."""
        self._uploads.pop(piface_id, None)

        state = self._load_state()
        upload_ids = state.session_upload_ids.pop(piface_id, [])

        for upload_id in upload_ids:
            upload = state.uploads.get(upload_id)
            if upload is None:
                continue

            upload.ref_sessions = [sid for sid in upload.ref_sessions if sid != piface_id]
            if upload.ref_sessions:
                continue

            path = Path(upload.path)
            try:
                if path.is_file():
                    path.unlink()
            except OSError:
                logger.warning("Failed to delete upload blob %s", path)

            state.uploads.pop(upload_id, None)

        self._save_state(state)

    # -- Session file capture ------------------------------------------------

    def _install_session_file_listener(self, piface_id: str, pi_session: PiSession) -> None:
        """Install an internal listener that captures the session file path.

        After the first ``agent_end`` event, we send ``get_state`` to pi and
        extract ``sessionFile`` from the response.  This keeps session files in
        pi's standard ``~/.pi/agent/sessions/`` directory so they show up in
        ``pi --resume``.
        """
        query_id = f"{_SESSION_FILE_QUERY_PREFIX}{piface_id}"
        captured = False

        def _on_event(event: dict) -> None:
            nonlocal captured
            if captured:
                return

            # After the first agent_end, query get_state for the session file
            if event.get("type") == "agent_end":
                asyncio.ensure_future(pi_session.send({"type": "get_state", "id": query_id}))

            # Capture the session file from the get_state response
            if (
                event.get("type") == "response"
                and event.get("id") == query_id
                and event.get("success")
            ):
                session_file = (event.get("data") or {}).get("sessionFile")
                normalized = self._normalize_session_file_path(session_file)
                if normalized:
                    captured = True
                    self._update_record(piface_id, session_file=normalized)
                    logger.info("Captured session file for %s: %s", piface_id, normalized)

        pi_session.add_listener(_on_event)

    def _next_internal_id(self, tag: str) -> str:
        return f"{_INTERNAL_QUERY_PREFIX}{tag}_{uuid.uuid4().hex}"

    async def _send_command_and_wait_for_response(
        self,
        pi_session: PiSession,
        command: dict[str, Any],
        *,
        timeout_seconds: float = 10.0,
    ) -> dict[str, Any]:
        """Send a command to a pi session and wait for its response."""
        command_id = command.get("id")
        if not isinstance(command_id, str) or not command_id.strip():
            command_id = self._next_internal_id("query")
            command["id"] = command_id

        loop = asyncio.get_running_loop()
        future: asyncio.Future[dict[str, Any]] = loop.create_future()

        def _on_event(event: dict[str, Any]) -> None:
            if event.get("type") != "response":
                return
            if event.get("id") != command_id:
                return
            if not future.done():
                future.set_result(event)

        pi_session.add_listener(_on_event)
        try:
            await pi_session.send(command)
            return await asyncio.wait_for(future, timeout=timeout_seconds)
        finally:
            pi_session.remove_listener(_on_event)

    @staticmethod
    def _extract_text_from_message_content(content: Any) -> str:
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts: list[str] = []
            for item in content:
                if not isinstance(item, dict):
                    continue
                if item.get("type") != "text":
                    continue
                text = item.get("text")
                if isinstance(text, str):
                    parts.append(text)
            return "".join(parts)
        return ""

    @staticmethod
    def _build_transcript_cleanup_prompt(transcript: str) -> str:
        return _TRANSCRIPT_CLEANUP_PROMPT_TEMPLATE.format(transcript=transcript.strip())

    def _extract_assistant_text_from_event_messages(self, event: dict[str, Any]) -> str:
        messages = event.get("messages")
        if not isinstance(messages, list):
            return ""

        assistant_texts: list[str] = []
        for message in messages:
            if not isinstance(message, dict):
                continue
            if message.get("role") != "assistant":
                continue
            text = self._extract_text_from_message_content(message.get("content")).strip()
            if text:
                assistant_texts.append(text)

        return "\n\n".join(assistant_texts)

    async def _run_prompt_and_capture_assistant_text(
        self,
        pi_session: PiSession,
        *,
        message: str,
        timeout_seconds: float = 45.0,
    ) -> str:
        command_id = self._next_internal_id("transcript_cleanup")
        loop = asyncio.get_running_loop()
        result_future: asyncio.Future[str] = loop.create_future()
        assistant_texts: list[str] = []

        def _on_event(event: dict[str, Any]) -> None:
            event_type = event.get("type")

            if event_type == "message_end":
                payload = event.get("message")
                if isinstance(payload, dict) and payload.get("role") == "assistant":
                    text = self._extract_text_from_message_content(payload.get("content")).strip()
                    if text:
                        assistant_texts.append(text)
                return

            if (
                event_type == "response"
                and event.get("id") == command_id
                and not event.get("success")
            ):
                error = event.get("error") or "Prompt failed"
                if not result_future.done():
                    result_future.set_exception(RuntimeError(str(error)))
                return

            if event_type != "agent_end":
                return

            combined = "\n\n".join(assistant_texts).strip()
            if not combined:
                combined = self._extract_assistant_text_from_event_messages(event).strip()
            if not result_future.done():
                result_future.set_result(combined)

        pi_session.add_listener(_on_event)
        try:
            await pi_session.send(
                {
                    "type": "prompt",
                    "id": command_id,
                    "message": message,
                }
            )
            try:
                return await asyncio.wait_for(result_future, timeout=timeout_seconds)
            except TimeoutError as exc:
                raise RuntimeError("Timed out waiting for transcript cleanup response") from exc
        finally:
            pi_session.remove_listener(_on_event)

    async def cleanup_transcript_with_pi(self, piface_id: str, transcript: str) -> str:
        """Use a short-lived low-thinking pi session to clean STT transcript text."""
        cleaned_input = transcript.strip()
        if not cleaned_input:
            return ""

        rec = self.get_record(piface_id)
        if rec is None:
            raise ValueError("Session not found")

        config = PiSessionConfig(
            working_dir=rec.effective_execution_dir,
            provider=rec.model_provider,
            model=rec.model_id,
            thinking_level="low",
            no_session=True,
            use_direnv=rec.use_direnv,
        )
        pi_session = PiSession(config)
        if self._pi_command_override:
            override = self._pi_command_override
            pi_session._build_command = lambda: override  # type: ignore[assignment]

        await pi_session.start()
        try:
            prompt = self._build_transcript_cleanup_prompt(cleaned_input)
            cleaned = await self._run_prompt_and_capture_assistant_text(pi_session, message=prompt)
            return cleaned.strip() or cleaned_input
        finally:
            await pi_session.stop()

    def read_fork_messages_from_session_file(
        self, session_file: str
    ) -> tuple[list[dict[str, str]], str | None]:
        """Read user messages with entry IDs from a persisted session file."""
        normalized = self._normalize_session_file_path(session_file)
        if normalized is None:
            return [], "file_not_found"

        path = Path(normalized)
        if not path.is_file():
            return [], "file_not_found"

        messages: list[dict[str, str]] = []
        try:
            for line in path.read_text().splitlines():
                if not line.strip():
                    continue
                try:
                    payload = json.loads(line)
                except json.JSONDecodeError:
                    continue

                if payload.get("type") != "message":
                    continue

                entry_id = payload.get("id")
                message = payload.get("message")
                if not isinstance(entry_id, str) or not isinstance(message, dict):
                    continue
                if message.get("role") != "user":
                    continue

                text = self._extract_text_from_message_content(message.get("content"))
                if text.strip():
                    messages.append({"entryId": entry_id, "text": text})
        except OSError:
            return [], "file_read_error"

        return messages, None

    async def get_fork_messages(self, piface_id: str) -> list[dict[str, str]]:
        """Return branchable user messages for a session."""
        rec = self.get_record(piface_id)
        if rec is None:
            raise ValueError("Session not found")

        if rec.status == SessionStatus.CLOSED:
            if not rec.session_file:
                raise ValueError("Session file not available")
            messages, error = self.read_fork_messages_from_session_file(rec.session_file)
            if error is not None:
                raise ValueError(error)
            return messages

        pi_session = self.get_session(piface_id)
        if pi_session is not None and pi_session.is_alive:
            response = await self._send_command_and_wait_for_response(
                pi_session,
                {
                    "type": "get_fork_messages",
                    "id": self._next_internal_id("fork_messages"),
                },
            )
            if not response.get("success"):
                raise ValueError(response.get("error") or "Failed to load fork messages")
            data = response.get("data")
            if not isinstance(data, dict):
                return []
            rows = data.get("messages")
            if not isinstance(rows, list):
                return []
            result: list[dict[str, str]] = []
            for row in rows:
                if not isinstance(row, dict):
                    continue
                entry_id = row.get("entryId")
                text = row.get("text")
                if isinstance(entry_id, str) and isinstance(text, str):
                    result.append({"entryId": entry_id, "text": text})
            return result

        if not rec.session_file:
            raise ValueError("Session file not available")

        messages, error = self.read_fork_messages_from_session_file(rec.session_file)
        if error is not None:
            raise ValueError(error)
        return messages

    async def branch_session(
        self,
        source_piface_id: str,
        *,
        entry_id: str,
        session_name: str | None = None,
    ) -> tuple[SessionRecord, str, bool]:
        """Fork from a source session entry into a new piface-managed live session."""
        source = self.get_record(source_piface_id)
        if source is None:
            raise ValueError("Session not found")

        if source.no_session:
            raise ValueError("Ephemeral sessions cannot be branched")

        source_session_file_value = self._normalize_session_file_path(source.session_file)
        if not source_session_file_value:
            raise ValueError("Session cannot be branched before session file is available")

        source_session_file = Path(source_session_file_value)
        if not source_session_file.is_file():
            raise ValueError("Session file no longer exists")

        # Create new workspace for the branched session
        execution_dir = source.effective_execution_dir
        workspace_fields: dict[str, object] = {
            "project_dir": source.effective_project_dir,
            "project_subdir": source.project_subdir,
            "workspace_mode": source.workspace_mode,
            "workspace_theme_override": source.workspace_theme_override,
            "workspace_skin_override": source.workspace_skin_override,
        }

        launch_prefix: list[str] | None = None

        if source.workspace_mode == "git_worktree":
            project_info = await self._workspace_manager.resolve_project(
                source.effective_project_dir
            )
            # Override subdir from source
            project_info = type(project_info)(
                project_dir=project_info.project_dir,
                project_subdir=source.project_subdir,
                is_git=project_info.is_git,
                config=project_info.config,
            )
            ws = await self._workspace_manager.create_workspace(
                project_info,
                session_name=session_name,
                source_branch=source.workspace_branch,
                use_direnv=source.use_direnv,
            )
            execution_dir = ws.execution_dir
            workspace_fields.update(
                workspace_mode="git_worktree",
                workspace_id=ws.workspace_id,
                workspace_name=ws.workspace_name,
                workspace_root=ws.workspace_root,
                workspace_branch=ws.workspace_branch,
                workspace_base_ref=ws.workspace_base_ref,
                workspace_theme_override=project_info.config.ui.theme_override,
                workspace_skin_override=project_info.config.ui.skin_override,
                workspace_created_by_piface=True,
                workspace_status="ready",
                bootstrap_log_path=ws.bootstrap_log_path,
            )

            if project_info.config.launch and project_info.config.launch.script:
                launch_prefix = self._workspace_manager.build_launch_command(
                    [],
                    execution_dir=execution_dir,
                    config=project_info.config,
                    use_direnv=source.use_direnv,
                    target_type="pi",
                )
                if not launch_prefix:
                    launch_prefix = None

        config = PiSessionConfig(
            working_dir=execution_dir,
            provider=source.model_provider,
            model=source.model_id,
            thinking_level=source.thinking_level,
            session_file=str(source_session_file),
            use_direnv=source.use_direnv if launch_prefix is None else False,
            launch_command_prefix=launch_prefix,
        )

        pi_session = PiSession(config)
        if self._pi_command_override:
            override = self._pi_command_override
            pi_session._build_command = lambda: override  # type: ignore[assignment]

        await pi_session.start()

        try:
            fork_response = await self._send_command_and_wait_for_response(
                pi_session,
                {
                    "type": "fork",
                    "entryId": entry_id,
                    "id": self._next_internal_id("fork"),
                },
            )
            if not fork_response.get("success"):
                raise ValueError(fork_response.get("error") or "Fork failed")

            fork_data = fork_response.get("data")
            if not isinstance(fork_data, dict):
                fork_data = {}
            selected_text = fork_data.get("text")
            selected_text = selected_text if isinstance(selected_text, str) else ""
            cancelled = bool(fork_data.get("cancelled"))

            if cancelled:
                await pi_session.stop()
                raise ValueError("Fork cancelled")

            if session_name is not None and session_name.strip():
                rename_response = await self._send_command_and_wait_for_response(
                    pi_session,
                    {
                        "type": "set_session_name",
                        "name": session_name.strip(),
                        "id": self._next_internal_id("set_session_name"),
                    },
                )
                if not rename_response.get("success"):
                    raise ValueError(
                        rename_response.get("error") or "Failed to rename forked session"
                    )

            state_response = await self._send_command_and_wait_for_response(
                pi_session,
                {
                    "type": "get_state",
                    "id": self._next_internal_id("branch_get_state"),
                },
            )
            if not state_response.get("success"):
                raise ValueError(
                    state_response.get("error") or "Failed to read forked session state"
                )

            state_data = state_response.get("data")
            if not isinstance(state_data, dict):
                state_data = {}

            branched_session_file = state_data.get("sessionFile")
            if not isinstance(branched_session_file, str) or not branched_session_file.strip():
                raise ValueError("Forked session file unavailable")

            new_piface_id = str(uuid.uuid4())
            now = datetime.now(UTC)
            normalized_name = (
                session_name.strip() if session_name and session_name.strip() else None
            )
            record = SessionRecord(
                piface_id=new_piface_id,
                working_dir=source.working_dir,
                status=SessionStatus.LIVE,
                session_file=branched_session_file,
                no_session=False,
                use_direnv=source.use_direnv,
                model_provider=source.model_provider,
                model_id=source.model_id,
                thinking_level=source.thinking_level,
                session_name=normalized_name or source.session_name,
                render_markdown=source.render_markdown,
                parent_piface_id=source_piface_id,
                branch_entry_id=entry_id,
                execution_dir=execution_dir,
                created_at=now,
                last_active=now,
                **workspace_fields,
            )

            self.sessions[new_piface_id] = pi_session
            state = self._load_state()
            state.sessions[new_piface_id] = record
            self._save_state(state)
            self.clone_session_upload_references(source_piface_id, new_piface_id)

            logger.info(
                "Branched session %s from %s at %s",
                new_piface_id,
                source_piface_id,
                entry_id,
            )
            return record, selected_text, False
        except Exception:
            if pi_session.is_alive:
                await pi_session.stop()
            raise

    # -- Session lifecycle ---------------------------------------------------

    async def create_session(
        self,
        working_dir: str,
        provider: str | None = "openai-codex",
        model: str | None = "gpt-5.5-codex",
        thinking_level: str | None = "medium",
        session_name: str | None = None,
        no_session: bool = False,
        render_markdown: bool = True,
        use_direnv: bool | None = None,
        worktree_root_override: Path | None = None,
        shared: bool = False,
    ) -> str:
        """Spawn a new pi session. Returns the piface_id."""
        piface_id = str(uuid.uuid4())
        effective_use_direnv = self.use_direnv_default if use_direnv is None else use_direnv

        # Resolve project and create workspace if in a git repo
        project_info = await self._workspace_manager.resolve_project(working_dir)

        execution_dir = working_dir
        workspace_fields: dict[str, object] = {
            "project_dir": project_info.project_dir,
            "project_subdir": project_info.project_subdir,
            "workspace_mode": "shared",
            "workspace_theme_override": None,
            "workspace_skin_override": None,
        }

        launch_prefix: list[str] | None = None

        if (
            not shared
            and project_info.is_git
            and project_info.config.workspace.mode == "git_worktree"
        ):
            ws = await self._workspace_manager.create_workspace(
                project_info,
                session_name=session_name,
                use_direnv=effective_use_direnv,
                worktree_root_override=worktree_root_override,
            )
            execution_dir = ws.execution_dir

            workspace_fields.update(
                workspace_mode="git_worktree",
                workspace_id=ws.workspace_id,
                workspace_name=ws.workspace_name,
                workspace_root=ws.workspace_root,
                workspace_branch=ws.workspace_branch,
                workspace_base_ref=ws.workspace_base_ref,
                workspace_theme_override=project_info.config.ui.theme_override,
                workspace_skin_override=project_info.config.ui.skin_override,
                workspace_created_by_piface=True,
                workspace_status="ready",
                bootstrap_log_path=ws.bootstrap_log_path,
            )

            # Build launch command prefix if launch config exists
            if project_info.config.launch and project_info.config.launch.script:
                launch_prefix = self._workspace_manager.build_launch_command(
                    [],
                    execution_dir=execution_dir,
                    config=project_info.config,
                    use_direnv=effective_use_direnv,
                    target_type="pi",
                )
                if not launch_prefix:
                    launch_prefix = None

        config = PiSessionConfig(
            working_dir=execution_dir,
            provider=provider,
            model=model,
            thinking_level=thinking_level,
            no_session=no_session,
            use_direnv=effective_use_direnv if launch_prefix is None else False,
            launch_command_prefix=launch_prefix,
        )

        pi_session = PiSession(config)
        if self._pi_command_override:
            override = self._pi_command_override
            pi_session._build_command = lambda: override  # type: ignore[assignment]

        # Install session file capture listener (unless ephemeral)
        if not no_session:
            self._install_session_file_listener(piface_id, pi_session)

        await pi_session.start()
        self.sessions[piface_id] = pi_session

        # Persist
        now = datetime.now(UTC)
        record = SessionRecord(
            piface_id=piface_id,
            working_dir=working_dir,
            status=SessionStatus.LIVE,
            no_session=no_session,
            use_direnv=effective_use_direnv,
            model_provider=provider,
            model_id=model,
            thinking_level=thinking_level,
            session_name=session_name,
            render_markdown=render_markdown,
            execution_dir=execution_dir,
            created_at=now,
            last_active=now,
            **workspace_fields,
        )
        state = self._load_state()
        state.sessions[piface_id] = record
        self._save_state(state)

        logger.info("Created session %s in %s", piface_id, execution_dir)
        return piface_id

    def get_or_create_pty(self, piface_id: str) -> PtySession:
        """Return the existing PTY for a session, or spawn a new one."""
        existing = self.pty_sessions.get(piface_id)
        if existing is not None:
            if existing.alive:
                return existing
            existing.close()  # ensure fd is released

        record = self.get_record(piface_id)
        if record is None:
            raise ValueError(f"No session record for {piface_id}")

        execution_dir = record.effective_execution_dir

        # Build launch command for PTY if workspace has launch config
        launch_command: list[str] | None = None
        if record.workspace_mode == "git_worktree" and record.workspace_root:
            ws_config = load_workspace_config(record.effective_project_dir)
            if ws_config.launch and ws_config.launch.script and "pty" in ws_config.launch.apply_to:
                launch_command = self._workspace_manager.build_launch_command(
                    ["bash", "-l"],
                    execution_dir=execution_dir,
                    config=ws_config,
                    use_direnv=record.use_direnv,
                    target_type="pty",
                )

        pty_session = PtySession.spawn(
            execution_dir,
            launch_command=launch_command,
        )
        self.pty_sessions[piface_id] = pty_session
        logger.info("Spawned PTY for session %s in %s", piface_id, execution_dir)
        return pty_session

    def close_pty(self, piface_id: str) -> None:
        """Close and remove the PTY for a session, if any."""
        pty_session = self.pty_sessions.pop(piface_id, None)
        if pty_session is not None:
            pty_session.close()
            logger.info("Closed PTY for session %s", piface_id)

    async def kill_session(self, piface_id: str) -> None:
        """Stop a pi session and mark it closed."""
        pi_session = self.sessions.get(piface_id)
        if pi_session is None:
            logger.warning("kill_session: unknown session %s", piface_id)
            return

        self.close_pty(piface_id)
        await pi_session.stop()
        self._update_record(
            piface_id,
            status=SessionStatus.CLOSED,
            last_active=datetime.now(UTC),
        )
        logger.info("Killed session %s", piface_id)

    async def resume_session(self, piface_id: str) -> SessionRecord:
        """Resume a previously closed session.

        If a persisted ``session_file`` exists, spawn pi with
        ``--session <path>`` so full history is restored.
        """
        rec = self.get_record(piface_id)
        if rec is None:
            raise ValueError("Session not found")

        if rec.no_session:
            raise ValueError("Ephemeral sessions cannot be resumed")

        existing = self.sessions.get(piface_id)
        if existing is not None and existing.is_alive:
            raise ValueError("Session is already live")

        # Validate workspace if git_worktree mode
        if rec.workspace_mode == "git_worktree" and rec.workspace_root:
            valid, error = await self._workspace_manager.validate_workspace(
                rec.workspace_root, rec.effective_project_dir
            )
            if not valid:
                raise ValueError(f"Workspace is no longer valid: {error}")

        execution_dir = rec.effective_execution_dir

        session_file = self._normalize_session_file_path(rec.session_file)
        if session_file and not Path(session_file).is_file():
            logger.warning(
                "Session file %s no longer exists for %s; starting fresh",
                session_file,
                piface_id,
            )
            session_file = None

        # Build launch prefix if workspace has launch config
        launch_prefix: list[str] | None = None
        if rec.workspace_mode == "git_worktree" and rec.workspace_root:
            ws_config = load_workspace_config(rec.effective_project_dir)
            if ws_config.launch and ws_config.launch.script:
                launch_prefix = self._workspace_manager.build_launch_command(
                    [],
                    execution_dir=execution_dir,
                    config=ws_config,
                    use_direnv=rec.use_direnv,
                    target_type="pi",
                )
                if not launch_prefix:
                    launch_prefix = None

        config = PiSessionConfig(
            working_dir=execution_dir,
            provider=rec.model_provider,
            model=rec.model_id,
            thinking_level=rec.thinking_level,
            session_file=session_file,
            use_direnv=rec.use_direnv if launch_prefix is None else False,
            launch_command_prefix=launch_prefix,
        )
        pi_session = PiSession(config)
        if self._pi_command_override:
            override = self._pi_command_override
            pi_session._build_command = lambda: override  # type: ignore[assignment]

        # If session_file is missing, capture it after first prompt.
        if not rec.session_file or not session_file:
            self._install_session_file_listener(piface_id, pi_session)

        await pi_session.start()
        self.sessions[piface_id] = pi_session

        now = datetime.now(UTC)
        self._update_record(
            piface_id,
            status=SessionStatus.LIVE,
            last_active=now,
            session_file=session_file,
        )

        updated = self.get_record(piface_id)
        if updated is None:
            raise RuntimeError("Failed to persist resumed session")

        logger.info("Resumed session %s (session_file=%s)", piface_id, session_file or "<new>")
        return updated

    async def send_to_session(self, piface_id: str, data: dict) -> None:
        """Forward a command dict to a pi session's stdin."""
        pi_session = self.sessions.get(piface_id)
        if pi_session is None or not pi_session.is_alive:
            logger.warning("send_to_session: session %s not available", piface_id)
            self.sessions.pop(piface_id, None)
            self._update_record(
                piface_id,
                status=SessionStatus.CLOSED,
                last_active=datetime.now(UTC),
            )
            return
        await pi_session.send(data)
        self._update_record(piface_id, last_active=datetime.now(UTC))

    def get_session(self, piface_id: str) -> PiSession | None:
        return self.sessions.get(piface_id)

    def list_sessions(self) -> list[SessionRecord]:
        """Return all session records from persisted state."""
        state = self._load_state_with_reconciled_liveness()
        cache: dict[str, tuple[str | None, str | None]] = {}
        return [
            self._resolve_workspace_visual_overrides(record, cache)
            for record in state.sessions.values()
        ]

    def get_record(self, piface_id: str) -> SessionRecord | None:
        """Get a single session record."""
        state = self._load_state_with_reconciled_liveness()
        record = state.sessions.get(piface_id)
        if record is None:
            return None
        return self._resolve_workspace_visual_overrides(record)

    def set_render_markdown(self, piface_id: str, enabled: bool) -> SessionRecord | None:
        """Persist per-session markdown rendering preference."""
        self._update_record(piface_id, render_markdown=enabled)
        return self.get_record(piface_id)

    def remove_record(self, piface_id: str) -> None:
        """Remove a session record by ID (and cleanup uploads)."""
        self.clear_session_uploads(piface_id)
        self.sessions.pop(piface_id, None)

        state = self._load_state()
        if piface_id in state.sessions:
            del state.sessions[piface_id]
            self._save_state(state)

    def read_history_from_session_file(
        self, session_file: str
    ) -> tuple[list[dict[str, Any]], str | None]:
        """Read pi message history directly from a persisted session file.

        Returns:
            (messages, error)
            - messages: list of pi message payloads (role/content/etc)
            - error: machine-readable error string, or None on success
        """
        normalized = self._normalize_session_file_path(session_file)
        if normalized is None:
            return [], "file_not_found"

        path = Path(normalized)
        if not path.is_file():
            return [], "file_not_found"

        messages: list[dict[str, Any]] = []
        try:
            for line in path.read_text().splitlines():
                if not line.strip():
                    continue
                try:
                    payload = json.loads(line)
                except json.JSONDecodeError:
                    continue

                if payload.get("type") != "message":
                    continue

                message = payload.get("message")
                if isinstance(message, dict):
                    messages.append(message)
        except OSError:
            return [], "file_read_error"

        return messages, None

    # -- Model listing -------------------------------------------------------

    async def get_available_models(self, *, force: bool = False) -> list[dict[str, Any]]:
        """Return available models by querying a live pi session.

        Results are cached in memory. Returns empty list if no live sessions.
        """
        if self._cached_models is not None and not force:
            return self._cached_models

        # Find any live session to query
        for piface_id, pi_session in self.sessions.items():
            if not pi_session.is_alive:
                continue

            loop = asyncio.get_running_loop()
            result_future: asyncio.Future[list[dict[str, Any]]] = loop.create_future()

            original_handler = pi_session.on_event

            def on_model_response(event: dict) -> None:
                if event.get("type") == "response" and event.get("id") == "__piface_models__":
                    if event.get("success") and event.get("data"):
                        models = event["data"].get("models", [])
                        if not result_future.done():
                            result_future.set_result(models)
                    else:
                        if not result_future.done():
                            result_future.set_result([])
                # Also forward to any existing handler
                if original_handler is not None:
                    original_handler(event)

            pi_session.on_event = on_model_response
            try:
                await pi_session.send(
                    {
                        "type": "get_available_models",
                        "id": "__piface_models__",
                    }
                )
                models = await asyncio.wait_for(result_future, timeout=10.0)
                self._cached_models = models
                return models
            except (TimeoutError, Exception):
                logger.warning("Failed to get models from session %s", piface_id)
            finally:
                pi_session.on_event = original_handler

        return []

    # -- Restore on startup --------------------------------------------------

    async def restore_sessions(self) -> None:
        """Re-spawn previously live sessions. Called on server startup.

        Sessions that have a stored ``session_file`` are resumed with
        ``--session <path>`` so pi reloads the full chat history from its
        standard session directory.
        """
        state = self._load_state()
        to_restore: list[SessionRecord] = []

        for rec in state.sessions.values():
            if rec.status != SessionStatus.LIVE:
                continue
            if rec.no_session:
                # Ephemeral sessions are not restored
                rec.status = SessionStatus.CLOSED
                continue
            to_restore.append(rec)

        self._save_state(state)

        for rec in to_restore:
            try:
                # Validate workspace if git_worktree mode
                if rec.workspace_mode == "git_worktree" and rec.workspace_root:
                    valid, error = await self._workspace_manager.validate_workspace(
                        rec.workspace_root, rec.effective_project_dir
                    )
                    if not valid:
                        logger.warning(
                            "Workspace invalid for session %s: %s; marking closed",
                            rec.piface_id,
                            error,
                        )
                        self._update_record(rec.piface_id, status=SessionStatus.CLOSED)
                        continue

                # If we have a captured session file, use --session to resume it.
                # Otherwise start fresh (the listener will capture the file
                # after the first prompt).
                session_file = self._normalize_session_file_path(rec.session_file)
                if session_file and not Path(session_file).is_file():
                    logger.warning(
                        "Session file %s no longer exists for %s; starting fresh",
                        session_file,
                        rec.piface_id,
                    )
                    session_file = None

                config = PiSessionConfig(
                    working_dir=rec.effective_execution_dir,
                    provider=rec.model_provider,
                    model=rec.model_id,
                    thinking_level=rec.thinking_level,
                    session_file=session_file,
                    use_direnv=rec.use_direnv,
                )
                pi_session = PiSession(config)
                if self._pi_command_override:
                    override = self._pi_command_override
                    pi_session._build_command = lambda: override  # type: ignore[assignment]

                # Install session file capture listener (in case it hasn't been
                # captured yet, or the file was missing and we start fresh).
                if not rec.session_file or not session_file:
                    self._install_session_file_listener(rec.piface_id, pi_session)

                await pi_session.start()
                self.sessions[rec.piface_id] = pi_session

                if rec.session_file != session_file:
                    self._update_record(rec.piface_id, session_file=session_file)

                logger.info(
                    "Restored session %s (session_file=%s)",
                    rec.piface_id,
                    session_file or "<new>",
                )
            except Exception:
                logger.exception("Failed to restore session %s", rec.piface_id)
                self._update_record(rec.piface_id, status=SessionStatus.CLOSED)

    # -- Shutdown ------------------------------------------------------------

    async def shutdown(self) -> None:
        """Stop all live sessions and PTYs."""
        for piface_id in list(self.pty_sessions):
            self.close_pty(piface_id)
        for piface_id, pi_session in self.sessions.items():
            if pi_session.is_alive:
                await pi_session.stop()
        logger.info("SessionManager shut down (%d sessions)", len(self.sessions))
