"""Speech transcription utilities powered by NVIDIA Parakeet v3."""

from __future__ import annotations

import asyncio
import subprocess
import tempfile
import threading
from pathlib import Path
from typing import Any

_MIME_SUFFIX_MAP = {
    "audio/webm": ".webm",
    "audio/webm;codecs=opus": ".webm",
    "audio/mp4": ".mp4",
    "audio/mpeg": ".mp3",
    "audio/wav": ".wav",
    "audio/x-wav": ".wav",
    "audio/flac": ".flac",
    "audio/ogg": ".ogg",
    "audio/ogg;codecs=opus": ".ogg",
}


def _disable_cuda_graphs_if_supported(model: Any) -> None:
    """Disable NeMo RNNT CUDA graphs when the model exposes the decoder toggle.

    Some Torch/CUDA builds used for older GPUs can trigger a runtime mismatch in
    NeMo's CUDA-graph setup path during the first Parakeet decode. Disabling CUDA
    graphs avoids that startup failure while keeping GPU inference enabled.
    """
    decoding = getattr(model, "decoding", None)
    decoder = getattr(decoding, "decoding", None)
    disable_cuda_graphs = getattr(decoder, "disable_cuda_graphs", None)
    if callable(disable_cuda_graphs):
        disable_cuda_graphs()


class SpeechTranscriptionError(RuntimeError):
    """Typed speech transcription error with an associated HTTP status code."""

    def __init__(self, message: str, *, code: str, status_code: int) -> None:
        super().__init__(message)
        self.code = code
        self.status_code = status_code


def infer_audio_suffix(mime_type: str) -> str:
    """Infer a reasonable temporary-file suffix from a MIME type."""
    normalized = mime_type.strip().lower()
    return _MIME_SUFFIX_MAP.get(normalized, ".bin")


def extract_transcription_text(result: Any) -> str:
    """Extract plain text from NeMo transcription outputs."""
    if isinstance(result, str):
        return result

    if isinstance(result, list) and result:
        item = result[0]
        if isinstance(item, str):
            return item
        if isinstance(item, dict):
            text = item.get("text")
            return text if isinstance(text, str) else ""
        text_attr = getattr(item, "text", None)
        return text_attr if isinstance(text_attr, str) else ""

    return ""


class ParakeetTranscriber:
    """Lazy-loading Parakeet v3 transcription service."""

    def __init__(
        self,
        *,
        model_name: str = "nvidia/parakeet-tdt-0.6b-v3",
        prefer_gpu: bool = True,
    ) -> None:
        self.model_name = model_name
        self.prefer_gpu = prefer_gpu
        self._model: Any | None = None
        self._model_lock = threading.Lock()

    async def transcribe(self, audio_bytes: bytes, mime_type: str) -> str:
        """Transcribe user-recorded audio bytes into text."""
        if not audio_bytes:
            raise SpeechTranscriptionError(
                "Audio payload is empty.",
                code="empty_audio",
                status_code=400,
            )

        text = await asyncio.to_thread(self._transcribe_sync, audio_bytes, mime_type)
        if not text.strip():
            raise SpeechTranscriptionError(
                "No transcript was produced for this audio clip.",
                code="empty_transcript",
                status_code=422,
            )
        return text.strip()

    def _transcribe_sync(self, audio_bytes: bytes, mime_type: str) -> str:
        model = self._get_or_load_model()

        with tempfile.TemporaryDirectory(prefix="piface-audio-") as tmp:
            tmp_dir = Path(tmp)
            source_path = tmp_dir / f"input{infer_audio_suffix(mime_type)}"
            wav_path = tmp_dir / "normalized.wav"
            source_path.write_bytes(audio_bytes)

            self._convert_to_wav_16khz_mono(source_path=source_path, wav_path=wav_path)

            try:
                result = model.transcribe([str(wav_path)])
            except Exception as exc:  # pragma: no cover - exercised by integration
                raise SpeechTranscriptionError(
                    f"Parakeet inference failed: {exc}",
                    code="inference_failed",
                    status_code=502,
                ) from exc

        return extract_transcription_text(result)

    def _get_or_load_model(self) -> Any:
        if self._model is not None:
            return self._model

        with self._model_lock:
            if self._model is not None:
                return self._model

            try:
                import nemo.collections.asr as nemo_asr  # type: ignore[import-not-found]
                import torch
            except ModuleNotFoundError as exc:
                raise SpeechTranscriptionError(
                    "Speech transcription dependencies are missing. Install the speech extra.",
                    code="missing_dependencies",
                    status_code=503,
                ) from exc

            try:
                model = nemo_asr.models.ASRModel.from_pretrained(model_name=self.model_name)
                if self.prefer_gpu and torch.cuda.is_available():
                    model = model.to("cuda")
                    _disable_cuda_graphs_if_supported(model)
            except Exception as exc:  # pragma: no cover - exercised by integration
                raise SpeechTranscriptionError(
                    f"Failed to load Parakeet model: {exc}",
                    code="model_load_failed",
                    status_code=503,
                ) from exc

            self._model = model
            return model

    @staticmethod
    def _convert_to_wav_16khz_mono(*, source_path: Path, wav_path: Path) -> None:
        command = [
            "ffmpeg",
            "-y",
            "-i",
            str(source_path),
            "-ac",
            "1",
            "-ar",
            "16000",
            str(wav_path),
        ]

        try:
            result = subprocess.run(command, capture_output=True, text=True, check=False)
        except FileNotFoundError as exc:
            raise SpeechTranscriptionError(
                "ffmpeg is required for audio conversion but was not found on PATH.",
                code="ffmpeg_missing",
                status_code=503,
            ) from exc

        if result.returncode != 0:
            detail = result.stderr.strip() or "Audio conversion failed"
            raise SpeechTranscriptionError(
                detail,
                code="audio_decode_failed",
                status_code=400,
            )
