"""Load and validate .piface/workspace.toml configuration."""

from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field, model_validator

_SUPPORTED_VERSIONS = {1}


class WorkspaceSection(BaseModel):
    mode: Literal["git_worktree"] = "git_worktree"
    root: str = "~/.local/share/piface/worktrees/{project_slug}"
    name_template: str = "{session_slug}-{short_id}"
    default_base: str = "current_branch"
    branch_prefix: str = "piface"
    auto_cleanup: bool = False


class EnvSection(BaseModel):
    use_direnv: bool = True


class FilesSection(BaseModel):
    model_config = {"populate_by_name": True}

    copy_paths: list[str] = Field(default_factory=list, alias="copy")
    symlink: list[str] = Field(default_factory=list)


class BootstrapSection(BaseModel):
    shell: str = "bash"
    use_direnv: bool = True
    cwd: Literal["workspace_root"] = "workspace_root"
    script: str | None = None
    timeout_seconds: int = 1800


class LaunchSection(BaseModel):
    shell: str = "bash"
    apply_to: list[Literal["pi", "pty"]] = Field(default_factory=lambda: ["pi", "pty"])
    script: str | None = None
    timeout_seconds: int = 30


class GitSection(BaseModel):
    create_branch: bool = True
    branch_template: str = "{branch_prefix}/{workspace_name}"
    detach: bool = False

    @model_validator(mode="after")
    def _validate_branch_detach(self) -> GitSection:
        if self.create_branch and self.detach:
            raise ValueError("git.create_branch and git.detach cannot both be true")
        return self


class UiSection(BaseModel):
    label_template: str = "{session_name} [{workspace_name}]"
    theme_override: Literal["light", "dark"] | None = None
    skin_override: (
        Literal[
            "default",
            "beos",
            "facebook2007",
            "nintendo",
            "nintendo-nes",
            "windows98",
            "winamp",
            "protoss",
            "terran",
            "zerg",
            "synthwave",
            "macos8",
        ]
        | None
    ) = None


class WorkspaceConfig(BaseModel):
    version: int = 1
    workspace: WorkspaceSection = Field(default_factory=WorkspaceSection)
    env: EnvSection = Field(default_factory=EnvSection)
    files: FilesSection = Field(default_factory=FilesSection)
    bootstrap: BootstrapSection | None = None
    launch: LaunchSection | None = None
    git: GitSection = Field(default_factory=GitSection)
    ui: UiSection = Field(default_factory=UiSection)

    @model_validator(mode="after")
    def _validate_version(self) -> WorkspaceConfig:
        if self.version not in _SUPPORTED_VERSIONS:
            raise ValueError(
                f"Unsupported workspace config version {self.version}; "
                f"supported: {sorted(_SUPPORTED_VERSIONS)}"
            )
        return self


def default_workspace_config() -> WorkspaceConfig:
    """Return the default config used when no .piface/workspace.toml exists."""
    return WorkspaceConfig()


def load_workspace_config(project_dir: str | Path) -> WorkspaceConfig:
    """Load .piface/workspace.toml from project_dir, or return defaults."""
    config_path = Path(project_dir) / ".piface" / "workspace.toml"
    if not config_path.is_file():
        return default_workspace_config()

    try:
        raw = tomllib.loads(config_path.read_text())
    except tomllib.TOMLDecodeError as exc:
        raise ValueError(f"Invalid TOML in {config_path}: {exc}") from exc

    try:
        return WorkspaceConfig.model_validate(raw)
    except Exception as exc:
        raise ValueError(f"Invalid workspace.toml schema in {config_path}: {exc}") from exc


def validate_workspace_root(resolved_root: Path, project_dir: Path) -> None:
    """Raise ValueError if resolved_root overlaps project_dir."""
    root = resolved_root.resolve()
    project = project_dir.resolve()
    if root == project or root.is_relative_to(project) or project.is_relative_to(root):
        raise ValueError(f"Workspace root {root} must be outside the project directory {project}")


def validate_file_paths(paths: list[str]) -> None:
    """Raise ValueError for path traversal or absolute paths."""
    for p in paths:
        if Path(p).is_absolute():
            raise ValueError(f"File path must not be absolute: {p}")
        if ".." in Path(p).parts:
            raise ValueError(f"File path traversal not allowed: {p}")


def render_template(template: str, variables: dict[str, str]) -> str:
    """Substitute {var_name} placeholders with values from variables dict."""
    return template.format(**variables)


def save_workspace_config(project_dir: str | Path, config: WorkspaceConfig) -> None:
    """Write a WorkspaceConfig to .piface/workspace.toml."""
    config_dir = Path(project_dir) / ".piface"
    config_dir.mkdir(parents=True, exist_ok=True)
    config_path = config_dir / "workspace.toml"
    config_path.write_text(serialize_workspace_config(config))


def serialize_workspace_config(config: WorkspaceConfig) -> str:
    """Serialize a WorkspaceConfig to TOML format."""
    lines: list[str] = [f"version = {config.version}", ""]

    # [workspace]
    ws = config.workspace
    lines.append("[workspace]")
    lines.append(f'mode = "{ws.mode}"')
    lines.append(f'root = "{ws.root}"')
    lines.append(f'name_template = "{ws.name_template}"')
    lines.append(f'default_base = "{ws.default_base}"')
    lines.append(f'branch_prefix = "{ws.branch_prefix}"')
    lines.append(f"auto_cleanup = {_toml_bool(ws.auto_cleanup)}")
    lines.append("")

    # [env]
    lines.append("[env]")
    lines.append(f"use_direnv = {_toml_bool(config.env.use_direnv)}")
    lines.append("")

    # [files]
    lines.append("[files]")
    lines.append(f"copy = {_toml_str_list(config.files.copy_paths)}")
    lines.append(f"symlink = {_toml_str_list(config.files.symlink)}")
    lines.append("")

    # [bootstrap] (optional)
    if config.bootstrap and config.bootstrap.script:
        bs = config.bootstrap
        lines.append("[bootstrap]")
        lines.append(f'shell = "{bs.shell}"')
        lines.append(f"use_direnv = {_toml_bool(bs.use_direnv)}")
        lines.append(f"timeout_seconds = {bs.timeout_seconds}")
        lines.append(f"script = {_toml_multiline_string(bs.script)}")
        lines.append("")

    # [launch] (optional)
    if config.launch and config.launch.script:
        la = config.launch
        lines.append("[launch]")
        lines.append(f'shell = "{la.shell}"')
        lines.append(f"apply_to = {_toml_str_list(la.apply_to)}")
        lines.append(f"timeout_seconds = {la.timeout_seconds}")
        lines.append(f"script = {_toml_multiline_string(la.script)}")
        lines.append("")

    # [git]
    gt = config.git
    lines.append("[git]")
    lines.append(f"create_branch = {_toml_bool(gt.create_branch)}")
    lines.append(f'branch_template = "{gt.branch_template}"')
    lines.append(f"detach = {_toml_bool(gt.detach)}")
    lines.append("")

    # [ui]
    ui = config.ui
    lines.append("[ui]")
    lines.append(f'label_template = "{ui.label_template}"')
    if ui.theme_override is not None:
        lines.append(f'theme_override = "{ui.theme_override}"')
    if ui.skin_override is not None:
        lines.append(f'skin_override = "{ui.skin_override}"')
    lines.append("")

    return "\n".join(lines) + "\n"


def _toml_bool(val: bool) -> str:
    return "true" if val else "false"


def _toml_str_list(items: list[str]) -> str:
    if not items:
        return "[]"
    inner = ", ".join(f'"{item}"' for item in items)
    return f"[{inner}]"


def _toml_multiline_string(text: str | None) -> str:
    if not text:
        return '""'
    return f'"""\n{text}\n"""'
